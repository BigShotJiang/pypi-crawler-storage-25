import pandas                               as pd 
import numpy                                as np
from typing                                 import List, Dict 

from LOG                                    import log
from PyDBLinks.DBDuck                       import DuckDB
from PyTools.Tools                          import TqdmN,DFToType
from DirsFile                               import Save_Csv,Mkdir,Save_Toml,Read_Toml
from .ICIR                                  import OneDay_IC,OneReturnCol_ICIR
from .PreProcess                            import 因子预处理
from ..MgrData.MgrDataHub                   import MgrDataHub
from ..utils.DataType                       import KLine,KLineN
# 导入绘图库
import matplotlib.pyplot                    as plt
import matplotlib.dates                     as mdates
import os

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

class DaysFactorICIR:
    """
    # 因子计算配置字典
    cfg = {
        # ==================== 数据处理相关配置 ====================
        # 分组数量（用于因子分组分析）
        "group_num": 10,
        # 是否进行缩尾处理（Winsorize），用于剔除异常值
        "do_winsor": True,
        # 是否进行中性化处理（行业/市值中性化）
        "do_neutral": True,
        # 是否进行标准化处理（Z-score 标准化）
        "do_std": True,
        # 证券代码列名
        "code_col": "code",

        # ==================== 文件路径相关配置 ====================
        # 数据存储根路径
        "SaveDataPath": "./factor_data/",
        # 因子名称（核心标识，需根据实际因子命名）
        "FactorName": "Momentum_120D",

        # ==================== 周期与表名配置 ====================
        # 周期（1440=日频）
        "Period": "1440",
        # 表名会在代码中动态拼接，此处无需配置 TblName
        # TblName 由代码根据 Period 和当日时间生成

        # ==================== 数据库存储配置 ====================
        # 数据库文件名称（用于 DuckDB 存储）
        "SaveDBName": "Momentum_Factor",

        # ==================== 收益列配置 ====================
        # 不同周期的收益列名（用于计算 IC）
        "return_cols": [
            'REBChgPer1', 'REBChgPer2', 'REBChgPer3',
            'REBChgPer5', 'REBChgPer10', 'REBChgPer20',
            'REBChgPer30', 'REBChgPer60', 'REBChgPer120'
        ]
    }
    # 如果你使用 TOML 格式（更适合配置文件），对应的内容如下：
 
    # factor_config.toml
    group_num = 10
    do_winsor = true
    do_neutral = true
    do_std = true
    code_col = "code"

    SaveDataPath = "./factor_data/"
    FactorName = "Momentum_120D"

    Period = "1440"
    SaveDBName = "Momentum_Factor"

    return_cols = [
        "REBChgPer1", "REBChgPer2", "REBChgPer3",
        "REBChgPer5", "REBChgPer10", "REBChgPer20",
        "REBChgPer30", "REBChgPer60", "REBChgPer120"
    ]
    """

    def __init__(self,cfg:dict ):
        self.group_num      = cfg.get("group_num",10)
        self.do_winsor      = cfg.get("do_winsor" ,{"mathed":"MADWIN","arges":{"k":5, "lower_quantile":0.01, "upper_quantile":0.99}})
        self.do_neutral     = cfg.get("do_neutral",{"mathed":"INDCAP"})
        self.do_std         = cfg.get("do_std",True)

        self.code_col       = cfg.get("code_col","code")
        self.FactorName     = cfg.get("FactorName","")
        self.SaveDataPath   = os.path.join(cfg.get("SaveDataPath","./"),self.FactorName)
        Mkdir( self.SaveDataPath)

        self.Period         = int(cfg.get("Period",1440))
        self.TblName        = cfg.get("TblName",f"Tbl_{self.FactorName}_IC{self.Period}")
        self.SaveDBName     = f"{cfg.get('SaveDBName',self.FactorName)}_{self.Period}" 
        self.prev_groups    = Read_Toml(f"{self.FactorName}_prev_groups", self.SaveDataPath)

        self.return_cols    = cfg.get("return_cols",[ 
                                'REBChgPer1','REBChgPer2', 'REBChgPer3', 
                                'REBChgPer5','REBChgPer10', 'REBChgPer20', 
                                'REBChgPer30', 'REBChgPer60','REBChgPer120'
                                ])
        self.DDLDict         :dict  = None  # 表名 到 DDL 的映射
        self.InitDBSave(cfg)
        self.MgrData:MgrDataHub  = MgrDataHub(cfg)### 数据管理器
    def getExampleCfg(self):
        info = '''
        cfg =  {
            "SaveDataPath": f"{DataPath}/结果报告/",
            "FactorName":"amount" , ###  total_mv "ChgPer120", HLPer1 ,ChgPerY ChgPer1
            "do_winsor" : {"mathed":"MADWIN","arges":{"k":5, "lower_quantile":0.01, "upper_quantile":0.99}},
            "do_neutral": {"mathed":"INDCAP"},###　中性化处理: 行业+市值  INDCAP
            "do_std": True,
            "return_cols": [
                "REBChgPer1", "REBChgPer2", "REBChgPer3",
                "REBChgPer5", 
                "REBChgPer10", "REBChgPer20",
                # 'REBChgPer30', 'REBChgPer60', 'REBChgPer120'
                ],
            "URL": "http://192.168.31.111:2012",
            "Username": "18866668888",
            "Password": "123456",
            }
        Factor  = Class_AnyOne(cfg)
        Factor.runDateRange("20050101",'20251231')
        Factor.FlashPrevGroups()### 刷新上一期分组数据 以便断续处理
        Factor.Run_DaysIC(['turnover_rate_f'])### 需要额外添加的现成字段 ,['total_mv']
        # ### 因子综合统计报告 包含因子IC、分位数统计等分析结果
        rstdata = Factor.因子综合统计报告(cuthold=True)
        Factor.因子分组回测报告(duckdb,["REBChgPer5","REBChgPer10","REBChgPer20"],True)
        Factor.duckdb.Close()
        '''
        return info

    def InitDBSave(self,cfg:dict, read_only=False):
        '''
        初始化DuckDB数据库 
        用于保存因子数据
        '''
        defaultcfg = {
            'db_path': self.SaveDataPath,  # 数据库文件夹路径
            'db_name': f"{self.FactorName}.db",          # 数据库文件名
            'memory_limit':cfg.get('DuckDB_MemoryLimit','2GB'),         # 内存限制
            'threads': cfg.get('DuckDB_Threads',4),                   # 线程数
            'temp_directory': cfg.get('DuckDB_TempPath','./tmp'),     # 临时目录
            'read_only': cfg.get('DuckDB_Read_only',read_only)              # 是否只读
            }
        self.duckdb = DuckDB(defaultcfg)
        ok = self.duckdb.CreateDB(self.SaveDBName)
        log.Info(f"Create DB {self.SaveDBName}:{ok}")
        return self.duckdb

    def 因子综合统计报告(self,p_value:float = 0.05,cuthold:bool=False,Cost:float=0.0015):
        '''
        因子综合统计报告
        包含因子IC、分位数统计等分析结果
        p_value:### p值 用于计算ICIR
        cuthold:### 将资金分成num分以应对N天滚动持仓统计
        Cost:### 成本 手续费1.5/1000
        '''
        df = self.duckdb.GetData(f"SELECT * FROM {self.SaveDBName}.{self.TblName}")
        df = df.dropna(subset=['rank_ic'])
        strrst = []
        for factor_col in df['factor_col'].unique():
            for return_col in df['return_col'].unique():
                ic_valid_df = df[(df['factor_col'] == factor_col) & (df['return_col'] == return_col)]
                ic_stats = OneReturnCol_ICIR(ic_valid_df,p_value)# 调用函数并打印结果
                group_return = self.N周期收益分组回测统计(ic_valid_df,return_col,cuthold,Cost)
                strrst.append({**ic_stats,**group_return}) 
        Save_Csv(pd.DataFrame(strrst),f'{ self.SaveDataPath}/{self.FactorName}_综合统计结果.csv',mode='w')
        limitrst = self.获取因子分位数统计(df)
        return strrst,limitrst
    def 获取因子分位数统计(self, df:pd.DataFrame=None):
        '''获取因子分位数统计结果'''
        rst = "因子{self.FactorName}各分位数:"
        if self.duckdb is not None:
            df = self.duckdb.GetData(f"SELECT * FROM {self.SaveDBName}.{self.TblName}")
        if df.empty or df is None:
            log.Info("没有数据可供分析")
            return rst
        df = df.dropna(subset=['rank_ic'])
        for return_col in df['return_col'].unique():
            df_return = df[df['return_col'] == return_col]
            for num in ['0.1','0.25','0.5','0.75','0.9']:
                df_return[f"factor_q_{num}"] = df_return["factor_quantile_1025507590"].apply(lambda x: eval(x)[num] )
            rst = f'''
                因子{self.FactorName}各分位数:
                factor_q_0.1: {df_return['factor_q_0.1'].mean()}
                factor_q_0.25: {df_return['factor_q_0.25'].mean()}
                factor_q_0.5: {df_return['factor_q_0.5'].mean()}
                factor_q_0.75: {df_return['factor_q_0.75'].mean()}
                factor_q_0.9: {df_return['factor_q_0.9'].mean()}
                '''
            break
        log.Info(df.columns)
        log.Info(rst)
        return rst
    def 因子分组回测报告(self,return_cols:list=None,cuthold:bool=False,Cost:float=0.0015):
        '''
        因子分组回测报告
        '''
        df = self.duckdb.GetData(f"SELECT * FROM {self.SaveDBName}.{self.TblName}")
        df = df.dropna(subset=['rank_ic'])
        if return_cols is None: return_cols = df['return_col'].unique()
        ### 对每个因子列和每个返回列进行分组回测统计
        rst = []
        for factor_col in df['factor_col'].unique():
            for return_col in return_cols:
                ic_valid_df = df[(df['factor_col'] == factor_col) & (df['return_col'] == return_col)]
                group_return = self.N周期收益分组回测统计(ic_valid_df,return_col,cuthold,Cost)
                rst.append(group_return)
        return rst
    def N周期收益分组回测统计(self,df,return_col,cuthold:bool=False,Cost:float=0.0015):
        '''
        粗浅的回测
        按因子分组, 每个分组按return_col进行回测, 每个分组的回测结果合并到一个DataFrame中
        cuthold:### 将资金分成num分以应对N天滚动持仓统计
        Cost:### 成本 手续费1.5/1000
        '''
        num = 2 * float(return_col.replace("REBChgPer",""))### 按持有天数将资金分成num份完成连续交易日的num天持续持有模拟
        df["group_returns_mean"]    = df["group_returns_mean"].apply(lambda x:
                                        {str(key):round(value,3) for key,value in eval(x.replace('=',':')).items()})
        df["turnover"]              = df["turnover"].apply(lambda x:
                                        {str(key):round(value,3) for key,value in eval(x.replace('=',':')).items()})
        ### 回测每组的收益 
        group_return ={}
        pltdatas = pd.DataFrame()
        for i in range(self.group_num):
            df[f"group_{i}"]        = df["group_returns_mean"].apply(lambda x:x.get(str(i),0)/100)
            df[f"turnover_{i}"]     = df["turnover"].apply(lambda x:x.get(str(i),0))
            ### 成本及收益计算
            df[f"Cost{i}"]          = df[f"turnover_{i}"] * Cost
            df[f"group_{i}_Cost"]   = df[f"group_{i}"] - df[f"Cost{i}"]
            if cuthold:### 将资金分成num分以应对N天滚动持仓统计
                df[f"group_{i}"]    = 1 + df[f"group_{i}_Cost"]/num
            else:
                df[f"group_{i}"]    = 1 + df[f"group_{i}_Cost"]
            df[f"bkline_{i}"]       = df[f"group_{i}"].cumprod()
            df[f"bktover_{i}"]      = 1+ df[f"turnover_{i}"]
            df[f"bktover_{i}"]      = df[f"bktover_{i}"].cumprod()
            rst = {
                "cuthold":cuthold,"Cost":Cost,
                f"group_{i}_return_col":return_col,
                f"days_{i}":len(df),
                f"bkline_{i}":df[f"bkline_{i}"].iloc[-1],
                f"bkline_{i}_Per(%)":100*df[f"bkline_{i}"].iloc[-1]/1,
                f"mean_turnover_{i}":df[f"turnover_{i}"].mean(),
                f"bktover_{i}":df[f"bktover_{i}"].iloc[-1],
                 }
            group_return.update(rst)        
            pltdf = df[['trade_date','factor_col', 'target_col','return_col', 
                        f"bkline_{i}",f"bktover_{i}",f"turnover_{i}"]].copy() 
            pltdatas = pd.concat([pltdatas,pltdf],axis=0)
        self.ShowRstPlt(pltdatas,return_col)
        return group_return
    def ShowRstPlt(self,data,return_col:str ):
        # 创建2个子图：净值图（上）和换手率图（下）
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10), sharex=True)
        
        # 定义颜色列表，确保每条线颜色不同
        colors = ['red', 'blue', 'green', 'orange', 'purple', 'brown', 'pink', 'gray', 'olive', 'cyan',
                 'magenta', 'yellow', 'navy', 'teal', 'coral', 'indigo', 'maroon', 'gold', 'silver', 'lime']
        
        # 第一个子图：净值曲线
        for i in range(self.group_num):
            color = colors[i % len(colors)]  # 循环使用颜色列表
            ax1.plot(data["trade_date"], data[f"bkline_{i}"], label=f"Group_{i}", color=color, linewidth=2)
        ax1.set_title(f"Factor Group Backtest Result_{return_col}")
        ax1.set_ylabel("Net Value")
        ax1.grid(True, linestyle="--", alpha=0.7)
        ax1.legend(loc="upper left")
        
        # 第二个子图：换手率曲线
        for i in range(self.group_num):
            color = colors[i % len(colors)]  # 使用相同的颜色对应关系
            ax2.plot(data["trade_date"], data[f"turnover_{i}"], label=f"Group_{i}", color=color, linewidth=2)
        ax2.set_xlabel("date")
        ax2.set_ylabel("turnover")
        ax2.grid(True, linestyle="--", alpha=0.7)
        ax2.legend(loc="upper left")
        
        # 设置日期格式和间隔
        # 根据数据长度自动调整刻度间隔
        date_count = len(data["trade_date"])
        if date_count <= 60:
            interval = 15  # 少于30个日期，每5天显示一个
        elif date_count <= 200:
            interval = 30  # 30-100个日期，每15天显示一个
        elif date_count <= 400:
            interval = 60  # 100-200个日期，每月显示一个
        else:
            interval = 120  # 超过200个日期，每2个月显示一个
        
        # 设置主要刻度
        ax2.xaxis.set_major_locator(mdates.DayLocator(interval=interval))
        # 自动旋转日期标签并调整布局
        plt.gcf().autofmt_xdate(rotation=45, ha='right')
        plt.tight_layout()
        # 保存图表
        savepath = f"{ self.SaveDataPath}/{self.FactorName}_{return_col}.png"
        plt.savefig(savepath)
        log.Info(f"回测结果图保存在: {savepath}")
    def 去ST涨停(self,df:pd.DataFrame):
        '''
        去除ST 涨停股票
        '''
        ### 去除ST 涨停股票
        data = df[~df['code'].isin(self.MgrData.STCodeList)].copy()### 去除ST股票
        # data["uplimit"] = data["code"].apply(lambda x: self.MgrData.DaysUPDWDict.get(x,{}).get("uplimit", 9999))### 计算涨停价格
        # data["dwlimit"] = data["code"].apply(lambda x: self.MgrData.DaysUPDWDict.get(x,{}).get("dwlimit",-9999))### 计算跌停价格
        # data['ZT']      = np.where(data['close'] >= data['uplimit'], 1, 0)### 涨停股票列表
        # data['DT']      = np.where(data['close'] <= data['dwlimit'], 1, 0)### 跌停股票列表
        # data            = data[data['ZT']==0]

        data = data.merge(updw_data[['code', 'uplimit', 'dwlimit']], on='code', how='left')
        data['uplimit'] = data['uplimit'].fillna(9999)
        data['dwlimit'] = data['dwlimit'].fillna(-9999)
        data['ZT'] = np.where(data['close'] >= data['uplimit'], 1, 0)
        data['DT'] = np.where(data['close'] <= data['dwlimit'], 1, 0)
        data = data[data['ZT']==0]
        return  data
 
    def OneIC_RST(self,data:pd.DataFrame, tradedate:str=""):
        '''
        计算单个交易日的IC统计结果
        '''
        ### 因子预处理
        df  = 因子预处理(data,self.FactorName,
                            {'do_winsor' :self.do_winsor , 
                            'do_neutral' :self.do_neutral,  
                            'do_std'     :self.do_std })
        
        ### 计算IC
        results, self.prev_groups = OneDay_IC(
                        df,tradedate,
                        self.FactorName,
                        self.return_cols,
                        self.group_num,
                        self.do_winsor,self.do_neutral,self.do_std,
                        self.code_col,self.prev_groups)
        self.SavePrevGroups(tradedate)
        return results

    def SavePrevGroups(self,tradedate:str): 
        '''
        保存上一个交易日的分组信息
        '''
        Save_Toml({"trade_date":tradedate,"prev_groups":self.prev_groups},
                f'{self.FactorName}_prev_groups', self.SaveDataPath,mode='w')

    def Set_ReturnCols(self,return_cols:List[str]):### 设置收益周期列
        '''
        设置收益周期列
        '''
        self.return_cols = return_cols

    def FlashPrevGroups(self):
        '''
        读取上一个交易日的分组信息
        '''
        prev_groups_filedata = Read_Toml(f"{self.FactorName}_prev_groups", self.SaveDataPath)
        if prev_groups_filedata:
            self.prev_groups = prev_groups_filedata.get("prev_groups",{})
            trade_date  = prev_groups_filedata.get("trade_date","")
            self.KDates=[x for x in self.KDates if x>trade_date]

    def SaveOneDayIC(self,results:List[Dict] ):
        '''
        保存IC结果到DuckDB
        '''
        data = pd.DataFrame(results)
        if  data.empty:
            log.Warn("没有有效的IC结果数据可供保存")
            return
        if self.DDLDict is None:
            self.DDLDict     = self.duckdb.getDDL(data)
            ok = self.duckdb.CreateTbl(self.TblName, 
                DDL     =   self.DDLDict,
                Mkey    =   ['trade_date','return_col','factor_col'],
                dbname  =   self.SaveDBName )
            log.Info(f"Create Table {self.TblName} in DB {self.SaveDBName}:{ok}")
        self.duckdb.SaveDF(data , self.TblName , dbname = self.SaveDBName  )

    def Run_DaysIC(self , Fileds:List[str]=[]):
        '''
        计算K线日期列表中每个交易日的因子IC
        '''
        Tqdm = TqdmN(self.KDates)
        self.MgrData.getBaseInfo()### 获取基础股票信息, 包含CodeInfo等
        for Tradedate in self.MgrData.KDates:
            Tqdm.update(Tradedate)
            self.MgrData.FlashST(f"{Tradedate} 150000",period)
            pers_df = self.MgrData.getPers(f"{Tradedate} 150000",period)
            updw_df = self.MgrData.FlashUPDW(f"{Tradedate} 150000",period)
            metrics_df = self.MgrData.getMetrics(f"{Tradedate} 150000",period)
            # 第一步：以 pers_df 为主表，左连接 updw_df
            pers_df = pers_df.merge(updw_df, on=['code', 'trade_date'], how='left')
            # 第二步：继续以当前结果（仍包含所有 pers_df 记录）为主表，左连接 metrics_df
            pers_df = pers_df.merge(metrics_df, on=['code', 'trade_date'], how='left')
            for Time  in self.MgrData.KTimes:
                ### 获取行情数据 --> 发送给策略处理
                TradeTime = f"{Tradedate} {Time}"
                PeriodKLs ={}
                for period in self.MgrData.Periods:
                    if Time in self.MgrData.PeriodTimes[period]:
                        klines =  self.MgrData.getDaysKlines(TradeTime,period)
                        self.OnFactorMark(TradeTime,period,klines)### 处理因子标记 
                        klines = klines.to_dict(orient='records')
                        PeriodKLs[period] ={x['code']:KLine(**x) for x in klines}### 转换为KLineN类型 ### 按周期记录
            data  = self.Get_FactorData(Tradedate,pers_df,PeriodKLs,Fileds)
            rst = self.OneIC_RST(data,tradedate)### 计算单个交易日的IC
            self.SaveOneDayIC(rst)### 保存单个交易日的IC
    def OnFactorMark(self,TradeTime:str,period:int,data:pd.DataFrame):
        '''
        多周期的时间节点 K线数据 生成因子标记
        '''
        pass
    def Get_FactorData(self,tradedate:str,pers_df:pd.DataFrame,
                PeriodKLs:Dict[str,Dict[str,KLineN]],Fileds:List[str]):
        '''
        最终的因子工程
        '''
        ### Set_DFType(data)### 为数据集设置数据类型
        ### 去ST涨停(data) 去掉ST涨停的股票

        pass

    def Set_DFType(self,data:pd.DataFrame):### 为数据集设置数据类型
        data['industry'] = data['industry'].apply(lambda x:str(x).split('-')[0])
        DFToType(data,['trade_date', 'trade_time'],str)
        DFToType(data,["total_mv",
                    'ChgPerW', 'ChgPerM',  'ChgPerY','HLPer1','close',
                    'ChgPer1','ChgPer2', 'ChgPer3', 'ChgPer5', 
                    'ChgPer10', 'ChgPer20', 'ChgPer30','ChgPer60',
                    'ChgPer120',  
                    'REBChgPer1', 'REBChgPer2', 'REBChgPer3', 'REBChgPer5',
                    'REBChgPer10', 'REBChgPer20', 'REBChgPer30', 'REBChgPer60',
                    'REBChgPer120'],float)
        data = data.replace(-9999, np.nan)
        return data
