"""Discovery commands: tools, resources, prompts.

All discovery is always live from the server — no caching.
The completion cache is updated as a side-effect for tab completion only.

Supports two modes:
  - Hub mode (default): connects to /hub/ for platform-level tools
  - Bundle mode (--bundle <slug>): connects to /bundle/<slug>/ for direct
    bundle tool access with full schema disclosure via standard MCP protocol
"""

import asyncio

import click

from mcpbundles.auth_resolve import resolve_auth
from mcpbundles.config import AuthError, CLISettings
from mcpbundles.exit_codes import USER_ERROR, CONNECTION_ERROR
from mcpbundles.mcp_client import hub_session, ConnectionError
from mcpbundles.completion import update_cache
from mcpbundles.output import (
    render_tools_table, render_tools_json,
    render_resources_table, render_resources_json,
    render_prompts_table, render_prompts_json,
    render_error, print_json, render_warning,
)
from mcpbundles.schema import render_tool_detail
from mcpbundles.completion import tool_name_completer
from mcpbundles.endpoints import resolve_endpoint


@click.command()
@click.argument("tool_name", required=False, shell_complete=tool_name_completer)
@click.option("--filter", "-f", "filter_str", help="Filter tools by name or description")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option("--as", "connection", help="Use a named connection (e.g. @hub)")
@click.option("--bundle", "bundle_slug", help="Connect directly to a bundle endpoint (e.g. attio)")
@click.pass_context
def tools(ctx: click.Context, tool_name: str | None, filter_str: str | None, as_json: bool, connection: str | None, bundle_slug: str | None) -> None:
    """List available MCP tools, or show detail for one tool.

    By default, lists hub-level tools. Use --bundle to connect directly
    to a bundle endpoint for full tool schema disclosure.

    Examples:
        mcpbundles tools                        # list hub tools
        mcpbundles tools --bundle attio          # list all Attio tools
        mcpbundles tools --bundle attio -f list  # filter Attio tools
        mcpbundles tools code_execution          # show schema for one
        mcpbundles tools --json                  # JSON output
    """
    asyncio.run(_tools_impl(ctx, tool_name, filter_str, as_json, connection, bundle_slug))


async def _tools_impl(ctx: click.Context, tool_name: str | None, filter_str: str | None, as_json: bool, connection: str | None, bundle_slug: str | None) -> None:
    settings: CLISettings = ctx.obj["settings"]
    try:
        auth = resolve_auth(settings, connection)
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)

    endpoint = resolve_endpoint(bundle_slug)

    try:
        async with hub_session(auth.token, auth.url, endpoint) as session:
            result = await session.list_tools()
            tool_list = result.tools

            update_cache([t.name for t in tool_list], [], [])

            if tool_name:
                match = next((t for t in tool_list if t.name == tool_name), None)
                if not match:
                    render_error(f"Tool '{tool_name}' not found. Run 'mcpbundles tools' to see available tools.")
                    raise SystemExit(USER_ERROR)
                if as_json:
                    print_json({"name": match.name, "description": match.description, "inputSchema": match.inputSchema})
                else:
                    render_tool_detail(match)
                return

            if filter_str:
                lower = filter_str.lower()
                tool_list = [t for t in tool_list if lower in t.name.lower() or (t.description and lower in t.description.lower())]

            if as_json:
                render_tools_json(tool_list)
            else:
                render_tools_table(tool_list, filter_str)
                if not bundle_slug:
                    render_warning(
                        "Showing hub tools only. Use --bundle <slug> to list tools in a specific bundle.\n"
                        "  Example: mcpbundles tools --bundle attio"
                    )

    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)
    except ConnectionError as exc:
        render_error(str(exc))
        raise SystemExit(CONNECTION_ERROR)


@click.command()
@click.argument("resource_uri", required=False)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option("--as", "connection", help="Use a named connection")
@click.option("--bundle", "bundle_slug", help="Connect directly to a bundle endpoint")
@click.pass_context
def resources(ctx: click.Context, resource_uri: str | None, as_json: bool, connection: str | None, bundle_slug: str | None) -> None:
    """List available MCP resources.

    By default, lists hub-level resources. Use --bundle to list
    resources for a specific bundle.

    Examples:
        mcpbundles resources
        mcpbundles resources --bundle attio
        mcpbundles resources --json
    """
    asyncio.run(_resources_impl(ctx, resource_uri, as_json, connection, bundle_slug))


async def _resources_impl(ctx: click.Context, resource_uri: str | None, as_json: bool, connection: str | None, bundle_slug: str | None) -> None:
    settings: CLISettings = ctx.obj["settings"]
    try:
        auth = resolve_auth(settings, connection)
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)

    endpoint = resolve_endpoint(bundle_slug)

    try:
        async with hub_session(auth.token, auth.url, endpoint) as session:
            result = await session.list_resources()
            resource_list = result.resources

            if as_json:
                render_resources_json(resource_list)
            else:
                render_resources_table(resource_list)

    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)
    except ConnectionError as exc:
        render_error(str(exc))
        raise SystemExit(CONNECTION_ERROR)


@click.command()
@click.argument("prompt_name", required=False)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option("--as", "connection", help="Use a named connection")
@click.option("--bundle", "bundle_slug", help="Connect directly to a bundle endpoint")
@click.pass_context
def prompts(ctx: click.Context, prompt_name: str | None, as_json: bool, connection: str | None, bundle_slug: str | None) -> None:
    """List available MCP prompts.

    By default, lists hub-level prompts. Use --bundle to list
    prompts for a specific bundle.

    Examples:
        mcpbundles prompts
        mcpbundles prompts --bundle attio
        mcpbundles prompts --json
    """
    asyncio.run(_prompts_impl(ctx, prompt_name, as_json, connection, bundle_slug))


async def _prompts_impl(ctx: click.Context, prompt_name: str | None, as_json: bool, connection: str | None, bundle_slug: str | None) -> None:
    settings: CLISettings = ctx.obj["settings"]
    try:
        auth = resolve_auth(settings, connection)
    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)

    endpoint = resolve_endpoint(bundle_slug)

    try:
        async with hub_session(auth.token, auth.url, endpoint) as session:
            result = await session.list_prompts()
            prompt_list = result.prompts

            if as_json:
                render_prompts_json(prompt_list)
            else:
                render_prompts_table(prompt_list)

    except AuthError as exc:
        render_error(str(exc))
        raise SystemExit(USER_ERROR)
    except ConnectionError as exc:
        render_error(str(exc))
        raise SystemExit(CONNECTION_ERROR)
