"""Spec-compliance tests for MCPSession handshake and cleanup.

Covers two recently-fixed regressions:

1. ``notifications/initialized`` MUST be awaited before ``_handshake``
   returns, so subsequent ``tools/list`` / ``tools/call`` requests cannot
   race ahead of the notification (MCP spec requires the server to receive
   it before any other client requests).

2. ``cleanup()`` MUST issue an HTTP ``DELETE`` with the ``Mcp-Session-Id``
   header so the server can release session resources eagerly.
"""

import json

import httpx
import pytest

from mcpbundles.mcp_client import MCPSession, _PROTOCOL_VERSION


class _RecordingTransport(httpx.AsyncBaseTransport):
    """Captures every request the session makes, in order."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, str, dict[str, str], dict | None]] = []

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        try:
            payload = json.loads(request.content) if request.content else None
        except (ValueError, json.JSONDecodeError):
            payload = None
        self.calls.append((request.method, str(request.url), dict(request.headers), payload))

        if request.method == "DELETE":
            return httpx.Response(204)

        if payload and payload.get("method") == "initialize":
            return httpx.Response(
                200,
                headers={
                    "content-type": "application/json",
                    "mcp-session-id": "session-abc-123",
                },
                json={
                    "jsonrpc": "2.0",
                    "id": payload["id"],
                    "result": {
                        "protocolVersion": _PROTOCOL_VERSION,
                        "capabilities": {},
                        "serverInfo": {"name": "test-server", "version": "0.1.0"},
                    },
                },
            )

        if payload and payload.get("method") == "notifications/initialized":
            return httpx.Response(202)

        return httpx.Response(404)


@pytest.mark.asyncio
async def test_handshake_sends_initialize_then_awaited_initialized_notification() -> None:
    transport = _RecordingTransport()
    async with httpx.AsyncClient(transport=transport) as client:
        session = MCPSession(client=client, url="https://test.example.com/hub/", session_id="", auth="bearer")

        sid = await session._handshake()

        assert sid == "session-abc-123"
        # Two synchronous requests must have happened by the time
        # _handshake returns: initialize, then notifications/initialized.
        methods = [(call[0], (call[3] or {}).get("method")) for call in transport.calls]
        assert methods == [
            ("POST", "initialize"),
            ("POST", "notifications/initialized"),
        ]
        # The notification carried the new session id.
        notif_headers = transport.calls[1][2]
        assert notif_headers.get("mcp-session-id") == "session-abc-123"


@pytest.mark.asyncio
async def test_cleanup_sends_delete_with_session_id() -> None:
    transport = _RecordingTransport()
    async with httpx.AsyncClient(transport=transport) as client:
        session = MCPSession(
            client=client,
            url="https://test.example.com/hub/",
            session_id="session-abc-123",
            auth="bearer",
        )

        await session.cleanup()

        assert len(transport.calls) == 1
        method, url, headers, _payload = transport.calls[0]
        assert method == "DELETE"
        assert url == "https://test.example.com/hub/"
        assert headers.get("mcp-session-id") == "session-abc-123"


@pytest.mark.asyncio
async def test_cleanup_with_no_session_id_is_noop() -> None:
    transport = _RecordingTransport()
    async with httpx.AsyncClient(transport=transport) as client:
        session = MCPSession(client=client, url="https://test.example.com/hub/", session_id="", auth="bearer")

        await session.cleanup()

        assert transport.calls == []


@pytest.mark.asyncio
async def test_cleanup_swallows_transport_errors() -> None:
    class _BoomTransport(httpx.AsyncBaseTransport):
        async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("network down")

    async with httpx.AsyncClient(transport=_BoomTransport()) as client:
        session = MCPSession(
            client=client,
            url="https://test.example.com/hub/",
            session_id="session-abc-123",
            auth="bearer",
        )
        # Must not propagate.
        await session.cleanup()
