import asyncio
import itertools
import logging
from collections import defaultdict
from collections.abc import AsyncIterator, Callable, Sequence
from contextlib import AbstractAsyncContextManager
from contextlib import asynccontextmanager as actxmgr
from dataclasses import dataclass, field
from typing import (
    Annotated,
    Any,
    Protocol,
    Self,
)
from uuid import UUID

import aiohttp_cors
import attrs
from pydantic import AliasChoices, BaseModel, Field, TypeAdapter

from ai.backend.appproxy.common.errors import ServerMisconfiguredError, ServiceUnavailable
from ai.backend.appproxy.common.etcd import TraefikEtcd, convert_to_etcd_dict
from ai.backend.appproxy.common.events import (
    AppProxyCircuitCreatedEvent,
    AppProxyCircuitRemovedEvent,
    AppProxyCircuitRouteUpdatedEvent,
    AppProxyWorkerCircuitAddedEvent,
)
from ai.backend.appproxy.common.types import ProxyProtocol, RouteInfo, SerializableCircuit
from ai.backend.appproxy.coordinator.health_checker import HealthCheckEngine
from ai.backend.common.clients.valkey_client.valkey_live.client import ValkeyLiveClient
from ai.backend.common.clients.valkey_client.valkey_schedule import ValkeyScheduleClient
from ai.backend.common.events.dispatcher import EventDispatcher, EventProducer
from ai.backend.common.health_checker.probe import HealthProbe
from ai.backend.common.leader import ValkeyLeaderElection
from ai.backend.common.lock import AbstractDistributedLock
from ai.backend.common.metrics.metric import (
    APIMetricObserver,
    EventMetricObserver,
    SystemMetricObserver,
)
from ai.backend.common.metrics.multiprocess import generate_latest_multiprocess
from ai.backend.common.types import AgentId, RedisConnectionInfo
from ai.backend.logging import BraceStyleAdapter

from .config import ServerConfig
from .defs import LockID
from .models import Circuit
from .models.utils import ExtendedAsyncSAEngine
from .models.worker import Worker

log = BraceStyleAdapter(logging.getLogger(__spec__.name))


class CoordinatorMetricRegistry:
    _instance: Self | None = None

    api: APIMetricObserver
    event: EventMetricObserver
    system: SystemMetricObserver

    def __init__(self) -> None:
        self.api = APIMetricObserver.instance()
        self.event = EventMetricObserver.instance()
        self.system = SystemMetricObserver.instance()

    @classmethod
    def instance(cls) -> Self:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def to_prometheus(self) -> str:
        self.system.observe()
        return generate_latest_multiprocess().decode("utf-8")


class DistributedLockFactory(Protocol):
    def __call__(self, lock_id: LockID, lifetime_hint: float) -> AbstractDistributedLock: ...


@dataclass
class CircuitManager:
    event_dispatcher: EventDispatcher
    event_producer: EventProducer
    traefik_etcd: TraefikEtcd | None
    local_config: ServerConfig
    _circuit_locks: dict[UUID, asyncio.Lock] = field(default_factory=dict)

    def _get_lock(self, circuit_id: UUID) -> asyncio.Lock:
        if circuit_id not in self._circuit_locks:
            self._circuit_locks[circuit_id] = asyncio.Lock()
        return self._circuit_locks[circuit_id]

    def _release_circuit_lock(self, circuit_id: UUID) -> None:
        self._circuit_locks.pop(circuit_id, None)

    @actxmgr
    async def circuit_lock(self, circuit_id: UUID) -> AsyncIterator[None]:
        async with self._get_lock(circuit_id):
            yield

    async def initialize_circuits(self, circuits: Sequence[Circuit]) -> None:
        if self.local_config.proxy_coordinator.enable_traefik:
            await self.initialize_traefik_circuits(circuits)
        else:
            for circuit in circuits:
                await self.initialize_legacy_circuit(circuit)

    async def initialize_traefik_circuits(self, circuits: Sequence[Circuit]) -> None:
        log.debug("initialize_traefik_circuits(): start")
        if not self.traefik_etcd:
            raise ServerMisconfiguredError("proxy-coordinator.traefik")

        for circuit_chunk in itertools.batched(circuits, 5):
            total_map: defaultdict[str, Any] = defaultdict(
                lambda: defaultdict(lambda: {"services": {}, "routers": {}, "middlewares": {}})
            )
            for circuit in circuit_chunk:
                worker_authority = circuit.worker_row.authority

                routers = circuit.traefik_routers
                middlewares = circuit.get_traefik_middlewares(self.local_config)
                services = circuit.traefik_services

                total_map[f"worker_{worker_authority}"][circuit.protocol.value.lower()][
                    "services"
                ].update(services)
                total_map[f"worker_{worker_authority}"][circuit.protocol.value.lower()][
                    "routers"
                ].update(routers)
                if middlewares:
                    total_map[f"worker_{worker_authority}"][circuit.protocol.value.lower()][
                        "middlewares"
                    ].update(middlewares)

            log.debug("traefik_etcd put_prefix {}", convert_to_etcd_dict(total_map))
            await self.traefik_etcd.put_prefix("", convert_to_etcd_dict(total_map))
            log.debug("initialize_traefik_circuits(): end")

    async def initialize_legacy_circuit(self, circuit: Circuit) -> None:
        worker_ready_evt = asyncio.Event()
        authority = circuit.worker_row.authority

        async def _event_handler(
            _context: CircuitManager,
            _agent_id: AgentId,
            event: AppProxyWorkerCircuitAddedEvent,
        ) -> None:
            if circuit.id in [c.id for c in event.circuits]:
                worker_ready_evt.set()

        worker_ready_event_handler = self.event_dispatcher.subscribe(
            AppProxyWorkerCircuitAddedEvent,
            self,
            _event_handler,
        )
        evt = AppProxyCircuitCreatedEvent(
            authority,
            [SerializableCircuit(**circuit.dump_model())],
        )
        await self.event_producer.broadcast_event(evt)
        try:
            async with asyncio.timeout(15.0):
                await worker_ready_evt.wait()
        except TimeoutError as e:
            raise ServiceUnavailable(
                "E10001: Proxy worker not responding", extra_data={"worker": authority}
            ) from e

        self.event_dispatcher.unsubscribe(worker_ready_event_handler)

    async def update_circuit_routes(self, circuit: Circuit, old_routes: list[RouteInfo]) -> None:
        async with self.circuit_lock(circuit.id):
            await self._update_circuit_routes_unlocked(circuit, old_routes)

    async def _update_circuit_routes_unlocked(
        self, circuit: Circuit, old_routes: list[RouteInfo]
    ) -> None:
        if self.local_config.proxy_coordinator.enable_traefik:
            await self.update_traefik_circuit_routes(circuit, old_routes)
        else:
            await self.update_legacy_circuit_routes(circuit, old_routes)

    async def update_traefik_circuit_routes(
        self, circuit: Circuit, old_routes: list[RouteInfo]
    ) -> None:
        log.debug("update_traefik_circuit_routes(): start")
        if not self.traefik_etcd:
            raise ServerMisconfiguredError("proxy-coordinator.traefik")

        worker_authority = circuit.worker_row.authority
        etcd_prefix = f"worker_{worker_authority}/{circuit.protocol.value.lower()}"

        # Circuit.traefik_services now emits a single bai_service_{circuit.id}
        # loadBalancer (see models/circuit.py) instead of one weighted entry
        # per session, so cleanup only needs to drop that single prefix before
        # re-publishing the new config. The old_routes argument is kept for
        # signature compatibility but is no longer consulted.
        del old_routes  # legacy signature; no per-session cleanup needed
        new_services = circuit.traefik_services

        log.debug(
            "traefik_etcd.delete_prefix {}", f"{etcd_prefix}/services/bai_service_{circuit.id}"
        )
        await self.traefik_etcd.delete_prefix(f"{etcd_prefix}/services/bai_service_{circuit.id}")

        log.debug(
            "traefik_etcd.put_prefix {} {}",
            f"{etcd_prefix}/services",
            convert_to_etcd_dict(new_services),
        )
        await self.traefik_etcd.put_prefix(
            f"{etcd_prefix}/services",
            convert_to_etcd_dict(new_services),
        )
        log.debug("update_traefik_circuit_routes(): end")

    async def update_legacy_circuit_routes(
        self, circuit: Circuit, old_routes: list[RouteInfo]
    ) -> None:
        # Get healthy routes for the circuit
        healthy_routes = circuit.healthy_routes

        event = AppProxyCircuitRouteUpdatedEvent(
            target_worker_authority=circuit.worker_row.authority,
            circuit=SerializableCircuit(**circuit.dump_model()),
            routes=healthy_routes,
        )
        await self.event_producer.broadcast_event(event)

    async def unload_circuits(self, circuits: Sequence[Circuit]) -> None:
        for circuit in circuits:
            try:
                async with self.circuit_lock(circuit.id):
                    if self.local_config.proxy_coordinator.enable_traefik:
                        await self.unload_traefik_circuit(circuit)
                    else:
                        await self.unload_legacy_circuit(circuit)
            except Exception:
                log.exception("Failed to unload circuit {}", circuit.id)
            finally:
                self._release_circuit_lock(circuit.id)

    async def unload_traefik_circuit(self, circuit: Circuit) -> None:
        log.debug("unload_traefik_circuit(): start")
        if not self.traefik_etcd:
            raise ServerMisconfiguredError("proxy-coordinator.traefik")

        worker_authority = circuit.worker_row.authority
        etcd_prefix = f"worker_{worker_authority}/{circuit.protocol.value.lower()}"

        # Circuit.traefik_services now emits a single bai_service_{circuit.id}
        # prefix per circuit (no per-session sub-keys), so cleanup only needs
        # to drop router / service / middleware prefixes scoped to the circuit id.
        prefixes_to_remove = [
            f"{etcd_prefix}/routers/bai_router_{circuit.id}",
            f"{etcd_prefix}/services/bai_service_{circuit.id}",
        ]
        if circuit.protocol == ProxyProtocol.HTTP:
            prefixes_to_remove.append(
                f"{etcd_prefix}/middlewares/bai_appproxy_plugin_{circuit.id}",
            )
            prefixes_to_remove.append(
                f"{etcd_prefix}/middlewares/appproxy/plugin/bai_appproxy_plugin_{circuit.id}",
            )

        for prefix in prefixes_to_remove:
            log.debug("traefik_etcd.delete_prefix {}", prefix)
            await self.traefik_etcd.delete_prefix(prefix)
        log.debug("unload_traefik_circuit(): end")

    async def reconcile_traefik_etcd_state(
        self,
        live_circuits: Sequence[Circuit],
        workers: Sequence[Worker],
    ) -> None:
        """Drop stale circuit keys left behind in etcd by missed unloads.

        For each (worker, protocol) scope, compare the set of circuit ids
        currently in the coordinator DB against the set of ``bai_service_{id}``
        keys present under ``worker_{authority}/{protocol}/services``. Any
        circuit id present in etcd but missing from the DB is an orphan
        (lost unload event, coordinator crash between DB delete and etcd
        cleanup, etc.) and gets the same prefix set removed as
        ``unload_traefik_circuit`` would have.

        The per-circuit put reconcile still runs before this helper, so this
        method is a pure cleanup pass — it never adds keys, only removes them.
        """
        if not self.traefik_etcd:
            raise ServerMisconfiguredError("proxy-coordinator.traefik")

        live_by_scope: dict[tuple[str, str], set[UUID]] = defaultdict(set)
        for circuit in live_circuits:
            scope = (circuit.worker_row.authority, circuit.protocol.value.lower())
            live_by_scope[scope].add(circuit.id)

        dropped = 0
        for worker in workers:
            for protocol in ("http", "tcp"):
                etcd_prefix = f"worker_{worker.authority}/{protocol}"
                services_prefix = f"{etcd_prefix}/services"
                try:
                    existing = await self.traefik_etcd.get_prefix(services_prefix)
                except Exception:
                    log.exception(
                        "reconcile_traefik_etcd_state: failed to list etcd services at {}",
                        services_prefix,
                    )
                    continue

                existing_ids: set[UUID] = set()
                for top_key in existing.keys():
                    if not top_key.startswith("bai_service_"):
                        continue
                    try:
                        existing_ids.add(UUID(top_key.removeprefix("bai_service_")))
                    except ValueError:
                        continue

                live_ids = live_by_scope.get((worker.authority, protocol), set())
                stale_ids = existing_ids - live_ids

                for stale_id in stale_ids:
                    prefixes_to_remove = [
                        f"{etcd_prefix}/routers/bai_router_{stale_id}",
                        f"{etcd_prefix}/services/bai_service_{stale_id}",
                    ]
                    if protocol == "http":
                        prefixes_to_remove.append(
                            f"{etcd_prefix}/middlewares/bai_appproxy_plugin_{stale_id}"
                        )
                        prefixes_to_remove.append(
                            f"{etcd_prefix}/middlewares/appproxy/plugin/bai_appproxy_plugin_{stale_id}"
                        )
                    for prefix in prefixes_to_remove:
                        try:
                            await self.traefik_etcd.delete_prefix(prefix)
                        except Exception:
                            log.exception(
                                "reconcile_traefik_etcd_state: delete_prefix {} failed",
                                prefix,
                            )
                    log.info(
                        "reconcile_traefik_etcd_state: dropped stale circuit {} from worker={} protocol={}",
                        stale_id,
                        worker.authority,
                        protocol,
                    )
                    dropped += 1

        if dropped:
            log.info("reconcile_traefik_etcd_state: dropped {} stale circuit(s)", dropped)

    async def unload_legacy_circuit(self, circuit: Circuit) -> None:
        event = AppProxyCircuitRemovedEvent(
            target_worker_authority=circuit.worker_row.authority,
            circuits=[SerializableCircuit(**circuit.dump_model())],
        )
        await self.event_producer.broadcast_event(event)


@attrs.define(slots=True, auto_attribs=True, init=False)
class RootContext:
    pidx: int
    db: ExtendedAsyncSAEngine
    distributed_lock_factory: DistributedLockFactory
    event_dispatcher: EventDispatcher
    event_producer: EventProducer
    core_event_dispatcher: EventDispatcher
    core_event_producer: EventProducer

    valkey_live: ValkeyLiveClient
    redis_lock: RedisConnectionInfo
    core_valkey_live: ValkeyLiveClient
    valkey_schedule: ValkeyScheduleClient
    local_config: ServerConfig
    cors_options: dict[str, aiohttp_cors.ResourceOptions]
    traefik_etcd: TraefikEtcd | None

    circuit_manager: CircuitManager
    health_engine: HealthCheckEngine

    metrics: CoordinatorMetricRegistry
    health_probe: HealthProbe
    leader_election: ValkeyLeaderElection


type CleanupContext = Callable[["RootContext"], AbstractAsyncContextManager[None]]


class InferenceAppConfig(BaseModel):
    session_id: Annotated[
        UUID,
        Field(
            ...,
            description="ID of the session associated with the inference app.",
            validation_alias=AliasChoices("session-id", "session_id"),
            serialization_alias="session-id",
        ),
    ]
    route_id: Annotated[
        UUID | None,
        Field(
            default=None,
            description="ID of the route. This is optional and may not be present for older routes.",
            validation_alias=AliasChoices("route-id", "route_id"),
            serialization_alias="route-id",
        ),
    ]
    kernel_host: Annotated[
        str | None,
        Field(
            ...,
            description="Host/IP address of the kernel. This is the address that the proxy will use to connect to the kernel.",
            validation_alias=AliasChoices("kernel-host", "kernel_host"),
            serialization_alias="kernel-host",
        ),
    ]
    kernel_port: Annotated[
        int,
        Field(
            ...,
            ge=1,
            le=65535,
            description="Port number of the kernel. This is the port that the proxy will use to connect to the kernel.",
            validation_alias=AliasChoices("kernel-port", "kernel_port"),
            serialization_alias="kernel-port",
        ),
    ]
    protocol: Annotated[
        ProxyProtocol,
        Field(
            default=ProxyProtocol.HTTP,
            description="Protocol used to connect to the kernel. Supported protocols are HTTP and WebSocket.",
            validation_alias=AliasChoices("protocol"),
            serialization_alias="protocol",
        ),
    ]
    traffic_ratio: Annotated[
        float,
        Field(
            ge=0.0,
            le=1.0,
            default=1.0,
            description="Traffic ratio for the inference app. This is used for load balancing between multiple apps.",
            validation_alias=AliasChoices("traffic-ratio", "traffic_ratio"),
            serialization_alias="traffic-ratio",
        ),
    ]


InferenceAppConfigDict = TypeAdapter(dict[str, list[InferenceAppConfig]])
