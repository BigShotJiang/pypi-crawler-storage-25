from __future__ import annotations

import asyncio
import functools
import grp
import importlib
import importlib.resources
import ipaddress
import logging
import os
import pwd
import signal
import socket
import ssl
import sys
import time
import traceback
import uuid
from collections.abc import AsyncGenerator, AsyncIterator, Callable, Iterable, Mapping, Sequence
from contextlib import AsyncExitStack, asynccontextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Final, cast
from uuid import UUID

import aiohttp_cors
import aiohttp_jinja2
import aiomonitor
import aiotools
import click
import jinja2
import memray
import pyroscope
import uvloop
from aiohttp import web
from pydantic import ValidationError
from setproctitle import setproctitle

from ai.backend.appproxy.common.config import RedisConfig
from ai.backend.appproxy.common.defs import (
    AGENTID_COORDINATOR,
    APPPROXY_ANYCAST_STREAM_KEY,
    APPPROXY_BROADCAST_CHANNEL,
)
from ai.backend.appproxy.common.errors import (
    GenericBadRequest,
    GenericForbidden,
    InternalServerError,
    MethodNotAllowed,
    ObjectNotFound,
    URLNotFound,
)
from ai.backend.appproxy.common.etcd import TraefikEtcd
from ai.backend.appproxy.common.events import (
    DoCheckUnusedPortEvent,
    DoCheckWorkerLostEvent,
    DoHealthCheckEvent,
    DoReconcileTraefikRoutesEvent,
    WorkerLostEvent,
)
from ai.backend.appproxy.common.types import (
    AppCreator,
    AppMode,
    EventLoopType,
    ProxyProtocol,
    RouteInfo,
    WebMiddleware,
    WebRequestHandler,
)
from ai.backend.appproxy.common.utils import (
    BackendAIAccessLogger,
    ensure_json_serializable,
    mime_match,
    ping_redis_connection,
)
from ai.backend.appproxy.coordinator.api.types import AppProxyStatusResponse
from ai.backend.appproxy.coordinator.models.worker import WorkerStatus
from ai.backend.common import redis_helper
from ai.backend.common.clients.valkey_client.valkey_leader.client import ValkeyLeaderClient
from ai.backend.common.clients.valkey_client.valkey_live.client import ValkeyLiveClient
from ai.backend.common.clients.valkey_client.valkey_schedule import ValkeyScheduleClient
from ai.backend.common.config import ModelHealthCheck
from ai.backend.common.defs import REDIS_LIVE_DB, REDIS_STREAM_DB, REDIS_STREAM_LOCK, RedisRole
from ai.backend.common.etcd import ConfigScopes
from ai.backend.common.events.dispatcher import EventDispatcher, EventProducer
from ai.backend.common.events.event_types.model_serving.anycast import (
    EndpointRouteListUpdatedEvent,
)
from ai.backend.common.exception import BackendAIError
from ai.backend.common.health_checker.checkers.valkey import ValkeyHealthChecker
from ai.backend.common.health_checker.probe import HealthProbe, HealthProbeOptions
from ai.backend.common.health_checker.types import ComponentId
from ai.backend.common.leader import ValkeyLeaderElection, ValkeyLeaderElectionConfig
from ai.backend.common.leader.tasks import (
    EventProducerTask,
    EventTaskSpec,
    LeaderCron,
    PeriodicTask,
)
from ai.backend.common.lock import FileLock, RedisLock
from ai.backend.common.message_queue.hiredis_queue import HiRedisQueue
from ai.backend.common.message_queue.queue import AbstractMessageQueue
from ai.backend.common.message_queue.redis_queue import RedisMQArgs, RedisQueue
from ai.backend.common.metrics.http import build_api_metric_middleware
from ai.backend.common.metrics.multiprocess_setup import cleanup_prometheus_multiprocess_dir
from ai.backend.common.msgpack import DEFAULT_PACK_OPTS, DEFAULT_UNPACK_OPTS
from ai.backend.common.service_discovery.event_publisher import ServiceDiscoveryEventPublisher
from ai.backend.common.service_discovery.redis_discovery.service_discovery import (
    RedisServiceDiscovery,
    RedisServiceDiscoveryArgs,
)
from ai.backend.common.service_discovery.service_discovery import (
    ServiceDiscovery,
    ServiceDiscoveryLoop,
    ServiceEndpoint,
    ServiceMetadata,
)
from ai.backend.common.types import (
    AgentId,
    HostPortPair,
    ModelServiceStatus,
    RedisProfileTarget,
    ServiceDiscoveryType,
)
from ai.backend.common.utils import env_info
from ai.backend.logging import BraceStyleAdapter, Logger, LogLevel
from ai.backend.logging.otel import OpenTelemetrySpec

from . import __version__
from .config import ServerConfig
from .config import load as load_config
from .defs import EVENT_DISPATCHER_CONSUMER_GROUP
from .errors import (
    CleanupContextNotInitializedError,
    MissingHealthCheckInfoError,
    MissingProfilingConfigError,
    MissingRouteInfoError,
    MissingTraefikConfigError,
)
from .health.database import DatabaseHealthChecker
from .health_checker import HealthCheckEngine
from .models import Circuit, Endpoint, Worker
from .models.utils import connect_database, execute_with_txn_retry
from .pglock import PgAdvisoryLock
from .types import (
    CircuitManager,
    CleanupContext,
    CoordinatorMetricRegistry,
    DistributedLockFactory,
    InferenceAppConfigDict,
    RootContext,
)

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession as SASession

log = BraceStyleAdapter(logging.getLogger(__spec__.name))

global_subapp_pkgs: Final[list[str]] = [
    ".circuit_v1",
    ".circuit_v2",
    ".conf",
    ".endpoint",
    ".health",
    ".proxy",
    ".slot_v1",
    ".slot_v2",
    ".worker_v1",
    ".worker_v2",
]


@web.middleware
async def request_context_aware_middleware(
    request: web.Request, handler: WebRequestHandler
) -> web.StreamResponse:
    request_id = request.headers.get("X-BackendAI-RequestID", str(uuid.uuid4()))
    request["request_id"] = request_id
    if _current_task := asyncio.current_task():
        setattr(_current_task, "request_id", request_id)
    return await handler(request)


@web.middleware
async def api_middleware(request: web.Request, handler: WebRequestHandler) -> web.StreamResponse:
    _handler = handler
    method_override = request.headers.get("X-Method-Override", None)
    if method_override:
        request = request.clone(method=method_override)
        new_match_info = await request.app.router.resolve(request)
        if new_match_info is None:
            raise InternalServerError("No matching method handler found")
        _handler = new_match_info.handler
        request._match_info = new_match_info
    ex = request.match_info.http_exception
    if ex is not None:
        # handled by exception_middleware
        raise ex
    return await _handler(request)


@web.middleware
async def exception_middleware(
    request: web.Request, handler: WebRequestHandler
) -> web.StreamResponse:
    root_ctx: RootContext = request.app["_root.context"]
    try:
        resp = await handler(request)
    except ValidationError as ex:
        log.exception("Failed to create response model: {}", ex.json(indent=2))
        raise InternalServerError() from ex
    except BackendAIError as ex:
        if ex.status_code == 500:
            log.warning("Internal server error raised inside handlers")
        log.exception("")
        if mime_match(request.headers.get("accept", "text/html"), "application/json"):
            return web.json_response(
                ensure_json_serializable(ex.body_dict),
                status=ex.status_code,
                headers={"Access-Control-Allow-Origin": "*"},
            )
        return aiohttp_jinja2.render_template(
            "error",
            request,
            ex.body_dict,
            status=ex.status_code,
        )
    except web.HTTPException as ex:
        if ex.status_code == 404:
            raise URLNotFound(extra_data=request.path) from ex
        if ex.status_code == 405:
            concrete_ex = cast(web.HTTPMethodNotAllowed, ex)
            raise MethodNotAllowed(
                extra_msg=f"Method {concrete_ex.method} not allowed",
                extra_data={"allowed_methods": list(concrete_ex.allowed_methods)},
            ) from ex
        log.warning("Bad request: {0!r}", ex)
        raise GenericBadRequest from ex
    except asyncio.CancelledError as e:
        # The server is closing or the client has disconnected in the middle of
        # request.  Atomic requests are still executed to their ends.
        log.debug("Request cancelled ({0} {1})", request.method, request.rel_url)
        raise e
    except Exception as e:
        log.exception("Uncaught exception in HTTP request handlers {0!r}", e)
        if root_ctx.local_config.debug.enabled:
            raise InternalServerError(traceback.format_exc()) from e
        raise InternalServerError() from e
    else:
        return resp


@asynccontextmanager
async def redis_ctx(root_ctx: RootContext) -> AsyncIterator[None]:
    redis_profile_target = RedisProfileTarget.from_dict(root_ctx.local_config.redis.to_dict())
    core_redis_profile_target = RedisProfileTarget.from_dict(
        (root_ctx.local_config.core_redis or root_ctx.local_config.redis).to_dict()
    )

    # Create valkey clients for live data access
    root_ctx.valkey_live = await ValkeyLiveClient.create(
        valkey_target=redis_profile_target.profile_target(RedisRole.LIVE).to_valkey_target(),
        db_id=REDIS_LIVE_DB,
        human_readable_name="appproxy-coordinator-live",
    )
    root_ctx.core_valkey_live = await ValkeyLiveClient.create(
        valkey_target=core_redis_profile_target.profile_target(RedisRole.LIVE).to_valkey_target(),
        db_id=REDIS_LIVE_DB,
        human_readable_name="appproxy-coordinator-core-live",
    )

    # Keep redis_lock for distributed locking (not yet migrated)
    root_ctx.redis_lock = redis_helper.get_redis_object_for_lock(
        redis_profile_target.profile_target(RedisRole.STREAM),
        name="lock",  # distributed locks
        db=REDIS_STREAM_LOCK,
    )
    await ping_redis_connection(root_ctx.redis_lock)

    # Initialize ValkeyScheduleClient for health status updates
    root_ctx.valkey_schedule = await ValkeyScheduleClient.create(
        valkey_target=core_redis_profile_target.profile_target(RedisRole.STREAM).to_valkey_target(),
        db_id=REDIS_LIVE_DB,
        human_readable_name="appproxy-schedule",
    )
    log.info("ValkeyScheduleClient initialized for health status updates")
    try:
        yield
    finally:
        await root_ctx.valkey_live.close()
        await root_ctx.core_valkey_live.close()
        await root_ctx.valkey_schedule.close()
        await root_ctx.redis_lock.close()


async def _make_message_queue(
    node_id: str,
    redis_config: RedisConfig,
    *,
    anycast_stream_key: str = APPPROXY_ANYCAST_STREAM_KEY,
    broadcast_channel: str = APPPROXY_BROADCAST_CHANNEL,
    use_experimental_redis_event_dispatcher: bool = False,
) -> AbstractMessageQueue:
    redis_profile_target: RedisProfileTarget = RedisProfileTarget.from_dict(redis_config.to_dict())
    stream_redis_target = redis_profile_target.profile_target(RedisRole.STREAM)

    args = RedisMQArgs(
        anycast_stream_key=anycast_stream_key,
        broadcast_channel=broadcast_channel,
        consume_stream_keys={
            anycast_stream_key,
        },
        subscribe_channels={
            broadcast_channel,
        },
        group_name=EVENT_DISPATCHER_CONSUMER_GROUP,
        node_id=node_id,
        db=REDIS_STREAM_DB,
    )

    if use_experimental_redis_event_dispatcher:
        return HiRedisQueue(
            stream_redis_target,
            args,
        )
    return await RedisQueue.create(
        stream_redis_target,
        args,
    )


@asynccontextmanager
async def event_dispatcher_ctx(root_ctx: RootContext) -> AsyncIterator[None]:
    mq = await _make_message_queue(
        root_ctx.local_config.proxy_coordinator.id,
        root_ctx.local_config.redis,
        use_experimental_redis_event_dispatcher=root_ctx.local_config.proxy_coordinator.use_experimental_redis_event_dispatcher,
    )
    root_ctx.event_producer = EventProducer(
        mq,
        source=AGENTID_COORDINATOR,
        log_events=root_ctx.local_config.debug.log_events,
    )
    root_ctx.event_dispatcher = EventDispatcher(
        mq,
        log_events=root_ctx.local_config.debug.log_events,
        event_observer=root_ctx.metrics.event,
    )
    core_mq = await _make_message_queue(
        root_ctx.local_config.proxy_coordinator.id,
        root_ctx.local_config.core_redis or root_ctx.local_config.redis,
        anycast_stream_key="events",
        broadcast_channel="events_all",
        use_experimental_redis_event_dispatcher=root_ctx.local_config.proxy_coordinator.use_experimental_redis_event_dispatcher,
    )
    root_ctx.core_event_producer = EventProducer(
        core_mq,
        source=AGENTID_COORDINATOR,
        log_events=root_ctx.local_config.debug.log_events,
    )
    root_ctx.core_event_dispatcher = EventDispatcher(
        core_mq,
        log_events=root_ctx.local_config.debug.log_events,
        event_observer=root_ctx.metrics.event,
    )
    await root_ctx.event_dispatcher.start()
    await root_ctx.core_event_dispatcher.start()
    try:
        yield
    finally:
        await root_ctx.event_producer.close()
        await root_ctx.core_event_producer.close()
        await asyncio.sleep(0.2)


@asynccontextmanager
async def leader_election_ctx(root_ctx: RootContext) -> AsyncIterator[None]:
    """
    Initialize leader election for distributed periodic task coordination.

    This replaces the GlobalTimer-based approach with a leader-based approach
    where only the elected leader coordinator instance runs periodic tasks.
    """

    # Create ValkeyLeaderClient for leader election
    redis_profile_target = RedisProfileTarget.from_dict(root_ctx.local_config.redis.to_dict())
    valkey_leader_client = await ValkeyLeaderClient.create(
        valkey_target=redis_profile_target.profile_target(RedisRole.STREAM).to_valkey_target(),
        db_id=REDIS_STREAM_LOCK,
        human_readable_name="appproxy-leader",
    )

    # Create leader election configuration
    server_id = f"appproxy-coordinator-{socket.gethostname()}-{root_ctx.pidx}"
    leader_config = ValkeyLeaderElectionConfig(
        server_id=server_id,
        leader_key="leader:appproxy:coordinator",
        lease_duration=30,
        renewal_interval=10.0,
        failure_threshold=3,
    )

    # Create leader election instance
    root_ctx.leader_election = ValkeyLeaderElection(
        leader_client=valkey_leader_client,
        config=leader_config,
    )

    # Create task specs for all periodic tasks.
    #
    # When Traefik is enabled, the coordinator no longer polls kernels itself
    # for health status — instead Traefik probes kernels directly via the
    # loadBalancer.healthCheck directive baked into the etcd config. We therefore
    # skip the ``health_check`` task and add a ``reconcile_traefik_routes`` task
    # that periodically re-publishes every inference circuit's etcd config as a
    # safety net against missed propagation events (e.g. on coordinator restart
    # or transient Redis issues).
    task_specs: list[EventTaskSpec] = [
        EventTaskSpec(
            name="unused_port_collection",
            event_factory=lambda: DoCheckUnusedPortEvent(),
            interval=10.0,
            initial_delay=5.0,
        ),
        EventTaskSpec(
            name="worker_lost_check",
            event_factory=lambda: DoCheckWorkerLostEvent(),
            interval=15.0,
            initial_delay=10.0,
        ),
    ]
    if root_ctx.local_config.proxy_coordinator.enable_traefik:
        task_specs.append(
            EventTaskSpec(
                name="reconcile_traefik_routes",
                event_factory=lambda: DoReconcileTraefikRoutesEvent(),
                interval=30.0,
                initial_delay=15.0,
            )
        )
    else:
        task_specs.insert(
            0,
            EventTaskSpec(
                name="health_check",
                event_factory=lambda: DoHealthCheckEvent(),
                interval=root_ctx.local_config.proxy_coordinator.health_check_timer_interval,
                initial_delay=5.0,
            ),
        )

    # Create and register LeaderCron
    leader_tasks: list[PeriodicTask] = [
        EventProducerTask(spec, root_ctx.event_producer) for spec in task_specs
    ]
    leader_cron = LeaderCron(tasks=leader_tasks)
    root_ctx.leader_election.register_task(leader_cron)

    await root_ctx.leader_election.start()
    try:
        yield
    finally:
        await root_ctx.leader_election.stop()


@asynccontextmanager
async def etcd_ctx(root_ctx: RootContext) -> AsyncIterator[None]:
    if root_ctx.local_config.proxy_coordinator.enable_traefik:
        traefik_config = root_ctx.local_config.proxy_coordinator.traefik
        if not traefik_config:
            raise MissingTraefikConfigError(
                "Traefik configuration is required when enable_traefik is True"
            )

        creds: dict[str, str] | None = None
        if traefik_config.etcd.password:
            creds = {"password": traefik_config.etcd.password}

        # Handle addr as either single HostPortPair or list
        addr = traefik_config.etcd.addr
        if isinstance(addr, list):
            # Use first address from the list
            host_port = addr[0]
        else:
            host_port = addr

        root_ctx.traefik_etcd = TraefikEtcd(
            HostPortPair(host_port.host, host_port.port),
            traefik_config.etcd.namespace,
            {ConfigScopes.GLOBAL: ""},
            credentials=creds,
        )
    else:
        root_ctx.traefik_etcd = None
    yield


async def on_worker_lost_event(
    context: RootContext,
    _worker_id: AgentId,
    event: WorkerLostEvent,
) -> None:
    log.warning("detected termination of proxy worker {}", event.worker_id)

    async def _update(sess: SASession) -> None:
        try:
            worker = await Worker.find_by_authority(sess, event.worker_id)
            worker.status = WorkerStatus.LOST
            await sess.flush()
        except ObjectNotFound:
            log.warning("worker {} not found in database", event.worker_id)

    async with context.db.connect() as db_conn:
        await execute_with_txn_retry(_update, context.db.begin_session, db_conn)


async def on_route_update_event(
    context: RootContext,
    _worker_id: AgentId,
    event: EndpointRouteListUpdatedEvent,
) -> None:
    (
        route_connection_info_json,
        health_check_enabled_str,
        health_check_config_json,
    ) = await context.core_valkey_live.get_multiple_live_data([
        f"endpoint.{event.endpoint_id}.route_connection_info",
        f"endpoint.{event.endpoint_id}.health_check_enabled",
        f"endpoint.{event.endpoint_id}.health_check_config",
    ])
    if not route_connection_info_json:
        raise MissingRouteInfoError(
            f"EndpointRouteListUpdatedEvent fired but no route info present on redis - "
            f"expected 'endpoint.{event.endpoint_id}.route_connection_info' key to be present on redis_live"
        )
    if not health_check_enabled_str:
        raise MissingHealthCheckInfoError(
            f"EndpointRouteListUpdatedEvent fired but no health check info present on redis - "
            f"expected 'endpoint.{event.endpoint_id}.health_check_enabled' key to be present on redis_live"
        )
    route_connection_info = InferenceAppConfigDict.validate_json(route_connection_info_json)

    health_check_enabled = health_check_enabled_str.decode("utf-8") == "true"
    health_check_config: ModelHealthCheck | None
    if health_check_enabled:
        if not health_check_config_json:
            raise MissingHealthCheckInfoError(
                f"EndpointRouteListUpdatedEvent fired but invalid health check configuration provided - "
                f"expected 'endpoint.{event.endpoint_id}.health_check_config' key to be present on redis_live"
            )
        health_check_config = ModelHealthCheck.model_validate_json(
            health_check_config_json.decode("utf-8")
        )
    else:
        health_check_config = None

    app_names = list(route_connection_info.keys())
    if len(app_names) > 0:
        app = app_names[0]
        new_routes = {r.session_id: RouteInfo(**r.model_dump()) for r in route_connection_info[app]}
    else:
        app = ""
        new_routes = {}

    async def _update(db_sess: SASession) -> None:
        # The manager's periodic sync loop fires EndpointRouteListUpdatedEvent
        # for every active endpoint in its DB — some of those may not yet be
        # registered with the coordinator (still PENDING, or proxy register
        # never happened). Swallow those quietly so they do not spam logs.
        try:
            endpoint = await Endpoint.get(db_sess, event.endpoint_id)
        except ObjectNotFound:
            log.debug(
                "on_route_update_event: endpoint {} not registered in coordinator DB, skipping",
                event.endpoint_id,
            )
            return
        try:
            circuit = await Circuit.get_by_endpoint(db_sess, endpoint.id)
        except ObjectNotFound:
            log.debug(
                "on_route_update_event: no circuit for endpoint {}, skipping",
                event.endpoint_id,
            )
            return
        old_routes = circuit.route_info or []
        if new_routes:
            traffic_ratios = await context.core_valkey_live.get_multiple_live_data([
                f"endpoint.{event.endpoint_id}.session.{route.session_id}.traffic_ratio"
                for route in new_routes.values()
            ])
            for idx, route in enumerate(new_routes.values()):
                ratio_bytes = traffic_ratios[idx]
                route.traffic_ratio = float(ratio_bytes.decode("utf-8")) if ratio_bytes else 1.0
            for route in old_routes:
                if _duplicate_route := new_routes.get(route.session_id):
                    _duplicate_route.health_status = route.health_status
                    _duplicate_route.last_health_check = route.last_health_check
                    _duplicate_route.consecutive_failures = route.consecutive_failures
        circuit.route_info = list(new_routes.values())

        endpoint.health_check_enabled = health_check_enabled
        endpoint.health_check_config = health_check_config

        await db_sess.commit()

        if not endpoint.health_check_enabled:
            # mark all routes as healthy
            # Publish health status transition events
            await context.health_engine.publish_health_transition_events([
                (r.session_id, None, ModelServiceStatus.HEALTHY) for r in circuit.route_info
            ])

        # Propagate updated route information to AppProxy workers
        await context.health_engine.propagate_route_updates_to_workers(circuit, old_routes)

    async with context.db.connect() as db_conn:
        await execute_with_txn_retry(_update, context.db.begin_session, db_conn)


async def _reconcile_worker_occupied_slots(
    context: RootContext,
    circuits: Sequence[Circuit],
    workers: Sequence[Worker],
) -> None:
    """Recompute Worker.occupied_slots from the live circuit set and write back
    any drifts.

    ``Worker.occupied_slots`` is currently maintained as an incremental counter
    (``+= 1`` on add_circuit, ``-= 1`` on unload), which can drift out of sync
    with the actual ``circuits`` table whenever an unload event is missed, a
    transaction rolls back partially, or external schema manipulation removes
    rows. Once drifted, ``pick_worker`` filters every worker out and the
    coordinator returns ``WorkerNotAvailable`` even though there are free
    slots. This helper rebuilds the counter from the rows actually present in
    the DB and writes back any worker whose stored value disagrees.
    """
    actual_counts: dict[UUID, int] = {}
    for circuit in circuits:
        actual_counts[circuit.worker] = actual_counts.get(circuit.worker, 0) + 1

    drifted: list[tuple[Worker, int]] = []
    for worker in workers:
        expected = actual_counts.get(worker.id, 0)
        if worker.occupied_slots != expected:
            drifted.append((worker, expected))
    if not drifted:
        return

    async def _fix(sess: SASession) -> None:
        for worker, expected in drifted:
            fresh = await Worker.get(sess, worker.id)
            log.info(
                "occupied_slots reconcile: worker={} {} -> {}",
                fresh.authority,
                fresh.occupied_slots,
                expected,
            )
            fresh.occupied_slots = expected

    try:
        async with context.db.connect() as db_conn:
            await execute_with_txn_retry(_fix, context.db.begin_session, db_conn)
    except Exception:
        log.exception("Failed to reconcile worker occupied_slots")


async def on_reconcile_traefik_routes(
    context: RootContext,
    _source: AgentId,
    _event: DoReconcileTraefikRoutesEvent,
) -> None:
    """Periodic reconcile handler that re-publishes every active circuit's
    etcd routing config from the PG source of truth, then drops any stale
    circuit keys that were left behind in etcd by missed unloads.

    Three phases:

    1. **Put reconcile** — iterate every circuit in the coordinator DB
       (both inference and interactive) and re-invoke ``update_circuit_routes``.
       Acts as a safety net for missed propagation events on the happy path.
    2. **Stale cleanup** — compare the DB circuit set against etcd via
       ``reconcile_traefik_etcd_state`` and remove any orphan
       ``bai_service_*`` / ``bai_router_*`` / ``bai_appproxy_plugin_*``
       prefixes so etcd cannot accumulate dead entries across crashes.
    3. **Worker counter reconcile** — recompute ``Worker.occupied_slots``
       from the actual circuit count and fix drifts. Without this the
       counter can wedge a worker permanently after a missed unload.

    Each phase swallows its own errors so a single bad circuit or worker
    cannot short-circuit the entire reconcile cycle.
    """
    if not context.local_config.proxy_coordinator.enable_traefik:
        return
    async with context.db.begin_readonly_session() as db_sess:
        circuits = await Circuit.list_circuits(db_sess, load_worker=True, load_endpoint=True)
        workers = await Worker.list_workers(db_sess)
    reconciled = 0
    for circuit in circuits:
        try:
            await context.circuit_manager.update_circuit_routes(
                circuit, list(circuit.route_info or [])
            )
            reconciled += 1
        except Exception:
            log.exception("Failed to reconcile traefik routes for circuit {}", circuit.id)
    try:
        await context.circuit_manager.reconcile_traefik_etcd_state(circuits, workers)
    except Exception:
        log.exception("Failed to reconcile stale traefik etcd state")
    await _reconcile_worker_occupied_slots(context, circuits, workers)
    log.debug("reconcile_traefik_routes cycle completed: {} circuits reconciled", reconciled)


@asynccontextmanager
async def event_handler_ctx(root_ctx: RootContext) -> AsyncIterator[None]:
    worker_lost_handler = root_ctx.event_dispatcher.consume(
        WorkerLostEvent, root_ctx, on_worker_lost_event, name="proxy-coordinator"
    )
    endpoint_route_update_handler = root_ctx.core_event_dispatcher.consume(
        EndpointRouteListUpdatedEvent,
        root_ctx,
        on_route_update_event,
        name="proxy-coordinator",
    )
    reconcile_traefik_routes_handler = root_ctx.event_dispatcher.consume(
        DoReconcileTraefikRoutesEvent,
        root_ctx,
        on_reconcile_traefik_routes,
        name="proxy-coordinator",
    )
    try:
        yield
    finally:
        root_ctx.event_dispatcher.unconsume(worker_lost_handler)
        root_ctx.core_event_dispatcher.unconsume(endpoint_route_update_handler)
        root_ctx.event_dispatcher.unconsume(reconcile_traefik_routes_handler)


@asynccontextmanager
async def database_ctx(root_ctx: RootContext) -> AsyncIterator[None]:
    async with connect_database(root_ctx.local_config.db) as db:
        root_ctx.db = db
        yield


@asynccontextmanager
async def distributed_lock_ctx(root_ctx: RootContext) -> AsyncIterator[None]:
    root_ctx.distributed_lock_factory = init_lock_factory(root_ctx)
    yield


@asynccontextmanager
async def health_check_ctx(root_ctx: RootContext) -> AsyncIterator[None]:
    health_engine = HealthCheckEngine(
        root_ctx.db,
        root_ctx.core_event_producer,
        root_ctx.valkey_live,
        root_ctx.circuit_manager,
        root_ctx.local_config.proxy_coordinator.health_check_timer_interval,
        root_ctx.valkey_schedule,
    )
    root_ctx.health_engine = health_engine
    await health_engine.start()

    async def _check_health(_context: None, _src: AgentId, _event: DoHealthCheckEvent) -> None:
        # In Traefik mode, the loadBalancer.healthCheck directive takes care of
        # probing kernels directly; the coordinator must NOT run its own polling
        # loop. The leader cron also skips publishing DoHealthCheckEvent in this
        # mode, but we guard here as well so stray events are never actioned.
        if root_ctx.local_config.proxy_coordinator.enable_traefik:
            return
        try:
            # Check all endpoints with health checking enabled
            # This now only performs individual route health checks
            await health_engine.check_all_endpoints()
            log.debug("Health check cycle completed - individual route health updated")

        except Exception:
            log.exception("Error during health check")
            raise

    health_check_evh = root_ctx.event_dispatcher.consume(
        DoHealthCheckEvent,
        None,
        _check_health,
    )
    # Note: Timer is now managed by leader_election_ctx via LeaderCron
    try:
        yield
    finally:
        root_ctx.event_dispatcher.unconsume(health_check_evh)
        await health_engine.stop()


@asynccontextmanager
async def unused_port_collection_ctx(root_ctx: RootContext) -> AsyncIterator[None]:
    async def _collect(_context: None, _src: AgentId, _event: DoCheckUnusedPortEvent) -> None:
        try:

            async def _update(sess: SASession) -> list[Circuit]:
                non_inference_http_circuits = [
                    c
                    for c in (await Circuit.list_circuits(sess))
                    if c.app_mode != AppMode.INFERENCE and c.protocol == ProxyProtocol.HTTP
                ]
                if len(non_inference_http_circuits) == 0:
                    return []
                last_access = await root_ctx.valkey_live.get_multiple_live_data([
                    f"circuit.{c.id!s}.last_access" for c in non_inference_http_circuits
                ])
                unused_circuits: list[Circuit] = []

                for idx in range(len(last_access)):
                    access = last_access[idx]
                    last_access_time: float = 0
                    current_time = time.time()
                    if access:
                        last_access_time = current_time - float(access.decode("utf-8"))
                    else:
                        circuit_created_at = non_inference_http_circuits[idx].created_at
                        last_access_time = (
                            current_time - circuit_created_at.timestamp()
                            if circuit_created_at
                            else 0.0
                        )
                    if (
                        last_access_time
                        > root_ctx.local_config.proxy_coordinator.unused_circuit_collection_timeout
                    ):
                        unused_circuits.append(non_inference_http_circuits[idx])
                if len(unused_circuits) == 0:
                    return []

                log.info(
                    "collecting {} unused circuits: {}",
                    len(unused_circuits),
                    [str(c.id) for c in unused_circuits],
                )

                worker_map: dict[UUID, Worker] = {}
                for circuit in unused_circuits:
                    if circuit.worker not in worker_map:
                        worker_map[circuit.worker] = await Worker.get(sess, circuit.worker)

                    worker_map[circuit.worker].occupied_slots -= 1
                    await sess.delete(circuit)

                return unused_circuits

            async with root_ctx.db.connect() as db_conn:
                unused_circuits = await execute_with_txn_retry(
                    _update, root_ctx.db.begin_session, db_conn
                )
            await root_ctx.circuit_manager.unload_circuits(unused_circuits)

        except Exception:
            log.exception("")
            raise

    unused_port_collection_evh = root_ctx.event_dispatcher.consume(
        DoCheckUnusedPortEvent,
        None,
        _collect,
    )
    # Note: Timer is now managed by leader_election_ctx via LeaderCron
    try:
        yield
    finally:
        root_ctx.event_dispatcher.unconsume(unused_port_collection_evh)


@asynccontextmanager
async def service_discovery_ctx(root_ctx: RootContext) -> AsyncIterator[None]:
    sd_type = root_ctx.local_config.service_discovery.type
    service_discovery: ServiceDiscovery
    match sd_type:
        case ServiceDiscoveryType.REDIS:
            # Use core redis for service discovery if available, otherwise use main redis
            core_redis_profile_target = RedisProfileTarget.from_dict(
                (root_ctx.local_config.core_redis or root_ctx.local_config.redis).to_dict()
            )
            live_redis_target = core_redis_profile_target.profile_target(RedisRole.LIVE)
            service_discovery = await RedisServiceDiscovery.create(
                RedisServiceDiscoveryArgs(valkey_target=live_redis_target.to_valkey_target())
            )
        case _:
            raise RuntimeError(
                f"Unsupported service discovery type: {sd_type}. "
                "Please use Redis service discovery for appproxy."
            )

    # Determine announce addresses
    announce_addr = root_ctx.local_config.proxy_coordinator.announce_addr
    sd_loop = ServiceDiscoveryLoop(
        sd_type,
        service_discovery,
        ServiceMetadata(
            display_name=f"appproxy-coordinator-{root_ctx.local_config.proxy_coordinator.id}",
            service_group="appproxy-coordinator",
            version=__version__,
            endpoint=ServiceEndpoint(
                address=announce_addr.host,
                port=announce_addr.port,
                protocol="http",
                # It can be separated into an internal-purpose port later.
                prometheus_address=str(announce_addr),
            ),
        ),
    )

    if root_ctx.local_config.otel.enabled:
        meta = sd_loop.metadata
        otel_spec = OpenTelemetrySpec(
            service_name=meta.service_group,
            service_version=meta.version,
            log_level=root_ctx.local_config.otel.log_level,
            endpoint=root_ctx.local_config.otel.endpoint,
            service_instance_id=meta.id,
            service_instance_name=meta.display_name,
            max_queue_size=root_ctx.local_config.otel.max_queue_size,
            max_export_batch_size=root_ctx.local_config.otel.max_export_batch_size,
        )
        BraceStyleAdapter.apply_otel(otel_spec)

    # Start event-based SD publishing if config has service_group set
    sd_config = root_ctx.local_config.service_discovery
    sd_event_publisher: ServiceDiscoveryEventPublisher | None = None
    if sd_config.service_group and hasattr(root_ctx, "event_producer"):
        sd_event_publisher = ServiceDiscoveryEventPublisher(
            event_producer=root_ctx.event_producer,
            config=sd_config,
            component_version=__version__,
            startup_time=datetime.now(tz=UTC),
        )
        await sd_event_publisher.start()

    try:
        yield
    finally:
        if sd_event_publisher is not None:
            await sd_event_publisher.stop()
        sd_loop.close()


@asynccontextmanager
async def circuit_manager_ctx(root_ctx: RootContext) -> AsyncIterator[None]:
    root_ctx.circuit_manager = CircuitManager(
        root_ctx.event_dispatcher,
        root_ctx.event_producer,
        root_ctx.traefik_etcd,
        root_ctx.local_config,
    )
    if root_ctx.local_config.proxy_coordinator.enable_traefik:
        async with root_ctx.db.begin_readonly_session() as session:
            circuits = await Circuit.list_circuits(session, load_worker=True, load_endpoint=True)
            log.info("Injecting traefik configuration of {} circuits", len(circuits))
            await root_ctx.circuit_manager.initialize_traefik_circuits(circuits)

    yield


@asynccontextmanager
async def health_probe_ctx(root_ctx: RootContext) -> AsyncIterator[None]:
    """Initialize and start health probe with all health checkers."""
    probe = HealthProbe(options=HealthProbeOptions(check_interval=60))
    root_ctx.health_probe = probe

    # Register health checkers using already-initialized resources
    await probe.register(DatabaseHealthChecker(db=root_ctx.db))
    await probe.register(
        ValkeyHealthChecker(
            clients={
                ComponentId("live"): root_ctx.valkey_live,
                ComponentId("schedule"): root_ctx.valkey_schedule,
            }
        )
    )

    # Start periodic health checking
    await probe.start()
    try:
        yield
    finally:
        await probe.stop()


async def metrics(request: web.Request) -> web.Response:
    request["do_not_print_access_log"] = True
    root_ctx: RootContext = request.app["_root.context"]
    allowed_network = ipaddress.IPv4Network(
        root_ctx.local_config.proxy_coordinator.metric_access_allowed_hosts
    )
    if not request.remote:
        raise GenericForbidden
    try:
        remote_ip = ipaddress.IPv4Network(request.remote)
        if not remote_ip.subnet_of(allowed_network):
            raise GenericForbidden
    except ValueError as e:
        raise GenericForbidden from e

    return web.Response(
        text=root_ctx.metrics.to_prometheus(),
        content_type="text/plain",
    )


async def on_prepare(_request: web.Request, response: web.StreamResponse) -> None:
    response.headers["Server"] = "BackendAI"


async def status(request: web.Request) -> web.Response:
    root_ctx: RootContext = request.app["_root.context"]
    request["do_not_print_access_log"] = True
    advertised_addr = root_ctx.local_config.proxy_coordinator.advertise_base_url
    response = AppProxyStatusResponse(
        api_version="v2",
        advertise_address=advertised_addr,
    )
    return web.json_response(response.model_dump(mode="json"))


def handle_loop_error(
    _root_ctx: RootContext,
    _loop: asyncio.AbstractEventLoop,
    context: Mapping[str, Any],
) -> None:
    exception = context.get("exception")
    msg = context.get("message", "(empty message)")
    if exception is not None:
        if sys.exc_info()[0] is not None:
            log.exception("Error inside event loop: {0}", msg)
        else:
            exc_info = (type(exception), exception, exception.__traceback__)
            log.error("Error inside event loop: {0}", msg, exc_info=exc_info)


def _init_subapp(
    pkg_name: str,
    root_app: web.Application,
    subapp: web.Application,
    global_middlewares: Iterable[WebMiddleware],
) -> None:
    subapp.on_response_prepare.append(on_prepare)

    async def _set_root_ctx(subapp: web.Application) -> None:
        # Allow subapp's access to the root app properties.
        # These are the public APIs exposed to plugins as well.
        subapp["_root.context"] = root_app["_root.context"]

    # We must copy the public interface prior to all user-defined startup signal handlers.
    subapp.on_startup.insert(0, _set_root_ctx)
    if "prefix" not in subapp:
        subapp["prefix"] = pkg_name.split(".")[-1].replace("_", "-")
    prefix = subapp["prefix"]
    root_app.add_subapp("/" + prefix, subapp)
    root_app.middlewares.extend(global_middlewares)  # type: ignore


def init_subapp(pkg_name: str, root_app: web.Application, create_subapp: AppCreator) -> None:
    root_ctx: RootContext = root_app["_root.context"]
    subapp, global_middlewares = create_subapp(root_ctx.cors_options)
    _init_subapp(pkg_name, root_app, subapp, global_middlewares)


def init_lock_factory(root_ctx: RootContext) -> DistributedLockFactory:
    ipc_base_path = root_ctx.local_config.proxy_coordinator.ipc_base_path
    coordinator_id = root_ctx.local_config.proxy_coordinator.id
    lock_backend = root_ctx.local_config.proxy_coordinator.distributed_lock
    log.debug("using {} as the distributed lock backend", lock_backend)
    match lock_backend:
        case "filelock":
            return lambda lock_id, lifetime_hint: FileLock(  # noqa: ARG005
                ipc_base_path / f"{coordinator_id}.{lock_id}.lock",
                timeout=0,
            )
        case "pg_advisory":
            return lambda lock_id, lifetime_hint: PgAdvisoryLock(  # noqa: ARG005
                root_ctx.db, lock_id
            )
        case "redlock":
            redlock_config = root_ctx.local_config.proxy_coordinator.redlock_config

            return lambda lock_id, lifetime_hint: RedisLock(
                str(lock_id),
                root_ctx.redis_lock,
                lifetime=min(lifetime_hint * 2, lifetime_hint + 30),
                lock_retry_interval=redlock_config.lock_retry_interval,
            )
        case other:
            raise ValueError(f"Invalid lock backend: {other}")


def build_root_app(
    pidx: int,
    local_config: ServerConfig,
    *,
    cleanup_contexts: Sequence[CleanupContext] | None = None,
    subapp_pkgs: Sequence[str] = (),
) -> web.Application:
    root_ctx = RootContext()
    root_ctx.metrics = CoordinatorMetricRegistry.instance()

    app = web.Application(
        middlewares=[
            request_context_aware_middleware,
            exception_middleware,
            api_middleware,
            build_api_metric_middleware(root_ctx.metrics.api),
        ]
    )
    global_exception_handler = functools.partial(handle_loop_error, root_ctx)
    loop = asyncio.get_running_loop()
    loop.set_exception_handler(global_exception_handler)
    app["_root.context"] = root_ctx
    root_ctx.local_config = local_config
    root_ctx.pidx = pidx
    root_ctx.cors_options = {
        "*": aiohttp_cors.ResourceOptions(  # type: ignore[no-untyped-call]
            allow_credentials=False, expose_headers="*", allow_headers="*"
        ),
    }
    app.on_response_prepare.append(on_prepare)
    with importlib.resources.as_file(importlib.resources.files("ai.backend.appproxy.common")) as f:
        template_path = f / "templates"
        aiohttp_jinja2.setup(app, loader=jinja2.FileSystemLoader(template_path))

    if cleanup_contexts is None:
        cleanup_contexts = [
            redis_ctx,
            distributed_lock_ctx,
            database_ctx,
            event_dispatcher_ctx,
            leader_election_ctx,
            etcd_ctx,
            circuit_manager_ctx,
            health_probe_ctx,
            health_check_ctx,
            unused_port_collection_ctx,
            event_handler_ctx,
            service_discovery_ctx,
        ]
    shutdown_context_instances = []

    async def _cleanup_context_wrapper(_app: web.Application) -> AsyncIterator[None]:
        # aiohttp's cleanup contexts are just async generators, not async context managers.
        if cleanup_contexts is None:
            raise CleanupContextNotInitializedError("Cleanup contexts are not initialized")
        async with AsyncExitStack() as stack:
            for cctx in cleanup_contexts:
                cctx_instance = cctx(root_ctx)
                if hasattr(cctx_instance, "shutdown"):
                    shutdown_context_instances.append(cctx_instance)
                await stack.enter_async_context(cctx_instance)
            yield

    async def _trigger_shutdown(_app: web.Application) -> None:
        # shutdown is triggered before cleanup, giving chances to close client connections first.
        for cctx_instance in shutdown_context_instances:
            try:
                await cctx_instance.shutdown()
            except Exception:
                log.exception("error while shutting down a cleanup context")

    app.on_shutdown.append(_trigger_shutdown)
    app.cleanup_ctx.append(_cleanup_context_wrapper)
    cors = aiohttp_cors.setup(app, defaults=root_ctx.cors_options)
    # should be done in create_app() in other modules.
    cors.add(app.router.add_route("GET", "/status", status))
    cors.add(app.router.add_route("GET", "/metrics", metrics))
    for pkg_name in subapp_pkgs:
        if pidx == 0:
            log.info("Loading module: {0}", pkg_name[1:])
        subapp_mod = importlib.import_module(pkg_name, "ai.backend.appproxy.coordinator.api")
        init_subapp(pkg_name, app, subapp_mod.create_app)
    return app


@asynccontextmanager
async def server_main(
    loop: asyncio.AbstractEventLoop,
    pidx: int,
    _args: Sequence[Any],
) -> AsyncIterator[None]:
    local_config: ServerConfig = _args[0]
    loop.set_debug(local_config.debug.asyncio)

    @asynccontextmanager
    async def aiomonitor_ctx(root_app: web.Application) -> AsyncGenerator[None, None]:
        # Start aiomonitor.
        m = aiomonitor.Monitor(
            loop,
            termui_port=local_config.proxy_coordinator.aiomonitor_termui_port + pidx,
            webui_port=local_config.proxy_coordinator.aiomonitor_webui_port + pidx,
            console_enabled=False,
            hook_task_factory=local_config.debug.enhanced_aiomonitor_task_info,
        )
        m.prompt = f"monitor (proxy-coordinator[{pidx}@{os.getpid()}]) >>> "
        # Add some useful console_locals for ease of debugging
        m.console_locals["root_app"] = root_app
        m.console_locals["root_ctx"] = root_app["_root.context"]
        aiomon_started = False
        try:
            m.start()
            aiomon_started = True
        except Exception as e:
            log.warning(
                "aiomonitor could not start but skipping this error to continue", exc_info=e
            )
        try:
            yield
        finally:
            if aiomon_started:
                m.close()

    @asynccontextmanager
    async def webapp_ctx() -> AsyncGenerator[None, None]:
        ssl_ctx = None
        if local_config.proxy_coordinator.tls_listen:
            ssl_ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
            ssl_ctx.load_cert_chain(
                str(local_config.proxy_coordinator.tls_cert),
                str(local_config.proxy_coordinator.tls_privkey),
            )

        runner = web.AppRunner(
            root_app, keepalive_timeout=30.0, access_log_class=BackendAIAccessLogger
        )
        await runner.setup()
        service_addr = local_config.proxy_coordinator.bind_addr
        site = web.TCPSite(
            runner,
            str(service_addr.host),
            service_addr.port,
            backlog=1024,
            reuse_port=True,
            ssl_context=ssl_ctx,
        )
        await site.start()
        try:
            yield
        finally:
            await runner.cleanup()

    proxy_init_stack = AsyncExitStack()
    await proxy_init_stack.__aenter__()
    try:
        root_app = build_root_app(pidx, local_config, subapp_pkgs=global_subapp_pkgs)
        await proxy_init_stack.enter_async_context(aiomonitor_ctx(root_app))
        await proxy_init_stack.enter_async_context(webapp_ctx())

        if os.geteuid() == 0:
            uid = local_config.proxy_coordinator.user
            gid = local_config.proxy_coordinator.group
            os.setgroups([
                g.gr_gid for g in grp.getgrall() if pwd.getpwuid(uid).pw_name in g.gr_mem
            ])
            os.setgid(gid)
            os.setuid(uid)
            log.info("changed process uid and gid to {}:{}", uid, gid)

        log.info("Started the app-proxy coordinator service.")
    except Exception:
        log.exception("Server initialization failure; triggering shutdown...")
        loop.call_later(0.2, os.kill, 0, signal.SIGINT)
    try:
        yield
    finally:
        log.info("shutting down...")
        await proxy_init_stack.__aexit__(None, None, None)


@aiotools.server_context
async def server_main_logwrapper(
    loop: asyncio.AbstractEventLoop,
    pidx: int,
    _args: Sequence[Any],
) -> AsyncGenerator[None, signal.Signals]:
    setproctitle(f"backend.ai: proxy-coordinator worker-{pidx}")
    local_config: ServerConfig = _args[0]
    log_endpoint: str = _args[1]
    logger = Logger(
        local_config.logging,
        is_master=False,
        log_endpoint=log_endpoint,
        msgpack_options={
            "pack_opts": DEFAULT_PACK_OPTS,
            "unpack_opts": DEFAULT_UNPACK_OPTS,
        },
    )
    try:
        with logger:
            async with server_main(loop, pidx, _args):
                yield
    except Exception:
        traceback.print_exc(file=sys.stderr)


@click.group(invoke_without_command=True)
@click.option(
    "-f",
    "--config-path",
    "--config",
    type=Path,
    default=None,
    help=(
        "The config file path. (default: ./proxy-coordinator.toml and"
        " /etc/backend.ai/proxy-coordinator.toml)"
    ),
)
@click.option(
    "--debug",
    is_flag=True,
    help="A shortcut to set `--log-level=DEBUG`",
)
@click.option(
    "--log-level",
    type=click.Choice([*LogLevel], case_sensitive=False),
    default=LogLevel.NOTSET,
    help="Set the logging verbosity level",
)
@click.pass_context
def main(ctx: click.Context, config_path: Path | None, debug: bool, log_level: LogLevel) -> None:
    """
    Start the proxy-coordinator service as a foreground process.
    """
    log_level = LogLevel.DEBUG if debug else log_level
    server_config = load_config(config_path, log_level)

    if ctx.invoked_subcommand is None:
        tracker: memray.Tracker | None = None
        if server_config.profiling.enable_pyroscope:
            if not server_config.profiling.pyroscope_config:
                raise MissingProfilingConfigError(
                    "Pyroscope configuration is required when enable_pyroscope is True"
                )
            pyroscope.configure(**server_config.profiling.pyroscope_config.model_dump())
        if server_config.profiling.enable_memray:
            tracker = memray.Tracker(
                server_config.profiling.memray_output_destination,
                follow_fork=True,
            )
            tracker.__enter__()
        server_config.proxy_coordinator.pid_file.touch(exist_ok=True)
        server_config.proxy_coordinator.pid_file.write_text(str(os.getpid()))
        ipc_base_path = server_config.proxy_coordinator.ipc_base_path
        ipc_base_path.mkdir(exist_ok=True, parents=True)
        log_sockpath = ipc_base_path / f"coordinator-logger-{os.getpid()}.sock"
        log_endpoint = f"ipc://{log_sockpath}"
        try:
            logger = Logger(
                server_config.logging,
                is_master=True,
                log_endpoint=log_endpoint,
                msgpack_options={
                    "pack_opts": DEFAULT_PACK_OPTS,
                    "unpack_opts": DEFAULT_UNPACK_OPTS,
                },
            )
            with logger:
                setproctitle("backend.ai: proxy-coordinator")
                log.info("Backend.AI AppProxy Coordinator {0}", __version__)
                log.info("runtime: {0}", env_info())
                if server_config.profiling.enable_pyroscope:
                    log.info("Pyroscope tracing enabled")
                if server_config.profiling.enable_memray:
                    log.info("Memray tracing enabled")
                log_config = logging.getLogger("ai.backend.appproxy.coordinator.config")
                log_config.debug("debug mode enabled.")
                runner: Callable[..., Any]
                match server_config.proxy_coordinator.event_loop:
                    case EventLoopType.UVLOOP:
                        runner = uvloop.run
                        log.info("Using uvloop as the event loop backend")
                    case EventLoopType.ASYNCIO:
                        runner = asyncio.run
                try:
                    aiotools.start_server(
                        server_main_logwrapper,
                        num_workers=1,
                        args=(server_config, log_endpoint),
                        wait_timeout=5.0,
                        runner=runner,
                    )
                finally:
                    cleanup_prometheus_multiprocess_dir()
                    log.info("terminated.")
        finally:
            if server_config.proxy_coordinator.pid_file.is_file():
                # check is_file() to prevent deleting /dev/null!
                server_config.proxy_coordinator.pid_file.unlink()
            if tracker:
                tracker.__exit__(None, None, None)
    else:
        # Click is going to invoke a subcommand.
        pass


if __name__ == "__main__":
    sys.exit(main())
