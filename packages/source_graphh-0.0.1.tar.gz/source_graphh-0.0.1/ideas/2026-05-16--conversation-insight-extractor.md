---
date: "2026-05-16"
relations: []
---

# Idea: Conversation Insight Extractor

**Date:** 2026-05-16
**Status:** New
**Context:** Proposed during an explore session about source-graph's goals, after tracing how the relationship between `code-intuition` and `goal-achievement-system` emerged from conversation turns.

## Description

source-graph (or a similar tool) should be able to analyze conversation records (chatlogs, explore sessions) to extract "insight nodes" and "derivation relations", producing a **conversation insight graph**.

Conversations in explore mode are not disposable — they are knowledge assets. Currently, insights exist only in the agent's context window; after the session ends, they scatter into chatlog files waiting for manual reading. A conversation insight graph would make the insight-generation process visible and reusable.

### Node types to extract

- `insight` — e.g. "relations are where meaning happens"
- `decision` — e.g. "code-intuition is source-graph's product goal"
- `question` — e.g. "what's the logic of bidirectional related_goals?"
- `artifact` — e.g. "created ideas/goals/code-intuition/goal.md"

### Relation types to extract

- `led_to` — A insight/observation led to B conclusion
- `resolved_by` — A question was resolved by B answer/decision
- `enabled` — A goal/decision enabled B insight to emerge
- `references` — A idea references B artifact/goal

## Motivation

- **Insights are lost:** Currently, insights exist only in the agent's context window; after the session ends, they scatter into chatlog files waiting for manual reading.
- **Visibility:** A conversation insight graph would make the insight-generation process visible and reusable.
- **Connection discovery:** It would reveal isolated insights (mentioned but never connected).
- **Validation:** It would validate explore mode effectiveness — a good session should have deep connections, not parallel unrelated points.
- **Dogfooding:** It would be ultimate dogfooding — source-graph analyzing its own development conversations.

## Potential Implementation

- Parse chatlog / conversation records (structured text with speaker turns)
- Extract candidate nodes using heuristics or LLM prompting:
  - Key assertions → `insight`
  - Committed choices → `decision`
  - Explicit questions → `question`
  - Created files / external refs → `artifact`
- Extract typed relations between nodes based on temporal proximity, reference patterns, and causal language
- Output as a graph (nodes + edges) viewable through source-graph's existing visualization layer
- Re-evaluate and enrich the graph across multiple sessions

## Related Areas

- `ideas/goals/code-intuition/goal.md`
- `ideas/goals/goal-achievement-system/goal.md`
- `ideas/2026-05-16--typed-relations-for-goal-achievement-system.md`
- `ideas/2026-05-16--source-graph-as-universal-relation-extractor.md`
- `ideas/archive/chatlogs/` — the data source this idea would consume

## Notes

- This idea was born from the very conversation it describes analyzing.
- It is self-describing: the act of proposing a conversation insight extractor during a conversation is an instance of the meta-pattern it describes.
- **Tension / Unbound status:** This idea touches both `code-intuition` and `goal-achievement-system`:
  - From `code-intuition` angle: it extends source-graph from code analyzer to universal relation extractor (conversations are structured texts with relations)
  - From `goal-achievement-system` angle: it tracks how insights emerge during goal-clarification conversations, supporting goal iteration and path reconstruction
  - Agreed to record as **unbound** — `serves_goal: null` — because its primary service target is not yet clear. Time will tell which goal it naturally aligns with.
- **Open question:** Should it be a source-graph extractor plugin, or a standalone tool?
- **Open question:** Can the same `typed-relations` framework be applied to conversation-derived relations?
