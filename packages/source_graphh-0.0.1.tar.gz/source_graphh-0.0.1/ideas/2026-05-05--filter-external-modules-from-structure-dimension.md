---
date: "2026-05-05"
relations: []
---

# Idea: Filter external modules from structure dimension

**Date:** 2026-05-05
**Status:** New
**Context:** User observed that external module nodes clutter the `structure` dimension of the HTML report.

## Description

In the `structure` dimension of the HTML report, external module nodes (like `argparse`, `sys`, `os`) appear as root nodes because `_build_tree_data` adds orphan nodes (nodes with no relations in the current dimension) to the root list. These external modules have no meaning in the `structure` dimension and pollute the view.

### Example / Use case

When viewing the `structure` dimension, the root list includes nodes such as `argparse`, `sys`, and `os` alongside actual project files. These external modules have no parent-child relationships in the structure dimension, so they appear as orphans at the top level, making the tree harder to navigate.

## Motivation

External modules are irrelevant when exploring the project's internal code hierarchy. Including them as orphan root nodes adds noise, reduces clarity, and degrades the user experience of the structure visualization.

## Potential Implementation

- Modify `_build_tree_data` to exclude orphan nodes that represent external/stdlib modules when building the tree for the `structure` dimension.
- Alternatively, add a filter step before adding orphans to the root list that checks whether a node is an external module (e.g., by module name or by a flag in the node data).

## Related Areas

- HTML report generation
- `_build_tree_data` function
- `structure` dimension rendering

## Notes

- Need to determine a reliable way to identify external modules (e.g., stdlib list, `node.type` metadata, or path-based heuristics).
- Ensure the fix does not accidentally hide legitimate project orphans that should appear at the root.
