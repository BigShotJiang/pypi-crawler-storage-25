---
date: "2026-05-11"
relations:
  - target: goal:code-intuition
    relation: serves
    rationale: "Extends code intuition beyond Python to any language with an AST."
---

# Idea: Polyglot Extractor Support

**Date:** 2026-05-11
**Status:** New
**Context:** Proposed after Phase 1 decoupled extractors from disk I/O via the `extract(content, file_path)` protocol, making multi-language support a natural next step.

## Description

The `Extractor` protocol is now fully decoupled from disk: it receives source `content` and `file_path` and returns a list of `Node` and `Relation` objects. This means adding a new language requires only:

1. An AST parser for that language
2. Implementing the same `extract(content, file_path)` interface

The rest of the pipeline — `GraphStore`, visualization, query layer — is language-agnostic because it operates on uniform `Node` + `Relation` abstractions.

### Example / Use case

A team wants to visualize cross-language dependencies in a full-stack repository containing Python (backend), TypeScript (frontend), and Go (CLI). They register three extractors:

- `PythonStructureExtractor` + `PythonImportExtractor`
- `TypeScriptStructureExtractor` + `TypeScriptImportExtractor`
- `GoPackageExtractor`

All three write into the same `GraphStore`. The visualization renders a unified dependency graph where a Python API handler, a TypeScript React component, and a Go CLI tool can all appear in the same canvas, linked by cross-language relations (e.g., API contract edges).

## Motivation

Real-world codebases are rarely single-language. Making `source-graph` polyglot turns it from a Python-specific tool into a universal code knowledge base. The architectural work is already done; what remains is parser integration.

## Potential Implementation

1. **Language detection**: Use `file_path` suffix and/or shebang parsing to dispatch to the right extractor set. Register extractors in a `dict[str, list[Extractor]]` keyed by language.
2. **Parser options**:
   - **Language-native parsers**: `typescript` (via `typescript` or `swc`), `go/parser` (via Go toolchain), `rust-analyzer` syntax trees.
   - **Unified approach**: `tree-sitter` provides parsers for 100+ languages with a consistent C API. A single `tree-sitter` binding could power most language extractors.
3. **Node/Relation normalization**: Define a shared vocabulary of `kind` values (e.g., `class`, `function`, `module`, `import`) so that different extractors speak the same language to the store.
4. **Extensibility**: Allow users to register custom extractors at runtime via entry points or a configuration file.

## Related Areas

- `src/source_graph/extractor.py` — `Extractor` protocol definition
- `src/source_graph/python_*.py` — Current Python extractors as reference implementations
- `src/source_graph/store.py` — Language-agnostic storage layer

## Notes

- **Open question**: Should `source_paths` store a `language` column for filtering and UI styling?
- **Open question**: Tree-sitter produces syntax trees but not semantic resolution (types, imports). For languages with complex module systems (Rust crates, Go modules), a lightweight resolver may still be needed per language.
- **Caveat**: Polyglot support increases the surface area for schema drift. A strict `Node`/`Relation` validation layer becomes more important as more extractors are added.
