---
date: "2026-05-16"
relations: []
---

# Goal: Code Intuition

> 让开发者对代码库建立直觉。

## 是什么

source-graph 是一个**代码知识库 + 可视化工具**。

它从源代码中提取关系（结构、依赖、语义），存储为持久化的知识图谱，并通过多种可视化范式呈现，使开发者能够**感知**代码库的整体架构、耦合模式、瓶颈和演化趋势——而不需要逐行阅读代码。

"理解和导航"只是基础能力。**建立直觉**才是更深层次的目标。

## 做成什么样

### 1. 符号级语义分析

在**符号维度**上看清楚符号之间的依赖关系。

当前已实现的是文件维度的依赖关系（`a.py` imports `b.py`）。目标是在符号维度上回答：
- `a.py` 中的 `foo()` 调用了 `b.py` 中的 `bar()` 的哪个重载？
- 修改 `MyClass.__init__` 会影响多少处调用点？
- 这个类型注解指向的符号，在代码库中的完整继承链是什么？

### 2. 看清世界上的所有程序

source-graph 的野心是**多语言**。

不局限于 Python。任何有 AST 的编程语言都应该能被 source-graph 理解，并在同一张画布上呈现跨语言的依赖关系。

### 3. 多种可视化范式

不局限于 node-link 图。支持：
- **Dependency Matrix Heatmap** — 用颜色密度揭示耦合强度
- **Code Terrain** — 用地形隐喻感知架构的"山脉"与"平原"
- **Sankey Diagram** — 用流向揭示架构的"动脉"与"瓶颈"
- 未来可能的声音化（Sonification）—— 打破视觉通道，用听觉建立直觉

不同的范式回答不同的问题。开发者应该能根据当下想建立的直觉类型，切换视图。

### 4. 持久化知识库

不是一次性分析管道。数据库是产品本身：
- 增量更新（只分析变更的文件）
- 全文搜索（跨结构和内容）
- API 查询（IDE、CI、Dashboard 都能消费）
- 历史版本（观察架构随时间的演化）

### 5. 动态访问

从"生成报告 → 打开文件"的静态模式，进化到"启动服务 → 实时探索"的动态模式。

## 不做成什么样

来自旧项目 `diff-relation` 的教训和当前的技术约束：

- ❌ **不做 diff 分析工具** — 关系本身是价值，不局限于 diff 上下文
- ❌ **不做一次性分析管道** — Source Archive Layer 已打破这一点
- ❌ **不做纯静态报告生成器** — serve mode + API 已明确动态方向
- ❌ **不假设一步到位的语义分析** — 承认技术难度，先用依赖关系做概念验证，逐步建设自研语义分析能力
- ❌ **不局限于单一语言** — Python 是起点，不是终点

## 组成部分

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         Code Intuition Stack                            │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Layer 4: Intuition Layer (Multiple Visualization Paradigms)           │
│  ───────────────────────────────────────────────────────────────────   │
│  Matrix • Terrain • Sankey • Node-Link • Sonification (future)         │
│                                                                         │
│  Layer 3: Query Layer (Dynamic Access)                                 │
│  ───────────────────────────────────────────────────────────────────   │
│  Full-Text Search • REST API • Incremental Extract                     │
│                                                                         │
│  Layer 2: Semantic Layer (Symbol-Level Analysis)                       │
│  ───────────────────────────────────────────────────────────────────   │
│  Symbol Table • Bindings • Scope Resolution • Reference Tracking       │
│                                                                         │
│  Layer 1: Foundation Layer (Persistent Knowledge Base)                 │
│  ───────────────────────────────────────────────────────────────────   │
│  Source Archive • Structure Extraction • Import Extraction             │
│                                                                         │
│  Layer 0: Polyglot Layer (Universal Coverage)                          │
│  ───────────────────────────────────────────────────────────────────   │
│  Python ✓ • TypeScript • Go • Rust • ...                               │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 当前状态

| 组件 | 状态 |
|------|------|
| 文件维度结构提取（文件 → 类 → 方法） | ✅ 已实现 |
| 文件维度依赖提取（`a.py` imports `b.py`） | ✅ 已实现 |
| Source Archive Layer（原始文件持久化） | ✅ Phase 1 已完成 |
| Serve Mode（实时 HTTP 服务） | ✅ 已实现 |
| Presenter Template Separation | 🟡 Idea 阶段 |
| Symbol Table（符号表持久化） | 🟡 Idea 阶段 |
| Semantic Resolution（符号级解析） | 🔴 未开始 |
| Full-Text Search | 🔴 未开始 |
| Polyglot Extractor Support | 🔴 未开始 |
| Alternative Visualization Paradigms | 🔴 未开始 |

## 路径

从当前状态到目标的演进路线：

### Phase 1: 知识库基础设施（进行中）
- Presenter Template Separation
- Incremental Extract
- Content-hash-based change detection

### Phase 2: 符号语义分析（核心目标）
- Symbol Table Schema + Definition Population
- Import Binding Population
- Symbol Resolution Engine
- 这是从"文件维度"跃迁到"符号维度"的关键一步

### Phase 3: 查询与动态访问
- Code Knowledge Graph API（REST/GraphQL）
- Full-Text Search（FTS5）
- Frontend 从 SSR 切换到动态 SPA（fetch API）

### Phase 4: 多语言与扩展
- Polyglot Extractor Support（Tree-sitter 基础）
- 跨语言依赖关系可视化
- 自定义 Extractor 注册机制

### Phase 5: 直觉增强（长期）
- Alternative Visualization Paradigms（Matrix、Terrain、Sankey）
- 架构演化时间线
- Sonification 实验

## Open Questions

1. **"直觉"如何衡量？** 如何验证 source-graph 确实帮助开发者建立了直觉，而不只是提供了更多信息？
2. **多语言的统一抽象有多深？** 不同语言的模块系统、类型系统、作用域规则差异巨大。`Node`/`Relation` 抽象需要多通用？
3. **性能边界在哪里？** 百万行代码库的增量分析、符号解析、可视化渲染，各自的可接受延迟是多少？
4. **与现有工具的关系？** LSP、CodeQL、GitHub Copilot、SourceTrail（已停产）—— source-graph 的差异化价值是什么？
5. **商业模式？** 开源 CLI + 商业 SaaS？纯开源？个人工具 vs. 团队协作？

> **Created:** 2026-05-16  
> **Updated:** 2026-05-16

## Notes

- 这个目标是**从用户的碎片化表述中显式提取出来的**，不是凭空设计的。核心来源：
  - 5/9 Chatlog: "项目的目标是能在「符号」维度上看清楚「符号」之间的依赖关系"
  - 5/16 确认: "建立直觉是更深层次的目标"
  - 5/16 确认: "source-graph 的野心是看清世界上的所有程序"
- 目标是**活的**。它会随着时间丰满，不是一次性填写完整的模板。
- 当前最锋利的验证：让 source-graph 分析它自己，并在这个过程中验证每一次架构决策是否让"建立直觉"变得更容易。
