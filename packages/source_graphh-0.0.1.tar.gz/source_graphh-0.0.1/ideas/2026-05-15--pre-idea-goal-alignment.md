---
date: "2026-05-15"
relations: []
---

# Idea: Pre-Idea Goal Alignment

**Date:** 2026-05-15
**Status:** New
**Context:** During the design of the `goals/` directory mechanism, a critical correction emerged: the previous proposal for a "goal review ritual" after idea recording was backwards. The target must be considered *before* the idea, not after.

## Description

Establish a **pre-idea goal alignment** practice in the idea mechanism. Before an idea is discussed in depth or recorded, it is assessed against active goals. The relationship between the idea and the target is not one-way ("does this serve the goal?") but bidirectional: the idea either aligns with the goal, diverges from it, or enriches it.

This corrects a fundamental sequencing error: if goals are reviewed only after ideas are generated, the mechanism degrades into a "post-hoc justification system" where any idea can be retrofitted to the goal. True goal-driven thinking requires the goal to act as a filter *before* the idea takes shape.

### The Three Alignment States

| State | Meaning | Action |
|-------|---------|--------|
| **Aligned** | The idea is a path segment toward the goal | Continue discussion and record |
| **Divergent** | The idea has value but does not serve the current goal | Delay discussion, or record as unbound (`serves_goal: null`) |
| **Enriching** | The idea reveals a dimension the goal itself is missing | Update the goal before proceeding |

### Example / Use case

A team is discussing adding a real-time collaboration feature to a tool.

- **Active goal**: "Build a personal code knowledge base"
- **Idea**: "Add real-time collaborative editing"
- **Alignment check**: Does real-time collaboration serve a personal knowledge base?
  - **Aligned?** No — personal implies single-user.
  - **Divergent?** Yes, this is a multi-user feature.
  - **Enriching?** Maybe — if the definition of "personal" should expand to "small team", the goal itself needs updating.

Without pre-idea alignment, the team would discuss the feature for 30 minutes before realizing it conflicts with the product direction.

## Motivation

1. **Prevents goal erosion**: When ideas are generated first and aligned later, the goal slowly drifts to accommodate every interesting idea.
2. **Saves discussion time**: A 30-second alignment check can prevent hours of discussion on ideas that do not serve the current direction.
3. **Makes goal quality visible**: If most ideas are "divergent," the goal is either too narrow or the wrong goal. If most are "enriching," the goal is too vague.
4. **Preserves creative freedom**: "Divergent" is a valid outcome — the idea is not rejected, just deferred or recorded without binding.

## Potential Implementation

### Phase 1: Lightweight human practice (no code changes)

1. Update `record-idea` skill workflow to include an alignment step before structuring the idea
2. The skill prompts: "Which active goal does this idea relate to?" and offers the three states
3. The assessment is recorded in the idea's frontmatter or notes section

### Phase 2: Structured frontmatter

Add an `alignment` section to idea frontmatter:

```yaml
alignment:
  assessed_against: goal-achievement-system
  relation: aligned          # aligned | divergent | enriching
  rationale: "This idea directly implements the goal storage mechanism proposed in the goal."
```

### Phase 3: Dashboard integration

The auto-generated ideas dashboard (if implemented) shows:
- Percentage of ideas per alignment state per goal
- Goals with high "divergent" rates (possible goal/target mismatch)
- Goals with high "enriching" rates (goals that are still crystallizing)

## Related Areas

- `.claude/skills/record-idea/SKILL.md` — workflow template to modify
- `ideas/2026-05-12--goal-achievement-system-the-ultimate-form-of-idea-mechanism.md` — the parent goal this idea serves
- `ideas/goals/goal-achievement-system/goal.md` — the active goal file
- `ideas/2026-05-11--bidirectional-idea-change-linking.md` — related "bidirectional" concept, though applied to a different domain

## Notes

- **Human judgment is essential**: The alignment states cannot be determined automatically. The mechanism provides the *frame* for judgment, not the judgment itself.
- **"No goal" is still valid**: If no active goal exists, the alignment step is skipped and the idea is recorded as unbound. This preserves the exploratory phase.
- **Divergent ideas are not waste**: They may become the seed of a future goal. The key is *explicit divergence*, not implicit drift.
- **Open question**: Should the alignment assessment be mutable? If a goal is updated, should past ideas be re-assessed, or does the assessment reflect the goal state *at the time of discussion*?
