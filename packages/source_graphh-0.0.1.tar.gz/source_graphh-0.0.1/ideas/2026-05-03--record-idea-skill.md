---
date: "2026-05-03"
relations:
  - target: goal:goal-achievement-system
    relation: serves
    rationale: "Provides the foundational skill for capturing and persisting ideas within the goal achievement system."
---

# Idea: Record-Idea Skill

**Date:** 2026-05-03
**Status:** New
**Context:** During a conversation about creating custom skills for the `source-graph` project, the need arose to capture and persist ideas so they wouldn't be lost after the session ended. This skill was created as a direct response to that need.
**Serves:** [Goal Achievement System](2026-05-12--goal-achievement-system-the-ultimate-form-of-idea-mechanism.md)

## Description

Create a custom Kimi Code CLI skill called `record-idea` that captures ideas, feature requests, architectural decisions, or design concepts from conversations and persists them as structured markdown files in the project's `ideas/` directory.

The skill provides:
- A standardized markdown template with frontmatter (date, status, context)
- Consistent file naming convention: `ideas/<YYYY-MM-DD>--<kebab-case-title>.md`
- Clear sections for description, motivation, implementation approach, related areas, and notes
- Guidelines for writing ideas so they remain understandable without the full conversation context

### Example workflow

1. User says: *"We should add a dependency graph view that shows cross-file imports."*
2. Agent invokes the `record-idea` skill.
3. Skill structures the idea using the template and writes it to `ideas/2026-05-03--cross-file-import-dependency-extractor.md`.
4. The idea is now part of the project's permanent backlog, reviewable by any future reader.

## Motivation

1. **Prevents idea loss**: Conversations often generate valuable ideas that are forgotten once the session ends. Persisting them ensures they can be revisited and implemented later.
2. **Builds a project backlog**: Over time, the `ideas/` folder becomes a curated backlog of potential features, refactors, and design explorations.
3. **Enables async collaboration**: Team members (or future versions of the agent) can review recorded ideas without needing the original conversation context.
4. **Low friction**: The skill is triggered by natural phrases like "record this idea" or "write this down," making it effortless to capture thoughts in the moment.

## Potential Implementation

1. **Create the skill file** at `.claude/skills/record-idea/SKILL.md`.
   - Define frontmatter with `name` and `description`.
   - Provide a workflow section (identify → scope → structure → write).
   - Include the full markdown template with all required sections.
   - Add guidelines for writing style and status tracking.
2. **Establish the `ideas/` directory** as the canonical storage location.
   - Ensure it exists at the project root.
   - Use kebab-case titles and ISO date prefixes for sortability.
3. **Document the skill** so users know it's available and how to trigger it.

## Related Areas

- `.claude/skills/record-idea/SKILL.md` (the skill definition itself)
- `ideas/` (the directory where ideas are persisted)
- `.claude/skills/skill-creator/SKILL.md` (patterns for creating effective skills: progressive disclosure, concise instructions, proper frontmatter)
- `source-graph` project's custom skill ecosystem

## Notes

- **Status tracking**: Currently ideas are marked `New`. Future extensions could add statuses like `Exploring`, `Accepted`, `Declined`, or `Implemented` to track lifecycle.
- **Linking related ideas**: As the `ideas/` folder grows, it may be useful to add a `Related Ideas` section or frontmatter field that links to other idea files (e.g., `related: ["2026-05-03--cross-file-import-dependency-extractor.md"]`).
- **Auto-generating specs**: A future enhancement could bridge the gap between idea and implementation by auto-generating an OpenSpec change from an idea file, pre-populating the spec with the description and potential implementation steps.
- **Idea review workflow**: Consider a periodic review process (manual or automated) that surfaces old `New` ideas and prompts the user to update their status or prioritize them.
- **Evolution direction:** The `record-idea` skill has evolved beyond its initial scope. See `ideas/2026-05-12--record-idea-v2-lifecycle-management.md` for a comprehensive upgrade proposal covering structured frontmatter, lifecycle operations (Create/Append/Link/Update), template variants, and stable identifier resolution.
