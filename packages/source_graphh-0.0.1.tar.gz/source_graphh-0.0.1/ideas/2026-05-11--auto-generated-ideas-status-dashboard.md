---
date: "2026-05-11"
relations:
  - target: goal:goal-achievement-system
    relation: serves
    rationale: "Provides an overview of idea states to support goal-aligned prioritization."
---

# Idea: Auto-Generated Ideas Status Dashboard

**Date:** 2026-05-11
**Status:** New
**Context:** With 10+ ideas in `ideas/` and growing, there is no single place to see "what's the current state of the backlog." To check an idea's status, you must open each file and read its frontmatter. There is no overview of which ideas are New, which are In Progress, which are Implemented, or which have been sitting untouched for months. This friction slows down prioritization and makes it easy for valuable ideas to be forgotten.
**Serves:** [Goal Achievement System](2026-05-12--goal-achievement-system-the-ultimate-form-of-idea-mechanism.md)

## Description

Create a periodically auto-generated `ideas/README.md` (or `ideas/DASHBOARD.md`) that scans all idea files and produces a structured, human-readable status matrix. This serves as the canonical "project backlog view" — a single file that answers "what should we work on next?"

### Dashboard Sections

```markdown
# Ideas Dashboard

*Generated automatically from ideas/*.md — do not edit manually*

## Summary

| Status | Count | Oldest | Newest |
|--------|-------|--------|--------|
| New | 5 | 2026-05-03 | 2026-05-11 |
| Exploring | 2 | 2026-05-05 | 2026-05-09 |
| In Progress | 1 | 2026-05-09 | 2026-05-09 |
| Implemented | 4 | 2026-05-03 | 2026-05-11 |

## By Theme

### 🏗️ Architecture Foundation
| Idea | Status | Date | Links |
|------|--------|------|-------|
| Source Archive Layer | ✅ Implemented | 2026-05-09 | [change](openspec/changes/add-source-archive-layer) |
| Persistent Symbol Table | 🟡 New | 2026-05-09 | [idea](2026-05-09--persistent-symbol-table-and-source-archive.md) |
| Semantic Resolution | 🟡 New | 2026-05-09 | [idea](...) |

### 🎨 Visualization & Interaction
| Idea | Status | Date | Links |
|------|--------|------|-------|
| Presenter Template Separation | 🟡 New | 2026-05-11 | [idea](...) |
| Code Knowledge Graph API | 🟡 New | 2026-05-11 | [idea](...) |
| Radical Visualization Paradigms | 🟡 New | 2026-05-05 | [idea](...) |

## Stale Ideas (no activity > 30 days)

- `2026-05-03--explore-alternatives-to-pure-html-graph-rendering.md` — Status: New
- `2026-05-05--file-directory-tree-view.md` — Status: New

## Recently Implemented

- `2026-05-11--add-source-archive-layer` → [change](openspec/changes/add-source-archive-layer)
```

### Auto-Detection Rules

**Theme clustering** (Phase 2):
- Extract keywords from title and tags
- Group ideas sharing keywords into themes
- Themes with < 2 ideas are folded into "Miscellaneous"

**Stale detection**:
- Idea with `Status: New` and `Date` > 30 days ago → flagged as stale
- Idea with `Status: Exploring` and no linked change after 14 days → flagged as "at risk"

**Change linkage**:
- If an idea file mentions `openspec/changes/<name>/` → auto-link to change
- If a change's `proposal.md` links back to an idea → bidirectional link confirmed

## Motivation

1. **Single source of truth for backlog**: No more `ls ideas/` + `grep Status` + mental aggregation.
2. **Priority signals at a glance**: Stale ideas surface automatically. High-gravity ideas (many cross-references) bubble up.
3. **Onboarding accelerator**: New contributors read one file and understand the entire project's intellectual landscape.
4. **Decision support**: Before starting a new idea, check the dashboard — "Is there already an idea covering this?"
5. **Celebration of progress**: The "Recently Implemented" section makes completed work visible, creating closure.

## Potential Implementation

### Phase 1: Markdown generator script

```python
# scripts/generate-ideas-dashboard.py
import glob
import re
from datetime import datetime, timedelta
from pathlib import Path
import yaml

def parse_idea(path: Path) -> dict:
    with open(path) as f:
        text = f.read()
    # Extract frontmatter
    if text.startswith("---"):
        _, frontmatter, body = text.split("---", 2)
        meta = yaml.safe_load(frontmatter)
    else:
        meta = {}
    return {
        "id": path.stem,
        "title": meta.get("title", path.stem),
        "status": meta.get("Status", "New"),
        "date": datetime.strptime(meta.get("Date", "1970-01-01"), "%Y-%m-%d"),
        "tags": meta.get("tags", []),
        "body": body,
    }

def generate_dashboard(ideas: list[dict]) -> str:
    # Build summary table, theme tables, stale list, etc.
    ...

def main():
    ideas = [parse_idea(Path(p)) for p in glob.glob("ideas/*.md")]
    dashboard = generate_dashboard(ideas)
    Path("ideas/README.md").write_text(dashboard)

if __name__ == "__main__":
    main()
```

### Phase 2: CI integration

```yaml
# .github/workflows/ideas-dashboard.yml
name: Update Ideas Dashboard
on:
  push:
    paths:
      - "ideas/*.md"
jobs:
  update:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v5
      - run: uv run scripts/generate-ideas-dashboard.py
      - run: |
          git config user.name "github-actions"
          git config user.email "actions@github.com"
          git add ideas/README.md
          git diff --cached --quiet || git commit -m "chore: update ideas dashboard"
          git push
```

### Phase 3: Enhanced with cross-reference graph

Combine with [`ideas/2026-05-11--auto-generated-ideas-reference-graph.md`](2026-05-11--auto-generated-ideas-reference-graph.md):
- Dashboard links to the interactive graph
- Graph nodes link back to dashboard sections
- Together they form a "ideas wiki" — structured overview + visual exploration

## Related Areas

- `ideas/` — the data source
- `.claude/skills/record-idea/SKILL.md` — template definition; adding `tags` frontmatter improves theme clustering
- `ideas/2026-05-11--auto-generated-ideas-reference-graph.md` — visual complement to this structured dashboard
- `scripts/` — natural home for the generator script

## Notes

- **Do-not-edit header**: The generated file should have a prominent header warning users not to edit it manually, with a pointer to the generator script.
- **Manual overrides**: If a user *really* wants to override the dashboard, they can edit it — the generator should be idempotent and overwrite on next run.
- **Archive integration**: Archived ideas (`ideas/archive/`) should be optionally included (grayed out) or excluded from the main view.
- **Link to changes**: The dashboard should detect when an idea has been promoted to a change by scanning `openspec/changes/*/proposal.md` for back-references.
- **Future: Natural language queries**: Instead of static markdown, the dashboard could be a small CLI: `source-graph ideas-dashboard --status New --tag architecture`.
- **Architecture context:** This idea is simplified by the `record-idea` v2 upgrade in `ideas/2026-05-12--record-idea-v2-lifecycle-management.md`. With structured YAML frontmatter, the dashboard generator no longer needs regex parsing — it reads `status:`, `type:`, `tags:`, and `date:` directly. The reference graph is also simplified because `related_ideas:` and `related_changes:` in frontmatter provide edges explicitly.
