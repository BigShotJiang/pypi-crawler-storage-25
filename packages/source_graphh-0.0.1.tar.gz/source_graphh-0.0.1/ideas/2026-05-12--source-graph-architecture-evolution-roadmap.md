---
date: "2026-05-12"
relations: []
---

# Idea: Source Graph Architecture Evolution Roadmap

**Date:** 2026-05-12
**Status:** Active Roadmap
**Context:** Exploration of `unified-report-rendering-validation` revealed that the fundamental constraint on source-graph is not "lack of testing" but "data, presentation, and output format are all welded into a single static HTML file." This idea records the agreed-upon sequence for unlocking that constraint.

## The Core Constraint

```
┌─────────────────────────────────────────────────────────────┐
│  Current: Three layers welded into one artifact              │
├─────────────────────────────────────────────────────────────┤
│  Data Layer      ──►  SQLite (source_graph.db)               │
│       │                                                     │
│       ▼                                                     │
│  Assembly Layer  ──►  presenter.py serializes ALL data      │
│       │               into one JSON blob                     │
│       ▼                                                     │
│  Output Layer    ──►  report.html (self-contained)           │
│                       ├── all node data                      │
│                       ├── all relation data                  │
│                       ├── all source code                    │
│                       ├── 900 lines JS rendering logic       │
│                       └── 200 lines CSS                      │
└─────────────────────────────────────────────────────────────┘
```

This single-file design was correct for a "toy" phase — zero dependencies, double-click to open. But it creates a hard ceiling on:
- **Incremental updates**: Changing a filter requires re-running the entire pipeline.
- **Frontend evolution**: JS lives in a Python f-string — no lint, no build, no source maps.
- **Multiple consumers**: HTML is for humans only; tools (IDEs, CI) cannot query the data.
- **Dynamic interactivity**: Every query must be pre-baked; no runtime filtering without regeneration.

## The Unlocked Architecture

```
                    ┌─────────────────────┐
                    │  source_graph.db     │  ◄── Core asset
                    │  (SQLite + WAL)      │
                    └──────────┬──────────┘
                               │
           ┌───────────────────┼───────────────────┐
           │                   │                   │
           ▼                   ▼                   ▼
    ┌─────────────┐    ┌─────────────┐    ┌─────────────────┐
    │  Static HTML│    │  Static Dir │    │  HTTP Serve     │
    │  (snapshot) │    │  (multi-file)│   │  (real-time)    │
    │             │    │             │    │                 │
    │  present    │    │  present    │    │  serve <db>     │
    │  command    │    │  --dir      │    │                 │
    └─────────────┘    └─────────────┘    └─────────────────┘
         │                   │                   │
         │                   │                   ▼
         │                   │          ┌─────────────────┐
         │                   │          │  Future: API    │
         │                   │          │  /api/nodes     │
         │                   │          │  /api/search    │
         │                   │          └─────────────────┘
         │                   │
         └───────────────────┘
              All share the same
              presenter.render() core
```

## Agreed Evolution Sequence

### Step 0: Unified Report Rendering Validation (Retained)
- **Idea**: `ideas/2026-05-11--unified-report-rendering-validation.md`
- **Status**: Important, not urgent
- **What**: Playwright-based headless browser validation of generated HTML
- **Why retained**: Even after architecture evolves, the HTML output (whether static or served) still needs regression testing. Playwright validates that embedded JSON is syntactically correct and that frontend interactions execute without runtime errors.
- **Trigger**: After presenter-template-separation lands, so the validation script can target both inline-HTML and served-HTML modes.

### Step 1: Add Serve Command (Completed ✓)
- **Change**: `openspec/changes/archive/2026-05-12-add-serve-command/`
- **Spec**: `openspec/specs/serve-mode/spec.md` (synced from change)
- **What**: `source-graph serve <db_path>` starts an HTTP server that calls `presenter.render()` on each request
- **Why now**: Lowest-risk path to unlock "live report viewing." Reuses 100% of existing presenter logic. Frontend requires zero changes. Adds zero dependencies.
- **Scope boundary**: No REST API, no query parameters, no frontend fetch. Pure server-side rendering MVP.
- **Status**: Implemented, tested, and archived on 2026-05-12.

### Step 2: Presenter Template Separation ✓ Completed
- **Idea**: `ideas/archive/implemented/2026-05-11--presenter-template-separation.md`
- **Change**: `openspec/changes/archive/2026-05-19-replace-presenter-with-fastapi-serve/`
- **What**: `presenter.py` was abolished (not refactored). Frontend assets extracted to `src/source_graph/web/`. FastAPI serves static files + `GET /api/data` endpoint. Frontend loads data via `fetch()`.
- **Why**: Unlocks frontend tooling (ESLint, formatting, unit tests). Eliminates f-string escaping bugs. Makes the frontend editable by non-Python developers.
- **Relationship to Step 1**: Serve mode was the foundation; this change replaced the SSR approach with true frontend-backend separation.

### Step 3: Code Knowledge Graph API
- **Idea**: `ideas/2026-05-11--code-knowledge-graph-api.md`
- **What**: `source-graph serve` grows REST endpoints (`/api/nodes`, `/api/search`, etc.). Frontend switches from embedded JSON to `fetch('/api/...')`.
- **Why**: Enables dynamic querying, IDE integration, CI/CD guards, team dashboards.
- **Relationship to Step 1**: Step 1 proves the "db → HTTP" loop works. Step 3 adds API routes and converts the frontend from SSR to SPA. The same `server.py` evolves; no rewrite needed.

### Step 4: Separate Relationship Production from Rendering
- **Idea**: `ideas/2026-05-05--separate-relationship-production-from-rendering.md`
- **What**: `extract` and `present` become fully independent CLI phases. `present` loads from a DB path instead of receiving a live `RelationStore` object.
- **Why**: Eliminates redundant extraction. Enables CI/CD stage separation.
- **Relationship**: Already partially complete (`extract` and `present` subcommands exist). The remaining work is refactoring `HTMLPresenter` to accept a DB path, which is a natural prerequisite for serve mode's database-loading logic.

## Cross-Reference Matrix

| Idea / Change | Related Artifacts | Relationship |
|--------------|-------------------|--------------|
| `unified-report-rendering-validation` | `add-serve-command` (change, archived) | Serve mode provides a more efficient validation target than file generation |
| `presenter-template-separation` | `add-serve-command` (change, archived) | Template separation makes serve mode's file-serving cleaner; serve mode works either way |
| `code-knowledge-graph-api` | `add-serve-command` (change, archived) | Serve MVP is the infrastructure foundation; API mode is the evolution |
| `separate-relationship-production-from-rendering` | `add-serve-command` (change, archived) | Both require presenter to load from a database path |
| `explore-alternatives-to-pure-html-graph-rendering` | `code-knowledge-graph-api` (idea) | API mode enables alternative rendering stacks (D3, Sigma, WebGL) |

## Decision Log

| Date | Decision | Rationale |
|------|----------|-----------|
| 2026-05-12 | Serve MVP uses SSR, not API+SPA | Zero frontend changes, zero API design, lowest risk |
| 2026-05-12 | No query string routing in serve MVP | Frontend already handles dimension switching client-side; URL routing adds complexity without user value |
| 2026-05-12 | Use stdlib `http.server`, not FastAPI | Single route MVP; avoid dependencies until API mode justifies them |
| 2026-05-12 | Playwright validation retained but deferred | Validation is important but blocked on having a stable, separable frontend |

## Open Questions

1. **Should `serve` support hot-reload?** If the database changes on disk while serving, should the next request auto-detect and reload? SQLite's connection caching may hide updates.
2. **Should static HTML mode be deprecated once serve mode matures?** Or should both always coexist for offline distribution?
3. **When does presenter-template-separation happen relative to serve?** Before (cleaner) or after (lower risk)?
