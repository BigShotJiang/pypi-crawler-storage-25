---
date: "2026-05-11"
relations:
  - target: goal:code-intuition
    relation: serves
    rationale: "Enables dynamic frontend and alternative rendering paradigms for code intuition visualization."
---

# Idea: Separate Presenter into Data + Template Layers

**Date:** 2026-05-11
**Status:** Implemented
**Context:** During the implementation of `add-source-archive-layer`, repeated f-string escaping bugs in `presenter.py` revealed that the current "pure Python f-string generates HTML/JS/CSS" approach has reached its architectural ceiling. The file is 1100+ lines of interleaved Python, HTML, CSS, and JavaScript, making it fragile to extend.

## Description

Refactor `presenter.py` from a monolithic f-string HTML generator into a clean separation:
- **Python layer**: Queries the store, serializes data to JSON, renders a template
- **Template layer**: A static HTML template with embedded JSON data blocks
- **Frontend layer**: Pure static JavaScript that reads the JSON at runtime and renders the UI

### Current Problem

```python
# presenter.py (current) — 1100+ lines
html = f"""
<script>
const graphData = {json.dumps(all_data)};  // Python generating JS
function renderNode(node) {{
  let tooltip = `FQN: ${{escapeHtml(node.fqn)}}`;  // f-string + JS template literal conflict
  // ... 600 more lines of interleaved JS/CSS
}}
</script>
"""
```

Pain points:
1. **Escaping hell**: JS `{` conflicts with Python f-string `{`. Every frontend change risks a SyntaxError.
2. **Un-testable frontend**: JS logic is embedded in a Python string — cannot lint, format, or unit test.
3. **No separation of concerns**: Changing a tooltip style requires editing Python code.
4. **Scalability ceiling**: Adding new views (matrix, sankey, terrain) makes the file exponentially larger.

### Proposed Architecture

```
┌─────────────────────────────────────────────┐
│  Python: presenter.py                        │
│  ─────────────────────                       │
│  • Query store (nodes, relations, sources)  │
│  • Build data structures                     │
│  • Render Jinja2 template                    │
│  • Output: HTML file                         │
└──────────────┬──────────────────────────────┘
               │ passes data as JSON
               ▼
┌─────────────────────────────────────────────┐
│  Template: templates/report.html            │
│  ─────────────────────────────               │
│  • Static HTML structure                    │
│  • `<script id="data" type="json">`         │
│  • `<link rel="stylesheet" href="...">`     │
│  • `<script src="static/app.js"></script>`  │
└─────────────────────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────┐
│  Frontend: static/app.js                     │
│  ─────────────────────                       │
│  • Pure JavaScript, no Python strings        │
│  • Reads JSON from DOM at runtime            │
│  • Renders all views (tree, graph, map)      │
│  • Unit-testable with Jest/Vitest            │
└─────────────────────────────────────────────┘
```

### Example

**Python (presenter.py)**
```python
from jinja2 import Environment, FileSystemLoader

class HTMLPresenter:
    def render(self, dimension: str) -> str:
        data = {
            "dimensions": self._build_all_dimensions(),
            "sourceContents": self._build_source_contents(),
            "sourcePaths": self._build_source_paths(),
        }
        template = self._jinja.get_template("report.html")
        return template.render(
            graph_data=json.dumps(data),
            default_dimension=dimension,
        )
```

**Template (templates/report.html)**
```html
<!DOCTYPE html>
<html>
<head><title>Source Graph</title></head>
<body>
  <div id="app"></div>
  <script id="graph-data" type="application/json">
    {{ graph_data | safe }}
  </script>
  <script src="static/app.js"></script>
</body>
</html>
```

**Frontend (static/app.js)**
```javascript
const data = JSON.parse(document.getElementById('graph-data').textContent);

function renderNode(node) {
  // Pure JS — no f-string escaping, no Python interleaving
  const snippet = getSourceSnippet(node);
  // ...
}
```

## Motivation

1. **Eliminate f-string escaping bugs**: Frontend code lives in `.js` files, not Python strings.
2. **Frontend testability**: Can run ESLint, unit tests, and formatters on `static/app.js`.
3. **Designer-friendly**: HTML/CSS/JS can be edited by someone who doesn't know Python.
4. **Scalable views**: Adding a new visualization only requires adding a JS module, not touching Python.
5. **Reusable frontend**: The same `app.js` can consume data from a local file (static HTML) or from an API (dynamic mode).

## Potential Implementation

1. **Phase 1: Extract JS to static file**
   - Move all JavaScript from `presenter.py` to `src/source_graph/static/app.js`
   - Replace inline JS with `<script src="...">` reference
   - Keep CSS inline initially

2. **Phase 2: Introduce Jinja2 template**
   - Add `templates/report.html`
   - Replace f-string HTML with `jinja2.Template.render()`
   - Pass data as JSON blocks

3. **Phase 3: Extract CSS**
   - Move styles to `static/style.css`
   - Template links to external stylesheet

4. **Phase 4: Frontend testing**
   - Add `jest` or `vitest` to project
   - Write unit tests for `renderNode()`, `getSourceSnippet()`, etc.

## Related Areas

- `src/source_graph/presenter.py` — current monolithic implementation
- `openspec/changes/add-source-archive-layer/` — the change that exposed the fragility
- `ideas/2026-05-03--explore-alternatives-to-pure-html-graph-rendering.md` — related but orthogonal (that idea focuses on rendering *technology*, this one on *architecture*)

## Notes

- **Jinja2 vs stdlib `string.Template`**: Jinja2 is more powerful (conditionals, loops, filters) but adds a dependency. For a CLI tool, `string.Template` might be sufficient and lighter.
- **Self-contained HTML trade-off**: Current output is a single `.html` file. After template separation, the output might require multiple files (HTML + JS + CSS). To preserve single-file distribution, consider embedding JS/CSS as data URIs or using a bundler.
- **Migration path**: Can be done incrementally — first extract JS while keeping f-string HTML, then introduce template engine.
- **Architecture context:** This idea is Step 2 in the evolution roadmap (`ideas/2026-05-12--source-graph-architecture-evolution-roadmap.md`). It can happen before or after `add-serve-command` — serve mode works with both inline-HTML and template-based HTML.
- **Enables:** `ideas/2026-05-11--unified-report-rendering-validation.md` (frontend testability), `ideas/2026-05-11--code-knowledge-graph-api.md` (reusable frontend for dynamic mode).

## Outcome (2026-05-19)

This idea was implemented by change [`replace-presenter-with-fastapi-serve`](../openspec/changes/archive/2026-05-19-replace-presenter-with-fastapi-serve/).

**What was completed:**
- `presenter.py` (1175 lines) was deleted entirely — not refactored, but abolished
- `present` CLI subcommand was removed; `serve` is now the only consumption path
- Frontend assets (HTML/JS/CSS) were extracted to `src/source_graph/web/`
- FastAPI replaced `http.server`; `GET /api/data` returns all dimension data as JSON
- Frontend loads data via `fetch('/api/data')` instead of embedded JSON
- Data-building logic (`_build_*` methods) migrated to `data_builder.py` as pure functions
- All 90 tests pass

**What diverged from the original proposal:**
- No Jinja2 template was introduced — the original proposal assumed retaining `present` with template rendering
- The actual implementation went further: full frontend-backend separation with FastAPI
- No `jest` or `vitest` was added — frontend testability was achieved through architectural separation alone

**Status:** Implemented
