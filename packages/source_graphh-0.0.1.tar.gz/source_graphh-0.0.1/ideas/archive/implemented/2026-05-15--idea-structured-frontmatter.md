---
date: "2026-05-15"
relations:
  - target: goal:goal-achievement-system
    relation: serves
    rationale: "Frontmatter 是 goal-achievement-system 数据基础设施的基石。"
---

# Idea: Structured Frontmatter for Ideas

**Date:** 2026-05-15
**Status:** New
**Context:** The current `record-idea` template uses inline metadata (`**Date:**`, `**Status:**`, `**Context:**`) at the top of each idea file. This format is human-readable but not machine-parseable, which blocks dashboard generation, graph extraction, and any form of automated idea analysis. This idea proposes migrating to structured YAML frontmatter.

## Description

Replace the inline metadata block in idea files with a YAML frontmatter block. The frontmatter becomes the machine-readable interface for idea properties, while the markdown body remains free-form for human narrative.

### Current Format (inline)

```markdown
# Idea: Title

**Date:** 2026-05-12
**Status:** New
**Context:** After reviewing all 23 ideas...
```

### Target Format (YAML frontmatter)

```markdown
---
date: 2026-05-12
status: New
context: "After reviewing all 23 ideas..."
serves_goal: goal-achievement-system
tags: [architecture, mechanism]
related_ideas:
  - 2026-05-12--goal-achievement-system
---

# Idea: Title
```

### Frontmatter Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `date` | string (YYYY-MM-DD) | yes | Creation date |
| `status` | enum | yes | New / Exploring / Accepted / Declined / Implemented |
| `context` | string | yes | One-sentence origin |
| `serves_goal` | string | no | Goal directory name this idea serves |
| `tags` | string[] | no | Thematic tags for clustering |
| `related_ideas` | string[] | no | Other idea file stems (date + title) |

## Motivation

1. **Enables dashboard generation**: A script can parse YAML frontmatter with `yaml.safe_load()` instead of regex-matching `**Date:**` patterns. The existing `auto-generated-ideas-status-dashboard` idea is blocked on this.
2. **Enables reference graph extraction**: `related_ideas:` provides edges explicitly, without regex-parsing markdown links. The `auto-generated-ideas-reference-graph` idea is simplified by this.
3. **Enables goal binding**: `serves_goal:` is the data foundation for the `goal-aware-record-idea-skill` idea.
4. **Standard practice**: YAML frontmatter is the convention in Jekyll, Hugo, Obsidian, and most modern markdown-based systems.

## Potential Implementation

### Phase 1: Update the skill template

1. Modify `.claude/skills/record-idea/SKILL.md` template to use YAML frontmatter
2. New ideas are created with the frontmatter format
3. The inline metadata fields become optional fallbacks for backward compatibility

### Phase 2: Batch migration (optional)

```python
# scripts/migrate-idea-frontmatter.py
# Scans ideas/*.md, extracts inline metadata, converts to YAML frontmatter
# Preserves all body content
```

This is a one-time script. It should:
- Extract `**Date:**`, `**Status:**`, `**Context:**` via regex
- Generate YAML frontmatter block
- Prepend to file
- Remove or comment out the old inline block

### Phase 3: Tooling unlock

Once all ideas use YAML frontmatter:
- `scripts/generate-ideas-dashboard.py` reads `status:`, `date:`, `tags:` directly
- `scripts/generate-ideas-graph.py` reads `related_ideas:` for edges
- `scripts/goal-status-report.py` reads `serves_goal:` to show goal coverage

## Related Areas

- `.claude/skills/record-idea/SKILL.md` — template source
- `ideas/2026-05-11--auto-generated-ideas-status-dashboard.md` — unblocked by this change
- `ideas/2026-05-11--auto-generated-ideas-reference-graph.md` — simplified by this change
- `ideas/2026-05-15--goal-aware-record-idea-skill.md` — depends on `serves_goal:` frontmatter
- `ideas/2026-05-12--record-idea-v2-lifecycle-management.md` — this idea is a subset of the v2 proposal's Layer 1 (Data layer)

## Notes

- **Backward compatibility**: Ideas without frontmatter should still be readable by tooling during a transition period. Tooling can attempt YAML frontmatter first, then fall back to regex parsing.
- **Migration risk**: The batch script must be tested on a copy of the ideas directory first. A single malformed regex could corrupt idea files.
- **Open question**: Should `context:` remain in frontmatter (structured) or move to the body (more narrative)? Suggestion: keep it in frontmatter — it is metadata, not content.

## Outcome (2026-05-17)

This idea was partially absorbed by [`typed-relations-for-goal-achievement-system`](2026-05-16--typed-relations-for-goal-achievement-system.md), which established a **minimal frontmatter schema** (`date` + `relations`) across all 31 goal/idea files.

**What was completed:**
- All 29 ideas and 2 goals now have YAML frontmatter
- `serves_goal` and `related_ideas` were subsumed by the unified `relations` field
- `date` was successfully migrated from inline metadata to frontmatter

**What was explicitly excluded:**
- `status`, `context`, and `tags` were removed from the schema per decision to keep frontmatter minimal
- Inline `**Date:**`, `**Status:**`, `**Context:**` blocks remain in document body

**What was completed (2026-05-18):**
1. `.claude/skills/record-idea/SKILL.md` template updated — new ideas are created via the `gas write` CLI, which generates deterministic YAML frontmatter
2. `gas` CLI tooling built: `gas write` for frontmatter generation, `gas validate` for schema compliance checking

**Status:** Implemented
