---
date: "2026-05-05"
relations: []
---

# Idea: Separate Relationship Production from Rendering

**Date:** 2026-05-05
**Status:** Implemented
**Context:** Discussion about decoupling the extraction/storage pipeline from visualization in the source-graph project.

## Description

Split the current monolithic pipeline into two independent phases: **relationship production** (extraction + storage) and **relationship rendering** (visualization).

Currently, `cli.py` performs extraction → storage → rendering in a single command. `HTMLPresenter.render(store, dimension)` receives a live `RelationStore` object and generates a static HTML file. Every change in view, dimension, or filter forces a full re-run of the entire pipeline.

The proposed separation:
- `source-graph extract` only produces `source_graph.db`.
- `source-graph present <db_path>` loads the database and handles all rendering independently.

This establishes a clean architectural boundary between producing relational data and consuming it for visualization.

### Example / Use case

A developer runs `source-graph extract ./my-project` once to generate `source_graph.db`. They can then run:

```bash
source-graph present source_graph.db --dimension structure
source-graph present source_graph.db --dimension dependency
source-graph present source_graph.db --filter exclude-external
```

…multiple times without re-extracting. In CI/CD, extraction runs on every commit while presentation runs on-demand or as a separate nightly job.

## Motivation

1. **Eliminate redundant work**: Changing a view, dimension, or filter currently requires re-running the full extraction + storage + rendering pipeline, which is slow and unnecessary.
2. **Switch views without re-extracting**: Once the database exists, any visualization can be regenerated from it instantly.
3. **Incremental updates**: The database can be updated incrementally (e.g., only changed files) without touching the presentation layer.
4. **Multiple output formats**: The same `source_graph.db` can feed HTML, SVG, JSON, or future formats without re-extracting.
5. **Runtime filtering and search**: A separated presenter can support filtering, search, and dimension switching at runtime without regenerating the output file.
6. **CI/CD separation**: Extraction and presentation can run in different pipeline stages, jobs, or even repositories.

## Potential Implementation

### Short-term (minimum viable)
- Extract rendering logic from `cli.py`.
- Add `source-graph present <db_path>` as a new CLI subcommand.
- Refactor `HTMLPresenter` to load from a database path instead of receiving a `RelationStore` object.
- Continue generating static HTML; the primary deliverable is the *separation of concerns*, not new interactivity.

### Mid-term
- Introduce multiple presenter backends: `HTMLStaticPresenter`, `HTTPServerPresenter`, etc.
- Add runtime filtering, search, and dimension switching without output regeneration.
- Support new visualization paradigms (matrix, terrain, sankey) as pluggable backends.

### Long-term (uncertain, needs exploration)
- `source-graph serve <db>` — launch a dynamic local HTTP service.
- Real-time querying via browser.
- Hot reload when the database changes on disk.
- Export current dynamic view to static HTML.
- Transition the project from a "static report generator" to a "code architecture browser."

## Related Areas

- `src/source_graph/cli.py` — current monolithic command that performs extraction, storage, and rendering in one pass.
- `src/source_graph/presenter.py` — current `HTMLPresenter` implementation; needs refactoring to accept a DB path or abstract data interface.
- `src/source_graph/store.py` — `RelationStore` and SQLite persistence layer; forms the data contract between the CLI and Presenter.
- `ideas/2026-05-03--explore-alternatives-to-pure-html-graph-rendering.md` — related but distinct. That idea focuses on alternative *rendering stacks* (JS payload, WASM SQLite, WebGL). This idea focuses on architectural *separation of concerns* between pipeline phases.
- `ideas/2026-05-05--radical-visualization-paradigms-beyond-node-link.md` — future visualization paradigms that would benefit directly from a pluggable presenter backend system enabled by this separation.

## Notes

- **Presenter form**: Should it be a standalone CLI tool, a subcommand (`source-graph present`), or a separate package entirely?
- **Static vs. dynamic trade-off**: How to preserve the current advantage of single-file offline distribution while enabling dynamic querying? A hybrid model (static export from a dynamic service) may be the answer.
- **Data contract**: Should the Presenter use `RelationStore` directly, or should an abstract interface insulate it from storage changes?
- **Offline distribution**: The long-term `serve` mode introduces a dependency on a running process. Consider whether the default behavior should remain static HTML with `serve` as an opt-in advanced feature.
- **Migration path**: The short-term MVP can be delivered without changing the existing `extract` behavior; simply add `present` and later deprecate the all-in-one flow.
- **Architecture context:** This idea is Step 4 in the evolution roadmap (`ideas/2026-05-12--source-graph-architecture-evolution-roadmap.md`). The database-as-contract pattern it establishes is the foundation for both `present` and `serve` commands loading data independently.
- **Enables:** `openspec/changes/archive/2026-05-12-add-serve-command/` — serve mode's `RelationStore(db_path)` loading logic is a direct continuation of the "presenter loads from database" separation.

## Outcome (2026-05-09 / 2026-05-19)

This idea was implemented by change [`separate-production-from-rendering`](../openspec/changes/archive/2026-05-09-separate-production-from-rendering/) (2026-05-09) and later deepened by [`replace-presenter-with-fastapi-serve`](../openspec/changes/archive/2026-05-19-replace-presenter-with-fastapi-serve/) (2026-05-19).

**What was completed:**
- `extract` CLI subcommand was added — produces `source_graph.db` without rendering
- `GraphStore` protocol was introduced in `store.py` as the data contract between extraction and consumption layers
- `HTMLPresenter` was refactored to load from a database path via `RelationStore(db_path)`
- `present` CLI subcommand was added — loads db and generates static HTML independently
- The monolithic `cli.py` pipeline was split into two independent phases

**What diverged from the original proposal:**
- The `present` subcommand and `HTMLPresenter` class were later removed entirely (2026-05-19)
- Static HTML generation was replaced by FastAPI `serve` mode with a dynamic JSON API (`GET /api/data`)
- Frontend assets were extracted to `src/source_graph/web/` and load data via `fetch()` instead of embedded JSON
- Data-building logic migrated to `data_builder.py` as pure functions
- The separation became even more radical: extraction and rendering now run in separate processes

**Status:** Implemented
