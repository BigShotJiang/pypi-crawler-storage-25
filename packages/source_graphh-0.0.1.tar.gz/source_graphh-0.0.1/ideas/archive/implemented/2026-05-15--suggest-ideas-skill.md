# Idea: Suggest-Ideas Skill

**Date:** 2026-05-15
**Status:** Implemented
**Context:** During the exploration of the idea mechanism's consumption side, a critical gap was identified: the mechanism has a `record-idea` skill for production, but no skill for discovery and recommendation. When a user starts a session facing 27 ideas, there is no tool to help them navigate from goals to actionable ideas.

## Description

Create a `suggest-ideas` skill as the sibling of `record-idea`. While `record-idea` handles production (creating ideas), `suggest-ideas` handles consumption (discovering and recommending ideas).

The skill operates in two modes:

**Mode 1: Filter — from goal to existing ideas**
- Scans active goals and the ideas that serve them
- Ranks and categorizes ideas across multiple dimensions
- Presents a recommendation list for user selection

**Mode 2: Inspire — from goal to gaps**
- Reads a goal's Present State and Success criteria
- Compares against the coverage of existing ideas
- Identifies blank areas where no idea currently addresses the goal
- Suggests new idea directions to fill those gaps

## Motivation

1. **Solves the "where do I start" problem**: A user with 27 ideas and 1 goal needs navigation, not more production tools.
2. **Makes goals operational**: A goal in `goals/` is only useful if it helps filter and prioritize ideas. This skill makes that relationship explicit and actionable.
3. **Connects production and consumption**: `record-idea` creates; `suggest-ideas` discovers. Together they form a closed loop.
4. **Zero new data required**: The skill works by reading existing `goals/` and `ideas/` content. No new frontmatter fields or conventions are needed for the first version.

## Proposed Workflow

```
User triggers skill ("What should I work on?" / "Suggest ideas for this goal")
    │
    ▼
1. Scan goals/*/goal.md
   - List active goals
   - Let user select one (or default to a primary goal)
    │
    ▼
2. Read the selected goal.md
   - Extract What, Present State, Success, Path sections
    │
    ▼
3. Scan ideas/*.md
   - Read frontmatter or inline metadata
   - Read body content for keyword/context matching
    │
    ▼
4. Mode 1: Filter recommendations
   ├─ Dimension A: Status priority (New > Exploring > Accepted > ...)
   ├─ Dimension B: Goal binding (serves_goal matches the selected goal)
   ├─ Dimension C: Content overlap (idea description overlaps with goal keywords)
   └─ Dimension D: Recency (newer ideas may reflect more current thinking)
    │
    ▼
5. Mode 2: Gap discovery
   - Map goal's stated needs against ideas' described coverage
   - Flag areas where the goal mentions X but no idea addresses X
   - Suggest: "You may need an idea that covers..."
    │
    ▼
6. Present recommendation list
   ┌─────────────────────────────────────────────────────┐
   │  Based on goal: 「建设目标达成系统」                  │
   │                                                      │
   │  [High Priority | Existing Ideas]                    │
   │  1. idea-structured-frontmatter                      │
   │     Status: New | Rationale: Data layer foundation   │
   │                                                      │
   │  2. goal-aware-record-idea-skill                     │
   │     Status: New | Rationale: Low cost, high impact   │
   │                                                      │
   │  [To Explore | Blank Areas]                          │
   │  3. [Gap] Goal evaluation trigger mechanism          │
   │     Rationale: Goal mentions "on-demand evaluation"  │
   │                but no idea covers "who triggers it"  │
   └─────────────────────────────────────────────────────┘
```

## Signal Sources (First Version)

The first version has no dedicated structured signals. It reads and synthesizes:

| Source | What to read | How to use |
|--------|-------------|-----------|
| `goals/*/goal.md` | `# Heading`, `## Present State`, `## Success Looks Like`, `## Path` | Understand target direction and current gaps |
| `ideas/*.md` | Frontmatter (`status`, `serves_goal`, `date`) or inline metadata | Filter and rank |
| `ideas/*.md` | Body content (`# Idea: Title`, `## Description`, `## Motivation`) | Keyword overlap with goal |

Future versions can add structured signals (`tags`, `priority`, `effort`, `blocking`) as the mechanism evolves.

## Related Areas

- `.claude/skills/record-idea/SKILL.md` — the production counterpart
- `ideas/2026-05-15--goal-aware-record-idea-skill.md` — this skill's Mode 1 partially overlaps with goal-aware recording, but focuses on consumption rather than production
- `ideas/goals/goal-achievement-system/goal.md` — the first goal this skill should target for recommendations
- `ideas/2026-05-11--auto-generated-ideas-status-dashboard.md` — a passive overview; this skill is an active, interactive navigator

## Notes

- **Name alternatives**: `discover-ideas`, `explore-ideas`, `idea-compass`. `suggest-ideas` is chosen for clarity — it directly states what the skill does.
- **Trigger phrases**: "What should I work on?", "Suggest ideas", "What ideas serve this goal?", "Find gaps in our plan"
- **Graceful degradation**: If `goals/` does not exist, the skill falls back to scanning all ideas and ranking by status/recency.
- **Open question**: Should the skill also recommend *which goal* to focus on, if multiple active goals exist? Or should goal selection be strictly user-driven?
- **Implementation**: Implemented on 2026-05-16 as `.claude/skills/suggest-ideas/SKILL.md`. The skill follows the Agent-reasoning approach (not mechanical scoring), with sequential Mode 1 (recommend) → Mode 2 (gap discovery), parallel sub-agent reading for >10 ideas, and conversational output. See OpenSpec change `suggest-ideas-skill` (archived).
