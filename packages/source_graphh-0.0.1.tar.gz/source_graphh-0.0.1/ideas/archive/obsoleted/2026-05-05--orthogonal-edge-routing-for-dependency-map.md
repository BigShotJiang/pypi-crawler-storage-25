# Idea: Orthogonal Edge Routing for Dependency Map

**Date:** 2026-05-05
**Status:** Obsoleted
**Obsoleted By:** `add-cytoscape-graph-view` change (commit d1aab78)
**Reason:** The new Graph view uses Cytoscape.js with `curve-style: taxi`, which provides orthogonal (Manhattan-style) edge routing out of the box. The Map view's SVG-based diagonal routing is preserved as-is; there is no need to retrofit orthogonal routing onto it.
**Context:** First version of the dependency Map view uses straight diagonal lines for edges. The user observed that diagonal lines look visually cluttered and wants to explore orthogonal (elbow-style) edge routing.

## Description

Replace the current diagonal edge routing in the dependency Map view with orthogonal (Manhattan-style) routing. Edges should travel vertically and horizontally only, creating a cleaner circuit-board-like appearance with fewer visual crossings.

### Example / Use case

Current diagonal routing:

```
  cli.py ─────────╲
                   ╲
  import_extractor  ╲
                     ╲
  extractor.py ───────╲
                       ╲
  models.py ◄───────────╳
```

Proposed orthogonal routing:

```
  cli.py ─────┐
              │
  import_extractor
              │
  extractor.py┘──┐
                 │
  models.py ◄────┘
```

## Motivation

Diagonal lines crossing at arbitrary angles create visual noise and make it harder to trace dependency paths. Orthogonal routing:
- Reduces perceived clutter
- Makes edge tracing easier (follow horizontal/vertical lines)
- Is the industry standard for layered graph drawings (Sugiyama layout)
- Aligns with professional tools like Graphviz dot, Dagre, etc.

## Potential Implementation

### Approach 1: Simple Elbow (L-shape or Z-shape)

For each edge from source (top layer) to target (bottom layer):
1. Exit source node from bottom center
2. Travel vertically down to a shared "channel" at mid-height between layers
3. Travel horizontally to align with target node's top center
4. Travel vertically down to target node's top center

```
  src ──┐
        │
   ─────┼────  ← horizontal channel
        │
  tgt ──┘
```

### Approach 2: Port-based Routing

Assign connection ports to nodes (top/bottom/left/right). Route edges through a grid system, minimizing total wire length and crossings.

### Key Challenges

| Challenge | Potential Solution |
|-----------|-------------------|
| **Channel congestion** | Multiple edges sharing the same horizontal channel — use vertical offset staggering |
| **Crossing minimization** | Order nodes within each layer to minimize edge crossings (barycenter heuristic) |
| **Edge bundling** | Edges from the same source to different targets can share initial vertical segment |
| **SCC internal edges** | Edges within an SCC (currently not drawn externally) could be drawn as small orthogonal loops inside the group node |

## Related Areas

- `src/source_graph/presenter.py` — `renderDependencyMap` frontend function
- SVG `<polyline>` or `<path>` elements (replace current `<line>`)
- Layer spacing and node positioning calculations

## Notes

- The first version intentionally used diagonal lines for simplicity. Orthogonal routing is a natural next step once the layered layout stabilizes.
- Should be implemented as a pure frontend change (no backend data structure modifications needed).
- Consider whether to make this a toggle ("Diagonal" vs "Orthogonal") or simply replace diagonal entirely.
- Reference: Sugiyama, Tagawa, and Toda (1981) — Methods for Visual Understanding of Hierarchical System Structures.
