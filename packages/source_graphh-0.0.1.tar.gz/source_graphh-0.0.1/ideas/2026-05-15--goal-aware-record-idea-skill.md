---
date: "2026-05-15"
relations:
  - target: idea:2026-05-03--record-idea-skill
    relation: refines
    rationale: "Adds goal-context awareness to the basic record-idea skill, enabling goal-driven thinking at the point of idea creation."
---

# Idea: Goal-Aware Record-Idea Skill

**Date:** 2026-05-15
**Status:** New
**Context:** During the implementation of the `goals/` directory and the crystallization of the Pre-Idea Goal Alignment insight, it became clear that the current `record-idea` skill operates in a vacuum — it has no knowledge of active goals and therefore cannot support goal-driven thinking at the point of idea creation.

## Description

Upgrade the `record-idea` skill from a "file writer" to a "goal-context-aware recorder." When the skill is triggered, it first scans `ideas/goals/` for active goals and presents them to the user as context. The recording workflow gains an explicit alignment step before the idea is structured and written.

This is the minimal viable integration between the goal mechanism and the idea mechanism. No code changes are required — only modifications to the skill's workflow and prompt in `SKILL.md`.

### Proposed Workflow Change

Current workflow:
```
identify → scope → structure → write
```

Target workflow:
```
identify → scope → align → structure → write
```

The `align` step:
1. Scan `ideas/goals/*/goal.md` and extract the goal name from the first heading
2. Present active goals to the user
3. Ask: "Which goal (if any) does this idea serve?"
4. If a goal is selected, set `serves_goal: <goal-name>` in the frontmatter
5. If the user selects "none / not sure yet," proceed without binding

### Example / Use case

```
User: "We should add a hot-reload feature to serve mode"

Agent: [scans goals/]
       Active goals:
       1. goal-achievement-system — 建设目标达成系统
       2. [none / not sure yet]

       Which goal does this idea serve?

User: "None, this is about source-graph itself"

Agent: [records idea with serves_goal: null, or suggests creating a new goal]
```

## Motivation

1. **Makes goals operational, not decorative**: A goal in `goals/` that is never referenced during idea creation is just a document. This integration makes goals an active part of the creative process.
2. **Prevents retroactive justification**: By asking "which goal?" *before* the idea is structured, it prevents the common anti-pattern of forcing every idea to fit the current direction after the fact.
3. **Zero implementation cost**: No code, no scripts, no new dependencies. Only a skill prompt change.
4. **Foundation for richer integration**: Once the skill knows about goals, future extensions (alignment state tracking, goal dashboards, automatic idea clustering) become possible.

## Potential Implementation

1. **Update `SKILL.md` workflow section**
   - Add the `align` step between `scope` and `structure`
   - Include instructions for scanning `ideas/goals/*/goal.md`
   - Provide prompt text for the alignment question

2. **Update template**
   - Add optional `serves_goal:` field to the idea template
   - Default to empty if no goal is selected

3. **Graceful degradation**
   - If `ideas/goals/` does not exist or is empty, skip the `align` step silently
   - The skill continues to work exactly as before in projects without goals

## Related Areas

- `.claude/skills/record-idea/SKILL.md` — the skill definition to modify
- `ideas/2026-05-15--pre-idea-goal-alignment.md` — the alignment practice this skill enables
- `ideas/goals/goal-achievement-system/goal.md` — the first active goal the skill should detect
- `ideas/2026-05-12--record-idea-v2-lifecycle-management.md` — broader skill upgrade proposal that includes this capability

## Notes

- **This is a prompt engineering change, not a code change.** The skill uses existing filesystem tools (`ls`, `cat`) to discover goals. No new CLI commands or APIs are needed.
- **Goal discovery is heuristic**: The skill reads the first `# Heading` from each `goals/*/goal.md` to present a human-readable name. This is intentionally lightweight.
- **Future extension**: If `alignment:` frontmatter (relation + rationale) becomes standard, the `align` step can ask follow-up questions: "Is this idea aligned, divergent, or enriching to the goal?"
