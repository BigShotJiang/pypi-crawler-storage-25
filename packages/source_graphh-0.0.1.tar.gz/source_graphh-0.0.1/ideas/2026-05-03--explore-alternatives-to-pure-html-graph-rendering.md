---
date: "2026-05-03"
relations:
  - target: idea:2026-05-11--code-knowledge-graph-api
    relation: depends_on
    rationale: "Dynamic querying via API or WASM SQLite is a prerequisite before alternative renderers can justify their complexity."
---

# Idea: Explore Alternatives to Pure HTML Graph Rendering

**Date:** 2026-05-03
**Status:** New
**Context:** User raised concerns that the current pure-HTML rendering approach cannot directly query SQLite-stored node and relationship data, creating a hard ceiling on interactivity.

## Description

The `source-graph` project currently uses pure HTML to render knowledge-graph node relationships. While this guarantees portability and zero dependencies, it also creates a fundamental architectural boundary: the HTML frontend has no direct access to the SQLite database where nodes and relations are stored. Every query, filter, or interactive exploration must therefore be pre-baked into the generated HTML file, turning the visualization into a static snapshot.

This idea proposes evaluating alternative rendering stacks that bridge the gap between the SQLite data layer and the visual frontend, enabling dynamic, client-side querying and richer interactions without regenerating the entire output file.

### Example / Use case

A user clicks on a function node and wants to see only its immediate upstream callers. With pure HTML, this would require regenerating the file with a filtered dataset. A renderer with direct data access could execute the query client-side and redraw the view instantly.

## Motivation

1. **Interactivity ceiling**: Pre-generated HTML cannot support on-the-fly filtering, search, or drill-down without a full regeneration pass.
2. **Scalability**: As graphs grow, embedding all possible views in a single HTML file becomes unwieldy.
3. **Leverage stored data**: `RelationStore` already persists rich node and relation data in SQLite; the renderer should be able to tap into that structure rather than flattening it ahead of time.
4. **Future dimensions**: Once cross-file dependency extraction ([see related idea](2026-05-03--cross-file-import-dependency-extractor.md)) lands, users will want to toggle between structure and dependency views dynamically—something far more natural with a queryable frontend.

## Potential Implementation

Evaluate and prototype one or more of the following approaches:

1. **SVG + JavaScript + embedded JSON data**  
   Keep a self-contained HTML file but embed the full graph as a structured JSON/JavaScript payload. A small in-page JS engine can then query and filter the dataset locally without needing SQLite access. This is the lightest lift and preserves single-file distribution.

2. **SVG/Canvas with WASM SQLite (sql.js or DuckDB-WASM)**  
   Render using SVG or Canvas (e.g., D3.js, Cytoscape.js, or a custom Canvas renderer) and load the actual SQLite database via WebAssembly. This gives the frontend full SQL query power while keeping everything client-side and offline-capable.

3. **WebGL / Force-directed libraries**  
   Use a dedicated graph visualization library (e.g., Force Graph, Sigma.js) that consumes a JSON export but offers highly optimized rendering and interaction for larger graphs.

4. **Hybrid lightweight server**  
   If offline single-file distribution is relaxed, a minimal local HTTP server could serve both the SQLite file and a web UI, allowing the browser to fetch query results via a tiny REST or WebSocket API.

## Related Areas

- `src/source_graph/presenter.py` — current `HTMLPresenter` implementation
- `src/source_graph/store.py` — `RelationStore` SQLite schema and query interface
- `ideas/2026-05-03--cross-file-import-dependency-extractor.md` — discusses dimension switching in `HTMLPresenter`, which would benefit directly from a dynamic renderer

## Notes

- **Portability trade-off**: The chief advantage of pure HTML is zero dependencies and single-file offline viewing. Any alternative must either preserve that (options 1–2) or justify the added complexity (options 3–4).
- **Bundle size**: WASM SQLite engines add megabytes to the payload; measure whether the gain in query flexibility is worth the size cost.
- **Migration path**: Consider implementing option 1 (embedded JSON) as an incremental step. It requires no new technology and immediately unlocks client-side filtering, while leaving the door open to WASM SQLite later.
- **Open question**: Should the presenter layer be split into a `Renderer` ABC with multiple backends (`HTMLStaticRenderer`, `SVGJSRenderer`, etc.), or should the current `HTMLPresenter` simply grow a JS payload mode?
- **Architecture context:** This idea explores rendering *technology* alternatives (SVG, Canvas, WebGL, WASM). It is orthogonal to the architecture evolution tracked in `ideas/2026-05-12--source-graph-architecture-evolution-roadmap.md`, which focuses on separating data from presentation. Any rendering technology chosen here will benefit from that separation.
- **Prerequisite:** `ideas/2026-05-11--code-knowledge-graph-api.md` — dynamic querying (via API or WASM SQLite) is necessary before alternative renderers can justify their complexity. A static snapshot renderer doesn't need WebGL.
