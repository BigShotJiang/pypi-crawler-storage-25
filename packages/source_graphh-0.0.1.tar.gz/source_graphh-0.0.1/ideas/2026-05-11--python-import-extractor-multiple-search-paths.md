---
date: "2026-05-11"
relations: []
---

# Idea: Python Import Extractor with Multiple Search Paths

**Date:** 2026-05-11
**Status:** New
**Context:** Exploration of Phase 1 (Source Archive Layer) for the persistent symbol table architecture. The discussion confirmed that `PythonImportExtractor` requires `file_path` to resolve relative imports (e.g., `from . import foo`) using the file's location within the package. This sparked the realization that the extractor could be generalized to accept multiple source roots, enabling cross-directory and cross-project import resolution.

## Description

Enhance `PythonImportExtractor` to accept **multiple path parameters** (multiple search paths / source roots) rather than resolving imports solely within the single analyzed package. By matching import statements against a configurable set of directories or path prefixes, the extractor could resolve dependencies to third-party libraries, other local projects, or multiple source roots within a monorepo, producing a more complete and accurate dependency graph.

This directly leverages the existing need for `file_path` (package-relative resolution) and extends it into a broader capability: given a list of candidate roots, resolve `import requests` to the actual `requests/__init__.py` in `site-packages`, or `import other_project.foo` to the correct file in a sibling directory.

### Example / Use case

If the user passes both their project source directory **and** their `site-packages` directory as search paths:

```python
# my_project/api.py
import requests
from my_other_lib import utils
```

The extractor could resolve:
- `requests` → `/usr/lib/python3.x/site-packages/requests/__init__.py`
- `my_other_lib.utils` → `/path/to/other/src/my_other_lib/utils.py`

This creates dependency edges to actual files outside the primary source tree, rather than leaving these as unresolved external references.

## Motivation

1. **Complete dependency graphs**: Currently, imports outside the analyzed directory (stdlib, third-party, other projects) are either ignored or marked opaquely. Multi-path resolution makes the graph comprehensive.
2. **Monorepo support**: Projects with multiple source roots (e.g., `packages/a`, `packages/b`, `libs/shared`) need the ability to resolve imports across internal boundaries.
3. **Third-party visibility**: Understanding which specific versions of external libraries are used, and where they live on disk, adds valuable context to the knowledge base.
4. **Natural extension of existing logic**: The extractor already reasons about file system paths for relative imports. Extending this to a prioritized list of absolute roots is a small architectural leap with large capability gain.
5. **Aligns with Layer 1 (Source Archive)**: Once resolved, these external files could also be archived into `source_files`, making the database truly self-contained.

## Potential Implementation

1. **Extend extractor interface**:
   - Change `PythonImportExtractor.extract(content, file_path)` to accept an optional `search_paths: list[Path]` parameter.
   - Maintain backward compatibility: default to `[Path(file_path).parent]` (current behavior).

2. **Implement module-to-path resolution**:
   - For absolute imports (`import foo.bar`), iterate `search_paths` in order.
   - Attempt to locate `foo/bar.py` or `foo/bar/__init__.py` within each root.
   - Return the first match, or mark as unresolved.

3. **Relative import behavior**:
   - Relative imports (`from . import foo`) continue to resolve against `file_path`'s containing package, independent of `search_paths`.
   - Alternatively, `search_paths` could include the immediate package context implicitly.

4. **CLI integration**:
   - Add `--search-path` / `-I` flags to the CLI `extract` command (repeatable).
   - Automatically include the target directory and common virtual-environment `site-packages` if detected.

5. **Store integration**:
   - Resolved external files create `file` nodes and `file_imports_module` / `file_imports_symbol` relations just like internal files.
   - Optionally tag external nodes with `source="external"` or `source="stdlib"` for filtering.

## Related Areas

- `src/source_graph/python_import_extractor.py` — the extractor to enhance
- `ideas/2026-05-09--persistent-symbol-table-and-source-archive.md` — the broader architecture this idea extends; specifically Phase 1 (Source Archive Layer) and the insight that extractors should be content-driven but may need path context for resolution
- `ideas/2026-05-03--symbol-level-import-dependency-extraction.md` — related import-extraction enhancement; multi-path resolution makes symbol-level cross-project edges possible
- `src/source_graph/cli.py` — CLI argument parsing and search-path wiring
- `src/source_graph/store.py` — storage of resolved external file nodes and relations
- `ideas/2026-05-05--filter-external-modules-from-structure-dimension.md` — filtering external modules becomes more relevant once they are explicitly resolved

## Notes

- **Performance concern**: Searching across many large directories (e.g., all of `site-packages`) on every `import` statement could be slow. Consider caching a directory index or using `sys.path` meta-path hooks instead of naive filesystem walks.
- **Scope boundary**: The current discrete-file constraint still applies—external files would only be archived if explicitly included in the analysis set or if the user opts into archiving resolved dependencies.
- **Virtual environments**: Should the extractor auto-detect `venv` / `virtualenv` site-packages? Should it respect `PYTHONPATH`?
- **Overlap with `sys.path`**: Python's own import machinery already does this. Could the extractor leverage `importlib.util.find_spec(module_name)` safely in a sandboxed way, rather than reimplementing path resolution?
- **Follow-up**: This idea might later evolve into a configurable "resolver backend" abstraction, allowing pluggable strategies (filesystem, `sys.path`, Bazel build graph, etc.).
