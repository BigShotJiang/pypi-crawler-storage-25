---
date: "2026-05-11"
relations:
  - target: goal:goal-achievement-system
    relation: serves
    rationale: "Enables structured idea recording with type-specific templates for the goal achievement system."
---

# Idea: Record-Idea Template Variants by Idea Type

**Date:** 2026-05-11
**Status:** New
**Context:** After implementing Phase 1, we discussed improving the record-idea skill and the user asked for ideas.
**Serves:** [Goal Achievement System](2026-05-12--goal-achievement-system-the-ultimate-form-of-idea-mechanism.md)

## Description

The current `record-idea` skill uses a single generic template for all ideas (Description / Motivation / Potential Implementation / Notes). In practice, not all ideas fit this structure well.

### Example / Use case

- Architecture decisions need: Context / Decision / Consequences / Alternatives considered
- Bug patterns need: Symptom / Root cause / Fix approach / Prevention
- Experiments need: Hypothesis / Minimal experiment / Success criteria / Rollback plan
- Feature requests need: User story / Acceptance criteria / Dependencies / Effort estimate
- All of these are forced into the same generic template, producing awkward or sparse sections

## Motivation

Using one generic template for every kind of idea leads to poorly structured notes. Sections end up blank or shoehorned, which makes ideas harder to scan and act on later. Matching the template to the idea type would improve clarity and reduce friction when recording ideas.

## Potential Implementation

- Add an optional `--type` parameter to the `record-idea` skill (or let the user specify the type in conversation)
- Maintain multiple templates: `adr.md`, `bug-pattern.md`, `experiment.md`, `feature.md`, `generic.md`
- The subagent selects the appropriate template based on type, falling back to `generic.md`
- Templates are stored in `.claude/skills/record-idea/templates/`

## Related Areas

- `.claude/skills/record-idea/SKILL.md`
- `ideas/` directory

## Notes

- Should the type be inferred from keywords if the user does not specify it?
- Keep `generic.md` as the default so existing behavior is preserved.
- **Architecture context:** This idea is absorbed into the broader `record-idea` v2 upgrade proposed in `ideas/2026-05-12--record-idea-v2-lifecycle-management.md`. Template variants become Layer 1 of the three-layer upgrade (structured frontmatter + type-driven templates).
