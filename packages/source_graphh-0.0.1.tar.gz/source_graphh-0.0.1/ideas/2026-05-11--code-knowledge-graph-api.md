---
date: "2026-05-11"
relations:
  - target: goal:code-intuition
    relation: serves
    rationale: "Exposes the code knowledge graph as a queryable API, enabling dynamic access for code intuition."
---

# Idea: Code Knowledge Graph API

**Date:** 2026-05-11
**Status:** New
**Context:** The `source_graph.db` SQLite database now contains rich structured data: nodes, relations, source contents, and source paths. Currently, the only way to access this data is through the `present` subcommand (HTML report) or direct SQL. This idea proposes exposing the database as a queryable HTTP API, transforming source-graph from a "report generator" into a "code knowledge platform."

## Description

Add a `serve` subcommand that starts a lightweight HTTP server providing read-only access to the source graph database. This enables:
- IDEs and editors to query code structure on demand
- CI/CD pipelines to run automated architectural checks
- Web dashboards to visualize code evolution over time
- Team members to share and bookmark specific code relationships

### Proposed API Surface

```bash
# Start the server
source-graph serve source_graph.db --port 8080
```

**REST API endpoints:**

```
GET /api/nodes?kind=function&source_file=src/cli.py
→ [{"id": "...", "name": "extract_command", "kind": "function", "fqn": "...", ...}]

GET /api/nodes/{id}
→ Single node with full metadata and source snippet

GET /api/relations?source_id=abc123&dimension=structure
→ [{"id": "...", "source_id": "...", "target_id": "...", "type": "..."}]

GET /api/dependencies/{node_id}
→ Transitive dependency tree (upstream + downstream)

GET /api/search?q=foo&kind=function
→ Full-text search over node names and FQNs

GET /api/source/{content_id}
→ {"content": "import os\n...", "paths": ["src/a.py", "src/b.py"]}

GET /api/dimensions
→ ["structure", "dependencies"]
```

### Example Use Cases

**IDE Integration**
```bash
# VS Code extension calls:
curl http://localhost:8080/api/search?q=extract_command
→ Shows "extract_command is defined in src/cli.py:53, called by src/main.py:12"
```

**CI/CD Architectural Guard**
```yaml
# .github/workflows/arch-check.yml
- run: |
    source-graph serve source_graph.db --port 8080 &
    curl -s http://localhost:8080/api/dependencies/src/core.py \
      | jq '.downstream' \
      | grep -c "src/ui.py" \
      | xargs test {} -lt 5  # fail if core.py has >5 UI dependencies
```

**Shared Team Dashboard**
```html
<!-- Internal wiki embeds live graph -->
<iframe src="http://team-server:8080/view/structure?highlight=src/store.py">
```

## Motivation

1. **Database is the product**: With the Source Archive Layer complete, the SQLite database is a rich knowledge base. Currently it's trapped behind a static HTML report.
2. **Multiple consumers**: HTML reports are for humans. APIs are for tools — IDEs, CI, dashboards, documentation generators.
3. **Real-time querying**: HTML reports are snapshots. An API allows on-demand queries without regenerating output.
4. **Collaboration**: A team can run `serve` on a shared database, bookmark URLs to specific code relationships.
5. **Foundation for future layers**: The Symbol Table (Layer 2) and Semantic Resolution (Layer 3) will produce even richer queryable data. An API layer makes that data accessible.

## Potential Implementation

### Phase 1: Read-only HTTP server (MVP)

```python
# src/source_graph/server.py
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import sqlite3

class GraphAPIHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/api/nodes"):
            self._handle_nodes()
        elif self.path.startswith("/api/relations"):
            self._handle_relations()
        # ... etc

    def _handle_nodes(self):
        # Parse query params, query SQLite, return JSON
        ...
```

Use Python stdlib `http.server` for zero-dependency MVP. Later can migrate to `uvicorn` + `fastapi` for async and auto-generated OpenAPI docs.

### Phase 2: Web UI (dynamic viewer)

Reuse the HTML/JS frontend from the presenter, but have it fetch data from `/api/*` endpoints instead of reading embedded JSON. Same UI, dynamic data.

```html
<!-- Dynamic mode -->
<script>
fetch('/api/dimensions')
  .then(r => r.json())
  .then(dims => renderSelector(dims));

fetch('/api/nodes?dimension=structure')
  .then(r => r.json())
  .then(nodes => renderTree(nodes));
</script>
```

### Phase 3: GraphQL or structured query language

REST endpoints are fine for known queries, but code exploration is ad-hoc. Consider adding:

```graphql
# POST /graphql
{
  node(fqn: "src/cli.py/extract_command") {
    name
    source_content {
      content
      snippet(start_line: 53, end_line: 88)
    }
    callers {
      name
      source_file
    }
  }
}
```

Or a simpler text-based query DSL:
```bash
source-graph query source_graph.db "functions named foo in src/cli.py"
```

## Related Areas

- `src/source_graph/store.py` — SQLite schema and query interface
- `src/source_graph/presenter.py` — HTML frontend (can be reused for dynamic web UI)
- `openspec/changes/add-source-archive-layer/` — established the database foundation
- `ideas/2026-05-09--persistent-symbol-table-and-source-archive.md` — Layer 2-4 will produce the richest API data
- `ideas/2026-05-11--presenter-template-separation.md` — frontend template separation makes dynamic mode easier

## Notes

- **Read-only first**: Write operations (live editing) are out of scope. The API is a lens, not an editor.
- **SQLite concurrency**: SQLite handles multiple readers well with WAL mode. For high-traffic, consider read replicas or migrating to Postgres.
- **Authentication**: Not needed for local CLI usage. For shared servers, add `--token` flag or reverse proxy auth.
- **OpenAPI**: If using FastAPI, API docs are automatic. If using stdlib, consider generating `openapi.yaml` manually.
- **Bundle size**: The dynamic web UI should be a single `.html` file that loads JS from CDN or embedded data URI, preserving the "zero dependencies, single file" philosophy where possible.
- **Architecture context:** This idea is Step 3 in the evolution roadmap (`ideas/2026-05-12--source-graph-architecture-evolution-roadmap.md`). The `serve` command (`openspec/changes/archive/2026-05-12-add-serve-command/`) is the intentional MVP foundation: it proves the "db → HTTP" loop with zero frontend changes. This idea evolves that same server into a full API + dynamic SPA.
- **Prerequisite:** `ideas/2026-05-11--presenter-template-separation.md` — having JS/CSS as independent files makes the frontend → API transition much cleaner (the same `app.js` just swaps its data source from embedded JSON to `fetch`).
- **MVP path:** Serve mode starts with SSR (`presenter.render()` per request). API mode adds `/api/*` routes and converts the frontend to fetch-on-load. Both coexist in the same `server.py`.
