---
date: "2026-05-19"
relations:
- target: "goal:code-intuition"
  relation: "serves"
  rationale: "Removes a common friction point in local development workflow."
---

**Status:** New
**Context:** During `replace-presenter-with-fastapi-serve` testing, `run-self-analysis.sh` failed with `Errno 48: address already in use` because a previous `serve` process was still holding port 8080. Manual `pkill` was required to free the port.

## Description

Eliminate hard-coded ports in development scripts. Use dynamic port allocation so multiple instances or parallel tests can coexist without conflict.

### Current Problem

```bash
# scripts/run-self-analysis.sh
python3 -m source_graph.cli serve ... --port 8080   # ← hard-coded

# scripts/test-serve.sh
$PYTHON -m source_graph.cli serve ... --port 18080   # ← hard-coded
```

**Pain points**:
- Port 8080 frequently occupied by other services or zombie processes
- Cannot run `test-serve.sh` and `run-self-analysis.sh` simultaneously
- CI environments may have arbitrary ports already taken

### Proposed Solution

**Option A: Random available port (recommended)**

```bash
find_free_port() {
    python3 -c "import socket; s=socket.socket(); s.bind(('',0)); print(s.getsockname()[1]); s.close()"
}

PORT=$(find_free_port)
$PYTHON -m source_graph.cli serve ... --port "$PORT"
echo "Server running on http://127.0.0.1:$PORT"
```

**Option B: Serve supports `--port 0`**

Modify `serve` command to accept `--port 0`, which tells the OS to assign an available port. The actual port is then printed to stdout:

```
$ source-graph serve db --port 0
Server running on http://127.0.0.1:49231
```

**Option C: Environment variable override**

```bash
PORT=${SOURCE_GRAPH_PORT:-8080}
source-graph serve db --port "$PORT"
```

This allows CI or developers to set `SOURCE_GRAPH_PORT=0` for random allocation.

### Recommendation

Combine **Option A** (random port for scripts) with **Option C** (environment override for flexibility):

```bash
# scripts/.common.sh
resolve_port() {
    if [ -n "${SOURCE_GRAPH_PORT:-}" ]; then
        echo "$SOURCE_GRAPH_PORT"
    else
        python3 -c "import socket; s=socket.socket(); s.bind(('',0)); print(s.getsockname()[1]); s.close()"
    fi
}
```

## Motivation

1. **Eliminate port conflicts**: No more "address already in use" errors
2. **Parallel testing**: Multiple test suites can run serve simultaneously
3. **CI reliability**: Tests don't fail due to port contention

## Related Areas

- `scripts/run-self-analysis.sh`
- `scripts/test-serve.sh`
- `src/source_graph/cli.py` (serve command argument parsing)
- `src/source_graph/server/config.py` (port configuration)
