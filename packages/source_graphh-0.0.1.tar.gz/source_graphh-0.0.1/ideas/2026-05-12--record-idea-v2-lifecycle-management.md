---
date: "2026-05-12"
relations:
  - target: goal:goal-achievement-system
    relation: serves
    rationale: "Upgrades idea recording from a file writer to a lifecycle management infrastructure for the goal achievement system."
  - target: idea:2026-05-03--record-idea-skill
    relation: refines
    rationale: "Evolves the basic record-idea skill into a full lifecycle OS with append, update, and link operations."
---

# Idea: Record-Idea v2 — From File Writer to Idea Lifecycle OS

**Date:** 2026-05-12
**Status:** New
**Context:** After completing the `add-serve-command` change (explore → propose → implement → archive → update ideas), the agent experienced the full lifecycle of an idea and identified systemic friction in how ideas are recorded, evolved, and linked to implementation.
**Serves:** [Goal Achievement System](2026-05-12--goal-achievement-system-the-ultimate-form-of-idea-mechanism.md)

## Description

The current `record-idea` skill is a "write markdown file" tool. It creates a snapshot of a conversation and saves it to `ideas/`. This works for capturing initial thoughts, but it breaks down when ideas evolve across multiple conversations, get promoted to changes, are implemented, and need their status synchronized with the OpenSpec workflow.

This idea proposes upgrading `record-idea` from a **file writer** to an **idea lifecycle management infrastructure** — a system that tracks an idea from birth (recorded in conversation) through evolution (appended decisions, status changes) to death or graduation (implemented as a change, declined, or merged into another idea).

## Real Pain Points from Actual Usage

### Pain 1: Template flattens structured thinking

The `architecture-evolution-roadmap` idea (created during the serve-mode discussion) was forced into the generic Description/Motivation/Potential Implementation/Notes template. Its actual value was in **structured decisions** (evolution sequence, cross-reference matrix, decision log). The template turned these into prose, making them harder to scan and update.

### Pain 2: Multi-conversation ideas cannot be appended

`unified-report-rendering-validation` was created on 2026-05-11. On 2026-05-12, the conversation produced a critical new judgment ("Playwright is important-not-urgent; serve mode takes priority"). This judgment should have been appended to the original idea's decision log. Instead, it was scattered into a new roadmap idea and change artifacts. The original idea became stale.

### Pain 3: Cross-references are manual toil

After `add-serve-command` was archived, 5 idea files needed their `openspec/changes/add-serve-command/` links manually updated to `openspec/changes/archive/2026-05-12-add-serve-command/`. This was error-prone, easy to miss, and created broken links.

### Pain 4: Status is a static label, not a lifecycle

The roadmap idea marked Step 1 as "Current Priority." After implementation, it was manually changed to "Completed ✓." Meanwhile, the original `unified-report-rendering-validation` idea still says `Status: New` despite having been deeply explored and deprioritized. The idea's `Status` field and the OpenSpec change's `isComplete` field are two disconnected worlds.

## The Three-Layer Upgrade

```
Current:  record-idea = "write markdown file"
                    ↓
Target:   record-idea = "idea lifecycle management infrastructure"

┌─────────────────────────────────────────────────────────────────┐
│  Layer 3: Presentation                                          │
│  ─────────────────────                                          │
│  • Auto-generated dashboard (ideas/README.md)                   │
│  • Reference graph (ideas/REFERENCE-GRAPH.md)                   │
│  • Query: "show me all New ideas about serve-mode"              │
├─────────────────────────────────────────────────────────────────┤
│  Layer 2: Workflow                                              │
│  ────────────────                                               │
│  • Create  → write new idea file                                │
│  • Append  → add to existing idea (decisions, new context)      │
│  • Link    → connect idea ↔ change, idea ↔ idea                 │
│  • Update  → change status, reflect implementation progress     │
│  • Query   → find ideas by tag, status, type, related change    │
├─────────────────────────────────────────────────────────────────┤
│  Layer 1: Data                                                  │
│  ─────────                                                      │
│  • Structured YAML frontmatter (type, status, decisions, etc.)  │
│  • Stable identifiers for cross-references (not file paths)     │
│  • Template variants per idea type (roadmap, adr, bug, feature) │
└─────────────────────────────────────────────────────────────────┘
```

## Key Improvements

### 1. Structured Frontmatter (Layer 1)

Replace inline metadata with YAML frontmatter:

```yaml
---
title: "Source Graph Architecture Evolution Roadmap"
date: 2026-05-12
status: active-roadmap
type: roadmap
context: "Exploration of unified-report-rendering-validation revealed..."
related_ideas:
  - 2026-05-11--unified-report-rendering-validation
  - 2026-05-11--presenter-template-separation
related_changes:
  - add-serve-command          # ← stable identifier, not path!
tags: [architecture, roadmap, serve-mode]
decisions:
  - date: 2026-05-12
    decision: "Serve MVP uses SSR, not API+SPA"
    rationale: "Zero frontend changes, lowest risk"
---
```

**Why this unlocks everything**:
- `type: roadmap` → skill auto-selects `templates/roadmap.md`
- `related_changes: [add-serve-command]` → archive skill resolves to current path dynamically
- `decisions:` → append operations target a structured array, not prose
- Dashboard generator parses YAML, not regex

### 2. Lifecycle Operations (Layer 2)

The skill should support operations beyond "Create":

| Operation | Trigger | Action |
|-----------|---------|--------|
| **Create** | "record this idea" | Write new file with selected template |
| **Append** | "add to the serve-mode idea" | Find file, append to `decisions:` or `## Notes` |
| **Update Status** | "mark X as implemented" | Update `status:` frontmatter |
| **Link** | "link this idea to change Y" | Add to `related_changes:` |
| **Query** | "what ideas are about serve?" | Search frontmatter tags/titles |

**Append is the most undervalued capability.** Conversations rarely produce a complete idea in one shot. Being able to say *"append to idea X: we decided Y"* prevents idea staleness.

### 3. Stable Identifiers (Layer 1 + 2)

Use change **names** instead of file paths in cross-references:

```yaml
related_changes:
  - add-serve-command
```

A resolver script (`scripts/resolve-idea-links.py`) maps names to current paths at render time:
- Active: `openspec/changes/add-serve-command/`
- Archived: `openspec/changes/archive/2026-05-12-add-serve-command/`

This eliminates the manual path-fixing toil that happened today.

### 4. Template Variants (Layer 1)

Match template to idea type:

| Type | Template Focus | Sections |
|------|---------------|----------|
| `generic` | Catch-all | Description / Motivation / Implementation / Notes |
| `roadmap` | Evolution planning | Sequence / Decision Log / Cross-Reference Matrix |
| `adr` | Architecture decision | Context / Decision / Consequences / Alternatives |
| `bug-pattern` | Recurring issue | Symptom / Root Cause / Fix / Prevention |
| `experiment` | Spike/POC | Hypothesis / Method / Success Criteria / Rollback |
| `feature` | User-facing capability | User Story / Acceptance Criteria / Dependencies |

The skill infers type from keywords or asks the user. `generic` remains the default.

## Relationship to Existing Ideas

This idea is a **meta-upgrade** that enables and simplifies the following existing ideas:

- `ideas/2026-05-11--record-idea-template-variants.md` → **Absorbed** into Layer 1 (type-driven templates)
- `ideas/2026-05-11--bidirectional-idea-change-linking.md` → **Enabled** by Layer 1 (`related_changes` frontmatter) and Layer 2 (Link operation)
- `ideas/2026-05-11--auto-generated-ideas-status-dashboard.md` → **Simplified** by Layer 1 (dashboard parses YAML frontmatter instead of regex)
- `ideas/2026-05-11--auto-generated-ideas-reference-graph.md` → **Simplified** by Layer 1 (`related_ideas` gives edges directly)

## Potential Implementation

### Phase 1: Frontmatter migration ✅ Completed

**Implemented by:** `openspec/changes/archive/2026-05-18-add-gas-frontmatter-cli/`

1. ~~Update `record-idea/SKILL.md` template to use YAML frontmatter~~ → Done via `gas write` CLI
2. ~~Add `type` field with inference logic~~ → Deferred: minimal schema (`date` + `relations`) chosen over full v2 schema
3. ~~Migrate existing ideas (batch script: extract inline metadata → YAML)~~ → Done: all 29 ideas + 2 goals migrated

**Note:** The `gas` CLI generates a minimal frontmatter schema (`date`, `relations`) rather than the full v2 schema (`type`, `status`, `decisions`, `tags`, etc.). The remaining v2 frontmatter fields are unimplemented.

### Phase 2: Append operation

1. Add "append to idea" workflow to skill
2. Support appending to `decisions:`, `notes:`, or arbitrary sections
3. Validate that target idea exists

### Phase 3: Stable identifier resolver

1. `scripts/resolve-idea-links.py` — maps `change: <name>` to current path
2. Update `openspec-archive-change` skill to run resolver after archive
3. Dashboard generator uses resolver for clickable links

### Phase 4: Dashboard & graph generator

1. `scripts/generate-ideas-dashboard.py` — reads YAML frontmatter, writes `ideas/README.md`
2. `scripts/generate-ideas-graph.py` — reads `related_ideas`/`related_changes`, produces `ideas/REFERENCE-GRAPH.md`

## Notes

- **Migration path**: Existing ideas with inline metadata can be batch-converted. The script should preserve all content while moving `Date`, `Status`, `Context` into frontmatter.
- **Backward compatibility**: Ideas without frontmatter should still be readable by dashboard generators (fallback to current regex parsing during transition).
- **Open question**: Should `decisions:` live in frontmatter (structured, queryable) or in the markdown body (more narrative, easier to read)? Suggestion: frontmatter for machine consumption, body for human narrative. Or both — frontmatter for the index, body for the story.
- **Open question**: How does the Append operation handle conflicting judgments? If a later conversation reverses an earlier decision, should it overwrite or add a new decision entry with a "supersedes" field?
