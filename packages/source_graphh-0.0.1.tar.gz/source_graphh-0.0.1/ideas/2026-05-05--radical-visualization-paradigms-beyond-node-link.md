---
date: "2026-05-05"
relations:
  - target: goal:code-intuition
    relation: serves
    rationale: "Provides alternative visualization paradigms (matrix, terrain, Sankey) to establish different types of code intuition."
---

# Idea: Radical Visualization Paradigms Beyond Node-Link Diagrams

**Date:** 2026-05-05
**Status:** New
**Context:** User asked for more radical and intuitive visualization approaches beyond the current Tree/Map/Graph views.

## Description

The `source-graph` project currently visualizes code structure and dependencies through conventional node-link diagrams (Tree view, Map view, Graph view). While effective, these all share the same fundamental paradigm: nodes as shapes and relationships as connecting lines. This idea proposes five alternative visualization paradigms that completely break away from node-link diagrams, leveraging other human perceptual channels (spatial density, flow, terrain, depth, even sound) to reveal architectural patterns.

### Five Proposed Paradigms

1. **Dependency Matrix Heatmap (Adjacency Matrix)** — Completely abandons node-link, using color density in a grid. Rows/columns are modules; cell color = dependency strength. Instantly reveals circular dependencies (symmetric blocks), hubs (bright rows/columns), and islands (dark rows/columns). Implementable with pure HTML/CSS Grid or D3.js. Limit: >50 nodes needs interactive zoom/filtering.

2. **Code Terrain / Dependency Landscape** — Maps dependency density to elevation. High-coupled modules = mountains, low-coupled = plains, dependency direction = rivers/slopes. Leverages the human brain's powerful terrain processing ability. Implementation: Canvas/WebGL (three.js or d3-contour), using graph coordinates as terrain base. Height = in-degree + out-degree.

3. **Sankey Diagram** — Flow perspective. Line width = dependency count/weight. Reveals the "arteries" of architecture and anti-patterns. Implementation: D3-sankey, aggregating graph data by directory/module level.

4. **3D Force-Directed Graph** — Depth encodes layer/SCC nesting. Rotatable perspective reveals hidden crossings. Implementation: three.js + force-graph 3D. Risk: may be gimmicky unless depth encodes real structural value.

5. **Sonification** — Most radical, breaks the visual channel entirely. Circular dependencies = dissonant chords, deep call chains = descending scales, isolated modules = silence, high-coupled centers = drone bass, new dependencies = bell sounds, deleted = decaying reverb. Implementation: Web Audio API. Learning curve: need to define an "auditory language of code."

### Example / Use case

A developer opens a large legacy codebase and wants to understand coupling patterns at a glance. The Dependency Matrix Heatmap immediately shows a bright 4×4 symmetric block — four modules tightly circularly dependent. Switching to the Sankey view reveals that 60% of all architectural flow passes through a single module, identifying a bottleneck. The Terrain view confirms this module as a "mountain peak" surrounded by sloping dependencies.

## Motivation

1. **Cognitive overload**: Node-link diagrams become unreadable beyond ~50 nodes due to edge crossing and layout instability.
2. **Pattern invisibility**: Circular dependencies, hub modules, and architectural layers are hard to spot when scattered across a force-directed layout.
3. **Untapped perceptual channels**: The brain processes matrices, terrain, flow, and sound with specialized circuitry — these can encode information more efficiently than spatial node placement alone.
4. **Complementary questions**: Different paradigms answer different questions. Heatmaps answer "how strong is coupling?" Sankey answers "where is architectural flow?" Terrain answers "where are the centers of gravity?"

## Potential Implementation

**Primary recommendation:**
- **Dependency Matrix Heatmap + Sankey Diagram** (module aggregation layer). Both are completely different paradigms with no complex layout algorithms needed. They answer complementary questions and are implementable with mature libraries (D3.js, D3-sankey, or even pure HTML/CSS for the matrix).

**Secondary recommendation:**
- **Code Terrain**. Use three.js to elevate Graph view coordinates into height. Can be added as a "3D Terrain" toggle to the existing Graph view with minimal architectural change.

**Deferred / experimental:**
- **3D Force-Directed Graph** — only if depth can encode a real structural dimension (e.g., SCC nesting depth, directory depth).
- **Sonification** — most radical, requires defining a full "auditory language of code" and likely suits a standalone experimental demo first.

## Related Areas

- `src/source_graph/presenter.py` — current `HTMLPresenter` implementation; new paradigms may need new presenter methods or a renderer plugin system
- `src/source_graph/store.py` — `RelationStore` SQLite schema; matrix and Sankey views need aggregated dependency counts
- `ideas/2026-05-03--explore-alternatives-to-pure-html-graph-rendering.md` — related but orthogonal: that idea explores alternative *rendering stacks* (HTML vs SVG/Canvas/WebGL/WASM) to solve data-access and interactivity limits, while this idea explores alternative *visual paradigms* (matrix, terrain, flow, sound) that could be implemented on any rendering stack

## Notes

- **Scalability**: The heatmap approach scales poorly beyond ~50 nodes without interactive zoom/filtering; consider directory-level aggregation.
- **Aggregation layer**: Sankey and Terrain both benefit from aggregating raw file-level dependencies up to module/directory level first.
- **3D risk**: Without depth encoding real data, 3D force-directed graphs often become gimmicks. Ensure depth = a real metric (e.g., cyclic dependency depth, directory depth, or centrality).
- **Sonification language**: Sonification is only useful if the mapping from code properties to sound is consistent and learnable. Consider starting with a simple mapping (isolation = silence, coupling = drone pitch) and expanding iteratively.
- **Open question**: Should these new paradigms live as toggles within the existing HTML output, or as separate output modes (`--format matrix`, `--format sankey`, etc.)?
- **Open question**: Can the current `RelationStore` schema efficiently serve aggregated adjacency matrix and flow data, or does it need pre-computed summary tables?
