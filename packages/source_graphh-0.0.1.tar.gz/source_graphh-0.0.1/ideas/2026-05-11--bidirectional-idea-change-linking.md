---
date: "2026-05-11"
relations:
  - target: goal:goal-achievement-system
    relation: serves
    rationale: "Links ideas to implementation changes for traceability within the goal achievement system."
---

# Idea: Bidirectional Idea-Change Linking in OpenSpec Workflow

**Date:** 2026-05-11
**Status:** New
**Context:** After implementing Phase 1, we discussed improving the record-idea skill and the user asked for ideas.
**Serves:** [Goal Achievement System](2026-05-12--goal-achievement-system-the-ultimate-form-of-idea-mechanism.md)

## Description

Currently, ideas reference changes via hardcoded markdown links (`[change](../openspec/changes/add-source-archive-layer/)`). When a change is archived, the path changes and all references become stale (the user had to manually fix this today).

### Example / Use case

- An idea links to an in-progress change using a relative filesystem path.
- The change is archived and moved to `openspec/changes/archive/`.
- The idea's link is now broken.
- The user must manually find and update every referencing idea.

## Motivation

The relationship between ideas and changes is important for traceability, but it is currently implicit and manual. Stale links break that traceability and create maintenance toil every time a change is archived. Making the linking bidirectional and stable would let us query dependencies and keep status in sync automatically.

## Potential Implementation

- Use stable identifiers instead of paths: `change: add-source-archive-layer` in idea frontmatter
- Add an `ideas/` scanning step to `openspec-archive-change` skill: find all ideas referencing the archived change and update their links
- Add automatic status backflow: when a change completes, update the linked idea's status (e.g., "Phase 1 Completed")
- Future: index ideas into the source-graph database itself, creating `idea → references → change` relations queryable like code relations

## Related Areas

- `.claude/skills/record-idea/SKILL.md`
- `.claude/skills/openspec-archive-change/SKILL.md`
- `ideas/2026-05-09--persistent-symbol-table-and-source-archive.md` (the user had to manually update this today)

## Notes

- Stable identifiers could be YAML frontmatter keys or a lightweight link syntax.
- Backflow should probably be opt-in per idea to avoid unexpected edits.
- **Architecture context:** This idea is enabled by the `record-idea` v2 upgrade in `ideas/2026-05-12--record-idea-v2-lifecycle-management.md`. The structured frontmatter (`related_changes:`) and stable identifier resolver in v2 provide the data foundation that makes bidirectional linking automatic rather than manual.
