---
date: "2026-05-05"
relations: []
---

# Idea: File directory tree view

**Date:** 2026-05-05
**Status:** New
**Context:** User wants a "file map" or directory tree view showing the project's physical file organization.

## Description

Add a new visualization mode that displays the project's physical directory structure rather than code-level structure (classes/methods) or import dependencies. This "file map" view would group files by their directory path, providing a familiar explorer-like layout.

### Example / Use case

```
📁 src/
  └── 📁 source_graph/
      ├── 📄 __init__.py
      ├── 📄 cli.py
      ├── 📄 models.py
      └── 📄 store.py
📁 tests/
  ├── 📄 test_presenter.py
  └── 📄 test_store.py
```

This view helps users quickly locate files and understand the project's physical layout, complementing the existing semantic and hierarchical views.

## Motivation

The existing dimensions serve different purposes:
- `dependencies` dimension: shows "who imports who" (semantic coupling)
- `structure` dimension: shows "file contains class contains method" (code hierarchy)

Neither shows the physical file organization. A directory tree view fills this gap and is often the first mental model developers use when navigating a codebase.

## Potential Implementation

Two approaches were discussed:

1. **Add a new "files" dimension**: Build a tree from `source_file` paths, grouping nodes by directory. Each directory becomes a branch node; each file becomes a leaf.
2. **Toggle in `structure` dimension**: Add a switch within the existing `structure` dimension to toggle between "code details" (current behavior) and "file map" (directory-only view).

## Related Areas

- HTML report generation / presenter
- `structure` dimension logic
- Tree-building / `_build_tree_data`
- `source_file` path handling in store or models

## Notes

- If implemented as a new dimension, consider how it interacts with filtering and search.
- If implemented as a toggle, ensure state is preserved when switching views.
- Open question: should the file map still allow expanding into code-level detail, or remain strictly physical?
