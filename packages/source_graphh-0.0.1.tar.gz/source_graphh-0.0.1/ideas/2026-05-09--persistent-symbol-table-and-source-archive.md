---
date: "2026-05-09"
relations:
  - target: goal:code-intuition
    relation: serves
    rationale: "Provides the persistent semantic foundation for symbol-level code intuition."
---

# Idea: Persistent Symbol Table and Source Archive as Semantic Foundation

**Date:** 2026-05-09
**Status:** Phase 1 Completed, Phase 2+ Not Started
**Context:** Deepening exploration of `2026-05-03--symbol-level-import-dependency-extraction.md`. The discussion revealed that symbol-level import extraction is not merely a feature addition, but a stepping stone toward a broader capability: self-hosted semantic analysis for discrete file inputs. Two critical architectural insights emerged: (1) the symbol table must be persisted to the database, not treated as a transient compiler artifact, and (2) original source files must be archived after analysis, as they are currently discarded and lost.

**Completed Change:** Phase 1 (Source Archive Layer) was implemented in [`openspec/changes/archive/2026-05-11-add-source-archive-layer`](../openspec/changes/archive/2026-05-11-add-source-archive-layer/).

## Description

Transform `source-graph` from a "disposable analysis pipeline" into a "code knowledge base" by introducing two foundational infrastructure layers:

1. **Source Archive Layer (Layer 1)**: Persist the full content of analyzed source files into the SQLite database. This establishes the database as the single source of truth for all downstream analysis, eliminating dependency on the original files remaining at their disk paths.

2. **Persistent Symbol Table Layer (Layer 2)**: Design and implement a database-backed symbol namespace system that records, for every analyzed file: (a) what symbols are defined within it, and (b) what names are bound to what entities within each scope. This symbol table becomes the core infrastructure enabling semantic resolution (Layer 3) and precise dependency queries (Layer 4).

This idea re-frames the earlier "symbol-level import dependency extraction" from a standalone feature into a data-population strategy for the `bindings` table within the symbol table.

## Core Insights from Exploration

### Insight 1: The symbol table is a product asset, not a compiler artifact

In traditional compilers, the symbol table is an in-memory intermediate structure discarded after code generation. For `source-graph`, the symbol table *is* the product — it is the persistent representation of "understanding" about the codebase. It must be queryable, durable, and evolvable.

### Insight 2: Discarding source files after analysis is an architectural defect

The current pipeline reads files once, extracts AST-derived nodes/relations, and discards the original content. This creates several problems:

- **Incremental updates impossible**: Cannot detect which files changed without re-reading from disk.
- **Source context lost**: Visualization cannot show source snippets or precise line content.
- **Secondary analysis blocked**: Adding new extractors later requires re-reading disk files, which may have moved or changed.
- **Offline fragility**: The database becomes an "orphan" if source files are relocated.

### Insight 3: Symbol-level import extraction is a data-population strategy, not a feature

The earlier idea of extracting `file_imports_symbol` relations should be understood as: **populating the `bindings` table with `binding_type = 'import_from'` records**. It is one of several data sources feeding the symbol table, alongside definition extraction (`binding_type = 'definition'`), assignments, parameter bindings, etc.

## Proposed Four-Layer Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│  Layer 4: Application (Queries & Visualization)                     │
│  ─────────────────────────────────────────────────────────────────  │
│  "Who depends on MyClass?" / "Show the inheritance chain of Foo"   │
│                                                                     │
│  Input: Resolved symbol references from Layer 3                     │
└─────────────────────────────────────────────────────────────────────┘
                              ▲
                              │ aggregate queries
┌─────────────────────────────────────────────────────────────────────┐
│  Layer 3: Semantic Resolution                                       │
│  ─────────────────────────────────────────────────────────────────  │
│  Scan use-sites (function calls, attribute access, type annotations,│
│  inheritance, decorators) and resolve each to a fully-qualified     │
│  symbol using the symbol table from Layer 2.                        │
│                                                                     │
│  Input: Symbol namespace (Layer 2) + source content (Layer 1)       │
│  Output: `symbol_references` table                                  │
└─────────────────────────────────────────────────────────────────────┘
                              ▲
                              │ name resolution
┌─────────────────────────────────────────────────────────────────────┐
│  Layer 2: Symbol Table                                              │
│  ─────────────────────────────────────────────────────────────────  │
│                                                                     │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐             │
│  │   symbols   │    │  bindings   │    │   scopes    │             │
│  │  (definitions)│   │(name→entity │    │ (hierarchy) │             │
│  └─────────────┘    └─────────────┘    └─────────────┘             │
│                                                                     │
│  Answers: "In this scope, what does name X resolve to?"             │
│                                                                     │
│  Input: AST extraction results from Layer 1                         │
└─────────────────────────────────────────────────────────────────────┘
                              ▲
                              │ AST traversal
┌─────────────────────────────────────────────────────────────────────┐
│  Layer 1: Source Archive + Extraction                               │
│  ─────────────────────────────────────────────────────────────────  │
│                                                                     │
│  ┌─────────────────────┐    ┌─────────────────────────────────┐    │
│  │    source_files     │    │        Extractors               │    │
│  │    (archived)       │    │  • StructureExtractor           │    │
│  │                     │    │  • ImportExtractor              │    │
│  │  • full content     │    │  • (future) TypeExtractor       │    │
│  │  • content_hash     │    │  • (future) ReferenceExtractor  │    │
│  │  • last_modified    │    │                                 │    │
│  └─────────────────────┘    └─────────────────────────────────┘    │
│                                                                     │
│  The ground truth. All analysis reads from here, not disk.          │
└─────────────────────────────────────────────────────────────────────┘
```

## Proposed Database Schema

### source_files — The Archive

```sql
CREATE TABLE source_files (
    id TEXT PRIMARY KEY,              -- matches file node id
    path TEXT NOT NULL,               -- original path at analysis time
    content TEXT NOT NULL,            -- full source content
    content_hash TEXT NOT NULL,       -- SHA-256 for incremental change detection
    file_size INTEGER,
    last_modified REAL,               -- os.path.getmtime
    language TEXT DEFAULT 'python',
    analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### symbols — The Definition Catalog

```sql
CREATE TABLE symbols (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,               -- local name: MyClass
    fqn TEXT NOT NULL UNIQUE,         -- fully qualified: utils.MyClass
    kind TEXT NOT NULL,               -- class | function | method | variable | module | parameter

    source_file TEXT NOT NULL,
    start_line INTEGER,
    start_col INTEGER,
    end_line INTEGER,
    end_col INTEGER,

    parent_symbol_id TEXT,            -- hierarchical containment
    is_exported BOOLEAN DEFAULT 1,    -- visible to external importers?

    properties TEXT                   -- JSON: decorators, base_classes, parameters, etc.
);
```

### bindings — The Name Resolution Core

The most critical table. Records every name→entity mapping in every scope.

```sql
CREATE TABLE bindings (
    id TEXT PRIMARY KEY,
    scope_symbol_id TEXT NOT NULL,    -- the scope where binding exists (usually a module)
    local_name TEXT NOT NULL,         -- the name used in code: MyClass or MC (as-alias)
    bound_to_fqn TEXT,                -- resolved entity FQN (NULL if unresolved)
    binding_type TEXT NOT NULL,       -- definition | import | import_from | assignment | parameter | for_target

    -- Source location of the binding statement
    source_file TEXT NOT NULL,
    line INTEGER,
    col INTEGER,

    -- For import bindings
    imported_from_module TEXT,        -- e.g. "utils"
    imported_symbol_name TEXT         -- e.g. "MyClass"
);
```

### symbol_references — Use-Site Tracking (Layer 3)

```sql
CREATE TABLE symbol_references (
    id TEXT PRIMARY KEY,
    source_file TEXT NOT NULL,
    line INTEGER,
    col INTEGER,
    ref_type TEXT NOT NULL,           -- call | attribute_access | inheritance | type_annotation | decorator
    referenced_fqn TEXT,              -- resolved target (NULL if unresolved)
    raw_name TEXT NOT NULL            -- literal text from source
);
```

## Relationship to Prior Ideas

| Prior Idea | Relationship |
|-----------|-------------|
| [`ideas/2026-05-03--symbol-level-import-dependency-extraction.md`](2026-05-03--symbol-level-import-dependency-extraction.md) | **Absorbed as data source.** Import extraction populates `bindings` with `binding_type = 'import_from'`. No longer a standalone feature; it is the seed data for Layer 2. |
| `separate-relationship-production-from-rendering` | **Aligned.** The database evolves from a transient cache into a persistent knowledge base, making the separation even more justified. |
| `filter-external-modules-from-structure-dimension` | **Trivial once symbol table exists.** External vs. internal distinction becomes a query on `bindings.bound_to_fqn` or `symbols.source_file`. |
| `cli-support-directory-argument` | **Orthogonal.** Convenience improvement unaffected by this architectural shift. |

## Potential Implementation Strategy

### Phase 1: Source Archive ✓ Completed (2026-05-11)

Implemented in [`openspec/changes/archive/2026-05-11-add-source-archive-layer`](../openspec/changes/archive/2026-05-11-add-source-archive-layer/).

What was delivered:
1. ✓ Added `source_contents` and `source_paths` tables to the SQLite schema.
2. ✓ Modified `extract` command to archive source files before extraction.
3. ✓ Decoupled extractors from disk I/O — they now receive `content` directly.
4. ✓ Extended `Node` model with `source_content_id` linking nodes to archived content.
5. ✓ Enhanced HTML presenter to embed archived source data and display code snippets in tooltips.

What was deferred to future phases:
- Content-hash-based incremental update (skip unchanged files) → Phase 1.5
- `source_files` single-table design was split into `source_contents` + `source_paths` for deduplication
- Compression / external blob storage → future optimization

### Phase 2: Symbol Table Schema + Definition Population (Week 2-3)

1. Add `symbols`, `bindings`, `scopes` tables.
2. Extend `PythonStructureExtractor` to populate `symbols` (definitions) and `bindings` (implicit self-definitions).
3. Each `class Foo` creates a `symbol` record and a `binding` record in the module scope: `Foo → Foo`.

### Phase 3: Import Binding Population (Week 3-4)

1. Extend `PythonImportExtractor` to write to `bindings` instead of (or in addition to) `relations`.
2. `from utils import MyClass` → binding: `scope=api.py, local_name=MyClass, bound_to_fqn=utils.MyClass, binding_type=import_from`.
3. `import utils` → binding: `scope=api.py, local_name=utils, bound_to_fqn=utils, binding_type=import`.
4. Evaluate whether `nodes`+`relations` tables can be derived as views over `symbols`+`bindings`.

### Phase 4: Symbol Resolution Engine (Month 2+)

1. Scan source code for use-sites (function calls, attribute access, type annotations, inheritance lists, decorators).
2. For each use-site, resolve the name using the scope's bindings chain.
3. Populate `symbol_references` with resolved FQNs.
4. External/unresolved references remain as raw names with NULL `referenced_fqn`.

## Open Questions

1. **Storage volume**: For large codebases, archiving all source files in SQLite may create multi-GB databases. Is compression needed? External blob storage?
2. **Schema migration path**: The existing `nodes`+`relations` schema is battle-tested. Should `symbols`+`bindings` coexist initially, or attempt a migration?
3. **nodes/relations vs. symbols/bindings**: Can `nodes` be a view over `symbols`? Can `relations` be materialized from `bindings`? Or should they be independent systems?
4. **Multi-language future**: Should `source_files` and `symbols` schemas be language-agnostic from the start?
5. **Binding scope granularity**: Module-level only initially, or include class-level and function-level scopes from day one?

## Notes

- **This is an architecture idea, not a feature idea.** It re-frames multiple existing ideas into a unified capability stack.
- The discrete-file constraint remains the hard boundary. Layer 3 (semantic resolution) will always be limited to symbols discoverable within the analyzed file set. External symbols (stdlib, unanalyzed third-party) will be referenced opaquely.
- The `bindings` table design is inspired by the Roslyn compiler's symbol table and Python's `symtable` module, but adapted for persistence and cross-file discrete analysis.
- **Discussion**: The full conversation that shaped this architecture is recorded in `ideas/archive/chatlogs/2026-05-09--persistent-symbol-table-and-source-archive.md`.
