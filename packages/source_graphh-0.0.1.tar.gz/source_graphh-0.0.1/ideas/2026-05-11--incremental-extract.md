---
date: "2026-05-11"
relations:
  - target: goal:code-intuition
    relation: serves
    rationale: "Enables efficient analysis of large codebases through incremental updates, supporting code intuition at scale."
---

# Idea: Incremental Extract

**Date:** 2026-05-11
**Status:** New
**Context:** Proposed immediately after completing Phase 1 (Source Archive Layer), which introduced content-addressed source storage via SHA-256.

## Description

On each `extract` run, compare the disk file's hash against `source_contents.id` (SHA-256) to decide, per file, what work is actually necessary:

- **Hash unchanged** → skip extraction entirely, reuse existing nodes and relations
- **Hash changed** → re-extract only this file, then clean up its old nodes and relations
- **File deleted** → remove the corresponding path, nodes, and relations from the database

This transforms the pipeline from a brute-force re-analyzer into an incremental, delta-aware system.

### Example / Use case

A developer runs `source-graph extract src/` on a 500-file project. Only 3 files changed since the last run. Instead of parsing all 500 files, the tool hashes all 500 files, skips 497, re-extracts 3, and cleans up the 3 old graph fragments. The run completes in milliseconds rather than seconds.

## Motivation

This is the leap from "toy analyzer" to "production tool for million-line codebases." Without incrementality, every analysis run is O(total codebase size). With incrementality, the cost is O(changed files). The Source Archive Layer (Phase 1) has already laid the exact foundation: `source_contents.id` is the content hash, and `source_paths` maps each file path to its current content hash.

## Potential Implementation

1. **Hash collection**: Scan the target directory tree and compute SHA-256 for every file (can be parallelized).
2. **Delta detection**: Query `source_paths` to build the previous state map (`path → content_hash`). Compare with the new scan.
3. **Three sets**: `added` (new path), `modified` (path exists, hash differs), `removed` (path in DB but missing from disk).
4. **Apply changes**:
   - For `added` / `modified`: archive content, run extractors, write new nodes/relations, then delete old nodes/relations for that path (for `modified`).
   - For `removed`: delete the path from `source_paths`, cascade-delete associated nodes and relations.
5. **Transaction boundary**: Wrap the entire delta application in a single SQLite transaction so the database is always consistent.

## Related Areas

- `src/source_graph/store.py` — `source_contents` and `source_paths` tables
- `src/source_graph/cli.py` — `extract` command orchestration
- `ideas/2026-05-09--persistent-symbol-table-and-source-archive.md` — Phase 1.5 originally sketched incremental update as deferred work

## Notes

- **Open question**: Should we also store `last_modified` timestamps as a fast-path before hashing? Timestamps are cheap but unreliable (git checkouts, `touch`, etc.); hash is the ground truth.
- **Open question**: How to handle extractor schema changes (e.g., we add a new relation type)? A schema-version flag could force a full re-extract.
- **Caveat**: Incrementality assumes extractors are deterministic. If an extractor produces different output for identical input on different runs, the incremental logic would appear to miss updates.
