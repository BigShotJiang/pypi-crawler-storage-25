---
date: "2026-05-11"
relations: []
---

# Idea: Unified Report Rendering Validation

**Date:** 2026-05-11
**Status:** New
**Context:** Two presenter bugs were only caught by manual browser inspection, revealing that string-level tests are insufficient for HTML/JS validation.

## Description

建立一个统一的「报告渲染验证」能力，底层是一个可复用的验证函数/脚本。开发时手动调用它做快速检查，CI 里自动调用它做回归门禁。

A core validation script (`scripts/verify-report.py`) using Playwright or similar validates generated `report.html` by loading it in a headless browser, checking for console errors, validating injected JavaScript variables, and exercising basic UI interactions. The same core function is wrapped for both developer quick-checks (`make verify-report`) and CI regression gates (`tests/test_presenter_e2e.py`).

### Example / Use case

After modifying `presenter.py`, a developer runs:

```bash
make verify-report
```

This generates a test report, launches a headless browser, and within seconds confirms:
- No `</script>` in archived source code broke JSON injection
- No `\n` escapes caused JS syntax errors
- All injected globals (`graphData`, `sourceContents`, `sourcePaths`) are present and valid
- UI interactions (dimension switch, hover) execute without runtime exceptions

## Motivation

The current test suite only checks for string containment (`assert "snippet" in html`) but does NOT validate that the generated HTML is structurally sound or that the embedded JavaScript is syntactically valid and executes without runtime errors.

Two real bugs prove this gap:
1. `</script>` inside archived source code prematurely closed the HTML `<script>` tag, breaking JSON injection
2. `\n` newline escapes in JavaScript were incorrectly rendered as literal newlines, causing JS syntax errors

Debugging via "human opens browser, inspects console, reports back to AI" is inefficient and does not scale as the project transitions from "toy" to "production tool".

## Potential Implementation

- Add Playwright (or similar headless browser tool) as a dev/test dependency
- Implement `scripts/verify-report.py` with a reusable `verify_report(html_path)` function:
  1. Launch headless browser
  2. Load the HTML file
  3. Capture console logs and page errors
  4. Assert presence and accessibility of `graphData`, `sourceContents`, `sourcePaths`
  5. Trigger basic UI interactions (click dimension buttons, hover graph nodes)
  6. Collect any exceptions thrown during interactions
  7. Exit 0 on pass, exit 1 with detailed error output on failure
- Wrap the core function in `tests/test_presenter_e2e.py` for pytest/CI integration
- Provide `make verify-report` target for developer quick-check

## Related Areas

- `src/source_graph/presenter.py` — the HTML/JS/CSS generator being validated
- `tests/test_presenter.py` — current string-level presenter tests
- `scripts/` — home for the core validation script
- `build/output/report.html` — typical target file to validate

## Notes

- **Open question:** Playwright vs. Selenium vs. lightweight HTML/JS parser? Playwright is recommended for real browser execution and console error capture.
- **Open question:** Should the validation script also generate the report (via CLI), or only validate an existing file? Suggest: default to validating existing file, optional flag to auto-generate first.
- **Caveat:** Headless browser tests add dependency weight and may be slower than unit tests; keep them scoped to presenter output validation only.
- **Related ideas:** `ideas/2026-05-11--incremental-extract.md`, `ideas/2026-05-11--polyglot-extractor-support.md`, `ideas/2026-05-11--full-text-code-search-over-knowledge-graph.md`
- **Overlap:** Related to `ideas/2026-05-05--explore-alternatives-to-pure-html-graph-rendering.md` — any rendering change will benefit from this validation layer.
- **Architecture context:** This idea is part of the broader evolution tracked in `ideas/2026-05-12--source-graph-architecture-evolution-roadmap.md`. Serve mode (`openspec/changes/archive/2026-05-12-add-serve-command/`) provides a more efficient validation target than file-based generation, though Playwright remains valuable for CI regression gates.
- **Blocked by:** `ideas/2026-05-11--presenter-template-separation.md` — extracting JS/CSS into independent files makes headless browser testing significantly more practical (the validation script can target a served page without worrying about inline-HTML quirks).


## Updated Context (2026-05-19)

This idea has become **more urgent** after `replace-presenter-with-fastapi-serve`.

**New real bug that Playwright would have caught:**

During the `replace-presenter-with-fastapi-serve` change, `presenter.py` was split into `web/app.js` + FastAPI backend. The JS extraction script (`sed`) accidentally removed the `const graphData = ...` declaration while keeping `sourceContents` and `sourcePaths`. The result: `app.js` loaded in the browser threw `ReferenceError: graphData is not defined`, breaking the entire UI.

**Why existing tests didn't catch it:**
- `pytest` + `TestClient` tests `GET /api/data` returns JSON ✅
- `bash` + `curl` tests HTTP status codes ✅
- **Neither validates that the browser can execute the frontend code**

**Post-template-separation implications:**

The original idea assumed validation of a self-contained `report.html` file. After `replace-presenter-with-fastapi-serve`, the validation target shifts:

```
Old target:  build/output/report.html  (static file, load directly)
New target:  http://localhost:PORT/     (running server, fetch API)
```

Playwright test flow should now be:
1. Start `source-graph serve` on a random port
2. Open `http://localhost:PORT/` in headless browser
3. Wait for `fetch('/api/data')` to complete
4. Assert no console errors (catches `ReferenceError`)
5. Assert dimension selector populated
6. Assert tree/graph/map renders without error

**Blocked by:** ✅ `presenter-template-separation` is now complete. This idea is unblocked.
