---
date: "2026-05-11"
relations:
  - target: goal:goal-achievement-system
    relation: serves
    rationale: "Visualizes idea relationships to support goal-aligned navigation and discovery."
---

# Idea: Auto-Generated Ideas Reference Graph

**Date:** 2026-05-11
**Status:** New
**Context:** The `ideas/` directory now contains 10+ markdown files, each linking to others via relative markdown links (e.g., `[see related idea](2026-05-03--symbol-level-import-dependency-extraction.md)`). These links are static text — there is no way to visualize which ideas are central hubs, which are orphaned, or which form natural clusters. As the backlog grows, discovering relationships between ideas becomes increasingly difficult.
**Serves:** [Goal Achievement System](2026-05-12--goal-achievement-system-the-ultimate-form-of-idea-mechanism.md)

## Description

Create a tool that scans `ideas/*.md`, extracts all internal cross-references, and generates an interactive graph visualization (`ideas/graph.html` or `build/ideas-graph.html`). This transforms the ideas directory from a flat file list into a navigable knowledge graph.

### What to Extract

For each idea file, parse:
1. **Frontmatter**: `Status`, `Date`, `tags` (if present)
2. **Outbound links**: All `[...](YYYY-MM-DD--*.md)` references
3. **Inbound links**: Reverse mapping — which ideas link *to* this one
4. **Keywords**: Named entities in the title (e.g., "API", "Presenter", "Symbol Table")

### Graph Visualization

```
┌─────────────────────────────────────────────────────────────┐
│                    Ideas Reference Graph                     │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│     ┌──────────────────────┐                                 │
│     │  Symbol Table        │◄────┐    ┌──────────────┐      │
│     │  (4 inbound links)   │     │    │  File Tree   │      │
│     │  Status: In Progress │     │    │  (orphaned)  │      │
│     └──────────┬───────────┘     │    └──────────────┘      │
│                │                 │                           │
│     ┌──────────▼───────────┐     │    ┌──────────────┐      │
│     │  Source Archive      │─────┘    │  API Layer   │      │
│     │  (1 inbound)         │          │  (1 inbound) │      │
│     │  Status: Implemented │          └──────────────┘      │
│     └──────────────────────┘                                 │
│                                                              │
│  Legend: ──► references    ┌─── cluster boundary            │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Proposed Implementation

```bash
# CLI command
source-graph ideas-graph --output build/ideas-graph.html

# Or as a CI step
# .github/workflows/ideas-graph.yml
# - run: source-graph ideas-graph --output build/ideas-graph.html
# - uses: actions/upload-artifact
```

**Backend (Python)**:
1. Glob `ideas/*.md` (excluding `archive/`)
2. Parse frontmatter with `yaml.safe_load()`
3. Extract links with regex: `r'\[([^\]]+)\]\(([^)]+\.md)\)'`
4. Build adjacency list: `idea_id → [referenced_ids]`
5. Compute centrality metrics (in-degree = popularity)
6. Cluster by shared references (Jaccard similarity)

**Frontend (HTML/JS)**:
- Use Cytoscape.js (already a project dependency) to render the graph
- Node size ∝ inbound link count
- Node color ∝ status (New=blue, Exploring=yellow, Implemented=green, Declined=gray)
- Click node → popup with idea summary + link to full markdown
- Drag to pan, scroll to zoom

### Example Output Structure

```json
{
  "nodes": [
    {"id": "symbol-table", "title": "Persistent Symbol Table", "status": "In Progress", "inbound": 4, "tags": ["architecture"]},
    {"id": "source-archive", "title": "Source Archive Layer", "status": "Implemented", "inbound": 1, "tags": ["architecture"]}
  ],
  "edges": [
    {"source": "source-archive", "target": "symbol-table", "type": "references"},
    {"source": "api-layer", "target": "symbol-table", "type": "references"}
  ],
  "clusters": [
    {"name": "Architecture Stack", "members": ["source-archive", "symbol-table", "semantic-resolution"]},
    {"name": "Visualization", "members": ["presenter-template", "api-layer", "radical-paradigms"]}
  ]
}
```

## Motivation

1. **Discoverability**: New team members (or future versions of the agent) can open `ideas/graph.html` and immediately see the project's intellectual landscape.
2. **Priority signals**: Ideas with high in-degree are "gravitational centers" — many other ideas depend on them. These should be prioritized.
3. **Orphan detection**: Ideas with zero inbound links and old dates might be stale or forgotten, prompting review.
4. **Cluster awareness**: Visually grouping ideas by theme reveals natural implementation phases (e.g., "do all the architecture-layer ideas first, then the visualization ideas").
5. **Self-awareness**: The tool can be bootstrapped — use source-graph itself to analyze its own `ideas/` directory.

## Potential Implementation

### Phase 1: Static JSON + HTML viewer (MVP)

- Python script scans `ideas/`, outputs `build/ideas-graph.json`
- Reuse existing `presenter.py` graph rendering code (Cytoscape.js)
- Single HTML file that loads the JSON

### Phase 2: Interactive features

- Click node to expand/collapse its cluster
- Filter by status ("show only New ideas")
- Search by keyword
- Hover to preview idea description

### Phase 3: CI integration

- GitHub Action runs on every push to `main`
- Regenerates graph, commits to `build/ideas-graph.html`
- Or serves via GitHub Pages

## Related Areas

- `ideas/` directory — the data source
- `src/source_graph/presenter.py` — can reuse Cytoscape.js graph rendering logic
- `ideas/2026-05-11--code-knowledge-graph-api.md` — the API idea could serve this data dynamically in the future
- `.claude/skills/record-idea/SKILL.md` — template source; adding `tags` frontmatter would improve clustering

## Notes

- **Bootstrap opportunity**: This tool can be built using source-graph itself. Create a custom "IdeaExtractor" that parses markdown instead of Python, and use the existing presenter to render the graph.
- **Link rot**: If an idea file is renamed or moved, relative links break. The scanner should report broken links.
- **Archive handling**: Ideas in `ideas/archive/` should be included in the graph but visually distinguished (dimmed, smaller, or in a separate layer).
- **Temporal view**: Optional timeline mode showing ideas by date, revealing "bursts of creativity" vs. "long-dormant threads."
