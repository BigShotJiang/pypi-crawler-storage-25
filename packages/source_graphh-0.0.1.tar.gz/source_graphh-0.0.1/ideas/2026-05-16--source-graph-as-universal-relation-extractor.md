---
date: "2026-05-16"
relations:
  - target: goal:code-intuition
    relation: serves
    rationale: "Transforms source-graph from a code analyzer into a universal relation extractor that consumes its own project metadata."
---

# Idea: Source-Graph as Universal Relation Extractor

**Date:** 2026-05-16
**Status:** New
**Context:** A deep insight emerged during a conversation about bidirectional goal links: if goals and ideas adopt typed frontmatter relations, source-graph can extract and parse them — transforming source-graph from a "code analyzer" into a "universal relation extractor" that consumes its own project metadata.
## Description

Source-graph's stated ambition is **"to see all programs in the world."** Currently, this is interpreted as "multi-language code analysis." But the insight from today's conversation suggests a broader interpretation:

> If a document contains structured relations (e.g., YAML frontmatter linking goals to other goals), then source-graph can extract those relations just as it extracts `import` relations from Python AST.

This reframes source-graph's mission:

```
Before:  Python AST → Import relations → Graph
After:   Any structured text → Typed relations → Graph
```

The **dogfooding闭环** (bootstrapping loop) looks like this:

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   source-graph (the product)                                │
│        │                                                    │
│        ▼                                                    │
│   analyzes goals/ + ideas/ ──▶ produces goal-relationship   │
│        │                        graph (typed edges)         │
│        │                                                    │
│        ▼                                                    │
│   goal-achievement-system (the process)                     │
│        │                                                    │
│        ▼                                                    │
│   consumes graph ──▶ manages source-graph's development     │
│        │                                                    │
│        └────────────────────────────────────────────────────┘
```

This is not a dependency cycle — it is a **cross-time-scale bootstrapping structure**:
- The *product* (source-graph) produces the graph
- The *process* (goal-achievement-system) consumes the graph to steer the product

### Example / Use case

**Input**: `ideas/goals/goal-achievement-system/goal.md` with typed frontmatter:

```yaml
---
related_goals:
  - name: code-intuition
    relation: serves
    rationale: "G-A-S serves code-intuition as its first target."
---
```

**Extraction**: A source-graph Markdown+YAML extractor parses the frontmatter and emits:

```json
{
  "source": "goal-achievement-system",
  "target": "code-intuition",
  "relation": "serves",
  "rationale": "G-A-S serves code-intuition as its first target."
}
```

**Consumption**: The goal-achievement-system dashboard renders this as a directed edge labeled "serves" between the two goal nodes, making the service relationship visible at a glance.

## Motivation

1. **Architectural foundation for "all programs"**: If source-graph can only parse Python AST, its ambition is capped. If it can parse any structured text with relations, the abstraction is deep enough to support arbitrary languages and even non-code artifacts.
2. **Self-hosting validation**: Source-graph analyzing its own goals and ideas is the ultimate dogfooding scenario. If it cannot make sense of its own project's metadata, it cannot claim to understand "all programs."
3. **Closes the loop between product and process**: The goal-achievement-system manages source-graph's development. If source-graph can feed structured goal data into that system, the team gains a data-driven view of its own priorities.
4. **Extends beyond code**: Documentation, configuration files, architecture decision records (ADRs), and API specs all contain relationships. A universal relation extractor makes them visible.

## Potential Implementation

### Phase 1: Markdown + YAML Frontmatter Extractor

Build a new extractor that targets markdown files with YAML frontmatter (like `ideas/goals/*/goal.md` and `ideas/*.md`):

```python
# src/source_graph/extractors/frontmatter_extractor.py
class FrontmatterExtractor:
    def extract(self, path: Path) -> List[Relation]:
        # Parse YAML frontmatter
        # Identify relation fields (related_goals, related_ideas, related_changes)
        # Emit typed Relation objects into the knowledge graph
```

This is the smallest step that validates the "universal" claim.

### Phase 2: Generalize to Arbitrary Structured Text

Extract the pattern from Phase 1 into a configurable extractor:

```yaml
# config/frontmatter-schema.yaml
- file_pattern: "ideas/goals/*/goal.md"
  relation_fields:
    - field: "related_goals"
      source_key: "name"       # the goal's own identifier
      target_key: "name"       # the related goal's identifier
      type_key: "relation"
      meta_keys: ["rationale"]
```

### Phase 3: Polyglot + Non-Code Pipeline Integration

Once the Tree-sitter polyglot foundation is laid (see `ideas/2026-05-11--polyglot-extractor-support.md`), the frontmatter extractor becomes one of many extractors feeding a unified relation store:

```
Python AST Extractor ──┐
TypeScript AST ────────┤
Markdown Frontmatter ──┼──▶ Unified Relation Store ──▶ Visualization
Go AST ────────────────┤
YAML Config ───────────┘
```

## Related Areas

- `ideas/goals/code-intuition/goal.md` — the goal this idea serves; contains the "see all programs" ambition
- `ideas/goals/goal-achievement-system/goal.md` — the process target that consumes the extracted relations
- `ideas/archive/implemented/2026-05-15--idea-structured-frontmatter.md` — the prerequisite: goals/ideas must use structured frontmatter before they can be machine-extracted
- `ideas/2026-05-16--typed-relations-for-goal-achievement-system.md` — the prerequisite: relations must be typed before extraction produces meaningful graphs
- `ideas/2026-05-11--polyglot-extractor-support.md` — the long-term extractor architecture this idea extends
- `ideas/2026-05-11--code-knowledge-graph-api.md` — the API layer that would expose extracted frontmatter relations alongside code relations
- `ideas/2026-05-12--goal-achievement-system-the-ultimate-form-of-idea-mechanism.md` — the higher-order system enabled by this extraction capability

## Notes

- **Direction C (graph view) depends on Direction A (typed relations)**: Source-graph can only produce a meaningful goal-relationship graph if the underlying relations carry type information. Untyped edges render as an undirected hairball.
- **Chicken-and-egg with frontmatter adoption**: This idea only becomes actionable once a critical mass of goals/ideas uses YAML frontmatter with typed relations. The first few files must be migrated by hand.
- **Scope discipline**: "Universal relation extractor" is an architectural direction, not a single feature. Each new extractor (Python AST, Markdown frontmatter, YAML config) is a concrete deliverable.
- **Open question**: Should the extracted relations live in the same database table as code relations (`import`, `contains`), or a separate semantic layer? Code relations are syntactic; goal relations are intentional. Mixing them may confuse queries.
- **Open question**: What is the identifier space for non-code entities? Code symbols have file paths and line numbers. Goals have directory names (`code-intuition`). Ideas have file stems (`2026-05-16--typed-relations`). A unified addressing scheme may be needed.
