---
date: "2026-05-19"
relations:
- target: "goal:code-intuition"
  relation: "serves"
  rationale: "Eliminates environment-related bugs and reduces onboarding friction for developers."
---

**Status:** New
**Context:** During `replace-presenter-with-fastapi-serve`, `run-self-analysis.sh` used system `python3` while the project dependencies (fastapi, uvicorn) were installed in `.venv`. This caused `ModuleNotFoundError: No module named 'fastapi'`. The fix was manually changing `python3` to `.venv/bin/python` in the script, revealing that no systematic environment management exists.

## Description

Establish a single source of truth for Python environment management across all `scripts/` and development workflows.

### Current Problem

```bash
# scripts/run-self-analysis.sh
python3 -m source_graph.cli extract src/ -o build/output   # ← system python3
python3 -m source_graph.cli serve build/output/source_graph.db  # ← system python3

# scripts/test-serve.sh
PYTHON="${PROJECT_ROOT}/.venv/bin/python"
$PYTHON -m source_graph.cli extract src/ -o build/output   # ← venv python
```

Inconsistencies:
1. `run-self-analysis.sh` uses `python3` (system) while `test-serve.sh` uses `.venv/bin/python` (venv)
2. No script initializes the virtual environment if missing
3. New contributors must manually discover that `.venv` exists and dependencies must be installed

### Proposed Solution

```
scripts/
├── .common.sh          # New: PYTHON=..., VENV_DIR=..., setup_venv()
├── run-self-analysis.sh  # Updated: source .common.sh
├── test-serve.sh         # Updated: source .common.sh
└── setup-dev.sh          # New: one-command dev environment bootstrap
```

**`scripts/.common.sh`**:
```bash
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VENV_DIR="${PROJECT_ROOT}/.venv"
PYTHON="${VENV_DIR}/bin/python"

setup_venv() {
    if [ ! -d "$VENV_DIR" ]; then
        echo "Creating virtual environment..."
        python3 -m venv "$VENV_DIR"
    fi
    if [ ! -f "${VENV_DIR}/bin/uv" ]; then
        echo "Installing uv..."
        curl -LsSf https://astral.sh/uv/install.sh | sh
    fi
    echo "Installing dependencies..."
    uv pip install -e "${PROJECT_ROOT}"
}
```

**`scripts/setup-dev.sh`** (new):
```bash
#!/bin/bash
set -euo pipefail
source "$(dirname "$0")/.common.sh"
setup_venv
echo "Dev environment ready. Use scripts/*.sh to run."
```

### Alternative: Use `uv run`

Instead of managing `.venv` paths manually, use `uv run` which automatically finds and activates the virtual environment:

```bash
uv run python -m source_graph.cli serve build/output/source_graph.db
```

Pros: No path management, no `.common.sh` needed
Cons: Requires `uv` to be installed globally

## Motivation

1. **Eliminate environment bugs**: `ModuleNotFoundError` should never happen because the wrong Python is used
2. **Reduce onboarding friction**: New contributors run one script and have a working environment
3. **Consistency**: All scripts use the same Python interpreter

## Related Areas

- `scripts/run-self-analysis.sh`
- `scripts/test-serve.sh`
- `pyproject.toml` (dependency declarations)
- `README.md` (setup instructions)
