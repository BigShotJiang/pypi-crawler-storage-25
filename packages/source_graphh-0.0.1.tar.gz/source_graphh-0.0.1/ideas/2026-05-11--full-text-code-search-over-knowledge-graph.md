---
date: "2026-05-11"
relations:
  - target: goal:code-intuition
    relation: serves
    rationale: "Enables hybrid text and structure search to accelerate code intuition discovery."
---

# Idea: Full-Text Code Search over Knowledge Graph

**Date:** 2026-05-11
**Status:** New
**Context:** Proposed after Phase 1 placed both structured AST data (nodes/relations) and raw source content (`source_contents`) into the same SQLite database, enabling a new class of hybrid queries.

## Description

Regular `grep` searches content but doesn't understand structure. Regular AST tools understand structure but don't index content. Now both live in the same database — we can combine them.

By adding a full-text search (FTS) index over `source_contents.content` and JOINing it with `nodes` and `relations`, we unlock queries that span both dimensions simultaneously.

### Example / Use case

1. **"Find all files calling `os.path.join` AND containing `TODO` in source"**
   - FTS query on `source_contents.content` for `TODO`
   - JOIN with `nodes` where `kind = 'call'` and `name = 'os.path.join'`

2. **"Find all subclasses of `BaseHandler` where the source exceeds 100 lines"**
   - Query `relations` for `kind = 'inherits'` and target `BaseHandler`
   - JOIN with `source_contents` via `source_content_id` and count lines

3. **"Search for `deprecated` markers, then trace upstream who still depends on them"**
   - FTS search for the word `deprecated`
   - Map hits back to `nodes` (functions/classes)
   - Traverse `relations` upstream to find callers/importers

## Motivation

This is a genuinely unique capability. Most code search tools are either text-first (grep, ripgrep, GitHub search) or structure-first (CodeQL, language servers). By keeping both in one place, `source-graph` can be the first tool in its class to offer native hybrid queries without external indexing pipelines.

## Potential Implementation

1. **Enable FTS5**: SQLite ships with the FTS5 extension. Create a virtual table:
   ```sql
   CREATE VIRTUAL TABLE source_contents_fts USING fts5(
       content,
       content='source_contents',
       content_rowid='rowid'
   );
   ```
2. **Keep in sync**: Use FTS5 `external content` mode so the virtual table references `source_contents` without duplication. Maintain triggers or manual rebuilds on insert/update/delete.
3. **Query interface**: Extend the CLI or future query API with a `search` command:
   ```
   source-graph search "TODO" --kind call --name "os.path.join"
   ```
   This compiles to an FTS query JOINed with `nodes`/`relations` filters.
4. **Ranking**: FTS5 supports BM25 ranking out of the box. Rank results by relevance and surface the most likely matches first.

## Related Areas

- `src/source_graph/store.py` — `source_contents` table and schema migrations
- `src/source_graph/cli.py` — Query/search command interface
- `ideas/2026-05-09--persistent-symbol-table-and-source-archive.md` — Symbol table and source archive architecture
- `ideas/2026-05-11--incremental-extract.md` — Incremental updates must also keep FTS index in sync

## Notes

- **Open question**: FTS5 tokenization for code. The default `unicode61` tokenizer splits identifiers like `os_path_join` into separate tokens. A custom tokenizer (or pre-processing) might be needed for precise identifier search.
- **Open question**: Performance on large codebases. FTS5 is fast, but JOINing with wide `nodes`/`relations` tables may require query optimization or materialized views.
- **Caveat**: FTS indexes increase database size. For a 1 GB codebase, expect roughly 30-50% overhead. The tradeoff is acceptable for interactive search but may require optional toggling.
