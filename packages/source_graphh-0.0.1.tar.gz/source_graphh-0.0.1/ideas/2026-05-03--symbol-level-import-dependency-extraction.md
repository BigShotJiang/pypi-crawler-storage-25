---
date: "2026-05-03"
relations: []
---

# Idea: Symbol-Level Import Dependency Extraction

**Date:** 2026-05-03
**Status:** New
**Context:** Following the decision to scope the initial `PythonImportExtractor` to module-level imports only, the user explicitly requested recording symbol-level granularity as a future enhancement: "初期只记录 module-level, system-level 的粒度后续考虑。"

## Description

As a follow-up enhancement to the module-level import extractor, extend the dependency graph to track **which specific symbols are imported from a module**. Instead of only recording that `a.py` imports module `b`, the extractor would create a `file_imports_symbol` relation from `a.py` to a symbol node representing `b.MyClass` (or equivalent) when encountering `from b import MyClass`.

This evolves the dependency dimension from coarse module-level edges to fine-grained symbol-level edges, enabling more precise dependency queries and visualizations.

### Example / Use case

Given:

```python
# a.py
from b import MyClass
```

The extractor would produce:

- `file_imports_symbol` — `a.py` → `b.MyClass`

This allows users to ask "which files depend on `MyClass`?" rather than just "which files import module `b`?"

## Motivation

1. **Precision**: Module-level import edges can over-approximate dependencies. A file importing `from os import path` does not depend on all of `os`.
2. **Refactoring support**: Fine-grained symbol dependencies help assess the blast radius of renaming or moving a specific class/function.
3. **Foundation for impact analysis**: Enables reverse lookups like "which files import `MyClass`?" with higher fidelity.
4. **Natural extension**: The initial extractor architecture and `RelationStore` multi-dimension support already accommodate this; it is a matter of parsing depth.

## Potential Implementation

1. **Enhance AST parsing** in `python_import_extractor.py`:
   - For `ImportFrom` nodes, capture the `names` list (imported symbols) in addition to the module name.
   - Create symbol nodes (e.g., `kind="symbol"`) qualified by their containing module.
   - Emit `file_imports_symbol` relations in addition to (or instead of) `file_imports_module` for `from ... import ...` statements.
2. **Symbol resolution / validation**:
   - Attempt to resolve whether the symbol actually exists in the target module (may require scanning the target file's AST or leveraging existing structure extraction data).
   - Handle unresolved symbols gracefully (e.g., create the relation anyway with a flag, or skip it).
3. **Presenter updates**:
   - Ensure `HTMLPresenter` can render symbol nodes within module contexts or as distinct nodes in the dependency view.
4. **Store queries**:
   - Add helper methods to `RelationStore` for reverse symbol dependency lookups if not already generically supported.

## Related Areas

- `ideas/2026-05-03--cross-file-import-dependency-extractor.md` (parent idea — this entry defers the `file_imports_symbol` aspect proposed there to a later phase)
- `src/source_graph/python_import_extractor.py` (will be created for the initial module-level extractor; this enhancement extends it)
- `src/source_graph/models.py` (node/relation type definitions)
- `src/source_graph/presenter.py` (visualization of symbol-level dependency edges)
- `src/source_graph/store.py` (query support for reverse symbol lookups)
- `ideas/2026-05-09--persistent-symbol-table-and-source-archive.md` (architectural deepening — this idea has been subsumed into the broader symbol table & source archive architecture; symbol-level import extraction becomes the data-population strategy for the `bindings` table)

## Notes

- **Deferred decision**: The initial implementation of `PythonImportExtractor` will only create `file_imports_module` relations. Symbol-level extraction is intentionally out of scope for the first phase to reduce complexity.
- **Challenges**:
  - **Re-exports**: `MyClass` might not be defined in `b.py` but imported from elsewhere (`c.py`). Resolving the true definition location requires transitive resolution.
  - **False positives**: If the symbol does not exist in the target module, creating a relation creates false dependency data.
  - **Increased AST parsing complexity**: Requires deeper analysis of target modules or integration with existing structure extraction output to validate symbol existence.
- **Open questions**:
  - Should `import b` followed by `b.MyClass` usage also create a `file_imports_symbol` relation, or only explicit `from b import MyClass`?
  - How should star imports (`from b import *`) be represented in a symbol-level graph?
- **Architectural evolution**: See `ideas/2026-05-09--persistent-symbol-table-and-source-archive.md` for the broader context. This idea's `file_imports_symbol` concept is absorbed as the `binding_type = 'import_from'` population strategy within the persistent symbol table layer.
- **Discussion**: The exploration that led to this architectural deepening is recorded in `ideas/archive/chatlogs/2026-05-09--persistent-symbol-table-and-source-archive.md`.
