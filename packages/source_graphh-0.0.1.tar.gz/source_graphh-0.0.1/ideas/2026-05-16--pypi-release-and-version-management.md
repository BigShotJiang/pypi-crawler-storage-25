---
date: "2026-05-16"
relations: []
---

# Idea: PyPI Release and Version Management

**Date:** 2026-05-16
**Status:** New
**Context:** The project already has `pyproject.toml` configured with hatchling build backend, a console script entry point (`source-graph = "source_graph.cli:main"`), and project metadata. However, the version remains at `0.1.0`, and there is no established release process. This idea addresses the gap between "packaging-ready" and "actually distributable" — the critical step that turns source-graph from a local development tool into a product users can install with `pip`.

> **Created:** 2026-05-16  
> **Updated:** 2026-05-16

## Core Direction

Establish a formal PyPI release pipeline with clear version management practices, enabling users to install source-graph via `pip install source-graph` and receive updates through standard Python packaging channels.

## Current State

- `pyproject.toml` exists with hatchling backend
- Console script `source-graph` is registered
- Version is hardcoded at `0.1.0`
- No release automation, no changelog, no versioning policy
- `Development Status :: 3 - Alpha` classifier is accurate

## Implementation Path

### Phase 1: Release Infrastructure

- **PyPI account and trusted publishing**: Configure PyPI trusted publishing via GitHub Actions (OIDC) to avoid storing long-lived API tokens
- **Release workflow**: GitHub Actions workflow triggered on tag push or release creation that builds the package and publishes to PyPI
- **Version source of truth**: Decide whether version lives in `pyproject.toml` only, or is dynamically read from Git tags (e.g., `hatch-vcs`)

### Phase 2: Version Management Discipline

- **Semantic Versioning (SemVer)**: Adopt `MAJOR.MINOR.PATCH` with clear rules for what constitutes a breaking change in a CLI tool
- **Pre-release versions**: Use `a1`, `b1`, `rc1` suffixes during active development; keep `0.x` series while in Alpha
- **Changelog maintenance**: Establish a `CHANGELOG.md` with categories (Added, Changed, Deprecated, Removed, Fixed, Security) — consider enforcing via PR template

### Phase 3: Quality Gates

- **Release checklist**: Tests must pass, version must be bumped, changelog must be updated
- **Automated pre-release checks**: Run test suite, lint, and build verification in CI before allowing release
- **Smoke test after publish**: Verify `pip install source-graph` works and the CLI launches correctly

## Open Questions

1. **Version source**: Static in `pyproject.toml`, or dynamic from Git tags using `hatch-vcs`?
2. **Release trigger**: Push a Git tag, create a GitHub Release, or both?
3. **Pre-release publishing**: Publish alpha/beta versions to PyPI (test.pypi.org first?), or only stable releases?
4. **Backward compatibility promise**: At what version do we commit to SemVer strictly for CLI arguments and output formats?
5. **Release cadence**: Event-driven (when ready), time-based, or milestone-based?

## Relationship to Other Ideas

- Enables `ci-cd-integration-for-cloud-hosted-repos` (not yet recorded): CI workflows can `pip install source-graph` instead of cloning and installing from source
- Complements `source-graph-architecture-evolution-roadmap`: Each roadmap step can correspond to a minor version bump
