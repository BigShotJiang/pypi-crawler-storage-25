# GAS — Goal Achievement System

CLI tool for managing idea frontmatter in the `ideas/` directory.
