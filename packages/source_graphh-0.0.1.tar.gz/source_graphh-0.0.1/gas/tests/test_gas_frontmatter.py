"""Tests for gas.idea_frontmatter module."""

from pathlib import Path

import pytest

from gas.idea_frontmatter import (
    IdeaFrontmatter,
    IdeaRelation,
    kebab_case,
    parse,
    validate,
    write_frontmatter,
)


class TestParse:
    def test_parse_minimal_frontmatter(self):
        content = '---\ndate: "2026-05-17"\nrelations: []\n---\n# Idea\n'
        fm = parse(content)
        assert fm.date == "2026-05-17"
        assert fm.relations == []

    def test_parse_with_relations(self):
        content = """---
date: "2026-05-17"
relations:
  - target: goal:code-intuition
    relation: serves
    rationale: "It serves."
---
# Idea
"""
        fm = parse(content)
        assert fm.date == "2026-05-17"
        assert len(fm.relations) == 1
        assert fm.relations[0].target == "goal:code-intuition"
        assert fm.relations[0].relation == "serves"
        assert fm.relations[0].rationale == "It serves."

    def test_parse_missing_delimiter_raises(self):
        with pytest.raises(ValueError, match="does not start with frontmatter delimiter"):
            parse("# No frontmatter\n")

    def test_parse_no_closing_delimiter_raises(self):
        with pytest.raises(ValueError, match="closing delimiter not found"):
            parse("---\ndate: \"2026-05-17\"\n")

    def test_parse_invalid_yaml_raises(self):
        with pytest.raises(ValueError):
            parse("---\nnot a mapping\n---\n")


class TestWriteFrontmatter:
    def test_write_minimal(self):
        fm = IdeaFrontmatter(date="2026-05-17")
        result = write_frontmatter(fm)
        assert result == '---\ndate: "2026-05-17"\nrelations: []\n---\n'

    def test_write_with_relations_sorted(self):
        fm = IdeaFrontmatter(
            date="2026-05-17",
            relations=[
                IdeaRelation(target="goal:b", relation="depends_on", rationale="B"),
                IdeaRelation(target="goal:a", relation="serves", rationale="A"),
                IdeaRelation(target="goal:a", relation="depends_on", rationale="C"),
            ],
        )
        result = write_frontmatter(fm)
        # Should be sorted by relation then target
        assert "depends_on" in result
        lines = result.splitlines()
        # Find relation block lines
        rel_lines = [l for l in lines if "target:" in l or "relation:" in l or "rationale:" in l]
        assert rel_lines[0].strip() == '- target: "goal:a"'
        assert rel_lines[1].strip() == 'relation: "depends_on"'
        assert rel_lines[3].strip() == '- target: "goal:b"'
        assert rel_lines[4].strip() == 'relation: "depends_on"'
        assert rel_lines[6].strip() == '- target: "goal:a"'
        assert rel_lines[7].strip() == 'relation: "serves"'

    def test_write_empty_relations_flow_style(self):
        fm = IdeaFrontmatter(date="2026-05-17")
        result = write_frontmatter(fm)
        assert "relations: []" in result

    def test_roundtrip(self):
        original = IdeaFrontmatter(
            date="2026-05-17",
            relations=[
                IdeaRelation(target="goal:code-intuition", relation="serves", rationale="Rationale here."),
            ],
        )
        written = write_frontmatter(original)
        parsed = parse(written)
        assert parsed.date == original.date
        assert len(parsed.relations) == 1
        assert parsed.relations[0].target == original.relations[0].target
        assert parsed.relations[0].relation == original.relations[0].relation
        assert parsed.relations[0].rationale == original.relations[0].rationale


class TestValidate:
    def test_valid_frontmatter(self, tmp_path: Path):
        ideas_dir = tmp_path / "ideas"
        ideas_dir.mkdir()
        goals_dir = ideas_dir / "goals"
        goals_dir.mkdir()
        (goals_dir / "code-intuition").mkdir()
        (goals_dir / "code-intuition" / "goal.md").write_text("---\n---\n")

        fm = IdeaFrontmatter(
            date="2026-05-17",
            relations=[
                IdeaRelation(
                    target="goal:code-intuition",
                    relation="serves",
                    rationale="It serves.",
                ),
            ],
        )
        violations = validate(fm, ideas_dir / "test.md", ideas_dir, goals_dir)
        assert violations == []

    def test_invalid_date_format(self, tmp_path: Path):
        fm = IdeaFrontmatter(date="05-17-2026")
        violations = validate(fm, tmp_path / "test.md", tmp_path, tmp_path)
        assert any("Invalid date format" in v for v in violations)

    def test_invalid_relation_type(self, tmp_path: Path):
        fm = IdeaFrontmatter(
            date="2026-05-17",
            relations=[
                IdeaRelation(target="goal:x", relation="invalid", rationale="Rationale."),
            ],
        )
        violations = validate(fm, tmp_path / "test.md", tmp_path, tmp_path)
        assert any("Invalid relation type" in v for v in violations)

    def test_missing_relation_fields(self, tmp_path: Path):
        fm = IdeaFrontmatter(
            date="2026-05-17",
            relations=[
                IdeaRelation(target="", relation="serves", rationale=""),
            ],
        )
        violations = validate(fm, tmp_path / "test.md", tmp_path, tmp_path)
        assert any("missing 'target'" in v for v in violations)
        assert any("missing 'rationale'" in v for v in violations)

    def test_broken_target_reference(self, tmp_path: Path):
        ideas_dir = tmp_path / "ideas"
        ideas_dir.mkdir()
        goals_dir = ideas_dir / "goals"
        goals_dir.mkdir()

        fm = IdeaFrontmatter(
            date="2026-05-17",
            relations=[
                IdeaRelation(target="goal:nonexistent", relation="serves", rationale="Rationale."),
            ],
        )
        violations = validate(fm, ideas_dir / "test.md", ideas_dir, goals_dir)
        assert any("Broken target reference" in v for v in violations)

    def test_unrecognized_target_namespace(self, tmp_path: Path):
        fm = IdeaFrontmatter(
            date="2026-05-17",
            relations=[
                IdeaRelation(target="unknown:thing", relation="serves", rationale="Rationale."),
            ],
        )
        violations = validate(fm, tmp_path / "test.md", tmp_path, tmp_path)
        assert any("unrecognized namespace" in v for v in violations)


class TestKebabCase:
    def test_simple_title(self):
        assert kebab_case("My Great Idea") == "my-great-idea"

    def test_already_lowercase(self):
        assert kebab_case("my great idea") == "my-great-idea"

    def test_multiple_spaces(self):
        assert kebab_case("My   Great   Idea") == "my-great-idea"

    def test_special_characters(self):
        assert kebab_case("My Great Idea!") == "my-great-idea"

    def test_leading_trailing_special(self):
        assert kebab_case("!My Great Idea!") == "my-great-idea"
