"""Tests for gas.cli module."""

import json
from pathlib import Path

import pytest

from gas.cli import main


class TestWriteSubcommand:
    def test_write_creates_file(self, tmp_path: Path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        ret = main(["write", "--date", "2026-05-17", "--title", "My Great Idea"])
        assert ret == 0
        file_path = tmp_path / "ideas" / "2026-05-17--my-great-idea.md"
        assert file_path.exists()
        content = file_path.read_text()
        assert 'date: "2026-05-17"' in content
        assert "relations: []" in content

    def test_write_with_relations(self, tmp_path: Path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        rels = json.dumps(
            [
                {
                    "target": "goal:code-intuition",
                    "relation": "serves",
                    "rationale": "It serves.",
                }
            ]
        )
        ret = main(["write", "--date", "2026-05-17", "--title", "My Great Idea", "--relations", rels])
        assert ret == 0
        file_path = tmp_path / "ideas" / "2026-05-17--my-great-idea.md"
        content = file_path.read_text()
        assert 'target: "goal:code-intuition"' in content
        assert 'relation: "serves"' in content

    def test_write_collision_handling(self, tmp_path: Path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        main(["write", "--date", "2026-05-17", "--title", "My Great Idea"])
        main(["write", "--date", "2026-05-17", "--title", "My Great Idea"])
        assert (tmp_path / "ideas" / "2026-05-17--my-great-idea.md").exists()
        assert (tmp_path / "ideas" / "2026-05-17--my-great-idea-2.md").exists()

    def test_write_missing_date(self, tmp_path: Path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        with pytest.raises(SystemExit):
            main(["write", "--title", "My Great Idea"])

    def test_write_missing_title(self, tmp_path: Path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        with pytest.raises(SystemExit):
            main(["write", "--date", "2026-05-17"])

    def test_write_invalid_date(self, tmp_path: Path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        ret = main(["write", "--date", "05-17-2026", "--title", "My Great Idea"])
        assert ret == 1
        captured = capsys.readouterr()
        assert "Invalid date format" in captured.err

    def test_write_relations_sorted(self, tmp_path: Path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        rels = json.dumps(
            [
                {"target": "goal:b", "relation": "depends_on", "rationale": "B"},
                {"target": "goal:a", "relation": "serves", "rationale": "A"},
            ]
        )
        main(["write", "--date", "2026-05-17", "--title", "My Great Idea", "--relations", rels])
        file_path = tmp_path / "ideas" / "2026-05-17--my-great-idea.md"
        content = file_path.read_text()
        # depends_on should come before serves
        assert content.index("depends_on") < content.index("serves")


class TestValidateSubcommand:
    def test_validate_no_files(self, tmp_path: Path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        ret = main(["validate"])
        assert ret == 0
        captured = capsys.readouterr()
        assert "No idea or goal files found" in captured.out

    def test_validate_valid_file(self, tmp_path: Path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        ideas_dir = tmp_path / "ideas"
        ideas_dir.mkdir()
        (ideas_dir / "2026-05-17--test.md").write_text('---\ndate: "2026-05-17"\nrelations: []\n---\n')
        ret = main(["validate"])
        assert ret == 0
        captured = capsys.readouterr()
        assert "compliant" in captured.out

    def test_validate_invalid_date(self, tmp_path: Path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        ideas_dir = tmp_path / "ideas"
        ideas_dir.mkdir()
        (ideas_dir / "test.md").write_text('---\ndate: "bad-date"\nrelations: []\n---\n')
        ret = main(["validate"])
        assert ret == 1
        captured = capsys.readouterr()
        assert "Invalid date format" in captured.out

    def test_validate_broken_target(self, tmp_path: Path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        ideas_dir = tmp_path / "ideas"
        ideas_dir.mkdir()
        goals_dir = ideas_dir / "goals"
        goals_dir.mkdir()
        (ideas_dir / "test.md").write_text(
            '---\ndate: "2026-05-17"\nrelations:\n  - target: goal:missing\n    relation: serves\n    rationale: "R."\n---\n'
        )
        ret = main(["validate"])
        assert ret == 1
        captured = capsys.readouterr()
        assert "Broken target reference" in captured.out

    def test_validate_invalid_relation_type(self, tmp_path: Path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        ideas_dir = tmp_path / "ideas"
        ideas_dir.mkdir()
        (ideas_dir / "test.md").write_text(
            '---\ndate: "2026-05-17"\nrelations:\n  - target: goal:x\n    relation: unknown\n    rationale: "R."\n---\n'
        )
        ret = main(["validate"])
        assert ret == 1
        captured = capsys.readouterr()
        assert "Invalid relation type" in captured.out

    def test_validate_goal_file(self, tmp_path: Path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        ideas_dir = tmp_path / "ideas"
        ideas_dir.mkdir()
        goals_dir = ideas_dir / "goals" / "test-goal"
        goals_dir.mkdir(parents=True)
        (goals_dir / "goal.md").write_text('---\ndate: "2026-05-17"\nrelations: []\n---\n')
        ret = main(["validate"])
        assert ret == 0
        captured = capsys.readouterr()
        assert "compliant" in captured.out
