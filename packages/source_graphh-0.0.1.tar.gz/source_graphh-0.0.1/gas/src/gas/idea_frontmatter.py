"""Frontmatter parsing, writing, and validation for idea/goal markdown files."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

VALID_RELATION_TYPES = {"serves", "depends_on", "refines"}
DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")


@dataclass
class IdeaRelation:
    target: str
    relation: str
    rationale: str

    def to_dict(self) -> dict[str, str]:
        return {
            "target": self.target,
            "relation": self.relation,
            "rationale": self.rationale,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> IdeaRelation:
        return cls(
            target=str(data.get("target", "")),
            relation=str(data.get("relation", "")),
            rationale=str(data.get("rationale", "")),
        )


@dataclass
class IdeaFrontmatter:
    date: str
    relations: list[IdeaRelation] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "date": self.date,
            "relations": [r.to_dict() for r in self.relations],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> IdeaFrontmatter:
        rels = data.get("relations", [])
        if rels is None:
            rels = []
        return cls(
            date=str(data.get("date", "")),
            relations=[IdeaRelation.from_dict(r) for r in rels],
        )


def _str_representer(dumper, data):
    """Force double quotes on all string values."""
    return dumper.represent_scalar("tag:yaml.org,2002:str", data, style='"')


class _FrontmatterDumper(yaml.SafeDumper):
    """Custom YAML dumper for deterministic frontmatter output."""

    def represent_mapping(self, tag, mapping, flow_style=None):
        node = super().represent_mapping(tag, mapping, flow_style=flow_style)
        # Ensure keys are unquoted plain scalars
        for key_node, value_node in node.value:
            if isinstance(key_node, yaml.ScalarNode):
                key_node.style = None  # plain scalar
        return node

    def represent_sequence(self, tag, sequence, flow_style=None):
        # Empty sequences in flow style, non-empty in block style
        if not sequence:
            flow_style = True
        else:
            flow_style = False
        return super().represent_sequence(tag, sequence, flow_style=flow_style)


_FrontmatterDumper.add_representer(str, _str_representer)
_FrontmatterDumper.add_representer(IdeaRelation, lambda dumper, data: dumper.represent_mapping(
    "tag:yaml.org,2002:map", data.to_dict(), flow_style=False
))


def parse(content: str) -> IdeaFrontmatter:
    """Parse YAML frontmatter from markdown content.

    Expects content to start with '---' followed by YAML, then '---'.
    Returns IdeaFrontmatter with parsed data.
    """
    if not content.startswith("---"):
        raise ValueError("Content does not start with frontmatter delimiter")

    # Find end of frontmatter
    end_idx = content.find("\n---", 3)
    if end_idx == -1:
        raise ValueError("Frontmatter closing delimiter not found")

    yaml_block = content[3:end_idx].strip()
    data = yaml.safe_load(yaml_block)
    if not isinstance(data, dict):
        raise ValueError("Frontmatter is not a valid YAML mapping")

    return IdeaFrontmatter.from_dict(data)


def write_frontmatter(frontmatter: IdeaFrontmatter) -> str:
    """Serialize frontmatter to a YAML block wrapped in '---' delimiters.

    Uses custom SafeDumper for deterministic output:
    - Unquoted keys
    - Double-quoted string values
    - Empty relations as flow-style []
    - Non-empty relations in block style, sorted by relation then target
    """
    # Sort relations
    sorted_rels = sorted(
        frontmatter.relations,
        key=lambda r: (r.relation, r.target),
    )
    frontmatter = IdeaFrontmatter(
        date=frontmatter.date,
        relations=sorted_rels,
    )

    data = frontmatter.to_dict()
    yaml_str = yaml.dump(
        data,
        Dumper=_FrontmatterDumper,
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False,
        width=float("inf"),
    )
    # Remove trailing newline that yaml.dump adds
    yaml_str = yaml_str.rstrip("\n")
    return f"---\n{yaml_str}\n---\n"


def validate(
    frontmatter: IdeaFrontmatter,
    file_path: Path,
    ideas_dir: Path,
    goals_dir: Path,
) -> list[str]:
    """Validate frontmatter against the typed-relations schema.

    Returns a list of violation messages (empty if valid).
    """
    violations: list[str] = []

    # Date format
    if not DATE_PATTERN.match(frontmatter.date):
        violations.append(f"Invalid date format: '{frontmatter.date}' (expected YYYY-MM-DD)")

    # Relations validation
    for rel in frontmatter.relations:
        if not rel.target:
            violations.append("Relation missing 'target' field")
        if not rel.relation:
            violations.append("Relation missing 'relation' field")
        if not rel.rationale:
            violations.append("Relation missing 'rationale' field")
        if rel.relation and rel.relation not in VALID_RELATION_TYPES:
            violations.append(
                f"Invalid relation type: '{rel.relation}' (expected one of {VALID_RELATION_TYPES})"
            )

        # Target file existence
        if rel.target:
            target_path = _resolve_target(rel.target, ideas_dir, goals_dir)
            if target_path is None:
                violations.append(f"Broken target reference: '{rel.target}' (unrecognized namespace)")
            elif not target_path.exists():
                violations.append(f"Broken target reference: '{rel.target}' (file not found: {target_path})")

    return violations


def _resolve_target(target: str, ideas_dir: Path, goals_dir: Path) -> Path | None:
    """Resolve a target string to a filesystem path.

    Target formats:
    - goal:<goal-name>  -> ideas/goals/<goal-name>/goal.md
    - idea:<stem>       -> ideas/<stem>.md
    """
    if target.startswith("goal:"):
        goal_name = target[5:]
        return goals_dir / goal_name / "goal.md"
    elif target.startswith("idea:"):
        stem = target[5:]
        return ideas_dir / f"{stem}.md"
    else:
        return None


def kebab_case(title: str) -> str:
    """Convert a title to a kebab-case filename segment.

    Lowercase, replace non-alphanumeric with hyphens, collapse multiples.
    """
    lowered = title.lower()
    # Replace any non-alphanumeric sequence with a single hyphen
    cleaned = re.sub(r"[^a-z0-9]+", "-", lowered)
    # Strip leading/trailing hyphens
    cleaned = cleaned.strip("-")
    return cleaned
