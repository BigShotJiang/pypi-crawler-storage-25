from gas.cli import main
import sys

sys.exit(main())
