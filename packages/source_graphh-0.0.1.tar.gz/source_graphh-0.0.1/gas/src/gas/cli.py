"""CLI for GAS frontmatter operations."""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import sys
from pathlib import Path

from gas.idea_frontmatter import (
    DATE_PATTERN,
    VALID_RELATION_TYPES,
    IdeaFrontmatter,
    IdeaRelation,
    kebab_case,
    parse,
    validate,
    write_frontmatter,
)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="gas",
        description="GAS (Goal Achievement System) frontmatter CLI for idea/goal files.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {importlib.metadata.version('gas')}",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # write subcommand
    write_parser = subparsers.add_parser(
        "write",
        help="Create a new idea/goal file with deterministic YAML frontmatter.",
        description="Create a new idea/goal file with deterministic YAML frontmatter.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  gas write --date 2026-05-17 --title "My Great Idea"
  gas write --date 2026-05-17 --title "My Great Idea" \\
      --relations '[{"target":"goal:code-intuition","relation":"serves","rationale":"It serves the goal."}]'

Output behavior:
  The absolute path to the created file is printed to stdout.
  If a file with the same date and title already exists, a numeric suffix (-2, -3, ...) is appended.

Relation types:
  serves      - The idea contributes to achieving the target goal/idea.
  depends_on  - The idea cannot proceed without the target goal/idea.
  refines     - The idea improves or narrows the target goal/idea.

Target namespace format:
  goal:<goal-name>  -> ideas/goals/<goal-name>/goal.md
  idea:<stem>       -> ideas/<stem>.md
        """.strip(),
    )
    write_parser.add_argument(
        "--date",
        required=True,
        help="Creation date in YYYY-MM-DD format.",
    )
    write_parser.add_argument(
        "--title",
        required=True,
        help="Idea title (used to generate the kebab-case filename).",
    )
    write_parser.add_argument(
        "--relations",
        default="[]",
        help=(
            'JSON array of relation objects. Example: '
            '[{"target":"goal:code-intuition","relation":"serves","rationale":"..."}]'
        ),
    )

    # validate subcommand
    validate_parser = subparsers.add_parser(
        "validate",
        help="Scan ideas/ and ideas/goals/ for frontmatter compliance.",
        description="Scan ideas/ and ideas/goals/ for frontmatter compliance.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Validation rules:
  - date must be in YYYY-MM-DD format
  - relations must be an array of objects with target, relation, and rationale fields
  - relation type must be one of: serves, depends_on, refines
  - target references must point to existing files (goal:<name> or idea:<stem>)

Exit codes:
  0  All files are compliant
  1  One or more violations found
        """.strip(),
    )

    return parser


def _write_idea(args: argparse.Namespace) -> int:
    # Validate date format
    if not DATE_PATTERN.match(args.date):
        print(f"Invalid date format: '{args.date}' (expected YYYY-MM-DD)", file=sys.stderr)
        return 1

    # Parse relations JSON
    try:
        rels_raw = json.loads(args.relations)
    except json.JSONDecodeError as e:
        print(f"Invalid relations JSON: {e}", file=sys.stderr)
        return 1

    if not isinstance(rels_raw, list):
        print("Relations must be a JSON array", file=sys.stderr)
        return 1

    relations: list[IdeaRelation] = []
    for item in rels_raw:
        if not isinstance(item, dict):
            print("Each relation must be a JSON object", file=sys.stderr)
            return 1
        try:
            relations.append(IdeaRelation.from_dict(item))
        except Exception as e:
            print(f"Invalid relation object: {e}", file=sys.stderr)
            return 1

    frontmatter = IdeaFrontmatter(
        date=args.date,
        relations=relations,
    )

    # Generate filename
    kebab = kebab_case(args.title)
    filename = f"{args.date}--{kebab}.md"
    ideas_dir = Path("ideas")
    ideas_dir.mkdir(exist_ok=True)
    file_path = ideas_dir / filename

    # Handle collision
    counter = 2
    original_path = file_path
    while file_path.exists():
        file_path = ideas_dir / f"{args.date}--{kebab}-{counter}.md"
        counter += 1

    content = write_frontmatter(frontmatter)
    file_path.write_text(content, encoding="utf-8")
    print(str(file_path.resolve()))
    return 0


def _validate(args: argparse.Namespace) -> int:
    ideas_dir = Path("ideas")
    goals_dir = ideas_dir / "goals"

    files_to_check: list[Path] = []

    if ideas_dir.exists():
        files_to_check.extend(ideas_dir.glob("*.md"))

    if goals_dir.exists():
        for goal_dir in goals_dir.iterdir():
            if goal_dir.is_dir():
                goal_file = goal_dir / "goal.md"
                if goal_file.exists():
                    files_to_check.append(goal_file)

    if not files_to_check:
        print("No idea or goal files found.")
        return 0

    all_violations: list[tuple[Path, list[str]]] = []
    for file_path in files_to_check:
        content = file_path.read_text(encoding="utf-8")
        try:
            fm = parse(content)
        except ValueError as e:
            all_violations.append((file_path, [f"Frontmatter parse error: {e}"]))
            continue

        violations = validate(fm, file_path, ideas_dir, goals_dir)
        if violations:
            all_violations.append((file_path, violations))

    if not all_violations:
        print(f"All {len(files_to_check)} file(s) have compliant frontmatter.")
        return 0

    for file_path, violations in all_violations:
        print(f"{file_path}:")
        for v in violations:
            print(f"  - {v}")

    return 1


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command == "write":
        return _write_idea(args)
    elif args.command == "validate":
        return _validate(args)
    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
