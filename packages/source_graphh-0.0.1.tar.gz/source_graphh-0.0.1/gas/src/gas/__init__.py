"""GAS (Goal Achievement System) frontmatter CLI tools."""
