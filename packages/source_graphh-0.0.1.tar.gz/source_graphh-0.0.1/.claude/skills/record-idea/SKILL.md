---
name: record-idea
description: Record ideas, feature requests, architectural decisions, or design concepts from conversation as structured markdown files in the project's ideas/ folder. Triggered by phrases like "record this idea", "save this idea", "write this down", or any request to persist a concept for later.
---

# Record Idea

Persist an idea from the current conversation as a structured markdown file in `ideas/<YYYY-MM-DD>--<kebab-case-title>.md`.

## Workflow

To avoid polluting the current session's context window, **delegate the entire task to a subagent**:

1. **Launch a subagent** via `Agent` with a clear prompt containing:
   - The full conversation context (entire user/agent exchange that led to this request)
   - The explicit instruction to record the idea(s) from that context
2. **Let the subagent execute** — it handles scanning `ideas/`, generating frontmatter via the `gas` CLI, appending body content, and reporting back.
3. **Surface the result** — Confirm to the user which file(s) were created.

### Subagent Prompt Template

Pass the subagent a prompt like:

> You are a focused task agent. Record the idea(s) from the following conversation as structured markdown files in the `ideas/` directory.
>
> **Conversation context:**
> <paste full relevant conversation here>
>
> Instructions:
> 1. Scan `ideas/` for existing files on the same topic. If found, reference them and note how this idea evolves or differs.
> 2. Ensure `ideas/` exists at the project root.
> 3. For each distinct idea:
>    a. Run `gas write --help` to understand the CLI usage.
>    b. Run `gas write --date <YYYY-MM-DD> --title "<Idea Title>"` to create the file with YAML frontmatter.
>       - Capture the file path printed to stdout.
>       - If the idea has goal/idea relations, include `--relations '<JSON>'`.
>    c. **Append** the body content to the created file using `WriteFile(mode="append")`.
>       - **CRITICAL: Do NOT overwrite the file.** It already contains YAML frontmatter.
>    d. The file name is derived automatically by `gas write` from the date and title.
> 4. If a file with the same date + title exists, `gas write` will append `-2`, `-3`, etc. automatically.
> 5. Report back the exact file paths created.
>
> Body template to append after the frontmatter:
> ```markdown
> # Idea: <Title>
>
> **Date:** <YYYY-MM-DD>
> **Status:** <New | Exploring | Accepted | Declined | Implemented — default to New unless user specifies>
> **Context:** <One-sentence origin from the conversation>
>
> ## Description
>
> <What the idea is>
>
> ### Example / Use case
>
> <Concrete example if applicable>
>
> ## Motivation
>
> <Why it matters — problem solved, value added>
>
> ## Potential Implementation
>
> <High-level approach or steps>
>
> ## Related Areas
>
> <Relevant files, modules, concepts>
>
> ## Notes
>
> <Open questions, caveats, follow-ups>
> ```

## File Naming

```
ideas/<YYYY-MM-DD>--<kebab-case-title>.md
```

Example: `ideas/2026-05-03--cross-file-import-extractor.md`

## Guidelines

- Include enough context that the idea is understandable without the full conversation.
- If the idea is a direct continuation of a previous idea, reference the previous file and explain the evolution.
- Use the `Status` field to track lifecycle. Default to `New` unless the user specifies otherwise.
- In `## Notes`, capture unresolved questions, risks, or dependencies.
- Keep the file focused on one idea. If the user asks to record multiple ideas, create one file per idea.
