---
name: suggest-ideas
description: Recommend actionable ideas based on active goals and identify gaps where goals lack idea coverage. Use when the user asks "What should I work on?", "Suggest ideas", "What ideas serve this goal?", "Find gaps in our plan", or any request to discover, prioritize, filter, or navigate ideas in the ideas/ directory.
---

# Suggest Ideas

Navigate from goals to actionable ideas through agent reasoning. Read idea content in full. Do not rely on frontmatter metadata for judgments.

## Workflow

### Step 1: DISCOVER — Scan for contexts

Use Shell to list `ideas/goals/*/goal.md`.
If the directory does not exist or is empty, proceed to Step 2 with only the preset options.

Build the option list:
- Each discovered goal (extract the title from the first `# Heading` in the goal.md file)
- "No goal — browse unbound ideas"
- "All ideas — cross-goal comprehensive view"

### Step 2: SELECT — Ask the user

Use AskUserQuestion to present the options from Step 1.
Let the user select one. Default to the first discovered goal if only one exists.

### Step 3: READ GOAL — Understand the target

If a specific goal was selected:
- Read the goal.md file in full using ReadFile
- Retain the complete text for reasoning

If "No goal" or "All ideas" was selected, note the context and skip this step.

### Step 4: READ IDEAS — Load all active ideas

Read every `ideas/*.md` file. Exclude `ideas/archive/` completely.

If there are more than 10 ideas, use parallel sub-agents to read and summarize.

**Parallel reading strategy:**
- Launch 2-3 sub-agents via the Agent tool
- Assign each a subset of idea files (roughly equal splits)
- Each sub-agent uses the prompt template in the Sub-Agent Prompt section below
- Collect all {path, summary} results from sub-agents

If there are 10 or fewer ideas, read them directly without sub-agents.

### Step 5: MODE 1 — RECOMMEND

Based on the goal content (if any) and all idea summaries, reason about which ideas are most worth pursuing now.

Consider:
- Does this idea genuinely move the goal forward? Judge from content, not frontmatter claims.
- What is the idea's maturity? Fuzzy concept or clear implementation path?
- Is the timing right? Are prerequisites met?
- What is the value-to-effort ratio?

Produce a prioritized list of recommended ideas. For each, explain the rationale in natural language.

### Step 6: MODE 2 — DISCOVER GAPS

After establishing what is already covered by existing ideas, look back at the goal description.

Identify areas where the goal describes needs, directions, or open questions that no idea addresses.

Special context handling:
- **"No goal" selected**: Identify whether scattered ideas cluster into coherent directions that might deserve a goal.
- **"All ideas" selected**: Identify which goals are over-served and which are under-served by existing ideas.

### Step 7: PRESENT — Respond conversationally

Output the results in free-form conversational language. Do not use a rigid template or fixed sections.

The output should include:
- A brief framing of the selected context
- Recommendations with contextual rationale
- Gap discoveries (if applicable)
- Optional follow-up questions or next-step suggestions

## Sub-Agent Prompt Template

Use this prompt when delegating to sub-agents for parallel idea reading:

> You are a focused reading agent. Read the following idea files and return a concise summary for each.
>
> **Idea files to read:**
> <list of file paths>
>
> **Instructions:**
> 1. Read each file in full using ReadFile.
> 2. For each idea, write a 2-3 sentence summary capturing:
>    - The core direction or problem the idea addresses
>    - Its current maturity (fuzzy concept vs. clear path)
>    - Any stated status or progress
> 3. Return a list in this format:
>    - `path: summary`
> 4. Do not judge or rank the ideas. Just summarize their content accurately.

## Edge Cases

- **No goals directory**: Fall back to "All ideas" context automatically. Do not fail.
- **No ideas**: Report that no ideas are available and suggest using the record-idea skill.
- **All ideas are archived**: Only active ideas in `ideas/*.md` count. Archive is excluded.
- **Single goal exists**: Still present the AskUserQuestion with all options. Do not auto-select the only goal.
