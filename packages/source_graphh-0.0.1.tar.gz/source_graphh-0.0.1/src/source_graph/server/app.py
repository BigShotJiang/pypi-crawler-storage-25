"""FastAPI application for source-graph serve mode."""

import importlib.resources as resources

from fastapi import FastAPI
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from ..data_builder import build_all_data
from ..store import RelationStore
from . import config

app = FastAPI()

# Determine the web directory path at import time
_web_dir = resources.files("source_graph") / "web"

# Serve static assets
app.mount("/static", StaticFiles(directory=str(_web_dir)), name="static")


@app.get("/")
async def root() -> FileResponse:
    """Serve the main index.html."""
    return FileResponse(str(_web_dir / "index.html"))


@app.get("/api/data")
async def get_data() -> JSONResponse:
    """Return all dimension data, source contents, and source paths."""
    store = RelationStore(config.get_db_path())
    payload = build_all_data(store)
    return JSONResponse(content=payload)
