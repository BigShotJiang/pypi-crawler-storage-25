"""Server configuration."""

_db_path: str = ""


def configure(db_path: str) -> None:
    """Set the database path for the server."""
    global _db_path
    _db_path = db_path


def get_db_path() -> str:
    """Return the configured database path."""
    return _db_path
