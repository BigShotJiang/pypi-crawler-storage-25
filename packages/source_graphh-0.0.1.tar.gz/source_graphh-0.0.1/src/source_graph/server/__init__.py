"""FastAPI server package for source-graph."""

from .app import app

__all__ = ["app"]
