"""Data-building logic for source-graph visualization.

Pure functions that transform GraphStore data into view-ready payloads.
"""

from typing import Any, Dict, List, Optional, Set, Tuple

from .models import NodeFilter, RelationFilter
from .store import GraphStore


def build_tree_data(store: GraphStore, dimension: str) -> List[Dict[str, Any]]:
    """Build hierarchical tree data for a given dimension."""
    relations = store.get_relations(RelationFilter(dimension=dimension))

    # Build parent -> children mapping
    children_map: Dict[str, List[str]] = {}
    all_node_ids: set = set()
    for relation in relations:
        all_node_ids.add(relation.source_id)
        all_node_ids.add(relation.target_id)
        children_map.setdefault(relation.source_id, []).append(relation.target_id)

    # Find root nodes: nodes that are sources but never targets
    target_ids = {r.target_id for r in relations}
    root_ids = [nid for nid in all_node_ids if nid not in target_ids]

    # Also add orphan nodes (nodes with no relations at all)
    all_store_nodes = store.get_nodes(NodeFilter())
    for node in all_store_nodes:
        if node.id not in all_node_ids:
            root_ids.append(node.id)

    node_lookup = {n.id: n for n in all_store_nodes}

    def build_node(node_id: str) -> Optional[Dict[str, Any]]:
        node = node_lookup.get(node_id)
        if node is None:
            return None
        children = []
        for child_id in children_map.get(node_id, []):
            child = build_node(child_id)
            if child:
                children.append(child)
        result = {
            "id": node.id,
            "name": node.name,
            "kind": node.kind,
            "fqn": node.fqn,
            "source_file": node.source_file,
            "range": {
                "start_line": node.range.start_line,
                "end_line": node.range.end_line,
            } if node.range else None,
            "source_content_id": node.source_content_id,
            "children": children,
            "collapsed": False,
        }
        return result

    trees = []
    for root_id in root_ids:
        tree = build_node(root_id)
        if tree:
            trees.append(tree)

    return trees


def build_dependency_data(store: GraphStore, dimension: str) -> Dict[str, Any]:
    """Build structured dependency graph data for a given dimension."""
    relations = store.get_relations(RelationFilter(dimension=dimension))
    if not relations:
        return {"nodes": {}, "edges": [], "roots": []}

    node_ids = set()
    for r in relations:
        node_ids.add(r.source_id)
        node_ids.add(r.target_id)

    all_nodes = store.get_nodes(NodeFilter())
    node_lookup = {n.id: n for n in all_nodes if n.id in node_ids}

    edges = []
    adj: Dict[str, List[Tuple[str, bool]]] = {}
    for r in relations:
        src = node_lookup.get(r.source_id)
        tgt = node_lookup.get(r.target_id)
        if not src or not tgt:
            continue
        is_external = tgt.kind == "external_module"
        edges.append({"source": src.name, "target": tgt.name, "is_external": is_external})
        adj.setdefault(src.name, []).append((tgt.name, is_external))

    if not edges:
        return {"nodes": {}, "edges": [], "roots": []}

    # Sort children alphabetically for stable display
    for src_name in adj:
        adj[src_name].sort(key=lambda x: x[0])

    # Build nodes metadata
    nodes: Dict[str, Dict[str, Any]] = {}
    for node in node_lookup.values():
        internal_out = sum(
            1 for e in edges if e["source"] == node.name and not e["is_external"]
        )
        nodes[node.name] = {
            "is_external": node.kind == "external_module",
            "internal_out_degree": internal_out,
            "kind": node.kind,
        }

    # Root nodes: all nodes that have outgoing edges
    root_names = list(adj.keys())
    root_names.sort(key=lambda n: nodes[n]["internal_out_degree"])

    return {
        "nodes": nodes,
        "edges": edges,
        "roots": root_names,
    }


def build_dependency_map_data(store: GraphStore, dimension: str) -> Dict[str, Any]:
    """Build layered dependency map data (internal files only) for a given dimension."""
    relations = store.get_relations(RelationFilter(dimension=dimension))
    if not relations:
        return {"nodes": [], "edges": []}

    all_nodes = store.get_nodes(NodeFilter())
    node_lookup = {n.id: n for n in all_nodes}

    # Filter to internal-only edges
    internal_edges: List[Tuple[str, str]] = []
    internal_node_names: Set[str] = set()
    for r in relations:
        src = node_lookup.get(r.source_id)
        tgt = node_lookup.get(r.target_id)
        if not src or not tgt:
            continue
        if src.kind == "external_module" or tgt.kind == "external_module":
            continue
        internal_edges.append((src.name, tgt.name))
        internal_node_names.add(src.name)
        internal_node_names.add(tgt.name)

    if not internal_node_names:
        return {"nodes": [], "edges": []}

    # Build adjacency list
    adj: Dict[str, List[str]] = {name: [] for name in internal_node_names}
    for src, tgt in internal_edges:
        adj[src].append(tgt)

    # Tarjan SCC algorithm
    index_counter = [0]
    stack: List[str] = []
    lowlinks: Dict[str, int] = {}
    index: Dict[str, int] = {}
    on_stack: Dict[str, bool] = {}
    sccs: List[List[str]] = []

    def strongconnect(v: str) -> None:
        index[v] = index_counter[0]
        lowlinks[v] = index_counter[0]
        index_counter[0] += 1
        stack.append(v)
        on_stack[v] = True

        for w in adj.get(v, []):
            if w not in internal_node_names:
                continue
            if w not in index:
                strongconnect(w)
                lowlinks[v] = min(lowlinks[v], lowlinks[w])
            elif on_stack.get(w, False):
                lowlinks[v] = min(lowlinks[v], index[w])

        if lowlinks[v] == index[v]:
            scc: List[str] = []
            while True:
                w = stack.pop()
                on_stack[w] = False
                scc.append(w)
                if w == v:
                    break
            sccs.append(scc)

    for v in internal_node_names:
        if v not in index:
            strongconnect(v)

    # Build node-to-SCC mapping
    node_to_scc: Dict[str, int] = {}
    for i, scc in enumerate(sccs):
        for node in scc:
            node_to_scc[node] = i

    # Build compressed DAG edges
    scc_adj: List[Set[int]] = [set() for _ in sccs]
    for src, tgt in internal_edges:
        src_scc = node_to_scc[src]
        tgt_scc = node_to_scc[tgt]
        if src_scc != tgt_scc:
            scc_adj[src_scc].add(tgt_scc)

    # Bottom-up layer assignment
    layer: Dict[int, int] = {}
    visited: Set[int] = set()

    def assign_layer(scc_id: int) -> int:
        if scc_id in visited:
            return layer.get(scc_id, 0)
        visited.add(scc_id)
        max_child_layer = -1
        for child_id in scc_adj[scc_id]:
            child_layer = assign_layer(child_id)
            max_child_layer = max(max_child_layer, child_layer)
        layer[scc_id] = max_child_layer + 1
        return layer[scc_id]

    for i in range(len(sccs)):
        assign_layer(i)

    # Build output nodes
    nodes = []
    for i, scc in enumerate(sccs):
        scc.sort()
        nodes.append({
            "id": f"scc_{i}",
            "names": scc,
            "layer": layer[i],
        })

    # Sort by layer descending, then alphabetically by first name
    nodes.sort(key=lambda n: (-n["layer"], n["names"][0]))

    # Build output edges
    edges = []
    seen_edges: Set[Tuple[int, int]] = set()
    for src_id in range(len(sccs)):
        for tgt_id in scc_adj[src_id]:
            key = (src_id, tgt_id)
            if key in seen_edges:
                continue
            seen_edges.add(key)
            edges.append({
                "source": f"scc_{src_id}",
                "target": f"scc_{tgt_id}",
            })

    return {"nodes": nodes, "edges": edges}


def build_graph_data(store: GraphStore, dimension: str) -> Dict[str, Any]:
    """Build raw graph data (nodes and edges) for Cytoscape rendering."""
    relations = store.get_relations(RelationFilter(dimension=dimension))
    if not relations:
        return {"nodes": [], "edges": []}

    all_nodes = store.get_nodes(NodeFilter())
    node_lookup = {n.id: n for n in all_nodes}

    nodes: List[Dict[str, Any]] = []
    node_names: Set[str] = set()
    edges: List[Dict[str, str]] = []

    for r in relations:
        src = node_lookup.get(r.source_id)
        tgt = node_lookup.get(r.target_id)
        if not src or not tgt:
            continue
        if src.kind == "external_module" or tgt.kind == "external_module":
            continue
        if src.name not in node_names:
            nodes.append({
                "id": src.name,
                "name": src.name,
                "kind": src.kind,
                "fqn": src.fqn,
            })
            node_names.add(src.name)
        if tgt.name not in node_names:
            nodes.append({
                "id": tgt.name,
                "name": tgt.name,
                "kind": tgt.kind,
                "fqn": tgt.fqn,
            })
            node_names.add(tgt.name)
        edges.append({"source": src.name, "target": tgt.name})

    return {"nodes": nodes, "edges": edges}


def build_all_data(store: GraphStore) -> Dict[str, Any]:
    """Assemble the complete payload for the frontend API.

    Returns all dimension data, source contents, and source paths.
    """
    dimensions = store.get_dimensions()
    if not dimensions:
        dimensions = ["structure"]

    result: Dict[str, Any] = {}
    for dim in dimensions:
        if dim == "dependencies":
            result[dim] = {
                "type": "dependency_graph",
                "data": {
                    "tree": build_dependency_data(store, dim),
                    "map": build_dependency_map_data(store, dim),
                    "graph": build_graph_data(store, dim),
                },
            }
        else:
            result[dim] = {
                "type": "tree",
                "data": build_tree_data(store, dim),
            }

    return {
        "dimensions": result,
        "sourceContents": store.get_source_contents(),
        "sourcePaths": store.get_source_paths(),
    }
