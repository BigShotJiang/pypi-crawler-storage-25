
let defaultDimension = "structure";
let graphData = {};
let sourceContents = {};
let sourcePaths = [];
let showExternal = true;
let currentView = 'graph';

function escapeHtml(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function getIcon(kind) {
  const icons = {
    file: '📄', class: '🏛️', function: '⚡', method: '🔧',
    variable: '📦', module: '📁', default: '📎'
  };
  return icons[kind] || icons.default;
}

function getSourceSnippet(contentId, startLine, endLine) {
  const content = sourceContents[contentId];
  if (!content) return null;
  const lines = content.split('\\n');
  const snippet = lines.slice(startLine - 1, endLine).join('\\n');
  return snippet;
}

function renderNode(node) {
  const hasChildren = node.children && node.children.length > 0;
  const toggleClass = hasChildren ? 'toggle' : 'toggle leaf';
  const toggleIcon = node.collapsed ? '▶' : '▼';
  const collapsedClass = node.collapsed ? 'collapsed' : '';

  let tooltip = `FQN: ${escapeHtml(node.fqn)}`;
  if (node.range) {
    tooltip += `\\nLines: ${node.range.start_line}-${node.range.end_line}`;
  }
  if (node.source_file && node.source_file !== node.fqn) {
    tooltip += `\\nFile: ${escapeHtml(node.source_file)}`;
  }
  if (node.source_content_id && node.range) {
    const snippet = getSourceSnippet(node.source_content_id, node.range.start_line, node.range.end_line);
    if (snippet) {
      tooltip += `\n\n<div class="snippet">${escapeHtml(snippet)}</div>`;
    }
  }

  return `<li>
    <div class="node ${collapsedClass}" data-id="${escapeHtml(node.id)}">
      <span class="${toggleClass}">${hasChildren ? toggleIcon : ''}</span>
      <span class="icon">${getIcon(node.kind)}</span>
      <span class="name">${escapeHtml(node.name)}</span>
      <span class="kind">${escapeHtml(node.kind)}</span>
      <span class="tooltip">${tooltip}</span>
    </div>
    ${hasChildren ? `<ul>${node.children.map(renderNode).join('')}</ul>` : ''}
  </li>`;
}

function renderDimension(dimension) {
  const dimData = graphData[dimension];
  const treeEl = document.getElementById('tree');
  const statsEl = document.getElementById('stats');
  const viewToggleContainer = document.getElementById('view-toggle-container');

  if (!dimData) {
    treeEl.innerHTML = '<div class="empty">No data for this dimension.</div>';
    statsEl.textContent = '';
    viewToggleContainer.style.display = 'none';
    return;
  }

  if (dimData.type === 'dependency_graph') {
    document.getElementById('external-toggle-container').style.display = 'block';
    viewToggleContainer.style.display = 'block';
    if (currentView === 'graph') {
      renderGraph(dimData.data.graph, dimension);
    } else if (currentView === 'map') {
      renderDependencyMap(dimData.data.map, dimension);
    } else {
      renderDependencyGraph(dimData.data.tree, dimension);
    }
  } else {
    document.getElementById('external-toggle-container').style.display = 'none';
    viewToggleContainer.style.display = 'none';
    renderTree(dimData.data, dimension);
  }
}

function renderTree(data, dimension) {
  const treeEl = document.getElementById('tree');
  const statsEl = document.getElementById('stats');

  if (!data || data.length === 0) {
    treeEl.innerHTML = '<div class="empty">No data for this dimension.</div>';
    statsEl.textContent = '';
    return;
  }

  statsEl.textContent = `Dimension: "${dimension}" — ${data.length} root node(s)`;
  treeEl.innerHTML = `<ul>${data.map(renderNode).join('')}</ul>`;
}

function renderDependencyGraph(data, dimension) {
  const treeEl = document.getElementById('tree');
  const statsEl = document.getElementById('stats');

  if (!data || !data.edges || data.edges.length === 0) {
    treeEl.innerHTML = '<div class="empty">No dependencies found.</div>';
    statsEl.textContent = '';
    return;
  }

  // Build filtered adjacency list
  const adj = {};
  for (const edge of data.edges) {
    if (!showExternal && edge.is_external) continue;
    if (!adj[edge.source]) adj[edge.source] = [];
    adj[edge.source].push({target: edge.target, is_external: edge.is_external});
  }

  // Sort children alphabetically
  for (const src in adj) {
    adj[src].sort((a, b) => a.target.localeCompare(b.target));
  }

  function buildTree(name, path) {
    if (path.includes(name)) {
      return {
        id: name + '-circular',
        name: name,
        kind: 'default',
        fqn: '[circular]',
        source_file: null,
        range: null,
        children: [],
        collapsed: false,
      };
    }
    const children = [];
    const childItems = adj[name] || [];
    for (const item of childItems) {
      const childTree = buildTree(item.target, path.concat([name]));
      if (childTree) children.push(childTree);
    }
    const nodeData = data.nodes[name] || {};
    return {
      id: name,
      name: name,
      kind: nodeData.kind || 'default',
      fqn: name,
      source_file: null,
      range: null,
      children: children,
      collapsed: false,
    };
  }

  const trees = [];
  for (const root of data.roots) {
    const tree = buildTree(root, []);
    if (tree) trees.push(tree);
  }

  if (trees.length === 0) {
    treeEl.innerHTML = '<div class="empty">No dependencies found.</div>';
    statsEl.textContent = '';
    return;
  }

  const externalLabel = showExternal ? ' (external shown)' : ' (external hidden)';
  statsEl.textContent = `Dimension: "${dimension}" — ${trees.length} root node(s)${externalLabel}`;
  treeEl.innerHTML = `<ul>${trees.map(renderNode).join('')}</ul>`;
}

function renderDependencyMap(mapData, dimension) {
  const treeEl = document.getElementById('tree');
  const statsEl = document.getElementById('stats');

  if (!mapData || !mapData.nodes || mapData.nodes.length === 0) {
    treeEl.innerHTML = '<div class="empty">No internal dependencies found.</div>';
    statsEl.textContent = '';
    return;
  }

  const NODE_WIDTH = 150;
  const NODE_HEIGHT_SINGLE = 30;
  const NODE_HEIGHT_PER_EXTRA = 18;
  const LAYER_SPACING = 90;
  const PADDING = 50;

  // Group nodes by layer
  const layerMap = {};
  for (const node of mapData.nodes) {
    if (!layerMap[node.layer]) layerMap[node.layer] = [];
    layerMap[node.layer].push(node);
  }

  const layers = Object.keys(layerMap).map(Number).sort((a, b) => b - a);
  const maxLayer = Math.max(...layers);
  const numLayers = layers.length;

  const svgWidth = 960;
  const svgHeight = numLayers * LAYER_SPACING + PADDING * 2;

  // Calculate node positions
  const nodePositions = {};
  for (const layer of layers) {
    const nodes = layerMap[layer];
    const totalNodeWidth = nodes.reduce((sum, n) => sum + NODE_WIDTH, 0);
    const gap = nodes.length === 1 ? (svgWidth - totalNodeWidth) / 2 : (svgWidth - totalNodeWidth) / (nodes.length + 1);
    let x = gap;
    for (const node of nodes) {
      const nodeHeight = NODE_HEIGHT_SINGLE + Math.max(0, node.names.length - 1) * NODE_HEIGHT_PER_EXTRA;
      nodePositions[node.id] = {
        x: x,
        y: PADDING + (maxLayer - layer) * LAYER_SPACING,
        width: NODE_WIDTH,
        height: nodeHeight,
      };
      x += NODE_WIDTH + gap;
    }
  }

  // Build SVG
  let svg = `<svg width="${svgWidth}" height="${svgHeight}" style="background:white;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">`;

  // Edges (draw first so they are behind nodes)
  for (const edge of mapData.edges) {
    const src = nodePositions[edge.source];
    const tgt = nodePositions[edge.target];
    if (src && tgt) {
      svg += `<line class="map-edge" data-source="${edge.source}" data-target="${edge.target}" x1="${src.x + src.width/2}" y1="${src.y + src.height}" x2="${tgt.x + tgt.width/2}" y2="${tgt.y}" stroke="#bbb" stroke-width="1.5" />`;
    }
  }

  // Nodes
  for (const node of mapData.nodes) {
    const pos = nodePositions[node.id];
    const isScc = node.names.length > 1;
    const fill = isScc ? '#fff3e0' : '#e3f2fd';
    const stroke = isScc ? '#ff9800' : '#2196f3';

    svg += `<g class="map-node" data-id="${node.id}" style="cursor:pointer;">`;
    svg += `<rect x="${pos.x}" y="${pos.y}" width="${pos.width}" height="${pos.height}" rx="4" fill="${fill}" stroke="${stroke}" stroke-width="2" />`;

    for (let i = 0; i < node.names.length; i++) {
      const ty = pos.y + 18 + i * NODE_HEIGHT_PER_EXTRA;
      const fontSize = node.names.length > 3 ? '10' : '12';
      svg += `<text x="${pos.x + pos.width/2}" y="${ty}" text-anchor="middle" font-size="${fontSize}" fill="#333" style="pointer-events:none;">${escapeHtml(node.names[i])}</text>`;
    }
    svg += `</g>`;
  }

  svg += `</svg>`;

  treeEl.innerHTML = svg;
  statsEl.textContent = `Dimension: "${dimension}" — Map view (${mapData.nodes.length} nodes, ${mapData.edges.length} edges)`;

  // Add click handler for highlighting
  const svgEl = treeEl.querySelector('svg');
  svgEl.addEventListener('click', (e) => {
    const nodeEl = e.target.closest('.map-node');
    if (nodeEl) {
      const nodeId = nodeEl.getAttribute('data-id');
      highlightDownstream(nodeId, mapData);
    } else {
      clearHighlight(svgEl);
    }
  });

  // Tooltip handlers
  const tooltipDiv = document.getElementById('map-tooltip');
  svgEl.addEventListener('mouseover', (e) => {
    const nodeEl = e.target.closest('.map-node');
    if (nodeEl) {
      const nodeId = nodeEl.getAttribute('data-id');
      const node = mapData.nodes.find(n => n.id === nodeId);
      if (node) {
        const outDeps = mapData.edges.filter(e => e.source === nodeId).length;
        const inDeps = mapData.edges.filter(e => e.target === nodeId).length;
        tooltipDiv.innerHTML = `<strong>${escapeHtml(node.names.join(', '))}</strong><br/>Outgoing: ${outDeps} | Incoming: ${inDeps}`;
        tooltipDiv.style.display = 'block';
      }
    }
  });
  svgEl.addEventListener('mousemove', (e) => {
    tooltipDiv.style.left = (e.clientX + 12) + 'px';
    tooltipDiv.style.top = (e.clientY + 12) + 'px';
  });
  svgEl.addEventListener('mouseout', (e) => {
    tooltipDiv.style.display = 'none';
  });
}

function highlightDownstream(nodeId, mapData) {
  const adj = {};
  for (const edge of mapData.edges) {
    if (!adj[edge.source]) adj[edge.source] = [];
    adj[edge.source].push(edge.target);
  }

  const highlighted = new Set();
  function dfs(id) {
    if (highlighted.has(id)) return;
    highlighted.add(id);
    for (const child of (adj[id] || [])) {
      dfs(child);
    }
  }
  dfs(nodeId);

  const svg = document.getElementById('tree').querySelector('svg');
  svg.querySelectorAll('.map-node rect').forEach(rect => {
    const id = rect.parentElement.getAttribute('data-id');
    if (highlighted.has(id)) {
      rect.style.opacity = '1';
      rect.style.strokeWidth = '3';
    } else {
      rect.style.opacity = '0.25';
      rect.style.strokeWidth = '1';
    }
  });
  svg.querySelectorAll('.map-edge').forEach(el => {
    const src = el.getAttribute('data-source');
    const tgt = el.getAttribute('data-target');
    if (highlighted.has(src) && highlighted.has(tgt)) {
      el.style.opacity = '1';
      el.setAttribute('stroke', '#e74c3c');
      el.setAttribute('stroke-width', '2.5');
    } else {
      el.style.opacity = '0.08';
      el.setAttribute('stroke', '#bbb');
      el.setAttribute('stroke-width', '1.5');
    }
  });
}

function clearHighlight(svg) {
  svg.querySelectorAll('.map-node rect').forEach(rect => {
    rect.style.opacity = '1';
    rect.style.strokeWidth = '2';
  });
  svg.querySelectorAll('.map-edge').forEach(el => {
    el.style.opacity = '1';
    el.setAttribute('stroke', '#bbb');
    el.setAttribute('stroke-width', '1.5');
  });
}

function renderGraph(graphData, dimension) {
  const treeEl = document.getElementById('tree');
  const statsEl = document.getElementById('stats');

  if (!graphData || !graphData.nodes || graphData.nodes.length === 0) {
    treeEl.innerHTML = '<div class="empty">No internal dependencies found.</div>';
    statsEl.textContent = '';
    return;
  }

  // Tarjan SCC algorithm
  function tarjanSCC(nodes, edges) {
    const adj = {};
    const nodeSet = new Set(nodes.map(n => n.id));
    for (const n of nodes) adj[n.id] = [];
    for (const e of edges) {
      if (nodeSet.has(e.source) && nodeSet.has(e.target)) {
        adj[e.source].push(e.target);
      }
    }

    let idx = 0;
    const stack = [];
    const onStack = {};
    const indices = {};
    const lowlinks = {};
    const sccs = [];

    function strongconnect(v) {
      indices[v] = idx;
      lowlinks[v] = idx;
      idx++;
      stack.push(v);
      onStack[v] = true;

      for (const w of (adj[v] || [])) {
        if (!(w in indices)) {
          strongconnect(w);
          lowlinks[v] = Math.min(lowlinks[v], lowlinks[w]);
        } else if (onStack[w]) {
          lowlinks[v] = Math.min(lowlinks[v], indices[w]);
        }
      }

      if (lowlinks[v] === indices[v]) {
        const scc = [];
        let w;
        do {
          w = stack.pop();
          onStack[w] = false;
          scc.push(w);
        } while (w !== v);
        sccs.push(scc);
      }
    }

    for (const v of Object.keys(adj)) {
      if (!(v in indices)) strongconnect(v);
    }
    return sccs;
  }

  const sccs = tarjanSCC(graphData.nodes, graphData.edges);

  // Build Cytoscape elements
  const elements = [];
  const sccMap = {}; // nodeId -> parentId

  sccs.forEach((scc, idx) => {
    if (scc.length > 1) {
      const parentId = 'scc_' + idx;
      elements.push({ data: { id: parentId, label: 'SCC (' + scc.length + ')' } });
      scc.forEach(nodeId => { sccMap[nodeId] = parentId; });
    }
  });

  for (const node of graphData.nodes) {
    const ele = {
      data: {
        id: node.id,
        label: node.name,
        kind: node.kind,
        fqn: node.fqn,
      }
    };
    if (sccMap[node.id]) {
      ele.data.parent = sccMap[node.id];
    }
    elements.push(ele);
  }

  for (let i = 0; i < graphData.edges.length; i++) {
    const e = graphData.edges[i];
    elements.push({
      data: {
        id: 'e' + i,
        source: e.source,
        target: e.target,
      }
    });
  }

  treeEl.innerHTML = '<div id="cy" style="width:100%;height:600px;background:white;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);"></div>';
  statsEl.textContent = `Dimension: "${dimension}" — Graph view (${graphData.nodes.length} nodes, ${graphData.edges.length} edges)`;

  const cy = cytoscape({
    container: document.getElementById('cy'),
    elements: elements,
    style: [
      {
        selector: 'node',
        style: {
          'background-color': '#e3f2fd',
          'border-color': '#2196f3',
          'border-width': 2,
          'label': 'data(label)',
          'text-valign': 'center',
          'text-halign': 'center',
          'font-size': '12px',
          'width': 'label',
          'height': 'label',
          'padding': '10px',
          'shape': 'round-rectangle',
          'text-wrap': 'wrap',
          'text-max-width': '120px',
        }
      },
      {
        selector: 'node[kind="class"]',
        style: {
          'background-color': '#f3e5f5',
          'border-color': '#9c27b0',
        }
      },
      {
        selector: 'node[kind="function"], node[kind="method"]',
        style: {
          'background-color': '#e8f5e9',
          'border-color': '#4caf50',
        }
      },
      {
        selector: ':parent',
        style: {
          'background-color': '#fff3e0',
          'border-color': '#ff9800',
          'border-width': 2,
          'label': '',
          'padding': '20px',
          'shape': 'round-rectangle',
        }
      },
      {
        selector: 'edge',
        style: {
          'curve-style': 'taxi',
          'taxi-direction': 'downward',
          'line-color': '#bbb',
          'width': 1.5,
          'target-arrow-shape': 'triangle',
          'target-arrow-color': '#bbb',
          'arrow-scale': 1,
        }
      },
      {
        selector: '.dimmed',
        style: { 'opacity': 0.1 }
      },
      {
        selector: '.highlighted',
        style: {
          'line-color': '#e74c3c',
          'width': 2.5,
          'target-arrow-color': '#e74c3c',
        }
      },
      {
        selector: 'node.highlighted',
        style: {
          'border-width': 3,
          'border-color': '#e74c3c',
          'background-color': '#ffebee',
        }
      }
    ],
    layout: {
      name: 'dagre',
      rankDir: 'TB',
      rankSep: 100,
      nodeSep: 60,
      edgeSep: 20,
      padding: 50,
    }
  });

  // Highlight downstream on click
  cy.on('tap', 'node', function(evt) {
    const node = evt.target;
    const successors = node.successors();
    cy.elements().not(successors).not(node).addClass('dimmed');
    successors.addClass('highlighted');
    node.addClass('highlighted');
  });

  cy.on('tap', function(evt) {
    if (evt.target === cy) {
      cy.elements().removeClass('dimmed highlighted');
    }
  });

  // Tooltip
  const tooltipDiv = document.getElementById('map-tooltip');
  cy.on('mouseover', 'node', function(evt) {
    const node = evt.target;
    const outDeps = node.outgoers().edges().length;
    const inDeps = node.incomers().edges().length;
    tooltipDiv.innerHTML = `<strong>${escapeHtml(node.data('label'))}</strong><br/>Outgoing: ${outDeps} | Incoming: ${inDeps}`;
    tooltipDiv.style.display = 'block';
  });

  cy.on('mousemove', function(evt) {
    tooltipDiv.style.left = (evt.originalEvent.clientX + 12) + 'px';
    tooltipDiv.style.top = (evt.originalEvent.clientY + 12) + 'px';
  });

  cy.on('mouseout', 'node', function() {
    tooltipDiv.style.display = 'none';
  });
}

function populateSelector() {
  const select = document.getElementById('dim-select');
  const dims = Object.keys(graphData);
  select.innerHTML = dims.map(d => `<option value="${escapeHtml(d)}" ${d === defaultDimension ? 'selected' : ''}>${escapeHtml(d)}</option>`).join('');
  select.addEventListener('change', (e) => {
    renderDimension(e.target.value);
  });
}

document.getElementById('view-select').addEventListener('change', (e) => {
  currentView = e.target.value;
  const dimSelect = document.getElementById('dim-select');
  renderDimension(dimSelect.value);
});

document.getElementById('tree').addEventListener('click', (e) => {
  const treeEl = document.getElementById('tree');
  if (treeEl.querySelector('svg')) return;

  const nodeEl = e.target.closest('.node');
  if (!nodeEl) return;

  const toggleEl = nodeEl.querySelector('.toggle');
  if (toggleEl.classList.contains('leaf')) return;

  const isCollapsed = nodeEl.classList.toggle('collapsed');
  toggleEl.textContent = isCollapsed ? '▶' : '▼';
});

document.getElementById('show-external').addEventListener('change', (e) => {
  showExternal = e.target.checked;
  const dimSelect = document.getElementById('dim-select');
  renderDimension(dimSelect.value);
});

async function init() {
  try {
    const res = await fetch('/api/data');
    const payload = await res.json();
    graphData = payload.dimensions;
    sourceContents = payload.sourceContents;
    sourcePaths = payload.sourcePaths;
    const dims = Object.keys(payload.dimensions);
    defaultDimension = dims[0] || 'structure';
    populateSelector();
    renderDimension(defaultDimension);
  } catch (err) {
    console.error('Failed to load data:', err);
    document.getElementById('tree').innerHTML = '<div class="empty">Failed to load data.</div>';
  }
}

init();
