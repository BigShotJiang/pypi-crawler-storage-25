"""Core data models for source-graph."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class Range:
    """Source code location range."""

    start_line: int
    start_col: int
    end_line: int
    end_col: int


@dataclass
class Node:
    """A node in the source graph."""

    id: str
    name: str
    kind: str
    fqn: str
    source_file: str
    range: Optional[Range] = None
    parent_id: Optional[str] = None
    properties: Dict = field(default_factory=dict)
    source_content_id: Optional[str] = None


@dataclass
class Relation:
    """A relation between two nodes."""

    id: str
    source_id: str
    target_id: str
    type: str
    dimension: str
    properties: Dict = field(default_factory=dict)


@dataclass
class NodeFilter:
    """Filter conditions for querying nodes."""

    kind: Optional[str] = None
    source_file: Optional[str] = None
    dimension: Optional[str] = None
    parent_id: Optional[str] = None


@dataclass
class RelationFilter:
    """Filter conditions for querying relations."""

    type: Optional[str] = None
    dimension: Optional[str] = None
    source_id: Optional[str] = None
    target_id: Optional[str] = None
    source_file: Optional[str] = None
