"""CLI entry point for source-graph."""

import argparse
import hashlib
import importlib.metadata
import logging
import os
import sys
from pathlib import Path
from typing import List, Optional

from .models import NodeFilter
from .python_import_extractor import PythonImportExtractor
from .python_structure_extractor import PythonStructureExtractor
from .store import RelationStore

logger = logging.getLogger(__name__)


def _collect_valid_paths(file_paths: List[str]) -> List[str]:
    seen = set()
    valid_paths = []
    for file_path in file_paths:
        path = Path(file_path)
        if not path.exists():
            logger.warning("File or directory not found: %s", file_path)
            continue
        if path.is_dir():
            for root, _dirs, files in os.walk(path, followlinks=True):
                for name in files:
                    if name.endswith(".py"):
                        py_path = Path(root) / name
                        resolved = py_path.resolve()
                        if resolved not in seen:
                            seen.add(resolved)
                            valid_paths.append(str(py_path))
        elif path.is_file():
            resolved = path.resolve()
            if resolved not in seen:
                seen.add(resolved)
                valid_paths.append(str(path))
        else:
            logger.warning("Not a file or directory: %s", file_path)
    return valid_paths


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(levelname)s: %(message)s",
    )


def extract_command(args: argparse.Namespace) -> int:
    _setup_logging(args.verbose)

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    db_path = output_dir / "source_graph.db"

    valid_paths = _collect_valid_paths(args.files)
    if not valid_paths:
        logger.error("No valid files to analyze.")
        return 1

    store = RelationStore(str(db_path))
    structure_extractor = PythonStructureExtractor()
    import_extractor = PythonImportExtractor(valid_paths)

    for file_path in valid_paths:
        logger.info("Extracting: %s", file_path)

        # Read and archive source content
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            logger.warning("Failed to read file %s: %s", file_path, e)
            continue

        content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
        store.add_source_content(content_hash, content, len(content))
        store.add_source_path(file_path, content_hash, os.path.getmtime(file_path))

        # Extract using archived content
        nodes, relations = structure_extractor.extract(content, file_path)
        for node in nodes:
            node.source_content_id = content_hash
        store.add_nodes(nodes)
        store.add_relations(relations)
        logger.info("  [structure] %d nodes, %d relations", len(nodes), len(relations))

        nodes, relations = import_extractor.extract(content, file_path)
        for node in nodes:
            node.source_content_id = content_hash
        store.add_nodes(nodes)
        store.add_relations(relations)
        logger.info("  [dependencies] %d nodes, %d relations", len(nodes), len(relations))

    if not store.get_nodes(NodeFilter()):
        logger.error("No nodes extracted. Nothing to save.")
        return 1

    logger.info("SQLite database written to: %s", db_path)
    return 0


def serve_command(args: argparse.Namespace) -> int:
    _setup_logging(args.verbose)

    db_path = Path(args.db_path)
    if not db_path.exists():
        logger.error("Database not found: %s", db_path)
        return 1

    from .server.config import configure
    from .server.app import app
    import uvicorn

    configure(str(db_path))
    uvicorn.run(app, host=args.host, port=args.port)
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="source-graph",
        description="Extract, store, and visualize code relationships.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {importlib.metadata.version('source-graphh')}",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose logging.",
    )

    subparsers = parser.add_subparsers(dest="command")

    extract_parser = subparsers.add_parser(
        "extract",
        help="Extract relationships from source files and save to a database.",
    )
    extract_parser.add_argument(
        "files",
        nargs="+",
        help="One or more Python source files or directories to analyze.",
    )
    extract_parser.add_argument(
        "--output",
        "-o",
        required=True,
        help="Output directory for SQLite database.",
    )

    serve_parser = subparsers.add_parser(
        "serve",
        help="Serve an interactive HTML report from an existing database.",
    )
    serve_parser.add_argument(
        "db_path",
        help="Path to the source_graph.db file.",
    )
    serve_parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)",
    )
    serve_parser.add_argument(
        "--port",
        type=int,
        default=8080,
        help="Port to listen on (default: 8080)",
    )

    args = parser.parse_args(argv)

    if args.command == "extract":
        return extract_command(args)
    elif args.command == "serve":
        return serve_command(args)
    else:
        parser.print_usage()
        return 1


if __name__ == "__main__":
    sys.exit(main())
