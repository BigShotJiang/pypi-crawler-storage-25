"""Extractor abstract base class."""

from abc import ABC, abstractmethod
from typing import List, Tuple

from .models import Node, Relation


class Extractor(ABC):
    """Abstract base class for source graph extractors.

    Each extractor is responsible for extracting nodes and relations
    from source files for a specific dimension.

    Contract:
    - `dimension` returns the dimension name this extractor produces.
    - `extract(file_path)` reads a single file and returns (nodes, relations).
    - All returned nodes must have globally unique IDs.
    - All returned relations must reference valid node IDs.
    """

    @property
    @abstractmethod
    def dimension(self) -> str:
        """Return the dimension name produced by this extractor, e.g. 'structure'."""
        pass

    @abstractmethod
    def extract(self, content: str, file_path: str) -> Tuple[List[Node], List[Relation]]:
        """Extract nodes and relations from a single file.

        Args:
            content: Raw source text of the file.
            file_path: Path to the source file (for FQN generation and import resolution).

        Returns:
            A tuple of (nodes, relations) found in the file.
        """
        pass
