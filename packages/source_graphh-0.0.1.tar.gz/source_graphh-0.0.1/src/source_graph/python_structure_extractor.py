"""Python structure extractor using the ast module."""

import ast
import hashlib
import logging
from typing import List, Tuple, Union

from .extractor import Extractor
from .models import Node, Range, Relation

logger = logging.getLogger(__name__)


class PythonStructureExtractor(Extractor):
    """Extracts file/class/function/method containment relations."""

    @property
    def dimension(self) -> str:
        return "structure"

    def _make_id(self, fqn: str) -> str:
        return hashlib.sha256(fqn.encode()).hexdigest()[:16]

    def _make_range(self, node: ast.AST) -> Range:
        end_lineno = getattr(node, "end_lineno", node.lineno)
        end_col_offset = getattr(node, "end_col_offset", 0)
        return Range(
            start_line=node.lineno,
            start_col=node.col_offset,
            end_line=end_lineno,
            end_col=end_col_offset,
        )

    def extract(self, content: str, file_path: str) -> Tuple[List[Node], List[Relation]]:
        nodes: List[Node] = []
        relations: List[Relation] = []

        try:
            tree = ast.parse(content)
        except SyntaxError as e:
            logger.warning("Syntax error in %s: %s", file_path, e)
            return nodes, relations

        file_fqn = file_path
        file_id = self._make_id(file_fqn)
        file_node = Node(
            id=file_id,
            name=file_path,
            kind="file",
            fqn=file_fqn,
            source_file=file_path,
            range=None,
            parent_id=None,
        )
        nodes.append(file_node)

        for body_node in tree.body:
            if isinstance(body_node, ast.ClassDef):
                self._extract_class(body_node, file_id, file_fqn, file_path, nodes, relations)
            elif isinstance(body_node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self._extract_function(body_node, file_id, file_fqn, file_path, nodes, relations)
            elif isinstance(body_node, ast.Assign):
                for target in body_node.targets:
                    if isinstance(target, ast.Name):
                        var_fqn = f"{file_fqn}/{target.id}"
                        var_id = self._make_id(var_fqn)
                        var_node = Node(
                            id=var_id,
                            name=target.id,
                            kind="variable",
                            fqn=var_fqn,
                            source_file=file_path,
                            range=self._make_range(body_node),
                            parent_id=file_id,
                        )
                        nodes.append(var_node)
                        relations.append(
                            Relation(
                                id=f"{file_id}-{var_id}",
                                source_id=file_id,
                                target_id=var_id,
                                type="file_contains_variable",
                                dimension=self.dimension,
                            )
                        )

        return nodes, relations

    def _extract_class(
        self,
        class_node: ast.ClassDef,
        parent_id: str,
        parent_fqn: str,
        file_path: str,
        nodes: List[Node],
        relations: List[Relation],
    ) -> None:
        class_fqn = f"{parent_fqn}/{class_node.name}"
        class_id = self._make_id(class_fqn)
        nodes.append(
            Node(
                id=class_id,
                name=class_node.name,
                kind="class",
                fqn=class_fqn,
                source_file=file_path,
                range=self._make_range(class_node),
                parent_id=parent_id,
            )
        )
        relations.append(
            Relation(
                id=f"{parent_id}-{class_id}",
                source_id=parent_id,
                target_id=class_id,
                type="file_contains_class" if parent_fqn == file_path else "class_contains_class",
                dimension=self.dimension,
            )
        )

        for body_node in class_node.body:
            if isinstance(body_node, ast.ClassDef):
                self._extract_class(body_node, class_id, class_fqn, file_path, nodes, relations)
            elif isinstance(body_node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self._extract_method(body_node, class_id, class_fqn, file_path, nodes, relations)
            elif isinstance(body_node, ast.Assign):
                for target in body_node.targets:
                    if isinstance(target, ast.Name):
                        var_fqn = f"{class_fqn}/{target.id}"
                        var_id = self._make_id(var_fqn)
                        nodes.append(
                            Node(
                                id=var_id,
                                name=target.id,
                                kind="variable",
                                fqn=var_fqn,
                                source_file=file_path,
                                range=self._make_range(body_node),
                                parent_id=class_id,
                            )
                        )
                        relations.append(
                            Relation(
                                id=f"{class_id}-{var_id}",
                                source_id=class_id,
                                target_id=var_id,
                                type="class_contains_variable",
                                dimension=self.dimension,
                            )
                        )

    def _extract_function(
        self,
        func_node: Union[ast.FunctionDef, ast.AsyncFunctionDef],
        parent_id: str,
        parent_fqn: str,
        file_path: str,
        nodes: List[Node],
        relations: List[Relation],
    ) -> None:
        func_fqn = f"{parent_fqn}/{func_node.name}"
        func_id = self._make_id(func_fqn)
        nodes.append(
            Node(
                id=func_id,
                name=func_node.name,
                kind="function",
                fqn=func_fqn,
                source_file=file_path,
                range=self._make_range(func_node),
                parent_id=parent_id,
            )
        )
        relations.append(
            Relation(
                id=f"{parent_id}-{func_id}",
                source_id=parent_id,
                target_id=func_id,
                type="file_contains_function",
                dimension=self.dimension,
            )
        )

        # Handle nested functions
        for body_node in func_node.body:
            if isinstance(body_node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self._extract_function(body_node, func_id, func_fqn, file_path, nodes, relations)

    def _extract_method(
        self,
        func_node: Union[ast.FunctionDef, ast.AsyncFunctionDef],
        parent_id: str,
        parent_fqn: str,
        file_path: str,
        nodes: List[Node],
        relations: List[Relation],
    ) -> None:
        func_fqn = f"{parent_fqn}/{func_node.name}"
        func_id = self._make_id(func_fqn)
        nodes.append(
            Node(
                id=func_id,
                name=func_node.name,
                kind="method",
                fqn=func_fqn,
                source_file=file_path,
                range=self._make_range(func_node),
                parent_id=parent_id,
            )
        )
        relations.append(
            Relation(
                id=f"{parent_id}-{func_id}",
                source_id=parent_id,
                target_id=func_id,
                type="class_contains_method",
                dimension=self.dimension,
            )
        )

        # Handle nested functions inside methods
        for body_node in func_node.body:
            if isinstance(body_node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self._extract_function(body_node, func_id, func_fqn, file_path, nodes, relations)
