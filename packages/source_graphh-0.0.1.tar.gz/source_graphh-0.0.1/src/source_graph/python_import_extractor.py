"""Python import dependency extractor using the ast module."""

import ast
import hashlib
import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .extractor import Extractor
from .models import Node, Relation

logger = logging.getLogger(__name__)


class PythonImportExtractor(Extractor):
    """Extracts cross-file import dependencies.

    Expects to be initialized with the full set of files being analyzed
    so that imported module names can be resolved to files within the set.
    """

    def __init__(self, all_file_paths: Optional[List[str]] = None) -> None:
        self._original_paths = list(all_file_paths or [])
        self._abs_to_orig: Dict[str, str] = {
            os.path.realpath(os.path.abspath(p)): p for p in self._original_paths
        }
        self._all_files: set = set(self._abs_to_orig.keys())
        self._package_root = self._compute_package_root(list(self._all_files))
        self._external_nodes: Dict[str, Node] = {}

    @property
    def dimension(self) -> str:
        return "dependencies"

    def _make_id(self, fqn: str) -> str:
        return hashlib.sha256(fqn.encode()).hexdigest()[:16]

    def _compute_lcp_of_dirs(self, dir_paths: List[str]) -> str:
        """Compute longest common directory path from directory paths."""
        if not dir_paths:
            return ""
        path_objs = [Path(p) for p in dir_paths]
        first_parts = path_objs[0].parts
        common = []
        for parts in zip(*[p.parts for p in path_objs]):
            if len(set(parts)) == 1:
                common.append(parts[0])
            else:
                break
        return str(Path(*common)) if common else ""

    def _compute_package_root(self, abs_paths: List[str]) -> str:
        """Infer package root from __init__.py locations.

        Finds directories containing __init__.py among analyzed files,
        then takes the LCP of their parent directories.
        Falls back to traditional file parent LCP if no __init__.py found.
        """
        package_dirs = set()
        for p in abs_paths:
            dir_path = Path(p).parent
            init_abs = os.path.realpath(os.path.abspath(dir_path / "__init__.py"))
            if init_abs in self._all_files:
                package_dirs.add(str(dir_path))

        if package_dirs:
            parent_dirs = [str(Path(d).parent) for d in package_dirs]
            return self._compute_lcp_of_dirs(parent_dirs)

        # Fallback: LCP of file parent dirs
        return self._compute_lcp_of_dirs([str(Path(p).parent) for p in abs_paths])

    def _resolve_module(self, module_name: str) -> Optional[str]:
        """Resolve module name to a file path in the analyzed set.

        Returns the original path (as passed to __init__) for consistent IDs.
        """
        if not module_name or not self._package_root:
            return None
        parts = module_name.split(".")

        candidate_py = Path(self._package_root) / Path(*parts).with_suffix(".py")
        candidate_init = Path(self._package_root) / Path(*parts) / "__init__.py"

        for candidate in [candidate_py, candidate_init]:
            resolved = str(candidate.resolve())
            if resolved in self._all_files:
                return self._abs_to_orig[resolved]
        return None

    def _get_external_node(self, module_name: str) -> Node:
        """Get or create a deduplicated external module node."""
        if module_name not in self._external_nodes:
            fqn = f"<external>/{module_name}"
            self._external_nodes[module_name] = Node(
                id=self._make_id(fqn),
                name=module_name,
                kind="external_module",
                fqn=fqn,
                source_file="<external>",
            )
        return self._external_nodes[module_name]

    def _module_path_for_file(self, abs_path: str) -> List[str]:
        """Compute module path parts for a file relative to package root.

        Regular .py: root/pkg/a.py -> ['pkg', 'a']
        __init__.py: root/pkg/__init__.py -> ['pkg']
        """
        rel = Path(abs_path).relative_to(self._package_root)
        parts = list(rel.with_suffix("").parts)
        if parts and parts[-1] == "__init__":
            parts = parts[:-1]
        return parts

    def _resolve_relative_module(
        self, file_path: str, level: int, module: Optional[str]
    ) -> Optional[str]:
        """Resolve a relative ImportFrom to an absolute module name.

        Returns the target module name (e.g., 'pkg.sub.module') or None
        if the relative import escapes the package root.
        """
        abs_path = os.path.realpath(os.path.abspath(file_path))
        module_path = self._module_path_for_file(abs_path)

        # current_package: module path minus the file itself (if not __init__)
        if Path(file_path).name == "__init__.py":
            current_package = module_path
        else:
            current_package = module_path[:-1] if module_path else []

        # level dots = backtrack (level - 1) from current package
        backtrack = level - 1
        if backtrack > len(current_package):
            return None

        target_package = current_package[: len(current_package) - backtrack]

        if module is None:
            target_module_parts = target_package
        else:
            target_module_parts = target_package + module.split(".")

        if not target_module_parts:
            return None

        return ".".join(target_module_parts)

    def extract(self, content: str, file_path: str) -> Tuple[List[Node], List[Relation]]:
        nodes: List[Node] = []
        relations: List[Relation] = []

        abs_path = os.path.abspath(file_path)
        orig_path = self._abs_to_orig.get(abs_path, file_path)

        try:
            tree = ast.parse(content)
        except SyntaxError as e:
            logger.warning("Syntax error in %s: %s", file_path, e)
            return nodes, relations

        # Source file node (consistent ID with PythonStructureExtractor)
        file_id = self._make_id(orig_path)
        file_node = Node(
            id=file_id,
            name=orig_path,
            kind="file",
            fqn=orig_path,
            source_file=orig_path,
        )
        nodes.append(file_node)

        # Collect imported modules: (module_name, is_relative)
        imported_modules: List[Tuple[str, bool]] = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imported_modules.append((alias.name, False))
            elif isinstance(node, ast.ImportFrom):
                if node.level == 0:
                    if node.module:
                        imported_modules.append((node.module, False))
                else:
                    module_name = self._resolve_relative_module(
                        file_path, node.level, node.module
                    )
                    if module_name is not None:
                        imported_modules.append((module_name, True))

        for module_name, is_relative in imported_modules:
            if not module_name:
                continue

            resolved_path = self._resolve_module(module_name)
            if resolved_path:
                target_id = self._make_id(resolved_path)
                target_node = Node(
                    id=target_id,
                    name=resolved_path,
                    kind="file",
                    fqn=resolved_path,
                    source_file=resolved_path,
                )
                nodes.append(target_node)
            else:
                target_node = self._get_external_node(module_name)
                nodes.append(target_node)
                target_id = target_node.id

            rel_props = {}
            if is_relative:
                rel_props["is_relative"] = True

            relations.append(
                Relation(
                    id=f"{file_id}-{target_id}",
                    source_id=file_id,
                    target_id=target_id,
                    type="file_imports_module",
                    dimension=self.dimension,
                    properties=rel_props,
                )
            )

        return nodes, relations
