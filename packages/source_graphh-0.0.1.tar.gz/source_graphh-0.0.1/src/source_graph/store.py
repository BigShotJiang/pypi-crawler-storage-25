"""RelationStore implementation backed by SQLite."""

import json
import shutil
import sqlite3
from typing import Dict, List, Optional, Protocol

from .models import Node, NodeFilter, Relation, RelationFilter, Range


class GraphStore(Protocol):
    """Protocol for graph data access."""

    def get_nodes(self, filter: NodeFilter) -> List[Node]:
        ...

    def get_relations(self, filter: RelationFilter) -> List[Relation]:
        ...

    def get_dimensions(self) -> List[str]:
        ...

    def get_source_contents(self) -> Dict[str, str]:
        ...

    def get_source_paths(self) -> List[Dict[str, str]]:
        ...


class RelationStore:
    """SQLite-backed store for nodes and relations."""

    def __init__(self, db_path: Optional[str] = None) -> None:
        self._db_path = db_path or ":memory:"
        self._conn = sqlite3.connect(self._db_path)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        cursor = self._conn.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS nodes (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                kind TEXT NOT NULL,
                fqn TEXT NOT NULL,
                source_file TEXT NOT NULL,
                start_line INTEGER,
                start_col INTEGER,
                end_line INTEGER,
                end_col INTEGER,
                parent_id TEXT,
                properties TEXT NOT NULL DEFAULT '{}',
                source_content_id TEXT
            )
            """
        )
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS relations (
                id TEXT PRIMARY KEY,
                source_id TEXT NOT NULL,
                target_id TEXT NOT NULL,
                type TEXT NOT NULL,
                dimension TEXT NOT NULL,
                properties TEXT NOT NULL DEFAULT '{}'
            )
            """
        )
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS source_contents (
                id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                file_size INTEGER NOT NULL
            )
            """
        )
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS source_paths (
                path TEXT NOT NULL,
                content_id TEXT NOT NULL,
                last_modified REAL,
                UNIQUE(path, content_id)
            )
            """
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_nodes_kind ON nodes(kind)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_nodes_source_file ON nodes(source_file)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_nodes_parent_id ON nodes(parent_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_relations_dimension ON relations(dimension)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_relations_source_id ON relations(source_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_relations_target_id ON relations(target_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_relations_type ON relations(type)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_source_paths_path ON source_paths(path)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_source_paths_content_id ON source_paths(content_id)"
        )
        # Migrate existing databases: add source_content_id if missing
        try:
            cursor.execute(
                "ALTER TABLE nodes ADD COLUMN source_content_id TEXT"
            )
        except sqlite3.OperationalError:
            pass  # Column already exists
        self._conn.commit()

    def _node_to_row(self, node: Node) -> tuple:
        range_data = None
        if node.range:
            range_data = json.dumps({
                "start_line": node.range.start_line,
                "start_col": node.range.start_col,
                "end_line": node.range.end_line,
                "end_col": node.range.end_col,
            })
        return (
            node.id,
            node.name,
            node.kind,
            node.fqn,
            node.source_file,
            range_data,
            node.parent_id,
            json.dumps(node.properties),
            node.source_content_id,
        )

    def _row_to_node(self, row: sqlite3.Row) -> Node:
        range_obj = None
        if row["start_line"] is not None:
            range_obj = Range(
                start_line=row["start_line"],
                start_col=row["start_col"],
                end_line=row["end_line"],
                end_col=row["end_col"],
            )
        return Node(
            id=row["id"],
            name=row["name"],
            kind=row["kind"],
            fqn=row["fqn"],
            source_file=row["source_file"],
            range=range_obj,
            parent_id=row["parent_id"],
            properties=json.loads(row["properties"]),
            source_content_id=row["source_content_id"],
        )

    def _relation_to_row(self, relation: Relation) -> tuple:
        return (
            relation.id,
            relation.source_id,
            relation.target_id,
            relation.type,
            relation.dimension,
            json.dumps(relation.properties),
        )

    def _row_to_relation(self, row: sqlite3.Row) -> Relation:
        return Relation(
            id=row["id"],
            source_id=row["source_id"],
            target_id=row["target_id"],
            type=row["type"],
            dimension=row["dimension"],
            properties=json.loads(row["properties"]),
        )

    def add_nodes(self, nodes: List[Node]) -> None:
        cursor = self._conn.cursor()
        for node in nodes:
            range_data = None
            if node.range:
                range_data = json.dumps({
                    "start_line": node.range.start_line,
                    "start_col": node.range.start_col,
                    "end_line": node.range.end_line,
                    "end_col": node.range.end_col,
                })
            cursor.execute(
                """
                INSERT OR REPLACE INTO nodes
                (id, name, kind, fqn, source_file, start_line, start_col, end_line, end_col, parent_id, properties, source_content_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    node.id,
                    node.name,
                    node.kind,
                    node.fqn,
                    node.source_file,
                    node.range.start_line if node.range else None,
                    node.range.start_col if node.range else None,
                    node.range.end_line if node.range else None,
                    node.range.end_col if node.range else None,
                    node.parent_id,
                    json.dumps(node.properties),
                    node.source_content_id,
                ),
            )
        self._conn.commit()

    def get_nodes(self, filter: NodeFilter) -> List[Node]:
        conditions = []
        params = []
        if filter.kind is not None:
            conditions.append("kind = ?")
            params.append(filter.kind)
        if filter.source_file is not None:
            conditions.append("source_file = ?")
            params.append(filter.source_file)
        if filter.parent_id is not None:
            conditions.append("parent_id = ?")
            params.append(filter.parent_id)

        query = "SELECT * FROM nodes"
        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        cursor = self._conn.execute(query, params)
        return [self._row_to_node(row) for row in cursor.fetchall()]

    def add_relations(self, relations: List[Relation]) -> None:
        cursor = self._conn.cursor()
        for relation in relations:
            cursor.execute(
                """
                INSERT OR REPLACE INTO relations
                (id, source_id, target_id, type, dimension, properties)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    relation.id,
                    relation.source_id,
                    relation.target_id,
                    relation.type,
                    relation.dimension,
                    json.dumps(relation.properties),
                ),
            )
        self._conn.commit()

    def get_relations(self, filter: RelationFilter) -> List[Relation]:
        conditions = []
        params = []
        if filter.type is not None:
            conditions.append("type = ?")
            params.append(filter.type)
        if filter.dimension is not None:
            conditions.append("dimension = ?")
            params.append(filter.dimension)
        if filter.source_id is not None:
            conditions.append("source_id = ?")
            params.append(filter.source_id)
        if filter.target_id is not None:
            conditions.append("target_id = ?")
            params.append(filter.target_id)

        query = "SELECT * FROM relations"
        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        cursor = self._conn.execute(query, params)
        relations = [self._row_to_relation(row) for row in cursor.fetchall()]

        if filter.source_file is not None:
            # Need to filter by source_file of related nodes
            node_ids = set()
            for rel in relations:
                node_ids.add(rel.source_id)
                node_ids.add(rel.target_id)
            if node_ids:
                placeholders = ", ".join("?" for _ in node_ids)
                node_cursor = self._conn.execute(
                    f"SELECT id, source_file FROM nodes WHERE id IN ({placeholders})",
                    list(node_ids),
                )
                node_files = {row["id"]: row["source_file"] for row in node_cursor.fetchall()}
            else:
                node_files = {}
            relations = [
                rel for rel in relations
                if node_files.get(rel.source_id) == filter.source_file
                or node_files.get(rel.target_id) == filter.source_file
            ]

        return relations

    def get_dimensions(self) -> List[str]:
        cursor = self._conn.execute(
            "SELECT DISTINCT dimension FROM relations ORDER BY dimension"
        )
        return [row["dimension"] for row in cursor.fetchall()]

    def add_source_content(self, id: str, content: str, file_size: int) -> None:
        cursor = self._conn.cursor()
        cursor.execute(
            """
            INSERT OR IGNORE INTO source_contents (id, content, file_size)
            VALUES (?, ?, ?)
            """,
            (id, content, file_size),
        )
        self._conn.commit()

    def add_source_path(self, path: str, content_id: str, last_modified: float) -> None:
        cursor = self._conn.cursor()
        cursor.execute(
            """
            INSERT OR REPLACE INTO source_paths (path, content_id, last_modified)
            VALUES (?, ?, ?)
            """,
            (path, content_id, last_modified),
        )
        self._conn.commit()

    def get_source_contents(self) -> Dict[str, str]:
        cursor = self._conn.execute("SELECT id, content FROM source_contents")
        return {row["id"]: row["content"] for row in cursor.fetchall()}

    def get_source_paths(self) -> List[Dict[str, str]]:
        cursor = self._conn.execute("SELECT path, content_id FROM source_paths")
        return [{"path": row["path"], "content_id": row["content_id"]} for row in cursor.fetchall()]

    def save(self, path: str) -> None:
        if self._db_path == ":memory:":
            # Dump in-memory database to file
            target_conn = sqlite3.connect(path)
            with target_conn:
                self._conn.backup(target_conn)
            target_conn.close()
        else:
            self._conn.close()
            shutil.copy2(self._db_path, path)
            self._conn = sqlite3.connect(self._db_path)
            self._conn.row_factory = sqlite3.Row

    def load(self, path: str) -> None:
        if self._conn:
            self._conn.close()
        if self._db_path != ":memory:":
            shutil.copy2(path, self._db_path)
            self._conn = sqlite3.connect(self._db_path)
        else:
            source_conn = sqlite3.connect(path)
            self._conn = sqlite3.connect(":memory:")
            with self._conn:
                source_conn.backup(self._conn)
            source_conn.close()
        self._conn.row_factory = sqlite3.Row
        self._init_schema()
