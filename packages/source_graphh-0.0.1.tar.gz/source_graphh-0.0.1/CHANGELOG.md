# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.0.1] - 2026-05-20

### Added
- Initial PyPI release as `source-graphh`.
- CLI commands: `extract`, `serve`.
- Structure and dependency extraction for Python source files.
- SQLite-based knowledge graph storage.
- Web-based visualization with FastAPI serve mode.
