#!/bin/bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"

export PYTHONPATH="${PROJECT_ROOT}/src:${PYTHONPATH:-}"

rm -rf build/output/
mkdir -p build/output/

PYTHON="${PROJECT_ROOT}/.venv/bin/python"

$PYTHON -m source_graph.cli extract \
    src/ \
    -o build/output

echo ""
echo "=== Starting server ==="
echo "Open http://127.0.0.1:8080 in your browser"
echo "Press Ctrl+C to stop"
echo ""

$PYTHON -m source_graph.cli serve \
    build/output/source_graph.db \
    --host 127.0.0.1 \
    --port 8080
