#!/bin/bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"

export PYTHONPATH="${PROJECT_ROOT}/src:${PYTHONPATH:-}"

rm -rf build/output/
mkdir -p build/output/

echo "=== Extract ==="
PYTHON="${PROJECT_ROOT}/.venv/bin/python"

$PYTHON -m source_graph.cli extract \
    src/ \
    -o build/output

echo ""
echo "=== Serve ==="
# Start server in background on a fixed port
$PYTHON -m source_graph.cli serve \
    build/output/source_graph.db \
    --host 127.0.0.1 \
    --port 18080 &
SERVER_PID=$!

# Give the server a moment to start
sleep 1

cleanup() {
    echo ""
    echo "=== Cleanup ==="
    kill "$SERVER_PID" 2>/dev/null || true
    wait "$SERVER_PID" 2>/dev/null || true
}
trap cleanup EXIT

echo "Server PID: $SERVER_PID"
echo ""

echo "=== Test: GET / ==="
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:18080/)
if [ "$HTTP_CODE" = "200" ]; then
    echo "✓ Status 200"
else
    echo "✗ Unexpected status: $HTTP_CODE"
    exit 1
fi

echo "=== Test: HTML content ==="
TMP_HTML=$(mktemp)
curl -s http://127.0.0.1:18080/ > "$TMP_HTML"

if grep -q "<!DOCTYPE html>" "$TMP_HTML"; then
    echo "✓ Contains <!DOCTYPE html>"
else
    echo "✗ Missing <!DOCTYPE html>"
    rm -f "$TMP_HTML"
    exit 1
fi

if grep -q "Source Graph" "$TMP_HTML"; then
    echo "✓ Contains 'Source Graph'"
else
    echo "✗ Missing 'Source Graph'"
    rm -f "$TMP_HTML"
    exit 1
fi

rm -f "$TMP_HTML"

echo ""
echo "=== Test: GET /api/data ==="
TMP_JSON=$(mktemp)
HTTP_CODE=$(curl -s -o "$TMP_JSON" -w "%{http_code}" http://127.0.0.1:18080/api/data)
if [ "$HTTP_CODE" = "200" ]; then
    echo "✓ Status 200"
else
    echo "✗ Unexpected status: $HTTP_CODE"
    rm -f "$TMP_JSON"
    exit 1
fi

if grep -q '"dimensions"' "$TMP_JSON"; then
    echo "✓ JSON contains dimensions"
else
    echo "✗ JSON missing dimensions"
    rm -f "$TMP_JSON"
    exit 1
fi

rm -f "$TMP_JSON"

echo ""
echo "=== Test: GET /static/app.js ==="
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:18080/static/app.js)
if [ "$HTTP_CODE" = "200" ]; then
    echo "✓ Status 200"
else
    echo "✗ Unexpected status: $HTTP_CODE"
    exit 1
fi

echo "=== Test: GET /static/style.css ==="
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:18080/static/style.css)
if [ "$HTTP_CODE" = "200" ]; then
    echo "✓ Status 200"
else
    echo "✗ Unexpected status: $HTTP_CODE"
    exit 1
fi

echo ""
echo "=== All serve tests passed ==="
