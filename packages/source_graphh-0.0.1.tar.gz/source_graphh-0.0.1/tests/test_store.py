"""Tests for RelationStore."""

import tempfile
import os

from source_graph.models import Node, Relation, Range, NodeFilter, RelationFilter
from source_graph.store import RelationStore


def test_add_and_get_nodes():
    store = RelationStore()
    node = Node(
        id="n1",
        name="foo",
        kind="function",
        fqn="foo",
        source_file="test.py",
        range=Range(1, 0, 5, 10),
    )
    store.add_nodes([node])
    results = store.get_nodes(NodeFilter(kind="function"))
    assert len(results) == 1
    assert results[0].name == "foo"


def test_get_nodes_filter_source_file():
    store = RelationStore()
    store.add_nodes([
        Node(id="n1", name="a", kind="function", fqn="a", source_file="a.py"),
        Node(id="n2", name="b", kind="function", fqn="b", source_file="b.py"),
    ])
    results = store.get_nodes(NodeFilter(source_file="a.py"))
    assert len(results) == 1
    assert results[0].name == "a"


def test_add_and_get_relations():
    store = RelationStore()
    store.add_nodes([
        Node(id="n1", name="a", kind="file", fqn="a.py", source_file="a.py"),
        Node(id="n2", name="b", kind="function", fqn="b", source_file="a.py"),
    ])
    store.add_relations([
        Relation(id="r1", source_id="n1", target_id="n2", type="contains", dimension="structure"),
    ])
    results = store.get_relations(RelationFilter(dimension="structure"))
    assert len(results) == 1
    assert results[0].type == "contains"


def test_get_dimensions():
    store = RelationStore()
    store.add_relations([
        Relation(id="r1", source_id="n1", target_id="n2", type="contains", dimension="structure"),
        Relation(id="r2", source_id="n1", target_id="n2", type="calls", dimension="reference"),
    ])
    dims = store.get_dimensions()
    assert dims == ["reference", "structure"]


def test_save_and_load():
    store = RelationStore()
    node = Node(
        id="n1",
        name="foo",
        kind="function",
        fqn="foo",
        source_file="test.py",
        range=Range(1, 0, 5, 10),
        properties={"async": True},
    )
    relation = Relation(
        id="r1",
        source_id="n1",
        target_id="n1",
        type="self",
        dimension="test",
        properties={"confidence": 0.9},
    )
    store.add_nodes([node])
    store.add_relations([relation])

    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    store.save(path)

    store2 = RelationStore()
    store2.load(path)

    nodes = store2.get_nodes(NodeFilter())
    assert len(nodes) == 1
    assert nodes[0].properties == {"async": True}

    relations = store2.get_relations(RelationFilter())
    assert len(relations) == 1
    assert relations[0].properties == {"confidence": 0.9}

    os.unlink(path)


def test_add_and_get_source_contents():
    store = RelationStore()
    store.add_source_content("abc123", "import os\n", 9)
    contents = store.get_source_contents()
    assert contents == {"abc123": "import os\n"}


def test_add_and_get_source_paths():
    store = RelationStore()
    store.add_source_path("src/cli.py", "abc123", 1234567890.0)
    paths = store.get_source_paths()
    assert len(paths) == 1
    assert paths[0]["path"] == "src/cli.py"
    assert paths[0]["content_id"] == "abc123"


def test_source_paths_uniqueness():
    store = RelationStore()
    store.add_source_path("src/a.py", "hash1", 1000.0)
    store.add_source_path("src/a.py", "hash1", 2000.0)
    paths = store.get_source_paths()
    # Same (path, content_id) should not create duplicate
    assert len(paths) == 1
    # But last_modified should be updated (INSERT OR REPLACE)
    # Actually, with same values, it just replaces


def test_content_deduplication():
    store = RelationStore()
    store.add_source_content("hash1", "x = 1\n", 6)
    store.add_source_content("hash1", "x = 1\n", 6)
    store.add_source_path("src/a.py", "hash1", 1000.0)
    store.add_source_path("src/b.py", "hash1", 1000.0)

    contents = store.get_source_contents()
    assert len(contents) == 1
    assert contents["hash1"] == "x = 1\n"

    paths = store.get_source_paths()
    assert len(paths) == 2


def test_node_with_source_content_id():
    store = RelationStore()
    node = Node(
        id="n1",
        name="foo",
        kind="function",
        fqn="foo",
        source_file="test.py",
        source_content_id="abc123",
    )
    store.add_nodes([node])
    results = store.get_nodes(NodeFilter())
    assert len(results) == 1
    assert results[0].source_content_id == "abc123"


def test_source_contents_persisted_on_save_load():
    store = RelationStore()
    store.add_source_content("hash1", "def foo(): pass\n", 17)
    store.add_source_path("src/a.py", "hash1", 1000.0)

    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    store.save(path)

    store2 = RelationStore()
    store2.load(path)

    contents = store2.get_source_contents()
    assert contents == {"hash1": "def foo(): pass\n"}

    paths = store2.get_source_paths()
    assert len(paths) == 1
    assert paths[0]["path"] == "src/a.py"

    os.unlink(path)
