"""Tests for CLI subcommands."""

import os
import tempfile
from pathlib import Path

from source_graph.cli import _collect_valid_paths, main
from source_graph.models import Node, NodeFilter, Relation
from source_graph.store import RelationStore


def test_extract_subcommand_produces_db():
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a simple Python file
        src_file = Path(tmpdir) / "test.py"
        src_file.write_text("def foo(): pass\n")

        output_dir = Path(tmpdir) / "output"
        output_dir.mkdir()

        ret = main(["extract", str(src_file), "-o", str(output_dir)])
        assert ret == 0

        db_path = output_dir / "source_graph.db"
        assert db_path.exists()

        report_path = output_dir / "report.html"
        assert not report_path.exists()


def test_extract_no_valid_files_exits_nonzero():
    with tempfile.TemporaryDirectory() as tmpdir:
        output_dir = Path(tmpdir) / "output"
        output_dir.mkdir()

        ret = main(["extract", "nonexistent.py", "-o", str(output_dir)])
        assert ret != 0

        db_path = output_dir / "source_graph.db"
        assert not db_path.exists()


def test_serve_missing_database_exits_nonzero():
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "nonexistent.db"
        ret = main(["serve", str(db_path)])
        assert ret != 0


def test_missing_subcommand_prints_usage():
    ret = main([])
    assert ret != 0


def test_extract_with_directory_argument():
    with tempfile.TemporaryDirectory() as tmpdir:
        src_dir = Path(tmpdir) / "src"
        sub_dir = src_dir / "subpackage"
        sub_dir.mkdir(parents=True)

        (src_dir / "root.py").write_text("def root(): pass\n")
        (sub_dir / "nested.py").write_text("def nested(): pass\n")

        output_dir = Path(tmpdir) / "output"
        output_dir.mkdir()

        ret = main(["extract", str(src_dir), "-o", str(output_dir)])
        assert ret == 0

        db_path = output_dir / "source_graph.db"
        assert db_path.exists()


def test_extract_mixed_input_deduplicates():
    with tempfile.TemporaryDirectory() as tmpdir:
        src_dir = Path(tmpdir) / "src"
        src_dir.mkdir()

        (src_dir / "module.py").write_text("def func(): pass\n")

        output_dir = Path(tmpdir) / "output"
        output_dir.mkdir()

        # Pass both the directory and the specific file inside it
        ret = main(["extract", str(src_dir), str(src_dir / "module.py"), "-o", str(output_dir)])
        assert ret == 0

        db_path = output_dir / "source_graph.db"
        assert db_path.exists()


def test_extract_archives_source_contents():
    with tempfile.TemporaryDirectory() as tmpdir:
        src_file = Path(tmpdir) / "test.py"
        src_file.write_text("def foo(): pass\n")

        output_dir = Path(tmpdir) / "output"
        output_dir.mkdir()

        ret = main(["extract", str(src_file), "-o", str(output_dir)])
        assert ret == 0

        db_path = output_dir / "source_graph.db"
        store = RelationStore(str(db_path))

        contents = store.get_source_contents()
        assert len(contents) == 1
        content = list(contents.values())[0]
        assert "def foo(): pass" in content

        paths = store.get_source_paths()
        assert len(paths) == 1
        assert paths[0]["path"] == str(src_file)

        nodes = store.get_nodes(NodeFilter())
        for node in nodes:
            if node.kind != "file":
                assert node.source_content_id is not None


def test_extract_embeds_source_data():
    with tempfile.TemporaryDirectory() as tmpdir:
        src_file = Path(tmpdir) / "test.py"
        src_file.write_text("class Foo:\n    pass\n")

        output_dir = Path(tmpdir) / "output"
        output_dir.mkdir()

        ret = main(["extract", str(src_file), "-o", str(output_dir)])
        assert ret == 0

        db_path = output_dir / "source_graph.db"
        store = RelationStore(str(db_path))

        contents = store.get_source_contents()
        assert len(contents) == 1
        assert "class Foo:" in list(contents.values())[0]

        paths = store.get_source_paths()
        assert len(paths) == 1


def test_collect_valid_paths_with_symlinked_directory():
    with tempfile.TemporaryDirectory() as tmpdir:
        real_dir = Path(tmpdir) / "real"
        real_dir.mkdir()
        (real_dir / "script.py").write_text("x = 1\n")

        link_dir = Path(tmpdir) / "link"
        os.symlink(real_dir, link_dir)

        paths = _collect_valid_paths([str(link_dir)])
        assert len(paths) == 1
        assert paths[0].endswith("script.py")
