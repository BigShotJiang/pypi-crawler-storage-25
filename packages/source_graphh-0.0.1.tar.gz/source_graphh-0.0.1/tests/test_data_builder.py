"""Tests for data-building logic."""

import json
import tempfile

from source_graph.data_builder import (
    build_all_data,
    build_dependency_data,
    build_dependency_map_data,
    build_graph_data,
    build_tree_data,
)
from source_graph.models import Node, Relation, Range
from source_graph.store import RelationStore


def test_tree_data_structure():
    store = RelationStore()
    store.add_nodes([
        Node(id="f1", name="test.py", kind="file", fqn="test.py", source_file="test.py"),
        Node(id="c1", name="Foo", kind="class", fqn="test.py/Foo", source_file="test.py", range=Range(1, 0, 10, 1)),
        Node(id="m1", name="bar", kind="method", fqn="test.py/Foo/bar", source_file="test.py", range=Range(2, 4, 5, 20)),
    ])
    store.add_relations([
        Relation(id="r1", source_id="f1", target_id="c1", type="file_contains_class", dimension="structure"),
        Relation(id="r2", source_id="c1", target_id="m1", type="class_contains_method", dimension="structure"),
    ])

    tree_data = build_tree_data(store, "structure")

    assert len(tree_data) == 1
    root = tree_data[0]
    assert root["name"] == "test.py"
    assert root["kind"] == "file"
    assert len(root["children"]) == 1
    assert root["children"][0]["name"] == "Foo"
    assert root["children"][0]["children"][0]["name"] == "bar"


def test_dependency_graph_structured_output():
    """Dependencies dimension returns structured data."""
    store = RelationStore()
    store.add_nodes([
        Node(id="a", name="a.py", kind="file", fqn="a.py", source_file="a.py"),
        Node(id="b", name="b.py", kind="file", fqn="b.py", source_file="b.py"),
        Node(id="c", name="c.py", kind="file", fqn="c.py", source_file="c.py"),
        Node(id="os", name="os", kind="external_module", fqn="os", source_file="<external>"),
    ])
    store.add_relations([
        Relation(id="r1", source_id="a", target_id="b", type="file_imports_module", dimension="dependencies"),
        Relation(id="r2", source_id="a", target_id="os", type="file_imports_module", dimension="dependencies"),
        Relation(id="r3", source_id="b", target_id="c", type="file_imports_module", dimension="dependencies"),
        Relation(id="r4", source_id="c", target_id="os", type="file_imports_module", dimension="dependencies"),
    ])

    tree_data = build_dependency_data(store, "dependencies")

    # Verify tree nodes metadata
    assert tree_data["nodes"]["a.py"]["is_external"] is False
    assert tree_data["nodes"]["a.py"]["internal_out_degree"] == 1  # only b.py
    assert tree_data["nodes"]["b.py"]["internal_out_degree"] == 1  # c.py
    assert tree_data["nodes"]["c.py"]["internal_out_degree"] == 0  # only os (external)
    assert tree_data["nodes"]["os"]["is_external"] is True
    assert tree_data["nodes"]["os"]["internal_out_degree"] == 0

    # Verify tree edges
    edge_pairs = [(e["source"], e["target"], e["is_external"]) for e in tree_data["edges"]]
    assert ("a.py", "b.py", False) in edge_pairs
    assert ("a.py", "os", True) in edge_pairs
    assert ("b.py", "c.py", False) in edge_pairs
    assert ("c.py", "os", True) in edge_pairs

    # Verify map data
    map_data = build_dependency_map_data(store, "dependencies")
    assert "nodes" in map_data
    assert "edges" in map_data
    map_node_names = [n["names"][0] for n in map_data["nodes"]]
    assert "a.py" in map_node_names
    assert "b.py" in map_node_names
    assert "c.py" in map_node_names
    # os should not be in map (external filtered out)
    assert "os" not in map_node_names

    # Verify graph data
    graph_data = build_graph_data(store, "dependencies")
    assert "nodes" in graph_data
    assert "edges" in graph_data
    graph_node_ids = {n["id"] for n in graph_data["nodes"]}
    assert "a.py" in graph_node_ids
    assert "b.py" in graph_node_ids
    assert "c.py" in graph_node_ids
    assert "os" not in graph_node_ids  # external filtered out
    graph_edge_pairs = {(e["source"], e["target"]) for e in graph_data["edges"]}
    assert ("a.py", "b.py") in graph_edge_pairs
    assert ("b.py", "c.py") in graph_edge_pairs


def test_dependency_graph_root_ordering():
    """Root nodes are sorted by internal out-degree ascending."""
    store = RelationStore()
    store.add_nodes([
        Node(id="a", name="a.py", kind="file", fqn="a.py", source_file="a.py"),
        Node(id="b", name="b.py", kind="file", fqn="b.py", source_file="b.py"),
        Node(id="c", name="c.py", kind="file", fqn="c.py", source_file="c.py"),
        Node(id="os", name="os", kind="external_module", fqn="os", source_file="<external>"),
    ])
    store.add_relations([
        Relation(id="r1", source_id="a", target_id="b", type="file_imports_module", dimension="dependencies"),
        Relation(id="r2", source_id="a", target_id="os", type="file_imports_module", dimension="dependencies"),
        Relation(id="r3", source_id="b", target_id="c", type="file_imports_module", dimension="dependencies"),
        Relation(id="r4", source_id="c", target_id="os", type="file_imports_module", dimension="dependencies"),
    ])

    tree_data = build_dependency_data(store, "dependencies")
    roots = tree_data["roots"]
    # c.py has 0 internal deps, a.py and b.py have 1 each
    # c.py should be first; a.py and b.py tie-break alphabetically
    assert roots[0] == "c.py"
    assert roots[1:] == ["a.py", "b.py"]


def test_dependency_map_filters_external():
    """Map view excludes external modules and external edges."""
    store = RelationStore()
    store.add_nodes([
        Node(id="a", name="a.py", kind="file", fqn="a.py", source_file="a.py"),
        Node(id="b", name="b.py", kind="file", fqn="b.py", source_file="b.py"),
        Node(id="os", name="os", kind="external_module", fqn="os", source_file="<external>"),
    ])
    store.add_relations([
        Relation(id="r1", source_id="a", target_id="b", type="file_imports_module", dimension="dependencies"),
        Relation(id="r2", source_id="a", target_id="os", type="file_imports_module", dimension="dependencies"),
    ])

    map_data = build_dependency_map_data(store, "dependencies")

    assert len(map_data["nodes"]) == 2
    node_names = [n["names"][0] for n in map_data["nodes"]]
    assert "a.py" in node_names
    assert "b.py" in node_names
    assert "os" not in node_names

    assert len(map_data["edges"]) == 1
    # Verify edge connects a.py -> b.py via SCC IDs
    scc_map = {tuple(n["names"]): n["id"] for n in map_data["nodes"]}
    a_scc = scc_map[("a.py",)]
    b_scc = scc_map[("b.py",)]
    assert map_data["edges"][0]["source"] == a_scc
    assert map_data["edges"][0]["target"] == b_scc


def test_dependency_map_layering():
    """Map view layers nodes by longest-path distance to leaf."""
    store = RelationStore()
    store.add_nodes([
        Node(id="a", name="a.py", kind="file", fqn="a.py", source_file="a.py"),
        Node(id="b", name="b.py", kind="file", fqn="b.py", source_file="b.py"),
        Node(id="c", name="c.py", kind="file", fqn="c.py", source_file="c.py"),
    ])
    store.add_relations([
        Relation(id="r1", source_id="a", target_id="b", type="file_imports_module", dimension="dependencies"),
        Relation(id="r2", source_id="b", target_id="c", type="file_imports_module", dimension="dependencies"),
    ])

    map_data = build_dependency_map_data(store, "dependencies")

    layers = {n["names"][0]: n["layer"] for n in map_data["nodes"]}
    # c.py is leaf (layer 0), b.py is above (layer 1), a.py is top (layer 2)
    assert layers["c.py"] == 0
    assert layers["b.py"] == 1
    assert layers["a.py"] == 2


def test_dependency_map_scc_compression():
    """Map view compresses strongly connected components."""
    store = RelationStore()
    store.add_nodes([
        Node(id="a", name="a.py", kind="file", fqn="a.py", source_file="a.py"),
        Node(id="b", name="b.py", kind="file", fqn="b.py", source_file="b.py"),
        Node(id="c", name="c.py", kind="file", fqn="c.py", source_file="c.py"),
    ])
    store.add_relations([
        Relation(id="r1", source_id="a", target_id="b", type="file_imports_module", dimension="dependencies"),
        Relation(id="r2", source_id="b", target_id="a", type="file_imports_module", dimension="dependencies"),
        Relation(id="r3", source_id="a", target_id="c", type="file_imports_module", dimension="dependencies"),
    ])

    map_data = build_dependency_map_data(store, "dependencies")

    # a.py and b.py form an SCC, c.py is separate
    assert len(map_data["nodes"]) == 2
    scc_names = [tuple(n["names"]) for n in map_data["nodes"]]
    assert ("a.py", "b.py") in scc_names or ("b.py", "a.py") in scc_names
    assert ("c.py",) in scc_names

    # Only one edge from SCC to c.py
    assert len(map_data["edges"]) == 1


def test_dependency_map_alphabetical_ordering():
    """Nodes within the same layer are sorted alphabetically."""
    store = RelationStore()
    store.add_nodes([
        Node(id="a", name="a.py", kind="file", fqn="a.py", source_file="a.py"),
        Node(id="b", name="b.py", kind="file", fqn="b.py", source_file="b.py"),
        Node(id="c", name="c.py", kind="file", fqn="c.py", source_file="c.py"),
    ])
    store.add_relations([
        Relation(id="r1", source_id="a", target_id="c", type="file_imports_module", dimension="dependencies"),
        Relation(id="r2", source_id="b", target_id="c", type="file_imports_module", dimension="dependencies"),
    ])

    map_data = build_dependency_map_data(store, "dependencies")

    # a.py and b.py are in the same layer (layer 1), c.py is layer 0
    layer1_nodes = [n for n in map_data["nodes"] if n["layer"] == 1]
    assert len(layer1_nodes) == 2
    assert layer1_nodes[0]["names"][0] == "a.py"
    assert layer1_nodes[1]["names"][0] == "b.py"


def test_build_all_data():
    """build_all_data assembles complete payload."""
    store = RelationStore()
    store.add_nodes([
        Node(id="f1", name="test.py", kind="file", fqn="test.py", source_file="test.py"),
        Node(id="c1", name="Foo", kind="class", fqn="test.py/Foo", source_file="test.py"),
    ])
    store.add_relations([
        Relation(id="r1", source_id="f1", target_id="c1", type="file_contains_class", dimension="structure"),
    ])

    payload = build_all_data(store)

    assert "dimensions" in payload
    assert "structure" in payload["dimensions"]
    assert payload["dimensions"]["structure"]["type"] == "tree"
    assert "data" in payload["dimensions"]["structure"]
    assert "sourceContents" in payload
    assert "sourcePaths" in payload
