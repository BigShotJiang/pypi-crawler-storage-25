"""Tests for PythonStructureExtractor."""

import tempfile
import os

from source_graph.python_structure_extractor import PythonStructureExtractor


def _write_temp_file(content: str) -> str:
    fd, path = tempfile.mkstemp(suffix=".py")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
    except:
        os.close(fd)
        raise
    return path


def test_simple_class():
    code = """
class Foo:
    def bar(self):
        pass
"""
    path = _write_temp_file(code)
    extractor = PythonStructureExtractor()
    nodes, relations = extractor.extract(code, path)

    kinds = {n.kind for n in nodes}
    assert kinds == {"file", "class", "method"}

    class_node = [n for n in nodes if n.kind == "class"][0]
    assert class_node.name == "Foo"

    method_node = [n for n in nodes if n.kind == "method"][0]
    assert method_node.name == "bar"
    assert method_node.parent_id == class_node.id

    rel_types = {r.type for r in relations}
    assert "file_contains_class" in rel_types
    assert "class_contains_method" in rel_types

    os.unlink(path)


def test_nested_classes():
    code = """
class Outer:
    class Inner:
        def inner_method(self):
            pass
"""
    path = _write_temp_file(code)
    extractor = PythonStructureExtractor()
    nodes, relations = extractor.extract(code, path)

    class_nodes = [n for n in nodes if n.kind == "class"]
    assert len(class_nodes) == 2

    inner = [n for n in class_nodes if n.name == "Inner"][0]
    outer = [n for n in class_nodes if n.name == "Outer"][0]
    assert inner.parent_id == outer.id

    rel = [r for r in relations if r.target_id == inner.id][0]
    assert rel.type == "class_contains_class"

    os.unlink(path)


def test_nested_functions():
    code = """
def outer():
    def inner():
        pass
"""
    path = _write_temp_file(code)
    extractor = PythonStructureExtractor()
    nodes, relations = extractor.extract(code, path)

    func_nodes = [n for n in nodes if n.kind == "function"]
    assert len(func_nodes) == 2

    inner = [n for n in func_nodes if n.name == "inner"][0]
    outer = [n for n in func_nodes if n.name == "outer"][0]
    assert inner.parent_id == outer.id

    os.unlink(path)


def test_empty_file():
    path = _write_temp_file("")
    extractor = PythonStructureExtractor()
    nodes, relations = extractor.extract("", path)

    assert len(nodes) == 1
    assert nodes[0].kind == "file"
    assert len(relations) == 0

    os.unlink(path)


def test_syntax_error():
    code = "class Foo(\n"
    path = _write_temp_file(code)
    extractor = PythonStructureExtractor()
    nodes, relations = extractor.extract(code, path)

    assert len(nodes) == 0
    assert len(relations) == 0

    os.unlink(path)


def test_module_level_function():
    code = """
def standalone():
    pass
"""
    path = _write_temp_file(code)
    extractor = PythonStructureExtractor()
    nodes, relations = extractor.extract(code, path)

    func = [n for n in nodes if n.kind == "function"][0]
    file_node = [n for n in nodes if n.kind == "file"][0]
    assert func.parent_id == file_node.id

    rel = [r for r in relations if r.target_id == func.id][0]
    assert rel.type == "file_contains_function"

    os.unlink(path)


def test_async_function_and_method():
    code = """
async def top_level():
    pass

class MyClass:
    async def my_method(self):
        pass
"""
    path = _write_temp_file(code)
    extractor = PythonStructureExtractor()
    nodes, relations = extractor.extract(code, path)

    func = [n for n in nodes if n.name == "top_level"][0]
    assert func.kind == "function"

    method = [n for n in nodes if n.name == "my_method"][0]
    assert method.kind == "method"

    os.unlink(path)
