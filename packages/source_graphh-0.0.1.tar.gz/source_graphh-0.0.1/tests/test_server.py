"""Tests for FastAPI server."""

import tempfile
from pathlib import Path

from fastapi.testclient import TestClient

from source_graph.models import Node, Relation
from source_graph.server.app import app
from source_graph.server.config import configure
from source_graph.store import RelationStore


def test_root_returns_html():
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "source_graph.db"
        store = RelationStore(str(db_path))
        store.add_nodes([
            Node(id="f1", name="test.py", kind="file", fqn="test.py", source_file="test.py"),
        ])
        store.add_relations([])

        configure(str(db_path))
        client = TestClient(app)

        response = client.get("/")
        assert response.status_code == 200
        assert response.headers["content-type"].startswith("text/html")
        assert "<!DOCTYPE html>" in response.text
        assert "Source Graph" in response.text


def test_static_files_served():
    configure("")
    client = TestClient(app)

    response = client.get("/static/app.js")
    assert response.status_code == 200
    assert "javascript" in response.headers["content-type"]

    response = client.get("/static/style.css")
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/css")

    response = client.get("/static/index.html")
    assert response.status_code == 200


def test_api_data_returns_json():
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "source_graph.db"
        store = RelationStore(str(db_path))
        store.add_nodes([
            Node(id="f1", name="test.py", kind="file", fqn="test.py", source_file="test.py"),
            Node(id="c1", name="Foo", kind="class", fqn="test.py/Foo", source_file="test.py"),
        ])
        store.add_relations([
            Relation(id="r1", source_id="f1", target_id="c1", type="file_contains_class", dimension="structure"),
        ])

        configure(str(db_path))
        client = TestClient(app)

        response = client.get("/api/data")
        assert response.status_code == 200
        assert response.headers["content-type"].startswith("application/json")

        data = response.json()
        assert "dimensions" in data
        assert "structure" in data["dimensions"]
        assert data["dimensions"]["structure"]["type"] == "tree"
        assert "sourceContents" in data
        assert "sourcePaths" in data
