"""Tests for PythonImportExtractor."""

import os
import tempfile

from source_graph.python_import_extractor import PythonImportExtractor


def _write_temp_file(content: str, suffix: str = ".py") -> str:
    fd, path = tempfile.mkstemp(suffix=suffix)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
    except:
        os.close(fd)
        raise
    return path


def test_simple_import_external():
    code = "import os\n"
    path = _write_temp_file(code)
    extractor = PythonImportExtractor([path])
    nodes, relations = extractor.extract(code, path)

    file_node = [n for n in nodes if n.kind == "file"][0]
    ext_nodes = [n for n in nodes if n.kind == "external_module"]
    assert len(ext_nodes) == 1
    assert ext_nodes[0].name == "os"
    assert ext_nodes[0].source_file == "<external>"

    assert len(relations) == 1
    assert relations[0].type == "file_imports_module"
    assert relations[0].source_id == file_node.id
    assert relations[0].target_id == ext_nodes[0].id
    assert relations[0].dimension == "dependencies"

    os.unlink(path)


def test_from_import_external():
    code = "from collections import defaultdict\n"
    path = _write_temp_file(code)
    extractor = PythonImportExtractor([path])
    nodes, relations = extractor.extract(code, path)

    ext_nodes = [n for n in nodes if n.kind == "external_module"]
    assert len(ext_nodes) == 1
    assert ext_nodes[0].name == "collections"

    os.unlink(path)


def test_multiple_imports():
    code = "import os, sys\n"
    path = _write_temp_file(code)
    extractor = PythonImportExtractor([path])
    nodes, relations = extractor.extract(code, path)

    ext_nodes = [n for n in nodes if n.kind == "external_module"]
    assert len(ext_nodes) == 2
    names = {n.name for n in ext_nodes}
    assert names == {"os", "sys"}

    assert len(relations) == 2

    os.unlink(path)


def test_relative_import_same_package():
    """from . import x resolves to __init__.py in the same package."""
    tmpdir = tempfile.mkdtemp()
    init_path = os.path.join(tmpdir, "__init__.py")
    a_path = os.path.join(tmpdir, "a.py")

    with open(init_path, "w", encoding="utf-8") as f:
        f.write("# package init\n")
    with open(a_path, "w", encoding="utf-8") as f:
        f.write("from . import x\n")

    extractor = PythonImportExtractor([init_path, a_path])
    with open(a_path, "r", encoding="utf-8") as f:
        a_content = f.read()
    nodes, relations = extractor.extract(a_content, a_path)

    file_nodes = [n for n in nodes if n.kind == "file"]
    assert len(file_nodes) == 2
    assert len(relations) == 1
    assert relations[0].type == "file_imports_module"
    target_node = [n for n in file_nodes if n.id == relations[0].target_id][0]
    assert target_node.name == init_path

    os.unlink(init_path)
    os.unlink(a_path)
    os.rmdir(tmpdir)


def test_relative_import_submodule():
    """from .module import x resolves to sibling module."""
    tmpdir = tempfile.mkdtemp()
    init_path = os.path.join(tmpdir, "__init__.py")
    a_path = os.path.join(tmpdir, "a.py")
    b_path = os.path.join(tmpdir, "b.py")

    with open(init_path, "w", encoding="utf-8") as f:
        f.write("# package init\n")
    with open(a_path, "w", encoding="utf-8") as f:
        f.write("from .b import thing\n")
    with open(b_path, "w", encoding="utf-8") as f:
        f.write("# module b\n")

    extractor = PythonImportExtractor([init_path, a_path, b_path])
    with open(a_path, "r", encoding="utf-8") as f:
        a_content = f.read()
    nodes, relations = extractor.extract(a_content, a_path)

    file_nodes = [n for n in nodes if n.kind == "file"]
    # source a.py and target b.py
    assert len(file_nodes) == 2
    assert len(relations) == 1
    target_node = [n for n in file_nodes if n.id == relations[0].target_id][0]
    assert target_node.name == b_path

    os.unlink(init_path)
    os.unlink(a_path)
    os.unlink(b_path)
    os.rmdir(tmpdir)


def test_relative_import_parent_package():
    """from .. import x resolves to parent package's __init__.py."""
    tmpdir = tempfile.mkdtemp()
    init_path = os.path.join(tmpdir, "__init__.py")
    sub_dir = os.path.join(tmpdir, "sub")
    os.makedirs(sub_dir)
    sub_init = os.path.join(sub_dir, "__init__.py")
    c_path = os.path.join(sub_dir, "c.py")

    with open(init_path, "w", encoding="utf-8") as f:
        f.write("# top init\n")
    with open(sub_init, "w", encoding="utf-8") as f:
        f.write("# sub init\n")
    with open(c_path, "w", encoding="utf-8") as f:
        f.write("from .. import x\n")

    extractor = PythonImportExtractor([init_path, sub_init, c_path])
    with open(c_path, "r", encoding="utf-8") as f:
        c_content = f.read()
    nodes, relations = extractor.extract(c_content, c_path)

    file_nodes = [n for n in nodes if n.kind == "file"]
    # source c.py and target top __init__.py
    assert len(file_nodes) == 2
    assert len(relations) == 1
    target_node = [n for n in file_nodes if n.id == relations[0].target_id][0]
    assert target_node.name == init_path

    os.unlink(init_path)
    os.unlink(sub_init)
    os.unlink(c_path)
    os.rmdir(sub_dir)
    os.rmdir(tmpdir)


def test_relative_import_star():
    """from . import * resolves to current package's __init__.py."""
    tmpdir = tempfile.mkdtemp()
    init_path = os.path.join(tmpdir, "__init__.py")
    a_path = os.path.join(tmpdir, "a.py")

    with open(init_path, "w", encoding="utf-8") as f:
        f.write("__all__ = ['x']\n")
    with open(a_path, "w", encoding="utf-8") as f:
        f.write("from . import *\n")

    extractor = PythonImportExtractor([init_path, a_path])
    with open(a_path, "r", encoding="utf-8") as f:
        a_content = f.read()
    nodes, relations = extractor.extract(a_content, a_path)

    file_nodes = [n for n in nodes if n.kind == "file"]
    assert len(file_nodes) == 2
    assert len(relations) == 1
    target_node = [n for n in file_nodes if n.id == relations[0].target_id][0]
    assert target_node.name == init_path

    os.unlink(init_path)
    os.unlink(a_path)
    os.rmdir(tmpdir)


def test_relative_import_init_self():
    """from . import x from __init__.py resolves to self."""
    tmpdir = tempfile.mkdtemp()
    init_path = os.path.join(tmpdir, "__init__.py")

    with open(init_path, "w", encoding="utf-8") as f:
        f.write("from . import x\n")

    extractor = PythonImportExtractor([init_path])
    with open(init_path, "r", encoding="utf-8") as f:
        init_content = f.read()
    nodes, relations = extractor.extract(init_content, init_path)

    file_nodes = [n for n in nodes if n.kind == "file"]
    # source and target are the same __init__.py, so two nodes with same id
    assert len(file_nodes) == 2
    assert len(relations) == 1
    # relation target is the source file itself
    source_node = [n for n in file_nodes if n.name == init_path][0]
    assert relations[0].target_id == source_node.id

    os.unlink(init_path)
    os.rmdir(tmpdir)


def test_relative_import_escapes_root():
    """from ... import x from a file too shallow is skipped."""
    tmpdir = tempfile.mkdtemp()
    init_path = os.path.join(tmpdir, "__init__.py")
    a_path = os.path.join(tmpdir, "a.py")

    with open(init_path, "w", encoding="utf-8") as f:
        f.write("# init\n")
    with open(a_path, "w", encoding="utf-8") as f:
        f.write("from ... import x\n")

    extractor = PythonImportExtractor([init_path, a_path])
    with open(a_path, "r", encoding="utf-8") as f:
        a_content = f.read()
    nodes, relations = extractor.extract(a_content, a_path)

    # Only the file node, no relations for the over-scoped relative import
    assert len(nodes) == 1
    assert len(relations) == 0

    os.unlink(init_path)
    os.unlink(a_path)
    os.rmdir(tmpdir)


def test_relative_import_has_is_relative_flag():
    """Relations from relative imports carry is_relative=True."""
    tmpdir = tempfile.mkdtemp()
    init_path = os.path.join(tmpdir, "__init__.py")
    a_path = os.path.join(tmpdir, "a.py")

    with open(init_path, "w", encoding="utf-8") as f:
        f.write("# init\n")
    with open(a_path, "w", encoding="utf-8") as f:
        f.write("from . import x\n")

    extractor = PythonImportExtractor([init_path, a_path])
    with open(a_path, "r", encoding="utf-8") as f:
        a_content = f.read()
    nodes, relations = extractor.extract(a_content, a_path)

    assert len(relations) == 1
    assert relations[0].properties.get("is_relative") is True

    os.unlink(init_path)
    os.unlink(a_path)
    os.rmdir(tmpdir)


def test_absolute_import_no_is_relative_flag():
    """Relations from absolute imports do not carry is_relative."""
    code = "import os\n"
    path = _write_temp_file(code)
    extractor = PythonImportExtractor([path])
    nodes, relations = extractor.extract(code, path)

    assert len(relations) == 1
    assert relations[0].properties.get("is_relative") is None

    os.unlink(path)


def test_internal_file_resolution():
    tmpdir = tempfile.mkdtemp()
    path_a = os.path.join(tmpdir, "a.py")
    path_b = os.path.join(tmpdir, "b.py")

    with open(path_a, "w", encoding="utf-8") as f:
        f.write("import b\n")
    with open(path_b, "w", encoding="utf-8") as f:
        f.write("# module b\n")

    extractor = PythonImportExtractor([path_a, path_b])
    with open(path_a, "r", encoding="utf-8") as f:
        a_content = f.read()
    nodes, relations = extractor.extract(a_content, path_a)

    file_nodes = [n for n in nodes if n.kind == "file"]
    assert len(file_nodes) == 2

    ext_nodes = [n for n in nodes if n.kind == "external_module"]
    assert len(ext_nodes) == 0

    assert len(relations) == 1
    assert relations[0].type == "file_imports_module"
    target_node = [n for n in file_nodes if n.id == relations[0].target_id][0]
    assert target_node.name == path_b

    os.unlink(path_a)
    os.unlink(path_b)
    os.rmdir(tmpdir)


def test_init_file_resolution():
    code_a = "import pkg\n"
    code_init = "# pkg init\n"

    # Create a temporary directory for the package
    tmpdir = tempfile.mkdtemp()
    pkg_dir = os.path.join(tmpdir, "pkg")
    os.makedirs(pkg_dir)
    path_a = os.path.join(tmpdir, "a.py")
    path_init = os.path.join(pkg_dir, "__init__.py")

    with open(path_a, "w", encoding="utf-8") as f:
        f.write(code_a)
    with open(path_init, "w", encoding="utf-8") as f:
        f.write(code_init)

    extractor = PythonImportExtractor([path_a, path_init])
    with open(path_a, "r", encoding="utf-8") as f:
        a_content = f.read()
    nodes, relations = extractor.extract(a_content, path_a)

    ext_nodes = [n for n in nodes if n.kind == "external_module"]
    assert len(ext_nodes) == 0

    assert len(relations) == 1
    target_node = [n for n in nodes if n.id == relations[0].target_id][0]
    assert target_node.name == path_init

    os.unlink(path_a)
    os.unlink(path_init)
    os.rmdir(pkg_dir)
    os.rmdir(tmpdir)


def test_nested_module_resolution():
    code_a = "import pkg.utils\n"
    code_init = "# pkg init\n"
    code_utils = "# utils\n"

    tmpdir = tempfile.mkdtemp()
    pkg_dir = os.path.join(tmpdir, "pkg")
    os.makedirs(pkg_dir)
    path_a = os.path.join(tmpdir, "a.py")
    path_init = os.path.join(pkg_dir, "__init__.py")
    path_utils = os.path.join(pkg_dir, "utils.py")

    with open(path_a, "w", encoding="utf-8") as f:
        f.write(code_a)
    with open(path_init, "w", encoding="utf-8") as f:
        f.write(code_init)
    with open(path_utils, "w", encoding="utf-8") as f:
        f.write(code_utils)

    extractor = PythonImportExtractor([path_a, path_init, path_utils])
    with open(path_a, "r", encoding="utf-8") as f:
        a_content = f.read()
    nodes, relations = extractor.extract(a_content, path_a)

    ext_nodes = [n for n in nodes if n.kind == "external_module"]
    assert len(ext_nodes) == 0

    assert len(relations) == 1
    target_node = [n for n in nodes if n.id == relations[0].target_id][0]
    assert target_node.name == path_utils

    os.unlink(path_a)
    os.unlink(path_init)
    os.unlink(path_utils)
    os.rmdir(pkg_dir)
    os.rmdir(tmpdir)


def test_external_module_deduplication():
    code_a = "import os\n"
    code_b = "import os\n"
    path_a = _write_temp_file(code_a)
    path_b = _write_temp_file(code_b)

    extractor = PythonImportExtractor([path_a, path_b])

    with open(path_a, "r", encoding="utf-8") as f:
        a_content = f.read()
    with open(path_b, "r", encoding="utf-8") as f:
        b_content = f.read()
    nodes_a, relations_a = extractor.extract(a_content, path_a)
    nodes_b, relations_b = extractor.extract(b_content, path_b)

    # Collect all external nodes across both extractions
    all_ext_ids = set()
    for n in nodes_a + nodes_b:
        if n.kind == "external_module":
            all_ext_ids.add(n.id)

    # Should be exactly one external node for "os"
    assert len(all_ext_ids) == 1

    assert len(relations_a) == 1
    assert len(relations_b) == 1
    # Both relations point to the same external node
    assert relations_a[0].target_id == relations_b[0].target_id

    os.unlink(path_a)
    os.unlink(path_b)


def test_empty_file():
    path = _write_temp_file("")
    extractor = PythonImportExtractor([path])
    nodes, relations = extractor.extract("", path)

    assert len(nodes) == 1
    assert nodes[0].kind == "file"
    assert len(relations) == 0

    os.unlink(path)


def test_syntax_error():
    code = "import os\nclass Foo(\n"
    path = _write_temp_file(code)
    extractor = PythonImportExtractor([path])
    nodes, relations = extractor.extract(code, path)

    assert len(nodes) == 0
    assert len(relations) == 0

    os.unlink(path)


def test_package_root_detection():
    """Package root is inferred from __init__.py location."""
    tmpdir = tempfile.mkdtemp()
    tmpdir = os.path.realpath(tmpdir)
    pkg_dir = os.path.join(tmpdir, "pkg")
    os.makedirs(pkg_dir)
    init_path = os.path.join(pkg_dir, "__init__.py")
    a_path = os.path.join(pkg_dir, "a.py")

    with open(init_path, "w", encoding="utf-8") as f:
        f.write("# init\n")
    with open(a_path, "w", encoding="utf-8") as f:
        f.write("from .b import x\n")

    extractor = PythonImportExtractor([init_path, a_path])
    assert extractor._package_root == tmpdir

    os.unlink(init_path)
    os.unlink(a_path)
    os.rmdir(pkg_dir)
    os.rmdir(tmpdir)


def test_package_root_fallback_to_lcp():
    """Without __init__.py, package root falls back to LCP."""
    tmpdir = tempfile.mkdtemp()
    tmpdir = os.path.realpath(tmpdir)
    a_path = os.path.join(tmpdir, "a.py")
    b_path = os.path.join(tmpdir, "b.py")

    with open(a_path, "w", encoding="utf-8") as f:
        f.write("import b\n")
    with open(b_path, "w", encoding="utf-8") as f:
        f.write("# b\n")

    extractor = PythonImportExtractor([a_path, b_path])
    assert extractor._package_root == tmpdir

    os.unlink(a_path)
    os.unlink(b_path)
    os.rmdir(tmpdir)
