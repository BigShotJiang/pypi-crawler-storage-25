# source-graph

Extract, store, and visualize code relationships.

## Overview

`source-graph` treats code as a container of relationships. It extracts relationships from source files, stores them in a structured format, and presents them as an interactive HTML visualization.

**Architecture**: Extractor → Store → Presenter

## Installation

Requires Python 3.9+.

```bash
pip install -e .
```

## Usage

### CLI

The CLI has two subcommands: `extract` and `serve`.

#### Extract relationships to a database

```bash
source-graph extract src/*.py --output build/
```

This creates `build/source_graph.db` containing the extracted nodes and relations.

#### Serve an interactive report from a database

```bash
source-graph serve build/source_graph.db
```

This starts an HTTP server at `http://127.0.0.1:8080` that serves the interactive report directly from the database, without generating a file on disk. Use `--host` and `--port` to customize the binding.

### Library

```python
from source_graph import RelationStore, PythonStructureExtractor

store = RelationStore()
extractor = PythonStructureExtractor()

nodes, relations = extractor.extract("my_module.py")
store.add_nodes(nodes)
store.add_relations(relations)

store.save("output.db")
```

## Development

```bash
# Run tests
python -m pytest

# Run on the project itself
bash scripts/run-self-analysis.sh
```

## Milestone 1

- **Extractor**: Python AST-based structure extraction (file → class → method/function)
- **Store**: In-memory store with JSON persistence
- **Presenter**: Interactive HTML with expand/collapse, dimension switching, and hover details

## License

MIT
