## MODIFIED Requirements

### Requirement: Extractor extracts absolute and relative import statements
The system SHALL provide a `PythonImportExtractor` that parses `import` and `from ... import` statements from Python source files and produces nodes and relations for the `dependencies` dimension.

#### Scenario: Simple import statement
- **WHEN** a file contains `import os`
- **THEN** the extractor creates a relation from the importing file to an external module node representing `os`

#### Scenario: From-import statement
- **WHEN** a file contains `from collections import defaultdict`
- **THEN** the extractor creates a relation from the importing file to an external module node representing `collections`

#### Scenario: Multiple imports in one statement
- **WHEN** a file contains `import os, sys`
- **THEN** the extractor creates separate relations for `os` and `sys`

#### Scenario: Relative imports are resolved
- **WHEN** a file contains `from . import x`
- **THEN** the extractor resolves the import relative to the current file's package and creates a relation if the target is found within the analyzed set

#### Scenario: Relative from-import to submodule
- **WHEN** a file at `pkg/a.py` contains `from .b import x`
- **THEN** the extractor creates a relation from `pkg/a.py` to `pkg/b.py`

#### Scenario: Relative parent import
- **WHEN** a file at `pkg/sub/c.py` contains `from .. import x`
- **THEN** the extractor creates a relation from `pkg/sub/c.py` to `pkg/__init__.py`

### Requirement: Module names are resolved to files within the analyzed set
The system SHALL attempt to resolve imported module names to file paths among the files being analyzed. Resolution SHALL use reverse path construction from the detected package root: for a module name `x.y.z`, the system SHALL check candidate paths `ROOT/x/y/z.py` and `ROOT/x/y/z/__init__.py` where ROOT is the inferred package root directory.

The package root SHALL be inferred automatically from `__init__.py` locations among the analyzed files. The system SHALL find all directories containing `__init__.py` and compute the longest common directory of their parent directories. If no `__init__.py` is found, the system SHALL fall back to the longest common parent directory of all analyzed files.

#### Scenario: Import resolves to a module file
- **GIVEN** analyzed files include `/project/src/b.py`
- **WHEN** another file contains `import b`
- **THEN** the relation target is the node for `/project/src/b.py`

#### Scenario: Import resolves to a package init file
- **GIVEN** analyzed files include `/project/src/pkg/__init__.py`
- **WHEN** another file contains `import pkg`
- **THEN** the relation target is the node for `/project/src/pkg/__init__.py`

#### Scenario: Import resolves to a nested module
- **GIVEN** analyzed files include `/project/src/pkg/utils.py`
- **WHEN** another file contains `import pkg.utils`
- **THEN** the relation target is the node for `/project/src/pkg/utils.py`

#### Scenario: Unresolved imports become external nodes
- **WHEN** a file contains `import os` and `os` does not match any analyzed file
- **THEN** the relation target is an external module node with `source_file` set to `<external>`

#### Scenario: Package root detected from __init__.py
- **GIVEN** analyzed files include `/project/src/pkg/__init__.py` and `/project/src/pkg/a.py`
- **WHEN** the extractor processes `pkg/a.py`
- **THEN** the package root is `/project/src/` (the parent of the directory containing `__init__.py`)
- **AND** a relative import `from .b import x` resolves to `/project/src/pkg/b.py`

### Requirement: Extractor creates file_imports_module relations
The system SHALL create relations of type `file_imports_module` in the `dependencies` dimension, with the importing file as `source_id` and the imported file (or external module) as `target_id`.

#### Scenario: Internal dependency relation
- **WHEN** `a.py` imports `b.py` and both are in the analyzed set
- **THEN** a `file_imports_module` relation exists with `source_id` = a.py's node id and `target_id` = b.py's node id
- **AND** the relation's `dimension` is `dependencies`

#### Scenario: External dependency relation
- **WHEN** `a.py` imports `json` and `json` is not in the analyzed set
- **THEN** a `file_imports_module` relation exists with `source_id` = a.py's node id
- **AND** the target is an external module node named `json`

### Requirement: CLI runs both extractors
The system SHALL run both `PythonStructureExtractor` and `PythonImportExtractor` over all input files, storing nodes and relations from both dimensions in the `RelationStore`.

#### Scenario: Single file with imports
- **WHEN** the CLI analyzes one file
- **THEN** the store contains `structure` dimension relations (file → class/function)
- **AND** the store contains `dependencies` dimension relations for any imports in that file

#### Scenario: Multiple files with cross-dependencies
- **WHEN** the CLI analyzes `a.py` and `b.py` where `a.py` imports `b`
- **THEN** the store contains a `dependencies` relation from `a.py` to `b.py`

### Requirement: HTML report renders dependencies as interactive graph
The system SHALL render the `dependencies` dimension as an interactive dependency graph using structured data (`type: "dependency_graph"`), distinct from the tree view used for the `structure` dimension. The graph SHALL support two view modes: a **Map** view (layered directed graph, default) and a **Tree** view (collapsible tree). A toggle SHALL allow switching between Map and Tree views. Both views SHALL support tooltips.

#### Scenario: Map view is default
- **GIVEN** the HTML report is rendered for the `dependencies` dimension
- **WHEN** the page loads
- **THEN** the Map view is displayed by default
- **AND** a view toggle shows "Map" as the active option

#### Scenario: Switching to Tree view
- **GIVEN** the Map view is displayed for the `dependencies` dimension
- **WHEN** the user clicks the Tree option in the view toggle
- **THEN** the Tree view is displayed
- **AND** the Tree option is shown as active

#### Scenario: Simple dependency graph in Tree view
- **GIVEN** `a.py` imports `b.py` and `b.py` imports `os`
- **WHEN** the HTML report is rendered for the `dependencies` dimension in Tree view
- **THEN** the output contains an interactive graph showing `a.py` with a dependency on `b.py`, and `b.py` with a dependency on `os` marked as external

#### Scenario: Graph with multiple branches in Tree view
- **GIVEN** `a.py` imports both `b.py` and `c.py`
- **WHEN** the HTML report is rendered for the `dependencies` dimension in Tree view
- **THEN** the graph shows both branches from `a.py` in alphabetical order

#### Scenario: Circular dependency annotation in Tree view
- **GIVEN** `a.py` imports `b.py`, `b.py` imports `c.py`, and `c.py` imports `a.py`
- **WHEN** the HTML report is rendered for the `dependencies` dimension in Tree view
- **THEN** the graph annotates the cycle (e.g., `[circular]`)

### Requirement: External modules are deduplicated
The system SHALL create at most one external module node per unique module name across all files.

#### Scenario: Multiple files import same external module
- **GIVEN** both `a.py` and `b.py` contain `import os`
- **WHEN** extraction completes
- **THEN** there is exactly one external module node for `os`
- **AND** there are two relations pointing to it (from `a.py` and from `b.py`)

## ADDED Requirements

### Requirement: External dependencies can be toggled in the HTML report
The system SHALL provide a "Show External Dependencies" toggle in the HTML report header when viewing the `dependencies` dimension. The toggle SHALL default to ON. When the toggle is OFF, external module nodes and any downstream chains reachable through them SHALL be hidden from the graph.

#### Scenario: External dependencies visible by default
- **GIVEN** `a.py` imports `b.py` and `os`
- **WHEN** the HTML report is rendered for the `dependencies` dimension
- **THEN** both `b.py` and `os` are visible in the graph
- **AND** the "Show External Dependencies" toggle is checked

#### Scenario: Hiding external dependencies
- **GIVEN** `a.py` imports `b.py` and `os`
- **WHEN** the user unchecks "Show External Dependencies"
- **THEN** `os` is hidden from the graph
- **AND** `b.py` remains visible

#### Scenario: External dependency downstream is hidden
- **GIVEN** `a.py` imports `json`, and `json` (external) imports `decoder` (external)
- **WHEN** the user unchecks "Show External Dependencies"
- **THEN** both `json` and `decoder` are hidden from the graph

### Requirement: Root file nodes are sorted by internal dependency count
The system SHALL sort root file nodes in the `dependencies` dimension by their count of outgoing edges to internal (non-external) nodes, in ascending order. Files with fewer internal dependencies SHALL appear first. Child nodes within each branch SHALL be sorted alphabetically and SHALL NOT be reordered by dependency count.

#### Scenario: Leaf file appears first
- **GIVEN** `c.py` has no internal dependencies, `a.py` imports `b.py` and `c.py`, and `b.py` imports `os`
- **WHEN** the HTML report is rendered for the `dependencies` dimension
- **THEN** the root order is `c.py` (0 internal deps), then `a.py` (2 internal deps)
- **AND** `b.py` does not appear as a root because it is a child of `a.py`

#### Scenario: Child nodes are alphabetical
- **GIVEN** `a.py` imports `z.py`, `m.py`, and `b.py`
- **WHEN** `a.py` is expanded in the graph
- **THEN** the child dependencies appear in alphabetical order: `b.py`, `m.py`, `z.py`

### Requirement: Map view displays only internal files
The system SHALL render the Map view using only internal files (non-external modules). External module nodes SHALL be excluded from the Map. Edges pointing to or from external modules SHALL be omitted from the Map.

#### Scenario: Map view hides external modules
- **GIVEN** `a.py` imports `b.py` and `os`
- **WHEN** the Map view is rendered
- **THEN** `a.py` and `b.py` are visible as nodes
- **AND** `os` is not visible as a node
- **AND** the edge from `a.py` to `os` is not drawn

#### Scenario: Map view with only external dependencies
- **GIVEN** `a.py` imports only `os`
- **WHEN** the Map view is rendered
- **THEN** `a.py` is visible as an isolated node with no edges

### Requirement: Map view compresses cycles into grouped nodes
The system SHALL detect strongly connected components (SCCs) in the internal-file dependency graph and compress each SCC into a single grouped node before layering. The grouped node SHALL visually indicate that it contains multiple files.

#### Scenario: Simple cycle is compressed
- **GIVEN** `a.py` imports `b.py` and `b.py` imports `a.py`
- **WHEN** the Map view is rendered
- **THEN** `a.py` and `b.py` appear as a single grouped node
- **AND** no cycle edges are drawn between them externally

#### Scenario: No cycle when graph is acyclic
- **GIVEN** `a.py` imports `b.py` and `b.py` imports `c.py`
- **WHEN** the Map view is rendered
- **THEN** each file appears as its own node
- **AND** edges are drawn from `a.py` to `b.py` and from `b.py` to `c.py`

### Requirement: Map view layers nodes by depth-to-leaf
The system SHALL assign each node (or grouped SCC node) to a layer based on its longest-path distance to a leaf node. Leaf nodes (nodes with no outgoing internal edges) SHALL be in layer 0. A node's layer SHALL be 1 + the maximum layer of its children. Nodes in higher layers SHALL be rendered above nodes in lower layers.

#### Scenario: Linear chain layering
- **GIVEN** `a.py` imports `b.py`, `b.py` imports `c.py`, and `c.py` has no internal imports
- **WHEN** the Map view is rendered
- **THEN** `c.py` is in the bottom layer
- **AND** `b.py` is in the layer above `c.py`
- **AND** `a.py` is in the layer above `b.py`

#### Scenario: Diamond shape layering
- **GIVEN** `a.py` imports `b.py` and `c.py`, and both `b.py` and `c.py` import `d.py`
- **WHEN** the Map view is rendered
- **THEN** `d.py` is in the bottom layer
- **AND** `b.py` and `c.py` are in the layer above `d.py`
- **AND** `a.py` is in the layer above `b.py` and `c.py`

#### Scenario: Isolated file in bottom layer
- **GIVEN** `a.py` imports `b.py`, and `c.py` has no imports and is not imported by any internal file
- **WHEN** the Map view is rendered
- **THEN** `c.py` is in the bottom layer alongside `b.py`

### Requirement: Map view supports click-to-highlight downstream chain
The system SHALL support clicking a node in the Map view to highlight its entire downstream dependency chain. All nodes and edges reachable from the clicked node via outgoing internal edges SHALL be highlighted. All other nodes and edges SHALL be dimmed.

#### Scenario: Click highlights downstream chain
- **GIVEN** `a.py` imports `b.py` and `c.py`, `b.py` imports `d.py`, and `c.py` has no further imports
- **WHEN** the user clicks `a.py` in the Map view
- **THEN** `a.py`, `b.py`, `c.py`, and `d.py` are highlighted
- **AND** all edges from `a.py` to `b.py`, `a.py` to `c.py`, and `b.py` to `d.py` are highlighted

#### Scenario: Click on leaf highlights only itself
- **GIVEN** `a.py` imports `b.py` and `b.py` has no further internal imports
- **WHEN** the user clicks `b.py` in the Map view
- **THEN** only `b.py` is highlighted
- **AND** `a.py` is dimmed

#### Scenario: Click on empty area clears highlight
- **GIVEN** a node is currently highlighted in the Map view
- **WHEN** the user clicks on an empty area of the SVG canvas
- **THEN** all nodes and edges return to normal brightness

### Requirement: Map view renders edges as diagonal lines
The system SHALL render dependency edges in the Map view as straight diagonal lines connecting source node centers to target node centers. Nodes within the same layer SHALL be ordered alphabetically to reduce edge crossings.

#### Scenario: Edge connects layered nodes
- **GIVEN** `a.py` imports `b.py` and they are in adjacent layers
- **WHEN** the Map view is rendered
- **THEN** a straight line is drawn from the center of the `a.py` node to the center of the `b.py` node

### Requirement: Relative imports are marked with is_relative property
The system SHALL set `properties={"is_relative": True}` on `file_imports_module` relations that originate from relative import statements.

#### Scenario: Relative import relation has flag
- **WHEN** a file contains `from . import x` and the target is resolved
- **THEN** the resulting `file_imports_module` relation has `properties={"is_relative": True}`

#### Scenario: Absolute import relation has no flag
- **WHEN** a file contains `import os`
- **THEN** the resulting `file_imports_module` relation does not have an `is_relative` property (or has `False`)

### Requirement: Relative imports escaping the analyzed set are skipped
The system SHALL skip creating relations for relative imports whose resolution would produce an empty target module name (i.e., the import references a package above the detected package root).

#### Scenario: Over-scoped relative import is ignored
- **GIVEN** the package root is `/project/src/`
- **WHEN** a file at `/project/src/a.py` contains `from ... import x`
- **THEN** no relation is created for that import

### Requirement: from . import * resolves to package init
The system SHALL resolve `from . import *` as a dependency on the current package's `__init__.py` file.

#### Scenario: Star import from package
- **GIVEN** analyzed files include `/project/src/pkg/__init__.py` and `/project/src/pkg/a.py`
- **WHEN** `pkg/a.py` contains `from . import *`
- **THEN** the extractor creates a relation from `pkg/a.py` to `pkg/__init__.py`
