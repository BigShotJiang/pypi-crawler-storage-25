## ADDED Requirements

### Requirement: Goal storage directory structure
Each goal SHALL reside in its own directory under `ideas/goals/<goal-name>/`. The directory SHALL contain at minimum a `goal.md` file representing the current version of the goal. Optional content such as reference materials or attachments MAY be added to the same directory.

#### Scenario: Goal directory created
- **WHEN** a goal named "goal-achievement-system" is established
- **THEN** a directory `ideas/goals/goal-achievement-system/` exists
- **AND** it contains a file named `goal.md`

#### Scenario: Goal directory supports attachments
- **WHEN** a goal requires supplementary reference material
- **THEN** additional files MAY be placed in `ideas/goals/<goal-name>/`
- **AND** they coexist alongside `goal.md` without interfering with the goal mechanism

### Requirement: Goal file frontmatter
The `goal.md` file SHALL contain a YAML frontmatter block with the fields `date` and `relations`. The `date` field SHALL use the `YYYY-MM-DD` format. The `relations` field SHALL be an array of typed relation objects, each containing `target` (namespace-qualified string), `relation` (enum: `serves`, `depends_on`, `refines`), and `rationale` (non-empty string). The `created_at` and `updated_at` fields SHALL NOT appear in frontmatter.

#### Scenario: Goal file with valid typed relations
- **WHEN** a goal file is created
- **THEN** its frontmatter contains `date` and `relations`
- **AND** `relations` is an array of objects with `target`, `relation`, and `rationale`
- **AND** `date` matches `YYYY-MM-DD`

#### Scenario: Goal with no related goals
- **WHEN** a goal has no relationship to other goals
- **THEN** `relations` SHALL be an empty array `[]`

#### Scenario: Goal with extra frontmatter fields
- **WHEN** a goal file frontmatter contains `created_at`, `updated_at`, or `related_goals`
- **THEN** it is invalid

### Requirement: Goal iteration history
Each goal directory SHALL contain a `history/` subdirectory. When a goal is iterated, the current `goal.md` SHALL be copied into `history/` with the filename `vN-YYYYMMDD.md` before modification. The original idea that was promoted to become a goal SHALL be preserved as `history/initial-idea.md`.

#### Scenario: First iteration of a goal
- **WHEN** a goal is iterated for the first time
- **THEN** the previous `goal.md` is copied to `history/v1-20260512.md`
- **AND** a new `goal.md` replaces it

#### Scenario: Source idea preserved on promotion
- **WHEN** an idea is promoted to become a goal
- **THEN** the original idea content is copied to `history/initial-idea.md`
- **AND** the source idea file remains in `ideas/` at its original location
