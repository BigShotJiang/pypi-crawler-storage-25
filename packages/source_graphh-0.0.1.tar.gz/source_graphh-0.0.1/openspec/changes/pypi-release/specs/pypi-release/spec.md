## ADDED Requirements

### Requirement: Package builds a valid wheel containing only source-graph artifacts
The source-graph package SHALL build into a wheel that contains the `source_graph` Python package, the `source_graph/web/` static assets, and a `source-graph` console script entry point. The wheel SHALL NOT contain the `gas` package or a `gas` console script.

#### Scenario: Wheel contents are correct
- **WHEN** the package is built with `python -m build --wheel`
- **THEN** the resulting wheel contains `source_graph/` and `source_graph/web/`
- **AND** the wheel does not contain `gas/` or `gas.cli`
- **AND** `source_graph-0.0.1.dist-info/entry_points.txt` lists `source-graph` but not `gas`

#### Scenario: Installed CLI is executable
- **WHEN** the user installs the wheel in a fresh virtual environment
- **THEN** the command `source-graph --version` exits with status 0
- **AND** the command `gas` is not available

### Requirement: Version is derived from git tags via hatch-vcs
The package version SHALL be determined at build time by hatch-vcs reading the latest git tag. When a release tag `v0.0.1` exists, the built package version SHALL be `0.0.1`. When no release tag matches the current commit, the version SHALL reflect the distance from the nearest tag in hatch-vcs's standard dev format.

#### Scenario: Release build produces clean version
- **WHEN** the repository is checked out at tag `v0.0.1`
- **AND** the package is built
- **THEN** the wheel filename contains `source_graph-0.0.1`
- **AND** `source-graph --version` outputs a string containing `0.0.1`

#### Scenario: Development build produces dev version
- **WHEN** the repository has commits after tag `v0.0.1` with no new tag
- **AND** the package is built
- **THEN** the wheel filename contains a dev version string (e.g., `source_graph-0.0.1.dev1`)

### Requirement: Release workflow publishes to PyPI via Trusted Publishing
A GitHub Actions workflow SHALL trigger on GitHub Release creation, build the package, and publish it to PyPI using Trusted Publishing (OIDC). The workflow SHALL require the `id-token: write` permission to request an OIDC token from GitHub.

#### Scenario: Creating a GitHub Release triggers PyPI publish
- **WHEN** a maintainer creates a GitHub Release for tag `v0.0.1`
- **THEN** the release workflow runs
- **AND** the workflow builds a wheel and sdist
- **AND** the workflow publishes both artifacts to PyPI
- **AND** `pip install source-graph` installs version `0.0.1`

### Requirement: TestPyPI testing precedes production release
The release workflow SHALL first publish to TestPyPI on tag push, and production PyPI publication SHALL be gated behind a GitHub Release creation. Alternatively, the workflow SHALL support a distinct trigger or job for TestPyPI verification before the production publish job runs.

#### Scenario: Tag push publishes to TestPyPI
- **WHEN** a git tag `v0.0.1` is pushed to GitHub
- **THEN** a TestPyPI publish job runs
- **AND** the package appears on https://test.pypi.org/project/source-graph/
- **AND** `pip install -i https://test.pypi.org/simple/ source-graph` succeeds

### Requirement: gas is independently packageable
The `gas/` directory SHALL contain its own `pyproject.toml` with independent metadata, version, and entry points. It SHALL be buildable into a wheel without depending on source-graph's build configuration.

#### Scenario: gas builds independently
- **WHEN** `cd gas && python -m build --wheel` is executed
- **THEN** a wheel is produced containing the `gas` package
- **AND** the wheel's entry_points.txt contains `gas = gas.cli:main`
