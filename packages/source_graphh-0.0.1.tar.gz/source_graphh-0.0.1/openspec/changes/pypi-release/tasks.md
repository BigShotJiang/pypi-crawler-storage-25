## 1. Split gas into an independent package

- [x] 1.1 Create `gas/pyproject.toml` with hatchling backend, hatch-vcs, and `gas = gas.cli:main` entry point
- [x] 1.2 Move `tests/test_gas_cli.py` and `tests/test_gas_frontmatter.py` to `gas/tests/`
- [x] 1.3 Remove `gas` console script and `gas/src` from `pythonpath` in source-graph `pyproject.toml`
- [x] 1.4 Verify `cd gas && python -m build --wheel` produces a valid wheel containing only `gas/`

## 2. Configure hatch-vcs for source-graph

- [x] 2.1 Install hatch-vcs in the local environment (`uv pip install hatch-vcs`)
- [x] 2.2 Update source-graph `pyproject.toml`: add `hatch-vcs` to build-system requires, set `dynamic = ["version"]`, add `[tool.hatch.version]` with `source = "vcs"`
- [x] 2.3 Remove hardcoded `version = "0.1.0"` from `[project]` section
- [x] 2.4 Verify local build produces a dev version string (e.g., `source_graph-0.0.1.dev1`)

## 3. Validate source-graph wheel contents

- [x] 3.1 Build source-graph wheel and inspect contents: confirm `source_graph/` and `web/` are present, `gas/` is absent
- [x] 3.2 Verify `entry_points.txt` contains only `source-graph`, not `gas`
- [x] 3.3 Install wheel in a fresh venv and run `source-graph --version`

## 4. Mirror repository to GitHub

- [x] 4.1 Add GitHub remote: `git remote add github git@github.com:SR1s/CoreIntuition.git`
- [x] 4.2 Push `pypi-release` branch to GitHub
- [ ] 4.3 Verify GitHub Actions CI runs and passes on Python 3.9–3.12

## 5. Configure Trusted Publishing on PyPI platforms

- [x] 5.1 Register / log in to https://test.pypi.org and enable 2FA
- [x] 5.2 On TestPyPI: Account settings → Publishing → Add pending publisher for `SR1s/CoreIntuition`, workflow `release.yml`
- [x] 5.3 Register / log in to https://pypi.org and enable 2FA
- [x] 5.4 On PyPI: Account settings → Publishing → Add pending publisher for `SR1s/CoreIntuition`, workflow `release.yml`
- [x] 5.5 On GitHub: Verify repository Settings → Actions → General → Workflow permissions is set to "Read and write permissions"

## 6. Create release workflow

- [x] 6.1 Write `.github/workflows/release.yml` with jobs for TestPyPI (tag push) and PyPI (GitHub Release creation) using Trusted Publishing
- [ ] 6.2 Commit and push `release.yml` to GitHub ← 依赖 4.2
- [ ] 6.3 Verify workflow file appears in GitHub UI without YAML syntax errors

## 7. Test release on TestPyPI

- [x] 7.1 Create local tag `v0.0.1`: `git tag v0.0.1`
- [x] 7.2 Push tag to GitHub: `git push github v0.0.1`
- [x] 7.3 Watch GitHub Actions run the TestPyPI publish job
- [x] 7.4 Verify package appears at https://test.pypi.org/project/source-graph/0.0.1/
- [x] 7.5 Verify `pip install -i https://test.pypi.org/simple/ source-graph` installs and `source-graph --version` works

## 8. Production release to PyPI

- [ ] 8.1 Create a GitHub Release for tag `v0.0.1` (triggers the PyPI publish job)
- [ ] 8.2 Watch GitHub Actions run the PyPI publish job
- [ ] 8.3 Verify package appears at https://pypi.org/project/source-graph/0.0.1/
- [ ] 8.4 Verify `pip install source-graph` installs and `source-graph --version` works in a fresh environment

## 9. Post-release cleanup

- [x] 9.1 Create `CHANGELOG.md` with initial `v0.0.1` entry
- [ ] 9.2 Push tag `v0.0.1` to Gitee: `git push origin v0.0.1`
- [ ] 9.3 Create a Gitee Release for `v0.0.1` and attach the wheel/sdist files
