## Context

source-graph currently exists as a local development tool with packaging infrastructure (`pyproject.toml`, hatchling backend) but no release process. The version is hardcoded at `0.1.0`, there are no git tags, and the repository lives on Gitee. The `gas` CLI tool shares the same `pyproject.toml` and tests, even though it is a separate product. The existing `.github/workflows/ci.yml` is dormant because the code is not hosted on GitHub.

The goal is to establish a minimal viable PyPI release pipeline: version management, automated builds, and distribution through standard Python packaging channels.

## Goals / Non-Goals

**Goals:**
- source-graph can be installed via `pip install source-graph`
- Version is managed through git tags, not hardcoded files
- Releases are built and published automatically via GitHub Actions
- First release (`v0.0.1`) is tested on TestPyPI before going to production PyPI
- gas is packaged independently from source-graph

**Non-Goals:**
- Automated changelog generation from commit messages
- Pre-release versions (alpha/beta/rc) beyond the initial `0.0.1`
- Multi-platform binary distribution (e.g., PyInstaller, shiv)
- Publishing to package managers other than PyPI (Homebrew, apt, etc.)
- Gitee CI integration (GitHub is the chosen CI platform)

## Decisions

### Decision 1: Use hatch-vcs for dynamic versioning

**Rationale:** Eliminates the classic "forgot to bump version" error. The version is the git tag; the tag is the version. For a CLI tool where releases are event-driven, this reduces human error.

**Alternatives considered:**
- Static version in `pyproject.toml`: Simpler, but requires manual editing and a commit per release.
- Manual version bump script: More moving parts; still requires human execution.

### Decision 2: GitHub Actions + Trusted Publishing (OIDC)

**Rationale:** No long-lived API tokens to manage. PyPI trusts GitHub's identity assertion. This is the modern standard for Python package publishing.

**Alternatives considered:**
- Gitee Go + API token: Gitee Go is not supported by PyPI Trusted Publishing, forcing token-based auth which is less secure and requires secret rotation.
- Local manual publishing with `twine`: Simplest for a one-off, but not reproducible and creates a bus factor.

### Decision 3: gas gets its own `pyproject.toml` instead of being moved into `src/`

**Rationale:** gas is a separate product. A dedicated `gas/pyproject.toml` makes it an independently installable and versionable package without reorganizing directory structures. Tests move to `gas/tests/` to match.

**Alternatives considered:**
- Move `gas/src/gas/` into `src/gas/`: Would unify the source tree but entangles two products in one package namespace.
- Keep gas in source-graph's wheel: Rejected because users installing `source-graph` should not receive the `gas` CLI.

### Decision 4: TestPyPI smoke test before every PyPI release

**Rationale:** Catches packaging mistakes (missing files, broken entry points, metadata errors) before they reach the production index. The initial `v0.0.1` must pass this gate.

**Alternatives considered:**
- Skip TestPyPI and go straight to PyPI: Faster, but mistakes are public and irreversible (PyPI does not allow re-uploading the same version).

### Decision 5: Accept dev versions during local development

**Rationale:** hatch-vcs generates `0.0.1.devN+g<hash>` when no release tag is checked out. This is standard behavior and accurately reflects that the local checkout is ahead of the last release.

**Alternatives considered:**
- Pin a fallback version: Would mask the true distance from the last tag.

## Risks / Trade-offs

- **[Risk] GitHub mirror drifts out of sync with Gitee** → Mitigation: Make GitHub the primary remote for release tags, or set up a sync hook. For now, manual push to both remotes is acceptable.
- **[Risk] `source-graph` package name is taken on PyPI between now and first release** → Mitigation: Name is currently available. Complete registration and Trusted Publisher setup promptly.
- **[Risk] Trusted Publishing setup is complex for first-time users** → Mitigation: Document exact PyPI UI navigation steps in the task list. Test on TestPyPI first.
- **[Risk] gas tests break after relocation** → Mitigation: Move tests atomically and run them from the gas package directory before proceeding.
- **[Trade-off] Local dev versions look ugly (`0.0.1.dev1+g8f2a1b`)** → Accepted: Only affects editable installs during development; release versions are clean.

## Migration Plan

1. Split gas into independent package (`gas/pyproject.toml`, relocate tests)
2. Configure hatch-vcs in source-graph's `pyproject.toml`
3. Remove `gas` console script from source-graph's `pyproject.toml`
4. Push repository to GitHub
5. Configure Trusted Publishers on TestPyPI and PyPI
6. Write `.github/workflows/release.yml`
7. Tag `v0.0.1`, push tag to GitHub, verify TestPyPI release
8. Create GitHub Release to trigger PyPI production release
9. Verify `pip install source-graph` works and CLI launches

Rollback: If the PyPI release is broken, the version cannot be re-uploaded. The mitigation is to immediately release `v0.0.2` with the fix. TestPyPI testing in step 7 exists to prevent this scenario.

## Open Questions

1. Should the GitHub repository become the primary remote, or remain a mirror with Gitee as primary?
2. Does gas need its own independent release cycle immediately, or can it stay at `0.0.1` and share the initial release momentum?
