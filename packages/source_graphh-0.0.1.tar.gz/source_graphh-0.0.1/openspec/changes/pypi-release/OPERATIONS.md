# 人工操作清单

本文档列出所有**无法自动编码**的步骤，并标注每一步由谁执行。

- **`[人工]`** — 必须你在网页或终端手动完成（涉及外部平台账号、2FA、网页配置）
- **`[Agent]`** — 可以交给 Agent 执行（git 命令、验证命令、轮询检查）

---

## 快速总览：所有 `[人工]` 步骤

以下 8 个步骤**只能人工完成**。建议先集中处理这些，Agent 步骤可以并行或后续执行。

| # | 步骤 | 平台 | 预估时间 |
|---|------|------|---------|
| 1 | 注册/登录 TestPyPI + 开启 2FA | test.pypi.org | 5 min |
| 2 | 在 TestPyPI 配置 Trusted Publisher | test.pypi.org | 3 min |
| 3 | 注册/登录 PyPI + 开启 2FA | pypi.org | 5 min |
| 4 | 在 PyPI 配置 Trusted Publisher | pypi.org | 3 min |
| 5 | 确认 GitHub Actions 权限为 Read and write | github.com | 2 min |
| 6 | 创建 GitHub Release（触发 PyPI 发布） | github.com | 3 min |
| 7 | 创建 Gitee Release 并上传附件 | gitee.com | 5 min |

---

## 1. GitHub 镜像

| 步骤 | 执行者 | 操作 | 命令 / 路径 | 结果（完成后回填） |
|------|--------|------|-------------|-------------------|
| 1.1 | `[Agent]` | 添加 GitHub remote | `git remote add github git@github.com:SR1s/CoreIntuition.git` | remote 名称：`github` |
| 1.2 | `[Agent]` | Push main 分支 | `git push github main` | GitHub 仓库 URL：________________ |
| 1.3 | `[Agent]` | 验证 CI 通过 | 打开 GitHub → Actions 标签页 | CI 最新运行结果链接：________________ |

---

## 2. TestPyPI 账号与配置

| 步骤 | 执行者 | 操作 | 路径 | 结果（完成后回填） |
|------|--------|------|------|-------------------|
| 2.1 | **`[人工]`** | 注册/登录 TestPyPI | https://test.pypi.org | 用户名：________________ |
| 2.2 | **`[人工]`** | 开启 2FA | Account settings → Security → Add 2FA | 2FA 方式（TOTP app）：________________ |
| 2.3 | **`[人工]`** | 配置 Trusted Publisher | Account settings → Publishing → Add a new pending publisher | 状态：□ 已配置 |
| | | 填写信息： | | |
| | | - PyPI Project Name: `source-graph` | | |
| | | - Owner: `SR1s` | | |
| | | - Repository name: `CoreIntuition` | | |
| | | - Workflow name: `release.yml` | | |
| | | - Environment name: *(留空)* | | |
| 2.4 | `[Agent]` | 首次发布后验证 | `curl -s https://test.pypi.org/pypi/source-graph/0.0.1/json \| python -m json.tool` | TestPyPI 项目链接：________________ |
| 2.5 | `[Agent]` | 安装验证 | `pip install -i https://test.pypi.org/simple/ source-graph` | 验证结果：□ 成功 / □ 失败 |

---

## 3. PyPI 账号与配置

| 步骤 | 执行者 | 操作 | 路径 | 结果（完成后回填） |
|------|--------|------|------|-------------------|
| 3.1 | **`[人工]`** | 注册/登录 PyPI | https://pypi.org | 用户名：________________ |
| 3.2 | **`[人工]`** | 开启 2FA | Account settings → Security → Add 2FA | 2FA 方式（TOTP app）：________________ |
| 3.3 | **`[人工]`** | 配置 Trusted Publisher | Account settings → Publishing → Add a new pending publisher | 状态：□ 已配置 |
| | | 填写信息与 TestPyPI 相同（项目名 `source-graph`，Owner `SR1s`，Repo `CoreIntuition`，Workflow `release.yml`） | | |
| 3.4 | `[Agent]` | 首次发布后验证 | `curl -s https://pypi.org/pypi/source-graph/0.0.1/json \| python -m json.tool` | PyPI 项目链接：________________ |
| 3.5 | `[Agent]` | 安装验证 | `pip install source-graph`（在全新 venv 中） | 验证结果：□ 成功 / □ 失败 |
| | | 运行 `source-graph --version` | | 输出版本：________________ |

---

## 4. GitHub Actions 权限检查

| 步骤 | 执行者 | 操作 | 路径 | 结果（完成后回填） |
|------|--------|------|------|-------------------|
| 4.1 | **`[人工]`** | 验证 Workflow 权限 | GitHub 仓库 → Settings → Actions → General → Workflow permissions | 当前设置：________________ |
| | | 必须是 **"Read and write permissions"** | | 状态：□ 已确认 |

---

## 5. Tag 推送与观察（TestPyPI）

| 步骤 | 执行者 | 操作 | 命令 / 路径 | 结果（完成后回填） |
|------|--------|------|-------------|-------------------|
| 5.1 | `[Agent]` | 本地打 tag | `git tag v0.0.1` | 本地 tag 列表确认：`git tag -l` → ________________ |
| 5.2 | `[Agent]` | Push tag 到 GitHub | `git push github v0.0.1` | Tag URL：________________ |
| 5.3 | `[Agent]` | 观察 Actions 运行 | 轮询 GitHub Actions API 或打开网页 | Actions 运行链接：________________ |
| 5.4 | `[Agent]` | 确认 TestPyPI 出现 | `curl -s https://test.pypi.org/pypi/source-graph/0.0.1/json` | 状态：□ 已出现 |

---

## 6. GitHub Release 创建（触发 PyPI 正式发布）

| 步骤 | 执行者 | 操作 | 路径 | 结果（完成后回填） |
|------|--------|------|------|-------------------|
| 6.1 | **`[人工]`** | 创建 GitHub Release | GitHub 仓库 → Releases → Draft a new release | Release URL：________________ |
| | | - Choose tag: `v0.0.1` | | |
| | | - Title: `v0.0.1` | | |
| | | - Description: 复制 CHANGELOG.md 内容 | | |
| 6.2 | `[Agent]` | 观察 Actions 运行 | 轮询 GitHub Actions API 或打开网页 | Actions 运行链接：________________ |
| 6.3 | `[Agent]` | 确认 PyPI 出现 | `curl -s https://pypi.org/pypi/source-graph/0.0.1/json` | 状态：□ 已出现 |

---

## 7. Gitee 同步

| 步骤 | 执行者 | 操作 | 命令 / 路径 | 结果（完成后回填） |
|------|--------|------|-------------|-------------------|
| 7.1 | `[Agent]` | Push tag 到 Gitee | `git push origin v0.0.1` | Gitee tag URL：________________ |
| 7.2 | **`[人工]`** | 创建 Gitee Release | Gitee 仓库 → Releases → 创建发行版 | Gitee Release URL：________________ |
| | | 上传附件：wheel 和 sdist 文件 | | 附件：□ 已上传 |

---

## 人工执行快速检查表

完成以下 8 项后，Agent 可以接手剩余的所有验证和执行工作。

- [ ] **TestPyPI** 账号注册完成
- [ ] **TestPyPI** 2FA 开启
- [ ] **TestPyPI** Trusted Publisher 配置完成（Owner: `SR1s`, Repo: `CoreIntuition`, Workflow: `release.yml`）
- [ ] **PyPI** 账号注册完成
- [ ] **PyPI** 2FA 开启
- [ ] **PyPI** Trusted Publisher 配置完成（同上）
- [ ] **GitHub** Actions 权限确认为 "Read and write permissions"
- [ ] **Gitee** Release 创建并上传附件（最后一步）
