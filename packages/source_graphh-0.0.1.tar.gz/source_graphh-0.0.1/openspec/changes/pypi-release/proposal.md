## Why

source-graph is currently a local-only development tool. Users must clone the repository and install from source. There is no established release process, version management discipline, or distribution channel. Publishing to PyPI turns source-graph into a product that anyone can install with `pip install source-graph` and receive updates through standard Python packaging channels.

## What Changes

- **Split gas into an independent package**: Remove the `gas` console script from source-graph's `pyproject.toml`. Create a separate `gas/pyproject.toml` so gas can be built and distributed independently. Move gas-specific tests from `tests/` to `gas/tests/`.
- **Adopt hatch-vcs for dynamic versioning**: Replace the hardcoded `version = "0.1.0"` in `pyproject.toml` with hatch-vcs reading from git tags. The first release tag will be `v0.0.1`.
- **Add automated release workflow**: Create a GitHub Actions workflow (`.github/workflows/release.yml`) that builds the package and publishes to PyPI using Trusted Publishing (OIDC).
- **Mirror repository to GitHub**: Push the Gitee-hosted repository to `github.com/SR1s/CoreIntuition` so GitHub Actions can run.
- **Establish TestPyPI testing**: Configure Trusted Publishing for TestPyPI and perform a test release before the first production release.
- **Create initial CHANGELOG.md**: Document the `v0.0.1` release with Keep a Changelog format.

## Capabilities

### New Capabilities
- `pypi-release`: PyPI release automation, version management, and distribution pipeline for the source-graph CLI tool.

### Modified Capabilities
- *(none — no existing spec-level behavior changes. Removing the `gas` console script from source-graph's packaging is an implementation detail, not a change to CLI subcommand behavior.)*

## Impact

- **Build system**: `pyproject.toml` changes (hatch-vcs, dynamic version, removed gas entry point).
- **Package structure**: New `gas/pyproject.toml`; gas tests relocated.
- **CI/CD**: New `.github/workflows/release.yml`; existing `.github/workflows/ci.yml` remains.
- **Repository remotes**: Addition of GitHub remote for Actions execution.
- **External accounts**: Requires PyPI and TestPyPI accounts with 2FA and Trusted Publisher configuration.
- **Developer workflow**: Local dev versions will appear as `0.0.1.devN+g<hash>` when no release tag is checked out (standard hatch-vcs behavior).
