## 1. GraphStore Protocol and Data Contract

- [x] 1.1 Define `GraphStore` Protocol in `store.py` or a new `protocols.py` with `get_nodes`, `get_relations`, `get_dimensions`
- [x] 1.2 Verify `RelationStore` satisfies the `GraphStore` protocol (duck typing)
- [x] 1.3 Update any type hints in `presenter.py` that reference `RelationStore` to use `GraphStore`

## 2. HTMLPresenter Refactoring

- [x] 2.1 Change `HTMLPresenter.__init__` to accept a `GraphStore` instance instead of being parameterless
- [x] 2.2 Remove `store` parameter from `HTMLPresenter.render()`; use `self.store` internally
- [x] 2.3 Update `_build_dependency_data`, `_build_dependency_map_data`, `_build_graph_data`, `_build_tree_data` to use `self.store`
- [x] 2.4 Verify all rendering behavior remains unchanged (Tree, Map, Graph views)

## 3. CLI Subcommands

- [x] 3.1 Restructure `cli.py` to use `argparse` subparsers with `extract` and `present`
- [x] 3.2 Implement `extract` subcommand: parse args, run extractors, save to `source_graph.db` in output dir
- [x] 3.3 Implement `present` subcommand: parse `db_path`, instantiate `RelationStore` + `HTMLPresenter`, write `report.html` to db's directory
- [x] 3.4 Handle missing subcommand: print usage and exit non-zero
- [x] 3.5 Handle error cases: no valid files (extract), missing db (present)

## 4. Testing

- [x] 4.1 Update `test_presenter.py` to construct `HTMLPresenter` with a `RelationStore` passed to `__init__`
- [x] 4.2 Add test for `extract` subcommand producing `source_graph.db` without `report.html`
- [x] 4.3 Add test for `present` subcommand producing `report.html` from an existing db
- [x] 4.4 Add test for missing subcommand usage
- [x] 4.5 Add test for `present` with missing database
- [x] 4.6 Run full test suite (`pytest`) and verify all pass

## 5. Scripts and Documentation

- [x] 5.1 Update `scripts/run-self-analysis.sh` to run `extract` then `present`
- [x] 5.2 Verify self-analysis still produces correct output
- [x] 5.3 Update README with new CLI usage examples (`extract`, `present`)
