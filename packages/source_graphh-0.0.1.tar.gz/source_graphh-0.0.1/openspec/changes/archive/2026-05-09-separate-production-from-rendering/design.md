## Context

The current `cli.py` uses `argparse` with a flat argument list to perform extraction, storage, and rendering in a single pass. `HTMLPresenter.render(store, dimension)` receives a live `RelationStore` object that is constructed and populated inside the CLI. This tight coupling means the presenter cannot be invoked independently, and any change to visualization requires re-running the full extraction pipeline.

## Goals / Non-Goals

**Goals:**
- Split the CLI into two subcommands: `extract` (production) and `present` (rendering).
- Refactor `HTMLPresenter` to load data via a `GraphStore` protocol rather than receiving a live object.
- Keep all existing rendering behavior (Tree, Map, Graph views) completely unchanged.
- Preserve single-file offline HTML output as the default deliverable.

**Non-Goals:**
- No new visualization paradigms or rendering stacks (matrix, terrain, sankey, etc.).
- No dynamic server or WebSocket features.
- No changes to the SQLite schema or extraction logic.
- No WASM SQLite or in-browser querying.

## Decisions

### 1. Subcommand structure: `extract` and `present`

**Decision:** Use `argparse` subparsers to create `extract` and `present` as first-class subcommands. Remove the legacy single-command usage.

**Rationale:**
- Explicit separation makes the pipeline phases discoverable and composable.
- Each subcommand has its own help text, argument set, and validation logic.
- Aligns with standard CLI conventions (`git clone`, `git push`, etc.).

**Alternatives considered:**
- **Flags on a single command** (`--extract-only`, `--present-only`): Rejected. Creates a confusing matrix of mutually exclusive flags and unclear defaults.
- **Separate executables** (`source-graph-extract`, `source-graph-present`): Rejected. Overkill for this scope; subcommands are sufficient and keep distribution simple.

### 2. `GraphStore` protocol for presenter data access

**Decision:** Define a `GraphStore` `typing.Protocol` that abstracts `get_nodes`, `get_relations`, and `get_dimensions`. `HTMLPresenter` accepts an object satisfying this protocol. A concrete `RelationStore` adapter implements the protocol.

**Rationale:**
- Insulates the presenter from storage specifics (SQLite schema, connection lifecycle).
- Enables testing with mock stores without touching the filesystem.
- Leaves the door open for alternative backends (in-memory, network API) without presenter changes.

**Alternatives considered:**
- **Pass `db_path: str` directly**: Rejected. Ties the presenter to SQLite file paths, making testing and future backends harder.
- **Keep passing `RelationStore` directly**: Rejected. `RelationStore` is a concrete class with SQLite-specific behavior; the presenter should depend on an interface, not an implementation.

### 3. `present` output path: sibling to input database

**Decision:** `source-graph present <db_path>` writes `report.html` to the same directory as `<db_path>`. No `--output` flag for the MVP.

**Rationale:**
- Simple and predictable: the database and its rendered view live together.
- Can be relaxed later with an optional `--output` flag without breaking changes.

**Alternatives considered:**
- **Stdout default**: Rejected. HTML is large and multi-line; redirecting to a file is awkward for users who just want a report next to their database.
- **Require `--output`**: Rejected. Adds friction for the common case.

## Risks / Trade-offs

| Risk | Mitigation |
|------|------------|
| **Breaking change**: Existing users/scripts use the old single-command syntax. | Document migration in commit message and README. The change is a single release note item. |
| **Presenter protocol overhead**: `GraphStore` protocol adds an abstraction layer that may feel premature. | Protocol has only three methods matching existing `RelationStore` API; overhead is minimal. |
| **Two-step workflow friction**: Users must run two commands instead of one. | The two-step flow is the intended architecture; scripts like `run-self-analysis.sh` can wrap both steps. |
| **Test churn**: Many tests instantiate `HTMLPresenter` directly. | Update tests to use new constructor; no rendering behavior changes, so test assertions remain stable. |

## Migration Plan

1. Implement subcommands and protocol refactor.
2. Update `run-self-analysis.sh` to run `extract` then `present`.
3. Update README with new CLI usage.
4. No rollback needed — old behavior is simply unavailable; users pin to previous version if needed.

## Open Questions

- Should the `extract` command gain a `--watch` flag in the future to auto-regenerate the database on file changes?
- Should `present` support an `--output` flag for custom report paths, or is sibling-to-db sufficient long-term?
