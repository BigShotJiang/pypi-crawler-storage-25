## Why

The current `cli.py` performs extraction, storage, and rendering in a single monolithic command. Changing a view, dimension, or filter forces a full re-run of the entire pipeline even when the underlying data has not changed. Separating relationship production (extraction + storage) from relationship rendering (visualization) establishes a clean architectural boundary, eliminates redundant work, and unlocks incremental updates and multiple output formats from the same database.

## What Changes

- **Add `extract` subcommand**: `source-graph extract <files> -o <dir>` runs extraction and storage only, producing `source_graph.db` in the output directory. **BREAKING**: The legacy single-command usage `source-graph <files> -o <dir>` is removed.
- **Add `present` subcommand**: `source-graph present <db_path>` loads an existing `source_graph.db` and renders `report.html` in the same directory as the database.
- **Refactor `HTMLPresenter` interface**: Change from receiving a live `RelationStore` object to accepting a `GraphStore` protocol (or database path). The presenter instantiates its own store connection.
- **Update test suite**: Add tests for the new subcommands and update existing presenter tests to use the new initialization pattern.
- **Update `run-self-analysis.sh`**: Change from a single command to two-step `extract` + `present`.

## Capabilities

### New Capabilities
- `cli-subcommands`: Split CLI into `extract` and `present` subcommands with distinct responsibilities and argument sets.

### Modified Capabilities
- `graph-visualization`: The presenter initialization contract changes. `HTMLPresenter` no longer receives a `RelationStore` object; it loads data via a `GraphStore` protocol or database path. The rendering output behavior remains unchanged.

## Impact

- `src/source_graph/cli.py`: Complete restructuring to use `argparse` subparsers (`extract`, `present`).
- `src/source_graph/presenter.py`: `HTMLPresenter.__init__` signature changes; `render()` no longer takes a `store` argument.
- `tests/test_presenter.py`: Update to construct `HTMLPresenter` with new signature.
- `tests/`: New tests for CLI subcommand behavior.
- `scripts/run-self-analysis.sh`: Two-step invocation.
