## ADDED Requirements

### Requirement: Extract subcommand produces database
The system SHALL provide an `extract` subcommand that accepts source files and an output directory, runs extraction, and writes `source_graph.db` to the output directory. The subcommand SHALL NOT perform any rendering.

#### Scenario: Successful extraction
- **WHEN** the user runs `source-graph extract src/ -o build/`
- **THEN** the system extracts structure and dependencies from `src/`
- **AND** writes `build/source_graph.db`
- **AND** does not produce `report.html`

#### Scenario: Extraction with no valid files
- **WHEN** the user runs `source-graph extract nonexistent/ -o build/`
- **THEN** the system exits with a non-zero status code
- **AND** prints an error message indicating no valid files were found

### Requirement: Present subcommand renders from database
The system SHALL provide a `present` subcommand that accepts a path to `source_graph.db` and generates `report.html` in the same directory as the database. The subcommand SHALL load the database and invoke the presenter without re-running extraction.

#### Scenario: Successful presentation
- **WHEN** the user runs `source-graph present build/source_graph.db`
- **THEN** the system loads `build/source_graph.db`
- **AND** generates `build/report.html`
- **AND** the report contains the expected visualization

#### Scenario: Presentation with missing database
- **WHEN** the user runs `source-graph present nonexistent.db`
- **THEN** the system exits with a non-zero status code
- **AND** prints an error message indicating the database was not found

### Requirement: Subcommands have distinct help text
The system SHALL display help text specific to each subcommand when invoked with `--help`. The `extract` help SHALL describe file and output arguments. The `present` help SHALL describe the database path argument.

#### Scenario: Extract help
- **WHEN** the user runs `source-graph extract --help`
- **THEN** the help text includes descriptions for `files`, `--output`, and `--verbose`

#### Scenario: Present help
- **WHEN** the user runs `source-graph present --help`
- **THEN** the help text includes descriptions for the `db_path` argument

### Requirement: Legacy single-command usage is removed
The system SHALL NOT support the legacy single-command usage `source-graph <files> -o <dir>`. Invoking the command without a subcommand SHALL print usage instructions and exit with a non-zero status code.

#### Scenario: Missing subcommand
- **WHEN** the user runs `source-graph src/ -o build/` without a subcommand
- **THEN** the system prints usage instructions listing available subcommands
- **AND** exits with a non-zero status code
