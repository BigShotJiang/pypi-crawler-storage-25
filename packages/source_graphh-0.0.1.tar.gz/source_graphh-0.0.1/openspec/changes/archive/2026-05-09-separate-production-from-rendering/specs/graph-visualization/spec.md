## MODIFIED Requirements

### Requirement: Python provides raw graph data
The system SHALL provide a `_build_graph_data` method in `presenter.py` that outputs raw internal nodes and edges suitable for Cytoscape consumption. The output MUST include node metadata (name, kind, fqn) and edge relationships (source, target). The output MUST NOT perform SCC compression, layer assignment, or coordinate calculation.

#### Scenario: Graph data construction via presenter
- **WHEN** `render()` is called on an `HTMLPresenter` instance that has been initialized with a `GraphStore`
- **THEN** `_build_graph_data` is invoked using the presenter's internal store
- **AND** the resulting graph data is embedded in the HTML as JSON

## ADDED Requirements

### Requirement: Presenter accepts GraphStore protocol
The system SHALL initialize `HTMLPresenter` with an object satisfying the `GraphStore` protocol. The presenter SHALL use this store to query nodes, relations, and dimensions at render time. The presenter SHALL NOT accept a `RelationStore` object directly.

#### Scenario: Initialize presenter with GraphStore
- **WHEN** an `HTMLPresenter` is constructed with a `GraphStore`-compatible store
- **THEN** `render()` succeeds and produces valid HTML
- **AND** the presenter queries the store for nodes, relations, and dimensions

#### Scenario: Presenter with mock GraphStore
- **WHEN** an `HTMLPresenter` is constructed with a mock object implementing `GraphStore`
- **THEN** `render()` succeeds without requiring a real SQLite database
