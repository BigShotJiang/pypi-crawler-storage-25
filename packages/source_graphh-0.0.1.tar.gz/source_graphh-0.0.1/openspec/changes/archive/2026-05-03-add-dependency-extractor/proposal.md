## Why

Current `source-graph` only extracts containment relations (file → class → method) within individual files. Files are isolated trees with no cross-file edges, preventing users from understanding how a codebase is wired together. Adding import dependency extraction turns isolated file trees into a connected dependency graph, answering the most common question when exploring code: "what depends on what?"

## What Changes

- Add `PythonImportExtractor` implementing the `Extractor` interface, producing a new `dependencies` dimension.
- Parse absolute `import` and `from ... import` statements from Python AST.
- Resolve imported module names to file paths within the analyzed file set using reverse path resolution.
- Create `file_imports_module` relations between file nodes (or to `<external>` nodes for unresolved imports).
- Extend `HTMLPresenter` to render the `dependencies` dimension as an ASCII dependency graph in a `<pre>` block, separate from the existing tree view for `structure`.
- Update CLI to run both `PythonStructureExtractor` and `PythonImportExtractor` over input files.
- Add tests for the new extractor.

## Capabilities

### New Capabilities
- `cross-file-dependencies`: Extract and visualize cross-file import dependencies. Covers AST-based import extraction, module-to-file path resolution within the passed file set, external module handling, and ASCII dependency graph rendering in HTML output.

### Modified Capabilities
<!-- No existing spec requirements are changing. SQLite storage and CLI output behavior remain the same; only new data and rendering paths are added. -->

## Impact

- New file: `src/source_graph/python_import_extractor.py`
- Modified: `src/source_graph/cli.py` (orchestrate both extractors)
- Modified: `src/source_graph/presenter.py` (add ASCII renderer for dependencies dimension)
- New tests: `tests/test_python_import_extractor.py`
