## ADDED Requirements

### Requirement: Extractor extracts absolute import statements
The system SHALL provide a `PythonImportExtractor` that parses `import` and `from ... import` statements from Python source files and produces nodes and relations for the `dependencies` dimension.

#### Scenario: Simple import statement
- **WHEN** a file contains `import os`
- **THEN** the extractor creates a relation from the importing file to an external module node representing `os`

#### Scenario: From-import statement
- **WHEN** a file contains `from collections import defaultdict`
- **THEN** the extractor creates a relation from the importing file to an external module node representing `collections`

#### Scenario: Multiple imports in one statement
- **WHEN** a file contains `import os, sys`
- **THEN** the extractor creates separate relations for `os` and `sys`

#### Scenario: Relative imports are ignored
- **WHEN** a file contains `from . import x`
- **THEN** no relation is created for that import

### Requirement: Module names are resolved to files within the analyzed set
The system SHALL attempt to resolve imported module names to file paths among the files being analyzed. Resolution SHALL use reverse path construction: for a module name `x.y.z`, the system SHALL check candidate paths `LCP/x/y/z.py` and `LCP/x/y/z/__init__.py` where LCP is the longest common parent directory of all analyzed files.

#### Scenario: Import resolves to a module file
- **GIVEN** analyzed files include `/project/src/b.py`
- **WHEN** another file contains `import b`
- **THEN** the relation target is the node for `/project/src/b.py`

#### Scenario: Import resolves to a package init file
- **GIVEN** analyzed files include `/project/src/pkg/__init__.py`
- **WHEN** another file contains `import pkg`
- **THEN** the relation target is the node for `/project/src/pkg/__init__.py`

#### Scenario: Import resolves to a nested module
- **GIVEN** analyzed files include `/project/src/pkg/utils.py`
- **WHEN** another file contains `import pkg.utils`
- **THEN** the relation target is the node for `/project/src/pkg/utils.py`

#### Scenario: Unresolved imports become external nodes
- **WHEN** a file contains `import os` and `os` does not match any analyzed file
- **THEN** the relation target is an external module node with `source_file` set to `<external>`

### Requirement: Extractor creates file_imports_module relations
The system SHALL create relations of type `file_imports_module` in the `dependencies` dimension, with the importing file as `source_id` and the imported file (or external module) as `target_id`.

#### Scenario: Internal dependency relation
- **WHEN** `a.py` imports `b.py` and both are in the analyzed set
- **THEN** a `file_imports_module` relation exists with `source_id` = a.py's node id and `target_id` = b.py's node id
- **AND** the relation's `dimension` is `dependencies`

#### Scenario: External dependency relation
- **WHEN** `a.py` imports `json` and `json` is not in the analyzed set
- **THEN** a `file_imports_module` relation exists with `source_id` = a.py's node id
- **AND** the target is an external module node named `json`

### Requirement: CLI runs both extractors
The system SHALL run both `PythonStructureExtractor` and `PythonImportExtractor` over all input files, storing nodes and relations from both dimensions in the `RelationStore`.

#### Scenario: Single file with imports
- **WHEN** the CLI analyzes one file
- **THEN** the store contains `structure` dimension relations (file → class/function)
- **AND** the store contains `dependencies` dimension relations for any imports in that file

#### Scenario: Multiple files with cross-dependencies
- **WHEN** the CLI analyzes `a.py` and `b.py` where `a.py` imports `b`
- **THEN** the store contains a `dependencies` relation from `a.py` to `b.py`

### Requirement: HTML report renders dependencies as ASCII graph
The system SHALL render the `dependencies` dimension as an ASCII dependency graph inside a `<pre>` block, distinct from the tree view used for the `structure` dimension.

#### Scenario: Simple dependency graph
- **GIVEN** `a.py` imports `b.py` and `b.py` imports `os`
- **WHEN** the HTML report is rendered for the `dependencies` dimension
- **THEN** the output contains an ASCII graph showing `a.py ──► b.py ──► os [external]`

#### Scenario: Graph with multiple branches
- **GIVEN** `a.py` imports both `b.py` and `c.py`
- **WHEN** the HTML report is rendered for the `dependencies` dimension
- **THEN** the ASCII graph shows both branches from `a.py`

#### Scenario: Circular dependency annotation
- **GIVEN** `a.py` imports `b.py`, `b.py` imports `c.py`, and `c.py` imports `a.py`
- **WHEN** the HTML report is rendered for the `dependencies` dimension
- **THEN** the ASCII graph annotates the cycle (e.g., `[circular]`)

### Requirement: External modules are deduplicated
The system SHALL create at most one external module node per unique module name across all files.

#### Scenario: Multiple files import same external module
- **GIVEN** both `a.py` and `b.py` contain `import os`
- **WHEN** extraction completes
- **THEN** there is exactly one external module node for `os`
- **AND** there are two relations pointing to it (from `a.py` and from `b.py`)
