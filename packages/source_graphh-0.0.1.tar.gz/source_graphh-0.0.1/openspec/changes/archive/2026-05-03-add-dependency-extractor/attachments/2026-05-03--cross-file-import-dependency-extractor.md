# Idea: Cross-File Import/Dependency Extractor

**Date:** 2026-05-03
**Status:** New
**Context:** Current `source-graph` only extracts containment relations (structure dimension). Files are isolated trees with no cross-file edges, limiting the tool's ability to show how a codebase is wired together.

## Description

Add a new `PythonImportExtractor` that analyzes `import` and `from ... import` statements to produce a `dependencies` dimension. This dimension would create relations between files/modules based on import statements, turning isolated file trees into a connected dependency graph.

### Example relations

- `file_imports_module` — `a.py` imports `b` (via `import b` or `from b import ...`)
- `file_imports_symbol` — `a.py` imports `b.MyClass` (via `from b import MyClass`)

### Visualization behavior

The existing `HTMLPresenter` already supports dimension switching. A user could toggle from the **"structure"** view (file → class → method) to the **"dependencies"** view (file → imported modules/files) to understand how components connect.

### Future extensions

- Resolve relative imports (`from . import x`, `from ..pkg import y`) to actual file paths.
- Transitive dependency closure queries in `RelationStore`.
- Reverse dependency lookup ("which files import this module?").

## Motivation

1. **Real-world utility**: Understanding "what depends on what" is one of the most common questions when exploring a codebase. Structure alone doesn't answer it.
2. **Leverages existing architecture**: The `Extractor` ABC, `RelationStore` multi-dimension support, and `HTMLPresenter` dimension switching are all already built for this.
3. **No new dependencies**: Can be implemented using only the Python `ast` module, consistent with the current extractor.
4. **Natural milestone**: Adding a second dimension validates the multi-dimensional design and makes the project significantly more compelling than a single tree viewer.

## Potential Implementation

1. Create `src/source_graph/python_import_extractor.py` implementing the `Extractor` interface.
   - Parse AST for `Import` and `ImportFrom` nodes.
   - Map imported module names to file paths within the analyzed set.
   - Create `Node` objects for modules/files and `Relation` objects of type `file_imports_module` / `file_imports_symbol`.
2. Update `src/source_graph/cli.py` to run both `PythonStructureExtractor` and `PythonImportExtractor` over the input files.
3. Add tests in `tests/test_python_import_extractor.py`.
4. (Optional) Enhance the presenter to render cross-file edges more distinctly (e.g., dashed lines or different colors) when in dependency mode.

## Related Areas

- `src/source_graph/extractor.py` (base class)
- `src/source_graph/python_structure_extractor.py` (reference implementation)
- `src/source_graph/cli.py` (orchestration)
- `src/source_graph/store.py` (multi-dimension storage)
- `src/source_graph/presenter.py` (dimension switching UI)

## Notes

- Relative import resolution may require passing the project root or package context into the extractor.
- For unresolved imports (stdlib or third-party), we can still create nodes with `kind="external_module"` to show the boundary between project code and external dependencies.
- Consider whether `import x.y.z` should create relations to `x`, `x.y`, and `x.y.z` or just the leaf module.
