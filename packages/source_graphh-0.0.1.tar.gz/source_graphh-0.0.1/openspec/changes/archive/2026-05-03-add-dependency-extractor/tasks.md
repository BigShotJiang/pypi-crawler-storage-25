## 1. Core Extractor Implementation

- [x] 1.1 Create `src/source_graph/python_import_extractor.py` implementing the `Extractor` interface with `dimension = "dependencies"`
- [x] 1.2 Implement AST traversal to collect `ast.Import` and `ast.ImportFrom` nodes (absolute imports only)
- [x] 1.3 Implement reverse path resolution: construct candidate file paths from module name and check against the passed file set
- [x] 1.4 Create `file` nodes for importing files and `<external>` nodes for unresolved imports, ensuring external nodes are deduplicated by module name
- [x] 1.5 Create `file_imports_module` relations with `dimension="dependencies"`

## 2. CLI Integration

- [x] 2.1 Update `src/source_graph/cli.py` to instantiate both `PythonStructureExtractor` and `PythonImportExtractor`
- [x] 2.2 Run both extractors over all input files and merge results into the `RelationStore`
- [x] 2.3 Verify that `--dimension dependencies` can be passed and the correct dimension is visualized

## 3. Presenter Enhancement

- [x] 3.1 Add `_build_dependency_data()` method to `HTMLPresenter` that queries `dependencies` dimension relations and builds an ASCII dependency graph
- [x] 3.2 Implement cycle detection for the ASCII graph and annotate cycles with `[circular]`
- [x] 3.3 Add `renderDependencies()` JS function to display the ASCII graph inside a `<pre>` block when `dependencies` dimension is selected
- [x] 3.4 Wire dimension switching logic to use tree renderer for `structure` and ASCII renderer for `dependencies`

## 4. Tests

- [x] 4.1 Create `tests/test_python_import_extractor.py` with test cases for simple imports, from-imports, multi-import, unresolved imports, and internal file resolution
- [x] 4.2 Add test for `__init__.py` resolution (e.g., `import pkg` resolves to `pkg/__init__.py`)
- [x] 4.3 Add test verifying external module deduplication
- [x] 4.4 Run full test suite to ensure no regressions in existing extractors, store, or presenter

## 5. Verification

- [x] 5.1 Run CLI against the project's own source files (`src/source_graph/*.py`) and verify `dependencies` dimension renders correctly
- [x] 5.2 Verify `structure` dimension continues to work unchanged
- [x] 5.3 Review generated HTML for readability of ASCII dependency graph
