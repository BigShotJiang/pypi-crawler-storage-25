## Context

The `source-graph` tool currently extracts only containment relations (structure dimension: file → class → function → method) using `PythonStructureExtractor`. Each file is an isolated tree. There is no way to see how files depend on each other.

The architecture already supports multiple dimensions: `Extractor` ABC, `RelationStore` with dimension filtering, and `HTMLPresenter` with dimension switching. Adding a second dimension validates this multi-dimensional design and significantly increases the tool's utility.

## Goals / Non-Goals

**Goals:**
- Extract absolute import statements (`import x`, `from x import y`) from Python source files.
- Map imported module names to files within the passed file set.
- Create `dependencies` dimension relations linking importing files to imported files.
- Mark unresolved imports (stdlib, third-party, not in file set) as `<external>` nodes.
- Render the `dependencies` dimension as an ASCII dependency graph in the HTML report.

**Non-Goals:**
- Relative imports (`from . import x`) — deferred to future enhancement.
- Symbol-level granularity (`from b import MyClass`) — deferred to future enhancement (see idea `2026-05-03--symbol-level-import-dependency-extraction.md`).
- True graph layout algorithms (force-directed, etc.) — ASCII text rendering is sufficient for MVP.
- Resolving imports outside the passed file set (e.g. scanning site-packages or PYTHONPATH).
- C extensions, namespace packages, or dynamic imports.

## Decisions

### Decision: Reverse path resolution (Path 2)

**Choice:** Instead of inferring module names for each file (forward mapping), construct candidate file paths from the import statement and check against the known file set.

**Rationale:** Avoids assuming a package root. As long as the relative path relationship between files is correct, imports resolve accurately. Simple and robust for MVP.

**Alternatives considered:**
- Forward inference (LCP → module names): Requires guessing the package root, which can be wrong if the user passes a subset of files.

### Decision: Module-level relations only

**Choice:** Create one `file_imports_module` relation per import, linking the importing file to the target file (or `<external>`).

**Rationale:** Matches the "file dependency" abstraction. Keeps the data model simple and the renderer straightforward.

**Alternatives considered:**
- Symbol-level relations: Would require tracking re-exports and definitions, significantly more complex.
- Multi-hop relations (`import x.y.z` → links to x, x.y, and x.y.z): Over-engineered for file-level dependency analysis.

### Decision: `__init__.py` treated as a regular file

**Choice:** When `import pkg` resolves to `pkg/__init__.py`, the relation target is the `__init__.py` file node itself. No alias or virtual module node is created.

**Rationale:** Maintains consistent "file dependency" semantics across all nodes. No special-case logic in the data model or renderer.

### Decision: ASCII `<pre>` block for dependency visualization

**Choice:** Use a simple ASCII text graph inside a `<pre>` tag for the `dependencies` dimension, separate from the existing collapsible tree for `structure`.

**Rationale:** Zero external dependencies, trivial to implement, and clearly communicates file-to-file relationships. A true graph renderer would require layout algorithms or external JS libraries.

**Alternatives considered:**
- Adjacency list cards: Requires more HTML/CSS structure.
- True graph visualization (D3.js, etc.): Violates the zero-dependency constraint.

### Decision: Absolute imports only in MVP

**Choice:** The extractor only handles `import x.y` and `from x import y`. Relative imports are skipped.

**Rationale:** Absolute imports cover the majority of real-world code. Relative import resolution requires package-context awareness (current file's position in the package hierarchy), which adds complexity without proportional MVP value.

## Risks / Trade-offs

| Risk | Mitigation |
|------|-----------|
| Import resolution is approximate (module namespace → file path) | Document the limitation. Unresolved imports gracefully fall back to `<external>`. |
| Circular dependencies in the ASCII graph may be confusing | Detect cycles during rendering and annotate them (e.g. `[circular]`). |
| Large codebases produce unreadable ASCII graphs | ASCII graph is an MVP visualization. Future enhancements can add filtering or interactive views. |
| `__init__.py` display may look odd to users | Consistent with the "file dependency" contract. Users familiar with Python understand `__init__.py` semantics. |
