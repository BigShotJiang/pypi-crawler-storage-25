## ADDED Requirements

### Requirement: Discover available goal contexts
The system SHALL scan `ideas/goals/` for goal files and present them alongside two preset options: "No goal" and "All ideas".

#### Scenario: Goals exist
- **WHEN** the skill is triggered
- **THEN** the agent scans `ideas/goals/*/goal.md`
- **AND** presents discovered goals plus "No goal" and "All ideas" options

#### Scenario: No goals exist
- **WHEN** the skill is triggered and `ideas/goals/` is empty or absent
- **THEN** the agent presents only "No goal" and "All ideas" options
- **AND** does not error or fail

### Requirement: Select target context via user interaction
The system SHALL use `AskUserQuestion` to let the user select one context from the discovered options.

#### Scenario: User selects a specific goal
- **WHEN** the agent presents goal context options
- **AND** the user selects a specific goal
- **THEN** the agent proceeds with that goal as the recommendation context

#### Scenario: User selects "All ideas"
- **WHEN** the agent presents goal context options
- **AND** the user selects "All ideas"
- **THEN** the agent proceeds with a cross-goal comprehensive view

### Requirement: Read goal content in full
When a specific goal is selected, the system SHALL read the corresponding `goal.md` file in its entirety to understand the target direction, present state, success criteria, and open questions.

#### Scenario: Goal file is read
- **WHEN** a user selects a specific goal context
- **THEN** the agent reads the full text of the selected `goals/<name>/goal.md`
- **AND** retains this content for subsequent reasoning steps

### Requirement: Read active ideas in full
The system SHALL read the full text of all active idea files from `ideas/*.md`, excluding any files in `ideas/archive/`.

#### Scenario: Active ideas are loaded
- **WHEN** the agent begins idea analysis
- **THEN** the agent reads all `ideas/*.md` files
- **AND** excludes `ideas/archive/` from consideration

### Requirement: Parallel reading with global associative reasoning
The system SHALL use parallel sub-agents to read and summarize idea files, then perform global associative reasoning in the main agent.

#### Scenario: Multiple ideas are processed in parallel
- **WHEN** there are more than 10 active ideas
- **THEN** the agent launches parallel sub-agents to read and summarize subsets of ideas
- **AND** the main agent receives all summaries
- **AND** the main agent performs cross-idea relationship analysis

#### Scenario: Small idea set handled directly
- **WHEN** there are 10 or fewer active ideas
- **THEN** the main agent may read all ideas directly without parallel sub-agents

### Requirement: Recommend ideas through reasoning
The system SHALL analyze each idea's relevance, value, maturity, and timing based on the goal content and idea full text, producing prioritized recommendations with rationale.

#### Scenario: Goal-aware recommendation
- **WHEN** a specific goal is selected and ideas are loaded
- **THEN** the agent assesses each idea against the goal's direction and needs
- **AND** produces a prioritized list with contextual rationale for each recommendation
- **AND** the assessment is based on content understanding, not frontmatter metadata

#### Scenario: No-goal recommendation
- **WHEN** "No goal" is selected and ideas are loaded
- **THEN** the agent assesses ideas based on intrinsic value, recency, and coherence
- **AND** produces a prioritized list with rationale

### Requirement: Identify gaps after establishing coverage
After producing recommendations, the system SHALL identify areas in the goal description that are not covered by any existing idea.

#### Scenario: Goal has uncovered areas
- **WHEN** recommendations are complete
- **AND** the goal describes needs or directions with no corresponding idea
- **THEN** the agent identifies and describes these uncovered areas

#### Scenario: Goal is well-covered
- **WHEN** recommendations are complete
- **AND** all major goal directions have corresponding ideas
- **THEN** the agent reports that no significant gaps are identified

### Requirement: Conversational output
The system SHALL present recommendations and gaps in free-form conversational output, optionally including follow-up questions or next-step suggestions.

#### Scenario: Natural response format
- **WHEN** the agent completes analysis
- **THEN** the output is in natural conversational language
- **AND** is not constrained to a rigid template or fixed sections
- **AND** may include contextual follow-up questions

### Requirement: Graceful degradation
When no goals directory exists or no goals are present, the system SHALL fall back to a meaningful browsing experience without failing.

#### Scenario: Missing goals directory
- **WHEN** `ideas/goals/` does not exist
- **THEN** the agent proceeds with "All ideas" context automatically
- **AND** produces reasoning-based recommendations across all ideas
