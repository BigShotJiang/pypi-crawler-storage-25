## 1. Setup

- [x] 1.1 Create skill directory `.claude/skills/suggest-ideas/`

## 2. Skill Definition — Workflow

- [x] 2.1 Write SKILL.md frontmatter with name, description, and trigger phrases
- [x] 2.2 Write DISCOVER step: scan `ideas/goals/` and present preset options ("No goal", "All ideas")
- [x] 2.3 Write SELECT step: use AskUserQuestion for context selection
- [x] 2.4 Write READ GOAL step: read goal.md in full when specific goal selected

## 3. Skill Definition — Idea Reading

- [x] 3.1 Write parallel sub-agent reading strategy for `ideas/*.md` (excluding archive/)
- [x] 3.2 Write sub-agent prompt template for idea summarization
- [x] 3.3 Write main agent integration: receive summaries and retain goal context

## 4. Skill Definition — Reasoning Modes

- [x] 4.1 Write Mode 1 (recommendation) guidelines: content-based reasoning, no mechanical scoring
- [x] 4.2 Write Mode 2 (gap discovery) guidelines: sequential to Mode 1, identify uncovered goal areas
- [x] 4.3 Write reasoning constraints: full text only, frontmatter not used for judgment

## 5. Skill Definition — Output and Edge Cases

- [x] 5.1 Write conversational output guidelines: free-form, natural language, optional follow-ups
- [x] 5.2 Write graceful degradation rules for missing goals/ directory
- [x] 5.3 Write special context handling: "No goal" and "All ideas" modes

## 6. Verification

- [x] 6.1 Review complete SKILL.md against design.md decisions and spec.md requirements
- [x] 6.2 Verify skill triggers match intended phrases ("What should I work on?", "Suggest ideas", etc.)
