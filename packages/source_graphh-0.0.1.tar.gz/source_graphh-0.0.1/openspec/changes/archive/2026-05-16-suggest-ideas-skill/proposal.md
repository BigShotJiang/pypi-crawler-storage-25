## Why

The project has a `record-idea` skill for producing ideas but no skill for consuming them. When a user starts a session facing 26 ideas, there is no tool to help them navigate from goals to actionable ideas. This change creates `suggest-ideas` as the consumption-side counterpart, closing the production-consumption loop.

## What Changes

- Create `.claude/skills/suggest-ideas/SKILL.md` — a new Claude skill that recommends ideas based on active goals
- The skill operates in two modes:
  - **Filter**: Recommends existing ideas that best serve a selected goal through Agent reasoning (not mechanical scoring)
  - **Inspire**: Identifies gaps where a goal describes needs not yet covered by any idea
- The skill supports three entry contexts:
  - Specific goal from `goals/*/goal.md`
  - "No goal" — browse unbound ideas
  - "All" — cross-goal comprehensive view
- The skill reads idea **full text** for understanding, not frontmatter metadata
- Parallel sub-agents read and summarize ideas; main agent performs global associative reasoning
- Archive ideas are excluded from consideration

## Capabilities

### New Capabilities

- `suggest-ideas`: Agent-assisted idea discovery and recommendation skill. Navigates from goals to actionable ideas through conversational reasoning, with gap discovery for uncovered goal areas.

### Modified Capabilities

- None. This change introduces a new skill without altering existing system behavior or requirements.

## Impact

- New file: `.claude/skills/suggest-ideas/SKILL.md`
- No changes to existing code, APIs, or dependencies
- No breaking changes
- Relies on existing `ideas/goals/` and `ideas/` directory conventions
