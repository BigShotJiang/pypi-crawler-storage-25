## Context

The project has a mature `record-idea` skill for persisting ideas to `ideas/*.md`, but no skill for discovering and prioritizing them. When a user asks "What should I work on?", the agent has no structured way to navigate the 26+ ideas toward active goals. This design creates `suggest-ideas` as the consumption-side counterpart.

The `ideas/` directory recently gained a `goals/` subdirectory with the first active goal (`goal-achievement-system`). This creates the minimal infrastructure needed for goal-aware recommendation, but most ideas lack structured frontmatter and goal bindings.

## Goals / Non-Goals

**Goals:**
- Create `suggest-ideas` as the action entry point — the first interaction when a user asks "What should I work on?"
- Enable goal-aware idea recommendation through Agent reasoning, not mechanical algorithms
- Identify gaps where goal descriptions are not covered by existing ideas
- Work with current data (mixed frontmatter and inline metadata, incomplete goal bindings)

**Non-Goals:**
- Modify the `record-idea` skill or its template
- Migrate existing ideas to structured frontmatter
- Process or include `ideas/archive/` content
- Generate new idea drafts (remain strictly on the consumption side)
- Add goal health checks or evaluation triggers
- Handle multi-level goal recursion (goal → sub-goal → idea nesting)
- Use alignment states (aligned/divergent/enriching) in recommendation logic

## Decisions

**1. Idea full text is the source of truth, not frontmatter**
- *Rationale*: Frontmatter is abstract, easily outdated, and may not reflect idea evolution. The Agent's strength is understanding content, not parsing metadata.
- *Alternative considered*: Dual-track parsing (frontmatter + inline fallback). Rejected because it encourages reliance on stale structured data rather than live content understanding.

**2. Agent reasoning replaces mechanical scoring**
- *Rationale*: Scoring algorithms (status points + recency bonus + keyword matching) waste the Agent's capability. Recommendation requires contextual judgment about relevance, maturity, timing, and value — all of which the Agent can assess from full text.
- *Alternative considered*: Weighted scoring with multiple dimensions. Rejected as overly rigid and unable to capture semantic relationships.

**3. Mode 1 (recommendation) and Mode 2 (gap discovery) are sequential, not parallel**
- *Rationale*: Gap discovery depends on understanding what is already covered. The Agent must first establish a coverage landscape through recommendations before it can accurately identify blank areas.
- *Alternative considered*: Parallel algorithmic processing. Rejected because gap detection without coverage context produces false positives.

**4. Parallel sub-agents read and summarize; main agent performs global reasoning**
- *Rationale*: 26+ idea files risk context window exhaustion. Sub-agents handle bulk reading and compression, while the main agent retains the goal context and performs cross-idea associative reasoning.
- *Trade-off*: Sub-agents may miss subtle cross-idea relationships. Mitigated by the main agent's global view and ability to re-read specific ideas for deeper analysis.

**5. Conversational output format**
- *Rationale*: A rigid template constrains the Agent's ability to adapt to context. Free-form output allows natural expression, nuanced rationale, and contextual follow-up suggestions.
- *Alternative considered*: Structured output with fixed sections. Rejected as too mechanical for a reasoning-driven skill.

**6. Two preset options: "No goal" and "All ideas"**
- *Rationale*: Not all ideas are goal-bound. Users need a way to browse unbound ideas or take a cross-goal comprehensive view.

**7. Archive ideas excluded**
- *Rationale*: The archive currently has minimal content and does not yet represent valuable historical constraints. Including it would add noise without benefit.

## Risks / Trade-offs

- **[Risk]** Sub-agent grouping may obscure cross-group idea relationships → **Mitigation**: Main agent retains all summaries and performs global associative reasoning; can re-read specific ideas if relationships are suspected.

- **[Risk]** Context window pressure from goal + 26 idea summaries + reasoning → **Mitigation**: Sub-agents compress each idea to 2-3 sentence summaries; main agent only sees compressed forms unless deep analysis is needed.

- **[Risk]** "No goal" and "All" contexts weaken or eliminate Mode 2 (gap discovery) since there is no target reference → **Mitigation**: Accepted as design constraint. In "No goal" mode, Mode 2 becomes "direction clustering" (identifying whether scattered ideas form coherent directions). In "All" mode, Mode 2 becomes "coverage imbalance" (which goals are over/under-served).

- **[Trade-off]** Reading full text is slower than parsing frontmatter → Accepted. Accuracy and relevance of recommendations outweigh speed for an interactive skill.

## Migration Plan

No migration needed. This change creates a single new file (`.claude/skills/suggest-ideas/SKILL.md`) without modifying existing code or data.

## Open Questions

1. Should the skill proactively suggest creating a new goal when "No goal" context shows strong clustering in a particular direction?
2. What is the optimal number of ideas per sub-agent for parallel reading? (Current estimate: 8-10 per sub-agent for 26 ideas.)
3. Should the skill offer to transition into `record-idea` or OpenSpec change workflow after making a recommendation?
