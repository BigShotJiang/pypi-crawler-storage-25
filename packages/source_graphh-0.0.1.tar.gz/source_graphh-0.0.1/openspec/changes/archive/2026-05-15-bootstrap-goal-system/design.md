## Context

The project's `ideas/` directory contains 22 well-formed ideas, each cross-referenced, yet they form a maze without a destination. The `goal-achievement-system` idea identified the fundamental gap: the idea mechanism manages *how* ideas are recorded and linked, but lacks a *why* dimension — a shared direction that ideas serve as path segments toward.

This change is the first practical step toward the Goal-Present-Path model. It does not implement the full system; it bootstraps the physical infrastructure for explicit goal storage by promoting the `goal-achievement-system` idea itself into the first goal.

## Goals / Non-Goals

**Goals:**
- Establish `ideas/goals/<goal-name>/` as the canonical location for explicit goal files
- Promote `goal-achievement-system` from idea to goal as the inaugural entry
- Define frontmatter conventions for goal files and idea-to-goal binding
- Preserve goal iteration history via the `history/` subdirectory

**Non-Goals:**
- Modifying any source code, CLI commands, or existing skill definitions
- Migrating existing ideas to bind to goals (opt-in for future ideas only)
- Automating goal creation, promotion, or archiving (all manual for now)
- Creating a README, index, or dashboard for goals/
- Enforcing that every idea must bind to a goal

## Decisions

### 1. Place `goals/` inside `ideas/`, not at project root

**Rationale:** The user explicitly stated this preference — goals grew from the soil of ideas, so they naturally root there. Semantically goals sit above ideas, but directory placement is a design preference, not a structural constraint.

**Alternatives considered:**
- `goals/` at project root — cleaner separation, but rejected per user preference
- `goals/` as a sibling to `ideas/` under `.claude/` — too hidden, disconnected from the idea soil

### 2. Each goal lives in its own folder

**Rationale:** Maximizes cohesion. History, attachments, and future extensions (images, reference materials) all live within the goal's boundary. Archiving is a simple directory move.

**Alternatives considered:**
- Flat files in `goals/` — rejected because history would need naming convention hacks to avoid collisions
- Goal file + separate `history/` at `goals/` level — rejected because cross-goal history mixing is confusing

### 3. Goal file named `goal.md`, no date prefix for active goals

**Rationale:** Active goals are living entities referenced by name. A stable filename (`goal.md`) makes linking predictable. Only historical snapshots get dated names.

### 4. History versions named `vN-YYYYMMDD.md`, source idea as `initial-idea.md`

**Rationale:** Version + date gives both sequence and temporal context. The source idea is preserved as `initial-idea.md` so the promotion path is always traceable.

### 5. Free-form body, structured frontmatter only

**Rationale:** The user explicitly requested free-form content. Goals are human-authored and human-responsible; rigid templates would constrain the "living entity" nature. Frontmatter is the minimal machine-readable interface needed for linking.

### 6. Goal-to-goal and idea-to-goal linking via frontmatter, not body links

**Rationale:** Links in body text are for human narrative. Frontmatter links are for machine readability and future tooling (dashboard generation, graph extraction). Separating the two prevents link rot in structured relationships.

## Risks / Trade-offs

| Risk | Mitigation |
|------|-----------|
| Goal file becomes stale as the project evolves | `updated_at` frontmatter makes staleness visible; periodic manual review encouraged |
| Content duplication between source idea and goal file | Expected — the goal is a living fork, not a snapshot. The `history/initial-idea.md` preserves the origin |
| Multiple active goals lead to folder sprawl | Low risk initially; if it becomes a problem, archive by moving entire directories |
| Frontmatter conventions may drift over time | Documented in this change; future changes can codify conventions |

## Migration Plan

Not applicable — this is a greenfield mechanism with no existing data to migrate.

## Open Questions

1. When a goal is archived, should the entire folder move to `goals/archive/` or just the `goal.md` file?
2. Should `updated_at` be manually maintained, or could a git hook update it?
3. How many levels of `related_goals` recursion should be considered healthy before it becomes a graph problem?
