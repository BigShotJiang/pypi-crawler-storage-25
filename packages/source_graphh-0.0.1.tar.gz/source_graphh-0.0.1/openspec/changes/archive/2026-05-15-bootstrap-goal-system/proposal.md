## Why

The project has accumulated 22 ideas in `ideas/`, all well-recorded and cross-referenced, yet they form a maze without a destination. The `goal-achievement-system` idea identified the core gap: ideas need goals. This change bootstraps the first practical step by giving goals a physical, explicit home in the project's idea mechanism.

## What Changes

- Create `ideas/goals/<goal-name>/` directory structure for explicit goal storage
- Promote `ideas/2026-05-12--goal-achievement-system-the-ultimate-form-of-idea-mechanism.md` from idea to goal as the inaugural entry
- Establish the goal promotion workflow: idea → `goals/<name>/goal.md` + `history/`
- Define frontmatter conventions for goal files (`related_goals`, `created_at`, `updated_at`) and idea-to-goal binding (`serves_goal`)

## Capabilities

### New Capabilities
- `goal-management`: Directory-based goal storage with versioning (`history/`), free-form content, and frontmatter-based goal-to-goal and idea-to-goal linkage.

### Modified Capabilities
- *(none — this is a new meta-mechanism that does not alter existing product specs)*

## Impact

- New directory: `ideas/goals/`
- One idea file promoted (original retained in `ideas/`)
- Frontmatter conventions introduced for future idea and goal files
- No code, API, or dependency changes
