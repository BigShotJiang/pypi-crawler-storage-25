## ADDED Requirements

### Requirement: Goal storage directory structure
Each goal SHALL reside in its own directory under `ideas/goals/<goal-name>/`. The directory SHALL contain at minimum a `goal.md` file representing the current version of the goal. Optional content such as reference materials or attachments MAY be added to the same directory.

#### Scenario: Goal directory created
- **WHEN** a goal named "goal-achievement-system" is established
- **THEN** a directory `ideas/goals/goal-achievement-system/` exists
- **AND** it contains a file named `goal.md`

#### Scenario: Goal directory supports attachments
- **WHEN** a goal requires supplementary reference material
- **THEN** additional files MAY be placed in `ideas/goals/<goal-name>/`
- **AND** they coexist alongside `goal.md` without interfering with the goal mechanism

### Requirement: Goal file frontmatter
The `goal.md` file SHALL contain a YAML frontmatter block with the fields `related_goals`, `created_at`, and `updated_at`. The `related_goals` field SHALL be a list of goal directory names. The date fields SHALL use the `YYYY-MM-DD` format.

#### Scenario: Goal file with valid frontmatter
- **WHEN** a goal file is created
- **THEN** its frontmatter contains `related_goals`, `created_at`, and `updated_at`
- **AND** `related_goals` is an array of strings
- **AND** date fields match `YYYY-MM-DD`

#### Scenario: Goal with no related goals
- **WHEN** a goal has no relationship to other goals
- **THEN** `related_goals` SHALL be an empty array `[]`

### Requirement: Goal iteration history
Each goal directory SHALL contain a `history/` subdirectory. When a goal is iterated, the current `goal.md` SHALL be copied into `history/` with the filename `vN-YYYYMMDD.md` before modification. The original idea that was promoted to become a goal SHALL be preserved as `history/initial-idea.md`.

#### Scenario: First iteration of a goal
- **WHEN** a goal is iterated for the first time
- **THEN** the previous `goal.md` is copied to `history/v1-20260512.md`
- **AND** a new `goal.md` replaces it

#### Scenario: Source idea preserved on promotion
- **WHEN** an idea is promoted to become a goal
- **THEN** the original idea content is copied to `history/initial-idea.md`
- **AND** the source idea file remains in `ideas/` at its original location

### Requirement: Idea-to-goal binding
An idea file MAY declare which goal it serves via a `serves_goal` field in its YAML frontmatter. The value SHALL be the goal directory name (not a file path). Idea files SHALL NOT be required to declare a `serves_goal`.

#### Scenario: Idea bound to a goal
- **WHEN** an idea declares `serves_goal: goal-achievement-system`
- **THEN** the binding refers to `ideas/goals/goal-achievement-system/`

#### Scenario: Unbound idea
- **WHEN** an idea does not declare `serves_goal`
- **THEN** it is considered unbound and valid
- **AND** no error or warning is produced
