## ADDED Requirements

### Requirement: Graph view renders internal dependency graph
The system SHALL render a new "Graph" view for the `dependencies` dimension using Cytoscape.js. This view MUST display only internal nodes and internal dependency edges. External dependencies MUST be excluded.

#### Scenario: Dependencies dimension loads with Graph as default
- **WHEN** the user opens the report and the default dimension is `dependencies`
- **THEN** the Graph view is displayed by default
- **AND** the view toggle shows "Graph" as the selected option

#### Scenario: Switching to Graph view from Map
- **WHEN** the user selects "Graph" from the view toggle while on the `dependencies` dimension
- **THEN** the Graph view replaces the Map view in the container
- **AND** Cytoscape initializes with the internal dependency data

### Requirement: Python provides raw graph data
The system SHALL provide a `_build_graph_data` method in `presenter.py` that outputs raw internal nodes and edges suitable for Cytoscape consumption. The output MUST include node metadata (name, kind, fqn) and edge relationships (source, target). The output MUST NOT perform SCC compression, layer assignment, or coordinate calculation.

#### Scenario: Graph data construction
- **WHEN** `render()` is called for the `dependencies` dimension
- **THEN** `_build_graph_data` is invoked alongside existing `_build_dependency_data` and `_build_dependency_map_data`
- **AND** the resulting graph data is embedded in the HTML as JSON

### Requirement: Frontend detects strongly connected components
The system SHALL detect strongly connected components (SCCs) in the browser using Tarjan's algorithm on the raw graph data. Each SCC MUST be rendered as a Cytoscape compound node (a parent node containing its member nodes). Edges between nodes inside the same SCC MUST be visible.

#### Scenario: Single-node SCC
- **WHEN** a node has no cycles with any other node
- **THEN** it is rendered as a standalone node with no parent

#### Scenario: Multi-node SCC
- **WHEN** nodes A, B, and C form a cycle (A→B→C→A)
- **THEN** a compound parent node is created containing A, B, and C
- **AND** the internal edges (A→B, B→C, C→A) are rendered inside the compound
- **AND** edges from outside the compound to any member node target the member node

### Requirement: Orthogonal edge routing
The system SHALL render all edges using orthogonal (Manhattan-style) routing. Edges MUST travel vertically and horizontally only, with right-angle bends.

#### Scenario: Edge between two layers
- **WHEN** an edge connects a node in a higher layer to a node in a lower layer
- **THEN** the edge follows Cytoscape's `taxi` routing with downward direction
- **AND** the edge does not overlap with nodes

### Requirement: Interactive zoom and pan
The system SHALL allow users to zoom and pan the graph freely. The graph MUST support mouse wheel zoom, click-and-drag pan, and pinch-to-zoom on touch devices.

#### Scenario: Zoom out to see full graph
- **WHEN** the user scrolls down (zoom out) or uses the fit button
- **THEN** the entire graph becomes visible within the viewport

#### Scenario: Zoom in to inspect details
- **WHEN** the user scrolls up (zoom in)
- **THEN** node labels and edge details become more readable
- **AND** the zoom level is constrained between a minimum and maximum bound

### Requirement: Click-to-highlight downstream dependencies
The system SHALL highlight a node and all its downstream (transitive) dependencies when clicked. Unrelated nodes and edges MUST be visually dimmed.

#### Scenario: Click on a node with downstream dependencies
- **WHEN** the user clicks a node that has outgoing edges
- **THEN** the clicked node and all reachable downstream nodes are highlighted
- **AND** all other nodes and edges are dimmed to 20% opacity
- **AND** clicking on empty space resets the highlight

### Requirement: Node tooltip on hover
The system SHALL display a tooltip when hovering over a node. The tooltip MUST show the node's name and dependency statistics (outgoing edge count, incoming edge count).

#### Scenario: Hover over a node
- **WHEN** the user hovers over any node
- **THEN** a tooltip appears near the cursor showing the node's information
- **AND** the tooltip disappears when the mouse leaves the node

### Requirement: Existing views remain untouched
The system SHALL NOT modify the behavior, appearance, or data pipelines of the existing Map view and Tree view. The Graph view MUST coexist as a peer option.

#### Scenario: Switching between all three views
- **WHEN** the user switches from Graph to Map to Tree and back to Graph
- **THEN** each view renders correctly without side effects on the others
- **AND** the Map view continues to use its fixed SVG canvas
- **AND** the Tree view continues to use its HTML list rendering
