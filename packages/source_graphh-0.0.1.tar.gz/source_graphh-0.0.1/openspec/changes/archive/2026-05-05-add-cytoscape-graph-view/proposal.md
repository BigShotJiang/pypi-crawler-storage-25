## Why

The current Map view uses a fixed 960px canvas with straight diagonal lines for edges. This creates visual clutter as the dependency graph grows—nodes get squeezed together and edges cross at arbitrary angles, making it hard to trace dependency paths. We need a modern graph visualization that supports an infinite canvas with zoom/pan, orthogonal edge routing, and automatic layered layout, while keeping the existing Map and Tree views untouched as stable baselines.

## What Changes

- **Add Graph view**: A new visualization mode for the `dependencies` dimension, powered by Cytoscape.js with cytoscape-dagre layout. It appears alongside existing Map and Tree views in the view toggle.
- **Add `_build_graph_data` method**: A new backend method in `presenter.py` that outputs raw internal nodes and edges (uncompressed, no SCC collapsing) for the Graph view renderer to consume.
- **Frontend SCC detection**: The Graph view runs Tarjan's SCC algorithm in the browser to identify strongly connected components and render them as Cytoscape compound nodes (parent containers).
- **Orthogonal edge routing**: Use Cytoscape's `curve-style: taxi` for Manhattan-style edges.
- **Extended view toggle**: The view selector dropdown expands from `[Map, Tree]` to `[Graph, Map, Tree]`. Graph becomes the default view for the dependencies dimension.
- **No changes to Map/Tree**: Existing Map view (fixed SVG canvas) and Tree view (HTML/CSS) remain completely untouched.

## Capabilities

### New Capabilities
- `graph-visualization`: Interactive dependency graph rendering with Cytoscape.js, including zoom/pan, orthogonal edge routing, compound nodes for SCCs, click-to-highlight downstream, and tooltips.

### Modified Capabilities
- *(none — existing views and data pipelines remain unchanged)*

## Impact

- `src/source_graph/presenter.py`: Add `_build_graph_data()` and extend the HTML template with Cytoscape CDN imports and `renderGraph()` JavaScript function.
- Frontend dependencies: Cytoscape.js and cytoscape-dagre loaded via CDN (unpkg).
- UI: View toggle in the header gains a third option.
- Performance: Large graphs (hundreds of nodes) are handled by Cytoscape's Canvas renderer; initial load includes ~350KB of JS from CDN.
