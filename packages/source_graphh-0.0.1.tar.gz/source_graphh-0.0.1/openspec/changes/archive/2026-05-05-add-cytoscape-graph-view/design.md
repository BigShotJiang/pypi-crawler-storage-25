## Context

The current `src/source_graph/presenter.py` generates a single self-contained HTML file with three visualization modes:

- **Tree view**: Recursive HTML list with CSS, for all dimensions.
- **Map view** (dependencies only): Fixed 960px SVG canvas with diagonal `<line>` edges, SCC-compressed nodes, and manual DOM-based highlighting.
- **Dependency graph view** (dependencies only): Same data as Tree view but rendered as a collapsible tree.

The Map view is node-centric: Python calculates SCCs, assigns layers, computes coordinates, and emits SVG strings. This creates a rigid system where the canvas width caps the expressiveness of the layout.

## Goals / Non-Goals

**Goals:**
- Introduce a **Graph view** using Cytoscape.js with cytoscape-dagre for an infinite-canvas, interactive dependency visualization.
- Achieve **data/presentation separation**: Python outputs raw graph data; the browser handles layout (Sugiyama via Dagre), edge routing (taxi), and interaction.
- Render SCCs as **compound nodes** (parent containers with visible children) rather than collapsed single nodes.
- Keep the Graph view as a **peer to Map and Tree**, not a replacement.

**Non-Goals:**
- No modifications to Map view, Tree view, or their data pipelines.
- No changes to extraction or storage layers (`store.py`, extractors).
- No display of external dependencies in Graph view (same filter as Map view).
- No build tools or bundlers; keep the single-file HTML output model.
- No server-side rendering or dynamic data fetching.

## Decisions

### 1. Cytoscape.js over hand-written SVG

**Decision**: Use Cytoscape.js (Canvas renderer) + cytoscape-dagre for layout, rather than extending the SVG-based Map view with panzoom and custom orthogonal routing.

**Rationale**:
- Cytoscape provides battle-tested implementations of zoom/pan, orthogonal edges (`taxi`), compound nodes, and graph traversal APIs.
- The "data extraction / view presentation" separation aligns with the project's maturation direction.
- Custom SVG orthogonal routing + crossing minimization + compound nodes would require reimplementing a large subset of what Cytoscape already does.

**Alternatives considered**:
- **Hand-written SVG + panzoom**: Rejected. Finite canvas was the root problem; simply adding zoom to SVG does not solve layout quality (crossing minimization, edge bundling).
- **D3 + custom layout**: Rejected. D3-zoom and D3 layouts are powerful but require significantly more glue code for compound graphs and orthogonal routing.
- **Cytoscape only, no dagre**: Rejected. Cytoscape's built-in layouts (grid, circle, concentric) do not produce readable hierarchical DAG visualizations. Dagre is the standard Sugiyama implementation for Cytoscape.

### 2. Frontend SCC detection

**Decision**: Run Tarjan's SCC algorithm in the browser on raw node/edge data, then construct Cytoscape compound nodes.

**Rationale**:
- Preserves the "rendering layer handles rendering concerns" boundary. Python outputs raw facts; the browser decides how to group them visually.
- Reuses the same algorithmic logic already present in `_build_dependency_map_data`, but expressed in JavaScript where the compound-node API lives.
- If future views need different grouping strategies (e.g., package-level grouping), the backend data does not need to change.

**Alternatives considered**:
- **Python-side SCC + compound metadata**: Rejected. Would require backend to know about Cytoscape's compound-node data model, violating separation.

### 3. CDN delivery for Cytoscape dependencies

**Decision**: Load `cytoscape` and `cytoscape-dagre` (plus `dagre`) from unpkg CDN via `<script>` tags.

**Rationale**:
- Maintains the project's zero-build-step, single-file-output model.
- The presenter generates a standalone HTML file that opens in any browser with internet access.
- If offline use becomes a requirement later, we can vendor the minified bundles into the repository.

### 4. Graph view as default for dependencies

**Decision**: When the `dependencies` dimension loads, default to Graph view instead of Map view.

**Rationale**:
- Graph view is the intended future-primary exploration surface for dependencies.
- Map view remains available for users who prefer the compact fixed-canvas layout.
- Tree view retains its role for hierarchical browsing.

## Risks / Trade-offs

| Risk | Mitigation |
|------|------------|
| **CDN unavailable** → Graph view fails to render | Keep Map/Tree as fallbacks. Future iteration can vendor the JS bundles. |
| **Large JS payload** (~350KB minified) → slow initial load on slow networks | CDN scripts load asynchronously; Map/Tree render immediately if Graph JS is slow. |
| **Canvas rendering limits custom SVG** → cannot easily add bespoke visual marks | Cytoscape's style system is expressive (node shapes, gradients, labels, pies). For truly custom marks, we can fall back to Map view. |
| **Compound node complexity** → Dagre's compound graph support is less mature than simple DAG | Keep SCC sizes small in practice (codebase SCCs are typically 2-5 files). Test with real data early. |
| **Touch/mobile interaction** → Canvas zoom/pan gestures may conflict with page scroll | Cytoscape supports pinch-to-zoom and touch pan; configure `userZoomingEnabled` and `userPanningEnabled` thoughtfully. |

## Migration Plan

1. Implement `_build_graph_data` in `presenter.py`.
2. Extend HTML template with Cytoscape CDN scripts and `renderGraph()` function.
3. Update view toggle to include Graph option and set it as default for dependencies.
4. Validate with real project data; check compound node rendering and edge clarity.
5. No rollback needed — Map and Tree are untouched.

## Open Questions

- Should we add a "Reset View" button (fit + center) to the Graph view UI?
- Should hover tooltip show the same information as Map view (outgoing/incoming counts), or richer data?
