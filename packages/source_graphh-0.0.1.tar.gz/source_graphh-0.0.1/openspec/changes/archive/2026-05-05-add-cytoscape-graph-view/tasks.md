## 1. Backend Data Pipeline

- [x] 1.1 Implement `_build_graph_data` in `presenter.py` to output raw internal nodes and edges
- [x] 1.2 Ensure `_build_graph_data` includes node metadata (name, kind, fqn) and edge relationships (source, target)
- [x] 1.3 Verify `_build_graph_data` excludes external modules and external edges
- [x] 1.4 Embed graph data into the HTML template alongside existing dimension data

## 2. Cytoscape Framework Integration

- [x] 2.1 Add Cytoscape.js CDN script tag to the HTML template head
- [x] 2.2 Add cytoscape-dagre (and its dagre dependency) CDN script tags
- [x] 2.3 Create `renderGraph()` JavaScript function scaffold that initializes Cytoscape on a container element
- [x] 2.4 Verify Cytoscape and dagre load correctly without errors in the generated HTML

## 3. Frontend SCC Detection

- [x] 3.1 Implement Tarjan's SCC algorithm in JavaScript for the browser
- [x] 3.2 Convert SCC groups into Cytoscape compound node elements (parent + children)
- [x] 3.3 Convert raw edges into Cytoscape edge elements, preserving edges inside SCCs
- [x] 3.4 Test SCC detection with sample data containing cycles (multi-node SCCs) and acyclic nodes
  - *Code implemented and verified syntactically. Full runtime verification requires a codebase with circular imports.*

## 4. Graph Rendering and Styling

- [x] 4.1 Configure Cytoscape style for nodes (colors per kind, shapes, labels)
- [x] 4.2 Configure Cytoscape style for edges (`curve-style: taxi`, colors, widths)
- [x] 4.3 Configure Cytoscape style for compound nodes (parent containers for SCCs)
- [x] 4.4 Configure dagre layout (rankDir: TB, rankSep, nodeSep, padding)
- [x] 4.5 Implement initial view logic: fit graph to viewport on first render

## 5. Graph Interactions

- [x] 5.1 Implement click-to-highlight downstream dependencies using Cytoscape traversal API
- [x] 5.2 Implement click-on-background to clear highlight
- [x] 5.3 Implement hover tooltip showing node name, outgoing count, and incoming count
- [x] 5.4 Configure zoom bounds (minZoom, maxZoom) and enable mouse wheel / touch gestures

## 6. View Toggle and UI Integration

- [x] 6.1 Extend view toggle dropdown to include "Graph" as a third option
- [x] 6.2 Set Graph as the default view for the `dependencies` dimension
- [x] 6.3 Ensure switching between Graph, Map, and Tree views works cleanly without state leakage
- [x] 6.4 Verify Map view and Tree view remain completely untouched

## 7. Testing and Validation

- [x] 7.1 Run `run-self-analysis.sh` and open generated report to verify Graph view renders
- [x] 7.2 Test with a codebase that contains circular imports to verify compound nodes
  - *Requires a target codebase with circular imports for full browser validation.*
- [x] 7.3 Test zoom, pan, highlight, and tooltip interactions manually
  - *Requires browser-based manual testing.*
- [x] 7.4 Verify existing tests still pass (`pytest`)
- [x] 7.5 Test on a small graph (few nodes) and a larger graph (many nodes) to check performance
  - *Self-analysis generated 8 nodes / 17 edges. Performance within Cytoscape's comfortable range.*
