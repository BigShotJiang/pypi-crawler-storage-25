## ADDED Requirements

### Requirement: Nodes are stored in SQLite
The system SHALL persist all nodes added via `RelationStore.add_nodes()` into a SQLite `nodes` table.

#### Scenario: Adding a node
- **WHEN** a node with id "n1" is added to the store
- **THEN** the node is retrievable via `get_nodes` with matching filters
- **AND** the node exists in the SQLite `nodes` table

### Requirement: Relations are stored in SQLite
The system SHALL persist all relations added via `RelationStore.add_relations()` into a SQLite `relations` table.

#### Scenario: Adding a relation
- **WHEN** a relation with id "r1" is added to the store
- **THEN** the relation is retrievable via `get_relations` with matching filters
- **AND** the relation exists in the SQLite `relations` table

### Requirement: Node properties are JSON-serialized
The system SHALL serialize `Node.properties` dictionaries to JSON text before storing in SQLite, and deserialize them back to dictionaries on retrieval.

#### Scenario: Round-trip properties
- **WHEN** a node with properties `{"async": true}` is added
- **THEN** the node retrieved from the store has properties equal to `{"async": true}`

### Requirement: Relation properties are JSON-serialized
The system SHALL serialize `Relation.properties` dictionaries to JSON text before storing in SQLite, and deserialize them back to dictionaries on retrieval.

#### Scenario: Round-trip relation properties
- **WHEN** a relation with properties `{"confidence": 0.9}` is added
- **THEN** the relation retrieved from the store has properties equal to `{"confidence": 0.9}`

### Requirement: Filtering nodes by kind
The system SHALL support filtering nodes by `kind` via `NodeFilter`.

#### Scenario: Filter by kind
- **WHEN** nodes of kinds "function" and "class" exist in the store
- **AND** `get_nodes(NodeFilter(kind="function"))` is called
- **THEN** only nodes with kind "function" are returned

### Requirement: Filtering nodes by source file
The system SHALL support filtering nodes by `source_file` via `NodeFilter`.

#### Scenario: Filter by source file
- **WHEN** nodes from "a.py" and "b.py" exist in the store
- **AND** `get_nodes(NodeFilter(source_file="a.py"))` is called
- **THEN** only nodes from "a.py" are returned

### Requirement: Filtering relations by dimension
The system SHALL support filtering relations by `dimension` via `RelationFilter`.

#### Scenario: Filter by dimension
- **WHEN** relations with dimensions "structure" and "reference" exist in the store
- **AND** `get_relations(RelationFilter(dimension="structure"))` is called
- **THEN** only relations with dimension "structure" are returned

### Requirement: Store supports file-backed and in-memory modes
The system SHALL allow `RelationStore` to operate against either a file-backed SQLite database or an in-memory (`:memory:`) database.

#### Scenario: In-memory store
- **WHEN** `RelationStore()` is constructed with no path
- **THEN** data is stored in memory and not written to disk

#### Scenario: File-backed store
- **WHEN** `RelationStore("/path/to/db")` is constructed
- **THEN** data is persisted to the specified SQLite file

### Requirement: Save and load preserve SQLite state
The system SHALL support `save(path)` to copy the current database to a new file, and `load(path)` to replace the current database with one from a file.

#### Scenario: Save and reload
- **WHEN** nodes and relations are added to a store
- **AND** `save("backup.db")` is called
- **AND** a new store calls `load("backup.db")`
- **THEN** the new store contains the same nodes and relations
