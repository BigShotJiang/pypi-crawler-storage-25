## ADDED Requirements

### Requirement: CLI accepts an output directory
The system SHALL accept `--output` as a directory path and create it if it does not exist.

#### Scenario: Directory does not exist
- **WHEN** the user runs the CLI with `--output ./reports`
- **AND** the directory `./reports` does not exist
- **THEN** the directory is created

#### Scenario: Directory already exists
- **WHEN** the user runs the CLI with `--output ./reports`
- **AND** the directory `./reports` exists
- **THEN** the command succeeds and writes files into the existing directory

### Requirement: CLI generates SQLite database in output directory
The system SHALL write `source_graph.db` into the output directory, containing all extracted nodes and relations.

#### Scenario: Single file extraction
- **WHEN** the CLI analyzes one Python file
- **THEN** `source_graph.db` is created in the output directory
- **AND** the database contains nodes and relations from the analyzed file

#### Scenario: Multiple file extraction
- **WHEN** the CLI analyzes multiple Python files
- **THEN** `source_graph.db` contains merged nodes and relations from all files

### Requirement: CLI generates HTML report in output directory
The system SHALL write `report.html` into the output directory, visualizing the data from the SQLite database.

#### Scenario: HTML report generation
- **WHEN** the CLI completes extraction
- **THEN** `report.html` is created in the output directory
- **AND** the HTML renders the extracted structure correctly

### Requirement: CLI removes JSON export option
The system SHALL no longer accept a `--json` argument.

#### Scenario: JSON option rejected
- **WHEN** the user provides `--json data.json`
- **THEN** the CLI reports an unrecognized argument error
