## 1. Refactor RelationStore to SQLite Backend

- [x] 1.1 Modify `RelationStore.__init__` to accept optional `db_path` and initialize SQLite connection (file or `:memory:`)
- [x] 1.2 Implement SQLite schema creation (`nodes` and `relations` tables with indexes)
- [x] 1.3 Rewrite `add_nodes` to insert/replace into SQLite `nodes` table
- [x] 1.4 Rewrite `get_nodes` to query SQLite with `NodeFilter` conditions
- [x] 1.5 Rewrite `add_relations` to insert/replace into SQLite `relations` table
- [x] 1.6 Rewrite `get_relations` to query SQLite with `RelationFilter` conditions
- [x] 1.7 Rewrite `get_dimensions` to query distinct `dimension` values from SQLite
- [x] 1.8 Implement JSON serialization/deserialization for `properties` fields in both nodes and relations
- [x] 1.9 Rewrite `save` to copy current SQLite database to the given path
- [x] 1.10 Rewrite `load` to replace current connection with database from the given path

## 2. Adapt CLI for Directory Output

- [x] 2.1 Change `--output` argument to accept a directory path instead of a file path
- [x] 2.2 Add output directory creation logic (`mkdir -p` equivalent)
- [x] 2.3 Remove `--json` argument and all related logic
- [x] 2.4 Update `RelationStore` instantiation to use file-backed SQLite at `<output_dir>/source_graph.db`
- [x] 2.5 Update HTML report output path to `<output_dir>/report.html`
- [x] 2.6 Update CLI help text and error messages

## 3. Update Tests

- [x] 3.1 Rewrite `test_store.py` to test SQLite-backed `RelationStore` (use `:memory:` for isolation)
- [x] 3.2 Remove JSON save/load tests from `test_store.py`
- [x] 3.3 Verify `test_presenter.py` still passes with minimal or no changes
- [x] 3.4 Verify `test_python_structure_extractor.py` still passes
- [x] 3.5 Run full test suite and fix any regressions
