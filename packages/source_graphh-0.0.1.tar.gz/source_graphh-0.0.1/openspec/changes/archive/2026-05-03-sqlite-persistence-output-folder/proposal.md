## Why

The current source-graph CLI stores extracted nodes and relations only in memory with optional JSON persistence. This limits the tool's utility for incremental analysis, large codebases, and downstream querying. Moving to SQLite as the mandatory persistence layer provides a structured, queryable store while simplifying the output model.

## What Changes

- **BREAKING**: CLI `--output` changes from a single HTML file path to an output directory path. The tool will generate `source_graph.db` (SQLite) and `report.html` inside this directory.
- **BREAKING**: Remove `--json` CLI option. JSON persistence is replaced by mandatory SQLite persistence.
- Rewrite `RelationStore` to use SQLite as its backing store instead of in-memory dictionaries. Public interface (`add_nodes`, `get_nodes`, `add_relations`, `get_relations`, `get_dimensions`, `save`, `load`) remains unchanged.
- Store `Node` and `Relation` `properties` dicts as JSON-serialized TEXT in SQLite.
- `HTMLPresenter.render()` continues to accept `RelationStore`; it transparently reads from SQLite via the store interface.
- Update tests to use SQLite-backed `RelationStore` and remove JSON save/load tests.

## Capabilities

### New Capabilities
- `sqlite-storage`: SQLite-backed persistence for nodes and relations with full CRUD and filtering support.

### Modified Capabilities
- `cli-output`: Output behavior changes from single-file to directory-based output. Remove JSON export option.

## Impact

- `src/source_graph/cli.py`: Argument parsing, output directory handling, file generation paths.
- `src/source_graph/store.py`: Complete rewrite of internal storage from `dict` to SQLite.
- `tests/test_store.py`: Remove JSON tests, adapt to SQLite semantics.
- `tests/test_presenter.py`: Likely minimal changes since `RelationStore` interface is preserved.
