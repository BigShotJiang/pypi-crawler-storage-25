## Context

`RelationStore` currently holds nodes and relations in two Python dictionaries (`_nodes`, `_relations`). The CLI optionally serializes this state to JSON via `--json`. This design is simple but offers no queryability, no incremental updates, and requires full memory residency.

The project is a Python CLI tool with no server component. SQLite is available in the standard library and fits the single-user, local-file execution model perfectly.

## Goals / Non-Goals

**Goals:**
- Replace in-memory `RelationStore` with SQLite-backed implementation while preserving the public interface.
- Make SQLite persistence mandatory (no optional JSON).
- Change CLI output from a single HTML file to an output directory containing both `source_graph.db` and `report.html`.
- Store `properties` dicts as JSON-serialized TEXT in SQLite.
- Ensure all existing tests pass after adaptation.

**Non-Goals:**
- Changing `Extractor` or `Presenter` public interfaces.
- Adding new query capabilities beyond existing filters.
- Browser-side SQLite access (WASM, sql.js, etc.).
- Multi-process concurrency or WAL mode tuning.
- Database migration framework (we accept breaking the DB schema on version changes for now).

## Decisions

### SQLite Schema

Two tables:

```sql
CREATE TABLE IF NOT EXISTS nodes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    kind TEXT NOT NULL,
    fqn TEXT NOT NULL,
    source_file TEXT NOT NULL,
    start_line INTEGER,
    start_col INTEGER,
    end_line INTEGER,
    end_col INTEGER,
    parent_id TEXT,
    properties TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS relations (
    id TEXT PRIMARY KEY,
    source_id TEXT NOT NULL,
    target_id TEXT NOT NULL,
    type TEXT NOT NULL,
    dimension TEXT NOT NULL,
    properties TEXT NOT NULL DEFAULT '{}'
);
```

**Rationale**: Flat tables map directly to `Node` and `Relation` dataclasses. No foreign key constraints are enforced to keep inserts order-independent (extractors may add relations before all nodes are loaded).

### Properties Serialization

`properties` fields are stored as `TEXT` with `json.dumps` on write and `json.loads` on read.

**Rationale**: SQLite lacks a native map/dict type. JSON is human-readable, standard-library only, and sufficient for small metadata blobs. Alternatives considered: `pickle` (opaque, unsafe), separate `properties` table (overkill for key-value metadata).

### `RelationStore` Constructor Change

The constructor will accept an optional `db_path: str`. When provided, it opens (or creates) that SQLite file. When omitted, it uses an in-memory SQLite database (`:memory:`).

**Rationale**: This preserves testability (tests can use `:memory:`) while allowing the CLI to pass a real file path. The public `add_nodes`, `get_nodes`, `add_relations`, `get_relations`, `get_dimensions`, `save`, and `load` signatures remain unchanged.

### CLI Output Directory

`--output` becomes a directory path. The CLI creates the directory if missing and writes:
- `<output_dir>/source_graph.db`
- `<output_dir>/report.html`

**Rationale**: Groups artifacts together. Users can specify a single argument instead of separate `--output` and `--json` paths.

### `save` and `load` Behavior

`save(path)` will copy the current in-memory/open SQLite database to the given path (using SQLite backup API or file copy). `load(path)` will attach to the given SQLite file, replacing any current connection.

**Rationale**: Keeps the `save`/`load` contract intact for tests and potential future use, while underlying storage is now always SQLite.

## Risks / Trade-offs

| Risk | Mitigation |
|------|------------|
| Slower than dict for small datasets | Acceptable; SQLite is fast enough for CLI-scale data. Benchmark if concerned. |
| `properties` JSON round-trip changes types (e.g., tuple→list) | Documented non-goal; Python `json` behavior is well-understood. |
| Tests using `RelationStore()` now need SQLite setup | Constructor defaults to `:memory:`, so no file I/O required in tests. |
| Breaking change for CLI users using `--json` | Document in release notes; `--json` is removed entirely. |

## Migration Plan

Not applicable for a CLI tool with no persistent server state. Users previously using `--json` will need to regenerate their stores via the new `--output` directory workflow.

## Open Questions

- Should `save`/`load` be deprecated in favor of always using file-backed SQLite? (Deferred; keep for now to minimize interface changes.)
