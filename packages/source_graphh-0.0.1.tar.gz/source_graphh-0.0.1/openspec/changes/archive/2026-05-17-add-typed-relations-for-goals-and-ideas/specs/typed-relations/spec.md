## ADDED Requirements

### Requirement: Namespace-qualified target identifiers
A relation target SHALL be expressed as `<namespace>:<identifier>`. The `goal` namespace SHALL refer to `goals/<identifier>/goal.md`. The `idea` namespace SHALL refer to `ideas/<identifier>.md`.

#### Scenario: Goal target resolution
- **WHEN** a relation contains `target: goal:code-intuition`
- **THEN** it resolves to `ideas/goals/code-intuition/goal.md`

#### Scenario: Idea target resolution
- **WHEN** a relation contains `target: idea:incremental-extract`
- **THEN** it resolves to `ideas/2026-05-11--incremental-extract.md`

#### Scenario: Bare string fallback
- **WHEN** a target contains no namespace prefix
- **THEN** the parser SHALL infer the namespace from the identifier format
- **AND** identifiers matching `YYYY-MM-DD--*` pattern SHALL be treated as `idea:`
- **AND** all other bare strings SHALL be treated as `goal:`

### Requirement: Typed relation schema
Each relation object in the `relations` array SHALL contain exactly three fields: `target` (string), `relation` (enum), and `rationale` (string). The `rationale` field SHALL NOT be empty.

#### Scenario: Valid relation object
- **WHEN** a relation is defined as `{target: goal:code-intuition, relation: serves, rationale: "G-A-S serves code-intuition as its primary target"}`
- **THEN** it is valid

#### Scenario: Missing rationale
- **WHEN** a relation omits the `rationale` field or provides an empty string
- **THEN** it is invalid

### Requirement: Relation type semantics
The system SHALL support exactly three relation types: `serves`, `depends_on`, and `refines`. The `serves` type SHALL indicate that the source entity exists to support the target goal. The `depends_on` type SHALL indicate that the source cannot progress without the target. The `refines` type SHALL indicate that the source is an evolved or narrower-scope version of the target.

#### Scenario: Serve relation
- **WHEN** an idea has `relation: serves` with a `goal:*` target
- **THEN** it expresses service to that goal

#### Scenario: Depends-on relation
- **WHEN** an idea has `relation: depends_on` with any target
- **THEN** it expresses a prerequisite dependency

#### Scenario: Refines relation
- **WHEN** an idea has `relation: refines` with any target
- **THEN** it expresses an evolutionary refinement

### Requirement: Frontmatter schema for goals and ideas
Goal files and idea files SHALL contain a YAML frontmatter block with exactly two fields: `date` (string in `YYYY-MM-DD` format) and `relations` (array of relation objects). No other fields SHALL appear in the frontmatter.

#### Scenario: Minimal valid goal frontmatter
- **WHEN** a goal file frontmatter contains only `date` and `relations`
- **THEN** it is valid

#### Scenario: Idea with no relations
- **WHEN** an idea file frontmatter contains only `date` and `relations: []`
- **THEN** it is valid

#### Scenario: Frontmatter with extra fields
- **WHEN** a frontmatter contains fields other than `date` and `relations`
- **THEN** it is invalid
