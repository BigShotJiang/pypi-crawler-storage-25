## MODIFIED Requirements

### Requirement: Goal file frontmatter
The `goal.md` file SHALL contain a YAML frontmatter block with the fields `date` and `relations`. The `date` field SHALL use the `YYYY-MM-DD` format. The `relations` field SHALL be an array of typed relation objects, each containing `target` (namespace-qualified string), `relation` (enum: `serves`, `depends_on`, `refines`), and `rationale` (non-empty string). The `created_at` and `updated_at` fields SHALL NOT appear in frontmatter.

#### Scenario: Goal file with valid typed relations
- **WHEN** a goal file is created
- **THEN** its frontmatter contains `date` and `relations`
- **AND** `relations` is an array of objects with `target`, `relation`, and `rationale`
- **AND** `date` matches `YYYY-MM-DD`

#### Scenario: Goal with no related goals
- **WHEN** a goal has no relationship to other goals
- **THEN** `relations` SHALL be an empty array `[]`

#### Scenario: Goal with extra frontmatter fields
- **WHEN** a goal file frontmatter contains `created_at`, `updated_at`, or `related_goals`
- **THEN** it is invalid

## REMOVED Requirements

### Requirement: Idea-to-goal binding
**Reason:** The `serves_goal` field is superseded by the unified `relations` field with `relation: serves` and namespace-qualified targets. A single mechanism replaces two overlapping mechanisms.

**Migration:** Ideas previously using `serves_goal: <name>` SHALL migrate to `relations: [{target: goal:<name>, relation: serves, rationale: "..."}]`.

#### Scenario: Legacy serves_goal field
- **WHEN** an idea file contains `serves_goal` in frontmatter
- **THEN** it is invalid
- **AND** the binding SHALL be expressed via `relations` instead
