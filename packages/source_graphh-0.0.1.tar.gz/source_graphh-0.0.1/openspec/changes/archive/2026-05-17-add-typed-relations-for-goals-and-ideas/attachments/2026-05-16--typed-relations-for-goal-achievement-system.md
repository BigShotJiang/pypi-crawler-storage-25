---
date: "2026-05-16"
relations:
  - target: goal:goal-achievement-system
    relation: serves
    rationale: "Typed relations are the foundation for meaningful goal-idea relationship graphs and downstream tooling."
---

# Idea: Typed Relations for Goal Achievement System

**Date:** 2026-05-16
**Status:** New
**Context:** During a discussion about the bidirectional `related_goals` link between `code-intuition` and `goal-achievement-system`, it became clear that an untyped list cannot distinguish "depends_on" from "serves" — collapsing meaningful feedback loops into zero-information undirected edges.
## Description

The current `related_goals` field in goal frontmatter is an **untyped list of strings**:

```yaml
related_goals:
  - code-intuition
```

This format can only express "there is some relationship." It cannot answer:
- Does goal A *depend on* goal B?
- Does goal A *serve* goal B?
- Do they *conflict*?

When bidirectional links exist (e.g., `code-intuition` ↔ `goal-achievement-system`), the untyped list collapses two directed edges into a single undirected edge, destroying the semantic information that makes the graph meaningful.

This idea proposes evolving `related_goals` from a simple string list into **typed relation objects**:

```yaml
related_goals:
  - name: code-intuition
    relation: depends_on
    rationale: >-
      goal-achievement-system needs a concrete service target to avoid
      the self-referential trap; code-intuition is its first consumer.
  - name: some-future-goal
    relation: enables
    rationale: >-
      By providing structured goal metadata, the system makes downstream
      tooling (dashboards, graph renderers) possible.
```

### Proposed Relation Types

| Type | Meaning | Example |
|------|---------|---------|
| `depends_on` | This goal cannot progress without the other | G-A-S depends on code-intuition |
| `serves` | This goal exists to support the other | G-A-S serves code-intuition |
| `refines` | This goal is a narrower scope of the other | "symbol-level analysis" refines "code-intuition" |
| `enables` | Achieving this goal makes the other achievable | structured frontmatter enables typed relations |
| `inspired_by` | Origin or intellectual debt | code-intuition inspired by SourceTrail |
| `conflicts_with` | Pursuing one may undermine the other | "speed" vs "exhaustive correctness" |

### Example / Use case

**Before (untyped):**
```yaml
# goals/goal-achievement-system/goal.md
related_goals:
  - code-intuition
# goals/code-intuition/goal.md
related_goals:
  - goal-achievement-system
```
A reader sees a mutual link and cannot tell whether this is:
- A dependency cycle (bad)
- A service relationship (good)
- A coincidence (neutral)

**After (typed):**
```yaml
# goals/goal-achievement-system/goal.md
related_goals:
  - name: code-intuition
    relation: serves
    rationale: "G-A-S's first and current service target is code-intuition."
# goals/code-intuition/goal.md
related_goals:
  - name: goal-achievement-system
    relation: depends_on
    rationale: "Code-intuition depends on G-A-S for process management."
```
Now the mutual link is revealed as a **feedback loop**: a service target (serves) and its consumer (depends_on). This is meaningful architectural information, not ambiguity.

## Motivation

1. **Preserves semantic information in bidirectional links**: Untyped bidirectional = undirected edge = zero information. Typed bidirectional = two directed edges = meaningful feedback loop.
2. **Enables graph-based reasoning**: Any dashboard, graph renderer, or automated analysis that consumes goal files needs typed edges to produce useful visualizations or insights.
3. **Prevents false symmetry**: "A depends on B" and "B serves A" are not the same statement. The current list format forces them to look identical.
4. **Foundation for dependency analysis**: If goals form a directed graph with typed edges, we can compute reachability, identify cycles, and detect orphaned goals automatically.

## Potential Implementation

### Phase 1: Schema extension

Update the goal file schema to accept either the legacy list (backward compatible) or the new typed list:

```yaml
related_goals:
  - name: code-intuition
    relation: depends_on
    rationale: "..."
```

### Phase 2: Migrate existing goal files

Convert `ideas/goals/goal-achievement-system/goal.md` and `ideas/goals/code-intuition/goal.md` to typed relations as the reference implementation.

### Phase 3: Tooling unlock

- `scripts/generate-goal-graph.py` renders directed edges with labels
- `scripts/goal-health-check.py` detects cycles, orphans, and relation imbalances
- Dashboard shows "goals that serve N others but depend on 0" (hubs) vs "goals that depend on N others but serve 0" (sinks)

## Related Areas

- `ideas/goals/goal-achievement-system/goal.md` — current consumer of `related_goals`
- `ideas/goals/code-intuition/goal.md` — current other endpoint of the bidirectional link
- `ideas/2026-05-15--idea-structured-frontmatter.md` — provides the YAML frontmatter foundation this idea builds upon
- `ideas/2026-05-15--pre-idea-goal-alignment.md` — the `aligned/divergent/enriching` taxonomy could be extended with the same typed-relation pattern
- `ideas/2026-05-11--bidirectional-idea-change-linking.md` — related bidirectional linking concept in the OpenSpec domain

## Notes

- **Direction C depends on Direction A**: Accepting bidirectional links as a graph (Direction C) only makes sense if the edges are typed (Direction A). Untyped bidirectional links are indistinguishable from undirected edges.
- **Backward compatibility**: The new schema should accept both `related_goals: [name]` and `related_goals: [{name, relation, rationale}]` during a transition period.
- **Open question**: Should `rationale` be required? A relation without rationale is still better than no relation, but a rationale prevents drift in meaning over time.
- **Open question**: Should this typing scheme be extended to `related_ideas` in idea files as well, creating a unified relation model across both goals and ideas?
