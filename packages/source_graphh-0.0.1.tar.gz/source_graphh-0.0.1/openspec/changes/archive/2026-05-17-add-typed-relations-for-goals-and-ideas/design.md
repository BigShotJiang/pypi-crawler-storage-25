## Context

Current goal files use `related_goals: [name]` (untyped string list). Idea files use inline `**Serves:**` markdown links. Neither format is machine-parseable for relationship types. The `typed-relations` idea (2026-05-16) identified that bidirectional links collapse into zero-information undirected edges without type annotations.

After exploration, the scope was expanded beyond goals to include ideas, with a unified `relations` field replacing both `related_goals` and `related_ideas`. The schema was deliberately minimized to only `date` and `relations` — `status`, `context`, `tags`, and `serves_goal` remain in document body.

## Goals / Non-Goals

**Goals:**
- Define a typed relation model with namespace-qualified targets
- Migrate all 2 goals and 29 active ideas to the new frontmatter schema
- Establish `rationale` as a required field for every relation
- Enable downstream tooling (graph extraction, dependency analysis) to consume typed edges

**Non-Goals:**
- No automated migration script — Agent modifies files directly
- No backward compatibility with old `related_goals` string-list format
- No new tooling built in this change (dashboard, graph renderer, etc.)
- No changes to idea body content or structure

## Decisions

**1. Unified `relations` field instead of `related_goals` / `related_ideas` separate fields**
- *Rationale:* A single field with namespace-qualified targets (`goal:code-intuition`, `idea:incremental-extract`) scales to future entity types without schema changes.
- *Alternative considered:* Separate fields per entity type (`related_goals`, `related_ideas`). Rejected because adding a new entity type (e.g., `plan`) would require a new field.

**2. Namespace-qualified targets (`goal:<name>`, `idea:<stem>`)**
- *Rationale:* Target identifier carries type information, eliminating need for `target_type` field.
- *Alternative considered:* `target_type` field. Rejected as redundant.

**3. `rationale` is required**
- *Rationale:* Prevents semantic drift over time. A relation without rationale decays into unexplained linkage.
- *Alternative considered:* Optional rationale. Rejected because the long-term value outweighs the short-term migration cost.

**4. Three relation types: `serves`, `depends_on`, `refines`**
- *Rationale:* Sufficient for current needs without over-design. `serves` for goal-service relationships, `depends_on` for prerequisites, `refines` for evolutionary upgrades.
- *Alternative considered:* More types (`enables`, `inspired_by`, `conflicts_with`). Rejected as speculative.

**5. No backward compatibility**
- *Rationale:* Only 31 files total. One-time migration is simpler than maintaining dual parsers.
- *Alternative considered:* Accept both string list and object list during transition. Rejected as unnecessary debt.

## Risks / Trade-offs

- **[Risk]** `rationale` required → increases migration friction for ideas with many links → *Mitigation:* Most ideas have 0–2 explicit relations; friction is bounded.
- **[Risk]** Old tooling that parses `related_goals` breaks → *Mitigation:* This is a known breaking change documented in proposal. No such tooling exists in the codebase yet.
- **[Trade-off]** Minimal schema (only `date` + `relations`) vs. rich metadata → *Accepted:* `status`, `context`, `tags` provide no machine-parseable value for graph extraction.

## Migration Plan

1. Update 2 goal files: replace `related_goals` with `relations`, migrate `created_at`/`updated_at` to body
2. Update 3 ideas with existing frontmatter: clean up extra fields, add `relations`
3. Update 26 ideas without frontmatter: add `date` + `relations` (or just `date` if no known relations)
4. Verify all 31 files parse correctly with `yaml.safe_load`

## Open Questions

- Should `serves` be restricted to target only `goal:*` at the schema level, or is that a convention?
- Future: when a new entity type (e.g., `plan`) is introduced, does the namespace rule `plan:<id>` require any code changes, or is it purely a convention?
