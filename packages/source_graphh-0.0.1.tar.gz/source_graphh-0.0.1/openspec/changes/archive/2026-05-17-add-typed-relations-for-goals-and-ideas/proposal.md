## Why

Current goal and idea files use untyped string lists (`related_goals: [name]`) to express relationships. This format collapses bidirectional links into zero-information undirected edges — "A depends on B" and "B serves A" look identical. Without typed relations, automated graph extraction, dependency analysis, and goal-aligned dashboards cannot produce meaningful insights.

## What Changes

- **BREAKING**: Evolve goal and idea frontmatter schema from untyped `related_goals` / `related_ideas` string lists to typed `relations` objects with `target`, `relation`, and `rationale` fields.
- Introduce namespaced target identifiers (`goal:<name>`, `idea:<stem>`) for unambiguous cross-references.
- Define three relation types: `serves`, `depends_on`, `refines`.
- Require `rationale` for every relation to prevent semantic drift.
- Migrate all 2 goals and 29 active ideas to the new schema.
- Remove `status`, `context`, `tags`, `serves_goal`, `created_at`, `updated_at` from frontmatter — these remain in document body.

## Capabilities

### New Capabilities
- `typed-relations`: Typed relation model for goals and ideas. Defines namespace rules, relation types, schema format, and rationale requirements.

### Modified Capabilities
- `goal-management`: Goal file schema changes — `related_goals` field replaced by `relations`. Existing goal frontmatter structure changes.

## Impact

- All files in `ideas/goals/*/goal.md` and `ideas/*.md` frontmatter structures change.
- Any tooling that parses goal/idea frontmatter must update to consume `relations` instead of `related_goals` / `related_ideas`.
- No source code changes — this is a metadata/schema change only.
