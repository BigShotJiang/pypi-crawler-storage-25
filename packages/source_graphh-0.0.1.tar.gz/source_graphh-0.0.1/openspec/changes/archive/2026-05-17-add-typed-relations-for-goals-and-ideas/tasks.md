## 1. Update Goal Files

- [x] 1.1 Update `ideas/goals/goal-achievement-system/goal.md` frontmatter: replace `related_goals` with `relations`, add `serves code-intuition` relation with rationale, migrate `created_at`/`updated_at` to body
- [x] 1.2 Update `ideas/goals/code-intuition/goal.md` frontmatter: replace `related_goals` with `relations`, migrate `created_at`/`updated_at` to body

## 2. Update Ideas with Existing Frontmatter

- [x] 2.1 Update `ideas/2026-05-16--pypi-release-and-version-management.md`: replace frontmatter with `date` + `relations: []`, migrate `created_at`/`updated_at` to body
- [x] 2.2 Update `ideas/2026-05-16--source-graph-as-universal-relation-extractor.md`: add `serves code-intuition` relation with rationale
- [x] 2.3 Update `ideas/2026-05-16--typed-relations-for-goal-achievement-system.md`: replace frontmatter with `date` + `relations` (serves G-A-S), migrate `serves_goal`/`status` to body

## 3. Update Ideas without Frontmatter (with Known Relations)

- [x] 3.1 Add frontmatter to `ideas/2026-05-03--record-idea-skill.md`: `date` + `serves goal:goal-achievement-system`
- [x] 3.2 Add frontmatter to `ideas/2026-05-11--auto-generated-ideas-reference-graph.md`: `date` + `serves goal:goal-achievement-system`
- [x] 3.3 Add frontmatter to `ideas/2026-05-11--auto-generated-ideas-status-dashboard.md`: `date` + `serves goal:goal-achievement-system`
- [x] 3.4 Add frontmatter to `ideas/2026-05-11--bidirectional-idea-change-linking.md`: `date` + `serves goal:goal-achievement-system`
- [x] 3.5 Add frontmatter to `ideas/2026-05-11--record-idea-template-variants.md`: `date` + `serves goal:goal-achievement-system`
- [x] 3.6 Add frontmatter to `ideas/2026-05-12--record-idea-v2-lifecycle-management.md`: `date` + `serves goal:goal-achievement-system`
- [x] 3.7 Add frontmatter to `ideas/2026-05-11--presenter-template-separation.md`: `date` + `serves goal:code-intuition`
- [x] 3.8 Add frontmatter to `ideas/2026-05-11--incremental-extract.md`: `date` + `serves goal:code-intuition`
- [x] 3.9 Add frontmatter to `ideas/2026-05-09--persistent-symbol-table-and-source-archive.md`: `date` + `serves goal:code-intuition`
- [x] 3.10 Add frontmatter to `ideas/2026-05-11--code-knowledge-graph-api.md`: `date` + `serves goal:code-intuition`
- [x] 3.11 Add frontmatter to `ideas/2026-05-11--full-text-code-search-over-knowledge-graph.md`: `date` + `serves goal:code-intuition`
- [x] 3.12 Add frontmatter to `ideas/2026-05-11--polyglot-extractor-support.md`: `date` + `serves goal:code-intuition`
- [x] 3.13 Add frontmatter to `ideas/2026-05-05--radical-visualization-paradigms-beyond-node-link.md`: `date` + `serves goal:code-intuition`
- [x] 3.14 Add frontmatter to `ideas/2026-05-03--explore-alternatives-to-pure-html-graph-rendering.md`: `date` + `depends_on idea:code-knowledge-graph-api` + rationale
- [x] 3.15 Add frontmatter to `ideas/2026-05-12--record-idea-v2-lifecycle-management.md`: `date` + `refines idea:record-idea-skill` + rationale
- [x] 3.16 Add frontmatter to `ideas/2026-05-15--goal-aware-record-idea-skill.md`: `date` + `refines idea:record-idea-skill` + rationale

## 4. Update Ideas without Frontmatter (No Known Relations)

- [x] 4.1 Add frontmatter to `ideas/2026-05-03--symbol-level-import-dependency-extraction.md`: `date` + `relations: []`
- [x] 4.2 Add frontmatter to `ideas/2026-05-05--file-directory-tree-view.md`: `date` + `relations: []`
- [x] 4.3 Add frontmatter to `ideas/2026-05-05--filter-external-modules-from-structure-dimension.md`: `date` + `relations: []`
- [x] 4.4 Add frontmatter to `ideas/2026-05-05--separate-relationship-production-from-rendering.md`: `date` + `relations: []`
- [x] 4.5 Add frontmatter to `ideas/2026-05-11--python-import-extractor-multiple-search-paths.md`: `date` + `relations: []`
- [x] 4.6 Add frontmatter to `ideas/2026-05-11--unified-report-rendering-validation.md`: `date` + `relations: []`
- [x] 4.7 Add frontmatter to `ideas/2026-05-12--goal-achievement-system-the-ultimate-form-of-idea-mechanism.md`: `date` + `relations: []`
- [x] 4.8 Add frontmatter to `ideas/2026-05-12--source-graph-architecture-evolution-roadmap.md`: `date` + `relations: []`
- [x] 4.9 Add frontmatter to `ideas/2026-05-15--idea-structured-frontmatter.md`: `date` + `relations: []`
- [x] 4.10 Add frontmatter to `ideas/2026-05-15--pre-idea-goal-alignment.md`: `date` + `relations: []`
- [x] 4.11 Add frontmatter to `ideas/2026-05-16--conversation-insight-extractor.md`: `date` + `relations: []`

## 5. Verification

- [x] 5.1 Verify all 31 files have valid YAML frontmatter
- [x] 5.2 Verify every `relations` entry has non-empty `target`, `relation`, and `rationale`
- [x] 5.3 Verify no frontmatter contains fields other than `date` and `relations`
