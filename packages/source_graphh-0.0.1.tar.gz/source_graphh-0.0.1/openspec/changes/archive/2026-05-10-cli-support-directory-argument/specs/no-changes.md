## No Spec Changes

This change is a pure implementation enhancement to the `extract` subcommand's file collection logic. No new capabilities are introduced, and no existing spec-level requirements are modified.

The behavior change (accepting directories in addition to files) is fully described in `proposal.md` and `design.md`.
