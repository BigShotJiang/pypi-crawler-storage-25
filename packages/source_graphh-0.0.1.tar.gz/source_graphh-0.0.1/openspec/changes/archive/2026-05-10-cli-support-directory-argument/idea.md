# Idea: CLI Support Directory Argument

**Date:** 2026-05-05
**Status:** New
**Context:** While designing the self-analysis test script (`ideas/2026-05-05--add-self-analysis-test-script.md`), we discussed using `src/*` to support future project expansion. However, the current CLI only accepts file paths — directories are skipped with a warning. This idea records the need to enhance the CLI to accept directory arguments and recursively collect `.py` files.

## Description

Extend the `source-graph` CLI so that when a directory is passed as a `files` argument, it recursively collects all `.py` files within that directory (similar to tools like `black`, `mypy`, or `pytest`).

Currently:
```bash
source-graph src/ -o build/output          # ❌ "No valid files to analyze"
source-graph src/source_graph/*.py -o ...  # ✅ works, but not future-proof
```

Desired:
```bash
source-graph src/ -o build/output          # ✅ recursively finds all .py files
```

## Example / Use case

**Self-analysis script** (future version):
```bash
python3 -m source_graph.cli \
    src/ \
    -o build/output \
    -d structure
```

This gracefully handles project growth — adding sub-packages under `src/source_graph/` or additional top-level packages under `src/` requires no script changes.

## Motivation

1. **Developer UX**: Most Python CLI tools accept directories. Users expect `source-graph src/` to "just work."
2. **Future-proofing**: Project structure may expand with sub-packages, plugins, or multiple source roots. Hardcoding `src/source_graph/*.py` in scripts becomes brittle.
3. **Consistency**: Aligns with standard Python tooling conventions (`black src/`, `mypy src/`, `ruff check src/`).
4. **Simpler integration**: Scripts and CI pipelines can pass a single directory instead of constructing file lists.

## Potential Implementation

Modify `src/source_graph/cli.py` in the file collection loop (around line 60-70):

```python
valid_paths = []
for file_path in args.files:
    path = Path(file_path)
    if path.is_dir():
        valid_paths.extend(str(p) for p in path.rglob("*.py"))
    elif path.is_file():
        valid_paths.append(str(path))
    else:
        logger.warning("File or directory not found: %s", file_path)
```

Considerations:
- Should there be an `--include` / `--exclude` pattern option (e.g., skip `venv/`, `__pycache__/`)?
- Should the recursive search follow symlinks? (`rglob` does not by default — probably correct for safety)
- Update CLI help text: `help="One or more Python source files or directories to analyze."`

## Related Areas

- `src/source_graph/cli.py` — the CLI entry point and argument parsing
- `ideas/2026-05-05--add-self-analysis-test-script.md` — the self-analysis script that would benefit from this enhancement

## Notes

- **Deferred decision**: The initial self-analysis script will use `src/source_graph/*.py` to keep scope minimal. This enhancement is recorded for a future iteration.
- **Open questions**:
  - Should directory traversal be opt-in via a flag (e.g., `--recursive`/`-r`) or the default behavior when a directory is passed?
  - How should hidden directories (`.git/`, `.tox/`) be handled? Implicit exclusion list, or explicit `--exclude`?
