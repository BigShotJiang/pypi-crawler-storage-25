## Context

The `extract` subcommand in `src/source_graph/cli.py` currently validates input paths with `_collect_valid_paths()`, which explicitly rejects directories with a "Not a file" warning. This forces callers to enumerate files manually (e.g., `src/source_graph/*.py`), which is brittle and inconsistent with standard Python tooling.

## Goals / Non-Goals

**Goals:**
- Allow directory arguments to `extract` to recursively discover `.py` files
- Support mixed input (files + directories) with deduplication
- Follow symbolic links during traversal
- Update help text and self-analysis script accordingly

**Non-Goals:**
- Adding `--include` / `--exclude` glob patterns
- Filtering out directories like `__pycache__` or `.venv` (only `.py` extension filtering)
- Changing the `present` subcommand behavior
- Multi-language file discovery (remains Python-only)

## Decisions

### Default recursive behavior
- **Decision**: Directory traversal is the default behavior when a directory is passed.
- **Rationale**: Matches conventions of `black`, `mypy`, `ruff`. Users expect `source-graph src/` to "just work."

### Follow symbolic links
- **Decision**: Use a custom recursive walker that follows symlinks.
- **Rationale**: Cost is minimal (~5 lines vs 1 line for `rglob`). Supports monorepo-style symlinked packages. Avoids silently skipping valid code.

### No directory blacklist
- **Decision**: Only filter by `.py` extension; do not exclude `__pycache__`, `.venv`, etc.
- **Rationale**: The tool is "open" — users control the input scope. If they pass a root directory containing a venv, that's their choice.

### Deduplication strategy
- **Decision**: Use a `set` of resolved absolute paths before returning the final list.
- **Rationale**: Simple, handles overlapping inputs (e.g., `src/` + `src/file.py`) deterministically.

## Risks / Trade-offs

| Risk | Mitigation |
|------|------------|
| Accidentally analyzing venv/site-packages if user passes project root | Documented as user responsibility; no implicit exclusion |
| Symlink cycles causing infinite recursion | `os.walk(followlinks=True)` handles cycles safely in modern Python |
| Existing tests assume file-only input | Add new tests without changing existing test assertions |
