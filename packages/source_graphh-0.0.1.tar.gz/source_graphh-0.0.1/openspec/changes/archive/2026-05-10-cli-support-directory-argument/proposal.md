## Why

The CLI's `extract` subcommand currently only accepts individual file paths. Passing a directory results in a "No valid files to analyze" error, which is inconsistent with standard Python tooling (`black`, `mypy`, `ruff`) and brittle for scripts that must enumerate files manually. We need the CLI to recursively discover `.py` files when given a directory argument.

## What Changes

- Modify `_collect_valid_paths()` in `src/source_graph/cli.py` to:
  - Recursively collect `*.py` files when a directory is passed as an argument
  - Follow symbolic links during directory traversal
  - Accept mixed inputs (directories + files) and deduplicate overlapping paths
  - Update help text for the `files` argument to indicate directory support
- Update `scripts/run-self-analysis.sh` to pass `src/` instead of `src/source_graph/*.py`
- Add unit tests for directory input, mixed input, and symlink handling

## Capabilities

### New Capabilities
<!-- No new capabilities introduced -->
- *None*

### Modified Capabilities
<!-- The extract subcommand behavior expands to accept directories, but the existing spec scenarios remain valid. No spec-level requirement changes. -->
- *None*

## Impact

- `src/source_graph/cli.py` — file collection logic
- `tests/test_cli.py` — new test coverage
- `scripts/run-self-analysis.sh` — simplified invocation
