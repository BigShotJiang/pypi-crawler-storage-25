## 1. Core Implementation

- [x] 1.1 Update `_collect_valid_paths()` in `cli.py` to recursively discover `*.py` files from directory arguments
- [x] 1.2 Add symlink following support to directory traversal
- [x] 1.3 Add deduplication for mixed file + directory inputs
- [x] 1.4 Update `files` argument help text to indicate directory support

## 2. Script Updates

- [x] 2.1 Update `scripts/run-self-analysis.sh` to pass `src/` instead of `src/source_graph/*.py`

## 3. Tests

- [x] 3.1 Add test for directory input (recursive `.py` discovery)
- [x] 3.2 Add test for mixed directory + file input with deduplication
- [x] 3.3 Add test for symlinked directory traversal
- [x] 3.4 Run full test suite and verify no regressions
