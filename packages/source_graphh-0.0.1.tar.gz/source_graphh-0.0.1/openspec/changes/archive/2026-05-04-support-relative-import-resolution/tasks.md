## 1. Core Implementation

- [x] 1.1 Implement `_compute_package_root()` using `__init__.py` detection with LCP-of-parents fallback
- [x] 1.2 Add `_compute_lcp_of_dirs()` helper for directory-path LCP (extract from existing `_compute_lcp`)
- [x] 1.3 Refactor `__init__` to use `_package_root` instead of `_lcp`
- [x] 1.4 Update `_resolve_module()` to resolve under `_package_root`
- [x] 1.5 Add `_resolve_relative_module(file_path, level, module)` with package-aware module path inference
- [x] 1.6 Update `extract()` AST loop: remove `node.level == 0` guard, route relative imports to `_resolve_relative_module`
- [x] 1.7 Set `properties={"is_relative": True}` on relations from relative imports
- [x] 1.8 Skip relation generation when relative import resolves to empty module name

## 2. Tests

- [x] 2.1 Replace `test_relative_import_ignored` with `test_relative_import_same_package`
- [x] 2.2 Add `test_relative_import_parent_package` (`from .. import x`)
- [x] 2.3 Add `test_relative_import_submodule` (`from .module import x`)
- [x] 2.4 Add `test_relative_import_star` (`from . import *` → `__init__.py`)
- [x] 2.5 Add `test_relative_import_init_self` (`from . import x` from `__init__.py`)
- [x] 2.6 Add `test_relative_import_escapes_root` (`from ... import x` from shallow file)
- [x] 2.7 Add `test_relative_import_has_is_relative_flag`
- [x] 2.8 Add `test_package_root_detection` with `__init__.py` present
- [x] 2.9 Add `test_package_root_fallback_to_lcp` without `__init__.py`
- [x] 2.10 Verify all existing tests still pass (absolute import compatibility)

## 3. Spec Update

- [x] 3.1 Update `openspec/specs/cross-file-dependencies/spec.md` with modified requirements (relative import resolution, package root detection)
- [x] 3.2 Add new requirements to `openspec/specs/cross-file-dependencies/spec.md` (is_relative flag, skipped escapes, star import)
