# Idea: Support Relative Import Resolution in PythonImportExtractor

**Date:** 2026-05-03
**Status:** New
**Context:** The user noted that the current `PythonImportExtractor` skips all relative imports, yet the source-graph project itself relies heavily on them (`from .extractor import Extractor`, `from .models import Node`, etc.).

## Description

Extend `PythonImportExtractor` to resolve relative imports (`from . import x`, `from .. import y`, `from .module import z`) to actual files within the analyzed set. Currently, the extractor only handles absolute imports (`import x`, `from x import y`) and explicitly ignores `ImportFrom` nodes with `node.level > 0`. This leaves a significant gap for typical Python codebases where relative imports are the standard for intra-package references.

### Example / Use case

Given a project structure:

```
src/
  source_graph/
    __init__.py
    python_import_extractor.py
    extractor.py
    models.py
```

With `python_import_extractor.py` containing:

```python
from .extractor import Extractor
from .models import Node, Relation
```

The extractor should resolve `.extractor` to `src/source_graph/extractor.py` and `.models` to `src/source_graph/models.py`, emitting `file_imports_module` relations from `python_import_extractor.py` to those files, just as it does for absolute imports.

## Motivation

1. **Completeness for real codebases**: Relative imports are extremely common in Python packages. The source-graph project itself uses them extensively, meaning its own dependency graph is currently incomplete.
2. **Accurate intra-package graphs**: Without relative import support, the dependency dimension misses the very edges that bind a package together.
3. **Natural extension**: The extractor already maintains the full set of analyzed files and computes a longest common parent directory (`_lcp`). Relative resolution is a matter of using the current file's absolute path to determine its package prefix and then resolving the relative module path against that prefix.

## Potential Implementation

1. **Capture relative imports in AST parsing**:
   - In the `ImportFrom` handling loop, remove the `node.level == 0` guard so that `node.level > 0` imports are also collected.
   - For relative imports, the effective module name must be computed from the current file's directory depth and the import's level.

2. **Resolve relative module paths**:
   - Given a file at `/project/src/source_graph/extractor.py` and an import `from .models import Node`:
     - The file's directory is `/project/src/source_graph/`.
     - The import level is `1` (one dot), so the base package is `source_graph`.
     - The module `.models` resolves to `source_graph.models`.
     - Map `source_graph.models` to `src/source_graph/models.py` using the existing `_resolve_module` logic.
   - For `from ..other_pkg import thing` from `src/source_graph/extractor.py`:
     - Level `2` moves up to `src/`, then into `other_pkg`.

3. **Edge cases**:
   - `from . import something` (intra-package import without submodule) — may need to resolve to `__init__.py` of the current package.
   - `from .. import something` — same, but parent package.
   - Ensure resolution does not escape the analyzed set (`_lcp`) boundary.

## Related Areas

- `src/source_graph/python_import_extractor.py` — the extractor to extend
- `ideas/2026-05-03--symbol-level-import-dependency-extraction.md` — sibling future enhancement that also touches `python_import_extractor.py`
- `openspec/changes/archive/2026-05-03-add-dependency-extractor/` — the archived change that introduced the base `PythonImportExtractor`

## Notes

- **Challenge**: Relative imports require knowing the current file's position within the package hierarchy, which means `extract()` needs to use `file_path` not just for reading but also for computing the package prefix.
- **Open questions**:
  - Should relative imports that resolve outside the analyzed set be treated as external dependencies or silently ignored?
  - How to handle `from . import *` at the file level?
  - Should the relation type remain `file_imports_module` for relative imports, or should a distinct type like `file_imports_relative_module` be introduced?
- **Deferred**: This is intentionally out of scope for the initial MVP but is the highest-value next increment for the dependency dimension.
