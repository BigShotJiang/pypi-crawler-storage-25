## Why

`PythonImportExtractor` currently skips all relative imports (`from . import x`, `from .. import y`), leaving a significant gap in dependency graphs for typical Python codebases where relative imports are the standard for intra-package references. The source-graph project itself relies heavily on relative imports, meaning its own dependency graph is currently incomplete. This change closes that gap.

## What Changes

- Extend `PythonImportExtractor` to resolve relative `ImportFrom` statements (`from .`, `from ..`, `from .module`) to actual files within the analyzed set.
- Replace LCP-based module resolution with automatic package root detection using `__init__.py` locations, making resolution reliable for real Python packages.
- Emit `file_imports_module` relations for relative imports with `properties={"is_relative": True}` for traceability.
- Gracefully handle edge cases: `from . import *`, relative imports that escape the analyzed set, and `__init__.py` self-references.
- Update tests to cover relative import resolution scenarios.

## Capabilities

### New Capabilities
<!-- None - this is an enhancement to existing capability -->

### Modified Capabilities
- `cross-file-dependencies`: Changes the requirement "Relative imports are ignored" to "Relative imports are resolved". Also updates module resolution from LCP-based to package-root-based.

## Impact

- Modified: `src/source_graph/python_import_extractor.py` (core logic changes)
- Modified: `tests/test_python_import_extractor.py` (new test cases, update existing "ignored" test)
- Modified: `openspec/specs/cross-file-dependencies/spec.md` (requirement updates)
