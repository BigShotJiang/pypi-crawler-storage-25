## MODIFIED Requirements

### Requirement: Extractor extracts absolute import statements
The system SHALL provide a `PythonImportExtractor` that parses `import` and `from ... import` statements from Python source files and produces nodes and relations for the `dependencies` dimension.

#### Scenario: Simple import statement
- **WHEN** a file contains `import os`
- **THEN** the extractor creates a relation from the importing file to an external module node representing `os`

#### Scenario: From-import statement
- **WHEN** a file contains `from collections import defaultdict`
- **THEN** the extractor creates a relation from the importing file to an external module node representing `collections`

#### Scenario: Multiple imports in one statement
- **WHEN** a file contains `import os, sys`
- **THEN** the extractor creates separate relations for `os` and `sys`

#### Scenario: Relative imports are resolved
- **WHEN** a file contains `from . import x`
- **THEN** the extractor resolves the import relative to the current file's package and creates a relation if the target is found within the analyzed set

#### Scenario: Relative from-import to submodule
- **WHEN** a file at `pkg/a.py` contains `from .b import x`
- **THEN** the extractor creates a relation from `pkg/a.py` to `pkg/b.py`

#### Scenario: Relative parent import
- **WHEN** a file at `pkg/sub/c.py` contains `from .. import x`
- **THEN** the extractor creates a relation from `pkg/sub/c.py` to `pkg/__init__.py`

### Requirement: Module names are resolved to files within the analyzed set
The system SHALL attempt to resolve imported module names to file paths among the files being analyzed. Resolution SHALL use reverse path construction from the detected package root: for a module name `x.y.z`, the system SHALL check candidate paths `ROOT/x/y/z.py` and `ROOT/x/y/z/__init__.py` where ROOT is the inferred package root directory.

#### Scenario: Import resolves to a module file
- **GIVEN** analyzed files include `/project/src/b.py`
- **WHEN** another file contains `import b`
- **THEN** the relation target is the node for `/project/src/b.py`

#### Scenario: Import resolves to a package init file
- **GIVEN** analyzed files include `/project/src/pkg/__init__.py`
- **WHEN** another file contains `import pkg`
- **THEN** the relation target is the node for `/project/src/pkg/__init__.py`

#### Scenario: Import resolves to a nested module
- **GIVEN** analyzed files include `/project/src/pkg/utils.py`
- **WHEN** another file contains `import pkg.utils`
- **THEN** the relation target is the node for `/project/src/pkg/utils.py`

#### Scenario: Unresolved imports become external nodes
- **WHEN** a file contains `import os` and `os` does not match any analyzed file
- **THEN** the relation target is an external module node with `source_file` set to `<external>`

#### Scenario: Package root detected from __init__.py
- **GIVEN** analyzed files include `/project/src/pkg/__init__.py` and `/project/src/pkg/a.py`
- **WHEN** the extractor processes `pkg/a.py`
- **THEN** the package root is `/project/src/` (the parent of the directory containing `__init__.py`)
- **AND** a relative import `from .b import x` resolves to `/project/src/pkg/b.py`

## ADDED Requirements

### Requirement: Relative imports are marked with is_relative property
The system SHALL set `properties={"is_relative": True}` on `file_imports_module` relations that originate from relative import statements.

#### Scenario: Relative import relation has flag
- **WHEN** a file contains `from . import x` and the target is resolved
- **THEN** the resulting `file_imports_module` relation has `properties={"is_relative": True}`

#### Scenario: Absolute import relation has no flag
- **WHEN** a file contains `import os`
- **THEN** the resulting `file_imports_module` relation does not have an `is_relative` property (or has `False`)

### Requirement: Relative imports escaping the analyzed set are skipped
The system SHALL skip creating relations for relative imports whose resolution would produce an empty target module name (i.e., the import references a package above the detected package root).

#### Scenario: Over-scoped relative import is ignored
- **GIVEN** the package root is `/project/src/`
- **WHEN** a file at `/project/src/a.py` contains `from ... import x`
- **THEN** no relation is created for that import

### Requirement: from . import * resolves to package init
The system SHALL resolve `from . import *` as a dependency on the current package's `__init__.py` file.

#### Scenario: Star import from package
- **GIVEN** analyzed files include `/project/src/pkg/__init__.py` and `/project/src/pkg/a.py`
- **WHEN** `pkg/a.py` contains `from . import *`
- **THEN** the extractor creates a relation from `pkg/a.py` to `pkg/__init__.py`
