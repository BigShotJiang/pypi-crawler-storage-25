## Context

`PythonImportExtractor` currently extracts only absolute imports (`import x`, `from x import y`) and explicitly skips `ImportFrom` nodes with `node.level > 0`. Module name resolution uses the LCP (longest common parent directory) of all analyzed files as the module namespace root. This works for flat or simple structures but breaks down for real Python packages where `__init__.py` defines package boundaries and relative imports are the norm.

The source-graph project itself uses relative imports extensively (`from .extractor import Extractor`, `from .models import Node`), so its own dependency graph is currently incomplete.

## Goals / Non-Goals

**Goals:**
- Resolve relative imports (`from . import x`, `from .. import y`, `from .module import z`) to files within the analyzed set.
- Infer the correct Python package root automatically from `__init__.py` locations, replacing the LCP heuristic.
- Maintain backward compatibility: absolute imports and existing test cases continue to work unchanged.
- Emit `file_imports_module` relations for relative imports with `is_relative=True` property for traceability.
- Handle edge cases: `from . import *`, `__init__.py` self-references, and relative imports that escape the analyzed set.

**Non-Goals:**
- Symbol-level import resolution (`from b import MyClass` still links to `b.py`, not `MyClass`).
- Namespace packages (PEP 420) without `__init__.py`.
- Dynamic imports (`__import__`, `importlib`).
- Resolving imports outside the passed file set (e.g., scanning site-packages).

## Decisions

### Decision: Automatic package root detection (replaces LCP)

**Choice:** Infer the package root by finding directories containing `__init__.py` among the analyzed files, then taking the LCP of their parent directories. Fallback to traditional file LCP if no `__init__.py` is found.

**Rationale:** LCP assumes the file-system common ancestor equals the Python package root, which fails when `__init__.py` sits at a deeper level. Package root detection grounds resolution in Python's actual package structure.

**Algorithm:**
```
package_dirs = {dir(p) for p in files if dir(p)/__init__.py in files}
if package_dirs:
    package_root = LCP({parent(d) for d in package_dirs})
else:
    package_root = LCP({parent(p) for p in files})
```

**Example:**
```
src/source_graph/__init__.py
src/source_graph/a.py

package_dirs = {src/source_graph/}
parent_dirs = {src/}
package_root = src/
```

### Decision: Module path inference with __init__ normalization

**Choice:** Compute each file's module path from the package root, treating `__init__.py` specially (its module path is the directory path, not `dir.__init__`).

**Rationale:** `__init__.py` represents the package itself in Python's module namespace. Treating it as module `__init__` causes incorrect relative import resolution.

**Rules:**
- Regular `.py` file: `root/pkg/sub/module.py` → module path `['pkg', 'sub', 'module']`
- `__init__.py`: `root/pkg/sub/__init__.py` → module path `['pkg', 'sub']`

### Decision: Package-aware relative import resolution

**Choice:** Resolve `ImportFrom` with `level > 0` by computing the target package from the current file's module path, not from the file system directly.

**Algorithm:**
```
current_module = module_path of current file
current_package = current_module if file is __init__.py else current_module[:-1]
target_package = current_package[:len(current_package) - (level - 1)]

if module is None:
    target_module = target_package                    # from . import x
else:
    target_module = target_package + [module]         # from .module import x
```

**Verification:**
| File | Import | level | module | Target Module |
|------|--------|-------|--------|---------------|
| `pkg/a.py` | `from .b import x` | 1 | `b` | `pkg.b` |
| `pkg/__init__.py` | `from . import x` | 1 | None | `pkg` |
| `pkg/sub/c.py` | `from .. import x` | 2 | None | `pkg` |
| `pkg/sub/c.py` | `from ..other import x` | 2 | `other` | `pkg.other` |

### Decision: Unified relation type with relative flag

**Choice:** Use `file_imports_module` for all imports (absolute and relative), adding `properties={"is_relative": True}` only for relative imports.

**Rationale:** Avoids data model and renderer changes. The `is_relative` flag provides debugging and filtering capability without breaking existing consumers.

**Alternatives considered:**
- `file_imports_relative_module`: Would require renderer updates.
- No flag at all: Harder to distinguish relative imports when debugging.

### Decision: Skip empty target modules

**Choice:** If relative import resolution produces an empty target module name (e.g., `from ... import x` from a file too close to the package root), skip generating a relation entirely.

**Rationale:** An empty string target would create a meaningless external node. Skipping is cleaner than emitting garbage.

### Decision: from . import * targets the package init

**Choice:** Treat `from . import *` as a dependency on the current package's `__init__.py`.

**Rationale:** `from . import *` consumes the package's public interface, which is defined by `__init__.py` (via `__all__`). Linking to `__init__.py` correctly models the dependency.

## Risks / Trade-offs

| Risk | Mitigation |
|------|-----------|
| Package root detection fails if no `__init__.py` exists | Fallback to LCP preserves existing behavior |
| Partial file sets (only subpackage analyzed) yield incorrect cross-boundary relative imports | Document limitation; imports escaping the detected root are skipped |
| `__init__.py` in nested paths may produce surprising root for monorepos with multiple top-level packages | Algorithm naturally handles multiple roots by LCP-of-parents |
| Circular self-reference via `from . import x` in `__init__.py` | Target is the same `__init__.py` file; deduplication prevents duplicate nodes |
