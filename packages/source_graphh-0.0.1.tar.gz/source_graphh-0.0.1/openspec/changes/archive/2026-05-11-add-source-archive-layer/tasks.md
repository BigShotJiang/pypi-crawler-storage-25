## 1. Schema and Storage Layer

- [x] 1.1 Add `source_contents` table to `RelationStore._init_schema()`
- [x] 1.2 Add `source_paths` table to `RelationStore._init_schema()`
- [x] 1.3 Add `add_source_content(id, content, file_size)` method to `RelationStore`
- [x] 1.4 Add `add_source_path(path, content_id, last_modified)` method to `RelationStore`
- [x] 1.5 Add `get_source_contents()` method to `RelationStore` for presenter queries
- [x] 1.6 Add `get_source_paths()` method to `RelationStore` for presenter queries
- [x] 1.7 Add `source_content_id` column to `nodes` table via `ALTER TABLE`
- [x] 1.8 Update `Node` dataclass in `models.py` with `source_content_id` field

## 2. Extractor Refactoring

- [x] 2.1 Update `Extractor` protocol in `extractor.py` to `extract(content, file_path)`
- [x] 2.2 Refactor `PythonStructureExtractor.extract()` to accept `content` parameter and remove internal `open()`
- [x] 2.3 Refactor `PythonImportExtractor.extract()` to accept `content` parameter and remove internal `open()`
- [x] 2.4 Update all extractor tests to pass `content` parameter

## 3. CLI Integration

- [x] 3.1 Modify `extract_command()` to read file contents before extraction loop
- [x] 3.2 Add archiving step: write to `source_contents` (INSERT OR IGNORE) before extraction
- [x] 3.3 Add archiving step: write to `source_paths` (INSERT OR REPLACE) before extraction
- [x] 3.4 Pass archived `content` to extractors instead of letting them read disk
- [x] 3.5 Bind `source_content_id` to all extracted nodes before `store.add_nodes()`
- [x] 3.6 Update CLI tests for new extract flow

## 4. Presenter Enhancement

- [x] 4.1 Add `get_source_contents()` and `get_source_paths()` to `GraphStore` protocol (or use `hasattr` check)
- [x] 4.2 Query archived source data in `HTMLPresenter.render()`
- [x] 4.3 Embed `sourceContents` and `sourcePaths` as JavaScript in generated HTML
- [x] 4.4 Add `getSourceSnippet()` helper in frontend JavaScript
- [x] 4.5 Extend tooltip rendering to include source code snippets
- [x] 4.6 Add monospace/code styling for source snippets in tooltip CSS
- [x] 4.7 Handle external modules gracefully (no snippet)

## 5. Testing and Validation

- [x] 5.1 Add store tests for `source_contents` CRUD operations
- [x] 5.2 Add store tests for `source_paths` CRUD operations
- [x] 5.3 Add store tests for `(path, content_id)` uniqueness constraint
- [x] 5.4 Add store tests for content deduplication (same content, different paths)
- [x] 5.5 Add integration test: full extract → present cycle with source snippet verification
- [x] 5.6 Run existing test suite to verify no regressions
