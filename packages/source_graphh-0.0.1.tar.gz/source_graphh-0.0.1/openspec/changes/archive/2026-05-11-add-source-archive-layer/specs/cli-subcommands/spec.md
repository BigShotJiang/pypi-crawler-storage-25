## MODIFIED Requirements

### Requirement: Extract subcommand produces database
The system SHALL provide an `extract` subcommand that accepts source files and an output directory, archives source contents and paths into SQLite, runs extraction against archived content, and writes `source_graph.db` to the output directory. The subcommand SHALL NOT perform any rendering.

#### Scenario: Successful extraction with archiving
- **WHEN** the user runs `source-graph extract src/ -o build/`
- **THEN** the system reads all source files from `src/`
- **AND** archives contents into `source_contents` and paths into `source_paths`
- **AND** extracts structure and dependencies using archived content
- **AND** writes `build/source_graph.db`
- **AND** does not produce `report.html`

#### Scenario: Extraction with no valid files
- **WHEN** the user runs `source-graph extract nonexistent/ -o build/`
- **THEN** the system exits with a non-zero status code
- **AND** prints an error message indicating no valid files were found

### Requirement: Subcommands have distinct help text
The system SHALL display help text specific to each subcommand when invoked with `--help`. The `extract` help SHALL describe file and output arguments. The `present` help SHALL describe the database path argument.

#### Scenario: Extract help
- **WHEN** the user runs `source-graph extract --help`
- **THEN** the help text includes descriptions for `files`, `--output`, and `--verbose`

#### Scenario: Present help
- **WHEN** the user runs `source-graph present --help`
- **THEN** the help text includes descriptions for the `db_path` argument

### Requirement: Legacy single-command usage is removed
The system SHALL NOT support the legacy single-command usage `source-graph <files> -o <dir>`. Invoking the command without a subcommand SHALL print usage instructions and exit with a non-zero status code.

#### Scenario: Missing subcommand
- **WHEN** the user runs `source-graph src/ -o build/` without a subcommand
- **THEN** the system prints usage instructions listing available subcommands
- **AND** exits with a non-zero status code

## ADDED Requirements

### Requirement: Extract subcommand archives before extracting
The system SHALL modify the `extract` subcommand to archive all source files into `source_contents` and `source_paths` before invoking extractors. Extractors SHALL receive content from the archive rather than reading directly from disk.

#### Scenario: Extraction reads from archive
- **WHEN** the `extract` subcommand processes a file
- **THEN** the file content is first written to `source_contents`
- **AND** the path mapping is written to `source_paths`
- **AND** the extractor receives the archived content for parsing
