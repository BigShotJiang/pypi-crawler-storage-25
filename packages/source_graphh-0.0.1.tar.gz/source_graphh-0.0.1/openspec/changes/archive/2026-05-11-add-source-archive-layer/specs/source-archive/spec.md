## ADDED Requirements

### Requirement: Source contents are archived in SQLite
The system SHALL persist the full content of analyzed source files into a SQLite `source_contents` table. The table SHALL use `content_hash` (SHA-256 of the content) as its primary key, enabling content-addressed storage.

#### Scenario: Archiving a source file
- **WHEN** a file with content `"import os\n"` is analyzed
- **THEN** a record is created in `source_contents` with `id` equal to the SHA-256 hash of `"import os\n"`
- **AND** the record contains the full file content

#### Scenario: Duplicate content is not stored twice
- **WHEN** two different paths contain identical content
- **THEN** only one `source_contents` record is created
- **AND** both paths reference the same `content_id` via `source_paths`

### Requirement: Source paths are archived with content mapping
The system SHALL persist file path information into a SQLite `source_paths` table. Each record SHALL map a path to a `source_contents` record. The table SHALL enforce uniqueness on the `(path, content_id)` combination.

#### Scenario: Archiving a path-to-content mapping
- **WHEN** a file at `"src/cli.py"` with content hash `"abc123"` is analyzed
- **THEN** a record is created in `source_paths` with `path="src/cli.py"` and `content_id="abc123"`

#### Scenario: Same path with different content creates new mapping
- **WHEN** a file at `"src/cli.py"` is re-analyzed with changed content producing hash `"def456"`
- **THEN** a new `source_paths` record is created with `path="src/cli.py"` and `content_id="def456"`
- **AND** the old mapping remains in the database

### Requirement: Extractors are content-driven
The system SHALL modify all extractors to accept source content as a parameter rather than reading files from disk internally. Extractors SHALL receive `content` and `file_path` parameters, where `content` is the raw source text and `file_path` is used solely for FQN generation and relative import resolution.

#### Scenario: Structure extractor receives content directly
- **WHEN** `PythonStructureExtractor.extract(content="class Foo:\n  pass", file_path="a.py")` is called
- **THEN** the extractor parses the provided content without reading from disk
- **AND** produces nodes with FQN derived from `"a.py"`

#### Scenario: Import extractor receives content directly
- **WHEN** `PythonImportExtractor.extract(content="import os", file_path="a.py")` is called
- **THEN** the extractor parses the provided content without reading from disk
- **AND** resolves relative imports using `"a.py"` as the reference point

### Requirement: Nodes reference archived content
The system SHALL extend the `Node` model with a `source_content_id` field that references `source_contents.id`. All nodes produced by extractors SHALL have this field populated with the content hash of the analyzed file.

#### Scenario: Extracted node links to archived content
- **WHEN** a file with content hash `"abc123"` is extracted producing a class node
- **THEN** the class node's `source_content_id` equals `"abc123"`

### Requirement: HTML report displays source snippets
The system SHALL enhance the HTML presenter to embed archived source contents and display source code snippets in node tooltips. The presenter SHALL look up content via `node.source_content_id` and extract the relevant line range.

#### Scenario: Tooltip shows source snippet for a function
- **WHEN** a user hovers over a function node defined at lines 10-15
- **THEN** the tooltip displays the corresponding source code lines from the archive

#### Scenario: External modules have no source snippet
- **WHEN** a user hovers over an external module node
- **THEN** the tooltip shows only metadata (name, kind) without a source snippet
