## MODIFIED Requirements

### Requirement: Node tooltip on hover
The system SHALL display a tooltip when hovering over a node. The tooltip MUST show the node's name, dependency statistics (outgoing edge count, incoming edge count), and a source code snippet from the archive when available.

#### Scenario: Hover over a node with source snippet
- **WHEN** the user hovers over a function node with archived source content
- **THEN** a tooltip appears showing the node's name and dependency statistics
- **AND** the tooltip displays the relevant source code lines from the archive

#### Scenario: Hover over an external module node
- **WHEN** the user hovers over an external module node
- **THEN** a tooltip appears showing the node's name and dependency statistics
- **AND** no source code snippet is displayed

### Requirement: Presenter accepts GraphStore protocol
The system SHALL initialize `HTMLPresenter` with an object satisfying the `GraphStore` protocol. The presenter SHALL use this store to query nodes, relations, dimensions, and archived source contents at render time.

#### Scenario: Initialize presenter with GraphStore
- **WHEN** an `HTMLPresenter` is constructed with a `GraphStore`-compatible store
- **THEN** `render()` succeeds and produces valid HTML
- **AND** the presenter queries the store for nodes, relations, dimensions, and source contents

#### Scenario: Presenter with mock GraphStore
- **WHEN** an `HTMLPresenter` is constructed with a mock object implementing `GraphStore`
- **THEN** `render()` succeeds without requiring a real SQLite database

## ADDED Requirements

### Requirement: HTML report embeds archived source data
The system SHALL modify the HTML presenter to embed archived source contents and source paths as JavaScript data structures within the generated HTML. The presenter SHALL query `source_contents` and `source_paths` from the store and serialize them for client-side lookup.

#### Scenario: Source data embedded in HTML
- **WHEN** `render()` is called
- **THEN** the HTML contains a `sourceContents` JavaScript object mapping content hashes to content text
- **AND** the HTML contains a `sourcePaths` array mapping paths to content hashes
