## Why

The source-graph pipeline currently discards source file contents after AST parsing. This creates a fundamental architectural gap: the database only stores derived graph structures (nodes/relations), not the raw material that produced them. Without archived source contents, the system cannot support incremental updates, precise source snippet visualization, or future semantic analysis layers that need to re-examine original code.

This change implements **Phase 1 (Source Archive Layer)** of the broader architecture described in [`ideas/2026-05-09--persistent-symbol-table-and-source-archive.md`](../../ideas/2026-05-09--persistent-symbol-table-and-source-archive.md), establishing the first foundational layer toward transforming source-graph from a disposable analysis pipeline into a persistent code knowledge base.

## What Changes

- Introduce two new SQLite tables: `source_contents` (content-addressed source storage) and `source_paths` (path-to-content mapping with archiving)
- Decouple extractors from disk I/O: extractors receive `content` directly and no longer read files internally
- Modify the `extract` subcommand to archive source files before extraction
- Extend `Node` model with `source_content_id` linking analysis products to archived content
- Enhance HTML presenter to display source code snippets in node tooltips via content lookup
- **BREAKING**: Extractor protocol signature changes from `extract(file_path)` to `extract(content, file_path)`

## Capabilities

### New Capabilities
- `source-archive`: Content-addressed storage of source files with path-to-content mapping, enabling source snippet visualization and future incremental analysis

### Modified Capabilities
- `cli-subcommands`: The `extract` subcommand behavior changes to archive source files into `source_contents`/`source_paths` before running extractors
- `graph-visualization`: Node tooltips in the HTML report gain the ability to display source code snippets from the archive

## Impact

- `src/source_graph/store.py`: New schema and storage methods
- `src/source_graph/models.py`: `Node` gains `source_content_id` field
- `src/source_graph/extractor.py`: Protocol signature change
- `src/source_graph/python_structure_extractor.py`: Stop reading disk, accept `content` parameter
- `src/source_graph/python_import_extractor.py`: Stop reading disk, accept `content` parameter
- `src/source_graph/cli.py`: Extract flow split into "archive" and "extract" phases
- `src/source_graph/presenter.py`: Embed archived source data; tooltip source snippet rendering
