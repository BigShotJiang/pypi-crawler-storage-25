## Context

source-graph currently operates as a disposable analysis pipeline: files are read from disk, AST-parsed, nodes/relations are extracted, and the original source content is discarded. The SQLite database only stores derived graph structures.

This design introduces the Source Archive Layer — the first step toward transforming source-graph into a persistent code knowledge base where the database becomes the single source of truth for all downstream analysis.

## Goals / Non-Goals

**Goals:**
- Establish content-addressed source storage (`source_contents`) and path-to-content mapping (`source_paths`)
- Decouple extractors from disk I/O so they receive content directly
- Enable HTML report tooltips to display source code snippets from the archive
- Create the foundation for future incremental updates and semantic analysis

**Non-Goals:**
- Incremental updates (hash-based skipping) — Phase 1.5
- Symbol table, bindings, or semantic resolution — Phase 2+
- Content compression or external blob storage
- Multi-version history management beyond basic (path, content_id) uniqueness

## Decisions

### Content-addressed storage with `content_hash` as primary key
**Decision:** `source_contents.id = SHA-256(content)`

**Rationale:** Content hash as identity enables natural deduplication (identical files across different paths share storage), provides stable identifiers for incremental updates, and aligns with content-addressable storage principles.

**Alternative considered:** UUID per record — rejected because it would prevent automatic deduplication and complicate incremental detection.

### Separate `source_contents` and `source_paths` tables
**Decision:** Two tables: one for content (deduplicated), one for path-to-content mapping.

**Rationale:** Separates the "what" (content) from the "where" (path). A single content can be referenced by multiple paths. Path mappings are archived per-analysis and support future version history.

**Alternative considered:** Single table with both path and content — rejected because it would duplicate content storage for identical files at different paths.

### Extractors receive `content` parameter directly
**Decision:** Change extractor protocol from `extract(file_path)` to `extract(content, file_path)`.

**Rationale:** Establishes the database as the input source for analysis. Extractors become pure content transformers. The `file_path` parameter is retained solely for FQN generation and relative import resolution.

**Alternative considered:** Extractors read from database internally — rejected because it couples extractors to storage and complicates testing.

### Nodes reference content, not paths
**Decision:** `Node.source_content_id` references `source_contents.id` (content hash).

**Rationale:** Analysis products belong to the content that was analyzed, not the path through which it was accessed. Paths are metadata that can be looked up indirectly via `content_id`.

**Alternative considered:** `Node.source_path_id` referencing `source_paths` — rejected because nodes are semantically tied to content, not to a specific path mapping.

## Risks / Trade-offs

| Risk | Mitigation |
|------|-----------|
| Embedding all source content in HTML inflates file size | Acceptable for typical projects (< 5MB total); defer lazy loading to future optimization |
| Orphaned `source_paths` records when content changes | Acceptable for Phase 1; future cleanup via batch IDs or TTL |
| Extractor protocol change breaks external extractors | This is a **BREAKING** change documented in proposal; only built-in extractors exist currently |
| `source_contents` table grows large for big codebases | SQLite handles multi-MB TEXT; defer compression to future |

## Migration Plan

No migration needed — this is an additive change. Existing databases without `source_contents`/`source_paths` will have these tables created on next `extract` run. The `nodes` table schema is extended with `source_content_id` via `ALTER TABLE ADD COLUMN`.

## Open Questions

1. Should `source_paths` include a `batch_id` or `analysis_run_id` to group mappings from a single `extract` invocation for easier cleanup?
2. How should the presenter handle nodes whose `source_content_id` references content that no longer exists in `source_contents` (e.g., after database corruption or partial export)?
3. Should `source_contents` store language information for future multi-language support?
