## Why

当前 `diff-relation` 项目陷入困境的根本原因：**目标定义过窄 + 技术假设不成立**。

具体表现为：

1. **输入假设过窄**：把系统局限为 "diff 输入"，而核心目标（识别代码关系）与 diff 无关
2. **产出物倒置**：把 "diff 改动点之间的引用关系聚类" 作为最终产出，而 "关系" 本身才是价值所在
3. **技术墙**：对"部分代码做语义分析"不成熟（LSP 需完整项目结构，jedi 也不完美），导致语义提取层迟迟无法推进，连带可视化层也无法落地

新项目 `source-graph` 另起炉灶，回归本质：**代码是一个关系容器，系统负责提取、承载、呈现关系**。

## What Changes

- **新建项目** `source-graph`，不继承旧项目代码包袱
- 核心架构：提取器（Extractor）→ 关系容器（Store）→ 呈现层（Presenter）
- 首个里程碑：结构维度（文件→类→方法的 contains 关系）

## Capabilities

### New Capabilities
- `structure-extraction`：从代码文件提取物理结构关系
- `relation-store`：持久化存储多维度关系数据
- `html-presenter`：交互式 HTML 可视化，支持维度切换

### Modified Capabilities
- 无（新项目）

## Impact

- **新增项目**：`source-graph/`（独立仓库）
- **旧项目**：`diff-relation` 完全不动，保留现状
- **无破坏性变更**：新项目与旧项目零耦合
