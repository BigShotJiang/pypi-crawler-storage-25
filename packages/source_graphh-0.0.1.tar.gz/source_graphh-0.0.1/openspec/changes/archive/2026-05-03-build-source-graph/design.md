## 架构概览

```
┌─────────────────────────────────────────────────────────────┐
│                    source graph                              │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   ┌─────────────┐      ┌─────────────┐      ┌───────────┐  │
│   │  Extractor  │─────▶│    Store    │◀─────│ Presenter │  │
│   │  (Python)   │      │ (persisted) │      │  (HTML)   │  │
│   └─────────────┘      └─────────────┘      └───────────┘  │
│        ↑                                          │         │
│        └──────── 输入：一个或多个文件路径 ──────────┘         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 设计原则

1. **关系是一等公民**：系统不预设关系类型，而是承载、容纳、呈现关系
2. **维度隔离**：不同关系类型属于不同维度，可独立展示
3. **提取器独立**：每个提取器独立工作，互不强依赖
4. **克制**：不过度设计，按需实现

---

## 核心数据模型

### Node（节点）

节点是"关系"的端点，具有层次结构：

```python
@dataclass
class Node:
    id: str                    # 全局唯一标识
    name: str                  # 节点名称
    kind: str                  # "file" | "class" | "function" | "method" | "variable"
    fqn: str                   # Fully Qualified Name，如 "file_a/ClassA/method_a"
    source_file: str           # 所属源文件路径
    range: Optional[Range]     # 在源文件中的位置
    parent_id: Optional[str]   # 父节点 ID（构成层次）
    properties: Dict           # 额外属性，提取器自由填充
```

### Relation（关系）

```python
@dataclass
class Relation:
    id: str
    source_id: str             # 源节点 ID
    target_id: str             # 目标节点 ID
    type: str                  # 具体关系类型："contains" | "calls" | "imports" | "inherits" | ...
    dimension: str             # 所属维度："structure" | "reference" | "dependency" | ...
    properties: Dict           # 额外属性（行号、置信度、来源提取器等）
```

**关键设计**：`type` 和 `dimension` 分离
- `dimension` = 这个关系属于哪个"视图层"
- `type` = 在这个视图内，具体是什么关系

---

## 三层接口

### Layer 1: Extractor（提取器）

```python
class Extractor(ABC):
    @property
    @abstractmethod
    def dimension(self) -> str:
        """返回此提取器产出的维度名称，如 'structure'"""
        pass

    @abstractmethod
    def extract(self, file_path: str) -> Tuple[List[Node], List[Relation]]:
        """
        输入：单个文件的文件路径
        输出：(该文件中的节点列表, 该文件中的关系列表)
        """
        pass
```

**设计决策**：
- 输入是文件路径（不是文件内容），提取器自行读取
- 不考虑项目上下文参数
- 不考虑提取器组合/链式调用
- 一个提取器只产出一种 dimension 的关系

### Layer 2: Store（关系容器）

```python
class RelationStore:
    def add_nodes(self, nodes: List[Node]) -> None: ...
    def add_relations(self, relations: List[Relation]) -> None: ...
    def get_nodes(self, filter: NodeFilter) -> List[Node]: ...
    def get_relations(self, filter: RelationFilter) -> List[Relation]: ...
    def get_dimensions(self) -> List[str]: ...
    def save(self, path: str) -> None: ...      # 持久化
    def load(self, path: str) -> None: ...      # 加载
```

**设计决策**：
- 关系需要持久化（JSON 或 SQLite，Milestone 1 先用 JSON）
- 查询能力根据呈现层需要按需实现
- 暂不考虑增量更新

### Layer 3: Presenter（呈现层）

```python
class Presenter:
    def render(self, store: RelationStore, dimension: str) -> str:
        """
        输入：关系容器 + 用户选择的维度
        输出：HTML 字符串（完整页面）
        """
        pass
```

**设计决策**：
- 输出格式：HTML（完整可交互页面）
- 交互：动态切换维度（仅支持单一维度展示，暂不支持叠加）
- 维度选择面板：列出 store 中所有可用 dimension

---

## Milestone 1: 结构维度

### 范围

输入：一个或多个 Python 文件路径  
输出：交互式 HTML，展示文件→类→方法的 contains 关系树

### 技术栈

- **提取器**：Python `ast` 模块（标准库，零外部依赖）
- **存储**：JSON 文件
- **呈现**：纯 HTML + JavaScript（可内嵌 D3.js 或简单 DOM 树）

### 关系类型

```
dimension: "structure"
types:
  - "file_contains_class"
  - "class_contains_method"
  - "file_contains_function"
```

---

## 输入假设

最小输入单元：一个文件  
支持批量：多个文件路径  

```
极简 ◄──────────────────────────────────────► 完整
  │                    │
  ▼                    ▼
单个文件           多个文件
  │                    │
  ▼                    ▼
AST 提取          批量 AST 提取
（结构关系）       （结构关系）
```

未来可向左右扩展，但 Milestone 1 不做过度设计。

---

## 不做的事（明确边界）

| 不做 | 原因 |
|------|------|
| 语义分析（调用关系、类型推断） | 技术不成熟，非 Milestone 1 范围 |
| 多维度叠加展示 | 设计简化，仅支持单一维度切换 |
| diff 解析 | 与核心目标无关 |
| 项目上下文/虚拟工作空间 | 简化假设，输入即文件 |
| 提取器组合/链式调用 | 不过度设计 |
| 跨文件引用解析 | 需要语义分析，暂不涉及 |
