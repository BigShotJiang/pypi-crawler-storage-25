## Phase 1: 核心基础设施

- [x] 1.1 定义核心数据模型
  - `Node` dataclass（id, name, kind, fqn, source_file, range, parent_id, properties）
  - `Relation` dataclass（id, source_id, target_id, type, dimension, properties）
  - `Range` dataclass（start_line, start_col, end_line, end_col）
  - `NodeFilter` / `RelationFilter` 查询条件类

- [x] 1.2 实现 `RelationStore`
  - `add_nodes()` / `add_relations()`
  - `get_nodes()` / `get_relations()`（支持按 dimension、type、source_file 过滤）
  - `get_dimensions()`（返回所有可用维度）
  - `save(path)` / `load(path)`：JSON 格式持久化
  - 单元测试

- [x] 1.3 定义 `Extractor` 抽象接口
  - `Extractor` ABC（dimension 属性 + extract 方法）
  - 接口契约文档

## Phase 2: 结构维度提取器

- [x] 2.1 实现 `PythonStructureExtractor`
  - 继承 `Extractor`，dimension = "structure"
  - 使用 Python `ast` 模块遍历文件
  - 提取节点：FileNode → ClassNode / FunctionNode → MethodNode
  - 提取关系：file_contains_class, class_contains_method, file_contains_function
  - 为每个节点生成 FQN

- [x] 2.2 处理边界情况
  - 嵌套类
  - 嵌套函数
  - 模块级别的函数/变量
  - 语法错误的文件（优雅跳过 + 日志）

- [x] 2.3 提取器单元测试
  - 简单类结构
  - 嵌套结构
  - 空文件
  - 语法错误文件

## Phase 3: 呈现层

- [x] 3.1 实现 `HTMLPresenter`
  - `render(store, dimension)` → 完整 HTML 页面
  - 维度选择面板（从 store 读取可用维度列表）
  - 默认展示树形结构（文件夹/文件/类/方法层级）
  - 纯 HTML + 内嵌 CSS + 内嵌 JS（不依赖外部构建工具）

- [x] 3.2 交互功能
  - 点击展开/折叠节点
  - 维度切换（面板选择后重新渲染）
  - 节点悬停显示详细信息（FQN、行号范围）

## Phase 4: CLI 与端到端

- [x] 4.1 实现 CLI 入口
  - 命令：`source-graph <file1> [file2] ... --output report.html`
  - 流程：遍历输入文件 → 运行提取器 → 存入 Store → 渲染 HTML → 写出文件

- [x] 4.2 端到端验证
  - 用真实 Python 项目（如本项目自身）跑通完整 pipeline
  - 验证 HTML 输出可正常打开和交互
  - 验证 JSON 持久化文件内容正确

## Phase 5: 项目初始化

- [x] 5.1 新建 `source-graph` 项目仓库
  - 目录结构：`src/`, `tests/`, `pyproject.toml`
  - Python 版本要求
  - 无外部依赖（Milestone 1 只用标准库）

- [x] 5.2 基础工程配置
  - pytest 配置
  - 简单的 CI（可选）
  - README（使用说明）
