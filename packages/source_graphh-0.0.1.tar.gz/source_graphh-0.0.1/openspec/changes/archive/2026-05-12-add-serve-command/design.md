## Context

`source-graph` currently has two CLI subcommands: `extract` (produces `source_graph.db`) and `present` (reads the db and writes `report.html`). There is no way to view the report without generating a file on disk. This design adds a `serve` subcommand that hosts the report directly from the database over HTTP, eliminating the file-generation step for iterative exploration.

The presenter layer (`HTMLPresenter.render()`) already builds all dimension data and serializes it into a self-contained HTML string. This design reuses that capability unchanged — the server is a thin HTTP wrapper around the existing render pipeline.

## Goals / Non-Goals

**Goals:**
- Add `source-graph serve <db_path>` that starts an HTTP server
- Browser visit to `http://host:port/` displays the interactive report
- Reuse existing `HTMLPresenter.render()` without modification
- Zero changes to frontend code (`app.js`, CSS, HTML structure)
- Zero new Python dependencies (stdlib only)

**Non-Goals:**
- REST API endpoints (e.g. `/api/nodes`, `/api/data`)
- Query-string routing (e.g. `/?dimension=dependencies`)
- Frontend dynamic fetching (`fetch('/api/...')`)
- Runtime filtering, search, or drill-down without page refresh
- Concurrent request optimization or caching layers
- HTTPS or authentication

## Decisions

### 1. Use Python stdlib `http.server` instead of FastAPI/Flask

**Rationale:** The server surface area is exactly one route (`GET /`). `http.server.BaseHTTPRequestHandler` is sufficient and avoids adding dependencies. If the project later needs a full REST API, migrating to FastAPI is straightforward because the data-building logic is already isolated in `HTMLPresenter`.

**Alternative considered:** FastAPI would give auto-generated docs and async handling, but is overkill for a single-route MVP and adds `uvicorn` + `fastapi` dependencies.

### 2. Server-side rendering (SSR) instead of API + SPA

**Rationale:** The `HTMLPresenter` already generates a complete, self-contained HTML page. Calling `presenter.render()` on each request is the shortest path to value. The frontend requires no modifications — dimension switching, hover tooltips, graph rendering all continue to work via the embedded JSON payload.

**Alternative considered:** API-driven mode where frontend fetches `/api/data` and renders dynamically. This is the long-term direction (see `code-knowledge-graph-api` idea), but adds API design, frontend async initialization, and CORS concerns. Deferred to a future change.

### 3. No query parameter handling in MVP

**Rationale:** `HTMLPresenter.render(dimension)` sets the default dimension, but the returned HTML already includes data for *all* dimensions. The frontend's dimension selector works client-side without server re-involvement. Adding `?dimension=X` would require URL parsing and a decision on whether to re-render or rely on client-side switching — complexity without clear user benefit at this stage.

**Migration path:** If needed later, query parameters can be parsed in `do_GET` and passed to `render()` without breaking existing behavior.

### 4. Read database on every request

**Rationale:** SQLite with WAL mode handles multiple readers efficiently. The data-building logic in `_build_*_data()` operates on in-memory structures after the initial query. For typical project sizes, request latency is sub-second. Caching the rendered HTML would add invalidation complexity for minimal gain.

## Risks / Trade-offs

| Risk | Mitigation |
|------|-----------|
| **Performance**: Large databases may cause slow page loads because all dimensions are rendered on every request | Acceptable for MVP — databases are local SQLite, queries are indexed. If problematic, future change can add selective dimension rendering or caching. |
| **Concurrency**: `http.server` is single-threaded; simultaneous requests block | Acceptable for local development use case. If needed later, switch to `ThreadingHTTPServer` or FastAPI. |
| **Scope creep**: Users may expect API endpoints after seeing a server running | Document clearly that `serve` is a static report viewer, not an API server. Future `code-knowledge-graph-api` change will address API needs. |
| **Database locked**: If `extract` runs while `serve` is active, SQLite writer lock may briefly block readers | WAL mode mitigates this. Document that `serve` reads from a snapshot and may lag behind active extractions. |
