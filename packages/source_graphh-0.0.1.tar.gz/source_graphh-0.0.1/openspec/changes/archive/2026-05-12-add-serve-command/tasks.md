## 1. Server Module

- [x] 1.1 Create `src/source_graph/server.py` with `ServeHandler` class extending `http.server.BaseHTTPRequestHandler`
- [x] 1.2 Implement `do_GET` to handle `GET /` by calling `HTMLPresenter.render()` and returning HTML response
- [x] 1.3 Implement `do_GET` to return 404 for all other paths
- [x] 1.4 Add `run_server(db_path, host, port)` function that creates `HTTPServer` and calls `serve_forever()`
- [x] 1.5 Add graceful shutdown on KeyboardInterrupt (Ctrl+C)

## 2. CLI Integration

- [x] 2.1 Add `serve` subparser to `cli.py` with arguments: `db_path`, `--host`, `--port`
- [x] 2.2 Implement `serve_command(args)` that validates `db_path` exists and calls `run_server()`
- [x] 2.3 Wire `serve_command` into the main dispatch block
- [x] 2.4 Add log message on server startup showing bound URL (e.g. `Serving at http://127.0.0.1:8080`)

## 3. Testing

- [x] 3.1 Add unit test for `serve_command` with missing database (asserts non-zero exit)
- [x] 3.2 Add integration test: start server in thread, `GET /`, assert response is valid HTML containing `<!DOCTYPE html>`
- [x] 3.3 Verify existing `extract` and `present` commands are unaffected

## 4. Documentation

- [x] 4.1 Update README.md with `serve` command usage example
- [x] 4.2 Add `serve` to CLI help text (already handled by argparse, verify output)
