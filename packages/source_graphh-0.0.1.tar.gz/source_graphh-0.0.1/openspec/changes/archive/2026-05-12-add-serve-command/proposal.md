## Why

Current `source-graph` requires running `present` to regenerate a static `report.html` every time a user wants to view the analysis results. This is inefficient for iterative exploration: a developer must `extract` → `present` → open file → repeat. The SQLite database (`source_graph.db`) already contains all structured data; the rendering step should be accessible on-demand without file generation. A `serve` command bridges this gap by turning the database into a live, browser-accessible report.

## What Changes

- Add `source-graph serve <db_path>` CLI subcommand
- Add `src/source_graph/server.py` using Python stdlib `http.server` (zero new dependencies)
- HTTP handler calls existing `HTMLPresenter.render()` on each `GET /` to produce the full HTML response
- Frontend (`app.js`) requires **zero changes** — all dimension data remains embedded JSON, dimension switching stays pure client-side JS
- Add `--host` (default `127.0.0.1`) and `--port` (default `8080`) arguments
- No REST API, no query string routing, no frontend fetch logic in MVP

## Capabilities

### New Capabilities
- `serve-mode`: Serve an interactive HTML report directly from an existing SQLite database over HTTP, without generating intermediate files.

### Modified Capabilities
- *(None — this is a pure implementation change. CLI subcommand behavior is covered by existing `cli-subcommands` spec; no spec-level requirements change.)*

## Impact

- `src/source_graph/cli.py`: add `serve` subcommand parser and dispatch
- `src/source_graph/server.py`: new file (~60 lines)
- `src/source_graph/presenter.py`: **no changes**
- `src/source_graph/static/*` (if template separation lands first): **no changes**
- Existing `extract` and `present` commands: **no behavioral impact**
- Dependencies: **none** (uses stdlib `http.server`)
