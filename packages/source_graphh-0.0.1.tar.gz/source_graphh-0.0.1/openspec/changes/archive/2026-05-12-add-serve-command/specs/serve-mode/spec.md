## ADDED Requirements

### Requirement: Serve command accepts a database path
The system SHALL provide a `serve` CLI subcommand that accepts a path to an existing `source_graph.db` SQLite database.

#### Scenario: Successful invocation
- **WHEN** the user runs `source-graph serve /path/to/source_graph.db`
- **THEN** the system validates that the database file exists
- **THEN** the system starts an HTTP server

#### Scenario: Missing database
- **WHEN** the user runs `source-graph serve /nonexistent/db`
- **THEN** the system outputs an error message indicating the database was not found
- **THEN** the system exits with a non-zero status code

### Requirement: Server binds to configurable host and port
The system SHALL accept `--host` and `--port` arguments for the `serve` subcommand. The default host SHALL be `127.0.0.1` and the default port SHALL be `8080`.

#### Scenario: Default binding
- **WHEN** the user runs `source-graph serve source_graph.db` without host or port arguments
- **THEN** the server listens on `127.0.0.1:8080`

#### Scenario: Custom binding
- **WHEN** the user runs `source-graph serve source_graph.db --host 0.0.0.0 --port 3000`
- **THEN** the server listens on `0.0.0.0:3000`

### Requirement: GET / returns an HTML report
The server SHALL respond to `GET /` with a complete, self-contained HTML page generated from the database using the existing `HTMLPresenter.render()` logic.

#### Scenario: Browser loads the report
- **WHEN** a browser sends `GET /` to the running server
- **THEN** the server reads the SQLite database
- **THEN** the server invokes `HTMLPresenter.render()` with the default dimension
- **THEN** the server responds with `Content-Type: text/html; charset=utf-8`
- **THEN** the response body contains a valid HTML document with embedded graph data, source contents, and source paths

#### Scenario: Report includes all dimensions
- **WHEN** a browser loads the served page
- **THEN** the page contains data for all dimensions present in the database
- **THEN** the frontend dimension selector allows switching between dimensions without additional server requests

### Requirement: Server does not modify the database
The server SHALL open the database in read-only mode or rely on SQLite's default read behavior. It SHALL NOT write to or modify the database file.

#### Scenario: Concurrent extraction
- **WHEN** the server is serving a database
- **WHEN** a separate `source-graph extract` process updates that same database
- **THEN** the server continues to operate without errors
- **THEN** subsequent page refreshes reflect the updated data
