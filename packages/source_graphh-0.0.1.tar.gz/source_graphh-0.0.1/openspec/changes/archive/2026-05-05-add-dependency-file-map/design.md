## Context

The `dependencies` dimension currently offers a single Tree view where users pick a root file and traverse its import chain via DFS. This is good for deep investigation but poor for understanding global architecture—there is no way to see at a glance which files are central hubs, which are leaf utilities, or how the project layers from entry points down to foundations.

We need a second view mode: a top-down layered map that treats the internal-file dependency graph as a directed graph, compresses cycles, layers by depth-to-leaf, and renders as an SVG graph.

## Goals / Non-Goals

**Goals:**
- Add a Map view to the `dependencies` dimension, rendered as a layered directed graph in SVG.
- Make Map the default view; Tree remains available via a view toggle.
- Exclude external modules from the Map; only internal files participate.
- Handle cycles by compressing strongly connected components (SCC) into grouped nodes before layering.
- Layer nodes by longest-path distance to a leaf (bottom-up), so entry files appear at the top and foundational files at the bottom.
- Support click-to-highlight: clicking a node highlights its entire downstream chain; others dim.
- Use simple diagonal edge routing with alphabetical intra-layer ordering to reduce crossings (first version).

**Non-Goals:**
- No external visualization libraries (D3, Cytoscape, etc.); pure SVG + JS.
- No orthogonal (elbow) edge routing in the first version; diagonal lines only.
- No drag-to-rearrange or pan/zoom in the first version.
- No changes to CLI, extractors, models, or store.

## Decisions

### 1. Map is default, Tree is secondary

**Decision**: When the user opens the `dependencies` dimension, the Map view renders first. A toggle switches to Tree.

**Rationale**: The Map gives the global architectural overview that most users want first. Tree is for drilling into specific files.

### 2. Full SVG rendering

**Decision**: The Map is rendered entirely in SVG (`<svg>` containing `<g>`, `<rect>`, `<text>`, `<line>`).

**Rationale**: SVG provides a single coordinate system for both nodes and edges, eliminating the need to synchronize HTML and SVG layers on resize. SVG elements support standard DOM events (click, hover) and CSS styling (`fill`, `stroke`, `opacity`). Tooltip can be implemented as a floating HTML `<div>` positioned via JS.

**Alternative considered**: HTML nodes + SVG edge overlay. Rejected because keeping two coordinate systems in sync is fragile and adds complexity for no benefit.

### 3. Diagonal edge routing (first version)

**Decision**: Edges are drawn as straight lines from source node center to target node center.

**Rationale**: Simplest to implement. Crossing reduction is handled by alphabetical intra-layer ordering, which is sufficient for small-to-medium projects.

**Alternative considered**: Orthogonal elbow edges (Sugiyama style). Rejected as out of scope for first version; can be added later if diagonal lines become unreadable.

### 4. Tarjan SCC algorithm for cycle compression

**Decision**: Use Tarjan's algorithm (iterative or recursive DFS) to find strongly connected components. Compress each SCC into a single super-node before layering.

**Rationale**: Tarjan is linear time and well-understood. Python's recursion limit could be an issue for very large graphs; if encountered, switch to iterative DFS. After compression the graph is guaranteed DAG, making layering trivial.

### 5. Bottom-up layer assignment

**Decision**: A node's layer = 1 + max(layer of its children). Leaf nodes (no internal outgoing edges) are layer 0. SCCs are treated as single nodes for this calculation.

**Rationale**: This places entry files (deep dependency chains) at the top and foundational files (many importers, few imports) at the bottom, matching the user's mental model.

**Alternative considered**: Top-down layering (distance from roots). Rejected because entry files would be at the bottom, which is counter-intuitive.

## Risks / Trade-offs

| Risk | Mitigation |
|------|------------|
| **Large projects** may produce maps too wide or tall for comfortable viewing | First version accepts this limitation; future iteration can add zoom/pan or filtering. |
| **Recursive DFS** in Tarjan may hit Python recursion limit | Use iterative DFS if graphs exceed ~1000 nodes; document this limit. |
| **Diagonal edges** may cross heavily in dense graphs | Alphabetical intra-layer ordering helps; orthogonal routing is a future enhancement. |
| **SCC compression** loses fine-grained internal structure of cycles | SCCs are drawn as grouped nodes with a border; internal edges are still visible inside the group. |

## Open Questions

- *(none — all design points were clarified during exploration)*
