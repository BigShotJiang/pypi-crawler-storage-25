## 1. Backend: Build dependency map data

- [x] 1.1 Add `_build_dependency_map_data` in `presenter.py` that filters out external modules and external edges
- [x] 1.2 Implement Tarjan SCC algorithm to detect and compress cycles into grouped nodes
- [x] 1.3 Implement bottom-up layer assignment: layer = 1 + max(child layer), leaves = layer 0; include isolated files in layer 0
- [x] 1.4 Sort nodes alphabetically within each layer
- [x] 1.5 Return structured data: `{"layers": [...], "edges": [...], "sccs": [...]}`

## 2. Frontend: SVG Map rendering

- [x] 2.1 Add `renderDependencyMap` function that renders the Map view using full SVG
- [x] 2.2 Calculate node positions: fixed vertical layer spacing, equal horizontal distribution within each layer
- [x] 2.3 Render nodes as SVG `<rect>` + `<text>` grouped in `<g>` elements; render edges as SVG `<line>` elements
- [x] 2.4 Render SCC grouped nodes with a visual border indicating multiple files inside
- [x] 2.5 Add CSS styling for nodes, edges, and SCC groups (hover states, default colors)

## 3. Frontend: View toggle and interaction

- [x] 3.1 Add a "View: [Map ▼]" toggle in the header, visible only for `dependencies` dimension, defaulting to Map
- [x] 3.2 Switching toggle re-renders between Map and Tree views without reloading data
- [x] 3.3 Implement click-to-highlight: clicking a node highlights its entire downstream DFS chain
- [x] 3.4 Dim unhighlighted nodes and edges (opacity 0.3)
- [x] 3.5 Clicking empty SVG canvas clears highlight
- [x] 3.6 Add tooltip on hover showing file name and dependency counts

## 4. Integration and tests

- [x] 4.1 Update `render` method to include Map data alongside Tree data for `dependencies` dimension
- [x] 4.2 Add tests for `_build_dependency_map_data`: filtering, SCC compression, layering, alphabetical ordering
- [x] 4.3 Add tests for presenter HTML output: Map SVG elements exist, view toggle exists, default is Map
- [x] 4.4 Run full test suite (`pytest`) and ensure all tests pass
