## Why

The current `dependencies` dimension renders as an interactive tree where users must pick a root file and drill down branch by branch. This makes it impossible to see the global picture— which files are central hubs, which are leaf utilities, and how the overall architecture layers. A top-down layered map view is needed to understand project structure at a glance.

## What Changes

- Add a new **Map** view to the `dependencies` dimension, rendered as a layered directed graph (SVG) with internal files as nodes and import relationships as edges.
- The Map view becomes the **default** view for `dependencies`; the existing Tree view remains available via toggle.
- External modules are **excluded** from the Map; only internal files participate.
- Cycles are handled by compressing strongly connected components (SCC) into grouped nodes before layering.
- Nodes are layered by longest-path distance to a leaf (bottom-up), so entry files like `cli.py` appear at the top and foundational files like `models.py` at the bottom.
- Clicking a node highlights its entire downstream dependency chain; unhighlighted nodes dim.
- Simple diagonal edge routing with alphabetical intra-layer ordering to minimize crossings (first version).

## Capabilities

### New Capabilities
- *(none — this extends existing dependency visualization rather than introducing a new domain capability)*

### Modified Capabilities
- `cross-file-dependencies`: The HTML rendering requirement changes to support a second view mode (Map) within the `dependencies` dimension, with Map as the default. This is a presentation-layer behavioral change.

## Impact

- `src/source_graph/presenter.py`: New `_build_dependency_map_data()` method; SVG rendering logic for Map view; view toggle (Map/Tree) in the frontend.
- `tests/test_presenter.py`: New tests for Map view structure, layering, and SCC handling.
- No changes to CLI, extractors, models, or store.
