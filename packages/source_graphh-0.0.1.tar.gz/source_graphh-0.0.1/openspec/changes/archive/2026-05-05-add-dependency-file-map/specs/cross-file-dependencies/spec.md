## MODIFIED Requirements

### Requirement: HTML report renders dependencies as interactive graph
The system SHALL render the `dependencies` dimension as an interactive dependency graph using structured data (`type: "dependency_graph"`), distinct from the tree view used for the `structure` dimension. The graph SHALL support two view modes: a **Map** view (layered directed graph, default) and a **Tree** view (collapsible tree). A toggle SHALL allow switching between Map and Tree views. Both views SHALL support tooltips.

#### Scenario: Map view is default
- **GIVEN** the HTML report is rendered for the `dependencies` dimension
- **WHEN** the page loads
- **THEN** the Map view is displayed by default
- **AND** a view toggle shows "Map" as the active option

#### Scenario: Switching to Tree view
- **GIVEN** the Map view is displayed for the `dependencies` dimension
- **WHEN** the user clicks the Tree option in the view toggle
- **THEN** the Tree view is displayed
- **AND** the Tree option is shown as active

#### Scenario: Simple dependency graph in Tree view
- **GIVEN** `a.py` imports `b.py` and `b.py` imports `os`
- **WHEN** the HTML report is rendered for the `dependencies` dimension in Tree view
- **THEN** the output contains an interactive graph showing `a.py` with a dependency on `b.py`, and `b.py` with a dependency on `os` marked as external

#### Scenario: Graph with multiple branches in Tree view
- **GIVEN** `a.py` imports both `b.py` and `c.py`
- **WHEN** the HTML report is rendered for the `dependencies` dimension in Tree view
- **THEN** the graph shows both branches from `a.py` in alphabetical order

#### Scenario: Circular dependency annotation in Tree view
- **GIVEN** `a.py` imports `b.py`, `b.py` imports `c.py`, and `c.py` imports `a.py`
- **WHEN** the HTML report is rendered for the `dependencies` dimension in Tree view
- **THEN** the graph annotates the cycle (e.g., `[circular]`)

## ADDED Requirements

### Requirement: Map view displays only internal files
The system SHALL render the Map view using only internal files (non-external modules). External module nodes SHALL be excluded from the Map. Edges pointing to or from external modules SHALL be omitted from the Map.

#### Scenario: Map view hides external modules
- **GIVEN** `a.py` imports `b.py` and `os`
- **WHEN** the Map view is rendered
- **THEN** `a.py` and `b.py` are visible as nodes
- **AND** `os` is not visible as a node
- **AND** the edge from `a.py` to `os` is not drawn

#### Scenario: Map view with only external dependencies
- **GIVEN** `a.py` imports only `os`
- **WHEN** the Map view is rendered
- **THEN** `a.py` is visible as an isolated node with no edges

### Requirement: Map view compresses cycles into grouped nodes
The system SHALL detect strongly connected components (SCCs) in the internal-file dependency graph and compress each SCC into a single grouped node before layering. The grouped node SHALL visually indicate that it contains multiple files.

#### Scenario: Simple cycle is compressed
- **GIVEN** `a.py` imports `b.py` and `b.py` imports `a.py`
- **WHEN** the Map view is rendered
- **THEN** `a.py` and `b.py` appear as a single grouped node
- **AND** no cycle edges are drawn between them externally

#### Scenario: No cycle when graph is acyclic
- **GIVEN** `a.py` imports `b.py` and `b.py` imports `c.py`
- **WHEN** the Map view is rendered
- **THEN** each file appears as its own node
- **AND** edges are drawn from `a.py` to `b.py` and from `b.py` to `c.py`

### Requirement: Map view layers nodes by depth-to-leaf
The system SHALL assign each node (or grouped SCC node) to a layer based on its longest-path distance to a leaf node. Leaf nodes (nodes with no outgoing internal edges) SHALL be in layer 0. A node's layer SHALL be 1 + the maximum layer of its children. Nodes in higher layers SHALL be rendered above nodes in lower layers.

#### Scenario: Linear chain layering
- **GIVEN** `a.py` imports `b.py`, `b.py` imports `c.py`, and `c.py` has no internal imports
- **WHEN** the Map view is rendered
- **THEN** `c.py` is in the bottom layer
- **AND** `b.py` is in the layer above `c.py`
- **AND** `a.py` is in the layer above `b.py`

#### Scenario: Diamond shape layering
- **GIVEN** `a.py` imports `b.py` and `c.py`, and both `b.py` and `c.py` import `d.py`
- **WHEN** the Map view is rendered
- **THEN** `d.py` is in the bottom layer
- **AND** `b.py` and `c.py` are in the layer above `d.py`
- **AND** `a.py` is in the layer above `b.py` and `c.py`

#### Scenario: Isolated file in bottom layer
- **GIVEN** `a.py` imports `b.py`, and `c.py` has no imports and is not imported by any internal file
- **WHEN** the Map view is rendered
- **THEN** `c.py` is in the bottom layer alongside `b.py`

### Requirement: Map view supports click-to-highlight downstream chain
The system SHALL support clicking a node in the Map view to highlight its entire downstream dependency chain. All nodes and edges reachable from the clicked node via outgoing internal edges SHALL be highlighted. All other nodes and edges SHALL be dimmed.

#### Scenario: Click highlights downstream chain
- **GIVEN** `a.py` imports `b.py` and `c.py`, `b.py` imports `d.py`, and `c.py` has no further imports
- **WHEN** the user clicks `a.py` in the Map view
- **THEN** `a.py`, `b.py`, `c.py`, and `d.py` are highlighted
- **AND** all edges from `a.py` to `b.py`, `a.py` to `c.py`, and `b.py` to `d.py` are highlighted

#### Scenario: Click on leaf highlights only itself
- **GIVEN** `a.py` imports `b.py` and `b.py` has no further internal imports
- **WHEN** the user clicks `b.py` in the Map view
- **THEN** only `b.py` is highlighted
- **AND** `a.py` is dimmed

#### Scenario: Click on empty area clears highlight
- **GIVEN** a node is currently highlighted in the Map view
- **WHEN** the user clicks on an empty area of the SVG canvas
- **THEN** all nodes and edges return to normal brightness

### Requirement: Map view renders edges as diagonal lines
The system SHALL render dependency edges in the Map view as straight diagonal lines connecting source node centers to target node centers. Nodes within the same layer SHALL be ordered alphabetically to reduce edge crossings.

#### Scenario: Edge connects layered nodes
- **GIVEN** `a.py` imports `b.py` and they are in adjacent layers
- **WHEN** the Map view is rendered
- **THEN** a straight line is drawn from the center of the `a.py` node to the center of the `b.py` node
