## ADDED Requirements

### Requirement: CLI write command generates idea files with deterministic frontmatter
The `gas write` command SHALL create a new markdown file containing only a YAML frontmatter block, with the filename derived from `--date` and `--title` arguments.

#### Scenario: Successful idea creation
- **WHEN** the command `gas write --date 2026-05-17 --title "My Great Idea"` is executed
- **THEN** a file is created at `ideas/2026-05-17--my-great-idea.md`
- **AND** the file contains exactly:
  ```yaml
  ---
  date: "2026-05-17"
  relations: []
  ---
  ```
- **AND** the absolute file path is printed to stdout

#### Scenario: Write with relations
- **WHEN** the command includes `--relations '[{"target":"goal:code-intuition","relation":"serves","rationale":"..."}]'`
- **THEN** the generated file contains the specified relations in the frontmatter
- **AND** relations are sorted by `relation` type first, then by `target` alphabetically

#### Scenario: Filename collision
- **WHEN** a file with the same date and title already exists
- **THEN** the command creates the file with a numeric suffix (e.g., `-2`, `-3`)

### Requirement: CLI write command accepts only date, title, and relations
The `write` command SHALL accept exactly three optional/required flags: `--date` (required), `--title` (required), and `--relations` (optional, default `[]`). It SHALL NOT accept a file path argument.

#### Scenario: Missing required arguments
- **WHEN** `--date` or `--title` is omitted
- **THEN** the command exits with a non-zero status code
- **AND** an error message is printed to stderr

#### Scenario: Invalid date format
- **WHEN** `--date` is not in `YYYY-MM-DD` format
- **THEN** the command exits with a non-zero status code
- **AND** an error message is printed to stderr

### Requirement: CLI validate command checks frontmatter compliance
The `gas validate` command SHALL scan `ideas/` and `ideas/goals/` directories and report any frontmatter violations.

#### Scenario: Valid files pass
- **WHEN** all idea and goal files have compliant frontmatter
- **THEN** the command exits with status code 0
- **AND** a success message is printed to stdout

#### Scenario: Invalid date format detected
- **WHEN** a file contains a `date` field not matching `YYYY-MM-DD`
- **THEN** the command exits with a non-zero status code
- **AND** an error message including the file path is printed

#### Scenario: Invalid relation type detected
- **WHEN** a relation contains a `relation` field not in `{serves, depends_on, refines}`
- **THEN** the command reports the invalid type and file path

#### Scenario: Missing relation fields detected
- **WHEN** a relation object lacks `target`, `relation`, or `rationale`
- **THEN** the command reports the missing field and file path

#### Scenario: Non-existent target detected
- **WHEN** a relation `target` references a file that does not exist
- **THEN** the command reports the broken reference and file path

### Requirement: CLI provides comprehensive help
The `gas write --help` output SHALL include usage examples, relation type semantics, target namespace format, and output behavior, sufficient for a subagent to construct correct command invocations without external documentation.

#### Scenario: Subagent reads help
- **WHEN** `gas write --help` is executed
- **THEN** the output includes all available flags
- **AND** the output includes an example with `--relations` JSON
- **AND** the output describes the stdout behavior (file path output)
