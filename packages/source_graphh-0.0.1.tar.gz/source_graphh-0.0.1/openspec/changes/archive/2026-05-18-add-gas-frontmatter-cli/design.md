## Context

All 29 existing idea files and 2 goal files have been migrated to a unified YAML frontmatter schema (`date` + `relations`) defined by the `typed-relations` spec. However, the `.claude/skills/record-idea/SKILL.md` template still generates ideas without frontmatter, and its ad-hoc markdown writing produces format inconsistencies (field ordering, quote style, empty-array vs null).

This change introduces a standalone CLI tool (`gas`) that becomes the single source of truth for frontmatter generation and validation. The `record-idea` skill delegates frontmatter creation to this tool, ensuring every new idea file is schema-compliant from creation.

## Goals / Non-Goals

**Goals:**
- Provide a deterministic CLI for generating frontmatter that conforms to the `typed-relations` spec
- Update the `record-idea` skill to use the CLI, eliminating frontmatter drift
- Provide a validation command to audit existing idea/goal files

**Non-Goals:**
- Modify the `typed-relations` schema or spec (this is a tooling change, not a schema change)
- Build dashboard, graph renderer, or other downstream analytics tools
- Automatic goal inference or alignment assessment (that belongs to `goal-aware-record-idea-skill`)
- Migrate existing idea body content (only frontmatter format is concerned)

## Decisions

### 1. Independent directory with proper Python package structure

**Rationale:** `src/source_graph/` is the core code-analysis package. Frontmatter tooling serves the meta-layer (project knowledge management), not the code-extraction domain. Keeping them separate avoids domain confusion and allows the GAS tooling to evolve independently.

**Structure:**
```
gas/
└── src/
    └── gas/
        ├── __init__.py
        ├── idea_frontmatter.py
        └── cli.py
```

The `gas/src/gas/` nesting follows standard Python package conventions. `pyproject.toml` adds `gas/src` to `pythonpath` and registers `gas = "gas.cli:main"` as a console script entry point, enabling `gas write ...` invocation.

**Alternative considered:** `scripts/idea_frontmatter.py` — rejected because scripts are typically one-off, while this is persistent infrastructure that will be invoked by the skill on every idea creation. Flat `gas/src/{files}` — rejected because it creates an invalid Python package (no `__init__.py`, modules exposed at top-level namespace).

### 2. CLI interface instead of Python API

**Rationale:** The `record-idea` skill delegates work to subagents. Subagents have Shell access and can invoke CLI commands. A CLI is more robust than requiring subagents to import Python modules (environment/path uncertainty).

**Design detail:** The `write` command does NOT take a file path. Instead, it takes `--date` and `--title`, generates the kebab-cased filename (`ideas/<date>--<kebab-title>.md`), writes only the frontmatter, and prints the path to stdout.

### 3. `relations: []` as the default (not `null`)

**Rationale:** The `typed-relations` spec explicitly states `relations` is an array. An empty array `[]` is the minimal valid value. While `null` semantically means "not yet assessed," the spec does not allow `null` for this field. The skill will default to `[]` and let goal-aware workflows populate relations later.

### 4. PyYAML with custom SafeDumper for deterministic output

**Rationale:** ruamel.yaml preserves comments and formatting (useful for editing), but we are generating new files where formatting must be deterministic. After experimentation, a custom `yaml.SafeDumper` with an overridden `represent_mapping` method provides precise control over output formatting.

**Implementation approach:**
- Subclass `yaml.SafeDumper`
- Override `represent_mapping` to emit keys as unquoted scalars and string values as double-quoted scalars
- Override sequence representation to emit empty lists in flow style (`[]`) and non-empty lists in block style with correct indentation
- Let PyYAML handle all escaping logic (quotes, backslashes, unicode, etc.) rather than manual string replacement

**Output rules:**
- Field order: `date`, then `relations`
- Keys: unquoted plain scalars (`style=None`)
- String values: always double-quoted (`style='"'`)
- `relations`: empty → `[]`; with items → sorted by `relation` type first, then `target` alphabetically
- No extra blank lines inside frontmatter

**Key nuance — `style=None` vs `style='"'`: **
In the custom `represent_mapping`, keys are emitted with `ScalarNode(..., style=None)`. This tells PyYAML's emitter to decide whether quotes are needed based on YAML plain-scalar rules. For simple identifiers like `date` or `relations`, the result is unquoted. For hypothetical future keys containing spaces (e.g., `relate to`), `style=None` would automatically produce `"relate to"` — still valid YAML. This is safer than a global `add_representer(str, ...)` which blindly quotes everything including keys.

String values, however, use `style='"'` to force double quotes regardless of content, ensuring deterministic output for all values.

**Why not manual string construction?**
Manual concatenation (`lines.append(f'date: "{value}"')`) works for the current minimal schema but requires re-implementing YAML escaping for every edge case (quotes, backslashes, unicode control characters, multiline strings). PyYAML's built-in emitter is battle-tested and will correctly handle any future schema extensions without additional escaping logic.

### 5. `write` command writes frontmatter only, body is appended by caller

**Rationale:** The `record-idea` skill template includes dynamic body sections (Description, Motivation, Notes, etc.) that vary per idea. The CLI should not own body content generation. It creates the file with frontmatter only; the subagent appends body content via `WriteFile` (append mode).

**Critical UX detail:** The skill documentation and subagent prompt must explicitly use the word **"append"** (not "write") and include a clear warning that the file already contains frontmatter. The subagent prompt should provide a concrete `WriteFile(mode="append")` example to prevent accidental overwrites.

## Risks / Trade-offs

- **[Risk]** Subagents must learn the new workflow (call CLI first, then append body). Existing muscle memory of "construct full markdown and WriteFile" will break.
  → **Mitigation:** Update SKILL.md with explicit step-by-step workflow and example subagent prompt.

- **[Risk]** CLI depends on the project having a Python environment with PyYAML installed.
  → **Mitigation:** Use the project's existing `.venv` (already managed by `uv`). Add PyYAML to project dependencies if not present.

- **[Risk]** If `--title` contains characters that don't kebab-case cleanly, filename generation may produce unexpected results.
  → **Mitigation:** Document the kebab-case transformation in `--help`. Implementation: lowercase, replace spaces/special chars with `-`, collapse multiple dashes.

## Migration Plan

No migration needed for existing files — this is an additive tool. Existing idea/goal files remain valid. The `validate` command can optionally be run against them to verify compliance.

## Open Questions

1. Should the `validate` command be added to CI (e.g., GitHub Actions) to prevent invalid frontmatter from being committed?
2. Should the CLI support an `update` command to re-format existing files (useful if output rules evolve)?
