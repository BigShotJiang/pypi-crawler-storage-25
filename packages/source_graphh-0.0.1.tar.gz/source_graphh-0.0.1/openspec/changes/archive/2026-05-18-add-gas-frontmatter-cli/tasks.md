## 1. Infrastructure Setup

- [x] 1.1 Create `gas/src/gas/` directory structure with `__init__.py`
- [x] 1.2 Add PyYAML to project dependencies (check if already present, add if not)
- [x] 1.3 Add `gas/src` to `pythonpath` in `pyproject.toml` and register `gas` entry point
- [x] 1.4 Verify `gas` module can be executed via `python -m gas` and `gas write --help`

## 2. Core Frontmatter Library

- [x] 2.1 Implement `IdeaFrontmatter` and `IdeaRelation` dataclasses in `gas/src/idea_frontmatter.py`
- [x] 2.2 Implement `parse()` function to read frontmatter from markdown files
- [x] 2.3 Implement `write_frontmatter()` function using PyYAML custom `SafeDumper` (unquoted keys, double-quoted string values, flow-style empty lists, sorted relations)
- [x] 2.4 Implement `validate()` function with all validation rules (date format, relation fields, relation type enum, target syntax, target file existence)
- [x] 2.5 Implement `kebab_case()` utility for filename generation from title

## 3. CLI Interface

- [x] 3.1 Implement `write` subcommand (`--date`, `--title`, `--relations` flags, stdout path output, filename collision handling)
- [x] 3.2 Implement `validate` subcommand (scan `ideas/` and `ideas/goals/`, report violations, exit codes)
- [x] 3.3 Implement comprehensive `--help` output for `write` subcommand (usage, examples, relation type semantics, target namespace format)
- [x] 3.4 Add `--help` for `validate` subcommand

## 4. Tests

- [x] 4.1 Add roundtrip tests for `parse()` → `write_frontmatter()`
- [x] 4.2 Add validation rule tests (valid/invalid date, relation types, missing fields, broken targets)
- [x] 4.3 Add CLI write tests (filename generation, collision handling, relations sorting)
- [x] 4.4 Add CLI validate tests (valid directory, invalid files, exit codes)

## 5. Skill Integration

- [x] 5.1 Update `.claude/skills/record-idea/SKILL.md` template to remove frontmatter block
- [x] 5.2 Update SKILL.md workflow section: add `gas write` CLI invocation step, followed by `WriteFile(mode="append")` for body content, with explicit "do not overwrite" warning
- [x] 5.3 Update subagent prompt template to use `gas write --help` for guidance
- [x] 5.4 Test the updated skill with a sample idea creation

## 6. Verification & Cleanup

- [x] 6.1 Run `gas validate` against all existing `ideas/*.md` and `ideas/goals/*/goal.md` files
- [x] 6.2 Fix any validation errors in existing files (if found)
- [x] 6.3 Update `ideas/2026-05-15--idea-structured-frontmatter.md` Outcome section to mark as Implemented
- [x] 6.4 Archive the change via `openspec archive`
