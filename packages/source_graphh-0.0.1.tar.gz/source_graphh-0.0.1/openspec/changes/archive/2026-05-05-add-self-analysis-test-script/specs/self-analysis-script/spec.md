## ADDED Requirements

### Requirement: Self-analysis script exists and is executable
The project SHALL provide a bash script at `scripts/run-self-analysis.sh` that runs `source-graph` against the project's own Python source files.

#### Scenario: Developer runs the script
- **WHEN** the developer executes `./scripts/run-self-analysis.sh` from the project root
- **THEN** the script runs successfully and produces output in `build/output/`

### Requirement: Output directory is cleaned before each run
The script SHALL remove and recreate `build/output/` before invoking the CLI to ensure no stale artifacts remain from previous runs.

#### Scenario: Second run after output exists
- **GIVEN** `build/output/` contains files from a previous run
- **WHEN** the developer runs the script again
- **THEN** old files are removed and new files are generated

### Requirement: Script invokes CLI with correct parameters
The script SHALL invoke `python3 -m source_graph.cli` with all `.py` files under `src/source_graph/` and output to `build/output/`.

#### Scenario: Script generates report
- **WHEN** the script executes the CLI invocation
- **THEN** `build/output/source_graph.db` is created
- **AND** `build/output/report.html` is created

### Requirement: Generated artifacts are ignored by git
The project SHALL include a `.gitignore` file that excludes `build/output/` and common Python artifacts.

#### Scenario: Git status shows no untracked build artifacts
- **GIVEN** the script has been run and `build/output/` exists
- **WHEN** the developer runs `git status`
- **THEN** `build/output/` and its contents are not listed as untracked files
