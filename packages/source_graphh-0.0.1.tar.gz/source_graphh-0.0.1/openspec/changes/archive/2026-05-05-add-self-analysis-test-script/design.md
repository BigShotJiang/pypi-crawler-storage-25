## Context

The project has a working CLI (`source-graph`) that can extract structure and dependencies from Python files and render them as HTML. However, there is no convenient way for developers to run the tool against its own codebase during development. Manual CLI invocation is required, and stale output artifacts can accumulate across runs.

## Goals / Non-Goals

**Goals:**
- Provide a single-command way to run `source-graph` on the project's own source files
- Ensure clean, reproducible output by clearing the output directory before each run
- Keep generated artifacts out of version control
- Use development-friendly invocation (`python3 -m`) so code changes are picked up without reinstalling the package

**Non-Goals:**
- Modifying the CLI to accept directory arguments (deferred to future change, see `ideas/2026-05-05--cli-support-directory-argument.md`)
- Adding watch/continuous regeneration mode
- Running pytest as part of the analysis script
- Cross-platform compatibility beyond Unix-like systems (macOS/Linux)

## Decisions

**Single run vs. separate runs per dimension**
- **Decision:** Run the CLI once, output to a single directory.
- **Rationale:** The `HTMLPresenter` already embeds data for all dimensions and provides a browser-side selector. Running once avoids redundant extraction and simplifies the script. The `--dimension` flag only controls the default view.

**Bash vs. Python script**
- **Decision:** Use bash.
- **Rationale:** The script is a thin orchestration wrapper around CLI calls. Bash is sufficient, familiar to the team, and avoids adding a Python dependency for a simple wrapper.

**Input file selection: `src/source_graph/*.py` vs. recursive**
- **Decision:** Use `src/source_graph/*.py` (non-recursive glob).
- **Rationale:** Currently all source files are in the top-level package directory. This is the simplest correct expression. Future expansion to sub-packages is deferred until the CLI supports directory arguments.

**Output directory: `build/output/`**
- **Decision:** Use `build/output/` and clear only this directory.
- **Rationale:** Keeps build artifacts in a conventional location. `build/` itself is not removed to avoid disrupting other potential build tools.

**`.gitignore` scope**
- **Decision:** Create a comprehensive `.gitignore` with Python-standard entries plus `build/output/`.
- **Rationale:** The project currently lacks a `.gitignore`. Creating one now prevents accidental commits of common artifacts (pycache, eggs, venvs) in addition to the script output.

## Risks / Trade-offs

| Risk | Mitigation |
|------|-----------|
| Script fails silently if source files are moved/renamed | The script uses `set -euo pipefail` to fail fast on errors |
| `src/source_graph/*.py` breaks if sub-packages are added | Documented limitation; deferred to CLI directory support |
| Bash not available on all developer machines | Project is currently macOS/Linux focused; documented non-goal |
