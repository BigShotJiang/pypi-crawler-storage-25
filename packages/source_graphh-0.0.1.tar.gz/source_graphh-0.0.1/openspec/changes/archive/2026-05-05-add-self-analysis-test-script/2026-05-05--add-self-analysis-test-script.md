# Idea: Add Self-Analysis Test Script

**Date:** 2026-05-05
**Status:** New
**Context:** The project needs a convenient way to run source-graph against its own codebase to validate behavior and generate real output.

## Description

Add a test/development script that runs the `source-graph` CLI against the current project's own Python source files. The script should:

1. Collect all `.py` files under `src/source_graph/`
2. Run the CLI for both `structure` and `dependencies` dimensions
3. Output reports to `build/output/`
4. **Clear the output directory before each run** to prevent stale artifacts from polluting results
5. The `build/output/` directory should be **gitignored** to avoid committing generated reports

## Example / Use case

```bash
./scripts/run-self-analysis.sh
# → build/output/structure/report.html
# → build/output/dependencies/report.html
```

This makes it trivial to verify that changes to extractors, presenters, or the CLI work correctly on real data.

## Motivation

- **Dogfooding**: The best way to validate source-graph is to use it on itself
- **Visual regression**: Quickly see if rendering or extraction changes affect output
- **Developer UX**: One command to generate both dimensions instead of manual CLI invocations
- **Clean builds**: Clearing output prevents confusion from stale SQLite/HTML artifacts

## Potential Implementation

1. Create `scripts/run-self-analysis.sh` (bash)
   - Detect project root from script location
   - `rm -rf build/output/ && mkdir -p build/output/`
   - Run CLI twice with `--dimension structure` and `--dimension dependencies`
2. Add `build/output/` to `.gitignore`

Alternative: A Python script using `subprocess.run` and `pathlib` could be more cross-platform.

## Related Areas

- `src/source_graph/cli.py` — the CLI entry point
- `pyproject.toml` — package configuration and console script entry point

## Notes

- Should the script use the installed `source-graph` command or `python3 -m source_graph.cli`?
  - The latter is safer during development before reinstalling the package
- Consider adding a `--watch` mode in the future for continuous regeneration during development
- Could also run pytest before analysis to ensure the code is in a working state
