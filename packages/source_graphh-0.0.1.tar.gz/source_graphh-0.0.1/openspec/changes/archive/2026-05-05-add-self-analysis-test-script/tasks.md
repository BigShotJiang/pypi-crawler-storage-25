## 1. Project Hygiene

- [x] 1.1 Create `.gitignore` with Python-standard ignores and `build/output/`

## 2. Self-Analysis Script

- [x] 2.1 Create `scripts/` directory
- [x] 2.2 Create `scripts/run-self-analysis.sh` with clean output directory, CLI invocation, and error handling
- [x] 2.3 Make `scripts/run-self-analysis.sh` executable (`chmod +x`)

## 3. Validation

- [x] 3.1 Run the script and verify `build/output/source_graph.db` and `build/output/report.html` are generated
- [x] 3.2 Run `git status` and confirm `build/output/` is ignored
- [x] 3.3 Run the script a second time and confirm stale artifacts are cleared
