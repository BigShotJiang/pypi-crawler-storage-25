## Why

The project needs a convenient way to run `source-graph` against its own codebase to validate behavior, verify extraction and rendering changes, and generate real output for visual inspection. Currently, developers must manually construct CLI invocations for each dimension.

## What Changes

- Add `scripts/run-self-analysis.sh` — a bash script that runs `source-graph` against the project's own Python source files
- Create `.gitignore` with Python-standard ignores plus `build/output/`
- The script:
  - Clears `build/output/` before each run to prevent stale artifacts
  - Runs the CLI once with `src/source_graph/*.py` as input
  - Outputs to `build/output/`
  - Uses `python3 -m source_graph.cli` for development convenience

## Capabilities

### New Capabilities
- `self-analysis-script`: A developer-facing convenience script for dogfooding the tool on its own codebase

### Modified Capabilities
<!-- No existing capability requirements are changing. This is a pure addition. -->

## Impact

- New `scripts/` directory at project root
- New `.gitignore` at project root
- `build/output/` directory created at runtime (gitignored)
- No changes to core library code, CLI behavior, or public APIs
