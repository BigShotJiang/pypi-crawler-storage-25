## Context

`presenter.py` is 1175 lines: 620 lines of JavaScript and 180 lines of CSS embedded in Python f-strings. Every frontend change risks f-string syntax errors (JS `${}` conflicts with Python `{}`). The file is unlintable, unformattable, and unapproachable for anyone who does not write Python.

The project goal (`code-intuition`) explicitly rejects the "pure static report generator" pattern. `serve` mode already exists and works. The natural evolution is to make `serve` the sole consumption path and separate the frontend from the backend entirely.

## Goals / Non-Goals

**Goals:**
- Eliminate `presenter.py` and the `present` CLI command.
- Move all frontend code (HTML, JS, CSS) into standalone files under `src/source_graph/web/`.
- Serve the frontend via FastAPI with static file serving.
- Provide a single REST endpoint (`GET /api/data`) that returns all pre-built dimension data.
- Preserve 100% of existing rendering behavior (tree, map, graph views, tooltips, interactions).
- Migrate data-building logic (`_build_*` methods) to a clean `data_builder.py` module.

**Non-Goals:**
- Do not redesign the API schema beyond the minimal "all data at once" shape.
- Do not add new visualization features or new dimensions.
- Do not introduce a build step (webpack, bundler) for the frontend.
- Do not change the `extract` CLI command or the database schema.
- Do not add authentication, CORS, or multi-user support.

## Decisions

### Decision: Use FastAPI instead of extending `http.server`

**Rationale:** `http.server` would require manually implementing MIME types, path security, routing, and static file serving. FastAPI provides all of this with `StaticFiles` and clean route decorators. The dependency cost (~15 transitive packages) is acceptable for a project whose goal includes evolving toward a full API (Code Knowledge Graph API).

**Alternative considered:** Extending `http.server.BaseHTTPRequestHandler` to add file routing. Rejected because it produces brittle, hard-to-test code and blocks future API evolution.

### Decision: Global variable for `db_path` instead of dependency injection

**Rationale:** The `serve` command is a single-user local CLI tool. A module-level `_db_path` variable is the simplest mechanism to pass the CLI argument into FastAPI route handlers. Dependency injection (FastAPI `Depends`) adds boilerplate without benefit in this context.

**Alternative considered:** FastAPI `app.state` and `Depends`. Rejected as over-engineering for a local server.

### Decision: Single endpoint `GET /api/data` returning all dimensions

**Rationale:** The frontend currently consumes all data at page load time (embedded JSON). Changing to a single endpoint minimizes both backend and frontend changes. The frontend only needs to replace `const graphData = {...injected...}` with `const payload = await fetch('/api/data').then(r => r.json())`.

**Alternative considered:** Per-dimension endpoints (`GET /api/data?dimension=X`). Rejected because it would require frontend restructuring and offers no immediate benefit.

### Decision: Package frontend assets inside `src/source_graph/web/`

**Rationale:** CLI tools distributed via `pip` must include their resources inside the Python package so `importlib.resources` can locate them regardless of installation path. Using `web/` instead of `static/` avoids confusion with web-framework terminology.

**Alternative considered:** Project-root `static/` directory with `MANIFEST.in` or hatchling `force-include`. Rejected because it complicates the build and creates fragile runtime path resolution.

### Decision: `data_builder.py` as pure functions, not methods on a class

**Rationale:** The existing `_build_*` methods only need a `store` argument. Extracting them as module-level pure functions eliminates the `HTMLPresenter` class entirely and makes them directly testable without instantiation.

**Alternative considered:** Keeping them as methods on a new `DataBuilder` class. Rejected because no state is needed beyond the `store` parameter.

## Risks / Trade-offs

| Risk | Mitigation |
|------|-----------|
| **Zero-dependency project now has 15+ transitive deps** | FastAPI is well-maintained, widely adopted, and aligns with the long-term API goal. If dep footprint becomes a concern later, can revisit `http.server` or `starlette` alone. |
| **Frontend no longer works when opened as a local file** | This is intentional — `present` is being removed. Users must use `serve`. Document this clearly in README. |
| **Tests heavily depend on string matching in HTML output** | `test_presenter.py` tests are being migrated to `test_data_builder.py` (assert on JSON structures) and `test_server.py` (assert on HTTP responses). String-based assertions are eliminated. |
| `importlib.resources` behavior differs between editable and installed packages | Verify via `pip install -e .` and `pip install .` that `resources.files("source_graph") / "web"` resolves correctly. Hatchling includes package data by default. |
| **FastAPI startup time** | Uvicorn startup adds ~200ms. Negligible for a dev tool. |
