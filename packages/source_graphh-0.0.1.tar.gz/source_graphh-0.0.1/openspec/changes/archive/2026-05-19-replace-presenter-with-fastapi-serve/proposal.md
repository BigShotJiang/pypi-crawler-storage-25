## Why

`presenter.py` has reached an architectural ceiling at 1175 lines — 620 lines of JavaScript and 180 lines of CSS are trapped inside Python f-strings, creating an escaping hell where every frontend change risks a SyntaxError. More fundamentally, `source-graph`'s goal (code-intuition) has explicitly committed to dynamic access over static report generation. The `present` command generates a self-contained HTML file that is unlintable, untestable, and blocks frontend evolution. We need to abolish this pattern entirely and move to a clean frontend-backend separation.

## What Changes

- **BREAKING**: Remove the `present` CLI subcommand. `source-graph serve` becomes the only way to view reports.
- **BREAKING**: Delete `src/source_graph/presenter.py` and the `HTMLPresenter` class. The 280 lines of data-building logic (`_build_tree_data`, `_build_dependency_data`, etc.) migrate to a new `data_builder.py` module.
- Replace `http.server`-based `server.py` with a FastAPI application (`server/` package) that serves:
  - `GET /` → `web/index.html` (static file)
  - `GET /static/*` → `web/app.js`, `web/style.css` (static files)
  - `GET /api/data` → JSON payload with all dimensions, source contents, and source paths
- Extract all frontend code from `presenter.py` into `src/source_graph/web/`:
  - `index.html` — pure static HTML, no template logic
  - `app.js` — the 620 lines of rendering logic, now loading data via `fetch('/api/data')`
  - `style.css` — the 180 lines of styles
- Migrate `tests/test_presenter.py` to `tests/test_data_builder.py` (testing data-building logic) and `tests/test_server.py` (testing API endpoints and static file serving).
- Add `fastapi` and `uvicorn` to project dependencies.

## Capabilities

### New Capabilities

- `api-driven-frontend`: The backend provides a single REST endpoint (`GET /api/data`) that returns all pre-built dimension data, source contents, and source paths as JSON. The frontend loads this data at runtime via `fetch()` instead of receiving it through server-side embedding.
- `frontend-backend-separation`: Frontend assets (HTML, JS, CSS) live as independent static files in `src/source_graph/web/`, served directly by the HTTP server without template rendering or dynamic generation.

### Modified Capabilities

- `serve-mode`: The serve command's implementation changes from `http.server` + `HTMLPresenter.render()` to FastAPI + static file serving + JSON API. The user-facing behavior (run `source-graph serve db` → open browser → see interactive report) remains unchanged, but the internal architecture and data flow are completely replaced.

## Impact

- **CLI**: `present` subcommand removed from `cli.py` and documentation.
- **Dependencies**: `fastapi` and `uvicorn` added to `pyproject.toml`.
- **Tests**: `test_presenter.py` deleted; present-related tests in `test_cli.py` removed or converted to serve tests.
- **File structure**: New `src/source_graph/web/` directory for frontend assets; new `src/source_graph/server/` package for FastAPI app; new `src/source_graph/data_builder.py` for data-building logic.
