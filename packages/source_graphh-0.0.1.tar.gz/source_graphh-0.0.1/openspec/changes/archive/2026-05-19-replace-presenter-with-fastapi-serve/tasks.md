## 1. Setup

- [x] 1.1 Add `fastapi` and `uvicorn` to `pyproject.toml` dependencies
- [x] 1.2 Create `src/source_graph/web/` directory
- [x] 1.3 Create `src/source_graph/server/` package directory with `__init__.py`

## 2. Extract Data-Building Logic

- [x] 2.1 Create `src/source_graph/data_builder.py` with `build_tree_data(store, dimension)` — migrate from `presenter.py._build_tree_data`
- [x] 2.2 Add `build_dependency_data(store, dimension)` — migrate from `presenter.py._build_dependency_data`
- [x] 2.3 Add `build_dependency_map_data(store, dimension)` — migrate from `presenter.py._build_dependency_map_data`
- [x] 2.4 Add `build_graph_data(store, dimension)` — migrate from `presenter.py._build_graph_data`
- [x] 2.5 Add `build_all_data(store)` — assembles the complete payload for `GET /api/data`
- [x] 2.6 Run `test_data_builder.py` (migrated from `test_presenter.py`) to verify all data-building logic

## 3. Extract Frontend Assets

- [x] 3.1 Create `src/source_graph/web/style.css` — extract all `<style>` content from `presenter.py`
- [x] 3.2 Create `src/source_graph/web/index.html` — pure static HTML with `<script src="/static/app.js">` and `<link rel="stylesheet" href="/static/style.css">`
- [x] 3.3 Create `src/source_graph/web/app.js` — extract all `<script>` content from `presenter.py`, add `async function init()` that fetches `/api/data` and assigns to global variables
- [x] 3.4 Verify `index.html` contains no template variables, no inline JS/CSS, and no embedded JSON

## 4. Implement FastAPI Server

- [x] 4.1 Create `src/source_graph/server/config.py` with module-level `_db_path` variable and `configure(db_path)` function
- [x] 4.2 Create `src/source_graph/server/app.py` with FastAPI app, `GET /api/data` endpoint, and `GET /` → `FileResponse(web/index.html)`
- [x] 4.3 Mount `/static` with `StaticFiles` pointing to `resources.files("source_graph") / "web"`
- [x] 4.4 Update `src/source_graph/server/__init__.py` to export the app
- [x] 4.5 Verify `source-graph serve` starts successfully and responds to `GET /`, `GET /static/app.js`, `GET /api/data`

## 5. Update CLI

- [x] 5.1 Remove `present_command` function and `present_parser` from `src/source_graph/cli.py`
- [x] 5.2 Update `serve_command` to use uvicorn + FastAPI app instead of `run_server` from old `server.py`
- [x] 5.3 Remove `from .presenter import HTMLPresenter` import from `cli.py`
- [x] 5.4 Delete `src/source_graph/server.py` (old http.server implementation)
- [x] 5.5 Delete `src/source_graph/presenter.py`

## 6. Migrate Tests

- [x] 6.1 Create `tests/test_data_builder.py` — migrate all `_build_*` tests from `test_presenter.py`
- [x] 6.2 Create `tests/test_server.py` — test `GET /api/data` returns valid JSON, test `GET /` returns HTML, test static files are served
- [x] 6.3 Update `tests/test_cli.py` — remove `test_present_subcommand_produces_report`, `test_present_missing_database_exits_nonzero`, `test_present_embeds_source_data`; add `test_serve_subcommand_starts_server`
- [x] 6.4 Delete `tests/test_presenter.py`
- [x] 6.5 Run full test suite `python -m pytest` and ensure all tests pass

## 7. Documentation

- [x] 7.1 Update `README.md` — remove `present` command documentation, update `serve` documentation to describe the new architecture
- [x] 7.2 Verify `source-graph --help` no longer shows `present`
- [x] 7.3 Run `source-graph extract src/ -o build/ && source-graph serve build/source_graph.db` manually and verify the report renders correctly in browser
