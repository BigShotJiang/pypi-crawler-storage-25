## ADDED Requirements

### Requirement: Backend provides a single data endpoint
The system SHALL provide a `GET /api/data` endpoint that returns a JSON object containing all dimension data, source contents, and source paths.

#### Scenario: API returns all dimensions
- **WHEN** a client sends `GET /api/data` to the running server
- **THEN** the server responds with `Content-Type: application/json`
- **THEN** the response body contains a `dimensions` object with an entry for every dimension in the database
- **THEN** each dimension entry contains a `type` field (either `"tree"` or `"dependency_graph"`) and a `data` field
- **THEN** the response body contains `sourceContents` mapping content hashes to source text
- **THEN** the response body contains `sourcePaths` as an array of path records

### Requirement: Frontend loads data via fetch
The frontend SHALL load its data by calling `fetch('/api/data')` during initialization, instead of receiving embedded JSON from server-side rendering.

#### Scenario: Page loads and fetches data
- **WHEN** a browser loads `GET /`
- **THEN** the served `index.html` loads `app.js`
- **THEN** `app.js` calls `fetch('/api/data')`
- **THEN** the response is parsed as JSON
- **THEN** the parsed data is assigned to `window.graphData`, `window.sourceContents`, and `window.sourcePaths`
- **THEN** the existing rendering logic executes using this data without modification

### Requirement: Data payload preserves existing structure
The JSON shape returned by `GET /api/data` SHALL match the structure previously embedded in the HTML by `HTMLPresenter.render()`, ensuring zero changes to frontend data consumption logic.

#### Scenario: Tree dimension data shape
- **WHEN** the `structure` dimension exists in the database
- **THEN** `GET /api/data` returns `dimensions.structure.type === "tree"`
- **THEN** `dimensions.structure.data` is an array of tree node objects with `id`, `name`, `kind`, `fqn`, `children`, and `collapsed` fields

#### Scenario: Dependency dimension data shape
- **WHEN** the `dependencies` dimension exists in the database
- **THEN** `GET /api/data` returns `dimensions.dependencies.type === "dependency_graph"`
- **THEN** `dimensions.dependencies.data.tree` contains `nodes`, `edges`, and `roots`
- **THEN** `dimensions.dependencies.data.map` contains `nodes` and `edges`
- **THEN** `dimensions.dependencies.data.graph` contains `nodes` and `edges`
