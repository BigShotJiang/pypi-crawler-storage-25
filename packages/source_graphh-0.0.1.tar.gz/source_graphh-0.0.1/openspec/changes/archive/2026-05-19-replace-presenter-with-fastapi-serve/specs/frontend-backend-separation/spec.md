## ADDED Requirements

### Requirement: Frontend assets live as independent static files
All frontend code (HTML, JavaScript, CSS) SHALL reside as standalone files inside `src/source_graph/web/` and SHALL NOT be generated or embedded by Python code at runtime.

#### Scenario: Directory structure
- **WHEN** the project is installed
- **THEN** `importlib.resources.files("source_graph") / "web"` resolves to a directory
- **THEN** that directory contains `index.html`, `app.js`, and `style.css`

#### Scenario: No server-side rendering
- **WHEN** the server handles `GET /`
- **THEN** it returns the contents of `web/index.html` without modification
- **THEN** no template engine is involved
- **THEN** no Python string interpolation occurs in the HTML response

### Requirement: Static files are served directly
The server SHALL serve `app.js` and `style.css` at `/static/app.js` and `/static/style.css` respectively, with correct `Content-Type` headers.

#### Scenario: Browser requests assets
- **WHEN** a browser loads `GET /` and parses `index.html`
- **THEN** the browser requests `/static/app.js` and `/static/style.css`
- **THEN** the server responds with `200 OK` and `Content-Type: application/javascript` or `text/css`
- **THEN** the response body contains the exact file contents

### Requirement: Frontend data access is abstracted
The frontend SHALL encapsulate data loading in a single function, making the future transition from embedded-JSON to fetch-based loading a one-line change.

#### Scenario: Data loading abstraction
- **WHEN** `app.js` initializes
- **THEN** it calls an `init()` function
- **THEN** `init()` fetches `/api/data` and assigns the result to global variables
- **THEN** all existing rendering functions consume those global variables
