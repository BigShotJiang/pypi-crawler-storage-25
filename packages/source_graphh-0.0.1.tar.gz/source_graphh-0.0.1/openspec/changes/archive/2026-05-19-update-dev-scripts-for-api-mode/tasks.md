## 1. Update run-self-analysis.sh

- [x] 1.1 Replace `present` command with `serve` in `scripts/run-self-analysis.sh`
- [x] 1.2 Add `--port` argument (e.g., 8080) and echo instructions to user
- [x] 1.3 Run script manually to verify it starts serve without errors

## 2. Update test-serve.sh

- [x] 2.1 Remove obsolete `/api/nodes` 404 test
- [x] 2.2 Add test for `GET /api/data` returning 200 and valid JSON with `dimensions` key
- [x] 2.3 Add test for `GET /static/app.js` returning 200 with JavaScript content-type
- [x] 2.4 Add test for `GET /static/style.css` returning 200 with CSS content-type
- [x] 2.5 Ensure script uses `.venv/bin/python` consistently
- [x] 2.6 Run script manually to verify all assertions pass
