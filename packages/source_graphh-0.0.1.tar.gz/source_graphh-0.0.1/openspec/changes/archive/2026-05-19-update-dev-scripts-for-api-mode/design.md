## Context

The `replace-presenter-with-fastapi-serve` change fundamentally altered how source-graph serves reports. Two convenience scripts in `scripts/` were left pointing to the old architecture.

## Goals / Non-Goals

**Goals:**
- Fix `run-self-analysis.sh` so it runs without errors
- Fix `test-serve.sh` so it validates the actual FastAPI routes

**Non-Goals:**
- No new features
- No changes to application code

## Decisions

### Decision: `run-self-analysis.sh` becomes a "start server" script

**Rationale:** Without `present`, the only way to view the report is `serve`. The script's purpose shifts from "generate and exit" to "extract then serve".

### Decision: Keep `test-serve.sh` as bash integration test

**Rationale:** Even though `pytest` + `TestClient` covers the Python layer, a bash script validates the CLI entry point and subprocess behavior (port binding, signal handling).

## Risks / Trade-offs

| Risk | Mitigation |
|------|-----------|
| Scripts drift again | Add a CI step that runs both scripts on every PR |
