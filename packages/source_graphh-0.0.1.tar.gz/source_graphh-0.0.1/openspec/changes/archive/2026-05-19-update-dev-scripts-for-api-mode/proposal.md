## Why

The `replace-presenter-with-fastapi-serve` change removed the `present` command and replaced the `http.server` backend with FastAPI. Two development scripts in `scripts/` still reference the old architecture and will fail or produce misleading results: `run-self-analysis.sh` calls the deleted `present` command, and `test-serve.sh` tests a non-existent `/api/nodes` endpoint instead of the new `/api/data` and `/static/*` routes.

## What Changes

- Update `scripts/run-self-analysis.sh`: replace `present` with `serve` (launches server and blocks until Ctrl+C)
- Update `scripts/test-serve.sh`:
  - Remove the obsolete `/api/nodes` 404 test
  - Add test for `GET /api/data` returning valid JSON with `dimensions`, `sourceContents`, and `sourcePaths`
  - Add tests for `GET /static/app.js` and `GET /static/style.css`
  - Use the project's `.venv/bin/python` consistently instead of mixing `python3` and `.venv/bin/python`

## Capabilities

### New Capabilities
- *(none — this is a maintenance change)*

### Modified Capabilities
- *(none — no spec-level behavior changes)*

## Impact

- `scripts/run-self-analysis.sh` — behavior changes from "generate file then exit" to "start server and block"
- `scripts/test-serve.sh` — test coverage updated to match FastAPI routes
