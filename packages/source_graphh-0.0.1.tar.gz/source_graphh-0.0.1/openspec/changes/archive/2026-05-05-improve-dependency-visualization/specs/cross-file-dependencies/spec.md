## MODIFIED Requirements

### Requirement: HTML report renders dependencies as interactive graph
The system SHALL render the `dependencies` dimension as an interactive dependency graph using structured data (`type: "dependency_graph"`), distinct from the tree view used for the `structure` dimension. The graph SHALL support collapsible nodes and tooltips using the same UI primitives as the structure tree view.

#### Scenario: Simple dependency graph
- **GIVEN** `a.py` imports `b.py` and `b.py` imports `os`
- **WHEN** the HTML report is rendered for the `dependencies` dimension
- **THEN** the output contains an interactive graph showing `a.py` with a dependency on `b.py`, and `b.py` with a dependency on `os` marked as external

#### Scenario: Graph with multiple branches
- **GIVEN** `a.py` imports both `b.py` and `c.py`
- **WHEN** the HTML report is rendered for the `dependencies` dimension
- **THEN** the graph shows both branches from `a.py` in alphabetical order

#### Scenario: Circular dependency annotation
- **GIVEN** `a.py` imports `b.py`, `b.py` imports `c.py`, and `c.py` imports `a.py`
- **WHEN** the HTML report is rendered for the `dependencies` dimension
- **THEN** the graph annotates the cycle (e.g., `[circular]`)

## ADDED Requirements

### Requirement: External dependencies can be toggled in the HTML report
The system SHALL provide a "Show External Dependencies" toggle in the HTML report header when viewing the `dependencies` dimension. The toggle SHALL default to ON. When the toggle is OFF, external module nodes and any downstream chains reachable through them SHALL be hidden from the graph.

#### Scenario: External dependencies visible by default
- **GIVEN** `a.py` imports `b.py` and `os`
- **WHEN** the HTML report is rendered for the `dependencies` dimension
- **THEN** both `b.py` and `os` are visible in the graph
- **AND** the "Show External Dependencies" toggle is checked

#### Scenario: Hiding external dependencies
- **GIVEN** `a.py` imports `b.py` and `os`
- **WHEN** the user unchecks "Show External Dependencies"
- **THEN** `os` is hidden from the graph
- **AND** `b.py` remains visible

#### Scenario: External dependency downstream is hidden
- **GIVEN** `a.py` imports `json`, and `json` (external) imports `decoder` (external)
- **WHEN** the user unchecks "Show External Dependencies"
- **THEN** both `json` and `decoder` are hidden from the graph

### Requirement: Root file nodes are sorted by internal dependency count
The system SHALL sort root file nodes in the `dependencies` dimension by their count of outgoing edges to internal (non-external) nodes, in ascending order. Files with fewer internal dependencies SHALL appear first. Child nodes within each branch SHALL be sorted alphabetically and SHALL NOT be reordered by dependency count.

#### Scenario: Leaf file appears first
- **GIVEN** `c.py` has no internal dependencies, `a.py` imports `b.py` and `c.py`, and `b.py` imports `os`
- **WHEN** the HTML report is rendered for the `dependencies` dimension
- **THEN** the root order is `c.py` (0 internal deps), then `a.py` (2 internal deps)
- **AND** `b.py` does not appear as a root because it is a child of `a.py`

#### Scenario: Child nodes are alphabetical
- **GIVEN** `a.py` imports `z.py`, `m.py`, and `b.py`
- **WHEN** `a.py` is expanded in the graph
- **THEN** the child dependencies appear in alphabetical order: `b.py`, `m.py`, `z.py`
