## 1. Backend: Restructure dependency data output

- [x] 1.1 Change `_build_dependency_data` in `presenter.py` to return a dict with `nodes`, `edges`, and `roots` instead of an ASCII string
- [x] 1.2 Compute internal out-degree for each node (count of edges where target is not external) and include it in node data for root sorting
- [x] 1.3 Ensure child nodes are collected in sorted order (alphabetical by target name)

## 2. Frontend: Add dependency graph rendering and toggle

- [x] 2.1 Update frontend `renderDimension` to handle `type: "dependency_graph"` alongside existing `"tree"` and `"ascii"`
- [x] 2.2 Implement `renderDependencyGraph` function that renders structured dependency data using collapsible tree UI (reuse existing tree primitives)
- [x] 2.3 Add "Show External Dependencies" toggle checkbox to the header, visible only when `dependencies` dimension is active, default checked
- [x] 2.4 Implement toggle logic: when unchecked, filter out nodes with `is_external: true` and any downstream children reachable only through external nodes

## 3. Frontend: Implement sorting

- [x] 3.1 Sort root nodes by `internal_out_degree` ascending before rendering
- [x] 3.2 Ensure non-root child nodes are displayed in alphabetical order

## 4. Tests and verification

- [x] 4.1 Update `test_presenter.py` to assert on new `dependency_graph` structured output instead of ASCII string
- [x] 4.2 Add test verifying root order is sorted by internal dependency count
- [x] 4.3 Run full test suite (`pytest`) and ensure all tests pass
