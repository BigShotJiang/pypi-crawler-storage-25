## Why

The current `dependencies` dimension visualization has two usability issues: (1) external dependencies are always shown with no way to filter them out, cluttering the view when users want to focus on internal code relationships; and (2) file nodes are displayed in alphabetical order, making it hard to identify which files are the most independent (leaf-like) versus heavily dependent on others.

## What Changes

- **BREAKING**: The `dependencies` dimension output format changes from a plain ASCII string (`type: "ascii"`) to structured data (`type: "dependency_graph"`), enabling frontend interactivity.
- Add a frontend toggle "Show External Dependencies" (default: ON) that filters out external module nodes and their downstream chains when turned OFF.
- Root file nodes in the `dependencies` dimension are sorted by internal out-degree (ascending), so files with fewer internal dependencies appear first (leaf-priority ordering).
- Child dependency nodes are sorted alphabetically for stable, predictable display.

## Capabilities

### New Capabilities
- *(none — changes are presentation-layer enhancements to existing capability)*

### Modified Capabilities
- `cross-file-dependencies`: The HTML rendering requirement changes from a static ASCII `<pre>` block to an interactive dependency graph with toggleable external dependency filtering and leaf-priority root ordering.

## Impact

- `src/source_graph/presenter.py`: `_build_dependency_data()` output format changes; frontend JS rendering logic updates.
- `tests/test_presenter.py`: Tests for `dependencies` dimension rendering will need updates to match new structured output and behavior.
- No changes to `cli.py`, extractors, models, or store.
