## Context

The `dependencies` dimension is currently rendered as a static ASCII string inside a `<pre>` block. The backend (`_build_dependency_data`) performs DFS traversal, marks external modules with `[external]`, sorts roots alphabetically, and returns a single concatenated string. The frontend receives this string opaquely and cannot manipulate it.

This design blocks two usability improvements: filtering external dependencies at view time, and ordering files by their coupling to other internal files.

## Goals / Non-Goals

**Goals:**
- Enable frontend toggling of external dependency visibility in the `dependencies` dimension.
- Sort root file nodes by internal out-degree ascending (leaf-priority ordering).
- Keep child nodes in stable alphabetical order.
- Separate data generation from presentation so the frontend controls rendering logic.

**Non-Goals:**
- No new CLI flags or options.
- No changes to extractors, models, store, or the `structure` dimension rendering.
- No backend-side filtering or sorting toggles (all interactivity lives in the frontend).

## Decisions

### 1. Structured data replaces ASCII string for `dependencies` dimension

**Decision**: Change `_build_dependency_data` to return a dict `{"nodes": [...], "edges": [...]}` instead of an ASCII string. The frontend receives this dict and renders it as an interactive tree-like view.

**Rationale**: Plain text cannot be filtered or re-sorted client-side. Structured data is necessary for both the toggle and the ordering feature.

**Alternative considered**: Keep ASCII and add a backend flag (CLI option) to control filtering. Rejected because it requires regenerating HTML for every view preference and mixes data with presentation.

### 2. External dependency toggle is frontend-only, default ON

**Decision**: The backend always emits the full graph including external nodes. A checkbox in the HTML header controls visibility via JavaScript.

**Rationale**: Data/view separation keeps the backend simple. Users can switch the toggle without re-running the tool.

**When OFF**: External nodes and any downstream chains reachable only through external nodes are pruned from the rendered tree. Internal nodes that happen to be children of external nodes are also hidden because their only visible path goes through the external node.

### 3. Leaf-priority ordering for root nodes only

**Decision**: Root nodes (files that have outgoing `dependencies` relations) are sorted by their count of outgoing edges to **internal** nodes only. Nodes with fewer internal dependencies appear first. Child nodes are sorted alphabetically and are not reordered by out-degree.

**Rationale**: "Dependency少的文件" was clarified to mean files that depend on few other internal files (leaf-like, bottom of the dependency pyramid). Sorting only roots keeps the tree structure predictable—once you expand a file, its children stay in a fixed, browsable order.

### 4. Render dependencies as an interactive tree view, not `<pre>`

**Decision**: The frontend renders `dependencies` using the same collapsible tree UI primitives already used for the `structure` dimension, rather than a `<pre>` ASCII block.

**Rationale**: Reusing existing UI components reduces frontend code duplication and gives users a consistent interaction model (toggle, collapse, tooltips).

## Risks / Trade-offs

| Risk | Mitigation |
|------|------------|
| **BREAKING change** to `_build_dependency_data` return type | Update `test_presenter.py` tests that assert on `dependencies` output. Document the change in proposal. |
| Frontend bundle size / complexity | The change adds one toggle and reuses existing tree rendering logic; no new libraries. |
| Users who preferred the compact ASCII view | The tree view is slightly more verbose but more interactive. No option to revert to ASCII is provided (out of scope). |
| Circular dependency rendering | The existing DFS circular guard (`[circular]`) is preserved in the frontend traversal logic. |

## Open Questions

- *(none — all design points were clarified during exploration)*
