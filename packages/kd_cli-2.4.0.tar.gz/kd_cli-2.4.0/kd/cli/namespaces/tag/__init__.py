"""Tag namespace: /tag

Commands: list, show, create, rename, delete, add, remove, issues, articles
API layer: YouTrack REST API (/api/tags, /api/issues/*/tags, /api/articles/*/tags)
"""

from __future__ import annotations

import sys
from typing import Any, Literal

from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.confirm import require_confirm
from kd.cli.core.namespaces import Namespace
from kd.cli.core.option_registry import (
    OptionDeclaration,
    OptionLayer,
    ResolvedOptions,
    limit_option,
    project_option,
)
from kd.exceptions import ValidationError
from kd.models import Article, Issue, Tag
from kd.primer import load_primer


def _tag_to_row(tag: Tag) -> dict[str, Any]:
    """Convert a Tag to a flat dict for table output."""
    return {
        "name": tag.name,
        "owner": tag.owner.name if tag.owner else "",
        "color": tag.color.id if tag.color else "",
        "untag_on_resolve": tag.untag_on_resolve,
    }


def _tag_to_detail(tag: Tag) -> dict[str, Any]:
    """Convert a Tag to a detailed dict for show output."""
    result: dict[str, Any] = {
        "name": tag.name,
        "owner": tag.owner.name if tag.owner else "",
        "untag_on_resolve": tag.untag_on_resolve,
    }
    if tag.color:
        result["color"] = tag.color.id
        if tag.color.background:
            result["background"] = tag.color.background
        if tag.color.foreground:
            result["foreground"] = tag.color.foreground
    return result


def _issue_to_row(issue: Issue) -> dict[str, Any]:
    """Convert a tagged Issue to a flat dict for table output."""
    return {
        "id": issue.id_readable,
        "summary": issue.summary,
        "project": issue.project.name if issue.project else "",
    }


def _article_to_row(article: Article) -> dict[str, Any]:
    """Convert a tagged Article to a flat dict for table output."""
    return {
        "id": article.id_readable,
        "summary": article.summary,
        "project": article.project.name if article.project else "",
    }


# --- Tag Commands ---


class TagListCommand(Command):
    """List tags.  Optional prefix/namespace filter is query-backed (cheap)."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List tags",
            requires_client=True,
            usage="kd /tag list [--prefix P | --namespace N] [--limit N]",
            examples=[
                "kd /tag list",
                "kd /tag list --limit 100",
                "kd /tag list --prefix kind:",
                "kd /tag list --namespace component",
            ],
            see_also=["/tag show", "/tag entities"],
        )

    def _register_options(self) -> None:
        self.register_option(limit_option())
        self.register_option(
            OptionDeclaration(
                name="prefix",
                layer=OptionLayer.COMMAND,
                help_text="Filter tags by name prefix (query-backed; e.g. 'kind:')",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="namespace",
                layer=OptionLayer.COMMAND,
                help_text="Shorthand for --prefix NAME: (adds the trailing colon)",
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        limit = options.command.get("limit", 50)
        prefix_opt = options.command.get("prefix")
        namespace_opt = options.command.get("namespace")
        if prefix_opt is not None and namespace_opt is not None:
            raise ValidationError("--prefix and --namespace are mutually exclusive")
        prefix: str | None
        if namespace_opt is not None:
            prefix = f"{namespace_opt}:"
        else:
            prefix = prefix_opt
        tags, cap_hit = client.tags.list(top=limit, prefix=prefix)
        if cap_hit:
            print(
                f"Warning: tag scan stopped at {limit * 10} pages without exhausting; "
                "results may be incomplete. Narrow the prefix or raise --limit.",
                file=sys.stderr,
            )
        return [_tag_to_row(t) for t in tags]


class TagShowCommand(Command):
    """Show tag details."""

    def __init__(self) -> None:
        super().__init__(
            "show",
            "Show tag details",
            requires_client=True,
            usage="kd /tag show TAG_NAME",
            examples=["kd /tag show sprint-47"],
            see_also=["/tag list", "/tag issues"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /tag show TAG_NAME")
        tag = client.tags.get(args[0])
        return _tag_to_detail(tag)


class TagCreateCommand(Command):
    """Create a tag."""

    def __init__(self) -> None:
        super().__init__(
            "create",
            "Create a tag",
            requires_client=True,
            usage="kd /tag create TAG_NAME",
            examples=['kd /tag create "sprint-47"'],
            see_also=["/tag list", "/tag delete"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /tag create TAG_NAME")
        tag = client.tags.create(args[0])
        return _tag_to_detail(tag)


class TagRenameCommand(Command):
    """Rename a tag."""

    def __init__(self) -> None:
        super().__init__(
            "rename",
            "Rename a tag",
            requires_client=True,
            usage="kd /tag rename TAG_NAME NEW_NAME",
            examples=['kd /tag rename sprint-47 "sprint-48"'],
            see_also=["/tag show"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if len(args) < 2:
            raise ValidationError("Usage: kd /tag rename TAG_NAME NEW_NAME")
        tag = client.tags.rename(args[0], args[1])
        return _tag_to_detail(tag)


class TagDeleteCommand(Command):
    """Delete a tag."""

    def __init__(self) -> None:
        super().__init__(
            "delete",
            "Delete a tag",
            requires_client=True,
            usage="kd /tag delete TAG_NAME",
            examples=["kd /tag delete sprint-47 --confirm"],
            see_also=["/tag list", "/tag create"],
        )
        self.register_option(
            OptionDeclaration(
                name="confirm",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text=(
                    "Required — tag delete is not recoverable from Deleted "
                    "Items (tag membership is lost across all entities)"
                ),
                hidden_from_reference=True,
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /tag delete TAG_NAME")
        name = args[0]
        require_confirm(
            confirmed=bool(options.command.get("confirm")),
            command="/tag delete",
            entity_id=name,
            caveat=(
                "Tag membership is removed from every tagged issue and "
                "article; recreating the tag does not restore assignments. "
                "Full recovery requires a database backup restore."
            ),
        )
        client.tags.delete(name)
        return {"ok": True, "action": "delete", "tag": name}


class TagAddCommand(Command):
    """Add a tag to an issue or article."""

    def __init__(self) -> None:
        super().__init__(
            "add",
            "Tag an issue or article",
            requires_client=True,
            usage="kd /tag add ENTITY_ID TAG_NAME",
            long_description=(
                "Entity type is auto-detected from the ID format: FB-123 = issue, FB-A-1 = article."
            ),
            examples=[
                "kd /tag add FB-123 sprint-47",
                "kd /tag add FB-A-1 reviewed",
            ],
            see_also=["/tag remove", "/tag issues"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if len(args) < 2:
            raise ValidationError("Usage: kd /tag add ENTITY_ID TAG_NAME")
        entity_id, tag_name = args[0], args[1]
        client.tags.add(entity_id, tag_name)
        return {"ok": True, "action": "add", "entity": entity_id, "tag": tag_name}


class TagRemoveCommand(Command):
    """Remove a tag from an issue or article."""

    def __init__(self) -> None:
        super().__init__(
            "remove",
            "Untag an issue or article",
            requires_client=True,
            usage="kd /tag remove ENTITY_ID TAG_NAME",
            long_description=(
                "Entity type is auto-detected from the ID format: FB-123 = issue, FB-A-1 = article."
            ),
            examples=[
                "kd /tag remove FB-123 sprint-47",
                "kd /tag remove FB-A-1 reviewed",
            ],
            see_also=["/tag add", "/tag issues"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if len(args) < 2:
            raise ValidationError("Usage: kd /tag remove ENTITY_ID TAG_NAME")
        entity_id, tag_name = args[0], args[1]
        client.tags.remove(entity_id, tag_name)
        return {"ok": True, "action": "remove", "entity": entity_id, "tag": tag_name}


class TagIssuesCommand(Command):
    """List issues tagged with a specific tag (or intersection of tags)."""

    def __init__(self) -> None:
        super().__init__(
            "issues",
            "List issues with a tag",
            requires_client=True,
            usage="kd /tag issues TAG_NAME [--tag TAG ...] [--project P] [--limit N]",
            long_description=(
                "Lists issues tagged with the given tag.  Single-tag uses the "
                "fast server-side tag-issues endpoint; multi-tag composes a "
                "YouTrack query and uses /issues?query=... with AND semantics. "
                "Use --project to scope results to a single project (forces "
                "the composed-query path)."
            ),
            examples=[
                "kd /tag issues sprint-47",
                "kd /tag issues blocked --limit 100",
                "kd /tag issues kind:note --tag component:authservice",
                "kd /tag issues kind:note --tag component:authservice --project KDCLI",
            ],
            see_also=["/tag show", "/tag add", "/tag articles"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="tag",
                short_name="t",
                layer=OptionLayer.COMMAND,
                is_list=True,
                help_text="Additional tag filter (repeatable, AND semantics)",
            )
        )
        self.register_option(project_option(help_text="Scope results to a project"))
        self.register_option(limit_option())

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /tag issues TAG_NAME")
        extra_tags: list[str] = options.command.get("tag", [])
        tags = [args[0], *extra_tags]
        limit = options.command.get("limit", 50)
        project = options.command.get("project")
        issues = client.tags.issues(tags, project=project, top=limit)
        return [_issue_to_row(i) for i in issues]


class TagArticlesCommand(Command):
    """List articles tagged with a specific tag (or intersection of tags)."""

    def __init__(self) -> None:
        super().__init__(
            "articles",
            "List articles with a tag",
            requires_client=True,
            usage="kd /tag articles TAG_NAME [--tag TAG ...] [--project P] [--limit N]",
            long_description=(
                "Lists articles tagged with the given tag. Uses client-side "
                "filtering because the YouTrack API has no server-side "
                "article-by-tag endpoint. Use --project to scope the scan "
                "to a single project. Repeat --tag to require multiple tags "
                "(AND semantics)."
            ),
            examples=[
                "kd /tag articles reviewed",
                'kd /tag articles "type:guide" --project FB',
                "kd /tag articles type:case --tag component:authservice -p CMCSA",
                "kd /tag articles blocked --limit 100",
            ],
            see_also=["/tag issues", "/tag show", "/tag add"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="tag",
                short_name="t",
                layer=OptionLayer.COMMAND,
                is_list=True,
                help_text="Additional tag filter (repeatable, AND semantics)",
            )
        )
        self.register_option(project_option(help_text="Scope scan to a project"))
        self.register_option(limit_option())

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /tag articles TAG_NAME")
        extra_tags: list[str] = options.command.get("tag", [])
        tags = [args[0], *extra_tags]
        limit = options.command.get("limit", 50)
        project = options.command.get("project")
        articles = client.tags.articles(tags, project=project, top=limit)
        return [_article_to_row(a) for a in articles]


class TagEntitiesCommand(Command):
    """Cross-entity tag discovery: list entities tagged with TAG across kinds."""

    def __init__(self) -> None:
        super().__init__(
            "entities",
            "List entities tagged with TAG across kinds",
            requires_client=True,
            usage=(
                "kd /tag entities TAG_NAME [--tag TAG ...] [--project P] "
                "[--kind issue|article|all] "
                "[--limit-issues N] [--limit-articles N] [--limit N] "
                "[--primer-scope]"
            ),
            long_description=(
                "Answers 'what do we have tagged X' across issues and articles "
                "in a single call.  Returns a flat results list plus a meta "
                "dict reporting per-kind completeness: scanned, complete, "
                "truncated, count, limit_per_kind, error.  Default sort is "
                "kind asc (articles first), updated desc within kind.  Single- "
                "kind failure yields exit 0 with meta.<kind>.error populated — "
                "structured consumers must read meta (exit 0 does not mean "
                "every kind succeeded). "
                "--limit supplies the symmetric per-kind default; "
                "--limit-issues and --limit-articles override per kind.  "
                "--primer-scope substitutes the primer's pinned tags as an "
                "OR scope (match=any); mutually exclusive with the positional "
                "TAG and --tag arguments."
            ),
            examples=[
                "kd /tag entities kind:note",
                "kd /tag entities kind:note --tag component:authservice --project KDCLI",
                "kd /tag entities kind:note --kind article --limit-articles 5",
                "kd /tag entities kind:note --limit 20 -o json",
                "kd /tag entities --primer-scope",
            ],
            see_also=["/tag issues", "/tag articles", "/tag show", "/primer/tag list"],
        )
        self.display_hint = "tag_entities"

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="tag",
                short_name="t",
                layer=OptionLayer.COMMAND,
                is_list=True,
                help_text="Additional tag filter (repeatable, AND semantics)",
            )
        )
        self.register_option(project_option(help_text="Scope results to a project"))
        self.register_option(
            OptionDeclaration(
                name="kind",
                layer=OptionLayer.COMMAND,
                choices=["issue", "article", "all"],
                default="all",
                help_text="Restrict to 'issue', 'article', or 'all' (default)",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="limit-issues",
                layer=OptionLayer.COMMAND,
                type=int,
                help_text="Per-kind limit for issues (default 50)",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="limit-articles",
                layer=OptionLayer.COMMAND,
                type=int,
                help_text="Per-kind limit for articles (default 50)",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="limit",
                short_name="l",
                layer=OptionLayer.COMMAND,
                type=int,
                help_text=(
                    "Symmetric per-kind default (50 when unset). "
                    "--limit-issues and --limit-articles override per kind."
                ),
            )
        )
        self.register_option(
            OptionDeclaration(
                name="primer-scope",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text=(
                    "Use tags pinned in .kd/primer.yaml as an OR scope "
                    "(match=any). Mutually exclusive with positional TAG and --tag."
                ),
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        extra_tags: list[str] = options.command.get("tag", [])
        primer_scope = bool(options.command.get("primer-scope"))

        if primer_scope and (args or extra_tags):
            raise ValidationError(
                "--primer-scope is mutually exclusive with positional TAG and --tag."
            )

        match: Literal["all", "any"]
        if primer_scope:
            primer_tags = [t.name for t in load_primer().tags]
            if not primer_tags:
                raise ValidationError(
                    "--primer-scope set but .kd/primer.yaml has no pinned tags. "
                    "Pin a tag with: kd /primer/tag add TAG_NAME"
                )
            tag_names = primer_tags
            match = "any"
        else:
            if not args:
                raise ValidationError(
                    "Usage: kd /tag entities TAG_NAME [--tag T2 ...] | --primer-scope"
                )
            tag_names = [args[0], *extra_tags]
            match = "all"

        project = options.command.get("project")
        kind_opt = options.command.get("kind", "all")
        if kind_opt == "all":
            kinds: tuple[str, ...] = ("issue", "article")
        elif kind_opt == "issue":
            kinds = ("issue",)
        elif kind_opt == "article":
            kinds = ("article",)
        else:
            raise ValidationError(f"Invalid --kind '{kind_opt}'. Use 'issue', 'article', or 'all'.")

        symmetric = options.command.get("limit")
        per_issue = options.command.get("limit-issues")
        per_article = options.command.get("limit-articles")
        base = symmetric if symmetric is not None else 50
        limit_per_kind = {
            "issue": per_issue if per_issue is not None else base,
            "article": per_article if per_article is not None else base,
        }

        result = client.tags.entities(
            tag_names,
            project=project,
            kinds=kinds,
            limit_per_kind=limit_per_kind,
            match=match,
        )
        return {
            "results": [r.model_dump() for r in result.results],
            "meta": {k: m.model_dump(exclude_none=True) for k, m in result.meta.items()},
        }


# --- Namespace Factory ---


def create_tag_namespace() -> Namespace:
    """Build the /tag namespace."""
    ns = Namespace("tag", "Tag management and entity tagging", path="tag")
    ns.register_command("list", TagListCommand())
    ns.register_command("show", TagShowCommand())
    ns.register_command("create", TagCreateCommand())
    ns.register_command("rename", TagRenameCommand())
    ns.register_command("delete", TagDeleteCommand())
    ns.register_command("add", TagAddCommand())
    ns.register_command("remove", TagRemoveCommand())
    ns.register_command("issues", TagIssuesCommand())
    ns.register_command("articles", TagArticlesCommand())
    ns.register_command("entities", TagEntitiesCommand())
    return ns
