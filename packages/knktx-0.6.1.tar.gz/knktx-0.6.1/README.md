# knktx-mcp

MCP server for [knktx](https://github.com/StanK23/knktx) — AI agent project management.

Provides project, board, card, document, memory, skill, and config management tools via the Model Context Protocol.

## Installation

```bash
pip install .
# or with uv:
uv pip install .
```

## Configuration

Set these environment variables:

```bash
export KNKTX_API_URL="https://your-instance.com/api/v1"
export KNKTX_API_KEY="your-api-key"
```

Generate an API key from the knktx Settings page.

## Usage

### With Claude Code

Add to your `~/.claude/settings.json`:

```json
{
  "mcpServers": {
    "knktx": {
      "command": "knktx-mcp",
      "env": {
        "KNKTX_API_URL": "https://your-instance.com/api/v1",
        "KNKTX_API_KEY": "your-api-key"
      }
    }
  }
}
```

### Standalone

```bash
knktx-mcp
```

The server uses stdio transport by default.

## 0.6.0 Migration Notes

- New MCP edit tools:
  - `edit_document_content`
  - `edit_note_content`
  - `edit_skill_file_content`
- MCP edit tools default to `response_mode="changes"` so terminal users see bounded deltas by default.
- Existing read tools keep full-detail defaults unless they already returned lightweight metadata.
- Existing content-heavy write/update tools may now support `response_mode="summary"` or `response_mode="full"`. If an integration needs the full echoed record after a write, pass `response_mode="full"` explicitly.
- `summary` mode is metadata-only. It does not include full content bodies.
- `changes` mode is the explicit opt-in/out contract for bounded edit deltas. Use `response_mode="summary"` when even bounded text fragments should be suppressed.
- For partial edits to existing documents, notes, and skill files, prefer `edit_document_content`, `edit_note_content`, and `edit_skill_file_content`. Full-write tools like `create_document` / `update_document`, `write_note` / `update_note`, `create_skill` / `update_skill`, and `update_skill_file` still send replacement bodies in the request.
- `list_skills`, `list_plugins`, `list_mcp_configs`, and `list_workflows` now return compact summaries by default. Use the corresponding `get_*` tools when you need full detail.
- `get_board`, `list_cards`, `update_card`, `move_card`, `comment_on_card`, `list_comments`, and `update_comment` now accept optional `response_mode="summary"` for compact metadata while keeping `full` as the default.

## Available Tools

### Projects
| Tool | Description |
|------|-------------|
| `list_projects` | List all projects |
| `create_project` | Create a new project |
| `get_project` | Get project details |
| `update_project` | Update project fields |
| `archive_project` | Archive a project |
| `restore_project` | Restore archived project |
| `delete_project` | Delete a project |

### Boards & Cards
| Tool | Description |
|------|-------------|
| `list_boards` | List boards in a project |
| `create_board` | Create a plan board |
| `get_board` | Get board with cards |
| `update_board` | Update board fields |
| `delete_board` | Delete a board |
| `list_cards` | List cards on a board |
| `get_card` | Get card details |
| `create_card` | Create a task card |
| `update_card` | Update card details |
| `move_card` | Transition card status |
| `reorder_card` | Reorder card position |
| `delete_card` | Delete a card |
| `comment_on_card` | Add comment to card |
| `list_comments` | List card comments |
| `update_comment` | Edit a comment |
| `delete_comment` | Delete a comment |

### Documents
| Tool | Description |
|------|-------------|
| `list_documents` | List documents in a project |
| `get_document` | Read document by type |
| `get_document_by_id` | Read document by ID |
| `create_document` | Create a document |
| `update_document` | Update document content |
| `delete_document` | Delete a document |

### Notes
| Tool | Description |
|------|-------------|
| `list_notes` | List notes with optional status filter |
| `search_notes` | Search notes by keyword |
| `write_note` | Create or update a note |
| `delete_note` | Delete a note |

### Skills & Plugins
| Tool | Description |
|------|-------------|
| `list_skills` | List available skills |
| `get_skill` | Get skill with files |
| `create_skill` | Create a skill |
| `update_skill` | Update a skill |
| `delete_skill` | Delete a skill |
| `list_plugins` | List agent plugins |
| `get_plugin` | Get plugin details |
| `create_plugin` | Create a plugin |
| `update_plugin` | Update a plugin |
| `delete_plugin` | Delete a plugin |

### MCP Configs
| Tool | Description |
|------|-------------|
| `list_mcp_configs` | List MCP server configs |
| `get_mcp_config` | Get MCP server config |
| `create_mcp_config` | Create MCP config |
| `update_mcp_config` | Update MCP config |
| `delete_mcp_config` | Delete MCP config |

### Rules & Workflows
| Tool | Description |
|------|-------------|
| `get_workflows` | Get rules + workflows (bootstrap) |
| `list_workflows` | List workflow definitions |
| `get_workflow` | Get workflow details |
| `create_workflow` | Create a workflow |
| `update_workflow` | Update a workflow |
| `delete_workflow` | Delete a workflow |
| `duplicate_workflow` | Duplicate a workflow |
| `list_rules` | List rules |
| `get_rule` | Get rule details |
| `create_rule` | Create a rule |
| `update_rule` | Update a rule |
| `delete_rule` | Delete a rule |
| `check_obligations` | Check pending obligations |
| `start_workflow` | Start a workflow |
| `get_current_step` | Get current workflow step |

### Activity
| Tool | Description |
|------|-------------|
| `get_activity` | Get project activity log |
