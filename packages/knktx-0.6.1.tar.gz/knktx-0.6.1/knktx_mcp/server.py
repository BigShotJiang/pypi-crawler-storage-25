"""knktx MCP server — exposes project management tools for AI agents."""

import asyncio
import json
import re
from collections.abc import Callable, Coroutine
from typing import Annotated, Any, Literal, TypeAlias

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from knktx_mcp.client import ApiError, KnktxClient
from knktx_mcp.enforcement import StepData, render_rules, render_workflows

# Without a Field description, LLMs skip the agent_model param — this alias ensures
# every mutating tool exposes it with a clear prompt so agents consistently identify themselves.
_SLUG_RE = re.compile(r"^[a-z0-9-]+$")

_AgentModel: TypeAlias = Annotated[str | None, Field(description="Your full model ID (e.g. 'claude-opus-4-6', 'gpt-codex-5.4')")]
_Assignee: TypeAlias = Annotated[str | None, Field(description="Auto-populated from agent_model when omitted. Only set to override.")]
_ResponseMode: TypeAlias = Literal["summary", "full"]
_EditResponseMode: TypeAlias = Literal["summary", "changes", "full"]
_SummaryFn: TypeAlias = Callable[[dict[str, Any]], dict[str, Any]]
_MAX_JSON_ARG_CHARS = 1_000_000


mcp = FastMCP(
    "knktx",
    instructions=(
        "At session start, call get_workflows() to retrieve your operational workflows and rules. "
        "Before starting any task, match against the workflow list and follow the matching "
        "workflow step-by-step. For project-scoped work, also call "
        "get_document(project_slug, 'handoff') for current state and "
        "get_document(project_slug, 'project_description') for architecture and locked decisions."
    ),
)

_client: KnktxClient | None = None
_client_lock = asyncio.Lock()


async def _get_client() -> KnktxClient:
    global _client
    async with _client_lock:
        if _client is None:
            _client = KnktxClient()
    return _client


async def _close_client() -> None:
    global _client
    if _client is not None:
        await _client.aclose()
        _client = None


def _fmt(data: Any) -> str:
    """Format API response as readable JSON. Passes strings through unchanged."""
    if isinstance(data, str):
        return data
    return json.dumps(data, indent=2, default=str, ensure_ascii=False)


async def _void_to_msg(coro: Coroutine[Any, Any, Any], msg: str) -> str:
    """Await a void-returning coroutine and return a static message string."""
    await coro
    return msg


async def _api_call(coro: Coroutine[Any, Any, Any]) -> str:
    """Execute an API call and format the result."""
    return _fmt(await coro)


async def _api_call_with_summary(
    coro: Coroutine[Any, Any, Any],
    *,
    response_mode: _ResponseMode,
    summarize: _SummaryFn,
) -> str:
    """Execute an API call and optionally compact the result for terminal use."""
    data = await coro
    if response_mode == "full":
        return _fmt(data)
    return _fmt(summarize(data))


async def _api_call_with_list_summary(
    coro: Coroutine[Any, Any, Any],
    *,
    summarize: _SummaryFn,
) -> str:
    """Execute a list-returning API call and compact each record for terminal use."""
    data = await coro
    return _fmt([summarize(item) if isinstance(item, dict) else item for item in data])


async def _api_call_with_optional_list_summary(
    coro: Coroutine[Any, Any, Any],
    *,
    response_mode: _ResponseMode,
    summarize: _SummaryFn,
) -> str:
    """Execute a list-returning API call and optionally compact each record for terminal use."""
    data = await coro
    if response_mode == "full":
        return _fmt(data)
    return _fmt([summarize(item) if isinstance(item, dict) else item for item in data])


def _parse_json_array(value: list[dict[str, Any]] | str, *, field_name: str) -> list[dict[str, Any]]:
    """Accept a pre-parsed list or a JSON-encoded array string."""
    if isinstance(value, list):
        parsed = value
    else:
        if len(value) > _MAX_JSON_ARG_CHARS:
            raise ValueError(f"'{field_name}' JSON payload exceeds {_MAX_JSON_ARG_CHARS} characters")
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON for '{field_name}' parameter: {e}") from None
        if not isinstance(parsed, list):
            raise ValueError(f"'{field_name}' must be a JSON array")
    if any(not isinstance(item, dict) for item in parsed):
        raise ValueError(f"'{field_name}' must be a JSON array of objects")
    return parsed


async def _run_edit_content_tool(
    operations: list[dict[str, Any]] | str,
    *,
    edit_call: Callable[[list[dict[str, Any]]], Coroutine[Any, Any, Any]],
) -> str:
    """Parse edit operations and normalize validation errors into MCP-safe responses."""
    try:
        return await _api_call(edit_call(_parse_json_array(operations, field_name="operations")))
    except ValueError as e:
        return f"Error: {e}"


def _line_count(text: str) -> int:
    if not text:
        return 0
    return text.count("\n") + 1


def _summarize_text_record(record: dict[str, Any], *, field_name: str) -> dict[str, Any]:
    content = record.get(field_name) or ""
    summary = dict(record)
    summary.pop(field_name, None)
    summary[f"{field_name}_length"] = len(content)
    summary[f"{field_name}_lines"] = _line_count(content)
    return summary


def _summarize_document(document: dict[str, Any]) -> dict[str, Any]:
    return _summarize_text_record(document, field_name="content")


def _summarize_note(note: dict[str, Any]) -> dict[str, Any]:
    return _summarize_text_record(note, field_name="content")


def _summarize_skill(skill: dict[str, Any]) -> dict[str, Any]:
    files = skill.get("files") or []
    summary = dict(skill)
    summary.pop("files", None)
    summary["file_count"] = len(files)
    summary["files"] = [
        {
            "path": file_data.get("path"),
            "content_length": len(file_data.get("content") or ""),
            "content_lines": _line_count(file_data.get("content") or ""),
        }
        for file_data in files
    ]
    return summary


def _summarize_skill_list_item(skill: dict[str, Any]) -> dict[str, Any]:
    files = skill.get("files") or []
    summary = dict(skill)
    summary.pop("files", None)
    summary["file_count"] = len(files)
    return summary


def _summarize_skill_file(skill_file: dict[str, Any]) -> dict[str, Any]:
    summary = _summarize_text_record(skill_file, field_name="content")
    return {
        "path": summary.get("path"),
        "content_length": summary.get("content_length"),
        "content_lines": summary.get("content_lines"),
    }


def _summarize_plugin(plugin: dict[str, Any]) -> dict[str, Any]:
    return _summarize_text_record(plugin, field_name="content")


def _summarize_mcp_config(config: dict[str, Any]) -> dict[str, Any]:
    config_body = config.get("config")
    install_command = config.get("install_command") or ""
    summary = dict(config)
    summary.pop("config", None)
    summary.pop("install_command", None)
    summary["config_keys"] = sorted(config_body.keys()) if isinstance(config_body, dict) else None
    summary["install_command_length"] = len(install_command)
    return summary


def _summarize_workflow(workflow: dict[str, Any]) -> dict[str, Any]:
    steps = workflow.get("steps") or []
    summary = dict(workflow)
    summary.pop("steps", None)
    summary["step_count"] = len(steps)
    summary["steps"] = [
        {
            "id": step.get("id"),
            "type": step.get("type"),
            "action": step.get("action"),
            "label": step.get("label"),
            "position": step.get("position"),
            "agents": step.get("agents"),
        }
        for step in steps
    ]
    return summary


def _summarize_workflow_list_item(workflow: dict[str, Any]) -> dict[str, Any]:
    steps = workflow.get("steps") or []
    summary = dict(workflow)
    summary.pop("steps", None)
    summary["step_count"] = len(steps)
    return summary


def _summarize_card(card: dict[str, Any]) -> dict[str, Any]:
    description = card.get("description") or ""
    metadata = card.get("metadata")
    summary = dict(card)
    summary.pop("description", None)
    summary.pop("metadata", None)
    summary["description_length"] = len(description)
    summary["metadata_keys"] = sorted(metadata.keys()) if isinstance(metadata, dict) else None
    return summary


def _summarize_comment(comment: dict[str, Any]) -> dict[str, Any]:
    return _summarize_text_record(comment, field_name="content")


def _summarize_board_with_cards(board: dict[str, Any]) -> dict[str, Any]:
    cards = board.get("cards") or []
    summary = dict(board)
    summary["cards"] = [
        _summarize_card(card) if isinstance(card, dict) else card
        for card in cards
    ]
    return summary


# === Projects ===


@mcp.tool()
async def list_projects(include_archived: bool = False) -> str:
    """List all projects you own. By default, archived projects are excluded."""
    client = await _get_client()
    return await _api_call(client.list_projects(include_archived=include_archived))


@mcp.tool()
async def create_project(name: str, description: str | None = None, agent_model: _AgentModel = None) -> str:
    """Create a new project."""
    client = await _get_client()
    return await _api_call(client.create_project(name, description, agent_model=agent_model))


@mcp.tool()
async def get_project(slug: str) -> str:
    """Get project details by slug."""
    client = await _get_client()
    return await _api_call(client.get_project(slug))


@mcp.tool()
async def update_project(
    slug: str,
    name: str | None = None,
    description: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Update a project's name or description."""
    fields: dict[str, Any] = {}
    if name is not None:
        fields["name"] = name
    if description is not None:
        fields["description"] = description
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call(client.update_project(slug, **fields, agent_model=agent_model))


@mcp.tool()
async def archive_project(slug: str, agent_model: _AgentModel = None) -> str:
    """Archive a project (soft delete — can be restored)."""
    client = await _get_client()
    return await _api_call(client.archive_project(slug, agent_model=agent_model))


@mcp.tool()
async def restore_project(slug: str, agent_model: _AgentModel = None) -> str:
    """Restore an archived project."""
    client = await _get_client()
    return await _api_call(client.restore_project(slug, agent_model=agent_model))


@mcp.tool()
async def delete_project(slug: str, agent_model: _AgentModel = None) -> str:
    """Permanently delete a project. The project must be archived first. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_project(slug, agent_model=agent_model), "Project deleted.")


# === Boards ===


@mcp.tool()
async def list_boards(
    project_slug: str,
    status: Literal["active", "completed", "archived"] | None = "active",
) -> str:
    """List all boards in a project. Returns active boards by default. Pass status=null for all."""
    client = await _get_client()
    return await _api_call(client.list_boards(project_slug, status=status))


@mcp.tool()
async def create_board(project_slug: str, name: str, description: str | None = None, agent_model: _AgentModel = None) -> str:
    """Create a new plan board in a project."""
    client = await _get_client()
    return await _api_call(client.create_board(project_slug, name, description, agent_model=agent_model))


@mcp.tool()
async def get_board(project_slug: str, board_id: str, response_mode: _ResponseMode = "full") -> str:
    """Get a board with its cards. Use `response_mode="summary"` for compact card summaries."""
    client = await _get_client()

    async def _fetch() -> dict[str, Any]:
        data = await client.get_board(project_slug, board_id)
        data["cards"] = await client.list_cards(project_slug, board_id)
        return data

    return await _api_call_with_summary(
        _fetch(),
        response_mode=response_mode,
        summarize=_summarize_board_with_cards,
    )


@mcp.tool()
async def update_board(
    project_slug: str,
    board_id: str,
    name: str | None = None,
    description: str | None = None,
    status: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Update a board's name, description, or status. Status: "active", "completed", or "archived"."""
    fields: dict[str, Any] = {}
    if name is not None:
        fields["name"] = name
    if description is not None:
        fields["description"] = description
    if status is not None:
        fields["status"] = status
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call(client.update_board(project_slug, board_id, **fields, agent_model=agent_model))


@mcp.tool()
async def delete_board(project_slug: str, board_id: str, agent_model: _AgentModel = None) -> str:
    """Delete a board and all its cards. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_board(project_slug, board_id, agent_model=agent_model), "Board deleted.")


# === Cards ===


@mcp.tool()
async def list_cards(project_slug: str, board_id: str, response_mode: _ResponseMode = "full") -> str:
    """List all cards on a board (all statuses). Use `response_mode="summary"` for compact card metadata."""
    client = await _get_client()
    return await _api_call_with_optional_list_summary(
        client.list_cards(project_slug, board_id),
        response_mode=response_mode,
        summarize=_summarize_card,
    )


@mcp.tool()
async def get_card(project_slug: str, board_id: str, card_id: str) -> str:
    """Get a single card by ID."""
    client = await _get_client()
    return await _api_call(client.get_card(project_slug, board_id, card_id))


@mcp.tool()
async def create_card(
    project_slug: str,
    board_id: str,
    title: str,
    description: str | None = None,
    status: str = "inbox",
    assignee: _Assignee = None,
    source_note_id: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Create a task card on a board. Status: inbox, in_progress, done, or merged. Use source_note_id to link a card to the note that inspired it."""
    client = await _get_client()
    return await _api_call(
        client.create_card(project_slug, board_id, title, description=description, status=status, assignee=assignee, source_note_id=source_note_id, agent_model=agent_model)
    )


@mcp.tool()
async def update_card(
    project_slug: str,
    board_id: str,
    card_id: str,
    title: str | None = None,
    description: str | None = None,
    assignee: _Assignee = None,
    branch_name: str | None = None,
    pr_url: str | None = None,
    source_note_id: str | None = None,
    response_mode: _ResponseMode = "full",
    agent_model: _AgentModel = None,
) -> str:
    """Update a task card's details. Does not change status — use move_card for that. Use `response_mode="summary"` for compact card metadata."""
    fields: dict[str, Any] = {}
    if title is not None:
        fields["title"] = title
    if description is not None:
        fields["description"] = description
    if assignee is not None:
        fields["assignee"] = assignee
    if branch_name is not None:
        fields["branch_name"] = branch_name
    if pr_url is not None:
        fields["pr_url"] = pr_url
    if source_note_id is not None:
        fields["source_note_id"] = source_note_id
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call_with_summary(
        client.update_card(project_slug, board_id, card_id, **fields, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_card,
    )


@mcp.tool()
async def move_card(
    project_slug: str,
    board_id: str,
    card_id: str,
    status: str,
    response_mode: _ResponseMode = "full",
    agent_model: _AgentModel = None,
) -> str:
    """Transition a card to a new status column. Status: inbox, in_progress, done, or merged. Use `response_mode="summary"` for compact card metadata."""
    client = await _get_client()
    return await _api_call_with_summary(
        client.move_card(project_slug, board_id, card_id, status, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_card,
    )


@mcp.tool()
async def reorder_card(project_slug: str, board_id: str, card_id: str, position: int, agent_model: _AgentModel = None) -> str:
    """Change a card's position within its current status column. 0 = top."""
    client = await _get_client()
    return await _api_call(client.reorder_card(project_slug, board_id, card_id, position, agent_model=agent_model))


@mcp.tool()
async def delete_card(project_slug: str, board_id: str, card_id: str, agent_model: _AgentModel = None) -> str:
    """Delete a card from a board. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_card(project_slug, board_id, card_id, agent_model=agent_model), "Card deleted.")


@mcp.tool()
async def comment_on_card(
    project_slug: str,
    board_id: str,
    card_id: str,
    content: str,
    response_mode: _ResponseMode = "full",
    agent_model: _AgentModel = None,
) -> str:
    """Add a comment to a task card. Author is determined from the API key. Use `response_mode="summary"` for compact comment metadata."""
    client = await _get_client()
    return await _api_call_with_summary(
        client.comment_on_card(project_slug, board_id, card_id, content, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_comment,
    )


@mcp.tool()
async def list_comments(
    project_slug: str,
    board_id: str,
    card_id: str,
    response_mode: _ResponseMode = "full",
) -> str:
    """List all comments on a card. Use `response_mode="summary"` for compact comment metadata."""
    client = await _get_client()
    return await _api_call_with_optional_list_summary(
        client.list_comments(project_slug, board_id, card_id),
        response_mode=response_mode,
        summarize=_summarize_comment,
    )


@mcp.tool()
async def update_comment(
    project_slug: str,
    board_id: str,
    card_id: str,
    comment_id: str,
    content: str,
    response_mode: _ResponseMode = "full",
    agent_model: _AgentModel = None,
) -> str:
    """Edit an existing comment on a card. Use `response_mode="summary"` for compact comment metadata."""
    client = await _get_client()
    return await _api_call_with_summary(
        client.update_comment(project_slug, board_id, card_id, comment_id, content, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_comment,
    )


@mcp.tool()
async def delete_comment(
    project_slug: str,
    board_id: str,
    card_id: str,
    comment_id: str,
    agent_model: _AgentModel = None,
) -> str:
    """Delete a comment from a card. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(
        client.delete_comment(project_slug, board_id, card_id, comment_id, agent_model=agent_model), "Comment deleted."
    )


# === Documents ===


@mcp.tool()
async def list_documents(
    project_slug: str,
    doc_type: str | None = None,
    board_id: str | None = None,
    path: str | None = None,
    include_completed: bool = False,
) -> str:
    """List documents in a project, optionally filtered. Documents linked to completed/archived boards are hidden by default."""
    client = await _get_client()
    return await _api_call(client.list_documents(project_slug, doc_type=doc_type, board_id=board_id, path=path, include_completed=include_completed))


@mcp.tool()
async def get_document(
    project_slug: str,
    doc_type: str,
    board_id: str | None = None,
    response_mode: _ResponseMode = "full",
) -> str:
    """Read a project document by type (e.g. "handoff", "project_description", "plan")."""
    client = await _get_client()
    return await _api_call_with_summary(
        client.get_document_by_type(project_slug, doc_type, board_id=board_id),
        response_mode=response_mode,
        summarize=_summarize_document,
    )


@mcp.tool()
async def create_document(
    project_slug: str,
    doc_type: str,
    title: str,
    content: str,
    board_id: str | None = None,
    path: str | None = None,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Create or update a project document (upserts by project + doc_type + board_id).

    This sends the full document body. For partial edits to an existing document,
    prefer `edit_document_content` to avoid large MCP request payloads.
    """
    client = await _get_client()
    return await _api_call_with_summary(
        client.write_document(project_slug, doc_type, title, content, board_id=board_id, path=path, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_document,
    )


@mcp.tool()
async def update_document(
    project_slug: str,
    document_id: str,
    title: str | None = None,
    content: str | None = None,
    path: str | None = None,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Update an existing document's title, content, or folder path. Change path to move between folders.

    If `content` is provided, it replaces the full stored body. For partial edits
    to existing content, prefer `edit_document_content`.
    """
    fields: dict[str, Any] = {}
    if title is not None:
        fields["title"] = title
    if content is not None:
        fields["content"] = content
    if path is not None:
        fields["path"] = path
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call_with_summary(
        client.update_document(project_slug, document_id, **fields, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_document,
    )


@mcp.tool()
async def delete_document(project_slug: str, document_id: str, agent_model: _AgentModel = None) -> str:
    """Delete a document. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_document(project_slug, document_id, agent_model=agent_model), "Document deleted.")


# === Notes ===


@mcp.tool()
async def get_note(note_id: str, response_mode: _ResponseMode = "full") -> str:
    """Get a note by UUID (e.g. '550e8400-e29b-41d4-a716-446655440000')."""
    client = await _get_client()
    return await _api_call_with_summary(
        client.get_note(note_id),
        response_mode=response_mode,
        summarize=_summarize_note,
    )


@mcp.tool()
async def list_notes(project_slug: str | None = None, status: str = "active", board_id: str | None = None) -> str:
    """List notes (summaries without content). Use get_note(note_id) for full content. Status: "active", "completed", or "archived"."""
    client = await _get_client()
    effective_board_id = board_id if project_slug else None
    return await _api_call(client.list_notes(project_slug=project_slug, status=status, board_id=effective_board_id))


@mcp.tool()
async def write_note(
    title: str,
    content: str | None = None,
    description: str | None = None,
    agent: str | None = None,
    tags: list[str] | None = None,
    status: str | None = None,
    board_id: str | None = None,
    clear_fields: list[str] | None = None,
    project_slug: str | None = None,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Write a note (upserts by title). PATCH semantics: omit a field to leave it unchanged.

    content: required when creating, optional on update (omit to keep existing).
      If provided for an existing note, it replaces the full stored body.
      Prefer `edit_note_content` for partial edits to an existing note.
    description: short summary (max 500 chars) shown in list results.
    status: "active", "completed", or "archived".
    clear_fields: list of field names to explicitly set to null (e.g. ["description", "tags"]).
      Clearable fields: description, content, agent, tags, board_id.
    """
    client = await _get_client()
    return await _api_call_with_summary(
        client.write_note(title, content, description=description, agent=agent, tags=tags, status=status, board_id=board_id, clear_fields=clear_fields, project_slug=project_slug, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_note,
    )


@mcp.tool()
async def update_note(
    note_id: str,
    title: str | None = None,
    content: str | None = None,
    description: str | None = None,
    agent: str | None = None,
    tags: list[str] | None = None,
    status: str | None = None,
    board_id: str | None = None,
    clear_fields: list[str] | None = None,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Update a note by ID. PATCH semantics: only provided fields are modified.

    If `content` is provided, it replaces the full stored body. For partial edits,
    prefer `edit_note_content`.

    status: "active", "completed", or "archived".
    clear_fields: list of field names to explicitly set to null (e.g. ["description", "tags"]).
    """
    client = await _get_client()
    return await _api_call_with_summary(
        client.patch_note(note_id, title=title, content=content, description=description, agent=agent, tags=tags, status=status, board_id=board_id, clear_fields=clear_fields, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_note,
    )


@mcp.tool()
async def delete_note(title: str, project_slug: str | None = None, agent_model: _AgentModel = None) -> str:
    """Delete a note by title."""
    client = await _get_client()
    return await _void_to_msg(
        client.delete_note(title, project_slug=project_slug, agent_model=agent_model), "Note deleted."
    )


# === Skills ===


@mcp.tool()
async def list_skills(agent: str | None = None) -> str:
    """List all available skills, optionally filtered by agent. Returns compact summaries without file contents."""
    agent = agent.strip().lower() if agent else None
    client = await _get_client()
    return await _api_call_with_list_summary(
        client.list_skills(agent=agent),
        summarize=_summarize_skill_list_item,
    )


@mcp.tool()
async def get_skill(slug: str, response_mode: _ResponseMode = "full") -> str:
    """Get a skill by slug. Use `response_mode="summary"` for compact file metadata."""
    client = await _get_client()
    return await _api_call_with_summary(
        client.get_skill(slug),
        response_mode=response_mode,
        summarize=_summarize_skill,
    )


@mcp.tool()
async def create_skill(
    name: str,
    files: list[dict[str, Any]] | str | None = None,
    version: str = "1.0.0",
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_public: bool = False,
    enabled: bool = True,
    user_invocable: bool = False,
    allowed_tools: list[str] | None = None,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Create a new skill. files is a JSON-encoded array, e.g. '[{"path": "SKILL.md", "content": "# My Skill"}]'.

    This writes the full file set for the skill. After creation, prefer
    `edit_skill_file_content` for partial edits to existing files.
    """
    parsed_files = _parse_json_array(files, field_name="files") if files is not None else []
    client = await _get_client()
    return await _api_call_with_summary(
        client.create_skill(name, files=parsed_files, version=version, description=description, metadata=metadata, is_public=is_public, enabled=enabled, user_invocable=user_invocable, allowed_tools=allowed_tools, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_skill,
    )


@mcp.tool()
async def update_skill(
    slug: str,
    name: str | None = None,
    files: list[dict[str, Any]] | str | None = None,
    version: str | None = None,
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_public: bool | None = None,
    enabled: bool | None = None,
    user_invocable: bool | None = None,
    allowed_tools: list[str] | None = None,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Update an existing skill. files is a JSON-encoded array of {path, content} objects (replaces all files).

    If `files` is provided, it replaces the skill's full file set. For partial
    edits to one existing file, prefer `edit_skill_file_content`.
    """
    fields: dict[str, Any] = {}
    if name is not None:
        fields["name"] = name
    if files is not None:
        fields["files"] = _parse_json_array(files, field_name="files")
    if version is not None:
        fields["version"] = version
    if description is not None:
        fields["description"] = description
    if metadata is not None:
        fields["metadata"] = metadata
    if is_public is not None:
        fields["is_public"] = is_public
    if enabled is not None:
        fields["enabled"] = enabled
    if user_invocable is not None:
        fields["user_invocable"] = user_invocable
    if allowed_tools is not None:
        fields["allowed_tools"] = allowed_tools
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call_with_summary(
        client.update_skill(slug, **fields, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_skill,
    )


@mcp.tool()
async def delete_skill(slug: str, agent_model: _AgentModel = None) -> str:
    """Delete a skill by slug. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_skill(slug, agent_model=agent_model), "Skill deleted.")


@mcp.tool()
async def get_skill_file(slug: str, path: str, response_mode: _ResponseMode = "full") -> str:
    """Get a single file from a skill by path (e.g. 'SKILL.md' or 'agents/code.md')."""
    client = await _get_client()
    try:
        return await _api_call_with_summary(
            client.get_skill_file(slug, path),
            response_mode=response_mode,
            summarize=_summarize_skill_file,
        )
    except ValueError as e:
        return f"Error: {e}"


@mcp.tool()
async def update_skill_file(
    slug: str,
    path: str,
    content: str,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Create or update a single file within a skill (e.g. 'SKILL.md' or 'agents/code.md').

    This replaces the full file body. Use it for create/full rewrite flows; for
    partial edits to an existing file, prefer `edit_skill_file_content`.
    """
    client = await _get_client()
    try:
        return await _api_call_with_summary(
            client.update_skill_file(slug, path, content, agent_model=agent_model),
            response_mode=response_mode,
            summarize=_summarize_skill,
        )
    except ValueError as e:
        return f"Error: {e}"


@mcp.tool()
async def delete_skill_file(slug: str, path: str, agent_model: _AgentModel = None) -> str:
    """Remove a single file from a skill (e.g. 'SKILL.md' or 'agents/code.md'). Returns a compact skill summary."""
    client = await _get_client()
    try:
        return await _api_call_with_summary(
            client.delete_skill_file(slug, path, agent_model=agent_model),
            response_mode="summary",
            summarize=_summarize_skill,
        )
    except ValueError as e:
        return f"Error: {e}"


# === MCP Configs ===


@mcp.tool()
async def list_mcp_configs(agent: str | None = None) -> str:
    """List all MCP server configurations, optionally filtered by agent. Returns compact summaries without full config bodies."""
    agent = agent.strip().lower() if agent else None
    client = await _get_client()
    return await _api_call_with_list_summary(
        client.list_mcp_configs(agent=agent),
        summarize=_summarize_mcp_config,
    )


@mcp.tool()
async def get_mcp_config(name: str, response_mode: _ResponseMode = "full") -> str:
    """Get an MCP server configuration by name. Use `response_mode="summary"` for compact metadata."""
    client = await _get_client()
    return await _api_call_with_summary(
        client.get_mcp_config(name),
        response_mode=response_mode,
        summarize=_summarize_mcp_config,
    )


@mcp.tool()
async def create_mcp_config(
    name: str,
    config: dict[str, Any],
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_public: bool = False,
    enabled: bool = True,
    install_command: str | None = None,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Create a new MCP server configuration."""
    client = await _get_client()
    return await _api_call_with_summary(
        client.create_mcp_config(name, config, description=description, metadata=metadata, is_public=is_public, enabled=enabled, install_command=install_command, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_mcp_config,
    )


@mcp.tool()
async def update_mcp_config(
    name: str,
    config: dict[str, Any] | None = None,
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_public: bool | None = None,
    enabled: bool | None = None,
    install_command: str | None = None,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Update an MCP server configuration."""
    fields: dict[str, Any] = {}
    if config is not None:
        fields["config"] = config
    if description is not None:
        fields["description"] = description
    if metadata is not None:
        fields["metadata"] = metadata
    if is_public is not None:
        fields["is_public"] = is_public
    if enabled is not None:
        fields["enabled"] = enabled
    if install_command is not None:
        fields["install_command"] = install_command
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call_with_summary(
        client.update_mcp_config(name, **fields, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_mcp_config,
    )


@mcp.tool()
async def delete_mcp_config(name: str, agent_model: _AgentModel = None) -> str:
    """Delete an MCP server configuration. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_mcp_config(name, agent_model=agent_model), "MCP config deleted.")


# === Plugins ===


@mcp.tool()
async def list_plugins(agent: str | None = None) -> str:
    """List plugin configurations. Each entry is one agent (e.g. "claude") and returns compact summaries without full install scripts."""
    agent = agent.strip().lower() if agent else None
    client = await _get_client()
    return await _api_call_with_list_summary(
        client.list_plugins(agent=agent),
        summarize=_summarize_plugin,
    )


@mcp.tool()
async def get_plugin(slug: str, response_mode: _ResponseMode = "full") -> str:
    """Get a plugin configuration by slug. Each entry is one agent (e.g. "claude"). Use `response_mode="summary"` for compact metadata."""
    client = await _get_client()
    return await _api_call_with_summary(
        client.get_plugin(slug),
        response_mode=response_mode,
        summarize=_summarize_plugin,
    )


@mcp.tool()
async def create_plugin(
    name: str,
    content: str = "",
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_public: bool = False,
    enabled: bool = True,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Create a plugin configuration. One entry per agent (e.g. name="claude"), not per plugin. Content contains the full install script. Check list_plugins() first to avoid duplicates."""
    client = await _get_client()
    return await _api_call_with_summary(
        client.create_plugin(name, content=content, description=description, metadata=metadata, is_public=is_public, enabled=enabled, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_plugin,
    )


@mcp.tool()
async def update_plugin(
    slug: str,
    name: str | None = None,
    content: str | None = None,
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_public: bool | None = None,
    enabled: bool | None = None,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Update a plugin configuration. Changing the name may update the slug."""
    fields: dict[str, Any] = {}
    if name is not None:
        fields["name"] = name
    if content is not None:
        fields["content"] = content
    if description is not None:
        fields["description"] = description
    if metadata is not None:
        fields["metadata"] = metadata
    if is_public is not None:
        fields["is_public"] = is_public
    if enabled is not None:
        fields["enabled"] = enabled
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call_with_summary(
        client.update_plugin(slug, **fields, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_plugin,
    )


@mcp.tool()
async def delete_plugin(slug: str, agent_model: _AgentModel = None) -> str:
    """Delete a plugin configuration by slug. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_plugin(slug, agent_model=agent_model), "Plugin deleted.")


# === Activity ===


@mcp.tool()
async def get_activity(project_slug: str, limit: int = 20) -> str:
    """Get recent project activity (timeline). Returns the last 20 events by default."""
    client = await _get_client()
    return await _api_call(client.get_activity(project_slug, limit=limit))


# === Workflows ===


@mcp.tool()
async def get_workflows(agent: str | None = None) -> str:
    """Returns all enabled workflows and rules as structured markdown. Main entry point for agents to read operational instructions."""
    agent = agent.strip().lower() if agent else None
    client = await _get_client()
    data = await client.list_workflows(enabled=True, agent=agent)

    # Render workflows as markdown (with step-level agent filtering)
    result = render_workflows(data, agent=agent)

    # Also render rules
    try:
        rules_data = await client.list_rules(enabled=True, agent=agent)
        rules_section = render_rules(rules_data)
        if rules_section:
            result = result + "\n\n" + rules_section
    except ApiError as exc:
        result = result + f"\n\n[RULES LOAD ERROR: {exc} — rules omitted from this response]"

    return result


@mcp.tool()
async def list_workflows(enabled: bool | None = True, agent: str | None = None) -> str:
    """Returns workflow metadata list (id, name, trigger, enabled, version). By default returns only enabled workflows."""
    agent = agent.strip().lower() if agent else None
    client = await _get_client()
    return await _api_call_with_list_summary(
        client.list_workflows(enabled=enabled, agent=agent),
        summarize=_summarize_workflow_list_item,
    )


@mcp.tool()
async def get_workflow(workflow_id: str, response_mode: _ResponseMode = "full") -> str:
    """Get a specific workflow by ID. Use `response_mode="summary"` for compact step metadata."""
    client = await _get_client()
    return await _api_call_with_summary(
        client.get_workflow(workflow_id),
        response_mode=response_mode,
        summarize=_summarize_workflow,
    )


@mcp.tool()
async def create_workflow(
    name: str,
    steps: list[StepData] | None = None,
    description: str | None = None,
    trigger_type: Literal["event", "manual"] | None = None,
    trigger_config: dict[str, Any] | None = None,
    enabled: bool = True,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Create a new workflow. All workflows are global."""
    client = await _get_client()
    return await _api_call_with_summary(
        client.create_workflow(name, description=description, trigger_type=trigger_type, trigger_config=trigger_config, steps=steps, enabled=enabled, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_workflow,
    )


@mcp.tool()
async def update_workflow(
    workflow_id: str,
    name: str | None = None,
    steps: list[StepData] | None = None,
    description: str | None = None,
    trigger_type: Literal["event", "manual"] | None = None,
    trigger_config: dict[str, Any] | None = None,
    enabled: bool | None = None,
    response_mode: _ResponseMode = "summary",
    agent_model: _AgentModel = None,
) -> str:
    """Update an existing workflow's steps, trigger, or metadata."""
    client = await _get_client()

    kwargs = {
        k: v
        for k, v in {
            "name": name,
            "description": description,
            "trigger_type": trigger_type,
            "trigger_config": trigger_config,
            "steps": steps,
            "enabled": enabled,
        }.items()
        if v is not None
    }
    if not kwargs:
        return "No fields to update"
    return await _api_call_with_summary(
        client.update_workflow(workflow_id, **kwargs, agent_model=agent_model),
        response_mode=response_mode,
        summarize=_summarize_workflow,
    )


@mcp.tool()
async def edit_document_content(
    project_slug: str,
    document_id: str,
    operations: list[dict[str, Any]] | str,
    expected_version: int | None = None,
    response_mode: _EditResponseMode = "changes",
    agent_model: _AgentModel = None,
) -> str:
    """Apply targeted document edits. `operations` accepts a parsed array or JSON string. Defaults to `changes` so the terminal shows bounded deltas.

    Prefer this over `update_document(..., content=...)` for partial edits.
    """
    client = await _get_client()
    return await _run_edit_content_tool(
        operations,
        edit_call=lambda parsed_operations: client.edit_document_content(
            project_slug,
            document_id,
            parsed_operations,
            expected_version=expected_version,
            response_mode=response_mode,
            agent_model=agent_model,
        ),
    )


@mcp.tool()
async def edit_note_content(
    note_id: str,
    operations: list[dict[str, Any]] | str,
    expected_version: int | None = None,
    response_mode: _EditResponseMode = "changes",
    agent_model: _AgentModel = None,
) -> str:
    """Apply targeted note edits. `operations` accepts a parsed array or JSON string. Defaults to `changes` so the terminal shows bounded deltas.

    Prefer this over `write_note(..., content=...)` or `update_note(..., content=...)`
    for partial edits to existing notes.
    """
    client = await _get_client()
    return await _run_edit_content_tool(
        operations,
        edit_call=lambda parsed_operations: client.edit_note_content(
            note_id,
            parsed_operations,
            expected_version=expected_version,
            response_mode=response_mode,
            agent_model=agent_model,
        ),
    )


@mcp.tool()
async def edit_skill_file_content(
    slug: str,
    path: str,
    operations: list[dict[str, Any]] | str,
    expected_version: int | None = None,
    response_mode: _EditResponseMode = "changes",
    agent_model: _AgentModel = None,
) -> str:
    """Apply targeted edits to a single skill file. `operations` accepts a parsed array or JSON string. Defaults to `changes` so the terminal shows bounded deltas.

    Prefer this over `update_skill_file(..., content=...)` for partial edits to an
    existing file.
    """
    client = await _get_client()
    return await _run_edit_content_tool(
        operations,
        edit_call=lambda parsed_operations: client.edit_skill_file_content(
            slug,
            path,
            parsed_operations,
            expected_version=expected_version,
            response_mode=response_mode,
            agent_model=agent_model,
        ),
    )


@mcp.tool()
async def insert_step(
    workflow_id: str,
    step: StepData,
    position: int,
    agent_model: _AgentModel = None,
) -> str:
    """Insert a single step into a workflow at the given position. Shifts existing steps down."""
    client = await _get_client()
    workflow = await client.get_workflow(workflow_id)
    steps = workflow.get("steps", [])
    step["position"] = position
    steps.insert(position, step)
    # Re-number positions after insertion
    for i, s in enumerate(steps):
        s["position"] = i
    return await _api_call(client.update_workflow(workflow_id, steps=steps, agent_model=agent_model))


@mcp.tool()
async def remove_step(
    workflow_id: str,
    step_id: str,
    agent_model: _AgentModel = None,
) -> str:
    """Remove a single step from a workflow by step ID. Re-numbers remaining positions."""
    client = await _get_client()
    workflow = await client.get_workflow(workflow_id)
    steps = workflow.get("steps", [])
    original_len = len(steps)
    steps = [s for s in steps if s.get("id") != step_id]
    if len(steps) == original_len:
        return f"Step '{step_id}' not found in workflow"
    for i, s in enumerate(steps):
        s["position"] = i
    return await _api_call(client.update_workflow(workflow_id, steps=steps, agent_model=agent_model))


@mcp.tool()
async def delete_workflow(workflow_id: str, agent_model: _AgentModel = None) -> str:
    """Delete a workflow by ID."""
    client = await _get_client()
    return await _void_to_msg(client.delete_workflow(workflow_id, agent_model=agent_model), "Workflow deleted.")


@mcp.tool()
async def duplicate_workflow(workflow_id: str, agent_model: _AgentModel = None) -> str:
    """Clone an existing workflow. Resets version to 1, appends ' (copy)' to name."""
    client = await _get_client()
    return await _api_call(client.duplicate_workflow(workflow_id, agent_model=agent_model))


# === Rules ===


@mcp.tool()
async def list_rules(
    rule_type: str | None = None,
    enabled: bool | None = None,
    source: Literal["custom", "settings"] | None = None,
    agent: str | None = None,
    project_slug: str | None = None,
    include_global: bool = False,
) -> str:
    """List rules, optionally filtered. Without project_slug returns global rules only. With project_slug returns that project's rules. Set include_global=true with a project_slug to get both."""
    agent = agent.strip().lower() if agent else None
    if project_slug:
        project_slug = project_slug.strip().lower()
        if not _SLUG_RE.match(project_slug):
            return "Error: project_slug must contain only lowercase letters, numbers, and hyphens"
    client = await _get_client()
    return await _api_call(client.list_rules(
        rule_type=rule_type, enabled=enabled, source=source, agent=agent,
        project_slug=project_slug, include_global=include_global,
    ))


@mcp.tool()
async def get_rule(rule_id: str) -> str:
    """Get a rule by its UUID."""
    client = await _get_client()
    return await _api_call(client.get_rule(rule_id))


@mcp.tool()
async def create_rule(
    name: str,
    rule_type: str,
    config: dict[str, Any] | None = None,
    description: str | None = None,
    source: Literal["custom", "settings"] = "custom",
    enabled: bool = True,
    project_slug: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Create a new rule (rendered in get_workflows() output). Types: prohibition, obligation, preference. Pass project_slug to scope to a project (omit for global). Source is immutable after creation."""
    if project_slug:
        project_slug = project_slug.strip().lower()
        if not _SLUG_RE.match(project_slug):
            return "Error: project_slug must contain only lowercase letters, numbers, and hyphens"
    client = await _get_client()
    return await _api_call(
        client.create_rule(
            name,
            rule_type,
            description=description,
            config=config,
            source=source,
            enabled=enabled,
            project_slug=project_slug,
            agent_model=agent_model,
        )
    )


@mcp.tool()
async def update_rule(
    rule_id: str,
    name: str | None = None,
    description: str | None = None,
    rule_type: str | None = None,
    config: dict[str, Any] | None = None,
    enabled: bool | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Update an existing rule. Note: project_slug cannot be changed after creation."""
    client = await _get_client()
    kwargs = {
        k: v
        for k, v in {
            "name": name,
            "description": description,
            "rule_type": rule_type,
            "config": config,
            "enabled": enabled,
        }.items()
        if v is not None
    }
    if not kwargs:
        return "No fields to update"
    return await _api_call(client.update_rule(rule_id, **kwargs, agent_model=agent_model))


@mcp.tool()
async def delete_rule(rule_id: str, agent_model: _AgentModel = None) -> str:
    """Delete a rule by ID."""
    client = await _get_client()
    return await _void_to_msg(client.delete_rule(rule_id, agent_model=agent_model), "Rule deleted.")


def main() -> None:
    """Entry point for the knktx MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
