import json

import pytest

from knktx_mcp import server
from knktx_mcp.client import KnktxClient


@pytest.mark.anyio
async def test_get_document_keeps_full_default_and_supports_summary(monkeypatch):
    class DummyClient:
        async def get_document_by_type(self, project_slug: str, doc_type: str, *, board_id=None):
            assert project_slug == "knktx"
            assert doc_type == "handoff"
            assert board_id is None
            return {
                "id": "doc-1",
                "doc_type": doc_type,
                "title": "HANDOFF",
                "content": "line one\nline two",
                "version": 5,
            }

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    full_result = json.loads(await server.get_document("knktx", "handoff"))
    summary_result = json.loads(
        await server.get_document("knktx", "handoff", response_mode="summary")
    )

    assert full_result["content"] == "line one\nline two"
    assert "content" not in summary_result
    assert "content_preview" not in summary_result
    assert summary_result["content_length"] == 17
    assert summary_result["content_lines"] == 2


@pytest.mark.anyio
async def test_get_skill_keeps_full_default_and_supports_summary(monkeypatch):
    class DummyClient:
        async def get_skill(self, slug: str):
            assert slug == "demo-skill"
            return {
                "id": "skill-1",
                "name": "Demo Skill",
                "slug": slug,
                "files": [
                    {"path": "SKILL.md", "content": "alpha\nbeta"},
                    {"path": "agents/code.md", "content": "gamma"},
                ],
                "version": "1.0.0",
                "content_version": 3,
            }

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    full_result = json.loads(await server.get_skill("demo-skill"))
    summary_result = json.loads(
        await server.get_skill("demo-skill", response_mode="summary")
    )

    assert full_result["files"][0]["content"] == "alpha\nbeta"
    assert summary_result["slug"] == "demo-skill"
    assert summary_result["file_count"] == 2
    assert summary_result["files"] == [
        {"path": "SKILL.md", "content_length": 10, "content_lines": 2},
        {"path": "agents/code.md", "content_length": 5, "content_lines": 1},
    ]


@pytest.mark.anyio
async def test_get_plugin_keeps_full_default_and_supports_summary(monkeypatch):
    class DummyClient:
        async def get_plugin(self, slug: str):
            assert slug == "claude"
            return {
                "id": "plugin-1",
                "name": "claude",
                "slug": slug,
                "content": "plugin install script",
                "enabled": True,
            }

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    full_result = json.loads(await server.get_plugin("claude"))
    summary_result = json.loads(
        await server.get_plugin("claude", response_mode="summary")
    )

    assert full_result["content"] == "plugin install script"
    assert "content" not in summary_result
    assert summary_result["content_length"] == 21
    assert summary_result["content_lines"] == 1


@pytest.mark.anyio
async def test_get_mcp_config_keeps_full_default_and_supports_summary(monkeypatch):
    class DummyClient:
        async def get_mcp_config(self, name: str):
            assert name == "firecrawl"
            return {
                "name": name,
                "config": {"command": "firecrawl"},
                "install_command": "uvx firecrawl",
                "enabled": True,
            }

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    full_result = json.loads(await server.get_mcp_config("firecrawl"))
    summary_result = json.loads(
        await server.get_mcp_config("firecrawl", response_mode="summary")
    )

    assert full_result["config"] == {"command": "firecrawl"}
    assert full_result["install_command"] == "uvx firecrawl"
    assert "config" not in summary_result
    assert "install_command" not in summary_result
    assert summary_result["config_keys"] == ["command"]
    assert summary_result["install_command_length"] == 13


@pytest.mark.anyio
async def test_list_skills_returns_compact_summaries(monkeypatch):
    class DummyClient:
        async def list_skills(self, *, agent=None):
            assert agent == "claude"
            return [
                {
                    "id": "skill-1",
                    "name": "Demo Skill",
                    "slug": "demo-skill",
                    "files": [
                        {"path": "SKILL.md", "content": "alpha"},
                        {"path": "agents/code.md", "content": "beta"},
                    ],
                    "version": "1.0.0",
                    "enabled": True,
                }
            ]

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    result = json.loads(await server.list_skills(agent="Claude"))

    assert result == [
        {
            "id": "skill-1",
            "name": "Demo Skill",
            "slug": "demo-skill",
            "version": "1.0.0",
            "enabled": True,
            "file_count": 2,
        }
    ]


@pytest.mark.anyio
async def test_list_mcp_configs_returns_compact_summaries(monkeypatch):
    class DummyClient:
        async def list_mcp_configs(self, *, agent=None):
            assert agent == "codex"
            return [
                {
                    "id": "cfg-1",
                    "name": "firecrawl",
                    "config": {"command": "uvx", "args": ["firecrawl"]},
                    "install_command": "uv tool install firecrawl",
                    "enabled": True,
                }
            ]

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    result = json.loads(await server.list_mcp_configs(agent="Codex"))

    assert result == [
        {
            "id": "cfg-1",
            "name": "firecrawl",
            "enabled": True,
            "config_keys": ["args", "command"],
            "install_command_length": 25,
        }
    ]


@pytest.mark.anyio
async def test_list_plugins_returns_compact_summaries(monkeypatch):
    class DummyClient:
        async def list_plugins(self, *, agent=None):
            assert agent == "claude"
            return [
                {
                    "id": "plugin-1",
                    "name": "claude",
                    "slug": "claude",
                    "content": "line one\nline two",
                    "enabled": True,
                }
            ]

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    result = json.loads(await server.list_plugins(agent="Claude"))

    assert result == [
        {
            "id": "plugin-1",
            "name": "claude",
            "slug": "claude",
            "enabled": True,
            "content_length": 17,
            "content_lines": 2,
        }
    ]


@pytest.mark.anyio
async def test_list_workflows_returns_metadata_summaries(monkeypatch):
    class DummyClient:
        async def list_workflows(self, *, enabled=True, agent=None):
            assert enabled is False
            assert agent == "claude"
            return [
                {
                    "id": "wf-1",
                    "name": "Session Start",
                    "description": "Bootstrap",
                    "enabled": True,
                    "steps": [
                        {"id": "s1", "label": "Read docs"},
                        {"id": "s2", "label": "Check boards"},
                    ],
                    "version": 5,
                }
            ]

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    result = json.loads(await server.list_workflows(enabled=False, agent="Claude"))

    assert result == [
        {
            "id": "wf-1",
            "name": "Session Start",
            "description": "Bootstrap",
            "enabled": True,
            "version": 5,
            "step_count": 2,
        }
    ]


@pytest.mark.anyio
async def test_get_board_keeps_full_default_and_supports_summary(monkeypatch):
    class DummyClient:
        async def get_board(self, project_slug: str, board_id: str):
            assert project_slug == "knktx"
            assert board_id == "board-1"
            return {
                "id": board_id,
                "project_id": "proj-1",
                "name": "Targeted Content Editing",
                "description": "Plan board",
                "status": "active",
            }

        async def list_cards(self, project_slug: str, board_id: str):
            assert project_slug == "knktx"
            assert board_id == "board-1"
            return [
                {
                    "id": "card-1",
                    "board_id": board_id,
                    "title": "PR4",
                    "description": "Compact noisy MCP responses",
                    "status": "in_progress",
                    "position": 0,
                    "branch_name": "feature/mcp-response-compactness",
                    "pr_url": None,
                    "assignee": "gpt-codex-5.4",
                    "assignee_agent": {"id": "agent-1", "model_name": "gpt-codex-5.4"},
                    "source_note_id": None,
                    "metadata": {"priority": "high", "area": "mcp"},
                }
            ]

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    full_result = json.loads(await server.get_board("knktx", "board-1"))
    summary_result = json.loads(
        await server.get_board("knktx", "board-1", response_mode="summary")
    )

    assert full_result["cards"][0]["description"] == "Compact noisy MCP responses"
    assert full_result["cards"][0]["metadata"] == {"priority": "high", "area": "mcp"}
    assert summary_result["name"] == "Targeted Content Editing"
    assert summary_result["cards"] == [
        {
            "id": "card-1",
            "board_id": "board-1",
            "title": "PR4",
            "status": "in_progress",
            "position": 0,
            "branch_name": "feature/mcp-response-compactness",
            "pr_url": None,
            "assignee": "gpt-codex-5.4",
            "assignee_agent": {"id": "agent-1", "model_name": "gpt-codex-5.4"},
            "source_note_id": None,
            "description_length": 27,
            "metadata_keys": ["area", "priority"],
        }
    ]


@pytest.mark.anyio
async def test_list_cards_keeps_full_default_and_supports_summary(monkeypatch):
    class DummyClient:
        async def list_cards(self, project_slug: str, board_id: str):
            assert project_slug == "knktx"
            assert board_id == "board-1"
            return [
                {
                    "id": "card-1",
                    "board_id": board_id,
                    "title": "PR4",
                    "description": "Compact noisy MCP responses",
                    "status": "done",
                    "position": 0,
                    "branch_name": None,
                    "pr_url": "https://example.com/pr/158",
                    "assignee": "gpt-codex-5.4",
                    "assignee_agent": None,
                    "source_note_id": "note-1",
                    "metadata": {"priority": "high"},
                }
            ]

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    full_result = json.loads(await server.list_cards("knktx", "board-1"))
    summary_result = json.loads(
        await server.list_cards("knktx", "board-1", response_mode="summary")
    )

    assert full_result[0]["description"] == "Compact noisy MCP responses"
    assert full_result[0]["metadata"] == {"priority": "high"}
    assert summary_result == [
        {
            "id": "card-1",
            "board_id": "board-1",
            "title": "PR4",
            "status": "done",
            "position": 0,
            "branch_name": None,
            "pr_url": "https://example.com/pr/158",
            "assignee": "gpt-codex-5.4",
            "assignee_agent": None,
            "source_note_id": "note-1",
            "description_length": 27,
            "metadata_keys": ["priority"],
        }
    ]


@pytest.mark.anyio
async def test_update_card_keeps_full_default_and_supports_summary(monkeypatch):
    class DummyClient:
        async def update_card(self, project_slug: str, board_id: str, card_id: str, **fields):
            assert project_slug == "knktx"
            assert board_id == "board-1"
            assert card_id == "card-1"
            assert fields["title"] == "PR4"
            assert fields["agent_model"] == "gpt-codex-5.4"
            return {
                "id": card_id,
                "board_id": board_id,
                "title": fields["title"],
                "description": "Compact noisy MCP responses",
                "status": "in_progress",
                "position": 0,
                "branch_name": "feature/mcp-response-compactness",
                "pr_url": None,
                "assignee": "gpt-codex-5.4",
                "assignee_agent": None,
                "source_note_id": None,
                "metadata": {"priority": "high"},
            }

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    full_result = json.loads(
        await server.update_card(
            "knktx",
            "board-1",
            "card-1",
            title="PR4",
            agent_model="gpt-codex-5.4",
        )
    )
    summary_result = json.loads(
        await server.update_card(
            "knktx",
            "board-1",
            "card-1",
            title="PR4",
            response_mode="summary",
            agent_model="gpt-codex-5.4",
        )
    )

    assert full_result["description"] == "Compact noisy MCP responses"
    assert summary_result["description_length"] == 27
    assert summary_result["metadata_keys"] == ["priority"]


@pytest.mark.anyio
async def test_move_card_keeps_full_default_and_supports_summary(monkeypatch):
    class DummyClient:
        async def move_card(self, project_slug: str, board_id: str, card_id: str, status: str, agent_model=None):
            assert project_slug == "knktx"
            assert board_id == "board-1"
            assert card_id == "card-1"
            assert status == "done"
            assert agent_model == "gpt-codex-5.4"
            return {
                "id": card_id,
                "board_id": board_id,
                "title": "PR4",
                "description": "Compact noisy MCP responses",
                "status": status,
                "position": 0,
                "branch_name": None,
                "pr_url": None,
                "assignee": "gpt-codex-5.4",
                "assignee_agent": None,
                "source_note_id": None,
                "metadata": None,
            }

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    full_result = json.loads(
        await server.move_card(
            "knktx", "board-1", "card-1", "done", agent_model="gpt-codex-5.4"
        )
    )
    summary_result = json.loads(
        await server.move_card(
            "knktx",
            "board-1",
            "card-1",
            "done",
            response_mode="summary",
            agent_model="gpt-codex-5.4",
        )
    )

    assert full_result["description"] == "Compact noisy MCP responses"
    assert summary_result["description_length"] == 27
    assert summary_result["metadata_keys"] is None


@pytest.mark.anyio
async def test_comment_on_card_keeps_full_default_and_supports_summary(monkeypatch):
    class DummyClient:
        async def comment_on_card(self, project_slug: str, board_id: str, card_id: str, content: str, agent_model=None):
            assert project_slug == "knktx"
            assert board_id == "board-1"
            assert card_id == "card-1"
            assert content == "Looks good"
            assert agent_model == "gpt-codex-5.4"
            return {
                "id": "comment-1",
                "card_id": card_id,
                "author": "codex",
                "author_type": "agent",
                "content": content,
                "agent_user": {"id": "agent-1", "model_name": "gpt-codex-5.4"},
            }

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    full_result = json.loads(
        await server.comment_on_card(
            "knktx",
            "board-1",
            "card-1",
            "Looks good",
            agent_model="gpt-codex-5.4",
        )
    )
    summary_result = json.loads(
        await server.comment_on_card(
            "knktx",
            "board-1",
            "card-1",
            "Looks good",
            response_mode="summary",
            agent_model="gpt-codex-5.4",
        )
    )

    assert full_result["content"] == "Looks good"
    assert "content" not in summary_result
    assert summary_result["content_length"] == 10
    assert summary_result["content_lines"] == 1


@pytest.mark.anyio
async def test_list_comments_keeps_full_default_and_supports_summary(monkeypatch):
    class DummyClient:
        async def list_comments(self, project_slug: str, board_id: str, card_id: str):
            assert project_slug == "knktx"
            assert board_id == "board-1"
            assert card_id == "card-1"
            return [
                {
                    "id": "comment-1",
                    "card_id": card_id,
                    "author": "codex",
                    "author_type": "agent",
                    "content": "line one\nline two",
                    "agent_user": None,
                }
            ]

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    full_result = json.loads(await server.list_comments("knktx", "board-1", "card-1"))
    summary_result = json.loads(
        await server.list_comments(
            "knktx", "board-1", "card-1", response_mode="summary"
        )
    )

    assert full_result[0]["content"] == "line one\nline two"
    assert summary_result == [
        {
            "id": "comment-1",
            "card_id": "card-1",
            "author": "codex",
            "author_type": "agent",
            "agent_user": None,
            "content_length": 17,
            "content_lines": 2,
        }
    ]


@pytest.mark.anyio
async def test_update_comment_keeps_full_default_and_supports_summary(monkeypatch):
    class DummyClient:
        async def update_comment(
            self,
            project_slug: str,
            board_id: str,
            card_id: str,
            comment_id: str,
            content: str,
            agent_model=None,
        ):
            assert project_slug == "knktx"
            assert board_id == "board-1"
            assert card_id == "card-1"
            assert comment_id == "comment-1"
            assert content == "Updated"
            assert agent_model == "gpt-codex-5.4"
            return {
                "id": comment_id,
                "card_id": card_id,
                "author": "codex",
                "author_type": "agent",
                "content": content,
                "agent_user": None,
            }

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    full_result = json.loads(
        await server.update_comment(
            "knktx",
            "board-1",
            "card-1",
            "comment-1",
            "Updated",
            agent_model="gpt-codex-5.4",
        )
    )
    summary_result = json.loads(
        await server.update_comment(
            "knktx",
            "board-1",
            "card-1",
            "comment-1",
            "Updated",
            response_mode="summary",
            agent_model="gpt-codex-5.4",
        )
    )

    assert full_result["content"] == "Updated"
    assert summary_result["content_length"] == 7
    assert summary_result["content_lines"] == 1


@pytest.mark.anyio
async def test_create_document_summary_is_metadata_only(monkeypatch):
    class DummyClient:
        async def write_document(
            self,
            project_slug: str,
            doc_type: str,
            title: str,
            content: str,
            *,
            board_id=None,
            path=None,
            agent_model=None,
        ):
            assert project_slug == "knktx"
            assert doc_type == "handoff"
            assert title == "HANDOFF"
            assert content == "top secret"
            assert agent_model in {"gpt-codex-5.4", None}
            return {
                "id": "doc-1",
                "doc_type": doc_type,
                "title": title,
                "content": content,
                "version": 9,
            }

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    summary_result = json.loads(
        await server.create_document(
            "knktx",
            "handoff",
            "HANDOFF",
            "top secret",
            agent_model="gpt-codex-5.4",
        )
    )
    full_result = json.loads(
        await server.create_document(
            "knktx",
            "handoff",
            "HANDOFF",
            "top secret",
            response_mode="full",
        )
    )

    assert "content" not in summary_result
    assert "content_preview" not in summary_result
    assert summary_result["content_length"] == 10
    assert full_result["content"] == "top secret"


@pytest.mark.anyio
async def test_edit_note_content_defaults_to_changes_and_parses_json(monkeypatch):
    captured: dict[str, object] = {}

    class DummyClient:
        async def edit_note_content(
            self,
            note_id: str,
            operations: list[dict[str, object]],
            *,
            expected_version=None,
            response_mode="summary",
            agent_model=None,
        ):
            captured["note_id"] = note_id
            captured["operations"] = operations
            captured["expected_version"] = expected_version
            captured["response_mode"] = response_mode
            captured["agent_model"] = agent_model
            return {
                "response_mode": response_mode,
                "changed": True,
                "version": 2,
                "operations_applied": 1,
                "bytes_before": 5,
                "bytes_after": 3,
                "changes": [
                    {
                        "type": "replace",
                        "old_text": "hello",
                        "new_text": "bye",
                        "applied": True,
                    }
                ],
            }

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    result = json.loads(
        await server.edit_note_content(
            "note-1",
            '[{"type":"replace","old_text":"hello","new_text":"bye"}]',
            expected_version=4,
            agent_model="gpt-codex-5.4",
        )
    )

    assert result["response_mode"] == "changes"
    assert result["changes"] == [
        {
            "type": "replace",
            "old_text": "hello",
            "new_text": "bye",
            "applied": True,
        }
    ]
    assert captured == {
        "note_id": "note-1",
        "operations": [{"type": "replace", "old_text": "hello", "new_text": "bye"}],
        "expected_version": 4,
        "response_mode": "changes",
        "agent_model": "gpt-codex-5.4",
    }


@pytest.mark.anyio
async def test_edit_note_content_forwards_explicit_summary_mode(monkeypatch):
    captured: dict[str, object] = {}

    class DummyClient:
        async def edit_note_content(
            self,
            note_id: str,
            operations: list[dict[str, object]],
            *,
            expected_version=None,
            response_mode="changes",
            agent_model=None,
        ):
            captured["note_id"] = note_id
            captured["operations"] = operations
            captured["response_mode"] = response_mode
            return {
                "response_mode": response_mode,
                "changed": True,
                "version": 3,
                "operations_applied": 1,
                "bytes_before": 5,
                "bytes_after": 7,
            }

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    result = json.loads(
        await server.edit_note_content(
            "note-1",
            [{"type": "insert_after", "anchor": "hello", "text": " world"}],
            response_mode="summary",
        )
    )

    assert result == {
        "response_mode": "summary",
        "changed": True,
        "version": 3,
        "operations_applied": 1,
        "bytes_before": 5,
        "bytes_after": 7,
    }
    assert captured["response_mode"] == "summary"


@pytest.mark.anyio
async def test_edit_document_content_returns_error_for_invalid_json(monkeypatch):
    class DummyClient:
        async def edit_document_content(self, *args, **kwargs):
            raise AssertionError("should not be called")

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    result = await server.edit_document_content("knktx", "doc-1", "{not json}")

    assert result.startswith("Error: Invalid JSON for 'operations' parameter:")


@pytest.mark.anyio
async def test_edit_skill_file_content_rejects_non_object_operations(monkeypatch):
    class DummyClient:
        async def edit_skill_file_content(self, *args, **kwargs):
            raise AssertionError("should not be called")

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)

    result = await server.edit_skill_file_content("demo-skill", "agents/code.md", "[1]")

    assert result == "Error: 'operations' must be a JSON array of objects"


@pytest.mark.anyio
async def test_edit_document_content_rejects_oversized_json(monkeypatch):
    class DummyClient:
        async def edit_document_content(self, *args, **kwargs):
            raise AssertionError("should not be called")

    async def fake_get_client():
        return DummyClient()

    monkeypatch.setattr(server, "_get_client", fake_get_client)
    monkeypatch.setattr(server, "_MAX_JSON_ARG_CHARS", 10)

    result = await server.edit_document_content("knktx", "doc-1", "x" * 11)

    assert result == "Error: 'operations' JSON payload exceeds 10 characters"


@pytest.mark.anyio
@pytest.mark.parametrize(
    ("method_name", "args", "expected_path"),
    [
        (
            "edit_document_content",
            ("proj slug", "doc 1", [{"type": "delete", "text": "Body"}]),
            "/projects/proj%20slug/documents/doc%201/edit-content",
        ),
        (
            "edit_note_content",
            ("note 1", [{"type": "delete", "text": "Body"}]),
            "/notes/note%201/edit-content",
        ),
        (
            "edit_skill_file_content",
            ("demo skill", "agents/My file.md", [{"type": "delete", "text": "Body"}]),
            "/skills/demo%20skill/files/agents/My%20file.md/edit-content",
        ),
    ],
)
async def test_client_edit_content_methods_default_to_changes_and_escape_paths(
    monkeypatch, method_name, args, expected_path
):
    client = KnktxClient(api_url="http://example.test", api_key="test-key")
    captured: dict[str, object] = {}

    async def fake_request(method: str, path: str, **kwargs):
        captured["method"] = method
        captured["path"] = path
        captured["kwargs"] = kwargs
        return {"ok": True}

    monkeypatch.setattr(client, "_request", fake_request)

    method = getattr(client, method_name)
    result = await method(*args, expected_version=7, agent_model="gpt-codex-5.4")

    await client.aclose()

    assert result == {"ok": True}
    assert captured == {
        "method": "POST",
        "path": expected_path,
        "kwargs": {
            "json": {
                "operations": [{"type": "delete", "text": "Body"}],
                "response_mode": "changes",
                "expected_version": 7,
            },
            "agent_model": "gpt-codex-5.4",
        },
    }
