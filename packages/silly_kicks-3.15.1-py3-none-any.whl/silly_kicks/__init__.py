"""silly-kicks: classify and value on-ball football actions.

Originally developed as socceraction by Tom Decroos and Pieter Robberechts
at KU Leuven. This is an independently maintained successor.
"""

__version__ = "3.15.1"

__all__ = ["__version__"]
