"""FastAPI server: xhs.polly.wang backend.

Endpoints
---------
GET  /                          → serves index.html (single-page frontend)
GET  /manifest.webmanifest      → PWA manifest
POST /api/extract               → {url, invite_code} → {task_id}
GET  /api/task/{tid}/stream     → SSE progress feed
GET  /api/task/{tid}            → final ExtractResult JSON (once done)
GET  /healthz                   → "ok"

Invite code
-----------
Comma-separated list of allowed invite codes from env `XHSX_INVITE_CODES`.
Clients pass it either in POST body or `X-Invite-Code` header. Once validated
the frontend stores it in localStorage so subsequent visits are silent.

Rate limit
----------
Per invite code: env `XHSX_DAILY_QUOTA` (default 50). In-memory counters that
reset at UTC midnight. For low traffic this is enough; upgrade to Redis/SQLite
if needed later.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import time
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from pydantic import BaseModel
from sse_starlette.sse import EventSourceResponse

from xhsx import __version__
from xhsx.pipeline import extract as pipeline_extract

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

_WEB_DIR = Path(__file__).resolve().parent / "web"

_INVITE_CODES: set[str] = {
    c.strip() for c in os.getenv("XHSX_INVITE_CODES", "xiaoxuan2026").split(",") if c.strip()
}
_DAILY_QUOTA = int(os.getenv("XHSX_DAILY_QUOTA", "50"))
_CONCURRENCY = int(os.getenv("XHSX_CONCURRENCY", "4"))
_CORS_ORIGINS = [
    o.strip()
    for o in os.getenv(
        "XHSX_CORS_ORIGINS",
        "https://xhs.polly.wang,https://polly.wang,http://localhost:8892",
    ).split(",")
    if o.strip()
]

# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = FastAPI(title="XHSExtractor", version=__version__)

app.add_middleware(
    CORSMiddleware,
    allow_origins=_CORS_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# In-memory task state
# ---------------------------------------------------------------------------

_TASKS: dict[str, dict[str, Any]] = {}
# Per-task event queue for SSE fan-out
_QUEUES: dict[str, asyncio.Queue] = {}

# Quota: {date_iso: {invite_code: count}}
_QUOTA: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))


def _today_utc() -> str:
    return datetime.now(timezone.utc).date().isoformat()


def _check_and_consume_quota(code: str) -> tuple[bool, int, int]:
    today = _today_utc()
    used = _QUOTA[today][code]
    if used >= _DAILY_QUOTA:
        return False, used, _DAILY_QUOTA
    _QUOTA[today][code] = used + 1
    return True, used + 1, _DAILY_QUOTA


# ---------------------------------------------------------------------------
# URL helpers
# ---------------------------------------------------------------------------

_URL_RE = re.compile(
    r"https?://(?:xhslink\.com|(?:www\.)?xiaohongshu\.com|xhslink\.com)/\S+",
    re.IGNORECASE,
)


def _extract_url(raw: str) -> str | None:
    """Pull the first xhs URL out of a user-pasted blob (which may contain
    the whole share-card text: '2 四象现发布了一篇小红书笔记... http://xhslink.com/a/xxx ...')"""
    if not raw:
        return None
    m = _URL_RE.search(raw)
    if m:
        return m.group(0).rstrip("，。,.;；、)）]】>》")
    return None


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class ExtractIn(BaseModel):
    url: str
    invite_code: str | None = None


class ExtractOut(BaseModel):
    task_id: str


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@app.get("/healthz")
async def healthz() -> dict:
    return {"status": "ok", "version": __version__}


@app.get("/", response_class=HTMLResponse)
async def index() -> HTMLResponse:
    path = _WEB_DIR / "index.html"
    if not path.is_file():
        return HTMLResponse(
            "<h1>XHSExtractor</h1><p>Frontend not installed. See /docs for API.</p>",
            status_code=200,
        )
    return HTMLResponse(path.read_text(encoding="utf-8"))


@app.get("/manifest.webmanifest")
async def manifest() -> Response:
    path = _WEB_DIR / "manifest.webmanifest"
    if path.is_file():
        return FileResponse(path, media_type="application/manifest+json")
    return JSONResponse({"error": "not found"}, status_code=404)


@app.get("/icon.svg")
async def icon_svg() -> Response:
    path = _WEB_DIR / "icon.svg"
    if path.is_file():
        return FileResponse(path, media_type="image/svg+xml")
    return Response(status_code=404)


def _verify_invite(code: str | None) -> str:
    if not code or code not in _INVITE_CODES:
        raise HTTPException(status_code=401, detail="invalid_invite_code")
    return code


@app.post("/api/extract", response_model=ExtractOut)
async def api_extract(body: ExtractIn, request: Request) -> ExtractOut:
    code = body.invite_code or request.headers.get("x-invite-code")
    code = _verify_invite(code)

    ok, used, quota = _check_and_consume_quota(code)
    if not ok:
        raise HTTPException(status_code=429, detail=f"daily_quota_exceeded ({used}/{quota})")

    url = _extract_url(body.url)
    if not url:
        raise HTTPException(status_code=400, detail="no_xhs_url_found")

    tid = uuid.uuid4().hex[:12]
    queue: asyncio.Queue = asyncio.Queue()
    _QUEUES[tid] = queue
    _TASKS[tid] = {
        "status": "pending",
        "url": url,
        "invite_code": code,
        "created_at": time.time(),
        "result": None,
        "error": None,
    }

    asyncio.create_task(_run_task(tid, url))
    return ExtractOut(task_id=tid)


async def _run_task(tid: str, url: str) -> None:
    task = _TASKS[tid]
    queue = _QUEUES[tid]
    loop = asyncio.get_running_loop()

    def on_progress(stage: str, data: dict) -> None:
        # Called from the pipeline — schedule non-blocking put.
        loop.call_soon_threadsafe(queue.put_nowait, {"event": stage, "data": data})

    task["status"] = "running"
    try:
        result = await pipeline_extract(url, concurrency=_CONCURRENCY, on_progress=on_progress)
        task["result"] = result.model_dump()
        task["status"] = "done"
        await queue.put(
            {
                "event": "result",
                "data": {
                    "markdown": result.merged_article,
                    "title": result.note.title,
                    "author": result.note.author,
                    "image_count": len(result.note.images),
                    "elapsed": result.elapsed_sec,
                },
            }
        )
    except Exception as e:  # noqa: BLE001
        task["status"] = "error"
        task["error"] = str(e)
        await queue.put({"event": "error", "data": {"message": str(e)}})
    finally:
        await queue.put({"event": "close", "data": {}})


@app.get("/api/task/{tid}/stream")
async def api_task_stream(tid: str):
    if tid not in _QUEUES:
        raise HTTPException(status_code=404, detail="task_not_found")
    queue = _QUEUES[tid]

    async def gen():
        while True:
            evt = await queue.get()
            name = evt["event"]
            yield {"event": name, "data": json.dumps(evt["data"], ensure_ascii=False)}
            if name in ("close", "error"):
                break

    return EventSourceResponse(gen())


@app.get("/api/task/{tid}")
async def api_task_get(tid: str) -> dict:
    if tid not in _TASKS:
        raise HTTPException(status_code=404, detail="task_not_found")
    t = _TASKS[tid]
    return {
        "task_id": tid,
        "status": t["status"],
        "error": t["error"],
        "result": t["result"],
    }
