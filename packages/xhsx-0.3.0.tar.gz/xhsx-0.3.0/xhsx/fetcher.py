"""Fetch & parse Xiaohongshu notes via headless browser.

Strategy:
1. Resolve short links (xhslink.com → www.xiaohongshu.com/explore/<id>)
2. Open page with Playwright (chromium headless)
3. Extract from `window.__INITIAL_STATE__` (primary) or DOM fallback
"""

from __future__ import annotations

import asyncio
import json
import re
from typing import Any

import httpx
from playwright.async_api import async_playwright

from xhsx.models import Note

XHSLINK_RE = re.compile(r"https?://(?:www\.)?xhslink\.com/[A-Za-z0-9/]+")
EXPLORE_RE = re.compile(r"xiaohongshu\.com/(?:explore|discovery/item)/([A-Za-z0-9]+)")

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)


async def resolve_short_link(url: str) -> str:
    """Follow xhslink.com redirects to the canonical explore URL."""
    if "xhslink.com" not in url:
        return url
    async with httpx.AsyncClient(
        follow_redirects=True,
        timeout=10.0,
        headers={"User-Agent": USER_AGENT},
    ) as client:
        resp = await client.get(url)
        return str(resp.url)


def _extract_note_id(url: str) -> str:
    m = EXPLORE_RE.search(url)
    if m:
        return m.group(1)
    raise ValueError(f"Cannot parse note id from URL: {url}")


def _parse_initial_state(html: str) -> dict[str, Any] | None:
    """Extract window.__INITIAL_STATE__ JSON blob."""
    # Xiaohongshu injects: window.__INITIAL_STATE__={...}</script>
    m = re.search(
        r"window\.__INITIAL_STATE__\s*=\s*(\{.*?\})\s*</script>",
        html,
        re.DOTALL,
    )
    if not m:
        return None
    raw = m.group(1)
    # xhs sometimes uses `undefined` literals — sanitize to null
    raw = re.sub(r":\s*undefined\b", ": null", raw)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return None


def _note_from_state(state: dict[str, Any], note_id: str, url: str) -> Note | None:
    """Pull the note object out of __INITIAL_STATE__."""
    # Path observed: state["note"]["noteDetailMap"][note_id]["note"]
    try:
        detail_map = state.get("note", {}).get("noteDetailMap") or {}
        entry = detail_map.get(note_id) or next(iter(detail_map.values()), None)
        if not entry:
            return None
        note = entry.get("note") or {}
    except Exception:
        return None

    title = note.get("title", "") or ""
    desc = note.get("desc", "") or ""
    author = (note.get("user") or {}).get("nickname", "") or ""

    images: list[str] = []
    for img in note.get("imageList") or []:
        # Prefer the highest-res URL
        url_default = img.get("urlDefault") or img.get("url") or ""
        if url_default:
            images.append(url_default)

    video_url = None
    video = note.get("video") or {}
    streams = (video.get("media") or {}).get("stream") or {}
    for _codec, variants in streams.items():
        if variants:
            video_url = (variants[0] or {}).get("masterUrl")
            if video_url:
                break

    tags = [
        t.get("name", "")
        for t in (note.get("tagList") or [])
        if t.get("name")
    ]

    return Note(
        note_id=note_id,
        url=url,
        title=title,
        desc=desc,
        author=author,
        images=images,
        video_url=video_url,
        tags=tags,
    )


async def fetch_note(url: str, *, headless: bool = True, timeout: int = 20000) -> Note:
    """Fetch a Xiaohongshu note and return structured data.

    Raises ValueError if parsing fails.
    """
    canonical = await resolve_short_link(url)
    note_id = _extract_note_id(canonical)

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=headless)
        context = await browser.new_context(user_agent=USER_AGENT, locale="zh-CN")
        page = await context.new_page()
        try:
            await page.goto(canonical, timeout=timeout, wait_until="domcontentloaded")
            # Wait a tick for __INITIAL_STATE__ to be populated
            await page.wait_for_function(
                "() => !!window.__INITIAL_STATE__",
                timeout=timeout,
            )
            html = await page.content()
        finally:
            await context.close()
            await browser.close()

    state = _parse_initial_state(html)
    if not state:
        raise ValueError("Failed to locate __INITIAL_STATE__ in page HTML")

    note = _note_from_state(state, note_id, canonical)
    if not note:
        raise ValueError(f"Note {note_id} not found in state (login-walled or deleted?)")
    note.raw_html_len = len(html)
    return note


def fetch_note_sync(url: str, **kw: Any) -> Note:
    return asyncio.run(fetch_note(url, **kw))
