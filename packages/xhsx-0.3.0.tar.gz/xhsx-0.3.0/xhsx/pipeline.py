"""Pipeline: URL → faithful Markdown article.

Single path: fetch → per-page OCR → stitch → Markdown.
No LLM rewriting, no summarization.
"""

from __future__ import annotations

import re
import time
from typing import Callable

from xhsx.fetcher import fetch_note
from xhsx.llm import ocr_images
from xhsx.models import ExtractResult


async def extract(
    url: str,
    *,
    concurrency: int = 4,
    headless: bool = True,
    on_progress: "Callable[[str, dict], None] | None" = None,
) -> ExtractResult:
    """Extract and format a Xiaohongshu note as Markdown.

    `on_progress(stage, data)` is called with progress events:
        ("fetching", {})
        ("fetched", {"title": str, "author": str, "image_count": int})
        ("ocr", {"done": int, "total": int})
        ("done", {"elapsed": float})
    """
    def _emit(stage: str, data: dict | None = None) -> None:
        if on_progress:
            try:
                on_progress(stage, data or {})
            except Exception:
                pass

    t0 = time.time()
    _emit("fetching", {"url": url})
    note = await fetch_note(url, headless=headless)
    _emit(
        "fetched",
        {
            "title": note.title,
            "author": note.author,
            "image_count": len(note.images),
        },
    )

    ocr_texts: list[str] = []
    if note.images:
        def _on_done(done: int, total: int) -> None:
            _emit("ocr", {"done": done, "total": total})

        ocr_texts = await ocr_images(
            note.images, concurrency=concurrency, on_done=_on_done
        )

    markdown = _assemble_markdown(
        note.title, note.desc, note.author, note.tags, note.url, ocr_texts
    )

    elapsed = round(time.time() - t0, 2)
    _emit("done", {"elapsed": elapsed})

    return ExtractResult(
        note=note,
        ocr_texts=ocr_texts,
        merged_article=markdown,
        elapsed_sec=elapsed,
    )


# ---------------------------------------------------------------------------
# Page-boundary stitching (heuristic, no LLM)
# ---------------------------------------------------------------------------

_ENDING_PUNCT = set("。！？!?.;:；：、…")
_CLOSING_PUNCT = set("”\"’'」』）)]】》>")
_TOPIC_RE = re.compile(r"#([^#\[\]]+)\[话题\]#")

# "名字，" or "名字：" — short Chinese noun (2-4 chars) that starts a new list item
_LIST_ITEM_RE = re.compile(r"^[\u4e00-\u9fa5]{2,4}[，,、：:]")


def _last_visible_char(s: str) -> str:
    s = s.rstrip()
    while s and s[-1] in _CLOSING_PUNCT:
        s = s[:-1]
    return s[-1] if s else ""


def _looks_like_new_paragraph(nxt: str) -> bool:
    """Return True if `nxt` clearly begins a new paragraph/list item."""
    if not nxt:
        return True
    first = nxt.lstrip()
    if not first:
        return True
    if first.startswith(("#", "-", "*", ">", "•", "　")):
        return True
    if _LIST_ITEM_RE.match(first):
        return True
    return False


def _join_pages_faithfully(pages: list[str]) -> str:
    """Concatenate OCR pages; glue mid-sentence cross-page breaks, but keep
    paragraph breaks when the next page clearly starts a new unit."""
    cleaned = [
        p.strip()
        for p in pages
        if p and p.strip() and not p.startswith("[OCR failed")
    ]
    if not cleaned:
        return ""

    result = cleaned[0]
    for nxt in cleaned[1:]:
        last = _last_visible_char(result)
        mid_sentence = bool(last) and last not in _ENDING_PUNCT and not last.isspace()
        new_para = _looks_like_new_paragraph(nxt)
        if mid_sentence and not new_para:
            result = result.rstrip() + nxt.lstrip()
        else:
            result = result.rstrip() + "\n\n" + nxt.lstrip()
    return result


def _split_title_from_body(body: str) -> tuple[str, str]:
    """If the OCR body starts with a short headline followed by a blank line,
    treat it as a title."""
    lines = body.split("\n")
    buf: list[str] = []
    i = 0
    while i < len(lines) and lines[i].strip():
        buf.append(lines[i].strip())
        i += 1
    while i < len(lines) and not lines[i].strip():
        i += 1
    head = " ".join(buf).strip()
    if head and len(head) <= 30 and not any(c in _ENDING_PUNCT for c in head):
        rest = "\n".join(lines[i:]).strip()
        return head, rest
    return "", body


def _clean_desc(desc: str) -> tuple[str, list[str]]:
    """Return (cleaned_desc, inline_tags)."""
    if not desc:
        return "", []
    tags = _TOPIC_RE.findall(desc)
    cleaned = _TOPIC_RE.sub("", desc).strip().rstrip("#").strip()
    return cleaned, tags


def _assemble_markdown(
    title: str,
    desc: str,
    author: str,
    tags: list[str],
    url: str,
    ocr_texts: list[str],
) -> str:
    body = _join_pages_faithfully(ocr_texts)
    ocr_title, body_rest = _split_title_from_body(body)

    h1 = (title or ocr_title or "").strip()
    desc_clean, topic_tags = _clean_desc(desc)

    all_tags: list[str] = []
    for t in (tags or []) + topic_tags:
        t = t.strip()
        if t and t not in all_tags:
            all_tags.append(t)

    parts: list[str] = []
    if h1:
        parts.append(f"# {h1}")
    if author:
        parts.append(f"*作者：{author}*")
    if desc_clean:
        parts.append(f"> {desc_clean}")
    if body_rest:
        parts.append(body_rest)
    elif body and not h1:
        parts.append(body)

    if all_tags:
        parts.append(" ".join(f"`#{t}`" for t in all_tags))

    if url:
        parts.append(f"---\n\n*原文链接：{url}*")

    return "\n\n".join(p for p in parts if p).strip() + "\n"
