"""XHSExtractor — Xiaohongshu note → coherent article."""

from pathlib import Path as _Path

from dotenv import load_dotenv as _load_dotenv

# Auto-load .env from project root and current working dir
for _p in (_Path(__file__).resolve().parent.parent / ".env", _Path.cwd() / ".env"):
    if _p.is_file():
        _load_dotenv(_p, override=False)

from xhsx.models import Note, ExtractResult  # noqa: E402

__version__ = "0.3.0"
__all__ = ["Note", "ExtractResult"]
