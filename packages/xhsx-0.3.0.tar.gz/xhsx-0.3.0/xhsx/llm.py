"""Vision OCR via CopilotX (OpenAI-compatible).

Env:
    COPILOTX_BASE_URL  default: https://api.polly.wang/v1
    COPILOTX_API_KEY   default: copilotx
    XHSX_VISION_MODEL  default: gpt-4o
"""

from __future__ import annotations

import asyncio
import base64
import mimetypes
import os
from typing import Callable, Iterable

import httpx
from openai import AsyncOpenAI


def _client() -> AsyncOpenAI:
    return AsyncOpenAI(
        base_url=os.getenv("COPILOTX_BASE_URL", "https://api.polly.wang/v1"),
        api_key=os.getenv("COPILOTX_API_KEY", "copilotx"),
    )


VISION_MODEL = os.getenv("XHSX_VISION_MODEL", "gpt-4o")

_XHSCDN_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    ),
    "Referer": "https://www.xiaohongshu.com/",
}


async def _download_as_data_url(url: str, client: httpx.AsyncClient) -> str:
    """Fetch an image and inline it as data:URL (vision APIs require it)."""
    resp = await client.get(url, headers=_XHSCDN_HEADERS, timeout=20.0)
    resp.raise_for_status()
    ctype = resp.headers.get("content-type", "").split(";")[0].strip()
    if not ctype or not ctype.startswith("image/"):
        guess = mimetypes.guess_type(url)[0]
        ctype = guess or "image/webp"
    b64 = base64.b64encode(resp.content).decode("ascii")
    return f"data:{ctype};base64,{b64}"


OCR_PROMPT = (
    "请提取图片中的全部文字，严格保持原有顺序、换行与段落结构。"
    "只输出文字，不要任何解释、标题或 Markdown 装饰。"
    "如果图中没有文字，输出一个英文短横线：-"
)


async def ocr_image(
    image_url: str,
    *,
    model: str = VISION_MODEL,
    http: httpx.AsyncClient | None = None,
) -> str:
    """OCR a single image. Downloads http(s) URLs and inlines as data URL."""
    owns_client = http is None
    client_http = http or httpx.AsyncClient()
    try:
        if image_url.startswith("http"):
            data_url = await _download_as_data_url(image_url, client_http)
        else:
            data_url = image_url
        client = _client()
        resp = await client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": OCR_PROMPT},
                        {"type": "image_url", "image_url": {"url": data_url}},
                    ],
                }
            ],
            temperature=0.0,
        )
        return (resp.choices[0].message.content or "").strip()
    finally:
        if owns_client:
            await client_http.aclose()


async def ocr_images(
    image_urls: Iterable[str],
    *,
    model: str = VISION_MODEL,
    concurrency: int = 4,
    on_done: "Callable[[int, int], None] | None" = None,
) -> list[str]:
    """OCR many images concurrently. Order preserved.

    on_done(done, total) is called every time a single image finishes
    (regardless of order).
    """
    sem = asyncio.Semaphore(concurrency)
    urls = list(image_urls)
    total = len(urls)
    done = 0
    lock = asyncio.Lock()

    async with httpx.AsyncClient() as http:
        async def _one(u: str) -> str:
            nonlocal done
            async with sem:
                try:
                    res = await ocr_image(u, model=model, http=http)
                except Exception as e:
                    res = f"[OCR failed: {e}]"
            async with lock:
                done += 1
                if on_done:
                    try:
                        on_done(done, total)
                    except Exception:
                        pass
            return res

        return await asyncio.gather(*[_one(u) for u in urls])
