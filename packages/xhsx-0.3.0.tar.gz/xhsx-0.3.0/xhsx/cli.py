"""Typer CLI — `xhsx <url>`."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from xhsx import __version__
from xhsx.pipeline import extract

app = typer.Typer(
    add_completion=False,
    help="XHSExtractor — 小红书链接 → 逐字还原的 Markdown 文章",
    no_args_is_help=True,
)
console = Console()


def _print_result(result) -> None:
    note = result.note
    meta = Table(show_header=False, box=None, pad_edge=False)
    meta.add_column(style="bold cyan", no_wrap=True)
    meta.add_column()
    meta.add_row("作者", note.author or "(无)")
    meta.add_row("图片", f"{len(note.images)} 张")
    if note.tags:
        meta.add_row("标签", " ".join(f"#{t}" for t in note.tags))
    meta.add_row("耗时", f"{result.elapsed_sec}s")
    console.print(Panel(meta, title="📔 笔记信息", border_style="cyan"))

    console.print()
    console.print(Panel(
        Markdown(result.merged_article),
        title="✨ 文章",
        border_style="green",
    ))


@app.command()
def extract_cmd(
    url: str = typer.Argument(..., help="小红书链接（xhslink.com 短链或 explore 长链）"),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o", help="写入文件（.md / .json）"
    ),
    json_out: bool = typer.Option(False, "--json", help="以 JSON 输出到 stdout"),
    concurrency: int = typer.Option(4, "--concurrency", "-c", help="OCR 并发数"),
    headed: bool = typer.Option(False, "--headed", help="显示浏览器窗口（调试用）"),
) -> None:
    """抓取小红书笔记，OCR 每页，拼成一篇 Markdown。"""
    with console.status("[bold blue]Fetching & OCR..."):
        result = asyncio.run(extract(
            url,
            concurrency=concurrency,
            headless=not headed,
        ))

    if json_out:
        sys.stdout.write(result.model_dump_json(indent=2, ensure_ascii=False))
        sys.stdout.write("\n")
        return

    if output:
        if output.suffix == ".json":
            output.write_text(
                result.model_dump_json(indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        else:
            md = result.merged_article.rstrip() + "\n"
            if result.note.images and "## 原图" not in md:
                md += "\n---\n\n## 原图\n\n"
                for u in result.note.images:
                    md += f"![]({u})\n\n"
            output.write_text(md, encoding="utf-8")
        console.print(f"[green]✓ 已写入 {output}[/green]")
        return

    _print_result(result)


@app.command()
def version() -> None:
    """Print version."""
    console.print(f"xhsx {__version__}")


@app.command()
def serve(
    host: str = typer.Option("127.0.0.1", "--host", help="Bind host"),
    port: int = typer.Option(8892, "--port", help="Bind port"),
    reload: bool = typer.Option(False, "--reload", help="Uvicorn auto-reload (dev)"),
) -> None:
    """Run the FastAPI web server (xhs.polly.wang backend)."""
    try:
        import uvicorn
    except ImportError:
        console.print(
            "[red]Missing server extras.[/red] Install with: "
            "[bold]pip install 'xhsx[server]'[/bold]"
        )
        raise typer.Exit(code=1)

    console.print(f"[bold green]xhsx {__version__}[/bold green] serving on http://{host}:{port}")
    uvicorn.run("xhsx.server:app", host=host, port=port, reload=reload)


# Allow `xhsx <url>` without explicit subcommand
def _main() -> None:
    if len(sys.argv) >= 2 and sys.argv[1].startswith("http"):
        sys.argv.insert(1, "extract-cmd")
    app()


if __name__ == "__main__":
    _main()
