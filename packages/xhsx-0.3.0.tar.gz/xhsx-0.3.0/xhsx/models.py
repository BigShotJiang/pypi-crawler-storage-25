"""Data models."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class Note(BaseModel):
    """Parsed Xiaohongshu note."""

    note_id: str
    url: str
    title: str = ""
    desc: str = ""
    author: str = ""
    images: list[str] = Field(default_factory=list)
    video_url: Optional[str] = None
    tags: list[str] = Field(default_factory=list)
    raw_html_len: int = 0


class ExtractResult(BaseModel):
    """End-to-end extraction result."""

    note: Note
    ocr_texts: list[str] = Field(default_factory=list)
    merged_article: str = ""
    cost_usd: float = 0.0
    elapsed_sec: float = 0.0
