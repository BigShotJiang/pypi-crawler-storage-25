# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: ags_py_codegen

# pylint: disable=duplicate-code
# pylint: disable=line-too-long
# pylint: disable=missing-function-docstring
# pylint: disable=missing-module-docstring
# pylint: disable=too-many-arguments
# pylint: disable=too-many-branches
# pylint: disable=too-many-instance-attributes
# pylint: disable=too-many-lines
# pylint: disable=too-many-locals
# pylint: disable=too-many-public-methods
# pylint: disable=too-many-return-statements
# pylint: disable=too-many-statements
# pylint: disable=unused-import

# AccelByte Gaming Services Challenge Service

from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple, Union

from .....core import Operation
from .....core import HeaderStr
from .....core import HttpResponse

from ...models import IamErrorResponse
from ...models import ModelEvaluatePlayerProgressionRequest
from ...models import ResponseError


class AdminEvaluateProgress(Operation):
    """Evaluate User's Progressions (adminEvaluateProgress)

    - Required permission: ADMIN:NAMESPACE:{namespace}:CHALLENGE:PROGRESSION [UPDATE]
    - Limited up to 10 users per request

    Properties:
        url: /challenge/v1/admin/namespaces/{namespace}/progress/evaluate

        method: POST

        tags: ["Challenge Progression"]

        consumes: ["application/json"]

        produces: ["application/json"]

        securities: [BEARER_AUTH]

        body: (body) REQUIRED ModelEvaluatePlayerProgressionRequest in body

        namespace: (namespace) REQUIRED str in path

        challenge_code: (challengeCode) OPTIONAL List[str] in query

        include_one_time_event: (includeOneTimeEvent) OPTIONAL str in query

    Responses:
        204: No Content - (No Content)

        400: Bad Request - IamErrorResponse (20018: bad request: {{message}})

        401: Unauthorized - IamErrorResponse (20001: unauthorized access)

        403: Forbidden - IamErrorResponse (20013: insufficient permission)

        404: Not Found - ResponseError (20029: not found)

        500: Internal Server Error - ResponseError (20000: internal server error: {{message}})
    """

    # region fields

    _url: str = "/challenge/v1/admin/namespaces/{namespace}/progress/evaluate"
    _method: str = "POST"
    _consumes: List[str] = ["application/json"]
    _produces: List[str] = ["application/json"]
    _securities: List[List[str]] = [["BEARER_AUTH"]]
    _location_query: str = None

    body: ModelEvaluatePlayerProgressionRequest  # REQUIRED in [body]
    namespace: str  # REQUIRED in [path]
    challenge_code: List[str]  # OPTIONAL in [query]
    include_one_time_event: str  # OPTIONAL in [query]

    # endregion fields

    # region properties

    @property
    def url(self) -> str:
        return self._url

    @property
    def method(self) -> str:
        return self._method

    @property
    def consumes(self) -> List[str]:
        return self._consumes

    @property
    def produces(self) -> List[str]:
        return self._produces

    @property
    def securities(self) -> List[List[str]]:
        return self._securities

    @property
    def location_query(self) -> str:
        return self._location_query

    # endregion properties

    # region get methods

    # endregion get methods

    # region get_x_params methods

    def get_all_params(self) -> dict:
        return {
            "body": self.get_body_params(),
            "path": self.get_path_params(),
            "query": self.get_query_params(),
        }

    def get_body_params(self) -> Any:
        if not hasattr(self, "body") or self.body is None:
            return None
        return self.body.to_dict()

    def get_path_params(self) -> dict:
        result = {}
        if hasattr(self, "namespace"):
            result["namespace"] = self.namespace
        return result

    def get_query_params(self) -> dict:
        result = {}
        if hasattr(self, "challenge_code"):
            result["challengeCode"] = self.challenge_code
        if hasattr(self, "include_one_time_event"):
            result["includeOneTimeEvent"] = self.include_one_time_event
        return result

    # endregion get_x_params methods

    # region is/has methods

    # endregion is/has methods

    # region with_x methods

    def with_body(
        self, value: ModelEvaluatePlayerProgressionRequest
    ) -> AdminEvaluateProgress:
        self.body = value
        return self

    def with_namespace(self, value: str) -> AdminEvaluateProgress:
        self.namespace = value
        return self

    def with_challenge_code(self, value: List[str]) -> AdminEvaluateProgress:
        self.challenge_code = value
        return self

    def with_include_one_time_event(self, value: str) -> AdminEvaluateProgress:
        self.include_one_time_event = value
        return self

    # endregion with_x methods

    # region to methods

    def to_dict(self, include_empty: bool = False) -> dict:
        result: dict = {}
        if hasattr(self, "body") and self.body:
            result["body"] = self.body.to_dict(include_empty=include_empty)
        elif include_empty:
            result["body"] = ModelEvaluatePlayerProgressionRequest()
        if hasattr(self, "namespace") and self.namespace:
            result["namespace"] = str(self.namespace)
        elif include_empty:
            result["namespace"] = ""
        if hasattr(self, "challenge_code") and self.challenge_code:
            result["challengeCode"] = [str(i0) for i0 in self.challenge_code]
        elif include_empty:
            result["challengeCode"] = []
        if hasattr(self, "include_one_time_event") and self.include_one_time_event:
            result["includeOneTimeEvent"] = str(self.include_one_time_event)
        elif include_empty:
            result["includeOneTimeEvent"] = ""
        return result

    # endregion to methods

    # region response methods

    # noinspection PyMethodMayBeStatic
    def parse_response(
        self, code: int, content_type: str, content: Any
    ) -> Tuple[None, Union[None, HttpResponse, IamErrorResponse, ResponseError]]:
        """Parse the given response.

        204: No Content - (No Content)

        400: Bad Request - IamErrorResponse (20018: bad request: {{message}})

        401: Unauthorized - IamErrorResponse (20001: unauthorized access)

        403: Forbidden - IamErrorResponse (20013: insufficient permission)

        404: Not Found - ResponseError (20029: not found)

        500: Internal Server Error - ResponseError (20000: internal server error: {{message}})

        ---: HttpResponse (Undocumented Response)

        ---: HttpResponse (Unexpected Content-Type Error)

        ---: HttpResponse (Unhandled Error)
        """
        pre_processed_response, error = self.pre_process_response(
            code=code, content_type=content_type, content=content
        )
        if error is not None:
            return None, None if error.is_no_content() else error
        code, content_type, content = pre_processed_response

        if code == 204:
            return None, None
        if code == 400:
            return None, IamErrorResponse.create_from_dict(content)
        if code == 401:
            return None, IamErrorResponse.create_from_dict(content)
        if code == 403:
            return None, IamErrorResponse.create_from_dict(content)
        if code == 404:
            return None, ResponseError.create_from_dict(content)
        if code == 500:
            return None, ResponseError.create_from_dict(content)

        return self.handle_undocumented_response(
            code=code, content_type=content_type, content=content
        )

    # endregion response methods

    # region static methods

    @classmethod
    def create(
        cls,
        body: ModelEvaluatePlayerProgressionRequest,
        namespace: str,
        challenge_code: Optional[List[str]] = None,
        include_one_time_event: Optional[str] = None,
        **kwargs,
    ) -> AdminEvaluateProgress:
        instance = cls()
        instance.body = body
        instance.namespace = namespace
        if challenge_code is not None:
            instance.challenge_code = challenge_code
        if include_one_time_event is not None:
            instance.include_one_time_event = include_one_time_event
        if x_flight_id := kwargs.get("x_flight_id", None):
            instance.x_flight_id = x_flight_id
        return instance

    @classmethod
    def create_from_dict(
        cls, dict_: dict, include_empty: bool = False
    ) -> AdminEvaluateProgress:
        instance = cls()
        if "body" in dict_ and dict_["body"] is not None:
            instance.body = ModelEvaluatePlayerProgressionRequest.create_from_dict(
                dict_["body"], include_empty=include_empty
            )
        elif include_empty:
            instance.body = ModelEvaluatePlayerProgressionRequest()
        if "namespace" in dict_ and dict_["namespace"] is not None:
            instance.namespace = str(dict_["namespace"])
        elif include_empty:
            instance.namespace = ""
        if "challengeCode" in dict_ and dict_["challengeCode"] is not None:
            instance.challenge_code = [str(i0) for i0 in dict_["challengeCode"]]
        elif include_empty:
            instance.challenge_code = []
        if "includeOneTimeEvent" in dict_ and dict_["includeOneTimeEvent"] is not None:
            instance.include_one_time_event = str(dict_["includeOneTimeEvent"])
        elif include_empty:
            instance.include_one_time_event = ""
        return instance

    @staticmethod
    def get_field_info() -> Dict[str, str]:
        return {
            "body": "body",
            "namespace": "namespace",
            "challengeCode": "challenge_code",
            "includeOneTimeEvent": "include_one_time_event",
        }

    @staticmethod
    def get_required_map() -> Dict[str, bool]:
        return {
            "body": True,
            "namespace": True,
            "challengeCode": False,
            "includeOneTimeEvent": False,
        }

    @staticmethod
    def get_collection_format_map() -> Dict[str, Union[None, str]]:
        return {
            "challengeCode": "csv",  # in query
        }

    # endregion static methods
