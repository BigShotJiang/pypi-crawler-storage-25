"""Tests for media types and schema field builders."""

from __future__ import annotations

from pathlib import Path
import shutil
import sys

import pytest

SDK_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SDK_ROOT))

from aimp_sdk.agent_loader import load_mode_runtime  # noqa: E402
from aimp_sdk.media_types import (  # noqa: E402
    AudioRef,
    FileRef,
    ImageRef,
    IndexResult,
    JsonRef,
    MediaLoadError,
    MediaRef,
    SearchResult,
    TYPE_KIND_MAP,
    TextRef,
    VideoRef,
    get_kind_for_type,
)

FRAMEWORK_TEMPLATE_MODULES = (
    Path(__file__).resolve().parents[2]
    / "framework"
    / "aimp_framework"
    / "project_template"
    / "test_modules"
)


def _write_module(tmp_path: Path, template_name: str) -> str:
    module_path = tmp_path / "agent.py"
    source_template = FRAMEWORK_TEMPLATE_MODULES / template_name
    shutil.copy2(source_template, module_path)
    return str(module_path)


def test_media_refs_load_bytes_and_fail_without_source() -> None:
    assert ImageRef(bytes_data=b"img").load_bytes() == b"img"
    assert AudioRef(bytes_data=b"aud").load() == b"aud"
    assert VideoRef(bytes_data=b"vid").load() == b"vid"
    assert FileRef(bytes_data=b"file").load() == b"file"
    assert TextRef(bytes_data=b"hello").load() == "hello"
    assert JsonRef(bytes_data=b'{"key": "value"}').load() == {"key": "value"}
    with pytest.raises(MediaLoadError):
        MediaRef().load_bytes()


def test_type_kind_map_and_result_defaults() -> None:
    assert TYPE_KIND_MAP[ImageRef] == "image"
    assert TYPE_KIND_MAP[str] == "text"
    assert get_kind_for_type(ImageRef) == "image"
    assert SearchResult(results=[{"id": "1"}]).total == 1
    assert IndexResult(vector_id="abc123").indexed is True


def test_schema_builders_support_media_and_select_fields(tmp_path: Path) -> None:
    module_path = _write_module(tmp_path, "functional_mode_media_compare.py")
    runtime = load_mode_runtime(str(module_path))
    spec = runtime.mode_specs()["compare"]
    # v2 mode specs expose schema via inputs/outputs/parameters
    assert "image" in spec.inputs.fields
    assert spec.inputs.fields["image"].kind == "image"
    assert spec.inputs.fields["notes"].kind == "text"
    assert "output_format" in spec.parameters.fields
    assert spec.parameters.fields["output_format"].kind == "select"
