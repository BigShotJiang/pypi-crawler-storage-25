"""Tests for functional mode -> model orchestration runtime."""

from __future__ import annotations

import json
import os
from pathlib import Path
import selectors
import subprocess
import shutil
import sys

import pytest

SDK_ROOT = Path(__file__).resolve().parents[1]
FRAMEWORK_ROOT = SDK_ROOT.parents[0] / "framework"
for key in list(sys.modules):
    if key == "aimp_sdk" or key.startswith("aimp_sdk."):
        sys.modules.pop(key, None)
sys.path.insert(0, str(SDK_ROOT))

from aimp_sdk.agent_loader import load_agent_contract  # noqa: E402
from aimp_sdk.agent_runner import AgentRunner  # noqa: E402


def _write_modes_agent(
    tmp_path: Path,
    template_name: str = "pipeline_runtime_agent.py",
) -> str:
    agent_dir = tmp_path / "app"
    agent_dir.mkdir(parents=True, exist_ok=True)
    (agent_dir / "__init__.py").write_text("", encoding="utf-8")
    (agent_dir / "contract.toml").write_text(
        "[agent]\n"
        'name = "semantic-search"\n'
        'version = "1.0.0"\n'
        'author = "username"\n'
        'description = "Semantic search over documents"\n',
        encoding="utf-8",
    )
    template_root = (
        Path(__file__).resolve().parents[2]
        / "framework"
        / "aimp_framework"
        / "project_template"
        / "test_modules"
    )
    shutil.copy2(template_root / template_name, agent_dir / "agent.py")
    return str(agent_dir / "agent.py")


def _execution_context(tmp_path: Path, *, request_id: str) -> dict[str, object]:
    return {
        "model_id": "model-123",
        "request_id": request_id,
        "artifacts_dir": str(tmp_path / "artifacts"),
        "cache_dir": str(tmp_path / "cache"),
        "work_dir": str(tmp_path / request_id),
        "limits": {"cpu": "1", "memory_mb": 128, "timeout_seconds": 30},
        "accelerator": {"kind": "cpu", "backend": None, "count": 0, "identifiers": []},
    }


def test_mode_based_agent_runner_dispatches_to_handlers(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    module_path = _write_modes_agent(tmp_path)
    monkeypatch.setenv("AIMP_MODEL_ID", "model-123")
    runner = AgentRunner(module_path)
    runner.start()

    index_response = runner.handle_request(
        {
            "request_id": "idx-1",
            "mode": "find",
            "input": {"items": ["one", "three", "seven"]},
            "parameters": {},
            "execution_context": _execution_context(tmp_path, request_id="req-1"),
            "vector_context": None,
        }
    )
    search_response = runner.handle_request(
        {
            "request_id": "search-1",
            "mode": "search",
            "input": {"query": "four"},
            "parameters": {"top_k": 2},
            "execution_context": _execution_context(tmp_path, request_id="req-2"),
            "vector_context": None,
        }
    )
    runner.shutdown()

    assert index_response["output"] == {"indexed": {"kind": "integer", "content": 3}}
    assert search_response["output"] == {
        "results": {"kind": "text", "content": ["one", "three"]},
        "count": {"kind": "integer", "content": 2},
    }


def test_agent_runner_module_emits_ready_and_stays_alive(tmp_path: Path) -> None:
    module_path = _write_modes_agent(tmp_path)
    python_path_entries = [str(SDK_ROOT), str(FRAMEWORK_ROOT)]
    existing_python_path = os.environ.get("PYTHONPATH", "").strip()
    if existing_python_path:
        python_path_entries.append(existing_python_path)

    process = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "aimp_sdk.agent_runner",
            "--module",
            module_path,
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
        env={**os.environ, "PYTHONPATH": os.pathsep.join(python_path_entries)},
    )
    try:
        assert process.stdout is not None
        assert process.stderr is not None
        selector = selectors.DefaultSelector()
        selector.register(process.stdout, selectors.EVENT_READ)
        events = selector.select(timeout=5)
        if not events:
            stderr = process.stderr.read()
            raise AssertionError(f"agent_runner did not emit readiness output. stderr={stderr!r}")
        ready_line = process.stdout.readline().strip()
        assert ready_line, process.stderr.read()
        assert json.loads(ready_line) == {"type": "ready"}
        assert process.poll() is None
    finally:
        process.terminate()
        process.wait(timeout=5)


def test_load_agent_contract_generates_modes_metadata_from_code(tmp_path: Path) -> None:
    module_path = _write_modes_agent(tmp_path)

    contract = load_agent_contract(module_path)

    assert contract["schema_version"] == 5
    assert contract["agent"]["name"] == "semantic-search"
    assert contract["resources"]["vector_db"] == {
        "collections": [
            {
                "alias": "docs",
                "name": "Documents",
                "description": "Document embeddings used by vector-backed modes.",
                "dimension": 1536,
                "metric": "cosine",
            }
        ]
    }
    assert sorted(contract["modes"]) == ["find", "search"]
    assert contract["modes"]["search"]["outputs"] == [
        {"name": "results", "kind": "text", "required": True, "multiple": True},
        {"name": "count", "kind": "integer", "required": True},
    ]
    assert "parameters" not in contract
    assert contract["modes"]["search"]["parameters"]["top_k"] == {
        "kind": "integer",
        "default": 5,
        "min": 1,
        "max": 20,
    }


def test_mode_runtime_emits_typed_list_outputs_as_json(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    module_path = _write_modes_agent(tmp_path, "typed_list_runtime_agent.py")
    monkeypatch.setenv("AIMP_MODEL_ID", "model-123")
    runner = AgentRunner(module_path)
    runner.start()

    response = runner.handle_request(
        {
            "request_id": "search-typed-list",
            "mode": "search",
            "input": {"query": "cat"},
            "parameters": {},
            "execution_context": _execution_context(tmp_path, request_id="req-typed-list"),
            "vector_context": None,
        }
    )
    runner.shutdown()

    assert response["output"] == {
        "matches": {
            "kind": "json",
            "content": [
                {
                    "image_id": "cat-1",
                    "filename": "cat.png",
                    "score": 0.91,
                }
            ],
        },
        "count": {"kind": "integer", "content": 1},
    }
