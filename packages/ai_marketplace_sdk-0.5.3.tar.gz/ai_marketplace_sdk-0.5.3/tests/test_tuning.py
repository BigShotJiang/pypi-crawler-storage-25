"""Tests for fine-tune schema and bundle helpers."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from aimp_sdk.tuning import load_tuning_schema_class  # noqa: E402
from aimp_sdk.tuning import load_model_tuning_contract  # noqa: E402
from aimp_sdk.tuning import load_tuning_schema_contract  # noqa: E402
from aimp_sdk.tuning import TuneResult  # noqa: E402
from aimp_sdk.tuning import open_tuning_session  # noqa: E402
from aimp_sdk.runtime import ProcessContext  # noqa: E402
from aimp_sdk.runtime import RuntimeContext  # noqa: E402
from aimp_sdk.tuning_data import TuningBundleError  # noqa: E402
from aimp_sdk.tuning_data import build_tuning_dataset_bundle  # noqa: E402
from aimp_sdk.tuning_data import load_tuning_dataset_bundle  # noqa: E402


ENGINE_TEMPLATE = (
    "from aimp_framework import Engine\n\n"
    "class DemoEngine(Engine):\n"
    "    def load(self):\n"
    "        pass\n"
)

MODEL_TEMPLATE = (
    "from aimp_sdk import Model\n"
    "from .engine import DemoEngine\n"
    "from .tuning.runner import DemoTuning\n\n"
    "class DemoModel(Model):\n"
    "    engine = DemoEngine\n"
    "    tuning = DemoTuning\n"
)

DATASET_TEMPLATE = (
    "from aimp_sdk.tuning import FineTuneSchema, TextField\n\n"
    "class DemoSchema(FineTuneSchema):\n"
    "    prompt = TextField(required=True)\n"
    "    completion = TextField(required=True)\n"
)

RUNNER_TEMPLATE = (
    "from aimp_sdk.tuning import TuneResult, TuningSession\n\n"
    "class DemoTuning:\n"
    "    strategy = '{strategy}'\n"
    "    training_runtime_profile = '{runtime_profile}'\n"
    "    dataset_requirements = {{'format': 'aimp_tuning_bundle_v1'}}\n"
    "    dataset_spec = {{'format': 'aimp_tuning_bundle_v1'}}\n"
    "    objective = {{'name': 'validation_loss', 'direction': 'minimize'}}\n"
    "    split_policy = {{'strategy': 'auto', 'validation_ratio': 0.1}}\n"
    "    parameters = {{'epochs': {{'kind': 'integer', 'default': 3, 'min': 1, 'max': 5}}}}\n"
    "    async def run(self, session: TuningSession) -> TuneResult:\n"
    "        return TuneResult(metrics={{'validation_loss': 0.0}})\n"
)


def _write_model_tuning_fixture(
    tmp_path: Path,
    *,
    strategy: str,
    runtime_profile: str,
) -> Path:
    project_dir = tmp_path / "project"
    model_dir = project_dir / "models" / "demo_model"
    tuning_dir = model_dir / "tuning"
    tuning_dir.mkdir(parents=True)
    (project_dir / "models" / "__init__.py").write_text("", encoding="utf-8")
    (model_dir / "__init__.py").write_text("", encoding="utf-8")
    (tuning_dir / "__init__.py").write_text("", encoding="utf-8")
    (project_dir / "agent.py").write_text("print('ok')\n", encoding="utf-8")
    (model_dir / "engine.py").write_text(ENGINE_TEMPLATE, encoding="utf-8")
    (model_dir / "model.py").write_text(MODEL_TEMPLATE, encoding="utf-8")
    (tuning_dir / "dataset.py").write_text(DATASET_TEMPLATE, encoding="utf-8")
    (tuning_dir / "runner.py").write_text(
        RUNNER_TEMPLATE.format(strategy=strategy, runtime_profile=runtime_profile),
        encoding="utf-8",
    )
    return project_dir


def test_load_tuning_schema_contract_from_module(tmp_path: Path) -> None:
    module_path = tmp_path / "schema.py"
    module_path.write_text(
        "from aimp_sdk import AudioField, FineTuneSchema, ImageField, TuningTextField, VideoField\n\n"
        "class ClipSchema(FineTuneSchema):\n"
        '    query_image = ImageField(description="query")\n'
        '    reference_audio = AudioField(required=False, description="audio")\n'
        '    clip = VideoField(required=False, description="video")\n'
        "    caption = TuningTextField(required=False)\n",
        encoding="utf-8",
    )

    contract = load_tuning_schema_contract(str(module_path))

    assert list(contract) == ["fields"]
    assert contract["fields"] == [
        {
            "key": "query_image",
            "type": "image",
            "required": True,
            "description": "query",
            "multiple": False,
        },
        {
            "key": "reference_audio",
            "type": "audio",
            "required": False,
            "description": "audio",
            "multiple": False,
        },
        {
            "key": "clip",
            "type": "video",
            "required": False,
            "description": "video",
            "multiple": False,
        },
        {
            "key": "caption",
            "type": "text",
            "required": False,
            "description": None,
            "multiple": False,
        },
    ]


def test_build_and_load_tuning_dataset_bundle(tmp_path: Path) -> None:
    query_image = tmp_path / "query.jpg"
    candidate_image = tmp_path / "candidate.jpg"
    query_image.write_bytes(b"query")
    candidate_image.write_bytes(b"candidate")
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "records": [
                    {
                        "query_image": "query.jpg",
                        "candidate_image": "candidate.jpg",
                        "caption": "pair",
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    schema_contract = {
        "fields": [
            {
                "key": "query_image",
                "type": "image",
                "required": True,
                "multiple": False,
            },
            {
                "key": "candidate_image",
                "type": "image",
                "required": True,
                "multiple": False,
            },
            {"key": "caption", "type": "text", "required": False, "multiple": False},
        ],
    }

    payload = build_tuning_dataset_bundle(
        schema_contract=schema_contract,
        bundle_path=bundle_path,
    )
    output_path = tmp_path / payload.file_name
    with output_path.open("wb") as handle:
        payload.stream.seek(0)
        handle.write(payload.stream.read())

    loaded = load_tuning_dataset_bundle(output_path)
    try:
        assert loaded.manifest["schema"] == schema_contract
        assert isinstance(loaded.manifest["schema_fingerprint"], str)
        assert len(loaded.manifest["schema_fingerprint"]) == 64
        assert loaded.dataset.num_rows == 1
        row = loaded.dataset[0]
        assert loaded.resolve_path(row["query_image"]).read_bytes() == b"query"
        assert loaded.resolve_path(row["candidate_image"]).read_bytes() == b"candidate"
        assert row["caption"] == "pair"
    finally:
        loaded.cleanup()


def test_build_tuning_dataset_bundle_runs_field_preprocessors_and_validators(
    tmp_path: Path,
) -> None:
    schema_module = tmp_path / "schema.py"
    schema_module.write_text(
        "from aimp_sdk import FineTuneSchema, ImageField, TuningTextField, TuningJsonField\n\n"
        "def trim_text(value):\n"
        "    return str(value).strip()\n\n"
        "def require_png(value):\n"
        '    if not str(value).lower().endswith(".png"):\n'
        '        raise ValueError("Only PNG files are allowed")\n\n'
        "def add_source(value):\n"
        "    result = dict(value)\n"
        '    result.setdefault("source", "sdk-test")\n'
        "    return result\n\n"
        "class DemoSchema(FineTuneSchema):\n"
        "    gallery = ImageField(required=True, multiple=True, validators=[require_png])\n"
        "    caption = TuningTextField(required=False, preprocessors=[trim_text])\n"
        "    metadata = TuningJsonField(required=True, preprocessors=[add_source])\n",
        encoding="utf-8",
    )
    (tmp_path / "one.png").write_bytes(b"one")
    (tmp_path / "two.png").write_bytes(b"two")
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "records": [
                    {
                        "gallery": ["one.png", "two.png"],
                        "caption": "  ready  ",
                        "metadata": {"label": "positive"},
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    schema_cls = load_tuning_schema_class(str(schema_module))

    payload = build_tuning_dataset_bundle(
        schema_contract=schema_cls.contract(),
        bundle_path=bundle_path,
        schema_cls=schema_cls,
    )
    output_path = tmp_path / payload.file_name
    with output_path.open("wb") as handle:
        payload.stream.seek(0)
        handle.write(payload.stream.read())

    loaded = load_tuning_dataset_bundle(output_path)
    try:
        row = loaded.dataset[0]
        assert row["caption"] == "ready"
        assert json.loads(row["metadata"]) == {
            "label": "positive",
            "source": "sdk-test",
        }
        assert len(row["gallery"]) == 2
    finally:
        loaded.cleanup()


def test_build_tuning_dataset_bundle_rejects_post_preprocess_type_mismatch(
    tmp_path: Path,
) -> None:
    schema_module = tmp_path / "schema.py"
    schema_module.write_text(
        "from aimp_sdk import FineTuneSchema, TuningTextField\n\n"
        "def return_json(value):\n"
        '    return {"value": value}\n\n'
        "class DemoSchema(FineTuneSchema):\n"
        "    caption = TuningTextField(preprocessors=[return_json])\n",
        encoding="utf-8",
    )
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps({"records": [{"caption": "hello"}]}),
        encoding="utf-8",
    )
    schema_cls = load_tuning_schema_class(str(schema_module))

    with pytest.raises(
        TuningBundleError, match=r"Record 0 field 'caption' item 0 must be text"
    ):
        build_tuning_dataset_bundle(
            schema_contract=schema_cls.contract(),
            bundle_path=bundle_path,
            schema_cls=schema_cls,
        )


def test_build_tuning_dataset_bundle_surfaces_item_index_for_multiple_validator_failures(
    tmp_path: Path,
) -> None:
    schema_module = tmp_path / "schema.py"
    schema_module.write_text(
        "from aimp_sdk import FineTuneSchema, ImageField\n\n"
        "def require_png(value):\n"
        '    if not str(value).lower().endswith(".png"):\n'
        '        raise ValueError("Only PNG files are allowed")\n\n'
        "class DemoSchema(FineTuneSchema):\n"
        "    gallery = ImageField(required=True, multiple=True, validators=[require_png])\n",
        encoding="utf-8",
    )
    (tmp_path / "good.png").write_bytes(b"png")
    (tmp_path / "bad.jpg").write_bytes(b"jpg")
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps({"records": [{"gallery": ["good.png", "bad.jpg"]}]}),
        encoding="utf-8",
    )
    schema_cls = load_tuning_schema_class(str(schema_module))

    with pytest.raises(
        TuningBundleError,
        match=r"Record 0 field 'gallery' item 1 validation failed: Only PNG files are allowed",
    ):
        build_tuning_dataset_bundle(
            schema_contract=schema_cls.contract(),
            bundle_path=bundle_path,
            schema_cls=schema_cls,
        )


def test_schema_fingerprint_is_stable_and_changes_with_schema(tmp_path: Path) -> None:
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps({"records": [{"input": {"prompt": "hello"}}]}),
        encoding="utf-8",
    )
    base_schema = {
        "fields": [
            {"key": "input", "type": "json", "required": True, "multiple": False}
        ],
    }
    changed_schema = {
        "fields": [
            {"key": "input", "type": "json", "required": False, "multiple": False}
        ],
    }

    first = build_tuning_dataset_bundle(
        schema_contract=base_schema, bundle_path=bundle_path
    )
    second = build_tuning_dataset_bundle(
        schema_contract=base_schema, bundle_path=bundle_path
    )
    third = build_tuning_dataset_bundle(
        schema_contract=changed_schema, bundle_path=bundle_path
    )

    def manifest_for(payload_name: str, payload: object) -> dict[str, object]:
        output_path = tmp_path / payload_name
        with output_path.open("wb") as handle:
            payload.stream.seek(0)
            handle.write(payload.stream.read())
        loaded = load_tuning_dataset_bundle(output_path)
        try:
            return dict(loaded.manifest)
        finally:
            loaded.cleanup()

    first_manifest = manifest_for("first.zip", first)
    second_manifest = manifest_for("second.zip", second)
    third_manifest = manifest_for("third.zip", third)

    assert first_manifest["schema_fingerprint"] == second_manifest["schema_fingerprint"]
    assert first_manifest["schema_fingerprint"] != third_manifest["schema_fingerprint"]


def test_open_tuning_session_requires_dataset_path() -> None:
    with pytest.raises(RuntimeError, match="dataset_path is required"):
        with open_tuning_session(
            {},
            {},
            process_context=ProcessContext(),
            runtime_context=RuntimeContext(),
        ):
            raise AssertionError("context manager should not yield")


def test_open_tuning_session_materializes_author_facing_views(tmp_path: Path) -> None:
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "records": [
                    {"prompt": "hello", "completion": "world"},
                    {"prompt": "bye", "completion": "moon"},
                ]
            }
        ),
        encoding="utf-8",
    )
    payload = build_tuning_dataset_bundle(
        schema_contract={
            "fields": [
                {"key": "prompt", "type": "text", "required": True, "multiple": False},
                {
                    "key": "completion",
                    "type": "text",
                    "required": True,
                    "multiple": False,
                },
            ],
        },
        bundle_path=bundle_path,
    )
    output_path = tmp_path / payload.file_name
    with output_path.open("wb") as handle:
        payload.stream.seek(0)
        handle.write(payload.stream.read())

    extracted_root: Path | None = None
    with open_tuning_session(
        {
            "dataset_path": str(output_path),
            "split_policy": {"strategy": "auto", "validation_ratio": 0.5},
            "trial_id": 7,
        },
        {"learning_rate": 0.01, "epochs": 3},
        process_context=ProcessContext(artifacts_dir=tmp_path / "artifacts"),
        runtime_context=RuntimeContext(
            request_id="req-1",
            cache_dir=tmp_path / "cache",
            work_dir=tmp_path / "work",
        ),
    ) as tuning:
        extracted_root = tuning.resolve_path("data.parquet").parent
        assert tuning.train_dataset.num_rows == 1
        assert tuning.validation_dataset.num_rows == 1
        record = tuning.train_dataset[0]
        assert record.prompt in {"hello", "bye"}
        assert tuning.params.learning_rate == 0.01
        assert tuning.params.epochs == 3
        assert tuning.request_id == "req-1"
        assert tuning.trial_id == 7
        assert tuning.artifacts_dir == tmp_path / "artifacts"
        assert extracted_root.exists()

    assert extracted_root is not None
    assert not extracted_root.exists()


def test_tune_result_rejects_invalid_metrics() -> None:
    with pytest.raises(ValueError, match="non-empty dict"):
        TuneResult(metrics={})

    with pytest.raises(ValueError, match="must be numeric"):
        TuneResult(metrics={"validation_loss": "bad"})


def test_build_tuning_dataset_bundle_rejects_unknown_fields(tmp_path: Path) -> None:
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps({"records": [{"unexpected": "value"}]}), encoding="utf-8"
    )

    with pytest.raises(TuningBundleError, match="unknown fine-tune fields"):
        build_tuning_dataset_bundle(
            schema_contract={
                "fields": [
                    {
                        "key": "input",
                        "type": "json",
                        "required": True,
                        "multiple": False,
                    }
                ],
            },
            bundle_path=bundle_path,
        )


def test_tuning_session_suggest_helpers_use_defaults_and_validate(
    tmp_path: Path,
) -> None:
    bundle_path = tmp_path / "bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "records": [
                    {"prompt": "hello", "completion": "world"},
                    {"prompt": "bye", "completion": "moon"},
                ]
            }
        ),
        encoding="utf-8",
    )
    payload = build_tuning_dataset_bundle(
        schema_contract={
            "fields": [
                {"key": "prompt", "type": "text", "required": True, "multiple": False},
                {
                    "key": "completion",
                    "type": "text",
                    "required": True,
                    "multiple": False,
                },
            ],
        },
        bundle_path=bundle_path,
    )
    output_path = tmp_path / payload.file_name
    with output_path.open("wb") as handle:
        payload.stream.seek(0)
        handle.write(payload.stream.read())

    with open_tuning_session(
        {
            "dataset_path": str(output_path),
            "split_policy": {"strategy": "auto", "validation_ratio": 0.5},
        },
        {"learning_rate": 0.02, "epochs": 4, "batch_size": 32},
        process_context=ProcessContext(artifacts_dir=tmp_path / "artifacts"),
        runtime_context=RuntimeContext(),
    ) as session:
        assert session.suggest_float("learning_rate", 0.001, 0.1, default=0.01) == 0.02
        assert session.suggest_int("epochs", 1, 10, default=3) == 4
        assert session.suggest_categorical("batch_size", [8, 16, 32], default=16) == 32
        assert session.suggest_int("missing_epochs", 1, 10, default=3) == 3

        with pytest.raises(RuntimeError, match="must be between"):
            session.suggest_float("learning_rate", 0.03, 0.1, default=0.05)

        with pytest.raises(RuntimeError, match="not one of"):
            session.suggest_categorical("batch_size", [8, 16], default=8)


def test_load_model_tuning_contract_requires_model_scoped_runner_metadata(
    tmp_path: Path,
) -> None:
    project_dir = _write_model_tuning_fixture(
        tmp_path,
        strategy="lora",
        runtime_profile="cpu",
    )

    contract = load_model_tuning_contract(
        str(project_dir / "agent.py"), model_key="demo_model"
    )
    assert contract["strategy"] == "lora"
    assert contract["training_runtime_profile"] == "cpu"
    assert contract["model_key"] == "demo_model"
    assert contract["schema"]["fields"][0]["key"] == "prompt"


def test_load_model_tuning_contract_fails_when_strategy_missing(tmp_path: Path) -> None:
    project_dir = _write_model_tuning_fixture(
        tmp_path,
        strategy="missing",
        runtime_profile="cpu",
    )

    with pytest.raises(RuntimeError, match="supported strategy"):
        load_model_tuning_contract(
            str(project_dir / "agent.py"), model_key="demo_model"
        )
