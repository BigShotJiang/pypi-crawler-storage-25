import pytest

from aimp_sdk.playground import (
    Cards,
    Gallery,
    Markdown,
    PlaygroundInputs,
    PlaygroundSpec,
    Status,
    Table,
    Text,
    ViewBase,
    _fields_dict,
    _resolve_field_name,
    image_id_from,
    validate_mode_playground,
    Computed,
)


# ---------------------------------------------------------------------------
# Fixtures — minimal schema stubs (no real framework Schema needed)
# ---------------------------------------------------------------------------


class _FakeField:
    """Minimal stand-in for a framework Field with a .name attribute."""

    def __init__(self, name: str) -> None:
        self.name = name


class _FakeOutputs:
    """Stand-in for a framework Outputs Schema class."""

    _fields = {
        "results": _FakeField("results"),
        "article": _FakeField("article"),
        "sources": _FakeField("sources"),
        "indexed": _FakeField("indexed"),
        "messages": _FakeField("messages"),
        "data": _FakeField("data"),
        "images": _FakeField("images"),
    }


class _FakeInputs:
    _fields = {
        "image": _FakeField("image"),
        "prompt": _FakeField("prompt"),
    }


class _FakeSDKOutputs:
    """Stand-in for a SDK SchemaDecl with .fields dict."""

    fields = {
        "results": object(),
        "indexed": object(),
    }


class _FakeSDKInputs:
    fields = {
        "image": object(),
    }


# Convenience field refs
_results = _FakeField("results")
_article = _FakeField("article")
_sources = _FakeField("sources")
_indexed = _FakeField("indexed")
_messages = _FakeField("messages")
_data = _FakeField("data")
_images = _FakeField("images")
_image = _FakeField("image")


# ---------------------------------------------------------------------------
# _resolve_field_name
# ---------------------------------------------------------------------------


class TestResolveFieldName:
    def test_field_object_returns_name(self):
        assert _resolve_field_name(_results, "label") == "results"

    def test_string_returns_stripped_name(self):
        assert _resolve_field_name("  results  ", "label") == "results"

    def test_empty_string_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            _resolve_field_name("", "label")

    def test_unknown_type_raises(self):
        with pytest.raises(TypeError, match="Schema Field reference"):
            _resolve_field_name(42, "label")

    def test_field_without_name_raises(self):
        bad = _FakeField("")
        with pytest.raises(ValueError, match="no name set"):
            _resolve_field_name(bad, "label")


# ---------------------------------------------------------------------------
# _fields_dict
# ---------------------------------------------------------------------------


class TestFieldsDict:
    def test_sdk_schema_decl(self):
        d = _fields_dict(_FakeSDKOutputs)
        assert "results" in d

    def test_framework_schema(self):
        d = _fields_dict(_FakeOutputs)
        assert "results" in d

    def test_none_returns_empty(self):
        assert _fields_dict(None) == {}

    def test_unknown_type_returns_empty(self):
        assert _fields_dict(object()) == {}


# ---------------------------------------------------------------------------
# ViewBase presets — structure validation
# ---------------------------------------------------------------------------


class TestCardsView:
    def test_validate_valid_field(self):
        view = Cards(_results, title="filename", score="score")
        view.validate_against_outputs(_FakeOutputs)

    def test_validate_string_field(self):
        view = Cards("results")
        view.validate_against_outputs(_FakeOutputs)

    def test_validate_unknown_field_raises(self):
        view = Cards(_FakeField("nonexistent"))
        with pytest.raises(ValueError, match="nonexistent"):
            view.validate_against_outputs(_FakeOutputs)

    def test_contract_image_layout(self):
        """image present → image card grid layout."""
        view = Cards(_results, title="filename", image="url", score="score")
        view.validate_against_outputs(_FakeOutputs)
        c = view.to_contract()
        assert c["preset"] == "cards"
        assert c["field"] == "results"
        assert c["title"] == "filename"
        assert c["image"] == "url"
        assert c["score"] == "score"
        assert "empty" in c

    def test_contract_citation_layout(self):
        """body + url, no image → text/citation card layout."""
        view = Cards(_results, title="title", body="text", score="score", url="link")
        view.validate_against_outputs(_FakeOutputs)
        c = view.to_contract()
        assert c["preset"] == "cards"
        assert c["body"] == "text"
        assert c["url"] == "link"
        assert "image" not in c

    def test_contract_omits_none_keys(self):
        view = Cards(_results)
        view.validate_against_outputs(_FakeOutputs)
        c = view.to_contract()
        assert "title" not in c
        assert "image" not in c
        assert "body" not in c
        assert "url" not in c

    def test_sdk_schema_decl_works(self):
        view = Cards(_FakeField("results"))
        view.validate_against_outputs(_FakeSDKOutputs)


class TestMarkdownView:
    def test_valid(self):
        view = Markdown(_article)
        view.validate_against_outputs(_FakeOutputs)
        assert view.to_contract() == {"preset": "markdown", "field": "article"}

    def test_unknown_field(self):
        with pytest.raises(ValueError, match="bad_field"):
            Markdown(_FakeField("bad_field")).validate_against_outputs(_FakeOutputs)


class TestTextView:
    def test_valid(self):
        view = Text(_article)
        view.validate_against_outputs(_FakeOutputs)
        assert view.to_contract() == {"preset": "text", "field": "article"}


class TestTableView:
    def test_valid_no_columns(self):
        view = Table(_data)
        view.validate_against_outputs(_FakeOutputs)
        c = view.to_contract()
        assert c["preset"] == "table"
        assert "columns" not in c

    def test_with_columns(self):
        view = Table(_data, columns=["a", "b"])
        view.validate_against_outputs(_FakeOutputs)
        c = view.to_contract()
        assert c["columns"] == ["a", "b"]


class TestGalleryView:
    def test_valid(self):
        view = Gallery(_images, image="url", caption="alt")
        view.validate_against_outputs(_FakeOutputs)
        c = view.to_contract()
        assert c["preset"] == "gallery"
        assert c["image"] == "url"
        assert c["caption"] == "alt"


class TestStatusView:
    def test_valid(self):
        view = Status(_indexed)
        view.validate_against_outputs(_FakeOutputs)
        assert view.to_contract() == {"preset": "status", "field": "indexed"}


# ---------------------------------------------------------------------------
# Computed / image_id_from
# ---------------------------------------------------------------------------


class TestComputed:
    def test_valid(self):
        c = Computed(from_field="image", strategy="image_id")
        assert c.from_field == "image"
        assert c.strategy == "image_id"

    def test_contract(self):
        c = Computed(from_field="image", strategy="image_id")
        d = c.to_contract()
        assert d == {
            "hidden": True,
            "computed": True,
            "from": "image",
            "strategy": "image_id",
        }

    def test_unknown_strategy_raises(self):
        with pytest.raises(ValueError, match="strategy"):
            Computed(from_field="image", strategy="bad_strategy")

    def test_empty_from_field_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            Computed(from_field="", strategy="image_id")


class TestImageIdFrom:
    def test_field_object(self):
        c = image_id_from(_image)
        assert c.from_field == "image"
        assert c.strategy == "image_id"

    def test_string(self):
        c = image_id_from("image")
        assert c.from_field == "image"


# ---------------------------------------------------------------------------
# PlaygroundInputs
# ---------------------------------------------------------------------------


class TestPlaygroundInputs:
    def test_valid(self):
        pi = PlaygroundInputs(image_id=image_id_from(_image))
        pi.validate_against_inputs(_FakeInputs)  # from_field="image" exists ✓

    def test_sdk_schema_decl(self):
        pi = PlaygroundInputs(image_id=image_id_from("image"))
        pi.validate_against_inputs(_FakeSDKInputs)  # from_field="image" exists ✓

    def test_override_key_need_not_exist_in_schema(self):
        """image_id is a derived/hidden field — it does NOT need to be declared
        in mode Inputs.  Only the from_field source must exist.
        """
        pi = PlaygroundInputs(image_id=image_id_from(_image))
        # _FakeInputs has "image" but NOT "image_id" — should not raise
        pi.validate_against_inputs(_FakeInputs)

    def test_unknown_from_field_raises(self):
        pi = PlaygroundInputs(image_id=Computed(from_field="nonexistent", strategy="image_id"))
        with pytest.raises(ValueError, match="nonexistent"):
            pi.validate_against_inputs(_FakeInputs)

    def test_non_computed_raises(self):
        with pytest.raises(TypeError, match="Computed instance"):
            PlaygroundInputs(image_id="not_a_computed")  # type: ignore[arg-type]

    def test_contract(self):
        pi = PlaygroundInputs(image_id=image_id_from("image"))
        d = pi.to_contract()
        assert d == {
            "image_id": {
                "hidden": True,
                "computed": True,
                "from": "image",
                "strategy": "image_id",
            }
        }

    def test_empty_schema_skips_field_validation(self):
        """When there are no declared fields, field names are not validated."""
        pi = PlaygroundInputs(image_id=image_id_from("image"))
        pi.validate_against_inputs(None)  # no schema — should not raise


# ---------------------------------------------------------------------------
# PlaygroundSpec
# ---------------------------------------------------------------------------


class TestPlaygroundSpec:
    def test_missing_view_raises(self):
        with pytest.raises(TypeError, match="must declare"):

            class NoView(PlaygroundSpec):
                pass

    def test_empty_view_list_raises(self):
        with pytest.raises(TypeError, match="must not be empty"):

            class EmptyView(PlaygroundSpec):
                view = []

    def test_invalid_view_type_raises(self):
        with pytest.raises(TypeError, match="ViewBase instance"):

            class BadView(PlaygroundSpec):
                view = "not_a_view"

    def test_invalid_view_list_item_raises(self):
        with pytest.raises(TypeError, match="ViewBase instance"):

            class BadList(PlaygroundSpec):
                view = [Cards(_results), "bad"]

    def test_single_view(self):
        class SingleSpec(PlaygroundSpec):
            view = Cards(_results)

        assert isinstance(SingleSpec.view, ViewBase)

    def test_list_view(self):
        class MultiSpec(PlaygroundSpec):
            view = [Markdown(_article), Cards(_sources, title="title", body="text", score="score")]

        assert isinstance(MultiSpec.view, list)
        assert len(MultiSpec.view) == 2

    def test_validate_against_mode_single(self):
        class Spec(PlaygroundSpec):
            view = Cards(_results)

        Spec.validate_against_mode(_FakeInputs, _FakeOutputs)

    def test_validate_against_mode_list(self):
        class Spec(PlaygroundSpec):
            view = [Markdown(_article), Status(_indexed)]

        Spec.validate_against_mode(_FakeInputs, _FakeOutputs)

    def test_validate_against_mode_with_inputs(self):
        class Spec(PlaygroundSpec):
            inputs = PlaygroundInputs(image_id=image_id_from(_image))
            view = Cards(_results)

        Spec.validate_against_mode(_FakeInputs, _FakeOutputs)

    def test_validate_unknown_output_field_raises(self):
        class Spec(PlaygroundSpec):
            view = Cards(_FakeField("nonexistent"))

        with pytest.raises(ValueError, match="nonexistent"):
            Spec.validate_against_mode(_FakeInputs, _FakeOutputs)

    def test_contract_single_view(self):
        class Spec(PlaygroundSpec):
            view = Status(_indexed)

        Spec.validate_against_mode(_FakeInputs, _FakeOutputs)
        c = Spec.to_contract()
        assert "views" in c
        assert len(c["views"]) == 1
        assert c["views"][0]["preset"] == "status"
        assert "inputs" not in c

    def test_contract_with_inputs(self):
        class Spec(PlaygroundSpec):
            inputs = PlaygroundInputs(image_id=image_id_from(_image))
            view = Cards(_results)

        Spec.validate_against_mode(_FakeInputs, _FakeOutputs)
        c = Spec.to_contract()
        assert "inputs" in c
        assert "image_id" in c["inputs"]

    def test_contract_multi_view(self):
        class Spec(PlaygroundSpec):
            view = [Markdown(_article), Cards(_sources, title="title", body="text")]

        Spec.validate_against_mode(_FakeInputs, _FakeOutputs)
        c = Spec.to_contract()
        assert len(c["views"]) == 2
        assert c["views"][0]["preset"] == "markdown"
        assert c["views"][1]["preset"] == "cards"
        assert c["views"][1]["body"] == "text"


# ---------------------------------------------------------------------------
# validate_mode_playground (cross-cutting helper)
# ---------------------------------------------------------------------------


class TestValidateModePlayground:
    def _make_mode_cls(self, outputs=_FakeOutputs, inputs=_FakeInputs):
        class FakeMode:
            schema = type(
                "FakeSchema",
                (),
                {"Inputs": inputs, "Outputs": outputs},
            )

        return FakeMode

    def test_valid_spec(self):
        class Spec(PlaygroundSpec):
            view = Cards(_results)

        mode_cls = self._make_mode_cls()
        validate_mode_playground(mode_cls, Spec)  # must not raise

    def test_non_spec_raises(self):
        mode_cls = self._make_mode_cls()
        with pytest.raises(TypeError, match="PlaygroundSpec subclass"):
            validate_mode_playground(mode_cls, "not_a_spec")

    def test_unknown_field_raises(self):
        class Spec(PlaygroundSpec):
            view = Cards(_FakeField("ghost"))

        mode_cls = self._make_mode_cls()
        with pytest.raises(TypeError, match="ghost"):
            validate_mode_playground(mode_cls, Spec)

    def test_mode_without_outputs_raises(self):
        class Spec(PlaygroundSpec):
            view = Status(_indexed)

        class NoOutputMode:
            pass

        with pytest.raises(TypeError, match="no accessible Outputs"):
            validate_mode_playground(NoOutputMode, Spec)
