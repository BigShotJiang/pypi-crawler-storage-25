"""Tests for SDK functional mode loading utilities."""

from __future__ import annotations

import importlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import typing

import pytest

SDK_ROOT = Path(__file__).resolve().parents[1]
FRAMEWORK_ROOT = SDK_ROOT.parents[0] / "framework"
for key in list(sys.modules):
    if key == "aimp_sdk" or key.startswith("aimp_sdk."):
        sys.modules.pop(key, None)
sys.path.insert(0, str(SDK_ROOT))

from aimp_sdk._type_lineage import framework_schema_type  # noqa: E402
from aimp_sdk.agent_loader import _load_module  # noqa: E402
from aimp_sdk.loader import load_contract  # noqa: E402
from aimp_sdk.agent_loader import load_mode_runtime  # noqa: E402


FRAMEWORK_TEMPLATE_MODULES = (
    Path(__file__).resolve().parents[2]
    / "framework"
    / "aimp_framework"
    / "project_template"
    / "test_modules"
)


def _write_module(tmp_path: Path, template_name: str) -> str:
    settings_path = tmp_path / "settings.py"
    settings_path.write_text(
        "from aimp_sdk import Settings\n\n"
        "class Project(Settings):\n"
        "    timeout = '30s'\n",
        encoding="utf-8",
    )
    (tmp_path / "contract.toml").write_text(
        "[agent]\n"
        'name = "test-agent"\n'
        'version = "1.0.0"\n',
        encoding="utf-8",
    )
    module_path = tmp_path / "agent.py"
    source_template = FRAMEWORK_TEMPLATE_MODULES / template_name
    shutil.copy2(source_template, module_path)
    return str(module_path)


def test_load_mode_runtime_finds_decorated_modes(tmp_path: Path) -> None:
    module_path = _write_module(
        tmp_path,
        "functional_mode_valid.py",
    )
    runtime = load_mode_runtime(module_path)
    assert sorted(runtime.modes_contract()) == ["sample"]


def test_load_mode_runtime_raises_for_missing_or_duplicate_modes(
    tmp_path: Path,
) -> None:
    missing_model_path = _write_module(tmp_path, "functional_mode_missing.py")
    with pytest.raises(ValueError, match="No @mode-decorated functions"):
        load_mode_runtime(missing_model_path)

    multiple_model_path = _write_module(
        tmp_path,
        "functional_mode_duplicate.py",
    )
    with pytest.raises(ValueError, match="Duplicate mode name"):
        load_mode_runtime(multiple_model_path)


def test_load_mode_runtime_binds_loaded_module_as_main_for_import_time_dependencies(
    tmp_path: Path,
) -> None:
    settings_path = tmp_path / "settings.py"
    settings_path.write_text(
        "from aimp_sdk import Settings\n\n"
        "class Project(Settings):\n"
        "    timeout = '30s'\n",
        encoding="utf-8",
    )
    module_path = tmp_path / "agent.py"
    module_path.write_text(
        "MODULE_MARKER = 'agent-marker'\n"
        "import __main__\n"
        "if getattr(__main__, 'MODULE_MARKER', None) != MODULE_MARKER:\n"
        "    raise RuntimeError('__main__ is not bound to the loaded agent module')\n"
        "from aimp_framework.base import Schema, TextField\n"
        "from aimp_sdk import mode\n\n"
        "class ExampleSchema:\n"
        "    class Inputs(Schema.Inputs):\n"
        "        query = TextField(required=True)\n\n"
        "    class Outputs(Schema.Outputs):\n"
        "        result = TextField(required=True)\n\n"
        "    class Params(Schema.Params):\n"
        "        pass\n\n"
        "@mode(name='example')\n"
        "async def run_example(inputs: ExampleSchema.Inputs, params: ExampleSchema.Params) -> ExampleSchema.Outputs:\n"
        "    _ = params\n"
        "    return ExampleSchema.Outputs(result=inputs.query)\n",
        encoding="utf-8",
    )

    runtime = load_mode_runtime(str(module_path))

    assert sorted(runtime.modes_contract()) == ["example"]


def test_load_contract_succeeds_after_preimporting_framework_base(
    tmp_path: Path,
) -> None:
    module_path = _write_module(tmp_path, "pipeline_runtime_agent.py")
    importlib.import_module("aimp_framework.base")

    contract = load_contract(module_path)

    assert sorted(contract["modes"]) == ["find", "search"]
    assert contract["modes"]["find"]["outputs"] == [
        {"name": "indexed", "kind": "integer", "required": True}
    ]


def test_loaded_nested_schema_annotations_share_current_framework_lineage(
    tmp_path: Path,
) -> None:
    module_path = _write_module(tmp_path, "pipeline_runtime_agent.py")
    importlib.import_module("aimp_framework.base")

    module = _load_module(module_path)
    request_annotation = typing.get_type_hints(module.run_find)["request"]

    assert framework_schema_type() is request_annotation.__mro__[2]


def test_load_contract_matches_runtime_contract_for_nested_schema_agent(
    tmp_path: Path,
) -> None:
    module_path = _write_module(tmp_path, "pipeline_runtime_agent.py")

    contract = load_contract(module_path)
    runtime = load_mode_runtime(module_path)

    assert contract["modes"] == runtime.modes_contract()


def test_contract_cli_exports_nested_schema_agent(tmp_path: Path) -> None:
    module_path = _write_module(tmp_path, "pipeline_runtime_agent.py")
    python_path_entries = [str(SDK_ROOT), str(FRAMEWORK_ROOT)]
    existing_python_path = os.environ.get("PYTHONPATH", "").strip()
    if existing_python_path:
        python_path_entries.append(existing_python_path)

    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "aimp_sdk.contract",
            "--module",
            module_path,
        ],
        capture_output=True,
        text=True,
        env={**os.environ, "PYTHONPATH": os.pathsep.join(python_path_entries)},
        check=False,
    )

    assert result.returncode == 0, result.stderr or result.stdout
    payload = json.loads(result.stdout)
    assert "error" not in payload
    assert sorted(payload["modes"]) == ["find", "search"]


def test_load_contract_exports_typed_list_outputs_as_json(tmp_path: Path) -> None:
    module_path = _write_module(tmp_path, "typed_list_runtime_agent.py")

    contract = load_contract(module_path)

    assert contract["modes"]["search"]["outputs"] == [
        {"name": "matches", "kind": "json", "required": True},
        {"name": "count", "kind": "integer", "required": True},
    ]
