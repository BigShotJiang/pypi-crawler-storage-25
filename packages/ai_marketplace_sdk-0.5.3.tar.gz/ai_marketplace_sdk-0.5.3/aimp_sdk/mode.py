"""Functional mode metadata and contract introspection."""

from __future__ import annotations

from dataclasses import dataclass
import inspect
from typing import TYPE_CHECKING, Any
from typing import Callable
from typing import get_type_hints

from ._type_lineage import framework_schema_type
from ._type_lineage import sdk_model_type
from .decorators import SchemaDecl
from .decorators import schema_decl_from_framework_schema
from .playground import validate_mode_playground
from .registry import normalize_registry_name

if TYPE_CHECKING:
    from aimp_framework.base import Schema as FrameworkSchema

    from .model import Model as SDKModel


class ModeError(Exception):
    """Raised when a mode operation cannot be completed."""


@dataclass(frozen=True)
class ModeMetadata:
    """Decorator-owned public mode metadata."""

    name: str
    label: str | None = None
    description: str | None = None
    playground: type[Any] | None = None


@dataclass(frozen=True)
class ModeFunctionContract:
    """Resolved contract extracted from one decorated mode function."""

    func: Callable[..., Any]
    metadata: ModeMetadata
    mode_name: str
    inputs_param_name: str
    inputs_schema_cls: type[FrameworkSchema]
    inputs_schema: SchemaDecl
    params_param_name: str
    params_schema_cls: type[FrameworkSchema]
    params_schema: SchemaDecl | None
    model_params: tuple[tuple[str, type[SDKModel]], ...]
    outputs_schema_cls: type[FrameworkSchema]
    outputs_schema: SchemaDecl


def mode(
    *,
    name: str,
    label: str | None = None,
    description: str | None = None,
    playground: type[Any] | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Declare one public mode using functional authoring."""
    raw_name = str(name or "").strip()
    if not raw_name:
        raise TypeError("mode(name=...) requires a non-empty name.")
    normalized_name = normalize_registry_name(raw_name)
    if not normalized_name:
        raise TypeError(f"Invalid mode name: {name!r}.")

    normalized_label: str | None = None
    if label is not None:
        normalized_label = str(label).strip()
        if not normalized_label:
            raise TypeError("mode(label=...) must be non-empty when provided.")

    normalized_description: str | None = None
    if description is not None:
        normalized_description = str(description)

    if playground is not None and not isinstance(playground, type):
        raise TypeError("mode(playground=...) must be a class when provided.")

    metadata = ModeMetadata(
        name=normalized_name,
        label=normalized_label,
        description=normalized_description,
        playground=playground,
    )

    def _decorate(func: Callable[..., Any]) -> Callable[..., Any]:
        if not callable(func):
            raise TypeError("@mode can only decorate callables.")
        setattr(func, "__aimp_mode__", metadata)
        return func

    return _decorate


def extract_mode_function_contract(func: Callable[..., Any]) -> ModeFunctionContract:
    """Extract and validate one decorated mode function contract."""
    raw_metadata = getattr(func, "__aimp_mode__", None)
    if raw_metadata is None:
        raise TypeError(
            f"Function '{getattr(func, '__name__', '<unknown>')}' is not a @mode."
        )
    if isinstance(raw_metadata, ModeMetadata):
        metadata = raw_metadata
    else:
        metadata = ModeMetadata(
            name=str(getattr(raw_metadata, "name", "") or "").strip(),
            label=getattr(raw_metadata, "label", None),
            description=getattr(raw_metadata, "description", None),
            playground=getattr(raw_metadata, "playground", None),
        )
        if not metadata.name:
            raise TypeError(
                f"Function '{getattr(func, '__name__', '<unknown>')}' has invalid @mode metadata."
            )
    if not inspect.iscoroutinefunction(func):
        raise TypeError(f"Mode '{metadata.name}' must be async.")

    signature = inspect.signature(func)
    type_hints = get_type_hints(func)
    schema_type = framework_schema_type()
    model_type = sdk_model_type()

    inputs_param_name = ""
    inputs_schema_cls: type[Any] | None = None
    params_param_name = ""
    params_schema_cls: type[Any] | None = None
    model_params: list[tuple[str, type[Any]]] = []

    for parameter in signature.parameters.values():
        if parameter.kind not in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        ):
            raise TypeError(
                f"Mode '{metadata.name}' has unsupported parameter kind for '{parameter.name}'."
            )

        annotation = type_hints.get(parameter.name, parameter.annotation)
        if annotation is inspect.Signature.empty:
            raise TypeError(
                f"Mode '{metadata.name}' parameter '{parameter.name}' must have a type annotation."
            )

        if isinstance(annotation, type) and issubclass(annotation, model_type):
            model_params.append((parameter.name, annotation))
            continue

        if isinstance(annotation, type) and issubclass(annotation, schema_type):
            role = getattr(annotation, "__schema_role__", None)
            if role == "inputs":
                if inputs_schema_cls is not None:
                    raise TypeError(
                        f"Mode '{metadata.name}' declares multiple Inputs schema parameters."
                    )
                inputs_param_name = parameter.name
                inputs_schema_cls = annotation
                continue
            if role == "params":
                if params_schema_cls is not None:
                    raise TypeError(
                        f"Mode '{metadata.name}' declares multiple Params schema parameters."
                    )
                params_param_name = parameter.name
                params_schema_cls = annotation
                continue
            if role == "outputs":
                raise TypeError(
                    f"Mode '{metadata.name}' parameter '{parameter.name}' cannot use Outputs schema annotation."
                )
            raise TypeError(
                f"Mode '{metadata.name}' parameter '{parameter.name}' uses unsupported schema annotation "
                f"'{annotation.__name__}'. Expected Schema.Inputs or Schema.Params subclass."
            )

        raise TypeError(
            f"Mode '{metadata.name}' parameter '{parameter.name}' has unsupported annotation "
            f"'{getattr(annotation, '__name__', repr(annotation))}'."
        )

    if inputs_schema_cls is None:
        raise TypeError(
            f"Mode '{metadata.name}' must declare exactly one Inputs schema parameter."
        )
    if params_schema_cls is None:
        raise TypeError(
            f"Mode '{metadata.name}' must declare exactly one Params schema parameter."
        )

    return_annotation = type_hints.get("return", signature.return_annotation)
    if return_annotation is inspect.Signature.empty:
        raise TypeError(
            f"Mode '{metadata.name}' must declare an Outputs schema return annotation."
        )
    if not (
        isinstance(return_annotation, type)
        and issubclass(return_annotation, schema_type)
    ):
        raise TypeError(
            f"Mode '{metadata.name}' return annotation must be a Schema subclass."
        )
    if not issubclass(return_annotation, schema_type.Outputs):
        raise TypeError(
            f"Mode '{metadata.name}' return annotation '{return_annotation.__name__}' must be a Schema.Outputs subclass."
        )

    outputs_schema = schema_decl_from_framework_schema(
        return_annotation,
        location="output",
        owner_name=f"{return_annotation.__name__}",
    )
    if outputs_schema is None or not outputs_schema.order:
        raise TypeError(
            f"Mode '{metadata.name}' outputs schema '{return_annotation.__name__}' must be non-empty."
        )

    inputs_schema = schema_decl_from_framework_schema(
        inputs_schema_cls,
        location="input",
        owner_name=f"{inputs_schema_cls.__name__}",
    )
    params_schema = schema_decl_from_framework_schema(
        params_schema_cls,
        location="parameter",
        owner_name=f"{params_schema_cls.__name__}",
    )

    if metadata.playground is not None:
        dummy_mode = type(
            f"_{func.__name__}_ModeShim",
            (),
            {
                "__name__": f"{func.__name__}",
                "inputs": inputs_schema,
                "outputs": outputs_schema,
            },
        )
        validate_mode_playground(dummy_mode, metadata.playground)

    return ModeFunctionContract(
        func=func,
        metadata=metadata,
        mode_name=metadata.name,
        inputs_param_name=inputs_param_name,
        inputs_schema_cls=inputs_schema_cls,
        inputs_schema=inputs_schema,
        params_param_name=params_param_name,
        params_schema_cls=params_schema_cls,
        params_schema=params_schema,
        model_params=tuple(model_params),
        outputs_schema_cls=return_annotation,
        outputs_schema=outputs_schema,
    )
