"""Declarative Django-like vector authoring primitives."""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any, ClassVar

from aimp_framework.base import Metric

from .vector import JsonValue, VectorClient, VectorSearchResult


_ALIAS_PATTERN = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,63}$")
_NO_DEFAULT = object()
_FIELD_COUNTER = 0


def _next_field_counter() -> int:
    global _FIELD_COUNTER
    value = _FIELD_COUNTER
    _FIELD_COUNTER += 1
    return value


def _normalize_alias(alias: str) -> str:
    normalized = str(alias or "").strip()
    if not normalized:
        raise TypeError("Vector alias must be non-empty.")
    if not _ALIAS_PATTERN.fullmatch(normalized):
        raise TypeError(
            f"Vector alias '{normalized}' must start with a letter and contain only "
            "letters, numbers, underscore, and hyphen (max 64 chars)."
        )
    return normalized


def _is_json_value(value: Any) -> bool:
    if value is None or isinstance(value, (str, int, float, bool)):
        return True
    if isinstance(value, list):
        return all(_is_json_value(item) for item in value)
    if isinstance(value, dict):
        return all(
            isinstance(key, str) and _is_json_value(item) for key, item in value.items()
        )
    return False


def _is_embedding(value: Any) -> bool:
    if not isinstance(value, (list, tuple)):
        return False
    for item in value:
        if isinstance(item, bool) or not isinstance(item, (int, float)):
            return False
    return True


class VectorField:
    """Base descriptor for one declared vector payload field."""

    kind: ClassVar[str] = "json"
    supports_range_lookups: ClassVar[bool] = False

    def __init__(
        self,
        *,
        filterable: bool = False,
        required: bool = False,
        default: Any = _NO_DEFAULT,
        label: str | None = None,
    ) -> None:
        if not isinstance(filterable, bool):
            raise TypeError("VectorField.filterable must be a bool.")
        if not isinstance(required, bool):
            raise TypeError("VectorField.required must be a bool.")
        if label is not None and not isinstance(label, str):
            raise TypeError("VectorField.label must be a string when provided.")
        self.filterable = filterable
        self.required = required
        self.default = default
        self.label = label.strip() if isinstance(label, str) and label.strip() else None
        self.creation_order = _next_field_counter()
        self.name: str | None = None
        if default is not _NO_DEFAULT:
            self.validate(default, field_name="default")

    def __set_name__(self, owner: type, name: str) -> None:
        self.name = name

    def validate(self, value: Any, *, field_name: str | None = None) -> None:
        """Validate one concrete field value."""
        _ = value, field_name

    def validate_lookup(self, lookup: str, value: Any, *, field_name: str) -> None:
        if lookup == "exact":
            self.validate(value, field_name=field_name)
            return
        if lookup == "in":
            if not isinstance(value, (list, tuple)):
                raise TypeError(f"{field_name}__in must be a list or tuple.")
            for item in value:
                self.validate(item, field_name=field_name)
            return
        if lookup in {"gte", "lte"}:
            if not self.supports_range_lookups:
                raise TypeError(f"{field_name} does not support {lookup} lookups.")
            self.validate(value, field_name=field_name)
            return
        raise ValueError(f"Unsupported lookup '{lookup}' for {field_name}.")

    def has_default(self) -> bool:
        return self.default is not _NO_DEFAULT

    def get_default(self) -> Any:
        if self.default is _NO_DEFAULT:
            raise ValueError("VectorField has no default.")
        return self.default


class TextField(VectorField):
    """Text payload field."""

    kind = "text"

    def validate(self, value: Any, *, field_name: str | None = None) -> None:
        if not isinstance(value, str):
            target = field_name or self.name or "value"
            raise TypeError(f"{target} must be a string.")


class StringField(VectorField):
    """String payload field."""

    kind = "string"

    def validate(self, value: Any, *, field_name: str | None = None) -> None:
        if not isinstance(value, str):
            target = field_name or self.name or "value"
            raise TypeError(f"{target} must be a string.")


class IntegerField(VectorField):
    """Integer payload field."""

    kind = "integer"
    supports_range_lookups = True

    def validate(self, value: Any, *, field_name: str | None = None) -> None:
        if isinstance(value, bool) or not isinstance(value, int):
            target = field_name or self.name or "value"
            raise TypeError(f"{target} must be an integer.")


class FloatField(VectorField):
    """Numeric payload field."""

    kind = "float"
    supports_range_lookups = True

    def validate(self, value: Any, *, field_name: str | None = None) -> None:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            target = field_name or self.name or "value"
            raise TypeError(f"{target} must be a number.")


class BooleanField(VectorField):
    """Boolean payload field."""

    kind = "boolean"

    def validate(self, value: Any, *, field_name: str | None = None) -> None:
        if not isinstance(value, bool):
            target = field_name or self.name or "value"
            raise TypeError(f"{target} must be a boolean.")


class JsonField(VectorField):
    """JSON payload field."""

    kind = "json"

    def validate(self, value: Any, *, field_name: str | None = None) -> None:
        if not _is_json_value(value):
            target = field_name or self.name or "value"
            raise TypeError(f"{target} must be JSON-serializable.")


class VectorQuery:
    """Query-like wrapper over one bound vector instance."""

    def __init__(
        self, vector: Vector, *, filters: dict[str, Any] | None = None
    ) -> None:
        self._vector = vector
        self._filters = dict(filters or {})

    def filter(self, **kwargs: Any) -> VectorQuery:
        compiled = self._vector._compile_filters(kwargs)
        merged = dict(self._filters)
        for field_name, value in compiled.items():
            if (
                field_name in merged
                and isinstance(merged[field_name], dict)
                and isinstance(value, dict)
            ):
                merged[field_name] = {**merged[field_name], **value}
            else:
                merged[field_name] = value
        return VectorQuery(self._vector, filters=merged)

    def search(
        self,
        query_or_embedding: list[float],
        *,
        limit: int | None = None,
        score_threshold: float | None = None,
    ) -> list[VectorSearchResult]:
        return self._vector._search_internal(
            query_or_embedding,
            limit=limit,
            filters=self._filters or None,
            score_threshold=score_threshold,
        )

    def delete(self, ids: list[str] | None = None) -> int:
        if ids is None:
            raise TypeError(
                "delete() requires explicit ids; delete-by-filter is not supported."
            )
        return self._vector._client().delete(ids)

    def stats(self) -> dict[str, Any]:
        return self._vector._stats_internal(filters=self._filters or None)

    def count(self) -> int:
        return self._vector._count_internal(filters=self._filters or None)


class VectorManager:
    """Django-like manager for one bound vector instance."""

    def __init__(self, vector: Vector) -> None:
        self._vector = vector

    def filter(self, **kwargs: Any) -> VectorQuery:
        return VectorQuery(self._vector).filter(**kwargs)

    def search(
        self,
        query_or_embedding: list[float],
        *,
        limit: int | None = None,
        score_threshold: float | None = None,
    ) -> list[VectorSearchResult]:
        return VectorQuery(self._vector).search(
            query_or_embedding,
            limit=limit,
            score_threshold=score_threshold,
        )

    def index(
        self,
        embedding: list[float],
        *,
        id: str | None = None,
        **field_values: Any,
    ) -> str:
        if not _is_embedding(embedding):
            raise TypeError("index() expects an embedding vector.")
        metadata = self._vector._build_index_metadata(field_values)
        return self._vector._client().upsert(
            [float(item) for item in embedding], id=id, metadata=metadata
        )

    def delete(self, ids: list[str] | None = None) -> int:
        return VectorQuery(self._vector).delete(ids)

    def stats(self) -> dict[str, Any]:
        return VectorQuery(self._vector).stats()

    def count(self) -> int:
        return VectorQuery(self._vector).count()


class Vector:
    """Project-local logical vector binding with Django-like declaration style."""

    alias: ClassVar[str | None] = None
    name: ClassVar[str | None] = None
    description: ClassVar[str | None] = None
    dimension: ClassVar[int | None] = None
    metric: ClassVar[Metric | None] = None
    default_limit: ClassVar[int | None] = None

    _aimp_vector_alias: ClassVar[str]
    _aimp_vector_name: ClassVar[str]
    _aimp_vector_description: ClassVar[str]
    _aimp_vector_fields: ClassVar[dict[str, VectorField]]
    _aimp_vector_dimension: ClassVar[int | None]
    _aimp_vector_metric: ClassVar[Metric | None]
    _aimp_vector_default_limit: ClassVar[int | None]

    def __init_subclass__(cls) -> None:
        super().__init_subclass__()
        if cls is Vector or cls.__name__ == "VectorKnowledge":
            return

        if "Meta" in cls.__dict__:
            raise ValueError(
                f"{cls.__name__}.Meta authoring was removed. Declare vector config as class attributes instead."
            )

        alias_value = getattr(cls, "alias", None)
        if not isinstance(alias_value, str) or not alias_value.strip():
            raise TypeError(f"{cls.__name__}.alias must be a non-empty string.")
        vector_alias = _normalize_alias(alias_value)

        name_value = getattr(cls, "name", None)
        if not isinstance(name_value, str) or not name_value.strip():
            raise TypeError(f"{cls.__name__}.name must be a non-empty string.")
        vector_name = name_value.strip()

        description_value = getattr(cls, "description", None)
        if not isinstance(description_value, str) or not description_value.strip():
            raise TypeError(f"{cls.__name__}.description must be a non-empty string.")
        vector_description = description_value.strip()

        dimension = getattr(cls, "dimension", None)
        if dimension is None:
            raise TypeError(f"{cls.__name__}.dimension must be a positive integer.")
        if (
            isinstance(dimension, bool)
            or not isinstance(dimension, int)
            or dimension <= 0
        ):
            raise TypeError(f"{cls.__name__}.dimension must be a positive integer.")

        metric = getattr(cls, "metric", None)
        if metric is None:
            raise TypeError(f"{cls.__name__}.metric must be a Metric enum value.")
        if not isinstance(metric, Metric):
            raise TypeError(f"{cls.__name__}.metric must be a Metric enum value.")

        default_limit = getattr(cls, "default_limit", None)
        if default_limit is not None:
            if (
                isinstance(default_limit, bool)
                or not isinstance(default_limit, int)
                or default_limit <= 0
            ):
                raise TypeError(
                    f"{cls.__name__}.default_limit must be a positive integer when provided."
                )

        fields: dict[str, VectorField] = {}
        for base in reversed(cls.__mro__[1:]):
            fields.update(dict(getattr(base, "_aimp_vector_fields", {})))
        declared_here = [
            (field_name, value)
            for field_name, value in cls.__dict__.items()
            if isinstance(value, VectorField)
        ]
        declared_here.sort(key=lambda item: item[1].creation_order)
        for field_name, field in declared_here:
            field.name = field_name
            fields[field_name] = field

        cls._aimp_vector_alias = vector_alias
        cls._aimp_vector_name = vector_name
        cls._aimp_vector_description = vector_description
        cls._aimp_vector_dimension = dimension
        cls._aimp_vector_metric = metric
        cls._aimp_vector_default_limit = default_limit
        cls._aimp_vector_fields = fields

    @property
    def vector_alias(self) -> str:
        """Return the logical alias resolved for this vector class."""
        return type(self)._aimp_vector_alias

    @property
    def alias(self) -> str:
        """Return the public collection alias."""
        return type(self)._aimp_vector_alias

    @property
    def description(self) -> str:
        """Return the public collection description."""
        return type(self)._aimp_vector_description

    @property
    def objects(self) -> VectorManager:
        """Return the manager bound to this vector instance."""
        return VectorManager(self)

    @property
    def declared_fields(self) -> dict[str, VectorField]:
        """Return declared payload fields in source order."""
        return dict(type(self)._aimp_vector_fields)

    def _client(self) -> VectorClient:
        return VectorClient(resource_alias=self.vector_alias)

    def _resolve_field_and_lookup(self, raw_key: str) -> tuple[str, str, VectorField]:
        if "__" in raw_key:
            field_name, lookup = raw_key.split("__", 1)
        else:
            field_name, lookup = raw_key, "exact"
        field = type(self)._aimp_vector_fields.get(field_name)
        if field is None:
            raise ValueError(
                f"{type(self).__name__} does not declare a field named '{field_name}'."
            )
        if not field.filterable:
            raise ValueError(f"{type(self).__name__}.{field_name} is not filterable.")
        return field_name, lookup, field

    def _compile_filters(self, filters: dict[str, Any] | None) -> dict[str, Any]:
        if filters is None:
            return {}
        if not isinstance(filters, dict):
            raise TypeError("filters must be a dict when provided.")
        compiled: dict[str, Any] = {}
        for raw_key, value in filters.items():
            field_name, lookup, field = self._resolve_field_and_lookup(raw_key)
            field.validate_lookup(lookup, value, field_name=field_name)
            if lookup == "exact":
                compiled[field_name] = value
                continue
            operator = f"${lookup}"
            existing = compiled.get(field_name)
            if existing is None:
                compiled[field_name] = {operator: value}
            elif isinstance(existing, dict):
                existing[operator] = value
            else:
                raise ValueError(
                    f"Cannot combine exact and lookup filters for '{field_name}' in one query."
                )
        return compiled

    def _resolve_search_embedding(self, embedding: list[float]) -> list[float]:
        if _is_embedding(embedding):
            return [float(item) for item in embedding]
        raise TypeError("search() expects an embedding vector.")

    def _build_index_metadata(
        self, field_values: dict[str, Any]
    ) -> dict[str, JsonValue]:
        if not isinstance(field_values, dict):
            raise TypeError(
                "index() field values must be provided as keyword arguments."
            )
        unknown = sorted(set(field_values) - set(type(self)._aimp_vector_fields))
        if unknown:
            raise ValueError(
                f"{type(self).__name__}.objects.index() received undeclared fields: {', '.join(unknown)}."
            )

        metadata: dict[str, JsonValue] = {}
        for field_name, field in type(self)._aimp_vector_fields.items():
            if field_name in field_values:
                value = field_values[field_name]
            elif field.has_default():
                value = field.get_default()
            elif field.required:
                raise ValueError(
                    f"{type(self).__name__}.objects.index() requires field '{field_name}'."
                )
            else:
                continue
            field.validate(value, field_name=field_name)
            metadata[field_name] = value
        return metadata

    def _search_internal(
        self,
        query_or_embedding: list[float],
        *,
        limit: int | None = None,
        filters: dict[str, Any] | None = None,
        score_threshold: float | None = None,
    ) -> list[VectorSearchResult]:
        resolved_limit = (
            limit
            if limit is not None
            else (type(self)._aimp_vector_default_limit or 10)
        )
        embedding = self._resolve_search_embedding(query_or_embedding)
        return self._client().search(
            embedding,
            limit=resolved_limit,
            filters=filters,
            score_threshold=score_threshold,
        )

    def _stats_internal(
        self, *, filters: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        return self._client().stats(filters=filters)

    def _count_internal(self, *, filters: dict[str, Any] | None = None) -> int:
        return self._client().count(filters=filters)

    def search(
        self,
        query_or_embedding: list[float],
        *,
        limit: int | None = None,
        filters: dict[str, Any] | None = None,
        score_threshold: float | None = None,
    ) -> list[VectorSearchResult]:
        """Compatibility wrapper for direct vector search."""
        return self.objects.filter(**(filters or {})).search(
            query_or_embedding,
            limit=limit,
            score_threshold=score_threshold,
        )

    def index(
        self,
        embedding: list[float],
        *,
        metadata: dict[str, JsonValue] | None = None,
        id: str | None = None,
    ) -> str:
        """Compatibility wrapper for direct vector upsert."""
        return self._client().upsert(embedding, id=id, metadata=metadata)

    def delete(self, ids: list[str]) -> int:
        """Delete vectors by ID from this logical vector binding."""
        return self._client().delete(ids)

    def stats(self) -> dict[str, Any]:
        """Return runtime stats for this logical vector binding."""
        return self.objects.stats()

    def count(self) -> int:
        """Convenience wrapper that returns the current vector count."""
        return self.objects.count()


class VectorKnowledge(Vector):
    """Legacy alias for model-scoped vector resources."""

    def search(self, vector: list[float], top_k: int = 10) -> list["Hit"]:
        results = Vector.search(self, vector, limit=top_k)
        hits: list[Hit] = []
        for result in results:
            payload = result.payload if isinstance(result.payload, dict) else {}
            text = payload.get("text", "") if isinstance(payload, dict) else ""
            metadata = payload.get("metadata", {}) if isinstance(payload, dict) else {}
            if not isinstance(metadata, dict):
                metadata = {}
            hits.append(
                Hit(
                    id=result.id,
                    score=result.score,
                    text=str(text),
                    metadata=metadata,
                )
            )
        return hits

    def insert(
        self,
        text: str,
        vector: list[float],
        metadata: dict[str, JsonValue] | None = None,
    ) -> None:
        Vector.index(
            self,
            vector,
            metadata={
                "text": text,
                "metadata": dict(metadata or {}),
            },
        )

    def insert_many(
        self,
        texts: list[str],
        vectors: list[list[float]],
    ) -> None:
        if len(texts) != len(vectors):
            raise ValueError(
                "insert_many() expects the same number of texts and vectors."
            )
        for text, vector in zip(texts, vectors, strict=True):
            self.insert(text=text, vector=vector)


@dataclass(frozen=True)
class Hit:
    """Platform search hit surfaced by vector search helpers."""

    id: str
    score: float
    text: str
    metadata: dict[str, Any]
