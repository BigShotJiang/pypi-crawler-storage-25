"""Manifest parsing for v2 agent contracts."""

from __future__ import annotations

from pathlib import Path
import tomllib
from typing import Any


def contract_path_for_module(module_path: str | Path) -> Path:
    """Return the sibling runtime contract path for one entrypoint."""
    module_file = Path(module_path).resolve()
    runtime_contract = module_file.parent / "runtime" / "contract.toml"
    if runtime_contract.exists():
        return runtime_contract
    return module_file.parent / "contract.toml"


def load_agent_contract(module_path: str | Path) -> dict[str, Any]:
    """Load agent metadata and optional manifest hints from disk."""
    contract_path = contract_path_for_module(module_path)
    if not contract_path.exists():
        raise FileNotFoundError(f"Agent contract not found: {contract_path}")
    payload = tomllib.loads(contract_path.read_text(encoding="utf-8"))
    if "parameters" in payload:
        raise ValueError("Root-level parameters are not allowed in contract.toml")

    schema_version = payload.get("schema_version")
    capabilities = payload.get("capabilities") or {}
    if capabilities and not isinstance(capabilities, dict):
        raise ValueError("[capabilities] must be a TOML table")
    modes = payload.get("modes") or {}
    if modes and not isinstance(modes, dict):
        raise ValueError("[modes] must be a TOML table when declared")
    agent_metadata = payload.get("agent") or {}
    if agent_metadata and not isinstance(agent_metadata, dict):
        raise ValueError("[agent] must be a TOML table when declared")

    normalized_modes: dict[str, dict[str, Any]] = {}
    for raw_name, raw_mode in modes.items():
        mode_name = str(raw_name or "").strip().lower()
        if not mode_name:
            raise ValueError("Mode names must be non-empty")
        if not isinstance(raw_mode, dict):
            raise ValueError(f"[modes.{mode_name}] must be a TOML table")
        enabled = bool(raw_mode.get("enabled", True))
        if not enabled:
            continue
        normalized_modes[mode_name] = raw_mode

    return {
        "schema_version": int(schema_version) if schema_version is not None else None,
        "agent": {
            "name": str(agent_metadata.get("name", "") or "").strip(),
            "version": str(agent_metadata.get("version", "") or "").strip(),
            "author": str(agent_metadata.get("author", "") or "").strip(),
            "description": str(agent_metadata.get("description", "") or "").strip(),
        },
        "capabilities": {
            "vector": bool(capabilities.get("vector", False)),
            "tuning": bool(capabilities.get("tuning", False)),
        },
        "modes": normalized_modes,
        "tuning": payload.get("tuning"),
    }
