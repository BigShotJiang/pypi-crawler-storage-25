"""Build-time runner for framework-driven agent projects."""

from __future__ import annotations

import argparse
import os
import sys
from typing import Any

from .agent_loader import load_agent_class


def _module_path_from_env() -> str:
    return os.environ.get("MODEL_ENTRYPOINT", "").strip()


def run_build(module_path: str) -> None:
    """Load root agent and invoke its engine build hook.

    The root agent is a deployable runtime with its own build process.
    Workers are built separately as independent runtime units.
    """
    agent_cls = load_agent_class(module_path)
    agent = agent_cls()

    # Build root agent engine if present
    engine = getattr(agent, "engine", None)
    if engine is not None:
        build = getattr(engine, "build", None)
        if build is not None:
            build()


def main() -> None:
    parser = argparse.ArgumentParser(description="AI Marketplace build runner")
    parser.add_argument(
        "--module",
        dest="module_path",
        default=None,
        help="Path to the agent module (defaults to MODEL_ENTRYPOINT env var).",
    )
    args = parser.parse_args()
    module_path = args.module_path or _module_path_from_env()
    if not module_path:
        print(
            "Missing agent module path. Set MODEL_ENTRYPOINT or pass --module.",
            file=sys.stderr,
        )
        raise SystemExit(1)

    try:
        run_build(module_path)
    except Exception as exc:  # noqa: BLE001
        print(str(exc), file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
