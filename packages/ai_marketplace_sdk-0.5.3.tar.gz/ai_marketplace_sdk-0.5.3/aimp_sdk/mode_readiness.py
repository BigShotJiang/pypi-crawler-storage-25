"""CLI helper to output SDK mode implementation status as JSON."""

from __future__ import annotations

import argparse
import json
import sys

from .loader import load_mode_implementations


def main() -> None:
    """Load model mode implementation status from a module and print JSON."""
    parser = parser = argparse.ArgumentParser(
        description="Export model mode implementation status"
    )
    parser.add_argument(
        "--module",
        dest="module_path",
        required=True,
        help="Path to the model module file (e.g., /workspace/agent.py).",
    )
    args = parser.parse_args()

    try:
        readiness = load_mode_implementations(args.module_path)
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"error": str(exc)}))
        sys.exit(1)

    print(json.dumps(readiness))


if __name__ == "__main__":
    main()
