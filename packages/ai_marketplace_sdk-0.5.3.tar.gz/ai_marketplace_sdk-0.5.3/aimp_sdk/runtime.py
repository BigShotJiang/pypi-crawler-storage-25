"""Runtime context primitives for model execution."""

from __future__ import annotations

from contextvars import ContextVar
from contextvars import Token
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal
import os


@dataclass(frozen=True)
class AcceleratorInfo:
    """Generic accelerator facts resolved by the runtime."""

    kind: Literal["cpu", "gpu", "unknown"] = "unknown"
    backend: str | None = None
    count: int = 0
    identifiers: tuple[str, ...] = ()


@dataclass(frozen=True)
class ExecutionLimits:
    """Execution limits applied by the runtime."""

    cpu: str | None = None
    memory_mb: int | None = None
    timeout_seconds: int | None = None


@dataclass(frozen=True)
class ProcessContext:
    """Stable process-local context exposed during model setup/teardown."""

    model_id: str = ""
    artifacts_dir: Path = Path(".")
    cache_dir: Path = Path(".cache")
    work_dir: Path = Path(".")
    limits: ExecutionLimits = ExecutionLimits()
    accelerator: AcceleratorInfo = AcceleratorInfo()
    composition_manifest: dict[str, Any] | None = None

    def component_dir(self, name: str) -> Path:
        """Return the platform-managed directory for one component bundle."""
        normalized = str(name or "").strip()
        if not normalized:
            raise ValueError("component name is required")
        return self.artifacts_dir / "components" / normalized


@dataclass(frozen=True)
class RuntimeContext:
    """Platform-owned execution context exposed to model code."""

    model_id: str = ""
    mode: str = "execute"
    request_id: str | None = None
    artifacts_dir: Path = Path(".")
    cache_dir: Path = Path(".cache")
    work_dir: Path = Path(".")
    limits: ExecutionLimits = ExecutionLimits()
    accelerator: AcceleratorInfo = AcceleratorInfo()
    composition_manifest: dict[str, Any] | None = None

    def component_dir(self, name: str) -> Path:
        """Return the platform-managed directory for one component bundle."""
        normalized = str(name or "").strip()
        if not normalized:
            raise ValueError("component name is required")
        return self.artifacts_dir / "components" / normalized


@dataclass(frozen=True)
class VectorExecutionContext:
    """Request-scoped vector access metadata resolved by the runtime."""

    gateway_url: str = ""
    execution_token: str = ""
    model_id: str = ""
    vector_resources: tuple[dict[str, Any], ...] = ()
    timeout_seconds: float | None = None
    request_id: str | None = None


_current_runtime_context: ContextVar[RuntimeContext | None] = ContextVar(
    "aimp_current_runtime_context",
    default=None,
)
_current_vector_context: ContextVar[VectorExecutionContext | None] = ContextVar(
    "aimp_current_vector_context",
    default=None,
)


def process_context_from_env() -> ProcessContext:
    """Build a process-local context from startup environment variables."""
    return ProcessContext(
        model_id=_optional_env("AIMP_MODEL_ID") or _optional_env("MODEL_ID") or "",
        artifacts_dir=_path_env("MODEL_ARTIFACTS_DIR", default="/app/artifacts"),
        cache_dir=_path_env("MODEL_CACHE_DIR", default="/tmp/aimp-cache"),
        work_dir=_path_env("MODEL_WORK_DIR", default="/tmp/aimp-work"),
        limits=_execution_limits_from_env(),
        accelerator=_accelerator_info_from_env(),
    )


def runtime_context_from_env(mode: str) -> RuntimeContext:
    """Build a runtime context from the current execution environment."""
    request_id = _optional_env("MODEL_REQUEST_ID") or _optional_env("AIMP_REQUEST_ID")
    process_context = process_context_from_env()
    return RuntimeContext(
        model_id=process_context.model_id,
        mode=str(mode or "execute").strip().lower() or "execute",
        request_id=request_id,
        artifacts_dir=process_context.artifacts_dir,
        cache_dir=process_context.cache_dir,
        work_dir=process_context.work_dir,
        limits=process_context.limits,
        accelerator=process_context.accelerator,
    )


def runtime_context_from_payload(
    payload: dict[str, Any], *, mode: str
) -> RuntimeContext:
    """Build a runtime context from an execution payload."""
    limits_payload = (
        payload.get("limits") if isinstance(payload.get("limits"), dict) else {}
    )
    accelerator_payload = (
        payload.get("accelerator")
        if isinstance(payload.get("accelerator"), dict)
        else {}
    )
    accelerator_identifiers_raw = accelerator_payload.get("identifiers", [])
    accelerator_identifiers = tuple(
        str(item).strip() for item in accelerator_identifiers_raw if str(item).strip()
    )

    return RuntimeContext(
        model_id=str(payload.get("model_id", "") or "").strip(),
        mode=str(mode or "execute").strip().lower() or "execute",
        request_id=_normalize_optional_string(payload.get("request_id")),
        artifacts_dir=Path(str(payload.get("artifacts_dir", "/app/artifacts"))),
        cache_dir=Path(str(payload.get("cache_dir", "/tmp/aimp-cache"))),
        work_dir=Path(str(payload.get("work_dir", "/tmp/aimp-work"))),
        limits=ExecutionLimits(
            cpu=_normalize_optional_string(limits_payload.get("cpu")),
            memory_mb=_normalize_optional_int(limits_payload.get("memory_mb")),
            timeout_seconds=_normalize_optional_int(
                limits_payload.get("timeout_seconds")
            ),
        ),
        accelerator=AcceleratorInfo(
            kind=_normalize_accelerator_kind(accelerator_payload.get("kind")),
            backend=_normalize_optional_string(accelerator_payload.get("backend")),
            count=max(
                _normalize_optional_int(accelerator_payload.get("count")) or 0, 0
            ),
            identifiers=accelerator_identifiers,
        ),
        composition_manifest=(
            payload.get("composition_manifest")
            if isinstance(payload.get("composition_manifest"), dict)
            else None
        ),
    )


def vector_context_from_payload(
    payload: dict[str, Any] | None,
) -> VectorExecutionContext | None:
    """Build a vector execution context from a request payload."""
    if not isinstance(payload, dict):
        return None

    vector_resources_raw = payload.get("vector_resources", [])
    vector_resources: list[dict[str, Any]] = []
    if isinstance(vector_resources_raw, list):
        for item in vector_resources_raw:
            if isinstance(item, dict):
                vector_resources.append(item)

    timeout_seconds = payload.get("timeout_seconds")
    normalized_timeout: float | None
    if timeout_seconds is None:
        normalized_timeout = None
    else:
        try:
            normalized_timeout = float(timeout_seconds)
        except (TypeError, ValueError):
            normalized_timeout = None

    return VectorExecutionContext(
        gateway_url=str(payload.get("gateway_url", "") or "").strip(),
        execution_token=str(payload.get("execution_token", "") or "").strip(),
        model_id=str(payload.get("model_id", "") or "").strip(),
        vector_resources=tuple(vector_resources),
        timeout_seconds=normalized_timeout,
        request_id=_normalize_optional_string(payload.get("request_id")),
    )


def set_current_execution_context(
    runtime_context: RuntimeContext,
    vector_context: VectorExecutionContext | None,
) -> tuple[Token[RuntimeContext | None], Token[VectorExecutionContext | None]]:
    """Store request-scoped runtime/vector context for the current execution."""
    runtime_token = _current_runtime_context.set(runtime_context)
    vector_token = _current_vector_context.set(vector_context)
    return runtime_token, vector_token


def reset_current_execution_context(
    tokens: tuple[Token[RuntimeContext | None], Token[VectorExecutionContext | None]],
) -> None:
    """Reset request-scoped runtime/vector context after execution."""
    runtime_token, vector_token = tokens
    _current_runtime_context.reset(runtime_token)
    _current_vector_context.reset(vector_token)


def get_current_runtime_context() -> RuntimeContext | None:
    """Return the current request-scoped runtime context, if any."""
    return _current_runtime_context.get()


def get_current_vector_context() -> VectorExecutionContext | None:
    """Return the current request-scoped vector context, if any."""
    return _current_vector_context.get()


def _execution_limits_from_env() -> ExecutionLimits:
    """Build generic execution limits from environment variables."""
    return ExecutionLimits(
        cpu=_optional_env("MODEL_CPU_LIMIT"),
        memory_mb=_int_env("MODEL_MEMORY_MB"),
        timeout_seconds=_int_env("MODEL_TIMEOUT_SECONDS"),
    )


def _accelerator_info_from_env() -> AcceleratorInfo:
    """Build generic accelerator metadata from environment variables."""
    accelerator_kind = _enum_env(
        "MODEL_ACCELERATOR_KIND",
        allowed={"cpu", "gpu", "unknown"},
        default="unknown",
    )
    accelerator_backend = _optional_env("MODEL_ACCELERATOR_BACKEND")
    accelerator_count = _int_env("MODEL_ACCELERATOR_COUNT", default=0) or 0
    accelerator_identifiers = tuple(
        part.strip()
        for part in (_optional_env("MODEL_ACCELERATOR_IDENTIFIERS") or "").split(",")
        if part.strip()
    )
    return AcceleratorInfo(
        kind=accelerator_kind,
        backend=accelerator_backend,
        count=max(accelerator_count, 0),
        identifiers=accelerator_identifiers,
    )


def _optional_env(name: str) -> str | None:
    value = os.environ.get(name, "").strip()
    return value or None


def _path_env(name: str, *, default: str) -> Path:
    value = os.environ.get(name, "").strip() or default
    return Path(value)


def _int_env(name: str, *, default: int | None = None) -> int | None:
    value = os.environ.get(name, "").strip()
    if not value:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _enum_env(
    name: str,
    *,
    allowed: set[str],
    default: Literal["cpu", "gpu", "unknown"],
) -> Literal["cpu", "gpu", "unknown"]:
    value = os.environ.get(name, "").strip().lower()
    if value in allowed:
        return value  # type: ignore[return-value]
    return default


def _normalize_optional_string(value: Any) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    return normalized or None


def _normalize_optional_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _normalize_accelerator_kind(value: Any) -> Literal["cpu", "gpu", "unknown"]:
    normalized = str(value or "").strip().lower()
    if normalized in {"cpu", "gpu", "unknown"}:
        return normalized  # type: ignore[return-value]
    return "unknown"
