"""Fine-tune schema descriptors and author-facing tuning runtime types."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from importlib import util
from importlib import import_module
from pathlib import Path
from types import SimpleNamespace
from typing import TYPE_CHECKING, Any, Iterator, Literal
import os
import sys

if TYPE_CHECKING:
    from .tuning_data import LoadedTuningBundle

FieldValidator = Callable[[Any], None]
FieldPreprocessor = Callable[[Any], Any]
TuningFieldType = Literal["image", "audio", "video", "text", "file", "json"]
TuningStrategy = Literal["lora", "full_tune"]
TrainingRuntimeProfile = Literal["cpu", "gpu"]


@dataclass(slots=True)
class TuningField:
    """Descriptor for one fine-tune input field."""

    field_type: TuningFieldType
    required: bool = True
    description: str | None = None
    multiple: bool = False
    validators: tuple[FieldValidator, ...] = ()
    preprocessors: tuple[FieldPreprocessor, ...] = ()

    def to_contract(self, key: str) -> dict[str, Any]:
        """Serialize the field definition into a public contract shape."""
        return {
            "key": key,
            "type": self.field_type,
            "required": self.required,
            "description": self.description,
            "multiple": self.multiple,
        }

    def preprocess_value(self, value: Any) -> Any:
        """Run field preprocessors in declaration order."""
        processed = value
        for preprocessor in self.preprocessors:
            processed = preprocessor(processed)
        return processed

    def validate_value(self, value: Any) -> None:
        """Run field validators in declaration order."""
        for validator in self.validators:
            validator(value)


class ImageField(TuningField):
    """Image fine-tune input field."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
        multiple: bool = False,
        validators: list[FieldValidator] | tuple[FieldValidator, ...] | None = None,
        preprocessors: list[FieldPreprocessor]
        | tuple[FieldPreprocessor, ...]
        | None = None,
    ) -> None:
        super().__init__(
            field_type="image",
            required=required,
            description=description,
            multiple=multiple,
            validators=tuple(validators or ()),
            preprocessors=tuple(preprocessors or ()),
        )


class AudioField(TuningField):
    """Audio fine-tune input field."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
        multiple: bool = False,
        validators: list[FieldValidator] | tuple[FieldValidator, ...] | None = None,
        preprocessors: list[FieldPreprocessor]
        | tuple[FieldPreprocessor, ...]
        | None = None,
    ) -> None:
        super().__init__(
            field_type="audio",
            required=required,
            description=description,
            multiple=multiple,
            validators=tuple(validators or ()),
            preprocessors=tuple(preprocessors or ()),
        )


class VideoField(TuningField):
    """Video fine-tune input field."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
        multiple: bool = False,
        validators: list[FieldValidator] | tuple[FieldValidator, ...] | None = None,
        preprocessors: list[FieldPreprocessor]
        | tuple[FieldPreprocessor, ...]
        | None = None,
    ) -> None:
        super().__init__(
            field_type="video",
            required=required,
            description=description,
            multiple=multiple,
            validators=tuple(validators or ()),
            preprocessors=tuple(preprocessors or ()),
        )


class TextField(TuningField):
    """Text fine-tune input field."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
        multiple: bool = False,
        validators: list[FieldValidator] | tuple[FieldValidator, ...] | None = None,
        preprocessors: list[FieldPreprocessor]
        | tuple[FieldPreprocessor, ...]
        | None = None,
    ) -> None:
        super().__init__(
            field_type="text",
            required=required,
            description=description,
            multiple=multiple,
            validators=tuple(validators or ()),
            preprocessors=tuple(preprocessors or ()),
        )


class FileField(TuningField):
    """Generic file fine-tune input field."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
        multiple: bool = False,
        validators: list[FieldValidator] | tuple[FieldValidator, ...] | None = None,
        preprocessors: list[FieldPreprocessor]
        | tuple[FieldPreprocessor, ...]
        | None = None,
    ) -> None:
        super().__init__(
            field_type="file",
            required=required,
            description=description,
            multiple=multiple,
            validators=tuple(validators or ()),
            preprocessors=tuple(preprocessors or ()),
        )


class JsonField(TuningField):
    """JSON fine-tune input field."""

    def __init__(
        self,
        *,
        required: bool = True,
        description: str | None = None,
        multiple: bool = False,
        validators: list[FieldValidator] | tuple[FieldValidator, ...] | None = None,
        preprocessors: list[FieldPreprocessor]
        | tuple[FieldPreprocessor, ...]
        | None = None,
    ) -> None:
        super().__init__(
            field_type="json",
            required=required,
            description=description,
            multiple=multiple,
            validators=tuple(validators or ()),
            preprocessors=tuple(preprocessors or ()),
        )


class FineTuneSchema:
    """Base class for tuning schema definitions."""

    @classmethod
    def fields_contract(cls) -> list[dict[str, Any]]:
        """Return serialized field definitions in source order."""
        fields: list[dict[str, Any]] = []
        for key, value in cls.__dict__.items():
            if isinstance(value, TuningField):
                fields.append(value.to_contract(key))
        return fields

    @classmethod
    def contract(cls) -> dict[str, Any]:
        """Return the public fine-tune schema contract."""
        fields = cls.fields_contract()
        if not fields:
            raise ValueError("FineTuneSchema must declare at least one TuningField")
        return {"fields": fields}


class TuningRecord(SimpleNamespace):
    """One attribute-access training record materialized from the dataset bundle."""


class TuningParams(SimpleNamespace):
    """One attribute-access view of platform-supplied hyperparameters."""


@dataclass(slots=True)
class TuningDatasetView:
    """Author-facing dataset view that yields attribute-access records."""

    dataset: Any

    @property
    def num_rows(self) -> int:
        """Return the number of records exposed by this view."""
        return len(self.dataset)

    def __len__(self) -> int:
        return len(self.dataset)

    def __iter__(self) -> Iterator[TuningRecord]:
        for item in self.dataset:
            yield _materialize_record(item)

    def __getitem__(self, index: int) -> TuningRecord:
        return _materialize_record(self.dataset[index])


@dataclass(slots=True)
class TuneResult:
    """Structured tuning result returned by ``Component.tune(self, tuning)``."""

    metrics: dict[str, float]

    def __post_init__(self) -> None:
        if not isinstance(self.metrics, dict) or not self.metrics:
            raise ValueError("TuneResult.metrics must be a non-empty dict[str, float]")
        normalized: dict[str, float] = {}
        for raw_name, raw_value in self.metrics.items():
            name = str(raw_name).strip()
            if not name:
                raise ValueError("TuneResult.metrics keys must be non-empty")
            if not isinstance(raw_value, (int, float)):
                raise ValueError(
                    f"TuneResult.metrics['{name}'] must be numeric, got {type(raw_value).__name__}"
                )
            normalized[name] = float(raw_value)
        self.metrics = normalized


@dataclass(slots=True)
class TuningSession:
    """Author-facing tuning session passed into ``Component.tune(self, tuning)``."""

    train_dataset: TuningDatasetView
    validation_dataset: TuningDatasetView
    params: TuningParams
    artifacts_dir: Path
    cache_dir: Path
    work_dir: Path
    limits: Any
    accelerator: Any
    request_id: str | None
    trial_id: int | None
    _bundle: "LoadedTuningBundle"

    def resolve_path(self, relative_path: str) -> Path:
        """Resolve one dataset-relative asset path to an extracted absolute path."""
        return self._bundle.resolve_path(relative_path)

    def suggest_float(
        self,
        name: str,
        min_val: float,
        max_val: float,
        *,
        default: float,
    ) -> float:
        """Resolve one float parameter from backend values or explicit default."""
        key = _normalize_parameter_name(name)
        _ensure_numeric_bounds(min_val=min_val, max_val=max_val, kind="float", name=key)
        if isinstance(default, bool) or not isinstance(default, (int, float)):
            raise RuntimeError(f"Default for parameter '{key}' must be numeric")
        resolved = self._resolve_suggested_value(key=key, default=float(default))
        if isinstance(resolved, bool) or not isinstance(resolved, (int, float)):
            raise RuntimeError(f"Parameter '{key}' must be numeric")
        number = float(resolved)
        if number < float(min_val) or number > float(max_val):
            raise RuntimeError(
                f"Parameter '{key}' must be between {float(min_val)} and {float(max_val)}"
            )
        return number

    def suggest_int(
        self,
        name: str,
        min_val: int,
        max_val: int,
        *,
        default: int,
    ) -> int:
        """Resolve one integer parameter from backend values or explicit default."""
        key = _normalize_parameter_name(name)
        if isinstance(min_val, bool) or not isinstance(min_val, int):
            raise RuntimeError(f"min_val for parameter '{key}' must be an integer")
        if isinstance(max_val, bool) or not isinstance(max_val, int):
            raise RuntimeError(f"max_val for parameter '{key}' must be an integer")
        _ensure_numeric_bounds(
            min_val=min_val, max_val=max_val, kind="integer", name=key
        )
        if isinstance(default, bool) or not isinstance(default, int):
            raise RuntimeError(f"Default for parameter '{key}' must be an integer")
        resolved = self._resolve_suggested_value(key=key, default=default)
        if isinstance(resolved, bool) or not isinstance(resolved, int):
            raise RuntimeError(f"Parameter '{key}' must be an integer")
        if resolved < min_val or resolved > max_val:
            raise RuntimeError(
                f"Parameter '{key}' must be between {min_val} and {max_val}"
            )
        return resolved

    def suggest_categorical(
        self,
        name: str,
        choices: Sequence[Any],
        *,
        default: Any,
    ) -> Any:
        """Resolve one categorical parameter from backend values or explicit default."""
        key = _normalize_parameter_name(name)
        options = list(choices)
        if not options:
            raise RuntimeError(f"Parameter '{key}' choices must be non-empty")
        if default not in options:
            raise RuntimeError(f"Default for parameter '{key}' must be in choices")
        resolved = self._resolve_suggested_value(key=key, default=default)
        if resolved not in options:
            raise RuntimeError(
                f"Parameter '{key}' value '{resolved}' is not one of: {', '.join(str(item) for item in options)}"
            )
        return resolved

    def _resolve_suggested_value(self, *, key: str, default: Any) -> Any:
        if hasattr(self.params, key):
            return getattr(self.params, key)
        return default


@dataclass(slots=True)
class TuningContext:
    """Generic model-scoped tuning context for one trial/run."""

    input: dict[str, Any]
    parameters: dict[str, Any]
    runtime_context: Any
    process_context: Any


def _namespaceify(value: Any, *, namespace_type: type[SimpleNamespace]) -> Any:
    """Recursively convert JSON-like dict payloads into attribute-access namespaces."""
    if isinstance(value, dict):
        materialized: dict[str, Any] = {}
        for key, item in value.items():
            normalized_key = str(key).strip()
            materialized[normalized_key] = _namespaceify(
                item,
                namespace_type=TuningRecord,
            )
        return namespace_type(**materialized)
    if isinstance(value, list):
        return [_namespaceify(item, namespace_type=TuningRecord) for item in value]
    return value


def _normalize_parameter_name(name: str) -> str:
    normalized = str(name or "").strip()
    if not normalized:
        raise RuntimeError("Parameter name must be non-empty")
    return normalized


def _ensure_numeric_bounds(
    *, min_val: float, max_val: float, kind: str, name: str
) -> None:
    if isinstance(min_val, bool) or not isinstance(min_val, (int, float)):
        raise RuntimeError(f"min_val for parameter '{name}' must be numeric")
    if isinstance(max_val, bool) or not isinstance(max_val, (int, float)):
        raise RuntimeError(f"max_val for parameter '{name}' must be numeric")
    if float(max_val) < float(min_val):
        raise RuntimeError(
            f"max_val for parameter '{name}' must be >= min_val for {kind} suggestion"
        )


def _extract_param_definition(value: Any, *, name: str) -> dict[str, Any]:
    if hasattr(value, "to_contract") and callable(value.to_contract):
        payload = value.to_contract()
        if not isinstance(payload, dict):
            raise RuntimeError(
                f"Tuning parameter '{name}' to_contract() must return a dict"
            )
        return payload
    if isinstance(value, dict):
        return dict(value)
    raise RuntimeError(f"Tuning parameter '{name}' must be a parameter object or dict")


def _validate_parameter_definition(
    name: str, payload: dict[str, Any]
) -> dict[str, Any]:
    kind = str(payload.get("kind") or "").strip().lower()
    if kind not in {"integer", "float", "select"}:
        raise RuntimeError(
            f"Tuning parameter '{name}' kind must be one of: integer, float, select"
        )
    required = bool(payload.get("required", True))
    normalized: dict[str, Any] = {
        "kind": kind,
        "default": payload.get("default"),
        "required": required,
    }
    if kind in {"integer", "float"}:
        min_val = payload.get("min")
        max_val = payload.get("max")
        if min_val is None or max_val is None:
            raise RuntimeError(f"Tuning parameter '{name}' requires min and max")
        _ensure_numeric_bounds(
            min_val=float(min_val), max_val=float(max_val), kind=kind, name=name
        )
        normalized["min"] = int(min_val) if kind == "integer" else float(min_val)
        normalized["max"] = int(max_val) if kind == "integer" else float(max_val)
        if kind == "integer":
            if isinstance(payload.get("default"), bool) or not isinstance(
                payload.get("default"), int
            ):
                raise RuntimeError(
                    f"Tuning parameter '{name}' default must be an integer"
                )
        else:
            default = payload.get("default")
            if isinstance(default, bool) or not isinstance(default, (int, float)):
                raise RuntimeError(f"Tuning parameter '{name}' default must be numeric")
            normalized["default"] = float(default)
        if (
            normalized["default"] < normalized["min"]
            or normalized["default"] > normalized["max"]
        ):
            raise RuntimeError(
                f"Tuning parameter '{name}' default must be within min/max bounds"
            )
        step = payload.get("step")
        if step is not None:
            normalized["step"] = int(step) if kind == "integer" else float(step)
        log = payload.get("log")
        if log:
            normalized["log"] = bool(log)
    else:
        options = payload.get("options")
        if not isinstance(options, list) or not options:
            raise RuntimeError(
                f"Tuning parameter '{name}' select requires non-empty options"
            )
        if payload.get("default") not in options:
            raise RuntimeError(
                f"Tuning parameter '{name}' default must be one of options"
            )
        normalized["options"] = options
    return normalized


def _normalized_runner_parameters(runner_cls: type[Any]) -> dict[str, dict[str, Any]]:
    raw = getattr(runner_cls, "parameters", {})
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise RuntimeError("Tuning runner parameters must be a dict")
    normalized: dict[str, dict[str, Any]] = {}
    for raw_name, raw_value in raw.items():
        name = str(raw_name or "").strip()
        if not name:
            raise RuntimeError("Tuning parameter names must be non-empty")
        payload = _extract_param_definition(raw_value, name=name)
        normalized[name] = _validate_parameter_definition(name, payload)
    return normalized


def _schema_class_from_dataset_module(module_name: str) -> type[FineTuneSchema]:
    module = import_module(module_name)
    subclasses = _find_schema_subclasses(module)
    if not subclasses:
        raise RuntimeError(
            f"No FineTuneSchema subclass found in module '{module_name}'"
        )
    if len(subclasses) > 1:
        names = ", ".join(sorted(cls.__name__ for cls in subclasses))
        raise RuntimeError(
            f"Multiple FineTuneSchema subclasses found in module '{module_name}': {names}"
        )
    return subclasses[0]


def _derive_model_key(model_cls: type[Any]) -> str:
    module_name = str(getattr(model_cls, "__module__", "") or "")
    parts = module_name.split(".")
    for index, part in enumerate(parts):
        if part == "models" and index + 1 < len(parts):
            key = str(parts[index + 1] or "").strip()
            if key:
                return key
    return str(getattr(model_cls, "__name__", "") or "").strip().lower()


def _resolve_tuning_model_class(module_path: str, model_key: str) -> type[Any]:
    from .loader import load_model_class

    normalized_key = str(model_key or "").strip().lower()
    if not normalized_key:
        raise RuntimeError("model_key is required to resolve model-scoped tuning")

    agent_module_path = Path(module_path).resolve()
    project_root = agent_module_path.parent
    model_module_path = project_root / "models" / normalized_key / "model.py"
    if not model_module_path.exists():
        raise RuntimeError(
            f"Model key '{model_key}' could not be resolved at models/{normalized_key}/model.py"
        )
    return load_model_class(str(model_module_path))


def load_model_tuning_contract(module_path: str, *, model_key: str) -> dict[str, Any]:
    """Load model-scoped tuning metadata and dataset schema contract from agent.py."""
    if not module_path or not os.path.exists(module_path):
        raise FileNotFoundError(f"Agent module not found: {module_path}")

    model_cls = _resolve_tuning_model_class(module_path, model_key)
    tuning_runner_cls = getattr(model_cls, "tuning", None)
    if tuning_runner_cls is None:
        raise RuntimeError(
            f"Model '{model_cls.__name__}' does not declare tuning capability (missing tuning class)"
        )
    if not isinstance(tuning_runner_cls, type):
        raise RuntimeError(
            f"Model '{model_cls.__name__}' tuning declaration must reference a class"
        )

    strategy = str(getattr(tuning_runner_cls, "strategy", "") or "").strip().lower()
    if strategy not in {"lora", "full_tune"}:
        raise RuntimeError(
            f"Tuning runner '{tuning_runner_cls.__name__}' must declare supported strategy"
        )
    training_runtime_profile = (
        str(getattr(tuning_runner_cls, "training_runtime_profile", "") or "")
        .strip()
        .lower()
    )
    if training_runtime_profile not in {"cpu", "gpu"}:
        raise RuntimeError(
            f"Tuning runner '{tuning_runner_cls.__name__}' must declare training_runtime_profile as 'cpu' or 'gpu'"
        )

    dataset_module_name = f"{model_cls.__module__.rsplit('.', 1)[0]}.tuning.dataset"
    schema_cls = _schema_class_from_dataset_module(dataset_module_name)
    parameters = _normalized_runner_parameters(tuning_runner_cls)

    objective = getattr(tuning_runner_cls, "objective", None)
    split_policy = getattr(tuning_runner_cls, "split_policy", None)
    dataset_requirements = getattr(tuning_runner_cls, "dataset_requirements", None)
    dataset_spec = getattr(tuning_runner_cls, "dataset_spec", None)
    for key, value in (
        ("objective", objective),
        ("split_policy", split_policy),
        ("dataset_requirements", dataset_requirements),
        ("dataset_spec", dataset_spec),
    ):
        if not isinstance(value, dict):
            raise RuntimeError(
                f"Tuning runner '{tuning_runner_cls.__name__}' must declare '{key}' as a dict"
            )

    return {
        "supported": True,
        "model_key": str(model_key).strip().lower(),
        "strategy": strategy,
        "training_runtime_profile": training_runtime_profile,
        "dataset_requirements": dict(dataset_requirements),
        "dataset_spec": dict(dataset_spec),
        "objective": dict(objective),
        "split_policy": dict(split_policy),
        "schema": schema_cls.contract(),
        "parameters": parameters,
    }


def _materialize_record(value: Any) -> TuningRecord:
    """Convert one dataset record dict into an attribute-access object."""
    if not isinstance(value, dict):
        raise RuntimeError("Fine-tune dataset rows must be JSON objects")
    materialized = _namespaceify(value, namespace_type=TuningRecord)
    if not isinstance(materialized, TuningRecord):
        raise RuntimeError("Failed to materialize fine-tune dataset record")
    return materialized


def _materialize_params(parameters: dict[str, Any]) -> TuningParams:
    """Convert trial parameter payload into an attribute-access namespace."""
    materialized: dict[str, Any] = {}
    for raw_key, raw_value in parameters.items():
        key = str(raw_key).strip()
        if not key:
            raise RuntimeError("Fine-tune parameter names must be non-empty")
        materialized[key] = _namespaceify(raw_value, namespace_type=TuningRecord)
    return TuningParams(**materialized)


def _empty_validation_dataset(dataset: Any) -> Any:
    """Return an empty dataset with the same schema as the training dataset."""
    return dataset.select([])


def _split_bundle_dataset(
    bundle: "LoadedTuningBundle", input_data: dict[str, Any]
) -> tuple[Any, Any]:
    """Split one extracted bundle into train/validation datasets."""
    split_policy = (
        input_data.get("split_policy")
        if isinstance(input_data.get("split_policy"), dict)
        else {}
    )
    strategy = str(split_policy.get("strategy") or "auto").strip().lower() or "auto"
    if strategy in {"none", "disabled"}:
        return bundle.dataset, _empty_validation_dataset(bundle.dataset)
    if strategy != "auto":
        raise RuntimeError(f"Unsupported tuning split strategy: {strategy}")

    raw_validation_ratio = split_policy.get("validation_ratio", 0.1)
    try:
        validation_ratio = float(raw_validation_ratio)
    except (TypeError, ValueError) as exc:
        raise RuntimeError("split_policy.validation_ratio must be numeric") from exc

    if not 0.0 < validation_ratio < 1.0:
        raise RuntimeError("split_policy.validation_ratio must be between 0 and 1")

    if len(bundle.dataset) < 2:
        raise RuntimeError(
            "Fine-tune dataset must contain at least 2 records when validation split is enabled"
        )

    split = bundle.dataset.train_test_split(
        test_size=validation_ratio, seed=42, shuffle=True
    )
    return split["train"], split["test"]


def _find_schema_subclasses(module: Any) -> list[type[FineTuneSchema]]:
    subclasses: list[type[FineTuneSchema]] = []
    for value in vars(module).values():
        if (
            isinstance(value, type)
            and _is_fine_tune_schema_subclass(value)
            and getattr(value, "__module__", None) == module.__name__
        ):
            subclasses.append(value)
    return subclasses


def _is_fine_tune_schema_subclass(value: type[Any]) -> bool:
    for base in value.__mro__[1:]:
        if base.__name__ != "FineTuneSchema":
            continue
        if base.__module__.endswith("aimp_sdk.tuning"):
            return True
    return False


def _purge_modules_for_path(module_dir: str) -> None:
    """Remove cached modules loaded from one project directory."""
    normalized_dir = os.path.abspath(module_dir)
    prefix = f"{normalized_dir}{os.sep}"
    for module_name, module in list(sys.modules.items()):
        if (
            module_name == "aimp_user_tuning_schema"
            or module_name == "modes"
            or module_name.startswith("modes.")
            or module_name == "components"
            or module_name.startswith("components.")
            or module_name == "settings"
            or module_name == "resources"
            or module_name == "src"
            or module_name.startswith("src.")
        ):
            sys.modules.pop(module_name, None)
            continue
        module_file = getattr(module, "__file__", None)
        if isinstance(module_file, str):
            normalized_file = os.path.abspath(module_file)
            if normalized_file == normalized_dir or normalized_file.startswith(prefix):
                sys.modules.pop(module_name, None)
                continue
        module_paths = getattr(module, "__path__", None)
        if module_paths is None:
            continue
        for entry in module_paths:
            normalized_entry = os.path.abspath(str(entry))
            if normalized_entry == normalized_dir or normalized_entry.startswith(
                prefix
            ):
                sys.modules.pop(module_name, None)
                break


def load_tuning_schema_class(module_path: str) -> type[FineTuneSchema]:
    """Load a FineTuneSchema subclass from a Python module path."""
    if not module_path or not os.path.exists(module_path):
        msg = f"Tuning schema module not found: {module_path}"
        raise FileNotFoundError(msg)

    spec = util.spec_from_file_location("aimp_user_tuning_schema", module_path)
    if spec is None or spec.loader is None:
        msg = f"Failed to load module spec: {module_path}"
        raise ImportError(msg)

    module = util.module_from_spec(spec)
    module_dir = os.path.dirname(os.path.abspath(module_path))
    _purge_modules_for_path(module_dir)
    sys.modules["aimp_user_tuning_schema"] = module
    sys.path.insert(0, module_dir)
    try:
        spec.loader.exec_module(module)
    finally:
        sys.path.remove(module_dir)

    subclasses = _find_schema_subclasses(module)
    if not subclasses:
        raise ValueError("No FineTuneSchema subclass found in module")
    if len(subclasses) > 1:
        names = ", ".join(sorted(cls.__name__ for cls in subclasses))
        raise ValueError(f"Multiple FineTuneSchema subclasses found: {names}")
    return subclasses[0]


def load_tuning_schema_contract(module_path: str) -> dict[str, Any]:
    """Load the serialized fine-tune schema contract from a module path."""
    schema_cls = load_tuning_schema_class(module_path)
    return schema_cls.contract()


@contextmanager
def open_tuning_session(
    input_data: dict[str, Any],
    parameters: dict[str, Any],
    *,
    process_context: Any,
    runtime_context: Any,
) -> Iterator[TuningSession]:
    """Open one validated fine-tune bundle and expose the author-facing tuning session."""
    from .tuning_data import load_tuning_dataset_bundle

    dataset_path = str(input_data.get("dataset_path") or "").strip()
    if not dataset_path:
        raise RuntimeError("dataset_path is required for fine-tune execution")

    bundle = load_tuning_dataset_bundle(dataset_path)
    try:
        train_dataset, validation_dataset = _split_bundle_dataset(bundle, input_data)
        trial_id_raw = input_data.get("trial_id")
        trial_id = int(trial_id_raw) if isinstance(trial_id_raw, int) else None
        yield TuningSession(
            train_dataset=TuningDatasetView(train_dataset),
            validation_dataset=TuningDatasetView(validation_dataset),
            params=_materialize_params(parameters),
            artifacts_dir=Path(str(getattr(process_context, "artifacts_dir", "."))),
            cache_dir=Path(str(getattr(runtime_context, "cache_dir", ".cache"))),
            work_dir=Path(str(getattr(runtime_context, "work_dir", "."))),
            limits=getattr(runtime_context, "limits", None),
            accelerator=getattr(runtime_context, "accelerator", None),
            request_id=getattr(runtime_context, "request_id", None),
            trial_id=trial_id,
            _bundle=bundle,
        )
    finally:
        bundle.cleanup()
