"""SDK entrypoint for model runtime execution."""

from __future__ import annotations

import argparse
import json
import os
import sys

from .loader import execute_from_env


def main() -> None:
    """Execute one model runtime module from environment."""
    parser = argparse.ArgumentParser(
        description="AI Marketplace model runtime entrypoint"
    )
    parser.add_argument(
        "--module",
        dest="module_path",
        default=os.environ.get("MODEL_ENTRYPOINT"),
        help="Path to the model module (defaults to MODEL_ENTRYPOINT env var).",
    )

    args = parser.parse_args()
    if not args.module_path:
        print(
            json.dumps(
                {
                    "error": "Missing model module path. Set MODEL_ENTRYPOINT or pass --module.",
                }
            )
        )
        sys.exit(1)

    execute_from_env(args.module_path)


if __name__ == "__main__":
    main()
