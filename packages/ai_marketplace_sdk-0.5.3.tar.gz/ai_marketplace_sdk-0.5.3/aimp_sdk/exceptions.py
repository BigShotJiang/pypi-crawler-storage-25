"""SDK exceptions for topology validation and other errors."""

from __future__ import annotations


class SDKError(Exception):
    """Base exception for SDK errors."""

    pass


class TopologyError(SDKError):
    """Base exception for topology validation errors."""

    pass
