"""Typed media reference types for mode inputs and outputs.

These types allow SDK to infer parameter kinds from type hints,
improving developer ergonomics while maintaining model-agnostic design.

Usage::

    from aimp_sdk import Model, mode, ImageRef, SearchResult

    class MyModel(Model):
        @mode("search")
        def search(self, image: ImageRef, limit: int = 10) -> SearchResult:
            pil_image = image.load()  # Returns PIL Image
            embedding = self.encode(pil_image)
            results = self.vector.search(embedding, limit=limit)
            return SearchResult(results=results)
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
from typing import BinaryIO
from typing import TYPE_CHECKING
import urllib.request
import urllib.error

if TYPE_CHECKING:
    from PIL import Image


@dataclass(frozen=True)
class MediaRef:
    """Base class for media references.

    Media references are resolved by the runtime from presigned URLs
    or local paths. They provide a type-safe way to declare input modalities.
    """

    url: str | None = None
    path: Path | None = None
    bytes_data: bytes | None = None
    media_type: str = "application/octet-stream"

    def _get_bytes(self) -> bytes:
        """Get raw bytes for this media reference."""
        if self.bytes_data is not None:
            return self.bytes_data
        if self.path is not None:
            return self.path.read_bytes()
        if self.url is not None:
            try:
                with urllib.request.urlopen(self.url, timeout=60) as response:
                    return response.read()
            except urllib.error.URLError as exc:
                raise MediaLoadError(f"Failed to load media from URL: {exc}") from exc
        raise MediaLoadError("MediaRef has no url, path, or bytes_data")

    def _get_file_like(self) -> BinaryIO:
        """Get a file-like object for this media reference."""
        import io

        return io.BytesIO(self._get_bytes())

    def load_bytes(self) -> bytes:
        """Load the media as raw bytes.

        Returns:
            Raw media bytes.

        Raises:
            MediaLoadError: If the media cannot be loaded.
        """
        return self._get_bytes()


@dataclass(frozen=True)
class ImageRef(MediaRef):
    """Reference to an image input.

    The image can be provided as:
    - A URL (presigned URL from media upload)
    - A local file path
    - Raw bytes

    Use ``.load()`` to get a PIL Image, or ``.load_bytes()`` for raw data.
    """

    media_type: str = "image/*"

    def load(self) -> Image.Image:
        """Load the image as a PIL Image.

        Returns:
            PIL Image object ready for processing.

        Raises:
            MediaLoadError: If the image cannot be loaded.
        """
        try:
            from PIL import Image
        except ImportError as exc:
            raise MediaLoadError(
                "PIL is required to load images. Install with: pip install pillow"
            ) from exc

        try:
            return Image.open(self._get_file_like()).convert("RGB")
        except Exception as exc:
            raise MediaLoadError(f"Failed to load image: {exc}") from exc

    def load_bytes(self) -> bytes:
        """Load the image as raw bytes.

        Returns:
            Raw image bytes.

        Raises:
            MediaLoadError: If the image cannot be loaded.
        """
        return self._get_bytes()


@dataclass(frozen=True)
class AudioRef(MediaRef):
    """Reference to an audio input.

    Use ``.load()`` to get raw audio bytes, or use with your preferred
    audio library (soundfile, librosa, etc.).
    """

    media_type: str = "audio/*"

    def load(self) -> bytes:
        """Load the audio as raw bytes.

        Returns:
            Raw audio bytes.

        Raises:
            MediaLoadError: If the audio cannot be loaded.
        """
        return self._get_bytes()

    def load_bytes(self) -> bytes:
        """Load the audio as raw bytes (alias for load()).

        Returns:
            Raw audio bytes.
        """
        return self._get_bytes()


@dataclass(frozen=True)
class VideoRef(MediaRef):
    """Reference to a video input.

    Use ``.load()`` to get raw video bytes, or use with your preferred
    video library (opencv, ffmpeg, etc.).
    """

    media_type: str = "video/*"

    def load(self) -> bytes:
        """Load the video as raw bytes.

        Returns:
            Raw video bytes.

        Raises:
            MediaLoadError: If the video cannot be loaded.
        """
        return self._get_bytes()

    def load_bytes(self) -> bytes:
        """Load the video as raw bytes (alias for load()).

        Returns:
            Raw video bytes.
        """
        return self._get_bytes()


@dataclass(frozen=True)
class FileRef(MediaRef):
    """Reference to a generic file input.

    Use for arbitrary binary files that don't fit other categories.
    """

    media_type: str = "application/octet-stream"

    def load(self) -> bytes:
        """Load the file as raw bytes.

        Returns:
            Raw file bytes.

        Raises:
            MediaLoadError: If the file cannot be loaded.
        """
        return self._get_bytes()

    def load_bytes(self) -> bytes:
        """Load the file as raw bytes (alias for load()).

        Returns:
            Raw file bytes.
        """
        return self._get_bytes()


@dataclass(frozen=True)
class TextRef(MediaRef):
    """Reference to a text input.

    Text can be provided as:
    - A URL to a text file
    - A local file path
    - Raw bytes (will be decoded as UTF-8)

    For simple text inputs, use ``str`` type directly instead of TextRef.
    """

    media_type: str = "text/plain"

    def load(self) -> str:
        """Load and decode the text.

        Returns:
            Decoded text string.

        Raises:
            MediaLoadError: If the text cannot be loaded or decoded.
        """
        try:
            return self._get_bytes().decode("utf-8")
        except UnicodeDecodeError as exc:
            raise MediaLoadError(f"Failed to decode text as UTF-8: {exc}") from exc

    def load_bytes(self) -> bytes:
        """Load the text as raw bytes.

        Returns:
            Raw text bytes.
        """
        return self._get_bytes()


@dataclass(frozen=True)
class JsonRef(MediaRef):
    """Reference to a JSON input.

    JSON can be provided as:
    - A URL to a JSON file
    - A local file path
    - Raw bytes (will be parsed as JSON)

    For structured JSON input, prefer using ``dict`` or
    ``Annotated[dict, Input(...)]`` in your mode signature.
    This type is for JSON files that need to be loaded.
    """

    media_type: str = "application/json"

    def load(self) -> Any:
        """Load and parse the JSON.

        Returns:
            Parsed JSON value (dict, list, or primitive).

        Raises:
            MediaLoadError: If the JSON cannot be loaded or parsed.
        """
        import json

        try:
            return json.loads(self._get_bytes().decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise MediaLoadError(f"Failed to parse JSON: {exc}") from exc

    def load_bytes(self) -> bytes:
        """Load the JSON as raw bytes.

        Returns:
            Raw JSON bytes.
        """
        return self._get_bytes()


class MediaLoadError(RuntimeError):
    """Raised when a media reference cannot be loaded."""


# ---------------------------------------------------------------------------
# Output types for structured responses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SearchResult:
    """Structured search result for vector-enabled modes.

    Usage::

        @mode("search")
        def search(self, image: ImageRef, limit: int = 10) -> SearchResult:
            embedding = self.encode(image.load())
            results = self.vector.search(embedding, limit=limit)
            return SearchResult(results=[
                {"id": r.id, "score": r.score, "metadata": r.payload}
                for r in results
            ])
    """

    results: list[dict[str, Any]]
    total: int | None = None

    def __post_init__(self) -> None:
        if self.total is None:
            object.__setattr__(self, "total", len(self.results))


@dataclass(frozen=True)
class IndexResult:
    """Structured index result for vector-enabled modes.

    Usage::

        @mode("index")
        def index(self, image: ImageRef, metadata: dict | None = None) -> IndexResult:
            embedding = self.encode(image.load())
            vector_id = self.vector.add(embedding, metadata=metadata)
            return IndexResult(vector_id=vector_id)
    """

    vector_id: str
    indexed: bool = True


# ---------------------------------------------------------------------------
# Type hint to kind mapping
# ---------------------------------------------------------------------------

TYPE_KIND_MAP: dict[type, str] = {
    ImageRef: "image",
    AudioRef: "audio",
    VideoRef: "video",
    FileRef: "file",
    TextRef: "text",
    JsonRef: "json",
    dict: "json",
    str: "text",
    int: "integer",
    float: "number",
    bool: "boolean",
}


def get_kind_for_type(hint: type) -> str:
    """Get the parameter kind for a type hint.

    Args:
        hint: A type hint (e.g., ImageRef, str, int).

    Returns:
        The corresponding parameter kind string.

    Raises:
        ValueError: If the type is not recognized.
    """
    if hint in TYPE_KIND_MAP:
        return TYPE_KIND_MAP[hint]

    origin = getattr(hint, "__origin__", None)
    if origin is not None:
        args = getattr(hint, "__args__", ())
        if args:
            return get_kind_for_type(args[0])
        return "text"

    if hasattr(hint, "__name__"):
        hint_name = hint.__name__.lower()
        if hint_name in ("str", "string"):
            return "text"
        if hint_name in ("int", "integer"):
            return "integer"
        if hint_name in ("float", "number"):
            return "number"
        if hint_name in ("bool", "boolean"):
            return "boolean"

    return "text"
