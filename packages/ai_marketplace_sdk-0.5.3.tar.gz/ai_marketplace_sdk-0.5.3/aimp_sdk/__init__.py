"""AI Marketplace Python SDK."""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any

from .components import Component
from .decorators import (
    ModeArgSpec,
    boolean,
    file,
    image,
    integer,
    json,
    number,
    select,
    text,
    text_param,
    video,
    audio,
)
from .exceptions import (
    SDKError,
    TopologyError,
)

from .agent_loader import (
    load_agent_class,
    load_agent_contract,
    load_agent_vector_contract,
)
from .loader import execute_from_env, load_contract, load_model_class
from .media_types import (
    AudioRef,
    FileRef,
    ImageRef,
    JsonRef,
    MediaLoadError,
    MediaRef,
    SearchResult,
    IndexResult,
    TextRef,
    VideoRef,
    TYPE_KIND_MAP,
    get_kind_for_type,
)
from .model import Model
from .model import Model as ModelBase
from .mode import ModeError, mode
from .runtime import (
    AcceleratorInfo,
    ExecutionLimits,
    ProcessContext,
    RuntimeContext,
    VectorExecutionContext,
)
from .settings import Settings, VectorRef
from .vector_store import (
    BooleanField,
    FloatField,
    IntegerField,
    JsonField,
    Metric,
    StringField,
    TextField,
    Vector,
    VectorKnowledge,
    Hit,
)
from .tuning import (
    AudioField,
    FileField,
    FineTuneSchema,
    ImageField,
    TuneResult,
    TuningDatasetView,
    TuningContext,
    TuningParams,
    TuningSession,
    JsonField as TuningJsonField,
    TextField as TuningTextField,
    VideoField,
    load_model_tuning_contract,
    load_tuning_schema_class,
    load_tuning_schema_contract,
)
from .vector import (
    JsonPrimitive,
    JsonValue,
    VectorClient,
    VectorClientError,
    VectorSearchResult,
)

if TYPE_CHECKING:
    from .client import Client, FineTuneJob
    from .tuning_data import (
        LoadedTuningBundle,
        TuningBundleError,
        TuningBundlePayload,
        build_tuning_dataset_bundle,
        load_tuning_dataset_bundle,
    )

_LAZY_EXPORTS = {
    "Client": (".client", "Client"),
    "FineTuneJob": (".client", "FineTuneJob"),
    "LoadedTuningBundle": (".tuning_data", "LoadedTuningBundle"),
    "TuningBundleError": (".tuning_data", "TuningBundleError"),
    "TuningBundlePayload": (".tuning_data", "TuningBundlePayload"),
    "build_tuning_dataset_bundle": (".tuning_data", "build_tuning_dataset_bundle"),
    "load_tuning_dataset_bundle": (".tuning_data", "load_tuning_dataset_bundle"),
    # Playground DSL
    "PlaygroundSpec": (".playground", "PlaygroundSpec"),
    "PlaygroundInputs": (".playground", "PlaygroundInputs"),
    "Computed": (".playground", "Computed"),
    "image_id_from": (".playground", "image_id_from"),
    "ViewBase": (".playground", "ViewBase"),
    "Image": (".playground", "Image"),
    "Cards": (".playground", "Cards"),
    "Markdown": (".playground", "Markdown"),
    "Text": (".playground", "Text"),
    "Table": (".playground", "Table"),
    "Status": (".playground", "Status"),
}


def __getattr__(name: str) -> Any:
    """Load optional SDK exports lazily to keep lightweight flows dependency-free."""
    target = _LAZY_EXPORTS.get(name)
    if target is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module_name, attribute_name = target
    module = importlib.import_module(module_name, __name__)
    value = getattr(module, attribute_name)
    globals()[name] = value
    return value


__all__ = [
    # Exceptions
    "SDKError",
    "TopologyError",
    # Core classes
    "Model",
    "ModelBase",
    "mode",
    "Component",
    "Settings",
    "Metric",
    "Vector",
    "VectorRef",
    "VectorKnowledge",
    "StringField",
    "IntegerField",
    "FloatField",
    "BooleanField",
    "JsonField",
    "TextField",
    "Hit",
    "text",
    "image",
    "audio",
    "video",
    "file",
    "json",
    "text_param",
    "integer",
    "number",
    "boolean",
    "select",
    "ModeArgSpec",
    "ModeError",
    "MediaRef",
    "ImageRef",
    "AudioRef",
    "VideoRef",
    "FileRef",
    "TextRef",
    "JsonRef",
    "MediaLoadError",
    "SearchResult",
    "IndexResult",
    "TYPE_KIND_MAP",
    "get_kind_for_type",
    "AcceleratorInfo",
    "ExecutionLimits",
    "ProcessContext",
    "RuntimeContext",
    "VectorExecutionContext",
    "VectorClient",
    "VectorClientError",
    "VectorSearchResult",
    "JsonPrimitive",
    "JsonValue",
    "AudioField",
    "FileField",
    "FineTuneSchema",
    "ImageField",
    "TuneResult",
    "TuningDatasetView",
    "TuningContext",
    "TuningParams",
    "TuningSession",
    "TuningTextField",
    "TuningJsonField",
    "VideoField",
    "load_model_tuning_contract",
    "load_tuning_schema_class",
    "load_tuning_schema_contract",
    "execute_from_env",
    "load_contract",
    "load_agent_contract",
    "load_agent_vector_contract",
    "load_model_class",
    "load_agent_class",
    "Client",
    "FineTuneJob",
    "LoadedTuningBundle",
    "TuningBundleError",
    "TuningBundlePayload",
    "build_tuning_dataset_bundle",
    "load_tuning_dataset_bundle",
    # Playground DSL
    "PlaygroundSpec",
    "PlaygroundInputs",
    "Computed",
    "image_id_from",
    "ViewBase",
    "Image",
    "Cards",
    "Markdown",
    "Text",
    "Table",
    "Status",
]
