"""Fine-tune dataset bundle helpers built on top of Hugging Face datasets."""

from __future__ import annotations

from contextlib import redirect_stderr
from contextlib import redirect_stdout
from dataclasses import dataclass
from pathlib import Path
from tempfile import SpooledTemporaryFile
from tempfile import TemporaryDirectory
from typing import TYPE_CHECKING, Any, BinaryIO
import hashlib
import io
import json
import shutil
import zipfile

from datasets import Dataset

if TYPE_CHECKING:
    from .tuning import FineTuneSchema, TuningField


class TuningBundleError(RuntimeError):
    """Raised when a fine-tune bundle is invalid."""


@dataclass
class TuningBundlePayload:
    """Serialized fine-tune dataset bundle ready for upload."""

    stream: BinaryIO
    size_bytes: int
    sha256: str
    file_name: str
    content_type: str


@dataclass
class LoadedTuningBundle:
    """Extracted fine-tune dataset bundle."""

    dataset: Dataset
    root_dir: Path
    manifest: dict[str, Any]
    _temporary_directory: TemporaryDirectory[str]

    def cleanup(self) -> None:
        """Release extracted bundle resources."""
        self._temporary_directory.cleanup()

    def resolve_path(self, relative_path: str) -> Path:
        """Resolve one stored relative path to an extracted absolute path."""
        return self.root_dir / relative_path


def _compute_stream_sha256(stream: BinaryIO) -> str:
    sha256 = hashlib.sha256()
    stream.seek(0)
    while True:
        chunk = stream.read(1024 * 1024)
        if not chunk:
            break
        sha256.update(chunk)
    stream.seek(0)
    return sha256.hexdigest()


def _compute_schema_fingerprint(schema_contract: dict[str, Any]) -> str:
    canonical = json.dumps(
        schema_contract, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _read_bundle_source(bundle_path: Path) -> list[dict[str, Any]]:
    try:
        parsed = json.loads(bundle_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise TuningBundleError(f"Invalid JSON bundle: {exc}") from exc

    records = parsed.get("records") if isinstance(parsed, dict) else parsed
    if not isinstance(records, list) or not records:
        raise TuningBundleError(
            "Fine-tune bundle must contain a non-empty records array"
        )
    normalized: list[dict[str, Any]] = []
    for index, item in enumerate(records):
        if not isinstance(item, dict):
            raise TuningBundleError(f"Record {index} must be a JSON object")
        normalized.append(item)
    return normalized


def _validate_record_keys(
    *,
    schema_contract: dict[str, Any],
    record: dict[str, Any],
    index: int,
) -> dict[str, dict[str, Any]]:
    fields = schema_contract.get("fields")
    if not isinstance(fields, list) or not fields:
        raise TuningBundleError("Schema contract is missing fine-tune fields")

    field_map: dict[str, dict[str, Any]] = {}
    for field in fields:
        if not isinstance(field, dict):
            raise TuningBundleError("Schema fields must be objects")
        key = str(field.get("key") or "").strip()
        if not key:
            raise TuningBundleError("Schema field key must be non-empty")
        field_map[key] = field

    unknown = sorted(key for key in record.keys() if key not in field_map)
    if unknown:
        raise TuningBundleError(
            f"Record {index} contains unknown fine-tune fields: {', '.join(unknown)}"
        )
    return field_map


def _normalize_json_value(value: Any) -> str:
    try:
        return json.dumps(value, sort_keys=True)
    except TypeError as exc:
        raise TuningBundleError(f"JSON field is not serializable: {exc}") from exc


def _load_field_hooks(
    schema_cls: type["FineTuneSchema"] | None,
) -> dict[str, "TuningField"]:
    if schema_cls is None:
        return {}
    from .tuning import TuningField

    hooks: dict[str, TuningField] = {}
    for key, value in schema_cls.__dict__.items():
        if isinstance(value, TuningField):
            hooks[key] = value
    return hooks


def _validate_field_value_type(
    *,
    record_index: int,
    field_key: str,
    field_type: str,
    value: Any,
    item_index: int,
) -> None:
    context = f"Record {record_index} field '{field_key}' item {item_index}"
    if field_type in {"image", "audio", "video", "file"}:
        if not isinstance(value, str) or not value.strip():
            raise TuningBundleError(f"{context} must be a file path")
        return
    if field_type == "text":
        if not isinstance(value, str):
            raise TuningBundleError(f"{context} must be text")
        return
    if field_type == "json":
        return
    raise TuningBundleError(
        f"Unsupported fine-tune field type '{field_type}' for {field_key}"
    )


def _apply_field_hooks(
    *,
    hook_field: "TuningField" | None,
    field_type: str,
    record_index: int,
    field_key: str,
    item_index: int,
    value: Any,
) -> Any:
    processed = value
    _validate_field_value_type(
        record_index=record_index,
        field_key=field_key,
        field_type=field_type,
        value=processed,
        item_index=item_index,
    )
    if hook_field is not None:
        try:
            processed = hook_field.preprocess_value(processed)
        except (TypeError, ValueError) as exc:
            raise TuningBundleError(
                f"Record {record_index} field '{field_key}' item {item_index} "
                f"preprocessing failed: {exc}"
            ) from exc
    _validate_field_value_type(
        record_index=record_index,
        field_key=field_key,
        field_type=field_type,
        value=processed,
        item_index=item_index,
    )
    if hook_field is not None:
        try:
            hook_field.validate_value(processed)
        except (TypeError, ValueError) as exc:
            raise TuningBundleError(
                f"Record {record_index} field '{field_key}' item {item_index} "
                f"validation failed: {exc}"
            ) from exc
    return processed


def _copy_binary_file(
    *,
    zip_file: zipfile.ZipFile,
    source_path: Path,
    record_index: int,
    field_key: str,
    item_index: int,
) -> str:
    destination = (
        f"files/{record_index:05d}/{field_key}/{item_index:03d}_{source_path.name}"
    )
    with source_path.open("rb") as handle:
        zip_file.writestr(destination, handle.read())
    return destination


def build_tuning_dataset_bundle(
    *,
    schema_contract: dict[str, Any],
    bundle_path: str | Path,
    schema_cls: type["FineTuneSchema"] | None = None,
) -> TuningBundlePayload:
    """Validate a local JSON bundle and serialize it into a zipped dataset artifact."""
    source_path = Path(bundle_path).expanduser().resolve()
    if not source_path.exists() or not source_path.is_file():
        raise TuningBundleError(f"Bundle file not found: {bundle_path}")

    records = _read_bundle_source(source_path)
    base_dir = source_path.parent
    canonical_records: list[dict[str, Any]] = []
    field_hooks = _load_field_hooks(schema_cls)

    zip_stream = SpooledTemporaryFile(max_size=50 * 1024 * 1024)
    with zipfile.ZipFile(zip_stream, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for record_index, record in enumerate(records):
            field_map = _validate_record_keys(
                schema_contract=schema_contract,
                record=record,
                index=record_index,
            )
            canonical_record: dict[str, Any] = {}
            for field_key, field in field_map.items():
                required = bool(field.get("required", True))
                multiple = bool(field.get("multiple", False))
                field_type = str(field.get("type") or "").strip()
                raw_value = record.get(field_key)

                if raw_value in (None, ""):
                    if required:
                        raise TuningBundleError(
                            f"Record {record_index} is missing required field: {field_key}"
                        )
                    canonical_record[field_key] = [] if multiple else None
                    continue

                values = raw_value if multiple else [raw_value]
                if multiple and not isinstance(values, list):
                    raise TuningBundleError(
                        f"Record {record_index} field '{field_key}' must be an array"
                    )

                normalized_values: list[Any] = []
                for item_index, value in enumerate(values):
                    processed_value = _apply_field_hooks(
                        hook_field=field_hooks.get(field_key),
                        field_type=field_type,
                        record_index=record_index,
                        field_key=field_key,
                        item_index=item_index,
                        value=value,
                    )
                    if field_type in {"image", "audio", "video", "file"}:
                        file_path = (base_dir / str(processed_value)).resolve()
                        if not file_path.exists() or not file_path.is_file():
                            raise TuningBundleError(
                                f"Record {record_index} field '{field_key}' "
                                f"item {item_index} file not found: {processed_value}"
                            )
                        relative_path = _copy_binary_file(
                            zip_file=zf,
                            source_path=file_path,
                            record_index=record_index,
                            field_key=field_key,
                            item_index=item_index,
                        )
                        normalized_values.append(relative_path)
                    elif field_type == "text":
                        normalized_values.append(processed_value)
                    elif field_type == "json":
                        normalized_values.append(_normalize_json_value(processed_value))

                canonical_record[field_key] = (
                    normalized_values if multiple else normalized_values[0]
                )
            canonical_records.append(canonical_record)

        dataset = Dataset.from_list(canonical_records)
        parquet_buffer = SpooledTemporaryFile(max_size=50 * 1024 * 1024)
        with io.StringIO() as sink, redirect_stdout(sink), redirect_stderr(sink):
            dataset.to_parquet(parquet_buffer)
        parquet_buffer.seek(0)
        with zf.open("data.parquet", "w") as zipped_file:
            shutil.copyfileobj(parquet_buffer, zipped_file)

        manifest = {
            "format_version": 1,
            "dataset_format": "aimp_tuning_bundle_v1",
            "schema": schema_contract,
            "schema_fingerprint": _compute_schema_fingerprint(schema_contract),
            "record_count": len(canonical_records),
        }
        zf.writestr("manifest.json", json.dumps(manifest, sort_keys=True))

    zip_stream.seek(0, io.SEEK_END)
    size_bytes = zip_stream.tell()
    zip_stream.seek(0)
    sha256 = _compute_stream_sha256(zip_stream)

    return TuningBundlePayload(
        stream=zip_stream,
        size_bytes=size_bytes,
        sha256=sha256,
        file_name="fine_tune_bundle.zip",
        content_type="application/zip",
    )


def load_tuning_dataset_bundle(bundle_path: str | Path) -> LoadedTuningBundle:
    """Load a serialized fine-tune dataset bundle from disk."""
    source_path = Path(bundle_path).expanduser().resolve()
    if not source_path.exists() or not source_path.is_file():
        raise TuningBundleError(f"Fine-tune dataset bundle not found: {bundle_path}")

    temp_dir = TemporaryDirectory()
    root_dir = Path(temp_dir.name)
    with zipfile.ZipFile(source_path) as zf:
        zf.extractall(root_dir)
        try:
            manifest = json.loads(
                (root_dir / "manifest.json").read_text(encoding="utf-8")
            )
        except FileNotFoundError as exc:
            temp_dir.cleanup()
            raise TuningBundleError(
                "Fine-tune dataset bundle is missing manifest.json"
            ) from exc
        dataset_path = root_dir / "data.parquet"
        if not dataset_path.exists():
            temp_dir.cleanup()
            raise TuningBundleError("Fine-tune dataset bundle is missing data.parquet")
        dataset = Dataset.from_parquet(str(dataset_path))

    return LoadedTuningBundle(
        dataset=dataset,
        root_dir=root_dir,
        manifest=manifest,
        _temporary_directory=temp_dir,
    )
