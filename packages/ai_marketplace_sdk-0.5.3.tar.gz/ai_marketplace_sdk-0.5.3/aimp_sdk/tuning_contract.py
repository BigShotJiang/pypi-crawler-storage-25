"""CLI helper to output model-scoped fine-tune contract as JSON."""

from __future__ import annotations

import argparse
import json
import sys

from .tuning import load_model_tuning_contract


def main() -> None:
    """Load model-scoped tuning contract from agent module and print JSON."""
    parser = argparse.ArgumentParser(
        description="Export model-scoped fine-tune contract as JSON"
    )
    parser.add_argument(
        "--module",
        dest="module_path",
        required=True,
        help="Path to the agent module file (e.g., /app/agent.py).",
    )
    parser.add_argument(
        "--model-key",
        dest="model_key",
        required=True,
        help="Model key selector (e.g., vision_model).",
    )
    args = parser.parse_args()

    try:
        contract = load_model_tuning_contract(
            args.module_path, model_key=args.model_key
        )
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"error": str(exc)}))
        sys.exit(1)

    print(json.dumps(contract))


if __name__ == "__main__":
    main()
