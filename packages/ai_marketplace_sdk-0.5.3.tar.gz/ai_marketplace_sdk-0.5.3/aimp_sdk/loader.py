"""Model loading utilities for the SDK."""

from __future__ import annotations

from contextlib import contextmanager
from importlib import import_module
from importlib import util
import json
import os
import sys
from types import ModuleType
from typing import Any, TypedDict

from .model import Model
from .runtime import ProcessContext, RuntimeContext
from .runtime import process_context_from_env, runtime_context_from_env


class ModeImplementationStatus(TypedDict):
    """Verification result for a public model mode."""

    implemented: bool
    reason: str | None


def _purge_foreign_package_modules(package_name: str, anchor_file: str) -> None:
    """Keep only the current package lineage in ``sys.modules``."""
    current_package_dir = os.path.dirname(os.path.abspath(anchor_file))
    current_prefix = f"{current_package_dir}{os.sep}"
    for module_name, module in list(sys.modules.items()):
        if module_name != package_name and not module_name.startswith(f"{package_name}."):
            continue
        module_file = getattr(module, "__file__", None)
        if isinstance(module_file, str):
            normalized_file = os.path.abspath(module_file)
            if normalized_file == current_package_dir or normalized_file.startswith(
                current_prefix
            ):
                continue
        module_paths = getattr(module, "__path__", None)
        if module_paths is not None:
            keep_module = False
            for entry in module_paths:
                normalized_entry = os.path.abspath(str(entry))
                if normalized_entry == current_package_dir or normalized_entry.startswith(
                    current_prefix
                ):
                    keep_module = True
                    break
            if keep_module:
                continue
        sys.modules.pop(module_name, None)


def _purge_runtime_package_lineages() -> None:
    """Normalize SDK and framework module lineages before loading user code."""
    _purge_foreign_package_modules("aimp_sdk", __file__)
    framework_base = import_module("aimp_framework.base")
    framework_anchor = getattr(framework_base, "__file__", None)
    if not isinstance(framework_anchor, str) or not framework_anchor:
        raise ImportError("Failed to resolve active aimp_framework.base module path.")
    _purge_foreign_package_modules("aimp_framework", framework_anchor)


def _purge_modules_for_path(module_dir: str) -> None:
    """Remove cached modules loaded from one project directory.

    This prevents stale `agent.*` modules from a previous project import from leaking
    into the current module load.
    """
    normalized_dir = os.path.abspath(module_dir)
    prefix = f"{normalized_dir}{os.sep}"
    local_roots: set[str] = set()
    try:
        for entry in os.listdir(normalized_dir):
            entry_path = os.path.join(normalized_dir, entry)
            if os.path.isdir(entry_path) and os.path.isfile(
                os.path.join(entry_path, "__init__.py")
            ):
                local_roots.add(entry)
                continue
            if os.path.isfile(entry_path) and entry.endswith(".py"):
                local_roots.add(entry[:-3])
    except FileNotFoundError:
        local_roots = set()

    for module_name, module in list(sys.modules.items()):
        if (
            module_name == "aimp_user_model"
            or module_name.startswith("aimp_user_model.")
            or module_name == "agent"
            or module_name.startswith("agent.")
        ):
            sys.modules.pop(module_name, None)
            continue
        module_file = getattr(module, "__file__", None)
        if isinstance(module_file, str):
            normalized_file = os.path.abspath(module_file)
            if normalized_file == normalized_dir or normalized_file.startswith(prefix):
                sys.modules.pop(module_name, None)
                continue
        root_name = module_name.split(".", 1)[0]
        if root_name in local_roots:
            sys.modules.pop(module_name, None)
            continue
        module_paths = getattr(module, "__path__", None)
        if module_paths is None:
            continue
        for entry in module_paths:
            normalized_entry = os.path.abspath(str(entry))
            if normalized_entry == normalized_dir or normalized_entry.startswith(
                prefix
            ):
                sys.modules.pop(module_name, None)
                break


@contextmanager
def bind_main_module(module: ModuleType):
    """Temporarily expose the loaded user module as ``__main__`` during exec.

    Some third-party libraries imported at module load time expect
    ``sys.modules["__main__"]`` to resolve to the actively executing user module.
    """
    previous_main = sys.modules.get("__main__")
    sys.modules["__main__"] = module
    try:
        yield
    finally:
        if previous_main is None:
            sys.modules.pop("__main__", None)
        else:
            sys.modules["__main__"] = previous_main


def _find_model_subclasses(module: Any) -> list[type[Model]]:
    """Find Model subclasses defined in a module."""
    subclasses: list[type[Model]] = []
    for value in vars(module).values():
        if (
            isinstance(value, type)
            and _is_model_subclass(value)
            and getattr(value, "__module__", None) == module.__name__
        ):
            subclasses.append(value)
    return subclasses


def _is_model_subclass(value: type[Any]) -> bool:
    """Return True when a class derives from any ``aimp_sdk.model.Model`` lineage."""
    for base in value.__mro__[1:]:
        if base.__name__ != "Model":
            continue
        if base.__module__.endswith("aimp_sdk.model"):
            return True
    return False


def _load_user_module(module_path: str) -> ModuleType:
    """Load one user-authored module through a single deterministic import path."""
    if not module_path or not os.path.exists(module_path):
        msg = f"Model module not found: {module_path}"
        raise FileNotFoundError(msg)

    spec = util.spec_from_file_location(
        "aimp_user_model",
        module_path,
        submodule_search_locations=[os.path.dirname(os.path.abspath(module_path))],
    )
    if spec is None or spec.loader is None:
        msg = f"Failed to load module spec: {module_path}"
        raise ImportError(msg)

    module = util.module_from_spec(spec)
    module_dir = os.path.dirname(os.path.abspath(module_path))
    _purge_modules_for_path(module_dir)
    _purge_runtime_package_lineages()
    sys.modules["aimp_user_model"] = module
    parent_dir = os.path.dirname(module_dir)
    sdk_parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, sdk_parent_dir)
    sys.path.insert(1, module_dir)
    sys.path.insert(2, parent_dir)
    try:
        with bind_main_module(module):
            spec.loader.exec_module(module)
    finally:
        sys.path.remove(module_dir)
        sys.path.remove(parent_dir)
        sys.path.remove(sdk_parent_dir)
    return module


def load_model_class(module_path: str) -> type[Model]:
    """Load a Model subclass from a Python module path.

    Args:
        module_path: Filesystem path to the module (e.g., "/workspace/agent.py").

    Returns:
        Single Model subclass defined in the module.

    Raises:
        FileNotFoundError: If module_path does not exist.
        ImportError: If module cannot be imported.
        ValueError: If no Model subclass is found or multiple are found.
    """
    module = _load_user_module(module_path)

    subclasses = _find_model_subclasses(module)
    if not subclasses:
        msg = "No Model subclass found in module"
        raise ValueError(msg)
    if len(subclasses) > 1:
        names = ", ".join(sorted(cls.__name__ for cls in subclasses))
        msg = f"Multiple Model subclasses found: {names}"
        raise ValueError(msg)

    return subclasses[0]


def load_contract(module_path: str) -> dict[str, Any]:
    """Load an agent contract from a module path.

    Args:
        module_path: Filesystem path to the module.

    Returns:
        Contract dictionary with modes and parameters.
    """
    from .agent_loader import load_agent_contract

    return load_agent_contract(module_path)


def load_mode_implementations(
    module_path: str,
) -> dict[str, ModeImplementationStatus]:
    """Return SDK-level implementation verification for model actions.

    Args:
        module_path: Filesystem path to the model module.

    Returns:
        Mapping of mode name to implementation verification status.
    """
    from .agent_loader import (
        load_mode_implementations as load_agent_mode_implementations,
    )

    return load_agent_mode_implementations(module_path)


def load_runtime_context(mode: str) -> RuntimeContext:
    """Build runtime context for the current execution."""
    return runtime_context_from_env(mode)


def load_process_context() -> ProcessContext:
    """Build process-local context for model setup/teardown."""
    return process_context_from_env()


def execute_from_env(module_path: str) -> None:
    """Execute the model using environment-provided input and parameters.

    This is intended to be called by the container entrypoint.

    Args:
        module_path: Filesystem path to the model module.
    """
    input_path = os.environ.get("MODEL_INPUT_PATH", "").strip()
    if input_path:
        try:
            with open(input_path, "r", encoding="utf-8") as handle:
                input_json = handle.read()
        except FileNotFoundError as exc:
            _print_error(f"MODEL_INPUT_PATH not found: {input_path}")
            raise SystemExit(1) from exc
        except OSError as exc:
            _print_error(f"Failed to read MODEL_INPUT_PATH: {exc}")
            raise SystemExit(1) from exc
    else:
        input_json = os.environ.get("MODEL_INPUT", "{}")
    parameters_json = os.environ.get("MODEL_PARAMETERS", "{}")
    mode = os.environ.get("MODEL_MODE", "").strip()

    try:
        input_data = json.loads(input_json)
    except json.JSONDecodeError as exc:
        _print_error(f"Invalid JSON in MODEL_INPUT: {exc}")
        raise SystemExit(1) from exc
    try:
        parameters = json.loads(parameters_json)
    except json.JSONDecodeError as exc:
        _print_error(f"Invalid JSON in MODEL_PARAMETERS: {exc}")
        raise SystemExit(1) from exc
    if parameters is None:
        parameters = {}
    if not isinstance(parameters, dict):
        _print_error("MODEL_PARAMETERS must be a JSON object")
        raise SystemExit(1)

    process_context = load_process_context()
    load_runtime_context(mode)
    model_cls = load_model_class(module_path)
    model = model_cls()

    setup_completed = False
    try:
        model.setup(process_context)
        setup_completed = True
        result = model.dispatch(mode, input_data, parameters)
    except Exception as exc:  # noqa: BLE001
        _print_error(str(exc))
        raise SystemExit(1) from exc
    finally:
        if setup_completed:
            try:
                model.teardown(process_context)
            except Exception as exc:  # noqa: BLE001
                _print_error(str(exc))
                raise SystemExit(1) from exc

    print(json.dumps(result))


def _print_error(message: str) -> None:
    """Print a standardized JSON error to stdout."""
    print(json.dumps({"error": message}))
