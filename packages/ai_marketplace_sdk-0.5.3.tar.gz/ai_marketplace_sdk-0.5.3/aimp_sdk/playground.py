"""Playground DSL — declarative view specs for the Playground UI.

Design rules
------------
- ``PlaygroundSpec`` is declared per-mode in ``playground.py``.
- Each spec is referenced from its mode via the ``playground`` kwarg on ``@mode``.
- ``PlaygroundSpec.validate_against_mode`` is called at mode-definition time,
  not at execution time.
- Only top-level output field references are validated against the mode schema.
- Item-level keys inside list/JSON fields are declared as plain strings; they
  cannot be statically validated because ``ListField`` / ``JsonField`` are
  opaque to the playground layer.
- Execution responses never include playground metadata.
- The platform (frontend) controls all visual styling — colour, spacing,
  animation.  The DSL only declares *what* to show, never *how* it looks.

Usage example (playground.py)::

    from aimp_sdk.playground import Cards, Image, Markdown, PlaygroundSpec, Table
    from schemas import SearchSchema, IndexSchema

    class SearchPlayground(PlaygroundSpec):
        view = Cards(
            SearchSchema.Outputs.matches,
            title="filename",
            image=Image("image_id", badges=["score"]),
            empty="No similar images found",
        )

    class IndexPlayground(PlaygroundSpec):
        view = Table(IndexSchema.Outputs.indexed, columns=["image_id", "filename"])

    class WritePlayground(PlaygroundSpec):
        view = [
            Markdown(WriteSchema.Outputs.article),
            Cards(
                WriteSchema.Outputs.sources,
                title="title",
                body="excerpt",
                metrics=["relevance"],
                badges=["category"],
                action="link",
            ),
        ]

Usage in agent.py::

    from aimp_sdk import mode
    from playground import SearchPlayground

    @mode(name="search", playground=SearchPlayground)
    async def search(...):
        ...
"""

from __future__ import annotations

from typing import Any, ClassVar


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_field_name(ref: Any, label: str) -> str:
    """Accept a framework Field instance or a plain string; return the field name.

    This lets callers write either ``Schema.Outputs.results`` (a real Field
    object) or ``"results"`` (a fallback string).  The Field-object form
    gives compile-time IDE support and AttributeError on misspelled names.
    """
    name = getattr(ref, "name", None)
    if name is not None:
        if not isinstance(name, str) or not name.strip():
            raise ValueError(
                f"{label}: Field instance has no name set. "
                "Reference a class-level Schema field "
                "(e.g. MySchema.Outputs.results), not a Field() constructor call."
            )
        return name.strip()
    if isinstance(ref, str):
        if not ref.strip():
            raise ValueError(f"{label}: field name must be a non-empty string.")
        return ref.strip()
    raise TypeError(
        f"{label}: expected a Schema Field reference or a string field name, "
        f"got {type(ref).__name__}."
    )


def _fields_dict(schema: Any) -> dict[str, Any]:
    """Return the field name → field mapping from a SDK SchemaDecl or a
    framework Schema class.  Returns an empty dict for anything else.
    """
    if schema is None:
        return {}
    # SDK SchemaDecl — has .fields: dict[str, SchemaFieldDecl]
    fields = getattr(schema, "fields", None)
    if isinstance(fields, dict):
        return fields
    # Framework Schema class — has ._fields: dict[str, Field]
    framework_fields = getattr(schema, "_fields", None)
    if isinstance(framework_fields, dict):
        return framework_fields
    return {}


def _check_output_field(name: str, outputs: Any, label: str) -> None:
    """Raise ValueError when *name* is not declared in the outputs schema."""
    fields = _fields_dict(outputs)
    if name not in fields:
        known = sorted(fields)
        raise ValueError(
            f"{label!r} references output field {name!r} which does not exist. "
            f"Known outputs: {known}"
        )


def _check_input_field(name: str, inputs: Any, label: str) -> None:
    """Raise ValueError when *name* is not declared in the inputs schema."""
    fields = _fields_dict(inputs)
    if name not in fields:
        known = sorted(fields)
        raise ValueError(
            f"{label!r} references input field {name!r} which does not exist. "
            f"Known inputs: {known}"
        )


# ---------------------------------------------------------------------------
# Image slot — composable image element for Cards
# ---------------------------------------------------------------------------


class Image:
    """Declare an image slot inside a ``Cards`` view.

    ``field`` — item-level key whose value is an image URL or vector
    image-id reference (resolved via the platform's preview cache).

    ``badges`` — ordered list of item-level keys to overlay on top of the
    image as badges.  The platform controls badge position, colour, and
    format based on each value's type.  An empty list (the default) shows
    no overlays.

    Example::

        image=Image("image_id", badges=["score", "category"])
    """

    def __init__(self, field: str, *, badges: list[str] | None = None) -> None:
        if not isinstance(field, str) or not field.strip():
            raise ValueError("Image: field must be a non-empty string.")
        if badges is not None:
            if not isinstance(badges, list):
                raise TypeError("Image: badges must be a list of strings.")
            for i, b in enumerate(badges):
                if not isinstance(b, str) or not b.strip():
                    raise ValueError(f"Image: badges[{i}] must be a non-empty string.")
        self.field = field.strip()
        self.badges: list[str] = list(badges) if badges is not None else []

    def to_contract(self) -> dict[str, Any]:
        return {"field": self.field, "badges": self.badges}


# ---------------------------------------------------------------------------
# ViewBase
# ---------------------------------------------------------------------------


class ViewBase:
    """Sealed base for all built-in Playground view presets.

    Subclasses must implement:
    - ``validate_against_outputs(outputs)``: validate top-level output field refs.
    - ``to_contract()``: return a JSON-serialisable dict for the platform contract.
    """

    _preset: ClassVar[str]

    def validate_against_outputs(self, outputs: Any) -> None:
        raise NotImplementedError

    def to_contract(self) -> dict[str, Any]:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# View presets
# ---------------------------------------------------------------------------


class Cards(ViewBase):
    """Render a list output field as a responsive grid of content cards.

    The visual layout adapts automatically based on which fields are declared:

    - ``image`` present → image-first grid cards; each badge in
      ``image.badges`` is overlaid directly on the image
    - ``image`` absent → text/citation card list; ``metrics`` rendered as
      progress bars or value labels below the title
    - ``action`` present → each card gains a clickable action button

    ``field`` — top-level output field containing the list (validated).

    ``title``, ``subtitle``, ``body`` — item-level keys for card text.

    ``image`` — an ``Image`` instance declaring the image field and its
    overlay badges.  Pass ``Image("field_name")`` or
    ``Image("field_name", badges=["score"])``.

    ``badges`` — item-level keys rendered as card-level badges (not on the
    image).  Pass a list: ``badges=["status", "category"]``.

    ``metrics`` — item-level keys rendered as numerical metrics on the card
    (e.g. price, rating, score for text-only cards).
    Pass a list: ``metrics=["price", "rating"]``.

    ``action`` — item-level key whose value is used as the card action URL.

    ``empty`` — static label shown when the list is empty.
    """

    _preset = "cards"

    def __init__(
        self,
        field: Any,
        *,
        title: str | None = None,
        subtitle: str | None = None,
        body: str | None = None,
        image: Image | None = None,
        badges: list[str] | None = None,
        metrics: list[str] | None = None,
        action: str | None = None,
        empty: str = "No results",
    ) -> None:
        if image is not None and not isinstance(image, Image):
            raise TypeError(
                f"Cards: image must be an Image instance "
                f"(e.g. Image('field_name')), got {type(image).__name__}. "
                "Pass Image('field_name') or Image('field_name', badges=['score'])."
            )
        if badges is not None:
            if not isinstance(badges, list):
                raise TypeError("Cards: badges must be a list of strings.")
            for i, b in enumerate(badges):
                if not isinstance(b, str) or not b.strip():
                    raise ValueError(f"Cards: badges[{i}] must be a non-empty string.")
        if metrics is not None:
            if not isinstance(metrics, list):
                raise TypeError("Cards: metrics must be a list of strings.")
            for i, m in enumerate(metrics):
                if not isinstance(m, str) or not m.strip():
                    raise ValueError(f"Cards: metrics[{i}] must be a non-empty string.")
        self._field_ref = field
        self.title = title
        self.subtitle = subtitle
        self.body = body
        self.image = image
        self.badges: list[str] = list(badges) if badges is not None else []
        self.metrics: list[str] = list(metrics) if metrics is not None else []
        self.action = action
        self.empty = empty

    def validate_against_outputs(self, outputs: Any) -> None:
        name = _resolve_field_name(self._field_ref, "Cards")
        _check_output_field(name, outputs, "Cards")

    def to_contract(self) -> dict[str, Any]:
        name = _resolve_field_name(self._field_ref, "Cards.to_contract")
        contract: dict[str, Any] = {
            "preset": self._preset,
            "field": name,
            "empty": self.empty,
        }
        if self.image is not None:
            contract["image"] = self.image.to_contract()
        for key in ("title", "subtitle", "body", "action"):
            val = getattr(self, key)
            if val is not None:
                contract[key] = val
        if self.badges:
            contract["badges"] = self.badges
        if self.metrics:
            contract["metrics"] = self.metrics
        return contract


class Markdown(ViewBase):
    """Render a text output field as formatted Markdown.

    ``field`` — top-level output field (validated).
    """

    _preset = "markdown"

    def __init__(self, field: Any) -> None:
        self._field_ref = field

    def validate_against_outputs(self, outputs: Any) -> None:
        name = _resolve_field_name(self._field_ref, "Markdown")
        _check_output_field(name, outputs, "Markdown")

    def to_contract(self) -> dict[str, Any]:
        name = _resolve_field_name(self._field_ref, "Markdown.to_contract")
        return {"preset": self._preset, "field": name}


class Text(ViewBase):
    """Render a text output field as plain unformatted text.

    ``field`` — top-level output field (validated).
    """

    _preset = "text"

    def __init__(self, field: Any) -> None:
        self._field_ref = field

    def validate_against_outputs(self, outputs: Any) -> None:
        name = _resolve_field_name(self._field_ref, "Text")
        _check_output_field(name, outputs, "Text")

    def to_contract(self) -> dict[str, Any]:
        name = _resolve_field_name(self._field_ref, "Text.to_contract")
        return {"preset": self._preset, "field": name}


class Table(ViewBase):
    """Render a list output field as a data table.

    ``field`` — top-level output field (validated).

    ``columns`` — optional whitelist of item-level keys to display as columns.
    When omitted the table uses the keys of the first row.
    Item-level keys are not schema-validated.
    """

    _preset = "table"

    def __init__(
        self,
        field: Any,
        *,
        columns: list[str] | None = None,
    ) -> None:
        self._field_ref = field
        self.columns = list(columns) if columns is not None else None

    def validate_against_outputs(self, outputs: Any) -> None:
        name = _resolve_field_name(self._field_ref, "Table")
        _check_output_field(name, outputs, "Table")

    def to_contract(self) -> dict[str, Any]:
        name = _resolve_field_name(self._field_ref, "Table.to_contract")
        contract: dict[str, Any] = {"preset": self._preset, "field": name}
        if self.columns:
            contract["columns"] = self.columns
        return contract


class Status(ViewBase):
    """Render a single JSON output field as an operation status summary.

    Suitable for index / write / delete modes where the output is one
    structured result object rather than a list.  The frontend displays
    a large status icon (✓ / ✗ / ⟳) derived from any ``status`` key
    in the object, then lists all key-value pairs below it.

    ``field`` — top-level output field (validated).
    """

    _preset = "status"

    def __init__(self, field: Any) -> None:
        self._field_ref = field

    def validate_against_outputs(self, outputs: Any) -> None:
        name = _resolve_field_name(self._field_ref, "Status")
        _check_output_field(name, outputs, "Status")

    def to_contract(self) -> dict[str, Any]:
        name = _resolve_field_name(self._field_ref, "Status.to_contract")
        return {"preset": self._preset, "field": name}


# ---------------------------------------------------------------------------
# Input overrides
# ---------------------------------------------------------------------------

_ALLOWED_STRATEGIES: frozenset[str] = frozenset({"image_id"})


class Computed:
    """Hide an input field from the Playground UI and derive its value
    automatically using a named platform strategy.

    Use the ``image_id_from()`` factory instead of constructing this directly.
    """

    def __init__(self, *, from_field: str, strategy: str) -> None:
        if not from_field.strip():
            raise ValueError("Computed.from_field must be a non-empty string.")
        if strategy not in _ALLOWED_STRATEGIES:
            allowed = sorted(_ALLOWED_STRATEGIES)
            raise ValueError(
                f"Computed strategy {strategy!r} is not supported. "
                f"Allowed strategies: {allowed}"
            )
        self.from_field = from_field.strip()
        self.strategy = strategy

    def to_contract(self) -> dict[str, Any]:
        return {
            "hidden": True,
            "computed": True,
            "from": self.from_field,
            "strategy": self.strategy,
        }


def image_id_from(field: Any) -> Computed:
    """Derive ``image_id`` by hashing the bytes of an image input field.

    Pass a Schema.Inputs field reference or a string field name::

        image_id=image_id_from(SearchSchema.Inputs.image)
        image_id=image_id_from("image")  # fallback
    """
    name = _resolve_field_name(field, "image_id_from")
    return Computed(from_field=name, strategy="image_id")


class PlaygroundInputs:
    """Declare Playground-only overrides for mode input fields.

    Each keyword argument names an input field and provides a ``Computed``
    instance that describes how the platform should derive or hide it::

        inputs = PlaygroundInputs(
            image_id=image_id_from(SearchSchema.Inputs.image),
        )
    """

    def __init__(self, **field_overrides: Computed) -> None:
        for name, override in field_overrides.items():
            if not isinstance(override, Computed):
                raise TypeError(
                    f"PlaygroundInputs.{name} must be a Computed instance "
                    f"(e.g. image_id_from(field)), got {type(override).__name__}."
                )
        self._overrides: dict[str, Computed] = dict(field_overrides)

    def validate_against_inputs(self, inputs: Any) -> None:
        fields = _fields_dict(inputs)
        for field_name, computed in self._overrides.items():
            if fields and computed.from_field not in fields:
                known = sorted(fields)
                raise ValueError(
                    f"PlaygroundInputs.{field_name} derives from unknown input "
                    f"field {computed.from_field!r}. Known inputs: {known}"
                )

    def to_contract(self) -> dict[str, Any]:
        return {name: override.to_contract() for name, override in self._overrides.items()}


# ---------------------------------------------------------------------------
# PlaygroundSpec
# ---------------------------------------------------------------------------


class PlaygroundSpec:
    """Base class for per-mode playground view specifications.

    Declare one subclass per mode in ``playground.py``.
    Reference it from the mode via the ``playground`` kwarg on ``@mode``.

    Subclass rules
    --------------
    - ``view`` (required): a single ``ViewBase`` instance **or** an ordered list
      of ``ViewBase`` instances.  A list produces multiple rendered sections;
      the platform arranges them based on count and screen layout.
    - ``inputs`` (optional): a ``PlaygroundInputs`` instance declaring which
      input fields should be hidden and auto-derived.

    Validation
    ----------
    ``validate_against_mode`` is called by the ``@mode`` decorator at
    class-definition time.  Errors surface immediately, not at runtime.

    Example::

        class WritePlayground(PlaygroundSpec):
            view = [
                Markdown(WriteSchema.Outputs.article),
                Cards(
                    WriteSchema.Outputs.sources,
                    title="title",
                    body="excerpt",
                    metrics=["relevance"],
                    badges=["category"],
                    action="link",
                ),
                Table(WriteSchema.Outputs.stats),
            ]
    """

    view: ClassVar[ViewBase | list[ViewBase]]
    inputs: ClassVar[PlaygroundInputs | None] = None

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        _validate_playground_spec_structure(cls)

    @classmethod
    def validate_against_mode(cls, inputs_schema: Any, outputs_schema: Any) -> None:
        """Cross-validate all field references against the mode's schema."""
        if cls.inputs is not None:
            cls.inputs.validate_against_inputs(inputs_schema)
        views = cls.view if isinstance(cls.view, list) else [cls.view]
        for view in views:
            view.validate_against_outputs(outputs_schema)

    @classmethod
    def to_contract(cls) -> dict[str, Any]:
        """Return the JSON-serialisable contract section for this spec."""
        views = cls.view if isinstance(cls.view, list) else [cls.view]
        contract: dict[str, Any] = {
            "views": [v.to_contract() for v in views],
        }
        if cls.inputs is not None:
            contract["inputs"] = cls.inputs.to_contract()
        return contract


def _validate_playground_spec_structure(cls: type) -> None:
    """Check that a PlaygroundSpec subclass has a valid ``view`` declaration."""
    view = cls.__dict__.get("view")
    if view is None:
        raise TypeError(
            f"{cls.__name__} must declare "
            "`view = <ViewBase instance or list[ViewBase]>`"
        )
    if isinstance(view, ViewBase):
        return
    if isinstance(view, list):
        if not view:
            raise TypeError(f"{cls.__name__}.view list must not be empty.")
        for i, item in enumerate(view):
            if not isinstance(item, ViewBase):
                raise TypeError(
                    f"{cls.__name__}.view[{i}] must be a ViewBase instance, "
                    f"got {type(item).__name__}."
                )
        return
    raise TypeError(
        f"{cls.__name__}.view must be a ViewBase instance or a list of "
        f"ViewBase instances, got {type(view).__name__}."
    )


# ---------------------------------------------------------------------------
# Public helper for Mode.__init_subclass__ integration
# ---------------------------------------------------------------------------


def validate_mode_playground(mode_cls: type, pg_cls: Any) -> None:
    """Validate that *pg_cls* is a ``PlaygroundSpec`` subclass and that all
    its field references match the mode's schema.

    Called from ``Mode.__init_subclass__`` in both the SDK and the framework.
    Resolves the schema from either SDK SchemaDecl attributes (``.inputs``,
    ``.outputs``) or a framework schema container (``.schema.Inputs``,
    ``.schema.Outputs``).
    """
    if not (isinstance(pg_cls, type) and issubclass(pg_cls, PlaygroundSpec)):
        raise TypeError(
            f"Mode '{mode_cls.__name__}.playground' must be a PlaygroundSpec "
            f"subclass, got {type(pg_cls).__name__}."
        )
    outputs_schema = _resolve_mode_outputs(mode_cls)
    if outputs_schema is None:
        raise TypeError(
            f"Cannot validate '{mode_cls.__name__}.playground': "
            "the mode has no accessible Outputs schema."
        )
    inputs_schema = _resolve_mode_inputs(mode_cls)
    try:
        pg_cls.validate_against_mode(inputs_schema, outputs_schema)
    except (ValueError, TypeError) as exc:
        raise TypeError(
            f"Mode '{mode_cls.__name__}.playground' failed schema validation: {exc}"
        ) from exc


def _resolve_mode_outputs(mode_cls: type) -> Any:
    outputs = getattr(mode_cls, "outputs", None)
    if outputs is not None:
        return outputs
    schema_container = getattr(mode_cls, "schema", None)
    if schema_container is not None:
        return getattr(schema_container, "Outputs", None)
    return None


def _resolve_mode_inputs(mode_cls: type) -> Any:
    inputs = getattr(mode_cls, "inputs", None)
    if inputs is not None:
        return inputs
    schema_container = getattr(mode_cls, "schema", None)
    if schema_container is not None:
        return getattr(schema_container, "Inputs", None)
    return None
