"""Static vector contract probe for published model images."""

from __future__ import annotations

import argparse
import json
import os
import sys

from .agent_loader import load_agent_vector_contract


def _module_path_from_env() -> str:
    return os.environ.get("MODEL_ENTRYPOINT", "").strip()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Inspect declared vector contract without starting the model runtime"
    )
    parser.add_argument(
        "--module",
        dest="module_path",
        default=None,
        help="Path to the agent module (defaults to MODEL_ENTRYPOINT env var).",
    )
    args = parser.parse_args()
    module_path = args.module_path or _module_path_from_env()
    if not module_path:
        print(
            "Missing agent module path. Set MODEL_ENTRYPOINT or pass --module.",
            file=sys.stderr,
        )
        raise SystemExit(1)

    payload = load_agent_vector_contract(module_path)
    print(json.dumps(payload))
    raise SystemExit(0 if payload["ok"] else 1)


if __name__ == "__main__":
    main()
