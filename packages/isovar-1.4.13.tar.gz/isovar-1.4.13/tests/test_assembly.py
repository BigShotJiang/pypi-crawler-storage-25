# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import random
from time import time

from isovar.read_collector import ReadCollector
from isovar.variant_sequence import VariantSequence
from isovar.variant_sequence_helpers import initial_variant_sequences_from_reads
from isovar.allele_read import AlleleRead
from isovar.assembly import (
    iterative_overlap_assembly,
    greedy_merge,
    collapse_substrings
)

from pyensembl import ensembl_grch38
from varcode import Variant

from .common import eq_
from .testing_helpers import load_bam


def test_assemble_transcript_fragments_snv():
    alignment_file = load_bam("data/cancer-wgs-primary.chr12.bam")
    chromosome = "12"
    base1_location = 65857041
    ref = "G"
    alt = "C"
    variant = Variant(
        contig=chromosome,
        start=base1_location,
        ref=ref,
        alt=alt,
        ensembl=ensembl_grch38)
    read_creator = ReadCollector()
    variant_reads = read_creator.allele_reads_supporting_variant(
        variant=variant,
        alignment_file=alignment_file)

    sequences = iterative_overlap_assembly(
        initial_variant_sequences_from_reads(variant_reads),
        min_overlap_size=30)

    assert len(sequences) > 0
    max_read_length = max(len(r) for r in variant_reads)
    for s in sequences:
        print("%s%s%s weight=%d length=%d" % (
            s.prefix,
            s.alt,
            s.suffix,
            len(s.reads),
            len(s.sequence)))
        eq_(s.alt, alt)
        if len(s.read_names) > 1:
            # expect sequences supported by more than one read to be greater
            # than the read length
            assert len(s) > max_read_length, \
                "Expected assembled sequences to be longer than read length (%d)" % (
                    max_read_length,)


def test_assembly_of_simple_sequence_from_mock_reads():
    # Read sequences:
    #    AAAAA|CC|TTTTT
    #    AAAAA|CC|TTTTT
    #   GAAAAA|CC|TTTTTG
    #     AAAA|CC|TTTT
    reads = [
        # two identical reads with sequence AAAAA|CC|TTTTT
        AlleleRead(prefix="A" * 5, allele="CC", suffix="T" * 5, name="dup1"),
        AlleleRead(prefix="A" * 5, allele="CC", suffix="T" * 5, name="dup2"),
        # longer sequence GAAAAA|CC|TTTTTG
        AlleleRead(
            prefix="G" + "A" * 5,
            allele="CC",
            suffix="T" * 5 + "G",
            name="longer"),
        # shorter sequence AAAA|CC|TTTT
        AlleleRead(prefix="A" * 4, allele="CC", suffix="T" * 4, name="shorter"),
    ]
    expected_variant_sequence = VariantSequence(
        prefix="G" + "A" * 5, alt="CC", suffix="T" * 5 + "G", reads=reads)
    initial_variant_sequences = initial_variant_sequences_from_reads(reads)
    # expecting one fewer sequence than reads since two of the reads are
    # duplicates
    eq_(len(initial_variant_sequences), len(reads) - 1)

    # calling into either iterative_overlap_assembly or greedy_merge should
    # give same results
    for fn in [greedy_merge, iterative_overlap_assembly]:

        assembled_variant_sequences = fn(
            initial_variant_sequences,
            min_overlap_size=1)

        # since no reads contradict each other then we should get back a single
        # assembled sequence
        eq_(len(assembled_variant_sequences),
            1,
            "Unexpected number of variant sequences: %s" % (assembled_variant_sequences,))
        assembled_variant_sequence = assembled_variant_sequences[0]
        eq_(assembled_variant_sequence, expected_variant_sequence)

        eq_(len(assembled_variant_sequence.reads), len(reads))

        eq_(assembled_variant_sequence.min_coverage(), 1)
        # 2 bases with 1/4 reads, 2 bases with 3/4 reads, remaining 10 bases with
        # all 4/4 reads
        expected_mean_coverage = (2 * 1 + 2 * 3 + 10 * 4) / 14
        eq_(assembled_variant_sequence.mean_coverage(), expected_mean_coverage)


def test_collapse_substrings():
    # AAA|C|GGG
    vs_longer = VariantSequence(
        prefix="AAA", alt="C", suffix="GGG", reads={"1"})
    # AAA|C|GG
    vs_shorter = VariantSequence(
        prefix="AAA", alt="C", suffix="GG", reads={"2"})
    vs_unrelated = VariantSequence("TAA", alt="C", suffix="GG", reads={"3"})
    results = collapse_substrings([vs_longer, vs_shorter, vs_unrelated])
    eq_(len(results), 2), "Expected two sequences, got %d: %s" % (
        len(results), results)
    vs_combined = vs_longer.add_reads({"2"})
    assert vs_combined in results, "Expected %s to be in %s" % (vs_combined, results)
    assert vs_unrelated in results, "Expected %s to be in %s" % (vs_unrelated, results)


def test_collapse_substrings_absorbed_sequence_not_reappended():
    # Regression test for issue #130.
    # A shorter sequence is contained in one longer result (vs_long1) but NOT
    # in another longer result (vs_long2). Before the fix, the inner loop
    # continued past the containment match and `found_superstring` got
    # overwritten to False, causing the absorbed short sequence to be
    # *also* appended to result_list (double counting its reads).
    vs_long1 = VariantSequence(
        prefix="AAA", alt="C", suffix="GGG", reads={"L1"})   # AAA|C|GGG
    vs_long2 = VariantSequence(
        prefix="AAA", alt="C", suffix="TTT", reads={"L2"})   # AAA|C|TTT
    vs_short = VariantSequence(
        prefix="AA", alt="C", suffix="GG", reads={"S"})      # AA|C|GG
    # Sanity-check the containment relationships the bug depends on:
    assert vs_long1.contains(vs_short)
    assert not vs_long2.contains(vs_short)

    # Pass long1 first so that after length-sort it ends up before long2 in
    # result_list. The bug then manifested when iterating short's superstring
    # candidates: long1 matched, long2 did not, and `found_superstring` was
    # clobbered by the last iteration.
    results = collapse_substrings([vs_long1, vs_long2, vs_short])

    assert len(results) == 2, \
        "Expected short sequence to be absorbed into long1 and not reappended, got %d: %s" % (
            len(results), results)

    # The surviving long1 should have absorbed short's reads.
    long1_in_results = [r for r in results if r.suffix == "GGG"]
    assert len(long1_in_results) == 1
    assert long1_in_results[0].reads == frozenset({"L1", "S"}), \
        "Expected long1 to carry both L1 and S reads, got %s" % (long1_in_results[0].reads,)

    # long2 should be unchanged (not carrying short's reads).
    long2_in_results = [r for r in results if r.suffix == "TTT"]
    assert len(long2_in_results) == 1
    assert long2_in_results[0].reads == frozenset({"L2"})

    # And short should not have reappeared as a standalone entry.
    assert not any(r.prefix == "AA" and r.suffix == "GG" for r in results), \
        "Short sequence should have been absorbed, not reappended: %s" % (results,)


def test_collapse_substrings_absorbs_into_first_only():
    # If a short sequence is contained in TWO longer sequences, we should
    # only absorb it into one (the first encountered). Otherwise the same
    # reads would be counted in both supersets.
    vs_long1 = VariantSequence(
        prefix="AAA", alt="C", suffix="GGG", reads={"L1"})
    vs_long2 = VariantSequence(
        prefix="TAA", alt="C", suffix="GGG", reads={"L2"})
    vs_short = VariantSequence(
        prefix="AA", alt="C", suffix="GG", reads={"S"})
    assert vs_long1.contains(vs_short)
    assert vs_long2.contains(vs_short)

    results = collapse_substrings([vs_long1, vs_long2, vs_short])
    eq_(len(results), 2)

    # Exactly one of the two longer sequences should carry the short read.
    n_carrying_short = sum(1 for r in results if "S" in r.reads)
    eq_(n_carrying_short, 1,
        "Short read 'S' should only be absorbed into one longer sequence, got %d: %s" % (
            n_carrying_short, results))


def test_assembly_of_many_subsequences():
    original_prefix = "ACTGAACCTTGGAAACCCTTTGGG"
    original_allele = "CCCTTT"
    original_suffix = "GGAAGGAAGGAATTTTTTTT"

    # generate 100 subsequences of all combinations of 0-9
    # characters trimmed from beginning of prefix vs. end of suffix
    subsequences = [
        VariantSequence(
            prefix=original_prefix[i:],
            alt=original_allele,
            suffix=original_suffix[:-j] if j > 0 else original_suffix,
            reads={str(i) + "_" + str(j)})
        for i in range(10)
        for j in range(10)
    ]
    eq_(100, len(subsequences))
    # adding one decoy sequence which doesn't match
    decoy = VariantSequence(
        prefix="G" + original_prefix[1:],
        alt=original_allele,
        suffix=original_suffix,
        reads={"decoy"})
    input_sequences = subsequences + [decoy]
    results = iterative_overlap_assembly(
        input_sequences, min_overlap_size=len(original_allele))

    eq_(len(results), 2)

    result = results[0]
    eq_(result.prefix, original_prefix)
    eq_(result.alt, original_allele)
    eq_(result.suffix, original_suffix)
    eq_(len(result.reads), len(subsequences))

    result_decoy = results[1]
    eq_(result_decoy.sequence, decoy.sequence)


def test_assembly_time():
    original_prefix = "ACTGAACCTTGGAAACCCTTTGGG"
    original_allele = "CCCTTT"
    original_suffix = "GGAAGGAAGGAATTTTTTTTGGCC"

    # generate 400 subsequences of all combinations of 0-19
    # characters trimmed from beginning of prefix vs. end of suffix
    subsequences = [
        VariantSequence(
            prefix=original_prefix[i:],
            alt=original_allele,
            suffix=original_suffix[:-j] if j > 0 else original_suffix,
            reads={str(i) + "_" + str(j)})
        for i in range(20)
        for j in range(20)
    ]
    eq_(len(subsequences), 400)
    t_start = time()
    results = iterative_overlap_assembly(
        subsequences,
        min_overlap_size=len(original_allele))
    t_end = time()
    eq_(len(results), 1)
    result = results[0]
    eq_(result.prefix, original_prefix)
    eq_(result.suffix, original_suffix)
    t_elapsed = t_end - t_start
    assert t_elapsed < 0.1, \
        "Expected assembly of 400 sequences to take less than 100ms: %0.4fms" % (
            t_elapsed * 1000,)


def test_assembly_unrelated_sequences():
    # 2 overlapping sequences, 1 with a different suffix,
    # and 2 totally unrelated sequences
    variant_sequences = [
        VariantSequence(
            prefix="CCC",
            alt="T",
            suffix="GGG",
            reads={"1"}),
        VariantSequence(
            prefix="TCCC",
            alt="T",
            suffix="G",
            reads={"2"}),
        VariantSequence(
            prefix="CCC",
            alt="T",
            suffix="AAA",
            reads={"3"}),
        VariantSequence(
            prefix="AGG",
            alt="T",
            suffix="CGG",
            reads={"4"}),
        VariantSequence(
            prefix="CAC",
            alt="T",
            suffix="TTT",
            reads={"5"})
    ]
    results = iterative_overlap_assembly(
        variant_sequences, min_overlap_size=1)
    eq_(len(results), 4)
    # first two sequences were overlapping
    count_multiple = 0
    count_singleton = 0
    for result in results:
        # all but one result are singletons
        if len(result.reads) > 1:
            eq_(result.reads, {"1", "2"})
            count_multiple += 1
        else:
            count_singleton += 1
    eq_(3, count_singleton)
    eq_(1, count_multiple)


def test_assembly_no_sequences():
    eq_(iterative_overlap_assembly([]), [])


def test_assembly_1_sequence():
    vs = VariantSequence(
        prefix="CCC",
        alt="T",
        suffix="GGG",
        reads={"1"})
    eq_(iterative_overlap_assembly([vs]), [vs])


def test_greedy_merge_deterministic_across_input_orders():
    """
    Verify that greedy_merge produces the same assembled sequences
    regardless of input order. Regression test for #153, also covers #148.
    """
    variant_sequences = [
        VariantSequence(prefix="AAAAAA", alt="CC", suffix="TTTT", reads={"r1"}),
        VariantSequence(prefix="AAAA", alt="CC", suffix="TTTTGG", reads={"r2"}),
        VariantSequence(prefix="GGAAAAAA", alt="CC", suffix="TT", reads={"r3"}),
        VariantSequence(prefix="AAA", alt="CC", suffix="TTTTGGCC", reads={"r4"}),
        VariantSequence(prefix="CCGGAAAAAA", alt="CC", suffix="T", reads={"r5"}),
    ]

    reference_result = greedy_merge(variant_sequences, min_overlap_size=1)
    reference_sequences = sorted(r.sequence for r in reference_result)
    reference_all_reads = set().union(*(r.reads for r in reference_result))

    rng = random.Random(42)
    for trial in range(20):
        shuffled = list(variant_sequences)
        rng.shuffle(shuffled)
        result = greedy_merge(shuffled, min_overlap_size=1)
        result_sequences = sorted(r.sequence for r in result)
        result_all_reads = set().union(*(r.reads for r in result))
        assert result_sequences == reference_sequences, \
            "Trial %d: different sequences from shuffled input.\nRef: %s\nGot: %s" % (
                trial, reference_sequences, result_sequences)
        assert result_all_reads == reference_all_reads, \
            "Trial %d: different reads from shuffled input.\nRef: %s\nGot: %s" % (
                trial, reference_all_reads, result_all_reads)


def test_greedy_merge_prefers_larger_overlap():
    """
    When a sequence could merge with two partners, the larger overlap
    should be chosen. This tests the sorting logic in greedy_merge_helper.
    """
    # A overlaps B by 3 bases, A overlaps C by 6 bases.
    # A should merge with C (larger overlap) not B.
    vs_a = VariantSequence(prefix="AAAAAA", alt="X", suffix="TTTTTT", reads={"a"})
    vs_b = VariantSequence(prefix="AAA", alt="X", suffix="TTTTTTGGGGGG", reads={"b"})
    vs_c = VariantSequence(prefix="AAAAAA", alt="X", suffix="TTTTTTCCCCCC", reads={"c"})

    result = greedy_merge([vs_a, vs_b, vs_c], min_overlap_size=1)

    # A+C should merge (overlap = 6+6+1=13 bases out of 13+13=26)
    # leaving B unmerged (or merging in a subsequent round if compatible)
    merged_reads = set()
    for r in result:
        merged_reads.update(r.reads)
    assert merged_reads == {"a", "b", "c"}, \
        "All reads should be accounted for, got %s" % merged_reads

    # The longest assembled sequence should contain C's long suffix
    longest = max(result, key=len)
    assert "CCCCCC" in longest.sequence, \
        "Expected the larger overlap (with C's CCCCCC suffix) to be preferred"


def test_iterative_assembly_deterministic_across_input_orders():
    """
    End-to-end test: iterative_overlap_assembly should produce
    identical results regardless of input ordering.
    """
    original_prefix = "ACTGAACCTTGG"
    original_allele = "CC"
    original_suffix = "GGAAGGAAGGAA"

    subsequences = [
        VariantSequence(
            prefix=original_prefix[i:],
            alt=original_allele,
            suffix=original_suffix[:-j] if j > 0 else original_suffix,
            reads={str(i) + "_" + str(j)})
        for i in range(6)
        for j in range(6)
    ]

    reference = iterative_overlap_assembly(subsequences, min_overlap_size=2)
    reference_sequences = sorted(r.sequence for r in reference)

    rng = random.Random(123)
    for trial in range(10):
        shuffled = list(subsequences)
        rng.shuffle(shuffled)
        result = iterative_overlap_assembly(shuffled, min_overlap_size=2)
        result_sequences = sorted(r.sequence for r in result)
        assert result_sequences == reference_sequences, \
            "Trial %d: different assembly from shuffled input" % trial


def test_assembly_circuit_breaker_skips_merge():
    """
    When the number of sequences after collapse exceeds
    max_assembly_sequences, the greedy merge is skipped and sequences
    are returned sorted by read support.
    """
    # Use distinct prefixes so collapse_substrings can't fold them
    prefixes = ["GAT", "CTA", "AGC", "TCA", "GCG"]
    variant_sequences = [
        VariantSequence(
            prefix=p, alt="X", suffix="TTT",
            reads={"%s_%d" % (p, k) for k in range(i + 1)})
        for i, p in enumerate(prefixes)
    ]

    result = iterative_overlap_assembly(
        variant_sequences,
        min_overlap_size=1,
        max_assembly_sequences=3)

    eq_(len(result), 5, "All 5 sequences should be returned (no merge)")
    read_counts = [len(r.reads) for r in result]
    assert read_counts == sorted(read_counts, reverse=True), \
        "Results should be sorted by decreasing read count, got %s" % read_counts


def test_assembly_circuit_breaker_disabled_with_none():
    """max_assembly_sequences=None disables the circuit breaker."""
    variant_sequences = [
        VariantSequence(prefix="A" * 5, alt="CC", suffix="T" * 5, reads={"r1"}),
        VariantSequence(prefix="A" * 5, alt="CC", suffix="T" * 5 + "G", reads={"r2"}),
    ]
    result = iterative_overlap_assembly(
        variant_sequences,
        min_overlap_size=1,
        max_assembly_sequences=None)
    # Should merge normally despite any threshold
    eq_(len(result), 1)


def test_assembly_circuit_breaker_not_triggered_under_threshold():
    """
    When the sequence count is under the threshold, greedy merge proceeds
    normally (same as no circuit breaker).
    """
    variant_sequences = [
        VariantSequence(prefix="AAAA", alt="CC", suffix="TTTT", reads={"r1"}),
        VariantSequence(prefix="AA", alt="CC", suffix="TTTTGG", reads={"r2"}),
    ]
    result_with_breaker = iterative_overlap_assembly(
        variant_sequences, min_overlap_size=1, max_assembly_sequences=100)
    result_without_breaker = iterative_overlap_assembly(
        variant_sequences, min_overlap_size=1, max_assembly_sequences=None)
    eq_(len(result_with_breaker), len(result_without_breaker))
    for r1, r2 in zip(result_with_breaker, result_without_breaker):
        eq_(r1.sequence, r2.sequence)
