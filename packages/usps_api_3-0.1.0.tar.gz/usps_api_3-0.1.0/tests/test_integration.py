import pytest

from usps_api_3 import USPSClient


@pytest.mark.integration
def test_get_address_against_usps_test_endpoint(
    usps_test_credentials,
    usps_test_base_url,
):
    client_id, client_secret = usps_test_credentials
    client = USPSClient(
        key=client_id,
        secret=client_secret,
        base_url=usps_test_base_url,
    )

    response = client.get_address(
        street_address="1600 Pennsylvania Ave NW",
        city="Washington",
        state="DC",
        zip_code="20500",
    )

    assert response.address.state == "DC"
    assert response.address.zip_code == "20500"
    assert response.address.city


def test_get_city_state_against_usps_test_endpoint(
    usps_test_credentials,
    usps_test_base_url,
):
    client_id, client_secret = usps_test_credentials
    client = USPSClient(
        key=client_id,
        secret=client_secret,
        base_url=usps_test_base_url,
    )

    response = client.get_city_state(zip_code="20500")

    assert response.city == "WASHINGTON"
    assert response.state == "DC"
    assert response.zip_code == "20500"


def test_get_zip_code_against_usps_test_endpoint(
    usps_test_credentials,
    usps_test_base_url,
):
    client_id, client_secret = usps_test_credentials
    client = USPSClient(
        key=client_id,
        secret=client_secret,
        base_url=usps_test_base_url,
    )

    response = client.get_zip_code(
        street_address="1600 Pennsylvania Ave NW",
        city="Washington",
        state="DC",
    )

    assert response.address.zip_code == "20500"
    assert response.address.city == "WASHINGTON"
    assert response.address.state == "DC"
