import os
from pathlib import Path

import pytest
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[1]
load_dotenv(PROJECT_ROOT / ".env")


def pytest_addoption(parser):
    parser.addoption(
        "--run-integration",
        action="store_true",
        default=False,
        help="Run tests that make real HTTP requests to USPS.",
    )


@pytest.fixture
def usps_test_credentials(pytestconfig):
    if not pytestconfig.getoption("--run-integration"):
        pytest.skip("pass --run-integration to run tests against USPS")

    client_id = os.getenv("USPS_CLIENT_ID")
    client_secret = os.getenv("USPS_CLIENT_SECRET")

    if not client_id or not client_secret:
        pytest.skip("set USPS_CLIENT_ID and USPS_CLIENT_SECRET to run USPS tests")

    return client_id, client_secret


@pytest.fixture
def usps_test_base_url():
    return os.getenv("USPS_TEST_BASE_URL", "https://apis-tem.usps.com")
