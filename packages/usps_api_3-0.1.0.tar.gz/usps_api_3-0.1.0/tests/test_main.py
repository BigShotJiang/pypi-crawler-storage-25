import json

import requests

from usps_api_3 import USPSClient


class DummyResponse:
    def __init__(self, status_code=200, json_data=None, text=""):
        self.status_code = status_code
        self._json_data = json_data
        self.text = text

    def json(self):
        if self._json_data is None and self.text:
            return json.loads(self.text)
        return self._json_data

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(response=self)


def test_client_uses_provided_base_url_for_oauth_and_address_lookup(monkeypatch):
    calls = []

    token_payload = {
        "access_token": "test-token",
        "issued_at": 1_900_000_000_000,
        "expires_in": 3600,
        "token_type": "Bearer",
        "status": "approved",
    }
    address_payload = {
        "firm": "string",
        "address": {
            "streetAddress": "123 MAIN ST",
            "streetAddressAbbreviation": "",
            "secondaryAddress": "",
            "cityAbbreviation": "ANYTOWN",
            "city": "ANYTOWN",
            "state": "CA",
            "ZIPCode": "90210",
            "ZIPPlus4": "1234",
            "urbanization": "",
        },
        "additionalInfo": {
            "deliveryPoint": "00",
            "carrierRoute": "C012",
            "DPVConfirmation": "Y",
            "DPVCMRA": "N",
            "business": "N",
            "centralDeliveryPoint": "N",
            "vacant": "N",
        },
        "corrections": [{"code": "A1", "text": "normalized"}],
        "matches": [{"code": "M1", "text": "exact"}],
        "warnings": [],
    }

    responses = [
        DummyResponse(status_code=200, json_data=token_payload),
        DummyResponse(status_code=200, text=json.dumps(address_payload)),
    ]

    def fake_post(url, data=None, headers=None, auth=None):
        calls.append(
            {
                "method": "POST",
                "url": url,
                "data": data,
                "headers": headers,
                "auth": auth,
            }
        )
        return responses.pop(0)

    def fake_get(url, params=None, headers=None):
        calls.append(
            {
                "method": "GET",
                "url": url,
                "params": params,
                "headers": headers,
                "auth": None,
            }
        )
        return responses.pop(0)

    monkeypatch.setattr(requests, "post", fake_post)
    monkeypatch.setattr(requests, "get", fake_get)

    client = USPSClient(
        key="client-id",
        secret="client-secret",
        base_url="https://apis-tem.usps.com",
    )
    response = client.get_address(street_address="123 Main St", state="CA")

    assert calls[0]["method"] == "POST"
    assert calls[1]["method"] == "GET"
    assert calls[0]["url"] == "https://apis-tem.usps.com/oauth2/v3/token"
    assert calls[1]["url"] == "https://apis-tem.usps.com/addresses/v3/address"
    assert calls[1]["headers"]["Authorization"] == "Bearer test-token"
    assert "Content-Type" not in calls[1]["headers"]
    assert calls[1]["params"] == {
        "streetAddress": "123 Main St",
        "state": "CA",
    }
    assert response.address.city == "ANYTOWN"
    assert response.address.zip_code == "90210"
    assert response.address.zip_code_plus_4 == "1234"
    assert response.additional_info.dpv_confirmation == "Y"
    assert response.additional_info.dpv_cmra == "N"
