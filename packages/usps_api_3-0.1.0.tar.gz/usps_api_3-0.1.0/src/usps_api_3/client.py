from __future__ import annotations

import functools
import re
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any, Concatenate, Literal, ParamSpec, TypeVar

import requests
from pydantic import BaseModel, ConfigDict, Field, ValidationError
from pydantic.alias_generators import to_camel, to_snake


class USPSModel(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class OAuthRequestBody(BaseModel):
    grant_type: Literal["client_credentials", "refresh_token", "authorization_code"]
    scope: str | None = None
    client_id: str
    client_secret: str


class OAuthResponse(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_snake,
        populate_by_name=True,
    )
    access_token: str
    issued_at: int  # Unix epoch time in milliseconds
    expires_in: int  # Expiration time in seconds
    token_type: str
    status: Literal["approved", "revoked"]
    issuer: str | None = None
    scope: str | None = None
    client_id: str | None = None
    application_name: str | None = None
    api_products: str | None = None
    public_key: str | None = None


class OAuthRevokeBody(BaseModel):
    token: str
    token_type_hint: Literal["access_token", "refresh_token"] | None = "refresh_token"


class AddressValidationRequestParams(USPSModel):
    firm: str | None = Field(None, max_length=50)
    street_address: str
    secondary_address: str | None = None
    city: str | None = None
    state: str = Field(min_length=2, max_length=2)
    urbanization: str | None = None
    zip_code: str | None = Field(
        None,
        pattern=r"^\d{5}$",
        validation_alias="ZIPCode",
        serialization_alias="ZIPCode",
    )
    zip_code_plus_4: str | None = Field(
        None,
        pattern=r"^\d{4}$",
        validation_alias="ZIPPlus4",
        serialization_alias="ZIPPlus4",
    )


class Address(USPSModel):
    street_address: str = Field(min_length=1, max_length=100)
    street_address_abbreviation: str = Field("", min_length=0, max_length=50)
    secondary_address: str = Field("", min_length=0, max_length=50)
    city_abbreviation: str
    city: str = Field(min_length=1, max_length=28)
    state: str = Field(min_length=2, max_length=2)
    zip_code: str = Field(
        pattern=r"^\d{5}$",
        validation_alias="ZIPCode",
        serialization_alias="ZIPCode",
    )
    zip_code_plus_4: str | None = Field(
        None,
        pattern=r"^\d{4}$",
        validation_alias="ZIPPlus4",
        serialization_alias="ZIPPlus4",
    )
    urbanization: str = Field("", min_length=0, max_length=96)
    property_name: Any | None = None


class AddressAdditionalInfo(USPSModel):
    delivery_point: str
    carrier_route: str = Field("", min_length=0, max_length=5)
    dpv_confirmation: Literal["Y", "D", "S", "N"] = Field(
        validation_alias="DPVConfirmation",
        serialization_alias="DPVConfirmation",
    )
    dpv_cmra: Literal["Y", "N"] = Field(
        validation_alias="DPVCMRA",
        serialization_alias="DPVCMRA",
    )
    business: Literal["Y", "N"]
    central_delivery_point: Literal["Y", "N", ""]
    vacant: Literal["Y", "N"]


class AddressCorrection(BaseModel):
    code: str = Field(min_length=0, max_length=2)
    text: str


class AddressMatch(BaseModel):
    code: str = Field(min_length=0, max_length=2)
    text: str


class AddressValidationResponse(USPSModel):
    firm: str = Field("", min_length=0, max_length=50)
    address: Address
    additional_info: AddressAdditionalInfo
    corrections: list[AddressCorrection]
    matches: list[AddressMatch]
    warnings: list[str] | None = None


class ZipCodeResponse(USPSModel):
    firm: str = Field("", min_length=0, max_length=50)
    address: Address


class CityStateResponse(USPSModel):
    city: str = Field(min_length=1, max_length=28)
    state: str = Field(min_length=2, max_length=2)
    zip_code: str = Field(
        min_length=5,
        max_length=5,
        pattern=r"^\d{5}$",
        validation_alias="ZIPCode",
        serialization_alias="ZIPCode",
    )


P = ParamSpec("P")
R = TypeVar("R")
ModelT = TypeVar("ModelT", bound=BaseModel)


def use_oauth[**P, R](
    func: Callable[Concatenate[USPSClient, P], R],
) -> Callable[Concatenate[USPSClient, P], R]:
    @functools.wraps(func)
    def wrapper(self: USPSClient, *args: P.args, **kwargs: P.kwargs) -> R:
        """
        Refresh the OAuth token if it's missing or about to expire.
        If the response is not authorized, try refreshing the token once and retrying the request.
        """

        if not self.oauth_token:
            self.refresh_oauth_token()

        five_minutes_ms = 5 * 60 * 1000
        current_time_ms = int(datetime.now(UTC).timestamp() * 1000)

        expires_at_ms = self.oauth_token.issued_at + (
            self.oauth_token.expires_in * 1000
        )
        is_expiring = expires_at_ms - five_minutes_ms < current_time_ms
        if is_expiring:
            self.refresh_oauth_token()

        try:
            return func(self, *args, **kwargs)
        except requests.HTTPError as err:
            if (
                err.response is not None and err.response.status_code == 401
            ):  # Unauthorized, token might be expired
                self.refresh_oauth_token()
                return func(self, *args, **kwargs)
            else:
                raise

    return wrapper


class USPSClient:
    BASE_URL = "https://apis.usps.com"

    def __init__(
        self,
        key: str,
        secret: str,
        base_url: str | None = None,
    ):
        self.key = key
        self.secret = secret
        self.BASE_URL = (base_url or self.BASE_URL).rstrip("/")
        self.refresh_oauth_token()

    def refresh_oauth_token(self):
        self.oauth_token = self.generate_oauth_token()

    @staticmethod
    def _parse_json_response(
        response: requests.Response,
        model: type[ModelT],
        context: str,
    ) -> ModelT:
        """
        Parse the response into JSON then it's expected model. Raise descriptive errors for common parsing issues
        """
        try:
            payload = response.json()
        except ValueError as err:
            if not response.text.strip():
                raise ValueError(f"{context} returned an empty response body") from err

            raise ValueError(f"{context} returned invalid JSON") from err

        try:
            print(payload)
            return model.model_validate(payload)
        except ValidationError as err:
            raise ValueError(f"{context} returned an unexpected JSON payload") from err

    def generate_oauth_token(self):
        ENDPOINT = "/oauth2/v3/token"

        url = self.BASE_URL + ENDPOINT

        params = OAuthRequestBody(
            grant_type="client_credentials",
            client_id=self.key,
            client_secret=self.secret,
        )

        response = requests.post(
            url,
            data=params.model_dump_json(),
            headers={"Content-Type": "application/json"},
        )
        response.raise_for_status()

        if response.status_code == 200:
            return self._parse_json_response(
                response,
                OAuthResponse,
                "OAuth token endpoint",
            )
        else:
            raise ValueError("Failed to generate OAuth token")

    def revoke_oauth_token(
        self,
        token: str,
        token_type_hint: Literal["access_token", "refresh_token"]
        | None = "refresh_token",
    ):
        ENDPOINT = "/oauth2/v3/revoke"

        url = self.BASE_URL + ENDPOINT

        params = OAuthRevokeBody(token=token, token_type_hint=token_type_hint)

        response = requests.post(
            url,
            data=params.model_dump_json(),
            headers={"Content-Type": "application/json"},
            auth=(self.key, self.secret),
        )
        response.raise_for_status()

        if response.status_code == 200:
            return {"message": "Token revoked successfully"}
        else:
            raise ValueError("Failed to revoke OAuth token")

    @use_oauth
    def get_address(
        self,
        street_address: str,
        state: str,
        firm: str | None = None,
        secondary_address: str | None = None,
        city: str | None = None,
        urbanization: str | None = None,
        zip_code: str | None = None,
        zip_code_plus_4: str | None = None,
    ):
        ENDPOINT = "/addresses/v3/address"

        url = self.BASE_URL + ENDPOINT

        query_params = AddressValidationRequestParams(
            firm=firm,
            street_address=street_address,
            secondary_address=secondary_address,
            city=city,
            state=state,
            zip_code=zip_code,
            urbanization=urbanization,
            zip_code_plus_4=zip_code_plus_4,
        ).model_dump(by_alias=True, exclude_none=True)

        headers = {
            "Authorization": f"Bearer {self.oauth_token.access_token}",
        }

        response = requests.get(
            url,
            params=query_params,
            headers=headers,
        )
        response.raise_for_status()

        return self._parse_json_response(
            response,
            AddressValidationResponse,
            "Address validation endpoint",
        )

    def get_city_state(self, zip_code: str) -> CityStateResponse:
        ENDPOINT = "/addresses/v3/city-state"
        zip_code = zip_code.strip()

        if re.fullmatch(r"^\d{5}$", zip_code) is None:
            raise ValueError("ZIP code must be a 5-digit string")

        url = self.BASE_URL + ENDPOINT

        query_params = {"ZIPCode": zip_code}

        headers = {
            "Authorization": f"Bearer {self.oauth_token.access_token}",
        }

        response = requests.get(
            url,
            params=query_params,
            headers=headers,
        )
        response.raise_for_status()

        return self._parse_json_response(
            response,
            CityStateResponse,
            "City-State endpoint",
        )

    def get_zip_code(
        self,
        street_address: str,
        city: str,
        state: str,
        firm: str | None = None,
        secondary_address: str | None = None,
        zip_code: str | None = None,
        zip_plus_4: str | None = None,
    ):
        ENDPOINT = "/addresses/v3/zipcode"

        url = self.BASE_URL + ENDPOINT

        query_params = AddressValidationRequestParams(
            firm=firm,
            street_address=street_address,
            secondary_address=secondary_address,
            city=city,
            state=state,
            zip_code=zip_code,
            zip_code_plus_4=zip_plus_4,
        ).model_dump(by_alias=True, exclude_none=True)

        headers = {
            "Authorization": f"Bearer {self.oauth_token.access_token}",
        }

        response = requests.get(
            url,
            params=query_params,
            headers=headers,
        )
        response.raise_for_status()

        return self._parse_json_response(
            response,
            ZipCodeResponse,
            "ZIP code endpoint",
        )
