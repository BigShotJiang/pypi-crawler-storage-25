#EzTelegramApi

Simple Telegram helper for sending messages.