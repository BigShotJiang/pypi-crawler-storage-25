"""Shared pytest fixtures for iagent-stack."""

from __future__ import annotations

import pytest

from iagent_stack import Config, Stack


@pytest.fixture
def test_config() -> Config:
    return Config(
        api_key="iah_test_key",
        hub_base_url="https://api.iagenthub.test/v1",
        connect_timeout=1.0,
        read_timeout=1.0,
        max_retries=0,
        user_agent="iagent-stack-test/0.1.0",
    )


@pytest.fixture
async def stack(test_config: Config):
    """A Stack wired to a non-routable test base URL."""
    s = Stack(config=test_config)
    yield s
    await s.close()
