"""Tests for the HTTP transport layer."""

from __future__ import annotations

import pytest
from pytest_httpx import HTTPXMock

from iagent_stack import (
    AuthenticationError,
    Config,
    PaymentRequiredError,
    RateLimitError,
    Stack,
    UpstreamError,
)


async def test_successful_request_returns_json(httpx_mock: HTTPXMock) -> None:
    config = Config(
        api_key="iah_test",
        hub_base_url="https://api.iagenthub.test/v1",
        max_retries=0,
    )
    httpx_mock.add_response(
        url="https://api.iagenthub.test/v1/trust/ratings/base/0xabc",
        json={"rating": "AAA", "score": 95},
    )
    stack = Stack(config=config)
    result = await stack.trust.rating("base", "0xabc")
    assert result == {"rating": "AAA", "score": 95}
    await stack.close()


async def test_401_raises_authentication_error(httpx_mock: HTTPXMock) -> None:
    config = Config(api_key="bad_key", hub_base_url="https://api.iagenthub.test/v1", max_retries=0)
    httpx_mock.add_response(
        url="https://api.iagenthub.test/v1/trust/ratings/base/0xabc",
        status_code=401,
        json={"error": "invalid_key"},
    )
    stack = Stack(config=config)
    with pytest.raises(AuthenticationError) as exc_info:
        await stack.trust.rating("base", "0xabc")
    assert exc_info.value.status == 401
    assert exc_info.value.product == "trust"
    await stack.close()


async def test_402_without_autopay_raises_payment_required(httpx_mock: HTTPXMock) -> None:
    config = Config(
        api_key="iah_test",
        hub_base_url="https://api.iagenthub.test/v1",
        max_retries=0,
        x402_autopay=False,
    )
    httpx_mock.add_response(
        url="https://api.iagenthub.test/v1/ref/search?q=research+agents&limit=20",
        status_code=402,
        json={
            "accepts": [
                {"scheme": "exact", "network": "base-mainnet", "asset": "USDC", "amount": "0.01"}
            ]
        },
    )
    stack = Stack(config=config)
    with pytest.raises(PaymentRequiredError) as exc_info:
        await stack.ref.search("research agents")
    assert exc_info.value.status == 402
    assert len(exc_info.value.accepts) == 1
    assert exc_info.value.accepts[0]["asset"] == "USDC"
    await stack.close()


async def test_429_with_retry_after_triggers_backoff(httpx_mock: HTTPXMock) -> None:
    config = Config(
        api_key="iah_test",
        hub_base_url="https://api.iagenthub.test/v1",
        max_retries=1,
        retry_backoff_seconds=0.01,
    )
    httpx_mock.add_response(
        url="https://api.iagenthub.test/v1/log/traces?agent_id=my-agent&limit=100",
        status_code=429,
        headers={"retry-after": "0.01"},
    )
    httpx_mock.add_response(
        url="https://api.iagenthub.test/v1/log/traces?agent_id=my-agent&limit=100",
        json=[{"decision_id": "d1"}],
    )
    stack = Stack(config=config)
    result = await stack.log.traces(agent_id="my-agent")
    assert result == [{"decision_id": "d1"}]
    await stack.close()


async def test_429_after_max_retries_raises_rate_limit(httpx_mock: HTTPXMock) -> None:
    config = Config(
        api_key="iah_test",
        hub_base_url="https://api.iagenthub.test/v1",
        max_retries=0,
    )
    httpx_mock.add_response(
        url="https://api.iagenthub.test/v1/log/traces?agent_id=my-agent&limit=100",
        status_code=429,
        headers={"retry-after": "5"},
    )
    stack = Stack(config=config)
    with pytest.raises(RateLimitError) as exc_info:
        await stack.log.traces(agent_id="my-agent")
    assert exc_info.value.retry_after == 5.0
    await stack.close()


async def test_500_raises_upstream_error(httpx_mock: HTTPXMock) -> None:
    config = Config(
        api_key="iah_test",
        hub_base_url="https://api.iagenthub.test/v1",
        max_retries=0,
    )
    httpx_mock.add_response(
        url="https://api.iagenthub.test/v1/safe/verify",
        status_code=500,
        json={"error": "internal_server_error"},
    )
    stack = Stack(config=config)
    with pytest.raises(UpstreamError) as exc_info:
        await stack.safe.verify(
            agent_id="a1",
            action_type="pay",
            action_payload={"amount": 1},
        )
    assert exc_info.value.status == 500
    assert exc_info.value.product == "safe"
    await stack.close()


async def test_auth_header_is_set_on_requests(httpx_mock: HTTPXMock) -> None:
    config = Config(
        api_key="iah_live_abc123",
        hub_base_url="https://api.iagenthub.test/v1",
        max_retries=0,
    )
    httpx_mock.add_response(
        url="https://api.iagenthub.test/v1/hub/usage",
        json={"total_usd": 0},
    )
    stack = Stack(config=config)
    await stack.hub.usage()
    request = httpx_mock.get_requests()[0]
    assert request.headers["authorization"] == "Bearer iah_live_abc123"
    assert "iagent-stack" in request.headers["user-agent"]
    await stack.close()


async def test_a2a_headers_included_when_enabled(httpx_mock: HTTPXMock) -> None:
    config = Config(
        api_key="iah_test",
        hub_base_url="https://api.iagenthub.test/v1",
        max_retries=0,
        a2a_enabled=True,
        a2a_agent_id="did:web:my-agent.example",
    )
    httpx_mock.add_response(
        url="https://api.iagenthub.test/v1/ref/search?q=anything&limit=20",
        json={"results": []},
    )
    stack = Stack(config=config)
    await stack.ref.search("anything")
    request = httpx_mock.get_requests()[0]
    assert request.headers["x-a2a-agent-id"] == "did:web:my-agent.example"
    assert request.headers["x-a2a-version"] == "0.3.0"
    await stack.close()
