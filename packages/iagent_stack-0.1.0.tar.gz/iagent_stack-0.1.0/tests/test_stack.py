"""Tests for the top-level Stack client."""

from __future__ import annotations

import os
from unittest.mock import patch

import pytest

from iagent_stack import (
    Config,
    PaymentRequiredError,
    STACK_PRODUCTS,
    Stack,
    SUPPORTED_PROTOCOLS,
    __version__,
)
from iagent_stack.products import (
    ComputeClient,
    EdgeClient,
    FarmClient,
    FoundryClient,
    HubClient,
    IdClient,
    LawClient,
    LogClient,
    MarketClient,
    MemoryClient,
    PayClient,
    RefClient,
    SafeClient,
    SimClient,
    TrustClient,
)


def test_version_string() -> None:
    assert __version__.count(".") == 2


def test_stack_products_list_is_fifteen() -> None:
    # iAgentGrid is intentionally not in the public client surface
    assert len(STACK_PRODUCTS) == 15


def test_supported_protocols_are_2026_bleeding_edge() -> None:
    assert SUPPORTED_PROTOCOLS["erc-8004"] == "v1"
    assert SUPPORTED_PROTOCOLS["x402"] == "v2"
    assert SUPPORTED_PROTOCOLS["a2a"] == "0.3.0"
    assert SUPPORTED_PROTOCOLS["mcp"] == "2025-06-18"
    assert "ap2" in SUPPORTED_PROTOCOLS


async def test_stack_exposes_all_fifteen_product_clients(stack: Stack) -> None:
    pairings = [
        (stack.trust, TrustClient),
        (stack.ref, RefClient),
        (stack.log, LogClient),
        (stack.pay, PayClient),
        (stack.safe, SafeClient),
        (stack.sim, SimClient),
        (stack.hub, HubClient),
        (stack.memory, MemoryClient),
        (stack.id_, IdClient),
        (stack.law, LawClient),
        (stack.market, MarketClient),
        (stack.compute, ComputeClient),
        (stack.edge, EdgeClient),
        (stack.farm, FarmClient),
        (stack.foundry, FoundryClient),
    ]
    assert len(pairings) == 15
    for client, expected_type in pairings:
        assert isinstance(client, expected_type)


async def test_stack_sub_clients_are_cached(stack: Stack) -> None:
    assert stack.trust is stack.trust
    assert stack.pay is stack.pay


async def test_stack_has_no_grid_attribute(stack: Stack) -> None:
    # iAgentGrid is internal infrastructure; never exposed as a product client
    assert not hasattr(stack, "grid")


def test_config_from_env_defaults() -> None:
    with patch.dict(os.environ, {}, clear=True):
        config = Config.from_env()
    assert config.api_key is None
    assert config.hub_base_url == "https://api.hub.ijarvis.ai/v1"
    assert config.x402_autopay is False
    assert config.x402_per_call_cap_usd == 1.00


def test_config_from_env_reads_autopay_flag() -> None:
    with patch.dict(os.environ, {
        "IAGENT_API_KEY": "iah_test",
        "IAGENT_X402_AUTOPAY": "true",
        "IAGENT_X402_PER_CALL_CAP_USD": "0.25",
    }, clear=True):
        config = Config.from_env()
    assert config.api_key == "iah_test"
    assert config.x402_autopay is True
    assert config.x402_per_call_cap_usd == 0.25


def test_config_base_url_for_routes_through_hub_by_default() -> None:
    config = Config(api_key="test", hub_base_url="https://api.hub.ijarvis.ai/v1")
    assert config.base_url_for("trust") == "https://api.hub.ijarvis.ai/v1/trust"
    assert config.base_url_for("pay") == "https://api.hub.ijarvis.ai/v1/pay"


def test_config_base_url_for_falls_back_to_direct_if_no_hub() -> None:
    config = Config(api_key="test", hub_base_url=None)
    assert config.base_url_for("trust").startswith("https://api.iagentfi.com")
    assert config.base_url_for("pay").startswith("https://api.pay.ijarvis.ai")


def test_config_per_product_override_wins_over_hub() -> None:
    config = Config(
        api_key="test",
        hub_base_url="https://api.hub.ijarvis.ai/v1",
        product_base_urls={"trust": "https://custom.example.com/trust"},
    )
    assert config.base_url_for("trust") == "https://custom.example.com/trust"
    # Non-overridden product still routes through hub
    assert config.base_url_for("pay") == "https://api.hub.ijarvis.ai/v1/pay"


def test_payment_required_error_preserves_accepts() -> None:
    err = PaymentRequiredError(
        "payment needed",
        accepts=[{"network": "base-mainnet", "asset": "USDC", "amount": "0.01"}],
        network="base-mainnet",
        amount="0.01",
    )
    assert err.accepts[0]["asset"] == "USDC"
    assert err.network == "base-mainnet"


def test_stack_repr_masks_api_key() -> None:
    stack = Stack(api_key="iah_secret_key_do_not_leak")
    rendered = repr(stack)
    assert "iah_secret_key" not in rendered
    assert "***" in rendered
