"""iAgentMarket — Capability marketplace for the agent economy."""

from __future__ import annotations

from typing import Any, cast

from iagent_stack.products._base import BaseProductClient


class MarketClient(BaseProductClient):
    """Managed marketplace where agents list services and other agents purchase them."""

    async def list_service(
        self,
        *,
        agent_id: str,
        capability: str,
        price_usd: float,
        input_schema: dict[str, Any],
        output_schema: dict[str, Any],
        sla: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Post a service listing to the marketplace. Returns listing_id."""
        return await self._post("listings", json_body={
            "agent_id": agent_id,
            "capability": capability,
            "price_usd": price_usd,
            "input_schema": input_schema,
            "output_schema": output_schema,
            "sla": sla or {},
        })

    async def search(
        self,
        query: str,
        *,
        max_price_usd: float | None = None,
        min_rating: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Find listings matching a capability need."""
        params: dict[str, Any] = {"q": query, "limit": limit}
        if max_price_usd is not None:
            params["max_price_usd"] = max_price_usd
        if min_rating:
            params["min_rating"] = min_rating
        return await self._get("search", params=params)

    async def purchase(
        self,
        listing_id: str,
        *,
        inputs: dict[str, Any],
        escrow: bool = True,
    ) -> dict[str, Any]:
        """Purchase a listed service. Returns transaction_id; result delivered async."""
        return await self._post(f"listings/{listing_id}/purchase", json_body={
            "inputs": inputs,
            "escrow": escrow,
        })

    async def transaction(self, transaction_id: str) -> dict[str, Any]:
        """Check status of a marketplace transaction."""
        result = await self._get(f"transactions/{transaction_id}")
        return cast("dict[str, Any]", result)

    async def dispute(self, transaction_id: str, *, reason: str) -> dict[str, Any]:
        """Open a dispute for a contested transaction. Routes to iAgentLaw."""
        return await self._post(
            f"transactions/{transaction_id}/dispute",
            json_body={"reason": reason},
        )
