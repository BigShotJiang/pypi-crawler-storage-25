"""iAgentSafe — Runtime guardrails for autonomous agents."""

from __future__ import annotations

from typing import Any, Literal, cast

from iagent_stack.products._base import BaseProductClient

Verdict = Literal["allow", "deny", "review"]


class SafeClient(BaseProductClient):
    """Pre-action verification: prompt injection, counterparty risk, behavior anomaly,
    and kill-switch controls for autonomous agents."""

    async def verify(
        self,
        *,
        agent_id: str,
        action_type: str,
        action_payload: dict[str, Any],
        counterparty: str | None = None,
    ) -> dict[str, Any]:
        """
        Pre-check a proposed action. Returns {verdict: allow|deny|review, reasons: [...]}
        """
        return await self._post("verify", json_body={
            "agent_id": agent_id,
            "action_type": action_type,
            "action_payload": action_payload,
            "counterparty": counterparty,
        })

    async def scan_input(self, text: str) -> dict[str, Any]:
        """Scan a user input or retrieved document for prompt-injection signals."""
        result = await self._post("scan", json_body={"text": text})
        return cast("dict[str, Any]", result)

    async def kill(self, agent_id: str, *, reason: str = "operator_halt") -> dict[str, Any]:
        """Emergency stop: halt all activity for an agent."""
        result = await self._post(f"kill/{agent_id}", json_body={"reason": reason})
        return cast("dict[str, Any]", result)

    async def policies(self, agent_id: str) -> list[dict[str, Any]]:
        """List active policies for an agent."""
        result = await self._get(f"policies/{agent_id}")
        return cast("list[dict[str, Any]]", result)
