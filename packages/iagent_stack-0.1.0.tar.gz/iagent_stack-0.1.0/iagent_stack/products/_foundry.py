"""iAgentFoundry — Custom model fine-tuning on iJarvis hardware."""

from __future__ import annotations

from typing import Any, Literal, cast

from iagent_stack.products._base import BaseProductClient

Method = Literal["full", "lora", "qlora", "dpo", "orpo"]


class FoundryClient(BaseProductClient):
    """Fine-tune models up to 70B parameters on iJarvis DGX Spark pair + RTX 6000 Pro."""

    async def base_models(self) -> list[dict[str, Any]]:
        """List available base models that can be fine-tuned."""
        result = await self._get("base-models")
        return cast("list[dict[str, Any]]", result)

    async def upload_dataset(
        self,
        *,
        name: str,
        data_format: str,
        size_bytes: int,
        content_sha256: str,
    ) -> dict[str, Any]:
        """
        Register a training dataset. Returns an upload URL for the actual bytes.
        Data stays on iJarvis infrastructure.
        """
        return await self._post("datasets", json_body={
            "name": name,
            "format": data_format,
            "size_bytes": size_bytes,
            "content_sha256": content_sha256,
        })

    async def create_job(
        self,
        *,
        base_model: str,
        dataset_id: str,
        method: Method = "lora",
        hyperparameters: dict[str, Any] | None = None,
        output_name: str,
    ) -> dict[str, Any]:
        """Submit a fine-tuning job. Returns job_id and estimated cost."""
        return await self._post("jobs", json_body={
            "base_model": base_model,
            "dataset_id": dataset_id,
            "method": method,
            "hyperparameters": hyperparameters or {},
            "output_name": output_name,
        })

    async def job(self, job_id: str) -> dict[str, Any]:
        """Get current status of a fine-tuning job."""
        result = await self._get(f"jobs/{job_id}")
        return cast("dict[str, Any]", result)

    async def cancel_job(self, job_id: str) -> dict[str, Any]:
        """Cancel a running job. Partial cost may apply."""
        result = await self._post(f"jobs/{job_id}/cancel")
        return cast("dict[str, Any]", result)

    async def deploy(self, model_id: str, *, host_via_compute: bool = True) -> dict[str, Any]:
        """
        Deploy a fine-tuned model. When `host_via_compute=True` the model is
        served via iJarvis Compute at agent-economy pricing.
        """
        return await self._post(f"models/{model_id}/deploy", json_body={
            "host_via_compute": host_via_compute,
        })
