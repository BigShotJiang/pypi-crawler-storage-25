"""iAgentRef — Agent discovery and capability search."""

from __future__ import annotations

from typing import Any, cast

from iagent_stack.products._base import BaseProductClient


class RefClient(BaseProductClient):
    """Semantic search over every ERC-8004 registered agent across supported chains."""

    async def search(
        self,
        query: str,
        *,
        limit: int = 20,
        min_rating: str | None = None,
        max_price_usd: float | None = None,
        chains: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Search agent capabilities in natural language.

        >>> await stack.ref.search("agents that do onchain research", min_rating="BBB")
        """
        params: dict[str, Any] = {"q": query, "limit": limit}
        if min_rating:
            params["min_rating"] = min_rating
        if max_price_usd is not None:
            params["max_price_usd"] = max_price_usd
        if chains:
            params["chains"] = ",".join(chains)
        return await self._get("search", params=params)

    async def get_agent(self, agent_id: str) -> dict[str, Any]:
        """Resolve a specific agent-id (ERC-8004 or DID) to full agent-card."""
        result = await self._get(f"agents/{agent_id}")
        return cast("dict[str, Any]", result)

    async def register(self, agent_card_url: str) -> dict[str, Any]:
        """Submit an agent card URL for indexing. Returns queue position."""
        result = await self._post("register", json_body={"agent_card_url": agent_card_url})
        return cast("dict[str, Any]", result)
