"""iAgentPay — x402 V2 treasury and payments for autonomous agents."""

from __future__ import annotations

from typing import Any, Literal, cast

from iagent_stack.products._base import BaseProductClient

Network = Literal["base-mainnet", "solana-mainnet", "ethereum-mainnet"]


class PayClient(BaseProductClient):
    """
    Treasury controls on top of x402 V2: budgets, caps, counterparty checks,
    anomaly detection, multi-chain routing. Every payment is pre-checked
    against iAgentFi trust ratings and iAgentSafe policies.
    """

    async def send(
        self,
        *,
        to: str,
        amount_usd: float,
        network: Network = "base-mainnet",
        asset: str = "USDC",
        memo: str | None = None,
        require_min_rating: str | None = "B",
        allow_override: bool = False,
    ) -> dict[str, Any]:
        """
        Execute a payment from the agent's treasury.

        Automatically blocks if the counterparty rating is below `require_min_rating`
        unless `allow_override=True`.
        """
        return await self._post("payments", json_body={
            "to": to,
            "amount_usd": amount_usd,
            "network": network,
            "asset": asset,
            "memo": memo,
            "require_min_rating": require_min_rating,
            "allow_override": allow_override,
        })

    async def budget(self, agent_id: str) -> dict[str, Any]:
        """Current budget state for an agent (daily, weekly, monthly, per-counterparty)."""
        result = await self._get(f"budgets/{agent_id}")
        return cast("dict[str, Any]", result)

    async def set_budget(
        self,
        agent_id: str,
        *,
        daily_usd: float | None = None,
        weekly_usd: float | None = None,
        monthly_usd: float | None = None,
        per_counterparty_usd: float | None = None,
    ) -> dict[str, Any]:
        """Update budget caps for an agent."""
        body = {
            k: v for k, v in {
                "daily_usd": daily_usd,
                "weekly_usd": weekly_usd,
                "monthly_usd": monthly_usd,
                "per_counterparty_usd": per_counterparty_usd,
            }.items() if v is not None
        }
        result = await self._post(f"budgets/{agent_id}", json_body=body)
        return cast("dict[str, Any]", result)

    async def treasury(self) -> dict[str, Any]:
        """Summary of treasury balances across all chains and assets."""
        result = await self._get("treasury")
        return cast("dict[str, Any]", result)
