"""iAgentLog — Agent-native observability."""

from __future__ import annotations

from datetime import datetime
from typing import Any, cast

from iagent_stack.products._base import BaseProductClient


class LogClient(BaseProductClient):
    """
    Capture and query agent decisions (counterparty selection, tool choice,
    rejection reasons, fallback paths), not just raw LLM calls.
    """

    async def log_decision(
        self,
        *,
        agent_id: str,
        decision_type: str,
        inputs: dict[str, Any],
        outputs: dict[str, Any],
        counterparty: str | None = None,
        cost_usd: float | None = None,
        parent_decision_id: str | None = None,
    ) -> dict[str, Any]:
        """Record a single agent decision. Returns the assigned decision_id."""
        return await self._post("decisions", json_body={
            "agent_id": agent_id,
            "decision_type": decision_type,
            "inputs": inputs,
            "outputs": outputs,
            "counterparty": counterparty,
            "cost_usd": cost_usd,
            "parent_decision_id": parent_decision_id,
        })

    async def traces(
        self,
        agent_id: str,
        *,
        since: datetime | None = None,
        until: datetime | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Return decision traces for an agent in reverse chronological order."""
        params: dict[str, Any] = {"agent_id": agent_id, "limit": limit}
        if since:
            params["since"] = since.isoformat()
        if until:
            params["until"] = until.isoformat()
        return await self._get("traces", params=params)

    async def anomalies(self, agent_id: str, *, window_hours: int = 24) -> list[dict[str, Any]]:
        """Return any behavioral anomalies detected against the agent's baseline."""
        result = await self._get(f"anomalies/{agent_id}", params={"window_hours": window_hours})
        return cast("list[dict[str, Any]]", result)
