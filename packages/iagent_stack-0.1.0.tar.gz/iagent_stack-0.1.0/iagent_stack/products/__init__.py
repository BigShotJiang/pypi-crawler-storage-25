"""
Product sub-clients for each member of the iJarvis Agent Stack.

iAgentGrid is intentionally NOT exposed. It is private compute infrastructure
that runs behind every other product; it has no public API surface.
"""

from iagent_stack.products._base import BaseProductClient
from iagent_stack.products._compute import ComputeClient
from iagent_stack.products._edge import EdgeClient
from iagent_stack.products._farm import FarmClient
from iagent_stack.products._foundry import FoundryClient
from iagent_stack.products._hub import HubClient
from iagent_stack.products._id import IdClient
from iagent_stack.products._law import LawClient
from iagent_stack.products._log import LogClient
from iagent_stack.products._market import MarketClient
from iagent_stack.products._memory import MemoryClient
from iagent_stack.products._pay import PayClient
from iagent_stack.products._ref import RefClient
from iagent_stack.products._safe import SafeClient
from iagent_stack.products._sim import SimClient
from iagent_stack.products._trust import TrustClient

__all__ = [
    "BaseProductClient",
    "TrustClient",
    "RefClient",
    "LogClient",
    "PayClient",
    "SafeClient",
    "SimClient",
    "HubClient",
    "MemoryClient",
    "IdClient",
    "LawClient",
    "MarketClient",
    "ComputeClient",
    "EdgeClient",
    "FarmClient",
    "FoundryClient",
]
