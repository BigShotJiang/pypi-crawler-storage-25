"""iAgentFi — Trust and ratings bureau for the agent economy."""

from __future__ import annotations

from typing import Any, Literal, cast

from iagent_stack.products._base import BaseProductClient

Chain = Literal["base", "ethereum", "avalanche", "bnb", "solana"]


class TrustClient(BaseProductClient):
    """
    iAgentFi rating bureau client.

    Fetches institutional-style trust ratings for agents, operators, and
    agent frameworks. Ratings follow the iAgentFi methodology (CC BY 4.0,
    published at github.com/iAgentFi/methodology).
    """

    async def rating(self, chain: Chain, address: str) -> dict[str, Any]:
        """Get the current rating for an agent or operator address."""
        result = await self._get(f"ratings/{chain}/{address}")
        return cast("dict[str, Any]", result)

    async def history(self, chain: Chain, address: str, *, limit: int = 50) -> list[dict[str, Any]]:
        """Rating history for an agent. Newest first."""
        result = await self._get(f"ratings/{chain}/{address}/history", params={"limit": limit})
        return cast("list[dict[str, Any]]", result)

    async def methodology(self, version: str = "latest") -> dict[str, Any]:
        """Return the current methodology document metadata."""
        result = await self._get(f"methodology/{version}")
        return cast("dict[str, Any]", result)

    async def batch_rate(self, refs: list[dict[str, str]]) -> list[dict[str, Any]]:
        """Rate many agents at once. Input: [{chain, address}, ...]."""
        result = await self._post("ratings/batch", json_body={"refs": refs})
        return cast("list[dict[str, Any]]", result)
