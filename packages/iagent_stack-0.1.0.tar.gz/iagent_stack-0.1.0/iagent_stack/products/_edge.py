"""iAgentEdge — Turnkey on-prem agent infrastructure appliance."""

from __future__ import annotations

from typing import Any, cast

from iagent_stack.products._base import BaseProductClient


class EdgeClient(BaseProductClient):
    """
    Remote-management API for iAgentEdge appliances deployed at customer sites.
    Appliance runs the full iJarvis Agent Stack privately on customer hardware.
    """

    async def appliances(self) -> list[dict[str, Any]]:
        """List all appliances registered to this operator."""
        result = await self._get("appliances")
        return cast("list[dict[str, Any]]", result)

    async def appliance(self, appliance_id: str) -> dict[str, Any]:
        """Get detailed status for a specific appliance."""
        result = await self._get(f"appliances/{appliance_id}")
        return cast("dict[str, Any]", result)

    async def update(
        self,
        appliance_id: str,
        *,
        target_version: str | None = None,
        schedule: str = "next_maintenance_window",
    ) -> dict[str, Any]:
        """Schedule a stack update on the appliance."""
        return await self._post(f"appliances/{appliance_id}/update", json_body={
            "target_version": target_version,
            "schedule": schedule,
        })

    async def audit_log(
        self,
        appliance_id: str,
        *,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get audit log entries for appliance access and operations."""
        result = await self._get(f"appliances/{appliance_id}/audit", params={"limit": limit})
        return cast("list[dict[str, Any]]", result)

    async def bom(self, tier: str = "mid") -> dict[str, Any]:
        """
        Get the reference hardware bill of materials for a given tier.

        Tiers: "dev" (~$25K), "mid" (~$75K), "enterprise" (~$250K)
        """
        result = await self._get(f"bom/{tier}")
        return cast("dict[str, Any]", result)
