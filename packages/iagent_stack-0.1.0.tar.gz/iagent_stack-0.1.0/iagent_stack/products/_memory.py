"""iAgentMemory — Persistent memory infrastructure."""

from __future__ import annotations

from typing import Any, Literal, cast

from iagent_stack.products._base import BaseProductClient

Layer = Literal["episodic", "semantic", "relationship"]


class MemoryClient(BaseProductClient):
    """Portable, framework-agnostic memory for agents."""

    async def remember(
        self,
        *,
        agent_id: str,
        layer: Layer,
        content: dict[str, Any],
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """Store a memory. Returns the assigned memory_id."""
        return await self._post("memories", json_body={
            "agent_id": agent_id,
            "layer": layer,
            "content": content,
            "tags": tags or [],
        })

    async def recall(
        self,
        *,
        agent_id: str,
        query: str,
        layer: Layer | None = None,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """Retrieve relevant memories by semantic query."""
        params: dict[str, Any] = {"agent_id": agent_id, "query": query, "limit": limit}
        if layer:
            params["layer"] = layer
        return await self._get("recall", params=params)

    async def forget(self, memory_id: str) -> dict[str, Any]:
        """Delete a specific memory."""
        result = await self._delete(f"memories/{memory_id}")
        return cast("dict[str, Any]", result)

    async def export(self, agent_id: str) -> dict[str, Any]:
        """Export all memories for an agent. Portable JSON format."""
        result = await self._get(f"export/{agent_id}")
        return cast("dict[str, Any]", result)
