"""iAgentSim — Adversarial simulation."""

from __future__ import annotations

from typing import Any, cast

from iagent_stack.products._base import BaseProductClient


class SimClient(BaseProductClient):
    """Sandbox environment for testing agent behavior under adversarial conditions."""

    async def scenarios(self) -> list[dict[str, Any]]:
        """List available pre-built test scenarios."""
        result = await self._get("scenarios")
        return cast("list[dict[str, Any]]", result)

    async def run(
        self,
        *,
        agent_endpoint: str,
        scenario_ids: list[str],
        wallet_cap_usd: float = 10.0,
    ) -> dict[str, Any]:
        """Kick off a simulation. Returns a run_id for status tracking."""
        return await self._post("runs", json_body={
            "agent_endpoint": agent_endpoint,
            "scenario_ids": scenario_ids,
            "wallet_cap_usd": wallet_cap_usd,
        })

    async def result(self, run_id: str) -> dict[str, Any]:
        """Fetch the result report for a simulation run."""
        result = await self._get(f"runs/{run_id}")
        return cast("dict[str, Any]", result)
