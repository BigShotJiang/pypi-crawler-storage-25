"""iJarvis Compute — Boutique dedicated inference on iJarvis hardware."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any, cast

from iagent_stack.products._base import BaseProductClient


class ComputeClient(BaseProductClient):
    """
    Agent-accessible inference on dedicated iJarvis hardware. OpenAI-compatible
    chat.completions interface with x402 V2 per-request settlement.
    """

    async def models(self) -> list[dict[str, Any]]:
        """List available models and their current unit pricing."""
        result = await self._get("models")
        return cast("list[dict[str, Any]]", result)

    async def chat(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        temperature: float = 0.7,
        max_tokens: int | None = None,
        top_p: float = 1.0,
        stream: bool = False,
        extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Run a chat completion. Compatible with OpenAI's chat.completions surface.

        Streaming is supported via `stream_chat()`.
        """
        body: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "top_p": top_p,
            "stream": False,
        }
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if extra:
            body.update(extra)
        result = await self._post("chat/completions", json_body=body)
        return cast("dict[str, Any]", result)

    async def stream_chat(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        temperature: float = 0.7,
        max_tokens: int | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream a chat completion. Yields SSE event dicts as they arrive.

        Note: streaming requires direct access to the underlying httpx client.
        Stubbed here; full implementation lives in iagent_stack.contrib.streaming.
        """
        raise NotImplementedError(
            "Streaming requires iagent_stack.contrib.streaming. "
            "Use `await stack.compute.chat(..., stream=False)` for non-streaming."
        )

    async def embeddings(
        self,
        *,
        model: str,
        texts: str | list[str],
    ) -> dict[str, Any]:
        """Generate embeddings. OpenAI-compatible embeddings interface."""
        return await self._post("embeddings", json_body={
            "model": model,
            "input": texts,
        })
