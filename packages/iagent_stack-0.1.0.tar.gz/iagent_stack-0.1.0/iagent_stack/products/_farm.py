"""iAgentFarm — Persistent agent hosting on iJarvis hardware."""

from __future__ import annotations

from typing import Any, Literal, cast

from iagent_stack.products._base import BaseProductClient

Tier = Literal["starter", "pro", "dedicated", "enterprise"]


class FarmClient(BaseProductClient):
    """Host long-running autonomous agents 24/7 on dedicated or shared iJarvis hardware."""

    async def deploy(
        self,
        *,
        name: str,
        image: str,
        tier: Tier = "starter",
        environment: dict[str, str] | None = None,
        framework: str | None = None,
        entrypoint: str | None = None,
    ) -> dict[str, Any]:
        """
        Deploy a new agent. Returns agent_id and endpoint URL.

        `image` is a container image reference. `framework` is optional
        hint ("langgraph", "crewai", "autogen", "custom") for default wiring.
        """
        return await self._post("deployments", json_body={
            "name": name,
            "image": image,
            "tier": tier,
            "environment": environment or {},
            "framework": framework,
            "entrypoint": entrypoint,
        })

    async def list_agents(self) -> list[dict[str, Any]]:
        """List all deployed agents for this operator."""
        result = await self._get("deployments")
        return cast("list[dict[str, Any]]", result)

    async def get_agent(self, agent_id: str) -> dict[str, Any]:
        """Get deployment status and recent activity for a hosted agent."""
        result = await self._get(f"deployments/{agent_id}")
        return cast("dict[str, Any]", result)

    async def restart(self, agent_id: str) -> dict[str, Any]:
        """Restart a hosted agent."""
        result = await self._post(f"deployments/{agent_id}/restart")
        return cast("dict[str, Any]", result)

    async def stop(self, agent_id: str) -> dict[str, Any]:
        """Stop a hosted agent. Does not delete. Use `delete()` to remove."""
        result = await self._post(f"deployments/{agent_id}/stop")
        return cast("dict[str, Any]", result)

    async def delete(self, agent_id: str) -> dict[str, Any]:
        """Permanently delete a hosted agent and its storage."""
        result = await self._delete(f"deployments/{agent_id}")
        return cast("dict[str, Any]", result)

    async def logs(
        self,
        agent_id: str,
        *,
        limit: int = 200,
        since_seconds: int | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch recent log lines from a hosted agent's container."""
        params: dict[str, Any] = {"limit": limit}
        if since_seconds:
            params["since_seconds"] = since_seconds
        result = await self._get(f"deployments/{agent_id}/logs", params=params)
        return cast("list[dict[str, Any]]", result)
