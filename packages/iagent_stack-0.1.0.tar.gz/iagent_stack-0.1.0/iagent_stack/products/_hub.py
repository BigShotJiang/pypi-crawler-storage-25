"""iAgentHub — The iJarvis Agent Stack gateway. Unified auth, billing, metadata."""

from __future__ import annotations

from typing import Any, cast

from iagent_stack.products._base import BaseProductClient


class HubClient(BaseProductClient):
    """Meta-client for Stack-wide operations: usage, billing, api-key management."""

    async def usage(self, *, month: str | None = None) -> dict[str, Any]:
        """Per-product usage for the current or specified month (YYYY-MM)."""
        params = {"month": month} if month else None
        result = await self._get("usage", params=params)
        return cast("dict[str, Any]", result)

    async def invoice(self, month: str) -> dict[str, Any]:
        """Generated invoice for a specific month."""
        result = await self._get(f"invoices/{month}")
        return cast("dict[str, Any]", result)

    async def rotate_key(self) -> dict[str, Any]:
        """Rotate the current API key. Old key valid for 24h grace period."""
        result = await self._post("keys/rotate")
        return cast("dict[str, Any]", result)
