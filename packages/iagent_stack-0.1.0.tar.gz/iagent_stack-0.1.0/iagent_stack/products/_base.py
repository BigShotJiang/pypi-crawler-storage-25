"""Base class shared by all product sub-clients."""

from __future__ import annotations

from typing import Any, cast

from iagent_stack._transport import Transport


class BaseProductClient:
    """
    Shared base for product sub-clients. Every product gets the same
    `_get`, `_post`, `_delete` helpers routed through the Stack's Transport.
    """

    def __init__(self, transport: Transport, *, product: str) -> None:
        self._transport = transport
        self._product = product

    async def _get(self, path: str, *, params: dict[str, Any] | None = None) -> Any:
        return await self._transport.request("GET", self._product, path, params=params)

    async def _post(self, path: str, *, json_body: Any = None) -> Any:
        return await self._transport.request("POST", self._product, path, json_body=json_body)

    async def _delete(self, path: str) -> Any:
        return await self._transport.request("DELETE", self._product, path)

    async def status(self) -> dict[str, Any]:
        """Service health check. All products implement `GET /status`."""
        result = await self._get("status")
        return cast(dict[str, Any], result)

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} product={self._product!r}>"
