"""iAgentLaw — Legal and liability infrastructure."""

from __future__ import annotations

from typing import Any, cast

from iagent_stack.products._base import BaseProductClient


class LawClient(BaseProductClient):
    """Terms templates, action risk scoring, insurance brokerage, dispute arbitration."""

    async def risk_score(
        self,
        *,
        proposed_action: str,
        jurisdiction: str,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Score the legal risk of a proposed action in a given jurisdiction."""
        return await self._post("risk-score", json_body={
            "proposed_action": proposed_action,
            "jurisdiction": jurisdiction,
            "context": context or {},
        })

    async def terms_template(self, template_id: str, *, jurisdiction: str) -> dict[str, Any]:
        """Fetch a templated agreement (operator ToS, A2A transaction terms, etc.)."""
        result = await self._get(f"templates/{template_id}", params={"jurisdiction": jurisdiction})
        return cast("dict[str, Any]", result)

    async def insurance_quote(
        self,
        *,
        operator: str,
        coverage_types: list[str],
        annual_revenue_usd: float,
    ) -> dict[str, Any]:
        """Get an insurance quote from partner underwriters."""
        return await self._post("insurance/quote", json_body={
            "operator": operator,
            "coverage_types": coverage_types,
            "annual_revenue_usd": annual_revenue_usd,
        })

    async def file_incident(
        self,
        *,
        incident_type: str,
        log_decision_ids: list[str],
        narrative: str,
    ) -> dict[str, Any]:
        """File an incident for arbitration. Links to iAgentLog decisions."""
        return await self._post("incidents", json_body={
            "incident_type": incident_type,
            "log_decision_ids": log_decision_ids,
            "narrative": narrative,
        })
