"""iAgentID — Verifiable credentials for autonomous agents."""

from __future__ import annotations

from typing import Any, cast

from iagent_stack.products._base import BaseProductClient


class IdClient(BaseProductClient):
    """W3C Verifiable Credential issuance, verification, and revocation."""

    async def issue(
        self,
        *,
        subject: str,
        credential_type: str,
        claims: dict[str, Any],
        expiration: str | None = None,
    ) -> dict[str, Any]:
        """Mint a signed credential. Returns the full VC JWT."""
        return await self._post("issue", json_body={
            "subject": subject,
            "credential_type": credential_type,
            "claims": claims,
            "expiration": expiration,
        })

    async def verify(self, credential: str) -> dict[str, Any]:
        """Verify a credential. Returns {valid: bool, reasons: [...]}. Cached 60s."""
        result = await self._post("verify", json_body={"credential": credential})
        return cast("dict[str, Any]", result)

    async def revoke(self, credential_id: str, *, reason: str) -> dict[str, Any]:
        """Revoke a previously issued credential. Propagates to caches within 30s."""
        result = await self._post(f"revoke/{credential_id}", json_body={"reason": reason})
        return cast("dict[str, Any]", result)

    async def resolve_did(self, did: str) -> dict[str, Any]:
        """Resolve a DID to its current DID document."""
        result = await self._get(f"did/{did}")
        return cast("dict[str, Any]", result)
