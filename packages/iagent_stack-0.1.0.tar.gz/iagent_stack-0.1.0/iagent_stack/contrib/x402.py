"""
x402 V2 payment signing.

Produces the `X-Payment` header value required to redeem an x402 402 challenge.
Requires iagent-stack[x402] extra (web3, eth-account for EVM; solana for Solana).

Usage is automatic when Config.x402_autopay=True is set on the Stack. Manual
construction is exposed here for custom flows and testing.
"""

from __future__ import annotations

import base64
import json
import time
from typing import Any


async def sign_payment(
    *,
    accepts_entry: dict[str, Any],
    private_key: str,
) -> str:
    """
    Produce an x402 V2 X-Payment header value for a single accepts entry.

    Returns a base64-encoded JSON payload with the signed authorization.
    Raises ImportError if the required chain dependency is not installed.

    Parameters
    ----------
    accepts_entry:
        One element from the `accepts` array of an x402 V2 402 response.
        Must contain `network`, `asset`, and amount.
    private_key:
        Hex-encoded private key string. For EVM chains: 0x-prefixed 32-byte key.
        For Solana: base58 or base64 private key.
    """
    network = accepts_entry.get("network", "")
    if network.startswith("base") or network.startswith("ethereum"):
        return await _sign_evm_payment(accepts_entry, private_key)
    if network.startswith("solana"):
        return await _sign_solana_payment(accepts_entry, private_key)
    raise ValueError(f"x402: unsupported network {network!r}")


async def _sign_evm_payment(entry: dict[str, Any], private_key: str) -> str:
    try:
        from eth_account import Account
        from eth_account.messages import encode_typed_data
    except ImportError as exc:
        raise ImportError(
            "iagent-stack[x402] not installed. "
            "Run `pip install iagent-stack[x402]` to enable x402 autopay."
        ) from exc

    pay_to = entry["pay_to"]
    amount = str(entry.get("amount") or entry.get("price") or "0")
    asset = entry.get("asset", "USDC")
    nonce = int(time.time() * 1000)
    deadline = nonce + 60_000

    typed_data = {
        "domain": {
            "name": "x402",
            "version": "2",
            "chainId": _chain_id_for(entry["network"]),
        },
        "primaryType": "PaymentAuthorization",
        "message": {
            "payTo": pay_to,
            "amount": amount,
            "asset": asset,
            "nonce": nonce,
            "deadline": deadline,
        },
        "types": {
            "EIP712Domain": [
                {"name": "name", "type": "string"},
                {"name": "version", "type": "string"},
                {"name": "chainId", "type": "uint256"},
            ],
            "PaymentAuthorization": [
                {"name": "payTo", "type": "address"},
                {"name": "amount", "type": "string"},
                {"name": "asset", "type": "string"},
                {"name": "nonce", "type": "uint256"},
                {"name": "deadline", "type": "uint256"},
            ],
        },
    }

    account = Account.from_key(private_key)
    signed = account.sign_message(encode_typed_data(full_message=typed_data))

    payload = {
        "version": "v2",
        "scheme": entry.get("scheme", "exact"),
        "network": entry["network"],
        "authorization": typed_data["message"],
        "signature": signed.signature.hex(),
        "signer": account.address,
    }
    return base64.b64encode(json.dumps(payload).encode()).decode()


async def _sign_solana_payment(entry: dict[str, Any], private_key: str) -> str:
    try:
        from solders.keypair import Keypair
    except ImportError as exc:
        raise ImportError(
            "iagent-stack[x402] not installed. "
            "Run `pip install iagent-stack[x402]` to enable x402 autopay."
        ) from exc

    keypair = Keypair.from_base58_string(private_key)
    pay_to = entry["pay_to"]
    amount = str(entry.get("amount") or entry.get("price") or "0")
    nonce = int(time.time() * 1000)

    message_bytes = f"x402:v2:{pay_to}:{amount}:{nonce}".encode()
    signature = keypair.sign_message(message_bytes)

    payload = {
        "version": "v2",
        "scheme": entry.get("scheme", "exact"),
        "network": entry["network"],
        "authorization": {
            "payTo": pay_to,
            "amount": amount,
            "asset": entry.get("asset", "USDC"),
            "nonce": nonce,
        },
        "signature": str(signature),
        "signer": str(keypair.pubkey()),
    }
    return base64.b64encode(json.dumps(payload).encode()).decode()


def _chain_id_for(network: str) -> int:
    mapping = {
        "base-mainnet": 8453,
        "base-sepolia": 84532,
        "ethereum-mainnet": 1,
        "ethereum-sepolia": 11155111,
    }
    if network in mapping:
        return mapping[network]
    raise ValueError(f"Unknown EVM network: {network}")
