"""
Optional contrib modules for iagent-stack.

These require extra dependencies installed via optional extras:
    pip install iagent-stack[x402]  # web3, eth-account, solana
    pip install iagent-stack[mcp]   # anthropic mcp SDK

Core iagent-stack works without any of these. Contrib adds capabilities:
- contrib.x402 : sign x402 V2 payment payloads for autopay
- contrib.streaming : SSE streaming for iJarvis Compute chat completions
"""
