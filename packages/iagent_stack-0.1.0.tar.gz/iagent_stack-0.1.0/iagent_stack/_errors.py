"""Exception hierarchy for iagent-stack."""

from __future__ import annotations

from typing import Any


class IAgentStackError(Exception):
    """Base exception for all iagent-stack errors."""

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        product: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.product = product


class AuthenticationError(IAgentStackError):
    """API key missing, invalid, revoked, or expired."""


class PaymentRequiredError(IAgentStackError):
    """HTTP 402 returned without autopay configured, or payment failed."""

    def __init__(
        self,
        message: str,
        *,
        accepts: list[dict[str, Any]] | None = None,
        network: str | None = None,
        amount: str | None = None,
        status: int | None = None,
        product: str | None = None,
    ) -> None:
        super().__init__(message, status=status, product=product)
        self.accepts = accepts or []
        self.network = network
        self.amount = amount


class RateLimitError(IAgentStackError):
    """HTTP 429. Retry after `retry_after` seconds."""

    def __init__(
        self,
        message: str,
        *,
        retry_after: float | None = None,
        status: int | None = None,
        product: str | None = None,
    ) -> None:
        super().__init__(message, status=status, product=product)
        self.retry_after = retry_after


class ProductNotAvailableError(IAgentStackError):
    """Product endpoint is offline, unreachable, or not yet launched."""


class UpstreamError(IAgentStackError):
    """Underlying product returned an unexpected error. Includes raw payload."""

    def __init__(
        self,
        message: str,
        *,
        body: Any = None,
        status: int | None = None,
        product: str | None = None,
    ) -> None:
        super().__init__(message, status=status, product=product)
        self.body = body
