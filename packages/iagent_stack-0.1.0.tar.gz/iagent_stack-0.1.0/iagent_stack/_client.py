"""
Stack — the top-level client for the iJarvis Agent Stack SDK.

Exposes all 16 products as attributes. Each sub-client is lazy: created on
first access, reuses the Stack's shared Transport.
"""

from __future__ import annotations

from typing import Any, TypeVar

from iagent_stack._config import Config
from iagent_stack._errors import ProductNotAvailableError
from iagent_stack._transport import Transport
from iagent_stack.products import (
    BaseProductClient,
    ComputeClient,
    EdgeClient,
    FarmClient,
    FoundryClient,
    HubClient,
    IdClient,
    LawClient,
    LogClient,
    MarketClient,
    MemoryClient,
    PayClient,
    RefClient,
    SafeClient,
    SimClient,
    TrustClient,
)

T = TypeVar("T", bound=BaseProductClient)


class Stack:
    """
    Top-level client for every product in the iJarvis Agent Stack.

    >>> from iagent_stack import Stack
    >>> stack = Stack()                             # picks up IAGENT_API_KEY from env
    >>> stack = Stack(api_key="iah_live_...")       # explicit
    >>> stack = Stack(config=Config(...))           # full control

    Products (attribute → product):
        stack.trust    → iAgentFi          (ratings & trust)
        stack.ref      → iAgentRef              (agent discovery)
        stack.log      → iAgentLog         (observability)
        stack.pay      → iAgentPay         (x402 treasury)
        stack.safe     → iAgentSafe        (runtime guardrails)
        stack.sim      → iAgentSim         (adversarial simulation)
        stack.hub      → iAgentHub         (gateway metadata / billing)
        stack.memory   → iAgentMemory      (persistent memory)
        stack.id_      → iAgentID          (verifiable credentials)
        stack.law      → iAgentLaw         (legal & liability)
        stack.market   → iAgentMarket      (capability marketplace)
        stack.compute  → iJarvis Compute   (rentable inference)
        stack.edge     → iAgentEdge        (on-prem appliance)
        stack.farm     → iAgentFarm        (agent hosting)
        stack.foundry  → iAgentFoundry     (fine-tuning)

    iAgentGrid is not exposed as a client. It is the internal compute fabric
    that runs behind every product; it has no public API surface by design.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        config: Config | None = None,
        **config_overrides: Any,
    ) -> None:
        if config is None:
            config = Config.from_env()
        if api_key is not None:
            config = _replace(config, api_key=api_key)
        if config_overrides:
            config = _replace(config, **config_overrides)

        self._config = config
        self._transport = Transport(config)

        # Lazy sub-clients
        self._subclients: dict[str, Any] = {}

    # --- Product accessors ---------------------------------------------------

    @property
    def trust(self) -> TrustClient:
        return self._get("trust", TrustClient)

    @property
    def ref(self) -> RefClient:
        return self._get("ref", RefClient)

    @property
    def log(self) -> LogClient:
        return self._get("log", LogClient)

    @property
    def pay(self) -> PayClient:
        return self._get("pay", PayClient)

    @property
    def safe(self) -> SafeClient:
        return self._get("safe", SafeClient)

    @property
    def sim(self) -> SimClient:
        return self._get("sim", SimClient)

    @property
    def hub(self) -> HubClient:
        return self._get("hub", HubClient)

    @property
    def memory(self) -> MemoryClient:
        return self._get("memory", MemoryClient)

    # `id` shadows Python's builtin, so we expose as `id_`.
    @property
    def id_(self) -> IdClient:
        return self._get("id_", IdClient)

    @property
    def law(self) -> LawClient:
        return self._get("law", LawClient)

    @property
    def market(self) -> MarketClient:
        return self._get("market", MarketClient)

    @property
    def compute(self) -> ComputeClient:
        return self._get("compute", ComputeClient)

    @property
    def edge(self) -> EdgeClient:
        return self._get("edge", EdgeClient)

    @property
    def farm(self) -> FarmClient:
        return self._get("farm", FarmClient)

    @property
    def foundry(self) -> FoundryClient:
        return self._get("foundry", FoundryClient)

    # --- Lifecycle ----------------------------------------------------------

    async def close(self) -> None:
        """Close the shared HTTP transport. Call on shutdown."""
        await self._transport.close()

    async def __aenter__(self) -> Stack:
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # --- Health / introspection ---------------------------------------------

    async def health(self) -> dict[str, bool]:
        """
        Ping every configured product. Returns a dict of product → healthy bool.
        Useful for status pages and CI smoke tests.
        """
        products = [
            "trust", "ref", "log", "pay", "safe", "sim", "hub",
            "memory", "id_", "law", "market",
            "compute", "edge", "farm", "foundry",
        ]
        results: dict[str, bool] = {}
        for name in products:
            try:
                await self._transport.request("GET", name, "status")
                results[name] = True
            except ProductNotAvailableError:
                results[name] = False
            except Exception:
                results[name] = False
        return results

    def __repr__(self) -> str:
        masked = "***" if self._config.api_key else "unset"
        return f"Stack(api_key={masked}, hub={self._config.hub_base_url!r})"

    # --- Internal -----------------------------------------------------------

    def _get(self, name: str, cls: type[T]) -> T:
        if name not in self._subclients:
            self._subclients[name] = cls(self._transport, product=name)
        client = self._subclients[name]
        assert isinstance(client, cls)
        return client


def _replace(config: Config, **overrides: Any) -> Config:
    """Return a new Config with the given fields replaced."""
    import dataclasses
    return dataclasses.replace(config, **overrides)
