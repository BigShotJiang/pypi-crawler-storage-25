"""Configuration for the iagent-stack SDK."""

from __future__ import annotations

import os
from dataclasses import dataclass, field

DEFAULT_BASE_URLS: dict[str, str] = {
    # Software Stack (7)
    "trust":   "https://api.iagentfi.com/v2",
    "ref":     "https://api.iref.ai/v1",
    "log":     "https://api.iagentlog.com/v1",
    "pay":     "https://api.pay.ijarvis.ai/v1",
    "safe":    "https://api.iagentsafe.com/v1",
    "sim":     "https://api.iagentsim.com/v1",
    "hub":     "https://api.hub.ijarvis.ai/v1",
    # Trust Substrate (4)
    "memory":  "https://api.iagentmemory.com/v1",
    "id_":     "https://api.iagentid.com/v1",
    "law":     "https://api.iagentlaw.com/v1",
    "market":  "https://api.iagentmarket.com/v1",
    # Hardware Moat (5; grid is internal-only)
    "compute": "https://api.compute.ijarvis.ai/v1",
    "edge":    "https://api.iagentedge.com/v1",
    "farm":    "https://api.iagentfarm.com/v1",
    "foundry": "https://api.iagentfoundry.com/v1",
}


@dataclass(frozen=True)
class Config:
    """
    SDK configuration. Most users can call `Stack()` with no args and pick
    up `IAGENT_API_KEY` from env. Use `Config` directly for custom endpoints,
    proxy configs, or per-environment overrides.
    """

    api_key: str | None = None
    # Base URL for the unified iAgentHub gateway. If set, all product traffic
    # routes through this (single integration point, single billing). If None,
    # each product hits its own domain using DEFAULT_BASE_URLS.
    hub_base_url: str | None = "https://api.hub.ijarvis.ai/v1"
    # Per-product override URLs. Keys must be in DEFAULT_BASE_URLS.
    product_base_urls: dict[str, str] = field(default_factory=dict)
    # HTTP timeouts (seconds)
    connect_timeout: float = 10.0
    read_timeout: float = 60.0
    # Retry policy
    max_retries: int = 3
    retry_backoff_seconds: float = 0.5
    # x402 autopay: if enabled, 402 responses are automatically paid on the
    # configured network (None = disabled, raise PaymentRequiredError).
    x402_autopay: bool = False
    x402_network: str = "base-mainnet"
    x402_wallet_private_key: str | None = None
    # Max per-call spend cap (USD). Prevents runaway agents burning the treasury.
    x402_per_call_cap_usd: float = 1.00
    # User-Agent to send with requests. Agents should customize.
    user_agent: str = "iagent-stack-python/0.1.0"
    # If True, the SDK will cache agent-card.json lookups for 5 minutes.
    cache_agent_cards: bool = True
    # Enable A2A mode: signed requests + verifiable provenance headers.
    a2a_enabled: bool = False
    a2a_agent_id: str | None = None

    @classmethod
    def from_env(cls) -> Config:
        """
        Build Config from environment variables:
            IAGENT_API_KEY
            IAGENT_HUB_BASE_URL
            IAGENT_X402_AUTOPAY ("1"/"true")
            IAGENT_X402_NETWORK
            IAGENT_X402_WALLET_PRIVATE_KEY
            IAGENT_X402_PER_CALL_CAP_USD
            IAGENT_A2A_AGENT_ID
        """
        autopay_raw = os.environ.get("IAGENT_X402_AUTOPAY", "").lower()
        autopay = autopay_raw in ("1", "true", "yes")
        cap = os.environ.get("IAGENT_X402_PER_CALL_CAP_USD")
        return cls(
            api_key=os.environ.get("IAGENT_API_KEY"),
            hub_base_url=os.environ.get("IAGENT_HUB_BASE_URL", "https://api.hub.ijarvis.ai/v1"),
            x402_autopay=autopay,
            x402_network=os.environ.get("IAGENT_X402_NETWORK", "base-mainnet"),
            x402_wallet_private_key=os.environ.get("IAGENT_X402_WALLET_PRIVATE_KEY"),
            x402_per_call_cap_usd=float(cap) if cap else 1.00,
            a2a_agent_id=os.environ.get("IAGENT_A2A_AGENT_ID"),
            a2a_enabled=bool(os.environ.get("IAGENT_A2A_AGENT_ID")),
        )

    def base_url_for(self, product: str) -> str:
        """Get the base URL for a product. Routes through hub if configured."""
        if self.hub_base_url and product not in self.product_base_urls:
            return f"{self.hub_base_url.rstrip('/')}/{product}"
        return self.product_base_urls.get(product) or DEFAULT_BASE_URLS[product]
