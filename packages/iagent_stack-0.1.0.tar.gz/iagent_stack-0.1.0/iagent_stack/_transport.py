"""
HTTP transport for iagent-stack. Handles:
- Authentication via API key
- x402 V2 autopay (HTTP 402 → pay → retry)
- Rate limit backoff with Retry-After
- Per-product request routing through iAgentHub gateway or direct
- A2A signed request mode (optional)
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

import httpx

from iagent_stack._config import Config
from iagent_stack._errors import (
    AuthenticationError,
    PaymentRequiredError,
    ProductNotAvailableError,
    RateLimitError,
    UpstreamError,
)

logger = logging.getLogger("iagent_stack")


class Transport:
    """
    Asynchronous HTTP transport. One instance is shared by all product
    subclients on a Stack. Manages a single httpx.AsyncClient pool.
    """

    def __init__(self, config: Config) -> None:
        self._config = config
        timeout = httpx.Timeout(
            connect=config.connect_timeout,
            read=config.read_timeout,
            write=config.read_timeout,
            pool=config.connect_timeout,
        )
        headers = {
            "User-Agent": config.user_agent,
            "Accept": "application/json",
            "x-iagent-sdk-version": "0.1.0",
        }
        if config.api_key:
            headers["Authorization"] = f"Bearer {config.api_key}"
        if config.a2a_enabled and config.a2a_agent_id:
            headers["x-a2a-agent-id"] = config.a2a_agent_id
            headers["x-a2a-version"] = "0.3.0"

        self._client = httpx.AsyncClient(timeout=timeout, headers=headers)

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> Transport:
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    async def request(
        self,
        method: str,
        product: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any = None,
    ) -> Any:
        """
        Execute an HTTP request against a product API with retry + x402 handling.
        Returns parsed JSON. Raises appropriate IAgentStackError subclass on failure.
        """
        base = self._config.base_url_for(product)
        url = f"{base.rstrip('/')}/{path.lstrip('/')}"

        last_exc: Exception | None = None
        for attempt in range(self._config.max_retries + 1):
            try:
                response = await self._client.request(method, url, params=params, json=json_body)
            except httpx.HTTPError as exc:
                last_exc = exc
                await asyncio.sleep(self._config.retry_backoff_seconds * (2 ** attempt))
                continue

            # Success
            if 200 <= response.status_code < 300:
                return self._parse_body(response, product)

            # Authentication
            if response.status_code in (401, 403):
                raise AuthenticationError(
                    f"Authentication failed for {product} ({response.status_code})",
                    status=response.status_code,
                    product=product,
                )

            # Payment required — x402 V2
            if response.status_code == 402:
                paid = await self._try_x402_autopay(response, product)
                if paid:
                    # Retry the original request with payment header attached by autopay
                    continue
                raise PaymentRequiredError(
                    f"{product} returned 402 Payment Required and autopay is disabled",
                    status=402,
                    product=product,
                    accepts=self._extract_x402_accepts(response),
                )

            # Rate limit
            if response.status_code == 429:
                retry_after = float(response.headers.get("retry-after", "1"))
                if attempt < self._config.max_retries:
                    await asyncio.sleep(retry_after)
                    continue
                raise RateLimitError(
                    f"{product} rate limited",
                    status=429,
                    retry_after=retry_after,
                    product=product,
                )

            # Upstream gone / unreachable
            if response.status_code in (502, 503, 504):
                if attempt < self._config.max_retries:
                    await asyncio.sleep(self._config.retry_backoff_seconds * (2 ** attempt))
                    continue
                raise ProductNotAvailableError(
                    f"{product} unreachable (HTTP {response.status_code})",
                    status=response.status_code,
                    product=product,
                )

            # Generic 4xx/5xx
            raise UpstreamError(
                f"{product} returned HTTP {response.status_code}",
                status=response.status_code,
                product=product,
                body=self._parse_body_safe(response),
            )

        raise ProductNotAvailableError(
            f"{product} unreachable after {self._config.max_retries} retries: {last_exc}",
            product=product,
        )

    # --- helpers ----------------------------------------------------------

    def _parse_body(self, response: httpx.Response, product: str) -> Any:
        try:
            return response.json()
        except json.JSONDecodeError as exc:
            raise UpstreamError(
                f"{product} returned non-JSON body",
                status=response.status_code,
                product=product,
                body=response.text[:500],
            ) from exc

    def _parse_body_safe(self, response: httpx.Response) -> Any:
        try:
            return response.json()
        except Exception:
            return response.text[:500]

    def _extract_x402_accepts(self, response: httpx.Response) -> list[dict[str, Any]]:
        """Extract the `accepts` array from an x402 V2 402 response."""
        try:
            body = response.json()
            accepts = body.get("accepts")
            if isinstance(accepts, list):
                return accepts
        except Exception:
            pass
        return []

    async def _try_x402_autopay(self, response: httpx.Response, product: str) -> bool:
        """
        Attempt to pay an x402 V2 demand and set headers for retry. Returns True
        on success, False if autopay disabled or no compatible accepts entry.

        Actual on-chain signing lives in a separate facilitator client (installed
        via the `x402` extra). This stub is deliberately conservative: if anything
        looks wrong, bail out and raise PaymentRequiredError in the caller.
        """
        if not self._config.x402_autopay:
            return False
        if not self._config.x402_wallet_private_key:
            logger.warning("x402 autopay enabled but no wallet private key configured")
            return False

        accepts = self._extract_x402_accepts(response)
        compatible = [a for a in accepts if a.get("network") == self._config.x402_network]
        if not compatible:
            logger.warning(
                "x402: no accepts entry for network=%s in response from %s",
                self._config.x402_network,
                product,
            )
            return False

        chosen = compatible[0]
        amount_usd = float(chosen.get("price_usd") or chosen.get("amount_usd") or 0)
        if amount_usd > self._config.x402_per_call_cap_usd:
            logger.warning(
                "x402: %s demanded %.4f USD, exceeds per-call cap %.4f",
                product, amount_usd, self._config.x402_per_call_cap_usd,
            )
            return False

        # Sign + attach payment header. Left as a stub here; concrete implementation
        # is in iagent_stack.contrib.x402 (requires the `x402` extra).
        try:
            from iagent_stack.contrib.x402 import sign_payment
        except ImportError:
            logger.warning("x402 autopay requested but iagent_stack[x402] not installed")
            return False

        payment_header = await sign_payment(
            accepts_entry=chosen,
            private_key=self._config.x402_wallet_private_key,
        )
        # The next iteration of the retry loop will use this header
        self._client.headers["x-payment"] = payment_header
        return True
