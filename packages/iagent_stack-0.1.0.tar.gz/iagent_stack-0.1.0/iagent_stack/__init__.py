"""
iagent-stack: Unified SDK for the iJarvis Agent Stack.

Sixteen products, one entity (iJarvis LLC), three layers:

Software Stack (7)     : trust, ref, log, pay, safe, sim, hub
Trust Substrate (4)    : memory, id, law, market
Hardware Moat (5)      : grid (internal), compute, edge, farm, foundry

Usage:

    from iagent_stack import Stack

    stack = Stack(api_key="iah_...")

    # Any product via attribute access:
    rating = await stack.trust.rating("base", "0x123...")
    spend  = await stack.pay.send(to="agent.eth", amount_usd=0.05)
    traces = await stack.log.traces(agent_id="my-agent")

Every call is authenticated with a single API key (iAgentHub unified gateway)
and settles via x402 V2 on Base or Solana under the hood.

Protocol compliance: ERC-8004 v1, x402 V2, A2A 0.3.0, MCP 2025-06-18,
ERC-8183 draft, AP2 v1, OASF 0.8.
"""

from iagent_stack._client import Stack
from iagent_stack._config import Config
from iagent_stack._errors import (
    AuthenticationError,
    IAgentStackError,
    PaymentRequiredError,
    ProductNotAvailableError,
    RateLimitError,
    UpstreamError,
)
from iagent_stack._version import __version__

__all__ = [
    "Stack",
    "Config",
    "IAgentStackError",
    "AuthenticationError",
    "PaymentRequiredError",
    "RateLimitError",
    "ProductNotAvailableError",
    "UpstreamError",
    "__version__",
]

# Exposed for agents parsing the SDK itself for capability discovery
SPEC_VERSION = "iJarvis-agent-stack-sdk/v0.1.0"
STACK_PRODUCTS = [
    "trust", "ref", "log", "pay", "safe", "sim", "hub",
    "memory", "id_", "law", "market",
    "compute", "edge", "farm", "foundry",
]
SUPPORTED_PROTOCOLS = {
    "erc-8004": "v1",
    "erc-8183": "draft",
    "a2a": "0.3.0",
    "mcp": "2025-06-18",
    "x402": "v2",
    "ap2": "v1",
    "oasf": "0.8",
}
