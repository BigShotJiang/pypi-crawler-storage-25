# iagent-stack

Unified Python SDK for the **iJarvis Agent Stack**. Four products shipping in 2026; eleven more on a three-year roadmap. One SDK, one `pip install`, one authentication surface.

## Install

```bash
pip install iagent-stack
```

Optional extras:

```bash
pip install iagent-stack[x402]   # enable x402 V2 autopay (EVM + Solana)
pip install iagent-stack[mcp]    # native MCP server wrapper helpers
pip install iagent-stack[dev]    # pytest, ruff, mypy for contributors
```

## Product availability

The SDK exposes all 15 product clients today, but only Cluster 1 endpoints serve live traffic in 2026. Calling a roadmap product returns `ProductNotAvailableError` until its endpoint launches. Code written now against the full SDK continues to work as roadmap products ship.

| Attribute | Product | Capability | Status |
|---|---|---|---|
| `stack.trust` | iAgentFi | ratings & trust bureau | **Shipping 2026** (v1 live, v2 in build) |
| `stack.ref` | iAgentRef | agent discovery | **Shipping 2026** (Q2) |
| `stack.log` | iAgentLog | observability | **Shipping 2026** (Q2-Q3) |
| `stack.pay` | iAgentPay | x402 treasury | **Shipping 2026** (Q3, anchor) |
| `stack.compute` | iJarvis Compute | boutique inference | **Shipping 2026** (Q3) |
| `stack.hub` | iAgentHub | gateway / billing | SDK built pre-publish; hosted gateway 2027 |
| `stack.safe` | iAgentSafe | runtime guardrails | Roadmap 2027 |
| `stack.memory` | iAgentMemory | persistent memory | Roadmap 2027 |
| `stack.edge` | iAgentEdge | on-prem appliance | Roadmap 2027 (hardware) |
| `stack.farm` | iAgentFarm | agent hosting | Roadmap 2027 (hardware) |
| `stack.sim` | iAgentSim | adversarial simulation | Roadmap 2028 |
| `stack.id_` | iAgentID | verifiable credentials | Roadmap 2028 |
| `stack.market` | iAgentMarket | capability marketplace | Roadmap 2028 |
| `stack.foundry` | iAgentFoundry | fine-tuning | Roadmap 2028 (hardware) |
| `stack.law` | iAgentLaw | legal & liability | Parked pending anchor partner |

iAgentGrid is private compute infrastructure running behind every stack product. It has no public API surface by design and is not exposed as a client.

## Quickstart

```python
from iagent_stack import Stack

stack = Stack()  # reads IAGENT_API_KEY from env

# Cluster 1 products (live 2026):
rating  = await stack.trust.rating("base", "0xabc...")
results = await stack.ref.search("agents that do onchain research")
tx      = await stack.pay.send(to="agent.eth", amount_usd=0.05)
models  = await stack.compute.models()

# Roadmap products exist in the SDK today but raise ProductNotAvailableError
# until their endpoints launch. Code against them now; the call succeeds the
# day the endpoint ships.
```

## Configuration

Most setups work with just an API key. For more control:

```python
from iagent_stack import Stack, Config

config = Config(
    api_key="iah_live_...",
    hub_base_url="https://api.hub.ijarvis.ai/v1",  # or None for direct-to-product
    x402_autopay=True,
    x402_network="base-mainnet",
    x402_wallet_private_key="0x...",
    x402_per_call_cap_usd=0.25,
    a2a_enabled=True,
    a2a_agent_id="did:web:my-agent.example",
)
stack = Stack(config=config)
```

Environment variables (read by `Config.from_env()`):

- `IAGENT_API_KEY`
- `IAGENT_HUB_BASE_URL`
- `IAGENT_X402_AUTOPAY` (`1`/`true`)
- `IAGENT_X402_NETWORK`
- `IAGENT_X402_WALLET_PRIVATE_KEY`
- `IAGENT_X402_PER_CALL_CAP_USD`
- `IAGENT_A2A_AGENT_ID`

## x402 V2 autopay

When `x402_autopay=True`, HTTP 402 responses from any product are automatically signed and retried on the configured network. A per-call USD cap (`x402_per_call_cap_usd`) prevents runaway agents. Signing requires the `[x402]` extra.

## Standards compliance

- **ERC-8004 v1** — agent identity + reputation + validation registries (mainnet Jan 29, 2026)
- **x402 V2** — HTTP-native payments with reusable sessions and multi-chain settlement
- **A2A 0.3.0** — Agent-to-Agent protocol (Linux Foundation)
- **MCP 2025-06-18** — Model Context Protocol (Anthropic)
- **OASF 0.8** — Open Agent Schema Framework
- **AP2 v1** — Google Agent Payments Protocol
- **ERC-8183** (draft) — agentic commerce standard

## Lifecycle

`Stack` owns an async HTTP pool. Use it as an async context manager or call `close()` on shutdown:

```python
async with Stack() as stack:
    health = await stack.health()
    print(health)   # {'trust': True, 'ref': True, ...}
```

## Development

```bash
git clone https://github.com/iJarvis/iagent-stack
cd iagent-stack/sdk/python
pip install -e ".[dev]"
pytest
```

## License

Apache-2.0. Copyright iJarvis LLC.

## Links

- Stack homepage: [hub.ijarvis.ai](https://hub.ijarvis.ai)
- Agent card: [hub.ijarvis.ai/.well-known/agent-card.json](https://hub.ijarvis.ai/.well-known/agent-card.json)
- Source: [github.com/iJarvis/iagent-stack](https://github.com/iJarvis/iagent-stack)
