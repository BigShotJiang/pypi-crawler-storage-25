"""Tests for the canonical branch-naming rule.

Plan 0006 Slice 1: ``agentic_protocol.branch_naming`` exposes
``TASK_REF_RE``, ``derive_task_ref_candidates``,
``format_suggested_branch_name``, and ``__protocol_version__`` as the
single source of truth for branch-naming validation across every gate.
``agent_handoff_mcp`` re-exports these without duplication.
"""

from __future__ import annotations

import re

import pytest

from agentic_protocol import branch_naming
from agentic_protocol.branch_naming import (
    TASK_REF_RE,
    derive_task_ref_candidates,
    format_suggested_branch_name,
)


POSITIVE_CORPUS = (
    "feature/ahmcp-35",
    "feature/ahmcp-37-branch-naming-enforcement",
    "feature/maint-dirty-br-01",
    "feature/maint-archive-stale-20260502",
    "feature/plan-0006",
    "feature/e17-10",
)


NEGATIVE_CORPUS = (
    "main",
    "master",
    "fix/foo",
    "chore/bar",
    "wip-thing",
    "feature/foo",  # single-segment
    "feature/foo-bar",  # no digit
    "feature/no-digits-here",
    "hotfix/x",
    "release/v1",
    "feature/AHMCP-37",  # uppercase
    "feature/-x",  # leading hyphen
    "feature/123-foo",  # leading digit segment
    "feature/",  # empty task ref
    "FEATURE/ahmcp-37",  # uppercase prefix
    "",
)


@pytest.mark.parametrize("name", POSITIVE_CORPUS)
def test_task_ref_re_accepts_conforming_names(name: str) -> None:
    assert TASK_REF_RE.match(name) is not None


@pytest.mark.parametrize("name", NEGATIVE_CORPUS)
def test_task_ref_re_rejects_non_conforming_names(name: str) -> None:
    assert TASK_REF_RE.match(name) is None


def test_task_ref_re_is_compiled_regex() -> None:
    assert isinstance(TASK_REF_RE, re.Pattern)


def test_protocol_version_marker_is_string() -> None:
    assert isinstance(branch_naming.__protocol_version__, str)
    assert branch_naming.__protocol_version__ != ""


@pytest.mark.parametrize(
    "branch,expected",
    [
        # Walk every digit-bearing prefix from longest to shortest. ``ahmcp`` is
        # dropped because it has no digit.
        ("feature/ahmcp-37-branch-naming-enforcement", [
            "ahmcp-37-branch-naming-enforcement",
            "ahmcp-37-branch-naming",
            "ahmcp-37-branch",
            "ahmcp-37",
        ]),
        ("feature/ahmcp-37", ["ahmcp-37"]),
        # Only the full ref carries a digit; shorter prefixes are digit-less.
        ("feature/maint-dirty-br-01", ["maint-dirty-br-01"]),
        ("feature/plan-0006", ["plan-0006"]),
        # Both ``e17-10`` and ``e17`` carry a digit; both are returned.
        ("feature/e17-10", ["e17-10", "e17"]),
        # non-conforming → empty
        ("feature/foo", []),
        ("feature/foo-bar", []),
        ("fix/foo", []),
        ("main", []),
        ("", []),
    ],
)
def test_derive_task_ref_candidates(branch: str, expected: list[str]) -> None:
    assert derive_task_ref_candidates(branch) == expected


def test_derive_returns_lowercase_for_conforming() -> None:
    """Callers uppercase before intersecting against the live task table.
    The derivation MUST stay lowercase so that intersection logic owns the
    case conversion rather than guessing it here."""
    candidates = derive_task_ref_candidates(
        "feature/ahmcp-37-branch-naming-enforcement"
    )
    assert all(c == c.lower() for c in candidates)


@pytest.mark.parametrize(
    "task_ref,slug,expected",
    [
        ("AHMCP-37", None, "feature/ahmcp-37"),
        ("ahmcp-37", None, "feature/ahmcp-37"),
        ("AHMCP-37", "branch-naming-enforcement",
         "feature/ahmcp-37-branch-naming-enforcement"),
        ("MAINT-DIRTY-BR-01", None, "feature/maint-dirty-br-01"),
        ("PLAN-0006", "rollout", "feature/plan-0006-rollout"),
    ],
)
def test_format_suggested_branch_name(
    task_ref: str, slug: str | None, expected: str
) -> None:
    suggestion = format_suggested_branch_name(task_ref, slug=slug)
    assert suggestion == expected
    assert TASK_REF_RE.match(suggestion) is not None


def test_format_suggested_branch_name_returns_none_without_task_ref() -> None:
    """Callers (e.g. the post-checkout warn helper) pass None when no
    active task is registered. The formatter returns None so the warn
    path can fall back to a generic message instead of crashing."""
    assert format_suggested_branch_name(None) is None
    assert format_suggested_branch_name("") is None


def test_handoff_re_export_is_canonical_object() -> None:
    """``agent_handoff_mcp`` MUST re-export the same compiled regex
    object — not a literal copy. A second compiled pattern would let
    grammar tweaks drift across packages.
    """
    from agent_handoff_mcp import (
        TASK_REF_RE as handoff_re,
        derive_task_ref_candidates as handoff_derive,
        format_suggested_branch_name as handoff_format,
    )

    assert handoff_re is TASK_REF_RE
    assert handoff_derive is derive_task_ref_candidates
    assert handoff_format is format_suggested_branch_name
