"""Plan 0010 Slice 6 — branch-grammar registry."""

from __future__ import annotations

import pytest


def test_registry_includes_documented_exception_kinds() -> None:
    from agentic_protocol.branch_naming import BRANCH_GRAMMAR_REGISTRY

    kinds = {entry.kind for entry in BRANCH_GRAMMAR_REGISTRY}
    expected = {"feature", "release", "hotfix", "maint", "revert"}
    assert expected <= kinds


@pytest.mark.parametrize(
    "branch,expected_kind",
    [
        ("feature/ahmcp-37-branch-naming-enforcement", "feature"),
        ("release/0.9.1", "release"),
        ("hotfix/ahmcp-99-fix-bug", "hotfix"),
        ("maint/cleanup-stale-rows", "maint"),
        ("revert/ahmcp-12-bad-merge", "revert"),
    ],
)
def test_classify_branch_returns_correct_kind(branch: str, expected_kind: str) -> None:
    from agentic_protocol.branch_naming import classify_branch

    classification = classify_branch(branch)
    assert classification is not None
    assert classification.kind == expected_kind


@pytest.mark.parametrize(
    "branch",
    [
        "feature/ahmcp-37-branch-naming-enforcement",
        "release/0.9.1",
        "hotfix/ahmcp-99-fix-bug",
        "maint/cleanup-stale-rows",
        "revert/ahmcp-12-bad-merge",
    ],
)
def test_is_allowed_branch_passes_for_documented_patterns(branch: str) -> None:
    from agentic_protocol.branch_naming import is_allowed_branch

    assert is_allowed_branch(branch, mode="post_checkout_warn")


def test_is_allowed_branch_fails_closed_for_unknown_pattern() -> None:
    from agentic_protocol.branch_naming import classify_branch, is_allowed_branch

    assert classify_branch("experiment/some-prototype") is None
    assert not is_allowed_branch("experiment/some-prototype", mode="post_checkout_warn")


def test_main_is_classified() -> None:
    from agentic_protocol.branch_naming import classify_branch

    assert classify_branch("main") is not None
