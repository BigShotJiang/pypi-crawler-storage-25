# Empty file to make it a package.

__version__ = "1.0.0"
__author__ = "Preeti Soni"

from minieval.scorers.faithfulness import FaithfulnessScorer
from minieval.scorers.relevance import RelevanceScorer
from minieval.scorers.toxicity import ToxicityScorer

class Evaluator:
    def __init__(self):
        self.faithfulness = FaithfulnessScorer()
        self.relevance = RelevanceScorer()
        self.toxicity = ToxicityScorer()
    
    def score(self, question: str, context: str, answer: str):
        faithfulness = self.faithfulness.score(context, answer)
        relevance = self.relevance.score(question, answer)
        toxicity = self.toxicity.score(answer)
        overall = (faithfulness + relevance) / 2
        
        return type("Result", (), {
            "faithfulness": faithfulness,
            "relevance": relevance,
            "toxicity": toxicity,
            "overall_score": overall,
            "passed": overall > 0.7,
            "summary": lambda: f"Overall: {overall:.2f} | Faithfulness: {faithfulness:.2f} | Relevance: {relevance:.2f}"
        })()