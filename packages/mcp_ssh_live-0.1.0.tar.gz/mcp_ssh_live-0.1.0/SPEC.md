# mcp-ssh-live — Specification

> **Interactive, streaming SSH tool for LLM agents via MCP (Model Context Protocol).**
>
> Solves the fundamental limitation of request/response SSH tools: long-running
> commands can be observed incrementally instead of blocking until completion.

---

## Goals

1. Let an LLM agent (Claude/Cursor/Zed) **spawn long-running remote commands**
   and **tail their output incrementally** with sub-10-second latency.
2. **Replace ad-hoc `screen/nohup/tee` workarounds** currently used when running
   parsers, attacks, indexing jobs that last minutes to hours.
3. **Reusable across projects** — install once via `pipx`, register in any MCP
   client, point at any host.
4. **Multi-host** — can manage jobs across several servers simultaneously.
5. **Stable across SSH drops** — auto-reconnect transparent to running jobs.

## Non-goals

- Full interactive shell emulation for humans (for that: use `ssh`/`tmux`).
- File synchronization, port forwarding (scope creep — can be added later).
- GUI.

---

## User stories

1. **Long-running job.**
   LLM runs `python parser.py` on remote. Gets a `job_id` immediately. Polls
   `ssh_tail(job_id)` every few seconds, streams stdout to user in chat, sees
   when job finishes or crashes.

2. **Reactive debugging.**
   LLM notices error in `ssh_tail` output, sends SIGINT via `ssh_signal`,
   edits config remotely (`ssh_upload`), re-runs.

3. **Parallel workflows.**
   LLM starts parser (`job_A`) + builds index (`job_B`) on same host. Polls
   both alternately. No manual screens needed.

4. **Multi-server.**
   LLM runs deploys on 3 servers at once. Each `spawn` call targets a
   different host.

---

## Architecture

### High-level

```
┌─────────────────────────┐
│ MCP client              │
│ (Claude, Cursor, Zed)   │
└──────────┬──────────────┘
           │ JSON-RPC / stdio
┌──────────▼─────────────────────────────────────┐
│ mcp-ssh-live (Python)                          │
│                                                │
│  FastMCP server — 8 tools (exec, spawn, tail…) │
│                                                │
│  ┌──────────────────────────────────────────┐  │
│  │ ConnectionPool                            │  │
│  │  host:port → SSHConnection                │  │
│  │   paramiko.Transport (persistent)         │  │
│  │   auto-reconnect                          │  │
│  └──────────┬───────────────────────────────┘  │
│             │                                   │
│  ┌──────────▼───────────────────────────────┐  │
│  │ JobManager (in-process)                  │  │
│  │  job_id → Job                            │  │
│  │   * paramiko.Channel                     │  │
│  │   * stdout / stderr ring buffers         │  │
│  │   * 2 reader threads (drain pipes)       │  │
│  │   * exit_status Event                    │  │
│  │   * metadata (cmd, started_at, host)     │  │
│  └──────────────────────────────────────────┘  │
│                                                │
└──────────┬─────────────────────────────────────┘
           │ SSH (TCP 22)
┌──────────▼──────────┐
│ Remote server(s)    │
└─────────────────────┘
```

### Process model

- **Single long-lived Python process** (started by MCP client).
- **One `paramiko.SSHClient` per unique `(host, user, port)`** — persistent.
- **One `paramiko.Channel` per job** — opened under same transport.
  `paramiko.Transport` supports concurrent channels without new TCP handshake.
- **Two reader threads per active job** — one for stdout, one for stderr.
  They `channel.recv_ready()` + `channel.recv(4096)` in a loop and append to
  line-oriented ring buffers.
- **No asyncio in v1** — threads are simpler and paramiko is not asyncio-native.
  Consider `asyncssh` migration in v2.

### Data model

```python
@dataclass
class JobLine:
    line_no: int          # monotonic, per-job
    stream: str           # 'stdout' | 'stderr'
    ts: float             # unix epoch
    text: str             # single line, newline stripped

@dataclass
class Job:
    job_id: str                          # uuid4 or host-counter
    host: str
    cmd: str
    started_at: float
    finished_at: Optional[float]
    exit_status: Optional[int]           # None while running
    pid: Optional[int]                   # remote pid (if we can extract)
    channel: paramiko.Channel
    stdout: deque[JobLine]               # maxlen=10000 default
    stderr: deque[JobLine]               # maxlen=10000 default
    line_counter: int
    done_event: threading.Event
    pty: bool                            # was started with pty?
```

### Ring buffer

- `collections.deque(maxlen=N)` per stream. Default `N=10_000` lines.
- Line numbers monotonic, never reused. `tail(since=X)` always returns lines
  with `line_no > X` that are still in buffer.
- If caller's `since` is older than oldest line in buffer: return `truncated=True`
  flag so LLM knows it lost some output.
- **Total log** optionally mirrored to `~/.cache/mcp-ssh-live/logs/<job_id>.log`
  so full output survives even after ring eviction.

### Reader-thread loop (pseudocode)

```python
def _read_stream(job, channel, stream_name):
    buf = ''
    recv = channel.recv if stream_name == 'stdout' else channel.recv_stderr
    while not channel.closed:
        try:
            chunk = recv(4096)
            if not chunk:
                break
            buf += chunk.decode('utf-8', errors='replace')
            while '\n' in buf:
                line, buf = buf.split('\n', 1)
                job.append_line(stream_name, line)
        except socket.timeout:
            continue
    if buf:
        job.append_line(stream_name, buf)   # last unterminated line
```

### tail() with blocking wait

`ssh_tail(job_id, since_line_no, wait_ms, max_lines)`:

```
1. snapshot = job.lines_since(since_line_no, stream='stdout'+'stderr')
2. if snapshot not empty or job finished:
     return (snapshot[:max_lines], still_running=not job.done)
3. wait on job.new_line_cond with timeout = wait_ms/1000
4. snapshot = job.lines_since(since_line_no, ...)
5. return snapshot (possibly empty)
```

LLM can now call in a loop with `wait_ms=5000` and get live-ish stream.

---

## MCP Tools (public API)

All tools are JSON-in/JSON-out via FastMCP decorators.
All tools support optional `host` param — if omitted, uses configured default.

### 1. `ssh_exec`

**Purpose:** simple synchronous command (current behavior of existing tools).

```python
ssh_exec(
    command: str,
    host: Optional[str] = None,
    timeout_ms: int = 60_000,
    cwd: Optional[str] = None,
    env: Optional[dict[str,str]] = None,
) -> {
    "stdout": str,
    "stderr": str,
    "exit_status": int,
    "duration_ms": int,
    "truncated": bool,          # if output > max_inline_chars
}
```

- If output exceeds `max_inline_chars` (default 64 KB), truncate and set flag.
- Kills process on timeout with SIGTERM then SIGKILL.

### 2. `ssh_spawn`

**Purpose:** start background job, return `job_id`.

```python
ssh_spawn(
    command: str,
    host: Optional[str] = None,
    cwd: Optional[str] = None,
    env: Optional[dict[str,str]] = None,
    pty: bool = False,             # True for interactive (top/htop/passwords)
    label: Optional[str] = None,   # human-readable, shown in list_jobs
) -> {
    "job_id": str,
    "started_at": float,
    "host": str,
}
```

- Returns immediately after SSH `exec_command` succeeds.
- Reader threads start before return.
- Job persists until explicit `ssh_remove_job` OR process exits AND 10 min elapse
  (configurable).

### 3. `ssh_tail`

**Purpose:** get new lines from a job; optionally block until new lines appear.

```python
ssh_tail(
    job_id: str,
    since_line_no: int = 0,       # 0 = from start (oldest in buffer)
    wait_ms: int = 0,             # 0 = don't block; >0 = wait up to this
    max_lines: int = 500,
    stream: str = "both",         # "stdout" | "stderr" | "both"
) -> {
    "lines": [
        {"line_no": 142, "stream": "stdout", "ts": 1737123456.12, "text": "..."},
        ...
    ],
    "last_line_no": int,          # max line_no returned, use as next `since`
    "still_running": bool,
    "exit_status": Optional[int], # None if running
    "buffer_truncated": bool,     # lines were evicted before `since_line_no`
}
```

- If `wait_ms > 0` and no new lines: blocks on condvar.
- If job already finished: returns immediately with all remaining lines.

### 4. `ssh_send_stdin`

**Purpose:** write to stdin of a running job (sudo password, interactive prompts).

```python
ssh_send_stdin(
    job_id: str,
    data: str,                     # will have '\n' appended if `newline=True`
    newline: bool = True,
) -> {"written": int}
```

### 5. `ssh_signal`

**Purpose:** kill/interrupt a job.

```python
ssh_signal(
    job_id: str,
    signal: str = "TERM",          # "TERM" | "KILL" | "INT" | "HUP"
) -> {"sent": bool, "exit_status": Optional[int]}
```

- paramiko `channel.send_signal()` if supported by remote sshd; fallback to
  shell `kill -SIGNAL <pid>` if we captured pid.
- Note: OpenSSH server usually blocks `send_signal` unless
  `AcceptEnv` / specific config. Realistic implementation uses the
  "spawn a wrapper that echoes its pid first" trick (see Edge Cases).

### 6. `ssh_list_jobs`

```python
ssh_list_jobs(
    host: Optional[str] = None,
    include_finished: bool = True,
) -> {
    "jobs": [
        {
            "job_id": str,
            "host": str,
            "cmd": str,
            "label": Optional[str],
            "started_at": float,
            "finished_at": Optional[float],
            "exit_status": Optional[int],
            "still_running": bool,
            "stdout_lines": int,
            "stderr_lines": int,
        },
        ...
    ]
}
```

### 7. `ssh_remove_job`

**Purpose:** drop finished job from memory. Running job must be signaled first
(or pass `force=True` to SIGKILL+remove).

```python
ssh_remove_job(job_id: str, force: bool = False) -> {"removed": bool}
```

### 8. `ssh_upload` / `ssh_download`

**Purpose:** SFTP, because `cat > file <<EOF` is painful for binaries.

```python
ssh_upload(
    local_path: str,
    remote_path: str,
    host: Optional[str] = None,
    mode: Optional[int] = None,     # octal e.g. 0o755
) -> {"bytes": int, "sha256": str}

ssh_download(
    remote_path: str,
    local_path: str,
    host: Optional[str] = None,
    max_bytes: int = 100 * 1024 * 1024,
) -> {"bytes": int, "sha256": str}
```

### 9. (bonus) `ssh_list_hosts`

```python
ssh_list_hosts() -> {
    "hosts": [
        {"host": "1.2.3.4", "user": "root", "connected": true,
         "active_jobs": 2, "last_used": 1737...}
    ]
}
```

---

## Configuration

### CLI entrypoint

```bash
mcp-ssh-live \
    --host 1.2.3.4 \
    --port 22 \
    --user root \
    --password-env SSH_PASSWORD \           # OR
    --key ~/.ssh/id_rsa \
    --alias prod \                          # optional short name
    --log-dir ~/.cache/mcp-ssh-live/logs
```

Multiple `--host` blocks allowed for multi-host setups:

```bash
mcp-ssh-live \
    --host prod=1.2.3.4 --user root --password-env PROD_PASS \
    --host stage=10.0.0.5 --user deploy --key ~/.ssh/stage_key
```

### Config file (alternative)

`~/.config/mcp-ssh-live/config.toml`:

```toml
default_host = "prod"

[hosts.prod]
host = "1.2.3.4"
port = 22
user = "root"
password_env = "SSH_PASSWORD"

[hosts.stage]
host = "10.0.0.5"
user = "deploy"
key = "~/.ssh/stage_key"

[limits]
ring_buffer_lines = 10000
max_jobs_per_host = 50
max_inline_chars = 65536
reap_finished_after_sec = 600
```

### MCP client registration

#### Claude Desktop / Claude Code

`~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "ssh-live": {
      "command": "pipx",
      "args": ["run", "mcp-ssh-live"],
      "env": {
        "SSH_PASSWORD": "..."
      }
    }
  }
}
```

#### Cursor

`~/.cursor/mcp.json`: same format as Claude Desktop.

#### Zed

`settings.json`:

```json
{
  "context_servers": {
    "ssh-live": {
      "command": {
        "path": "pipx",
        "args": ["run", "mcp-ssh-live"],
        "env": {"SSH_PASSWORD": "..."}
      }
    }
  }
}
```

---

## Edge cases & decisions

### 1. Signal handling on typical sshd

OpenSSH server historically doesn't honor `channel.send_signal`. Workaround
used by VS Code remote etc.:

- Spawn wrapper: `exec bash -c "echo PID=$$; exec <cmd>"`.
- First line of stdout contains `PID=<n>`. Store `job.pid = n`.
- `ssh_signal` runs a **separate short exec** `kill -SIGNAL <pid>` over the
  same ssh connection.
- Alternative: if remote has `AcceptEnv` allowing signals, use native channel
  signals.

### 2. Interactive input (sudo password)

- `ssh_spawn(pty=True)` — gives process a TTY so prompts behave.
- `ssh_send_stdin(data="mypass\n")`.
- For predictable sudo: recommend `sudo -S -p ''` and send password first line.

### 3. Binary output

- Reader threads decode as UTF-8 with `errors='replace'` — binary blobs become
  garbled but don't crash. For real binaries use `ssh_download`.

### 4. SSH connection drop

- paramiko Transport detects EOF → mark all jobs on that host as crashed,
  exit_status=`-1`, synthesize stderr line "[mcp-ssh-live: connection lost]".
- Next `ssh_exec` / `ssh_spawn` to that host triggers reconnect.
- Running jobs can't be resumed (remote side killed them) — this is a
  fundamental limitation. Workaround: user prefixes long jobs with `nohup`/
  `disown` manually in v1; v2 may auto-wrap.

### 5. Rate limiting & resource caps

- Max active jobs per host: default 50, configurable. `ssh_spawn` returns
  error if exceeded.
- Ring buffer has hard `maxlen` — old lines silently evicted.
- Tail-to-disk is append-only, rotated/truncated only by user.

### 6. Security

- Passwords passed via env var only, never in command line (visible in `ps`).
- Keys via path (default perms checked: warn if 0644).
- `known_hosts` respected (`AutoAddPolicy` disabled by default; configurable
  `--insecure-auto-add`).
- **No tool does `exec_command` with string interpolation from LLM without
  explicit escape** — LLM supplies the whole command string; user trusts LLM.
  This is the SSH tool's actual purpose; the sandbox is at MCP-client level
  (user approves each call).

### 7. Job cleanup

- Finished jobs kept for `reap_finished_after_sec` (default 10 min) so LLM can
  still fetch final lines.
- `ssh_list_jobs` includes finished ones until reaped.
- On server shutdown: all jobs SIGTERM → 5s grace → SIGKILL; connection closed.

### 8. Line buffering on remote

Many programs buffer stdout when not a TTY. If user complains about "no lines
until job finishes":
- Suggest `ssh_spawn(pty=True)` (most programs line-buffer with TTY).
- Or use `stdbuf -oL <cmd>` / `python -u` / `PYTHONUNBUFFERED=1`.
- **Document this explicitly in README** — it's the #1 surprise for users.

---

## Tech stack

| Component | Choice | Why |
|---|---|---|
| Language | **Python 3.10+** | Needed for paramiko; ubiquitous in MCP ecosystem |
| MCP framework | **[FastMCP](https://github.com/jlowin/fastmcp)** | Decorator-based, minimal boilerplate |
| SSH | **paramiko** | Pure-python, stable, multi-channel Transport |
| CLI | **typer** or **argparse** | Typer for config UX, fallback argparse |
| Config | **tomllib** (stdlib 3.11+) | No extra dep |
| Logging | **logging** (stdlib) + rotating file handler | Mirror job output to disk |
| Packaging | **hatchling** (`pyproject.toml`) | PEP 621 compliant |
| Distribution | **PyPI** via `pipx` | One-command install for users |

Tests: **pytest** + **pytest-asyncio** + local sshd in Docker for integration.

---

## Directory layout

```
mcp-ssh-live/
├── pyproject.toml
├── README.md
├── LICENSE (MIT)
├── SPEC.md                        ← this file
├── docs/
│   ├── INSTALL.md
│   ├── USAGE.md
│   ├── TROUBLESHOOTING.md
│   └── zed-extension/
│       └── SPEC.md                ← how to wrap for Zed later
├── src/mcp_ssh_live/
│   ├── __init__.py
│   ├── __main__.py                ← `python -m mcp_ssh_live`
│   ├── server.py                  ← FastMCP setup + tool wiring
│   ├── config.py                  ← CLI + TOML config loading
│   ├── connection.py              ← SSHConnection, ConnectionPool
│   ├── job.py                     ← Job dataclass, ring buffer, reader threads
│   ├── job_manager.py             ← JobManager singleton
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── exec_tool.py
│   │   ├── spawn_tool.py
│   │   ├── tail_tool.py
│   │   ├── signal_tool.py
│   │   ├── stdin_tool.py
│   │   ├── jobs_tool.py
│   │   └── sftp_tool.py
│   └── utils/
│       ├── signals.py             ← PID-capture wrapper, kill helper
│       └── ringbuf.py
└── tests/
    ├── conftest.py                ← docker-sshd fixture
    ├── test_exec.py
    ├── test_spawn_tail.py
    ├── test_signal.py
    ├── test_sftp.py
    ├── test_reconnect.py
    └── test_edge_cases.py
```

---

## Implementation plan (phased)

Each phase is independently testable. Stop/checkpoint between phases.

### Phase 1 — Skeleton & `ssh_exec` (MVP, ~1h)

**Deliverable:** installable package, one working tool.

- [ ] `pyproject.toml` with deps: `fastmcp`, `paramiko`, `typer`
- [ ] `src/mcp_ssh_live/__main__.py` → parse CLI → start FastMCP stdio server
- [ ] `SSHConnection` class: connect, `exec(cmd, timeout)` returning (stdout, stderr, rc)
- [ ] `ssh_exec` tool wired up
- [ ] README with minimal install + Claude Desktop config example
- [ ] `pipx install -e .` works, stdio MCP handshake works

**Acceptance:** can run `ssh_exec("hostname")` from Claude Desktop chat.

### Phase 2 — Jobs & streaming (core feature, ~2h)

**Deliverable:** live tail of long jobs.

- [ ] `Job` dataclass with deque ring buffers
- [ ] `JobManager` with uuid-keyed dict, RLock
- [ ] Reader threads (stdout + stderr)
- [ ] `ssh_spawn`, `ssh_tail` (with wait_ms), `ssh_list_jobs`, `ssh_remove_job`
- [ ] Condition variable for efficient `wait_ms` blocking
- [ ] Tests: spawn `seq 100`, tail in 3 polls, verify ordering + line_no monotonic

**Acceptance:** start `python -u -c "import time; [print(i) or time.sleep(1) for i in range(30)]"`, poll `tail` 3× with `wait_ms=5000`, see incremental output.

### Phase 3 — Signals & stdin (~1h)

- [ ] PID-capture wrapper in `ssh_spawn` (`exec bash -c "echo PID=$$; exec ..."`)
- [ ] Parse first stdout line to get `job.pid`
- [ ] `ssh_signal` — try `channel.send_signal`, fallback to `kill -SIGNAL <pid>`
  via new short exec
- [ ] `ssh_send_stdin`
- [ ] Tests: spawn `sleep 300`, `ssh_signal("KILL")`, verify exit_status=-9 or 137

**Acceptance:** can kill runaway jobs, can feed sudo password.

### Phase 4 — SFTP & multi-host (~1h)

- [ ] `ssh_upload`, `ssh_download` via `paramiko.SFTPClient`
- [ ] `ConnectionPool` keyed by host, lazy connect
- [ ] TOML config file loading
- [ ] `ssh_list_hosts`
- [ ] Tests: upload → read remotely → download → compare sha256

**Acceptance:** multi-host config works; can upload/run/download in one LLM turn.

### Phase 5 — Robustness (~1h)

- [ ] Reconnect on transport failure
- [ ] Graceful shutdown (SIGTERM→SIGKILL all jobs on exit)
- [ ] Finished-job reaper thread
- [ ] Buffer eviction truncation flag
- [ ] Log-to-disk mirror (optional)
- [ ] Full test suite against dockerized sshd

**Acceptance:** pull network cable during a job → reconnect → new jobs work;
old jobs marked crashed cleanly.

### Phase 6 — Polish & publish (~1h)

- [ ] Comprehensive README with real-world examples
- [ ] USAGE.md with buffering gotchas
- [ ] TROUBLESHOOTING.md
- [ ] CI: pytest on 3.10/3.11/3.12
- [ ] Publish to PyPI
- [ ] Announce in Zed Discord / MCP awesome list

**Total:** ~7 hours of focused work for a solid v1.

---

## Testing strategy

### Unit tests

- Ring buffer eviction, line numbering, thread safety.
- Config parsing (TOML + CLI precedence).
- Tool schema validation.

### Integration tests (docker-compose)

- `linuxserver/openssh-server` as test fixture.
- Tests hit a real sshd, spawn real processes.
- Verify: exec, spawn→tail incremental, signal delivery, SFTP roundtrip.

### Manual validation checklist

- [ ] `python -u parser.py` shows line-by-line in tail
- [ ] `sudo -S cmd` + `ssh_send_stdin(password)` works
- [ ] `Ctrl+C` equivalent (`ssh_signal("INT")`) actually interrupts
- [ ] 1000-line burst doesn't lose lines (with default 10k buffer)
- [ ] Reconnect after `iptables -A INPUT -p tcp --dport 22 -j DROP` then restore
- [ ] Works with password auth AND key auth
- [ ] Works behind bastion (ProxyJump) — v2 maybe

---

## Open questions (decide before Phase 1)

1. **uuid vs counter for job_id?**
   - uuid: unique across restarts, long.
   - counter `host-1`, `host-2`: short, friendly, but collides on restart.
   - **Decision:** short uuid4 prefix (`a3f8b2`) — 6 chars, 16.7M space, friendly.

2. **FastMCP version — stable API?**
   - Current `fastmcp>=0.9` looks stable. Pin `>=0.9,<1.0` for now.

3. **Async or threaded?**
   - paramiko is threaded. Jumping to `asyncssh` is big refactor.
   - **Decision:** threads for v1, revisit.

4. **Where to store finished-job logs?**
   - `~/.cache/mcp-ssh-live/logs/<job_id>.log`
   - Keep forever? Rotate by age?
   - **Decision:** keep last 100, opt-in via `--log-dir`. Default off.

5. **Ship Zed extension in same repo or separate?**
   - Zed requires Rust crate with WASM.
   - **Decision:** separate repo `zed-ssh-live`, link from main README.
   - Docs stub at `docs/zed-extension/SPEC.md`.

---

## Success metrics

After v1 is deployed and in use:

- **Latency:** tail-roundtrip < 10 s for 95% of polls.
- **Stability:** 24 h of continuous LLM usage without MCP server crash.
- **Adoption:** at least 3 MCP clients tested (Claude Desktop, Cursor, Zed).
- **Ergonomics:** LLM can complete "run a 2-hour parser and show progress"
  task without any custom screen/nohup instructions from the user.

---

## References

- [Model Context Protocol spec](https://modelcontextprotocol.io/)
- [FastMCP](https://github.com/jlowin/fastmcp)
- [paramiko](https://docs.paramiko.org/)
- Existing SSH MCP servers reviewed (all request/response, no streaming):
  - [`tufantunc/ssh-mcp`](https://github.com/tufantunc/ssh-mcp)
  - [`classfang/ssh-mcp-server`](https://github.com/classfang/ssh-mcp-server)
  - [`AiondaDotCom/mcp-ssh`](https://github.com/AiondaDotCom/mcp-ssh)
- Zed MCP extensions docs: <https://zed.dev/docs/extensions/mcp-extensions>

---

## License

MIT (to be confirmed by author).

## Contact

Author: TBD.
Repo: TBD (`github.com/<you>/mcp-ssh-live`).