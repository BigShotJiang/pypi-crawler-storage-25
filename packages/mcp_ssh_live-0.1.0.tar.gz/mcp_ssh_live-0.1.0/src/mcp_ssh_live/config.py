"""Configuration for mcp-ssh-live.

Handles:

* Host configuration (one or many hosts).
* CLI argument parsing (Typer-based) with multi-host support.
* Optional TOML config file loading (``~/.config/mcp-ssh-live/config.toml``
  by default, or explicit ``--config``).
* Environment variable resolution for passwords (``--password-env``).
* Precedence: CLI > env > TOML > built-in defaults.

See ``SPEC.md`` §"Configuration" for the full design.
"""

from __future__ import annotations

import logging
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

# tomllib is stdlib from Python 3.11+. Fall back to tomli on 3.10.
try:  # pragma: no cover - trivial import shim
    import tomllib as _tomllib  # type: ignore[attr-defined]
except ModuleNotFoundError:  # pragma: no cover - 3.10 fallback
    import tomli as _tomllib  # type: ignore[no-redef]


log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Built-in defaults (see SPEC.md §"Configuration" → limits)
# ---------------------------------------------------------------------------

DEFAULT_SSH_PORT = 22
DEFAULT_RING_BUFFER_LINES = 10_000
DEFAULT_MAX_JOBS_PER_HOST = 50
DEFAULT_MAX_INLINE_CHARS = 65_536
DEFAULT_REAP_FINISHED_AFTER_SEC = 600
DEFAULT_EXEC_TIMEOUT_MS = 60_000
DEFAULT_RECONNECT_RETRIES = 3
DEFAULT_RECONNECT_DELAY_SEC = 2.0

DEFAULT_CONFIG_PATH = Path.home() / ".config" / "mcp-ssh-live" / "config.toml"


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class ConfigError(ValueError):
    """Raised when configuration is invalid or incomplete."""


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class HostConfig:
    """A single remote SSH target.

    One of ``password``/``password_env``/``key`` must be provided for
    authentication (``password`` is usually populated lazily from the env at
    load-time, never stored in TOML).
    """

    alias: str
    host: str
    port: int = DEFAULT_SSH_PORT
    user: str = "root"
    password: str | None = None
    password_env: str | None = None
    key: str | None = None  # path to private key
    key_passphrase_env: str | None = None

    def resolve_password(self) -> str | None:
        """Return the effective password, reading from env if needed."""
        if self.password is not None:
            return self.password
        if self.password_env:
            val = os.environ.get(self.password_env)
            if val is None:
                log.warning(
                    "Host %r: password_env=%r is not set in environment",
                    self.alias,
                    self.password_env,
                )
            return val
        return None

    def resolve_key_path(self) -> Path | None:
        """Return the expanded path to the private key, or None."""
        if not self.key:
            return None
        return Path(self.key).expanduser()

    def resolve_key_passphrase(self) -> str | None:
        if self.key_passphrase_env:
            return os.environ.get(self.key_passphrase_env)
        return None

    def validate(self) -> None:
        """Raise ConfigError if the host is missing required fields."""
        if not self.alias:
            raise ConfigError("host entry is missing an alias")
        if not self.host:
            raise ConfigError(f"host {self.alias!r}: 'host' is required")
        if self.port <= 0 or self.port > 65535:
            raise ConfigError(f"host {self.alias!r}: invalid port {self.port}")
        if not self.user:
            raise ConfigError(f"host {self.alias!r}: 'user' is required")
        if not self.password and not self.password_env and not self.key:
            raise ConfigError(
                f"host {self.alias!r}: one of password, password_env, or key is required"
            )
        key_path = self.resolve_key_path()
        if key_path is not None:
            if not key_path.exists():
                raise ConfigError(f"host {self.alias!r}: key file does not exist: {key_path}")
            # Warn (not fail) on world-readable keys (Windows lacks real perms).
            try:
                mode = key_path.stat().st_mode & 0o777
                if mode & 0o077:
                    log.warning(
                        "host %r: key file %s has permissive mode %o (recommend 0600)",
                        self.alias,
                        key_path,
                        mode,
                    )
            except OSError:
                pass


@dataclass
class Limits:
    """Resource caps. Corresponds to ``[limits]`` TOML section."""

    ring_buffer_lines: int = DEFAULT_RING_BUFFER_LINES
    max_jobs_per_host: int = DEFAULT_MAX_JOBS_PER_HOST
    max_inline_chars: int = DEFAULT_MAX_INLINE_CHARS
    reap_finished_after_sec: int = DEFAULT_REAP_FINISHED_AFTER_SEC
    exec_timeout_ms: int = DEFAULT_EXEC_TIMEOUT_MS
    reconnect_retries: int = DEFAULT_RECONNECT_RETRIES
    reconnect_delay_sec: float = DEFAULT_RECONNECT_DELAY_SEC


@dataclass
class AppConfig:
    """Top-level effective configuration.

    Populated by merging defaults, TOML, env, and CLI (in that order, latest
    wins).
    """

    hosts: dict[str, HostConfig] = field(default_factory=dict)
    default_host: str | None = None
    limits: Limits = field(default_factory=Limits)
    log_dir: Path | None = None  # opt-in disk mirror of job output
    insecure_auto_add_host_keys: bool = False
    known_hosts_path: Path | None = None  # None → paramiko default

    # ------------------------------------------------------------------ API

    def get_host(self, alias_or_none: str | None) -> HostConfig:
        """Resolve a host name (or None → default_host).

        Accepts either an alias registered in ``self.hosts`` or a raw
        ``host[:port]`` address that matches one of the registered hosts.
        """
        if alias_or_none is None:
            if self.default_host is None:
                if len(self.hosts) == 1:
                    return next(iter(self.hosts.values()))
                raise ConfigError(
                    "No host specified and no default_host configured "
                    f"(available: {sorted(self.hosts)})"
                )
            alias_or_none = self.default_host

        if alias_or_none in self.hosts:
            return self.hosts[alias_or_none]

        # Try matching by raw address.
        for hc in self.hosts.values():
            if hc.host == alias_or_none:
                return hc

        raise ConfigError(f"Unknown host {alias_or_none!r} (available: {sorted(self.hosts)})")

    def validate(self) -> None:
        # Empty hosts list is allowed — the server can start without any
        # pre-configured hosts and accept connections via the ssh_connect
        # tool at runtime. A TOML / CLI host list is still validated when
        # present so a typo in a pre-configured host fails loudly at boot.
        for hc in self.hosts.values():
            hc.validate()
        if self.default_host is not None and self.default_host not in self.hosts:
            raise ConfigError(
                f"default_host={self.default_host!r} not found in hosts "
                f"(available: {sorted(self.hosts)})"
            )


# ---------------------------------------------------------------------------
# TOML loading
# ---------------------------------------------------------------------------


def load_toml(path: Path) -> dict:
    """Load a TOML file into a raw dict. Returns {} if the file does not exist."""
    if not path.exists():
        return {}
    try:
        with path.open("rb") as f:
            return _tomllib.load(f)
    except OSError as e:
        raise ConfigError(f"cannot read config file {path}: {e}") from e
    except Exception as e:  # tomllib raises TOMLDecodeError
        raise ConfigError(f"invalid TOML in {path}: {e}") from e


def _host_from_toml(alias: str, raw: dict) -> HostConfig:
    if not isinstance(raw, dict):
        raise ConfigError(f"[hosts.{alias}] must be a table")
    try:
        return HostConfig(
            alias=alias,
            host=raw.get("host", ""),
            port=int(raw.get("port", DEFAULT_SSH_PORT)),
            user=raw.get("user", "root"),
            password=raw.get("password"),  # discouraged but allowed
            password_env=raw.get("password_env"),
            key=raw.get("key"),
            key_passphrase_env=raw.get("key_passphrase_env"),
        )
    except (TypeError, ValueError) as e:
        raise ConfigError(f"invalid [hosts.{alias}] entry: {e}") from e


def config_from_toml(data: dict) -> AppConfig:
    """Build an AppConfig from a raw TOML dict.

    Missing or unknown keys are ignored (but logged at DEBUG).
    """
    cfg = AppConfig()

    raw_hosts = data.get("hosts", {}) or {}
    if not isinstance(raw_hosts, dict):
        raise ConfigError("[hosts] must be a table of tables")
    for alias, raw in raw_hosts.items():
        cfg.hosts[alias] = _host_from_toml(alias, raw)

    default_host = data.get("default_host")
    if default_host is not None:
        cfg.default_host = str(default_host)

    raw_limits = data.get("limits", {}) or {}
    if not isinstance(raw_limits, dict):
        raise ConfigError("[limits] must be a table")
    cfg.limits = Limits(
        ring_buffer_lines=int(raw_limits.get("ring_buffer_lines", DEFAULT_RING_BUFFER_LINES)),
        max_jobs_per_host=int(raw_limits.get("max_jobs_per_host", DEFAULT_MAX_JOBS_PER_HOST)),
        max_inline_chars=int(raw_limits.get("max_inline_chars", DEFAULT_MAX_INLINE_CHARS)),
        reap_finished_after_sec=int(
            raw_limits.get("reap_finished_after_sec", DEFAULT_REAP_FINISHED_AFTER_SEC)
        ),
        exec_timeout_ms=int(raw_limits.get("exec_timeout_ms", DEFAULT_EXEC_TIMEOUT_MS)),
        reconnect_retries=int(raw_limits.get("reconnect_retries", DEFAULT_RECONNECT_RETRIES)),
        reconnect_delay_sec=float(
            raw_limits.get("reconnect_delay_sec", DEFAULT_RECONNECT_DELAY_SEC)
        ),
    )

    server_section = data.get("server", {}) or {}
    if isinstance(server_section, dict):
        ld = server_section.get("log_dir")
        if ld:
            cfg.log_dir = Path(str(ld)).expanduser()
        cfg.insecure_auto_add_host_keys = bool(server_section.get("insecure_auto_add", False))
        kh = server_section.get("known_hosts")
        if kh:
            cfg.known_hosts_path = Path(str(kh)).expanduser()

    return cfg


# ---------------------------------------------------------------------------
# CLI --host parsing
# ---------------------------------------------------------------------------


def parse_host_spec(spec: str) -> tuple[str, str, int]:
    """Parse a ``--host`` CLI value.

    Accepts:

    * ``1.2.3.4`` → alias="default", host="1.2.3.4", port=22
    * ``1.2.3.4:2222`` → alias="default", host="1.2.3.4", port=2222
    * ``prod=1.2.3.4`` → alias="prod", host="1.2.3.4", port=22
    * ``prod=1.2.3.4:2222`` → alias="prod", host="1.2.3.4", port=2222
    """
    spec = spec.strip()
    if not spec:
        raise ConfigError("--host value is empty")

    if "=" in spec:
        alias, rest = spec.split("=", 1)
        alias = alias.strip()
        rest = rest.strip()
        if not alias:
            raise ConfigError(f"--host {spec!r}: alias is empty")
    else:
        alias = "default"
        rest = spec

    if ":" in rest:
        host, port_str = rest.rsplit(":", 1)
        try:
            port = int(port_str)
        except ValueError as e:
            raise ConfigError(f"--host {spec!r}: invalid port {port_str!r}") from e
    else:
        host = rest
        port = DEFAULT_SSH_PORT

    if not host:
        raise ConfigError(f"--host {spec!r}: host is empty")

    return alias, host, port


# ---------------------------------------------------------------------------
# Merge CLI overrides into AppConfig
# ---------------------------------------------------------------------------


@dataclass
class CliOverrides:
    """Raw CLI flags, kept separate from AppConfig so precedence is explicit."""

    config_path: Path | None = None
    host_specs: list[str] = field(default_factory=list)
    user: str | None = None
    password_env: str | None = None
    key: str | None = None
    alias: str | None = None  # shorthand: name the single CLI host
    default_host: str | None = None
    log_dir: Path | None = None
    insecure_auto_add_host_keys: bool = False
    known_hosts_path: Path | None = None


def apply_cli_overrides(cfg: AppConfig, overrides: CliOverrides) -> AppConfig:
    """Merge CLI overrides into an already-loaded AppConfig.

    CLI ``--host`` entries always win over TOML entries with the same alias.
    If only one ``--host`` was given and ``--alias`` was set, the alias
    overrides whatever was parsed from the spec.
    """
    # --host ... (repeatable)
    if overrides.host_specs:
        parsed: list[HostConfig] = []
        for spec in overrides.host_specs:
            alias, host, port = parse_host_spec(spec)
            parsed.append(
                HostConfig(
                    alias=alias,
                    host=host,
                    port=port,
                    user=overrides.user or "root",
                    password_env=overrides.password_env,
                    key=overrides.key,
                )
            )

        # If exactly one --host AND --alias was given, rename it.
        if len(parsed) == 1 and overrides.alias:
            parsed[0].alias = overrides.alias

        # Detect duplicate aliases in CLI (would overwrite each other silently).
        seen: set[str] = set()
        for hc in parsed:
            if hc.alias in seen:
                raise ConfigError(
                    f"--host aliases must be unique; duplicate: {hc.alias!r}. "
                    "Use 'alias=host' form to disambiguate."
                )
            seen.add(hc.alias)

        for hc in parsed:
            cfg.hosts[hc.alias] = hc

        # If no default_host set yet and exactly one CLI host → use it.
        if cfg.default_host is None and len(parsed) == 1:
            cfg.default_host = parsed[0].alias

    if overrides.default_host is not None:
        cfg.default_host = overrides.default_host

    if overrides.log_dir is not None:
        cfg.log_dir = overrides.log_dir.expanduser()

    if overrides.insecure_auto_add_host_keys:
        cfg.insecure_auto_add_host_keys = True

    if overrides.known_hosts_path is not None:
        cfg.known_hosts_path = overrides.known_hosts_path.expanduser()

    return cfg


# ---------------------------------------------------------------------------
# Top-level loader
# ---------------------------------------------------------------------------


def load_config(overrides: CliOverrides) -> AppConfig:
    """Produce the final effective AppConfig.

    Order of precedence (latest wins):
        1. Built-in defaults (AppConfig dataclass defaults)
        2. TOML file (if found or explicitly given)
        3. Environment variables (resolved lazily on connect, not here)
        4. CLI flags
    """
    # 1 + 2: start from TOML (which itself starts from AppConfig defaults).
    toml_path = overrides.config_path
    if toml_path is None and DEFAULT_CONFIG_PATH.exists():
        toml_path = DEFAULT_CONFIG_PATH

    if toml_path is not None:
        log.info("Loading config from %s", toml_path)
        data = load_toml(toml_path)
        cfg = config_from_toml(data)
    else:
        cfg = AppConfig()

    # 4: CLI overrides.
    cfg = apply_cli_overrides(cfg, overrides)

    cfg.validate()
    return cfg


# ---------------------------------------------------------------------------
# Logging setup helper (stderr only — stdout is reserved for MCP JSON-RPC)
# ---------------------------------------------------------------------------


def configure_logging(level: str = "INFO") -> None:
    """Configure root logger to write to stderr only.

    MCP stdio transport uses stdout for JSON-RPC frames. Any write to stdout
    from our own logging would corrupt the protocol stream, so we pin the
    stream handler to stderr explicitly.
    """
    numeric = getattr(logging, level.upper(), logging.INFO)
    handler = logging.StreamHandler(stream=sys.stderr)
    handler.setFormatter(
        logging.Formatter(
            fmt="%(asctime)s %(levelname)s %(name)s: %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
        )
    )
    root = logging.getLogger()
    # Replace any pre-existing handlers to avoid accidental stdout leaks.
    root.handlers = [handler]
    root.setLevel(numeric)
