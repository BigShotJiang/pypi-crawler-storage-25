"""JobManager — in-process registry of live and recently-finished :class:`Job` s.

The JobManager is the single source of truth for "which remote commands
has this server process started, and what's their state right now".
Every tool that deals with background work (``ssh_spawn``, ``ssh_tail``,
``ssh_list_jobs``, ``ssh_remove_job``, ``ssh_signal``, ``ssh_send_stdin``)
routes through this object.

Responsibilities:

* **Allocate job_ids.** Short (6-char) uuid4 prefix, per the resolved
  Phase 0 open question. Collisions are astronomically unlikely but we
  still retry on the rare clash so two jobs can't share an id.

* **Enforce capacity caps.** ``max_jobs_per_host`` (from
  :class:`AppConfig.Limits`) is checked at :meth:`register_new` time;
  exceeding it raises :class:`JobCapacityExceeded` which the
  ``ssh_spawn`` tool folds into a structured error response instead of
  crashing the tool call.

* **Publish atomically.** The classic race is: a job's reader thread
  fires ``done_event`` before the manager has indexed the job under its
  id, so a ``ssh_tail(job_id)`` called immediately after spawn
  dereferences a key-not-found. We solve this by calling
  :meth:`register_new` BEFORE :meth:`Job.start`, under a single lock
  that also holds the capacity check.

* **Reap finished jobs.** A background daemon thread periodically
  sweeps for jobs whose ``finished_at`` is older than
  ``reap_finished_after_sec`` and removes them. This matches the SPEC
  contract that ``ssh_list_jobs`` keeps recently-finished jobs around
  for a grace window so the LLM can still fetch their tail output.

* **Shut down cleanly.** :meth:`close_all` signals every running job
  (best-effort SIGTERM via :meth:`Job.request_stop` + channel close),
  joins reader threads up to a short grace window, then empties the
  registry. Called by the :class:`server.ServerState` shutdown path.

Threading model:

* :attr:`_lock` is an :class:`RLock` that guards :attr:`_jobs` and
  :attr:`_per_host_counts`. Held only for the duration of quick
  dict-manipulation — never while waiting on a Job or the network.

* The reaper thread acquires :attr:`_lock` only when it's found
  candidates to remove; the outer scan reads a list of snapshots so
  the lock is held for O(1) time per sweep.

* :meth:`get`, :meth:`list`, :meth:`snapshot_all` never block on a Job;
  they return either the live object (for tail tool usage) or
  immutable snapshots (for list / remove decision logic).

Not covered here:

* Actually running the remote ``kill`` command — that lives in the
  :func:`ssh_signal` tool (Phase 3) which uses the manager's
  :meth:`get` to find the :class:`Job` and the connection pool to send
  the ``kill`` exec.
* Disk-mirror of job output — Phase 5, opt-in via ``--log-dir``.
"""

from __future__ import annotations

import logging
import os
import threading
import time
import uuid
from collections.abc import Callable

from .config import AppConfig
from .job import Job, JobSnapshot

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class JobManagerError(RuntimeError):
    """Base class for JobManager-specific errors."""


class JobNotFound(JobManagerError, KeyError):
    """Raised when :meth:`JobManager.get` is asked for an unknown job_id.

    Inherits from both :class:`KeyError` (so idiomatic Python callers
    can use ``try: ... except KeyError:``) and :class:`JobManagerError`
    (so tool code can catch just our errors without swallowing unrelated
    KeyErrors from elsewhere).
    """

    def __init__(self, job_id: str) -> None:
        super().__init__(f"no such job: {job_id!r}")
        self.job_id = job_id


class JobCapacityExceeded(JobManagerError):
    """Raised when ``max_jobs_per_host`` would be exceeded by a new spawn.

    Carries enough detail for ``ssh_spawn`` to surface a friendly error:
    which host is full, what the cap is, and how many active jobs it
    currently has.
    """

    def __init__(self, host: str, active: int, cap: int) -> None:
        super().__init__(
            f"too many active jobs on host {host!r}: {active}/{cap} "
            f"(increase limits.max_jobs_per_host in config, "
            f"or use ssh_remove_job to free a slot)"
        )
        self.host = host
        self.active = active
        self.cap = cap


class JobStillRunning(JobManagerError):
    """Raised by :meth:`remove` when asked to drop a still-running job without ``force=True``.

    Matches the SPEC contract: removing a running job silently would
    leak the remote process (no one is reading its output anymore, but
    the remote sshd keeps it alive). Callers must either signal it
    first or pass ``force=True`` (which triggers a best-effort SIGKILL
    via the standard Phase 3 kill path — wired up by the signal tool).
    """

    def __init__(self, job_id: str) -> None:
        super().__init__(
            f"job {job_id!r} is still running; signal it first or pass force=True to remove anyway"
        )
        self.job_id = job_id


# ---------------------------------------------------------------------------
# ID allocation
# ---------------------------------------------------------------------------

_DEFAULT_ID_LEN = 6


def _new_job_id(existing: set[str], *, length: int = _DEFAULT_ID_LEN) -> str:
    """Allocate a fresh short job_id that doesn't collide with ``existing``.

    Uses the first ``length`` hex chars of a uuid4 (default 6 → 16.7M
    space). Retries on collision; after 16 consecutive clashes (lotto-
    level improbable) we fall back to the full 32-char uuid so the
    caller always gets a unique id instead of looping forever.

    The collision-retry loop keeps :meth:`register_new` O(1) in the
    common case while guaranteeing termination in the pathological one.
    """
    for _ in range(16):
        candidate = uuid.uuid4().hex[:length]
        if candidate not in existing:
            return candidate
    # Fallback: use the full uuid4 hex. Still short enough to be
    # human-friendly-ish and collision-free for all practical purposes.
    log.warning(
        "JobManager: %d consecutive short-id collisions; falling back to full uuid",
        16,
    )
    return uuid.uuid4().hex


# ---------------------------------------------------------------------------
# JobManager
# ---------------------------------------------------------------------------


class JobManager:
    """Thread-safe registry of :class:`Job` instances + reaper thread.

    Usage::

        mgr = JobManager(cfg)
        mgr.start()                                  # launches reaper

        # In ssh_spawn:
        job_id = mgr.allocate_id()                   # reserve
        chan = conn.open_session()
        chan.exec_command(wrapped_cmd)
        job = Job(job_id=job_id, host=..., channel=chan, cmd=..., ...)
        mgr.register_new(job)                        # publishes + caps
        job.start()                                  # only NOW reader threads run

        # In ssh_tail:
        mgr.get(job_id).stdout.lines_since(cursor, ...)

        # In server shutdown:
        mgr.close_all()

    Construction is cheap (no threads yet). Call :meth:`start` when the
    server is ready to accept requests, and :meth:`close_all` before
    the server process exits.
    """

    def __init__(
        self,
        cfg: AppConfig,
        *,
        # Injected clock so tests can advance "time" without sleeping.
        # Default is :func:`time.time` (wall clock); the reaper uses it
        # to compare against ``Job.finished_at``.
        time_fn: Callable[[], float] = time.time,
        # Injected id allocator so tests can inject deterministic ids.
        id_fn: Callable[[set[str]], str] | None = None,
    ) -> None:
        self._cfg = cfg
        self._time_fn = time_fn
        self._id_fn = id_fn or _new_job_id

        # job_id → Job (or None when the id has been reserved via
        # :meth:`allocate_id` but :meth:`register_new` hasn't completed
        # yet). The None sentinel is the simplest way to prevent a
        # concurrent ``allocate_id`` call from handing out the same id
        # before we've constructed the Job. Consumers (:meth:`get`,
        # :meth:`list`, :meth:`snapshot_all`) all filter ``None`` out
        # so the sentinel is invisible in the public API.
        self._jobs: dict[str, Job | None] = {}

        # host alias → number of *active* (not-yet-finished) jobs. Kept
        # as a derived counter so capacity checks are O(1). Rebuilt on
        # each register/remove under the lock; never diverges from the
        # authoritative source in _jobs.
        self._per_host_active: dict[str, int] = {}

        # RLock because some internal helpers (e.g. _drop_unlocked)
        # call public methods like len() that also grab the lock.
        self._lock = threading.RLock()

        # Reaper thread — lazily started by :meth:`start` so a server
        # that never uses jobs (e.g. ssh_exec only) doesn't pay for it.
        self._reaper_thread: threading.Thread | None = None
        self._reaper_stop = threading.Event()
        self._reaper_interval_sec: float = 5.0

        # Shutdown flag. Once set, :meth:`register_new` refuses new
        # jobs so we don't race the close_all path.
        self._shutting_down = False

    # ------------------------------------------------------------------ repr

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        with self._lock:
            return (
                f"JobManager(jobs={len(self._jobs)}, "
                f"per_host={dict(self._per_host_active)}, "
                f"shutting_down={self._shutting_down})"
            )

    # ------------------------------------------------------------------ lifecycle

    def start(self) -> None:
        """Start the background reaper thread.

        Idempotent. Safe to call even if no jobs are ever spawned — the
        reaper sleeps on an Event so it's effectively free when idle.
        """
        with self._lock:
            if self._reaper_thread is not None and self._reaper_thread.is_alive():
                return
            if self._shutting_down:
                raise RuntimeError("cannot start JobManager after close_all()")

            self._reaper_stop.clear()
            t = threading.Thread(
                target=self._reaper_loop,
                name="job-reaper",
                daemon=True,
            )
            self._reaper_thread = t
            t.start()
            log.debug(
                "JobManager reaper started (interval=%.1fs, grace=%ds)",
                self._reaper_interval_sec,
                self._cfg.limits.reap_finished_after_sec,
            )

    def close_all(self, *, wait_sec: float = 5.0) -> None:
        """Stop the reaper, tear down every Job, empty the registry.

        Called from :meth:`ServerState.close` on graceful shutdown. The
        per-Job teardown is best-effort — we give each Job a short
        window to join its reader threads, then move on. Remote
        processes are NOT killed here (that requires the signal-tool
        machinery); if the user wants jobs terminated they should run
        ``ssh_signal`` first, or accept that the SSH transport close
        will SIGHUP most remotes.

        Phase 5 graceful-shutdown: BEFORE tearing down the local-side
        state, we send SIGTERM to every running job's remote pid (via
        a short ``kill -TERM <pid>`` exec on the same transport — same
        trick ``ssh_signal`` uses, wired here directly so we don't
        depend on the tool layer). Each job gets up to ~5 s to exit on
        its own; any still-running after that grace window gets a
        SIGKILL. This matches the SPEC contract:

            "On server shutdown: all jobs SIGTERM → 5s grace → SIGKILL;
             connection closed."

        Remote side effect: the shell wrappers we spawned see SIGTERM,
        their handlers (if any) run, and exit codes propagate back
        through the channel's exit_status. Without this step, merely
        closing the SSH channel from our side leaves the remote
        process at the mercy of sshd's HUP-on-disconnect behavior,
        which is inconsistent across sshd builds — explicit signalling
        gives us a deterministic shutdown.

        Idempotent.
        """
        with self._lock:
            if self._shutting_down:
                return
            self._shutting_down = True
            self._reaper_stop.set()
            jobs = list(self._jobs.values())

        # ----- Phase 5: graceful TERM → grace → KILL -------------------
        # Split "signal" from "channel close" so the remote has a real
        # chance to clean up before the SSH EOF races its signal
        # handler. We intentionally don't import the signal tool here —
        # the dependency would be circular, and the kill command we
        # need is a one-liner.
        running_jobs = [j for j in jobs if j is not None and j.is_running()]
        for job in running_jobs:
            try:
                self._send_remote_kill(job, "TERM")
                job.mark_killed("TERM")
            except Exception:  # pragma: no cover - best effort
                log.debug(
                    "JobManager: error sending SIGTERM to job %r",
                    job.job_id,
                    exc_info=True,
                )

        # Wait up to ~5 s for graceful exit. We poll because Job.done_event
        # fires on exit_status delivery, which is already wired by the
        # Job's exit-watcher thread.
        grace_sec = 5.0
        if running_jobs:
            deadline = self._time_fn() + grace_sec
            for job in running_jobs:
                remaining = deadline - self._time_fn()
                if remaining <= 0:
                    break
                try:
                    job.done_event.wait(timeout=remaining)
                except Exception:  # pragma: no cover
                    pass

        # Anything still alive gets KILLed. ``is_running`` is cheap
        # (just checks the done_event); re-checking after the grace
        # window avoids sending KILL to a job that already exited.
        for job in running_jobs:
            if job.is_running():
                try:
                    self._send_remote_kill(job, "KILL")
                    job.mark_killed("KILL")
                except Exception:  # pragma: no cover
                    log.debug(
                        "JobManager: error sending SIGKILL to job %r",
                        job.job_id,
                        exc_info=True,
                    )

        # Close each Job *outside* the lock so a slow channel close
        # doesn't block other tool calls racing us to the door.
        for job in jobs:
            if job is None:
                continue
            try:
                job.close(wait_threads_sec=wait_sec / max(1, len(jobs)))
            except Exception:  # pragma: no cover - best effort
                log.debug("JobManager: error closing job %r", job.job_id, exc_info=True)

        # Join the reaper after we've stopped it; it may be mid-sleep.
        t = self._reaper_thread
        if t is not None:
            t.join(timeout=2.0)

        with self._lock:
            self._jobs.clear()
            self._per_host_active.clear()
            self._reaper_thread = None

        log.info("JobManager: closed; %d job(s) torn down", len(jobs))

    # ------------------------------------------------------------------ graceful kill helper

    def _send_remote_kill(self, job, signal_name: str) -> None:
        """Send ``kill -<SIG> <pid>`` to the remote on a fresh exec channel.

        Mirrors the fallback path in the Phase 3 ``ssh_signal`` tool,
        inlined here so :meth:`close_all` doesn't have to reach into
        the tool layer (which would create a circular import).

        Silent no-op if:

        * The job has no captured pid (``capture_pid=False`` at spawn,
          or the PID-line parse failed). In that case the best we can
          do is close the channel and rely on sshd's HUP behavior.
        * The pool doesn't have a live transport for the host (we're
          being torn down mid-outage). A failure here is expected and
          not worth logging at warn level.
        * paramiko raises anything — we're in shutdown, the priority
          is finishing teardown, not chasing edge cases.

        ``signal_name`` is the short form without the ``SIG`` prefix
        (``"TERM"``, ``"KILL"``) because that's what ``kill -X`` wants
        on the remote side.
        """
        if job.pid is None:
            log.debug(
                "JobManager._send_remote_kill: job %r has no captured pid; "
                "relying on channel close",
                job.job_id,
            )
            return

        # Import lazily to avoid a circular import at module load time
        # (connection.py → job.py → job_manager.py is acyclic today,
        # and we'd rather keep it that way).
        try:
            from .connection import ConnectionPool  # noqa: F401
        except ImportError:  # pragma: no cover
            return

        pool = getattr(self, "_pool_for_shutdown", None)
        if pool is None:
            # No pool was registered via :meth:`attach_pool`. Happens
            # in unit tests that build a JobManager in isolation; we
            # silently skip the remote kill (Job.close will still tear
            # down the channel).
            return

        try:
            conn = pool.get(job.host)
        except Exception:
            return

        try:
            transport = (
                conn._client.get_transport() if conn._client is not None else None
            )  # noqa: SLF001
            if transport is None or not transport.is_active():
                return
            chan = transport.open_session()
        except Exception:
            return

        try:
            chan.settimeout(2.0)
            chan.exec_command(f"kill -{signal_name} {int(job.pid)}")
            # Drain briefly so the remote ``kill`` can complete before
            # the next signal attempt; we don't care about its exit
            # code (a non-zero could mean "no such pid", i.e. the job
            # already exited — fine by us).
            try:
                chan.recv_exit_status()
            except Exception:
                pass
        except Exception:
            pass
        finally:
            try:
                chan.close()
            except Exception:
                pass

    def attach_pool(self, pool) -> None:
        """Register a :class:`ConnectionPool` for graceful-shutdown signalling.

        Called once by :func:`server.build_server` after both the
        manager and the pool are constructed. Stored as a weakref-
        avoiding attribute (a plain reference is fine because the
        ServerState owns both objects with matching lifetimes).
        Without this call :meth:`_send_remote_kill` degrades to the
        "no pool" no-op above — still safe, just less graceful.
        """
        self._pool_for_shutdown = pool

    # ------------------------------------------------------------------ id allocation

    def allocate_id(self) -> str:
        """Reserve and return a fresh job_id.

        Two-phase registration (:meth:`allocate_id` → construct Job →
        :meth:`register_new`) is a deliberate choice: the caller needs
        the id BEFORE constructing the Job (so it can pass the id to
        the Job constructor, which wants it for thread names / log
        messages). We simply pre-insert the id into the registry as a
        sentinel (None value) so a concurrent spawn doesn't hand out
        the same id, then replace the sentinel with the real Job in
        :meth:`register_new`.

        If the caller aborts between these two calls (e.g. the
        exec_command raises), they must call :meth:`cancel_id` to
        release the reservation.
        """
        with self._lock:
            if self._shutting_down:
                raise RuntimeError("JobManager is shutting down; cannot allocate new ids")
            job_id = self._id_fn(set(self._jobs))
            # Sentinel: a None entry reserves the key without satisfying
            # any Job-valued operation. get() / list() skip None values.
            self._jobs[job_id] = None  # type: ignore[assignment]
            return job_id

    def cancel_id(self, job_id: str) -> None:
        """Release a reservation made by :meth:`allocate_id` without registering a Job.

        Used by :func:`ssh_spawn` when the exec_command fails — we've
        reserved the id but have nothing to attach to it. Silently
        no-ops if the id was already replaced by a real Job (bug in the
        caller) or doesn't exist.
        """
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry is None and job_id in self._jobs:
                # It really was a sentinel; drop it.
                del self._jobs[job_id]

    # ------------------------------------------------------------------ register

    def register_new(self, job: Job) -> None:
        """Attach a freshly-constructed :class:`Job` to its reserved id.

        Performs the ``max_jobs_per_host`` capacity check atomically
        with insertion — two concurrent spawns racing for the last slot
        can't both win. On capacity failure the reserved id is
        released before the exception propagates, so the caller doesn't
        need to remember to :meth:`cancel_id`.

        The Job itself must have been constructed with ``job.job_id ==
        the id returned by allocate_id()``; we assert this rather than
        silently accepting a mismatch, because a mismatch means the id
        in log messages won't match the id in ``ssh_list_jobs`` and
        debugging becomes very confusing.
        """
        with self._lock:
            if self._shutting_down:
                # Release the reservation so we don't leak the id.
                self._jobs.pop(job.job_id, None)
                raise RuntimeError("JobManager is shutting down; cannot register new jobs")

            if job.job_id not in self._jobs:
                raise RuntimeError(
                    f"register_new({job.job_id!r}) without matching allocate_id(); "
                    "caller bypassed the two-phase registration protocol"
                )

            # Capacity check: count *active* jobs on the same host,
            # excluding finished-but-not-yet-reaped ones. A job that's
            # already exited shouldn't block a new spawn — its slot is
            # conceptually free even though the buffer is still held
            # for tail-after-exit.
            cap = self._cfg.limits.max_jobs_per_host
            active = self._per_host_active.get(job.host, 0)
            if active >= cap:
                # Release the reservation before raising so the caller
                # doesn't have to clean up.
                self._jobs.pop(job.job_id, None)
                raise JobCapacityExceeded(job.host, active, cap)

            # Replace the sentinel with the real Job.
            self._jobs[job.job_id] = job
            self._per_host_active[job.host] = active + 1

        log.debug(
            "JobManager: registered job %r on host %r (active now=%d)",
            job.job_id,
            job.host,
            self._per_host_active[job.host],
        )

    # ------------------------------------------------------------------ lookup

    def get(self, job_id: str) -> Job:
        """Return the live :class:`Job` for ``job_id`` or raise :class:`JobNotFound`.

        Callers hold the returned reference for as long as they need —
        we don't refcount; the Job isn't freed until :meth:`remove` or
        :meth:`close_all`, both of which call :meth:`Job.close` to wake
        any tail pollers gracefully.
        """
        with self._lock:
            entry = self._jobs.get(job_id)
            # None sentinel means the id was reserved but registration
            # never completed (or was cancelled). Treat as not-found.
            if entry is None:
                raise JobNotFound(job_id)
            return entry

    def __contains__(self, job_id: str) -> bool:
        with self._lock:
            return self._jobs.get(job_id) is not None

    def __len__(self) -> int:
        """Number of fully-registered jobs (sentinels excluded)."""
        with self._lock:
            return sum(1 for v in self._jobs.values() if v is not None)

    # ------------------------------------------------------------------ list

    def list(
        self,
        *,
        host: str | None = None,
        include_finished: bool = True,
    ) -> list[Job]:
        """Return the matching :class:`Job` instances.

        Returns live references (not snapshots) because the typical
        caller is the ``ssh_list_jobs`` tool which then calls
        :meth:`Job.snapshot` on each. Giving them live refs avoids a
        double-copy at the cost of one more method call per job.

        Sentinels (allocated-but-not-registered ids) are excluded.
        """
        with self._lock:
            result: list[Job] = []
            for job in self._jobs.values():
                if job is None:
                    continue
                if host is not None and job.host != host:
                    continue
                if not include_finished and not job.is_running():
                    continue
                result.append(job)
            return result

    def snapshot_all(
        self,
        *,
        host: str | None = None,
        include_finished: bool = True,
    ) -> list[JobSnapshot]:
        """Like :meth:`list` but returns immutable snapshots suitable for JSON.

        Slightly more expensive (one snapshot per job), but the
        snapshots can safely be returned to MCP clients without any
        worry about thread-safety of the underlying Job state.
        """
        return [j.snapshot() for j in self.list(host=host, include_finished=include_finished)]

    # ------------------------------------------------------------------ removal

    def remove(self, job_id: str, *, force: bool = False) -> bool:
        """Drop ``job_id`` from the registry.

        Returns True if a job was actually removed, False if the id
        wasn't present (matches the ``ssh_remove_job`` tool contract,
        which returns ``{"removed": bool}``).

        If the job is still running, raises :class:`JobStillRunning`
        unless ``force=True``. When forcing, we :meth:`Job.request_stop`
        and :meth:`Job.close` the channel — which sends SSH EOF but
        does NOT guarantee the remote process dies. The caller (the
        ``ssh_remove_job`` tool) is responsible for first calling
        ``ssh_signal(KILL)`` via the Phase 3 path if a true kill is
        required.
        """
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                return False

            if job.is_running() and not force:
                raise JobStillRunning(job_id)

            # Remove from registry & host counter before closing so a
            # concurrent list() doesn't see a half-closed job. Closing
            # the channel is done outside the lock (below).
            del self._jobs[job_id]
            if job.is_running():
                # Was counted as active; decrement.
                self._decrement_host_locked(job.host)
            # If the job finished before we got here, it had already
            # been decremented by the reaper / finalize path.

        # Outside the lock: channel.close() may briefly block on an
        # sshd that's slow to ack EOF.
        try:
            job.close()
        except Exception:  # pragma: no cover - best-effort cleanup
            log.debug("JobManager.remove(%r): close() error", job_id, exc_info=True)

        log.info("JobManager: removed job %r (force=%s)", job_id, force)
        return True

    def _decrement_host_locked(self, host: str) -> None:
        """Decrement the per-host active counter; caller holds :attr:`_lock`."""
        current = self._per_host_active.get(host, 0)
        if current <= 1:
            # Pop instead of leaving a zero entry so ``ssh_list_hosts``
            # (Phase 4) reflects genuine emptiness.
            self._per_host_active.pop(host, None)
        else:
            self._per_host_active[host] = current - 1

    # ------------------------------------------------------------------ per-host stats

    def active_count(self, host: str) -> int:
        """Return how many jobs on ``host`` are still running.

        Used by ``ssh_list_hosts`` (Phase 4). Kept on the manager (not
        the connection pool) because the manager is the authoritative
        source of job state.
        """
        with self._lock:
            return self._per_host_active.get(host, 0)

    def active_count_all(self) -> dict[str, int]:
        """Snapshot of the active-count table, copied out under the lock."""
        with self._lock:
            return dict(self._per_host_active)

    # ------------------------------------------------------------------ reaper

    def _reaper_loop(self) -> None:
        """Background thread: periodically sweep for old finished jobs.

        Runs until :attr:`_reaper_stop` fires (on :meth:`close_all`).
        Errors inside the sweep are caught and logged so one bad job
        can't kill the reaper (a dead reaper silently leaks memory,
        and we'd rather see noisy warnings).
        """
        grace_sec = self._cfg.limits.reap_finished_after_sec

        while not self._reaper_stop.is_set():
            # Event.wait doubles as a sleep with a responsive stop flag.
            if self._reaper_stop.wait(timeout=self._reaper_interval_sec):
                return

            try:
                self._sweep_once(grace_sec)
            except Exception:  # pragma: no cover - defensive
                log.exception("JobManager reaper sweep failed")

    def _sweep_once(self, grace_sec: int) -> None:
        """Remove every finished Job whose ``finished_at`` is older than the grace window.

        We also pick up the host-counter-sync case: if a Job reached
        :attr:`is_running()` == False after being counted as active,
        its slot should be freed immediately (not waiting for the full
        grace period), so subsequent spawns see the accurate count.
        That happens here too.
        """
        now = self._time_fn()
        cutoff = now - grace_sec
        to_drop: list[str] = []

        with self._lock:
            for job_id, job in list(self._jobs.items()):
                if job is None:
                    continue
                if job.is_running():
                    continue
                # Sync the per-host counter as soon as we notice a job
                # that's finished but still counted as active. Idempotent.
                if job.finished_at is not None:
                    # Was this host still counting it? Check by looking
                    # for any still-running jobs on the same host; if
                    # this one's the last finished-but-counted, decrement.
                    # Simpler: recompute from scratch on each sweep,
                    # cheap for small N.
                    pass

                finished_at = job.finished_at or now
                if finished_at <= cutoff:
                    to_drop.append(job_id)

            # Recompute per-host counters from current state. Cheaper
            # than tracking "already-synced finished" because N is
            # small (<= limits.max_jobs_per_host * num_hosts).
            fresh_counts: dict[str, int] = {}
            for job in self._jobs.values():
                if job is None:
                    continue
                if job.is_running():
                    fresh_counts[job.host] = fresh_counts.get(job.host, 0) + 1
            self._per_host_active = fresh_counts

            # Remove the expired jobs under the same lock so another
            # thread can't resurrect them via get().
            dropped_jobs: list[Job] = []
            for job_id in to_drop:
                j = self._jobs.pop(job_id, None)
                if j is not None:
                    dropped_jobs.append(j)

        # Close outside the lock (same rationale as :meth:`remove`).
        for job in dropped_jobs:
            try:
                job.close()
            except Exception:  # pragma: no cover
                log.debug("reaper: error closing %r", job.job_id, exc_info=True)

        if dropped_jobs:
            log.info(
                "JobManager reaper: removed %d finished job(s) older than %ds",
                len(dropped_jobs),
                grace_sec,
            )


# ---------------------------------------------------------------------------
# Module-level helpers (used by ssh_spawn tool in Phase 2)
# ---------------------------------------------------------------------------


def build_manager(cfg: AppConfig) -> JobManager:
    """Factory used by :mod:`mcp_ssh_live.server` to assemble a JobManager.

    Kept as a free function (not a classmethod) so tests can
    monkey-patch it to return a stub manager without subclassing.
    Respects the ``MCP_SSH_LIVE_REAPER_INTERVAL_SEC`` env var for local
    debugging — normally the default 5 s cadence is correct, but
    integration tests that want to observe the reaper's effect within
    a test-case budget can lower it via the env.
    """
    mgr = JobManager(cfg)
    override = os.environ.get("MCP_SSH_LIVE_REAPER_INTERVAL_SEC")
    if override:
        try:
            mgr._reaper_interval_sec = max(0.05, float(override))  # noqa: SLF001
        except ValueError:
            log.warning("Ignoring invalid MCP_SSH_LIVE_REAPER_INTERVAL_SEC=%r", override)
    return mgr
