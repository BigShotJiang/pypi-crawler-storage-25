"""Line-numbered ring buffer for job output streams.

Why a custom type instead of a bare :class:`collections.deque`:

* We need **monotonic line numbers** that never reuse a value, even after
  the oldest lines are evicted. Callers of :func:`ssh_tail` remember the
  last ``line_no`` they saw and ask for "everything after N"; if line_no
  could reset or reuse, a tail loop that polls across a buffer rollover
  would silently duplicate or lose lines.

* We need to tell callers **when their cursor has fallen off the back**
  of the buffer (their ``since_line_no`` is older than our oldest kept
  line). ``ssh_tail`` returns ``buffer_truncated=True`` in that case so
  the LLM knows it missed output and can decide how to recover.

* We need a **condition variable** so ``ssh_tail(wait_ms=5000)`` can
  block efficiently until new lines arrive, instead of busy-polling. The
  condvar lives on the buffer (not on the Job) because multiple streams
  (stdout + stderr) share it — a poller waiting on either should wake up
  when either one appends.

Thread-safety: all public methods acquire an internal :class:`RLock`.
Multiple reader threads (one per stream) append concurrently; multiple
tail pollers may call :meth:`lines_since` / :meth:`wait_for_lines`
concurrently. The condvar wraps the same lock, so wake-ups are atomic
with respect to appends.

Line numbering scheme
---------------------

Line numbers are **per-job**, not per-stream — stdout line 7 and stderr
line 8 are adjacent in a unified timeline even though they live in
separate buffers. This matches how humans read interleaved output (a
stderr warning that follows a stdout progress print should have the
higher line_no) and matches the SPEC JobLine contract. The
:class:`LineCounter` singleton per Job allocates the numbers; each
:class:`RingBuffer` just records them.

A ``line_no`` of ``0`` is reserved to mean "before the first line ever
appended", so callers can pass ``since_line_no=0`` to request the full
buffer from the beginning without a special case.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from collections.abc import Iterable
from dataclasses import dataclass

# ---------------------------------------------------------------------------
# JobLine — the unit of buffered output
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class JobLine:
    """One line of output from a remote job.

    Immutable by design: once appended to the ring buffer, a line is never
    mutated. Snapshots returned by :meth:`RingBuffer.lines_since` can be
    safely shared between threads / serialized to JSON without copying.

    Attributes:
        line_no: Monotonic per-job index, allocated at append time. Never
            reused even after the oldest lines are evicted. Stable across
            the life of the Job.
        stream: ``"stdout"`` or ``"stderr"``. The ring buffer itself
            doesn't care which stream a line came from — that's the Job's
            concern — but we store it here so snapshots are
            self-describing for JSON serialization.
        ts: Unix epoch seconds (float) when the line was observed by the
            reader thread. Not the time the remote process *emitted* it;
            network buffering may delay this by tens of ms. Useful for
            rough latency measurements and for the log-to-disk mirror.
        text: The line contents, newline stripped. UTF-8 decoded with
            ``errors='replace'`` (so binary blobs degrade gracefully
            instead of crashing a reader thread). A trailing ``\\r`` is
            stripped when present, to normalize CRLF output from
            pty-allocated channels.
    """

    line_no: int
    stream: str  # "stdout" | "stderr"
    ts: float
    text: str


# ---------------------------------------------------------------------------
# LineCounter — shared monotonic source of line_no across a Job's streams
# ---------------------------------------------------------------------------


class LineCounter:
    """Thread-safe monotonic counter shared by a Job's stdout + stderr.

    Every :meth:`RingBuffer.append` call consumes one number from here.
    Separate Jobs get separate counters (their line_no spaces are
    independent); within one Job, both streams draw from the same counter
    so stdout line 7 and stderr line 8 reflect their true temporal order.

    ``next()`` returns 1 on the first call (0 is reserved as "before any
    line ever existed" for the ``since_line_no`` API).
    """

    __slots__ = ("_value", "_lock")

    def __init__(self) -> None:
        self._value = 0
        self._lock = threading.Lock()

    def next(self) -> int:
        with self._lock:
            self._value += 1
            return self._value

    def current(self) -> int:
        """Return the last-allocated value without advancing.

        Useful for ``ssh_list_jobs`` to report ``stdout_lines`` /
        ``stderr_lines`` without holding the buffer lock.
        """
        with self._lock:
            return self._value


# ---------------------------------------------------------------------------
# RingBuffer — the per-stream bounded deque with eviction-aware reads
# ---------------------------------------------------------------------------


class RingBuffer:
    """Bounded line-numbered buffer for one output stream of one job.

    Parameters:
        maxlen: Hard cap on retained lines. Older lines are silently
            evicted when the buffer is full. Default 10 000 matches SPEC.
        counter: Shared :class:`LineCounter` (see class docstring for why
            it's shared across streams). If ``None``, a fresh private
            counter is created — useful in tests.

    Public API:

    * :meth:`append` — record a new line, wake any waiters.
    * :meth:`lines_since` — snapshot of everything with line_no > cursor.
    * :meth:`wait_for_lines` — block up to ``timeout_sec`` for new lines
      after a cursor; designed for the ``ssh_tail(wait_ms=...)`` contract.
    * :meth:`oldest_line_no` / :meth:`newest_line_no` — cheap stats.
    * :meth:`is_truncated_since` — whether a cursor has fallen off the
      back.

    Not a public API:

    * The internal :class:`deque` and its :class:`Condition` lock are
      shared with :class:`RingBufferView` (see :meth:`view`) so a Job can
      expose a read-only handle without leaking the append side.
    """

    def __init__(
        self,
        *,
        maxlen: int = 10_000,
        counter: LineCounter | None = None,
    ) -> None:
        if maxlen <= 0:
            raise ValueError(f"ring buffer maxlen must be positive, got {maxlen}")

        self._deque: deque[JobLine] = deque(maxlen=maxlen)
        self._maxlen = maxlen
        self._counter = counter or LineCounter()
        # Tracks the line_no of the oldest line *ever* evicted, so
        # is_truncated_since() can answer correctly even when the buffer
        # is not currently full (e.g. after a user manually cleared it —
        # reserved for Phase 5).
        self._highest_evicted_line_no: int = 0

        # RLock-backed Condition so append+notify is atomic w.r.t. waiters
        # seeing the post-append state when they wake up.
        self._cond = threading.Condition(threading.RLock())

        # Synthetic-line marker support: when a reader thread observes
        # EOF / connection loss / exit, it can append a marker line and
        # call notify_done(), which releases every currently-blocked
        # tail poller so they return promptly with an up-to-date view.
        self._done = False

    # ------------------------------------------------------------------ stats

    @property
    def maxlen(self) -> int:
        return self._maxlen

    @property
    def counter(self) -> LineCounter:
        return self._counter

    def __len__(self) -> int:
        """Number of lines currently retained (not the total ever seen)."""
        with self._cond:
            return len(self._deque)

    def oldest_line_no(self) -> int | None:
        """line_no of the oldest retained line, or None if empty."""
        with self._cond:
            if not self._deque:
                return None
            return self._deque[0].line_no

    def newest_line_no(self) -> int | None:
        """line_no of the newest retained line, or None if empty."""
        with self._cond:
            if not self._deque:
                return None
            return self._deque[-1].line_no

    def is_done(self) -> bool:
        """True once :meth:`notify_done` has been called.

        Used by :meth:`wait_for_lines` to return early instead of waiting
        the full timeout when there will never be more lines.
        """
        with self._cond:
            return self._done

    def is_truncated_since(self, since_line_no: int) -> bool:
        """Return True if lines with ``line_no > since_line_no`` may have
        been evicted before the caller could read them.

        Specifically: if any line strictly newer than ``since_line_no``
        was evicted from this buffer, the caller's cursor has fallen off
        the back and the output they'd see via :meth:`lines_since` is
        incomplete. The tail tool surfaces this as ``buffer_truncated``
        so the LLM knows it lost output and can decide whether to bail /
        restart the job / accept the gap.

        A cursor *at or before* the oldest evicted line is only truncated
        if the buffer has ever evicted anything at all — otherwise the
        buffer still contains the complete history from line 1 onward
        and the cursor is just "behind" in the normal sense.
        """
        with self._cond:
            # Nothing's ever been evicted → never truncated.
            if self._highest_evicted_line_no == 0:
                return False
            # Cursor is newer than the last evicted line → nothing they
            # wanted has been dropped.
            if since_line_no >= self._highest_evicted_line_no:
                return False
            return True

    # ------------------------------------------------------------------ append

    def append(self, stream: str, text: str, *, ts: float | None = None) -> JobLine:
        """Record one line, wake any blocked tail pollers, return the JobLine.

        ``text`` is taken verbatim — the reader thread is responsible for
        splitting on ``\\n`` and stripping trailing ``\\r``. We don't
        re-split here because a JobLine is supposed to represent exactly
        one remote newline unit.

        ``ts`` defaults to the current wall-clock (``time.time()``);
        tests can pass a fixed value for determinism.
        """
        if ts is None:
            ts = time.time()

        line_no = self._counter.next()
        line = JobLine(line_no=line_no, stream=stream, ts=ts, text=text)

        with self._cond:
            # Capture what the deque is about to drop, so is_truncated_since
            # can keep track even after maxlen-driven eviction.
            if len(self._deque) == self._maxlen:
                evicted = self._deque[0]
                if evicted.line_no > self._highest_evicted_line_no:
                    self._highest_evicted_line_no = evicted.line_no
            self._deque.append(line)
            # notify_all because multiple tail callers may be waiting on
            # this same buffer and they're all interested.
            self._cond.notify_all()

        return line

    def notify_done(self) -> None:
        """Mark the buffer as complete (no more appends will come).

        Called by the Job's reader thread when it sees EOF, exit_status,
        or a fatal connection error. Wakes every blocked
        :meth:`wait_for_lines` so they return promptly with whatever they
        have instead of waiting the full timeout.

        Idempotent — calling twice is a no-op. Does NOT prevent further
        :meth:`append` calls (a reader thread may legitimately want to
        append a synthetic ``"[mcp-ssh-live: connection lost]"`` line
        *after* marking done); such appends still wake waiters.
        """
        with self._cond:
            self._done = True
            self._cond.notify_all()

    # ------------------------------------------------------------------ reads

    def lines_since(
        self,
        since_line_no: int,
        *,
        max_lines: int | None = None,
    ) -> list[JobLine]:
        """Return every retained line with ``line_no > since_line_no``.

        The result is a *copy* — callers can iterate / serialize it
        outside the lock without racing against further appends.

        ``max_lines`` caps the slice (returning the *oldest* matching
        lines). Callers who want the most recent N should look at the
        tail of :meth:`lines_since(0)`; we prefer oldest-first because
        the tail tool contract is "give me everything after my cursor,
        in order", and chopping from the front would hide the oldest
        unseen output.

        ``since_line_no=0`` returns the full retained buffer.
        Negative values are treated as ``0``.
        """
        if since_line_no < 0:
            since_line_no = 0

        with self._cond:
            # Fast-path: cursor is at or ahead of the newest line.
            if not self._deque or since_line_no >= self._deque[-1].line_no:
                return []

            # The deque is sorted by line_no (append-only), so we could
            # binary-search. But 10k is small and Python's bisect doesn't
            # support key= on deque; a linear scan from whichever end is
            # closer is simpler and fast enough.
            oldest_no = self._deque[0].line_no
            if since_line_no < oldest_no:
                # Cursor is behind the oldest retained line → return
                # everything we have. The caller separately asks
                # is_truncated_since() to learn they lost data.
                result: list[JobLine] = list(self._deque)
            else:
                # Scan from the back (typical case: cursor was recent).
                # Collect matches, then reverse.
                gathered: list[JobLine] = []
                for ln in reversed(self._deque):
                    if ln.line_no <= since_line_no:
                        break
                    gathered.append(ln)
                gathered.reverse()
                result = gathered

            if max_lines is not None and max_lines >= 0 and len(result) > max_lines:
                result = result[:max_lines]

            return result

    def wait_for_lines(
        self,
        since_line_no: int,
        *,
        timeout_sec: float,
    ) -> None:
        """Block up to ``timeout_sec`` waiting for a line newer than the cursor.

        Returns as soon as either:

        * a line with ``line_no > since_line_no`` exists in the buffer, or
        * :meth:`notify_done` has been called (no more lines are coming), or
        * the timeout expires.

        Does NOT return the lines — the caller follows up with
        :meth:`lines_since`. Splitting "wait" from "read" keeps the API
        symmetric with :func:`ssh_tail` which always reads afterwards,
        and makes it easy for tests to assert on wake-up timing without
        race-free snapshot capture.

        ``timeout_sec <= 0`` returns immediately (equivalent to a poll).
        A :class:`threading.Condition.wait_for` is used under the hood so
        spurious wake-ups don't cut the wait short.
        """
        if timeout_sec <= 0:
            return

        deadline = time.monotonic() + timeout_sec

        def _ready() -> bool:
            # Under the condvar lock by wait_for's contract.
            if self._done:
                return True
            if not self._deque:
                return False
            return self._deque[-1].line_no > since_line_no

        with self._cond:
            # Fast-path: already ready, don't touch the wait timer.
            if _ready():
                return

            # Loop to defend against spurious wake-ups and to honour the
            # absolute deadline across notify_all storms.
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return
                # Condition.wait_for accepts a predicate; it returns
                # True on predicate satisfaction, False on timeout.
                if self._cond.wait_for(_ready, timeout=remaining):
                    return

    # ------------------------------------------------------------------ views

    def view(self) -> RingBufferView:
        """Return a read-only handle suitable for handing to tool code.

        The view shares state with this buffer (zero-copy) but lacks
        :meth:`append` / :meth:`notify_done`, so tools can't accidentally
        corrupt a Job's output stream. Reader threads keep the write
        side; the JobManager publishes the view to tail / list callers.
        """
        return RingBufferView(self)


class RingBufferView:
    """Read-only façade over a :class:`RingBuffer`.

    Exposes every query method (``lines_since``, ``wait_for_lines``,
    length, line-no stats, truncation check) but no mutators. The view
    holds a strong reference to the underlying buffer, so as long as the
    view is alive the buffer can't be garbage-collected — in practice
    this is always the Job's lifetime.
    """

    __slots__ = ("_buf",)

    def __init__(self, buf: RingBuffer) -> None:
        self._buf = buf

    # Stats ----------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._buf)

    @property
    def maxlen(self) -> int:
        return self._buf.maxlen

    def oldest_line_no(self) -> int | None:
        return self._buf.oldest_line_no()

    def newest_line_no(self) -> int | None:
        return self._buf.newest_line_no()

    def is_done(self) -> bool:
        return self._buf.is_done()

    def is_truncated_since(self, since_line_no: int) -> bool:
        return self._buf.is_truncated_since(since_line_no)

    # Reads ----------------------------------------------------------------

    def lines_since(
        self,
        since_line_no: int,
        *,
        max_lines: int | None = None,
    ) -> list[JobLine]:
        return self._buf.lines_since(since_line_no, max_lines=max_lines)

    def wait_for_lines(self, since_line_no: int, *, timeout_sec: float) -> None:
        self._buf.wait_for_lines(since_line_no, timeout_sec=timeout_sec)


# ---------------------------------------------------------------------------
# Utility: merge two buffers' snapshots into a single ordered list
# ---------------------------------------------------------------------------


def merge_sorted_by_line_no(
    streams: Iterable[Iterable[JobLine]],
    *,
    max_lines: int | None = None,
) -> list[JobLine]:
    """Merge multiple already-sorted JobLine iterables into one ordered list.

    Used by the ``ssh_tail(stream="both")`` path, which pulls a snapshot
    from stdout and stderr buffers independently and then needs to
    present them to the LLM in chronological (line_no) order so an error
    that interleaved a progress print still appears in the right place.

    We don't use :func:`heapq.merge` because:

    * We want a concrete list (JSON-serialized downstream).
    * ``max_lines`` lets us stop early without materializing the full
      merged sequence.
    * The input sizes are small (<=10k each) so the constant-factor
      overhead of a pairwise merge is negligible and the code is
      obviously correct.
    """
    materialized: list[list[JobLine]] = [list(s) for s in streams]

    # Combine into one list, stable-sort by line_no. Python's sort is
    # Timsort which is O(n) for already-sorted runs, so concatenating
    # pre-sorted lists and re-sorting is effectively a merge here.
    combined: list[JobLine] = []
    for s in materialized:
        combined.extend(s)
    combined.sort(key=lambda ln: ln.line_no)

    if max_lines is not None and max_lines >= 0 and len(combined) > max_lines:
        combined = combined[:max_lines]

    return combined
