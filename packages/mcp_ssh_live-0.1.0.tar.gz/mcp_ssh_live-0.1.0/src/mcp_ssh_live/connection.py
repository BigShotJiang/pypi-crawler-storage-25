"""SSH connection primitives for mcp-ssh-live.

Provides:

* :class:`SSHConnection` — a thin wrapper around :class:`paramiko.SSHClient`
  that owns a persistent transport to a single ``(host, port, user)`` tuple.
  Exposes :meth:`exec` (synchronous one-shot command with timeout+kill) and
  :meth:`open_session` (for the Job reader threads to take ownership of a
  long-running channel — wired up in Phase 2).
* :class:`ConnectionPool` — lazy cache of ``SSHConnection`` keyed by host
  alias. In Phase 1 we only ever create one entry, but the class is
  designed for the Phase 4 multi-host world.

Design decisions (see ``SPEC.md`` for rationale):

* One :class:`paramiko.SSHClient` per unique ``(host, port, user)``. Paramiko's
  underlying ``Transport`` supports many concurrent channels, so all jobs
  on the same host share one TCP/SSH handshake.
* ``known_hosts`` is enforced by default via ``RejectPolicy``. The user can
  opt-in to ``AutoAddPolicy`` with ``--insecure-auto-add``.
* ``exec()`` implements the SPEC contract: run a command with a wall-clock
  timeout, and if it overruns, first ``TERM`` then (after 5 s grace) ``KILL``
  the remote process via a second short exec using the PID trick.
* All logging goes through :mod:`logging`, which our main module has pinned
  to stderr (stdout is the MCP JSON-RPC stream).
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from pathlib import Path

import paramiko

from .config import HostConfig

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class SSHError(RuntimeError):
    """Base class for mcp-ssh-live SSH errors."""


class SSHConnectError(SSHError):
    """Raised when we cannot establish an SSH session."""


class SSHExecTimeout(SSHError):
    """Raised when a synchronous exec exceeds its wall-clock timeout.

    Carries whatever stdout/stderr we managed to capture before killing the
    remote process, so callers can still surface partial output.
    """

    def __init__(
        self,
        message: str,
        stdout: str = "",
        stderr: str = "",
        duration_ms: int = 0,
        killed: bool = False,
    ) -> None:
        super().__init__(message)
        self.stdout = stdout
        self.stderr = stderr
        self.duration_ms = duration_ms
        self.killed = killed


# ---------------------------------------------------------------------------
# Result type for exec()
# ---------------------------------------------------------------------------


@dataclass
class ExecResult:
    """Outcome of :meth:`SSHConnection.exec`."""

    stdout: str
    stderr: str
    exit_status: int
    duration_ms: int
    # True if the remote process was killed because it overran ``timeout_ms``.
    timed_out: bool = False


# ---------------------------------------------------------------------------
# Wrapper: build the "echo PID=$$; exec <cmd>" shell prefix
# ---------------------------------------------------------------------------


def build_pid_wrapper(
    cmd: str,
    *,
    cwd: str | None = None,
    env: dict[str, str] | None = None,
) -> str:
    """Wrap ``cmd`` so that the remote bash prints ``PID=<pid>`` on stdout
    before ``exec``-ing into the user's command.

    The resulting string is intended to be passed to
    :meth:`paramiko.SSHClient.exec_command` with a login-ish bash. The
    ``exec`` means the outer shell is *replaced* by an **inner** ``bash -c
    "<user cmd>"``, so:

    * The PID we printed (``$$`` of the outer bash) is preserved across the
      ``exec``, and becomes the PID of the inner bash that actually runs
      the user's command. Killing that PID terminates the whole subtree.
    * The user's command can use arbitrary shell syntax (``&&``, ``;``,
      ``|``, subshells, heredocs…) because it's evaluated by the inner
      bash as a full script, not as the argv of ``exec``.

    Why the two-level wrapping (outer ``bash -c`` + inner ``bash -c``):

    A naive ``exec <user cmd>`` would parse ``&&``/``;``/``|`` at the
    *outer* shell, which means anything after the first simple command
    never runs (the outer shell is gone after ``exec`` succeeds). Example:
    ``exec hostname && whoami`` prints only ``hostname`` — ``whoami`` is
    silently dropped. Wrapping the user cmd in ``bash -c "..."`` delegates
    the whole compound expression to a fresh shell that *does* stick
    around to run it.

    ``cwd`` and ``env`` are rendered as shell prefix statements in the
    outer shell (so they apply before the inner bash inherits them).

    Example::

        build_pid_wrapper("hostname && whoami", cwd="/opt/app",
                          env={"FOO": "bar"})

    produces (conceptually)::

        bash -c 'cd "/opt/app" && export FOO="bar" && echo PID=$$ && exec bash -c "hostname && whoami"'

    Note: we intentionally do NOT shell-escape the user command itself.
    The LLM supplies the command verbatim; it is the caller's responsibility
    to construct a valid shell fragment (per SPEC "Security" section). We
    do, however, escape embedded double quotes so the inner ``bash -c "..."``
    string literal stays syntactically valid — users who need literal ``"``
    inside their command can still get them via ``\"``.
    """
    prelude_parts: list[str] = []
    if cwd:
        # Quote cwd with double quotes; callers shouldn't put " in cwd.
        safe_cwd = cwd.replace('"', '\\"')
        prelude_parts.append(f'cd "{safe_cwd}"')
    if env:
        for k, v in env.items():
            if not _is_safe_env_name(k):
                raise ValueError(f"unsafe env var name: {k!r}")
            safe_v = v.replace('"', '\\"')
            prelude_parts.append(f'export {k}="{safe_v}"')
    prelude_parts.append("echo PID=$$")

    # Inner ``bash -c "..."`` wraps the user's command so compound shell
    # constructs survive the outer ``exec``. We need to escape FOUR things
    # so the outer shell doesn't mangle the inner script before the inner
    # bash ever sees it — and so the inner bash still interprets the user's
    # intent correctly:
    #
    # 1. ``\``  → ``\\``   (must be first; later escapes produce backslashes
    #                       that mustn't re-escape themselves)
    # 2. ``"``  → ``\"``    (keeps the inner double-quoted string literal
    #                       syntactically valid)
    # 3. ``$``  → ``\$``    (**critical**: without this, the OUTER bash
    #                       performs parameter expansion on the inner
    #                       script before passing it to ``bash -c``. A
    #                       user command like ``read a; echo $a`` would
    #                       arrive at the inner bash as ``read a; echo ``
    #                       because ``$a`` was empty in the outer shell.
    #                       This bit us in Phase 3 stdin tests: the inner
    #                       ``read`` succeeded, but the echoed variables
    #                       were already stripped out by the outer shell.)
    # 4. `` ` `` → ``\```   (same rationale as ``$``: backticks trigger
    #                       command substitution in the outer shell, which
    #                       would execute user code at the wrong level).
    #
    # After this the inner bash receives the ORIGINAL user command byte-
    # for-byte, modulo the fact that bash's own double-quoted parsing
    # then un-escapes ``\$`` back to ``$`` and ``\``` back to `` ` `` —
    # exactly what we want for a transparent pass-through.
    inner_quoted = (
        cmd.replace("\\", "\\\\").replace('"', '\\"').replace("$", "\\$").replace("`", "\\`")
    )
    prelude_parts_with_exec = prelude_parts + [f'exec bash -c "{inner_quoted}"']

    full = " && ".join(prelude_parts_with_exec)

    # Wrap as bash -c '...'. Single-quote the whole thing; escape embedded
    # single quotes by closing, inserting \', reopening.
    return "bash -c " + _single_quote(full)


def _is_safe_env_name(name: str) -> bool:
    if not name:
        return False
    if not (name[0].isalpha() or name[0] == "_"):
        return False
    return all(c.isalnum() or c == "_" for c in name)


def _single_quote(s: str) -> str:
    return "'" + s.replace("'", "'\\''") + "'"


# ---------------------------------------------------------------------------
# SSHConnection
# ---------------------------------------------------------------------------


class SSHConnection:
    """A persistent SSH connection to a single remote host.

    Thread-safe for concurrent ``exec()`` calls and channel opens, because
    paramiko's Transport supports it. The :attr:`_lock` serializes connect /
    disconnect only.
    """

    def __init__(
        self,
        host_cfg: HostConfig,
        *,
        known_hosts_path: Path | None = None,
        insecure_auto_add: bool = False,
        connect_timeout_sec: float = 15.0,
        reconnect_retries: int = 3,
        reconnect_delay_sec: float = 2.0,
    ) -> None:
        self.cfg = host_cfg
        self._known_hosts_path = known_hosts_path
        self._insecure_auto_add = insecure_auto_add
        self._connect_timeout = connect_timeout_sec
        # Phase 5: how many times connect_with_retries() will retry on
        # transient failures, and how long it sleeps between tries.
        # Exposed on the constructor so ConnectionPool can propagate
        # AppConfig.limits.reconnect_* here; a per-instance override
        # (tests, ad-hoc debugging) remains possible.
        self._reconnect_retries = max(0, reconnect_retries)
        self._reconnect_delay_sec = max(0.0, reconnect_delay_sec)

        self._client: paramiko.SSHClient | None = None
        self._lock = threading.RLock()

    # ------------------------------------------------------------------ repr

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        return (
            f"SSHConnection(alias={self.cfg.alias!r}, "
            f"host={self.cfg.host!r}, port={self.cfg.port}, "
            f"user={self.cfg.user!r}, connected={self.is_connected()})"
        )

    # ------------------------------------------------------------------ state

    def is_connected(self) -> bool:
        """Return True if the underlying transport is alive."""
        with self._lock:
            if self._client is None:
                return False
            t = self._client.get_transport()
            return bool(t and t.is_active())

    # ------------------------------------------------------------------ connect

    def connect(self) -> None:
        """Open the SSH transport (idempotent).

        Raises :class:`SSHConnectError` on failure.
        """
        with self._lock:
            if self.is_connected():
                return

            client = paramiko.SSHClient()

            # Host-key policy: either load known_hosts and reject unknowns,
            # or auto-add (insecure, explicit opt-in).
            if self._insecure_auto_add:
                log.warning(
                    "Host %r: --insecure-auto-add enabled; host key will be auto-accepted",
                    self.cfg.alias,
                )
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            else:
                # Load the user's known_hosts (or the one they specified).
                try:
                    if self._known_hosts_path is not None:
                        client.load_host_keys(str(self._known_hosts_path))
                    else:
                        client.load_system_host_keys()
                except OSError as e:
                    # Not fatal; paramiko will still refuse unknown keys below.
                    log.debug("could not load known_hosts: %s", e)
                client.set_missing_host_key_policy(paramiko.RejectPolicy())

            password = self.cfg.resolve_password()
            key_path = self.cfg.resolve_key_path()
            key_passphrase = self.cfg.resolve_key_passphrase()

            connect_kwargs: dict = {
                "hostname": self.cfg.host,
                "port": self.cfg.port,
                "username": self.cfg.user,
                "timeout": self._connect_timeout,
                "allow_agent": key_path is None and password is None,
                "look_for_keys": key_path is None and password is None,
            }
            if key_path is not None:
                connect_kwargs["key_filename"] = str(key_path)
                if key_passphrase is not None:
                    connect_kwargs["passphrase"] = key_passphrase
            if password is not None:
                connect_kwargs["password"] = password

            log.info(
                "Connecting to %s@%s:%d (alias=%r, auth=%s)",
                self.cfg.user,
                self.cfg.host,
                self.cfg.port,
                self.cfg.alias,
                "key" if key_path else ("password" if password else "agent"),
            )

            try:
                client.connect(**connect_kwargs)
            except paramiko.AuthenticationException as e:
                client.close()
                raise SSHConnectError(
                    f"authentication failed for {self.cfg.user}@{self.cfg.host}: {e}"
                ) from e
            except paramiko.SSHException as e:
                client.close()
                raise SSHConnectError(
                    f"SSH protocol error for {self.cfg.user}@{self.cfg.host}: {e}"
                ) from e
            except OSError as e:
                client.close()
                raise SSHConnectError(f"cannot reach {self.cfg.host}:{self.cfg.port}: {e}") from e

            # Keep the transport alive under NAT / idle firewalls.
            t = client.get_transport()
            if t is not None:
                t.set_keepalive(30)

            self._client = client
            log.info("Connected: %s", self)

    def close(self) -> None:
        """Close the transport (safe to call repeatedly)."""
        with self._lock:
            if self._client is not None:
                try:
                    self._client.close()
                except Exception:  # pragma: no cover
                    log.debug("error closing SSH client", exc_info=True)
                self._client = None

    # ------------------------------------------------------------------ reconnect

    def connect_with_retries(
        self,
        *,
        retries: int | None = None,
        delay_sec: float | None = None,
    ) -> None:
        """Open the transport with bounded retries on transient failures.

        Phase 5 entry point: wherever we previously called
        :meth:`connect` directly from a hot path (tool handlers, job
        spawn, SFTP open), we route through here so a transient network
        hiccup or a freshly-rebooted sshd gets a few attempts before we
        surface an error to the caller.

        Retry policy:

        * Total attempts = ``retries + 1`` (the first attempt is not a
          retry). Default comes from :attr:`_reconnect_retries`, which
          the :class:`ConnectionPool` seeds from
          :attr:`AppConfig.limits.reconnect_retries`.
        * Delay between attempts is a fixed :attr:`_reconnect_delay_sec`
          seconds (no exponential backoff — we're optimising for "server
          just rebooted, takes a few seconds to accept TCP" rather than
          for a long outage). Jitter would help under thundering-herd
          conditions but we're a single-client library.
        * Only :class:`SSHConnectError` triggers a retry. Anything else
          (e.g. a :class:`ValueError` from a malformed host config)
          propagates immediately — retrying a programmer error is just
          noise.

        If every attempt fails, the last :class:`SSHConnectError` is
        re-raised with a slightly enriched message noting the retry
        count, so the caller's log / structured-error response makes
        it obvious this wasn't a first-try failure.
        """
        if self.is_connected():
            return

        effective_retries = self._reconnect_retries if retries is None else max(0, retries)
        effective_delay = self._reconnect_delay_sec if delay_sec is None else max(0.0, delay_sec)

        last_error: SSHConnectError | None = None
        attempts = effective_retries + 1

        for attempt_no in range(1, attempts + 1):
            try:
                self.connect()
                if attempt_no > 1:
                    log.info(
                        "SSHConnection[%s]: reconnected on attempt %d/%d",
                        self.cfg.alias,
                        attempt_no,
                        attempts,
                    )
                return
            except SSHConnectError as e:
                last_error = e
                if attempt_no >= attempts:
                    break
                log.warning(
                    "SSHConnection[%s]: attempt %d/%d failed: %s; retrying in %.1fs",
                    self.cfg.alias,
                    attempt_no,
                    attempts,
                    e,
                    effective_delay,
                )
                if effective_delay > 0:
                    time.sleep(effective_delay)

        # Exhausted retries. Re-raise with context so log lines show
        # "after N attempts" rather than a single-try failure.
        assert last_error is not None  # unreachable without at least one exception
        raise SSHConnectError(
            f"could not connect to {self.cfg.user}@{self.cfg.host}:{self.cfg.port} "
            f"after {attempts} attempt(s): {last_error}"
        ) from last_error

    # ------------------------------------------------------------------ low-level

    def _ensure_client(self) -> paramiko.SSHClient:
        """Return the paramiko client, reconnecting with retries if needed.

        Every internal code path that needs a live transport goes
        through here (``exec`` / ``open_session`` / ``open_sftp``), so
        bolting the retry logic in at this choke point covers all
        tool handlers uniformly. Callers that explicitly want a
        single-shot connect can still invoke :meth:`connect` directly.
        """
        if not self.is_connected():
            self.connect_with_retries()
        assert self._client is not None  # for type checkers
        return self._client

    def open_session(self) -> paramiko.Channel:
        """Open a fresh exec channel on the transport.

        Callers are responsible for closing it. Used by Phase 2 Job machinery.
        """
        client = self._ensure_client()
        transport = client.get_transport()
        if transport is None or not transport.is_active():
            raise SSHConnectError(f"transport for {self.cfg.alias!r} is not active")
        return transport.open_session()

    def open_sftp(self) -> paramiko.SFTPClient:
        """Open a fresh SFTP subsystem channel on the transport.

        Used by the Phase 4 ``ssh_upload`` / ``ssh_download`` tools. Each
        call returns a NEW :class:`paramiko.SFTPClient`; callers are
        responsible for ``close()``-ing it when done. We don't cache a
        shared SFTP client because:

        * paramiko's SFTPClient is not documented as thread-safe; two
          concurrent uploads on one client can interleave their SSH_FXP
          request ids in buggy ways on some server builds.
        * Opening a new SFTP subsystem is cheap (one SSH_MSG_CHANNEL_OPEN
          + one subsystem request) — a handful of ms against a healthy
          sshd, negligible against the file I/O that follows.
        * A short-lived client makes cleanup trivial: wrap in
          ``with ... as sftp:`` or try/finally and be done.

        paramiko's :meth:`SSHClient.open_sftp` does exactly this under
        the hood (it creates a new Transport channel + SFTPClient each
        call), so we delegate instead of rolling our own. The tiny
        wrapper exists only so error surface is consistent with
        :meth:`exec` / :meth:`open_session` (same SSHConnectError type
        on a dead transport).
        """
        client = self._ensure_client()
        transport = client.get_transport()
        if transport is None or not transport.is_active():
            raise SSHConnectError(f"transport for {self.cfg.alias!r} is not active")
        try:
            return client.open_sftp()
        except paramiko.SSHException as e:
            # E.g. remote sshd has disabled the sftp subsystem, or the
            # server went away mid-request. Surface as our own error so
            # the tool layer can fold it into the structured response.
            raise SSHConnectError(f"cannot open SFTP subsystem on {self.cfg.alias!r}: {e}") from e

    # ------------------------------------------------------------------ exec

    def exec(
        self,
        command: str,
        *,
        timeout_ms: int = 60_000,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
        capture_pid: bool = True,
        pty: bool = False,
    ) -> ExecResult:
        """Run ``command`` synchronously and return its output.

        The command is wrapped with the PID-capture prelude (unless
        ``capture_pid=False``), so we can kill it on timeout via
        ``kill -TERM/-KILL`` on a separate short session. This sidesteps the
        fact that OpenSSH's sshd commonly ignores ``channel.send_signal``.

        On timeout: we first send SIGTERM, wait 5 seconds, then SIGKILL,
        and raise :class:`SSHExecTimeout` with whatever output we captured.

        Args:
            command: remote shell fragment.
            timeout_ms: wall-clock budget; <=0 means "no timeout".
            cwd: optional remote working directory.
            env: optional environment overrides (applied via ``export``).
            capture_pid: wrap the command so we can kill it by PID on timeout.
            pty: allocate a remote pseudo-TTY. Useful for line-buffered output,
                but causes stdout and stderr to be merged by the kernel.
        """
        client = self._ensure_client()

        if capture_pid:
            wrapped = build_pid_wrapper(command, cwd=cwd, env=env)
        else:
            # No wrapper → no PID, so no timeout-kill; log a warning if a
            # timeout was requested anyway.
            if timeout_ms and timeout_ms > 0:
                log.debug(
                    "exec(capture_pid=False) with timeout=%d ms: kill-on-timeout disabled",
                    timeout_ms,
                )
            wrapped = _compose_plain(command, cwd=cwd, env=env)

        transport = client.get_transport()
        if transport is None or not transport.is_active():
            raise SSHConnectError(f"transport for {self.cfg.alias!r} is not active")

        channel = transport.open_session()
        try:
            if pty:
                channel.get_pty()
            # Use a short per-recv timeout so our loop can check wall-clock
            # and react to timeouts / disconnects promptly.
            channel.settimeout(0.5)

            t0 = time.monotonic()
            channel.exec_command(wrapped)

            deadline: float | None
            if timeout_ms and timeout_ms > 0:
                deadline = t0 + (timeout_ms / 1000.0)
            else:
                deadline = None

            stdout_buf: list[bytes] = []
            stderr_buf: list[bytes] = []
            pid: int | None = None
            pid_line_stripped = False
            pid_carry = b""  # partial first line while hunting for PID=

            timed_out = False

            while True:
                # Pull whatever is ready on both streams.
                progressed = False
                if channel.recv_ready():
                    chunk = channel.recv(65536)
                    if chunk:
                        progressed = True
                        if capture_pid and not pid_line_stripped:
                            pid, leftover, pid_line_stripped = _extract_pid(pid_carry + chunk)
                            if pid_line_stripped:
                                stdout_buf.append(leftover)
                                pid_carry = b""
                            else:
                                pid_carry = leftover
                        else:
                            stdout_buf.append(chunk)
                if channel.recv_stderr_ready():
                    chunk = channel.recv_stderr(65536)
                    if chunk:
                        progressed = True
                        stderr_buf.append(chunk)

                if channel.exit_status_ready() and not (
                    channel.recv_ready() or channel.recv_stderr_ready()
                ):
                    break

                if deadline is not None and time.monotonic() >= deadline:
                    timed_out = True
                    break

                if not progressed:
                    # Nothing ready — sleep briefly to avoid busy-loop.
                    time.sleep(0.02)

            duration_ms = int((time.monotonic() - t0) * 1000)

            if timed_out:
                # Try to kill the remote process. We need a separate session;
                # the current one is stuck in the user's runaway command.
                if capture_pid and pid is not None:
                    log.warning(
                        "exec %r on %r timed out after %d ms; killing pid=%d",
                        _short(command),
                        self.cfg.alias,
                        duration_ms,
                        pid,
                    )
                    self._remote_kill(pid, "TERM")
                    # Give the user process 5 seconds to clean up.
                    grace_deadline = time.monotonic() + 5.0
                    while time.monotonic() < grace_deadline:
                        if channel.exit_status_ready():
                            break
                        time.sleep(0.1)
                    if not channel.exit_status_ready():
                        log.warning("pid=%d did not exit after SIGTERM; sending SIGKILL", pid)
                        self._remote_kill(pid, "KILL")
                else:
                    log.warning(
                        "exec %r on %r timed out after %d ms; no PID captured, cannot kill",
                        _short(command),
                        self.cfg.alias,
                        duration_ms,
                    )

                # Drain whatever is left so we don't lose final output.
                self._drain_remaining(
                    channel, stdout_buf, stderr_buf, pid_carry, capture_pid, pid_line_stripped
                )

                stdout_s = b"".join(stdout_buf).decode("utf-8", errors="replace")
                stderr_s = b"".join(stderr_buf).decode("utf-8", errors="replace")
                raise SSHExecTimeout(
                    f"command timed out after {timeout_ms} ms on host {self.cfg.alias!r}",
                    stdout=stdout_s,
                    stderr=stderr_s,
                    duration_ms=duration_ms,
                    killed=(capture_pid and pid is not None),
                )

            # Normal exit path: drain once more in case anything slipped in
            # between the exit_status check and our break.
            self._drain_remaining(
                channel, stdout_buf, stderr_buf, pid_carry, capture_pid, pid_line_stripped
            )

            exit_status = channel.recv_exit_status()
            stdout_s = b"".join(stdout_buf).decode("utf-8", errors="replace")
            stderr_s = b"".join(stderr_buf).decode("utf-8", errors="replace")

            return ExecResult(
                stdout=stdout_s,
                stderr=stderr_s,
                exit_status=exit_status,
                duration_ms=duration_ms,
                timed_out=False,
            )
        finally:
            try:
                channel.close()
            except Exception:  # pragma: no cover
                log.debug("error closing channel", exc_info=True)

    # ------------------------------------------------------------------ helpers

    def _drain_remaining(
        self,
        channel: paramiko.Channel,
        stdout_buf: list[bytes],
        stderr_buf: list[bytes],
        pid_carry: bytes,
        capture_pid: bool,
        pid_line_stripped: bool,
    ) -> None:
        """Drain any remaining bytes from a (possibly dying) channel.

        Best-effort; swallows socket.timeout.
        """
        # If we were still hunting for PID= and the process died before we
        # found it, flush what we had as stdout so we don't lose it.
        if capture_pid and not pid_line_stripped and pid_carry:
            stdout_buf.append(pid_carry)

        deadline = time.monotonic() + 0.5
        while time.monotonic() < deadline:
            progressed = False
            try:
                if channel.recv_ready():
                    chunk = channel.recv(65536)
                    if chunk:
                        stdout_buf.append(chunk)
                        progressed = True
                if channel.recv_stderr_ready():
                    chunk = channel.recv_stderr(65536)
                    if chunk:
                        stderr_buf.append(chunk)
                        progressed = True
            except TimeoutError:
                pass
            if not progressed:
                break

    def _remote_kill(self, pid: int, signal_name: str) -> None:
        """Send ``kill -SIGNAL pid`` on a fresh short session.

        Errors are logged and swallowed — the caller is already in a
        timeout-recovery path and we don't want to mask the original error.
        """
        try:
            client = self._ensure_client()
            transport = client.get_transport()
            if transport is None or not transport.is_active():
                log.warning("_remote_kill: transport inactive; skipping")
                return
            chan = transport.open_session()
            try:
                chan.settimeout(5.0)
                chan.exec_command(f"kill -{signal_name} {int(pid)}")
                # We don't really care about output, but drain briefly so the
                # server isn't left with an unread pipe.
                try:
                    chan.recv_exit_status()
                except Exception:
                    pass
            finally:
                try:
                    chan.close()
                except Exception:
                    pass
        except Exception as e:  # pragma: no cover - best-effort
            log.warning("remote kill pid=%d sig=%s failed: %s", pid, signal_name, e)


# ---------------------------------------------------------------------------
# Module-private helpers
# ---------------------------------------------------------------------------


def _compose_plain(
    cmd: str,
    *,
    cwd: str | None = None,
    env: dict[str, str] | None = None,
) -> str:
    """Like :func:`build_pid_wrapper` but without the PID echo / exec.

    Used when the caller opted out of PID capture (and accepted that we
    can't kill-by-PID on timeout).
    """
    parts: list[str] = []
    if cwd:
        safe_cwd = cwd.replace('"', '\\"')
        parts.append(f'cd "{safe_cwd}"')
    if env:
        for k, v in env.items():
            if not _is_safe_env_name(k):
                raise ValueError(f"unsafe env var name: {k!r}")
            safe_v = v.replace('"', '\\"')
            parts.append(f'export {k}="{safe_v}"')
    parts.append(cmd)
    return " && ".join(parts)


def _extract_pid(data: bytes) -> tuple[int | None, bytes, bool]:
    """Scan ``data`` for the first ``PID=<n>\\n`` line.

    Returns ``(pid_or_None, remainder_bytes, found_flag)``.

    * If the newline hasn't arrived yet, returns ``(None, data, False)`` so
      the caller can keep buffering.
    * If a line is found but doesn't match ``PID=<digits>``, treats the whole
      buffer as regular stdout and returns ``(None, data, True)``.
    """
    nl = data.find(b"\n")
    if nl < 0:
        return None, data, False

    first_line = data[:nl]
    rest = data[nl + 1 :]

    # Tolerate a trailing \r (in case a pty was allocated and CRLF is in play).
    if first_line.endswith(b"\r"):
        first_line = first_line[:-1]

    if first_line.startswith(b"PID="):
        try:
            pid = int(first_line[4:])
            return pid, rest, True
        except ValueError:
            pass

    # Not a PID line — put the original buffer back as stdout.
    return None, data, True


def _short(s: str, n: int = 80) -> str:
    s = s.replace("\n", " ")
    return s if len(s) <= n else s[: n - 1] + "…"


# ---------------------------------------------------------------------------
# ConnectionPool
# ---------------------------------------------------------------------------


class ConnectionPool:
    """Lazy cache of :class:`SSHConnection` keyed by host alias.

    Phase 1 only ever creates one entry, but the class is ready for the
    Phase 4 multi-host world.
    """

    def __init__(
        self,
        hosts: dict[str, HostConfig],
        *,
        known_hosts_path: Path | None = None,
        insecure_auto_add: bool = False,
        reconnect_retries: int = 3,
        reconnect_delay_sec: float = 2.0,
    ) -> None:
        self._host_cfgs = hosts
        self._known_hosts_path = known_hosts_path
        self._insecure_auto_add = insecure_auto_add
        # Phase 5: seeded from AppConfig.limits.reconnect_{retries,delay_sec}
        # by :func:`server.build_pool`. Propagated to every SSHConnection
        # the pool lazily constructs, so auto-reconnect is uniform across
        # hosts without callers having to know about it.
        self._reconnect_retries = max(0, reconnect_retries)
        self._reconnect_delay_sec = max(0.0, reconnect_delay_sec)

        self._conns: dict[str, SSHConnection] = {}
        self._lock = threading.RLock()

    def get(self, alias: str) -> SSHConnection:
        """Return a (possibly freshly created) connection for ``alias``.

        Does NOT eagerly connect — the first :meth:`SSHConnection.exec` call
        will trigger the handshake.
        """
        with self._lock:
            conn = self._conns.get(alias)
            if conn is None:
                if alias not in self._host_cfgs:
                    raise SSHError(
                        f"unknown host alias {alias!r} (available: {sorted(self._host_cfgs)})"
                    )
                conn = SSHConnection(
                    self._host_cfgs[alias],
                    known_hosts_path=self._known_hosts_path,
                    insecure_auto_add=self._insecure_auto_add,
                    reconnect_retries=self._reconnect_retries,
                    reconnect_delay_sec=self._reconnect_delay_sec,
                )
                self._conns[alias] = conn
            return conn

    def aliases(self) -> list[str]:
        with self._lock:
            return sorted(self._host_cfgs)

    def close_all(self) -> None:
        with self._lock:
            for conn in list(self._conns.values()):
                try:
                    conn.close()
                except Exception:  # pragma: no cover
                    log.debug("error closing connection", exc_info=True)
            self._conns.clear()
