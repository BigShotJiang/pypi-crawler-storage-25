"""CLI entrypoint for mcp-ssh-live.

Parses command-line arguments (via Typer), loads the effective configuration,
builds the FastMCP server, and runs it over stdio until the MCP client
disconnects or we receive a termination signal.

Usage examples::

    # Single host, password from env
    mcp-ssh-live --host 1.2.3.4 --user root --password-env SSH_PASSWORD

    # Single host with named alias and custom port
    mcp-ssh-live --host prod=1.2.3.4:22 --user root --password-env SSH_PASSWORD

    # Multi-host (repeat --host)
    mcp-ssh-live \\
        --host prod=1.2.3.4 --user root --password-env PROD_PASS \\
        --host stage=10.0.0.5 --user deploy --key ~/.ssh/stage_key

    # Use a TOML config file
    mcp-ssh-live --config ~/.config/mcp-ssh-live/config.toml

Stdout is reserved for the MCP JSON-RPC stream over stdio; everything this
process prints for humans (logs, errors, the ``--help`` text) goes to stderr.
"""

from __future__ import annotations

import logging
import signal
import sys
from pathlib import Path

import typer

from . import __version__
from .config import (
    CliOverrides,
    ConfigError,
    configure_logging,
    load_config,
)
from .server import ServerState, build_server, run_stdio

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Typer app
# ---------------------------------------------------------------------------


def _version_callback(value: bool) -> None:
    if value:
        # --version is a read-only flag; print to stdout is fine here because
        # the MCP stdio protocol hasn't started yet — we exit immediately.
        typer.echo(f"mcp-ssh-live {__version__}")
        raise typer.Exit()


# ---------------------------------------------------------------------------
# Main command
#
# We expose a single Typer *command* (not a subcommand group) so that all
# flags live directly on the binary: ``mcp-ssh-live --host ...`` rather than
# ``mcp-ssh-live serve --host ...``. ``typer.run(serve)`` in :func:`main`
# gives us exactly that shape while still producing a nice ``--help``.
# ---------------------------------------------------------------------------


def serve(
    host: list[str] = typer.Option(
        None,
        "--host",
        help=(
            "Remote host to manage. Repeatable for multi-host setups. "
            "Formats accepted: '1.2.3.4', '1.2.3.4:2222', 'alias=1.2.3.4', "
            "'alias=1.2.3.4:2222'."
        ),
        metavar="[ALIAS=]HOST[:PORT]",
    ),
    user: str | None = typer.Option(
        None,
        "--user",
        "-u",
        help="Remote username. Applies to all --host entries without their own.",
    ),
    password_env: str | None = typer.Option(
        None,
        "--password-env",
        help=(
            "Name of the environment variable containing the SSH password. "
            "Preferred over --password because env vars aren't visible in "
            "'ps'. Mutually exclusive with --key."
        ),
        metavar="ENV_VAR",
    ),
    key: str | None = typer.Option(
        None,
        "--key",
        help="Path to the private key file. Mutually exclusive with --password-env.",
        metavar="PATH",
    ),
    alias: str | None = typer.Option(
        None,
        "--alias",
        help=(
            "Short name for the single --host entry. Ignored when multiple "
            "--host flags are given (use 'alias=host' syntax instead)."
        ),
    ),
    default_host: str | None = typer.Option(
        None,
        "--default-host",
        help=(
            "Which configured host alias to use when a tool is called "
            "without an explicit 'host' argument. Required only when more "
            "than one host is configured and none is obvious."
        ),
    ),
    config: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help=(
            "Path to a TOML config file. If omitted, "
            "~/.config/mcp-ssh-live/config.toml is loaded if it exists."
        ),
        exists=False,  # we report a nicer error from load_config
        dir_okay=False,
        resolve_path=False,
    ),
    log_dir: Path | None = typer.Option(
        None,
        "--log-dir",
        help=(
            "Opt-in: mirror every spawned job's stdout/stderr to "
            "<log-dir>/<job_id>.log. Disabled by default."
        ),
        dir_okay=True,
        file_okay=False,
        resolve_path=False,
    ),
    insecure_auto_add: bool = typer.Option(
        False,
        "--insecure-auto-add",
        help=(
            "Auto-accept unknown host keys (paramiko AutoAddPolicy). "
            "INSECURE: vulnerable to MITM on first connect. Off by default."
        ),
    ),
    known_hosts: Path | None = typer.Option(
        None,
        "--known-hosts",
        help="Path to a known_hosts file. Defaults to paramiko's system default.",
        dir_okay=False,
        resolve_path=False,
    ),
    log_level: str = typer.Option(
        "INFO",
        "--log-level",
        help="Log level for this process's own logs (stderr). DEBUG/INFO/WARNING/ERROR.",
        metavar="LEVEL",
    ),
    version: bool | None = typer.Option(  # noqa: ARG001 - consumed by callback
        None,
        "--version",
        callback=_version_callback,
        is_eager=True,
        help="Print the package version and exit.",
    ),
) -> None:
    """Run the MCP server over stdio (this is the default command)."""
    configure_logging(log_level)

    # Basic sanity on mutually-exclusive auth flags.
    if password_env and key:
        typer.echo(
            "error: --password-env and --key are mutually exclusive per --host. "
            "If you need a mix, use a TOML config file with per-host settings.",
            err=True,
        )
        raise typer.Exit(code=2)

    overrides = CliOverrides(
        config_path=config,
        host_specs=list(host or []),
        user=user,
        password_env=password_env,
        key=key,
        alias=alias,
        default_host=default_host,
        log_dir=log_dir,
        insecure_auto_add_host_keys=insecure_auto_add,
        known_hosts_path=known_hosts,
    )

    try:
        cfg = load_config(overrides)
    except ConfigError as e:
        typer.echo(f"error: {e}", err=True)
        raise typer.Exit(code=2) from e

    state = build_server(cfg)
    _install_signal_handlers(state)

    log.info("mcp-ssh-live v%s ready; serving MCP over stdio", __version__)
    try:
        run_stdio(state)
    except KeyboardInterrupt:
        log.info("interrupted; shutting down")
    except Exception:
        log.exception("fatal error in MCP server loop")
        # ``from None`` suppresses the implicit exception chaining
        # when we re-raise as typer.Exit. The original traceback has
        # already been logged via ``log.exception`` above, so chaining
        # it through to Typer's own error handler would just print it
        # twice — once from logging, once from Typer's cause-chain
        # formatter. ``from None`` keeps the CLI output clean.
        raise typer.Exit(code=1) from None
    finally:
        state.close()


# Backwards-compat alias in case anything imports ``app`` from this module
# (tests, Typer's generated completion scripts, etc.). ``typer.run`` builds
# its own app internally; we only keep this name so code referencing it
# doesn't break.
app = serve


# ---------------------------------------------------------------------------
# Signal handling
# ---------------------------------------------------------------------------


def _install_signal_handlers(state: ServerState) -> None:
    """Install best-effort SIGTERM/SIGINT handlers.

    FastMCP's stdio runner already handles KeyboardInterrupt, but we also
    want SIGTERM (graceful shutdown when the MCP client kills us) to close
    SSH connections cleanly. Phase 5 will extend this to also SIGTERM all
    running jobs; Phase 1 just releases the transports.
    """

    def _handler(signum: int, _frame) -> None:  # pragma: no cover - signal path
        log.info("received signal %d; closing SSH connections", signum)
        try:
            state.close()
        finally:
            # Re-raise the default behavior so the runtime actually exits.
            # KeyboardInterrupt for SIGINT is idiomatic and plays well with
            # FastMCP's loop; for SIGTERM we just sys.exit.
            if signum == signal.SIGINT:
                raise KeyboardInterrupt
            sys.exit(0)

    try:
        signal.signal(signal.SIGINT, _handler)
    except (ValueError, OSError):  # pragma: no cover - non-main-thread etc.
        pass

    # SIGTERM doesn't exist on Windows Python in the usual sense; guard.
    sigterm = getattr(signal, "SIGTERM", None)
    if sigterm is not None:
        try:
            signal.signal(sigterm, _handler)
        except (ValueError, OSError):  # pragma: no cover
            pass


# ---------------------------------------------------------------------------
# Entry point (installed as console script ``mcp-ssh-live``)
# ---------------------------------------------------------------------------


def main() -> None:
    """Console-script entry point.

    We wrap ``app()`` so tracebacks from config errors, auth failures, etc.
    don't spill onto stdout (which would corrupt the MCP JSON-RPC stream if
    the client has already started talking to us).
    """
    # ``typer.run`` wraps ``serve`` as a single-command Typer app, meaning
    # the user invokes flags directly on the binary (no ``serve`` subcommand
    # required). This matches the CLI shape documented in SPEC.md.
    typer.run(serve)


if __name__ == "__main__":  # pragma: no cover
    main()
