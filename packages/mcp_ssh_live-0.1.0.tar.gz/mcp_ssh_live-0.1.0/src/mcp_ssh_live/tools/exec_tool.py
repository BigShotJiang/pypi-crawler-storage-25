"""The ``ssh_exec`` tool — synchronous one-shot remote command execution.

See ``SPEC.md`` §"MCP Tools (public API)" → "1. ``ssh_exec``" for the contract.

Behavior:

* Wall-clock timeout enforced via :meth:`SSHConnection.exec`, which kills
  the remote process (SIGTERM → 5 s grace → SIGKILL) via the PID-capture
  trick.
* Output larger than ``max_inline_chars`` is truncated *from the tail end*
  (we keep the beginning — that's where error context usually lives for
  simple commands; jobs that need the full output should use
  ``ssh_spawn``/``ssh_tail``).
* On connection / protocol errors we return a structured error payload
  rather than raising — MCP clients surface ``isError`` nicely, but for
  ``ssh_exec`` the LLM usually wants to keep going, so we fold the error
  into the normal response shape with ``exit_status=-1`` and a stderr
  synthesized line.
"""

from __future__ import annotations

import logging

from fastmcp import FastMCP

from ..config import AppConfig
from ..connection import (
    ConnectionPool,
    SSHConnectError,
    SSHError,
    SSHExecTimeout,
)

log = logging.getLogger(__name__)


def _truncate(s: str, limit: int) -> tuple[str, bool]:
    """Truncate ``s`` to ``limit`` chars. Returns (truncated_str, was_truncated)."""
    if limit <= 0 or len(s) <= limit:
        return s, False
    marker = f"\n[...truncated {len(s) - limit} chars...]"
    # Reserve some room for the marker so the total stays <= limit.
    keep = max(0, limit - len(marker))
    return s[:keep] + marker, True


def register(
    mcp: FastMCP,
    pool: ConnectionPool,
    cfg: AppConfig,
) -> None:
    """Register the ``ssh_exec`` tool on ``mcp``.

    The tool closes over ``pool`` and ``cfg`` so the FastMCP decorator gets
    a zero-argument (from the MCP protocol's perspective, only JSON args)
    callable that can reach the shared server state.
    """

    default_timeout_ms = cfg.limits.exec_timeout_ms
    default_max_inline_chars = cfg.limits.max_inline_chars

    @mcp.tool(
        name="ssh_exec",
        description=(
            "Run a shell command on the remote host and return its full "
            "stdout/stderr/exit status. Blocks until the command finishes "
            "or the wall-clock timeout expires (SIGTERM then SIGKILL).\n\n"
            "WHEN TO USE ssh_exec:\n"
            "- Short commands that finish in under ~60s.\n"
            "- Fire-and-forget background tasks that must SURVIVE a "
            "disconnect (use nohup or screen so the process keeps running "
            "even if the MCP server restarts or Zed closes).\n\n"
            "SURVIVING DISCONNECT — nohup pattern:\n"
            "  ssh_exec('nohup python -u train.py > /tmp/train.log 2>&1 &')\n"
            "  # process keeps running after disconnect; check later with:\n"
            "  ssh_exec('tail -n 50 /tmp/train.log')\n"
            "  ssh_exec('ps aux | grep train.py')\n\n"
            "SURVIVING DISCONNECT — screen pattern:\n"
            "  ssh_exec('screen -dmS myjob bash -c \"python train.py > /tmp/out.log 2>&1\"')\n"
            "  # reattach later: screen -r myjob\n\n"
            "WARNING: ssh_spawn ties the remote process to the MCP channel — "
            "it dies on disconnect. Use ssh_exec+nohup/screen for tasks that "
            "must outlive the current session.\n\n"
            "For real-time streaming output of a command you will watch to "
            "completion without disconnecting, use ssh_spawn + ssh_tail instead."
        ),
    )
    def ssh_exec(
        command: str,
        host: str | None = None,
        timeout_ms: int = default_timeout_ms,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
    ) -> dict:
        """Execute ``command`` synchronously on ``host`` (or the default host).

        Args:
            command: The shell fragment to run on the remote. Passed to
                ``bash -c`` after a PID-capture prelude; your own shell
                metacharacters (``|``, ``&&``, ``$VAR``, etc.) work normally.
            host: Alias of the configured host, or its raw address. If
                omitted, the server's ``default_host`` is used. When only a
                single host is configured, this argument is optional.
            timeout_ms: Wall-clock budget. On overrun the remote process
                receives SIGTERM, then (after 5 s grace) SIGKILL. Set to 0 or
                a negative number to disable.
            cwd: Remote working directory (``cd`` before running).
            env: Additional environment variables for the remote process.
                Names must match ``[A-Za-z_][A-Za-z0-9_]*``.

        Returns:
            A dict with keys ``stdout``, ``stderr``, ``exit_status``,
            ``duration_ms``, ``truncated``, ``timed_out``, ``host``. On
            connection/protocol errors, ``exit_status`` is -1 and ``stderr``
            contains a ``[mcp-ssh-live: ...]`` diagnostic line.
        """
        try:
            host_cfg = cfg.get_host(host)
        except ValueError as e:
            # Configuration error — surface as a structured error response.
            return {
                "stdout": "",
                "stderr": f"[mcp-ssh-live: config error] {e}",
                "exit_status": -1,
                "duration_ms": 0,
                "truncated": False,
                "timed_out": False,
                "host": host or "",
            }

        conn = pool.get(host_cfg.alias)

        try:
            result = conn.exec(
                command,
                timeout_ms=timeout_ms,
                cwd=cwd,
                env=env,
            )
            stdout, out_trunc = _truncate(result.stdout, default_max_inline_chars)
            stderr, err_trunc = _truncate(result.stderr, default_max_inline_chars)
            return {
                "stdout": stdout,
                "stderr": stderr,
                "exit_status": result.exit_status,
                "duration_ms": result.duration_ms,
                "truncated": out_trunc or err_trunc,
                "timed_out": result.timed_out,
                "host": host_cfg.alias,
            }
        except SSHExecTimeout as e:
            stdout, out_trunc = _truncate(e.stdout, default_max_inline_chars)
            # Append a synthesized line so the LLM notices the timeout even if
            # it only inspects stderr.
            synth = (
                f"\n[mcp-ssh-live: command timed out after {timeout_ms} ms; "
                f"{'killed' if e.killed else 'NOT killed (no PID captured)'}]"
            )
            stderr_raw = e.stderr + synth
            stderr, err_trunc = _truncate(stderr_raw, default_max_inline_chars)
            return {
                "stdout": stdout,
                "stderr": stderr,
                # Conventional "killed by signal N" exit is 128+N. We don't
                # know for sure whether TERM or KILL won the race, so report
                # -1 and let the stderr diagnostic speak for itself.
                "exit_status": -1,
                "duration_ms": e.duration_ms,
                "truncated": out_trunc or err_trunc,
                "timed_out": True,
                "host": host_cfg.alias,
            }
        except SSHConnectError as e:
            log.warning("ssh_exec connect error on %r: %s", host_cfg.alias, e)
            return {
                "stdout": "",
                "stderr": f"[mcp-ssh-live: connection failed] {e}",
                "exit_status": -1,
                "duration_ms": 0,
                "truncated": False,
                "timed_out": False,
                "host": host_cfg.alias,
            }
        except SSHError as e:
            log.warning("ssh_exec SSH error on %r: %s", host_cfg.alias, e)
            return {
                "stdout": "",
                "stderr": f"[mcp-ssh-live: ssh error] {e}",
                "exit_status": -1,
                "duration_ms": 0,
                "truncated": False,
                "timed_out": False,
                "host": host_cfg.alias,
            }
        except Exception as e:  # pragma: no cover - defensive
            log.exception("ssh_exec unexpected error on %r", host_cfg.alias)
            return {
                "stdout": "",
                "stderr": f"[mcp-ssh-live: unexpected error] {type(e).__name__}: {e}",
                "exit_status": -1,
                "duration_ms": 0,
                "truncated": False,
                "timed_out": False,
                "host": host_cfg.alias,
            }
