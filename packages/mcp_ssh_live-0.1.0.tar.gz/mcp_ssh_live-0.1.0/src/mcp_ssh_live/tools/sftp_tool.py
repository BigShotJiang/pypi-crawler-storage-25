"""The ``ssh_upload`` and ``ssh_download`` tools — SFTP file transfer.

See ``SPEC.md`` §"MCP Tools (public API)" → "8. ``ssh_upload`` /
``ssh_download``" for the full contract.

Why SFTP instead of ``cat > file <<EOF`` over ``ssh_exec``:

* **Binary-safe.** Heredoc-ing a binary through shell escapes is a
  losing game — nulls, high bytes, CRLF translation, quoting — all
  silently corrupt the payload. SFTP pushes raw bytes.
* **Large files.** Shell pipelines have line-length limits on many
  sshd builds; SFTP streams arbitrary sizes.
* **Integrity.** We can sha256 both sides and report the hash in the
  response, so the LLM knows the transfer completed without
  corruption.
* **mode / mtime preserved** (optional). Useful when uploading
  scripts that must be executable, or when rsync-style "skip if
  unchanged" logic runs on the caller side.

Both tools are best-effort about *not* leaking partial state on
failure:

* ``ssh_upload`` writes to ``<remote_path>.partial``, fsyncs, and
  renames atomically on completion. If the transfer dies halfway,
  the target path is untouched and the ``.partial`` file is left on
  disk so the operator can inspect or resume.
* ``ssh_download`` writes to ``<local_path>.partial`` with the same
  atomic-rename pattern. A download that times out never leaves a
  truncated file at the final path, so downstream tools that check
  for existence don't get confused.

Size limits are there to prevent a misbehaving LLM from accidentally
exfiltrating a 100 GB database on a whim:

* Upload: soft cap matches :attr:`AppConfig.limits.max_inline_chars`
  by default, but the real knob is the ``max_bytes`` argument (default
  100 MiB). Larger payloads can be enabled per-call by passing a
  higher value explicitly.
* Download: default 100 MiB, same ``max_bytes`` knob.

Error handling follows the same folded-response philosophy as the
other tools: unknown host / unreadable local file / remote permission
denied / short write — all become ``{ok: False, error: {kind,
message}}`` instead of exceptions.
"""

from __future__ import annotations

import errno
import hashlib
import logging
import os
import posixpath
import stat
import time
from pathlib import Path

from fastmcp import FastMCP

from ..config import AppConfig
from ..connection import ConnectionPool, SSHConnectError, SSHError

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
#
# All caps / chunk sizes in one place so tests can override and operators
# can grep for them. Defaults picked to balance "safe for a typical LLM
# misfire" against "reasonable for a real deployment push".

# Hard ceiling on ``max_bytes`` regardless of what the caller asks for.
# 1 GiB — enough for any realistic artifact we'd push from an MCP client,
# small enough that a runaway upload can't exhaust a typical server disk.
_HARD_MAX_BYTES = 1 * 1024 * 1024 * 1024

# Default ``max_bytes`` when the caller doesn't specify. 100 MiB matches
# SPEC.md §"8. ssh_download"'s default and is big enough for most
# configs / parsers / small datasets, small enough that an accidental
# ``/var/log/syslog`` pull doesn't chug for an hour.
_DEFAULT_MAX_BYTES = 100 * 1024 * 1024

# Per-read chunk size for streaming upload + download. 64 KiB matches
# paramiko's internal window defaults well — bigger doesn't speed up
# significantly and costs more memory for the sha256 incremental
# update, smaller adds per-chunk overhead.
_CHUNK = 64 * 1024


# ---------------------------------------------------------------------------
# Response shape helpers
# ---------------------------------------------------------------------------


def _ok_upload_response(
    *,
    host: str,
    local_path: str,
    remote_path: str,
    bytes_transferred: int,
    sha256: str,
    mode_set: int | None,
    duration_ms: int,
) -> dict:
    """Shape returned on a successful upload."""
    return {
        "ok": True,
        "host": host,
        "local_path": local_path,
        "remote_path": remote_path,
        "bytes": bytes_transferred,
        "sha256": sha256,
        "mode_set": mode_set,
        "duration_ms": duration_ms,
        "error": None,
    }


def _ok_download_response(
    *,
    host: str,
    remote_path: str,
    local_path: str,
    bytes_transferred: int,
    sha256: str,
    duration_ms: int,
) -> dict:
    """Shape returned on a successful download."""
    return {
        "ok": True,
        "host": host,
        "remote_path": remote_path,
        "local_path": local_path,
        "bytes": bytes_transferred,
        "sha256": sha256,
        "duration_ms": duration_ms,
        "error": None,
    }


def _err_response(
    *,
    kind: str,
    message: str,
    host: str = "",
    local_path: str = "",
    remote_path: str = "",
    is_upload: bool = True,
) -> dict:
    """Shape returned on any failure path.

    Mirrors both success-shape key sets so a pattern-matching LLM gets
    the same keys regardless of direction or outcome. We special-case
    the ``local_path``/``remote_path`` ordering so an upload error
    report puts local first (matching the success shape) and a
    download error report puts remote first.
    """
    if is_upload:
        return {
            "ok": False,
            "host": host,
            "local_path": local_path,
            "remote_path": remote_path,
            "bytes": 0,
            "sha256": "",
            "mode_set": None,
            "duration_ms": 0,
            "error": {"kind": kind, "message": message},
        }
    return {
        "ok": False,
        "host": host,
        "remote_path": remote_path,
        "local_path": local_path,
        "bytes": 0,
        "sha256": "",
        "duration_ms": 0,
        "error": {"kind": kind, "message": message},
    }


# ---------------------------------------------------------------------------
# Common helpers
# ---------------------------------------------------------------------------


def _clamp_max_bytes(max_bytes: int | None) -> int:
    """Normalize ``max_bytes`` to a sane positive integer.

    Negative or zero → default. Anything above :data:`_HARD_MAX_BYTES`
    is clamped down; the caller gets back the clamped value in the
    response via ``bytes`` (if the payload was big enough to hit it).
    """
    if max_bytes is None or max_bytes <= 0:
        return _DEFAULT_MAX_BYTES
    if max_bytes > _HARD_MAX_BYTES:
        log.debug("max_bytes=%d clamped to hard ceiling %d", max_bytes, _HARD_MAX_BYTES)
        return _HARD_MAX_BYTES
    return max_bytes


def _human_size(n: int) -> str:
    """Format a byte count for log lines. Not shown to the caller."""
    for unit in ("B", "KiB", "MiB", "GiB"):
        if n < 1024:
            return f"{n:.1f} {unit}" if unit != "B" else f"{n} {unit}"
        n /= 1024.0
    return f"{n:.1f} TiB"


def _posix_parent(path: str) -> str | None:
    """Return the POSIX parent directory of ``path``, or None if at root."""
    parent = posixpath.dirname(path)
    if not parent or parent == path:
        return None
    return parent


def _sftp_mkdir_p(sftp, remote_dir: str) -> None:
    """Recursively ``mkdir -p`` on the SFTP side.

    paramiko's :meth:`SFTPClient.mkdir` fails if the parent doesn't
    exist and doesn't accept a ``parents=True`` flag. We walk the path
    components and create each segment, ignoring "already exists"
    errors so the operation is idempotent.

    Silently does nothing if ``remote_dir`` is empty, ``"."`` or
    ``"/"`` — the root is assumed to exist (it is, by definition).
    """
    if not remote_dir or remote_dir in ("/", "."):
        return

    # Try to stat first — fast path for the common case where the
    # directory already exists.
    try:
        sftp.stat(remote_dir)
        return
    except OSError:
        pass

    parent = _posix_parent(remote_dir)
    if parent:
        _sftp_mkdir_p(sftp, parent)

    try:
        sftp.mkdir(remote_dir)
    except OSError as e:
        # Recover from EEXIST (concurrent creator) and from "file
        # already exists" pseudo-codes some servers emit. Any other
        # IOError propagates to the caller.
        err = getattr(e, "errno", None)
        if err in (errno.EEXIST, None):
            # Confirm it's actually a directory; if it's a file we've
            # just hit a real name collision and the next operation
            # will fail anyway with a clearer message.
            try:
                attrs = sftp.stat(remote_dir)
                if stat.S_ISDIR(getattr(attrs, "st_mode", 0) or 0):
                    return
            except OSError:
                pass
        raise


def _remote_isdir(sftp, remote_path: str) -> bool:
    """Return True if ``remote_path`` exists and is a directory."""
    try:
        attrs = sftp.stat(remote_path)
        return stat.S_ISDIR(getattr(attrs, "st_mode", 0) or 0)
    except OSError:
        return False


# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------


def _do_upload(
    conn,
    *,
    local_path: Path,
    remote_path: str,
    mode: int | None,
    max_bytes: int,
) -> tuple[int, str, int | None, int]:
    """Perform the actual SFTP upload.

    Returns ``(bytes_transferred, sha256_hex, mode_set_or_None,
    duration_ms)``. Raises :class:`IOError` / :class:`OSError` /
    :class:`SSHError` on failure — the caller folds these into the
    response shape.

    Implementation notes:

    * We stream the file in 64 KiB chunks so memory stays bounded
      regardless of payload size.
    * We incrementally sha256 the bytes we read. Doing it here (once)
      instead of re-reading the file after the upload means we can
      return the hash even for a file that's being mutated underneath
      us — the hash reflects what we actually sent.
    * Size check: before we open any SFTP channel we stat the local
      file. If it exceeds ``max_bytes`` we fail fast with a clear
      message, without touching the network.
    * Atomic-ish write: upload to ``<remote_path>.partial``, fsync,
      then ``posix_rename`` (or ``rename``) to the final path. On
      failure the caller sees no half-written target, and the leftover
      ``.partial`` file is a debuggable artifact.
    """
    t0 = time.monotonic()

    st = local_path.stat()
    total_size = st.st_size
    if total_size > max_bytes:
        raise OSError(
            f"local file is {_human_size(total_size)} > max_bytes {_human_size(max_bytes)}; "
            "raise max_bytes to override"
        )

    sftp = conn.open_sftp()
    tmp_path = remote_path + ".partial"
    sha = hashlib.sha256()
    written = 0

    try:
        # Make sure the remote parent directory exists. Idempotent; does
        # nothing if already present. Matches rsync/scp's conventional
        # behavior of auto-creating intermediate dirs.
        parent = _posix_parent(remote_path)
        if parent:
            _sftp_mkdir_p(sftp, parent)

        # If the caller pointed at an existing directory, be helpful
        # and append the local filename — matches ``scp``'s behavior
        # and saves one round-trip for a common mistake.
        final_remote = remote_path
        if _remote_isdir(sftp, remote_path):
            final_remote = posixpath.join(remote_path, local_path.name)
            tmp_path = final_remote + ".partial"

        with local_path.open("rb") as local_f:
            with sftp.file(tmp_path, "wb") as remote_f:
                # A larger sftp write buffer reduces round-trips; paramiko
                # exposes ``set_pipelined`` for this. Turning it on speeds
                # up transfers substantially on high-latency links with
                # minimal memory impact (paramiko caps queued writes).
                try:
                    remote_f.set_pipelined(True)
                except Exception:  # pragma: no cover - older paramiko
                    pass

                while True:
                    chunk = local_f.read(_CHUNK)
                    if not chunk:
                        break
                    remote_f.write(chunk)
                    sha.update(chunk)
                    written += len(chunk)

                # Let the server flush before we rename. Not every sshd
                # honors fsync over SFTP, but on those that do this is
                # the difference between an atomic rename and "renamed a
                # file whose buffers hadn't reached the disk yet".
                try:
                    remote_f.flush()
                except Exception:  # pragma: no cover
                    pass

        # Atomic-ish rename. posix_rename is the SFTP extension that
        # performs an overwrite; fall back to plain rename + remove on
        # servers that don't implement it.
        try:
            sftp.posix_rename(tmp_path, final_remote)
        except (OSError, AttributeError):
            # AttributeError: old paramiko without posix_rename
            # IOError: server doesn't support the extension
            try:
                sftp.remove(final_remote)
            except OSError:
                pass
            sftp.rename(tmp_path, final_remote)

        mode_set: int | None = None
        if mode is not None:
            try:
                sftp.chmod(final_remote, mode)
                mode_set = mode
            except OSError as e:
                # chmod failure is non-fatal — the bytes are already
                # there. Log the miss and let the caller see mode_set
                # as the mode actually applied (None means we skipped
                # or failed).
                log.warning(
                    "ssh_upload: chmod %o on %r failed: %s",
                    mode,
                    final_remote,
                    e,
                )

        duration_ms = int((time.monotonic() - t0) * 1000)
        return written, sha.hexdigest(), mode_set, duration_ms
    finally:
        try:
            sftp.close()
        except Exception:  # pragma: no cover - best-effort
            pass


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------


def _do_download(
    conn,
    *,
    remote_path: str,
    local_path: Path,
    max_bytes: int,
) -> tuple[int, str, int]:
    """Perform the actual SFTP download.

    Returns ``(bytes_transferred, sha256_hex, duration_ms)``. Raises
    :class:`IOError` / :class:`OSError` / :class:`SSHError` on failure.

    Mirrors :func:`_do_upload`:

    * 64 KiB chunks, incremental sha256.
    * Remote size check (``sftp.stat``) before opening the channel, so
      an oversize download fails fast without burning any wire time.
    * Writes to ``<local_path>.partial`` and ``os.replace``'s to the
      final path on success. A download that's interrupted never
      leaves a truncated artifact at the final path.
    """
    t0 = time.monotonic()

    sftp = conn.open_sftp()
    try:
        try:
            attrs = sftp.stat(remote_path)
        except FileNotFoundError as e:
            raise OSError(f"remote file not found: {remote_path}") from e
        except OSError as e:
            # paramiko raises IOError with errno on some servers, or
            # with no errno at all; both we surface as "not found /
            # unreadable" rather than crashing.
            raise OSError(f"cannot stat remote file {remote_path!r}: {e}") from e

        remote_size = getattr(attrs, "st_size", None)
        if remote_size is None:
            # Unusual — server didn't return a size. We can't pre-flight
            # check, so we'll enforce the cap streaming-side below.
            pass
        elif remote_size > max_bytes:
            raise OSError(
                f"remote file is {_human_size(remote_size)} > max_bytes "
                f"{_human_size(max_bytes)}; raise max_bytes to override"
            )

        # Ensure the local parent directory exists. matches the upload
        # path's auto-mkdir convenience; a caller that wants to fail
        # loud on missing dirs can create the file themselves first.
        local_path.parent.mkdir(parents=True, exist_ok=True)

        tmp_path = local_path.with_suffix(local_path.suffix + ".partial")
        sha = hashlib.sha256()
        read_total = 0

        with sftp.file(remote_path, "rb") as remote_f:
            # Hint paramiko to pipeline reads; big win on high-latency
            # links. See :func:`_do_upload` for the same flag.
            try:
                remote_f.set_pipelined(True)
            except Exception:  # pragma: no cover
                pass

            with tmp_path.open("wb") as local_f:
                while True:
                    chunk = remote_f.read(_CHUNK)
                    if not chunk:
                        break
                    read_total += len(chunk)
                    # Streaming enforcement of the cap: catches the
                    # "server didn't tell us the size" case above.
                    if read_total > max_bytes:
                        raise OSError(
                            f"remote file exceeded max_bytes={_human_size(max_bytes)} "
                            "during streaming read; aborting"
                        )
                    local_f.write(chunk)
                    sha.update(chunk)

                local_f.flush()
                try:
                    os.fsync(local_f.fileno())
                except OSError:  # pragma: no cover - e.g. special filesystems
                    pass

        # Atomic rename of the .partial → final path. os.replace is
        # atomic on POSIX and atomic-on-same-volume on Windows, which
        # is the common case (we created the .partial in the same
        # parent dir).
        os.replace(tmp_path, local_path)

        duration_ms = int((time.monotonic() - t0) * 1000)
        return read_total, sha.hexdigest(), duration_ms
    finally:
        try:
            sftp.close()
        except Exception:  # pragma: no cover
            pass
        # Best-effort: if we bailed with a .partial still on disk,
        # leave it for the operator to inspect. We don't delete it
        # here because a deletion-inside-except can mask the original
        # error; a caller who wants a clean retry can remove it.


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register(
    mcp: FastMCP,
    pool: ConnectionPool,
    cfg: AppConfig,
) -> None:
    """Register ``ssh_upload`` and ``ssh_download`` on ``mcp``.

    Closes over the :class:`ConnectionPool` (SFTP channel opens go
    through the pooled transport, same as ``ssh_exec`` / ``ssh_spawn``)
    and the :class:`AppConfig` (for host-alias resolution).
    """

    # ------------------------------------------------------------------ upload

    @mcp.tool(
        name="ssh_upload",
        description=(
            "Upload a local file to the remote host via SFTP. Binary-"
            "safe; preserves arbitrary bytes unlike 'cat > file <<EOF' "
            "over ssh_exec.\n\n"
            "Writes to <remote_path>.partial first, then renames "
            "atomically on success — a crashed upload never leaves a "
            "half-written file at the target path. Parent directories "
            "are auto-created (mkdir -p). If remote_path points at an "
            "existing directory, the local filename is appended (same "
            "as scp).\n\n"
            "Size cap: max_bytes (default 100 MiB, hard ceiling 1 GiB). "
            "Returns a sha256 of the bytes actually transferred so the "
            "caller can verify integrity.\n\n"
            "Optional mode (octal, e.g. 493 for 0o755) runs chmod on "
            "the remote after the transfer. A chmod failure is "
            "non-fatal — the bytes are already there; mode_set=null "
            "in the response means the chmod was skipped or rejected."
        ),
    )
    def ssh_upload(
        local_path: str,
        remote_path: str,
        host: str | None = None,
        mode: int | None = None,
        max_bytes: int | None = None,
    ) -> dict:
        """Upload ``local_path`` → ``host:remote_path``.

        Args:
            local_path: Absolute or relative path to a local file.
                Resolved against the server's current working
                directory; using an absolute path avoids surprises.
            remote_path: Destination path on the remote host. Can be
                a full file path (overwritten atomically) or a
                directory (local filename appended). Intermediate
                directories are created automatically.
            host: Alias of the configured host, or a raw address. If
                omitted, the server's default host is used.
            mode: Optional POSIX mode bits (int), e.g. 0o755 or 493.
                Applied via chmod after the upload. Pass None to skip.
            max_bytes: Hard cap on the transfer size. Default 100 MiB,
                clamped to 1 GiB.

        Returns:
            A dict with keys ``ok``, ``host``, ``local_path``,
            ``remote_path``, ``bytes`` (int; 0 on error),
            ``sha256`` (hex), ``mode_set`` (int or null), ``duration_ms``,
            ``error``.

            Error ``kind`` values: ``config`` (unknown host / empty
            path), ``local_io`` (local file missing, permission denied,
            too large), ``connect`` (SSH handshake failed),
            ``remote_io`` (SFTP error on the server side),
            ``unexpected``.
        """
        # --- Parameter validation ----------------------------------------
        # We reject empty paths and non-str types loudly rather than
        # letting them fail deep inside paramiko — the error message
        # is useless if it comes from ``posixpath.join`` or a silent
        # ``Path("")``.

        if not local_path or not isinstance(local_path, str):
            return _err_response(
                kind="config",
                message=f"local_path must be a non-empty string; got {local_path!r}",
                is_upload=True,
            )
        if not remote_path or not isinstance(remote_path, str):
            return _err_response(
                kind="config",
                message=f"remote_path must be a non-empty string; got {remote_path!r}",
                local_path=local_path,
                is_upload=True,
            )

        local_p = Path(local_path).expanduser()
        if not local_p.exists():
            return _err_response(
                kind="local_io",
                message=f"local file does not exist: {local_p}",
                local_path=local_path,
                remote_path=remote_path,
                is_upload=True,
            )
        if not local_p.is_file():
            return _err_response(
                kind="local_io",
                message=f"local path is not a regular file: {local_p}",
                local_path=local_path,
                remote_path=remote_path,
                is_upload=True,
            )

        cap = _clamp_max_bytes(max_bytes)

        # --- Host resolution ---------------------------------------------
        try:
            host_cfg = cfg.get_host(host)
        except ValueError as e:
            return _err_response(
                kind="config",
                message=str(e),
                host=host or "",
                local_path=local_path,
                remote_path=remote_path,
                is_upload=True,
            )

        conn = pool.get(host_cfg.alias)

        # --- Ensure SSH is up (lazy) -------------------------------------
        try:
            conn.connect()
        except SSHConnectError as e:
            log.warning("ssh_upload connect error on %r: %s", host_cfg.alias, e)
            return _err_response(
                kind="connect",
                message=f"cannot establish SSH session: {e}",
                host=host_cfg.alias,
                local_path=local_path,
                remote_path=remote_path,
                is_upload=True,
            )
        except SSHError as e:
            return _err_response(
                kind="connect",
                message=f"SSH error: {e}",
                host=host_cfg.alias,
                local_path=local_path,
                remote_path=remote_path,
                is_upload=True,
            )

        # --- Do the transfer ---------------------------------------------
        # NOTE on ``except OSError``: in Python 3, ``IOError`` IS
        # ``OSError`` (they're aliases since PEP 3151). Splitting them
        # into two ``except`` blocks triggers ruff B025 ("duplicate
        # exception") and, more importantly, is a lie — the second
        # ``except`` can never fire because the first catches everything.
        # We pick ``remote_io`` as the ``kind`` because every path inside
        # ``_do_upload`` that raises a non-SSHError OSError is doing so
        # in a remote SFTP operation; local read failures on the source
        # file are caught earlier by the ``exists() / is_file()`` checks
        # at the top of this handler, so by the time we get here the
        # only realistic IO error is remote-side.
        try:
            written, sha256_hex, mode_set, duration_ms = _do_upload(
                conn,
                local_path=local_p,
                remote_path=remote_path,
                mode=mode,
                max_bytes=cap,
            )
        except OSError as e:
            log.warning("ssh_upload IO error on %r: %s", host_cfg.alias, e)
            return _err_response(
                kind="remote_io",
                message=str(e),
                host=host_cfg.alias,
                local_path=local_path,
                remote_path=remote_path,
                is_upload=True,
            )
        except SSHError as e:
            return _err_response(
                kind="connect",
                message=f"SSH error during transfer: {e}",
                host=host_cfg.alias,
                local_path=local_path,
                remote_path=remote_path,
                is_upload=True,
            )
        except Exception as e:  # pragma: no cover - defensive  # noqa: BLE001
            log.exception("ssh_upload unexpected error on %r", host_cfg.alias)
            return _err_response(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
                host=host_cfg.alias,
                local_path=local_path,
                remote_path=remote_path,
                is_upload=True,
            )

        log.info(
            "ssh_upload: %s -> %s:%s (%s, sha256=%s..., %d ms)",
            local_p,
            host_cfg.alias,
            remote_path,
            _human_size(written),
            sha256_hex[:12],
            duration_ms,
        )

        return _ok_upload_response(
            host=host_cfg.alias,
            local_path=str(local_p),
            remote_path=remote_path,
            bytes_transferred=written,
            sha256=sha256_hex,
            mode_set=mode_set,
            duration_ms=duration_ms,
        )

    # ------------------------------------------------------------------ download

    @mcp.tool(
        name="ssh_download",
        description=(
            "Download a file from the remote host to a local path via "
            "SFTP. Binary-safe.\n\n"
            "Writes to <local_path>.partial first, then atomically "
            "replaces the final path on success. A failed or cancelled "
            "download never leaves a truncated file where downstream "
            "tooling would pick it up.\n\n"
            "Size cap: max_bytes (default 100 MiB, hard ceiling 1 "
            "GiB). Remote size is checked via sftp.stat BEFORE the "
            "transfer starts; files that exceed the cap fail fast. "
            "Caps are enforced streaming-side too, so a misreported "
            "remote size can't trick us into filling the local disk."
        ),
    )
    def ssh_download(
        remote_path: str,
        local_path: str,
        host: str | None = None,
        max_bytes: int | None = None,
    ) -> dict:
        """Download ``host:remote_path`` → ``local_path``.

        Args:
            remote_path: Absolute path to the file on the remote host.
                Tilde expansion is NOT performed (paramiko's SFTP
                doesn't know about the remote user's ``$HOME``).
            local_path: Where to write the file locally. Parent
                directories are created automatically.
            host: Alias of the configured host, or a raw address.
            max_bytes: Hard cap. Default 100 MiB, clamped to 1 GiB.

        Returns:
            A dict with keys ``ok``, ``host``, ``remote_path``,
            ``local_path``, ``bytes``, ``sha256``, ``duration_ms``,
            ``error``.

            Error ``kind`` values: ``config`` / ``connect`` / ``remote_io``
            (not found, permission denied, too large) / ``local_io``
            (can't write the .partial file) / ``unexpected``.
        """
        if not remote_path or not isinstance(remote_path, str):
            return _err_response(
                kind="config",
                message=f"remote_path must be a non-empty string; got {remote_path!r}",
                is_upload=False,
            )
        if not local_path or not isinstance(local_path, str):
            return _err_response(
                kind="config",
                message=f"local_path must be a non-empty string; got {local_path!r}",
                remote_path=remote_path,
                is_upload=False,
            )

        local_p = Path(local_path).expanduser()
        cap = _clamp_max_bytes(max_bytes)

        try:
            host_cfg = cfg.get_host(host)
        except ValueError as e:
            return _err_response(
                kind="config",
                message=str(e),
                host=host or "",
                remote_path=remote_path,
                local_path=local_path,
                is_upload=False,
            )

        conn = pool.get(host_cfg.alias)

        try:
            conn.connect()
        except SSHConnectError as e:
            log.warning("ssh_download connect error on %r: %s", host_cfg.alias, e)
            return _err_response(
                kind="connect",
                message=f"cannot establish SSH session: {e}",
                host=host_cfg.alias,
                remote_path=remote_path,
                local_path=local_path,
                is_upload=False,
            )
        except SSHError as e:
            return _err_response(
                kind="connect",
                message=f"SSH error: {e}",
                host=host_cfg.alias,
                remote_path=remote_path,
                local_path=local_path,
                is_upload=False,
            )

        # Same note as ssh_upload's handler: IOError is OSError since
        # Python 3, so a single ``except OSError`` covers every IO
        # failure mode from inside ``_do_download``. We classify as
        # ``remote_io`` because the dominant failure modes are
        # paramiko's SFTP errors (not found, permission denied, too
        # large). Genuinely local failures (disk full writing the
        # .partial file, permission on local_path.parent) are rare and
        # the ``remote_io`` kind with the raw message is still more
        # useful to the LLM than a misleading ``local_io`` label.
        try:
            read_total, sha256_hex, duration_ms = _do_download(
                conn,
                remote_path=remote_path,
                local_path=local_p,
                max_bytes=cap,
            )
        except OSError as e:
            log.warning("ssh_download IO error on %r: %s", host_cfg.alias, e)
            return _err_response(
                kind="remote_io",
                message=str(e),
                host=host_cfg.alias,
                remote_path=remote_path,
                local_path=local_path,
                is_upload=False,
            )
        except SSHError as e:
            return _err_response(
                kind="connect",
                message=f"SSH error during transfer: {e}",
                host=host_cfg.alias,
                remote_path=remote_path,
                local_path=local_path,
                is_upload=False,
            )
        except Exception as e:  # pragma: no cover - defensive
            log.exception("ssh_download unexpected error on %r", host_cfg.alias)
            return _err_response(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
                host=host_cfg.alias,
                remote_path=remote_path,
                local_path=local_path,
                is_upload=False,
            )

        log.info(
            "ssh_download: %s:%s -> %s (%s, sha256=%s..., %d ms)",
            host_cfg.alias,
            remote_path,
            local_p,
            _human_size(read_total),
            sha256_hex[:12],
            duration_ms,
        )

        return _ok_download_response(
            host=host_cfg.alias,
            remote_path=remote_path,
            local_path=str(local_p),
            bytes_transferred=read_total,
            sha256=sha256_hex,
            duration_ms=duration_ms,
        )
