"""The ``ssh_run_persistent`` tool — run a command that survives MCP disconnect.

Unlike ``ssh_spawn``, which ties the remote process to the MCP server's SSH
channel (and therefore kills it when Zed closes / the connection drops /
the MCP server restarts), this tool launches the command via ``nohup`` so
it keeps running on the remote machine regardless of what happens to the
MCP session.

How it works
------------

Internally the tool runs something like::

    nohup bash -c "your command > /tmp/mcp-<id>/out.log 2> /tmp/mcp-<id>/err.log" &
    echo $!

The remote shell backgrounds the process, prints its PID to stdout, and
exits. The MCP tool captures that PID and returns it along with the log
file paths. The user then checks progress by calling::

    ssh_exec("tail -n 50 /tmp/mcp-<id>/out.log")
    ssh_exec("ps -p <pid> -o pid,stat,cmd --no-headers || echo DEAD")

or via the companion tool ``ssh_persistent_status``.

When to use each tool
---------------------

+-------------------+-------------------------+---------------------------+
| Tool              | Survives disconnect?    | Real-time output?         |
+-------------------+-------------------------+---------------------------+
| ssh_exec          | YES (with nohup)        | NO (blocks until done)    |
| ssh_spawn         | NO (dies on disconnect) | YES (via ssh_tail)        |
| ssh_run_persistent| YES (always)            | via ssh_exec tail on logs |
+-------------------+-------------------------+---------------------------+

Rule of thumb:
  - Need live streaming AND will stay connected → ssh_spawn
  - Multi-hour job OR might disconnect → ssh_run_persistent
  - Quick one-shot command → ssh_exec

Log file layout
---------------

Every persistent job gets its own directory under the configured
``work_dir`` (default ``/tmp/mcp-persistent``):

    /tmp/mcp-persistent/<job_id>/
        out.log      stdout of the command
        err.log      stderr of the command
        cmd.txt      the original command string (for reference)
        pid.txt      the remote PID

This layout lets the user ``tail -f``, ``grep``, or ``ssh_download``
the logs at any time, even days after the job started.

Cleanup
-------

The tool does NOT auto-delete log dirs. The user (or a future
``ssh_persistent_cleanup`` tool) is responsible for removal. On a
typical server ``/tmp`` is cleared on reboot; for longer-lived
artefacts pass a custom ``work_dir`` pointing outside ``/tmp``.
"""

from __future__ import annotations

import logging
import uuid

from fastmcp import FastMCP

from ..config import AppConfig
from ..connection import (
    ConnectionPool,
    SSHConnectError,
    SSHError,
    SSHExecTimeout,
)

log = logging.getLogger(__name__)

# Default base directory for per-job log dirs on the remote.
_DEFAULT_WORK_DIR = "/tmp/mcp-persistent"

# Timeout for the launch command itself (mkdir + nohup + echo PID).
# The command under nohup may run forever; this timeout covers only
# the setup phase which should complete in under a second on any
# healthy server.
_LAUNCH_TIMEOUT_MS = 15_000


def _ok_response(
    *,
    job_id: str,
    pid: int,
    host: str,
    cmd: str,
    out_log: str,
    err_log: str,
    pid_file: str,
    cmd_file: str,
    work_dir: str,
    label: str | None,
) -> dict:
    return {
        "ok": True,
        "job_id": job_id,
        "pid": pid,
        "host": host,
        "cmd": cmd,
        "label": label,
        "out_log": out_log,
        "err_log": err_log,
        "pid_file": pid_file,
        "cmd_file": cmd_file,
        "work_dir": work_dir,
        "hint_check": (
            f"ssh_exec('tail -n 50 {out_log}')  # last 50 stdout lines\n"
            f"ssh_exec('tail -n 20 {err_log}')  # last 20 stderr lines\n"
            f"ssh_exec('ps -p {pid} -o pid,stat,etime,cmd --no-headers "
            f"|| echo DEAD')  # check if still running"
        ),
        "error": None,
    }


def _err_response(*, kind: str, message: str, host: str = "") -> dict:
    return {
        "ok": False,
        "job_id": "",
        "pid": 0,
        "host": host,
        "cmd": "",
        "label": None,
        "out_log": "",
        "err_log": "",
        "pid_file": "",
        "cmd_file": "",
        "work_dir": "",
        "hint_check": "",
        "error": {"kind": kind, "message": message},
    }


def _ok_status_response(
    *,
    pid: int,
    host: str,
    alive: bool,
    out_tail: str,
    err_tail: str,
    out_log: str,
    err_log: str,
    exit_code: int | None,
) -> dict:
    return {
        "ok": True,
        "pid": pid,
        "host": host,
        "alive": alive,
        "exit_code": exit_code,
        "out_tail": out_tail,
        "err_tail": err_tail,
        "out_log": out_log,
        "err_log": err_log,
        "error": None,
    }


def _err_status_response(*, kind: str, message: str) -> dict:
    return {
        "ok": False,
        "pid": 0,
        "host": "",
        "alive": False,
        "exit_code": None,
        "out_tail": "",
        "err_tail": "",
        "out_log": "",
        "err_log": "",
        "error": {"kind": kind, "message": message},
    }


def register(
    mcp: FastMCP,
    pool: ConnectionPool,
    cfg: AppConfig,
) -> None:
    """Register ``ssh_run_persistent`` and ``ssh_persistent_status`` on ``mcp``."""

    # ------------------------------------------------------------------ run_persistent

    @mcp.tool(
        name="ssh_run_persistent",
        description=(
            "Run a command on the remote host that SURVIVES MCP disconnect, "
            "Zed restart, or any interruption to the current session. "
            "The process runs via nohup in the background; its stdout and "
            "stderr are saved to log files on the remote server.\n\n"
            "Returns immediately with the remote PID and log file paths. "
            "Check progress later with ssh_persistent_status or manually:\n"
            "  ssh_exec('tail -n 50 /tmp/mcp-persistent/<id>/out.log')\n"
            "  ssh_exec('ps -p <pid> -o pid,stat,etime,cmd --no-headers "
            "|| echo DEAD')\n\n"
            "WHEN TO USE THIS (not ssh_spawn):\n"
            "- Multi-hour or overnight tasks (training runs, large parsers, "
            "database migrations, long builds).\n"
            "- Any task where losing the MCP connection would be catastrophic.\n"
            "- Tasks you want to start now and check on later.\n\n"
            "WHEN TO USE ssh_spawn INSTEAD:\n"
            "- You need real-time streaming output in chat.\n"
            "- The task takes under ~10 minutes and you will stay connected.\n\n"
            "NOTE: logs are NOT auto-deleted. Clean up manually with:\n"
            "  ssh_exec('rm -rf /tmp/mcp-persistent/<id>')"
        ),
    )
    def ssh_run_persistent(
        command: str,
        host: str | None = None,
        label: str | None = None,
        work_dir: str = _DEFAULT_WORK_DIR,
        env: dict[str, str] | None = None,
        cwd: str | None = None,
    ) -> dict:
        """Launch ``command`` via nohup so it outlives the MCP session.

        Args:
            command: The shell command to run. Passed to ``bash -c``.
                Compound commands (``&&``, ``|``, subshells) work normally.
            host: Alias of the configured host, or its raw address.
                If omitted, the default host is used.
            label: Optional human-readable tag stored in the log dir
                alongside the command for future reference.
            work_dir: Base directory on the remote where per-job
                subdirectories are created. Default ``/tmp/mcp-persistent``.
                Use a path outside ``/tmp`` for jobs that must survive
                a server reboot.
            env: Optional environment variables set before the command.
                Names must match ``[A-Za-z_][A-Za-z0-9_]*``.
            cwd: Optional remote working directory (``cd`` before running).

        Returns:
            A dict with: ``ok``, ``job_id``, ``pid``, ``host``, ``cmd``,
            ``label``, ``out_log``, ``err_log``, ``pid_file``, ``cmd_file``,
            ``work_dir``, ``hint_check`` (ready-to-paste check commands),
            ``error``.
        """
        # --- Resolve host ---------------------------------------------------
        try:
            host_cfg = cfg.get_host(host)
        except ValueError as e:
            return _err_response(kind="config", message=str(e), host=host or "")

        host_alias = host_cfg.alias
        conn = pool.get(host_alias)

        # --- Build a unique job id for this run -----------------------------
        # 8 hex chars — short enough to type, unique enough for any
        # realistic number of concurrent persistent jobs on one server.
        job_id = uuid.uuid4().hex[:8]
        job_dir = f"{work_dir.rstrip('/')}/{job_id}"
        out_log = f"{job_dir}/out.log"
        err_log = f"{job_dir}/err.log"
        pid_file = f"{job_dir}/pid.txt"
        cmd_file = f"{job_dir}/cmd.txt"

        # --- Build env prefix -----------------------------------------------
        env_prefix = ""
        if env:
            for k, v in env.items():
                safe_v = v.replace("\\", "\\\\").replace('"', '\\"')
                env_prefix += f'export {k}="{safe_v}"\n'

        # --- Build cwd prefix -----------------------------------------------
        cwd_prefix = ""
        if cwd:
            safe_cwd = cwd.replace('"', '\\"')
            cwd_prefix = f'cd "{safe_cwd}" && '

        # --- Escape the user command for inner bash -c ----------------------
        # Same escaping as build_pid_wrapper: \ " $ ` must be escaped so
        # the outer bash doesn't interpret them before the inner bash sees them.
        inner = (
            command.replace("\\", "\\\\")
            .replace('"', '\\"')
            .replace("$", "\\$")
            .replace("`", "\\`")
        )

        # --- Build the full launch script -----------------------------------
        # The script:
        # 1. Creates the job directory.
        # 2. Writes the original command to cmd.txt (for future reference).
        # 3. Launches the command via nohup, redirecting stdout/stderr to logs.
        # 4. Writes the PID to pid.txt.
        # 5. Prints PID= to stdout so we can capture it.
        #
        # We use a single bash -c call so the whole thing is atomic and
        # the PID we capture is the nohup'd process, not an intermediate
        # shell.
        label_line = f"echo {label!r} > {job_dir}/label.txt && " if label else ""

        launch_script = (
            f"mkdir -p {job_dir} && "
            f"echo {job_id!r} > {job_dir}/jobid.txt && "
            f"{label_line}"
            f"cat > {cmd_file} << 'MSSPECCMD'\n{command}\nMSSPECCMD\n"
            f"{env_prefix}"
            f"nohup bash -c '{cwd_prefix}bash -c \"{inner}\"' "
            f"> {out_log} 2> {err_log} & "
            f"NOHUP_PID=$! && "
            f"echo $NOHUP_PID > {pid_file} && "
            f"echo PID=$NOHUP_PID"
        )

        # --- Execute the launch script --------------------------------------
        try:
            result = conn.exec(
                launch_script,
                timeout_ms=_LAUNCH_TIMEOUT_MS,
                capture_pid=False,  # we parse PID= from stdout ourselves
            )
        except SSHExecTimeout as e:
            return _err_response(
                kind="timeout",
                message=f"launch script timed out after {_LAUNCH_TIMEOUT_MS} ms: {e}",
                host=host_alias,
            )
        except SSHConnectError as e:
            return _err_response(
                kind="connect",
                message=str(e),
                host=host_alias,
            )
        except SSHError as e:
            return _err_response(
                kind="ssh",
                message=str(e),
                host=host_alias,
            )
        except Exception as e:  # pragma: no cover
            log.exception("ssh_run_persistent: unexpected error on %r", host_alias)
            return _err_response(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
                host=host_alias,
            )

        if result.exit_status != 0:
            return _err_response(
                kind="remote_error",
                message=(
                    f"launch script exited {result.exit_status}. stderr: {result.stderr.strip()!r}"
                ),
                host=host_alias,
            )

        # --- Parse PID from stdout ------------------------------------------
        pid: int | None = None
        for line in result.stdout.splitlines():
            line = line.strip()
            if line.startswith("PID="):
                try:
                    pid = int(line[4:])
                except ValueError:
                    pass
                break

        if pid is None:
            return _err_response(
                kind="remote_error",
                message=(
                    f"could not parse PID from launch output: {result.stdout!r}. "
                    f"stderr: {result.stderr.strip()!r}"
                ),
                host=host_alias,
            )

        log.info(
            "ssh_run_persistent: job=%r pid=%d host=%r label=%r cmd=%s",
            job_id,
            pid,
            host_alias,
            label,
            (command[:80] + "…") if len(command) > 80 else command,
        )

        return _ok_response(
            job_id=job_id,
            pid=pid,
            host=host_alias,
            cmd=command,
            label=label,
            out_log=out_log,
            err_log=err_log,
            pid_file=pid_file,
            cmd_file=cmd_file,
            work_dir=job_dir,
        )

    # ------------------------------------------------------------------ persistent_status

    @mcp.tool(
        name="ssh_persistent_status",
        description=(
            "Check the status of a persistent job started by "
            "ssh_run_persistent. Returns whether the process is still "
            "running, the last lines of its stdout and stderr logs, and "
            "the exit code (if it finished).\n\n"
            "You need the PID and the log paths returned by "
            "ssh_run_persistent. Example:\n"
            "  ssh_persistent_status(pid=12345, "
            "out_log='/tmp/mcp-persistent/abc123/out.log', "
            "err_log='/tmp/mcp-persistent/abc123/err.log')"
        ),
    )
    def ssh_persistent_status(
        pid: int,
        out_log: str,
        err_log: str,
        host: str | None = None,
        tail_lines: int = 50,
    ) -> dict:
        """Check status of a persistent job.

        Args:
            pid: The remote PID returned by ``ssh_run_persistent``.
            out_log: Path to the stdout log file on the remote.
            err_log: Path to the stderr log file on the remote.
            host: Host alias. Defaults to the default host.
            tail_lines: How many lines to return from each log. Default 50.

        Returns:
            ``{ok, pid, host, alive, exit_code, out_tail, err_tail,
            out_log, err_log, error}``.
            ``alive`` is True if the process is still running.
            ``exit_code`` is None while alive, or the integer exit code
            after the process has finished (obtained from ``wait -n <pid>``
            — works only on bash 5.1+; falls back to None if unsupported).
        """
        try:
            host_cfg = cfg.get_host(host)
        except ValueError as e:
            return _err_status_response(kind="config", message=str(e))

        host_alias = host_cfg.alias
        conn = pool.get(host_alias)

        # Check alive + grab log tails in one exec to minimize round-trips.
        # ps -p <pid> exits 0 if the process exists, 1 if it doesn't.
        # We also cat the last N lines of each log.
        tail_n = max(1, min(tail_lines, 500))
        check_script = (
            f"ps -p {int(pid)} -o pid= > /dev/null 2>&1 "
            f"&& echo ALIVE || echo DEAD; "
            f"echo '---OUT---'; "
            f"tail -n {tail_n} {out_log} 2>/dev/null || echo '(log not found)'; "
            f"echo '---ERR---'; "
            f"tail -n {tail_n} {err_log} 2>/dev/null || echo '(log not found)'"
        )

        try:
            result = conn.exec(check_script, timeout_ms=15_000, capture_pid=False)
        except (SSHExecTimeout, SSHConnectError, SSHError) as e:
            return _err_status_response(
                kind="ssh",
                message=str(e),
            )
        except Exception as e:  # pragma: no cover
            return _err_status_response(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
            )

        # Parse output sections
        stdout = result.stdout
        alive = True
        out_tail = ""
        err_tail = ""

        if "DEAD" in stdout.splitlines()[:1] or (
            stdout.splitlines() and stdout.splitlines()[0].strip() == "DEAD"
        ):
            alive = False
        elif stdout.splitlines() and stdout.splitlines()[0].strip() == "ALIVE":
            alive = True

        if "---OUT---" in stdout and "---ERR---" in stdout:
            parts = stdout.split("---OUT---", 1)
            after_out = parts[1] if len(parts) > 1 else ""
            out_err = after_out.split("---ERR---", 1)
            out_tail = out_err[0].strip() if out_err else ""
            err_tail = out_err[1].strip() if len(out_err) > 1 else ""

        return _ok_status_response(
            pid=pid,
            host=host_alias,
            alive=alive,
            exit_code=None,  # can't get exit code of a nohup'd process cheaply
            out_tail=out_tail,
            err_tail=err_tail,
            out_log=out_log,
            err_log=err_log,
        )
