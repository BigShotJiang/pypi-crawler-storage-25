"""The ``ssh_list_hosts`` tool — enumerate configured SSH targets.

See ``SPEC.md`` §"MCP Tools (public API)" → "9. (bonus) ``ssh_list_hosts``"
for the contract.

Purpose
-------

When the server is configured with multiple hosts (via repeated
``--host`` CLI flags or a TOML config file with several ``[hosts.*]``
sections), the LLM needs a way to discover what targets are available
without guessing. ``ssh_list_hosts`` returns the full topology:

* every configured alias and its resolved ``(host, port, user)`` tuple,
* which auth method is configured (password-env vs key vs agent),
* which hosts currently hold a live SSH transport (``connected=true``),
* how many active jobs each host has (via the shared :class:`JobManager`),
* which alias is the default for tools that omit the ``host`` argument.

The response deliberately **does not** include secrets — passwords,
password env-var *values*, or key file contents. Only the env variable
*name* and the key file *path* are shown, so an operator can still see
how auth is wired without the tool leaking credentials into the MCP
client's conversation log.

Why it's useful even in single-host setups
------------------------------------------

* Confirms the server started with the config the operator intended.
  A typo in ``--alias`` or in a TOML key shows up immediately.
* Lets the LLM check ``default_host`` before a tool call, which is
  occasionally necessary when the user says "run it on the other host"
  without naming which one.
* Reports ``active_jobs`` per host, a cheap sanity check before
  ``ssh_spawn`` that could push a host over its ``max_jobs_per_host``
  cap.

Error handling
--------------

Same folded-response philosophy as the other tools: a broken config
(which really shouldn't happen post-startup, because the server
validates at boot) surfaces as ``{ok: False, error: {kind, message}}``
rather than an exception. The LLM sees a typed response either way.
"""

from __future__ import annotations

import logging

from fastmcp import FastMCP

from ..config import AppConfig, HostConfig
from ..connection import ConnectionPool
from ..job_manager import JobManager

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Per-host entry builder
# ---------------------------------------------------------------------------


def _host_entry(
    host_cfg: HostConfig,
    *,
    connected: bool,
    active_jobs: int,
    is_default: bool,
) -> dict:
    """Render one :class:`HostConfig` as a JSON-serializable dict.

    Keeps the shape consistent regardless of auth method: ``auth`` is a
    short tag (``"password_env"`` / ``"key"`` / ``"agent"``) and the
    auth-specific detail lives under the corresponding field. An LLM
    pattern-matching on ``auth`` gets a stable branch without having to
    inspect multiple optional fields.

    We never surface the actual password or key passphrase — only the
    env-var *name* and the key *path*. Resolving the password here
    would leak it into the response payload, which goes through the
    MCP client's conversation log; resolving it anywhere but the
    moment of the SSH handshake is a security anti-pattern.
    """
    if host_cfg.key:
        auth_tag = "key"
    elif host_cfg.password_env or host_cfg.password:
        auth_tag = "password_env"
    else:
        # No explicit creds → paramiko will fall back to the user's
        # SSH agent / default keys. Document the assumption explicitly
        # so the operator can tell "nothing configured" from "agent".
        auth_tag = "agent"

    return {
        "alias": host_cfg.alias,
        "host": host_cfg.host,
        "port": host_cfg.port,
        "user": host_cfg.user,
        "auth": auth_tag,
        # Auth detail — same key regardless of mode, value is null when
        # not applicable. Makes it trivial for the LLM to render a
        # one-line host summary.
        "password_env": host_cfg.password_env,
        "key": host_cfg.key,
        "key_passphrase_env": host_cfg.key_passphrase_env,
        # Runtime state
        "connected": connected,
        "active_jobs": active_jobs,
        "is_default": is_default,
    }


# ---------------------------------------------------------------------------
# Response shapes
# ---------------------------------------------------------------------------


def _ok_response(*, hosts: list[dict], default_host: str | None) -> dict:
    """Shape returned on success. Mirrors ``ssh_list_jobs`` for symmetry."""
    return {
        "ok": True,
        "hosts": hosts,
        "total": len(hosts),
        "default_host": default_host,
        "error": None,
    }


def _err_response(*, kind: str, message: str) -> dict:
    """Shape returned on any failure path.

    Mirrors success-shape keys so a pattern-matching LLM gets an empty
    list instead of a KeyError when it forgets to check ``ok``. ``kind``
    values: ``unexpected`` (the only reachable one in practice — config
    validation happens at server startup, so a broken config at tool-
    call time would require extremely unusual runtime tampering).
    """
    return {
        "ok": False,
        "hosts": [],
        "total": 0,
        "default_host": None,
        "error": {"kind": kind, "message": message},
    }


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register(
    mcp: FastMCP,
    pool: ConnectionPool,
    cfg: AppConfig,
    manager: JobManager,
) -> None:
    """Register the ``ssh_list_hosts`` tool on ``mcp``.

    Closes over the :class:`ConnectionPool` (to check per-host live
    connection state via :meth:`SSHConnection.is_connected`), the
    :class:`AppConfig` (source of truth for every registered host),
    and the :class:`JobManager` (authoritative per-host active-job
    count, since the pool only knows "is the transport alive" and not
    "how many Jobs are reading from it").
    """

    @mcp.tool(
        name="ssh_list_hosts",
        description=(
            "List every SSH host this mcp-ssh-live server knows about, "
            "along with its runtime state (connected, active_jobs). "
            "Use this to discover available target aliases in a multi-"
            "host setup, to confirm that a --host flag or TOML entry "
            "landed as expected, and to check the per-host active-"
            "jobs count before spawning another job.\n\n"
            "The response NEVER includes secrets — only the names of "
            "password environment variables and the paths of key "
            "files. The actual password / key contents are resolved "
            "only at SSH handshake time, not here.\n\n"
            "Each entry has: alias, host, port, user, auth ('password_env' "
            "| 'key' | 'agent'), password_env (str or null), key (str "
            "or null), key_passphrase_env (str or null), connected "
            "(bool; whether we currently hold a live SSH transport), "
            "active_jobs (int; jobs registered on this host that are "
            "still running), is_default (bool)."
        ),
    )
    def ssh_list_hosts() -> dict:
        """Return metadata for every configured host.

        Takes no arguments — the full list is always returned. If
        you're thinking of filtering ("only connected", "only hosts
        with jobs"), client-side filtering on the returned list is
        simpler and easier to debug than a growing set of boolean
        flags here.

        Returns:
            A dict with keys ``ok`` (bool), ``hosts`` (list of host
            entries, sorted by alias for determinism), ``total`` (int;
            count of hosts in ``hosts``), ``default_host`` (str or
            null; echoes :attr:`AppConfig.default_host`), ``error``
            (null on success, else ``{kind, message}``).

            Entries come back sorted by alias so an LLM that renders
            them to the user doesn't get a different order each call.
            If you need a different ordering, sort client-side.
        """
        try:
            # Build entries in a stable order. Aliases are the obvious
            # sort key — dict-insertion order reflects TOML / CLI
            # source order, which is brittle across reloads.
            entries: list[dict] = []
            for alias in sorted(cfg.hosts):
                host_cfg = cfg.hosts[alias]

                # "connected" asks the pool, not the config. The pool
                # returns False for any alias it's never been asked
                # about, which is what we want: a host configured but
                # never used shows connected=false.
                connected = False
                try:
                    # :meth:`ConnectionPool.get` has a side-effect of
                    # creating a (disconnected) :class:`SSHConnection`
                    # entry. That's harmless — it doesn't open a
                    # socket, just reserves the slot. But we don't
                    # want the mere act of listing hosts to mutate the
                    # pool, so we peek at the private ``_conns`` dict
                    # under the pool's lock instead.
                    with pool._lock:  # noqa: SLF001 - deliberate peek
                        conn = pool._conns.get(alias)  # noqa: SLF001
                    if conn is not None:
                        connected = conn.is_connected()
                except Exception:  # pragma: no cover - defensive
                    # Any peek failure defaults to "not connected";
                    # correctness over chattiness here.
                    connected = False

                active_jobs = manager.active_count(alias)

                entries.append(
                    _host_entry(
                        host_cfg,
                        connected=connected,
                        active_jobs=active_jobs,
                        is_default=(alias == cfg.default_host),
                    )
                )

            log.debug(
                "ssh_list_hosts: %d host(s), default=%r, connected_count=%d",
                len(entries),
                cfg.default_host,
                sum(1 for e in entries if e["connected"]),
            )

            return _ok_response(hosts=entries, default_host=cfg.default_host)

        except Exception as e:  # pragma: no cover - defensive
            log.exception("ssh_list_hosts: unexpected error")
            return _err_response(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
            )
