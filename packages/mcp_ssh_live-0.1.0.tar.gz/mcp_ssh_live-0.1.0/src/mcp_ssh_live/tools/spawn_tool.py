"""The ``ssh_spawn`` tool — start a long-running remote command in the background.

See ``SPEC.md`` §"MCP Tools (public API)" → "2. ``ssh_spawn``" for the full
contract. In short: open a fresh SSH exec channel, send the
PID-capture-wrapped command, immediately register a :class:`Job` in the
:class:`JobManager`, and return a short ``job_id`` that subsequent
``ssh_tail`` / ``ssh_signal`` / ``ssh_send_stdin`` calls use to address
the job.

Why this is a separate tool from ``ssh_exec``:

* ``ssh_exec`` blocks the MCP round-trip until the command finishes. That's
  fine for ``hostname`` but useless for a 3-hour parser — the MCP client
  (and the LLM waiting on the response) just times out after ~60 s.
* ``ssh_spawn`` returns in <100 ms after ``exec_command`` hands off to the
  remote bash. The LLM then polls ``ssh_tail(job_id, since_line_no, wait_ms)``
  to stream output incrementally, which is the whole point of this project.

Error handling philosophy (same as ``ssh_exec``): we fold
configuration / connection / capacity errors into a structured JSON response
with ``ok=False`` and a human-readable ``error`` field, instead of raising
through FastMCP. MCP clients surface ``isError`` cleanly, but for ``ssh_spawn``
the LLM usually wants to notice the failure, adjust (e.g. pick a different
host, wait for a slot), and move on without losing its turn. A structured
response achieves that; an exception usually doesn't.

PTY mode gotcha (documented in SPEC.md §"8. Line buffering on remote"):

    Many programs line-buffer their stdout when stdin is a TTY and
    block-buffer it otherwise. An LLM that spawns ``python parser.py``
    without ``pty=True`` will see nothing for minutes, then everything
    at once when the process exits. The fix is either ``pty=True`` here
    or ``python -u`` / ``PYTHONUNBUFFERED=1`` on the remote. We document
    both in the tool description so the LLM picks the right one.
"""

from __future__ import annotations

import logging

from fastmcp import FastMCP

from ..config import AppConfig
from ..connection import (
    ConnectionPool,
    SSHConnectError,
    SSHError,
    build_pid_wrapper,
)
from ..job import Job
from ..job_manager import JobCapacityExceeded, JobManager

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Response builders
# ---------------------------------------------------------------------------
#
# We centralize the two response shapes (success + folded-error) so all
# exit paths of the tool produce structurally identical dicts. That makes
# the JSON schema FastMCP derives from the return type stable, and makes
# it trivial for an LLM to pattern-match on ``ok`` without worrying about
# which keys might be missing in an error case.


def _ok_response(
    *,
    job_id: str,
    host: str,
    started_at: float,
    pty: bool,
    label: str | None,
) -> dict:
    """Shape returned on a successful spawn."""
    return {
        "ok": True,
        "job_id": job_id,
        "host": host,
        "started_at": started_at,
        "pty": pty,
        "label": label,
        "error": None,
    }


def _err_response(
    *,
    kind: str,
    message: str,
    host: str = "",
) -> dict:
    """Shape returned on any failure path.

    ``kind`` is a short machine-readable tag (``config``, ``connect``,
    ``capacity``, ``ssh``, ``unexpected``) so the LLM / higher-level
    orchestration code can branch on failure type without regex'ing
    the human message. ``message`` is the full human-readable diagnostic.
    """
    return {
        "ok": False,
        "job_id": "",
        "host": host,
        "started_at": 0.0,
        "pty": False,
        "label": None,
        "error": {"kind": kind, "message": message},
    }


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register(
    mcp: FastMCP,
    pool: ConnectionPool,
    cfg: AppConfig,
    manager: JobManager,
) -> None:
    """Register the ``ssh_spawn`` tool on ``mcp``.

    Closes over ``pool`` (to open SSH channels), ``cfg`` (to resolve host
    aliases and ring-buffer limits), and ``manager`` (to allocate job_ids
    and publish the Job).
    """

    ring_maxlen = cfg.limits.ring_buffer_lines

    @mcp.tool(
        name="ssh_spawn",
        description=(
            "Start a shell command on the remote host IN THE BACKGROUND "
            "and return a short job_id immediately (<100 ms). Use "
            "ssh_tail to stream output line-by-line while the job runs.\n\n"
            "WHEN TO USE ssh_spawn:\n"
            "- You need real-time output in chat (builds, deploys, log tails).\n"
            "- The command takes more than ~60s but you WILL stay connected.\n\n"
            "WARNING — PROCESS DIES ON DISCONNECT:\n"
            "ssh_spawn ties the remote process to the MCP server's SSH "
            "channel. If the MCP server restarts, Zed closes, or the "
            "connection drops — the remote process receives SIGHUP and "
            "dies. Do NOT use ssh_spawn for tasks that must survive a "
            "disconnect (multi-hour training runs, overnight parsers, etc.).\n\n"
            "FOR TASKS THAT MUST SURVIVE DISCONNECT — use ssh_exec with "
            "nohup or screen instead:\n"
            "  ssh_exec('nohup python -u train.py > /tmp/train.log 2>&1 &')\n"
            "  ssh_exec('screen -dmS myjob bash -c \"python train.py\"')\n"
            "Then check progress with:\n"
            "  ssh_exec('tail -n 50 /tmp/train.log')\n"
            "  ssh_exec('screen -r myjob')\n\n"
            "BUFFERING GOTCHA: many programs block-buffer stdout when "
            "stdin is not a TTY, so you see nothing until exit. Fix: "
            "pass pty=True, or use 'python -u' / PYTHONUNBUFFERED=1 / "
            "'stdbuf -oL'. pty=True merges stderr into stdout."
        ),
    )
    def ssh_spawn(
        command: str,
        host: str | None = None,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
        pty: bool = False,
        label: str | None = None,
    ) -> dict:
        """Spawn ``command`` on ``host`` in the background.

        Args:
            command: The shell fragment to run on the remote. Passed to
                an outer ``bash -c`` with a PID-capture prelude, then
                ``exec``'d into an inner ``bash -c "<command>"`` so your
                shell metacharacters (``|``, ``&&``, ``$VAR``,
                redirects) work normally.
            host: Alias of the configured host, or its raw address. If
                omitted, the server's default host is used.
            cwd: Remote working directory (``cd`` before running).
            env: Additional environment variables for the remote process.
                Names must match ``[A-Za-z_][A-Za-z0-9_]*`` (safe env
                name regex, enforced by the wrapper builder).
            pty: Allocate a remote pseudo-TTY. Needed for interactive
                programs (``sudo -S``, REPLs, ``passwd``) and for
                line-buffered output from programs that only flush to a
                TTY. Note: with pty=True the remote kernel merges stderr
                into stdout, and CRLF line endings may appear in the
                buffer (we strip the \\r).
            label: Optional human-readable tag for ``ssh_list_jobs``.
                Useful when the LLM spawns several jobs on the same host
                and needs a memorable handle ("nightly-parser",
                "log-follow", …).

        Returns:
            A dict with keys ``ok`` (bool), ``job_id`` (str; empty on
            failure), ``host`` (str), ``started_at`` (float Unix epoch),
            ``pty`` (bool), ``label`` (str or null), ``error`` (null on
            success, else ``{kind, message}``).

            On success, call ``ssh_tail(job_id, since_line_no=0,
            wait_ms=5000)`` immediately to start the streaming loop. The
            first stdout line you'd naively expect (``PID=<n>``) has
            already been stripped — the reader thread consumes it to
            populate the remote pid used by ``ssh_signal``.
        """
        # --- Resolve host config -------------------------------------------
        # Done first so a typo in ``host`` doesn't burn an SSH channel.
        try:
            host_cfg = cfg.get_host(host)
        except ValueError as e:
            return _err_response(kind="config", message=str(e), host=host or "")

        host_alias = host_cfg.alias

        # --- Get/open the pooled SSH connection ----------------------------
        # The pool is lazy: the first call on a given host triggers the
        # handshake. A connect failure here means paramiko couldn't
        # authenticate / reach the server; fold into the structured
        # error response so the LLM can react.
        conn = pool.get(host_alias)
        try:
            # ``_ensure_client`` is private but the alternative is to
            # let :meth:`SSHConnection.open_session` implicitly connect,
            # which ties error reporting to a less obvious call site.
            conn.connect()
        except SSHConnectError as e:
            log.warning("ssh_spawn connect error on %r: %s", host_alias, e)
            return _err_response(
                kind="connect",
                message=f"cannot establish SSH session: {e}",
                host=host_alias,
            )
        except SSHError as e:
            log.warning("ssh_spawn SSH error on %r: %s", host_alias, e)
            return _err_response(
                kind="ssh",
                message=f"SSH error: {e}",
                host=host_alias,
            )

        # --- Allocate the job_id up-front ----------------------------------
        # Two-phase registration (see JobManager docstring): reserve
        # the id now, so the Job we construct below carries the same id
        # it'll be indexed under. If anything between here and
        # register_new() raises, we must cancel_id() to release the slot.
        try:
            job_id = manager.allocate_id()
        except RuntimeError as e:
            # Only raised when the manager is shutting down.
            return _err_response(
                kind="unexpected",
                message=f"job manager is not accepting new jobs: {e}",
                host=host_alias,
            )

        # --- Build the wrapped command -------------------------------------
        # The wrapper guarantees the first stdout line is PID=<n>, which
        # the Job's stdout reader thread consumes to populate job.pid
        # (used by ssh_signal to fall back to ``kill -SIGNAL <pid>``
        # when OpenSSH's sshd ignores ``channel.send_signal``).
        try:
            wrapped = build_pid_wrapper(command, cwd=cwd, env=env)
        except ValueError as e:
            # Unsafe env var name, empty cwd string, etc.
            manager.cancel_id(job_id)
            return _err_response(
                kind="config",
                message=f"cannot build remote command wrapper: {e}",
                host=host_alias,
            )

        # --- Open the SSH exec channel -------------------------------------
        # We open it here (not inside Job.__init__) so a channel-open
        # failure doesn't leave a half-constructed Job floating around
        # the JobManager. The channel becomes the Job's property once we
        # hand it over to the constructor below.
        try:
            channel = conn.open_session()
        except SSHConnectError as e:
            manager.cancel_id(job_id)
            log.warning("ssh_spawn open_session failed on %r: %s", host_alias, e)
            return _err_response(
                kind="connect",
                message=f"could not open SSH channel: {e}",
                host=host_alias,
            )
        except Exception as e:  # pragma: no cover - defensive
            manager.cancel_id(job_id)
            log.exception("ssh_spawn unexpected error opening channel on %r", host_alias)
            return _err_response(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
                host=host_alias,
            )

        # --- Configure the channel and start the command -------------------
        try:
            if pty:
                # get_pty() must be called BEFORE exec_command(). It
                # fixes line-buffering for most TUI-aware programs and
                # is required for interactive input (sudo, passwd). It
                # has the side effect of merging stderr into stdout at
                # the kernel level — documented in the tool description.
                channel.get_pty()

            # Per-recv timeout — Job.start() will re-set this, but we
            # set it here too so a broken sshd doesn't wedge us between
            # exec_command and Job construction.
            channel.settimeout(0.5)

            # Kick off the remote command. Paramiko buffers this write
            # until ack; a hung sshd here would block, but we've seen
            # sub-10 ms times against a healthy server.
            channel.exec_command(wrapped)
        except Exception as e:
            # Anything from auth-dropped to sshd-refusing-exec. Tear
            # down the channel and release the reserved id.
            try:
                channel.close()
            except Exception:  # pragma: no cover
                pass
            manager.cancel_id(job_id)
            log.warning(
                "ssh_spawn exec_command failed on %r (job_id=%r): %s: %s",
                host_alias,
                job_id,
                type(e).__name__,
                e,
            )
            return _err_response(
                kind="ssh",
                message=f"exec_command failed: {type(e).__name__}: {e}",
                host=host_alias,
            )

        # --- Construct the Job and publish it ------------------------------
        # Construction is cheap (no threads yet). We register with the
        # manager FIRST, then call start() — otherwise a very fast
        # command (``true``) could exit before the manager indexes the
        # job, and a tail() called right after spawn would see
        # JobNotFound.
        job = Job(
            job_id=job_id,
            host=host_alias,
            cmd=command,
            channel=channel,
            ring_maxlen=ring_maxlen,
            capture_pid=True,
            pty=pty,
            label=label,
            # Phase 5: opt-in disk mirror. When the server was started
            # with ``--log-dir PATH`` (or the TOML equivalent), every
            # line written to this job's ring buffer is also appended
            # to ``<PATH>/<job_id>.log``. Set to None here means we pay
            # zero overhead when the operator didn't opt in.
            log_dir=cfg.log_dir,
        )

        try:
            manager.register_new(job)
        except JobCapacityExceeded as e:
            # The per-host cap was hit. Close the channel and release
            # the id; the user can either remove an old job or
            # reconfigure ``limits.max_jobs_per_host`` and retry.
            try:
                channel.close()
            except Exception:  # pragma: no cover
                pass
            # manager.register_new already cancelled our reservation on
            # capacity failure, so we don't call cancel_id() here.
            log.info("ssh_spawn refused: %s", e)
            return _err_response(
                kind="capacity",
                message=str(e),
                host=host_alias,
            )
        except Exception as e:
            # Shutdown race or bug; be defensive so we don't leak a channel.
            try:
                channel.close()
            except Exception:  # pragma: no cover
                pass
            manager.cancel_id(job_id)
            log.exception("ssh_spawn register_new failed on %r", host_alias)
            return _err_response(
                kind="unexpected",
                message=f"could not register job: {type(e).__name__}: {e}",
                host=host_alias,
            )

        # --- Start reader threads AFTER the manager has indexed the job ----
        # From this point on, ssh_tail(job_id) will find the job and
        # see its output stream as it arrives.
        try:
            job.start()
        except Exception as e:
            # Extremely unlikely (thread spawn failure). Tear down.
            log.exception("ssh_spawn Job.start() failed on %r", host_alias)
            try:
                manager.remove(job_id, force=True)
            except Exception:  # pragma: no cover
                pass
            return _err_response(
                kind="unexpected",
                message=f"could not start reader threads: {type(e).__name__}: {e}",
                host=host_alias,
            )

        log.info(
            "ssh_spawn: job=%r host=%r pty=%s label=%r cmd=%s",
            job_id,
            host_alias,
            pty,
            label,
            (command[:80] + "…") if len(command) > 80 else command,
        )

        return _ok_response(
            job_id=job_id,
            host=host_alias,
            started_at=job.started_at,
            pty=pty,
            label=label,
        )
