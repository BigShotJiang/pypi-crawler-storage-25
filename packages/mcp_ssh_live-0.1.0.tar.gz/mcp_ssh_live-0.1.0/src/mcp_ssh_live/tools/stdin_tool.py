"""The ``ssh_send_stdin`` tool — write bytes to a running job's stdin.

See ``SPEC.md`` §"MCP Tools (public API)" → "4. ``ssh_send_stdin``" and
§"Edge cases & decisions" → "2. Interactive input (sudo password)" for
the full design rationale.

What this tool is for
---------------------

Some remote programs need input on stdin after they start:

* ``sudo -S -p ''`` reads the password from stdin (one line).
* ``python`` / ``ipython`` / ``node`` REPLs consume lines of code.
* Interactive CLIs (``psql``, ``mysql``, ``gdb``, ``mc``) expect
  keystrokes.
* Tools like ``tee``, ``wc``, ``sort`` accept piped input from the user.

Without a way to push bytes into the job's stdin, the LLM would have
to pre-bake the input into the command (``echo pw | sudo -S …``),
which leaks the password into the shell history on the remote, into
``ps`` output, and into the MCP client's conversation log. Having a
dedicated ``ssh_send_stdin`` keeps the sensitive payload off the
command line entirely.

How this interacts with ``pty``
--------------------------------

* ``ssh_spawn(pty=False)`` (the default) gives the job a pipe-based
  stdin. Bytes written with :meth:`paramiko.Channel.send` arrive at
  the remote as expected. Stdin can be closed cleanly by the remote
  EOF'ing the channel.

* ``ssh_spawn(pty=True)`` allocates a pseudo-TTY. Writes behave
  slightly differently: the terminal may do ICRNL translation (``\\n``
  → ``\\r``), line discipline may echo input into stdout (so the text
  you just sent reappears on the tail!), and ``Ctrl-C``-style control
  characters need to be sent as raw bytes (e.g. ``\\x03`` for ^C).

Both modes are supported. The tool documents the quirks in its
description so the LLM knows what to expect.

Why we don't auto-append a newline for ``pty=True``
----------------------------------------------------

A TTY's line discipline is in "cooked" mode by default, which means
the remote program only receives input once a ``\\n`` is seen. If we
silently stripped the caller's newlines we'd break interactive REPLs.
If we silently added one on top of the caller's, we'd double-send on
programs that expect a specific separator (e.g. a REPL that wraps
multi-line input with its own continuation). We leave the ``newline``
parameter under caller control with a documented default.

Security surface
----------------

This tool is a deliberate bypass of the "every command is visible to
the MCP approval layer" invariant — the LLM can push arbitrary bytes
into a running remote process with a single tool call, and those
bytes might include a password that the MCP client logged only as
``"len=18"``. Two safeguards:

1. The tool description says so explicitly, so a human configuring
   approval policies knows to gate it more strictly than ``ssh_exec``.
2. We never log the payload contents, only the length. Even DEBUG-
   level logging is payload-blind.

Error handling
--------------

Same folded-response philosophy as the other tools: unknown job_id,
a closed channel, a ``pty``-mismatched write, all become
``{ok: False, error: {kind, message}}`` instead of exceptions. The
LLM sees a typed dict either way.
"""

from __future__ import annotations

import logging

from fastmcp import FastMCP

from ..config import AppConfig
from ..job import Job
from ..job_manager import JobManager, JobNotFound

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
#
# Hard caps live here so tests and operators can see them in one place.
# A real interactive prompt takes a handful of bytes; a REPL that
# ingests kilobytes per turn is unusual but allowed up to the cap.
# Anything bigger should use ``ssh_upload`` — stdin-piping a megabyte
# through an MCP round-trip is almost certainly the wrong design.

# Hard cap on a single ``ssh_send_stdin`` payload. 64 KiB is large
# enough for any real interactive input, small enough to keep a single
# MCP JSON-RPC frame well under typical client buffer limits, and
# matches the natural chunk size paramiko reads from the wire.
_HARD_MAX_BYTES = 65_536

# Per-call write timeout on the paramiko channel. ``channel.send()``
# buffers internally but can block if the remote's input-pipe buffer
# is full (rare — most interactive programs drain their stdin
# immediately). The timeout is short so a misbehaving remote doesn't
# freeze an MCP round-trip.
_SEND_TIMEOUT_SEC = 5.0


# ---------------------------------------------------------------------------
# Response shapes
# ---------------------------------------------------------------------------


def _ok_response(
    *,
    job_id: str,
    host: str,
    bytes_written: int,
    newline_appended: bool,
    closed_stdin: bool,
) -> dict:
    """Shape returned on a successful write.

    ``bytes_written`` counts every byte actually accepted by paramiko
    (including an auto-appended ``\\n`` when ``newline=True``).
    ``newline_appended`` is True iff we added one; this is the only
    way for the caller to distinguish "I passed an explicit ``\\n`` at
    the end" from "the tool added one for me".

    ``closed_stdin`` is True iff the caller asked us to send EOF
    *after* the write (via ``close_stdin=True``). Closing stdin
    signals many programs to exit (``cat``, ``wc``, ``sort``); keeping
    it open is the default so REPLs stay alive for the next write.
    """
    return {
        "ok": True,
        "job_id": job_id,
        "host": host,
        "bytes_written": bytes_written,
        "newline_appended": newline_appended,
        "closed_stdin": closed_stdin,
        "error": None,
    }


def _err_response(
    *,
    kind: str,
    message: str,
    job_id: str = "",
) -> dict:
    """Shape returned on any failure path.

    Mirrors the success shape's keys so the LLM's pattern matching
    is identical in both cases — only the ``ok`` flag and the
    ``error`` object differ. ``bytes_written=0`` on every error
    path, even if a partial write happened before the failure (the
    partial isn't recoverable and reporting a nonzero count would
    mislead retry logic into thinking the write succeeded).
    """
    return {
        "ok": False,
        "job_id": job_id,
        "host": "",
        "bytes_written": 0,
        "newline_appended": False,
        "closed_stdin": False,
        "error": {"kind": kind, "message": message},
    }


# ---------------------------------------------------------------------------
# Payload preparation
# ---------------------------------------------------------------------------


def _prepare_payload(
    data: str,
    *,
    newline: bool,
) -> tuple[bytes, bool]:
    """Turn the caller's ``data`` into the exact bytes we'll send.

    Returns ``(bytes_payload, newline_was_appended)``.

    Rules:

    * The caller's string is UTF-8 encoded. This matches what almost
      every remote program expects for text input; binary stdin (rare
      — usually ``ssh_upload`` territory) isn't supported by this
      tool on purpose.
    * If ``newline=True`` AND the payload doesn't already end in
      ``\\n``, we append one. If it DOES already end in ``\\n``, we
      leave it alone so the caller gets exactly what they asked for.
      Doubling a trailing newline is surprising and breaks REPLs that
      interpret a blank line as "submit current buffer".
    * We never strip a caller-supplied ``\\r`` — pty-mode jobs may
      legitimately want to send CRLF.
    """
    # ``errors='strict'`` here (not 'replace' like in the reader)
    # because an unencodable caller string means the LLM built a
    # payload wrong — silently replacing with U+FFFD would send
    # nonsense to a password prompt and the user would just see
    # "incorrect password" without a hint. Better to fail loudly.
    try:
        payload = data.encode("utf-8")
    except UnicodeEncodeError as e:
        # Shouldn't happen for Python 3 ``str``, but defensive.
        raise ValueError(f"cannot encode data as UTF-8: {e}") from e

    appended = False
    if newline and not payload.endswith(b"\n"):
        payload = payload + b"\n"
        appended = True

    return payload, appended


def _write_all(job: Job, payload: bytes) -> int:
    """Write ``payload`` to the job's channel, returning bytes written.

    paramiko's :meth:`Channel.send` is best-effort: it may return a
    count smaller than ``len(payload)`` if the remote's window is
    full. We loop until the whole payload is flushed or an error
    occurs. A stuck remote would eventually hit our
    :data:`_SEND_TIMEOUT_SEC` via :meth:`Channel.settimeout` and raise
    a timeout exception, which the caller folds into an error
    response.

    Returns the number of bytes successfully written. On partial
    write + error, the caller should treat the whole call as failed
    (the remote program already got a partial line, which is a
    protocol violation for most password / REPL use cases — the LLM
    must decide whether to retry or abort).
    """
    if not payload:
        return 0

    # Short per-call timeout. We restore the channel's own timeout
    # afterwards so the Job's reader threads continue to observe
    # their usual _RECV_TIMEOUT_SEC on recv().
    try:
        prior_timeout = job.channel.gettimeout()
    except Exception:  # pragma: no cover - older paramiko
        prior_timeout = None

    try:
        job.channel.settimeout(_SEND_TIMEOUT_SEC)

        written = 0
        view = memoryview(payload)
        while written < len(payload):
            # send() returns the number of bytes accepted into
            # paramiko's internal buffer. It never raises on partial
            # write — only on closed channel / transport error /
            # timeout — so we loop straightforwardly.
            n = job.channel.send(view[written:])
            if n <= 0:
                # Channel closed while we were writing. Treat as an
                # error; the caller's retry logic will kick in.
                break
            written += n
        return written
    finally:
        # Restore the prior timeout so reader threads aren't left in
        # a surprising state. If prior_timeout was None, clearing is
        # safe (paramiko's default is "blocking").
        try:
            job.channel.settimeout(prior_timeout)
        except Exception:  # pragma: no cover - defensive
            pass


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register(
    mcp: FastMCP,
    cfg: AppConfig,  # noqa: ARG001 - kept for API symmetry with other tool modules
    manager: JobManager,
) -> None:
    """Register the ``ssh_send_stdin`` tool on ``mcp``.

    Closes over the :class:`JobManager` to look up the Job by id.
    Does NOT need the :class:`ConnectionPool` — all writes go to the
    Job's already-open channel, not a fresh session.
    """

    @mcp.tool(
        name="ssh_send_stdin",
        description=(
            "Write bytes to the stdin of a running job (one spawned "
            "by ssh_spawn). Used for password prompts (sudo -S -p ''), "
            "REPL input (python, node), and any interactive CLI that "
            "expects keystrokes.\n\n"
            "By default a trailing '\\n' is appended so the remote "
            "program sees a complete line (this is what 'sudo -S' and "
            "most line-based REPLs need). Set newline=False to send "
            "raw bytes without the terminator — useful for control "
            "characters (e.g. data='\\x03' to send ^C to a pty-mode "
            "job, or data='\\x04' for ^D / EOF).\n\n"
            "Set close_stdin=True to close the remote's stdin AFTER "
            "the write, which signals EOF to programs like 'cat', "
            "'wc', 'sort'. Leaving it open (default) lets you make "
            "more writes to the same job.\n\n"
            "IMPORTANT: for password input, pair this with "
            "ssh_spawn(pty=True) AND the command 'sudo -S -p \"\"'. "
            "Without pty=True, sudo refuses to read the password from "
            'a pipe on most distros. Without the -p "" flag, sudo '
            "writes its prompt to stdout, which mixes into ssh_tail "
            "output.\n\n"
            "Payload size is capped at 64 KiB per call. For larger "
            "input use ssh_upload to place a file on disk, then have "
            "the command read from it."
        ),
    )
    def ssh_send_stdin(
        job_id: str,
        data: str,
        newline: bool = True,
        close_stdin: bool = False,
    ) -> dict:
        """Write ``data`` to the stdin of ``job_id``'s remote process.

        Args:
            job_id: The id returned by ``ssh_spawn``.
            data: The text to send, UTF-8 encoded on the wire. Can be
                empty; an empty ``data`` with ``newline=True`` sends
                just a single ``\\n`` (useful for "press Enter"
                prompts). Control characters are passed verbatim, so
                ``"\\x03"`` sends ^C to a pty-mode job's line
                discipline.
            newline: When True (default), append a ``\\n`` to ``data``
                unless it already ends with one. When False, send
                exactly the bytes in ``data`` — useful for control
                characters (``\\x03`` for ^C, ``\\x04`` for ^D) and
                for multi-write sequences that assemble a line
                progressively.
            close_stdin: When True, close the remote's stdin channel
                AFTER the write completes. Signals EOF to the remote
                program. When False (default), stdin stays open and
                you can make subsequent ssh_send_stdin calls.

        Returns:
            A dict with keys ``ok`` (bool), ``job_id`` (str),
            ``host`` (str), ``bytes_written`` (int; total bytes
            accepted by paramiko, including any auto-appended ``\\n``),
            ``newline_appended`` (bool; whether the tool added a
            newline), ``closed_stdin`` (bool; echo of the
            ``close_stdin`` argument on success), ``error`` (null on
            success, else ``{kind, message}``).

            Error ``kind`` values: ``bad_param`` (empty job_id,
            data not a string, payload too large), ``not_found``
            (unknown job_id), ``not_running`` (job already exited),
            ``channel_closed`` (stdin has already been closed),
            ``write_failed`` (paramiko error during send),
            ``unexpected``.
        """
        # --- Validate job_id ---------------------------------------------
        if not job_id or not isinstance(job_id, str):
            return _err_response(
                kind="bad_param",
                message=f"job_id must be a non-empty string; got {job_id!r}",
                job_id=str(job_id) if job_id else "",
            )

        # --- Validate data ------------------------------------------------
        # We accept ``""`` (with newline=True it still sends "\n" — a
        # "press Enter" operation). We reject non-string types because
        # the tool is declared as ``data: str`` and a caller who
        # accidentally sent a bytes object or a dict would otherwise
        # trigger an opaque TypeError inside _prepare_payload.
        if not isinstance(data, str):
            return _err_response(
                kind="bad_param",
                message=f"data must be a string; got {type(data).__name__}",
                job_id=job_id,
            )

        # Encode up front to size-check BEFORE touching paramiko. This
        # is cheap and catches oversized payloads without any channel
        # state being affected.
        try:
            payload, newline_appended = _prepare_payload(data, newline=newline)
        except ValueError as e:
            return _err_response(
                kind="bad_param",
                message=str(e),
                job_id=job_id,
            )

        if len(payload) > _HARD_MAX_BYTES:
            return _err_response(
                kind="bad_param",
                message=(
                    f"payload too large: {len(payload)} bytes (cap {_HARD_MAX_BYTES}); "
                    "use ssh_upload for larger inputs"
                ),
                job_id=job_id,
            )

        # --- Look up the job ---------------------------------------------
        try:
            job = manager.get(job_id)
        except JobNotFound as e:
            return _err_response(kind="not_found", message=str(e), job_id=job_id)
        except Exception as e:  # pragma: no cover - defensive
            log.exception("ssh_send_stdin: unexpected lookup error for %r", job_id)
            return _err_response(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
                job_id=job_id,
            )

        # --- Check job is still running ----------------------------------
        # Writing to a finished job's channel either raises or
        # silently discards (paramiko behavior varies). Either way
        # the user almost certainly made a mistake — report it
        # explicitly so the LLM can course-correct (e.g. spawn a new
        # job, or stop the retry loop).
        if not job.is_running():
            snap = job.snapshot()
            return _err_response(
                kind="not_running",
                message=(
                    f"job {job_id!r} is not running "
                    f"(status={snap.status}, exit_status={snap.exit_status}); "
                    "cannot send stdin to a finished job"
                ),
                job_id=job_id,
            )

        # --- Additional sanity on the channel -----------------------------
        # ``channel.eof_sent`` is True once we've called
        # ``shutdown_write()`` (i.e. a previous ssh_send_stdin call
        # closed stdin). Writing after that would either fail silently
        # or raise inside paramiko depending on version. Report it as
        # a distinct error so the LLM knows why.
        try:
            if getattr(job.channel, "eof_sent", False):
                return _err_response(
                    kind="channel_closed",
                    message=(
                        f"stdin for job {job_id!r} was already closed "
                        "(close_stdin=True on a previous call); re-spawn the job to send more"
                    ),
                    job_id=job_id,
                )
        except Exception:  # pragma: no cover - attribute may be missing
            pass

        # --- Do the write -------------------------------------------------
        # We log only the byte count, NEVER the payload. This is the
        # key security property of the tool (see module docstring):
        # an operator who reads the server logs must not be able to
        # reconstruct a password from them.
        log.info(
            "ssh_send_stdin: job=%r bytes=%d newline_appended=%s close_stdin=%s",
            job_id,
            len(payload),
            newline_appended,
            close_stdin,
        )

        try:
            written = _write_all(job, payload)
        except Exception as e:
            log.warning(
                "ssh_send_stdin: write failed for job %r after %d bytes: %s: %s",
                job_id,
                0,
                type(e).__name__,
                e,
            )
            return _err_response(
                kind="write_failed",
                message=f"paramiko write failed: {type(e).__name__}: {e}",
                job_id=job_id,
            )

        # If we wrote less than the full payload, the channel closed
        # mid-write. Report as write_failed with enough detail for
        # the LLM to decide what to do.
        if written != len(payload):
            return _err_response(
                kind="write_failed",
                message=(
                    f"short write: {written}/{len(payload)} bytes "
                    "(remote channel probably closed mid-write)"
                ),
                job_id=job_id,
            )

        # --- Optionally close stdin --------------------------------------
        # ``shutdown_write()`` sends an SSH EOF on the stdin direction
        # of the channel. The remote sees its stdin hit EOF, which is
        # what ``cat`` / ``wc`` / ``sort`` need to finalize their
        # output and exit. The channel's stdout/stderr stay open and
        # our reader threads keep draining them until the remote
        # closes those too.
        closed = False
        if close_stdin:
            try:
                job.channel.shutdown_write()
                closed = True
            except Exception as e:
                # The write itself succeeded; only the EOF send
                # failed. Surface a partial-success response rather
                # than throwing away the successful write.
                log.warning(
                    "ssh_send_stdin: shutdown_write failed for job %r: %s: %s",
                    job_id,
                    type(e).__name__,
                    e,
                )
                return _err_response(
                    kind="write_failed",
                    message=(
                        f"write succeeded ({written} bytes) but closing stdin failed: "
                        f"{type(e).__name__}: {e}"
                    ),
                    job_id=job_id,
                )

        snap = job.snapshot()
        return _ok_response(
            job_id=job_id,
            host=snap.host,
            bytes_written=written,
            newline_appended=newline_appended,
            closed_stdin=closed,
        )
