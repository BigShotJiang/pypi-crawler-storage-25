"""The ``ssh_signal`` tool — deliver POSIX signals to a spawned job.

See ``SPEC.md`` §"MCP Tools (public API)" → "5. ``ssh_signal``" and
§"Edge cases & decisions" → "1. Signal handling on typical sshd" for the
full design rationale.

The problem in one paragraph
----------------------------

Paramiko exposes :meth:`paramiko.Channel.send_signal`, which *should*
deliver a SIGTERM / SIGKILL / SIGINT to the remote process. In practice,
most OpenSSH ``sshd`` builds ignore that request entirely — they require
``AcceptEnv SSH_SIGNAL`` or similar configuration that is almost never
present on real servers. Relying on ``send_signal`` alone means "kill my
runaway job" silently does nothing, which is a terrible failure mode for
an LLM-driven tool (the agent thinks it killed the job, keeps polling,
and the job runs to completion anyway).

Our fix (the VS Code Remote trick)
-----------------------------------

When ``ssh_spawn`` starts a job it wraps the user command in a
``bash -c 'echo PID=$$ && exec bash -c "<cmd>"'`` prelude. The first
stdout line is ``PID=<n>``; the Job's stdout reader thread consumes it
and stashes the integer in :attr:`Job.pid`. That ``pid`` is the PID of
the **inner bash** that's running the user's command (the ``exec``
preserves it across the outer-shell replacement) — killing that PID
terminates the whole remote process tree.

``ssh_signal`` therefore has two delivery paths:

1. **``channel.send_signal``** — tried first because it's the fastest
   (no extra SSH exec) and the semantically cleanest (the signal is
   delivered to the exact channel's foreground process group). Usually
   a silent no-op, but on sshd builds that do honor it, this is the
   right answer.

2. **``kill -<SIG> <pid>``** fallback — opened as a brand-new short
   exec channel on the same :class:`paramiko.Transport`. This runs as
   the same SSH user, so it can signal any process that user owns,
   which includes the spawned job. We wait up to ~500 ms for the kill
   command itself to exit, then return.

Both paths are issued on every call (unless ``use_pid_fallback=False``);
the cost of a "double kill" is negligible and the belt-and-braces
approach means we don't have to guess which path the remote sshd
honors.

Status reporting
----------------

The tool returns ``{ok, sent, exit_status, ...}``. ``sent=True`` means
"at least one delivery path did not error out" — it does NOT guarantee
the remote process actually died, because Unix signals are fire-and-
forget. To know for sure, the caller should either:

* poll ``ssh_tail`` until ``still_running=False``, or
* pass ``wait_ms`` to this tool: we'll wait up to that long for the
  job's ``done_event`` to fire and report the resulting ``exit_status``
  in the response. This is a quality-of-life feature for the common
  "kill-and-confirm" pattern the LLM usually wants.

Signal vocabulary
-----------------

We accept the common human-readable names (``TERM``, ``KILL``, ``INT``,
``HUP``, ``QUIT``, ``USR1``, ``USR2``, ``STOP``, ``CONT``) both with and
without the ``SIG`` prefix, case-insensitive. A numeric name (``"9"``
or ``9``) is also accepted, because LLMs occasionally emit the number
they remembered for SIGKILL rather than the name. Unknown names are
rejected loudly with an ``bad_param`` error — silently mapping them to
SIGTERM would hide a real caller bug.

Error handling
--------------

Same folded-response shape as the other tools: unknown job_id, missing
PID capture (on a job that was spawned without the wrapper),
connection-drop mid-signal, invalid signal name — each becomes a
structured ``{ok: False, error: {kind, message}}`` dict instead of an
exception. The LLM sees a well-typed response in every case and can
branch on ``error.kind``.
"""

from __future__ import annotations

import logging
import time

from fastmcp import FastMCP

from ..config import AppConfig
from ..connection import ConnectionPool, SSHConnectError, SSHError
from ..job import Job
from ..job_manager import JobManager, JobNotFound

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Signal-name normalization
# ---------------------------------------------------------------------------
#
# We keep our own whitelist instead of delegating to :mod:`signal`:
#
# * ``signal.Signals`` on Windows is missing most POSIX signals (SIGKILL,
#   SIGHUP, SIGQUIT, SIGUSR1/2), so ``signal.Signals[name]`` raises
#   KeyError and we'd have to special-case it anyway. The whitelist makes
#   the tool cross-platform by default.
#
# * The wire format on the remote is ``kill -<NAME>`` where ``<NAME>``
#   is a string understood by the remote ``kill`` builtin. All common
#   shells accept both ``kill -TERM`` and ``kill -15``, so we normalize
#   to the name form (which is more readable in audit logs) and only
#   fall back to the number if we don't recognize the name.
#
# Both forms are kept deliberately to let the LLM pick whichever it
# remembers — numerics are especially useful when it's mimicking the
# syntax of a shell snippet it saw in documentation.

# Canonical (SIG-prefixed) name → POSIX number. The number is used
# purely for reporting and for the numeric-form fallback; the delivery
# path always uses the canonical name in the remote command.
_SIGNAL_NUMBERS: dict[str, int] = {
    "SIGTERM": 15,
    "SIGKILL": 9,
    "SIGINT": 2,
    "SIGHUP": 1,
    "SIGQUIT": 3,
    "SIGUSR1": 10,
    "SIGUSR2": 12,
    "SIGSTOP": 19,
    "SIGCONT": 18,
    "SIGABRT": 6,
    "SIGPIPE": 13,
    "SIGALRM": 14,
}

# Number → canonical name, for the "caller passed ``9``" path.
_NUMBER_TO_SIGNAL: dict[int, str] = {v: k for k, v in _SIGNAL_NUMBERS.items()}


class _BadSignalName(ValueError):
    """Raised by :func:`_normalize_signal_name` when the input is unparseable.

    Kept module-private because :func:`ssh_signal` folds it into the
    structured error response — it never escapes to the MCP client.
    """


def _normalize_signal_name(raw) -> tuple[str, int]:
    """Coerce a user-supplied signal argument to ``(canonical_name, number)``.

    Accepts:

    * strings, case-insensitive, with or without ``SIG`` prefix
      (``"TERM"``, ``"sigterm"``, ``"SIGTERM"`` all map to
      ``("SIGTERM", 15)``);
    * numeric strings (``"9"`` → ``("SIGKILL", 9)``);
    * plain ints (``9`` → ``("SIGKILL", 9)``).

    Returns the canonical name (for use in the remote ``kill`` command
    and in log lines) and the numeric value (for the response payload,
    so callers can assert on a stable representation).

    Raises :class:`_BadSignalName` with a human-readable message on any
    unknown signal. The caller surfaces this as ``kind="bad_param"``.
    """
    # --- Integer path: accepted verbatim if we know the number -----------
    if isinstance(raw, bool):
        # ``bool`` is a subclass of ``int``; a caller passing ``True``
        # almost certainly made a typing mistake and didn't mean
        # SIGHUP. Reject loudly.
        raise _BadSignalName(
            f"signal must be a name (e.g. 'TERM') or a POSIX number (e.g. 15); got bool {raw!r}"
        )
    if isinstance(raw, int):
        name = _NUMBER_TO_SIGNAL.get(raw)
        if name is None:
            raise _BadSignalName(f"unknown signal number {raw}; known: {sorted(_NUMBER_TO_SIGNAL)}")
        return name, raw

    # --- String path: strip SIG, uppercase, accept name OR stringified int
    if not isinstance(raw, str):
        raise _BadSignalName(f"signal must be a string or int; got {type(raw).__name__}")

    s = raw.strip()
    if not s:
        raise _BadSignalName("signal name is empty")

    # Numeric string: delegate to the int path.
    if s.lstrip("-").isdigit():
        try:
            return _normalize_signal_name(int(s))
        except _BadSignalName:
            raise  # re-raise with the integer-path message

    upper = s.upper()
    canonical = upper if upper.startswith("SIG") else f"SIG{upper}"

    number = _SIGNAL_NUMBERS.get(canonical)
    if number is None:
        raise _BadSignalName(
            f"unknown signal {raw!r}; known: "
            f"{sorted(n.removeprefix('SIG') for n in _SIGNAL_NUMBERS)}"
        )
    return canonical, number


# ---------------------------------------------------------------------------
# Response shapes
# ---------------------------------------------------------------------------


def _ok_response(
    *,
    job_id: str,
    host: str,
    signal_name: str,
    signal_number: int,
    sent_via_channel: bool,
    sent_via_pid: bool,
    pid: int | None,
    exit_status: int | None,
    still_running: bool,
) -> dict:
    """Shape returned on a successful (or best-effort) signal delivery.

    ``sent`` is the OR of the two delivery paths — True if at least one
    didn't error out. The per-path booleans (``sent_via_channel`` /
    ``sent_via_pid``) let an operator debug *why* a signal didn't take
    effect on a specific server (``channel.send_signal`` ignored? PID
    capture missing? both?).
    """
    return {
        "ok": True,
        "job_id": job_id,
        "host": host,
        "signal": signal_name,
        "signal_number": signal_number,
        "sent": sent_via_channel or sent_via_pid,
        "sent_via_channel": sent_via_channel,
        "sent_via_pid": sent_via_pid,
        "pid": pid,
        "exit_status": exit_status,
        "still_running": still_running,
        "error": None,
    }


def _err_response(
    *,
    kind: str,
    message: str,
    job_id: str = "",
) -> dict:
    """Shape returned on any failure path. Mirrors success-shape keys so
    pattern-matching on the response doesn't have to special-case
    errors — ``sent`` is False, every per-path flag is False, every
    optional field is None / empty.
    """
    return {
        "ok": False,
        "job_id": job_id,
        "host": "",
        "signal": "",
        "signal_number": 0,
        "sent": False,
        "sent_via_channel": False,
        "sent_via_pid": False,
        "pid": None,
        "exit_status": None,
        "still_running": False,
        "error": {"kind": kind, "message": message},
    }


# ---------------------------------------------------------------------------
# Delivery helpers (split out so the tool function stays readable and
# each path is individually testable)
# ---------------------------------------------------------------------------


def _try_channel_send_signal(job: Job, signal_name: str) -> bool:
    """Try paramiko's in-channel signal delivery. Returns True on success.

    ``channel.send_signal`` expects the signal name WITHOUT the ``SIG``
    prefix per RFC 4254 §6.9 (e.g. ``"TERM"``, not ``"SIGTERM"``). We
    strip the prefix here so callers don't have to know.

    Always a best-effort; silently returns False on:

    * a closed channel (job already finished between snapshot and send),
    * paramiko raising :class:`paramiko.SSHException` because the
      underlying transport rejected the request,
    * the remote sshd accepting the request but having no effect
      (we can't detect this — it looks the same as success on our side).
    """
    # Remove SIG prefix per RFC 4254 wire format. Our normalized names
    # always have the prefix (``SIGTERM``); the wire sends ``TERM``.
    wire_name = signal_name.removeprefix("SIG")

    try:
        # paramiko.Channel.send_signal exists on all supported versions;
        # a very old paramiko might not have it, in which case we'd
        # get AttributeError and the caller just moves on to the pid
        # fallback.
        job.channel.send_signal(wire_name)
        return True
    except AttributeError:
        log.debug("paramiko channel has no send_signal(); skipping in-channel path")
        return False
    except Exception as e:
        # Channel closed, transport dead, sshd rejected: all "oh well,
        # try the fallback". Log at debug so a server that routinely
        # rejects send_signal doesn't spam warnings on every kill.
        log.debug(
            "channel.send_signal(%r) failed for job %r: %s: %s",
            wire_name,
            job.job_id,
            type(e).__name__,
            e,
        )
        return False


def _try_remote_kill(
    pool: ConnectionPool,
    job: Job,
    signal_name: str,
) -> tuple[bool, str | None]:
    """Open a fresh short exec channel and run ``kill -<SIG> <pid>``.

    Returns ``(success, error_message_or_None)``. The error message is
    only populated on failure, so the caller can include it in the
    tool response's ``error`` field if BOTH delivery paths fail.

    Why a fresh channel instead of reusing the job's: the job's
    channel is owned by its reader threads. Writing an exec to it
    would either conflict with ``channel.exec_command`` (single use)
    or mangle its stdout. A new short-lived channel on the same
    :class:`paramiko.Transport` is the SPEC-prescribed idiom and costs
    one round-trip.

    The kill command runs as the same SSH user (the one configured for
    the host). It can therefore only signal processes owned by that
    user. For root that's everything; for a non-root user it's
    whatever they spawned — which is exactly what we want, since they
    spawned the job via this same connection.
    """
    if job.pid is None:
        return False, "no PID captured for this job (was it spawned without the wrapper?)"

    # The wire name for ``kill`` accepts both ``-TERM`` and ``-SIGTERM``;
    # we use the short form because that's what 99% of docs show.
    short_name = signal_name.removeprefix("SIG")
    kill_cmd = f"kill -{short_name} {int(job.pid)}"

    try:
        conn = pool.get(job.host)
    except SSHError as e:
        return False, f"cannot resolve SSH connection for host {job.host!r}: {e}"

    try:
        conn.connect()
    except SSHConnectError as e:
        return False, f"SSH connection to {job.host!r} is down: {e}"
    except SSHError as e:
        return False, f"SSH error on {job.host!r}: {e}"

    # Fire the kill on a brand-new session. paramiko's Transport
    # supports many concurrent channels (that's why we picked it), so
    # this does NOT disturb the job's own stdout/stderr reader threads.
    try:
        chan = conn.open_session()
    except SSHError as e:
        return False, f"could not open session for kill command: {e}"

    try:
        # Short timeout on recv so we don't hang if the remote sshd is
        # misbehaving. ``kill`` exits in < 10 ms on any real system.
        chan.settimeout(1.0)
        chan.exec_command(kill_cmd)

        # Wait briefly for exit_status so we can distinguish "kill
        # succeeded" (exit 0) from "no such pid" (exit 1) from "access
        # denied" (exit 1 with "Operation not permitted" on stderr).
        # 500 ms is generous; a real kill returns in single-digit ms.
        deadline = time.monotonic() + 0.5
        while time.monotonic() < deadline:
            if chan.exit_status_ready():
                break
            time.sleep(0.01)

        if chan.exit_status_ready():
            rc = chan.recv_exit_status()
            if rc == 0:
                return True, None

            # Drain stderr for a diagnostic. Best-effort — on some
            # builds ``kill -9`` doesn't print anything on failure.
            err_chunks: list[bytes] = []
            while chan.recv_stderr_ready():
                try:
                    err_chunks.append(chan.recv_stderr(4096))
                except Exception:
                    break
            err_text = b"".join(err_chunks).decode("utf-8", errors="replace").strip()
            msg = f"remote 'kill -{short_name} {job.pid}' exited {rc}"
            if err_text:
                msg = f"{msg}: {err_text}"
            return False, msg

        # Kill command didn't even finish in our window. Not necessarily
        # a problem — the signal may still have been delivered — but we
        # can't confirm, so report best-effort success with a note.
        return True, None
    except Exception as e:
        log.debug("remote kill exec failed for job %r: %s", job.job_id, e, exc_info=True)
        return False, f"{type(e).__name__}: {e}"
    finally:
        try:
            chan.close()
        except Exception:  # pragma: no cover
            pass


def _wait_for_exit(job: Job, *, timeout_sec: float) -> None:
    """Block up to ``timeout_sec`` for the job's done_event to fire.

    Convenience wrapper so the main tool function reads cleanly. Does
    nothing on a zero or negative timeout (callers can always skip the
    wait and poll ``ssh_tail`` themselves).
    """
    if timeout_sec <= 0:
        return
    job.done_event.wait(timeout=timeout_sec)


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register(
    mcp: FastMCP,
    pool: ConnectionPool,
    cfg: AppConfig,  # noqa: ARG001 - kept for API symmetry with other tools
    manager: JobManager,
) -> None:
    """Register the ``ssh_signal`` tool on ``mcp``.

    Closes over the :class:`ConnectionPool` (needed for the PID-fallback
    ``kill`` exec on a fresh channel) and the :class:`JobManager`
    (needed to look up the Job by id and reach its captured PID).
    """

    @mcp.tool(
        name="ssh_signal",
        description=(
            "Deliver a POSIX signal (TERM, KILL, INT, HUP, QUIT, "
            "USR1, USR2, STOP, CONT, and a few others) to a job "
            "started by ssh_spawn. Use TERM (polite, the default) "
            "for graceful shutdown; use KILL only when TERM fails to "
            "stop the job within a reasonable window.\n\n"
            "Delivery strategy: we first try paramiko's in-channel "
            "send_signal (often ignored by OpenSSH sshd), then "
            "fall back to 'kill -<SIG> <pid>' on a fresh SSH session "
            "using the PID captured at spawn time. Both paths are "
            "attempted unless use_pid_fallback=False.\n\n"
            "Pass wait_ms > 0 to block up to that many milliseconds "
            "waiting for the job to actually exit; the response then "
            "includes the real exit_status. Otherwise we return "
            "immediately with still_running indicating whether the "
            "signal took effect within the fire-and-forget window.\n\n"
            "Common patterns:\n"
            "  # Polite stop, wait up to 5 s:\n"
            "  ssh_signal(job_id, 'TERM', wait_ms=5000)\n"
            "  # Hard kill, don't wait (verify via ssh_tail later):\n"
            "  ssh_signal(job_id, 'KILL')\n"
            "  # Interrupt (like Ctrl-C):\n"
            "  ssh_signal(job_id, 'INT')"
        ),
    )
    def ssh_signal(
        job_id: str,
        signal: str = "TERM",
        wait_ms: int = 0,
        use_channel: bool = True,
        use_pid_fallback: bool = True,
    ) -> dict:
        """Send ``signal`` to the remote process behind ``job_id``.

        Args:
            job_id: The id returned by ``ssh_spawn``.
            signal: Signal name (``"TERM"``, ``"SIGTERM"``, ``"kill"``,
                …) or POSIX number (``9``, ``"9"``). Case-insensitive.
                Defaults to ``"TERM"`` — the polite choice.
            wait_ms: If > 0, after delivering the signal we block up to
                this many milliseconds for the job's done_event to
                fire, and report the real ``exit_status`` in the
                response. Capped internally at 30000 ms. A value of 0
                (default) returns immediately.
            use_channel: When True (default), try paramiko's
                in-channel ``send_signal`` first. Set to False to skip
                this path entirely — occasionally useful on a server
                known to reject it in ways that leave the channel in a
                bad state.
            use_pid_fallback: When True (default), open a fresh SSH
                session and run ``kill -<SIG> <pid>``. Requires the
                job to have been spawned with PID capture enabled
                (which is always the case via ssh_spawn). Set to False
                if you specifically want to verify whether
                ``channel.send_signal`` alone works on your server.

        Returns:
            A dict with keys ``ok``, ``job_id``, ``host``, ``signal``
            (canonical name like ``"SIGTERM"``), ``signal_number``,
            ``sent`` (bool; at-least-one-path succeeded),
            ``sent_via_channel`` (bool), ``sent_via_pid`` (bool),
            ``pid`` (the captured remote PID or null), ``exit_status``
            (int if the job exited within wait_ms, else null),
            ``still_running`` (bool), ``error`` (null on success, else
            ``{kind, message}``).

            Error ``kind`` values: ``bad_param`` (unknown signal name /
            empty job_id), ``not_found`` (job_id unknown), ``no_pid``
            (PID fallback requested but no PID was captured — rare,
            usually indicates a broken wrapper), ``delivery_failed``
            (both paths errored out), ``unexpected``.
        """
        # --- Validate job_id ---------------------------------------------
        if not job_id or not isinstance(job_id, str):
            return _err_response(
                kind="bad_param",
                message=f"job_id must be a non-empty string; got {job_id!r}",
                job_id=str(job_id) if job_id else "",
            )

        # --- Parse and normalize the signal name -------------------------
        try:
            signal_name, signal_number = _normalize_signal_name(signal)
        except _BadSignalName as e:
            return _err_response(
                kind="bad_param",
                message=str(e),
                job_id=job_id,
            )

        # --- Clamp wait_ms -----------------------------------------------
        # 30 s ceiling mirrors ssh_tail's hard cap; keeps an MCP round-
        # trip thread from being held for too long by an over-eager
        # wait parameter.
        if wait_ms < 0:
            wait_ms = 0
        if wait_ms > 30_000:
            log.debug("ssh_signal: wait_ms=%d capped to 30000", wait_ms)
            wait_ms = 30_000

        # --- Look up the job ---------------------------------------------
        try:
            job = manager.get(job_id)
        except JobNotFound as e:
            return _err_response(kind="not_found", message=str(e), job_id=job_id)
        except Exception as e:  # pragma: no cover - defensive
            log.exception("ssh_signal: unexpected lookup error for %r", job_id)
            return _err_response(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
                job_id=job_id,
            )

        # If the job is already done, signaling is a no-op. We still
        # return ok=True with sent=False so the LLM can see "yeah, I
        # asked to kill it, but it was already dead" without having to
        # disambiguate that from a real failure.
        if not job.is_running():
            snap = job.snapshot()
            log.info(
                "ssh_signal: job %r already finished (status=%s exit=%s); no signal sent",
                job_id,
                snap.status,
                snap.exit_status,
            )
            return _ok_response(
                job_id=job_id,
                host=snap.host,
                signal_name=signal_name,
                signal_number=signal_number,
                sent_via_channel=False,
                sent_via_pid=False,
                pid=snap.pid,
                exit_status=snap.exit_status,
                still_running=False,
            )

        # --- Attempt delivery via both paths -----------------------------
        # We run both paths unconditionally (unless the caller opted
        # out) because signals are idempotent — delivering SIGTERM
        # twice is indistinguishable from once, and the cost of the
        # second delivery is one cheap exec channel.

        sent_via_channel = False
        if use_channel:
            sent_via_channel = _try_channel_send_signal(job, signal_name)

        sent_via_pid = False
        pid_error: str | None = None
        if use_pid_fallback:
            if job.pid is None:
                # Caller asked for PID fallback but we never captured
                # one. Report a distinct error kind so the LLM can
                # decide whether to retry with use_pid_fallback=False.
                if not sent_via_channel:
                    return _err_response(
                        kind="no_pid",
                        message=(
                            "cannot use PID fallback: no PID was captured "
                            f"for job {job_id!r} (re-spawn with capture_pid=True)"
                        ),
                        job_id=job_id,
                    )
                # Channel path succeeded; skip the fallback silently.
                pid_error = "no PID captured; PID fallback skipped"
            else:
                sent_via_pid, pid_error = _try_remote_kill(pool, job, signal_name)

        # If neither path delivered, surface as delivery_failed.
        if not sent_via_channel and not sent_via_pid:
            msg_parts: list[str] = []
            if use_channel:
                msg_parts.append("channel.send_signal was rejected or unsupported")
            if use_pid_fallback and pid_error:
                msg_parts.append(f"PID fallback: {pid_error}")
            if not msg_parts:
                msg_parts.append("no delivery path was enabled")
            return _err_response(
                kind="delivery_failed",
                message=f"could not deliver {signal_name} to job {job_id!r}: "
                + "; ".join(msg_parts),
                job_id=job_id,
            )

        # --- Record the kill intent on the Job ---------------------------
        # mark_killed is idempotent and appends a synthetic stderr
        # line so an ssh_tail poller sees a clear reason for the
        # eventual exit. Called AFTER delivery attempts so we don't
        # mislabel a job whose signal we failed to deliver at all.
        try:
            job.mark_killed(signal_name.removeprefix("SIG"))
        except Exception:  # pragma: no cover - best-effort
            log.debug("ssh_signal: mark_killed failed for %r", job_id, exc_info=True)

        # --- Optional wait for exit --------------------------------------
        if wait_ms > 0:
            _wait_for_exit(job, timeout_sec=wait_ms / 1000.0)

        # --- Snapshot and return -----------------------------------------
        snap = job.snapshot()
        still_running = snap.exit_status is None and job.is_running()

        log.info(
            "ssh_signal: job=%r sig=%s sent_via_channel=%s sent_via_pid=%s "
            "waited_ms=%d still_running=%s exit=%s",
            job_id,
            signal_name,
            sent_via_channel,
            sent_via_pid,
            wait_ms,
            still_running,
            snap.exit_status,
        )

        return _ok_response(
            job_id=job_id,
            host=snap.host,
            signal_name=signal_name,
            signal_number=signal_number,
            sent_via_channel=sent_via_channel,
            sent_via_pid=sent_via_pid,
            pid=snap.pid,
            exit_status=snap.exit_status,
            still_running=still_running,
        )
