"""The ``ssh_tail`` tool — stream incremental output from a spawned job.

See ``SPEC.md`` §"MCP Tools (public API)" → "3. ``ssh_tail``" for the full
contract.

This is the single most important tool of the project: the reason
``mcp-ssh-live`` exists is so that an LLM can call
``ssh_tail(job_id, since_line_no=N, wait_ms=5000)`` in a loop and watch a
long-running remote command's output arrive line by line, instead of
waiting hours for a ``ssh_exec`` to return.

Contract summary
----------------

Given a ``job_id`` returned by ``ssh_spawn`` and a monotonic cursor
``since_line_no``, return every buffered line with
``line_no > since_line_no`` (up to ``max_lines``), across the requested
stream(s). If ``wait_ms > 0`` and there's nothing newer than the cursor
**at the moment of the call**, block up to ``wait_ms`` milliseconds on a
condition variable and return as soon as either:

* a new line is appended,
* the job finishes (``done_event`` fires), or
* the timeout elapses.

The response always includes:

* ``lines`` — the new JobLines, chronologically ordered by ``line_no``
  (merged across stdout / stderr when ``stream="both"``).
* ``last_line_no`` — the largest ``line_no`` in ``lines``, or the
  caller's ``since_line_no`` if ``lines`` is empty. Callers feed this
  back as ``since_line_no`` on the next poll.
* ``still_running`` / ``exit_status`` / ``status`` — so the LLM knows
  when to stop polling.
* ``buffer_truncated`` — True if older-than-cursor lines have been
  evicted from the ring buffer (see :meth:`RingBuffer.is_truncated_since`).
* ``pid`` — the remote PID if captured (useful for out-of-band
  diagnostics; ``ssh_signal`` uses it internally).

Error handling
--------------

Same structured-error philosophy as the other tools: a missing job_id,
a bad ``stream`` value, or a manager-shutdown race is folded into the
normal response shape with ``ok=False`` and ``error={kind, message}``,
rather than raising through FastMCP. The LLM sees a valid dict either
way and can branch cleanly.

Polling-loop guidance (surfaced in the tool description so the LLM uses
it correctly)
--------------------------------------------------------------------

* Start with ``since_line_no=0`` to get everything buffered so far.
* Set ``wait_ms`` to 5000–10000 for "near-live" streaming. Smaller
  values just waste round-trips; larger values are fine but delay the
  "job finished" notification by that many ms.
* Check ``still_running`` and break the loop when it flips to False.
* If ``buffer_truncated`` is True, the LLM missed output — it can
  either live with the gap (common case for logs) or surface a warning
  to the user. Increasing ``ring_buffer_lines`` in config helps.
"""

from __future__ import annotations

import logging
import time
from dataclasses import asdict

from fastmcp import FastMCP

from ..config import AppConfig
from ..job import Job, JobStatus
from ..job_manager import JobManager, JobNotFound
from ..utils.ringbuf import JobLine, merge_sorted_by_line_no

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
#
# Defaults and caps for the tool parameters. Exposed as module-level
# constants so tests can tweak them without mucking with the function
# signature, and so the values are discoverable in one place.

# Default when the caller doesn't pass max_lines. 500 matches SPEC.md
# §"3. ssh_tail" and is a reasonable ceiling for a single MCP round-trip
# payload (≈ 500 * 100 chars = 50 KB of JSON).
_DEFAULT_MAX_LINES = 500

# Hard cap regardless of what the caller asks for — an LLM that sets
# max_lines=1_000_000 shouldn't be able to burn our ring buffer into a
# 100 MB JSON response. If the buffer genuinely has that many lines the
# caller can just do two polls.
_HARD_MAX_LINES_CAP = 10_000

# Hard cap on wait_ms. Agents occasionally pass pathological values
# (wait_ms=600_000 = 10 minutes), which holds an MCP channel thread for
# way too long. 60 s is plenty for "near-live" streaming and matches the
# typical MCP-client tool timeout.
_HARD_MAX_WAIT_MS = 60_000

# Minimum observable wait when a caller passes something ridiculous like
# wait_ms=1. The condvar wakeup latency is already ~a few ms; we just
# short-circuit sub-10 ms values to "don't wait" so we don't pay the
# syscall overhead for no reason.
_MIN_MEANINGFUL_WAIT_MS = 10

# Valid ``stream`` selector values.
_VALID_STREAMS = frozenset({"stdout", "stderr", "both"})


# ---------------------------------------------------------------------------
# Response shapes
# ---------------------------------------------------------------------------


def _ok_response(
    *,
    lines: list[JobLine],
    last_line_no: int,
    still_running: bool,
    exit_status: int | None,
    status: str,
    buffer_truncated: bool,
    stream: str,
    job_id: str,
    host: str,
    pid: int | None,
) -> dict:
    """Shape returned on any successful tail (including zero new lines).

    ``lines`` is serialized to a list of plain dicts so FastMCP's
    JSON-schema derivation sees a concrete ``{line_no, stream, ts, text}``
    structure rather than a custom dataclass — some MCP clients render
    schema-typed list items inline to the LLM, which is nicer than
    opaque text blobs.
    """
    return {
        "ok": True,
        "job_id": job_id,
        "host": host,
        "pid": pid,
        "lines": [asdict(ln) for ln in lines],
        "last_line_no": last_line_no,
        "still_running": still_running,
        "exit_status": exit_status,
        "status": status,
        "buffer_truncated": buffer_truncated,
        "stream": stream,
        "error": None,
    }


def _err_response(
    *,
    kind: str,
    message: str,
    job_id: str = "",
) -> dict:
    """Shape returned on any failure path.

    Mirrors the success shape's top-level keys so the LLM's pattern
    matching is identical in both cases — only the ``ok`` flag and the
    ``error`` object differ. Every list/optional key is populated with
    a safe default (empty list, 0, None) so downstream code that
    indexes into ``response["lines"]`` without checking ``ok`` still
    gets a well-typed empty list instead of a KeyError.
    """
    return {
        "ok": False,
        "job_id": job_id,
        "host": "",
        "pid": None,
        "lines": [],
        "last_line_no": 0,
        "still_running": False,
        "exit_status": None,
        "status": "",
        "buffer_truncated": False,
        "stream": "",
        "error": {"kind": kind, "message": message},
    }


# ---------------------------------------------------------------------------
# Core gather logic (split out for testability)
# ---------------------------------------------------------------------------


def _gather_lines(
    job: Job,
    *,
    since_line_no: int,
    stream: str,
    max_lines: int,
) -> tuple[list[JobLine], bool]:
    """Pull a snapshot of new lines from the requested stream(s).

    Returns ``(lines, buffer_truncated)``. ``buffer_truncated`` is True
    if *any* of the selected streams has evicted lines newer than the
    cursor (we OR across streams because from the caller's perspective
    a gap in either one is a lost-data event).

    The two-stream "both" case is handled by pulling each buffer
    independently and then merging by ``line_no``. Since stdout and
    stderr share a :class:`LineCounter`, the merged sequence has no
    duplicates and is strictly monotonic — so the caller's next
    ``since_line_no = result[-1].line_no`` advance is correct
    regardless of which stream each returned line came from.

    We intentionally pass ``max_lines`` to each per-stream call AND to
    the merge so both stages respect the cap:

    * Per-stream cap guards against pulling 10k stdout lines when
      max_lines=50.
    * Post-merge cap guards against two streams each returning their
      max (up to 2x max_lines together) before we trim to the exact
      request size.

    The two passes together are still O(max_lines) because each
    per-stream result is bounded by that value.
    """
    if stream == "stdout":
        lines = job.stdout.lines_since(since_line_no, max_lines=max_lines)
        truncated = job.stdout.is_truncated_since(since_line_no)
        return lines, truncated

    if stream == "stderr":
        lines = job.stderr.lines_since(since_line_no, max_lines=max_lines)
        truncated = job.stderr.is_truncated_since(since_line_no)
        return lines, truncated

    # "both": snapshot each independently, merge, trim.
    stdout_lines = job.stdout.lines_since(since_line_no, max_lines=max_lines)
    stderr_lines = job.stderr.lines_since(since_line_no, max_lines=max_lines)
    merged = merge_sorted_by_line_no(
        (stdout_lines, stderr_lines),
        max_lines=max_lines,
    )
    truncated = job.stdout.is_truncated_since(since_line_no) or job.stderr.is_truncated_since(
        since_line_no
    )
    return merged, truncated


def _wait_for_new_lines(
    job: Job,
    *,
    since_line_no: int,
    stream: str,
    timeout_sec: float,
) -> None:
    """Block up to ``timeout_sec`` for new lines to arrive after the cursor.

    For a single stream we delegate to :meth:`RingBufferView.wait_for_lines`.
    For ``stream="both"`` we need to wake on *either* buffer getting a
    new line — so we split the timeout between alternating short waits,
    checking readiness between slices. This is coarser than a proper
    multi-source condvar (which would need a shared event, a bigger
    refactor of :class:`RingBuffer`) but it's simple, correct, and the
    latency cost is bounded by the slice size (~100 ms).

    Why not just wait on one buffer and hope the other doesn't fire
    first: a job that only writes to stderr would never wake a poller
    waiting on stdout. And most real jobs interleave, so in practice
    the first slice almost always catches the wake-up.
    """
    if timeout_sec <= 0:
        return

    # done_event wake-up: if the job finishes mid-wait we want to
    # return immediately so the poller can see the final state. The
    # per-buffer wait_for_lines already respects notify_done(), which
    # the exit watcher thread calls on finalize, so this is automatic
    # for the single-stream paths.

    if stream == "stdout":
        job.stdout.wait_for_lines(since_line_no, timeout_sec=timeout_sec)
        return
    if stream == "stderr":
        job.stderr.wait_for_lines(since_line_no, timeout_sec=timeout_sec)
        return

    # stream == "both": slice the timeout. 100 ms slices bound the
    # worst-case extra wake-up delay at 100 ms, which is well inside
    # the "sub-10 s" SPEC target for tail-roundtrip latency.
    slice_sec = 0.1
    deadline = time.monotonic() + timeout_sec

    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return

        # Early exit if the job has already finished — no more lines
        # are coming regardless of which buffer we poll.
        if not job.is_running():
            return

        # Early exit if either stream already has something new.
        if (job.stdout.newest_line_no() or 0) > since_line_no:
            return
        if (job.stderr.newest_line_no() or 0) > since_line_no:
            return

        # Wait on stdout for one slice. If nothing shows up, the loop
        # re-checks stderr in the next iteration. Over a full wait this
        # gives each buffer ~50% of the wall-clock wakeup budget, and
        # the ``newest_line_no`` pre-check ensures we exit within one
        # slice of either buffer's notify_all().
        this_slice = min(slice_sec, remaining)
        # Alternate streams across iterations so we don't disproportionately
        # starve one side when the other is continuously busy.
        target = job.stdout if (int(remaining * 10) & 1) == 0 else job.stderr
        target.wait_for_lines(since_line_no, timeout_sec=this_slice)

        # Loop re-evaluates the readiness predicate and deadline.


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register(
    mcp: FastMCP,
    cfg: AppConfig,  # noqa: ARG001 - kept for API symmetry with other tools
    manager: JobManager,
) -> None:
    """Register the ``ssh_tail`` tool on ``mcp``.

    Closes over the :class:`JobManager` for job lookup. Does NOT need
    the ConnectionPool — tailing reads from in-memory ring buffers
    populated by the Job's own reader threads, with zero additional
    SSH traffic. That's the whole point of the streaming design.
    """

    @mcp.tool(
        name="ssh_tail",
        description=(
            "Stream incremental output from a job started by ssh_spawn. "
            "Given a monotonic cursor 'since_line_no', return every buffered "
            "line with line_no > cursor (up to max_lines). If wait_ms > 0 and "
            "nothing new is available, block up to wait_ms milliseconds for "
            "new output. Returns still_running=False and exit_status when the "
            "job has finished.\n\n"
            "Canonical polling loop (use this):\n"
            "  cursor = 0\n"
            "  while True:\n"
            "      r = ssh_tail(job_id, since_line_no=cursor, wait_ms=5000,\n"
            "                   max_lines=500, stream='both')\n"
            "      for ln in r['lines']: show_to_user(ln)\n"
            "      cursor = r['last_line_no']\n"
            "      if not r['still_running']: break\n\n"
            "If r['buffer_truncated'] is True, older output was evicted "
            "from the ring buffer before you read it — either live with "
            "the gap or increase limits.ring_buffer_lines on the server. "
            "This tool does NOT open a new SSH connection per call; all "
            "data comes from in-memory buffers maintained by the spawn's "
            "reader threads."
        ),
    )
    def ssh_tail(
        job_id: str,
        since_line_no: int = 0,
        wait_ms: int = 0,
        max_lines: int = _DEFAULT_MAX_LINES,
        stream: str = "both",
    ) -> dict:
        """Return new lines from ``job_id`` since ``since_line_no``.

        Args:
            job_id: The id returned by ``ssh_spawn``.
            since_line_no: Your cursor. 0 on the first call; on each
                subsequent call, pass the ``last_line_no`` from the
                previous response. Negative values are clamped to 0.
            wait_ms: If > 0 and no new lines are immediately available,
                block up to this many milliseconds waiting. Capped
                internally at 60000 ms so a misbehaving caller can't
                hold an MCP channel for 10 minutes. Values below 10 ms
                are treated as 0 (no wait) because condvar wakeup
                latency eats them anyway.
            max_lines: Maximum lines to return in this response. Capped
                internally at 10000. The cap is there to keep a single
                response payload small — if the buffer has more lines
                pending, just poll again with an updated cursor.
            stream: ``"stdout"``, ``"stderr"``, or ``"both"`` (default).
                "both" merges the two streams by line_no, which gives
                the true interleaved order a human would see.

        Returns:
            A dict with keys:

            * ``ok`` (bool) — False only on lookup/validation failure.
            * ``job_id``, ``host``, ``pid`` — echo of state.
            * ``lines`` — list of ``{line_no, stream, ts, text}`` dicts
              in ascending ``line_no`` order.
            * ``last_line_no`` — feed back as ``since_line_no`` next poll.
              When ``lines`` is empty, equals the input ``since_line_no``.
            * ``still_running`` (bool), ``exit_status`` (int or null),
              ``status`` (string, one of pending/running/finished/crashed/
              killed) — job lifecycle.
            * ``buffer_truncated`` (bool) — True if your cursor has
              fallen off the back of the ring buffer.
            * ``stream`` — echo of the requested stream selector.
            * ``error`` — null on success, ``{kind, message}`` on
              failure. ``kind`` is one of ``not_found`` / ``bad_param``
              / ``unexpected``.
        """
        # --- Validate parameters -------------------------------------------
        # We normalize silently instead of raising on clamp-able values
        # (negative since_line_no, oversized wait_ms / max_lines) because
        # LLMs occasionally pass slightly-wrong numbers and round-tripping
        # an error in that case just loses the LLM's turn. But we DO fail
        # hard on fundamentally invalid ``stream`` — a typo there is a
        # bug that silently returning empty output would hide.

        if stream not in _VALID_STREAMS:
            return _err_response(
                kind="bad_param",
                message=(f"stream must be one of {sorted(_VALID_STREAMS)}; got {stream!r}"),
                job_id=job_id,
            )

        if since_line_no < 0:
            since_line_no = 0

        if max_lines < 0:
            max_lines = _DEFAULT_MAX_LINES
        if max_lines == 0:
            # 0 is a footgun: nothing returned, loop spins forever.
            # Normalize to the default so a well-intentioned
            # max_lines=0 (meaning "unlimited" in some APIs) still
            # returns something useful.
            max_lines = _DEFAULT_MAX_LINES
        if max_lines > _HARD_MAX_LINES_CAP:
            max_lines = _HARD_MAX_LINES_CAP

        if wait_ms < 0:
            wait_ms = 0
        if wait_ms > _HARD_MAX_WAIT_MS:
            log.debug("ssh_tail: wait_ms=%d capped to %d", wait_ms, _HARD_MAX_WAIT_MS)
            wait_ms = _HARD_MAX_WAIT_MS
        if 0 < wait_ms < _MIN_MEANINGFUL_WAIT_MS:
            wait_ms = 0

        # --- Look up the job -----------------------------------------------
        try:
            job = manager.get(job_id)
        except JobNotFound as e:
            # Either never existed, was reaped (finished + grace window
            # elapsed), or was removed. All three look the same to the
            # caller. The error kind ``not_found`` lets the LLM branch
            # on "retry with fresh spawn" vs other failures.
            return _err_response(kind="not_found", message=str(e), job_id=job_id)
        except Exception as e:  # pragma: no cover - defensive
            log.exception("ssh_tail: unexpected error looking up %r", job_id)
            return _err_response(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
                job_id=job_id,
            )

        # --- First gather: is there already something after the cursor? ----
        # We always do one non-blocking gather BEFORE any wait, so the
        # happy path (data already buffered) doesn't pay the condvar
        # overhead. This is important: a well-tuned polling loop with
        # frequent output spends most of its time in the fast path.
        lines, truncated = _gather_lines(
            job,
            since_line_no=since_line_no,
            stream=stream,
            max_lines=max_lines,
        )

        # --- Blocking wait if nothing to report yet -----------------------
        # Skip the wait entirely if:
        #   * caller didn't ask for one (wait_ms == 0)
        #   * we already have lines to return (fast path)
        #   * the job has already finished (no more lines are coming,
        #     and returning immediately lets the poller see
        #     still_running=False and break the loop)
        if not lines and wait_ms > 0 and job.is_running():
            timeout_sec = wait_ms / 1000.0
            try:
                _wait_for_new_lines(
                    job,
                    since_line_no=since_line_no,
                    stream=stream,
                    timeout_sec=timeout_sec,
                )
            except Exception as e:  # pragma: no cover - defensive
                log.exception("ssh_tail: wait failed on %r", job_id)
                # Don't fail the call; just skip the wait and return
                # whatever's in the buffer (possibly empty).
                _ = e

            # Gather again after waking. The snapshot may have grown,
            # or the job may have finished and flushed a partial final
            # line — either way the second gather is authoritative.
            lines, truncated = _gather_lines(
                job,
                since_line_no=since_line_no,
                stream=stream,
                max_lines=max_lines,
            )

        # --- Compute the response state ------------------------------------
        # Snapshot the job state AFTER the second gather so
        # ``still_running`` reflects reality at response time, not at
        # call time. A job that exited during our wait should show
        # still_running=False plus any final lines it flushed.
        snap = job.snapshot()

        if lines:
            last_line_no = lines[-1].line_no
        else:
            # Empty response: advance the cursor to the newest observed
            # line of any stream (so a poller that got zero lines
            # during a wait doesn't keep rescanning old territory).
            # If the job has literally never emitted anything yet,
            # leave the cursor where it was.
            newest = 0
            if stream in ("stdout", "both"):
                newest = max(newest, job.stdout.newest_line_no() or 0)
            if stream in ("stderr", "both"):
                newest = max(newest, job.stderr.newest_line_no() or 0)
            last_line_no = max(since_line_no, newest) if newest == 0 else since_line_no
            # ^ If nothing's been emitted, preserve the caller's cursor
            # verbatim. Only advancing on actual lines is the least
            # surprising contract for the LLM.
            last_line_no = since_line_no

        still_running = (
            snap.status
            not in (
                JobStatus.FINISHED,
                JobStatus.CRASHED,
                JobStatus.KILLED,
            )
            and snap.exit_status is None
        )

        log.debug(
            "ssh_tail: job=%r since=%d stream=%s wait_ms=%d -> %d line(s) "
            "last_line_no=%d still_running=%s truncated=%s",
            job_id,
            since_line_no,
            stream,
            wait_ms,
            len(lines),
            last_line_no,
            still_running,
            truncated,
        )

        return _ok_response(
            lines=lines,
            last_line_no=last_line_no,
            still_running=still_running,
            exit_status=snap.exit_status,
            status=snap.status,
            buffer_truncated=truncated,
            stream=stream,
            job_id=job_id,
            host=snap.host,
            pid=snap.pid,
        )
