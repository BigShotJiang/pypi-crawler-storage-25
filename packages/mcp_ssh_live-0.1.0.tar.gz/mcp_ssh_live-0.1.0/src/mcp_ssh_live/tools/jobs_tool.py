"""The ``ssh_list_jobs`` and ``ssh_remove_job`` tools.

See ``SPEC.md`` §"MCP Tools (public API)" → "6. ``ssh_list_jobs``" and
"7. ``ssh_remove_job``" for the full contracts. These two tools are
grouped in one module because they operate on the same subset of the
:class:`JobManager` API (``snapshot_all`` + ``remove``) and have
near-identical error shaping; splitting them into separate files would
just duplicate the response helpers.

``ssh_list_jobs``
-----------------

Return metadata for every job the server knows about — running,
finished-but-not-yet-reaped, or crashed. Callers use it to:

* Discover jobs they didn't spawn (useful when an LLM session restarts
  and needs to rediscover what was left running).
* Decide which finished job to ``ssh_remove_job`` to free a
  ``max_jobs_per_host`` slot.
* Surface a "what's running on my server?" view to the end user.

The response is a list of :class:`JobSnapshot` -shaped dicts. We
deliberately DON'T include any output lines — that's ``ssh_tail``'s job
— because a list endpoint that could return N*ring_maxlen lines is an
easy DoS vector and the schema surface gets unwieldy.

``ssh_remove_job``
------------------

Drop a job from the registry. Finished jobs can always be removed.
Running jobs require ``force=True``, which closes the SSH channel (SSH
EOF is sent to the remote stdin, which most programs interpret as
"close me"). ``force=True`` does NOT guarantee the remote process
dies — for a hard kill the LLM should call ``ssh_signal(KILL)`` first
and then remove.

Why we don't auto-send SIGKILL on ``force=True``: the signal path needs
a pid (captured from the PID wrapper), and that capture can fail on
exotic servers. Making ``force=True`` imply "signal + remove" would
swallow the distinction between "I closed the channel" and "I killed
the process", which the LLM genuinely needs to know to decide whether
to retry a flaky job. Keeping the two operations explicit is clearer.
"""

from __future__ import annotations

import logging
from dataclasses import asdict

from fastmcp import FastMCP

from ..config import AppConfig
from ..job_manager import JobManager, JobNotFound, JobStillRunning

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Response shapes — one per tool, kept close to the top so the JSON
# schema surface FastMCP derives is obvious at a glance.
# ---------------------------------------------------------------------------


def _list_ok_response(*, jobs: list[dict], total: int, host_filter: str | None) -> dict:
    """Shape returned by ``ssh_list_jobs`` on success.

    ``total`` is the count of jobs actually returned (after any
    ``host`` filter). We deliberately don't paginate — the
    ``max_jobs_per_host`` cap bounds the registry size, so even in the
    worst case the payload is a few hundred small metadata dicts.

    ``host_filter`` echoes the caller's filter (or null). Useful for
    LLMs that issue several concurrent ``ssh_list_jobs`` calls and
    need to disambiguate the responses without tracking their own
    request ids.
    """
    return {
        "ok": True,
        "jobs": jobs,
        "total": total,
        "host_filter": host_filter,
        "error": None,
    }


def _list_err_response(*, kind: str, message: str, host_filter: str | None = None) -> dict:
    """Error shape for ``ssh_list_jobs``. Mirrors the success keys so an
    LLM pattern-matching on ``jobs`` gets an empty list instead of a
    KeyError when it forgets to check ``ok`` first.
    """
    return {
        "ok": False,
        "jobs": [],
        "total": 0,
        "host_filter": host_filter,
        "error": {"kind": kind, "message": message},
    }


def _remove_ok_response(
    *,
    job_id: str,
    removed: bool,
    was_running: bool,
    forced: bool,
) -> dict:
    """Shape returned by ``ssh_remove_job`` on success.

    ``removed`` reports whether a job was actually dropped from the
    registry (False means the id wasn't present — not an error, just a
    no-op, matching the ``ssh_remove_job(job_id: str) -> {"removed":
    bool}`` contract in SPEC.md).

    ``was_running`` + ``forced`` give the LLM enough context to decide
    whether to follow up with a ``ssh_signal(KILL)`` — a job that was
    running AND was removed with force=True may still have its remote
    process alive, and the LLM should either accept that or kill it.
    """
    return {
        "ok": True,
        "job_id": job_id,
        "removed": removed,
        "was_running": was_running,
        "forced": forced,
        "error": None,
    }


def _remove_err_response(*, kind: str, message: str, job_id: str = "") -> dict:
    """Error shape for ``ssh_remove_job``.

    ``kind`` values:

    * ``still_running`` — caller asked to remove a running job without
      ``force=True``. The LLM should either signal it first or retry
      with ``force=True``.
    * ``not_found`` — id was never registered, or was already reaped.
      Note: this is also returned when the manager's
      :meth:`JobManager.remove` finds no entry; ``removed=False`` in
      the success path only happens when the manager's internal check
      considered the id absent too — they're the same case, and the
      success path is what we actually reach. ``not_found`` here is
      reserved for truly unexpected KeyError-style failures (shouldn't
      fire in normal operation).
    * ``unexpected`` — catch-all, logged at warning level.
    """
    return {
        "ok": False,
        "job_id": job_id,
        "removed": False,
        "was_running": False,
        "forced": False,
        "error": {"kind": kind, "message": message},
    }


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register(
    mcp: FastMCP,
    cfg: AppConfig,  # noqa: ARG001 - kept for API symmetry with other tool modules
    manager: JobManager,
) -> None:
    """Register ``ssh_list_jobs`` and ``ssh_remove_job`` on ``mcp``.

    Both tools close over the shared :class:`JobManager`. Neither
    touches the :class:`ConnectionPool` directly — listing reads the
    in-memory registry, and removal closes the SSH channel owned by
    the Job (not a pooled connection), so the pool only matters to
    ``ssh_spawn`` / ``ssh_exec`` / signal tools.
    """

    # ------------------------------------------------------------------ list

    @mcp.tool(
        name="ssh_list_jobs",
        description=(
            "List every job registered on this mcp-ssh-live server — "
            "running, finished-but-not-yet-reaped, and crashed. Returns "
            "metadata only (job_id, cmd, host, label, started_at, "
            "finished_at, exit_status, status, pid, pty, stdout_lines, "
            "stderr_lines); use ssh_tail to fetch the actual output of "
            "a specific job.\n\n"
            "Filter by host with the 'host' argument (alias or raw "
            "address). Pass include_finished=false to see only "
            "still-running jobs, which is typical when deciding "
            "whether to spawn a new one without hitting the "
            "max_jobs_per_host cap.\n\n"
            "Finished jobs are kept in the registry for a grace window "
            "(reap_finished_after_sec, default 600 s) so you can still "
            "fetch their final tail output after they exit."
        ),
    )
    def ssh_list_jobs(
        host: str | None = None,
        include_finished: bool = True,
    ) -> dict:
        """Return metadata for matching jobs.

        Args:
            host: If provided, only return jobs whose host equals this
                alias OR whose raw address matches. If omitted or null,
                return jobs across every host. We resolve the filter
                against the config so a user who types the raw IP
                still gets jobs tagged with the configured alias.
            include_finished: When True (default), return jobs in every
                lifecycle state. When False, skip jobs that have
                already exited / crashed / been killed — useful for
                capacity planning.

        Returns:
            A dict with keys ``ok`` (bool), ``jobs`` (list of
            metadata dicts), ``total`` (int; count of jobs in
            ``jobs``), ``host_filter`` (echo, str or null), ``error``
            (null on success, else ``{kind, message}``).

            Each entry in ``jobs`` has the :class:`JobSnapshot` fields:
            ``job_id``, ``host``, ``cmd``, ``label``, ``started_at``,
            ``finished_at`` (null if running), ``exit_status`` (null
            if running), ``status`` (one of pending/running/finished/
            crashed/killed), ``pid`` (null if not captured), ``pty``,
            ``stdout_lines``, ``stderr_lines``. Entries are ordered by
            ``started_at`` ascending so the oldest jobs come first —
            matching the order a human would scan through.
        """
        # --- Resolve the host filter (if any) -----------------------------
        # We resolve against the config so ``host="1.2.3.4"`` and
        # ``host="default"`` filter to the same set of jobs. A typo
        # becomes a structured error instead of a silent empty list,
        # which is easier for the LLM to notice and correct.
        resolved_host: str | None = None
        if host is not None:
            try:
                host_cfg = cfg.get_host(host)
                resolved_host = host_cfg.alias
            except ValueError as e:
                # Unknown alias / no default host configured, etc.
                return _list_err_response(
                    kind="bad_param",
                    message=str(e),
                    host_filter=host,
                )

        # --- Snapshot the registry under the manager's lock ---------------
        # snapshot_all returns immutable JobSnapshot instances; we
        # convert to dicts here (not in JobManager) so the manager
        # stays free of MCP-serialization concerns.
        try:
            snapshots = manager.snapshot_all(
                host=resolved_host,
                include_finished=include_finished,
            )
        except Exception as e:  # pragma: no cover - defensive
            log.exception("ssh_list_jobs: unexpected error")
            return _list_err_response(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
                host_filter=resolved_host,
            )

        # Sort by started_at ascending. The manager stores jobs in
        # insertion order (Python dict), which is *usually* the same,
        # but a reaper sweep can leave gaps — explicit sort removes
        # any ambiguity. Ties broken by job_id for full determinism.
        snapshots.sort(key=lambda s: (s.started_at, s.job_id))

        # Convert each snapshot to a plain dict for JSON. asdict on a
        # frozen dataclass is O(n) in fields, cheap.
        jobs_list = [asdict(s) for s in snapshots]

        log.debug(
            "ssh_list_jobs: host=%r include_finished=%s -> %d job(s)",
            resolved_host,
            include_finished,
            len(jobs_list),
        )

        return _list_ok_response(
            jobs=jobs_list,
            total=len(jobs_list),
            host_filter=resolved_host,
        )

    # ------------------------------------------------------------------ remove

    @mcp.tool(
        name="ssh_remove_job",
        description=(
            "Drop a job from the registry, freeing its slot against "
            "max_jobs_per_host and releasing its ring buffers.\n\n"
            "Finished / crashed / killed jobs can always be removed. "
            "STILL-RUNNING jobs require force=True, which closes the "
            "SSH channel (sends EOF to the remote's stdin) but does "
            "NOT guarantee the remote process dies — for a hard kill "
            "call ssh_signal(KILL) FIRST and then ssh_remove_job.\n\n"
            "Returns removed=True if a job was actually dropped, "
            "removed=False if the id wasn't present (a no-op, not an "
            "error — useful for idempotent cleanup scripts that don't "
            "know whether a job is still around)."
        ),
    )
    def ssh_remove_job(job_id: str, force: bool = False) -> dict:
        """Remove ``job_id`` from the registry.

        Args:
            job_id: The id returned by ``ssh_spawn``.
            force: When True, remove the job even if it's still
                running. Closes the SSH channel as a side effect.
                When False (default), removing a running job returns
                an error with ``kind="still_running"``.

        Returns:
            A dict with keys ``ok`` (bool), ``job_id`` (str),
            ``removed`` (bool; False means the id wasn't present),
            ``was_running`` (bool; snapshot at removal time — useful
            for deciding whether the remote process may still be
            alive), ``forced`` (bool; echo of the force argument),
            ``error`` (null on success, else ``{kind, message}``).

            Error ``kind`` values: ``still_running`` (caller asked to
            remove a live job without force=True), ``bad_param``
            (empty job_id), ``unexpected``.
        """
        # --- Parameter validation ----------------------------------------
        # An empty job_id would pass through JobManager.remove() as a
        # plain False (not-found), which is technically correct but
        # almost certainly a bug in the caller. Reject it loudly so
        # the LLM notices it forgot to substitute a variable.
        if not job_id or not isinstance(job_id, str):
            return _remove_err_response(
                kind="bad_param",
                message=f"job_id must be a non-empty string; got {job_id!r}",
                job_id=str(job_id) if job_id else "",
            )

        # --- Peek at the job's state BEFORE removal -----------------------
        # We want to report ``was_running`` in the response, but
        # JobManager.remove() doesn't surface that — and fetching the
        # Job separately is racy (it could finish between the peek and
        # the remove). We accept the race: the ``was_running`` flag is
        # a snapshot at peek time, and the LLM only uses it as a hint
        # for whether to follow up with ssh_signal(KILL). A job that
        # races from running-to-finished between peek and remove is
        # already not running by removal time — the "may still be
        # alive" guidance is harmlessly over-cautious in that case.
        was_running = False
        try:
            job = manager.get(job_id)
            was_running = job.is_running()
        except JobNotFound:
            # No such id. Fall through to remove() so we return a
            # uniform no-op response (matches the idempotent-cleanup
            # use case documented in the tool description).
            pass
        except Exception as e:  # pragma: no cover - defensive
            log.exception("ssh_remove_job: peek failed for %r", job_id)
            return _remove_err_response(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
                job_id=job_id,
            )

        # --- Attempt removal ----------------------------------------------
        try:
            removed = manager.remove(job_id, force=force)
        except JobStillRunning as e:
            # Running job, caller didn't pass force=True. Surface as a
            # distinct error kind so the LLM can retry with
            # force=True (or signal first) without having to parse the
            # human message.
            return _remove_err_response(
                kind="still_running",
                message=str(e),
                job_id=job_id,
            )
        except Exception as e:  # pragma: no cover - defensive
            log.exception("ssh_remove_job: remove failed for %r", job_id)
            return _remove_err_response(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
                job_id=job_id,
            )

        log.info(
            "ssh_remove_job: job=%r removed=%s was_running=%s force=%s",
            job_id,
            removed,
            was_running,
            force,
        )

        return _remove_ok_response(
            job_id=job_id,
            removed=removed,
            was_running=was_running,
            forced=force,
        )
