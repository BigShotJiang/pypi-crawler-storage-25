"""MCP tool implementations for mcp-ssh-live.

Each tool module registers one or more tools on the FastMCP server.
See SPEC.md §"MCP Tools (public API)" for the full public API.
"""
