"""The ``ssh_connect`` and ``ssh_disconnect`` tools.

These tools allow the LLM to connect to SSH hosts at runtime, without
any pre-configured ``--host`` CLI flags or TOML config. This is the
"no credentials at startup" pattern — the server starts empty, and the
agent adds hosts on demand by calling ``ssh_connect``.

Typical usage in chat:

    Agent: ssh_connect(host="1.2.3.4", user="root", password="<your-password>")
    → {"ok": true, "alias": "h-1", "host": "1.2.3.4", ...}

    Agent: ssh_exec(command="hostname", host="h-1")
    → {"stdout": "myserver\n", ...}

    Agent: ssh_disconnect(alias="h-1")
    → {"ok": true, "alias": "h-1", "removed": true}

Why this matters
----------------

Without these tools the server requires ``--host`` / ``--user`` /
``--password-env`` CLI flags at startup, which means credentials must
be baked into the MCP client config (e.g. Zed's ``settings.json``).
That is fine for a dedicated single-host setup but terrible for a
general-purpose tool: the user would have to edit JSON files and restart
Zed every time they want to connect to a different server.

With ``ssh_connect``, the MCP client config is credential-free:

    "context_servers": {
      "ssh-live": {
        "source": "custom",
        "command": "python",
        "args": ["-m", "mcp_ssh_live"]
      }
    }

The user just tells the agent the credentials in the chat and the agent
calls ``ssh_connect`` — same UX as existing SSH MCP servers like
``mcp-ssh``.

Alias auto-generation
---------------------

If the caller doesn't supply an ``alias``, we generate a short one from
the host: ``h-<first 8 chars of hex(sha256(host:port:user))>``. This is
stable across calls with the same credentials (reconnecting to the same
host gives the same alias), unique enough to avoid collisions in any
realistic multi-host setup, and short enough to type or reference in
subsequent tool calls.

Thread safety
-------------

``ssh_connect`` mutates ``cfg.hosts`` and ``pool._host_cfgs``. Both
operations are protected by the pool's ``_lock`` (acquired once to do
both atomically), so concurrent ``ssh_connect`` calls on different hosts
don't race.
"""

from __future__ import annotations

import hashlib
import logging

from fastmcp import FastMCP

from ..config import AppConfig, HostConfig
from ..connection import ConnectionPool, SSHConnectError

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Alias generation
# ---------------------------------------------------------------------------


def _auto_alias(host: str, port: int, user: str) -> str:
    """Generate a stable short alias from (host, port, user).

    Stable: same inputs → same alias across server restarts.
    Unique: SHA-256 collision probability is negligible for any realistic
    number of SSH targets.
    Short: 8 hex chars (h-xxxxxxxx) is easy to type and paste.
    """
    key = f"{host}:{port}:{user}".encode()
    digest = hashlib.sha256(key).hexdigest()[:8]
    return f"h-{digest}"


# ---------------------------------------------------------------------------
# Response helpers
# ---------------------------------------------------------------------------


def _ok_connect(
    *,
    alias: str,
    host: str,
    port: int,
    user: str,
    auth: str,
    is_new: bool,
) -> dict:
    return {
        "ok": True,
        "alias": alias,
        "host": host,
        "port": port,
        "user": user,
        "auth": auth,
        "is_new": is_new,
        "error": None,
    }


def _err_connect(*, kind: str, message: str, alias: str = "") -> dict:
    return {
        "ok": False,
        "alias": alias,
        "host": "",
        "port": 0,
        "user": "",
        "auth": "",
        "is_new": False,
        "error": {"kind": kind, "message": message},
    }


def _ok_disconnect(*, alias: str, removed: bool) -> dict:
    return {
        "ok": True,
        "alias": alias,
        "removed": removed,
        "error": None,
    }


def _err_disconnect(*, kind: str, message: str, alias: str = "") -> dict:
    return {
        "ok": False,
        "alias": alias,
        "removed": False,
        "error": {"kind": kind, "message": message},
    }


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register(
    mcp: FastMCP,
    pool: ConnectionPool,
    cfg: AppConfig,
) -> None:
    """Register ``ssh_connect`` and ``ssh_disconnect`` on ``mcp``."""

    # ------------------------------------------------------------------ connect

    @mcp.tool(
        name="ssh_connect",
        description=(
            "Add a new SSH host at runtime and open the connection. "
            "Call this first before using ssh_exec / ssh_spawn / "
            "ssh_upload / ssh_download on a new server.\n\n"
            "Returns an alias (e.g. 'h-3f8a1b2c') that you pass as the "
            "'host' argument to all other tools. If you supply your own "
            "alias it will be used instead.\n\n"
            "Auth: provide exactly one of password or key_path. "
            "If neither is given, paramiko tries the SSH agent and "
            "default key files (~/.ssh/id_*).\n\n"
            "Calling ssh_connect again with the same alias updates the "
            "credentials and reconnects."
        ),
    )
    def ssh_connect(
        host: str,
        user: str = "root",
        password: str | None = None,
        key_path: str | None = None,
        port: int = 22,
        alias: str | None = None,
        insecure_auto_add: bool = True,
    ) -> dict:
        """Connect to an SSH host and register it for subsequent tool calls.

        Args:
            host: IP address or hostname of the remote server.
            user: SSH username. Default ``root``.
            password: SSH password (plain text). Mutually exclusive with
                ``key_path``. Passing it here is safe — the value is
                never logged (only the byte count appears in DEBUG logs),
                and it lives only in the server process's memory for the
                duration of the connection.
            key_path: Path to a private key file on the LOCAL machine
                running the MCP server. Mutually exclusive with
                ``password``.
            port: SSH port. Default 22.
            alias: Optional short name for this host. When omitted, a
                stable alias is auto-generated from (host, port, user)
                so the same credentials always produce the same alias.
                Callers can pass a memorable name like ``"prod"`` or
                ``"mybox"`` to make subsequent tool calls more readable.
            insecure_auto_add: Accept unknown host keys automatically
                (paramiko AutoAddPolicy). Default True because this tool
                is typically called in interactive sessions where the
                user is actively choosing a target — production pinned
                deployments should use a TOML config with a known_hosts
                path instead. Set to False to require the host key to
                already be in the system known_hosts.

        Returns:
            ``{ok, alias, host, port, user, auth, is_new, error}``.
            ``is_new`` is False when the alias already existed and was
            just reconnected. ``auth`` is one of ``"password"`` /
            ``"key"`` / ``"agent"``.
        """
        # --- Validate --------------------------------------------------------
        if not host or not isinstance(host, str):
            return _err_connect(
                kind="bad_param",
                message=f"host must be a non-empty string; got {host!r}",
            )
        if password and key_path:
            return _err_connect(
                kind="bad_param",
                message="provide at most one of password or key_path, not both",
            )

        # --- Determine alias -------------------------------------------------
        effective_alias = (
            alias.strip() if alias and alias.strip() else _auto_alias(host, port, user)
        )

        if not effective_alias:
            return _err_connect(
                kind="bad_param",
                message="alias must be a non-empty string when provided",
            )

        # --- Build HostConfig ------------------------------------------------
        host_cfg = HostConfig(
            alias=effective_alias,
            host=host,
            port=port,
            user=user,
            # Store password directly (not via env var) — the caller
            # typed it into the chat; it already exists in the agent's
            # context. We don't need a round-trip through os.environ.
            password=password,
            key=key_path,
        )

        # Validate the host config (checks port range, non-empty host/user,
        # key file existence if supplied). Errors are config mistakes by
        # the caller — surface as bad_param so the LLM can self-correct.
        try:
            host_cfg.validate()
        except Exception as e:
            return _err_connect(
                kind="bad_param",
                message=str(e),
                alias=effective_alias,
            )

        # --- Register in cfg + pool atomically ------------------------------
        # We need to update both cfg.hosts (so get_host() / ssh_list_hosts
        # see the new entry) and pool._host_cfgs (so pool.get() can create
        # a connection for it). Do both under the pool lock so a concurrent
        # ssh_exec on another thread doesn't see an inconsistent state.
        is_new = effective_alias not in cfg.hosts

        with pool._lock:  # noqa: SLF001
            cfg.hosts[effective_alias] = host_cfg
            pool._host_cfgs[effective_alias] = host_cfg  # noqa: SLF001

            # If a stale SSHConnection exists for this alias (e.g. from a
            # previous ssh_connect call that we're now overriding), close
            # and remove it so the next call gets a fresh one with the new
            # credentials.
            old_conn = pool._conns.pop(effective_alias, None)  # noqa: SLF001

        if old_conn is not None:
            try:
                old_conn.close()
            except Exception:
                pass

        # Update default_host if this is the only host so far.
        if cfg.default_host is None or not cfg.hosts:
            cfg.default_host = effective_alias

        # Override the pool's insecure_auto_add for this specific connection
        # by creating the SSHConnection directly with the right policy, then
        # pre-registering it in the pool so pool.get() returns it.
        from ..connection import SSHConnection  # avoid circular at module level

        conn = SSHConnection(
            host_cfg,
            insecure_auto_add=insecure_auto_add,
            known_hosts_path=cfg.known_hosts_path,
            reconnect_retries=cfg.limits.reconnect_retries,
            reconnect_delay_sec=cfg.limits.reconnect_delay_sec,
        )

        # --- Eagerly connect (verify credentials now, not at first use) -----
        # Connecting eagerly gives immediate feedback: a wrong password
        # or unreachable host fails here with a clear error, before the
        # user has issued a real command and is confused by an opaque
        # SSHConnectError from ssh_exec.
        try:
            conn.connect()
        except SSHConnectError as e:
            # Roll back the registration so the alias doesn't linger as
            # a broken entry in ssh_list_hosts.
            with pool._lock:  # noqa: SLF001
                cfg.hosts.pop(effective_alias, None)
                pool._host_cfgs.pop(effective_alias, None)  # noqa: SLF001
            if cfg.default_host == effective_alias:
                cfg.default_host = next(iter(cfg.hosts), None)
            log.warning("ssh_connect failed for %r: %s", effective_alias, e)
            return _err_connect(
                kind="connect",
                message=str(e),
                alias=effective_alias,
            )
        except Exception as e:  # pragma: no cover - defensive
            with pool._lock:  # noqa: SLF001
                cfg.hosts.pop(effective_alias, None)
                pool._host_cfgs.pop(effective_alias, None)  # noqa: SLF001
            return _err_connect(
                kind="unexpected",
                message=f"{type(e).__name__}: {e}",
                alias=effective_alias,
            )

        # Register the live connection in the pool.
        with pool._lock:  # noqa: SLF001
            pool._conns[effective_alias] = conn  # noqa: SLF001

        auth = "key" if key_path else ("password" if password else "agent")

        log.info(
            "ssh_connect: alias=%r host=%s:%d user=%s auth=%s is_new=%s",
            effective_alias,
            host,
            port,
            user,
            auth,
            is_new,
        )

        return _ok_connect(
            alias=effective_alias,
            host=host,
            port=port,
            user=user,
            auth=auth,
            is_new=is_new,
        )

    # ------------------------------------------------------------------ disconnect

    @mcp.tool(
        name="ssh_disconnect",
        description=(
            "Close the SSH connection to a host and remove it from the "
            "registry. Any running jobs on that host are terminated "
            "(their channels are closed). After this call the alias is "
            "no longer valid for other tools.\n\n"
            "Returns removed=false (not an error) if the alias wasn't "
            "registered — useful for idempotent cleanup."
        ),
    )
    def ssh_disconnect(alias: str) -> dict:
        """Disconnect and deregister a host.

        Args:
            alias: The alias returned by ``ssh_connect`` or listed in
                ``ssh_list_hosts``.

        Returns:
            ``{ok, alias, removed, error}``. ``removed`` is False when
            the alias was not registered (idempotent no-op).
        """
        if not alias or not isinstance(alias, str):
            return _err_disconnect(
                kind="bad_param",
                message=f"alias must be a non-empty string; got {alias!r}",
            )

        # Remove from cfg and pool atomically.
        with pool._lock:  # noqa: SLF001
            existed = alias in cfg.hosts
            cfg.hosts.pop(alias, None)
            pool._host_cfgs.pop(alias, None)  # noqa: SLF001
            conn = pool._conns.pop(alias, None)  # noqa: SLF001

        # Close the transport outside the lock (may briefly block on EOF).
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

        # If this was the default host, pick a new default from whatever
        # remains, or clear it.
        if cfg.default_host == alias:
            cfg.default_host = next(iter(cfg.hosts), None)

        log.info("ssh_disconnect: alias=%r removed=%s", alias, existed)

        return _ok_disconnect(alias=alias, removed=existed)
