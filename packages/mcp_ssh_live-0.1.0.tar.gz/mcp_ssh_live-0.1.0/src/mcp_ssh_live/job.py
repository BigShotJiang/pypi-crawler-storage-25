"""Job model + reader threads for mcp-ssh-live (Phase 2).

A :class:`Job` is the server-side representation of **one long-running
remote command** spawned via ``ssh_spawn``. It owns:

* a :class:`paramiko.Channel` (one SSH exec channel on the shared
  transport — opened by :meth:`SSHConnection.open_session`),
* two :class:`RingBuffer` s (stdout + stderr, sharing one
  :class:`LineCounter` so line numbers are monotonic across streams),
* two daemon reader threads that ``channel.recv()`` / ``recv_stderr()``
  in a loop and append decoded lines to the buffers,
* an :class:`threading.Event` (``done_event``) that fires once the
  channel's ``exit_status_ready()`` is observed,
* lightweight metadata (``cmd``, ``host``, ``started_at``, ``label``,
  ``pty``, ``pid``) surfaced by ``ssh_list_jobs``.

Design decisions (see ``SPEC.md`` §"Reader-thread loop" for the why):

* **Two threads, not one + select**: paramiko's ``Channel`` exposes
  blocking ``recv`` / ``recv_stderr``; trying to multiplex them over a
  single thread with ``channel.settimeout`` + readiness probes works but
  costs latency (we miss the notification edge on the other stream).
  Two dedicated threads are simpler and latency-optimal. Threads are
  daemon so a crashed server process tears them down with the
  interpreter instead of hanging on shutdown.

* **PID extraction in the stdout reader**: when :meth:`SSHConnection.exec`
  wraps the user command in ``bash -c 'echo PID=$$ && exec bash -c
  "<cmd>"'`` (see :func:`connection.build_pid_wrapper`), the first
  stdout chunk begins with ``PID=<n>\\n``. The reader pulls that line
  out before appending anything to the ring buffer, so end users never
  see the bookkeeping. The PID is then available to ``ssh_signal``
  (Phase 3) for the ``kill -SIGNAL <pid>`` fallback on OpenSSH servers
  that ignore ``channel.send_signal``.

* **UTF-8 decode with** ``errors='replace'``: binary blobs on stdout
  (accidental ``cat /usr/bin/ls``) degrade to mojibake instead of
  crashing the reader thread. For real binary transfers users should
  call ``ssh_download`` (Phase 4). The decoder carries a small carry
  buffer across ``recv`` chunks so a UTF-8 sequence split across TCP
  packets still decodes correctly.

* **Line splitting respects** ``\\r\\n``: when a job was spawned with
  ``pty=True``, the remote kernel converts ``\\n`` → ``\\r\\n`` on the
  way out. We strip the trailing ``\\r`` so JobLine.text is always
  newline-unit pristine regardless of pty state.

* **Partial final line flushing**: if the remote process exits without
  emitting a trailing newline on its last line, we still want the user
  to see it. On exit the reader flushes the UTF-8 carry-buffer as one
  final JobLine — matching what ``cat`` / ``less`` would show.

* **Synthetic marker lines on failure**: if the reader thread dies from
  a transport error (EOFError, socket.error, paramiko.SSHException), we
  append ``[mcp-ssh-live: reader crashed: ...]`` to stderr and fire
  ``done_event``, so polling ``ssh_tail`` unblocks and the LLM sees a
  clear reason. Phase 5 extends this to connection-drop / reconnect.

Thread safety
-------------

* :class:`Job` fields set at construction are read by many threads but
  never mutated after :meth:`start`, so they need no lock.
* :attr:`exit_status`, :attr:`finished_at`, :attr:`pid` are mutated by
  the reader threads and read by everyone else. Access is guarded by
  :attr:`_state_lock`. Reads return a consistent snapshot via
  :meth:`snapshot`.
* Ring buffers have their own internal locks (see :mod:`utils.ringbuf`).
* :attr:`done_event` is a stdlib primitive, atomic by contract.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

import paramiko

from .utils.ringbuf import LineCounter, RingBuffer, RingBufferView

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Max bytes pulled per channel.recv() call. 64 KiB matches paramiko's
# default window size well and keeps per-iteration syscall count low
# without risking memory bloat on a runaway job.
_RECV_CHUNK = 65_536

# Per-recv socket timeout (seconds). Short enough that the reader thread
# checks ``stop_requested`` / exit_status promptly, long enough that we
# don't burn CPU in a busy loop when the remote is quiet.
_RECV_TIMEOUT_SEC = 0.25

# After the channel closes, give the remote a brief window to report its
# exit status before we give up. Most sshd implementations deliver it
# instantly; pathological ones sometimes take a few ms.
_EXIT_STATUS_GRACE_SEC = 2.0

# Hard cap on how long a single decoded line can grow before we force-flush
# it as its own JobLine. Defends against a remote process that writes
# gigabytes without ever emitting a newline (e.g. ``yes | tr -d '\n'``);
# without a cap the reader thread's carry buffer would grow unbounded.
_MAX_LINE_BYTES = 1_048_576  # 1 MiB


# ---------------------------------------------------------------------------
# JobStatus — string enum surfaced to clients
# ---------------------------------------------------------------------------


class JobStatus:
    """String constants for the lifecycle state of a Job.

    Not a real ``enum.Enum`` because FastMCP serializes string constants
    more cleanly into JSON schemas than Enum members (which typically
    round-trip as their ``.value``). Using bare strings keeps the wire
    contract trivial to document.
    """

    PENDING = "pending"  # Job created, threads not yet started.
    RUNNING = "running"  # exec_command sent, channel open, reading.
    FINISHED = "finished"  # Remote process exited cleanly (exit_status set).
    CRASHED = "crashed"  # Transport error / reader thread died.
    KILLED = "killed"  # Terminated by ssh_signal / timeout.


# ---------------------------------------------------------------------------
# Snapshot — read-only view suitable for ssh_list_jobs
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class JobSnapshot:
    """Immutable metadata snapshot for a Job, safe to serialize to JSON.

    Produced by :meth:`Job.snapshot`. Never contains live objects
    (channels, locks, buffers) — just primitives — so the ``ssh_list_jobs``
    tool can return it verbatim without worrying about lifecycle.
    """

    job_id: str
    host: str
    cmd: str
    label: str | None
    started_at: float
    finished_at: float | None
    exit_status: int | None
    status: str
    pid: int | None
    pty: bool
    stdout_lines: int
    stderr_lines: int


# ---------------------------------------------------------------------------
# Job — the main Phase 2 type
# ---------------------------------------------------------------------------


@dataclass
class Job:
    """One long-running remote command plus its output buffers and reader threads.

    Construction is split from :meth:`start` so the JobManager can
    register the Job under its ``job_id`` *before* any reader thread is
    running — otherwise a very fast command (``true``) could fire its
    done_event before the manager has a chance to index it.

    Typical lifecycle::

        job = Job(job_id="a3f8b2", host="prod", channel=chan,
                  cmd="python -u parser.py", ring_maxlen=10_000,
                  capture_pid=True)
        job_manager.register(job)      # published to tail / list callers
        job.start()                    # launches the two reader threads
        # ... time passes ...
        job.done_event.wait()          # or poll exit_status via snapshot()
        job_manager.reap_later(job)    # Phase 5 reaper

    Attributes (all read-only once :meth:`start` has been called, except
    the four explicitly lock-protected ones):

        job_id: Short uuid prefix, e.g. ``"a3f8b2"``. Assigned by the
            JobManager.
        host: Alias of the configured host this job runs on.
        cmd: The user-supplied command string (pre-wrapping). Stored
            verbatim so ``ssh_list_jobs`` can show what's running.
        label: Optional human-friendly tag passed to ``ssh_spawn``. Shown
            in ``ssh_list_jobs`` but otherwise unused.
        channel: The :class:`paramiko.Channel` we read from. Owned by the
            Job once handed to the constructor; closed in :meth:`close`.
        started_at: Unix epoch at Job construction (not at first byte).
        pty: Whether the channel was allocated with get_pty(). Affects
            line-split normalization.
        capture_pid: Whether the stdout reader should strip a leading
            ``PID=<n>\\n`` line. Matches the :func:`build_pid_wrapper`
            output shape.

    Lock-protected mutables (snapshot via :meth:`snapshot`):

        exit_status: Remote process exit code, once known. None while
            still running.
        finished_at: Unix epoch when exit_status was observed.
        pid: Remote PID, extracted from the first PID= line of stdout if
            ``capture_pid`` is True.
        status: One of the :class:`JobStatus` constants.
    """

    job_id: str
    host: str
    cmd: str
    channel: paramiko.Channel

    ring_maxlen: int = 10_000
    capture_pid: bool = True
    pty: bool = False
    label: str | None = None
    started_at: float = field(default_factory=time.time)

    # Phase 5: opt-in disk mirror. When non-None, every line appended to
    # either buffer is ALSO written to ``<log_dir>/<job_id>.log`` in a
    # simple ``<iso_ts> <stream> <text>\n`` format. This gives operators
    # a durable record of a job's output even after the ring buffer
    # evicts old lines or the server process restarts. The JobManager
    # seeds this from :attr:`AppConfig.log_dir` at :meth:`ssh_spawn`
    # time; set to None (the default) to skip the disk mirror entirely.
    log_dir: Path | None = None

    # ------------------------------------------------------------------ state
    # Declared as dataclass fields so repr() is useful during debugging.
    # All four are mutated ONLY under ``_state_lock``.
    exit_status: int | None = None
    finished_at: float | None = None
    pid: int | None = None
    status: str = JobStatus.PENDING

    # ------------------------------------------------------------------ private
    # Populated in __post_init__. Omitted from repr because they contain
    # locks / threads / buffers that don't render usefully.
    _state_lock: threading.RLock = field(init=False, repr=False)
    _counter: LineCounter = field(init=False, repr=False)
    _stdout: RingBuffer = field(init=False, repr=False)
    _stderr: RingBuffer = field(init=False, repr=False)
    _done_event: threading.Event = field(init=False, repr=False)
    _stop_requested: threading.Event = field(init=False, repr=False)
    _threads: list[threading.Thread] = field(init=False, repr=False, default_factory=list)
    _started: bool = field(init=False, repr=False, default=False)

    # Phase 5 disk mirror: the actually-open file handle (or None if
    # ``log_dir`` wasn't set, or if opening failed — in the latter case
    # we degrade silently to in-memory-only instead of taking the whole
    # job down for what's a nice-to-have). Guarded by ``_log_lock`` so
    # the two reader threads don't interleave bytes mid-line.
    _log_file: object | None = field(init=False, repr=False, default=None)
    _log_lock: threading.Lock = field(init=False, repr=False)

    # ------------------------------------------------------------------ init

    def __post_init__(self) -> None:
        # Runtime validation of the dataclass inputs.
        if not self.job_id:
            raise ValueError("Job requires a non-empty job_id")
        if not self.host:
            raise ValueError(f"Job {self.job_id!r} requires a non-empty host")
        if self.ring_maxlen <= 0:
            raise ValueError(
                f"Job {self.job_id!r}: ring_maxlen must be positive, got {self.ring_maxlen}"
            )

        self._state_lock = threading.RLock()
        self._counter = LineCounter()
        # Both buffers share the counter so stdout line 7 and stderr line
        # 8 are in the correct temporal order across streams (see
        # :mod:`utils.ringbuf` docstring for why).
        self._stdout = RingBuffer(maxlen=self.ring_maxlen, counter=self._counter)
        self._stderr = RingBuffer(maxlen=self.ring_maxlen, counter=self._counter)
        self._done_event = threading.Event()
        self._stop_requested = threading.Event()

        # Phase 5 disk mirror init. The lock protects every write
        # against interleaving from the two reader threads; the file
        # handle itself stays None if log_dir wasn't provided OR if
        # open() failed (we log and degrade to in-memory-only so a
        # missing / unwritable log dir isn't a job-killer).
        self._log_lock = threading.Lock()
        self._log_file = None
        if self.log_dir is not None:
            try:
                self.log_dir.mkdir(parents=True, exist_ok=True)
                log_path = self.log_dir / f"{self.job_id}.log"
                # Line-buffered append-mode so concurrent ssh_list_jobs
                # tail-via-cat sees fresh data without us fsync'ing on
                # every write (which would dominate wall-clock time for
                # chatty jobs).
                self._log_file = log_path.open("a", buffering=1, encoding="utf-8")
                log.debug("Job %r: disk mirror open at %s", self.job_id, log_path)
            except OSError as e:
                log.warning(
                    "Job %r: could not open disk mirror under %s: %s; continuing without it",
                    self.job_id,
                    self.log_dir,
                    e,
                )
                self._log_file = None

    # ------------------------------------------------------------------ repr

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        with self._state_lock:
            return (
                f"Job(job_id={self.job_id!r}, host={self.host!r}, "
                f"status={self.status!r}, exit_status={self.exit_status!r}, "
                f"pid={self.pid!r}, cmd={_short(self.cmd)!r})"
            )

    # ------------------------------------------------------------------ views

    @property
    def stdout(self) -> RingBufferView:
        """Read-only view of the stdout ring buffer.

        Returning a view (not the raw RingBuffer) makes it impossible for
        tool code to accidentally call :meth:`RingBuffer.append` and
        corrupt the stream.
        """
        return self._stdout.view()

    @property
    def stderr(self) -> RingBufferView:
        """Read-only view of the stderr ring buffer."""
        return self._stderr.view()

    @property
    def done_event(self) -> threading.Event:
        """Fires when the remote process has exited (or the reader crashed).

        Set BEFORE :attr:`exit_status` / :attr:`finished_at` are
        published — but under the state lock, so any
        ``done_event.wait(); snapshot()`` sequence will see consistent
        values.
        """
        return self._done_event

    @property
    def stdout_line_count(self) -> int:
        """Total lines ever written to stdout (including evicted ones)."""
        # Since both buffers share one counter, we can't derive a
        # per-stream total from the counter alone. We use len() of the
        # retained deque plus the high-water evicted line_no — but
        # that's messy. For Phase 2 purposes callers only need a live
        # count for display; return the current retention length.
        return len(self._stdout)

    @property
    def stderr_line_count(self) -> int:
        return len(self._stderr)

    # ------------------------------------------------------------------ snapshot

    def snapshot(self) -> JobSnapshot:
        """Return an immutable metadata snapshot — safe to serialize to JSON.

        All four lock-protected fields are read atomically so the tool
        response never shows a torn state like "still_running=True but
        exit_status=0".
        """
        with self._state_lock:
            return JobSnapshot(
                job_id=self.job_id,
                host=self.host,
                cmd=self.cmd,
                label=self.label,
                started_at=self.started_at,
                finished_at=self.finished_at,
                exit_status=self.exit_status,
                status=self.status,
                pid=self.pid,
                pty=self.pty,
                stdout_lines=len(self._stdout),
                stderr_lines=len(self._stderr),
            )

    def is_running(self) -> bool:
        """Cheap, lock-protected check. Equivalent to ``not done_event.is_set()``."""
        return not self._done_event.is_set()

    # ------------------------------------------------------------------ start

    def start(self) -> None:
        """Launch the two reader threads (daemon).

        Idempotent: a second call is a no-op with a warning (signals a
        bug in the caller). Must be called AFTER the JobManager has
        published the Job under its ``job_id``, so an instantly-finishing
        job (``true``) can still be looked up by ``ssh_tail``.
        """
        with self._state_lock:
            if self._started:
                log.warning("Job %r: start() called twice; ignoring", self.job_id)
                return
            self._started = True

            # Per-recv socket timeout so the reader threads poll
            # ``_stop_requested`` at a bounded cadence.
            try:
                self.channel.settimeout(_RECV_TIMEOUT_SEC)
            except Exception:  # pragma: no cover - defensive
                log.debug("Job %r: could not set channel timeout", self.job_id, exc_info=True)

            self.status = JobStatus.RUNNING

        stdout_t = threading.Thread(
            target=self._read_stdout,
            name=f"job-{self.job_id}-stdout",
            daemon=True,
        )
        stderr_t = threading.Thread(
            target=self._read_stderr,
            name=f"job-{self.job_id}-stderr",
            daemon=True,
        )
        # Wait-for-exit runs as its own thread so exit_status is reaped
        # promptly even if both streams are quiet (e.g. a command that
        # exits without printing anything).
        exit_t = threading.Thread(
            target=self._watch_exit,
            name=f"job-{self.job_id}-exit",
            daemon=True,
        )

        self._threads = [stdout_t, stderr_t, exit_t]
        for t in self._threads:
            t.start()

        log.info(
            "Job %r started: host=%r pty=%s cmd=%s",
            self.job_id,
            self.host,
            self.pty,
            _short(self.cmd),
        )

    # ------------------------------------------------------------------ stop

    def request_stop(self) -> None:
        """Signal reader threads to exit at the next recv boundary.

        Does NOT kill the remote process — that's ``ssh_signal``'s job.
        This just tells our own threads to stop blocking on recv so the
        Job can be torn down after the remote has been killed (or after
        the JobManager reaps a finished job).
        """
        self._stop_requested.set()

    def _close_log_file(self) -> None:
        """Idempotently flush and close the disk mirror, if any.

        Called from :meth:`close` during normal teardown, and from the
        ``_append_line`` error path when a write fails. The lock makes
        sure a reader thread mid-write doesn't race the close.
        """
        with self._log_lock:
            if self._log_file is None:
                return
            try:
                self._log_file.flush()
            except Exception:  # pragma: no cover
                pass
            try:
                self._log_file.close()
            except Exception:  # pragma: no cover
                pass
            self._log_file = None

    def close(self, *, wait_threads_sec: float = 2.0) -> None:
        """Tear down the channel and join reader threads.


        Safe to call multiple times. Called by the JobManager during
        ``ssh_remove_job`` and during server shutdown. Does NOT kill the
        remote process; if the channel is still open when we close it,
        paramiko will send an SSH EOF which most processes interpret as
        stdin-closed (which may or may not terminate them).
        """
        self.request_stop()

        try:
            self.channel.close()
        except Exception:  # pragma: no cover
            log.debug("Job %r: error closing channel", self.job_id, exc_info=True)

        # Wake any tail callers blocked on the ring buffers.
        self._stdout.notify_done()
        self._stderr.notify_done()

        for t in list(self._threads):
            try:
                t.join(timeout=wait_threads_sec)
            except Exception:  # pragma: no cover
                log.debug("Job %r: error joining %s", self.job_id, t.name, exc_info=True)

        # Phase 5: close the disk mirror last, AFTER the reader threads
        # have joined. Any late ``_append_line`` attempt from a reader
        # that shaved seconds off our join timeout will see
        # ``self._log_file is None`` under the lock and silently skip —
        # the ring buffers are the authoritative record, the file is a
        # best-effort replica.
        self._close_log_file()

    # ------------------------------------------------------------------ reader: stdout

    def _read_stdout(self) -> None:
        """Reader thread for the stdout channel.

        Pulls bytes via ``channel.recv()`` until EOF or the channel is
        closed, decodes with a UTF-8 carry buffer, splits on ``\\n``, and
        appends each line to the stdout RingBuffer.

        On ``capture_pid=True`` the very first complete line is parsed as
        a PID marker and stored on :attr:`pid` — it is NOT added to the
        ring buffer (users never see the bookkeeping line). If the first
        line isn't a valid ``PID=<n>`` marker, we treat it as regular
        stdout (shouldn't happen with our wrapper, but defensive).
        """
        carry = bytearray()
        pid_consumed = not self.capture_pid  # Already "consumed" if we weren't looking.

        try:
            while not self._stop_requested.is_set():
                try:
                    chunk = self.channel.recv(_RECV_CHUNK)
                except Exception as e:
                    # paramiko raises socket.timeout as socket.timeout in
                    # older versions and builtins.TimeoutError in newer
                    # ones. Either way we just loop to re-check stop.
                    if _is_timeout(e):
                        continue
                    # Real transport error: surface and bail.
                    self._on_reader_crash("stdout", e)
                    return

                if not chunk:
                    # EOF: the channel was closed cleanly by the remote.
                    break

                carry.extend(chunk)

                # --- PID-marker extraction on the very first newline ---
                if not pid_consumed:
                    nl = carry.find(b"\n")
                    if nl < 0:
                        # Still waiting for the first newline. Guard
                        # against a malformed / absent PID line that
                        # would otherwise grow carry unboundedly.
                        if len(carry) > _MAX_LINE_BYTES:
                            log.warning(
                                "Job %r: no PID line after %d bytes; "
                                "treating first chunk as regular stdout",
                                self.job_id,
                                len(carry),
                            )
                            pid_consumed = True
                        continue

                    first = bytes(carry[:nl])
                    del carry[: nl + 1]

                    # Tolerate CRLF from pty channels.
                    if first.endswith(b"\r"):
                        first = first[:-1]

                    if first.startswith(b"PID="):
                        try:
                            extracted = int(first[4:])
                            with self._state_lock:
                                self.pid = extracted
                            log.info("Job %r: captured remote pid=%d", self.job_id, extracted)
                        except ValueError:
                            # Malformed marker: fall back to treating it
                            # as regular output so the user sees it.
                            self._append_line("stdout", first.decode("utf-8", errors="replace"))
                    else:
                        # First line wasn't a PID marker — emit it
                        # verbatim. Our wrapper always emits one, so this
                        # branch only fires on a misconfiguration or a
                        # user who passed ``capture_pid=False`` upstream
                        # of us — still safer than silently dropping.
                        self._append_line("stdout", first.decode("utf-8", errors="replace"))

                    pid_consumed = True
                    # Fall through to normal line-splitting below in case
                    # the same chunk carried more lines after PID.

                # --- Normal line splitting on newline ---
                self._drain_lines(carry, "stdout")

            # Channel closed — flush any partial final line.
            if carry:
                self._append_line("stdout", _decode_and_strip(bytes(carry)))
        except Exception as e:  # pragma: no cover - truly unexpected
            self._on_reader_crash("stdout", e)
        finally:
            self._stdout.notify_done()

    # ------------------------------------------------------------------ reader: stderr

    def _read_stderr(self) -> None:
        """Reader thread for the stderr channel. Mirror of _read_stdout but:

        * Uses ``channel.recv_stderr`` instead of ``channel.recv``.
        * Never does PID extraction (stderr is always user output).
        """
        carry = bytearray()

        try:
            while not self._stop_requested.is_set():
                try:
                    chunk = self.channel.recv_stderr(_RECV_CHUNK)
                except Exception as e:
                    if _is_timeout(e):
                        continue
                    self._on_reader_crash("stderr", e)
                    return

                if not chunk:
                    break

                carry.extend(chunk)
                self._drain_lines(carry, "stderr")

            if carry:
                self._append_line("stderr", _decode_and_strip(bytes(carry)))
        except Exception as e:  # pragma: no cover
            self._on_reader_crash("stderr", e)
        finally:
            self._stderr.notify_done()

    # ------------------------------------------------------------------ reader: exit

    def _watch_exit(self) -> None:
        """Dedicated thread that waits for ``recv_exit_status`` and finalizes state.

        Kept separate from the stdout/stderr readers because
        ``recv_exit_status()`` blocks until the remote delivers it — we
        don't want to couple that wait to either output stream, which
        might be EOF'd much earlier on a job that redirects its output.
        """
        try:
            # recv_exit_status() blocks on paramiko's internal event,
            # not on the socket, so it's fine to call in parallel with
            # recv/recv_stderr on the other threads.
            code = self.channel.recv_exit_status()
            self._finalize_exit(code, status=JobStatus.FINISHED)
        except Exception as e:
            # EOFError / SSHException / socket errors from a dropped
            # transport: mark crashed and synthesize a stderr line so
            # ssh_tail callers see a reason.
            log.warning("Job %r: exit watcher failed: %s", self.job_id, e)
            with self._state_lock:
                if self.exit_status is None:
                    self._stderr.append(
                        "stderr",
                        f"[mcp-ssh-live: exit watcher failed: {type(e).__name__}: {e}]",
                    )
            self._finalize_exit(-1, status=JobStatus.CRASHED)

    # ------------------------------------------------------------------ helpers

    def _drain_lines(self, carry: bytearray, stream: str) -> None:
        """Split every complete ``\\n``-terminated line out of ``carry``.

        Left-over bytes (no trailing newline yet) stay in ``carry`` for
        the next recv. Respects :data:`_MAX_LINE_BYTES` to prevent
        unbounded growth on a remote that emits a gigabyte without a
        newline — in that case we force-flush as a single JobLine.
        """
        while True:
            nl = carry.find(b"\n")
            if nl < 0:
                if len(carry) > _MAX_LINE_BYTES:
                    # Emergency flush. Rare in practice; mostly defends
                    # against pathological input.
                    forced = bytes(carry)
                    carry.clear()
                    self._append_line(
                        stream,
                        _decode_and_strip(forced) + "  [mcp-ssh-live: forced line flush at 1 MiB]",
                    )
                return

            line_bytes = bytes(carry[:nl])
            del carry[: nl + 1]

            # Strip trailing \r so pty-mode CRLF matches non-pty LF.
            if line_bytes.endswith(b"\r"):
                line_bytes = line_bytes[:-1]

            self._append_line(stream, line_bytes.decode("utf-8", errors="replace"))

    def _append_line(self, stream: str, text: str) -> None:
        """Append one decoded line to the appropriate ring buffer.

        Small wrapper so call sites don't have to remember which buffer
        maps to which stream name. Phase 5: also mirrors the line to
        the on-disk log file (if ``log_dir`` was provided at Job
        construction time) so a full record survives ring-buffer
        eviction and server restart.
        """
        if stream == "stdout":
            self._stdout.append("stdout", text)
        elif stream == "stderr":
            self._stderr.append("stderr", text)
        else:  # pragma: no cover - guarded internally
            raise ValueError(f"unknown stream {stream!r}")

        # Phase 5 disk mirror. Kept OUTSIDE the ring-buffer append path
        # so a sluggish filesystem doesn't backpressure the reader
        # thread — the ring buffer is authoritative for tail callers,
        # the on-disk file is a best-effort replica. On write failure
        # we log once and disable the mirror (self._log_file=None) so
        # a bad disk doesn't flood the server's own stderr with
        # per-line errors.
        if self._log_file is not None:
            # ISO-8601 with microseconds at a monotonic-ish UTC time,
            # matches what operators expect when grep'ing a log file.
            # Using ``time.time()`` instead of the JobLine's own ``ts``
            # is deliberate: the reader thread already spent that ts
            # updating the ring buffer; re-reading it here would need a
            # lock dance. Wall-clock drift between the two timestamps
            # is bounded by a few microseconds — fine for forensics.
            line = f"{_iso_now()} {stream} {text}\n"
            try:
                with self._log_lock:
                    # Check under the lock in case another thread already
                    # disabled the mirror between our outer check and here.
                    if self._log_file is not None:
                        self._log_file.write(line)
            except (OSError, ValueError) as e:
                # ValueError fires when the file has been closed under
                # us (race against Job.close). Neither case should take
                # the job down; log once and fall silent.
                log.warning(
                    "Job %r: disk mirror write failed; disabling: %s",
                    self.job_id,
                    e,
                )
                with self._log_lock:
                    try:
                        if self._log_file is not None:
                            self._log_file.close()
                    except Exception:  # pragma: no cover
                        pass
                    self._log_file = None

    def _finalize_exit(self, code: int, *, status: str) -> None:
        """Publish exit code, set finished_at, fire done_event.

        Idempotent — a KILLED job that also later receives its exit code
        keeps the KILLED status but gets a real exit_status integer for
        ``ssh_list_jobs`` to display.
        """
        with self._state_lock:
            # Only the FIRST finalizer wins for status transitions, so
            # a kill path that already set status=KILLED isn't
            # overwritten by the natural exit code arriving afterwards.
            already_final = self.exit_status is not None
            self.exit_status = code
            if self.finished_at is None:
                self.finished_at = time.time()
            if not already_final:
                self.status = status

        # Notify rings BEFORE setting done_event so a tail caller woken
        # by the event sees the buffers already flushed.
        self._stdout.notify_done()
        self._stderr.notify_done()
        self._done_event.set()

        log.info(
            "Job %r finalized: exit=%d status=%s duration=%.2fs",
            self.job_id,
            code,
            status,
            (self.finished_at or time.time()) - self.started_at,
        )

    def mark_killed(self, signal_name: str) -> None:
        """Record that this job was killed by ``ssh_signal`` / timeout.

        Called by Phase 3 signal handling BEFORE the remote actually
        exits, so ``ssh_list_jobs`` can distinguish "user killed it" from
        "it crashed on its own". The real exit_status arrives later via
        :meth:`_finalize_exit` (typically 128+signum or -1).
        """
        with self._state_lock:
            if self.exit_status is None:
                self.status = JobStatus.KILLED
        self._stderr.append(
            "stderr",
            f"[mcp-ssh-live: sent SIG{signal_name} to remote pid]",
        )

    def _on_reader_crash(self, which: str, exc: BaseException) -> None:
        """Shared failure path for stdout / stderr reader threads.

        Appends a diagnostic stderr line, sets status=CRASHED (unless the
        job was explicitly killed), wakes waiters.
        """
        log.warning(
            "Job %r: %s reader crashed: %s: %s",
            self.job_id,
            which,
            type(exc).__name__,
            exc,
        )
        self._stderr.append(
            "stderr",
            f"[mcp-ssh-live: {which} reader crashed: {type(exc).__name__}: {exc}]",
        )
        # Only downgrade status if no harder final state has been set
        # (KILLED / FINISHED both win over CRASHED).
        with self._state_lock:
            if self.exit_status is None and self.status not in (
                JobStatus.KILLED,
                JobStatus.FINISHED,
            ):
                self.status = JobStatus.CRASHED

        # Don't call _finalize_exit here — the exit watcher thread is
        # responsible for publishing the authoritative exit_status. We
        # just make sure waiters unblock.
        self._stdout.notify_done()
        self._stderr.notify_done()


# ---------------------------------------------------------------------------
# Module-private helpers
# ---------------------------------------------------------------------------


def _is_timeout(exc: BaseException) -> bool:
    """Return True for the various timeout exception classes paramiko might raise.

    paramiko's :meth:`Channel.recv` surfaces ``socket.timeout`` on older
    Pythons and a plain :class:`TimeoutError` on 3.10+ (since
    ``socket.timeout`` is an alias for it there). Some intermediate
    wrappers also raise :class:`paramiko.SSHException` with a timeout
    message. We accept all three so the reader loop doesn't
    accidentally treat a timeout as a fatal error.
    """
    import socket

    if isinstance(exc, (TimeoutError, socket.timeout)):
        return True
    # Some paramiko builds wrap the socket timeout.
    if isinstance(exc, paramiko.SSHException) and "timeout" in str(exc).lower():
        return True
    return False


def _decode_and_strip(raw: bytes) -> str:
    """UTF-8 decode a byte string and strip a trailing ``\\r`` if present.

    Used on end-of-stream partial-line flushes, where the remote didn't
    emit a final ``\\n`` so :meth:`_drain_lines` never saw the line.
    """
    if raw.endswith(b"\r"):
        raw = raw[:-1]
    return raw.decode("utf-8", errors="replace")


def _short(s: str, n: int = 80) -> str:
    """Collapse newlines and truncate for log-line readability."""
    s = s.replace("\n", " ").replace("\r", " ")
    return s if len(s) <= n else s[: n - 1] + "…"


def _iso_now() -> str:
    """Return the current UTC time as an ISO-8601 string with microseconds.

    Used by the Phase 5 disk mirror so each line in
    ``<log_dir>/<job_id>.log`` is prefixed with a human-readable
    timestamp that grep / awk can parse without extra tooling.
    Format: ``YYYY-MM-DDTHH:MM:SS.ffffffZ`` (trailing ``Z`` denotes
    UTC, matches RFC 3339 / ISO 8601 "Zulu" form).
    """
    import datetime as _dt

    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
