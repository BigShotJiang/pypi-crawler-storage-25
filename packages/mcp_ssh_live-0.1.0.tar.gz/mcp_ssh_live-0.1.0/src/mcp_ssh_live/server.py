"""FastMCP server wiring for mcp-ssh-live.

This module is intentionally thin: it builds the shared state
(:class:`ConnectionPool`) from an already-loaded :class:`AppConfig`,
instantiates a :class:`fastmcp.FastMCP` app, registers each tool module on
it, and returns the app ready to be served over stdio.

The CLI entrypoint in ``__main__.py`` owns the lifecycle (signal handlers,
graceful shutdown); this file only knows how to assemble the pieces.

Design notes:

* One global ``ConnectionPool`` per server process, shared by every tool.
  Tools close over it at registration time.
* Each tool lives in its own module under :mod:`mcp_ssh_live.tools` and
  exposes a ``register(mcp, pool, cfg)`` function. This keeps the server
  module small and makes it trivial to add Phase 2+ tools later.
* All logging goes through :mod:`logging`, which ``configure_logging`` has
  pinned to stderr (stdout is reserved for the MCP JSON-RPC stream over
  stdio).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from fastmcp import FastMCP

from . import __version__
from .config import AppConfig
from .connection import ConnectionPool
from .job_manager import JobManager, build_manager
from .tools import (
    connect_tool,
    exec_tool,
    hosts_tool,
    jobs_tool,
    persistent_tool,
    sftp_tool,
    signal_tool,
    spawn_tool,
    stdin_tool,
    tail_tool,
)

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Server state
# ---------------------------------------------------------------------------


@dataclass
class ServerState:
    """Shared handles returned by :func:`build_server`.

    The CLI keeps a reference to this so it can close pooled connections
    cleanly during shutdown.
    """

    mcp: FastMCP
    pool: ConnectionPool
    cfg: AppConfig
    job_manager: JobManager

    def close(self) -> None:
        """Release all pooled SSH connections and tear down every Job.

        Order matters: we close the JobManager FIRST so its reader
        threads stop trying to use channels on the transports we're
        about to tear down. Then the ConnectionPool closes the
        transports themselves. Both steps are best-effort — a single
        error in one must not prevent the other from running, or a
        broken job could leak the whole TCP socket on shutdown.
        """
        try:
            self.job_manager.close_all()
        except Exception:  # pragma: no cover - best-effort
            log.debug("error while closing job manager", exc_info=True)
        try:
            self.pool.close_all()
        except Exception:  # pragma: no cover - best-effort
            log.debug("error while closing connection pool", exc_info=True)


# ---------------------------------------------------------------------------
# Builders
# ---------------------------------------------------------------------------


def build_pool(cfg: AppConfig) -> ConnectionPool:
    """Construct a :class:`ConnectionPool` from the effective config.

    The pool itself is lazy: no SSH handshake happens until the first tool
    call touches a host. Phase 5: reconnect-retry parameters are read from
    :attr:`AppConfig.limits` and propagated into every
    :class:`SSHConnection` the pool lazily constructs — so a transient
    network blip or a sshd restart gets a few retries before the tool
    layer surfaces an error.
    """
    return ConnectionPool(
        cfg.hosts,
        known_hosts_path=cfg.known_hosts_path,
        insecure_auto_add=cfg.insecure_auto_add_host_keys,
        reconnect_retries=cfg.limits.reconnect_retries,
        reconnect_delay_sec=cfg.limits.reconnect_delay_sec,
    )


def build_server(
    cfg: AppConfig,
    *,
    pool: ConnectionPool | None = None,
    job_manager: JobManager | None = None,
    name: str = "mcp-ssh-live",
) -> ServerState:
    """Assemble the FastMCP app and register all tools.

    Args:
        cfg: The fully validated application configuration.
        pool: Optional pre-built :class:`ConnectionPool`. Useful in tests
            that want to stub out the pool. When ``None``, a real pool is
            built from ``cfg``.
        job_manager: Optional pre-built :class:`JobManager`. Tests that
            want to inject a deterministic id allocator or a stub clock
            pass one in; production callers leave it as ``None`` and a
            real manager is built from ``cfg``. The reaper thread is
            started here (not in the caller) so every ServerState is
            self-contained.
        name: The MCP server name advertised to clients.

    Returns:
        A :class:`ServerState` containing the FastMCP app, the pool,
        and the job manager.
    """
    if pool is None:
        pool = build_pool(cfg)
    if job_manager is None:
        job_manager = build_manager(cfg)

    # Start the JobManager's background reaper thread. Idempotent, so
    # a caller that passed in a pre-started manager for testing isn't
    # penalised.
    job_manager.start()

    # Phase 5: give the JobManager a handle on the ConnectionPool so
    # its graceful-shutdown path (:meth:`JobManager.close_all`) can
    # send ``kill -TERM``/``-KILL`` to each live job's remote pid via
    # a short exec channel on the already-authenticated transport,
    # instead of just yanking the channel and relying on sshd's HUP
    # behavior. Without this attach the shutdown still runs, just
    # less gracefully (see the ``_send_remote_kill`` docstring).
    job_manager.attach_pool(pool)

    mcp = FastMCP(
        name=name,
        instructions=(
            "Interactive, streaming SSH tool for LLM agents. "
            "Use ssh_exec for short synchronous commands (<60s). "
            "Use ssh_spawn + ssh_tail for long-running jobs with incremental "
            "output streaming — spawn returns a job_id immediately, then poll "
            "tail(job_id, since_line_no, wait_ms=5000) to watch output arrive. "
            "Use ssh_signal to deliver TERM/KILL/INT, ssh_send_stdin for "
            "interactive input (sudo, REPLs), ssh_list_jobs / ssh_remove_job "
            "for registry management."
        ),
    )

    log.info(
        "mcp-ssh-live v%s starting: hosts=%s default_host=%r log_dir=%s",
        __version__,
        sorted(cfg.hosts),
        cfg.default_host,
        cfg.log_dir,
    )

    # -- Runtime connect/disconnect (no credentials at startup needed) ------
    connect_tool.register(mcp, pool, cfg)

    # -- Persistent jobs (survive MCP disconnect via nohup) -----------------
    persistent_tool.register(mcp, pool, cfg)

    # -- Phase 1 tools ------------------------------------------------------
    exec_tool.register(mcp, pool, cfg)

    # -- Phase 2 tools (jobs + streaming tail) ------------------------------
    # Order-independent — each tool only touches the shared pool / cfg /
    # job_manager at call time, not at registration time. Grouped by phase
    # in source order purely for readability.
    spawn_tool.register(mcp, pool, cfg, job_manager)
    tail_tool.register(mcp, cfg, job_manager)
    jobs_tool.register(mcp, cfg, job_manager)

    # -- Phase 3 tools (signals + stdin) ------------------------------------
    signal_tool.register(mcp, pool, cfg, job_manager)
    stdin_tool.register(mcp, cfg, job_manager)

    # -- Phase 4 tools (SFTP + multi-host discovery) ------------------------
    # ssh_upload / ssh_download go through SFTP on the pooled transport —
    # same ConnectionPool the exec/spawn tools share, so a previously
    # authenticated host doesn't re-handshake for a file transfer.
    # ssh_list_hosts reads the pool + JobManager to report per-host
    # runtime state (connected / active_jobs) without leaking secrets.
    sftp_tool.register(mcp, pool, cfg)
    hosts_tool.register(mcp, pool, cfg, job_manager)

    return ServerState(mcp=mcp, pool=pool, cfg=cfg, job_manager=job_manager)


# ---------------------------------------------------------------------------
# Convenience: run over stdio
# ---------------------------------------------------------------------------


def run_stdio(state: ServerState) -> None:
    """Run the FastMCP server over stdio (blocks until the client disconnects).

    This is the transport MCP clients (Claude Desktop, Cursor, Zed) use to
    spawn us as a subprocess. Stdout is reserved for JSON-RPC frames, which
    is why :func:`configure_logging` pins all logs to stderr.
    """
    try:
        state.mcp.run(transport="stdio")
    finally:
        state.close()
