"""mcp-ssh-live — Interactive, streaming SSH tool for LLM agents via MCP.

See SPEC.md in the repository root for the full technical specification.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]
