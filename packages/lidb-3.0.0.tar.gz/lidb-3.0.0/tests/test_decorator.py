# Copyright (c) ZhangYundi
# Licensed under the MIT License
# Test for @dataset decorator

import pytest
import polars as pl

from lidb import dataset
from lidb.dataset import Dataset


class TestDatasetDecorator:
    """测试 @dataset 装饰器"""

    def test_decorator_creates_dataset(self):
        """装饰器应返回 Dataset 对象"""

        @dataset()
        def my_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "value": [1]})

        # 装饰器应该返回 Dataset 实例
        assert isinstance(my_data, Dataset)

    def test_decorator_with_depends(self):
        """装饰器支持 depends 参数"""

        @dataset()
        def base_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "base": [1]})

        @dataset(base_data)
        def derived_data(date: str, depend: pl.DataFrame) -> pl.DataFrame:
            return depend.with_columns(derived=pl.col("base") * 2)

        assert isinstance(base_data, Dataset)
        assert isinstance(derived_data, Dataset)

    def test_decorator_tb_parameter(self):
        """装饰器支持 tb 参数"""

        @dataset(tb="custom/table/path")
        def my_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        assert my_data.tb == "custom/table/path"

    def test_decorator_update_time_parameter(self):
        """装饰器支持 update_time 参数"""

        @dataset(update_time="09:30")
        def daily_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        assert daily_data.update_time == "09:30"

    def test_decorator_window_parameter(self):
        """装饰器支持 window 参数"""

        @dataset(window="5d")
        def windowed_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        assert windowed_data._window == "5d"

    def test_decorator_partitions_parameter(self):
        """装饰器支持 partitions 参数"""

        @dataset(partitions=["date"])
        def partitioned_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "value": [1]})

        assert partitioned_data.partitions == ["date"]

    def test_decorator_empty_partitions_still_gets_appended(self):
        """partitions=[] 时仍会追加 _append_partitions（如 date, asset）"""

        @dataset(partitions=[])
        def no_partition_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        # 实际行为：空列表 + _append_partitions
        assert "date" in no_partition_data.partitions

    def test_decorator_is_hft_parameter(self):
        """装饰器支持 is_hft 参数"""

        @dataset(is_hft=True)
        def hft_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        assert hft_data._is_hft is True

    def test_decorator_multiple_depends(self):
        """装饰器支持多个依赖"""

        @dataset()
        def source1(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "v1": [1]})

        @dataset()
        def source2(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "v2": [2]})

        @dataset(source1, source2)
        def combined(date: str, depend1: pl.DataFrame, depend2: pl.DataFrame) -> pl.DataFrame:
            return depend1.join(depend2, on="date")

        assert len(combined._depends) == 2

    def test_decorator_default_values(self):
        """装饰器默认参数值"""

        @dataset()
        def default_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        # 默认值检查（基于实际行为）
        # @dataset() 装饰器显式传入 data_name=fn.__name__，从 fn 参数推断 partitions
        assert default_data.update_time == ""  # 默认空字符串
        assert default_data._window == "1d"  # 默认 1d
        assert default_data._is_hft is False  # 默认 False
        # partitions 会被推断（包含 date）
        assert "date" in default_data.partitions

    def test_decorator_preserves_function_name(self):
        """装饰器保留原函数名"""

        @dataset()
        def my_custom_function(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        # data_name 在装饰器中赋值为 fn.__name__
        assert my_custom_function.data_name == "my_custom_function"

    def test_decorator_partitions_none_inference(self):
        """partitions=None 时从函数参数推断分区"""

        @dataset()
        def data_with_params(date: str, asset: str, value: int) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "asset": [asset], "value": [value]})

        # partitions=None 时，从 fn 参数推断
        # 默认会排除 'this', 'depend'，但包含其他所有参数
        assert "date" in data_with_params.partitions
        assert "asset" in data_with_params.partitions
        assert "value" in data_with_params.partitions


class TestDatasetConstructorEquivalence:
    """测试直接构造 Dataset 与使用 @dataset 装饰器的一致性"""

    def test_save_path_and_tb_consistency_with_tb_param(self):
        """当指定 tb 参数时，两种构造方式的 save_path 和 tb 应该一致"""
        tb_value = "custom/test/path"

        @dataset(tb=tb_value)
        def decorated_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        # 方式2：直接构造
        def plain_fn(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        constructed_data = Dataset(fn=plain_fn, tb=tb_value, data_name="decorated_data")

        # 验证 tb 一致
        assert decorated_data.tb == constructed_data.tb
        # 验证 save_path 一致
        assert decorated_data.save_path == constructed_data.save_path

    def test_save_path_and_tb_consistency_default_tb(self):
        """不指定 tb 参数时，两种构造方式的 save_path 和 tb 应该一致"""

        @dataset()
        def decorated_default(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        def plain_fn_default(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        constructed_default = Dataset(fn=plain_fn_default, data_name="decorated_default")

        # 验证 tb 一致
        assert decorated_default.tb == constructed_default.tb
        # 验证 save_path 一致
        assert decorated_default.save_path == constructed_default.save_path

    def test_save_path_and_tb_consistency_with_data_name(self):
        """显式指定 data_name 时，两种构造方式的 save_path 和 tb 应该一致"""
        data_name = "my_custom_name"
        tb_value = "custom/path"

        @dataset(tb=tb_value, data_name=data_name)
        def decorated_named(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        constructed_named = Dataset(fn=lambda date: pl.DataFrame({"date": [date]}), tb=tb_value, data_name=data_name)

        # 验证 tb 一致
        assert decorated_named.tb == constructed_named.tb
        # 验证 save_path 一致
        assert decorated_named.save_path == constructed_named.save_path

    def test_update_time_consistency(self):
        """两种构造方式的 update_time 应该一致"""
        update_time_value = "15:30:00"

        @dataset(update_time=update_time_value)
        def decorated_update(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        constructed_update = Dataset(fn=lambda date: pl.DataFrame({"date": [date]}), update_time=update_time_value)

        assert decorated_update.update_time == constructed_update.update_time

    def test_window_consistency(self):
        """两种构造方式的 window 应该一致"""
        window_value = "5d"

        @dataset(window=window_value)
        def decorated_window(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        constructed_window = Dataset(fn=lambda date: pl.DataFrame({"date": [date]}), window=window_value)

        assert decorated_window._window == constructed_window._window

    def test_partitions_consistency(self):
        """两种构造方式的 partitions 应该一致"""
        partitions_value = ["asset", "date"]

        @dataset(partitions=partitions_value)
        def decorated_partitions(date: str, asset: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "asset": [asset]})

        constructed_partitions = Dataset(
            fn=lambda date, asset: pl.DataFrame({"date": [date], "asset": [asset]}),
            partitions=partitions_value,
        )

        assert decorated_partitions.partitions == constructed_partitions.partitions

    def test_is_hft_consistency(self):
        """两种构造方式的 is_hft 应该一致"""
        is_hft_value = True

        @dataset(is_hft=is_hft_value)
        def decorated_hft(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        constructed_hft = Dataset(fn=lambda date: pl.DataFrame({"date": [date]}), is_hft=is_hft_value)

        assert decorated_hft._is_hft == constructed_hft._is_hft

    def test_full_equivalence(self):
        """完整参数下两种构造方式应该完全等价"""
        tb_value = "full/test/path"
        update_time_value = "16:00:00"
        window_value = "3d"
        partitions_value = ["exchange"]
        is_hft_value = False
        data_name = "full_test_ds"

        @dataset(
            tb=tb_value,
            update_time=update_time_value,
            window=window_value,
            partitions=partitions_value,
            is_hft=is_hft_value,
            data_name=data_name,
        )
        def decorated_full(date: str, exchange: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "exchange": [exchange]})

        constructed_full = Dataset(
            fn=lambda date, exchange: pl.DataFrame({"date": [date], "exchange": [exchange]}),
            tb=tb_value,
            update_time=update_time_value,
            window=window_value,
            partitions=partitions_value,
            is_hft=is_hft_value,
            data_name=data_name,
        )

        # 验证所有关键属性一致
        assert decorated_full.tb == constructed_full.tb
        assert decorated_full.save_path == constructed_full.save_path
        assert decorated_full.update_time == constructed_full.update_time
        assert decorated_full._window == constructed_full._window
        assert decorated_full.partitions == constructed_full.partitions
        assert decorated_full._is_hft == constructed_full._is_hft
        assert decorated_full.data_name == constructed_full.data_name