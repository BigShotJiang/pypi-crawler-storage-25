"""测试 init 模块的配置初始化"""
from lidb.init import DB_PATH, CONFIG_PATH, get_settings


def test_constants_defined():
    """模块级常量定义正常"""
    assert DB_PATH is not None
    assert CONFIG_PATH is not None


def test_get_settings_returns_config():
    """get_settings 返回有效配置对象"""
    settings = get_settings()
    assert settings is not None
