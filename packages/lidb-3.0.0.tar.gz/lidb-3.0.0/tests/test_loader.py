"""测试 loader 模块"""
import polars as pl
import pytest
from lidb.loader import load_ds
from lidb.dataset import Dataset


class TestLoadDs:
    """测试 load_ds"""

    def test_beg_date_gt_end_date_raises(self):
        """开始日期大于结束日期时抛出 ValueError"""
        with pytest.raises(ValueError, match="beg_date must be less than end_date"):
            load_ds(
                ds_conf={"test": []},
                beg_date="2024-01-05",
                end_date="2024-01-01",
                times=[""],
                show_progress=False,
            )

    def test_empty_ds_conf_returns_empty(self):
        """空配置时返回空字典"""
        result = load_ds(
            ds_conf={},
            beg_date="2024-01-01",
            end_date="2024-01-03",
            times=[""],
            show_progress=False,
        )
        assert result == {}

    def test_load_ds_returns_dict(self):
        """ds_list 为空时返回 dict"""
        result = load_ds(
            ds_conf={"test": []},
            beg_date="2024-01-02",
            end_date="2024-01-02",
            times=[""],
            show_progress=False,
        )
        assert isinstance(result, dict)
