"""测试 DataService"""
import polars as pl
from lidb.svc.data import DataService


class TestDataService:
    """测试 DataService 生命周期"""

    def test_initial_state(self):
        """新建的 DataService 不应在运行中"""
        ds = DataService()
        assert ds.is_running is False

    def test_put_get_roundtrip(self):
        """put_data 后 get_data 能取回相同数据"""
        ds = DataService()
        data = {"test": pl.DataFrame({"a": [1, 2, 3]})}
        ds.put_data("key1", data)
        key, result, is_empty = ds.get_data()
        assert key == "key1"
        assert result["test"].to_dict(as_series=False) == {"a": [1, 2, 3]}
        assert is_empty is False

    def test_get_empty_returns_empty_flag(self):
        """空队列时 get_data 返回 empty 标志"""
        ds = DataService()
        key, data, is_empty = ds.get_data()
        assert is_empty is True
        assert data is None

    def test_stop_idempotent(self):
        """多次 stop 不应报错"""
        ds = DataService()
        ds.stop()  # 未启动时 stop
        ds.stop()  # 再次 stop
        assert ds.is_running is False
