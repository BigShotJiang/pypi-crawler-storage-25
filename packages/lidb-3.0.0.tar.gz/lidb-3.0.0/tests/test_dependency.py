# Copyright (c) ZhangYundi.
# Licensed under the MIT License.
# Created on 2026/4/27 17:53
# Description:

import pytest
from lidb import dataset, Dataset
import polars as pl


@pytest.fixture
def ds_base():
    """基础数据集"""
    @dataset()
    def _ds_base(date: str):
        return pl.DataFrame(
            {
                "date": [date, ],
                "asset": ["000001", ],
                "value": [1.0, ],
            }
        )
    return _ds_base


@pytest.fixture
def ds_target(ds_base):
    """依赖 ds_base 的数据集"""
    @dataset(ds_base)
    def _ds_target(this: Dataset, date: str):
        depend = this.get_dependsPIT(date, 1)
        return depend.with_columns(value=pl.col("value") * 2)
    return _ds_target


@pytest.fixture
def ds_base1():
    """底层数据集1"""
    @dataset()
    def _ds_base1(date: str):
        return pl.DataFrame({
            "date": [date, ],
            "asset": ["000001", ],
            "value1": [1.0, ],
        })
    return _ds_base1


@pytest.fixture
def ds_base2(ds_base1):
    """底层数据集2，依赖 ds_base1"""
    @dataset(ds_base1)
    def _ds_base2(this: Dataset, date: str):
        depend = this.get_dependsPIT(date, 1)
        return depend.with_columns(value2=pl.col("value1") * 10)
    return _ds_base2


@pytest.fixture
def ds_base3(ds_base2):
    """底层数据集3，依赖 ds_base2"""
    @dataset(ds_base2)
    def _ds_base3(this: Dataset, date: str):
        depend = this.get_dependsPIT(date, 1)
        return depend.with_columns(value3=pl.col("value2") * 10)
    return _ds_base3


@pytest.fixture
def ds_multi_level(ds_base3):
    """多级依赖数据集，依赖 ds_base3"""
    @dataset(ds_base3)
    def _ds_multi_level(this: Dataset, date: str):
        depend = this.get_dependsPIT(date, 1)
        return depend.with_columns(final=pl.col("value3") * 10)
    return _ds_multi_level


class TestMultiLevelDependency:
    """测试多级依赖链"""

    def test_multi_level_dependency(self, ds_multi_level, ds_base1, ds_base2, ds_base3):
        """测试 ds_base1 -> ds_base2 -> ds_base3 -> ds_target 多级依赖"""
        date = "2020-01-02"

        # 获取最终结果
        result = ds_multi_level.get_value(date)

        # 验证结果不为空
        assert result is not None, "multi-level dependency should return a result"
        assert not result.is_empty(), "result should not be empty"

        # 验证所有层级的数据都存在
        assert "value1" in result.columns, "value1 from ds_base1 should exist"
        assert "value2" in result.columns, "value2 from ds_base2 should exist"
        assert "value3" in result.columns, "value3 from ds_base3 should exist"
        assert "final" in result.columns, "final from ds_target should exist"

        # 验证计算链: 1.0 -> 10.0 -> 100.0 -> 1000.0
        assert result["value1"][0] == 1.0, "value1 should be 1.0"
        assert result["value2"][0] == 10.0, "value2 should be 1.0 * 10 = 10.0"
        assert result["value3"][0] == 100.0, "value3 should be 10.0 * 10 = 100.0"
        assert result["final"][0] == 1000.0, "final should be 100.0 * 10 = 1000.0"

        # 验证底层数据自动补全
        base1_val = ds_base1.get_value(date)
        assert base1_val is not None and not base1_val.is_empty(), "ds_base1 should auto-complete"

        base2_val = ds_base2.get_value(date)
        assert base2_val is not None and not base2_val.is_empty(), "ds_base2 should auto-complete"

        base3_val = ds_base3.get_value(date)
        assert base3_val is not None and not base3_val.is_empty(), "ds_base3 should auto-complete"

    def test_multi_level_get_history(self, ds_multi_level, ds_base1, ds_base2, ds_base3):
        """测试多级依赖的 get_history 自动补全"""
        dates = ["2020-01-02", "2020-01-03"]

        result = ds_multi_level.get_history(dates)

        # 验证返回结果
        assert result is not None, "get_history should return a result"
        if hasattr(result, "collect"):
            result = result.collect()
        assert result is not None and not result.is_empty(), "get_history result should not be empty"

        # 验证所有底层数据都被自动补全
        for date in dates:
            for ds, name in [(ds_base1, "ds_base1"), (ds_base2, "ds_base2"), (ds_base3, "ds_base3")]:
                val = ds.get_value(date)
                assert val is not None and not val.is_empty(), f"{name} should auto-complete for {date}"


class TestDatasetDependency:
    """测试数据集依赖关系"""

    def test_dependency(self, ds_target):
        """测试数据集依赖关系和自动补全功能"""
        date = "2020-01-02"
        val = ds_target.get_value(date)

        # 验证 ds_target 正确获取了 ds_base 的数据并做了转换
        assert val is not None, "ds_target should return a result"
        assert not val.is_empty(), "ds_target result should not be empty"
        assert val["value"][0] == 2.0, "ds_target should multiply ds_base value by 2"
        assert val["asset"][0] == "000001", "asset should be preserved from ds_base"
        assert val["date"][0] == date, f"date should be {date}"

    def test_get_history_auto_complete(self, ds_target, ds_base):
        """测试 get_history 是否会自动补全依赖数据集"""
        dates = ["2020-01-02", "2020-01-03", "2020-01-06"]
        result = ds_target.get_history(dates)

        # 验证返回结果不为空
        assert result is not None, "get_history should return a result"

        # 验证 ds_base 的历史数据被自动补全
        for date in dates:
            base_val = ds_base.get_value(date)
            assert base_val is not None, f"ds_base should auto-complete for {date}"
            assert not base_val.is_empty(), f"ds_base should have data for {date}"

        # 验证返回数据的行数与日期数一致
        if hasattr(result, "collect"):
            result = result.collect()
        assert result is not None and not result.is_empty(), "get_history result should not be empty"
    