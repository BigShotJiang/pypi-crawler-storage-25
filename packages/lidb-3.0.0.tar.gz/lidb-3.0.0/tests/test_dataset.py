"""测试 dataset 模块的公共函数"""
import pytest
from lidb.dataset import _resolve_update_time, Dataset


class MockDataset:
    """用于测试 _resolve_update_time 的 mock"""
    def __init__(self, update_time: str):
        self.update_time = update_time


M = MockDataset  # shorthand


class TestResolveUpdateTime:
    """测试 _resolve_update_time 规则"""

    def test_no_depends_returns_as_is(self):
        """无依赖时返回原值"""
        assert _resolve_update_time("", []) == ""
        assert _resolve_update_time("08:00:00", []) == "08:00:00"
        assert _resolve_update_time("15:00:00", []) == "15:00:00"

    def test_midday_is_cleared(self):
        """09:30~15:00 视为实时"""
        assert _resolve_update_time("10:00:00", []) == ""
        assert _resolve_update_time("12:00:00", []) == ""

    def test_boundary_09_30(self):
        """09:30:00 不被清除（盘前）"""
        assert _resolve_update_time("09:30:00", []) == "09:30:00"

    def test_boundary_15_00(self):
        """15:00:00 不被清除（盘后）"""
        assert _resolve_update_time("15:00:00", []) == "15:00:00"

    def test_with_realtime_dep_clears_premarket(self):
        """有实时依赖时盘前时间被修复为空"""
        result = _resolve_update_time("08:00:00", [M("")])
        assert result == ""

    def test_with_realtime_dep_keeps_postmarket(self):
        """有实时依赖时盘后时间保留"""
        result = _resolve_update_time("15:00:00", [M("")])
        assert result == "15:00:00"

    def test_with_postmarket_dep(self):
        """有盘后依赖且自身为空时用依赖的最大值"""
        result = _resolve_update_time("", [M("15:00:00")])
        assert result == "15:00:00"

    def test_both_premarket_matches(self):
        """自身和依赖都是盘前时取 max"""
        result = _resolve_update_time("08:00:00", [M("09:00:00")])
        assert result == "09:00:00"
