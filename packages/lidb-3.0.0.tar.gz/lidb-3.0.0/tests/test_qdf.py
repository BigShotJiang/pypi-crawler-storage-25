"""测试 QDF 模块"""
import polars as pl
import pytest
from lidb.qdf.expr import Expr
from lidb.qdf.errors import ParseError
from lidb.qdf.qdf import QDF


class TestExpr:
    """测试 Expr 表达式解析"""

    def test_parse_simple_column(self):
        """解析简单列名"""
        e = Expr("close")
        assert e.alias == "close"
        assert e.fn_name == ""

    def test_parse_with_alias(self):
        """解析带别名的表达式"""
        e = Expr("close as c")
        assert e.alias == "c"

    def test_parse_function(self):
        """解析函数调用"""
        e = Expr("ts_mean(close, 5) as ma5")
        assert e.alias == "ma5"
        assert e.fn_name == "ts_mean"

    def test_parse_invalid_expr(self):
        """无效表达式应抛 ParseError"""
        with pytest.raises(ParseError):
            Expr("((((")

    def test_parse_arithmetic(self):
        """解析算术表达式"""
        e = Expr("close + high as sum")
        assert e.fn_name == "add"

    def test_n_args(self):
        """n_args 返回参数数量"""
        e = Expr("ts_mean(close, 5) as ma")
        assert e.n_args == 2

    def test_depth(self):
        """depth 返回嵌套深度"""
        e = Expr("1+2")
        assert e.depth >= 1


class TestQDFBasic:
    """测试 QDF 基础功能"""

    @pytest.fixture
    def sample_qdf(self):
        data = pl.DataFrame({
            "date": ["2024-01-01", "2024-01-02"],
            "asset": ["000001", "000001"],
            "close": [10.0, 11.0],
            "high": [11.0, 12.0],
        })
        return QDF(data, index=("date", "asset"))

    def test_sql_simple_column(self, sample_qdf):
        """查询已有列"""
        result = sample_qdf.sql("close", show_progress=False)
        assert "close" in result.columns

    def test_sql_alias(self, sample_qdf):
        """查询带别名"""
        result = sample_qdf.sql("close * 2 as double_close", show_progress=False)
        assert "double_close" in result.columns

    def test_sql_failed_exprs_property(self, sample_qdf):
        """无效表达式记录到 failed 列表"""
        sample_qdf.sql("close as", show_progress=False)
        assert len(sample_qdf.failed) >= 1, "无效表达式应被记录到 failed"

    def test_sql_multiple_exprs(self, sample_qdf):
        """多个表达式"""
        result = sample_qdf.sql("close", "high", show_progress=False)
        assert "close" in result.columns
        assert "high" in result.columns


class TestQDFCache:
    """测试 QDF 缓存行为"""

    @pytest.fixture
    def sample_qdf(self):
        data = pl.DataFrame({
            "date": ["2024-01-01", "2024-01-01"],
            "asset": ["000001", "000002"],
            "close": [10.0, 20.0],
        })
        return QDF(data, index=("date", "asset"))

    def test_cache_works(self, sample_qdf):
        """启用缓存后重复查询不报错"""
        sample_qdf.sql("close * 2 as d1", cache=True, show_progress=False)
        # 第二次查询应命中缓存
        result = sample_qdf.sql("close * 2 as d1", cache=True, show_progress=False)
        assert "d1" in result.columns
