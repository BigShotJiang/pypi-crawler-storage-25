# 表管理

表模块提供单表单数据存储（无分区），支持全量更新和增量更新两种模式。

## 类

### `Table`

用于管理数据库表的类。单表单数据——所有数据存储在同一个目录下，不支持分区。

#### `__init__(self, fn: Callable[..., pl.DataFrame], tb: str, update_time: str, mode: TableMode = TableMode.F)`

初始化一个新表。

**参数**:
- `fn`: 数据获取函数
- `tb`: 表名（存储路径）
- `update_time`: 数据更新时间（如 `"15:00:00"`）
- `mode`: 更新模式（`TableMode.F` 全量覆盖 / `TableMode.I` 增量追加）

#### `get_value(self, date: str, eager: bool = True) -> pl.DataFrame | pl.LazyFrame`

获取数据。若数据未更新则抛出 `RuntimeError`（替代原有的 `sys.exit()`）。

#### `update(self, verbose: bool = False)`

更新数据。根据当前时间与 `update_time` 判断是否需要更新。

### `TableMode`

更新模式的枚举。
- `TableMode.F`: 全量更新（`"full"`）— 覆盖旧数据
- `TableMode.I`: 增量更新（`"increment"`）— 追加新数据

## 使用方法

```python
from lidb import Table, TableMode
import polars as pl

def fetch_data(date: str) -> pl.DataFrame:
    return pl.DataFrame({"date": [date], "value": [1]})

table = Table(fn=fetch_data, tb="my_table", update_time="15:00:00")
table.update()
data = table.get_value("2024-01-01")
```
