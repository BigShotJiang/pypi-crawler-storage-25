# 初始化和配置

init模块提供 lidb 库的初始化函数和配置设置。配置读取使用 `dynaconf`，`get_settings()` 由 `@cache` 装饰，首次调用后结果被缓存。

配置创建逻辑提取为独立函数 `_ensure_config_exists()`，使初始化行为可测试。

## 函数和变量

### `NAME`

库名称: "lidb"

### `DB_PATH`

数据库存储路径。模块级初始化时从配置文件 `global.path` 覆盖。

### `CONFIG_PATH`

配置文件路径：`~/.config/lidb/settings.toml`

### `get_settings()`

获取当前库设置。通过 `@cache` 缓存，首次调用后不重复读文件。

**返回**:
- 配置设置对象

## 使用方法

```python
from lidb import NAME, DB_PATH, CONFIG_PATH, get_settings

print(f"库名称: {NAME}")
print(f"数据库路径: {DB_PATH}")

settings = get_settings()
```
