# lidb 质量修复执行计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 按风险等级修复 lidb 代码库中已识别的 CRITICAL→HIGH→MEDIUM 质量缺陷，补全测试盲区

**Architecture:** 在不动核心抽象（Dataset 依赖追踪、QDF 表达式引擎、parquet 分区存储）的前提下，消除 `sys.exit()` 等危险模式、分离副作用、提取公共逻辑为独立函数、拆分长文件。所有改动遵循 TDD 模式：先写测试，再改实现。

**Tech Stack:** Python 3.12+, pytest, polars

**设计文档:** `~/.gstack/projects/lidb/link-yundi-main-design-quality-fix-20260510.md`

---

## 文件总览

### 修改的文件
| 文件 | 改动 |
|------|------|
| `lidb/dataset.py` | sys.exit() → RuntimeError, 提取 update_time 逻辑 |
| `lidb/table.py` | sys.exit() → RuntimeError |
| `lidb/parse.py` | 分离文件删除逻辑为独立函数 |
| `lidb/init.py` | 提取配置创建函数 `_ensure_config_exists` |
| `lidb/qdf/qdf.py` | 错误表达式可见性改进 |

### 新建的文件
| 文件 | 职责 |
|------|------|
| `lidb/loader.py` | 从 dataset.py 拆分：`load_ds()`, `loader()`, `DataLoader` |

### 新建/修改的测试文件
| 文件 | 覆盖目标 |
|------|---------|
| `tests/test_table.py` | 修改现有测试，验证异常行为 |
| `tests/test_parse.py` | 修改现有测试，验证 cleanup_empty_files |
| `tests/test_init.py` | 新建：验证 import 无 IO 副作用 |
| `tests/test_loader.py` | 新建：load_ds、DataLoader |
| `tests/test_data_service.py` | 新建：DataService 生命周期 |
| `tests/test_qdf.py` | 新建：Expr 解析、依赖图、错误隔离 |

---

### Task 1: 替换 table.py 中的 sys.exit()

**Files:**
- Modify: `lidb/table.py:106`
- Modify: `tests/test_table.py` (追加测试)

- [ ] **Step 1: 确认当前代码**

当前 `table.py:106`:
```python
def get_value(self, date: str, eager: bool = True) -> pl.DataFrame | pl.LazyFrame:
    if self._need_update(date):
        self._log("Update first plz.", "warning")
        sys.exit()
```

- [ ] **Step 2: 追加测试**

在 `tests/test_table.py` 追加：
```python
def test_get_value_raises_on_missing_update(self):
    """未更新时调用 get_value 应抛 RuntimeError 而非 exit"""
    def fn(date: str) -> pl.DataFrame:
        return pl.DataFrame({"date": [date]})

    table = Table(fn=fn, tb="test/nonexistent", update_time="09:30")

    with pytest.raises(RuntimeError, match="必须先调用 update"):
        table.get_value("2024-01-01")
```

- [ ] **Step 3: 运行确认新测试 FAIL**

Run: `python -m pytest tests/test_table.py::TestTable::test_get_value_raises_on_missing_update -v`
Expected: FAIL — still calls sys.exit()

- [ ] **Step 4: 修改 table.py**

将 `import sys` 移除（检查是否其他地方用到），将 `sys.exit()` 替换：
```python
def get_value(self, date: str, eager: bool = True) -> pl.DataFrame | pl.LazyFrame:
    if self._need_update(date):
        raise RuntimeError(f"{self.tb}: 数据未更新，必须先在 update() 后调用")
```

- [ ] **Step 5: 确认测试 PASS**

Run: `python -m pytest tests/test_table.py::TestTable -v`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add lidb/table.py tests/test_table.py
git commit -m "fix(table): 替换 sys.exit() 为 RuntimeError"
```

---

### Task 2: 替换 dataset.py 中的 sys.exit()

**Files:**
- Modify: `lidb/dataset.py:189-191`

- [ ] **Step 1: 修改 dataset.py**

删除 `import sys`（确认没有其他地方使用），将：
```python
if not has_rt:
    warnings.warn(f"{self.data_name}:{self.save_path} 更新时间推断错误", UserWarning)
    sys.exit()
```
替换为：
```python
if not has_rt:
    raise RuntimeError(f"{self.data_name}:{self.save_path} 更新时间推断错误")
```

> 注意：此分支是防御性死代码（几乎不可达），替换为 raise 是安全兜底。不写专门测试——真正的测试在 `_resolve_update_time` 纯函数测试中覆盖。

- [ ] **Step 2: 验证现有测试仍通过**

Run: `python -m pytest tests/test_dataset_dependency.py -v`
Expected: PASS

- [ ] **Step 3: Commit**

```bash
git add lidb/dataset.py
git commit -m "fix(dataset): 替换 sys.exit() 为 RuntimeError"
```

---

### Task 3: 分离 parse.py 中的文件删除副作用

**Files:**
- Modify: `lidb/parse.py`
- Modify: `tests/test_parse.py`

- [ ] **Step 1: 在 parse.py 末尾追加独立函数**

```python
def cleanup_empty_files(root_path: Path | str, file_pattern: str = "*.parquet"):
    """删除指定路径下所有空文件，返回删除数量"""
    if isinstance(root_path, str):
        root_path = Path(root_path)
    count = 0
    for file_path in root_path.rglob(file_pattern):
        if file_path.stat().st_size == 0:
            file_path.unlink()
            count += 1
    return count
```

- [ ] **Step 2: 修改 `parse_hive_partition_structure`**

删除第 89-92 行的文件删除逻辑：
```python
# 删除这部分：
if file_path.stat().st_size == 0:
    # 删除
    file_path.unlink()
    continue
```
替换为：
```python
if file_path.stat().st_size == 0:
    continue  # 跳过空文件，不再在这里删除
```

- [ ] **Step 3: 在 `dataset.py get_value()` 中复用 `cleanup_empty_files`**

将 `get_value()` 中第 274-278 行的手动空文件删除替换为调用 `cleanup_empty_files`：
```python
# 替换：
# for file_path in search_path.rglob("*.parquet"):
#     if file_path.stat().st_size == 0:
#         logger.warning(f"{file_path}: Deleting empty file.")
#         file_path.unlink()
# 为：
from .parse import cleanup_empty_files
cleaned = cleanup_empty_files(search_path)
if cleaned:
    logger.warning(f"{search_path}: Cleaned {cleaned} empty files.")
```

在文件顶部加上 `from .parse import cleanup_empty_files` 导入。

- [ ] **Step 5: 在 `__init__.py` 导出 `cleanup_empty_files`**

```python
from .parse import parse_hive_partition_structure, cleanup_empty_files
```

- [ ] **Step 6: 追加测试**

在 `tests/test_parse.py` 追加：
```python
def test_cleanup_empty_files_removes_and_counts(self):
    """cleanup_empty_files 删除空文件并返回计数"""
    with tempfile.TemporaryDirectory() as tmpdir:
        base = Path(tmpdir)
        empty_file = base / "date=2024-01-01" / "empty.parquet"
        empty_file.parent.mkdir(parents=True)
        empty_file.touch()

        normal_file = base / "date=2024-01-02" / "data.parquet"
        normal_file.parent.mkdir(parents=True)
        normal_file.write_bytes(b"data")

        count = cleanup_empty_files(tmpdir)
        assert count == 1
        assert not empty_file.exists()
        assert normal_file.exists()

def test_parse_no_longer_deletes_files(self):
    """parse_hive_partition_structure 不再删除空文件"""
    with tempfile.TemporaryDirectory() as tmpdir:
        base = Path(tmpdir)
        empty_file = base / "date=2024-01-01" / "empty.parquet"
        empty_file.parent.mkdir(parents=True)
        empty_file.touch()

        parse_hive_partition_structure(tmpdir)
        # parse 后空文件应该仍然存在
        assert empty_file.exists(), "parse 不应删除文件"
```

- [ ] **Step 7: 运行所有 parse 测试**

Run: `python -m pytest tests/test_parse.py -v`
Expected: PASS

- [ ] **Step 8: Commit**

```bash
git add lidb/parse.py lidb/dataset.py tests/test_parse.py
git commit -m "fix(parse): 分离文件删除副作用为独立 cleanup_empty_files 函数"
```

---

### Task 4: 提取配置创建函数以提高可测试性

**Files:**
- Modify: `lidb/init.py`
- Create: `tests/test_init.py`

- [ ] **Step 1: 修改 init.py**

将配置文件的创建逻辑从模块级内联移入独立的 `_ensure_config_exists()` 函数：

```python
# 删除模块级自动创建代码（第 20-28 行）：
# if not CONFIG_PATH.exists():
#     try:
#         ...
#     ...

def get_settings():
    _ensure_config_exists()
    try:
        return Dynaconf(settings_files=[CONFIG_PATH])
    except Exception as e:
        logger.error(f"Read settings file failed: {e}")
        return {}

def _ensure_config_exists():
    """确保配置文件存在，不存在则创建"""
    if CONFIG_PATH.exists():
        return
    try:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        logger.error(f"Failed to create settings file: {e}")
    with open(CONFIG_PATH, "w") as f:
        template_content = f'[GLOBAL]\npath="{DB_PATH}"\n\n[POLARS]\nmax_threads=32\n'
        f.write(template_content)
    logger.info(f"Settings file created: {CONFIG_PATH}")
```

> 保留模块级的 `_settiings = get_settings()` 调用——`get_settings()` 现在通过 `_ensure_config_exists()` 内聚了配置创建逻辑，可独立测试。完全消除 import 时 IO 需要更大的重构（延迟所有配置初始化），本次不包含。

- [ ] **Step 2: 创建 `tests/test_init.py`**

```python
"""测试 init 模块的延迟初始化行为"""
from lidb.init import DB_PATH, CONFIG_PATH, get_settings


def test_constants_defined_without_io():
    """模块级常量定义不需要 IO"""
    assert DB_PATH is not None
    assert CONFIG_PATH is not None


def test_get_settings_returns_dict():
    """get_settings 返回有效配置"""
    settings = get_settings()
    assert settings is not None
```

- [ ] **Step 3: 运行测试**

Run: `python -m pytest tests/test_init.py -v`
Expected: PASS

- [ ] **Step 4: Commit**

```bash
git add lidb/init.py tests/test_init.py
git commit -m "refactor(init): 提取 _ensure_config_exists 以提高配置初始化的可测试性"
```

---

### Task 5: 提取 update_time 解析逻辑为独立函数

**Files:**
- Modify: `lidb/dataset.py`
- Modify: `tests/test_dataset.py`（新建）

- [ ] **Step 1: 在 dataset.py 中编写纯函数**

在 `Dataset` 类之外新增：
```python
def _resolve_update_time(
    update_time: str,
    depends: list[Dataset],
) -> str:
    """
    根据当前 Dataset 和底层依赖解析最终的 update_time。

    规则:
    - 09:30~15:00 之间的时间视为实时（空字符串）
    - 有实时依赖时，当前 update_time <= 09:30 会被修复为空
    - 有盘后依赖 (>=15:00) 时，当前如果为空会被修复为依赖的最大值
    """
    if "09:30:00" < update_time < "15:00:00":
        update_time = ""

    if not depends:
        return update_time

    has_rt = any(not ds.update_time for ds in depends)
    dep_uts = [ds.update_time for ds in depends if ds.update_time]
    max_ut = max(dep_uts) if dep_uts else ""

    if not update_time:
        if max_ut >= "15:00:00":
            update_time = max_ut
        return update_time

    if not max_ut:
        if update_time <= "09:30:00":
            update_time = ""
        return update_time

    if not has_rt:
        update_time = max(max_ut, update_time)
    elif max_ut >= "15:00:00":
        update_time = max(max_ut, update_time)
    elif update_time <= "09:30:00":
        update_time = ""

    return update_time
```

- [ ] **Step 2: 在 Dataset.__init__ 中调用该函数**

替换 `__init__` 中第 164~201 行：
```python
# 替换全部：
# if "09:30:00" < update_time < "15:00:00":
#     update_time = ""
# ...（整个 update_time 块）

# 改为：
self.update_time = _resolve_update_time(update_time, self._depends)
```

- [ ] **Step 3: 创建 `tests/test_dataset.py`**

```python
"""测试 dataset 模块的公共函数"""
import pytest
from lidb.dataset import _resolve_update_time, Dataset


class MockDataset:
    """用于测试 _resolve_update_time 的 mock"""
    def __init__(self, update_time: str):
        self.update_time = update_time


M = MockDataset  # shorthand


class TestResolveUpdateTime:
    """测试 _resolve_update_time 规则"""

    def test_no_depends_returns_as_is(self):
        """无依赖时返回原值"""
        assert _resolve_update_time("", []) == ""
        assert _resolve_update_time("08:00:00", []) == "08:00:00"
        assert _resolve_update_time("15:00:00", []) == "15:00:00"

    def test_midday_is_cleared(self):
        """09:30~15:00 视为实时"""
        assert _resolve_update_time("10:00:00", []) == ""
        assert _resolve_update_time("12:00:00", []) == ""

    def test_boundary_09_30(self):
        """09:30:00 不被清除（盘前）"""
        assert _resolve_update_time("09:30:00", []) == "09:30:00"

    def test_boundary_15_00(self):
        """15:00:00 不被清除（盘后）"""
        assert _resolve_update_time("15:00:00", []) == "15:00:00"

    def test_with_realtime_dep_clears_premarket(self):
        """有实时依赖时盘前时间被修复为空"""
        result = _resolve_update_time("08:00:00", [M("")])
        assert result == ""

    def test_with_realtime_dep_keeps_postmarket(self):
        """有实时依赖时盘后时间保留"""
        result = _resolve_update_time("15:00:00", [M("")])
        assert result == "15:00:00"

    def test_with_postmarket_dep(self):
        """有盘后依赖且自身为空时用依赖的最大值"""
        result = _resolve_update_time("", [M("15:00:00")])
        assert result == "15:00:00"

    def test_both_premarket_matches(self):
        """自身和依赖都是盘前时取 max"""
        result = _resolve_update_time("08:00:00", [M("09:00:00")])
        assert result == "09:00:00"
```

- [ ] **Step 4: 运行测试**

Run: `python -m pytest tests/test_dataset.py -v`
Expected: PASS

- [ ] **Step 5: 验证现有 Dataset 测试通过**

Run: `python -m pytest tests/test_dataset_dependency.py -v`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add lidb/dataset.py tests/test_dataset.py
git commit -m "refactor(dataset): 提取 update_time 解析为纯函数 _resolve_update_time"
```

---

### Task 6: 新建 DataService 测试

**Files:**
- Create: `tests/test_data_service.py`

- [ ] **Step 1: 创建测试文件**

```python
"""测试 DataService"""
import time
import polars as pl
from lidb.svc.data import DataService


class TestDataService:
    """测试 DataService 生命周期"""

    def test_initial_state(self):
        """新建的 DataService 不应在运行中"""
        ds = DataService()
        assert ds.is_running is False

    def test_put_get_roundtrip(self):
        """put_data 后 get_data 能取回相同数据"""
        ds = DataService()
        data = {"test": pl.DataFrame({"a": [1, 2, 3]})}
        ds.put_data("key1", data)
        key, result, is_empty = ds.get_data()
        assert key == "key1"
        assert result["test"].to_dict(as_series=False) == {"a": [1, 2, 3]}
        assert is_empty is False

    def test_get_empty_returns_empty_flag(self):
        """空队列时 get_data 返回 empty 标志"""
        ds = DataService()
        key, data, is_empty = ds.get_data()
        assert is_empty is True
        assert data is None

    def test_stop_idempotent(self):
        """多次 stop 不应报错"""
        ds = DataService()
        ds.stop()  # 未启动时 stop
        ds.stop()  # 再次 stop
        assert ds.is_running is False

    # 注意：Queue.put() 在队列满时会永久阻塞，不自动淘汰。
    # 因此不写 "超过容量自动淘汰" 测试——Queue 的行为就是阻塞而非淘汰。
```

- [ ] **Step 2: 运行测试**

Run: `python -m pytest tests/test_data_service.py -v`
Expected: PASS

- [ ] **Step 3: Commit**

```bash
git add tests/test_data_service.py
git commit -m "test: 新增 DataService 测试覆盖"
```

---

### Task 7: 新建 QDF 测试

**Files:**
- Create: `tests/test_qdf.py`

- [ ] **Step 1: 创建测试文件**

```python
"""测试 QDF 模块"""
import polars as pl
import pytest
from lidb.qdf.expr import Expr
from lidb.qdf.errors import ParseError, FailError
from lidb.qdf.qdf import QDF


class TestExpr:
    """测试 Expr 表达式解析"""

    def test_parse_simple_column(self):
        """解析简单列名"""
        e = Expr("close")
        assert e.alias == "close"
        assert e.fn_name is None

    def test_parse_with_alias(self):
        """解析带别名的表达式"""
        e = Expr("close as c")
        assert e.alias == "c"

    def test_parse_function(self):
        """解析函数调用"""
        e = Expr("ts_mean(close, 5) as ma5")
        assert e.alias == "ma5"
        assert e.fn_name == "ts_mean"

    def test_parse_invalid_expr(self):
        """无效表达式应抛 ParseError"""
        with pytest.raises(ParseError):
            Expr("((((")

    def test_parse_arithmetic(self):
        """解析算术表达式"""
        e = Expr("close + high as sum")
        assert e.fn_name == "add"

    def test_n_args(self):
        """n_args 返回参数数量"""
        e = Expr("ts_mean(close, 5) as ma")
        assert e.n_args == 2

    def test_depth(self):
        """depth 返回嵌套深度"""
        e = Expr("1+2")
        assert e.depth >= 1


class TestQDFBasic:
    """测试 QDF 基础功能"""

    @pytest.fixture
    def sample_qdf(self):
        data = pl.DataFrame({
            "date": ["2024-01-01", "2024-01-02"],
            "asset": ["000001", "000001"],
            "close": [10.0, 11.0],
            "high": [11.0, 12.0],
        })
        return QDF(data, index=("date", "asset"))

    def test_sql_simple_column(self, sample_qdf):
        """查询已有列"""
        result = sample_qdf.sql("close", show_progress=False)
        assert "close" in result.columns

    def test_sql_alias(self, sample_qdf):
        """查询带别名"""
        result = sample_qdf.sql("close * 2 as double_close", show_progress=False)
        assert "double_close" in result.columns

    def test_sql_failed_exprs_property(self, sample_qdf):
        """无效表达式记录到 failed 列表"""
        sample_qdf.sql("close as", show_progress=False)
        # 无效表达式应导致 failed 列表非空
        assert len(sample_qdf.failed) >= 1, "无效表达式应被记录到 failed"

    def test_sql_multiple_exprs(self, sample_qdf):
        """多个表达式"""
        result = sample_qdf.sql("close", "high", show_progress=False)
        assert "close" in result.columns
        assert "high" in result.columns


class TestQDFCache:
    """测试 QDF 缓存行为"""

    @pytest.fixture
    def sample_qdf(self):
        data = pl.DataFrame({
            "date": ["2024-01-01"],
            "asset": ["000001"],
            "close": [10.0],
        })
        return QDF(data, index=("date", "asset"))

    def test_cache_speed(self, sample_qdf):
        """启用缓存后重复查询应更快"""
        import time
        sample_qdf.sql("close * 2 as d1", cache=True, show_progress=False)
        t0 = time.time()
        sample_qdf.sql("close * 2 as d1", cache=True, show_progress=False)
        t1 = time.time()
        # 至少不慢于首次（缓存命中应比首次快或持平）
        assert t1 - t0 < 1.0  # 防超时断言
```

- [ ] **Step 2: 运行测试**

Run: `python -m pytest tests/test_qdf.py -v`
Expected: PASS

- [ ] **Step 3: Commit**

```bash
git add tests/test_qdf.py
git commit -m "test: 新增 QDF 表达式解析和基础查询测试覆盖"
```

---

### Task 8: 新建 loader.py 并添加测试

**Files:**
- Create: `lidb/loader.py`
- Modify: `lidb/dataset.py`（移除导出函数）
- Modify: `lidb/__init__.py`（更新 import）
- Create: `tests/test_loader.py`

- [ ] **Step 1: 分析 dataset.py 中需要拆分的函数**

需要移出 `dataset.py` 的函数：
- `loader()` — 单数据集加载器
- `load_ds()` — 多数据集并发加载
- `DataLoader` — 数据加载服务类

保留在 `dataset.py` 中的函数：
- `Dataset` 类（及其所有方法）
- `complete_data()` — 与 Dataset 内部紧密耦合
- `_resolve_update_time()` — 刚提取的函数
- `DataLoader` — 拆出
- `InstrumentType` — 枚举

- [ ] **Step 2: 创建 `lidb/loader.py`**

```python
# Copyright (c) ZhangYundi.
# Licensed under the MIT License.
# Created on 2026/05/10
# Description: 数据加载编排——load_ds / loader / DataLoader

from __future__ import annotations

from collections import defaultdict

import polars as pl
import polars.selectors as cs
import xcals
import ygo

from .dataset import Dataset


def loader(data_name: str,
           ds: Dataset,
           date_list: list[str],
           prev_date_list: list[str],
           prev_date_mapping: dict[str, str],
           time: str,
           process_time: bool,
           avoid_future: bool = True,
           **constraints) -> pl.LazyFrame:
    """单数据集加载器"""
    if avoid_future:
        if time:
            if time < ds.update_time:
                if len(prev_date_list) > 1:
                    lf = ds.get_history(prev_date_list, eager=False, **constraints)
                else:
                    lf = ds.get_value(prev_date_list[0], eager=False, **constraints)
            else:
                if len(date_list) > 1:
                    lf = ds.get_history(date_list, eager=False, **constraints)
                else:
                    lf = ds.get_value(date_list[0], eager=False, **constraints)
        else:
            if ds.update_time > "09:30:00":
                if len(prev_date_list) > 1:
                    lf = ds.get_history(prev_date_list, eager=False, **constraints)
                else:
                    lf = ds.get_value(prev_date_list[0], eager=False, **constraints)
            else:
                if len(date_list) > 1:
                    lf = ds.get_history(date_list, eager=False, **constraints)
                else:
                    lf = ds.get_value(date_list[0], eager=False, **constraints)
    else:
        all_date_list = [prev_date_list[0], ] + date_list
        lf = ds.get_history(all_date_list, eager=False, **constraints)

    schema = lf.collect_schema()
    include_time = schema.get("time") is not None
    if process_time and time:
        if include_time:
            lf = lf.filter(time=time)
        else:
            lf = lf.with_columns(time=pl.lit(time))
    if (time < ds.update_time) & avoid_future:
        lf = lf.with_columns(date=pl.col("date").replace(prev_date_mapping))
    keep = {"date", "time", "asset"}
    if ds._name:
        columns = lf.collect_schema().names()
        rename_cols = set(columns).difference(keep)
        if len(rename_cols) > 1:
            lf = lf.rename({k: f"{ds._name}.{k}" for k in rename_cols})
        else:
            lf = lf.rename({k: ds._name for k in rename_cols})
    return data_name, lf


def load_ds(ds_conf: dict[str, list[Dataset]],
            beg_date: str,
            end_date: str,
            times: list[str],
            n_jobs: int = 11,
            backend: str = "loky",
            show_progress: bool = True,
            eager: bool = False,
            process_time: bool = True,
            avoid_future: bool = True,
            **constraints) -> dict[str, pl.DataFrame | pl.LazyFrame]:
    """多数据集并发加载"""
    if beg_date > end_date:
        raise ValueError("beg_date must be less than end_date")
    date_list = xcals.get_tradingdays(beg_date, end_date)
    beg_date, end_date = date_list[0], date_list[-1]
    prev_date_list = xcals.get_tradingdays(xcals.shift_tradeday(beg_date, -1),
                                           xcals.shift_tradeday(end_date, -1))
    prev_date_mapping = {prev_date: date_list[i] for i, prev_date in enumerate(prev_date_list)}
    results = defaultdict(list)
    index = ("date", "time", "asset")
    _index = ("date", "asset")
    with ygo.pool(n_jobs=n_jobs,
                  backend=backend,
                  show_progress=show_progress) as go:
        for data_name, ds_list in ds_conf.items():
            for ds in ds_list:
                _data_name = f"{data_name}:{ds.tb}"
                if ds._name:
                    _data_name += f".alias({ds._name})"
                for time in times:
                    go.submit(loader,
                              job_name="Loading",
                              postfix=data_name, )(data_name=_data_name,
                                                   ds=ds,
                                                   date_list=date_list,
                                                   prev_date_list=prev_date_list,
                                                   prev_date_mapping=prev_date_mapping,
                                                   time=time,
                                                   process_time=process_time,
                                                   avoid_future=avoid_future,
                                                   **constraints)
        for name, lf in go.do():
            results[name].append(lf)
    _LFs_with_time = {}
    _LFs_without_time = {}
    for name, lfList in results.items():
        lf = pl.concat(lfList)
        if "time" not in lf.collect_schema().names():
            _LFs_without_time[name] = lf
        else:
            _LFs_with_time[name] = lf
    LFs_with_time = defaultdict(list)
    LFs_without_time = defaultdict(list)
    for name, lf in _LFs_with_time.items():
        dn, _ = name.split(":")
        LFs_with_time[dn].append(lf)
    for name, lf in _LFs_without_time.items():
        dn, _ = name.split(":")
        LFs_without_time[dn].append(lf)
    LFs_with_time = {
        name: (pl.concat(lfList, how="align")
               .sort(index)
               .select(*index, cs.exclude(index)))
        for name, lfList in LFs_with_time.items()}
    LFs_without_time = {
        name: (pl.concat(lfList, how="align")
               .sort(_index)
               .select(*_index, cs.exclude(_index)))
        for name, lfList in LFs_without_time.items()}
    dns = list(LFs_with_time.keys()) if LFs_with_time else list(LFs_without_time.keys())
    LFs = dict()
    for dn in dns:
        _lf_with_time = LFs_with_time.get(dn)
        _lf_without_time = LFs_without_time.get(dn)
        if _lf_with_time is not None:
            LFs[dn] = _lf_with_time
            if _lf_without_time is not None:
                LFs[dn] = LFs[dn].join(_lf_without_time, on=["date", "asset"], how="left")
        else:
            LFs[dn] = _lf_without_time
    if not eager:
        return LFs
    return {name: lf.collect() for name, lf in LFs.items()}


class DataLoader:
    """数据加载服务"""

    def __init__(self, name: str):
        self._name = name
        self._index: tuple[str] = ("date", "time", "asset")
        self._df: pl.LazyFrame | pl.DataFrame = None
        self._all_df: pl.LazyFrame | pl.DataFrame = None

    def get(self,
            ds_list: list[Dataset],
            beg_date: str,
            end_date: str,
            times: list[str],
            avoid_future: bool = True,
            columns: list[str] | None = None,
            eager: bool = False,
            n_jobs: int = -1,
            backend: str = "loky",
            **constraints):
        lf = load_ds(ds_conf={self._name: ds_list},
                     beg_date=beg_date,
                     end_date=end_date,
                     n_jobs=n_jobs,
                     backend=backend,
                     times=times,
                     avoid_future=avoid_future,
                     eager=eager,
                     process_time=True,
                     **constraints)
        self._df = lf[self._name]
        if columns:
            self._df = self._df.select("date", "time", "asset", *columns)
        self.add_data(self._df)

    @property
    def name(self) -> str:
        return self._name

    @property
    def data(self) -> pl.DataFrame | None:
        if isinstance(self._df, pl.LazyFrame):
            self._df = self._df.collect()
        return self._df

    @property
    def all_data(self) -> pl.DataFrame | None:
        if isinstance(self._all_df, pl.LazyFrame):
            self._all_df = self._all_df.collect()
        return self._all_df

    def add_data(self, df: pl.DataFrame | pl.LazyFrame):
        if self._all_df is None:
            self._all_df = df
        else:
            self._all_df = pl.concat([self._all_df.lazy(), df.lazy()], how="align").sort(self._index)
```

- [ ] **Step 3: 修改 `lidb/dataset.py`**

从 `dataset.py` 中删除：
1. `loader()` 函数（第 487~562 行）
2. `load_ds()` 函数（第 565~689 行）  
3. `DataLoader` 类（第 692~769 行）
4. `from collections import defaultdict`（移到 loader.py）
5. `import csv`（如果仅被 loader 使用）

在 `dataset.py` 中，`load_ds` 只在 `get_dependsPIT()` 内部被调用。使用惰性导入避免循环引用：
```python
def get_dependsPIT(self, ...):
    from .loader import load_ds  # 惰性导入，避免循环引用
    ...
```
删除 `dataset.py` 顶部的 `from collections import defaultdict`（仅在 loader 中使用）。

- [ ] **Step 4: 修改 `lidb/__init__.py`**

```python
# 替换：
# from .dataset import Dataset, DataLoader
# 为：
from .dataset import Dataset
from .loader import DataLoader
```

- [ ] **Step 5: 创建 `tests/test_loader.py`**

```python
"""测试 loader 模块"""
import polars as pl
import pytest
from lidb.loader import load_ds
from lidb.dataset import Dataset


class TestLoadDs:
    """测试 load_ds"""

    def test_beg_date_gt_end_date_raises(self):
        """开始日期大于结束日期时抛出 ValueError"""
        with pytest.raises(ValueError, match="beg_date must be less than end_date"):
            load_ds(
                ds_conf={"test": []},
                beg_date="2024-01-05",
                end_date="2024-01-01",
                times=[""],
                show_progress=False,
            )

    def test_empty_ds_conf_returns_empty(self):
        """空配置时返回空字典"""
        result = load_ds(
            ds_conf={},
            beg_date="2024-01-01",
            end_date="2024-01-03",
            times=[""],
            show_progress=False,
        )
        assert result == {}

    def test_load_ds_returns_lazy_by_default(self):
        """默认返回 LazyFrame"""
        result = load_ds(
            ds_conf={"test": []},
            beg_date="2024-01-01",
            end_date="2024-01-01",
            times=[""],
            show_progress=False,
        )
        # 空 ds_list 不会触发实际数据加载，但返回应为 dict
        assert isinstance(result, dict)
```

- [ ] **Step 6: 运行测试**

Run: `python -m pytest tests/test_loader.py -v`
Expected: PASS

Run: `python -m pytest tests/test_dataset.py tests/test_dataset_dependency.py tests/test_decorator.py -v`
Expected: PASS（确保拆后不破坏现有测试）

- [ ] **Step 7: Commit**

```bash
git add lidb/loader.py lidb/dataset.py lidb/__init__.py tests/test_loader.py
git commit -m "refactor: 从 dataset.py 拆分 loader 模块（load_ds/DataLoader）"
```

---

### Task 9: 全面回归测试

**Files:** 全量测试

- [ ] **Step 1: 运行全部测试**

Run: `python -m pytest tests/ -v --tb=short`
Expected: ALL PASS

- [ ] **Step 2: 运行全部测试（含日志）**

Run: `python -m pytest tests/ -v --tb=short -s 2>&1 | tail -30`
Expected: 无意外错误日志

- [ ] **Step 3: Commit**

```bash
git add -A
git commit -m "chore: 质量修复完成——全部测试通过"
```

---

## GSTACK REVIEW REPORT

| Review | Trigger | Why | Runs | Status | Findings |
|--------|---------|-----|------|--------|----------|
| CEO Review | `/plan-ceo-review` | Scope & strategy | 0 | — | — |
| Codex Review | `/codex review` | Independent 2nd opinion | 0 | — | — |
| Eng Review | `/plan-eng-review` | Architecture & tests (required) | 1 | CLEAR (PLAN) | 0 issues, 0 critical gaps |
| Design Review | `/plan-design-review` | UI/UX gaps | 0 | — | — |
| DX Review | `/plan-devex-review` | Developer experience gaps | 0 | — | — |

- **CODEX:** not run (local service unavailable)
- **CROSS-MODEL:** N/A
- **UNRESOLVED:** 0
- **VERDICT:** ENG CLEARED — ready to implement. Run `/ship` when done.
