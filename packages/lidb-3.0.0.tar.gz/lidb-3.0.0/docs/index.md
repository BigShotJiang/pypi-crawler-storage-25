# lidb API 文档

## 概述

`lidb` 是一个用于量化数据处理和管理的 Python 库，提供数据集管理（带依赖追踪和自动填充）、数据库操作（本地 parquet / MySQL / ClickHouse）、表达式因子计算等功能。

## 模块

| 模块 | 文件 | 说明 |
|------|------|------|
| 数据集 | `dataset.py` | Dataset 类，带依赖追踪、自动填充缺失数据、`_collect_existing_dates` 统一空数据处理 |
| 数据加载 | `loader.py` | load_ds / loader / DataLoader，从 dataset.py 拆分 |
| 装饰器 | `decorator.py` | `@dataset` 装饰器 |
| 数据库 | `database.py` | 本地 parquet 存储、MySQL/ClickHouse 桥接 |
| 表管理 | `table.py` | 单表单数据（全量/增量模式） |
| 表达式引擎 | `qdf/` | QDF 因子计算系统（Lark 语法 + 拓扑排序） |
| 数据服务 | `svc/data.py` | DataService 后台线程数据加载 |
| 配置 | `init.py` | dynaconf 配置管理，`@cache` 缓存配置读取 |
| 解析 | `parse.py` | SQL 解析 + Hive 分区结构解析 + `cleanup_empty_files` |

## 安装

```bash
pip install lidb
```

## 快速开始

```python
from lidb import Dataset, DataLoader

# 创建数据集
my_dataset = Dataset(fn=my_function, tb="my_table")

# 加载数据
loader = DataLoader("my_data")
loader.get([my_dataset], beg_date="2023-01-01", end_date="2023-01-31", times=["09:30:00"])
```
