# 解析工具

parse模块提供 SQL 解析和 Hive 分区结构解析等工具函数。

`cleanup_empty_files` 从 `parse_hive_partition_structure` 中分离而来——原函数会在解析时删除空文件（副作用），现改为纯解析，空文件清理由调用方按需使用 `cleanup_empty_files`。

## 函数

### `parse_hive_partition_structure(path: Path | str, file_pattern: str = "*.parquet") -> pl.DataFrame`

解析Hive风格的分区目录结构并返回为DataFrame。跳过空文件（0 字节）但不删除。

**参数**:
- `path`: 要解析的路径
- `file_pattern`: 文件匹配模式（默认 `*.parquet`）

**返回**:
- `pl.DataFrame`: 包含分区信息的DataFrame

### `cleanup_empty_files(root_path: Path | str, file_pattern: str = "*.parquet") -> int`

删除指定路径下所有空文件。

**参数**:
- `root_path`: 根路径
- `file_pattern`: 文件匹配模式（默认 `*.parquet`）

**返回**:
- `int`: 删除的空文件数量

### `extract_table_names_from_sql(sql_query: str) -> list[str]`

从SQL语句中提取表名称。

### `format_sql(sql_content: str) -> str`

格式化SQL语句，去除注释。

## 使用方法

```python
from lidb import parse_hive_partition_structure, cleanup_empty_files

# 解析分区结构（不会删除文件）
partition_info = parse_hive_partition_structure("/path/to/partitioned/data")
print(partition_info)

# 按需清理空文件
count = cleanup_empty_files("/path/to/partitioned/data")
```

## 数据流

```
get_value()/get_history()
  → _collect_existing_dates()
    → cleanup_empty_files()   清理 0 字节文件
    → parse_hive_partition_structure()  扫描分区
    → scan + 行数验证        清理 0 行 parquet
  → 缺失日期 → complete_data()  自动重填
```
