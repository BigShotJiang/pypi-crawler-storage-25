# 数据集管理

数据集模块提供数据集的创建、加载和历史数据检索等功能。核心类 `Dataset` 在 `dataset.py` 中，数据加载编排（`load_ds`、`loader`、`DataLoader`）在 `loader.py` 中。

`loader.py` 从 `dataset.py` 拆分而来，通过惰性导入避免循环引用。

## Dataset 类

### `__init__(self, *depends: Dataset, fn: Callable[..., pl.DataFrame | pl.LazyFrame], tb: str = "", update_time: str = "", window: str = "1d", partitions: list[str] = None, is_hft: bool = False, data_name: str = "", frame: int = 1)`

初始化一个新的数据集。`update_time` 的解析逻辑由纯函数 `_resolve_update_time()` 处理，替代了原有的 7 层嵌套 if-else。

**参数**:
- `depends`: 依赖的数据集
- `fn`: 数据计算函数
- `tb`: 存储表名
- `update_time`: 数据更新时间
- `window`: 依赖的回看窗口
- `partitions`: 分区列
- `is_hft`: 数据集是否包含高频数据
- `data_name`: 数据集名称
- `frame`: 用于名称推断的帧级别

### `get_value(self, date, eager: bool = True, backend: Literal["threading", "multiprocessing", "loky"] = "loky", **constraints)`

获取特定日期的数据集值。使用 `_collect_existing_dates()` 统一判定数据是否已存在（空文件/0 行数据视为不存在），自动清理并重填。

**参数**:
- `date`: 目标日期
- `eager`: 是否返回DataFrame (True) 或 LazyFrame (False)
- `backend`: 依赖加载的并发后端
- `**constraints`: 过滤条件

**返回**:
- `pl.DataFrame | pl.LazyFrame`: 数据集值

### `get_pit(self, date: str, query_time: str, eager: bool = True, **contraints)`

获取特定时间点的值，如果查询时间早于更新时间，则返回前一天的值。

**参数**:
- `date`: 目标日期
- `query_time`: 查询时间
- `eager`: 是否返回DataFrame (True) 或 LazyFrame (False)

**返回**:
- `pl.DataFrame`: 特定时间点的值

### `get_history(self, dateList: list[str], n_jobs: int = 11, backend: Literal["threading", "multiprocessing", "loky"] = "loky", eager: bool = True, rep_asset: str = "000001", **constraints)`

获取一系列日期的历史数据。与 `get_value()` 共享 `_collect_existing_dates()` 的空数据处理逻辑。

**参数**:
- `dateList`: 日期列表
- `n_jobs`: 并发作业数量
- `backend`: 并发后端
- `eager`: 是否返回DataFrame (True) 或 LazyFrame (False)
- `rep_asset`: 用于分区检测的代表性资产

**返回**:
- `pl.DataFrame | pl.LazyFrame`: 历史数据

### `get_dependsPIT(self, date: str, days: int, backend: Literal["threading", "multiprocessing", "loky"] = "loky", depends: list[Dataset] | None = None)`

获取特定时间点的依赖数据。使用惰性导入 `from .loader import load_ds` 避免循环引用。

**参数**:
- `date`: 目标日期
- `days`: 回看天数
- `backend`: 并发后端
- `depends`: 可选的依赖列表

**返回**:
- `pl.LazyFrame | None`: 依赖数据

### `alias(self, new_name: str)`

为数据集设置别名。

**参数**:
- `new_name`: 新别名

**返回**:
- `Dataset`: 自身引用

---

## loader 模块

`load_ds`、`loader`、`DataLoader` 在 `lidb/loader.py` 中。

### `DataLoader`

用于加载和管理多个数据集的类。

#### `__init__(self, name: str)`

初始化DataLoader。

**参数**:
- `name`: 加载器名称

#### `get(self, ds_list: list[Dataset], beg_date: str, end_date: str, times: list[str], avoid_future: bool = True, columns: list[str] | None = None, eager: bool = False, n_jobs: int = -1, backend: Literal["threading", "multiprocessing", "loky"] = "loky", **constraints)`

加载数据集。

**参数**:
- `ds_list`: 要加载的数据集列表
- `beg_date`: 开始日期
- `end_date`: 结束日期
- `times`: 要加载的时间列表
- `avoid_future`: 是否避免未来数据
- `columns`: 要加载的特定列
- `eager`: 是否返回DataFrame (True) 或 LazyFrame (False)
- `n_jobs`: 并发作业数量
- `backend`: 并发后端

#### `name(self) -> str`

获取加载器名称。

**返回**:
- `str`: 加载器名称

#### `data(self) -> pl.DataFrame | None`

获取已加载的数据。

**返回**:
- `pl.DataFrame | None`: 已加载的数据

#### `all_data(self) -> pl.DataFrame | None`

获取所有数据，包括之前加载的数据。

**返回**:
- `pl.DataFrame | None`: 所有数据

#### `add_data(self, df: pl.DataFrame | pl.LazyFrame)`

向加载器添加数据。

**参数**:
- `df`: 要添加的数据

---

## 函数

### `load_ds(ds_conf: dict[str, list[Dataset]], beg_date: str, end_date: str, times: list[str], n_jobs: int = 11, backend: Literal["threading", "multiprocessing", "loky"] = "loky", show_progress: bool = True, eager: bool = False, process_time: bool = True, avoid_future: bool = True, **constraints) -> dict[str, pl.DataFrame | pl.LazyFrame]`

加载多个数据集。

**参数**:
- `ds_conf`: 数据集配置
- `beg_date`: 开始日期
- `end_date`: 结束日期
- `times`: 要加载的时间列表
- `n_jobs`: 并发作业数量
- `backend`: 并发后端
- `show_progress`: 是否显示进度
- `eager`: 是否返回DataFrames
- `process_time`: 是否处理时间信息
- `avoid_future`: 是否避免未来数据

**返回**:
- `dict[str, pl.DataFrame | pl.LazyFrame]`: 按名称分组的已加载数据集
