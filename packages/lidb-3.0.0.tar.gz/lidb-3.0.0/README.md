# lidb

`lidb` is a Python library for data processing and management, providing tools for dataset handling, database operations, and data loading.

## Features

- Dataset management with dependency tracking
- Database operations (SQL, MySQL, ClickHouse)
- Data loading and scanning
- Table management
- Configuration and initialization

## Installation

```bash
# PyPI（发布版本）
pip install lidb

# GitHub（最新开发版本）
pip install -e "lidb @ git+ssh://git@github.com/link-yundi/lidb.git"
```

## Documentation

See [API Documentation](docs/index.md) for detailed usage.

## Quick Start

```python
from lidb import Dataset, DataLoader

# Create a dataset
my_dataset = Dataset(fn=my_function, tb="my_table")

# Load data
loader = DataLoader("my_data")
loader.get([my_dataset], beg_date="2023-01-01", end_date="2023-01-31", times=["09:30:00"])
```

## License

MIT License

## Version

2.3.7.2