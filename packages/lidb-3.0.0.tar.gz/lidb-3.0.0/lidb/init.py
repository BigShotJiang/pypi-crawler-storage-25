# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2025/7/17 14:40
# Description:

from functools import cache
from pathlib import Path
from dynaconf import Dynaconf
import logair
import os


USERHOME = Path("~").expanduser()
NAME = "lidb"
DB_PATH = USERHOME / NAME
CONFIG_PATH = USERHOME / ".config" / NAME / "settings.toml"

logger = logair.get_logger(NAME)


def _ensure_config_exists():
    """确保配置文件存在，不存在则创建"""
    if CONFIG_PATH.exists():
        return
    try:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        logger.error(f"Failed to create settings file: {e}")
    with open(CONFIG_PATH, "w") as f:
        template_content = f'[GLOBAL]\npath="{DB_PATH}"\n\n[POLARS]\nmax_threads=32\n'
        f.write(template_content)
    logger.info(f"Settings file created: {CONFIG_PATH}")


@cache
def get_settings():
    _ensure_config_exists()
    try:
        return Dynaconf(settings_files=[CONFIG_PATH])
    except Exception as e:
        logger.error(f"Read settings file failed: {e}")
        return {}

# 模块级初始化：从配置覆盖 DB_PATH（如配置了 global.path），设置 polars 线程数
_settings = get_settings()
if _settings is not None:
    setting_db_path = _settings.get("global.path", "")
    setting_polars_threads = _settings.get("polars.max_threads", 32)
    os.environ["POLARS_MAX_THREADS"] = str(setting_polars_threads)
    if setting_db_path and Path(setting_db_path) != DB_PATH:
        DB_PATH = Path(setting_db_path)
