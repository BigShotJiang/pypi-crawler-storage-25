# Copyright (c) ZhangYundi.
# Licensed under the MIT License.
# Description: 数据加载编排——load_ds / loader / DataLoader

from __future__ import annotations

from collections import defaultdict
from typing import Literal

import polars as pl
import polars.selectors as cs
import xcals
import ygo

from .dataset import Dataset


def loader(data_name: str,
           ds: Dataset,
           date_list: list[str],
           prev_date_list: list[str],
           prev_date_mapping: dict[str, str],
           time: str,
           process_time: bool,
           avoid_future: bool = True,
           **constraints) -> pl.LazyFrame:
    """单数据集加载器"""
    if avoid_future:
        if time:
            if time < ds.update_time:
                if len(prev_date_list) > 1:
                    lf = ds.get_history(prev_date_list, eager=False, **constraints)
                else:
                    lf = ds.get_value(prev_date_list[0], eager=False, **constraints)
            else:
                if len(date_list) > 1:
                    lf = ds.get_history(date_list, eager=False, **constraints)
                else:
                    lf = ds.get_value(date_list[0], eager=False, **constraints)
        else:
            if ds.update_time > "09:30:00":
                if len(prev_date_list) > 1:
                    lf = ds.get_history(prev_date_list, eager=False, **constraints)
                else:
                    lf = ds.get_value(prev_date_list[0], eager=False, **constraints)
            else:
                if len(date_list) > 1:
                    lf = ds.get_history(date_list, eager=False, **constraints)
                else:
                    lf = ds.get_value(date_list[0], eager=False, **constraints)
    else:
        all_date_list = [prev_date_list[0], ] + date_list
        lf = ds.get_history(all_date_list, eager=False, **constraints)

    schema = lf.collect_schema()
    include_time = schema.get("time") is not None
    if process_time and time:
        if include_time:
            lf = lf.filter(time=time)
        else:
            lf = lf.with_columns(time=pl.lit(time))
    if (time < ds.update_time) & avoid_future:
        lf = lf.with_columns(date=pl.col("date").replace(prev_date_mapping))
    keep = {"date", "time", "asset"}
    if ds._name:
        columns = lf.collect_schema().names()
        rename_cols = set(columns).difference(keep)
        if len(rename_cols) > 1:
            lf = lf.rename({k: f"{ds._name}.{k}" for k in rename_cols})
        else:
            lf = lf.rename({k: ds._name for k in rename_cols})
    return data_name, lf


def load_ds(ds_conf: dict[str, list[Dataset]],
            beg_date: str,
            end_date: str,
            times: list[str],
            n_jobs: int = 11,
            backend: Literal["threading", "multiprocessing", "loky"] = "loky",
            show_progress: bool = True,
            eager: bool = False,
            process_time: bool = True,
            avoid_future: bool = True,
            **constraints) -> dict[str, pl.DataFrame | pl.LazyFrame]:
    """多数据集并发加载"""
    if beg_date > end_date:
        raise ValueError("beg_date must be less than end_date")
    date_list = xcals.get_tradingdays(beg_date, end_date)
    beg_date, end_date = date_list[0], date_list[-1]
    prev_date_list = xcals.get_tradingdays(xcals.shift_tradeday(beg_date, -1),
                                           xcals.shift_tradeday(end_date, -1))
    prev_date_mapping = {prev_date: date_list[i] for i, prev_date in enumerate(prev_date_list)}
    results = defaultdict(list)
    index = ("date", "time", "asset")
    _index = ("date", "asset")
    with ygo.pool(n_jobs=n_jobs,
                  backend=backend,
                  show_progress=show_progress) as go:
        for data_name, ds_list in ds_conf.items():
            for ds in ds_list:
                _data_name = f"{data_name}:{ds.tb}"
                if ds._name:
                    _data_name += f".alias({ds._name})"
                for time in times:
                    go.submit(loader,
                              job_name="Loading",
                              postfix=data_name, )(data_name=_data_name,
                                                   ds=ds,
                                                   date_list=date_list,
                                                   prev_date_list=prev_date_list,
                                                   prev_date_mapping=prev_date_mapping,
                                                   time=time,
                                                   process_time=process_time,
                                                   avoid_future=avoid_future,
                                                   **constraints)
        for name, lf in go.do():
            results[name].append(lf)
    _LFs_with_time = {}
    _LFs_without_time = {}
    for name, lfList in results.items():
        lf = pl.concat(lfList)
        if "time" not in lf.collect_schema().names():
            _LFs_without_time[name] = lf
        else:
            _LFs_with_time[name] = lf
    LFs_with_time = defaultdict(list)
    LFs_without_time = defaultdict(list)
    for name, lf in _LFs_with_time.items():
        dn, _ = name.split(":")
        LFs_with_time[dn].append(lf)
    for name, lf in _LFs_without_time.items():
        dn, _ = name.split(":")
        LFs_without_time[dn].append(lf)
    LFs_with_time = {
        name: (pl.concat(lfList, how="align")
               .sort(index)
               .select(*index, cs.exclude(index)))
        for name, lfList in LFs_with_time.items()}
    LFs_without_time = {
        name: (pl.concat(lfList, how="align")
               .sort(_index)
               .select(*_index, cs.exclude(_index)))
        for name, lfList in LFs_without_time.items()}
    dns = list(LFs_with_time.keys()) if LFs_with_time else list(LFs_without_time.keys())
    LFs = dict()
    for dn in dns:
        _lf_with_time = LFs_with_time.get(dn)
        _lf_without_time = LFs_without_time.get(dn)
        if _lf_with_time is not None:
            LFs[dn] = _lf_with_time
            if _lf_without_time is not None:
                LFs[dn] = LFs[dn].join(_lf_without_time, on=["date", "asset"], how="left")
        else:
            LFs[dn] = _lf_without_time
    if not eager:
        return LFs
    return {name: lf.collect() for name, lf in LFs.items()}


class DataLoader:
    """数据加载服务"""

    def __init__(self, name: str):
        self._name = name
        self._index: tuple[str] = ("date", "time", "asset")
        self._df: pl.LazyFrame | pl.DataFrame = None
        self._all_df: pl.LazyFrame | pl.DataFrame = None

    def get(self,
            ds_list: list[Dataset],
            beg_date: str,
            end_date: str,
            times: list[str],
            avoid_future: bool = True,
            columns: list[str] | None = None,
            eager: bool = False,
            n_jobs: int = -1,
            backend: Literal["threading", "multiprocessing", "loky"] = "loky",
            **constraints):
        lf = load_ds(ds_conf={self._name: ds_list},
                     beg_date=beg_date,
                     end_date=end_date,
                     n_jobs=n_jobs,
                     backend=backend,
                     times=times,
                     avoid_future=avoid_future,
                     eager=eager,
                     process_time=True,
                     **constraints)
        self._df = lf[self._name]
        if columns:
            self._df = self._df.select("date", "time", "asset", *columns)
        self.add_data(self._df)

    @property
    def name(self) -> str:
        return self._name

    @property
    def data(self) -> pl.DataFrame | None:
        if isinstance(self._df, pl.LazyFrame):
            self._df = self._df.collect()
        return self._df

    @property
    def all_data(self) -> pl.DataFrame | None:
        if isinstance(self._all_df, pl.LazyFrame):
            self._all_df = self._all_df.collect()
        return self._all_df

    def add_data(self, df: pl.DataFrame | pl.LazyFrame):
        if self._all_df is None:
            self._all_df = df
        else:
            self._all_df = pl.concat([self._all_df.lazy(), df.lazy()], how="align").sort(self._index)
