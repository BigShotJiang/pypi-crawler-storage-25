# Copyright (c) ZhangYundi.
# Licensed under the MIT License.
# Created on 2025/10/27 14:13
# Description:

from __future__ import annotations

import inspect
import os
import pathlib
import shutil
import traceback
from enum import Enum
from functools import partial
from typing import Callable, Literal

import logair
import pandas as pd
import polars as pl
import polars.selectors as cs
import xcals
import ygo
from varname import varname

from .database import put, tb_path, scan, DB_PATH
from .parse import parse_hive_partition_structure, cleanup_empty_files

DEFAULT_DS_PATH = DB_PATH / "datasets"


def _resolve_update_time(
    update_time: str,
    depends: list[Dataset],
) -> str:
    """
    根据当前 Dataset 和底层依赖解析最终的 update_time。

    规则:
    - 09:30~15:00 之间的时间视为实时（空字符串）
    - 有实时依赖时，当前 update_time <= 09:30 会被修复为空
    - 有盘后依赖 (>=15:00) 时，当前如果为空会被修复为依赖的最大值
    """
    if "09:30:00" < update_time < "15:00:00":
        update_time = ""

    if not depends:
        return update_time

    has_rt = any(not ds.update_time for ds in depends)
    dep_uts = [ds.update_time for ds in depends if ds.update_time]
    max_ut = max(dep_uts) if dep_uts else ""

    if not update_time:
        if max_ut >= "15:00:00":
            update_time = max_ut
        return update_time

    if not max_ut:
        if update_time <= "09:30:00":
            update_time = ""
        return update_time

    if not has_rt:
        update_time = max(max_ut, update_time)
    elif max_ut >= "15:00:00":
        update_time = max(max_ut, update_time)
    elif update_time <= "09:30:00":
        update_time = ""

    return update_time


class InstrumentType(Enum):
    STOCK = "Stock"  # 股票
    ETF = "ETF"  #
    CB = "ConvertibleBond"  # 可转债


def complete_data(fn, date, save_path, partitions):
    logger = logair.get_logger(__name__)
    try:
        data = fn()
        if data is None:
            # 保存数据的逻辑在fn中实现了
            return
        # 剔除以 `_` 开头的列
        data = data.select(~cs.starts_with("_"))
        if not isinstance(data, (pl.DataFrame, pl.LazyFrame)):
            logger.error(f"{save_path}: Result of dataset.fn must be polars.DataFrame or polars.LazyFrame.")
            return
        if isinstance(data, pl.LazyFrame):
            data = data.collect()
        cols = data.columns
        if "date" not in cols:
            data = data.with_columns(pl.lit(date).alias("date")).select("date", *cols)
        else:
            data = data.cast({"date": pl.Utf8})
        data = data.filter(date=date)
        if "time" in data.columns:
            if data["time"].n_unique() < 2:
                data = data.drop("time")
        if data.is_empty():
            logger.error(f"{save_path}: Empty data for {date}.")
        else:
            put(data, save_path, partitions=partitions)
    except Exception as e:
        logger.error(f"{save_path}: Error when complete data for {date}\n", exc_info=e)


class Dataset:

    def __init__(self,
                 *depends: Dataset,
                 fn: Callable[..., pl.DataFrame | pl.LazyFrame],
                 tb: str = "",
                 update_time: str = "",
                 window: str = "1d",
                 partitions: list[str] = None,
                 is_hft: bool = False,
                 data_name: str = "",
                 frame: int = 1,
                 _name: str = ""):
        """

        Parameters
        ----------
        depends: Dataset
            底层依赖数据集
        fn: str
            数据集计算函数。如果要用到底层依赖数据集，则必须显示定义形参 `depend`
        tb: str
            数据集保存表格, 如果没有指定，默认 {lidb.DB_PATH}/datasets/<module>
        update_time: str
            更新时间: 默认没有-实时更新，也就是可以取到当天值
            更新时间只允许三种情况：
            - 1. 盘前时间点：比如 08:00:00, 09:00:00, 09:15:00 ...
            - 2. 盘中时间点：归为实时更新，使用空值 ""
            - 3. 盘后时间点：比如 15:00:00, 16:30:00, 20:00:00 ...
        partitions: list[str]
            分区: 如果指定为 None, 则自动从 fn 参数推断，如果不需要分区，应该将其设定为空列表: []
        is_hft: bool
            是否是高频数据，如果是，则会按照asset进行分区存储，默认 False
            hft定义为：时间步长 < 1min
        window: str
            配合depends使用，在取depends时，会回看window周期，最小单位为`d`。不足 `d` 的会往上取整为`1d`
        data_name: str
            数据名，默认为空，会自动推断，如果指定了，则使用指定名
        frame: int
            用于自动推断 数据名
        """
        self._depends = list(depends)
        self._name = _name
        self.fn = fn
        self.fn_params_sig = ygo.fn_signature_params(fn)
        self._is_depend = "depend" in self.fn_params_sig and len(self._depends) > 0
        self._is_hft = is_hft
        self._frame = frame
        self.data_name = data_name
        if not self.data_name:
            try:
                self.data_name = varname(frame, strict=False)
            except Exception as e:
                pass
        if self.data_name:
            self.data_name = self.data_name.replace('ds_', '')
        fn_params = ygo.fn_params(self.fn)
        self.fn_params = {k: v for (k, v) in fn_params}
        # 更新底层依赖数据集的同名参数
        self._update_depends()

        if pd.Timedelta(window).days < 1:
            window = "1d"
        window_td = pd.Timedelta(window)
        self._window = window
        self._days = window_td.days
        if window_td.seconds > 0:
            self._days += 1
        # 检测是否高频数据：如果是高频数据，则按照标的进行分区，高频的定义为时间差 < 60s
        self._append_partitions = ["asset", "date"] if is_hft else ["date", ]
        if partitions is not None:
            partitions = [k for k in partitions if k not in self._append_partitions]
            partitions = [*partitions, *self._append_partitions]
        else:
            # partitions = self._append_partitions
            exclude_partitions = ["this", "depend"]
            partitions = [k for k in self.fn_params_sig if k not in self._append_partitions and k not in exclude_partitions]
            partitions = [*partitions, *self._append_partitions]
        self.partitions = partitions
        self._type_asset = "asset" in self.fn_params_sig
        self._tb = tb
        mod = inspect.getmodule(fn)
        self.tb = tb if tb else DEFAULT_DS_PATH / mod.__name__ / f"{self.data_name}"
        self.save_path = tb_path(self.tb)
        self.constraints = dict()
        for k in self.partitions[:-len(self._append_partitions)]:
            if k in self.fn_params:
                v = self.fn_params[k]
                if isinstance(v, (list, tuple)) and not isinstance(v, str):
                    v = sorted(v)
                self.constraints[k] = v
                self.save_path = self.save_path / f"{k}={v}"

        self.update_time = _resolve_update_time(update_time, self._depends)
        self.fn = ygo.delay(self.fn)(this=self)

    def _collect_existing_dates(self, search_path: pathlib.Path) -> set[str]:
        """返回 search_path 下实际有数据的日期集合。

        将空文件（0 字节或 0 行）视为不存在：
        先清理 0 字节文件，再扫描分区结构，对每个候选日期做行数检查。
        0 行的分区会被删除，不计入返回值。
        """
        cleaned = cleanup_empty_files(search_path)
        if cleaned:
            logair.get_logger(__name__).warning(f"{search_path}: Cleaned {cleaned} empty files.")

        if self.is_empty(search_path):
            return set()

        hive_info = parse_hive_partition_structure(search_path)
        if "date" not in hive_info.columns:
            return set()

        candidates = set(hive_info["date"].to_list())
        valid = set()
        for d in candidates:
            date_path = search_path / f"date={d}"
            if not date_path.exists():
                continue
            try:
                row_count = scan(date_path).select(pl.len()).collect().item()
                if row_count > 0:
                    valid.add(d)
                else:
                    shutil.rmtree(date_path)
            except Exception:
                shutil.rmtree(date_path)
        return valid

    def _update_depends(self):
        new_deps = list()
        for dep in self._depends:
            new_dep = dep(**self.fn_params).alias(dep._name)
            new_deps.append(new_dep)
        self._depends = new_deps

    def is_empty(self, path) -> bool:
        return not any(path.rglob("*.parquet"))

    def __call__(self, *depends, **fn_kwargs):
        """赋值时也会同步更新底层依赖数据集的同名参数"""
        if "data_name" in fn_kwargs:
            data_name = fn_kwargs.pop("data_name")
        else:
            data_name = self.data_name
        window = fn_kwargs.get("window", self._window)
        fn = ygo.delay(self.fn)(**fn_kwargs)
        depends = depends or self._depends
        ds = Dataset(*depends,
                     fn=fn,
                     tb=self._tb,
                     partitions=self.partitions,
                     update_time=self.update_time,
                     is_hft=self._is_hft,
                     window=window,
                     data_name=data_name,
                     frame=self._frame+1,
                     _name=self._name)
        return ds

    def alias(self, new_name: str):
        self._name = new_name
        return self

    def get_value(self,
                  date,
                  eager: bool = True,
                  backend: Literal["threading", "multiprocessing", "loky"] = "loky",
                  **constraints):
        """
        取值: 不保证未来数据
        Parameters
        ----------
        date: str
            取值日期
        eager: bool
        backend:  Literal["threading", "multiprocessing", "loky"]
            获取依赖因子并发后端
        constraints: dict
            取值的过滤条件

        Returns
        -------

        """
        logger = logair.get_logger(f"{__name__}.{self.__class__.__name__}")
        _constraints = {k: v for k, v in constraints.items() if k in self.partitions}
        _limits = {k: v for k, v in constraints.items() if k not in self.partitions}
        search_path = self.save_path
        for k, v in _constraints.items():
            if k in self.constraints:
                continue
            if isinstance(v, (list, tuple)) and not isinstance(v, str):
                v = sorted(v)
            search_path = search_path / f"{k}={v}"
        search_path = search_path / f"date={date}"

        # 统一判定：数据是否已存在（空文件/0 行数据都视为不存在）
        existing = self._collect_existing_dates(search_path.parent)
        if date in existing:
            lf = scan(search_path).cast({"date": pl.Utf8})
            schema = lf.collect_schema()
            _limits = {k: v for k, v in constraints.items() if schema.get(k) is not None}
            lf = lf.filter(date=date, **_limits)
            if not eager:
                return lf
            return lf.collect()

        days = self.constraints.get("days", constraints.get("days", self._days))
        if self._depends:
            # 先补齐depend
            _beg_date = date
            if days > 1:
                _beg_date = xcals.shift_tradeday(date, -(days-1))
            _depend_dates = xcals.get_tradingdays(_beg_date, date)
            for depend in self._depends:
                depend.get_history(_depend_dates, eager=False, backend=backend)

        fn = self.fn
        save_path = self.save_path
        if self._is_depend:
            fn = partial(fn, date=date, depend=self.get_dependsPIT(date, days=days, backend=backend))
        else:
            fn = partial(fn, date=date)
        if self._type_asset:
            if "asset" in _constraints:
                fn = ygo.delay(self.fn)(asset=_constraints["asset"])
        if len(self.constraints) < len(self.partitions) - len(self._append_partitions):
            # 如果分区指定的字段没有在Dataset定义中指定，需要在get_value中指定
            params = dict()
            for k in self.partitions[:-len(self._append_partitions)]:
                if k not in self.constraints:
                    v = constraints[k]
                    params[k] = v
                    save_path = save_path / f"{k}={v}"
            fn = ygo.delay(self.fn)(**params)

        today = xcals.today()
        now = xcals.now()
        if (date > today) or (date == today and now < self.update_time):
            logger.warning(f"{self.tb}: {date} is not ready, waiting for {self.update_time}")
            return
        complete_data(fn, date, save_path, self._append_partitions)

        lf = scan(search_path).cast({"date": pl.Utf8})
        schema = lf.collect_schema()
        _limits = {k: v for k, v in constraints.items() if schema.get(k) is not None}
        lf = lf.filter(date=date, **_limits)
        if not eager:
            return lf
        return lf.collect()

    def get_pit(self, date: str, query_time: str, eager: bool = True, **contraints):
        """取值：如果取值时间早于更新时间，则返回上一天的值"""
        if not self.update_time:
            return self.get_value(date, **contraints)
        val_date = date
        if query_time < self.update_time:
            val_date = xcals.shift_tradeday(date, -1)
        return self.get_value(val_date, eager=eager, **contraints).with_columns(date=pl.lit(date), )

    def get_history(self,
                    dateList: list[str],
                    n_jobs: int = 11,
                    backend: Literal["threading", "multiprocessing", "loky"] = "loky",
                    eager: bool = True,
                    rep_asset: str = "000001",  # 默认 000001
                    **constraints):
        """获取历史值: 不保证未来数据"""
        _constraints = {k: v for k, v in constraints.items() if k in self.partitions}
        search_path = self.save_path
        for k, v in _constraints.items():
            if k in self.constraints:
                continue
            if isinstance(v, (list, tuple)) and not isinstance(v, str):
                v = sorted(v)
            search_path = search_path / f"{k}={v}"
        if self.is_empty(search_path):
            # 需要补全全部数据
            missing_dates = dateList
        else:
            if not self._type_asset:
                _search_path = self.save_path
                for k, v in _constraints.items():
                    if k in self.constraints:
                        continue
                    if k != "asset":
                        _search_path = _search_path / f"{k}={v}"
                    else:
                        _search_path = _search_path / f"asset={rep_asset}"
                exist_dates = self._collect_existing_dates(_search_path)
            else:
                exist_dates = self._collect_existing_dates(search_path)
            missing_dates = sorted(set(dateList) - exist_dates)
        if missing_dates:
            days = self.constraints.get("days", constraints.get("days", self._days))
            # 先逐个补齐 depends
            if self._depends:
                _end_date = max(missing_dates)
                _beg_date = min(missing_dates)
                if days > 1:
                    _beg_date = xcals.shift_tradeday(_beg_date, -(days-1))
                _depend_dates = xcals.get_tradingdays(_beg_date, _end_date)
                for depend in self._depends:
                    depend.get_history(_depend_dates, eager=False, backend=backend)

            fn = self.fn
            save_path = self.save_path

            if self._type_asset:
                if "asset" in _constraints:
                    fn = ygo.delay(self.fn)(asset=_constraints["asset"])

            if len(self.constraints) < len(self.partitions) - len(self._append_partitions):
                params = dict()
                for k in self.partitions[:-len(self._append_partitions)]:
                    if k not in self.constraints:
                        v = constraints[k]
                        params[k] = v
                        save_path = save_path / f"{k}={v}"
                fn = ygo.delay(fn)(**params)
            else:
                # 传递非分区参数
                non_partition_params = {k: v for k, v in constraints.items()
                                        if k not in self.partitions and k not in self._append_partitions}
                if non_partition_params:
                    fn = ygo.delay(fn)(**non_partition_params)

            with ygo.pool(n_jobs=n_jobs, backend=backend) as go:
                info_path = self.save_path
                try:
                    info_path = info_path.relative_to(DB_PATH)
                except:
                    pass
                if self._is_depend:
                    with ygo.pool(n_jobs=n_jobs, show_progress=False, backend=backend) as _go:
                        for date in missing_dates:
                            _go.submit(self.get_dependsPIT, job_name="preparing depend")(date=date, days=days, backend=backend)
                        for (date, depend) in zip(missing_dates, _go.do()):
                            fn = partial(fn, date=date, depend=depend)
                            go.submit(complete_data,
                                      job_name=f"Completing",
                                      postfix=info_path,
                                      leave=False)(fn=fn,
                                                   date=date,
                                                   save_path=save_path,
                                                   partitions=self._append_partitions, )
                else:
                    for date in missing_dates:
                        fn = partial(fn, date=date)
                        go.submit(complete_data,
                                  job_name=f"Completing",
                                  postfix=info_path,
                                  leave=False)(fn=fn,
                                               date=date,
                                               save_path=save_path,
                                               partitions=self._append_partitions, )
                go.do()
        data = scan(search_path, ).cast({"date": pl.Utf8}).filter(pl.col("date").is_in(dateList), **constraints)
        data = data.sort("date")
        if eager:
            return data.collect()
        return data

    def get_dependsPIT(self,
                       date: str,
                       days: int,
                       backend: Literal["threading", "multiprocessing", "loky"] = "loky",
                       depends: list[Dataset] | None = None) -> pl.LazyFrame | None:
        """获取依赖数据集"""
        if not depends and not self._depends:
            return None
        end_date = date
        beg_date = date
        if days > 1:
            beg_date = xcals.shift_tradeday(beg_date, -(days-1))
        depends = depends or self._depends
        params = {
            "ds_conf": dict(depend=depends),
            "beg_date": beg_date,
            "end_date": end_date,
            "times": [self.update_time, ],
            "show_progress": False,
            "eager": False,
            "n_jobs": 1,
            "backend": backend,
            "process_time": False,  # 不处理时间
        }
        from .loader import load_ds  # 惰性导入，避免循环引用

        res = load_ds(**params)
        return res["depend"]


