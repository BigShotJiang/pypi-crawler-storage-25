# xray_conf_models

High-level human-facing config models generated from Go AST in `infra/conf`.

## Quick use

```python
from xray_conf_models import XrayConfig
from xray_conf_models import InboundDetourConfig, StreamConfig, TCPConfig, VLessInboundConfig

config = XrayConfig(
    inbounds=[
        InboundDetourConfig(
            protocol="vless",
            port="443",
            settings=VLessInboundConfig(decryption="none"),
            stream_settings=StreamConfig(
                security="tls",
                tcp_settings=TCPConfig(header={"type": "none"}),
            ),
        )
    ]
)

print(config.to_native_json())
```

## What this layer is

- `xray_conf_models.models`: generated Pydantic classes that mirror Go `conf` structs.
- `xray_conf_models.base`: small runtime base with JSON helpers.
- `tools/conf_model_generator`: generator implementation.
- `tools/conf_model_generator/go_ast_exporter`: Go helper that extracts struct/type metadata and loader maps.

## Responsibility map

- `go_ast_exporter/main.go`: parses `infra/conf` with Go AST and emits normalized JSON metadata.
- `go_extractor.py`: runs the Go helper and converts JSON into Python IR.
- `collect.py`: walks the reachable type graph starting from `conf.Config`.
- `render.py`: renders Python type aliases and Pydantic models.
- `writers.py`: writes the generated package files.
- `docs.py`: writes this README text.

## Go reuse

This layer reuses Go in two different ways:

1. Structure discovery:
   The generator does not regex Go files. It uses Go AST via `go/parser` and `go/ast` to extract exported `infra/conf` types, field tags and loader declarations.
2. Runtime semantics:
   The generated Python classes only mirror the human-facing config shape. They do not reimplement `Build()`, `Override()` or protocol loading semantics. Those still belong to Go code in `infra/conf`.

That split is intentional:
- Python owns typing and IDE discoverability.
- Go remains the source of truth for actual config interpretation.

## Limits

- Custom `UnmarshalJSON` / `MarshalJSON` logic is documented on the generated type, but not reimplemented automatically.
- `json.RawMessage` fields become `JsonValue` unless the generator can bind them to a `NewJSONConfigLoader` map.
- Loader-backed fields such as inbound/outbound `settings` become unions of known config classes plus `JsonValue`.
