"""Auto-generated human-facing Xray config models from `shadowsocks.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class ShadowsocksClientConfig(ConfModel):
    """Go semantics: Build() in Go."""
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    level: int | None = Field(default=None)
    email: str | None = Field(default=None)
    method: str | None = Field(default=None)
    password: str | None = Field(default=None)
    uot: bool | None = Field(default=None)
    uot_version: int | None = Field(default=None, alias="uotVersion")
    servers: list[ShadowsocksServerTarget] | None = Field(default=None)

class ShadowsocksServerConfig(ConfModel):
    """Go semantics: Build() in Go."""
    method: str | None = Field(default=None)
    password: str | None = Field(default=None)
    level: int | None = Field(default=None)
    email: str | None = Field(default=None)
    clients: list[ShadowsocksUserConfig] | None = Field(default=None)
    network: NetworkList | JsonValue | None = Field(default=None)

class ShadowsocksServerTarget(ConfModel):
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    level: int | None = Field(default=None)
    email: str | None = Field(default=None)
    method: str | None = Field(default=None)
    password: str | None = Field(default=None)
    uot: bool | None = Field(default=None)
    uot_version: int | None = Field(default=None, alias="uotVersion")

class ShadowsocksUserConfig(ConfModel):
    method: str | None = Field(default=None)
    password: str | None = Field(default=None)
    level: int | None = Field(default=None)
    email: str | None = Field(default=None)
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)

__all__ = [
    "ShadowsocksClientConfig",
    "ShadowsocksServerConfig",
    "ShadowsocksServerTarget",
    "ShadowsocksUserConfig",
]
