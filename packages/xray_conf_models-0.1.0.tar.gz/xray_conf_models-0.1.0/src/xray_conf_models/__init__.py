from xray_conf_models.base import ConfModel, JsonValue
from xray_conf_models.api import *
import xray_conf_models.api as api_models
from xray_conf_models.blackhole import *
import xray_conf_models.blackhole as blackhole_models
from xray_conf_models.common import *
import xray_conf_models.common as common_models
from xray_conf_models.dns import *
import xray_conf_models.dns as dns_models
from xray_conf_models.dns_proxy import *
import xray_conf_models.dns_proxy as dns_proxy_models
from xray_conf_models.dokodemo import *
import xray_conf_models.dokodemo as dokodemo_models
from xray_conf_models.fakedns import *
import xray_conf_models.fakedns as fakedns_models
from xray_conf_models.freedom import *
import xray_conf_models.freedom as freedom_models
from xray_conf_models.grpc import *
import xray_conf_models.grpc as grpc_models
from xray_conf_models.http import *
import xray_conf_models.http as http_models
from xray_conf_models.hysteria import *
import xray_conf_models.hysteria as hysteria_models
from xray_conf_models.log import *
import xray_conf_models.log as log_models
from xray_conf_models.loopback import *
import xray_conf_models.loopback as loopback_models
from xray_conf_models.metrics import *
import xray_conf_models.metrics as metrics_models
from xray_conf_models.observatory import *
import xray_conf_models.observatory as observatory_models
from xray_conf_models.policy import *
import xray_conf_models.policy as policy_models
from xray_conf_models.reverse import *
import xray_conf_models.reverse as reverse_models
from xray_conf_models.router import *
import xray_conf_models.router as router_models
from xray_conf_models.router_strategy import *
import xray_conf_models.router_strategy as router_strategy_models
from xray_conf_models.shadowsocks import *
import xray_conf_models.shadowsocks as shadowsocks_models
from xray_conf_models.socks import *
import xray_conf_models.socks as socks_models
from xray_conf_models.transport_authenticators import *
import xray_conf_models.transport_authenticators as transport_authenticators_models
from xray_conf_models.transport_internet import *
import xray_conf_models.transport_internet as transport_internet_models
from xray_conf_models.trojan import *
import xray_conf_models.trojan as trojan_models
from xray_conf_models.tun import *
import xray_conf_models.tun as tun_models
from xray_conf_models.version import *
import xray_conf_models.version as version_models
from xray_conf_models.vless import *
import xray_conf_models.vless as vless_models
from xray_conf_models.vmess import *
import xray_conf_models.vmess as vmess_models
from xray_conf_models.wireguard import *
import xray_conf_models.wireguard as wireguard_models
from xray_conf_models.xray import *
import xray_conf_models.xray as xray_models
from xray_conf_models.xray import Config as XrayConfig
from pydantic import BaseModel

__all__ = ["ConfModel", "JsonValue", "XrayConfig"
    , *api_models.__all__
    , *blackhole_models.__all__
    , *common_models.__all__
    , *dns_models.__all__
    , *dns_proxy_models.__all__
    , *dokodemo_models.__all__
    , *fakedns_models.__all__
    , *freedom_models.__all__
    , *grpc_models.__all__
    , *http_models.__all__
    , *hysteria_models.__all__
    , *log_models.__all__
    , *loopback_models.__all__
    , *metrics_models.__all__
    , *observatory_models.__all__
    , *policy_models.__all__
    , *reverse_models.__all__
    , *router_models.__all__
    , *router_strategy_models.__all__
    , *shadowsocks_models.__all__
    , *socks_models.__all__
    , *transport_authenticators_models.__all__
    , *transport_internet_models.__all__
    , *trojan_models.__all__
    , *tun_models.__all__
    , *version_models.__all__
    , *vless_models.__all__
    , *vmess_models.__all__
    , *wireguard_models.__all__
    , *xray_models.__all__
]

for _name in __all__:
    _obj = globals().get(_name)
    if isinstance(_obj, type) and issubclass(_obj, BaseModel) and _obj is not BaseModel:
        _obj.model_rebuild(_types_namespace=globals())
