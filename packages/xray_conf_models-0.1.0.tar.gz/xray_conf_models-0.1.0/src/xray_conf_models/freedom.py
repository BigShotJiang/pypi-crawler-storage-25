"""Auto-generated human-facing Xray config models from `freedom.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class Fragment(ConfModel):
    packets: str | None = Field(default=None)
    length: Int32Range | JsonValue | None = Field(default=None)
    interval: Int32Range | JsonValue | None = Field(default=None)
    max_split: Int32Range | JsonValue | None = Field(default=None, alias="maxSplit")

class FreedomConfig(ConfModel):
    """Go semantics: Build() in Go."""
    target_strategy: str | None = Field(default=None, alias="targetStrategy")
    domain_strategy: str | None = Field(default=None, alias="domainStrategy")
    redirect: str | None = Field(default=None)
    user_level: int | None = Field(default=None, alias="userLevel")
    fragment: Fragment | None = Field(default=None)
    noise: Noise | None = Field(default=None)
    noises: list[Noise] | None = Field(default=None)
    proxy_protocol: int | None = Field(default=None, alias="proxyProtocol")

class Noise(ConfModel):
    type: str | None = Field(default=None)
    packet: str | None = Field(default=None)
    delay: Int32Range | JsonValue | None = Field(default=None)
    apply_to: str | None = Field(default=None, alias="applyTo")

__all__ = [
    "Fragment",
    "FreedomConfig",
    "Noise",
]
