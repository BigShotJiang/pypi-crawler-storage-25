"""Auto-generated human-facing Xray config models from `hysteria.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class HysteriaClientConfig(ConfModel):
    """Go semantics: Build() in Go."""
    version: int | None = Field(default=None)
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)

class HysteriaServerConfig(ConfModel):
    """Go semantics: Build() in Go."""
    version: int | None = Field(default=None)
    clients: list[HysteriaUserConfig] | None = Field(default=None)

class HysteriaUserConfig(ConfModel):
    auth: str | None = Field(default=None)
    level: int | None = Field(default=None)
    email: str | None = Field(default=None)

__all__ = [
    "HysteriaClientConfig",
    "HysteriaServerConfig",
    "HysteriaUserConfig",
]
