"""Auto-generated human-facing Xray config models from `trojan.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class TrojanClientConfig(ConfModel):
    """TrojanClientConfig is configuration of trojan servers Go semantics: Build() in Go."""
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    level: int | None = Field(default=None)
    email: str | None = Field(default=None)
    password: str | None = Field(default=None)
    flow: str | None = Field(default=None)
    servers: list[TrojanServerTarget] | None = Field(default=None)

class TrojanInboundFallback(ConfModel):
    """TrojanInboundFallback is fallback configuration"""
    name: str | None = Field(default=None)
    alpn: str | None = Field(default=None)
    path: str | None = Field(default=None)
    type: str | None = Field(default=None)
    dest: JsonValue | None = Field(default=None)
    xver: int | None = Field(default=None)

class TrojanServerConfig(ConfModel):
    """TrojanServerConfig is Inbound configuration Go semantics: Build() in Go."""
    clients: list[TrojanUserConfig] | None = Field(default=None)
    fallbacks: list[TrojanInboundFallback] | None = Field(default=None)

class TrojanServerTarget(ConfModel):
    """TrojanServerTarget is configuration of a single trojan server"""
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    level: int | None = Field(default=None)
    email: str | None = Field(default=None)
    password: str | None = Field(default=None)
    flow: str | None = Field(default=None)

class TrojanUserConfig(ConfModel):
    """TrojanUserConfig is user configuration"""
    password: str | None = Field(default=None)
    level: int | None = Field(default=None)
    email: str | None = Field(default=None)
    flow: str | None = Field(default=None)

__all__ = [
    "TrojanClientConfig",
    "TrojanInboundFallback",
    "TrojanServerConfig",
    "TrojanServerTarget",
    "TrojanUserConfig",
]
