"""Auto-generated human-facing Xray config models from `vless.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class VLessInboundConfig(ConfModel):
    """Go semantics: Build() in Go."""
    clients: list[JsonValue] | None = Field(default=None)
    decryption: str | None = Field(default=None)
    fallbacks: list[VLessInboundFallback] | None = Field(default=None)
    flow: str | None = Field(default=None)
    testseed: list[int] | None = Field(default=None)

class VLessInboundFallback(ConfModel):
    name: str | None = Field(default=None)
    alpn: str | None = Field(default=None)
    path: str | None = Field(default=None)
    type: str | None = Field(default=None)
    dest: JsonValue | None = Field(default=None)
    xver: int | None = Field(default=None)

class VLessOutboundConfig(ConfModel):
    """Go semantics: Build() in Go."""
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    level: int | None = Field(default=None)
    email: str | None = Field(default=None)
    id: str | None = Field(default=None)
    flow: str | None = Field(default=None)
    seed: str | None = Field(default=None)
    encryption: str | None = Field(default=None)
    reverse: VLessReverseConfig | None = Field(default=None)
    testpre: int | None = Field(default=None)
    testseed: list[int] | None = Field(default=None)
    vnext: list[VLessOutboundVnext] | None = Field(default=None)

class VLessOutboundVnext(ConfModel):
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    users: list[JsonValue] | None = Field(default=None)

class VLessReverseConfig(ConfModel):
    """Go semantics: Build() in Go."""
    tag: str | None = Field(default=None)
    sniffing: SniffingConfig | None = Field(default=None)

__all__ = [
    "VLessInboundConfig",
    "VLessInboundFallback",
    "VLessOutboundConfig",
    "VLessOutboundVnext",
    "VLessReverseConfig",
]
