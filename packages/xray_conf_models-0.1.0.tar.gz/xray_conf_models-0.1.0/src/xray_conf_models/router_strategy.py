"""Auto-generated human-facing Xray config models from `router_strategy.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class healthCheckSettings(ConfModel):
    """healthCheckSettings holds settings for health Checker Go semantics: Build() in Go."""
    destination: str | None = Field(default=None)
    connectivity: str | None = Field(default=None)
    interval: str | int | float | None = Field(default=None)
    sampling: int | None = Field(default=None)
    timeout: str | int | float | None = Field(default=None)
    http_method: str | None = Field(default=None, alias="httpMethod")

__all__ = [
    "healthCheckSettings",
]
