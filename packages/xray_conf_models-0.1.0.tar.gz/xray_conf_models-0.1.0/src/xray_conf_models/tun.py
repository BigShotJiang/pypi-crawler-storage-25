"""Auto-generated human-facing Xray config models from `tun.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class TunConfig(ConfModel):
    """Go semantics: Build() in Go."""
    name: str | None = Field(default=None)
    mtu: int | None = Field(default=None, alias="MTU")
    user_level: int | None = Field(default=None, alias="userLevel")

__all__ = [
    "TunConfig",
]
