"""Auto-generated human-facing Xray config models from `router.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class BalancingRule(ConfModel):
    """Go semantics: Build() in Go."""
    tag: str | None = Field(default=None)
    selector: StringList | JsonValue | None = Field(default=None)
    strategy: StrategyConfig | None = Field(default=None)
    fallback_tag: str | None = Field(default=None, alias="fallbackTag")

class RouterConfig(ConfModel):
    """Go semantics: Build() in Go."""
    rules: list[JsonValue] | None = Field(default=None)
    domain_strategy: str | None = Field(default=None, alias="domainStrategy")
    balancers: list[BalancingRule] | None = Field(default=None)

class StrategyConfig(ConfModel):
    """StrategyConfig represents a strategy config"""
    type: str | None = Field(default=None)
    settings: JsonValue | None = Field(default=None)

__all__ = [
    "BalancingRule",
    "RouterConfig",
    "StrategyConfig",
]
