"""Auto-generated human-facing Xray config models from `fakedns.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

"""Go semantics: custom UnmarshalJSON, custom MarshalJSON, Build() in Go."""
FakeDNSConfig: TypeAlias = JsonValue

__all__ = [
    "FakeDNSConfig",
]
