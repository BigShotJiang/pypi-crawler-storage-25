"""Auto-generated human-facing Xray config models from `metrics.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class MetricsConfig(ConfModel):
    """Go semantics: Build() in Go."""
    tag: str | None = Field(default=None)
    listen: str | None = Field(default=None)

__all__ = [
    "MetricsConfig",
]
