"""Auto-generated human-facing Xray config models from `observatory.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class BurstObservatoryConfig(ConfModel):
    """Go semantics: Build() in Go."""
    subject_selector: list[str] | None = Field(default=None, alias="subjectSelector")
    ping_config: healthCheckSettings | None = Field(default=None, alias="pingConfig", description="health check settings")

class ObservatoryConfig(ConfModel):
    """Go semantics: Build() in Go."""
    subject_selector: list[str] | None = Field(default=None, alias="subjectSelector")
    probe_url: str | None = Field(default=None, alias="probeURL")
    probe_interval: str | int | float | None = Field(default=None, alias="probeInterval")
    enable_concurrency: bool | None = Field(default=None, alias="enableConcurrency")

__all__ = [
    "BurstObservatoryConfig",
    "ObservatoryConfig",
]
