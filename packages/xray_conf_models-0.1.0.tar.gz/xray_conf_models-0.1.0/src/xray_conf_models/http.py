"""Auto-generated human-facing Xray config models from `http.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class HTTPAccount(ConfModel):
    """Go semantics: Build() in Go."""
    user: str | None = Field(default=None)
    pass_: str | None = Field(default=None, alias="pass")

class HTTPClientConfig(ConfModel):
    """Go semantics: Build() in Go."""
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    level: int | None = Field(default=None)
    email: str | None = Field(default=None)
    user: str | None = Field(default=None)
    pass_: str | None = Field(default=None, alias="pass")
    servers: list[HTTPRemoteConfig] | None = Field(default=None)
    headers: dict[str, str] | None = Field(default=None)

class HTTPRemoteConfig(ConfModel):
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    users: list[JsonValue] | None = Field(default=None)

class HTTPServerConfig(ConfModel):
    """Go semantics: Build() in Go."""
    accounts: list[HTTPAccount] | None = Field(default=None)
    allow_transparent: bool | None = Field(default=None, alias="allowTransparent")
    user_level: int | None = Field(default=None, alias="userLevel")

__all__ = [
    "HTTPAccount",
    "HTTPClientConfig",
    "HTTPRemoteConfig",
    "HTTPServerConfig",
]
