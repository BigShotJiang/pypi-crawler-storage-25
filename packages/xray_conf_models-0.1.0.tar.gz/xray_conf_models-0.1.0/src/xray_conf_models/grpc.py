"""Auto-generated human-facing Xray config models from `grpc.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class GRPCConfig(ConfModel):
    """Go semantics: Build() in Go."""
    authority: str | None = Field(default=None)
    service_name: str | None = Field(default=None, alias="serviceName")
    multi_mode: bool | None = Field(default=None, alias="multiMode")
    idle_timeout: int | None = Field(default=None)
    health_check_timeout: int | None = Field(default=None)
    permit_without_stream: bool | None = Field(default=None)
    initial_windows_size: int | None = Field(default=None)
    user_agent: str | None = Field(default=None)

__all__ = [
    "GRPCConfig",
]
