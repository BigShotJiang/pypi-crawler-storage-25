"""Auto-generated human-facing Xray config models from `reverse.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class BridgeConfig(ConfModel):
    """Go semantics: Build() in Go."""
    tag: str | None = Field(default=None)
    domain: str | None = Field(default=None)

class PortalConfig(ConfModel):
    """Go semantics: Build() in Go."""
    tag: str | None = Field(default=None)
    domain: str | None = Field(default=None)

class ReverseConfig(ConfModel):
    """Go semantics: Build() in Go."""
    bridges: list[BridgeConfig] | None = Field(default=None)
    portals: list[PortalConfig] | None = Field(default=None)

__all__ = [
    "BridgeConfig",
    "PortalConfig",
    "ReverseConfig",
]
