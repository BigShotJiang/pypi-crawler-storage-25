"""Auto-generated human-facing Xray config models from `dokodemo.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class DokodemoConfig(ConfModel):
    """Go semantics: Build() in Go."""
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    port_map: dict[str, str] | None = Field(default=None, alias="portMap")
    network: NetworkList | JsonValue | None = Field(default=None)
    follow_redirect: bool | None = Field(default=None, alias="followRedirect")
    user_level: int | None = Field(default=None, alias="userLevel")

__all__ = [
    "DokodemoConfig",
]
