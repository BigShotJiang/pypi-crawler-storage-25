"""Auto-generated human-facing Xray config models from `log.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class LogConfig(ConfModel):
    """Go semantics: Build() in Go."""
    access: str | None = Field(default=None)
    error: str | None = Field(default=None)
    loglevel: str | None = Field(default=None)
    dns_log: bool | None = Field(default=None, alias="dnsLog")
    mask_address: str | None = Field(default=None, alias="maskAddress")

__all__ = [
    "LogConfig",
]
