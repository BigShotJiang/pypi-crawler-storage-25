"""Auto-generated human-facing Xray config models from `version.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class VersionConfig(ConfModel):
    """Go semantics: Build() in Go."""
    min: str | None = Field(default=None)
    max: str | None = Field(default=None)

__all__ = [
    "VersionConfig",
]
