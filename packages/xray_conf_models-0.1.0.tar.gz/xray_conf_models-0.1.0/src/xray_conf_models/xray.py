"""Auto-generated human-facing Xray config models from `xray.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class Config(ConfModel):
    """Go semantics: Build() in Go, Override() in Go."""
    transport: dict[str, JsonValue] | None = Field(default=None, description="Deprecated: Global transport config is no longer used left for returning error")
    log: LogConfig | None = Field(default=None)
    routing: RouterConfig | None = Field(default=None)
    dns: DNSConfig | None = Field(default=None)
    inbounds: list[InboundDetourConfig] | None = Field(default=None)
    outbounds: list[OutboundDetourConfig] | None = Field(default=None)
    policy: PolicyConfig | None = Field(default=None)
    api: APIConfig | None = Field(default=None)
    metrics: MetricsConfig | None = Field(default=None)
    stats: StatsConfig | None = Field(default=None)
    reverse: ReverseConfig | None = Field(default=None)
    fake_dns: FakeDNSConfig | JsonValue | None = Field(default=None, alias="fakeDns")
    observatory: ObservatoryConfig | None = Field(default=None)
    burst_observatory: BurstObservatoryConfig | None = Field(default=None, alias="burstObservatory")
    version: VersionConfig | None = Field(default=None)

class InboundDetourConfig(ConfModel):
    """Go semantics: Build() in Go."""
    protocol: Literal['dokodemo-door', 'http', 'hysteria', 'mixed', 'shadowsocks', 'socks', 'trojan', 'tun', 'tunnel', 'vless', 'vmess', 'wireguard'] | None = Field(default=None)
    port: PortList | JsonValue | None = Field(default=None)
    listen: Address | JsonValue | None = Field(default=None)
    settings: DokodemoConfig | HTTPServerConfig | HysteriaServerConfig | ShadowsocksServerConfig | SocksServerConfig | TrojanServerConfig | TunConfig | VLessInboundConfig | VMessInboundConfig | WireGuardConfig | JsonValue | None = Field(default=None)
    tag: str | None = Field(default=None)
    stream_settings: StreamConfig | None = Field(default=None, alias="streamSettings")
    sniffing: SniffingConfig | None = Field(default=None)

class MuxConfig(ConfModel):
    """Go semantics: Build() in Go."""
    enabled: bool | None = Field(default=None)
    concurrency: int | None = Field(default=None)
    xudp_concurrency: int | None = Field(default=None, alias="xudpConcurrency")
    xudp_proxy_udp443: str | None = Field(default=None, alias="xudpProxyUDP443")

class OutboundDetourConfig(ConfModel):
    """Go semantics: Build() in Go."""
    protocol: Literal['blackhole', 'block', 'direct', 'dns', 'freedom', 'http', 'hysteria', 'loopback', 'shadowsocks', 'socks', 'trojan', 'vless', 'vmess', 'wireguard'] | None = Field(default=None)
    send_through: str | None = Field(default=None, alias="sendThrough")
    tag: str | None = Field(default=None)
    settings: BlackholeConfig | DNSOutboundConfig | FreedomConfig | HTTPClientConfig | HysteriaClientConfig | LoopbackConfig | ShadowsocksClientConfig | SocksClientConfig | TrojanClientConfig | VLessOutboundConfig | VMessOutboundConfig | WireGuardConfig | JsonValue | None = Field(default=None)
    stream_settings: StreamConfig | None = Field(default=None, alias="streamSettings")
    proxy_settings: ProxyConfig | None = Field(default=None, alias="proxySettings")
    mux: MuxConfig | None = Field(default=None)
    target_strategy: str | None = Field(default=None, alias="targetStrategy")

class SniffingConfig(ConfModel):
    """Go semantics: Build() in Go."""
    enabled: bool | None = Field(default=None)
    dest_override: StringList | JsonValue | None = Field(default=None, alias="destOverride")
    domains_excluded: StringList | JsonValue | None = Field(default=None, alias="domainsExcluded")
    metadata_only: bool | None = Field(default=None, alias="metadataOnly")
    route_only: bool | None = Field(default=None, alias="routeOnly")

class StatsConfig(ConfModel):
    """Go semantics: Build() in Go."""
    pass

__all__ = [
    "Config",
    "InboundDetourConfig",
    "MuxConfig",
    "OutboundDetourConfig",
    "SniffingConfig",
    "StatsConfig",
]
