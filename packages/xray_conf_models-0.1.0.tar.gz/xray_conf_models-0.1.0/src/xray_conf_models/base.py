"""Base runtime for generated human-facing config models."""

from __future__ import annotations

import json
from typing import Any, TypeAlias

from pydantic import BaseModel, ConfigDict

JsonValue: TypeAlias = dict[str, Any] | list[Any] | str | int | float | bool | None


class ConfModel(BaseModel):
    """Base class for generated `infra/conf`-shaped models."""

    model_config = ConfigDict(
        populate_by_name=True,
        extra="forbid",
        arbitrary_types_allowed=True,
    )

    def to_native_dict(self, *, exclude_none: bool = True) -> dict[str, Any]:
        return self.model_dump(by_alias=True, exclude_none=exclude_none)

    def to_native_json(self, *, exclude_none: bool = True, indent: int = 2) -> str:
        return json.dumps(self.to_native_dict(exclude_none=exclude_none), ensure_ascii=False, indent=indent)

    @classmethod
    def from_native_dict(cls, data: dict[str, Any]):
        return cls.model_validate(data)

    @classmethod
    def from_native_json(cls, data: str):
        return cls.model_validate(json.loads(data))
