"""Auto-generated human-facing Xray config models from `common.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

"""Go semantics: custom UnmarshalJSON, custom MarshalJSON, Build() in Go."""
Address: TypeAlias = JsonValue

class Int32Range(ConfModel):
    """Int32Range deserializes from \"1-2\" or 1, so can deserialize from both int and number. Negative integers can be passed as sentinel values, but do not parse as ranges. Value will be exchanged if From > To, use .Left and .Right to get original value if need. Go semantics: custom UnmarshalJSON, custom MarshalJSON."""
    left: int | None = Field(default=None, alias="Left")
    right: int | None = Field(default=None, alias="Right")
    from_: int | None = Field(default=None, alias="From")
    to: int | None = Field(default=None, alias="To")

"""Go semantics: Build() in Go."""
Network: TypeAlias = str

"""Go semantics: custom UnmarshalJSON, Build() in Go."""
NetworkList: TypeAlias = list[Network]

class PortList(ConfModel):
    """Go semantics: custom UnmarshalJSON, custom MarshalJSON, Build() in Go."""
    range: list[PortRange | JsonValue] | None = Field(default=None, alias="Range")

class PortRange(ConfModel):
    """Go semantics: custom UnmarshalJSON, custom MarshalJSON, Build() in Go."""
    from_: int | None = Field(default=None, alias="From")
    to: int | None = Field(default=None, alias="To")

"""Go semantics: custom UnmarshalJSON."""
StringList: TypeAlias = list[str]

__all__ = [
    "Address",
    "Int32Range",
    "Network",
    "NetworkList",
    "PortList",
    "PortRange",
    "StringList",
]
