"""Auto-generated human-facing Xray config models from `loopback.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class LoopbackConfig(ConfModel):
    """Go semantics: Build() in Go."""
    inbound_tag: str | None = Field(default=None, alias="inboundTag")

__all__ = [
    "LoopbackConfig",
]
