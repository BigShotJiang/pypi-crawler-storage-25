"""Auto-generated human-facing Xray config models from `dns_proxy.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class DNSOutboundConfig(ConfModel):
    """Go semantics: Build() in Go."""
    network: Network | None = Field(default=None)
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    user_level: int | None = Field(default=None, alias="userLevel")
    non_ip_query: str | None = Field(default=None, alias="nonIPQuery")
    block_types: list[int] | None = Field(default=None, alias="blockTypes")

__all__ = [
    "DNSOutboundConfig",
]
