"""Auto-generated human-facing Xray config models from `dns.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class DNSConfig(ConfModel):
    """DNSConfig is a JSON serializable object for dns.Config. Go semantics: Build() in Go."""
    servers: list[NameServerConfig | JsonValue] | None = Field(default=None)
    hosts: HostsWrapper | JsonValue | None = Field(default=None)
    client_ip: Address | JsonValue | None = Field(default=None, alias="clientIp")
    tag: str | None = Field(default=None)
    query_strategy: str | None = Field(default=None, alias="queryStrategy")
    disable_cache: bool | None = Field(default=None, alias="disableCache")
    serve_stale: bool | None = Field(default=None, alias="serveStale")
    serve_expired_ttl: int | None = Field(default=None, alias="serveExpiredTTL")
    disable_fallback: bool | None = Field(default=None, alias="disableFallback")
    disable_fallback_if_match: bool | None = Field(default=None, alias="disableFallbackIfMatch")
    enable_parallel_query: bool | None = Field(default=None, alias="enableParallelQuery")
    use_system_hosts: bool | None = Field(default=None, alias="useSystemHosts")

"""Go semantics: custom UnmarshalJSON, custom MarshalJSON."""
HostAddress: TypeAlias = JsonValue

class HostsWrapper(ConfModel):
    """Go semantics: custom UnmarshalJSON, custom MarshalJSON, Build() in Go."""
    hosts: dict[str, HostAddress | JsonValue] | None = Field(default=None, alias="Hosts")

class NameServerConfig(ConfModel):
    """Go semantics: custom UnmarshalJSON, Build() in Go."""
    address: Address | JsonValue | None = Field(default=None)
    client_ip: Address | JsonValue | None = Field(default=None, alias="clientIp")
    port: int | None = Field(default=None)
    skip_fallback: bool | None = Field(default=None, alias="skipFallback")
    domains: list[str] | None = Field(default=None)
    expected_i_ps: StringList | JsonValue | None = Field(default=None, alias="expectedIPs")
    expect_i_ps: StringList | JsonValue | None = Field(default=None, alias="expectIPs")
    query_strategy: str | None = Field(default=None, alias="queryStrategy")
    tag: str | None = Field(default=None)
    timeout_ms: int | None = Field(default=None, alias="timeoutMs")
    disable_cache: bool | None = Field(default=None, alias="disableCache")
    serve_stale: bool | None = Field(default=None, alias="serveStale")
    serve_expired_ttl: int | None = Field(default=None, alias="serveExpiredTTL")
    final_query: bool | None = Field(default=None, alias="finalQuery")
    unexpected_i_ps: StringList | JsonValue | None = Field(default=None, alias="unexpectedIPs")

__all__ = [
    "DNSConfig",
    "HostAddress",
    "HostsWrapper",
    "NameServerConfig",
]
