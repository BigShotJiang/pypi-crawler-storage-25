"""Auto-generated human-facing Xray config models from `transport_internet.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

Bandwidth: TypeAlias = str

class CustomSockoptConfig(ConfModel):
    system: str | None = Field(default=None)
    network: str | None = Field(default=None)
    level: str | None = Field(default=None)
    opt: str | None = Field(default=None)
    value: str | None = Field(default=None)
    type: str | None = Field(default=None)

class FinalMask(ConfModel):
    tcp: list[Mask] | None = Field(default=None)
    udp: list[Mask] | None = Field(default=None)
    quic_params: QuicParamsConfig | None = Field(default=None, alias="quicParams")

class HappyEyeballsConfig(ConfModel):
    """Go semantics: custom UnmarshalJSON."""
    prioritize_i_pv6: bool | None = Field(default=None, alias="prioritizeIPv6")
    try_delay_ms: int | None = Field(default=None, alias="tryDelayMs")
    interleave: int | None = Field(default=None)
    max_concurrent_try: int | None = Field(default=None, alias="maxConcurrentTry")

class HttpUpgradeConfig(ConfModel):
    """Go semantics: Build() in Go."""
    host: str | None = Field(default=None)
    path: str | None = Field(default=None)
    headers: dict[str, str] | None = Field(default=None)
    accept_proxy_protocol: bool | None = Field(default=None, alias="acceptProxyProtocol")

class HysteriaConfig(ConfModel):
    """Go semantics: Build() in Go."""
    version: int | None = Field(default=None)
    auth: str | None = Field(default=None)
    congestion: str | None = Field(default=None)
    up: Bandwidth | None = Field(default=None)
    down: Bandwidth | None = Field(default=None)
    udphop: UdpHop | None = Field(default=None)
    udp_idle_timeout: int | None = Field(default=None, alias="udpIdleTimeout")
    masquerade: Masquerade | None = Field(default=None)

class KCPConfig(ConfModel):
    """Go semantics: Build() in Go."""
    mtu: int | None = Field(default=None)
    tti: int | None = Field(default=None)
    uplink_capacity: int | None = Field(default=None, alias="uplinkCapacity")
    downlink_capacity: int | None = Field(default=None, alias="downlinkCapacity")
    congestion: bool | None = Field(default=None)
    read_buffer_size: int | None = Field(default=None, alias="readBufferSize")
    write_buffer_size: int | None = Field(default=None, alias="writeBufferSize")
    header: JsonValue | None = Field(default=None)
    seed: str | None = Field(default=None)

class LimitFallback(ConfModel):
    after_bytes: int | None = Field(default=None, alias="AfterBytes")
    bytes_per_sec: int | None = Field(default=None, alias="BytesPerSec")
    burst_bytes_per_sec: int | None = Field(default=None, alias="BurstBytesPerSec")

class Mask(ConfModel):
    """Go semantics: Build() in Go."""
    type: str | None = Field(default=None)
    settings: JsonValue | None = Field(default=None)

class Masquerade(ConfModel):
    type: str | None = Field(default=None)
    dir: str | None = Field(default=None)
    url: str | None = Field(default=None)
    rewrite_host: bool | None = Field(default=None, alias="rewriteHost")
    insecure: bool | None = Field(default=None)
    content: str | None = Field(default=None)
    headers: dict[str, str] | None = Field(default=None)
    status_code: int | None = Field(default=None, alias="statusCode")

class ProxyConfig(ConfModel):
    """Go semantics: Build() in Go."""
    tag: str | None = Field(default=None)
    transport_layer: bool | None = Field(default=None, alias="transportLayer", description="TransportLayerProxy: For compatibility.")

class QuicParamsConfig(ConfModel):
    congestion: str | None = Field(default=None)
    debug: bool | None = Field(default=None)
    brutal_up: Bandwidth | None = Field(default=None, alias="brutalUp")
    brutal_down: Bandwidth | None = Field(default=None, alias="brutalDown")
    udp_hop: UdpHop | None = Field(default=None, alias="udpHop")
    init_stream_receive_window: int | None = Field(default=None, alias="initStreamReceiveWindow")
    max_stream_receive_window: int | None = Field(default=None, alias="maxStreamReceiveWindow")
    init_connection_receive_window: int | None = Field(default=None, alias="initConnectionReceiveWindow")
    max_connection_receive_window: int | None = Field(default=None, alias="maxConnectionReceiveWindow")
    max_idle_timeout: int | None = Field(default=None, alias="maxIdleTimeout")
    keep_alive_period: int | None = Field(default=None, alias="keepAlivePeriod")
    disable_path_mtu_discovery: bool | None = Field(default=None, alias="disablePathMTUDiscovery")
    max_incoming_streams: int | None = Field(default=None, alias="maxIncomingStreams")

class REALITYConfig(ConfModel):
    """Go semantics: Build() in Go."""
    master_key_log: str | None = Field(default=None, alias="masterKeyLog")
    show: bool | None = Field(default=None)
    target: JsonValue | None = Field(default=None)
    dest: JsonValue | None = Field(default=None)
    type: str | None = Field(default=None)
    xver: int | None = Field(default=None)
    server_names: list[str] | None = Field(default=None, alias="serverNames")
    private_key: str | None = Field(default=None, alias="privateKey")
    min_client_ver: str | None = Field(default=None, alias="minClientVer")
    max_client_ver: str | None = Field(default=None, alias="maxClientVer")
    max_time_diff: int | None = Field(default=None, alias="maxTimeDiff")
    short_ids: list[str] | None = Field(default=None, alias="shortIds")
    mldsa65_seed: str | None = Field(default=None, alias="mldsa65Seed")
    limit_fallback_upload: LimitFallback | None = Field(default=None, alias="limitFallbackUpload")
    limit_fallback_download: LimitFallback | None = Field(default=None, alias="limitFallbackDownload")
    fingerprint: str | None = Field(default=None)
    server_name: str | None = Field(default=None, alias="serverName")
    password: str | None = Field(default=None)
    public_key: str | None = Field(default=None, alias="publicKey")
    short_id: str | None = Field(default=None, alias="shortId")
    mldsa65_verify: str | None = Field(default=None, alias="mldsa65Verify")
    spider_x: str | None = Field(default=None, alias="spiderX")

class SocketConfig(ConfModel):
    """Go semantics: Build() in Go."""
    mark: int | None = Field(default=None)
    tcp_fast_open: Any | None = Field(default=None, alias="tcpFastOpen")
    tproxy: str | None = Field(default=None)
    accept_proxy_protocol: bool | None = Field(default=None, alias="acceptProxyProtocol")
    domain_strategy: str | None = Field(default=None, alias="domainStrategy")
    dialer_proxy: str | None = Field(default=None, alias="dialerProxy")
    tcp_keep_alive_interval: int | None = Field(default=None, alias="tcpKeepAliveInterval")
    tcp_keep_alive_idle: int | None = Field(default=None, alias="tcpKeepAliveIdle")
    tcp_congestion: str | None = Field(default=None, alias="tcpCongestion")
    tcp_window_clamp: int | None = Field(default=None, alias="tcpWindowClamp")
    tcp_max_seg: int | None = Field(default=None, alias="tcpMaxSeg")
    penetrate: bool | None = Field(default=None)
    tcp_user_timeout: int | None = Field(default=None, alias="tcpUserTimeout")
    v6only: bool | None = Field(default=None)
    interface: str | None = Field(default=None)
    tcp_mptcp: bool | None = Field(default=None, alias="tcpMptcp")
    custom_sockopt: list[CustomSockoptConfig] | None = Field(default=None, alias="customSockopt")
    address_port_strategy: str | None = Field(default=None, alias="addressPortStrategy")
    happy_eyeballs: HappyEyeballsConfig | JsonValue | None = Field(default=None, alias="happyEyeballs")
    trusted_x_forwarded_for: list[str] | None = Field(default=None, alias="trustedXForwardedFor")

class SplitHTTPConfig(ConfModel):
    """Go semantics: Build() in Go."""
    host: str | None = Field(default=None)
    path: str | None = Field(default=None)
    mode: str | None = Field(default=None)
    headers: dict[str, str] | None = Field(default=None)
    x_padding_bytes: Int32Range | JsonValue | None = Field(default=None, alias="xPaddingBytes")
    x_padding_obfs_mode: bool | None = Field(default=None, alias="xPaddingObfsMode")
    x_padding_key: str | None = Field(default=None, alias="xPaddingKey")
    x_padding_header: str | None = Field(default=None, alias="xPaddingHeader")
    x_padding_placement: str | None = Field(default=None, alias="xPaddingPlacement")
    x_padding_method: str | None = Field(default=None, alias="xPaddingMethod")
    uplink_http_method: str | None = Field(default=None, alias="uplinkHTTPMethod")
    session_placement: str | None = Field(default=None, alias="sessionPlacement")
    session_key: str | None = Field(default=None, alias="sessionKey")
    seq_placement: str | None = Field(default=None, alias="seqPlacement")
    seq_key: str | None = Field(default=None, alias="seqKey")
    uplink_data_placement: str | None = Field(default=None, alias="uplinkDataPlacement")
    uplink_data_key: str | None = Field(default=None, alias="uplinkDataKey")
    uplink_chunk_size: Int32Range | JsonValue | None = Field(default=None, alias="uplinkChunkSize")
    no_grpc_header: bool | None = Field(default=None, alias="noGRPCHeader")
    no_sse_header: bool | None = Field(default=None, alias="noSSEHeader")
    sc_max_each_post_bytes: Int32Range | JsonValue | None = Field(default=None, alias="scMaxEachPostBytes")
    sc_min_posts_interval_ms: Int32Range | JsonValue | None = Field(default=None, alias="scMinPostsIntervalMs")
    sc_max_buffered_posts: int | None = Field(default=None, alias="scMaxBufferedPosts")
    sc_stream_up_server_secs: Int32Range | JsonValue | None = Field(default=None, alias="scStreamUpServerSecs")
    server_max_header_bytes: int | None = Field(default=None, alias="serverMaxHeaderBytes")
    xmux: XmuxConfig | None = Field(default=None)
    download_settings: StreamConfig | None = Field(default=None, alias="downloadSettings")
    extra: JsonValue | None = Field(default=None)

class StreamConfig(ConfModel):
    """Go semantics: Build() in Go."""
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    network: TransportProtocol | None = Field(default=None)
    security: str | None = Field(default=None)
    finalmask: FinalMask | None = Field(default=None)
    tls_settings: TLSConfig | None = Field(default=None, alias="tlsSettings")
    reality_settings: REALITYConfig | None = Field(default=None, alias="realitySettings")
    raw_settings: TCPConfig | None = Field(default=None, alias="rawSettings")
    tcp_settings: TCPConfig | None = Field(default=None, alias="tcpSettings")
    xhttp_settings: SplitHTTPConfig | None = Field(default=None, alias="xhttpSettings")
    splithttp_settings: SplitHTTPConfig | None = Field(default=None, alias="splithttpSettings")
    kcp_settings: KCPConfig | None = Field(default=None, alias="kcpSettings")
    grpc_settings: GRPCConfig | None = Field(default=None, alias="grpcSettings")
    ws_settings: WebSocketConfig | None = Field(default=None, alias="wsSettings")
    httpupgrade_settings: HttpUpgradeConfig | None = Field(default=None, alias="httpupgradeSettings")
    hysteria_settings: HysteriaConfig | None = Field(default=None, alias="hysteriaSettings")
    sockopt: SocketConfig | None = Field(default=None)

class TCPConfig(ConfModel):
    """Go semantics: Build() in Go."""
    header: Authenticator | NoOpConnectionAuthenticator | JsonValue | None = Field(default=None)
    accept_proxy_protocol: bool | None = Field(default=None, alias="acceptProxyProtocol")

class TLSCertConfig(ConfModel):
    """Go semantics: Build() in Go."""
    certificate_file: str | None = Field(default=None, alias="certificateFile")
    certificate: list[str] | None = Field(default=None)
    key_file: str | None = Field(default=None, alias="keyFile")
    key: list[str] | None = Field(default=None)
    usage: str | None = Field(default=None)
    ocsp_stapling: int | None = Field(default=None, alias="ocspStapling")
    one_time_loading: bool | None = Field(default=None, alias="oneTimeLoading")
    build_chain: bool | None = Field(default=None, alias="buildChain")

class TLSConfig(ConfModel):
    """Go semantics: Build() in Go."""
    allow_insecure: bool | None = Field(default=None, alias="allowInsecure")
    certificates: list[TLSCertConfig] | None = Field(default=None)
    server_name: str | None = Field(default=None, alias="serverName")
    alpn: StringList | JsonValue | None = Field(default=None)
    enable_session_resumption: bool | None = Field(default=None, alias="enableSessionResumption")
    disable_system_root: bool | None = Field(default=None, alias="disableSystemRoot")
    min_version: str | None = Field(default=None, alias="minVersion")
    max_version: str | None = Field(default=None, alias="maxVersion")
    cipher_suites: str | None = Field(default=None, alias="cipherSuites")
    fingerprint: str | None = Field(default=None)
    reject_unknown_sni: bool | None = Field(default=None, alias="rejectUnknownSni")
    curve_preferences: StringList | JsonValue | None = Field(default=None, alias="curvePreferences")
    master_key_log: str | None = Field(default=None, alias="masterKeyLog")
    pinned_peer_cert_sha256: str | None = Field(default=None, alias="pinnedPeerCertSha256")
    verify_peer_cert_by_name: str | None = Field(default=None, alias="verifyPeerCertByName")
    verify_peer_cert_in_names: list[str] | None = Field(default=None, alias="verifyPeerCertInNames")
    ech_server_keys: str | None = Field(default=None, alias="echServerKeys")
    ech_config_list: str | None = Field(default=None, alias="echConfigList")
    ech_force_query: str | None = Field(default=None, alias="echForceQuery")
    ech_sockopt: SocketConfig | None = Field(default=None, alias="echSockopt")

"""Go semantics: Build() in Go."""
TransportProtocol: TypeAlias = str

class UdpHop(ConfModel):
    ports: JsonValue | None = Field(default=None)
    interval: Int32Range | JsonValue | None = Field(default=None)

class WebSocketConfig(ConfModel):
    """Go semantics: Build() in Go."""
    host: str | None = Field(default=None)
    path: str | None = Field(default=None)
    headers: dict[str, str] | None = Field(default=None)
    accept_proxy_protocol: bool | None = Field(default=None, alias="acceptProxyProtocol")
    heartbeat_period: int | None = Field(default=None, alias="heartbeatPeriod")

class XmuxConfig(ConfModel):
    max_concurrency: Int32Range | JsonValue | None = Field(default=None, alias="maxConcurrency")
    max_connections: Int32Range | JsonValue | None = Field(default=None, alias="maxConnections")
    c_max_reuse_times: Int32Range | JsonValue | None = Field(default=None, alias="cMaxReuseTimes")
    h_max_request_times: Int32Range | JsonValue | None = Field(default=None, alias="hMaxRequestTimes")
    h_max_reusable_secs: Int32Range | JsonValue | None = Field(default=None, alias="hMaxReusableSecs")
    h_keep_alive_period: int | None = Field(default=None, alias="hKeepAlivePeriod")

__all__ = [
    "Bandwidth",
    "CustomSockoptConfig",
    "FinalMask",
    "HappyEyeballsConfig",
    "HttpUpgradeConfig",
    "HysteriaConfig",
    "KCPConfig",
    "LimitFallback",
    "Mask",
    "Masquerade",
    "ProxyConfig",
    "QuicParamsConfig",
    "REALITYConfig",
    "SocketConfig",
    "SplitHTTPConfig",
    "StreamConfig",
    "TCPConfig",
    "TLSCertConfig",
    "TLSConfig",
    "TransportProtocol",
    "UdpHop",
    "WebSocketConfig",
    "XmuxConfig",
]
