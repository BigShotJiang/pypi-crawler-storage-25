"""Auto-generated human-facing Xray config models from `vmess.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class VMessDefaultConfig(ConfModel):
    """Go semantics: Build() in Go."""
    level: int | None = Field(default=None)

class VMessInboundConfig(ConfModel):
    """Go semantics: Build() in Go."""
    clients: list[JsonValue] | None = Field(default=None)
    default: VMessDefaultConfig | None = Field(default=None)

class VMessOutboundConfig(ConfModel):
    """Go semantics: Build() in Go."""
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    level: int | None = Field(default=None)
    email: str | None = Field(default=None)
    id: str | None = Field(default=None)
    security: str | None = Field(default=None)
    experiments: str | None = Field(default=None)
    vnext: list[VMessOutboundTarget] | None = Field(default=None)

class VMessOutboundTarget(ConfModel):
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    users: list[JsonValue] | None = Field(default=None)

__all__ = [
    "VMessDefaultConfig",
    "VMessInboundConfig",
    "VMessOutboundConfig",
    "VMessOutboundTarget",
]
