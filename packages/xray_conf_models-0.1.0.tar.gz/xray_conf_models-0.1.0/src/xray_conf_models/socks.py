"""Auto-generated human-facing Xray config models from `socks.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class SocksAccount(ConfModel):
    """Go semantics: Build() in Go."""
    user: str | None = Field(default=None)
    pass_: str | None = Field(default=None, alias="pass")

class SocksClientConfig(ConfModel):
    """Go semantics: Build() in Go."""
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    level: int | None = Field(default=None)
    email: str | None = Field(default=None)
    user: str | None = Field(default=None)
    pass_: str | None = Field(default=None, alias="pass")
    servers: list[SocksRemoteConfig] | None = Field(default=None)

class SocksRemoteConfig(ConfModel):
    address: Address | JsonValue | None = Field(default=None)
    port: int | None = Field(default=None)
    users: list[JsonValue] | None = Field(default=None)

class SocksServerConfig(ConfModel):
    """Go semantics: Build() in Go."""
    auth: str | None = Field(default=None)
    accounts: list[SocksAccount] | None = Field(default=None)
    udp: bool | None = Field(default=None)
    ip: Address | JsonValue | None = Field(default=None)
    user_level: int | None = Field(default=None, alias="userLevel")

__all__ = [
    "SocksAccount",
    "SocksClientConfig",
    "SocksRemoteConfig",
    "SocksServerConfig",
]
