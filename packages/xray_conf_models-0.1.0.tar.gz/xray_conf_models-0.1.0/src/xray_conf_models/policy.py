"""Auto-generated human-facing Xray config models from `policy.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class Policy(ConfModel):
    """Go semantics: Build() in Go."""
    handshake: int | None = Field(default=None)
    conn_idle: int | None = Field(default=None, alias="connIdle")
    uplink_only: int | None = Field(default=None, alias="uplinkOnly")
    downlink_only: int | None = Field(default=None, alias="downlinkOnly")
    stats_user_uplink: bool | None = Field(default=None, alias="statsUserUplink")
    stats_user_downlink: bool | None = Field(default=None, alias="statsUserDownlink")
    stats_user_online: bool | None = Field(default=None, alias="statsUserOnline")
    buffer_size: int | None = Field(default=None, alias="bufferSize")

class PolicyConfig(ConfModel):
    """Go semantics: Build() in Go."""
    levels: dict[int, Policy] | None = Field(default=None)
    system: SystemPolicy | None = Field(default=None)

class SystemPolicy(ConfModel):
    """Go semantics: Build() in Go."""
    stats_inbound_uplink: bool | None = Field(default=None, alias="statsInboundUplink")
    stats_inbound_downlink: bool | None = Field(default=None, alias="statsInboundDownlink")
    stats_outbound_uplink: bool | None = Field(default=None, alias="statsOutboundUplink")
    stats_outbound_downlink: bool | None = Field(default=None, alias="statsOutboundDownlink")

__all__ = [
    "Policy",
    "PolicyConfig",
    "SystemPolicy",
]
