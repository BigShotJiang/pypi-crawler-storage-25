"""Auto-generated human-facing Xray config models from `blackhole.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class BlackholeConfig(ConfModel):
    """Go semantics: Build() in Go."""
    response: JsonValue | None = Field(default=None)

__all__ = [
    "BlackholeConfig",
]
