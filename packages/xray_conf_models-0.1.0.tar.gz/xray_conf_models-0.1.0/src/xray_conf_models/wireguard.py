"""Auto-generated human-facing Xray config models from `wireguard.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class WireGuardConfig(ConfModel):
    """Go semantics: Build() in Go."""
    is_client: bool | None = Field(default=None, alias="IsClient")
    no_kernel_tun: bool | None = Field(default=None, alias="noKernelTun")
    secret_key: str | None = Field(default=None, alias="secretKey")
    address: list[str] | None = Field(default=None)
    peers: list[WireGuardPeerConfig] | None = Field(default=None)
    mtu: int | None = Field(default=None)
    workers: int | None = Field(default=None)
    reserved: list[int] | None = Field(default=None)
    domain_strategy: str | None = Field(default=None, alias="domainStrategy")

class WireGuardPeerConfig(ConfModel):
    """Go semantics: Build() in Go."""
    public_key: str | None = Field(default=None, alias="publicKey")
    pre_shared_key: str | None = Field(default=None, alias="preSharedKey")
    endpoint: str | None = Field(default=None)
    keep_alive: int | None = Field(default=None, alias="keepAlive")
    allowed_i_ps: list[str] | None = Field(default=None, alias="allowedIPs")

__all__ = [
    "WireGuardConfig",
    "WireGuardPeerConfig",
]
