"""Auto-generated human-facing Xray config models from `transport_authenticators.go`."""

from __future__ import annotations

from typing import Any, Literal, TypeAlias

from pydantic import Field

from xray_conf_models.base import ConfModel, JsonValue

class Authenticator(ConfModel):
    """Go semantics: Build() in Go."""
    request: AuthenticatorRequest | None = Field(default=None)
    response: AuthenticatorResponse | None = Field(default=None)

class AuthenticatorRequest(ConfModel):
    """Go semantics: Build() in Go."""
    version: str | None = Field(default=None)
    method: str | None = Field(default=None)
    path: StringList | JsonValue | None = Field(default=None)
    headers: dict[str, StringList | JsonValue] | None = Field(default=None)

class AuthenticatorResponse(ConfModel):
    """Go semantics: Build() in Go."""
    version: str | None = Field(default=None)
    status: str | None = Field(default=None)
    reason: str | None = Field(default=None)
    headers: dict[str, StringList | JsonValue] | None = Field(default=None)

class NoOpConnectionAuthenticator(ConfModel):
    """Go semantics: Build() in Go."""
    pass

__all__ = [
    "Authenticator",
    "AuthenticatorRequest",
    "AuthenticatorResponse",
    "NoOpConnectionAuthenticator",
]
