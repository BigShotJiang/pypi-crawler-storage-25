"""Utility and support functions."""
