# Federated Learning — Enterprise Rewrite

This folder contains an enterprise-style refactor of the `fl_framework` package.
The package is provided as `federated_learning` and preserves the original
framework API while adding enterprise-oriented structure, packaging, and
getting-started documentation.

Installation
------------

1. Create a virtual environment and install runtime dependencies:

```bash
python -m venv .venv
source .venv/bin/activate  # on Windows use `.venv\Scripts\Activate.ps1`
pip install -r requirements.txt
```

Quickstart — programmatic (Server)
---------------------------------

Minimal example to start a server programmatically:

```python
from federated_learning.config import FLConfig
from federated_learning.fl_server import FLServer

cfg = FLConfig(
	backend_url="http://localhost:8000",
	sqs_queue_url="https://sqs.us-east-1.amazonaws.com/…/server-queue",
	sqs_server_queue_url="https://sqs.us-east-1.amazonaws.com/…/server-queue",
	client_id="fl-server",
	model_id="my_model_v1",
	min_clients_for_aggregation=2,
)

server = FLServer(cfg, client_queue_urls=[
	"https://sqs.us-east-1.amazonaws.com/…/client-1",
	"https://sqs.us-east-1.amazonaws.com/…/client-2",
])
server.start()  # Blocking; use start_async() for background thread
```

Quickstart — programmatic (Client)
---------------------------------

Client example (you must provide a model implementing `FLModel`):

```python
from federated_learning.config import FLConfig
from federated_learning.fl_client import FLClient
from my_models import MyModel  # your implementation of FLModel

cfg = FLConfig(
	backend_url="http://localhost:8000",
	sqs_queue_url="https://sqs.us-east-1.amazonaws.com/…/client-queue",
	sqs_server_queue_url="https://sqs.us-east-1.amazonaws.com/…/server-queue",
	client_id="edge-node-1",
	model_id="my_model_v1",
)

model = MyModel()
client = FLClient(model=model, config=cfg, train_data_fn=lambda: load_train_df(), eval_data_fn=lambda: load_eval_df())
client.start()
```

CLI
---

A minimal CLI is provided for development:

```bash
python -m federated_learning.cli --role server --model-id my_model_v1
```

Testing
-------

Run the basic import test:

```bash
pip install -r requirements.txt
pytest -q
```

Configuration
-------------

Most runtime options can be set via environment variables. Important keys:

- `FL_BACKEND_URL` — Backend HTTP API base URL
- `FL_SQS_QUEUE_URL` — SQS queue URL for client
- `FL_SQS_SERVER_QUEUE_URL` — SQS queue URL for server
- `FL_USE_MONGODB` — when `true`, use MongoDB storage backend
- `FL_MONGO_URI`, `FL_MONGO_DB` — MongoDB connection details

Contributing
------------

This repository is a starting point. Suggested next steps:

- Add structured logging and Prometheus metrics.
- Expand unit tests for `aggregator`, `transport`, and `sqs_listener`.
- Add CI (GitHub Actions) and packaging (wheel) pipelines.

See the package source in the `federated_learning` package for implementation details.
