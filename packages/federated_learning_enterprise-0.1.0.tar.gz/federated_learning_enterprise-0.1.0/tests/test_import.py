def test_import_package():
    import federated_learning
    assert hasattr(federated_learning, "__version__")
