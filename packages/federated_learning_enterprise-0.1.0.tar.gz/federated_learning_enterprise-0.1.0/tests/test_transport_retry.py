from federated_learning.transport import _build_session


def test_build_session_retry_defaults():
    # Build a session with non-default params to ensure they're applied
    session = _build_session(retries=5, backoff=1.0)

    for scheme in ("http://", "https://"):
        adapter = session.adapters[scheme]
        retry = getattr(adapter, "max_retries", None)
        assert retry is not None, "Adapter should have a Retry configured"

        # Verify numeric parameters
        assert retry.total == 5
        assert retry.backoff_factor == 1.0

        # status_forcelist should include common transient statuses
        sf = set(getattr(retry, "status_forcelist", []) or [])
        assert {429, 500, 502, 503, 504}.issubset(sf)

        # urllib3 versions differ: allowed_methods or method_whitelist
        allowed = getattr(retry, "allowed_methods", None) or getattr(retry, "method_whitelist", None)
        assert allowed is not None
        allowed_upper = {m.upper() for m in allowed}
        assert "GET" in allowed_upper and "POST" in allowed_upper
