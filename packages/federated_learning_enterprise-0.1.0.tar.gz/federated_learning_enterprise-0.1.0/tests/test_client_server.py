import time

import numpy as np
import pandas as pd


from federated_learning.config import FLConfig


class DummyBroker:
    listeners = {}


class DummyListener:
    """In-memory SQS-like listener for tests."""

    def __init__(self, config, queue_url: str | None = None) -> None:
        self._cfg = config
        self._queue_url = queue_url or config.sqs_queue_url
        if not self._queue_url:
            raise ValueError("queue_url required for DummyListener")
        DummyBroker.listeners[self._queue_url] = self
        self._handlers = {}

    def register(self, event_type, handler):
        self._handlers.setdefault(event_type, []).append(handler)

    def register_many(self, mapping):
        for k, v in mapping.items():
            self.register(k, v)

    def listen(self):
        # no-op for tests
        return None

    def listen_async(self):
        return None

    def stop(self):
        return None

    def send(self, event, queue_url: str | None = None):
        target = DummyBroker.listeners.get(queue_url or self._queue_url)
        if not target:
            return None
        handlers = target._handlers.get(event.event, [])
        for handler in list(handlers):
            # deliver synchronously
            handler(event, "receipt", lambda: None)
        return "msgid"


class InMemoryTransport:
    """Shared in-memory transport backend for tests.

    Stores client submissions and global weights in class-level dicts so
    server+client instances share the same backend state.
    """

    _client_submissions = {}
    _global_weights = {}

    def __init__(self, config):
        self._cfg = config

    def send_weights(self, weights, round_, num_samples, metrics=None):
        key = (self._cfg.model_id, round_)
        if self._cfg.client_id == "fl-server":
            InMemoryTransport._global_weights[key] = {"weights": weights, "metrics": metrics or {}, "round": round_}
        else:
            InMemoryTransport._client_submissions.setdefault(key, []).append({
                "client_id": self._cfg.client_id,
                "weights": weights,
                "num_samples": num_samples,
                "metrics": metrics or {},
            })

    def get_global_weights(self, round_):
        return InMemoryTransport._global_weights.get((self._cfg.model_id, round_), None)

    def poll_global_weights(self, round_, poll_interval_s=0.1, timeout_s: float | None = None):
        deadline = time.time() + (timeout_s or 1.0)
        while time.time() < deadline:
            v = self.get_global_weights(round_)
            if v is not None:
                return v
            time.sleep(poll_interval_s)
        raise RuntimeError("timeout waiting for global weights")

    def get_client_weights(self, model_id, round_):
        return InMemoryTransport._client_submissions.get((model_id, round_), [])


from federated_learning.model_contract import FLModel


class DummyModel(FLModel):
    MODEL_ID = "test_model"

    def __init__(self):
        self._w = np.array([0.0])

    def get_weights(self):
        return {"w": self._w}

    def set_weights(self, weights):
        self._w = weights["w"]

    def train(self, data: pd.DataFrame, **kwargs):
        # simple deterministic update: add number of samples to weight
        self._w = self._w + len(data)
        return {"samples": len(data)}

    def evaluate(self, data: pd.DataFrame):
        return {"loss": 0.0}

    def serialize(self) -> bytes:
        import pickle

        return pickle.dumps(self._w)

    @classmethod
    def deserialize(cls, data: bytes):
        import pickle

        inst = cls()
        inst._w = pickle.loads(data)
        return inst


def test_client_server_round(monkeypatch):
    """Integration-style test: server starts a round and a client submits.

    Uses in-memory stubs for SQS and transport so the test is local-only.
    """
    import federated_learning.fl_client as fl_client
    import federated_learning.fl_server as fl_server
    import federated_learning.transport as transport_mod
    import federated_learning.sqs_listener as sqs_mod

    # Patch SQS and transport to in-memory implementations
    monkeypatch.setattr(sqs_mod, "SQSListener", DummyListener)
    monkeypatch.setattr(fl_server, "SQSListener", DummyListener)
    monkeypatch.setattr(fl_client, "SQSListener", DummyListener)
    monkeypatch.setattr(transport_mod, "WeightTransport", InMemoryTransport)

    # Server config and client config (they share model_id)
    server_cfg = FLConfig(backend_url="http://localhost", model_id="test_model", client_id="fl-server", sqs_queue_url="server-queue", sqs_server_queue_url="server-queue", min_clients_for_aggregation=1)
    client_cfg = FLConfig(backend_url="http://localhost", model_id="test_model", client_id="client-1", sqs_queue_url="client-queue", sqs_server_queue_url="server-queue")

    # Create server and client (listeners will register themselves in DummyBroker)
    server = fl_server.FLServer(server_cfg, client_queue_urls=["client-queue"])

    model = DummyModel()
    client = fl_client.FLClient(model=model, config=client_cfg, train_data_fn=lambda: pd.DataFrame({"x": [1, 2, 3]}), eval_data_fn=lambda: pd.DataFrame({"x": [1, 2, 3]}))

    # Start a round with initial weights — this should synchronously drive the
    # client training, submission, aggregation and broadcast via in-memory stubs.
    initial = {"w": np.array([1.0])}
    server.start_round(round_=0, global_weights=initial)

    key = ("test_model", 0)
    assert key in InMemoryTransport._global_weights, "Aggregated weights were not stored"

    agg = InMemoryTransport._global_weights[key]
    # Client model should have been updated to the aggregated weights
    client_w = client._model.get_weights()["w"]
    assert np.allclose(client_w, agg["weights"]["w"]) 
    # Given initial 1.0 and 3 training samples, DummyModel adds 3
    assert np.allclose(client_w, np.array([4.0]))
