"""FedAvg aggregator (stateless) — enterprise adaptation."""
from __future__ import annotations

import logging
from typing import Any, Dict, List, NamedTuple, Optional

import numpy as np

from .exceptions import AggregationError

logger = logging.getLogger(__name__)


class ClientUpdate(NamedTuple):
    client_id: str
    weights: Dict[str, np.ndarray]
    num_samples: int
    metrics: Dict[str, Any]


class Aggregator:
    def aggregate(self, updates: List[ClientUpdate], *, strategy: str = "fedavg") -> Dict[str, np.ndarray]:
        if not updates:
            raise AggregationError("Cannot aggregate: no client updates provided")

        if strategy == "uniform":
            raw_weights = np.ones(len(updates))
        elif strategy == "fedavg":
            raw_weights = np.array([u.num_samples for u in updates], dtype=float)
            if raw_weights.sum() == 0:
                logger.warning("[aggregator] All num_samples=0, falling back to uniform")
                raw_weights = np.ones(len(updates))
        else:
            raise AggregationError(f"Unknown aggregation strategy: {strategy!r}")

        norm_weights = raw_weights / raw_weights.sum()

        ref_keys = set(updates[0].weights.keys())
        for upd in updates[1:]:
            if set(upd.weights.keys()) != ref_keys:
                raise AggregationError("Client weight keys mismatch")

        aggregated: Dict[str, np.ndarray] = {}
        for key in ref_keys:
            arrays = [upd.weights[key] for upd in updates]
            aggregated[key] = self._aggregate_key(key, arrays, norm_weights, updates)

        logger.info("[aggregator] aggregated %d updates — keys: %s", len(updates), sorted(aggregated.keys()))
        return aggregated

    def _aggregate_key(self, key: str, arrays: List[np.ndarray], weights: np.ndarray, updates: List[ClientUpdate]) -> np.ndarray:
        sample_arr = arrays[0]
        if sample_arr.dtype == np.uint8:
            best_idx = int(np.argmax(weights))
            logger.debug("[aggregator] key=%s (blob) -> selecting client %s", key, updates[best_idx].client_id)
            return arrays[best_idx]
        try:
            result = sum(weights[i] * arrays[i].astype(np.float64) for i in range(len(arrays)))
            return result.astype(sample_arr.dtype)
        except Exception as exc:
            raise AggregationError(f"Failed to average key={key!r}: {exc}") from exc

    def aggregate_metrics(self, updates: List[ClientUpdate]) -> Dict[str, float]:
        if not updates:
            return {}
        total_samples = sum(u.num_samples for u in updates)
        if total_samples == 0:
            return {}
        keys = set()
        for u in updates:
            keys.update(k for k, v in u.metrics.items() if isinstance(v, (int, float)))
        result: Dict[str, float] = {}
        for key in keys:
            weighted_sum = sum(u.metrics.get(key, 0.0) * u.num_samples for u in updates)
            result[key] = round(weighted_sum / total_samples, 6)
        return result
