"""SQS listener wrapper using boto3 (keeps original API compatibility)."""
from __future__ import annotations

import logging
import threading
import time
from typing import Callable, Dict, Optional

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from .config import FLConfig
from .events import FLEvent, FLEventType
from .exceptions import SQSError

logger = logging.getLogger(__name__)

HandlerFn = Callable[[FLEvent, str, Callable[[], None]], None]


class SQSListener:
    def __init__(self, config: FLConfig, queue_url: Optional[str] = None) -> None:
        self._cfg = config
        self._queue_url = queue_url or config.sqs_queue_url
        if not self._queue_url:
            raise SQSError("SQSListener requires a queue URL")
        self._handlers: Dict[FLEventType, list[HandlerFn]] = {}
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._sqs = boto3.client("sqs", region_name=config.sqs_region)

    def register(self, event_type: FLEventType, handler: HandlerFn) -> None:
        self._handlers.setdefault(event_type, []).append(handler)

    def register_many(self, mapping: Dict[FLEventType, HandlerFn]) -> None:
        for event_type, handler in mapping.items():
            self.register(event_type, handler)

    def listen(self) -> None:
        logger.info("[sqs] Listening on %s", self._queue_url)
        self._stop_event.clear()
        while not self._stop_event.is_set():
            try:
                self._poll_once()
            except SQSError as exc:
                logger.error("[sqs] Error: %s — retrying in 5s", exc)
                time.sleep(5)
            except Exception as exc:
                logger.exception("[sqs] Unexpected error: %s — retrying in 10s", exc)
                time.sleep(10)

    def listen_async(self) -> threading.Thread:
        if self._thread and self._thread.is_alive():
            return self._thread
        self._thread = threading.Thread(target=self.listen, name=f"fl-sqs-listener-{self._cfg.client_id[:8]}", daemon=True)
        self._thread.start()
        logger.info("[sqs] Listener thread started: %s", self._thread.name)
        return self._thread

    def stop(self) -> None:
        self._stop_event.set()
        logger.info("[sqs] Stop signal sent")

    def _poll_once(self) -> None:
        try:
            response = self._sqs.receive_message(
                QueueUrl=self._queue_url,
                MaxNumberOfMessages=10,
                WaitTimeSeconds=self._cfg.sqs_wait_time_s,
                VisibilityTimeout=self._cfg.sqs_visibility_timeout_s,
                AttributeNames=["All"],
                MessageAttributeNames=["All"],
            )
        except (BotoCoreError, ClientError) as exc:
            raise SQSError(f"SQS receive_message failed: {exc}") from exc

        messages = response.get("Messages", [])
        for msg in messages:
            self._dispatch(msg)

    def _dispatch(self, raw_msg: dict) -> None:
        body = raw_msg.get("Body", "")
        receipt = raw_msg["ReceiptHandle"]
        try:
            event = FLEvent.from_sqs_body(body)
        except Exception as exc:
            logger.warning("[sqs] Failed to parse SQS message — deleting: %s", exc)
            self._delete(receipt)
            return
        handlers = self._handlers.get(event.event, [])
        if not handlers:
            logger.debug("[sqs] No handler for event %s — skipping", event.event)
            return
        def ack() -> None:
            self._delete(receipt)
        for handler in handlers:
            try:
                handler(event, receipt, ack)
            except Exception as exc:
                logger.exception("[sqs] Handler for %s raised %s", event.event, exc)

    def _delete(self, receipt_handle: str) -> None:
        try:
            self._sqs.delete_message(QueueUrl=self._queue_url, ReceiptHandle=receipt_handle)
        except (BotoCoreError, ClientError) as exc:
            logger.warning("[sqs] Could not delete message: %s", exc)

    def send(self, event: FLEvent, queue_url: Optional[str] = None) -> str:
        target = queue_url or self._queue_url
        try:
            kwargs = {"QueueUrl": target, "MessageBody": event.to_sqs_body()}
            if target.endswith('.fifo'):
                kwargs['MessageGroupId'] = event.model_id
                kwargs['MessageDeduplicationId'] = f"{event.event.value}-{event.round}-{event.client_id}"
            resp = self._sqs.send_message(**kwargs)
            msg_id = resp["MessageId"]
            logger.info("[sqs] Sent event=%s model=%s round=%d → %s (id=%s)", event.event.value, event.model_id, event.round, target, msg_id)
            return msg_id
        except (BotoCoreError, ClientError) as exc:
            raise SQSError(f"Failed to send SQS message: {exc}") from exc
