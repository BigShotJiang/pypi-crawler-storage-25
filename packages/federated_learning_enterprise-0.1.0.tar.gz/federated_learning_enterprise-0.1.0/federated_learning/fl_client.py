"""FLClient orchestration (enterprise-adapted).

API compatible with original `fl_framework.FLClient`.
"""
from __future__ import annotations

import logging
import threading
from typing import Callable, Dict, Optional

from .config import FLConfig
from .events import FLEvent, FLEventType
from .exceptions import FLFrameworkError, WeightTransportError
from .model_contract import FLModel
from .sqs_listener import SQSListener
from .mongo_storage import MongoStorage

logger = logging.getLogger(__name__)


class FLClient:
    def __init__(self, model: FLModel, config: FLConfig, train_data_fn: Optional[Callable] = None, eval_data_fn: Optional[Callable] = None) -> None:
        self._model = model
        self._cfg = config
        self._train_data_fn = train_data_fn
        self._eval_data_fn = eval_data_fn or train_data_fn
        if config.use_mongodb:
            logger.info("[client:%s] using MongoDB storage backend", config.client_id)
            self._storage = MongoStorage(config)
        else:
            from .transport import WeightTransport
            logger.info("[client:%s] using HTTP API transport backend", config.client_id)
            self._storage = WeightTransport(config)
        self._listener = SQSListener(config, queue_url=config.sqs_queue_url)
        self._current_round: int = -1
        self._stop_event = threading.Event()
        self._listener.register_many({FLEventType.ROUND_START: self._on_round_start, FLEventType.MODEL_BROADCAST: self._on_model_broadcast})

    def start(self) -> None:
        logger.info("[client:%s] starting — model=%s queue=%s", self._cfg.client_id, self._cfg.model_id, self._cfg.sqs_queue_url)
        self._listener.listen()

    def start_async(self) -> threading.Thread:
        return self._listener.listen_async()

    def stop(self) -> None:
        self._listener.stop()
        logger.info("[client:%s] stop signal sent", self._cfg.client_id)

    def _on_round_start(self, event: FLEvent, receipt: str, ack: Callable[[], None]) -> None:
        try:
            logger.info("[client:%s] ROUND_START round=%d", self._cfg.client_id, event.round)
            self._current_round = event.round
            if event.weights:
                self._model.set_weights(event.weights)
                self._model.on_round_start(event.round, event.weights)
            elif event.weights_ref:
                result = self._storage.get_global_weights(event.round)
                if result:
                    self._model.set_weights(result["weights"])
                    self._model.on_round_start(event.round, result["weights"]) 
            local_epochs = int(event.extra.get("local_epochs", self._cfg.local_epochs))
            train_df = self._train_data_fn() if self._train_data_fn else None
            if train_df is None:
                logger.warning("[client:%s] No training data — skipping round", self._cfg.client_id)
                ack(); return
            logger.info("[client:%s] training — epochs=%d samples=%d", self._cfg.client_id, local_epochs, len(train_df))
            train_meta = self._model.train(train_df, epochs=local_epochs)
            num_samples = int(train_meta.get("samples", len(train_df)))
            eval_df = self._eval_data_fn() if self._eval_data_fn else train_df
            metrics = self._model.evaluate(eval_df) if eval_df is not None else {}
            self._model.on_round_end(event.round, metrics)
            logger.info("[client:%s] metrics: %s", self._cfg.client_id, metrics)
            updated_weights = self._model.get_weights()
            self._storage.send_weights(weights=updated_weights, round_=event.round, num_samples=num_samples, metrics=metrics)
            if self._cfg.sqs_server_queue_url:
                submit_event = FLEvent(event=FLEventType.WEIGHTS_SUBMIT, model_id=self._cfg.model_id, round=event.round, client_id=self._cfg.client_id, num_samples=num_samples, weights=None, metrics=metrics)
                self._listener.send(submit_event, queue_url=self._cfg.sqs_server_queue_url)
            ack()
        except WeightTransportError as exc:
            logger.error("[client:%s] transport error: %s", self._cfg.client_id, exc)
        except FLFrameworkError as exc:
            logger.error("[client:%s] framework error: %s", self._cfg.client_id, exc)
            ack()
        except Exception as exc:
            logger.exception("[client:%s] unexpected error: %s", self._cfg.client_id, exc)

    def _on_model_broadcast(self, event: FLEvent, receipt: str, ack: Callable[[], None]) -> None:
        try:
            logger.info("[client:%s] MODEL_BROADCAST round=%d", self._cfg.client_id, event.round)
            weights = event.weights
            if weights is None:
                try:
                    result = self._storage.get_global_weights(round_=event.round)
                    if result:
                        weights = result["weights"]
                except Exception as exc:
                    logger.error("[client:%s] failed to fetch weights from storage: %s", self._cfg.client_id, exc)
                    return
            if weights:
                self._model.set_weights(weights)
                logger.info("[client:%s] model updated from broadcast", self._cfg.client_id)
            ack()
        except Exception as exc:
            logger.exception("[client:%s] broadcast apply failed: %s", self._cfg.client_id, exc)

    def run_round(self, round_: int, *, global_weights: Optional[Dict] = None, local_epochs: Optional[int] = None) -> Dict:
        if global_weights:
            self._model.set_weights(global_weights)
            self._model.on_round_start(round_, global_weights)
        train_df = self._train_data_fn() if self._train_data_fn else None
        if train_df is None:
            raise FLFrameworkError("No training data provided — set train_data_fn")
        epochs = local_epochs or self._cfg.local_epochs
        train_meta = self._model.train(train_df, epochs=epochs)
        num_samples = int(train_meta.get("samples", len(train_df)))
        eval_df = self._eval_data_fn() if self._eval_data_fn else train_df
        metrics = self._model.evaluate(eval_df)
        self._model.on_round_end(round_, metrics)
        weights = self._model.get_weights()
        return {"weights": weights, "num_samples": num_samples, "metrics": metrics}
