"""HTTP weight transport compatible with backend REST API."""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

import numpy as np
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .config import FLConfig
from .events import decode_weights, encode_weights
from .exceptions import WeightTransportError

logger = logging.getLogger(__name__)


def _build_session(retries: int = 3, backoff: float = 0.5) -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=retries,
        backoff_factor=backoff,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST"],
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


class WeightTransport:
    def __init__(self, config: FLConfig) -> None:
        self._cfg = config
        self._session = _build_session()

    def send_weights(self, weights: Dict[str, np.ndarray], round_: int, num_samples: int, metrics: Optional[Dict[str, Any]] = None) -> None:
        url = f"{self._cfg.backend_url}/fl/weights"
        payload = {
            "model_id": self._cfg.model_id,
            "round": round_,
            "client_id": self._cfg.client_id,
            "weights": encode_weights(weights),
            "num_samples": num_samples,
            "metrics": metrics or {},
        }
        logger.info("[transport] POST %s | model=%s round=%d client=%s", url, self._cfg.model_id, round_, self._cfg.client_id)
        try:
            resp = self._session.post(url, json=payload, headers=self._cfg.backend_headers, timeout=self._cfg.backend_timeout_s)
            resp.raise_for_status()
            logger.info("[transport] weights accepted: %s", resp.status_code)
        except requests.RequestException as exc:
            raise WeightTransportError(f"Failed to send weights to {url}: {exc}") from exc

    def get_global_weights(self, round_: int) -> Optional[Dict[str, Any]]:
        url = f"{self._cfg.backend_url}/fl/weights/latest"
        params = {"model_id": self._cfg.model_id, "round": round_}
        logger.info("[transport] GET %s params=%s", url, params)
        try:
            resp = self._session.get(url, params=params, headers=self._cfg.backend_headers, timeout=self._cfg.backend_timeout_s)
        except requests.RequestException as exc:
            raise WeightTransportError(f"Failed to fetch global weights from {url}: {exc}") from exc

        if resp.status_code == 204:
            logger.debug("[transport] 204 — global weights not ready yet")
            return None

        try:
            resp.raise_for_status()
        except requests.HTTPError as exc:
            raise WeightTransportError(f"Backend returned error fetching weights: {exc}") from exc

        data = resp.json()
        data["weights"] = decode_weights(data["weights"])
        return data

    def poll_global_weights(self, round_: int, *, poll_interval_s: float = 5.0, timeout_s: Optional[float] = None) -> Dict[str, Any]:
        deadline = time.monotonic() + (timeout_s or self._cfg.round_timeout_s)
        attempt = 0
        while time.monotonic() < deadline:
            attempt += 1
            result = self.get_global_weights(round_)
            if result is not None:
                logger.info("[transport] global weights received (attempt %d)", attempt)
                return result
            logger.debug("[transport] waiting for round %d global weights (attempt %d)…", round_, attempt)
            time.sleep(poll_interval_s)

        raise WeightTransportError(f"Timeout waiting for round {round_} global weights after {timeout_s or self._cfg.round_timeout_s}s")

    def get_client_weights(self, model_id: str, round_: int) -> list[Dict[str, Any]]:
        url = f"{self._cfg.backend_url}/fl/weights/round/{round_}/clients"
        params = {"model_id": model_id}
        logger.info("[transport] GET %s params=%s", url, params)
        try:
            resp = self._session.get(url, params=params, headers=self._cfg.backend_headers, timeout=self._cfg.backend_timeout_s)
            resp.raise_for_status()
        except requests.RequestException as exc:
            raise WeightTransportError(f"Failed to fetch client weights from {url}: {exc}") from exc

        data = resp.json()
        clients = data.get("clients", [])
        for client in clients:
            if "weights" in client and client["weights"]:
                client["weights"] = decode_weights(client["weights"])
        logger.info("[transport] fetched %d client submissions for round %d", len(clients), round_)
        return clients
