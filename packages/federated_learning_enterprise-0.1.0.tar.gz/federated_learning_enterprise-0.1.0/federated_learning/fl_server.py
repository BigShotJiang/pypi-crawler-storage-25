"""FLServer orchestration (enterprise-adapted).

This implementation follows the API of the original `fl_framework.FLServer`.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Callable, Dict, List, Optional

from .aggregator import Aggregator, ClientUpdate
from .config import FLConfig
from .events import FLEvent, FLEventType
from .exceptions import AggregationError, FLFrameworkError, RoundTimeoutError
from .model_contract import FLModel
from .sqs_listener import SQSListener
from .mongo_storage import MongoStorage

logger = logging.getLogger(__name__)


class FLServer:
    def __init__(self, config: FLConfig, client_queue_urls: Optional[List[str]] = None, on_round_complete: Optional[Callable[[int, Dict, Dict], None]] = None) -> None:
        self._cfg = config
        self._client_queues = client_queue_urls or []
        self._on_round_complete_cb = on_round_complete
        self._aggregator = Aggregator()

        if config.use_mongodb:
            logger.info("[server] using MongoDB storage backend")
            self._storage = MongoStorage(config)
        else:
            from .transport import WeightTransport  # lazy
            logger.info("[server] using HTTP API transport backend")
            self._storage = WeightTransport(config)

        server_queue = config.sqs_server_queue_url or config.sqs_queue_url
        self._listener = SQSListener(config, queue_url=server_queue)
        self._listener.register(FLEventType.WEIGHTS_SUBMIT, self._on_weights_submit)

        self._lock = threading.Lock()
        self._current_round: int = -1
        self._pending_updates: Dict[int, List[ClientUpdate]] = {}
        self._aggregated_rounds: set = set()
        self._global_weights: Optional[Dict] = None
        self._round_event = threading.Event()

    def start(self, auto_advance: bool = True) -> None:
        logger.info("[server] starting | model=%s min_clients=%d", self._cfg.model_id, self._cfg.min_clients_for_aggregation)
        self._listener.listen()

    def start_async(self) -> threading.Thread:
        return self._listener.listen_async()

    def stop(self) -> None:
        self._listener.stop()

    def start_round(self, round_: int, global_weights: Optional[Dict] = None, local_epochs: Optional[int] = None) -> None:
        with self._lock:
            self._current_round = round_
            self._pending_updates.setdefault(round_, [])
            if global_weights is not None:
                self._global_weights = global_weights

        weights_in_message = global_weights
        weights_ref = False
        if self._cfg.use_mongodb and global_weights is not None:
            try:
                self._storage.save_global_weights(round_=round_, weights=global_weights, metrics={}, client_id="fl-server")
                weights_in_message = None
                weights_ref = True
                logger.info("[server] saved round=%d global weights to MongoDB (SQS ref only)", round_)
            except Exception as exc:
                logger.warning("[server] could not pre-save weights to MongoDB, embedding in SQS: %s", exc)

        event = FLEvent.round_start(model_id=self._cfg.model_id, round_=round_, global_weights=weights_in_message, local_epochs=local_epochs or self._cfg.local_epochs)
        if weights_ref:
            event.weights_ref = "mongodb"

        for queue_url in self._client_queues:
            try:
                self._listener.send(event, queue_url=queue_url)
            except Exception as exc:
                logger.error("[server] could not broadcast to %s: %s", queue_url, exc)

        logger.info("[server] ROUND_START round=%d → %d clients", round_, len(self._client_queues))

    def wait_for_round(self, round_: int, timeout_s: Optional[float] = None) -> Dict:
        deadline = time.monotonic() + (timeout_s or self._cfg.round_timeout_s)
        while time.monotonic() < deadline:
            with self._lock:
                if round_ in self._aggregated_rounds:
                    return self._global_weights
                updates = self._pending_updates.get(round_, [])
                if len(updates) >= self._cfg.min_clients_for_aggregation:
                    self._aggregated_rounds.add(round_)
                    return self._aggregate_and_broadcast(round_, updates)
            time.sleep(1.0)
        raise RoundTimeoutError(f"Round {round_} did not complete within {timeout_s or self._cfg.round_timeout_s:.0f}s (got {len(self._pending_updates.get(round_, []))} / {self._cfg.min_clients_for_aggregation} updates)")

    def _on_weights_submit(self, event: FLEvent, receipt: str, ack: Callable[[], None]) -> None:
        if event.model_id != self._cfg.model_id:
            ack(); return
        client_weights = event.weights
        if client_weights is None:
            try:
                submissions = self._storage.get_client_weights(model_id=event.model_id, round_=event.round)
                for sub in submissions:
                    if sub["client_id"] == event.client_id:
                        client_weights = sub["weights"]
                        break
                if client_weights is None:
                    ack(); return
            except Exception:
                return
        update = ClientUpdate(client_id=event.client_id, weights=client_weights, num_samples=event.num_samples, metrics=event.metrics)
        should_aggregate = False
        with self._lock:
            bucket = self._pending_updates.setdefault(event.round, [])
            if any(u.client_id == event.client_id for u in bucket):
                ack(); return
            bucket.append(update)
            if len(bucket) >= self._cfg.min_clients_for_aggregation:
                should_aggregate = True
        ack()
        if should_aggregate:
            with self._lock:
                if event.round in self._aggregated_rounds:
                    return
                self._aggregated_rounds.add(event.round)
                updates = list(self._pending_updates.get(event.round, []))
            try:
                self._aggregate_and_broadcast(event.round, updates)
            except AggregationError as exc:
                logger.error("[server] aggregation failed: %s", exc)

    def _aggregate_and_broadcast(self, round_: int, updates: List[ClientUpdate]) -> Dict:
        logger.info("[server] aggregating round=%d with %d updates", round_, len(updates))
        aggregated = self._aggregator.aggregate(updates)
        agg_metrics = self._aggregator.aggregate_metrics(updates)
        self._global_weights = aggregated
        try:
            total_samples = sum(u.num_samples for u in updates)
            self._storage.send_weights(weights=aggregated, round_=round_, num_samples=total_samples, metrics={**agg_metrics, "clients": len(updates)})
        except Exception as exc:
            logger.error("[server] failed to push aggregated weights to storage: %s", exc)
        broadcast = FLEvent(model_id=self._cfg.model_id, event=FLEventType.MODEL_BROADCAST, round=round_, client_id="*", weights=None, metrics=agg_metrics)
        for queue_url in self._client_queues:
            try:
                self._listener.send(broadcast, queue_url=queue_url)
            except Exception as exc:
                logger.error("[server] broadcast to %s failed: %s", queue_url, exc)
        complete = FLEvent.round_complete(model_id=self._cfg.model_id, round_=round_, metrics=agg_metrics, participating_clients=[u.client_id for u in updates])
        logger.info("[server] round %d complete | metrics=%s", round_, agg_metrics)
        if self._on_round_complete_cb:
            try:
                self._on_round_complete_cb(round_, aggregated, agg_metrics)
            except Exception as exc:
                logger.warning("[server] on_round_complete callback raised: %s", exc)
        with self._lock:
            self._pending_updates.pop(round_, None)
        self._round_event.set(); self._round_event.clear()
        return aggregated

    def aggregate_manually(self, updates: List[ClientUpdate]) -> Dict:
        return self._aggregator.aggregate(updates)
