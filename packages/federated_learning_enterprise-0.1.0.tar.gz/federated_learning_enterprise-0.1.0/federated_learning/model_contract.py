"""Abstract FLModel contract (compatible with original framework)."""
from __future__ import annotations

import abc
from typing import Any, Dict, List, Type

import numpy as np
import pandas as pd


class FLModel(abc.ABC):
    MODEL_ID: str = ""

    @abc.abstractmethod
    def get_weights(self) -> Dict[str, np.ndarray]:
        pass

    @abc.abstractmethod
    def set_weights(self, weights: Dict[str, np.ndarray]) -> None:
        pass

    @abc.abstractmethod
    def train(self, data: pd.DataFrame, **kwargs: Any) -> Dict[str, Any]:
        pass

    @abc.abstractmethod
    def evaluate(self, data: pd.DataFrame) -> Dict[str, float]:
        pass

    @abc.abstractmethod
    def serialize(self) -> bytes:
        pass

    @classmethod
    @abc.abstractmethod
    def deserialize(cls, data: bytes) -> "FLModel":
        pass

    def on_round_start(self, round_: int, global_weights: Dict[str, np.ndarray]) -> None:
        return None

    def on_round_end(self, round_: int, metrics: Dict[str, float]) -> None:
        return None


_MODEL_REGISTRY: Dict[str, Type[FLModel]] = {}


def register(cls: Type[FLModel]) -> Type[FLModel]:
    if not cls.MODEL_ID:
        raise ValueError("MODEL_ID must be set on FLModel subclasses")
    _MODEL_REGISTRY[cls.MODEL_ID] = cls
    return cls


def get_model_class(model_id: str) -> Type[FLModel]:
    try:
        return _MODEL_REGISTRY[model_id]
    except KeyError as exc:
        available = list(_MODEL_REGISTRY.keys())
        raise KeyError(f"No FLModel registered for {model_id!r}. Available: {available}") from exc


def list_registered_models() -> List[str]:
    return list(_MODEL_REGISTRY.keys())
