"""Configuration dataclass for the federated learning package.

This is intentionally compatible with the original `fl_framework.FLConfig` API.
"""
from __future__ import annotations

import os
import uuid
from dataclasses import dataclass, field
from typing import Optional


def _env(key: str, default: str = "") -> str:
    return os.environ.get(key, default)


@dataclass
class FLConfig:
    # Backend API
    backend_url: str = field(default_factory=lambda: _env("FL_BACKEND_URL", "http://localhost:8000"))
    backend_api_key: Optional[str] = field(default_factory=lambda: _env("FL_BACKEND_API_KEY") or None)
    backend_timeout_s: float = 30.0

    # SQS
    sqs_queue_url: str = field(default_factory=lambda: _env("FL_SQS_QUEUE_URL", ""))
    sqs_server_queue_url: str = field(default_factory=lambda: _env("FL_SQS_SERVER_QUEUE_URL", ""))
    sqs_region: str = field(default_factory=lambda: _env("FL_SQS_REGION", "us-east-1"))
    sqs_wait_time_s: int = 20
    sqs_visibility_timeout_s: int = 60

    # FL protocol
    client_id: str = field(default_factory=lambda: _env("FL_CLIENT_ID") or str(uuid.uuid4()))
    model_id: str = field(default_factory=lambda: _env("FL_MODEL_ID", "default"))
    round_timeout_s: float = field(default_factory=lambda: float(_env("FL_ROUND_TIMEOUT_S", "300")))
    max_rounds: int = field(default_factory=lambda: int(_env("FL_MAX_ROUNDS", "100")))

    # Training defaults
    local_epochs: int = 10
    min_clients_for_aggregation: int = 2

    # MongoDB
    use_mongodb: bool = field(default_factory=lambda: _env("FL_USE_MONGODB", "false").lower() == "true")
    mongo_uri: str = field(default_factory=lambda: _env("FL_MONGO_URI", "mongodb://localhost:27017/"))
    mongo_db: str = field(default_factory=lambda: _env("FL_MONGO_DB", "waste_valorization"))

    @property
    def backend_headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self.backend_api_key:
            h["Authorization"] = f"Bearer {self.backend_api_key}"
        return h

    def validate(self) -> None:
        if self.use_mongodb:
            if not self.mongo_uri:
                raise ValueError("FLConfig.mongo_uri must not be empty when use_mongodb=True")
            if not self.mongo_db:
                raise ValueError("FLConfig.mongo_db must not be empty when use_mongodb=True")
        else:
            if not self.backend_url:
                raise ValueError("FLConfig.backend_url must not be empty")
        if not self.sqs_queue_url:
            raise ValueError("FLConfig.sqs_queue_url must not be empty (set FL_SQS_QUEUE_URL)")
