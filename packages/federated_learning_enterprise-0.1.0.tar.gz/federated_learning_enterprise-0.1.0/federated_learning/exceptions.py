"""Framework exceptions for enterprise package."""
from __future__ import annotations

class FLFrameworkError(Exception):
    """Base class for framework errors."""


class AggregationError(FLFrameworkError):
    pass


class WeightTransportError(FLFrameworkError):
    pass


class RoundTimeoutError(FLFrameworkError):
    pass


class SQSError(FLFrameworkError):
    pass
