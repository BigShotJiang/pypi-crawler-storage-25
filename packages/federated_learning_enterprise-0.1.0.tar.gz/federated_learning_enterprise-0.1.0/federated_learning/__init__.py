"""Enterprise-grade federated learning package (refactor).

This package intentionally keeps a minimal top-level import surface to avoid
heavy imports during package import. Use the submodules directly for entry
points (e.g. `federated_learning.fl_server.FLServer`).
"""

__all__ = ["__version__"]

__version__ = "0.1.0"
