"""SQS event schema and helpers (compatible with original framework)."""
from __future__ import annotations

import base64
import json
import pickle
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

import numpy as np


class FLEventType(str, Enum):
    ROUND_START = "FL_ROUND_START"
    MODEL_BROADCAST = "FL_MODEL_BROADCAST"
    WEIGHTS_SUBMIT = "FL_WEIGHTS_SUBMIT"
    TRAINING_START = "FL_TRAINING_START"
    ROUND_COMPLETE = "FL_ROUND_COMPLETE"
    ERROR = "FL_ERROR"
    PING = "FL_PING"
    PONG = "FL_PONG"


def encode_weights(weights: Dict[str, np.ndarray]) -> str:
    raw = pickle.dumps(weights, protocol=4)
    return base64.b64encode(raw).decode("ascii")


def decode_weights(encoded: str) -> Dict[str, np.ndarray]:
    return pickle.loads(base64.b64decode(encoded))


@dataclass
class FLEvent:
    event: FLEventType
    model_id: str
    round: int
    client_id: str = "*"
    num_samples: int = 0
    weights: Optional[Dict[str, np.ndarray]] = None
    weights_ref: Optional[str] = None
    metrics: Dict[str, Any] = field(default_factory=dict)
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_sqs_body(self) -> str:
        payload: Dict[str, Any] = {
            "event": self.event.value,
            "model_id": self.model_id,
            "round": self.round,
            "client_id": self.client_id,
            "num_samples": self.num_samples,
            "metrics": self.metrics,
            "extra": self.extra,
        }
        if self.weights is not None:
            payload["weights"] = encode_weights(self.weights)
        if self.weights_ref is not None:
            payload["weights_ref"] = self.weights_ref
        return json.dumps(payload)

    @classmethod
    def from_sqs_body(cls, body: str) -> "FLEvent":
        d = json.loads(body)
        weights: Optional[Dict[str, np.ndarray]] = None
        if "weights" in d:
            weights = decode_weights(d["weights"])
        return cls(
            event=FLEventType(d["event"]),
            model_id=d["model_id"],
            round=int(d["round"]),
            client_id=d.get("client_id", "*"),
            num_samples=int(d.get("num_samples", 0)),
            weights=weights,
            weights_ref=d.get("weights_ref"),
            metrics=d.get("metrics", {}),
            extra=d.get("extra", {}),
        )

    @classmethod
    def round_start(
        cls,
        model_id: str,
        round_: int,
        *,
        global_weights: Optional[Dict[str, np.ndarray]] = None,
        weights_ref: Optional[str] = None,
        local_epochs: int = 10,
    ) -> "FLEvent":
        return cls(
            event=FLEventType.ROUND_START,
            model_id=model_id,
            round=round_,
            client_id="*",
            weights=global_weights,
            weights_ref=weights_ref,
            extra={"local_epochs": local_epochs},
        )

    @classmethod
    def weights_submit(
        cls,
        model_id: str,
        round_: int,
        client_id: str,
        weights: Dict[str, np.ndarray],
        num_samples: int,
        metrics: Optional[Dict[str, Any]] = None,
    ) -> "FLEvent":
        return cls(
            event=FLEventType.WEIGHTS_SUBMIT,
            model_id=model_id,
            round=round_,
            client_id=client_id,
            weights=weights,
            num_samples=num_samples,
            metrics=metrics or {},
        )

    @classmethod
    def model_broadcast(
        cls,
        model_id: str,
        round_: int,
        aggregated_weights: Dict[str, np.ndarray],
        metrics: Optional[Dict[str, Any]] = None,
    ) -> "FLEvent":
        return cls(
            event=FLEventType.MODEL_BROADCAST,
            model_id=model_id,
            round=round_,
            client_id="*",
            weights=aggregated_weights,
            metrics=metrics or {},
        )

    @classmethod
    def round_complete(
        cls,
        model_id: str,
        round_: int,
        metrics: Dict[str, Any],
        participating_clients: List[str],
    ) -> "FLEvent":
        return cls(
            event=FLEventType.ROUND_COMPLETE,
            model_id=model_id,
            round=round_,
            client_id="*",
            metrics=metrics,
            extra={"clients": participating_clients},
        )
