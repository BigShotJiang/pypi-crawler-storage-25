"""MongoDB storage backend (compatibility layer).

This mirrors the API from the original framework and uses `pymongo`.
"""
from __future__ import annotations

import logging
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

import numpy as np
from pymongo import MongoClient, DESCENDING
from pymongo.errors import PyMongoError

from .config import FLConfig
from .events import encode_weights, decode_weights
from .exceptions import WeightTransportError

logger = logging.getLogger(__name__)


class MongoStorage:
    def __init__(self, config: FLConfig) -> None:
        self._cfg = config
        self._client: Optional[MongoClient] = None
        self._db = None
        self._connect()

    def _connect(self) -> None:
        try:
            mongo_uri = getattr(self._cfg, 'mongo_uri', 'mongodb://localhost:27017/')
            mongo_db = getattr(self._cfg, 'mongo_db', 'waste_valorization')
            logger.info(f"[mongo] connecting to {mongo_uri}")
            self._client = MongoClient(mongo_uri, serverSelectionTimeoutMS=5000, connectTimeoutMS=5000)
            self._client.server_info()
            self._db = self._client[mongo_db]
            logger.info(f"[mongo] connected to database: {mongo_db}")
        except PyMongoError as exc:
            raise WeightTransportError(f"Failed to connect to MongoDB: {exc}") from exc

    def close(self) -> None:
        if self._client:
            self._client.close()
            logger.info("[mongo] connection closed")

    def send_weights(self, weights: Dict[str, np.ndarray], round_: int, num_samples: int, metrics: Optional[Dict[str, Any]] = None) -> None:
        if self._cfg.client_id == "fl-server":
            self.save_global_weights(round_=round_, weights=weights, metrics=metrics, client_id=self._cfg.client_id)
        else:
            self.save_client_weights(round_=round_, client_id=self._cfg.client_id, weights=weights, num_samples=num_samples, metrics=metrics)

    def save_client_weights(self, round_: int, client_id: str, weights: Dict[str, np.ndarray], num_samples: int, metrics: Optional[Dict[str, Any]] = None) -> None:
        collection = self._db.fl_client_weights
        document = {
            "model_id": self._cfg.model_id,
            "round": round_,
            "client_id": client_id,
            "weights": encode_weights(weights),
            "num_samples": num_samples,
            "metrics": metrics or {},
            "timestamp": datetime.utcnow(),
        }
        try:
            collection.update_one({"model_id": self._cfg.model_id, "round": round_, "client_id": client_id}, {"$set": document}, upsert=True)
            logger.info("[mongo] saved client weights | model=%s round=%d client=%s samples=%d", self._cfg.model_id, round_, client_id, num_samples)
        except PyMongoError as exc:
            raise WeightTransportError(f"Failed to save client weights: {exc}") from exc

    def get_client_weights(self, round_: int, model_id: Optional[str] = None) -> List[Dict[str, Any]]:
        collection = self._db.fl_client_weights
        model_id = model_id or self._cfg.model_id
        try:
            cursor = collection.find({"model_id": model_id, "round": round_})
            clients = []
            for doc in cursor:
                clients.append({
                    "client_id": doc["client_id"],
                    "weights": decode_weights(doc["weights"]),
                    "num_samples": doc["num_samples"],
                    "metrics": doc.get("metrics", {}),
                    "timestamp": doc.get("timestamp"),
                })
            logger.info("[mongo] retrieved %d client submissions | model=%s round=%d", len(clients), model_id, round_)
            return clients
        except PyMongoError as exc:
            raise WeightTransportError(f"Failed to retrieve client weights: {exc}") from exc

    def save_global_weights(self, round_: int, weights: Dict[str, np.ndarray], metrics: Optional[Dict[str, Any]] = None, client_id: str = "fl-server") -> None:
        collection = self._db.fl_global_weights
        document = {
            "model_id": self._cfg.model_id,
            "round": round_,
            "client_id": client_id,
            "weights": encode_weights(weights),
            "metrics": metrics or {},
            "timestamp": datetime.utcnow(),
        }
        try:
            collection.update_one({"model_id": self._cfg.model_id, "round": round_}, {"$set": document}, upsert=True)
            logger.info("[mongo] saved global weights | model=%s round=%d", self._cfg.model_id, round_)
        except PyMongoError as exc:
            raise WeightTransportError(f"Failed to save global weights: {exc}") from exc

    def get_global_weights(self, round_: int, model_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        collection = self._db.fl_global_weights
        model_id = model_id or self._cfg.model_id
        try:
            doc = collection.find_one({"model_id": model_id, "round": round_})
            if doc is None:
                logger.debug("[mongo] global weights not found | model=%s round=%d", model_id, round_)
                return None
            result = {"weights": decode_weights(doc["weights"]), "metrics": doc.get("metrics", {}), "round": doc["round"], "timestamp": doc.get("timestamp"),}
            logger.info("[mongo] retrieved global weights | model=%s round=%d", model_id, round_)
            return result
        except PyMongoError as exc:
            raise WeightTransportError(f"Failed to retrieve global weights: {exc}") from exc

    def poll_global_weights(self, round_: int, poll_interval_s: float = 5.0, timeout_s: Optional[float] = None) -> Dict[str, Any]:
        deadline = time.time() + (timeout_s or self._cfg.round_timeout_s)
        attempt = 0
        while time.time() < deadline:
            attempt += 1
            result = self.get_global_weights(round_)
            if result is not None:
                logger.info("[mongo] global weights received (attempt %d)", attempt)
                return result
            logger.debug("[mongo] waiting for round %d global weights (attempt %d)…", round_, attempt)
            time.sleep(poll_interval_s)
        raise WeightTransportError(f"Timeout waiting for round {round_} global weights after {timeout_s or self._cfg.round_timeout_s}s")

    def save_initial_model(self, weights: Dict[str, np.ndarray], metadata: Optional[Dict[str, Any]] = None, version: Optional[str] = None) -> None:
        collection = self._db.fl_models
        document = {"model_id": self._cfg.model_id, "version": version or "1.0", "weights": encode_weights(weights), "metadata": metadata or {}, "created_at": datetime.utcnow(),}
        try:
            collection.update_one({"model_id": self._cfg.model_id}, {"$set": document}, upsert=True)
            logger.info("[mongo] saved initial model | model=%s version=%s", self._cfg.model_id, version or "1.0")
        except PyMongoError as exc:
            raise WeightTransportError(f"Failed to save initial model: {exc}") from exc

    def get_initial_model(self, model_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        collection = self._db.fl_models
        model_id = model_id or self._cfg.model_id
        try:
            doc = collection.find_one({"model_id": model_id}, sort=[("created_at", DESCENDING)])
            if doc is None:
                logger.warning("[mongo] initial model not found | model=%s", model_id)
                return None
            result = {"weights": decode_weights(doc["weights"]), "metadata": doc.get("metadata", {}), "version": doc.get("version"), "created_at": doc.get("created_at"),}
            logger.info("[mongo] retrieved initial model | model=%s version=%s", model_id, result["version"]) 
            return result
        except PyMongoError as exc:
            raise WeightTransportError(f"Failed to retrieve initial model: {exc}") from exc

    def get_latest_round(self, model_id: Optional[str] = None) -> int:
        collection = self._db.fl_global_weights
        model_id = model_id or self._cfg.model_id
        try:
            doc = collection.find_one({"model_id": model_id}, sort=[("round", DESCENDING)])
            if doc:
                return doc["round"]
            return 0
        except PyMongoError as exc:
            logger.warning(f"Failed to get latest round: {exc}")
            return 0
