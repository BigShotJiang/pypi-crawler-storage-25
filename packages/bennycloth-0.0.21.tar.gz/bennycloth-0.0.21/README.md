# BennyCloth

The name BennyCloth is a combination of **Benny** the Beaver and a 
**synonym for Canvas**, whose 
[REST API](https://canvas.instructure.com/doc/api/index.html) was the means 
for delivering homework assignments, randomized using many of the 
functions in this package.

BennyCloth is available on [pypi](https://pypi.org/project/bennycloth/).

## Packages

+ `loads`
+ `steel`
+ `concrete`
+ `wood`
+ `canvas`
+ `matrix`
+ `beaverFrame`
+ `images`
