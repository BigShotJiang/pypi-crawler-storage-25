import bennycloth as bc

def test_null():
    assert True

