# Final Release Audit Report (v1 Candidate)

Date: 2026-04-12
Repository: ins_pricing
Scope: maintainability, redundancy, logic structure, CentOS7 + dual A30 + CUDA + torch1.x compatibility, large-scale efficiency/OOM balance.

## 1. Multi-Agent Audit Coverage

- Agent A (maintainability/redundancy/logic structure): reviewed FT training flow and trainer parameter surfaces.
- Agent B (platform compatibility): reviewed torch1.x/CentOS7/CUDA/DDP/DataLoader stability paths.
- Agent C (performance/OOM at 10M+ rows): reviewed lazy dataset/cache/DataLoader and final-fit OOM behavior.

## 2. Key Issues Found and Resolved

### A. Maintainability and Redundancy

1. FT unsupervised validation path had split lazy/non-lazy implementations.
- Fix: unified to one epoch evaluator and one early-stop/prune step.
- Code: `modelling/bayesopt/models/model_ft_trainer.py`

2. FT lazy dataset cache logic repeated across three datasets.
- Fix: introduced `_BlockLRUCache` and switched dataset cache paths to common component.
- Code: `modelling/bayesopt/models/model_ft_trainer.py`

3. ResNet param source existed in multiple manually maintained sets.
- Fix: consolidated to `_RESN_MODEL_CONSTRUCTOR_KEYS + _RESN_RUNTIME_ONLY_KEYS` and reused in build/sanitize.
- Code: `modelling/bayesopt/trainers/trainer_resn.py`

4. ResNet `use_layernorm` could be accepted but not applied in model construction.
- Fix: moved `use_layernorm` into constructor-handled params and wired into `_build_model(...)`.
- Added regression: `test_resn_build_model_applies_use_layernorm_param`.
- Code:
  - `modelling/bayesopt/trainers/trainer_resn.py`
  - `tests/modelling/test_resn_param_sanitize.py`

5. Frontend double-lift defaults/validation drifted from expected contract.
- Fixes:
  - corrected default target field `"response"` (UI typo fix),
  - changed CSV validation to drop invalid required rows and raise clear `"No valid rows remain"` on empty remainder.
- Code:
  - `frontend/ui_frontend.py`
  - `frontend/workflows_compare.py`

6. `PricingApp()` constructor had eager filesystem side-effects (`$HOME` auth path creation).
- Fix: lazy-init `auth_store`; defer workspace directory creation until actually needed.
- Code: `frontend/app_controller.py`

### B. Performance and OOM Balance

1. Shuffle with block-cache datasets caused high cache miss/re-encode overhead.
- Fix: added block-aligned samplers:
  - `_BlockShuffleSampler`
  - `_DistributedBlockShuffleSampler`
- Code: `modelling/bayesopt/utils/torch_trainer_mixin.py`

2. Large lazy datasets with workers>0 risked host memory amplification.
- Fix: added large-dataset auto worker downgrade (`workers=0`) for block-cache datasets.
- Env: `BAYESOPT_LARGE_DATASET_ROW_THRESHOLD`
- Code: `modelling/bayesopt/utils/torch_trainer_mixin.py`

3. Final training lacked OOM retry ladder.
- Fix: added `_fit_with_oom_retry` in trainer mixin path and used in final fit path.
- Fallback actions: increase `batch_num`, force `dataloader_workers=0`, switch `resource_profile=memory_saving`.
- Env: `BAYESOPT_FINAL_TRAIN_OOM_RETRIES`
- Code:
  - `modelling/bayesopt/runtime/trainer_cv_prediction.py`
  - `modelling/bayesopt/trainers/trainer_ft.py`
  - `modelling/bayesopt/trainers/trainer_resn.py`

4. Validation peak memory needed explicit cap option.
- Fix: added optional val batch cap.
- Env: `BAYESOPT_VAL_BATCH_CAP`
- Code: `modelling/bayesopt/utils/torch_trainer_mixin.py`

5. GNN production inference did not propagate row-guard settings.
- Fix: pass `gnn_max_fit_rows`, `gnn_max_predict_rows`, `gnn_predict_chunk_rows` into inference-time GNN model builder.
- Code:
  - `production/inference.py`
  - `tests/production/test_inference.py`

6. Block-shuffle samplers materialized full shuffled index arrays each epoch.
- Fix: switched to streaming index generation (distributed sampler keeps only tiny padding prefix).
- Code:
  - `modelling/bayesopt/utils/torch_trainer_mixin.py`
  - `tests/modelling/test_runtime_portability.py`

7. FT numeric preprocessing materialized full numeric matrix for mean/std.
- Fix: blockwise stats accumulation with env-tunable block size (`BAYESOPT_FT_PREPROC_BLOCK_ROWS`).
- Code:
  - `modelling/bayesopt/models/model_ft_trainer.py`
  - `tests/modelling/test_ft_lazy_dataset.py`

8. Torch legacy-load fallback had order-dependent kwarg behavior risk.
- Fix: `torch_load(..., weights_only=False)` path now never forwards `weights_only` kwarg.
- Added regression covering cached capability state.
- Code:
  - `utils/torch_compat.py`
  - `tests/utils/test_model_loading.py`

9. ResNet trainer load path used a direct loader path separate from centralized artifact policy.
- Fix: switched `ResNetTrainer.load` to `load_model_artifact_payload(..., model_key="resn")`.
- Code: `modelling/bayesopt/trainers/trainer_resn.py`

## 3. Runtime Configuration Recommendations (CentOS7, Dual A30, Torch1.x)

Recommended starting profile for 10M+ rows / 30+ features:

- `BAYESOPT_RESOURCE_PROFILE=memory_saving`
- `BAYESOPT_DDP_ALLOW_WORKERS_IN_MEMORY_SAVING=0`
- `BAYESOPT_LARGE_DATASET_ROW_THRESHOLD=3000000`
- `BAYESOPT_FT_LAZY_BLOCK_SIZE=64`
- `BAYESOPT_FT_LAZY_CACHE_BLOCKS=16`
- `BAYESOPT_FT_PREPROC_BLOCK_ROWS=200000`
- `BAYESOPT_BLOCK_SHUFFLE_SEED=13`
- `BAYESOPT_FINAL_TRAIN_OOM_RETRIES=2`
- `BAYESOPT_VAL_BATCH_CAP=2048` (or tighter if validation OOM persists)
- `OMP_NUM_THREADS=1`
- `OPENBLAS_NUM_THREADS=1`

Model-side operational guidance:

- Enable lazy datasets for FT/ResNet on very large tables.
- Keep `dataloader_workers=0` unless host memory headroom is validated under production load.
- Start with single-process or conservative DDP settings, then scale out after stability baseline.

## 4. Validation and Test Evidence

### Test Suites Executed

1. Focused regression suites (runtime portability, FT lazy dataset, Optuna namespace, graph/gnn, ResNet sanitize).
2. Expanded modelling regression set:
- `test_ft_checkpoints.py`
- `test_trainer_optuna_guards.py`
- `test_tweedie_power_param_filtering.py`
- `test_loss_resolution.py`
- plus all focused suites above.

### Current Result

- Full local release gate:
  - `tests/modelling tests/frontend tests/production tests/utils`
  - Result: `284 passed, 5 skipped`
- Additional focused gate:
  - `tests/frontend tests/production/test_inference.py tests/modelling/test_runtime_portability.py tests/modelling/test_ft_lazy_dataset.py tests/modelling/test_resn_param_sanitize.py`
  - Result: `82 passed, 1 skipped`

## 5. Residual Risk and Release Gate

- Residual risk is mainly environment-specific (actual CentOS7 dual-A30 runtime behavior under full production data volume).
- Release gate recommendation:
  1. Run torch1.x + CUDA smoke on target server.
  2. Run dual-GPU DDP/DataParallel smoke for FT and one non-FT model.
  3. Run 10M-row staged load test to tune `BAYESOPT_VAL_BATCH_CAP` and cache block parameters.

Status: Multi-agent re-audit PASS; candidate is code-complete and local regression clean. Proceed to server-side CentOS7 dual-A30 gate before production promotion.
