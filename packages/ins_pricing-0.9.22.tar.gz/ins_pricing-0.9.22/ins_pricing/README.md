# ins_pricing

Distribution name: `ins_pricing` (import package is also `ins_pricing`).

This repository is organized as layered tooling for modelling, pricing, production inference,
governance, reporting, and frontend workflows.

## Documentation Layers

- Layer 1 (global navigation): this file.
- Layer 2 (module boundaries and entrypoints):
  - [modelling/README.md](modelling/README.md)
  - [pricing/README.md](pricing/README.md)
  - [production/README.md](production/README.md)
  - [governance/README.md](governance/README.md)
  - [reporting/README.md](reporting/README.md)
  - [frontend/README.md](frontend/README.md)
- Layer 3 (deep-dive and reference):
  - [modelling/bayesopt/README.md](modelling/bayesopt/README.md) for BayesOpt internals and
    loss/distribution mapping.
  - [docs/api_reference.md](docs/api_reference.md) for package-level public exports.

## Architecture At A Glance

- `cli/`: training/explain/watchdog entry scripts and shared CLI helpers.
- `modelling/`: training, explainability, plotting, and evaluation.
- `pricing/`: exposure, factor tables, premium rating, calibration.
- `production/`: preprocessing, predictor loading, batch inference, monitoring metrics.
- `governance/`: registry, approvals, audit trail, release/rollback.
- `reporting/`: Markdown report generation and daily scheduling.
- `frontend/`: NiceGUI UI for config-driven workflows.
- `utils/`: shared utilities (metrics, paths, IO, numerics, logging, device helpers).

## Latest Code Alignment (2026-04-12)

- BayesOpt runtime now includes stronger portability and large-data safeguards:
  block-aligned shuffling for lazy datasets, final-train OOM retry tuning,
  validation batch capping, and expanded worker/context controls.
- Optuna study namespace now uses a stable signature suffix derived from model/task/search-space
  payload, reducing accidental cross-run study collisions.
- Frontend double-lift workflow now drops rows with invalid prediction values and reports
  how many rows were removed; UI default target key is `response`.
- Production inference now forwards GNN row-guard config (`gnn_max_fit_rows`,
  `gnn_max_predict_rows`, `gnn_predict_chunk_rows`) and applies ResNet `use_layernorm`
  from resolved params.
- Pricing, governance, and reporting public APIs remain stable in this release.
- Full release rationale and verification details: [docs/final_release_audit_report.md](docs/final_release_audit_report.md).

## Quick Start

```python
from ins_pricing.modelling import BayesOptConfig, BayesOptModel
from ins_pricing.pricing import rate_premium
from ins_pricing.production import load_predictor_from_config
```

## Typical Cross-Module Flow

1. Train with `modelling` (CLI, Python API, or frontend launcher).
2. Explain and evaluate with `modelling.explain`, `modelling.plotting`, and `modelling.evaluation`.
3. Build premiums with `pricing`.
4. Serve or batch-run predictions with `production`.
5. Track approvals/releases with `governance`.
6. Publish periodic summaries with `reporting`.

## Import Policy

Use canonical paths:

- `ins_pricing.modelling.*`
- `ins_pricing.pricing.*`
- `ins_pricing.production.*`
- `ins_pricing.governance.*`
- `ins_pricing.reporting.*`
- `ins_pricing.frontend.*`

`ins_pricing` and `ins_pricing.modelling` keep imports lazy so pricing/production/governance
can be imported without pulling heavy modelling dependencies.

## Torch 1.x Compatibility Check

Torch checkpoints are loaded with secure `weights_only` mode when available. On torch 1.x,
the package can fall back to trusted legacy loading through
`INS_PRICING_ALLOW_LEGACY_TORCH_LOAD=1` (default).

To validate torch 1.x runtime behavior in a torch 1.x environment:

```bash
./scripts/run_torch1_compat_smoke.sh
# or run the pytest commands directly:
python -m pytest tests/utils/test_model_loading.py -q
python -m pytest tests/production/test_inference.py tests/modelling/test_ft_checkpoints.py -q
```

## Runtime Tuning Environment Variables

- `BAYESOPT_WINDOWS_MAX_WORKERS`: caps auto `DataLoader` workers on Windows when
  `dataloader_workers` is not explicitly set. Default is `4`.
- `BAYESOPT_FT_LAZY_BLOCK_SIZE`: controls FT lazy-dataset encode/mask cache block size.
  Minimum effective value is `32`, default is `256`.
- `BAYESOPT_FT_LAZY_CACHE_BLOCKS`: number of lazy FT blocks kept in per-worker LRU cache.
  Default is `8`; increase this when using highly shuffled large datasets.
- `BAYESOPT_FT_PREPROC_BLOCK_ROWS`: FT numeric preprocessor block size (rows) used when
  computing mean/std without full-matrix materialization. Default is `200000`.
- `BAYESOPT_LARGE_DATASET_ROW_THRESHOLD`: row threshold that forces `workers=0` for
  block-cache lazy datasets to reduce host-memory amplification in large training runs.
  Default is `3000000`.
- `BAYESOPT_BLOCK_SHUFFLE_SEED`: seed for block-aligned shuffling used by lazy block-cache datasets.
  Default is `13`.
- `BAYESOPT_FINAL_TRAIN_OOM_RETRIES`: retry count for final-model `fit` on OOM with automatic
  fallback to memory-saving settings (larger `batch_num`, `workers=0`, `memory_saving` profile).
  Default is `2`.
- `BAYESOPT_VAL_BATCH_CAP`: optional hard cap for validation DataLoader batch size (all torch models).
  Default is unset (no cap).
