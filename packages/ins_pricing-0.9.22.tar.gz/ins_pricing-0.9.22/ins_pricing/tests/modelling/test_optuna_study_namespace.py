from __future__ import annotations

import importlib.util
import re
import sys
import types
from dataclasses import dataclass
from pathlib import Path

import pytest

pytest.importorskip("optuna")


REPO_ROOT = Path(__file__).resolve().parents[2]
MODULE_PATH = REPO_ROOT / "modelling" / "bayesopt" / "runtime" / "trainer_optuna.py"


def _load_trainer_optuna_module(monkeypatch: pytest.MonkeyPatch):
    fake_root = types.ModuleType("ins_pricing")
    fake_root.__path__ = [str(REPO_ROOT)]

    fake_modelling = types.ModuleType("ins_pricing.modelling")
    fake_modelling.__path__ = [str(REPO_ROOT / "modelling")]

    fake_bayesopt = types.ModuleType("ins_pricing.modelling.bayesopt")
    fake_bayesopt.__path__ = [str(REPO_ROOT / "modelling" / "bayesopt")]

    fake_bayesopt_utils = types.ModuleType("ins_pricing.modelling.bayesopt.utils")
    fake_bayesopt_utils.__path__ = [str(REPO_ROOT / "modelling" / "bayesopt" / "utils")]

    fake_utils = types.ModuleType("ins_pricing.utils")
    fake_utils.ensure_parent_dir = lambda *_args, **_kwargs: None
    fake_utils.get_logger = lambda _name: None
    fake_utils.log_print = lambda *_args, **_kwargs: None

    fake_artifacts = types.ModuleType("ins_pricing.modelling.bayesopt.artifacts")
    fake_artifacts.best_params_csv_path = lambda *args, **kwargs: Path("/tmp/best_params.csv")

    class _DistributedUtils:
        @staticmethod
        def is_main_process() -> bool:
            return True

    fake_distributed_utils = types.ModuleType(
        "ins_pricing.modelling.bayesopt.utils.distributed_utils"
    )
    fake_distributed_utils.DistributedUtils = _DistributedUtils

    fake_torch = types.ModuleType("torch")

    monkeypatch.setitem(sys.modules, "ins_pricing", fake_root)
    monkeypatch.setitem(sys.modules, "ins_pricing.modelling", fake_modelling)
    monkeypatch.setitem(sys.modules, "ins_pricing.modelling.bayesopt", fake_bayesopt)
    monkeypatch.setitem(sys.modules, "ins_pricing.modelling.bayesopt.utils", fake_bayesopt_utils)
    monkeypatch.setitem(sys.modules, "ins_pricing.utils", fake_utils)
    monkeypatch.setitem(sys.modules, "ins_pricing.modelling.bayesopt.artifacts", fake_artifacts)
    monkeypatch.setitem(
        sys.modules,
        "ins_pricing.modelling.bayesopt.utils.distributed_utils",
        fake_distributed_utils,
    )
    monkeypatch.setitem(sys.modules, "torch", fake_torch)

    spec = importlib.util.spec_from_file_location(
        "test_trainer_optuna_loaded",
        str(MODULE_PATH),
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to load module from {MODULE_PATH}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _make_trainer(module):
    class _DummyTrainer(module.TrainerOptunaMixin):
        def __init__(self) -> None:
            self.label = "Xgboost"
            self.model_name_prefix = "xgb"
            self.best_params = None
            self.best_trial = None
            self.study_name = None
            self.enable_distributed_optuna = False
            self.ctx = types.SimpleNamespace(
                model_nme="policy",
                rand_seed=13,
            )
            self.config = types.SimpleNamespace(
                optuna_storage=None,
                optuna_study_prefix="bayesopt",
                optuna_cleanup_synchronize=False,
            )
            self.output = types.SimpleNamespace(result_dir="/tmp")

        def _clean_gpu(self, synchronize: bool = False) -> None:
            _ = synchronize
            return None

    return _DummyTrainer()


def test_optuna_study_name_has_stable_signature_suffix(monkeypatch: pytest.MonkeyPatch):
    module = _load_trainer_optuna_module(monkeypatch)
    trainer = _make_trainer(module)

    study_name = trainer._resolve_optuna_study_name()
    study_name_repeat = trainer._resolve_optuna_study_name()

    assert study_name == study_name_repeat
    assert study_name.startswith("bayesopt_policy_xgb_")
    suffix = study_name.rsplit("_", 1)[-1]
    assert len(suffix) == 12
    assert re.fullmatch(r"[0-9a-f]{12}", suffix)


def test_optuna_study_name_changes_when_search_space_changes(
    monkeypatch: pytest.MonkeyPatch,
):
    module = _load_trainer_optuna_module(monkeypatch)
    trainer_a = _make_trainer(module)
    trainer_b = _make_trainer(module)
    trainer_b.config.xgb_search_space = {"max_depth": [4, 8], "eta": [0.05, 0.2]}
    trainer_b.config.loss_name = "poisson"

    study_name_a = trainer_a._resolve_optuna_study_name()
    study_name_b = trainer_b._resolve_optuna_study_name()

    assert study_name_a != study_name_b
    assert study_name_a.startswith("bayesopt_policy_xgb_")
    assert study_name_b.startswith("bayesopt_policy_xgb_")


def test_optuna_study_name_is_stable_with_set_values(monkeypatch: pytest.MonkeyPatch):
    module = _load_trainer_optuna_module(monkeypatch)
    trainer = _make_trainer(module)
    trainer.config.xgb_search_space = {"feature_subset": {"f3", "f1", "f2"}}

    name_a = trainer._resolve_optuna_study_name()
    name_b = trainer._resolve_optuna_study_name()

    assert name_a == name_b


def test_optuna_namespace_reads_dataclass_search_spaces(monkeypatch: pytest.MonkeyPatch):
    module = _load_trainer_optuna_module(monkeypatch)
    trainer = _make_trainer(module)

    @dataclass
    class _Cfg:
        optuna_storage: object = None
        optuna_study_prefix: str = "bayesopt"
        optuna_cleanup_synchronize: bool = False
        ft_role: str = "model"
        cv_strategy: str = "kfold"
        rand_seed: int = 13
        xgb_search_space: dict = None

    trainer.config = _Cfg(xgb_search_space={"max_depth": [4, 8], "eta": [0.05, 0.2]})
    payload = trainer._build_optuna_namespace_signature_payload()

    assert "xgb_search_space" in payload
    assert payload["xgb_search_space"]["max_depth"] == [4, 8]
