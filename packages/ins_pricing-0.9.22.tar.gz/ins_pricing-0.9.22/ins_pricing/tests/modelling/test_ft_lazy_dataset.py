from __future__ import annotations

from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest
import torch

from ins_pricing.modelling.bayesopt.models.model_ft_trainer import (
    _EpochMaskedTabularDataset,
    _FTPreprocessorSnapshot,
    _LazyFTMaskedDataset,
    _LazyFTSupervisedDataset,
    FTTransformerSklearn,
)


def _make_preprocessor_snapshot() -> _FTPreprocessorSnapshot:
    return _FTPreprocessorSnapshot(
        num_cols=["n1", "n2"],
        cat_cols=["c1"],
        num_mean=np.array([0.0, 0.0], dtype=np.float32),
        num_std=np.array([1.0, 1.0], dtype=np.float32),
        cat_categories={"c1": np.array(["a", "b"], dtype=object)},
        cat_maps={"c1": {"a": 0, "b": 1}},
        cat_str_maps={"c1": {"a": 0, "b": 1}},
        num_geo=0,
    )


def test_lazy_supervised_dataset_uses_block_cache(monkeypatch):
    n_rows = 64
    X = pd.DataFrame(
        {
            "n1": np.arange(n_rows, dtype=np.float32),
            "n2": np.arange(n_rows, dtype=np.float32) * 2.0,
            "c1": (["a", "b"] * (n_rows // 2)),
        }
    )
    y = np.arange(n_rows, dtype=np.float32)
    owner = SimpleNamespace(
        num_cols=["n1", "n2"],
        cat_cols=["c1"],
        _num_mean=np.array([0.0, 0.0], dtype=np.float32),
        _num_std=np.array([1.0, 1.0], dtype=np.float32),
        cat_categories={"c1": np.array(["a", "b"], dtype=object)},
        cat_maps={"c1": {"a": 0, "b": 1}},
        cat_str_maps={"c1": {"a": 0, "b": 1}},
        num_geo=0,
        _validate_vector=lambda *_args, **_kwargs: None,
    )
    monkeypatch.setenv("BAYESOPT_FT_LAZY_BLOCK_SIZE", "32")
    dataset = _LazyFTSupervisedDataset(owner, X, y)

    encode_num_calls = {"count": 0}
    encode_cat_calls = {"count": 0}
    orig_encode_nums = dataset.pre.encode_nums
    orig_encode_cats = dataset.pre.encode_cats

    def _count_encode_nums(frame):
        encode_num_calls["count"] += 1
        return orig_encode_nums(frame)

    def _count_encode_cats(frame):
        encode_cat_calls["count"] += 1
        return orig_encode_cats(frame)

    monkeypatch.setattr(dataset.pre, "encode_nums", _count_encode_nums)
    monkeypatch.setattr(dataset.pre, "encode_cats", _count_encode_cats)

    _ = dataset[0]
    _ = dataset[1]
    _ = dataset[3]
    assert encode_num_calls["count"] == 1
    assert encode_cat_calls["count"] == 1

    _ = dataset[32]
    assert encode_num_calls["count"] == 2
    assert encode_cat_calls["count"] == 2


def test_lazy_masked_dataset_mask_block_changes_by_epoch(monkeypatch):
    pre = _make_preprocessor_snapshot()
    n_rows = 64
    X = pd.DataFrame(
        {
            "n1": np.linspace(0.1, 1.5, n_rows, dtype=np.float32),
            "n2": np.linspace(1.0, 3.5, n_rows, dtype=np.float32),
            "c1": (["a", "b"] * (n_rows // 2)),
        }
    )
    monkeypatch.setenv("BAYESOPT_FT_LAZY_BLOCK_SIZE", "32")
    dataset = _LazyFTMaskedDataset(pre, X, mask_prob_num=0.5, mask_prob_cat=0.5, seed=17)

    dataset.set_epoch(0)
    _ = dataset[0]
    num_mask_epoch0 = np.asarray(dataset._cache_num_mask, dtype=bool).copy()
    cat_mask_epoch0 = np.asarray(dataset._cache_cat_mask, dtype=bool).copy()
    dataset.set_epoch(1)
    _ = dataset[0]
    num_mask_epoch1 = np.asarray(dataset._cache_num_mask, dtype=bool).copy()
    cat_mask_epoch1 = np.asarray(dataset._cache_cat_mask, dtype=bool).copy()

    assert not np.array_equal(num_mask_epoch0, num_mask_epoch1)
    assert not np.array_equal(cat_mask_epoch0, cat_mask_epoch1)


def test_lazy_masked_dataset_epoch_ref_only_update_changes_mask(monkeypatch):
    pre = _make_preprocessor_snapshot()
    n_rows = 64
    X = pd.DataFrame(
        {
            "n1": np.linspace(0.1, 1.5, n_rows, dtype=np.float32),
            "n2": np.linspace(1.0, 3.5, n_rows, dtype=np.float32),
            "c1": (["a", "b"] * (n_rows // 2)),
        }
    )
    monkeypatch.setenv("BAYESOPT_FT_LAZY_BLOCK_SIZE", "32")
    dataset = _LazyFTMaskedDataset(pre, X, mask_prob_num=0.5, mask_prob_cat=0.5, seed=23)

    dataset.set_epoch(0)
    _ = dataset[0]
    num_mask_epoch0 = np.asarray(dataset._cache_num_mask, dtype=bool).copy()
    cat_mask_epoch0 = np.asarray(dataset._cache_cat_mask, dtype=bool).copy()

    # Simulate worker process behavior: epoch ref shared memory updates,
    # but worker-side set_epoch is not called.
    dataset._epoch_ref[0] = 1
    _ = dataset[0]
    num_mask_epoch1 = np.asarray(dataset._cache_num_mask, dtype=bool).copy()
    cat_mask_epoch1 = np.asarray(dataset._cache_cat_mask, dtype=bool).copy()

    assert not np.array_equal(num_mask_epoch0, num_mask_epoch1)
    assert not np.array_equal(cat_mask_epoch0, cat_mask_epoch1)


def test_epoch_masked_dataset_mask_block_changes_by_epoch(monkeypatch):
    monkeypatch.setenv("BAYESOPT_FT_LAZY_BLOCK_SIZE", "32")
    dataset = _EpochMaskedTabularDataset(
        X_num=torch.ones((64, 6), dtype=torch.float32),
        X_cat=torch.ones((64, 3), dtype=torch.long),
        X_geo=torch.zeros((64, 0), dtype=torch.float32),
        mask_prob_num=0.5,
        mask_prob_cat=0.5,
        unknown_idx=torch.tensor([3, 3, 3], dtype=torch.long),
        seed=29,
    )

    dataset.set_epoch(0)
    _ = dataset[0]
    num_mask_epoch0 = np.asarray(dataset._cache_num_mask, dtype=bool).copy()
    cat_mask_epoch0 = np.asarray(dataset._cache_cat_mask, dtype=bool).copy()
    dataset.set_epoch(1)
    _ = dataset[0]
    num_mask_epoch1 = np.asarray(dataset._cache_num_mask, dtype=bool).copy()
    cat_mask_epoch1 = np.asarray(dataset._cache_cat_mask, dtype=bool).copy()

    assert not np.array_equal(num_mask_epoch0, num_mask_epoch1)
    assert not np.array_equal(cat_mask_epoch0, cat_mask_epoch1)


def test_epoch_masked_dataset_epoch_ref_only_update_changes_mask(monkeypatch):
    monkeypatch.setenv("BAYESOPT_FT_LAZY_BLOCK_SIZE", "32")
    dataset = _EpochMaskedTabularDataset(
        X_num=torch.ones((64, 6), dtype=torch.float32),
        X_cat=torch.ones((64, 3), dtype=torch.long),
        X_geo=torch.zeros((64, 0), dtype=torch.float32),
        mask_prob_num=0.5,
        mask_prob_cat=0.5,
        unknown_idx=torch.tensor([3, 3, 3], dtype=torch.long),
        seed=37,
    )
    dataset.set_epoch(0)
    _ = dataset[0]
    num_mask_epoch0 = np.asarray(dataset._cache_num_mask, dtype=bool).copy()
    cat_mask_epoch0 = np.asarray(dataset._cache_cat_mask, dtype=bool).copy()

    dataset._epoch_ref[0] = 1
    _ = dataset[0]
    num_mask_epoch1 = np.asarray(dataset._cache_num_mask, dtype=bool).copy()
    cat_mask_epoch1 = np.asarray(dataset._cache_cat_mask, dtype=bool).copy()

    assert not np.array_equal(num_mask_epoch0, num_mask_epoch1)
    assert not np.array_equal(cat_mask_epoch0, cat_mask_epoch1)


def test_lazy_masked_dataset_supports_multi_worker_dataloader(monkeypatch):
    pre = _make_preprocessor_snapshot()
    n_rows = 64
    X = pd.DataFrame(
        {
            "n1": np.linspace(0.1, 1.5, n_rows, dtype=np.float32),
            "n2": np.linspace(1.0, 3.5, n_rows, dtype=np.float32),
            "c1": (["a", "b"] * (n_rows // 2)),
        }
    )
    monkeypatch.setenv("BAYESOPT_FT_LAZY_BLOCK_SIZE", "32")
    dataset = _LazyFTMaskedDataset(pre, X, mask_prob_num=0.25, mask_prob_cat=0.35, seed=31)
    dataset.set_epoch(2)

    loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=8,
        num_workers=2,
        shuffle=False,
    )
    try:
        batch = next(iter(loader))
    except RuntimeError as exc:
        if "torch_shm_manager" in str(exc) or "Operation not permitted" in str(exc):
            pytest.skip("multiprocessing shared-memory unavailable in current runtime")
        raise
    assert len(batch) == 7
    assert int(batch[0].shape[0]) == 8


def test_ft_preprocessor_block_stats_match_numpy(monkeypatch):
    monkeypatch.setenv("BAYESOPT_FT_PREPROC_BLOCK_ROWS", "2")
    X = pd.DataFrame(
        {
            "n1": [1.0, np.nan, 3.0, 4.0],
            "n2": [2.0, 4.0, np.inf, 8.0],
        }
    )
    model = FTTransformerSklearn(
        model_nme="ft",
        num_cols=["n1", "n2"],
        cat_cols=[],
        use_gpu=False,
        use_ddp=False,
        use_data_parallel=False,
        epochs=2,
        batch_num=4,
        patience=1,
        task_type="regression",
    )
    model._fit_preprocessor(X)

    expected = np.nan_to_num(
        X[["n1", "n2"]].to_numpy(dtype=np.float32, copy=False),
        nan=0.0,
        posinf=0.0,
        neginf=0.0,
    )
    expected_mean = expected.mean(axis=0).astype(np.float32, copy=False)
    expected_std = expected.std(axis=0).astype(np.float32, copy=False)
    expected_std = np.where(expected_std < 1e-6, 1.0, expected_std).astype(np.float32, copy=False)

    np.testing.assert_allclose(model._num_mean, expected_mean)
    np.testing.assert_allclose(model._num_std, expected_std)
