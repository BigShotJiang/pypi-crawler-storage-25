from __future__ import annotations

import inspect
from types import SimpleNamespace

from ins_pricing.modelling.bayesopt.trainers.trainer_resn import ResNetTrainer


def test_resn_sanitize_best_params_does_not_build_probe_model(monkeypatch):
    cfg = SimpleNamespace(
        distributed=SimpleNamespace(use_resn_ddp=False),
        invalid_param_policy="ignore",
    )
    ctx = SimpleNamespace(
        task_type="regression",
        use_gpu=False,
        config=cfg,
        loss_name="gamma",
    )
    trainer = ResNetTrainer(ctx)

    def _fail_if_called(*_args, **_kwargs):
        raise AssertionError("_build_model should not be called by _sanitize_best_params")

    monkeypatch.setattr(trainer, "_build_model", _fail_if_called)

    sanitized = trainer._sanitize_best_params(
        {
            "hidden_dim": 128,
            "dropout": 0.1,
            "tw_power": 1.7,
            "unsupported_key": 42,
        }
    )

    assert sanitized["hidden_dim"] == 128
    assert sanitized["dropout"] == 0.1
    assert "tw_power" not in sanitized
    assert "unsupported_key" not in sanitized


def test_resn_allowlist_covers_supported_tunable_fields():
    expected_tunable = {
        "hidden_dim",
        "block_num",
        "batch_num",
        "epochs",
        "learning_rate",
        "patience",
        "use_layernorm",
        "dropout",
        "residual_scale",
        "stochastic_depth",
        "weight_decay",
        "use_data_parallel",
        "use_ddp",
        "use_lazy_dataset",
        "predict_batch_size",
        "tw_power",
    }
    from ins_pricing.modelling.bayesopt.models.model_resn import ResNetSklearn

    constructor_keys = set(inspect.signature(ResNetSklearn.__init__).parameters.keys())
    constructor_keys.discard("self")
    supported_keys = constructor_keys | {"use_lazy_dataset", "predict_batch_size", "tw_power"}
    assert expected_tunable <= set(ResNetTrainer._RESN_PARAM_KEYS)
    assert set(ResNetTrainer._RESN_PARAM_KEYS) <= supported_keys


def test_resn_build_model_applies_use_layernorm_param():
    cfg = SimpleNamespace(
        distributed=SimpleNamespace(use_resn_ddp=False, use_resn_data_parallel=False),
        invalid_param_policy="ignore",
    )
    ctx = SimpleNamespace(
        task_type="regression",
        use_gpu=False,
        config=cfg,
        loss_name="gamma",
        model_nme="resn",
        epochs=2,
        var_nmes=["x1", "x2", "x3"],
        distribution=None,
        default_tweedie_power=lambda: 1.5,
    )
    trainer = ResNetTrainer(ctx)
    model = trainer._build_model({"use_layernorm": False})
    assert model.use_layernorm is False
