from __future__ import annotations

import torch

import ins_pricing.modelling.bayesopt.models.model_gnn as gnn_mod


def test_gnn_set_params_rebuilds_backbone_with_parallel_wrapper(monkeypatch):
    calls = []

    def _fake_wrap_model_for_parallel(model, **kwargs):
        calls.append(dict(kwargs))
        return model, bool(kwargs.get("use_data_parallel", False)), kwargs.get("device")

    monkeypatch.setattr(gnn_mod, "wrap_model_for_parallel", _fake_wrap_model_for_parallel)
    monkeypatch.setattr(gnn_mod.torch.cuda, "is_available", lambda: False)
    monkeypatch.setattr(gnn_mod.DeviceManager, "is_mps_available", staticmethod(lambda: False))

    model = gnn_mod.GraphNeuralNetSklearn(
        model_nme="policy",
        input_dim=4,
        hidden_dim=8,
        num_layers=2,
        k_neighbors=3,
        use_data_parallel=True,
        use_ddp=False,
        use_gpu=True,
    )
    assert calls, "Expected constructor to route through wrap_model_for_parallel"
    first_call = calls[-1]
    assert first_call["use_data_parallel"] is True

    model.set_params({"hidden_dim": 16})
    second_call = calls[-1]
    assert second_call["use_data_parallel"] is True

    model.set_params({"use_data_parallel": False, "hidden_dim": 12})
    third_call = calls[-1]
    assert third_call["use_data_parallel"] is False
    assert isinstance(model.gnn, torch.nn.Module)
