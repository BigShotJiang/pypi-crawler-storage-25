"""Central state and pure reducers for the v2 dashboard."""

from __future__ import annotations

import colorsys
import hashlib
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from loguru import logger

from ._data import RepoStatus, load_cache, load_cache_timestamp, load_health_cache
from .health import RepoHealth, Severity

if TYPE_CHECKING:
    from ._gql import TeamsSnapshot
    from .awsprobe import AwsState
    from .sysmeter import GpuStats, RamStats
    from .sysprobe import DnsCheckResult, PingResult, SystemSnapshot

# Panel sizing -- mirrors v1 constraints (lesson #13).
PANEL_WIDTH_DEFAULT = 38
PANEL_WIDTH_MIN = 24
PANEL_WIDTH_MAX = 60
PANEL_WIDTH_STEP = 2

UNASSIGNED_TEAM = "unassigned"
OPEN_SOURCE_TEAM = "__open_source__"

SORT_MODES: tuple[str, ...] = ("health", "alpha", "issues", "prs")

# --- Filter categories ---------------------------------------------------
VISIBILITY_FILTERS: tuple[str, ...] = ("private", "public")
HEALTH_FILTERS: tuple[str, ...] = (
    "broken-ci",
    "no-renovate",
    "renovate-prs-piling",
    "stale-prs",
    "issues",
)
FILTER_MODES: tuple[str, ...] = (
    "all",
    *VISIBILITY_FILTERS,
    *HEALTH_FILTERS,
)

_TEAM_FILTER_PREFIX = "team:"
_ORG_FILTER_PREFIX = "org:"


@dataclass(frozen=True)
class RepoTeamInfo:
    """GitHub team ownership for a repo -- primary team plus every team."""

    primary: str = UNASSIGNED_TEAM
    all: tuple[str, ...] = ()


@dataclass(frozen=True)
class ErrorEntry:
    """A single entry in the error log drawer."""

    timestamp: datetime
    source: str  # "refresh" | "usage" | "cache" | "ui"
    message: str


@dataclass(frozen=True)
class FilterSections:
    """Grouped filter modes for the sectioned filter panel."""

    orgs: list[str]
    teams: list[str]
    visibility: list[str]
    health: list[str]

    def all_modes(self) -> list[str]:
        """Flat list of every filter mode across all sections."""
        return [*self.orgs, *self.teams, *self.visibility, *self.health]


@dataclass
class AppState:
    """Mutable app state. Widgets read from here; workers write to it."""

    healths: list[RepoHealth] = field(default_factory=list)
    health_by_name: dict[str, RepoHealth] = field(default_factory=dict)
    repo_teams: dict[str, RepoTeamInfo] = field(default_factory=dict)
    team_labels: dict[str, str] = field(default_factory=lambda: {UNASSIGNED_TEAM: "Unassigned"})
    gpu_stats: GpuStats | None = None
    ram_stats: RamStats | None = None
    system_snapshot: SystemSnapshot | None = None
    aws_state: AwsState | None = None
    ping_result: PingResult | None = None
    dns_results: list[DnsCheckResult] = field(default_factory=list)
    docker_filter_augint_shell: bool = False
    errors: list[ErrorEntry] = field(default_factory=list)

    sort_mode: str = SORT_MODES[0]
    active_filters: set[str] = field(default_factory=set)
    hide_workspace: bool = False
    search_text: str = ""
    layout_name: str = "packed"
    theme_name: str = "default"
    panel_width: int = PANEL_WIDTH_DEFAULT

    selected_full_name: str | None = None

    last_refresh_at: datetime | None = None
    next_refresh_at: datetime | None = None
    is_refreshing: bool = False
    consecutive_errors: int = 0
    last_error_message: str | None = None

    # API rate limit tracking (updated after each refresh).
    gql_remaining: int = 5000
    gql_limit: int = 5000
    gql_reset_at: datetime | None = None
    rest_remaining: int = 5000
    rest_limit: int = 5000
    rest_reset_at: datetime | None = None

    # Repos whose most recent refresh attempt failed (shown gray/stale).
    stale_repos: set[str] = field(default_factory=set)

    # Cooperative cancellation flag for threaded workers.
    cancel_requested: bool = False

    def log_error(self, source: str, message: str, *, limit: int = 200) -> None:
        self.errors.append(ErrorEntry(timestamp=datetime.now(UTC), source=source, message=message))
        if len(self.errors) > limit:
            del self.errors[: len(self.errors) - limit]

    def clear_errors(self) -> None:
        self.errors.clear()


# ---------------------------------------------------------------------------
# Team helpers
# ---------------------------------------------------------------------------


def team_filter_mode(team_key: str) -> str:
    return f"{_TEAM_FILTER_PREFIX}{team_key}"


def team_key_from_filter(mode: str) -> str | None:
    if mode.startswith(_TEAM_FILTER_PREFIX):
        return mode.removeprefix(_TEAM_FILTER_PREFIX)
    return None


# ---------------------------------------------------------------------------
# Org (owner) helpers
# ---------------------------------------------------------------------------


def org_filter_mode(owner: str) -> str:
    return f"{_ORG_FILTER_PREFIX}{owner}"


def org_key_from_filter(mode: str) -> str | None:
    if mode.startswith(_ORG_FILTER_PREFIX):
        return mode.removeprefix(_ORG_FILTER_PREFIX)
    return None


def owner_of(full_name: str) -> str:
    """Extract the owner (org or user) from a ``owner/repo`` full name."""
    return full_name.split("/", 1)[0] if "/" in full_name else full_name


def display_team_label(team_key: str, team_labels: dict[str, str]) -> str:
    if team_key == UNASSIGNED_TEAM:
        return "Unassigned"
    if team_key == OPEN_SOURCE_TEAM:
        return "Open Source"
    return team_labels.get(team_key, team_key.replace("-", " ").title())


# Golden-angle hue step -- guarantees that every new slot lands maximally far
# from the previously-used hues, so adjacent teams can never collide into
# similar colours (e.g. "woxom" vs "augmenting-integrations" both being blue).
_GOLDEN_ANGLE = 137.50776405003785
# Fixed saturation / lightness -- tuned for terminal legibility against both
# dark and paper-like backgrounds.
_TEAM_ACCENT_S = 0.60
_TEAM_ACCENT_L = 0.62


def _hsl_hex(hue_deg: float) -> str:
    h = (hue_deg % 360.0) / 360.0
    r, g, b = colorsys.hls_to_rgb(h, _TEAM_ACCENT_L, _TEAM_ACCENT_S)
    return f"#{int(r * 255):02x}{int(g * 255):02x}{int(b * 255):02x}"


def team_accent(team_key: str, known_teams: Iterable[str] | None = None) -> str:
    """Return a deterministic hex colour for ``team_key``.

    When ``known_teams`` is supplied, colours are assigned by *sorted index*
    through the golden-angle rotation, so every team in that set is guaranteed
    a maximally-distinct hue from its neighbours. Without it we fall back to
    hashing the team key into the same rotation -- still deterministic per
    key, but no longer guaranteed distinct between a given pair of keys.
    """
    if team_key == UNASSIGNED_TEAM:
        return "#808080"
    if known_teams is not None:
        keys = sorted({k for k in known_teams if k and k != UNASSIGNED_TEAM})
        if team_key in keys:
            idx = keys.index(team_key)
            return _hsl_hex(idx * _GOLDEN_ANGLE)
    digest = hashlib.sha256(team_key.encode("utf-8")).digest()
    idx = int.from_bytes(digest[:2], "big")
    return _hsl_hex(idx * _GOLDEN_ANGLE)


def merge_teams_snapshot(
    state: AppState,
    snapshot: TeamsSnapshot,
    known_repos: Iterable[str],
) -> None:
    """Apply a batched GraphQL teams snapshot to state.

    Replaces the previous REST-per-repo ``merge_team_data`` flow: one GraphQL
    query covers every team in every org, and the snapshot already contains
    the sorted (primary-first) assignment list. Must run on the main thread.

    Args:
        state: AppState to mutate (repo_teams, team_labels).
        snapshot: Fresh TeamsSnapshot from ``_gql.fetch_workspace_teams``.
        known_repos: All repo full_names currently in the workspace. Repos
            with no GraphQL team assignment get a default ``RepoTeamInfo()``
            so the filter panel still lists them (apply_open_source_team
            promotes unassigned personal repos afterward).
    """
    state.team_labels.update(snapshot.labels)
    for full_name in known_repos:
        assignments = snapshot.by_full_name.get(full_name)
        if not assignments:
            # Personal repo, or org repo with no team access grants.
            state.repo_teams[full_name] = RepoTeamInfo()
            continue
        slugs = tuple(a.slug for a in assignments)
        state.repo_teams[full_name] = RepoTeamInfo(primary=slugs[0], all=slugs)
    if snapshot.errored:
        for owner, err in snapshot.errored.items():
            logger.debug(f"teams fetch for {owner}: {err}")


def apply_open_source_team(state: AppState) -> None:
    """Promote personal public repos with no team to the Open Source group."""
    state.team_labels[OPEN_SOURCE_TEAM] = "Open Source"
    for full_name, health in state.health_by_name.items():
        info = state.repo_teams.get(full_name, RepoTeamInfo())
        if info.primary == UNASSIGNED_TEAM and not health.status.private:
            state.repo_teams[full_name] = RepoTeamInfo(
                primary=OPEN_SOURCE_TEAM,
                all=(OPEN_SOURCE_TEAM,),
            )


# ---------------------------------------------------------------------------
# Reducers (pure functions; easy to unit-test)
# ---------------------------------------------------------------------------


def apply_sort(
    healths: list[RepoHealth],
    mode: str,
    repo_teams: dict[str, RepoTeamInfo] | None = None,
) -> list[RepoHealth]:
    if mode == "alpha":
        return sorted(healths, key=lambda h: h.status.name.lower())
    if mode == "issues":
        return sorted(healths, key=lambda h: h.status.open_issues, reverse=True)
    if mode == "prs":
        return sorted(healths, key=lambda h: h.status.open_prs, reverse=True)
    # "health": primary=severity, secondary=team, tertiary=problem count.
    teams = repo_teams or {}
    return sorted(
        healths,
        key=lambda h: (
            int(h.worst_severity),
            teams.get(h.status.full_name, RepoTeamInfo()).primary,
            h.score,
        ),
    )


def _matches_filter(h: RepoHealth, mode: str, repo_teams: dict[str, RepoTeamInfo]) -> bool:
    """Check whether a single health entry passes a single filter mode."""
    if mode == "private":
        return h.status.private
    if mode == "public":
        return not h.status.private
    if mode == "broken-ci":
        return any(c.check_name == "broken_ci" and c.severity != Severity.OK for c in h.checks)
    if mode == "no-renovate":
        return any(
            c.check_name == "renovate_enabled" and c.severity != Severity.OK for c in h.checks
        )
    if mode == "renovate-prs-piling":
        return any(
            c.check_name == "renovate_prs_piling" and c.severity != Severity.OK for c in h.checks
        )
    if mode == "stale-prs":
        return any(c.check_name == "stale_prs" and c.severity != Severity.OK for c in h.checks)
    if mode == "issues":
        return any(c.check_name == "open_issues" and c.severity != Severity.OK for c in h.checks)
    team_key = team_key_from_filter(mode)
    if team_key is not None:
        info = repo_teams.get(h.status.full_name)
        if info is None:
            # Team data not fetched yet -- include the repo so it isn't
            # hidden just because the refresh hasn't completed.
            return True
        if team_key == UNASSIGNED_TEAM:
            return info.primary == UNASSIGNED_TEAM
        return team_key in info.all
    org_key = org_key_from_filter(mode)
    if org_key is not None:
        return owner_of(h.status.full_name) == org_key
    return True


def apply_filter(
    healths: list[RepoHealth],
    mode: str,
    repo_teams: dict[str, RepoTeamInfo] | None = None,
) -> list[RepoHealth]:
    if mode == "all":
        return list(healths)
    teams = repo_teams or {}
    return [h for h in healths if _matches_filter(h, mode, teams)]


def apply_active_filters(
    healths: list[RepoHealth],
    active: set[str],
    repo_teams: dict[str, RepoTeamInfo] | None = None,
) -> list[RepoHealth]:
    """Apply multiple filters with OR semantics.

    Every checked filter is an OR **selection**: each checked item adds
    matching repos to the visible set.  This matches the mental model
    of a multi-select checklist where checking ``broken-ci`` +
    ``team:woxom`` means "show broken-CI repos PLUS woxom repos."
    """
    if not active:
        return list(healths)
    teams = repo_teams or {}
    selections = sorted(active)
    return [h for h in healths if any(_matches_filter(h, mode, teams) for mode in selections)]


def available_filter_sections(
    team_labels: dict[str, str],
    repo_teams: dict[str, RepoTeamInfo],
    healths: list[RepoHealth] | None = None,
) -> FilterSections:
    """Return filter modes grouped into UI sections."""
    team_keys = {team for info in repo_teams.values() for team in (info.all or (info.primary,))}
    team_dynamic = [
        team_filter_mode(team_key)
        for team_key in sorted(
            team_keys, key=lambda key: display_team_label(key, team_labels).lower()
        )
    ]
    org_keys: set[str] = set()
    if healths:
        org_keys = {owner_of(h.status.full_name) for h in healths}
    org_dynamic = [org_filter_mode(key) for key in sorted(org_keys)]
    return FilterSections(
        orgs=org_dynamic,
        teams=team_dynamic,
        visibility=list(VISIBILITY_FILTERS),
        health=list(HEALTH_FILTERS),
    )


def available_filter_modes(
    team_labels: dict[str, str],
    repo_teams: dict[str, RepoTeamInfo],
    healths: list[RepoHealth] | None = None,
) -> list[str]:
    """Flat list of all available filter modes (compat wrapper)."""
    sections = available_filter_sections(team_labels, repo_teams, healths)
    return [*FILTER_MODES, *sections.orgs, *sections.teams]


def fuzzy_match(haystack: str, needle: str) -> bool:
    """fzf-style fuzzy match: chars of needle appear in order in haystack."""
    if not needle:
        return True
    hay = haystack.lower()
    ndl = needle.lower()
    it = iter(hay)
    return all(c in it for c in ndl)


def apply_fuzzy_filter(
    healths: list[RepoHealth],
    query: str,
) -> list[RepoHealth]:
    """Filter repos by fuzzy-matching the query against full_name."""
    if not query:
        return healths
    return [h for h in healths if fuzzy_match(h.status.full_name, query)]


def visible_healths(state: AppState) -> list[RepoHealth]:
    pool = state.healths
    if state.hide_workspace:
        pool = [h for h in pool if not h.status.is_workspace]
    pool = apply_active_filters(pool, state.active_filters, state.repo_teams)
    pool = apply_fuzzy_filter(pool, state.search_text)
    return apply_sort(
        pool,
        state.sort_mode,
        state.repo_teams,
    )


def ensure_selection(state: AppState) -> None:
    vis = visible_healths(state)
    if not vis:
        state.selected_full_name = None
        return
    names = {h.status.full_name for h in vis}
    if state.selected_full_name not in names:
        state.selected_full_name = vis[0].status.full_name


def selected_health(state: AppState) -> RepoHealth | None:
    ensure_selection(state)
    if state.selected_full_name is None:
        return None
    return state.health_by_name.get(state.selected_full_name)


def move_selection(state: AppState, delta: int) -> None:
    vis = visible_healths(state)
    if not vis:
        return
    ensure_selection(state)
    current_index = next(
        (i for i, h in enumerate(vis) if h.status.full_name == state.selected_full_name),
        0,
    )
    new_index = max(0, min(len(vis) - 1, current_index + delta))
    state.selected_full_name = vis[new_index].status.full_name


# ---------------------------------------------------------------------------
# Cache bootstrap
# ---------------------------------------------------------------------------


def bootstrap_from_cache(state: AppState, restrict_to: set[str] | None = None) -> bool:
    """Populate state.healths from the on-disk cache. Returns True if loaded.

    Also seeds ``last_refresh_at`` from the cache's ``health_ts`` so the
    staleness indicator shows a real "updated Xm ago" value from the
    first paint, instead of staying blank until the first live refresh
    lands.
    """
    try:
        cache = load_cache()
        if restrict_to is not None:
            cache = {k: v for k, v in cache.items() if k in restrict_to}
        if not cache:
            return False
        statuses: list[RepoStatus] = list(cache.values())
        health_cache = load_health_cache(cache)
        state.healths = [health_cache.get(s.full_name) or RepoHealth(status=s) for s in statuses]
        state.health_by_name = {h.status.full_name: h for h in state.healths}
        # Best-effort -- if the cache predates the health_ts field we just
        # leave last_refresh_at as None and the staleness chip will show
        # "loading..." until the first live refresh commits.
        cache_ts = load_cache_timestamp()
        if cache_ts is not None:
            state.last_refresh_at = cache_ts
        return True
    except Exception as exc:
        state.log_error("cache", f"{exc.__class__.__name__}: {exc}")
        return False
