from setuptools import setup, find_packages

with open("README.md", "r") as f:
    description = f.read()

setup(
    name="amazon-ads-api-connector",
    version="0.2.0",
    packages=find_packages(),
    install_requires=[
        "httpx",
    ],
    author="Markus U. Wahl",
    long_description=description,
    long_description_content_type="text/markdown",
    description="API wrapper for the Amazon Ads API",
)

# pip install setuptools wheel twine
# python setup.py sdist bdist_wheel
# pip install twine
# twine upload dist/*
