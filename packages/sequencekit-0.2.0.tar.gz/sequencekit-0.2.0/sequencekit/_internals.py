from collections import Counter 

_SUPPORTED_TYPES = (str, list, tuple)

def _validate_sequence(sequence):
    if not isinstance(sequence, _SUPPORTED_TYPES):
        raise TypeError(
            f"Invalid input type: {type(sequence).__name__}. "
            "Expected: str, list, tuple"
        )

def _frequency_map(sequence):
    """
    freq = {} 
    for item in sequence: 
        freq[item] = freq.get(item, 0) + 1
    return freq
    """
    return Counter(sequence)

def _convert_output(result, out="list"):
    out = out.lower().strip()

    if out == "list":
        return result if isinstance(result, list) else list(result)
    
    if out == "tuple":
        return tuple(result)
    
    if out == "str":
        if not all(isinstance(x, str) for x in result):
            raise TypeError(
                "Cannot convert non-string items to string"
            )
        return "".join(result)
    
    raise ValueError(
        f"Invalid output type: {out}. "
        "Expected: 'list', 'tuple', 'str'"
    )