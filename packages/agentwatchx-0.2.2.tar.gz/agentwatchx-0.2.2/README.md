# AgentWatchX Python SDK

Observability for AI agents. Catches hallucinations, silent failures, and missing executions automatically.

## Install

```bash
pip install agentwatchx
```

## 2-Line Integration

```python
import agentwatchx
agentwatchx.init(api_key="your_api_key")

# That's it. Every OpenAI/Anthropic/Gemini/Groq/Mistral/LangChain/LlamaIndex call is now traced.
# No decorators, no wrappers, no code changes needed.
```

## What it captures

- Model, input, output, token usage, latency — automatically
- Tool calls made by the LLM (function calling)
- Hallucination detection — agent claims actions it never performed
- Failure masking — tool errors the agent hides from users
- Missing execution — user asks for action, agent just talks

## Supported Libraries

| Library | Auto-instrumented |
|---|---|
| OpenAI | ✅ |
| Anthropic | ✅ |
| Gemini | ✅ |
| Groq | ✅ |
| Mistral | ✅ |
| LangChain | ✅ |
| LlamaIndex | ✅ |

## Configuration

```python
agentwatchx.init(
    api_key="your_api_key",
)
```

## Advanced Usage

```python
# Manual trace decorator
@agentwatchx.trace
def my_agent(query: str):
    return client.chat.completions.create(...)

# Manual logging
agentwatchx.log({"service": "my-agent", "input": "hello", "output": "world"})

# Check status
print(agentwatchx.status())
# → {"initialized": True, "instrumented": ["openai"], "buffered_traces": 0}
```

## Links

- [Documentation](https://agentwatchx.com/docs)
- [Dashboard](https://agentwatchx.com/dashboard)
