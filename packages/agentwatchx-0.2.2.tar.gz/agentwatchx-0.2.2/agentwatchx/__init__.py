"""AgentWatchX — Observability SDK for AI Agent Execution."""

from agentwatchx.client import AgentWatchXClient
from agentwatchx.decorators import trace
from agentwatchx.schemas import TraceData, ToolCallData

# Module-level client instance
_client: AgentWatchXClient | None = None


def init(api_key: str, endpoint: str = "https://agentwatchx-api-production.up.railway.app", auto_instrument: bool = True, **kwargs):
    """Initialize the AgentWatchX SDK.

    After calling init(), tracing begins automatically for supported libraries
    (OpenAI, Anthropic, Gemini, Groq, Mistral, LangChain, LlamaIndex) if they are installed.

    Set auto_instrument=False to disable auto-patching and use manual
    capture/wrap/trace only.
    """
    global _client
    _client = AgentWatchXClient(api_key=api_key, endpoint=endpoint, **kwargs)

    if auto_instrument:
        from agentwatchx.integrations import auto_instrument as _auto
        _auto(_client)

    return _client


def get_client() -> AgentWatchXClient:
    if _client is None:
        raise RuntimeError("AgentWatchX SDK not initialized. Call agentwatchx.init() first.")
    return _client


def wrap(llm_client):
    """Wrap an LLM client instance for explicit trace capture.

    This is optional when auto-instrumentation is active. Use it when you
    want to trace a specific client instance without global patching.

    Supported: OpenAI, Anthropic client instances.
    """
    if _client is None:
        raise RuntimeError("AgentWatchX SDK not initialized. Call agentwatchx.init() first.")

    # Detect client type and apply instance-level wrapping
    client_type = type(llm_client).__module__

    if "openai" in client_type:
        from agentwatchx.integrations.openai_patch import patch
        patch(_client)
    elif "anthropic" in client_type:
        from agentwatchx.integrations.anthropic_patch import patch
        patch(_client)

    return llm_client


def log(data: dict):
    """Manually log a trace from a dict. Convenience for custom events."""
    if _client is None:
        raise RuntimeError("AgentWatchX SDK not initialized. Call agentwatchx.init() first.")

    tool_calls = []
    for tc in data.get("tool_calls", []):
        tool_calls.append(ToolCallData(**tc) if isinstance(tc, dict) else tc)

    trace_data = TraceData(
        service=data.get("service", data.get("type", "custom")),
        input_text=str(data.get("input", data.get("input_text", ""))),
        output_text=str(data.get("output", data.get("output_text", ""))) if data.get("output") or data.get("output_text") else None,
        llm_model=data.get("llm_model", data.get("model")),
        duration_ms=data.get("duration_ms"),
        tool_calls=tool_calls,
        metadata={k: v for k, v in data.items() if k not in {
            "service", "type", "input", "input_text", "output", "output_text",
            "llm_model", "model", "duration_ms", "tool_calls",
        }},
    )
    _client.capture(trace_data)


def shutdown():
    """Flush pending traces and close the client."""
    if _client:
        from agentwatchx.integrations import unpatch_all
        unpatch_all()
        _client.flush()
        _client.close()


def status() -> dict:
    """Return SDK connection status."""
    if _client is None:
        return {"initialized": False}
    info = _client.status()
    from agentwatchx.integrations import get_instrumented
    info["instrumented"] = get_instrumented()
    return info


__all__ = [
    "init", "trace", "wrap", "log", "shutdown", "status",
    "get_client", "TraceData", "ToolCallData",
]
