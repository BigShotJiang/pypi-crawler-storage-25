"""
Auto-instrumentation registry.

Detects installed LLM libraries and patches them to capture traces
automatically after agentwatchx.init() is called.
"""

import importlib
import logging

logger = logging.getLogger("agentwatchx.integrations")

_PATCHES = {
    "openai": "agentwatchx.integrations.openai_patch",
    "anthropic": "agentwatchx.integrations.anthropic_patch",
    "google.generativeai": "agentwatchx.integrations.gemini_patch",
    "groq": "agentwatchx.integrations.groq_patch",
    "mistralai": "agentwatchx.integrations.mistral_patch",
    "langchain_core": "agentwatchx.integrations.langchain_cb",
    "llama_index": "agentwatchx.integrations.llamaindex_cb",
}

_applied: list[str] = []


def auto_instrument(client):
    """Detect installed libraries and apply patches. Called by init()."""
    for lib_name, patch_module in _PATCHES.items():
        if lib_name in _applied:
            continue  # already patched, skip

        try:
            importlib.import_module(lib_name)
        except ImportError:
            continue  # library not installed, skip

        try:
            mod = importlib.import_module(patch_module)
            mod.patch(client)
            _applied.append(lib_name)
            logger.info("Instrumented %s", lib_name)
        except Exception as exc:
            logger.warning("Failed to instrument %s: %s", lib_name, exc)


def get_instrumented() -> list[str]:
    """Return list of libraries that were successfully instrumented."""
    return list(_applied)


def unpatch_all():
    """Remove all patches (for testing / shutdown)."""
    for lib_name, patch_module in _PATCHES.items():
        if lib_name not in _applied:
            continue
        try:
            mod = importlib.import_module(patch_module)
            if hasattr(mod, "unpatch"):
                mod.unpatch()
        except Exception:
            pass
    _applied.clear()
