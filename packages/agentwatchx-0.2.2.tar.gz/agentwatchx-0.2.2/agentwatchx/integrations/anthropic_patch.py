"""
Auto-instrumentation for the Anthropic Python SDK.

Patches:
  - messages.create (sync + async)
  - Handles both regular and streaming responses

After agentwatchx.init(), every Anthropic call is traced automatically.
"""

import time
import functools
import logging

logger = logging.getLogger("agentwatchx.integrations.anthropic")

_original_create = None
_original_async_create = None
_client_ref = None
_patched = False


def patch(awx_client):
    """Monkey-patch anthropic messages.create."""
    global _original_create, _original_async_create, _client_ref, _patched
    if _patched:
        return
    _client_ref = awx_client

    try:
        from anthropic.resources.messages import Messages
    except ImportError:
        logger.debug("anthropic messages module not found, skipping")
        return

    _original_create = Messages.create

    @functools.wraps(_original_create)
    def patched_create(self, *args, **kwargs):
        stream = kwargs.get("stream", False)
        start = time.perf_counter()

        if stream:
            result = _original_create(self, *args, **kwargs)
            return _wrap_stream(result, kwargs, start)

        error = None
        result = None
        try:
            result = _original_create(self, *args, **kwargs)
            return result
        except Exception as exc:
            error = exc
            raise
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            _capture_trace(kwargs, result, error, duration_ms)

    Messages.create = patched_create

    # Patch async
    try:
        from anthropic.resources.messages import AsyncMessages
        _original_async_create = AsyncMessages.create

        @functools.wraps(_original_async_create)
        async def patched_async_create(self, *args, **kwargs):
            stream = kwargs.get("stream", False)
            start = time.perf_counter()

            if stream:
                result = await _original_async_create(self, *args, **kwargs)
                return _wrap_async_stream(result, kwargs, start)

            error = None
            result = None
            try:
                result = await _original_async_create(self, *args, **kwargs)
                return result
            except Exception as exc:
                error = exc
                raise
            finally:
                duration_ms = (time.perf_counter() - start) * 1000
                _capture_trace(kwargs, result, error, duration_ms)

        AsyncMessages.create = patched_async_create
    except ImportError:
        pass

    _patched = True
    logger.info("Anthropic auto-instrumentation applied")


def unpatch():
    """Restore original methods."""
    global _original_create, _original_async_create, _patched
    if _original_create:
        from anthropic.resources.messages import Messages
        Messages.create = _original_create
        _original_create = None
    if _original_async_create:
        from anthropic.resources.messages import AsyncMessages
        AsyncMessages.create = _original_async_create
        _original_async_create = None
    _patched = False


def _wrap_stream(stream, kwargs, start):
    """Wrap a sync Anthropic stream to capture events."""
    content_parts = []
    input_tokens = 0
    output_tokens = 0
    try:
        for event in stream:
            # Collect text deltas
            if hasattr(event, "type"):
                if event.type == "content_block_delta" and hasattr(event, "delta"):
                    if hasattr(event.delta, "text"):
                        content_parts.append(event.delta.text)
                elif event.type == "message_delta" and hasattr(event, "usage"):
                    output_tokens = getattr(event.usage, "output_tokens", 0)
                elif event.type == "message_start" and hasattr(event, "message"):
                    usage = getattr(event.message, "usage", None)
                    if usage:
                        input_tokens = getattr(usage, "input_tokens", 0)
            yield event
    finally:
        duration_ms = (time.perf_counter() - start) * 1000
        _capture_stream_trace(kwargs, content_parts, input_tokens, output_tokens, duration_ms)


async def _wrap_async_stream(stream, kwargs, start):
    """Wrap an async Anthropic stream."""
    content_parts = []
    input_tokens = 0
    output_tokens = 0
    try:
        async for event in stream:
            if hasattr(event, "type"):
                if event.type == "content_block_delta" and hasattr(event, "delta"):
                    if hasattr(event.delta, "text"):
                        content_parts.append(event.delta.text)
                elif event.type == "message_delta" and hasattr(event, "usage"):
                    output_tokens = getattr(event.usage, "output_tokens", 0)
                elif event.type == "message_start" and hasattr(event, "message"):
                    usage = getattr(event.message, "usage", None)
                    if usage:
                        input_tokens = getattr(usage, "input_tokens", 0)
            yield event
    finally:
        duration_ms = (time.perf_counter() - start) * 1000
        _capture_stream_trace(kwargs, content_parts, input_tokens, output_tokens, duration_ms)


def _capture_stream_trace(kwargs, content_parts, input_tokens, output_tokens, duration_ms):
    """Build trace from collected stream data."""
    if _client_ref is None:
        return

    from agentwatchx.schemas import TraceData

    model = kwargs.get("model", "unknown")
    messages = kwargs.get("messages", [])
    input_text = _extract_input(messages)
    output_text = "".join(content_parts)

    metadata = {"provider": "anthropic", "streamed": True}
    if input_tokens or output_tokens:
        metadata["input_tokens"] = input_tokens
        metadata["output_tokens"] = output_tokens

    try:
        _client_ref.capture(TraceData(
            service="anthropic",
            input_text=input_text,
            output_text=output_text or None,
            llm_model=model,
            duration_ms=round(duration_ms, 2),
            metadata=metadata,
        ))
    except Exception as exc:
        logger.debug("Failed to capture Anthropic stream trace: %s", exc)


def _extract_input(messages):
    """Pull input text from the last message."""
    if not messages:
        return ""
    last = messages[-1]
    if isinstance(last, dict):
        content = last.get("content", "")
        return content if isinstance(content, str) else str(content)
    return str(last)


def _capture_trace(kwargs, result, error, duration_ms):
    """Extract trace data from a non-streaming Anthropic call."""
    if _client_ref is None:
        return

    from agentwatchx.schemas import TraceData

    model = kwargs.get("model", "unknown")
    messages = kwargs.get("messages", [])
    input_text = _extract_input(messages)

    output_text = None
    tool_calls = []
    metadata = {"provider": "anthropic"}

    if error:
        metadata["error"] = str(error)
    elif result:
        try:
            blocks = result.content
            text_parts = []
            for b in blocks:
                if hasattr(b, "text"):
                    text_parts.append(b.text)
                elif hasattr(b, "type") and b.type == "tool_use":
                    from agentwatchx.schemas import ToolCallData
                    tool_calls.append(ToolCallData(
                        name=b.name,
                        input=b.input if hasattr(b, "input") else None,
                        status="success",
                    ))
            output_text = " ".join(text_parts)

            if hasattr(result, "usage") and result.usage:
                metadata["input_tokens"] = result.usage.input_tokens
                metadata["output_tokens"] = result.usage.output_tokens
        except (AttributeError, TypeError):
            output_text = str(result)

    try:
        _client_ref.capture(TraceData(
            service="anthropic",
            input_text=input_text,
            output_text=output_text,
            llm_model=model,
            duration_ms=round(duration_ms, 2),
            tool_calls=tool_calls,
            metadata=metadata,
        ))
    except Exception as exc:
        logger.debug("Failed to capture Anthropic trace: %s", exc)
