"""
Auto-instrumentation for the Google Generative AI Python SDK (google-generativeai).

Patches:
  - GenerativeModel.generate_content (sync)
  - GenerativeModel.generate_content_async (async)

After agentwatchx.init(), every Gemini call is traced automatically.
"""

import time
import functools
import logging

logger = logging.getLogger("agentwatchx.integrations.gemini")

_original_generate = None
_original_async_generate = None
_client_ref = None
_patched = False


def patch(awx_client):
    """Monkey-patch google.generativeai GenerativeModel."""
    global _original_generate, _original_async_generate, _client_ref, _patched
    if _patched:
        return
    _client_ref = awx_client

    try:
        from google.generativeai import GenerativeModel
    except ImportError:
        logger.debug("google.generativeai not found, skipping")
        return

    _original_generate = GenerativeModel.generate_content

    @functools.wraps(_original_generate)
    def patched_generate(self, *args, **kwargs):
        stream = kwargs.get("stream", False)
        start = time.perf_counter()

        if stream:
            result = _original_generate(self, *args, **kwargs)
            return _wrap_stream(result, self, args, kwargs, start)

        error = None
        result = None
        try:
            result = _original_generate(self, *args, **kwargs)
            return result
        except Exception as exc:
            error = exc
            raise
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            _capture_trace(self, args, kwargs, result, error, duration_ms)

    GenerativeModel.generate_content = patched_generate

    # Patch async
    try:
        _original_async_generate = GenerativeModel.generate_content_async

        @functools.wraps(_original_async_generate)
        async def patched_async_generate(self, *args, **kwargs):
            stream = kwargs.get("stream", False)
            start = time.perf_counter()

            if stream:
                result = await _original_async_generate(self, *args, **kwargs)
                return _wrap_async_stream(result, self, args, kwargs, start)

            error = None
            result = None
            try:
                result = await _original_async_generate(self, *args, **kwargs)
                return result
            except Exception as exc:
                error = exc
                raise
            finally:
                duration_ms = (time.perf_counter() - start) * 1000
                _capture_trace(self, args, kwargs, result, error, duration_ms)

        GenerativeModel.generate_content_async = patched_async_generate
    except AttributeError:
        pass

    _patched = True
    logger.info("Gemini auto-instrumentation applied")


def unpatch():
    """Restore original methods."""
    global _original_generate, _original_async_generate, _patched
    if _original_generate:
        from google.generativeai import GenerativeModel
        GenerativeModel.generate_content = _original_generate
        _original_generate = None
    if _original_async_generate:
        from google.generativeai import GenerativeModel
        GenerativeModel.generate_content_async = _original_async_generate
        _original_async_generate = None
    _patched = False


def _extract_input(args, kwargs):
    """Pull input text from generate_content arguments."""
    contents = args[0] if args else kwargs.get("contents", "")
    if isinstance(contents, str):
        return contents
    if isinstance(contents, list):
        parts = []
        for item in contents:
            if isinstance(item, str):
                parts.append(item)
            elif hasattr(item, "text"):
                parts.append(item.text)
            elif isinstance(item, dict) and "text" in item:
                parts.append(item["text"])
        return " ".join(parts) if parts else str(contents)
    return str(contents)


def _extract_model_name(model_instance):
    """Get model name from the GenerativeModel instance."""
    if hasattr(model_instance, "model_name"):
        return model_instance.model_name
    if hasattr(model_instance, "_model_name"):
        return model_instance._model_name
    return "gemini-unknown"


def _wrap_stream(stream, model_instance, args, kwargs, start):
    """Wrap a sync streaming response to capture the full output."""
    chunks = []
    try:
        for chunk in stream:
            chunks.append(chunk)
            yield chunk
    finally:
        duration_ms = (time.perf_counter() - start) * 1000
        _capture_stream_trace(model_instance, args, kwargs, chunks, duration_ms)


async def _wrap_async_stream(stream, model_instance, args, kwargs, start):
    """Wrap an async streaming response to capture the full output."""
    chunks = []
    try:
        async for chunk in stream:
            chunks.append(chunk)
            yield chunk
    finally:
        duration_ms = (time.perf_counter() - start) * 1000
        _capture_stream_trace(model_instance, args, kwargs, chunks, duration_ms)


def _capture_stream_trace(model_instance, args, kwargs, chunks, duration_ms):
    """Build a trace from collected stream chunks."""
    if _client_ref is None or not chunks:
        return

    from agentwatchx.schemas import TraceData

    model = _extract_model_name(model_instance)
    input_text = _extract_input(args, kwargs)

    content_parts = []
    for chunk in chunks:
        try:
            if hasattr(chunk, "text"):
                content_parts.append(chunk.text)
            elif hasattr(chunk, "candidates"):
                for candidate in chunk.candidates:
                    for part in candidate.content.parts:
                        if hasattr(part, "text"):
                            content_parts.append(part.text)
        except (AttributeError, IndexError):
            pass

    output_text = "".join(content_parts)
    metadata = {"provider": "gemini", "streamed": True}

    # Try to get usage from the last chunk
    try:
        last = chunks[-1]
        if hasattr(last, "usage_metadata"):
            um = last.usage_metadata
            metadata["prompt_tokens"] = getattr(um, "prompt_token_count", 0)
            metadata["completion_tokens"] = getattr(um, "candidates_token_count", 0)
            metadata["total_tokens"] = getattr(um, "total_token_count", 0)
    except (AttributeError, TypeError):
        pass

    try:
        _client_ref.capture(TraceData(
            service="gemini",
            input_text=input_text,
            output_text=output_text or None,
            llm_model=model,
            duration_ms=round(duration_ms, 2),
            metadata=metadata,
        ))
    except Exception as exc:
        logger.debug("Failed to capture Gemini stream trace: %s", exc)


def _capture_trace(model_instance, args, kwargs, result, error, duration_ms):
    """Extract trace data from a non-streaming Gemini call."""
    if _client_ref is None:
        return

    from agentwatchx.schemas import TraceData

    model = _extract_model_name(model_instance)
    input_text = _extract_input(args, kwargs)

    output_text = None
    tool_calls = []
    metadata = {"provider": "gemini"}

    if error:
        metadata["error"] = str(error)
    elif result:
        try:
            # Extract text from response
            if hasattr(result, "text"):
                output_text = result.text
            elif hasattr(result, "candidates"):
                text_parts = []
                for candidate in result.candidates:
                    for part in candidate.content.parts:
                        if hasattr(part, "text"):
                            text_parts.append(part.text)
                        elif hasattr(part, "function_call"):
                            from agentwatchx.schemas import ToolCallData
                            fc = part.function_call
                            tool_calls.append(ToolCallData(
                                name=fc.name,
                                input=dict(fc.args) if hasattr(fc, "args") else None,
                                status="success",
                            ))
                output_text = " ".join(text_parts)

            # Usage metadata
            if hasattr(result, "usage_metadata"):
                um = result.usage_metadata
                metadata["prompt_tokens"] = getattr(um, "prompt_token_count", 0)
                metadata["completion_tokens"] = getattr(um, "candidates_token_count", 0)
                metadata["total_tokens"] = getattr(um, "total_token_count", 0)
        except (AttributeError, TypeError):
            output_text = str(result)

    try:
        _client_ref.capture(TraceData(
            service="gemini",
            input_text=input_text,
            output_text=output_text,
            llm_model=model,
            duration_ms=round(duration_ms, 2),
            tool_calls=tool_calls,
            metadata=metadata,
        ))
    except Exception as exc:
        logger.debug("Failed to capture Gemini trace: %s", exc)
