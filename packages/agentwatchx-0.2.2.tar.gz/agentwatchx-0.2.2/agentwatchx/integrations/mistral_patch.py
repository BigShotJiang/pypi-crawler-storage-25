"""
Auto-instrumentation for the Mistral AI Python SDK (mistralai v2+).

Patches:
  - Mistral.chat.complete (sync)
  - Mistral.chat.complete_async (async)
  - Handles both regular and streaming responses

Mistral v2 SDK uses client.chat.complete() instead of the OpenAI-style
completions.create() pattern.

After agentwatchx.init(), every Mistral call is traced automatically.
"""

import time
import functools
import logging

logger = logging.getLogger("agentwatchx.integrations.mistral")

_original_complete = None
_original_async_complete = None
_client_ref = None
_patched = False


def patch(awx_client):
    """Monkey-patch mistralai chat.complete."""
    global _original_complete, _original_async_complete, _client_ref, _patched
    if _patched:
        return
    _client_ref = awx_client

    try:
        from mistralai.chat import Chat
    except ImportError:
        logger.debug("mistralai.chat module not found, skipping")
        return

    _original_complete = Chat.complete

    @functools.wraps(_original_complete)
    def patched_complete(self, *args, **kwargs):
        stream = kwargs.get("stream", False)
        start = time.perf_counter()

        if stream:
            result = _original_complete(self, *args, **kwargs)
            return _wrap_stream(result, kwargs, start)

        error = None
        result = None
        try:
            result = _original_complete(self, *args, **kwargs)
            return result
        except Exception as exc:
            error = exc
            raise
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            _capture_trace(kwargs, result, error, duration_ms)

    Chat.complete = patched_complete

    # Patch async
    try:
        _original_async_complete = Chat.complete_async

        @functools.wraps(_original_async_complete)
        async def patched_async_complete(self, *args, **kwargs):
            stream = kwargs.get("stream", False)
            start = time.perf_counter()

            if stream:
                result = await _original_async_complete(self, *args, **kwargs)
                return _wrap_async_stream(result, kwargs, start)

            error = None
            result = None
            try:
                result = await _original_async_complete(self, *args, **kwargs)
                return result
            except Exception as exc:
                error = exc
                raise
            finally:
                duration_ms = (time.perf_counter() - start) * 1000
                _capture_trace(kwargs, result, error, duration_ms)

        Chat.complete_async = patched_async_complete
    except AttributeError:
        pass

    _patched = True
    logger.info("Mistral auto-instrumentation applied")


def unpatch():
    """Restore original methods."""
    global _original_complete, _original_async_complete, _patched
    if _original_complete:
        from mistralai.chat import Chat
        Chat.complete = _original_complete
        _original_complete = None
    if _original_async_complete:
        from mistralai.chat import Chat
        Chat.complete_async = _original_async_complete
        _original_async_complete = None
    _patched = False


def _extract_input(kwargs):
    """Pull input text from the messages list."""
    messages = kwargs.get("messages", [])
    if not messages:
        return ""
    last = messages[-1]
    if isinstance(last, dict):
        content = last.get("content", "")
        return content if isinstance(content, str) else str(content)
    # Handle Mistral message objects
    if hasattr(last, "content"):
        return str(last.content)
    return str(last)


def _wrap_stream(stream, kwargs, start):
    """Wrap a sync streaming response to capture the full output."""
    chunks = []
    try:
        for chunk in stream:
            chunks.append(chunk)
            yield chunk
    finally:
        duration_ms = (time.perf_counter() - start) * 1000
        _capture_stream_trace(kwargs, chunks, duration_ms)


async def _wrap_async_stream(stream, kwargs, start):
    """Wrap an async streaming response to capture the full output."""
    chunks = []
    try:
        async for chunk in stream:
            chunks.append(chunk)
            yield chunk
    finally:
        duration_ms = (time.perf_counter() - start) * 1000
        _capture_stream_trace(kwargs, chunks, duration_ms)


def _capture_stream_trace(kwargs, chunks, duration_ms):
    """Build a trace from collected stream chunks."""
    if _client_ref is None or not chunks:
        return

    from agentwatchx.schemas import TraceData

    model = kwargs.get("model", "unknown")
    input_text = _extract_input(kwargs)

    content_parts = []
    for chunk in chunks:
        try:
            # Mistral stream chunks have data.choices[0].delta.content
            data = chunk.data if hasattr(chunk, "data") else chunk
            delta = data.choices[0].delta
            if delta and hasattr(delta, "content") and delta.content:
                content_parts.append(delta.content)
        except (IndexError, AttributeError):
            pass

    output_text = "".join(content_parts)
    metadata = {"provider": "mistral", "streamed": True}

    # Try to get usage from the last chunk
    try:
        last = chunks[-1]
        data = last.data if hasattr(last, "data") else last
        if hasattr(data, "usage") and data.usage:
            metadata["prompt_tokens"] = getattr(data.usage, "prompt_tokens", 0)
            metadata["completion_tokens"] = getattr(data.usage, "completion_tokens", 0)
            metadata["total_tokens"] = getattr(data.usage, "total_tokens", 0)
    except (AttributeError, TypeError):
        pass

    try:
        _client_ref.capture(TraceData(
            service="mistral",
            input_text=input_text,
            output_text=output_text or None,
            llm_model=model,
            duration_ms=round(duration_ms, 2),
            metadata=metadata,
        ))
    except Exception as exc:
        logger.debug("Failed to capture Mistral stream trace: %s", exc)


def _capture_trace(kwargs, result, error, duration_ms):
    """Extract trace data from a non-streaming Mistral call."""
    if _client_ref is None:
        return

    from agentwatchx.schemas import TraceData

    model = kwargs.get("model", "unknown")
    input_text = _extract_input(kwargs)

    output_text = None
    tool_calls = []
    metadata = {"provider": "mistral"}

    if error:
        metadata["error"] = str(error)
    elif result:
        try:
            choice = result.choices[0]
            output_text = choice.message.content or ""

            # Capture tool calls
            if hasattr(choice.message, "tool_calls") and choice.message.tool_calls:
                from agentwatchx.schemas import ToolCallData
                for tc in choice.message.tool_calls:
                    tool_calls.append(ToolCallData(
                        name=tc.function.name,
                        input=tc.function.arguments,
                        status="success",
                    ))

            if hasattr(result, "usage") and result.usage:
                metadata["prompt_tokens"] = getattr(result.usage, "prompt_tokens", 0)
                metadata["completion_tokens"] = getattr(result.usage, "completion_tokens", 0)
                metadata["total_tokens"] = getattr(result.usage, "total_tokens", 0)
        except (IndexError, AttributeError):
            output_text = str(result)

    try:
        _client_ref.capture(TraceData(
            service="mistral",
            input_text=input_text,
            output_text=output_text,
            llm_model=model,
            duration_ms=round(duration_ms, 2),
            tool_calls=tool_calls,
            metadata=metadata,
        ))
    except Exception as exc:
        logger.debug("Failed to capture Mistral trace: %s", exc)
