"""
Auto-instrumentation for the OpenAI Python SDK (v1+).

Patches:
  - chat.completions.create (sync + async)
  - Handles both regular and streaming responses

After agentwatchx.init(), every OpenAI call is traced automatically.
"""

import time
import functools
import logging

logger = logging.getLogger("agentwatchx.integrations.openai")

_original_create = None
_original_async_create = None
_client_ref = None
_patched = False


def patch(awx_client):
    """Monkey-patch openai chat completions."""
    global _original_create, _original_async_create, _client_ref, _patched
    if _patched:
        return
    _client_ref = awx_client

    try:
        from openai.resources.chat.completions import Completions
    except ImportError:
        logger.debug("openai chat completions module not found, skipping")
        return

    _original_create = Completions.create

    @functools.wraps(_original_create)
    def patched_create(self, *args, **kwargs):
        stream = kwargs.get("stream", False)
        start = time.perf_counter()

        if stream:
            # For streaming, wrap the iterator to capture chunks
            result = _original_create(self, *args, **kwargs)
            return _wrap_stream(result, kwargs, start)

        error = None
        result = None
        try:
            result = _original_create(self, *args, **kwargs)
            return result
        except Exception as exc:
            error = exc
            raise
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            _capture_trace(kwargs, result, error, duration_ms)

    Completions.create = patched_create

    # Patch async
    try:
        from openai.resources.chat.completions import AsyncCompletions
        _original_async_create = AsyncCompletions.create

        @functools.wraps(_original_async_create)
        async def patched_async_create(self, *args, **kwargs):
            stream = kwargs.get("stream", False)
            start = time.perf_counter()

            if stream:
                result = await _original_async_create(self, *args, **kwargs)
                return _wrap_async_stream(result, kwargs, start)

            error = None
            result = None
            try:
                result = await _original_async_create(self, *args, **kwargs)
                return result
            except Exception as exc:
                error = exc
                raise
            finally:
                duration_ms = (time.perf_counter() - start) * 1000
                _capture_trace(kwargs, result, error, duration_ms)

        AsyncCompletions.create = patched_async_create
    except ImportError:
        pass

    _patched = True
    logger.info("OpenAI auto-instrumentation applied")


def unpatch():
    """Restore original methods."""
    global _original_create, _original_async_create, _patched
    if _original_create:
        from openai.resources.chat.completions import Completions
        Completions.create = _original_create
        _original_create = None
    if _original_async_create:
        from openai.resources.chat.completions import AsyncCompletions
        AsyncCompletions.create = _original_async_create
        _original_async_create = None
    _patched = False


def _wrap_stream(stream, kwargs, start):
    """Wrap a sync streaming response to capture the full output."""
    chunks = []
    try:
        for chunk in stream:
            chunks.append(chunk)
            yield chunk
    finally:
        duration_ms = (time.perf_counter() - start) * 1000
        _capture_stream_trace(kwargs, chunks, duration_ms)


async def _wrap_async_stream(stream, kwargs, start):
    """Wrap an async streaming response to capture the full output."""
    chunks = []
    try:
        async for chunk in stream:
            chunks.append(chunk)
            yield chunk
    finally:
        duration_ms = (time.perf_counter() - start) * 1000
        _capture_stream_trace(kwargs, chunks, duration_ms)


def _capture_stream_trace(kwargs, chunks, duration_ms):
    """Build a trace from collected stream chunks."""
    if _client_ref is None or not chunks:
        return

    from agentwatchx.schemas import TraceData

    model = kwargs.get("model", "unknown")
    messages = kwargs.get("messages", [])
    input_text = messages[-1].get("content", "") if messages else ""

    # Reassemble streamed content
    content_parts = []
    for chunk in chunks:
        try:
            delta = chunk.choices[0].delta
            if delta and delta.content:
                content_parts.append(delta.content)
        except (IndexError, AttributeError):
            pass

    output_text = "".join(content_parts)
    metadata = {"provider": "openai", "streamed": True}

    # Try to get usage from the last chunk (OpenAI includes it there)
    try:
        last = chunks[-1]
        if hasattr(last, "usage") and last.usage:
            metadata["prompt_tokens"] = last.usage.prompt_tokens
            metadata["completion_tokens"] = last.usage.completion_tokens
            metadata["total_tokens"] = last.usage.total_tokens
    except (AttributeError, TypeError):
        pass

    try:
        _client_ref.capture(TraceData(
            service="openai",
            input_text=input_text,
            output_text=output_text or None,
            llm_model=model,
            duration_ms=round(duration_ms, 2),
            metadata=metadata,
        ))
    except Exception as exc:
        logger.debug("Failed to capture OpenAI stream trace: %s", exc)


def _capture_trace(kwargs, result, error, duration_ms):
    """Extract trace data from a non-streaming OpenAI chat completion call."""
    if _client_ref is None:
        return

    from agentwatchx.schemas import TraceData

    model = kwargs.get("model", "unknown")
    messages = kwargs.get("messages", [])
    input_text = messages[-1].get("content", "") if messages else ""

    output_text = None
    tool_calls = []
    metadata = {"provider": "openai"}

    if error:
        metadata["error"] = str(error)
    elif result:
        try:
            choice = result.choices[0]
            output_text = choice.message.content or ""

            # Capture tool calls if the model made any
            if hasattr(choice.message, "tool_calls") and choice.message.tool_calls:
                from agentwatchx.schemas import ToolCallData
                for tc in choice.message.tool_calls:
                    tool_calls.append(ToolCallData(
                        name=tc.function.name,
                        input=tc.function.arguments,
                        status="success",
                    ))

            if hasattr(result, "usage") and result.usage:
                metadata["prompt_tokens"] = result.usage.prompt_tokens
                metadata["completion_tokens"] = result.usage.completion_tokens
                metadata["total_tokens"] = result.usage.total_tokens
        except (IndexError, AttributeError):
            output_text = str(result)

    try:
        _client_ref.capture(TraceData(
            service="openai",
            input_text=input_text,
            output_text=output_text,
            llm_model=model,
            duration_ms=round(duration_ms, 2),
            tool_calls=tool_calls,
            metadata=metadata,
        ))
    except Exception as exc:
        logger.debug("Failed to capture OpenAI trace: %s", exc)
