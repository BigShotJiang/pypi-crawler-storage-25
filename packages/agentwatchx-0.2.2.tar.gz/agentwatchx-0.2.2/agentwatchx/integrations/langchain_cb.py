"""
Auto-instrumentation for LangChain via callback handler.

Registers an AgentWatchX callback handler globally so all LangChain
LLM/chain/chat model invocations are traced automatically.

Works with langchain-core >= 0.1.0 (the modern package structure).
"""

import time
import logging
from typing import Any
from uuid import UUID

logger = logging.getLogger("agentwatchx.integrations.langchain")

_client_ref = None
_handler_instance = None
_patched = False


def patch(awx_client):
    """Create and globally register a LangChain callback handler."""
    global _client_ref, _handler_instance, _patched
    if _patched:
        return
    _client_ref = awx_client

    try:
        from langchain_core.callbacks import BaseCallbackHandler
    except ImportError:
        logger.debug("langchain_core not available, skipping")
        return

    class AWXCallbackHandler(BaseCallbackHandler):
        """Captures LLM start/end events and sends them as traces."""

        def __init__(self):
            self._runs: dict[UUID, dict] = {}

        @property
        def always_verbose(self) -> bool:
            return True

        def on_llm_start(
            self,
            serialized: dict[str, Any],
            prompts: list[str],
            *,
            run_id: UUID,
            **kwargs: Any,
        ) -> None:
            model = (
                kwargs.get("invocation_params", {}).get("model_name")
                or kwargs.get("invocation_params", {}).get("model")
                or serialized.get("kwargs", {}).get("model_name")
                or serialized.get("kwargs", {}).get("model")
                or "unknown"
            )
            self._runs[run_id] = {
                "start": time.perf_counter(),
                "input_text": prompts[0] if prompts else "",
                "model": model,
                "metadata": {"provider": "langchain"},
            }

        def on_chat_model_start(
            self,
            serialized: dict[str, Any],
            messages: list[list],
            *,
            run_id: UUID,
            **kwargs: Any,
        ) -> None:
            input_text = ""
            if messages and messages[0]:
                last_msg = messages[0][-1]
                if hasattr(last_msg, "content"):
                    input_text = str(last_msg.content)
                else:
                    input_text = str(last_msg)

            model = (
                kwargs.get("invocation_params", {}).get("model_name")
                or kwargs.get("invocation_params", {}).get("model")
                or serialized.get("kwargs", {}).get("model_name")
                or serialized.get("kwargs", {}).get("model")
                or "unknown"
            )
            self._runs[run_id] = {
                "start": time.perf_counter(),
                "input_text": input_text,
                "model": model,
                "metadata": {"provider": "langchain"},
            }

        def on_llm_end(self, response, *, run_id: UUID, **kwargs: Any) -> None:
            run = self._runs.pop(run_id, None)
            if not run or _client_ref is None:
                return
            duration_ms = (time.perf_counter() - run["start"]) * 1000

            output_text = ""
            try:
                gen = response.generations[0][0]
                output_text = gen.text if hasattr(gen, "text") else str(gen)
                # Capture token usage if available
                if hasattr(response, "llm_output") and response.llm_output:
                    usage = response.llm_output.get("token_usage", {})
                    if usage:
                        run["metadata"]["tokens"] = usage
            except (IndexError, AttributeError):
                output_text = str(response)

            from agentwatchx.schemas import TraceData
            try:
                _client_ref.capture(TraceData(
                    service="langchain",
                    input_text=run["input_text"],
                    output_text=output_text,
                    llm_model=run["model"],
                    duration_ms=round(duration_ms, 2),
                    metadata=run["metadata"],
                ))
            except Exception as exc:
                logger.debug("Failed to capture LangChain trace: %s", exc)

        def on_llm_error(self, error, *, run_id: UUID, **kwargs: Any) -> None:
            run = self._runs.pop(run_id, None)
            if not run or _client_ref is None:
                return
            duration_ms = (time.perf_counter() - run["start"]) * 1000
            run["metadata"]["error"] = str(error)

            from agentwatchx.schemas import TraceData
            try:
                _client_ref.capture(TraceData(
                    service="langchain",
                    input_text=run["input_text"],
                    output_text=None,
                    llm_model=run["model"],
                    duration_ms=round(duration_ms, 2),
                    metadata=run["metadata"],
                ))
            except Exception as exc:
                logger.debug("Failed to capture LangChain error trace: %s", exc)

    _handler_instance = AWXCallbackHandler()

    # Register globally by patching the callback manager's configure function.
    # This ensures our handler is included in every LLM/chain invocation
    # without requiring users to pass callbacks= manually.
    try:
        from langchain_core.callbacks.manager import CallbackManager

        _original_configure = CallbackManager.configure

        @classmethod
        def patched_configure(cls, *args, **kwargs):
            manager = _original_configure.__func__(cls, *args, **kwargs)
            if manager is not None and _handler_instance is not None:
                # Avoid duplicates
                handler_types = {type(h) for h in manager.handlers}
                if type(_handler_instance) not in handler_types:
                    manager.add_handler(_handler_instance)
            return manager

        CallbackManager.configure = patched_configure
        logger.info("LangChain global callback handler registered via CallbackManager.configure")
    except Exception as exc:
        logger.warning("Could not register LangChain handler globally: %s. "
                       "Use get_callback_handler() manually.", exc)

    _patched = True


def get_callback_handler():
    """Return the AWX callback handler for manual use.

    Usage with LangChain:
        from agentwatchx.integrations.langchain_cb import get_callback_handler
        llm.invoke("prompt", config={"callbacks": [get_callback_handler()]})
    """
    return _handler_instance


def unpatch():
    """Remove the global callback handler."""
    global _handler_instance, _patched
    _handler_instance = None
    _patched = False
