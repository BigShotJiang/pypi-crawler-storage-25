"""
Auto-instrumentation for LlamaIndex via its callback system.

Registers an AgentWatchX handler that captures LLM call events automatically.
Supports both llama-index >= 0.10 (llama_index.core) and legacy paths.
"""

import time
import logging
from typing import Any

logger = logging.getLogger("agentwatchx.integrations.llamaindex")

_client_ref = None
_handler_instance = None
_patched = False

# Resolved at patch time
_CBEventType = None
_CallbackManager = None
_BaseCallbackHandler = None
_Settings = None


def patch(awx_client):
    """Register a LlamaIndex callback handler globally."""
    global _client_ref, _handler_instance, _patched
    global _CBEventType, _CallbackManager, _BaseCallbackHandler, _Settings

    if _patched:
        return
    _client_ref = awx_client

    # Try modern import path first (llama-index >= 0.10)
    try:
        from llama_index.core.callbacks import CallbackManager, CBEventType
        from llama_index.core.callbacks.base_handler import BaseCallbackHandler
        from llama_index.core import Settings
    except ImportError:
        # Legacy import path
        try:
            from llama_index.callbacks import CallbackManager, CBEventType
            from llama_index.callbacks.base_handler import BaseCallbackHandler
            from llama_index import Settings
        except ImportError:
            logger.debug("llama_index callback modules not found, skipping")
            return

    _CBEventType = CBEventType
    _CallbackManager = CallbackManager
    _BaseCallbackHandler = BaseCallbackHandler
    _Settings = Settings

    class AWXLlamaHandler(BaseCallbackHandler):
        """Captures LlamaIndex LLM events and sends them as traces."""

        def __init__(self):
            super().__init__(
                event_starts_to_trace=[CBEventType.LLM],
                event_ends_to_trace=[CBEventType.LLM],
            )
            self._events: dict[str, dict] = {}

        def on_event_start(
            self,
            event_type: CBEventType,
            payload: dict | None = None,
            event_id: str = "",
            **kwargs: Any,
        ) -> str:
            if event_type == CBEventType.LLM:
                input_text = ""
                model = "unknown"
                if payload:
                    # Try to extract from messages
                    messages = payload.get("messages", [])
                    if messages:
                        last = messages[-1]
                        input_text = str(last.content) if hasattr(last, "content") else str(last)
                    elif "prompt" in payload:
                        input_text = str(payload["prompt"])

                    model = (
                        payload.get("model_name")
                        or payload.get("model")
                        or "unknown"
                    )
                self._events[event_id] = {
                    "start": time.perf_counter(),
                    "input_text": input_text,
                    "model": model,
                    "metadata": {"provider": "llamaindex"},
                }
            return event_id

        def on_event_end(
            self,
            event_type: CBEventType,
            payload: dict | None = None,
            event_id: str = "",
            **kwargs: Any,
        ) -> None:
            if event_type != CBEventType.LLM:
                return
            ev = self._events.pop(event_id, None)
            if not ev or _client_ref is None:
                return

            duration_ms = (time.perf_counter() - ev["start"]) * 1000
            output_text = ""
            if payload:
                response = payload.get("response", payload.get("completion", ""))
                output_text = str(response)
                # Token usage
                tokens = payload.get("token_usage") or payload.get("usage")
                if tokens:
                    ev["metadata"]["tokens"] = (
                        tokens if isinstance(tokens, dict) else str(tokens)
                    )

            from agentwatchx.schemas import TraceData
            try:
                _client_ref.capture(TraceData(
                    service="llamaindex",
                    input_text=ev["input_text"],
                    output_text=output_text or None,
                    llm_model=ev["model"],
                    duration_ms=round(duration_ms, 2),
                    metadata=ev["metadata"],
                ))
            except Exception as exc:
                logger.debug("Failed to capture LlamaIndex trace: %s", exc)

        def start_trace(self, trace_id: str | None = None) -> None:
            pass

        def end_trace(
            self,
            trace_id: str | None = None,
            trace_map: dict[str, list[str]] | None = None,
        ) -> None:
            pass

    _handler_instance = AWXLlamaHandler()

    # Register globally via Settings.callback_manager
    try:
        if Settings.callback_manager is None:
            Settings.callback_manager = CallbackManager([_handler_instance])
        else:
            Settings.callback_manager.add_handler(_handler_instance)
        logger.info("LlamaIndex callback handler registered globally")
    except Exception as exc:
        logger.warning("Could not register LlamaIndex handler globally: %s. "
                       "Use get_callback_handler() manually.", exc)

    _patched = True


def get_callback_handler():
    """Return the AWX handler for manual use with LlamaIndex.

    Usage:
        from agentwatchx.integrations.llamaindex_cb import get_callback_handler
        from llama_index.core import Settings
        Settings.callback_manager.add_handler(get_callback_handler())
    """
    return _handler_instance


def unpatch():
    """Remove the handler."""
    global _handler_instance, _patched
    _handler_instance = None
    _patched = False
