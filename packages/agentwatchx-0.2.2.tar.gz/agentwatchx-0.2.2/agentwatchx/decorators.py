import functools
import time
from typing import Callable

from agentwatchx.schemas import TraceData


def trace(
    func: Callable | None = None,
    *,
    service: str = "default",
    llm_model: str | None = None,
):
    """
    Decorator to trace a function execution.

    Usage:
        @agentwatchx.trace
        def my_agent(input_text):
            ...

        @agentwatchx.trace(service="order-agent", llm_model="gpt-4")
        def my_agent(input_text):
            ...
    """
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            import agentwatchx

            input_text = str(args[0]) if args else str(kwargs) if kwargs else None
            start = time.perf_counter()
            error = None

            try:
                result = fn(*args, **kwargs)
                return result
            except Exception as e:
                error = e
                raise
            finally:
                duration_ms = (time.perf_counter() - start) * 1000
                output_text = None if error else str(result) if 'result' in dir() else None

                trace_data = TraceData(
                    service=service,
                    input_text=input_text,
                    output_text=output_text,
                    llm_model=llm_model,
                    duration_ms=round(duration_ms, 2),
                )

                try:
                    client = agentwatchx.get_client()
                    client.capture(trace_data)
                except RuntimeError:
                    pass  # SDK not initialized, silently skip

        return wrapper

    if func is not None:
        return decorator(func)
    return decorator
