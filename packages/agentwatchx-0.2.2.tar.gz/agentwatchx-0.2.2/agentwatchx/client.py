import threading
import time
import atexit

import httpx

from agentwatchx.schemas import TraceData


class AgentWatchXClient:
    """Core SDK client. Buffers traces and flushes in batches."""

    def __init__(
        self,
        api_key: str,
        endpoint: str = "https://agentwatchx-api-production.up.railway.app",
        flush_interval: float = 5.0,
        batch_size: int = 100,
        service: str = "default",
    ):
        self.api_key = api_key
        self.endpoint = endpoint.rstrip("/")
        self.flush_interval = flush_interval
        self.batch_size = batch_size
        self.default_service = service

        self._buffer: list[dict] = []
        self._lock = threading.Lock()
        self._http = httpx.Client(
            base_url=self.endpoint,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10.0,
        )

        # Background flush thread
        self._running = True
        self._flush_thread = threading.Thread(target=self._flush_loop, daemon=True)
        self._flush_thread.start()
        atexit.register(self.shutdown)

    def capture(self, trace: TraceData):
        """Add a trace to the buffer."""
        data = trace.model_dump()
        if data["service"] == "default":
            data["service"] = self.default_service
        with self._lock:
            self._buffer.append(data)
            if len(self._buffer) >= self.batch_size:
                self._send_batch()

    def flush(self):
        """Force flush all buffered traces."""
        with self._lock:
            self._send_batch()

    def close(self):
        """Stop the flush thread and close HTTP client."""
        self._running = False
        self.flush()
        self._http.close()

    def shutdown(self):
        """Alias for close — used by atexit."""
        self.close()

    def status(self) -> dict:
        with self._lock:
            buffered = len(self._buffer)
        return {
            "initialized": True,
            "endpoint": self.endpoint,
            "buffered_traces": buffered,
        }

    def _flush_loop(self):
        while self._running:
            time.sleep(self.flush_interval)
            self.flush()

    def _send_batch(self):
        """Send buffered traces. Must be called with self._lock held."""
        if not self._buffer:
            return
        batch = self._buffer[:self.batch_size]
        self._buffer = self._buffer[self.batch_size:]
        try:
            self._http.post("/v1/traces/batch", json={"traces": batch})
        except Exception:
            # Re-add to buffer on failure (best effort)
            self._buffer = batch + self._buffer
