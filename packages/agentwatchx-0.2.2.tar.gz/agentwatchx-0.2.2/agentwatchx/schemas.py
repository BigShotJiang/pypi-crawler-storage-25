from pydantic import BaseModel


class ToolCallData(BaseModel):
    name: str
    input: dict | str | None = None
    output: dict | str | None = None
    status: str = "success"
    duration_ms: float | None = None


class TraceData(BaseModel):
    service: str = "default"
    input_text: str | None = None
    output_text: str | None = None
    llm_model: str | None = None
    duration_ms: float | None = None
    tool_calls: list[ToolCallData] = []
    metadata: dict = {}
