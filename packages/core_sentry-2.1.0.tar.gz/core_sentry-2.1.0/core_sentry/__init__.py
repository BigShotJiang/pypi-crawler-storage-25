# -*- coding: utf-8 -*-

"""
A thin Python wrapper around the Sentry SDK providing a decorator
for automatic initialization and standalone functions for
the full event lifecycle.
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version


try:
    __version__ = version("core-sentry")

except PackageNotFoundError:
    __version__ = "unknown"


__all__ = [
    "__version__",
]
