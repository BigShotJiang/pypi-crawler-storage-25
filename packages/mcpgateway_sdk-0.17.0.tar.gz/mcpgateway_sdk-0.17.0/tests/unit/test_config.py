"""Tests for MCPGateway SDK configuration."""

from __future__ import annotations

import os
from unittest.mock import patch

from mcpgateway_sdk._config import SDKConfig


class TestSDKConfig:
    """Tests for SDKConfig initialization and environment variable handling."""

    def test_explicit_params(self) -> None:
        cfg = SDKConfig(api_key="my-key", url="https://gw.example.com", timeout=60.0)
        assert cfg.api_key == "my-key"
        assert cfg.url == "https://gw.example.com"
        assert cfg.timeout == 60.0

    def test_env_vars(self) -> None:
        env = {
            "MCPGATEWAY_API_KEY": "env-key",
            "MCPGATEWAY_URL": "https://env.example.com",
        }
        with patch.dict(os.environ, env, clear=False):
            cfg = SDKConfig()
        assert cfg.api_key == "env-key"
        assert cfg.url == "https://env.example.com"

    def test_explicit_overrides_env(self) -> None:
        env = {
            "MCPGATEWAY_API_KEY": "env-key",
            "MCPGATEWAY_URL": "https://env.example.com",
        }
        with patch.dict(os.environ, env, clear=False):
            cfg = SDKConfig(api_key="explicit-key", url="https://explicit.example.com")
        assert cfg.api_key == "explicit-key"
        assert cfg.url == "https://explicit.example.com"

    def test_default_url(self) -> None:
        env: dict[str, str] = {}
        with patch.dict(os.environ, env, clear=True):
            cfg = SDKConfig(api_key="k")
        assert cfg.url == "http://localhost:8000"

    def test_trailing_slash_stripped(self) -> None:
        cfg = SDKConfig(api_key="k", url="https://gw.example.com/")
        assert cfg.url == "https://gw.example.com"

    def test_multiple_trailing_slashes_stripped(self) -> None:
        cfg = SDKConfig(api_key="k", url="https://gw.example.com///")
        assert cfg.url == "https://gw.example.com"

    def test_default_timeout(self) -> None:
        cfg = SDKConfig(api_key="k")
        assert cfg.timeout == 30.0

    def test_custom_timeout(self) -> None:
        cfg = SDKConfig(api_key="k", timeout=120.0)
        assert cfg.timeout == 120.0

    def test_empty_api_key_when_no_env(self) -> None:
        env: dict[str, str] = {}
        with patch.dict(os.environ, env, clear=True):
            cfg = SDKConfig()
        assert cfg.api_key == ""
