#!/usr/bin/env python3
"""CI drift detection -- verify SDK covers all declared endpoints.

This script validates endpoint counts and format by inspecting each
resource class's ``_endpoints`` dict.  It does NOT compare against
the OpenAPI spec (``backend/docs/api/openapi.json``); OpenAPI-based
comparison is a future enhancement.
"""

from __future__ import annotations

import sys

from mcpgateway_sdk.resources.auth import AuthResource
from mcpgateway_sdk.resources.cache import CacheResource
from mcpgateway_sdk.resources.sandboxes import SandboxesResource
from mcpgateway_sdk.resources.servers import ServersResource
from mcpgateway_sdk.resources.skills import SkillsResource
from mcpgateway_sdk.resources.tools import ToolsResource

EXPECTED_TOTAL = 69  # 30 + 3 + 13 + 16 + 5 + 2


def main() -> int:
    """Check all resource _endpoints for completeness and validity.

    Returns:
        0 on success, 1 on drift or validation errors.
    """
    resources = {
        "servers": ServersResource,
        "tools": ToolsResource,
        "skills": SkillsResource,
        "sandboxes": SandboxesResource,
        "auth": AuthResource,
        "cache": CacheResource,
    }

    total = 0
    errors: list[str] = []

    for name, cls in resources.items():
        endpoints = getattr(cls, "_endpoints", {})
        count = len(endpoints)
        total += count
        print(f"  {name}: {count} endpoints")

        # Validate format
        for method_name, (http_method, path) in endpoints.items():
            if http_method not in ("GET", "POST", "PUT", "PATCH", "DELETE"):
                errors.append(f"{name}.{method_name}: invalid HTTP method '{http_method}'")
            if not path.startswith("/"):
                errors.append(f"{name}.{method_name}: path must start with / (got '{path}')")

    print(f"\nSDK covers {total}/{EXPECTED_TOTAL} endpoints")

    if errors:
        print("\nErrors:")
        for e in errors:
            print(f"  - {e}")
        return 1

    if total < EXPECTED_TOTAL:
        print(f"\nDRIFT: {EXPECTED_TOTAL - total} endpoints missing!")
        return 1

    print("All endpoints covered")
    return 0


if __name__ == "__main__":
    sys.exit(main())
