"""SDK configuration -- loads from explicit params or environment variables."""

from __future__ import annotations

import os


class SDKConfig:
    """Configuration for the MCPGateway SDK client.

    Parameters take precedence over environment variables. Falls back to
    ``MCPGATEWAY_API_KEY`` and ``MCPGATEWAY_URL`` env vars when explicit
    values are not provided.
    """

    def __init__(
        self,
        api_key: str | None = None,
        url: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.api_key: str = (
            api_key
            or os.environ.get("MCPGATEWAY_API_KEY")
            or os.environ.get("MCPGATEWAY_TOKEN", "")
        )
        raw_url = url or os.environ.get("MCPGATEWAY_URL", "http://localhost:8000")
        self.url: str = raw_url.rstrip("/")
        self.timeout: float = timeout
