# Changelog

All notable changes to atlassiancli are documented here.
The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Changed
- **PyPI distribution name renamed from `atlassiancli` to `inovagio-atlassian`.** The `atlassian-cli` name on PyPI is taken and PyPI's normalizer treats `atlassiancli` as the same canonical name, so the package publishes under the org-prefixed form. The installed binary command stays `atlassiancli` and the importable Python module stays `atlassiancli` — only the `pip install` line changes.
  - Old (never actually published): `pip install atlassiancli`
  - New: `pip install inovagio-atlassian`
- OSS governance + supply-chain hardening: SECURITY.md / CODE_OF_CONDUCT.md / CODEOWNERS / SUPPORT.md, issue + PR templates, SHA-pinned actions in CI/release, least-privilege workflow permissions, deployment environments (`pypi` with required reviewer, `test-pypi` tag-only), CodeQL default setup, secret scanning + push protection, Dependabot security updates.
- CI runner unified on pytest (drops broken `unittest discover` step that was hidden by Actions being disabled at the org).

### Added
- Stack-aware SOP autogeneration: `framework bootstrap --auto-sops` (default ON) detects Python / TypeScript / Go / Rust / C++ / Java / Kotlin / C# / Ruby / JavaScript and emits SOPs tuned to the toolchain. New `framework regenerate-sops` command.
- `atlassiancli review <KEY>` — unified story-time gate composing `analyze ready` + `analyze sop` + `analyze architecture` with worst-of verdict.
- Multi-tenant profiles via `~/.atlassiancli/<profile>.toml` and an interactive `configure` wizard.

## [0.1.0] - 2026-05-09

### Added
- Initial release: standalone, zero-pip-dep Python 3.12+ CLI
- 24+ Atlassian basics subcommands (create / analyze / transition / sprint / report / docs / etc.)
- Agent-callable layer: `--json` output, exit-code contract (0 / 1 / 75 / 77), idempotency guarantees
- Story analysis tier: `analyze lint`, `analyze atomicity`, `analyze ready`, `enhance`, `template`
- Doc framework bridge: `framework {create-stories,verify-stories,reverse-sync,sync-docs,bootstrap}`
- Pure-Python YAML codec, stdlib HTTP client, stdlib `.env` loader
- Markdown to Confluence storage XHTML formatter
- DDD-layered architecture (domain / application / infrastructure / cli)
- CI workflows (push + PR), release workflow (tag-triggered, manual approval to PyPI)
- Examples: minimal-project, doc-framework-product, agent-driven-workflow

[Unreleased]: https://github.com/inovagio/atlassiancli/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/inovagio/atlassiancli/releases/tag/v0.1.0
