# Contributing to atlassiancli

Thanks for your interest in improving atlassiancli. This project assumes only
`pip` as its package manager and Python 3.12+; no other tooling is required.

## Install dev dependencies

From a fresh checkout:

```bash
python3.12 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

The `dev` extra installs `ruff`, `build`, and `twine`. The runtime package
itself has zero third-party dependencies — that constraint is non-negotiable.

## Run the tests

The default test runner is the standard library's `unittest`:

```bash
python -m unittest discover tests/
```

All tests are written as `unittest.TestCase` subclasses, so contributors who
prefer `pytest` can use it without changes:

```bash
pip install pytest
pytest tests/
```

CI runs the `unittest` path. Either tool yields the same results.

## Lint

The default linter is `ruff` (installed via the `dev` extra):

```bash
ruff check .
```

The `[tool.ruff]` configuration in `pyproject.toml` selects rules that mirror
`flake8` + common plugins (E, W, F, I, N, UP, B, C4, SIM, RUF). Contributors
who prefer `flake8` can run it instead and will see substantially the same
violation set:

```bash
pip install flake8
flake8 src tests
```

CI runs `ruff`. Either tool is acceptable for local development.

## Build a wheel

```bash
python -m build
```

Produces `dist/atlassiancli-<version>.tar.gz` and a matching `.whl`.

## Coding standards

- Python 3.12+ syntax is fine (PEP 695 type aliases, `match` statements, etc.).
- No third-party imports inside `src/atlassiancli/`; standard library only.
- Tests live under `tests/` and use `unittest.TestCase` + `unittest.mock`.
- Keep the public CLI surface stable; subcommand additions land in numbered
  PRs per [PLAN.md](PLAN.md).

## CI gates

Every push and PR triggers `.github/workflows/ci.yml`:

- `ruff check src/ tests/` (lint)
- `ruff format --check src/ tests/` (formatting)
- `mypy src/atlassiancli/ --ignore-missing-imports` (informational; not a gate yet)
- `python -m unittest discover tests/` (stdlib test runner)
- `pytest tests/` (alternate runner — must also pass)
- `python -m build --wheel` (wheel artifact)
- `pip install <wheel> && atlassiancli --version` (smoke test in fresh venv)

Run all of these locally before pushing:

```bash
ruff check src/ tests/
ruff format --check src/ tests/
python -m unittest discover tests/
pytest tests/
python -m build --wheel
```

If `ruff format --check` reports drift, run `ruff format src/ tests/` and
commit the formatted result; CI will fail if the tree is not formatted.

## Releases

Tagged pushes (`v*`) trigger `.github/workflows/release.yml`:

1. Build sdist + wheel
2. Publish to **Test PyPI** automatically (OIDC trusted publishing)
3. Publish to **PyPI** — gated by manual approval via the `pypi` GitHub
   environment (configured in repo settings → Environments → required
   reviewers)

Before the first release, configure PyPI trusted publishing for this repo
at <https://pypi.org/manage/account/publishing/> and Test PyPI at
<https://test.pypi.org/manage/account/publishing/>. No API tokens required.
