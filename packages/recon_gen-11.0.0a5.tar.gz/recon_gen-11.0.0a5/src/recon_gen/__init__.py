"""Programmatic generator for AWS QuickSight + HTMX-rendered dashboards + audit PDFs."""

__version__ = "11.0.0a5"
