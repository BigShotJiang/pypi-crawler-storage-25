from setuptools import setup, find_packages

setup(
    name="Kingprint",
    version="1.0.1",
    author="Max",
    description="Essa biblioteca Adiciona um novo print que é bem melhor.",
    long_description="Motor de impressão estilizada com suporte a ANSI para terminais e integração com o Z-OS.",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)