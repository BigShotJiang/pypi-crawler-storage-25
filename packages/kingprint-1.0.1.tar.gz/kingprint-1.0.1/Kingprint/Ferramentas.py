import sys

CORES = {
    "red": "\033[91m", "green": "\033[92m", "yellow": "\033[93m",
    "blue": "\033[94m", "reset": "\033[0m", "bold": "\033[1m"
}

def kprint(*args, color=None, bold=False, **kwargs):
    estilo = ""
    if bold: estilo += CORES["bold"]
    if color: estilo += CORES.get(color.lower(), "")
    
    if estilo:
        sys.stdout.write(estilo)
        print(*args, **kwargs)
        sys.stdout.write(CORES["reset"])
        sys.stdout.flush()
    else:
        print(*args, **kwargs)