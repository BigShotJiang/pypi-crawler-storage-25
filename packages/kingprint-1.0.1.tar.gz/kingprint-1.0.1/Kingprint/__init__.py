from .Ferramentas import kprint, CORES

# Adicione esta linha abaixo para resolver o erro:
__version__ = "1.0.0"

__all__ = ['kprint', 'CORES', '__version__']