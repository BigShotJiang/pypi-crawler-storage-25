"""
Tests for openverb-fellowship.

All tests use the real openverb core — no mocking of the protocol.
"""

import json
import pytest

from openverb import validate_action, build_registry, load_library

from openverb_fellowship import (
    Fellowship,
    FellowshipExecutor,
    format_receipt,
    ai_safe_policy,
    read_only_policy,
    deny_list_policy,
    permissive_policy,
    create_policy,
    generate_system_prompt,
    to_tool_call_schemas,
    parse_ai_response,
)


# ──────────────────────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────────────────────

@pytest.fixture
def fellowship():
    """A Fellowship with a few test verbs."""
    f = Fellowship("test.app", description="Test fellowship")

    @f.verb(
        name="job.create",
        description="Create a new job",
        params={
            "title": {"type": "string", "description": "Job title", "required": True},
            "client_id": {"type": "string", "description": "Client ID", "required": True},
        },
        returns={"id": {"type": "string", "description": "New job ID"}},
        category="jobs",
    )
    def create_job(params):
        return {"verb": "job.create", "status": "success", "data": {"id": "job_123"}}

    @f.verb(
        name="job.delete",
        description="Delete a job permanently",
        params={"id": {"type": "string", "description": "Job ID", "required": True}},
        returns={"success": {"type": "boolean"}},
        destructive=True,
        requires_confirmation=True,
        category="jobs",
    )
    def delete_job(params):
        return {"verb": "job.delete", "status": "success", "data": {"success": True}}

    @f.verb(
        name="job.list",
        description="List all jobs",
        params={},
        returns={"jobs": {"type": "array", "description": "Job list"}},
        category="jobs",
    )
    def list_jobs(params):
        return {"verb": "job.list", "status": "success", "data": {"jobs": []}}

    @f.verb(
        name="invoice.generate",
        description="Generate a PDF invoice",
        params={"job_id": {"type": "string", "description": "Job ID", "required": True}},
        returns={"url": {"type": "string", "description": "PDF URL"}},
        category="invoices",
    )
    def generate_invoice(params):
        return {"verb": "invoice.generate", "status": "success", "data": {"url": "https://example.com/invoice.pdf"}}

    return f


@pytest.fixture
def executor(fellowship):
    return FellowshipExecutor(fellowship)


# ──────────────────────────────────────────────────────────────
# Fellowship Registry
# ──────────────────────────────────────────────────────────────

class TestFellowship:
    def test_namespace_and_description(self, fellowship):
        assert fellowship.namespace == "test.app"
        assert fellowship.description == "Test fellowship"

    def test_verb_count(self, fellowship):
        assert len(fellowship) == 4

    def test_list_verbs(self, fellowship):
        names = fellowship.list_verbs()
        assert "job.create" in names
        assert "job.delete" in names
        assert "job.list" in names
        assert "invoice.generate" in names

    def test_get_verb(self, fellowship):
        verb = fellowship.get_verb("job.create")
        assert verb is not None
        assert verb["name"] == "job.create"
        assert verb["params"]["title"]["required"] is True

    def test_contains(self, fellowship):
        assert "job.create" in fellowship
        assert "nonexistent.verb" not in fellowship

    def test_get_verbs_by_category(self, fellowship):
        job_verbs = fellowship.get_verbs_by_category("jobs")
        assert len(job_verbs) == 3
        assert all(v.get("category") == "jobs" for v in job_verbs)

    def test_get_destructive_verbs(self, fellowship):
        destructive = fellowship.get_destructive_verbs()
        assert len(destructive) == 1
        assert destructive[0]["name"] == "job.delete"

    def test_get_verbs_requiring_confirmation(self, fellowship):
        confirm = fellowship.get_verbs_requiring_confirmation()
        assert len(confirm) == 1
        assert confirm[0]["name"] == "job.delete"

    def test_library_is_valid_verbLibrary(self, fellowship):
        lib = fellowship.library
        assert lib["namespace"] == "test.app"
        assert isinstance(lib["verbs"], list)
        assert len(lib["verbs"]) == 4

    def test_library_works_with_core_build_registry(self, fellowship):
        """Core utility must accept the fellowship's VerbLibrary."""
        registry = build_registry(fellowship.library)
        assert "job.create" in registry
        assert registry["job.create"]["name"] == "job.create"

    def test_library_works_with_core_validate_action(self, fellowship):
        """Core validate_action must work with fellowship verb defs."""
        verb_def = fellowship.get_verb("job.create")
        result = validate_action(
            {"verb": "job.create", "params": {"title": "Fix roof", "client_id": "c1"}},
            verb_def
        )
        assert result["valid"] is True

    def test_core_validation_catches_missing_required(self, fellowship):
        verb_def = fellowship.get_verb("job.create")
        result = validate_action({"verb": "job.create", "params": {}}, verb_def)
        assert result["valid"] is False
        assert "title" in result["error"]

    def test_to_json_produces_valid_verbLibrary_json(self, fellowship):
        raw = fellowship.to_json()
        parsed = json.loads(raw)
        assert parsed["namespace"] == "test.app"
        assert len(parsed["verbs"]) == 4

    def test_register_programmatic(self):
        f = Fellowship("prog.test")
        f.register(
            "item.create",
            handler=lambda params: {"verb": "item.create", "status": "success"},
            description="Create an item",
            params={"name": {"type": "string", "required": True}},
        )
        assert "item.create" in f
        assert len(f) == 1

    def test_describe(self, fellowship):
        desc = fellowship.describe()
        assert "test.app" in desc
        assert "job.create" in desc
        assert "job.delete" in desc
        assert "destructive" in desc

    def test_load_library_from_dict(self):
        f = Fellowship("external.test")
        lib = {
            "namespace": "external.test",
            "version": "0.1.0",
            "verbs": [
                {
                    "name": "item.get",
                    "description": "Get an item",
                    "params": {"id": {"type": "string", "required": True}},
                    "returns": {},
                    "destructive": False,
                    "requires_confirmation": False,
                }
            ]
        }
        f.load_library(lib)
        assert "item.get" in f

    def test_repr(self, fellowship):
        assert "test.app" in repr(fellowship)
        assert "4" in repr(fellowship)


# ──────────────────────────────────────────────────────────────
# Executor
# ──────────────────────────────────────────────────────────────

class TestFellowshipExecutor:
    def test_execute_success(self, executor):
        result = executor.execute({"verb": "job.create", "params": {"title": "Fix roof", "client_id": "c1"}})
        assert result["status"] == "success"
        assert result["verb"] == "job.create"
        assert "timestamp" in result
        assert result["duration_ms"] >= 0

    def test_execute_unknown_verb(self, executor):
        result = executor.execute({"verb": "fly.to_moon", "params": {}})
        assert result["status"] == "error"
        assert "fly.to_moon" in result["error_message"]

    def test_execute_missing_required_param(self, executor):
        result = executor.execute({"verb": "job.create", "params": {"title": "No client"}})
        assert result["status"] == "error"
        assert "client_id" in result["error_message"]

    def test_execute_no_handler(self, fellowship):
        """Verb defined but no handler registered."""
        f = Fellowship("no.handler")
        f.load_library({
            "namespace": "no.handler",
            "version": "0.1.0",
            "verbs": [{
                "name": "item.create",
                "description": "Create item",
                "params": {},
                "returns": {},
                "destructive": False,
                "requires_confirmation": False,
            }]
        })
        ex = FellowshipExecutor(f)
        result = ex.execute({"verb": "item.create", "params": {}})
        assert result["status"] == "error"
        assert "No handler" in result["error_message"]

    def test_execute_batch(self, executor):
        receipt = executor.execute_batch([
            {"verb": "job.create", "params": {"title": "Job A", "client_id": "c1"}},
            {"verb": "job.list", "params": {}},
        ])
        assert receipt["success"] is True
        assert len(receipt["executed"]) == 2
        assert len(receipt["failed"]) == 0
        assert "total_duration_ms" in receipt
        assert "timestamp" in receipt

    def test_execute_batch_partial_failure(self, executor):
        receipt = executor.execute_batch([
            {"verb": "job.create", "params": {"title": "OK", "client_id": "c1"}},
            {"verb": "fly.to_moon", "params": {}},
        ])
        assert receipt["success"] is False
        assert len(receipt["executed"]) == 1
        assert len(receipt["failed"]) == 1

    def test_stop_on_failure(self, fellowship):
        ex = FellowshipExecutor(fellowship, stop_on_failure=True)
        receipt = ex.execute_batch([
            {"verb": "fly.to_moon", "params": {}},            # fails
            {"verb": "job.list", "params": {}},               # should not run
        ])
        assert len(receipt["failed"]) == 1
        assert len(receipt["executed"]) == 0

    def test_dry_run(self, fellowship):
        ex = FellowshipExecutor(fellowship, dry_run=True)
        result = ex.execute({"verb": "job.create", "params": {"title": "T", "client_id": "c1"}})
        assert result["status"] == "success"
        assert result.get("skipped") is True
        assert result.get("skip_reason") == "dry-run"
        assert result["data"]["dry_run"] is True

    def test_format_receipt(self, executor):
        receipt = executor.execute_batch([
            {"verb": "job.create", "params": {"title": "T", "client_id": "c1"}},
        ])
        formatted = format_receipt(receipt)
        assert "SUCCESS" in formatted
        assert "job.create" in formatted
        assert "ms" in formatted

    def test_before_after_hooks(self, fellowship):
        before_calls = []
        after_calls = []

        ex = FellowshipExecutor(
            fellowship,
            on_before=lambda action: before_calls.append(action["verb"]),
            on_after=lambda action, result: after_calls.append(result["status"]),
        )
        ex.execute({"verb": "job.list", "params": {}})
        assert before_calls == ["job.list"]
        assert after_calls == ["success"]


# ──────────────────────────────────────────────────────────────
# Policy
# ──────────────────────────────────────────────────────────────

class TestPolicy:
    def test_permissive_allows_destructive(self, fellowship):
        ex = FellowshipExecutor(fellowship, policy=permissive_policy())
        result = ex.execute({"verb": "job.delete", "params": {"id": "job_1"}})
        assert result["status"] == "success"

    def test_ai_safe_requires_confirmation_for_destructive(self, fellowship):
        ex = FellowshipExecutor(fellowship, policy=ai_safe_policy())
        result = ex.execute({"verb": "job.delete", "params": {"id": "job_1"}})
        assert result.get("skipped") is True
        assert "confirmation" in result.get("skip_reason", "").lower()

    def test_ai_safe_allows_normal_verbs(self, fellowship):
        ex = FellowshipExecutor(fellowship, policy=ai_safe_policy())
        result = ex.execute({"verb": "job.create", "params": {"title": "T", "client_id": "c1"}})
        assert result["status"] == "success"

    def test_read_only_denies_writes(self, fellowship):
        policy = read_only_policy(allowed_verbs={"job.list"})
        ex = FellowshipExecutor(fellowship, policy=policy)
        result = ex.execute({"verb": "job.create", "params": {"title": "T", "client_id": "c1"}})
        assert result["status"] == "error"
        assert "Denied" in result["error_message"]

    def test_read_only_allows_listed_verb(self, fellowship):
        policy = read_only_policy(allowed_verbs={"job.list"})
        ex = FellowshipExecutor(fellowship, policy=policy)
        result = ex.execute({"verb": "job.list", "params": {}})
        assert result["status"] == "success"

    def test_deny_list(self, fellowship):
        policy = deny_list_policy(["invoice.generate"], reason="Invoicing disabled")
        ex = FellowshipExecutor(fellowship, policy=policy)
        result = ex.execute({"verb": "invoice.generate", "params": {"job_id": "j1"}})
        assert result["status"] == "error"
        assert "Invoicing disabled" in result["error_message"]

    def test_fluent_policy_builder(self, fellowship):
        policy = (
            create_policy()
            .deny("job.delete", "Deletion disabled in this environment")
            .require_confirmation("invoice.generate", "Invoices need approval")
            .build()
        )
        ex = FellowshipExecutor(fellowship, policy=policy)

        delete_result = ex.execute({"verb": "job.delete", "params": {"id": "j1"}})
        assert "Deletion disabled" in delete_result["error_message"]

        invoice_result = ex.execute({"verb": "invoice.generate", "params": {"job_id": "j1"}})
        assert invoice_result.get("skipped") is True


# ──────────────────────────────────────────────────────────────
# Prompt Generator
# ──────────────────────────────────────────────────────────────

class TestPrompt:
    def test_generate_system_prompt_contains_verbs(self, fellowship):
        prompt = generate_system_prompt(fellowship)
        assert "job.create" in prompt
        assert "job.delete" in prompt
        assert "invoice.generate" in prompt

    def test_generate_system_prompt_category_filter(self, fellowship):
        prompt = generate_system_prompt(fellowship, categories=["jobs"])
        assert "job.create" in prompt
        assert "invoice.generate" not in prompt

    def test_generate_system_prompt_verb_filter(self, fellowship):
        prompt = generate_system_prompt(fellowship, verbs=["job.create", "job.list"])
        assert "job.create" in prompt
        assert "job.list" in prompt
        assert "job.delete" not in prompt

    def test_generate_system_prompt_xml_style(self, fellowship):
        prompt = generate_system_prompt(fellowship, style="xml")
        assert "<verb name=" in prompt
        assert "<param name=" in prompt

    def test_generate_system_prompt_plain_style(self, fellowship):
        prompt = generate_system_prompt(fellowship, style="plain")
        assert "job.create" in prompt
        assert "**" not in prompt  # no markdown

    def test_generate_system_prompt_no_schema(self, fellowship):
        prompt = generate_system_prompt(fellowship, include_schema=False, include_example=False)
        assert "job.create" in prompt
        assert "client_id" not in prompt

    def test_generate_system_prompt_custom_instructions(self, fellowship):
        prompt = generate_system_prompt(fellowship, custom_instructions="Always respond in English.")
        assert "Always respond in English." in prompt

    def test_to_tool_call_schemas_all(self, fellowship):
        schemas = to_tool_call_schemas(fellowship)
        assert len(schemas) == 4
        names = [s["name"] for s in schemas]
        assert "job.create" in names

    def test_to_tool_call_schemas_filtered(self, fellowship):
        schemas = to_tool_call_schemas(fellowship, verb_names=["job.create"])
        assert len(schemas) == 1
        assert schemas[0]["name"] == "job.create"
        assert schemas[0]["parameters"]["type"] == "object"
        assert "title" in schemas[0]["parameters"]["properties"]
        assert "title" in schemas[0]["parameters"]["required"]

    def test_flags_in_prompt(self, fellowship):
        prompt = generate_system_prompt(fellowship, include_flags=True)
        assert "destructive" in prompt

    def test_no_flags_in_prompt(self, fellowship):
        prompt = generate_system_prompt(fellowship, include_flags=False)
        assert "⚠" not in prompt


# ──────────────────────────────────────────────────────────────
# parse_ai_response
# ──────────────────────────────────────────────────────────────

class TestParseAIResponse:
    def test_parses_json_array(self):
        raw = json.dumps([{"verb": "job.create", "params": {"title": "T", "client_id": "c1"}}])
        result = parse_ai_response(raw)
        assert result["success"] is True
        assert len(result["actions"]) == 1
        assert result["actions"][0]["verb"] == "job.create"

    def test_parses_actions_wrapper(self):
        raw = json.dumps({"actions": [{"verb": "job.list", "params": {}}]})
        result = parse_ai_response(raw)
        assert result["success"] is True

    def test_parses_commands_wrapper(self):
        raw = json.dumps({"commands": [{"verb": "job.list", "params": {}}]})
        result = parse_ai_response(raw)
        assert result["success"] is True

    def test_strips_markdown_fences(self):
        raw = "```json\n" + json.dumps([{"verb": "job.list", "params": {}}]) + "\n```"
        result = parse_ai_response(raw)
        assert result["success"] is True

    def test_fails_on_invalid_json(self):
        result = parse_ai_response("not json at all")
        assert result["success"] is False
        assert result["error"] is not None

    def test_fails_on_missing_verb(self):
        raw = json.dumps([{"params": {"title": "T"}}])
        result = parse_ai_response(raw)
        assert result["success"] is False
        assert "verb" in result["error"]
