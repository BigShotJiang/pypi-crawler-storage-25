"""
Fellowship Executor — validated, auditable, deterministic execution.

Wraps the core openverb create_executor() with:
  - Policy enforcement (allow / deny / require_confirmation)
  - Batch execution
  - Audit receipts with timestamps and duration
  - Before/after hooks
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

from openverb import (
    validate_action,
    Action,
    ActionResult,
    VerbHandler,
)

from .policy import evaluate_policy
from .registry import Fellowship
from .types import FellowshipResult, FellowshipReceipt, PolicyConfig


class FellowshipExecutor:
    """
    The orchestrator of the Fellowship.

    Every action is validated, policy-checked, executed, and receipted.
    Nothing is hidden. Nothing is implicit.

    Usage:
        executor = FellowshipExecutor(fellowship, policy=ai_safe_policy())
        result = executor.execute({"verb": "job.create", "params": {...}})
        receipt = executor.execute_batch([...])
    """

    def __init__(
        self,
        fellowship: Fellowship,
        *,
        policy: Optional[PolicyConfig] = None,
        dry_run: bool = False,
        stop_on_failure: bool = False,
        on_before: Optional[Callable[[Action], None]] = None,
        on_after: Optional[Callable[[Action, FellowshipResult], None]] = None,
    ):
        self.fellowship = fellowship
        self.policy = policy
        self.dry_run = dry_run
        self.stop_on_failure = stop_on_failure
        self.on_before = on_before
        self.on_after = on_after

    def execute(self, action: Action) -> FellowshipResult:
        """
        Execute a single action through the full Fellowship pipeline:
        validate → policy → dry-run check → handler → receipt.

        Args:
            action: { "verb": str, "params": dict }

        Returns:
            FellowshipResult with status, data, duration_ms, timestamp
        """
        verb_name = action.get("verb")
        timestamp = datetime.now(timezone.utc).isoformat()
        start = time.monotonic()

        verb_def = self.fellowship.get_verb(verb_name)

        # 1. Core validation
        validation = validate_action(action, verb_def)
        if not validation["valid"]:
            return self._result(verb_name, "error", timestamp, start,
                                error_message=validation["error"])

        # 2. Policy check
        if self.policy:
            policy_result = evaluate_policy(action, verb_def, self.policy)
            decision = policy_result["decision"]

            if decision == "deny":
                return self._result(verb_name, "error", timestamp, start,
                                    error_message=f"Denied by policy: {policy_result.get('reason') or 'No reason given'}")

            if decision == "require_confirmation":
                return self._result(verb_name, "error", timestamp, start,
                                    error_message=f"Requires confirmation: {policy_result.get('reason') or 'User confirmation needed'}",
                                    skipped=True,
                                    skip_reason=policy_result.get("reason") or "Requires confirmation")

        # 3. Dry run
        if self.dry_run:
            return self._result(verb_name, "success", timestamp, start,
                                data={"dry_run": True, "params": action.get("params", {})},
                                skipped=True,
                                skip_reason="dry-run")

        # 4. Before hook
        if self.on_before:
            self.on_before(action)

        # 5. Execute via fellowship
        try:
            raw = self.fellowship.execute(action)
            result = self._result(
                verb_name,
                raw.get("status", "success"),
                timestamp,
                start,
                data=raw.get("data"),
                error_message=raw.get("error_message"),
            )
        except Exception as e:
            result = self._result(verb_name, "error", timestamp, start,
                                  error_message=str(e))

        # 6. After hook
        if self.on_after:
            self.on_after(action, result)

        return result

    def execute_batch(self, actions: List[Action]) -> FellowshipReceipt:
        """
        Execute a list of actions and return a structured receipt.

        Args:
            actions: List of { "verb": str, "params": dict }

        Returns:
            FellowshipReceipt with executed, failed, skipped, summary
        """
        batch_start = time.monotonic()
        executed: List[FellowshipResult] = []
        failed: List[FellowshipResult] = []
        skipped: List[FellowshipResult] = []

        for action in actions:
            result = self.execute(action)

            if result.get("skipped"):
                skipped.append(result)
            elif result["status"] == "success":
                executed.append(result)
            else:
                failed.append(result)
                if self.stop_on_failure:
                    break

        parts = []
        if executed:
            parts.append(f"{len(executed)} succeeded")
        if failed:
            parts.append(f"{len(failed)} failed")
        if skipped:
            parts.append(f"{len(skipped)} skipped")

        return {
            "success": len(failed) == 0,
            "executed": executed,
            "failed": failed,
            "skipped": skipped,
            "summary": ", ".join(parts) or "No actions executed",
            "total_duration_ms": round((time.monotonic() - batch_start) * 1000, 2),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    # ── Helpers ────────────────────────────────────────────────

    @staticmethod
    def _result(
        verb: str,
        status: str,
        timestamp: str,
        start: float,
        *,
        data: Any = None,
        error_message: Optional[str] = None,
        skipped: bool = False,
        skip_reason: Optional[str] = None,
    ) -> FellowshipResult:
        result: FellowshipResult = {
            "verb": verb,
            "status": status,
            "timestamp": timestamp,
            "duration_ms": round((time.monotonic() - start) * 1000, 2),
        }
        if data is not None:
            result["data"] = data
        if error_message:
            result["error_message"] = error_message
        if skipped:
            result["skipped"] = True
        if skip_reason:
            result["skip_reason"] = skip_reason
        return result


def format_receipt(receipt: FellowshipReceipt) -> str:
    """Format a FellowshipReceipt as a human-readable string."""
    lines = [
        f"Fellowship Receipt — {receipt['timestamp']}",
        f"Status: {'✓ SUCCESS' if receipt['success'] else '✗ FAILED'}",
        f"Summary: {receipt['summary']}",
        "",
    ]
    if receipt["executed"]:
        lines.append("Executed:")
        for r in receipt["executed"]:
            lines.append(f"  ✓ {r['verb']} ({r['duration_ms']}ms)")
    if receipt["failed"]:
        lines.append("Failed:")
        for r in receipt["failed"]:
            lines.append(f"  ✗ {r['verb']}: {r.get('error_message', 'unknown error')}")
    if receipt["skipped"]:
        lines.append("Skipped:")
        for r in receipt["skipped"]:
            lines.append(f"  ⊘ {r['verb']}: {r.get('skip_reason', r.get('error_message', 'skipped'))}")
    lines.append(f"\nTotal: {receipt['total_duration_ms']}ms")
    return "\n".join(lines)
