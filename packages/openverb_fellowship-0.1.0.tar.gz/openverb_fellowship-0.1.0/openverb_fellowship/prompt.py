"""
Prompt Generator — turn a Fellowship into a ready-to-use AI system prompt.

Generates system prompt fragments that tell an AI model exactly
which verbs it can call and what their params look like.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from openverb import VerbLibrary, Verb

from .registry import Fellowship


def generate_system_prompt(
    fellowship: Fellowship,
    *,
    categories: Optional[List[str]] = None,
    verbs: Optional[List[str]] = None,
    include_schema: bool = True,
    include_flags: bool = True,
    include_example: bool = True,
    custom_instructions: Optional[str] = None,
    style: str = "markdown",  # "markdown" | "xml" | "plain"
) -> str:
    """
    Generate a system prompt from a Fellowship.

    Args:
        fellowship: The Fellowship to generate a prompt for
        categories: Only include verbs from these categories
        verbs: Only include these specific verb names
        include_schema: Include param schemas. Default True
        include_flags: Include destructive/confirmation flags. Default True
        include_example: Include a JSON example. Default True
        custom_instructions: Appended at the end
        style: "markdown" | "xml" | "plain"

    Returns:
        A system prompt string ready to paste into your model call
    """
    # Select verbs
    all_verbs = fellowship._verbs
    if verbs:
        verb_list = [v for v in all_verbs if v["name"] in verbs]
    elif categories:
        verb_list = [v for v in all_verbs if v.get("category") in categories]
    else:
        verb_list = all_verbs

    # Group by category
    grouped: Dict[str, List[Verb]] = {}
    for v in verb_list:
        cat = v.get("category", "general")
        grouped.setdefault(cat, []).append(v)

    sections: List[str] = []

    # Header
    if style == "markdown":
        sections.append(f"""## {fellowship.namespace} — OpenVerb Fellowship

You are an AI assistant operating inside an OpenVerb Fellowship system.

When you need to take an action, respond with a JSON array of actions.
Each action has a `verb` and optional `params`. Actions execute in order.

```json
[
  {{ "verb": "<verb_name>", "params": {{ ... }} }}
]
```

Only return JSON when taking actions. For text responses, reply normally.""")

    elif style == "xml":
        sections.append(f"""<fellowship namespace="{fellowship.namespace}">
When taking actions, return a JSON array: [{{"verb": "name", "params": {{...}}}}]
Only return JSON when taking actions. Actions execute in order.
</fellowship>""")

    else:
        sections.append(f"""FELLOWSHIP: {fellowship.namespace}
Return JSON array [{{ "verb": "name", "params": {{...}} }}] when taking actions.""")

    # Verb definitions
    verb_blocks: List[str] = []
    for category, cat_verbs in grouped.items():
        lines: List[str] = []

        if style == "markdown":
            lines.append(f"### {_format_category(category)}")
        elif style == "xml":
            lines.append(f'<category name="{category}">')
        else:
            lines.append(f"[{category.upper()}]")

        for v in cat_verbs:
            lines.extend(_format_verb(v, include_schema=include_schema,
                                      include_flags=include_flags, style=style))

        if style == "xml":
            lines.append("</category>")
        verb_blocks.append("\n".join(lines))

    header = "### Available Verbs\n\n" if style == "markdown" else ""
    sections.append(header + "\n\n".join(verb_blocks))

    # Example
    if include_example:
        ex = _build_example(verb_list, style)
        if ex:
            sections.append(ex)

    # Custom instructions
    if custom_instructions:
        sections.append(
            f"### Additional Instructions\n\n{custom_instructions}"
            if style == "markdown" else custom_instructions
        )

    return "\n\n".join(sections)


def _format_verb(verb: Verb, *, include_schema: bool, include_flags: bool, style: str) -> List[str]:
    lines: List[str] = []
    flags = []
    if include_flags:
        if verb.get("destructive"):
            flags.append("⚠ destructive")
        if verb.get("requires_confirmation"):
            flags.append("⚠ requires-confirmation")
    flag_str = f" [{', '.join(flags)}]" if flags else ""

    if style == "markdown":
        lines.append(f"**`{verb['name']}`**{flag_str} — {verb['description']}")
        if include_schema:
            params = verb.get("params") or {}
            if not params:
                lines.append("  *(no params required)*")
            else:
                for name, defn in params.items():
                    req = "required" if defn.get("required") else "optional"
                    lines.append(f"  - `{name}` *({defn.get('type', 'any')}, {req})*: {defn.get('description', '')}")
    elif style == "xml":
        lines.append(f'  <verb name="{verb["name"]}"{(" flags=" + repr(",".join(flags))) if flags else ""}>')
        lines.append(f'    <description>{verb["description"]}</description>')
        if include_schema:
            for name, defn in (verb.get("params") or {}).items():
                lines.append(f'    <param name="{name}" type="{defn.get("type","any")}" required="{defn.get("required", False)}">{defn.get("description","")}</param>')
        lines.append("  </verb>")
    else:
        lines.append(f"{verb['name']}{flag_str}: {verb['description']}")
        if include_schema:
            for name, defn in (verb.get("params") or {}).items():
                lines.append(f"  {name} ({defn.get('type','any')}{'*' if defn.get('required') else ''}): {defn.get('description','')}")

    return lines


def _build_example(verb_list: List[Verb], style: str) -> Optional[str]:
    if not verb_list:
        return None
    # Use the first verb as example
    v = verb_list[0]
    example_params: Dict[str, Any] = {}
    for name, defn in (v.get("params") or {}).items():
        t = defn.get("type", "string")
        if t == "string":
            example_params[name] = f"<{name}>"
        elif t == "number":
            example_params[name] = 0
        elif t == "boolean":
            example_params[name] = False
        elif t == "object":
            example_params[name] = {}
        elif t.startswith("array"):
            example_params[name] = []

    actions = [{"verb": v["name"], "params": example_params}]
    json_str = json.dumps(actions, indent=2)

    if style == "markdown":
        return f"### Example\n\n```json\n{json_str}\n```"
    elif style == "xml":
        return f"<example>\n{json_str}\n</example>"
    return f"EXAMPLE:\n{json_str}"


def _format_category(cat: str) -> str:
    return " ".join(w.capitalize() for w in cat.split("_")) + " Verbs"


def to_tool_call_schemas(fellowship: Fellowship, verb_names: Optional[List[str]] = None) -> List[Dict]:
    """
    Convert Fellowship verbs to OpenAI/Anthropic tool-call schemas.

    Args:
        fellowship: The Fellowship
        verb_names: Specific verbs to export. Default: all

    Returns:
        List of tool-call schema dicts (pass as `tools` in your API call)
    """
    verbs = (
        [v for v in fellowship._verbs if v["name"] in verb_names]
        if verb_names
        else fellowship._verbs
    )

    schemas = []
    for v in verbs:
        properties: Dict[str, Any] = {}
        required: List[str] = []
        for name, defn in (v.get("params") or {}).items():
            properties[name] = {
                "type": defn.get("type", "string"),
                "description": defn.get("description", ""),
            }
            if defn.get("enum"):
                properties[name]["enum"] = defn["enum"]
            if defn.get("required"):
                required.append(name)
        schemas.append({
            "name": v["name"],
            "description": v["description"],
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        })
    return schemas


def parse_ai_response(raw: str) -> Dict[str, Any]:
    """
    Parse an AI model response into a list of actions.

    Handles:
    - JSON arrays: [{"verb": ..., "params": ...}]
    - {"actions": [...]} or {"commands": [...]} wrappers
    - Markdown code fences

    Returns:
        { "success": bool, "actions": list, "error": str }
    """
    import re
    cleaned = re.sub(r"^```(?:json)?\n?", "", raw.strip(), flags=re.MULTILINE)
    cleaned = re.sub(r"\n?```$", "", cleaned.strip(), flags=re.MULTILINE)
    cleaned = cleaned.strip()

    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError:
        return {"success": False, "actions": [], "error": "Response is not valid JSON"}

    if isinstance(parsed, list):
        arr = parsed
    elif isinstance(parsed, dict):
        arr = parsed.get("actions") or parsed.get("commands") or []
    else:
        return {"success": False, "actions": [], "error": "Expected a JSON array of actions"}

    for i, item in enumerate(arr):
        if not isinstance(item, dict) or not isinstance(item.get("verb"), str):
            return {"success": False, "actions": [], "error": f"Action at index {i} missing 'verb' string"}

    return {"success": True, "actions": arr, "error": None}
