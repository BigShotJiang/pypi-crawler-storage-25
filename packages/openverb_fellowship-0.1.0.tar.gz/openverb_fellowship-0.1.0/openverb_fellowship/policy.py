"""
Policy Layer — who can run what.

Governance, Risk, Compliance built into the Fellowship.
Verbs become control surfaces.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from openverb import Action, Verb

from .types import PolicyConfig, PolicyDecision, PolicyResult, PolicyRule


def evaluate_policy(
    action: Action,
    verb_def: Optional[Verb],
    config: PolicyConfig,
) -> PolicyResult:
    """
    Evaluate a policy config against an action.

    Returns:
        { "decision": "allow"|"deny"|"require_confirmation", "reason": str }
    """
    rules: List[PolicyRule] = config.get("rules", [])
    default: PolicyDecision = config.get("default_decision", "allow")

    for rule in rules:
        verb_match = rule.get("verb") in ("*", action.get("verb"))
        if not verb_match:
            continue

        condition = rule.get("condition")
        if condition and not condition(action, verb_def):
            continue

        return {
            "decision": rule["decision"],
            "reason": rule.get("reason"),
        }

    return {"decision": default, "reason": None}


# ──────────────────────────────────────────────────────────────
# Built-in policy presets
# ──────────────────────────────────────────────────────────────

def permissive_policy() -> PolicyConfig:
    """Allow everything. Use only in trusted environments."""
    return {"rules": [], "default_decision": "allow"}


def ai_safe_policy() -> PolicyConfig:
    """
    Safe defaults for AI-driven execution.
    Allows read/write operations, blocks dangerous system calls.
    """
    return {
        "default_decision": "allow",
        "rules": [
            {
                "verb": "*",
                "decision": "require_confirmation",
                "reason": "Destructive action requires confirmation",
                "condition": lambda action, verb_def: (
                    verb_def is not None and verb_def.get("destructive", False)
                ),
            },
            {
                "verb": "*",
                "decision": "require_confirmation",
                "reason": "Action requires confirmation",
                "condition": lambda action, verb_def: (
                    verb_def is not None and verb_def.get("requires_confirmation", False)
                ),
            },
        ],
    }


def read_only_policy(allowed_verbs: Optional[set] = None) -> PolicyConfig:
    """
    Deny all writes. Only allow the verbs in allowed_verbs.
    If allowed_verbs is None, denies everything.
    """
    _allowed = allowed_verbs or set()
    return {
        "default_decision": "deny",
        "rules": [
            {
                "verb": "*",
                "decision": "allow",
                "reason": None,
                "condition": lambda action, _: action.get("verb") in _allowed,
            }
        ],
    }


def deny_list_policy(denied_verbs: List[str], reason: str = "Verb is blocked by policy") -> PolicyConfig:
    """Block a specific list of verbs, allow everything else."""
    return {
        "default_decision": "allow",
        "rules": [
            {"verb": verb, "decision": "deny", "reason": reason}
            for verb in denied_verbs
        ],
    }


# ──────────────────────────────────────────────────────────────
# Fluent builder
# ──────────────────────────────────────────────────────────────

class PolicyBuilder:
    """
    Fluent interface for building a PolicyConfig.

    Example:
        policy = (
            PolicyBuilder()
            .deny("db.reset", "Database reset requires manual intervention")
            .require_confirmation("job.delete", "Deletion is irreversible")
            .allow("job.list")
            .build()
        )
    """

    def __init__(self):
        self._rules: List[PolicyRule] = []
        self._default: PolicyDecision = "allow"

    def allow(self, verb: str, reason: Optional[str] = None) -> "PolicyBuilder":
        self._rules.append({"verb": verb, "decision": "allow", "reason": reason})
        return self

    def deny(self, verb: str, reason: Optional[str] = None) -> "PolicyBuilder":
        self._rules.append({"verb": verb, "decision": "deny", "reason": reason})
        return self

    def require_confirmation(self, verb: str, reason: Optional[str] = None) -> "PolicyBuilder":
        self._rules.append({"verb": verb, "decision": "require_confirmation", "reason": reason})
        return self

    def deny_all(self) -> "PolicyBuilder":
        self._default = "deny"
        return self

    def allow_all(self) -> "PolicyBuilder":
        self._default = "allow"
        return self

    def build(self) -> PolicyConfig:
        return {"rules": self._rules, "default_decision": self._default}


def create_policy() -> PolicyBuilder:
    """Start building a PolicyConfig with the fluent builder."""
    return PolicyBuilder()
