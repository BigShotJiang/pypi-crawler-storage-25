"""
Fellowship Registry — the declared action layer.

Every verb brought into the light. No hidden capabilities.
"""

from __future__ import annotations

import json
import functools
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

from openverb import (
    load_library,
    build_registry,
    validate_action,
    VerbLibrary,
    VerbRegistry,
    Verb,
    Action,
    ActionResult,
    VerbHandler,
)

from .types import FellowshipResult, FellowshipReceipt


class Fellowship:
    """
    A named, declared collection of verbs working together as a system.

    The Fellowship brings every AI action into the light — named,
    structured, auditable, and controllable.

    Usage:
        fellowship = Fellowship("my_app")

        @fellowship.verb(
            name="job.create",
            description="Create a new job record",
            params={
                "title": {"type": "string", "description": "Job title", "required": True},
                "client_id": {"type": "string", "description": "Client ID", "required": True},
            },
            returns={
                "id": {"type": "string", "description": "New job ID"},
            }
        )
        def create_job(params):
            return {"verb": "job.create", "status": "success", "data": {"id": "job_123"}}

        result = fellowship.execute({"verb": "job.create", "params": {"title": "Fix roof", "client_id": "c1"}})
    """

    def __init__(self, namespace: str, description: str = ""):
        self.namespace = namespace
        self.description = description
        self._verbs: List[Verb] = []
        self._handlers: Dict[str, VerbHandler] = {}
        self._library: Optional[VerbLibrary] = None
        self._registry: Optional[VerbRegistry] = None

    # ── Library construction ───────────────────────────────────

    def _rebuild(self) -> None:
        """Rebuild the internal VerbLibrary and VerbRegistry."""
        self._library = {
            "namespace": self.namespace,
            "version": "0.1.0",
            "description": self.description,
            "verbs": self._verbs,
        }
        self._registry = build_registry(self._library)

    @property
    def library(self) -> VerbLibrary:
        """The VerbLibrary dict — pass to any core openverb utility."""
        if self._library is None:
            self._rebuild()
        return self._library

    @property
    def registry(self) -> VerbRegistry:
        """The VerbRegistry dict — verb name → verb definition."""
        if self._registry is None:
            self._rebuild()
        return self._registry

    # ── Verb registration ──────────────────────────────────────

    def verb(
        self,
        name: str,
        description: str,
        params: Optional[Dict[str, Any]] = None,
        returns: Optional[Dict[str, Any]] = None,
        destructive: bool = False,
        requires_confirmation: bool = False,
        category: Optional[str] = None,
    ) -> Callable:
        """
        Decorator that registers a function as a verb in this Fellowship.

        The decorated function receives `params` dict and must return
        an ActionResult: { "verb": str, "status": "success"|"error", ... }

        Example:
            @fellowship.verb(
                name="invoice.generate",
                description="Generate a PDF invoice for a job",
                params={"job_id": {"type": "string", "required": True}},
                returns={"url": {"type": "string", "description": "PDF URL"}},
            )
            def generate_invoice(params):
                url = pdf_service.generate(params["job_id"])
                return {"verb": "invoice.generate", "status": "success", "data": {"url": url}}
        """
        def decorator(fn: Callable) -> Callable:
            verb_def: Verb = {
                "name": name,
                "description": description,
                "params": params or {},
                "returns": returns or {},
                "destructive": destructive,
                "requires_confirmation": requires_confirmation,
            }
            if category:
                verb_def["category"] = category

            self._verbs.append(verb_def)
            self._handlers[name] = fn
            # Invalidate cached library/registry
            self._library = None
            self._registry = None

            @functools.wraps(fn)
            def wrapper(*args, **kwargs):
                return fn(*args, **kwargs)
            return wrapper
        return decorator

    def register(
        self,
        name: str,
        handler: VerbHandler,
        *,
        description: str,
        params: Optional[Dict[str, Any]] = None,
        returns: Optional[Dict[str, Any]] = None,
        destructive: bool = False,
        requires_confirmation: bool = False,
        category: Optional[str] = None,
    ) -> None:
        """
        Programmatically register a verb + handler (non-decorator style).

        Example:
            fellowship.register(
                "user.notify",
                handler=send_notification,
                description="Send a notification to a user",
                params={"user_id": {"type": "string", "required": True},
                        "message": {"type": "string", "required": True}},
            )
        """
        verb_def: Verb = {
            "name": name,
            "description": description,
            "params": params or {},
            "returns": returns or {},
            "destructive": destructive,
            "requires_confirmation": requires_confirmation,
        }
        if category:
            verb_def["category"] = category

        self._verbs.append(verb_def)
        self._handlers[name] = handler
        self._library = None
        self._registry = None

    def load_library(self, source: Union[str, Dict, Path]) -> None:
        """
        Load verb definitions from an existing VerbLibrary JSON file or dict.
        Handlers must still be registered separately via .add_handler().

        Useful for consuming an external openverb.*.json library.
        """
        lib = load_library(source)
        for verb_def in lib.get("verbs", []):
            if verb_def["name"] not in [v["name"] for v in self._verbs]:
                self._verbs.append(verb_def)
        self._library = None
        self._registry = None

    def add_handler(self, verb_name: str, handler: VerbHandler) -> None:
        """Add a handler for a verb that was loaded from a library file."""
        if verb_name not in self.registry:
            raise ValueError(f"Verb '{verb_name}' not found in fellowship. Register it first.")
        self._handlers[verb_name] = handler

    # ── Execution ──────────────────────────────────────────────

    def execute(self, action: Action) -> ActionResult:
        """
        Execute a single action.

        Uses core validate_action() for validation, then calls the
        registered handler.

        Args:
            action: { "verb": str, "params": dict }

        Returns:
            ActionResult: { "verb": str, "status": "success"|"error", ... }
        """
        verb_name = action.get("verb")
        verb_def = self.registry.get(verb_name)

        # Validate using core
        validation = validate_action(action, verb_def)
        if not validation["valid"]:
            return {
                "verb": verb_name,
                "status": "error",
                "error_message": validation["error"],
            }

        handler = self._handlers.get(verb_name)
        if not handler:
            return {
                "verb": verb_name,
                "status": "error",
                "error_message": f"No handler registered for verb: '{verb_name}'",
            }

        try:
            return handler(action.get("params", {}))
        except Exception as e:
            return {
                "verb": verb_name,
                "status": "error",
                "error_message": str(e),
            }

    # ── Inspection ─────────────────────────────────────────────

    def list_verbs(self) -> List[str]:
        """Return all verb names in this fellowship."""
        return list(self.registry.keys())

    def get_verb(self, name: str) -> Optional[Verb]:
        """Return a verb definition by name."""
        return self.registry.get(name)

    def get_verbs_by_category(self, category: str) -> List[Verb]:
        """Return all verbs in a given category."""
        return [v for v in self._verbs if v.get("category") == category]

    def get_destructive_verbs(self) -> List[Verb]:
        """Return all verbs marked destructive=True."""
        return [v for v in self._verbs if v.get("destructive")]

    def get_verbs_requiring_confirmation(self) -> List[Verb]:
        """Return all verbs marked requires_confirmation=True."""
        return [v for v in self._verbs if v.get("requires_confirmation")]

    def describe(self) -> str:
        """Human-readable summary of this fellowship."""
        lines = [
            f"Fellowship: {self.namespace}",
            f"Verbs: {len(self._verbs)}",
            "",
        ]
        for verb in self._verbs:
            flags = []
            if verb.get("destructive"):
                flags.append("destructive")
            if verb.get("requires_confirmation"):
                flags.append("requires-confirmation")
            flag_str = f"  [{', '.join(flags)}]" if flags else ""
            lines.append(f"  {verb['name']}{flag_str}")
            lines.append(f"    {verb['description']}")
        return "\n".join(lines)

    def to_json(self, indent: int = 2) -> str:
        """Export this fellowship's VerbLibrary as JSON."""
        return json.dumps(self.library, indent=indent)

    def __repr__(self) -> str:
        return f"Fellowship(namespace={self.namespace!r}, verbs={len(self._verbs)})"

    def __len__(self) -> int:
        return len(self._verbs)

    def __contains__(self, verb_name: str) -> bool:
        return verb_name in self.registry
