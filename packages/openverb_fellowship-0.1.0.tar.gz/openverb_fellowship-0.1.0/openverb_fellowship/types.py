"""
Type definitions for openverb-fellowship.

Extends the core openverb type aliases — no duplication.
"""

from typing import Any, Callable, Dict, List, Optional
from openverb import (
    VerbLibrary,
    Verb,
    VerbRegistry,
    Action,
    ActionResult,
    VerbHandler,
)

# Re-export core types so consumers only need one import
__all__ = [
    # Core types (re-exported)
    "VerbLibrary",
    "Verb",
    "VerbRegistry",
    "Action",
    "ActionResult",
    "VerbHandler",
    # Fellowship-specific types
    "PolicyDecision",
    "PolicyResult",
    "PolicyRule",
    "PolicyConfig",
    "FellowshipResult",
    "FellowshipReceipt",
]

# Policy types
PolicyDecision = str  # "allow" | "deny" | "require_confirmation"

PolicyResult = Dict[str, Any]
# { "decision": PolicyDecision, "reason": Optional[str] }

PolicyRule = Dict[str, Any]
# { "verb": str, "decision": PolicyDecision, "reason": str, "condition": Optional[Callable] }

PolicyConfig = Dict[str, Any]
# { "rules": List[PolicyRule], "default_decision": PolicyDecision }

# Fellowship execution result — extends ActionResult with audit fields
FellowshipResult = Dict[str, Any]
# {
#   "verb": str,
#   "status": "success" | "error",
#   "data": Any,
#   "error_message": str,
#   "duration_ms": float,
#   "timestamp": str,
#   "skipped": bool,
#   "skip_reason": str,
# }

# Batch receipt
FellowshipReceipt = Dict[str, Any]
# {
#   "success": bool,
#   "executed": List[FellowshipResult],
#   "failed": List[FellowshipResult],
#   "skipped": List[FellowshipResult],
#   "summary": str,
#   "total_duration_ms": float,
#   "timestamp": str,
# }
