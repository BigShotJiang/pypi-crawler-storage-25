"""
openverb-fellowship
===================
The Fellowship pattern for Python AI agents.

Register, execute, and audit verbs with zero friction.
Built on the openverb core protocol.

    pip install openverb-fellowship

Quick start:
    from openverb_fellowship import Fellowship, FellowshipExecutor, ai_safe_policy

    fellowship = Fellowship("my_app")

    @fellowship.verb(
        name="job.create",
        description="Create a new job record",
        params={
            "title": {"type": "string", "description": "Job title", "required": True},
        },
        returns={"id": {"type": "string", "description": "New job ID"}},
    )
    def create_job(params):
        return {"verb": "job.create", "status": "success", "data": {"id": "job_123"}}

    executor = FellowshipExecutor(fellowship, policy=ai_safe_policy())
    result = executor.execute({"verb": "job.create", "params": {"title": "Fix roof"}})
"""

__version__ = "0.1.0"

# Core openverb types — re-exported so consumers need one import
from openverb import (
    load_library,
    build_registry,
    validate_action,
    create_executor,
    load_core_library,
    VerbLibrary,
    Verb,
    VerbRegistry,
    Action,
    ActionResult,
    VerbHandler,
)

# Fellowship
from .registry import Fellowship

# Executor
from .executor import FellowshipExecutor, format_receipt

# Policy
from .policy import (
    evaluate_policy,
    permissive_policy,
    ai_safe_policy,
    read_only_policy,
    deny_list_policy,
    create_policy,
    PolicyBuilder,
)

# Prompt
from .prompt import (
    generate_system_prompt,
    to_tool_call_schemas,
    parse_ai_response,
)

# Types
from .types import (
    PolicyDecision,
    PolicyResult,
    PolicyRule,
    PolicyConfig,
    FellowshipResult,
    FellowshipReceipt,
)

__all__ = [
    # Core (re-exported)
    "load_library",
    "build_registry",
    "validate_action",
    "create_executor",
    "load_core_library",
    "VerbLibrary",
    "Verb",
    "VerbRegistry",
    "Action",
    "ActionResult",
    "VerbHandler",
    # Fellowship
    "Fellowship",
    # Executor
    "FellowshipExecutor",
    "format_receipt",
    # Policy
    "evaluate_policy",
    "permissive_policy",
    "ai_safe_policy",
    "read_only_policy",
    "deny_list_policy",
    "create_policy",
    "PolicyBuilder",
    # Prompt
    "generate_system_prompt",
    "to_tool_call_schemas",
    "parse_ai_response",
    # Types
    "PolicyDecision",
    "PolicyResult",
    "PolicyRule",
    "PolicyConfig",
    "FellowshipResult",
    "FellowshipReceipt",
]
