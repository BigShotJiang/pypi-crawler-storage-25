from diskcache import FanoutCache, Lock
from pandas import DataFrame
import re
import time
import random

cache = FanoutCache(shards=16, timeout=5, size_limit=3e11, eviction_policy='none')

def run_with_cache(func, *args, **kwargs):
    args_str = re.sub(r'\<.*?\>', '', str(args))
    cache_key = f"{func.__qualname__}_{args_str}_{kwargs}"
    # if cache_key in cache:
    #     return cache[cache_key]
    result = cache.get(cache_key, None)
    if result is not None:
        return result
    time.sleep(random.random() / 2)
    
    expired = kwargs.get('expired', None)
    if 'expired' in kwargs:
        del kwargs['expired']
    result = func(*args, **kwargs)
    if isinstance(result, DataFrame):
        if result.empty:
            return None
    else:
        if not result:
            return None
    t = time.time()
    if cache.set(cache_key, result, expired):
        print(f'{cache_key} cached -> {time.time() - t:.2f}s')
    else:
        print(f'{cache_key} cached failed')
    return result

async def async_run_with_cache(func, *args, **kwargs):
    args_str = re.sub(r'\<.*?\>', '', str(args))
    cache_key = f"{func.__qualname__}_{args_str}_{kwargs}"
    # if cache_key in cache:
    #     return cache[cache_key]
    result = cache.get(cache_key, None)
    if result is not None:
        return result
    time.sleep(random.random() / 2)
    
    expired = kwargs.get('expired', None)
    if 'expired' in kwargs:
        del kwargs['expired']
    result = await func(*args, **kwargs)
    if isinstance(result, DataFrame):
        if result.empty:
            return None
    else:
        if not result:
            return None
    t = time.time()
    if cache.set(cache_key, result, expired):
        print(f'{cache_key} cached -> {time.time() - t:.2f}s')
    else:
        print(f'{cache_key} cached failed')
    return result
    
def cache_decorate(func):
    def decorate(*args, **kwargs):
        return run_with_cache(func, *args, **kwargs)
    return decorate

def daily_cache_decorate(func):
    def decorate(*args, **kwargs):
        return run_with_cache(func, *args, **kwargs, expired=60*60*2)
    return decorate


def async_short_cache_decorate(async_func):
    async def decorate(*args, **kwargs):
        return await async_run_with_cache(async_func, *args, **kwargs, expired=60*5)
    return decorate

def async_medium_cache_decorate(async_func):
    async def decorate(*args, **kwargs):
        return await async_run_with_cache(async_func, *args, **kwargs, expired=60*30)
    return decorate

def async_long_cache_decorate(async_func):
    async def decorate(*args, **kwargs):
        return await async_run_with_cache(async_func, *args, **kwargs, expired=60*60*2)
    return decorate

def async_daily_cache_decorate(async_func):
    async def decorate(*args, **kwargs):
        return await async_run_with_cache(async_func, *args, **kwargs, expired=60*60*24)
    return decorate