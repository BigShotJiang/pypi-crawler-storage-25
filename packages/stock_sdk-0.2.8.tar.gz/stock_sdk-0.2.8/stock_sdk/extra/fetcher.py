from eltdx import TdxClient
from eltdx.services import WorkdayService
from stock_sdk.cache import daily_cache_decorate
from fake_useragent import UserAgent
import requests
import pandas as pd

from datetime import datetime

client = TdxClient()
for _ in range(3):
    import time
    try:
        client.connect()
    except:
        print("❌ 连接失败，尝试重试")
        time.sleep(2 * _)
workday = WorkdayService(client)

def get_925_auction(code, date):
    is_today = date == datetime.now().strftime('%Y-%m-%d')
    if is_today:
        auctions = [i for i in client.get_trade_all(code).items if i.time.hour == 9 and i.time.minute == 25]

        if len(auctions) == 0:
            return None
        else:
            auctions = auctions[0]

        return {
            'price': auctions.price,
            'volume': auctions.volume * 100,
            'amount': auctions.volume * auctions.price * 100,
            'date': datetime.now().strftime('%Y-%m-%d'),
            'code': code
        }
    else:
        auctions = client.get_auction_0925(code, date)
        if auctions.has_auction_0925:
            return {
                'price': auctions.price,
                'volume': auctions.volume * 100,
                'amount': auctions.amount,
                'date': auctions.trading_date,
                'code': code
            }
    return None

def get_recent_trade_day(date: datetime=None, forward=False, return_format: str='%Y-%m-%d'):
    if date is not None:
        if workday.is_workday(date.strftime('%Y-%m-%d')):
            return date.strftime(return_format)
        else:
            return workday.previous_workday(date).strftime(return_format) if not forward else workday.next_workday(date).strftime(return_format)
    else:
        if workday.is_workday(workday.today()):
            return workday.today().strftime(return_format)
        else:
            return workday.previous_workday().strftime(return_format) if not forward else workday.next_workday(date).strftime(return_format)
        
def get_next_trade_day(date: datetime=None, return_format: str='%Y-%m-%d'):
    next_day = workday.next_workday(date)
    if next_day:
        return next_day.strftime(return_format)
    else:
        return None

# @daily_cache_decorate
def get_last_day_limit(date) -> pd.DataFrame:
    """
    东方财富网-行情中心-涨停板行情-涨停股池
    https://quote.eastmoney.com/ztb/detail#type=ztgc
    :param date: 交易日
    :type date: str
    :return: 涨停股池
    :rtype: pandas.DataFrame
    """
    url = "https://push2ex.eastmoney.com/getTopicZTPool"
    params = {
        "ut": "7eea3edcaed734bea9cbfc24409ed989",
        "dpt": "wz.ztzt",
        "Pageindex": "0",
        "pagesize": "10000",
        "sort": "fbt:asc",
        "date": date.replace('-', ''),
    }
    r = requests.get(url, params=params)
    data_json = r.json()
    if data_json["data"] is None:
        return pd.DataFrame()
    if len(data_json["data"]["pool"]) == 0:
        return pd.DataFrame()
    temp_df = pd.DataFrame(data_json["data"]["pool"])
    temp_df.reset_index(inplace=True)
    temp_df["index"] = range(1, len(temp_df) + 1)
    temp_df.columns = [
        "序号",
        "代码",
        "_",
        "名称",
        "最新价",
        "涨跌幅",
        "成交额",
        "流通市值",
        "总市值",
        "换手率",
        "连板数",
        "首次封板时间",
        "最后封板时间",
        "封板资金",
        "炸板次数",
        "所属行业",
        "涨停统计",
    ]
    temp_df["涨停统计"] = (
        temp_df["涨停统计"].apply(lambda x: dict(x)["days"]).astype(str)
        + "/"
        + temp_df["涨停统计"].apply(lambda x: dict(x)["ct"]).astype(str)
    )
    temp_df = temp_df[
        [
            "序号",
            "代码",
            "名称",
            "涨跌幅",
            "最新价",
            "成交额",
            "流通市值",
            "总市值",
            "换手率",
            "封板资金",
            "首次封板时间",
            "最后封板时间",
            "炸板次数",
            "涨停统计",
            "连板数",
            "所属行业",
        ]
    ]
    temp_df["首次封板时间"] = temp_df["首次封板时间"].astype(str).str.zfill(6)
    temp_df["最后封板时间"] = temp_df["最后封板时间"].astype(str).str.zfill(6)
    temp_df["最新价"] = temp_df["最新价"] / 1000
    temp_df["涨跌幅"] = pd.to_numeric(temp_df["涨跌幅"], errors="coerce")
    temp_df["最新价"] = pd.to_numeric(temp_df["最新价"], errors="coerce")
    temp_df["成交额"] = pd.to_numeric(temp_df["成交额"], errors="coerce")
    temp_df["流通市值"] = pd.to_numeric(temp_df["流通市值"], errors="coerce")
    temp_df["总市值"] = pd.to_numeric(temp_df["总市值"], errors="coerce")
    temp_df["换手率"] = pd.to_numeric(temp_df["换手率"], errors="coerce")
    temp_df["封板资金"] = pd.to_numeric(temp_df["封板资金"], errors="coerce")
    temp_df["炸板次数"] = pd.to_numeric(temp_df["炸板次数"], errors="coerce")
    temp_df["连板数"] = pd.to_numeric(temp_df["连板数"], errors="coerce")
    return temp_df



if __name__ == '__main__':
    print(get_925_auction('001259', '2026-05-19'))
