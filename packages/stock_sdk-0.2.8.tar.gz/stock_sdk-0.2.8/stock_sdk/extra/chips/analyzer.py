import pandas as pd
from typing import Optional, Dict, List, Tuple
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np

class ChipDistributionAnalyzer:
    """筹码分布分析器"""
    
    def __init__(self, kdata: pd.DataFrame, accuracy_factor: int = 150, calc_range: Optional[int] = None):
        """
        初始化筹码分布分析器
        
        Args:
            kdata: K线数据，必须包含 [开盘, 收盘, 最高, 最低, 成交量, 换手率] 等字段
            accuracy_factor: 精度因子，决定价格分割的精度
            calc_range: 计算的K线范围，默认使用全部数据
        """
        self._validate_data(kdata)
        self.kdata = kdata
        self.factor = accuracy_factor
        self.range = calc_range
        
        # 设置matplotlib中文显示
        plt.rcParams['font.family'] = ['SimHei']
        plt.rcParams['axes.unicode_minus'] = False

    def _validate_data(self, kdata: pd.DataFrame) -> None:
        """
        验证输入数据的完整性
        
        Args:
            kdata: 待验证的K线数据
            
        Raises:
            ValueError: 当数据不完整或格式不正确时抛出
        """
        required_columns = ['open', 'close', 'high', 'low', 'vol', 'turnover']
        missing_columns = [col for col in required_columns if col not in kdata.columns]
        if missing_columns:
            raise ValueError(f"K线数据缺少必要字段: {missing_columns}")

    def calculate_chip_distribution(self, index: int) -> Dict:
        """
        计算指定位置的筹码分布
        
        Args:
            index: K线位置索引
            
        Returns:
            包含筹码分布结果的字典
        """
        # 确定计算范围
        start = max(0, index - self.range + 1) if self.range else 0
        kdata = self.kdata.iloc[start:index + 1]
        
        # 确定价格范围
        max_price = max(kdata['high'].values)
        min_price = min(kdata['low'].values)
        
        # 计算精度
        accuracy = max(0.01, (max_price - min_price) / (self.factor - 1))
        
        # 初始化分布数组
        price_range = [round(min_price + accuracy * i, 2) for i in range(self.factor)]
        distribution = [0] * self.factor
        
        # 计算每个K线的贡献
        for _, row in kdata.iterrows():
            distribution = self._calculate_k_line_contribution(
                row, distribution, min_price, accuracy, price_range
            )
        
        return self._calculate_distribution_metrics(
            distribution, price_range, self.kdata['close'].iloc[index]
        )

    def _calculate_k_line_contribution(
        self, 
        kline: pd.Series, 
        distribution: List[float],
        min_price: float,
        accuracy: float,
        price_range: List[float]
    ) -> List[float]:
        """
        计算单个K线对筹码分布的贡献
        
        Args:
            kline: 单个K线数据
            distribution: 现有筹码分布
            min_price: 最小价格
            accuracy: 价格精度
            price_range: 价格范围数组
            
        Returns:
            更新后的筹码分布
        """
        open_price = kline['open']
        close_price = kline['close']
        high_price = kline['high']
        low_price = kline['low']
        turnover_rate = min(1, kline['turnover'] / 100)
        
        # 计算平均价格
        avg_price = (open_price + close_price + high_price + low_price) / 4
        
        # 计算价格区间索引
        low_idx = max(0, int((low_price - min_price) / accuracy))
        high_idx = min(self.factor - 1, int((high_price - min_price) / accuracy))
        
        # 衰减现有筹码
        distribution = [d * (1 - turnover_rate) for d in distribution]
        
        # 一字板特殊处理
        if high_price == low_price:
            idx = int((high_price - min_price) / accuracy)
            distribution[idx] += turnover_rate / 2
        else:
            # 计算三角形分布
            for idx in range(low_idx, high_idx + 1):
                price = price_range[idx]
                if price <= avg_price:
                    weight = (price - low_price) / (avg_price - low_price)
                else:
                    weight = (high_price - price) / (high_price - avg_price)
                distribution[idx] += weight * turnover_rate
                
        return distribution

    def _calculate_distribution_metrics(
        self,
        distribution: List[float],
        price_range: List[float],
        current_price: float
    ) -> Dict:
        """
        计算筹码分布的各项指标
        
        Args:
            distribution: 筹码分布数组
            price_range: 价格范围数组
            current_price: 当前价格
            
        Returns:
            包含各项指标的字典
        """
        total_weight = sum(distribution)
        if total_weight == 0:
            return {
                'profit_ratio': 0,
                'avg_cost': 0,
                'cost_90_range': (0, 0),
                'concentration_90': 0,
                'cost_70_range': (0, 0),
                'concentration_70': 0,
                'prices': price_range,
                'distribution': distribution,
                'current_price': current_price
            }

        # 计算平均成本
        avg_cost = sum(p * d for p, d in zip(price_range, distribution)) / total_weight
        
        # 计算获利比例
        profit_ratio = sum(d for p, d in zip(price_range, distribution) if p <= current_price) / total_weight
        
        # 计算成本区间
        cost_90_range, concentration_90 = self._calculate_cost_range(
            price_range, distribution, total_weight, 0.9
        )
        cost_70_range, concentration_70 = self._calculate_cost_range(
            price_range, distribution, total_weight, 0.7
        )
        
        return {
            'prices': price_range,
            'distribution': distribution,
            'current_price': current_price,
            'profit_ratio': profit_ratio,
            'avg_cost': avg_cost,
            'cost_90_range': cost_90_range,
            'concentration_90': concentration_90,
            'cost_70_range': cost_70_range,
            'concentration_70': concentration_70
        }

    def _calculate_cost_range(
        self,
        price_range: List[float],
        distribution: List[float],
        total_weight: float,
        threshold: float
    ) -> Tuple[Tuple[float, float], float]:
        """
        计算指定比例的成本区间
        
        Args:
            price_range: 价格范围数组
            distribution: 筹码分布数组
            total_weight: 总权重
            threshold: 阈值(如0.9表示90%)
            
        Returns:
            (成本区间元组, 集中度)
        """
        sorted_prices = sorted(
            [(p, d) for p, d in zip(price_range, distribution)],
            key=lambda x: x[1],
            reverse=True
        )
        
        cumsum = 0
        cost_low = float('inf')
        cost_high = float('-inf')
        
        for price, dist in sorted_prices:
            cumsum += dist
            cost_low = min(cost_low, price)
            cost_high = max(cost_high, price)
            if cumsum >= threshold * total_weight:
                break
                
        concentration = (
            (cost_high - cost_low) / (cost_high + cost_low) * 100 
            if cost_high + cost_low > 0 else 0
        )
        
        return (cost_low, cost_high), concentration

    def visualize_distribution(self, chip_distribution: Dict, title_prefix: str = "") -> None:
        """
        可视化筹码分布
        
        Args:
            chip_distribution: 筹码分布数据
            title_prefix: 标题前缀
        """
        fig, ax = plt.subplots(figsize=(12, 6))
        
        # 绘制筹码分布
        for i in range(len(chip_distribution['prices'])):
            color = 'red' if chip_distribution['prices'][i] < chip_distribution['current_price'] else 'green'
            ax.barh(
                chip_distribution['prices'][i],
                chip_distribution['distribution'][i],
                color=color,
                alpha=0.6,
                edgecolor='none'
            )

        # 设置标题和标签
        title = f"筹码分布图: {title_prefix}\n"
        title += f"当前股价: {chip_distribution['current_price']:.2f}  "
        title += f"获利比例: {chip_distribution['profit_ratio']*100:.2f}%"
        
        ax.set_title(title, fontsize=12)
        ax.set_xlabel('筹码占比', fontsize=10)
        ax.set_ylabel('价格', fontsize=10)
        
        # 添加指标说明
        text_content = (
            f"获利比例: {chip_distribution['profit_ratio']*100:.2f}%\n"
            f"平均成本: {chip_distribution['avg_cost']:.2f}\n"
            f"90%成本: {chip_distribution['cost_90_range'][0]:.2f}-{chip_distribution['cost_90_range'][1]:.2f}\n"
            f"集中度: {chip_distribution['concentration_90']:.2f}%\n"
            f"70%成本: {chip_distribution['cost_70_range'][0]:.2f}-{chip_distribution['cost_70_range'][1]:.2f}\n"
            f"集中度: {chip_distribution['concentration_70']:.2f}%"
        )
        
        plt.text(
            1.02, 0.5,
            text_content,
            transform=ax.transAxes,
            verticalalignment='center',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.8)
        )

        ax.grid(True, linestyle='--', alpha=0.3)
        plt.show(block=True)

    def calculate_all_distributions(self) -> List[Dict]:
        """
        计算所有K线的筹码分布指标
        
        Returns:
            所有K线的筹码分布指标列表，每个元素包含:
            - profit_ratio: 获利比例
            - avg_cost: 平均成本
            - concentration_70: 70%筹码集中度
            - concentration_90: 90%筹码集中度
        """
        results = []
        min_price = min(self.kdata['low'])
        max_price = max(self.kdata['high'])
        price_step = (max_price - min_price) / (self.factor - 1)
        
        # 预先计算价格区间
        price_ranges = [round(min_price + price_step * i, 2) for i in range(self.factor)]
        
        # 初始化筹码分布
        distribution = [0] * self.factor
        
        for i in range(len(self.kdata)):
            k_line = self.kdata.iloc[i]
            current_price = k_line['close']
            
            # 更新当前K线的筹码分布
            distribution = self._calculate_k_line_contribution(
                k_line,
                distribution,
                min_price,
                price_step,
                price_ranges
            )
            
            # 计算关键指标
            metrics = self._calculate_key_metrics(distribution, price_ranges, current_price)
            results.append(metrics)
        
        return results

    def _calculate_key_metrics(self, distribution: List[float], price_ranges: List[float], 
                             current_price: float) -> Dict:
        """
        计算关键筹码分布指标
        
        Args:
            distribution: 筹码分布列表
            price_ranges: 价格区间列表
            current_price: 当前价格
            
        Returns:
            包含关键指标的字典
        """
        total_chips = sum(distribution)
        if total_chips == 0:
            return {
                'profit_ratio': 0,
                'avg_cost': current_price,
                'concentration_70': 0
            }
        
        # 1. 计算获利比例
        profit_chips = sum(d for i, d in enumerate(distribution) 
                          if price_ranges[i] <= current_price)
        profit_ratio = profit_chips / total_chips
        
        # 2. 计算平均成本
        avg_cost = sum(price * dist for price, dist in zip(price_ranges, distribution)) / total_chips
        
        # 3. 计算70%筹码集中度
        target_chips = total_chips * 0.7
        accumulated_chips = 0
        price_range_count = 0
        
        #
        sorted_dist = sorted(zip(price_ranges, distribution), 
                            key=lambda x: x[1], reverse=True)
        
        for _, chips in sorted_dist:
            accumulated_chips += chips
            price_range_count += 1
            if accumulated_chips >= target_chips:
                break
        
        concentration_70 = price_range_count / self.factor
        
        # 4. 计算90%筹码集中度
        target_chips = total_chips * 0.9
        accumulated_chips = 0
        price_range_count = 0
        
        for _, chips in sorted_dist:
            accumulated_chips += chips
            price_range_count += 1
            if accumulated_chips >= target_chips:
                break
        
        concentration_90 = price_range_count / self.factor
        

        return {
            'profit_ratio': profit_ratio,
            'avg_cost': avg_cost,
            'concentration_70': concentration_70,
            'concentration_90': concentration_90
        }
    
def judge_chip_main_behavior(chip_data):
    # 提取核心参数
    prices = chip_data["prices"]
    dist = chip_data["distribution"]
    cur_price = float(chip_data["current_price"])
    profit_ratio = float(chip_data["profit_ratio"])
    avg_cost = float(chip_data["avg_cost"])
    c90_low, c90_high = chip_data["cost_90_range"]
    conc90 = float(chip_data["concentration_90"])
    c70_low, c70_high = chip_data["cost_70_range"]
    conc70 = float(chip_data["concentration_70"])

    # 归一获利比例 0~100
    profit_pct = profit_ratio * 100

    # 状态标记
    is_shipping = False      # 主力出货
    is_rise_lock = False     # 锁仓拉升
    is_wash = False          # 洗盘
    is_bottom = False        # 低位磨底
    is_full_trapped = False  # 全员套牢

    # ========== 核心判定规则 ==========
    # 1. 全员深度套牢：现价低于90%筹码下沿，获利极低
    if cur_price < c90_low and profit_pct < 5:
        is_full_trapped = True
        is_bottom = True

    # 2. 主力出货 硬性条件（必须同时满足）
    # 条件1：获利比例 > 80% 主力大幅盈利
    # 条件2：现价站在90%成本上沿附近/上方
    # 条件3：筹码高度集中在高位
    if profit_pct > 80 and cur_price >= c90_high * 0.95 and conc90 < 10:
        is_shipping = True

    # 3. 锁仓拉升：获利适中、现价在成本区间中上部、集中度高
    if 30 < profit_pct < 80 and c70_low < cur_price < c70_high and conc70 < 8:
        is_rise_lock = True

    # 4. 洗盘：现价靠近平均成本，获利比例中等，筹码集中
    if abs(cur_price - avg_cost) / avg_cost < 0.03 and 20 < profit_pct < 60:
        is_wash = True

    # ========== 结果输出 ==========
    res = {
        "当前股价": round(cur_price, 2),
        "平均成本": round(avg_cost, 2),
        "获利比例(%)": round(profit_pct, 2),
        "90%成本区间": (round(c90_low, 2), round(c90_high, 2)),
        "90%筹码集中度(%)": round(conc90, 2),
        "状态判定": ""
    }

    if is_shipping:
        res["状态判定"] = "⚠️ 主力高位出货，坚决规避"
    elif is_full_trapped and is_bottom:
        res["状态判定"] = "📉 全员深度套牢，低位阴跌磨底，无出货条件"
    elif is_rise_lock:
        res["状态判定"] = "📈 主力锁仓拉升，持有为主"
    elif is_wash:
        res["状态判定"] = "🔄 中途洗盘，未出货"
    else:
        res["状态判定"] = "🤷 筹码散乱，无明显主力动作"

    return res

class ChipAnalyzer:
    def __init__(self):
        self.daily_data = []
        
    def add_daily_data(self, data: Dict):
        """添加单日筹码数据"""
        self.daily_data.append(data)
        
    def calculate_changes(self) -> pd.DataFrame:
        """计算每日指标变化"""
        if len(self.daily_data) < 2:
            return pd.DataFrame()
            
        df = pd.DataFrame(self.daily_data)
        df['date'] = pd.to_datetime(df['date'])
        df = df.sort_values('date')
        
        # 计算变化率
        df['avg_cost_change'] = df['avg_cost'].pct_change() * 100
        df['profit_ratio_change'] = df['profit_ratio'].pct_change() * 100
        df['concentration_70_change'] = df['concentration_70'].pct_change() * 100
        df['concentration_90_change'] = df['concentration_90'].pct_change() * 100
        
        # 计算筹码峰位置
        df['peak_price'] = df.apply(
            lambda row: row['prices'][np.argmax(row['distribution'])], axis=1
        )
        df['peak_price_change'] = df['peak_price'].pct_change() * 100
        
        # 计算低位筹码占比(低于90%成本下限)
        df['low_chip_ratio'] = df.apply(
            lambda row: sum(
                dist for price, dist in zip(row['prices'], row['distribution'])
                if price < row['cost_90_range'][0]
            ), axis=1
        )
        df['low_chip_change'] = df['low_chip_ratio'].pct_change() * 100
        
        # 计算高位筹码占比(高于90%成本上限)
        df['high_chip_ratio'] = df.apply(
            lambda row: sum(
                dist for price, dist in zip(row['prices'], row['distribution'])
                if price > row['cost_90_range'][1]
            ), axis=1
        )
        df['high_chip_change'] = df['high_chip_ratio'].pct_change() * 100
        
        return df
    
    def detect_main_force_action(self) -> Dict:
        """检测主力动作"""
        df = self.calculate_changes()
        if df.empty:
            return {'action': '数据不足', 'confidence': 0}
            
        latest = df.iloc[-1]
        prev = df.iloc[-2] if len(df) >= 2 else latest
        
        # 主力吸筹信号
        accumulation_signals = 0
        if latest['concentration_70'] < prev['concentration_70']:
            accumulation_signals += 1
        if latest['low_chip_ratio'] > prev['low_chip_ratio']:
            accumulation_signals += 1
        if latest['avg_cost'] < prev['avg_cost'] and latest['profit_ratio'] > prev['profit_ratio']:
            accumulation_signals += 1
            
        # 主力出货信号
        distribution_signals = 0
        if latest['concentration_70'] > prev['concentration_70']:
            distribution_signals += 1
        if latest['low_chip_ratio'] < prev['low_chip_ratio']:
            distribution_signals += 1
        if latest['avg_cost'] > prev['avg_cost'] and latest['profit_ratio'] < prev['profit_ratio']:
            distribution_signals += 1
        if latest['high_chip_ratio'] > prev['high_chip_ratio']:
            distribution_signals += 1
            
        # 洗盘信号
        wash_signals = 0
        if abs(latest['concentration_70_change']) < 2:
            wash_signals += 1
        if abs(latest['peak_price_change']) < 1:
            wash_signals += 1
        if abs(latest['low_chip_change']) < 5:
            wash_signals += 1
            
        # 判断主力动作
        if accumulation_signals >= 2:
            return {
                'action': '主力吸筹',
                'confidence': accumulation_signals / 3 * 100,
                'details': f"集中度下降{latest['concentration_70_change']:.2f}%, 低位筹码增加{latest['low_chip_change']:.2f}%"
            }
        elif distribution_signals >= 2:
            return {
                'action': '主力出货',
                'confidence': distribution_signals / 4 * 100,
                'details': f"集中度上升{latest['concentration_70_change']:.2f}%, 低位筹码减少{latest['low_chip_change']:.2f}%, 高位筹码增加{latest['high_chip_change']:.2f}%"
            }
        elif wash_signals >= 2:
            return {
                'action': '主力洗盘',
                'confidence': wash_signals / 3 * 100,
                'details': "筹码峰形态稳定，集中度变化不大"
            }
        else:
            return {
                'action': '无明显主力动作',
                'confidence': 50,
                'details': "各项指标变化不显著"
            }
    
    def plot_chip_distribution(self, date_index=-1):
        """绘制指定日期的筹码分布图"""
        if not self.daily_data:
            print("无数据可绘制")
            return
            
        data = self.daily_data[date_index]
        date_str = data['date'] if 'date' in data else '未知日期'
        
        plt.figure(figsize=(12, 8))
        plt.barh(data['prices'], data['distribution'], height=0.05, color='#1f77b4', alpha=0.7)
        
        # 标记当前价格
        plt.axhline(y=data['current_price'], color='red', linestyle='--', linewidth=2, label=f'当前价格: {data["current_price"]:.2f}元')
        
        # 标记平均成本
        plt.axhline(y=data['avg_cost'], color='green', linestyle='-.', linewidth=2, label=f'平均成本: {data["avg_cost"]:.2f}元')
        
        # 标记90%成本区间
        plt.axhspan(data['cost_90_range'][0], data['cost_90_range'][1], alpha=0.2, color='yellow', label='90%成本区间')
        
        plt.title(f'筹码分布图 - {date_str}', fontsize=16)
        plt.xlabel('筹码占比', fontsize=12)
        plt.ylabel('价格(元)', fontsize=12)
        plt.legend(fontsize=12)
        plt.grid(axis='x', alpha=0.3)
        plt.tight_layout()
        plt.show()
    
    def plot_trend_analysis(self):
        """绘制主力指标趋势图"""
        df = self.calculate_changes()
        if df.empty:
            print("数据不足，无法绘制趋势图")
            return
            
        fig, axes = plt.subplots(3, 1, figsize=(14, 12), sharex=True)
        
        # 价格与平均成本趋势
        axes[0].plot(df['date'], df['current_price'], 'o-', label='当前价格', color='red', linewidth=2)
        axes[0].plot(df['date'], df['avg_cost'], 's-', label='平均成本', color='green', linewidth=2)
        axes[0].fill_between(df['date'], df['current_price'], df['avg_cost'], 
                            where=df['current_price'] < df['avg_cost'], 
                            color='red', alpha=0.2, label='价格低于成本')
        axes[0].set_title('价格与平均成本趋势', fontsize=14)
        axes[0].legend()
        axes[0].grid(alpha=0.3)
        
        # 获利比例趋势
        axes[1].plot(df['date'], df['profit_ratio']*100, '^-', label='获利比例(%)', color='purple', linewidth=2)
        axes[1].axhline(y=50, color='gray', linestyle='--', label='50%分界线')
        axes[1].set_title('获利比例趋势', fontsize=14)
        axes[1].legend()
        axes[1].grid(alpha=0.3)
        
        # 筹码集中度趋势
        axes[2].plot(df['date'], df['concentration_70'], 'd-', label='70%集中度', color='orange', linewidth=2)
        axes[2].plot(df['date'], df['concentration_90'], 'v-', label='90%集中度', color='blue', linewidth=2)
        axes[2].set_title('筹码集中度趋势(数值越小越集中)', fontsize=14)
        axes[2].legend()
        axes[2].grid(alpha=0.3)
        
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
        plt.gca().xaxis.set_major_locator(mdates.DayLocator(interval=1))
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show(block=True)

if __name__ == '__main__':
    from stock_sdk import HamunaStockApi
    from stock_sdk.api import ADJUST

    api = HamunaStockApi('https://stock.ai.hamuna.club', 'hmcz1234')

    import asyncio
    
    kline = asyncio.run(api.get_daily_datelv_kline('002244', '2026-03-16', '2026-03-30', fq='qfq'))
    kline = pd.DataFrame(kline)
    kline.rename(columns={'volume': 'vol', 'turn': 'turnover', 'date': 'datetime'}, inplace=True)
    

    analyzer = ChipDistributionAnalyzer(kline)

    chip_ana = ChipAnalyzer()

    for i in range(len(kline)-1, len(kline)-1 - 10, -1):
        distributions = analyzer.calculate_chip_distribution(i)
        distributions['date'] = kline.iloc[i]['datetime']
        chip_ana.add_daily_data(distributions)
    
    chip_ana.plot_chip_distribution()
    
    # 如果有多个日期数据，执行以下分析
    if len(chip_ana.daily_data) >= 2:
        # 计算指标变化
        changes_df = chip_ana.calculate_changes()
        print("每日指标变化:")
        print(changes_df[['date', 'avg_cost', 'profit_ratio', 'concentration_70', 'low_chip_ratio']])
        
        # 检测主力动作
        action = chip_ana.detect_main_force_action()
        print(f"\n主力动作检测结果: {action['action']}")
        print(f"置信度: {action['confidence']:.1f}%")
        print(f"详细信息: {action['details']}")
        
        # 绘制趋势图
        chip_ana.plot_trend_analysis()
    else:
        print("\n提示：请添加至少2个日期的数据以进行主力变动分析")
        print("当前单日期分析结论：")
        print("1. 筹码主峰位于17.0-19.0元区间，峰值在18.0-19.0元")
        print("2. 70%集中度6.61%，属于中等偏集中水平，有一定主力控盘迹象")
        print("3. 当前价格低于平均成本，市场整体微亏，套牢盘主要在18.0-20.5元")
        print("4. 低位12.0-16.0元仍有少量残留筹码，可能是早期建仓的主力筹码")
    
