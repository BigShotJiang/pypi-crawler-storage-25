from stock_sdk.lib.tdxClient import TdxClient
from stock_sdk.lib.const import MARKET, PERIOD, ADJUST, SORT_TYPE, SORT_ORDER, CATEGORY, BOARD_TYPE
from stock_sdk.cache import async_long_cache_decorate
from stock_sdk.utils import get_stock_market
from concurrent.futures import ThreadPoolExecutor
from fake_useragent import UserAgent
from datetime import datetime, timedelta
from tqdm.asyncio import tqdm_asyncio
from stock_sdk.extra.fetcher import get_925_auction, get_last_day_limit, get_recent_trade_day, get_next_trade_day
from stock_sdk.extra.chips.analyzer import ChipDistributionAnalyzer, ChipAnalyzer
from aiodecorators import Semaphore

import traceback
import asyncio
try:
    import uvloop
    asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
except ImportError:
    pass
import json
import httpx
import pandas as pd

class HamunaStockApi:
    def __init__(self, base_url, token: str):
        self.num_concurrent_requests = 100
        self.client = TdxClient()
        self.executor = ThreadPoolExecutor(max_workers=self.num_concurrent_requests)
        self.http_client = httpx.AsyncClient(
            headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
                "Accept-Encoding": "gzip, deflate",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1",
            },
            http2=True,
            timeout=60,
            limits=httpx.Limits(max_keepalive_connections=20, max_connections=100)
        )
        self.base_url = base_url

        token_verified = self.verify_token(token)
        if not token_verified:
            raise ValueError("Token不合法，请检查后重试")
        else:
            self.token = token

    def verify_token(self, token: str):
        with httpx.Client() as client:
            response = client.post(self.base_url + '/api/auth/token_verify', json={'token': token})
        try:
            response.raise_for_status()
            if response.json()['valid']:
                print('Token合法')
                return True
            else:
                print('Token无效')
                return False
        except httpx.HTTPStatusError as e:
            print(e)
            return False

    def __get_market(self, market_str):
        if market_str.upper() == 'SH':
            return MARKET.SH
        elif market_str.upper() == 'SZ':
            return MARKET.SZ
        else:
            raise ValueError("Invalid market. Use 'SH' for Shanghai or 'SZ' for Shenzhen.")
        
    def _format_date(self, date):
        if isinstance(date, datetime):
            return date
        
        if isinstance(date, str):
            if '-' in date:
                return datetime.strptime(date, '%Y-%m-%d')
            if '.' in date:
                return datetime.strptime(date, '%Y.%m.%d')
            else:
                return datetime.strptime(date, '%Y%m%d')
        return date
    
    def _get_market(self, stock_code):
        market_str = get_stock_market(stock_code)
        return self.__get_market(market_str)
        
    async def async_run(self, func, *args):
        return await asyncio.to_thread(func, *args)
    
    async def _fetch(
            self,
        url: str, params: dict = {}, headers: dict = None, timeout: int = 60, method='get') -> dict:
        """通用异步GET请求（带重试，含 408 处理）"""
        useragent = UserAgent()
        request_headers = {"User-Agent": useragent.random, "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8", 'authorization': f'Bearer {self.token}'}
        if headers:
            request_headers.update(headers)

        func = getattr(self.http_client, method)
        parmas = {
            'params' if method == 'get' else 'json': params
        }
        for attempt in range(4):  # 增加重试次数到4
            try:
                response = await func(url, **parmas, headers=request_headers, timeout=timeout)
                response.raise_for_status()
                return response.json()
            except Exception as e:
                if attempt < 3:  # 最多重试3次
                    await asyncio.sleep(2 ** attempt)  # 指数退避
                    continue
                else:
                    return None
    
    # 获取股票列表
    @async_long_cache_decorate
    async def get_stock_list(self, filter_st=True):
        # 定义需要保留的代码前缀（按交易所区分）
        sh_prefixes = ('600', '601', '603', '605', '688')
        sz_prefixes = ('000', '001', '002', '003', '300', '301')

        def filter_stocks(stocks, prefixes, market_code):
            result = []
            for stock in stocks:
                code = stock['code']
                if code[:3] in prefixes or code[:2] in ('68',):  # 科创板可能是688，已包含
                    stock['market'] = market_code
                    if filter_st and 'ST' in stock['name'].upper():
                        continue
                    result.append({
                        'code': stock['code'],
                        'name': stock['name'],
                        'market': stock['market'],
                        'is_st': filter_st and 'ST' in stock['name'].upper()
                    })
            return result

        sh_stocks = filter_stocks(await self.async_run(self.client.stock_list, MARKET.SH), sh_prefixes, 'sh')
        sz_stocks = filter_stocks(await self.async_run(self.client.stock_list, MARKET.SZ), sz_prefixes, 'sz')
        return sh_stocks + sz_stocks
    
    @async_long_cache_decorate
    async def get_daily_kline(self, stock_code, count: int = 250, adjust: ADJUST = ADJUST.NONE):
        market = self._get_market(stock_code)
        return await self.async_run(self.client.stock_kline, market, stock_code, PERIOD.DAILY, 0, count, 1, adjust)
    
    # @async_long_cache_decorate
    async def get_daily_kline_rongwei(self, stock_code, date, direction=0, count: int = 250, adjust = 'qfq'):
        date = self._format_date(date).strftime('%Y%m%d')
        url = self.base_url + '/api/stock/kline/daily/' + stock_code
        params = {
            'count': count,
            'fq': adjust,
            'date': date,
            'direction': direction
        }
        return await self._fetch(url, params)
    
    async def get_minute_kline(self, stock_code, period: PERIOD, count: int = 250, adjust: ADJUST = ADJUST.NONE):
        market = self._get_market(stock_code)
        return await self.async_run(self.client.stock_kline, market, stock_code, period, 0, count, 1, adjust)

    @async_long_cache_decorate
    async def get_daily_datelv_kline(self, stock_code, start_date, end_date, fq: str = 'qfq'):
        url = self.base_url + '/api/stock/kline/datelv/daily'
        params = {
            'code': stock_code,
            'start_date': start_date,
            'end_date': end_date,
            'fq': fq
        }
        return await self._fetch(url, params)

    
    async def get_auctions(self, stock_code):
        market = self._get_market(stock_code)
        return await self.async_run(self.client.stock_auction, market, stock_code)
    
    # @async_long_cache_decorate
    @Semaphore(10)
    async def get_auction_0925(self, stock_code, date=None):
        return await self.async_run(get_925_auction, stock_code, date)
    
    async def stock_fundamental(self, stock_code):
        market = self._get_market(stock_code)
        return await self.async_run(self.client.stock_f10, market, stock_code)
    
    async def stock_fund_flow_summary_tdx(self, stock_code):
        market = self._get_market(stock_code)
        flow: pd.DataFrame = await self.async_run(self.client.stock_capital_flow, market, stock_code)
        flow['code'] = stock_code
        return flow.to_dict(orient='records')
    
    async def batch_stock_fundflow_summary_tdx(self, stock_codes):
        semaphore = asyncio.Semaphore(self.num_concurrent_requests)

        async def fetch(code: str):
            async with semaphore:
                return await self.stock_fund_flow_summary_tdx(code)

        tasks = [fetch(code) for code in stock_codes]
        results = await tqdm_asyncio.gather(*tasks, desc='获取股票资金流摘要')

        return results
    
    async def get_boards_tdx(self, board_type: BOARD_TYPE):
        return await self.async_run(self.client.stock_board_list, board_type)
    
    async def get_board_members_tdx(self, board_code, count=50, sort_type=SORT_TYPE.MAIN_NET_RATIO, sort_order=SORT_ORDER.DESC):
        return await self.async_run(self.client.stock_board_members, board_code, count, sort_type, sort_order)
                
    async def get_stock_belong_board_tdx(self, stock_code):
        market = self._get_market(stock_code)
        return await self.async_run(self.client.stock_belong_board, market, stock_code)
    
    async def market_monitor(self, market: MARKET, count):
        return await self.async_run(self.client.stock_market_monitor, market, 0, count)
    
    async def get_transaction_tdx(self, stock_code, date=None):
        market = self._get_market(stock_code)
        return await self.async_run(self.client.stock_transaction, market, stock_code, self._format_date(date))
    
    async def get_batched_daily_kline_tdx(
        self, stock_codes: list[str], count: int = 250, adjust: ADJUST = ADJUST.NONE
    ) -> tuple[list[str], list[any]]:
        semaphore = asyncio.Semaphore(self.num_concurrent_requests)

        async def fetch(code: str):
            async with semaphore:
                return await self.get_daily_kline(code, count, adjust)

        tasks = [fetch(code) for code in stock_codes]
        results = await asyncio.gather(*tasks)

        codes = []
        klines = []
        for code, kline in zip(stock_codes, results):
            if kline is not None:
                codes.append(code)
                klines.append(kline)

        return codes, klines
    
    async def get_quote_tdx(self, stock_code):
        market = self._get_market(stock_code)
        return await self.async_run(self.client.stock_quotes, market, stock_code)
    
    async def get_quotes_tdx(self, stock_codes: list[str]) -> list[dict]:
        def format_codes(codes):
            return [(self._get_market(code), code) for code in codes]
        
        stock_codes = format_codes(stock_codes)
        batches = [stock_codes[i:i + self.num_concurrent_requests] for i in range(0, len(stock_codes), self.num_concurrent_requests)]

        async def fetch_batch(batch):
            return await self.async_run(self.client.stock_quotes, batch)
        
        tasks = [fetch_batch(batch) for batch in batches]
        results = await asyncio.gather(*tasks)

        all_data = []
        for data in results:
            all_data.extend(data)
        return all_data

    @async_long_cache_decorate
    async def get_news_from_stock(self, code, days=7):
        print(f"[API] 获取 {code} 相关新闻...")
        """获取股票相关新闻"""
        try:
            code_str = str(code).strip()
            if code_str.startswith("6"):
                secid = f"1.{code_str}"
            elif code_str.startswith(("0", "3")):
                secid = f"0.{code_str}"
            else:
                secid = f"1.{code_str}"

            url = "https://np-listapi.eastmoney.com/comm/web/getListInfo"
            params = {
                "cfh": "1",
                "client": "web",
                "mTypeAndCode": secid,
                "type": "1",
                "pageSize": "50",
            }

            data = await self._fetch(
                url,
                params=params,
                headers={
                    "Referer": f"https://quote.eastmoney.com/sh{code}.html"
                    if code.startswith("6")
                    else f"https://quote.eastmoney.com/sz{code}.html",
                    "Accept": "*/*",
                },
                timeout=10,
            )
            try:
                if isinstance(data, dict) and "data" in data and "list" in data["data"]:
                    items = data["data"]["list"]
                    news_list = []
                    for item in items:
                        if isinstance(item, dict):
                            news_item = {
                                "title": item.get("Art_Title", ""),
                                "url": item.get("Art_Url", ""),
                                "summary": "",
                                "source": "东方财富",
                                "time": item.get("Art_ShowTime", ""),
                                "type": "news",
                            }
                            if news_item["title"]:
                                news_list.append(news_item)

                    if days > 0:
                        filtered_news = []
                        today = datetime.now().date()
                        for news in news_list:
                            try:
                                if news.get("time"):
                                    news_time = datetime.strptime(
                                        news["time"], "%Y-%m-%d %H:%M:%S"
                                    )
                                    news_date = news_time.date()
                                    days_ago_date = today - timedelta(days=days)
                                    if news_date >= days_ago_date:
                                        filtered_news.append(news)
                                else:
                                    filtered_news.append(news)
                            except:
                                filtered_news.append(news)
                        news_list = filtered_news

                    return news_list
            except:
                pass

            return []
        except Exception as e:
            return []

    @async_long_cache_decorate
    async def get_guba_posts(self, code, latest_count=10, hot_count=10):
        print(f"[API] 获取 {code} 股吧帖子（最新+热门）...")
        """获取股吧帖子（最新+热门）"""
        try:
            url = "https://gbapi.eastmoney.com/webarticlelist/api/Article/Articlelist"
            headers = {
                "Referer": f"https://guba.eastmoney.com/list,{code},99.html",
                "Accept": "application/json",
            }

            all_posts = []
            post_ids = set()

            params_latest = {
                "code": code,
                "sorttype": "1",
                "ps": str(latest_count),
                "from": "CommonBaPost",
                "deviceid": "quoteweb",
                "version": "200",
                "product": "Guba",
                "plat": "Web",
                "needzd": "true",
            }

            data = await self._fetch(
                url, params=params_latest, headers=headers, timeout=10
            )
            try:
                if (
                    isinstance(data, dict)
                    and "re" in data
                    and isinstance(data["re"], list)
                ):
                    for article in data["re"]:
                        if isinstance(article, dict):
                            post_id = article.get("post_id")
                            if post_id and post_id not in post_ids:
                                post_ids.add(post_id)
                                post_item = {
                                    "post_id": post_id,
                                    "title": article.get("post_title", ""),
                                    "url": article.get("post_url", ""),
                                    "author": article.get("user_nickname", ""),
                                    "read_count": article.get("post_click_count", 0),
                                    "comment_count": article.get(
                                        "post_comment_count", 0
                                    ),
                                    "time": article.get("post_publish_time", ""),
                                    "type": "forum",
                                    "sort_type": "latest",
                                }
                                if post_item["title"]:
                                    all_posts.append(post_item)
            except json.JSONDecodeError:
                pass

            params_hot = {
                "code": code,
                "sorttype": "2",
                "ps": str(hot_count),
                "from": "CommonBaPost",
                "deviceid": "quoteweb",
                "version": "200",
                "product": "Guba",
                "plat": "Web",
                "needzd": "true",
            }

            response_hot = await self._fetch(url, params=params_hot, headers=headers, timeout=10)
            if response_hot["status_code"] == 200:
                try:
                    data = json.loads(response_hot["text"])
                    if (
                        isinstance(data, dict)
                        and "re" in data
                        and isinstance(data["re"], list)
                    ):
                        for article in data["re"]:
                            if isinstance(article, dict):
                                post_id = article.get("post_id")
                                if post_id and post_id not in post_ids:
                                    post_ids.add(post_id)
                                    post_item = {
                                        "post_id": post_id,
                                        "title": article.get("post_title", ""),
                                        "url": article.get("post_url", ""),
                                        "author": article.get("user_nickname", ""),
                                        "read_count": article.get("post_click_count", 0),
                                        "comment_count": article.get(
                                            "post_comment_count", 0
                                        ),
                                        "time": article.get("post_publish_time", ""),
                                        "type": "forum",
                                        "sort_type": "hot",
                                    }
                                    if post_item["title"]:
                                        all_posts.append(post_item)
                except json.JSONDecodeError:
                    pass

            return all_posts
        except Exception as e:
            return []

    @async_long_cache_decorate
    async def get_industries(self):
        url = self.base_url + '/api/industry/mapper'
        response = await self._fetch(url)
        return response
    
    async def get_industry_info(self, industry_code):
        url = self.base_url + '/api/industry/info'
        response = await self._fetch(url, params={"code": industry_code})
        return response
    
    @async_long_cache_decorate
    async def get_industry_ranking(self):
        url = self.base_url + '/api/industry/ranking'
        response = await self._fetch(url)
        return response

    @async_long_cache_decorate
    async def get_industry_hotness(self):
        url = self.base_url + '/api/industry/fundflows'
        response = await self._fetch(url)
        if response:
            response = response['value']['industry_fundflows']
            return response
        return None
    
    @async_long_cache_decorate
    async def get_board_info(self, board_code, counts=240):
        url = self.base_url + '/api/stock/kline/daily/' + board_code
        response = await self._fetch(url, params={"count": counts})
        if response:
            response = response['value']['kline']
            return response
        return None
    
    @async_long_cache_decorate
    async def get_lastday_limit(self, date):
        date = self._format_date(date)
        yesterday = date - timedelta(days=1)

        day = get_recent_trade_day(yesterday, return_format='%Y%m%d')

        return get_last_day_limit(day)
    
    @async_long_cache_decorate
    async def get_chip_distribution(self, code, date=None, count=10):
        if date is None:
            klines = await self.get_daily_kline(code, count=30, adjust=ADJUST.QFQ)
        else:
            start_date = self._format_date(date) - timedelta(days=30)
            end_date = self._format_date(date)
            # klines = await self.get_daily_datelv_kline(code, start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
            klines = await self.get_daily_datelv_kline(code, start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'), fq='qfq')
        klines = pd.DataFrame(klines)
        klines.rename(columns={'volume': 'vol', 'turn': 'turnover', 'date': 'datetime'}, inplace=True)
        analyzer = ChipDistributionAnalyzer(klines)
        chip_ana = ChipAnalyzer()
        n_klines = klines.shape[0]
        for i in range(n_klines-1, n_klines-1 - count, -1):
            distributions = analyzer.calculate_chip_distribution(i)
            distributions['date'] = klines.iloc[i]['datetime']
            chip_ana.add_daily_data(distributions)

        main_force_detection = chip_ana.detect_main_force_action()
        return main_force_detection
        
    def get_latest_trade_day(self, date, forward=False):
        return get_recent_trade_day(self._format_date(date), forward)
                
    def get_next_trade_day(self, date):
        return get_next_trade_day(self._format_date(date))
    
    @async_long_cache_decorate
    async def auction_computation(self, r, auc):
        url = self.base_url + '/api/stock/computations/auction'
        if isinstance(r, pd.Series):
            r = r.to_dict()
        response = await self._fetch(url, params={"r": r, "auc": auc}, method='post')
        if response:
            return response
        return None

if __name__ == "__main__":
    import time
    api = HamunaStockApi(base_url='https://stock.ai.hamuna.club', token='hmcz1234')

    print(api)
