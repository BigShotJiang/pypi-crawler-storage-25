"""
HamunaStockApi - A股行情数据SDK

pip install stock_sdk -U -i https://pypi.tuna.tsinghua.edu.cn/simple
"""
from .api import HamunaStockApi

__version__ = "0.1.0"
__all__ = ["HamunaStockApi"]

__doc__ = """
HamunaStockApi - A股行情数据SDK

安装:
    pip install stock_sdk -U -i https://pypi.tuna.tsinghua.edu.cn/simple

使用:
    from stock_sdk import HamunaStockApi
    api = HamunaStockApi(base_url='https://stock.ai.hamuna.club', token='xxx')
"""
