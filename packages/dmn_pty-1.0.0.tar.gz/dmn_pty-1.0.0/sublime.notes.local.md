## Sublime Text integration

Tie in to sublime-mise? Or maybe to **any** build system?

SublimeShell plugin:
- run daemon in specific dir first
	- this allows output in the normal shell instead of in sublime or lost to logs
- bidirectional comms: example is doing mise tasks and getting a picker on which one to run

May be of interest:

on_window_command(window: Window, command_name: str, args: CommandArgs)
	Called when a window command is issued. The listener may return a (command, arguments) tuple to rewrite the command, or None to run the command unmodified.

on_text_command(view: View, command_name: str, args: CommandArgs)
	Called when a text command is issued. The listener may return a (command, arguments) tuple to rewrite the command, or None to run the command unmodified.

See also:
https://github.com/randy3k/SendCode/
https://claude.ai/chat/092cd769-9542-4fb1-a52e-21ea6929dab7

More ideas:
send selected text to terminal

Putting it all together, I think I want a suite of different plugins! Each interacting with `dmn` on their own. Which means `dmn` needs to properly handle multiple connections.

### Task loader

- Opens a panel pre-loaded with all the available scripts.
```
./scripts/test.sh
mise run test (pytest .)
mise run lint (uv run ruff)

```

First iteration: hardcoded list to test

Future:

- Load from mise
- Load from projects settings (build system-ish)
- Load from package.json?
- Load from defaults?

Think about:
- Types of tasks
	- Project-wide (just run bundle exec rspec from root)
	- File-specific (is this even needed? what for?). Maybe just allow defining a script with something like `$file` that gets replaced
- Outputs? Do we just have a popup panel saying: `Task "bundle exec rspec" exited with code 0` and an emoji? Or full output? Configurable?


Idea: maybe this should be decoupled/configurable. So the config of the TaskRunner plugin would be:

```json
{
	"sources": [
		"mise",
		"just",
		"make",
		"npm-run",
		"sublime-project", // Sublime Text project config block
	],
	"sink": "dmn", // also: Terminus, Sublime console??
}
```


### Send text to terminal

Command Palette includes a new entry "Send text to terminal". Could be nice to eg open `irb` on daemonised shell then send over the code

### Synchronise text

Bit more advanced. Maybe for composing a long query in mycli, or a hard command (altho for this there's already zle's edit-command-line)

Bidirectional sync somehow. Needs more refining
