
## Misc learning notes

```py
master_fd, slave_fd = pty.openpty()
```

- Allocates a new PTY: a master end (master_fd) and a slave end (slave_fd).
- Anything written to the slave appears on the master, and vice versa. The slave acts like a real TTY device to the program that uses it as its stdio.



A single event loop watching:

User keyboard input (stdin)
Shell output (master_fd)



The eventual loop (not shown here) will look like:

If stdin readable → read bytes → write to master_fd
If master_fd readable → read bytes → write to stdout


A pseudo‑terminal (PTY) is a kernel object that behaves like a real terminal device.
It has two ends:
- **Master**
	- Role: Controller
	- Typical owner: Terminal emulator, SSH client, your parent process
 ***Slave**
	- Role: Pretends to be a real tty
	- Typical owner: Shell, programs like bash, vim, less

Think:

	Slave = keyboard + screen (from the program’s POV)
	Master = wire to that keyboard/screen

Anything written to one side appears as input on the other.

Both FDs (master/slave) refer to the same kernel PTY object, just different ends

fork() duplicates the file descriptor table, not the underlying objects
✅ The parent and child both “have” the slave_fd
✅ They refer to the same PTY slave device
❌ They are not the same file descriptor entry


When you call close(fd):

The process removes that FD number from its own FD table
The kernel decrements the reference count
The underlying object is destroyed only when the count reaches zero

They are not closing “the same fd”—they are closing their own copy of an FD pointing to the same object.

The master is a transport, the slave is a terminal.



Unix has conventions that programs rely on:

File descriptor 0 → stdin
File descriptor 1 → stdout
File descriptor 2 → stderr

So the goal is not “have a PTY slave open somewhere”.
The goal is:

Make the PTY slave be fd 0, 1, and 2.

dup2() is the canonical, race‑free, POSIX way to say: “Make this exact fd number point to that exact underlying object.”



With just master_fd, the parent can:
✅ Handle all interactive I/O
- Write keystrokes to master_fd
- Read shell output from master_fd
✅ Propagate window size (SIGWINCH)
- Window size is a property of the PTY slave
- Setting it via the master automatically affects the slave
- The kernel delivers SIGWINCH to the foreground process group on the slave





Very similar stuff:
https://github.com/TVHGroup/oemessagingservice/blob/784b339857780ffc80c3f890bcd91cd7fc021ff8/python/jmsadapter.py#L196



https://medium.com/@cocarmon/from-sockets-and-selectors-comprehensive-guide-to-building-a-python-static-web-server-part-1-4-e2e998b18a0a





Writable is almost always true.
For connected sockets (and often for a PTY master), the kernel reports WRITABLE nearly all the time. With level‑triggered backends (what Python’s selectors generally use), your selector will wake up every loop for every fd with WRITE interest—even when you have nothing to send. That becomes a busy loop: high CPU, battery drain, and poor scaling with many connections.


Backpressure semantics.
You only need WRITE events when you have pending bytes and you previously got EAGAIN/partial writes. If you always stay subscribed to WRITE, you’ll keep getting spurious wakeups; the right way is to arm WRITE only when needed, then disarm once you drain the buffer.


The clean pattern is:

- Use selector.modify(fd, new_mask) to add/remove WRITE from the mask.
- Unregister only when you truly want zero interest (some backends don’t allow “register with mask=0”). Many tasks never need to go to zero (e.g., PTY read, client read).

https://medium.com/@cocarmon/from-sockets-and-selectors-comprehensive-guide-to-building-a-python-static-web-server-part-2-4-a1807bc2ef61
https://medium.com/@cocarmon/from-sockets-and-selectors-comprehensive-guide-to-building-a-performant-python-static-web-server-6444771b8ffb


Before sending commands, consider doing the equivalent to fancy ctrl+z (zle push-input)
Not sure how to do that tho!
seems like one way is to do: alt+x -> push-input<Enter>


### Backpressure

The sink should communicate "paused" back to the source when it's overloaded. My current implementation involves the sink either returning a status from write or directly calling source.pause()/source.resume(). The key question is whether to use callbacks or introduce a on_drain event for the Sink to signal when it's ready for more data. There's an alternative to a callback, where the Sink has a method to subscribe to draining

## tmux??

What dmn would need to become a single-session tmux
Right now dmn is monolithic — the PTY owner and the terminal bridge are in the same process. To support detach/reattach:
1. Split into two processes:
   - dmn-server — forks the shell, owns the PTY master, runs the event loop, listens on the Unix socket. This process is daemonized (detached from the controlling terminal).
   - dmn-client (or dmn attach) — connects to the server's Unix socket, puts the local terminal in raw mode, bridges stdin/stdout over the socket.
2. Protocol extension: The socket API would need a new message type for I/O bridging — not just fire-and-forget EXEC commands, but a persistent bidirectional stream. The client sends keystrokes, the server sends PTY output back.
3. Output buffering in the server: When no client is attached, the server needs to buffer recent PTY output (scrollback) so it can replay it when a client reattaches. tmux keeps a configurable scrollback buffer per pane.
4. SIGWINCH forwarding: The client detects terminal resize and sends the new dimensions to the server, which calls ioctl(TIOCSWINSZ) on the PTY.
5. Daemonization: The server needs to fork() + setsid() to detach from the controlling terminal, or use systemd socket activation.
Architectural overlap with dmn
You're already surprisingly close:
- PTY management: done
- Unix socket API: done
- SIGWINCH handling: done
- Event loop: done
The main gap is the client/server split and the bidirectional socket bridge. The current HandleSockConnectionTask handles request/response; you'd need a variant that streams I/O bidirectionally (essentially the same as StdinReadTask/StdoutWriteTask but over the socket instead of stdio).
It's probably a 300-400 line delta from where you are now — split main.py into server.py and client.py, add an ATTACH message type, and handle the stream lifecycle.
