# 🧬 toolkitbio

A comprehensive Python bioinformatics toolkit for DNA sequence analysis, file format conversion, NCBI queries, sequence alignment, phylogenetics, and protein structure visualization.

## Installation

```bash
pip install toolkitbio
```

## Features

| Module | Description |
|--------|-------------|
| `seq_operations` | DNA slicing, concatenation, transcription & translation |
| `fasta_reader` | Parse and read FASTA files |
| `genbank_writer` | Create GenBank format files |
| `fasta_to_genbank` | Convert FASTA → GenBank |
| `gene_annotation` | Add annotations and features to sequences |
| `ncbi_fetch` | Fetch sequences from NCBI Entrez |
| `pairwise_align` | Pairwise sequence alignment |
| `muscle_align` | Multiple sequence alignment via MUSCLE |
| `phylo_tree` | Phylogenetic tree construction (UPGMA/NJ) |
| `pdb_viewer` | 3D protein structure visualization |

## Quick Start (Python API)

```python
from toolkitbio import dna_operations, read_fasta, fetch_from_ncbi

# DNA operations
result = dna_operations("ATGCTAGCTAGCTAGCTG", start=3, end=11)
print(result["rna"])       # RNA sequence
print(result["protein"])   # Protein sequence

# Read FASTA file
records = read_fasta("sequences.fasta")

# Fetch from NCBI
data = fetch_from_ncbi("NM_001301717")
print(data["organism"], data["length"])
```

## Command-Line Interface

```bash
# DNA sequence operations
toolkitbio seq-ops --seq ATGCTAGCTAGCTAGCTG

# Read FASTA file
toolkitbio read-fasta sequences.fasta

# Fetch from NCBI
toolkitbio fetch-ncbi NM_001301717

# Pairwise alignment
toolkitbio align-pair --seq1 AGTACACTGGT --seq2 AGTACGCTGGT

# Convert FASTA to GenBank
toolkitbio convert input.fasta output.gb

# Build phylogenetic tree
toolkitbio phylo-tree aligned.fasta --method upgma

# View 3D protein structure
toolkitbio view-pdb 1A3N --save structure.png
```

## Requirements

- Python >= 3.8
- Biopython >= 1.80
- Matplotlib >= 3.5
- NumPy >= 1.21
- MUSCLE (optional, for multiple alignment)

## License

MIT License - see [LICENSE](LICENSE) for details.

## Author

**ravi** — ravi424e@gmail.com
