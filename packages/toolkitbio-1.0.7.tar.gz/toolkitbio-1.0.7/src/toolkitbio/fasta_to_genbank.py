"""
FASTA to GenBank Converter Module
===================================

Convert FASTA files to GenBank format.
"""

from Bio import SeqIO
from Bio.SeqRecord import SeqRecord


def convert_fasta_to_genbank(
    fasta_file,
    genbank_file,
    molecule_type="DNA",
    gene_name="ExampleGene",
    function="Hypothetical protein",
):
    """
    Convert a FASTA file to GenBank format.

    Args:
        fasta_file (str): Path to input FASTA file.
        genbank_file (str): Path to output GenBank file.
        molecule_type (str): Molecule type annotation.
        gene_name (str): Gene name annotation.
        function (str): Function annotation.

    Returns:
        int: Number of records converted.
    """
    records = []

    for record in SeqIO.parse(fasta_file, "fasta"):
        genbank_record = SeqRecord(
            record.seq,
            id=record.id,
            name=gene_name,
            description=record.description,
            annotations={
                "molecule_type": molecule_type,
                "gene": gene_name,
                "function": function,
            },
        )
        records.append(genbank_record)

    with open(genbank_file, "w") as output:
        SeqIO.write(records, output, "genbank")

    print(f"Converted {len(records)} records → {genbank_file}")
    return len(records)


def run(fasta_file, genbank_file):
    """Run FASTA to GenBank conversion."""
    return convert_fasta_to_genbank(fasta_file, genbank_file)


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 3:
        run(sys.argv[1], sys.argv[2])
    else:
        print("Usage: python fasta_to_genbank.py <input.fasta> <output.gb>")
