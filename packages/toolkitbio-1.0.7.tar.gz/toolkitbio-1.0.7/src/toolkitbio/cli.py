"""
toolkitbio CLI - Command-line interface for the bioinformatics toolkit.

Usage:
Commands to RUN the tools:
    seq-ops       Run DNA sequence operations
    read-fasta    Read a FASTA file
    write-genbank Create a GenBank file
    convert       Convert FASTA to GenBank
    annotate      Annotate a gene sequence
    fetch-ncbi    Fetch sequence from NCBI
    align-pair    Pairwise sequence alignment
    align-muscle  Multiple alignment with MUSCLE
    phylo-tree    Build phylogenetic tree
    view-pdb      View 3D PDB structure

Commands to VIEW the Python source code:
    1 to 10       (e.g., `toolkitbio 1` shows the code for DNA ops)
"""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="toolkitbio",
        description="toolkitbio - A Bioinformatics Toolkit by ravi",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # 1. seq-ops
    sub = subparsers.add_parser("seq-ops", aliases=["1"], help="[1] DNA sequence operations")
    sub.add_argument("--seq", default="ATGCTAGCTAGCTAGCTG", help="DNA sequence")
    sub.add_argument("--start", type=int, default=3, help="Slice start index")
    sub.add_argument("--end", type=int, default=11, help="Slice end index")
    sub.add_argument("--concat", default="GGCTAG", help="Sequence to concatenate")

    # 2. read-fasta
    sub = subparsers.add_parser("read-fasta", aliases=["2"], help="[2] Read a FASTA file")
    sub.add_argument("file", help="Path to FASTA file")

    # 3. write-genbank
    sub = subparsers.add_parser("write-genbank", aliases=["3"], help="[3] Create a GenBank file")
    sub.add_argument("--seq", default="ATGCGTACGTAGCTAGCTAG", help="DNA sequence")
    sub.add_argument("--output", default="output.gb", help="Output file")

    # 4. convert
    sub = subparsers.add_parser("convert", aliases=["4"], help="[4] Convert FASTA to GenBank")
    sub.add_argument("input", help="Input FASTA file")
    sub.add_argument("output", help="Output GenBank file")

    # 5. annotate
    sub = subparsers.add_parser("annotate", aliases=["5"], help="[5] Annotate a gene sequence")
    sub.add_argument("--seq", default="ATGCGTACGTAGCTAGCTAG", help="DNA sequence")

    # 6. fetch-ncbi
    sub = subparsers.add_parser("fetch-ncbi", aliases=["6"], help="[6] Fetch from NCBI")
    sub.add_argument("accession", help="Accession number")
    sub.add_argument("--email", default="ravi424e@gmail.com", help="Email for NCBI")

    # 7. align-pair
    sub = subparsers.add_parser("align-pair", aliases=["7"], help="[7] Pairwise alignment")
    sub.add_argument("--seq1", default="AGTACACTGGT", help="First sequence")
    sub.add_argument("--seq2", default="AGTACGCTGGT", help="Second sequence")

    # 8. align-muscle
    sub = subparsers.add_parser("align-muscle", aliases=["8"], help="[8] MUSCLE alignment")
    sub.add_argument("input", help="Input FASTA file")
    sub.add_argument("--output", default="aligned.fasta", help="Output file")
    sub.add_argument("--muscle-exe", default=None, help="Path to MUSCLE executable")

    # 9. phylo-tree
    sub = subparsers.add_parser("phylo-tree", aliases=["9"], help="[9] Build phylogenetic tree")
    sub.add_argument("alignment", help="Aligned FASTA file")
    sub.add_argument("--output", default="tree.nwk", help="Output Newick file")
    sub.add_argument("--method", default="upgma", choices=["upgma", "nj"])

    # 10. view-pdb
    sub = subparsers.add_parser("view-pdb", aliases=["10"], help="[10] View 3D PDB structure")
    sub.add_argument("pdb_id", help="PDB ID (e.g. 1A3N)")
    sub.add_argument("--save", default=None, help="Save plot to file")

    # Intercept numeric arguments to print source code
    if len(sys.argv) > 1 and sys.argv[1] in [str(i) for i in range(1, 11)]:
        from toolkitbio.original_scripts import SCRIPTS
        print(f"\n{'='*50}\nSource Code for Program {sys.argv[1]}\n{'='*50}\n")
        print(SCRIPTS[sys.argv[1]])
        print(f"\n{'='*50}\n")
        sys.exit(0)

    args = parser.parse_args()

    if args.command is None:
        print("="*50)
        print("*** Welcome to toolkitbio! ***")
        print("A Bioinformatics Toolkit for sequence analysis, alignment, and more.")
        print("="*50 + "\n")
        print("To use the toolkit, provide a command (or its number).")
        print("Example 1 (Code)     : toolkitbio 1")
        print("Example 1 (Run)      : toolkitbio seq-ops --seq ATGCTAGCTAGCTAGCTG")
        print("Example 2 (Run)      : toolkitbio read-fasta sequences.fasta\n")
        parser.print_help()
        sys.exit(0)

    if args.command in ("seq-ops", "1"):
        from toolkitbio.seq_operations import dna_operations
        result = dna_operations(args.seq, args.start, args.end, args.concat)
        for k, v in result.items():
            print(f"{k:15s}: {v}")

    elif args.command in ("read-fasta", "2"):
        from toolkitbio.fasta_reader import read_fasta
        read_fasta(args.file)

    elif args.command in ("write-genbank", "3"):
        from toolkitbio.genbank_writer import write_genbank
        write_genbank(sequence=args.seq, output_file=args.output)

    elif args.command in ("convert", "4"):
        from toolkitbio.fasta_to_genbank import convert_fasta_to_genbank
        convert_fasta_to_genbank(args.input, args.output)

    elif args.command in ("annotate", "5"):
        from toolkitbio.gene_annotation import annotate_gene, run
        run()

    elif args.command in ("fetch-ncbi", "6"):
        from toolkitbio.ncbi_fetch import fetch_from_ncbi
        result = fetch_from_ncbi(args.accession, email=args.email)
        for k, v in result.items():
            if k == "sequence":
                print(f"{k:15s}: {v[:80]}...")
            else:
                print(f"{k:15s}: {v}")

    elif args.command in ("align-pair", "7"):
        from toolkitbio.pairwise_align import pairwise_alignment
        result = pairwise_alignment(args.seq1, args.seq2)
        print(f"Score: {result['score']}")
        print(result['best_alignment'])

    elif args.command in ("align-muscle", "8"):
        from toolkitbio.muscle_align import muscle_alignment
        muscle_alignment(args.input, args.output, args.muscle_exe)

    elif args.command in ("phylo-tree", "9"):
        from toolkitbio.phylo_tree import build_phylo_tree
        build_phylo_tree(args.alignment, args.output, method=args.method)

    elif args.command in ("view-pdb", "10"):
        from toolkitbio.pdb_viewer import view_pdb_structure
        view_pdb_structure(args.pdb_id, save_plot=args.save)


if __name__ == "__main__":
    main()
