"""
NCBI Fetch Module
==================

Fetch nucleotide sequences from NCBI using Entrez.
"""

from Bio import Entrez, SeqIO


def fetch_from_ncbi(accession_number, email="ravi424e@gmail.com", db="nucleotide"):
    """
    Fetch a sequence record from NCBI by accession number.

    Args:
        accession_number (str): NCBI accession number (e.g., 'NM_001301717').
        email (str): Email for NCBI Entrez (required by NCBI).
        db (str): NCBI database name (default: 'nucleotide').

    Returns:
        dict: Dictionary with 'id', 'description', 'organism', 'sequence', and 'length'.
    """
    Entrez.email = email

    handle = Entrez.efetch(
        db=db,
        id=accession_number,
        rettype="gb",
        retmode="text",
    )

    seq_record = SeqIO.read(handle, "genbank")
    handle.close()

    result = {
        "id": seq_record.id,
        "description": seq_record.description,
        "organism": seq_record.annotations.get("organism", "Unknown"),
        "sequence": str(seq_record.seq),
        "length": len(seq_record.seq),
    }

    return result


def run(accession_number="NM_001301717"):
    """Run NCBI fetch and print results."""
    result = fetch_from_ncbi(accession_number)
    print(f"Accession  : {result['id']}")
    print(f"Description: {result['description']}")
    print(f"Organism   : {result['organism']}")
    print(f"Length     : {result['length']} bp")
    print(f"Sequence   : {result['sequence'][:80]}...")
    return result


if __name__ == "__main__":
    import sys
    acc = sys.argv[1] if len(sys.argv) > 1 else "NM_001301717"
    run(acc)
