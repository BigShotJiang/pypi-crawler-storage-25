"""
PDB Structure Viewer Module
==============================

Download and visualize 3D protein structures from PDB.
"""

from Bio.PDB import PDBList, PDBParser
import matplotlib.pyplot as plt
import numpy as np


def view_pdb_structure(pdb_id="1A3N", download_dir=".", show_plot=True, save_plot=None):
    """
    Download and visualize a 3D protein structure from PDB.

    Args:
        pdb_id (str): PDB ID (e.g., '1A3N').
        download_dir (str): Directory to download PDB file.
        show_plot (bool): Whether to display the 3D plot.
        save_plot (str): If provided, save the plot to this path.

    Returns:
        numpy.ndarray: Array of atom coordinates (N x 3).
    """
    PDBList().retrieve_pdb_file(pdb_id, pdir=download_dir, file_format="pdb")

    filename = f"pdb{pdb_id.lower()}.ent"
    structure = PDBParser(QUIET=True).get_structure(pdb_id, f"{download_dir}/{filename}")

    atoms = []
    for model in structure:
        for chain in model:
            for residue in chain:
                for atom in residue:
                    atoms.append(atom.coord)

    atoms = np.array(atoms)

    if show_plot or save_plot:
        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection="3d")
        ax.scatter(atoms[:, 0], atoms[:, 1], atoms[:, 2], c="blue", s=5, alpha=0.6)
        ax.set_title(f"3D Structure of {pdb_id}")
        ax.set_xlabel("X")
        ax.set_ylabel("Y")
        ax.set_zlabel("Z")
        if save_plot:
            plt.savefig(save_plot, dpi=150, bbox_inches="tight")
        if show_plot:
            plt.show()
        plt.close()

    return atoms


def run(pdb_id="1A3N"):
    """Run PDB viewer."""
    return view_pdb_structure(pdb_id)


if __name__ == "__main__":
    import sys
    pid = sys.argv[1] if len(sys.argv) > 1 else "1A3N"
    run(pid)
