"""
Gene Annotation Module
========================

Create, modify, and inspect gene annotations and sequence features.
"""

from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.SeqFeature import SeqFeature, FeatureLocation


def annotate_gene(
    sequence="ATGCGTACGTAGCTAGCTAG",
    seq_id="seq1",
    name="Example_Gene",
    description="An example DNA sequence for gene annotation.",
    organism="Synthetic organism",
    gene="ExampleGene",
    function="Hypothetical protein",
    feature_start=0,
    feature_end=21,
):
    """
    Create a SeqRecord with gene annotations and features.

    Args:
        sequence (str): DNA sequence string.
        seq_id (str): Sequence ID.
        name (str): Sequence name.
        description (str): Sequence description.
        organism (str): Organism name.
        gene (str): Gene name.
        function (str): Gene function description.
        feature_start (int): Gene feature start position.
        feature_end (int): Gene feature end position.

    Returns:
        SeqRecord: Annotated SeqRecord object.
    """
    dna_sequence = Seq(sequence)

    record = SeqRecord(
        dna_sequence,
        id=seq_id,
        name=name,
        description=description,
    )

    # Add annotations
    record.annotations["gene"] = gene
    record.annotations["function"] = function
    record.annotations["organism"] = organism

    # Add gene feature
    gene_feature = SeqFeature(
        FeatureLocation(feature_start, feature_end),
        type="gene",
        qualifiers={"gene": gene},
    )
    record.features.append(gene_feature)

    return record


def run():
    """Run with defaults and print the annotated record."""
    record = annotate_gene()
    print(f"ID          : {record.id}")
    print(f"Name        : {record.name}")
    print(f"Description : {record.description}")
    print(f"Annotations : {record.annotations}")
    print(f"Features    : {record.features}")
    return record


if __name__ == "__main__":
    run()
