"""
FASTA Reader Module
====================

Read and parse FASTA files, returning sequence records.
"""

from Bio import SeqIO


def read_fasta(file_path, verbose=True):
    """
    Read sequences from a FASTA file.

    Args:
        file_path (str): Path to the FASTA file.
        verbose (bool): If True, print each record's details.

    Returns:
        list: A list of dicts with 'id', 'description', and 'sequence' keys.
    """
    records = []
    for record in SeqIO.parse(file_path, "fasta"):
        entry = {
            "id": record.id,
            "description": record.description,
            "sequence": str(record.seq),
        }
        records.append(entry)
        if verbose:
            print(f"ID: {record.id}")
            print(f"Description: {record.description}")
            print(f"Sequence: {record.seq}")
            print()

    if verbose:
        print(f"Total records: {len(records)}")
    return records


def run(file_path):
    """Run FASTA reader on a file."""
    return read_fasta(file_path, verbose=True)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        run(sys.argv[1])
    else:
        print("Usage: python fasta_reader.py <path_to_fasta_file>")
