"""
Sequence Operations Module
===========================

Perform DNA sequence manipulation: slicing, concatenation,
transcription to RNA, and translation to protein.
"""

from Bio.Seq import Seq


def dna_operations(sequence="ATGCTAGCTAGCTAGCTG", start=3, end=11, concat_seq="GGCTAG"):
    """
    Perform a series of DNA sequence operations.

    Args:
        sequence (str): Input DNA sequence string.
        start (int): Start index for slicing (0-based).
        end (int): End index for slicing (exclusive).
        concat_seq (str): Sequence to concatenate after slicing.

    Returns:
        dict: A dictionary with keys 'original', 'sliced', 'concatenated', 'rna', 'protein'.
    """
    dna_sequence = Seq(sequence)

    # Slice
    sliced_sequence = dna_sequence[start:end]

    # Concatenate
    another_sequence = Seq(concat_seq)
    concatenated_sequence = sliced_sequence + another_sequence

    # Transcribe to RNA
    rna_sequence = concatenated_sequence.transcribe()

    # Translate to protein
    protein_sequence = rna_sequence.translate()

    result = {
        "original": str(dna_sequence),
        "sliced": str(sliced_sequence),
        "concatenated": str(concatenated_sequence),
        "rna": str(rna_sequence),
        "protein": str(protein_sequence),
    }

    return result


def run():
    """Run with default parameters and print results."""
    result = dna_operations()
    print(f"Original Sequence : {result['original']}")
    print(f"Sliced Sequence   : {result['sliced']}")
    print(f"Concatenated      : {result['concatenated']}")
    print(f"RNA Sequence      : {result['rna']}")
    print(f"Protein Sequence  : {result['protein']}")
    return result


if __name__ == "__main__":
    run()
