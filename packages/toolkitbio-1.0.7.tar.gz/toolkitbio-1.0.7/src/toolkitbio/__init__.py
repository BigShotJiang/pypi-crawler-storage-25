"""
toolkitbio - A Bioinformatics Toolkit
====================================

A comprehensive Python toolkit for bioinformatics analysis including:
- DNA sequence operations (slicing, transcription, translation)
- FASTA file reading and parsing
- GenBank file creation and conversion
- Gene annotation management
- NCBI sequence fetching
- Pairwise and multiple sequence alignment
- Phylogenetic tree construction
- PDB protein structure visualization

Usage:
    from toolkitbio import seq_operations, fasta_reader, ncbi_fetch
    
    # Or use the CLI:
    # toolkitbio --help
"""

__version__ = "1.0.0"
__author__ = "ravi"
__email__ = "ravi424e@gmail.com"

from toolkitbio.seq_operations import dna_operations
from toolkitbio.fasta_reader import read_fasta
from toolkitbio.genbank_writer import write_genbank
from toolkitbio.fasta_to_genbank import convert_fasta_to_genbank
from toolkitbio.gene_annotation import annotate_gene
from toolkitbio.ncbi_fetch import fetch_from_ncbi
from toolkitbio.pairwise_align import pairwise_alignment
from toolkitbio.muscle_align import muscle_alignment
from toolkitbio.phylo_tree import build_phylo_tree
from toolkitbio.pdb_viewer import view_pdb_structure

__all__ = [
    "dna_operations",
    "read_fasta",
    "write_genbank",
    "convert_fasta_to_genbank",
    "annotate_gene",
    "fetch_from_ncbi",
    "pairwise_alignment",
    "muscle_alignment",
    "build_phylo_tree",
    "view_pdb_structure",
]
