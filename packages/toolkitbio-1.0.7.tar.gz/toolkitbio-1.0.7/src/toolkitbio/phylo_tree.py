"""
Phylogenetic Tree Module
==========================

Build and visualize phylogenetic trees from multiple sequence alignments.
"""

from Bio import Phylo, AlignIO
from Bio.Phylo.TreeConstruction import DistanceCalculator, DistanceTreeConstructor
import matplotlib.pyplot as plt


def build_phylo_tree(
    alignment_file,
    tree_file="phylogenetic_tree.nwk",
    model="identity",
    method="upgma",
    show_plot=True,
    save_plot=None,
):
    """
    Build a phylogenetic tree from a multiple sequence alignment.

    Args:
        alignment_file (str): Path to aligned FASTA file.
        tree_file (str): Output Newick tree file path.
        model (str): Distance model ('identity', 'blosum62', etc.).
        method (str): Tree construction method ('upgma' or 'nj').
        show_plot (bool): Whether to display the tree plot.
        save_plot (str): If provided, save the tree plot to this path.

    Returns:
        Bio.Phylo.BaseTree.Tree: The constructed phylogenetic tree.
    """
    alignment = AlignIO.read(alignment_file, "fasta")

    # Calculate distance matrix
    calculator = DistanceCalculator(model)
    distance_matrix = calculator.get_distance(alignment)

    # Build tree
    constructor = DistanceTreeConstructor()
    if method == "upgma":
        tree = constructor.upgma(distance_matrix)
    elif method == "nj":
        tree = constructor.nj(distance_matrix)
    else:
        raise ValueError(f"Unknown method: {method}. Use 'upgma' or 'nj'.")

    # Save tree
    Phylo.write(tree, tree_file, "newick")
    print(f"Tree saved: {tree_file}")

    # Visualize
    if show_plot or save_plot:
        fig = plt.figure(figsize=(10, 6))
        ax = fig.add_subplot(1, 1, 1)
        Phylo.draw(tree, axes=ax, do_show=False)
        if save_plot:
            plt.savefig(save_plot, dpi=150, bbox_inches="tight")
            print(f"Plot saved: {save_plot}")
        if show_plot:
            plt.show()
        plt.close()

    return tree


def run(alignment_file, tree_file="phylogenetic_tree.nwk"):
    """Run phylogenetic tree construction."""
    return build_phylo_tree(alignment_file, tree_file)


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2:
        run(sys.argv[1])
    else:
        print("Usage: python phylo_tree.py <aligned_sequences.fasta>")
