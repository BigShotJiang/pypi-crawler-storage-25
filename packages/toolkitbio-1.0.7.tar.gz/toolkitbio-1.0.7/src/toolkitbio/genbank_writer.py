"""
GenBank Writer Module
======================

Create and write GenBank format files from DNA sequences.
"""

from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio import SeqIO


def write_genbank(
    sequence="ATGCGTACGTAGCTAGCTAG",
    seq_id="seq1",
    name="Example_Gene",
    description="Example gene sequence",
    output_file="output.gb",
    molecule_type="DNA",
):
    """
    Create a GenBank file from a DNA sequence.

    Args:
        sequence (str): DNA sequence string.
        seq_id (str): Unique sequence ID.
        name (str): Short name for the sequence.
        description (str): Description of the sequence.
        output_file (str): Output GenBank file path.
        molecule_type (str): Molecule type (DNA/RNA).

    Returns:
        SeqRecord: The written SeqRecord object.
    """
    dna_sequence = Seq(sequence)

    record = SeqRecord(
        dna_sequence,
        id=seq_id,
        name=name,
        description=description,
        annotations={
            "molecule_type": molecule_type,
            "gene": name,
            "function": "Hypothetical protein",
        },
    )

    with open(output_file, "w") as f:
        SeqIO.write(record, f, "genbank")

    print(f"GenBank file written: {output_file}")

    # Read back and verify
    with open(output_file, "r") as f:
        record_read = SeqIO.read(f, "genbank")
        print(f"Verified: {record_read.id} ({len(record_read.seq)} bp)")

    return record


def run():
    """Run with default parameters."""
    return write_genbank()


if __name__ == "__main__":
    run()
