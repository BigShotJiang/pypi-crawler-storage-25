"""
Pairwise Alignment Module
===========================

Perform pairwise sequence alignment between two DNA sequences.
"""

from Bio.Align import PairwiseAligner


def pairwise_alignment(seq1="AGTACACTGGT", seq2="AGTACGCTGGT", mode="global"):
    """
    Perform pairwise alignment of two DNA sequences.

    Args:
        seq1 (str): First DNA sequence.
        seq2 (str): Second DNA sequence.
        mode (str): Alignment mode - 'global' or 'local'.

    Returns:
        dict: Dictionary with 'seq1', 'seq2', 'score', 'alignment_count', and 'best_alignment'.
    """
    aligner = PairwiseAligner()
    aligner.mode = mode
    alignments = aligner.align(seq1, seq2)

    best = alignments[0]

    result = {
        "seq1": seq1,
        "seq2": seq2,
        "score": best.score,
        "alignment_count": len(alignments),
        "best_alignment": str(best),
    }

    return result


def run(seq1="AGTACACTGGT", seq2="AGTACGCTGGT"):
    """Run alignment and print results."""
    result = pairwise_alignment(seq1, seq2)
    print(f"Sequence 1       : {result['seq1']}")
    print(f"Sequence 2       : {result['seq2']}")
    print(f"Score            : {result['score']}")
    print(f"Total alignments : {result['alignment_count']}")
    print(f"\nBest Alignment:\n{result['best_alignment']}")
    return result


if __name__ == "__main__":
    run()
