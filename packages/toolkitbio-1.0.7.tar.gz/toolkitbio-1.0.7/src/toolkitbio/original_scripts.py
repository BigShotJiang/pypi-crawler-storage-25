SCRIPTS = {
    '1': """from Bio.Seq import Seq 
# Step 1: Create a DNA sequence object 
dna_sequence = Seq("ATGCTAGCTAGCTAGCTG") 
# Step 2: Slice the sequence from index 3 to 10 
sliced_sequence = dna_sequence[3:11] 
print("Sliced Sequence:", sliced_sequence) 
# Step 3: Concatenate with another sequence 
another_sequence = Seq("GGCTAG") 
concatenated_sequence = sliced_sequence + another_sequence 
print("Concatenated Sequence:", concatenated_sequence) 
# Step 4: Transcribe the concatenated sequence into RNA 
rna_sequence = concatenated_sequence.transcribe() 
print("RNA Sequence:", rna_sequence) 
# Step 5: Translate the RNA sequence into a protein sequence 
protein_sequence = rna_sequence.translate() 
print("Protein Sequence:", protein_sequence) """,
    '2': """from Bio import SeqIO

# Function to read FASTA file
def read_fasta(file_path):
    # SeqIO.parse() reads multiple sequences
    for record in SeqIO.parse(file_path, "fasta"):
        print(f"Description: {record.description}")
        print(f"Sequence: {record.seq}")
        print()  # blank line between records

# Call the function
fasta_file = r"C:\\Users\\adina\\OneDrive\\Desktop\\bioin\\fasta1.fasta"
read_fasta(fasta_file)""",
    '3': """from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio import SeqIO

# STEP 1: Create DNA sequence
dna_sequence = Seq("ATGCGTACGTAGCTAGCTAG")

# STEP 2: Create SeqRecord (holds sequence + info)
record = SeqRecord(
    dna_sequence,
    id="seq1",                              # unique ID
    name="Example_Gene",                    # short name
    description="Example gene sequence",    # description
    annotations={
        "molecule_type": "DNA",  # REQUIRED for GenBank!
        "gene": "ExampleGene",
        "function": "Hypothetical protein"
    }
)

# STEP 3: Write to GenBank file
output_file = "output.gb"
with open(output_file, "w") as f:
    SeqIO.write(record, f, "genbank")

print("GenBank file written successfully!")

# STEP 4: Read it back and verify
with open(output_file, "r") as f:
    record_read = SeqIO.read(f, "genbank")
    print(record_read)""",
    '4': """from Bio import SeqIO
from Bio.SeqRecord import SeqRecord

def convert_fasta_to_genbank(fasta_file, genbank_file):
    records = []  # store all records
    
    for record in SeqIO.parse(fasta_file, "fasta"):
        # Create new SeqRecord with GenBank annotations
        genbank_record = SeqRecord(
            record.seq,
            id=record.id,
            name="Example_Gene",
            description=record.description,
            annotations={
                "molecule_type": "DNA",  # REQUIRED!
                "gene": "ExampleGene",
                "function": "Hypothetical protein"
            }
        )
        records.append(genbank_record)
    
    # Write ALL records to GenBank
    with open(genbank_file, "w") as output:
        SeqIO.write(records, output, "genbank")
    
    print(f"Converted! Saved as {genbank_file}")

# Run conversion
convert_fasta_to_genbank("fasta1.fasta", "output1.gb")""",
    '5': """from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.SeqFeature import SeqFeature, FeatureLocation

# STEP 1: Create DNA sequence
dna_sequence = Seq("ATGCGTACGTAGCTAGCTAG")

# STEP 2: Create SeqRecord
record = SeqRecord(
    dna_sequence,
    id="seq1",
    name="Example_Gene",
    description="An example DNA sequence for gene annotation."
)

# STEP 3: ADD annotations
record.annotations["gene"] = "ExampleGene"
record.annotations["function"] = "Hypothetical protein"
record.annotations["organism"] = "Synthetic organism"

# STEP 4: ADD feature (gene location: start=0, end=21)
gene_feature = SeqFeature(
    FeatureLocation(0, 21),  # start, end position
    type="gene",
    qualifiers={"gene": "ExampleGene"}
)
record.features.append(gene_feature)

# STEP 5: MODIFY annotation
record.annotations["function"] = "Hypothetical protein with modified function"

# STEP 6: PRINT
print(f"ID: {record.id}")
print(f"Name: {record.name}")
print(f"Description: {record.description}")
print(f"Annotations: {record.annotations}")
print(f"Features: {record.features}")""",
    '6': """from Bio import Entrez, SeqIO

# STEP 1: SET email (NCBI requires this!)
Entrez.email = "your_email@example.com"

# STEP 2: Specify accession number
accession_number = "NM_001301717"

# STEP 3: FETCH from NCBI database
handle = Entrez.efetch(
    db="nucleotide",      # database name
    id=accession_number,  # accession ID
    rettype="gb",         # return type = GenBank
    retmode="text"        # format = text
)

# STEP 4: PARSE the result
seq_record = SeqIO.read(handle, "genbank")

# STEP 5: SHOW the data
print(f"Accession Number: {seq_record.id}")
print(f"Description: {seq_record.description}")
print(f"Organism: {seq_record.annotations['organism']}")
print(f"Sequence: {seq_record.seq}")
print(f"Length: {len(seq_record.seq)}")""",
    '7': """from Bio.Align import PairwiseAligner

# Define two DNA sequences
seq1 = "AGTACACTGGT"
seq2 = "AGTACGCTGGT"

# Create aligner and align
aligner = PairwiseAligner()
alignment = aligner.align(seq1, seq2)

# Print results
print(alignment)
print("Aligned Sequences:")
print(alignment[0])  # first best alignment
print(f"Alignment Score: {alignment[0].score}")""",
    '8': """import subprocess
from Bio import AlignIO

# Path to MUSCLE executable
muscle_exe = r"C:\\Users\\adina\\Downloads\\muscle3.8.31_i86win32.exe"

try:
    # Run MUSCLE alignment
    subprocess.run(
        [muscle_exe, 
         "-in", "fasta1.fasta",   # input file
         "-out", "aligned_sequences.fasta"], # output file
        check=True
    )
    
    # Read the alignment result
    alignment = AlignIO.read("aligned_sequences.fasta", "fasta")
    print(alignment)

except FileNotFoundError:
    print("Error: MUSCLE not found!")
except subprocess.CalledProcessError as e:
    print(f"Error running MUSCLE: {e}")""",
    '9': """from Bio import Phylo, AlignIO
from Bio.Phylo.TreeConstruction import DistanceCalculator, DistanceTreeConstructor
import matplotlib.pyplot as plt

# STEP 1: Load alignment
alignment = AlignIO.read("aligned_sequences.fasta", "fasta")

# STEP 2: Calculate distances between sequences
calculator = DistanceCalculator("identity")
distance_matrix = calculator.get_distance(alignment)

# STEP 3: Build tree using UPGMA method
constructor = DistanceTreeConstructor()
tree = constructor.upgma(distance_matrix)

# STEP 4: Save tree
Phylo.write(tree, "phylogenetic_tree.nwk", "newick")

# STEP 5: Visualize
fig = plt.figure(figsize=(8, 5))
ax = fig.add_subplot(1, 1, 1)
Phylo.draw(tree, axes=ax)
plt.show()""",
    '10': """from Bio.PDB import PDBList, PDBParser
import matplotlib.pyplot as plt
import numpy as np

# Download
PDBList().retrieve_pdb_file("1A3N", pdir=".", file_format="pdb")

# Read
structure = PDBParser(QUIET=True).get_structure("1A3N", "pdb1a3n.ent")

# Get coordinates
atoms = []
for model in structure:
    for chain in model:
        for residue in chain:
            for atom in residue:
                atoms.append(atom.coord)

# Plot 3D
atoms = np.array(atoms)
fig = plt.figure()
ax = fig.add_subplot(111, projection="3d")
ax.scatter(atoms[:,0], atoms[:,1], atoms[:,2], c="blue", s=5)
ax.set_title("3D Structure of 1A3N")
plt.show()""",
}

