"""
MUSCLE Alignment Module
========================

Perform multiple sequence alignment using MUSCLE executable.
Requires MUSCLE to be installed and accessible.
"""

import subprocess
import shutil
from Bio import AlignIO


def muscle_alignment(
    input_fasta,
    output_fasta="aligned_sequences.fasta",
    muscle_exe=None,
):
    """
    Run MUSCLE multiple sequence alignment.

    Args:
        input_fasta (str): Path to input FASTA file.
        output_fasta (str): Path to output aligned FASTA file.
        muscle_exe (str): Path to MUSCLE executable. If None, searches PATH.

    Returns:
        Bio.Align.MultipleSeqAlignment: The alignment result.

    Raises:
        FileNotFoundError: If MUSCLE executable is not found.
        subprocess.CalledProcessError: If MUSCLE fails.
    """
    if muscle_exe is None:
        muscle_exe = shutil.which("muscle")
        if muscle_exe is None:
            raise FileNotFoundError(
                "MUSCLE executable not found. Install MUSCLE or provide the path via muscle_exe parameter."
            )

    subprocess.run(
        [muscle_exe, "-in", input_fasta, "-out", output_fasta],
        check=True,
    )

    alignment = AlignIO.read(output_fasta, "fasta")
    print(f"Aligned {len(alignment)} sequences ({alignment.get_alignment_length()} columns)")
    return alignment


def run(input_fasta, output_fasta="aligned_sequences.fasta", muscle_exe=None):
    """Run MUSCLE alignment and print results."""
    alignment = muscle_alignment(input_fasta, output_fasta, muscle_exe)
    print(alignment)
    return alignment


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2:
        exe = sys.argv[2] if len(sys.argv) > 2 else None
        run(sys.argv[1], muscle_exe=exe)
    else:
        print("Usage: python muscle_align.py <input.fasta> [muscle_exe_path]")
