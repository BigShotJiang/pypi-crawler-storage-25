# create-tawala-app

**A command-line tool to create new Tawala projects with ease.**

## Quickstart

To scaffold a new Tawala project, simply run:

```bash
uvx create-tawala-app my-new-project
```
