"""Ollama backend implementation."""

import json
import logging
import time
from typing import TYPE_CHECKING, Callable

import httpx

from tinychat.backends.base import Backend, serialize_message
from tinychat.errors import BackendError, describe_http_error
from tinychat.models.config import BackendConfig
from tinychat.models.session import ChatSession

if TYPE_CHECKING:
    from tinychat.tools.base import Tool

logger = logging.getLogger(__name__)

HTTP_OK = 200


class OllamaBackend(Backend):
    """Backend for Ollama API."""

    def __init__(self, config: BackendConfig, client: httpx.AsyncClient | None = None):
        """Initialize Ollama backend."""
        self.config = config
        self._owns_client = client is None
        self.client = client or httpx.AsyncClient(
            base_url=config.endpoint,
            timeout=httpx.Timeout(30.0),
            trust_env=False,
        )

    async def aclose(self) -> None:
        """Close HTTP client and cleanup resources."""
        if self._owns_client:
            await self.client.aclose()

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.aclose()

    async def list_models(self) -> list[str]:
        """Return list of available models from Ollama."""
        response = await self.client.get("/api/tags")
        response.raise_for_status()
        data = response.json()
        return [model["name"] for model in data.get("models", [])]

    async def chat(
        self,
        session: ChatSession,
        on_token: Callable[[str], None],
        tools: list["Tool"] | None = None,
    ) -> dict:
        """Stream chat response from Ollama.

        Args:
            session: Chat session with messages
            on_token: Callback for each token streamed
            tools: Optional list of tools the model can call

        Returns:
            dict with 'content' key and optional 'tool_calls' key
        """
        messages = [
            serialize_message(msg)
            for msg in session.messages
            if not msg.metadata.get("compressed")
        ]
        if not messages:
            messages = [
                serialize_message(msg)
                for msg in session.messages
                if msg.role == "system" or msg.metadata.get("summary")
            ]
            if messages:
                logger.warning(
                    "All messages were compressed, falling back to system/summary messages"
                )

        payload: dict = {
            "model": session.model,
            "messages": messages,
            "stream": True,
        }

        if tools:
            payload["tools"] = [tool.to_openai_schema() for tool in tools]

        content_parts: list[str] = []
        tool_calls: list[dict] = []
        start_time = time.perf_counter()

        try:
            await self._process_stream(
                payload,
                session,
                on_token,
                content_parts,
                tool_calls,
            )
        except httpx.HTTPError as e:
            duration_ms = int((time.perf_counter() - start_time) * 1000)
            logger.exception(
                "Chat request failed",
                extra={
                    "backend": self.config.name,
                    "model": session.model,
                    "error": str(e),
                    "duration_ms": duration_ms,
                },
            )
            msg = f"Chat request failed: {describe_http_error(e)}"
            raise BackendError(
                msg,
                backend_name=self.config.name,
                original_error=e,
            ) from e

        duration_ms = int((time.perf_counter() - start_time) * 1000)
        logger.info(
            "Stream completed",
            extra={
                "backend": self.config.name,
                "model": session.model,
                "tokens": len(content_parts),
                "duration_ms": duration_ms,
            },
        )

        result: dict = {"content": "".join(content_parts)}
        if tool_calls:
            result["tool_calls"] = tool_calls
        return result

    async def _process_stream(
        self,
        payload: dict,
        session: ChatSession,
        on_token: Callable[[str], None],
        content_parts: list[str],
        tool_calls: list[dict],
    ) -> None:
        async with self.client.stream(
            "POST",
            "/api/chat",
            json=payload,
        ) as response:
            async for line in response.aiter_lines():
                if line:
                    try:
                        self._process_stream_line(
                            line,
                            on_token,
                            content_parts,
                            tool_calls,
                        )
                    except json.JSONDecodeError:
                        pass

    @staticmethod
    def _process_stream_line(
        line: str,
        on_token: Callable[[str], None],
        content_parts: list[str],
        tool_calls: list[dict],
    ) -> None:
        data = json.loads(line)
        if "message" not in data:
            return
        msg = data["message"]
        if "content" in msg and msg["content"]:
            token = msg["content"]
            on_token(token)
            content_parts.append(token)
        if "tool_calls" in msg:
            tool_calls.extend(msg["tool_calls"])

    async def test_connection(self) -> bool:
        """Test if Ollama backend is reachable."""
        try:
            response = await self.client.get("/api/tags")
            return response.status_code == HTTP_OK
        except httpx.HTTPError:
            return False

    def get_info(self) -> dict:
        """Return backend metadata."""
        return {
            "name": self.config.name,
            "type": self.config.type,
            "endpoint": self.config.endpoint,
            "default_model": self.config.default_model,
        }
