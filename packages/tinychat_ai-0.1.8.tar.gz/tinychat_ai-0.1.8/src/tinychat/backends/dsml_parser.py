"""DeepSeek DSML (DeepSeek Markup Language) tool call parser.

Parses DSML-format tool calls from model content into OpenAI-compatible
tool_calls structure.  Supports two parameter formats:

  Format 1 - XML Parameter Tags:
    <｜DSML｜function_calls>
    <｜DSML｜invoke name="fn">
      <｜DSML｜parameter name="x" string="true">val</｜DSML｜parameter>
    </｜DSML｜invoke>
    </｜DSML｜function_calls>

  Format 2 - Direct JSON:
    <｜DSML｜function_calls>
    <｜DSML｜invoke name="fn">
      {"x": "val"}
    </｜DSML｜invoke>
    </｜DSML｜function_calls>
"""

import json
import logging
import re
import uuid
from typing import Any

logger = logging.getLogger(__name__)

_START_TAG = "<｜DSML｜function_calls>"
_END_TAG = "</｜DSML｜function_calls>"

_RE_BLOCK = re.compile(rf"{re.escape(_START_TAG)}(.*?){re.escape(_END_TAG)}", re.DOTALL)
_RE_INVOKE = re.compile(
    r'<｜DSML｜invoke\s+name="([^"]+)"\s*>(.*?)</｜DSML｜invoke>',
    re.DOTALL,
)
_RE_PARAM_XML = re.compile(
    r'<｜DSML｜parameter\s+name="([^"]+)"'
    r'\s+string="(?:true|false)"\s*>(.*?)</｜DSML｜parameter>',
    re.DOTALL,
)


class DSMLParseResult:
    __slots__ = ("has_tool_calls", "content", "tool_calls")

    def __init__(
        self,
        has_tool_calls: bool,
        content: str | None,
        tool_calls: list[dict],
    ):
        self.has_tool_calls = has_tool_calls
        self.content = content
        self.tool_calls = tool_calls


def _generate_call_id() -> str:
    return f"call_{uuid.uuid4().hex[:24]}"


def _parse_invoke_params(invoke_body: str) -> dict[str, str]:
    xml_params: dict[str, str] = {}
    for name, value in _RE_PARAM_XML.findall(invoke_body):
        xml_params[name] = value
    if xml_params:
        return xml_params

    stripped = invoke_body.strip()
    if stripped.startswith("{"):
        try:
            parsed = json.loads(stripped)
            if isinstance(parsed, dict):
                return {
                    k: json.dumps(v, ensure_ascii=False)
                    if not isinstance(v, str)
                    else v
                    for k, v in parsed.items()
                }
        except json.JSONDecodeError:
            pass

    return {}


def _convert_param_value(value: str, param_type: str) -> Any:
    if value.lower() == "null":
        return None
    t = param_type.lower()
    if t in ("string", "str", "text"):
        return value
    if t in ("integer", "int"):
        return _try_convert_int(value)
    if t in ("number", "float"):
        return _try_convert_float(value)
    if t in ("boolean", "bool"):
        return value.lower() in ("true", "1")
    if t in ("object", "array"):
        return _try_parse_json(value)
    return _try_parse_json(value)


def _try_convert_int(value: str) -> int | str:
    try:
        return int(value)
    except (ValueError, TypeError):
        return value


def _try_convert_float(value: str) -> int | float | str:
    try:
        val = float(value)
        return int(val) if val == int(val) else val
    except (ValueError, TypeError):
        return value


def _try_parse_json(value: str) -> Any:
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return value


def _convert_params_with_schema(
    function_name: str,
    raw_params: dict[str, str],
    tools: list[dict] | None,
) -> dict[str, Any]:
    schema_props: dict[str, Any] = {}
    if tools:
        for tool in tools:
            func = tool.get("function", {})
            if func.get("name") == function_name:
                params = func.get("parameters", {})
                if isinstance(params, dict):
                    schema_props = params.get("properties", {})
                break

    converted: dict[str, Any] = {}
    for name, value in raw_params.items():
        ptype = "string"
        if name in schema_props and isinstance(schema_props[name], dict):
            ptype = schema_props[name].get("type", "string")
        converted[name] = _convert_param_value(value, ptype)
    return converted


def extract_tool_calls(
    content: str,
    tools: list[dict] | None = None,
) -> DSMLParseResult:
    if _START_TAG not in content:
        return DSMLParseResult(has_tool_calls=False, content=content, tool_calls=[])

    try:
        tool_calls: list[dict] = []
        for block in _RE_BLOCK.findall(content):
            for invoke_name, invoke_body in _RE_INVOKE.findall(block):
                raw = _parse_invoke_params(invoke_body)
                converted = _convert_params_with_schema(invoke_name, raw, tools)
                tool_calls.append(
                    {
                        "id": _generate_call_id(),
                        "type": "function",
                        "function": {
                            "name": invoke_name,
                            "arguments": json.dumps(converted, ensure_ascii=False),
                        },
                    },
                )

        if not tool_calls:
            return DSMLParseResult(has_tool_calls=False, content=content, tool_calls=[])

        idx = content.find(_START_TAG)
        normal_text = content[:idx] if idx > 0 else None
        return DSMLParseResult(
            has_tool_calls=True,
            content=normal_text,
            tool_calls=tool_calls,
        )
    except Exception:
        logger.exception("Error parsing DSML tool calls")
        return DSMLParseResult(has_tool_calls=False, content=content, tool_calls=[])


class DSMLStreamBuffer:
    """Buffers streaming content tokens and detects DSML tool calls.

    Tokens pass through immediately unless a potential DSML start tag
    prefix is detected, in which case buffering begins to avoid
    flashing raw DSML markup to the user.

    Usage::

        buf = DSMLStreamBuffer()
        for token in stream:
            action = buf.feed(token)
            if action == "display":
                show_to_user(token)
            elif action == "suppress":
                pass  # DSML content, will be parsed later
        result = buf.finalize(tools_schema)
    """

    def __init__(self) -> None:
        self._buffer: list[str] = []
        self._dsml_started: bool = False
        self._dsml_ended: bool = False
        self._pre_dsml: list[str] = []
        self._buffering: bool = False

    @staticmethod
    def _longest_prefix_match(text: str) -> int:
        for i in range(min(len(text), len(_START_TAG)), 0, -1):
            if _START_TAG[:i] == text[:i]:
                return i
        return 0

    def feed(self, token: str) -> str:
        if self._dsml_ended:
            return "suppress"

        if self._dsml_started:
            self._buffer.append(token)
            accumulated = "".join(self._buffer)
            if _END_TAG in accumulated:
                self._dsml_ended = True
            return "suppress"

        self._buffer.append(token)
        accumulated = "".join(self._buffer)

        if _START_TAG in accumulated:
            self._dsml_started = True
            self._buffering = False
            idx = accumulated.find(_START_TAG)
            pre = accumulated[:idx]
            if pre:
                self._pre_dsml.append(pre)
            self._buffer = [accumulated[idx:]]
            return "display" if pre else "suppress"

        prefix_len = self._longest_prefix_match(accumulated)
        if prefix_len > 0:
            self._buffering = True
            safe_end = len(accumulated) - prefix_len
            if safe_end > 0:
                to_emit = accumulated[:safe_end]
                self._buffer = [accumulated[safe_end:]]
                self._pre_dsml.append(to_emit)
                return "display" if to_emit else "suppress"
            return "suppress"

        if self._buffering:
            self._buffering = False

        to_emit = accumulated
        self._buffer = []
        self._pre_dsml.append(to_emit)
        return "display" if to_emit else "suppress"

    def finalize(self, tools: list[dict] | None = None) -> DSMLParseResult:
        full = "".join(self._buffer)
        pre_text = "".join(self._pre_dsml)
        full = pre_text + full

        if not self._dsml_started:
            return DSMLParseResult(has_tool_calls=False, content=full, tool_calls=[])

        return extract_tool_calls(full, tools)

    def reset(self) -> None:
        self._buffer.clear()
        self._dsml_started = False
        self._dsml_ended = False
        self._pre_dsml.clear()
