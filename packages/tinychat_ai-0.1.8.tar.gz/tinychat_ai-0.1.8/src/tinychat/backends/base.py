"""Abstract backend interface."""

import json
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Callable

from tinychat.models.session import ChatSession

if TYPE_CHECKING:
    from tinychat.models.message import Message
    from tinychat.tools.base import Tool


class Backend(ABC):
    """Abstract base class for LLM backends."""

    @abstractmethod
    async def list_models(self) -> list[str]:
        """Return list of available model names."""

    @abstractmethod
    async def chat(
        self,
        session: ChatSession,
        on_token: Callable[[str], None],
        tools: list["Tool"] | None = None,
    ) -> dict:
        """Stream chat response, calling on_token for each chunk.

        Args:
            session: Chat session with messages
            on_token: Callback for each token streamed
            tools: Optional list of tools the model can call

        Returns:
            dict with 'content' key and optional 'tool_calls' key
        """

    @abstractmethod
    async def test_connection(self) -> bool:
        """Verify backend is reachable."""

    @abstractmethod
    def get_info(self) -> dict:
        """Return backend metadata."""


def serialize_message(msg: "Message") -> dict[str, Any]:
    """Serialize a Message to a dict for API requests.

    Args:
        msg: The message to serialize

    Returns:
        dict with role, content, and optional tool_call_id/tool_calls/reasoning_content
    """

    result: dict[str, Any] = {"role": msg.role, "content": msg.content}

    if msg.role == "tool" and msg.tool_call_id:
        result["tool_call_id"] = msg.tool_call_id

    if msg.tool_calls:
        result["tool_calls"] = [_serialize_tool_call(tc) for tc in msg.tool_calls]

    # Include reasoning_content for assistant messages.
    # DeepSeek API: non-tool-call rounds can omit it (ignored by API),
    # but tool-call rounds MUST include it in subsequent requests.
    # Always including it is safe and simplifies logic.
    if msg.role == "assistant" and msg.reasoning_content is not None:
        result["reasoning_content"] = msg.reasoning_content

    return result


def _serialize_tool_call(tc: Any) -> dict[str, Any]:
    """Normalize a tool call to OpenAI-compatible format."""
    if not isinstance(tc, dict):
        return {
            "id": tc.id,
            "type": "function",
            "function": {
                "name": tc.name,
                "arguments": json.dumps(tc.arguments),
            },
        }
    func = tc.get("function")
    if isinstance(func, dict) and "name" in func:
        return {
            "id": tc.get("id", ""),
            "type": "function",
            "function": {
                "name": func.get("name", ""),
                "arguments": func.get("arguments", "{}"),
            },
        }
    return {
        "id": tc.get("id", ""),
        "type": "function",
        "function": {
            "name": tc.get("name", ""),
            "arguments": json.dumps(tc.get("arguments", {})),
        },
    }
