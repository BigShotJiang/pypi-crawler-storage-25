"""OpenAI-compatible backend implementation."""

import json
import logging
import time
from typing import TYPE_CHECKING, Callable

import httpx

from tinychat.backends.base import Backend, serialize_message
from tinychat.backends.dsml_parser import DSMLStreamBuffer
from tinychat.errors import BackendError, describe_http_error
from tinychat.models.config import BackendConfig
from tinychat.models.session import ChatSession

if TYPE_CHECKING:
    from tinychat.tools.base import Tool

logger = logging.getLogger(__name__)

HTTP_OK = 200
MAX_ERROR_TEXT_LENGTH = 200


class OpenAIBackend(Backend):
    """OpenAI-compatible backend implementation."""

    def __init__(self, config: BackendConfig, client: httpx.AsyncClient | None = None):
        """Initialize OpenAI backend."""
        self.config = config
        self._owns_client = client is None
        self.client = client or httpx.AsyncClient(
            base_url=config.endpoint,
            timeout=httpx.Timeout(30.0),
            trust_env=False,
        )
        self.api_key = config.api_key

        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        self.client.headers.update(headers)

    async def aclose(self) -> None:
        """Close HTTP client and cleanup resources."""
        if self._owns_client:
            await self.client.aclose()

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.aclose()

    async def list_models(self) -> list[str]:
        """Return list of available models from OpenAI API."""
        response = await self.client.get("/models")
        response.raise_for_status()
        data = response.json()
        return [model["id"] for model in data.get("data", [])]

    async def chat(
        self,
        session: ChatSession,
        on_token: Callable[[str], None],
        tools: list["Tool"] | None = None,
    ) -> dict:
        """Stream chat response from OpenAI-compatible API.

        Args:
            session: Chat session with messages
            on_token: Callback for each token streamed
            tools: Optional list of tools the model can call

        Returns:
            dict with 'content' key and optional 'tool_calls' key
        """
        messages = [
            serialize_message(msg)
            for msg in session.messages
            if not msg.metadata.get("compressed")
        ]
        if not messages:
            messages = [
                serialize_message(msg)
                for msg in session.messages
                if msg.role == "system" or msg.metadata.get("summary")
            ]
            if messages:
                logger.warning(
                    "All messages were compressed, falling back to system/summary messages"
                )

        payload: dict = {
            "model": session.model,
            "messages": messages,
            "stream": True,
        }

        if tools:
            payload["tools"] = [tool.to_openai_schema() for tool in tools]

        # DeepSeek thinking mode support
        # reasoning_effort: controls thinking depth (high/max)
        # thinking: { "type": "enabled/disabled" }
        session_params = session.parameters or {}
        if "reasoning_effort" in session_params:
            payload["reasoning_effort"] = session_params["reasoning_effort"]
        if "thinking" in session_params:
            payload["thinking"] = session_params["thinking"]

        # Merge session-level extra_body into payload top-level
        session_extra = session_params.get("extra_body", {})
        for key, value in session_extra.items():
            payload[key] = value

        # Auto-enable thinking mode for DeepSeek V4 models
        model_lower = session.model.lower()
        if "deepseek-v4" in model_lower or "deepseek-reasoner" in model_lower:
            if "thinking" not in session_params and "thinking" not in session_extra:
                payload["thinking"] = {"type": "enabled"}
            if "reasoning_effort" not in session_params:
                payload["reasoning_effort"] = "high"

        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        content_parts: list[str] = []
        tool_calls_map: dict[int, dict] = {}
        dsml_buffer = DSMLStreamBuffer()
        tools_schema = [tool.to_openai_schema() for tool in tools] if tools else None
        start_time = time.perf_counter()

        try:
            await self._process_stream(
                payload,
                headers,
                session,
                on_token,
                content_parts,
                tool_calls_map,
                dsml_buffer,
            )
        except httpx.HTTPError as e:
            duration_ms = int((time.perf_counter() - start_time) * 1000)
            logger.exception(
                "Chat request failed",
                extra={
                    "backend": self.config.name,
                    "model": session.model,
                    "error": str(e),
                    "duration_ms": duration_ms,
                },
            )
            msg = f"Chat request failed: {describe_http_error(e)}"
            raise BackendError(
                msg,
                backend_name=self.config.name,
                original_error=e,
            ) from e

        duration_ms = int((time.perf_counter() - start_time) * 1000)

        # Extract and clean accumulated reasoning content from session parameters
        reasoning_buf = session.parameters.pop("_reasoning_buffer", None)
        reasoning_content = "".join(reasoning_buf) if reasoning_buf else None

        logger.info(
            "Stream completed",
            extra={
                "backend": self.config.name,
                "model": session.model,
                "tokens": len(content_parts),
                "duration_ms": duration_ms,
                "has_reasoning": reasoning_content is not None,
            },
        )

        result: dict = {"content": "".join(content_parts)}
        if reasoning_content is not None:
            result["reasoning_content"] = reasoning_content
        if tool_calls_map:
            tool_calls = [tool_calls_map[i] for i in sorted(tool_calls_map.keys())]
            result["tool_calls"] = tool_calls
        else:
            dsml_result = dsml_buffer.finalize(tools_schema)
            if dsml_result.has_tool_calls:
                result["content"] = dsml_result.content or ""
                result["tool_calls"] = dsml_result.tool_calls
        return result

    async def _process_stream(
        self,
        payload: dict,
        headers: dict,
        session: ChatSession,
        on_token: Callable[[str], None],
        content_parts: list[str],
        tool_calls_map: dict[int, dict],
        dsml_buffer: DSMLStreamBuffer,
    ) -> None:
        async with self.client.stream(
            "POST",
            "/chat/completions",
            json=payload,
            headers=headers,
        ) as response:
            if response.status_code != HTTP_OK:
                error_text = await response.aread()
                msg = f"API error {response.status_code}: {error_text[:MAX_ERROR_TEXT_LENGTH]}"
                raise BackendError(
                    msg,
                    backend_name=self.config.name,
                    original_error=None,
                )

            async for line in response.aiter_lines():
                if line:
                    try:
                        await self._process_stream_line(
                            line,
                            session,
                            on_token,
                            content_parts,
                            tool_calls_map,
                            dsml_buffer,
                        )
                    except BackendError:
                        raise
                    except json.JSONDecodeError:
                        logger.warning(
                            "Invalid JSON in stream: %s",
                            line[:100],
                            extra={
                                "backend": self.config.name,
                                "model": session.model,
                            },
                        )

    async def _process_stream_line(
        self,
        line: str,
        session: ChatSession,
        on_token: Callable[[str], None],
        content_parts: list[str],
        tool_calls_map: dict[int, dict],
        dsml_buffer: DSMLStreamBuffer,
    ) -> None:
        line = line.strip()
        if line.startswith("data: "):
            line = line[6:]
        if line == "[DONE]":
            return

        data = json.loads(line)
        if "choices" not in data or len(data["choices"]) == 0:
            return

        delta = data["choices"][0].get("delta", {})
        if "tool_calls" in delta:
            self._update_tool_calls_map(tool_calls_map, delta["tool_calls"])

        # Capture reasoning_content (DeepSeek thinking mode)
        reasoning_delta = delta.get("reasoning_content")
        if reasoning_delta is not None:
            # Accumulate reasoning content in session parameters
            reasoning_buf = session.parameters.get("_reasoning_buffer")
            if reasoning_buf is None:
                reasoning_buf = []
                session.parameters["_reasoning_buffer"] = reasoning_buf
            reasoning_buf.append(reasoning_delta)

        if "content" in delta and delta["content"]:
            token_text = delta["content"]
            action = dsml_buffer.feed(token_text)
            if action == "display":
                on_token(token_text)
            content_parts.append(token_text)
        elif "error" in data:
            error_msg = data["error"].get("message", "Unknown error")
            msg = f"API error in stream: {error_msg}"
            raise BackendError(
                msg,
                backend_name=self.config.name,
                original_error=None,
            )

    @staticmethod
    def _update_tool_calls_map(
        tool_calls_map: dict[int, dict],
        tc_deltas: list[dict],
    ) -> None:
        for tc_delta in tc_deltas:
            idx = tc_delta.get("index", 0)
            if idx not in tool_calls_map:
                tool_calls_map[idx] = {
                    "id": tc_delta.get("id", ""),
                    "type": tc_delta.get("type", "function"),
                    "function": {"name": "", "arguments": ""},
                }
            if "id" in tc_delta:
                tool_calls_map[idx]["id"] = tc_delta["id"]
            if "function" in tc_delta:
                fn = tc_delta["function"]
                if "name" in fn:
                    tool_calls_map[idx]["function"]["name"] = fn["name"]
                if "arguments" in fn:
                    tool_calls_map[idx]["function"]["arguments"] += fn["arguments"]

    async def test_connection(self) -> bool:
        """Test if OpenAI backend is reachable."""
        try:
            response = await self.client.get("/models")
            return response.status_code == HTTP_OK
        except httpx.HTTPError:
            return False

    def get_info(self) -> dict:
        """Return backend metadata."""
        return {
            "name": self.config.name,
            "type": self.config.type,
            "endpoint": self.config.endpoint,
            "default_model": self.config.default_model,
            "api_key": self.config.api_key,
        }
