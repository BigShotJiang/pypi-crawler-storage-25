"""Storybook TUI - Component preview system for TinyChat."""

from .registry import Story, clear, get_all_stories, get_groups, register
from .canvas import StoryCanvas
from .app import StorybookApp

# Import story modules to ensure they are registered
# This must be after the registry imports so register() is available
from .stories import (  # noqa: F401
    message_widgets,
    status_bar,
    input_area,
    sidebar,
    rename_dialog,
    message_action_screen,
    session_list_dialog,
)

__all__ = [
    "Story",
    "clear",
    "get_all_stories",
    "get_groups",
    "register",
    "StoryCanvas",
    "StorybookApp",
]
