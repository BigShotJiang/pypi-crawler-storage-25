"""Stories for Command Palette component."""

from tinychat.storybook.registry import Story, register
from tinychat.storybook.dialog_preview import DialogPreview
from tinychat.components.command_palette import CommandPaletteScreen
from tinychat.utils.i18n import _


# Extended command list for Storybook demonstration
EXTENDED_COMMANDS = [
    # Session management
    {
        "name": "/new",
        "description": _("Create new session"),
        "category": "session",
        "icon": "➕",
    },
    {
        "name": "/sessions",
        "description": _("Manage sessions"),
        "category": "session",
        "icon": "📋",
    },
    {
        "name": "/clear",
        "description": _("Clear current conversation"),
        "category": "session",
        "icon": "🗑️",
    },
    {
        "name": "/rename",
        "description": _("Rename current session"),
        "category": "session",
        "icon": "✏️",
    },
    # System features
    {
        "name": "/compact",
        "description": _("Compact conversation history"),
        "category": "system",
        "icon": "📦",
    },
    {
        "name": "/theme",
        "description": _("Switch theme (dark/light)"),
        "category": "system",
        "icon": "🎨",
    },
    {
        "name": "/lang",
        "description": _("Switch language"),
        "category": "system",
        "icon": "🌐",
    },
    {
        "name": "/settings",
        "description": _("Open settings"),
        "category": "system",
        "icon": "⚙️",
    },
    # Tools and backends
    {
        "name": "/tools",
        "description": _("Manage tools"),
        "category": "tools",
        "icon": "🛠️",
    },
    {
        "name": "/backend",
        "description": _("Switch backend"),
        "category": "tools",
        "icon": "🔌",
    },
    {
        "name": "/model",
        "description": _("Switch model"),
        "category": "tools",
        "icon": "🤖",
    },
    # Help
    {
        "name": "/help",
        "description": _("Show help"),
        "category": "help",
        "icon": "❓",
    },
    {
        "name": "/shortcuts",
        "description": _("Show keyboard shortcuts"),
        "category": "help",
        "icon": "⌨️",
    },
    {
        "name": "/version",
        "description": _("Show version info"),
        "category": "help",
        "icon": "ℹ️",
    },
    # Exit
    {
        "name": "/quit",
        "description": _("Exit application"),
        "category": "system",
        "icon": "🚪",
    },
]


class _StoryCommandPaletteScreen(CommandPaletteScreen):
    """Command palette screen for storybook with pre-loaded commands."""

    def __init__(self, commands: list, filter_text: str = ""):
        super().__init__()
        self._story_commands = commands
        self._story_filter = filter_text

    async def _load_commands(self) -> None:
        """Load commands from story data."""
        self.commands = self._story_commands
        await self._update_list(self._story_filter)


def _command_palette_basic() -> Story:
    """Basic command palette with all available commands."""

    def make_screen() -> CommandPaletteScreen:
        return _StoryCommandPaletteScreen(EXTENDED_COMMANDS)

    return Story(
        group="Command Palette",
        title="Basic",
        description="Command palette showing all 15 available slash commands.",
        build=lambda: DialogPreview(make_screen),
    )


def _command_palette_filtered() -> Story:
    """Command palette with filter text applied."""

    def make_screen() -> CommandPaletteScreen:
        return _StoryCommandPaletteScreen(EXTENDED_COMMANDS, filter_text="compact")

    return Story(
        group="Command Palette",
        title="Filtered",
        description="Command palette with 'compact' filter text pre-filled.",
        build=lambda: DialogPreview(make_screen),
    )


def _command_palette_empty() -> Story:
    """Command palette with no matching results."""

    def make_screen() -> CommandPaletteScreen:
        return _StoryCommandPaletteScreen(EXTENDED_COMMANDS, filter_text="xyz")

    return Story(
        group="Command Palette",
        title="Empty Results",
        description="Command palette showing no results for unmatched filter.",
        build=lambda: DialogPreview(make_screen),
    )


def _command_palette_session_category() -> Story:
    """Command palette filtered to session commands."""

    def make_screen() -> CommandPaletteScreen:
        return _StoryCommandPaletteScreen(EXTENDED_COMMANDS, filter_text="session")

    return Story(
        group="Command Palette",
        title="Session Commands",
        description="Showing session management commands (/new, /sessions, /clear, /rename).",
        build=lambda: DialogPreview(make_screen),
    )


def _command_palette_tools_category() -> Story:
    """Command palette filtered to tools and backend commands."""

    def make_screen() -> CommandPaletteScreen:
        return _StoryCommandPaletteScreen(EXTENDED_COMMANDS, filter_text="tool")

    return Story(
        group="Command Palette",
        title="Tools Commands",
        description="Showing tools and backend commands (/tools, /backend, /model).",
        build=lambda: DialogPreview(make_screen),
    )


def _command_palette_help_category() -> Story:
    """Command palette filtered to help commands."""

    def make_screen() -> CommandPaletteScreen:
        return _StoryCommandPaletteScreen(EXTENDED_COMMANDS, filter_text="help")

    return Story(
        group="Command Palette",
        title="Help Commands",
        description="Showing help-related commands (/help, /shortcuts, /version).",
        build=lambda: DialogPreview(make_screen),
    )


register(
    _command_palette_basic(),
    _command_palette_filtered(),
    _command_palette_empty(),
    _command_palette_session_category(),
    _command_palette_tools_category(),
    _command_palette_help_category(),
)
