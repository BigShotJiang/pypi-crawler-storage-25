"""Stories for RenameSessionScreen dialog."""

from tinychat.storybook.registry import Story, register
from tinychat.storybook.dialog_preview import DialogPreview
from tinychat.components.rename_dialog import RenameSessionScreen


def _rename_dialog_default() -> Story:
    """Rename dialog with default session title."""

    def make_screen() -> RenameSessionScreen:
        return RenameSessionScreen(
            session_id="session_123",
            current_title="My Chat Session",
        )

    return Story(
        group="Dialogs",
        title="Rename Dialog - Default",
        description="Dialog to rename a chat session with pre-filled input.",
        build=lambda: DialogPreview(make_screen),
    )


def _rename_dialog_long_title() -> Story:
    """Rename dialog with a long existing title."""

    def make_screen() -> RenameSessionScreen:
        return RenameSessionScreen(
            session_id="session_456",
            current_title="A Very Long Session Title That Should Be Truncated",
        )

    return Story(
        group="Dialogs",
        title="Rename Dialog - Long Title",
        description="Shows how the dialog handles long pre-filled titles.",
        build=lambda: DialogPreview(make_screen),
    )


register(
    _rename_dialog_default(),
    _rename_dialog_long_title(),
)
