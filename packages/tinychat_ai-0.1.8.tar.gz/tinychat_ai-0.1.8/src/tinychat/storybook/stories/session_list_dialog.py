"""Story for SessionListDialog (session management UI)."""

from datetime import datetime, timedelta

from tinychat.storybook.registry import Story, register
from tinychat.storybook.dialog_preview import DialogPreview
from tinychat.components.session_list_dialog import SessionListScreen
from tinychat.models.session import SessionSummary


def _session_list_dialog() -> Story:
    """Session list dialog with multiple sample sessions."""
    now = datetime.now()
    sessions = [
        SessionSummary(
            id="sid-001",
            title="Introduction to TinyChat",
            backend_name="ollama",
            model="llama2",
            created_at=now - timedelta(days=2),
            updated_at=now - timedelta(minutes=10),
            message_count=8,
        ),
        SessionSummary(
            id="sid-002",
            title="Python Code Help",
            backend_name="openai",
            model="gpt-4",
            created_at=now - timedelta(days=1),
            updated_at=now - timedelta(hours=2),
            message_count=12,
        ),
        SessionSummary(
            id="sid-003",
            title="Testing Session",
            backend_name="ollama",
            model="mistral",
            created_at=now - timedelta(hours=3),
            updated_at=now - timedelta(hours=1),
            message_count=4,
        ),
    ]

    def make_screen() -> SessionListScreen:
        return SessionListScreen(sessions=sessions, session_manager=None)

    return Story(
        group="Dialogs",
        title="Session List",
        description="Dialog for managing and switching between chat sessions.",
        build=lambda: DialogPreview(make_screen),
    )


register(_session_list_dialog())
