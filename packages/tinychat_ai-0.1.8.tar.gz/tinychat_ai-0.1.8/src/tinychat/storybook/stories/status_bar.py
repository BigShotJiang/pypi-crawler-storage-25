"""Stories for StatusBar component in various states."""

from tinychat.storybook.registry import Story, register
from tinychat.components.status_bar import StatusBar


def _status_idle() -> Story:
    return Story(
        group="Status Bar",
        title="Idle",
        description="Default status when nothing is happening.",
        build=lambda: StatusBar(),
    )


def _status_loading() -> Story:
    s = StatusBar()
    s.status = "loading"
    return Story(
        group="Status Bar",
        title="Loading",
        description="Shown while loading a model or connecting.",
        build=lambda: s,
    )


def _status_streaming() -> Story:
    s = StatusBar()
    s.status = "streaming"
    s.backend_name = "ollama-local"
    s.model = "llama2"
    return Story(
        group="Status Bar",
        title="Streaming",
        description="Active response streaming with backend info.",
        build=lambda: s,
    )


def _status_success() -> Story:
    s = StatusBar()
    s.status = "success"
    s.backend_name = "openai"
    s.model = "gpt-4"
    s.response_time = 1.23
    return Story(
        group="Status Bar",
        title="Success",
        description="Operation completed successfully with metrics.",
        build=lambda: s,
    )


def _status_error() -> Story:
    s = StatusBar()
    s.status = "error"
    s.error_message = "Connection timeout"
    s.connection_status = "disconnected"
    return Story(
        group="Status Bar",
        title="Error",
        description="Displays an error condition.",
        build=lambda: s,
    )


def _status_with_todo() -> Story:
    s = StatusBar()
    s.todo_progress = "3/5"
    s.backend_name = "ollama"
    s.model = "mistral"
    return Story(
        group="Status Bar",
        title="With Todo Progress",
        description="Shows tool execution progress.",
        build=lambda: s,
    )


def _status_generating() -> Story:
    s = StatusBar()
    s.is_generating = True
    s.status = "streaming"
    s.tokens_per_second = 42.5
    return Story(
        group="Status Bar",
        title="Generating",
        description="Shows generating state with speed.",
        build=lambda: s,
    )


register(
    _status_idle(),
    _status_loading(),
    _status_streaming(),
    _status_success(),
    _status_error(),
    _status_with_todo(),
    _status_generating(),
)
