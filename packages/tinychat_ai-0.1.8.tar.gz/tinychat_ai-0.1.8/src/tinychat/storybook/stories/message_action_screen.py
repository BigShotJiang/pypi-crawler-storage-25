"""Stories for MessageActionScreen dialog."""

from tinychat.storybook.registry import Story, register
from tinychat.storybook.dialog_preview import DialogPreview
from tinychat.components.message_action_screen import MessageActionScreen


def _message_action_user() -> Story:
    """Actions for a user message (Delete and Copy available)."""

    def make_screen() -> MessageActionScreen:
        return MessageActionScreen(
            message_index=1,
            role="user",
            content="What is TinyChat?",
        )

    return Story(
        group="Dialogs",
        title="Message Actions - User",
        description="Shows Fork (hidden), Delete, and Copy for user messages.",
        build=lambda: DialogPreview(make_screen),
    )


def _message_action_assistant_last() -> Story:
    """Actions for the last assistant message (all buttons visible)."""

    def make_screen() -> MessageActionScreen:
        return MessageActionScreen(
            message_index=2,
            role="assistant",
            is_last_assistant=True,
            content="TinyChat is a terminal AI chat application.",
        )

    return Story(
        group="Dialogs",
        title="Message Actions - Assistant (Last)",
        description="Shows Fork, Regenerate, Copy for last assistant message.",
        build=lambda: DialogPreview(make_screen),
    )


def _message_action_assistant_not_last() -> Story:
    """Actions for an assistant message that is not the last (no Regenerate)."""

    def make_screen() -> MessageActionScreen:
        return MessageActionScreen(
            message_index=4,
            role="assistant",
            is_last_assistant=False,
            content="Earlier assistant response.",
        )

    return Story(
        group="Dialogs",
        title="Message Actions - Assistant (Not Last)",
        description="Shows Fork and Copy, but Regenerate hidden.",
        build=lambda: DialogPreview(make_screen),
    )


register(
    _message_action_user(),
    _message_action_assistant_last(),
    _message_action_assistant_not_last(),
)
