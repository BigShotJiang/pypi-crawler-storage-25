"""Stories for Sidebar component in various modes."""

from tinychat.storybook.registry import Story, register
from tinychat.components.sidebar import Sidebar


def _sidebar_backend_selection() -> Story:
    """Sidebar in backend selection mode with multiple backends."""

    def make() -> Sidebar:
        s = Sidebar(backends=["ollama-local", "openai-compatible", "custom-api"])
        s.available_models = ["llama2", "mistral", "gpt-4"]
        s.selected_model = "llama2"
        s.selected_backend_idx = 0
        s.todos = []
        return s

    return Story(
        group="Sidebar",
        title="Backend Selection",
        description="Shows available backends and models.",
        build=make,
    )


def _sidebar_with_todos() -> Story:
    """Sidebar displaying todo tasks."""

    def make() -> Sidebar:
        s = Sidebar(backends=["ollama-local"])
        s.available_models = ["llama2"]
        s.todos = [
            {"content": "Implement feature X", "status": "pending", "priority": "high"},
            {
                "content": "Fix bug in parser",
                "status": "in_progress",
                "priority": "medium",
            },
            {
                "content": "Write documentation",
                "status": "completed",
                "priority": "low",
            },
        ]
        return s

    return Story(
        group="Sidebar",
        title="With Todos",
        description="Sidebar showing tool execution tasks.",
        build=make,
    )


def _sidebar_navigation_mode() -> Story:
    """Sidebar in navigation mode showing chat history questions."""

    def make() -> Sidebar:
        s = Sidebar()
        s.mode = "navigation"
        s.navigation_questions = [
            "What is TinyChat?",
            "How do I install it?",
            "Can I use Ollama?",
            "How do I switch backends?",
        ]
        s.navigation_message_indices = [0, 2, 4, 6]
        s.navigation_cursor = 1  # second question highlighted
        return s

    return Story(
        group="Sidebar",
        title="Navigation Mode",
        description="Question-based navigation through chat history.",
        build=make,
    )


def _sidebar_model_selection() -> Story:
    """Sidebar with model selection focused."""

    def make() -> Sidebar:
        s = Sidebar(backends=["openai", "anthropic"])
        s.available_models = ["gpt-4", "claude-3", "gpt-3.5-turbo"]
        s.selected_model = "gpt-4"
        s.selected_backend_idx = 0
        s.cursor_section = "model"
        s.selected_model_idx = 0
        return s

    return Story(
        group="Sidebar",
        title="Model Selection",
        description="Shows model list with cursor on models.",
        build=make,
    )


register(
    _sidebar_backend_selection(),
    _sidebar_with_todos(),
    _sidebar_navigation_mode(),
    _sidebar_model_selection(),
)
