"""Stories for WorkflowProgressWidget component."""

from tinychat.storybook.registry import Story, register
from tinychat.components.workflow_progress_widget import WorkflowProgressWidget
from tinychat.models.workflow import WorkflowItem, WorkflowState, WorkflowStatus
from tinychat.tools.base import Tool


class MockTool(Tool):
    """Mock tool for stories."""

    @property
    def name(self) -> str:
        return "mock_tool"

    @property
    def description(self) -> str:
        return "A mock tool"

    @property
    def parameters(self) -> list:
        return []

    async def execute(self, arguments: dict) -> dict:
        return {"success": True, "output": "Mock result"}


def _workflow_progress_empty() -> Story:
    """Empty workflow (no items)."""
    state = WorkflowState(session_id="empty-session")
    return Story(
        group="Workflow Progress",
        title="Empty Workflow",
        description="Workflow panel with no tool calls yet.",
        build=lambda: WorkflowProgressWidget(
            workflow_state=state,
            tools={},
            on_confirm=lambda cid, args: None,
            on_deny=lambda cid: None,
            on_edit=lambda cid, args: None,
            on_retry=lambda cid, args: None,
        ),
    )


def _workflow_progress_all_completed() -> Story:
    """All tools completed successfully."""
    items = [
        WorkflowItem(
            call_id="1",
            tool_name="read_file",
            arguments={"path": "/tmp/config.toml"},
            status=WorkflowStatus.COMPLETED,
            started_at=None,
            completed_at=None,
            result_summary="File content loaded",
        ),
        WorkflowItem(
            call_id="2",
            tool_name="exec_shell",
            arguments={"command": "pwd"},
            status=WorkflowStatus.COMPLETED,
            started_at=None,
            completed_at=None,
            result_summary="/home/user/project",
        ),
        WorkflowItem(
            call_id="3",
            tool_name="write_file",
            arguments={"path": "/tmp/out.txt"},
            status=WorkflowStatus.COMPLETED,
            started_at=None,
            completed_at=None,
            result_summary="File written (1024 bytes)",
        ),
    ]
    state = WorkflowState(session_id="completed-session", items=items)
    tools = {item.tool_name: MockTool() for item in items}
    return Story(
        group="Workflow Progress",
        title="All Completed",
        description="All three tools completed successfully.",
        build=lambda: WorkflowProgressWidget(
            workflow_state=state,
            tools=tools,
            on_confirm=lambda cid, args: None,
            on_deny=lambda cid: None,
            on_edit=lambda cid, args: None,
            on_retry=lambda cid, args: None,
        ),
    )


def _workflow_progress_mixed() -> Story:
    """Mixed status: some running, some pending, some completed."""
    from datetime import datetime, timedelta

    now = datetime.now()
    items = [
        WorkflowItem(
            call_id="1",
            tool_name="read_file",
            arguments={"path": "/tmp/a.txt"},
            status=WorkflowStatus.COMPLETED,
            started_at=now - timedelta(seconds=2),
            completed_at=now - timedelta(seconds=1, milliseconds=500),
        ),
        WorkflowItem(
            call_id="2",
            tool_name="exec_shell",
            arguments={"command": "sleep 2"},
            status=WorkflowStatus.RUNNING,
            started_at=now - timedelta(seconds=1),
        ),
        WorkflowItem(
            call_id="3",
            tool_name="write_file",
            arguments={"path": "/tmp/b.txt"},
            status=WorkflowStatus.PENDING,
        ),
    ]
    state = WorkflowState(session_id="mixed-session", items=items)
    tools = {item.tool_name: MockTool() for item in items}
    return Story(
        group="Workflow Progress",
        title="Mixed Status",
        description="Shows completed, running, and pending items.",
        build=lambda: WorkflowProgressWidget(
            workflow_state=state,
            tools=tools,
            on_confirm=lambda cid, args: None,
            on_deny=lambda cid: None,
            on_edit=lambda cid, args: None,
            on_retry=lambda cid, args: None,
        ),
    )


def _workflow_progress_with_failure() -> Story:
    """Workflow with one failure."""
    items = [
        WorkflowItem(
            call_id="1",
            tool_name="read_file",
            arguments={"path": "/tmp/a.txt"},
            status=WorkflowStatus.COMPLETED,
        ),
        WorkflowItem(
            call_id="2",
            tool_name="exec_shell",
            arguments={"command": "invalid_cmd"},
            status=WorkflowStatus.FAILED,
            error="Command not found: invalid_cmd",
        ),
        WorkflowItem(
            call_id="3",
            tool_name="write_file",
            arguments={"path": "/tmp/b.txt"},
            status=WorkflowStatus.PENDING,
        ),
    ]
    state = WorkflowState(session_id="failed-session", items=items)
    tools = {item.tool_name: MockTool() for item in items}
    return Story(
        group="Workflow Progress",
        title="With Failure",
        description="One tool failed, others pending/completed.",
        build=lambda: WorkflowProgressWidget(
            workflow_state=state,
            tools=tools,
            on_confirm=lambda cid, args: None,
            on_deny=lambda cid: None,
            on_edit=lambda cid, args: None,
            on_retry=lambda cid, args: None,
        ),
    )


def _workflow_progress_collapsed() -> Story:
    """Workflow panel in collapsed state."""
    items = [
        WorkflowItem(
            call_id="1",
            tool_name="exec_shell",
            arguments={"command": "ls -la"},
            status=WorkflowStatus.COMPLETED,
        )
        for _ in range(5)
    ]
    state = WorkflowState(
        session_id="collapsed-session", items=items, is_collapsed=True
    )
    tools = {item.tool_name: MockTool() for item in items}
    return Story(
        group="Workflow Progress",
        title="Collapsed State",
        description="Workflow panel initially collapsed.",
        build=lambda: WorkflowProgressWidget(
            workflow_state=state,
            tools=tools,
            on_confirm=lambda cid, args: None,
            on_deny=lambda cid: None,
            on_edit=lambda cid, args: None,
            on_retry=lambda cid, args: None,
        ),
    )


register(
    _workflow_progress_empty(),
    _workflow_progress_all_completed(),
    _workflow_progress_mixed(),
    _workflow_progress_with_failure(),
    _workflow_progress_collapsed(),
)
