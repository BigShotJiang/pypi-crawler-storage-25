"""Story definitions for Storybook.

This package contains individual story modules for each TinyChat component.
Import all story modules here to ensure they are registered with the storybook.
"""

# Import story modules to trigger registration
from tinychat.storybook.stories import message_widgets  # noqa: F401
from tinychat.storybook.stories import status_bar  # noqa: F401
from tinychat.storybook.stories import tool_execution_widget  # noqa: F401
from tinychat.storybook.stories import workflow_progress_widget  # noqa: F401
from tinychat.storybook.stories import input_area  # noqa: F401
from tinychat.storybook.stories import sidebar  # noqa: F401
from tinychat.storybook.stories import rename_dialog  # noqa: F401
from tinychat.storybook.stories import message_action_screen  # noqa: F401
from tinychat.storybook.stories import session_list_dialog  # noqa: F401
from tinychat.storybook.stories import command_palette  # noqa: F401
