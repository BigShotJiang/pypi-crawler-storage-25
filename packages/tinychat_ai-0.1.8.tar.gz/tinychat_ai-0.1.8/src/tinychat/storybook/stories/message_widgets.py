"""Stories for message widget components."""

from tinychat.storybook.registry import Story, register
from tinychat.components.message_widgets import (
    UserMessageWidget,
    AssistantMessageWidget,
    ErrorMessageWidget,
    WelcomeWidget,
)


def _user_message_short() -> Story:
    return Story(
        group="Message Widgets",
        title="User Message - Short",
        description="A simple short user message.",
        build=lambda: UserMessageWidget("Hello, world!"),
    )


def _user_message_long() -> Story:
    return Story(
        group="Message Widgets",
        title="User Message - Long Content",
        description="User message with multi-line, longer content to test wrapping.",
        build=lambda: UserMessageWidget(
            "This is a much longer message that should wrap across multiple lines "
            "to demonstrate how the UserMessageWidget handles overflow and text wrapping "
            "in the terminal UI. It includes multiple sentences and should look clean."
        ),
    )


def _assistant_message_simple() -> Story:
    return Story(
        group="Message Widgets",
        title="Assistant Message - Simple",
        description="Basic assistant reply with markdown.",
        build=lambda: AssistantMessageWidget("Hi there! How can I help you today?"),
    )


def _assistant_message_markdown() -> Story:
    return Story(
        group="Message Widgets",
        title="Assistant Message - Markdown",
        description="Assistant message with **bold**, *italic*, and code blocks.",
        build=lambda: AssistantMessageWidget(
            "Here's an example:\n\n```python\nprint('Hello')\n```\n\nAnd **bold** text."
        ),
    )


def _error_message() -> Story:
    return Story(
        group="Message Widgets",
        title="Error Message",
        description="Displays an error with red styling.",
        build=lambda: ErrorMessageWidget("Failed to connect to the server."),
    )


def _welcome_message() -> Story:
    return Story(
        group="Message Widgets",
        title="Welcome Message",
        description="Shown when chat history is empty.",
        build=lambda: WelcomeWidget(),
    )


# Register all stories
register(
    _user_message_short(),
    _user_message_long(),
    _assistant_message_simple(),
    _assistant_message_markdown(),
    _error_message(),
    _welcome_message(),
)
