"""Stories for InputArea component."""

from tinychat.storybook.registry import Story, register
from tinychat.components.input_area import InputArea


def _input_area_default() -> Story:
    return Story(
        group="Input",
        title="Default (Empty)",
        description="Default input area with placeholder text.",
        build=lambda: InputArea(),
    )


def _input_area_with_content() -> Story:
    return Story(
        group="Input",
        title="With Content",
        description="Input area pre-filled with some text.",
        build=lambda: InputArea(text="Hello, how are you?"),
    )


def _input_area_multiline() -> Story:
    return Story(
        group="Input",
        title="Multiline Content",
        description="Input area containing multiple lines of text.",
        build=lambda: InputArea(text="Line 1\nLine 2\nLine 3"),
    )


register(
    _input_area_default(),
    _input_area_with_content(),
    _input_area_multiline(),
)
