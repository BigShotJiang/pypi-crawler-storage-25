"""Stories for ToolExecutionWidget component."""

from tinychat.storybook.registry import Story, register
from tinychat.components.tool_execution_widget import ToolExecutionWidget
from tinychat.models.workflow import WorkflowItem, WorkflowStatus
from tinychat.tools.base import Tool


class MockTool(Tool):
    """Mock tool for stories."""

    @property
    def name(self) -> str:
        return "mock_tool"

    @property
    def description(self) -> str:
        return "A mock tool for demonstration"

    @property
    def parameters(self) -> list:
        return []

    async def execute(self, arguments: dict) -> dict:
        return {"success": True, "output": "Mock result"}


def _tool_execution_pending() -> Story:
    """Tool execution pending user confirmation."""
    item = WorkflowItem(
        call_id="pending-1",
        tool_name="exec_shell",
        arguments={"command": "git status"},
        status=WorkflowStatus.PENDING,
    )
    return Story(
        group="Tool Execution",
        title="Pending Confirmation",
        description="Tool call awaiting user confirmation via inline card.",
        build=lambda: ToolExecutionWidget(
            item=item,
            tool=MockTool(),
            on_confirm=lambda cid, confirmed: None,
            on_deny=lambda cid: None,
            on_edit=lambda cid, args: None,
            on_retry=lambda cid, args: None,
        ),
    )


def _tool_execution_running() -> Story:
    """Tool execution in progress."""
    from datetime import datetime, timedelta

    now = datetime.now()
    item = WorkflowItem(
        call_id="running-1",
        tool_name="exec_shell",
        arguments={"command": "sleep 5"},
        status=WorkflowStatus.RUNNING,
        started_at=now - timedelta(seconds=2),
    )
    return Story(
        group="Tool Execution",
        title="Running",
        description="Tool is currently executing.",
        build=lambda: ToolExecutionWidget(
            item=item,
            tool=MockTool(),
            on_confirm=lambda cid, confirmed: None,
            on_deny=lambda cid: None,
            on_edit=lambda cid, args: None,
            on_retry=lambda cid, args: None,
        ),
    )


def _tool_execution_completed() -> Story:
    """Tool execution completed successfully."""
    from datetime import datetime, timedelta

    now = datetime.now()
    item = WorkflowItem(
        call_id="completed-1",
        tool_name="read_file",
        arguments={"path": "/tmp/config.toml"},
        status=WorkflowStatus.COMPLETED,
        started_at=now - timedelta(seconds=1),
        completed_at=now,
        result_summary="[config]\ntimeout=30\nretries=3",
    )
    return Story(
        group="Tool Execution",
        title="Completed",
        description="Tool executed successfully.",
        build=lambda: ToolExecutionWidget(
            item=item,
            tool=MockTool(),
            on_confirm=lambda cid, confirmed: None,
            on_deny=lambda cid: None,
            on_edit=lambda cid, args: None,
            on_retry=lambda cid, args: None,
        ),
    )


def _tool_execution_failed() -> Story:
    """Tool execution failed."""
    from datetime import datetime, timedelta

    now = datetime.now()
    item = WorkflowItem(
        call_id="failed-1",
        tool_name="exec_shell",
        arguments={"command": "nonexistent_cmd"},
        status=WorkflowStatus.FAILED,
        started_at=now - timedelta(milliseconds=500),
        completed_at=now,
        error="Command not found: nonexistent_cmd",
    )
    return Story(
        group="Tool Execution",
        title="Failed",
        description="Tool execution failed with error.",
        build=lambda: ToolExecutionWidget(
            item=item,
            tool=MockTool(),
            on_confirm=lambda cid, confirmed: None,
            on_deny=lambda cid: None,
            on_edit=lambda cid, args: None,
            on_retry=lambda cid, args: None,
        ),
    )


def _tool_execution_read_file() -> Story:
    """Read file tool with filename in title."""
    from datetime import datetime

    item = WorkflowItem(
        call_id="read-1",
        tool_name="read_file",
        arguments={"path": "/home/user/.bashrc"},
        status=WorkflowStatus.COMPLETED,
        started_at=datetime.now(),
        completed_at=datetime.now(),
        result_summary="# .bashrc\n# ...",
    )
    return Story(
        group="Tool Execution",
        title="Read File - Completed",
        description="File read operation showing filename in title.",
        build=lambda: ToolExecutionWidget(
            item=item,
            tool=MockTool(),
            on_confirm=lambda cid, confirmed: None,
            on_deny=lambda cid: None,
            on_edit=lambda cid, args: None,
            on_retry=lambda cid, args: None,
        ),
    )


register(
    _tool_execution_pending(),
    _tool_execution_running(),
    _tool_execution_completed(),
    _tool_execution_failed(),
    _tool_execution_read_file(),
)
