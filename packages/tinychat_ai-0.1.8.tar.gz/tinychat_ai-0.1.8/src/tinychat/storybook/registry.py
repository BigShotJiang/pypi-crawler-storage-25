"""Story registry for Storybook TUI.

Provides a simple registration system for component preview stories.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from textual.widget import Widget


@dataclass
class Story:
    """A single component preview story definition.

    Attributes:
        group: Group name for organizing stories (e.g., "Message Widgets")
        title: Story title displayed in the UI (e.g., "User Message - Basic")
        description: Optional description shown with the story (Markdown or plain text)
        build: Factory function that returns a fresh Widget instance
        parameters: Optional dictionary of parameters for Props panel (V2 feature)
    """

    group: str
    title: str
    description: str = ""
    build: Callable[[], Widget] | None = None
    parameters: dict[str, object] | None = None


# Internal registry
_stories: list[Story] = []


def register(*stories: Story) -> None:
    """Register one or more stories with the registry.

    Stories are added to the internal list and will appear in the UI
    sorted by group then title.

    Args:
        *stories: Variable number of Story instances to register
    """
    _stories.extend(stories)


def get_all_stories() -> list[Story]:
    """Get all registered stories sorted by group then title.

    Returns:
        A sorted list of all registered Story objects
    """
    return sorted(_stories, key=lambda s: (s.group, s.title))


def get_groups() -> list[str]:
    """Get all unique group names in order of first appearance.

    Returns:
        A list of unique group names preserving registration order
    """
    return list(dict.fromkeys(s.group for s in _stories))


def clear() -> None:
    """Clear all registered stories.

    This is primarily used for testing to ensure a clean state.
    """
    _stories.clear()
