"""StoryCanvas widget for displaying component previews."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.containers import VerticalScroll
from textual.widget import Widget
from textual.widgets import Static

if TYPE_CHECKING:
    from tinychat.storybook.registry import Story


class StoryCanvas(VerticalScroll):
    """Right-side preview canvas that displays the current story's component.

    StoryCanvas renders the selected story by showing its title, optional
    description, and the component widget produced by the build() factory.
    """

    def __init__(self, **kwargs) -> None:
        """Initialize StoryCanvas with empty state."""
        super().__init__(**kwargs)
        self._current_story: Story | None = None
        self._title_widget: Static | None = None
        self._content_widget: Widget | None = None

    def show_story(self, story: Story) -> None:
        """Display a new story, replacing any previous content.

        Args:
            story: The Story to render in the canvas
        """
        self._current_story = story

        # Remove previous widgets if present
        if self._title_widget is not None:
            self._title_widget.remove()
            self._title_widget = None
        if self._content_widget is not None:
            self._content_widget.remove()
            self._content_widget = None

        # Create and mount title (and description if present)
        title_text = f"## {story.title}"
        if story.description:
            title_text += f"\n{story.description}"
        self._title_widget = Static(title_text, classes="story-meta")
        self.mount(self._title_widget)

        # Build and mount the widget if build factory provided
        if story.build is not None:
            widget = story.build()
            self._content_widget = widget
            self.mount(widget)

        # Scroll to show content
        self.scroll_end(animate=False)
