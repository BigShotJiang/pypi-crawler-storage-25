"""Entry point for running Storybook TUI as a module: python -m tinychat.storybook"""

from tinychat.utils.i18n import init_i18n
from tinychat.storybook.app import StorybookApp


def main() -> None:
    """Initialize i18n and launch the Storybook application."""
    init_i18n("en")  # Fixed to English for development
    app = StorybookApp()
    app.run()


if __name__ == "__main__":
    main()
