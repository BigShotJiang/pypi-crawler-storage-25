"""DialogPreview - Embed a ModalScreen's content into a regular container.

This wrapper allows ModalScreen-based dialogs to be previewed inside Storybook
without needing to push them onto the app's screen stack.

Usage:
    def _make_screen():
        return SomeModalScreen(...)
    preview = DialogPreview(_make_screen)
"""

from __future__ import annotations

from typing import Callable

from textual.app import ComposeResult
from textual.containers import Container
from textual.screen import ModalScreen


class DialogPreview(Container):
    """A container that renders a ModalScreen's compose content inline.

    The ModalScreen is instantiated via a factory callable, but its `dismiss`
    method is replaced with a no-op to prevent attempting to pop the screen
    during preview.

    Args:
        screen_factory: A callable that returns a ModalScreen instance.
    """

    def __init__(
        self,
        screen_factory: Callable[[], ModalScreen],
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self._screen_factory = screen_factory

    def compose(self) -> ComposeResult:
        """Compose the ModalScreen's internal widgets."""
        screen = self._screen_factory()
        # Replace dismiss with a no-op to avoid screen stack manipulation
        screen.dismiss = lambda result=None: None  # type: ignore[assignment]
        # Yield all children from the screen's compose method
        yield from screen.compose()
