"""StorybookApp - Main application for TinyChat Storybook TUI."""

from __future__ import annotations

from typing import Optional

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal
from textual.widgets import Footer, Header, ListView, ListItem, Static

from tinychat.storybook.canvas import StoryCanvas
from tinychat.storybook.registry import get_all_stories
from tinychat.utils.theme_manager import ThemeManager


class StorybookApp(App):
    """Main Storybook application for previewing TinyChat components.

    Displays a sidebar with story list and a main canvas for component preview.
    Supports theme switching and keyboard navigation.
    """

    CSS_PATH = "styles/storybook.tcss"
    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("t", "toggle_theme", "Toggle Theme"),
        Binding("tab", "focus_next", "Focus Next"),
        Binding("down", "cursor_down", "Down", show=True),
        Binding("up", "cursor_up", "Up", show=True),
        Binding("enter", "select_story", "Select", show=True),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._theme_manager = ThemeManager()
        self._current_theme = "dark"

    def compose(self) -> ComposeResult:
        """Create child widgets for the app."""
        yield Header()
        with Horizontal():
            yield ListView(id="story-list")
            yield StoryCanvas(id="preview-canvas")
        yield Footer()

    def on_mount(self) -> None:
        """Populate the story list and select the first story."""
        self._populate_story_list()
        self._select_first_story()

    def _populate_story_list(self) -> None:
        """Build the list of stories in the sidebar."""
        list_view = self.query_one("#story-list", ListView)
        items: list[ListItem] = []
        current_group: Optional[str] = None

        for idx, story in enumerate(get_all_stories()):
            if story.group != current_group:
                # Add group header
                items.append(
                    ListItem(
                        Static(f"── {story.group} ──", classes="story-group-header"),
                        disabled=True,
                    )
                )
                current_group = story.group
            # Add story item with custom story_index attribute for lookup
            item = ListItem(
                Static(f"  {story.title}"),
                id=f"story-{idx}",
                classes="story-item",
            )
            item.story_index = idx  # type: ignore[attr-defined]
            items.append(item)

        list_view.clear()
        list_view.extend(items)

    def _select_first_story(self) -> None:
        """Select and display the first story in the list."""
        list_view = self.query_one("#story-list", ListView)
        # Find the first enabled (non-header) item
        for idx, child in enumerate(list_view.children):
            if not child.disabled:
                list_view.index = idx
                break
        self._show_selected_story()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Handle selection of a story from the list."""
        self._show_selected_story()

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        """Handle highlight change in the story list (arrow key navigation)."""
        self._show_selected_story()

    def _show_selected_story(self) -> None:
        """Display the currently selected story in the canvas."""
        list_view = self.query_one("#story-list", ListView)
        canvas = self.query_one("#preview-canvas", StoryCanvas)

        highlighted = list_view.highlighted_child
        if highlighted is None or highlighted.disabled:
            return

        story_idx = getattr(highlighted, "story_index", None)
        if not isinstance(story_idx, int):
            return

        stories = get_all_stories()
        if 0 <= story_idx < len(stories):
            story = stories[story_idx]
            canvas.show_story(story)

    def action_toggle_theme(self) -> None:
        """Toggle between dark and light themes."""
        self._current_theme = "light" if self._current_theme == "dark" else "dark"
        self._theme_manager.switch_theme(self._current_theme)
        self.refresh_css()

    def action_focus_next(self) -> None:
        """Toggle focus between sidebar and canvas."""
        list_view = self.query_one("#story-list", ListView)
        canvas = self.query_one("#preview-canvas", StoryCanvas)
        if self.focused is list_view:
            canvas.focus()
        else:
            list_view.focus()

    def action_cursor_down(self) -> None:
        """Move cursor down in the story list."""
        list_view = self.query_one("#story-list", ListView)
        if list_view.focus:
            list_view.action_cursor_down()

    def action_cursor_up(self) -> None:
        """Move cursor up in the story list."""
        list_view = self.query_one("#story-list", ListView)
        if list_view.focus:
            list_view.action_cursor_up()

    def action_select_story(self) -> None:
        """Select the currently highlighted story."""
        list_view = self.query_one("#story-list", ListView)
        if list_view.focus and list_view.highlighted_child:
            self._show_selected_story()
