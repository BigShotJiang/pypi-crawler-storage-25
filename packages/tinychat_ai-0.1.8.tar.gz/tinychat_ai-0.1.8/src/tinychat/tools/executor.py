"""Tool executor for handling tool calls with user confirmation."""

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from tinychat.models.message import Message, ToolCall
from tinychat.models.workflow import WorkflowItem, WorkflowStatus
from tinychat.tools.base import Tool, ToolResult

if TYPE_CHECKING:
    from tinychat.app_textual import TinyChatApp
    from tinychat.tools.workflow_manager import WorkflowManager

logger = logging.getLogger(__name__)

MAX_RECENT_CALLS = 20


class ToolExecutor:
    """Tool executor with user confirmation support (inline or modal)."""

    TRUST_THRESHOLD: int = 3

    def __init__(
        self,
        app: "TinyChatApp",
        tools: list[Tool],
        config_path: Path | None = None,
        workflow_manager: "WorkflowManager | None" = None,
    ) -> None:
        """Initialize tool executor.

        Args:
            app: The TinyChat application instance.
            tools: List of available tools.
            config_path: Optional config path for persisting allowed tools.
            workflow_manager: Optional workflow manager for tracking state.
        """
        self.app = app
        self.tools: dict[str, Tool] = {t.name: t for t in tools}
        self.always_allow: set[str] = set()
        self._recent_calls: list[tuple[str, str]] = []
        self._trust_counts: dict[str, int] = {}
        self._config_path = config_path
        self.workflow_manager = workflow_manager
        self._pending_confirmation_futures: dict[str, asyncio.Future[bool | None]] = {}

        if config_path is not None:
            from tinychat.utils.config_manager import load_allowed_tools  # noqa: PLC0415

            self.always_allow = set(load_allowed_tools(config_path=config_path))

    async def handle_tool_call(
        self,
        tool_name: str,
        arguments: dict[str, Any],
        call_id: str,
    ) -> tuple[ToolCall, Message]:
        """Handle a tool call from the LLM.

        Supports both inline confirmation (via ToolExecutionWidget) and
        inline confirmation (via ToolExecutionWidget) depending on whether
        a workflow_manager is set.

        Args:
            tool_name: Name of the tool to execute.
            arguments: Tool arguments dict.
            call_id: Unique call ID.

        Returns:
            Tuple of (ToolCall, Message) with execution result.
        """
        if tool_name not in self.tools:
            msg = f"Unknown tool: {tool_name}"
            raise ValueError(msg)

        # Deduplication check
        args_signature = json.dumps(arguments, sort_keys=True)
        if (tool_name, args_signature) in self._recent_calls:
            tool_call = ToolCall(
                id=call_id,
                name=tool_name,
                arguments=arguments,
                result=ToolResult(
                    success=False,
                    output="",
                    error="Duplicate call skipped",
                ),
            )
            message = Message(
                role="tool",
                content=(
                    "This tool was already called with the same arguments in this "
                    "conversation. Use the previous result instead."
                ),
                tool_call_id=call_id,
                tool_name=tool_name,
                metadata={"arguments": arguments},
            )
            return tool_call, message

        self._recent_calls.append((tool_name, args_signature))
        if len(self._recent_calls) > MAX_RECENT_CALLS:
            self._recent_calls = self._recent_calls[-MAX_RECENT_CALLS:]

        tool = self.tools[tool_name]
        start_time = time.perf_counter()

        # Determine if confirmation is needed BEFORE creating WorkflowItem
        needs_confirmation = (
            tool_name not in self.always_allow
            and tool_name != "no_action"
            and self._trust_counts.get(tool_name, 0) < self.TRUST_THRESHOLD
        )

        # Create WorkflowItem with appropriate initial status
        if self.workflow_manager:
            initial_status = (
                WorkflowStatus.PENDING if needs_confirmation else WorkflowStatus.RUNNING
            )
            item = WorkflowItem(
                call_id=call_id,
                tool_name=tool_name,
                arguments=arguments,
                status=initial_status,
                widget_collapsed=not needs_confirmation,
                tool_icon=tool.icon,
            )
            self.workflow_manager.add_item(item)

            if len(self.workflow_manager.state.items) == 1:
                self.app.mount_workflow_progress_widget(self.workflow_manager)

        confirmation: bool | None = None
        if needs_confirmation:
            if self.workflow_manager:
                # Inline confirmation via ToolExecutionWidget
                confirmation = await self._wait_for_confirmation(
                    tool_name, call_id, arguments, tool
                )
            else:
                # Modal fallback
                confirmation = await self.confirm_with_user(tool, arguments)
        else:
            # Auto-allow (always_allow or no_action or trust threshold met)
            confirmation = True

        if confirmation is False:
            # User denied
            duration_ms = int((time.perf_counter() - start_time) * 1000)
            logger.info(
                "Tool execution denied",
                extra={
                    "tool_name": tool_name,
                    "success": False,
                    "duration_ms": duration_ms,
                },
            )
            tool_call = ToolCall(
                id=call_id,
                name=tool_name,
                arguments=arguments,
                result=ToolResult(success=False, output="", error="User denied"),
            )
            message = Message(
                role="tool",
                content="Tool call denied by user",
                tool_call_id=call_id,
                tool_name=tool_name,
                metadata={"arguments": arguments},
            )
            self._trust_counts[tool_name] = 0

            # Update workflow state (listener will update UI)
            if self.workflow_manager:
                self.workflow_manager.update_status(
                    call_id,
                    WorkflowStatus.FAILED,
                    error="User denied",
                )

            return tool_call, message

        # Confirmation received (True or None for always allow)
        if confirmation is None:
            self.always_allow.add(tool_name)
            self._trust_counts[tool_name] = 0
            if self._config_path is not None:
                from tinychat.utils.config_manager import save_allowed_tools  # noqa: PLC0415

                save_allowed_tools(
                    list(self.always_allow),
                    config_path=self._config_path,
                )

        if confirmation is True:
            # Increment trust count
            new_count = self._trust_counts.get(tool_name, 0) + 1
            self._trust_counts[tool_name] = new_count
            # Auto-upgrade to always_allow once threshold is reached
            if new_count >= self.TRUST_THRESHOLD:
                self.always_allow.add(tool_name)
                if self._config_path is not None:
                    from tinychat.utils.config_manager import save_allowed_tools  # noqa: PLC0415

                    save_allowed_tools(
                        list(self.always_allow),
                        config_path=self._config_path,
                    )

        # Update status to RUNNING only if confirmation was needed (PENDING -> RUNNING)
        # For auto-allowed tools, status is already RUNNING
        if self.workflow_manager and needs_confirmation:
            self.workflow_manager.update_status(call_id, WorkflowStatus.RUNNING)

        # Execute the tool
        result = await tool.execute(arguments)
        duration_ms = int((time.perf_counter() - start_time) * 1000)

        logger.info(
            "Tool execution completed",
            extra={
                "tool_name": tool_name,
                "success": result.success,
                "duration_ms": duration_ms,
            },
        )

        tool_call = ToolCall(
            id=call_id,
            name=tool_name,
            arguments=arguments,
            result=result,
        )

        content = result.output if result.success else (result.error or "Unknown error")
        message = Message(
            role="tool",
            content=content,
            tool_call_id=call_id,
            tool_name=tool_name,
            metadata={"arguments": arguments, "result_metadata": result.metadata},
        )

        # Update workflow state (listener will update UI)
        if self.workflow_manager:
            status_enum = (
                WorkflowStatus.COMPLETED if result.success else WorkflowStatus.FAILED
            )
            self.workflow_manager.update_status(
                call_id,
                status_enum,
                result_summary=content[:100] if content else None,
                error=None if result.success else result.error,
                result_metadata=result.metadata,
            )

        return tool_call, message

    async def _wait_for_confirmation(
        self,
        tool_name: str,
        call_id: str,
        arguments: dict[str, Any],
        tool: Tool,
    ) -> bool | None:
        """Wait for user confirmation (inline or modal fallback).

        Args:
            tool_name: Tool name.
            call_id: Call ID.
            arguments: Tool arguments.
            tool: Tool instance.

        Returns:
            Confirmation result: True=allow, False=deny, None=always allow.
        """
        # Create future for inline confirmation
        future: asyncio.Future[bool | None] = asyncio.get_event_loop().create_future()
        self._pending_confirmation_futures[call_id] = future

        try:
            # Wait for confirmation with timeout? (optional)
            result = await asyncio.wait_for(future, timeout=300.0)  # 5 minute timeout
            return result
        except asyncio.TimeoutError:
            logger.warning(
                "Confirmation timeout for tool %s (call_id=%s)", tool_name, call_id
            )
            return False
        finally:
            self._pending_confirmation_futures.pop(call_id, None)

    def _handle_inline_confirmation(self, call_id: str, confirmed: bool) -> None:
        """Handle inline confirmation from ToolExecutionWidget.

        Args:
            call_id: The tool call ID.
            confirmed: True=allow, False=deny.
        """
        future = self._pending_confirmation_futures.get(call_id)
        if future and not future.done():
            future.set_result(confirmed)

    def _handle_edit(self, call_id: str, arguments: dict[str, Any]) -> None:
        """Handle edit request from ToolExecutionWidget.

        Args:
            call_id: The tool call ID.
            arguments: Current arguments.
        """
        # TODO: Implement argument editing dialog
        logger.info("Edit requested for call_id=%s", call_id)

    def _handle_retry(self, call_id: str, arguments: dict[str, Any]) -> None:
        """Handle retry request from ToolExecutionWidget.

        Args:
            call_id: The tool call ID.
            arguments: Arguments to retry with (should be same as original).
        """
        if not self.workflow_manager:
            logger.warning("Cannot retry: no workflow manager")
            return

        item = self.workflow_manager.get_item(call_id)
        if not item:
            logger.warning("Retry failed: item not found: %s", call_id)
            return

        tool_name = item.tool_name
        if tool_name not in self.tools:
            logger.warning("Retry failed: tool not found: %s", tool_name)
            return

        tool = self.tools[tool_name]

        import json

        args_signature = json.dumps(arguments, sort_keys=True)
        if (tool_name, args_signature) in self._recent_calls:
            self._recent_calls.remove((tool_name, args_signature))

        self.workflow_manager.retry_item(call_id)

        async def retry_execution() -> None:
            self.workflow_manager.update_status(call_id, WorkflowStatus.RUNNING)
            result = await tool.execute(arguments)
            status = (
                WorkflowStatus.COMPLETED if result.success else WorkflowStatus.FAILED
            )
            self.workflow_manager.update_status(
                call_id,
                status,
                result_summary=result.output if result.success else None,
                error=result.error if not result.success else None,
            )

        asyncio.create_task(retry_execution())
        logger.info("Retry initiated for call_id=%s, tool=%s", call_id, tool_name)

    async def confirm_with_user(
        self,
        tool: Tool,
        args: dict[str, Any],
    ) -> bool | None:
        """Confirmation fallback when inline confirmation is not available.

        Always returns True since modal confirmation has been removed.
        Inline confirmation via ToolExecutionWidget is the only path.

        Args:
            tool: The tool to confirm.
            args: Tool arguments.

        Returns:
            Always True.
        """
        return True
