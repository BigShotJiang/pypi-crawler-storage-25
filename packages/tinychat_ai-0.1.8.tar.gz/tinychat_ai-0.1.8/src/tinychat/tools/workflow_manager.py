"""Workflow manager for tracking tool execution status."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import TYPE_CHECKING, Any, Callable

from tinychat.models.workflow import (
    ExecutionContext,
    WorkflowItem,
    WorkflowState,
    WorkflowStatus,
)

if TYPE_CHECKING:
    from tinychat.app_textual import TinyChatApp

logger = logging.getLogger(__name__)


class WorkflowManager:
    """Manages workflow state and notifies listeners of updates."""

    def __init__(self, session_id: str, app: TinyChatApp) -> None:
        """Initialize workflow manager.

        Args:
            session_id: The session ID this workflow belongs to.
            app: The TinyChat application instance.
        """
        self.session_id = session_id
        self.app = app
        self.state = WorkflowState(session_id=session_id)
        self._listeners: list[Callable[[WorkflowState], None]] = []

    def add_execution(
        self, execution_id: str, workflow_id: str | None = None
    ) -> ExecutionContext:
        """Add a new execution context.

        Args:
            execution_id: Unique execution identifier.
            workflow_id: Optional workflow identifier.

        Returns:
            The created ExecutionContext.
        """
        return self.state.add_execution(execution_id, workflow_id)

    def get_execution(self, execution_id: str) -> ExecutionContext | None:
        """Get an execution context by ID.

        Args:
            execution_id: The execution ID.

        Returns:
            ExecutionContext if found, else None.
        """
        return self.state.get_execution(execution_id)

    def get_items_by_execution(self, execution_id: str) -> list[WorkflowItem]:
        """Get items for a specific execution.

        Args:
            execution_id: The execution ID.

        Returns:
            List of WorkflowItems in the execution.
        """
        return self.state.get_items_by_execution(execution_id)

    def add_item(
        self,
        item: WorkflowItem,
        execution_id: str | None = None,
        workflow_id: str | None = None,
    ) -> None:
        """Add a new workflow item.

        Args:
            item: The workflow item to add.
            execution_id: Optional execution context ID.
            workflow_id: Optional workflow ID.
        """
        if execution_id:
            item.execution_id = execution_id
        if workflow_id:
            item.workflow_id = workflow_id
        self.state.add_item(item, execution_id)
        self._notify_listeners()

    def update_status(
        self,
        call_id: str,
        status: WorkflowStatus,
        result_summary: str | None = None,
        error: str | None = None,
        result_metadata: dict[str, Any] | None = None,
    ) -> None:
        """Update the status of a workflow item.

        Args:
            call_id: The tool call ID to update.
            status: The new status.
            result_summary: Optional success summary.
            error: Optional error message.
            result_metadata: Optional result metadata (from ToolResult.metadata).
        """
        item = self._find_item(call_id)
        if not item:
            logger.warning("WorkflowItem not found: %s", call_id)
            return

        item.status = status
        if status == WorkflowStatus.RUNNING:
            self._start_item_timing(item)
        elif status in (WorkflowStatus.COMPLETED, WorkflowStatus.FAILED):
            self._complete_item_timing(
                item, status, result_summary, error, result_metadata
            )

        self._notify_listeners()

    def _start_item_timing(self, item: WorkflowItem) -> None:
        """Start timing for a workflow item.

        Resets timing when transitioning to RUNNING state to ensure accurate
        duration measurement. This handles retry scenarios where timing
        should start fresh for each attempt.

        Args:
            item: The workflow item.
        """
        now = datetime.now()

        if item.status == WorkflowStatus.PENDING and item.attempt > 1:
            logger.debug(
                "Retry attempt %d for call_id=%s, resetting start time",
                item.attempt,
                item.call_id,
            )

        item.started_at = now
        item.completed_at = None

    def _complete_item_timing(
        self,
        item: WorkflowItem,
        status: WorkflowStatus,
        result_summary: str | None,
        error: str | None,
        result_metadata: dict[str, Any] | None = None,
    ) -> None:
        """Complete timing for a workflow item.

        Records the attempt duration in history and sets final state.

        Args:
            item: The workflow item.
            status: Final status (COMPLETED or FAILED).
            result_summary: Optional success summary.
            error: Optional error message.
            result_metadata: Optional result metadata.
        """
        now = datetime.now()
        item.completed_at = now
        item.result_summary = result_summary
        item.error = error
        if result_metadata:
            item.result_metadata = result_metadata

        if item.started_at:
            duration_ms = int((now - item.started_at).total_seconds() * 1000)
            attempt_record = {
                "attempt": item.attempt,
                "started_at": item.started_at,
                "completed_at": now,
                "duration_ms": duration_ms,
                "status": status.value,
                "success": status == WorkflowStatus.COMPLETED,
            }
            item.attempt_history.append(attempt_record)

    def retry_item(self, call_id: str) -> bool:
        """Reset an item for retry.

        Increments attempt counter and resets status to PENDING.
        The next RUNNING transition will reset timing.

        Args:
            call_id: The tool call ID to retry.

        Returns:
            True if retry was initiated, False if item not found.
        """
        item = self._find_item(call_id)
        if not item:
            logger.warning("Cannot retry: item not found: %s", call_id)
            return False

        item.attempt += 1
        item.status = WorkflowStatus.PENDING
        item.started_at = None
        item.completed_at = None
        item.result_summary = None
        item.error = None

        self._notify_listeners()
        return True

    def _find_item(self, call_id: str) -> WorkflowItem | None:
        """Find a workflow item by call ID.

        Args:
            call_id: The tool call ID to find.

        Returns:
            The WorkflowItem if found, else None.
        """
        for item in self.state.items:
            if item.call_id == call_id:
                return item
        return None

    def get_item(self, call_id: str) -> WorkflowItem | None:
        """Get a workflow item by call ID (public API).

        Args:
            call_id: The tool call ID.

        Returns:
            The WorkflowItem if found, else None.
        """
        return self._find_item(call_id)

    def add_listener(self, callback: Callable[[WorkflowState], None]) -> None:
        """Add a status update listener.

        Args:
            callback: Function to call when state changes.
        """
        self._listeners.append(callback)

    def remove_listener(self, callback: Callable[[WorkflowState], None]) -> None:
        """Remove a status update listener.

        Args:
            callback: The listener to remove.
        """
        if callback in self._listeners:
            self._listeners.remove(callback)

    def _notify_listeners(self) -> None:
        """Notify all listeners of state changes."""
        for callback in self._listeners:
            try:
                callback(self.state)
            except Exception as e:
                logger.error("Workflow listener error: %s", e)

    def clear(self) -> None:
        """Clear all workflow items and executions."""
        self.state.items.clear()
        self.state.executions.clear()
        self.state.is_collapsed = False
        self._notify_listeners()

    def clear_execution(self, execution_id: str) -> None:
        """Clear a specific execution context.

        Args:
            execution_id: The execution ID to clear.
        """
        if execution_id in self.state.executions:
            ctx = self.state.executions[execution_id]
            for item in ctx.items:
                if item in self.state.items:
                    self.state.items.remove(item)
            del self.state.executions[execution_id]
            self._notify_listeners()
