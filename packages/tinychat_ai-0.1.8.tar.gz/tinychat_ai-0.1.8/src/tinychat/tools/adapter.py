"""Tool calling adapters for different LLM backends."""

import json
import logging
import textwrap
import uuid
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Callable

from tinychat.tools.trigger_manager import TriggerDetector
from tinychat.utils.i18n import get_current_locale

if TYPE_CHECKING:
    from tinychat.backends.base import Backend
    from tinychat.models.session import ChatSession
    from tinychat.tools.base import Tool

logger = logging.getLogger(__name__)

TOOL_TRIGGER_THRESHOLD = 0.05
MAX_TOOL_DESC_LENGTH = 100

TOOL_USAGE_RULES = textwrap.dedent("""\
    IMPORTANT RULES FOR TOOL USAGE:
    - Only call a tool when your built-in knowledge is genuinely insufficient.
    - Do NOT call tools for tasks you can answer directly: translation, explanation,
      math, general knowledge, conversation.
    - Do NOT call the same tool with the same arguments twice.
    - When in doubt, answer directly without using any tool.
    - You can call MULTIPLE tools in a single response to accomplish complex workflows.
    - For multi-step tasks, chain tools: e.g. use glob/grep to locate files,
      read_file to inspect content, edit_file to make changes, exec_shell to verify.
    - Think step-by-step: plan which tools you need BEFORE calling them,
      then execute the chain.
    - ALWAYS prefer efficient solutions: use bash command combinations (grep|awk|sed|sort|uniq)
      instead of multiple sequential tool calls. Combine operations when possible.
    """).strip()

_TOOL_SYSTEM_MARKER = "<!-- tinychat-tool-rules -->"


class ToolCallingAdapter(ABC):
    """Base class for LLM tool calling adapters."""

    def __init__(self, backend: "Backend"):
        self.backend = backend

    def build_tools_schema(self, tools: list["Tool"]) -> list[dict]:
        """Build OpenAI-format tools JSON schema."""
        return [tool.to_openai_schema() for tool in tools]

    @abstractmethod
    async def chat_with_tools(
        self,
        session: "ChatSession",
        tools: list["Tool"],
        on_token: Callable[[str], None],
        on_tool_call: Callable[[str, dict, str], None],
    ) -> None:
        """Chat with tool support.

        Args:
            session: Chat session with message history
            tools: Available tools
            on_token: Callback for each text token
            on_tool_call: Callback for tool calls (name, args, call_id)
        """


class NativeAdapter(ToolCallingAdapter):
    """Adapter for backends with native tool_calls support (Ollama 0.3+, OpenAI)."""

    def __init__(self, backend: "Backend"):
        super().__init__(backend)
        self._trigger_detector: TriggerDetector | None = None

    def _get_trigger_detector(self) -> TriggerDetector:
        """Get or create trigger detector."""
        if self._trigger_detector is None:
            locale = get_current_locale()
            self._trigger_detector = TriggerDetector(locale)
        return self._trigger_detector

    def _enhance_system_message(self, user_input: str, tools: list["Tool"]) -> str:
        """Enhance system message with trigger-based hints.

        Args:
            user_input: The user's input text.
            tools: Available tools.

        Returns:
            Enhanced system message with tool hints if triggers detected.
        """
        base_message = f"{_TOOL_SYSTEM_MARKER}\n{TOOL_USAGE_RULES}"

        if not tools or not user_input:
            return base_message

        # Detect triggered tools
        detector = self._get_trigger_detector()
        tool_names = [tool.name for tool in tools]
        triggered = detector.detect_all(user_input, tool_names)

        # Filter tools with significant trigger score
        # Using lower threshold (0.05) for better demonstration
        significant_triggers = [
            (tool, score)
            for tool, score in triggered
            if score >= TOOL_TRIGGER_THRESHOLD
        ]

        if not significant_triggers:
            return base_message

        # Build enhancement
        enhancement = "\n\n## Tool Usage Hints\n"
        enhancement += "Based on your input, the following tools might be useful:\n"

        for tool_name, score in significant_triggers[:3]:  # Show top 3
            # Find the tool to get its description
            tool = next((t for t in tools if t.name == tool_name), None)
            if tool:
                # Truncate description if too long
                desc = tool.description
                if len(desc) > MAX_TOOL_DESC_LENGTH:
                    desc = desc[: MAX_TOOL_DESC_LENGTH - 3] + "..."

                enhancement += f"- **{tool_name}** (relevance: {score:.1%}): {desc}\n"

        enhancement += (
            "\nRemember: Only use tools when necessary. You can still answer directly."
        )

        return base_message + enhancement

    def _ensure_tool_system_message(
        self,
        session: "ChatSession",
        tools: list["Tool"],
    ) -> None:
        from tinychat.models.message import Message  # noqa: PLC0415

        # Check if we already have a system message
        if any(
            _TOOL_SYSTEM_MARKER in msg.content
            for msg in session.messages
            if msg.role == "system"
        ):
            return

        # Get the latest user message for trigger detection
        user_input = ""
        for msg in reversed(session.messages):
            if msg.role == "user":
                user_input = msg.content
                break

        # Create enhanced system message
        system_content = self._enhance_system_message(user_input, tools)
        system_msg = Message(
            role="system",
            content=system_content,
        )
        session.messages.insert(0, system_msg)

    async def chat_with_tools(
        self,
        session: "ChatSession",
        tools: list["Tool"],
        on_token: Callable[[str], None],
        on_tool_call: Callable[[str, dict, str], None],
    ) -> None:
        """Chat using native tool_calls from backend response."""
        self._ensure_tool_system_message(session, tools)
        result = await self.backend.chat(
            session=session,
            on_token=on_token,
            tools=tools or None,
        )

        if result is None:
            return

        tool_calls = result.get("tool_calls", [])
        for tc in tool_calls:
            call_id = tc.get("id", f"native_{uuid.uuid4().hex[:8]}")
            func = tc.get("function", {})
            name = func.get("name", "")
            raw_args = func.get("arguments", {})

            if isinstance(raw_args, dict):
                args = raw_args
            elif isinstance(raw_args, str) and raw_args:
                try:
                    args = json.loads(raw_args)
                except (json.JSONDecodeError, TypeError):
                    logger.warning(
                        "Failed to parse tool arguments for '%s' as JSON: %s",
                        name,
                        raw_args[:100],
                    )
                    args = {}
            else:
                args = {}

            if not isinstance(args, dict):
                logger.warning(
                    "Tool arguments for '%s' are not a dict (got %s), using empty dict",
                    name,
                    type(args).__name__,
                )
                args = {}

            on_tool_call(name, args, call_id)
