"""Plugin manager for tool discovery and instantiation."""

import logging
import re
from importlib.metadata import entry_points
from typing import Any

from tinychat.tools.base import Tool

logger = logging.getLogger(__name__)


class PluginManager:
    """Plugin manager for discovering and managing tools via entry points."""

    ENTRY_POINT_GROUP = "tinychat.tools"

    FILE_PATH_PATTERN = re.compile(
        r"[/~]|\\\.\.?/|\.py|\.txt|\.json|\.toml|\.yaml|\.yml|\.md|\.csv"
        r"|read\s|write\s|edit\s|file|目录|文件夹",
    )
    COMMAND_PATTERN = re.compile(
        r"(?:^|(?<=[\s,;.!?/:|(){}\[\]\"'`\u4e00-\u9fff]))"
        r"(run|execute|pip|npm|cargo|python|node|bash|sh|curl|wget"
        r"|make|gcc|docker|systemctl)"
        r"(?:$|(?=[\s,;.!?/:|(){}\[\]\"'`\u4e00-\u9fff]))"
        r"|执行|运行|命令|脚本|跑一下",
    )
    TODO_PATTERN = re.compile(
        r"(?:^|(?<=[\s,;.!?/:|(){}\[\]\"'`\u4e00-\u9fff]))"
        r"(todo|todos|tasks?|plans?|schedule|agenda|workflow)"
        r"(?:$|(?=[\s,;.!?/:|(){}\[\]\"'`\u4e00-\u9fff]))"
        r"|待办|任务|计划|日程|议程|待办事项|任务管理|工作计划",
        re.IGNORECASE,
    )
    FILE_TOOL_NAMES = frozenset(
        {"read_file", "write_file", "edit_file", "list_directory", "glob", "grep"},
    )

    def __init__(self) -> None:
        self._tool_classes: list[type[Tool]] | None = None
        self._tool_instances: list[Tool] | None = None

    def _get_entry_points(self) -> list[Any]:
        """Get entry points for the tool group."""
        eps = entry_points()
        if hasattr(eps, "select"):
            return list(eps.select(group=self.ENTRY_POINT_GROUP))
        return list(eps.get(self.ENTRY_POINT_GROUP, []))

    def discover_tools(self) -> list[type[Tool]]:
        """Discover all installed tool classes via entry points."""
        if self._tool_classes is not None:
            return self._tool_classes

        tool_classes: list[type[Tool]] = []

        for ep in self._get_entry_points():
            try:
                loaded = ep.load()
                if isinstance(loaded, type) and issubclass(loaded, Tool):
                    tool_classes.append(loaded)
            except (ImportError, AttributeError, TypeError) as e:
                logger.warning(
                    "Failed to load tool from entry point '%s': %s", ep.name, e
                )
                continue

        self._tool_classes = tool_classes
        return tool_classes

    def instantiate_tools(self) -> list[Tool]:
        """Instantiate all discovered tools."""
        if self._tool_instances is not None:
            return self._tool_instances

        tool_classes = self.discover_tools()
        instances: list[Tool] = []
        seen_names: set[str] = set()
        for cls in tool_classes:
            instance = cls()
            if instance.name in seen_names:
                logger.warning(
                    "Duplicate tool name '%s' found. First occurrence will be used.",
                    instance.name,
                )
                continue
            instances.append(instance)
            seen_names.add(instance.name)
        self._tool_instances = instances
        return self._tool_instances

    def get_tool(self, name: str) -> Tool | None:
        """Get a tool by name."""
        tools = self.instantiate_tools()
        for tool in tools:
            if tool.name == name:
                return tool
        return None

    def get_all_tools(self) -> list[Tool]:
        """Get all available tools."""
        return self.instantiate_tools()

    def reload(self) -> None:
        """Clear cache and rediscover tools."""
        self._tool_classes = None
        self._tool_instances = None

    def select_tools(self, message: str, tools: list[Tool] | None = None) -> list[Tool]:
        """Select relevant tools based on message content.

        Uses simple pattern matching to determine which tools to expose:
        - File path patterns (/ ./ ~ .py .txt etc) -> file-related tools
        - Command keywords (run execute pip npm python etc) -> shell tool
        - Todo/task keywords (todo, task, plan, 待办, 任务, 计划) -> todo_list tool
        - No patterns matched -> only no_action (if available)
        """
        if tools is None:
            tools = self.instantiate_tools()

        tool_map = {t.name: t for t in tools}
        msg = message.strip()

        if not msg:
            return self._no_action_result(tool_map)

        selected_names = self._match_tool_patterns(msg)

        if not selected_names:
            return self._no_action_result(tool_map)

        if "no_action" in tool_map:
            selected_names.add("no_action")

        result = [tool_map[name] for name in selected_names if name in tool_map]
        logger.info("select_tools result: %s", [t.name for t in result])
        return result

    def _no_action_result(self, tool_map: dict[str, Tool]) -> list[Tool]:
        """Return no_action tool or empty list."""
        if "no_action" in tool_map:
            return [tool_map["no_action"]]
        return []

    def _match_tool_patterns(self, msg: str) -> set[str]:
        """Match message against tool selection patterns."""
        has_file_match = bool(self.FILE_PATH_PATTERN.search(msg))
        has_command_match = bool(self.COMMAND_PATTERN.search(msg))
        has_todo_match = bool(self.TODO_PATTERN.search(msg))

        logger.info(
            "select_tools: msg=%r has_file=%s has_command=%s has_todo=%s",
            msg[:80],
            has_file_match,
            has_command_match,
            has_todo_match,
        )

        selected_names: set[str] = set()

        if has_file_match:
            selected_names.update(self.FILE_TOOL_NAMES)

        if has_command_match:
            selected_names.add("exec_shell")

        if has_todo_match:
            selected_names.add("todo_list")
            selected_names.add("exec_shell")

        return selected_names
