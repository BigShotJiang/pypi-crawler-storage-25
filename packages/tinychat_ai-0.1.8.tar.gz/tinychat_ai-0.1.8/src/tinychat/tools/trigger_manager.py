"""Tool trigger words manager for multi-language tool invocation enhancement."""

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from tinychat.utils.i18n import get_current_locale

logger = logging.getLogger(__name__)


@dataclass
class ToolTriggerConfig:
    """Tool trigger words configuration for a single tool."""

    triggers: dict[str, list[str]] = field(default_factory=dict)  # language -> words
    weights: dict[str, float] = field(default_factory=dict)  # language -> weight
    priority: float = 1.0  # tool priority (0.0-1.0)

    def get_triggers(self, language: str) -> list[str]:
        """Get trigger words for specific language."""
        return self.triggers.get(language, [])

    def get_weight(self, language: str) -> float:
        """Get weight for specific language."""
        return self.weights.get(language, 1.0)


class TriggerWordsLoader:
    """Loader for tool trigger words configuration."""

    def __init__(self, config_dir: Path | None = None):
        """Initialize the loader.

        Args:
            config_dir: Directory containing trigger config files.
                       Defaults to package's trigger_config directory.
        """
        if config_dir is None:
            config_dir = Path(__file__).parent / "trigger_config"
        self.config_dir = config_dir
        self._cache: dict[str, dict[str, ToolTriggerConfig]] = {}

    def load_for_language(self, language: str) -> dict[str, ToolTriggerConfig]:
        """Load trigger configuration for specific language.

        Args:
            language: Language code (e.g., 'en', 'zh')

        Returns:
            Dictionary mapping tool names to their trigger configurations.
        """
        if language in self._cache:
            return self._cache[language]

        config = self._load_config(language)
        self._cache[language] = config
        return config

    def _load_config(self, language: str) -> dict[str, ToolTriggerConfig]:
        """Load configuration from file."""
        config_path = self.config_dir / f"{language}.json"

        if not config_path.exists():
            logger.debug("No trigger config for language '%s', using default", language)
            return self._load_default_config()

        try:
            with open(config_path, encoding="utf-8") as f:
                raw_config = json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to load trigger config for '%s': %s", language, e)
            return self._load_default_config()

        return self._parse_config(raw_config)

    def _load_default_config(self) -> dict[str, ToolTriggerConfig]:
        """Load default configuration."""
        default_path = self.config_dir / "default.json"

        if not default_path.exists():
            logger.warning("No default trigger config found, returning empty config")
            return {}

        try:
            with open(default_path, encoding="utf-8") as f:
                raw_config = json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to load default trigger config: %s", e)
            return {}

        return self._parse_config(raw_config)

    def _parse_config(self, raw_config: dict[str, Any]) -> dict[str, ToolTriggerConfig]:
        """Parse raw JSON config into ToolTriggerConfig objects."""
        configs = {}

        for tool_name, tool_config in raw_config.items():
            triggers = tool_config.get("triggers", {})
            weights = tool_config.get("weights", {})
            priority = tool_config.get("priority", 1.0)

            configs[tool_name] = ToolTriggerConfig(
                triggers=triggers,
                weights=weights,
                priority=priority,
            )

        return configs


class TriggerDetector:
    """Detect tool triggers in user input."""

    def __init__(self, language: str | None = None):
        """Initialize the detector.

        Args:
            language: Language code. If None, uses current locale.
        """
        if language is None:
            language = get_current_locale()
        self.language = language
        self.loader = TriggerWordsLoader()
        self.config = self.loader.load_for_language(language)

    def detect(self, text: str, tool_name: str) -> float:
        """Detect if text triggers a specific tool.

        Args:
            text: User input text.
            tool_name: Name of the tool to check.

        Returns:
            Trigger score between 0.0 and 1.0.
        """
        if tool_name not in self.config:
            return 0.0

        tool_config = self.config[tool_name]
        triggers = tool_config.get_triggers(self.language)

        if not triggers:
            return 0.0

        # Count matches
        matches = 0
        text_lower = text.lower()

        for word in triggers:
            if word.lower() in text_lower:
                matches += 1

        # Calculate base score
        base_score = matches / len(triggers)

        # Apply language weight and tool priority
        weight = tool_config.get_weight(self.language)
        priority = tool_config.priority

        return base_score * weight * priority

    def detect_all(self, text: str, tool_names: list[str]) -> list[tuple[str, float]]:
        """Detect triggers for multiple tools.

        Args:
            text: User input text.
            tool_names: List of tool names to check.

        Returns:
            List of (tool_name, score) tuples sorted by score descending.
        """
        results = []

        for tool_name in tool_names:
            score = self.detect(text, tool_name)
            if score > 0:
                results.append((tool_name, score))

        # Sort by score descending
        results.sort(key=lambda x: x[1], reverse=True)
        return results

    def get_top_triggers(
        self,
        text: str,
        tool_names: list[str],
        threshold: float = 0.3,
    ) -> list[str]:
        """Get tools with trigger score above threshold.

        Args:
            text: User input text.
            tool_names: List of tool names to check.
            threshold: Minimum score to include (default: 0.3).

        Returns:
            List of tool names with score above threshold.
        """
        triggered = self.detect_all(text, tool_names)
        return [tool for tool, score in triggered if score >= threshold]


# Convenience functions
def get_trigger_detector(language: str | None = None) -> TriggerDetector:
    """Get a trigger detector for the specified language."""
    return TriggerDetector(language)


def detect_tool_triggers(
    text: str,
    tool_names: list[str],
    language: str | None = None,
) -> list[tuple[str, float]]:
    """Convenience function to detect triggers for multiple tools."""
    detector = get_trigger_detector(language)
    return detector.detect_all(text, tool_names)
