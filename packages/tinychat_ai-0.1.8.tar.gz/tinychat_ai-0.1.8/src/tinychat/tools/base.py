"""Tool base classes and data models."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from tinychat.tools.trigger_manager import ToolTriggerConfig, TriggerWordsLoader


@dataclass
class ToolParameter:
    """Tool parameter definition."""

    name: str
    type: str
    description: str
    required: bool = True
    enum: list[str] | None = None
    default: Any = None


@dataclass
class ToolResult:
    """Tool execution result."""

    success: bool
    output: str
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class Tool(ABC):
    """Abstract base class for tools."""

    def __init__(self):
        """Initialize tool with trigger words loader."""
        self._trigger_loader = TriggerWordsLoader()
        self._trigger_cache: dict[str, ToolTriggerConfig] = {}

    @property
    @abstractmethod
    def name(self) -> str:
        """Tool unique identifier."""

    @property
    @abstractmethod
    def description(self) -> str:
        """Tool description shown to LLM."""

    @property
    @abstractmethod
    def parameters(self) -> list[ToolParameter]:
        """Parameter definitions."""

    @abstractmethod
    async def execute(self, arguments: dict[str, Any]) -> ToolResult:
        """Execute tool logic."""

    def get_trigger_config(self, language: str) -> ToolTriggerConfig:
        """Get trigger configuration for this tool.

        Args:
            language: Language code (e.g., 'en', 'zh')

        Returns:
            ToolTriggerConfig for this tool and language.
        """
        cache_key = f"{self.name}:{language}"

        if cache_key in self._trigger_cache:
            return self._trigger_cache[cache_key]

        # Load configuration for the language
        configs = self._trigger_loader.load_for_language(language)
        tool_config = configs.get(self.name)

        if not tool_config:
            # Fall back to default configuration
            default_configs = self._trigger_loader.load_for_language("default")
            tool_config = default_configs.get(self.name, ToolTriggerConfig())

        self._trigger_cache[cache_key] = tool_config
        return tool_config

    def get_trigger_words(self, language: str) -> list[str]:
        """Get trigger words for this tool in specified language.

        Args:
            language: Language code (e.g., 'en', 'zh')

        Returns:
            List of trigger words for this tool.
        """
        config = self.get_trigger_config(language)
        return config.get_triggers(language)

    @property
    def short_description(self) -> str:
        """Short description for UI display.

        Returns:
            Truncated description (max 50 chars) with ellipsis if needed.
        """
        if len(self.description) <= 50:
            return self.description
        return self.description[:47] + "..."

    @property
    def icon(self) -> str:
        """Tool icon for UI display.

        Returns:
            Unicode icon based on tool name and category.
        """
        # Default icon based on tool name
        tool_name = self.name.lower()

        # Todo operations (must be checked before file operations)
        if any(keyword in tool_name for keyword in ["todo", "task", "workflow"]):
            return "✅"
        # File operations
        elif any(keyword in tool_name for keyword in ["file", "read", "write", "edit"]):
            return "📄"
        # Directory operations
        elif any(keyword in tool_name for keyword in ["directory", "list"]):
            return "📁"
        # Shell/command operations
        elif any(
            keyword in tool_name for keyword in ["shell", "exec", "run", "command"]
        ):
            return "💻"
        # Search operations
        elif any(
            keyword in tool_name for keyword in ["search", "find", "grep", "glob"]
        ):
            return "🔍"
        # Web operations
        elif any(keyword in tool_name for keyword in ["web", "http", "url"]):
            return "🌐"
        # Database operations
        elif any(keyword in tool_name for keyword in ["db", "database", "query"]):
            return "🗄️"
        # Default tool icon
        else:
            return "🛠️"

    @property
    def important_parameters(self) -> list[str]:
        """Important parameters for UI preview display.

        Returns:
            List of parameter names that should be shown in UI preview.
            By default, returns first 3 required parameters.
        """
        required_params = [p.name for p in self.parameters if p.required]

        # Return first 3 required parameters, or all if less than 3
        return required_params[:3]

    def to_openai_schema(self) -> dict:
        """Convert to OpenAI tool schema format."""
        properties = {}
        required = []

        for param in self.parameters:
            prop_schema: dict[str, Any] = {
                "type": param.type,
                "description": param.description,
            }
            if param.enum is not None:
                prop_schema["enum"] = param.enum
            properties[param.name] = prop_schema

            if param.required:
                required.append(param.name)

        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
        }
