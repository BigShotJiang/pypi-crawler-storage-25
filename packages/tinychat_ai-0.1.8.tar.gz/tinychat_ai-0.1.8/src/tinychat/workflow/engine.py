"""Simple workflow execution engine."""

from __future__ import annotations

import asyncio
import copy
import logging
import re
from datetime import datetime
from typing import Any, Callable

from tinychat.models.workflow import (
    WorkflowDefinition,
    WorkflowStep,
)
from tinychat.tools.base import Tool
from tinychat.tools.executor import ToolExecutor

logger = logging.getLogger(__name__)


class WorkflowEngine:
    """Simple workflow execution engine."""

    def __init__(self, todo_tool: Tool, tool_executor: ToolExecutor):
        """Initialize the workflow engine.

        Args:
            todo_tool: Enhanced todo_list tool instance.
            tool_executor: Tool executor.
        """
        self.todo_tool = todo_tool
        self.tool_executor = tool_executor
        self._tools: dict[str, Tool] = {}
        self._background_tasks: set[asyncio.Task] = set()

    def register_tool(self, tool: Tool) -> None:
        """Register a tool."""
        self._tools[tool.name] = tool

    async def create_workflow(self, definition: dict[str, Any]) -> str:
        """Create a workflow definition."""

        # 验证工作流定义
        self._validate_workflow_definition(definition)

        # 转换为WorkflowDefinition, 将生成的workflow_id写回definition
        parsed = self._parse_workflow_definition(definition)
        definition["workflow_id"] = parsed.workflow_id

        # 使用todo_tool创建工作流
        result = await self.todo_tool.execute(
            {"action": "create_workflow", "workflow_definition": definition},
        )

        if not result.success:
            msg = f"Create workflow failed: {result.error}"
            raise ValueError(msg)

        return result.metadata["workflow_id"]

    async def start_execution(self, workflow_id: str) -> str:
        """Start workflow execution."""

        # 使用todo_tool开始执行
        result = await self.todo_tool.execute(
            {"action": "start_execution", "workflow_id": workflow_id},
        )

        if not result.success:
            msg = f"Start execution failed: {result.error}"
            raise ValueError(msg)

        execution_id = result.metadata["execution_id"]

        task = asyncio.create_task(self._execute_workflow(execution_id))
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)

        return execution_id

    async def get_status(self, execution_id: str) -> dict[str, Any]:
        """Get execution status."""

        result = await self.todo_tool.execute(
            {"action": "get_status", "execution_id": execution_id},
        )

        if not result.success:
            msg = f"Get status failed: {result.error}"
            raise ValueError(msg)

        return result.metadata

    async def pause_execution(self, execution_id: str) -> None:
        """Pause execution."""

        result = await self.todo_tool.execute(
            {"action": "pause_execution", "execution_id": execution_id},
        )

        if not result.success:
            msg = f"Pause execution failed: {result.error}"
            raise ValueError(msg)

    async def resume_execution(self, execution_id: str) -> None:
        """Resume execution."""

        result = await self.todo_tool.execute(
            {"action": "resume_execution", "execution_id": execution_id},
        )

        if not result.success:
            msg = f"Resume execution failed: {result.error}"
            raise ValueError(msg)

        task = asyncio.create_task(self._execute_workflow(execution_id))
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)

    async def cancel_execution(self, execution_id: str) -> None:
        """Cancel execution."""

        result = await self.todo_tool.execute(
            {"action": "cancel_execution", "execution_id": execution_id},
        )

        if not result.success:
            msg = f"Cancel execution failed: {result.error}"
            raise ValueError(msg)

    async def list_workflows(self) -> list[dict[str, Any]]:
        """List all workflows."""

        result = await self.todo_tool.execute({"action": "list_workflows"})

        if not result.success:
            msg = f"List workflows failed: {result.error}"
            raise ValueError(msg)

        return result.metadata.get("workflows", [])

    async def delete_workflow(self, workflow_id: str) -> None:
        """Delete a workflow."""

        result = await self.todo_tool.execute(
            {"action": "delete_workflow", "workflow_id": workflow_id},
        )

        if not result.success:
            msg = f"Delete workflow failed: {result.error}"
            raise ValueError(msg)

    def resume_running_executions(self) -> list[str]:
        """Resume all unfinished executions.

        Returns:
            List of resumed execution IDs.
        """
        resumed: list[str] = []
        for execution_id in self.todo_tool.get_all_execution_ids():
            state = self.todo_tool.get_execution_state(execution_id)
            if state and state.get("status") in ("running", "paused"):
                logger.info("Resuming unfinished execution: %s", execution_id)
                task = asyncio.create_task(self._execute_workflow(execution_id))
                self._background_tasks.add(task)
                task.add_done_callback(self._background_tasks.discard)
                resumed.append(execution_id)
        return resumed

    async def _execute_workflow(self, execution_id: str) -> None:
        """Execute a workflow (background task)."""

        logger.info("Starting workflow execution: %s", execution_id)

        try:
            execution_state = self.todo_tool.get_execution_state(execution_id)
            if not execution_state:
                logger.error("Execution state not found: %s", execution_id)
                return

            workflow_id = execution_state["workflow_id"]

            workflow_def_dict = self.todo_tool.get_workflow_definition(workflow_id)
            if not workflow_def_dict:
                logger.error("Workflow definition not found: %s", workflow_id)
                return

            workflow_def = self._parse_workflow_definition(workflow_def_dict)

            await self._run_step_loop(execution_id, workflow_def, execution_state)

            logger.info(
                "Workflow execution finished: %s, status: %s",
                execution_id,
                execution_state.get("status"),
            )

        except Exception as e:
            logger.error("Workflow execution exception: %s", e, exc_info=True)
            await self._mark_execution_failed(execution_id, e)

    async def _run_step_loop(
        self,
        execution_id: str,
        workflow_def: WorkflowDefinition,
        execution_state: dict[str, Any],
    ) -> None:
        """Run the main step execution loop."""
        while execution_state["status"] in ["running", "paused"]:
            if execution_state["status"] == "paused":
                execution_state = await self._handle_paused(
                    execution_id, execution_state
                )
                if execution_state is None:
                    break
                continue

            next_step = self._get_next_step(workflow_def, execution_state)

            if not next_step:
                has_failures = bool(execution_state.get("failed_steps"))
                if has_failures:
                    await self._mark_execution_failed(
                        execution_id,
                        RuntimeError("One or more steps failed"),
                    )
                else:
                    await self.todo_tool.execute(
                        {
                            "action": "update_step",
                            "execution_id": execution_id,
                            "step_id": "__completed__",
                            "step_result": {
                                "success": True,
                                "output": "All steps completed",
                                "metadata": {"completed": True},
                            },
                        },
                    )
                break

            step_result = await self._execute_step(next_step, execution_id)

            if not step_result.get("success", False):
                logger.warning(
                    "Step %s failed: %s",
                    next_step.id,
                    step_result.get("error"),
                )

            update_result = await self.todo_tool.execute(
                {
                    "action": "update_step",
                    "execution_id": execution_id,
                    "step_id": next_step.id,
                    "step_result": step_result,
                },
            )

            if not update_result.success:
                logger.error("Update step status failed: %s", update_result.error)

            execution_state = self.todo_tool.get_execution_state(execution_id)
            if not execution_state:
                logger.error("Failed to get updated state: %s", execution_id)
                break

            await asyncio.sleep(0.1)

    async def _handle_paused(
        self,
        execution_id: str,
        execution_state: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Handle paused execution state. Returns None if state is lost."""
        await asyncio.sleep(1)
        execution_state = self.todo_tool.get_execution_state(execution_id)
        if not execution_state:
            return None
        return execution_state

    async def _mark_execution_failed(self, execution_id: str, error: Exception) -> None:
        """Mark a workflow execution as failed due to an exception."""
        try:
            await self.todo_tool.execute(
                {
                    "action": "update_step",
                    "execution_id": execution_id,
                    "step_id": "__failed__",
                    "step_result": {
                        "success": False,
                        "output": f"Execution exception: {str(error)}",
                        "error": str(error),
                        "metadata": {"exception": True},
                    },
                },
            )
        except Exception:
            logger.exception("Failed to update failure status")

    async def _execute_step(
        self,
        step: WorkflowStep,
        execution_id: str,
    ) -> dict[str, Any]:
        """Execute a single step."""

        logger.info("Executing step: %s - %s", step.id, step.name)

        try:
            # 检查工具是否存在
            if step.tool not in self._tools:
                return {
                    "success": False,
                    "output": f"Tool not found: {step.tool}",
                    "error": f"Tool not found: {step.tool}",
                    "metadata": {"tool_missing": True},
                }

            tool = self._tools[step.tool]

            # 处理变量替换
            arguments = self._resolve_variables(step.arguments, {})

            tool_result = await tool.execute(arguments)

            return {
                "success": tool_result.success,
                "output": tool_result.output,
                "error": tool_result.error,
                "metadata": tool_result.metadata,
            }

        except Exception as e:
            logger.error("Step execution exception: %s - %s", step.id, e, exc_info=True)
            return {
                "success": False,
                "output": f"Step execution exception: {str(e)}",
                "error": str(e),
                "metadata": {"exception": True},
            }

    def _validate_workflow_definition(self, definition: dict[str, Any]) -> None:
        """Validate the workflow definition."""

        if not isinstance(definition, dict):
            msg = "Workflow definition must be a dict"
            raise ValueError(msg)

        self._validate_required_fields(definition)
        self._validate_steps(definition.get("steps", []))

    def _validate_required_fields(self, definition: dict[str, Any]) -> None:
        """Validate that required top-level fields are present."""
        required_fields = ["name", "steps"]
        for field_name in required_fields:
            if field_name not in definition:
                msg = f"Missing required field: {field_name}"
                raise ValueError(msg)

    def _validate_steps(self, steps: list[Any]) -> None:
        """Validate the steps list structure."""
        if not isinstance(steps, list):
            msg = "steps must be a list"
            raise ValueError(msg)

        if len(steps) == 0:
            msg = "steps cannot be empty"
            raise ValueError(msg)

        step_ids: set[str] = set()
        for i, step in enumerate(steps):
            self._validate_single_step(i, step, step_ids)

    def _validate_single_step(
        self,
        index: int,
        step: Any,
        seen_ids: set[str],
    ) -> None:
        """Validate a single workflow step."""
        if not isinstance(step, dict):
            msg = f"Step {index} must be a dict"
            raise ValueError(msg)

        required_step_fields = ["id", "name", "tool"]
        for field_name in required_step_fields:
            if field_name not in step:
                msg = f"Step {index} missing field: {field_name}"
                raise ValueError(msg)

        step_id = step["id"]
        if step_id in seen_ids:
            msg = f"Duplicate step ID: {step_id}"
            raise ValueError(msg)
        seen_ids.add(step_id)

    def _parse_workflow_definition(
        self,
        definition: dict[str, Any],
    ) -> WorkflowDefinition:
        """Parse the workflow definition."""

        workflow_id = (
            definition.get("workflow_id") or f"workflow_{datetime.now().timestamp()}"
        )

        steps = []
        for step_def in definition.get("steps", []):
            step = WorkflowStep(
                id=step_def["id"],
                name=step_def["name"],
                tool=step_def["tool"],
                arguments=step_def.get("arguments", {}),
                depends_on=step_def.get("depends_on", []),
                timeout=step_def.get("timeout"),
                max_retries=step_def.get("max_retries", 1),
                requires_confirmation=step_def.get("requires_confirmation", False),
            )
            steps.append(step)

        return WorkflowDefinition(
            workflow_id=workflow_id,
            name=definition["name"],
            description=definition.get("description", ""),
            steps=steps,
            variables=definition.get("variables", {}),
            version=definition.get("version", "1.0"),
        )

    def _get_next_step(
        self,
        workflow_def: WorkflowDefinition,
        execution_state: dict[str, Any],
    ) -> WorkflowStep | None:
        """Get the next executable step."""

        completed_steps = set(execution_state.get("completed_steps", []))
        failed_steps = set(execution_state.get("failed_steps", []))

        for step in workflow_def.steps:
            # 如果步骤已经完成或失败，跳过
            if step.id in completed_steps or step.id in failed_steps:
                continue

            # 检查依赖是否满足
            depends_on = set(step.depends_on)
            if depends_on.issubset(completed_steps):
                return step

        return None

    _VAR_PATTERN = re.compile(r"\{\{(\w+)\}\}")

    def _resolve_variables(
        self,
        arguments: dict[str, Any],
        variables: dict[str, Any],
    ) -> dict[str, Any]:
        """Substitute {{variable_name}} placeholders in argument values."""

        def _replace(value: Any) -> Any:
            if isinstance(value, str):
                return self._VAR_PATTERN.sub(
                    lambda m: str(variables.get(m.group(1), m.group(0))),
                    value,
                )
            if isinstance(value, dict):
                return {k: _replace(v) for k, v in value.items()}
            if isinstance(value, list):
                return [_replace(v) for v in value]
            return value

        return _replace(copy.deepcopy(arguments))


class WorkflowManager:
    """Workflow manager (advanced interface)."""

    def __init__(self, engine: WorkflowEngine):
        self.engine = engine
        self._execution_callbacks: dict[str, list[Callable]] = {}

    async def create_and_execute(self, definition: dict[str, Any]) -> str:
        """Create and immediately execute a workflow."""

        # 创建工作流
        workflow_id = await self.engine.create_workflow(definition)

        # 开始执行
        execution_id = await self.engine.start_execution(workflow_id)

        return execution_id

    async def monitor_execution(
        self,
        execution_id: str,
        on_status_change: Callable | None = None,
        on_step_complete: Callable | None = None,
    ) -> dict[str, Any]:
        """Monitor execution status."""

        final_status = None

        try:
            while True:
                # 获取当前状态
                status = await self.engine.get_status(execution_id)

                current_status = status.get("status")

                # 调用状态变化回调
                if on_status_change and final_status != current_status:
                    on_status_change(current_status, status)
                    final_status = current_status

                # 检查是否完成
                if current_status in ["completed", "failed", "cancelled"]:
                    break

                # 等待一段时间再检查
                await asyncio.sleep(1)

            return status

        except Exception as e:
            logger.error("Monitor execution exception: %s", e, exc_info=True)
            raise

    async def create_example_workflow(self, goal: str) -> str:
        """Create a sample workflow (auto-generated based on goal)."""

        # 这里可以集成LLM来生成工作流定义
        # 目前返回一个简单的示例工作流

        example_workflow = {
            "name": f"Process task: {goal[:50]}...",
            "description": f"Auto-generated workflow for: {goal}",
            "steps": [
                {
                    "id": "step_1",
                    "name": "Analyze task requirements",
                    "tool": "no_action",  # 使用no_action作为占位符
                    "arguments": {"task": goal},
                    "depends_on": [],
                },
                {
                    "id": "step_2",
                    "name": "Execute main operation",
                    "tool": "no_action",
                    "arguments": {"action": "process"},
                    "depends_on": ["step_1"],
                },
                {
                    "id": "step_3",
                    "name": "Generate result report",
                    "tool": "no_action",
                    "arguments": {"report": True},
                    "depends_on": ["step_2"],
                },
            ],
            "variables": {"goal": goal},
        }

        return await self.create_and_execute(example_workflow)
