"""Main Textual-based application for TinyChat."""

import asyncio
import json
import logging
import time
import uuid
from collections.abc import Iterable
from dataclasses import dataclass as _dataclass
from dataclasses import replace
from datetime import datetime
from typing import TYPE_CHECKING, ClassVar

from textual import work
from textual.app import App, ComposeResult, SystemCommand
from textual.binding import Binding, BindingsMap
from textual.command import CommandPalette, Provider
from textual.message import Message as TextualMessage
from textual.reactive import reactive, var
from textual.screen import Screen
from textual.widgets import Static
from textual.worker import Worker, WorkerState

from tinychat.backends.base import Backend
from tinychat.compaction.manager import CompactionManager, load_compaction_config
from tinychat.components.chat_view import ChatView
from tinychat.components.input_area import InputArea
from tinychat.components.sidebar import (
    BackendSwitchRequested,
    ModelSwitchRequested,
    QuestionJumpRequested,
    Sidebar,
)
from tinychat.components.status_bar import StatusBar
from tinychat.components.workflow_progress_widget import WorkflowProgressWidget
from tinychat.models.message import Message, ToolCall
from tinychat.models.session import ChatSession, SessionSummary
from tinychat.models.workflow import WorkflowState
from tinychat.tools.manager import PluginManager
from tinychat.tools.workflow_manager import WorkflowManager
from tinychat.utils.config_manager import (
    load_logging_config,
    load_user_config,
    save_user_config,
)
from tinychat.utils.i18n import _, get_available_locales, get_current_locale, set_locale
from tinychat.utils.http_client import HttpClientManager
from tinychat.utils.logging_config import setup_logging
from tinychat.utils.metrics import MetricsCollector

MAX_TITLE_DISPLAY_LENGTH = 50
MAX_TOOL_INVOCATION_DEPTH = 50
DEFAULT_VIRTUALIZATION_THRESHOLD: int = 28
DEFAULT_VISIBLE_MESSAGE_COUNT: int = 30
DEFAULT_LOADING_BATCH_SIZE: int = 15
DEFAULT_LOADING_FRAME_DELAY: float = 0.016

if TYPE_CHECKING:
    from tinychat.db.connection import DatabaseManager
    from tinychat.tools.adapter import ToolCallingAdapter
    from tinychat.tools.base import Tool, ToolResult
    from tinychat.tools.executor import ToolExecutor
    from tinychat.utils.session_manager import SessionManager
    from tinychat.utils.session_persistence import SessionPersistence
    from tinychat.workflow.engine import WorkflowEngine

logger = logging.getLogger(__name__)


@_dataclass
class _LLMStreamResult:
    content: str
    reasoning_content: str | None
    pending_tool_calls: list[tuple[str, dict, str]]
    error_occurred: bool
    cancelled_by_user: bool


class _PatchableVar(var):
    def __delete__(self, obj: object) -> None:
        pass


def _get_key_hint_provider() -> type[Provider]:
    from tinychat.components.key_hint_provider import KeyHintProvider

    return KeyHintProvider


class SessionChangedMessage(TextualMessage):
    """Message sent when the current session changes."""

    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        super().__init__()


class TinyChatApp(App):
    """Main Textual-based application orchestrator."""

    CSS_PATH = "styles/app.css"
    COMMANDS = {_get_key_hint_provider}

    BINDINGS: ClassVar[list] = [
        Binding("escape", "escape", _("Cancel"), show=True),
        Binding("ctrl+b", "toggle_backend_panel", _("Backend Panel"), show=True),
        Binding("ctrl+q", "quit", _("Quit"), show=True),
        Binding("ctrl+p", "command_palette", _("Command Palette"), show=True),
        Binding("ctrl+t", "new_session", _("New Session"), show=True),
        Binding("ctrl+l", "show_sessions", _("Sessions"), show=True),
        Binding("alt+m", "message_actions", _("Message Actions"), show=True),
    ]

    current_backend_name: reactive[str] = reactive("")
    current_session: reactive[ChatSession | None] = reactive(None)
    sessions: reactive[list[ChatSession]] = reactive(list)
    messages: reactive[list[Message]] = reactive(list)
    is_generating: var[bool] = _PatchableVar(False)
    connection_status: var[str] = var("disconnected")
    metrics: var[dict] = var(dict)
    show_backend_panel: var[bool] = var(False)
    show_navigation_panel: var[bool] = var(False)
    show_todo_panel: var[bool] = var(False)
    _has_status_error: bool = False
    # Per-invocation workflow manager (temporary, cleared on new message)
    current_workflow_manager: WorkflowManager | None = None

    def __init__(self, debug_no_compaction_limit: bool = False) -> None:
        """Initialize the TinyChat application.

        Args:
            debug_no_compaction_limit: Debug mode - skip token limit check for compaction.
        """
        super().__init__()
        self._debug_no_compaction_limit = debug_no_compaction_limit

        # Initialize logging first
        logging_config = load_logging_config()
        setup_logging(
            enabled=logging_config.enabled,
            level=logging_config.level,
            file=logging_config.file,
            max_size_mb=logging_config.max_size_mb,
            backup_count=logging_config.backup_count,
        )
        logger.info("Application starting")

        self._backends: dict[str, Backend] = {}
        self._available_models: list[str] = []
        self.http_manager = HttpClientManager()
        self.metrics_collector = MetricsCollector()
        self.tools: list[Tool] = []
        self.tool_executor: ToolExecutor | None = None
        self._workflow_engine: WorkflowEngine | None = None
        self._tool_adapter: ToolCallingAdapter | None = None
        self._plugin_manager: PluginManager | None = None
        self._tool_invocation_depth: int = 0
        self._streaming_queue: asyncio.Queue[str | None] = asyncio.Queue()
        self._streaming_consumer_task: asyncio.Task | None = None
        # Session management
        self.session_manager: SessionManager | None = None
        self._persistence: SessionPersistence | None = None
        self._db_manager: DatabaseManager | None = None
        self.workflow_managers: dict[str, WorkflowManager] = {}
        # Compaction management
        self._compaction_manager: CompactionManager | None = None
        self._compaction_tasks: set[asyncio.Task] = set()
        # UI update control flag (used to prevent flicker during compaction)
        self._skip_watch: bool = False
        # Progressive loading: track timers for cancellation
        self._progressive_load_timers: list = []

    def _ensure_tools_initialized(self) -> None:
        """Initialize tools system on first use (lazy loading)."""
        if self._plugin_manager is None:
            self._initialize_tools()

    def _initialize_tools(self) -> None:
        """Initialize the tools system."""
        from tinychat.tools.executor import ToolExecutor  # noqa: PLC0415
        from tinychat.workflow.engine import WorkflowEngine  # noqa: PLC0415

        self._plugin_manager = PluginManager()
        self.tools = self._plugin_manager.instantiate_tools()

        if self.tools:
            from tinychat.utils.config_manager import get_config_path  # noqa: PLC0415

            session_id = self.current_session.id if self.current_session else "default"
            workflow_manager = WorkflowManager(session_id=session_id, app=self)
            self.workflow_managers[session_id] = workflow_manager

            self.tool_executor = ToolExecutor(
                self,
                self.tools,
                config_path=get_config_path(),
                workflow_manager=workflow_manager,
            )

            todo_tool = next((t for t in self.tools if t.name == "todo_list"), None)
            if todo_tool and self.tool_executor:
                from tinychat.db.todo_dao import TodoListDAO  # noqa: PLC0415

                dao = TodoListDAO(self._db_manager.connection)
                todo_tool.set_dao(dao)
                todo_tool.set_session_id(session_id)
                engine = WorkflowEngine(
                    todo_tool=todo_tool,
                    tool_executor=self.tool_executor,
                )
                for tool in self.tools:
                    engine.register_tool(tool)
                todo_tool.set_workflow_engine(engine)
                self._workflow_engine = engine

            backend = self._get_backend()
            if backend:
                adapter_cls = self._select_tool_adapter(backend)
                self._tool_adapter = adapter_cls(backend)

            compaction_config = load_compaction_config()
            compaction_config.debug_no_limit = self._debug_no_compaction_limit
            try:
                status_bar = self.query_one(StatusBar)
                chat_view = self.query_one(ChatView)
            except Exception:  # noqa: BLE001
                status_bar = None
                chat_view = None
            self._compaction_manager = CompactionManager(
                config=compaction_config,
                status_bar=status_bar,
                chat_view=chat_view,
            )
        else:
            self.tool_executor = None
            self._tool_adapter = None
            # Always initialize CompactionManager even if no tools are available
            compaction_config = load_compaction_config()
            compaction_config.debug_no_limit = self._debug_no_compaction_limit
            try:
                status_bar = self.query_one(StatusBar)
                chat_view = self.query_one(ChatView)
            except Exception:  # noqa: BLE001
                status_bar = None
                chat_view = None
            self._compaction_manager = CompactionManager(
                config=compaction_config,
                status_bar=status_bar,
                chat_view=chat_view,
            )

    def get_or_create_workflow_manager(self, session_id: str) -> WorkflowManager:
        """Get or create a workflow manager for a session.

        Args:
            session_id: The session ID.

        Returns:
            WorkflowManager instance.
        """
        if session_id not in self.workflow_managers:
            self.workflow_managers[session_id] = WorkflowManager(
                session_id=session_id,
                app=self,
            )
        return self.workflow_managers[session_id]

    def mount_workflow_progress_widget(
        self, workflow_manager: WorkflowManager
    ) -> WorkflowProgressWidget:
        """Mount a workflow progress widget to the chat view.

        Args:
            workflow_manager: The workflow manager whose state to display.

        Returns:
            The mounted WorkflowProgressWidget.
        """
        chat_view = self._get_current_chat_view()
        if not chat_view:
            return None  # type: ignore[return-value]

        # Build callbacks that delegate to ToolExecutor
        on_confirm = None
        on_deny = None
        on_edit = None
        on_retry = None

        if self.tool_executor:

            def on_confirm(cid):  # type: ignore[misc]
                return self.tool_executor._handle_inline_confirmation(cid, True)  # type: ignore[attr-defined]

            def on_deny(cid):  # type: ignore[misc]
                return self.tool_executor._handle_inline_confirmation(cid, False)  # type: ignore[attr-defined]

            def on_edit(cid, args):  # type: ignore[misc]
                return self.tool_executor._handle_edit(cid, args)  # type: ignore[attr-defined]

            def on_retry(cid, args):  # type: ignore[misc]
                return self.tool_executor._handle_retry(cid, args)  # type: ignore[attr-defined]

        widget = chat_view.mount_workflow_progress_widget(
            workflow_state=workflow_manager.state,
            tools=self.tool_executor.tools if self.tool_executor else {},
            on_confirm=on_confirm,
            on_deny=on_deny,
            on_edit=on_edit,
            on_retry=on_retry,
        )

        # Register state update listener
        def on_state_update(state: WorkflowState) -> None:
            self.call_next(lambda: self._update_workflow_display(widget, state))

        workflow_manager.add_listener(on_state_update)
        return widget

    def _update_workflow_display(
        self,
        widget: WorkflowProgressWidget,
        state: WorkflowState,
    ) -> None:
        """Update workflow progress widget display.

        Args:
            widget: The widget to update.
            state: The new workflow state.
        """
        chat_view = self._get_current_chat_view()
        if not chat_view:
            return
        chat_view.update_workflow_progress_widget(widget, state)

    @staticmethod
    def _select_tool_adapter(backend: Backend) -> type:
        """Select appropriate tool calling adapter based on backend capability.

        Uses NativeAdapter by default. Only falls back to PromptAdapter
        if the backend explicitly declares no native tool_calls support
        via get_info()['supports_native_tool_calls'] == False.

        Args:
            backend: The backend instance to check.

        Returns:
            NativeAdapter for backends that support native tool_calls,
            PromptAdapter for all others.
        """
        try:
            info = backend.get_info()
            if info.get("supports_native_tool_calls") is False:
                from tinychat.tools.adapter import PromptAdapter  # noqa: PLC0415

                return PromptAdapter
        except (AttributeError, KeyError, TypeError):  # noqa: BLE001
            pass

        from tinychat.tools.adapter import NativeAdapter  # noqa: PLC0415

        return NativeAdapter

    def register_backend(self, name: str, backend: Backend) -> None:
        """Register a backend instance with the given name.

        Args:
            name: Unique identifier for the backend.
            backend: Backend instance to register.
        """
        self._backends[name] = backend

    def _get_backend(self, backend_name: str | None = None) -> Backend | None:
        """Get backend by name or return first available.

        Args:
            backend_name: Optional name of specific backend to retrieve.

        Returns:
            Backend instance if found, None otherwise.
        """
        name = backend_name or self.current_backend_name
        if name and name in self._backends:
            return self._backends[name]
        return next(iter(self._backends.values()), None)

    def _create_default_session(self) -> ChatSession:
        """Create a default session quickly without I/O (synchronous).

        Uses the first backend's info to populate backend_name and model.
        Increments session manager's counter to ensure unique titles.
        This method is used during startup to provide immediate UI responsiveness.

        Returns:
            New ChatSession with generated ID and title.
        """
        backend = self._get_backend()
        info = backend.get_info() if backend else {}
        # Increment the session manager's counter for consistent numbering
        if self.session_manager:
            self.session_manager.session_counter += 1
            counter = self.session_manager.session_counter
        else:
            # Fallback to local counter if no session manager (should not happen)
            if not hasattr(self, "_fallback_counter"):
                self._fallback_counter = 0
            self._fallback_counter += 1
            counter = self._fallback_counter
        return ChatSession(
            id=str(uuid.uuid4()),
            title=f"Chat {counter}",
            backend_name=info.get("name", ""),
            model=info.get("default_model", ""),
        )

    async def _switch_backend(self, backend_name: str) -> None:
        if self.is_generating:
            return

        backend = self._backends.get(backend_name)
        if not backend:
            return

        self.current_backend_name = backend_name

        is_connected = await backend.test_connection()

        models: list[str] = []
        if is_connected:
            try:
                models = await backend.list_models()
            except Exception as e:  # noqa: BLE001
                logger.debug(
                    "Failed to list models for backend %s: %s", backend_name, e
                )
        self._available_models = models

        model = models[0] if models else ""

        try:
            status_bar = self.query_one(StatusBar)
        except Exception:  # noqa: BLE001
            status_bar = None

        try:
            sidebar = self.query_one(Sidebar)
        except Exception:  # noqa: BLE001
            sidebar = None

        if status_bar:
            status_bar.update_backend_info(backend_name=backend_name, model=model)
            status_bar.update_connection_status(
                "connected" if is_connected else "disconnected",
            )

        if sidebar:
            sidebar.set_selected_backend(backend_name)
            sidebar.set_selected_model(model)
            sidebar.set_available_models(models)

        if self.current_session:
            self.current_session.backend_name = backend_name
            self.current_session.model = model
            if self.session_manager:
                self.current_session.touch()
                self.session_manager._save_session_if_not_empty(self.current_session)
                await self._refresh_session_list()

    async def on_backend_switch_requested(
        self,
        message: BackendSwitchRequested,
    ) -> None:
        if self.is_generating:
            return
        await self._switch_backend(message.backend_name)

    async def on_model_switch_requested(self, message: ModelSwitchRequested) -> None:
        if self.is_generating:
            return

        if not self.current_session:
            return

        self.current_session.model = message.model_name
        if self.session_manager:
            self.current_session.touch()
            self.session_manager._save_session_if_not_empty(self.current_session)
            await self._refresh_session_list()

        try:
            status_bar = self.query_one(StatusBar)
        except Exception:  # noqa: BLE001
            status_bar = None

        if status_bar:
            status_bar.update_backend_info(
                backend_name=self.current_session.backend_name,
                model=message.model_name,
            )

        try:
            sidebar = self.query_one(Sidebar)
        except Exception:  # noqa: BLE001
            sidebar = None

        if sidebar:
            sidebar.set_selected_model(message.model_name)

    def _get_current_chat_view(self) -> ChatView | None:
        try:
            cv = self.query_one(ChatView)
            return cv
        except Exception:  # noqa: BLE001
            return None

    def _focus_input_area(self) -> None:
        """Focus the InputArea widget safely."""
        try:
            self.query_one(InputArea).focus()
        except Exception:  # noqa: BLE001
            pass

    def _get_or_create_chat_view(self, messages: list[Message]) -> ChatView:
        try:
            return self.query_one(ChatView)
        except Exception:  # noqa: BLE001
            pass
        from tinychat.components.left_panel import LeftPanel  # noqa: PLC0415

        try:
            left_panel = self.query_one(LeftPanel)
            chat_view = ChatView(messages=messages)
            left_panel.mount(chat_view, before=self.query_one(InputArea))
            return chat_view
        except Exception:  # noqa: BLE001
            chat_view = ChatView(messages=messages)
            self.mount(chat_view)
            return chat_view

    @staticmethod
    def _set_terminal_title(title: str) -> None:
        import os

        try:
            fd = os.open("/dev/tty", os.O_WRONLY)
            os.write(fd, f"\33]0;{title}\a".encode())
            os.close(fd)
        except OSError as e:
            logger.warning("Failed to set terminal title: %s", e)

    def _get_status_prefix(self) -> str:
        """Get status prefix for terminal title.

        Returns:
            Status prefix symbol: ○ (idle), ◐ (generating), 🔧 (executing tools), ✕ (error)
        """
        if self._has_status_error:
            return "✕"
        if self._tool_invocation_depth > 0:
            return "🔧"
        if self.is_generating:
            return "◐"
        return "○"

    def _sync_terminal_title(self) -> None:
        """Sync terminal window title with status prefix and session title."""
        prefix = self._get_status_prefix()
        if self.current_session:
            title = f"{prefix} TC#{self.current_session.title}"
        else:
            title = f"{prefix} TinyChat"
        self._set_terminal_title(title)

    def watch_current_session(
        self,
        old_session: ChatSession | None,
        new_session: ChatSession | None,
    ) -> None:
        self._sync_terminal_title()

    def watch_is_generating(self, old: bool, new: bool) -> None:
        """Update terminal title when generating state changes."""
        self._sync_terminal_title()

    def watch_messages(
        self,
        old_messages: list[Message],
        new_messages: list[Message],
    ) -> None:
        # Skip if _skip_watch flag is set (e.g., during compaction)
        if getattr(self, "_skip_watch", False):
            return

        if self.current_session:
            self.current_session.messages = list(new_messages)
            chat_view = None
            try:
                chat_view = self.query_one(ChatView)
            except Exception:  # noqa: BLE001
                pass
            if not (chat_view and chat_view.is_streaming()):
                if self.session_manager:
                    self.session_manager.schedule_save(self.current_session.id)

        try:
            if self.screen is None:
                return
        except Exception:  # noqa: BLE001
            return

        try:
            chat_view = self.query_one(ChatView)
            chat_view.messages = new_messages
        except Exception:  # noqa: BLE001
            pass

    def _update_bindings_i18n(self) -> None:
        """Update App-level binding descriptions with current locale translations."""
        translated_descriptions = {
            "escape": _("Cancel"),
            "toggle_backend_panel": _("Backend Panel"),
            "quit": _("Quit"),
            "command_palette": _("Command Palette"),
            "new_session": _("New Session"),
            "show_sessions": _("Sessions"),
            "message_actions": _("Message Actions"),
        }
        new_bindings = BindingsMap()
        for key, binding in self._bindings:
            if binding.action in translated_descriptions:
                new_bindings.bind(
                    binding.key,
                    binding.action,
                    translated_descriptions[binding.action],
                    show=binding.show,
                )
            else:
                new_bindings.bind(
                    binding.key,
                    binding.action,
                    binding.description,
                    show=binding.show,
                )
        self._bindings = new_bindings

    def _update_screen_bindings_i18n(self) -> None:
        """Update Screen-level binding descriptions with current locale translations."""
        screen = self.screen
        if screen is None:
            return
        translated_descriptions = {
            "app.focus_next": _("Focus Next"),
            "app.focus_previous": _("Focus Previous"),
            "screen.copy_text": _("Copy selected text"),
        }
        new_bindings = BindingsMap()
        for key, binding in screen._bindings:  # noqa: SLF001
            if binding.action in translated_descriptions:
                new_bindings.bind(
                    binding.key,
                    binding.action,
                    translated_descriptions[binding.action],
                    show=binding.show,
                )
            else:
                new_bindings.bind(
                    binding.key,
                    binding.action,
                    binding.description,
                    show=binding.show,
                )
        screen._bindings = new_bindings  # noqa: SLF001

    def compose(self) -> ComposeResult:
        """Compose the application layout."""
        from tinychat.components.left_panel import LeftPanel  # noqa: PLC0415
        from tinychat.components.todo_panel import TodoPanel  # noqa: PLC0415

        yield Static("", id="header-bar")

        with LeftPanel():
            yield ChatView(id="chat-view", messages=self.messages)
            yield InputArea()
        yield Sidebar(classes="hidden-panel")
        yield TodoPanel()
        yield StatusBar()

    def _update_header_bar(self) -> None:
        if self.current_session:
            title = self.current_session.title
            if len(title) > MAX_TITLE_DISPLAY_LENGTH:
                title = title[: MAX_TITLE_DISPLAY_LENGTH - 3] + "..."
            try:
                header = self.query_one("#header-bar", Static)
                header.update(f" {title} ")
            except Exception:  # noqa: BLE001
                pass
        else:
            try:
                header = self.query_one("#header-bar", Static)
                header.update(" TinyChat ")
            except Exception:  # noqa: BLE001
                pass

    async def on_mount(self) -> None:
        """Initialize application with non-blocking startup."""
        from pathlib import Path  # noqa: PLC0415

        from tinychat.db.connection import DatabaseManager  # noqa: PLC0415
        from tinychat.db.migration import JsonToSqliteMigrator  # noqa: PLC0415
        from tinychat.db.persistence import SQLitePersistence  # noqa: PLC0415
        from tinychat.utils.session_manager import SessionManager  # noqa: PLC0415

        mount_start = time.perf_counter()
        logger.debug("[PERF] on_mount started")

        self._update_bindings_i18n()
        self._update_screen_bindings_i18n()
        i18n_time = time.perf_counter() - mount_start

        if self._workflow_engine:
            resumed = self._workflow_engine.resume_running_executions()
            if resumed:
                logger.info(
                    "Resumed %d unfinished executions: %s",
                    len(resumed),
                    resumed,
                )

        self._restore_todo_display()
        restore_time = time.perf_counter() - mount_start

        # Initialize session manager with SQLite persistence
        persistence_start = time.perf_counter()
        sqlite_path = Path.home() / ".tinychat" / "tinychat.db"
        json_dir = Path.home() / ".tinychat" / "sessions"

        migrator = JsonToSqliteMigrator(json_dir=json_dir, sqlite_path=sqlite_path)
        if migrator.should_migrate():
            count = migrator.migrate()
            logger.info("Migrated %d sessions from JSON to SQLite", count)

        db_manager = DatabaseManager(db_path=sqlite_path)
        db_manager.initialize()
        self._db_manager = db_manager
        self._persistence = SQLitePersistence(db_path=sqlite_path)
        self.session_manager = SessionManager(self._persistence)
        persistence_time = time.perf_counter() - persistence_start
        logger.debug(
            "[PERF] Session manager initialized in %.2fms", persistence_time * 1000
        )

        # If no backends configured, nothing else to do
        if not self._backends:
            total_time = time.perf_counter() - mount_start
            logger.debug(
                "[PERF] on_mount completed (no backends): %.2fms", total_time * 1000
            )
            return

        # Create default session quickly (synchronous, no I/O)
        session_start = time.perf_counter()
        default_session = self._create_default_session()
        self.session_manager.sessions[default_session.id] = default_session
        self.session_manager.active_session_id = default_session.id
        self.current_session = default_session
        self.current_backend_name = default_session.backend_name
        self.messages = default_session.messages.copy()
        # Populate sessions list with just the current session (non-blocking)
        self.sessions = [self._session_to_summary(default_session)]
        session_time = time.perf_counter() - session_start
        logger.debug("[PERF] Default session created in %.2fms", session_time * 1000)

        # Schedule quick UI update after refresh to ensure widgets are ready
        self.call_after_refresh(self._update_ui_after_quick_init)

        # Start background initialization worker
        self._backend_init_worker()

        total_time = time.perf_counter() - mount_start
        logger.debug(
            "[PERF] on_mount completed (blocking part): %.2fms (i18n: %.2fms, restore: %.2fms, persistence: %.2fms, session: %.2fms)",
            total_time * 1000,
            i18n_time * 1000,
            restore_time * 1000,
            persistence_time * 1000,
            session_time * 1000,
        )

    def _update_status_bar_complete(
        self,
        backend_name: str,
        model: str,
        connection_status: str,
    ) -> None:
        """Update status bar with complete initialization info
        (called on main thread)."""
        try:
            status_bar = self.query_one(StatusBar)
            status_bar.update_backend_info(backend_name=backend_name, model=model)
            status_bar.update_connection_status(connection_status)
            status_bar.set_status("idle")  # Clear loading state
        except Exception as e:  # noqa: BLE001
            logger.debug("Failed to update status bar: %s", e)

    def _update_status_bar_error(self, error_message: str) -> None:
        """Update status bar with error (called on main thread)."""
        try:
            status_bar = self.query_one(StatusBar)
            status_bar.update_connection_status("error")
            status_bar.set_status("error", message=error_message)
        except Exception as e:  # noqa: BLE001
            logger.debug("Failed to update status bar error: %s", e)

    def _update_status_bar_warning(self, message: str) -> None:
        """Update status bar with warning (called on main thread)."""
        try:
            status_bar = self.query_one(StatusBar)
            # Note: StatusBar doesn't have explicit warning state, use idle
            # but log the warning
            status_bar.set_status("idle")
            logger.warning("Backend warning: %s", message)
        except Exception as e:  # noqa: BLE001
            logger.debug("Failed to update status bar warning: %s", e)

    def _update_sidebar_after_init(
        self,
        is_connected: bool,
        available_models: list[str],
    ) -> None:
        """Update sidebar after backend initialization (called on main thread)."""
        try:
            sidebar = self.query_one(Sidebar)
            sidebar.backends = list(self._backends.keys())
            if is_connected and available_models:
                sidebar.set_available_models(available_models)
            else:
                sidebar.set_available_models([])
            if self.current_session:
                sidebar.set_selected_backend(self.current_session.backend_name)
                sidebar.set_selected_model(self.current_session.model)
        except Exception as e:  # noqa: BLE001
            logger.debug("Failed to update sidebar: %s", e)

    def _update_ui_after_quick_init(self) -> None:
        """Update UI immediately after quick initialization to show connecting state."""
        try:
            status_bar = self.query_one(StatusBar)
            backend = self._get_backend()
            if backend:
                info = backend.get_info()
                status_bar.update_backend_info(
                    backend_name=info.get("name", ""),
                    model=info.get("default_model", ""),
                )
            status_bar.update_connection_status("connecting")
            status_bar.set_status("loading", message=_("Connecting..."))

            sidebar = self.query_one(Sidebar)
            sidebar.backends = list(self._backends.keys())
            # Do not set available_models here; worker will populate when ready
            if self.current_session:
                sidebar.set_selected_backend(self.current_session.backend_name)
                sidebar.set_selected_model(self.current_session.model)

            # Set current backend name reactive
            if self.current_session:
                self.current_backend_name = self.current_session.backend_name

            self._update_header_bar()

            # Create initial ChatView
            if self.current_session:
                try:
                    self._get_or_create_chat_view(
                        self.current_session.messages,
                    )
                except Exception as e:  # noqa: BLE001
                    logger.debug("Failed to setup initial ChatView: %s", e)

            self.query_one(InputArea).focus()
        except Exception as e:  # noqa: BLE001
            logger.debug("UI quick init failed: %s", e)

    def _validate_default_model(
        self,
        default_model: str,
        available_models: list[str],
    ) -> str:
        if not available_models:
            return default_model
        if default_model and default_model not in available_models:
            logger.warning(
                "Configured model '%s' not found in available models: %s",
                default_model,
                available_models,
            )
            return available_models[0]
        return default_model

    def _resolve_connected_model(
        self,
        is_connected: bool,
        available_models: list[str],
        default_model: str,
    ) -> str:
        if not is_connected:
            self._available_models = []
            return default_model
        if available_models:
            self._available_models = available_models
            return self._validate_default_model(default_model, available_models)
        self._available_models = []
        return default_model or ""

    def _update_session_model_after_init(
        self,
        is_connected: bool,
        default_model: str,
    ) -> None:
        if not is_connected or not self.current_session:
            return
        if default_model and self.current_session.model != default_model:
            self.current_session.model = default_model
            try:
                self.session_manager._save_session_if_not_empty(self.current_session)
            except Exception as e:  # noqa: BLE001
                logger.warning(
                    "Failed to save session after model correction: %s",
                    e,
                    exc_info=True,
                )

    def action_message_actions(self) -> None:
        """Open message actions menu for the last message (Ctrl+M shortcut)."""
        if self.is_generating or not self.messages:
            return

        last_msg = self.messages[-1]
        index = len(self.messages) - 1

        if last_msg.role == "assistant":
            role = "assistant"
            is_last_assistant = True
        elif last_msg.role == "user":
            role = "user"
            is_last_assistant = False
        else:
            for i in range(len(self.messages) - 1, -1, -1):
                msg = self.messages[i]
                if msg.role in ("user", "assistant"):
                    index = i
                    role = msg.role
                    is_last_assistant = msg.role == "assistant"
                    break
            else:
                return

        from tinychat.components.message_action_screen import MessageActionScreen

        self.push_screen(
            MessageActionScreen(index, role, is_last_assistant),
            callback=lambda result: self._handle_message_action(result, index, role),
        )

    def _find_delete_range(
        self, messages: list[Message], user_idx: int
    ) -> tuple[int, int]:
        """Return (start_inclusive, end_exclusive) of messages to delete.

        Deletes the user message at user_idx and all subsequent messages
        (assistant, tool, error) up to but not including the next user message
        or end of conversation.

        Args:
            messages: List of all messages.
            user_idx: Index of the user message to delete.

        Returns:
            Tuple of (start_index, end_index) for deletion.
        """
        if user_idx >= len(messages) or messages[user_idx].role != "user":
            return user_idx, user_idx  # No-op range

        start = user_idx
        end = len(messages)
        for i in range(user_idx + 1, len(messages)):
            if messages[i].role == "user":
                end = i
                break
        return start, end

    def _handle_message_action(
        self, result: str | None, message_index: int, role: str
    ) -> None:
        """Handle message action results from the MessageActionScreen.

        Args:
            result: Action string ("fork", "regenerate", "delete") or None if cancelled.
            message_index: Message index that was targeted.
            role: Role of the message ("user" or "assistant").
        """
        if not result or self.is_generating:
            return

        if result == "copy_markdown":
            from tinychat.utils.clipboard import copy_to_clipboard

            chat_view = self._get_current_chat_view()
            if not chat_view or message_index >= len(chat_view.messages):
                return
            msg = chat_view.messages[message_index]
            if copy_to_clipboard(msg.content):
                self.notify(
                    _("Markdown copied to clipboard"),
                    title=_("Copied!"),
                    timeout=2,
                )
            else:
                self.notify(
                    _("Failed to copy to clipboard"),
                    title=_("Error"),
                    timeout=2,
                )
            self._focus_input_area()
            return

        # Fork: create a new session from this assistant message
        if result == "fork":
            if (
                role != "assistant"
                or not self.session_manager
                or not self.current_session
            ):
                return
            # Fork should be triggered on any assistant message (not just last)
            # Use asyncio.create_task to run async fork without blocking
            asyncio.create_task(self._fork_session_action(message_index))
        elif result == "regenerate":
            if role != "assistant" or not self.current_session:
                return
            # Regenerate only allowed on last assistant message (enforced by UI)
            if message_index != len(self.messages) - 1:
                return
            # Truncate messages to remove the assistant message (keep up to user message before it)
            # Since message_index points to the assistant, we keep messages[:message_index] (user message at message_index-1 remains)
            new_messages = self.messages[:message_index]
            self.messages = new_messages
            # Start regeneration worker (call directly; @work returns Worker)
            self._regenerate_worker()
        elif result == "delete":
            if role != "user":
                return
            # Compute delete range
            start, end = self._find_delete_range(self.messages, message_index)
            if end > start:
                new_messages = self.messages[:start] + self.messages[end:]
                self.messages = new_messages
                self.notify(_("Message deleted"))
                self._focus_input_area()

    async def _fork_session_action(self, message_index: int) -> None:
        """Async helper to fork a session and switch to it.

        Args:
            message_index: Index up to which messages are copied (inclusive).
        """
        if not self.session_manager or not self.current_session:
            return
        try:
            new_session = await self.session_manager.fork_session(
                self.current_session.id, message_index
            )
            await self._switch_to_session(new_session.id)
            self.notify(_("Session forked"))
        except Exception as e:
            logger.error("Failed to fork session: %s", e)
            self.notify(_("Failed to fork session"), title=_("Error"))

    @work(exclusive=True, description="Backend initialization")
    async def _backend_init_worker(self) -> None:
        """Background worker to test backend connection and fetch models."""
        worker_start = time.perf_counter()
        logger.debug("[PERF] _backend_init_worker started")

        if not self._backends:
            return

        first_backend_name = next(iter(self._backends))
        backend = self._backends[first_backend_name]

        async def _test_connection_safe() -> bool:
            try:
                return await backend.test_connection()
            except Exception as e:  # noqa: BLE001
                logger.warning("Connection test failed: %s", e, exc_info=True)
                return False

        async def _list_models_safe() -> list[str]:
            try:
                models = await backend.list_models()
                if not isinstance(models, list):
                    logger.warning("list_models returned non-list: %s", type(models))
                    return []
                return models
            except Exception as e:  # noqa: BLE001
                logger.warning("List models failed: %s", e, exc_info=True)
                return []
                return models
            except Exception as e:  # noqa: BLE001
                logger.warning("List models failed: %s", e, exc_info=True)
                return []

        try:
            is_connected, available_models = await asyncio.gather(
                _test_connection_safe(),
                _list_models_safe(),
            )
        except Exception as e:
            logger.exception("Backend initialization failed")
            self.connection_status = "error"
            self.call_after_refresh(self._update_status_bar_error, str(e)[:50])
            return

        self.connection_status = "connected" if is_connected else "disconnected"

        info = backend.get_info()
        backend_name = info.get("name", "")
        default_model = info.get("default_model", "")
        default_model = self._resolve_connected_model(
            is_connected,
            available_models,
            default_model,
        )

        self.call_after_refresh(
            self._update_status_bar_complete,
            backend_name,
            default_model,
            self.connection_status,
        )

        self.call_after_refresh(
            self._update_sidebar_after_init,
            is_connected,
            available_models,
        )

        self._update_session_model_after_init(is_connected, default_model)

        worker_time = time.perf_counter() - worker_start
        logger.debug(
            "[PERF] _backend_init_worker completed: %.2fms (connected: %s, models: %d)",
            worker_time * 1000,
            is_connected,
            len(available_models),
        )

        if is_connected and not available_models:
            self.call_after_refresh(
                self._update_status_bar_warning,
                _("Model validation pending - may fail on chat"),
            )

        self.call_after_refresh(self._load_session_summaries_worker)

    @work(exclusive=False, description="Load session summaries")
    async def _load_session_summaries_worker(self) -> None:
        """Background worker to load session summaries from disk."""
        worker_start = time.perf_counter()
        logger.debug("[PERF] _load_session_summaries_worker started")

        if not self.session_manager:
            return
        summaries = await self._build_session_summaries()
        self.sessions = summaries

        worker_time = time.perf_counter() - worker_start
        logger.debug(
            "[PERF] _load_session_summaries_worker completed: %.2fms (loaded: %d summaries)",
            worker_time * 1000,
            len(summaries),
        )

    async def on_unmount(self) -> None:
        """Save all pending sessions and cleanup backends before app exits."""
        if getattr(self, "_cleanup_done", False):
            return
        self._cleanup_done = True

        # Cancel all pending compaction tasks
        if self._compaction_tasks:
            for task in self._compaction_tasks:
                if not task.done():
                    task.cancel()
            # Wait for all tasks to complete (or be cancelled)
            await asyncio.gather(*self._compaction_tasks, return_exceptions=True)
            logger.debug("Cancelled all pending compaction tasks")

        if self.session_manager:
            await self.session_manager.save_all_pending()
            logger.info("Saved all pending sessions on app exit")

        if getattr(self, "_db_manager", None) is not None:
            self._db_manager.close()
            logger.debug("Closed database manager")

        if self.http_manager is not None:
            try:
                await self.http_manager.aclose()
                logger.debug("Closed HTTP client manager")
            except Exception as e:  # noqa: BLE001
                logger.warning("Error closing HTTP client manager: %s", e)
        else:
            for name, backend in self._backends.items():
                try:
                    await backend.aclose()
                    logger.debug("Closed backend: %s", name)
                except Exception as e:  # noqa: BLE001
                    logger.warning("Error closing backend %s: %s", name, e)

    def _show_empty_message_error(self) -> None:
        """Show error when user tries to send empty message."""
        try:
            status_bar = self.query_one(StatusBar)
            status_bar.set_status("error", message=_("Message cannot be empty"))
        except Exception as e:  # noqa: BLE001
            logger.warning("Error showing empty message error: %s", e)

    async def _handle_tool_calls_and_reinvoke(
        self,
        pending_tool_calls: list[tuple[str, dict, str]],
    ) -> None:
        # Always create a fresh WorkflowManager for each tool batch
        # so each batch gets its own UI panel
        if self.current_session and self.tool_executor:
            from tinychat.tools.workflow_manager import WorkflowManager

            self.current_workflow_manager = WorkflowManager(
                session_id=self.current_session.id,
                app=self,
            )
            self.tool_executor.workflow_manager = self.current_workflow_manager
            batch_workflow_manager = self.current_workflow_manager
        else:
            batch_workflow_manager = None

        if self._tool_invocation_depth >= MAX_TOOL_INVOCATION_DEPTH:
            logger.warning(
                "Max tool invocation depth (%d) reached, stopping tool call loop",
                MAX_TOOL_INVOCATION_DEPTH,
            )
            return

        self._tool_invocation_depth += 1
        self._sync_terminal_title()
        try:
            messages = self.messages.copy()
            last_msg = messages[-1] if messages else None
            if last_msg and last_msg.role == "assistant":
                tc_list = [
                    ToolCall(id=call_id, name=name, arguments=args)
                    for name, args, call_id in pending_tool_calls
                ]
                updated_msg = replace(last_msg, tool_calls=tc_list)
                messages[-1] = updated_msg
                self.set_reactive(TinyChatApp.messages, messages)

            # Bug1 Fix: Update status bar to indicate tool execution is in progress
            try:
                status_bar = self.query_one(StatusBar)
                status_bar.set_status("executing", message=_("Executing tools..."))
            except Exception:
                # Status bar might not be available during early startup
                pass

            tool_workers = []
            for tool_name, args, call_id in pending_tool_calls:
                worker = self._tool_execution_worker(tool_name, args, call_id)
                tool_workers.append(worker)

            tool_messages: list[Message] = []
            if tool_workers:
                results = await asyncio.gather(
                    *[w.wait() for w in tool_workers],
                    return_exceptions=True,
                )
                for worker, result in zip(tool_workers, results):
                    if isinstance(result, Exception):
                        logger.error("Tool worker %s failed: %s", worker.name, result)
                        call_id = (
                            worker.name.split("_")[-1] if "_" in worker.name else ""
                        )
                        error_msg = Message(
                            role="tool",
                            content=f"Error: {result}",
                            tool_call_id=call_id,
                            tool_name=worker.name,
                            metadata={"error": str(result)},
                        )
                        tool_messages.append(error_msg)
                    elif isinstance(result, Message):
                        tool_messages.append(result)

            if tool_messages:
                chat_view = self._get_current_chat_view()
                if chat_view:
                    chat_view._skip_tool_widget_rendering = True
                try:
                    self.messages = self.messages + tool_messages
                finally:
                    if chat_view:
                        chat_view._skip_tool_widget_rendering = False

            await self._llm_reenvocation_worker()
        finally:
            self._tool_invocation_depth -= 1
            self._sync_terminal_title()
            if batch_workflow_manager and self.current_session:
                from tinychat.utils.workflow_serialization import (
                    serialize_workflow_state,
                )

                serialized = serialize_workflow_state(batch_workflow_manager.state)
                if serialized:
                    self.current_session.workflow_history.extend(serialized)
            if self._tool_invocation_depth == 0:
                self.current_workflow_manager = None

    async def _perform_tool_chat(
        self,
        backend: Backend,
        on_token: object,
        pending_tool_calls: list[tuple[str, dict, str]],
    ) -> None:
        actionable_tools = [t for t in self.tools if t.name != "no_action"]
        if actionable_tools:
            self._tool_adapter.backend = backend
            await self._tool_adapter.chat_with_tools(
                self.current_session,
                actionable_tools,
                on_token,  # type: ignore[arg-type]
                lambda name, args, call_id: pending_tool_calls.append(
                    (name, args, call_id),
                ),
            )
        else:
            chat_result = await backend.chat(self.current_session, on_token)  # type: ignore[arg-type]
            self._collect_dsml_tool_calls(chat_result, pending_tool_calls)

    async def _perform_plain_chat(
        self,
        backend: Backend,
        on_token: object,
        pending_tool_calls: list[tuple[str, dict, str]],
    ) -> None:
        chat_result = await backend.chat(self.current_session, on_token)  # type: ignore[arg-type]
        self._collect_dsml_tool_calls(chat_result, pending_tool_calls)

    def _finalize_streaming_content(
        self,
        chat_view: ChatView,
        streaming_content: str,
        reasoning_content: str | None,
        cancelled_by_user: bool,
        pending_tool_calls: list[tuple[str, dict, str]],
    ) -> None:
        if not cancelled_by_user:
            messages = self.messages.copy()
            messages[-1] = replace(
                messages[-1],
                content=streaming_content,
                reasoning_content=reasoning_content,
            )
            self.set_reactive(TinyChatApp.messages, messages)
            chat_view.update_last_assistant_message(streaming_content)
        elif streaming_content:
            messages = self.messages.copy()
            messages[-1] = replace(
                messages[-1],
                content=streaming_content,
                reasoning_content=reasoning_content,
            )
            self.set_reactive(TinyChatApp.messages, messages)

        chat_view.finalize_streaming()

    def _handle_streaming_cancel(
        self,
        chat_view: ChatView | None,
        status_bar: StatusBar | None,
        streaming_content: str,
    ) -> None:
        if not streaming_content:
            if chat_view and self.messages:
                messages = self.messages.copy()
                messages[-1] = replace(messages[-1], content=_("[Stopped]"))
                self.set_reactive(TinyChatApp.messages, messages)
                chat_view.update_last_assistant_message(_("[Stopped]"))
        if status_bar:
            status_bar.set_status("idle", message=_("Stopped"))

    def _cleanup_after_streaming(
        self,
        status_bar: StatusBar | None,
        cancelled_by_user: bool,
    ) -> None:
        self.metrics_collector.stop()
        self.metrics = self.metrics_collector.get_metrics()

        if self.current_session:
            self.current_session.messages = list(self.messages)
            if self.session_manager:
                self.session_manager.schedule_save(self.current_session.id)

        if status_bar and not cancelled_by_user:
            status_bar.set_status("idle")
        self.is_generating = False

        if self._compaction_manager and self.current_session and not cancelled_by_user:
            backend = self._get_backend()
            if backend:
                asyncio.create_task(self._run_compaction_check(backend, status_bar))

    async def _run_compaction_check(
        self,
        backend: Backend,
        status_bar: StatusBar | None,
    ) -> None:
        """Run compaction check after assistant turn completes."""
        if not self._compaction_manager or not self.current_session:
            return

        # Create task and track it for cancellation on unmount
        task = asyncio.create_task(self._do_compaction_check(backend, status_bar))
        self._compaction_tasks.add(task)
        task.add_done_callback(self._compaction_tasks.discard)

    async def _do_compaction_check(
        self,
        backend: Backend,
        status_bar: StatusBar | None,
    ) -> None:
        """Perform the actual compaction check."""
        try:
            from tinychat.compaction.token_counter import (
                estimate_messages_tokens,
                get_model_context_limit,
            )

            active_messages = self._compaction_manager.get_active_messages(
                self.current_session
            )
            estimated_tokens = estimate_messages_tokens(active_messages)
            context_limit = await get_model_context_limit(
                backend, self.current_session.model
            )

            if status_bar and context_limit:
                status_bar.update_token_usage(estimated_tokens, context_limit)

            compacted = await self._compaction_manager.check_and_compact(
                self.current_session,
                backend,
            )
            if compacted and self.current_session:
                # Use incremental update to avoid UI flicker and scroll-to-bottom
                chat_view = self.query_one(ChatView)
                if chat_view:
                    chat_view.mark_messages_compressed(self.current_session.messages)
                # Update app's messages reactive without triggering watch
                self._skip_watch = True
                try:
                    self.messages = list(self.current_session.messages)
                finally:
                    self._skip_watch = False
        except Exception as e:
            logger.debug("Compaction check failed: %s", e)

    async def _streaming_consumer(self, chat_view: ChatView) -> None:
        while True:
            token = await self._streaming_queue.get()
            if token is None:
                break
            if chat_view.is_mounted and not chat_view._destroyed:
                await chat_view.append_stream_token(token)

    def _on_stream_token(
        self,
        token: str,
        first_token: list[bool],
        streaming_content: list[str],
        chat_view: ChatView | None,
        status_bar: StatusBar | None,
    ) -> None:
        self.metrics_collector.record_token()
        if first_token[0] and status_bar:
            status_bar.set_status("streaming")

        streaming_content[0] += token
        if chat_view:
            if chat_view.is_mounted and not chat_view._destroyed:
                self._streaming_queue.put_nowait(token)

        if status_bar:
            metrics = self.metrics_collector.get_metrics()
            status_bar.update_metrics(
                tokens_per_second=metrics.get("tokens_per_second"),
                response_time=metrics.get("response_time"),
            )
        first_token[0] = False

    async def _stream_llm_response(
        self,
        backend: Backend,
        chat_view: ChatView | None,
        status_bar: StatusBar | None,
    ) -> _LLMStreamResult:
        self.is_generating = True
        self._has_status_error = False
        self.metrics_collector.start()
        if chat_view:
            self._streaming_queue = asyncio.Queue()
            self._streaming_consumer_task = asyncio.create_task(
                self._streaming_consumer(chat_view)
            )
        first_token = [True]
        streaming_content = [""]
        error_occurred = False
        cancelled_by_user = False
        pending_tool_calls: list[tuple[str, dict, str]] = []
        # Track reasoning_content across the stream
        reasoning_content: str | None = None

        def on_token(token: str):
            nonlocal reasoning_content
            self._on_stream_token(
                token,
                first_token,
                streaming_content,
                chat_view,
                status_bar,
            )

        try:
            if self.tools and self._tool_adapter and self._plugin_manager:
                await self._perform_tool_chat(
                    backend,
                    on_token,
                    pending_tool_calls,
                )
            else:
                await self._perform_plain_chat(
                    backend,
                    on_token,
                    pending_tool_calls,
                )

            # Extract reasoning_content accumulated during streaming
            if self.current_session:
                reasoning_buf = self.current_session.parameters.pop(
                    "_reasoning_buffer", None
                )
                if reasoning_buf:
                    reasoning_content = "".join(reasoning_buf)

            if status_bar and not error_occurred:
                status_bar.set_status("success")

        except asyncio.CancelledError:
            logger.info("LLM re-invocation cancelled by user")
            cancelled_by_user = True
            self._handle_streaming_cancel(
                chat_view,
                status_bar,
                streaming_content[0],
            )
            raise

        except Exception as e:
            logger.exception("Error during LLM re-invocation")
            error_occurred = True
            self._handle_backend_error(e, first_token[0])
            if status_bar:
                error_str = str(e)[:50]
                status_bar.set_status("error", message=error_str)

        finally:
            if (
                self._streaming_consumer_task
                and not self._streaming_consumer_task.done()
            ):
                self._streaming_queue.put_nowait(None)
                try:
                    await self._streaming_consumer_task
                except asyncio.CancelledError:
                    pass
            if chat_view:
                self._finalize_streaming_content(
                    chat_view,
                    streaming_content[0],
                    reasoning_content,
                    cancelled_by_user,
                    pending_tool_calls,
                )

            self._cleanup_after_streaming(status_bar, cancelled_by_user)

        return _LLMStreamResult(
            content=streaming_content[0],
            reasoning_content=reasoning_content,
            pending_tool_calls=pending_tool_calls,
            error_occurred=error_occurred,
            cancelled_by_user=cancelled_by_user,
        )

    @work(exclusive=True, description="Chat streaming")
    async def _send_message_worker(self, text: str) -> None:
        """Worker implementation of send_message for concurrent execution.

        This method contains the core logic of sending a message and streaming
        the response. It is decorated with @work to run as a background task.

        Args:
            text: The user's message text.

        Note:
            This worker is exclusive - a new message will cancel any ongoing
            streaming worker automatically.
        """

        if not text or not text.strip():
            self._show_empty_message_error()
            return

        processed_text = self._process_special_commands(text)
        if not processed_text:
            return

        self._ensure_tools_initialized()

        try:
            status_bar = self.query_one(StatusBar)
        except Exception:  # noqa: BLE001
            status_bar = None

        chat_view = self._get_current_chat_view()

        message = Message(role="user", content=processed_text)
        assistant_message = Message(role="assistant", content=_("Thinking..."))
        new_messages = self.messages + [message, assistant_message]
        self.messages = new_messages

        if self.session_manager and self.current_session:
            renamed = self.session_manager.auto_rename_from_first_message(
                self.current_session.id
            )
            if renamed:
                self._update_header_bar()
                self._sync_terminal_title()
                await self._refresh_session_list()

        backend = self._get_backend(
            self.current_session.backend_name if self.current_session else None,
        )
        if not backend:
            logger.warning("No backend available for chat")
            return

        if not self.current_session:
            logger.warning("No active session for chat")
            return

        if status_bar:
            status_bar.set_status("loading")
        if chat_view:
            chat_view.start_streaming()

        result = await self._stream_llm_response(backend, chat_view, status_bar)

        if (
            result.pending_tool_calls
            and self.tool_executor
            and not result.error_occurred
            and not result.cancelled_by_user
        ):
            await self._handle_tool_calls_and_reinvoke(result.pending_tool_calls)
            # Focus input area after tool processing completes
            self._focus_input_area()
            return

        if (
            not result.error_occurred
            and not result.cancelled_by_user
            and self._should_auto_open_navigation()
        ):
            self.call_after_refresh(self._auto_open_navigation)

        # Focus input area after response completes (no tool calls)
        self._focus_input_area()

    def _needs_tool_confirmation(self, tool_name: str, args: dict) -> bool:
        """Check if a tool call requires user confirmation.

        Respects user preferences stored in session.parameters["tool_preferences"].

        Args:
            tool_name: Name of the tool.
            args: Tool arguments.

        Returns:
            True if confirmation is needed, False otherwise.
        """
        # Check session preferences
        if self.current_session:
            prefs = self.current_session.parameters.get("tool_preferences", {})
            if prefs.get(tool_name) is True:
                return False  # Always allow
            if prefs.get(tool_name) is False:
                return True  # Always ask (or could be "always deny" variant)

        # Default policy: risky tools require confirmation
        risky_tools = {"shell", "exec_shell", "write_file", "delete_file"}
        return tool_name in risky_tools

    def _save_tool_preference(self, tool_name: str, always_allow: bool) -> None:
        """Save user's tool preference to session.

        Args:
            tool_name: Name of the tool.
            always_allow: True to always allow, False to always ask.
        """
        if not self.current_session:
            return

        if "tool_preferences" not in self.current_session.parameters:
            self.current_session.parameters["tool_preferences"] = {}

        self.current_session.parameters["tool_preferences"][tool_name] = always_allow

        # Mark session dirty for persistence
        if self.session_manager:
            self.session_manager.schedule_save(self.current_session.id)

    # =========================================================================
    # Worker Methods (Tool Execution & LLM Re-invocation)
    # =========================================================================

    @work(exclusive=False, description="Tool execution")
    async def _tool_execution_worker(
        self,
        tool_name: str,
        args: dict,
        call_id: str,
    ) -> Message:
        """Worker that executes a single tool via ToolExecutor.

        ToolExecutor.handle_tool_call already handles user confirmation
        via Modal (push_screen + future), so this worker simply delegates.

        Args:
            tool_name: Name of the tool to execute.
            args: Tool arguments dict.
            call_id: Unique ID for this tool call.

        Returns:
            Message object with role="tool" containing the result.
        """
        if not self.tool_executor:
            msg = "Tool executor not initialized"
            raise RuntimeError(msg)

        tool_call, message = await self.tool_executor.handle_tool_call(
            tool_name,
            args,
            call_id,
        )
        return message

    async def _llm_reenvocation_worker(self) -> None:
        """Re-invoke the LLM after tool results are collected.

        This is a regular async method called from within _send_message_worker
        or recursively from itself. It streams the final response after tools
        execute. Not decorated with @work because it's called recursively and
        must run within the parent worker's lifecycle to avoid exclusive worker
        conflicts.

        Note: Does NOT create a WorkflowManager here. The manager is created
        by _handle_tool_calls_and_reinvoke (each tool batch gets its own panel).
        This method just reuses whatever manager exists for the streaming phase.
        """
        if not self.current_session:
            return

        self._ensure_tools_initialized()

        # Reuse existing WorkflowManager. If tool calls occur,
        # _handle_tool_calls_and_reinvoke will create a new one.
        if self.current_workflow_manager is None:
            from tinychat.tools.workflow_manager import WorkflowManager

            self.current_workflow_manager = WorkflowManager(
                session_id=self.current_session.id,
                app=self,
            )
            if self.tool_executor:
                self.tool_executor.workflow_manager = self.current_workflow_manager

        backend = self._get_backend(
            self.current_session.backend_name if self.current_session else None,
        )
        if not backend:
            return

        chat_view = self._get_current_chat_view()
        try:
            status_bar = self.query_one(StatusBar)
        except Exception:  # noqa: BLE001
            status_bar = None

        if status_bar:
            status_bar.set_status("loading")
        if chat_view:
            chat_view.start_streaming()
            pre_assistant = Message(role="assistant", content="")
            self.messages = self.messages + [pre_assistant]
            # Allow the UI to mount the AssistantMessageWidget before streaming
            await asyncio.sleep(0)

        result = await self._stream_llm_response(backend, chat_view, status_bar)

        if (
            result.pending_tool_calls
            and self.tool_executor
            and not result.error_occurred
            and not result.cancelled_by_user
        ):
            await self._handle_tool_calls_and_reinvoke(result.pending_tool_calls)

        # Note: Focus restoration handled by caller

    @work(exclusive=True, description="Regenerate")
    async def _regenerate_worker(self) -> None:
        """Worker to regenerate the last assistant response.

        This worker assumes self.messages has already been truncated to end
        with the last user message (by the handler). It creates an empty
        assistant message and streams the LLM response.
        """
        if not self.current_session:
            logger.warning("No active session for regenerate")
            return

        if self.is_generating:
            logger.debug("Already generating, skipping regenerate")
            return

        self._ensure_tools_initialized()

        # Create a fresh WorkflowManager for this regenerate operation
        from tinychat.tools.workflow_manager import WorkflowManager

        self.current_workflow_manager = WorkflowManager(
            session_id=self.current_session.id,
            app=self,
        )
        if self.tool_executor:
            self.tool_executor.workflow_manager = self.current_workflow_manager

        backend = self._get_backend(
            self.current_session.backend_name if self.current_session else None,
        )
        if not backend:
            logger.warning("No backend available for regenerate")
            return

        chat_view = self._get_current_chat_view()
        try:
            status_bar = self.query_one(StatusBar)
        except Exception:  # noqa: BLE001
            status_bar = None

        if status_bar:
            status_bar.set_status("loading", message=_("Regenerating..."))
        if chat_view:
            chat_view.start_streaming()
            assistant_message = Message(role="assistant", content="")
            self.messages = self.messages + [assistant_message]
            # Allow the UI to mount the AssistantMessageWidget before streaming
            await asyncio.sleep(0)

        result = await self._stream_llm_response(backend, chat_view, status_bar)

        if (
            result.pending_tool_calls
            and self.tool_executor
            and not result.error_occurred
            and not result.cancelled_by_user
        ):
            await self._handle_tool_calls_and_reinvoke(result.pending_tool_calls)

        # Focus input area after regeneration completes
        self._focus_input_area()

    # =========================================================================
    # Worker Event Handlers
    # =========================================================================

    def on_worker_state_changed(self, event: Worker.StateChanged) -> None:
        """Handle worker state changes for monitoring and cleanup."""
        worker = event.worker
        new_state = event.state
        old_state = getattr(worker, "_last_state", None)
        worker._last_state = new_state  # noqa: SLF001

        logger.debug("Worker %s state: %s → %s", worker.name, old_state, new_state)

        if new_state == WorkerState.ERROR:
            logger.error("Worker %s error: %s", worker.name, worker.error)
            self.is_generating = False
            self._has_status_error = True
            self._sync_terminal_title()

    def on_worker_error(self, event: Worker.error) -> None:
        """Handle unhandled worker exceptions."""
        worker = event.worker
        error = event.error

        logger.error(
            "Worker %s raised unhandled exception: %s",
            worker.name,
            error,
            exc_info=error,
        )

        # Show user-friendly error
        try:
            status_bar = self.query_one(StatusBar)
            error_str = str(error)[:50]
            status_bar.set_status("error", message=f"Worker error: {error_str}")
        except Exception:  # noqa: BLE001
            pass

        self.is_generating = False
        self._has_status_error = True
        self._sync_terminal_title()

    async def send_message(self, text: str) -> None:
        """Send a user message (async wrapper that starts worker).

        This method initiates the message sending process by starting
        the _send_message_worker (decorated with @work). It returns
        only after the worker completes (successfully or cancelled),
        allowing callers to await completion if needed.

        Args:
            text: The user's message text.
        """
        if not text or not text.strip():
            self._show_empty_message_error()
            return

        # Start the worker via @work decorator (returns Worker)
        # exclusive=True on the worker ensures any previous streaming
        # worker is cancelled
        worker = self._send_message_worker(text)

        # Wait for the worker to complete, propagating cancellation
        try:
            await worker.wait()
        except Exception as e:
            # If the worker was cancelled, ensure it's stopped and
            # propagate as CancelledError
            from textual.worker import WorkerCancelled  # noqa: PLC0415

            if isinstance(e, WorkerCancelled):
                # Ensure worker is cleaned up
                if worker.state in (WorkerState.RUNNING, WorkerState.PENDING):
                    worker.cancel()
                raise asyncio.CancelledError from e
            raise

    @staticmethod
    def _collect_dsml_tool_calls(
        chat_result: dict | None,
        pending_tool_calls: list[tuple[str, dict, str]],
    ) -> None:
        if not chat_result or not isinstance(chat_result, dict):
            return
        tool_calls = chat_result.get("tool_calls")
        if not tool_calls:
            return
        for tc in tool_calls:
            func = tc.get("function", {})
            call_id = tc.get("id", "")
            name = func.get("name", "")
            raw_args = func.get("arguments", "{}")
            try:
                args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
            except (json.JSONDecodeError, TypeError):
                args = {}
            if name:
                pending_tool_calls.append((name, args, call_id))
                logger.debug(
                    "DSML tool call collected: %s (id=%s, args_keys=%s)",
                    name,
                    call_id,
                    list(args.keys())
                    if isinstance(args, dict)
                    else type(args).__name__,
                )

    @staticmethod
    def _parse_todo_output(output: str) -> list[dict]:
        todos: list[dict] = []
        for line in output.split("\n"):
            line = line.strip()
            if not line or "No todos yet" in line:
                continue
            if line.startswith("[") and "]" in line:
                try:
                    priority_end = line.index("]")
                    priority = line[1:priority_end].lower()
                    rest = line[priority_end + 1 :].strip()
                    if rest:
                        status = "pending"
                        if rest.startswith("✓"):
                            status = "completed"
                        elif rest.startswith("⏳") or rest.startswith("🔄"):
                            status = "in_progress"
                        content = rest[1:].strip() if rest else ""
                        todos.append(
                            {
                                "content": content,
                                "status": status,
                                "priority": priority,
                            },
                        )
                except (ValueError, IndexError):
                    continue
        return todos

    def _update_todo_display(self, result: "ToolResult") -> None:
        """Update UI components with todo tool results.

        Args:
            result: The ToolResult from todo_list tool execution.
        """
        if not result.metadata:
            return

        try:
            status_bar = self.query_one(StatusBar)
            completed = result.metadata.get("completed", 0)
            total = result.metadata.get("total", 0)
            status_bar.update_todo_progress(completed=completed, total=total)
        except Exception as e:  # noqa: BLE001
            logger.debug("Could not update StatusBar todo progress: %s", e)

        try:
            if hasattr(result, "output") and result.output:
                todos = self._parse_todo_output(result.output)
                self._update_todo_panel(todos)
        except Exception as e:  # noqa: BLE001
            logger.debug("Could not update TodoPanel: %s", e)

    def _restore_todo_display(self) -> None:
        try:
            todo_tool = next((t for t in self.tools if t.name == "todo_list"), None)
            if not todo_tool or not todo_tool.todos:
                return

            todos = [
                {
                    "content": item.get("content", ""),
                    "status": item.get("status", "pending"),
                    "priority": item.get("priority", "medium"),
                }
                for item in todo_tool.todos
            ]

            self._update_todo_panel(todos)

            completed = sum(
                1 for t in todo_tool.todos if t.get("status") == "completed"
            )
            status_bar = self.query_one(StatusBar)
            status_bar.update_todo_progress(
                completed=completed,
                total=len(todo_tool.todos),
            )
        except Exception as e:  # noqa: BLE001
            logger.debug("Could not restore todo display: %s", e)

    def _update_todo_panel(self, todos: list[dict]) -> None:
        """Update the TodoPanel with current todos."""
        from tinychat.components.todo_panel import TodoPanel

        try:
            todo_panel = self.query_one(TodoPanel)
            todo_panel.todos = todos
        except Exception as e:  # noqa: BLE001
            logger.debug("Could not update TodoPanel: %s", e)

    def _process_special_commands(self, text: str) -> str | None:
        """Process special commands like translation.

        Args:
            text: Original user input

        Returns:
            Transformed text, or None if command is invalid
        """
        if text.startswith("翻译：") or text.startswith("翻译:"):
            content = text.split("：", 1)[-1].split(":", 1)[-1].strip()
            if not content:
                try:
                    status_bar = self.query_one(StatusBar)
                    status_bar.set_status(
                        "error",
                        message=_("Translation content cannot be empty"),
                    )
                except Exception as e:  # noqa: BLE001
                    logger.warning("Error showing translation error: %s", e)
                return None
            return f"请翻译以下内容：{content}"

        if text.lower().startswith("translate:"):
            content = text.split(":", 1)[-1].strip()
            if not content:
                try:
                    status_bar = self.query_one(StatusBar)
                    status_bar.set_status(
                        "error",
                        message=_("Translation content cannot be empty"),
                    )
                except Exception as e:  # noqa: BLE001
                    logger.warning("Error showing translation error: %s", e)
                return None
            return f"Please translate the following: {content}"

        if text.strip() == "/compact":
            self._ensure_tools_initialized()  # Ensure compaction manager is initialized
            logger.debug("Direct /compact command triggered")
            logger.debug(f"  _compaction_manager: {self._compaction_manager}")
            logger.debug(f"  current_session: {self.current_session}")
            if self._compaction_manager and self.current_session:
                # Check if compaction is enabled before checking backend
                if not self._compaction_manager.config.enabled:
                    self.notify(
                        _(
                            "Summary feature is disabled. Enable it in config: [compaction] enabled = true"
                        ),
                        title=_("Info"),
                    )
                    return ""

                backend = self._get_backend()
                logger.debug(f"  backend: {backend}")
                if backend:
                    logger.debug("Starting force compaction from direct command")
                    # Status bar will be updated by CompactionManager._compact()
                    # Don't set status here to avoid race conditions
                    asyncio.create_task(self._run_compaction_force(backend))
                else:
                    self.notify(
                        _("No backend connected. Please configure a backend first."),
                        title=_("Info"),
                    )
                    logger.warning("Cannot run /compact: no backend available")
            else:
                self.notify(
                    _("Please start a conversation first"),
                    title=_("Info"),
                )
                logger.warning("Cannot run /compact: missing manager or session")
            return ""

        return text

    async def _run_compaction_force(self, backend: Backend) -> None:
        """Force compaction via /compact command."""
        logger.debug("_run_compaction_force started")
        if not self._compaction_manager or not self.current_session:
            logger.warning("Cannot run compaction: manager or session is None")
            self.notify(_("Please start a conversation first"), title=_("Info"))
            return

        # Check if compaction is enabled in config
        if not self._compaction_manager.config.enabled:
            logger.warning("Compaction is disabled in configuration")
            self.notify(
                _(
                    "Summary feature is disabled. Enable it in config: [compaction] enabled = true"
                ),
                title=_("Info"),
            )
            return

        try:
            logger.debug("Calling force_compact...")
            compacted = await self._compaction_manager.force_compact(
                self.current_session,
                backend,
            )
            logger.debug(f"force_compact returned: {compacted}")
            if compacted and self.current_session:
                self.messages = list(self.current_session.messages)
                self.notify(_("Conversation summarized successfully"))
                logger.debug("Context compacted successfully, messages updated")
            elif not compacted:
                logger.warning(
                    "force_compact returned False - compaction did not occur"
                )
                self.notify(_("Already summarized or summarizing"), title=_("Info"))
        except Exception as e:
            logger.error("Force compaction failed: %s", e)
            self.notify(_("Failed to summarize conversation"), title=_("Error"))
        # Note: CompactionManager._compact() handles status bar cleanup in its finally block

    def _update_assistant_message(self, token: str, is_first: bool) -> None:
        """Update the last assistant message with streaming token.

        Args:
            token: Token to append or set as content.
            is_first: True if this is the first token (replaces content).
        """
        if not self.messages:
            return

        messages = self.messages.copy()
        last_message = messages[-1]

        if is_first:
            updated_message = replace(last_message, content=token)
            streaming_content = token
        else:
            updated_message = replace(
                last_message,
                content=last_message.content + token,
            )
            streaming_content = last_message.content + token

        messages[-1] = updated_message
        self.set_reactive(TinyChatApp.messages, messages)

        try:
            chat_view = self._get_current_chat_view()
            if chat_view:
                chat_view.update_last_assistant_message(streaming_content)
        except Exception as e:  # noqa: BLE001
            logger.warning("Error updating ChatView: %s", e)

    async def _finalize_streaming(self) -> None:
        """Finalize streaming by awaiting pending writes and stopping stream."""
        if hasattr(self, "_stream_write_tasks") and self._stream_write_tasks:
            await asyncio.gather(*self._stream_write_tasks, return_exceptions=True)
            self._stream_write_tasks = []

        try:
            chat_view = self._get_current_chat_view()
            if chat_view:
                active_stream = chat_view.get_active_stream()
                if active_stream:
                    await active_stream.stop()
                chat_view.stop_streaming()
        except Exception as e:  # noqa: BLE001
            logger.warning("Error finalizing streaming: %s", e)

    def _handle_backend_error(self, error: Exception, tokens_received: bool) -> None:
        """Handle backend errors by updating assistant message.

        Only persists non-retryable errors to the message history.
        Retryable errors (rate limits, server errors) are not saved
        because they will be retried or are transient.

        Args:
            error: The exception that occurred.
            tokens_received: Whether any tokens were received before error.
        """
        from tinychat.errors import is_retryable_error

        if not self.messages:
            return

        # Don't persist retryable errors (rate limits, 5xx, etc.)
        if is_retryable_error(error):
            logger.info("Skipping error persistence for retryable error: %s", error)
            return

        messages = self.messages.copy()
        last_message = messages[-1]

        error_str = str(error)
        max_error_len = 100 - len(_("[Error: {error}]").format(error=""))
        if len(error_str) > max_error_len:
            error_str = error_str[:max_error_len]
        error_text = _("[Error: {error}]").format(error=error_str)

        if tokens_received:
            updated_message = replace(
                last_message,
                content=last_message.content + f"\n{error_text}",
            )
        else:
            updated_message = replace(last_message, content=error_text)

        messages[-1] = updated_message
        self.set_reactive(TinyChatApp.messages, messages)

        try:
            chat_view = self._get_current_chat_view()
            if chat_view:
                chat_view.update_last_assistant_message(updated_message.content)
        except Exception as e:  # noqa: BLE001
            logger.warning("Error updating ChatView with error: %s", e)

    def get_system_commands(self, screen: Screen) -> Iterable[SystemCommand]:
        """Yield system commands with i18n support."""
        yield SystemCommand(
            _("Backend Panel"),
            _("Toggle the backend configuration panel"),
            self.action_toggle_backend_panel,
        )
        if not self.ansi_color:
            yield SystemCommand(
                _("Theme"),
                _("Change the current theme"),
                self.action_change_theme,
            )
        yield SystemCommand(
            _("Quit"),
            _("Quit the application as soon as possible"),
            self.action_quit,
        )

        if screen.query("HelpPanel"):
            yield SystemCommand(
                _("Keys"),
                _("Hide the keys and widget help panel"),
                self.action_hide_help_panel,
            )
        else:
            yield SystemCommand(
                _("Keys"),
                _("Show help for the focused widget and a summary of available keys"),
                self.action_show_help_panel,
            )

        if screen.maximized is not None:
            yield SystemCommand(
                _("Minimize"),
                _("Minimize the widget and restore to normal size"),
                screen.action_minimize,
            )

        yield SystemCommand(
            _("Screenshot"),
            _("Save an SVG 'screenshot' of the current screen"),
            lambda: self.set_timer(0.1, self.deliver_screenshot),
        )

        yield SystemCommand(
            _("Session History"),
            _("Manage session history (view, rename, delete)"),
            self.action_manage_history_sessions,
        )

        yield SystemCommand(
            _("Session Navigation"),
            _("Navigate between questions in the current session"),
            self.action_toggle_navigation_panel,
        )

        yield SystemCommand(
            _("Todo Panel"),
            _("Toggle the todo list panel"),
            self.action_toggle_todo_panel,
        )

        current = get_current_locale()
        if current == "en":
            yield SystemCommand(
                _("Switch to Chinese"),
                _("Change UI language to Chinese"),
                self._switch_to_chinese,
            )
        else:
            yield SystemCommand(
                _("Switch to English"),
                _("Change UI language to English"),
                self._switch_to_english,
            )

    def _switch_to_chinese(self) -> None:
        """Switch UI to Chinese."""
        self._change_locale("zh")

    def _switch_to_english(self) -> None:
        """Switch UI to English."""
        self._change_locale("en")

    def _change_locale(self, locale: str) -> None:
        """Change the application locale.

        Args:
            locale: New locale code (e.g., 'en', 'zh')
        """
        if locale not in get_available_locales():
            logger.warning("Invalid locale '%s' requested", locale)
            self.notify(_("Invalid locale."))
            return

        try:
            config = load_user_config()
            config.locale = locale
            save_user_config(config)
        except OSError:
            logger.exception("Failed to save locale config")
            self.notify(_("Failed to save language preference."))
            return

        set_locale(locale)

        self.refresh()

        self.notify(_("Language changed. Restart app for full effect."))

    def action_command_palette(self) -> None:
        self.push_screen(CommandPalette(placeholder=_("Search for commands...")))

    def action_toggle_backend_panel(self) -> None:
        """Toggle the backend configuration panel visibility."""
        self.show_backend_panel = not self.show_backend_panel
        sidebar = self.query_one(Sidebar)

        if self.show_backend_panel:
            sidebar.remove_class("hidden-panel")
            sidebar.backends = list(self._backends.keys())
            if self.current_session and self.current_session.model:
                sidebar.set_selected_model(self.current_session.model)
            sidebar.set_available_models(self._available_models)
            if self.current_session:
                sidebar.set_selected_backend(self.current_session.backend_name)
            # Defer focus to next refresh to ensure panel is visible
            self.call_after_refresh(sidebar.focus)
        else:
            sidebar.add_class("hidden-panel")
            self._focus_input_area()

    def action_toggle_navigation_panel(self) -> None:
        """Toggle the session navigation panel visibility."""
        self.show_navigation_panel = not self.show_navigation_panel
        sidebar = self.query_one(Sidebar)

        if self.show_navigation_panel:
            if self.show_backend_panel:
                self.show_backend_panel = False
            sidebar.mode = "navigation"
            sidebar.navigation_questions = self._get_user_questions()
            sidebar.navigation_message_indices = self._get_user_message_indices()
            sidebar.navigation_cursor = 0
            sidebar.remove_class("hidden-panel")
            sidebar.add_class("navigation-mode")
            # Defer focus to next refresh to ensure panel is visible
            self.call_after_refresh(sidebar.focus)
        else:
            sidebar.add_class("hidden-panel")
            sidebar.remove_class("navigation-mode")
            sidebar.mode = "backend"
            self._focus_input_area()

    def _get_user_questions(self) -> list[str]:
        return [m.content for m in self.messages if m.role == "user"]

    def _get_user_message_indices(self) -> list[int]:
        return [i for i, m in enumerate(self.messages) if m.role == "user"]

    def _update_navigation_panel(self) -> None:
        sidebar = self.query_one(Sidebar)
        sidebar.navigation_questions = self._get_user_questions()
        sidebar.navigation_message_indices = self._get_user_message_indices()

    def _should_auto_open_navigation(self) -> bool:
        return not any(m.role == "user" for m in self.messages)

    def _auto_open_navigation(self) -> None:
        if self.show_backend_panel:
            return
        questions = self._get_user_questions()
        if not questions:
            return
        self.show_navigation_panel = True
        sidebar = self.query_one(Sidebar)
        sidebar.mode = "navigation"
        sidebar.navigation_questions = questions
        sidebar.navigation_message_indices = self._get_user_message_indices()
        sidebar.navigation_cursor = 0
        sidebar.remove_class("hidden-panel")
        sidebar.add_class("navigation-mode")
        sidebar.focus()

    def action_toggle_todo_panel(self) -> None:
        """Toggle the todo panel visibility."""
        from tinychat.components.todo_panel import TodoPanel

        todo_panel = self.query_one(TodoPanel)
        if todo_panel.has_class("hidden-panel"):
            todo_panel.remove_class("hidden-panel")
            self.show_todo_panel = True
            todo_panel.focus()
        else:
            todo_panel.add_class("hidden-panel")
            self.show_todo_panel = False
            self._focus_input_area()

    def on_question_jump_requested(self, message: QuestionJumpRequested) -> None:
        chat_view = self._get_current_chat_view()
        if chat_view:
            chat_view.scroll_to_widget_top(message.message_index)

    async def on_session_changed(self, message: SessionChangedMessage) -> None:
        """Handle session change message."""
        self._update_session_ui(message.session_id)

    def action_escape(self) -> None:
        """Handle Escape key - stop streaming or close backend panel."""
        if self.is_generating:
            if (
                self._streaming_consumer_task
                and not self._streaming_consumer_task.done()
            ):
                self._streaming_consumer_task.cancel()
                self._streaming_consumer_task = None
            while not self._streaming_queue.empty():
                try:
                    self._streaming_queue.get_nowait()
                except asyncio.QueueEmpty:
                    break
            cancelled = 0
            for worker in list(self.workers):
                if worker.state in (WorkerState.RUNNING, WorkerState.PENDING):
                    worker.cancel()
                    cancelled += 1
            logger.info(
                "User requested to stop streaming, cancelled %d workers", cancelled
            )
        elif self.show_navigation_panel:
            self.action_toggle_navigation_panel()
        elif self.show_backend_panel:
            self.action_toggle_backend_panel()

    async def action_quit(self) -> None:
        """Handle quit action - cancel all workers before exiting."""
        cancelled = 0
        for worker in list(self.workers):
            if worker.state in (WorkerState.RUNNING, WorkerState.PENDING):
                worker.cancel()
                cancelled += 1
        if cancelled > 0:
            logger.info("Cancelled %d workers on quit", cancelled)
        await super().action_quit()

    def action_help_quit(self) -> None:
        """Override Textual's default Ctrl+C behavior to prevent 'do you want to quit' notification.

        Textual displays a toast notification when Ctrl+C is pressed, assuming the user
        wants to quit. Since we handle Ctrl+C differently in InputArea (clear input),
        we disable this notification entirely.
        """
        # Do nothing - this prevents the default 'Do you want to quit?' toast
        pass

    # =========================================================================
    # Session Management (OpenCode-style dialog)
    # =========================================================================

    async def _create_new_session(self) -> None:
        """Create a new session and switch to it."""
        if not self.session_manager:
            return

        # Save current session before switching (will be unloaded)
        old_session_id = self.session_manager.active_session_id
        if old_session_id:
            await self.session_manager.save_session_now(old_session_id)

        backend = self._get_backend()
        if not backend:
            return

        info = backend.get_info()
        backend_name = info.get("name", "default")
        model = info.get("default_model", "")

        session = await self.session_manager.create_session(backend_name, model)
        # _switch_to_session handles unload + UI updates
        await self._switch_to_session(session.id)
        self._update_header_bar()
        # 创建新会话后需要刷新会话列表
        await self._refresh_session_list()

    async def _load_or_create_session(self, session_id: str) -> str:
        if session_id in self.session_manager.sessions:
            return session_id

        loaded_session = self.session_manager.load_session_from_storage(session_id)
        if not loaded_session:
            logger.error("Failed to load session %s from storage", session_id)
            if self._backends:
                first_backend = next(iter(self._backends.values()))
                info = first_backend.get_info()
                backend_name = info.get("name", "")
                model = info.get("default_model", "")
                new_session = await self.session_manager.create_session(
                    backend_name,
                    model,
                )
                self._notify_session_fallback()
                return new_session.id
            raise RuntimeError(f"Cannot load or create session {session_id}")

        await self._validate_session_model(loaded_session)
        return session_id

    def _notify_session_fallback(self) -> None:
        self.notify(
            _("Failed to load session. A new session has been created."),
            title=_("Session Load Error"),
            severity="warning",
        )

    def _notify_session_load_failed(self) -> None:
        self.notify(
            _("Failed to load session. Please try again."),
            title=_("Session Load Error"),
            severity="error",
        )

    async def _validate_session_model(self, session: ChatSession) -> None:
        session_backend = self._get_backend(session.backend_name)
        if not session_backend:
            return
        try:
            available_models = await session_backend.list_models()
            if available_models and session.model not in available_models:
                old_model = session.model
                session.model = available_models[0]
                logger.warning(
                    "Session had invalid model '%s' for backend '%s', updated to '%s'",
                    old_model,
                    session.backend_name,
                    session.model,
                )
                self.session_manager._save_session_if_not_empty(session)
        except Exception as e:  # noqa: BLE001
            logger.warning(
                "Failed to validate models for session %s: %s",
                session.id,
                e,
                exc_info=True,
            )

    def _update_session_ui(self, session_id: str) -> None:
        """Update UI after session switch with progressive rendering."""
        if not self.current_session:
            return

        ui_start = time.perf_counter()
        msg_count = len(self.current_session.messages)

        # Use batch_update to reduce repaints for non-message UI elements
        with self.app.batch_update():
            self.set_reactive(
                TinyChatApp.messages,
                self.current_session.messages.copy(),
            )
            if (
                self.current_session.input_history
                and self.current_session.history_index == 0
            ):
                self.current_session.history_index = len(
                    self.current_session.input_history,
                )

            self._update_header_bar()
            self._sync_terminal_title()

            self.current_backend_name = self.current_session.backend_name
            try:
                status_bar = self.query_one(StatusBar)
                status_bar.update_backend_info(
                    backend_name=self.current_session.backend_name,
                    model=self.current_session.model,
                )
            except Exception:  # noqa: BLE001
                pass
            try:
                sidebar = self.query_one(Sidebar)
                sidebar.update()
            except Exception:  # noqa: BLE001
                pass

        try:
            chat_view = self.query_one(ChatView)
        except Exception:
            from tinychat.components.left_panel import LeftPanel

            try:
                left_panel = self.query_one(LeftPanel)
                chat_view = ChatView(messages=None)
                left_panel.mount(chat_view, before=self.query_one(InputArea))
            except Exception:
                chat_view = ChatView(messages=None)
                self.mount(chat_view)

        # Determine rendering strategy based on message count
        total_messages = len(self.current_session.messages)
        use_virtual = total_messages > self._get_virtualization_threshold()

        render_start = time.perf_counter()
        if use_virtual:
            logger.debug(
                "[PERF] _update_session_ui: strategy=virtual, threshold=%d, msgs=%d",
                self._get_virtualization_threshold(),
                total_messages,
            )
            self._render_virtual_mode(chat_view, total_messages)
        else:
            logger.debug(
                "[PERF] _update_session_ui: strategy=progressive, msgs=%d",
                total_messages,
            )
            self._render_progressive_batches(chat_view, total_messages)

        render_time = (time.perf_counter() - render_start) * 1000
        ui_time = (time.perf_counter() - ui_start) * 1000
        logger.debug(
            "[PERF] _update_session_ui: %.2fms total (render: %.2fms, ui_setup: %.2fms, msgs: %d, strategy: %s)",
            ui_time,
            render_time,
            ui_time - render_time,
            msg_count,
            "virtual" if use_virtual else "progressive",
        )

        ui_elapsed = (time.perf_counter() - ui_start) * 1000
        logger.debug(
            "[PERF] _update_session_ui completed in %.2fms (%d messages)",
            ui_elapsed,
            msg_count,
        )

    def _get_virtualization_threshold(self) -> int:
        """Get the virtualization threshold from config."""
        try:
            from tinychat.utils.config_manager import ConfigManager

            config = ConfigManager().get_settings()
            return config.get(
                "virtualization_threshold", DEFAULT_VIRTUALIZATION_THRESHOLD
            )
        except Exception:
            return DEFAULT_VIRTUALIZATION_THRESHOLD

    def _render_virtual_mode(self, chat_view: ChatView, total_messages: int) -> None:
        """Render initial visible messages for virtual scrolling mode."""
        start = time.perf_counter()
        chat_view.enable_virtual_mode(True)
        visible_count = min(DEFAULT_VISIBLE_MESSAGE_COUNT, total_messages)
        chat_view.set_virtual_size(total_messages)

        all_messages = self.current_session.messages
        chat_view.set_messages(all_messages, initial_visible_count=visible_count)

        def _after_scroll_end():
            chat_view._sync_virtual_scroll()
            chat_view._update_older_messages_indicator()

        chat_view.call_after_refresh(chat_view.scroll_end, animate=False)
        chat_view.call_after_refresh(_after_scroll_end)

        elapsed = (time.perf_counter() - start) * 1000
        logger.debug(
            "[PERF] _render_virtual_mode: %.2fms, virtual mode activated, %d messages, visible: %d",
            elapsed,
            total_messages,
            visible_count,
        )

        logger.debug(
            "[PERF] _render_virtual_mode: virtual mode activated for %d messages (visible: %d, threshold: %d)",
            total_messages,
            visible_count,
            self._get_virtualization_threshold(),
        )

    def _render_progressive_batches(
        self, chat_view: ChatView, total_messages: int
    ) -> None:
        """Render messages in progressive batches to avoid UI blocking.

        Batches are split intelligently to ensure tool messages are always
        in the same batch as their corresponding assistant message.
        """
        start = time.perf_counter()
        chat_view.enable_virtual_mode(False)

        batch_size = self._get_loading_batch_size()
        messages = self.current_session.messages
        batches = self._split_into_smart_batches(messages, batch_size)

        logger.debug(
            "[PERF] _render_progressive_batches: %d total messages, %d batches, batch_size=%d",
            total_messages,
            len(batches),
            batch_size,
        )

        if not batches:
            chat_view.set_messages([])
            return

        first_batch = batches[0]
        chat_view.set_messages(first_batch)

        for batch_idx, batch in enumerate(batches[1:], start=1):
            delay = batch_idx * self._get_loading_frame_delay()
            timer = self.set_timer(
                delay,
                lambda b=batch, idx=batch_idx: self._append_message_batch(
                    chat_view, b, idx
                ),
                name=f"progressive_load_batch_{batch_idx}",
            )
            self._progressive_load_timers.append(timer)

        elapsed = (time.perf_counter() - start) * 1000
        logger.debug(
            "[PERF] _render_progressive_batches: %.2fms (first batch rendered, %d deferred)",
            elapsed,
            len(batches) - 1,
        )

    def _split_into_smart_batches(self, messages: list, batch_size: int) -> list[list]:
        """Split messages into batches, keeping tool messages with their assistant.

        Tool messages must be in the same batch as their corresponding assistant
        message to ensure WorkflowProgressWidget is rendered correctly.

        Args:
            messages: List of messages to split.
            batch_size: Target batch size.

        Returns:
            List of message batches.
        """
        if not messages:
            return []

        batches: list[list] = []
        current_batch: list = []
        pending_tool_count = 0

        for msg in messages:
            if msg.role == "assistant" and msg.tool_calls:
                pending_tool_count = len(msg.tool_calls)

            current_batch.append(msg)

            if msg.role == "tool" and pending_tool_count > 0:
                pending_tool_count -= 1

            should_flush = (
                len(current_batch) >= batch_size and pending_tool_count == 0
            ) or len(current_batch) >= batch_size * 2

            if should_flush:
                batches.append(current_batch)
                current_batch = []

        if current_batch:
            batches.append(current_batch)

        logger.debug(
            "[PERF] _split_into_smart_batches: %d messages -> %d batches (batch_size=%d)",
            len(messages),
            len(batches),
            batch_size,
        )

        return batches

    def _get_loading_batch_size(self) -> int:
        """Get batch size for progressive loading from config."""
        try:
            from tinychat.utils.config_manager import ConfigManager

            config = ConfigManager().get_settings()
            return config.get("loading_batch_size", DEFAULT_LOADING_BATCH_SIZE)
        except Exception:
            return DEFAULT_LOADING_BATCH_SIZE

    def _get_loading_frame_delay(self) -> float:
        """Get delay between batches from config."""
        try:
            from tinychat.utils.config_manager import ConfigManager

            config = ConfigManager().get_settings()
            return config.get("loading_frame_delay", DEFAULT_LOADING_FRAME_DELAY)
        except Exception:
            return DEFAULT_LOADING_FRAME_DELAY

    def _append_message_batch(
        self, chat_view: ChatView, messages: list[Message], batch_index: int
    ) -> None:
        """Append a batch of messages to the chat view."""
        chat_view.append_messages(messages)

    async def _switch_to_session(self, session_id: str) -> None:
        switch_start = time.perf_counter()
        logger.debug("[PERF] _switch_to_session started for %s", session_id[:8])

        if not self.session_manager:
            return

        self._prepare_session_switch()

        try:
            old_session_id = self.session_manager.active_session_id

            try:
                session_id = await self._load_or_create_session(session_id)
            except RuntimeError:
                self._notify_session_load_failed()
                return

            if old_session_id and old_session_id != session_id:
                await self.session_manager.save_session_now(old_session_id)

            await self.session_manager.switch_session(session_id)

            if old_session_id and old_session_id != session_id:
                unloaded = self.session_manager.unload_session(old_session_id)
                if unloaded:
                    logger.debug(
                        "Unloaded previous session %s from memory", old_session_id
                    )

            self.current_session = self.session_manager.get_active_session()

            self.post_message(SessionChangedMessage(session_id))
            self._update_session_ui(session_id)

            questions = self._get_user_questions()
            if questions:
                self.call_after_refresh(self._auto_open_navigation)

            switch_time = time.perf_counter() - switch_start
            msg_count = (
                len(self.current_session.messages) if self.current_session else 0
            )
            logger.debug(
                "[PERF] _switch_to_session completed: %.2fms (session: %s..., msgs: %d)",
                switch_time * 1000,
                session_id[:8],
                msg_count,
            )
            if switch_time > 0.5:
                logger.warning(
                    "[PERF] Slow session switch detected: %.2fms for %s with %d messages",
                    switch_time * 1000,
                    session_id[:8],
                    msg_count,
                )
        finally:
            self._finalize_session_switch()

    def _prepare_session_switch(self) -> None:
        self._cancel_progressive_load_timers()

        old_chat_view = self._get_current_chat_view()
        if old_chat_view and old_chat_view._active_stream:
            old_chat_view.destroy()

        if self._streaming_consumer_task and not self._streaming_consumer_task.done():
            self._streaming_consumer_task.cancel()
        self._streaming_consumer_task = None
        while not self._streaming_queue.empty():
            try:
                self._streaming_queue.get_nowait()
            except asyncio.QueueEmpty:
                break

        self.is_generating = True
        try:
            status_bar = self.query_one(StatusBar)
            status_bar.set_status("loading")
        except Exception:  # noqa: BLE001
            logger.debug("StatusBar not available for loading state")
        try:
            input_area = self.query_one(InputArea)
            input_area.disabled = True
        except Exception:  # noqa: BLE001
            logger.debug("InputArea not available for disabling")

        try:
            chat_view = self._get_or_create_chat_view([])
            chat_view.show_loading_placeholder()
        except Exception as e:  # noqa: BLE001
            logger.debug("Could not show loading placeholder: %s", e)

    def _finalize_session_switch(self) -> None:
        try:
            status_bar = self.query_one(StatusBar)
            status_bar.set_status("idle")
        except Exception:  # noqa: BLE001
            logger.debug("StatusBar not available for idle state")
        try:
            input_area = self.query_one(InputArea)
            input_area.disabled = False
        except Exception:  # noqa: BLE001
            logger.debug("InputArea not available for re-enabling")
        self.is_generating = False
        self.call_after_refresh(self._focus_input_area)

    def _cancel_progressive_load_timers(self) -> None:
        """Cancel any pending progressive load timers from previous session switches."""
        for timer in self._progressive_load_timers:
            try:
                timer.stop()
            except Exception:  # noqa: BLE001
                pass
        self._progressive_load_timers.clear()

    def _session_to_summary(self, session: ChatSession) -> SessionSummary:
        """Convert a ChatSession to a SessionSummary."""
        from tinychat.models.session import SessionSummary  # noqa: PLC0415

        return SessionSummary(
            id=session.id,
            title=session.title,
            backend_name=session.backend_name,
            model=session.model,
            created_at=session.created_at,
            updated_at=session.updated_at or session.created_at,
            message_count=len(session.messages),
        )

    async def _build_session_summaries(self) -> list[SessionSummary]:
        """Build list of all session summaries from storage."""
        start_time = time.perf_counter()

        if not self.session_manager:
            return []
        # Get summaries from disk (includes all historical sessions)
        summaries = await self.session_manager.get_all_session_summaries_async()
        # Ensure current active session is included (it might be new and not yet saved)
        if self.current_session and not any(
            s.id == self.current_session.id for s in summaries
        ):
            summaries.append(self._session_to_summary(self.current_session))
        # Sort by updated_at descending
        summaries.sort(key=lambda s: s.updated_at, reverse=True)

        total_time = time.perf_counter() - start_time
        if total_time > 0.1:  # Log if takes >100ms
            logger.debug(
                "[PERF] _build_session_summaries: %.2fms for %d summaries",
                total_time * 1000,
                len(summaries),
            )

        return summaries

    async def _refresh_session_list(self) -> None:
        """Refresh the session list from disk.

        This should be called when session metadata changes (created, renamed, deleted).
        Avoid calling during session switches as it's expensive.
        """
        self.sessions = await self._build_session_summaries()

    async def action_new_session(self) -> None:
        """Create a new session (Ctrl+T)."""
        await self._create_new_session()

    async def action_show_sessions(self) -> None:
        """Open session list dialog (Ctrl+L or /sessions)."""
        await self.action_manage_history_sessions()

    def _on_session_selected(self, result: str | None) -> None:
        if result is None:
            self._focus_input_area()
            return
        if isinstance(result, tuple):
            if result[0] == "rename":
                _, session_id, current_title = result
                from tinychat.components.rename_dialog import RenameSessionScreen  # noqa: PLC0415

                def on_renamed(new_title: str | None) -> None:
                    if new_title and self.session_manager:
                        self.session_manager.rename_session(session_id, new_title)
                        self._update_header_bar()
                        self._sync_terminal_title()
                        # 会话重命名后需要刷新会话列表
                        # Use create_task for async refresh
                        asyncio.create_task(self._refresh_session_list())
                    self._focus_input_area()

                self.push_screen(
                    RenameSessionScreen(session_id, current_title),
                    callback=on_renamed,
                )
        elif isinstance(result, str):
            asyncio.create_task(self._switch_to_session(result))

    def _on_session_deleted(self, session_id: str, current_id: str | None) -> None:
        if session_id == current_id and self.session_manager:
            remaining = list(self.session_manager.sessions.values())
            if remaining:
                asyncio.create_task(self._switch_to_session(remaining[0].id))
            else:
                asyncio.create_task(self._create_new_session())
        # 会话删除后刷新会话列表
        asyncio.create_task(self._refresh_session_list())
        self._focus_input_area()

    async def action_manage_history_sessions(self) -> None:
        """Open session history management dialog."""
        from tinychat.components.session_list_dialog import SessionListScreen  # noqa: PLC0415

        all_sessions = (
            await self.session_manager.get_all_session_summaries_async()
            if self.session_manager
            else []
        )
        current_id = self.current_session.id if self.current_session else None

        self.push_screen(
            SessionListScreen(
                all_sessions,
                current_id,
                session_manager=self.session_manager,
                on_session_deleted=lambda sid: self._on_session_deleted(
                    sid,
                    current_id,
                ),
            ),
            callback=self._on_session_selected,
        )

    def show_command_palette(self) -> None:
        """Show command palette with available slash commands."""
        from tinychat.components.command_palette import CommandPaletteScreen

        def on_result(result):
            if result and result.get("name"):
                cmd = result["name"]
                if cmd == "/compact":
                    self._ensure_tools_initialized()  # Ensure compaction manager is initialized
                    backend = self._get_backend()
                    logger.debug("Command palette /compact triggered")
                    logger.debug(f"  backend: {backend}")
                    logger.debug(f"  _compaction_manager: {self._compaction_manager}")
                    logger.debug(f"  current_session: {self.current_session}")
                    if backend and self._compaction_manager and self.current_session:
                        logger.debug("Starting force compaction from command palette")
                        logger.debug(
                            f"  compaction_manager.status_bar: {self._compaction_manager.status_bar}"
                        )
                        # Check if compaction is enabled before starting
                        if not self._compaction_manager.config.enabled:
                            self.notify(
                                _(
                                    "Summary feature is disabled. Enable it in config: [compaction] enabled = true"
                                ),
                                title=_("Info"),
                            )
                            return
                        # Status bar will be updated by CompactionManager._compact()
                        # Don't set status here to avoid race conditions
                        asyncio.create_task(self._run_compaction_force(backend))
                    else:
                        if not backend:
                            self.notify(
                                _(
                                    "No backend connected. Please configure a backend first."
                                ),
                                title=_("Info"),
                            )
                        elif not self.current_session:
                            self.notify(
                                _("Please start a conversation first"),
                                title=_("Info"),
                            )
                        logger.warning(
                            f"Cannot run /compact: backend={backend}, session={self.current_session}"
                        )
                elif cmd == "/search":
                    self._show_search_history()
                elif cmd == "/sessions":
                    self.action_manage_history_sessions()
            self._focus_input_area()

        self.push_screen(CommandPaletteScreen(), callback=on_result)

    def _collect_user_questions(self) -> list[dict]:
        if not self.session_manager:
            return []
        questions: list[dict] = []
        seen_contents: set[str] = set()
        for session in self.session_manager.sessions.values():
            for msg in session.messages:
                if msg.role == "user" and msg.content and msg.content.strip():
                    content = msg.content.strip()
                    if content not in seen_contents:
                        seen_contents.add(content)
                        questions.append(
                            {
                                "content": content,
                                "session_title": session.title,
                                "session_id": session.id,
                                "timestamp": msg.timestamp,
                            }
                        )
        if self._persistence:
            try:
                all_sessions = self._persistence.load_all_sessions()
                for session in all_sessions:
                    if session.id in self.session_manager.sessions:
                        continue
                    for msg in session.messages:
                        if msg.role == "user" and msg.content and msg.content.strip():
                            content = msg.content.strip()
                            if content not in seen_contents:
                                seen_contents.add(content)
                                questions.append(
                                    {
                                        "content": content,
                                        "session_title": session.title,
                                        "session_id": session.id,
                                        "timestamp": msg.timestamp,
                                    }
                                )
            except Exception:
                logger.exception("Failed to load sessions for search history")
        questions.sort(key=lambda q: q.get("timestamp") or datetime.min, reverse=True)
        return questions

    def _show_search_history(self) -> None:
        from tinychat.components.search_history import SearchHistoryScreen

        questions = self._collect_user_questions()

        def on_result(result):
            if result and result.get("content"):
                input_area = self.query_one(InputArea)
                if input_area:
                    input_area.text = result["content"]
            self._focus_input_area()

        self.push_screen(SearchHistoryScreen(questions), callback=on_result)
