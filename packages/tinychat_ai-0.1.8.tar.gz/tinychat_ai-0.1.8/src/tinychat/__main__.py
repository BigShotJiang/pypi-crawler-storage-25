"""Main entry point for TinyChat."""

import argparse

from tinychat.app_textual import TinyChatApp
from tinychat.utils.config_manager import load_backends, load_user_config
from tinychat.utils.i18n import init_i18n


def _build_headers(api_key: str | None) -> dict[str, str] | None:
    if api_key:
        return {"Authorization": f"Bearer {api_key}"}
    return None


def main():
    """Main entry point for TinyChat application."""
    parser = argparse.ArgumentParser(
        description="TinyChat - A terminal-based AI chat application"
    )
    parser.add_argument(
        "--debug-no-compaction-limit",
        action="store_true",
        help="Debug mode: skip token limit check for context compaction (always compact)",
    )
    args = parser.parse_args()

    config = load_user_config()
    init_i18n(config.locale)

    backends_config = load_backends()

    app = TinyChatApp(debug_no_compaction_limit=args.debug_no_compaction_limit)

    for backend_config in backends_config:
        client = app.http_manager.create_client(
            base_url=backend_config.endpoint,
            headers=_build_headers(backend_config.api_key),
        )
        if backend_config.type == "ollama":
            from tinychat.backends.ollama import OllamaBackend  # noqa: PLC0415

            backend = OllamaBackend(backend_config, client=client)
        elif backend_config.type == "openai-compatible":
            from tinychat.backends.openai import OpenAIBackend  # noqa: PLC0415

            backend = OpenAIBackend(backend_config, client=client)
        else:
            continue
        app.register_backend(backend_config.name, backend)

    try:
        app.run()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
