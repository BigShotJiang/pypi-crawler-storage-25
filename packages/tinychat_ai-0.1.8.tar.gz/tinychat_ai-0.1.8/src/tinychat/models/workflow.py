"""Workflow management data models for tool execution tracking."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from tinychat.components.tool_execution_widget import ToolExecutionWidget


class WorkflowStatus(Enum):
    """Tool execution status (unified between single and batch workflows)."""

    PENDING = "pending"  # Pending execution
    RUNNING = "running"  # Executing
    COMPLETED = "completed"  # Execution succeeded
    FAILED = "failed"  # Execution failed


@dataclass
class WorkflowItem:
    """Individual tool call workflow item."""

    call_id: str
    tool_name: str
    arguments: dict[str, Any]
    status: WorkflowStatus = WorkflowStatus.PENDING
    started_at: datetime | None = None
    completed_at: datetime | None = None
    result_summary: str | None = None  # Short result summary
    error: str | None = None
    result_metadata: dict[str, Any] = field(default_factory=dict)  # ToolResult.metadata
    widget: ToolExecutionWidget | None = None  # UI widget reference (non-persistent)
    auto_collapse_at: float | None = None  # Timestamp for auto-collapse (epoch seconds)
    execution_id: str | None = None  # Reference to execution context
    workflow_id: str | None = None  # Workflow identifier
    attempt: int = 1  # Current attempt number
    attempt_history: list[dict] = field(default_factory=list)  # List of attempt records
    widget_collapsed: bool = (
        False  # Whether the widget is collapsed (default: expanded)
    )
    tool_icon: str = "🛠️"  # Tool icon for display (default: generic tool)

    @property
    def last_attempt_duration_ms(self) -> int | None:
        """Calculate duration of the last attempt in milliseconds."""
        if not self.attempt_history:
            if not self.started_at:
                return None
            end = self.completed_at or datetime.now()
            return int((end - self.started_at).total_seconds() * 1000)
        last = self.attempt_history[-1]
        started = last.get("started_at")
        ended = last.get("completed_at") or (
            datetime.now() if last.get("status") == WorkflowStatus.RUNNING else None
        )
        if not started or not ended:
            return None
        return int((ended - started).total_seconds() * 1000)

    @property
    def total_duration_ms(self) -> int | None:
        """Calculate total duration across all attempts in milliseconds."""
        if not self.attempt_history:
            if not self.started_at:
                return None
            end = self.completed_at or datetime.now()
            return int((end - self.started_at).total_seconds() * 1000)
        total = 0
        for attempt_record in self.attempt_history:
            started = attempt_record.get("started_at")
            ended = attempt_record.get("completed_at")
            if started and ended:
                total += int((ended - started).total_seconds() * 1000)
        if total == 0:
            return None
        return total

    @property
    def duration_ms(self) -> int | None:
        """Calculate execution duration (last attempt) in milliseconds."""
        return self.last_attempt_duration_ms

    @property
    def duration_str(self) -> str:
        """Human-readable duration string."""
        ms = self.duration_ms
        if ms is None:
            return ""
        if self.attempt > 1:
            total = self.total_duration_ms or 0
            return f"{ms}ms ({self.attempt} attempts, {total}ms total)"
        if ms < 1000:
            return f"{ms}ms"
        return f"{ms / 1000:.1f}s"

    @property
    def status_icon(self) -> str:
        """Get icon for current status."""
        icons = {
            WorkflowStatus.PENDING: "○",
            WorkflowStatus.RUNNING: "⚙️",
            WorkflowStatus.COMPLETED: "✓",
            WorkflowStatus.FAILED: "✗",
        }
        return icons.get(self.status, "○")


@dataclass
class ExecutionContext:
    """Single execution context containing items."""

    execution_id: str
    workflow_id: str | None = None
    items: list[WorkflowItem] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)

    @property
    def total(self) -> int:
        return len(self.items)

    @property
    def completed(self) -> int:
        return sum(1 for i in self.items if i.status == WorkflowStatus.COMPLETED)

    @property
    def failed(self) -> int:
        return sum(1 for i in self.items if i.status == WorkflowStatus.FAILED)

    @property
    def running(self) -> int:
        return sum(1 for i in self.items if i.status == WorkflowStatus.RUNNING)

    @property
    def pending(self) -> int:
        return sum(1 for i in self.items if i.status == WorkflowStatus.PENDING)


@dataclass
class WorkflowState:
    """Overall workflow state containing multiple execution contexts."""

    session_id: str
    executions: dict[str, ExecutionContext] = field(default_factory=dict)
    items: list[WorkflowItem] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    is_collapsed: bool = False  # UI state

    def add_execution(
        self, execution_id: str, workflow_id: str | None = None
    ) -> ExecutionContext:
        """Add a new execution context."""
        ctx = ExecutionContext(execution_id=execution_id, workflow_id=workflow_id)
        self.executions[execution_id] = ctx
        return ctx

    def get_execution(self, execution_id: str) -> ExecutionContext | None:
        """Get an execution context by ID."""
        return self.executions.get(execution_id)

    def get_items_by_execution(self, execution_id: str) -> list[WorkflowItem]:
        """Get items for a specific execution."""
        ctx = self.executions.get(execution_id)
        return ctx.items if ctx else []

    def add_item(self, item: WorkflowItem, execution_id: str | None = None) -> None:
        """Add an item to a specific execution or the default flat list."""
        if execution_id:
            if execution_id not in self.executions:
                self.add_execution(execution_id)
            self.executions[execution_id].items.append(item)
        self.items.append(item)

    def get_flat_items(self) -> list[WorkflowItem]:
        """Get flat list of all items."""
        return self.items

    @property
    def total(self) -> int:
        return len(self.items)

    @property
    def completed(self) -> int:
        return sum(1 for i in self.items if i.status == WorkflowStatus.COMPLETED)

    @property
    def failed(self) -> int:
        return sum(1 for i in self.items if i.status == WorkflowStatus.FAILED)

    @property
    def running(self) -> int:
        return sum(1 for i in self.items if i.status == WorkflowStatus.RUNNING)

    @property
    def pending(self) -> int:
        return sum(1 for i in self.items if i.status == WorkflowStatus.PENDING)

    @property
    def progress_percent(self) -> int:
        """Completion percentage."""
        if self.total == 0:
            return 0
        return int((self.completed / self.total) * 100)

    @property
    def progress_bar(self) -> str:
        """Text-based progress bar."""
        total_bars = 20
        filled = int((self.progress_percent / 100) * total_bars)
        return "█" * filled + "░" * (total_bars - filled)

    @property
    def status_summary(self) -> str:
        """Status summary string."""
        parts = [f"{self.completed}/{self.total} completed"]
        if self.running > 0:
            parts.append(f"{self.running} running")
        if self.failed > 0:
            parts.append(f"{self.failed} failed")
        if self.pending > 0:
            parts.append(f"{self.pending} pending")
        return " - ".join(parts)


@dataclass
class WorkflowStep:
    """Workflow step definition."""

    id: str
    name: str
    tool: str
    arguments: dict[str, Any]
    depends_on: list[str] = field(default_factory=list)
    timeout: int | None = None
    max_retries: int = 1
    requires_confirmation: bool = False


@dataclass
class WorkflowDefinition:
    """Workflow definition."""

    workflow_id: str
    name: str
    description: str
    steps: list[WorkflowStep]
    variables: dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    version: str = "1.0"


@dataclass
class ExecutionState:
    """Execution status."""

    execution_id: str
    workflow_id: str
    status: str  # "pending", "running", "paused", "completed", "failed", "cancelled"
    current_step: str | None = None
    completed_steps: list[str] = field(default_factory=list)
    failed_steps: list[str] = field(default_factory=list)
    step_results: dict[str, Any] = field(default_factory=dict)
    start_time: str | None = None
    end_time: str | None = None
    errors: dict[str, str] = field(default_factory=dict)
