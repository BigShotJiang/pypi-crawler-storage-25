"""Backend configuration models."""

from dataclasses import dataclass, field
from pathlib import Path

from tinychat.models.user_config import UserConfig

__all__ = ["BackendConfig", "LoggingConfig", "UserConfig"]


@dataclass
class BackendConfig:
    name: str
    type: str
    endpoint: str
    default_model: str
    api_key: str | None = None


@dataclass
class LoggingConfig:
    """Logging configuration for TinyChat.

    Attributes:
        enabled: Whether logging is enabled (default: False)
        level: Log level - DEBUG, INFO, WARNING, ERROR (default: INFO)
        file: Path to log file (default: ~/.tinychat/tinychat.log)
        max_size_mb: Maximum size of log file before rotation (default: 5)
        backup_count: Number of backup files to keep (default: 3)
    """

    enabled: bool = False
    level: str = "INFO"
    file: str = field(
        default_factory=lambda: str(Path.home() / ".tinychat" / "tinychat.log"),
    )
    max_size_mb: int = 5
    backup_count: int = 3
