"""TodoList data models."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class TodoItem:
    """A single item in a todo list."""

    id: str
    todo_list_id: str
    step_id: str
    content: str
    status: str = "pending"
    priority: str = "medium"
    depends_on: list[str] = field(default_factory=list)
    tool: str | None = None
    tool_args: dict[str, Any] = field(default_factory=dict)
    result: dict[str, Any] | None = None
    seq_num: int = 0
    created_at: datetime | None = None
    completed_at: datetime | None = None


@dataclass
class TodoList:
    """A todo list belonging to a session."""

    id: str
    session_id: str
    title: str = "Untitled"
    status: str = "active"
    is_active: bool = False
    items: list[TodoItem] = field(default_factory=list)
    created_at: datetime | None = None
    updated_at: datetime | None = None


@dataclass
class ExecutionStepResult:
    """Result of a single step during execution."""

    id: str
    execution_id: str
    step_id: str
    status: str = "pending"
    result: dict[str, Any] | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None


@dataclass
class Execution:
    """An execution of a workflow."""

    id: str
    todo_list_id: str
    status: str = "pending"
    current_step_id: str | None = None
    start_time: datetime | None = None
    end_time: datetime | None = None
    error_message: str | None = None
    step_results: list[ExecutionStepResult] = field(default_factory=list)
