"""Chat message data model."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from tinychat.tools.base import ToolResult


@dataclass
class ToolCall:
    """AI-initiated tool call."""

    id: str
    name: str
    arguments: dict[str, Any]
    result: "ToolResult | None" = None


@dataclass
class Message:
    """A single chat message."""

    role: str
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    tokens: int | None = None
    metadata: dict = field(default_factory=dict)
    tool_calls: list[ToolCall] | None = None
    tool_call_id: str | None = None
    tool_name: str | None = None
    reasoning_content: str | None = None
