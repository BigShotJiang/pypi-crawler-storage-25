"""Chat session data model."""

from dataclasses import dataclass, field
from datetime import datetime

from tinychat.models.message import Message


@dataclass
class ChatSession:
    """A chat session with message history."""

    id: str
    title: str
    backend_name: str
    model: str
    messages: list[Message] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime | None = None
    parameters: dict = field(default_factory=dict)
    # Metadata fields
    message_count: int = 0
    total_tokens: int = 0
    last_message_at: datetime | None = None
    # Input history for up/down arrow navigation
    input_history: list[str] = field(default_factory=list)
    history_index: int = 0
    # Number of times this session has been forked
    fork_count: int = 0
    workflow_history: list[dict] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Initialize updated_at to created_at if not set."""
        if self.updated_at is None:
            self.updated_at = self.created_at

    def touch(self) -> None:
        """Update the last modification timestamp."""
        self.updated_at = datetime.now()

    def update_metadata(self) -> None:
        """Update metadata from messages.

        Calculates message count, total tokens, and last message timestamp
        from the current messages list.
        """
        self.message_count = len(self.messages)
        self.total_tokens = sum(m.tokens or 0 for m in self.messages)
        if self.messages:
            self.last_message_at = self.messages[-1].timestamp
        else:
            self.last_message_at = None


@dataclass
class SessionSummary:
    """Lightweight summary of a session for list display.

    This contains only metadata, not the full message history,
    to keep memory usage low when browsing session history.
    """

    id: str
    title: str
    backend_name: str
    model: str
    created_at: datetime
    updated_at: datetime
    message_count: int = 0
    preview: str = ""
