"""Custom exception classes for TinyChat application."""

import json
import re
from pathlib import Path


def describe_http_error(error: Exception) -> str:
    msg = str(error).strip()
    if msg:
        return msg
    typename = type(error).__name__
    descriptions: dict[str, str] = {
        "ConnectError": "Connection refused — is the server running?",
        "ConnectTimeout": "Connection timed out — server may be unreachable",
        "ReadTimeout": "Read timed out — server took too long to respond",
        "WriteTimeout": "Write timed out — server took too long to accept data",
        "PoolTimeout": "Connection pool exhausted — too many requests",
        "UnsupportedProtocol": "Unsupported protocol in endpoint URL",
        "ReadError": "Read error — connection interrupted while receiving data",
    }
    return descriptions.get(typename, typename)


def is_retryable_error(error: Exception) -> bool:
    """Check if an error is transient and should be retried.

    Retryable errors (NOT saved to session):
    - 429 Rate Limit
    - 5xx Server errors
    - "Overloaded" provider errors
    - Network connection errors
    - Timeout errors

    Non-retryable errors (SHOULD be saved to session):
    - 400 Bad Request
    - 401 Unauthorized
    - 403 Forbidden
    - 404 Not Found
    - Context overflow errors
    - Invalid request errors

    Args:
        error: The exception to check.

    Returns:
        True if the error is retryable and should not be persisted.
    """
    error_str = str(error).lower()
    error_type = type(error).__name__

    # Network/connection errors are always retryable
    network_errors = {
        "connecterror",
        "connecttimeout",
        "readtimeout",
        "writetimeout",
        "pooltimeout",
        "readerror",
        "timeouterror",
    }
    if error_type.lower() in network_errors:
        return True

    # Check for rate limit patterns
    rate_limit_patterns = [
        "rate limit",
        "rate_limit",
        "too many requests",
        "rate increased too quickly",
        "429",
    ]
    if any(pattern in error_str for pattern in rate_limit_patterns):
        return True

    # Check for server overload patterns
    overload_patterns = [
        "overloaded",
        "capacity",
        "temporarily unavailable",
        "service unavailable",
        "internal server error",
        "bad gateway",
        "gateway timeout",
        "server error",
    ]
    if any(pattern in error_str for pattern in overload_patterns):
        return True

    # Check HTTP status codes in error message
    # 5xx errors are retryable
    if re.search(r"\b5\d{2}\b", error_str):
        return True

    # Check for JSON error responses with retryable codes
    try:
        if hasattr(error, "response"):
            response = getattr(error, "response", None)
            if response is not None:
                status_code = getattr(response, "status_code", None)
                if status_code is not None:
                    if status_code == 429 or status_code >= 500:
                        return True
                    if status_code in (400, 401, 403, 404):
                        return False

        # Try parsing error message as JSON
        json_match = re.search(r"\{.*\}", error_str)
        if json_match:
            parsed = json.loads(json_match.group())
            if isinstance(parsed, dict):
                code = str(parsed.get("code", "")).lower()
                error_type_json = str(parsed.get("type", "")).lower()

                if "rate_limit" in code or "too_many_requests" in error_type_json:
                    return True
                if "exhausted" in code or "unavailable" in code:
                    return True

                # Check nested error object
                nested_error = parsed.get("error", {})
                if isinstance(nested_error, dict):
                    nested_type = str(nested_error.get("type", "")).lower()
                    nested_code = str(nested_error.get("code", "")).lower()
                    if (
                        "too_many_requests" in nested_type
                        or "rate_limit" in nested_code
                    ):
                        return True
    except (json.JSONDecodeError, AttributeError):
        pass

    # Default: non-retryable (should be persisted)
    return False


class TinyChatError(Exception):
    """Base exception for all TinyChat errors."""


class BackendError(TinyChatError):
    """Backend connection and communication errors."""

    def __init__(
        self,
        message: str,
        backend_name: str,
        original_error: Exception | None = None,
    ):
        self.backend_name = backend_name
        self.original_error = original_error
        super().__init__(message)


class ValidationError(TinyChatError):
    """User input validation errors."""

    def __init__(self, field: str, message: str):
        self.field = field
        super().__init__(message)


class PersistenceError(TinyChatError):
    """Session persistence errors."""

    def __init__(
        self,
        message: str,
        file_path: Path | None = None,
        original_error: Exception | None = None,
    ):
        self.file_path = file_path
        self.original_error = original_error
        super().__init__(message)
