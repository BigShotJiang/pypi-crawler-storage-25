import sqlite3
from pathlib import Path


class DatabaseManager:
    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path
        self._connection: sqlite3.Connection | None = None

    def initialize(self) -> None:
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._connection = sqlite3.connect(str(self._db_path))
        self._connection.execute("PRAGMA journal_mode=WAL")
        self._connection.execute("PRAGMA foreign_keys=ON")
        self._connection.execute("PRAGMA busy_timeout=5000")
        self._connection.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY,
                title TEXT,
                backend_name TEXT,
                model TEXT,
                created_at TEXT,
                updated_at TEXT,
                last_message_at TEXT,
                message_count INTEGER DEFAULT 0,
                total_tokens INTEGER DEFAULT 0,
                input_history TEXT DEFAULT '[]',
                history_index INTEGER DEFAULT 0,
                fork_count INTEGER DEFAULT 0,
                workflow_history TEXT DEFAULT '[]',
                metadata TEXT DEFAULT '{}'
            )
        """)
        self._connection.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                session_id TEXT REFERENCES sessions(id),
                sequence_num INTEGER,
                role TEXT,
                content TEXT,
                timestamp TEXT,
                tokens INTEGER,
                tool_call_id TEXT,
                tool_name TEXT,
                metadata TEXT DEFAULT '{}'
            )
        """)
        self._connection.execute("""
            CREATE TABLE IF NOT EXISTS tool_calls (
                id TEXT PRIMARY KEY,
                message_id TEXT REFERENCES messages(id),
                session_id TEXT REFERENCES sessions(id),
                name TEXT,
                arguments TEXT DEFAULT '{}',
                result TEXT DEFAULT '{}',
                status TEXT,
                created_at TEXT,
                executed_at TEXT
            )
        """)
        self._connection.execute("""
            CREATE TABLE IF NOT EXISTS todo_lists (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
                title TEXT DEFAULT 'Untitled',
                status TEXT DEFAULT 'active' CHECK(status IN ('active', 'completed', 'discarded')),
                is_active INTEGER DEFAULT 0 CHECK(is_active IN (0, 1)),
                created_at TEXT DEFAULT (datetime('now')),
                updated_at TEXT DEFAULT (datetime('now'))
            )
        """)
        self._connection.execute("""
            CREATE TABLE IF NOT EXISTS todo_items (
                id TEXT PRIMARY KEY,
                todo_list_id TEXT NOT NULL REFERENCES todo_lists(id) ON DELETE CASCADE,
                step_id TEXT NOT NULL,
                content TEXT NOT NULL,
                status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'in_progress', 'completed', 'failed')),
                priority TEXT DEFAULT 'medium' CHECK(priority IN ('high', 'medium', 'low')),
                depends_on TEXT DEFAULT '[]',
                tool TEXT,
                tool_args TEXT DEFAULT '{}',
                result TEXT,
                seq_num INTEGER DEFAULT 0,
                created_at TEXT DEFAULT (datetime('now')),
                completed_at TEXT
            )
        """)
        self._connection.execute("""
            CREATE TABLE IF NOT EXISTS executions (
                id TEXT PRIMARY KEY,
                todo_list_id TEXT NOT NULL REFERENCES todo_lists(id) ON DELETE CASCADE,
                status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'running', 'completed', 'failed', 'cancelled')),
                current_step_id TEXT,
                start_time TEXT,
                end_time TEXT,
                error_message TEXT
            )
        """)
        self._connection.execute("""
            CREATE TABLE IF NOT EXISTS execution_step_results (
                id TEXT PRIMARY KEY,
                execution_id TEXT NOT NULL REFERENCES executions(id) ON DELETE CASCADE,
                step_id TEXT NOT NULL,
                status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'in_progress', 'completed', 'failed')),
                result TEXT,
                started_at TEXT,
                completed_at TEXT
            )
        """)
        self._connection.execute("""
            CREATE TRIGGER IF NOT EXISTS ensure_single_active_todo_list_insert
            BEFORE INSERT ON todo_lists
            WHEN NEW.is_active = 1
            BEGIN
                UPDATE todo_lists SET is_active = 0
                WHERE session_id = NEW.session_id AND is_active = 1;
            END
        """)
        self._connection.execute("""
            CREATE TRIGGER IF NOT EXISTS ensure_single_active_todo_list_update
            BEFORE UPDATE ON todo_lists
            WHEN NEW.is_active = 1 AND OLD.is_active = 0
            BEGIN
                UPDATE todo_lists SET is_active = 0
                WHERE session_id = NEW.session_id AND is_active = 1 AND id != NEW.id;
            END
        """)
        self._connection.execute("""
            CREATE TRIGGER IF NOT EXISTS todo_lists_updated_at
            AFTER UPDATE ON todo_lists
            BEGIN
                UPDATE todo_lists SET updated_at = datetime('now') WHERE id = NEW.id;
            END
        """)
        self._connection.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts
            USING fts5(content, role, session_id, tokenize='trigram')
        """)
        self._connection.execute("""
            CREATE TRIGGER IF NOT EXISTS messages_fts_ai_insert
            AFTER INSERT ON messages
            BEGIN
                INSERT INTO messages_fts(rowid, content, role, session_id)
                VALUES (NEW.rowid, NEW.content, NEW.role, NEW.session_id);
            END
        """)
        self._connection.execute("""
            CREATE TRIGGER IF NOT EXISTS messages_fts_au_update
            AFTER UPDATE ON messages
            BEGIN
                DELETE FROM messages_fts WHERE rowid = OLD.rowid;
                INSERT INTO messages_fts(rowid, content, role, session_id)
                VALUES (NEW.rowid, NEW.content, NEW.role, NEW.session_id);
            END
        """)
        self._connection.execute("""
            CREATE TRIGGER IF NOT EXISTS messages_fts_ad_delete
            AFTER DELETE ON messages
            BEGIN
                DELETE FROM messages_fts WHERE rowid = OLD.rowid;
            END
        """)
        self._connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_sessions_updated_at ON sessions(updated_at)
        """)
        self._connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_sessions_created_at ON sessions(created_at)
        """)
        self._connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_sessions_backend_name ON sessions(backend_name)
        """)
        self._connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_messages_session_id_seq ON messages(session_id, sequence_num)
        """)
        self._connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_messages_timestamp ON messages(timestamp)
        """)
        self._connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_messages_role_timestamp ON messages(role, timestamp)
        """)
        self._connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_tool_calls_message_id ON tool_calls(message_id)
        """)
        self._connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_tool_calls_session_id ON tool_calls(session_id)
        """)
        self._connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_todo_lists_session_id ON todo_lists(session_id)
        """)
        self._connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_todo_items_todo_list_id ON todo_items(todo_list_id)
        """)
        self._connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_executions_todo_list_id ON executions(todo_list_id)
        """)
        self._connection.execute("""
            CREATE INDEX IF NOT EXISTS idx_execution_step_results_execution_id ON execution_step_results(execution_id)
        """)
        self._connection.commit()

    @property
    def connection(self) -> sqlite3.Connection:
        if self._connection is None:
            raise RuntimeError("Database not initialized. Call initialize() first.")
        try:
            self._connection.execute("SELECT 1")
        except sqlite3.Error:
            self._connection = sqlite3.connect(str(self._db_path))
            self._connection.execute("PRAGMA journal_mode=WAL")
            self._connection.execute("PRAGMA foreign_keys=ON")
            self._connection.execute("PRAGMA busy_timeout=5000")
        return self._connection

    def close(self) -> None:
        if self._connection is not None:
            self._connection.close()
            self._connection = None
