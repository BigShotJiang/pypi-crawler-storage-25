"""JSON-to-SQLite session migration."""

import json
import logging
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

from tinychat.db.connection import DatabaseManager
from tinychat.db.persistence import SQLitePersistence
from tinychat.utils.session_persistence import SessionPersistence

logger = logging.getLogger(__name__)


class JsonToSqliteMigrator:
    def __init__(self, json_dir: Path, sqlite_path: Path):
        self._json_dir = json_dir
        self._sqlite_path = sqlite_path

    def should_migrate(self) -> bool:
        json_files = list(self._json_dir.glob("*.json"))
        if not json_files:
            return False
        if not self._sqlite_path.exists():
            return True
        if self._sqlite_path.stat().st_size == 0:
            return True
        try:
            conn = sqlite3.connect(str(self._sqlite_path))
            try:
                cursor = conn.execute("SELECT count(*) FROM sessions")
                if cursor.fetchone()[0] > 0:
                    return False
            finally:
                conn.close()
        except (sqlite3.Error, OSError) as e:
            logger.warning(
                "Error checking SQLite database %s: %s. Assuming migration needed.",
                self._sqlite_path,
                e,
            )
        return True

    def migrate(self) -> int:
        json_files = list(self._json_dir.glob("*.json"))
        if not json_files:
            return 0

        self._sqlite_path.parent.mkdir(parents=True, exist_ok=True)
        db_manager = DatabaseManager(self._sqlite_path)
        db_manager.initialize()
        db_manager.close()

        sqlite_persistence = SQLitePersistence(self._sqlite_path)

        count = 0
        failed_files: list[Path] = []
        for json_file in json_files:
            try:
                with open(json_file) as f:
                    data = json.load(f)
                data = SessionPersistence._deserialize_session_data(data)
                from tinychat.models.session import ChatSession

                session = ChatSession(**data)
                sqlite_persistence.save_session(session)
                count += 1
                logger.info("Migrated session %s (%s)", session.id, session.title)
            except (
                json.JSONDecodeError,
                OSError,
                KeyError,
                TypeError,
                ValueError,
            ) as e:
                logger.exception("Failed to migrate %s: %s", json_file.name, e)
                failed_files.append(json_file)

        if count > 0:
            self.backup_json_files()

        if failed_files:
            logger.warning(
                "Migration completed with %d success(es) and %d failure(s). "
                "Failed files: %s",
                count,
                len(failed_files),
                ", ".join(str(f) for f in failed_files),
            )

        return count

    def backup_json_files(self) -> Path:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = self._json_dir / f"backup_{timestamp}"
        backup_dir.mkdir(parents=True, exist_ok=True)

        for json_file in self._json_dir.glob("*.json"):
            shutil.move(str(json_file), str(backup_dir / json_file.name))

        logger.info(
            "Backed up %d JSON files to %s",
            len(list(backup_dir.glob("*.json"))),
            backup_dir,
        )
        return backup_dir
