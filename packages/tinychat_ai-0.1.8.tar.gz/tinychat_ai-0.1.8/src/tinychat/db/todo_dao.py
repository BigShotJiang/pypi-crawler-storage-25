"""Data Access Object for TodoList persistence."""

from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import datetime
from typing import Any

from tinychat.models.todo import Execution, ExecutionStepResult, TodoItem, TodoList


class TodoListDAO:
    """Data Access Object for TodoList, TodoItem, and Execution."""

    def __init__(self, connection: sqlite3.Connection) -> None:
        self._conn = connection

    def create_list(self, session_id: str, title: str = "Untitled") -> TodoList:
        """Create a new todo list for a session."""
        list_id = str(uuid.uuid4())
        now = datetime.now().isoformat()
        self._conn.execute(
            """INSERT INTO todo_lists (id, session_id, title, status, is_active, created_at, updated_at)
               VALUES (?, ?, ?, 'active', 0, ?, ?)""",
            (list_id, session_id, title, now, now),
        )
        self._conn.commit()
        return TodoList(
            id=list_id,
            session_id=session_id,
            title=title,
            status="active",
            is_active=False,
            items=[],
            created_at=datetime.fromisoformat(now),
            updated_at=datetime.fromisoformat(now),
        )

    def get_list(self, list_id: str) -> TodoList | None:
        """Get a todo list by ID, including its items."""
        cursor = self._conn.execute(
            """SELECT id, session_id, title, status, is_active, created_at, updated_at
               FROM todo_lists WHERE id = ?""",
            (list_id,),
        )
        row = cursor.fetchone()
        if row is None:
            return None

        items = self._get_items_for_list(list_id)
        return TodoList(
            id=row[0],
            session_id=row[1],
            title=row[2],
            status=row[3],
            is_active=bool(row[4]),
            items=items,
            created_at=self._parse_datetime(row[5]),
            updated_at=self._parse_datetime(row[6]),
        )

    def list_all(self, session_id: str) -> list[TodoList]:
        """Get all todo lists for a session."""
        cursor = self._conn.execute(
            """SELECT id, session_id, title, status, is_active, created_at, updated_at
               FROM todo_lists WHERE session_id = ? ORDER BY created_at DESC""",
            (session_id,),
        )
        rows = cursor.fetchall()
        result = []
        for row in rows:
            items = self._get_items_for_list(row[0])
            result.append(
                TodoList(
                    id=row[0],
                    session_id=row[1],
                    title=row[2],
                    status=row[3],
                    is_active=bool(row[4]),
                    items=items,
                    created_at=self._parse_datetime(row[5]),
                    updated_at=self._parse_datetime(row[6]),
                )
            )
        return result

    def delete_list(self, list_id: str) -> None:
        """Delete a todo list (cascades to items and executions)."""
        self._conn.execute("DELETE FROM todo_lists WHERE id = ?", (list_id,))
        self._conn.commit()

    def add_item(
        self,
        todo_list_id: str,
        step_id: str,
        content: str,
        priority: str = "medium",
        depends_on: list[str] | None = None,
        tool: str | None = None,
        tool_args: dict[str, Any] | None = None,
    ) -> TodoItem:
        """Add an item to a todo list."""
        item_id = str(uuid.uuid4())
        now = datetime.now().isoformat()
        depends_on = depends_on or []
        tool_args = tool_args or {}

        cursor = self._conn.execute(
            "SELECT COALESCE(MAX(seq_num), -1) + 1 FROM todo_items WHERE todo_list_id = ?",
            (todo_list_id,),
        )
        seq_num = cursor.fetchone()[0]

        self._conn.execute(
            """INSERT INTO todo_items
               (id, todo_list_id, step_id, content, status, priority, depends_on, tool, tool_args, seq_num, created_at)
               VALUES (?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?)""",
            (
                item_id,
                todo_list_id,
                step_id,
                content,
                priority,
                json.dumps(depends_on),
                tool,
                json.dumps(tool_args),
                seq_num,
                now,
            ),
        )
        self._conn.commit()
        return TodoItem(
            id=item_id,
            todo_list_id=todo_list_id,
            step_id=step_id,
            content=content,
            status="pending",
            priority=priority,
            depends_on=depends_on,
            tool=tool,
            tool_args=tool_args,
            seq_num=seq_num,
            created_at=datetime.fromisoformat(now),
        )

    def _get_items_for_list(self, list_id: str) -> list[TodoItem]:
        """Get all items for a todo list."""
        cursor = self._conn.execute(
            """SELECT id, todo_list_id, step_id, content, status, priority, depends_on,
                      tool, tool_args, result, seq_num, created_at, completed_at
               FROM todo_items WHERE todo_list_id = ? ORDER BY seq_num""",
            (list_id,),
        )
        rows = cursor.fetchall()
        return [
            TodoItem(
                id=row[0],
                todo_list_id=row[1],
                step_id=row[2],
                content=row[3],
                status=row[4],
                priority=row[5],
                depends_on=json.loads(row[6]) if row[6] else [],
                tool=row[7],
                tool_args=json.loads(row[8]) if row[8] else {},
                result=json.loads(row[9]) if row[9] else None,
                seq_num=row[10],
                created_at=self._parse_datetime(row[11]),
                completed_at=self._parse_datetime(row[12]),
            )
            for row in rows
        ]

    def activate_list(self, list_id: str) -> None:
        """Activate a todo list (deactivates others in same session)."""
        cursor = self._conn.execute(
            "SELECT session_id FROM todo_lists WHERE id = ?", (list_id,)
        )
        row = cursor.fetchone()
        if row is None:
            return
        session_id = row[0]

        self._conn.execute(
            "UPDATE todo_lists SET is_active = 0 WHERE session_id = ?", (session_id,)
        )
        self._conn.execute(
            "UPDATE todo_lists SET is_active = 1 WHERE id = ?", (list_id,)
        )
        self._conn.commit()

    def deactivate_list(self, list_id: str) -> None:
        """Deactivate a todo list."""
        self._conn.execute(
            "UPDATE todo_lists SET is_active = 0 WHERE id = ?", (list_id,)
        )
        self._conn.commit()

    def get_active_list(self, session_id: str) -> TodoList | None:
        """Get the active todo list for a session (if exists and not completed/discarded)."""
        cursor = self._conn.execute(
            """SELECT id FROM todo_lists
               WHERE session_id = ? AND is_active = 1
               AND status NOT IN ('completed', 'discarded')""",
            (session_id,),
        )
        row = cursor.fetchone()
        if row is None:
            return None
        return self.get_list(row[0])

    def update_list_status(self, list_id: str, status: str) -> None:
        """Update todo list status. 'completed' or 'discarded' deactivates."""
        is_active = 0 if status in ("completed", "discarded") else None
        if is_active is not None:
            self._conn.execute(
                "UPDATE todo_lists SET status = ?, is_active = ? WHERE id = ?",
                (status, is_active, list_id),
            )
        else:
            self._conn.execute(
                "UPDATE todo_lists SET status = ? WHERE id = ?", (status, list_id)
            )
        self._conn.commit()

    def update_item_status(self, item_id: str, status: str) -> None:
        """Update item status. Sets completed_at if completed."""
        if status == "completed":
            now = datetime.now().isoformat()
            self._conn.execute(
                "UPDATE todo_items SET status = ?, completed_at = ? WHERE id = ?",
                (status, now, item_id),
            )
        else:
            self._conn.execute(
                "UPDATE todo_items SET status = ? WHERE id = ?", (status, item_id)
            )
        self._conn.commit()

    def update_item_result(self, item_id: str, result: dict[str, Any]) -> None:
        """Update item execution result."""
        self._conn.execute(
            "UPDATE todo_items SET result = ? WHERE id = ?",
            (json.dumps(result), item_id),
        )
        self._conn.commit()

    def delete_item(self, item_id: str) -> None:
        """Delete an item."""
        self._conn.execute("DELETE FROM todo_items WHERE id = ?", (item_id,))
        self._conn.commit()

    def is_workflow(self, list_id: str) -> bool:
        """Check if a todo_list is a workflow (has items with dependencies)."""
        cursor = self._conn.execute(
            "SELECT depends_on FROM todo_items WHERE todo_list_id = ?",
            (list_id,),
        )
        for row in cursor.fetchall():
            depends_on = json.loads(row[0]) if row[0] else []
            if depends_on:
                return True
        return False

    @staticmethod
    def _parse_datetime(value: str | None) -> datetime | None:
        """Parse ISO format datetime string."""
        if value is None:
            return None
        try:
            return datetime.fromisoformat(value)
        except ValueError:
            return None

    def create_execution(self, todo_list_id: str) -> Execution:
        """Create a new execution for a workflow."""
        exec_id = str(uuid.uuid4())
        now = datetime.now().isoformat()
        self._conn.execute(
            """INSERT INTO executions (id, todo_list_id, status, start_time)
               VALUES (?, ?, 'pending', ?)""",
            (exec_id, todo_list_id, now),
        )
        self._conn.commit()
        return Execution(
            id=exec_id,
            todo_list_id=todo_list_id,
            status="pending",
            start_time=datetime.fromisoformat(now),
        )

    def get_execution(self, execution_id: str) -> Execution | None:
        """Get execution by ID with step results."""
        cursor = self._conn.execute(
            """SELECT id, todo_list_id, status, current_step_id, start_time, end_time, error_message
               FROM executions WHERE id = ?""",
            (execution_id,),
        )
        row = cursor.fetchone()
        if row is None:
            return None

        step_results = self._get_step_results(execution_id)
        return Execution(
            id=row[0],
            todo_list_id=row[1],
            status=row[2],
            current_step_id=row[3],
            start_time=self._parse_datetime(row[4]),
            end_time=self._parse_datetime(row[5]),
            error_message=row[6],
            step_results=step_results,
        )

    def update_execution(
        self,
        execution_id: str,
        status: str | None = None,
        current_step_id: str | None = None,
        error_message: str | None = None,
    ) -> None:
        """Update execution fields."""
        updates = []
        params = []
        if status is not None:
            updates.append("status = ?")
            params.append(status)
            if status in ("completed", "failed", "cancelled"):
                updates.append("end_time = ?")
                params.append(datetime.now().isoformat())
        if current_step_id is not None:
            updates.append("current_step_id = ?")
            params.append(current_step_id)
        if error_message is not None:
            updates.append("error_message = ?")
            params.append(error_message)
        if updates:
            params.append(execution_id)
            self._conn.execute(
                f"UPDATE executions SET {', '.join(updates)} WHERE id = ?",
                params,
            )
            self._conn.commit()

    def record_step_result(
        self,
        execution_id: str,
        step_id: str,
        status: str,
        result: dict[str, Any] | None = None,
    ) -> None:
        """Record a step result during execution."""
        result_id = str(uuid.uuid4())
        now = datetime.now().isoformat()
        self._conn.execute(
            """INSERT INTO execution_step_results (id, execution_id, step_id, status, result, started_at, completed_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                result_id,
                execution_id,
                step_id,
                status,
                json.dumps(result) if result else None,
                now,
                now if status in ("completed", "failed") else None,
            ),
        )
        self._conn.commit()

    def get_next_executable_step(self, execution_id: str) -> TodoItem | None:
        """Get the next executable step (dependencies satisfied, not completed)."""
        cursor = self._conn.execute(
            "SELECT todo_list_id FROM executions WHERE id = ?", (execution_id,)
        )
        row = cursor.fetchone()
        if row is None:
            return None
        todo_list_id = row[0]

        cursor = self._conn.execute(
            "SELECT step_id FROM execution_step_results WHERE execution_id = ? AND status = 'completed'",
            (execution_id,),
        )
        completed_steps = {r[0] for r in cursor.fetchall()}

        items = self._get_items_for_list(todo_list_id)

        for item in items:
            if item.step_id in completed_steps:
                continue
            if all(dep in completed_steps for dep in item.depends_on):
                return item
        return None

    def _get_step_results(self, execution_id: str) -> list[ExecutionStepResult]:
        """Get step results for an execution."""
        cursor = self._conn.execute(
            """SELECT id, execution_id, step_id, status, result, started_at, completed_at
               FROM execution_step_results WHERE execution_id = ?""",
            (execution_id,),
        )
        rows = cursor.fetchall()
        return [
            ExecutionStepResult(
                id=row[0],
                execution_id=row[1],
                step_id=row[2],
                status=row[3],
                result=json.loads(row[4]) if row[4] else None,
                started_at=self._parse_datetime(row[5]),
                completed_at=self._parse_datetime(row[6]),
            )
            for row in rows
        ]
