import json
import sqlite3
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from tinychat.models.message import Message, ToolCall
from tinychat.models.session import ChatSession, SessionSummary
from tinychat.tools.base import ToolResult


class SQLitePersistence:
    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path
        self._conn: sqlite3.Connection = sqlite3.connect(str(db_path))
        self._conn.execute("PRAGMA foreign_keys = ON")

    @property
    def storage_dir(self) -> Path:
        return self._db_path.parent

    def close(self) -> None:
        self._conn.close()

    def save_session(self, session: ChatSession) -> None:
        updated_at = session.updated_at or session.created_at
        last_message_at = session.last_message_at
        self._conn.execute(
            """INSERT OR REPLACE INTO sessions
               (id, title, backend_name, model, created_at, updated_at,
                last_message_at, message_count, total_tokens, input_history,
                history_index, fork_count, workflow_history, metadata)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                session.id,
                session.title,
                session.backend_name,
                session.model,
                session.created_at.isoformat(),
                updated_at.isoformat() if updated_at else None,
                last_message_at.isoformat() if last_message_at else None,
                session.message_count,
                session.total_tokens,
                json.dumps(session.input_history),
                session.history_index,
                session.fork_count,
                json.dumps(session.workflow_history),
                json.dumps(session.parameters),
            ),
        )
        self._save_messages_incremental(session)
        self._conn.commit()

    def _save_messages_incremental(self, session: ChatSession) -> None:
        """Save messages incrementally, only updating what changed."""
        existing_rows = self._conn.execute(
            "SELECT id, sequence_num, role, content, timestamp, tokens, "
            "tool_call_id, tool_name, metadata FROM messages WHERE session_id=? "
            "ORDER BY sequence_num",
            (session.id,),
        ).fetchall()

        existing_by_seq: dict[int, tuple] = {row[1]: row for row in existing_rows}
        existing_seqs = set(existing_by_seq.keys())
        current_seqs = set(range(len(session.messages)))

        # Delete messages that are no longer present
        to_delete = existing_seqs - current_seqs
        for seq in to_delete:
            msg_id = existing_by_seq[seq][0]
            self._conn.execute("DELETE FROM tool_calls WHERE message_id=?", (msg_id,))
            self._conn.execute("DELETE FROM messages WHERE id=?", (msg_id,))

        for seq, msg in enumerate(session.messages):
            if seq in existing_by_seq:
                existing = existing_by_seq[seq]
                msg_id = existing[0]
                if self._message_changed(existing, msg):
                    self._conn.execute(
                        """UPDATE messages SET role=?, content=?, timestamp=?,
                           tokens=?, tool_call_id=?, tool_name=?, metadata=?
                           WHERE id=?""",
                        (
                            msg.role,
                            msg.content,
                            msg.timestamp.isoformat(),
                            msg.tokens,
                            msg.tool_call_id,
                            msg.tool_name,
                            json.dumps(msg.metadata),
                            msg_id,
                        ),
                    )
                self._save_tool_calls_incremental(session.id, msg_id, msg.tool_calls)
            else:
                msg_id = str(uuid.uuid4())
                self._conn.execute(
                    """INSERT INTO messages
                       (id, session_id, sequence_num, role, content, timestamp,
                        tokens, tool_call_id, tool_name, metadata)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        msg_id,
                        session.id,
                        seq,
                        msg.role,
                        msg.content,
                        msg.timestamp.isoformat(),
                        msg.tokens,
                        msg.tool_call_id,
                        msg.tool_name,
                        json.dumps(msg.metadata),
                    ),
                )
                if msg.tool_calls:
                    for tc in msg.tool_calls:
                        self._insert_tool_call(session.id, msg_id, tc)

    def _message_changed(self, existing: tuple, msg: Message) -> bool:
        """Check if a message has changed compared to the existing row."""
        return (
            existing[2] != msg.role
            or existing[3] != msg.content
            or existing[4] != msg.timestamp.isoformat()
            or existing[5] != msg.tokens
            or existing[6] != msg.tool_call_id
            or existing[7] != msg.tool_name
            or json.loads(existing[8] or "{}") != msg.metadata
        )

    def _save_tool_calls_incremental(
        self,
        session_id: str,
        message_id: str,
        tool_calls: list[ToolCall] | None,
    ) -> None:
        """Save tool calls incrementally for a message."""
        existing_rows = self._conn.execute(
            "SELECT id, name, arguments, result FROM tool_calls WHERE message_id=?",
            (message_id,),
        ).fetchall()

        existing_by_id: dict[str, tuple] = {row[0]: row for row in existing_rows}
        current_ids = {tc.id for tc in (tool_calls or [])}

        # Delete tool calls that are no longer present
        to_delete = set(existing_by_id.keys()) - current_ids
        for tc_id in to_delete:
            self._conn.execute("DELETE FROM tool_calls WHERE id=?", (tc_id,))

        if not tool_calls:
            return

        for tc in tool_calls:
            if tc.id in existing_by_id:
                existing = existing_by_id[tc.id]
                if self._tool_call_changed(existing, tc):
                    result_json = self._tool_call_result_to_json(tc.result)
                    self._conn.execute(
                        """UPDATE tool_calls SET name=?, arguments=?, result=?
                           WHERE id=?""",
                        (
                            tc.name,
                            json.dumps(tc.arguments),
                            result_json,
                            tc.id,
                        ),
                    )
            else:
                self._insert_tool_call(session_id, message_id, tc)

    def _tool_call_changed(self, existing: tuple, tc: ToolCall) -> bool:
        """Check if a tool call has changed compared to the existing row."""
        existing_result = self._tool_call_result_to_json(tc.result)
        return (
            existing[1] != tc.name
            or json.loads(existing[2] or "{}") != tc.arguments
            or existing[3] != existing_result
        )

    def _tool_call_result_to_json(self, result: ToolResult | None) -> str | None:
        """Convert a ToolResult to its JSON representation."""
        if result is None:
            return None
        return json.dumps(
            {
                "success": result.success,
                "output": result.output,
                "error": result.error,
                "metadata": result.metadata,
            }
        )

    def _insert_tool_call(self, session_id: str, message_id: str, tc: ToolCall) -> None:
        """Insert a new tool call row."""
        result_json = self._tool_call_result_to_json(tc.result)
        self._conn.execute(
            """INSERT INTO tool_calls
               (id, message_id, session_id, name, arguments, result)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                tc.id,
                message_id,
                session_id,
                tc.name,
                json.dumps(tc.arguments),
                result_json,
            ),
        )

    def delete_session(self, session_id: str) -> None:
        self._conn.execute("DELETE FROM tool_calls WHERE session_id=?", (session_id,))
        self._conn.execute("DELETE FROM messages WHERE session_id=?", (session_id,))
        self._conn.execute("DELETE FROM sessions WHERE id=?", (session_id,))
        self._conn.commit()

    def load_session(self, session_id: str) -> ChatSession | None:
        row = self._conn.execute(
            "SELECT * FROM sessions WHERE id=?", (session_id,)
        ).fetchone()
        if row is None:
            return None
        return self._row_to_session(row)

    def load_all_sessions(self) -> list[ChatSession]:
        rows = self._conn.execute(
            "SELECT * FROM sessions ORDER BY updated_at DESC"
        ).fetchall()
        return [self._row_to_session(row) for row in rows]

    def load_all_session_summaries(self) -> list[SessionSummary]:
        rows = self._conn.execute(
            "SELECT * FROM sessions ORDER BY updated_at DESC"
        ).fetchall()
        summaries: list[SessionSummary] = []
        for row in rows:
            sid = row[0]
            title = row[1]
            backend_name = row[2]
            model = row[3]
            created_at = datetime.fromisoformat(row[4])
            updated_at_str = row[5]
            updated_at = (
                datetime.fromisoformat(updated_at_str) if updated_at_str else created_at
            )
            message_count = row[7]
            preview = self._get_preview(sid)
            summaries.append(
                SessionSummary(
                    id=sid,
                    title=title,
                    backend_name=backend_name,
                    model=model,
                    created_at=created_at,
                    updated_at=updated_at,
                    message_count=message_count,
                    preview=preview,
                )
            )
        return summaries

    def _get_preview(self, session_id: str) -> str:
        row = self._conn.execute(
            """SELECT content FROM messages
               WHERE session_id=? AND content != ''
               ORDER BY sequence_num DESC LIMIT 1""",
            (session_id,),
        ).fetchone()
        if row is None:
            return ""
        content: str = row[0]
        if len(content) > 40:
            return content[:40]
        return content

    def _row_to_session(self, row: tuple[Any, ...]) -> ChatSession:
        sid = row[0]
        title = row[1]
        backend_name = row[2]
        model = row[3]
        created_at = datetime.fromisoformat(row[4])
        updated_at_str = row[5]
        updated_at = datetime.fromisoformat(updated_at_str) if updated_at_str else None
        last_message_at_str = row[6]
        last_message_at = (
            datetime.fromisoformat(last_message_at_str) if last_message_at_str else None
        )
        message_count = row[7]
        total_tokens = row[8]
        input_history: list[str] = json.loads(row[9]) if row[9] else []
        history_index = row[10]
        fork_count = row[11]
        workflow_history: list[dict] = json.loads(row[12]) if row[12] else []
        parameters: dict = json.loads(row[13]) if row[13] else {}

        messages = self._load_messages(sid)

        session = ChatSession(
            id=sid,
            title=title,
            backend_name=backend_name,
            model=model,
            messages=messages,
            created_at=created_at,
            updated_at=updated_at,
            parameters=parameters,
            message_count=message_count,
            total_tokens=total_tokens,
            input_history=input_history,
            history_index=history_index,
            fork_count=fork_count,
            workflow_history=workflow_history,
        )
        session.last_message_at = last_message_at
        return session

    def _load_messages(self, session_id: str) -> list[Message]:
        rows = self._conn.execute(
            "SELECT * FROM messages WHERE session_id=? ORDER BY sequence_num",
            (session_id,),
        ).fetchall()
        messages: list[Message] = []
        for msg_row in rows:
            msg_id = msg_row[0]
            role = msg_row[3]
            content = msg_row[4]
            timestamp = datetime.fromisoformat(msg_row[5])
            tokens = msg_row[6]
            tool_call_id = msg_row[7]
            tool_name = msg_row[8]
            metadata: dict = json.loads(msg_row[9]) if msg_row[9] else {}

            tool_calls = self._load_tool_calls(msg_id)

            messages.append(
                Message(
                    role=role,
                    content=content,
                    timestamp=timestamp,
                    tokens=tokens,
                    metadata=metadata,
                    tool_calls=tool_calls if tool_calls else None,
                    tool_call_id=tool_call_id,
                    tool_name=tool_name,
                )
            )
        return messages

    def search_messages(
        self,
        query: str,
        *,
        role: str | None = None,
        session_id: str | None = None,
        limit: int = 50,
        order_by: str = "timestamp",
    ) -> list[tuple[Message, str]]:
        where_clauses: list[str] = []
        params: list[Any] = [query]

        if role is not None:
            where_clauses.append("AND m.role = ?")
            params.append(role)
        if session_id is not None:
            where_clauses.append("AND m.session_id = ?")
            params.append(session_id)

        params.append(limit)

        order_clause = (
            "ORDER BY fts.rank" if order_by == "rank" else "ORDER BY m.timestamp DESC"
        )

        sql = (
            "SELECT m.id, m.session_id, m.sequence_num, m.role, m.content, "
            "m.timestamp, m.tokens, m.tool_call_id, m.tool_name, m.metadata, "
            "m.session_id "
            "FROM messages_fts fts "
            "JOIN messages m ON m.rowid = fts.rowid "
            "WHERE messages_fts MATCH ? "
            + "".join(where_clauses)
            + f" {order_clause} LIMIT ?"
        )

        rows = self._conn.execute(sql, params).fetchall()
        results: list[tuple[Message, str]] = []
        for row in rows:
            ts = datetime.fromisoformat(row[5]) if row[5] else datetime.now()
            meta: dict = json.loads(row[9]) if row[9] else {}
            msg = Message(
                role=row[3],
                content=row[4],
                timestamp=ts,
                tokens=row[6],
                metadata=meta,
                tool_call_id=row[7],
                tool_name=row[8],
            )
            results.append((msg, row[10]))
        return results

    def _load_tool_calls(self, message_id: str) -> list[ToolCall] | None:
        rows = self._conn.execute(
            "SELECT * FROM tool_calls WHERE message_id=?", (message_id,)
        ).fetchall()
        if not rows:
            return None
        calls: list[ToolCall] = []
        for tc_row in rows:
            tc_id = tc_row[0]
            name = tc_row[3]
            arguments: dict = json.loads(tc_row[4]) if tc_row[4] else {}
            result_data = tc_row[5]
            result: ToolResult | None = None
            if result_data:
                parsed = json.loads(result_data)
                result = ToolResult(
                    success=parsed["success"],
                    output=parsed["output"],
                    error=parsed.get("error"),
                    metadata=parsed.get("metadata", {}),
                )
            calls.append(
                ToolCall(id=tc_id, name=name, arguments=arguments, result=result)
            )
        return calls
