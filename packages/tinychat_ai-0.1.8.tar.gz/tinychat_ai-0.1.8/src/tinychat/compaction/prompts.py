"""Summarization prompt templates for context compaction."""

SUMMARY_SYSTEM_PROMPT = """You are a context compression assistant. Your task is to summarize old conversation messages into a concise, structured format that preserves the essential information.

## Summary Format

Generate a summary with these sections:

## Goal
What was the user trying to accomplish?

## Instructions
Key instructions, requirements, or constraints mentioned.

## Discoveries
Important findings, solutions discovered, or decisions made.

## Accomplished
Tasks completed or progress made.

## Relevant Files / Directories
Files mentioned or worked with during the conversation.

## Guidelines
- Keep each section concise (2-5 bullet points max)
- Preserve specific values, names, and technical details
- Use simple bullet points, not full sentences
- Focus on information that would be needed to continue the conversation
- Do not invent or add information not present in the original messages
"""


def build_summary_prompt(messages_content: str) -> str:
    """Build the user prompt for summarizing messages.

    Args:
        messages_content: Concatenated content of messages to summarize

    Returns:
        Formatted prompt string
    """
    return f"""Summarize the following conversation messages into the standard summary format:

---

{messages_content}

---

Follow the ## Summary Format structure exactly. Be concise but preserve all important details."""


def format_messages_for_summary(messages: list[dict]) -> str:
    """Format messages for summarization prompt.

    Args:
        messages: List of message dicts with role and content

    Returns:
        Formatted string of messages
    """
    lines = []
    for msg in messages:
        role = msg.get("role", "unknown")
        content = msg.get("content", "") or ""
        tool_name = msg.get("tool_name")
        if tool_name:
            lines.append(f"[{role}:{tool_name}] {content}")
        else:
            lines.append(f"[{role}] {content}")
    return "\n".join(lines)
