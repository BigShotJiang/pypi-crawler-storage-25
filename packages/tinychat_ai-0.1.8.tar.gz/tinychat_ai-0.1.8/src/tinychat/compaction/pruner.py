"""Message pruning for context compaction."""

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tinychat.models.message import Message
    from tinychat.models.session import ChatSession

logger = logging.getLogger(__name__)


class MessagePruner:
    """Layer 1: Lightweight pruning of tool results without LLM.

    This pruner removes old tool result messages to free up context space,
    keeping only the most recent N tool results as configured.
    """

    def __init__(self, max_tool_results: int = 5) -> None:
        """Initialize MessagePruner.

        Args:
            max_tool_results: Maximum number of recent tool results to preserve
        """
        self.max_tool_results = max_tool_results

    def prune(self, session: "ChatSession") -> list[int]:
        """Prune old tool results to fit within max_tokens.

        Preserves the most recent N tool result messages, marking older ones
        as compressed.

        Args:
            session: ChatSession with messages to prune

        Returns:
            List of indices of compressed messages
        """
        compressed_indices: list[int] = []
        tool_result_count = 0
        found_later_tool_result = False

        for i in range(len(session.messages) - 1, -1, -1):
            msg = session.messages[i]

            if msg.role == "tool" or (msg.tool_name is not None and msg.content):
                if found_later_tool_result:
                    if not msg.metadata.get("compressed"):
                        msg.metadata["compressed"] = True
                        compressed_indices.append(i)
                        logger.debug(
                            "Pruned tool result at index %d (tool: %s)",
                            i,
                            msg.tool_name,
                        )
                else:
                    tool_result_count += 1
                    if tool_result_count > self.max_tool_results:
                        if not msg.metadata.get("compressed"):
                            msg.metadata["compressed"] = True
                            compressed_indices.append(i)
                            logger.debug(
                                "Pruned excess tool result at index %d (tool: %s)",
                                i,
                                msg.tool_name,
                            )
            else:
                if tool_result_count > 0:
                    found_later_tool_result = True

        return compressed_indices

    def get_active_tool_results(self, session: "ChatSession") -> list["Message"]:
        """Get list of active (non-compressed) tool result messages.

        Args:
            session: ChatSession to check

        Returns:
            List of active tool result messages
        """
        return [
            msg
            for msg in session.messages
            if (msg.role == "tool" or msg.tool_name is not None)
            and not msg.metadata.get("compressed")
        ]
