"""Context compaction module for TinyChat.

This module provides context compaction (summarization) to handle long
conversations that exceed model context windows.

Architecture:
- Layer 1 (Pruning): Remove old tool results without LLM call
- Layer 2 (Summarization): LLM generates structured summary of old messages
"""

from tinychat.compaction.config import CompactionConfig
from tinychat.compaction.manager import (
    CompactionManager,
    get_active_messages,
    load_compaction_config,
)
from tinychat.compaction.pruner import MessagePruner
from tinychat.compaction.summarizer import ConversationSummarizer
from tinychat.compaction.token_counter import (
    estimate_messages_tokens,
    estimate_text_tokens,
    get_model_context_limit,
)

__all__ = [
    "CompactionConfig",
    "CompactionManager",
    "ConversationSummarizer",
    "MessagePruner",
    "estimate_messages_tokens",
    "estimate_text_tokens",
    "get_active_messages",
    "get_model_context_limit",
    "load_compaction_config",
]
