"""Compaction configuration dataclass."""

from dataclasses import dataclass


@dataclass
class CompactionConfig:
    """Configuration for context compaction (summarization).

    Attributes:
        enabled: Master switch for compaction feature (default: True)
        auto: Automatic compaction after each turn (default: True)
        reserved_tokens: Token buffer kept free for model's max_output_tokens
            consideration (default: 20000)
        prune_tool_results: Enable tool result pruning (default: True)
        max_tool_results: Keep this many recent tool results (default: 5)
        preserve_recent_assistant: Keep this many recent assistant messages
            as anchors during summarization (default: 3)
        model: Model for summarization, empty string means use current model
            (default: "")
        debug_no_limit: Debug mode - skip token limit check, always compact
            (default: False)
    """

    enabled: bool = True
    auto: bool = True
    reserved_tokens: int = 20000
    prune_tool_results: bool = True
    max_tool_results: int = 5
    preserve_recent_assistant: int = 3
    model: str = ""
    debug_no_limit: bool = False
