"""LLM-based conversation summarization for context compaction."""

import logging
from datetime import datetime
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from tinychat.backends.base import Backend
    from tinychat.models.message import Message
    from tinychat.models.session import ChatSession

from tinychat.compaction.prompts import (
    SUMMARY_SYSTEM_PROMPT,
    build_summary_prompt,
    format_messages_for_summary,
)

logger = logging.getLogger(__name__)


class ConversationSummarizer:
    """Layer 2: LLM-based summarization of old messages.

    Generates structured summaries of conversation history to compress
    context while preserving essential information.
    """

    def __init__(self, model: str = "", preserve_recent_assistant: int = 3) -> None:
        """Initialize ConversationSummarizer.

        Args:
            model: Model to use for summarization. Empty string means
                use the current conversation model.
            preserve_recent_assistant: Number of recent assistant messages
                to preserve (not summarize) as conversation anchors.
        """
        self.model = model
        self.preserve_recent_assistant = preserve_recent_assistant

    async def summarize(
        self,
        session: "ChatSession",
        backend: "Backend",
        on_progress: Callable[[str], None] | None = None,
    ) -> "Message":
        """Generate a structured summary of old messages.

        Args:
            session: ChatSession containing messages to summarize
            backend: Backend to use for LLM call
            on_progress: Optional callback for progress updates

        Returns:
            A Message with role='system' containing the summary content
        """
        from tinychat.models.message import Message
        from tinychat.models.session import ChatSession

        messages_to_summarize = self._collect_messages_to_summarize(session)
        if not messages_to_summarize:
            logger.debug("No messages to summarize")
            return Message(
                role="system",
                content="[No messages to summarize]",
                metadata={"summary": True},
            )

        formatted = format_messages_for_summary(messages_to_summarize)
        summary_prompt = build_summary_prompt(formatted)

        if on_progress:
            on_progress("Generating summary...")

        summarization_model = self.model or session.model

        system_msg = Message(role="system", content=SUMMARY_SYSTEM_PROMPT)
        user_msg = Message(role="user", content=summary_prompt)

        temp_session = ChatSession(
            id=session.id,
            title=session.title,
            backend_name=session.backend_name,
            model=summarization_model,
            messages=[system_msg, user_msg],
        )

        try:

            def noop_on_token(token: str) -> None:
                pass

            response = await backend.chat(temp_session, noop_on_token)

            summary_content = response.get("content", "[Summary generation failed]")

        except Exception as e:
            logger.error("Failed to generate summary: %s", e)
            summary_content = f"[Summary generation failed: {e}]"

        summary_message = Message(
            role="system",
            content=summary_content,
            timestamp=datetime.now(),
            metadata={
                "summary": True,
                "summarized_count": len(messages_to_summarize),
            },
        )

        return summary_message

    def _collect_messages_to_summarize(self, session: "ChatSession") -> list[dict]:
        """Collect messages that should be summarized.

        Excludes system messages, already compressed messages, summary messages,
        and the most recent N assistant messages (as conversation anchors).

        Args:
            session: ChatSession to collect from

        Returns:
            List of message dicts to summarize
        """
        messages = []
        assistant_indices = []

        # First pass: collect all eligible messages and track assistant indices
        for msg in session.messages:
            if msg.metadata.get("compressed") or msg.metadata.get("summary"):
                continue
            if msg.role == "system":
                continue
            messages.append(
                {
                    "role": msg.role,
                    "content": msg.content,
                    "tool_name": msg.tool_name,
                }
            )
            if msg.role == "assistant":
                assistant_indices.append(len(messages) - 1)

        # Preserve the most recent N assistant messages
        preserve_count = min(self.preserve_recent_assistant, len(assistant_indices))
        if preserve_count > 0:
            preserve_indices = set(assistant_indices[-preserve_count:])
            messages = [
                msg for i, msg in enumerate(messages) if i not in preserve_indices
            ]

        return messages
