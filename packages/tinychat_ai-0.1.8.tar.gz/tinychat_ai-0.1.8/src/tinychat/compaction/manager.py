"""Compaction manager for context compaction."""

import logging
from typing import TYPE_CHECKING

from tinychat.compaction.config import CompactionConfig
from tinychat.compaction.pruner import MessagePruner
from tinychat.compaction.summarizer import ConversationSummarizer
from tinychat.compaction.token_counter import (
    estimate_messages_tokens,
    get_model_context_limit,
)
from tinychat.utils.i18n import _

if TYPE_CHECKING:
    from tinychat.backends.base import Backend
    from tinychat.components.chat_view import ChatView
    from tinychat.components.status_bar import StatusBar
    from tinychat.models.message import Message
    from tinychat.models.session import ChatSession

logger = logging.getLogger(__name__)

COMPACTION_NOTIFICATION = _(
    "Context has been compacted, preserving key conversation points."
)


class CompactionManager:
    """Main controller orchestrating the compaction process.

    Uses a dual-layer compression architecture:
    - Layer 1: Pruning (remove old tool results) - free, instant
    - Layer 2: Summarization (LLM-based) - API call, slower

    Attributes:
        config: Compaction configuration
    """

    def __init__(
        self,
        config: CompactionConfig,
        status_bar: "StatusBar | None" = None,
        chat_view: "ChatView | None" = None,
    ) -> None:
        """Initialize CompactionManager.

        Args:
            config: Compaction configuration
            status_bar: Optional status bar for UI updates
            chat_view: Optional chat view for showing summary rule widget
        """
        self.config = config
        self.status_bar = status_bar
        self.chat_view = chat_view
        self._is_compacting = False
        self._pruner = MessagePruner(max_tool_results=config.max_tool_results)
        self._summarizer = ConversationSummarizer(
            model=config.model,
            preserve_recent_assistant=config.preserve_recent_assistant,
        )

    async def check_and_compact(
        self,
        session: "ChatSession",
        backend: "Backend",
    ) -> bool:
        """Check token usage and compact if needed.

        Args:
            session: ChatSession to check and potentially compact
            backend: Backend for token estimation and summarization

        Returns:
            True if compaction occurred, False otherwise
        """
        if not self.config.enabled or not self.config.auto:
            return False

        if self._is_compacting:
            logger.debug("Compaction already in progress, skipping")
            return False

        self._is_compacting = True
        try:
            active_messages = self.get_active_messages(session)
            context_limit = await get_model_context_limit(backend, session.model)
            if context_limit is None:
                logger.debug(
                    "Unknown context limit for model '%s', skipping compaction",
                    session.model,
                )
                return False

            usable_limit = context_limit - self.config.reserved_tokens
            estimated_tokens = estimate_messages_tokens(active_messages)

            logger.debug(
                "Token check: %d / %d (usable limit)", estimated_tokens, usable_limit
            )

            if estimated_tokens < usable_limit and not self.config.debug_no_limit:
                return False

            return await self._compact(session, backend)
        finally:
            self._is_compacting = False

    async def force_compact(
        self,
        session: "ChatSession",
        backend: "Backend",
    ) -> bool:
        """Force compaction regardless of token usage.

        Use for /compact command.

        Args:
            session: ChatSession to compact
            backend: Backend for summarization

        Returns:
            True if compaction occurred
        """
        logger.debug(f"force_compact called, config.enabled={self.config.enabled}")
        if not self.config.enabled:
            logger.warning("Compaction is disabled in config")
            return False

        if self._is_compacting:
            logger.debug("Compaction already in progress, skipping")
            return False

        self._is_compacting = True
        try:
            result = await self._compact(session, backend)
            logger.debug(f"_compact returned: {result}")
            return result
        finally:
            self._is_compacting = False

    def _set_status_bar_summarizing(self, summarizing: bool) -> None:
        """Update status bar summarizing state.

        Args:
            summarizing: True to show summarizing indicator, False to hide.
        """
        if not self.status_bar:
            return

        self.status_bar.is_summarizing = summarizing

    def _set_status_bar_compaction(self, message: str) -> None:
        """Update status bar compaction status.

        Args:
            message: Status message to display (empty string to clear).
        """
        if not self.status_bar:
            logger.warning(
                f"Cannot set compaction status '{message}': status_bar is None"
            )
            return

        logger.debug(f"_set_status_bar_compaction called with message='{message}'")
        self.status_bar.compaction_status = message
        logger.debug(f"Status bar compaction_status set to: '{message}'")

    def _show_summary_rule(
        self, message_count: int, summary_date: str | None = None
    ) -> None:
        """Show summary rule widget in chat view.

        Args:
            message_count: Number of messages that were summarized.
            summary_date: Date when the summary was created.
        """
        if not self.chat_view:
            return

        self.chat_view.show_summary_rule(
            message_count=message_count, summary_date=summary_date
        )

    async def _compact(
        self,
        session: "ChatSession",
        backend: "Backend",
    ) -> bool:
        """Internal compaction logic.

        Args:
            session: ChatSession to compact
            backend: Backend for summarization

        Returns:
            True if compaction occurred
        """

        from tinychat.models.message import Message

        # Show compaction status in status bar
        logger.debug(
            f"Setting compaction status to 'Compacting...' (status_bar={self.status_bar})"
        )
        self._set_status_bar_compaction(_("Compacting..."))

        try:
            pruned_count = self._pruner.prune(session)
            logger.info("Pruned %d tool results", len(pruned_count))

            active_messages = self.get_active_messages(session)
            context_limit = await get_model_context_limit(backend, session.model)
            if context_limit is not None:
                usable_limit = context_limit - self.config.reserved_tokens
                estimated_tokens = estimate_messages_tokens(active_messages)

                if estimated_tokens < usable_limit:
                    session.messages.append(
                        Message(
                            role="system",
                            content=COMPACTION_NOTIFICATION,
                            metadata={"compaction_notification": True},
                        )
                    )
                    logger.info("Pruning sufficient, no summarization needed")
                    return True

            if self._summarizer:
                # Show summarizing status before starting LLM call
                self._set_status_bar_summarizing(True)

                summary_msg = await self._summarizer.summarize(session, backend)

                # Hide summarizing status after LLM call completes
                self._set_status_bar_summarizing(False)

                session.messages.append(summary_msg)
                summarized_count = summary_msg.metadata.get("summarized_count", 0)
                logger.info(
                    "Added summary message, total messages: %d",
                    len(session.messages),
                )

                # Show summary rule widget in chat view
                summary_date = None
                if summary_msg.timestamp:
                    summary_date = summary_msg.timestamp.strftime("%Y-%m-%d")
                self._show_summary_rule(
                    message_count=summarized_count, summary_date=summary_date
                )

            session.messages.append(
                Message(
                    role="system",
                    content=COMPACTION_NOTIFICATION,
                    metadata={"compaction_notification": True},
                )
            )

            return True

        except Exception as e:
            logger.error("Compaction failed: %s", e)
            # Ensure status indicators are cleared on error
            self._set_status_bar_summarizing(False)
            return False
        finally:
            # Clear compaction status
            logger.debug("Clearing compaction status")
            self._set_status_bar_compaction("")

    def get_active_messages(self, session: "ChatSession") -> list["Message"]:
        """Return only non-compressed messages for LLM consumption.

        Args:
            session: ChatSession to filter

        Returns:
            List of active (non-compressed) messages
        """
        return [msg for msg in session.messages if not msg.metadata.get("compressed")]


def load_compaction_config() -> CompactionConfig:
    """Load compaction configuration from unified TOML config.

    Returns:
        CompactionConfig with values from config file, or defaults
    """
    from tinychat.utils.config_manager import _load_config_once

    COMPACTION_SECTION = "compaction"

    data = _load_config_once()
    compaction_data = data.get(COMPACTION_SECTION, {})

    return CompactionConfig(
        enabled=compaction_data.get("enabled", True),
        auto=compaction_data.get("auto", True),
        reserved_tokens=compaction_data.get("reserved_tokens", 20000),
        prune_tool_results=compaction_data.get("prune_tool_results", True),
        max_tool_results=compaction_data.get("max_tool_results", 5),
        preserve_recent_assistant=compaction_data.get("preserve_recent_assistant", 3),
        model=compaction_data.get("model", ""),
    )


def get_active_messages(session: "ChatSession") -> list["Message"]:
    """Return only non-compressed messages for LLM consumption.

    Standalone function alias for CompactionManager.get_active_messages().

    Args:
        session: ChatSession to filter

    Returns:
        List of active (non-compressed) messages
    """
    return [msg for msg in session.messages if not msg.metadata.get("compressed")]
