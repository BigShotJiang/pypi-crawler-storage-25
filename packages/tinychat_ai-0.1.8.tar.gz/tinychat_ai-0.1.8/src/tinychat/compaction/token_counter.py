"""Token estimation utilities for context compaction."""

import logging
import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tinychat.backends.base import Backend
    from tinychat.models.message import Message

logger = logging.getLogger(__name__)

CHINESE_CHARS_PER_TOKEN = 2
ENGLISH_CHARS_PER_TOKEN = 4
PER_MESSAGE_OVERHEAD = 10

KNOWN_OPENAI_LIMITS: dict[str, int] = {
    "gpt-4": 128000,
    "gpt-4-turbo": 8192,
    "gpt-4-32k": 32768,
    "gpt-4-1106-preview": 128000,
    "gpt-4-0125-preview": 128000,
    "gpt-4-0613": 8192,
    "gpt-4-32k-0613": 32768,
    "gpt-3.5-turbo": 16385,
    "gpt-3.5-turbo-0613": 16385,
    "gpt-3.5-turbo-1106": 16385,
    "gpt-3.5-turbo-0125": 16385,
    "deepseek-v4-flash": 64000,
    "deepseek-v4-pro": 64000,
    "deepseek-reasoner": 64000,
    "deepseek-chat": 64000,
    "deepseek-v3": 64000,
}


def estimate_text_tokens(text: str) -> int:
    """Estimate token count for a single text.

    Uses a hybrid language heuristic:
    - Chinese characters (ord(c) > 127): 2 chars ≈ 1 token
    - English/alphanumeric: 4 chars ≈ 1 token

    Args:
        text: The text to estimate tokens for.

    Returns:
        Estimated token count.
    """
    if not text:
        return 0

    chinese_chars = 0
    english_chars = 0

    for char in text:
        if ord(char) > 127:
            chinese_chars += 1
        else:
            english_chars += 1

    chinese_tokens = chinese_chars / CHINESE_CHARS_PER_TOKEN
    english_tokens = english_chars / ENGLISH_CHARS_PER_TOKEN

    return int(chinese_tokens + english_tokens)


def estimate_messages_tokens(messages: list["Message"]) -> int:
    """Estimate total tokens for a list of messages.

    Includes +10 tokens per message overhead for role and structure.
    Also includes tool_calls and tool_call_id overhead if present.

    Args:
        messages: List of messages to estimate tokens for.

    Returns:
        Total estimated token count.
    """
    total = 0
    for msg in messages:
        total += estimate_text_tokens(msg.content)
        total += PER_MESSAGE_OVERHEAD

        # Tool call overhead estimation
        if msg.tool_calls:
            for tc in msg.tool_calls:
                # Estimate tool call name tokens
                total += estimate_text_tokens(tc.name)
                # Estimate tool call arguments tokens
                total += estimate_text_tokens(str(tc.arguments))
                # Structure overhead for tool call
                total += 4

        # Tool result overhead estimation
        if msg.tool_call_id:
            # Approximate token count for tool_call_id
            total += len(msg.tool_call_id) // 4

    return total


def _extract_openai_model_base(model: str) -> str:
    """Extract base model name from full model string.

    Args:
        model: Full model name (e.g., "gpt-4-turbo-2024-01-01").

    Returns:
        Base model name (e.g., "gpt-4-turbo").
    """
    if model.startswith("gpt-4-turbo"):
        return "gpt-4-turbo"

    patterns = [
        r"^gpt-4-32k",
        r"^gpt-4",
        r"^gpt-3\.5-turbo",
    ]

    for pattern in patterns:
        match = re.match(pattern, model)
        if match:
            return match.group(0)

    return model


def _parse_openai_model_limit(model: str) -> int | None:
    """Parse known context limit for OpenAI-compatible models.

    Args:
        model: Model name to parse.

    Returns:
        Known context limit or None if unknown.
    """
    base = _extract_openai_model_base(model)
    return KNOWN_OPENAI_LIMITS.get(base)


async def get_model_context_limit(backend: "Backend", model: str) -> int | None:
    """Get model's context limit from Ollama API or known limits.

    For Ollama backends, queries the /api/show endpoint for model's context_length.
    For OpenAI-compatible backends, parses model name for known limits.

    Args:
        backend: The backend instance.
        model: The model name to get context limit for.

    Returns:
        Context limit in tokens, or None if unable to determine.
    """
    # Dynamically check backend type to avoid circular imports
    backend_type = type(backend).__name__

    if backend_type == "OllamaBackend":
        return await _get_ollama_context_limit(backend, model)

    if backend_type == "OpenAIBackend":
        return _parse_openai_model_limit(model)

    logger.warning(f"Unknown backend type '{backend_type}' for context limit lookup")
    return None


async def _get_ollama_context_limit(backend: "Backend", model: str) -> int | None:
    """Query Ollama API for model's context_length.

    Args:
        backend: Ollama backend instance.
        model: Model name.

    Returns:
        Context limit from Ollama API, or None if unavailable.
    """
    try:
        # Use getattr to safely access client attribute
        client = getattr(backend, "client", None)
        if not client:
            logger.warning("OllamaBackend has no client attribute")
            return None

        response = await client.post(
            "/api/show",
            json={"name": model},
        )
        response.raise_for_status()
        data = response.json()

        context_length = data.get("context_length")
        if context_length is not None:
            return int(context_length)

        logger.warning("Ollama API response missing 'context_length' field")
        return None

    except Exception as e:
        logger.warning(f"Failed to get context limit from Ollama: {e}")
        return None
