"""Reconstruct WorkflowState from persisted messages for session restore."""

from __future__ import annotations


from tinychat.models.message import Message
from tinychat.models.workflow import (
    WorkflowItem,
    WorkflowState,
    WorkflowStatus,
)


def _is_error_tool_message(msg: Message) -> bool:
    if msg.metadata and msg.metadata.get("error"):
        return True
    content = msg.content or ""
    if content.startswith("Error:"):
        return True
    if content.startswith("Tool call denied"):
        return True
    return False


def _message_to_workflow_item(msg: Message) -> WorkflowItem:
    is_error = _is_error_tool_message(msg)
    arguments = (msg.metadata or {}).get("arguments", {})
    if not isinstance(arguments, dict):
        arguments = {}

    error = None
    result_summary = None
    if is_error:
        error = (msg.metadata or {}).get("error") or msg.content
    else:
        result_summary = msg.content[:100] if msg.content else None

    # Try to get tool icon from tool name (best effort)
    tool_icon = "🛠️"  # default
    tool_name = msg.tool_name or "unknown"
    # Simple icon mapping based on tool name
    if any(kw in tool_name.lower() for kw in ["file", "read", "write", "edit"]):
        tool_icon = "📄"
    elif any(kw in tool_name.lower() for kw in ["directory", "list"]):
        tool_icon = "📁"
    elif any(kw in tool_name.lower() for kw in ["shell", "exec", "run", "command"]):
        tool_icon = "💻"
    elif any(kw in tool_name.lower() for kw in ["search", "find", "grep", "glob"]):
        tool_icon = "🔍"
    elif any(kw in tool_name.lower() for kw in ["todo", "task", "workflow"]):
        tool_icon = "✅"

    return WorkflowItem(
        call_id=msg.tool_call_id or "",
        tool_name=tool_name,
        arguments=arguments,
        status=WorkflowStatus.FAILED if is_error else WorkflowStatus.COMPLETED,
        result_summary=result_summary,
        error=error,
        widget_collapsed=True,
        tool_icon=tool_icon,
    )


def reconstruct_workflow_batches(
    messages: list[Message],
) -> list[WorkflowState]:
    batches: list[WorkflowState] = []
    i = 0
    while i < len(messages):
        msg = messages[i]
        if msg.role == "assistant" and msg.tool_calls:
            i += 1
            tool_messages: list[Message] = []
            while i < len(messages) and messages[i].role == "tool":
                tool_messages.append(messages[i])
                i += 1
            if tool_messages:
                state = WorkflowState(session_id="")
                for tm in tool_messages:
                    state.add_item(_message_to_workflow_item(tm))
                batches.append(state)
        else:
            i += 1
    return batches
