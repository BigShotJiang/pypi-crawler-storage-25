"""Shared HTTP client manager for connection pool reuse."""

import httpx


class HttpClientManager:
    """Manages a shared httpx AsyncHTTPTransport for connection pool reuse.

    All clients created by this manager share the same underlying connection
    pool (transport), avoiding redundant TCP/SSL handshakes across backends
    and subagents.
    """

    DEFAULT_LIMITS = httpx.Limits(
        max_connections=50,
        max_keepalive_connections=20,
        keepalive_expiry=120,
    )

    def __init__(
        self,
        limits: httpx.Limits | None = None,
        retries: int = 1,
    ) -> None:
        self._transport = httpx.AsyncHTTPTransport(
            limits=limits or self.DEFAULT_LIMITS,
            retries=retries,
        )
        self._clients: list[httpx.AsyncClient] = []

    def create_client(
        self,
        base_url: str,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> httpx.AsyncClient:
        client = httpx.AsyncClient(
            base_url=base_url,
            timeout=httpx.Timeout(timeout),
            trust_env=False,
            transport=self._transport,
            headers=headers,
        )
        self._clients.append(client)
        return client

    async def aclose(self) -> None:
        await self._transport.aclose()
        self._clients.clear()
