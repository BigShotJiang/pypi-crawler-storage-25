"""Clipboard utilities with fallback support."""

import base64
import logging
import sys

logger = logging.getLogger(__name__)

_clipboard_backend: str | None = None


def _try_pyperclip(text: str) -> bool:
    """Try to copy using pyperclip.

    Returns True if successful, False otherwise.
    """
    global _clipboard_backend
    try:
        import pyperclip  # noqa: PLC0415

        pyperclip.copy(text)
        _clipboard_backend = "pyperclip"
        return True
    except Exception as e:  # noqa: BLE001
        logger.debug("pyperclip failed: %s", e)
        return False


def _try_osc52(text: str) -> bool:
    """Try to copy using OSC 52 escape sequence.

    Returns True if successful, False otherwise.
    """
    global _clipboard_backend
    try:
        base64_text = base64.b64encode(text.encode("utf-8")).decode("utf-8")
        osc52_sequence = f"\x1b]52;c;{base64_text}\a"
        sys.stdout.write(osc52_sequence)
        sys.stdout.flush()
        _clipboard_backend = "osc52"
        return True
    except Exception as e:  # noqa: BLE001
        logger.debug("OSC 52 failed: %s", e)
        return False


def copy_to_clipboard(text: str) -> bool:
    """Copy text to clipboard with fallback support.

    Tries pyperclip first, then falls back to OSC 52.

    Args:
        text: Text to copy to clipboard.

    Returns:
        True if copy was successful, False otherwise.
    """
    if _try_pyperclip(text):
        logger.debug("Copied using pyperclip")
        return True

    if _try_osc52(text):
        logger.debug("Copied using OSC 52")
        return True

    logger.warning("All clipboard methods failed")
    return False


def get_clipboard_backend() -> str | None:
    """Return the name of the clipboard backend last used."""
    return _clipboard_backend
