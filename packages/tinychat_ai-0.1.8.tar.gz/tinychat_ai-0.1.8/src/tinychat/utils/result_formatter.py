"""Formats tool execution results for display."""

from __future__ import annotations

from typing import Any

from tinychat.tools.base import ToolResult


class ResultFormatter:
    """Formats tool execution results for display."""

    def __init__(
        self, max_preview_lines: int = 10, max_preview_chars: int = 500
    ) -> None:
        self.max_preview_lines = max_preview_lines
        self.max_preview_chars = max_preview_chars

    def format_result(self, result: ToolResult) -> dict[str, Any]:
        """Format a ToolResult for display.

        Returns:
            {
                "summary": str,
                "preview": str,
                "is_truncated": bool,
                "total_lines": int,
                "stats": dict,
            }
        """
        stats = self._extract_stats(result)
        preview, is_truncated, total_lines = self._truncate_output(result.output)
        summary = self._build_summary(result, stats, total_lines)

        return {
            "summary": summary,
            "preview": preview,
            "is_truncated": is_truncated,
            "total_lines": total_lines,
            "stats": stats,
        }

    def _extract_stats(self, result: ToolResult) -> dict[str, Any]:
        """Extract statistics from result metadata."""
        known_keys = [
            "total_lines",
            "lines_returned",
            "match_count",
            "entry_count",
            "file_count",
            "bytes_written",
        ]
        stats: dict[str, Any] = {}
        for key in known_keys:
            if key in result.metadata:
                stats[key] = result.metadata[key]
        return stats

    def _truncate_output(self, output: str) -> tuple[str, bool, int]:
        """Truncate output to preview size.

        Returns (truncated, was_truncated, total_lines).
        """
        if not output:
            return "", False, 0

        lines = output.split("\n")
        total_lines = len(lines)
        was_truncated = False

        if total_lines > self.max_preview_lines:
            truncated_lines = lines[: self.max_preview_lines]
            remaining = total_lines - self.max_preview_lines
            truncated = "\n".join(truncated_lines)
            truncated += f"\n... {remaining} more lines"
            was_truncated = True
        else:
            truncated = output

        if len(truncated) > self.max_preview_chars:
            truncated = truncated[: self.max_preview_chars]
            was_truncated = True

        return truncated, was_truncated, total_lines

    def _build_summary(
        self,
        result: ToolResult,
        stats: dict[str, Any],
        total_lines: int,
    ) -> str:
        """Build a brief summary string."""
        if not result.success:
            return "Error"

        parts: list[str] = []

        if "match_count" in stats and "file_count" in stats:
            parts.append(
                f"{stats['match_count']} matches in {stats['file_count']} files"
            )
        elif "match_count" in stats:
            parts.append(f"{stats['match_count']} matches")
        elif "file_count" in stats:
            parts.append(f"{stats['file_count']} files")

        if "lines_returned" in stats and "total_lines" in stats:
            lines_returned = stats["lines_returned"]
            total = stats["total_lines"]
            parts.append(f"lines {lines_returned}-{total - 1}")
        elif "lines_returned" in stats:
            parts.append(f"{stats['lines_returned']} lines")
        elif "entry_count" in stats:
            parts.append(f"{stats['entry_count']} entries")
        elif "bytes_written" in stats:
            parts.append(f"{stats['bytes_written']} bytes written")
        elif total_lines > 0:
            parts.append(f"{total_lines} line{'s' if total_lines != 1 else ''}")

        return " | ".join(parts) if parts else "0 lines"
