"""Session persistence manager for saving/loading chat sessions."""

import json
import logging
import shutil
import time
import uuid
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

from tinychat.models.message import Message, ToolCall
from tinychat.models.session import ChatSession
from tinychat.tools.base import ToolResult

logger = logging.getLogger(__name__)


class SessionPersistence:
    """Manages persistent storage of chat sessions as JSON files."""

    def __init__(self, storage_dir: Path = Path.home() / ".tinychat" / "sessions"):
        """Initialize persistence manager.

        Args:
            storage_dir: Directory to store session files
        """
        self.storage_dir = storage_dir
        self.storage_dir.mkdir(parents=True, exist_ok=True)

    def save_session(self, session: ChatSession) -> None:
        """Save session to JSON file.

        Args:
            session: ChatSession to save
        """
        file_path = self.storage_dir / f"{session.id}.json"
        with open(file_path, "w") as f:
            json.dump(asdict(session), f, default=self._serialize_datetime)

    @staticmethod
    def _serialize_datetime(obj):
        """Serialize datetime to ISO format string."""
        if isinstance(obj, datetime):
            return obj.isoformat()
        msg = f"Object of type {type(obj)} is not JSON serializable"
        raise TypeError(msg)

    def load_all_sessions(self) -> list[ChatSession]:
        """Load all sessions from storage.

        Returns:
            List of ChatSession objects (skips corrupted files with backup)
        """
        start_time = time.perf_counter()
        sessions = []
        total_files = 0
        total_file_time = 0.0
        slow_files: list[tuple[str, float]] = []

        file_paths = list(self.storage_dir.glob("*.json"))
        logger.debug(
            "[PERF] Starting load_all_sessions, found %d files", len(file_paths)
        )

        for file_path in file_paths:
            file_start = time.perf_counter()
            total_files += 1
            try:
                with open(file_path) as f:
                    data = json.load(f)
                    data = self._deserialize_session_data(data)
                    sessions.append(ChatSession(**data))
            except (json.JSONDecodeError, KeyError, TypeError) as e:
                # Backup corrupted file before skipping
                self._backup_corrupted_file(file_path, str(e))
            finally:
                file_time = time.perf_counter() - file_start
                total_file_time += file_time
                if file_time > 0.05:  # Log files taking > 50ms
                    slow_files.append((file_path.name, file_time))

        total_time = time.perf_counter() - start_time
        avg_time = total_file_time / total_files if total_files > 0 else 0

        logger.debug(
            "[PERF] load_all_sessions completed: %d files in %.2fms (avg: %.2fms/file)",
            total_files,
            total_time * 1000,
            avg_time * 1000,
        )
        if slow_files:
            for name, t in sorted(slow_files, key=lambda x: x[1], reverse=True)[:5]:
                logger.debug("[PERF] Slow file: %s took %.2fms", name, t * 1000)

        return sessions

    def _backup_corrupted_file(self, file_path: Path, error: str) -> None:
        """Backup a corrupted session file with timestamp suffix.

        Args:
            file_path: Path to the corrupted file
            error: Error message for logging
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = file_path.with_suffix(f".json.corrupted_{timestamp}")
        try:
            shutil.copy(file_path, backup_path)
            logger.error(
                "Session file corrupted, backed up to %s: %s", backup_path, error
            )
        except Exception:
            logger.exception("Failed to backup corrupted file %s", file_path)

    @staticmethod
    def _deserialize_session_data(data: dict) -> dict:
        """Deserialize session data from dict.

        Converts message dicts to Message objects and datetime strings to
        datetime objects. Provides backward compatibility for missing
        updated_at field.

        Args:
            data: Raw session data dict

        Returns:
            Deserialized session data
        """
        if "messages" in data:
            data["messages"] = [
                SessionPersistence._deserialize_message(msg)
                if isinstance(msg, dict)
                else msg
                for msg in data["messages"]
            ]

        if "created_at" in data and isinstance(data["created_at"], str):
            data["created_at"] = datetime.fromisoformat(data["created_at"])

        # Handle updated_at with backward compatibility
        if "updated_at" in data and isinstance(data["updated_at"], str):
            data["updated_at"] = datetime.fromisoformat(data["updated_at"])
        elif "updated_at" not in data:
            # Backward compatibility: use created_at if available, else now
            if "created_at" in data:
                data["updated_at"] = data["created_at"]
            else:
                data["updated_at"] = datetime.now()

        # Ensure created_at has a value
        if "created_at" not in data:
            data["created_at"] = datetime.now()

        if "timestamp" in data and isinstance(data["timestamp"], str):
            data["timestamp"] = datetime.fromisoformat(data["timestamp"])

        # Handle last_message_at with backward compatibility
        if "last_message_at" in data and isinstance(data["last_message_at"], str):
            data["last_message_at"] = datetime.fromisoformat(data["last_message_at"])

        return data

    @staticmethod
    def _deserialize_message(msg_data: dict) -> Message:
        """Deserialize a message dict, including tool_calls.

        Args:
            msg_data: Raw message data dict

        Returns:
            Deserialized Message object
        """
        if "timestamp" in msg_data and isinstance(msg_data["timestamp"], str):
            msg_data["timestamp"] = datetime.fromisoformat(msg_data["timestamp"])

        if "tool_calls" in msg_data and msg_data["tool_calls"] is not None:
            msg_data["tool_calls"] = [
                SessionPersistence._deserialize_tool_call(tc)
                if isinstance(tc, dict)
                else tc
                for tc in msg_data["tool_calls"]
            ]

        return Message(**msg_data)

    @staticmethod
    def _deserialize_tool_call(tc_data: dict) -> ToolCall:
        """Deserialize a tool call dict.

        Args:
            tc_data: Raw tool call data dict

        Returns:
            Deserialized ToolCall object
        """
        # Handle result deserialization if present
        result = tc_data.get("result")
        if isinstance(result, dict):
            tc_data["result"] = ToolResult(**result)

        return ToolCall(**tc_data)

    def delete_session(self, session_id: str) -> None:
        """Delete session file.

        Args:
            session_id: ID of session to delete
        """
        file_path = self.storage_dir / f"{session_id}.json"
        if file_path.exists():
            file_path.unlink()

    def export_session(
        self,
        session: ChatSession,
        format: str = "markdown",
        output_path: Path | None = None,
    ) -> Path:
        """Export session to file.

        Args:
            session: Session to export
            format: Export format ("markdown" or "json")
            output_path: Optional output path (defaults to storage_dir)

        Returns:
            Path to exported file
        """
        if output_path is None:
            output_path = self.storage_dir / f"{session.id}.{format}"

        # Ensure parent directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if format == "json":
            with open(output_path, "w") as f:
                json.dump(asdict(session), f, default=self._serialize_datetime)
        elif format == "markdown":
            lines = [
                f"# {session.title}",
                "",
                f"> Backend: {session.backend_name} | Model: {session.model}",
                f"> Created: {session.created_at.isoformat()}",
                "",
            ]
            for msg in session.messages:
                role = "User" if msg.role == "user" else "Assistant"
                lines.extend(
                    [
                        f"## {role}",
                        "",
                        msg.content,
                        "",
                    ],
                )
            with open(output_path, "w") as f:
                f.write("\n".join(lines))
        else:
            msg = f"Unsupported export format: {format}"
            raise ValueError(msg)

        return output_path

    def import_session(self, file_path: Path) -> ChatSession:
        """Import session from file.

        Args:
            file_path: Path to import file

        Returns:
            Imported ChatSession with new ID to avoid conflicts

        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If format is not supported
        """
        if not file_path.exists():
            msg = f"Import file not found: {file_path}"
            raise FileNotFoundError(msg)

        if file_path.suffix == ".json":
            with open(file_path) as f:
                data = json.load(f)
                data = self._deserialize_session_data(data)
                session = ChatSession(**data)
                # Generate new ID to avoid conflicts
                session.id = str(uuid.uuid4())
                return session
        else:
            msg = f"Unsupported import format: {file_path.suffix}"
            raise ValueError(msg)
