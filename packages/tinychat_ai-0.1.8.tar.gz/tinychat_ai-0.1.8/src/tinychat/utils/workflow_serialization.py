"""Serialization utilities for workflow state persistence."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from tinychat.models.workflow import WorkflowState


def _serialize_value(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, Enum):
        return value.value
    return value


def _serialize_attempt_history(records: list[dict]) -> list[dict[str, Any]]:
    serialized = []
    for record in records:
        serialized_record = {}
        for key, value in record.items():
            serialized_record[key] = _serialize_value(value)
        serialized.append(serialized_record)
    return serialized


def serialize_workflow_state(state: WorkflowState) -> list[dict[str, Any]]:
    batches: list[dict[str, Any]] = []
    if state.executions:
        for execution_id, ctx in state.executions.items():
            items: list[dict[str, Any]] = []
            for item in ctx.items:
                items.append(_serialize_item(item))
            batches.append({"execution_id": execution_id, "items": items})
    elif state.items:
        items: list[dict[str, Any]] = []
        for item in state.items:
            items.append(_serialize_item(item))
        if items:
            batches.append({"execution_id": "default", "items": items})
    return batches


def _serialize_item(item: Any) -> dict[str, Any]:

    return {
        "call_id": item.call_id,
        "tool_name": item.tool_name,
        "arguments": item.arguments,
        "status": item.status.value,
        "result_summary": item.result_summary,
        "error": item.error,
        "started_at": item.started_at.isoformat() if item.started_at else None,
        "completed_at": item.completed_at.isoformat() if item.completed_at else None,
        "attempt": item.attempt,
        "attempt_history": _serialize_attempt_history(item.attempt_history),
        "result_metadata": item.result_metadata,
        "tool_icon": item.tool_icon,
    }
