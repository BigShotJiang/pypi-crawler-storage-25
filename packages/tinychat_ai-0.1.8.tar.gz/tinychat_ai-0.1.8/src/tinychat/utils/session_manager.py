"""Session manager for managing chat sessions."""

import asyncio
import copy
import json
import logging
import re
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Protocol

from tinychat.models.session import ChatSession, SessionSummary
from tinychat.utils.i18n import _

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

_CJK_RANGES = (
    (0x4E00, 0x9FFF),
    (0x3400, 0x4DBF),
    (0x20000, 0x2A6DF),
    (0xF900, 0xFAFF),
    (0x2F800, 0x2FA1F),
)


def _is_cjk_char(ch: str) -> bool:
    """Check if a character is a CJK character."""
    cp = ord(ch)
    return any(lo <= cp <= hi for lo, hi in _CJK_RANGES)


def _strip_markdown(text: str) -> str:
    """Strip common markdown syntax from text.

    Args:
        text: Text that may contain markdown.

    Returns:
        Text with markdown syntax removed.
    """
    # Remove code blocks
    text = re.sub(r"```[\s\S]*?```", "", text)
    # Remove inline code
    text = re.sub(r"`([^`]+)`", r"\1", text)
    # Remove bold/italic markers
    text = re.sub(r"\*\*?([^*]+)\*\*?", r"\1", text)
    text = re.sub(r"__?([^_]+)__?", r"\1", text)
    # Remove link syntax but keep text
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    # Remove image syntax
    text = re.sub(r"!\[([^\]]*)\]\([^)]+\)", "", text)
    # Remove heading markers
    text = re.sub(r"^#+\s*", "", text)

    return text.strip()


def _truncate_preview(text: str, max_len: int) -> str:
    """Truncate text to max_len, respecting CJK characters.

    Args:
        text: Text to truncate.
        max_len: Maximum length before truncation.

    Returns:
        Truncated text with "..." appended if truncated.
    """
    if len(text) <= max_len:
        return text

    truncated = text[:max_len]

    # Check if last character is CJK
    last_char = truncated[-1]
    if _is_cjk_char(last_char):
        # Check if we're breaking a CJK character sequence
        next_char = text[max_len] if max_len < len(text) else ""
        if _is_cjk_char(next_char):
            # Try to find a good break point before the last CJK char
            for i in range(len(truncated) - 1, -1, -1):
                if not _is_cjk_char(truncated[i]):
                    truncated = truncated[: i + 1]
                    break
            else:
                # All CJK, just truncate
                truncated = truncated[:-1]

    return truncated.rstrip() + "..."


def _generate_session_preview(session: ChatSession, max_len: int = 40) -> str:
    """Generate a preview text from a ChatSession's messages.

    Args:
        session: The chat session to generate preview from.
        max_len: Maximum length of the preview (default 40).

    Returns:
        A string preview of the last message, truncated if necessary.
        Returns empty string if no messages or all messages are empty.
    """
    if not session.messages:
        return ""

    # Look for the last message with non-empty content
    for msg in reversed(session.messages):
        content = msg.content or ""
        content = content.strip()

        if not content:
            continue

        # Handle tool messages
        if msg.role == "tool":
            tool_name = msg.tool_name or "tool"
            content = f"Tool: {tool_name}"

        # Replace newlines with spaces
        content = content.replace("\n", " ").replace("\r", " ")

        # Strip markdown syntax
        content = _strip_markdown(content)

        # Strip again after markdown removal
        content = content.strip()

        if not content:
            continue

        # Truncate if necessary
        if len(content) > max_len:
            content = _truncate_preview(content, max_len)

        return content

    return ""


class SessionPersistence(Protocol):
    """Protocol for session persistence."""

    def save_session(self, session: ChatSession) -> None:
        """Save session to storage."""
        ...

    def delete_session(self, session_id: str) -> None:
        """Delete session from storage."""
        ...

    def load_session(self, session_id: str) -> ChatSession | None:
        """Load a single session from storage by ID."""
        ...

    def load_all_sessions(self) -> list[ChatSession]:
        """Load all sessions from storage."""
        ...

    def load_all_session_summaries(self) -> list[SessionSummary]:
        """Load lightweight summaries of all sessions."""
        ...


class SessionManager:
    """Manages multiple chat sessions."""

    def __init__(self, persistence: SessionPersistence):
        self.sessions: dict[str, ChatSession] = {}
        self.active_session_id: str | None = None
        self.persistence = persistence
        self._session_counter = 0
        # Async safety lock for session operations
        self._lock = asyncio.Lock()
        self._save_tasks: dict[str, asyncio.Task] = {}
        self._save_delay: float = 2.0

    @property
    def session_counter(self) -> int:
        return self._session_counter

    @session_counter.setter
    def session_counter(self, value: int) -> None:
        self._session_counter = value

    def add_existing_session(self, session: ChatSession) -> None:
        """Add an existing session (e.g., loaded from persistence).

        Updates the session counter if the session title matches the default pattern.
        """
        self.sessions[session.id] = session

        # Update session counter if title matches default pattern
        if session.title.startswith("Chat "):
            try:
                # Extract number from "Chat {number}"
                session_num = int(session.title.split()[1])
                if session_num > self._session_counter:
                    self._session_counter = session_num
            except (IndexError, ValueError):
                # Not a default title, ignore
                pass

    async def create_session(self, backend_name: str, model: str) -> ChatSession:
        """Create new session with auto-generated ID and title."""
        async with self._lock:
            self._session_counter += 1
            session = ChatSession(
                id=str(uuid.uuid4()),
                title=f"Chat {self._session_counter}",
                backend_name=backend_name,
                model=model,
            )
            self.sessions[session.id] = session
            return session

    async def fork_session(
        self, source_session_id: str, up_to_index: int
    ) -> ChatSession:
        """Create a forked session from a source session up to a specific message index.

        The forked session is an independent copy with no parent-child relationship.
        All messages up to and including the specified index are deep-copied.

        Args:
            source_session_id: ID of the session to fork from.
            up_to_index: Message index to copy up to (inclusive).

        Returns:
            New ChatSession with copied messages.

        Raises:
            ValueError: If source session not found.
        """
        async with self._lock:
            source = self.sessions.get(source_session_id)
            if not source:
                raise ValueError(f"Session {source_session_id} not found")

            source.fork_count += 1
            prefix = _("[Fork{n}]").replace("{n}", str(source.fork_count))

            if prefix.endswith("】"):
                title = f"{prefix}{source.title}"
            else:
                title = f"{prefix} {source.title}"

            new_session = ChatSession(
                id=str(uuid.uuid4()),
                title=title,
                backend_name=source.backend_name,
                model=source.model,
            )
            self.sessions[new_session.id] = new_session

            # Deep copy messages up to and including the index
            if up_to_index < len(source.messages):
                new_session.messages = [
                    copy.deepcopy(msg) for msg in source.messages[: up_to_index + 1]
                ]
            else:
                # If index out of range, copy all messages
                new_session.messages = [copy.deepcopy(msg) for msg in source.messages]

            new_session.update_metadata()
            self.schedule_save(new_session.id)
            self.schedule_save(source_session_id)
            return new_session

    async def switch_session(self, session_id: str) -> None:
        """Switch to specified session."""
        async with self._lock:
            if session_id in self.sessions:
                self.active_session_id = session_id

    async def close_session(self, session_id: str) -> bool:
        """Close session and remove from memory and storage.

        Args:
            session_id: ID of session to close.

        Returns:
            True if session was closed.
            False if session not found (already missing).
        """
        async with self._lock:
            # Check if session exists
            if session_id not in self.sessions:
                # Session not in memory - try to clean up from persistence
                self.persistence.delete_session(session_id)
                return False

            # Remove from memory
            del self.sessions[session_id]

            # If this was the active session, clear active_session_id
            if self.active_session_id == session_id:
                self.active_session_id = None

            # Remove from persistent storage
            self.persistence.delete_session(session_id)

            # Cancel any pending save task
            if session_id in self._save_tasks:
                self._save_tasks[session_id].cancel()

            return True

    def unload_session(self, session_id: str) -> bool:
        """Unload a session from memory (keep persistence).

        This releases the session from memory but keeps the file on disk.
        Used to ensure only one session is in memory at a time.

        Args:
            session_id: ID of session to unload.

        Returns:
            True if session was unloaded.
            False if session not found or is the active session.
        """
        # Cannot unload the active session
        if self.active_session_id == session_id:
            return False

        if session_id in self.sessions:
            del self.sessions[session_id]
            # Cancel any pending save tasks for this session
            if session_id in self._save_tasks:
                self._save_tasks[session_id].cancel()
                # Note: task will be cleaned up when it finishes
            return True
        return False

    def load_session_from_storage(self, session_id: str) -> ChatSession | None:
        """Load a single session from persistent storage into memory.

        Args:
            session_id: ID of session to load.

        Returns:
            ChatSession if loaded successfully, None otherwise.
        """
        start_time = time.perf_counter()
        try:
            if hasattr(self.persistence, "load_session"):
                session = self.persistence.load_session(session_id)
                if session is None:
                    return None
                self.sessions[session.id] = session
                total_time = time.perf_counter() - start_time
                msg_count = len(session.messages)
                logger.debug(
                    "[PERF] load_session_from_storage: %s - %.2fms (msgs: %d)",
                    session_id[:8],
                    total_time * 1000,
                    msg_count,
                )
                return session

            storage_dir = getattr(self.persistence, "storage_dir", None)
            if not isinstance(storage_dir, Path):
                return None
            file_path = storage_dir / f"{session_id}.json"
            if not file_path.exists():
                return None

            io_start = time.perf_counter()
            with open(file_path) as f:
                file_content = f.read()
            io_time = time.perf_counter() - io_start

            parse_start = time.perf_counter()
            data = json.loads(file_content)
            data = self._deserialize_session_data(data)
            session = ChatSession(**data)
            self.sessions[session.id] = session
            parse_time = time.perf_counter() - parse_start

            total_time = time.perf_counter() - start_time
            file_size = len(file_content)
            msg_count = len(session.messages)

            logger.debug(
                "[PERF] load_session_from_storage: %s - %.2fms (io: %.2fms, parse: %.2fms, size: %d bytes, msgs: %d)",
                session_id[:8],
                total_time * 1000,
                io_time * 1000,
                parse_time * 1000,
                file_size,
                msg_count,
            )
            return session
        except (json.JSONDecodeError, KeyError, TypeError):
            logger.exception("Failed to load session %s", session_id)
            return None

    async def get_all_session_summaries_async(
        self, max_concurrent: int = 10
    ) -> list[SessionSummary]:
        """Get lightweight summaries of all sessions from storage asynchronously.

        This reads only metadata from session files, not full message history,
        to keep memory usage minimal. Uses parallel file I/O for better performance.

        Args:
            max_concurrent: Maximum number of concurrent file operations.

        Returns:
            List of SessionSummary objects sorted by updated_at descending.
        """
        import asyncio

        start_time = time.perf_counter()
        summaries: list[SessionSummary] = []
        total_files = 0
        slow_files: list[tuple[str, float]] = []

        try:
            if hasattr(self.persistence, "load_all_session_summaries"):
                summaries = self.persistence.load_all_session_summaries()
                summaries.sort(key=lambda s: s.updated_at, reverse=True)
                total_time = time.perf_counter() - start_time
                logger.debug(
                    "[PERF] get_all_session_summaries_async completed: %d summaries in %.2fms",
                    len(summaries),
                    total_time * 1000,
                )
                return summaries

            storage_dir = getattr(self.persistence, "storage_dir", None)
            if not isinstance(storage_dir, Path):
                # Persistence is likely a mock or misconfigured; return empty list
                logger.debug("[PERF] get_all_session_summaries_async: no storage_dir")
                return summaries

            file_paths = list(storage_dir.glob("*.json"))
            logger.debug(
                "[PERF] Starting get_all_session_summaries_async for %d files",
                len(file_paths),
            )

            # Process files in parallel with semaphore to limit concurrency
            semaphore = asyncio.Semaphore(max_concurrent)

            async def process_file(
                file_path: Path,
            ) -> tuple[SessionSummary | None, float, Exception | None]:
                """Process a single file and return (summary, time_taken, error)."""
                file_start = time.perf_counter()
                error = None
                summary = None
                try:
                    # Use to_thread for synchronous file I/O and JSON parsing
                    summary = await asyncio.to_thread(
                        self._load_session_summary, file_path
                    )
                except (
                    json.JSONDecodeError,
                    KeyError,
                    TypeError,
                    ValueError,
                    OSError,
                ) as e:
                    error = e
                file_time = time.perf_counter() - file_start
                return summary, file_time, error

            # Create tasks for all files
            tasks = []
            for file_path in file_paths:
                async with semaphore:
                    tasks.append(process_file(file_path))

            # Wait for all tasks to complete
            results = await asyncio.gather(*tasks, return_exceptions=False)

            # Process results
            for file_path, (summary, file_time, error) in zip(file_paths, results):
                total_files += 1
                if error:
                    logger.debug(
                        "Failed to load session summary from %s: %s",
                        file_path,
                        error,
                    )
                    continue
                if summary:
                    summaries.append(summary)
                if file_time > 0.05:  # Log files taking > 50ms
                    slow_files.append((file_path.name, file_time))

        except OSError as e:
            logger.debug("Error accessing storage_dir: %s", e)

        # Sort by updated_at descending (most recent first)
        summaries.sort(key=lambda s: s.updated_at, reverse=True)

        total_time = time.perf_counter() - start_time
        logger.debug(
            "[PERF] get_all_session_summaries_async completed: %d summaries in %.2fms (processed %d files)",
            len(summaries),
            total_time * 1000,
            total_files,
        )
        if slow_files:
            for name, t in sorted(slow_files, key=lambda x: x[1], reverse=True)[:5]:
                logger.debug("[PERF] Slow summary file: %s took %.2fms", name, t * 1000)

        return summaries

    def get_all_session_summaries(self) -> list[SessionSummary]:
        """Get lightweight summaries of all sessions from storage.

        Synchronous version for compatibility. Consider using
        get_all_session_summaries_async() for better performance.

        This reads only metadata from session files, not full message history,
        to keep memory usage minimal.

        Returns:
            List of SessionSummary objects sorted by updated_at descending.
        """
        import asyncio
        import threading

        # Run async version in event loop
        try:
            # Try to get existing event loop
            asyncio.get_running_loop()
            # If there's a running loop, we need to run in thread to avoid deadlock
            result = None
            event = threading.Event()

            def _run_in_thread():
                nonlocal result
                try:
                    result = asyncio.run(self.get_all_session_summaries_async())
                except Exception as e:
                    result = e
                finally:
                    event.set()

            thread = threading.Thread(target=_run_in_thread)
            thread.start()
            event.wait()

            if isinstance(result, Exception):
                raise result
            return result or []
        except RuntimeError:
            # No running event loop, create new one
            return asyncio.run(self.get_all_session_summaries_async())

    def _load_session_summary(self, file_path) -> SessionSummary | None:
        """Load only metadata from a session file.

        Args:
            file_path: Path to session JSON file.

        Returns:
            SessionSummary if successful, None otherwise.
        """
        start_time = time.perf_counter()
        try:
            with open(file_path) as f:
                data = json.load(f)

            # Extract only the fields we need for summary
            session_id = file_path.stem

            # Get basic fields
            title = data.get("title", "Untitled")
            backend_name = data.get("backend_name", "")
            model = data.get("model", "")
            message_count = data.get("message_count", 0)

            # Parse timestamps
            created_at = data.get("created_at")
            if isinstance(created_at, str):
                created_at = datetime.fromisoformat(created_at)
            elif not isinstance(created_at, datetime):
                created_at = datetime.now()

            updated_at = data.get("updated_at")
            if isinstance(updated_at, str):
                updated_at = datetime.fromisoformat(updated_at)
            elif not isinstance(updated_at, datetime):
                updated_at = created_at

            # Generate preview directly from JSON data without deserializing all messages
            preview = self._generate_preview_from_data(data)

            total_time = time.perf_counter() - start_time
            if total_time > 0.02:  # Log if takes more than 20ms
                logger.debug(
                    "[PERF] _load_session_summary slow: %s took %.2fms (msgs: %d)",
                    file_path.name,
                    total_time * 1000,
                    message_count,
                )

            return SessionSummary(
                id=session_id,
                title=title,
                backend_name=backend_name,
                model=model,
                created_at=created_at,
                updated_at=updated_at,
                message_count=message_count,
                preview=preview,
            )
        except (OSError, json.JSONDecodeError, ValueError) as e:
            logger.debug("Error loading summary from %s: %s", file_path, e)
            return None

    def _generate_preview_from_data(self, data: dict) -> str:
        """Generate preview directly from raw JSON data without deserializing all messages.

        Args:
            data: Raw session data dictionary.

        Returns:
            Preview string extracted from the last non-empty message.
        """
        messages_data = data.get("messages", [])
        if not messages_data:
            return ""

        # Iterate in reverse to find the last message with content
        for msg_data in reversed(messages_data):
            if isinstance(msg_data, dict):
                # Extract content from raw dict, handle tool messages
                role = msg_data.get("role", "")
                content = msg_data.get("content", "")
                tool_name = msg_data.get("tool_name", "") if role == "tool" else ""
            else:
                # If it's already a Message object (unlikely in JSON data)
                role = msg_data.role if hasattr(msg_data, "role") else ""
                content = msg_data.content if hasattr(msg_data, "content") else ""
                tool_name = (
                    msg_data.tool_name
                    if hasattr(msg_data, "tool_name") and role == "tool"
                    else ""
                )

            content = content or ""
            content = content.strip()

            if not content:
                continue

            # Handle tool messages
            if role == "tool":
                tool_name = tool_name or "tool"
                content = f"Tool: {tool_name}"

            # Replace newlines with spaces
            content = content.replace("\n", " ").replace("\r", " ")

            # Strip markdown syntax
            content = _strip_markdown(content)

            # Strip again after markdown removal
            content = content.strip()

            if not content:
                continue

            # Truncate if necessary (max_len = 40)
            if len(content) > 40:
                content = _truncate_preview(content, 40)

            return content

        return ""

    @staticmethod
    def _deserialize_session_data(data: dict) -> dict:
        """Deserialize session data from dict.

        Delegates to SessionPersistence._deserialize_session_data for
        consistent behavior across all deserialization paths.
        """
        from tinychat.utils.session_persistence import (  # noqa: PLC0415
            SessionPersistence as ConcretePersistence,
        )

        return ConcretePersistence._deserialize_session_data(data)

    def get_active_session(self) -> ChatSession | None:
        """Get current active session."""
        if self.active_session_id:
            return self.sessions.get(self.active_session_id)
        return None

    def _save_session_if_not_empty(self, session: ChatSession) -> None:
        """Save session only if it has messages.

        Args:
            session: The session to save.
        """
        if session.messages:
            self.persistence.save_session(session)

    def rename_session(self, session_id: str, new_title: str) -> None:
        """Rename session and persist.

        If the session is not in memory, it will be loaded, renamed,
        saved, and then unloaded (if it's not the active session) to
        maintain single-session mode.
        """
        session_in_memory = session_id in self.sessions

        if not session_in_memory:
            session = self.load_session_from_storage(session_id)
            if not session:
                logger.error("Cannot rename: session %s not found", session_id)
                return
        else:
            session = self.sessions[session_id]

        session.title = new_title
        session.touch()
        self._save_session_if_not_empty(session)

        if not session_in_memory and session_id != self.active_session_id:
            self.unload_session(session_id)

    def schedule_save(self, session_id: str) -> None:
        """Schedule a debounced save for the session.

        Multiple rapid calls will cancel the previous timer and start a new one,
        ensuring the save only happens after a period of inactivity.

        Args:
            session_id: The ID of the session to save.
        """
        # Cancel existing task if any
        if session_id in self._save_tasks:
            self._save_tasks[session_id].cancel()

        # Create new async task
        task = asyncio.create_task(self._debounced_save(session_id))
        self._save_tasks[session_id] = task

    async def _debounced_save(self, session_id: str) -> None:
        """Execute debounced save operation.

        Args:
            session_id: The ID of the session to save.
        """
        try:
            await asyncio.sleep(self._save_delay)
            await self._do_save(session_id)
        except asyncio.CancelledError:
            # Task was cancelled, just return
            pass
        finally:
            # Clean up task tracking
            self._save_tasks.pop(session_id, None)

    async def save_session_now(self, session_id: str) -> None:
        """Save a session immediately, bypassing the debounce timer.

        Args:
            session_id: The ID of the session to save.
        """
        await self._do_save(session_id)

    async def _do_save(self, session_id: str) -> None:
        """Execute the actual save operation.

        Args:
            session_id: The ID of the session to save.
        """
        if session_id in self.sessions:
            session = self.sessions[session_id]
            if not session.messages:
                return
            session.update_metadata()
            self.persistence.save_session(session)

    async def save_all_pending(self) -> None:
        """Save all sessions with pending saves immediately.

        This cancels all pending timers and saves the sessions right away.
        Useful for cleanup operations like app shutdown.
        """
        pending_ids = list(self._save_tasks.keys())

        for session_id in pending_ids:
            self._save_tasks[session_id].cancel()

        if pending_ids:
            await asyncio.gather(
                *(self._save_tasks[sid] for sid in pending_ids),
                return_exceptions=True,
            )

        for session_id in pending_ids:
            await self._do_save(session_id)

    @staticmethod
    def _is_cjk_char(ch: str) -> bool:
        cp = ord(ch)
        return any(lo <= cp <= hi for lo, hi in _CJK_RANGES)

    @staticmethod
    def _truncate_title(text: str, max_len: int = 30) -> str:
        if len(text) <= max_len:
            return text.strip()

        truncated = text[:max_len]

        last_char = truncated[-1]
        if SessionManager._is_cjk_char(last_char):
            next_char = text[max_len] if max_len < len(text) else ""
            if SessionManager._is_cjk_char(next_char):
                truncated = truncated[:-1]
        else:
            space_pos = truncated.rfind(" ")
            if space_pos > max_len // 2:
                truncated = truncated[:space_pos]

        result = truncated.rstrip(" \t,，.。;；:：!！?？、") + "..."
        return result

    def auto_rename_from_first_message(self, session_id: str) -> bool:
        """Auto-rename session based on first user message.

        Only renames sessions with default titles (starting with "Chat ").
        Truncates at word boundaries when possible to avoid breaking
        Chinese characters or words mid-way.

        Args:
            session_id: The ID of the session to rename.

        Returns:
            True if renamed, False otherwise.
        """
        session = self.sessions.get(session_id)
        if not session:
            return False

        if not session.title.startswith("Chat "):
            return False

        first_user_msg = next((m for m in session.messages if m.role == "user"), None)
        if not first_user_msg:
            return False

        new_title = self._truncate_title(first_user_msg.content)

        if not new_title:
            return False

        session.title = new_title
        session.touch()
        self._save_session_if_not_empty(session)
        return True
