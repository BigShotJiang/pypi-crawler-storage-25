"""Structured logging configuration for TinyChat.

This module provides JSON-formatted structured logging with support for:
- Console output (simple format)
- File output (JSON format with rotation)
- Extra fields for session tracking, metrics, and errors
"""

import json
import logging
import logging.handlers
from datetime import datetime, timezone
from pathlib import Path


class JsonFormatter(logging.Formatter):
    """JSON formatter for structured logging.

    Formats log records as JSON objects with timestamp, level, logger,
    and message fields. Supports extra fields for session tracking,
    performance metrics, and error information.

    Extra fields (added via logging.LogRecord attributes):
        - session_id: Chat session identifier
        - backend: Backend name (e.g., 'ollama', 'openai-compatible')
        - model: Model name
        - tokens: Token count
        - duration_ms: Operation duration in milliseconds
        - error: Error message or details
    """

    def format(self, record: logging.LogRecord) -> str:
        """Format a log record as a JSON string.

        Args:
            record: The log record to format.

        Returns:
            A JSON-formatted string representing the log entry.
        """
        entry: dict[str, object] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        if record.exc_info:
            entry["exception"] = self.formatException(record.exc_info)
        if record.stack_info:
            entry["stack_trace"] = self.formatStack(record.stack_info)

        if hasattr(record, "session_id"):
            entry["session_id"] = record.session_id
        if hasattr(record, "backend"):
            entry["backend"] = record.backend
        if hasattr(record, "model"):
            entry["model"] = record.model
        if hasattr(record, "tokens"):
            entry["tokens"] = record.tokens
        if hasattr(record, "duration_ms"):
            entry["duration_ms"] = record.duration_ms
        if hasattr(record, "error"):
            entry["error"] = record.error
        if hasattr(record, "tool_name"):
            entry["tool_name"] = record.tool_name
        if hasattr(record, "success"):
            entry["success"] = record.success

        return json.dumps(entry, ensure_ascii=False)


def setup_logging(
    enabled: bool = False,
    level: str = "INFO",
    file: str | None = None,
    max_size_mb: int = 5,
    backup_count: int = 3,
) -> None:
    """Configure structured logging for TinyChat.

    Sets up logging with console output (simple format) and optional
    file output (JSON format with rotation).

    Args:
        enabled: Whether to enable file logging. If False, only console
            output is configured.
        level: Log level as a string (DEBUG, INFO, WARNING, ERROR, CRITICAL).
            Default is INFO.
        file: Path to the log file. Supports ~ expansion. If enabled=True
            and file is provided, a rotating file handler is added.
        max_size_mb: Maximum size of each log file in megabytes.
            Default is 5 MB.
        backup_count: Number of backup files to keep. Default is 3.

    Example:
        # Basic setup (console only)
        setup_logging()

        # Enable file logging
        setup_logging(enabled=True, file="~/.tinychat/logs/tinychat.log")

        # With custom level
        setup_logging(enabled=True, level="DEBUG", file="/var/log/tinychat.log")
    """
    root_logger = logging.getLogger("tinychat")
    root_logger.setLevel(getattr(logging, level.upper()))

    # Clear existing handlers
    root_logger.handlers.clear()

    if enabled and file:
        log_path = Path(file).expanduser()
        log_path.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.handlers.RotatingFileHandler(
            log_path,
            maxBytes=max_size_mb * 1024 * 1024,
            backupCount=backup_count,
            encoding="utf-8",
        )
        file_handler.setFormatter(JsonFormatter())
        root_logger.addHandler(file_handler)
