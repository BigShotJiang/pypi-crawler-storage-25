"""Metrics collection for streaming performance tracking."""

import time


class MetricsCollector:
    """Collects and tracks streaming performance metrics."""

    def __init__(self):
        """Initialize metrics collector."""
        self.total_tokens = 0
        self.start_time: float | None = None
        self.first_token_time: float | None = None
        self.end_time: float | None = None

    def start(self) -> None:
        """Start metrics collection."""
        self.reset()
        self.start_time = time.time()

    def record_token(self) -> None:
        """Record a single token."""
        if self.start_time is None:
            return

        if self.first_token_time is None:
            self.first_token_time = time.time()

        self.total_tokens += 1

    def stop(self) -> None:
        """Stop metrics collection."""
        self.end_time = time.time()

    def get_elapsed_time(self) -> float:
        """Get elapsed time since start in seconds."""
        if self.start_time is None:
            return 0.0

        if self.end_time is not None:
            return self.end_time - self.start_time

        return time.time() - self.start_time

    def get_tokens_per_second(self) -> float:
        """Calculate tokens per second."""
        if not self.start_time or self.total_tokens == 0:
            return 0.0

        elapsed = self.get_elapsed_time()
        if elapsed == 0:
            return 0.0

        return self.total_tokens / elapsed

    def get_latency(self) -> float:
        """Get latency (time to first token) in seconds."""
        if self.start_time is None or self.first_token_time is None:
            return 0.0

        return self.first_token_time - self.start_time

    def get_response_time(self) -> float:
        """Get total response time in seconds."""
        return self.get_elapsed_time()

    def reset(self) -> None:
        """Reset all metrics."""
        self.total_tokens = 0
        self.start_time = None
        self.first_token_time = None
        self.end_time = None

    def get_metrics(self) -> dict:
        """Get all current metrics as a dictionary."""
        return {
            "total_tokens": self.total_tokens,
            "tokens_per_second": self.get_tokens_per_second(),
            "latency": self.get_latency(),
            "response_time": self.get_response_time(),
            "elapsed_time": self.get_elapsed_time(),
        }
