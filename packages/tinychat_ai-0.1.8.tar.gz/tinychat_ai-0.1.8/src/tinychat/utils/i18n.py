import gettext
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

_CURRENT_LOCALE: str = "en"
_TRANSLATOR: gettext.NullTranslations | None = None

_LOCALES_DIR = Path(__file__).parent.parent / "locales"


def init_i18n(locale: str | None = None) -> None:
    global _CURRENT_LOCALE, _TRANSLATOR

    _CURRENT_LOCALE = locale if locale is not None else "en"

    try:
        _TRANSLATOR = gettext.translation(
            "tinychat",
            localedir=str(_LOCALES_DIR),
            languages=[_CURRENT_LOCALE],
        )
    except FileNotFoundError:
        logger.debug(
            "Locale file not found for '%s', falling back to NullTranslations",
            _CURRENT_LOCALE,
        )
        _TRANSLATOR = gettext.NullTranslations()


def _(msgid: str) -> str:
    if _TRANSLATOR is None:
        return msgid
    return _TRANSLATOR.gettext(msgid)


def ngettext(msgid: str, msgid_plural: str, n: int) -> str:
    if _TRANSLATOR is None:
        return msgid if n == 1 else msgid_plural
    return _TRANSLATOR.ngettext(msgid, msgid_plural, n)


def get_current_locale() -> str:
    return _CURRENT_LOCALE


def set_locale(locale: str) -> None:
    init_i18n(locale)


def get_available_locales() -> list[str]:
    return ["en", "zh"]
