"""Parameter formatting utilities for tool UI display."""

import os
from typing import Any


class ParameterFormatter:
    """Formats tool parameters for UI display with truncation and masking."""

    # Sensitive parameter names that should be masked
    SENSITIVE_KEYS = {
        "api_key",
        "apikey",
        "api-key",
        "apiKey",
        "password",
        "passwd",
        "pwd",
        "token",
        "secret",
        "secret_key",
        "secretkey",
        "key",
        "private_key",
        "privatekey",
        "credential",
        "credentials",
        "auth_token",
        "authtoken",
        "bearer_token",
        "bearertoken",
    }

    # Parameter names that contain paths
    PATH_KEYS = {"path", "file", "filename", "filepath", "directory", "dir", "folder"}

    def truncate_value(self, value: Any, max_len: int = 50) -> str:
        """Truncate value for display.

        Args:
            value: Value to truncate
            max_len: Maximum length of output string

        Returns:
            Truncated string with ellipsis if needed
        """
        if value is None:
            return "None"

        # Convert to string
        str_value = str(value)

        # Already short enough
        if len(str_value) <= max_len:
            return str_value

        # Truncate with ellipsis
        return str_value[: max_len - 3] + "..."

    def _mask_sensitive_value(self, key: str, value: str) -> str:
        """Mask sensitive values like API keys and passwords.

        Args:
            key: Parameter name
            value: Parameter value

        Returns:
            Masked value
        """
        # Check if this is a sensitive parameter
        key_lower = key.lower()
        is_sensitive = any(sensitive in key_lower for sensitive in self.SENSITIVE_KEYS)

        if not is_sensitive:
            return value

        # Empty or None value
        if not value:
            return value

        # Special handling for API keys and tokens
        if any(prefix in key_lower for prefix in ["api", "token", "key", "secret"]):
            # For API keys like "sk-abc123...", show first 3 and last 4 chars
            if len(value) <= 10:
                return "*" * 8  # Short mask for very short values

            prefix_len = 3
            suffix_len = 4

            # Handle Bearer tokens
            if value.startswith("Bearer "):
                bearer = "Bearer "
                token = value[len(bearer) :]
                if len(token) <= 10:
                    return bearer + "*" * 8
                return bearer + token[:prefix_len] + "..." + token[-suffix_len:]

            # Handle other tokens/keys
            return value[:prefix_len] + "..." + value[-suffix_len:]

        # Generic sensitive value (password, secret, etc.)
        return "********"

    def _make_path_relative(self, path: str) -> str:
        """Make path relative to current directory if possible.

        Args:
            path: Path to process

        Returns:
            Relative path if within cwd, absolute path otherwise
        """
        if not isinstance(path, str):
            return str(path)

        # Already a relative path
        if path.startswith("./") or path.startswith("../"):
            return path

        # Home directory path
        home = os.path.expanduser("~")
        if path.startswith(home):
            return "~" + path[len(home) :]

        # Try to make relative to cwd
        try:
            cwd = os.getcwd()
            if path.startswith(cwd):
                relative = os.path.relpath(path, cwd)
                # Ensure it starts with ./
                if not relative.startswith("."):
                    relative = "./" + relative
                return relative
        except (ValueError, OSError):
            # Can't make relative (different drives on Windows, etc.)
            pass

        # Return as-is
        return path

    def format_for_preview(self, params: dict[str, Any]) -> list[str]:
        """Format parameters for preview display (truncated, masked).

        Args:
            params: Dictionary of parameter name to value

        Returns:
            List of formatted strings "key: value"
        """
        formatted = []

        for key, value in params.items():
            # Process value
            str_value = str(value)

            # Mask sensitive values
            str_value = self._mask_sensitive_value(key, str_value)

            # Make paths relative
            if any(path_key in key.lower() for path_key in self.PATH_KEYS):
                str_value = self._make_path_relative(str_value)

            # Truncate long values
            str_value = self.truncate_value(str_value, max_len=50)

            formatted.append(f"{key}: {str_value}")

        return formatted

    def format_for_detail(
        self, params: dict[str, Any], schema: dict
    ) -> dict[str, dict]:
        """Format parameters for detailed display with metadata.

        Args:
            params: Dictionary of parameter name to value
            schema: Tool parameter schema with type and description

        Returns:
            Dictionary with detailed parameter info:
            {
                "param_name": {
                    "value": str,  # Formatted value
                    "type": str,    # Parameter type
                    "description": str,  # Parameter description
                    "required": bool,  # Whether parameter is required
                }
            }
        """
        result = {}
        schema_props = schema.get("properties", {})
        required_params = set(schema.get("required", []))

        for key, value in params.items():
            param_schema = schema_props.get(key, {})

            # Process value
            str_value = str(value)

            # Mask sensitive values
            str_value = self._mask_sensitive_value(key, str_value)

            # Make paths relative
            if any(path_key in key.lower() for path_key in self.PATH_KEYS):
                str_value = self._make_path_relative(str_value)

            # Don't truncate for detailed view
            result[key] = {
                "value": str_value,
                "type": param_schema.get("type", "unknown"),
                "description": param_schema.get("description", ""),
                "required": key in required_params,
                "original_value": value,  # Keep original for reference
            }

        return result
