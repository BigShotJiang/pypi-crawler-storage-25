"""Unified TOML configuration manager for TinyChat.

This module provides a unified configuration system that stores both user
preferences and backend configurations in a single TOML file at
~/.config/tinychat/config.toml
"""

import logging
from pathlib import Path

try:
    import tomllib
except ImportError:
    import tomli as tomllib

import tomli_w

from tinychat.compaction.config import CompactionConfig
from tinychat.models.config import BackendConfig, LoggingConfig
from tinychat.models.user_config import UserConfig

logger = logging.getLogger(__name__)

_CONFIG_DIR = ".config/tinychat"
_CONFIG_CACHE: dict | None = None
_CONFIG_FILE = "config.toml"
_SETTINGS_SECTION = "settings"
_BACKENDS_SECTION = "backends"
_LOGGING_SECTION = "logging"
_ALLOWED_TOOLS_SECTION = "allowed_tools"
_COMPACTION_SECTION = "compaction"
_KEY_LOCALE = "locale"
_KEY_TOOLS = "tools"


def _load_config_once() -> dict:
    """Load config file once and cache it in memory.

    Subsequent calls return the cached dictionary. Call _invalidate_config_cache()
    to force a reload from disk (e.g., after saving).
    """
    global _CONFIG_CACHE
    if _CONFIG_CACHE is None:
        config_path = get_config_path()
        if config_path.exists():
            try:
                with open(config_path, "rb") as f:
                    _CONFIG_CACHE = tomllib.load(f)
            except (tomllib.TOMLDecodeError, OSError) as e:
                logger.warning("Failed to parse config file %s: %s", config_path, e)
                _CONFIG_CACHE = {}
        else:
            _CONFIG_CACHE = {}
    return _CONFIG_CACHE


def _invalidate_config_cache() -> None:
    """Clear the config cache, forcing next read to reload from disk."""
    global _CONFIG_CACHE
    _CONFIG_CACHE = None


def get_config_path() -> Path:
    """Return the path to the unified TOML configuration file.

    Returns:
        Path to ~/.config/tinychat/config.toml
    """
    return Path.home() / _CONFIG_DIR / _CONFIG_FILE


def load_user_config() -> UserConfig:
    """Load user configuration from TOML file.

    Uses cached config after first load. Returns default UserConfig if file
    doesn't exist or required sections/keys are missing.
    """
    data = _load_config_once()

    settings = data.get(_SETTINGS_SECTION, {})
    if not isinstance(settings, dict):
        logger.debug("Invalid [%s] section, returning default", _SETTINGS_SECTION)
        return UserConfig()

    locale = settings.get(_KEY_LOCALE)
    if not locale:
        logger.debug("Empty or missing locale value in config, returning default")
        return UserConfig()

    return UserConfig(locale=str(locale))


def save_user_config(config: UserConfig) -> None:
    """Save user configuration to TOML file.

    Preserves existing [[backends]] configuration if present.
    Creates parent directories if they don't exist.

    Args:
        config: UserConfig to save
    """
    config_path = get_config_path()

    try:
        config_path.parent.mkdir(parents=True, exist_ok=True)

        existing_backends = []
        if config_path.exists():
            try:
                with open(config_path, "rb") as f:
                    existing_data = tomllib.load(f)
                existing_backends = existing_data.get(_BACKENDS_SECTION, [])
            except (tomllib.TOMLDecodeError, OSError):
                pass

        data = {
            _SETTINGS_SECTION: {_KEY_LOCALE: config.locale},
        }

        if existing_backends:
            data[_BACKENDS_SECTION] = existing_backends

        with open(config_path, "wb") as f:
            tomli_w.dump(data, f)

        # Invalidate cache so next read reflects changes
        _invalidate_config_cache()

    except (OSError, PermissionError) as e:
        logger.warning("Failed to save config to %s: %s", config_path, e)


def load_backends() -> list[BackendConfig]:
    """Load backend configurations from unified TOML file.

    Uses cached config after first load. Returns empty list if no backends
    are configured.
    """
    data = _load_config_once()

    backends_data = data.get(_BACKENDS_SECTION, [])
    if not isinstance(backends_data, list):
        logger.debug("Invalid [%s] section, returning empty list", _BACKENDS_SECTION)
        return []

    backends = []
    for backend_data in backends_data:
        if not isinstance(backend_data, dict):
            continue
        try:
            backend = BackendConfig(
                name=backend_data["name"],
                type=backend_data["type"],
                endpoint=backend_data["endpoint"],
                default_model=backend_data["default_model"],
                api_key=backend_data.get("api_key"),
            )
            backends.append(backend)
        except KeyError as e:
            logger.warning("Missing required field in backend config: %s", e)
            continue

    return backends


def load_logging_config() -> LoggingConfig:
    """Load logging configuration from unified TOML file.

    Uses cached config after first load. Returns default LoggingConfig if
    [logging] section is missing.
    """
    data = _load_config_once()

    logging_data = data.get(_LOGGING_SECTION, {})
    if not isinstance(logging_data, dict):
        logger.debug("Invalid [%s] section, returning default", _LOGGING_SECTION)
        return LoggingConfig()

    # Return config with partial values, using defaults for missing fields
    return LoggingConfig(
        enabled=logging_data.get("enabled", False),
        level=logging_data.get("level", "INFO"),
        file=logging_data.get("file", str(Path.home() / ".tinychat" / "tinychat.log")),
        max_size_mb=logging_data.get("max_size_mb", 5),
        backup_count=logging_data.get("backup_count", 3),
    )


def save_logging_config(config: LoggingConfig) -> None:
    """Save logging configuration to TOML file.

    Preserves existing [settings] and [[backends]] configuration if present.
    Creates parent directories if they don't exist.

    Args:
        config: LoggingConfig to save
    """
    config_path = get_config_path()

    try:
        config_path.parent.mkdir(parents=True, exist_ok=True)

        # Load existing data to preserve other sections
        existing_data = {}
        if config_path.exists():
            try:
                with open(config_path, "rb") as f:
                    existing_data = tomllib.load(f)
            except (tomllib.TOMLDecodeError, OSError):
                pass

        # Build new data, preserving existing sections
        data = {}

        # Preserve [settings] section
        if _SETTINGS_SECTION in existing_data:
            data[_SETTINGS_SECTION] = existing_data[_SETTINGS_SECTION]

        # Preserve [[backends]] section
        if _BACKENDS_SECTION in existing_data:
            data[_BACKENDS_SECTION] = existing_data[_BACKENDS_SECTION]

        # Add [logging] section
        data[_LOGGING_SECTION] = {
            "enabled": config.enabled,
            "level": config.level,
            "file": config.file,
            "max_size_mb": config.max_size_mb,
            "backup_count": config.backup_count,
        }

        with open(config_path, "wb") as f:
            tomli_w.dump(data, f)

        # Invalidate cache so next read reflects changes
        _invalidate_config_cache()

    except (OSError, PermissionError) as e:
        logger.warning("Failed to save config to %s: %s", config_path, e)


def load_allowed_tools(config_path: Path | None = None) -> list[str]:
    _config_path = config_path or get_config_path()

    # Use cached config if using default path
    if config_path is None:
        data = _load_config_once()
    else:
        # Non-default path: load directly (no caching)
        if not _config_path.exists():
            logger.debug(
                "Config file not found at %s, returning empty list",
                _config_path,
            )
            return []
        try:
            with open(_config_path, "rb") as f:
                data = tomllib.load(f)
        except (tomllib.TOMLDecodeError, OSError) as e:
            logger.warning("Failed to parse config file %s: %s", _config_path, e)
            return []

    allowed_tools_data = data.get(_ALLOWED_TOOLS_SECTION, {})
    if not isinstance(allowed_tools_data, dict):
        logger.debug(
            "Invalid [%s] section, returning empty list",
            _ALLOWED_TOOLS_SECTION,
        )
        return []

    tools = allowed_tools_data.get(_KEY_TOOLS, [])
    if not isinstance(tools, list):
        logger.debug(
            "Invalid %s value in [%s], returning empty list",
            _KEY_TOOLS,
            _ALLOWED_TOOLS_SECTION,
        )
        return []

    return [str(t) for t in tools]


def save_allowed_tools(tools: list[str], config_path: Path | None = None) -> None:
    _config_path = config_path or get_config_path()

    try:
        _config_path.parent.mkdir(parents=True, exist_ok=True)

        existing_data = {}
        if _config_path.exists():
            try:
                with open(_config_path, "rb") as f:
                    existing_data = tomllib.load(f)
            except (tomllib.TOMLDecodeError, OSError):
                pass

        data = {}

        if _SETTINGS_SECTION in existing_data:
            data[_SETTINGS_SECTION] = existing_data[_SETTINGS_SECTION]

        if _BACKENDS_SECTION in existing_data:
            data[_BACKENDS_SECTION] = existing_data[_BACKENDS_SECTION]

        if _LOGGING_SECTION in existing_data:
            data[_LOGGING_SECTION] = existing_data[_LOGGING_SECTION]

        data[_ALLOWED_TOOLS_SECTION] = {_KEY_TOOLS: tools}

        with open(_config_path, "wb") as f:
            tomli_w.dump(data, f)

        # Invalidate cache if using default config path
        if config_path is None:
            _invalidate_config_cache()

    except (OSError, PermissionError) as e:
        logger.warning("Failed to save config to %s: %s", _config_path, e)


def load_compaction_config() -> CompactionConfig:
    """Load compaction configuration from unified TOML file.

    Uses cached config after first load. Returns default CompactionConfig if
    [compaction] section is missing.
    """
    data = _load_config_once()

    compaction_data = data.get(_COMPACTION_SECTION, {})
    if not isinstance(compaction_data, dict):
        logger.debug("Invalid [%s] section, returning default", _COMPACTION_SECTION)
        return CompactionConfig()

    return CompactionConfig(
        enabled=compaction_data.get("enabled", True),
        auto=compaction_data.get("auto", True),
        reserved_tokens=compaction_data.get("reserved_tokens", 20000),
        prune_tool_results=compaction_data.get("prune_tool_results", True),
        max_tool_results=compaction_data.get("max_tool_results", 5),
        preserve_recent_assistant=compaction_data.get("preserve_recent_assistant", 3),
        model=compaction_data.get("model", ""),
    )


def save_compaction_config(config: CompactionConfig) -> None:
    """Save compaction configuration to TOML file.

    Preserves existing [settings], [[backends]], and [logging] sections.
    Creates parent directories if they don't exist.

    Args:
        config: CompactionConfig to save
    """
    config_path = get_config_path()

    try:
        config_path.parent.mkdir(parents=True, exist_ok=True)

        existing_data = {}
        if config_path.exists():
            try:
                with open(config_path, "rb") as f:
                    existing_data = tomllib.load(f)
            except (tomllib.TOMLDecodeError, OSError):
                pass

        data = {}

        if _SETTINGS_SECTION in existing_data:
            data[_SETTINGS_SECTION] = existing_data[_SETTINGS_SECTION]

        if _BACKENDS_SECTION in existing_data:
            data[_BACKENDS_SECTION] = existing_data[_BACKENDS_SECTION]

        if _LOGGING_SECTION in existing_data:
            data[_LOGGING_SECTION] = existing_data[_LOGGING_SECTION]

        data[_COMPACTION_SECTION] = {
            "enabled": config.enabled,
            "auto": config.auto,
            "reserved_tokens": config.reserved_tokens,
            "prune_tool_results": config.prune_tool_results,
            "max_tool_results": config.max_tool_results,
            "preserve_recent_assistant": config.preserve_recent_assistant,
            "model": config.model,
        }

        with open(config_path, "wb") as f:
            tomli_w.dump(data, f)

        _invalidate_config_cache()

    except (OSError, PermissionError) as e:
        logger.warning("Failed to save config to %s: %s", config_path, e)


def get_settings() -> dict:
    """Return the [settings] section of the configuration.

    Returns an empty dict if the section is missing or invalid.
    """
    data = _load_config_once()
    settings = data.get(_SETTINGS_SECTION, {})
    if not isinstance(settings, dict):
        logger.debug("Invalid [%s] section, returning empty dict", _SETTINGS_SECTION)
        return {}
    return settings


class ConfigManager:
    """Simple manager to access configuration settings."""

    def get_settings(self) -> dict:
        """Get the settings section from the configuration."""
        return get_settings()
