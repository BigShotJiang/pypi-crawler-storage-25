"""UI components for TinyChat."""

from tinychat.components.summary_rule_widget import SummaryRuleWidget

__all__ = ["SummaryRuleWidget"]
