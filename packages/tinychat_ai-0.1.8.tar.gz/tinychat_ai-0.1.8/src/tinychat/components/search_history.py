import logging
from datetime import datetime

from textual.containers import Vertical, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Input, Label, ListItem, ListView, Static

from tinychat.utils.i18n import _

logger = logging.getLogger(__name__)


class HistoryItem(ListItem):
    pass


class SearchHistoryScreen(ModalScreen):
    def __init__(self, questions: list[dict]):
        super().__init__()
        self.all_questions = questions
        self._filtered = list(questions)

    def compose(self):
        yield Vertical(
            Static(_("Search History"), classes="command-palette-title"),
            Input(
                placeholder=_("Type to search your questions..."),
                id="search-history-filter",
            ),
            Static(
                _("Press ↑/↓ to navigate, Enter to select, Escape to cancel"),
                classes="command-palette-hint",
            ),
            ListView(id="search-history-list"),
            classes="command-palette-container",
        )

    async def on_mount(self):
        await self._update_list("")
        self.query_one("#search-history-filter").focus()

    async def _update_list(self, filter_text: str):
        list_view = self.query_one("#search-history-list", ListView)
        await list_view.clear()

        if filter_text:
            ft = filter_text.lower()
            self._filtered = [
                q
                for q in self.all_questions
                if ft in q["content"].lower()
                or ft in q.get("session_title", "").lower()
            ]
        else:
            self._filtered = list(self.all_questions)

        for q in self._filtered:
            content = q["content"]
            if len(content) > 80:
                content = content[:77] + "..."
            content = content.replace("\n", " ")

            session_label = q.get("session_title", "")
            time_str = self._format_time(q.get("timestamp"))

            detail_parts = []
            if session_label:
                detail_parts.append(session_label)
            if time_str:
                detail_parts.append(time_str)
            detail = " · ".join(detail_parts) if detail_parts else ""

            item = HistoryItem(
                Horizontal(
                    Label("💬", classes="command-icon"),
                    Label(content, classes="command-name"),
                    Label(detail, classes="command-description"),
                    classes="command-item-content",
                ),
                classes="command-item",
            )
            await list_view.append(item)

    @staticmethod
    def _format_time(ts: datetime | None) -> str:
        if ts is None:
            return ""
        now = datetime.now()
        delta = now - ts
        if delta.days == 0:
            hours = delta.seconds // 3600
            if hours == 0:
                minutes = delta.seconds // 60
                if minutes <= 1:
                    return _("now")
                return _("Session List")
            return _("Session List")
        if delta.days == 1:
            return _("Yesterday")
        if delta.days < 7:
            return ts.strftime("%a %H:%M")
        return ts.strftime("%m/%d")

    async def on_input_changed(self, event: Input.Changed):
        await self._update_list(event.value)

    def on_key(self, event):
        if event.key == "escape":
            self.dismiss(None)
            return
        if event.key in ("down", "up"):
            if self.query_one("#search-history-filter").has_focus:
                event.prevent_default()
                event.stop()
                list_view = self.query_one("#search-history-list")
                list_view.focus()
                if list_view.children:
                    if event.key == "down":
                        list_view.index = 0
                    else:
                        list_view.index = len(list_view.children) - 1

    def on_list_view_selected(self, event: ListView.Selected):
        idx = event.list_view.index
        if 0 <= idx < len(self._filtered):
            self.dismiss(self._filtered[idx])
