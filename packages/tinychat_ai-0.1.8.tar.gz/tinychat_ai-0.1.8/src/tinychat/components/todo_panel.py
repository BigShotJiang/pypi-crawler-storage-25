"""TodoPanel component - standalone panel for displaying todo items.

Uses dock:right layout for fixed positioning, separate from Sidebar.
"""

from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static

from tinychat.utils.i18n import _


def _truncate_text(text: str, max_display_width: int = 25) -> str:
    display_width = 0
    for i, char in enumerate(text):
        char_width = 2 if "\u4e00" <= char <= "\u9fff" else 1
        if display_width + char_width > max_display_width - 3:
            return text[:i] + "..."
        display_width += char_width
    return text


def _center_text(text: str, width: int = 31) -> str:
    display_width = 0
    for char in text:
        char_width = 2 if "\u4e00" <= char <= "\u9fff" else 1
        display_width += char_width
    if display_width >= width:
        return text
    padding = (width - display_width) // 2
    return " " * padding + text


def _center_line(text: str, width: int = 33) -> str:
    display_width = 0
    for char in text:
        char_width = 2 if "\u4e00" <= char <= "\u9fff" else 1
        display_width += char_width
    if display_width >= width:
        return text
    padding = (width - display_width) // 2
    return " " * padding + text


class TodoPanel(Static):
    """Standalone panel for displaying todo items.

    Uses dock:right for fixed overlay positioning.
    This panel is toggled via command palette (Ctrl+P).
    """

    todos: reactive[list[dict]] = reactive([], layout=True)

    can_focus = True

    DEFAULT_CSS = """
    TodoPanel {
        split: right;
        width: 35;
        height: 1fr;
        background: $panel;
        border-left: solid $primary;
        padding: 1;
    }

    TodoPanel.hidden-panel {
        display: none;
    }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.add_class("hidden-panel")

    def render(self) -> Text:
        text = Text()
        todos_title = f" {_('Todos')} "
        text.append(_center_line("═" * 3 + todos_title + "═" * 3) + "\n", style="bold")

        if not self.todos:
            text.append("  ")
            text.append(_center_text(_("No tasks")) + "\n")
            return text

        counts = {"completed": 0, "pending": 0, "in_progress": 0}
        icons = {"completed": "✓", "in_progress": "⏳", "pending": "○"}

        for todo in self.todos:
            status = todo.get("status", "pending")
            counts[status] = counts.get(status, 0) + 1
            priority = todo.get("priority", "medium").upper()[:4]
            content = _truncate_text(todo.get("content", ""))
            icon = icons.get(status, "○")
            line = f"{icon} [{priority}] {content}"
            text.append("  " + _center_text(line) + "\n")

        total = len(self.todos)
        completed = counts["completed"]
        progress_text = f"({completed}/{total})"
        text.append("\n" + _center_text(progress_text) + "\n")

        return text
