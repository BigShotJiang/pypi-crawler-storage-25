"""Tool execution widget for inline confirmation and result display.

This widget provides an inline card that shows the tool execution status
in context. It supports pending (confirmation), running, completed, and
failed states.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from textual import on
from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.widgets import Button, Collapsible, Label, Static

from tinychat.models.workflow import WorkflowItem, WorkflowStatus
from tinychat.utils.i18n import _

if TYPE_CHECKING:
    from tinychat.tools.base import Tool


class ToolExecutionWidget(Static):
    """Inline tool execution card with state-based rendering.

    Displays tool execution progress directly in the chat flow,
    supporting confirmation, execution, and result display.
    """

    can_focus = True

    DEFAULT_CSS = """
    ToolExecutionWidget {
        background: $warning 8%;
        color: $foreground-muted;
        margin: 0 3;
        padding: 0 2;
        border: none;
    }

    ToolExecutionWidget > Collapsible {
        margin: 0;
        padding: 0;
    }

    ToolExecutionWidget > Collapsible > Static {
        padding: 0 2;
    }

    ToolExecutionWidget.pending {
        background: $warning 12%;
        border: none;
    }

    ToolExecutionWidget.running {
        background: $primary 10%;
        border: none;
    }

    ToolExecutionWidget.completed {
        background: $success 8%;
        border: none;
    }

    ToolExecutionWidget.failed {
        background: $error 12%;
        border: none;
    }

    ToolExecutionWidget .tool-header {
        height: 1;
        width: 1fr;
        content-align: left middle;
    }

    ToolExecutionWidget .tool-icon {
        width: 3;
        text-align: center;
    }

    ToolExecutionWidget .tool-name {
        text-style: bold;
        margin-left: 1;
    }

    ToolExecutionWidget .tool-status {
        text-align: right;
        color: $text-muted;
    }

    ToolExecutionWidget .tool-description {
        color: $text-muted;
        margin-left: 4;
        margin-bottom: 0;
    }

    ToolExecutionWidget .arguments-section {
        margin-left: 2;
        margin-bottom: 0;
    }

    ToolExecutionWidget .arguments-label {
        color: $text-muted;
        text-style: italic;
    }

    ToolExecutionWidget .arguments-list {
        margin-left: 2;
        margin-top: 0;
    }

    ToolExecutionWidget .result-section {
        margin-left: 2;
        margin-top: 0;
    }

    ToolExecutionWidget .result-meta {
        color: $text-muted;
        margin-left: 4;
        margin-bottom: 0;
    }

    ToolExecutionWidget .error-message {
        color: $error;
        margin-left: 2;
        margin-bottom: 0;
    }

    ToolExecutionWidget .progress-indicator {
        color: $primary;
        text-style: bold;
    }

    ToolExecutionWidget .action-hint {
        color: $text-muted;
        margin-left: 2;
        margin-top: 0;
        margin-bottom: 0;
    }

    ToolExecutionWidget .action-buttons {
        margin-left: 2;
        margin-top: 0;
        height: auto;
    }

    ToolExecutionWidget .confirm-button {
        margin-right: 1;
        min-width: 0;
    }

    ToolExecutionWidget .deny-button {
        min-width: 0;
    }
    """

    BINDINGS = [
        ("space", "confirm", "Confirm"),
        ("escape", "deny", "Deny"),
        ("e", "edit", "Edit"),
        ("w", "toggle_collapsed", "Toggle"),
        ("r", "retry", "Retry"),
    ]

    def __init__(
        self,
        item: WorkflowItem,
        tool: Tool | None = None,
        on_confirm: callable | None = None,
        on_deny: callable | None = None,
        on_edit: callable | None = None,
        on_retry: callable | None = None,
        read_only: bool = False,
        **kwargs,
    ) -> None:
        """Initialize tool execution widget.

        Args:
            item: The workflow item representing this tool call.
            tool: Optional Tool instance (needed for execution/retry).
            on_confirm: Callback when user confirms.
            on_deny: Callback when user denies.
            on_edit: Callback when user wants to edit arguments.
            on_retry: Callback for retry action.
            read_only: If True, disable all interactive bindings.
            **kwargs: Additional Textual widget arguments.
        """
        super().__init__(**kwargs)
        self.item = item
        self.tool = tool
        self.on_confirm = on_confirm
        self.on_deny = on_deny
        self.on_edit = on_edit
        self.on_retry = on_retry
        self.read_only = read_only
        if read_only:
            self.BINDINGS = []
        self._displayed_status: WorkflowStatus | None = item.status

    def compose(self) -> ComposeResult:
        """Compose the widget UI."""
        title = self._build_title()
        collapsed = self._resolve_collapsed()
        with Collapsible(title=title, collapsed=collapsed):
            yield from self._build_inner_content()

    def _resolve_collapsed(self) -> bool:
        """Resolve the collapsed state based on status and widget_collapsed.

        Rules:
        - PENDING: always expanded (needs user confirmation).
        - COMPLETED / FAILED: always collapsed.
        - RUNNING: use widget_collapsed.
        """
        if self.item.status == WorkflowStatus.PENDING:
            return False
        if self.item.status in (WorkflowStatus.COMPLETED, WorkflowStatus.FAILED):
            return True
        return self.item.widget_collapsed

    def _build_title(self) -> str:
        """Build the collapsible title string."""
        icon = self.item.status_icon
        name = self.item.tool_name
        duration = f" ({self.item.duration_str})" if self.item.duration_str else ""

        if self.item.status == WorkflowStatus.PENDING:
            return f"{icon} {name}: {_('Pending')}{duration}"
        elif self.item.status == WorkflowStatus.RUNNING:
            return f"{icon} {name}: {_('Running')}{duration}"
        elif self.item.status == WorkflowStatus.COMPLETED:
            return f"{icon} {name}: {_('Completed')}{duration}"
        elif self.item.status == WorkflowStatus.FAILED:
            return f"{icon} {name}: {_('Failed')}{duration}"
        return f"{icon} {name}"

    def _build_inner_content(self):
        """Build inner content based on current status."""
        status = self.item.status

        if self.read_only and status == WorkflowStatus.PENDING:
            yield from self._build_completed_content()
        elif status == WorkflowStatus.PENDING:
            yield from self._build_pending_content()
        elif self.read_only and status == WorkflowStatus.RUNNING:
            yield from self._build_completed_content()
        elif status == WorkflowStatus.RUNNING:
            yield from self._build_running_content()
        elif status == WorkflowStatus.COMPLETED:
            yield from self._build_completed_content()
        elif status == WorkflowStatus.FAILED:
            yield from self._build_failed_content()

    def _build_pending_content(self):
        """Build pending confirmation content."""
        tool = self.tool
        if tool and hasattr(tool, "short_description"):
            yield Label(f"{tool.short_description}", classes="tool-description")

        if self.item.arguments:
            yield Label(_("Arguments:"), classes="arguments-label")
            arg_lines = []
            for key, value in self.item.arguments.items():
                arg_lines.append(f"  {key}: {value}")
            yield Label("\n".join(arg_lines), classes="arguments-list", markup=False)

        yield Label(
            _("[Space] Confirm  [Esc] Deny"), classes="action-hint", markup=False
        )
        with Horizontal(classes="action-buttons"):
            yield Button(_("✓ Confirm"), classes="confirm-button")
            yield Button(_("✗ Deny"), classes="deny-button")

    def _build_running_content(self):
        """Build running execution content."""
        yield Label(_("Executing..."), classes="progress-indicator")

        if self.item.arguments:
            key, val = next(iter(self.item.arguments.items()), (None, None))
            if key and val:
                yield Label(f"{key}: {val}", classes="arguments-section", markup=False)

    def _build_completed_content(self):
        """Build completed success content."""
        if self.item.result_summary:
            summary = self.item.result_summary
            if len(summary) > 80:
                summary = summary[:77] + "..."
            yield Label(f"{_('Output:')} {summary}", classes="result-meta")

    def _build_failed_content(self):
        """Build failed execution content."""
        if self.item.error:
            yield Label(f"{_('Error:')} {self.item.error}", classes="error-message")

    # Actions
    def action_confirm(self) -> None:
        """Handle Space key - confirm execution."""
        if self.item.status == WorkflowStatus.PENDING and self.on_confirm:
            self.on_confirm(self.item.call_id)

    def action_deny(self) -> None:
        """Handle Escape key - deny execution."""
        if self.item.status == WorkflowStatus.PENDING and self.on_deny:
            self.on_deny(self.item.call_id)

    def action_edit(self) -> None:
        """Handle 'e' key - edit arguments."""
        if self.item.status == WorkflowStatus.PENDING and self.on_edit:
            self.on_edit(self.item.call_id, self.item.arguments)

    def action_retry(self) -> None:
        """Handle 'r' key - retry execution."""
        if self.on_retry:
            self.on_retry(self.item.call_id, self.item.arguments)

    def action_toggle_collapsed(self) -> None:
        """Handle 'w' key - toggle collapse."""
        collapsible = self.query_one(Collapsible)
        if collapsible:
            collapsible.collapsed = not collapsible.collapsed

    @on(Button.Pressed, ".confirm-button")
    def _on_confirm_button(self, event: Button.Pressed) -> None:
        event.stop()
        self.action_confirm()

    @on(Button.Pressed, ".deny-button")
    def _on_deny_button(self, event: Button.Pressed) -> None:
        event.stop()
        self.action_deny()

    def update_status(
        self,
        status: WorkflowStatus,
        result_summary: str | None = None,
        error: str | None = None,
    ) -> None:
        """Update the widget state and refresh display.

        Note: WorkflowManager is the authoritative source for timestamps.
        This method acts as a fallback to ensure timestamps are set for
        items that may not have been updated through the manager (e.g.,
        direct widget updates or certain race conditions). Timestamps are
        only set if currently None to preserve manager-set values.

        Args:
            status: New workflow status.
            result_summary: Optional success summary.
            error: Optional error message.
        """
        if status == self._displayed_status:
            return

        self.item.status = status
        self._displayed_status = status
        if status == WorkflowStatus.RUNNING:
            if self.item.started_at is None:
                self.item.started_at = datetime.now()
        elif status in (WorkflowStatus.COMPLETED, WorkflowStatus.FAILED):
            if self.item.completed_at is None:
                self.item.completed_at = datetime.now()
            self.item.result_summary = result_summary
            self.item.error = error

        self._update_css_class()
        self._refresh_display()

        # Handle auto-collapse for completed items
        if status == WorkflowStatus.COMPLETED:
            self.item.widget_collapsed = True
            # Note: _refresh_display already set collapsible.collapsed based on status
            # This ensures widget_collapsed state is preserved for future recompositions

    def _update_css_class(self) -> None:
        """Update CSS class based on current status."""
        status_class_map = {
            WorkflowStatus.PENDING: "pending",
            WorkflowStatus.RUNNING: "running",
            WorkflowStatus.COMPLETED: "completed",
            WorkflowStatus.FAILED: "failed",
        }
        for cls in ("pending", "running", "completed", "failed"):
            self.remove_class(cls)
        if self.item.status in status_class_map:
            self.add_class(status_class_map[self.item.status])

    def _refresh_display(self) -> None:
        """Refresh title and inner content without full recompose."""
        try:
            collapsible = self.query_one(Collapsible)
            if collapsible:
                collapsible.title = self._build_title()
                collapsible.collapsed = self._resolve_collapsed()
                contents = collapsible.query_one("Contents")
                if contents:
                    contents.remove_children()
                    for child in self._build_inner_content():
                        contents.mount(child)
        except Exception:
            pass

    def on_mount(self) -> None:
        """Called when widget is mounted."""
        if self.item.status == WorkflowStatus.PENDING:
            self.call_next(self.focus)
        elif self.item.status in (WorkflowStatus.COMPLETED, WorkflowStatus.FAILED):
            # Ensure collapsed for completed/failed items if not already
            try:
                collapsible = self.query_one(Collapsible)
                collapsible.collapsed = True
            except Exception:
                pass
