"""Workflow progress panel widget for batch tool execution display.

Displays overall progress header + individual tool execution widgets
in a single-level structure (no nested collapsibles).
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING

from textual import events, on
from textual.app import ComposeResult
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Collapsible, Label, Static

from tinychat.models.workflow import WorkflowState, WorkflowStatus
from tinychat.components.tool_execution_widget import ToolExecutionWidget

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from tinychat.tools.base import Tool


class WorkflowProgressWidget(Static):
    """Workflow progress panel (embedded in ChatView).

    Shows a persistent summary header followed by a list of
    ToolExecutionWidget instances (one per tool call). No nested
    collapsibles - each tool manages its own expand/collapse state.
    """

    DEFAULT_CSS = """
    WorkflowProgressWidget {
        background: $panel;
        color: $foreground-muted;
        margin: 0 1;
        padding: 0 2;
        border: none;
        border-top: solid $border;
    }

    WorkflowProgressWidget.single-item {
        background: transparent;
        border: none;
        margin: 0;
        padding: 0;
    }

    WorkflowProgressWidget .summary-header {
        height: 1;
        width: 1fr;
        content-align: left middle;
        margin-bottom: 0;
        text-style: bold;
    }

    WorkflowProgressWidget .summary-header.all-done {
        color: $success;
        text-style: bold;
    }

    WorkflowProgressWidget .progress-bar {
        color: $primary;
        text-style: bold;
    }

    WorkflowProgressWidget.multi-item > ToolExecutionWidget {
        margin-left: 0;
    }

    WorkflowProgressWidget .batch-actions {
        margin-top: 0;
        color: $text-muted;
        text-style: italic;
    }
    """

    BINDINGS = [
        ("w", "toggle_all", "Toggle All"),
        ("r", "retry_failed", "Retry Failed"),
    ]

    # Reactive property to trigger updates
    _update_trigger: reactive[int] = reactive(0, init=False)

    def __init__(
        self,
        workflow_state: WorkflowState,
        tools: dict[str, "Tool"] | None = None,
        on_confirm: callable | None = None,
        on_deny: callable | None = None,
        on_edit: callable | None = None,
        on_retry: callable | None = None,
        read_only: bool = False,
        owner_message_index: int | None = None,
        **kwargs,
    ) -> None:
        """Initialize workflow progress widget.

        Args:
            workflow_state: The workflow state to display.
            tools: Optional dict of tool_name -> Tool instance (for execution).
            on_confirm: Confirmation callback (call_id -> bool).
            on_deny: Denial callback (call_id -> None).
            on_edit: Edit callback (call_id, arguments -> None).
            on_retry: Retry callback (call_id, arguments -> None).
            read_only: If True, disable all interactive bindings.
            owner_message_index: The message_index of the assistant message that
                owns this workflow. Used for virtual scroll tracking.
            **kwargs: Additional Textual widget arguments.
        """
        super().__init__(**kwargs)
        self.workflow_state = workflow_state
        self.tools = tools or {}
        self.on_confirm = on_confirm
        self.on_deny = on_deny
        self.on_edit = on_edit
        self.on_retry = on_retry
        self.read_only = read_only
        self.owner_message_index = owner_message_index
        if read_only:
            self.BINDINGS = []
        self._initialized = False
        self._all_expanded: bool = True
        self._last_update_time: float = 0.0
        self._last_state_hash: str = ""

    def on_mount(self) -> None:
        """Called when widget is mounted. Mark as initialized and sync display."""
        self._initialized = True
        existing_tools = list(self.query(ToolExecutionWidget))
        if existing_tools:
            self._set_classes_from_state()
            self._sync_existing_widget_status()
            self._last_state_hash = self._compute_state_hash()
            self._last_update_time = time.time()
            return
        self.update_display()
        self._last_state_hash = self._compute_state_hash()
        self._last_update_time = time.time()

    def _sync_existing_widget_status(self) -> None:
        """Sync existing widget _displayed_status with current state.

        This is needed when widgets were created in compose() but state changed
        before on_mount was called (race condition with call_next callbacks).
        """
        state_item_map = {item.call_id: item for item in self.workflow_state.items}
        for widget in self.query(ToolExecutionWidget):
            state_item = state_item_map.get(widget.item.call_id)
            if state_item and state_item.status != widget._displayed_status:
                widget.update_status(
                    status=state_item.status,
                    result_summary=state_item.result_summary,
                    error=state_item.error,
                )

    def _set_classes_from_state(self) -> None:
        if self.workflow_state.total == 1:
            self.add_class("single-item")
            self.remove_class("multi-item")
        else:
            self.add_class("multi-item")
            self.remove_class("single-item")

    def compose(self) -> ComposeResult:
        """Compose the widget UI."""
        yield from self._create_children()

    def _create_children(self) -> list[Widget]:
        """Build all child widgets.

        Returns:
            List of child widgets (header if batch, then tool widgets).
        """
        children: list[Widget] = []

        # Header for batch workflows (total > 1)
        if self.workflow_state.total > 1:
            children.append(self._build_header())

        # Tool execution widgets
        for item in self.workflow_state.items:
            tool = self.tools.get(item.tool_name)
            widget = ToolExecutionWidget(
                item=item,
                tool=tool,
                on_confirm=self.on_confirm,
                on_deny=self.on_deny,
                on_edit=self.on_edit,
                on_retry=self.on_retry,
                read_only=self.read_only,
            )
            # Store widget reference on item for later updates
            item.widget = widget  # type: ignore[attr-defined]
            children.append(widget)

        return children

    def _build_header(self) -> Label:
        """Build the persistent summary header."""
        completed = self.workflow_state.completed
        total = self.workflow_state.total
        bar = self.workflow_state.progress_bar

        if total == 0:
            title = "No tools queued"
        elif completed == total:
            title = f"✓ {completed}/{total} completed (100%)"
        else:
            summary = self.workflow_state.status_summary
            title = f"▼ {summary}"

        header = Label(f"{title}  {bar}", classes="summary-header")
        if completed == total:
            header.add_class("all-done")
        return header

    @on(events.Click, ".summary-header")
    def on_summary_header_click(self, event: events.Click) -> None:
        logger.debug("on_summary_header_click: _all_expanded=%s", self._all_expanded)
        event.stop()
        self.action_toggle_all()

    def update_display(self) -> None:
        """Update the display (called when state changes)."""
        logger.debug("update_display: _initialized=%s", self._initialized)
        if not self._initialized:
            return

        # Use batch update to minimize DOM operations
        with self.app.batch_update():
            self._update_display_internal()

    def _update_display_internal(self) -> None:
        """Internal implementation of display update."""
        # Update CSS classes
        if self.workflow_state.total == 1:
            self.add_class("single-item")
            self.remove_class("multi-item")
        else:
            self.add_class("multi-item")
            self.remove_class("single-item")

        # Get current widget IDs and state item IDs
        existing_widgets = list(self.query(ToolExecutionWidget))
        existing_widget_ids = {w.item.call_id for w in existing_widgets}
        state_item_ids = {item.call_id for item in self.workflow_state.items}

        # Map for quick lookup
        state_item_map = {item.call_id: item for item in self.workflow_state.items}

        # Add new items
        for item in self.workflow_state.items:
            if item.call_id not in existing_widget_ids:
                tool = self.tools.get(item.tool_name)
                widget = ToolExecutionWidget(
                    item=item,
                    tool=tool,
                    on_confirm=self.on_confirm,
                    on_deny=self.on_deny,
                    on_edit=self.on_edit,
                    on_retry=self.on_retry,
                    read_only=self.read_only,
                )
                item.widget = widget
                self.mount(widget)
                if item.status == WorkflowStatus.PENDING:
                    self.call_next(widget.focus)

        # Remove deleted items
        for widget in existing_widgets:
            if widget.item.call_id not in state_item_ids:
                widget.remove()

        # Update existing widgets
        for widget in self.query(ToolExecutionWidget):
            state_item = state_item_map.get(widget.item.call_id)
            if state_item:
                # Check if status has changed
                if state_item.status != widget._displayed_status:
                    widget.update_status(
                        status=state_item.status,
                        result_summary=state_item.result_summary,
                        error=state_item.error,
                    )
                # Also update widget reference on item
                state_item.widget = widget

        # Update header
        header = self.query_one_optional(".summary-header", Label)
        if self.workflow_state.total > 1:
            if header:
                completed = self.workflow_state.completed
                total = self.workflow_state.total
                bar = self.workflow_state.progress_bar

                if completed == total:
                    title = f"✓ {completed}/{total} completed (100%)"
                else:
                    summary = self.workflow_state.status_summary
                    title = f"▼ {summary}"

                header.update(f"{title}  {bar}")
                if completed == total:
                    header.add_class("all-done")
                else:
                    header.remove_class("all-done")
            else:
                new_header = self._build_header()
                tools = self.query(ToolExecutionWidget)
                if tools:
                    self.mount(new_header, before=tools.first())
                else:
                    self.mount(new_header)
        elif header:
            header.remove()

    def action_toggle_all(self) -> None:
        """Toggle collapse state of all tool widgets."""
        widgets = self.query(ToolExecutionWidget)
        logger.debug(
            "action_toggle_all: _all_expanded=%s, found %d ToolExecutionWidgets",
            self._all_expanded,
            len(widgets),
        )
        if not widgets:
            return

        collapsible_statuses = {
            WorkflowStatus.COMPLETED,
            WorkflowStatus.FAILED,
        }
        if self._all_expanded:
            for w in widgets:
                item = w.item
                if item.status in collapsible_statuses:
                    coll = w.query_one(Collapsible)
                    logger.debug(
                        "action_toggle_all: collapsing widget %s (status=%s)",
                        item.tool_name,
                        item.status,
                    )
                    coll.collapsed = True
            self._all_expanded = False
        else:
            for w in widgets:
                coll = w.query_one(Collapsible)
                logger.debug(
                    "action_toggle_all: expanding widget %s, collapsed_before=%s",
                    w.item.tool_name,
                    coll.collapsed,
                )
                coll.collapsed = False
            self._all_expanded = True

    def action_retry_failed(self) -> None:
        """Trigger retry for all failed items."""
        for item in self.workflow_state.items:
            if item.status == WorkflowStatus.FAILED and self.on_retry:
                self.on_retry(item.call_id, item.arguments)

    def _compute_state_hash(self) -> str:
        """Compute a hash of the current workflow state for change detection.

        Returns:
            A string hash representing the current state.
        """
        # Create a simple hash based on item counts and statuses
        items_info = []
        for item in self.workflow_state.items:
            items_info.append(
                f"{item.call_id}:{item.status.value}:{item.result_summary or ''}"
            )

        # Sort to ensure consistent ordering
        items_info.sort()

        # Include overall state
        state_info = f"total:{self.workflow_state.total}:completed:{self.workflow_state.completed}"

        return f"{state_info}|{','.join(items_info)}"

    def trigger_update(self) -> None:
        """Trigger an update with throttling and change detection."""
        current_time = time.time()
        current_hash = self._compute_state_hash()

        # Check if state has actually changed
        if current_hash == self._last_state_hash:
            logger.debug("trigger_update: state unchanged, skipping update")
            return

        # Throttle: only update if enough time has passed since last update
        if current_time - self._last_update_time < 0.1:  # 100ms throttle
            logger.debug(
                "trigger_update: throttling update (%.3fs since last)",
                current_time - self._last_update_time,
            )
            # Schedule a delayed update if not already scheduled
            if not hasattr(self, "_pending_update"):
                self._pending_update = True
                self.set_timer(0.1, self._delayed_update)
            return

        # Update the reactive property to trigger update
        self._update_trigger += 1
        self._last_state_hash = current_hash
        self._last_update_time = current_time

    def _delayed_update(self) -> None:
        """Handle delayed update after throttle period."""
        if hasattr(self, "_pending_update"):
            delattr(self, "_pending_update")
        self.trigger_update()

    def watch__update_trigger(self) -> None:
        """Watch for update trigger changes."""
        if self._initialized:
            logger.debug("watch__update_trigger: triggered update")
            self.update_display()

    def on_tool_execution_widget_updated(
        self, event: ToolExecutionWidget.Updated
    ) -> None:
        """Handle updates from child tool widgets."""
        self.trigger_update()
