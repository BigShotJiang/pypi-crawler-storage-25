"""Per-message widget classes for the ChatView.

Each message type (user, assistant, error, tool) is rendered as its own
widget instance, following the Textual best practice of using mount() for
incremental updates instead of rebuilding a single Markdown string.
"""

import logging
from typing import Any

from textual.widgets import Markdown, Static

from tinychat.models.message import Message, ToolCall
from tinychat.utils.i18n import _

logger = logging.getLogger(__name__)

MAX_ARGS_DISPLAY_LENGTH = 100


class UserMessageWidget(Markdown):
    """Displays a user message with distinct styling."""

    BORDER_TITLE = _("User")

    DEFAULT_CSS = """
    UserMessageWidget {
        background: $primary 8%;
        color: $text;
        margin: 0 1;
        padding: 1 2;
    }
    """

    def __init__(self, content: str, message_index: int = -1, **kwargs: Any) -> None:
        super().__init__(content, **kwargs)
        self.add_class("user-message")
        self.message_index = message_index


class AssistantMessageWidget(Markdown):
    """Displays an assistant message with distinct styling.

    Supports streaming via update() method for incremental content changes.
    """

    BORDER_TITLE = _("Assistant")

    DEFAULT_CSS = """
    AssistantMessageWidget {
        background: $surface;
        color: $text;
        margin: 0 1;
        padding: 1 2;
    }

    AssistantMessageWidget.empty-collapsed {
        height: 0;
        margin: 0;
        padding: 0;
        overflow: hidden;
    }
    """

    def __init__(self, content: str, message_index: int = -1, **kwargs: Any) -> None:
        super().__init__(content, **kwargs)
        self.add_class("assistant-message")
        self.message_index = message_index


class ErrorMessageWidget(Static):
    """Displays an error message with red styling."""

    DEFAULT_CSS = """
    ErrorMessageWidget {
        color: $error;
        background: $error 15%;
        margin: 0 1;
        padding: 1 2;
    }
    """

    def __init__(self, content: str, **kwargs: Any) -> None:
        prefix = f"[{_('Error')}] "
        super().__init__(prefix + content, **kwargs)
        self.add_class("error-message")


class ReasoningWidget(Static):
    """Displays reasoning/thinking content with muted styling."""

    DEFAULT_CSS = """
    ReasoningWidget {
        color: $foreground-muted;
        background: $surface;
        margin: 0 1;
        padding: 1 2;
        text-style: italic;
    }
    """

    def __init__(self, content: str, **kwargs: Any) -> None:
        thinking_label = _("Thinking")
        display_content = f"💭 {thinking_label}:\n{content}"
        super().__init__(display_content, markup=False, **kwargs)
        self.add_class("reasoning")


class ToolCallWidget(Static):
    """Displays a tool call card with tool name, arguments, and result content."""

    DEFAULT_CSS = """
    ToolCallWidget {
        background: $warning 8%;
        color: $foreground-muted;
        margin: 0 3;
        padding: 0 2;
    }
    """

    def __init__(
        self,
        tool_call: ToolCall,
        result_content: str | None = None,
        **kwargs: Any,
    ) -> None:
        content = self._render_tool_call(tool_call, result_content)
        super().__init__(content, markup=False, **kwargs)
        self.add_class("tool-call")

    @staticmethod
    def _render_tool_call(
        tool_call: ToolCall,
        result_content: str | None = None,
    ) -> str:
        args_str = ToolCallWidget._format_arguments(tool_call.arguments)
        parts = [f"{_('Tool:')} `{tool_call.name}`"]
        if args_str:
            truncated = (
                args_str
                if len(args_str) <= MAX_ARGS_DISPLAY_LENGTH
                else args_str[:MAX_ARGS_DISPLAY_LENGTH] + "..."
            )
            parts.append(truncated)
        if result_content:
            parts.append(f"\n{_('Result:')} {result_content}")
        return " ".join(parts)

    @staticmethod
    def _format_arguments(arguments: dict[str, Any]) -> str:
        if not arguments:
            return ""
        items = [f"{k}={repr(v)}" for k, v in arguments.items()]
        return ", ".join(items)


class WelcomeWidget(Markdown):
    """Displays the welcome message when chat is empty."""

    DEFAULT_CSS = """
    WelcomeWidget {
        color: $foreground-muted;
        margin: 2 4;
    }
    """

    def __init__(self, **kwargs: Any) -> None:
        content = (
            f"# {_('Welcome to TinyChat!')}\n\n"
            f"{_('Start a conversation by typing your message below.')}\n\n"
            f"*{_('Tips: Your chat history is saved automatically.')}*"
        )
        super().__init__(content, **kwargs)
        self.add_class("welcome-message")


def message_to_widget(
    message: Message, message_index: int | None = None
) -> Static | Markdown | list[Static | Markdown]:
    """Convert a Message data model to the appropriate widget instance.

    Args:
        message: The message to convert.
        message_index: Optional index to attach to the widget for identification.

    Returns:
        A widget instance (UserMessageWidget, AssistantMessageWidget, etc.).
        For assistant messages with reasoning_content, returns a list of widgets
        [ReasoningWidget, AssistantMessageWidget].
    """
    if message.role == "user":
        return UserMessageWidget(
            message.content,
            message_index=message_index if message_index is not None else -1,
        )
    if message.role == "error":
        return ErrorMessageWidget(message.content)
    if message.role == "tool":
        tool_call = ToolCall(
            id=message.tool_call_id or "",
            name=message.tool_name or "unknown",
            arguments=message.metadata.get("arguments", {}) if message.metadata else {},
        )
        return ToolCallWidget(tool_call=tool_call, result_content=message.content)

    if message.role == "assistant" and message.reasoning_content:
        reasoning_widget = ReasoningWidget(message.reasoning_content)
        content = message.content or ""
        assistant_widget = AssistantMessageWidget(
            content, message_index=message_index if message_index is not None else -1
        )
        return [reasoning_widget, assistant_widget]

    if message.tool_calls:
        content = message.content or ""
        return AssistantMessageWidget(
            content, message_index=message_index if message_index is not None else -1
        )
    return AssistantMessageWidget(
        message.content or "",
        message_index=message_index if message_index is not None else -1,
    )
