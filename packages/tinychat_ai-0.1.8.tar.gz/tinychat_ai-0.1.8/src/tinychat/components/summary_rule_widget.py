"""Summary rule widget for displaying context compression boundary.

This widget displays a horizontal rule with centered text indicating
that messages above have been summarized/condensed during context
compression operations.
"""

from datetime import datetime
from typing import Any

from textual.widgets import Static
from textual.app import RenderResult

from tinychat.utils.i18n import _


class SummaryRuleWidget(Static):
    """A widget that displays a horizontal rule with summary information.

    This widget is used to visually indicate where context compression
    has occurred, showing which messages have been summarized above
    this point.

    Example:
        # Create with default text
        widget = SummaryRuleWidget(message_count=10, summary_date="2024-03-15")

        # Create with custom text
        widget = SummaryRuleWidget(summary_text="Custom summary message")

        # Update existing widget
        widget.update_summary("Updated message")
    """

    DEFAULT_CSS = """
    SummaryRuleWidget {
        height: auto;
        margin: 1 0;
        padding: 0 2;
        content-align: center middle;
        color: $text-muted;
        text-style: dim;
    }

    SummaryRuleWidget .rule-line {
        color: $surface-lighten-2;
    }
    """

    def __init__(
        self,
        summary_text: str | None = None,
        message_count: int = 0,
        summary_date: str | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize the summary rule widget.

        Args:
            summary_text: Custom text to display. If None, a default
                message with message_count and summary_date is generated.
            message_count: Number of messages that were summarized.
            summary_date: Date when the summary was created.
            **kwargs: Additional arguments passed to Static.
        """
        super().__init__(**kwargs)
        self.add_class("summary-rule")

        if summary_text is not None:
            self.summary_text = summary_text
        else:
            # Use current date if not provided
            if summary_date is None:
                summary_date = datetime.now().strftime("%Y-%m-%d")

            self.summary_text = _(
                f"📝 Above content summarized ({message_count} messages, {summary_date})"
            )

    def render(self) -> RenderResult:
        """Render the widget with horizontal rule and centered text.

        Returns:
            A renderable object showing the rule with centered text.
        """
        return self.summary_text

    def update_summary(self, summary_text: str) -> None:
        """Update the summary text displayed by this widget.

        Args:
            summary_text: The new summary text to display.
        """
        self.summary_text = summary_text
        self.update(summary_text)
