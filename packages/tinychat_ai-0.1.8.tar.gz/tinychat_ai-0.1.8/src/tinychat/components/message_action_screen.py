"""Message context actions modal screen.

Provides a context menu for message-level actions:
- Fork: Create a new session from this assistant message
- Regenerate: Re-generate the last assistant response
- Delete: Remove a user message and all its replies
"""

from __future__ import annotations

from typing import ClassVar

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container
from textual.screen import ModalScreen
from textual.widgets import Button, Label

from tinychat.utils.i18n import _


class MessageActionScreen(ModalScreen[str | None]):
    """Modal screen for message context actions.

    Args:
        message_index: Index of the message in the ChatView.messages list.
        role: Role of the message ("user" or "assistant").
        is_last_assistant: Whether this is the last assistant message in the conversation.
    """

    BINDINGS: ClassVar[list] = [
        Binding("f", "fork", "", show=False),
        Binding("r", "regenerate", "", show=False),
        Binding("c", "copy_markdown", "", show=False),
        Binding("d", "delete", "", show=False),
        Binding("escape", "cancel", "", show=False),
    ]

    DEFAULT_CSS = """
    MessageActionScreen {
        align: center middle;
    }

    #message-action-dialog {
        width: 50;
        height: auto;
        border: thick $primary;
        background: $surface;
        padding: 1 2;
    }

    #message-action-title {
        text-style: bold;
        height: 1;
        margin-bottom: 1;
    }

    #message-action-buttons {
        height: auto;
        width: 100%;
        layout: vertical;
        align: center middle;
    }

    #message-action-buttons Button {
        margin: 0 1;
        min-width: 30;
        height: 3;
        padding: 0 1;
    }

    #message-action-hint {
        color: $text-muted;
        text-style: italic;
        height: 1;
        margin-top: 1;
        text-align: center;
    }
    """

    def __init__(
        self,
        message_index: int,
        role: str,
        is_last_assistant: bool = False,
        content: str = "",
    ) -> None:
        super().__init__()
        self.message_index = message_index
        self.role = role
        self.is_last_assistant = is_last_assistant
        self.content = content

    def compose(self) -> ComposeResult:
        with Container(id="message-action-dialog"):
            yield Label(_("Message Actions"), id="message-action-title")
            with Container(id="message-action-buttons"):
                # All buttons are yielded; visibility controlled in on_mount
                yield Button(_("Fork from here"), id="btn-fork")
                yield Button(_("Regenerate answer"), id="btn-regenerate")
                yield Button(_("Copy Markdown"), id="btn-copy-markdown")
                yield Button(_("Delete message"), id="btn-delete")
            yield Label(_("[Esc] Cancel"), id="message-action-hint")

    def on_mount(self) -> None:
        self._update_button_visibility()
        # Focus first visible button
        buttons = self.query("#message-action-buttons Button")
        for btn in buttons:
            if btn.display:
                btn.focus()
                break

    def _update_button_visibility(self) -> None:
        """Show/hide buttons based on message role and is_last_assistant."""
        btn_fork = self.query_one("#btn-fork", Button)
        btn_regenerate = self.query_one("#btn-regenerate", Button)
        btn_delete = self.query_one("#btn-delete", Button)

        # Fork: always shown for assistant messages
        if self.role == "assistant":
            btn_fork.display = True
        else:
            btn_fork.display = False

        # Regenerate: only for last assistant message
        if self.role == "assistant" and self.is_last_assistant:
            btn_regenerate.display = True
        else:
            btn_regenerate.display = False

        # Delete: only for user messages
        if self.role == "user":
            btn_delete.display = True
        else:
            btn_delete.display = False

        # Copy Markdown: for user or assistant messages
        if self.role in ("user", "assistant"):
            btn_copy_markdown = self.query_one("#btn-copy-markdown", Button)
            btn_copy_markdown.display = True
        else:
            btn_copy_markdown = self.query_one("#btn-copy-markdown", Button)
            btn_copy_markdown.display = False

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-fork":
            self.dismiss("fork")
        elif event.button.id == "btn-regenerate":
            self.dismiss("regenerate")
        elif event.button.id == "btn-delete":
            self.dismiss("delete")
        elif event.button.id == "btn-copy-markdown":
            self.dismiss("copy_markdown")

    def action_fork(self) -> None:
        self.dismiss("fork")

    def action_regenerate(self) -> None:
        self.dismiss("regenerate")

    def action_copy_markdown(self) -> None:
        self.dismiss("copy_markdown")

    def action_delete(self) -> None:
        self.dismiss("delete")

    def action_cancel(self) -> None:
        self.dismiss(None)
