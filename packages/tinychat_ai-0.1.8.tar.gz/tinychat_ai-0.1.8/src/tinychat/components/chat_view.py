"""ChatView component for displaying message history using Textual.

Uses per-message widget architecture: each message is rendered as its own
widget (UserMessageWidget, AssistantMessageWidget, etc.) mounted into a
VerticalScroll container. Streaming uses Markdown.get_stream() for efficient
incremental updates with automatic batching.
"""

import logging
from collections.abc import Callable
from dataclasses import replace

from textual import events, on
from textual.app import ComposeResult
from textual.binding import BindingsMap
from textual.containers import VerticalScroll
from textual.geometry import Size
from textual.reactive import reactive
from textual.widgets import Markdown, Static

from tinychat.components.message_widgets import (
    AssistantMessageWidget,
    UserMessageWidget,
    WelcomeWidget,
    message_to_widget,
)
from tinychat.components.summary_rule_widget import SummaryRuleWidget
from tinychat.components.tool_execution_widget import ToolExecutionWidget
from tinychat.components.workflow_progress_widget import WorkflowProgressWidget
from tinychat.models.message import Message
from tinychat.models.workflow import WorkflowItem, WorkflowState, WorkflowStatus
from tinychat.tools.base import Tool
from tinychat.utils.clipboard import copy_to_clipboard
from tinychat.utils.i18n import _
from tinychat.utils.workflow_reconstruction import reconstruct_workflow_batches


def _normalize_widgets(
    widget_or_list: Static | Markdown | list[Static | Markdown],
) -> list[Static | Markdown]:
    """Normalize message_to_widget output to always be a list."""
    if isinstance(widget_or_list, list):
        return widget_or_list
    return [widget_or_list]


logger = logging.getLogger(__name__)

_VIRTUAL_WINDOW_SIZE: int = 60
_VIRTUAL_BUFFER: int = 20
_WIDGET_HEIGHT_ESTIMATE: int = 3
_FALLBACK_VIEWPORT_HEIGHT: int = 24
_SCROLL_COOLDOWN_SECONDS: float = 0.05
_SCROLL_DELTA_THRESHOLD: int = 5
_AUTO_SCROLL_DEBOUNCE_SECONDS: float = 0.05
_AUTO_SCROLL_TOLERANCE: int = 3


class _OlderMessagesIndicator(Static):
    DEFAULT_CSS = """
    _OlderMessagesIndicator {
        color: $text-muted;
        text-align: center;
        padding: 0 1;
        height: 1;
        background: $surface-darken-1;
    }
    _OlderMessagesIndicator:hover {
        color: $text;
        background: $primary-darken-2;
    }
    """

    def __init__(self, hidden_count: int, **kwargs) -> None:
        super().__init__(
            _("↑ {count} older messages").format(count=hidden_count),
            **kwargs,
        )
        self._older_indicator = True
        self._hidden_count = hidden_count

    def on_click(self) -> None:
        try:
            chat_view = self.query_ancestor(ChatView)
            if chat_view._loading_older_in_progress:
                return
            chat_view._loading_older_in_progress = True
            chat_view.add_class("loading-older")
            chat_view._load_older_messages()
            chat_view.call_after_refresh(chat_view._finish_loading_older)
        except Exception:
            chat_view._loading_older_in_progress = False
            chat_view.remove_class("loading-older")


class ChatView(VerticalScroll):
    """Component to display chat message history.

    Each message is rendered as a separate widget instance, mounted
    incrementally into this VerticalScroll container. Streaming uses
    Markdown.get_stream() for efficient incremental Markdown rendering
    with automatic update coalescing.
    """

    DEFAULT_CSS = """
    ChatView {
        height: 1fr;
        scrollbar-color: $primary;
        scrollbar-color-hover: $primary-lighten-1;
        scrollbar-color-active: $primary-darken-1;
        scrollbar-background: $surface;
        scrollbar-size-vertical: 2;
    }
    ChatView.loading-older _OlderMessagesIndicator {
        opacity: 0.5;
    }
    """

    messages: reactive[list[Message]] = reactive(list)

    def __init__(self, messages: list[Message] | None = None, **kwargs):
        super().__init__(**kwargs)
        self._initial_messages = messages
        self._destroyed: bool = False
        self._streaming_content = ""
        self._active_stream: Markdown | None = None
        self._skip_tool_widget_rendering: bool = False
        self._scroll_timer = None
        self._virtual_mode: bool = False
        self._virtual_size: int = 0
        self._is_loading: bool = False
        self._loading_older_in_progress: bool = False
        self._virtual_window_size: int = _VIRTUAL_WINDOW_SIZE
        self._virtual_buffer: int = _VIRTUAL_BUFFER
        self._virtual_scroll_y: float = 0.0
        self._all_messages: list[Message] = []
        self._scroll_cooldown: bool = False

    def compose(self) -> ComposeResult:
        yield WelcomeWidget()

    def on_mount(self) -> None:
        if self._initial_messages:
            self._skip_watch = True
            try:
                self.load_messages(self._initial_messages)
            finally:
                self._skip_watch = False
        self.call_after_refresh(self.anchor)
        self._update_bindings_i18n()

    def watch_scroll_y(self, old_value: float, new_value: float) -> None:
        super().watch_scroll_y(old_value, new_value)
        if self._virtual_mode and round(old_value) != round(new_value):
            self._on_scroll_for_virtual()

    def _update_bindings_i18n(self) -> None:
        translated_descriptions = {
            "scroll_up": _("Scroll Up"),
            "scroll_down": _("Scroll Down"),
            "scroll_left": _("Scroll Left"),
            "scroll_right": _("Scroll Right"),
            "scroll_home": _("Scroll Home"),
            "scroll_end": _("Scroll End"),
            "page_up": _("Page Up"),
            "page_down": _("Page Down"),
            "page_left": _("Page Left"),
            "page_right": _("Page Right"),
        }
        new_bindings = BindingsMap()
        for key, binding in self._bindings:
            if binding.action in translated_descriptions:
                new_bindings.bind(
                    binding.key,
                    binding.action,
                    translated_descriptions[binding.action],
                    show=binding.show,
                )
            else:
                new_bindings.bind(
                    binding.key,
                    binding.action,
                    binding.description,
                    show=binding.show,
                )
        self._bindings = new_bindings

    def add_message(self, message: Message) -> None:
        """Mount a new message widget and update the messages reactive list.

        Args:
            message: The message to add.
        """
        welcome = self.query(WelcomeWidget)
        if welcome:
            welcome.remove()

        index = len(self.messages)
        widgets = _normalize_widgets(message_to_widget(message, message_index=index))
        self.mount_all(widgets)

        self._skip_watch = True
        try:
            self.messages = self.messages + [message]
        finally:
            self._skip_watch = False

        if self.should_auto_scroll():
            self.call_after_refresh(self.anchor)

    def update_last_assistant_message(self, content: str) -> None:
        """Update the content of the last AssistantMessageWidget (for streaming).

        Args:
            content: The new content to set on the last assistant widget.
        """
        if self._destroyed:
            return

        self._streaming_content = content

        assistant_widgets = self.query(AssistantMessageWidget)
        if not assistant_widgets:
            return

        last_widget = assistant_widgets[-1]
        last_widget.update(content)
        if not content:
            last_widget.add_class("empty-collapsed")
        else:
            last_widget.remove_class("empty-collapsed")

        self._skip_watch = True
        try:
            if self.messages:
                updated = replace(self.messages[-1], content=content)
                self.messages = self.messages[:-1] + [updated]
        finally:
            self._skip_watch = False

        if self.should_auto_scroll():
            self.call_after_refresh(self.anchor)

    def load_messages(self, messages: list[Message]) -> None:
        """Replace all displayed messages (used for session switching).

        Clears all children and mounts widgets for the given messages.
        Tool result messages are rendered as WorkflowProgressWidget (read-only)
        to match the live execution appearance.

        Args:
            messages: The messages to display.
        """
        self._streaming_content = ""
        self._active_stream = None
        self._is_streaming = False
        self._all_messages = list(messages)
        self.remove_children()

        if messages:
            widgets_to_mount: list = []
            tool_call_ids = self._collect_tool_call_ids(messages)
            idx = 0
            while idx < len(messages):
                msg = messages[idx]
                if msg.role == "tool" and msg.tool_call_id in tool_call_ids:
                    idx += 1
                    continue
                widgets = _normalize_widgets(message_to_widget(msg, message_index=idx))
                widgets_to_mount.extend(widgets)

                if msg.role == "assistant" and msg.tool_calls:
                    batch = self._collect_tool_messages(messages, idx, tool_call_ids)
                    if batch:
                        state = self._build_readonly_workflow_state(
                            messages, idx, batch
                        )
                        if state and state.items:
                            wf_widget = WorkflowProgressWidget(
                                workflow_state=state,
                                read_only=True,
                                owner_message_index=idx,
                            )
                            widgets_to_mount.append(wf_widget)

                idx += 1
            self.mount_all(widgets_to_mount)
        else:
            self.mount(WelcomeWidget())

        self._skip_watch = True
        try:
            self.messages = list(messages)
        finally:
            self._skip_watch = False

        self.call_after_refresh(self.scroll_end, animate=False)

    @staticmethod
    def _collect_tool_call_ids(messages: list[Message]) -> set[str]:
        ids: set[str] = set()
        for msg in messages:
            if msg.role == "assistant" and msg.tool_calls:
                for tc in msg.tool_calls:
                    ids.add(tc.id)
        return ids

    @staticmethod
    def _collect_tool_messages(
        messages: list[Message],
        assistant_idx: int,
        tool_call_ids: set[str],
    ) -> list[Message]:
        batch: list[Message] = []
        for i in range(assistant_idx + 1, len(messages)):
            msg = messages[i]
            if msg.role != "tool":
                break
            if msg.tool_call_id not in tool_call_ids:
                break
            batch.append(msg)
        return batch

    @staticmethod
    def _build_readonly_workflow_state(
        messages: list[Message],
        assistant_idx: int,
        tool_messages: list[Message],
    ) -> WorkflowState | None:

        subset: list[Message] = [
            messages[assistant_idx],
        ] + tool_messages
        batches = reconstruct_workflow_batches(subset)
        return batches[0] if batches else None

    def clear_messages(self) -> None:
        """Remove all message widgets and show the welcome message."""
        self.remove_children()
        self.mount(WelcomeWidget())

        self._skip_watch = True
        try:
            self.messages = []
        finally:
            self._skip_watch = False

    def _build_message_widgets(
        self, messages: list[Message], start_index: int = 0
    ) -> list:
        """Build widget list from messages with tool call handling.

        This method handles the logic for rendering tool result messages
        as WorkflowProgressWidget instead of individual tool messages.
        It also inserts SummaryRuleWidget when encountering summary messages.

        Args:
            messages: List of messages to convert to widgets.
            start_index: Starting index for message_index property.

        Returns:
            List of widgets to mount.
        """
        widgets_to_mount: list = []
        tool_call_ids = self._collect_tool_call_ids(messages)
        idx = 0
        while idx < len(messages):
            msg = messages[idx]

            # Handle summary message: insert SummaryRuleWidget instead of rendering
            if msg.metadata.get("summary"):
                summarized_count = msg.metadata.get("summarized_count", 0)
                summary_date = None
                if msg.timestamp:
                    ts = msg.timestamp
                    if isinstance(ts, str):
                        from datetime import datetime

                        ts = datetime.fromisoformat(ts)
                    summary_date = ts.strftime("%Y-%m-%d")
                summary_widget = SummaryRuleWidget(
                    message_count=summarized_count,
                    summary_date=summary_date,
                )
                widgets_to_mount.append(summary_widget)
                if msg.content:
                    widgets = _normalize_widgets(
                        message_to_widget(msg, message_index=start_index + idx)
                    )
                    widgets_to_mount.extend(widgets)
                idx += 1
                continue

            # Skip compaction notification messages (not user-visible)
            if msg.metadata.get("compaction_notification"):
                idx += 1
                continue

            if msg.role == "tool" and msg.tool_call_id in tool_call_ids:
                idx += 1
                continue
            widgets = _normalize_widgets(
                message_to_widget(msg, message_index=start_index + idx)
            )
            widgets_to_mount.extend(widgets)

            if msg.role == "assistant" and msg.tool_calls:
                batch = self._collect_tool_messages(messages, idx, tool_call_ids)
                if batch:
                    state = self._build_readonly_workflow_state(messages, idx, batch)
                    if state and state.items:
                        wf_widget = WorkflowProgressWidget(
                            workflow_state=state,
                            read_only=True,
                            owner_message_index=start_index + idx,
                        )
                        widgets_to_mount.append(wf_widget)

            idx += 1
        return widgets_to_mount

    # =============================================================================
    # Progressive loading API
    # =============================================================================

    def show_loading_placeholder(self) -> None:
        """Display a loading placeholder while session loads."""
        self.remove_children()
        self._is_loading = True
        loading_widget = Static("Loading session...", classes="loading-indicator")
        self.mount(loading_widget)
        self.refresh()

    def remove_loading_placeholder(self) -> None:
        """Remove the loading placeholder if present."""
        self._is_loading = False
        for child in list(self.children):
            if "loading-indicator" in child.classes:
                child.remove()

    def set_messages(
        self,
        messages: list[Message],
        initial_visible_count: int | None = None,
    ) -> None:
        """Replace all displayed messages with the given messages.

        In virtual mode, only the visible window is rendered.
        All messages are stored in _all_messages for virtual scrolling.

        Args:
            messages: List of Message objects to display.
            initial_visible_count: In virtual mode, only render the last N messages
                initially. Must be set when messages is the full list but only a
                tail window should be displayed (e.g., session restore).
        """
        self.remove_children()
        self._is_loading = False
        self._streaming_content = ""
        self._active_stream = None
        self._is_streaming = False
        self._all_messages = list(messages)

        if messages:
            if self._virtual_mode and initial_visible_count is not None:
                visible_count = min(initial_visible_count, len(messages))
                start_idx = len(messages) - visible_count
                start_idx, _ = self._adjust_range_for_tool_groups(
                    start_idx, len(messages) - 1
                )
                window_messages = messages[start_idx:]
                self._virtual_scroll_y = 0.0
                widgets_to_mount = self._build_message_widgets(
                    window_messages, start_index=start_idx
                )
                self.mount_all(widgets_to_mount)
                logger.debug(
                    "[VIRTUAL] set_messages: %d total, rendering tail window [%d:%d]",
                    len(messages),
                    start_idx,
                    len(messages) - 1,
                )
            elif self._virtual_mode and len(messages) > self._virtual_window_size:
                visible_range = self._visible_range
                adj_start, adj_end = self._adjust_range_for_tool_groups(
                    visible_range[0], visible_range[1]
                )
                window_messages = messages[adj_start : adj_end + 1]
                widgets_to_mount = self._build_message_widgets(
                    window_messages, start_index=adj_start
                )
                self.mount_all(widgets_to_mount)
                logger.debug(
                    "[VIRTUAL] set_messages: %d total, rendering window %s",
                    len(messages),
                    (adj_start, adj_end),
                )
            else:
                widgets_to_mount = self._build_message_widgets(messages)
                self.mount_all(widgets_to_mount)
        else:
            self.mount(WelcomeWidget())

        self._skip_watch = True
        try:
            self.messages = list(messages)
        finally:
            self._skip_watch = False
        self.refresh(layout=True)

    def append_messages(self, messages: list[Message]) -> None:
        """Append messages to the existing display.

        Args:
            messages: List of Message objects to append.
        """
        if not messages:
            return

        self._is_loading = False
        start_index = len(self.messages)

        # Build widgets for new messages with tool call handling
        widgets_to_mount = self._build_message_widgets(messages, start_index)
        self.mount_all(widgets_to_mount)

        self._skip_watch = True
        try:
            self.messages = self.messages + messages
        finally:
            self._skip_watch = False
        self.refresh(layout=False)

    def set_virtual_size(self, size: int) -> None:
        """Set the virtual size for virtual scrolling.

        Args:
            size: Total number of messages (or virtual units).
        """
        self._virtual_size = size
        widget_height = self._get_widget_height_estimate()
        vs = self.virtual_size
        current_width = vs.width if hasattr(vs, "height") and vs.width > 0 else 0
        self.virtual_size = Size(current_width, size * widget_height)

    @property
    def virtual_mode(self) -> bool:
        """Check if virtual scrolling mode is enabled."""
        return self._virtual_mode

    @property
    def is_loading(self) -> bool:
        """Check if the chat view is currently loading."""
        return self._is_loading

    def _get_widget_height_estimate(self) -> int:
        """Estimate the height of a single message widget in rows.

        Uses measured heights from visible widgets if available,
        otherwise falls back to the default estimate.
        """
        measured_heights = []
        for w in self.children:
            if hasattr(w, "message_index") and w.display:
                height = getattr(w, "size", None)
                if height and hasattr(height, "height"):
                    measured_heights.append(height.height)

        if measured_heights:
            avg = sum(measured_heights) / len(measured_heights)
            return max(_WIDGET_HEIGHT_ESTIMATE, int(avg))

        return _WIDGET_HEIGHT_ESTIMATE

    @property
    def _visible_range(self) -> tuple[int, int]:
        """Compute the (start, end) index range of messages visible in the viewport.

        Returns:
            Tuple of (start_index, end_index) inclusive range.
        """
        if not self._virtual_mode or self._virtual_size == 0:
            return (0, len(self._all_messages) - 1)

        widget_height = self._get_widget_height_estimate()
        viewport_height = (
            self.size.height if self.size.height > 0 else _FALLBACK_VIEWPORT_HEIGHT
        )
        visible_count = max(1, viewport_height // widget_height)

        scroll_y = self._virtual_scroll_y
        max_scroll = max(1, (self._virtual_size - visible_count) * widget_height)
        scroll_ratio = (
            min(1.0, max(0.0, scroll_y / max_scroll)) if max_scroll > 0 else 0.0
        )

        center_index = int(scroll_ratio * max(0, self._virtual_size - 1))
        half_window = self._virtual_window_size // 2

        start = max(0, center_index - half_window - self._virtual_buffer)
        end = min(
            self._virtual_size - 1, center_index + half_window + self._virtual_buffer
        )

        return (start, end)

    def _on_scroll_for_virtual(self) -> None:
        """Handle scroll events in virtual mode to dynamically load/unload widgets."""
        if not self._virtual_mode or not self._all_messages or self._scroll_cooldown:
            return

        self._scroll_cooldown = True
        self.set_timer(_SCROLL_COOLDOWN_SECONDS, self._clear_scroll_cooldown)

        new_scroll_y = float(self.scroll_y)
        if abs(new_scroll_y - self._virtual_scroll_y) < _SCROLL_DELTA_THRESHOLD:
            return

        self._virtual_scroll_y = new_scroll_y
        new_range = self._compute_scroll_range()

        if not new_range:
            return

        visible_indices = {
            getattr(w, "message_index", -1)
            for w in self.children
            if hasattr(w, "message_index")
        }
        current_start = min(visible_indices) if visible_indices else 0
        current_end = max(visible_indices) if visible_indices else 0
        old_range = (current_start, current_end)

        if old_range == new_range:
            return

        logger.debug(
            "[VIRTUAL] scroll_y=%.0f range: %s -> %s (total: %d, children: %d)",
            new_scroll_y,
            old_range,
            new_range,
            len(self._all_messages),
            len(self.children),
        )

        self._render_virtual_window(new_range)

    def _compute_scroll_range(self) -> tuple[int, int] | None:
        """Compute visible message range based on current scroll position.

        Uses the actual scroll_y relative to max_scroll_y to determine where
        in the full message list the viewport is, then expands with buffer.
        """
        if not self._virtual_mode or not self._all_messages:
            return None

        total = len(self._all_messages)
        if total <= self._virtual_window_size:
            return (0, total - 1)

        widget_height = self._get_widget_height_estimate()
        viewport_height = (
            self.size.height if self.size.height > 0 else _FALLBACK_VIEWPORT_HEIGHT
        )

        max_scroll_y = max(1.0, float(self.max_scroll_y))
        scroll_ratio = (
            min(1.0, max(0.0, self._virtual_scroll_y / max_scroll_y))
            if max_scroll_y > 0
            else 0.0
        )

        visible_count = max(1, viewport_height // widget_height)
        half_window = self._virtual_window_size // 2

        scrollable_slots = max(1, total - visible_count)
        center_index = int(scroll_ratio * scrollable_slots)

        start = max(0, center_index - half_window - self._virtual_buffer)
        end = min(total - 1, center_index + half_window + self._virtual_buffer)

        return (start, end)

    def _clear_scroll_cooldown(self) -> None:
        self._scroll_cooldown = False

    def _sync_virtual_scroll(self) -> None:
        """Synchronize _virtual_scroll_y with actual scroll position."""
        self._virtual_scroll_y = float(self.scroll_y)

    def _update_older_messages_indicator(self) -> None:
        if not self._virtual_mode or not self._all_messages:
            return
        visible_indices = {
            getattr(w, "message_index", -1)
            for w in self.children
            if hasattr(w, "message_index")
        }
        min_visible = min(visible_indices) if visible_indices else 0
        hidden_count = min_visible
        for child in list(self.children):
            if getattr(child, "_older_indicator", False):
                child.remove()
        if hidden_count > 0:
            indicator = _OlderMessagesIndicator(hidden_count)
            first_child = self.children[0] if self.children else None
            if first_child:
                self.mount(indicator, before=first_child)
            else:
                self.mount(indicator)

    def _finish_loading_older(self) -> None:
        self._loading_older_in_progress = False
        self.remove_class("loading-older")

    def _load_older_messages(self) -> None:
        if not self._virtual_mode or not self._all_messages:
            return
        visible_indices = {
            getattr(w, "message_index", -1)
            for w in self.children
            if hasattr(w, "message_index")
        }
        min_visible = min(visible_indices) if visible_indices else 0
        if min_visible <= 0:
            return
        batch = min(min_visible, _VIRTUAL_WINDOW_SIZE)
        new_start = max(0, min_visible - batch)
        new_end = self._compute_current_max_visible(visible_indices)
        new_start, new_end = self._adjust_range_for_tool_groups(new_start, new_end)
        self._render_virtual_window((new_start, new_end))

    def _compute_current_max_visible(
        self, visible_indices: set[int] | None = None
    ) -> int:
        if visible_indices is None:
            visible_indices = {
                getattr(w, "message_index", -1)
                for w in self.children
                if hasattr(w, "message_index")
            }
        return max(visible_indices) if visible_indices else len(self._all_messages) - 1

    def _find_assistant_for_tool(self, tool_idx: int) -> int | None:
        """Find the assistant message index that owns a tool message.

        Scans backwards from tool_idx to find the preceding assistant
        message whose tool_calls contain this tool's tool_call_id.

        Args:
            tool_idx: Index of the tool message in _all_messages.

        Returns:
            The assistant message index, or None if not found.
        """
        msg = self._all_messages[tool_idx]
        if msg.role != "tool" or not msg.tool_call_id:
            return None
        for i in range(tool_idx - 1, -1, -1):
            m = self._all_messages[i]
            if m.role == "assistant" and m.tool_calls:
                if any(tc.id == msg.tool_call_id for tc in m.tool_calls):
                    return i
            if m.role in ("user", "assistant"):
                break
        return None

    def _adjust_range_for_tool_groups(
        self, start_idx: int, end_idx: int
    ) -> tuple[int, int]:
        """Expand range boundaries so tool messages are never rendered
        without their owning assistant message.

        Args:
            start_idx: Start of the desired range.
            end_idx: End of the desired range.

        Returns:
            Adjusted (start_idx, end_idx).
        """
        total = len(self._all_messages)
        adjusted_start = start_idx
        adjusted_end = end_idx

        if adjusted_start > 0 and adjusted_start < total:
            msg = self._all_messages[adjusted_start]
            if msg.role == "tool" and msg.tool_call_id:
                assistant_idx = self._find_assistant_for_tool(adjusted_start)
                if assistant_idx is not None:
                    adjusted_start = min(adjusted_start, assistant_idx)

        if adjusted_end < total - 1:
            msg = self._all_messages[adjusted_end]
            if msg.role == "assistant" and msg.tool_calls:
                tool_call_ids = {tc.id for tc in msg.tool_calls}
                for i in range(adjusted_end + 1, total):
                    m = self._all_messages[i]
                    if m.role == "tool" and m.tool_call_id in tool_call_ids:
                        adjusted_end = max(adjusted_end, i)
                    else:
                        break

        return (adjusted_start, adjusted_end)

    def _get_or_create_widget(
        self, index: int, message: Message
    ) -> list[Static | Markdown]:
        """Get or create widget(s) for the given message index.

        Each message index has its own persistent widget instance.
        When not in viewport, the widget is hidden (display=False).
        When back in viewport, the same widget instance is shown again.

        Args:
            index: The message index.
            message: The message to display.

        Returns:
            A list of widget instances ready to be shown.
            For messages with reasoning_content, returns [ReasoningWidget, AssistantMessageWidget].
        """
        import logging

        logger = logging.getLogger(__name__)

        # Look for existing widget with matching index
        for w in self.children:
            if hasattr(w, "message_index") and w.message_index == index:
                logger.debug(
                    f"_get_or_create_widget: Found existing widget for index {index}, display={w.display}"
                )
                if not w.display:
                    w.display = True
                    logger.debug(
                        f"_get_or_create_widget: Showed widget for index {index}"
                    )
                # Return list for consistency - caller will handle list
                return [w]

        # Create new widget if no existing one found
        logger.debug(f"_get_or_create_widget: Creating new widget for index {index}")
        widgets = _normalize_widgets(message_to_widget(message, message_index=index))
        return widgets

    def _render_virtual_window(self, visible_range: tuple[int, int]) -> None:
        """Render only the messages within the visible range.

        Uses widget reuse pool: hides widgets instead of removing them,
        and reuses hidden widgets when scrolling back.

        Args:
            visible_range: (start_index, end_index) of messages to render.
        """
        start_idx, end_idx = visible_range
        if start_idx < 0 or end_idx < start_idx:
            return

        start_idx, end_idx = self._adjust_range_for_tool_groups(start_idx, end_idx)

        visible_indices = {
            getattr(w, "message_index", -1)
            for w in self.children
            if hasattr(w, "message_index")
        }
        needed_indices = set(range(start_idx, end_idx + 1))

        to_hide = visible_indices - needed_indices
        to_add_indices = sorted(needed_indices - visible_indices)

        prepending_above = False
        if to_add_indices:
            min_visible = min(visible_indices) if visible_indices else -1
            min_to_add = min(to_add_indices)
            if min_to_add < min_visible:
                prepending_above = True

        old_scroll_y = float(self.scroll_y)

        # Hide widgets that are no longer needed
        for idx in to_hide:
            for w in list(self.children):
                if getattr(w, "message_index", -1) == idx:
                    w.display = False
                    break

        # Hide WorkflowProgressWidgets whose owner is no longer visible
        # Use owner_message_index instead of sibling-based calculation
        for w in list(self.children):
            if isinstance(w, WorkflowProgressWidget):
                owner_idx = getattr(w, "owner_message_index", None)
                if owner_idx is not None and owner_idx not in needed_indices:
                    w.display = False

        # Show widgets that are needed but currently hidden
        for idx in needed_indices:
            for w in self.children:
                if getattr(w, "message_index", -1) == idx:
                    if not w.display:
                        w.display = True
                    break

        # Show WorkflowProgressWidgets whose owner is now visible
        for w in self.children:
            if isinstance(w, WorkflowProgressWidget) and not w.display:
                owner_idx = getattr(w, "owner_message_index", None)
                if owner_idx is not None and owner_idx in needed_indices:
                    w.display = True

        # Remove widgets that are far outside the visible range.
        # We hide widgets instead of removing them for reuse, but we still remove
        # widgets that are far outside the current visible range to keep the DOM clean.
        # Use a symmetric buffer to maximize widget reuse during scrolling in both directions.
        buffer_before = self._virtual_window_size + self._virtual_buffer * 3
        buffer_after = self._virtual_window_size + self._virtual_buffer * 3
        min_keep = max(0, start_idx - buffer_before)
        max_keep = min(len(self._all_messages) - 1, end_idx + buffer_after)
        indices_to_keep = set(range(min_keep, max_keep + 1))

        for w in list(self.children):
            if hasattr(w, "message_index"):
                idx = w.message_index
                if idx not in indices_to_keep:
                    w.remove()
            elif isinstance(w, WorkflowProgressWidget):
                owner_idx = getattr(w, "owner_message_index", None)
                if owner_idx is not None and owner_idx not in indices_to_keep:
                    w.remove()

        if to_add_indices:
            messages_by_index = {i: self._all_messages[i] for i in to_add_indices}
            tool_call_ids = self._collect_tool_call_ids(self._all_messages)
            widgets_to_mount: list = []

            for idx in to_add_indices:
                msg = messages_by_index[idx]
                if msg.role == "tool" and msg.tool_call_id in tool_call_ids:
                    continue

                widgets = self._get_or_create_widget(idx, msg)
                # Only mount if widget is not already in DOM
                for widget in widgets:
                    if widget not in self.children:
                        widgets_to_mount.append((idx, widget))

                if msg.role == "assistant" and msg.tool_calls:
                    batch = self._collect_tool_messages(
                        self._all_messages, idx, tool_call_ids
                    )
                    if batch:
                        state = self._build_readonly_workflow_state(
                            self._all_messages, idx, batch
                        )
                        if state and state.items:
                            # Try to reuse existing WorkflowProgressWidget with same owner
                            wf_widget = None
                            for w in self.children:
                                if (
                                    isinstance(w, WorkflowProgressWidget)
                                    and not w.display
                                    and getattr(w, "owner_message_index", None) == idx
                                ):
                                    wf_widget = w
                                    wf_widget.workflow_state = state
                                    wf_widget.display = True
                                    break
                            if wf_widget is None:
                                wf_widget = WorkflowProgressWidget(
                                    workflow_state=state,
                                    read_only=True,
                                    owner_message_index=idx,
                                )
                            # Only mount if not already in children
                            if wf_widget not in self.children:
                                widgets_to_mount.append((idx, wf_widget))

            widgets_to_mount.sort(key=lambda x: x[0])

            for mount_idx, widget in widgets_to_mount:
                insert_before = None
                # For WorkflowProgressWidget, use mount_idx (owner's index) for position
                widget_mount_idx = mount_idx
                for child in self.children:
                    child_idx = getattr(child, "message_index", -1)
                    if child_idx >= 0 and child_idx > widget_mount_idx:
                        insert_before = child
                        break

                if insert_before is not None:
                    self.mount(widget, before=insert_before)
                else:
                    self.mount(widget)

        self.refresh(layout=False)

        if prepending_above:
            # Calculate added content height for more precise scroll restoration
            added_count = len(to_add_indices)
            estimated_added_height = added_count * self._get_widget_height_estimate()

            # Directly adjust scroll_y instead of relying on _restore_position
            target_y = old_scroll_y + estimated_added_height
            self.scroll_to(y=target_y, animate=False, immediate=True)
            self._virtual_scroll_y = target_y
            self._update_older_messages_indicator()
        else:
            self._update_older_messages_indicator()

    def enable_virtual_mode(self, enable: bool) -> None:
        """Enable or disable virtual scrolling mode.

        When disabled, all messages from _all_messages are restored.

        Args:
            enable: True to enable virtual scrolling, False to disable.
        """
        was_virtual = self._virtual_mode
        self._virtual_mode = enable

        if was_virtual and not enable and self._all_messages:
            self._virtual_scroll_y = 0.0
            self.remove_children()
            widgets = self._build_message_widgets(self._all_messages)
            self.mount_all(widgets)
            self.refresh(layout=True)
            logger.debug(
                "[VIRTUAL] exited virtual mode, restored %d widgets",
                len(self._all_messages),
            )

    def mark_messages_compressed(self, messages: list[Message]) -> None:
        """Update messages with compression metadata without triggering UI rebuild.

        This method is used after context compaction to update the internal
        messages list with compressed flags, without triggering watch_messages
        which would cause a full UI rebuild and scroll to bottom.

        Args:
            messages: The updated messages list with compression metadata.
        """
        self._skip_watch = True
        try:
            self.messages = list(messages)
        finally:
            self._skip_watch = False

    # =========================================================================
    # Backward compatibility API (used by existing tests and app_textual.py)
    # =========================================================================

    _skip_watch: bool = False

    def should_auto_scroll(self) -> bool:
        if self.max_scroll_y == 0:
            return True
        tolerance = _AUTO_SCROLL_TOLERANCE
        return (self.max_scroll_y - self.scroll_y) <= tolerance

    def scroll_to_bottom(self) -> None:
        """Scroll to the bottom of the chat view.

        Deprecated: Use ``self.scroll_end(animate=False)`` or
        ``self.call_after_refresh(self.anchor)`` instead.
        """
        self.scroll_end(animate=False)

    def scroll_to_widget_top(self, message_index: int) -> None:
        for widget in self.children:
            if getattr(widget, "message_index", None) == message_index:
                target_y = widget.virtual_region.y
                self.scroll_to(
                    x=self.scroll_x,
                    y=target_y,
                    animate=False,
                    immediate=True,
                )
                return
        logger.debug(
            "scroll_to_widget_top: no widget found for message_index=%d",
            message_index,
        )

    def _format_messages(self) -> str:
        lines = []
        for i, message in enumerate(self.messages):
            if i > 0:
                lines.append("")
                lines.append("---")
                lines.append("")
            if message.role == "user":
                lines.append(f"**{_('User:')}**")
                lines.append(message.content)
            elif message.role == "tool":
                lines.append(f"> **{_('Result:')}** `{message.tool_name or 'unknown'}`")
                if message.content:
                    lines.append("> ```")
                    for line in message.content.split("\n"):
                        lines.append(f"> {line}")
                    lines.append("> ```")
            else:
                lines.append(f"**{_('Assistant:')}**")
                if message.content:
                    lines.append(message.content)
        return "\n".join(lines)

    def _format_welcome_message(self) -> str:
        return (
            f"# {_('Welcome to TinyChat!')}\n\n"
            f"{_('Start a conversation by typing your message below.')}\n\n"
            f"*{_('Tips: Your chat history is saved automatically.')}*"
        )

    def _can_update(self) -> bool:
        try:
            return self.app is not None and self.is_mounted
        except (AttributeError, RuntimeError):
            return False

    # =========================================================================
    # Reactive watcher - incremental diffing
    # =========================================================================

    def watch_messages(
        self,
        old_messages: list[Message],
        new_messages: list[Message],
    ) -> None:
        if getattr(self, "_skip_watch", False):
            return
        if not self._can_update():
            return

        if len(new_messages) < len(old_messages) or (
            len(new_messages) == 0 and len(old_messages) > 0
        ):
            self.load_messages(new_messages)
            return

        new_count = len(new_messages) - len(old_messages)
        if new_count > 0:
            welcome = self.query(WelcomeWidget)
            if welcome:
                welcome.remove()
            delta_messages = new_messages[len(old_messages) :]
            start_index = len(old_messages)

            if self._skip_tool_widget_rendering:
                for i, msg in enumerate(delta_messages):
                    if msg.role == "tool":
                        continue
                    widgets = _normalize_widgets(
                        message_to_widget(msg, message_index=start_index + i)
                    )
                    self.mount_all(widgets)
            else:
                widgets_to_mount = self._build_message_widgets(
                    delta_messages, start_index
                )
                self.mount_all(widgets_to_mount)

            if self.should_auto_scroll():
                self.call_after_refresh(self.anchor)

    # =========================================================================
    # Lifecycle
    # =========================================================================

    def destroy(self) -> None:
        self._destroyed = True
        if self._scroll_timer is not None:
            self._scroll_timer.stop()
            self._scroll_timer = None
        if self._active_stream and self._active_stream._task is not None:
            self._active_stream._task.cancel()
        self._active_stream = None
        self._streaming_content = ""
        self._is_streaming = False

    # =========================================================================
    # Streaming API (MarkdownStream-based)
    # =========================================================================

    def start_streaming(self) -> None:
        """Initialize streaming state.

        Note: The actual MarkdownStream is created lazily on first append
        to support cases where the assistant widget is added after calling
        start_streaming().
        """
        self._streaming_content = ""
        self._is_streaming = True
        self._active_stream = None  # Will be created on first token
        if self._scroll_timer is not None:
            self._scroll_timer.stop()
            self._scroll_timer = None
        logger.debug("Streaming state initialized")

    async def append_stream_token(self, token: str) -> None:
        """Append a token delta to the last AssistantMessageWidget during streaming.

        Uses MarkdownStream.write() which automatically coalesces rapid updates
        for optimal performance. This should be called from a worker.

        Args:
            token: The delta token to append.
        """
        if self._destroyed:
            return

        self._streaming_content += token

        # Lazy stream creation: find widget and create stream if needed
        if not self._active_stream:
            assistant_widgets = self.query(AssistantMessageWidget)
            if assistant_widgets:
                last_widget = assistant_widgets[-1]
                last_widget.remove_class("empty-collapsed")
                self._active_stream = Markdown.get_stream(last_widget)
                logger.debug("MarkdownStream created for %s", last_widget.id)

        # Write to stream (async, automatically batches)
        if self._active_stream:
            await self._active_stream.write(token)

        # Auto-scroll if at bottom (debounced)
        self._schedule_auto_scroll()

    def _schedule_auto_scroll(self) -> None:
        """Schedule a debounced auto-scroll check."""
        if self._scroll_timer is not None:
            self._scroll_timer.stop()
        self._scroll_timer = self.set_timer(
            _AUTO_SCROLL_DEBOUNCE_SECONDS,
            self._do_auto_scroll,
        )

    def _do_auto_scroll(self) -> None:
        """Perform the actual auto-scroll check."""
        self._scroll_timer = None
        if self.should_auto_scroll():
            self.call_after_refresh(self.anchor)

    def finalize_streaming(self) -> None:
        """Finalize streaming by rendering final content and cleaning up stream.

        This method ensures the complete Markdown document is properly rendered
        by calling widget.update() with the full accumulated content, then
        asynchronously stops the MarkdownStream in the background.
        """
        # Sync messages reactive with final content
        self._skip_watch = True
        try:
            if self.messages and self._streaming_content:
                updated = replace(self.messages[-1], content=self._streaming_content)
                self.messages = self.messages[:-1] + [updated]
        finally:
            self._skip_watch = False

        # First, ensure final content is rendered via direct update
        assistant_widgets = self.query(AssistantMessageWidget)
        if assistant_widgets:
            last_widget = assistant_widgets[-1]
            # Direct update ensures final render is correct (bypasses stream batching)
            last_widget.update(self._streaming_content)

        # Then schedule async cleanup of the stream (non-blocking)
        self.call_later(self._async_cleanup_stream)
        self._is_streaming = False

        if self.should_auto_scroll():
            self.call_after_refresh(self.anchor)

    def stop_streaming(self) -> None:
        """Mark streaming as stopped (sync cleanup)."""
        self._is_streaming = False
        if self._scroll_timer is not None:
            self._scroll_timer.stop()
            self._scroll_timer = None

    # =========================================================================
    # Backward compatibility API (used by existing app_textual.py until migrated)
    # =========================================================================

    def append_to_last_assistant_message(self, token: str) -> None:
        """Backward compatibility: sync version that updates content immediately.

        During migration period, this method maintains the same behavior as before:
        - Immediately update _streaming_content (synchronous)
        - Schedule async MarkdownStream write in background
        - Update reactive messages synchronously

        New code should use append_stream_token() (async) instead.
        """
        if self._destroyed:
            return

        # Update streaming content immediately (synchronous, for test assertions)
        self._streaming_content += token

        # Schedule async stream write (non-blocking)
        self.call_later(self._async_append_token, token)

        # Update reactive messages immediately (skip watch)
        self._skip_watch = True
        try:
            if self.messages:
                updated = replace(self.messages[-1], content=self._streaming_content)
                self.messages = self.messages[:-1] + [updated]
        finally:
            self._skip_watch = False

    async def _async_append_token(self, token: str) -> None:
        """Async helper for backward compatibility."""
        if self._destroyed:
            return
        try:
            if self._active_stream:
                await self._active_stream.write(token)
        except Exception as e:  # noqa: BLE001
            logger.debug("Stream write failed: %s", e)

    async def _async_cleanup_stream(self) -> None:
        """Asynchronously stop and cleanup the MarkdownStream."""
        if self._active_stream:
            try:
                await self._active_stream.stop()
            except Exception as e:  # noqa: BLE001
                logger.debug("Error stopping MarkdownStream: %s", e)
            finally:
                self._active_stream = None

    def get_active_stream(self):
        """Get the active MarkdownStream (for debugging)."""
        return self._active_stream

    def is_streaming(self) -> bool:
        """Check if currently streaming."""
        return getattr(self, "_is_streaming", False)

    def get_streaming_content(self) -> str:
        """Get current streaming content (for persistence)."""
        if self.messages:
            return self.messages[-1].content or ""
        return ""

    def clear_streaming(self) -> None:
        """Clear streaming state (for error recovery)."""
        if self._active_stream:
            self._active_stream = None
        self._is_streaming = False
        if self._scroll_timer is not None:
            self._scroll_timer.stop()
            self._scroll_timer = None

    # =========================================================================
    # Workflow integration
    # =========================================================================

    def mount_workflow_progress_widget(
        self,
        workflow_state: WorkflowState,
        tools: dict[str, "Tool"] | None = None,
        on_confirm: Callable | None = None,
        on_deny: Callable | None = None,
        on_edit: Callable | None = None,
        on_retry: Callable | None = None,
    ) -> WorkflowProgressWidget:
        """Mount a workflow progress widget to the end of chat view.

        Args:
            workflow_state: The workflow state to display.
            tools: Optional dict of tool_name -> Tool instance.
            on_confirm: Confirmation callback.
            on_deny: Denial callback.
            on_edit: Edit callback.
            on_retry: Retry callback.

        Returns:
            The mounted WorkflowProgressWidget.
        """
        widget = WorkflowProgressWidget(
            workflow_state=workflow_state,
            tools=tools,
            on_confirm=on_confirm,
            on_deny=on_deny,
            on_edit=on_edit,
            on_retry=on_retry,
        )
        self.mount(widget)
        self.call_after_refresh(self.anchor)
        return widget

    def update_workflow_progress_widget(
        self,
        widget: WorkflowProgressWidget,
        state: WorkflowState,
    ) -> None:
        """Update an existing workflow progress widget.

        Args:
            widget: The widget to update.
            state: The new workflow state.
        """
        widget.workflow_state = state
        widget.trigger_update()

    def mount_tool_execution_widget(
        self,
        item: WorkflowItem,
        tool: Tool | None = None,
        on_confirm: Callable | None = None,
        on_deny: Callable | None = None,
        on_edit: Callable | None = None,
        on_retry: Callable | None = None,
    ) -> ToolExecutionWidget:
        """Mount a tool execution widget to the end of chat view.

        Args:
            item: The workflow item representing this tool call.
            tool: Optional Tool instance.
            on_confirm: Callback when user confirms.
            on_deny: Callback when user denies.
            on_edit: Callback for edit action.
            on_retry: Callback for retry action.

        Returns:
            The mounted ToolExecutionWidget.
        """
        widget = ToolExecutionWidget(
            item=item,
            tool=tool,
            on_confirm=on_confirm,
            on_deny=on_deny,
            on_edit=on_edit,
            on_retry=on_retry,
        )
        self.mount(widget)
        self.call_after_refresh(self.anchor)
        return widget

    def update_tool_execution_widget(
        self,
        widget: ToolExecutionWidget,
        status: WorkflowStatus,
        result_summary: str | None = None,
        error: str | None = None,
    ) -> None:
        """Update a tool execution widget's status.

        Args:
            widget: The widget to update.
            status: New status.
            result_summary: Optional result summary.
            error: Optional error message.
        """
        widget.update_status(status, result_summary=result_summary, error=error)

    # =========================================================================
    # Summary Rule Widget - Context Compression Indicator
    # =========================================================================

    def show_summary_rule(
        self,
        message_count: int = 0,
        summary_date: str | None = None,
        summary_text: str | None = None,
    ) -> SummaryRuleWidget:
        """Display a summary rule widget at the end of the chat view.

        This method shows a horizontal rule with centered text indicating
        that messages above this point have been summarized/condensed during
        context compression operations.

        Args:
            message_count: Number of messages that were summarized.
            summary_date: Date when the summary was created (defaults to today).
            summary_text: Optional custom text to display instead of the default.

        Returns:
            The mounted SummaryRuleWidget instance.
        """
        # Remove any existing summary rule first
        self.hide_summary_rule()

        widget = SummaryRuleWidget(
            message_count=message_count,
            summary_date=summary_date,
            summary_text=summary_text,
        )
        self.mount(widget)
        self.call_after_refresh(self.anchor)
        return widget

    def hide_summary_rule(self) -> None:
        """Remove the summary rule widget from the chat view.

        This method safely removes any existing SummaryRuleWidget instances
        from the chat view, used when hiding the context compression indicator.
        """
        for widget in self.query(SummaryRuleWidget):
            widget.remove()

    def update_summary_rule(
        self,
        message_count: int | None = None,
        summary_date: str | None = None,
        summary_text: str | None = None,
    ) -> SummaryRuleWidget | None:
        """Update the existing summary rule widget with new information.

        If no summary rule exists, creates one. Otherwise updates the existing
        widget with the new parameters.

        Args:
            message_count: New message count to display.
            summary_date: New date to display.
            summary_text: Custom text to display (overrides other parameters).

        Returns:
            The updated SummaryRuleWidget instance, or None if none exists
            and no parameters were provided to create one.
        """
        existing_widgets = list(self.query(SummaryRuleWidget))

        if not existing_widgets:
            # No existing widget, create one if we have enough info
            if summary_text is not None or message_count is not None:
                return self.show_summary_rule(
                    message_count=message_count or 0,
                    summary_date=summary_date,
                    summary_text=summary_text,
                )
            return None

        # Update existing widget
        widget = existing_widgets[0]
        if summary_text is not None:
            widget.update_summary(summary_text)
        elif message_count is not None:
            from datetime import datetime

            date = summary_date or datetime.now().strftime("%Y-%m-%d")
            new_text = _(
                f"📝 Above content summarized ({message_count} messages, {date})"
            )
            widget.update_summary(new_text)

        return widget

    # =========================================================================
    # Backward compatibility API (used by existing tests and app_textual.py)
    # =========================================================================
    # Clipboard auto-copy
    # =========================================================================
    # Clipboard auto-copy
    # =========================================================================

    @on(events.MouseUp)
    def on_mouse_up(self, event: events.MouseUp) -> None:
        # Right-click: show context menu for message actions
        if event.button == 3 and not getattr(self.app, "is_generating", False):
            logger.debug(
                "Right-click detected on widget=%s, forwarding to _handle_right_click",
                type(event.widget).__name__ if event.widget else "None",
            )
            self._handle_right_click(event)
            return

        # Left/middle click: copy selected text to clipboard
        selected_text = self.screen.get_selected_text()
        if not selected_text or not selected_text.strip():
            return

        if copy_to_clipboard(selected_text):
            char_count = len(selected_text)
            self.app.notify(
                _("Copied {char_count} characters to clipboard").format(
                    char_count=char_count,
                ),
                title=_("Copied!"),
                timeout=2,
            )
        else:
            self.app.notify(
                _("Failed to copy to clipboard"),
                title=_("Error"),
                timeout=2,
            )

    def _handle_right_click(self, event: events.MouseUp) -> None:
        """Handle right-click on a message to show context actions menu.

        Args:
            event: The mouse up event.
        """
        target_types = (UserMessageWidget, AssistantMessageWidget)
        msg_widget = None

        if event.widget is not None:
            if isinstance(event.widget, target_types):
                msg_widget = event.widget
            else:
                for cls in target_types:
                    try:
                        msg_widget = event.widget.query_ancestor(cls)
                        if msg_widget is not None:
                            break
                    except Exception:
                        continue

        if msg_widget is None:
            try:
                clicked_widget, _ = self.screen.get_widget_at(
                    event.screen_x, event.screen_y
                )
            except Exception:
                logger.debug(
                    "Right-click: could not find widget at screen (%d, %d)",
                    event.screen_x,
                    event.screen_y,
                )
                return

            if isinstance(clicked_widget, target_types):
                msg_widget = clicked_widget
            else:
                for cls in target_types:
                    try:
                        msg_widget = clicked_widget.query_ancestor(cls)
                        if msg_widget is not None:
                            break
                    except Exception:
                        continue

        if msg_widget is None:
            logger.debug("Right-click: no message widget found, ignoring")
            return

        # Determine role and message index
        if isinstance(msg_widget, UserMessageWidget):
            role = "user"
        elif isinstance(msg_widget, AssistantMessageWidget):
            role = "assistant"
        else:
            return

        index = getattr(msg_widget, "message_index", -1)
        if index == -1:
            return

        # Check if this is the last assistant message
        # Look forward from this message to see if any later assistant message exists
        is_last_assistant = False
        if role == "assistant":
            is_last_assistant = not any(
                m.role == "assistant" for m in self.messages[index + 1 :]
            )

        # Push the context menu screen
        from tinychat.components.message_action_screen import MessageActionScreen

        msg_content = self.messages[index].content if index < len(self.messages) else ""
        self.app.push_screen(
            MessageActionScreen(index, role, is_last_assistant, content=msg_content),
            callback=lambda result: self.app._handle_message_action(
                result, index, role
            ),
        )
