"""StatusBar component for displaying status information using Textual."""

from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static

from tinychat.utils.i18n import _


class StatusBar(Static):
    """Component to display status information."""

    DEFAULT_CSS = """
    StatusBar {
        height: 1;
        dock: bottom;
        padding: 0 1;
        background: $panel;
        color: $text;
    }
    """

    backend_name: reactive[str] = reactive("", repaint=True)
    model: reactive[str] = reactive("", repaint=True)
    connection_status: reactive[str] = reactive("disconnected", repaint=True)
    response_time: reactive[float | None] = reactive(None, repaint=True)
    tokens_per_second: reactive[float | None] = reactive(None, repaint=True)
    error_message: reactive[str | None] = reactive(None, repaint=True)
    is_generating: reactive[bool] = reactive(False, repaint=True)
    is_summarizing: reactive[bool] = reactive(False, repaint=True)
    status: reactive[str] = reactive("idle", repaint=True)
    todo_progress: reactive[str] = reactive("", repaint=True)
    token_usage: reactive[str] = reactive("", repaint=True)
    compaction_status: reactive[str] = reactive("", repaint=True)

    def render(self) -> Text:
        """Render the status bar content."""
        if self.status == "error" and self.error_message:
            text = Text()
            text.append(_("ERROR: "), style="bold red")
            text.append(self.error_message, style="red")
            return text

        parts = self._build_status_parts()

        if not parts:
            return Text(_("Status Bar"))

        return Text(" │ ".join(parts))

    def _build_status_parts(self) -> list[str]:
        """Build the list of status bar segments."""
        parts = self._build_status_indicator()

        parts = self._append_backend_info(parts)
        parts = self._append_connection(parts)
        parts = self._append_metrics(parts)
        parts = self._append_todo(parts)
        parts = self._append_compaction(parts)

        return parts

    def _build_status_indicator(self) -> list[str]:
        """Build the status indicator segment."""
        parts: list[str] = []
        if self.status == "loading":
            parts.append(f"⏳ {_('Loading...')}")
        elif self.status == "streaming":
            parts.append(f"⚡ {_('Streaming...')}")
        elif self.status == "success":
            parts.append(f"✓ {_('Success')}")
        elif self.status == "executing":
            parts.append(f"🔧 {_('Executing tools...')}")
        elif self.is_summarizing:
            parts.append(f"📝 {_('Summarizing...')}")
        elif self.is_generating:
            parts.append(f"⏳ {_('Generating...')}")
        return parts

    def _append_backend_info(self, parts: list[str]) -> list[str]:
        """Append backend and model info segments."""
        if self.backend_name:
            parts.append(f"{_('Backend:')} {self.backend_name}")
        if self.model:
            parts.append(f"{_('Model:')} {self.model}")
        return parts

    def _append_connection(self, parts: list[str]) -> list[str]:
        """Append connection status segment."""
        status_emoji = "●" if self.connection_status == "connected" else "○"
        parts.append(f"{_('Status:')} {status_emoji} {self.connection_status}")
        return parts

    def _append_metrics(self, parts: list[str]) -> list[str]:
        """Append performance metrics segments."""
        if self.response_time is not None:
            parts.append(f"{_('Response:')} {self.response_time:.2f}s")
        if self.tokens_per_second is not None:
            parts.append(f"{_('Speed:')} {self.tokens_per_second:.1f} {_('tok/s')}")
        return parts

    def _append_todo(self, parts: list[str]) -> list[str]:
        """Append todo progress segment."""
        if self.todo_progress:
            parts.append(f"📋 {self.todo_progress}")
        return parts

    def _append_compaction(self, parts: list[str]) -> list[str]:
        """Append compaction-related segments."""
        if self.compaction_status:
            parts.append(f"{self.compaction_status}")
        if self.token_usage:
            parts.append(f"{self.token_usage}")
        return parts

    def update_backend_info(self, backend_name: str, model: str) -> None:
        """Update backend and model information."""
        self.backend_name = backend_name
        self.model = model

    def update_metrics(
        self,
        response_time: float | None = None,
        tokens_per_second: float | None = None,
    ) -> None:
        """Update performance metrics."""
        if response_time is not None:
            self.response_time = response_time
        if tokens_per_second is not None:
            self.tokens_per_second = tokens_per_second

    def update_connection_status(self, status: str) -> None:
        """Update connection status."""
        self.connection_status = status

    def show_error(self, message: str) -> None:
        """Show error message in status bar."""
        self.status = "error"
        self.error_message = message
        self.is_generating = False

    def set_generating(self, generating: bool) -> None:
        """Set generating state."""
        self.is_generating = generating
        if generating:
            self.error_message = None

    def set_summarizing(self, summarizing: bool) -> None:
        """Set summarizing state.

        Args:
            summarizing: True to show summarizing indicator, False to hide.
        """
        self.is_summarizing = summarizing
        if summarizing:
            self.error_message = None

    def set_status(self, status: str, message: str | None = None) -> None:
        """Set status state.

        Args:
            status: Status state (idle, loading, streaming, error, success).
            message: Optional message (used for error status).
        """
        self.status = status
        if status == "error" and message:
            self.error_message = message
        elif status != "error":
            self.error_message = None

    def update_todo_progress(self, completed: int, total: int) -> None:
        """Update todo progress display.

        Args:
            completed: Number of completed tasks.
            total: Total number of tasks.
        """
        if total > 0:
            self.todo_progress = f"{completed}/{total}"
        else:
            self.todo_progress = ""

    def update_token_usage(self, current: int, limit: int) -> None:
        """Update token usage display.

        Args:
            current: Current token count.
            limit: Model's context limit.
        """
        if limit > 0:
            if current >= 1000:
                current_str = f"{current / 1000:.1f}k"
            else:
                current_str = str(current)
            if limit >= 1000:
                limit_str = f"{limit / 1000:.0f}k"
            else:
                limit_str = str(limit)
            self.token_usage = f"{current_str} / {limit_str} tokens"
        else:
            self.token_usage = ""
