"""InputArea component for user text input using Textual."""

import asyncio
from typing import ClassVar

from textual.binding import Binding, BindingsMap
from textual.events import Key
from textual.widgets import TextArea

from tinychat.utils.i18n import _


class InputArea(TextArea):
    """Component for user input with placeholder."""

    BINDINGS: ClassVar[list] = [
        Binding("ctrl+j", "newline", "New Line", show=False),
    ]

    def __init__(
        self,
        placeholder: str | None = None,
        **kwargs,
    ):
        """Initialize InputArea with placeholder."""
        kwargs.pop("text", None)
        super().__init__(text="", language=None, **kwargs)
        if placeholder is None:
            placeholder = _("Type your message... (Enter to send, Ctrl+J for newline)")
        self.placeholder = placeholder

    def on_mount(self) -> None:
        """Update binding descriptions with i18n on mount."""
        self._update_bindings_i18n()

    def _update_bindings_i18n(self) -> None:
        """Update binding descriptions with current locale translations."""
        translated_descriptions = {
            "newline": _("New Line"),
            "copy": _("Copy"),
            "cut": _("Cut"),
            "paste": _("Paste"),
            "undo": _("Undo"),
            "redo": _("Redo"),
            "select_all": _("Select all"),
            "select_line": _("Select line"),
            "cursor_up": _("Cursor up"),
            "cursor_down": _("Cursor down"),
            "cursor_left": _("Cursor left"),
            "cursor_right": _("Cursor right"),
            "cursor_line_start": _("Cursor line start"),
            "cursor_line_end": _("Cursor line end"),
            "cursor_page_up": _("Cursor page up"),
            "cursor_page_down": _("Cursor page down"),
            "cursor_word_left": _("Cursor word left"),
            "cursor_word_right": _("Cursor word right"),
            "page_left": _("Page Left"),
            "page_right": _("Page Right"),
            "delete_left": _("Delete character left"),
            "delete_right": _("Delete character right"),
            "delete_word_left": _("Delete left to start of word"),
            "delete_word_right": _("Delete right to start of word"),
            "delete_line": _("Delete line"),
            "delete_to_start_of_line": _("Delete to line start"),
            "delete_to_end_of_line_or_delete_line": _("Delete to line end"),
            "cursor_up(True)": _("Cursor up select"),
            "cursor_down(True)": _("Cursor down select"),
            "cursor_left(True)": _("Cursor left select"),
            "cursor_right(True)": _("Cursor right select"),
            "cursor_line_start(True)": _("Cursor line start select"),
            "cursor_line_end(True)": _("Cursor line end select"),
            "cursor_word_left(True)": _("Cursor left word select"),
            "cursor_word_right(True)": _("Cursor right word select"),
        }
        new_bindings = BindingsMap()
        for key, binding in self._bindings:
            if binding.action in translated_descriptions:
                new_bindings.bind(
                    binding.key,
                    binding.action,
                    translated_descriptions[binding.action],
                    show=binding.show,
                )
            else:
                new_bindings.bind(
                    binding.key,
                    binding.action,
                    binding.description,
                    show=binding.show,
                )
        self._bindings = new_bindings

    def on_key(self, event: Key) -> None:
        """Handle key events."""
        if event.key == "enter":
            # Send message on Enter
            event.prevent_default()
            self.action_send_message()
        elif event.key == "up":
            cursor_col = self.cursor_location[1]
            if cursor_col == 0 or not self.text:
                event.prevent_default()
                self.action_history_up()
        elif event.key == "down":
            cursor_col = self.cursor_location[1]
            if cursor_col >= len(self.text) or not self.text:
                event.prevent_default()
                self.action_history_down()
        elif event.key == "slash":
            event.prevent_default()
            self.action_show_command_palette()
        elif event.key == "ctrl+c":
            # Clear input on Ctrl+C (not copying text)
            event.prevent_default()
            event.stop()
            self.action_clear_input()

    def action_send_message(self) -> None:
        """Send the current message."""
        text = self.text
        if text.strip():
            if hasattr(self.app, "send_message"):
                asyncio.create_task(self.app.send_message(text))
            self.text = ""

    def action_newline(self) -> None:
        """Insert a newline."""
        self.insert("\n")

    def action_clear_input(self) -> None:
        """Clear the current input."""
        self.text = ""

    def _get_session(self):
        """Get current session from app."""
        return getattr(self.app, "current_session", None)

    def action_history_up(self) -> None:
        """Navigate to previous input in history."""
        session = self._get_session()
        if not session or not session.input_history:
            return

        if session.history_index > 0:
            session.history_index -= 1
            self.text = session.input_history[session.history_index]

    def action_history_down(self) -> None:
        """Navigate to next input in history."""
        session = self._get_session()
        if not session or not session.input_history:
            return

        if session.history_index < len(session.input_history):
            self.text = session.input_history[session.history_index]
            session.history_index += 1
        else:
            self.text = ""

    def action_show_command_palette(self) -> None:
        """Show command palette with available slash commands."""
        if hasattr(self.app, "show_command_palette"):
            self.app.show_command_palette()

    def on_paste(self, event) -> None:
        """Handle paste events with image detection."""
        if hasattr(event, "text") and event.text:
            pass
        else:
            event.prevent_default()
            try:
                from tinychat.components.status_bar import StatusBar  # noqa: PLC0415

                status_bar = self.app.query_one(StatusBar)
                status_bar.set_status("error", message=_("Image input not supported"))
            except Exception:  # noqa: BLE001
                pass
