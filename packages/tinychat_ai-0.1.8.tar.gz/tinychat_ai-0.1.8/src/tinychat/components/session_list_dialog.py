"""Session list dialog - OpenCode-style /sessions dialog."""

from __future__ import annotations

import logging
from collections import OrderedDict
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Callable, ClassVar

from textual import events, on, work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Vertical
from textual.content import Content
from textual.screen import ModalScreen
from textual.timer import Timer
from textual.widgets import Button, Input, Label, ListItem, ListView, Static

from tinychat.utils.i18n import _, ngettext

SECONDS_PER_HOUR = 3600
SECONDS_PER_DAY = 86400
DAYS_IN_ONE_WEEK = 7

if TYPE_CHECKING:
    from tinychat.models.session import ChatSession, SessionSummary
    from tinychat.utils.session_manager import SessionManager

logger = logging.getLogger(__name__)


def _relative_time(dt: datetime) -> str:
    now = datetime.now()
    delta = now - dt
    if delta.total_seconds() < SECONDS_PER_HOUR:
        minutes = int(delta.total_seconds() / 60)
        if minutes <= 0:
            return _("now")
        return ngettext("{count} minute ago", "{count} minutes ago", minutes).format(
            count=minutes,
        )
    if delta.total_seconds() < SECONDS_PER_DAY:
        hours = int(delta.total_seconds() / 3600)
        return ngettext("{count} hour ago", "{count} hours ago", hours).format(
            count=hours,
        )
    if delta.days == 1:
        return _("Yesterday")
    if delta.days < DAYS_IN_ONE_WEEK:
        return dt.strftime(_("%a %H:%M"))
    return dt.strftime(_("%m/%d"))


def _date_category(dt: datetime) -> str:
    now = datetime.now()
    if dt.date() == now.date():
        return _("Today")
    yesterday = now.date() - timedelta(days=1)
    if dt.date() == yesterday:
        return _("Yesterday")
    return dt.strftime("%Y-%m-%d")


def _count_today_sessions(sessions: list[ChatSession]) -> int:
    today = datetime.now().date()
    return sum(1 for s in sessions if s.updated_at.date() == today)


def _fuzzy_match(query: str, text: str) -> int:
    if not query:
        return 1
    query_lower = query.lower()
    text_lower = text.lower()
    if query_lower in text_lower:
        return text_lower.index(query_lower)
    score = 0
    qi = 0
    for ch in text_lower:
        if qi < len(query_lower) and ch == query_lower[qi]:
            score += 1
            qi += 1
    return score if qi == len(query_lower) else -1


def _fuzzy_match_positions(query: str, text: str) -> list[tuple[int, int]] | None:
    if not query:
        return None
    query_lower = query.lower()
    text_lower = text.lower()
    if query_lower in text_lower:
        start = text_lower.index(query_lower)
        return [(start, start + len(query_lower))]
    positions: list[tuple[int, int]] = []
    qi = 0
    for i, ch in enumerate(text_lower):
        if qi < len(query_lower) and ch == query_lower[qi]:
            positions.append((i, i + 1))
            qi += 1
    return positions if qi == len(query_lower) else None


def _last_user_message_preview(
    session: ChatSession | SessionSummary,
    max_len: int = 40,
) -> str:
    # SessionSummary doesn't have messages, return empty preview
    if not hasattr(session, "messages") or not session.messages:
        return ""
    for msg in reversed(session.messages):
        if msg.role == "user" and msg.content.strip():
            preview = msg.content.strip().replace("\n", " ")
            if len(preview) > max_len:
                preview = preview[:max_len] + "..."
            return preview
    return ""


_SESSION_ID_PREFIX = "sid-"
_CATEGORY_ID_PREFIX = "cat-"


class _SessionSearchInput(Input):
    def check_consume_key(self, key: str, character: str | None) -> bool:
        if key in ("j", "k", "tab", "enter"):
            return False
        if key in ("ctrl_d", "ctrl_r"):
            return False
        return super().check_consume_key(key, character)

    def _handle_list_nav(self, key: str) -> None:
        list_view = self.screen.query_one("#session-list", ListView)
        if key == "j":
            list_view.action_cursor_down()
        else:
            list_view.action_cursor_up()

    def on_key(self, event) -> None:
        if event.name in ("j", "k"):
            event.stop()
            self._handle_list_nav(event.name)
            return
        if event.name in ("up", "down"):
            event.stop()
            list_view = self.screen.query_one("#session-list", ListView)
            list_view.focus()
            if event.name == "down":
                list_view.action_cursor_down()
            else:
                list_view.action_cursor_up()
            return
        if event.name == "tab":
            event.stop()
            list_view = self.screen.query_one("#session-list", ListView)
            list_view.focus()
            return
        if event.name == "enter":
            event.stop()
            list_view = self.screen.query_one("#session-list", ListView)
            if list_view.highlighted_child is not None:
                item_id = list_view.highlighted_child.id
                if item_id and item_id.startswith(_SESSION_ID_PREFIX):
                    self.screen.dismiss(item_id[len(_SESSION_ID_PREFIX) :])
            return
        if event.name == "ctrl_d":
            event.stop()
            self.screen.toggle_delete()
            return
        if event.name == "ctrl_r":
            event.stop()
            self.screen.rename_session()
            return


def _build_session_content(
    session: ChatSession | SessionSummary,
    current_session_id: str | None,
    delete_confirm_id: str | None,
    search_query: str = "",
) -> Content:
    is_current = session.id == current_session_id
    is_deleting = session.id == delete_confirm_id

    if is_deleting:
        return Content.from_markup(
            f"[bold $error on $error 20%] ✕ {_('Press ctrl+d again to confirm')}[/]",
        )

    indicator = (
        Content.from_markup("[bold $primary]●[/]") if is_current else Content(" ")
    )

    title_text = session.title
    title_content: Content
    positions = (
        _fuzzy_match_positions(search_query, title_text) if search_query else None
    )

    if positions:
        title_content = Content(title_text)
        for start, end in reversed(positions):
            title_content = title_content.stylize("bold $warning", start, end)
    else:
        title_content = Content(title_text)

    meta_parts = [session.model]
    msg_count = session.message_count
    if msg_count > 0:
        meta_parts.append(_("{count} msgs").format(count=msg_count))
    meta_text = " · ".join(meta_parts)

    meta_content = Content.from_markup("[dim $text-muted]$meta[/]", meta=meta_text)
    time_content = Content.from_markup(
        "[dim italic $text-muted]$time[/]",
        time=_relative_time(session.updated_at),
    )

    # Use session preview if available, fall back to extracting from messages
    preview = getattr(session, "preview", "") or _last_user_message_preview(session)
    preview_content: Content | None = None
    if preview:
        preview_content = Content.from_markup(
            "\n[dim italic $text-muted]> $preview[/]",
            preview=preview,
        )

    spacer = Content(" ")
    time_spacer = Content("  ")

    result = (
        indicator
        + spacer
        + title_content
        + spacer
        + meta_content
        + time_spacer
        + time_content
    )
    if preview_content:
        result = result + preview_content
    return result


class SessionContextMenuScreen(ModalScreen[str | None]):
    """Context menu for session actions on right-click."""

    BINDINGS: ClassVar[list] = [
        Binding("escape", "cancel", "", show=False),
    ]

    DEFAULT_CSS = """
    SessionContextMenuScreen {
        align: center middle;
    }

    #session-context-menu {
        width: 30;
        height: auto;
        border: thick $primary;
        background: $surface;
        padding: 1;
    }

    #session-context-menu Button {
        width: 100%;
        margin: 0;
        padding: 0 1;
        height: 3;
    }

    #session-context-menu Button:hover {
        background: $primary 20%;
    }
    """

    def __init__(
        self,
        session_id: str,
        session_title: str,
        is_current: bool,
        is_last_assistant: bool = False,
    ) -> None:
        super().__init__()
        self.session_id = session_id
        self.session_title = session_title
        self._is_current = is_current
        self.is_last_assistant = is_last_assistant

    def compose(self) -> ComposeResult:
        with Container(id="session-context-menu"):
            yield Label(_("Session Actions"), id="context-title")
            yield Button(_("🔀 Fork from here"), id="btn-fork")
            if self.is_last_assistant:
                yield Button(_("↻ Regenerate answer"), id="btn-regenerate")
            yield Button(_("🗑 Delete session"), id="btn-delete")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-fork":
            self.dismiss("fork")
        elif event.button.id == "btn-regenerate":
            self.dismiss("regenerate")
        elif event.button.id == "btn-delete":
            self.dismiss("delete")

    def action_cancel(self) -> None:
        self.dismiss(None)


class SessionListScreen(ModalScreen[str | None]):
    BINDINGS: ClassVar[list] = [
        Binding("escape", "close", ""),
        Binding("tab", "focus_search", "", show=False),
        Binding("k", "list_view__action_cursor_up", "", show=False),
        Binding("j", "list_view__action_cursor_down", "", show=False),
        Binding("pageup", "list_view__action_scroll_page_up", "", show=False),
        Binding("pagedown", "list_view__action_scroll_page_down", "", show=False),
        Binding("home", "list_view__action_scroll_home", "", show=False),
        Binding("end", "list_view__action_scroll_end", "", show=False),
    ]

    CSS_PATH = "../styles/session_list_dialog.tcss"
    DEFAULT_CSS = ""

    def __init__(
        self,
        sessions: list[SessionSummary],
        current_session_id: str | None = None,
        session_manager: SessionManager | None = None,
        on_session_deleted: Callable[[str], None] | None = None,
    ) -> None:
        super().__init__()
        self._all_sessions = sorted(sessions, key=lambda s: s.updated_at, reverse=True)
        self._current_session_id = current_session_id
        self._filtered: list[SessionSummary] = list(self._all_sessions)
        self._search_query: str = ""
        self._delete_confirm_id: str | None = None
        self._delete_timer: Timer | None = None
        self._session_manager = session_manager
        self._on_session_deleted = on_session_deleted

    def compose(self) -> ComposeResult:
        with Vertical(id="session-dialog"):
            with Vertical(id="session-dialog-header"):
                yield Label(_("Sessions"), id="session-dialog-title")
                today_count = _count_today_sessions(self._all_sessions)
                total = len(self._all_sessions)
                count_text = f"({total}"
                if today_count > 0 and today_count < total:
                    count_text += f" · {today_count} {_('today')}"
                count_text += ")"
                yield Label(count_text, id="session-dialog-count")
            yield _SessionSearchInput(
                placeholder=_("Search sessions..."),
                id="session-search",
                compact=True,
            )
            yield ListView(id="session-list", initial_index=0)
            with Vertical(id="session-dialog-footer"):
                yield Static(
                    Content.from_markup(
                        f"[dim]{_('↑↓ navigate  ↵ select  tab switch  ctrl+d delete')}"
                        f" {_('ctrl+r rename  esc close')}[/]",
                    ),
                    id="session-dialog-footer-text",
                )

    def _build_list_items(self) -> list[ListItem]:
        if not self._filtered:
            return [
                ListItem(
                    Static(
                        Content.from_markup(
                            f"[$text-muted]{_('No sessions found.')}\n"
                            f"{_('Press Ctrl+T to create one.')}[/]",
                        ),
                        classes="session-item-content",
                    ),
                    classes="session-empty-item",
                    disabled=True,
                ),
            ]

        is_searching = bool(self._search_query)

        if is_searching:
            items: list[ListItem] = []
            for session in self._filtered:
                items.append(self._build_session_item(session))
            return items

        grouped: OrderedDict[str, list[ChatSession]] = OrderedDict()
        for session in self._filtered:
            cat = _date_category(session.updated_at)
            if cat not in grouped:
                grouped[cat] = []
            grouped[cat].append(session)

        items = []
        for cat_idx, (category, sessions) in enumerate(grouped.items()):
            count = len(sessions)
            cat_content = Content.from_markup(
                "[$accent on $accent 10%]▌ $cat[/]"
                "$pad"
                "[dim $text-muted]$count $sessions_label[/]",
                cat=category,
                pad=" " * max(1, 16 - len(category)),
                count=str(count),
                sessions_label=_("sessions"),
            )
            cat_item = ListItem(
                Static(cat_content, classes="session-category-content"),
                id=f"{_CATEGORY_ID_PREFIX}{cat_idx}",
                classes="session-category-item",
                disabled=True,
            )
            items.append(cat_item)

            for session in sessions:
                items.append(self._build_session_item(session))

        return items

    def _build_session_item(self, session: ChatSession | SessionSummary) -> ListItem:
        is_deleting = session.id == self._delete_confirm_id
        content = _build_session_content(
            session,
            self._current_session_id,
            self._delete_confirm_id,
            self._search_query,
        )
        item_classes = "session-item"
        if is_deleting:
            item_classes += " deleting"
        return ListItem(
            Static(content, classes="session-item-content"),
            id=f"{_SESSION_ID_PREFIX}{session.id}",
            classes=item_classes,
        )

    @work(exclusive=True)
    async def _refresh_list(self) -> None:
        list_view = self.query_one("#session-list", ListView)
        await list_view.clear()
        new_items = self._build_list_items()
        if new_items:
            await list_view.extend(new_items)
            first_selectable = next(
                (i for i, item in enumerate(new_items) if not item.disabled),
                0,
            )
            list_view.index = first_selectable
        count_label = self.query_one("#session-dialog-count", Label)
        today_count = _count_today_sessions(self._filtered)
        total = len(self._filtered)
        all_count = len(self._all_sessions)
        if self._search_query and total != all_count:
            count_text = f"({total}/{all_count}"
        else:
            count_text = f"({total}"
        if today_count > 0 and today_count < total:
            count_text += f" \u00b7 {today_count} {_('today')}"
        count_text += ")"
        count_label.update(count_text)

    def on_mount(self) -> None:
        self._refresh_list()
        search_input = self.query_one("#session-search", Input)
        search_input.focus()

    @on(events.MouseUp)
    def on_mouse_up(self, event: events.MouseUp) -> None:
        """Handle right-click on session items to show context menu."""
        logger.debug(
            "MouseUp on widget=%s button=%s",
            type(event.widget).__name__ if event.widget else "None",
            event.button,
        )
        if event.button != 3:  # Right click only
            return

        # Get the widget that was clicked
        widget = event.widget
        if widget is None:
            return

        # Find the ListItem ancestor
        try:
            if isinstance(widget, ListItem):
                list_item = widget
            else:
                list_item = widget.query_ancestor(ListItem)
        except Exception:
            list_item = None

        if list_item is None or list_item.disabled:
            return

        # Extract session ID
        session_id = self._extract_session_id(list_item)
        if not session_id:
            return

        # Select this item in the ListView
        list_view = self.query_one("#session-list", ListView)
        list_view.index = list_view.children.index(list_item)

        # Find the session object
        session = next((s for s in self._all_sessions if s.id == session_id), None)
        if not session:
            return

        # Determine if this session's last message is from assistant
        is_last_assistant = False
        if hasattr(session, "messages") and session.messages:
            last_msg = session.messages[-1]
            is_last_assistant = last_msg.role == "assistant"

        # Show context menu
        self._show_context_menu(session_id, session.title, is_last_assistant)

    def _show_context_menu(
        self,
        session_id: str,
        session_title: str,
        is_last_assistant: bool = False,
    ) -> None:
        """Show context menu for a session."""
        self.app.push_screen(
            SessionContextMenuScreen(
                session_id=session_id,
                session_title=session_title,
                is_current=session_id == self._current_session_id,
                is_last_assistant=is_last_assistant,
            ),
            callback=lambda result: self._handle_context_action(result, session_id),
        )

    def _handle_context_action(self, action: str | None, session_id: str) -> None:
        """Handle context menu action."""
        if action == "fork":
            self._fork_session(session_id)
        elif action == "regenerate":
            self._regenerate_answer(session_id)
        elif action == "delete":
            self._delete_session(session_id)

    def _fork_session(self, session_id: str) -> None:
        """Fork a new session from the selected session."""
        # TODO: Implement fork logic - create new session branching from this one
        self.app.notify(
            _("Fork not yet implemented for session list"),
            title=_("Info"),
            timeout=2,
        )

    def _regenerate_answer(self, session_id: str) -> None:
        """Regenerate the last answer for this session."""
        # TODO: Implement regenerate - switch to session and trigger regeneration
        self.app.notify(
            _("Regenerate not yet implemented for session list"),
            title=_("Info"),
            timeout=2,
        )

    def _delete_session(self, session_id: str) -> None:
        """Delete the selected session."""
        if self._delete_confirm_id == session_id:
            # Already confirmed, delete immediately
            self._do_delete(session_id)
        else:
            # Start delete confirmation
            self._start_delete_confirm(session_id)

    @on(Input.Changed, "#session-search")
    def _on_search_changed(self, event: Input.Changed) -> None:
        query = event.value.strip()
        self._cancel_delete_confirm()
        self._search_query = query
        if not query:
            self._filtered = list(self._all_sessions)
        else:
            self._filtered = [
                s for s in self._all_sessions if _fuzzy_match(query, s.title) >= 0
            ]
        self._refresh_list()

    @on(ListView.Selected, "#session-list")
    def _on_list_selected(self, event: ListView.Selected) -> None:
        item = event.item
        if item is None or item.disabled:
            return
        session_id = self._extract_session_id(item)
        if session_id:
            self.dismiss(session_id)

    def action_close(self) -> None:
        self.dismiss(None)

    def action_focus_search(self) -> None:
        self.query_one("#session-search", _SessionSearchInput).focus()

    def action_list_view__action_cursor_down(self) -> None:
        self.query_one("#session-list", ListView).action_cursor_down()

    def action_list_view__action_cursor_up(self) -> None:
        self.query_one("#session-list", ListView).action_cursor_up()

    def on_key(self, event) -> None:
        if event.name == "escape":
            if self._delete_confirm_id:
                event.stop()
                self._cancel_delete_confirm()
        elif event.name == "ctrl_d":
            event.stop()
            self.toggle_delete()
        elif event.name == "ctrl_r":
            event.stop()
            self.rename_session()

    def _get_highlighted_session_id(self) -> str | None:
        list_view = self.query_one("#session-list", ListView)
        item = list_view.highlighted_child
        if item is None:
            return None
        return self._extract_session_id(item)

    def _extract_session_id(self, item: ListItem) -> str | None:
        item_id = item.id
        if item_id and item_id.startswith(_SESSION_ID_PREFIX):
            return item_id[len(_SESSION_ID_PREFIX) :]
        return None

    @work(exclusive=True)
    async def _do_delete(self, session_id: str) -> None:
        if self._session_manager:
            await self._session_manager.close_session(session_id)
        self._all_sessions = [s for s in self._all_sessions if s.id != session_id]
        self._filtered = [s for s in self._filtered if s.id != session_id]
        if self._on_session_deleted:
            self._on_session_deleted(session_id)
        self._delete_confirm_id = None
        self._delete_timer = None
        self._refresh_list()

    def toggle_delete(self) -> None:
        session_id = self._get_highlighted_session_id()
        if not session_id:
            return
        if self._delete_confirm_id == session_id:
            self._cancel_delete_confirm()
            self._do_delete(session_id)
        else:
            self._start_delete_confirm(session_id)

    def _start_delete_confirm(self, session_id: str) -> None:
        self._cancel_delete_confirm()
        self._delete_confirm_id = session_id
        try:
            item = self.query_one(f"#{_SESSION_ID_PREFIX}{session_id}", ListItem)
        except Exception:  # noqa: BLE001
            logger.warning("Delete confirm: session item not found for %s", session_id)
            self._delete_confirm_id = None
            return
        item.add_class("deleting")
        session = next((s for s in self._all_sessions if s.id == session_id), None)
        if session:
            try:
                static = item.query_one(".session-item-content", Static)
                static.update(
                    _build_session_content(
                        session,
                        self._current_session_id,
                        self._delete_confirm_id,
                        self._search_query,
                    ),
                )
            except Exception:  # noqa: BLE001
                logger.debug(
                    "Delete confirm: failed to update content for session %s",
                    session_id,
                )
        self._delete_timer = self.set_timer(5.0, self._cancel_delete_confirm)

    def _cancel_delete_confirm(self) -> None:
        if not self._delete_confirm_id:
            return
        session_id = self._delete_confirm_id
        try:
            item = self.query_one(f"#{_SESSION_ID_PREFIX}{session_id}", ListItem)
        except Exception:  # noqa: BLE001
            logger.debug("Cancel delete: session item not found for %s", session_id)
            self._delete_confirm_id = None
        else:
            item.remove_class("deleting")
            session = next(
                (s for s in self._all_sessions if s.id == session_id),
                None,
            )
            if session:
                try:
                    static = item.query_one(".session-item-content", Static)
                    static.update(
                        _build_session_content(
                            session,
                            self._current_session_id,
                            None,
                            self._search_query,
                        ),
                    )
                except Exception:  # noqa: BLE001
                    logger.debug(
                        "Cancel delete: failed to update content for session %s",
                        session_id,
                    )
            self._delete_confirm_id = None
        if self._delete_timer:
            self._delete_timer.stop()
            self._delete_timer = None

    def rename_session(self) -> None:
        session_id = self._get_highlighted_session_id()
        if not session_id:
            return
        session = next((s for s in self._all_sessions if s.id == session_id), None)
        if not session:
            return
        self.dismiss(("rename", session.id, session.title))
