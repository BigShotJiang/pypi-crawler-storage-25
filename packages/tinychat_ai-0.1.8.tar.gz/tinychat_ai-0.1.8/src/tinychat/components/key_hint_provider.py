"""Command palette provider that enriches commands with keyboard shortcut hints."""

from __future__ import annotations

from collections.abc import AsyncGenerator

from rich.style import Style
from rich.text import Text
from textual.command import DiscoveryHit, Hit, Provider
from textual.content import Content, Span


def format_key_hint_display(title: str, key: str | None) -> Text:
    if not key:
        return Text(title)

    result = Text()
    result.append(title)
    result.append("  ")
    result.append(key, style=Style(dim=True))
    return result


def _format_key_hint_content(highlighted: Content, key: str | None) -> Content:
    if not key:
        return highlighted

    key_content = Content(
        f"  {key}",
        spans=[Span(0, len(key) + 2, Style(dim=True))],
    )
    return highlighted + key_content


class KeyHintProvider(Provider):
    async def discover(self) -> AsyncGenerator[DiscoveryHit, None]:
        key_map = self._build_key_map()
        commands = sorted(
            self.app.get_system_commands(self.screen), key=lambda c: c.title
        )
        for title, help_text, callback, discover in commands:
            if not discover:
                continue
            key = self._find_key(callback, key_map)
            yield DiscoveryHit(
                format_key_hint_display(title, key),
                callback,
                text=title,
                help=help_text,
            )

    async def search(self, query: str) -> AsyncGenerator[Hit, None]:
        key_map = self._build_key_map()
        matcher = self.matcher(query)

        for title, help_text, callback, *_ in self.app.get_system_commands(self.screen):
            score = matcher.match(title)
            if score > 0:
                highlighted = matcher.highlight(title)
                key = self._find_key(callback, key_map)
                enriched = _format_key_hint_content(highlighted, key)
                yield Hit(
                    score,
                    enriched,
                    callback,
                    text=title,
                    help=help_text,
                )

    _ACTION_ALIASES: dict[str, str] = {
        "show_sessions": "manage_history_sessions",
    }

    def _build_key_map(self) -> dict[str, str]:
        action_to_key: dict[str, str] = {}
        for _key, binding in self.app._bindings:
            action_to_key[binding.action] = binding.key
        for _key, binding in self.screen._bindings:  # noqa: SLF001
            action_to_key[binding.action] = binding.key
        return action_to_key

    def _find_key(self, callback: object, action_to_key: dict[str, str]) -> str | None:
        if not hasattr(callback, "__func__"):
            return None
        callback_func = callback.__func__
        for action_name, key in action_to_key.items():
            action_method_name = f"action_{action_name}"
            action_method = getattr(self.app, action_method_name, None)
            if action_method is None:
                continue
            if callback_func is action_method.__func__:
                return key
            alias = self._ACTION_ALIASES.get(action_name)
            if alias:
                alias_method = getattr(self.app, f"action_{alias}", None)
                if alias_method and callback_func is alias_method.__func__:
                    return key
        return None
