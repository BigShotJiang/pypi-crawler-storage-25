"""Command palette component for slash commands."""

from textual.containers import Vertical, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Input, Label, ListItem, ListView, Static

from tinychat.utils.i18n import _


class CommandPaletteScreen(ModalScreen):
    """Modal screen showing available slash commands."""

    def __init__(self):
        super().__init__()
        self.commands = []

    def compose(self):
        yield Vertical(
            Static(_("Command Palette"), classes="command-palette-title"),
            Input(placeholder=_("Type command or tool name..."), id="command-filter"),
            Static(
                _("Press ↑/↓ to navigate, Enter to select, Escape to cancel"),
                classes="command-palette-hint",
            ),
            ListView(id="command-list"),
            classes="command-palette-container",
        )

    async def on_mount(self):
        await self._load_commands()
        self.query_one("#command-filter").focus()

    async def _load_commands(self) -> None:
        """Load available commands."""
        self.commands = [
            {
                "name": "/compact",
                "description": _("Compact conversation history"),
                "category": "system",
                "icon": "📦",
            },
            {
                "name": "/search",
                "description": _("Search your questions"),
                "category": "system",
                "icon": "🔍",
            },
        ]
        await self._update_list("")

    async def _update_list(self, filter_text: str):
        filtered = [
            cmd
            for cmd in self.commands
            if filter_text.lower() in cmd["name"].lower()
            or filter_text.lower() in cmd["description"].lower()
        ]
        list_view = self.query_one("#command-list", ListView)
        await list_view.clear()
        for cmd in filtered:
            list_item = ListItem(
                Horizontal(
                    Label(cmd["icon"], classes="command-icon"),
                    Label(cmd["name"], classes="command-name"),
                    Label(cmd["description"], classes="command-description"),
                    classes="command-item-content",
                ),
                classes="command-item",
            )
            await list_view.append(list_item)

    async def on_input_changed(self, event: Input.Changed):
        await self._update_list(event.value)

    def on_key(self, event):
        """Handle key events to navigate between Input and ListView."""
        if event.key == "escape":
            self.dismiss(None)
            return
        if event.key in ("down", "up"):
            if self.query_one("#command-filter").has_focus:
                event.prevent_default()
                event.stop()  # Stop event propagation to prevent ListView from handling it
                list_view = self.query_one("#command-list")
                list_view.focus()
                if list_view.children:
                    if event.key == "down":
                        list_view.index = 0
                    else:
                        list_view.index = len(list_view.children) - 1

    def on_list_view_selected(self, event: ListView.Selected):
        index = event.list_view.index
        selected = self.commands[index]
        self.dismiss(selected)
