"""Sidebar component for displaying backends and models using Textual."""

from collections import namedtuple
from typing import ClassVar

from rich.text import Text
from textual.message import Message
from textual.reactive import reactive
from textual.widgets import Static

from tinychat.utils.i18n import _

_BindingTuple = namedtuple("_BindingTuple", ["key", "binding"])


class _IterableBindingsMap:
    def __init__(self, bindings_map) -> None:
        self._map = bindings_map
        self.keys = bindings_map.shown_keys

    def __iter__(self):
        for key, binding in self._map:
            yield _BindingTuple(key=key, binding=binding)

    def __getattr__(self, name):
        return getattr(self._map, name)

    def __getitem__(self, key):
        return self._map[key]

    def __contains__(self, key):
        return key in self._map


class BackendSwitchRequested(Message):
    def __init__(self, backend_name: str) -> None:
        self.backend_name = backend_name
        super().__init__()


class ModelSwitchRequested(Message):
    def __init__(self, model_name: str) -> None:
        self.model_name = model_name
        super().__init__()


class QuestionJumpRequested(Message):
    def __init__(self, message_index: int) -> None:
        self.message_index = message_index
        super().__init__()


BackendSwitchRequested.handler_name = "on_backend_switch_requested"
ModelSwitchRequested.handler_name = "on_model_switch_requested"
QuestionJumpRequested.handler_name = "on_question_jump_requested"


class Sidebar(Static):
    """Component to display backends and selected model."""

    can_focus = False

    BINDINGS: ClassVar[list] = [
        ("up", "cursor_up", _("Navigate up")),
        ("down", "cursor_down", _("Navigate down")),
        ("enter", "cursor_select", _("Select")),
    ]

    DEFAULT_CSS = """
    Sidebar {
        min-width: 35;
        padding: 1;
        background: $panel;
        color: $text;
    }

    Sidebar {
        /* --cursor used for cursor indicator: ► */
    }
    """

    backends: reactive[list[str]] = reactive([], layout=True)
    selected_backend_idx: reactive[int] = reactive(0, layout=True)
    selected_model: reactive[str] = reactive("", layout=True)
    cursor_section: reactive[str] = reactive("backend", layout=True)
    selected_model_idx: reactive[int] = reactive(0, layout=True)
    mode: reactive[str] = reactive("backend")
    navigation_questions: reactive[list[str]] = reactive(list)
    navigation_message_indices: reactive[list[int]] = reactive(list)
    navigation_cursor: reactive[int] = reactive(0)

    def __init__(self, backends: list[str] | None = None, **kwargs):
        """Initialize Sidebar with optional backends list."""
        super().__init__(**kwargs)
        self.available_models: list[str] = []
        if backends is not None:
            self.backends = backends
        orig_bindings = object.__getattribute__(self, "_bindings")
        object.__setattr__(self, "_bindings", _IterableBindingsMap(orig_bindings))

    def focus(self, scroll_visible: bool = True) -> None:
        self.can_focus = True
        super().focus(scroll_visible=scroll_visible)

    def on_click(self, event) -> None:
        self.can_focus = True
        self.focus()

    def render(self) -> Text:
        """Render the sidebar content."""
        if self.mode == "navigation":
            return self._render_navigation()

        text = Text()

        backends_title = f" {_('Backends')} "
        text.append(
            self._center_line("═" * 3 + backends_title + "═" * 3) + "\n", style="bold"
        )

        for idx, backend in enumerate(self.backends):
            if self.cursor_section == "backend" and idx == self.selected_backend_idx:
                text.append("► ", style="bold")
                text.append(self._center_text(backend) + "\n")
            else:
                text.append("  ")
                text.append(self._center_text(backend) + "\n")

        text.append("\n")
        models_title = f" {_('Models')} "
        text.append(
            self._center_line("═" * 3 + models_title + "═" * 3) + "\n", style="bold"
        )

        if self.available_models:
            for idx, model in enumerate(self.available_models):
                if self.cursor_section == "model" and idx == self.selected_model_idx:
                    text.append("► ", style="bold")
                    text.append(self._center_text(model) + "\n")
                else:
                    text.append("  ")
                    text.append(self._center_text(model) + "\n")
        elif self.selected_model:
            text.append("  ")
            text.append(self._center_text(self.selected_model) + "\n")

        return text

    def _render_navigation(self) -> Text:
        text = Text()
        questions_title = f" {_('Questions')} "
        text.append(
            self._center_line("═" * 3 + questions_title + "═" * 3) + "\n", style="bold"
        )

        if not self.navigation_questions:
            text.append("  ")
            text.append(self._center_text(_("No questions")) + "\n")
            return text

        for idx, question in enumerate(self.navigation_questions):
            if idx == self.navigation_cursor:
                text.append("► ", style="bold")
            else:
                text.append("  ")
            text.append(self._center_text(self._truncate_text(question)) + "\n")

        return text

    @staticmethod
    def _truncate_text(text: str, max_display_width: int = 30) -> str:
        display_width = 0
        for i, char in enumerate(text):
            char_width = 2 if "\u4e00" <= char <= "\u9fff" else 1
            if display_width + char_width > max_display_width - 3:
                return text[:i] + "..."
            display_width += char_width
        return text

    @staticmethod
    def _center_text(text: str, width: int = 31) -> str:
        display_width = 0
        for char in text:
            char_width = 2 if "\u4e00" <= char <= "\u9fff" else 1
            display_width += char_width
        if display_width >= width:
            return text
        padding = (width - display_width) // 2
        return " " * padding + text

    @staticmethod
    def _center_line(text: str, width: int = 33) -> str:
        display_width = 0
        for char in text:
            char_width = 2 if "\u4e00" <= char <= "\u9fff" else 1
            display_width += char_width
        if display_width >= width:
            return text
        padding = (width - display_width) // 2
        return " " * padding + text

    def action_cursor_up(self) -> None:
        if self.mode == "navigation":
            if self.navigation_cursor > 0:
                self.navigation_cursor -= 1
            return
        if self.cursor_section == "backend":
            if self.selected_backend_idx > 0:
                self.selected_backend_idx -= 1
        elif self.cursor_section == "model":
            if self.selected_model_idx > 0:
                self.selected_model_idx -= 1
            else:
                self.cursor_section = "backend"

    def action_cursor_down(self) -> None:
        if self.mode == "navigation":
            if self.navigation_cursor < len(self.navigation_questions) - 1:
                self.navigation_cursor += 1
            return
        if self.cursor_section == "backend":
            if self.selected_backend_idx < len(self.backends) - 1:
                self.selected_backend_idx += 1
            elif self.available_models:
                self.cursor_section = "model"
                self.selected_model_idx = 0
        elif self.cursor_section == "model":
            if self.selected_model_idx < len(self.available_models) - 1:
                self.selected_model_idx += 1

    def action_cursor_select(self) -> None:
        if self.mode == "navigation":
            if self.navigation_questions and 0 <= self.navigation_cursor < len(
                self.navigation_questions
            ):
                global_index = self.navigation_message_indices[self.navigation_cursor]
                self.post_message(QuestionJumpRequested(message_index=global_index))
            return
        if self.cursor_section == "backend":
            backend_name = self.get_selected_backend()
            if backend_name:
                self.post_message(BackendSwitchRequested(backend_name=backend_name))
        elif self.cursor_section == "model":
            if self.available_models and 0 <= self.selected_model_idx < len(
                self.available_models,
            ):
                model_name = self.available_models[self.selected_model_idx]
                self.post_message(ModelSwitchRequested(model_name=model_name))

    def get_selected_backend(self) -> str:
        """Get the currently selected backend name."""
        if 0 <= self.selected_backend_idx < len(self.backends):
            return self.backends[self.selected_backend_idx]
        return ""

    def get_selected_model(self) -> str:
        """Get the selected model name."""
        return self.selected_model

    def set_selected_backend(self, name: str) -> None:
        """Set the selected backend by name."""
        try:
            idx = self.backends.index(name)
            self.selected_backend_idx = idx
        except ValueError:
            pass

    def set_selected_model(self, name: str) -> None:
        """Set the selected model name."""
        self.selected_model = name

    def set_available_models(self, models: list[str]) -> None:
        """Set the list of available models."""
        self.available_models = models
        self.refresh()
