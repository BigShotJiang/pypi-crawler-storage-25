"""Session rename dialog - mirrors OpenCode's DialogSessionRename."""

from __future__ import annotations

from typing import ClassVar

from textual import on
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container
from textual.screen import ModalScreen
from textual.widgets import Input, Label

from tinychat.utils.i18n import _


class RenameSessionScreen(ModalScreen[str | None]):
    """Modal dialog for renaming a session.

    Mirrors OpenCode's DialogSessionRename:
    - Title: "Rename Session"
    - Pre-filled with current session title
    - Enter: confirm rename
    - Escape: cancel
    """

    BINDINGS: ClassVar[list] = [
        Binding("escape", "cancel", ""),
    ]

    DEFAULT_CSS = """
    RenameSessionScreen {
        align: center middle;
    }

    #rename-dialog {
        width: 60;
        height: auto;
        border: thick $primary;
        background: $surface;
        padding: 1 2;
    }

    #rename-dialog-title {
        text-style: bold;
        height: 1;
        margin-bottom: 1;
    }

    #rename-input {
        height: 3;
        margin-bottom: 1;
    }

    #rename-hint {
        color: $text-muted;
        height: 1;
    }
    """

    def __init__(self, session_id: str, current_title: str) -> None:
        super().__init__()
        self._session_id = session_id
        self._current_title = current_title

    def compose(self) -> ComposeResult:
        with Container(id="rename-dialog"):
            yield Label(_("Rename Session"), id="rename-dialog-title")
            yield Input(
                value=self._current_title,
                id="rename-input",
            )
            yield Label(_("enter: confirm · escape: cancel"), id="rename-hint")

    def on_mount(self) -> None:
        inp = self.query_one("#rename-input", Input)
        inp.focus()
        inp.action_select_all()

    @on(Input.Submitted, "#rename-input")
    def _on_submit(self, event: Input.Submitted) -> None:
        new_title = event.value.strip()
        if new_title and new_title != self._current_title:
            self.dismiss(new_title)
        else:
            self.dismiss(None)

    def action_cancel(self) -> None:
        self.dismiss(None)
