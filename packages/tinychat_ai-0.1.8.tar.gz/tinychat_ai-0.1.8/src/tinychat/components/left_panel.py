"""Left panel container for ChatView and InputArea."""

from textual.containers import Vertical


class LeftPanel(Vertical):
    """Container for ChatView and InputArea on the left side of the layout.

    This container ensures ChatView and InputArea stay together on the left
    side when Sidebar is shown on the right.
    """
