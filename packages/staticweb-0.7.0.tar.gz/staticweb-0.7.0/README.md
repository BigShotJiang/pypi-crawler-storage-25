# StaticWeb

A fast, multi-threaded CLI tool to scrape static websites.

## Installation

pip install staticweb

## Usage

sw https://example.com --link

## Features

- Extract links (--link)
- Extract paragraphs (--para)
- Extract full text (--all)
- Extract custom tags (--tag h1)
- JSON output (--json)
- Save output (--save file.txt)
- Multi-threaded (--threads)
- Rich UI with progress bar

## Example

sw https://example.com --para
sw https://example.com --tag h1
sw https://example.com --link --json

## Disclaimer

Use responsibly. Respect website terms and robots.txt.