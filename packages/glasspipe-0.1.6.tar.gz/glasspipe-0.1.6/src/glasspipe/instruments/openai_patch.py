"""Monkey-patch for openai.chat.completions.create (sync only)."""
import sys
import time
from typing import Any

from glasspipe.trace import _current_run_id, _current_span_id, _new_id, _safe_write
from glasspipe import storage

_PRICING: dict[str, tuple[float, float]] = {
    "gpt-4o":        (2.50,  10.00),
    "gpt-4o-mini":   (0.15,   0.60),
    "gpt-4-turbo":   (10.00, 30.00),
    "gpt-3.5-turbo": (0.50,   1.50),
    "o3-mini":       (1.10,   4.40),
    "o4-mini":       (1.10,   4.40),
    "gpt-4.1":       (2.00,   8.00),
    "gpt-4.1-mini":  (0.40,   1.60),
    "gpt-4.1-nano":  (0.10,   0.40),
}


def _normalize_model(model: str) -> str:
    if not model:
        return model
    base = model.split("-202")[0].split("-2024")[0].split("-2025")[0]
    return base

_original = None


def _compute_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    inp, out = _PRICING.get(model, _PRICING.get(_normalize_model(model), (0.0, 0.0)))
    return (prompt_tokens * inp + completion_tokens * out) / 1_000_000


def _make_wrapper(original):
    def wrapper(self, *args, **kwargs):
        if _current_run_id.get() is None:
            return original(self, *args, **kwargs)

        span_id = _new_id()
        run_id = _current_run_id.get()
        parent_span_id = _current_span_id.get()
        messages = kwargs.get("messages") or (args[0] if args else None)
        model = kwargs.get("model") or (args[1] if len(args) > 1 else "unknown")

        _safe_write(
            storage.write_span_start,
            span_id, run_id, parent_span_id, "llm", "openai.chat.completions",
        )
        token = _current_span_id.set(span_id)
        t0 = time.monotonic()
        status = "ok"
        error_message = None
        response = None
        try:
            response = original(self, *args, **kwargs)
            return response
        except Exception as exc:
            status = "error"
            error_message = str(exc)
            raise
        finally:
            latency_ms = round((time.monotonic() - t0) * 1000, 2)
            _current_span_id.reset(token)

            prompt_tokens = 0
            completion_tokens = 0
            output_text = None
            is_stream = kwargs.get("stream", False)
            if response is not None:
                try:
                    usage = response.usage
                    prompt_tokens = usage.prompt_tokens
                    completion_tokens = usage.completion_tokens
                    model = response.model or model
                    output_text = response.choices[0].message.content
                except Exception:
                    pass

            meta = {
                "model": model,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "latency_ms": latency_ms,
                "cost_usd": _compute_cost(model, prompt_tokens, completion_tokens),
            }
            if is_stream:
                meta["stream"] = True

            _safe_write(
                storage.write_span_end,
                span_id,
                status,
                messages,
                {"text": output_text},
                meta,
                error_message,
            )

    return wrapper


def patch() -> None:
    global _original
    if _original is not None:
        return
    try:
        import openai.resources.chat.completions as _mod
        _original = _mod.Completions.create
        _mod.Completions.create = _make_wrapper(_original)
    except ImportError:
        pass


def unpatch() -> None:
    global _original
    if _original is None:
        return
    try:
        import openai.resources.chat.completions as _mod
        _mod.Completions.create = _original
        _original = None
    except ImportError:
        pass
