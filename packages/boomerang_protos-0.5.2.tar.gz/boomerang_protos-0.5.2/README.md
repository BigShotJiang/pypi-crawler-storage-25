# boomerang-protos (Python)

Generated Python protobuf + gRPC stubs for Boomerang shared protos.

```bash
pip install boomerang-protos
```

```python
from boomerang_protos_gen.boomerang.relationship.v1 import relationship_pb2
```
