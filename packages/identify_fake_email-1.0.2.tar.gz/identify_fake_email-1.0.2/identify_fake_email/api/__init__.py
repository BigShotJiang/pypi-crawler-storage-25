# flake8: noqa

# import apis into api package
from identify_fake_email.api.default_api import DefaultApi

