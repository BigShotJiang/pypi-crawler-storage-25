# identify-fake-email

PAID API - Free tier: 100 requests/month

Detect fake, disposable, and temporary email addresses using machine learning.

Features:

- Syntax validation (RFC 5322 compliant)
- MX record verification (domain can receive emails)
- Disposable email detection (temporary email providers)
- Role account detection (admin@, sales@, support@)
- ML-powered risk scoring (name_risk and domain_risk)
- New domain detection (registered less than 30 days)

Installation:

pip install identify-fake-email

Quick Start:

from identify_fake_email import EmailValidatorClient

client = EmailValidatorClient("YOUR_RAPIDAPI_KEY")
result = client.validate_email("user@example.com")

print(f"Valid: {result.valid_email}")
print(f"Risk score: {result.name_risk}")

if result.valid_email and result.name_risk < 0.7:
    print("Safe to accept")
else:
    print("Suspicious - review")

Response Fields:

- valid_email_structure: Passes syntax check
- mx_records: Domain has mail servers
- not_disposable: Not a temporary email
- new_domain: Domain registered less than 30 days
- is_role: Role-based address
- name_risk: ML score 0-1 (higher = riskier)
- domain_risk: ML score 0-1 (higher = riskier)
- valid_email: Overall validation result (not including name_risk, domain_risk)

Get an API Key:

https://rapidapi.com/JP1V/api/email-validator-syntax-mx-disposable-risk-detection

Links:

- API Documentation: https://jp1v.github.io/email-validator-openapi/
- GitHub: https://github.com/JP1V/email-validator-openapi
- RapidAPI: https://rapidapi.com/JP1V/api/email-validator-syntax-mx-disposable-risk-detection

License: MIT