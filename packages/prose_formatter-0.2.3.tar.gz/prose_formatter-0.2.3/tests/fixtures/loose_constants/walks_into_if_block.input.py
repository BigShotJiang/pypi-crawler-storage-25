"""
The walker descends into top-level `if` / `for` / `try` bodies
because those preserve module scope. A `SCREAMING_CASE`
assignment guarded by `if sys.platform == ...` is still
module-level and draws the diagnostic.
"""

import sys

if sys.platform == "win32":
    DEFAULT_BACKEND = "memory"
