"""
A multi-entry dict squashed onto one line strips every entry's
pre-`:` padding, since same-line `:`s have no column to align
against. The same dict spread across multiple lines belongs to
`align_colons` and stays padded for that pass to handle.
"""

oneline = {"first" : 1, "second" : 2, "third" : 3}

multiline = {
    "first"  : 1,
    "second" : 2,
}
