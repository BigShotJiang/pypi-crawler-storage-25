"""
Inputs that interleave singleton contexts with multi-item groups
across all four shapes: class fields, dict literals, function
parameters. Singletons strip their pre-`:` padding. Multi-line
multi-item groups stay padded for `align_colons` to align. A
multi-item group squashed onto a single line strips its padding
too, because same-line `:`s have no column to align against.
"""

class Solo:
    only_field : str


class Pair:
    first  : str
    second : int


single_dict = {"key" : "value"}

paired_dict = {
    "first"  : 1,
    "second" : 2,
}


def lone_param(x : int) -> int:
    return x


def two_params(first : int, second : str) -> str:
    return ""
