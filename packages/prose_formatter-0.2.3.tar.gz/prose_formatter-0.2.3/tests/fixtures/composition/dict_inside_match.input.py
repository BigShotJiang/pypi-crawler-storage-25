"""
A `match` whose single-statement arms each return a long inline
dict that exceeds the line budget once it lands on its arm line.
No key reordering — the rule list excludes alphabetize.

Rules:
- collection_layout
- match_case_align
- align_colons
"""


def dispatch(kind):
    match kind:
        case "alpha":
            return {"name": "alpha", "weight": 1, "extra_field": True, "comment_text": "primary"}
        case "beta":
            return {"name": "beta", "weight": 2, "extra_field": False, "comment_text": "secondary"}
        case _:
            return None
