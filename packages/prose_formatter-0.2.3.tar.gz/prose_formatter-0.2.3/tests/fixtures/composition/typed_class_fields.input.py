"""
A class whose annotated fields use `Optional` and `Union` from
`typing`.

Rules:
- align_colons
- align_equals
"""

from typing import Optional, Union


class Endpoint:
    host: Optional[str] = None
    port: Union[int, str] = 0
    fallback_host: Optional[str] = "localhost"
    retry_count: Union[int, None] = 3
