"""
A trailing comma followed by a same-line comment loses only the
comma. A comment that sits between the last element and the closing
bracket also rides through unchanged because the backward scan
treats comments as trivia before checking for a comma.
"""

posting = Posting(
    company="Cianbro",
    date_posted=None,
    title="Electrician",  # primary listing title
)

retired = [
    "INST_2014_0007",
    "INST_2018_0033",
    # legacy identifier kept for audit history
]
