"""
A run whose widest module overshoots the default `max-shift = 8`
greedily partitions into contiguous sub-groups under the default
`split` policy. Each sub-group aligns at its own column, so an
outlier line does not drag its short neighbors across the page.
"""

from io import BytesIO
from re import sub
from os import getenv
from collections.abc.mapping_helpers.namespaced import OrderedDict
from sys import path
from os.path import join
