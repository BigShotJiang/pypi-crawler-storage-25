"""
A list that mixes every atomic expression flavor, namely literals,
names, attribute chains, and unary operations over atomic operands.
Atomic items flow together in balanced lines. A call expression in
the middle of the list is non-atomic and breaks its surrounding run
into two independent flow segments that each balance on their own.
"""

mixed_atomics = [1, "two", None, True, alpha, beta, pkg.CONST, cls.name.upper, -1, +5, not ready, ~mask, gamma, delta, epsilon, zeta]
split_by_call = ["first", "second", "third", "fourth", "fifth", lookup(), "seventh", "eighth", "ninth", "tenth", "eleventh"]
