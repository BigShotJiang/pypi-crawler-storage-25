"""
Tuples are out of scope for this rule. `Expr::Tuple` is not matched
by `item_count`, so a multi-item tuple stays inline whether it is
parenthesized or bare. The visitor still descends through the
tuple's elements via `walk_expr`, so a qualifying inner collection
inside a tuple expands when it overflows the budget at its own column.
"""

paren_tuple = (1, 2, 3)
bare_tuple = 4, 5, 6
qualifying_inner_in_tuple = (1, {"first_key": 100, "second_key": 200, "third_key": 300, "fourth_key": 400, "fifth_key": 500}, 3)
