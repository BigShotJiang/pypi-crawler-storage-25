"""
A comment sitting between two statements is treated as the second
statement's leading block. The rule normalizes the canonical gap
above the comment and 1 blank line between the comment and the
following statement, regardless of the source's blank-count drift.
"""


def first():
    return 1


# detached header




def second():
    return 2
