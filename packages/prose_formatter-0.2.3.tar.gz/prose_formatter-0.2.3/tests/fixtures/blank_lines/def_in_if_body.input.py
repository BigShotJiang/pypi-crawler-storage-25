"""
Defs sitting inside an `if` block at module level do not pair-count.
The walker descends into the if body to find nested classes and
functions but applies no canonical rule at the if-body indentation.
"""


if FEATURE_X:
    def alpha():
        return 1
    def beta():
        return 2
