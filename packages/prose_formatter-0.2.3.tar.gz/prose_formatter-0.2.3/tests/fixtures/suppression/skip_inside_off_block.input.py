"""
A fmt: skip line sits inside an active fmt: off block. Every line
within the block stays verbatim, leaving the assignment runs above
and below the block to align as separate groups.
"""

x = 1
foo = 2
bar_baz = 3

# fmt: off
short = 1
inside = 2  # fmt: skip
mid = 3
# fmt: on

a = 1
bb = 2
ccc = 3
