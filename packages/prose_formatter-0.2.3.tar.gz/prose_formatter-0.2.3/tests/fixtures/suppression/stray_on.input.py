"""
A bare fmt: on with no preceding fmt: off is a no-op. Every
assignment in the file is eligible for alignment.
"""

x = 1
foo = 2
bar_baz = 3

# fmt: on

aa = 1
bbb = 2
cccc = 3
