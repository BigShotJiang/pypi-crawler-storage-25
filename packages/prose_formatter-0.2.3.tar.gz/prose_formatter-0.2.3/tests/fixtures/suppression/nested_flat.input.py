"""
Two consecutive fmt: off directives flatten, with the first
fmt: on closing the block. The second fmt: off does not nest, so
text after the closing fmt: on aligns normally.
"""

x = 1
foo = 2
bar_baz = 3

# fmt: off
short = 1
# fmt: off
much_longer_name = 2
mid = 3
# fmt: on

a = 1
bb = 2
ccc = 3
