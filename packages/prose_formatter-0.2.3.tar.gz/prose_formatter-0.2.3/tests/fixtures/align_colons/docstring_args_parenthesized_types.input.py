"""
Google-style `Args:` entries with parenthesized type hints. The
colon detector skips past the `(...)` group, so alignment anchors
on the `:` that follows the closing paren rather than any colons
that might sit inside the parens.
"""

def schedule(when: float, action: str, retries: int) -> None:
    """
    Queues an action.

    Args:
        when (float): unix timestamp.
        action (str): callable name to dispatch.
        retries (int): number of retry attempts on failure.
    """
    _enqueue(when, action, retries)
