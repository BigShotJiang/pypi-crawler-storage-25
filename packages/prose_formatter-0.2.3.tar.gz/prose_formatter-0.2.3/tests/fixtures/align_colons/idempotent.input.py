"""
Input that is already aligned. The rule recognizes each gap as
already carrying its target width of spaces and emits zero edits,
so the output text equals the input text byte-for-byte and the
pipeline reports no change.
"""

CAPITALS = {
    "USA"    : "Washington",
    "France" : "Paris",
    "Japan"  : "Tokyo",
    "Spain"  : "Madrid",
}


class User:
    id        : int
    name      : str
    email     : str
    is_active : bool


def register(
    request_id : str,
    user       : User,
    priority   : int,
) -> None:
    """
    Registers the user.

    Args:
        request_id : correlation id.
        user       : subject of registration.
        priority   : dispatch ordering.
    """
    pass
