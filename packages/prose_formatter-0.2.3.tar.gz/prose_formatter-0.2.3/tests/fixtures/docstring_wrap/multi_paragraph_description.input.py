"""
Two description paragraphs separated by a blank line wrap each
paragraph independently. The blank line between paragraphs is
preserved verbatim through the rewrite.
"""


def render():
    """
    First paragraph that is short.

    Second paragraph here that runs on much longer and exceeds the seventy six character docstring budget by a margin to force a wrap.
    """
    return 1
