"""
A `.config.toml` sidecar flips `docstring-structured-policy` to the
docstring budget so structured sections wrap at seventy six rather
than the default eighty eight.
"""


def configure(name, retries):
    """
    Summary line.

    Args:
        name: A descriptive name that exceeds the seventy six character docstring budget when the policy selects that budget for structured sections.
        retries: Number of retry attempts.
    """
    return name, retries
