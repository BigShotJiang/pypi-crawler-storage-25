"""
A Returns section wraps to the section budget so the return-value
description tracks the same horizontal room the Args table uses.
"""


def total(items):
    """
    Summary line.

    Returns:
        The running total of every numeric value the caller passed in, computed by adding each item to the accumulator in source order.
    """
    return sum(items)
