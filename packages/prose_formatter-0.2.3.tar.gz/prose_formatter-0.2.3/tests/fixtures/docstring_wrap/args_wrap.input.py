"""
A long Args entry wraps to the eighty eight character section budget rather
than the narrower description budget, so parameter tables retain the same
horizontal room code lines carry.
"""


def configure(name, retries):
    """
    Summary line.

    Args:
        name: A descriptive name that exceeds the section budget when written out in a single line because it explains the parameter at length.
        retries: Number of retry attempts the caller wants before giving up.
    """
    return name, retries
