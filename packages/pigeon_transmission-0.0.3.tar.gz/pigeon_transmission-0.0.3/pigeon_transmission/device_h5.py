"""
device_h5.py

This library provides a high-level interface for communicating with IMT Analytics CITREX measurement
devices via serial connection. It supports executing commands, reading and writing settings,
retrieving measurements, system states, system information and using the imt protocol.
It is not an official library provided or endorsed by IMT Analytics.

Author: Dennis Schramm
Date: 17.05.2026
Version: 0.0.3
Python-version: 3.10
Coding conventions: Is complied with PEP8 Style Guide for Python Code. E501 max line length is ignored.
"""
import serial
import copy
import time
import re


message_core_structure = {  # the standard syntax for a msg
    "start_token": ['%', 1],
    "operation": [None, None],
    "separator_token": ['#', 1],
    "operation_identifier": [None, None]
}

message_value_optional = {  # the syntax when a msg or response has a value
    "value_prefix": ['$', 1],
    "value": [None, None]
}

message_terminator = {  # the standard syntax for terminator
    "end_token": ['\r', 1]
}

message_value_mapping = {  # Overview of whether a command and a response can contain a value
    "CM": {"command_has_value": None, "response_has_value": None},  # None mean its variable (exist or not)
    "WS": {"command_has_value": True, "response_has_value": True},  # True means a value exist
    "RS": {"command_has_value": False, "response_has_value": True},  # False mean a value do not exist
    "RM": {"command_has_value": False, "response_has_value": True},
    "RI": {"command_has_value": False, "response_has_value": True},
    "ST": {"command_has_value": False, "response_has_value": True}
}

stream_protocol_specs = {
    "stream": {"baudrate": 19200, "msg length": 9},
    "fast stream": {"baudrate": 115200, "msg length": 27}
}

execute_command_dictionary = {  # this dict translate the string for the operation identifier and contain the conversion factor
    "start pressure/flow offset adjust": {"operation_identifier": 1, "conversion_factor": None},
    "start oxygen calibration": {"operation identifier": 2, "conversion_factor": None},
    "next calibration step": {"operation_identifier": 3, "conversion_factor": None},
    "stop running calibration": {"operation_identifier": 4, "conversion_factor": None},
    "switch echo": {"operation_identifier": 5, "conversion_factor": None, "value": {
        "off": 0,
        "on": 1}},
    "start stream": {"operation_identifier": 64, "conversion_factor": None},
    "stop stream": {"operation_identifier": 65, "conversion_factor": None},
    "start automated zero calibration": {"operation_identifier": 66, "conversion_factor": None, "range": {"min": 1, "max": 1}},
    "screen": {"operation_identifier": 67, "conversion_factor": None, "value": {
        "unlocked": 0,
        "locked": 1}},
    "touch": {"operation_identifier": 68, "conversion_factor": None, "value": {
        "unlocked": 0,
        "locked": 1}}
}

read_measurement_dictionary = {  # this dict translate the string for the operation identifier and contain the conversion factor
    "high flow": {"operation_identifier": 0, "conversion_factor": 10, "range": {"min": -3000, "max": 3000}},
    "differential pressure": {"operation_identifier": 3, "conversion_factor": 100, "range": {"min": -15000, "max": 15000}},
    "pressure high flow": {"operation_identifier": 4, "conversion_factor": 100, "range": {"min": 0, "max": 15000}},
    "volume high flow": {"operation_identifier": 6, "conversion_factor": 10, "range": {"min": 0, "max": 65536}},
    "current breath phase": {"operation_identifier": 8, "conversion_factor": 1, "range": {"min": 0, "max": 1}, "value": {
        "expiration": 0,
        "inspiration": 1}},
    "oxygen": {"operation_identifier": 9, "conversion_factor": 10, "range": {"min": 0, "max": 1100}},
    "temperature": {"operation_identifier": 11, "conversion_factor": 10, "range": {"min": 0, "max": 1000}},
    "high pressure": {"operation_identifier": 13, "conversion_factor": 1, "range": {"min": 0, "max": 10000}},
    "ambient pressure": {"operation_identifier": 14, "conversion_factor": 1, "range": {"min": 0, "max": 1150}},
    "inspiration time": {"operation_identifier": 19, "conversion_factor": 100, "range": {"min": 20, "max": 6000}},
    "expiration time": {"operation_identifier": 20, "conversion_factor": 100, "range": {"min": 20, "max": 6000}},
    "I:E Ratio": {"operation_identifier": 21, "conversion_factor": 10, "range": {"min": 1, "max": 3000}},
    "breath rate": {"operation_identifier": 22, "conversion_factor": 10, "range": {"min": 0, "max": 1500}},
    "volume inspiration": {"operation_identifier": 23, "conversion_factor": 1, "range": {"min": 0, "max": 10000}},
    "volume expiration": {"operation_identifier": 24, "conversion_factor": 1, "range": {"min": 0, "max": 10000}},
    "volume flow inspiration": {"operation_identifier": 25, "conversion_factor": 10, "range": {"min": 0, "max": 3000}},
    "volume flow expiration": {"operation_identifier": 26, "conversion_factor": 10, "range": {"min": 0, "max": 3000}},
    "peak pressure": {"operation_identifier": 27, "conversion_factor": 10, "range": {"min": 0, "max": 1500}},
    "mean pressure": {"operation_identifier": 28, "conversion_factor": 10, "range": {"min": 0, "max": 1500}},
    "peep": {"operation_identifier": 29, "conversion_factor": 10, "range": {"min": 0, "max": 1500}},
    "inspiratory time fraction": {"operation_identifier": 30, "conversion_factor": 10, "range": {"min": 0, "max": 1000}},
    "peak flow inspiration": {"operation_identifier": 31, "conversion_factor": 10, "range": {"min": -3000, "max": 3000}},
    "peak flown expiration": {"operation_identifier": 32, "conversion_factor": 10, "range": {"min": -3000, "max": 3000}},
    "plateau pressure": {"operation_identifier": 41, "conversion_factor": 10, "range": {"min": 0, "max": 1500}},
    # ## the range is not possible
    "compliance": {"operation_identifier": 42, "conversion_factor": 10, "range": {"min": 0, "max": 1000000}},
    "ipap": {"operation_identifier": 43, "conversion_factor": 10, "range": {"min": 0, "max": 1500}}
}

read_write_setting_dictionary = {  # this dict translate the string for the operation identifier and contain the conversion factor
    "gas type": {"operation_identifier": 1, "conversion_factor": None, "value": {
        "air": 0,
        "air o2 manually": 1,
        "air o2 automatically": 2,
        "n2o o2 manually": 3,
        "n2o o2 automatically": 4,
        "heliox": 5,
        "he o2 manually": 6,
        "he o2 automatically": 7,
        "n2": 8,
        "co2": 9,
        "custom": 10}},
    "manual oxygen concentration": {"operation_identifier": 2, "conversion_factor": 1, "range": {"min": 21, "max": 100}, "value": True},  # Note: "value" = True mean do not exist a translation - The value must be taken directly
    "gas standard": {"operation_identifier": 3, "conversion_factor": None, "value": {
        "atp": 0,
        "stp": 1,
        "btps": 2,
        "btpd": 3,
        "0/1013": 4,
        "20/981": 5,
        "15/1013": 6,
        "20/1013": 7,
        "25/991": 8,
        "ap21": 9,
        "stph": 10,
        "atpd": 11,
        "atps": 12,
        "btps-a": 13,
        "btpd-a": 14,
        "ntpd": 15,
        "ntps": 16}},
    "vol trigger response mode": {"operation_identifier": 4, "conversion_factor": None, "value": {
        "adult": 0,
        "pediatric": 1,
        "high_frequency": 2,
        "auto": 3}},
    "vol trigger trigger source": {"operation_identifier": 5, "conversion_factor": None, "value": {
        "internal high flow channel": 1,
        "external high flow channel": 3}},
    "vol trigger start trigger signal": {"operation_identifier": 6, "conversion_factor": None, "value": {
        "flow": 0,
        "pressure flow_channel": 1}},
    "vol trigger start trigger edge": {"operation_identifier": 7, "conversion_factor": None, "value": {
        "rising edge": 0,
        "falling edge": 1}},
    "vol trigger start trigger signal value": {"operation_identifier": 8, "conversion_factor": 10, "range": {"min": -2500, "max": 2500}, "value": True},  # Note: "value" = True mean do not exist a translation - The value must be taken directly
    "vol trigger end trigger signal": {"operation_identifier": 9, "conversion_factor": None, "value": {
        "flow": 0,
        "pressure": 1}},
    "vol trigger end trigger edge": {"operation_identifier": 10, "conversion_factor": None, "value": {
        "rising edge": 0,
        "falling edge": 1}},
    "vol trigger end trigger signal value": {"operation_identifier": 11, "conversion_factor": 10, "range": {"min": -2500, "max": 2500}, "value": True},  # Note: "value" = True mean do not exist a translation - The value must be taken directly
    "trigger delay": {"operation_identifier": 12, "conversion_factor": 1, "range": {"min": 10, "max": 120}, "value": True},
    "baseflow": {"operation_identifier": 13, "conversion_factor": None, "value": {
        "disabled": 0,
        "enabled": 1}},
    "baseflow volume trigger": {"operation_identifier": 14, "conversion_factor": 10, "range": {"min": -3000, "max": 3000}, "value": True},  # Note: "value" = True mean do not exist a translation - The value must be taken directly
    "filter type": {"operation_identifier": 15, "conversion_factor": None, "value": {
        "None": 0,
        "filter low": 1,
        "filter medium": 2,
        "filter high": 3}},
    "start trigger delay": {"operation_identifier": 19, "conversion_factor": 1, "range": {"min": 10, "max": 120}, "value": True},  # Note: "value" = True mean do not exist a translation - The value must be taken directly
    "end trigger delay": {"operation_identifier": 20, "conversion_factor": 1, "range": {"min": 10, "max": 120}, "value": True},  # Note: "value" = True mean do not exist a translation - The value must be taken directly
    "gas humidity": {"operation_identifier": 21, "conversion_factor": 1, "range": {"min": 0, "max": 100}, "value": True},  # Note: "value" = True mean do not exist a translation - The value must be taken directly
    "respiratory parameter pressure source": {"operation_identifier": 22, "conversion_factor": None, "value": {
        "pressure channel": 0,
        "differential pressure": 1,
        "high pressure": 2}},
    "dynamic pressure compensation": {"operation_identifier": 23, "conversion_factor": None, "value": {
        "disable": 0,
        "enable": 1}},
    "stream first value": {"operation_identifier": 64, "conversion_factor": None, "value": {key: value["operation_identifier"] for key, value in read_measurement_dictionary.items()}},  # use the operation identifier from read_measurement_dictionary
    "stream second value": {"operation_identifier": 65, "conversion_factor": None, "value": {key: value["operation_identifier"] for key, value in read_measurement_dictionary.items()}},  # use the operation identifier from read_measurement_dictionary
    "stream third value": {"operation_identifier": 66, "conversion_factor": None, "value": {key: value["operation_identifier"] for key, value in read_measurement_dictionary.items()}},  # use the operation identifier from read_measurement_dictionary
    "stream fourth value": {"operation_identifier": 160, "conversion_factor": None, "value": {key: value["operation_identifier"] for key, value in read_measurement_dictionary.items()}},
    "stream fifth value": {"operation_identifier": 161, "conversion_factor": None, "value": {key: value["operation_identifier"] for key, value in read_measurement_dictionary.items()}},
    "stream sixth value": {"operation_identifier": 162, "conversion_factor": None, "value": {key: value["operation_identifier"] for key, value in read_measurement_dictionary.items()}},
    "stream seventh value": {"operation_identifier": 163, "conversion_factor": None, "value": {key: value["operation_identifier"] for key, value in read_measurement_dictionary.items()}},
    "stream eighth value": {"operation_identifier": 164, "conversion_factor": None, "value": {key: value["operation_identifier"] for key, value in read_measurement_dictionary.items()}},
    "stream ninth value": {"operation_identifier": 165, "conversion_factor": None, "value": {key: value["operation_identifier"] for key, value in read_measurement_dictionary.items()}},
    "stream tenth value": {"operation_identifier": 166, "conversion_factor": None, "value": {key: value["operation_identifier"] for key, value in read_measurement_dictionary.items()}},
    "stream eleventh value": {"operation_identifier": 167, "conversion_factor": None, "value": {key: value["operation_identifier"] for key, value in read_measurement_dictionary.items()}},
    "stream_twelfth value": {"operation_identifier": 168, "conversion_factor": None, "value": {key: value["operation_identifier"] for key, value in read_measurement_dictionary.items()}},
    "usb mass storage": {"operation_identifier": 70, "conversion_factor": None, "value": {
        "disabled": 0,
        "enabled": 1}}
}

read_system_information_dictionary = {  # this dict translate the string for the operation identifier and contain the conversion factor
    "hardware version": {"operation_identifier": 1, "conversion_factor": None},
    "software major version": {"operation_identifier": 2, "conversion_factor": None},
    "software minor version": {"operation_identifier": 3, "conversion_factor": None},
    "software release": {"operation_identifier": 4, "conversion_factor": None},
    "last calibration day": {"operation_identifier": 5, "conversion_factor": None},
    "last calibration month": {"operation_identifier": 6, "conversion_factor": None},
    "last calibration year": {"operation_identifier": 7, "conversion_factor": None},
    "serial number": {"operation_identifier": 8, "conversion_factor": None},
    "next calibration day": {"operation_identifier": 9, "conversion_factor": None},
    "next calibration month": {"operation_identifier": 10, "conversion_factor": None},
    "next calibration year": {"operation_identifier": 11, "conversion_factor": None},
    "device type": {"operation_identifier": 12, "conversion_factor": None, "value": {
        "Invalid": 0,
        "Citrex H4": 1,
        "VT305": 2,
        "Citrex H5": 3,
        "Citrex H3": 4,
        "PF-300 Pro": 5,
        "Flowmeter F1": 6,
        "Flowmeter F2": 7}}
}

read_state_dictionary = {  # this dict translate the string for the operation identifier and contain the conversion factor
    "calibration state": {"operation_identifier": 1, "conversion_factor": None, "range": {"min": 0, "max": 27}, "value": {
        "Calibration state: idle": 0,
        "Calibration state: error during calibration": 1,
        "Oxygen calibration: waiting for 100pct oxygen": 2,
        "Oxygen calibration: reading 100pct oxygen": 3,
        "Oxygen calibration: waiting for 21pct oxygen": 4,
        "Oxygen calibration: reading 21pct oxygen": 5,
        "Oxygen calibration: finished, waiting for user acknowledge": 6,
        "Oxygen calibration: finished": 7,
        "Pressure/flow offset adjust: wait for user acknowledge": 8,
        "Pressure/flow offset adjust: reading offset": 9,
        "Pressure/flow offset adjust: finished, waiting for user acknowledge": 10,
        "Pressure/flow offset adjust: finished": 11,
        "Pressure sensor gain adjust: read offset, waiting for user acknowledge": 12,
        "Pressure sensor gain adjust: reading offset": 13,
        "Pressure sensor gain adjust: read high adjustment pressure 1, waiting for user acknowledge": 14,
        "Pressure sensor gain adjust: read high adjustment pressure 1": 15,
        "Pressure sensor gain adjust: read high adjustment pressure 2, waiting for user acknowledge": 16,
        "Pressure sensor gain adjust: read high adjustment pressure 2": 17,
        "Pressure sensor gain adjust: finished, waiting for user acknowledge": 18,
        "Pressure sensor gain adjust: finished": 19,
        "Flow calibration: next flow, waiting for user acknowledge": 20,
        "Flow calibration: read next flow": 21,
        "Flow calibration: finished, waiting for user acknowledge": 22,
        "Flow calibration: finished": 23,
        "Drift compensation: started": 24,
        "Drift compensation: read reference": 25,
        "Drift compensation: waiting for next temperature": 26,
        "Drift compensation: read temperature and offset": 27}}
}


class DeviceH5:
    def __init__(self, port: str | None = None, baudrate: int | None = None):
        """
        This method is used to initialize the class.
        """
        self.serial_interface = SerialInterface()
        self.io_validator = IOValidator()
        self.port = port  # Set the argument for port – Note: if it is not called with a with block, it will be None
        self.baudrate = baudrate  # set the argument for baud rate
        self.serial_object = None  # set the serial object

    def __enter__(self):
        """
        Context manager entry method.

        This method is automatically called when entering a `with` block.
        The serial interface is opened automatically

        Return:
            self (object): The current instance of the class
        """
        self.open_serial_interface(self.port, self.baudrate)  # open the serial object
        return self  # return

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Context manager exit method.

        This method is automatically called when leaving a `with` block.
        It ensures that the serial interface is properly closed, even if
        an exception occurs during execution inside the block.

        Args:
            exc_type (type): The exception type if an error occurred, else None
            exc_val (Exception): The exception instance if an error occurred, else None
            exc_tb (traceback): The traceback object if an error occurred, else None
        """
        self.close_serial_interface()  # close the serial port

    def open_serial_interface(self, port: str, baudrate: int) -> serial.Serial:
        """
        This method is used to open a serial interface.

        Args:
            port (str): The port where serial communication is to be established
            baudrate (int): The baudrate for the serial communication

        Return:
            serial_object (serial.Serial): The serial object of the session
        """
        allowed = [spec["baudrate"] for spec in stream_protocol_specs.values()]
        if baudrate not in allowed:
            raise ValueError(f"Invalid baudrate '{baudrate}'. Allowed baudrates are {allowed}")
        serial_object, e = self.serial_interface.open_port(port=port, baudrate=baudrate)  # call method for open serial port
        if serial_object is None:  # if serial Object is None
            raise ConnectionError(f"Error while open the serial port: {e}")  # raise a connection error
        self.serial_interface._get_echo_state(serial_object=serial_object)  # call the method for read the echo mode state and save as attribute of serial object
        self.serial_object = serial_object
        return serial_object  # return the serial object

    def close_serial_interface(self, serial_object: serial.Serial | None = None) -> None:
        """
        This method closed the serial object.

        Args:
            serial_object (serial.Serial | None): Optional - uses the instances serial object if omitted.
        """
        serial_object = serial_object or self.serial_object
        self.serial_interface.close_port(serial_object=serial_object)  # call the method for close the serial port

    def execute_command(self, operation_name: str, value: str | int | None = None, serial_object: serial.Serial | None = None) -> str | None:  # CM
        """
        This method is used to execute command(CM).

        Args:
            operation_name (str): The operation name of the command
            value (str | int | None): The value for the setting
            serial_object (serial.Serial | None): Optional - uses the instances serial object if omitted.

        Return:
            value (str | None): The return value of the response
        """
        serial_object = serial_object or self.serial_object
        result = self._handle_communication(operation="CM", operation_name=operation_name, value=value, dictionary=execute_command_dictionary, serial_object=serial_object)  # call the method
        if operation_name == "switch echo":
            serial_object.echo_state = True if value == "on" else False
        return result

    def write_setting(self, operation_name: str, value: str | int | None = None, serial_object: serial.Serial | None = None) -> str:  # WS
        """
        This method is used to write setting (WS).

        Args:
            operation_name (str): The operation name of the command
            value (str | int | None): The value for the setting
            serial_object (serial.Serial | None): Optional - uses the instances serial object if omitted.

        Return:
            value (str): The return value of the response
        """
        serial_object = serial_object or self.serial_object
        return self._handle_communication(operation="WS", operation_name=operation_name, value=value, dictionary=read_write_setting_dictionary, serial_object=serial_object)  # call the method

    def read_setting(self, operation_name: str, serial_object: serial.Serial | None = None) -> str:  # RS
        """
        This method is used to read setting (RS).

        Args:
            operation_name (str): The operation name of the command
            serial_object (serial.Serial | None): Optional - uses the instances serial object if omitted.

        Return:
            value (str): The return value of the response
        """
        serial_object = serial_object or self.serial_object
        return self._handle_communication(operation="RS", operation_name=operation_name, value=None, dictionary=read_write_setting_dictionary, serial_object=serial_object)  # call the method

    def read_measurement(self, operation_name: str, serial_object: serial.Serial | None = None) -> str:  # RM
        """
        This method is used to read measurement (RM).

        Args:
            operation_name (str): The operation name of the command
            serial_object (serial.Serial | None): Optional - uses the instances serial object if omitted.

        Return:
            value (str): The return value of the response
        """
        serial_object = serial_object or self.serial_object
        return self._handle_communication(operation="RM", operation_name=operation_name, value=None, dictionary=read_measurement_dictionary, serial_object=serial_object)  # call the method

    def read_system_information(self, operation_name: str, serial_object: serial.Serial | None = None) -> str:  # RI
        """
        This method is used to read system information (RI).

        Args:
            operation_name (str): The operation name of the command
            serial_object (serial.Serial | None): Optional - uses the instances serial object if omitted.

        Return:
            value (str): The return value of the response
        """
        serial_object = serial_object or self.serial_object
        return self._handle_communication(operation="RI", operation_name=operation_name, value=None, dictionary=read_system_information_dictionary, serial_object=serial_object)  # call the method

    def read_state(self, operation_name: str, serial_object: serial.Serial | None = None) -> str:  # ST
        """
        This method is used to read state (ST).

        Args:
            operation_name (str): The operation name of the command
            serial_object (serial.Serial | None): Optional - uses the instances serial object if omitted.

        Return:
            value (str): The return value of the response
        """
        serial_object = serial_object or self.serial_object
        return self._handle_communication(operation="ST", operation_name=operation_name, value=None, dictionary=read_state_dictionary, serial_object=serial_object)  # call the method

    def read_multiple_measurements(self, operation_name: str, sample_count: int | str | float, sample_rate: int | str | float, serial_object: serial.Serial | None = None) -> list:  # RM multiple
        """
        This method is used to read measurements (RM).

        Args:
            operation_name (str): The operation name of the command
            sample_count (int | str | float): The number of measured values
            sample_rate (int | str | float): The sample rate to use in Hz (min: 0.01 | max: 20)
            serial_object (serial.Serial | None): Optional - uses the instances serial object if omitted.

        Return:
            value (list): The return values of the response as list
        """
        serial_object = serial_object or self.serial_object
        sample_count = self.io_validator.validate_and_cast(value=sample_count, target_types=int, allowed_types=(str, float, int), min_value=1, max_value=999999)  # call the method for validate and cast the sample count
        sample_rate = self.io_validator.validate_and_cast(value=sample_rate, target_types=float, allowed_types=(str, float, int), min_value=0.01, max_value=20)  # call the method for validate and cast the sample rate
        value_list = []  # initialize an empty list
        wait_time = 0 if (result := 1 / float(sample_rate) - 0.05) < 0 else result  # if the sample rate is less than 50 ms, use 0 else result - Note: each command with a response takes an average of 50 ms
        for i in range(sample_count):  # start for loop
            value = self.read_measurement(operation_name=operation_name, serial_object=serial_object)  # read the measurement
            value_list.append(value)  # append the value to list
            if i < sample_count - 1:  # if no is the last iteration
                time.sleep(wait_time)  # wait
        return value_list  # return the list

    def start_stream(self, first_value: str, second_value: str, third_value: str, data_queue, stop_queue, streaming_duration: int | float | str | None, serial_object: serial.Serial | None = None) -> None:
        """
        This method is used to start the stream.\n
        Note: Please read the imt protocol stream documentation before using this feature.

        Args:
            first_value (str): The first value of stream
            second_value (str): The second value of stream
            third_value (str): The third value of stream
            data_queue (queue): The data queue where the measurement data is saved
            stop_queue (queue): The stop queue that handles cancellation and termination signals
            streaming_duration (int | float | str | None): The maximum duration of the stream in seconds
            serial_object (serial.Serial | None): Optional - uses the instances serial object if omitted.
        """
        serial_object = serial_object or self.serial_object
        baudrate = stream_protocol_specs["stream"]["baudrate"]
        msg_length = stream_protocol_specs["stream"]["msg length"]
        if serial_object.baudrate != baudrate:  # check that the correct baudrate is use
            raise ValueError(f"Invalid baudrate '{serial_object.baudrate}'. " f"This method requires {baudrate} for stream.")
        streaming_duration = self.io_validator.validate_and_cast(value=streaming_duration, target_types=float, allowed_types=(str, float, int, type(None)), min_value=1, max_value=999999)  # call the method to validate and cast the streaming duration
        self._set_stream_pre_configuration(serial_object, first_value, second_value, third_value)  # call method for set stream configuration
        self.execute_command(operation_name="start stream", value=None, serial_object=serial_object)  # call the method to start the stream
        self._handle_read_stream(serial_object, data_queue, stop_queue, streaming_duration, msg_length, first_value, second_value, third_value)  # call the method for handle the stream
        self.execute_command(operation_name="stop stream", value=None, serial_object=serial_object)  # call the method to stop the stream
        self.execute_command(operation_name="screen", value="unlocked", serial_object=serial_object)  # call method for unlock the screen

    def start_fast_stream(self, first_value: str, second_value: str, third_value: str,
                          fourth_value: str, fifth_value: str, sixth_value: str,
                          seventh_value: str, eighth_value: str, ninth_value: str,
                          tenth_value: str, eleventh_value: str, twelfth_value: str,
                          data_queue, stop_queue, streaming_duration: int | float | str | None, serial_object: serial.Serial | None = None) -> None:
        """
        This method is used to start the fast stream.\n
        Note: Please read the imt fast protocol stream documentation before using this feature.

        Args:
            first_value (str): The first value of fast stream
            second_value (str): The second value of fast stream
            third_value (str): The third value of fast stream
            fourth_value (str): The fourth value of the fast stream
            fifth_value (str): The fifth value of the fast stream
            sixth_value (str):The sixth value of the fast stream
            seventh_value (str): The seventh value of the fast stream
            eighth_value (str): The eighth value of the fast stream
            ninth_value (str): The ninth value of the fast stream
            tenth_value (str): The tenth value of the fast stream
            eleventh_value (str): The eleventh value of the fast stream
            twelfth_value (str): The twelfth value of the fast stream
            data_queue (queue): The data queue where the measurement data is saved
            stop_queue (queue): The stop queue that handles cancellation and termination signals
            streaming_duration (int | float | str | None): The maximum duration of the fast stream in seconds
            serial_object (serial.Serial | None): Optional - uses the instances serial object if omitted.
        """
        serial_object = serial_object or self.serial_object
        baudrate = stream_protocol_specs["fast stream"]["baudrate"]
        msg_length = stream_protocol_specs["fast stream"]["msg length"]
        if serial_object.baudrate != stream_protocol_specs["fast stream"]["baudrate"]:  # check that the correct baudrate is use - Note: only 115200 else raise an error
            raise ValueError(f"Invalid baudrate '{serial_object.baudrate}'. " f"This method requires {baudrate} for fast stream.")
        streaming_duration = self.io_validator.validate_and_cast(value=streaming_duration, target_types=float, allowed_types=(str, float, int, type(None)), min_value=1, max_value=999999)  # call the method to validate and cast the streaming duration
        self._set_stream_pre_configuration(serial_object, first_value, second_value, third_value, fourth_value, fifth_value, sixth_value, seventh_value, eighth_value, ninth_value, tenth_value, eleventh_value, twelfth_value)  # call method for set fast stream configuration
        self.execute_command(operation_name="start_stream", value=None, serial_object=serial_object)  # call the method to start the fast stream
        self._handle_read_stream(serial_object, data_queue, stop_queue, streaming_duration, msg_length, first_value, second_value, third_value, fourth_value, fifth_value, sixth_value, seventh_value, eighth_value, ninth_value, tenth_value, eleventh_value, twelfth_value)  # call the method for handle the fast stream
        self.execute_command(operation_name="stop_stream", value=None, serial_object=serial_object)  # call the method to stop the fast stream
        self.execute_command(operation_name="screen", value="unlocked", serial_object=serial_object)  # call method for unlock the screen

    def _handle_communication(self, operation: str, operation_name: str, value: str | int | None, dictionary: dict, serial_object: serial.Serial) -> str | None:
        """
        This method is used to handle the communication with the device.

        Args:
            operation (str): The execute operation - RM/CM/RS...
            operation_name (str): The operation name of the command
            value (str | int | None): The value to be setting
            dictionary (dict): The dictionary to use for the command
            serial_object (serial.Serial): The serial interface for communication

        Return:
            value (str | None): The return value of the response
        """
        operation_name = operation_name.lower().strip()  # all characters lower case and remove spaces
        operation_identifier = self.io_validator.check_operation_name(dictionary=dictionary, operation_name=operation_name)  # call the method to verify the operation_name and get the operation identifier
        conversion_factor = dictionary.get(operation_name, None).get("conversion_factor")  # get the conversion factor
        if value is not None:  # if the value is not none
            value = str(value).lower().strip()  # delete spaces
            if conversion_factor is not None:  # if the conversion fac tor is not none
                value = int(float(value) * conversion_factor)  # calculate the needed value for the device
        searched_value = self.io_validator.check_values_argument(dictionary=dictionary, operation=operation, operation_name=operation_name, value=value)  # call the method to verify the value
        if serial_object is None:  # if the serial object is None (not valid)
            raise ConnectionError("The serial object is not valid")
        for _ in range(5):  # start for loop
            value, error_occurred = self._execute_communication(operation=operation, operation_identifier=operation_identifier, value=searched_value, serial_object=serial_object)  # call the method to execute the communication
            if error_occurred:  # if an error occurred
                continue  # continue the loop
            if operation == "WS":  # if the operation is WS - command value and response value must be the same, otherwise something has gone wrong
                if str(searched_value) != str(value):  # if is not same
                    time.sleep(2)  # wait 2 seconds
                    continue  # continue the loop
            if (dict_range := execute_command_dictionary.get(operation_name, {}).get("range")) is not None:  # if range exist
                if not (dict_range.get("min") <= int(value) <= dict_range.get("max")):  # if the value is in range
                    time.sleep(2)  # wait 2 seconds
                    continue  # continue the loop
            if dictionary.get(operation_name, {}).get("value") not in (None, True) and value != "":  # if a translation for the value exist
                value = next((k for k, v in dictionary.get(operation_name, {}).get("value", {}).items() if str(v) == value), None)  # translate the response value
                if value is None:
                    continue  # continue the loop
            break  # break the loop no error
        else:  # only is called if the for loop runs without a break command
            raise ValueError("Invalid device response")  # raise an error
        if (conversion_factor := dictionary.get(operation_name, {}).get("conversion_factor")) is not None:  # if conversion factor exist
            value = str(float(value) / float(conversion_factor))  # convert the value
        return value  # return the value

    def _execute_communication(self, operation: str, operation_identifier: str, value: str | int | None, serial_object: serial.Serial) -> tuple[str | None, bool]:
        """
        This method is used to handle the communication with the device.

        Args:
            operation (str): The execute operation - RM/CM/RS...
            operation_identifier (str): The operation name of the command
            value (str | int | None): The value to be setting
            serial_object (serial.Serial): The serial interface for communication

        Return:
            value (str | None): The return value of the response
            error (bool): The error
        """
        command = self.io_validator.build_command(operation=operation, operation_identifier=operation_identifier, value=value)  # call the method for build command
        # print(f"sent: {command}")
        self.serial_interface.write_command(command=command, serial_object=serial_object)  # call the method for write the command
        chunk = self.serial_interface.read_command(length=1, serial_object=serial_object)  # call the method for read the command
        if chunk == b'':  # if the chunk is empty
            return "", True  # bool mean error occurred - A timeout often occurs then.
        if chunk == b'?':
            chunk, error = self.serial_interface.validate_followup_byte(chunk=chunk, serial_object=serial_object)
            if error:
                return chunk, True
        response_dict = self.io_validator.build_message_structure(operation, operation_identifier, value, has_value_key="response_has_value")  # call the method for build the structure of response
        response, error_occurred = self.serial_interface.read_packet(chunk=chunk, serial_object=serial_object, response_dict=response_dict)  # call the method for read the msg
        # print(f"received: {response}")
        if error_occurred:  # if an error occurred
            return response, True   # bool mean error occurred
        value, error_occurred = self.io_validator.check_response(response, response_dict)  # call the method for check the response
        if error_occurred:
            return value, True  # return the value and True for msg no valid
        return value, False  # return the value and false for no error

    def _set_stream_pre_configuration(self, serial_object: serial.Serial, *values: str) -> None:
        """
        This method is used to set the configuration of the stream.

        Args:
            serial_object (serial.Serial): The serial interface for communication
            *values (str): All values to be measured
        """

        execute_command_list = [
            ("screen", "locked")  # only for citrex - Note: The temporal resolution can only be ensured when the screen is locked
        ]
        for operation_name, value in execute_command_list:  # get all commands
            self.execute_command(operation_name=operation_name, value=value, serial_object=serial_object)  # call method to execute the command

        names = ["first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth", "tenth", "eleventh", "twelfth"]
        write_setting_list = [
            (f"stream {names[i]} value", values[i]) for i in range(len(values))
        ]  # create the list for set all values
        for operation_name, value in write_setting_list:  # get all commands
            self.write_setting(operation_name=operation_name, value=value, serial_object=serial_object)  # call method to execute the command

    def _handle_read_stream(self, serial_object: serial.Serial, data_queue: list, stop_queue: bool, streaming_duration: int | float | None, msg_length: int, *values: str) -> None:
        """
        This method is used to handle the communication with the device.

        Args:
            serial_object (serial.Serial): The serial interface for communication
            data_queue (queue): The data queue where the measurement data is saved
            stop_queue (queue): The stop queue that handles cancellation and termination signals
            streaming_duration (int | float | str | None): The maximum duration of the stream in seconds
            msg_length (int): The length of the streaming message
            *value (str): The values which are inside in the stream message
        """
        last_raw_timestamp, timestamp_rollover_count = None, 0  # initialize the variables
        streaming_duration = float('inf') if streaming_duration is None else streaming_duration  # if streaming duration is None set infinity else use the values of streaming duration
        conversion_factors = [read_measurement_dictionary.get(value, {}).get("conversion_factor") for value in values]  # get all conversion factor
        ranges = [(float(read_measurement_dictionary.get(value, {}).get("range").get("min")), float(read_measurement_dictionary.get(value, {}).get("range").get("max"))) for value in values]  # get the limit of the values min and max
        while stop_queue.empty():  # while stop_queue is empty
            response = self.serial_interface.read_streaming_msg(serial_object=serial_object, msg_length=msg_length)  # call method for read the msg x byte of stream
            if response is True:  # if response is True the device is without reaction
                stop_queue.put((True))  # write true to stop_queue
                return  # return
            timestamp, last_raw_timestamp, timestamp_rollover_count = self.io_validator.calculate_real_timestamp(response=response, last_raw_timestamp=last_raw_timestamp, timestamp_rollover_count=timestamp_rollover_count)  # calculate the real time step with overflow with 16bit
            error_occurred = self.io_validator.check_range(response, msg_length, ranges)  # call the method for check the range if all values
            if error_occurred:  # if error occurred
                continue
            measured_values = self.io_validator.extract_measured_values(response, msg_length, conversion_factors)  # get measured values
            data_queue.put((timestamp, *measured_values))  # write the data to data_queue
            if timestamp >= streaming_duration:  # when the maximum streaming duration has expired
                stop_queue.put((True))  # write True to stop_queue


class SerialInterface:
    @staticmethod
    def open_port(port: str, baudrate: int) -> serial.Serial:
        """
        This method is used to open serial ports.

        Args:
            port (str): The target port
            baudrate (int): The target baudrate

        Return:
            serial_port (serial.Serial): The session for this serial communication
        """
        for _ in range(3):  # start for loop
            try:  # try
                serial_port = serial.Serial(port, baudrate, timeout=11)  # open serial port with 11 seconds because the device need 10 second plus transport
                return serial_port, None  # return serial_port, error
            except serial.SerialException as e:  # except
                last_exception = e  # save the error
                time.sleep(2)  # retry after 2 seconds - but max 3 times
        return None, last_exception  # return None, error exception - that means error occurred

    @staticmethod
    def close_port(serial_object: serial.Serial) -> None:
        """
        This static method closed the serial object.

        Args:
            serial_object (serial.Serial): The serial object to be closed
        """
        try:
            serial_object.close()  # close the serial port
        except Exception:
            pass

    @staticmethod
    def write_command(command: bytes, serial_object: serial.Serial) -> None:
        """
        This static method write a command to serial object.

        Args:
            command (bytes): The command to be written
            serial_object (serial.Serial): The serial object to be closed
        """
        serial_object.write(command)  # write the command

    def read_command(self, length: int, serial_object: serial.Serial) -> bytes:
        """
        This method read a response from serial interface.

        Args:
            length (int): The length of read response
            serial_object (serial.Serial): The serial object where is read

        Return:
            response (bytes): The read response
        """
        return serial_object.read(length)  # return the response

    def read_packet(self, chunk: bytes, serial_object: serial.Serial, response_dict: dict) -> tuple[bytes, bool]:
        """
        This method read a response from serial interface.

        Args:
            chunk (bytes): The chunk of bytes msg
            serial_object (serial.Serial): The serial object where is read
            response_dict: The dict for get the end_token

        Return:
            message (bytes): The read response
            error (bool): The error as bool
        """
        start_token = response_dict["start_token"][0].encode().decode('unicode-escape').encode('utf-8')  # convert to bytes (b'%')
        separator_token = response_dict["separator_token"][0].encode().decode('unicode-escape').encode('utf-8')  # convert to bytes (b'#')
        end_token = response_dict["end_token"][0].encode().decode('unicode-escape').encode('utf-8')  # convert to bytes (b'\r')
        pattern = re.compile(rb'.*' + start_token + rb'(.{1,3})' + separator_token + rb'(.{0,18})' + end_token)  # build pattern b'{not important} % {1-3bytes} # {0-18 bytes} \r {not important}'
        message = chunk  # set the first chunk as message
        echo_message = None
        while True:  # run until the flag is false - only for term character
            chunk = self.read_command(1, serial_object)  # read the first byte
            message += chunk  # add the byte to message
            if b'' == chunk:  # if the chunk is empty
                return message, True  # mean timeout occurred
            if chunk == b'?':  # if the chunk is ?
                message, error = self.validate_followup_byte(chunk=message, serial_object=serial_object)  # call the method for verify ? is an error
                if error:
                    return message, True  # mean the response is ? also an error
            if pattern.search(message):
                message = message.replace(b'\x00', b'')  # replace all nul in the msg with nothing - the device send some times 0x00 (nul)
                if serial_object.echo_state and echo_message is None:
                    echo_message = message  # write message to echo_messages
                    message = b''  # clear the message
                    # print(f"echo: {echo_message}")  # echo_message
                    continue
                return message, False  # return the complete message incl. term_character as bytes - bool meaning no error occurred

    def validate_followup_byte(self, chunk: bytes, serial_object: serial.Serial) -> tuple[bytes, bool]:
        """
        This method validate the followup byte for check is an error or and ? in the response.

        Args:
            chunk (bytes): The chunk of bytes msg
            serial_object (serial.Serial): The serial object where is read

        Return:
            chunk (bytes): The read chunk
            error (bool): The error as bool
        """
        original_timeout = serial_object.timeout  # get the original _timeout
        serial_object.timeout = 1  # set timeout to 1 sec
        next_chunk = self.read_command(1, serial_object)  # read the next chunk
        serial_object.timeout = original_timeout  # set timeout to original
        if next_chunk == b'':  # if next chunk not exist
            return chunk, True  # the response is this error
        chunk += next_chunk  # add next chunk
        return chunk, False  # add next chunk to message

    @staticmethod
    def read_streaming_msg(serial_object: serial.Serial, msg_length: int) -> bytes | bool:
        """
        This method read a nine byte response from serial interface.

        Args:
            serial_object (serial.Serial): The serial object where is read
            msg_length (int): The length of the message

        Return:
            message (bytes | bool): The read response or True if not enough bytes were read
        """
        response = serial_object.read(msg_length)  # read x byte - note: every complete msg has x bytes
        if len(response) < msg_length:  # if less than x bytes were read
            return True  # return true for time out und less than x bytes
        while sum(response) % 256 != 0:  # while the chk sum is not equal to 0 - The message is invalid - use a shift register to shift one byte further. The division may simply have been shifted.
            response = response[1:] + serial_object.read(1)  # shift 1 byte
        return response  # return the msg ist valid

    def _get_echo_state(self, serial_object):
        for _ in range(5):
            self.write_command(b'%RS#1\r', serial_object)
            # print(f'echo test - sent: {b'%RS#1\r'}')
            chunk = self.read_command(1, serial_object)
            if chunk == b'?':  # if the first chunk is ? mean error
                continue  # continue
            response = chunk + serial_object.read_until(b"\r")  # read until '\r' plus the chunk
            echo = b'$' not in response  # b'$' not in response? - that mean we have an echo
            serial_object.echo_state = echo  # set the echo state
            if echo:
                # print(f'echo test - echo: {response}')
                response = serial_object.read_until(b"\r")
            break
        # print(f'echo test - received: {response}')


class IOValidator:
    def build_command(self, operation: str, operation_identifier: str, value: str | int | None) -> bytes:
        """
        This method is used to build the command.

        Args:
            operation (str): The operation to be performed example CM/RM....
            operation_identifier (str): The operation identifier for the command
            value (str | int | None): The value for the command if exist

        Return:
            command_as_byte (bytes): The built command
        """
        command_dict = self.build_message_structure(operation, operation_identifier, value, has_value_key="command_has_value")  # call the method for build the message structure
        command_as_byte = (''.join(str(value[0]) for value in command_dict.values() if value[0] is not None)).encode('utf-8')  # convert to command as bytes - get all entries of dict
        return command_as_byte  # return the command as bytes

    def build_message_structure(self, operation: str, operation_identifier: str, value: str | int | None, has_value_key: str) -> dict:
        """
        This method is used to build the structure of msg.

        Args:
            operation (str): The operation to be performed example CM/RM....
            operation_identifier (str): The operation identifier for the command
            value (str | int | None): The value for the command if exist
            has_value_key (str): only command_has_value and response_has_value

        Return:
            command_as_dict (dict): The built command as dict
        """
        update_core = {"operation": operation, "operation_identifier": operation_identifier}  # create the update dictionary for core structure
        core = self._update_dict(copy.deepcopy(message_core_structure), update_core)  # call the method for update the dict as core
        terminator = copy.deepcopy(message_terminator)  # get the edn token as deep copy dict
        has_value = message_value_mapping[operation][has_value_key]  # check if the message has a value - possible True/False and None that mean is variable
        if has_value or has_value is None:  # if (has_value is True) or (has_value is None and value is not None) or (has_value is None and has_value_key is True)
            if has_value_key == "response_has_value" or value is not None:  # if the out put dict ist for the response
                update_value = {"value": has_value if has_value_key == "response_has_value" else value}  # create update dict and if has_value_key is response use None else the value
                value_optional = self._update_dict(copy.deepcopy(message_value_optional), update_value)  # get the optional value as dict
                return {**core, **value_optional, **terminator}  # merge the dict
        return {**core, **terminator}  # merge the dict without value because no has value

    def check_response(self, response: bytes, response_dict: dict) -> tuple[str | None, bool]:
        """
        This method is used to build the structure of msg.

        Args:
            response (bytes): The response of device as bytes (b'%RM#0$11\r')
            response_dict (dict): The structure dict of response

        Return:
            value (str | None): The value of response
            error (bool): If an error occurred return True
        """
        response_str = response.decode('utf-8', errors='ignore')  # decode the response
        start_token = response_dict["start_token"][0]  # get the start token from the structure dict.
        index = response_str.rfind(start_token)  # get the position of start token in the msg - Note search the last start token in he msg
        if index == -1:  # if start token no exist
            return response_str, True  # return - true means msg no valid - start token not found
        response_str = response_str[index + 1:]  # get the response without start token and - delete "%"
        for key in ["operation", "separator_token", "operation_identifier"]:  # check if the token exist in the msg (RM and # and 0)
            expected_value, length = response_dict[key]  # get the token and the length
            if str(response_str[:length]) != str(expected_value):  # exist if exist
                return response_str, True  # return the response and True for msg no valid
            response_str = response_str[length:]  # delete the found and checked token
        response_str = response_str.replace(response_dict["end_token"][0], "")  # delete the end token - normally \r
        if not response_str:  # if response is empty
            expected_state = response_dict.get("value")[0]  # get expected state
            if expected_state is None or expected_state is False:  # if is none or false
                return "", False  # no error
            else:
                return response, True  # error
        value_prefix, length = response_dict["value_prefix"]
        if response_str[:length] != value_prefix:
            return response, True  # error occurred
        return response_str[length:], False  # return value, no error

    @staticmethod
    def calculate_real_timestamp(response: bytes, last_raw_timestamp: int | None, timestamp_rollover_count: int) -> tuple[float, int, int]:
        """
        This method is used to calculate the real timestamp with rollover.

        Args:
            response (bytes): The stream response
            last_raw_timestamp (int | None): The last raw timestamp
            timestamp_rollover (int): The counter of rollover

        Return:
            real_timestamp (int): The real calculated timestamp
            last_raw_timestamp (int): The last raw timestamp
            timestamp_rollover (int): The counter of rollover
        """
        raw_timestamp = int.from_bytes(response[0:2], byteorder='big')  # 2-byte timestamp max int is 65536 - The device then starts again at 0.
        if last_raw_timestamp is not None and raw_timestamp < last_raw_timestamp:  # check if the last timestamp is bigger then the new one
            timestamp_rollover_count += 1  # Rollover detected
        last_raw_timestamp = raw_timestamp  # write the new timestamp to the old timestamp
        full_ticks = timestamp_rollover_count * 65536 + raw_timestamp  # biggest integer with 16 bit is (2**16 -1) = 65536  - calculate the full tick
        timestamp = (full_ticks * 5) / 1000  # calculate the full time stamp - note 5 is every 5 ms I get a new value
        return timestamp, last_raw_timestamp, timestamp_rollover_count  # return

    @staticmethod
    def check_range(response: bytes, msg_length: int, ranges: list) -> bool | None:
        """
        This method is used to check the range of the values in the stream response.

        Args:
            response (bytes): The stream response
            msg_length (int): The length of message
            ranges (list): The ranges for all measured values (min & max)
        Return:
            error_occurred (True | None): If True return an error occurred else not
        """
        start = 2  # the first 2 byte are timestamp
        end = msg_length - 1  # the last byte is the check sum
        measured_values = []  # create empty list
        for i in range(start, end, 2):  # extract all measured values
            value = int.from_bytes(response[i:i + 2], byteorder='big', signed=True)  # get the value
            measured_values.append(value)  # append the measured value
        for value, (min_val, max_val) in zip(measured_values, ranges):  # get the measured value und the range (max min)
            if not (min_val <= value <= max_val):  # if not in range
                return True  # the value is not in range
        return None

    @staticmethod
    def extract_measured_values(response: bytes, msg_length: int, conversion_factors: list[float]):
        """
        This method is used to extract the measured values.

        Args:
            response (bytes): The stream response
            msg_length (int): The length of message
            conversion_factors (list[float]): The list with all conversion factors

        Return:
            converted_values (tuple): All measured values as tuple
        """
        start = 2  # the first 2 byte are timestamp
        end = msg_length - 1  # the last byte is the check sum
        measured_values = []  # create empty list
        for i in range(start, end, 2):  # extract all measured values
            value = int.from_bytes(response[i:i + 2], byteorder='big', signed=True)  # get the value
            measured_values.append(value)  # append the measured value
        converted_values = [
            raw / factor for raw, factor in zip(measured_values, conversion_factors)
        ]  # calculate all measured values
        return tuple(converted_values)

    @staticmethod
    def _update_dict(dict: dict, update_dict: dict) -> dict:
        """
        This static method is used to update a dict.

        Args:
            dict (dict): The dictionary that needs to be updated
            update_dict (dict): The dictionary with the new entries

        Return:
            dict (dict): The updated dictionary
        """
        for key, value in update_dict.items():  # get all items
            if key in dict:  # if the key exist in the dict
                dict[key][0] = value  # the dict is updated
                dict[key][1] = None if value is None or isinstance(value, bool) else len(str(value))  # update the length if is bool or none the length is None else the length
        return dict  # return dict

    def check_values_argument(self, dictionary: dict, operation: str, operation_name: str, value: str | None) -> str | None:  # value is None or str
        """
        This method is used to check the values of the command.

        Args:
            dictionary (dict): The dictionary for this operation (CM/RM etc....)
            operation (str): The operation (CM/RM.....)
            operation_name (str): The operation name (pressure_low)
            value (str | None): The value that is set

        Return:
            value (str | None): The value of response
        """
        command_has_value = message_value_mapping.get(operation, {}).get("command_has_value")  # get if the command_has_value
        entry_for_value = dictionary.get(operation_name, {}).get("value")  # get the entry for value
        if command_has_value is False and value is None:  # Case 1: No value required and none given
            return None  # return None
        if command_has_value is True and value is None:  # Case 2: Value required, but none given
            self._raise_error(dictionary, operation_name, value)  # call the method for raise the error
        if command_has_value is False and value is not None:  # Case 3: No value required, but one given
            self._raise_error(dictionary, operation_name, value)  # call the method for raise the error
        if command_has_value is None and value is None:  # Case 4: Unclear whether value is required, and none given
            if entry_for_value is None:  # if no value required
                return None  # return None
            self._raise_error(dictionary, operation_name, value)  # call the method for raise the error
        if value is not None:  # Cases 5 & 6: Value given, check whether checking the range or mapping for translation
            if entry_for_value is True:  # if entry_for_value is True
                min_value, max_value = dictionary.get(operation_name, {}).get("range").get("min"), dictionary.get(operation_name, {}).get("range").get("max")  # extract min_value, max_value
                try:  # try
                    if not (min_value <= int(value) <= max_value):  # if value if not in range
                        self._raise_error(dictionary, operation_name, value)  # raise an value error
                except ValueError:
                    self._raise_error(dictionary, operation_name, value)  # is impossible to convert in int
                return value  # return value
            elif entry_for_value is not None:  # if entry_for_value is not None
                translation = entry_for_value.get(value)  # get the translation
                if translation is None:  # if the translation is none
                    self._raise_error(dictionary, operation_name, value)  # call the method for raise the error
                return translation  # return translation
            else:
                self._raise_error(dictionary, operation_name, value)  # call the method for raise the error

    def _raise_error(self, dictionary: dict, operation_name: str, value: str | None) -> None:
        """
        This method is used to generate the raise error with msg

        Args:
            dictionary (dict): The dictionary for this operation (CM/RM etc....)
            operation_name (str): The operation name (pressure_low)
            value (str | None): The value that is set
        """
        entry_for_value = dictionary.get(operation_name, {}).get("value")  # get the entry for the value in the dict
        conversion_factor = dictionary.get(operation_name, None).get("conversion_factor")  # get the conversion factor
        if entry_for_value is None:  # if entry is none
            valid_values = None  # the valid values is none
        elif entry_for_value is True:  # if entry is True
            min_value, max_value = dictionary.get(operation_name, {}).get("range").get("min") / conversion_factor, dictionary.get(operation_name, {}).get("range").get("max") / conversion_factor  # get max and min value
            valid_values = f"values from {min_value} to {max_value}"  # set the valid range
        else:
            valid_values = list(dictionary.get(operation_name, {}).get("value"))  # set the list with valid operation_names
        if value is not None and conversion_factor is not None:
            value = value / conversion_factor
        raise ValueError(f"Value is not valid: {value}\nThe following values are valid: {valid_values}")  # raise an value error

    @staticmethod
    def check_operation_name(dictionary: dict, operation_name: str) -> str:
        """
        This method is used to generate the raise error with msg

        Args:
            dictionary (dict): The dictionary for this operation (CM/RM etc....)
            operation_name (str): The operation name (pressure_low)

        Return:
            operation_identifier (str): The translated operation name
        """
        if (operation_identifier := dictionary.get(operation_name, {}).get("operation_identifier")) is None:  # if operation identifier is not found
            raise ValueError(f"Operation name is not valid: {operation_name}\nThe following operation names are valid {list(dictionary.keys())}")  # raise value error
        return operation_identifier  # return the operation identifier

    @staticmethod
    def validate_and_cast(value, target_types, allowed_types, min_value=None, max_value=None) -> tuple[str | int | float | bool | None]:
        """
        This method validates whether the input value can be converted to the expected data type and whether it falls within the allowed range.

        Args:
            value (str | int | float | bool | None): The value to be checked
            target_types (str | int | float | bool | None | tuple): The target types
            allowed_types (tuple |str | int | float | bool | None): The allowed types
            min_value (int | float | None): The lower limit of the permissible range
            max_value (int | float | None): The upper limit of the permissible range

        Return:
            value (str | int | float | bool | None): the converted and verified value
        """
        if not isinstance(allowed_types, tuple):  # if the input in not a tuple
            allowed_types = (allowed_types,)  # convert to tuple
        if type(value) not in allowed_types:  # if the type of input value is not in the allowed types
            raise ValueError(f"The input '{value}' is invalid. Please provide data that is convertible to {target_types} in range of {min_value} to {max_value}")  # raise an error
        if type(value) is type(None) or type(value) is bool:  # if the type of value is bool or None return it directly
            return value
        try:  # try
            if target_types == str:  # if the target type is str
                return str(value)  # convert to str and return
            elif target_types == int:  # if the target type is int
                value_as_float = float(value)  # change to float - Note for convert string to float (directly from string to int not possible)
                if value_as_float.is_integer():  # check if is integer if not pass for raise error (maybe now is 3.4)
                    value_as_int = int(value_as_float)  # convert the float to int
                    if max_value is not None and min_value is not None:  # if max and min are not none
                        if not (min_value <= value_as_int <= max_value):  # if the sample_count is not in range
                            1 / 0  # for trigger the exception
                    return value_as_int  # return value as int
            elif target_types == float:  # convert in float
                value_as_float = float(value)  # convert to float
                if max_value is not None and min_value is not None:  # if are not None
                    if not (min_value <= value_as_float <= max_value):  # if the sample_count is not in range
                        1 / 0  # for trigger the exception
                return value_as_float  # return
            elif target_types is type(None):  # check if is None type
                return value  # return it
            elif target_types is bool:  # check if is bool
                return value  # return the value
        except Exception:  # Exception
            pass
        raise ValueError(f"The input '{value}' is invalid. Please provide data that is convertible to {target_types} in range of {min_value} to {max_value}")  # raise error


if __name__ == "__main__":
    pass
