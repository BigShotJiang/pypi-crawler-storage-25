__version__ = "0.0.3"
__author__ = ["Bachatero18", "Dennis Schramm"]
__license__ = "GPL-3.0-or-later"

from .device_h4 import DeviceH4
from .device_h5 import DeviceH5

__all__ = ["DeviceH4", "DeviceH5"]
