import logging

import matplotlib.pyplot as plt
import numpy as np

import gdutils as gd
from gdsofa import *


# Simple dynamics with a bar deformation
# Plot the mean position of the tip over time


def main():
    out = gd.fPath(__file__, "out")
    data_path = out / "bar"

    params = BaseSOFAParams(out_dir=out, dt=1e-2, scale=1e-3, n=100)
    params.add_container(data_path)
    params.save()

    root = RootNode(gravity=[0, 0, -9.81])
    root + DefaultAnimationLoop()
    root + VisualStyle(VISUAL.showAll)

    bar = root.add_child("bar")
    bar + EulerImplicitSolver(rayleighStiffness=1e-3)
    bar + CGLinearSolver()

    bar + MeshVTKLoader(filename=params.bar, scale=params.scale)
    bar + TetrahedronSetTopologyContainer(src=Link(bar.last))
    bar + MechanicalObject()
    bar + DiagonalMass(massDensity=1e3)

    box = np.array([-1, -1, -1, 1, 11, 11]) * params.scale
    bar + BoxROI(box=box, drawBoxes=True)
    bar + FixedProjectiveConstraint(indices=Link(bar.last, "indices"))

    bar + TetrahedronFEMForceField(youngModulus=1e6, poissonRatio=0.4)

    surf = bar.add_child("visu")
    surf + MeshOBJLoader(filename=params.bar_obj, scale=params.scale)
    surf + TriangleSetTopologyContainer(src=Link(surf.last))
    surf + MechanicalObject()
    surf + BarycentricMapping()
    surf.add_visual(color="red")

    box = np.array([99, -1, -1, 101, 11, 11]) * params.scale
    bar + BoxROI(box=box, name="ep")

    sofa = RunSofa(root, params, Controller)
    sofa.run(gui=True)

    if ctrl := sofa.controllers.get("Controller"):
        ctrl.plot()


class Controller(BaseSOFAController):
    def init(self):
        self.x = Link(self.find("MechanicalObject"), "position")
        self.end_ind = Link(self.find(name="ep"), "indices")

    def get_mean_pos(self):
        dofs = self.get(self.x)[self.get(self.end_ind)]
        return np.mean(dofs, axis=0)

    def after_animate(self):
        self.data.add(end_pos=self.get_mean_pos())

    def plot(self):
        df = self.data.df
        pos = np.array(df["end_pos"].tolist()) / self.params.scale
        x, y, z = pos[:, 0], pos[:, 1], pos[:, 2]
        t = df["t"].to_numpy()

        with gd.SPlot():
            fig, ax = plt.subplots()
            ax.plot(t, x, label="x")
            ax.plot(t, y, label="y")
            ax.plot(t, z, label="z")
            ax.set_xlabel("t [s]")
            ax.set_ylabel("position [mm]")
            ax.legend()
            gd.despine(fig)
            fig.tight_layout()


log = logging.getLogger(__name__)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    log = gd.get_logger()

    main()
