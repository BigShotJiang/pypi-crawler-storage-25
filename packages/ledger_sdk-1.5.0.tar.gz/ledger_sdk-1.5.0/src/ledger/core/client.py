import asyncio
import sys
import traceback
from datetime import datetime, timezone
from typing import Any

import ledger.core.buffer as buffer_module
import ledger.core.config as config_module
import ledger.core.flusher as flusher_module
import ledger.core.http_client as http_client_module
import ledger.core.rate_limiter as rate_limiter_module
import ledger.core.threaded_flusher as threaded_flusher_module
import ledger.core.validator as validator_module
import ledger.metrics as metrics_init_module
import ledger.metrics.aggregator as aggregator_module
import ledger.metrics.api as metrics_api_module
import ledger.tracing as tracing_init_module
import ledger.tracing.buffer as trace_buffer_module
import ledger.tracing.sampler as sampler_module
import ledger.tracing.span as span_module
import ledger.tracing.tracer as tracer_module
from ledger._version import __version__


class LedgerClient:
    """Client for sending logs to the Ledger logging service.

    The LedgerClient handles log buffering, batching, rate limiting, and automatic
    retries with circuit breaker protection. Logs are sent asynchronously in the
    background to minimize performance impact on your application.

    Example:
        >>> client = LedgerClient(api_key="ledger_your_api_key")
        >>> client.log_info("User logged in", {"user_id": "123"})
        >>> await client.shutdown()
    """

    tracer: "tracer_module.Tracer | None" = None
    metrics: "metrics_api_module.MetricsAPI | None" = None

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        flush_interval: float | None = None,
        flush_size: int | None = None,
        max_buffer_size: int | None = None,
        http_timeout: float | None = None,
        http_pool_size: int | None = None,
        rate_limit_buffer: float | None = None,
        environment: str | None = None,
        release: str | None = None,
        platform_version: str | None = None,
        service_name: str | None = None,
        tracing_enabled: bool | None = None,
        trace_sample_rate: float | None = None,
        trace_decision_window_ms: float | None = None,
        metrics_enabled: bool | None = None,
        metrics_aggregation_window_s: float | None = None,
        metrics_max_tags_per_metric: int | None = None,
    ):
        """Initialize the Ledger client.

        Args:
            api_key: Your Ledger API key (must start with 'ledger_').
            base_url: Base URL for the Ledger API. If not provided, uses the default
                production endpoint.
            flush_interval: How often (in seconds) to automatically flush buffered logs.
                Default is from config.
            flush_size: Maximum number of logs to include in a single batch.
                Default is from config.
            max_buffer_size: Maximum number of logs to hold in memory before dropping
                old logs. Default is from config.
            http_timeout: Timeout in seconds for HTTP requests. Default is from config.
            http_pool_size: Maximum number of concurrent HTTP connections.
                Default is from config.
            rate_limit_buffer: Safety margin (0-1) for rate limiting. For example, 0.9
                means use 90% of the allowed rate. Default is from config.
            environment: Optional environment identifier (e.g., "production", "staging").
                Attached to all logs.
            release: Optional release version identifier. Attached to all logs.
            platform_version: Python version string. Auto-detected if not provided.

        Raises:
            ValueError: If configuration parameters are invalid (e.g., invalid API key,
                negative timeouts, invalid URLs).
        """
        config = config_module.DEFAULT_CONFIG

        base_url = base_url if base_url is not None else config.base_url
        flush_interval = flush_interval if flush_interval is not None else config.flush_interval
        flush_size = flush_size if flush_size is not None else config.flush_size
        max_buffer_size = max_buffer_size if max_buffer_size is not None else config.max_buffer_size
        http_timeout = http_timeout if http_timeout is not None else config.http_timeout
        http_pool_size = http_pool_size if http_pool_size is not None else config.http_pool_size
        rate_limit_buffer = (
            rate_limit_buffer if rate_limit_buffer is not None else config.rate_limit_buffer
        )
        resolved_service_name = service_name if service_name is not None else config.service_name
        resolved_tracing_enabled = (
            tracing_enabled if tracing_enabled is not None else config.tracing_enabled
        )
        resolved_trace_sample_rate = (
            trace_sample_rate if trace_sample_rate is not None else config.trace_sample_rate
        )
        resolved_trace_decision_window_ms = (
            trace_decision_window_ms
            if trace_decision_window_ms is not None
            else config.trace_decision_window_ms
        )
        resolved_metrics_enabled = (
            metrics_enabled if metrics_enabled is not None else config.metrics_enabled
        )
        resolved_metrics_aggregation_window_s = (
            metrics_aggregation_window_s
            if metrics_aggregation_window_s is not None
            else config.metrics_aggregation_window_s
        )
        resolved_metrics_max_tags_per_metric = (
            metrics_max_tags_per_metric
            if metrics_max_tags_per_metric is not None
            else config.metrics_max_tags_per_metric
        )

        self._validate_config(
            api_key=api_key,
            base_url=base_url,
            flush_interval=flush_interval,
            flush_size=flush_size,
            max_buffer_size=max_buffer_size,
            http_timeout=http_timeout,
            http_pool_size=http_pool_size,
            rate_limit_buffer=rate_limit_buffer,
        )

        self.api_key = api_key
        self.base_url = base_url
        self.environment = environment
        self.release = release
        self.platform_version = (
            platform_version
            or f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        )
        self._flush_size = flush_size
        self._http_timeout = http_timeout
        self._http_pool_size = http_pool_size

        self._buffer = buffer_module.LogBuffer(max_size=max_buffer_size)

        rate_limits = config_module.DEFAULT_RATE_LIMITS
        self._rate_limiter = rate_limiter_module.RateLimiter(
            requests_per_minute=rate_limits["requests_per_minute"],
            requests_per_hour=rate_limits["requests_per_hour"],
            buffer=rate_limit_buffer,
        )

        constraints = config_module.DEFAULT_CONSTRAINTS
        self._validator = validator_module.Validator(constraints)

        def _make_http_client() -> http_client_module.HTTPClient:
            return http_client_module.HTTPClient(
                base_url=self.base_url,
                api_key=self.api_key,
                timeout=self._http_timeout,
                pool_size=self._http_pool_size,
            )

        try:
            asyncio.get_running_loop()
            self._http_client: http_client_module.HTTPClient | None = _make_http_client()
            self._flusher: (
                flusher_module.BackgroundFlusher | threaded_flusher_module.ThreadedFlusher
            ) = flusher_module.BackgroundFlusher(
                buffer=self._buffer,
                http_client=self._http_client,
                rate_limiter=self._rate_limiter,
                flush_interval=flush_interval,
                flush_size=flush_size,
                max_batch_size=constraints["max_batch_size"],
            )
            self._flusher.start()
            self._mode = "async"
        except RuntimeError:
            self._http_client = None
            self._flusher = threaded_flusher_module.ThreadedFlusher(
                buffer=self._buffer,
                http_client_factory=_make_http_client,
                rate_limiter=self._rate_limiter,
                flush_interval=flush_interval,
                flush_size=flush_size,
                max_batch_size=constraints["max_batch_size"],
            )
            self._flusher.start()
            self._mode = "threaded"

        self._sdk_start_time = datetime.now(timezone.utc)
        self._metrics_aggregator: aggregator_module.Aggregator | None = None

        if resolved_tracing_enabled:
            decision_buffer = trace_buffer_module.TraceDecisionBuffer(
                window_ms=resolved_trace_decision_window_ms
            )
            sampler = sampler_module.ErrorBiasedHeadSampler(rate=resolved_trace_sample_rate)
            self.tracer: tracer_module.Tracer | None = tracer_module.Tracer(
                service_name=resolved_service_name,
                sampler=sampler,
                on_span_end=self._on_span_end,
                decision_buffer=decision_buffer,
            )
            tracing_init_module._set_default_tracer(self.tracer)
        else:
            self.tracer = None

        if resolved_metrics_enabled:
            self._metrics_aggregator = aggregator_module.Aggregator(
                window_s=resolved_metrics_aggregation_window_s,
                on_flush=self._on_metrics_flush,
                max_tags_per_metric=resolved_metrics_max_tags_per_metric,
            )
            self.metrics: metrics_api_module.MetricsAPI | None = metrics_api_module.MetricsAPI(
                aggregator=self._metrics_aggregator
            )
            metrics_init_module._set_default_metrics(self.metrics)
        else:
            self.metrics = None

    def _on_span_end(self, span: span_module.Span) -> None:
        self._buffer.add_span(span.to_dict())
        self._flusher.notify()

    def _on_metrics_flush(self, payloads: list[dict[str, Any]]) -> None:
        self._buffer.add_metrics(payloads)
        self._flusher.notify()

    def _validate_config(
        self,
        api_key: str,
        base_url: str,
        flush_interval: float,
        flush_size: int,
        max_buffer_size: int,
        http_timeout: float,
        http_pool_size: int,
        rate_limit_buffer: float,
    ) -> None:
        errors = []

        if not api_key or not isinstance(api_key, str):
            errors.append("api_key must be a non-empty string")

        if not api_key.startswith("ledger_"):
            errors.append("api_key must start with 'ledger_' prefix")

        if not base_url or not isinstance(base_url, str):
            errors.append("base_url must be a non-empty string")

        if not base_url.startswith(("http://", "https://")):
            errors.append("base_url must start with 'http://' or 'https://'")

        if flush_interval <= 0:
            errors.append(f"flush_interval must be positive, got {flush_interval}")

        if flush_size <= 0:
            errors.append(f"flush_size must be positive, got {flush_size}")

        if max_buffer_size <= 0:
            errors.append(f"max_buffer_size must be positive, got {max_buffer_size}")

        if http_timeout <= 0:
            errors.append(f"http_timeout must be positive, got {http_timeout}")

        if http_pool_size <= 0:
            errors.append(f"http_pool_size must be positive, got {http_pool_size}")

        if not 0 < rate_limit_buffer <= 1:
            errors.append(f"rate_limit_buffer must be between 0 and 1, got {rate_limit_buffer}")

        if errors:
            raise ValueError("Invalid Ledger SDK configuration:\n  - " + "\n  - ".join(errors))

    def log_info(
        self,
        message: str,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        """Log an informational message.

        Args:
            message: The log message to record.
            attributes: Optional dictionary of custom attributes to attach to the log.
                Can contain any JSON-serializable values.

        Example:
            >>> client.log_info("User logged in", {"user_id": "123", "ip": "192.168.1.1"})
        """
        self._log(
            level="info",
            log_type="console",
            importance="standard",
            message=message,
            attributes=attributes,
        )

    def log_warning(
        self,
        message: str,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        """Log a warning message.

        Args:
            message: The warning message to record.
            attributes: Optional dictionary of custom attributes to attach to the log.
                Can contain any JSON-serializable values.

        Example:
            >>> client.log_warning("Cache miss rate high", {"rate": 0.85})
        """
        self._log(
            level="warning",
            log_type="console",
            importance="standard",
            message=message,
            attributes=attributes,
        )

    def log_error(
        self,
        message: str,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        """Log an error message.

        Args:
            message: The error message to record.
            attributes: Optional dictionary of custom attributes to attach to the log.
                Can contain any JSON-serializable values.

        Example:
            >>> client.log_error("Payment failed", {"order_id": "ORD-123", "amount": 99.99})
        """
        self._log(
            level="error",
            log_type="console",
            importance="high",
            message=message,
            attributes=attributes,
        )

    def log_exception(
        self,
        exception: Exception,
        message: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        """Log an exception with full stack trace.

        Automatically captures the exception type, message, and full stack trace.

        Args:
            exception: The exception object to log.
            message: Optional custom message. If not provided, uses str(exception).
            attributes: Optional dictionary of custom attributes to attach to the log.
                Can contain any JSON-serializable values.

        Example:
            >>> try:
            ...     risky_operation()
            ... except Exception as e:
            ...     client.log_exception(e, "Failed to process order", {"order_id": "123"})
        """
        stack_trace = "".join(
            traceback.format_exception(
                type(exception),
                exception,
                exception.__traceback__,
            )
        )

        self._log(
            level="error",
            log_type="exception",
            importance="high",
            message=message or str(exception),
            error_type=exception.__class__.__name__,
            error_message=str(exception),
            stack_trace=stack_trace,
            attributes=attributes,
        )

    def log_endpoint(
        self,
        method: str,
        path: str,
        status_code: int,
        duration_ms: float,
        query_params: str | None = None,
        path_params: dict[str, Any] | None = None,
        response_body: str | None = None,
    ) -> None:
        """Log an HTTP endpoint invocation.

        Args:
            method: HTTP method (GET, POST, etc.).
            path: Request path, optionally normalized.
            status_code: HTTP response status code.
            duration_ms: Request duration in milliseconds.
            query_params: Optional raw query string.
            path_params: Optional dict of path parameter names to their values.
            response_body: Optional response body preview for error responses (4 KB cap).

        Example:
            >>> client.log_endpoint("GET", "/users/{id}", 200, 12.5, path_params={"id": "123"})
        """
        if 200 <= status_code < 400:
            level = "info"
            importance = "standard"
        elif 400 <= status_code < 500:
            level = "warning"
            importance = "standard"
        else:
            level = "error"
            importance = "high"

        message = f"{method} {path} - {status_code} ({duration_ms:.0f}ms)"

        endpoint_data: dict[str, Any] = {
            "method": method,
            "path": path,
            "status_code": status_code,
            "duration_ms": round(duration_ms, 2),
        }

        if query_params:
            endpoint_data["query_params"] = query_params

        if path_params:
            endpoint_data["path_params"] = path_params

        if response_body:
            endpoint_data["response_body"] = response_body

        self._log(
            level=level,
            log_type="endpoint",
            importance=importance,
            message=message,
            attributes={"endpoint": endpoint_data},
        )

    def _log(
        self,
        level: str,
        log_type: str,
        importance: str,
        message: str | None = None,
        error_type: str | None = None,
        error_message: str | None = None,
        stack_trace: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        self._flusher.ensure_started()

        log_entry: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "level": level,
            "log_type": log_type,
            "importance": importance,
        }

        if message:
            log_entry["message"] = message

        if error_type:
            log_entry["error_type"] = error_type

        if error_message:
            log_entry["error_message"] = error_message

        if stack_trace:
            log_entry["stack_trace"] = stack_trace

        merged_attributes: dict[str, Any] = dict(attributes) if attributes else {}
        if self.tracer is not None:
            current_span = self.tracer.get_current_span()
            if current_span is not None:
                merged_attributes["trace_id"] = current_span.trace_id
                merged_attributes["span_id"] = current_span.span_id

        if merged_attributes:
            log_entry["attributes"] = merged_attributes

        log_entry["sdk_version"] = __version__
        log_entry["platform"] = "python"
        log_entry["platform_version"] = self.platform_version

        if self.environment:
            log_entry["environment"] = self.environment

        if self.release:
            log_entry["release"] = self.release

        validated_log = self._validator.validate_log(log_entry)

        self._buffer.add(validated_log)

        if self._buffer.size() >= self._flush_size:
            self._flusher.notify()

    def is_healthy(self) -> bool:
        """Check if the client is operating normally.

        Returns False if any of the following conditions are met:
        - Circuit breaker is open (too many consecutive failures)
        - 3 or more consecutive flush failures
        - Buffer is more than 90% full

        Returns:
            True if the client is healthy, False otherwise.

        Example:
            >>> if not client.is_healthy():
            ...     print("Warning: Ledger client is experiencing issues")
        """
        flusher_metrics = self._flusher.get_metrics()

        if flusher_metrics["circuit_breaker_open"]:
            return False

        if flusher_metrics["consecutive_failures"] >= 3:
            return False

        buffer_utilization = (self._buffer.size() / self._buffer.max_size) * 100
        if buffer_utilization > 90:
            return False

        return True

    def get_health_status(self) -> dict[str, Any]:
        """Get detailed health status information.

        Returns:
            Dictionary containing:
            - status (str): Overall status - "healthy", "degraded", or "unhealthy"
            - healthy (bool): True if status is "healthy"
            - issues (list[str] | None): List of current issues, or None if healthy
            - buffer_utilization_percent (float): Percentage of buffer in use
            - circuit_breaker_open (bool): Whether circuit breaker is active
            - consecutive_failures (int): Number of consecutive flush failures

        Example:
            >>> status = client.get_health_status()
            >>> if status["status"] != "healthy":
            ...     print(f"Issues: {status['issues']}")
        """
        flusher_metrics = self._flusher.get_metrics()
        buffer_utilization = (self._buffer.size() / self._buffer.max_size) * 100

        status = "healthy"
        issues = []

        if flusher_metrics["circuit_breaker_open"]:
            status = "unhealthy"
            issues.append("Circuit breaker is open (too many failures)")

        if flusher_metrics["consecutive_failures"] >= 3:
            status = "degraded" if status == "healthy" else status
            issues.append(f"Consecutive failures: {flusher_metrics['consecutive_failures']}")

        if buffer_utilization > 90:
            status = "degraded" if status == "healthy" else status
            issues.append(f"Buffer nearly full: {buffer_utilization:.1f}%")

        if self._buffer.get_dropped_count() > 0:
            status = "degraded" if status == "healthy" else status
            issues.append(f"Dropped logs: {self._buffer.get_dropped_count()}")

        return {
            "status": status,
            "healthy": status == "healthy",
            "issues": issues or None,
            "buffer_utilization_percent": round(buffer_utilization, 2),
            "circuit_breaker_open": flusher_metrics["circuit_breaker_open"],
            "consecutive_failures": flusher_metrics["consecutive_failures"],
        }

    def _stop_background_services(self) -> None:
        if self._metrics_aggregator is not None:
            self._metrics_aggregator.stop()

    async def shutdown(self, timeout: float = 10.0) -> None:
        """Gracefully shut down the client and flush remaining logs.

        This method should be called before your application exits to ensure all
        buffered logs are sent to the server. For sync applications use shutdown_sync().

        Args:
            timeout: Maximum time in seconds to wait for pending logs to flush.
                Default is 10 seconds.

        Example:
            >>> await client.shutdown()
            >>> # Or with custom timeout:
            >>> await client.shutdown(timeout=30.0)
        """
        self._stop_background_services()
        if self._mode == "async":
            await self._flusher.shutdown(timeout=timeout)  # type: ignore[union-attr]
            if self._http_client is not None:
                await self._http_client.close()
        else:
            self._flusher.shutdown(timeout=timeout)  # type: ignore[union-attr]

    def shutdown_sync(self, timeout: float = 10.0) -> None:
        """Gracefully shut down the client from synchronous code (Flask, Django).

        Use this instead of shutdown() in sync contexts such as atexit handlers.

        Args:
            timeout: Maximum time in seconds to wait for pending logs to flush.
                Default is 10 seconds.

        Example:
            >>> import atexit
            >>> atexit.register(client.shutdown_sync)
        """
        self._stop_background_services()
        if self._mode == "threaded":
            self._flusher.shutdown(timeout=timeout)  # type: ignore[union-attr]
        else:
            asyncio.run(self.shutdown(timeout=timeout))

    def get_metrics(self) -> dict[str, Any]:
        """Get comprehensive metrics about SDK performance and status.

        Returns:
            Dictionary containing:
            - sdk: SDK version and uptime information
            - buffer: Current buffer size, capacity, and dropped logs
            - flusher: Flush statistics including successes, failures, and timing
            - rate_limiter: Current rate and limits
            - errors: Error counts by type

        Example:
            >>> metrics = client.get_metrics()
            >>> print(f"Uptime: {metrics['sdk']['uptime_seconds']}s")
            >>> print(f"Success rate: {metrics['flusher']['successful_flushes']} / {metrics['flusher']['total_flushes']}")
        """
        flusher_metrics = self._flusher.get_metrics()
        uptime = (datetime.now(timezone.utc) - self._sdk_start_time).total_seconds()

        return {
            "sdk": {
                "uptime_seconds": round(uptime, 2),
                "version": __version__,
            },
            "buffer": {
                "current_size": self._buffer.size(),
                "max_size": self._buffer.max_size,
                "total_dropped": self._buffer.get_dropped_count(),
                "utilization_percent": round(
                    (self._buffer.size() / self._buffer.max_size) * 100, 2
                ),
            },
            "flusher": {
                "total_flushes": flusher_metrics["total_flushes"],
                "successful_flushes": flusher_metrics["successful_flushes"],
                "failed_flushes": flusher_metrics["failed_flushes"],
                "total_logs_sent": flusher_metrics["total_logs_sent"],
                "total_logs_failed": flusher_metrics["total_logs_failed"],
                "total_logs_rejected": flusher_metrics["total_logs_rejected"],
                "consecutive_failures": flusher_metrics["consecutive_failures"],
                "circuit_breaker_open": flusher_metrics["circuit_breaker_open"],
                "last_flush_time": flusher_metrics["last_flush_time"],
                "last_error": flusher_metrics["last_error"],
            },
            "rate_limiter": {
                "current_rate": self._rate_limiter.get_current_rate(),
                "limit_per_minute": self._rate_limiter.limit_per_minute,
            },
            "errors": flusher_metrics["errors_by_type"],
        }
