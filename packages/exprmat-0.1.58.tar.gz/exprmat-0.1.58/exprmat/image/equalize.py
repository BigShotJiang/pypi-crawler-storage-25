
import numpy as np


def equalize_histogram(layer):
    
    hist, bins = np.histogram(layer.flatten(), 256, [0, 256])
    
    # cumulative density function
    cdf = hist.cumsum()
    cdf_normalized = cdf * hist.max() / cdf.max()
    
    # mapping
    cdf_m = np.ma.masked_equal(cdf, 0)
    cdf_m = (cdf_m - cdf_m.min()) * 255 / (cdf_m.max() - cdf_m.min())
    cdf = np.ma.filled(cdf_m, 0).astype('uint8')

    equalized = cdf[layer]
    return equalized