
from tifffile import TiffFile as tiff
import os
import numpy as np
from exprmat import error, warning, info


def mix_channels(cyx, channel_colors = None, channel_intensities = None):
        
    nc, ny, nx = cyx.shape

    def int_to_rgb(color_int):
        c = color_int & 0xFFFFFFFF
        r = (c >> 16) & 0xFF
        g = (c >> 8)  & 0xFF
        b =  c        & 0xFF
        return r / 255, g / 255, b / 255
    
    def named_to_rgb(named):
        from matplotlib.colors import to_rgb
        return to_rgb(named)
    
    # mix color channel. if colormix is None, use the predefined colors from channels.
    # otherwise, the length of the mixer must match the channels selected.

    r = np.zeros((ny, nx))
    g = np.zeros((ny, nx))
    b = np.zeros((ny, nx))

    if channel_colors is not None:
        if len(channel_colors) != nc:
            error('color mixer must of the same length of channels')
        
    for i in range(nc):
        rx, gx, bx = named_to_rgb(channel_colors[i])
        ch = cyx[i, :, :]
        r += rx * ch * channel_intensities[i] if channel_intensities is not None else rx * ch
        g += gx * ch * channel_intensities[i] if channel_intensities is not None else rx * ch
        b += bx * ch * channel_intensities[i] if channel_intensities is not None else rx * ch
    
    stk = np.stack([r, g, b], axis = 2)
    stk[stk > 255] = 255
    stk[stk < 0] = 0
    stk = stk.astype('uint8')
    return stk