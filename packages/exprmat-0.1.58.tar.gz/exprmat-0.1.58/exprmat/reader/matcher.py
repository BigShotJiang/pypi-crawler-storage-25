'''
Matcher module aims to align different versions of genomic annotations (esp. for
human and mice) into one uniform nomenclature. Names of genes frequently vary,
and less frequently do their accessions in database. Routines here is used to 
filter genes that present in common database annotations, match them to common
accessions, and align new datasets to existing ones.
'''

import os
import scanpy as sc
import anndata as ad
import pandas as pd
import numpy as np

from scipy.sparse import csr_matrix
from exprmat.ansi import error, warning, info
from exprmat.data.finders import get_mapper_ensembl, get_mapper_name, get_genome
from exprmat.data.finders import update_mapper_ensembl, update_mapper, save_genome_changes
from exprmat.reader.metadata import metadata
from exprmat import config as cfg
from exprmat.ansi import info


def refine_finder(features_fpath, taxa = 'mmu'):
    table = pd.read_table(features_fpath, sep = '\t', header = None)
    assert len(table.columns) >= 2

    name_finder = get_mapper_name(taxa)
    ensembl_finder = get_mapper_ensembl(taxa)

    ensembls = table[0].tolist()
    names = table[1].tolist()
    mentioned_taxa = []

    for ens, nm in zip(ensembls, names):

        # here, we will check whether the names and ensembls starts with a reference
        # prefix. 10x's default will append something like mm10_ before the gene names
        # and indices in multi-species joint analysis. if there is no such prefix detected
        # this means the gene comes from the default taxa.
        
        if '_' in ens:
            reference_name = ens.split('_')[0]
            pure_ens = ens.replace(reference_name + '_', '')
            pure_nm = nm.replace(reference_name + '_', '')
            if not reference_name.lower() in cfg['taxa.reference'].keys():
                warning(f'gene {ens} seems to have a reference prefix, but not registered to taxa.')
                continue

            reference_taxa = cfg['taxa.reference'][reference_name.lower()]
            alt_name_finder = get_mapper_name(reference_taxa)
            alt_ens_finder = get_mapper_ensembl(reference_taxa)
            if ((pure_nm not in alt_name_finder.keys()) or (pure_ens not in alt_ens_finder.keys())):
                update_mapper(reference_taxa, pure_nm, pure_ens)
                if reference_taxa not in mentioned_taxa: mentioned_taxa += [reference_taxa]

        elif ((nm not in name_finder.keys()) or (ens not in ensembl_finder.keys())):
            update_mapper(taxa, nm, ens)
            if taxa not in mentioned_taxa: mentioned_taxa += [taxa]

    for taxa in mentioned_taxa:
        save_genome_changes(taxa)


def adjust_features(path, refine_finder = False, default_taxa = 'mmu', eccentric = None):
    '''
    There are three main types of features table that may occur in the matrix data folder.
    
    The currently using specification of 10x's feature files contains 3 columns for every
    feature detected, with the first column being ENSEMBL gene IDs, the second column being
    gene names, and ther third column being feature types. Feature types is an enumeration
    between ``Gene Expression``, ``Antibody Capture``, ``CRISPR Guide Capture``, 
    ``Multiplexing Capture``, or ``CUSTOM``. For multi-species data, the features and gene
    names start with the reference name, for 10x's default, e.g. ``mm10`` or ``hg19``.

    For prebuilt 10x references, the taxonomy prefixes are:

    - v1.2.0     human [hg19]     mouse [mm10]
    - v2.1.0     human [hg19]     mouse [mm10]
    - v3.0.0     human [hg19]     mouse [mm10]
    - v3.1.0     human [GRCh38]   mouse [mm10]
    - 2020a      human [GRCh38]   mouse [mm10]
    - 2024a      human [GRCh38]   mouse [GRCm39]

    For old 10x specification, when there is no antibody capture protocols been developed,
    this file may be named as ``genes.tsv``, and contains only 2 columns (before 2020.) The
    files are not compressed as they are now, and defaults to gene expression mRNA captures.

    For BGI's C4 platform, similar outputs are given in the same name as ``features.tsv.gz``,
    however, only one column indicating gene names present in this table. 

    This function helps to normalize the feature formats into the full 3-column structure,
    and compress the file if it is not done before. Since this is the only difference that
    happen to the three file components, we will enforce the format to be the newest 10x
    ones, and use the same routines to read them into memory.
    '''
    
    import pandas as pd
    fpath = os.path.join(path, 'features.tsv.gz')
    if not os.path.exists(fpath): fpath = os.path.join(path, 'features.tsv')
    if not os.path.exists(fpath): fpath = os.path.join(path, 'genes.tsv.gz')
    if not os.path.exists(fpath): fpath = os.path.join(path, 'genes.tsv')
    if not os.path.exists(fpath):
        error('do not find any possible feature table.')
        
    table = pd.read_table(fpath, sep = '\t', header = None)
    n_columns = len(table.columns)

    if n_columns >= 2 and refine_finder:

        name_finder = get_mapper_name(default_taxa)
        ensembl_finder = get_mapper_ensembl(default_taxa)

        ensembls = table[0].tolist()
        names = table[1].tolist()
        mentioned_taxa = []
        for ens, nm in zip(ensembls, names):

            # here, we will check whether the names and ensembls starts with a reference
            # prefix. 10x's default will append something like mm10_ before the gene names
            # and indices in multi-species joint analysis. if there is no such prefix detected
            # this means the gene comes from the default taxa.
            
            if eccentric is not None: ens = eccentric(ens)
            if '_' in ens:
                reference_name = ens.split('_')[0]
                pure_ens = ens.replace(reference_name + '_', '')
                pure_nm = nm.replace(reference_name + '_', '')
                if not reference_name.lower() in cfg['taxa.reference'].keys():
                    warning(f'gene {ens} seems to have a reference prefix, but not registered to taxa.')
                    continue

                reference_taxa = cfg['taxa.reference'][reference_name.lower()]
                alt_name_finder = get_mapper_name(reference_taxa)
                alt_ens_finder = get_mapper_ensembl(reference_taxa)
                if ((pure_nm not in alt_name_finder.keys()) or (pure_ens not in alt_ens_finder.keys())):
                    update_mapper(reference_taxa, pure_nm, pure_ens)
                    if reference_taxa not in mentioned_taxa: mentioned_taxa += [reference_taxa]

            elif ((nm not in name_finder.keys()) or (ens not in ensembl_finder.keys())):
                update_mapper(default_taxa, nm, ens)
                if default_taxa not in mentioned_taxa: mentioned_taxa += [default_taxa]

        for taxa in mentioned_taxa:
            save_genome_changes(taxa)

    # stringify the integer-indexed barcodes
    # bd rhapsody's data usually like this.
    bfile = os.path.join(path, 'barcodes.tsv')
    if not os.path.exists(bfile): bfile = os.path.join(path, 'barcodes.tsv.gz')
    if not os.path.exists(bfile):
        error('do not find any possible barcode table.')
    
    bc = pd.read_table(bfile, sep = '\t', header = None)
    bc.columns = ['id']
    oldid = bc['id'].tolist()
    newid = [(f'C{x}' if str(x).isnumeric() else str(x)) for x in bc['id']]

    if oldid != newid:
        bc['id'] = newid
        bc.to_csv(
            os.path.join(path, 'barcodes.tsv.gz'), 
            sep = '\t', header = None, index = False
        )

    if n_columns >= 3: 

        fpath = os.path.join(path, 'genes.tsv')
        if os.path.exists(fpath):
            os.rename(os.path.join(path, 'genes.tsv'), os.path.join(path, 'features.tsv'))
        
        fpath = os.path.join(path, 'features.tsv')
        if os.path.exists(fpath):
            from sh import gzip
            gzip(fpath)

        fpath = os.path.join(path, 'barcodes.tsv')
        if os.path.exists(fpath):
            from sh import gzip
            gzip(fpath)

        fpath = os.path.join(path, 'matrix.mtx')
        if os.path.exists(fpath):
            from sh import gzip
            gzip(fpath)

        return
    

    if n_columns == 2:

        info(f'path [{path}] contains legacy gene table.')
        construct = pd.DataFrame({
            'v0': table[0].tolist(),
            'v1': table[1].tolist(),
            'v2': ['Gene Expression'] * len(table[1].tolist())
        })

    if n_columns == 1:

        info(f'path [{path}] contains name only gene table.')
        query_gname = table[0].tolist()
        genome = get_genome(default_taxa)
        finder_gname = genome['gene'].tolist()
        finder_ensembl = genome['id'].tolist()

        query_ensembl = []
        n_not_found = 0
        for x in query_gname:
            
            if eccentric is not None: x = eccentric(x)
            if '_' in x:
                
                reference_name = x.split('_')[0]
                pure_nm = x.replace(reference_name + '_', '')
                
                if not reference_name.lower() in cfg['taxa.reference'].keys():
                    warning(f'gene {x} seems to have a reference prefix, but not registered to taxa.')
                    query_ensembl += [x]
                    n_not_found += 1
                    continue

                reference_taxa = cfg['taxa.reference'][reference_name.lower()]
                alt_name_finder = get_genome(reference_taxa)['gene'].tolist()
                alt_ens_finder = get_genome(reference_taxa)['id'].tolist()

                if x in finder_gname: 
                    query_ensembl += [reference_name + '_' + alt_ens_finder[alt_name_finder.index(pure_nm)]]
                    continue

            if x in finder_gname: 
                query_ensembl += [finder_ensembl[finder_gname.index(x)]]
            
            else: 
                query_ensembl += [x]
                n_not_found += 1
    
        construct = pd.DataFrame({
            'v0': query_ensembl,
            'v1': query_gname,
            'v2': ['Gene Expression'] * len(query_gname)
        })

        info(f'[adjust] {n_not_found} genes not found in reference when matching gene names.')
        info(f'[adjust] {len(finder_gname)} genes in reference genome annotation')

    construct.to_csv(
        os.path.join(path, 'features.tsv.gz'), 
        sep = '\t', header = None, index = False
    )

    fpath = os.path.join(path, 'barcodes.tsv')
    if os.path.exists(fpath):
        from sh import gzip
        gzip(fpath)
    
    fpath = os.path.join(path, 'matrix.mtx')
    if os.path.exists(fpath):
        from sh import gzip
        gzip(fpath)
    
    fpath = os.path.join(path, 'genes.tsv')
    if os.path.exists(fpath):
        os.rename(fpath, os.path.join(path, 'genes.tsv.backup'))

    return
    

def read_mtx_rna(
    src: str, prefix: str, 
    metadata: metadata, sample: str, raw: bool = False,
    default_taxa = 'mmu', eccentric = None, suppress_filter = False,
):
    '''
    Formalize the three components in the matrix directory, and read the folder with gene
    expression data only.

    Parameters
    ----------

    src : str
        The directory to the matrix.
    
    prefix : str
        Prefix before the file name convention.
    
    metadata : exprmat.reader.metadata.metadata
        The sample specific metadata table.
    
    sample : str
        The sample name according to the metadata.

    raw : bool
        Whether this expression matrix is confirmed to be unfiltered one. Unfiltered expression
        matrix contains all detected beads or droplets, including the empty drops and doublets
        at higher probabilities. We guess this field by default to see if a sample contains
        unexpectedly high number of cells.
    '''

    # try:
    
    adjust_features(src, refine_finder = True, default_taxa = default_taxa, eccentric = eccentric)

    import warnings
    warnings.filterwarnings('ignore')

    adata = sc.read_10x_mtx(
        src, var_names = 'gene_ids', gex_only = True, make_unique = False,
        prefix = prefix
    )

    if eccentric is not None:
        adata.var_names = [eccentric(x) for x in adata.var_names]

    # except Exception as ex: 
    #     warning('error occurs when reading matrix files:')
    #     warning(str(ex))
    #     return None

    final = match_matrix_rna(
        adata, metadata, sample, suppress_filter = suppress_filter,
        force_filter = raw, default_taxa = default_taxa
    )

    warnings.filterwarnings('default')
    
    del adata
    return final


def read_h5_rna(
    src: str, 
    metadata: metadata, sample: str, raw: bool = False,
    default_taxa = 'mmu', eccentric = None, suppress_filter = False,
):
    import warnings
    warnings.filterwarnings('ignore')

    adata = sc.read_10x_h5(
        src, gex_only = True
    )

    adata.var_names = adata.var['gene_ids'].tolist()
    del adata.var

    if eccentric is not None:
        adata.var_names = [eccentric(x) for x in adata.var_names]

    # except Exception as ex: 
    #     warning('error occurs when reading matrix files:')
    #     warning(str(ex))
    #     return None

    final = match_matrix_rna(
        adata, metadata, sample, suppress_filter = suppress_filter,
        force_filter = raw, default_taxa = default_taxa
    )

    warnings.filterwarnings('default')
    
    del adata
    return final


def read_mtx_cite(
    src: str, prefix: str, 
    metadata: metadata, sample: str, raw: bool = False,
    default_taxa = 'mmu', eccentric = None, suppress_filter = False,
):
    import warnings
    warnings.filterwarnings('ignore')

    adata = sc.read_10x_mtx(
        src, var_names = 'gene_ids', gex_only = False, make_unique = False,
        prefix = prefix
    )

    if eccentric is not None:
        adata.var_names = [eccentric(x) for x in adata.var_names]

    # split the rna and antigen part of the data
    rna = adata[:, adata.var['feature_types'] == 'Gene Expression'].copy()
    acap = adata[:, adata.var['feature_types'] == 'Antibody Capture'].copy()
    del adata

    final = match_matrix_rna(
        rna, metadata, sample, suppress_filter = suppress_filter,
        force_filter = raw, default_taxa = default_taxa
    )

    final_abc = match_matrix_cite(
        acap, final, metadata, sample, suppress_filter = suppress_filter,
        force_filter = raw, default_taxa = default_taxa
    )

    warnings.filterwarnings('default')
    return final, final_abc


def read_h5_cite(
    src: str, 
    metadata: metadata, sample: str, raw: bool = False,
    default_taxa = 'mmu', eccentric = None, suppress_filter = False,
):
    import warnings
    warnings.filterwarnings('ignore')

    adata = sc.read_10x_h5(
        src, gex_only = False
    )

    adata.var_names = adata.var['gene_ids'].tolist()
    rna = adata[:, adata.var['feature_types'] == 'Gene Expression'].copy()
    acap = adata[:, adata.var['feature_types'] == 'Antibody Capture'].copy()
    del rna.var
    del acap.var
    del adata

    if eccentric is not None:
        adata.var_names = [eccentric(x) for x in adata.var_names]
        
    final = match_matrix_rna(
        rna, metadata, sample, suppress_filter = suppress_filter,
        force_filter = raw, default_taxa = default_taxa
    )

    final_abc = match_matrix_cite(
        acap, final, metadata, sample, suppress_filter = suppress_filter,
        force_filter = raw, default_taxa = default_taxa
    )

    warnings.filterwarnings('default')
    return final, final_abc


def read_table_rna(
    src: str, 
    metadata: metadata, sample: str, raw: bool = False,
    default_taxa = 'mmu', eccentric = None, sep = '\t'
):
    '''
    Read from compressed or plain text tables.

    Parameters
    ----------

    src : str
        The directory to the matrix.
    
    metadata : exprmat.reader.metadata.metadata
        The sample specific metadata table.
    
    sample : str
        The sample name according to the metadata.

    raw : bool
        Whether this expression matrix is confirmed to be unfiltered one. Unfiltered expression
        matrix contains all detected beads or droplets, including the empty drops and doublets
        at higher probabilities. We guess this field by default to see if a sample contains
        unexpectedly high number of cells.
    '''

    # try:
    
    # in csv/tsv texts, genes are rows and cells are columns.
    adata = sc.read_text(
        src, delimiter = sep, first_column_names = True, dtype = 'float32'
    ).T

    if eccentric is not None:
        adata.var_names = [eccentric(x) for x in adata.var_names]

    # except Exception as ex: 
    #     warning('error occurs when reading matrix files:')
    #     warning(str(ex))
    #     return None

    final = match_matrix_rna(
        adata, metadata, sample, 
        force_filter = raw, default_taxa = default_taxa
    )
    
    del adata
    return final


def read_h5ad_rna(
        src: str, 
        metadata: metadata, sample: str, raw: bool = False,
        default_taxa = 'mmu', eccentric = None
    ):
    '''
    Read from a given h5ad. This typically occurs when you have to prepare the data yourself
    from others who give you a complex atlas. The assignment of samples and batches happens
    within a single h5ad file. Then, you would like to keep nearly all of the metadata you
    prepared by hand as it is. Only `modality`, `taxa` and `ubc` are generated for you.

    Thus, you must manually supply `sample`, `batch` and `group` yourself. Otherwise the program
    may not work as usual. It permits multiple samples in one h5ad file.

    Parameters
    ----------

    src : str
        The directory to the matrix.
    
    prefix : str
        Prefix before the file name convention.
    
    metadata : exprmat.reader.metadata.metadata
        The sample specific metadata table.
    
    sample : str
        The sample name according to the metadata.

    raw : bool
        Whether this expression matrix is confirmed to be unfiltered one. Unfiltered expression
        matrix contains all detected beads or droplets, including the empty drops and doublets
        at higher probabilities. We guess this field by default to see if a sample contains
        unexpectedly high number of cells.
    '''

    # try:
    
    adata = sc.read_h5ad(src)

    # except Exception as ex: 
    #     warning('error occurs when reading matrix files:')
    #     warning(str(ex))
    #     return None

    if adata.var_names.tolist()[0].startswith('rna:'):
        info('it seems that you have prepared the h5ad file manually.')
        info('we will not alter anything and test mandatory columns as is.')
        assert 'sample' in adata.obs.keys()
        assert 'modality' in adata.obs.keys()
        assert 'taxa' in adata.obs.keys()
        assert 'batch' in adata.obs.keys()
        assert 'gene' in adata.var.keys()
        return adata
    
    if eccentric is not None:
        adata.var_names = [eccentric(x) for x in adata.var_names]
    
    final = match_matrix_rna(
        adata, metadata, sample, 
        force_filter = raw, default_taxa = default_taxa,
        # this switch tells the program not to alter the cell names (keep them
        # directly to `barcodes`, not adding prefix to them), and keep the
        # sample, batch, and group columns as is. 
        do_not_alter_obs_names = True
    )
    
    del adata
    return final


def read_rds_rna(
        src: str, 
        metadata: metadata, sample: str, raw: bool = False,
        default_taxa = 'mmu', eccentric = None,
    ):

    import exprmat.parser as ep
    robj = ep.parse_rds(src)
    
    rclass = robj.get_class()
    adata = None

    if rclass == 'Seurat':
        # do not load any embeddings if loaded from startup.
        adata = ep.load_seurat(robj, assay = 'RNA', default_layer = 'counts', embeddings = [])
    
    else: error(f'r object of type {rclass} is not supported.')

    if adata.var_names.tolist()[0].startswith('rna:'):
        info('it seems that you have prepared the h5ad file manually.')
        info('we will not alter anything and test mandatory columns as is.')
        assert 'sample' in adata.obs.keys()
        assert 'modality' in adata.obs.keys()
        assert 'taxa' in adata.obs.keys()
        assert 'batch' in adata.obs.keys()
        assert 'gene' in adata.var.keys()
        return adata
    
    if eccentric is not None:
        adata.var_names = [eccentric(x) for x in adata.var_names]
    
    final = match_matrix_rna(
        adata, metadata, sample, 
        force_filter = raw, default_taxa = default_taxa,
        # this switch tells the program not to alter the cell names (keep them
        # directly to `barcodes`, not adding prefix to them), and keep the
        # sample, batch, and group columns as is. 
        do_not_alter_obs_names = True
    )
    
    del adata
    return final


def convert_to_ugene(gname, taxa, eccentric = None):
    
    if eccentric:
        gname = [eccentric(x) for x in gname]
        
    # map gene naming
    names = []
    gmask = []

    # here, we just add another condition to test whether the gname list is appropriate
    # ensembl format. if it is not, we try to map genes directly onto the names.
    # though i specify the var_names should be 'gene_ids', it may occur exceptions
    # where there are man-made references containing two or more species. by convention
    # in these double species reference, the 'gene_ids' should be 'mm10_ENSMUSG...'
    # or just name of the genes.

    default_finder_ens = get_mapper_ensembl(taxa)
    default_finder_name = get_mapper_name(taxa)
    not_in_list = []

    for x in gname:

        if '_' in x:

            reference_name = x.split('_')[0]
            pure_nm = x.replace(reference_name + '_', '')

            if not reference_name.lower() in cfg['taxa.reference'].keys():
                warning(f'gene {x} seems to have a reference prefix, but not registered to taxa.')
                gmask.append(False)
                not_in_list.append(x)
                continue

            reference_taxa = cfg['taxa.reference'][reference_name.lower()]
            alt_finder_name = get_mapper_name(reference_taxa)
            alt_finder_ens = get_mapper_ensembl(reference_taxa)

            if pure_nm in alt_finder_ens.keys():
                gmask.append(True)
                names.append(alt_finder_ens[pure_nm])
                continue
            
            if pure_nm in alt_finder_name.keys():
                gmask.append(True)
                names.append(alt_finder_name[pure_nm])
                continue
        
        if x in default_finder_ens.keys():
            gmask.append(True)
            names.append(default_finder_ens[x])
            continue
        
        if x in default_finder_name.keys():
            gmask.append(True)
            names.append(default_finder_name[x])
            continue
            
        gmask.append(False)
        not_in_list.append(x)

    names = ['rna:' + x for x in names]
    return names, gmask, not_in_list


def match_matrix_rna(
    adata, metadata: metadata, sample: str, 
    force_filter = False, default_taxa = 'mmu',
    do_not_alter_obs_names = False, suppress_filter = False
):

    # if more than 50000 cells in a single matrix, we just believe that it is
    # an unfiltered raw matrix. we should roughly filter the empty droplets

    raw_temp = None
    if force_filter and (not suppress_filter):

        # run empty drops.
        from exprmat.preprocessing.background import emptydrops
        filt, meta = emptydrops(adata) # filt is just a view.
        adata_f = filt.copy()
        adata_f.uns['emptydrops'] = meta
        raw_temp = adata

    else: adata_f = adata

    rows = metadata.dataframe[metadata.dataframe['sample'] == sample]
    assert len(rows) >= 1
    rows = rows[
        (rows['modality'] == 'rna') |
        (rows['modality'] == 'rna.raw') |
        (rows['modality'] == 'rnasp-c') |
        (rows['modality'] == 'rnasp-b') |
        (rows['modality'] == 'rnasp-s') |
        (rows['modality'] == 'cite')
    ]
    assert len(rows) == 1
    props = rows.iloc[0]

    if not do_not_alter_obs_names:
        # append the sample name to the barcode
        adata_f.obs_names = props['sample'] + ':' + adata_f.obs_names

    # map gene naming
    gname = adata_f.var_names.tolist()
    names = []
    gmask = []

    # here, we just add another condition to test whether the gname list is appropriate
    # ensembl format. if it is not, we try to map genes directly onto the names.
    # though i specify the var_names should be 'gene_ids', it may occur exceptions
    # where there are man-made references containing two or more species. by convention
    # in these double species reference, the 'gene_ids' should be 'mm10_ENSMUSG...'
    # or just name of the genes.

    default_finder_ens = get_mapper_ensembl(default_taxa)
    default_finder_name = get_mapper_name(default_taxa)
    not_in_list = []

    for x in gname:

        if '_' in x:

            reference_name = x.split('_')[0]
            pure_nm = x.replace(reference_name + '_', '')

            if not reference_name.lower() in cfg['taxa.reference'].keys():
                warning(f'gene {x} seems to have a reference prefix, but not registered to taxa.')
                gmask.append(False)
                not_in_list.append(x)
                continue

            reference_taxa = cfg['taxa.reference'][reference_name.lower()]
            alt_finder_name = get_mapper_name(reference_taxa)
            alt_finder_ens = get_mapper_ensembl(reference_taxa)

            if pure_nm in alt_finder_ens.keys():
                gmask.append(True)
                names.append(alt_finder_ens[pure_nm])
                continue
            
            if pure_nm in alt_finder_name.keys():
                gmask.append(True)
                names.append(alt_finder_name[pure_nm])
                continue
        
        if x in default_finder_ens.keys():
            gmask.append(True)
            names.append(default_finder_ens[x])
            continue
        
        if x in default_finder_name.keys():
            gmask.append(True)
            names.append(default_finder_name[x])
            continue
            
        gmask.append(False)
        not_in_list.append(x)

    final = adata_f[:, gmask]
    if raw_temp: raw_temp = raw_temp[:, gmask]

    final.var_names = ['rna:' + x for x in names]
    nondup = final.var_names.duplicated() == False
    final = final[:, nondup].copy()
    del adata_f

    if raw_temp: 
        raw_temp = raw_temp[:, nondup]
        raw_temp = raw_temp.copy() # convert a view to anndata
        
        assert raw_temp.shape[1] == final.shape[1]
        raw_temp.var = final.var.copy()
        del adata # remove the old raw adata reference.

    info(f'{len(not_in_list)} genes (out of {len(gname)}) not in the reference gene list.')
    info(f'total {len(names)} genes mapped. {len(np.unique(names))} unique genes.')
    
    # attach cell metadata onto the obs slot.
    
    for k in props.index.tolist():
        if do_not_alter_obs_names:
            if k in ['sample', 'batch', 'group']: continue
        if k not in ['location']: final.obs[k] = props[k]
    
    final.obs['barcode'] = final.obs_names
    final.obs['ubc'] = [props['sample'] + ':' + str(x + 1) for x in range(final.n_obs)]
    final.obs_names = [props['sample'] + ':' + str(x + 1) for x in range(final.n_obs)]
    del final.var
    
    if not isinstance(final.X, csr_matrix):
        final.X = csr_matrix(final.X)

    # if raw exist, store the data into a temporary location that cannot be saved.
    if raw_temp: final.uns['.raw'] = raw_temp

    return final


def match_matrix_cite(
    adata, accompany_rna, metadata: metadata, sample: str, 
    force_filter = False, default_taxa = 'mmu',
    do_not_alter_obs_names = False, suppress_filter = False
):

    # if more than 50000 cells in a single matrix, we just believe that it is
    # an unfiltered raw matrix. we should roughly filter the empty droplets

    rows = metadata.dataframe[metadata.dataframe['sample'] == sample]
    assert len(rows) >= 1
    rows = rows[
        (rows['modality'] == 'cite')
    ]
    assert len(rows) == 1
    props = rows.iloc[0]

    barcodes = [x.replace(props['sample'] + ':', '') for x in accompany_rna.obs['barcode']]
    adata_f = adata[barcodes, :].copy()
    assert adata_f.n_obs > 0

    if not do_not_alter_obs_names:
        # append the sample name to the barcode
        adata_f.obs_names = props['sample'] + ':' + adata_f.obs_names

    final = adata_f
    final.var_names = ['ag:' + x for x in adata_f.var_names]
    # remove duplicated genes
    duplicated = set(final.var_names[final.var_names.duplicated()].tolist())
    final = final[:, final.var_names.duplicated() == False].copy()

    # attach cell metadata onto the obs slot.
    
    for k in props.index.tolist():
        if do_not_alter_obs_names:
            if k in ['sample', 'batch', 'group']: continue
        if k not in ['location']: final.obs[k] = props[k]
    
    final.obs['barcode'] = final.obs_names
    final.obs['ubc'] = accompany_rna.obs['ubc'].tolist()
    final.obs_names = final.obs['ubc'].tolist()
    del final.var
    
    if not isinstance(final.X, csr_matrix):
        final.X = csr_matrix(final.X)

    del adata_f
    return final


def stringify_repertoire(df, contig, v, d, j, nt, aa):
    clone = ""
    df = df.copy()
    df.fillna('na', inplace = True)
    if v is not None and j is not None:
        if d is not None: clone = 'vdj(' + df[v] + ', ' + df[d] + ', ' + df[j] + ')'
        else: clone = 'vj(' + df[v] + ', ' + df[j] + ')'
    
    # aa alone may show degrees of degeneration!
    if nt is not None: clone = clone + (', ' if not isinstance(clone, str) else '') + 'nt(' + df[nt] + ')'
    elif aa is not None: clone = clone + (', ' if not isinstance(clone, str) else '') + 'aa(' + df[aa] + ')'
    return f'{contig}(' + clone + ')' 


# the per-cell basis did not fully support double allele expression
# of the tcr and ig for now. however, this is added into consideration for
# parsing raw csv files

# t cells undergo beta-rearrangement (v-d-j) during double negative stage,
# and once any of the allele become rearranged, the formation of pre-tcr
# by ptcra (pre-alpha) and this allele will trigger pre-tcr signaling and 
# inhibit the rearrangement of another beta chain. thus only <1% of human
# t cells express two allele of tcr-beta. 

# tcr-alpha undergo lesser inhibition, and 10%-30% of t cells express both 
# alpha chain alleles. a t cell may possess 1 or 2 alpha allele(s) and only
# 1 beta allele.

# ig-heavy chain rearrange first similarly, and forms pre-bcr with vpreb and 
# lambda-5 (igll1). inhibiting the other allele of igh. kappa and lambda 
# light chains commonly express the first functional allele. thus bcr commonly
# contains one heavy chain allele, and one of the four kappa-lambda alleles.

def parse_tcr_percell(
    fpath, *, sep = ',', index = True,

    # the mapper of columns between some custom export files towards a uniform one.
    barcode = 'barcode',
    sample = 'sample',
    barcode_translation = None,

    trav_gene = None,
    traj_gene = None,
    tra_full_length = None,
    tra_productive = None,
    tra_umi = None,
    tra_reads = None,
    # only pass cdr3 sequence to the file
    # since only cdr3 is not encoded by genome.
    tra_nt = None,
    tra_aa = None,

    trbv_gene = None,
    trbd_gene = None,
    trbj_gene = None,
    trb_full_length = None,
    trb_productive = None,
    trb_umi = None,
    trb_reads = None,
    trb_nt = None,
    trb_aa = None
):
    if isinstance(fpath, str):
        raw_table = pd.read_table(fpath, index_col = 0 if index else None, sep = sep)
    else: raw_table = fpath

    barcodes = raw_table[barcode].tolist()
    if barcode_translation is not None:
        barcodes = [barcode_translation(x) for x in barcodes]
    
    tidy = { 'barcode': barcodes, 'sample': raw_table[sample].tolist() }
    tidy = pd.DataFrame(tidy)

    if trav_gene is not None: tidy['trav'] = raw_table[trav_gene].tolist()
    if traj_gene is not None: tidy['traj'] = raw_table[traj_gene].tolist()
    if tra_full_length is not None: tidy['tra.full'] = raw_table[tra_full_length].tolist()
    if tra_productive is not None: tidy['tra.productive'] = raw_table[tra_productive].tolist()
    if tra_umi is not None: tidy['tra.umi'] = raw_table[tra_umi].tolist()
    if tra_reads is not None: tidy['tra.reads'] = raw_table[tra_reads].tolist()
    if tra_nt is not None: tidy['tra.nt'] = raw_table[tra_nt].tolist()
    if tra_aa is not None: tidy['tra.aa'] = raw_table[tra_aa].tolist()

    if trbv_gene is not None: tidy['trbv'] = raw_table[trbv_gene].tolist()
    if trbd_gene is not None: tidy['trbd'] = raw_table[trbd_gene].tolist()
    if trbj_gene is not None: tidy['trbj'] = raw_table[trbj_gene].tolist()
    if trb_full_length is not None: tidy['trb.full'] = raw_table[trb_full_length].tolist()
    if trb_productive is not None: tidy['trb.productive'] = raw_table[trb_productive].tolist()
    if trb_umi is not None: tidy['trb.umi'] = raw_table[trb_umi].tolist()
    if trb_reads is not None: tidy['trb.reads'] = raw_table[trb_reads].tolist()
    if trb_nt is not None: tidy['trb.nt'] = raw_table[trb_nt].tolist()
    if trb_aa is not None: tidy['trb.aa'] = raw_table[trb_aa].tolist()

    present_a = \
        (trav_gene is not None) or \
        (traj_gene is not None) or \
        (tra_nt is not None) or \
        (tra_aa is not None)
    
    present_b = \
        (trbv_gene is not None) or \
        (trbd_gene is not None) or \
        (trbj_gene is not None) or \
        (trb_nt is not None) or \
        (trb_aa is not None)
    
    if present_a: tidy['tra'] = stringify_repertoire(
        tidy, 'tra', 
        'trav'   if trav_gene is not None else None, 
        None,
        'traj'   if traj_gene is not None else None, 
        'tra.nt' if tra_nt is not None else None, 
        'tra.aa' if tra_aa is not None else None
    )
        
    if present_b: tidy['trb'] = stringify_repertoire(
        tidy, 'trb', 
        'trbv'   if trbv_gene is not None else None, 
        'trbd'   if trbd_gene is not None else None, 
        'trbj'   if trbj_gene is not None else None, 
        'trb.nt' if trb_nt is not None else None, 
        'trb.aa' if trb_aa is not None else None
    )
    
    if present_a and present_b:
        tidy['clone'] = 'tcr(' + tidy['tra'] + ', ' + tidy['trb'] + ')'
    elif present_a: tidy['clone'] = tidy['tra']
    elif present_b: tidy['clone'] = tidy['trb']

    # assign a clone id for each.
    indices = []
    existing = {}
    next_id = 1
    clones = tidy['clone'].tolist()
    for c in clones:
        if c not in existing.keys():
            indices.append('c:' + str(next_id))
            existing[c] = 'c:' + str(next_id)
            next_id += 1
        else: indices.append(existing[c])
    
    tidy['clone.id'] = indices
    return tidy


def parse_bcr_percell(
    fpath, *, sep = ',', index = True,

    # the mapper of columns between some custom export files towards a uniform one.
    barcode = 'barcode',
    sample = 'sample',
    barcode_translation = None,

    ighv_gene = None,
    ighd_gene = None,
    ighj_gene = None,
    igh_full_length = None,
    igh_productive = None,
    igh_umi = None,
    igh_reads = None,
    igh_nt = None,
    igh_aa = None,

    igkv_gene = None,
    igkj_gene = None,
    igk_full_length = None,
    igk_productive = None,
    igk_umi = None,
    igk_reads = None,
    igk_nt = None,
    igk_aa = None,

    iglv_gene = None,
    iglj_gene = None,
    igl_full_length = None,
    igl_productive = None,
    igl_umi = None,
    igl_reads = None,
    igl_nt = None,
    igl_aa = None,
):
    if isinstance(fpath, str):
        raw_table = pd.read_table(fpath, index_col = 0 if index else None, sep = sep)
    else: raw_table = fpath

    barcodes = raw_table[barcode].tolist()
    if barcode_translation is not None:
        barcodes = [barcode_translation(x) for x in barcodes]
    
    tidy = { 'barcode': barcodes, 'sample': raw_table[sample].tolist() }
    tidy = pd.DataFrame(tidy)

    if ighv_gene is not None:       tidy['ighv']           = raw_table[ighv_gene].tolist()
    if ighd_gene is not None:       tidy['ighd']           = raw_table[ighd_gene].tolist()
    if ighj_gene is not None:       tidy['ighj']           = raw_table[ighj_gene].tolist()
    if igh_full_length is not None: tidy['igh.full']       = raw_table[igh_full_length].tolist()
    if igh_productive is not None:  tidy['igh.productive'] = raw_table[igh_productive].tolist()
    if igh_umi is not None:         tidy['igh.umi']        = raw_table[igh_umi].tolist()
    if igh_reads is not None:       tidy['igh.reads']      = raw_table[igh_reads].tolist()
    if igh_nt is not None:          tidy['igh.nt']         = raw_table[igh_nt].tolist()
    if igh_aa is not None:          tidy['igh.aa']         = raw_table[igh_aa].tolist()

    if igkv_gene is not None:       tidy['igkv']           = raw_table[igkv_gene].tolist()
    if igkj_gene is not None:       tidy['igkj']           = raw_table[igkj_gene].tolist()
    if igk_full_length is not None: tidy['igk.full']       = raw_table[igk_full_length].tolist()
    if igk_productive is not None:  tidy['igk.productive'] = raw_table[igk_productive].tolist()
    if igk_umi is not None:         tidy['igk.umi']        = raw_table[igk_umi].tolist()
    if igk_reads is not None:       tidy['igk.reads']      = raw_table[igk_reads].tolist()
    if igk_nt is not None:          tidy['igk.nt']         = raw_table[igk_nt].tolist()
    if igk_aa is not None:          tidy['igk.aa']         = raw_table[igk_aa].tolist()

    if igkv_gene is not None:       tidy['iglv']           = raw_table[iglv_gene].tolist()
    if igkj_gene is not None:       tidy['iglj']           = raw_table[iglj_gene].tolist()
    if igk_full_length is not None: tidy['igl.full']       = raw_table[igl_full_length].tolist()
    if igk_productive is not None:  tidy['igl.productive'] = raw_table[igl_productive].tolist()
    if igk_umi is not None:         tidy['igl.umi']        = raw_table[igl_umi].tolist()
    if igk_reads is not None:       tidy['igl.reads']      = raw_table[igl_reads].tolist()
    if igk_nt is not None:          tidy['igl.nt']         = raw_table[igl_nt].tolist()
    if igk_aa is not None:          tidy['igl.aa']         = raw_table[igl_aa].tolist()

    present_h = \
        (ighv_gene is not None) or \
        (ighd_gene is not None) or \
        (ighj_gene is not None) or \
        (igh_nt is not None) or \
        (igh_aa is not None)
    
    present_k = \
        (igkv_gene is not None) or \
        (igkj_gene is not None) or \
        (igk_nt is not None) or \
        (igk_aa is not None)

    present_l = \
        (iglv_gene is not None) or \
        (iglj_gene is not None) or \
        (igl_nt is not None) or \
        (igl_aa is not None)
    
    if present_h: tidy['igh'] = stringify_repertoire(
        tidy, 'igh', 
        'ighv'   if ighv_gene is not None else None, 
        'ighd'   if ighd_gene is not None else None, 
        'ighj'   if ighj_gene is not None else None, 
        'igh.nt' if igh_nt is not None else None, 
        'igh.aa' if igh_aa is not None else None
    )
        
    if present_k: tidy['igk'] = stringify_repertoire(
        tidy, 'igk', 
        'igkv'   if igkv_gene is not None else None, 
        None,
        'igkj'   if igkj_gene is not None else None, 
        'igk.nt' if igk_nt is not None else None, 
        'igk.aa' if igk_aa is not None else None
    )

    if present_l: tidy['igl'] = stringify_repertoire(
        tidy, 'igl', 
        'iglv'   if iglv_gene is not None else None, 
        None,
        'iglj'   if iglj_gene is not None else None, 
        'igl.nt' if igl_nt is not None else None, 
        'igl.aa' if igl_aa is not None else None
    )
    
    if present_k or present_l:
        tidy['iglt'] = 'lt(' + tidy['igk'] + ', ' + tidy['igl'] + ')'
    else: tidy['iglt'] = '.'

    tidy['clone'] = 'bcr(' + tidy['igh'] + ', ' + tidy['iglt'] + ')'

    # assign a clone id for each.
    indices = []
    existing = {}
    next_id = 1
    clones = tidy['clone'].tolist()
    for c in clones:
        if c not in existing.keys():
            indices.append('b:' + str(next_id))
            existing[c] = 'b:' + str(next_id)
            next_id += 1
        else: indices.append(existing[c])
    
    tidy['clone.id'] = indices
    return tidy


def parse_tcr_10x(
    fpath, sep = ',', barcode_translation = None, sample = '.',
    filter_non_productive = True,
    filter_non_full_length = True,
):

    if isinstance(fpath, str):
        raw_table = pd.read_table(fpath, index_col = None, sep = sep)
    else: raw_table = fpath

    # filter out illegal detections
    raw_table = raw_table.loc[raw_table['is_cell'] == True, :]
    raw_table = raw_table.loc[raw_table['high_confidence'] == True, :]
    if filter_non_full_length: 
        raw_table = raw_table.loc[raw_table['full_length'] == True, :]
    if filter_non_productive:
        raw_table = raw_table.loc[raw_table['productive'] == True, :]

    tra_contigs = raw_table.loc[
        raw_table['chain'] == 'TRA', [
            'barcode', 'v_gene', 'j_gene', 'full_length', 'productive', 
            'reads', 'umis', 'cdr3_nt', 'cdr3'
        ]
    ].copy()

    trb_contigs = raw_table.loc[
        raw_table['chain'] == 'TRB', [
            'barcode', 'v_gene', 'd_gene', 'j_gene', 'full_length', 'productive', 
            'reads', 'umis', 'cdr3_nt', 'cdr3'
        ]
    ].copy()

    tra_contigs = tra_contigs.rename(columns = {
        'v_gene'      : 'trav',
        'j_gene'      : 'traj', 
        'full_length' : 'tra.full', 
        'productive'  : 'tra.productive', 
        'reads'       : 'tra.reads',
        'umis'        : 'tra.umi',
        'cdr3_nt'     : 'tra.nt', 
        'cdr3'        : 'tra.aa'
    })

    trb_contigs = trb_contigs.rename(columns = {
        'v_gene'      : 'trbv', 
        'd_gene'      : 'trbd', 
        'j_gene'      : 'trbj', 
        'full_length' : 'trb.full', 
        'productive'  : 'trb.productive', 
        'reads'       : 'trb.reads',
        'umis'        : 'trb.umi',
        'cdr3_nt'     : 'trb.nt', 
        'cdr3'        : 'trb.aa'
    })

    tra_contigs.index = tra_contigs['barcode'].tolist()
    del tra_contigs['barcode']
    trb_contigs.index = trb_contigs['barcode'].tolist()
    del trb_contigs['barcode']

    # set to inner, should detect both alpha and beta chains
    tidy = tra_contigs.join(trb_contigs, how = 'inner')
    tidy['tra'] = stringify_repertoire(tidy, 'tra', 'trav', None, 'traj', 'tra.nt', 'tra.aa')
    tidy['trb'] = stringify_repertoire(tidy, 'trb', 'trbv', 'trbd', 'trbj', 'trb.nt', 'trb.aa')
    tidy['clone'] = 'tcr(' + tidy['tra'] + ', ' + tidy['trb'] + ')'

    # assign a clone id for each.
    indices = []
    existing = {}
    next_id = 1
    clones = tidy['clone'].tolist()
    for c in clones:
        if c not in existing.keys():
            indices.append('c:' + str(next_id))
            existing[c] = 'c:' + str(next_id)
            next_id += 1
        else: indices.append(existing[c])
    
    tidy['clone.id'] = indices

    barcodes = tidy.index.tolist()
    if barcode_translation is not None:
        barcodes = [barcode_translation(x) for x in barcodes]
    tidy['barcode'] = barcodes
    tidy['sample'] = sample
    
    return tidy


def parse_bcr_10x(
    fpath, sep = ',', barcode_translation = None, sample = '.',
    filter_non_productive = True,
    filter_non_full_length = True,
):

    if isinstance(fpath, str):
        raw_table = pd.read_table(fpath, index_col = None, sep = sep)
    else: raw_table = fpath

    # filter out illegal detections
    raw_table = raw_table.loc[raw_table['is_cell'] == True, :]
    raw_table = raw_table.loc[raw_table['high_confidence'] == True, :]
    if filter_non_full_length: 
        raw_table = raw_table.loc[raw_table['full_length'] == True, :]
    if filter_non_productive:
        raw_table = raw_table.loc[raw_table['productive'] == True, :]

    igh_contigs = raw_table.loc[
        raw_table['chain'] == 'IGH', [
            'barcode', 'v_gene', 'd_gene', 'j_gene', 'full_length', 'productive', 
            'reads', 'umis', 'cdr3_nt', 'cdr3'
        ]
    ].copy()

    igk_contigs = raw_table.loc[
        raw_table['chain'] == 'IGK', [
            'barcode', 'v_gene', 'j_gene', 'full_length', 'productive', 
            'reads', 'umis', 'cdr3_nt', 'cdr3'
        ]
    ].copy()

    igl_contigs = raw_table.loc[
        raw_table['chain'] == 'IGL', [
            'barcode', 'v_gene', 'j_gene', 'full_length', 'productive', 
            'reads', 'umis', 'cdr3_nt', 'cdr3'
        ]
    ].copy()

    igh_contigs = igh_contigs.rename(columns = {
        'v_gene'      : 'ighv', 
        'd_gene'      : 'ighd', 
        'j_gene'      : 'ighj', 
        'full_length' : 'igh.full', 
        'productive'  : 'igh.productive', 
        'reads'       : 'igh.reads',
        'umis'        : 'igh.umi',
        'cdr3_nt'     : 'igh.nt', 
        'cdr3'        : 'igh.aa'
    })

    igk_contigs = igk_contigs.rename(columns = {
        'v_gene'      : 'igltv',
        'j_gene'      : 'igltj', 
        'full_length' : 'iglt.full', 
        'productive'  : 'iglt.productive', 
        'reads'       : 'iglt.reads',
        'umis'        : 'iglt.umi',
        'cdr3_nt'     : 'iglt.nt', 
        'cdr3'        : 'iglt.aa'
    })

    igl_contigs = igl_contigs.rename(columns = {
        'v_gene'      : 'igltv',
        'j_gene'      : 'igltj', 
        'full_length' : 'iglt.full', 
        'productive'  : 'iglt.productive', 
        'reads'       : 'iglt.reads',
        'umis'        : 'iglt.umi',
        'cdr3_nt'     : 'iglt.nt', 
        'cdr3'        : 'iglt.aa'
    })

    igh_contigs.index = igh_contigs['barcode'].tolist()
    del igh_contigs['barcode']
    iglt_contigs = pd.concat([igk_contigs, igl_contigs])
    iglt_contigs.index = iglt_contigs['barcode'].tolist()
    del iglt_contigs['barcode']

    # set to inner, should detect both alpha and beta chains
    tidy = igh_contigs.join(iglt_contigs, how = 'inner')
    tidy['igh'] = stringify_repertoire(tidy, 'igh', 'ighv', 'ighd', 'ighj', 'igh.nt', 'igh.aa')
    tidy['iglt'] = stringify_repertoire(tidy, 'iglt', 'igltv', None, 'igltj', 'iglt.nt', 'iglt.aa')
    tidy['clone'] = 'bcr(' + tidy['igh'] + ', ' + tidy['iglt'] + ')'

    # assign a clone id for each.
    indices = []
    existing = {}
    next_id = 1
    clones = tidy['clone'].tolist()
    for c in clones:
        if c not in existing.keys():
            indices.append('b:' + str(next_id))
            existing[c] = 'b:' + str(next_id)
            next_id += 1
        else: indices.append(existing[c])
    
    tidy['clone.id'] = indices

    barcodes = tidy.index.tolist()
    if barcode_translation is not None:
        barcodes = [barcode_translation(x) for x in barcodes]
    tidy['barcode'] = barcodes
    tidy['sample'] = sample
    
    return tidy


def attach_tcr(adata, fpath):

    info(f'reading tcr table from {fpath} ...')
    tcr = pd.read_table(fpath, index_col = None, sep = '\t')
    assert 'barcode' in tcr.columns
    assert 'sample' in tcr.columns
    assert 'tra' in tcr.columns
    assert 'trb' in tcr.columns
    origin_name = adata.obs_names.tolist()

    obs_df = adata.obs.copy()
    # obs_df.index = (adata.obs['sample'].astype('str') + ':' + adata.obs['barcode'].astype('str')).tolist()
    obs_df.index = adata.obs['barcode'].astype('str').tolist()

    tra = adata.obs['tra'].tolist() if 'tra' in adata.obs.keys() else ['na'] * adata.n_obs
    trb = adata.obs['trb'].tolist() if 'trb' in adata.obs.keys() else ['na'] * adata.n_obs
    clone = adata.obs['clone'].tolist() if 'clone' in adata.obs.keys() else ['na'] * adata.n_obs
    cloneid = adata.obs['clone.id'].tolist() if 'clone.id' in adata.obs.keys() else ['na'] * adata.n_obs
    trav = adata.obs['trav'].tolist() if 'trav' in adata.obs.keys() else ['na'] * adata.n_obs
    traj = adata.obs['traj'].tolist() if 'traj' in adata.obs.keys() else ['na'] * adata.n_obs
    trbv = adata.obs['trbv'].tolist() if 'trbv' in adata.obs.keys() else ['na'] * adata.n_obs
    trbj = adata.obs['trbj'].tolist() if 'trbj' in adata.obs.keys() else ['na'] * adata.n_obs
    
    # clean the rows out
    if 'tra' in obs_df.keys(): del obs_df['tra']
    if 'trb' in obs_df.keys(): del obs_df['trb']
    if 'trav' in obs_df.keys(): del obs_df['trav']
    if 'traj' in obs_df.keys(): del obs_df['traj']
    if 'trbv' in obs_df.keys(): del obs_df['trbv']
    if 'trbj' in obs_df.keys(): del obs_df['trbj']
    if 'clone' in obs_df.keys(): del obs_df['clone']
    if 'clone.id' in obs_df.keys(): del obs_df['clone.id']
    
    tcr.index = tcr['sample'].astype('str') + ':' + tcr['barcode'].astype('str')
    # test if tcr contains duplicated chains:
    dup_count = tcr.index.duplicated().sum()
    if dup_count > 0: 
        warning(f'tcr table contains {dup_count} duplicated contigs for one cell.')
        sort_tcr = tcr.sort_values(by = ['tra.umi', 'trb.umi'], ascending = False)
        tcr = sort_tcr.loc[~ sort_tcr.index.duplicated(), :]

    selected_cols = ['tra', 'trb', 'clone', 'clone.id']
    if 'trav' in tcr.columns: selected_cols += ['trav']
    if 'traj' in tcr.columns: selected_cols += ['traj']
    if 'trbv' in tcr.columns: selected_cols += ['trbv']
    if 'trbj' in tcr.columns: selected_cols += ['trbj']

    new_df = obs_df.join(tcr.loc[:, selected_cols], how = 'left')
    n_match = len(new_df) - new_df['clone'].isna().sum()
    new_df.index = origin_name

    # make sure the join operation do not introduce duplicates.
    assert len(new_df) == len(origin_name)

    n_tra = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['tra'].tolist(), tra)] 
    n_trb = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['trb'].tolist(), trb)] 
    n_clone = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['clone'].tolist(), clone)] 
    n_cloneid = [y if str(x) == 'nan' else (s + ':' + str(x)) for x, s, y in zip(new_df['clone.id'].tolist(), new_df['sample'].tolist(), cloneid)] 
    n_trav = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['trav'].tolist(), trav)] 
    n_traj = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['traj'].tolist(), traj)] 
    n_trbv = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['trbv'].tolist(), trbv)] 
    n_trbj = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['trbj'].tolist(), trbj)] 

    new_df['tra'] = n_tra
    new_df['trb'] = n_trb
    new_df['clone'] = n_clone
    new_df['clone.id'] = n_cloneid
    new_df['trav'] = n_trav
    new_df['traj'] = n_traj
    new_df['trbv'] = n_trbv
    new_df['trbj'] = n_trbj

    adata.obs = new_df

    warning(f'{n_match} out of {len(tcr)} ({(100 * n_match / len(tcr)):.1f}%) tcr detections mapped.')
    return


def attach_bcr(adata, fpath):

    info(f'reading bcr table from {fpath} ...')
    bcr = pd.read_table(fpath, index_col = None, sep = '\t')
    assert 'barcode' in bcr.columns
    assert 'sample' in bcr.columns
    assert 'igh' in bcr.columns
    assert 'iglt' in bcr.columns
    origin_name = adata.obs_names.tolist()

    obs_df = adata.obs.copy()
    # obs_df.index = (adata.obs['sample'].astype('str') + ':' + adata.obs['barcode'].astype('str')).tolist()
    obs_df.index = adata.obs['barcode'].astype('str').tolist()

    igh = adata.obs['igh'].tolist() if 'igh' in adata.obs.keys() else ['na'] * adata.n_obs
    iglt = adata.obs['iglt'].tolist() if 'iglt' in adata.obs.keys() else ['na'] * adata.n_obs
    clone = adata.obs['clone'].tolist() if 'clone' in adata.obs.keys() else ['na'] * adata.n_obs
    cloneid = adata.obs['clone.id'].tolist() if 'clone.id' in adata.obs.keys() else ['na'] * adata.n_obs
    ighv = adata.obs['ighv'].tolist() if 'ighv' in adata.obs.keys() else ['na'] * adata.n_obs
    ighj = adata.obs['ighj'].tolist() if 'ighj' in adata.obs.keys() else ['na'] * adata.n_obs
    igltv = adata.obs['igltv'].tolist() if 'igltv' in adata.obs.keys() else ['na'] * adata.n_obs
    igltj = adata.obs['igltj'].tolist() if 'igltj' in adata.obs.keys() else ['na'] * adata.n_obs
    
    # clean the rows out
    if 'igh' in obs_df.keys(): del obs_df['igh']
    if 'iglt' in obs_df.keys(): del obs_df['iglt']
    if 'ighv' in obs_df.keys(): del obs_df['ighv']
    if 'ighj' in obs_df.keys(): del obs_df['ighj']
    if 'igltv' in obs_df.keys(): del obs_df['igltv']
    if 'igltj' in obs_df.keys(): del obs_df['igltj']
    if 'clone' in obs_df.keys(): del obs_df['clone']
    if 'clone.id' in obs_df.keys(): del obs_df['clone.id']
    
    bcr.index = bcr['sample'].astype('str') + ':' + bcr['barcode'].astype('str')
    # test if bcr contains duplicated chains:
    dup_count = bcr.index.duplicated().sum()
    if dup_count > 0: 
        warning(f'bcr table contains {dup_count} duplicated contigs for one cell.')
        sort_tcr = bcr.sort_values(by = ['igh.umi', 'iglt.umi'], ascending = False)
        bcr = sort_tcr.loc[~ sort_tcr.index.duplicated(), :]

    selected_cols = ['igh', 'iglt', 'clone', 'clone.id']
    if 'ighv' in bcr.columns: selected_cols += ['ighv']
    if 'ighj' in bcr.columns: selected_cols += ['ighj']
    if 'igltv' in bcr.columns: selected_cols += ['igltv']
    if 'igltj' in bcr.columns: selected_cols += ['igltj']

    new_df = obs_df.join(bcr.loc[:, selected_cols], how = 'left')
    n_match = len(new_df) - new_df['clone'].isna().sum()
    new_df.index = origin_name

    # make sure the join operation do not introduce duplicates.
    assert len(new_df) == len(origin_name)

    n_igh = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['igh'].tolist(), igh)] 
    n_iglt = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['iglt'].tolist(), iglt)] 
    n_clone = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['clone'].tolist(), clone)] 
    n_cloneid = [y if str(x) == 'nan' else (s + ':' + str(x)) for x, s, y in zip(new_df['clone.id'].tolist(), new_df['sample'].tolist(), cloneid)] 
    n_ighv = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['ighv'].tolist(), ighv)] 
    n_ighj = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['ighj'].tolist(), ighj)] 
    n_igltv = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['igltv'].tolist(), igltv)] 
    n_igltj = [y if str(x) == 'nan' else str(x) for x, y in zip(new_df['igltj'].tolist(), igltj)] 

    new_df['igh'] = n_igh
    new_df['iglt'] = n_iglt
    new_df['clone'] = n_clone
    new_df['clone.id'] = n_cloneid
    new_df['ighv'] = n_ighv
    new_df['ighj'] = n_ighj
    new_df['igltv'] = n_igltv
    new_df['igltj'] = n_igltj

    adata.obs = new_df

    warning(f'{n_match} out of {len(bcr)} ({(100 * n_match / len(bcr)):.1f}%) bcr detections mapped.')
    return


def attach_splice_reads_mtx(adata, folder, default_taxa, sample):
    '''
    Attach MGI DNBC4 flavor output spliced/unspliced matrices. The folder of spliced reads contains
    barcodes.tsv.gz, features.tsv.gz, spanning, spliced and unspliced matrix files. Note that the
    order and content of the features may not match the given adata.
    '''

    features = pd.read_table(os.path.join(folder, 'features.tsv.gz'), sep = '\t', header = None)
    features = features.iloc[:, 0].tolist()

    from scipy.io import mmread
    from scipy.sparse import csr_matrix
    import gzip
    import io

    with gzip.open(os.path.join(folder, 'spliced.mtx.gz'), 'rb') as f:
        with io.TextIOWrapper(f, encoding = 'utf-8') as enc:
            spliced = mmread(enc)
        
    with gzip.open(os.path.join(folder, 'unspliced.mtx.gz'), 'rb') as f:
        with io.TextIOWrapper(f, encoding = 'utf-8') as enc:
            unspliced = mmread(enc)
    
    with gzip.open(os.path.join(folder, 'spanning.mtx.gz'), 'rb') as f:
        with io.TextIOWrapper(f, encoding = 'utf-8') as enc:
            ambiguous = mmread(enc)
    
    barcodes = pd.read_table(os.path.join(folder, 'barcodes.tsv.gz'), sep = '\t', header = None)
    barcodes = barcodes.iloc[:, 0].tolist()

    # make annotated data
    adata_f = ad.AnnData(
        X = csr_matrix((len(barcodes), len(features)), dtype = np.float32)
    )
    
    adata_f.obs_names = barcodes
    adata_f.var_names = features
    adata_f.layers['spliced'] = spliced.T.tocsr()
    adata_f.layers['unspliced'] = unspliced.T.tocsr()
    adata_f.layers['ambiguous'] = ambiguous.T.tocsr()

    # map gene naming
    gname = features
    names = []
    gmask = []

    # here, we just add another condition to test whether the gname list is appropriate
    # ensembl format. if it is not, we try to map genes directly onto the names.
    # though i specify the var_names should be 'gene_ids', it may occur exceptions
    # where there are man-made references containing two or more species. by convention
    # in these double species reference, the 'gene_ids' should be 'mm10_ENSMUSG...'
    # or just name of the genes.

    default_finder_ens = get_mapper_ensembl(default_taxa)
    default_finder_name = get_mapper_name(default_taxa)
    not_in_list = []

    for x in gname:

        if '_' in x:

            reference_name = x.split('_')[0]
            pure_nm = x.replace(reference_name + '_', '')

            if not reference_name.lower() in cfg['taxa.reference'].keys():
                warning(f'gene {x} seems to have a reference prefix, but not registered to taxa.')
                gmask.append(False)
                not_in_list.append(x)
                continue

            reference_taxa = cfg['taxa.reference'][reference_name.lower()]
            alt_finder_name = get_mapper_name(reference_taxa)
            alt_finder_ens = get_mapper_ensembl(reference_taxa)

            if pure_nm in alt_finder_ens.keys():
                gmask.append(True)
                names.append(alt_finder_ens[pure_nm])
                continue
            
            if pure_nm in alt_finder_name.keys():
                gmask.append(True)
                names.append(alt_finder_name[pure_nm])
                continue
        
        if x in default_finder_ens.keys():
            gmask.append(True)
            names.append(default_finder_ens[x])
            continue
        
        if x in default_finder_name.keys():
            gmask.append(True)
            names.append(default_finder_name[x])
            continue
            
        gmask.append(False)
        not_in_list.append(x)

    final = adata_f[:, gmask].copy()
    del adata_f
    final.var_names = ['rna:' + x for x in names]
    # remove duplicated genes
    duplicated = set(final.var_names[final.var_names.duplicated()].tolist())
    final = final[:, final.var_names.duplicated() == False].copy()
    final.obs_names = sample + ':' + final.obs_names

    # by now the variable names are identical, while the obs names should match
    # those in the obs['barcode']

    adata = adata[
        [x in final.obs_names for x in adata.obs['barcode'].tolist()],
        [x in final.var_names for x in adata.var_names.tolist()]
    ].copy()

    final = final[adata.obs['barcode'], adata.var_names].copy()
    adata.layers['spliced'] = final.layers['spliced']
    adata.layers['unspliced'] = final.layers['unspliced']
    adata.layers['ambiguous'] = final.layers['ambiguous']

    return adata


def attach_splice_reads_loom(adata, loom_file, default_taxa, sample):
    '''
    Attach Loom format of spliced/unspliced matrices.
    Typically from outputs of velocyto.
    '''

    # this typically gives a following result:
    # AnnData object with n_obs × n_vars = 55321 × 33696
    #   var: 'Accession', 'Chromosome', 'End', 'Start', 'Strand'
    #   layers: 'ambiguous', 'matrix', 'spliced', 'unspliced'

    adata_f = sc.read_loom(
        loom_file, sparse = True, cleanup = False, 
        X_name = 'matrix', obs_names = 'CellID', obsm_names = None, 
        var_names = 'Gene', varm_names = None, dtype = 'float32'
    )

    features = adata_f.var_names.tolist()
    # rename observations
    observs = [x[x.index(':') + 1:-1] for x in adata_f.obs_names]
    adata_f.obs_names = observs

    # map gene naming
    gname = features
    names = []
    gmask = []

    # here, we just add another condition to test whether the gname list is appropriate
    # ensembl format. if it is not, we try to map genes directly onto the names.
    # though i specify the var_names should be 'gene_ids', it may occur exceptions
    # where there are man-made references containing two or more species. by convention
    # in these double species reference, the 'gene_ids' should be 'mm10_ENSMUSG...'
    # or just name of the genes.

    default_finder_ens = get_mapper_ensembl(default_taxa)
    default_finder_name = get_mapper_name(default_taxa)
    not_in_list = []

    for x in gname:

        if '_' in x:

            reference_name = x.split('_')[0]
            pure_nm = x.replace(reference_name + '_', '')

            if not reference_name.lower() in cfg['taxa.reference'].keys():
                warning(f'gene {x} seems to have a reference prefix, but not registered to taxa.')
                gmask.append(False)
                not_in_list.append(x)
                continue

            reference_taxa = cfg['taxa.reference'][reference_name.lower()]
            alt_finder_name = get_mapper_name(reference_taxa)
            alt_finder_ens = get_mapper_ensembl(reference_taxa)

            if pure_nm in alt_finder_ens.keys():
                gmask.append(True)
                names.append(alt_finder_ens[pure_nm])
                continue
            
            if pure_nm in alt_finder_name.keys():
                gmask.append(True)
                names.append(alt_finder_name[pure_nm])
                continue
        
        if x in default_finder_ens.keys():
            gmask.append(True)
            names.append(default_finder_ens[x])
            continue
        
        if x in default_finder_name.keys():
            gmask.append(True)
            names.append(default_finder_name[x])
            continue
            
        gmask.append(False)
        not_in_list.append(x)

    final = adata_f[:, gmask].copy()
    del adata_f
    final.var_names = ['rna:' + x for x in names]
    # remove duplicated genes
    duplicated = set(final.var_names[final.var_names.duplicated()].tolist())
    final = final[:, final.var_names.duplicated() == False].copy()
    final.obs_names = sample + ':' + final.obs_names

    # by now the variable names are identical, while the obs names should match
    # those in the obs['barcode']

    # remove 10x lane no.
    adata.obs['barcode.pure'] = [
        x[:-2] if x[-2] == '-' else x for x in adata.obs['barcode'].tolist()
    ]

    adata = adata[
        [x in final.obs_names for x in adata.obs['barcode.pure'].tolist()],
        [x in final.var_names for x in adata.var_names.tolist()]
    ].copy()

    final = final[adata.obs['barcode.pure'], adata.var_names].copy()
    adata.layers['spliced'] = final.layers['spliced']
    adata.layers['unspliced'] = final.layers['unspliced']
    adata.layers['ambiguous'] = final.layers['ambiguous']
    del adata.obs['barcode.pure']
    return adata