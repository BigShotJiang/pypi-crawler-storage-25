
import scanpy as sc
import anndata as ad
import mudata as mu
import pandas as pd
import numpy as np
import zarr
import zarr.storage
import os

import exprmat.reader.metadata as mt
from exprmat.reader.metadata import load_metadata
from exprmat.data.finders import get_genome
from exprmat.reader.matcher import (
    read_mtx_rna, read_h5ad_rna, read_table_rna, read_h5_rna, read_rds_rna,
    read_h5_cite, read_mtx_cite,
    parse_tcr_10x, parse_bcr_10x,
    attach_splice_reads_mtx, attach_splice_reads_loom,
)
from exprmat.reader.matcher import attach_tcr
from exprmat.ansi import warning, info, error, red, green, pprog, wrap, dtypestr, dtypemat
from exprmat import config as cfg
from exprmat import default_logger
import exprmat.reader.static as st
import exprmat as em


def load_data(row, meta, eccentric = None, dump = '.', save_simultaneously = False) -> tuple[dict, list]:
    
    i_loc, i_sample, i_batch, i_grp, i_mod, i_taxa = (
        row['location'],
        row['sample'],
        row['batch'],
        row['group'],
        row['modality'],
        row['taxa']
    )

    res = { }
    appending_meta = []

    # extension of taxa: you can specify a specific version of the genome
    # assembly when specifying taxa. leaving it out allows exprmat to choose
    # the assembly (the latest version) automatically.

    # e.g.
    #    mmu            = 'grcm39'
    #    mmu/grcm38     = 'grcm38'

    if '/' in i_taxa: i_taxa, i_assembly = i_taxa.split('/')
    else: i_assembly = cfg['default.assembly'][i_taxa]
    
    info(f'reading sample {i_sample} [{i_mod}] ...')

    query_mod = i_mod
    if i_mod == 'rna.raw': 
        query_mod = 'rna'
        rna_auto = row.copy()
        rna_auto['modality'] = 'rna'
        appending_meta += [rna_auto]

    attempt_path = os.path.join(dump, query_mod, i_sample + '.h5ad')
    if os.path.exists(attempt_path):
        if not query_mod in res.keys(): res[query_mod] = {}
        res[query_mod][i_sample] = sc.read_h5ad(attempt_path)
        warning(f'load pre-exisiting file `{query_mod}/{i_sample}.h5ad`.')
        return res, appending_meta

    if i_mod in ['rna', 'rna.raw']:

        if not 'rna' in res.keys(): res['rna'] = {}
        is_raw = i_mod == 'rna.raw'

        # we automatically infer from the given location names to select
        # the correct way of loading samples:

        if i_loc.endswith('.tsv.gz') or i_loc.endswith('.tsv'):

            res['rna'][i_sample] = read_table_rna(
                src = i_loc, metadata = meta, sample = i_sample,
                raw = is_raw, default_taxa = i_taxa, eccentric = eccentric, sep = '\t'
            )

        elif i_loc.endswith('.csv.gz') or i_loc.endswith('.csv'):

            res['rna'][i_sample] = read_table_rna(
                src = i_loc, metadata = meta, sample = i_sample,
                raw = is_raw, default_taxa = i_taxa, eccentric = eccentric, sep = ','
            )
        
        elif i_loc.endswith('.ssv.gz') or i_loc.endswith('.ssv'):

            res['rna'][i_sample] = read_table_rna(
                src = i_loc, metadata = meta, sample = i_sample,
                raw = is_raw, default_taxa = i_taxa, eccentric = eccentric, sep = ' '
            )

        elif i_loc.endswith('.h5ad'):

            res['rna'][i_sample] = read_h5ad_rna(
                src = i_loc, metadata = meta, sample = i_sample,
                raw = is_raw, default_taxa = i_taxa, eccentric = eccentric
            )

        elif i_loc.endswith('.h5'):
            
            res['rna'][i_sample] = read_h5_rna(
                src = i_loc, metadata = meta, sample = i_sample,
                raw = is_raw, default_taxa = i_taxa, eccentric = eccentric
            )

        elif i_loc.endswith('.rds'):
            
            res['rna'][i_sample] = read_rds_rna(
                src = i_loc, metadata = meta, sample = i_sample,
                raw = is_raw, default_taxa = i_taxa, eccentric = eccentric
            )

        else:
            res['rna'][i_sample] = read_mtx_rna(
                src = i_loc, prefix = '', metadata = meta, sample = i_sample,
                raw = is_raw, default_taxa = i_taxa, eccentric = eccentric
            )
        
        res['rna'][i_sample].var = \
            st.search_genes(res['rna'][i_sample].var_names.tolist())
        
        # in search for spliced and unspliced reads

        splicing = (
            (meta.dataframe['sample'] == i_sample) & 
            (meta.dataframe['modality'] == 'rna.splicing')
        )

        if splicing.sum() > 1:
            warning(f'ignored spliced reads for sample [{i_sample}], since you specify more than one.')
        
        elif splicing.sum() == 1:
            
            import warnings
            warnings.filterwarnings('ignore')

            splice_loc = meta.dataframe.loc[splicing, :].iloc[0, 0]
            if os.path.isdir(splice_loc):
                res['rna'][i_sample] = attach_splice_reads_mtx(
                    res['rna'][i_sample], 
                    splice_loc, default_taxa = i_taxa,
                    sample = i_sample
                )

            elif splice_loc.endswith('.loom'):
                res['rna'][i_sample] = attach_splice_reads_loom(
                    res['rna'][i_sample], 
                    splice_loc, default_taxa = i_taxa,
                    sample = i_sample
                )
            
            else: error('skipped spliced matrix, not valid data format.')
            warnings.filterwarnings('default')
        
        else: pass

        if save_simultaneously:
            os.makedirs(os.path.join(dump, 'rna'), exist_ok = True)
            res['rna'][i_sample].write_h5ad(
                os.path.join(dump, 'rna', i_sample + '.h5ad')
            )


    elif i_mod == 'rna.splicing': pass
    elif i_mod == 'rna.tcr':

        # 10x tcr folder
        tcr = parse_tcr_10x(
            os.path.join(i_loc, 'filtered_contig_annotations.csv'),
            sample = i_sample,
            filter_non_productive = True,
            filter_non_full_length = True
        )

        if not os.path.exists(os.path.join(dump, 'tcr')):
            os.makedirs(os.path.join(dump, 'tcr'), exist_ok = True)

        tcr.to_csv(
            os.path.join(dump, 'tcr', i_sample + '.tsv.gz'), 
            sep = '\t', index = False
        )

    elif i_mod == 'rna.bcr':

        # 10x tcr folder
        tcr = parse_bcr_10x(
            os.path.join(i_loc, 'filtered_contig_annotations.csv'),
            sample = i_sample,
            filter_non_productive = True,
            filter_non_full_length = True
        )

        if not os.path.exists(os.path.join(dump, 'bcr')):
            os.makedirs(os.path.join(dump, 'bcr'), exist_ok = True)

        tcr.to_csv(
            os.path.join(dump, 'bcr', i_sample + '.tsv.gz'), 
            sep = '\t', index = False
        )

    elif i_mod == 'cite':

        if not 'rna' in res.keys(): res['rna'] = {}
        if not 'cite' in res.keys(): res['cite'] = {}

        # we automatically infer from the given location names to select
        # the correct way of loading samples:

        if i_loc.endswith('.h5'):
            
            a, b = read_h5_cite(
                src = i_loc, metadata = meta, sample = i_sample,
                raw = False, default_taxa = i_taxa, eccentric = eccentric
            )

            res['rna'][i_sample] = a
            res['cite'][i_sample] = b

        else:
            a, b = read_mtx_cite(
                src = i_loc, prefix = '', metadata = meta, sample = i_sample,
                raw = False, default_taxa = i_taxa, eccentric = eccentric
            )

            res['rna'][i_sample] = a
            res['cite'][i_sample] = b
        
        res['rna'][i_sample].var = \
            st.search_genes(res['rna'][i_sample].var_names.tolist())
        
        rna_auto = row.copy()
        rna_auto['modality'] = 'rna'
        appending_meta += [rna_auto]

        if save_simultaneously:
            os.makedirs(os.path.join(dump, 'rna'), exist_ok = True)
            os.makedirs(os.path.join(dump, 'cite'), exist_ok = True)
            res['rna'][i_sample].write_h5ad(
                os.path.join(dump, 'rna', i_sample + '.h5ad')
            )

            res['cite'][i_sample].write_h5ad(
                os.path.join(dump, 'cite', i_sample + '.h5ad')
            )
    
    elif i_mod == 'rnasp-c':
        
        if not 'rnasp-c' in res.keys(): res['rnasp-c'] = {}

        from exprmat.reader.spatial import read_seekspace, read_xenium_explorer, is_xenium_explorer
        
        if is_xenium_explorer(i_loc):
            res['rnasp-c'][i_sample] = read_xenium_explorer(
                src = i_loc, prefix = '', metadata = meta, sample = i_sample,
                raw = False, default_taxa = i_taxa, eccentric = eccentric
            )
        
        else:
            res['rnasp-c'][i_sample] = read_seekspace(
                src = i_loc, prefix = '', metadata = meta, sample = i_sample,
                raw = False, default_taxa = i_taxa, eccentric = eccentric
            )

        res['rnasp-c'][i_sample].var = \
            st.search_genes(res['rnasp-c'][i_sample].var_names.tolist())


    elif i_mod == 'rnasp-b':
        
        if not 'rnasp-b' in res.keys(): res['rnasp-b'] = {}

        from exprmat.reader.spatial import read_visium
        res['rnasp-b'][i_sample] = read_visium(
            src = i_loc, prefix = '', metadata = meta, sample = i_sample,
            raw = False, default_taxa = i_taxa, eccentric = eccentric
        )

        res['rnasp-b'][i_sample].var = \
            st.search_genes(res['rnasp-b'][i_sample].var_names.tolist())
        
        if save_simultaneously:
            os.makedirs(os.path.join(dump, 'rnasp-b'), exist_ok = True)
            res['rnasp-b'][i_sample].write_h5ad(
                os.path.join(dump, 'rnasp-b', i_sample + '.h5ad')
            )


    elif i_mod == 'rnasp-s':
        
        if not 'rnasp-s' in res.keys(): res['rnasp-s'] = {}

        from exprmat.reader.spatial import read_visium_hd
        res['rnasp-s'][i_sample], cellseg = read_visium_hd(
            src = i_loc, prefix = '', metadata = meta, sample = i_sample,
            raw = False, default_taxa = i_taxa, eccentric = eccentric
        )

        res['rnasp-s'][i_sample].var = \
            st.search_genes(res['rnasp-s'][i_sample].var_names.tolist())
        
        if cellseg is not None:
            if not 'rnasp-c' in res.keys(): res['rnasp-c'] = {}
            res['rnasp-c'][i_sample] = cellseg
            res['rnasp-c'][i_sample].var = \
                st.search_genes(res['rnasp-c'][i_sample].var_names.tolist())
        
        if save_simultaneously:
            os.makedirs(os.path.join(dump, 'rnasp-s'), exist_ok = True)
            res['rnasp-s'][i_sample].write_h5ad(
                os.path.join(dump, 'rnasp-s', i_sample + '.h5ad')
            )
    
    
    elif i_mod == 'atac':
        
        if not 'atac' in res.keys(): res['atac'] = {}
        default_assembly = i_assembly

        from exprmat.peaks.common import import_fragments
        frags = import_fragments(
            i_loc,
            assembly = default_assembly,
            sorted_by_barcode = False,
        )

        # rename the fragments:
        frags.obs['barcode'] = i_sample + ':' + frags.obs_names
        frags.obs_names = [i_sample + ':' + str(ix + 1) for ix in range(frags.n_obs)]
        frags.obs['ubc'] = frags.obs_names.copy()

        frags.uns['assembly'] = default_assembly
        # frags must not have the var table. otherwise error will occur when
        # assigning bins to the vars.
        res['atac'][i_sample] = frags

        if save_simultaneously:
            os.makedirs(os.path.join(dump, 'atac'), exist_ok = True)
            res['atac'][i_sample].write_h5ad(
                os.path.join(dump, 'atac', i_sample + '.h5ad')
            )

    elif i_mod in ['rna-bulk', 'atac-bulk']:
        
        # samples ended up with '-bulk' suffix will be processed into one
        # predefined anndata named 'bulk' in the corresoponding modality.
        # note that samples with different taxa property cannot be analysed together.
        
        pass

    else: warning(f'sample {i_sample} have no supported modalities')

    return res, appending_meta


class experiment:
    """
    Create the experiment class.

    Parameters that are not recorded below are left for internal use. 
    Do not set them when creating the experiment unless you know what you are doing.

    Typically, you should only initialize an experiment with a metadata table,
    and load on-disk dumps via :func:`load_experiment`

    >>> import exprmat as em
    >>> expm = em.experiment(meta, dump = 'dir', save_simultaneously = True)
    >>> expm.save()

    or load an existing experiment via

    >>> expm = em.load_experiment('dir')

    Parameters
    ----------

    meta: exprmat.metadata
        The metadata table to instruct the construction of experiment
    
    eccentric: None | Callable
        A short translator function if the gene names in the source matrix may not be one of
        (1) Unversioned ENSEMBL index, (2) Gene names, (3) Exprmat Unique Gene Index.
        For example, for raw data giving variable names as 'ENSMUSG000000001.23', this will not
        be recognized by the built-in reference database for M. Musculus, and you should pass
        
        >>> eccentric = lambda x: x.split('.')[0]
    
    dump: str = '.'
        Location to save the experiment when save() was called.
        You might change the save location explicitly in the save(fpath) method, but a default
        value is better given here. See save_simultaneously below.
    
    save_simultaneously: bool = True
        Write the sample to disk once it is transformed into exprmat-compatible version.
        When your experiment contains many samples, it is better to turn this to True, since
        it will skip the saved work when restarted from interruption.
    
    parallel: bool | int = False
        False turns off parallelization when loading samples, or use <int> workers to load
        data simultaneously. (Better turned off when sample < 6)
    
    """

    mudata: mu.MuData
    modalities: dict
    metadata: mt.metadata
    subset: str | None
    version: int
    directory: str
    spatial: zarr.storage.Store
    
    def __init__(
        self, meta : mt.metadata, 
        
        # user parameters
        eccentric = None, 
        save_simultaneously = True,
        dump = '.', 
        subset = None,
        version = em.SPECIFICATION,
        parallel = False,

        # internal parameters
        mudata = None, modalities = {}, attachments = {}
    ):
        
        table = meta.dataframe
        self.mudata = mudata
        self.modalities = modalities
        self.attachments = attachments
        self.metadata = meta
        self.subset = subset
        self.directory = dump
        self.version = version

        if os.path.exists(os.path.join(self.directory, 'spatial')):
            self.spatial = zarr.open(os.path.join(self.directory, 'spatial'), mode = 'r+')

        if self.mudata is not None:
            if len(self.modalities) == 0:
                warning('samples are not dumped in the experiment directory.')
            return
        
        if len(self.modalities) > 0:
            if self.mudata is None:
                warning('integrated mudata object is not generated.')
            return

        self.modalities = {}

        # use parallel to load single cell samples.
        if type(parallel) == int:
            
            # shut up the package.
            default_logger.silent = True

            from multiprocessing import Pool
            from functools import partial
            with Pool(parallel) as p:
                res = list(
                    pprog(
                        p.imap(
                            partial(
                                load_data,
                                meta = self.metadata,
                                eccentric = eccentric,
                                dump = self.directory,
                                save_simultaneously = save_simultaneously,
                            ),
                            iterable = [row for ind, row in table.iterrows()],
                            chunksize = 1,
                        ),
                        total = len(table),
                        desc = 'loading data'
                    )
                )
            
            default_logger.silent = False

            for mod_dict, app_meta in res:
                for i_mod in mod_dict.keys():
                    if not i_mod in self.modalities.keys():
                        self.modalities[i_mod] = {}
                    for i_sample in mod_dict[i_mod].keys():
                        self.modalities[i_mod][i_sample] = mod_dict[i_mod][i_sample]
                
                for am in app_meta:
                    self.metadata.insert_row(am)
        
        else:
            res = []
            for ind, row in table.iterrows():
                res += [load_data(row, self.metadata, eccentric, dump, save_simultaneously)]

            for mod_dict, app_meta in res:
                for i_mod in mod_dict.keys():
                    if not i_mod in self.modalities.keys():
                        self.modalities[i_mod] = {}
                    for i_sample in mod_dict[i_mod].keys():
                        self.modalities[i_mod][i_sample] = mod_dict[i_mod][i_sample]
                
                for am in app_meta:
                    self.metadata.insert_row(am)


        self.metadata.dataframe = self.metadata.dataframe.loc[
            self.metadata.dataframe['modality'] != 'rna.splicing', :
        ].copy()
        
        self.metadata.dataframe = self.metadata.dataframe.loc[
            self.metadata.dataframe['modality'] != 'rna.tcr', :
        ].copy()

        self.metadata.dataframe = self.metadata.dataframe.loc[
            self.metadata.dataframe['modality'] != 'rna.bcr', :
        ].copy()

        # attaching bulk datasets.

        for i_mod in ['rna-bulk', 'atac-bulk']:
            
            meta = self.metadata.dataframe.loc[
                self.metadata.dataframe['modality'] == i_mod, :
            ]

            if len(meta) == 0: continue

            if i_mod == 'rna-bulk':

                # bulk rna sequencing accepts expression matrices based on raw
                # counts (we recommend raw counts over any processed forms)
                # however, if normalized forms are only available, you may provide them.

                # it accepts generally any form of table, where the first row
                # contains gene names, and contains a row matched to sample name.

                datatable = []
                datarows = []
                example_row = None

                if len(meta['taxa'].unique()) != 1:
                    error('failed to merge rna experiments with different reference.')

                i_taxa = meta['taxa'].unique().tolist()[0]

                for sid in range(len(meta)):

                    prop = meta.iloc[sid]

                    if '/' in prop['taxa']: i_taxa, i_assembly = prop['taxa'].split('/')
                    else:
                        i_taxa = prop['taxa'] 
                        i_assembly = cfg['default.assembly'][i_taxa]

                    from exprmat.reader.matcher import convert_to_ugene
                    from exprmat.reader.spatial import read_table_from_extension

                    pdf = read_table_from_extension(prop['location'])
                    sampdf = pdf[[pdf.columns[0], prop['sample']]].set_index(pdf.columns[0])

                    names, gmask, notinlist = convert_to_ugene(sampdf.index.tolist(), i_taxa, eccentric = eccentric)
                    info(f'{len(notinlist)} unmatched genes from {len(sampdf)} rows.')
                    sampdf = sampdf.loc[gmask, :].copy()
                    sampdf.index = names
                    sampdf = sampdf.loc[~sampdf.index.duplicated(), :].copy()
                    datatable += [sampdf]
                    datarows += [pd.DataFrame(prop.copy()).T]
                    example_row = prop.copy()
                
                if len(datatable) == 1: datatable = datatable[0]
                elif len(datatable) == 2: datatable = datatable[0].join(datatable[1])
                else: datatable = datatable[0].join(datatable[1:])

                datarows = pd.concat(datarows)
                datarows.index = datatable.columns.tolist()

                # initialize anndata.
                adata = ad.AnnData(X = datatable.T, obs = datarows)
                adata.var = st.search_genes(adata.var_names.tolist())
                adata.obs_names = 'bulk-rna:' + adata.obs_names
                if not 'rna' in self.modalities.keys(): self.modalities['rna'] = {}
                self.modalities['rna']['bulk-rna'] = adata

                # replace metadata
                example_row['sample'] = 'bulk-rna'
                example_row['location'] = ':/rna/bulk-rna'
                example_row['group'] = '.'
                example_row['taxa'] = i_taxa
                example_row['modality'] = 'rna'
                example_row['batch'] = 'autogen'

                self.metadata.dataframe = self.metadata.dataframe.loc[
                    self.metadata.dataframe['modality'] != 'rna-bulk', :
                ].copy()
                self.metadata.insert_row(example_row)
            

            elif i_mod == 'atac-bulk':

                # bulk atac seq accepts bams as input.
                # if no bam files accessible, a bedgraph file can be supplied as an alternative
                # but several features (e.g. cut site identification) rely on raw fragments
                # and cannot be applied then.

                datarows = []
                if len(meta['taxa'].unique()) != 1:
                    error('failed to merge atac experiments with different reference.')
                
                given_format = []
                for sid in range(len(meta)):
                    prop = meta.iloc[sid].copy()
                    given_format.append(prop['location'].split('.')[-1])
                
                given_format = list(set(given_format))
                if len(given_format) > 1:
                    warning('you should always supply samples from bulk atacseq experiment with the same format.')
                    warning(f'here, you supplied [{", ".join(given_format)}].')
                    error(f'failed to harmonize atac-seq data with different format.')

                given_format = given_format[0]
                
                i_taxa = meta['taxa'].unique().tolist()[0]
                if '/' in i_taxa: i_taxa, i_assembly = i_taxa.split('/')
                else: i_assembly = cfg['default.assembly'][i_taxa]

                example_row = None
                fragments = []
                for sid in range(len(meta)):
                    prop = meta.iloc[sid].copy()

                    if given_format == 'bdg':
                        prop['bedgraph'] = prop['location']
                        # if there is bedgraph, test whether there is a bigwig file accompanying.
                        # for plotting we want bigwig files.
                        accbw = prop['location'].replace('.bdg', '.bigwig')
                        if not os.path.exists(accbw):
                            warning('do not find an accompanying bigwig files for visualization')
                            warning(f'generating bigwig file from bedgraph {prop["location"]} ...')
                            from exprmat.reader.conversions import bedgraph_to_bigwig
                            bedgraph_to_bigwig(prop['location'], i_assembly, accbw)

                    elif given_format == 'bigwig':
                        accbw = prop['location'].replace('.bigwig', '.bdg')
                        if not os.path.exists(accbw):
                            warning('do not find an accompanying bedgraph files for peak calling')
                            warning(f'generating bedgraph file from bigwig {prop["location"]} ...')
                            from exprmat.reader.conversions import bigwig_to_bedgraph
                            bigwig_to_bedgraph(prop['location'], accbw)
                        prop['bedgraph'] = accbw
                    
                    elif given_format == 'bam':
                        
                        # we expect the input bam are pair-end sequencing, sorted by coordinate
                        # now we will add sample tag to them, and generate fragments file for each.
                        from exprmat.reader.conversions import bam_to_fragments
                        frag = bam_to_fragments(prop['location'], prop['sample'])
                        fragments.append(frag)

                    datarows += [pd.DataFrame(prop).T]
                    example_row = prop.copy()
                
                if given_format != 'bam':
                    datarows = pd.concat(datarows)
                    datarows.index = 'bulk-atac:' + datarows['sample']
                    datarows.index.name = None
                    from scipy.sparse import csr_matrix
                    adata = ad.AnnData(
                        X = csr_matrix((len(datarows), 0), dtype = np.float32), 
                        obs = datarows
                    )

                    from exprmat.data.finders import get_genome_size
                    adata.uns['assembly.size'] = get_genome_size(i_assembly, as_dataframe = True)
                
                else:

                    # concat gzipped fragments
                    import tempfile
                    fd, temp_name = tempfile.mkstemp()
                    os.close(fd)
                    os.unlink(temp_name)
                    os.system('cat ' + ' '.join([f'"{x}"' for x in fragments]) + ' > ' + temp_name + '.tsv.gz')
                    
                    from exprmat.peaks.common import import_fragments
                    adata = import_fragments(
                        temp_name + '.tsv.gz',
                        assembly = i_assembly,
                        sorted_by_barcode = True,
                    )
                    
                    datarows = pd.concat(datarows)
                    datarows.index = datarows['sample']
                    datarows.index.name = None
                    adata.obs = adata.obs.join(datarows)
                    adata.obs_names = 'bulk-atac:' + datarows['sample']
                    adata.obs_names.name = None

                    os.unlink(temp_name + '.tsv.gz')

                adata.uns['assembly'] = i_assembly

                if not 'atac' in self.modalities.keys(): self.modalities['atac'] = {}
                self.modalities['atac']['bulk-atac'] = adata

                # replace metadata
                example_row['sample'] = 'bulk-atac'
                example_row['location'] = ':/atac/bulk-atac'
                example_row['group'] = '.'
                example_row['taxa'] = i_taxa
                example_row['modality'] = 'atac'
                example_row['batch'] = 'autogen'

                self.metadata.dataframe = self.metadata.dataframe.loc[
                    self.metadata.dataframe['modality'] != 'atac-bulk', :
                ].copy()
                self.metadata.insert_row(example_row)

        pass


    @property
    def obs(self):
        self.check_merged()
        return self.mudata.obs
    

    @property
    def var(self):
        self.check_merged()
        return self.mudata.var
    

    @property
    def shape(self):
        self.check_merged()
        return (self.mudata.n_obs, self.mudata.n_vars)
    
    
    def merge(
        self, join = 'outer', obsms = [], variable_columns = [],
        bool_merge_behavior = 'or',
        numeric_merge_behavior = 'mean',
        string_merge_behavior = 'unique_concat', string_merge_sep = ';',
        subset_dict = None, subset_key = 'leiden'
    ):
        '''
        Merge the separate modalities, and generate the integrated dataset.
        Note that this integration is merely concatenating the raw matrices without
        any batch correction. You should run batch correction if needed using the
        routines elsewhere. (or the general interface ``integrate(...)``).

        Using ``subset_key`` and ``subset_dict``, you may only pick a subset of the source
        data to merge. As commonly required to merge only the certain cell type for integration.

        Parameter ``variable_columns`` is designed for merging variable columns in the var table,
        which will otherwise (by default) completely disgarded. However, since some of the 
        variable columns are important (typically highly variable gene masks), you should
        set this variable and determine the merge behavior.
        '''

        # the var names are self-interpretable, and we will merge the samples
        # and throw away original column metadata. for atac-seq experiments, however,
        # the original var metadata is useful, we should store them and append
        # to the merged dataset later.

        merged = {}

        if 'rna' in self.modalities.keys():

            filtered = {}
            for rnak in self.modalities['rna'].keys():

                # if following the recommended routine, by the time one will need
                # to merge the datasets, the X slot should contain log normalized values.

                filtered[rnak] = ad.AnnData(
                    X = self.modalities['rna'][rnak].X,
                    obs = self.modalities['rna'][rnak].obs,
                    var = self.modalities['rna'][rnak].var
                )

                if 'counts' in self.modalities['rna'][rnak].layers.keys():
                    filtered[rnak].layers['counts'] = self.modalities['rna'][rnak].layers['counts']

                if 'spliced' in self.modalities['rna'][rnak].layers.keys():
                    filtered[rnak].layers['spliced'] = self.modalities['rna'][rnak].layers['spliced']

                if 'unspliced' in self.modalities['rna'][rnak].layers.keys():
                    filtered[rnak].layers['unspliced'] = self.modalities['rna'][rnak].layers['unspliced']

                if 'ambiguous' in self.modalities['rna'][rnak].layers.keys():
                    filtered[rnak].layers['ambiguous'] = self.modalities['rna'][rnak].layers['ambiguous']
                
                for obsm in obsms:
                    filtered[rnak].obsm[obsm] = self.modalities['rna'][rnak].obsm[obsm]

                if subset_dict is not None:
                    if rnak not in subset_dict.keys():
                        del filtered[rnak]
                    
                    else:
                        cell_mask = [
                            x in subset_dict[rnak] 
                            for x in filtered[rnak].obs[subset_key].tolist()
                        ]

                        if not all(cell_mask):
                            filtered[rnak] = filtered[rnak][cell_mask, :]


            # merge rna st.
            merged['rna'] = ad.concat(
                filtered, axis = 'obs', 
                join = join, label = 'sample'
            )

            # retrieve the corresponding gene info according to the universal 
            # nomenclature rna:[tax]:[ugene] format

            gene_names = merged['rna'].var_names.tolist()
            merged['rna'].var = st.search_genes(gene_names)

            # we will next merge variable columns. this is typically designed for
            # merging bool vector masks for hvgs.
            
            for varc in variable_columns:
                
                values = {}

                for rnak in self.modalities['rna'].keys():

                    # just skip samples with explicitly ignored subset.
                    if subset_dict is not None:
                        if rnak not in subset_dict.keys():
                            continue

                    key = self.modalities['rna'][rnak].var.index.tolist()
                    if not varc in self.modalities['rna'][rnak].var.columns.tolist():
                        warning(f'sample `{rnak}` does not contain variable column `{key}`. skipped.')
                        continue

                    value = self.modalities['rna'][rnak].var[varc].tolist()
                    for idk in range(len(key)):
                        if key[idk] not in values.keys(): values[key[idk]] = []
                        values[key[idk]] += [value[idk]]
                
                labels = values[list(values.keys())[0]]
                if type(labels[0]) is str:

                    if string_merge_behavior == 'unique_concat':
                        f = lambda l: string_merge_sep.join(list(set(l)))
                    elif string_merge_behavior == 'concat':
                        f = lambda l: string_merge_sep.join(l)
                    else: f = lambda l: 'NA'

                    merged_var = [f(values[g]) if g in values.keys() else 'NA' for g in gene_names]
                    merged['rna'].var[varc] = merged_var

                elif (type(labels[0]) is int) or \
                     (type(labels[0]) is float) or \
                     (type(labels[0]) is np.float32) or \
                     (type(labels[0]) is np.float64) or \
                     (type(labels[0]) is np.int32):

                    if numeric_merge_behavior == 'mean':
                        f = lambda l: np.mean(l)
                    elif string_merge_behavior == 'var':
                        f = lambda l: np.var(l)
                    elif string_merge_behavior == 'sd':
                        f = lambda l: np.std(l)
                    elif string_merge_behavior == 'max':
                        f = lambda l: np.max(l)
                    elif string_merge_behavior == 'min':
                        f = lambda l: np.min(l)
                    elif string_merge_behavior == 'median':
                        f = lambda l: np.median(l)
                    else: f = lambda l: float('nan')

                    merged_var = [f(values[g]) if g in values.keys() else float('nan') for g in gene_names]
                    merged['rna'].var[varc] = merged_var
                
                elif type(labels[0]) is bool:

                    if bool_merge_behavior == 'and':
                        f = lambda l: all(l)
                    elif bool_merge_behavior == 'or':
                        f = lambda l: any(l)
                    else: f = lambda l: False

                    merged_var = [f(values[g]) if g in values.keys() else False for g in gene_names]
                    merged['rna'].var[varc] = merged_var

                else: warning(f'`{key}` with unsupported type. skipped.')
                pass

            pass # merging 'rna'.

        
        if 'cite' in self.modalities.keys():

            filtered = {}
            for rnak in self.modalities['cite'].keys():

                # if following the recommended routine, by the time one will need
                # to merge the datasets, the X slot should contain log normalized values.

                filtered[rnak] = ad.AnnData(
                    X = self.modalities['cite'][rnak].X,
                    obs = self.modalities['cite'][rnak].obs,
                    var = self.modalities['cite'][rnak].var
                )

                if 'counts' in self.modalities['cite'][rnak].layers.keys():
                    filtered[rnak].layers['counts'] = self.modalities['cite'][rnak].layers['counts']

                for obsm in obsms:
                    filtered[rnak].obsm[obsm] = self.modalities['cite'][rnak].obsm[obsm]

                if subset_dict is not None:
                    if rnak not in subset_dict.keys():
                        del filtered[rnak]
                    
                    else:
                        cell_mask = [
                            x in subset_dict[rnak] 
                            for x in filtered[rnak].obs[subset_key].tolist()
                        ]

                        if not all(cell_mask):
                            filtered[rnak] = filtered[rnak][cell_mask, :]


            # merge rna st.
            merged['cite'] = ad.concat(
                filtered, axis = 'obs', 
                join = join, label = 'sample'
            )

            pass # merging 'cite'.
        
        
        # integrate tcr metadata
        if ('rna' in merged.keys()) and os.path.exists(os.path.join(self.directory, 'tcr')):
            st.rna_attach_tcr(merged['rna'], None, os.path.join(self.directory, 'tcr'))

        if ('rna' in merged.keys()) and os.path.exists(os.path.join(self.directory, 'bcr')):
            st.rna_attach_bcr(merged['rna'], None, os.path.join(self.directory, 'bcr'))

        if 'atac' in self.modalities.keys():
            filtered = {}
            assemblies = []
            assembly_size = None
            nvs = []
            var_table = None

            for atack in self.modalities['atac'].keys():
                
                filtered[atack] = ad.AnnData(
                    X = self.modalities['atac'][atack].X,
                    obs = self.modalities['atac'][atack].obs,
                    var = self.modalities['atac'][atack].var,
                )

                nvs.append(self.modalities['atac'][atack].n_vars)
                var_table = self.modalities['atac'][atack].var
                filtered[atack].uns['assembly'] = self.modalities['atac'][atack].uns['assembly'] 
                filtered[atack].uns['assembly.size'] = self.modalities['atac'][atack].uns['assembly.size'] 
                assemblies.append(self.modalities['atac'][atack].uns['assembly'] )
                assembly_size = self.modalities['atac'][atack].uns['assembly.size']

                if 'paired' in self.modalities['atac'][atack].obsm.keys():
                    filtered[atack].obsm['paired'] = self.modalities['atac'][atack].obsm['paired'] 
                if 'single' in self.modalities['atac'][atack].obsm.keys():
                    filtered[atack].obsm['single'] = self.modalities['atac'][atack].obsm['single'] 
            
            # check the assembly to be completely identical
            if len(set(assemblies)) != 1:
                warning(f'cannot merge atac data with different genomic assemblies.')
            
            if len(set(nvs)) != 1:
                warning(f'cannot merge atac data with inconsistant bins.')
                warning(f'you should not filter out the bins (or select features) before integration.')
            
            else:
                merged['atac'] = ad.concat(
                    filtered, axis = 'obs', 
                    join = join, label = 'sample'
                )

                merged['atac'].uns['assembly'] = assemblies[0]
                merged['atac'].uns['assembly.size'] = assembly_size
                if var_table is not None:
                    merged['atac'].var = var_table.loc[
                        merged['atac'].var_names, 
                        ['chr', 'start', 'end', 'location', 'unique']
                    ]

            pass

        if 'rnasp-c' in self.modalities.keys():

            filtered = {}
            spatialdict = {}

            for rnak in self.modalities['rnasp-c'].keys():

                # if following the recommended routine, by the time one will need
                # to merge the datasets, the X slot should contain log normalized values.

                filtered[rnak] = ad.AnnData(
                    X = self.modalities['rnasp-c'][rnak].X,
                    obs = self.modalities['rnasp-c'][rnak].obs,
                    var = self.modalities['rnasp-c'][rnak].var,
                )

                if 'counts' in self.modalities['rnasp-c'][rnak].layers.keys():
                    filtered[rnak].layers['counts'] = self.modalities['rnasp-c'][rnak].layers['counts']

                if 'spliced' in self.modalities['rnasp-c'][rnak].layers.keys():
                    filtered[rnak].layers['spliced'] = self.modalities['rnasp-c'][rnak].layers['spliced']

                if 'unspliced' in self.modalities['rnasp-c'][rnak].layers.keys():
                    filtered[rnak].layers['unspliced'] = self.modalities['rnasp-c'][rnak].layers['unspliced']

                if 'ambiguous' in self.modalities['rnasp-c'][rnak].layers.keys():
                    filtered[rnak].layers['ambiguous'] = self.modalities['rnasp-c'][rnak].layers['ambiguous']
                
                for obsm in list(set(['spatial'] + obsms)):
                    filtered[rnak].obsm[obsm] = self.modalities['rnasp-c'][rnak].obsm[obsm]

                for spsample in self.modalities['rnasp-c'][rnak].uns['spatial'].keys():
                    spatialdict[spsample] = self.modalities['rnasp-c'][rnak].uns['spatial'][spsample]

                if subset_dict is not None:
                    if rnak not in subset_dict.keys():
                        del filtered[rnak]
                    
                    else:
                        cell_mask = [
                            x in subset_dict[rnak] 
                            for x in filtered[rnak].obs[subset_key].tolist()
                        ]

                        if not all(cell_mask):
                            filtered[rnak] = filtered[rnak][cell_mask, :]


            # merge rna st.
            merged['rnasp-c'] = ad.concat(
                filtered, axis = 'obs', 
                join = join, label = 'sample'
            )

            merged['rnasp-c'].uns['spatial'] = spatialdict

            # retrieve the corresponding gene info according to the universal 
            # nomenclature rna:[tax]:[ugene] format

            gene_names = merged['rnasp-c'].var_names.tolist()
            merged['rnasp-c'].var = st.search_genes(gene_names)

            # we will next merge variable columns. this is typically designed for
            # merging bool vector masks for hvgs.
            
            for varc in variable_columns:
                
                values = {}

                for rnak in self.modalities['rnasp-c'].keys():

                    # just skip samples with explicitly ignored subset.
                    if subset_dict is not None:
                        if rnak not in subset_dict.keys():
                            continue

                    key = self.modalities['rnasp-c'][rnak].var.index.tolist()
                    if not varc in self.modalities['rnasp-c'][rnak].var.columns.tolist():
                        warning(f'sample `{rnak}` does not contain variable column `{key}`. skipped.')
                        continue

                    value = self.modalities['rnasp-c'][rnak].var[varc].tolist()
                    for idk in range(len(key)):
                        if key[idk] not in values.keys(): values[key[idk]] = []
                        values[key[idk]] += [value[idk]]
                
                labels = values[list(values.keys())[0]]
                if type(labels[0]) is str:

                    if string_merge_behavior == 'unique_concat':
                        f = lambda l: string_merge_sep.join(list(set(l)))
                    elif string_merge_behavior == 'concat':
                        f = lambda l: string_merge_sep.join(l)
                    else: f = lambda l: 'NA'

                    merged_var = [f(values[g]) if g in values.keys() else 'NA' for g in gene_names]
                    merged['rna'].var[varc] = merged_var

                elif (type(labels[0]) is int) or \
                     (type(labels[0]) is float) or \
                     (type(labels[0]) is np.float32) or \
                     (type(labels[0]) is np.float64) or \
                     (type(labels[0]) is np.int32):

                    if numeric_merge_behavior == 'mean':
                        f = lambda l: np.mean(l)
                    elif string_merge_behavior == 'var':
                        f = lambda l: np.var(l)
                    elif string_merge_behavior == 'sd':
                        f = lambda l: np.std(l)
                    elif string_merge_behavior == 'max':
                        f = lambda l: np.max(l)
                    elif string_merge_behavior == 'min':
                        f = lambda l: np.min(l)
                    elif string_merge_behavior == 'median':
                        f = lambda l: np.median(l)
                    else: f = lambda l: float('nan')

                    merged_var = [f(values[g]) if g in values.keys() else float('nan') for g in gene_names]
                    merged['rnasp-c'].var[varc] = merged_var
                
                elif type(labels[0]) is bool:

                    if bool_merge_behavior == 'and':
                        f = lambda l: all(l)
                    elif bool_merge_behavior == 'or':
                        f = lambda l: any(l)
                    else: f = lambda l: False

                    merged_var = [f(values[g]) if g in values.keys() else False for g in gene_names]
                    merged['rnasp-c'].var[varc] = merged_var

                else: warning(f'`{key}` with unsupported type. skipped.')
                pass

            pass # merging 'rnasp-c'.


        if len(merged) > 0:
            mdata = mu.MuData(merged)
            self.mudata = mdata

        else: self.mudata = None


    def attach_metadata(self, dataframe, slot = 'rna', by = 'sample'):
        '''
        Attach observation metadata after a dataset have been merged.
        The additional dataframe should contain a column matched to the `by` parameter, 
        which will be used to match the rows in the merged dataset. The other columns 
        will be attached as new observation metadata columns, or override the existing ones. 

        If the value in the dataframe is '@asis', the original value will be kept. 
        If the value starts with '@', it will be treated as a reference to another column 
        in the merged dataset, and the value will be copied from that column. 
        Otherwise, the value will be directly assigned to the new column.

        Parameters
        ----------
        dataframe: pd.DataFrame
            The dataframe containing the metadata to be attached. It should have a column 
            that matches the `by` parameter in the original merged dataset.

        slot: str = 'rna'
            The modality slot to attach the metadata to.

        by: str = 'sample'
            The index key to join.
        '''

        self.check_merged(slot)
        for irow in range(len(dataframe)):
            row = dataframe.iloc[irow, :].copy()
            mask = self[slot].obs[by] == row[by]

            for column in dataframe.columns:
                if column == by: continue
                if column not in self[slot].obs.columns: self[slot].obs[column] = ''
                else: self[slot].obs[column] = self[slot].obs[column].astype('str')

                if row[column] == '@asis': pass
                elif row[column].startswith('@'):
                    self[slot].obs.loc[mask, column] = self[slot].obs.loc[mask, row[column][1:]]
                else: self[slot].obs.loc[mask, column] = row[column]
            
        pass


    def do_for(self, modality, samples, func, parallel = None, **kwargs):
        
        results = {}

        queue = {}
        for mod, samp in zip(
            self.metadata.dataframe['modality'].tolist(),
            self.metadata.dataframe['sample'].tolist()
        ):
            if '.' in mod: continue
            if mod != modality: continue

            do = False
            if samples is None: do = True
            if isinstance(samples, list):
                if samp in samples: do = True

            if do: 
                
                results[samp] = None

                if self.modalities is None:
                    warning(f'experiment do not load any samples.')
                    return
                
                if not mod in self.modalities.keys():
                    warning(f'{mod} does not loaded in the modalities key.')
                    continue
                if not samp in self.modalities[mod].keys():
                    warning(f'{samp} not loaded in the {mod} modality.')
                    continue

                queue[samp] = { 'mod': mod, 'samp': samp, 'data': self.modalities[mod][samp] }
        
        # perform the operation for queues

        if parallel:

            # perform operation in parallel for the list of anndata.
            # the internal code is implemented in snapatac's package.
            # the parallel arguments is None or an integer representing the number
            # of jobs to take parallelly.

            from multiprocessing import Process
            from multiprocessing import Pool
            from functools import partial
            from exprmat import pprog

            partial_task = partial(st.parallel_return_self, func = func, kwargs = kwargs)
            keys = [key for key in queue.keys()]
            args = [[queue[k]['data'], k] for k in keys]
            del keys # no use! unordered parallel,
            # k is passed and returned for reconstruction of order

            # must be ordered
            p = Pool(processes = parallel)
            output = list(pprog(
                p.imap_unordered(partial_task, args),
                total = len(args), desc = 'processing anndata'
            ))

            p.close()
            
            results = {}
            for data, key, out in output:
                self.modalities[
                    queue[key]['mod']
                ][queue[key]['samp']] = data
                results[key] = out

            return results

        else:
            for key in queue.keys():
                results[key] = func(queue[key]['data'], key, **kwargs)
        
        return results

    def do_for_modality(self, modality, run_on_samples, func, **kwargs):
        if isinstance(run_on_samples, bool) and run_on_samples:
            return self.do_for(modality, self.all_samples(modality), func, **kwargs)
        elif isinstance(run_on_samples, list):
            return self.do_for(
                modality, list(set(self.all_samples(modality)) & set(run_on_samples)), 
                func, **kwargs
            )
        elif isinstance(run_on_samples, str):
            # match for samples, support regex also.
            # will turn on regex mode if the expression starts with '^'.
            alls = self.all_samples(modality)
            import re
            alls = [x for x in alls if re.match(run_on_samples, x) is not None]
            # info(f'sample(s) [{", ".join(alls)}] selected by regex.')
            return self.do_for(modality, alls, func, **kwargs)
        else:
            assert modality in self.mudata.mod.keys()
            return func(self.mudata[modality], 'integrated', **kwargs)
        
    def do_for_rna(self, run_on_samples, func, **kwargs):
        return self.do_for_modality('rna', run_on_samples, func, **kwargs)

    def do_for_cite(self, run_on_samples, func, **kwargs):
        return self.do_for_modality('cite', run_on_samples, func, **kwargs)
    
    def do_for_atac(self, run_on_samples, func, **kwargs):
        return self.do_for_modality('atac', run_on_samples, func, **kwargs)
    
    def do_for_atac_peaks(self, run_on_samples, func, **kwargs):
        return self.do_for_modality('atac-p', run_on_samples, func, **kwargs)
    
    def do_for_atac_gene_activity(self, run_on_samples, func, **kwargs):
        return self.do_for_modality('atac-g', run_on_samples, func, **kwargs)
    
    def do_for_rnaspc(self, run_on_samples, func, **kwargs):
        return self.do_for_modality('rnasp-c', run_on_samples, func, **kwargs)
    
    def do_for_rnaspb(self, run_on_samples, func, **kwargs):
        return self.do_for_modality('rnasp-b', run_on_samples, func, **kwargs)
        
    
    def plot_for_modality(
        self, modality, run_on_samples, func,
        run_on_splits = False, split_key = None, split_selection = None, 
        do_tight_layout = True, **kwargs
    ):
        from exprmat.utils import setup_styles
        setup_styles()

        if isinstance(run_on_samples, bool) and run_on_samples:
            figures = self.do_for(modality, self.all_samples(modality), func, **kwargs)
            for f in figures.values(): 
                if f is None: continue
                if do_tight_layout: f.tight_layout()
            return figures
        
        elif isinstance(run_on_samples, list):
            figures = self.do_for(
                modality, list(set(self.all_samples(modality)) & set(run_on_samples)), 
                func, **kwargs
            )

            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                for f in figures.values(): 
                    if f is None: continue
                    if do_tight_layout: f.tight_layout()
            
            return figures
        
        else:

            # the merged modality. this is not restricted to the sample table,
            # and we may generate secondary (artifical) modality that is not
            # directly loaded from disks.

            assert modality in self.mudata.mod.keys()

            if not run_on_splits:
                figure = func(self.mudata[modality], 'integrated', **kwargs)
                import warnings
                warnings.filterwarnings('ignore')
                if do_tight_layout: figure.tight_layout()
                return figure

            else:
                results = {}
                cats = self.mudata[modality].obs[split_key].cat.categories.tolist()
                if split_selection is None: split_selection = cats

                n_features = len(split_selection)
                for feat_id in range(len(split_selection)):

                    results[split_selection[feat_id]] = func(
                        self.mudata[modality][
                            self.mudata[modality].obs[split_key] == split_selection[feat_id],:].copy(),
                        # copy the data to silence the implicit modification warning on views. 
                        split_selection[feat_id], 
                        **kwargs
                    )

                    if do_tight_layout: results[split_selection[feat_id]].tight_layout()
                
                return results
    
    def plot_for_rna(
        self, run_on_samples, func,
        run_on_splits = False, split_key = None, split_selection = None, **kwargs
    ):
        return self.plot_for_modality(
            'rna', run_on_samples, func, 
            run_on_splits, split_key, split_selection, **kwargs
        )
    
    def plot_for_cite(
        self, run_on_samples, func,
        run_on_splits = False, split_key = None, split_selection = None, **kwargs
    ):
        return self.plot_for_modality(
            'cite', run_on_samples, func, 
            run_on_splits, split_key, split_selection, **kwargs
        )

    def plot_for_atac(
        self, run_on_samples, func,
        run_on_splits = False, split_key = None, split_selection = None, **kwargs
    ):
        return self.plot_for_modality(
            'atac', run_on_samples, func,
            run_on_splits, split_key, split_selection, **kwargs
        )

    def plot_for_atac_peaks(
        self, run_on_samples, func,
        run_on_splits = False, split_key = None, split_selection = None, **kwargs
    ):
        return self.plot_for_modality(
            'atac-p', run_on_samples, func, 
            run_on_splits, split_key, split_selection, **kwargs
        )

    def plot_for_atac_gene_activity(
        self, run_on_samples, func,
        run_on_splits = False, split_key = None, split_selection = None, **kwargs
    ):
        return self.plot_for_modality(
            'atac-g', run_on_samples, func, 
            run_on_splits, split_key, split_selection, **kwargs
        )
    
    def plot_for_rnaspc(
        self, run_on_samples, func,
        run_on_splits = False, split_key = None, split_selection = None, **kwargs
    ):
        return self.plot_for_modality(
            'rnasp-c', run_on_samples, func, 
            run_on_splits, split_key, split_selection, **kwargs
        )
    
    def plot_for_rnaspb(
        self, run_on_samples, func,
        run_on_splits = False, split_key = None, split_selection = None, **kwargs
    ):
        return self.plot_for_modality(
            'rnasp-b', run_on_samples, func, 
            run_on_splits, split_key, split_selection, **kwargs
        )

    
    def all_samples(self, modality = None):
        if modality is None:
            return self.metadata.dataframe['sample'].tolist()
        elif isinstance(modality, str): 
            return self.metadata.dataframe[
                (self.metadata.dataframe['modality'] == modality)
            ]['sample'].tolist()
        elif isinstance(modality, list):
            return self.metadata.dataframe.loc[
                [x in modality for x in self.metadata.dataframe['modality']], :
            ]['sample'].tolist()
    
    def all_rna_samples(self, with_raw = None):
        if with_raw is None:
            return self.all_samples('rna')
        else:
            samples = self.all_samples('rna')
            if with_raw: return [s for s in samples if ('.raw' in self['rna'][s].uns.keys())]
            else: return [s for s in samples if not ('.raw' in self['rna'][s].uns.keys())]
    
    def all_atac_samples(self):
        return self.all_samples('atac')
    
    def check_merged(self, slot = None):
        if self.mudata is None:
            error('requires the dataset to be merged before running this method.') 
        if slot is not None:
            if slot not in self.mudata.mod.keys():
                error(f'requires specific slot `{slot}` be in merged mudata.') 

    
    def build_subset(
        self, subset_name, slot = 'rna',
        values = None, keys = ['sample']
    ):
        self.check_merged(slot)
        self.pull()

        masks = []
        final = np.array([True] * self.mudata.n_obs, dtype = np.bool)
        for idx in range(len(keys)):
            masks += [np.array([x in values[idx] for x in self.mudata.obs[f'{slot}:{keys[idx]}'].tolist()])]
        
        for mask in masks: final = final & mask
        subset = self.mudata[final, :].copy()
        info(f'selected {final.sum()} observations from {len(final)}.')

        if not os.path.exists(os.path.join(self.directory, 'subsets')):
            os.makedirs(os.path.join(self.directory, 'subsets'))
        
        subset.write_h5mu(os.path.join(self.directory, 'subsets', subset_name + '.h5mu'))


    def build_subsample(
        self, subset_name, slot = 'rna',
        key = None, n = 3000
    ):
        self.check_merged(slot)
        self.pull()
        from exprmat.dynamics.utils import indices_to_bool

        if key is None:
            if n > self.mudata.n_obs:
                n = self.mudata.n_obs
                warning('subsample n > obs. returning all indices')
            else: info(f'randomly selects {n} cells from {self.mudata.n_obs}.')
            rind = np.random.choice(self.mudata.n_obs, size = n, replace = False)
            mask = indices_to_bool(rind, self.mudata.n_obs)

        elif isinstance(n, dict):
            values = self.mudata.obs[f'{slot}:{key}'].unique().tolist()
            rind = np.array([])
            for val in values:
                indices = np.argwhere(self.mudata.obs[f'{slot}:{key}'] == val).flatten()
                if str(val) in n.keys(): _n = n[str(val)]
                else: continue
                if _n == '*': _n = len(indices)

                if _n > len(indices):
                    _n = len(indices)
                    warning(f'subsample n > len({val}). returning all indices')
                else: info(f'randomly selects {_n} cells from [{val}] ({len(indices)}).')
                rind = np.append(rind, np.random.choice(indices, size = _n, replace = False))
            mask = indices_to_bool(rind, self.mudata.n_obs)

        subset = self.mudata[mask, :].copy()
        info(f'selected {mask.sum()} observations from {len(mask)}.')

        if not os.path.exists(os.path.join(self.directory, 'subsets')):
            os.makedirs(os.path.join(self.directory, 'subsets'))
        
        subset.write_h5mu(os.path.join(self.directory, 'subsets', subset_name + '.h5mu'))


    def annotate(
        self, slot = 'rna', annotation = 'cell.type',
        mapping = {}, cluster = 'leiden'
    ):
        self.check_merged(slot)

        reverse_dict = {}
        for key in mapping.keys():
            value = mapping[key]
            if isinstance(value, int):
                reverse_dict[str(value)] = key
            elif isinstance(value, str):
                reverse_dict[value] = key
            elif isinstance(value, list):
                for l in value:
                    reverse_dict[str(l)] = key
            
        annot = [
            reverse_dict[x] if x in reverse_dict.keys()
            else x
            for x in self.mudata[slot].obs[cluster].tolist()
        ]
        
        self.mudata[slot].obs[annotation] = annot
        self.mudata[slot].obs[annotation] = self.mudata[slot].obs[annotation].astype('category')
        print(self.mudata[slot].obs[annotation].value_counts())


    def annotate_merge(
        self, slot = 'rna', annotation = 'cell.type',
        merge = [], into = '_'
    ):
        '''
        Merge several categories ``merge`` into a single one ``into`` in the annotation column.
        This is a shortcut for :func:`annotate` when one just want to merge several existing
        categories into one without changing the other categories.
        '''
        self.check_merged(slot)
        ls = self.mudata[slot].obs[annotation].tolist()
        ls = [into if x in merge else x for x in ls]
        self.mudata[slot].obs[annotation] = ls
        self.mudata[slot].obs[annotation] = self.mudata[slot].obs[annotation].astype('category')
        print(self.mudata[slot].obs[annotation].value_counts())

    
    def annotate_paste(
        self, froms, into, slot = 'rna', sep = '.'
    ):
        '''
        Paste multiple annotation columns (``froms``) into one column (``into``) by 
        concatenating the values with separator ``sep``. All the columns to be concatenated
        will be treated as strings.
        '''

        self.check_merged(slot)
        ls = [self.mudata[slot].obs[f].tolist() for f in froms]
        concat = []
        for tupl in zip(*ls):
            concat.append(sep.join(list(tupl)))
        self.mudata[slot].obs[into] = concat
        self.mudata[slot].obs[into] = self.mudata[slot].obs[into].astype('category')
        print(self.mudata[slot].obs[into].value_counts())

    
    def annotate_broadcast(self, slot = 'rna', annotation = 'cell.type', todf = None, to = 'cell.type'):
        '''
        Broadcast a specific column annotation to the sibling subsets or the integrated dataset
        from the same experiment directory. 
        
        This is designed for the scenario where one has annotated a specific subset and want to 
        broadcast the annotation to other subsets or the integrated dataset.

        Parameters
        ----------
        slot: str = 'rna'
            The modality slot to perform the broadcasting.
        
        annotation: str = 'cell.type'
            The column name of the annotation to be broadcasted. It should be in the obs dataframe
        
        todf: str or None = None
            The target dataframe to broadcast the annotation to. It can be None, a subset name,
            or 'integrated'. If None, the annotation will be copied to the current dataset.
        
        to: str = 'cell.type'
            The column name of the target annotation. If the column already exists, the non-nan
            values from the source annotation will overwrite the values in the target column. 
            If the column does not exist, a new column will be created.
        '''

        import h5py
        from anndata.io import read_elem, write_elem
        
        if todf is None:
            
            # broadcast to the same dataset (just a copy of non-nan values.)
            toslot = self.mudata[slot].obs[to].tolist() \
                if to in self.mudata[slot].obs.columns \
                    else [None] * self.mudata[slot].n_obs
            fromslot = self.mudata[slot].obs[annotation].tolist()
            self.mudata[slot].obs[to] = [
                x if str(x) != 'nan' else y 
                for x, y in zip(fromslot, toslot)
            ]

            info(f'merged {annotation} to {to} in current dataset.')
            print(self.mudata[slot].obs[to].value_counts())
            self.mudata[slot].obs[to] = self.mudata[slot].obs[to].astype('category')

        # if todf is another subset.
        elif isinstance(todf, str) and os.path.exists(
            os.path.join(self.directory, 'subsets', todf + '.h5mu')
        ):
            if (self.subset is not None) and (todf == self.subset):

                # broadcast to the same dataset (just a copy of non-nan values.)
                toslot = self.mudata[slot].obs[to].tolist() \
                    if to in self.mudata[slot].obs.columns \
                        else [None] * self.mudata[slot].n_obs
                fromslot = self.mudata[slot].obs[annotation].tolist()
                self.mudata[slot].obs[to] = [
                    x if str(x) != 'nan' else y 
                    for x, y in zip(fromslot, toslot)
                ]

                info(f'merged {annotation} to {to} in current dataset.')
                print(self.mudata[slot].obs[to].value_counts())
                self.mudata[slot].obs[to] = self.mudata[slot].obs[to].astype('category')

            else:
                
                with h5py.File(os.path.join(self.directory, 'subsets', todf + '.h5mu'), 'r+') as h5f:
                    
                    target_df = read_elem(h5f['mod']['rna']['obs'])

                    toslot = target_df[to].tolist() \
                        if to in target_df.columns \
                            else [None] * len(target_df)

                    fromtable = pd.DataFrame({
                        'index': self.mudata[slot].obs_names.tolist(),
                        '.temp': self.mudata[slot].obs[annotation].tolist()
                    })

                    fromtable = fromtable.set_index('index')
                    target_df = target_df.join(fromtable, how = 'left')

                    fromslot = target_df['.temp'].tolist()
                    target_df[to] = [
                        x if str(x) != 'nan' else y 
                        for x, y in zip(fromslot, toslot)
                    ]

                    del target_df['.temp']
                    info(f'updated {annotation} to {to} in subsets/{todf}.h5mu')
                    print(target_df[to].value_counts())
                    target_df[to] = target_df[to].astype('category')

                    write_elem(h5f, '/mod/rna/obs', target_df)
        

        elif isinstance(todf, str) and todf == 'integrated':
            
            with h5py.File(os.path.join(self.directory, 'integrated.h5mu'), 'r+') as h5f:
                    
                target_df = read_elem(h5f['mod']['rna']['obs'])

                toslot = target_df[to].tolist() \
                    if to in target_df.columns \
                        else [None] * len(target_df)

                fromtable = pd.DataFrame({
                    'index': self.mudata[slot].obs_names.tolist(),
                    '.temp': self.mudata[slot].obs[annotation].tolist()
                })

                fromtable = fromtable.set_index('index')
                target_df = target_df.join(fromtable, how = 'left')

                fromslot = target_df['.temp'].tolist()
                target_df[to] = [
                    x if str(x) != 'nan' else y 
                    for x, y in zip(fromslot, toslot)
                ]

                del target_df['.temp']
                info(f'updated {annotation} to {to} in {todf}.h5mu')
                print(target_df[to].value_counts())
                target_df[to] = target_df[to].astype('category')

                write_elem(h5f, '/mod/rna/obs', target_df)
            
            
    def exclude(
        self, slot = 'rna', annotation = 'cell.type', remove = []
    ):
        '''
        Exclude observations with specific annotation values.
        '''

        self.check_merged(slot)
        ls = self.mudata[slot].obs[annotation].tolist()
        mask = [x not in remove for x in ls]
        orig = self.mudata.n_obs
        self.mudata = self.mudata[mask, :].copy()
        info(f'keep {self.mudata.n_obs} observations from {orig}.')


    def exclude_outlier(
        self, slot = 'rna', embedding = 'umap', xlim = (-5, 5), ylim = (-5, 5)
    ):
        '''
        Exclude observations with embedding coordinates outside of the specified limits. 
        This is designed for removing outliers in low-dimensional embedding space, 
        which may be generated by technical artifacts.
        '''
        self.check_merged(slot)
        assert embedding in self.mudata[slot].obsm
        assert self.mudata[slot].obsm[embedding].shape[1] == 2
        mask = (
            (self.mudata[slot].obsm[embedding][:, 0] >= xlim[0]) &
            (self.mudata[slot].obsm[embedding][:, 0] <= xlim[1]) &
            (self.mudata[slot].obsm[embedding][:, 1] >= ylim[0]) &
            (self.mudata[slot].obsm[embedding][:, 1] <= ylim[1])
        )

        orig = self.mudata.n_obs
        self.mudata = self.mudata[mask, :]
        info(f'keep {self.mudata.n_obs} observations from {orig}.')


    def keep(
        self, slot = 'rna', annotation = 'cell.type', k = []
    ):
        '''
        Keep observations with specific annotation values.
        '''

        self.check_merged(slot)
        ls = self.mudata[slot].obs[annotation].tolist()
        mask = [x in k for x in ls]
        orig = self.mudata.n_obs
        self.mudata = self.mudata[mask, :]
        info(f'keep {self.mudata.n_obs} observations from {orig}.')

    
    def exclude_nonexisting_variables(self, slot = 'rna'):
        '''
        Remove genes that do not express (since we make a subset of the total dataset).
        Since PCA doesn't allow columns that are completely made up of zeros.
        '''
        import numpy as np
        gene_mask = self.mudata.mod[slot].X.sum(axis = 0) <= 0.01
        print(f'removed {gene_mask.sum()} genes with zero expression.')
        self.mudata.mod[slot] = self.mudata.mod[slot][:, ~ gene_mask].copy()


    def find_variable(self, gene_name, slot = 'rna', layer = 'X'):
        self.check_merged(slot)
        from exprmat.utils import find_variable as fvar
        return fvar(self.mudata.mod[slot], gene_name = gene_name, layer = layer)
    

    def filter(self, into, conditions = [], criteria = [], slot = 'rna'):

        bool_masks = []
        assert len(conditions) == len(criteria)
        for cond, crit in zip(conditions, criteria):
            bool_masks.append(crit(self.find_variable(cond, slot)))
        
        npbool = bool_masks[0]
        if len(bool_masks) > 1:
            for bx in range(1, len(bool_masks)):
                npbool = npbool & bool_masks[bx]
        
        self.mudata[slot].obs[into] = ['true' if x else 'false' for x in npbool.tolist()]
        self.mudata[slot].obs[into] = self.mudata[slot].obs[into].astype('category')
        print(self.mudata[slot].obs[into].value_counts())


    # wrapper functions

    def run_rna_qc(self, run_on_samples = False, **kwargs):
        """
        Quality control filtering on RNA samples.

        Removes low-quality cells based on mitochondrial and ribosomal content,
        library-size outliers, and predicted doublets. Genes with insufficient
        detection across cells are also removed. Should be run per-sample before
        integration.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. ``False`` applies the function on the
            integrated mudata object; ``True`` iterates over all loaded
            per-sample AnnData objects in ``modalities['rna']``; a list or
            regex string selects specific samples by name.
        mt_seqid : str, default 'MT'
            Sequence ID (chromosome name) used to identify mitochondrial genes
            in the genome annotation. Use ``'chrM'`` for UCSC-style names.
        mt_percent : float, default 0.15
            Maximum allowed fraction of mitochondrial UMIs per cell. Cells
            above this threshold are flagged as low quality.
        ribo_genes : list[str] | None, default None
            ENSEMBL gene IDs of ribosomal genes. If ``None``, genes whose
            ``gene`` name starts with ``Rps`` or ``Rpl`` are auto-selected.
        ribo_percent : float | None, default None
            Maximum allowed fraction of ribosomal UMIs per cell. No filter is
            applied when ``None``.
        outlier_mode : str, default 'mads'
            Method for detecting library-size outliers. ``'mads'`` uses median
            absolute deviations; ``'tukey'`` uses Tukey fences.
        outlier_n : float, default 5
            Threshold multiplier for the chosen outlier method (number of MADs,
            or IQR multiplier).
        max_genes : int | None, default None
            Hard upper bound on detected genes per cell applied after the
            outlier filter.
        doublet_method : str, default 'scrublet'
            Doublet-detection algorithm. Supported: ``'scrublet'``.
        min_cells : int, default 3
            Minimum number of cells in which a gene must be detected to be
            retained.
        min_genes : int, default 300
            Minimum number of genes that must be detected in a cell to be
            retained.
        """
        results = self.do_for_rna(run_on_samples, st.rna_qc, **kwargs)
        if isinstance(results, dict):
            for k in results.keys():
                self.modalities['rna'][k] = results[k]
        else: self.mudata.mod['rna'] = results
        
    def run_rna_filter(self, run_on_samples = False):
        """
        Keep only cells and genes that passed QC.

        Subsets each sample's AnnData to the cells and genes whose ``qc``
        boolean flag (set by :meth:`run_rna_qc`) is ``True``. Must be preceded
        by :meth:`run_rna_qc`.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        """
        results = self.do_for_rna(run_on_samples, st.rna_filter)
        if isinstance(results, dict):
            for k in results.keys():
                self.modalities['rna'][k] = results[k]
        else: self.mudata.mod['rna'] = results

    def run_rna_filter_row_by_sum(self, run_on_samples = False, **kwargs):
        """
        Filter RNA cells (rows) by their total count.

        Retains only cells whose per-cell expression sum falls within the
        specified range.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        min_sum : float, default 3
            Minimum total count; cells below this threshold are removed.
        max_sum : float, default np.finfo(np.float32).max
            Maximum total count; cells above this threshold are removed.
        layer : str, default 'X'
            Layer to sum over (``'X'`` refers to the main matrix).
        """
        results = self.do_for_rna(run_on_samples, st.adata_filter_row_by_sum, **kwargs)
        if isinstance(results, dict):
            for k in results.keys():
                self.modalities['rna'][k] = results[k]
        else: self.mudata.mod['rna'] = results

    def run_rna_filter_column_by_sum(self, run_on_samples = False, **kwargs):
        """
        Filter RNA genes (columns) by their total count across cells.

        Retains only genes whose summed expression across all cells falls
        within the specified range.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        min_sum : float, default 3
            Minimum total count; genes below this threshold are removed.
        max_sum : float, default np.finfo(np.float32).max
            Maximum total count; genes above this threshold are removed.
        layer : str, default 'X'
            Layer to sum over (``'X'`` refers to the main matrix).
        """
        results = self.do_for_rna(run_on_samples, st.adata_filter_column_by_sum, **kwargs)
        if isinstance(results, dict):
            for k in results.keys():
                self.modalities['rna'][k] = results[k]
        else: self.mudata.mod['rna'] = results

    def run_rna_log_normalize(self, run_on_samples = False, **kwargs):
        """
        Normalize RNA counts to library size and apply log1p transformation.

        Scales each cell to the same total count (library-size normalization),
        stores the result in a named layer, then applies ``log1p`` to produce the
        log-normalized matrix which the pipeline uses downstream.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        key_source : str, default 'X'
            Layer containing raw counts (``'X'`` refers to the main matrix).
        key_norm : str, default 'norm'
            Destination layer name for the size-factor-normalized counts.
        key_lognorm : str, default 'lognorm'
            Destination layer name for the log-normalized values. After this
            step ``adata.X`` is replaced by this layer.
        """
        self.do_for_rna(run_on_samples, st.rna_log_normalize, **kwargs)

    def run_rna_select_hvg(self, run_on_samples = False, **kwargs):
        """
        Select highly variable genes (HVGs) for downstream analysis.

        Scores genes by their expression variance and flags the most variable
        subset, writing results into ``adata.var``. HVG selection is required
        before :meth:`run_rna_scale_pca`.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        key_lognorm : str, default 'lognorm'
            Layer containing log-normalized values.
        method : str, default 'vst'
            HVG selection strategy. Options: ``'vst'`` (Seurat v3 variance-
            stabilizing transformation), ``'ff'`` (Fano factor), ``'cellranger'``
            (negative-binomial log dispersion), ``'binned'`` (Seurat v1/v2).
        n_top_genes : int | None, default 2000
            Number of top highly variable genes to select. Used when
            ``method`` is ``'vst'``.
        min_disp : float, default 0.5
            Minimum normalized dispersion for the ``'cellranger'`` / ``'binned'``
            methods.
        max_disp : float, default inf
            Maximum normalized dispersion.
        min_mean : float, default 0.0125
            Minimum mean expression.
        max_mean : float, default 3
            Maximum mean expression.
        dest : str, default 'vst'
            Prefix for the var columns added (e.g. ``'vst.hvg'``,
            ``'vst.means'``, ``'vst.vars.norm'``).
        """
        self.do_for_rna(run_on_samples, st.rna_select_hvg, **kwargs)

    def run_rna_scale_pca(self, run_on_samples = False, **kwargs):
        """
        Scale HVG expression values and compute PCA embedding.

        Subsets to highly variable genes, zero-mean / unit-variance scales the
        log-normalized matrix across genes, then runs truncated SVD (PCA).
        Results are stored in ``adata.obsm[key_added]``,
        ``adata.varm[key_added]``, and ``adata.uns[key_added]``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        key_added : str, default 'pca'
            Key under which PCA coordinates are stored in ``obsm`` / ``varm``.
        n_comps : int, default 50
            Number of principal components to compute.
        hvg : str, default 'vst.hvg'
            ``adata.var`` column that flags highly variable genes.
        key_lognorm : str, default 'lognorm'
            Layer containing log-normalized values.
        key_scaled : str, default 'scaled'
            Destination layer name for the scaled matrix.
        random_state : int, default 42
            Random seed passed to the SVD solver.
        svd_solver : str, default 'arpack'
            SVD solver for scikit-learn PCA. Options: ``'arpack'``,
            ``'randomized'``, ``'auto'``.
        use_gpu : bool, default False
            Use RAPIDS (cuML) GPU-accelerated PCA if available.
        """
        self.do_for_rna(run_on_samples, st.rna_scale_pca, **kwargs)

    def run_rna_scvi(self, run_on_samples = False, **kwargs):
        """
        Compute a scVI or scANVI latent space representation.

        Trains a variational autoencoder on the HVG count matrix, optionally
        with semi-supervised imputation of cell labels (scANVI). The trained
        model is saved under ``<dump>/<rna|scvi|scanvi>/<sample>/<key_added>``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        key_added : str, default 'scvi'
            Key under which the latent coordinates are stored in ``obsm``.
        batch : str | None, default None
            ``adata.obs`` column to use as the batch key.
        n_comps : int, default 30
            Dimensionality of the latent space (``n_latent`` in scvi-tools).
        hvg : str, default 'vst.hvg'
            ``adata.var`` column that flags highly variable genes used for
            model training.
        key_counts : str, default 'counts'
            Layer containing raw integer counts.
        seeding : bool, default False
            When ``True``, runs scANVI instead of scVI (requires
            ``label_key`` in kwargs to specify the partial labels column).
        imputed_label_key : str, default 'cell.type.imputed'
            ``adata.obs`` key to store SCANVI-imputed cell-type labels. Only
            used when ``seeding=True``.
        label_key : str
            Only required when ``seeding=True``. ``adata.obs`` column
            containing the known partial cell-type labels for scANVI.
        """
        self.do_for_rna(run_on_samples, st.rna_scvi, savepath = self.directory, **kwargs)

    def run_rna_knn(self, run_on_samples = False, **kwargs):
        """
        Build a k-nearest-neighbor graph over cells.

        Computes pairwise distances in the chosen embedding space and constructs
        a connectivity graph stored in ``adata.obsp``. Required before running
        clustering or UMAP.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        use_rep : str, default 'pca'
            ``adata.obsm`` key of the embedding to use for neighbor search.
        n_comps : int | None, default None
            Number of dimensions from ``use_rep`` to use. ``None`` uses all.
        n_neighbors : int, default 30
            Number of nearest neighbors per cell.
        knn : bool, default True
            Whether to restrict to hard k-NN (True) or soft connectivity.
        method : str, default 'umap'
            Connectivity-weighting method. ``'umap'`` computes fuzzy
            simplicial set weights; ``'gauss'`` uses a Gaussian kernel.
        metric : str, default 'euclidean'
            Distance metric passed to the neighbor search.
        metric_kwds : dict, default {}
            Additional keyword arguments for the distance metric.
        random_state : int, default 0
            Random seed.
        key_added : str, default 'neighbors'
            Key under which neighbor results are stored in ``adata.uns``.
        n_jobs : int, default -1
            Number of parallel jobs for the neighbor search (``-1`` = all CPUs).
        use_gpu : bool, default False
            Use RAPIDS cuML GPU-accelerated neighbor search if available.
        gpu_approx_method : str, default 'nn_descent'
            Approximate NN algorithm used on GPU.
        """
        self.do_for_rna(run_on_samples, st.rna_knn, **kwargs)

    def run_rna_leiden(self, run_on_samples = False, **kwargs):
        """
        Cluster cells using the Leiden community-detection algorithm.

        Requires a pre-computed neighbor graph (see :meth:`run_rna_knn`).
        Cluster assignments are stored in ``adata.obs[key_added]``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        resolution : float, default 1
            Resolution parameter. Higher values produce finer-grained clusters.
        random_state : int, default 0
            Random seed for reproducibility.
        key_added : str, default 'leiden'
            ``adata.obs`` key to store cluster labels.
        adjacency : scipy sparse matrix | None, default None
            Custom adjacency matrix. If ``None``, uses the stored neighbor
            graph's connectivities.
        directed : bool | None, default None
            Treat the graph as directed. Only supported by ``leidenalg``
            flavor; not supported by ``igraph``.
        use_weights : bool, default True
            Use edge weights from the neighbor graph.
        n_iterations : int, default 2
            Number of Leiden iterations.
        neighbors_key : str | None, default None
            ``adata.uns`` key of the neighbor graph to use. Defaults to the
            standard ``'neighbors'`` key.
        flavor : str, default 'igraph'
            Leiden back-end. ``'igraph'`` (faster) or ``'leidenalg'``.
        use_gpu : bool, default False
            Use RAPIDS GPU-accelerated Leiden if available.
        theta : float, default 1
            Modularity parameter specific to some partition types.
        """
        self.do_for_rna(run_on_samples, st.rna_leiden, **kwargs)

    def run_rna_sc3(self, run_on_samples = False, **kwargs):
        """
        Cluster cells using the SC3 consensus clustering algorithm.

        SC3 constructs multiple distance matrices from different transformations
        of the expression matrix, runs k-means on each, and takes a consensus
        clustering across all runs.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        basis : str, default 'pca'
            ``adata.obsm`` key of the embedding to use as input.
        key_added : str, default 'sc3'
            Prefix written to ``adata.obs`` (e.g. ``'sc3.5'`` for k=5).
        n_clusters : list[int], default [3, 5, 10]
            Cluster numbers to test.
        d_range : int | list[int] | None, default None
            Number of PCA dimensions to use. ``None`` uses min(25, n_pcs).
        n_runs : int, default 5
            Number of random realizations for the consensus (recommend > 1).
        n_facility : int | None, default None
            Number of micro-clusters. Overridden by ``multiplier_facility``
            when provided.
        multiplier_facility : float | None, default None
            Micro-cluster count = ``multiplier_facility * max(n_clusters)``.
            Defaults to 3 when ``None``.
        batch_size : int | None, default None
            Batch size for mini-batch k-means. Default 100.
        random_state : int | None, default None
            Random seed for reproducibility.
        """
        self.do_for_rna(run_on_samples, st.rna_sc3, **kwargs)

    def run_rna_leiden_subcluster(self, run_on_samples = False, **kwargs):
        """
        Re-cluster a subset of existing Leiden clusters.

        Runs Leiden restricted to the specified cluster categories, then
        merges the new sub-cluster labels back into the original annotation
        column.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        cluster_key : str
            ``adata.obs`` column of the parent cluster assignment.
        clusters : list[str]
            Categories within ``cluster_key`` to subcluster.
        restrict_to : tuple | None, default None
            Passed directly to :func:`exprmat.clustering.run_leiden` as
            ``restrict_to``. Leave ``None`` to derive from ``cluster_key`` and
            ``clusters``.
        key_added : str, default 'leiden'
            ``adata.obs`` column to write the merged sub-cluster labels into.
        resolution : float, default 1
            Leiden resolution for the sub-clustering step.
        neighbors_key : str | None, default None
            ``adata.uns`` key of the neighbor graph.
        """
        self.do_for_rna(run_on_samples, st.rna_leiden_subcluster, **kwargs)

    def run_rna_umap(self, run_on_samples = False, **kwargs):
        """
        Compute a UMAP embedding of the cell neighborhood graph.

        Requires a pre-computed neighbor graph (see :meth:`run_rna_knn`).
        Embedding coordinates are stored in ``adata.obsm[key_added]``
        (default ``'umap'``).

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        min_dist : float, default 0.5
            Controls how tightly points cluster in the embedding. Smaller
            values produce more tightly packed clusters.
        spread : float, default 1.0
            Effective scale of embedded points. Used together with
            ``min_dist`` to set the ``a`` and ``b`` parameters.
        n_components : int, default 2
            Number of embedding dimensions.
        maxiter : int | None, default None
            Maximum optimization iterations. ``None`` uses 500 (<=10 000 cells)
            or 200 (>10 000 cells).
        alpha : float, default 1.0
            Initial learning rate for embedding optimization.
        gamma : float, default 1.0
            Repulsive strength in the loss function.
        negative_sample_rate : int, default 5
            Number of negative samples per positive.
        init_pos : str | array, default 'spectral'
            Initialization method (``'spectral'``, ``'random'``, or an
            array of initial coordinates).
        random_state : int, default 0
            Random seed.
        key_added : str | None, default None
            ``adata.obsm`` key to store the embedding. Defaults to ``'umap'``.
        neighbors_key : str, default 'neighbors'
            ``adata.uns`` key of the neighbor graph.
        use_gpu : bool, default False
            Use RAPIDS GPU-accelerated UMAP if available.
        """
        self.do_for_rna(run_on_samples, st.rna_umap, **kwargs)
    
    def run_rna_diffmap(self, run_on_samples = False, **kwargs):
        """
        Compute a diffusion map embedding.

        Constructs the Markov transition matrix from the neighbor graph and
        extracts its leading eigenvectors as a low-dimensional embedding suited
        for trajectory analysis.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        neighbors_key : str | None, default None
            ``adata.uns`` key of the neighbor graph. ``None`` falls back to
            ``'connectivities'`` from ``adata.obsp``.
        key_added : str, default 'diffmap'
            ``adata.obsm`` key to store the diffusion components.
        n_comps : int, default 3
            Number of diffusion components to compute.
        sort : str, default 'decrease'
            Sort eigenvalues in decreasing (``'decrease'``) or increasing
            (``'increase'``) order.
        density_normalize : bool, default True
            Apply density normalization to the Markov matrix.
        use_gpu : bool, default False
            Use RAPIDS (cuSPARSE) for the eigen-decomposition.
        """
        self.do_for_rna(run_on_samples, st.rna_diffmap, **kwargs)

    def run_rna_mde(self, run_on_samples = False, **kwargs):
        """
        Compute a Minimum Distortion Embedding (MDE) of the RNA data.

        MDE is a GPU-friendly alternative to UMAP that preserves both local
        and global structure. Requires ``pymde``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        data : str, default 'pca'
            ``adata.obsm`` key of the source embedding.
        key_added : str, default 'mde'
            ``adata.obsm`` key to store the MDE coordinates.
        device : str | None, default None
            Computation device: ``'cpu'`` or ``'cuda'``. ``None`` auto-selects
            GPU when available.
        n_dims : int, default 2
            Number of output dimensions.
        n_neighbors : int, default 15
            Number of neighbors considered when building the MDE problem.
        repulsive_fraction : float, default 0.7
            Fraction of dissimilarity edges used as repulsive constraints.
        eps : float, default 1e-5
            Convergence tolerance.
        max_iter : int, default 300
            Maximum optimization iterations.
        memory_size : int, default 10
            L-BFGS memory size.
        random_seed : int, default 42
            Random seed for the optimization.
        """
        self.do_for_rna(run_on_samples, st.rna_mde, **kwargs)

    def run_rna_mde_fit(self, run_on_samples = False, **kwargs):
        """
        Fit an MDE embedding by anchoring to an existing reference embedding.

        Projects new cells into a reference MDE / UMAP coordinate space by
        fitting only the unmasked cells to the reference coordinates.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        data : str, default 'pca'
            ``adata.obsm`` key of the high-dimensional source embedding.
        based : str, default 'umap'
            ``adata.obsm`` key of the reference 2-D embedding to anchor to.
        mask_key : str, default 'sample'
            ``adata.obs`` column used to define the reference subset.
        mask_values : list, default []
            Values in ``mask_key`` that identify reference cells.
        key_added : str, default 'mde'
            ``adata.obsm`` key to store the fitted MDE coordinates.
        eps : float, default 1e-5
            Convergence tolerance.
        max_iter : int, default 300
            Maximum optimization iterations.
        """
        self.do_for_rna(run_on_samples, st.rna_mde_fit, **kwargs)

    def run_rna_integrate(self, method = 'harmony', dest = 'harmony', **kwargs):
        """
        Batch-correct the RNA embedding after integration.

        Applies a batch-correction algorithm to the principal-component (or
        other) embedding stored in the merged mudata object. The corrected
        coordinates can then be used for KNN graph construction.

        Parameters
        ----------
        method : str, default 'harmony'
            Correction algorithm. Supported: ``'harmony'``, ``'scanorama'``.
        dest : str, default 'harmony'
            ``adata.obsm`` key to store the corrected embedding.
        **kwargs
            Additional keyword arguments forwarded to the chosen integration
            function (e.g. ``key`` to override the default batch obs column).
        """
        
        self.check_merged('rna')
        if method == 'harmony':
            from exprmat.preprocessing.integrate import harmony
            harmony(self.mudata['rna'], key = 'batch', adjusted_basis = dest, **kwargs)
        
        elif method == 'scanorama':
            from exprmat.preprocessing.integrate import scanorama
            scanorama(self.mudata['rna'], key = 'batch', adjusted_basis = dest, **kwargs)

        else: error(f'unsupported integration method `{method}`.')

    def run_rna_markers(self, run_on_samples = False, **kwargs):
        """
        Find per-cluster marker genes using statistical testing.

        Runs Wilcoxon rank-sum or t-test across cell groups and stores
        ranked gene lists in ``adata.uns[key_added]``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        groupby : str
            ``adata.obs`` column defining groups to compare (e.g. ``'leiden'``).
        groups : list[str] | 'all', default 'all'
            Groups to include. ``'all'`` tests every category in ``groupby``.
        reference : str, default 'rest'
            Reference group. ``'rest'`` compares each group against all others.
        n_genes : int | None, default None
            Number of top genes to return per group. ``None`` returns all.
        rankby_abs : bool, default False
            Rank by the absolute value of the score.
        pts : bool, default True
            Compute the fraction of cells expressing each gene (pct).
        key_added : str, default 'markers'
            ``adata.uns`` key to store the result.
        method : str, default 't-test'
            Statistical test. Options: ``'t-test'``, ``'t-test_overestim_var'``,
            ``'wilcoxon'``, ``'logreg'``.
        corr_method : str, default 'benjamini-hochberg'
            Multiple-testing correction method.
        tie_correct : bool, default False
            Apply tie correction for the Wilcoxon test.
        layer : str, default 'X'
            Layer to use for differential testing.
        gene_symbol : str, default 'gene'
            ``adata.var`` column containing human-readable gene symbols.
        """
        self.do_for_rna(run_on_samples, st.rna_markers, **kwargs)

    def run_rna_markers_deseq(self, run_on_samples = False, **kwargs):
        """
        Find differential genes using pseudo-bulk DESeq2 analysis.

        Aggregates cells to pseudo-bulk samples, then runs DESeq2-style negative
        binomial testing between two experimental conditions. Suitable for
        multi-sample designs where biological replicates exist.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        counts : str, default 'counts'
            Layer containing raw integer counts.
        metadata : list[str], default ['sample', 'group']
            ``adata.obs`` columns to include in the DESeq2 design.
        formula : str, default '~ group'
            R-style model formula for DESeq2.
        variable : str, default 'group'
            Factor in ``metadata`` whose contrast is tested.
        experiment : str, default '.'
            Level of ``variable`` corresponding to the experimental condition.
        control : str, default '.'
            Level of ``variable`` corresponding to the reference condition.
        statistics_params : dict, default {'quiet': True}
            Additional arguments forwarded to DESeq2 statistics step.
        key_added : str, default 'markers'
            ``adata.uns`` key to store the result.
        """
        self.do_for_rna(run_on_samples, st.rna_markers_deseq, **kwargs)

    def run_rna_kde(self, run_on_samples = False, **kwargs):
        """
        Compute kernel density estimates over a 2-D embedding.

        Estimates the spatial density of cells in the chosen embedding
        (e.g. UMAP) and stores the density values in ``adata.obs``.
        Useful for highlighting enriched regions of cell state space.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        groupby : str
            ``adata.obs`` column whose categories define the density groups.
        basis : str, default 'umap'
            ``adata.obsm`` key of the 2-D embedding to evaluate density on.
        key_added : str, default 'kde'
            Prefix for the density columns written into ``adata.obs``.
        bw_method : str | float, default 'scott'
            Bandwidth estimation method passed to
            ``scipy.stats.gaussian_kde``.
        """
        self.do_for_rna(run_on_samples, st.rna_kde, **kwargs)

    def run_rna_proportion(self, run_on_samples = False, **kwargs):
        '''
        This is a simplified method of cell type proportion calculation.
        It is implemented in earlier versions of the package and can be replaced by a more
        general version of counting summary. This returns a simple dataframe, while summary
        returns an annotated object and can be further processed using routines under
        ``exprmat.clustering.summary`` package.
        '''
        return self.do_for_rna(run_on_samples, st.rna_proportion, **kwargs)
    
    def run_rna_infercnv(self, run_on_samples = False, **kwargs):
        """
        Infer copy-number variation (CNV) events from RNA expression.

        Compares expression profiles of putative tumour cells against a normal
        reference to estimate genomic amplifications and deletions. Results are
        stored in ``adata.obsm[key_added]`` (per-cell smoothed CNV matrix) and
        ``adata.uns[key_added]`` (chromosomal position information). If
        per-gene CNV is requested it is stored in ``adata.layers[key_added]``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        key_added : str, default 'cnv'
            Key prefix for all stored results.
        reference : str | list[str]
            Category or categories in ``groupby`` that act as normal
            reference cells (e.g. ``'T'``).
        groupby : str, default 'leiden'
            ``adata.obs`` column that labels cell types / clusters.
        lognorm : str, default 'X'
            Layer of log-normalized expression to use.
        n_genes_chr : int, default 10
            Sliding-window half-width in genes along each chromosome.
        quantile : float, default 0.99
            Upper quantile clipping cutoff for CNV smoothing.
        noise : float, default 0.1
            Noise floor subtracted before normalization.
        gene : str, default 'gene'
            ``adata.var`` column with gene symbols.
        per_gene : bool, default False
            When ``True``, also store per-gene CNV values in a layer.
        """
        self.do_for_rna(run_on_samples, st.rna_infercnv, **kwargs)
    
    def run_rna_summary(self, run_on_samples = False, **kwargs):
        """
        Summarize expression aggregates per observation or variable group.

        Computes a summary statistic (count, mean, fraction, etc.) over a
        chosen layer, optionally stratified by two metadata axes. Returns an
        AnnData-like object with the summary values.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        data : str, default 'X'
            Layer to summarize.
        method : str, default 'n'
            Aggregation method: ``'n'`` (count), ``'mean'``, ``'fraction'``,
            ``'sum'``, ``'median'``.
        method_args : dict, default {}
            Additional arguments for the aggregation method.
        orient : str, default 'obs'
            Axis over which each statistic is computed (``'obs'`` or ``'var'``).
        on : str, default 'sample'
            Primary grouping column in ``adata.obs``.
        across : str | None, default None
            Secondary grouping column.
        split : str | None, default None
            Column used to further split rows in the result.
        attached_metadata_on : str | None, default None
            Extra metadata column to attach on the primary axis.
        attached_metadata_across : str | None, default None
            Extra metadata column to attach on the secondary axis.
        attach_method_on : str, default 'first'
            How to collapse multiple metadata values on the primary axis.
        attach_method_across : str, default 'first'
            How to collapse multiple metadata values on the secondary axis.
        """
        return self.do_for_rna(run_on_samples, st.rna_summary, **kwargs)
    
    def run_rna_aggregate(self, run_on_samples = False, **kwargs):
        """
        Aggregate expression across cells grouped by metadata columns.

        Produces a gene × group matrix by computing a statistic (mean, sum, etc.)
        within each combination of ``obs_key`` and optional ``var_key`` groups.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        data : str, default 'X'
            Layer to aggregate.
        method : str, default 'mean'
            Aggregation method: ``'mean'``, ``'sum'``, ``'median'``, etc.
        method_args : dict, default {}
            Additional arguments for the aggregation method.
        obs_key : str, default 'sample'
            ``adata.obs`` column defining cell groups.
        var_key : str | None, default None
            ``adata.var`` column for gene-level grouping. ``None`` keeps all
            genes separate.
        """
        return self.do_for_rna(run_on_samples, st.rna_aggregate, **kwargs)
    
    def run_rna_attach_tcr(self, run_on_samples = False):
        """
        Attach 10x TCR clonotype data to the RNA object.

        Reads all ``*.tsv`` / ``*.tsv.gz`` files from the ``tcr/``
        subdirectory under the experiment dump folder and maps clone IDs,
        alpha-chain, and beta-chain sequences onto ``adata.obs``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        """
        self.do_for_rna(
            run_on_samples, 
            st.rna_attach_tcr, 
            searchdir = os.path.join(self.directory, 'tcr')
        )

    def run_rna_calculate_tcr_metrics(self, run_on_samples = False, **kwargs):
        """
        Compute T-cell receptor (TCR) clonotype expansion metrics.

        Adds per-cell clone-size and expansion status columns to ``adata.obs``
        based on the clone IDs obtained after :meth:`run_rna_attach_tcr`.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        expanded_clone : int, default 2
            Minimum clone size to be classified as expanded.
        size_stat : str, default 'clone.id'
            ``adata.obs`` column containing clone identifiers for size
            counting.
        alpha : str, default 'tra'
            ``adata.obs`` column storing the TCR alpha-chain sequence.
        beta : str, default 'trb'
            ``adata.obs`` column storing the TCR beta-chain sequence.
        both : str, default 'trab'
            Destination column flagging cells with both alpha and beta chains.
        prefix : str, default 'tcr.'
            Prefix added to all new ``adata.obs`` metric columns.
        """
        self.do_for_rna(run_on_samples, st.rna_calculate_tcr_metrics, **kwargs)

    def run_rna_calculate_bcr_metrics(self, run_on_samples = False, **kwargs):
        """
        Compute B-cell receptor (BCR) clonotype expansion metrics.

        Analogous to :meth:`run_rna_calculate_tcr_metrics` but operates on BCR
        heavy-chain and light-chain sequences.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        expanded_clone : int, default 2
            Minimum clone size to be classified as expanded.
        size_stat : str, default 'clone.id'
            ``adata.obs`` column containing clone identifiers.
        alpha : str, default 'igh'
            ``adata.obs`` column for the heavy chain.
        beta : str, default 'iglt'
            ``adata.obs`` column for the light chain.
        both : str, default 'ighl'
            Destination column flagging cells with both heavy and light chains.
        prefix : str, default 'bcr.'
            Prefix added to all new ``adata.obs`` metric columns.
        """
        self.do_for_rna(run_on_samples, st.rna_calculate_bcr_metrics, **kwargs)
    
    def run_rna_aggregate_clone_by_identity(self, run_on_samples = False, **kwargs):
        """
        Re-label clone IDs to be unique per donor / patient identity.

        Disambiguates clones that share a numeric ID across patients by
        prepending the patient identifier. Result is stored in
        ``adata.obs['clone.id.<identity>']``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        identity : str, default 'patient'
            ``adata.obs`` column representing donor / patient identity.
        """
        self.do_for_rna(run_on_samples, st.rna_aggregate_clone_by_identity, **kwargs)
    
    def run_rna_calculate_startracs_metrics(self, run_on_samples = False, **kwargs):
        """
        Compute STARTRAC clonotype dynamics metrics.

        Calculates within-cluster expansion, inter-cluster plasticity,
        cluster-to-cluster transition, and (optionally) tissue-migration
        scores following the STARTRAC framework.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        clonotype : str, default 'clone.id'
            ``adata.obs`` column identifying clonotypes.
        cluster : str, default 'leiden'
            ``adata.obs`` column identifying cell clusters.
        tissue : str | None, default None
            ``adata.obs`` column for tissue / sample origin. When provided,
            migration scores are also computed.
        """
        self.do_for_rna(run_on_samples, st.rna_calculate_startracs_metrics, **kwargs)
    
    def run_rna_calculate_startracs_pairwise_metrics(self, run_on_samples = False, **kwargs):
        """
        Compute pairwise STARTRAC transition probabilities between clusters.

        Extends the STARTRAC framework to calculate clonal transition
        frequencies between every pair of cluster categories.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        base : str
            Source cluster category for pairwise transition.
        clonotype : str, default 'clone.id'
            ``adata.obs`` column identifying clonotypes.
        cluster : str, default 'leiden'
            ``adata.obs`` column identifying cell clusters.
        key_added : str, default 'tcr.cluster.ptrans'
            ``adata.uns`` key to store the pairwise transition matrix.
        """
        self.do_for_rna(run_on_samples, st.rna_calculate_startracs_pairwise_metrics, **kwargs)
    
    def run_rna_expression_mask(
        self, run_on_samples = False, gene = None, key = 'mask', 
        lognorm = 'X', threshold = 0.1, negate = False
    ):
        """
        Create a boolean mask based on the expression level of a single gene.

        Compares per-cell expression of ``gene`` against ``threshold`` and
        stores the result in ``adata.obs[key]``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        gene : str
            Gene identifier (ugene format ``'rna:<taxa>:<gene_id>'``).
        key : str, default 'mask'
            ``adata.obs`` column to store the boolean mask.
        lognorm : str, default 'X'
            Layer containing expression values to threshold.
        threshold : float, default 0.1
            Expression threshold.
        negate : bool, default False
            When ``True``, stores the negated mask (``expression < threshold``).
        """
        self.do_for_rna(
            run_on_samples, st.rna_expression_mask, 
            gene = gene, key = key, lognorm = lognorm, threshold = threshold,
            negate = negate
        )
    
    def run_rna_gsea(self, run_on_samples = False, **kwargs):
        """
        Run Gene Set Enrichment Analysis (GSEA) on differential expression results.

        Pre-ranks genes by log-fold change and runs GSEA pre-rank against the
        specified gene sets. Results are stored in ``adata.uns[key_added]``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        taxa : str
            Species identifier (e.g. ``'hsa'``, ``'mmu'``).
        de_slot : str
            ``adata.uns`` key of the differential expression result or a
            pre-computed ranked DataFrame with columns ``names`` and ``lfc``.
        group_name : str | None, default None
            Group name within the DE result to use. Required when ``de_slot``
            contains multiple groups.
        min_pct : float, default 0.0
            Minimum percent cells expressing the gene in the test group.
        max_pct_reference : float, default 1
            Maximum percent cells expressing the gene in the reference group.
        min_lfc : float | None, default None
            Minimum log-fold change filter.
        max_lfc : float | None, default None
            Maximum log-fold change filter.
        remove_zero_pval : bool, default False
            Remove genes with exactly zero p-value from the ranked list.
        max_q : float, default 0.05
            Maximum adjusted p-value (FDR) to include in the ranked list.
        key_added : str, default 'gsea'
            ``adata.uns`` key to store GSEA output.
        gene_sets : str | list, default 'all'
            Gene set collection name(s) from ``exprmat.data.geneset``.
        identifier : str, default 'entrez'
            Gene identifier type used by the gene sets (``'entrez'``,
            ``'uppercase'``, etc.).
        """
        self.do_for_rna(run_on_samples, st.rna_gsea, **kwargs)
    
    def run_rna_opa(self, run_on_samples = False, **kwargs):
        """
        Run Over-Representation Analysis (ORA / OPA) on differential expression results.

        Tests whether a set of up- or down-regulated genes is over-represented
        in curated gene sets using a hypergeometric / Fisher's exact test.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        taxa : str
            Species identifier (e.g. ``'hsa'``, ``'mmu'``).
        de_slot : str
            ``adata.uns`` key of the differential expression result.
        group_name : str | None, default None
            Group within the DE result to use.
        min_pct : float, default 0.0
            Minimum percent cells expressing the gene.
        max_pct_reference : float, default 1
            Maximum percent cells in the reference group.
        min_lfc : float | None, default None
            Minimum log-fold change.
        max_lfc : float | None, default None
            Maximum log-fold change.
        use_abs_lfc : bool, default False
            Use absolute LFC when applying ``min_abs_lfc`` / ``max_abs_lfc``.
        min_abs_lfc : float, default 1.0
            Minimum absolute LFC (only used when ``use_abs_lfc=True``).
        max_abs_lfc : float, default 25.0
            Maximum absolute LFC (only used when ``use_abs_lfc=True``).
        remove_zero_pval : bool, default False
            Remove genes with exactly zero p-value.
        max_q : float, default 0.05
            Maximum adjusted p-value for DE genes included in the test.
        key_added : str, default 'gsea'
            ``adata.uns`` key to store OPA results.
        gene_sets : str | list, default 'all'
            Gene set collection name(s).
        identifier : str, default 'entrez'
            Gene identifier type.
        opa_cutoff : float, default 0.05
            FDR cutoff for reporting enriched gene sets.
        """
        self.do_for_rna(run_on_samples, st.rna_opa, **kwargs)
    
    def run_rna_gsva(self, run_on_samples = False, key_added = 'gsva', **kwargs):
        """
        Run Gene Set Variation Analysis (GSVA) to score gene-set activity per cell.

        Computes a signed enrichment score for each gene set in each cell and,
        when operating on the merged object, registers the result as a new
        modality ``key_added`` in the mudata.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        key_added : str, default 'gsva'
            Modality key used when adding GSVA scores to the mudata object.
        taxa : str
            Species identifier (e.g. ``'hsa'``, ``'mmu'``).
        identifier : str, default 'uppercase'
            Gene identifier type matching the gene set annotation.
        gene_sets : str | list, default 'kegg'
            Gene set collection name(s).
        lognorm : str, default 'X'
            Layer of log-normalized expression values.
        n_cores : int, default 1
            Number of CPU cores for GSVA computation.
        kcdf : str, default 'Gaussian'
            Kernel for continuous data (``'Gaussian'``) or count data
            (``'Poisson'``).
        weight : float, default 1
            Exponent weight on gene ranks.
        min_genes : int, default 15
            Minimum gene set size to include.
        max_genes : int, default 1000
            Maximum gene set size to include.
        """
        gsv = self.do_for_rna(run_on_samples, st.rna_gsva, **kwargs)
        if not run_on_samples:
            gsv.var['gset'] = gsv.var_names.tolist()
            gsv.var_names = [key_added + ':' + str(i + 1) for i in range(gsv.n_vars)]
            self.mudata.mod[key_added] = gsv
        return gsv
    
    def run_rna_remove_slots(self, run_on_samples = False, slot = 'obs', names = []):
        """
        Delete named entries from a specified AnnData slot.

        Removes one or more named columns / keys from ``obs``, ``var``,
        ``obsm``, ``varm``, ``obsp``, ``varp``, ``layers``, or ``uns``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        slot : str, default 'obs'
            AnnData slot from which to remove entries. Must be one of
            ``'obs'``, ``'var'``, ``'obsm'``, ``'varm'``, ``'obsp'``,
            ``'varp'``, ``'layers'``, ``'uns'``.
        names : list[str], default []
            Names of entries to remove from the specified slot.
        """
        self.do_for_rna(run_on_samples, st.remove_slot, slot = slot, names = names)
    
    def run_rna_ligand_receptor(self, run_on_samples = False, **kwargs):
        """
        Infer ligand-receptor interactions using multi-cellular communication methods.

        Supports multiple LR inference flavors (e.g. rank-aggregate, LIANA)
        via the ``flavor`` parameter. Results are stored in ``adata.uns[key_added]``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        flavor : str, default 'ra'
            LR inference method. See ``exprmat.lr.flavors`` for supported options.
        taxa_source : str, default 'hsa'
            Species of the source (sender) cell.
        taxa_dest : str, default 'hsa'
            Species of the destination (receiver) cell.
        gene_symbol : str | None, default None
            ``adata.var`` column with gene symbols. If ``None``, the internal
            ``gene`` column is used.
        groupby : str, default 'cell.type'
            ``adata.obs`` column defining cell populations.
        use_raw : bool, default False
            Use ``adata.raw`` for expression values.
        min_cells : int, default 5
            Minimum cells per group to include a group in the analysis.
        expr_prop : float, default 0.1
            Minimum proportion of cells expressing a gene to consider it.
        n_perms : int, default 500
            Number of permutations for p-value estimation.
        seed : int, default 42
            Random seed.
        de_method : str, default 't-test'
            Differential expression method for LR scoring.
        resource_name : str, default 'consensus'
            LR resource database name.
        verbose : bool, default True
            Print progress information.
        key_added : str, default 'lr'
            ``adata.uns`` key to store results.
        n_jobs : int, default 20
            Number of parallel jobs.
        """
        self.do_for_rna(run_on_samples, st.rna_ligand_receptor, **kwargs)
    
    def run_rna_score_genes(self, run_on_samples = False, **kwargs):
        """
        Score cells against curated gene sets using the scanpy scoring method.

        Computes the average expression of each gene set minus a baseline of
        randomly sampled reference genes. Scores are stored in
        ``adata.obs['score.<gene_set_name>']``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        taxa : str
            Species identifier (e.g. ``'hsa'``, ``'mmu'``).
        gene_sets : str | dict
            Gene set collection name or a mapping of set names to gene lists.
        identifier : str, default 'uppercase'
            Gene identifier type used in the gene sets.
        lognorm : str, default 'X'
            Layer containing log-normalized expression values.
        random_state : int, default 42
            Random seed for reference gene sampling.
        """
        return self.do_for_rna(run_on_samples, st.rna_score_genes, **kwargs)
    
    def run_rna_score_genes_gsva(self, run_on_samples = False, key_added = 'gsva.scores', **kwargs):
        """
        Score cells per gene set using the GSVA method.

        Computes per-cell GSVA enrichment scores for each gene set and stores
        them in ``adata.obs['nes.<gene_set_name>']`` (when
        ``append_to_obs=True``) or returns / registers a full score AnnData.        

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        key_added : str, default 'gsva.scores'
            Modality key when adding the score matrix to the mudata.
        taxa : str
            Species identifier.
        gene_sets : str | dict
            Gene set collection name or a mapping of set names to gene lists.
        identifier : str, default 'uppercase'
            Gene identifier type.
        lognorm : str, default 'X'
            Layer of expression values.
        n_cores : int, default 1
            CPU cores for GSVA computation.
        kcdf : str, default 'Gaussian'
            Kernel for the GSVA density estimator.
        weight : float, default 1
            Exponent weight on gene rank.
        min_genes : int, default 15
            Minimum gene set size.
        max_genes : int, default 1000
            Maximum gene set size.
        append_to_obs : bool, default False
            When ``True``, writes scores as ``adata.obs`` columns instead of
            returning an AnnData matrix.
        """
        gsv = self.do_for_rna(run_on_samples, st.rna_score_genes_gsva, **kwargs)
        if not run_on_samples:
            gsv.var['gset'] = gsv.var_names.tolist()
            gsv.var_names = [key_added + ':' + str(i + 1) for i in range(gsv.n_vars)]
            self.mudata.mod[key_added] = gsv
        return gsv
    
    def run_rna_velocity(self, run_on_samples = False, **kwargs):
        """
        Infer RNA velocity and compute velocity-directed pseudotime.

        Fits spliced / unspliced count dynamics using scVelo, constructs a
        velocity graph, and estimates terminal states. Requires spliced and
        unspliced count layers obtained during data loading (``rna.splicing``).

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        neighbor_key : str, default 'neighbors'
            ``adata.uns`` key of the cell neighbor graph.
        neighbor_connectivity : str, default 'connectivities'
            ``adata.obsp`` key within the neighbor result.
        n_neighbors : int, default 35
            Number of neighbors used to build the velocity graph.
        hvg : str, default 'vst.norm'
            ``adata.var`` column flagging genes used for velocity fitting.
        velocity_key : str, default 'velocity'
            ``adata.layers`` key to store computed velocities.
        n_cpus : int | None, default None
            CPU count for parallel velocity computation.
        kwargs_filter : dict, default {}
            Extra arguments for :func:`scvelo.pp.filter_and_normalize`.
        kwargs_velocity : dict, default {}
            Extra arguments for :func:`scvelo.tl.velocity`.
        kwargs_velocity_graph : dict, default {}
            Extra arguments for :func:`scvelo.tl.velocity_graph`.
        kwargs_terminal_state : dict, default {}
            Extra arguments for terminal state estimation.
        kwargs_pseudotime : dict, default {'save_diffmap': True}
            Extra arguments for velocity pseudotime computation.
        """
        self.do_for_rna(run_on_samples, st.rna_velocity, **kwargs)
    
    def run_rna_consensus_nmf(self, run_on_samples = False, **kwargs):
        """
        Run consensus Non-Negative Matrix Factorization (cNMF) stability analysis.

        Runs NMF multiple times with random initialisations for each tested rank
        ``k`` and computes density-based silhouette scores to identify the most
        stable factorization. Results are stored in
        ``adata.uns[key_added]`` (per-k component matrices) and
        ``adata.uns[key_added + '.stats']`` (stability statistics). Use
        :meth:`run_rna_consensus_nmf_extract_k` to extract the final solution
        for a chosen ``k``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        ks : list[int]
            Range of ranks to test (e.g. ``[4, 5, 6, 7, 8]``).
        counts : str, default 'counts'
            Layer of raw integer counts.
        tpm : str, default 'norm'
            Layer of library-size-normalized counts (TPM-like).
        hvg : str, default 'vst.hvg'
            ``adata.var`` column flagging highly variable genes.
        min_counts : int, default 3
            Minimum per-gene count threshold.
        alpha_usage : float, default 0
            Regularization weight on the usage (H) matrix.
        alpha_spectra : float, default 0
            Regularization weight on the spectra (W) matrix.
        init : str, default 'random'
            NMF initialization strategy.
        max_nmf_iter : int, default 1000
            Maximum NMF iterations per run.
        n_permutation : int, default 100
            Number of random permutation runs per rank.
        seed : int, default 42
            Global random seed.
        beta_loss : str, default 'frobenius'
            Beta-divergence loss function (``'frobenius'``, ``'kullback-leibler'``).
        density_threshold : float, default 0.5
            Stability density threshold for consensus component selection.
        local_neighborhood_size : float, default 0.3
            Neighborhood fraction used for local density computation.
        refit : bool, default True
            Refit a final NMF model from the consensus.
        normalize_tpm_spectra : bool, default False
            Normalize TPM spectra to unit sum.
        key_added : str, default 'cnmf'
            ``adata.uns`` prefix for stored results.
        ncpus : int, default 1
            Number of CPU cores for parallel NMF runs.
        """
        self.do_for_rna(run_on_samples, st.rna_consensus_nmf, **kwargs)
    
    def run_rna_consensus_nmf_extract_k(self, run_on_samples = False, **kwargs):
        """
        Extract the cNMF solution for a chosen rank ``k``.

        Retrieves pre-computed consensus NMF results for the specified number
        of components and stores the usage matrix, spectra, and density
        information in dedicated ``obsm`` / ``varm`` / ``uns`` slots.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        k : int
            Number of NMF components to extract.
        nmf_slot : str, default 'cnmf'
            ``adata.uns`` key containing the cNMF run results.
        usage_added : str, default 'cnmf.{0}'
            ``adata.obsm`` key template (formatted with ``k``) for the cell
            usage matrix.
        spectra_added : str, default 'cnmf.{0}'
            ``adata.varm`` key template for the gene spectra.
        coef_added : str, default 'cnmf.coef.{0}'
            ``adata.varm`` key template for usage coefficients.
        spectra_cluster_dist_added : str, default 'cnmf.dist.{0}'
            ``adata.uns`` key for per-cluster spectra distances.
        density_added : str, default 'cnmf.density.{0}'
            ``adata.uns`` key for local density scores.
        """
        self.do_for_rna(run_on_samples, st.rna_consensus_nmf_extract_k, **kwargs)
    
    def run_rna_impute_magic(self, run_on_samples = False, **kwargs):
        """
        Denoise and impute RNA data using MAGIC.

        Markov Affinity-based Graph Imputation of Cells (MAGIC) smooths the
        expression matrix by diffusing information through a cell-similarity
        graph. The imputed matrix is stored in ``adata.layers[key_added]``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        key_added : str, default 'magic'
            Layer key for the imputed expression matrix.
        solver : str, default 'approximate'
            MAGIC solver: ``'approximate'`` (faster) or ``'exact'``.
        t : int | 'auto', default 'auto'
            Diffusion time steps. ``'auto'`` selects the optimal value.
        random_state : int, default 42
            Random seed.
        n_jobs : int, default 1
            Number of parallel jobs.
        n_pca : int, default 30
            Number of PCA components used for the affinity graph.
        knn : int, default 15
            Number of neighbors for the affinity graph.
        """
        self.do_for_rna(run_on_samples, st.rna_impute_magic, **kwargs) 

    def run_rna_layout_graph(self, run_on_samples = False, **kwargs):
        """
        Compute a force-directed graph layout (ForceAtlas2 / FA / FR*).

        Applies a spring-force graph layout algorithm to the cell neighbor
        graph and stores 2-D coordinates in ``adata.obsm``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        layout : str, default 'fa'
            Graph layout algorithm. Options: ``'fa'`` (ForceAtlas2),
            ``'fr'`` (Fruchterman-Reingold), ``'drl'``, ``'kk'``, etc.
        init_pos : str | bool | None, default None
            Initial node positions. ``None`` uses a random initialization.
        root : int | None, default None
            Root node index for rooted layouts.
        random_state : int, default 0
            Random seed.
        adjacency : scipy sparse | None, default None
            Custom adjacency matrix; defaults to neighbor connectivities.
        key_added_ext : str | None, default None
            Suffix appended to the default ``'X_draw_graph_<layout>'`` key.
        neighbors_key : str | None, default None
            ``adata.uns`` key of the neighbor graph.
        use_gpu : bool, default False
            Use RAPIDS GPU acceleration.
        """
        self.do_for_rna(run_on_samples, st.rna_layout_graph, **kwargs) 

    def run_rna_principle_tree(self, run_on_samples = False, **kwargs):
        """
        Fit a principal tree (trajectory skeleton) to the cell manifold.

        Supports both the Principal Polynomial Tree (PPT) and Elastic Principal
        Graph (EPG / ElPiGraph) methods, providing a topological skeleton of
        the differentiation landscape.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        use_rep : str, default 'umap'
            ``adata.obsm`` key of the embedding to fit.
        ndims_rep : int | None, default None
            Number of dimensions of ``use_rep`` to use.
        method : str, default 'ppt'
            Fitting algorithm: ``'ppt'`` or ``'epg'``.
        ppt_sigma : float, default 0.1
            PPT bandwidth.
        ppt_lambda : float, default 1
            PPT regularization strength.
        ppt_metric : str, default 'euclidean'
            Distance metric for PPT.
        ppt_nsteps : int, default 50
            Maximum PPT optimization steps.
        epg_lambda : float, default 0.01
            EPG length regularization.
        epg_mu : float, default 0.1
            EPG harmonic regularization.
        epg_trimmingradius : float, default inf
            Radius for outlier trimming in EPG.
        epg_initnodes : int, default 2
            Initial number of EPG nodes.
        device : str, default 'cpu'
            Computation device for EPG.
        seed : int, default 42
            Random seed.
        key_added : str, default 'ppt'
            ``adata.uns`` / ``adata.obsm`` key prefix for trajectory results.
        """
        self.do_for_rna(run_on_samples, st.rna_principle_tree, **kwargs) 

    def run_rna_principle_tree_explore_sigma(self, run_on_samples = False, **kwargs):
        """
        Explore the effect of the PPT sigma bandwidth parameter.

        Fits principal trees across a grid of ``sigma`` values and displays
        the resulting topologies for manual selection of the optimal sigma.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        nodes : int, default 200
            Number of principal tree nodes.
        use_rep : str, default 'umap'
            ``adata.obsm`` key of the embedding.
        ndims_rep : int | None, default None
            Number of dimensions to use.
        sigmas : list[float], default [1000, 100, 10, 1, 0.1, 0.01]
            Sigma values to explore.
        nsteps : int, default 1
            Optimization steps per sigma evaluation.
        metric : str, default 'euclidean'
            Distance metric.
        seed : int | None, default None
            Random seed.
        key_added : str, default 'ppt'
            Storage key prefix.
        """
        self.do_for_rna(run_on_samples, st.rna_principle_tree_explore_sigma, **kwargs)

    def run_rna_principle_tree_root(self, run_on_samples = False, **kwargs):
        """
        Define the root node of the principal tree and compute pseudotime.

        Sets the root milestone based on the provided ``root`` value and
        optionally restricts the root search to tip/fork nodes only.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        root : int | str
            Node ID or metadata value identifying the root.
        tips_only : bool, default False
            Restrict candidate roots to tip nodes.
        min_val : bool, default False
            Select root as the node with the minimum metadata value.
        trajectory_key : str, default 'ppt'
            ``adata.uns`` key of the trajectory to root.
        """
        self.do_for_rna(run_on_samples, st.rna_principle_tree_root, **kwargs)

    def run_rna_principle_tree_pseudotime(self, run_on_samples = False, **kwargs):
        """
        Project cells onto the principal tree to compute pseudotime.

        Assigns each cell its position along the principal tree branches and
        stores pseudotime values in ``adata.obs``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        n_jobs : int, default 1
            Number of parallel jobs.
        n_map : int, default 1
            Number of stochastic cell projections to average over.
        seed : int | None, default 42
            Random seed.
        trajectory_key : str, default 'ppt'
            ``adata.uns`` key of the principal tree.
        """
        self.do_for_rna(run_on_samples, st.rna_principle_tree_pseudotime, **kwargs)

    def run_rna_principle_tree_rename_milestones(self, run_on_samples = False, **kwargs):
        """
        Assign human-readable names to principal tree milestones.

        Maps node IDs (integers) to biological labels stored in
        ``adata.uns[trajectory_key + '.graph']['milestone_names']``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        rename : dict, default {}
            Mapping of node IDs (int or str) to label strings.
        trajectory_key : str, default 'ppt'
            ``adata.uns`` key of the trajectory.
        """
        self.do_for_rna(run_on_samples, st.rna_principle_tree_rename_milestones, **kwargs)

    def run_rna_principle_tree_trace(self, run_on_samples = False, **kwargs):
        """
        Trace a trajectory segment between two milestones.

        Extracts the branch connecting a pair of milestones and records
        ordered cell assignments along the path.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        destination : int | str
            Milestone node ID (or name) identifying the end of the trajectory
            segment to trace.
        source : int | str | None, default None
            Milestone node ID for the start. ``None`` uses the root.
        trajectory_key : str, default 'ppt'
            ``adata.uns`` key of the principal tree.
        lognorm : str, default 'X'
            Layer of expression values for gene dynamics fitting.
        binning : int, default 100
            Number of pseudotime bins for expression smoothing.
        statistic : str, default 'mean'
            Aggregation applied within each bin (``'mean'``, ``'median'``).
        skip_sparsity : int, default 40
            Skip segments with fewer than this many unique pseudotime values.
        order : int, default 4
            Polynomial order for the regression smoother.
        key_added : str, default 'trace'
            ``adata.uns`` key to store the trajectory trace result.
        """
        self.do_for_rna(run_on_samples, st.rna_principle_tree_trace, **kwargs)

    def run_rna_principle_tree_trace_pseudotime(self, run_on_samples = False, **kwargs):
        """
        Extract pseudotime values along a traced trajectory segment.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        destination : int | str
            Milestone node ID (or name) for the end of the trajectory.
        source : int | str | None, default None
            Milestone node ID for the start. ``None`` uses the root.
        trajectory_key : str, default 'ppt'
            ``adata.uns`` key of the principal tree.
        additional : list[str] | None, default None
            Extra ``adata.obs`` columns to include in the returned DataFrame.
        """
        return self.do_for_rna(run_on_samples, st.rna_principle_tree_trace_pseudotime, **kwargs)

    def run_rna_principle_tree_trace_values(self, run_on_samples = False, **kwargs):
        """
        Retrieve expression or metadata values along a trajectory segment.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        feature : str
            Gene name or ``adata.obs`` column to extract values from.
        destination : int | str
            Milestone node ID (or name) for the end of the trajectory.
        source : int | str | None, default None
            Milestone node ID for the start. ``None`` uses the root.
        trajectory_key : str, default 'ppt'
            ``adata.uns`` key of the principal tree.
        lognorm : str, default 'X'
            Layer to retrieve expression from.
        """
        return self.do_for_rna(run_on_samples, st.rna_principle_tree_trace_values, **kwargs)

    def run_rna_cytotrace(self, run_on_samples = False, **kwargs):
        """
        Estimate developmental potential using CytoTRACE2.

        Predicts differentiation state for each cell based on the diversity
        of expressed genes. Outputs are stored back into ``adata.obs``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        key_counts : str, default 'counts'
            Layer of raw integer counts used by the CytoTRACE2 model.
        key_gene : str, default 'gene'
            ``adata.var`` column with gene symbols.
        taxa : str, default 'mmu'
            Species identifier used to load the pretrained model weights.
        batch_size : int, default 20000
            Number of cells processed in each prediction chunk.
        smooth_batch_size : int, default 1000
            Cells per smoothing sub-chunk.
        disable_parallelization : bool, default False
            Run single-threaded even when multiple cores are available.
        max_cores : int, default 4
            Maximum CPU cores to use for parallel prediction and smoothing.
        seed : int, default 42
            Random seed.
        device : str, default 'cpu'
            Torch device for model inference: ``'cpu'`` or ``'cuda'``.
        """
        self.do_for_rna(run_on_samples, st.rna_cytotrace, **kwargs)

    def run_rna_metacell(self, run_on_samples = False, **kwargs):
        """
        Construct metacells by pooling similar cells.

        Assigns cells to metacells to reduce noise and data size, then
        aggregates expression into a compact metacell AnnData. The metacell
        object is added to ``modalities['rna']`` with a ``'-metacell'`` sample
        suffix.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        hvg_key : str, default 'vst.hvg'
            ``adata.var`` column flagging HVGs used for metacell construction.
        counts_key : str, default 'counts'
            Layer of raw counts.
        lognorm_key : str, default 'X'
            Layer of log-normalized values.
        datatypes : list[str], default ['rna']
            Modality types to include in the metacell aggregation.
        **kwargs
            Additional arguments forwarded to
            :func:`exprmat.metacell.assign_metacell`.
        """
        mc = self.do_for_rna(run_on_samples, st.rna_metacell, **kwargs)
        
        if isinstance(mc, dict):

            for k in mc.keys():
                rows = self.metadata.dataframe[(
                    (self.metadata.dataframe['sample'] == k) &
                    (self.metadata.dataframe['modality'] == 'rna')
                )]

                assert len(rows) == 1
                props = rows.iloc[0].copy()
                props['sample'] = props['sample'] + '-metacell'
                self.metadata.insert_row(props)
                if not 'rna' in self.modalities.keys(): self.modalities['rna'] = {}
                self.modalities['rna'][props['sample']] = mc[k]
            
        else:
            rows = self.metadata.dataframe[(
                (self.metadata.dataframe['modality'] == 'rna')
            )]
            
            props = rows.iloc[0].copy()
            for c in props.index: props[c] = 'autogen'
            props['sample'] = kwargs.get('key_added', 'metacell')
            props['modality'] = 'rna'
            props['taxa'] = rows['taxa'][0] if len(rows['taxa'].unique()) == 1 else '?'
            self.metadata.insert_row(props)
            if not 'rna' in self.modalities.keys(): self.modalities['rna'] = {}
            self.modalities['rna'][props['sample']] = mc
    
    def run_rna_infer_tf_activity(self, run_on_samples = False, **kwargs):
        """
        Infer transcription factor (TF) activity using SCENIC / pySCENIC.

        Infers a gene regulatory network from expression data, prunes it
        against TF-binding motif evidence, and scores each cell's TF activity
        using the AUCell method. Results are stored in
        ``adata.obsm[key_added]``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        layer : str, default 'counts'
            Layer of count data for GRN inference.
        gene : str, default 'gene'
            ``adata.var`` column with gene symbols.
        method : str, default 'grnboost2'
            GRN inference algorithm: ``'grnboost2'`` or ``'genie3'``.
        taxa : str, default 'hsa'
            Species identifier used to look up TF lists and motif databases.
        ncpus : int, default 1
            CPU cores for GRN inference.
        seed : int, default 42
            Random seed.
        features : str, default 'genes'
            Feature type for SCENIC pruning: ``'genes'`` or ``'regions'``.
        cistromes : str, default 'motifs'
            Cisrome type: ``'motifs'`` or ``'tracks'``.
        thresholds : list[float], default [0.75, 0.90]
            Importance score thresholds for target gene inclusion.
        top_n_targets : list[int], default [50]
            Top-N target gene cutoffs.
        top_n_regulators : list[int], default [5, 10, 50]
            Top-N regulator (TF) cutoffs.
        min_genes : int, default 20
            Minimum regulon size to keep.
        mask_dropout : bool, default True
            Mask dropout events in the AUCell matrix.
        keep_only_activating : bool, default True
            Retain only activating regulons.
        rank_threshold : int, default 5000
            Rank threshold for AUCell scoring.
        auc_threshold : float, default 0.05
            AUC threshold for binarizing regulon activity.
        nes_threshold : float, default 3.0
            NES threshold for motif enrichment.
        max_similarity_fdr : float, default 0.001
            FDR cutoff for cluster similarity in motif enrichment.
        min_orthologous_identity : float, default 0
            Minimum ortholog identity for cross-species motif mapping.
        chunk_size : int, default 100
            Chunk size for AUCell computation.
        weighted : bool, default False
            Use weighted AUC scoring.
        key_adjacencies : str, default 'tf.adjacencies'
            ``adata.uns`` key to cache GRN adjacency table.
        key_added : str, default 'tf'
            ``adata.obsm`` key for the TF activity matrix.
        """
        self.do_for_rna(run_on_samples, st.rna_infer_tf_activity, **kwargs)

    def run_rna_construct_atlas(self, run_on_samples = False, **kwargs):
        """
        Build a reference atlas from the current RNA dataset.

        Stores a compressed reference embedding that can later be used as a
        projection target for new datasets via :meth:`run_rna_project`.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        annotation : str, default 'cell.type'
            ``adata.obs`` column containing cell-type labels to store in the
            atlas reference.
        batch : str, default 'batch'
            ``adata.obs`` column used as the batch key for scVI training.
        counts_key : str, default 'counts'
            Layer of raw counts for scVI / scANVI training.
        hvg : str, default 'vst.hvg'
            ``adata.var`` column flagging highly variable genes.
        embedding : str, default 'umap'
            ``adata.obsm`` key of the reference 2-D layout.
        latent_key : str, default 'scanvi'
            ``adata.obsm`` key of the scANVI latent space.
        scanvi_unlabel : str, default 'unknown'
            Placeholder label used for unlabeled cells in scANVI.
        key_added : str, default 'atlas'
            ``adata.uns`` key where atlas metadata is stored.
        """
        self.do_for_rna(
            run_on_samples, st.rna_construct_atlas, 
            expm_dir = self.directory,
            expm_subset = self.subset,
            **kwargs
        )
    
    def run_rna_project(self, run_on_samples = False, **kwargs):
        """
        Project query cells into a reference atlas embedding.

        Maps cells onto the coordinate system of a pre-built reference atlas.
        Requires a reference atlas constructed by :meth:`run_rna_construct_atlas`.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        atlas_modality : str, default 'rna'
            Modality key of the reference atlas within the atlas experiment.
        atlas_embedding : str, default 'umap'
            ``adata.obsm`` key of the reference 2-D layout.
        counts_key : str, default 'counts'
            Layer of raw counts in the query data.
        batch_key : str, default 'batch'
            ``adata.obs`` column used as the batch key.
        key_query_latent : str, default 'scanvi'
            ``adata.obsm`` key for the scVI / scANVI latent coordinates of the
            query cells.
        scanvi_unlabel : str, default 'unknown'
            Placeholder label for unlabeled query cells in scANVI.
        scvi_epoch_reduction : int, default 3
            Divide reference scVI epoch count by this when fine-tuning on
            query data.
        predict_labels : str, default 'annot'
            ``adata.obs`` key for the transferred label predictions.
        key_added : str, default 'projection'
            ``adata.obsm`` key for the projected 2-D coordinates.
        embed_decay : int, default 30
            Number of neighbours used during embedding projection.
        re_embed : bool, default False
            Re-train the embedding model rather than re-using the reference.
        use_scanvi : bool, default True
            Use scANVI (with label transfer) instead of plain scVI.
        """
        self.do_for_rna(run_on_samples, st.rna_project, **kwargs)
    
    def run_rna_gate_polygon(self, run_on_samples = False, **kwargs):
        """
        Gate cells by a polygon defined in a 2-D gene-expression space.

        For each cell the expression values of two genes are read, optionally
        rescaled, and then tested for containment inside a user-supplied
        polygon.  A boolean ``obs`` column is added so the resulting gate can
        be used to subset, colour, or annotate cells.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        gene_x : str
            Feature name (gene symbol or ENSEMBL ID) placed on the X axis.
        gene_y : str
            Feature name (gene symbol or ENSEMBL ID) placed on the Y axis.
        layer : str, default 'X'
            Layer from which expression values are retrieved.
            ``'X'`` refers to the main matrix.
        remove_zero_expression : bool, default False
            If ``True``, cells with zero expression for either gene are
            excluded before polygon containment is evaluated.
        scale : str, default 'asis'
            Transformation applied to expression values before gating.
            Choices:

            * ``'asis'`` – no transformation.
            * ``'log'`` – ``log1p`` transformation.
            * ``'expm1'`` – inverse of ``log1p`` (i.e. expm1).
            * ``'arcsinh'`` – arcsinh transformation; the cofactor is
              ``median(nonzero) / 20`` unless *arcsinh_divider* is set.
        arcsinh_divider : float | None, default None
            Cofactor for the arcsinh transformation. Ignored unless
            ``scale='arcsinh'``.
        polygon : list[tuple[float, float]], default [(0,0),(1,0),(1,1),(0,1)]
            Ordered list of ``(x, y)`` vertices that define the gate polygon.
            Must form a closed shape (the library closes it automatically).
        key_added : str, default 'gate'
            Name of the boolean ``obs`` column written to the AnnData object.
        """
        self.do_for_rna(run_on_samples, st.rna_gate_polygon, **kwargs)

    def run_rna_nichenet(self, run_on_samples = False, **kwargs):
        """
        Infer upstream ligand activities using NicheNet.

        Scores ligands by their predicted ability to regulate a set of
        differentially expressed target genes in receiver cells.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        taxa : str
            Species identifier for NicheNet model weights (e.g. ``'hsa'``).
        receiver : str | list[str]
            Category or categories in ``identity`` that are the receiver cells.
        sender : str | list[str] | None, default None
            Sender cell categories. ``None`` uses all non-receiver cells as
            potential ligand sources.
        identity : str, default 'cell.type'
            ``adata.obs`` column with cell-type labels.
        foreground : list[str] | None, default None
            Differentially expressed genes in receiver cells that serve as the
            target gene set. Must be provided.
        background : list[str] | None, default None
            Background gene universe. ``None`` uses all expressed genes.
        expression_threshold : float, default 0.001
            Minimum mean expression fraction to consider a gene expressed.
        ncpus : int, default 1
            CPU cores for ligand activity prediction.
        key_added : str, default 'nichenet'
            ``adata.uns`` key to store NicheNet results.
        """
        self.do_for_rna(run_on_samples, st.rna_nichenet, **kwargs)

    def run_rna_nichenet_infer_targets(self, run_on_samples = False, **kwargs):
        """
        Infer ligand-specific target gene predictions using NicheNet.

        Extends NicheNet output by ranking target genes regulated by each
        top-scoring ligand.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        key_nichenet : str, default 'nichenet'
            ``adata.uns`` key of the NicheNet result from
            :meth:`run_rna_nichenet`.
        ligands : int | list[str], default 10
            Top-N ligands (int) or an explicit list of ligand names whose
            targets are to be predicted.
        n_targets : int, default 250
            Maximum number of target genes to report per ligand.
        """
        self.do_for_rna(run_on_samples, st.rna_nichenet_infer_targets, **kwargs)

    def run_rna_soupx(self, run_on_samples = False, **kwargs):
        """
        Remove ambient RNA contamination using SoupX.

        Estimates the ambient RNA profile from empty droplets and removes it
        from the count matrix. Requires the raw (unfiltered) count matrix to
        be stored in ``adata.uns['.raw']``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        raw_key : str, default '.raw'
            ``adata.uns`` key pointing to the raw unfiltered count matrix
            (used to estimate the soup profile).
        rho : float | None, default None
            Contamination fraction. ``None`` lets SoupX auto-estimate it.
        key_added : str, default 'counts'
            Layer key where the corrected count matrix is stored.
        """
        self.do_for_rna(run_on_samples, st.rna_soupx, **kwargs)

    def run_rna_sccoda(self, run_on_samples = False, **kwargs):
        """
        Test differential cell-type composition using scCODA.

        Fits a Bayesian Dirichlet-multinomial model to cell-type counts per
        sample and tests for compositional differences between conditions.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        major : str, default 'sample'
            ``adata.obs`` column identifying samples / spots.
        minor : str, default 'cell.type'
            ``adata.obs`` column for cell-type labels.
        categories : list[str], default ['group']
            Additional covariate columns for the design formula.
        formula : str, default 'group'
            Patsy formula for the fixed effects.
        num_samples : int, default 10000
            Number of MCMC posterior samples.
        num_warmup : int, default 1000
            Number of MCMC warm-up steps.
        seed : int, default 42
            Random seed.
        key_added : str, default 'sccoda'
            ``adata.uns`` key prefix for stored results.
        reference_cell_type : str, default 'automatic'
            Cell type used as the Dirichlet reference. ``'automatic'`` selects
            the most abundant absent type.
        automatic_reference_absence_threshold : float, default 0.05
            Maximum fraction in all samples to be considered "absent" for
            automatic reference selection.
        """
        self.do_for_rna(run_on_samples, st.rna_sccoda, **kwargs)

    def run_rna_covar_module_cophenetic(self, run_on_samples = False, **kwargs):
        """
        Evaluate cNMF rank stability for co-variation module analysis.

        Computes cophenetic correlation, residual sum of squares, and explained
        variance for a range of NMF ranks to guide optimal rank selection for
        :meth:`run_rna_covar_module`.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        col_sample : str, default 'sample'
            ``adata.obs`` sample column.
        col_major : str, default 'cell.type'
            ``adata.obs`` major cell-type column.
        col_fine : str, default 'cell.type.fine'
            ``adata.obs`` fine-grained cell-type column.
        nmf_clusters : list[int], default [4,5,6,7,8,9,10]
            Range of NMF ranks to evaluate.
        n_run : int, default 10
            Number of NMF runs per rank.
        max_iter : int, default 300
            Maximum NMF iterations.
        key_added : str, default 'covarnet'
            ``adata.uns`` key for cophenetic statistics.
        """
        self.do_for_rna(run_on_samples, st.rna_covar_module_cophenetic, **kwargs)

    def run_rna_covar_module(self, run_on_samples = False, **kwargs):
        """
        Identify co-variation modules of cell types across samples.

        Computes pairwise Pearson correlations in cell-type frequency across
        samples and applies NMF to extract co-variation modules (network
        communities). Results are stored in ``adata.uns[key_added]``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        col_sample : str, default 'sample'
            ``adata.obs`` sample column.
        col_major : str, default 'cell.type'
            ``adata.obs`` major cell-type column.
        col_fine : str, default 'cell.type.fine'
            ``adata.obs`` fine-grained cell-type column.
        nmf_clusters : int, default 5
            Number of NMF components (co-variation modules).
        n_run : int, default 10
            Number of NMF ensemble runs.
        max_iter : int, default 300
            Maximum NMF iterations per run.
        fdr : float, default 0.2
            FDR threshold for network edge inclusion.
        key_added : str, default 'covarnet'
            ``adata.uns`` key prefix for stored results.
        """
        self.do_for_rna(run_on_samples, st.rna_covar_module, **kwargs)


    def run_cite_clr_normalize(self, run_on_samples = False, **kwargs):
        """
        Apply centered log-ratio (CLR) normalization to CITE-seq protein data.

        Normalizes antibody-derived tag (ADT) counts across cells using the
        CLR transformation, which is robust to the sparse, compositional nature
        of ADT data.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. ``False`` uses the integrated CITE-seq
            modality; ``True`` processes all per-sample AnnData objects;
            a string or list of strings selects specific samples.
        key_source : str, default 'X'
            Source layer (raw or existing normalized counts).
        key_added : str, default 'clr'
            Layer key for the CLR-normalized output.
        """
        self.do_for_cite(run_on_samples, st.cite_centered_log_ratio, **kwargs)

    def run_cite_gate_polygon(self, run_on_samples = False, **kwargs):
        """
        Gate CITE-seq cells by a polygon defined in a 2-D protein-expression space.

        Identical in semantics to :meth:`run_rna_gate_polygon` but operates on
        the ``cite`` modality (antibody-derived tag counts) instead of the
        ``rna`` modality.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rna_qc` for semantics).
        gene_x : str
            Protein feature name placed on the X axis.
        gene_y : str
            Protein feature name placed on the Y axis.
        layer : str, default 'X'
            Layer from which expression values are retrieved.
            ``'X'`` refers to the main matrix.
        remove_zero_expression : bool, default False
            If ``True``, cells with zero expression for either protein are
            excluded before polygon containment is evaluated.
        scale : str, default 'asis'
            Transformation applied to expression values before gating.
            Choices:

            * ``'asis'`` – no transformation.
            * ``'log'`` – ``log1p`` transformation.
            * ``'expm1'`` – inverse of ``log1p``.
            * ``'arcsinh'`` – arcsinh transformation; the cofactor is
              ``median(nonzero) / 20`` unless *arcsinh_divider* is set.
        arcsinh_divider : float | None, default None
            Cofactor for the arcsinh transformation.  Ignored unless
            ``scale='arcsinh'``.
        polygon : list[tuple[float, float]], default [(0,0),(1,0),(1,1),(0,1)]
            Ordered list of ``(x, y)`` vertices that define the gate polygon.
        key_added : str, default 'gate'
            Name of the boolean ``obs`` column written to the AnnData object.
        """
        self.do_for_cite(run_on_samples, st.rna_gate_polygon, **kwargs)

    
    def run_atac_make_bins(self, run_on_samples = False, **kwargs):
        """
        Create a genome-wide tile / bin matrix from ATAC-seq fragments.

        Tiles the genome into fixed-size bins and counts the number of fragments
        overlapping each bin per cell, producing an integer count matrix.
        Bins can also be made from bedgraph files when no alignment BAM is
        available.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. ``False`` uses the integrated ATAC modality;
            ``True`` processes all per-sample AnnData objects; a string or list
            of strings selects specific samples.
        bin_size : int, default 500
            Width of each genomic bin in base pairs.
        inplace : bool, default True
            Update ``adata.X`` in place instead of creating a new layer.
        chunk_size : int, default 500
            Number of cells processed per chunk during tiling.
        exclude_chroms : list[str], default ['chrM','chrY','MT','M','Y']
            Contigs to exclude from tiling.
        min_frag_size : int | None, default None
            Minimum fragment size to include; ``None`` imposes no lower limit.
        max_frag_size : int | None, default None
            Maximum fragment size to include; ``None`` imposes no upper limit.
        counting_strategy : str, default 'paired-insertion'
            How fragments are counted: ``'paired-insertion'`` (insertion sites
            of the paired-end read), ``'fragment'`` (whole fragment).
        value_type : str, default 'target'
            What value to store per bin per cell.
        summary_type : str, default 'sum'
            Aggregation applied to multiple fragments per bin.
        n_jobs : int, default 8
            Number of parallel worker processes.
        """
        # bins can be made directly from bedgraph files if there is no alignment bam provided.
        # thus these samples can be used for clustering.
        self.do_for_atac(run_on_samples, st.atac_make_bins, **kwargs)
    
    def run_atac_filter_cells(self, run_on_samples = False, **kwargs):
        """
        Filter ATAC-seq cells by QC metrics.

        Removes cells with fragment counts or TSS enrichment scores outside the
        specified thresholds.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_atac_make_bins`).
        min_counts : int, default 5000
            Minimum number of fragments.
        max_counts : int, default 100000
            Maximum number of fragments.
        min_tsse : float, default 10
            Minimum TSS enrichment score.
        max_tsse : float, default 100
            Maximum TSS enrichment score.
        """
        self.do_for_atac(run_on_samples, st.atac_filter_cells, **kwargs)
    
    def run_atac_select_features(self, run_on_samples = False, **kwargs):
        """
        Select informative ATAC bins / peaks as features.

        Filters the bin matrix to retain peaks with sufficient coverage and
        discriminatory power for downstream dimensionality reduction.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_atac_make_bins`).
        n_features : int, default 50000
            Number of top accessible features (bins) to retain.
        filter_lower_quantile : float, default 0.005
            Lower quantile cutoff on accessibility frequency.
        filter_upper_quantile : float, default 0.005
            Upper quantile cutoff on accessibility frequency.
        whitelist : list[str] | None, default None
            Explicit list of feature IDs to always retain.
        blacklist : list[str] | None, default None
            Feature IDs to always exclude.
        key_added : str, default 'selected'
            ``adata.var`` boolean column flagging retained features.
        """
        self.do_for_atac(run_on_samples, st.atac_select_features, **kwargs)
    
    def run_atac_spectral(self, run_on_samples = False, **kwargs):
        """
        Compute spectral embedding for ATAC-seq dimensionality reduction.

        Applies spectral (Laplacian eigenmap) decomposition to the binarized
        peak or bin matrix and stores results in ``adata.obsm['spectral']``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_atac_make_bins`).
        key_added : str, default 'spectral'
            ``adata.obsm`` / ``adata.uns`` key for the spectral embedding.
        n_comps : int, default 30
            Number of spectral components to compute.
        features : str | None, default None
            ``adata.var`` boolean column selecting features. ``None`` uses all.
        random_state : int, default 0
            Random seed for the eigen-decomposition.
        sample_size : int | float | None, default None
            Number or fraction of cells used for landmark-based spectral
            embedding. ``None`` uses all cells.
        chunk_size : int | None, default None
            Cells processed per chunk for memory efficiency.
        distance_metric : str, default 'jaccard'
            Similarity metric applied to binarized accessibility.
        weighted_by_sd : bool, default True
            Weight components by their standard deviation.
        """
        self.do_for_atac(run_on_samples, st.atac_spectral, **kwargs)
    
    def run_atac_scrublet(self, run_on_samples = False, **kwargs):
        """
        Detect ATAC-seq doublets using Scrublet.

        Simulates doublets from the observed count matrix and scores each cell
        by its doublet probability. Scores and predictions are stored in
        ``adata.obs``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_atac_make_bins`).
        scrublet_init_args : dict, default {}
            Keyword arguments forwarded to ``scrublet.Scrublet(...)``.
        scrublet_args : dict, default {}
            Keyword arguments forwarded to
            ``scrublet.Scrublet.scrub_doublets(...)``.
        """
        self.do_for_atac(run_on_samples, st.atac_scrublet, **kwargs)
    
    def run_atac_knn(self, run_on_samples = False, **kwargs):
        """
        Build a k-nearest-neighbor graph for ATAC-seq cells.

        Constructs the cell neighbor graph from the spectral embedding for use
        in Leiden clustering and UMAP. Delegates to the same function as
        :meth:`run_rna_knn`.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_atac_make_bins`).
        use_rep : str, default 'spectral'
            ``adata.obsm`` key of the embedding.
        n_comps : int, default 30
            Number of dimensions to use.
        n_neighbors : int, default 15
            Number of neighbors per cell.
        knn : bool, default True
            Restrict to mutual k-nearest neighbors.
        method : str, default 'umap'
            Method for computing connectivities.
        metric : str, default 'euclidean'
            Distance metric.
        random_state : int, default 42
            Random seed.
        key_added : str, default 'neighbors'
            ``adata.uns`` key prefix for the neighbor graph.
        n_jobs : int | None, default None
            Number of parallel workers.
        """
        self.do_for_atac(run_on_samples, st.rna_knn, **kwargs)
    
    def run_atac_umap(self, run_on_samples = False, **kwargs):
        """
        Compute 2-D UMAP embedding for ATAC-seq data.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_atac_make_bins`).
        min_dist : float, default 0.5
            Minimum distance between embedded points.
        spread : float, default 1.0
            Effective scale of embedded points.
        n_components : int, default 2
            Number of UMAP dimensions.
        init_pos : str, default 'spectral'
            Initialization for UMAP layout.
        random_state : int, default 42
            Random seed.
        key_added : str, default 'umap'
            ``adata.obsm`` key prefix.
        neighbors_key : str | None, default None
            ``adata.uns`` key of the neighbor graph to use.
        use_gpu : bool, default False
            Use RAPIDS cuML GPU acceleration.
        """
        self.do_for_atac(run_on_samples, st.rna_umap, **kwargs)
    
    def run_atac_leiden(self, run_on_samples = False, **kwargs):
        """
        Cluster ATAC-seq cells using the Leiden algorithm.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_atac_make_bins`).
        resolution : float, default 1.0
            Resolution parameter; higher values produce more clusters.
        random_state : int, default 42
            Random seed.
        key_added : str, default 'leiden'
            ``adata.obs`` column for cluster labels.
        directed : bool, default True
            Treat the neighbor graph as directed.
        use_weights : bool, default True
            Use edge weights during modularity optimization.
        n_iterations : int, default -1
            Number of Leiden iterations; ``-1`` until convergence.
        partition_type : type | None, default None
            leidenalg partition type class.
        neighbors_key : str | None, default None
            ``adata.uns`` key of the neighbor graph.
        flavor : str, default 'leidenalg'
            Implementation: ``'leidenalg'`` or ``'igraph'``.
        """
        self.do_for_atac(run_on_samples, st.rna_leiden, **kwargs)
    
    def run_atac_leiden_subcluster(self, run_on_samples = False, **kwargs):
        """
        Sub-cluster a subset of ATAC-seq Leiden clusters.

        Re-applies Leiden clustering within already-defined clusters to
        produce higher-resolution sub-cluster labels.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_atac_make_bins`).
        cluster_key : str
            ``adata.obs`` column of the parent cluster assignment.
        clusters : list[str]
            Categories within ``cluster_key`` to subcluster.
        key_added : str, default 'leiden'
            ``adata.obs`` column to write the merged sub-cluster labels.
        resolution : float, default 1
            Leiden resolution for the sub-clustering step.
        neighbors_key : str | None, default None
            ``adata.uns`` key of the neighbor graph.
        """
        self.do_for_atac(run_on_samples, st.rna_leiden_subcluster, **kwargs)
    
    def run_atac_infer_gene_activity(self, run_on_samples = False, **kwargs):
        """
        Infer per-gene chromatin accessibility activity scores.

        Aggregates peak accessibility scores within gene bodies and proximal
        regulatory elements to produce a gene-level activity matrix. Results
        are stored in a new ``atac-g`` modality. Inference supports two
        strategies: from fragment files or from bedgraph / bigwig coverage.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_atac_make_bins`).
        make_gene_args : dict, default {}
            Arguments forwarded to the internal gene-matrix builder (e.g.
            ``upstream``, ``downstream`` window sizes in bp).
        exact : bool, default True
            Use exact BigWig statistics (slower) rather than approximate.
        """
        # inference on gene activity provides two alternative way. one from bam files
        # in the fragment matrix, and another from bedgraph counting.
        # more efficiently, should count on bigwig files.

        if not run_on_samples:
            if 'atac-g' in self.mudata.mod.keys():
                warning('atac-g modality exists in the mudata object. the run is cancelled to prevent overwrite.')
                error('if you want to overwrite existing modality, you should delete it manually first.')

        data = self.do_for_atac(run_on_samples, st.atac_infer_gene_activity, **kwargs)
        if isinstance(data, dict):
            for sampkey in data.keys():
                prop = self.metadata.dataframe.loc[
                    (self.metadata.dataframe['sample'] == sampkey) &
                    (self.metadata.dataframe['modality'] == 'atac'), :
                ]

                assert len(prop) == 1
                prop = prop.iloc[0, :].copy()
                prop['modality'] = 'atac-g'
                if not 'atac-g' in self.modalities.keys():
                    self.modalities['atac-g'] = {}
                
                self.modalities['atac-g'][sampkey] = data[sampkey]
                self.metadata.insert_row(prop)
        
        else: self.mudata.mod['atac-g'] = data

    def run_atac_call_peaks(self, run_on_samples = False, **kwargs):
        """
        Call accessible chromatin peaks from fragment data.

        Aggregates fragments per cell type (or globally) and calls peaks with
        MACS3. Results are stored in ``adata.uns['peaks']``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_atac_make_bins`).
        key_added : str, default 'peaks'
            ``adata.uns`` key where called peaks are stored (one DataFrame per
            group or sample).
        groupby : str | None, default None
            ``adata.obs`` column to merge fragments by before peak calling.
            ``None`` calls peaks on all cells jointly.
        pvalue : float, default 0.05
            MACS3 p-value cutoff.
        genome_size : str | None, default None
            Effective genome size string passed to MACS3 (e.g. ``'hs'``).
        """
        self.do_for_atac(run_on_samples, st.atac_call_peaks, **kwargs)

    def run_atac_merge_peaks(self, run_on_samples = False, **kwargs):
        """
        Merge peak sets across samples or cell groups.

        Combines per-sample or per-group peak BED files using IDR or a simple
        overlap strategy and produces a consensus peak set.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_atac_make_bins`).
        key_peaks : str, default 'peaks'
            ``adata.uns`` key with per-sample peak annotations.
        key_added : str, default 'peaks.merged'
            ``adata.uns`` key for the merged consensus peaks.
        key_groups : str, default 'peaks.group'
            ``adata.uns`` key mapping peaks to sample groups.
        groupby : str, default 'group'
            Grouping column used when merging peaks.
        flavor : str, default 'idr'
            Merge strategy: ``'idr'`` (Irreproducible Discovery Rate) or
            ``'union'`` / ``'intersect'``.
        """
        self.do_for_atac(run_on_samples, st.atac_merge_peaks, **kwargs)

    def run_atac_make_peak_matrix(self, run_on_samples = False, **kwargs):
        """
        Build a cell x peak count matrix from the consensus peak set.

        Counts fragments overlapping each consensus peak for every cell and
        stores the resulting count matrix in a new ``atacp`` modality.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_atac_make_bins`).
        key_peaks : str, default 'peaks.merged'
            ``adata.uns`` key of the consensus peak DataFrame.
        exact : bool, default True
            Use exact BigWig overlap statistics instead of approximate.
        """
        peak_matrix = self.do_for_atac(run_on_samples, st.atac_make_peak_matrix, **kwargs)
        if isinstance(peak_matrix, dict):
            for sampkey in peak_matrix.keys():
                prop = self.metadata.dataframe.loc[
                    (self.metadata.dataframe['sample'] == sampkey) &
                    (self.metadata.dataframe['modality'] == 'atac'), :
                ]

                assert len(prop) == 1
                prop = prop.iloc[0, :].copy()
                prop['modality'] = 'atac-p'
                if not 'atac-p' in self.modalities.keys():
                    self.modalities['atac-p'] = {}
                
                self.modalities['atac-p'][sampkey] = peak_matrix[sampkey]
                self.metadata.insert_row(prop)
        
        else: self.mudata.mod['atac-p'] = peak_matrix

    def run_atacp_filter_row_by_sum(self, run_on_samples = False, **kwargs):
        """
        Filter peaks (rows) from the ATAC peak matrix by total count sum.

        Removes peaks whose total accessibility sum across all cells falls below
        ``min_sum`` or above ``max_sum``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_make_bins` for semantics.
        min_sum : float | None, default None
            Minimum row sum to retain a peak.
        max_sum : float | None, default None
            Maximum row sum to retain a peak.
        layer : str | None, default None
            Layer to use for sum computation; ``None`` uses ``adata.X``.
        """
        results = self.do_for_atac_peaks(run_on_samples, st.adata_filter_row_by_sum, **kwargs)
        if isinstance(results, dict):
            for k in results.keys():
                self.modalities['atac-p'][k] = results[k]
        else: self.mudata.mod['atac-p'] = results

    def run_atacp_filter_column_by_sum(self, run_on_samples = False, **kwargs):
        """
        Filter cells (columns) from the ATAC peak matrix by total count sum.

        Removes cells whose total accessibility sum across all peaks falls
        below ``min_sum`` or above ``max_sum``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_make_bins` for semantics.
        min_sum : float | None, default None
            Minimum column sum to retain a cell.
        max_sum : float | None, default None
            Maximum column sum to retain a cell.
        layer : str | None, default None
            Layer to use for sum computation; ``None`` uses ``adata.X``.
        """
        results = self.do_for_atac_peaks(run_on_samples, st.adata_filter_column_by_sum, **kwargs)
        if isinstance(results, dict):
            for k in results.keys():
                self.modalities['atac-p'][k] = results[k]
        else: self.mudata.mod['atac-p'] = results

    def run_atacp_annotate_peak(self, run_on_samples = False, **kwargs):
        """
        Annotate ATAC-seq peaks with genomic features and nearest genes.

        Assigns functional labels (promoter, enhancer, intron, etc.) and
        nearest TSS gene information to each peak in ``adata.var``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_make_bins` for semantics.
        annotation_key : str, default 'type'
            ``adata.var`` column for genomic feature type labels.
        gene_key : str, default 'tss.nearest'
            ``adata.var`` column for the nearest TSS gene name.
        ugene_key : str, default 'ugene'
            ``adata.var`` column for unique gene identifiers.
        gname_key : str, default 'gene'
            ``adata.var`` column for gene symbol.
        distance_key : str, default 'tss.dist'
            ``adata.var`` column for distance to the nearest TSS.
        """
        self.do_for_atac_peaks(run_on_samples, st.atacp_annotate_peak, **kwargs)

    def run_atacp_markers_deseq(self, run_on_samples = False, **kwargs):
        """
        Find differentially accessible peaks across groups using DESeq2.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_make_bins` for semantics.
        groupby : str
            ``adata.obs`` column defining the groups to test.
        groups : list[str] | 'all', default 'all'
            Groups to include.
        reference : str | None, default None
            Reference group; ``None`` performs one-vs-rest comparisons.
        n_genes : int | None, default None
            Maximum number of genes / peaks to include per group.
        key_added : str, default 'deseq'
            Key prefix for results in ``adata.uns``.
        layer : str | None, default None
            Count layer to use.
        gene_symbol : str | None, default None
            ``adata.var`` column mapping feature IDs to display names.
        """
        self.do_for_atac_peaks(run_on_samples, st.rna_markers_deseq, **kwargs)

    def run_atacp_retrieve_sequence(self, run_on_samples = False, **kwargs):
        """
        Retrieve genomic sequences for each peak region.

        Fetches the reference DNA sequence for each peak from a genome FASTA
        and stores it in ``adata.var``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_make_bins` for semantics.
        length : int, default 200
            Length of the sequence window centred on each peak summit.
        key_added : str, default 'sequence'
            ``adata.var`` column to store retrieved sequences.
        """
        self.do_for_atac_peaks(run_on_samples, st.atacp_retrieve_sequence, **kwargs)

    def run_atacp_expression_linkage(self, run_on_samples = False, rna = 'rna', **kwargs):
        """
        Link ATAC-seq peaks to co-accessible RNA expression.

        Computes correlation between peak accessibility and gene expression in
        matched RNA cells to identify cis-regulatory relationships.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_make_bins` for semantics.
        rna : str, default 'rna'
            RNA modality key in this experiment used as the paired expression
            reference.
        key_added : str, default 'linkage'
            ``adata.uns`` key to store the peak-gene linkage table.
        lognorm_rna : str, default 'X'
            Layer of log-normalized RNA expression to correlate against peak
            accessibility.
        lognorm_atac : str, default 'X'
            Layer / matrix of peak accessibility values.
        method : str, default 'pearson'
            Correlation method: ``'pearson'`` or ``'spearman'``.
        min_cor : float, default 0
            Minimum absolute correlation to retain a peak-gene link.
        """
        if self.mudata and (not run_on_samples):
            self.do_for_atac_peaks(run_on_samples, st.atacp_expression_linkage, rna = self['rna'], **kwargs)
        else: self.do_for_atac_peaks(run_on_samples, st.atacp_expression_linkage, rna = self['rna'][rna], **kwargs)
    
    def run_atacp_motif_match(self, run_on_samples = False, **kwargs):
        """
        Match TF-binding motifs against peak sequences.

        Scans the DNA sequence of each peak for TF-binding motif occurrences
        and records which motifs match which peaks.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_make_bins` for semantics.
        key_added : str, default 'motifs'
            ``adata.varm`` key storing the sparse binary motif-match matrix
            (peaks × motifs).
        subset : str, default 'jaspar'
            Motif database subset to scan: ``'jaspar'``, ``'encode'``, etc.
        length : int, default 200
            Sequence window length around each peak summit.
        threshold : float, default 1e-5
            Match p-value threshold for calling a motif hit.
        """
        self.do_for_atac_peaks(run_on_samples, st.atacp_motif_match, **kwargs)

    def run_atacp_motif_enrichment(self, run_on_samples = False, **kwargs):
        """
        Test for TF-binding motif enrichment in differential peaks.

        Performs a hypergeometric or Fisher's exact test on motif occurrences
        within a set of differentially accessible peaks vs. background.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_make_bins` for semantics.
        background : str, default 'background'
            ``adata.uns`` key for pre-computed background sequences. If the
            key is absent, background sequences are fetched from the genome.
        n : int, default 50000
            Number of background sequences to sample when generating de-novo
            backgrounds.
        length : int, default 200
            Sequence window length (centred on each summit) used for both
            foreground and background.
        random_seed : int, default 42
            Random seed for background sampling.
        threshold : float, default 1e-5
            Motif-hit p-value threshold.
        motif_matches : str, default 'motifs'
            ``adata.varm`` key of the pre-computed motif-match matrix.
        subset : str, default 'jaspar'
            Motif database subset to use.
        key_added : str, default 'motifs.enrich'
            ``adata.uns`` key for the enrichment results DataFrame.
        """
        self.do_for_atac_peaks(run_on_samples, st.atacp_motif_enrichment, **kwargs)

    def run_atacp_chromvar(self, run_on_samples = False, **kwargs):
        """
        Compute per-cell TF-motif deviation scores using chromVAR.

        For each TF-binding motif, chromVAR computes a z-score deviation of
        peak accessibility relative to background peaks, providing a
        per-cell TF activity estimate. Results are stored in a new
        ``atac-chromvar`` modality.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_make_bins` for semantics.
        motif_matches : str, default 'motifs'
            ``adata.varm`` key of the binary motif-match matrix
            (peaks × motifs).
        bg_key : str, default 'bg.intern'
            ``adata.varm`` key of pre-computed background peak indices.
        n_jobs : int, default -1
            Number of parallel workers (``-1`` = all CPUs).
        key_added : str, default 'chromvar'
            ``adata.obsm`` key for the per-cell z-score deviation matrix.
        """
        chromvar = self.do_for_atac_peaks(run_on_samples, st.atacp_chromvar, **kwargs)
        if isinstance(chromvar, dict):
            for sampkey in chromvar.keys():
                prop = self.metadata.dataframe.loc[
                    (self.metadata.dataframe['sample'] == sampkey) &
                    (self.metadata.dataframe['modality'] == 'atac-p'), :
                ]

                assert len(prop) == 1
                prop = prop.iloc[0, :].copy()
                prop['modality'] = 'atac-chromvar'
                if not 'atac-chromvar' in self.modalities.keys():
                    self.modalities['atac-chromvar'] = {}
                
                self.modalities['atac-chromvar'][sampkey] = chromvar[sampkey]
                self.metadata.insert_row(prop)
        
        else: self.mudata.mod['atac-chromvar'] = chromvar
    
    def run_atacp_footprint(self, run_on_samples = False, atac = 'atac', **kwargs):
        """
        Compute TF-binding footprint scores on peak sequences.

        Estimates per-TF binding protection patterns by computing the
        Tn5 insertion density around motif instances relative to flanking
        regions.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_make_bins` for semantics.
        atac : str, default 'atac'
            ATAC modality key in this experiment providing fragment data.
        motif_matches : str, default 'motifs'
            ``adata.varm`` key of the binary motif-match matrix.
        flank : int, default 250
            Number of base pairs flanking each motif centre to include.
        key_added : str, default 'footprint'
            ``adata.uns`` key to store footprint signal arrays.
        n_jobs : int, default 1
            Number of parallel workers.
        """
        if self.mudata and (not run_on_samples):
            self.do_for_atac_peaks(run_on_samples, st.atacp_footprint, adata_atac = self['atac'], **kwargs)
        else: self.do_for_atac_peaks(run_on_samples, st.atacp_footprint, adata_atac = self['atac'][atac], **kwargs)

    def run_atacg_log_normalize(self, run_on_samples = False, **kwargs):
        """
        Log-normalize the ATAC gene-activity matrix.

        Divides each cell's activity counts by its total activity sum, scales
        to a target sum, and applies a log1p transformation.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_infer_gene_activity`.
        target_sum : float | None, default None
            Per-cell counts scaling target; ``None`` uses the median count.
        base : float | None, default None
            Logarithm base; ``None`` uses the natural logarithm.
        key_added : str, default 'lognorm'
            Layer key for the normalized output.
        layer : str | None, default None
            Source count layer; ``None`` uses ``adata.X``.
        """
        self.do_for_atac_gene_activity(run_on_samples, st.rna_log_normalize, **kwargs)

    def run_atacg_filter_row_by_sum(self, run_on_samples = False, **kwargs):
        """
        Filter genes (rows) from the ATAC gene-activity matrix by count sum.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_infer_gene_activity`.
        min_sum : float | None, default None
            Minimum row sum to retain a gene.
        max_sum : float | None, default None
            Maximum row sum to retain a gene.
        layer : str | None, default None
            Layer to use for sum computation; ``None`` uses ``adata.X``.
        """
        results = self.do_for_atac_gene_activity(run_on_samples, st.adata_filter_row_by_sum, **kwargs)
        if isinstance(results, dict):
            for k in results.keys():
                self.modalities['atac-g'][k] = results[k]
        else: self.mudata.mod['atac-g'] = results

    def run_atacg_filter_column_by_sum(self, run_on_samples = False, **kwargs):
        """
        Filter cells (columns) from the ATAC gene-activity matrix by count sum.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_infer_gene_activity`.
        min_sum : float | None, default None
            Minimum column sum to retain a cell.
        max_sum : float | None, default None
            Maximum column sum to retain a cell.
        layer : str | None, default None
            Layer to use for sum computation; ``None`` uses ``adata.X``.
        """
        results = self.do_for_atac_gene_activity(run_on_samples, st.adata_filter_column_by_sum, **kwargs)
        if isinstance(results, dict):
            for k in results.keys():
                self.modalities['atac-g'][k] = results[k]
        else: self.mudata.mod['atac-g'] = results

    def run_atacg_impute_magic(self, run_on_samples = False, **kwargs):
        """
        Denoise ATAC gene-activity scores using MAGIC imputation.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_infer_gene_activity`.
        key_added : str, default 'magic'
            Layer key for the imputed output.
        solver : str, default 'approximate'
            MAGIC solver: ``'approximate'`` or ``'exact'``.
        t : int | 'auto', default 'auto'
            Diffusion time steps.
        random_state : int, default 42
            Random seed.
        n_jobs : int, default 1
            Number of parallel jobs.
        n_pca : int, default 30
            Number of PCA components used for the affinity graph.
        knn : int, default 15
            Number of neighbors for the affinity graph.
        """
        self.do_for_atac_gene_activity(run_on_samples, st.rna_impute_magic, **kwargs) 

    def run_atacg_markers_deseq(self, run_on_samples = False, **kwargs):
        """
        Find differentially active genes in the ATAC gene-activity matrix
        using DESeq2.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. See :meth:`run_atac_infer_gene_activity`.
        groupby : str
            ``adata.obs`` column defining the groups to test.
        groups : list[str] | 'all', default 'all'
            Groups to include.
        reference : str | None, default None
            Reference group; ``None`` performs one-vs-rest comparisons.
        n_genes : int | None, default None
            Maximum number of genes to include per group.
        key_added : str, default 'deseq'
            Key prefix for results in ``adata.uns``.
        layer : str | None, default None
            Count layer to use.
        gene_symbol : str | None, default None
            ``adata.var`` column mapping feature IDs to display names.
        """
        self.do_for_atac_gene_activity(run_on_samples, st.rna_markers_deseq, **kwargs)


    def run_rnaspc_qc(self, run_on_samples = False, **kwargs):
        """
        Run quality control for spatial RNA-seq data.

        Computes per-cell QC metrics (mitochondrial fraction, total counts,
        total genes) and optionally flags doublets. Results are added to
        ``adata.obs`` and ``adata.var``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on. ``False`` uses the merged spatial modality;
            ``True`` processes all per-sample AnnData; a string or list selects
            specific samples.
        mt_seqid : str | None, default None
            Mitochondrial chromosome / contig identifier.
        mt_percent : float | None, default None
            Maximum allowed mitochondrial read fraction.
        min_genes : int | None, default None
            Minimum number of detected genes per cell.
        min_cells : int | None, default None
            Minimum number of cells a gene must appear in.
        doublet_method : str | None, default None
            Doublet detection method: ``'scrublet'`` or ``None``.
        """
        self.do_for_rnaspc(run_on_samples, st.rna_qc, **kwargs)
        
    def run_rnaspc_filter(self, run_on_samples = False):
        """
        Filter low-quality spots / cells from the spatial RNA-seq data.

        Removes cells and genes that fail QC thresholds computed by
        :meth:`run_rnaspc_qc`. The filtered AnnData replaces the existing
        ``rnasp-c`` modality entries.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        """
        results = self.do_for_rnaspc(run_on_samples, st.rna_filter)
        self.modalities['rnasp-c'] = results

    def run_rnaspc_log_normalize(self, run_on_samples = False, **kwargs):
        """
        Library-size normalize and log1p-transform spatial RNA-seq counts.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        target_sum : float | None, default None
            Per-cell scaling target; ``None`` uses the median library size.
        base : float | None, default None
            Logarithm base; ``None`` uses the natural logarithm.
        key_added : str, default 'lognorm'
            Layer key for the normalized output.
        layer : str | None, default None
            Source count layer; ``None`` uses ``adata.X``.
        """
        self.do_for_rnaspc(run_on_samples, st.rna_log_normalize, **kwargs)

    def run_rnaspc_select_hvg(self, run_on_samples = False, **kwargs):
        """
        Identify highly variable genes in the spatial RNA-seq data.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        method : str, default 'seurat_v3'
            HVG selection method.
        n_top_genes : int, default 3000
            Number of top highly variable genes to retain.
        layer : str | None, default None
            Layer to use; ``None`` uses ``adata.X``.
        dest : str, default 'vst.hvg'
            ``adata.var`` column for the HVG flag.
        """
        self.do_for_rnaspc(run_on_samples, st.rna_select_hvg, **kwargs)

    def run_rnaspc_scale_pca(self, run_on_samples = False, **kwargs):
        """
        Scale gene expression and compute PCA for spatial RNA-seq data.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        use_hvg : str | None, default 'vst.hvg'
            ``adata.var`` column flagging HVGs for PCA.
        n_comps : int, default 50
            Number of PCA components.
        use_layer : str | None, default 'X'
            Layer to scale and decompose.
        key_added : str, default 'pca'
            ``adata.obsm`` key for PCA coordinates.
        random_state : int, default 42
            Random seed.
        """
        self.do_for_rnaspc(run_on_samples, st.rna_scale_pca, **kwargs)

    def run_rnaspc_knn(self, run_on_samples = False, **kwargs):
        """
        Build a k-nearest-neighbor graph for spatial RNA-seq spots.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        use_rep : str, default 'pca'
            ``adata.obsm`` key of the embedding.
        n_comps : int, default 30
            Dimensions of ``use_rep`` to use.
        n_neighbors : int, default 15
            Number of neighbors per spot.
        metric : str, default 'euclidean'
            Distance metric.
        random_state : int, default 42
            Random seed.
        key_added : str, default 'neighbors'
            ``adata.uns`` key prefix for the neighbor graph.
        n_jobs : int | None, default None
            Number of parallel workers.
        """
        self.do_for_rnaspc(run_on_samples, st.rna_knn, **kwargs)

    def run_rnaspc_leiden(self, run_on_samples = False, **kwargs):
        """
        Cluster spatial RNA-seq spots using the Leiden algorithm.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        resolution : float, default 1.0
            Resolution parameter.
        random_state : int, default 42
            Random seed.
        key_added : str, default 'leiden'
            ``adata.obs`` column for cluster labels.
        neighbors_key : str | None, default None
            ``adata.uns`` key of the neighbor graph.
        flavor : str, default 'leidenalg'
            Implementation: ``'leidenalg'`` or ``'igraph'``.
        """
        self.do_for_rnaspc(run_on_samples, st.rna_leiden, **kwargs)

    def run_rnaspc_leiden_subcluster(self, run_on_samples = False, **kwargs):
        """
        Sub-cluster a subset of spatial RNA-seq Leiden clusters.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        cluster_key : str
            ``adata.obs`` column of the parent cluster assignment.
        clusters : list[str]
            Categories within ``cluster_key`` to subcluster.
        key_added : str, default 'leiden'
            ``adata.obs`` column to write merged sub-cluster labels.
        resolution : float, default 1
            Leiden resolution for the sub-clustering step.
        neighbors_key : str | None, default None
            ``adata.uns`` key of the neighbor graph.
        """
        self.do_for_rnaspc(run_on_samples, st.rna_leiden_subcluster, **kwargs)

    def run_rnaspc_umap(self, run_on_samples = False, **kwargs):
        """
        Compute 2-D UMAP embedding for spatial RNA-seq spots.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        min_dist : float, default 0.5
            Minimum distance between embedded points.
        spread : float, default 1.0
            Scale of embedded points.
        n_components : int, default 2
            Number of UMAP dimensions.
        random_state : int, default 42
            Random seed.
        key_added : str, default 'umap'
            ``adata.obsm`` key prefix.
        neighbors_key : str | None, default None
            ``adata.uns`` key of the neighbor graph.
        """
        self.do_for_rnaspc(run_on_samples, st.rna_umap, **kwargs)

    def run_rnaspc_mde(self, run_on_samples = False, **kwargs):
        """
        Compute 2-D MDE embedding for spatial RNA-seq spots.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        use_rep : str, default 'pca'
            ``adata.obsm`` key of the embedding.
        n_comps : int | None, default None
            Number of components to use.
        key_added : str, default 'mde'
            ``adata.obsm`` key for MDE coordinates.
        **kwargs
            Additional arguments passed to :func:`pymde.preserve_neighbors`.
        """
        self.do_for_rnaspc(run_on_samples, st.rna_mde, **kwargs)

    def run_rnaspc_mde_fit(self, run_on_samples = False, **kwargs):
        """
        Fit a pre-computed MDE solution to new spatial RNA-seq data.

        Projects additional spots into an existing MDE embedding.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        data : str, default 'pca'
            ``adata.obsm`` key of the high-dimensional source embedding.
        based : str, default 'umap'
            ``adata.obsm`` key of the reference 2-D layout to anchor to.
        mask_key : str, default 'sample'
            ``adata.obs`` column defining the reference cell subset.
        mask_values : list, default []
            Values in ``mask_key`` that identify reference cells.
        key_added : str, default 'mde'
            ``adata.obsm`` key for the fitted MDE coordinates.
        eps : float, default 1e-5
            Convergence tolerance.
        max_iter : int, default 300
            Maximum optimization iterations.
        """
        self.do_for_rnaspc(run_on_samples, st.rna_mde_fit, **kwargs)

    def run_rnaspc_aggregate(self, run_on_samples = False, **kwargs):
        """
        Aggregate spatial RNA-seq spot expression by grouping variable.

        Computes pseudo-bulk profiles by summing or averaging expression within
        each group (e.g. cell type or spatial domain).

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        groupby : str
            ``adata.obs`` column defining the aggregation groups.
        fun : str, default 'mean'
            Aggregation function: ``'mean'``, ``'sum'``, ``'median'``.
        layer : str | None, default None
            Layer to aggregate; ``None`` uses ``adata.X``.
        """
        return self.do_for_rnaspc(run_on_samples, st.rna_aggregate, **kwargs)

    def run_rnaspc_transform(self, run_on_samples = False, xfunc = lambda x:x, yfunc = lambda x:x):
        """
        Apply coordinate transformation functions to spatial spot positions.

        Useful for registering or rescaling the spatial coordinates stored in
        ``adata.obsm['spatial']``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        xfunc : callable, default identity
            Transformation applied to the x-axis coordinates.
        yfunc : callable, default identity
            Transformation applied to the y-axis coordinates.
        """
        self.do_for_rnaspc(run_on_samples, st.rnaspc_transform, xfunc = xfunc, yfunc = yfunc)

    def run_rnaspc_expression_mask(
        self, run_on_samples = False, gene = None, key = 'mask', 
        lognorm = 'X', threshold = 0.1, negate = False
    ):
        """
        Create a boolean mask of spot-level gene expression.

        Flags spots where expression of the specified gene exceeds (or falls
        below) a threshold, storing the boolean flag in ``adata.obs[key]``.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        gene : str | None, default None
            Gene name to evaluate (``adata.var_names`` entry).
        key : str, default 'mask'
            ``adata.obs`` column for the binary mask.
        lognorm : str, default 'X'
            Layer to threshold.
        threshold : float, default 0.1
            Expression threshold.
        negate : bool, default False
            If ``True``, mask spots *below* the threshold.
        """
        return self.do_for_rnaspc(
            run_on_samples, st.rna_expression_mask, 
            gene = gene, key = key, lognorm = lognorm, threshold = threshold,
            negate = negate
        )

    def run_rnaspc_integrate(self, method = 'harmony', dest = 'harmony', **kwargs):
        """
        Integrate spatial RNA-seq data across multiple sections using batch correction.

        Removes technical batch effects from the spatial assay, producing a
        corrected low-dimensional representation.

        Parameters
        ----------
        method : str, default 'harmony'
            Integration method: ``'harmony'`` or ``'scanorama'``.
        dest : str, default 'harmony'
            ``adata.obsm`` key for the corrected embedding.
        **kwargs
            Additional arguments forwarded to the chosen integration function.
        """
        
        self.check_merged('rnasp-c')
        if method == 'harmony':
            from exprmat.preprocessing.integrate import harmony
            harmony(self.mudata['rnasp-c'], key = 'batch', adjusted_basis = dest, **kwargs)
        
        elif method == 'scanorama':
            from exprmat.preprocessing.integrate import scanorama
            scanorama(self.mudata['rnasp-c'], key = 'batch', adjusted_basis = dest, **kwargs)

        else: error(f'unsupported integration method `{method}`.')


    def run_rnaspc_markers(self, run_on_samples = False, **kwargs):
        """
        Find marker genes for spatial RNA-seq spot clusters.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        groupby : str
            ``adata.obs`` column defining the groups.
        groups : list[str] | 'all', default 'all'
            Groups to include.
        reference : str, default 'rest'
            Reference group.
        n_genes : int | None, default None
            Maximum number of marker genes per group.
        method : str, default 't-test_overestim_var'
            Statistical test.
        key_added : str, default 'markers'
            ``adata.uns`` key for results.
        layer : str | None, default None
            Layer to use; ``None`` uses ``adata.X``.
        """
        self.do_for_rnaspc(run_on_samples, st.rna_markers, **kwargs)

    def run_rnaspc_kde(self, run_on_samples = False, **kwargs):
        """
        Compute kernel density estimates on spatial spot embeddings.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        groupby : str
            ``adata.obs`` column defining the groups.
        key_added : str, default 'kde'
            ``adata.obsm`` key for KDE scores.
        use_rep : str, default 'umap'
            Embedding to compute density on.
        bandwidth : float, default 0.5
            Kernel bandwidth.
        """
        self.do_for_rnaspc(run_on_samples, st.rna_kde, **kwargs)

    def run_rnaspc_proportion(self, run_on_samples = False, **kwargs):
        '''
        This is a simplified method of cell type proportion calculation.
        It is implemented in earlier versions of the package and can be replaced by a more
        general version of counting summary. This returns a simple dataframe, while summary
        returns an annotated object and can be further processed using routines under
        ``exprmat.clustering.summary`` package.
        '''
        return self.do_for_rnaspc(run_on_samples, st.rna_proportion, **kwargs)

    def run_rnaspc_roi(self, run_on_samples = False, **kwargs):
        """
        Extract a region of interest (ROI) from spatial RNA-seq data.

        Crops the expression data and spatial coordinates to a bounding box or
        polygon region of interest and returns the subsetted AnnData.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to operate on (see :meth:`run_rnaspc_qc`).
        spsample : str
            Key of the spatial sample to extract the ROI from.
        **kwargs
            Additional arguments forwarded to
            :func:`exprmat.reader.static.rnaspc_roi`.
        """
        
        roi = self.do_for_rnaspc(run_on_samples, st.rnaspc_roi, **kwargs)
        if isinstance(roi, dict):
            roi = roi[kwargs.get('spsample')]
        
        roi.uns['spatial'] = {
            kwargs.get('sample_added'): roi.uns['spatial'][kwargs.get('spsample')]
        }

        rows = self.metadata.dataframe[(
            (self.metadata.dataframe['sample'] == kwargs.get('spsample')) &
            (self.metadata.dataframe['modality'] == 'rnasp-c')
        )]

        assert len(rows) == 1
        props = rows.iloc[0].copy()
        props['sample'] = kwargs.get('sample_added')
        props['modality'] = 'rnasp-c'

        self.metadata.insert_row(props)
        if not 'rnasp-c' in self.modalities.keys(): self.modalities['rnasp-c'] = {}
        self.modalities['rnasp-c'][kwargs.get('sample_added')] = roi
        self.modalities['rnasp-c'][kwargs.get('sample_added')].var = \
            st.search_genes(self.modalities['rnasp-c'][kwargs.get('sample_added')].var_names.tolist())



    # plotting wrappers

    def plot_rna_qc(self, run_on_samples = False, **kwargs):
        """
        Plot RNA QC metrics per cell.

        Generates violin or scatter plots of mitochondrial fraction, total
        UMI counts, and detected gene counts.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot. See :meth:`run_rna_qc` for semantics.
        figsize : tuple[float, float], default (10, 2.2)
            Width and height of the figure in inches.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_qc, **kwargs)

    def plot_rna_embedding(self, run_on_samples = False, **kwargs):
        """
        Plot a single RNA embedding colored by metadata or gene expression.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot. See :meth:`run_rna_qc` for semantics.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column or gene name used for coloring.
        slot : str, default 'X'
            Layer to use when ``color`` is a gene.
        embedding_dims : list[int], default [0, 1]
            Which two dimensions of the embedding to plot.
        ptsize : float, default 8
            Marker size in points.
        size : float | None, default None
            Overrides ``ptsize`` when set.
        hue_order : list | None, default None
            Order in which categorical levels are plotted.
        default_color : str, default 'black'
            Color used when all cells share the same value.
        alpha : float, default 0.8
            Marker transparency.
        rasterize : bool, default True
            Rasterize scatter points to reduce file size.
        sort : bool, default True
            Draw cells with higher values on top.
        annotate : bool, default True
            Label cluster centroids.
        annotate_style : str, default 'index'
            Label style — ``'index'`` (cluster ID) or ``'name'``.
        annotate_foreground : str, default 'black'
            Color of the annotation text.
        annotate_stroke : str, default 'white'
            Color of the annotation text outline.
        annotate_fontsize : int, default 12
            Font size of annotation labels.
        annotate_only : list | None, default None
            Restrict annotations to these category values.
        legend : bool, default True
            Show the color legend.
        contour_plot : bool, default False
            Overlay KDE contour lines.
        contour_fill : bool, default False
            Fill contour regions.
        contour_palatte : str | None, default None
            Color palette for contour lines.
        contour_mask : str | None, default None
            ``adata.obs`` column used to mask cells before contouring.
        contour_mask_values : list, default []
            Values of ``contour_mask`` to include.
        contour_linewidth : float, default 0.8
            Width of contour lines.
        contour_default_color : str, default 'black'
            Color of contour lines when not colored by a variable.
        contour_alpha : float, default 1
            Transparency of contour lines.
        contour_levels : int, default 10
            Number of contour level bands.
        contour_bw : float, default 0.5
            Bandwidth for KDE contour smoothing.
        legend_col : int, default 1
            Number of columns in the legend.
        add_outline : bool, default False
            Draw a highlight outline around each cell.
        outline_color : str, default 'black'
            Color of the cell outline.
        outline_margin : int, default 20
            Pixel margin for the outline.
        title : str | None, default None
            Axes title.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        ax : matplotlib.axes.Axes | None, default None
            Axes to draw into; creates a new figure when ``None``.
        dpi : int, default 100
            Figure resolution.
        cmap : str, default 'turbo'
            Colormap name for continuous coloring.
        cmap_reverse : bool, default False
            Reverse the colormap.
        cmap_lower : str, default '#000000'
            Color assigned to the lowest value when using a continuous map.
        vmin : float, default 0
            Minimum value for the color scale.
        vmax : float | None, default None
            Maximum value for the color scale.
        cbar : bool, default False
            Show a colorbar.
        hue_norm : tuple | None, default None
            Normalization range passed to seaborn.
        ticks : bool, default False
            Show axis ticks.
        frameon : str | bool, default 'small'
            Axis frame style.
        xlabel : str | None, default None
            X-axis label.
        ylabel : str | None, default None
            Y-axis label.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_embedding, **kwargs)
    
    def plot_rna_embedding_mask(self, run_on_samples = False, **kwargs):
        """
        Plot a 2-D RNA embedding with a boolean mask overlay.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column whose values are tested against ``values``.
        values : list
            Cells whose ``color`` value is in this list are highlighted.
        slot : str, default 'X'
            Unused for mask plots; kept for API consistency.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        title : str | None, default None
            Axes title.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_embedding_mask, **kwargs)
    
    def plot_rna_embedding_atlas(self, run_on_samples = False, **kwargs):
        """
        Plot an RNA embedding using atlas-style layout (reference mapping).

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column or gene name used for coloring.
        embedding_dims : list[int], default [0, 1]
            Which two dimensions of the embedding to plot.
        hue_order : list | None, default None
            Order in which categorical levels are plotted.
        title : str | None, default None
            Axes title.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        ax : matplotlib.axes.Axes | None, default None
            Axes to draw into; creates a new figure when ``None``.
        cmap : str, default 'turbo'
            Colormap name.
        cmap_reverse : bool, default False
            Reverse the colormap.
        cmap_lower : str, default '#000000'
            Color for the lowest value.
        legend : bool, default True
            Show the color legend.
        legend_loc : str, default 'right margin'
            Legend placement.
        legend_col : int, default 1
            Number of columns in the legend.
        frameon : str | bool, default 'small'
            Axis frame style.
        fontsize : int, default 10
            Font size for axis labels.
        annotate : bool, default True
            Label cluster centroids.
        annotate_style : str, default 'index'
            Label style — ``'index'`` or ``'name'``.
        annotate_fontsize : int, default 12
            Font size of annotation labels.
        annotate_foreground : str, default 'black'
            Color of annotation text.
        annotate_stroke : str, default 'white'
            Color of annotation text outline.
        ticks : bool, default False
            Show axis ticks.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_embedding_atlas, **kwargs)

    def plot_rna_embedding_multiple(self, run_on_samples = False, **kwargs):
        """
        Plot multiple RNA embeddings in a grid layout.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        features : list[str]
            ``adata.obs`` columns or gene names to color each panel.
        ncols : int
            Number of columns in the subplot grid.
        figsize : tuple[float, float], default (3, 3)
            Width and height of each individual panel in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_multiple_embedding, **kwargs)
    
    def plot_rna_embedding_atlas_multiple(self, run_on_samples = False, **kwargs):
        """
        Plot multiple RNA embeddings using atlas-style layout in a grid.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        features : list[str]
            ``adata.obs`` columns or gene names to color each panel.
        ncols : int
            Number of columns in the subplot grid.
        figsize : tuple[float, float], default (3, 3)
            Width and height of each individual panel in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_multiple_embedding_atlas, **kwargs)

    def plot_rna_markers(self, run_on_samples = False, **kwargs):
        """
        Plot a ranked marker gene list as a volcano or ridgeline figure.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        figsize : tuple[float, float]
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        plot_type : str, default 'dotplot'
            Plot style — e.g. ``'dotplot'``, ``'heatmap'``, ``'matrixplot'``.
        groups : str | list[str] | None, default None
            Cell groups to include.
        n_genes : int | None, default None
            Number of top marker genes to show per group.
        groupby : str | None, default None
            ``adata.obs`` column defining the groups.
        values_to_plot : str | None, default None
            Quantity to color by (e.g. ``'logfoldchanges'``).
        var_names : list | dict | None, default None
            Explicit gene list; mutually exclusive with ``n_genes``.
        min_logfoldchange : float | None, default 1
            Minimum log fold-change filter.
        max_logfoldchange : float | None, default None
            Maximum log fold-change filter.
        max_p_adjust : float, default 0.05
            Maximum adjusted p-value filter.
        min_pct : float, default 0.25
            Minimum detection fraction in the group.
        max_pct_reference : float, default 0.75
            Maximum detection fraction in the reference group.
        key : str | None, default None
            ``adata.uns`` key for marker results.
        gene_symbols : str | None, default None
            ``adata.var`` column with human-readable gene symbols.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_markers, **kwargs)
    
    def plot_rna_dotplot(self, run_on_samples = False, **kwargs):
        """
        Plot a dot plot of gene expression across cell groups.

        Dot size encodes fraction of cells expressing the gene; color encodes
        mean expression level.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        var_names : list[str] | dict
            Genes or gene-group mapping to plot.
        groupby : str
            ``adata.obs`` column defining the cell groups (y-axis).
        figsize : tuple[float, float]
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        log : bool, default False
            Log-transform expression values.
        categories_order : list | None, default None
            Custom display order for groups.
        expression_cutoff : float, default 0
            Minimum expression to count a cell as expressing a gene.
        dendrogram : bool, default False
            Cluster groups by expression similarity.
        dendrogram_rep : str | None, default None
            Representation used for dendrogram clustering.
        mean_only_expressed : bool, default False
            Average over expressing cells only.
        standard_scale : str | None, default None
            Standardize along ``'var'`` or ``'group'``.
        title : str | None, default None
            Figure title.
        colorbar_title : str | None, default None
            Label for the color bar.
        size_title : str | None, default None
            Label for the size legend.
        gene_symbols : str | None, default None
            ``adata.var`` column with human-readable gene symbols.
        var_group_positions : list | None, default None
            Start/end positions for gene group brackets.
        var_group_labels : list | None, default None
            Labels for gene group brackets.
        var_group_rotation : float | None, default None
            Rotation angle for group labels.
        layer : str | None, default None
            Layer to use instead of ``adata.X``.
        swap_axes : bool, default False
            Swap genes and groups on the axes.
        dot_color_df : pd.DataFrame | None, default None
            Pre-computed color data frame.
        vmin : float | None, default None
            Minimum value for the color scale.
        vmax : float | None, default None
            Maximum value for the color scale.
        vcenter : float | None, default None
            Center value for diverging colormaps.
        norm : matplotlib normalization | None, default None
            Custom normalization.
        cmap : str, default 'turbo'
            Colormap name.
        dot_max : float | None, default None
            Size of the largest dot (normalized fraction).
        dot_min : float | None, default None
            Size of the smallest dot (normalized fraction).
        smallest_dot : float, default 0
            Minimum rendered dot size.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_dot, **kwargs)
    
    def plot_rna_heatmap(self, run_on_samples = False, **kwargs):
        """
        Plot a heatmap of gene expression across cells or groups.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        var_names : list[str] | dict
            Genes or gene-group mapping to plot.
        groupby : str
            ``adata.obs`` column defining the cell groups.
        dpi : int, default 100
            Figure resolution.
        categories_order : list | None, default None
            Custom display order for groups.
        cmap : str, default 'turbo'
            Colormap name.
        figsize : tuple[float, float], default (4, 8)
            Width and height of the figure in inches.
        standard_scale : str | None, default None
            Standardize along ``'var'`` or ``'group'``.
        var_identifier : str, default 'gene'
            ``adata.var`` column to use as gene labels.
        var_group_labels : list | None, default None
            Labels for gene group brackets.
        show_gene_labels : bool | None, default None
            Display individual gene names on the y-axis.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_heatmap, **kwargs)
    
    def plot_rna_kde(self, run_on_samples = False, **kwargs):
        """
        Plot kernel density estimates on the RNA embedding.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        kde : str | None, default None
            Pre-computed KDE key in ``adata.obsm``.
        grouping_key : str | None, default None
            ``adata.obs`` column used to split KDE by group.
        figsize : tuple[float, float]
            Width and height of each panel in inches.
        dpi : int, default 100
            Figure resolution.
        groups : list | None, default None
            Subset of groups to plot.
        ncols : int | None, default None
            Number of columns in the grid.
        background : str | None, default None
            Background color of each panel.
        annotate : bool, default True
            Label cluster centroids.
        annotate_fontsize : int, default 12
            Font size of annotation labels.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_kde, **kwargs)
    
    def plot_rna_projection(self, run_on_samples = False, **kwargs):
        """
        Plot query cells projected onto a reference atlas embedding.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        color : str | None, default None
            ``adata.obs`` column or gene name for coloring.
        figsize : tuple[float, float]
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        projection_key : str | None, default None
            Key in ``adata.obsm`` holding the projected coordinates.
        background : str | None, default None
            Background color of the panel.
        annotate : bool, default True
            Label cluster centroids.
        annotate_fontsize : int, default 12
            Font size of annotation labels.
        groupby : str | None, default None
            ``adata.obs`` column used to split panels.
        groups : list | None, default None
            Subset of groups to plot.
        ncols : int | None, default None
            Number of columns in the grid.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_projection, **kwargs)
    
    def plot_rna_proportion(self, run_on_samples = False, **kwargs):
        """
        Plot cell-type proportions across samples or conditions.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        major : str
            ``adata.obs`` column defining the major grouping (e.g. samples).
        minor : str
            ``adata.obs`` column defining the minor grouping (e.g. cell types).
        plot : str, default 'bar'
            Plot type — ``'bar'``, ``'pie'``, or ``'both'``.
        cmap : str, default 'turbo'
            Colormap name.
        normalize : str | bool, default True
            Normalize proportions along ``'major'``, ``'minor'``, or ``True``.
        figsize : tuple[float, float]
            Width and height of the figure in inches.
        stacked : bool, default True
            Whether the bar chart is stacked.
        wedge : dict | None, default None
            Additional keyword arguments for pie wedge styling.
        legend : bool, default True
            Show the color legend.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_proportion, **kwargs)
    
    def plot_rna_gene_gene(self, run_on_samples = False, **kwargs):
        """
        Plot a scatter plot of two gene expression values.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        gene_x : str
            Feature displayed on the X-axis.
        gene_y : str
            Feature displayed on the Y-axis.
        color : str
            ``adata.obs`` column or gene used for coloring.
        layer : str, default 'X'
            Layer to retrieve expression from.
        ptsize : float, default 8
            Marker size.
        alpha : float, default 0.8
            Marker transparency.
        rasterize : bool, default True
            Rasterize scatter points.
        sort : bool, default True
            Draw cells with higher values on top.
        annotate : bool, default True
            Label cluster centroids.
        annotate_fontsize : int, default 12
            Font size of annotation labels.
        legend : bool, default True
            Show the color legend.
        contour_plot : bool, default True
            Overlay KDE contour lines.
        contour_fill : bool, default False
            Fill contour regions.
        title : str | None, default None
            Axes title.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        cmap : str, default 'turbo'
            Colormap name.
        cmap_reverse : bool, default False
            Reverse the colormap.
        frameon : str | bool, default 'small'
            Axis frame style.
        scale : str, default 'asis'
            Value transformation — ``'asis'`` or ``'log'``.
        remove_zero_expression : bool, default False
            Exclude cells where both genes are zero.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_gene_gene, **kwargs)
    
    def plot_rna_gene_gene_regress(self, run_on_samples = False, **kwargs):
        """
        Plot gene-vs-gene scatter with a regression line overlay.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        x : str | list[str]
            Gene or list of genes for the X-axis (averaged when a list).
        y : str | list[str]
            Gene or list of genes for the Y-axis (averaged when a list).
        figsize : tuple[float, float], default (3, 3)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        title : str | None, default None
            Axes title.
        regression_info : bool, default True
            Annotate regression statistics on the plot.
        layer : str, default 'X'
            Layer to retrieve expression from.
        scale : str, default 'asis'
            Value transformation — ``'asis'`` or ``'log'``.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_gene_gene_regress, **kwargs)

    def plot_rna_gene_gene_multiple(self, run_on_samples = False, **kwargs):
        """
        Plot a grid of gene-vs-gene scatter plots.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        color : str
            ``adata.obs`` column or gene used for coloring all panels.
        features_xy : list[tuple[str, str]]
            List of ``(gene_x, gene_y)`` pairs, one per panel.
        ncols : int
            Number of columns in the subplot grid.
        figsize : tuple[float, float], default (3, 3)
            Width and height of each panel in inches.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_multiple_gene_gene, **kwargs)
    
    def plot_rna_cnv_matrix(self, run_on_samples = False, **kwargs):
        """
        Plot the inferred copy-number variation (CNV) matrix.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        groupby : str, default 'leiden.cnv'
            ``adata.obs`` column used to group rows of the heatmap.
        use_rep : str, default 'cnv'
            Key in ``adata.obsm`` for the CNV matrix.
        cmap : str, default 'bwr'
            Colormap name (diverging recommended).
        figsize : tuple[int, int], default (16, 10)
            Width and height of the figure in inches.
        draw_autosome_only : bool, default False
            Restrict to autosomal chromosomes only.
        vmin : float | None, default None
            Minimum value for the color scale.
        vmax : float | None, default None
            Maximum value for the color scale.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_cnv_matrix, **kwargs)
    
    def plot_rna_expression_bar(self, run_on_samples = False, **kwargs):
        """
        Plot a bar chart of mean gene expression across cell groups.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        gene : str
            Gene or feature to plot.
        group : str
            ``adata.obs`` column defining the groups (x-axis).
        split : str | None, default None
            ``adata.obs`` column for splitting bars within each group.
        slot : str, default 'X'
            Layer to retrieve expression from.
        selected_groups : list | None, default None
            Subset of groups to include.
        selected_splits : list | None, default None
            Subset of split values to include.
        palette : list[str], default ['red', 'black']
            Color palette for split bars.
        figsize : tuple[float, float], default (6, 3)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_expression_bar, **kwargs)
    
    def plot_rna_expression_bar_multiple(self, run_on_samples = False, **kwargs):
        """
        Plot a grid of expression bar charts for multiple genes.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        features : list[str]
            Genes or features to plot, one panel each.
        ncols : int
            Number of columns in the subplot grid.
        group : str
            ``adata.obs`` column defining the groups (x-axis).
        split : str | None, default None
            ``adata.obs`` column for splitting bars within each group.
        slot : str, default 'X'
            Layer to retrieve expression from.
        selected_groups : list | None, default None
            Subset of groups to include.
        palette : list[str]
            Color palette for split bars.
        figsize : tuple[float, float], default (6, 3)
            Width and height of each panel in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_expression_bar_multiple, **kwargs)
    
    def plot_rna_compare_scatter(self, run_on_samples = False, **kwargs):
        """
        Plot a comparison scatter between two groups or conditions.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        group_x : str
            Label of the group shown on the X-axis.
        group_y : str
            Label of the group shown on the Y-axis.
        key : str
            ``adata.uns`` key holding the differential expression results.
        slot : str, default 'X'
            Layer to retrieve expression from.
        markers : list[str] | None, default None
            Genes to label in the plot.
        figsize : tuple[float, float]
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_compare_scatter, **kwargs)
    
    def plot_rna_nichenet_ligands(self, run_on_samples = False, **kwargs):
        """
        Plot NicheNet ligand activity scores.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        key_nichenet : str, default 'nichenet'
            ``adata.uns`` key holding the NicheNet results.
        figsize : tuple[float, float], default (12, 4)
            Width and height of the figure in inches.
        width_ratios : list[float], default [1, 8]
            Relative widths of the ligand-score and target-heatmap panels.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_nichenet_ligands, **kwargs)
    
    def plot_rna_qc_gene_counts(
        self, ncols = 4, figsize = (3, 3)
    ):
        """
        Plot per-sample histograms of gene count distributions.

        Produces a grid of histograms showing the number of detected genes
        per cell for each loaded RNA sample.

        Parameters
        ----------
        ncols : int, default 4
            Number of columns in the subplot grid.
        figsize : tuple[float, float], default (3, 3)
            Width and height of each individual subplot in inches.
        """
        from exprmat.utils import setup_styles
        setup_styles()

        from exprmat.preprocessing.plot import rna_plot_gene_histogram
        import matplotlib.pyplot as plt
        import warnings
        warnings.filterwarnings('ignore')
        if self.modalities is None: error('samples are not loaded')
        if not 'rna' in self.modalities.keys(): error('samples are not loaded')

        n_features = len(self.modalities['rna'])
        if n_features == 0: error('samples are not loaded')

        nrows = n_features // ncols
        if n_features % ncols != 0: nrows += 1
        fig, axes = plt.subplots(nrows, ncols)

        samples = list(self.modalities['rna'].keys())
        samples.sort()
        for feat_id in range(n_features):

            try:
                if len(axes.shape) == 2:
                    rna_plot_gene_histogram(
                        self.modalities['rna'][samples[feat_id]],
                        sample_name = samples[feat_id],
                        ax = axes[feat_id // ncols, feat_id % ncols]
                    )

                elif len(axes.shape) == 1:
                    rna_plot_gene_histogram(
                        self.modalities['rna'][samples[feat_id]],
                        sample_name = samples[feat_id],
                        ax = axes[feat_id]
                    )
            
            except: pass
        
        fig.set_figwidth(figsize[0])
        fig.set_figheight(figsize[1])
        fig.tight_layout()
        return fig
    
    def plot_rna_gsea_running_es(self, run_on_samples = False, **kwargs):
        """
        Plot GSEA running enrichment score (ES) curves.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        gsea : str
            ``adata.uns`` key holding the GSEA results.
        terms : list[str]
            Gene-set terms to draw ES curves for.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        colors : list[str] | None, default None
            Colors for each term's curve.
        title : str | None, default None
            Figure title.
        """
        return self.plot_for_rna(
            run_on_samples, st.rna_plot_gsea_running_es, 
            do_tight_layout = False, **kwargs
        )
    
    def plot_rna_gsea_dotplot(self, run_on_samples = False, **kwargs):
        """
        Plot GSEA results as a bubble / dot plot.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        gsea_key : str
            ``adata.uns`` key holding the GSEA results.
        max_fdr : float, default 1
            Maximum FDR threshold for showing gene sets.
        max_p : float, default 0.05
            Maximum p-value threshold for showing gene sets.
        top_term : int, default 100
            Maximum number of gene sets to display.
        colour : str, default 'p'
            Column mapped to dot color.
        title : str, default ''
            Figure title.
        cmap : str, default 'turbo'
            Colormap name.
        figsize : tuple[float, float], default (3, 2)
            Width and height of the figure in inches.
        cutoff : float, default 1
            Cutoff applied to the color column.
        ptsize : float, default 5
            Base dot size.
        terms : list[str] | None, default None
            Explicit list of gene-set names to include.
        formatter : callable, default identity
            Function applied to gene-set names for display.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_gsea_dotplot, **kwargs)
    
    def plot_rna_opa_dotplot(self, run_on_samples = False, **kwargs):
        """
        Plot over-representation analysis (OPA) results as a dot plot.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        opa_key : str
            ``adata.uns`` key holding the OPA results.
        max_fdr : float, default 1
            Maximum FDR threshold for showing terms.
        max_p : float, default 0.05
            Maximum p-value threshold.
        top_term : int, default 100
            Maximum number of terms to display.
        terms : list[str] | None, default None
            Explicit list of term names to include.
        colour : str, default 'fdr'
            Column mapped to dot color.
        title : str | None, default None
            Figure title (defaults to ``opa_key``).
        cmap : str, default 'turbo'
            Colormap name.
        figsize : tuple[float, float], default (3, 2)
            Width and height of the figure in inches.
        cutoff : float, default 1
            Cutoff applied to the color column.
        ptsize : float, default 5
            Base dot size.
        formatter : callable, default identity
            Function applied to term names for display.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_opa_dotplot, **kwargs)
    
    def plot_rna_lr_heatmap(self, run_on_samples = False, **kwargs):
        """
        Plot a heatmap of ligand-receptor interaction scores.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        lr_key : str
            ``adata.uns`` key holding the LR results.
        groupby : str
            ``adata.obs`` column used to define cell-type groups.
        source_key : str, default 'source'
            Column name for the sender cell type.
        target_key : str, default 'target'
            Column name for the receiver cell type.
        score_key : str | None, default None
            Column to use for interaction scores.
        inverse_score : bool, default False
            Invert the score (useful for p-value columns).
        top_n : int | None, default None
            Keep only the top-N interactions.
        orderby : str | None, default None
            Column used for ordering interactions.
        orderby_ascending : bool | None, default None
            Sort ascending when ``True``.
        orderby_absolute : bool, default False
            Sort by absolute value.
        filter_fun : callable | None, default None
            Custom filter applied to the results table.
        source_labels : list | str | None, default None
            Sender cell types to include.
        target_labels : list | str | None, default None
            Receiver cell types to include.
        ligand_complex : list | str | None, default None
            Filter by ligand complex.
        receptor_complex : list | str | None, default None
            Filter by receptor complex.
        pivot_mode : str, default 'counts'
            Aggregation mode — ``'counts'`` or ``'mean'``.
        annotate : bool, default True
            Annotate cells with numeric values.
        mask_mode : str, default 'or'
            Masking logic — ``'and'`` or ``'or'``.
        figure_size : tuple[float, float], default (5, 5)
            Width and height of the figure in inches.
        cmap : str, default 'turbo'
            Colormap name.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_lr_heatmap, **kwargs)
    
    def plot_rna_lr_dotplot(self, run_on_samples = False, **kwargs):
        """
        Plot ligand-receptor interaction scores as a dot plot.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        lr_key : str
            ``adata.uns`` key holding the LR results.
        colour : str | None, default None
            Column mapped to dot color.
        size : str | None, default None
            Column mapped to dot size.
        source_labels : list | None, default None
            Sender cell types to include.
        target_labels : list | None, default None
            Receiver cell types to include.
        top_n : int | None, default None
            Keep only the top-N interactions.
        orderby : str | None, default None
            Column used for ordering interactions.
        orderby_ascending : bool | None, default None
            Sort ascending when ``True``.
        orderby_absolute : bool, default False
            Sort by absolute value.
        filter_fun : callable | None, default None
            Custom filter applied to the results table.
        ligand_complex : str | None, default None
            Filter by ligand complex.
        receptor_complex : str | None, default None
            Filter by receptor complex.
        inverse_colour : bool, default False
            Invert the color score.
        inverse_size : bool, default False
            Invert the size score.
        cmap : str
            Colormap name.
        size_ratio : float, default 1.0
            Scale factor for dot sizes.
        sort : bool, default False
            Sort interactions.
        colorbar : bool, default False
            Show the colorbar.
        figure_size : tuple[float, float], default (8, 6)
            Width and height of the figure in inches.
        paired : bool, default False
            Plot source→target pairs as paired columns.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_lr_dotplot, **kwargs)
    
    def plot_rna_lr_circleplot(self, run_on_samples = False, **kwargs):
        """
        Plot ligand-receptor interactions as a chord / circle diagram.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        lr_key : str
            ``adata.uns`` key holding the LR results.
        groupby : str
            ``adata.obs`` column defining cell-type groups.
        source_key : str, default 'source'
            Column name for the sender cell type.
        target_key : str, default 'target'
            Column name for the receiver cell type.
        score_key : str | None, default None
            Column used for edge weights.
        inverse_score : bool, default False
            Invert the score.
        top_n : int | None, default None
            Keep only the top-N interactions.
        orderby : str | None, default None
            Column used for ordering.
        orderby_ascending : bool | None, default None
            Sort ascending when ``True``.
        orderby_absolute : bool, default False
            Sort by absolute value.
        filter_fun : callable | None, default None
            Custom filter applied to the results table.
        source_labels : list | str | None, default None
            Sender cell types to include.
        target_labels : list | str | None, default None
            Receiver cell types to include.
        ligand_complex : list | str | None, default None
            Filter by ligand complex.
        receptor_complex : list | str | None, default None
            Filter by receptor complex.
        pivot_mode : str, default 'counts'
            Aggregation mode — ``'counts'`` or ``'mean'``.
        mask_mode : str, default 'or'
            Masking logic — ``'and'`` or ``'or'``.
        figure_size : tuple[float, float], default (5, 5)
            Width and height of the figure in inches.
        edge_alpha : float, default 0.5
            Edge transparency.
        edge_arrow_size : int, default 10
            Arrow head size.
        edge_width_scale : tuple[float, float], default (1, 5)
            Minimum and maximum edge width.
        node_alpha : float, default 1
            Node transparency.
        node_size_scale : tuple[float, float], default (100, 400)
            Minimum and maximum node size.
        node_label_offset : tuple[float, float], default (0.1, -0.2)
            Offset for node labels.
        node_label_size : int, default 8
            Font size of node labels.
        node_label_alpha : float, default 0.7
            Transparency of node label backgrounds.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_lr_circleplot, **kwargs)
    
    def plot_rna_volcano(self, run_on_samples = False, **kwargs):
        """
        Plot a volcano plot for differential expression results.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        de_slot : str, default 'deg'
            ``adata.uns`` key holding the DE results.
        label : list[str], default []
            Gene names to label individually.
        show_all : bool, default False
            Show all genes including non-significant ones.
        min_pct : float, default 0
            Minimum detection rate to include a gene.
        max_pct_reference : float, default 1
            Maximum detection rate in the reference group.
        min_lfc : float, default -25
            Minimum log fold-change to include.
        max_lfc : float, default 25
            Maximum log fold-change to include.
        remove_zero_pval : bool, default False
            Exclude genes with zero p-value.
        highlight_min_logp : float, default 5
            Minimum -log10(p) threshold for highlighting.
        highlight_min_lfc : float, default 1.5
            Minimum |LFC| threshold for highlighting.
        xlim : float, default 5
            X-axis limit (symmetric around 0).
        ylim : float, default 100
            Y-axis upper limit.
        figsize : tuple[float, float], default (3, 3)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_volcano, **kwargs)
    
    def plot_rna_spliced_proportions(self, run_on_samples = False, **kwargs):
        """
        Plot the proportion of spliced vs. unspliced RNA counts.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        groupby : str, default 'leiden'
            ``adata.obs`` column used to group cells.
        layers : list[str] | None, default None
            Layers to include (e.g. ``['spliced', 'unspliced', 'ambiguous']``).
        highlight : str, default 'unspliced'
            Layer to highlight in the bar chart.
        add_labels_pie : bool, default True
            Show percentage labels on the pie chart.
        add_labels_bar : bool, default True
            Show percentage labels on the bar chart.
        fontsize : int, default 8
            Font size for labels.
        figsize : tuple[float, float], default (10, 2)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        use_raw : bool, default True
            Use ``adata.obs`` pre-computed counts when available.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_spliced_proportions, **kwargs)
    
    def plot_rna_velocity_gene(self, run_on_samples = False, **kwargs):
        """
        Plot per-gene RNA velocity (phase portrait).

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str, default 'umap'
            Embedding key in ``adata.obsm``.
        gene : str | None, default None
            Gene to visualize; when ``None`` the top variable gene is used.
        groupby : str, default 'cell.type'
            ``adata.obs`` column used for coloring.
        vkey : str, default 'velocity'
            ``adata.layers`` key holding velocity values.
        mode : str, default 'stochastic'
            Velocity mode — e.g. ``'stochastic'`` or ``'deterministic'``.
        neighbor_key : str, default 'neighbors'
            ``adata.uns`` key for the neighbor graph.
        highly_variable : str, default 'vst.hvg'
            ``adata.var`` boolean column marking highly variable genes.
        figsize : tuple[float, float], default (14, 28)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_velocity_gene, **kwargs)
    
    def plot_rna_velocity_streamline(self, run_on_samples = False, **kwargs):
        """
        Plot RNA velocity directions as streamlines on an embedding.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str, default 'umap'
            Embedding key in ``adata.obsm``.
        vkey : str, default 'velocity'
            ``adata.layers`` key holding velocity values.
        neighbor_key : str, default 'neighbors'
            ``adata.uns`` key for the neighbor graph.
        color : str, default 'leiden'
            ``adata.obs`` column for cell coloring.
        contour_plot : bool, default False
            Overlay KDE contour lines.
        figsize : tuple[float, float], default (5, 5)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        density : int, default 2
            Density of stream-line seeds.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_velocity_streamline, **kwargs)
    
    def plot_rna_cnmf_silhoutte(self, run_on_samples = False, **kwargs):
        """
        Plot cNMF rank selection using silhouette stability scores.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        nmf_slot : str, default 'cnmf'
            ``adata.uns`` key prefix for cNMF results.
        figsize : tuple[float, float], default (3, 2)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_cnmf_silhoutte, **kwargs)
    
    def plot_rna_cnmf_density(self, run_on_samples = False, **kwargs):
        """
        Plot cNMF local density scores for rank selection.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        k : int
            Number of NMF components (rank) whose density to plot.
        nmf_slot : str, default 'cnmf'
            ``adata.uns`` key prefix for cNMF results.
        figsize : tuple[float, float], default (3, 2)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_cnmf_density, **kwargs)

    def plot_rna_cnmf_distance_comps(self, run_on_samples = False, **kwargs):
        """
        Plot pairwise distances between cNMF spectra components.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        k : int
            Number of NMF components (rank) to visualize.
        nmf_slot : str, default 'cnmf'
            ``adata.uns`` key prefix for cNMF results.
        cmap : str, default 'reds'
            Colormap name.
        figsize : tuple[float, float], default (3, 3)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_cnmf_distance_comps, **kwargs)

    def plot_rna_cnmf_distance_usages(self, run_on_samples = False, **kwargs):
        """
        Plot pairwise distances between cNMF cell usage vectors.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        k : int
            Number of NMF components (rank) to visualize.
        nmf_slot : str, default 'cnmf'
            ``adata.uns`` key prefix for cNMF results.
        metrics : str, default 'cosine'
            Distance metric for pairwise cell distances.
        downsample : float, default 0.1
            Fraction of cells to downsample before computing distances.
        method : str, default 'single'
            Linkage method for seriation.
        annotations : str | None, default None
            ``adata.obs`` column or ``adata.obsm`` key for color annotations.
        show_indices : bool, default False
            Show cell indices on axes.
        legend_cols : int, default 1
            Number of columns in the annotation legend.
        cmap : str, default 'reds'
            Colormap for the distance matrix.
        cmap_annotations : str, default 'set1'
            Colormap for annotation bars.
        figsize : tuple[float, float], default (3, 3)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_cnmf_distance_usages, **kwargs)
    
    def plot_rna_cnmf_distance_modules(self, run_on_samples = False, **kwargs):
        """
        Plot distances between cNMF gene modules.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        k : int
            Number of NMF components (rank) to visualize.
        nmf_slot : str, default 'cnmf'
            ``adata.uns`` key prefix for cNMF results.
        metrics : str, default 'cosine'
            Distance metric for pairwise gene distances.
        downsample : float, default 1
            Fraction of genes to include (1 = all).
        method : str, default 'complete'
            Linkage method for seriation.
        annotations : str | None, default None
            Annotation column or key for color bars.
        cmap_annotations : str, default 'set1'
            Colormap for annotation bars.
        show_indices : bool, default False
            Show gene indices on axes.
        cmap : str, default 'reds'
            Colormap for the distance matrix.
        figsize : tuple[float, float], default (3, 3)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        legend_cols : int, default 1
            Number of columns in the annotation legend.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_cnmf_distance_modules, **kwargs)
    
    def plot_rna_graph(self, run_on_samples = False, **kwargs):
        """
        Plot the cell neighbor graph in a 2-D layout.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str | None, default None
            Key in ``adata.obsm`` for the background embedding.
        background_color : str | None, default None
            Color used for background cells.
        trajectory_key : str, default 'ppt'
            ``adata.uns``/``adata.obsm`` prefix for trajectory data.
        embedding_dims : list[int], default [0, 1]
            Dimensions of the embedding to plot.
        size_nodes : float | None, default None
            Size of trajectory node markers.
        alpha_nodes : float, default 1
            Transparency of trajectory node markers.
        linewidth : float, default 2
            Width of trajectory edges.
        alpha_seg : float, default 1
            Transparency of trajectory edges.
        color_cells : str | None, default None
            ``adata.obs`` column for cell coloring.
        tips : bool, default True
            Annotate leaf (tip) nodes.
        forks : bool, default True
            Annotate branch (fork) nodes.
        nodes : list, default []
            Additional node indices to annotate.
        rasterized : bool, default True
            Rasterize the scatter layer.
        contour_plot : bool, default False
            Overlay KDE contour lines on the background.
        figsize : tuple[float, float], default (3, 3)
            Width and height of the figure in inches.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_graph, **kwargs)

    def plot_rna_principle_tree_segments(self, run_on_samples = False, **kwargs):
        """
        Plot the principal tree topology with branch segments.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str | None, default None
            Key in ``adata.obsm`` for the background embedding.
        color_seg : str, default 'segments'
            Color scheme for trajectory segments.
        background_color : str | None, default None
            Color used for background cells.
        cmap_seg : str, default 'viridis'
            Colormap for segment coloring.
        layer_seg : str | None, default 'fitted'
            Layer used for continuous segment coloring.
        perc_seg : list | None, default None
            Percentile range for segment color clipping.
        color_cells : str | None, default None
            ``adata.obs`` column for cell coloring.
        scale_path : float, default 1
            Scale factor for segment widths.
        rasterized : bool, default True
            Rasterize the scatter layer.
        trajectory_key : str, default 'ppt'
            ``adata.uns``/``adata.obsm`` prefix for trajectory data.
        embedding_dims : list[int], default [0, 1]
            Dimensions of the embedding to plot.
        contour_plot : bool, default False
            Overlay KDE contour lines.
        figsize : tuple[float, float], default (3, 3)
            Width and height of the figure in inches.
        annotate : bool, default False
            Label milestone nodes.
        annotate_fontsize : int, default 9
            Font size of milestone labels.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_principle_tree_segments, **kwargs)

    def plot_rna_principle_tree_trace(self, run_on_samples = False, **kwargs):
        """
        Plot gene expression or pseudotime along a traced trajectory.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        trace_key : str, default 'trace'
            ``adata.uns`` key holding the trace AnnData object.
        trajectory_key : str, default 'ppt'
            ``adata.uns``/``adata.obsm`` prefix for trajectory data.
        values : str, default 'fitted'
            Values to display — ``'fitted'`` (scaled) or ``'expression'``.
        show_hvg_only : str | None, default None
            If set, restrict to highly-variable genes in this ``adata.var`` column.
        show_leiden_only : list[int] | None, default None
            If set, restrict to genes belonging to these Leiden pattern clusters.
        show_genes : list[str] | None, default None
            Explicit list of genes to display.
        p_cutoff : float, default 0.0001
            Maximum p-value for gene selection.
        cmap : str, default 'turbo'
            Colormap name.
        figsize : tuple[float, float], default (4, 8)
            Width and height of the figure in inches.
        show_gene_names : bool | None, default None
            Display gene names on the y-axis (auto-detected from row count).
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_principle_tree_trace, **kwargs)
    
    def plot_rna_emptydrops(self, run_on_samples = False, **kwargs):
        """
        Plot the EmptyDrops knee plot for distinguishing cells from empty droplets.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        key : str, default 'emptydrops'
            ``adata.uns`` key holding the EmptyDrops results.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_emptydrops, **kwargs)

    def plot_rna_covarnet(self, run_on_samples = False, **kwargs):
        """
        Plot the co-variation network of cell types.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        key : str, default 'covarnet'
            ``adata.uns`` key holding the co-variation network.
        node_size : int, default 500
            Base node size.
        cmap : str, default 'category20b'
            Colormap for node colors.
        cmap_edge : str, default 'reds/r'
            Colormap for edge colors.
        figsize : tuple[float, float], default (3, 3)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_covarnet, **kwargs)

    def plot_rna_covarnet_components(self, run_on_samples = False, **kwargs):
        """
        Plot the NMF components of the co-variation network.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        key : str, default 'covarnet'
            ``adata.uns`` key prefix for co-variation network results.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_covarnet_components, **kwargs)
    
    def plot_rna_covarnet_usages(self, run_on_samples = False, **kwargs):
        """
        Plot the cell usage weights of the co-variation network components.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        key : str, default 'covarnet'
            ``adata.uns`` key prefix for co-variation network results.
        """
        return self.plot_for_rna(run_on_samples, st.rna_plot_covarnet_usages, **kwargs)

    def plot_rna_group_comparison(self, run_on_samples = False, **kwargs):
        return self.plot_for_rna(run_on_samples, st.rna_plot_group_comparison, **kwargs)
    
    
    def plot_cite_gene_gene(self, run_on_samples = False, **kwargs):
        """
        Plot a scatter plot of two CITE-seq protein expression values.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        gene_x : str
            Protein feature displayed on the X-axis.
        gene_y : str
            Protein feature displayed on the Y-axis.
        color : str
            ``adata.obs`` column or feature used for coloring.
        layer : str, default 'X'
            Layer to retrieve expression from.
        ptsize : float, default 8
            Marker size.
        alpha : float, default 0.8
            Marker transparency.
        title : str | None, default None
            Axes title.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        cmap : str, default 'turbo'
            Colormap name.
        """
        return self.plot_for_cite(run_on_samples, st.rna_plot_gene_gene, **kwargs)

    def plot_cite_embedding(self, run_on_samples = False, **kwargs):
        """
        Plot a CITE-seq embedding colored by protein expression or metadata.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column or protein name used for coloring.
        slot : str, default 'X'
            Layer to use when ``color`` is a protein feature.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        title : str | None, default None
            Axes title.
        cmap : str, default 'turbo'
            Colormap name.
        annotate : bool, default True
            Label cluster centroids.
        legend : bool, default True
            Show the color legend.
        """
        return self.plot_for_cite(run_on_samples, st.rna_plot_embedding, **kwargs)
    
    def plot_cite_embedding_mask(self, run_on_samples = False, **kwargs):
        """
        Plot a CITE-seq embedding with a boolean mask overlay.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column whose values are tested against ``values``.
        values : list
            Cells whose ``color`` value is in this list are highlighted.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        title : str | None, default None
            Axes title.
        """
        return self.plot_for_cite(run_on_samples, st.rna_plot_embedding_mask, **kwargs)
    
    def plot_cite_embedding_atlas(self, run_on_samples = False, **kwargs):
        """
        Plot a CITE-seq embedding using atlas-style reference layout.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column or protein name used for coloring.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        title : str | None, default None
            Axes title.
        cmap : str, default 'turbo'
            Colormap name.
        annotate : bool, default True
            Label cluster centroids.
        legend : bool, default True
            Show the color legend.
        """
        return self.plot_for_cite(run_on_samples, st.rna_plot_embedding_atlas, **kwargs)

    def plot_cite_embedding_multiple(self, run_on_samples = False, **kwargs):
        """
        Plot a grid of CITE-seq embeddings for multiple proteins.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        features : list[str]
            Protein names or ``adata.obs`` columns to color each panel.
        ncols : int
            Number of columns in the subplot grid.
        figsize : tuple[float, float], default (3, 3)
            Width and height of each panel in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_cite(run_on_samples, st.rna_plot_multiple_embedding, **kwargs)
    
    def plot_cite_embedding_atlas_multiple(self, run_on_samples = False, **kwargs):
        """
        Plot a grid of CITE-seq atlas-style embeddings for multiple proteins.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        features : list[str]
            Protein names or ``adata.obs`` columns to color each panel.
        ncols : int
            Number of columns in the subplot grid.
        figsize : tuple[float, float], default (3, 3)
            Width and height of each panel in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_cite(run_on_samples, st.rna_plot_multiple_embedding_atlas, **kwargs)

    def plot_atac_qc(self, run_on_samples = False, **kwargs):
        """
        Plot ATAC-seq QC metrics (fragment counts, TSS enrichment score).

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        figsize : tuple[float, float], default (8, 2.5)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_atac(run_on_samples, st.atac_plot_qc, **kwargs)
    
    def plot_atac_embedding(self, run_on_samples = False, **kwargs):
        """
        Plot a 2-D ATAC-seq embedding colored by metadata or accessibility.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column or feature name used for coloring.
        slot : str, default 'X'
            Layer to use when ``color`` is a feature.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        title : str | None, default None
            Axes title.
        cmap : str, default 'turbo'
            Colormap name.
        annotate : bool, default True
            Label cluster centroids.
        legend : bool, default True
            Show the color legend.
        """
        return self.plot_for_atac(run_on_samples, st.rna_plot_embedding, **kwargs)
    
    def plot_atac_embedding_multiple(self, run_on_samples = False, **kwargs):
        """
        Plot a grid of ATAC-seq embeddings for multiple features.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        features : list[str]
            Feature names or ``adata.obs`` columns to color each panel.
        ncols : int
            Number of columns in the subplot grid.
        figsize : tuple[float, float], default (3, 3)
            Width and height of each panel in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_atac(run_on_samples, st.rna_plot_multiple_embedding, **kwargs)

    def plot_atac_embedding_mask(self, run_on_samples = False, **kwargs):
        """
        Plot a 2-D ATAC-seq embedding with a boolean mask overlay.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column whose values are tested against ``values``.
        values : list
            Cells whose ``color`` value is in this list are highlighted.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        title : str | None, default None
            Axes title.
        """
        return self.plot_for_atac(run_on_samples, st.rna_plot_embedding_mask, **kwargs)
    
    def plot_atac_peaks(self, run_on_samples = False, **kwargs):
        """
        Plot ATAC-seq peak tracks for selected genomic regions.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        group_key : str
            ``adata.obs`` column defining the track groups.
        peaks_key : str | None, default None
            ``adata.uns`` key holding peak calls.
        gene : str | None, default None
            Gene whose locus defines the plotting window.
        upstream : int, default 5000
            Base pairs upstream of the gene to include.
        downstream : int, default 5000
            Base pairs downstream of the gene to include.
        chr : str | None, default None
            Chromosome to plot (alternative to ``gene``).
        xf : int | None, default None
            Start coordinate of the plotting window.
        xt : int | None, default None
            End coordinate of the plotting window.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        gene_track_height : float, default 0.25
            Fraction of figure height for the gene model track.
        chrom_track_height : float, default 0.05
            Fraction of figure height for the chromosome ruler.
        peak_annotation_height : float, default 0.1
            Fraction of per-group height for peak annotation bars.
        consensus_annotation_height : float, default 0.05
            Fraction of remaining height for consensus peak annotations.
        linkage_height : float, default 0.25
            Fraction of remaining height for peak–gene linkage arcs.
        min_frag_length : int | None, default None
            Minimum fragment length to include.
        max_frag_length : int, default 180
            Maximum fragment length to include.
        title : str | None, default None
            Figure title.
        showgn : bool, default True
            Show gene names on the gene track.
        plot_consensus_peak : bool | None, default None
            Add a consensus peak track.
        plot_linkage : bool | None, default None
            Add a peak–gene linkage track.
        linkage_score : str, default 'cor'
            Linkage scoring column.
        """
        return self.plot_for_atac(
            run_on_samples, st.atac_plot_peaks, dump = self.directory,
            do_tight_layout = False, **kwargs
        )
    
    def plot_atacg_embedding(self, run_on_samples = False, **kwargs):
        """
        Plot a 2-D embedding of ATAC gene-activity scores.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column or gene-activity feature used for coloring.
        slot : str, default 'X'
            Layer to use when ``color`` is a gene-activity feature.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        title : str | None, default None
            Axes title.
        cmap : str, default 'turbo'
            Colormap name.
        annotate : bool, default True
            Label cluster centroids.
        legend : bool, default True
            Show the color legend.
        """
        return self.plot_for_atac_gene_activity(run_on_samples, st.rna_plot_embedding, **kwargs)
    
    def plot_atacg_embedding_multiple(self, run_on_samples = False, **kwargs):
        """
        Plot a grid of ATAC gene-activity embeddings for multiple features.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        features : list[str]
            Gene-activity scores or ``adata.obs`` columns to color each panel.
        ncols : int
            Number of columns in the subplot grid.
        figsize : tuple[float, float], default (3, 3)
            Width and height of each panel in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_atac_gene_activity(run_on_samples, st.rna_plot_multiple_embedding, **kwargs)
    
    def plot_atacg_embedding_mask(self, run_on_samples = False, **kwargs):
        """
        Plot a 2-D ATAC gene-activity embedding with a boolean mask overlay.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column whose values are tested against ``values``.
        values : list
            Cells whose ``color`` value is in this list are highlighted.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        title : str | None, default None
            Axes title.
        """
        return self.plot_for_atac_gene_activity(run_on_samples, st.rna_plot_embedding_mask, **kwargs)


    def plot_rnaspc_qc(self, run_on_samples = False, **kwargs):
        """
        Plot spatial RNA-seq QC metrics per spot.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        figsize : tuple[float, float], default (10, 2.2)
            Width and height of the figure in inches.
        """
        return self.plot_for_rnaspc(run_on_samples, st.rna_plot_qc, **kwargs)

    def plot_rnaspc_embedding(self, run_on_samples = False, **kwargs):
        """
        Plot a 2-D transcriptome embedding for spatial RNA-seq spots.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column or gene name used for coloring.
        slot : str, default 'X'
            Layer to use when ``color`` is a gene.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        title : str | None, default None
            Axes title.
        cmap : str, default 'turbo'
            Colormap name.
        annotate : bool, default True
            Label cluster centroids.
        legend : bool, default True
            Show the color legend.
        """
        return self.plot_for_rnaspc(run_on_samples, st.rna_plot_embedding, **kwargs)

    def plot_rnaspc_embedding_atlas(self, run_on_samples = False, **kwargs):
        """
        Plot a spatial RNA-seq embedding using atlas-style layout.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column or gene name used for coloring.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        title : str | None, default None
            Axes title.
        cmap : str, default 'turbo'
            Colormap name.
        annotate : bool, default True
            Label cluster centroids.
        legend : bool, default True
            Show the color legend.
        """
        return self.plot_for_rnaspc(run_on_samples, st.rna_plot_embedding_atlas, **kwargs)
    
    def plot_rnaspc_embedding_atlas_multiple(self, run_on_samples = False, **kwargs):
        """
        Plot a grid of spatial RNA-seq atlas-style embeddings.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        features : list[str]
            Gene names or ``adata.obs`` columns to color each panel.
        ncols : int
            Number of columns in the subplot grid.
        figsize : tuple[float, float], default (3, 3)
            Width and height of each panel in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rnaspc(run_on_samples, st.rna_plot_multiple_embedding_atlas, **kwargs)
    
    def plot_rnaspc_embedding_mask(self, run_on_samples = False, **kwargs):
        """
        Plot a spatial RNA-seq embedding with a boolean mask overlay.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        color : str
            ``adata.obs`` column whose values are tested against ``values``.
        values : list
            Spots whose ``color`` value is in this list are highlighted.
        figsize : tuple[float, float], default (4, 4)
            Width and height of the figure in inches.
        dpi : int, default 100
            Figure resolution.
        title : str | None, default None
            Axes title.
        """
        return self.plot_for_rnaspc(run_on_samples, st.rna_plot_embedding_mask, **kwargs)
    
    def plot_rnaspc_embedding_multiple(self, run_on_samples = False, **kwargs):
        """
        Plot a grid of spatial RNA-seq embeddings for multiple features.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        basis : str
            Key in ``adata.obsm`` for the 2-D embedding coordinates.
        features : list[str]
            Gene names or ``adata.obs`` columns to color each panel.
        ncols : int
            Number of columns in the subplot grid.
        figsize : tuple[float, float], default (3, 3)
            Width and height of each panel in inches.
        dpi : int, default 100
            Figure resolution.
        """
        return self.plot_for_rnaspc(run_on_samples, st.rna_plot_multiple_embedding, **kwargs)
    
    def plot_rnaspc_embedding_spatial(self, run_on_samples = False, **kwargs):
        """
        Plot expression or metadata directly on the tissue image (spatial plot).

        Overlays colored spots on the H&E / brightfield tissue image using the
        original spatial coordinates.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to plot.
        spatial : str | None, default None
            Key in ``adata.uns['spatial']`` for the spatial metadata. Inferred
            when the dataset contains a single spatial sample.
        image : str, default 'hires'
            Image resolution key — ``'hires'`` or ``'lowres'``.
        select_channels : list[str] | None, default None
            Channel names to include; ``None`` selects all channels.
        channel_colors : list[str] | None, default None
            HTML color for each channel; when ``None`` uses stored colors.
        channel_intensities : list[float] | None, default None
            Intensity scale factor per channel; defaults to 1 for all.
        interpolation : str, default 'nearest'
            Interpolation method for the image (e.g. ``'bicubic'``).
        xrange : tuple[int, int] | None, default None
            Pixel column range to display.
        yrange : tuple[int, int] | None, default None
            Pixel row range to display.
        ticks : bool, default False
            Show axis ticks.
        dpi : int, default 100
            Figure resolution.
        mode : str, default 'cells'
            Overlay mode — ``'cells'`` draws spot boundaries.
        key_boundary : str, default 'smoothed'
            Key for cell boundary polygons.
        cells_color : str, default 'cell.type'
            ``adata.obs`` column used to color spot overlays.
        show_subset : list | None, default None
            Subset of category values to highlight.
        cell_alpha : float, default 0.3
            Transparency of cell overlays.
        cell_filled : bool, default True
            Fill cell polygon overlays.
        cell_palette : str, default 'turbo'
            Colormap for cell overlays.
        cell_legend : bool, default True
            Show legend for cell overlays.
        title : str | None, default None
            Axes title.
        figsize : tuple[float, float], default (3, 3)
            Width and height of the figure in inches.
        """
        return self.plot_for_rnaspc(run_on_samples, st.rnaspc_plot_embedding_spatial, zstore = self.spatial, **kwargs)
    
    

    def plot_sankey(self, run_on_samples = False, **kwargs):
        return self.plot_for_rna(run_on_samples, st.adata_plot_sankey, **kwargs)
    
    def plot_matrix(self, run_on_samples = False, **kwargs):
        return self.plot_for_rna(run_on_samples, st.adata_plot_matrix, **kwargs)
    


    # accessor wrappers

    def get_rna_markers(self, run_on_samples = False, **kwargs):
        """
        Retrieve the marker gene table from stored differential expression results.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to retrieve from.
        de_slot : str, default 'markers'
            Key in ``adata.uns`` that holds the stored DE results.
        group_name : str, optional
            Which comparison group to retrieve. When the DE result contains
            exactly one group this defaults to that group automatically.
        min_pct : float, default 0.25
            Minimum fraction of cells in the group expressing the gene.
        max_pct_reference : float, default 0.75
            Maximum fraction of cells in the reference group expressing the gene.
        min_lfc : float, default 1
            Minimum log-fold-change threshold.
        max_lfc : float, default 100
            Maximum log-fold-change threshold.
        remove_zero_pval : bool, default False
            Drop genes whose adjusted p-value is zero (i.e. infinite ``-log10 q``).
        max_q : float, optional
            Keep only genes with adjusted p-value ≤ this value.
        max_p : float, optional
            Keep only genes with raw p-value ≤ this value.
        """
        return self.do_for_rna(run_on_samples, st.rna_get_markers, **kwargs)
    
    def get_atacp_markers(self, run_on_samples = False, **kwargs):
        """
        Retrieve the differential accessibility table from ATAC peak results.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to retrieve from.
        de_slot : str, default 'markers'
            Key in ``adata.uns`` that holds the stored DA results.
        group_name : str, optional
            Which comparison group to retrieve. When the DA result contains
            exactly one group this defaults to that group automatically.
        min_pct : float, default 0.25
            Minimum fraction of cells in the group with the peak accessible.
        max_pct_reference : float, default 0.75
            Maximum fraction of cells in the reference group with the peak accessible.
        min_lfc : float, default 1
            Minimum log-fold-change threshold.
        max_lfc : float, default 100
            Maximum log-fold-change threshold.
        remove_zero_pval : bool, default False
            Drop peaks whose adjusted p-value is zero (i.e. infinite ``-log10 q``).
        max_q : float, optional
            Keep only peaks with adjusted p-value ≤ this value.
        max_p : float, optional
            Keep only peaks with raw p-value ≤ this value.
        """
        return self.do_for_atac_peaks(run_on_samples, st.rna_get_markers, **kwargs)
    
    def get_atacg_markers(self, run_on_samples = False, **kwargs):
        """
        Retrieve the differential activity table from ATAC gene-activity results.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to retrieve from.
        de_slot : str, default 'markers'
            Key in ``adata.uns`` that holds the stored DA results.
        group_name : str, optional
            Which comparison group to retrieve. When the DA result contains
            exactly one group this defaults to that group automatically.
        min_pct : float, default 0.25
            Minimum fraction of cells in the group with the feature accessible.
        max_pct_reference : float, default 0.75
            Maximum fraction of cells in the reference group with the feature accessible.
        min_lfc : float, default 1
            Minimum log-fold-change threshold.
        max_lfc : float, default 100
            Maximum log-fold-change threshold.
        remove_zero_pval : bool, default False
            Drop features whose adjusted p-value is zero (i.e. infinite ``-log10 q``).
        max_q : float, optional
            Keep only features with adjusted p-value ≤ this value.
        max_p : float, optional
            Keep only features with raw p-value ≤ this value.
        """
        return self.do_for_atac_gene_activity(run_on_samples, st.rna_get_markers, **kwargs)
    

    def get_rna_lr(
        self, run_on_samples = False, lr_slot = 'lr', source_labels = None, target_labels = None,
        ligand_complex = None, receptor_complex = None, 
        filter_fun = None, top_n: int = None,
        orderby: str | None = None,
        orderby_ascending: bool | None = None,
        orderby_absolute: bool = False
    ):
        """
        Retrieve the ligand-receptor interaction results as a DataFrame.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to retrieve from.
        lr_slot : str, default 'lr'
            ``adata.uns`` key containing the LR results.
        source_labels : list[str] | None, default None
            Filter to interactions where the source cell type is in this list.
        target_labels : list[str] | None, default None
            Filter to interactions where the target cell type is in this list.
        ligand_complex : str | None, default None
            Filter by ligand complex name.
        receptor_complex : str | None, default None
            Filter by receptor complex name.
        filter_fun : callable | None, default None
            Custom filter function applied to the results DataFrame.
        top_n : int | None, default None
            Return only the top-N interactions.
        orderby : str | None, default None
            Column to sort results by.
        orderby_ascending : bool | None, default None
            Sort ascending (``True``) or descending (``False``).
        orderby_absolute : bool, default False
            Sort by absolute value of ``orderby``.
        """
        return self.do_for_rna(
            run_on_samples, st.rna_get_lr,
            lr_slot = lr_slot, source_labels = source_labels,
            target_labels = target_labels, ligand_complex = ligand_complex,
            receptor_complex = receptor_complex, filter_fun = filter_fun,
            top_n = top_n, orderby = orderby, orderby_ascending = orderby_ascending,
            orderby_absolute = orderby_absolute
        )
    
    def get_rna_gsea(
        self, run_on_samples = False, gsea_slot = 'gsea', max_fdr = 1.00, max_p = 0.05
    ):
        """
        Retrieve GSEA results as a filtered DataFrame.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to retrieve from.
        gsea_slot : str, default 'gsea'
            ``adata.uns`` key containing the GSEA results.
        max_fdr : float, default 1.00
            Maximum BH-corrected FDR to include.
        max_p : float, default 0.05
            Maximum nominal p-value to include.
        """
        return self.do_for_rna(
            run_on_samples, st.rna_get_gsea, 
            gsea_slot = gsea_slot,
            max_fdr = max_fdr, max_p = max_p
        )
    
    def get_rna_opa(
        self, run_on_samples = False, opa_slot = 'opa', max_fdr = 1.00, max_p = 0.05
    ):
        """
        Retrieve over-representation analysis (OPA) results as a filtered DataFrame.

        Parameters
        ----------
        run_on_samples : bool | list[str] | str, default False
            Samples to retrieve from.
        opa_slot : str, default 'opa'
            ``adata.uns`` key containing the OPA results.
        max_fdr : float, default 1.00
            Maximum BH-corrected FDR to include.
        max_p : float, default 0.05
            Maximum nominal p-value to include.
        """
        return self.do_for_rna(
            run_on_samples, st.rna_get_opa, 
            gsea_slot = opa_slot, max_fdr = max_fdr, max_p = max_p
        )


    def save(self, fdir = None, subset = None, save_samples = True, save_raw = False):

        import os
        if fdir is None: fdir = self.directory
        if subset is not None: self.subset = subset

        if save_raw:
            warning('save_raw = True is passed. we do not recommend saving raw matrices.')
            warning('this may increase the data size to a great extent, yet seldomly useful.')
            warning('you should run background correction with qc and it is not needed since then.')

        os.makedirs(fdir, exist_ok = True)
        self.metadata.save(os.path.join(fdir, 'metadata.tsv'))

        def save_h5mu_handle_recreate(h5, fpath):
            try: h5.write_h5mu(fpath)
            except:
                warning('attempted to re-create the h5mu file.')
                rec = mu.MuData({x: h5.mod[x] for x in h5.mod.keys()})
                rec.write_h5mu(fpath)

        if self.mudata is not None:
            if (self.subset is None) or (fdir != self.directory):
                info(f"main dataset write to {os.path.join(fdir, 'integrated.h5mu')}")
                save_h5mu_handle_recreate(self.mudata, os.path.join(fdir, 'integrated.h5mu'))
                self.directory = fdir

            else: 
                info(f"main dataset write to {os.path.join(fdir, 'subsets', self.subset + '.h5mu')}")
                save_h5mu_handle_recreate(self.mudata, os.path.join(fdir, 'subsets', self.subset + '.h5mu'))

        if not save_samples: return

        if (self.modalities is not None) and (len(self.modalities) > 0):
            info('saving individual samples. (pass `save_samples = False` to skip)')
            for key in self.modalities.keys():
                os.makedirs(os.path.join(fdir, key), exist_ok = True)
                for sample in pprog(list(self.modalities[key].keys()), desc = f'modality [{key}]'):
                    
                    if '.raw' in self.modalities[key][sample].uns.keys() and (not save_raw):
                        del self.modalities[key][sample].uns['.raw']
                        warning(f'raw matrix is not saved for {key}/{sample}. pass save_raw = True to save')
                    
                    # save individual samples
                    self.modalities[key][sample].write_h5ad(
                        os.path.join(fdir, key, f'{sample}.h5ad')
                    )
        
        # save specification and dataset information
        import pickle
        with open(os.path.join(fdir, 'spec.pkl'), 'wb') as fspec:
            pickle.dump({
                'spec': self.version
            }, fspec)


    def push(
        self, 
        columns: list[str] | None = None, 
        mods: list[str] | None = None, 
        common: bool | None = None, 
        prefixed: bool | None = None, 
        drop: bool = False, 
        only_drop: bool = False
    ):
        self.mudata.push_obs(
            columns = columns, mods = mods, common = common,
            prefixed = prefixed, drop = drop, only_drop = only_drop
        )

    
    def pull(
        self,
        columns: list[str] | None = None,
        mods: list[str] | None = None, common: bool | None = None, 
        join_common: bool | None = None, 
        nonunique: bool | None = None, 
        join_nonunique: bool | None = None, 
        unique: bool | None = None, 
        prefix_unique: bool | None = True, 
        drop: bool = False, only_drop: bool = False
    ):
        self.mudata.pull_obs(
            columns = columns, mods = mods, 
            common = common, join_common = join_common,
            nonunique = nonunique, join_nonunique = join_nonunique,
            unique = unique, prefix_unique = prefix_unique,
            drop = drop, only_drop = only_drop
        )


    def joint(
        self, expm, name1 = 'self', name2 = 'addition',
        keep_obs = ['sample', 'batch', 'modality', 'taxa', 'group', 'cell.type'],
        keep_obsm = [],
        keep_layers = ['counts'],
        concat_label = 'origin',
        concat_dump = 'joint'
    ):
        
        concat_meta = exprmat.reader.metadata.metadata(
            locations = None, modality = None, default_taxa = None, 
            df = pd.concat(
                (self.metadata.dataframe, expm.metadata.dataframe),
                join = 'inner', ignore_index = True
        ))

        concat_dict = merge_dictionary(
            self.modalities,
            expm.modalities
        )

        self.pull(columns = keep_obs)
        expm.pull(columns = keep_obs)
        concat_mudata = mu.concat(
            {name1: self.mudata, name2: expm.mudata},
            join = 'outer', label = concat_label
        )

        merge = experiment(
            meta = concat_meta,
            mudata = concat_mudata,
            modalities = concat_dict,
            dump = concat_dump
        )

        if merge.mudata is not None:
            for mod in merge.mudata.mod_names:
                del merge.mudata[mod].obs

                for obsm in list(merge.mudata[mod].obsm_keys()):
                    if not obsm in keep_obsm:
                        del merge.mudata[mod].obsm[obsm]

                for layer in list(merge.mudata[mod].layers.keys()):
                    if not layer in keep_layers:
                        del merge.mudata[mod].layers[layer]
                

        merge.push(columns = keep_obs + ['origin'])
        merge.mudata['rna'].var = st.search_genes(concat_mudata['rna'].var.index)
        return merge
    

    def link_barcode(
        self, mod1, sample1, barcode1, mod2, sample2, barcode2, 
        unify_sample = 'multi'
    ):

        if self.mudata:
            mod1obs = self.mudata.mod[mod1].obs_names.tolist()
            mod2obs = self.mudata.mod[mod2].obs_names.tolist()
            bc1 = self.mudata.mod[mod1].obs[barcode1].tolist()
            bc2 = self.mudata.mod[mod2].obs[barcode2].tolist()
            purebc2 = [x.replace(sample2 + ':', '') for x in bc2 if x.startswith(sample2 + ':')]

            uname_mapping = {}
            counter = 1
            for x1 in bc1:
                if x1.startswith(sample1 + ':'):
                    if x1.replace(sample1 + ':', '') in purebc2:
                        uname_mapping[sample1 + ':' + x1.replace(sample1 + ':', '')] = unify_sample + ':' + str(counter)
                        uname_mapping[sample2 + ':' + x1.replace(sample1 + ':', '')] = unify_sample + ':' + str(counter)
                        counter += 1
            
            mod1obs = [uname_mapping[x] if x in uname_mapping.keys() else y for x, y in zip(bc1, mod1obs)]
            mod2obs = [uname_mapping[x] if x in uname_mapping.keys() else y for x, y in zip(bc2, mod2obs)]
            
            n_replace = 0
            for x in mod1obs:
                if x.startswith(unify_sample + ':'): n_replace += 1

            info(f'unified {n_replace} from two modalities.') 
            self.mudata.mod[mod1].obs_names = mod1obs
            self.mudata.mod[mod2].obs_names = mod2obs
        
        else:
            mod1obs = self[mod1][sample1].obs_names.tolist()
            mod2obs = self[mod2][sample2].obs_names.tolist()
            bc1 = self[mod1][sample1].obs[barcode1].tolist()
            bc2 = self[mod2][sample2].obs[barcode2].tolist()
            purebc2 = [x.replace(sample2 + ':', '') for x in bc2 if x.startswith(sample2 + ':')]

            uname_mapping = {}
            counter = 1
            for x1 in bc1:
                if x1.startswith(sample1 + ':'):
                    if x1.replace(sample1 + ':', '') in purebc2:
                        uname_mapping[sample1 + ':' + x1.replace(sample1 + ':', '')] = unify_sample + ':' + str(counter)
                        uname_mapping[sample2 + ':' + x1.replace(sample1 + ':', '')] = unify_sample + ':' + str(counter)
                        counter += 1
            
            mod1obs = [uname_mapping[x] if x in uname_mapping.keys() else y for x, y in zip(bc1, mod1obs)]
            mod2obs = [uname_mapping[x] if x in uname_mapping.keys() else y for x, y in zip(bc2, mod2obs)]
            n_replace = 0
            for x in mod1obs:
                if x.startswith(unify_sample + ':'): n_replace += 1

            info(f'unified {n_replace} from two modalities.') 
            self[mod1][sample1].obs_names = mod1obs
            self[mod2][sample2].obs_names = mod2obs


    # magic accessors

    def __getitem__(self, key):

        if self.mudata:
            if key in self.mudata.mod.keys():
                return self.mudata[key]
            else: 
                warning(f'key must be one of [{", ".join(list(self.mudata.mod.keys()))}]')
                error(f'no integrated modality named `{key}`.')
        
        else:
            if key in self.modalities.keys():
                return self.modalities[key]
            else:
                warning(f'key must be one of [{", ".join(list(self.modalities.keys()))}]')
                error(f'no modality named `{key}` (dataset not integrated).')
            

    def __str__(self):

        from exprmat.ansi import green, cyan, red, yellow, common_length, annot
        from io import StringIO as string_io
        output = string_io()

        def print_anndata(adata: ad.AnnData, strio):
            print(yellow('annotated data'), 'of size', adata.n_obs, '×', adata.n_vars)

            import textwrap
            if adata.obs is not None and len(adata.obs) > 0:
                print(green('    obs'), ':', end = ' ', file = strio)

                wrapped = wrap([
                    x + ' ' + annot('<' + dtypestr(adata.obs[x].dtype) + '>')
                    for x in adata.obs.keys()
                ], n = 90, sep = ' ')

                for nline in range(len(wrapped)):
                    if nline == 0: print(wrapped[nline], file = strio)
                    else: print(' ' * 9, wrapped[nline], file = strio)

            if adata.var is not None and len(adata.var) > 0:
                print(green('    var'), ':', end = ' ', file = strio)
                
                wrapped = wrap([
                    x + ' ' + annot('<' + dtypestr(adata.var[x].dtype) + '>')
                    for x in adata.var.keys()
                ], n = 90, sep = ' ')

                for nline in range(len(wrapped)):
                    if nline == 0: print(wrapped[nline], file = strio)
                    else: print(' ' * 9, wrapped[nline], file = strio)
            
            if adata.layers is not None and len(adata.layers) > 0:
                print(green(' layers'), ':', end = ' ', file = strio)
                
                wrapped = wrap([
                    x + ' ' + annot('<' + dtypestr(adata.layers[x].dtype) + '>')
                    for x in adata.layers.keys()
                ], n = 90, sep = ' ')

                for nline in range(len(wrapped)):
                    if nline == 0: print(wrapped[nline], file = strio)
                    else: print(' ' * 9, wrapped[nline], file = strio)
            
            if adata.obsm is not None and len(adata.obsm) > 0:
                print(green('   obsm'), ':', end = ' ', file = strio)

                wrapped = wrap([
                    x + ' ' + annot('<' + dtypemat(adata.obsm[x]) + '>')
                    for x in adata.obsm.keys()
                ], n = 90, sep = ' ')

                for nline in range(len(wrapped)):
                    if nline == 0: print(wrapped[nline], file = strio)
                    else: print(' ' * 9, wrapped[nline], file = strio)
            
            if adata.varm is not None and len(adata.varm) > 0:
                print(green('   varm'), ':', end = ' ', file = strio)
                
                wrapped = wrap([
                    x + ' ' + annot('<' + dtypemat(adata.varm[x]) + '>')
                    for x in adata.varm.keys()
                ], n = 90, sep = ' ')

                for nline in range(len(wrapped)):
                    if nline == 0: print(wrapped[nline], file = strio)
                    else: print(' ' * 9, wrapped[nline], file = strio)

            if adata.obsp is not None and len(adata.obsp) > 0:
                print(green('   obsp'), ':', end = ' ', file = strio)
                
                wrapped = wrap([
                    x + ' ' + annot('<' + dtypemat(adata.obsp[x]) + '>')
                    for x in adata.obsp.keys()
                ], n = 90, sep = ' ')

                for nline in range(len(wrapped)):
                    if nline == 0: print(wrapped[nline], file = strio)
                    else: print(' ' * 9, wrapped[nline], file = strio)

            if adata.varp is not None and len(adata.varp) > 0:
                print(green('   varp'), ':', end = ' ', file = strio)
                
                wrapped = wrap([
                    x + ' ' + annot('<' + dtypemat(adata.varp[x]) + '>')
                    for x in adata.varp.keys()
                ], n = 90, sep = ' ')

                for nline in range(len(wrapped)):
                    if nline == 0: print(wrapped[nline], file = strio)
                    else: print(' ' * 9, wrapped[nline], file = strio)

            if adata.uns is not None and len(adata.uns) > 0:
                print(green('    uns'), ':', end = ' ', file = strio)
                wrapped = textwrap.wrap(' '.join(adata.uns.keys()), width = 90)
                for nline in range(len(wrapped)):
                    if nline == 0: print(wrapped[nline], file = strio)
                    else: print(' ' * 9, wrapped[nline], file = strio)
            

        if self.mudata is not None:
            if self.subset is None:
                print(red('integrated dataset'), 'of size', self.mudata.n_obs, '×', self.mudata.n_vars, file = output)
            else: print(red('subset'), self.subset, 'of size', self.mudata.n_obs, '×', self.mudata.n_vars, file = output)
            print('contains modalities:', ', '.join([cyan(x) for x in list(self.mudata.mod.keys())]), file = output)

            for m in self.mudata.mod.keys():
                print('\n', 'modality', cyan(f'[{m}]'), file = output)
                print_anndata(self.mudata.mod[m], output)
            
            print('', file = output)

        else: print(red('[!]'), 'dataset not integrated.', file = output)

        if self.modalities is None or len(self.modalities) == 0:
            print(red('[*]'), 'samples not loaded from disk.', file = output)
        
        else:
            print(red('[*]'), 'composed of samples:', file = output)
            len_mod = 5
            len_batch = 5
            len_sample = 5
            
            for i_loc, i_sample, i_batch, i_grp, i_mod, i_taxa in zip(
                self.metadata.dataframe['location'], 
                self.metadata.dataframe['sample'], 
                self.metadata.dataframe['batch'], 
                self.metadata.dataframe['group'], 
                self.metadata.dataframe['modality'], 
                self.metadata.dataframe['taxa']
            ):
                if len(i_mod) > len_mod: len_mod = len(i_mod)
                if len(i_batch) > len_batch: len_batch = len(i_batch)
                if len(i_sample) > len_sample: len_sample = len(i_sample)

            if len_batch > 30: len_batch = 30
            if len_sample > 30: len_sample = 30

            for i_loc, i_sample, i_batch, i_grp, i_mod, i_taxa in zip(
                self.metadata.dataframe['location'], 
                self.metadata.dataframe['sample'], 
                self.metadata.dataframe['batch'], 
                self.metadata.dataframe['group'], 
                self.metadata.dataframe['modality'], 
                self.metadata.dataframe['taxa']
            ):
                if '.' in i_mod: continue
                loaded = False
                if (self.modalities is not None) and \
                   (i_mod in self.modalities.keys()) and \
                   (i_sample in self.modalities[i_mod].keys()):
                    loaded = True

                p_sample = i_sample if len(i_sample) < 30 else i_sample[:27] + ' ..'
                p_batch = i_batch if len(i_batch) < 30 else i_batch[:27] + ' ..'
                print(
                    ' ',
                    common_length(i_sample, len_sample), ' ',
                    cyan(common_length(i_mod, len_mod)), 
                    yellow(f'{i_taxa:4}'), ' ',
                    f'batch {green(common_length(i_batch, len_batch))}', ' ',
                    'of size',
                    red('dataset not loaded') if not loaded else 
                    f'{green(str(self.modalities[i_mod][i_sample].n_obs))} × ' +
                    f'{yellow(str(self.modalities[i_mod][i_sample].n_vars))}' + 
                    (' (with raw)' if ('.raw' in self.modalities[i_mod][i_sample].uns.keys()) else ''),
                    file = output
                )

        return output.getvalue()


    def __repr__(self):

        return (
            f'<exprmat.experiment> @ {hex(id(self))} (spec:{self.version if self.version else 1}) ' + 
            f'from "{self.directory if self.directory else "."}" ' + (f'(subset [{self.subset}]) ' if self.subset else '') +
            f'{"integrated" if self.mudata else "not integrated"}{", samples loaded" if len(self.modalities) > 0 else ""} ({len(self.metadata.dataframe)} samples)'
        )

    pass


def merge_dictionary(dict1, dict2):

    for key in dict2.keys():
        if key not in dict1.keys():
            dict1[key] = dict2[key]
        elif isinstance(dict2[key], dict) and isinstance(dict1[key], dict):
            merge_dictionary(dict1[key], dict2[key])
        else: error('conflicting keys.')
    
    return dict1


def load_experiment(direc, load_samples = True, load_subset = None):
    '''
    Load an experiment dump directory.

    Parameters
    ----------
    direc: str
        Experiment dump directory

    load_samples: bool = True
        Whether to load individual samples. This must be set to True if you did not
        merge the samples to generate an integrated dataset, or else nothing will be loaded.
        After integration, you may choose not to load samples if you did not need them.
    
    load_subset: str | None = None
        Whether to load subset dataset. If `None`, the loader searches and load
        the integrated dataset by default. If you have build subsets with
        :func:`experiment.build_subset`, you may load a subset instead of the whole dataset.
    '''

    import os
    if not os.path.exists(os.path.join(direc, 'metadata.tsv')):
        error('failed to load st. [metadata.tsv] file not found.')
    
    # read individual modality and sample
    meta = load_metadata(os.path.join(direc, 'metadata.tsv'))

    # load specification
    version = load_experiment_specification(direc)
    
    # update the object to the newest version
    from exprmat.reader.updater import update
    version = update(meta, direc, version)

    meta.dataframe = meta.dataframe.loc[
        ['.' not in x for x in meta.dataframe['modality']], :
    ].copy()

    modalities = {}
    if load_samples:
        prog = pprog(desc = 'loading samples', total = len(meta.dataframe['sample']))
        for modal, samp in zip(meta.dataframe['modality'], meta.dataframe['sample']):
            prog.update()
            if '.' in modal: continue
            attempt = os.path.join(direc, modal, samp + '.h5ad')
            if os.path.exists(attempt):
                if modal not in modalities.keys(): modalities[modal] = {}
                modalities[modal][samp] = sc.read_h5ad(attempt)
            else: warning(f'sample dump [{modal}/{samp}] missing.')

    mdata = None
    subset = None
    if load_subset is None:
        if os.path.exists(os.path.join(direc, 'integrated.h5mu')):
            mdata = mu.read_h5mu(os.path.join(direc, 'integrated.h5mu'))
    else:
        subset = load_subset
        if os.path.exists(os.path.join(direc, 'subsets', load_subset + '.h5mu')):
            mdata = mu.read_h5mu(os.path.join(direc, 'subsets', load_subset + '.h5mu'))

    expr = experiment(
        meta = meta, 
        mudata = mdata, 
        modalities = modalities, 
        dump = direc,
        subset = subset,
        version = version
    )

    return expr


def load_experiment_specification(direc):
    
    import pickle
    if os.path.exists(os.path.join(direc, 'spec.pkl')):
        with open(os.path.join(direc, 'spec.pkl'), 'rb') as fspec:
            return pickle.load(fspec)['spec']
    
    # the oldest specification, before the versioning system implemented.
    else: return 1 