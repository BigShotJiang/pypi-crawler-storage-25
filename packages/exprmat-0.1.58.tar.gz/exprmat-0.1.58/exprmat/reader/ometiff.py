
from lxml import etree
from tifffile import TiffFile as tiff
import os
import numpy as np
from typing import List, Dict, Tuple, Optional, Union, Iterable
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor
import threading

from exprmat import error, warning, info


class ometifffile(tiff):

    def __init__(self, file_path, *args, max_workers = 4, enable_cache = True, **kwargs):
        
        # initialize the parent class
        super().__init__(file_path, *args, **kwargs)

        # store the file path
        self.file_path = file_path

        # Extract biomarker information
        self.extract_biomarkers()


    def extract_biomarkers(self) -> None:
        """
        Extract biomarker information from the OME.TIFF file.
        Stores results in self.biomarkers and self.channel_info.
        """
        self.biomarkers = []
        self.planes = []
        
        # read ome metadata
        if not hasattr(self, 'ome_metadata'):
            error('the file is not ome-tiff.')

        meta = etree.fromstring(self.ome_metadata.encode('utf-8'))
        pixels = meta.xpath(".//*[local-name()='Image']/*[local-name()='Pixels']")
        if len(pixels) != 1: error('at present, only tiff files with only one ome image structure is supported.')
        
        # extract sequential data from metadata
        channels = []
        current_ifd = 0
        sections = []

        i = 0
        for item in pixels[0].iterchildren():
            
            self.order = pixels[0].get('DimensionOrder')
            if item.tag.endswith('Channel'):
                channels.append({
                    'id': item.get('ID'),
                    'name': item.get('Name'),
                    'color': int(item.get('Color')),
                    'bpp': int(item.get('SamplesPerPixel')),
                    'index': i
                })

                i += 1
                self.biomarkers.append(item.get('Name'))
            
            if item.tag.endswith('TiffData'):
                current_ifd = int(item.get('IFD'))
            
            if item.tag.endswith('Plane'):
                plane = {
                    'c': int(item.get('TheC')),
                    'z': int(item.get('TheZ')),
                    't': int(item.get('TheT')),
                    'w': int(pixels[0].get('SizeX')),
                    'h': int(pixels[0].get('SizeY')),
                    'ifd': current_ifd
                }

                plane['channel'] = channels[plane['c']]
                sections.append(plane)
        
        self.planes = sections
        self.channels = channels


    def summary(self) -> None:

        from exprmat.ansi import green, cyan, red, yellow, common_length, annot
        print(red('ometiff'), 'from', os.path.basename(self.file_path))
        print('with', len(self.series), green('series'))

        print('\nwith', len(self.planes), green('planes'))
        for section in self.planes:
            print(' ',
                green(common_length(str(section['w']), 6, right = True)) + ' [w]',
                green(common_length(str(section['h']), 6, right = True)) + ' [h]',
                red(common_length(str(section['c']), 3, right = True)) + ' [c]',
                red(common_length(str(section['z']), 3, right = True)) + ' [z]',
                red(common_length(str(section['t']), 3, right = True)) + ' [t]',
                str(section['channel']['name'])
            )
        
        print('\nwith', len(self.series[0].levels), green('levels'))
        for i, level in enumerate(self.series[0].levels):
            print(' ', yellow(f'level {i}'), 'of shape', level.pages[0].shape, 'with', len(level.pages), 'pages')

    
    def read_region(self, level = 0, x = None, y = None, c = [0]):
        '''
        Retrieve image in C-Y-X order.
        Note that the common saving architecture in python recognize Y-X-C.
        '''
        store = self.series[0].aszarr()
        import zarr
        z = zarr.open(store, mode = 'r')

        def parse_selector(n, f = '?'):
            if n is None: return slice(None)
            elif isinstance(n, tuple) and len(n) == 2:
                return slice(*n)
            elif isinstance(n, list):
                if f != 'c': return n
                else: 
                    channel_pres = []
                    for k in n:
                        if isinstance(k, int): channel_pres.append(k)
                        elif k in self.biomarkers: channel_pres.append(self.biomarkers.index(k))
                        else: error('failed to specify channel with names or indices.')
                    return channel_pres
                
            else: error(f'unrecognized index pattern for {f}.')

        selectors = []
        selectors.append(parse_selector(y, 'y'))
        selectors.append(parse_selector(x, 'x'))
        selectors.append(parse_selector(c, 'c'))

        yxc = z[level][tuple(selectors)]
        return yxc.transpose(2, 0, 1)


    def mix_channels(self, level = 0, x = None, y = None, c = [0], intensities = None, colormix = None):
        
        cyx = self.read_region(level, x, y, c)
        nc, ny, nx = cyx.shape

        def int_to_rgb(color_int):
            c = color_int & 0xFFFFFFFF
            r = (c >> 16) & 0xFF
            g = (c >> 8)  & 0xFF
            b =  c        & 0xFF
            return r / 255, g / 255, b / 255
        
        def named_to_rgb(named):
            from matplotlib.colors import to_rgb
            return to_rgb(named)
        
        # mix color channel. if colormix is None, use the predefined colors from channels.
        # otherwise, the length of the mixer must match the channels selected.

        r = np.zeros((ny, nx))
        g = np.zeros((ny, nx))
        b = np.zeros((ny, nx))

        if colormix:
            if len(colormix) != len(c):
                error('color mixer must of the same length of channels')
        
        if intensities is None:
            intensities = [1] * len(c)
            
        for i, channel in enumerate(c):
            attempt_channel = self.channels[channel] if isinstance(channel, int) else \
                self.channels[self.biomarkers.index(channel)]
            rx, gx, bx = named_to_rgb(colormix[i]) if colormix \
                else int_to_rgb(attempt_channel['color'])
            ch = cyx[i, :, :]
            r += rx * ch * intensities[i]
            g += gx * ch * intensities[i]
            b += bx * ch * intensities[i]
        
        stk = np.stack([r, g, b], axis = 2)
        stk[stk > 255] = 255
        stk[stk < 0] = 0
        stk = stk.astype('uint8')
        return stk
    
    
    def save_region(self, path, **kwargs):
        
        from PIL import Image
        img = Image.fromarray(self.mix_channels(**kwargs))
        img.save(path)