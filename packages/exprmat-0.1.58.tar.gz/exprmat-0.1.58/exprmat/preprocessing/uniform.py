'''
Normalization in uniform normal space.
'''

import numpy as np
from exprmat.preprocessing.sparse import sparse_zscore_column
from exprmat.preprocessing.sctransform.transform import vst


def scale(E, gene_mean = None, gene_stdev = None):
    from scipy.sparse import issparse
    if issparse(E):
        return sparse_zscore_column(E, gene_mean, gene_stdev)
    else:
        if gene_mean is None:
            gene_mean = E.mean(0)
        if gene_stdev is None:
            gene_stdev = np.sqrt(np.var(E, axis = 0, ddof = 1))
        return (E - gene_mean) / (gene_stdev + 1e-8)


def sct(
    E, var = None, latent_variable = ['log.umi'], 
    min_cells = 5, min_variance = float('-inf'), bw_adjust = 3,
    clip_range = None
):
    return vst(
        E, cell_attr = var, latent_var = latent_variable, method = 'poisson',
        residual_type = 'pearson', min_cells = min_cells, min_variance = min_variance,
        bw_adjust = bw_adjust, res_clip_range = clip_range
    )