
import numpy as np
import pandas as pd
from scipy import sparse
from typing import Optional, Union, Dict, Any
from exprmat import error, warning, info


class soup_channel:
    """
    Container for single-cell RNA-seq data and soup contamination analysis.

    Matches R SoupChannel object structure with:
    - tod: table of droplets (raw counts)
    - toc: table of counts (filtered cells)
    - metadata: cell metadata (not metadata)
    - soup_profile: background contamination profile
    - clusters: clustering information

    For tod and toc matrices, rows are genes and columns are cells. (R convention)
    """

    def __init__(
        self,
        tod: sparse.csr_matrix,
        toc: sparse.csr_matrix,
        metadata: Optional[pd.DataFrame] = None,
        calc_soup_profile: bool = True,
        **kwargs
    ):
        
        self.tod = tod  # unfiltered
        self.toc = toc  # filtered

        # gene information
        self.n_genes = toc.shape[0]
        self.n_cells = toc.shape[1]

        # store gene names if provided
        self.gene_names = kwargs.get('gene_names', None)
        if self.gene_names is None:
            self.gene_names = [f"gene_{i}" for i in range(self.n_genes)]

        # initialize metaData with R naming
        if metadata is None:
            # create default metadata with n.umi column
            self.metadata = pd.DataFrame({
                'n.umi': np.array(toc.sum(axis=0)).flatten()
            }, index=[f"cell.{i}" for i in range(self.n_cells)])
        else:
            self.metadata = metadata
            # ensure n.umi column exists
            if 'n.umi' not in self.metadata.columns:
                self.metadata['n.umi'] = np.array(toc.sum(axis=0)).flatten()

        # initialize other attributes
        self.soup_profile = None
        self.clusters = None
        self.dr = None  # dimension reduction
        self.fit = {}  # store fitting results

        # store contamination fraction in metaData as 'rho'
        if 'rho' not in self.metadata.columns:
            self.metadata['rho'] = None

        # store any additional parameters
        for key, value in kwargs.items():
            if key != 'gene_names':  # Already handled
                setattr(self, key, value)

        # calculate soup profile if requested
        if calc_soup_profile:
            self.calc_soup_profile()


    def calc_soup_profile(self):
        
        # Get UMI counts per droplet
        droplet_umis = np.array(self.tod.sum(axis = 0)).flatten()

        # match R's default soupRange = c(0, 100)
        # this means > 0 AND < 100, not just < 100
        empty_droplets = (droplet_umis > 0) & (droplet_umis < 100)

        if np.sum(empty_droplets) > 0:
            soup_counts = np.array(self.tod[:, empty_droplets].sum(axis=1)).flatten()
            total_soup = np.sum(soup_counts)

            if self.gene_names is not None: gene_index = self.gene_names
            else: gene_index = [f"gene:{i:05d}" for i in range(self.n_genes)]

            self.soup_profile = pd.DataFrame({
                'est': soup_counts / total_soup if total_soup > 0 else np.zeros(self.n_genes),
                'counts': soup_counts
            }, index = gene_index)

        else:
            # no droplets in range
            if self.gene_names is not None: gene_index = self.gene_names
            else: gene_index = [f"gene:{i:05d}" for i in range(self.n_genes)]

            self.soup_profile = pd.DataFrame({
                'est': np.zeros(self.n_genes),
                'counts': np.zeros(self.n_genes)
            }, index = gene_index)


    def set_contamination_fraction(self, cont_frac, forced = False):
        """
        Set contamination fraction

        Parameters
        ----------
        cont_frac : float or dict
            Contamination fraction (0-1). Can be constant or cell-specific.
        
        forced : bool
            Allow very high contamination fractions with warning
        """

        # validation matching R behavior
        if isinstance(cont_frac, (int, float)):
            if cont_frac > 1:
                error("contamination fraction greater than 1 detected. This is impossible.")
            if cont_frac > 0.5:
                if forced:
                    warning(f"extremely high contamination estimated ({cont_frac:.2g}).")
                    warning(f"proceeding with forced = True.")
                else: error(f"extremely high contamination estimated ({cont_frac:.2g}).")
            elif cont_frac > 0.3:
                warning(f"estimated contamination is very high ({cont_frac:.2g}).")
            self.metadata['rho'] = cont_frac

        else:
            # cell-specific contamination
            for cell_id, rho in cont_frac.items():
                if cell_id in self.metadata.index:
                    self.metadata.loc[cell_id, 'rho'] = rho


    def set_cluster(self, clusters):
        
        if hasattr(clusters, '__len__'):
            if len(clusters) != self.n_cells:
                error("invalid cluster specification. length must match number of cells.")

            # Convert to string to match R behavior
            self.metadata['clusters'] = [str(c) for c in clusters]
            self.clusters = np.array([str(c) for c in clusters])
        else: error("invalid cluster specification.")

        # Check for NAs
        if pd.isna(self.metadata['clusters']).any():
            error("na's found in cluster names.")


    def set_soup_profile(self, soup_prof):

        if 'est' not in soup_prof.columns:
            error("est column missing from soup_prof")
        if 'counts' not in soup_prof.columns:
            error("counts column missing from soup_prof")

        self.soup_profile = soup_prof


    def set_dr(self, dr, name = None):
        
        dr = pd.DataFrame(dr)
        if dr.shape[1] < 2:
            error("need at least two reduced dimensions.")

        if dr.shape[0] != self.n_cells:
            error("dr rows must match number of cells.")

        if name: col_names = [f"{name}.1", f"{name}.2"]
        else: col_names = ["dr.1", "dr.2"]

        self.metadata[col_names[0]] = dr.iloc[:, 0].values
        self.metadata[col_names[1]] = dr.iloc[:, 1].values
        self.dr = col_names

