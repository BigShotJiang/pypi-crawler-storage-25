
import numba as nb
import numpy as np

from typing import Literal

import anndata as ad
import numpy as np
from scipy.sparse import csr_matrix
from scipy.stats import false_discovery_control
from exprmat import error, warning, info

from .dirichlet_multinomial import (
    estimate_alpha,
    eval_log_likelihood_dirichlet_multinomial,
    evaluate_simulations_dirichlet_multinomial,
)

from .multinomial import (
    eval_log_likelihood_multinomial,
    evaluate_simulations_multinomial,
)

from .sgt import simple_good_turing


@nb.njit
def jit_intersect1d(
    ar1: np.ndarray, ar2: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    JIT compiled version of numpy.intersect1d

    Always assumes that the input arrays are unique and always returns the indices
    """
    ar1 = ar1.ravel()
    ar2 = ar2.ravel()

    aux = np.concatenate((ar1, ar2))
    aux_sort_indices = np.argsort(aux, kind="mergesort")
    aux = aux[aux_sort_indices]

    mask = aux[1:] == aux[:-1]
    int1d = aux[:-1][mask]

    ar1_indices = aux_sort_indices[:-1][mask]
    ar2_indices = aux_sort_indices[1:][mask] - ar1.size

    return int1d, ar1_indices, ar2_indices


# The minimum UMI threshold to immediately discard barcodes
MIN_UMI_THRESHOLD = 500
# The number of expected cells in the dataset
N_EXPECTED_CELLS = 20000
# Considers the 95th percentile cell as the highest UMI total
MAX_PERCENTILE = 0.95
# The ratio with which to set the immediate acceptance threshold (the candidate upper bound)
MAX_MIN_RATIO = 5
# The fraction of the median accepted cells to set the candidate lower bound
UMI_MIN_FRAC = 0.01
# The index lower bound for ambient barcodes (descending sort of barcode UMI sums)
AMB_INDEX_MIN = 45000
# The index upper bound for ambient barcodes (descending sort of barcode UMI sums)
AMB_INDEX_MAX = 90000
# The number of simulations to perform
N_SIMULATIONS = 10000
# The threshold for the false discovery rate
FDR_THRESHOLD = 0.01
# The seed for the random number generator
SEED = 42


def eval_pvalue(
    obs: float,
    background: np.ndarray,
) -> float:
    r = np.sum(background <= obs)
    return float((r + 1) / (background.size + 1))


def score_candidate_bcs(
    obs_llik: np.ndarray,
    obs_totals: np.ndarray,
    sim_llik: np.ndarray,
) -> np.ndarray:
    pvalues = np.zeros(obs_totals.size)
    for idx in np.arange(pvalues.size):
        pvalues[idx] = eval_pvalue(
            obs_llik[idx],
            sim_llik[obs_totals[idx]],
        )
    return false_discovery_control(pvalues, method = "bh")


def emptydrops(
    adata: ad.AnnData,
    min_umi_threshold: int = MIN_UMI_THRESHOLD,
    n_expected_cells: int = N_EXPECTED_CELLS,
    max_percentile: float = MAX_PERCENTILE,
    max_min_ratio: float | int = MAX_MIN_RATIO,
    umi_min_frac: float = UMI_MIN_FRAC,
    amb_ind_min: int = AMB_INDEX_MIN,
    amb_ind_max: int = AMB_INDEX_MAX,
    n_iter: int = N_SIMULATIONS,
    fdr_threshold: float = FDR_THRESHOLD,
    seed: int = SEED,
    verbose: bool = False,
    method: Literal["dirichlet", "multinomial"] = "multinomial"
) -> tuple[ad.AnnData, dict]:
    
    # Enforce typing on inputs
    min_umi_threshold = int(min_umi_threshold)
    n_expected_cells = int(n_expected_cells)
    max_percentile = float(max_percentile)
    max_min_ratio = int(max_min_ratio)
    umi_min_frac = float(umi_min_frac)
    amb_ind_min = int(amb_ind_min)
    amb_ind_max = min(int(amb_ind_max), adata.shape[0])
    n_iter = int(n_iter)
    fdr_threshold = float(fdr_threshold)
    seed = int(seed)

    if not isinstance(adata.X, csr_matrix):
        adata.X = csr_matrix(adata.X)

    # Extract matrix from AnnData object
    matrix = adata.X

    if min_umi_threshold <= 0:
        error("threshold must be positive non-zero")

    # Determine cell UMI counts
    cell_umi_counts = np.array(matrix.sum(axis = 1)).flatten().astype(int)
    if np.all(cell_umi_counts < min_umi_threshold):
        warning(f"all barcodes have less than {min_umi_threshold} UMIs.")
        return (adata[np.zeros(adata.shape[0], dtype = bool)], dict())

    # Identify ambient cells
    if cell_umi_counts.size < amb_ind_min:
        warning(f'returning simply filtered anndata (umis < {min_umi_threshold})')
        warning(f'found only {cell_umi_counts.size} barcodes. need at least {amb_ind_min + 1} barcodes')
        warning(f'not enough barcodes to identify ambient cells.')
        mask = cell_umi_counts < min_umi_threshold
        return adata[mask], dict()

    argsorted_cell_umi_counts = np.argsort(cell_umi_counts)[::-1]  # descending order
    ambient_mask = argsorted_cell_umi_counts[amb_ind_min:amb_ind_max]

    # Extract ambient matrix
    amb_matrix = matrix[ambient_mask]
    ambient_gene_sum = np.array(amb_matrix.sum(axis=0)).flatten()

    # Convert probabilities
    probs = simple_good_turing(ambient_gene_sum)

    # Estimate alpha
    # Estimate alpha only if using dirichlet method
    if method == "dirichlet":
        alpha = estimate_alpha(amb_matrix, probs)
        info(f"dirichlet distribution, ptimized alpha = {alpha:.4f}")
    else:
        info("using multinomial model (no alpha estimation)...")
        alpha = None

    # Identify the retainment boundary
    max_ind = int(np.round(n_expected_cells * (1.0 - max_percentile)))
    n_umi_max = int(cell_umi_counts[argsorted_cell_umi_counts[max_ind]])
    retain = int(max(n_umi_max / max_min_ratio, 1))
    n_valid = int(np.sum(cell_umi_counts >= retain))
    info(f"retainment boundary: {retain} umi's ({n_valid} auto-accepted cells)")

    # Identify the auto-reject boundary
    median_idx = min(n_valid // 2, len(cell_umi_counts) - 1)
    median_umi = cell_umi_counts[argsorted_cell_umi_counts[median_idx]]
    reject_boundary = max(
        min_umi_threshold,
        int(np.round(umi_min_frac * median_umi)),
    )
    info(f"rejection boundary: {reject_boundary} umi's")

    # Score simulations (now with multiprocessing)
    candidate_mask = (cell_umi_counts < retain) & (cell_umi_counts >= reject_boundary)
    candidate_matrix = matrix[candidate_mask]
    candidate_totals = cell_umi_counts[candidate_mask]
    
    # Score simulations - use different method based on parameter
    if method == "dirichlet":
        assert alpha is not None, "alpha must be specified for Dirichlet method"
        assert alpha > 0, "alpha must be greater than 0"
        
        info(f"evaluating s = {n_iter} simulations up to n = {retain} unique totals (dirichlet-multinomial)")
        sim_llik = evaluate_simulations_dirichlet_multinomial(
            retain, n_iter, alpha, probs, seed
        )

        info("evaluating likelihood for {candidate_totals.size} candidate barcodes")
        obs_llik = eval_log_likelihood_dirichlet_multinomial(
            alpha, candidate_matrix, candidate_totals, probs
        )

    else:
        info(f"evaluating s = {n_iter} simulations up to n = {retain} unique totals (multinomial)")
        sim_llik = evaluate_simulations_multinomial(retain, n_iter, probs, seed)

        info(f"evaluating likelihood for {candidate_totals.size} candidate barcodes")
        obs_llik = eval_log_likelihood_multinomial(
            candidate_matrix, candidate_totals, probs
        )

    # candidate false-discovery-rates
    info(f"evaluating pvalues for {candidate_totals.size} candidate barcodes")
    fdr = score_candidate_bcs(
        obs_llik,
        candidate_totals,
        sim_llik,
    )

    # build the mask of fully passing cells
    passing_candidates = np.flatnonzero(fdr < fdr_threshold)
    passing_candidates_in_original_index = np.flatnonzero(candidate_mask)[
        passing_candidates
    ]
    
    auto_accepted = np.flatnonzero(cell_umi_counts >= retain)
    passing_cells = np.unique(
        np.concatenate([auto_accepted, passing_candidates_in_original_index]))
    info(f"identified {passing_candidates.size} passing candidates and {auto_accepted.size} retained cells.")
    
    stats = {
        "probs": probs,
        "alpha": alpha,
        "sim_llik": sim_llik,
        "obs_llik": obs_llik,
        "obs_totals": candidate_totals,
        "fdr": fdr,
        "n_iter": n_iter,
        "autoaccept": auto_accepted,
        "candidates": passing_candidates_in_original_index
    }
    
    return (adata[passing_cells], stats)