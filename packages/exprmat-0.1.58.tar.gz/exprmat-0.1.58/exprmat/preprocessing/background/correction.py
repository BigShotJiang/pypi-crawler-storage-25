
import numpy as np
import pandas as pd
from scipy import sparse, stats
from typing import TYPE_CHECKING, Literal, Optional, Union
from .soupx import soup_channel
from exprmat import error, warning, info


def adjust_counts(
    sc: soup_channel,
    clusters: Optional[Union[bool, np.ndarray]] = None,
    method: Literal["subtraction", "multinomial", "soup"] = "subtraction",
    round: bool = False,
    verbose: int = 1,
    tol: float = 1e-3,
    p_cutoff: float = 0.01,
    **kwargs
) -> sparse.csr_matrix:
    
    # Check prerequisites
    if 'rho' not in sc.metadata.columns or sc.metadata['rho'].isna().all():
        error("contamination fractions must have already been calculated/set.")

    # Handle clusters parameter like R
    if clusters is None:
        if 'clusters' in sc.metadata.columns:
            clusters = sc.metadata['clusters'].values
        else:
            if verbose >= 1:
                warning("clustering data not found. Adjusting counts at cell level.")
            clusters = False

    # Recursive application when using clusters (matching R logic)
    if clusters is not False:
        if verbose >= 1:
            unique_clusters = np.unique(clusters)
            info(f"adjusting counts using method '{method}' with {len(unique_clusters)} clusters")

        # Split cells by cluster
        cluster_groups = {}
        for i, cell_id in enumerate(sc.metadata.index):
            cluster = clusters[i]
            if cluster not in cluster_groups:
                cluster_groups[cluster] = []
            cluster_groups[cluster].append(i)

        # Create cluster-level aggregated data
        cluster_toc = []
        cluster_metadata = []

        for cluster_id in sorted(cluster_groups.keys()):
            cell_indices = cluster_groups[cluster_id]
            # Aggregate counts for cluster
            cluster_counts = np.array(sc.toc[:, cell_indices].sum(axis=1)).flatten()
            cluster_toc.append(cluster_counts)

            # Aggregate metadata
            cluster_nUMIs = sc.metadata.iloc[cell_indices]['n.umi'].sum()
            cluster_rho = (sc.metadata.iloc[cell_indices]['rho'] *
                          sc.metadata.iloc[cell_indices]['n.umi']).sum() / cluster_nUMIs
            cluster_metadata.append({'n.umi': cluster_nUMIs, 'rho': cluster_rho})

        # Create temporary cluster-level SoupChannel
        cluster_toc_matrix = sparse.csr_matrix(np.column_stack(cluster_toc))

        tmp_sc = type(sc).__new__(type(sc))
        tmp_sc.toc = cluster_toc_matrix
        tmp_sc.tod = sc.tod  # Keep original tod
        tmp_sc.soup_profile = sc.soup_profile
        tmp_sc.metadata = pd.DataFrame(cluster_metadata)
        tmp_sc.n_genes = sc.n_genes
        tmp_sc.n_cells = len(cluster_groups)

        # Recursively apply without clustering
        cluster_corrected = adjust_counts(
            tmp_sc, clusters = False, method = method,
            round = False, verbose = verbose, tol = tol, p_cutoff = p_cutoff
        )

        # Calculate soup counts removed at cluster level
        cluster_soup = tmp_sc.toc - cluster_corrected

        # Expand back to cell level using expandClusters logic
        cell_soup = expand_clusters(
            cluster_soup, sc.toc, clusters, cluster_groups,
            sc.metadata['n.umi'].values * sc.metadata['rho'].values,
            verbose=verbose, **kwargs
        )

        # Return corrected counts
        out = sc.toc - cell_soup

        if round: out = stochastic_round(out)
        return out
    
    # Single-cell level correction
    if method == "subtraction":
        return substraction(sc, round, verbose, tol)
    elif method == "multinomial":
        return multinomial(sc, round, verbose, tol)
    elif method == "soup":
        return soup_only(sc, round, verbose, p_cutoff)
    else: error(f"unknown method: {method}")


def expand_clusters(
    cluster_soup: sparse.csr_matrix,
    toc: sparse.csr_matrix,
    clusters: np.ndarray,
    cluster_groups: dict,
    target_soup_counts: np.ndarray,
    verbose: int = 1,
    **kwargs
) -> sparse.csr_matrix:

    n_genes, n_cells = toc.shape

    if verbose > 0:
        info(f"expanding counts from {cluster_soup.shape[1]} clusters to {n_cells} cells")

    # Build output using COO format for efficient construction
    row_indices = []
    col_indices = []
    data_values = []

    cluster_ids = list(cluster_groups.keys())

    for cluster_idx, cluster_id in enumerate(cluster_ids):
        cell_indices = cluster_groups[cluster_id]

        if len(cell_indices) == 0 or cluster_idx >= cluster_soup.shape[1]:
            continue

        cluster_soup_vec = cluster_soup[:, cluster_idx].toarray().flatten()
        nonzero_genes = np.nonzero(cluster_soup_vec)[0]

        if len(cell_indices) == 1:
            # Single cell - direct assignment
            for gene_idx in nonzero_genes:
                row_indices.append(gene_idx)
                col_indices.append(cell_indices[0])
                data_values.append(cluster_soup_vec[gene_idx])
        else:
            # Multiple cells - vectorized allocation
            cell_indices_array = np.array(cell_indices)
            cell_weights = target_soup_counts[cell_indices_array]
            total_weight = np.sum(cell_weights)
            ww = cell_weights / total_weight if total_weight > 0 else np.ones(len(cell_indices)) / len(cell_indices)

            # Vectorized: get all bucket limits at once
            bucketLims = toc[nonzero_genes, :][:, cell_indices_array].toarray()  # (n_nonzero_genes, n_cells_in_cluster)

            # Vectorized allocation for all genes at once
            allocated = alloc_vectorized(cluster_soup_vec[nonzero_genes], bucketLims, ww)

            # Add to COO lists
            for i, gene_idx in enumerate(nonzero_genes):
                for j, cell_idx in enumerate(cell_indices):
                    val = allocated[i, j]
                    if val > 0:
                        row_indices.append(gene_idx)
                        col_indices.append(cell_idx)
                        data_values.append(val)

    return sparse.csr_matrix(
        (data_values, (row_indices, col_indices)),
        shape = (n_genes, n_cells), dtype = cluster_soup.dtype
    )


def alloc_vectorized(tgt: np.ndarray, bucketLims: np.ndarray, ws: np.ndarray) -> np.ndarray:
    """
    Vectorized version of alloc for multiple genes at once.
    tgt: (n_genes,) target values
    bucketLims: (n_genes, n_buckets) bucket limits
    ws: (n_buckets,) weights
    Returns: (n_genes, n_buckets) allocated values
    """
    n_genes, n_buckets = bucketLims.shape
    ws = ws / np.sum(ws)

    # Initial allocation
    initial = tgt[:, None] * ws[None, :]  # (n_genes, n_buckets)

    # Check which genes can use simple allocation
    simple_mask = np.all(initial <= bucketLims, axis=1)

    result = np.zeros_like(initial)
    result[simple_mask] = initial[simple_mask]

    # Complex reallocation for remaining genes
    complex_idx = np.where(~simple_mask)[0]

    for idx in complex_idx:
        result[idx] = alloc(tgt[idx], bucketLims[idx], ws)

    return result


def alloc(tgt: float, bucketLims: np.ndarray, ws: np.ndarray) -> np.ndarray:
    
    # R: ws = ws/sum(ws) - normalize weights
    ws = ws / np.sum(ws)

    # R: if(all(tgt*ws<=bucketLims)) return(tgt*ws)
    initial_allocation = tgt * ws
    if np.all(initial_allocation <= bucketLims):
        return initial_allocation

    # R's complex reallocation algorithm
    # R: o = order(bucketLims/ws)
    # Need to handle zero weights carefully
    with np.errstate(divide = 'ignore', invalid = 'ignore'):
        ratios = bucketLims / ws
        ratios[ws == 0] = np.inf  # R behavior for zero weights

    o = np.argsort(ratios)  # R: order() gives 1-based, argsort gives 0-based

    # Reorder arrays by the order
    w = ws[o]
    y = bucketLims[o]

    # R's cumulative calculations
    # R: cw = cumsum(c(0,w[-length(w)]))
    cw = np.concatenate([[0], np.cumsum(w[:-1])])

    # R: cy = cumsum(c(0,y[-length(y)]))
    cy = np.concatenate([[0], np.cumsum(y[:-1])])

    # R: k = y/w* (1 - cw) + cy
    # Handle zero weights: R sets k[w==0] = Inf
    k = np.full_like(w, np.inf)
    nonzero_w = w != 0
    if np.any(nonzero_w):
        k[nonzero_w] = y[nonzero_w] / w[nonzero_w] * (1 - cw[nonzero_w]) + cy[nonzero_w]

    # R: b = (k<=tgt)
    b = k <= tgt

    # R: resid = tgt-sum(y[b])
    resid = tgt - np.sum(y[b])

    # R: w = w/(1-sum(w[b]))
    sum_w_b = np.sum(w[b])
    if sum_w_b < 1.0:
        w = w / (1 - sum_w_b)

    # R: out = ifelse(b,y,resid*w)
    out = np.where(b, y, resid * w)

    # R: return(out[order(o)]) - need to reverse the sort
    # Create reverse order mapping
    reverse_order = np.empty_like(o)
    reverse_order[o] = np.arange(len(o))

    return out[reverse_order]


# R version translation, slow.
def substraction_r(
        sc: soup_channel,
        roundToInt: bool,
        verbose: int,
        tol: float
) -> sparse.csr_matrix:
    """
    Simple subtraction method (equation 5 from paper).
    Matches R implementation exactly.
    """
    if verbose >= 1:
        info("using subtraction method")

    # Calculate expected soup counts
    soup_expression = sc.soup_profile['est'].values
    corrected = sc.toc.copy().astype(float)

    for cell_idx in range(sc.n_cells):
        cell_rho = sc.metadata.iloc[cell_idx]['rho']
        cell_nUMIs = sc.metadata.iloc[cell_idx]['n.umi']

        # Expected soup counts for this cell
        expected_soup = soup_expression * cell_nUMIs * cell_rho

        # Get observed counts
        observed = sc.toc[:, cell_idx].toarray().flatten()

        # Simple subtraction
        corrected_counts = observed - expected_soup

        # Can't have negative counts
        corrected_counts = np.maximum(corrected_counts, 0)

        corrected[:, cell_idx] = corrected_counts.reshape(-1, 1)

    if roundToInt:
        corrected = stochastic_round(corrected)

    return corrected.tocsr()


def substraction(sc, roundToInt: bool, verbose, tol):
    X = sc.toc.tocsc(copy = True)

    soup = sc.soup_profile['est'].values
    rho = sc.metadata['rho'].values
    nUMI = sc.metadata['n.umi'].values

    scale = rho * nUMI  # (C,)

    data = X.data
    indices = X.indices
    indptr = X.indptr

    col_ids = np.repeat(np.arange(X.shape[1]), np.diff(indptr))
    scale_expanded = scale[col_ids]
    soup_vals = soup[indices]
    data -= soup_vals * scale_expanded

    np.maximum(data, 0, out = data)
    return X.tocsr()


def multinomial(
        sc: soup_channel,
        roundToInt: bool,
        verbose: int,
        tol: float
) -> sparse.csr_matrix:
    """
    Vectorized multinomial likelihood optimization method - 10x faster.
    Maintains exact compatibility with R's algorithm while processing in batches.
    """

    if verbose >= 1: info(f"fitting multinomial distribution to {sc.n_cells} cells (vectorized)")

    # Initialize with subtraction method (much faster than original cell-by-cell)
    if verbose >= 2: info("initializing with subtraction method")

    corrected = substraction(sc, False, 0, tol)
    fit_init = sc.toc - corrected

    ps = sc.soup_profile['est'].values
    out = sparse.lil_matrix(sc.toc.shape)

    # Process cells in batches for better memory usage and vectorization
    batch_size = min(500, sc.n_cells)  # Adjust based on available memory

    for batch_start in range(0, sc.n_cells, batch_size):
        batch_end = min(batch_start + batch_size, sc.n_cells)

        if verbose >= 1 and batch_start % (batch_size * 10) == 0:
            info(f"processing cells {batch_start + 1}-{batch_end}/{sc.n_cells}")

        # Process this batch
        for cell_idx in range(batch_start, batch_end):
            # Target soup molecules for this cell
            nSoupUMIs = round(sc.metadata.iloc[cell_idx]['n.umi'] *
                              sc.metadata.iloc[cell_idx]['rho'])

            # Observational limits
            lims = sc.toc[:, cell_idx].toarray().flatten()

            # Initial soup counts (vectorized initialization)
            fit = fit_init[:, cell_idx].toarray().flatten().astype(float)

            # Fast vectorized optimization
            fit = multinomial_optim(fit, ps, lims, nSoupUMIs, verbose >= 3)

            # Store corrected counts
            out[:, cell_idx] = (lims - fit).reshape(-1, 1)

    out = out.tocsr()

    if roundToInt:
        out = stochastic_round(out)

    if verbose >= 1:
        original_total = sc.toc.sum()
        corrected_total = out.sum()
        info(f"removed {(1 - corrected_total / original_total) * 100:.1f}% of counts")

    return out


def multinomial_optim(
        fit: np.ndarray,
        ps: np.ndarray,
        lims: np.ndarray,
        nSoupUMIs: int,
        verbose: bool,
        max_iter: int = 200
) -> np.ndarray:
    
    fit = fit.copy()

    # Pre-compute masks and indices for efficiency
    ps_nonzero = ps > 0

    for iteration in range(max_iter):
        # Vectorized computation of which can be increased/decreased
        increasable = (fit < lims) & ps_nonzero
        decreasable = fit > 0

        if not np.any(increasable) and not np.any(decreasable):
            break

        # Vectorized likelihood change calculations
        delInc = np.full(len(fit), -np.inf)
        delDec = np.full(len(fit), -np.inf)

        if np.any(increasable):
            mask = increasable
            delInc[mask] = np.log(ps[mask]) - np.log(fit[mask] + 1)

        if np.any(decreasable):
            mask = decreasable
            delDec[mask] = -np.log(ps[mask]) + np.log(fit[mask])

        # Find best moves (vectorized)
        finite_inc = np.isfinite(delInc)
        finite_dec = np.isfinite(delDec)

        max_delInc = np.max(delInc[finite_inc]) if np.any(finite_inc) else -np.inf
        max_delDec = np.max(delDec[finite_dec]) if np.any(finite_dec) else -np.inf

        # Get all indices of best moves
        wInc_all = np.where((delInc == max_delInc) & finite_inc)[0]
        wDec_all = np.where((delDec == max_delDec) & finite_dec)[0]

        if len(wInc_all) == 0 and len(wDec_all) == 0:
            break

        # Randomly select from ties (matching R behavior)
        wInc = np.random.choice(wInc_all) if len(wInc_all) > 0 else None
        wDec = np.random.choice(wDec_all) if len(wDec_all) > 0 else None

        # Current soup count
        current_soup = int(np.sum(fit))

        # Make moves based on current state
        if current_soup < nSoupUMIs:
            # Need more soup
            if wInc is not None and max_delInc > -np.inf:
                fit[wInc] += 1
        elif current_soup > nSoupUMIs:
            # Too much soup
            if wDec is not None and max_delDec > -np.inf:
                fit[wDec] -= 1
        else:
            # At target, check for improvements
            if max_delInc + max_delDec > 0 and wInc is not None and wDec is not None:
                fit[wInc] += 1
                fit[wDec] -= 1
            elif max_delInc + max_delDec == 0:
                # Handle ambiguous case with vectorized redistribution
                zeroBucket = np.unique(np.concatenate([wInc_all, wDec_all]))
                if len(wDec_all) > 0 and len(zeroBucket) > 0:
                    fit[wDec_all] -= 1
                    redistribution = len(wDec_all) / len(zeroBucket)
                    fit[zeroBucket] += redistribution
                break
            else:
                break

        # Early termination check
        if abs(current_soup - nSoupUMIs) <= 0.5:
            break

    if verbose and iteration == max_iter - 1:
        warning(f"max iterations reached.")

    return fit


def soup_only(
    sc: soup_channel,
    round: bool,
    verbose: int,
    p_cutoff: float
) -> sparse.csr_matrix:
    
    if verbose >= 1: info("identifying genes likely to be pure contamination")
    corrected = sc.toc.copy().astype(float)

    for cell_idx in range(sc.n_cells):
        cell_rho = sc.metadata.iloc[cell_idx]['rho']
        cell_nUMIs = sc.metadata.iloc[cell_idx]['n.umi']
        observed = sc.toc[:, cell_idx].toarray().flatten()

        # Expected soup counts
        expected_soup = sc.soup_profile['est'].values * cell_nUMIs * cell_rho

        # Calculate p-values for each gene
        p_vals = []
        for gene_idx in range(sc.n_genes):
            if expected_soup[gene_idx] <= 0:
                p_val = 0.0 if observed[gene_idx] > 0 else 1.0
            else:
                # Poisson test - is observed significantly > expected?
                p_val = 1 - stats.poisson.cdf(observed[gene_idx] - 1, expected_soup[gene_idx])
            p_vals.append(p_val)

        # Sort genes by p-value
        gene_order = np.argsort(p_vals)

        # Remove genes until we've removed ~rho fraction
        soup_removed = 0
        target_soup = cell_nUMIs * cell_rho

        for gene_idx in gene_order:
            if p_vals[gene_idx] > p_cutoff:
                # This gene shows no evidence of endogenous expression
                soup_removed += observed[gene_idx]
                corrected[gene_idx, cell_idx] = 0

                if soup_removed >= target_soup:
                    break

    if round:
        corrected = stochastic_round(corrected)

    return corrected.tocsr()


def stochastic_round(matrix: sparse.spmatrix) -> sparse.csr_matrix:
    
    matrix = matrix.tocsr()
    data = matrix.data.copy()

    # Get integer and fractional parts
    int_part = np.floor(data)
    frac_part = data - int_part

    # Stochastically round up based on fractional part
    round_up = np.random.random(len(data)) < frac_part
    data = int_part + round_up

    # Create new matrix with integer values
    result = sparse.csr_matrix((data, matrix.indices, matrix.indptr),
                               shape=matrix.shape, dtype=int)
    return result
