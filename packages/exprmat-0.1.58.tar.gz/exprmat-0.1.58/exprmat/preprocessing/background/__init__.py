
from .emptydrops import emptydrops

from exprmat.preprocessing.background.soupx import soup_channel
from exprmat.preprocessing.background.correction import adjust_counts
from exprmat.preprocessing.background.estimation import estimate_contamination


def soupx_correct(
    filtered, raw, key_added = 'soupx',
    pc = 12, knn_metrics = 'cosine', cluster_resolution = 0.2,
    estimate_kwargs = {}, adjust_kwargs = {}
):
    
    import anndata as ad
    import scanpy as sc

    sch = soup_channel(
        tod = raw.X.T,
        toc = filtered.X.T
    )

    # run a coarse clustering first with 12 pc. 
    adata = ad.AnnData(X = sch.toc.T)
    sc.pp.normalize_total(adata, inplace = True)
    sc.pp.scale(adata, zero_center = False)
    sc.pp.pca(adata, n_comps = pc)
    sc.pp.neighbors(adata, metric = knn_metrics)
    sc.tl.leiden(adata, resolution = cluster_resolution, flavor = 'igraph', n_iterations = 2)

    sch.set_cluster(adata.obs['leiden'])
    sch = estimate_contamination(sch, **estimate_kwargs)
    out = adjust_counts(sch, **adjust_kwargs)

    filtered.layers[key_added] = out.T
    return out
