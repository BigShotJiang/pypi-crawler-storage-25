
# REFERENCES:
# https://cran.r-project.org/doc/manuals/r-release/R-ints.html#Serialization-Formats
# https://github.com/LTLA/rds2cpp/blob/master/include/rds2cpp/parse_object.hpp#L30
# https://blog.djnavarro.net/posts/2021-11-15_serialisation-with-rds/
# https://github.com/wch/r-source/blob/79298c499218846d14500255efd622b5021c10ec/src/main/serialize.c#L1855

# adapted from py8rds.
# copyright (c) the py8rds authors.

from .rds import (r_obj, parse_rds)
from .converter import (as_numpy, as_data_frame, as_anndata)
from .seurat import load_seurat