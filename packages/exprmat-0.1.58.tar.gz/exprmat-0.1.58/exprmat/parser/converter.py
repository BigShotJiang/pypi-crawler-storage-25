
import numpy as np
import pandas as pd
import anndata as ad
from scipy import sparse
from .rds import factor_to_array, INT_NA, r_obj


def as_data_frame(robj):
    cols = {}
    names = robj.get("names").value
    for i in range(len(names)):
        val = robj.value[i]
        cl = val.get("class")
        if (cl is not None) and "factor" in cl.value:
            val = factor_to_array(val)
        else:
            val = val.value
        cols[names[i]] = val

    r = pd.DataFrame(cols)
    row_names = robj.get("row.names")
    if (row_names is not None) and (row_names.value is not None):
        if (len(row_names.value) != 2) \
            or (row_names.value[0] != INT_NA): 
            r.index = row_names.value

    # set int NAs, cannot do in before as numpy int32 doesn't support NAs
    int32_cols = r.select_dtypes(include=["int32"]).columns
    r[int32_cols] = r[int32_cols].astype("Int32").replace(INT_NA, pd.NA)

    return r


def as_numpy(robj: r_obj):
    cl = robj.get_class()
    if cl == "dgCMatrix":
        return dgc_matrix_to_numpy(robj)
    if cl == "REALSXP":
        return array_to_numpy(robj)


def as_anndata(robj):
    X = as_numpy(robj).T
    adata = ad.AnnData(X = X)
    dimnames = robj.get("dimnames")
    if dimnames is None:
        dimnames = robj.get("Dimnames")  # for sparse Matrices

    if dimnames is not None:
        dimnames = dimnames.value
        if dimnames[0].value is not None:
            adata.var_names = dimnames[0].value
        if dimnames[1].value is not None:
            adata.obs_names = dimnames[1].value
    return adata


def array_to_numpy(robj):

    dim = robj.get("dim")
    if dim is None: dim = len(robj.value)
    else: dim = dim.value
    X = np.array(robj.value).reshape(dim, order="F")
    return X


def dgc_matrix_to_numpy(robj):
    
    i = robj.get("i").value
    p = robj.get("p").value
    dim = robj.get("Dim").value
    x = robj.get("x").value
    dimnames = robj.get("Dimnames").value
    X = sparse.csc_matrix((x, i, p), dim)
    return X


def is_default_index(df):
    idx = df.index

    if isinstance(idx, pd.RangeIndex):
        return idx.start == 0 and idx.step == 1 and idx.stop == len(df)

    try: return pd.Index(idx.astype(int)).equals(pd.RangeIndex(len(df)))
    except (ValueError, TypeError): return False