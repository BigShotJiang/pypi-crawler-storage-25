
import gzip
import struct
import numpy as np
from numpy.dtypes import StringDType
from exprmat import error, warning

INT_NA = -2147483648

sexp_types = {
    0: {"SEXPTYPE": "NILSXP", "description": "NULL"},
    1: {"SEXPTYPE": "SYMSXP", "description": "symbols"},
    2: {"SEXPTYPE": "LISTSXP", "description": "pairlists"},
    3: {"SEXPTYPE": "CLOSXP", "description": "closures"},
    4: {"SEXPTYPE": "ENVSXP", "description": "environments"},
    5: {"SEXPTYPE": "PROMSXP", "description": "promises"},
    6: {"SEXPTYPE": "LANGSXP", "description": "languageobjects"},
    7: {"SEXPTYPE": "SPECIALSXP", "description": "special functions"},
    8: {"SEXPTYPE": "BUILTINSXP", "description": "builtinfunctions"},
    9: {"SEXPTYPE": "CHARSXP", "description": "internalcharacterstrings"},
    10: {"SEXPTYPE": "LGLSXP", "description": "logicalvectors"},
    13: {"SEXPTYPE": "INTSXP", "description": "integervectors"},
    14: {"SEXPTYPE": "REALSXP", "description": "numericvectors"},
    15: {"SEXPTYPE": "CPLXSXP", "description": "complexvectors"},
    16: {"SEXPTYPE": "STRSXP", "description": "charactervectors"},
    17: {"SEXPTYPE": "DOTSXP", "description": "dot-dot-dotobject"},
    18: {"SEXPTYPE": "ANYSXP", "description": "make'any'argswork"},
    19: {"SEXPTYPE": "VECSXP", "description": "list(genericvector)"},
    20: {"SEXPTYPE": "EXPRSXP", "description": "expressionvector"},
    21: {"SEXPTYPE": "BCODESXP", "description": "bytecode"},
    22: {"SEXPTYPE": "EXTPTRSXP", "description": "externalpointer"},
    23: {"SEXPTYPE": "WEAKREFSXP", "description": "weak"},
    24: {"SEXPTYPE": "RAWSXP", "description": "reference raw vector"},
    25: {"SEXPTYPE": "S4SXP", "description": "S4 classes"},
    238: {"SEXPTYPE": "ALTREP", "description": "ALTREP_SXP / custom ALTREP"},
    242: {"SEXPTYPE": "EMPTYENV", "description": "NULL"},
    249: {"SEXPTYPE": "NAMESPACESXP", "description": "NULL"},
    251: {"SEXPTYPE": "MISSINGARG", "description": "NULL"},
    253: {"SEXPTYPE": "GLOBALENV", "description": "NULL"},
    254: {"SEXPTYPE": "NILSXP", "description": "NULL"},
    255: {"SEXPTYPE": "REFSXP", "description": "reference to previous object"},
}


class rds_file:
    def __init__(self):
        self.format_version = 0
        self.writer_version = [0, 0, 0]
        self.reader_version = [0, 0, 0]
        self.encoding = ""
        self.object = None
        self.environments = []
        self.symbols = []
        self.external_pointers = []


class r_obj:

    def __init__(self):

        self.value = None

        # attributes has unique names and then can be stored in dict, 
        # but they are serialized as pairlist which names are not necessary unique.
        # so we will store attributes as list of [scalar, r_obj] pairs
        self.attributes = []

    def get(self, inxs):

        """
        Recursively navigate into an r_obj using indices and/or names.
        Indices are used only to search in the value; names are used to search both in attributes (first)
        and then in values if they are a pairlist (should be the case for S4 slots).

        Parameters
        ----------
        inxs : int | str | list[int | str]
            A single index/name or a list describing a path within an R object.

        Returns
        -------
        One of
            - a r_obj object,
            - a primitive Python value (int, float, bool, str, etc.),
            - or `None` if any step along the path cannot be resolved.
        """

        if not isinstance(inxs, list):
            inxs = [inxs]
        r = self._get(inxs[0])
        if (r is None) or (len(inxs) == 1): return r
        return r.get(inxs[1:])


    def _get(self, inx):

        # look by index
        if isinstance(inx, int):
            if isinstance(self.value, list):
                return self.value[inx]
            elif inx == 0: return self.value
            else: return None

        # look by name
        elif isinstance(inx, str):
            # in attributes
            for a in self.attributes:
                if inx == a[0]: return a[1]
            
            # in values
            if not isinstance(self.value, list):
                return None
            
            for v in self.value:
                if isinstance(v, list):
                    if inx == v[0]: return v[1]
        
        return None


    def get_class(self):
        r = self._get("class")
        if r is None: r = self._get("sexptype")
        else: r = " : ".join(r.value)
        return r


    def is_primitive(self, x):
        return isinstance(x, (int, float, bool, str, bytes, type(None), np.generic))


    def structure(self, level = 1, color = True):
        print('\n'.join(self.pretty_print(level = level, color = color)))


    def pretty_print(self, name = "root", indent = "", maxItems = 100, level = 1e3, color = False):
        
        if level < 0: return []
        level -= 1

        from exprmat.ansi import red, green, yellow, cyan, annot

        def print_value_np(values):
            pstr = '['
            size = values.size

            preview_count = min(3, size)
            pstr += ", ".join([
                (cyan(format(values.flat[i], '.0f')) if color else format(values.flat[i], '.0f')) 
                    if type(values.flat[i]) is np.integer else (
                (cyan(format(values.flat[i], '.2f')) if color else format(values.flat[i], '.2f')) 
                    if np.isreal(values.flat[i]) else 
                (red("'" + values.flat[i] + "'") if color else f"'{values.flat[i]}'"))
                for i in range(preview_count)
            ])
            if size > 3: pstr += ", .."
            pstr += ']'
            return pstr
        
        def print_value_list(values):
            pstr = '['
            size = len(values)

            preview_count = min(3, size)
            pstr += ", ".join([
                (cyan(format(values[i], '.0f')) if color else format(values[i], '.0f')) 
                    if type(values[i]) is np.integer else (
                (cyan(format(values[i], '.2f')) if color else format(values[i], '.2f')) 
                    if np.isreal(values[i]) else 
                (red("'" + values[i] + "'") if color else f"'{values[i]}'"))
                for i in range(preview_count)
            ])
            if size > 3: pstr += ", .."
            pstr += ']'
            return pstr
        
        lines = []
        parts = []
        if len(indent) > 0: parts.append(indent[:-1])
        parts.append(green(name) if color else name)

        # class name coloring
        class_name = str(self.get_class())
        if color: 
            if class_name.endswith('SXP'): class_name = annot(f'<{class_name}>')
            else: class_name = yellow(class_name)
        else: class_name = f'<{class_name}>'
        parts.append(class_name)

        indent = indent.replace("$", ".").replace("*", ".").replace("@", ".")
        
        values = self.value
        values_is_array = isinstance(values, np.ndarray)
        if (not isinstance(values, list)) and (not values_is_array): values = [values]
        
        handled_values = False
        if values_is_array:
            if values.size == 0:
                parts.append("[]")
                handled_values = True
                lines.append(' '.join(parts))
                parts = []

            else:
                first_val = values.flat[0]
                if self.is_primitive(first_val):
                    parts.append(print_value_np(values))
                    if values.ndim > 1: parts.append(f"({values.shape})")
                    handled_values = True
                    
                    lines.append(' '.join(parts))
                    parts = []

                else:
                    values = values.tolist()
                    values_is_array = False
            

        if not handled_values:
            if len(values) == 0:
                parts.append("[]")
                lines.append(' '.join(parts))
                parts = []

            elif self.is_primitive(values[0]):
                parts.append(print_value_list(values))
                lines.append(' '.join(parts))
                parts = []

            elif isinstance(values[0], r_obj):
                lines.append(' '.join(parts))
                parts = []
                for i in range(len(values)):
                    lines += values[i].pretty_print(
                        name = str(i),
                        indent = indent + "$ ",
                        maxItems = maxItems,
                        level = level,
                        color = color
                    )
                    

            else:
                lines.append(' '.join(parts))
                parts = []

                for i in range(len(values)):
                    if self.is_primitive(values[i]):
                        parts.append(indent + "$ " + str(values[i]))
                        lines.append(' '.join(parts))
                        parts = []
                    
                    elif isinstance(values[i][1], r_obj):
                        lines += values[i][1].pretty_print(
                            name = str(values[i][0]),
                            indent = indent + "$ ",
                            maxItems = maxItems,
                            level = level,
                            color = color
                        )

                    else:
                        parts.append(
                            indent + "$ "
                            + str(values[i][0]) + " : "
                            + str(values[i][1]) 
                        )

                        lines.append(' '.join(parts))
                        parts = []
        
        # attributes
        for a in self.attributes:
            if len(a) != 2: raise RuntimeError("Attributes are not in a pair: " + str(a))
            
            if a[0] != "sexptype":
                lines += a[1].pretty_print(
                    name = str(a[0]),
                    indent = indent + "* ",
                    maxItems = maxItems,
                    level = level,
                    color = color
                )

        return lines

    
    def __getitem__(self, index):
        return self.get([index])
    
    
def parse_object_header(reader):
    
    object_header = [reader.read(1) for _ in range(4)]
    if any(len(b) == 0 for b in object_header):
        raise EOFError("Unexpected end of file while reading object header")

    header_bin = [f"{struct.unpack('>B', b)[0]:08b}" for b in object_header]
    sexp_type = struct.unpack("<B", object_header[3])[0]

    other_bits = struct.unpack(">B", object_header[2])[0]
    object_bit = bool(other_bits & 0b00000001)
    attributes_bit = bool((other_bits & 0b00000010) >> 1)
    tag_bit = bool((other_bits & 0b00000100) >> 2)
    gp_bit = bool(struct.unpack(">B", object_header[1])[0] & 0b00000001)

    return {
        "bytes": object_header,
        "sexp_type_code": sexp_type,
        "sexptype": sexp_types[sexp_type]["SEXPTYPE"] if sexp_type in sexp_types else -1,
        "flags": {
            "object": object_bit,
            "attributes": attributes_bit & (sexp_type < 255),  
            # sexp_type==255 is symbol, symbol has no attributes (I hope), 
            # but have seqpool index in preceeding bytes
            "tag": tag_bit,
            "gp": gp_bit,
        },
    }


def parse_rds(file_path: str) -> r_obj:
    
    rds = rds_file()
    with open(file_path, "rb") as f:
        magic_number = f.read(2)

    if magic_number == b"\x1f\x8b":
        reader = gzip.open(file_path, "rb")
    else: reader = open(file_path, "rb")

    format = reader.read(2)
    if format == b"X\n": pass
    elif format == b"A\n":
        raise NotImplementedError("ASCII format detected")
    elif format == b"B\n": 
        raise NotImplementedError("Native word-order binary format detected")
    else: raise NotImplementedError(f"Unknown Format '{format}'")

    rds.format_version = struct.unpack(">I", reader.read(4))[0]
    rds.writer_version = struct.unpack("BBB", reader.read(4)[1:])
    rds.reader_version = struct.unpack("BBB", reader.read(4)[1:])

    if rds.format_version == 3:
        encoding_length = struct.unpack(">I", reader.read(4))[0]
        rds.encoding = reader.read(encoding_length).decode()

    rds.object = parse_object(reader, rds)
    return rds.object


def parse_object(reader, rds: rds_file):
    header = parse_object_header(reader)
    robj = r_obj()
    
    if header["sexptype"] == "S4SXP":
        robj = parse_s4sxp(reader, rds)

    elif header["sexptype"] == "LISTSXP":
        # For pairlists, attributes are serialized BEFORE TAG/CAR/CDR.
        attrs = None
        if header["flags"]["attributes"]:
            attrs = parse_object(reader).value
        robj.value = parse_listsxp(reader, rds, header["flags"]["tag"])
        if attrs is not None:
            robj.attributes = attrs

    elif header["sexptype"] == "LANGSXP":
        # Language objects have the same pairlist layout as LISTSXP.
        attrs = None
        if header["flags"]["attributes"]:
            attrs = parse_object(reader, rds).value
        robj.value = parse_listsxp(reader, rds, header["flags"]["tag"])
        if attrs is not None:
            robj.attributes = attrs

    elif header["sexptype"] == "SYMSXP":
        robj.value = parse_symsxp(reader, rds)

    elif header["sexptype"] == "CHARSXP":
        robj.value = parse_charsxp(reader)

    elif header["sexptype"] == "LGLSXP":
        robj.value = parse_lglsxp(reader)

    elif header["sexptype"] == "STRSXP":
        robj.value = parse_strsxp(reader, rds)

    elif header["sexptype"] == "CPLXSXP":
        robj.value = parse_cplxsxp(reader)

    elif header["sexptype"] == "REALSXP":
        robj.value = parse_realsxp(reader)

    elif header["sexptype"] == "INTSXP":
        robj.value = parse_intsxp(reader)

    elif header["sexptype"] == "BUILTINSXP":
        robj.value = parse_builtinsxp(reader)

    elif header["sexptype"] == "SPECIALSXP":
        robj.value = parse_specialsxp(reader)

    elif header["sexptype"] == "VECSXP":
        robj.value = parse_vecsxp(reader, rds)

    elif header["sexptype"] == "EXPRSXP":
        robj.value = parse_exprsxp(reader, rds)

    elif header["sexptype"] == "CLOSXP":
        robj.value = parse_closxp(reader, rds, header["flags"]["attributes"])

    elif header["sexptype"] == "PROMSXP":
        attrs = None
        if header["flags"]["attributes"]:
            attrs = parse_object(reader, rds).value
        robj.value = parse_promsxp(reader, rds, header["flags"]["tag"])
        if attrs is not None:
            robj.attributes = attrs

    elif header["sexptype"] == "ENVSXP":
        robj.value = parse_envsxp(reader, rds)
        rds.symbols.append(robj.value)

    elif header["sexptype"] == "BCODESXP":
        robj.value = parse_bcodesxp(reader, rds)

    elif header["sexptype"] in [
        "NILSXP",
        "MISSINGARG",
        "GLOBALENV",
        "EMPTYENV",
        "MINUS_ONE",
    ]:
        robj.value = None

    elif header["sexptype"] == "NAMESPACESXP":
        robj.value = parse_namespacesxp(reader, rds)
        rds.symbols.append(robj.value)
    # REFSXP / pooled symbol reference
    elif header["sexptype"] == "REFSXP":
        size = struct.unpack(">I", b"".join(header["bytes"]))[0]
        inx = (size + 1) // 256 - 2

        if 0 <= inx < len(rds.symbols):
            # Looks like this REFSXP is actually pointing into the symbol pool.
            robj.value = rds.symbols[inx]
        else:
            # This REFSXP is not a pooled symbol (e.g. environment, other object),
            # and we don’t currently maintain a full reference table. To keep
            # parsing robust and avoid crashes, we return a placeholder.
            robj.value = f"<REFSXP_{inx}>"

    elif header["sexptype"] == "ALTREP":
        robj.value = parse_altrep(reader, rds)

    elif header["sexptype"] == "EXTPTRSXP":
        val, attrs = parse_extptrsxp(reader, rds)
        robj.value = val
        if attrs is not None:
            robj.attributes = attrs

    elif header["sexptype"] == "RAWSXP":
        robj.value = parse_rawsxp(reader)

    elif header["sexptype"] == "DOTSXP":
        attrs = None
        if header["flags"]["attributes"]:
            attrs = parse_object(reader, rds).value
        robj.value = parse_dotsxp(reader, rds, header["flags"]["tag"])
        if attrs is not None: robj.attributes = attrs

    elif header["sexptype"] == "WEAKREFSXP":
        robj.value = parse_weakrefsxp(reader, rds)

    elif header["sexptype"] == "ANYSXP":
        robj.value = parse_anysxp(reader, rds)

    else:
        raise NotImplementedError(f"Unimplemented SEXPTYPE '{header['sexptype']}'")

    # S4 fields are stored as attributes (pairlist), so the attr flag is true, but we store them as data.
    # At this point for S4, we've already read attributes.
    if header["flags"]["attributes"] and header["sexptype"] not in (
        "S4SXP",
        "ENVSXP",
        "CLOSXP",
        "LISTSXP",
        "LANGSXP",
        "ALTREP",
        "NAMESPACESXP",
        "EXTPTRSXP",
        "PROMSXP",
        "DOTSXP",
    ):
        attributes = parse_object(reader, rds).value
        if attributes is not None:
            robj.attributes = attributes

    # Fallback if attributes aren't in the expected list form.
    if not isinstance(robj.attributes, list):
        robj.attributes = [["__raw_attributes__", robj.attributes]]

    robj.attributes.append(["sexptype", header["sexptype"]])
    return robj


def parse_s4sxp(reader, rds):
    return parse_object(reader, rds)  # S4 is stored as LISTSXP, so just continue


def parse_listsxp(reader, rds, has_tag):
    """
    Parse a dotted pair / pairlist object (LISTSXP, also used for LANGSXP).

    Serialization layout for each cons cell (serialize.c):

        [ATTRIB] (handled outside this function)
        [TAG]  (only if has_tag == True)
        [CAR]
        [CDR]  (another LISTSXP cell, or NILSXP terminator)

    'has_tag' is constant for the entire list – either every cell has a
    tag or none of them do.
    """
    value = []

    # TAG or None
    if has_tag:
        pair_name = parse_object(reader, rds).value
    else:
        pair_name = None

    # CAR (always present)
    pair_value = parse_object(reader, rds)
    value.append([pair_name, pair_value])

    # CDR: either another pairlist cell or NULL terminator
    rest = parse_object(reader, rds)

    if rest.value is not None:
        # A proper pairlist from our parser should be represented as a list
        # of [name, Robj] pairs (and not as a list of Robj instances).
        if isinstance(rest.value, list) and (
            len(rest.value) == 0 or not isinstance(rest.value[0], r_obj)
        ):
            value.extend(rest.value)
        else:
            # Unexpected structure in CDR; preserve it as a single item so
            # we don't lose information.
            value.append([None, rest])

    return value


def parse_namespacesxp(reader, rds):
    """
    Parse a NAMESPACESXP (code 249).

    R's ReadItem does:

        SEXP s = InStringVec(stream, ref_table);
        s = R_FindNamespace1(s);

    InStringVec reads:
        - placeholder int (must be 0),
        - length (int),
        - then 'length' strings via ReadItem (usually CHARSXP).

    Here we:
      * Read the placeholder and length.
      * Read 'length' string objects with parse_object.
      * Return a Python list of strings (namespace spec), similar to STRSXP.

    The enclosing Robj will still get an attribute ['sexptype', 'NAMESPACESXP'],
    so you can distinguish it from a normal STRSXP if needed.
    """

    # Placeholder (should be 0).
    placeholder = struct.unpack(">i", reader.read(4))[0]

    # Length of the string vector.
    length = struct.unpack(">i", reader.read(4))[0]

    strings = []
    for i in range(length):
        elt = parse_object(reader, rds)  # typically CHARSXP Robj
        strings.append(elt.value)

    # Just return the list of strings, STRSXP-style.
    return strings


def parse_symsxp(reader, rds):
    # should be text representation of literals
    value = parse_object(reader, rds).value
    rds.symbols.append(value)
    return value


def parse_altrep(reader, rds):
    """
    Parse an ALTREP object (ALTREP_SXP, code 238).

    According to R's serialize.c (ReadItem):

        case ALTREP_SXP:
        {
            R_ReadItemDepth++;
            SEXP info  = ReadItem(ref_table, stream);
            SEXP state = ReadItem(ref_table, stream);
            SEXP attr  = ReadItem(ref_table, stream);
            s = ALTREP_UNSERIALIZE_EX(info, state, attr, objf, levs);
            ...
        }

    We cannot call ALTREP_UNSERIALIZE_EX from Python, so we expose the
    three components directly:

        value = [
            ["info",  <Robj>],
            ["state", <Robj>],
            ["attr",  <Robj>],
        ]

    This keeps the stream aligned and lets Robj.toString() print something
    sensible for ALTREP objects.
    """

    info = parse_object(reader, rds)  # usually something indicating ALTREP class
    state = parse_object(reader, rds)  # ALTREP-specific state (e.g., length/start/step)
    attr = parse_object(
        reader, rds
    )  # attributes that R would attach to the final object

    value = [
        ["info", info],
        ["state", state],
        ["attr", attr],
    ]

    # convert known ALTREPs into usual representationa
    if info.value[0][1].value == "compact_intseq":
        value = state.value[1] + state.value[2] * np.arange(state.value[0])

    return value


def parse_charsxp(reader):
    size = struct.unpack(">i", reader.read(4))[0]

    if size == -1:
        value = None

    else:
        raw = reader.read(size)

        # Try UTF-8 first (what most modern R sessions use)
        try: value = raw.decode("utf-8")

        except UnicodeDecodeError:

            # Fall back to Latin-1; this matches how R can keep 8-bit data
            # around in non-UTF-8 encodings without blowing up.
            try: value = raw.decode("latin-1")

            except UnicodeDecodeError:
                # As an absolute fallback, replace invalid bytes so we never crash.
                value = raw.decode("utf-8", errors="replace")

    return value


def parse_strsxp(reader, rds):
    size = struct.unpack(">I", reader.read(4))[0]
    value = np.empty(size, dtype=StringDType(na_object=np.nan))

    for i in range(size):
        v = parse_object(reader, rds).value
        if v is None: value[i] = np.nan
        else: value[i] = v

    return value


def parse_cplxsxp(reader):
    size = struct.unpack(">I", reader.read(4))[0]
    value = np.zeros(size, dtype=np.complex128)
    for i in range(size):
        real = struct.unpack(">d", reader.read(8))[0]
        imag = struct.unpack(">d", reader.read(8))[0]
        value[i] = complex(real, imag)
    return value


def oversize():
    
    warning('this is commonly triggered by storing extra-large dense arrays or matrices')
    warning('that have length exceeding 2147483647, the maximum storage limit of R')
    warning('approximately 46340 * 46340 in square dense matrix.')
    warning('we encourage you not to store huge dense matrices (e.g. the scaled data matrix)')
    warning('which can be easily re-generated without having to occupy disk space.')
    
    error('your rds file overflow capacity of our rds parser.')


def parse_realsxp(reader):
    size = struct.unpack(">I", reader.read(4))[0]

    if size == 4294967295: # uint_max
        oversize()

    value = np.frombuffer(reader.read(size * 8), dtype=">f8").astype(np.float64, copy=False)
    return value


def parse_intsxp(reader):
    size = struct.unpack(">I", reader.read(4))[0]

    if size == 4294967295: # uint_max
        oversize()

    value = np.frombuffer(reader.read(size * 4), dtype=">i4").astype(np.int32, copy=False)
    return value


def parse_builtinsxp(reader):
    size = struct.unpack(">I", reader.read(4))[0]
    value = reader.read(size).decode()
    return value


def parse_specialsxp(reader):
    return parse_builtinsxp(reader)


def parse_lglsxp(reader):
    # logical are stored as integers
    value = parse_intsxp(reader)
    value = np.ma.array(value == 1, mask=value == INT_NA)
    return value


def parse_vecsxp(reader, rds):
    size = struct.unpack(">I", reader.read(4))[0]
    value = []
    for _ in range(size):
        value.append(parse_object(reader, rds))
    return value


def parse_exprsxp(reader, rds):
    return parse_vecsxp(reader, rds)


def parse_rawsxp(reader):
    size = struct.unpack(">I", reader.read(4))[0]
    raw = reader.read(size)
    return np.frombuffer(raw, dtype=np.uint8)


def parse_dotsxp(reader, rds, has_tag):
    return parse_listsxp(reader, rds, has_tag)


def parse_promsxp(reader, rds, has_tag):
    """
    Parse an R promise (PROMSXP). R serializes it like a dotted pair:
    TAG = env, CAR = value, CDR = expr.
    """
    env = parse_object(reader, rds) if has_tag else None
    value = parse_object(reader, rds)
    expr = parse_object(reader, rds)
    return [
        ["env", env],
        ["value", value],
        ["expr", expr],
    ]


def parse_weakrefsxp(reader, rds):
    """
    Weak references are serialized without payload; keep a placeholder.
    """
    return None


def parse_anysxp(reader, rds):
    """
    ANYSXP is a rarely serialized placeholder; treat as NULL.
    """
    return None


def parse_envsxp(reader, rds):
    """
    Parse an R environment (ENVSXP) according to R's serialize.c ReadItem:

        int locked = InInteger(stream);
        ENCLOS  = ReadItem(...)
        FRAME   = ReadItem(...)
        HASHTAB = ReadItem(...)
        ATTRIB  = ReadItem(...)

    We expose a simple structure as a pairlist-like list of [name, Robj]
    pairs, and include the locked flag and environment-specific attributes
    inside the value.
    """

    # locked flag
    locked = struct.unpack(">i", reader.read(4))[0]

    # ENCLOS: enclosing environment
    enclos = parse_object(reader, rds)

    # FRAME: symbol/value bindings pairlist
    frame = parse_object(reader, rds)

    # HASHTAB: hash table, often NULL or VECSXP
    hashtab = parse_object(reader, rds)

    # ATTRIB: environment-specific attributes
    env_attrs = parse_object(reader, rds)

    env_value = [
        ["locked", locked],
        ["enclos", enclos],
        ["frame", frame],
        ["hashtab", hashtab],
        ["env_attrs", env_attrs],
    ]

    return env_value


def parse_closxp(reader, rds, has_attributes=False):
    """
    Parse an R closure (CLOSXP).

    Layout:

        [CLOSXP header]
        [ATTRIB] ?  if has_attributes
        [CLOENV]
        [FORMALS]
        [BODY]
    """

    if has_attributes:
        _attr_robj = parse_object(reader, rds)  # ignored, just advance stream

    env_robj = parse_object(reader, rds)
    formals_robj = parse_object(reader, rds)
    body_robj = parse_object(reader, rds)

    value = [
        ["env", env_robj],
        ["formals", formals_robj],
        ["body", body_robj],
    ]

    return value


# start of BCODESXP ####
# Bytecode helper constants from serialize.c

BCODESXP_CODE = 21  # standard R SEXP type
LANGSXP_CODE = 6
LISTSXP_CODE = 2

BCREPDEF_CODE = 244
BCREPREF_CODE = 243
ATTRLANGSXP_CODE = 240
ATTRLISTSXP_CODE = 239


def parse_bcodesxp(reader, rds):
    """
    Parse a BCODESXP (bytecode object).

    R's ReadItem for BCODESXP calls ReadBC, which does:

        reps_len = InInteger(stream);
        reps     = allocVector(VECSXP, reps_len);
        s        = ReadBC1(ref_table, reps, stream);

    ReadBC1 then reads:
        code   = ReadItem(...)
        consts = ReadBCConsts(...)

    We mirror that structure but return a pairlist-style value:

        [
          ["code",   <Robj>],
          ["consts", <Robj with value = list of const Robj>]
        ]
    """

    # ---- reps length (for shared subtrees in bytecode language) ----
    reps_len = struct.unpack(">i", reader.read(4))[0]
    reps = [None] * max(reps_len, 0)
    value = read_bc1(reader, reps, rds)
    return value


def read_bc1(reader, reps, rds):
    """
    Python version of ReadBC1(ref_table, reps, stream).

    Layout:

        code   = ReadItem(...)
        consts = ReadBCConsts(...)
    """

    code_robj = parse_object(reader, rds)
    consts_list = read_bc_consts(reader, reps, rds)  # list of Robj / nested BC

    # Wrap consts list into an Robj so that it prints as a list.
    consts_robj = r_obj()
    consts_robj.value = consts_list
    consts_robj.attributes = []

    # BCODESXP value is represented as a pairlist-style list of [name, Robj]
    # so that Robj.toString() prints it nicely.
    value = [
        ["code", code_robj],
        ["consts", consts_robj],
    ]

    return value


def read_bc_consts(reader, reps, rds):
    n = struct.unpack(">i", reader.read(4))[0]
    consts = []
    for i in range(n):
        type_code = struct.unpack(">i", reader.read(4))[0]

        if type_code == BCODESXP_CODE:
            const_val = read_bc1(reader, reps)
            nested = r_obj()
            nested.value = const_val
            nested.attributes = [["sexptype", "BCODESXP"]]
            consts.append(nested)

        elif type_code in (
            LANGSXP_CODE,
            LISTSXP_CODE,
            BCREPDEF_CODE,
            BCREPREF_CODE,
            ATTRLANGSXP_CODE,
            ATTRLISTSXP_CODE,
        ):
            const_val = read_bc_lang(reader, type_code, reps, rds)
            consts.append(const_val)

        else:
            const_val = parse_object(reader, rds)
            consts.append(const_val)

    return consts


def read_bc_lang(reader, type_code, reps, rds):
    """
    Python port of ReadBCLang(int type, SEXP ref_table, SEXP reps, R_inpstream_t stream).

    type_code is the integer 'type' that R read with InInteger().

    Semantics:

      - If type == BCREPREF:
            return reps[ InInteger(stream) ]

      - If type in {BCREPDEF, LANGSXP, LISTSXP, ATTRLANGSXP, ATTRLISTSXP}:
            build a LANG/LIST node with optional attributes and
            recursively-read CAR/CDR (which themselves are given by
            type codes and handled again via ReadBCLang).

      - Otherwise:
            default: just ReadItem(...) and return that SEXP
            (i.e. in Python, call parse_object(reader)).
    """

    # 1. BCREPREF: reference to an existing node in 'reps'
    if type_code == BCREPREF_CODE:
        idx = struct.unpack(">i", reader.read(4))[0]
        if 0 <= idx < len(reps):
            return reps[idx]
        return None

    # 2. Default branch: NOT a BCLang-compressed node
    if type_code not in (
        BCREPDEF_CODE,
        LANGSXP_CODE,
        LISTSXP_CODE,
        ATTRLANGSXP_CODE,
        ATTRLISTSXP_CODE,
    ):
        # This mirrors the 'default' case in C code (ReadItem).
        return parse_object(reader, rds)

    # 3. Now we're in the "real" BCLang path: BCREPDEF/LANG/LIST/ATTRLANG/ATTRLIST
    pos = -1
    hasattr = False
    t = type_code

    if t == BCREPDEF_CODE:
        # BCREPDEF: first int is position, second is underlying type
        pos = struct.unpack(">i", reader.read(4))[0]
        t = struct.unpack(">i", reader.read(4))[0]

    # Handle "attribute-wrapped" types.
    if t == ATTRLANGSXP_CODE:
        t = LANGSXP_CODE
        hasattr = True
    elif t == ATTRLISTSXP_CODE:
        t = LISTSXP_CODE
        hasattr = True

    # Human-readable type name for debugging / printing
    type_name = sexp_types.get(t, {}).get("SEXPTYPE", f"TYPE_{t}")

    node = r_obj()
    node.attributes = []

    # Optional attributes for the bc-lang node
    attr_robj = None
    if hasattr: attr_robj = parse_object(reader, rds)
    tag_robj = parse_object(reader, rds)
    car_type = struct.unpack(">i", reader.read(4))[0]
    car_val = read_bc_lang(reader, car_type, reps, rds)
    cdr_type = struct.unpack(">i", reader.read(4))[0]
    cdr_val = read_bc_lang(reader, cdr_type, reps, rds)

    # Store this node in 'reps' if it was a BCREPDEF
    if 0 <= pos < len(reps):
        reps[pos] = node

    # Represent this bc-lang node as a pairlist-like structure so your
    # existing toString() can print it nicely.
    node.value = [
        ["bctype", type_name],
        ["tag", tag_robj],
        ["car", car_val],
        ["cdr", cdr_val],
    ]

    # Attach attributes if present.
    if attr_robj is not None:
        if isinstance(attr_robj.value, list):
            node.attributes = attr_robj.value
        else:
            node.attributes = [["attr", attr_robj]]

    return node


def parse_extptrsxp(reader, rds):
    """
    Parse EXTPTRSXP (external pointer).

    According to R serialize.c:
      - pointer value itself is NOT serialized (restored as NULL)
      - prot, tag, and attributes ARE serialized

    Layout on disk:
        [EXTPTRSXP header]
        PROT  = ReadItem(...)
        TAG   = ReadItem(...)
        ATTR  = ReadItem(...)

    We represent this as:
        value = [
            ["ptr",  None],
            ["prot", <Robj>],
            ["tag",  <Robj>],
        ]
    """

    prot = parse_object(reader, rds)
    tag = parse_object(reader, rds)
    attrs = parse_object(reader, rds)

    value = [
        ["ptr", None],  # pointer is always NULL after unserialization
        ["prot", prot],
        ["tag", tag],
    ]

    return value, attrs


def factor_to_array(robj):

    val = None
    cl = robj.get("class")
    if (cl is not None) and "factor" in cl.value:
        val = np.empty(len(robj.value), dtype=StringDType(na_object=np.nan))
        levels = robj.get("levels").value
        
        for i in range(len(robj.value)):
            if robj.value[i] != INT_NA: val[i] = levels[robj.value[i] - 1]
            else: val[i] = np.nan
    
    return val
