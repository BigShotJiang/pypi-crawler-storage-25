
from .converter import as_anndata, as_data_frame, is_default_index, array_to_numpy, as_numpy
from .rds import r_obj
import numpy as np
import pandas as pd
from exprmat import error, warning


def load_seurat(
    robj: r_obj, assay = 'RNA', layer = None, embeddings = None, 
    default_layer = 'counts'
):
    if robj.get_class() != 'Seurat':
        error(f'the rds object is not of type Seurat, but {robj.get_class()}')
    
    major = int(robj['version'][0][0][0])
    
    if major == 1:
        error('seurat v1 object are not supported.')
    elif major == 2:
        error('seurat v2 object are not supported.')
    elif major == 3 or major == 4:
        return load_seurat_v3_v4(robj, assay, layer, embeddings, default_layer)
    elif major == 5:
        return load_seurat_v5(robj, assay, layer, embeddings, default_layer)
    else: error(f'seurat v{major} object are not supported.')


def load_seurat_v3_v4(
    robj: r_obj, assay = 'RNA', layer = None, embeddings = None, 
    default_layer = 'counts'
):
    """
    Converts a Seurat object into AnnData.

    1. All layers (by default) or specified layer in a specified assay. (layers)
    2. Cell metadata table (obs)
    3. Variable metadata if any (var)
    4. All or specified dimension reductions (obsm)
    """

    assay_names = robj.get(["assays", "names"]).value.tolist()
    if isinstance(assay, str): assay = assay_names.index(assay)

    layer_names = robj.get(["assays", assay]).value
    layer_names = [x[0] for x in layer_names]
    layer_names = [x for x in layer_names if x in ['counts', 'data', 'scale.data']]
    if layer is None: layer = layer_names
    if type(default_layer) is int: default_layer = layer[default_layer]

    cnts = robj.get(["assays", assay, default_layer])
    obs = as_data_frame(robj.get("meta.data"))
    var = as_data_frame(robj.get(["assays", assay, "meta.features"]))
    
    adata = as_anndata(cnts)

    # load other layers:
    for i, lname in enumerate(layer_names):
        if lname == default_layer: continue
        npa = as_numpy(robj.get(["assays", assay, lname])).T
        if npa.shape == adata.shape:
            adata.layers[lname] = npa

    # try to get obs names from assay if they absent in layer
    if is_default_index(adata.obs):
        obs_names = robj.get(["assays", assay, "cells", "dimnames", 0])
        if (obs_names is not None) and (len(obs_names.value) == adata.shape[0]):
            adata.obs_names = obs_names.value

    # try to keep dimnames if they are missed in obs/var
    if is_default_index(obs) and (obs.shape[0] == adata.shape[0]):
        obs.index = adata.obs_names

    # one more place to find obs_names
    if is_default_index(obs):
        obs_names = robj.get(["active.ident", "names"]).value
        if obs.shape[0] == len(obs_names):
            obs.index = obs_names

    if is_default_index(var):
        var.index = adata.var_names

    if not is_default_index(obs) and not is_default_index(adata.obs):
        obs = obs.loc[adata.obs_names, :]

    adata.obs = obs
    adata.var = var

    # load reduced dims
    rdims = robj.get(["reductions"])
    rdims_names = rdims.get("names")
    if rdims_names is not None:
        rdims_names = rdims_names.value
        for i in range(len(rdims_names)):
            
            if embeddings:
                if rdims_names not in embeddings:
                    continue

            assay_used = rdims.get([i, "assay.used", 0])
            if (assay_used is None) or assay_used == assay_names[assay]:
                adata.obsm[rdims_names[i]] = array_to_numpy(
                    rdims.get([i, "cell.embeddings"])
                )

    return adata


def load_seurat_v5(
    robj: r_obj, assay = 'RNA', layer = None, embeddings = None, 
    default_layer = 'counts'
):
    assay_names = robj.get(["assays", "names"]).value.tolist()
    if isinstance(assay, str): assay = assay_names.index(assay)

    layer_names = robj.get(["assays", assay, 'layers', 'names']).value.tolist()
    if layer is None: layer = layer_names
    if type(default_layer) is str: default_layer = layer.index(default_layer)

    cnts = robj.get(["assays", assay, 'layers', default_layer])
    obs = as_data_frame(robj.get("meta.data"))

    # seurat v5 have cancelled the gene-wise metadata.
    # only gene names are kept.
    var = pd.DataFrame(index = robj.get(["assays", assay, "features", "dimnames", 0]).value)
    
    adata = as_anndata(cnts)

    # load other layers:
    for i, lname in enumerate(layer_names):
        if lname == default_layer: continue
        npa = as_numpy(robj.get(["assays", assay, 'layers', i])).T
        if npa.shape == adata.shape:
            adata.layers[lname] = npa

    # try to get obs names from assay if they absent in layer
    if is_default_index(adata.obs):
        obs_names = robj.get(["assays", assay, "cells", "dimnames", 0])
        if (obs_names is not None) and (len(obs_names.value) == adata.shape[0]):
            adata.obs_names = obs_names.value

    # try to keep dimnames if they are missed in obs/var
    if is_default_index(obs) and (obs.shape[0] == adata.shape[0]):
        obs.index = adata.obs_names

    # one more place to find obs_names
    if is_default_index(obs):
        obs_names = robj.get(["active.ident", "names"]).value
        if obs.shape[0] == len(obs_names):
            obs.index = obs_names

    if is_default_index(var):
        var.index = adata.var_names

    if not is_default_index(obs) and not is_default_index(adata.obs):
        obs = obs.loc[adata.obs_names, :]

    adata.obs = obs
    adata.var = var

    # load reduced dims
    rdims = robj.get(["reductions"])
    rdims_names = rdims.get("names")
    if rdims_names is not None:
        rdims_names = rdims_names.value
        for i in range(len(rdims_names)):
            
            if embeddings:
                if rdims_names not in embeddings:
                    continue

            assay_used = rdims.get([i, "assay.used", 0])
            if (assay_used is None) or assay_used == assay_names[assay]:
                adata.obsm[rdims_names[i]] = array_to_numpy(
                    rdims.get([i, "cell.embeddings"])
                )

    return adata