
from __future__ import annotations
from typing import Literal

import jax.numpy as jnp
import numpy as np
import numpyro as npy
import numpyro.distributions as npd
from anndata import AnnData
from jax import config, random
from mudata import MuData
from numpyro.infer import Predictive
import pandas as pd
from xarray import DataTree

from exprmat.descriptive.composition import compositional_model
from exprmat import error, warning
config.update("jax_enable_x64", True)


class sccoda(compositional_model):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def make_arviz(  # type: ignore
        self,
        data: AnnData,
        rng_key: int | None = None,
        num_prior_samples: int = 500,
        use_posterior_predictive: bool = True,
    ) -> DataTree:
        
        sample_adata = data
        if not self.mcmc: 
            error("no mcmc sampling found. please run a sampler first")

        # feature names
        cell_types = sample_adata.var.index.to_list()

        # arviz dimensions
        dims = {
            "alpha": ["cell_type"],
            "sigma_d": ["covariate", "0"],
            "b_offset": ["covariate", "cell_type_nb"],
            "ind_raw": ["covariate", "cell_type_nb"],
            "ind": ["covariate", "cell_type_nb"],
            "b_raw": ["covariate", "cell_type_nb"],
            "beta": ["covariate", "cell_type"],
            "concentrations": ["obs", "cell_type"],
            "predictions": ["obs", "cell_type"],
            "counts": ["obs", "cell_type"],
        }

        # arviz coordinates
        reference_index = sample_adata.uns["sccoda"]["reference_index"]
        cell_types_nb = cell_types[:reference_index] + cell_types[reference_index + 1 :]
        coords = {
            "cell_type": cell_types,
            "cell_type_nb": cell_types_nb,
            "covariate": sample_adata.uns["sccoda"]["covariate_names"],
            "obs": sample_adata.obs.index,
        }

        dtype = "float64"

        # Prior and posterior predictive simulation
        numpyro_covariates = jnp.array(sample_adata.obsm["covariate_matrix"], dtype=dtype)
        numpyro_n_total = jnp.array(sample_adata.obsm["sample_counts"], dtype=dtype)
        ref_index = jnp.array(sample_adata.uns["sccoda"]["reference_index"])

        if rng_key is None:
            rng = np.random.default_rng()
            rng_key = random.key(rng.integers(0, 10000))
        else: rng_key = random.key(rng_key)

        if use_posterior_predictive:
            posterior_predictive = Predictive(self.model, self.mcmc.get_samples())(
                rng_key,
                counts=None,
                covariates=numpyro_covariates,
                n_total=numpyro_n_total,
                ref_index=ref_index,
                sample_adata=sample_adata,
            )

            # Remove problematic posterior predictive arrays with wrong dimensions
            if posterior_predictive and "counts" in posterior_predictive:
                counts_shape = posterior_predictive["counts"].shape
                expected_dims = 2  # ['sample', 'cell_type']
                if len(counts_shape) != expected_dims:
                    posterior_predictive = {k: v for k, v in posterior_predictive.items() if k != "counts"}
                    warning(f"removed 'counts' from posterior_predictive due to dimension mismatch")
                    warning(f"got {len(counts_shape)}D, expected {expected_dims}D")
        else:
            posterior_predictive = None

        if num_prior_samples > 0:
            prior = Predictive(self.model, num_samples=num_prior_samples)(
                rng_key,
                counts=None,
                covariates=numpyro_covariates,
                n_total=numpyro_n_total,
                ref_index=ref_index,
                sample_adata=sample_adata,
            )
            # Remove problematic prior arrays with wrong dimensions
            if prior and "counts" in prior:
                counts_shape = prior["counts"].shape
                expected_dims = 2  # ['sample', 'cell_type']
                if len(counts_shape) != expected_dims:
                    prior = {k: v for k, v in prior.items() if k != "counts"}
                    warning(f"removed 'counts' from posterior_predictive due to dimension mismatch")
                    warning(f"got {len(counts_shape)}D, expected {expected_dims}D")
        
        else: prior = None

        import arviz as az

        # Create arviz object
        arviz_data = az.from_numpyro(
            self.mcmc, prior = prior, 
            posterior_predictive = posterior_predictive, 
            dims = dims, coords = coords
        )

        return arviz_data
    

    def prepare(
        self,
        adata: AnnData,
        formula: str,
        reference_cell_type: str = "automatic",
        automatic_reference_absence_threshold: float = 0.05,
    ) -> AnnData | MuData:
        
        adata = super().prepare(
            adata, formula, reference_cell_type, 
            automatic_reference_absence_threshold
        )
        
        # all parameters that are returned for analysis
        adata.uns["sccoda"]["param_names"] = [
            "sigma_d", "b_offset",
            "ind_raw", "alpha",
            "ind", "b_raw", "beta",
            "concentration",
            "prediction",
        ]

        adata.uns["sccoda"]["model_type"] = "classic"
        adata.uns["sccoda"]["select_type"] = "spikeslab"

        return adata


    def set_init_mcmc_states(
        self, rng_key: None, ref_index: np.ndarray, 
        sample_adata: AnnData
    ) -> AnnData:  # type: ignore

        # data dimensions
        N, D = sample_adata.obsm["covariate_matrix"].shape
        P = sample_adata.X.shape[1]

        # sizes of different parameter matrices
        alpha_size = [P]
        sigma_size = [D, 1]
        beta_nobl_size = [D, P - 1]

        # initial MCMC states
        rng = np.random.default_rng(seed=rng_key)

        sample_adata.uns["sccoda"]["mcmc"]["init_params"] = {
            "sigma_d": np.ones(dtype=np.float64, shape=sigma_size),
            "b_offset": rng.normal(0.0, 1.0, beta_nobl_size),
            "ind_raw": np.zeros(dtype=np.float64, shape=beta_nobl_size),
            "alpha": rng.normal(0.0, 1.0, alpha_size),
        }

        return sample_adata


    def model(  # type: ignore
        self,
        counts: np.ndarray,
        covariates: np.ndarray,
        n_total: np.ndarray,
        ref_index,
        sample_adata: AnnData,
    ):
        # data dimensions
        N, D = sample_adata.obsm["covariate_matrix"].shape
        P = sample_adata.X.shape[1]

        # numpyro plates for all dimensions
        covariate_axis = npy.plate("covs", D, dim=-2)
        cell_type_axis = npy.plate("ct", P, dim=-1)
        cell_type_axis_nobl = npy.plate("ctnb", P - 1, dim=-1)
        sample_axis = npy.plate("sample", N, dim=-2)

        # effect priors
        with covariate_axis:
            sigma_d = npy.sample("sigma_d", npd.HalfCauchy(1.0))

        with covariate_axis, cell_type_axis_nobl:
            b_offset = npy.sample("b_offset", npd.Normal(0.0, 1.0))

            # spike-and-slab
            ind_raw = npy.sample("ind_raw", npd.Normal(0.0, 1.0))
            ind_scaled = ind_raw * 50
            ind = npy.deterministic("ind", jnp.exp(ind_scaled) / (1 + jnp.exp(ind_scaled)))

            b_raw = sigma_d * b_offset

            beta_raw = npy.deterministic("b_raw", ind * b_raw)

        with cell_type_axis:
            # intercepts
            alpha = npy.sample("alpha", npd.Normal(0.0, 5.0))

            # add 0 effect reference feature
            with covariate_axis:
                beta_full = jnp.concatenate(
                    (beta_raw[:, :ref_index], jnp.zeros(shape = [D, 1]), beta_raw[:, ref_index:]), axis = -1)
                beta = npy.deterministic("beta", beta_full)

        # combine intercepts and effects
        with sample_axis:
            concentrations = npy.deterministic(
                "concentrations", jnp.nan_to_num(jnp.exp(alpha + jnp.matmul(covariates, beta)), 0.0001))

        # calculate DM-distributed counts
        predictions = npy.sample("counts", npd.DirichletMultinomial(concentrations, n_total), obs=counts)

        return predictions


    def run_nuts(
        self,
        data: AnnData,
        num_samples: int = 10000,
        num_warmup: int = 1000,
        rng_key: int = 0,
        copy: bool = False,
        *args,
        **kwargs,
    ):
        return super().run_nuts(
            data, num_samples, 
            num_warmup, rng_key, copy, *args, **kwargs
        )


    def credible_effects(
        self, data: AnnData,
        est_fdr: float = None
    ) -> pd.Series:
        return super().credible_effects(data, est_fdr)

