import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
from typing import Literal

import networkx as nx
from typing import Dict, Any
from exprmat.nmf.models.nmf import Nmf
from exprmat import error


def freq_calculate(meta: pd.DataFrame) -> pd.DataFrame:
    
    # Create contingency table
    mat_ct = pd.crosstab(meta['fine'], meta['sample'])

    # Get major mapping (deduplicated)
    meta_sc = meta[['major', 'fine']].drop_duplicates()
    meta_sc = meta_sc.set_index('fine').sort_index()

    # Sort mat_ct by fine
    mat_ct = mat_ct.sort_index()

    # Add major column
    mat_ct.insert(0, 'major', meta_sc.loc[mat_ct.index, 'major'])

    # Group by major and scale each group to sum to 1
    numeric_cols = mat_ct.columns[1:]  # All columns except major
    mat_fq = mat_ct.copy()

    def scale_group(group):
        group[numeric_cols] = group[numeric_cols].div(group[numeric_cols].sum(axis = 0), axis = 1)
        return group

    mat_fq = mat_fq.groupby('major', group_keys = False, observed = False) \
        .apply(scale_group, include_groups = False)
    
    return mat_fq.fillna(0)


def freq_normalize(
    mat_fq: pd.DataFrame,
    normalize: Literal["minmax", "zscore"] = "minmax"
) -> pd.DataFrame:
    
    # Remove major column
    mat_numeric = mat_fq.copy()

    if normalize == "minmax":
        # Min-Max normalization: (X - min) / (max - min)
        row_min = mat_numeric.min(axis=1)
        row_max = mat_numeric.max(axis=1)

        mat_normalize = mat_numeric.sub(row_min, axis=0)
        # Add epsilon to avoid division by zero when max == min
        denominator = row_max - row_min
        denominator = denominator.replace(0, 1e-10)
        mat_normalize = mat_normalize.div(denominator, axis=0)

    elif normalize == "zscore":
        # Z-Score normalization: (X - mean) / std
        row_mean = mat_numeric.mean(axis=1)
        row_std = mat_numeric.std(axis=1)

        mat_normalize = mat_numeric.sub(row_mean, axis=0)
        # Add epsilon to avoid division by zero when std == 0
        row_std = row_std.replace(0, 1e-10)
        mat_normalize = mat_normalize.div(row_std, axis=0)

        # Clip negative values to 0
        mat_normalize = mat_normalize.clip(lower=0)

    else: error(f"unknown normalization method: {normalize}")

    return mat_normalize


def pair_correlation(
    mat_fq: pd.DataFrame,
    method: Literal["pearson", "spearman"] = "pearson"
) -> pd.DataFrame:
    """
    Calculate pairwise correlations between cell subsets.

    Parameters
    ----------
    mat_fq : pd.DataFrame
        Frequency matrix with major column + sample columns
    method : {"pearson", "spearman"}, default="pearson"
        Correlation method

    Returns
    -------
    pd.DataFrame
        Columns: fine1, fine2, major1, major2,
                 correlation, pval, pval_fdr, spe
    """
    # Extract major and numeric data
    major_cluster = mat_fq.iloc[:, 0]
    mat_numeric = mat_fq.iloc[:, 1:]

    # Compute correlation matrix
    corr_matrix = mat_numeric.T.corr(method=method)
    n_clusters = len(corr_matrix)

    # Calculate p-values for each pair
    pval_matrix = np.ones((n_clusters, n_clusters))

    if method == "pearson": corr_func = stats.pearsonr
    else: corr_func = stats.spearmanr

    for i in range(n_clusters):
        for j in range(i + 1, n_clusters):
            import warnings
            with warnings.catch_warnings():
                warnings.filterwarnings('ignore')
                _, p = corr_func(mat_numeric.iloc[i], mat_numeric.iloc[j])
                pval_matrix[i, j] = p
                pval_matrix[j, i] = p
    
    # missing or zeros introduce nan correlation
    pval_matrix[np.isnan(pval_matrix)] = 1

    # Apply FDR correction
    # Extract upper triangle p-values
    upper_tri_indices = np.triu_indices(n_clusters, k=1)
    pvals_upper = pval_matrix[upper_tri_indices]

    # FDR correction
    _, pvals_fdr, _, _ = multipletests(pvals_upper, method = 'fdr_bh')

    # Create FDR matrix
    pval_fdr_matrix = np.ones((n_clusters, n_clusters))
    pval_fdr_matrix[upper_tri_indices] = pvals_fdr
    pval_fdr_matrix = pval_fdr_matrix + pval_fdr_matrix.T - np.diag(np.diag(pval_fdr_matrix))

    # Calculate specificity for each pair
    spe_matrix = np.zeros((n_clusters, n_clusters))

    for i in range(n_clusters):
        for j in range(i + 1, n_clusters):
            r_ij = corr_matrix.iloc[i, j]

            # Background set: {r_ik, r_kj | k ≠ i, j}
            background = []
            for k in range(n_clusters):
                if k != i and k != j:
                    background.append(corr_matrix.iloc[i, k])
                    background.append(corr_matrix.iloc[k, j])

            if len(background) > 0:
                # Fraction of background correlations <= r_ij
                spe = np.sum(np.array(background) <= r_ij) / len(background)
            else: spe = 1.0

            spe_matrix[i, j] = spe
            spe_matrix[j, i] = spe

    # Extract upper triangle and convert to long format
    results = []
    for i in range(n_clusters):
        for j in range(i + 1, n_clusters):
            results.append({
                'fine1': corr_matrix.index[i],
                'fine2': corr_matrix.index[j],
                'correlation': corr_matrix.iloc[i, j],
                'pval': pval_matrix[i, j],
                'pval_fdr': pval_fdr_matrix[i, j] - 1,
                'spe': spe_matrix[i, j]
            })

    return pd.DataFrame(results)



def _update_h_kl(V, W, H, max_iter=100, tol=1e-4):
    """
    Multiplicative update for H with fixed W (KL divergence).

    Parameters
    ----------
    V : np.ndarray
        Target matrix (features × samples)
    W : np.ndarray
        Fixed basis matrix (features × components)
    H : np.ndarray
        Coefficient matrix to update (components × samples)
    max_iter : int, default=100
        Maximum number of iterations
    tol : float, default=1e-4
        Convergence tolerance

    Returns
    -------
    np.ndarray
        Updated H matrix
    """
    eps = 1e-10

    for i in range(max_iter):
        H_old = H.copy()

        # Multiplicative update rule for KL divergence
        # H = H * (W.T @ (V / (W @ H))) / (W.T @ 1)
        WH = W @ H + eps
        numerator = W.T @ (V / WH)
        denominator = W.sum(axis=0, keepdims=True).T + eps

        H = H * (numerator / denominator)
        H = np.maximum(H, eps)

        # Check convergence
        if np.linalg.norm(H - H_old) < tol:
            break

    return H


def cm_network(
    nmf_result: Nmf,
    cor_result: pd.DataFrame,
    proportions: pd.DataFrame,
    top_n: int = 10,
    corr: float = 0.2,
    fdr: float = 0.05
) -> Dict[str, Any]:
    """
    Construct cellular module network.

    Parameters
    ----------
    nmf_result : sklearn.decomposition.NMF or fitted NMF object
        Fitted NMF model with components (W matrix)
    cor_result : pd.DataFrame
        Output from pair_correlation
    top_n : int, default=10
        Number of top cell subsets per CM
    corr : float, default=0.2
        Correlation threshold
    fdr : float, default=0.05
        FDR threshold

    Returns
    -------
    dict
        {
            'global': {'node': df, 'edge': df},
            'each': {'node': df, 'edge': df},
            'raw': nmf_result,
            'filter': df (weights),
            'ann': df (annotations)
        }
    """
    # Extract W matrix (basis matrix)
    W = nmf_result.W
    n_cms = W.shape[1]
    n_all = W.shape[0]

    # Create CM names
    cm_names = [f"CM{i+1:02d}" for i in range(n_cms)]

    # Create weight dataframe
    weight_df = pd.DataFrame(W, columns = cm_names)
    weight_df.insert(0, 'fine', proportions.index.tolist())

    # Select top_n cell subsets per CM
    top_clusters = {}
    filter_list = []

    for cm in cm_names:
        top_idx = weight_df[cm].nlargest(top_n).index
        top_clusters[cm] = weight_df.loc[top_idx, 'fine'].tolist()

        for idx in top_idx:
            filter_list.append({
                'CM': cm,
                'fine': weight_df.loc[idx, 'fine'],
                'weight': weight_df.loc[idx, cm]
            })

    filter_df = pd.DataFrame(filter_list)

    # Calculate specificity cutoff
    spe_cutoff = 1 - ((top_n - 1) * 2 - 1) / ((n_all - 1) * 2 - 1)

    # Filter correlation edges
    filtered_edges = cor_result[
        (cor_result['correlation'] > corr) &
        (cor_result['pval_fdr'] < fdr) &
        (cor_result['spe'] > spe_cutoff)
    ].copy()

    # Build global network
    G_global = nx.Graph()

    # Add nodes
    for _, row in filter_df.iterrows():
        G_global.add_node(
            row['fine'],
            CM=row['CM'],
            weight=row['weight']
        )

    # Add edges
    for _, row in filtered_edges.iterrows():
        if row['fine1'] in G_global.nodes and row['fine2'] in G_global.nodes:
            G_global.add_edge(
                row['fine1'],
                row['fine2'],
                correlation=row['correlation'],
                pval=row['pval'],
                pval_fdr=row['pval_fdr'],
                spe=row['spe']
            )

    # Convert global network to dataframes
    global_nodes = pd.DataFrame([
        {'fine': node, **data}
        for node, data in G_global.nodes(data=True)
    ])

    global_edges = pd.DataFrame([
        {'fine1': u, 'fine2': v, **data}
        for u, v, data in G_global.edges(data=True)
    ])

    # Build per-CM subgraphs
    each_nodes_list = []
    each_edges_list = []

    for cm in cm_names:
        # Get nodes for this CM
        cm_nodes = [n for n in G_global.nodes if G_global.nodes[n].get('CM') == cm]

        if len(cm_nodes) == 0:
            continue

        # Create subgraph
        subgraph = G_global.subgraph(cm_nodes).copy()

        # Remove isolated nodes
        isolated = list(nx.isolates(subgraph))
        subgraph.remove_nodes_from(isolated)

        # Convert to dataframes
        for node, data in subgraph.nodes(data=True):
            each_nodes_list.append({'CM': cm, 'fine': node, **data})

        for u, v, data in subgraph.edges(data=True):
            each_edges_list.append({'CM': cm, 'fine1': u, 'fine2': v, **data})

    each_nodes = pd.DataFrame(each_nodes_list) if each_nodes_list else pd.DataFrame()
    each_edges = pd.DataFrame(each_edges_list) if each_edges_list else pd.DataFrame()

    # Create annotation dataframe
    ann_df = filter_df.copy()

    return {
        'global': {'node': global_nodes, 'edge': global_edges},
        'each': {'node': each_nodes, 'edge': each_edges},
        'raw': nmf_result,
        'filter': filter_df,
        'ann': ann_df
    }



def sc_cm_recover(ref: Dict[str, Any], mat_fq: pd.DataFrame) -> np.ndarray:
    """Recover cellular modules in new scRNA-seq data.

    Parameters
    ----------
    ref : dict
        Output from cm_network (contains NMF result)
    mat_fq : pd.DataFrame
        Normalized frequency matrix for new data (without major column)

    Returns
    -------
    np.ndarray
        CM abundance matrix (CMs × samples)
    """
    # Extract W matrix from reference
    nmf_result = ref['raw']
    W = nmf_result.components_.T  # features × components

    # Get filter info to match row order
    filter_df = ref['filter']
    fines = filter_df['fine'].unique()

    # Align mat_fq rows with W rows
    # Ensure mat_fq has the same fines as in W
    mat_fq_aligned = mat_fq.loc[fines].copy()

    # Filter rows with zero variance
    row_vars = mat_fq_aligned.var(axis=1)
    valid_rows = row_vars > 0

    W_filtered = W[valid_rows, :]
    V = mat_fq_aligned.loc[valid_rows].values

    # Initialize H randomly
    n_components = W_filtered.shape[1]
    n_samples = V.shape[1]
    H = np.random.rand(n_components, n_samples)

    # Update H with fixed W
    H = _update_h_kl(V, W_filtered, H, max_iter=100, tol=1e-4)

    # Create CM names and sort
    cm_names = [f"CM{i+1:02d}" for i in range(n_components)]
    H_df = pd.DataFrame(H, index=cm_names, columns=mat_fq_aligned.columns)
    H_df = H_df.sort_index()

    return H_df.values
