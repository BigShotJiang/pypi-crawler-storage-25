
from __future__ import annotations

import warnings
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Literal

import jax.numpy as jnp
import numpy as np
import pandas as pd
import scanpy as sc
from anndata import AnnData
from jax import config, random
from mudata import MuData
from numpyro.infer import HMC, MCMC, NUTS, initialization
import numpyro as npy
from scipy.cluster import hierarchy as sp_hierarchy
import arviz as az

from exprmat import error, warning, info
config.update("jax_enable_x64", True)


class compositional_model(ABC):

    @abstractmethod
    def __init__(self):
        pass

    @abstractmethod
    def make_arviz(self, *args, **kwargs):
        pass

    @abstractmethod
    def model(self, *args, **kwargs):
        pass

    @abstractmethod
    def set_init_mcmc_states(self, *args, **kwargs):
        pass

    def prepare(
        self,
        sample_adata: AnnData,
        formula: str,
        reference_cell_type: str = "automatic",
        automatic_reference_absence_threshold: float = 0.05,
    ) -> AnnData:
        """
        Handles data preprocessing, covariate matrix creation, reference selection, 
        and zero count replacement.

        Arguments
        ---------

        sample_adata: 
            anndata object with cell counts as sample_adata.X and covariates saved in 
            sample_adata.obs.

        formula: 
            R-style formula for building the covariate matrix.
            Categorical covariates are handled automatically, with the covariate value of 
            the first sample being used as the reference category.
            To set a different level as the base category for a categorical covariate, 
            use "C(<CovariateName>, Treatment('<ReferenceLevelName>'))"

        reference_cell_type: 
            Column name that sets the reference cell type.
            Reference the name of a column. If "automatic", the cell type with the 
            lowest dispersion in relative abundance that is present in at least 90% 
            of samlpes will be chosen.

        automatic_reference_absence_threshold: 
            If using reference_cell_type = "automatic", determine the maximum fraction 
            of zero entries for a cell type to be considered as a possible reference cell type.

        Returns:
            AnnData object that is ready for CODA models.
        """
        dtype = "float64"

        # Convert count data to float64 (needed for correct inference)
        sample_adata.X = sample_adata.X.astype(dtype)

        # Build covariate matrix from R-like formula, save in obsm
        import patsy

        covariate_matrix = patsy.dmatrix(formula, sample_adata.obs)
        covariate_names = covariate_matrix.design_info.column_names[1:]
        sample_adata.obsm["covariate_matrix"] = np.array(covariate_matrix[:, 1:]).astype(dtype)

        cell_types = sample_adata.var.index.to_list()

        # Invoke instance of the correct model depending on reference cell type
        # Automatic reference selection (dispersion-based)
        if reference_cell_type == "automatic":
            percent_zero = np.sum(sample_adata.X == 0, axis=0) / sample_adata.X.shape[0]
            nonrare_ct = np.where(percent_zero < automatic_reference_absence_threshold)[0]

            if len(nonrare_ct) == 0:
                warning("no cell types that have large enough presence") 
                error("please increase automatic_reference_absence_threshold")

            rel_abun = sample_adata.X / np.sum(sample_adata.X, axis=1, keepdims=True)

            # select reference
            cell_type_disp = np.var(rel_abun, axis=0) / (np.mean(rel_abun, axis=0) + 1e-8)
            min_var = np.min(cell_type_disp[nonrare_ct])
            ref_index = np.where(cell_type_disp == min_var)[0][0]

            ref_cell_type = cell_types[ref_index]
            info(f"automatic reference selection: reference cell type set to {ref_cell_type}")

        # Column name as reference cell type
        elif reference_cell_type in cell_types:
            ref_index = cell_types.index(reference_cell_type)

        # None of the above: Throw error
        else: error("reference index is not a valid cell type name or numerical index")

        # Add pseudocount if zeroes are present.
        if np.count_nonzero(sample_adata.X) != np.size(sample_adata.X):
            info("zero counts encountered in data! Added a pseudocount of 0.5.")
            sample_adata.X[sample_adata.X == 0] = 0.5

        sample_adata.obsm["sample_counts"] = np.sum(sample_adata.X, axis = 1)

        # Check for relative abundances
        if np.allclose(sample_adata.obsm["sample_counts"], 1.0):
            warning("all samples sum to ~1, suggesting relative abundances were provided. ")
            warning("sccoda requires absolute cell counts. results may be meaningless.")

        # Check input data
        if covariate_matrix.shape[0] != sample_adata.X.shape[0]:
            row_len_covariate_matrix = sample_adata.obsm["covariate_matrix"].shape[0]
            row_len_sample_adata = sample_adata.X.shape[0]
            error(f"wrong input dimensions x[{row_len_covariate_matrix},:] != y[{row_len_sample_adata},:]")
        
        if covariate_matrix.shape[0] != len(sample_adata.obsm["sample_counts"]):
            covariate_matrix = sample_adata.obsm["covariate_matrix"]
            len_sample_counts = len(sample_adata.obsm["sample_counts"])
            error(f"wrong input dimensions x[{covariate_matrix},:] != n_total[{len_sample_counts}]")

        # Save important model parameters in uns
        sample_adata.uns["sccoda"] = {
            "formula": formula,
            "reference_cell_type": cell_types[ref_index],
            "reference_index": ref_index,
            "automatic_reference_absence_threshold": automatic_reference_absence_threshold,
            "covariate_names": covariate_names,
            "mcmc": {"init_params": []},
        }

        return sample_adata

    def run_mcmc(
        self,
        sample_adata: AnnData,
        kernel: npy.infer.mcmc.MCMCKernel,
        rng_key = None,
        copy: bool = False,
        *args,
        **kwargs,
    ):
        dtype = "float64"

        # The tracked MCMC parameters for diagnostic checks
        extra_fields = (
            "potential_energy",
            "num_steps",
            "adapt_state.step_size",
            "accept_prob",
            "mean_accept_prob",
        )

        # Convert all data needed for modeling to numpyro arrays
        numpyro_counts = jnp.array(sample_adata.X, dtype = dtype)
        numpyro_covariates = jnp.array(sample_adata.obsm["covariate_matrix"], dtype = dtype)
        numpyro_n_total = jnp.array(sample_adata.obsm["sample_counts"], dtype = dtype)

        # Create mcmc attribute and run inference
        self.mcmc = MCMC(kernel, progress_bar = False, *args, **kwargs)
        self.mcmc.run(
            rng_key,
            numpyro_counts,
            numpyro_covariates,
            numpyro_n_total,
            jnp.array(sample_adata.uns["sccoda"]["reference_index"]),
            sample_adata,
            extra_fields = extra_fields,
        )

        acc_rate = np.array(self.mcmc.last_state.mean_accept_prob)
        if acc_rate < 0.6:
            warning(f"acceptance rate unusually low ({acc_rate} < 0.5)! results might be incorrect. ")
            warning(f"please check feasibility of results and re-run the sampling step with a different rng_key if necessary.")
        
        if acc_rate > 0.95:
            warning(f"acceptance rate unusually high ({acc_rate} > 0.95)! results might be incorrect. ")
            warning(f"please check feasibility of results and re-run the sampling step with a different rng_key if necessary.")

        # Set acceptance rate and save sampled values to `sample_adata.uns`
        sample_adata.uns["sccoda"]["mcmc"]["acceptance_rate"] = np.array(self.mcmc.last_state.mean_accept_prob)
        samples = self.mcmc.get_samples()
        for k, v in samples.items():
            samples[k] = np.array(v)
        sample_adata.uns["sccoda"]["mcmc"]["samples"] = samples

        # Evaluate results and create result dataframes (based on tree-aggregation or not)
        if sample_adata.uns["sccoda"]["model_type"] == "classic":
            intercept_df, effect_df = self.summary_prepare(sample_adata)  # type: ignore
        elif sample_adata.uns["sccoda"]["model_type"] == "tree_agg":
            intercept_df, effect_df, node_df = self.summary_prepare(sample_adata)  # type: ignore
            # Save node df in `sample_adata.uns`
            sample_adata.uns["sccoda"]["node_df"] = node_df
        else: error("no valid model type.")

        # Save intercept and effect dfs in `sample_adata.varm` (one effect df per covariate)
        sample_adata.varm["intercept_df"] = intercept_df
        for cov in effect_df.index.get_level_values("Covariate"):
            sample_adata.varm[f"effect_df_{cov}"] = effect_df.loc[cov, :]
        if copy: return sample_adata


    def run_nuts(
        self,
        adata: AnnData,
        num_samples: int = 10000,
        num_warmup: int = 1000,
        rng_key: int = 0,
        copy: bool = False,
        *args,
        **kwargs,
    ):
        """
        Run No-U-turn sampling (Hoffman and Gelman, 2014), an efficient version of 
        Hamiltonian Monte Carlo sampling to infer optimal model parameters.

        data: AnnData object or MuData object.
        modality_key: If data is a MuData object, specify which modality to use.
        num_samples: Number of sampled values after burn-in.
        num_warmup: Number of burn-in (warmup) samples.
        rng_key: The rng state used.
        copy: Return a copy instead of writing to adata.
        *args: Additional args passed to numpyro NUTS
        **kwargs: Additional kwargs passed to numpyro NUTS

        Returns:
            Calls `self.__run_mcmc`
        """
        
        sample_adata = adata
        if copy: sample_adata = sample_adata.copy()

        rng_key_array = random.key_data(random.key(rng_key))
        sample_adata.uns["sccoda"]["mcmc"]["rng_key"] = np.array(rng_key_array)

        # Set up NUTS kernel
        sample_adata = self.set_init_mcmc_states(
            rng_key, sample_adata.uns["sccoda"]["reference_index"], sample_adata
        )

        init_params = sample_adata.uns["sccoda"]["mcmc"]["init_params"]
        nuts_kernel = NUTS(self.model, *args, init_strategy = initialization.init_to_value(
            values = init_params), **kwargs)
        
        # Save important parameters in `sample_adata.uns`
        sample_adata.uns["sccoda"]["mcmc"]["num_samples"] = num_samples
        sample_adata.uns["sccoda"]["mcmc"]["num_warmup"] = num_warmup
        sample_adata.uns["sccoda"]["mcmc"]["algorithm"] = "NUTS"

        return self.run_mcmc(
            sample_adata, nuts_kernel, num_samples = num_samples, num_warmup = num_warmup, 
            rng_key = rng_key_array, copy = copy
        )


    def run_hmc(
        self,
        data: AnnData,
        num_samples: int = 20000,
        num_warmup: int = 5000,
        rng_key=None,
        copy: bool = False,
        *args,
        **kwargs,
    ):
        """
        Run standard Hamiltonian Monte Carlo sampling (Neal, 2011) to infer optimal model parameters.

        data: AnnData object or MuData object.
        modality_key: If data is a MuData object, specify which modality to use.
        num_samples: Number of sampled values after burn-in.
        num_warmup: Number of burn-in (warmup) samples.
        rng_key: The rng state used. If None, a random state will be selected.
        copy: Return a copy instead of writing to adata.
        *args: Additional args passed to numpyro HMC
        **kwargs: Additional kwargs passed to numpyro HMC
        """
        sample_adata = data
        if copy: sample_adata = sample_adata.copy()

        # Set rng key if needed
        if rng_key is None:
            rng = np.random.default_rng()
            rng_key = random.key(rng.integers(0, 10000))
            sample_adata.uns["sccoda"]["mcmc"]["rng_key"] = rng_key
        else: rng_key = random.key(rng_key)

        # Set up HMC kernel
        sample_adata = self.set_init_mcmc_states(
            rng_key, sample_adata.uns["sccoda"]["reference_index"], sample_adata
        )
        
        init_params = sample_adata.uns["sccoda"]["mcmc"]["init_params"]
        hmc_kernel = HMC(self.model, *args, init_strategy=initialization.init_to_value(
            values = init_params), **kwargs)

        # Save important parameters in `sample_adata.uns`
        sample_adata.uns["sccoda"]["mcmc"]["num_samples"] = num_samples
        sample_adata.uns["sccoda"]["mcmc"]["num_warmup"] = num_warmup
        sample_adata.uns["sccoda"]["mcmc"]["algorithm"] = "HMC"

        return self.run_mcmc(
            sample_adata, hmc_kernel, num_samples = num_samples, 
            num_warmup = num_warmup, rng_key = rng_key, copy = copy
        )


    def get_intercept_df(self, data: AnnData) -> pd.DataFrame:
        return data.varm["intercept_df"]

    def get_effect_df(self, data: AnnData) -> pd.DataFrame:
        
        sample_adata = data
        covariates = sample_adata.uns["sccoda"]["covariate_names"]
        effect_dfs = [sample_adata.varm[f"effect_df_{cov}"] for cov in covariates]
        effect_df = pd.concat(effect_dfs)

        effect_df.index = pd.MultiIndex.from_product(
            (covariates, sample_adata.var.index.tolist()), names=["Covariate", "Cell Type"]
        )

        effect_df.index = effect_df.index.set_levels(
            effect_df.index.levels[0].str.replace("Condition", "").str.replace("[", "").str.replace("]", ""),
            level = 0,
        )

        return effect_df

    def get_node_df(self, data: AnnData) -> pd.DataFrame:
        return data.uns["sccoda"]["node_df"]

    def credible_effects(self, data: AnnData, est_fdr: float = None) -> pd.Series:
        
        sample_adata = data
        # Get model and effect selection types
        select_type = sample_adata.uns["sccoda"]["select_type"]
        model_type = sample_adata.uns["sccoda"]["model_type"]

        # If other than None for est_fdr is specified, recalculate intercept and effect DataFrames
        if isinstance(est_fdr, float):
            if est_fdr < 0 or est_fdr > 1:
                error("est_fdr must be between 0 and 1!")
            else: _, eff_df = self.summary_prepare(sample_adata, est_fdr = est_fdr)  # type: ignore
        # otherwise, get pre-calculated DataFrames. Effect DataFrame is stitched together from varm
        elif model_type == "tree_agg" and select_type == "sslasso":
            eff_df = sample_adata.uns["sccoda"]["node_df"]
        else:
            covariates = sample_adata.uns["sccoda"]["covariate_names"]
            effect_dfs = [sample_adata.varm[f"effect_df_{cov}"] for cov in covariates]
            eff_df = pd.concat(effect_dfs)
            eff_df.index = pd.MultiIndex.from_product(
                (covariates, sample_adata.var.index.tolist()), names=["Covariate", "Cell Type"]
            )

        out = eff_df["Final Parameter"] != 0
        out.rename("credible change")

        return out
    
    def summary_prepare(
        self, sample_adata: AnnData, est_fdr: float = 0.05, *args, **kwargs
    ) -> tuple[pd.DataFrame, pd.DataFrame] | tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    
        select_type = sample_adata.uns["sccoda"]["select_type"]
        model_type = sample_adata.uns["sccoda"]["model_type"]

        # Create arviz summary for intercepts, effects and node effects
        if model_type == "tree_agg":
            var_names = ["alpha", "b_tilde", "beta"]
        elif model_type == "classic":
            var_names = ["alpha", "beta"]
        else: error("no valid model type!")

        import arviz as az

        arviz_data = self.make_arviz(
            sample_adata, num_prior_samples = 0, 
            use_posterior_predictive = False
        )

        summ = az.summary(
            data = arviz_data,
            var_names = var_names,
            kind = "stats",
            *args, **kwargs,
        )

        posterior = arviz_data["posterior"]
        summ["median"] = posterior[var_names].median(dim = ["chain", "draw"]) \
            .to_dataframe().stack().reindex(summ.index)

        effect_df = summ.loc[summ.index.str.match("|".join([r"beta\["]))].copy()
        intercept_df = summ.loc[summ.index.str.match("|".join([r"alpha\["]))].copy()

        # Build neat index
        cell_types = sample_adata.var.index.to_list()
        covariates = sample_adata.uns["sccoda"]["covariate_names"]

        intercept_df.index = pd.Index(cell_types, name="Cell Type")
        effect_df.index = pd.MultiIndex.from_product(
            [covariates, cell_types], names = ["Covariate", "Cell Type"])
        intercept_df = self.complete_alpha_df(sample_adata, intercept_df)

        # Processing only if using tree aggregation
        if model_type == "tree_agg":
            node_df = summ.loc[summ.index.str.match("|".join([r"b_tilde\["]))].copy()

            # Neat index for node df
            node_names = sample_adata.uns["sccoda"]["node_names"]
            covariates_node = [x + "_node" for x in covariates]
            node_df.index = pd.MultiIndex.from_product(
                [covariates_node, node_names], names = ["Covariate", "Node"])

            # Complete node df
            node_df = self.complete_node_df(sample_adata, node_df)

            # Complete effect df
            effect_df = self.complete_beta_df(
                sample_adata,
                intercept_df,
                effect_df,
                target_fdr = est_fdr,
                model_type = "tree_agg",
                select_type = select_type,
                node_df = node_df,
            )

        else:
            # Complete effect df
            effect_df = self.complete_beta_df(
                sample_adata, intercept_df, effect_df, target_fdr = est_fdr, 
                select_type = select_type, model_type = "classic"
            )

        # Give nice column names, remove unnecessary columns
        hdis = intercept_df.columns[intercept_df.columns.str.contains("hdi|eti")]
        hdis_new = hdis.str.replace("hdi_", "HDI ").str.replace(
            r"eti(\d+)_(lb|ub)", 
            lambda m: f"ETI {m.group(1)}% {'lower' if m.group(2) == 'lb' else 'upper'}", 
            regex = True
        )

        # Calculate credible intervals if using classical spike-and-slab
        if select_type == "spikeslab":
            # Credible interval
            ind_post = np.array(sample_adata.uns["sccoda"]["mcmc"]["samples"]["ind"])
            ind_post[ind_post < 1e-3] = np.nan

            b_raw_sel = np.array(sample_adata.uns["sccoda"]["mcmc"]["samples"]["b_raw"]) * ind_post

            res = az.from_dict(posterior = {"b_raw_sel": np.array([b_raw_sel])})

            summary_sel = az.summary(
                data = res,
                kind = "stats",
                var_names = ["b_raw_sel"],
                skipna = True,
                *args, **kwargs,
            )

            ref_index = sample_adata.uns["sccoda"]["reference_index"]
            n_conditions = len(covariates)
            n_cell_types = len(cell_types)

            def insert_row(idx, df, df_insert):
                return pd.concat(
                    [
                        df.iloc[:idx,],
                        df_insert,
                        df.iloc[idx:,],
                    ]
                ).reset_index(drop=True)

            for i in range(n_conditions):
                summary_sel = insert_row(
                    (i * n_cell_types) + ref_index,
                    summary_sel,
                    pd.DataFrame.from_dict(data={"mean": [0], "sd": [0], hdis[0]: [0], hdis[1]: [0]}),
                )

            effect_df.loc[:, hdis[0]] = list(summary_sel[hdis[0]])
            effect_df.loc[:, hdis[1]] = list(summary_sel.loc[:, hdis[1]]) 
            
        elif select_type == "sslasso": pass
        else: error("no valid select type!")

        # Select relevant columns and give nice column names for all result dfs, then return them
        intercept_df = intercept_df.loc[
            :, ["final_parameter", hdis[0], hdis[1], "sd", "expected_sample"]].copy()
        intercept_df = intercept_df.rename(
            columns = dict(zip(
                intercept_df.columns,
                ["Final Parameter", hdis_new[0], hdis_new[1], "SD", "Expected Sample"],
                strict=False,
            ))
        )

        if select_type == "sslasso":
            effect_df = effect_df.loc[
                :, ["final_parameter", "median", hdis[0], hdis[1], "sd", "expected_sample", "log_fold"]
            ].copy()

            effect_df = effect_df.rename(
                columns = dict(zip(
                    effect_df.columns,
                    ["Effect", "Median", hdis_new[0], hdis_new[1], "SD", "Expected Sample", "log2-fold change"],
                    strict=False,
                ))
            )

        else:
            effect_df = effect_df.loc[
                :, ["final_parameter", hdis[0], hdis[1], "sd", "inclusion_prob", "expected_sample", "log_fold"]
            ].copy()

            effect_df = effect_df.rename(
                columns=dict(zip(
                    effect_df.columns,
                    [
                        "Final Parameter",
                        hdis_new[0],
                        hdis_new[1],
                        "SD",
                        "Inclusion probability",
                        "Expected Sample",
                        "log2-fold change",
                    ],
                    strict=False,
                ))
            )

        if model_type == "tree_agg":

            node_df = node_df.loc[
                :, ["final_parameter", "median", hdis[0], hdis[1], "sd", "delta", "significant"]
            ].copy()

            node_df = node_df.rename(columns = dict(zip(
                node_df.columns, [
                    "Final Parameter", "Median", hdis_new[0], hdis_new[1], 
                    "SD", "Delta", "Is credible"
                ], strict = False ))
            )

            return intercept_df, effect_df, node_df
        else: return intercept_df, effect_df

    def complete_beta_df(
        self,
        sample_adata: AnnData,
        intercept_df: pd.DataFrame,
        effect_df: pd.DataFrame,
        model_type: str,
        select_type: str,
        target_fdr: float = 0.05,
        node_df: pd.DataFrame = None,
    ) -> pd.DataFrame:
        
        # Data dimensions
        D = len(effect_df.index.levels[0])
        K = len(effect_df.index.levels[1])

        # Effect processing for different models
        # Classic scCODA (spike-and-slab + no tree aggregation)
        if model_type == "classic" and select_type == "spikeslab":
            
            beta_inc_prob = []
            beta_nonzero_mean = []

            # Get MCMC samples for parameter "beta"
            beta_raw = np.array(sample_adata.uns["sccoda"]["mcmc"]["samples"]["beta"])

            # Calculate inclusion prob, nonzero mean for every effect
            for j in range(beta_raw.shape[1]):
                for i in range(beta_raw.shape[2]):
                    beta_i_raw = beta_raw[:, j, i]
                    beta_i_raw_nonzero = np.where(np.abs(beta_i_raw) > 1e-3)[0]
                    prob = beta_i_raw_nonzero.shape[0] / beta_i_raw.shape[0]
                    beta_inc_prob.append(prob)
                    if len(beta_i_raw[beta_i_raw_nonzero]) > 0:
                        beta_nonzero_mean.append(beta_i_raw[beta_i_raw_nonzero].mean())
                    else:
                        beta_nonzero_mean.append(0)

            effect_df.loc[:, "inclusion_prob"] = beta_inc_prob
            effect_df.loc[:, "mean_nonzero"] = beta_nonzero_mean

            # Inclusion prob threshold value. Direct posterior probability approach cf. Newton et al. (2004)
            def opt_thresh(result, alpha):
                incs = np.array(result.loc[result["inclusion_prob"] > 0, "inclusion_prob"])
                incs[::-1].sort()

                for c in np.unique(incs):
                    fdr = np.mean(1 - incs[incs >= c])

                    if fdr < alpha:
                        # ceiling with 3 decimals precision
                        c = np.floor(c * 10**3) / 10**3  # noqa: PLW2901
                        return c, fdr
                    
                return 1.0, 0

            threshold, fdr_ = opt_thresh(effect_df, target_fdr)

            # Save cutoff inclusion probability to scCODA params in uns
            sample_adata.uns["sccoda"]["threshold_prob"] = threshold

            # Decide whether betas are significant or not, set non-significant ones to 0
            effect_df.loc[:, "final_parameter"] = np.where(
                effect_df.loc[:, "inclusion_prob"] >= threshold, effect_df.loc[:, "mean_nonzero"], 0
            )

        # tascCODA model (spike-and-slab LASSO + tree aggregation)
        elif select_type == "sslasso" and model_type == "tree_agg":
            # Get ancestor matrix
            A = sample_adata.uns["sccoda"]["ancestor_matrix"]

            # Feature-level effects are just node-level effects time ancestor matrix
            effect_df["final_parameter"] = np.matmul(
                np.kron(np.eye(D, dtype=int), A), np.array(node_df["final_parameter"])
            )

        # Get expected sample, log-fold change
        y_bar = np.mean(np.sum(sample_adata.X, axis=1))
        alpha_par = intercept_df.loc[:, "final_parameter"]
        alphas_exp = np.exp(alpha_par)
        alpha_sample = (alphas_exp / np.sum(alphas_exp) * y_bar).values

        beta_mean = np.array(alpha_par)
        for d in range(D):
            beta_d = effect_df.loc[:, "final_parameter"].values[(d * K) : ((d + 1) * K)]
            beta_d = beta_mean + beta_d
            beta_d = np.exp(beta_d)
            beta_d = beta_d / np.sum(beta_d) * y_bar
            if d == 0:
                beta_sample = beta_d
                log_sample = np.log2(beta_d / alpha_sample)
            else:
                beta_sample = np.append(beta_sample, beta_d)
                log_sample = np.append(log_sample, np.log2(beta_d / alpha_sample))

        effect_df.loc[:, "expected_sample"] = beta_sample
        effect_df.loc[:, "log_fold"] = log_sample

        return effect_df

    def complete_node_df(
        self,
        sample_adata: AnnData,
        node_df: pd.DataFrame,
    ) -> pd.DataFrame:
        
        # calculate inclusion threshold
        theta = np.median(np.array(sample_adata.uns["sccoda"]["mcmc"]["samples"]["theta"]))
        l_0 = sample_adata.uns["sccoda"]["sslasso_pen_args"]["lambda_0"]
        l_1 = sample_adata.uns["sccoda"]["sslasso_pen_args"]["lambda_1_scaled"]

        def delta(l_0, l_1, theta):
            p_t = (theta * l_1 / 2) / ((theta * l_1 / 2) + ((1 - theta) * l_0 / 2))
            return 1 / (l_0 - l_1) * np.log(1 / p_t - 1)

        D = len(node_df.index.levels[0])

        # apply inclusion threshold
        deltas = delta(l_0, l_1, theta)
        refs = np.sort(sample_adata.uns["sccoda"]["reference_index"])
        deltas = np.insert(deltas, [refs[i] - i for i in range(len(refs))], 0)

        node_df["delta"] = np.tile(deltas, D)
        node_df["significant"] = np.abs(node_df["median"]) > node_df["delta"]
        node_df["final_parameter"] = np.where(node_df.loc[:, "significant"], node_df.loc[:, "median"], 0)

        return node_df

    def complete_alpha_df(self, sample_adata: AnnData, intercept_df: pd.DataFrame) -> pd.DataFrame:
        
        intercept_df = intercept_df.rename(columns={"mean": "final_parameter"})
        # Get expected sample
        y_bar = np.mean(np.sum(sample_adata.X, axis=1))
        alphas_exp = np.exp(intercept_df.loc[:, "final_parameter"])
        alpha_sample = (alphas_exp / np.sum(alphas_exp) * y_bar).values
        intercept_df.loc[:, "expected_sample"] = alpha_sample
        return intercept_df
