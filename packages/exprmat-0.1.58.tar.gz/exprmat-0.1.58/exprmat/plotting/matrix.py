
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage, leaves_list
from scipy.spatial.distance import pdist
from typing import Optional, Tuple
from exprmat import error

def plot_matrix(
    mat: pd.DataFrame,
    dend_x: bool = True,
    dend_y: bool = True,
    show_dend_x: bool = True,
    show_dend_y: bool = True,
    width_dend_x = 1,
    height_dend_y = 1,
    dpi: int = 100,
    figsize: Tuple[int, int] = (5, 4),
    cmap: str = 'viridis'
) -> None:
    
    from exprmat.plotting.palettes import mpl
    
    if not isinstance(mat, pd.DataFrame):
        error('mat should be a pandas dataframe')
    
    if not np.issubdtype(mat.values.dtype, np.number):
        error('mat should contain numerical values')
    
    if mat.isnull().any().any():
        error('mat contains non-numeric values (e.g. nan, inf)')
    
    mat_copy = mat.copy()
    
    # column dendrogram
    col_order = np.arange(mat_copy.shape[1])
    col_linkage = None
    if dend_x:
        col_linkage = linkage(pdist(mat_copy.T, metric = 'euclidean'), method = 'ward')
        col_order = leaves_list(col_linkage)
        mat_copy = mat_copy.iloc[:, col_order]
    
    # row dendrogram
    row_order = np.arange(mat_copy.shape[0])
    row_linkage = None
    if dend_y:
        row_linkage = linkage(pdist(mat_copy, metric = 'euclidean'), method = 'ward')
        row_order = leaves_list(row_linkage)
        mat_copy = mat_copy.iloc[row_order, :]
    
    fig = plt.figure(figsize = figsize, dpi = dpi)
    
    heatmap_left = (0.05 + width_dend_x / figsize[0]) if show_dend_y else 0.1
    heatmap_bottom = 0.05
    heatmap_width = (figsize[0] * 0.9 - width_dend_x) / figsize[0] if show_dend_x else 0.8
    heatmap_height = ((figsize[1] * 0.9 - height_dend_y) / figsize[1]) if show_dend_y else 0.9
    
    ax_row_dend = None
    if show_dend_y and dend_y:
        ax_row_dend = fig.add_axes([0.05, heatmap_bottom, width_dend_x / figsize[0], heatmap_height])

        dendrogram(row_linkage, orientation='left', ax=ax_row_dend, no_labels=True)
        ax_row_dend.set_xticks([])
        ax_row_dend.set_yticks([])
        ax_row_dend.spines['top'].set_visible(False)
        ax_row_dend.spines['bottom'].set_visible(False)
        ax_row_dend.spines['left'].set_visible(False)
    
    ax_col_dend = None
    if show_dend_x and dend_x:
        ax_col_dend = fig.add_axes([heatmap_left, 0.95 - height_dend_y / figsize[1], heatmap_width, height_dend_y / figsize[1]])

        dendrogram(col_linkage, orientation='top', ax=ax_col_dend, no_labels=True)
        ax_col_dend.set_xticks([])
        ax_col_dend.set_yticks([])
        ax_col_dend.spines['top'].set_visible(False)
        ax_col_dend.spines['left'].set_visible(False)
        ax_col_dend.spines['right'].set_visible(False)
    

    ax_heatmap = fig.add_axes([heatmap_left, heatmap_bottom, heatmap_width, heatmap_height])
    im = ax_heatmap.imshow(mat_copy.values, cmap = mpl(cmap), aspect = 'auto')
    
    ax_heatmap.set_xticks(range(len(mat_copy.columns)))
    ax_heatmap.set_xticklabels(mat_copy.columns, rotation = 45, ha='right', fontsize=9)
    ax_heatmap.set_yticks(range(len(mat_copy.index)))
    ax_heatmap.yaxis.tick_right()
    ax_heatmap.set_yticklabels(mat_copy.index, fontsize = 9, ha = 'left')
    
    return fig