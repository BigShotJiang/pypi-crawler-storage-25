
import seaborn as sns
from matplotlib import ticker
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

from matplotlib.collections import PolyCollection
from matplotlib import colors as mcolors
from scipy import sparse, stats

from exprmat.utils import find_variable, choose_layer
from exprmat.ansi import error, info
from exprmat.plotting.utils import mpl as to_matplotlib


def barplot(
    adata, *, sample_name, gene, 
    slot = 'X', group = 'cell.type', selected_groups = None, selected_splits = None,
    split = 'treat', palette = ['red', 'black'], ax = None, style = 'box',
    size = (6,3), dpi = 100, violin_kwargs = {}, legend = True, flierprops = None
):
    
    plt.rcParams["ytick.labelright"] = False
    plt.rcParams["ytick.labelleft"] = True
    
    colnames = ['logc' + x for x in [gene]]
    cellnames = ['c' + str(i) for i in range(len(adata.obs_names.tolist()))]
    lognorm = find_variable(adata, gene, layer = slot)
    data = pd.DataFrame(lognorm)
    
    data.columns = colnames
    if split == None: data['split'] = 'default.split'
    else: data['split'] = adata.obs[split].tolist()
    data['row'] = adata.obs[group].tolist()
    data['cell'] = cellnames

    longform = pd.wide_to_long(data, 'logc', i = ['cell', 'split', 'row'], j = 'name', suffix = r'[\w\.]+')
    longform = longform.reset_index()
    dropzeros = longform

    if selected_groups is None: selected_groups = adata.obs[group].value_counts().index.tolist()
    select_ct = [x in selected_groups for x in dropzeros['row'].tolist()]
    dropzeros['selected.celltype'] = select_ct
    dropzeros = dropzeros.loc[dropzeros['selected.celltype'],:]

    if selected_splits is None:
        if split is not None: selected_splits = adata.obs[split].value_counts().index.tolist()
        else: selected_splits = ['default.split']

    select_sp = [x in selected_splits for x in dropzeros['split'].tolist()]
    dropzeros = dropzeros.loc[select_sp,:]

    if ax is None: fig, axes = plt.subplots(1, 1, figsize = size, dpi = dpi)
    else: axes = ax

    if style == 'box':

        sns.boxplot(
            data = dropzeros.loc[dropzeros['name'] == gene,:],
            x = "row", y = "logc", hue = 'split', ax = axes, fill = True,
            palette = palette, saturation = 0.8, log_scale = False,
            color = '.8', linecolor = '0', order = selected_groups, gap = 0.3,
            flierprops = flierprops if flierprops else dict(markerfacecolor = '0.1', markersize = 1, linestyle = 'none'),
            showfliers = True, width = 0.6
        )
    
    elif style == 'violin':

        sns.violinplot(
            data = dropzeros.loc[dropzeros['name'] == gene,:],
            x = "row", y = "logc", hue = 'split', ax = axes, fill = True,
            palette = palette, saturation = 0.8, log_scale = False,
            color = '.8', linecolor = '0', order = selected_groups, gap = 0,
            width = 0.8, **violin_kwargs
        )
    
    else: error('can only set plot style to `box` or `violin`.')
    
    axes.tick_params(
        axis = 'y', right = False, left = True, color = 'gray', length = 4,
        grid_color = 'none'
    )
        
    axes.tick_params(
        axis = 'x', left = True, color = 'black', length = 4,
        grid_color = 'lightgray'
    )
            
    if legend: axes.legend(bbox_to_anchor = (1, 1), loc = 'upper left', borderaxespad = 0, frameon = False)
    else: axes.get_legend().remove()
    axes.set_xlabel('')
    axes.set_ylabel(f'({sample_name}) {gene}')
    # axes.set_xticks(selected_groups)
    axes.set_yticks([0.0, 2.5])

    # axes.set_xticklabels(selected_groups, rotation = 45)

    from scipy import stats
    # here, we will run the wilcox test
    gene_data = dropzeros.loc[dropzeros['name'] == gene,:]
    if group != None:
        xtl = []
        for ct in selected_groups:
            cell_data = gene_data.loc[gene_data['row'] == ct,:]
            groups = [x for _, x in cell_data.groupby(cell_data['split'])]
            values = [x['logc'].tolist() for x in groups]
            if len(values) == 2:
                w = stats.mannwhitneyu(values[0], values[1])
                rel = np.mean(np.array(values[0])) - np.mean(np.array(values[1]))
                xtl += [ct + '\n{:.3f}'.format(w.pvalue) + ' ' + ('D' if rel < 0 else 'U')]
                info(ct + ', p = {:.3f}'.format(w.pvalue) + ', ' + ('D' if rel < 0 else 'U') + ' ' + groups[0].iloc[0, 1] + ' over ' + groups[1].iloc[0, 1])
            else: xtl += [ct]
        
        # axes.set_xticks(selected_groups)
        axes.set_xticklabels(xtl, rotation = 45, ha = 'right', va = 'top')
    
    else:
        groups = [x for _, x in gene_data.groupby(gene_data['split'])]
        values = [x['logc'].tolist() for x in groups]
        xtl = 'whole'
        if len(values) == 2:
            w = stats.mannwhitneyu(values[0], values[1])
            rel = np.mean(np.array(values[0])) - np.mean(np.array(values[1]))
            xtl = 'whole\n{:.3f}'.format(w.pvalue) + ' ' + ('D' if rel < 0 else 'U')
            info(ct + ', p = {:.3f}'.format(w.pvalue) + ', ' + ('D' if rel < 0 else 'U') + ' ' + groups[0].iloc[0, 1] + ' over ' + groups[1].iloc[0, 1])
        axes.set_xticklabels([xtl], rotation = 45, ha = 'right', va = 'top')
        pass

    axes.spines[['right', 'top']].set_visible(False)
    axes.yaxis.set_major_formatter(ticker.StrMethodFormatter("{x:.1f}"))

    if ax is None: return fig
    else: return axes.figure


def compare_scatter(
    adata, *, group_x, group_y, key, slot = 'X', markers = [],
    ax = None, sample = None, figsize = (4, 4), dpi = 100
):
    import numpy as np
    x = choose_layer(adata[adata.obs[key] == group_x, :], layer = slot).copy()
    y = choose_layer(adata[adata.obs[key] == group_y, :], layer = slot).copy()
    mean_x = np.array(x.mean(axis = 0))[0]
    mean_y = np.array(y.mean(axis = 0))[0]
    varn = adata.var['gene'].tolist()

    show_text = True
    if isinstance(markers, str):
        import exprmat.reader.static as st
        
        df1 = st.rna_get_markers(
            adata, None, de_slot = markers, max_q = 0.05, min_pct = 0, max_pct_reference = 1,
            min_lfc = -100, max_lfc = -0.5
        )

        df2 = st.rna_get_markers(
            adata, None, de_slot = markers, max_q = 0.05, min_pct = 0, max_pct_reference = 1,
            min_lfc = 0.5, max_lfc = 100
        )

        markers = df1['gene'].tolist() + df2['gene'].tolist()
        show_text = False
    
    ann = ['annot' if x in markers else 'bg' for x in varn]

    if ax is None: fig, axes = plt.subplots(1, 1, figsize = figsize, dpi = dpi)
    else: axes = ax

    sns.scatterplot(
        x = mean_x, y = mean_y, ax = ax, hue = ann,
        hue_order = ['bg', 'annot'], palette = ['gray', 'red'],
        s = 4, edgecolor = None, legend = False,
        rasterized = True
    )

    plt.xlabel(f'Average expression in {group_x}')
    plt.ylabel(f'Average expression in {group_y}')
    plt.plot([0, mean_x.max()], [0, mean_x.max()], linewidth = 1, linestyle = '--', color = 'red')

    for x, y, name in zip(mean_x, mean_y, varn):
        if name in markers:
            if show_text: plt.text(x = x, y = y, s = name, fontsize = 9, color = 'black')

    if ax is None: return fig
    else: return axes.figure


def matrix(
    adata, layer = 'X', obs_names = None, var_names = None, 
    figsize = (3, 3), ax = None, **kwargs
):
    mat = choose_layer(adata, layer = layer)
    
    if ax is None: fig, ax = plt.subplots(figsize = figsize)
    else: fig = ax.figure

    ax.imshow(mat, **kwargs)

    obs = adata.obs_names.tolist() if obs_names is None else adata.obs[obs_names].tolist()
    var = adata.var_names.tolist() if var_names is None else adata.obs[var_names].tolist()
    ax.set_xticks(range(len(var)), labels = var, rotation = 90, ha = "right", va = 'center', rotation_mode = "anchor")
    ax.set_yticks(range(len(obs)), labels = obs)

    return fig


def volcano(
    adata, de_slot = 'deg', label = [],
    show_all = False, min_pct = 0, max_pct_reference = 1, 
    min_lfc = -25, max_lfc = 25, remove_zero_pval = False,
    highlight_min_logp = 5, highlight_min_lfc = 1.5,
    xlim = 5, ylim = 100,
    figsize = (3, 3), dpi = 100
):

    import numpy as np
    import matplotlib.pyplot as plt
    from adjustText import adjust_text
    import exprmat.reader.static as st

    pvals = []
    fc = []
    names = []

    if isinstance(de_slot, str):
        plots = st.rna_get_markers(
            adata, None, de_slot = de_slot,
            min_pct = min_pct, max_pct_reference = max_pct_reference, 
            min_lfc = min_lfc, max_lfc = max_lfc, 
            remove_zero_pval = remove_zero_pval
        )
        
    else: plots = de_slot
    
    pvals = plots['log10.q'].tolist()
    fc = plots['lfc'].tolist()
    names = plots['gene'].tolist()

    fig, axes = plt.subplots(1, 1, figsize = figsize, dpi = dpi)
    axes.scatter(fc, pvals, c = 'k', s = 4)

    sig_pvals = []
    sig_fc = []
    sig_names = []

    for p, f, nm in zip(pvals, fc, names):
        if nm in label:
            sig_pvals += [p]
            sig_fc += [f]
            sig_names += [nm]

        if (p > highlight_min_logp and abs(f) >= highlight_min_lfc) and show_all:
            sig_pvals += [p]
            sig_fc += [f]
            sig_names += [nm]

    texts = []
    for p, f, nm in zip(sig_pvals, sig_fc, sig_names):
        texts += [axes.text(f, p, nm, va = 'top', ha = 'center')]

    # adjust_text(texts)
    axes.scatter(sig_fc, sig_pvals, c = 'r', s = 10)
    axes.grid(False)

    xlim = min(np.abs(np.array(fc)).max(), xlim)
    ylim = min(ylim, np.max(np.array(pvals)))
    axes.set_xlim([-xlim, xlim])
    axes.set_ylim([-ylim / 20, ylim])

    axes.vlines(x = [0], ymin = [0], ymax = [ylim], linestyles = 'dashed', color = 'gray', linewidth = 0.6)
    axes.set_yticks([])
    axes.set_xlabel('Log-2 fold changes')
    for pos in ['right', 'top', 'left']:
        axes.spines[pos].set_visible(False)
        
    return fig


def validate_inputs(adata, group_key, cell_type_key, pseudobulk, sample_key, pseudobulk_layer):
    if group_key not in adata.obs.columns:
        raise KeyError(f"{group_key} not in adata.obs")
    if cell_type_key not in adata.obs.columns:
        raise KeyError(f"{cell_type_key} not in adata.obs")
    if pseudobulk:
        if sample_key not in adata.obs.columns:
            raise KeyError(f"{sample_key} not in adata.obs")
        if pseudobulk_layer not in adata.layers:
            raise KeyError(f"{pseudobulk_layer} not in adata.layers")


def get_gene_labels(adata, gene_key):
    if gene_key in adata.var.columns:
        return adata.var[gene_key].astype(str).to_numpy()
    return adata.var_names.astype(str).to_numpy()


def make_gene_to_idx(gene_labels):
    gene_to_idx = {}
    for i, g in enumerate(gene_labels):
        if g not in gene_to_idx:
            gene_to_idx[g] = i
    return gene_to_idx


def prepare_display_rows(genes, gene_to_idx):
    display_rows = []
    requested_genes = []

    if isinstance(genes, dict):
        for receptor, ligs in genes.items():
            receptor = str(receptor)
            for lig in ligs:
                lig = str(lig)
                requested_genes.append(lig)
                display_rows.append({'gene': lig, 'receptor': receptor})
    else:
        for g in genes:
            g = str(g)
            requested_genes.append(g)
            display_rows.append({'gene': g, 'receptor': ''})

    missing_genes = [g for g in requested_genes if g not in gene_to_idx]
    display_rows = [row for row in display_rows if row['gene'] in gene_to_idx]

    if len(display_rows) == 0:
        raise ValueError('None of the requested genes were found in adata.var')

    present_genes = []
    for row in display_rows:
        g = row['gene']
        if g not in present_genes:
            present_genes.append(g)

    return display_rows, present_genes, missing_genes


def prepare_obs(
    adata,
    group_key,
    cell_type_key,
    control_group,
    experiment_group,
    cell_type_order,
    pseudobulk,
    sample_key,
):
    obs_cols = [group_key, cell_type_key]
    if pseudobulk:
        obs_cols.append(sample_key)

    obs = adata.obs[obs_cols].copy()
    obs[group_key] = obs[group_key].astype(str)
    obs[cell_type_key] = obs[cell_type_key].astype(str)
    if pseudobulk:
        obs[sample_key] = obs[sample_key].astype(str)

    g1 = str(control_group)
    g2 = str(experiment_group)
    keep = obs[group_key].isin([g1, g2])

    all_cell_types = sorted(obs[cell_type_key].unique().tolist())
    if cell_type_order is None:
        cell_types = sorted(obs.loc[keep, cell_type_key].unique().tolist())
    else:
        cell_types = [str(ct) for ct in cell_type_order]
        unknown_cell_types = [ct for ct in cell_types if ct not in all_cell_types]
        if len(unknown_cell_types) > 0:
            error('unknown cell types in cell_type_order: ' + ', '.join(unknown_cell_types))
        keep = keep & obs[cell_type_key].isin(cell_types)

    obs = obs.loc[keep]
    if obs.shape[0] == 0:
        error('no cells found for the selected control/experiment groups and cell types')

    return obs, g1, g2, cell_types


def init_stat_frames(present_genes, cell_types):
    ctrl_mean = pd.DataFrame(index = present_genes, columns = cell_types, dtype = float)
    exp_mean = pd.DataFrame(index = present_genes, columns = cell_types, dtype = float)
    ctrl_pct = pd.DataFrame(index = present_genes, columns = cell_types, dtype = float)
    exp_pct = pd.DataFrame(index = present_genes, columns = cell_types, dtype = float)
    pval = pd.DataFrame(index = present_genes, columns = cell_types, dtype = float)
    n_ctrl = pd.Series(index = cell_types, dtype = int)
    n_exp = pd.Series(index = cell_types, dtype = int)
    return ctrl_mean, exp_mean, ctrl_pct, exp_pct, pval, n_ctrl, n_exp


def aggregate_log_expr(X_pb, gene_idx, sample_index, sample_cell_ids, target_sum):
    sample_expr = []
    for cell_ids in sample_cell_ids:
        idx = sample_index.get_indexer(cell_ids)
        Xi = X_pb[idx, :][:, gene_idx]
        counts = np.asarray(Xi.sum(axis = 0)).ravel()
        libsize = float(np.sum(counts))
        if libsize <= 0:
            sample_expr.append(np.zeros(len(gene_idx), dtype = float))
        else:
            norm = counts / libsize * float(target_sum)
            sample_expr.append(np.log1p(norm))

    if len(sample_expr) == 0:
        return np.empty((0, len(gene_idx)), dtype = float)
    return np.vstack(sample_expr)


def pval_from_arrays(pval_df, present_genes, ct, ctrl_vals_by_gene, exp_vals_by_gene):
    for j, g in enumerate(present_genes):
        ctrl_vals = ctrl_vals_by_gene[:, j]
        exp_vals = exp_vals_by_gene[:, j]

        if ctrl_vals.size == 0 or exp_vals.size == 0:
            pval_df.loc[g, ct] = np.nan
            continue

        if np.all(ctrl_vals == ctrl_vals[0]) \
            and np.all(exp_vals == exp_vals[0]) \
            and ctrl_vals[0] == exp_vals[0]:
            pval_df.loc[g, ct] = 1.0
        
        else:
            pval_df.loc[g, ct] = stats.mannwhitneyu(
                ctrl_vals, exp_vals, alternative = 'two-sided'
            ).pvalue


def single_cell_stats(
    adata, log_scale,
    gene_idx, present_genes,
    obs, group_key, cell_type_key,
    g1, g2, cell_types, min_cells,
    ctrl_mean, exp_mean, ctrl_pct, exp_pct,
    pval, n_ctrl, n_exp,
):
    sample_index = adata.obs_names

    for ct in cell_types:
        ct_mask = obs[cell_type_key].to_numpy() == ct
        group_vals = obs[group_key].to_numpy()

        idx_ctrl = obs.index[ct_mask & (group_vals == g1)]
        idx_exp = obs.index[ct_mask & (group_vals == g2)]

        n_ctrl[ct] = len(idx_ctrl)
        n_exp[ct] = len(idx_exp)

        X_ctrl = None
        X_exp = None

        if len(idx_ctrl) > 0:
            X_ctrl = log_scale[sample_index.get_indexer(idx_ctrl), :][:, gene_idx]
            ctrl_mean.loc[present_genes, ct] = np.asarray(X_ctrl.mean(axis = 0)).ravel()
            ctrl_pct.loc[present_genes, ct] = np.asarray((X_ctrl > 0).mean(axis = 0)).ravel()

        if len(idx_exp) > 0:
            X_exp = log_scale[sample_index.get_indexer(idx_exp), :][:, gene_idx]
            exp_mean.loc[present_genes, ct] = np.asarray(X_exp.mean(axis = 0)).ravel()
            exp_pct.loc[present_genes, ct] = np.asarray((X_exp > 0).mean(axis = 0)).ravel()

        if len(idx_ctrl) > 0 and len(idx_exp) > 0:
            ctrl_arr = X_ctrl.toarray() if sparse.issparse(X_ctrl) else np.asarray(X_ctrl)
            exp_arr = X_exp.toarray() if sparse.issparse(X_exp) else np.asarray(X_exp)
            pval_from_arrays(pval, present_genes, ct, ctrl_arr, exp_arr)

        if n_ctrl[ct] < min_cells:
            ctrl_mean.loc[:, ct] = np.nan
            ctrl_pct.loc[:, ct] = np.nan
            pval.loc[:, ct] = np.nan

        if n_exp[ct] < min_cells:
            exp_mean.loc[:, ct] = np.nan
            exp_pct.loc[:, ct] = np.nan
            pval.loc[:, ct] = np.nan


def pseudobulk_stats(
    adata, pseudobulk,
    gene_idx, present_genes,
    obs, group_key, cell_type_key,
    sample_key, g1, g2,
    cell_types, pseudobulk_target_sum,
    ctrl_mean, exp_mean, ctrl_pct, exp_pct,
    pval, n_ctrl, n_exp,
):
    sample_index = adata.obs_names

    for ct in cell_types:
        ct_mask = obs[cell_type_key].to_numpy() == ct
        group_vals = obs[group_key].to_numpy()

        idx_ctrl = obs.index[ct_mask & (group_vals == g1)]
        idx_exp = obs.index[ct_mask & (group_vals == g2)]

        ctrl_df = obs.loc[idx_ctrl, [sample_key]]
        exp_df = obs.loc[idx_exp, [sample_key]]

        ctrl_sample_ids = ctrl_df[sample_key].drop_duplicates().tolist()
        exp_sample_ids = exp_df[sample_key].drop_duplicates().tolist()

        n_ctrl[ct] = len(ctrl_sample_ids)
        n_exp[ct] = len(exp_sample_ids)

        ctrl_sample_cells = [ctrl_df.index[ctrl_df[sample_key] == sid] for sid in ctrl_sample_ids]
        exp_sample_cells = [exp_df.index[exp_df[sample_key] == sid] for sid in exp_sample_ids]

        ctrl_arr = aggregate_log_expr(pseudobulk, gene_idx, sample_index, ctrl_sample_cells, pseudobulk_target_sum)
        exp_arr = aggregate_log_expr(pseudobulk, gene_idx, sample_index, exp_sample_cells, pseudobulk_target_sum)

        if ctrl_arr.shape[0] > 0:
            ctrl_mean.loc[present_genes, ct] = np.asarray(ctrl_arr.mean(axis = 0)).ravel()
            ctrl_pct.loc[present_genes, ct] = np.asarray((ctrl_arr > 0).mean(axis = 0)).ravel()

        if exp_arr.shape[0] > 0:
            exp_mean.loc[present_genes, ct] = np.asarray(exp_arr.mean(axis = 0)).ravel()
            exp_pct.loc[present_genes, ct] = np.asarray((exp_arr > 0).mean(axis = 0)).ravel()

        if ctrl_arr.shape[0] > 1 and exp_arr.shape[0] > 1:
            pval_from_arrays(pval, present_genes, ct, ctrl_arr, exp_arr)


def prepare_display_matrices(display_rows, ctrl_mean, exp_mean, ctrl_pct, exp_pct, pval, genes):
    display_genes = [row['gene'] for row in display_rows]
    display_receptors = [row['receptor'] for row in display_rows]

    display_ctrl_mean = ctrl_mean.loc[display_genes].copy()
    display_exp_mean = exp_mean.loc[display_genes].copy()
    display_ctrl_pct = ctrl_pct.loc[display_genes].copy()
    display_exp_pct = exp_pct.loc[display_genes].copy()
    display_pval = pval.loc[display_genes].copy()
    display_logfc = (display_exp_mean - display_ctrl_mean).copy()

    group_specs = []
    if isinstance(genes, dict):
        start = 0
        for i in range(1, len(display_receptors) + 1):
            if i == len(display_receptors) or display_receptors[i] != display_receptors[start]:
                group_specs.append((display_receptors[start], start, i))
                start = i

    return (
        display_genes,
        display_receptors,
        display_ctrl_mean,
        display_exp_mean,
        display_ctrl_pct,
        display_exp_pct,
        display_pval,
        display_logfc,
        group_specs,
    )


def make_result_df(
    display_genes, display_receptors, display_ctrl_mean,
    display_exp_mean, display_logfc, display_pval,
    display_ctrl_pct, display_exp_pct,
    cell_types, g1, g2, n_ctrl, n_exp, pseudobulk,
):
    rows = []
    for row_idx, (g, receptor) in enumerate(zip(display_genes, display_receptors)):
        for ct_idx, ct in enumerate(cell_types):
            rows.append({
                'gene': g,
                'summary.label': g,
                'receptor': receptor,
                'row': row_idx,
                'ctype': ct,
                'ctrl': g1,
                'expm': g2,
                'ctrl.expr': display_ctrl_mean.iat[row_idx, ct_idx],
                'expm.expr': display_exp_mean.iat[row_idx, ct_idx],
                'logfc': display_logfc.iat[row_idx, ct_idx],
                'pval': display_pval.iat[row_idx, ct_idx],
                'ctrl.pct': display_ctrl_pct.iat[row_idx, ct_idx],
                'expm.pct': display_exp_pct.iat[row_idx, ct_idx],
                'ctrl.n': n_ctrl[ct],
                'expm.n': n_exp[ct],
                'mode': 'pseudobulk' if pseudobulk else 'single-cell',
            })
    return pd.DataFrame(rows)


def p_to_stars(p, alpha):
    if pd.isna(p) or p > alpha: return ''
    if p < 0.001: return '***'
    if p < 0.01: return '**'
    return '*'


def pval_annotate(display_pval, cell_types, n_ctrl, n_exp, pseudobulk, alpha):
    pval_annot = display_pval.copy().astype(object)
    for col_idx, ct in enumerate(cell_types):
        one_sample_group = pseudobulk and (n_ctrl[ct] <= 1 or n_exp[ct] <= 1)
        for row_idx in range(pval_annot.shape[0]):
            if one_sample_group:
                pval_annot.iat[row_idx, col_idx] = '?'
            else:
                p = display_pval.iat[row_idx, col_idx]
                pval_annot.iat[row_idx, col_idx] = p_to_stars(p, alpha)
    return pval_annot


def draw_receptor_brackets(ax, group_specs, n_cols, font_size):
    if len(group_specs) == 0: return
    bracket_x = n_cols + 0.3
    tick_x = n_cols + 0.1
    text_x = n_cols + 0.6
    for receptor, start, end in group_specs:
        y0 = start + 0.25
        y1 = end - 0.25
        ax.plot([bracket_x, bracket_x], [y0, y1], color = 'black', lw = 1, clip_on = False)
        ax.plot([tick_x, bracket_x], [y0, y0], color = 'black', lw = 1, clip_on = False)
        ax.plot([tick_x, bracket_x], [y1, y1], color = 'black', lw = 1, clip_on = False)
        ax.text(text_x, (y0 + y1) / 2, receptor, ha = 'left', va = 'center', fontsize = font_size)


def group_comparison(
    adata,
    genes,
    group_key,
    control_group,
    experiment_group,
    cell_type_key = 'cell.type',
    gene_key = 'gene',
    layer = None,
    min_cells = 10,
    cell_type_order = None,
    alpha = 0.05,
    figsize = (8, 3),
    cmap_expr = 'ylorrd/r',
    cmap_lfc = 'seismic',
    pseudobulk = False,
    pseudobulk_layer = 'counts',
    sample_key = 'sample',
    pseudobulk_target_sum = 1e6,
    dpi = 100,
):
    """
    Compare a gene list between two groups across cell types.
    """
    validate_inputs(adata, group_key, cell_type_key, pseudobulk, sample_key, pseudobulk_layer)

    X_sc = None if pseudobulk else (adata.layers[layer] if layer is not None else adata.X)
    X_pb = adata.layers[pseudobulk_layer] if pseudobulk else None

    gene_labels = get_gene_labels(adata, gene_key)
    gene_to_idx = make_gene_to_idx(gene_labels)
    display_rows, present_genes, missing_genes = prepare_display_rows(genes, gene_to_idx)
    gene_idx = np.array([gene_to_idx[g] for g in present_genes], dtype = int)

    obs, g1, g2, cell_types = prepare_obs(
        adata,
        group_key,
        cell_type_key,
        control_group,
        experiment_group,
        cell_type_order,
        pseudobulk,
        sample_key,
    )

    ctrl_mean, exp_mean, ctrl_pct, exp_pct, pval, n_ctrl, n_exp = init_stat_frames(
        present_genes, cell_types)

    if pseudobulk:
        pseudobulk_stats(
            adata, X_pb, gene_idx, present_genes,
            obs, group_key, cell_type_key, sample_key,
            g1, g2, cell_types,
            pseudobulk_target_sum,
            ctrl_mean, exp_mean, ctrl_pct, exp_pct,
            pval, n_ctrl, n_exp,
        )

    else:
        single_cell_stats(
            adata, X_sc, gene_idx, present_genes,
            obs, group_key, cell_type_key,
            g1, g2, cell_types, min_cells,
            ctrl_mean, exp_mean, ctrl_pct, exp_pct,
            pval, n_ctrl, n_exp,
        )

    (
        display_genes,
        display_receptors,
        display_ctrl_mean,
        display_exp_mean,
        display_ctrl_pct,
        display_exp_pct,
        display_pval,
        display_logfc,
        group_specs,
    ) = prepare_display_matrices(
        display_rows, ctrl_mean, exp_mean, ctrl_pct, exp_pct, pval, genes)

    # Keep logFC masking semantics identical to previous version.
    display_logfc = display_logfc.mask(display_pval > alpha)

    result_df = make_result_df(
        display_genes,
        display_receptors,
        display_ctrl_mean,
        display_exp_mean,
        display_logfc,
        display_pval,
        display_ctrl_pct,
        display_exp_pct,
        cell_types,
        g1, g2,
        n_ctrl, n_exp,
        pseudobulk,
    )

    font_size = 9
    with plt.rc_context({
        'font.size': font_size,
        'axes.titlesize': font_size,
        'axes.labelsize': font_size,
        'xtick.labelsize': font_size,
        'ytick.labelsize': font_size,
    }):
        fig = plt.figure(figsize = figsize, dpi = dpi)
        gs = fig.add_gridspec(2, 2, width_ratios = [1.0, 0.05], hspace = 0.12, wspace = 0.5)
        ax_expr = fig.add_subplot(gs[0, 0])
        cax_expr_holder = fig.add_subplot(gs[0, 1])
        ax_lfc = fig.add_subplot(gs[1, 0], sharex = ax_expr)
        cax_lfc_holder = fig.add_subplot(gs[1, 1])

        if len(group_specs) > 0:
            fig.subplots_adjust(left = 0.20, right = 0.95)

        max_cbar_h = 1.5 / fig.get_figheight()

        def make_bottom_aligned_cbar_ax(holder_ax):
            box = holder_ax.get_position()
            cbar_h = min(box.height, max_cbar_h)
            cax = fig.add_axes([box.x0, box.y0, box.width, cbar_h])
            holder_ax.set_visible(False)
            return cax

        cax_expr = make_bottom_aligned_cbar_ax(cax_expr_holder)
        cax_lfc = make_bottom_aligned_cbar_ax(cax_lfc_holder)

        expr_vals = np.r_[display_ctrl_mean.to_numpy().ravel(), display_exp_mean.to_numpy().ravel()]
        expr_vals = expr_vals[np.isfinite(expr_vals)]
        if expr_vals.size == 0:
            vmin_expr, vmax_expr = 0.0, 1.0
        else:
            vmin_expr = float(np.min(expr_vals))
            vmax_expr = float(np.max(expr_vals))

        lfc_vals = display_logfc.to_numpy().ravel()
        lfc_vals = lfc_vals[np.isfinite(lfc_vals)]
        if lfc_vals.size == 0:
            vmax_lfc = 1.0
        else:
            vmax_lfc = float(np.max(np.abs(lfc_vals)))
            if vmax_lfc == 0:
                vmax_lfc = 1.0

        cmap_expr_obj = to_matplotlib(cmap_expr)
        expr_norm = mcolors.Normalize(vmin = vmin_expr, vmax = vmax_expr)

        polys = []
        facecolors = []
        n_rows = len(display_genes)
        n_cols = len(cell_types)
        for i in range(n_rows):
            for j in range(n_cols):
                v_ctrl = display_ctrl_mean.iat[i, j]
                v_exp = display_exp_mean.iat[i, j]
                tri_top_left = [(j, i), (j + 1, i), (j, i + 1)]
                tri_bottom_right = [(j + 1, i), (j + 1, i + 1), (j, i + 1)]

                polys.append(tri_top_left)
                facecolors.append(cmap_expr_obj(expr_norm(v_ctrl)) if np.isfinite(v_ctrl) else (1, 1, 1, 0))

                polys.append(tri_bottom_right)
                facecolors.append(cmap_expr_obj(expr_norm(v_exp)) if np.isfinite(v_exp) else (1, 1, 1, 0))

        tri_collection = PolyCollection(
            polys,
            facecolors = facecolors,
            edgecolors = 'white',
            linewidths = 0.5,
        )
        ax_expr.add_collection(tri_collection)

        ax_expr.set_xlim(0, n_cols)
        ax_expr.set_ylim(n_rows, 0)
        ax_expr.set_aspect('auto')
        ax_expr.set_title(f'{g1} / {g2}', fontsize = font_size)
        ax_expr.set_xlabel('Cell Annotation', fontsize = font_size)
        ax_expr.set_ylabel('Ligand', fontsize = font_size)
        ax_expr.spines['bottom'].set_visible(True)
        ax_expr.spines['left'].set_visible(True)
        ax_expr.spines['top'].set_visible(False)
        ax_expr.spines['right'].set_visible(False)

        expr_sm = plt.cm.ScalarMappable(norm = expr_norm, cmap = cmap_expr_obj)
        expr_sm.set_array([])
        fig.colorbar(expr_sm, cax = cax_expr, label = 'Mean Log Expression')

        pval_annot = pval_annotate(display_pval, cell_types, n_ctrl, n_exp, pseudobulk, alpha)

        sns.heatmap(
            display_logfc,
            cmap = to_matplotlib(cmap_lfc),
            vmin = -vmax_lfc,
            vmax = vmax_lfc,
            center = 0,
            ax = ax_lfc,
            cbar_ax = cax_lfc,
            linewidths = 0.5,
            linecolor = 'white',
            annot = pval_annot,
            fmt = '',
            annot_kws = {'fontsize': font_size},
            cbar_kws = {'label': 'Log fold change'},
        )

        ax_lfc.set_title('Log FC by Cell Type', fontsize = font_size)
        ax_lfc.set_xlabel('Cell Annotation', fontsize = font_size)
        ax_lfc.set_ylabel('', fontsize = font_size)
        ax_lfc.spines['bottom'].set_visible(True)
        ax_lfc.spines['left'].set_visible(True)
        ax_lfc.set_xlim(0, n_cols)

        x_pos = np.arange(len(cell_types)) + 0.5
        y_pos = np.arange(len(display_genes)) + 0.5
        for ax in [ax_expr, ax_lfc]:
            ax.set_xticks(x_pos)
            ax.set_xticklabels(cell_types, rotation = 90, fontsize = font_size)
            ax.set_yticks(y_pos)
            ax.set_yticklabels(display_genes, rotation = 0, fontsize = font_size)
            ax.tick_params(axis = 'both', labelsize = font_size)

        draw_receptor_brackets(ax_expr, group_specs, n_cols, font_size)
        draw_receptor_brackets(ax_lfc, group_specs, n_cols, font_size)

        for cax in [cax_expr, cax_lfc]:
            cax.tick_params(labelsize = font_size)
            cax.yaxis.label.set_size(font_size)

        if len(missing_genes) > 0:
            fig.suptitle(
                'Missing genes dropped: ' + ', '.join(sorted(set(missing_genes))), 
                fontsize = font_size, y = 1.02
            )

    return fig