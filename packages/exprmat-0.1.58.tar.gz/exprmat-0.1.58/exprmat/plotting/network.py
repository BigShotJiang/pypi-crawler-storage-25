
def network_global_to_nx(network):
    import networkx as nx
    g = nx.Graph()

    for i, node in network['global']['node'].iterrows():
        g.add_node(node['fine'], weight = node['weight'])
    
    for i, conn in network['global']['edge'].iterrows():
        g.add_edge(conn['fine1'], conn['fine2'], weight = conn['correlation'])

    return g


def draw_covarnet(
    adata, key = 'covarnet', 
    node_size = 500, cmap = 'category20b', cmap_edge = 'reds/r',
    figsize = (3, 3), dpi = 100
):
    import networkx as nx
    import matplotlib.pyplot as plt 
    from exprmat.plotting.palettes import mpl

    network = adata.uns[key]
    G = network_global_to_nx(network)
    pos = nx.kamada_kawai_layout(G)
    edges, weights = zip(*nx.get_edge_attributes(G, 'weight').items())

    fig, ax = plt.subplots(1, 1, figsize = figsize, dpi = dpi)

    nx.draw(
        G, pos, with_labels = True, node_size = node_size,
        node_color = network['global']['node']['weight'].tolist(), cmap = mpl(cmap),
        edge_color = weights, edge_cmap = mpl(cmap_edge), ax = ax
    )

    return fig