
import numpy as np
import matplotlib.pyplot as plt


def plot_raw_selection(raw, selection, sample_name = None, figsize = (3, 3), dpi = 100):
    
    ranks = np.array(raw.X.sum(1).T)[0]
    idx = np.argsort(ranks)[::-1]

    autoaccept = selection['autoaccept']
    candidates = selection['candidates']
    mask_a = np.zeros(shape = len(ranks))
    mask_c = np.zeros(shape = len(ranks))
    mask_a[autoaccept] = 1
    mask_c[candidates] = 1

    ranks = ranks[idx]
    mask_a = mask_a[idx] > 0.5
    mask_c = mask_c[idx] > 0.5

    nonzero = ranks > 0
    idx = idx[nonzero]
    ranks = ranks[nonzero]
    mask_a = mask_a[nonzero]
    mask_c = mask_c[nonzero]
    
    ys = np.log10(ranks)
    xs = np.log10(np.arange(len(ranks)) + 1)

    fig, ax = plt.subplots(1, 1, figsize = figsize, dpi = dpi)
    ax.plot(
        xs, ys, c = '#a0a0a010', 
        markersize = 2, linestyle = 'None', marker = 'o')

    # plot groundtruth
    ax.plot(
        xs[mask_a], ys[mask_a], c = '#00000030', 
        markersize = 3, linestyle = 'None', marker = 'o')

    ax.plot(
        xs[mask_c], ys[mask_c], c = '#ff000030', 
        markersize = 3, linestyle = 'None', marker = 'o')

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.set_xlabel('Log 10 droplets')
    ax.set_ylabel((f'({sample_name}) ' if sample_name else '') + 'Log 10 UMI reads')

    return fig