import numpy as np
import pytest

from x4d_devkit.eval.metrics import (
    center_distance,
    scale_iou,
    quaternion_yaw,
    yaw_diff,
    attr_acc,
    cummean,
)


class TestCenterDistance:
    def test_same_point(self):
        assert center_distance([0, 0, 0], [0, 0, 0]) == 0.0

    def test_xy_only(self):
        assert center_distance([3, 0, 0], [0, 4, 100]) == pytest.approx(5.0)

    def test_known_distance(self):
        assert center_distance([1, 1, 0], [4, 5, 0]) == pytest.approx(5.0)


class TestScaleIou:
    def test_identical_boxes(self):
        assert scale_iou([4, 2, 1.5], [4, 2, 1.5]) == pytest.approx(1.0)

    def test_no_overlap(self):
        assert scale_iou([4, 2, 1.5], [0, 2, 1.5]) == pytest.approx(0.0)

    def test_half_size(self):
        iou = scale_iou([4, 2, 2], [2, 1, 1])
        assert iou == pytest.approx(2 / 16)

    def test_double_one_dim(self):
        iou = scale_iou([4, 2, 2], [4, 2, 4])
        assert iou == pytest.approx(16 / 32)


class TestQuaternionYaw:
    def test_identity(self):
        assert quaternion_yaw([0, 0, 0, 1]) == pytest.approx(0.0, abs=1e-10)

    def test_90_deg_z(self):
        s = np.sin(np.pi / 4)
        c = np.cos(np.pi / 4)
        assert quaternion_yaw([0, 0, s, c]) == pytest.approx(np.pi / 2, abs=1e-10)

    def test_180_deg_z(self):
        yaw = quaternion_yaw([0, 0, 1, 0])
        assert abs(abs(yaw) - np.pi) < 1e-10


class TestYawDiff:
    def test_same_yaw(self):
        q = [0, 0, 0, 1]
        assert yaw_diff(q, q) == pytest.approx(0.0, abs=1e-10)

    def test_90_deg(self):
        q1 = [0, 0, 0, 1]
        s = np.sin(np.pi / 4)
        c = np.cos(np.pi / 4)
        q2 = [0, 0, s, c]
        assert yaw_diff(q1, q2) == pytest.approx(np.pi / 2, abs=1e-10)

    def test_wrapping_2pi(self):
        yaw1_rad = np.deg2rad(-10)
        yaw2_rad = np.deg2rad(10)
        s1, c1 = np.sin(yaw1_rad / 2), np.cos(yaw1_rad / 2)
        s2, c2 = np.sin(yaw2_rad / 2), np.cos(yaw2_rad / 2)
        q1 = [0, 0, s1, c1]
        q2 = [0, 0, s2, c2]
        assert yaw_diff(q1, q2) == pytest.approx(np.deg2rad(20), abs=1e-6)

    def test_barrier_period_pi(self):
        q1 = [0, 0, 0, 1]
        q2 = [0, 0, 1.0, 0.0]
        assert yaw_diff(q1, q2, period=np.pi) == pytest.approx(0.0, abs=1e-10)


class TestAttrAcc:
    def test_match(self):
        assert attr_acc(["vehicle.moving"], ["vehicle.moving"]) == 1.0

    def test_mismatch(self):
        assert attr_acc(["vehicle.moving"], ["vehicle.parked"]) == 0.0

    def test_empty_gt(self):
        assert np.isnan(attr_acc([], ["vehicle.moving"]))

    def test_empty_pred(self):
        assert np.isnan(attr_acc(["vehicle.moving"], []))

    def test_both_empty(self):
        assert np.isnan(attr_acc([], []))


class TestCummean:
    def test_basic(self):
        arr = np.array([2.0, 4.0, 6.0])
        result = cummean(arr)
        np.testing.assert_allclose(result, [2.0, 3.0, 4.0])

    def test_with_nan(self):
        arr = np.array([2.0, np.nan, 6.0])
        result = cummean(arr)
        assert result[0] == pytest.approx(2.0)
        assert result[2] == pytest.approx(4.0)

    def test_all_nan(self):
        arr = np.array([np.nan, np.nan, np.nan])
        result = cummean(arr)
        np.testing.assert_allclose(result, [1.0, 1.0, 1.0])
