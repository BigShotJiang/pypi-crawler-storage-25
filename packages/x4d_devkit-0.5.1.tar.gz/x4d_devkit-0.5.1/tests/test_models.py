import numpy as np
import pytest

from x4d_devkit.core.models import (
    ClipMeta,
    CalibratedSensor,
    EgoPose,
    Sample,
    SampleData,
    Annotation,
    Instance,
)


class TestClipMeta:
    def test_construction(self):
        meta = ClipMeta(
            clip_id="20180724_n015_scene-0061_000",
            schema_version="0.1",
            session_id="n015-2018-07-24-11-22-45+0800",
            vehicle_id="n015",
            capture_time_utc="2018-07-24T00:00:00Z",
            duration_s=19.5,
            num_keyframes=39,
            num_sweeps=305,
            sensors={"CAM_FRONT": {"modality": "camera", "resolution": [1600, 900]}},
        )
        assert meta.clip_id == "20180724_n015_scene-0061_000"
        assert meta.num_keyframes == 39

    def test_frozen(self):
        meta = ClipMeta(
            clip_id="test", schema_version="0.1", session_id="s",
            vehicle_id="v", capture_time_utc="t", duration_s=1.0,
            num_keyframes=1, num_sweeps=0, sensors={},
        )
        with pytest.raises(AttributeError):
            meta.clip_id = "new"


class TestEgoPose:
    def test_construction_and_numpy(self):
        ep = EgoPose(
            token="abc123",
            timestamp_us=1532402928669023,
            translation=np.array([1.0, 2.0, 3.0]),
            rotation=np.array([0.0, 0.0, 0.0, 1.0]),
        )
        assert ep.token == "abc123"
        assert ep.translation.dtype == np.float64
        assert ep.rotation.shape == (4,)

    def test_accepts_list_input(self):
        ep = EgoPose(
            token="abc", timestamp_us=0,
            translation=[1, 2, 3], rotation=[0, 0, 0, 1],
        )
        assert isinstance(ep.translation, np.ndarray)
        assert isinstance(ep.rotation, np.ndarray)


class TestSample:
    def test_construction(self):
        s = Sample(token="t1", timestamp_us=100, is_keyframe=True, prev="", next="t2")
        assert s.token == "t1"
        assert s.prev == ""
        assert s.next == "t2"


class TestSampleData:
    def test_construction(self):
        sd = SampleData(
            token="sd1", sample_token="s1", channel="CAM_FRONT",
            timestamp_us=100, file_path="samples/CAM_FRONT/100.jpg",
            ego_pose_token="ep1", calibrated_sensor_token="cs1",
            is_keyframe=True, width=1600, height=900, prev="", next="sd2",
        )
        assert sd.channel == "CAM_FRONT"
        assert sd.width == 1600


class TestCalibratedSensor:
    def test_construction(self):
        cs = CalibratedSensor(
            token="cs1", channel="cam_front", modality="camera",
            translation=np.zeros(3), rotation=np.array([0, 0, 0, 1.0]),
            intrinsics={"camera_model": "pinhole",
                        "fx": 1266.4, "fy": 1266.4, "cx": 816.3, "cy": 491.5,
                        "image_width": 1600, "image_height": 900},
            distortion={"model": "plumb_bob",
                        "k1": 0.0, "k2": 0.0, "k3": 0.0, "p1": 0.0, "p2": 0.0},
        )
        assert cs.modality == "camera"
        assert cs.intrinsics["fx"] == 1266.4
        assert cs.distortion["model"] == "plumb_bob"


class TestAnnotation:
    def test_construction(self):
        ann = Annotation(
            token="a1", sample_token="s1", instance_token="i1",
            category="vehicle.car",
            translation=np.array([10.0, 20.0, 1.0]),
            size=np.array([4.5, 1.8, 1.5]),
            rotation=np.array([0, 0, 0, 1.0]),
            num_lidar_pts=42, visibility="4",
            velocity=np.array([1.0, 0.5, 0.0]),
            attributes=["vehicle.moving"],
            prev="", next="a2",
        )
        assert ann.category == "vehicle.car"
        assert ann.size.shape == (3,)

    def test_velocity_none(self):
        ann = Annotation(
            token="a1", sample_token="s1", instance_token="i1",
            category="vehicle.car",
            translation=[0, 0, 0], size=[1, 1, 1], rotation=[0, 0, 0, 1],
            num_lidar_pts=0, visibility="1",
            velocity=None, attributes=[], prev="", next="",
        )
        assert ann.velocity is None


class TestAnnotationScore:
    def test_score_none_for_gt(self):
        ann = Annotation(
            token="a1", sample_token="s1", instance_token="i1",
            category="vehicle.car",
            translation=[0, 0, 0], size=[1, 1, 1], rotation=[0, 0, 0, 1],
            num_lidar_pts=10, visibility="4",
            velocity=None, attributes=[], prev="", next="",
            score=None,
        )
        assert ann.score is None

    def test_score_float_for_pred(self):
        ann = Annotation(
            token="a1", sample_token="s1", instance_token="i1",
            category="vehicle.car",
            translation=[0, 0, 0], size=[1, 1, 1], rotation=[0, 0, 0, 1],
            num_lidar_pts=0, visibility="",
            velocity=None, attributes=[], prev="", next="",
            score=0.85,
        )
        assert ann.score == 0.85


class TestInstance:
    def test_construction(self):
        inst = Instance(
            token="i1", category="vehicle.car", num_annotations=5,
            first_annotation_token="a1", last_annotation_token="a5",
        )
        assert inst.num_annotations == 5
