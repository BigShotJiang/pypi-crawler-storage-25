import json

import numpy as np
import pytest

from x4d_devkit.converters.nuscenes import (
    quat_wxyz_to_named,
    translation_to_named,
    invert_se3,
    apply_se3,
    compose_se3,
    quat_to_rotation_matrix,
    rotation_matrix_to_quat,
    size_wlh_to_named,
    intrinsic_matrix_to_named,
    build_clip_id,
)


class TestQuaternionConversion:
    def test_wxyz_to_named(self):
        # nuScenes: [w, x, y, z]
        q = [1.0, 0.0, 0.0, 0.0]
        result = quat_wxyz_to_named(q)
        assert result == {"qx": 0.0, "qy": 0.0, "qz": 0.0, "qw": 1.0}

    def test_wxyz_to_named_non_identity(self):
        q = [0.707, 0.0, 0.0, 0.707]
        result = quat_wxyz_to_named(q)
        assert result["qw"] == pytest.approx(0.707)
        assert result["qz"] == pytest.approx(0.707)


class TestTranslationConversion:
    def test_to_named(self):
        t = [1.0, 2.0, 3.0]
        result = translation_to_named(t)
        assert result == {"x": 1.0, "y": 2.0, "z": 3.0}


class TestSE3:
    def test_identity_transform(self):
        """Applying identity transform should not change the point."""
        t = [0.0, 0.0, 0.0]
        q = [1.0, 0.0, 0.0, 0.0]  # w,x,y,z identity
        R = quat_to_rotation_matrix(q)
        point = np.array([1.0, 2.0, 3.0])
        result = apply_se3(R, t, point)
        np.testing.assert_allclose(result, point, atol=1e-10)

    def test_pure_translation(self):
        t = [10.0, 20.0, 30.0]
        q = [1.0, 0.0, 0.0, 0.0]
        R = quat_to_rotation_matrix(q)
        point = np.array([1.0, 2.0, 3.0])
        result = apply_se3(R, t, point)
        np.testing.assert_allclose(result, [11.0, 22.0, 33.0], atol=1e-10)

    def test_invert_se3(self):
        """Applying transform then inverse should return original point."""
        t = [10.0, 20.0, 30.0]
        q = [0.707, 0.0, 0.0, 0.707]  # 90deg around z
        R = quat_to_rotation_matrix(q)
        R_inv, t_inv = invert_se3(R, t)
        point = np.array([5.0, 3.0, 1.0])
        transformed = apply_se3(R, t, point)
        recovered = apply_se3(R_inv, t_inv, transformed)
        np.testing.assert_allclose(recovered, point, atol=1e-6)

    def test_compose_se3(self):
        """compose(A, B) applied to point should equal A(B(point))."""
        t1 = [1.0, 0.0, 0.0]
        q1 = [1.0, 0.0, 0.0, 0.0]
        R1 = quat_to_rotation_matrix(q1)

        t2 = [0.0, 2.0, 0.0]
        q2 = [1.0, 0.0, 0.0, 0.0]
        R2 = quat_to_rotation_matrix(q2)

        R_c, t_c = compose_se3(R1, t1, R2, t2)
        point = np.array([0.0, 0.0, 0.0])
        result = apply_se3(R_c, t_c, point)
        np.testing.assert_allclose(result, [1.0, 2.0, 0.0], atol=1e-10)

    def test_rotation_matrix_roundtrip(self):
        q = [0.5, 0.5, 0.5, 0.5]  # w,x,y,z
        R = quat_to_rotation_matrix(q)
        q_back = rotation_matrix_to_quat(R)
        # Quaternions can differ by sign
        if q_back[0] * q[0] < 0:
            q_back = [-x for x in q_back]
        np.testing.assert_allclose(q_back, q, atol=1e-6)


class TestSizeConversion:
    def test_wlh_to_named(self):
        # nuScenes: [w, l, h]
        size = [1.8, 4.5, 1.5]
        result = size_wlh_to_named(size)
        assert result == {"length": 4.5, "width": 1.8, "height": 1.5}


class TestIntrinsicConversion:
    def test_matrix_to_named(self):
        matrix = [[1266.4, 0.0, 816.3], [0.0, 1266.4, 491.5], [0.0, 0.0, 1.0]]
        result = intrinsic_matrix_to_named(matrix)
        assert result["fx"] == pytest.approx(1266.4)
        assert result["fy"] == pytest.approx(1266.4)
        assert result["cx"] == pytest.approx(816.3)
        assert result["cy"] == pytest.approx(491.5)
        assert result["camera_model"] == "pinhole"
        # Image dimensions default to nuScenes standard 1600x900 when not given.
        assert result["image_width"] == 1600
        assert result["image_height"] == 900

    def test_empty_intrinsic(self):
        """nuScenes uses empty list for non-camera sensors."""
        result = intrinsic_matrix_to_named([])
        assert result is None


class TestBuildClipId:
    def test_basic(self):
        clip_id = build_clip_id(date_captured="2018-07-24", vehicle="n015", scene_name="scene-0061")
        assert clip_id == "20180724_n015_scene-0061_000"

    def test_different_date_format(self):
        clip_id = build_clip_id(date_captured="2018-08-01", vehicle="n008", scene_name="scene-0103")
        assert clip_id == "20180801_n008_scene-0103_000"


import os

from x4d_devkit.core.token import generate_token

NUSCENES_DATAROOT = "/data/PublicDatasets/nuscenes"
NUSCENES_AVAILABLE = os.path.isdir(os.path.join(NUSCENES_DATAROOT, "v1.0-mini"))


@pytest.mark.skipif(not NUSCENES_AVAILABLE, reason="nuScenes data not found")
class TestNuScenesConverterExtraction:
    """Integration tests using real nuScenes mini data."""

    @pytest.fixture
    def converter(self, tmp_path):
        from x4d_devkit.converters.nuscenes import NuScenesConverter
        return NuScenesConverter(
            dataroot=NUSCENES_DATAROOT,
            version="v1.0-mini",
            output_dir=str(tmp_path / "output"),
        )

    def test_init_loads_nuscenes(self, converter):
        assert converter.nusc is not None
        assert len(converter.nusc.scene) == 10

    def test_extract_scene_metadata(self, converter):
        scene = converter.nusc.scene[0]  # scene-0061
        clip_id, meta = converter._extract_metadata(scene)
        assert clip_id == "20180724_n015_scene-0061_000"
        assert meta["clip_id"] == clip_id
        assert meta["vehicle_id"] == "n015"
        assert "LIDAR_TOP" in meta["sensors"]
        assert "CAM_FRONT" in meta["sensors"]
        assert "RADAR_FRONT" not in meta["sensors"]
        assert len(meta["sensors"]) == 7  # 6 cam + 1 lidar
        assert meta["sensors"]["LIDAR_TOP"]["modality"] == "lidar"
        assert meta["sensors"]["CAM_FRONT"]["modality"] == "camera"
        assert meta["schema_version"] == "0.1"

    def test_extract_calibrated_sensors(self, converter):
        scene = converter.nusc.scene[0]
        clip_id, _ = converter._extract_metadata(scene)
        cs_records = converter._extract_calibrated_sensors(scene, clip_id)
        assert len(cs_records) == 7
        channels = {r["channel"] for r in cs_records}
        assert "CAM_FRONT" in channels
        assert "LIDAR_TOP" in channels
        assert "RADAR_FRONT" not in channels
        # Check token is deterministic
        cam_front = next(r for r in cs_records if r["channel"] == "CAM_FRONT")
        expected_token = generate_token(clip_id, "cs:CAM_FRONT")
        assert cam_front["calibrated_sensor_token"] == expected_token
        # Check named fields
        assert "x" in cam_front["translation"]
        assert "qx" in cam_front["rotation"]
        assert cam_front["intrinsics"] is not None
        assert "fx" in cam_front["intrinsics"]
        assert cam_front["intrinsics"]["camera_model"] == "pinhole"
        assert "child_frame" not in cam_front  # dropped in v0.4

    def test_ego_poses_local_coordinates(self, converter):
        scene = converter.nusc.scene[0]
        clip_id, _ = converter._extract_metadata(scene)
        ego_poses = converter._extract_ego_poses(scene, clip_id)
        # First keyframe ego_pose should be at origin
        first_kf_pose = min(
            (p for p in ego_poses if p["_is_keyframe"]),
            key=lambda p: p["timestamp_us"],
        )
        assert first_kf_pose["translation"]["x"] == pytest.approx(0.0, abs=1e-6)
        assert first_kf_pose["translation"]["y"] == pytest.approx(0.0, abs=1e-6)
        assert first_kf_pose["translation"]["z"] == pytest.approx(0.0, abs=1e-6)
        assert first_kf_pose["rotation"]["qw"] == pytest.approx(1.0, abs=1e-6)
        assert first_kf_pose["rotation"]["qx"] == pytest.approx(0.0, abs=1e-6)

    def test_annotations_have_velocity(self, converter):
        """At least some annotations should have non-null velocity after extraction."""
        scene = converter.nusc.scene[0]
        clip_id, _ = converter._extract_metadata(scene)
        annotations, instances = converter._extract_annotations(scene, clip_id)
        velocities = [a.get("velocity") for a in annotations]
        non_null = [v for v in velocities if v is not None]
        assert len(non_null) > 0, "Expected some annotations with velocity"
        v = non_null[0]
        assert "vx" in v and "vy" in v and "vz" in v

    def test_annotations_local_coordinates(self, converter):
        scene = converter.nusc.scene[0]
        clip_id, _ = converter._extract_metadata(scene)
        annotations, instances = converter._extract_annotations(scene, clip_id)
        assert len(annotations) > 0
        assert len(instances) > 0
        # Check annotation fields
        ann = annotations[0]
        assert "annotation_token" in ann
        assert "sample_token" in ann
        assert "instance_token" in ann
        assert "category" in ann
        assert "bbox_3d" in ann
        assert "translation" in ann["bbox_3d"]
        assert "size" in ann["bbox_3d"]
        assert "rotation" in ann["bbox_3d"]
        assert "length" in ann["bbox_3d"]["size"]
        # Check instance fields
        inst = instances[0]
        assert "instance_token" in inst
        assert "category" in inst
        assert "num_annotations" in inst
        assert "first_annotation_token" in inst
        assert "last_annotation_token" in inst


@pytest.mark.skipif(not NUSCENES_AVAILABLE, reason="nuScenes data not found")
class TestNuScenesConverterSamples:
    @pytest.fixture
    def converter(self, tmp_path):
        from x4d_devkit.converters.nuscenes import NuScenesConverter
        return NuScenesConverter(
            dataroot=NUSCENES_DATAROOT,
            version="v1.0-mini",
            output_dir=str(tmp_path / "output"),
        )

    def test_extract_samples(self, converter):
        scene = converter.nusc.scene[0]
        clip_id, _ = converter._extract_metadata(scene)
        samples = converter._extract_samples(scene, clip_id)
        assert len(samples) == scene["nbr_samples"]
        # All should be keyframes
        assert all(s["is_keyframe"] for s in samples)
        # Check prev/next chain
        assert samples[0]["prev"] is None
        assert samples[-1]["next"] is None
        for i in range(1, len(samples)):
            assert samples[i]["prev"] == samples[i - 1]["sample_token"]
            assert samples[i - 1]["next"] == samples[i]["sample_token"]

    def test_extract_sample_data(self, converter):
        scene = converter.nusc.scene[0]
        clip_id, _ = converter._extract_metadata(scene)
        ego_poses = converter._extract_ego_poses(scene, clip_id)
        ep_old_to_new = {ep["_original_token"]: ep["ego_pose_token"] for ep in ego_poses}
        sample_data_records = converter._extract_sample_data(scene, clip_id, ep_old_to_new)

        # Should have both keyframe and sweep records
        kf_count = sum(1 for sd in sample_data_records if sd["is_keyframe"])
        sweep_count = sum(1 for sd in sample_data_records if not sd["is_keyframe"])
        assert kf_count > 0
        assert sweep_count > 0

        # Check channels — only target channels
        channels = {sd["channel"] for sd in sample_data_records}
        assert "CAM_FRONT" in channels
        assert "LIDAR_TOP" in channels
        assert "RADAR_FRONT" not in channels

        # Check file_path format
        for sd in sample_data_records:
            assert sd["file_path"].endswith((".bin", ".jpg"))
            assert str(sd["timestamp_us"]) in sd["file_path"]
            if sd["is_keyframe"]:
                assert sd["file_path"].startswith("samples/")
            else:
                assert sd["file_path"].startswith("sweeps/")

    def test_extract_sample_data_prev_next_per_channel(self, converter):
        """prev/next chain should link records within the same channel."""
        scene = converter.nusc.scene[0]
        clip_id, _ = converter._extract_metadata(scene)
        ego_poses = converter._extract_ego_poses(scene, clip_id)
        ep_old_to_new = {ep["_original_token"]: ep["ego_pose_token"] for ep in ego_poses}
        sample_data_records = converter._extract_sample_data(scene, clip_id, ep_old_to_new)

        sd_by_token = {sd["sample_data_token"]: sd for sd in sample_data_records}
        cam_front_sds = [sd for sd in sample_data_records if sd["channel"] == "CAM_FRONT"]
        cam_front_sds.sort(key=lambda sd: sd["timestamp_us"])
        # First should have prev=None, last next=None
        assert cam_front_sds[0]["prev"] is None
        assert cam_front_sds[-1]["next"] is None
        # Check chain consistency
        for i in range(1, len(cam_front_sds)):
            assert cam_front_sds[i]["prev"] == cam_front_sds[i - 1]["sample_data_token"]


@pytest.mark.skipif(not NUSCENES_AVAILABLE, reason="nuScenes data not found")
class TestNuScenesConverterFullScene:
    @pytest.fixture
    def converter(self, tmp_path):
        from x4d_devkit.converters.nuscenes import NuScenesConverter
        return NuScenesConverter(
            dataroot=NUSCENES_DATAROOT,
            version="v1.0-mini",
            output_dir=str(tmp_path / "output"),
        )

    def test_convert_single_scene(self, converter):
        """Convert scene-0061 and verify output structure."""
        scene = converter.nusc.scene[0]
        clip_id = converter.convert_scene(scene["token"])

        clip_dir = converter.output_dir / "clips" / clip_id
        assert clip_dir.is_dir()

        # Check all 7 JSON files exist
        for name in [
            "meta.json",
            "calibrated_sensor.json",
            "ego_pose.json",
            "sample.json",
            "sample_data.json",
            "annotation.json",
            "instance.json",
        ]:
            json_path = clip_dir / name
            assert json_path.is_file(), f"Missing {name}"
            with open(json_path) as f:
                data = json.load(f)
            if name == "meta.json":
                assert isinstance(data, dict)
                assert data["clip_id"] == clip_id
            else:
                assert isinstance(data, list)
                assert len(data) > 0, f"{name} is empty"

        # Check sensor data directories
        assert (clip_dir / "samples" / "LIDAR_TOP").is_dir()
        assert (clip_dir / "samples" / "CAM_FRONT").is_dir()
        assert not (clip_dir / "samples" / "RADAR_FRONT").exists()

        # Check sensor files exist and are non-empty
        lidar_files = list((clip_dir / "samples" / "LIDAR_TOP").glob("*.bin"))
        assert len(lidar_files) > 0
        assert lidar_files[0].stat().st_size > 0

        cam_files = list((clip_dir / "samples" / "CAM_FRONT").glob("*.jpg"))
        assert len(cam_files) > 0

        # Check sweeps exist
        assert (clip_dir / "sweeps" / "LIDAR_TOP").is_dir()
        sweep_files = list((clip_dir / "sweeps" / "LIDAR_TOP").glob("*.bin"))
        assert len(sweep_files) > 0

    def test_sample_data_files_all_exist(self, converter):
        """Every file_path in sample_data.json should exist on disk."""
        scene = converter.nusc.scene[0]
        clip_id = converter.convert_scene(scene["token"])
        clip_dir = converter.output_dir / "clips" / clip_id

        with open(clip_dir / "sample_data.json") as f:
            sample_data = json.load(f)

        for sd in sample_data:
            fp = clip_dir / sd["file_path"]
            assert fp.is_file(), f"Missing file: {sd['file_path']}"

    def test_token_determinism(self, converter, tmp_path):
        """Running conversion twice should produce identical tokens."""
        scene = converter.nusc.scene[0]
        clip_id_1 = converter.convert_scene(scene["token"])
        clip_dir_1 = converter.output_dir / "clips" / clip_id_1

        # Second conversion to different output
        from x4d_devkit.converters.nuscenes import NuScenesConverter
        converter2 = NuScenesConverter(
            dataroot=NUSCENES_DATAROOT,
            version="v1.0-mini",
            output_dir=str(tmp_path / "output2"),
        )
        clip_id_2 = converter2.convert_scene(scene["token"])
        clip_dir_2 = converter2.output_dir / "clips" / clip_id_2

        assert clip_id_1 == clip_id_2
        for name in ["sample.json", "annotation.json", "instance.json"]:
            with open(clip_dir_1 / name) as f:
                data1 = json.load(f)
            with open(clip_dir_2 / name) as f:
                data2 = json.load(f)
            assert data1 == data2, f"Non-deterministic: {name}"


@pytest.mark.skipif(not NUSCENES_AVAILABLE, reason="nuScenes data not found")
class TestNuScenesConverterAllScenes:
    def test_convert_all_scenes(self, tmp_path):
        from x4d_devkit.converters.nuscenes import NuScenesConverter

        converter = NuScenesConverter(
            dataroot=NUSCENES_DATAROOT,
            version="v1.0-mini",
            output_dir=str(tmp_path / "output"),
        )
        clip_ids = converter.convert()
        assert len(clip_ids) == 10

        clips_dir = tmp_path / "output" / "clips"
        for clip_id in clip_ids:
            clip_dir = clips_dir / clip_id
            assert clip_dir.is_dir()
            # Every clip should have all 7 JSON files
            for name in [
                "meta.json",
                "calibrated_sensor.json",
                "ego_pose.json",
                "sample.json",
                "sample_data.json",
                "annotation.json",
                "instance.json",
            ]:
                assert (clip_dir / name).is_file()

            # Every sample_data file_path should exist
            with open(clip_dir / "sample_data.json") as f:
                sd_records = json.load(f)
            for sd in sd_records:
                assert (clip_dir / sd["file_path"]).is_file(), (
                    f"Missing: {clip_id}/{sd['file_path']}"
                )

    def test_no_duplicate_tokens_across_clips(self, tmp_path):
        from x4d_devkit.converters.nuscenes import NuScenesConverter

        converter = NuScenesConverter(
            dataroot=NUSCENES_DATAROOT,
            version="v1.0-mini",
            output_dir=str(tmp_path / "output"),
        )
        clip_ids = converter.convert()

        all_sample_tokens: set[str] = set()
        clips_dir = tmp_path / "output" / "clips"
        for clip_id in clip_ids:
            with open(clips_dir / clip_id / "sample.json") as f:
                samples = json.load(f)
            for s in samples:
                assert s["sample_token"] not in all_sample_tokens, (
                    f"Duplicate sample_token across clips: {s['sample_token']}"
                )
                all_sample_tokens.add(s["sample_token"])
