from x4d_devkit.core.token import generate_token


def test_sample_token():
    clip_id = "20180724_n015_scene-0061_000"
    timestamp_us = 1532402927647951
    token = generate_token(clip_id, str(timestamp_us))
    assert isinstance(token, str)
    assert len(token) == 16
    assert all(c in "0123456789abcdef" for c in token)


def test_sample_token_deterministic():
    clip_id = "20180724_n015_scene-0061_000"
    timestamp_us = 1532402927647951
    t1 = generate_token(clip_id, str(timestamp_us))
    t2 = generate_token(clip_id, str(timestamp_us))
    assert t1 == t2


def test_different_inputs_different_tokens():
    clip_id = "20180724_n015_scene-0061_000"
    t1 = generate_token(clip_id, "1532402927647951")
    t2 = generate_token(clip_id, "1532402927648000")
    assert t1 != t2


def test_sample_data_token():
    clip_id = "20180724_n015_scene-0061_000"
    token = generate_token(clip_id, "CAM_FRONT:1532402927647951")
    assert len(token) == 16


def test_ego_pose_token():
    clip_id = "20180724_n015_scene-0061_000"
    token = generate_token(clip_id, "ego:1532402927647951")
    assert len(token) == 16


def test_calibrated_sensor_token():
    clip_id = "20180724_n015_scene-0061_000"
    token = generate_token(clip_id, "cs:CAM_FRONT")
    assert len(token) == 16


def test_annotation_token():
    clip_id = "20180724_n015_scene-0061_000"
    sample_token = "abc1234567890def"
    instance_token = "1234567890abcdef"
    token = generate_token(clip_id, f"ann:{sample_token}:{instance_token}")
    assert len(token) == 16


def test_instance_token():
    clip_id = "20180724_n015_scene-0061_000"
    token = generate_token(clip_id, "inst:car:1532402927647951")
    assert len(token) == 16
