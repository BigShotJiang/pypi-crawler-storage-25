"""Tests for x4d_devkit.validation module."""
import json

import numpy as np
import pytest
from pathlib import Path

from x4d_devkit.validation import validate_clip


@pytest.fixture
def valid_clip(tmp_path):
    """Create a minimal valid clip directory."""
    clip_dir = tmp_path / "test_clip_000"
    clip_dir.mkdir()
    (clip_dir / "samples" / "LIDAR_TOP").mkdir(parents=True)

    ts = 1000000

    # meta.json
    (clip_dir / "meta.json").write_text(
        json.dumps(
            {
                "clip_id": "test_clip_000",
                "schema_version": "0.1",
                "session_id": "test_session",
                "vehicle_id": "v01",
                "capture_time_utc": "2024-01-01T00:00:00Z",
                "duration_s": 1.0,
                "keyframe_count": 1,
                "sweep_count": 0,
                "sensors": {
                    "LIDAR_TOP": {
                        "modality": "lidar",
                        "point_format": {
                            "fields": [
                                "x",
                                "y",
                                "z",
                                "intensity",
                                "ring_index",
                            ],
                            "types": ["float32"] * 5,
                            "bytes_per_point": 20,
                        },
                    }
                },
            }
        )
    )

    # calibrated_sensor.json
    (clip_dir / "calibrated_sensor.json").write_text(
        json.dumps(
            [
                {
                    "calibrated_sensor_token": "cs_lidar",
                    "channel": "lidar_top",
                    "parent_frame": "base_link",
                    "translation": {"x": 0, "y": 0, "z": 1.8},
                    "rotation": {"qx": 0, "qy": 0, "qz": 0, "qw": 1},
                    "intrinsics": None,
                    "distortion": None,
                }
            ]
        )
    )

    # ego_pose.json
    (clip_dir / "ego_pose.json").write_text(
        json.dumps(
            [
                {
                    "ego_pose_token": "ep_0",
                    "timestamp_us": ts,
                    "translation": {"x": 0, "y": 0, "z": 0},
                    "rotation": {"qx": 0, "qy": 0, "qz": 0, "qw": 1},
                }
            ]
        )
    )

    # sample.json
    (clip_dir / "sample.json").write_text(
        json.dumps(
            [
                {
                    "sample_token": "s_0",
                    "clip_id": "test_clip_000",
                    "timestamp_us": ts,
                    "is_keyframe": True,
                    "prev": None,
                    "next": None,
                }
            ]
        )
    )

    # sample_data.json
    (clip_dir / "sample_data.json").write_text(
        json.dumps(
            [
                {
                    "sample_data_token": "sd_0",
                    "sample_token": "s_0",
                    "channel": "LIDAR_TOP",
                    "timestamp_us": ts,
                    "file_path": "samples/LIDAR_TOP/1000000.bin",
                    "ego_pose_token": "ep_0",
                    "calibrated_sensor_token": "cs_lidar",
                    "is_keyframe": True,
                    "width": None,
                    "height": None,
                    "prev": None,
                    "next": None,
                }
            ]
        )
    )

    # annotation.json
    (clip_dir / "annotation.json").write_text(
        json.dumps(
            [
                {
                    "annotation_token": "ann_0",
                    "sample_token": "s_0",
                    "instance_token": "inst_0",
                    "category": "vehicle.car",
                    "bbox_3d": {
                        "translation": {"x": 10, "y": 5, "z": 0.5},
                        "size": {"length": 4.5, "width": 1.8, "height": 1.5},
                        "rotation": {"qx": 0, "qy": 0, "qz": 0, "qw": 1},
                    },
                    "num_lidar_pts": 100,
                    "visibility": "4",
                    "velocity": {"vx": 1.0, "vy": 0.0, "vz": 0.0},
                    "attributes": [],
                    "prev": None,
                    "next": None,
                    "score": None,
                }
            ]
        )
    )

    # instance.json
    (clip_dir / "instance.json").write_text(
        json.dumps(
            [
                {
                    "instance_token": "inst_0",
                    "category": "vehicle.car",
                    "num_annotations": 1,
                    "first_annotation_token": "ann_0",
                    "last_annotation_token": "ann_0",
                }
            ]
        )
    )

    # Point cloud binary
    pts = np.random.randn(100, 5).astype(np.float32)
    pts.tofile(str(clip_dir / "samples" / "LIDAR_TOP" / "1000000.bin"))

    return clip_dir


def test_valid_clip_passes(valid_clip):
    report = validate_clip(valid_clip)
    assert report.ok, str(report)
    assert len(report.errors) == 0


def test_missing_json_file(valid_clip):
    (valid_clip / "instance.json").unlink()
    report = validate_clip(valid_clip)
    assert not report.ok
    assert any("instance.json" in e.message for e in report.errors)


def test_missing_lidar_file(valid_clip):
    (valid_clip / "samples" / "LIDAR_TOP" / "1000000.bin").unlink()
    report = validate_clip(valid_clip)
    assert not report.ok
    assert any("lidar" in e.check.lower() for e in report.errors)


def test_invalid_bbox_size(valid_clip):
    anns = json.loads((valid_clip / "annotation.json").read_text())
    anns[0]["bbox_3d"]["size"]["length"] = -1.0
    (valid_clip / "annotation.json").write_text(json.dumps(anns))
    report = validate_clip(valid_clip)
    assert not report.ok


def test_missing_ego_pose_ref(valid_clip):
    sds = json.loads((valid_clip / "sample_data.json").read_text())
    sds[0]["ego_pose_token"] = "nonexistent"
    (valid_clip / "sample_data.json").write_text(json.dumps(sds))
    report = validate_clip(valid_clip)
    assert not report.ok
