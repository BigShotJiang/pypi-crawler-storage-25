"""Integration tests for ClipLoader — requires nuScenes mini data."""

import os

import numpy as np
import pytest

from x4d_devkit.core.loader import ClipLoader
from x4d_devkit.core.models import (
    ClipMeta, CalibratedSensor, EgoPose, Sample,
    SampleData, Annotation, Instance,
)

NUSCENES_DATAROOT = "/data/PublicDatasets/nuscenes"
NUSCENES_AVAILABLE = os.path.isdir(os.path.join(NUSCENES_DATAROOT, "v1.0-mini"))


@pytest.fixture(scope="module")
def clip_dir(tmp_path_factory):
    """Convert scene-0061 once and return the clip directory path."""
    if not NUSCENES_AVAILABLE:
        pytest.skip("nuScenes data not found")
    from x4d_devkit.converters.nuscenes import NuScenesConverter

    out = tmp_path_factory.mktemp("loader_test")
    conv = NuScenesConverter(
        dataroot=NUSCENES_DATAROOT, version="v1.0-mini", output_dir=str(out),
    )
    scene = conv.nusc.scene[0]
    clip_id = conv.convert_scene(scene["token"])
    return out / "clips" / clip_id


@pytest.mark.skipif(not NUSCENES_AVAILABLE, reason="nuScenes data not found")
class TestClipLoader:
    def test_load_meta(self, clip_dir):
        loader = ClipLoader(clip_dir)
        assert isinstance(loader.meta, ClipMeta)
        assert loader.meta.clip_id.startswith("2018")
        assert loader.meta.num_keyframes > 0

    def test_samples(self, clip_dir):
        loader = ClipLoader(clip_dir)
        assert len(loader.samples) > 0
        assert all(isinstance(s, Sample) for s in loader.samples)
        timestamps = [s.timestamp_us for s in loader.samples]
        assert timestamps == sorted(timestamps)

    def test_ego_poses(self, clip_dir):
        loader = ClipLoader(clip_dir)
        assert len(loader.ego_poses) > 0
        assert all(isinstance(ep, EgoPose) for ep in loader.ego_poses)

    def test_calibrated_sensors(self, clip_dir):
        loader = ClipLoader(clip_dir)
        assert len(loader.calibrated_sensors) == 7
        channels = {cs.channel for cs in loader.calibrated_sensors}
        assert "CAM_FRONT" in channels
        assert "LIDAR_TOP" in channels

    def test_annotations_and_instances(self, clip_dir):
        loader = ClipLoader(clip_dir)
        assert len(loader.annotations) > 0
        assert len(loader.instances) > 0
        assert all(isinstance(a, Annotation) for a in loader.annotations)
        assert all(isinstance(i, Instance) for i in loader.instances)

    def test_get_by_token(self, clip_dir):
        loader = ClipLoader(clip_dir)
        sample = loader.samples[0]
        found = loader.get(sample.token)
        assert found is sample

    def test_get_unknown_token_raises(self, clip_dir):
        loader = ClipLoader(clip_dir)
        with pytest.raises(KeyError):
            loader.get("nonexistent_token")

    def test_sample_data_for_channel(self, clip_dir):
        loader = ClipLoader(clip_dir)
        cam_data = loader.sample_data_for_channel("CAM_FRONT")
        assert len(cam_data) > 0
        assert all(sd.channel == "CAM_FRONT" for sd in cam_data)
        timestamps = [sd.timestamp_us for sd in cam_data]
        assert timestamps == sorted(timestamps)

    def test_sample_data_for_sample(self, clip_dir):
        loader = ClipLoader(clip_dir)
        sample = loader.samples[0]
        sds = loader.sample_data_for_sample(sample.token)
        assert len(sds) > 0
        assert all(sd.sample_token == sample.token for sd in sds)

    def test_annotations_for_sample(self, clip_dir):
        loader = ClipLoader(clip_dir)
        for sample in loader.samples:
            anns = loader.annotations_for_sample(sample.token)
            if anns:
                assert all(a.sample_token == sample.token for a in anns)
                break

    def test_load_point_cloud(self, clip_dir):
        loader = ClipLoader(clip_dir)
        lidar_data = loader.sample_data_for_channel("LIDAR_TOP")
        kf = next(sd for sd in lidar_data if sd.is_keyframe)
        pc = loader.load_point_cloud(kf)
        assert isinstance(pc, np.ndarray)
        assert pc.ndim == 2
        assert pc.shape[1] == 5  # x, y, z, intensity, ring_index
        assert pc.shape[0] > 100

    def test_load_image_path(self, clip_dir):
        loader = ClipLoader(clip_dir)
        cam_data = loader.sample_data_for_channel("CAM_FRONT")
        kf = next(sd for sd in cam_data if sd.is_keyframe)
        path = loader.load_image_path(kf)
        assert path.is_file()
        assert path.suffix == ".jpg"
