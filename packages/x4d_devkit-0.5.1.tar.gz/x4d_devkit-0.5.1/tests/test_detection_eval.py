"""Integration tests for DetectionEval — requires nuScenes mini converted clips."""

import copy
import json
import os
from pathlib import Path

import numpy as np
import pytest

from x4d_devkit.core.loader import ClipLoader
from x4d_devkit.eval.detection import (
    DetectionConfig,
    DetectionResult,
    DetectionEval,
    nusc_detection_config,
)

NUSCENES_DATAROOT = "/data/PublicDatasets/nuscenes"
NUSCENES_AVAILABLE = os.path.isdir(os.path.join(NUSCENES_DATAROOT, "v1.0-mini"))


def _create_pred_clip_from_gt(gt_clip_dir: Path, pred_clip_dir: Path,
                               noise_std: float = 0.0, drop_rate: float = 0.0):
    """Create a prediction clip by copying GT annotations with optional noise."""
    import shutil
    pred_clip_dir.mkdir(parents=True, exist_ok=True)

    for name in ["meta.json", "sample.json", "ego_pose.json",
                 "calibrated_sensor.json", "sample_data.json"]:
        shutil.copy2(gt_clip_dir / name, pred_clip_dir / name)

    with open(gt_clip_dir / "annotation.json") as f:
        gt_anns = json.load(f)

    rng = np.random.default_rng(42)
    pred_anns = []
    for ann in gt_anns:
        if drop_rate > 0 and rng.random() < drop_rate:
            continue
        pred = copy.deepcopy(ann)
        pred["score"] = 1.0
        if noise_std > 0:
            pred["bbox_3d"]["translation"]["x"] += rng.normal(0, noise_std)
            pred["bbox_3d"]["translation"]["y"] += rng.normal(0, noise_std)
        pred_anns.append(pred)

    with open(pred_clip_dir / "annotation.json", "w") as f:
        json.dump(pred_anns, f, indent=2)

    with open(pred_clip_dir / "instance.json", "w") as f:
        json.dump([], f)


@pytest.fixture(scope="module")
def gt_clip_dir(tmp_path_factory):
    if not NUSCENES_AVAILABLE:
        pytest.skip("nuScenes data not found")
    from x4d_devkit.converters.nuscenes import NuScenesConverter

    out = tmp_path_factory.mktemp("eval_test")
    conv = NuScenesConverter(
        dataroot=NUSCENES_DATAROOT, version="v1.0-mini", output_dir=str(out / "gt"),
    )
    scene = conv.nusc.scene[0]
    clip_id = conv.convert_scene(scene["token"])
    return out / "gt" / "clips" / clip_id


class TestDetectionConfig:
    def test_nusc_config(self):
        cfg = nusc_detection_config()
        assert len(cfg.class_names) == 10
        assert cfg.dist_thresholds == [0.5, 1.0, 2.0, 4.0]
        assert cfg.dist_th_tp == 2.0
        assert cfg.min_recall == 0.1
        assert cfg.min_precision == 0.1
        assert "car" in cfg.class_range


@pytest.mark.skipif(not NUSCENES_AVAILABLE, reason="nuScenes data not found")
class TestDetectionEvalPerfect:
    def test_perfect_predictions(self, gt_clip_dir, tmp_path):
        pred_dir = tmp_path / "pred_perfect" / gt_clip_dir.name
        _create_pred_clip_from_gt(gt_clip_dir, pred_dir)

        gt_loader = ClipLoader(gt_clip_dir)
        pred_loader = ClipLoader(pred_dir)

        evaluator = DetectionEval(gt_clips=[gt_loader], pred_clips=[pred_loader])
        result = evaluator.evaluate()

        assert isinstance(result, DetectionResult)
        # Some classes (bus, trailer) have no boxes within range in the mini
        # dataset, so perfect mAP won't be 1.0 across all 10 classes.
        # Classes that DO have boxes should get AP=1.0.
        classes_with_data = [
            cn for cn, ap in result.mean_dist_aps.items() if ap > 0
        ]
        assert len(classes_with_data) >= 8
        for cn in classes_with_data:
            assert result.mean_dist_aps[cn] == pytest.approx(1.0, abs=0.01)

        # TP errors for classes with data should be near zero
        for cn in classes_with_data:
            assert result.label_tp_errors[cn]["trans_err"] < 0.01
            assert result.label_tp_errors[cn]["scale_err"] < 0.01

        assert result.nd_score > 0.7


@pytest.mark.skipif(not NUSCENES_AVAILABLE, reason="nuScenes data not found")
class TestDetectionEvalNoisy:
    def test_noisy_predictions(self, gt_clip_dir, tmp_path):
        noise_std = 0.5
        pred_dir = tmp_path / "pred_noisy" / gt_clip_dir.name
        _create_pred_clip_from_gt(gt_clip_dir, pred_dir, noise_std=noise_std)

        gt_loader = ClipLoader(gt_clip_dir)
        pred_loader = ClipLoader(pred_dir)

        evaluator = DetectionEval(gt_clips=[gt_loader], pred_clips=[pred_loader])
        result = evaluator.evaluate()

        # Translation noise should increase trans_err for classes with data
        classes_with_data = [
            cn for cn, ap in result.mean_dist_aps.items() if ap > 0
        ]
        trans_errs = [
            result.label_tp_errors[cn]["trans_err"]
            for cn in classes_with_data
        ]
        assert max(trans_errs) > 0.1
        assert max(trans_errs) < 2.0

        # Scale was not perturbed, so classes with data should have low scale error.
        # Some cross-matching due to translation noise can cause minor scale errors.
        for cn in classes_with_data:
            assert result.label_tp_errors[cn]["scale_err"] < 0.1


@pytest.mark.skipif(not NUSCENES_AVAILABLE, reason="nuScenes data not found")
class TestDetectionEvalEmpty:
    def test_empty_predictions(self, gt_clip_dir, tmp_path):
        pred_dir = tmp_path / "pred_empty" / gt_clip_dir.name
        _create_pred_clip_from_gt(gt_clip_dir, pred_dir, drop_rate=1.0)

        gt_loader = ClipLoader(gt_clip_dir)
        pred_loader = ClipLoader(pred_dir)

        evaluator = DetectionEval(gt_clips=[gt_loader], pred_clips=[pred_loader])
        result = evaluator.evaluate()

        assert result.mean_ap == pytest.approx(0.0)
        assert result.nd_score == pytest.approx(0.0, abs=0.01)
