import numpy as np
import pytest

from x4d_devkit.fusion import (
    LIDAR_FUSED_DTYPE,
    FusionSource,
    fuse_pointclouds,
)


def _identity_pose():
    m = np.eye(4, dtype=np.float64)
    return m


def test_fused_dtype_is_5_float32_fields():
    assert LIDAR_FUSED_DTYPE.itemsize == 20
    assert LIDAR_FUSED_DTYPE.names == ("x", "y", "z", "intensity", "t")
    for name in LIDAR_FUSED_DTYPE.names:
        assert LIDAR_FUSED_DTYPE.fields[name][0] == np.dtype("<f4")


def test_single_lidar_identity_pose_no_per_point_ts():
    pts = np.array(
        [(1.0, 2.0, 3.0, 0.5),
         (4.0, 5.0, 6.0, 0.9)],
        dtype=[("x", "<f4"), ("y", "<f4"), ("z", "<f4"), ("intensity", "<f4")],
    )
    out = fuse_pointclouds(
        sources=[FusionSource(points=pts, lidar_to_ego=_identity_pose(), per_point_ts_field=None)],
        frame_ref_time_us=0,
    )
    assert out.dtype == LIDAR_FUSED_DTYPE
    assert out.shape == (2,)
    np.testing.assert_array_equal(out["x"], [1.0, 4.0])
    np.testing.assert_allclose(out["intensity"], [0.5, 0.9], rtol=1e-6)
    np.testing.assert_array_equal(out["t"], [0.0, 0.0])


def test_multi_lidar_concat_with_per_lidar_pose():
    pts_a = np.array([(1.0, 0.0, 0.0, 0.1)],
                     dtype=[("x", "<f4"), ("y", "<f4"), ("z", "<f4"), ("intensity", "<f4")])
    pts_b = np.array([(0.0, 1.0, 0.0, 0.2)],
                     dtype=[("x", "<f4"), ("y", "<f4"), ("z", "<f4"), ("intensity", "<f4")])
    pose_b = np.eye(4, dtype=np.float64); pose_b[0, 3] = 5.0  # shift +5 in x
    out = fuse_pointclouds(
        sources=[
            FusionSource(points=pts_a, lidar_to_ego=_identity_pose(), per_point_ts_field=None),
            FusionSource(points=pts_b, lidar_to_ego=pose_b, per_point_ts_field=None),
        ],
        frame_ref_time_us=0,
    )
    assert out.shape == (2,)
    np.testing.assert_allclose(out["x"], [1.0, 5.0])
    np.testing.assert_allclose(out["y"], [0.0, 1.0])


def test_per_point_ts_offset_is_seconds_relative_to_frame_ref():
    # Points at +1ms and +2ms vs frame ref
    pts = np.array(
        [(1.0, 0.0, 0.0, 0.0, 1_000_000_000),
         (2.0, 0.0, 0.0, 0.0, 1_000_001_000)],
        dtype=[("x", "<f4"), ("y", "<f4"), ("z", "<f4"), ("intensity", "<f4"), ("timestamp", "<u8")],
    )
    out = fuse_pointclouds(
        sources=[FusionSource(points=pts, lidar_to_ego=_identity_pose(),
                              per_point_ts_field="timestamp", per_point_ts_unit="ns")],
        frame_ref_time_us=1_000_000,  # 1ms after epoch
    )
    np.testing.assert_allclose(out["t"], [0.0, 1e-6], atol=1e-9)


def test_missing_intensity_raises():
    pts = np.array([(1.0, 2.0, 3.0)],
                   dtype=[("x", "<f4"), ("y", "<f4"), ("z", "<f4")])
    with pytest.raises(ValueError, match="intensity"):
        fuse_pointclouds(
            sources=[FusionSource(points=pts, lidar_to_ego=_identity_pose(), per_point_ts_field=None)],
            frame_ref_time_us=0,
        )


def test_per_point_ts_offset_microseconds_unit():
    # Points at +1ms vs frame ref, given in microseconds
    pts = np.array(
        [(1.0, 0.0, 0.0, 0.0, 1_000_000),
         (2.0, 0.0, 0.0, 0.0, 1_001_000)],
        dtype=[("x", "<f4"), ("y", "<f4"), ("z", "<f4"), ("intensity", "<f4"), ("timestamp", "<u8")],
    )
    out = fuse_pointclouds(
        sources=[FusionSource(points=pts, lidar_to_ego=_identity_pose(),
                              per_point_ts_field="timestamp", per_point_ts_unit="us")],
        frame_ref_time_us=1_000_000,
    )
    np.testing.assert_allclose(out["t"], [0.0, 1e-3], atol=1e-9)


def test_unsupported_ts_unit_raises():
    pts = np.array(
        [(1.0, 0.0, 0.0, 0.0, 0)],
        dtype=[("x", "<f4"), ("y", "<f4"), ("z", "<f4"), ("intensity", "<f4"), ("timestamp", "<u8")],
    )
    with pytest.raises(ValueError, match="unsupported per_point_ts_unit"):
        fuse_pointclouds(
            sources=[FusionSource(points=pts, lidar_to_ego=_identity_pose(),
                                  per_point_ts_field="timestamp", per_point_ts_unit="ms")],
            frame_ref_time_us=0,
        )


def test_unstructured_array_raises():
    pts = np.zeros((3, 4), dtype=np.float32)  # plain (N, 4) — not structured
    with pytest.raises(ValueError, match="structured numpy array"):
        fuse_pointclouds(
            sources=[FusionSource(points=pts, lidar_to_ego=_identity_pose(), per_point_ts_field=None)],
            frame_ref_time_us=0,
        )


def test_dtype_round_trip_via_tofile(tmp_path):
    pts = np.array(
        [(1.5, -2.5, 3.5, 0.25),
         (10.0, 20.0, 30.0, 0.5)],
        dtype=[("x", "<f4"), ("y", "<f4"), ("z", "<f4"), ("intensity", "<f4")],
    )
    out = fuse_pointclouds(
        sources=[FusionSource(points=pts, lidar_to_ego=_identity_pose(), per_point_ts_field=None)],
        frame_ref_time_us=0,
    )
    path = tmp_path / "test.bin"
    out.tofile(str(path))
    assert path.stat().st_size == 2 * 20  # 2 points * 20 bytes/point
    roundtrip = np.fromfile(str(path), dtype=LIDAR_FUSED_DTYPE)
    np.testing.assert_array_equal(roundtrip, out)
