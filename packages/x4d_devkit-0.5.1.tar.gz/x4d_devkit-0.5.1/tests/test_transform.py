import numpy as np
import pytest

from x4d_devkit.core.transform import (
    quat_to_rotation_matrix,
    rotation_matrix_to_quat,
    Transform,
)


class TestQuatHelpers:
    def test_identity_quat_to_matrix(self):
        """Identity quat [0,0,0,1] -> identity matrix."""
        R = quat_to_rotation_matrix(0.0, 0.0, 0.0, 1.0)
        np.testing.assert_allclose(R, np.eye(3), atol=1e-10)

    def test_90deg_z_rotation(self):
        """90 deg around Z: qx=0, qy=0, qz=sin(45), qw=cos(45)."""
        s = np.sin(np.pi / 4)
        c = np.cos(np.pi / 4)
        R = quat_to_rotation_matrix(0.0, 0.0, s, c)
        # X axis -> Y axis
        np.testing.assert_allclose(R @ [1, 0, 0], [0, 1, 0], atol=1e-10)

    def test_roundtrip(self):
        """quat -> matrix -> quat round-trip."""
        qx, qy, qz, qw = 0.5, 0.5, 0.5, 0.5
        R = quat_to_rotation_matrix(qx, qy, qz, qw)
        qx2, qy2, qz2, qw2 = rotation_matrix_to_quat(R)
        # Quaternions can differ by sign
        q1 = np.array([qx, qy, qz, qw])
        q2 = np.array([qx2, qy2, qz2, qw2])
        if np.dot(q1, q2) < 0:
            q2 = -q2
        np.testing.assert_allclose(q2, q1, atol=1e-6)


class TestTransform:
    def test_identity(self):
        T = Transform.identity()
        np.testing.assert_allclose(T.rotation, np.eye(3))
        np.testing.assert_allclose(T.translation, [0, 0, 0])

    def test_from_quat_identity(self):
        T = Transform.from_quat([0, 0, 0], [0, 0, 0, 1])
        np.testing.assert_allclose(T.rotation, np.eye(3), atol=1e-10)
        np.testing.assert_allclose(T.translation, [0, 0, 0])

    def test_apply_single_point(self):
        T = Transform.from_quat([10, 20, 30], [0, 0, 0, 1])
        result = T.apply(np.array([1.0, 2.0, 3.0]))
        np.testing.assert_allclose(result, [11, 22, 33], atol=1e-10)

    def test_apply_batch(self):
        T = Transform.from_quat([1, 0, 0], [0, 0, 0, 1])
        pts = np.array([[0, 0, 0], [1, 1, 1]])
        result = T.apply(pts)
        np.testing.assert_allclose(result, [[1, 0, 0], [2, 1, 1]], atol=1e-10)

    def test_inverse_roundtrip(self):
        T = Transform.from_quat([10, 20, 30], [0.0, 0.0, np.sin(np.pi / 4), np.cos(np.pi / 4)])
        pts = np.array([[5, 3, 1], [0, 0, 0]])
        recovered = T.inverse.apply(T.apply(pts))
        np.testing.assert_allclose(recovered, pts, atol=1e-10)

    def test_matmul_composition(self):
        A = Transform.from_quat([1, 0, 0], [0, 0, 0, 1])
        B = Transform.from_quat([0, 2, 0], [0, 0, 0, 1])
        C = A @ B
        result = C.apply(np.array([0.0, 0.0, 0.0]))
        np.testing.assert_allclose(result, [1, 2, 0], atol=1e-10)

    def test_matmul_equals_sequential_apply(self):
        A = Transform.from_quat([1, 2, 3], [0.0, 0.0, np.sin(np.pi / 8), np.cos(np.pi / 8)])
        B = Transform.from_quat([4, 5, 6], [0.0, np.sin(np.pi / 6), 0.0, np.cos(np.pi / 6)])
        pt = np.array([7.0, 8.0, 9.0])
        composed = (A @ B).apply(pt)
        sequential = A.apply(B.apply(pt))
        np.testing.assert_allclose(composed, sequential, atol=1e-10)

    def test_as_matrix(self):
        T = Transform.from_quat([1, 2, 3], [0, 0, 0, 1])
        M = T.as_matrix
        assert M.shape == (4, 4)
        np.testing.assert_allclose(M[:3, 3], [1, 2, 3])
        assert M[3, 3] == 1.0

    def test_quat_property(self):
        quat = [0.0, 0.0, np.sin(np.pi / 4), np.cos(np.pi / 4)]
        T = Transform.from_quat([0, 0, 0], quat)
        np.testing.assert_allclose(T.quat, quat, atol=1e-10)
