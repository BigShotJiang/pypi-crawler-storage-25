"""Integration tests for TransformChain — requires nuScenes mini data."""

import os

import numpy as np
import pytest

from x4d_devkit.core.loader import ClipLoader
from x4d_devkit.core.transform import Transform, TransformChain

NUSCENES_DATAROOT = "/data/PublicDatasets/nuscenes"
NUSCENES_AVAILABLE = os.path.isdir(os.path.join(NUSCENES_DATAROOT, "v1.0-mini"))


@pytest.fixture(scope="module")
def loader(tmp_path_factory):
    if not NUSCENES_AVAILABLE:
        pytest.skip("nuScenes data not found")
    from x4d_devkit.converters.nuscenes import NuScenesConverter

    out = tmp_path_factory.mktemp("chain_test")
    conv = NuScenesConverter(
        dataroot=NUSCENES_DATAROOT, version="v1.0-mini", output_dir=str(out),
    )
    scene = conv.nusc.scene[0]
    clip_id = conv.convert_scene(scene["token"])
    return ClipLoader(out / "clips" / clip_id)


@pytest.mark.skipif(not NUSCENES_AVAILABLE, reason="nuScenes data not found")
class TestTransformChain:
    def test_ego_from_sensor_lidar(self, loader):
        chain = TransformChain(loader)
        T = chain.get_ego_from_sensor("LIDAR_TOP")
        assert isinstance(T, Transform)
        # LIDAR_TOP has extrinsic offset from base_link, should not be identity
        assert not np.allclose(T.translation, [0, 0, 0], atol=1e-3)

    def test_ego_from_sensor_camera(self, loader):
        chain = TransformChain(loader)
        T = chain.get_ego_from_sensor("CAM_FRONT")
        assert isinstance(T, Transform)

    def test_world_from_ego_first_frame_near_identity(self, loader):
        """First ego_pose in local coords should be near identity."""
        chain = TransformChain(loader)
        first_ep = loader.ego_poses[0]
        T = chain.get_world_from_ego(first_ep.token)
        np.testing.assert_allclose(T.translation, [0, 0, 0], atol=0.1)
        np.testing.assert_allclose(T.rotation, np.eye(3), atol=0.1)

    def test_world_from_sensor_composition(self, loader):
        """world_from_sensor == world_from_ego @ ego_from_sensor."""
        chain = TransformChain(loader)
        lidar_data = loader.sample_data_for_channel("LIDAR_TOP")
        sd = next(s for s in lidar_data if s.is_keyframe)

        T_direct = chain.get_world_from_sensor(sd)
        T_ego = chain.get_world_from_ego(sd.ego_pose_token)
        T_sensor = chain.get_ego_from_sensor(sd.channel)
        T_composed = T_ego @ T_sensor

        np.testing.assert_allclose(T_direct.rotation, T_composed.rotation, atol=1e-10)
        np.testing.assert_allclose(T_direct.translation, T_composed.translation, atol=1e-10)

    def test_point_cloud_round_trip(self, loader):
        """sensor -> world -> sensor round-trip should recover original points."""
        chain = TransformChain(loader)
        lidar_data = loader.sample_data_for_channel("LIDAR_TOP")
        sd = next(s for s in lidar_data if s.is_keyframe)
        pc = loader.load_point_cloud(sd)
        xyz = pc[:, :3]

        world_pts = chain.transform_points_to_world(xyz, sd)
        recovered = chain.transform_points_to_sensor(world_pts, sd)
        np.testing.assert_allclose(recovered, xyz, atol=1e-6)

    def test_transform_points_to_world_changes_coords(self, loader):
        """Points in world coords should differ from sensor coords."""
        chain = TransformChain(loader)
        lidar_data = loader.sample_data_for_channel("LIDAR_TOP")
        sd = next(s for s in lidar_data if s.is_keyframe)
        pc = loader.load_point_cloud(sd)
        xyz = pc[:10, :3]

        world_pts = chain.transform_points_to_world(xyz, sd)
        # Not identical (LIDAR_TOP has extrinsic offset)
        assert not np.allclose(world_pts, xyz, atol=1e-3)
