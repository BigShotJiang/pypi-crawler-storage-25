"""Lidar fusion to ego frame.

Single-lidar and multi-lidar share one path: each source provides its points
in lidar frame plus a 4x4 homogeneous lidar->ego transform. Output is a
contiguous structured array with the canonical 5-field layout.

Used by the X-4D ingestion pipeline to write `samples/lidar/<ts>.bin` and
`sweeps/lidar/<ts>.bin`. Downstream consumers read with
`np.fromfile(path, dtype=LIDAR_FUSED_DTYPE)`.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np


LIDAR_FUSED_DTYPE = np.dtype([
    ("x", "<f4"),
    ("y", "<f4"),
    ("z", "<f4"),
    ("intensity", "<f4"),
    ("t", "<f4"),
])


@dataclass
class FusionSource:
    points: np.ndarray                   # structured array; must include x, y, z, intensity
    lidar_to_ego: np.ndarray             # (4, 4) float64 homogeneous
    per_point_ts_field: Optional[str] = None  # name of u64/i64 ts field, e.g. "timestamp"
    per_point_ts_unit: str = "ns"        # "ns" | "us"


def _intensity_field(names: tuple[str, ...]) -> str:
    for n in names:
        if "intensity" in n.lower():
            return n
    raise ValueError(
        f"point cloud has no field with 'intensity' in its name (got {names!r}); "
        "fusion refuses to silently zero-fill"
    )


def _transform_xyz(xyz: np.ndarray, T: np.ndarray) -> np.ndarray:
    # xyz: (N, 3) float64; T: (4, 4) float64; returns (N, 3) float32
    homog = np.empty((xyz.shape[0], 4), dtype=np.float64)
    homog[:, :3] = xyz
    homog[:, 3] = 1.0
    out = homog @ T.T
    return out[:, :3].astype(np.float32, copy=False)


def fuse_pointclouds(sources: list[FusionSource], frame_ref_time_us: int) -> np.ndarray:
    """Transform each source into ego frame and concat into the 5-field layout.

    `frame_ref_time_us` is the synced frame timestamp; per-point `t` is computed
    as `(point_ts - frame_ref) / 1e6` (seconds). When a source has no per-point
    timestamp, `t` is filled with 0 (semantics: no motion-comp info available).
    """
    if not sources:
        return np.empty((0,), dtype=LIDAR_FUSED_DTYPE)

    chunks: list[np.ndarray] = []
    for src in sources:
        pts = src.points
        if pts.dtype.names is None:
            raise ValueError(
                "FusionSource.points must be a structured numpy array with named fields"
            )
        names = pts.dtype.names
        for required in ("x", "y", "z"):
            if required not in names:
                raise ValueError(f"source missing field {required!r}; got {names!r}")
        intensity_name = _intensity_field(names)

        xyz = np.column_stack([pts["x"], pts["y"], pts["z"]]).astype(np.float64, copy=False)
        ego_xyz = _transform_xyz(xyz, np.asarray(src.lidar_to_ego, dtype=np.float64))

        intensity = np.asarray(pts[intensity_name], dtype=np.float32)

        if src.per_point_ts_field and src.per_point_ts_field in names:
            raw_ts = np.asarray(pts[src.per_point_ts_field], dtype=np.int64)
            if src.per_point_ts_unit == "ns":
                ref_ns = int(frame_ref_time_us) * 1000
                t = ((raw_ts - ref_ns).astype(np.float64) / 1e9).astype(np.float32)
            elif src.per_point_ts_unit == "us":
                ref_us = int(frame_ref_time_us)
                t = ((raw_ts - ref_us).astype(np.float64) / 1e6).astype(np.float32)
            else:
                raise ValueError(f"unsupported per_point_ts_unit: {src.per_point_ts_unit}")
        else:
            t = np.zeros((ego_xyz.shape[0],), dtype=np.float32)

        out = np.empty((ego_xyz.shape[0],), dtype=LIDAR_FUSED_DTYPE)
        out["x"] = ego_xyz[:, 0]
        out["y"] = ego_xyz[:, 1]
        out["z"] = ego_xyz[:, 2]
        out["intensity"] = intensity
        out["t"] = t
        chunks.append(out)

    return np.concatenate(chunks, axis=0)
