"""SE3 transform utilities for X4D coordinate systems.

Quaternion convention: [qx, qy, qz, qw] (X4D standard).
Transform naming convention: dst_from_src (e.g. world_from_ego).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def quat_to_rotation_matrix(qx: float, qy: float, qz: float, qw: float) -> np.ndarray:
    """Convert quaternion to 3x3 rotation matrix.

    Args:
        qx: Quaternion x component.
        qy: Quaternion y component.
        qz: Quaternion z component.
        qw: Quaternion w (scalar) component.

    Returns:
        (3, 3) rotation matrix as numpy float64 array.
    """
    q = np.array([qx, qy, qz, qw], dtype=float)
    q = q / np.linalg.norm(q)
    x, y, z, w = q
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
            [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
            [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
        ]
    )


def rotation_matrix_to_quat(R: np.ndarray) -> tuple[float, float, float, float]:
    """Convert 3x3 rotation matrix to quaternion.

    Args:
        R: (3, 3) rotation matrix.

    Returns:
        Tuple of (qx, qy, qz, qw).
    """
    trace = R[0, 0] + R[1, 1] + R[2, 2]
    if trace > 0:
        s = 0.5 / np.sqrt(trace + 1.0)
        w = 0.25 / s
        x = (R[2, 1] - R[1, 2]) * s
        y = (R[0, 2] - R[2, 0]) * s
        z = (R[1, 0] - R[0, 1]) * s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = 2.0 * np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2])
        w = (R[2, 1] - R[1, 2]) / s
        x = 0.25 * s
        y = (R[0, 1] + R[1, 0]) / s
        z = (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = 2.0 * np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2])
        w = (R[0, 2] - R[2, 0]) / s
        x = (R[0, 1] + R[1, 0]) / s
        y = 0.25 * s
        z = (R[1, 2] + R[2, 1]) / s
    else:
        s = 2.0 * np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1])
        w = (R[1, 0] - R[0, 1]) / s
        x = (R[0, 2] + R[2, 0]) / s
        y = (R[1, 2] + R[2, 1]) / s
        z = 0.25 * s
    return (float(x), float(y), float(z), float(w))


@dataclass(frozen=True)
class Transform:
    """SE3 rigid-body transform (rotation + translation).

    Naming convention: variable name should read as ``dst_from_src``.
    Example: ``world_from_ego = Transform(...)`` means ``p_world = T @ p_ego``.

    Attributes:
        rotation: (3, 3) rotation matrix.
        translation: (3,) translation vector in meters.

    Example::

        T = Transform.from_quat([1.0, 2.0, 3.0], [0, 0, 0, 1])
        pts_world = T.apply(pts_sensor)       # (N, 3) -> (N, 3)
        T_inv = T.inverse                     # invert
        T_composed = T_a @ T_b                # compose
        mat = T.as_matrix                     # (4, 4) homogeneous matrix
    """

    rotation: np.ndarray     # (3, 3) rotation matrix
    translation: np.ndarray  # (3,)

    def __post_init__(self) -> None:
        object.__setattr__(self, "rotation", np.asarray(self.rotation, dtype=float))
        object.__setattr__(self, "translation", np.asarray(self.translation, dtype=float))

    @classmethod
    def identity(cls) -> Transform:
        """Return the identity transform (no rotation, no translation)."""
        return cls(rotation=np.eye(3), translation=np.zeros(3))

    @classmethod
    def from_quat(
        cls,
        translation: np.ndarray | list[float],
        quat: np.ndarray | list[float],
    ) -> Transform:
        """Construct a Transform from translation and quaternion.

        Args:
            translation: (3,) position vector [x, y, z].
            quat: (4,) quaternion [qx, qy, qz, qw].

        Returns:
            Transform instance.
        """
        q = np.asarray(quat, dtype=float)
        R = quat_to_rotation_matrix(q[0], q[1], q[2], q[3])
        return cls(rotation=R, translation=np.asarray(translation, dtype=float))

    @property
    def inverse(self) -> Transform:
        """Return the inverse transform such that ``T @ T.inverse ≈ identity``."""
        R_inv = self.rotation.T
        t_inv = -R_inv @ self.translation
        return Transform(rotation=R_inv, translation=t_inv)

    def __matmul__(self, other: Transform) -> Transform:
        """Compose transforms: (A @ B).apply(p) == A.apply(B.apply(p))."""
        R = self.rotation @ other.rotation
        t = self.rotation @ other.translation + self.translation
        return Transform(rotation=R, translation=t)

    def apply(self, points: np.ndarray) -> np.ndarray:
        """Apply this transform to points.

        Args:
            points: (N, 3) or (3,) array of 3D points.

        Returns:
            Transformed points with the same shape as input.
        """
        return (self.rotation @ points.T).T + self.translation

    @property
    def as_matrix(self) -> np.ndarray:
        """Return (4, 4) homogeneous transformation matrix."""
        M = np.eye(4)
        M[:3, :3] = self.rotation
        M[:3, 3] = self.translation
        return M

    @property
    def quat(self) -> np.ndarray:
        """Return quaternion as [qx, qy, qz, qw]."""
        return np.array(rotation_matrix_to_quat(self.rotation))


from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from x4d_devkit.core.loader import ClipLoader
    from x4d_devkit.core.models import SampleData


class TransformChain:
    """Build coordinate transform chains from a loaded clip.

    Composes sensor → ego → world transforms using calibration
    and ego_pose data from a ClipLoader.

    For most use cases, prefer ``ClipLoader.get_transform()`` and
    ``ClipLoader.load_point_cloud(..., frame=)``, which use TransformChain
    internally.

    Args:
        loader: A loaded ClipLoader instance.

    Example::

        chain = TransformChain(loader)
        T = chain.get_world_from_sensor(sd)
        pts_world = T.apply(pts_sensor)
    """

    def __init__(self, loader: ClipLoader) -> None:
        self._loader = loader
        self._cs_by_channel = {cs.channel: cs for cs in loader.calibrated_sensors}

    def get_ego_from_sensor(self, channel: str) -> Transform:
        """Get the static sensor-to-ego transform for a channel.

        This is the extrinsic calibration (fixed, does not change per frame).

        Args:
            channel: Sensor channel name (e.g. "LIDAR_TOP").

        Returns:
            Transform from sensor frame to ego (base_link) frame.
        """
        cs = self._cs_by_channel[channel]
        return Transform.from_quat(cs.translation, cs.rotation)

    def get_world_from_ego(self, ego_pose_token: str) -> Transform:
        """Get the ego-to-world transform for a specific ego pose.

        Args:
            ego_pose_token: Token of the ego pose record.

        Returns:
            Transform from ego frame to world frame.
        """
        ep = self._loader.get(ego_pose_token)
        return Transform.from_quat(ep.translation, ep.rotation)

    def get_world_from_sensor(self, sd: SampleData) -> Transform:
        """Get the full sensor-to-world transform for a sample_data record.

        Equivalent to ``world_from_ego @ ego_from_sensor``.

        Args:
            sd: The SampleData record.

        Returns:
            Transform from sensor frame to world frame.
        """
        return self.get_world_from_ego(sd.ego_pose_token) @ self.get_ego_from_sensor(sd.channel)

    def transform_points_to_world(self, points: np.ndarray, sd: SampleData) -> np.ndarray:
        """Transform points from sensor frame to world frame.

        Args:
            points: (N, 3) array of 3D points in sensor coordinates.
            sd: The SampleData record (determines which sensor and ego pose).

        Returns:
            (N, 3) array of points in world coordinates.
        """
        return self.get_world_from_sensor(sd).apply(points)

    def transform_points_to_sensor(self, points: np.ndarray, sd: SampleData) -> np.ndarray:
        """Transform points from world frame to sensor frame.

        Args:
            points: (N, 3) array of 3D points in world coordinates.
            sd: The SampleData record.

        Returns:
            (N, 3) array of points in sensor coordinates.
        """
        return self.get_world_from_sensor(sd).inverse.apply(points)
