"""Deterministic token generation for X4D dataset format.

All tokens are md5(clip_id + ":" + discriminator), truncated to 16 hex chars.
"""

import hashlib


def generate_token(clip_id: str, discriminator: str) -> str:
    """Generate a deterministic 16-char hex token.

    Args:
        clip_id: The clip identifier (e.g. "20180724_n015_scene-0061_000").
        discriminator: Type-specific suffix. Convention:
            - sample:            str(timestamp_us)
            - sample_data:       f"{channel}:{timestamp_us}"
            - ego_pose:          f"ego:{timestamp_us}"
            - calibrated_sensor: f"cs:{channel}"
            - annotation:        f"ann:{sample_token}:{instance_token}"
            - instance:          f"inst:{category}:{first_timestamp_us}"

    Returns:
        16-character lowercase hex string.
    """
    raw = f"{clip_id}:{discriminator}"
    return hashlib.md5(raw.encode()).hexdigest()[:16]
