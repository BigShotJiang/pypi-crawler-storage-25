"""Frozen dataclass models for X4D dataset entities.

All models are frozen (immutable) dataclasses. Array fields (translation,
rotation, size, velocity) are stored as numpy float64 arrays.

Coordinate conventions:
    - Quaternions: [qx, qy, qz, qw]
    - Translation: [x, y, z] in meters
    - Size: [length, width, height] in meters
    - Velocity: [vx, vy, vz] in m/s
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass(frozen=True)
class ClipMeta:
    """Metadata for an X4D clip (from meta.json).

    Attributes:
        clip_id: Unique clip identifier (e.g. "20180724_n015_scene-0061_000").
        schema_version: X4D format version (e.g. "0.2").
        session_id: Recording session identifier.
        vehicle_id: Vehicle identifier.
        capture_time_utc: Capture timestamp in ISO 8601 format.
        duration_s: Clip duration in seconds.
        num_keyframes: Number of keyframes (annotated frames).
        num_sweeps: Number of sweep frames (non-annotated intermediate frames).
        sensors: Sensor metadata dict, keyed by channel name. Each value
            contains ``modality`` ("lidar"/"camera") and ``point_format``
            (for LiDAR channels, describes binary file field layout).
    """

    clip_id: str
    schema_version: str
    session_id: str
    vehicle_id: str
    capture_time_utc: str
    duration_s: float
    num_keyframes: int
    num_sweeps: int
    sensors: dict[str, dict[str, Any]]


@dataclass(frozen=True)
class CalibratedSensor:
    """Static sensor extrinsic calibration (sensor → ego transform).

    Attributes:
        token: Unique token for this calibrated sensor record.
        channel: Sensor channel name — equals the ROS frame_id of the sensor
            (e.g. "lidar_top", "cam_front_left").
        modality: "lidar" or "camera".
        translation: (3,) float64 array — sensor position in ego frame [x, y, z] meters.
        rotation: (4,) float64 array — sensor orientation as quaternion [qx, qy, qz, qw].
        intrinsics: Full camera intrinsics dict (camera_model, fx, fy, cx, cy,
            image_width, image_height) or None for LiDAR.
        distortion: Distortion model dict (model + coefficients) or None.
    """

    token: str
    channel: str
    modality: str
    translation: np.ndarray
    rotation: np.ndarray
    intrinsics: dict | None
    distortion: dict | None

    def __post_init__(self) -> None:
        object.__setattr__(self, "translation", np.asarray(self.translation, dtype=np.float64))
        object.__setattr__(self, "rotation", np.asarray(self.rotation, dtype=np.float64))


@dataclass(frozen=True)
class EgoPose:
    """Ego vehicle pose at a specific timestamp (ego → world transform).

    The world frame is a local coordinate system where the first ego pose
    of the clip is approximately at the origin.

    Attributes:
        token: Unique token for this ego pose record.
        timestamp_us: Timestamp in microseconds.
        translation: (3,) float64 array — ego position in world frame [x, y, z] meters.
        rotation: (4,) float64 array — ego orientation as quaternion [qx, qy, qz, qw].
    """

    token: str
    timestamp_us: int
    translation: np.ndarray
    rotation: np.ndarray

    def __post_init__(self) -> None:
        object.__setattr__(self, "translation", np.asarray(self.translation, dtype=np.float64))
        object.__setattr__(self, "rotation", np.asarray(self.rotation, dtype=np.float64))


@dataclass(frozen=True)
class Sample:
    """A synchronized snapshot across all sensors at a timestamp.

    Attributes:
        token: Unique sample token.
        timestamp_us: Timestamp in microseconds.
        is_keyframe: True if this sample has annotations.
        prev: Token of previous sample in temporal order, or "" if first.
        next: Token of next sample in temporal order, or "" if last.
    """

    token: str
    timestamp_us: int
    is_keyframe: bool
    prev: str
    next: str


@dataclass(frozen=True)
class SampleData:
    """A single sensor observation (one channel at one timestamp).

    Attributes:
        token: Unique sample_data token.
        sample_token: Token of the parent sample.
        channel: Sensor channel name (e.g. "LIDAR_TOP", "CAM_FRONT").
        timestamp_us: Timestamp in microseconds.
        file_path: Relative path to the sensor data file within the clip directory.
        ego_pose_token: Token of the ego pose at this timestamp.
        calibrated_sensor_token: Token of the calibrated sensor for this channel.
        is_keyframe: True if this is a keyframe (annotated) observation.
        width: Image width in pixels (None for LiDAR).
        height: Image height in pixels (None for LiDAR).
        prev: Token of previous sample_data in same channel, or "" if first.
        next: Token of next sample_data in same channel, or "" if last.
    """

    token: str
    sample_token: str
    channel: str
    timestamp_us: int
    file_path: str
    ego_pose_token: str
    calibrated_sensor_token: str
    is_keyframe: bool
    width: int | None
    height: int | None
    prev: str
    next: str


@dataclass(frozen=True)
class Annotation:
    """A 3D bounding box annotation in **per-sample ego frame** (v0.5).

    Annotations are natively stored in the ego frame of the sample they belong
    to (the ego_pose of the sample's LiDAR keyframe). Use
    ``ClipLoader.annotations_for_sample(..., frame="world")`` to transform to
    the clip's local world frame when needed (rare — typically only for
    cross-frame trajectory visualization).

    Attributes:
        token: Unique annotation token.
        sample_token: Token of the sample this annotation belongs to.
        instance_token: Token of the tracked object instance.
        category: Object category string (e.g. "car", "pedestrian").
        translation: (3,) float64 array — box center [x, y, z] in this sample's ego frame.
        size: (3,) float64 array — box dimensions [length, width, height] in meters.
        rotation: (4,) float64 array — box orientation as quaternion [qx, qy, qz, qw],
            relative to this sample's ego frame.
        num_lidar_pts: Number of LiDAR points inside this box (real-counted, ≥ 0).
        visibility: Visibility level as string ("1" to "4", or "" if unknown).
        velocity: (3,) float64 array — velocity [vx, vy, vz] in m/s, **ego frame**
            (forward = +x, left = +y), or None.
        attributes: List of attribute strings (e.g. ["vehicle.moving"]).
        prev: Token of previous annotation of same instance, or "" if first.
        next: Token of next annotation of same instance, or "" if last.
        score: Detection confidence score (None for ground truth, float for predictions).
    """

    token: str
    sample_token: str
    instance_token: str
    category: str
    translation: np.ndarray
    size: np.ndarray
    rotation: np.ndarray
    num_lidar_pts: int
    visibility: str
    velocity: np.ndarray | None
    attributes: list[str]
    prev: str
    next: str
    score: float | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "translation", np.asarray(self.translation, dtype=np.float64))
        object.__setattr__(self, "size", np.asarray(self.size, dtype=np.float64))
        object.__setattr__(self, "rotation", np.asarray(self.rotation, dtype=np.float64))
        if self.velocity is not None:
            object.__setattr__(self, "velocity", np.asarray(self.velocity, dtype=np.float64))


@dataclass(frozen=True)
class Instance:
    """A tracked object instance across multiple samples.

    Attributes:
        token: Unique instance token.
        category: Object category string.
        num_annotations: Total number of annotations for this instance.
        first_annotation_token: Token of the first annotation in temporal order.
        last_annotation_token: Token of the last annotation in temporal order.
    """

    token: str
    category: str
    num_annotations: int
    first_annotation_token: str
    last_annotation_token: str
