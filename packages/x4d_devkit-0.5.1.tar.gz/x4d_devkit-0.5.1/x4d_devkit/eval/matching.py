# x4d_devkit/eval/matching.py
"""Detection matching: accumulate GT/Pred pairs into precision-recall curves."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from x4d_devkit.eval.metrics import (
    center_distance,
    scale_iou,
    yaw_diff,
    attr_acc,
    cummean,
)

NELEM = 101  # Number of recall interpolation points


@dataclass
class MetricData:
    """Interpolated precision, recall, and TP error curves (101 points)."""

    recall: np.ndarray       # (101,)
    precision: np.ndarray    # (101,)
    confidence: np.ndarray   # (101,)
    trans_err: np.ndarray    # (101,)
    scale_err: np.ndarray    # (101,)
    orient_err: np.ndarray   # (101,)
    vel_err: np.ndarray      # (101,)
    attr_err: np.ndarray     # (101,)

    @property
    def max_recall_ind(self) -> int:
        """Index of last non-zero confidence (= max achieved recall point)."""
        non_zero = np.nonzero(self.confidence)[0]
        if len(non_zero) == 0:
            return 0
        return int(non_zero[-1])

    @classmethod
    def no_predictions(cls) -> MetricData:
        """Return a zero-valued MetricData for when there are no predictions."""
        return cls(
            recall=np.linspace(0, 1, NELEM),
            precision=np.zeros(NELEM),
            confidence=np.zeros(NELEM),
            trans_err=np.ones(NELEM),
            scale_err=np.ones(NELEM),
            orient_err=np.ones(NELEM),
            vel_err=np.ones(NELEM),
            attr_err=np.ones(NELEM),
        )


def accumulate(
    gt_boxes: dict[str, list[dict]],
    pred_boxes: dict[str, list[dict]],
    class_name: str,
    dist_th: float,
) -> MetricData:
    """Match predictions to ground truth and compute interpolated curves.

    Args:
        gt_boxes: {sample_token: [box_dict, ...]} — all GT boxes across samples.
        pred_boxes: {sample_token: [box_dict, ...]} — all pred boxes across samples.
        class_name: Class to evaluate (e.g. "car").
        dist_th: Center distance threshold for matching.

    Each box_dict has: translation (3,), size (3,), rotation (4,) [qx,qy,qz,qw],
    category (str), score (float, pred only), velocity (3,) or None, attributes (list[str]).

    Returns:
        MetricData with interpolated curves at 101 recall points.
    """
    # Filter by class
    gt_by_sample: dict[str, list[dict]] = {}
    npos = 0
    for sample_token, boxes in gt_boxes.items():
        class_boxes = [b for b in boxes if b["category"] == class_name]
        gt_by_sample[sample_token] = class_boxes
        npos += len(class_boxes)

    pred_by_sample: dict[str, list[dict]] = {}
    all_preds = []
    for sample_token, boxes in pred_boxes.items():
        class_boxes = [b for b in boxes if b["category"] == class_name]
        class_boxes.sort(key=lambda b: b["score"], reverse=True)
        pred_by_sample[sample_token] = class_boxes
        for i, b in enumerate(class_boxes):
            all_preds.append((b["score"], sample_token, i))

    if npos == 0:
        return MetricData.no_predictions()

    # Sort all predictions globally by score descending
    all_preds.sort(key=lambda x: x[0], reverse=True)

    # Greedy matching
    tp_list = []
    conf_list = []
    match_data = {k: [] for k in ["trans_err", "scale_err", "orient_err", "vel_err", "attr_err"]}
    matched_gt: dict[str, set[int]] = {st: set() for st in gt_by_sample}

    for score, sample_token, pred_idx in all_preds:
        pred = pred_by_sample[sample_token][pred_idx]
        gt_list = gt_by_sample.get(sample_token, [])

        min_dist = float("inf")
        min_gt_idx = -1
        for gt_idx, gt in enumerate(gt_list):
            if gt_idx in matched_gt.get(sample_token, set()):
                continue
            d = center_distance(pred["translation"], gt["translation"])
            if d < min_dist:
                min_dist = d
                min_gt_idx = gt_idx

        is_tp = min_dist < dist_th and min_gt_idx >= 0
        tp_list.append(1 if is_tp else 0)
        conf_list.append(score)

        if is_tp:
            matched_gt[sample_token].add(min_gt_idx)
            gt = gt_list[min_gt_idx]
            match_data["trans_err"].append(center_distance(pred["translation"], gt["translation"]))
            match_data["scale_err"].append(1.0 - scale_iou(pred["size"], gt["size"]))
            period = np.pi if class_name == "barrier" else 2 * np.pi
            match_data["orient_err"].append(yaw_diff(pred["rotation"], gt["rotation"], period=period))
            if pred["velocity"] is not None and gt["velocity"] is not None:
                vel_diff = float(np.linalg.norm(
                    np.asarray(pred["velocity"])[:2] - np.asarray(gt["velocity"])[:2]
                ))
                match_data["vel_err"].append(vel_diff)
            else:
                match_data["vel_err"].append(float("nan"))
            match_data["attr_err"].append(1.0 - attr_acc(gt["attributes"], pred["attributes"]))
        else:
            for key in match_data:
                match_data[key].append(float("nan"))

    # Compute precision / recall
    tp_arr = np.array(tp_list, dtype=float)
    conf_arr = np.array(conf_list, dtype=float)
    tp_cum = np.cumsum(tp_arr)
    fp_cum = np.cumsum(1 - tp_arr)
    precision_raw = tp_cum / (tp_cum + fp_cum)
    recall_raw = tp_cum / npos

    # Interpolate to NELEM recall points
    recall_interp = np.linspace(0, 1, NELEM)
    precision_interp = np.zeros(NELEM)
    confidence_interp = np.zeros(NELEM)

    for i, r in enumerate(recall_interp):
        mask = recall_raw >= r - 1e-10
        if mask.any():
            precision_interp[i] = precision_raw[mask].max()
            confidence_interp[i] = conf_arr[mask].min()

    # Interpolate TP errors using cumulative mean
    tp_metric_interp = {}
    for key in match_data:
        raw = np.array(match_data[key], dtype=float)
        cm = cummean(raw)
        interp = np.ones(NELEM)
        for i, r in enumerate(recall_interp):
            mask = recall_raw >= r - 1e-10
            if mask.any():
                idx = np.where(mask)[0][0]
                interp[i] = cm[idx]
        tp_metric_interp[key] = interp

    return MetricData(
        recall=recall_interp,
        precision=precision_interp,
        confidence=confidence_interp,
        trans_err=tp_metric_interp["trans_err"],
        scale_err=tp_metric_interp["scale_err"],
        orient_err=tp_metric_interp["orient_err"],
        vel_err=tp_metric_interp["vel_err"],
        attr_err=tp_metric_interp["attr_err"],
    )
