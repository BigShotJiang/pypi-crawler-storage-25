"""Pure metric functions for detection evaluation."""

from __future__ import annotations

import numpy as np

from x4d_devkit.core.transform import quat_to_rotation_matrix


def center_distance(
    translation_a: list[float] | np.ndarray,
    translation_b: list[float] | np.ndarray,
) -> float:
    """L2 distance between two 3D points in the XY plane (Z ignored)."""
    a = np.asarray(translation_a, dtype=float)
    b = np.asarray(translation_b, dtype=float)
    return float(np.linalg.norm(a[:2] - b[:2]))


def scale_iou(
    size_a: list[float] | np.ndarray,
    size_b: list[float] | np.ndarray,
) -> float:
    """Axis-aligned scale IoU between two 3D box sizes [l, w, h]."""
    sa = np.asarray(size_a, dtype=float)
    sb = np.asarray(size_b, dtype=float)
    min_s = np.minimum(sa, sb)
    intersection = float(np.prod(min_s))
    vol_a = float(np.prod(sa))
    vol_b = float(np.prod(sb))
    union = vol_a + vol_b - intersection
    if union <= 0:
        return 0.0
    return intersection / union


def quaternion_yaw(quat: list[float] | np.ndarray) -> float:
    """Extract yaw angle from quaternion [qx, qy, qz, qw]."""
    qx, qy, qz, qw = quat[0], quat[1], quat[2], quat[3]
    R = quat_to_rotation_matrix(qx, qy, qz, qw)
    v = R @ np.array([1.0, 0.0, 0.0])
    return float(np.arctan2(v[1], v[0]))


def _angle_diff(x: float, y: float, period: float) -> float:
    """Smallest signed angle difference, respecting periodicity."""
    diff = (x - y + period / 2) % period - period / 2
    if diff > np.pi:
        diff -= period
    return diff


def yaw_diff(
    quat_a: list[float] | np.ndarray,
    quat_b: list[float] | np.ndarray,
    period: float = 2 * np.pi,
) -> float:
    """Absolute yaw angle difference between two quaternions [qx,qy,qz,qw]."""
    yaw_a = quaternion_yaw(quat_a)
    yaw_b = quaternion_yaw(quat_b)
    return abs(_angle_diff(yaw_a, yaw_b, period))


def attr_acc(
    gt_attrs: list[str],
    pred_attrs: list[str],
) -> float:
    """Attribute classification accuracy. Returns NaN if either is empty."""
    if not gt_attrs or not pred_attrs:
        return float("nan")
    return 1.0 if gt_attrs[0] == pred_attrs[0] else 0.0


def cummean(arr: np.ndarray) -> np.ndarray:
    """NaN-aware cumulative mean. Returns ones if all NaN."""
    mask = ~np.isnan(arr)
    count = np.cumsum(mask).astype(float)
    count[count == 0] = 1.0
    filled = np.where(mask, arr, 0.0)
    result = np.cumsum(filled) / count
    if not mask.any():
        return np.ones_like(arr)
    return result
