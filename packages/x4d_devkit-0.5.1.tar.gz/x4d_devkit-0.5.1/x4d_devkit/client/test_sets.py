"""Test sets API wrapper — benchmark clip selections managed by the platform.

Test sets are the platform's way of claiming "these clips are the benchmark:
don't train on them, don't let experiments move them". See the platform
CLAUDE.md section on Benchmark Architecture for the design rationale.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from x4d_devkit.client.client import X4DClient


class TestSetsAPI:
    def __init__(self, client: "X4DClient"):
        self._client = client

    def create(
        self,
        project_id: int,
        name: str,
        clip_ids: list[str],
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict:
        """Create or replace a test set.

        Idempotent on (project_id, name): re-calling with the same name
        replaces the clip_ids list. Treat that as version replacement, not
        in-place mutation — if you want to keep the old list, start a new
        name (`v1` → `v2`).
        """
        return self._client.post(
            "/test-sets",
            json={
                "project_id": project_id,
                "name": name,
                "description": description,
                "clip_ids": clip_ids,
                "metadata": metadata or {},
            },
        )

    def list(self, project_id: int) -> list[dict]:
        """List all test sets for a project."""
        resp = self._client.get(f"/projects/{project_id}/test-sets")
        return resp["items"]

    def list_test_clip_ids(self, project_id: int) -> list[str]:
        """Return the union of clip_ids across every test set in the project.

        A clip is test-marked if it appears in at least one set. Training
        pipelines use this (indirectly via ``clips.list_all(exclude_test=True)``)
        to avoid training on benchmark data.
        """
        return self._client.get(f"/projects/{project_id}/test-clip-ids")

    def get(self, test_set_id: int) -> dict:
        return self._client.get(f"/test-sets/{test_set_id}")

    def delete(self, test_set_id: int) -> None:
        self._client.delete(f"/test-sets/{test_set_id}")
