"""Checkpoints API wrapper — training project registers its trained models
so the platform's Model Compare view can run inference on them.

This is the primary integration point between a training project and the
platform: after every epoch the training CLI calls ``register(...)`` and
the checkpoint immediately shows up in Compare's dropdown.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from x4d_devkit.client.client import X4DClient


class CheckpointsAPI:
    def __init__(self, client: "X4DClient"):
        self._client = client

    def register(
        self,
        project_id: int,
        name: str,
        service_id: str,
        ckpt_uri: str,
        metadata: dict[str, Any] | None = None,
    ) -> dict:
        """Register a trained checkpoint for inference.

        Idempotent on (project_id, service_id, ckpt_uri) — re-calling with
        the same arguments updates name/metadata instead of creating a dup.

        Args:
            project_id: X-4D project the checkpoint belongs to.
            name: Human-readable name, e.g. ``"exp_hg1_v1 · epoch 5"``.
            service_id: The ``service_id`` of the training/inference service
                that owns the checkpoint file (must be registered with the
                platform, otherwise inference dispatch will 404).
            ckpt_uri: Local path to the .pth file *on the service container*.
                Remote/S3 URIs are not yet supported.
            metadata: Arbitrary JSONB bag. By convention keys used by the
                inference backend are ``cfg_file``, ``epoch``, ``is_best``,
                ``training_task_id``.
        """
        return self._client.post(
            "/checkpoints",
            json={
                "project_id": project_id,
                "name": name,
                "service_id": service_id,
                "ckpt_uri": ckpt_uri,
                "metadata": metadata or {},
            },
        )

    def list(self, project_id: int) -> list[dict]:
        resp = self._client.get(f"/projects/{project_id}/checkpoints")
        return resp["items"]

    def get(self, checkpoint_id: int) -> dict:
        return self._client.get(f"/checkpoints/{checkpoint_id}")

    def delete(self, checkpoint_id: int) -> None:
        self._client.delete(f"/checkpoints/{checkpoint_id}")
