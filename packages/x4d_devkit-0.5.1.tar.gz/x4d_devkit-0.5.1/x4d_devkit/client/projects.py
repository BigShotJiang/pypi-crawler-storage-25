"""Projects API wrapper."""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from x4d_devkit.client.client import X4DClient


class ProjectsAPI:
    def __init__(self, client: X4DClient):
        self._client = client

    def list(
        self, page: int = 1, page_size: int = 50, search: str | None = None
    ) -> dict:
        """List all projects."""
        params = {"page": page, "page_size": page_size}
        if search:
            params["search"] = search
        return self._client.get("/projects", params=params)

    def get(self, project_id: int) -> dict:
        """Get a project by ID."""
        return self._client.get(f"/projects/{project_id}")

    def list_annotation_classes(self, project_id: int) -> list[dict]:
        """List the annotation class definitions configured for a project.

        Each item has ``{id, label, color, shortcut?, default_size?}``. The
        platform returns raw labels as configured — no simplification, no
        mapping. The training project owns its own `class_mapping:` in its
        experiment yaml and maps these to its model's class space.
        """
        resp = self._client.get(f"/projects/{project_id}/annotation-classes")
        return resp.get("classes", [])
