"""X-4D DevKit CLI."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def cmd_projects_list(args):
    from x4d_devkit.client import X4DClient

    with X4DClient(base_url=args.base_url) as client:
        resp = client.projects.list()
        for p in resp["items"]:
            print(f"  [{p['id']}] {p['name']} — {p.get('clip_count', '?')} clips")


def cmd_clips_list(args):
    from x4d_devkit.client import X4DClient

    with X4DClient(base_url=args.base_url) as client:
        resp = client.clips.list(
            project_id=args.project_id,
            page_size=args.page_size,
            lifecycle=args.lifecycle,
            has_archive=args.has_archive,
        )
        print(f"Total: {resp['total']} clips (showing page {resp['page']})")
        for c in resp["items"]:
            status = c.get("lifecycle", "?")
            kf = (
                c.get("statistics", {}).get("keyframe_count", "?")
                if c.get("statistics")
                else "?"
            )
            print(f"  {c['clip_id']}  [{status}]  {kf} keyframes")


def cmd_clips_download(args):
    from x4d_devkit.client import X4DClient

    with X4DClient(base_url=args.base_url, timeout=600.0) as client:
        # Read clip IDs from file or comma-separated
        if Path(args.clip_ids).exists():
            clip_ids = Path(args.clip_ids).read_text().strip().splitlines()
        else:
            clip_ids = args.clip_ids.split(",")
        clip_ids = [cid.strip() for cid in clip_ids if cid.strip()]

        print(f"Downloading {len(clip_ids)} clips to {args.output}...")

        def on_progress(clip_id, i, total):
            print(f"  [{i}/{total}] {clip_id} done")

        paths = client.clips.download_tars(
            clip_ids=clip_ids,
            output_dir=args.output,
            workers=args.workers,
            on_progress=on_progress,
        )
        print(f"Downloaded {len(paths)} clips successfully")


def cmd_validate(args):
    from x4d_devkit.validation import validate_clip

    target = Path(args.path)

    if (target / "meta.json").exists():
        # Single clip directory
        report = validate_clip(target)
        print(report)
        sys.exit(0 if report.ok else 1)
    else:
        # Directory of clips
        all_ok = True
        for clip_dir in sorted(target.iterdir()):
            if clip_dir.is_dir() and (clip_dir / "meta.json").exists():
                report = validate_clip(clip_dir)
                print(report)
                if not report.ok:
                    all_ok = False
        sys.exit(0 if all_ok else 1)


def main():
    parser = argparse.ArgumentParser(prog="x4d", description="X-4D DevKit CLI")
    parser.add_argument(
        "--base-url", default="http://localhost:8000", help="Platform API URL"
    )
    sub = parser.add_subparsers(dest="command")

    # projects list
    p_proj = sub.add_parser("projects", help="Project operations")
    p_proj_sub = p_proj.add_subparsers(dest="subcommand")
    p_proj_list = p_proj_sub.add_parser("list", help="List projects")
    p_proj_list.set_defaults(func=cmd_projects_list)

    # clips list
    p_clips = sub.add_parser("clips", help="Clip operations")
    p_clips_sub = p_clips.add_subparsers(dest="subcommand")

    p_clips_list = p_clips_sub.add_parser("list", help="List clips")
    p_clips_list.add_argument("--project-id", type=int, required=True)
    p_clips_list.add_argument("--page-size", type=int, default=20)
    p_clips_list.add_argument("--lifecycle", type=str, default=None)
    p_clips_list.add_argument("--has-archive", type=bool, default=None)
    p_clips_list.set_defaults(func=cmd_clips_list)

    p_clips_dl = p_clips_sub.add_parser("download", help="Download clip tar archives")
    p_clips_dl.add_argument(
        "--clip-ids", required=True, help="Comma-separated IDs or path to file"
    )
    p_clips_dl.add_argument("--output", required=True, help="Output directory")
    p_clips_dl.add_argument("--workers", type=int, default=4)
    p_clips_dl.set_defaults(func=cmd_clips_download)

    # validate
    p_val = sub.add_parser("validate", help="Validate clip directory")
    p_val.add_argument("path", help="Clip directory or parent directory")
    p_val.set_defaults(func=cmd_validate)

    args = parser.parse_args()
    if not hasattr(args, "func"):
        parser.print_help()
        sys.exit(1)
    args.func(args)


if __name__ == "__main__":
    main()
