"""Validation report dataclass."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ValidationIssue:
    """A single validation issue found during clip validation.

    Attributes:
        check: Check category (e.g. "json_exists", "lidar_format", "annotation_bbox").
        level: Severity — "error" (blocks usage) or "warning" (non-critical).
        message: Human-readable description of the issue.
        detail: Additional detail (e.g. file path, exception message).
    """

    check: str
    level: str  # "error" or "warning"
    message: str
    detail: str = ""


@dataclass
class ValidationReport:
    """Result of validating a clip directory.

    Attributes:
        clip_id: The clip identifier.
        issues: List of validation issues found.
        ok: True if no errors (warnings are allowed).
        errors: List of error-level issues.
        warnings: List of warning-level issues.
    """

    clip_id: str
    issues: list[ValidationIssue] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        """True if validation passed (no errors, warnings are OK)."""
        return not any(i.level == "error" for i in self.issues)

    @property
    def errors(self) -> list[ValidationIssue]:
        """All error-level issues."""
        return [i for i in self.issues if i.level == "error"]

    @property
    def warnings(self) -> list[ValidationIssue]:
        """All warning-level issues."""
        return [i for i in self.issues if i.level == "warning"]

    def __str__(self) -> str:
        status = "PASS" if self.ok else "FAIL"
        lines = [
            f"[{status}] {self.clip_id}: {len(self.errors)} errors, {len(self.warnings)} warnings"
        ]
        for issue in self.issues:
            prefix = "ERROR" if issue.level == "error" else "WARN"
            lines.append(f"  [{prefix}] {issue.check}: {issue.message}")
            if issue.detail:
                lines.append(f"           {issue.detail}")
        return "\n".join(lines)
