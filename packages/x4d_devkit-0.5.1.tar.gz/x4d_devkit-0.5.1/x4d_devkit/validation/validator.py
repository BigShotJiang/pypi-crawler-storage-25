"""Clip directory validation."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from x4d_devkit.validation.report import ValidationReport, ValidationIssue

REQUIRED_JSON_FILES = [
    "meta.json",
    "calibrated_sensor.json",
    "ego_pose.json",
    "sample.json",
    "sample_data.json",
    "annotation.json",
    "instance.json",
]

KNOWN_CATEGORIES = {
    "car",
    "truck",
    "bus",
    "trailer",
    "construction_vehicle",
    "pedestrian",
    "motorcycle",
    "bicycle",
    "vehicle.car",
    "vehicle.truck",
    "vehicle.bus.bendy",
    "vehicle.bus.rigid",
    "vehicle.trailer",
    "vehicle.construction",
    "human.pedestrian.adult",
    "human.pedestrian.child",
    "human.pedestrian.construction_worker",
    "human.pedestrian.police_officer",
    "vehicle.motorcycle",
    "vehicle.bicycle",
    "traffic_cone",
    "barrier",
    "movable_object.barrier",
    "movable_object.trafficcone",
    "movable_object.pushable_pullable",
    "movable_object.debris",
    "static_object.bicycle_rack",
}


def validate_clip(clip_dir: str | Path) -> ValidationReport:
    """Validate an X-4D clip directory for completeness and correctness.

    Checks:
        1. All required JSON files exist and parse correctly.
        2. LiDAR binary files exist and have valid format.
        3. Ego pose references are valid.
        4. Annotation integrity (categories, bbox dimensions, references).
        5. Prev/next chain integrity for samples.

    Args:
        clip_dir: Path to the clip directory (must contain meta.json).

    Returns:
        ValidationReport with errors and warnings. Use ``report.ok`` to
        check if validation passed (no errors).

    Example::

        report = validate_clip("/data/clips/my_clip")
        if report.ok:
            print("Validation passed!")
        else:
            for err in report.errors:
                print(f"  {err.check}: {err.message}")
    """
    clip_dir = Path(clip_dir)

    # Try to get clip_id from meta.json, fallback to directory name
    clip_id = clip_dir.name
    issues: list[ValidationIssue] = []
    jsons: dict[str, any] = {}

    # 1. Check JSON files exist and parse
    for fname in REQUIRED_JSON_FILES:
        path = clip_dir / fname
        if not path.exists():
            issues.append(
                ValidationIssue("json_exists", "error", f"Missing {fname}")
            )
            continue
        try:
            with open(path) as f:
                jsons[fname] = json.load(f)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            issues.append(
                ValidationIssue("json_parse", "error", f"Cannot parse {fname}", str(e))
            )

    if "meta.json" in jsons:
        clip_id = jsons["meta.json"].get("clip_id", clip_id)

    # If we can't parse essential files, return early
    if "sample.json" not in jsons or "sample_data.json" not in jsons:
        return ValidationReport(clip_id=clip_id, issues=issues)

    # 2. Build indices
    samples = jsons["sample.json"]
    sample_data = jsons["sample_data.json"]
    ego_poses = jsons.get("ego_pose.json", [])
    annotations = jsons.get("annotation.json", [])
    instances = jsons.get("instance.json", [])

    sample_tokens = {s["sample_token"] for s in samples}
    ego_pose_tokens = {ep["ego_pose_token"] for ep in ego_poses}
    instance_tokens = {inst["instance_token"] for inst in instances}

    # 3. LiDAR file completeness
    # Find lidar keyframe sample_data records
    lidar_sds = [
        sd
        for sd in sample_data
        if sd.get("is_keyframe") and "LIDAR" in sd.get("channel", "").upper()
    ]

    for sd in lidar_sds:
        file_path = clip_dir / sd["file_path"]
        if not file_path.exists():
            issues.append(
                ValidationIssue(
                    "lidar_exists",
                    "error",
                    f"Missing LiDAR file: {sd['file_path']}",
                )
            )
            continue
        # Check format
        try:
            raw = np.fromfile(str(file_path), dtype=np.float32)
            if raw.size == 0:
                issues.append(
                    ValidationIssue(
                        "lidar_format",
                        "error",
                        f"Empty point cloud: {sd['file_path']}",
                    )
                )
            elif raw.size % 5 != 0:
                # Try other common strides
                valid = False
                for stride in [3, 4, 6]:
                    if raw.size % stride == 0:
                        valid = True
                        break
                if not valid:
                    issues.append(
                        ValidationIssue(
                            "lidar_format",
                            "warning",
                            f"Point cloud size {raw.size} not divisible by expected stride",
                            sd["file_path"],
                        )
                    )
        except Exception as e:
            issues.append(
                ValidationIssue(
                    "lidar_format",
                    "error",
                    f"Cannot read point cloud: {sd['file_path']}",
                    str(e),
                )
            )

    if not lidar_sds:
        issues.append(
            ValidationIssue("lidar_exists", "error", "No LiDAR keyframe data found")
        )

    # 4. Ego pose coverage
    for sd in lidar_sds:
        if sd.get("ego_pose_token") and sd["ego_pose_token"] not in ego_pose_tokens:
            issues.append(
                ValidationIssue(
                    "ego_pose_ref",
                    "error",
                    f"sample_data references missing ego_pose: {sd['ego_pose_token']}",
                )
            )

    # 5. Annotation integrity
    for ann in annotations:
        # Category check
        cat = ann.get("category", "")
        if cat not in KNOWN_CATEGORIES:
            issues.append(
                ValidationIssue(
                    "annotation_category",
                    "warning",
                    f"Unknown category: {cat}",
                    ann.get("annotation_token", ""),
                )
            )

        # Bbox dimensions
        bbox = ann.get("bbox_3d", {})
        size = bbox.get("size", {})
        for dim in ["length", "width", "height"]:
            val = size.get(dim, 0)
            if not isinstance(val, (int, float)) or val <= 0 or not np.isfinite(val):
                issues.append(
                    ValidationIssue(
                        "annotation_bbox",
                        "error",
                        f"Invalid bbox {dim}={val}",
                        ann.get("annotation_token", ""),
                    )
                )
                break

        # num_lidar_pts must be a non-negative integer (v0.5+: real-computed,
        # 0 means "no points in box", not a default placeholder).
        npts = ann.get("num_lidar_pts")
        if not isinstance(npts, int) or isinstance(npts, bool) or npts < 0:
            issues.append(
                ValidationIssue(
                    "annotation_num_lidar_pts",
                    "error",
                    f"Invalid num_lidar_pts={npts!r} (must be int >= 0)",
                    ann.get("annotation_token", ""),
                )
            )

        # Sample token reference
        if ann.get("sample_token") not in sample_tokens:
            issues.append(
                ValidationIssue(
                    "annotation_ref",
                    "error",
                    f"Annotation references missing sample: {ann.get('sample_token')}",
                )
            )

        # Instance token reference
        if ann.get("instance_token") and ann["instance_token"] not in instance_tokens:
            issues.append(
                ValidationIssue(
                    "annotation_ref",
                    "error",
                    f"Annotation references missing instance: {ann.get('instance_token')}",
                )
            )

    # 6. Prev/next chain integrity for samples
    for s in samples:
        if s.get("prev") and s["prev"] not in sample_tokens:
            issues.append(
                ValidationIssue(
                    "chain_integrity",
                    "warning",
                    f"Sample prev token not found: {s['prev']}",
                )
            )
        if s.get("next") and s["next"] not in sample_tokens:
            issues.append(
                ValidationIssue(
                    "chain_integrity",
                    "warning",
                    f"Sample next token not found: {s['next']}",
                )
            )

    return ValidationReport(clip_id=clip_id, issues=issues)
