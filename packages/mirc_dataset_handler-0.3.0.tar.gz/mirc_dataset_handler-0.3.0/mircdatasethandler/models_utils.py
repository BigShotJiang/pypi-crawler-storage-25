import segmentation_models_pytorch as smp

def get_model(model_name, backbone):
    if model_name == "Unet":
        model = smp.Unet(
            encoder_name=backbone,  
            encoder_weights="imagenet",    
            in_channels=3,                 
            classes=3                      
        )
    elif model_name == "FPN":
        model = smp.FPN(
            encoder_name=backbone,
            encoder_weights="imagenet",
            in_channels=3,
            classes=3
        )
    elif model_name == "DeepLabV3":
        model = smp.DeepLabV3(
            encoder_name=backbone,
            encoder_weights="imagenet",
            in_channels=3,
            classes=3
        )
    elif model_name == "MAnet":
        model = smp.MAnet(
            encoder_name=backbone,
            encoder_weights="imagenet",
            in_channels=3,
            classes=3
        )
    elif model_name == "PAN":
        model = smp.PAN(
            encoder_name=backbone,
            encoder_weights="imagenet",
            in_channels=3,
            classes=3
        )
    else:
        raise ValueError(f"Modelo {model_name} não é suportado.")
    
    return model