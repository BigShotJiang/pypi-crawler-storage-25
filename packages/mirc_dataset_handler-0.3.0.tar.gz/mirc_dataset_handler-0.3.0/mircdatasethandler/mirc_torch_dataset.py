import numpy as np
from PIL import Image
from cv2 import fillPoly as cv2_fillPoly
from torch import from_numpy as torch_from_numpy
from torch.utils.data import Dataset


class MIRCTorchDataset(Dataset):
    def __init__(self, dataset_partitions, transform=None, mask_mode=None, target_size=(256, 256)):
        if isinstance(dataset_partitions, dict):
            dataset_partitions = [dataset_partitions]

        self.dataset_partitions = dataset_partitions
        self.transform = transform
        self.mask_mode = mask_mode
        self.target_width = target_size[0]
        self.target_height = target_size[1]
        self.sample_index = []

        for partition_index, partition in enumerate(self.dataset_partitions):
            for key in partition.keys():
                self.sample_index.append((partition_index, key))

    def __len__(self):
        return len(self.sample_index)

    def __getitem__(self, idx):
        partition_index, sample_key = self.sample_index[idx]
        sample = self.dataset_partitions[partition_index][sample_key]

        image_nd = self.__load_image(sample["image_path"])
        mask_human, mask_robot = self.__build_binary_masks(sample)
        mask_nd = self.__transform_masks(mask_human, mask_robot)

        image_chw = image_nd.transpose((2, 0, 1)).astype(np.float32) / 255.0

        return {
            "image": torch_from_numpy(image_chw).float(),
            "mask": torch_from_numpy(mask_nd).long()
        }

    def __load_image(self, image_path):
        with Image.open(image_path) as image:
            image = image.convert("RGB")
            image = image.resize((self.target_width, self.target_height), Image.BILINEAR)
            image_nd = np.array(image, dtype=np.uint8)

        return image_nd

    def __build_binary_masks(self, sample):
        mask_human = np.zeros((self.target_height, self.target_width), dtype=np.uint8)
        mask_robot = np.zeros((self.target_height, self.target_width), dtype=np.uint8)

        image_width = sample["image_width"]
        image_height = sample["image_height"]

        scale_x = self.target_width / image_width
        scale_y = self.target_height / image_height

        for obj in sample["objects"]:
            label = obj["label"]
            points = obj["points"]

            if not points:
                continue

            polygon = self.__scale_polygon(points, scale_x, scale_y)

            if polygon is None or len(polygon) == 0:
                continue

            if label == "person":
                cv2_fillPoly(mask_human, [polygon], 1)
            elif label == "robot":
                cv2_fillPoly(mask_robot, [polygon], 1)

        return mask_human, mask_robot

    def __scale_polygon(self, points, scale_x, scale_y):
        polygon = np.array(points, dtype=np.float32)

        if polygon.ndim != 2 or polygon.shape[0] == 0 or polygon.shape[1] != 2:
            return None

        polygon[:, 0] = polygon[:, 0] * scale_x
        polygon[:, 1] = polygon[:, 1] * scale_y

        polygon = np.rint(polygon).astype(np.int32)

        polygon[:, 0] = np.clip(polygon[:, 0], 0, self.target_width - 1)
        polygon[:, 1] = np.clip(polygon[:, 1], 0, self.target_height - 1)

        return polygon

    def __transform_masks(self, mask_human, mask_robot):
        mask_human = np.where(mask_human > 0, 1, 0).astype(np.uint8)
        mask_robot = np.where(mask_robot > 0, 1, 0).astype(np.uint8)

        if self.mask_mode == "entropy":
            mask = np.where(mask_robot == 1, 2, mask_human).astype(np.uint8)
        else:
            mask = np.zeros_like(mask_human, dtype=np.uint8)
            mask[mask_human == 1] = 1
            mask[mask_robot == 1] = 2

        return mask