import os, numpy, pandas, torch

def save_checkpoint(model, optimizer, epoch, fold, is_best, checkpoint_dir, best_val_loss=None, is_finetune=False):
    if fold == "":
        fold_dir = checkpoint_dir
    else:
        fold_dir = os.path.join(checkpoint_dir, f"fold{fold+1}")
    os.makedirs(fold_dir, exist_ok=True)

    last_checkpoint_path = os.path.join(fold_dir, "last_training_loss.pth")

    payload = dict()
    if not is_finetune:
        payload = {
            'epoch': epoch,
            'fold': fold,
            'model_state_dict': model.state_dict()
        }
    else:
        payload = {
            'model_state_dict': model.state_dict()
        }

    if best_val_loss is not None:
        payload['best_val_loss'] = float(best_val_loss)

    torch.save(payload, last_checkpoint_path)

    if is_best:
        best_checkpoint_path = os.path.join(fold_dir, "best_val_loss.pth")
        torch.save(payload, best_checkpoint_path)


def save_metrics_to_csv(loss_train, loss_val, metrics_val, checkpoint_dir, fold, epoch, num_classes=3):
    os.makedirs(checkpoint_dir, exist_ok=True)

    if metrics_val is None or len(metrics_val) == 0:
        data = {
            'epoch': epoch,
            'loss_train': float(loss_train),
            'loss_val': float(loss_val),
            'avg_dice_val': numpy.nan,
            'avg_iou_val': numpy.nan,
        }
        for c in range(num_classes):
            data[f'dice_class_{c}_val'] = numpy.nan
            data[f'iou_class_{c}_val'] = numpy.nan
    else:
        mean_dice_val, mean_iou_val, dice_per_class_val, iou_per_class_val = zip(*metrics_val)

        avg_dice_val = float(numpy.nanmean(mean_dice_val))
        avg_iou_val  = float(numpy.nanmean(mean_iou_val))

        data = {
            'epoch': int(epoch),
            'loss_train': float(loss_train),
            'loss_val': float(loss_val),
            'avg_dice_val': avg_dice_val,
            'avg_iou_val': avg_iou_val,
        }

        for c in range(num_classes):
            data[f'dice_class_{c}_val'] = float(numpy.nanmean([d[c] for d in dice_per_class_val]))
            data[f'iou_class_{c}_val']  = float(numpy.nanmean([i[c] for i in iou_per_class_val]))

    metrics_df = pandas.DataFrame([data])

    csv_path = os.path.join(checkpoint_dir, f"fold{fold+1}_report.csv")
    if not os.path.isfile(csv_path):
        metrics_df.to_csv(csv_path, index=False)
    else:
        metrics_df.to_csv(csv_path, mode='a', header=False, index=False)