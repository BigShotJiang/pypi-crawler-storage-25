"""Architecture constraint tests — prevent dependency violations between packages."""

import ast
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent

CLI_PKG = ROOT / "ppclaw_cli"
SRV_PKG = ROOT / "ppclaw_server"


def _collect_imports(filepath: pathlib.Path) -> list[str]:
    """Return all imported module names from a Python file."""
    source = filepath.read_text()
    tree = ast.parse(source, filename=str(filepath))
    modules: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                modules.append(alias.name)
        elif isinstance(node, ast.ImportFrom) and node.module:
            modules.append(node.module)
    return modules


def _py_files(pkg: pathlib.Path) -> list[pathlib.Path]:
    return sorted(pkg.rglob("*.py"))


# --- Constraint 1: CLI must not import from ppclaw_server ---


def test_cli_does_not_import_server():
    """CLI package communicates with the server via HTTP, not direct imports."""
    violations = []
    for py in _py_files(CLI_PKG):
        for mod in _collect_imports(py):
            if mod.startswith("ppclaw_server"):
                violations.append(f"{py.relative_to(ROOT)}: imports {mod}")
    assert not violations, "CLI must not import server internals:\n" + "\n".join(violations)


# --- Constraint 2: Server routes must not import each other ---


def test_server_routes_do_not_cross_import():
    """Each route module should be independent; shared logic goes in _helpers."""
    routes_dir = SRV_PKG / "routes"
    if not routes_dir.exists():
        return
    route_modules = {
        f.stem for f in routes_dir.glob("*.py") if f.stem not in ("__init__", "_helpers")
    }
    # Build fully-qualified names for sibling route modules
    routes_fq = {f"ppclaw_server.routes.{name}" for name in route_modules}
    violations = []
    for py in routes_dir.glob("*.py"):
        if py.stem in ("__init__", "_helpers"):
            continue
        source = py.read_text()
        tree = ast.parse(source, filename=str(py))
        for node in ast.walk(tree):
            # Only catch direct sibling imports: from .gateway import X
            # Not parent imports: from ..services import X
            if isinstance(node, ast.ImportFrom) and node.module:
                # Relative imports: level=1 means "from .X", level=2 means "from ..X"
                if node.level == 1 and node.module in route_modules and node.module != py.stem:
                    violations.append(f"routes/{py.name}: imports sibling route .{node.module}")
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    own_fq = f"ppclaw_server.routes.{py.stem}"
                    if alias.name in routes_fq and alias.name != own_fq:
                        violations.append(f"routes/{py.name}: imports sibling route {alias.name}")
    assert not violations, "Route modules must not cross-import:\n" + "\n".join(violations)


# --- Constraint 3: const.py must not import from its own package ---


def test_const_is_leaf_module():
    """const.py should only depend on stdlib — it must not import sibling modules."""
    for pkg in (CLI_PKG, SRV_PKG):
        const_file = pkg / "const.py"
        if not const_file.exists():
            continue
        pkg_name = pkg.name
        for mod in _collect_imports(const_file):
            if mod.startswith(pkg_name) and mod != pkg_name:
                # Allow importing from the package itself (e.g. `from . import __version__`)
                # but not sibling modules like `from .output import ...`
                parts = mod.split(".")
                if len(parts) > 1 and parts[1] not in ("__init__", "__version__"):
                    raise AssertionError(
                        f"{const_file.relative_to(ROOT)}: imports {mod} "
                        "(const.py must be a leaf module)"
                    )
