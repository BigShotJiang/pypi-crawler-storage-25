"""HTTP client for the API Server."""

import httpx

from .output import (
    EXIT_API_ERROR,
    EXIT_CHANNEL_CONFIG_FAILED,
    EXIT_CONFIG_FAILED,
    EXIT_DEVICE_FAILED,
    EXIT_DOCTOR_FAILED,
    EXIT_GATEWAY_FAILED,
    EXIT_GATEWAY_TIMEOUT,
    EXIT_GATEWAY_UPDATE_FAILED,
    EXIT_MISSING_API_KEY,
    EXIT_NODE_FAILED,
    EXIT_PAIRING_FAILED,
    EXIT_SANDBOX_CONNECT,
    EXIT_SANDBOX_CREATE,
    EXIT_SANDBOX_PAUSE_FAILED,
    EXIT_SANDBOX_RESUME_FAILED,
    EXIT_SERVICE_CONFIG_FAILED,
    CLIError,
)

# Map server error_code → CLI exit_code for backward compatibility
_ERROR_CODE_TO_EXIT = {
    "MISSING_API_KEY": EXIT_MISSING_API_KEY,
    "SANDBOX_CREATE_FAILED": EXIT_SANDBOX_CREATE,
    "SANDBOX_CONNECT_FAILED": EXIT_SANDBOX_CONNECT,
    "GATEWAY_TIMEOUT": EXIT_GATEWAY_TIMEOUT,
    "GATEWAY_FAILED": EXIT_GATEWAY_FAILED,
    "GATEWAY_UPDATE_FAILED": EXIT_GATEWAY_UPDATE_FAILED,
    "NODE_START_FAILED": EXIT_NODE_FAILED,
    "DOCTOR_FAILED": EXIT_DOCTOR_FAILED,
    "SERVICE_CONFIG_FAILED": EXIT_SERVICE_CONFIG_FAILED,
    "PAIRING_FAILED": EXIT_PAIRING_FAILED,
    "DEVICE_FAILED": EXIT_DEVICE_FAILED,
    "SANDBOX_PAUSE_FAILED": EXIT_SANDBOX_PAUSE_FAILED,
    "SANDBOX_RESUME_FAILED": EXIT_SANDBOX_RESUME_FAILED,
    "CONFIG_FAILED": EXIT_CONFIG_FAILED,
    "CHANNEL_CONFIG_FAILED": EXIT_CHANNEL_CONFIG_FAILED,
}


class APIClient:
    """HTTP client for the API Server."""

    def __init__(self, server_url: str, api_key: str):
        self._base = server_url.rstrip("/")
        self._client = httpx.Client(
            timeout=600,
            headers={"Authorization": "Bearer {key}".format(key=api_key)},
        )

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """Send request and return parsed JSON. Raise CLIError on error responses."""
        url = "{base}{path}".format(base=self._base, path=path)
        response = self._client.request(method, url, **kwargs)

        try:
            data = response.json()
        except Exception as exc:
            if response.status_code >= 400:
                raise CLIError(
                    "Server returned HTTP {code}".format(code=response.status_code),
                    "HTTP_ERROR",
                    EXIT_API_ERROR,
                ) from exc
            raise CLIError("Server returned non-JSON response", "HTTP_ERROR", 1) from exc

        if data.get("status") == "error":
            error_code = data.get("error_code", "UNKNOWN")
            message = data.get("message", "Unknown error")
            exit_code = _ERROR_CODE_TO_EXIT.get(error_code, 1)
            raise CLIError(message, error_code, exit_code)

        if response.status_code >= 400:
            raise CLIError(
                "Server returned HTTP {code}".format(code=response.status_code),
                "HTTP_ERROR",
                1,
            )

        return data

    # --- Sandbox operations ---

    def launch(
        self,
        timeout: int = 180,
        template_id: str = None,
        mode: str = "gateway",
        display_name: str = None,
        sandbox_type: str = "always-on",
        idle_timeout: int = None,
    ) -> dict:
        body = {"timeout": timeout, "mode": mode, "sandbox_type": sandbox_type}
        if template_id:
            body["template_id"] = template_id
        if display_name:
            body["display_name"] = display_name
        if idle_timeout is not None:
            body["idle_timeout"] = idle_timeout
        return self._request("POST", "/sandboxes", json=body)

    def node_connect(
        self,
        sandbox_id: str,
        gateway_url: str,
        gateway_token: str = None,
    ) -> dict:
        body = {"gateway_url": gateway_url}
        if gateway_token:
            body["gateway_token"] = gateway_token
        return self._request(
            "POST", "/sandboxes/{id}/node/connect".format(id=sandbox_id), json=body
        )

    def node_reconnect(
        self,
        sandbox_id: str,
        gateway_url: str,
        gateway_token: str = None,
    ) -> dict:
        body = {"gateway_url": gateway_url}
        if gateway_token:
            body["gateway_token"] = gateway_token
        return self._request(
            "POST", "/sandboxes/{id}/node/reconnect".format(id=sandbox_id), json=body
        )

    def node_status(self, sandbox_id: str, gateway_url: str) -> dict:
        return self._request(
            "GET",
            "/sandboxes/{id}/node/status".format(id=sandbox_id),
            params={"gateway_url": gateway_url},
        )

    def node_disconnect(self, sandbox_id: str) -> dict:
        return self._request("POST", "/sandboxes/{id}/node/disconnect".format(id=sandbox_id))

    def list_sandboxes(self) -> dict:
        return self._request("GET", "/sandboxes")

    def status(self, sandbox_id: str) -> dict:
        return self._request("GET", "/sandboxes/{id}".format(id=sandbox_id))

    def pause(self, sandbox_id: str) -> dict:
        return self._request("POST", "/sandboxes/{id}/pause".format(id=sandbox_id))

    def resume(self, sandbox_id: str) -> dict:
        return self._request("POST", "/sandboxes/{id}/resume".format(id=sandbox_id))

    def stop(self, sandbox_id: str) -> dict:
        return self._request("DELETE", "/sandboxes/{id}".format(id=sandbox_id))

    # --- Gateway operations ---

    def gateway_start(self, sandbox_id: str) -> dict:
        return self._request("POST", "/sandboxes/{id}/gateway/start".format(id=sandbox_id))

    def gateway_stop(self, sandbox_id: str) -> dict:
        return self._request("POST", "/sandboxes/{id}/gateway/stop".format(id=sandbox_id))

    def gateway_restart(self, sandbox_id: str) -> dict:
        return self._request("POST", "/sandboxes/{id}/gateway/restart".format(id=sandbox_id))

    def gateway_update(self, sandbox_id: str) -> dict:
        return self._request("POST", "/sandboxes/{id}/gateway/update".format(id=sandbox_id))

    def gateway_doctor(self, sandbox_id: str, **flags) -> dict:
        params = {k: "true" for k, v in flags.items() if v}
        return self._request(
            "GET",
            "/sandboxes/{id}/gateway/doctor".format(id=sandbox_id),
            params=params,
        )

    # --- Services operations ---

    def services_setup(self, sandbox_id: str) -> dict:
        return self._request("POST", "/sandboxes/{id}/services/setup".format(id=sandbox_id))

    def services_list(self, sandbox_id: str) -> dict:
        return self._request("GET", "/sandboxes/{id}/services".format(id=sandbox_id))

    # --- Device operations (gateway-side node pairing) ---

    def devices_list(self, sandbox_id: str, json: bool = False) -> dict:
        params = {"json": "true"} if json else {}
        return self._request("GET", "/sandboxes/{id}/devices".format(id=sandbox_id), params=params)

    def devices_approve(self, sandbox_id: str, request_id: str = None) -> dict:
        body = {}
        if request_id:
            body["request_id"] = request_id
        return self._request(
            "POST", "/sandboxes/{id}/devices/approve".format(id=sandbox_id), json=body
        )

    # --- Pairing operations ---

    def pairing_list(self, sandbox_id: str, channel: str) -> dict:
        return self._request(
            "GET",
            "/sandboxes/{id}/pairing".format(id=sandbox_id),
            params={"channel": channel},
        )

    def pairing_approve(self, sandbox_id: str, channel: str, code: str) -> dict:
        return self._request(
            "POST",
            "/sandboxes/{id}/pairing/approve".format(id=sandbox_id),
            json={"channel": channel, "code": code},
        )

    # --- Channel configuration ---

    def feishu_config(self, sandbox_id: str, **kwargs) -> dict:
        return self._request(
            "POST",
            "/sandboxes/{id}/pairing/feishu".format(id=sandbox_id),
            json=kwargs,
        )

    # --- Config operations ---

    def config_set(self, sandbox_id: str, key: str, value: str) -> dict:
        return self._request(
            "POST",
            "/sandboxes/{id}/config".format(id=sandbox_id),
            json={"key": key, "value": value},
        )
