"""Structured output and error handling for OpenClaw Sandbox CLI."""

import json

from .const import PACKAGE_NAME

# --- Exit codes (grouped by category) ---

EXIT_OK = 0
EXIT_UNKNOWN = 1
EXIT_MISSING_API_KEY = 10
EXIT_SANDBOX_CREATE = 20
EXIT_SANDBOX_CONNECT = 21
EXIT_SANDBOX_TIMEOUT = 22
EXIT_GATEWAY_TIMEOUT = 30
EXIT_GATEWAY_FAILED = 31
EXIT_GATEWAY_UPDATE_FAILED = 32
EXIT_API_ERROR = 40
EXIT_SERVICE_CONFIG_FAILED = 50
EXIT_DOCTOR_FAILED = 60
EXIT_PAIRING_FAILED = 70
EXIT_NODE_FAILED = 75
EXIT_DEVICE_FAILED = 76
EXIT_SANDBOX_PAUSE_FAILED = 77
EXIT_SANDBOX_RESUME_FAILED = 78
EXIT_UPDATE_FAILED = 80
EXIT_CONFIG_FAILED = 81
EXIT_CHANNEL_CONFIG_FAILED = 82

# --- JSON mode state ---

_json_mode = False


def set_json_mode(enabled: bool):
    global _json_mode
    _json_mode = enabled


def is_json_mode() -> bool:
    return _json_mode


# --- Custom exceptions ---


class CLIError(Exception):
    """Base exception for structured CLI errors."""

    def __init__(self, message: str, error_code: str, exit_code: int = 1, remediation: str = ""):
        super().__init__(message)
        self.error_code = error_code
        self.exit_code = exit_code
        self.remediation = remediation


class UpdateError(CLIError):
    def __init__(self, message: str = "Update failed."):
        super().__init__(
            message,
            "UPDATE_FAILED",
            EXIT_UPDATE_FAILED,
            remediation="Check network connectivity, then retry: pip install -U {pkg}".format(
                pkg=PACKAGE_NAME
            ),
        )


# --- JSON output helpers ---


def output_success(data: dict):
    """Print JSON success payload to stdout and return."""
    payload = {"status": "ok", **data}
    print(json.dumps(payload), flush=True)


def output_server_data(data: dict):
    """Forward server response to output_success, stripping the server 'status' field."""
    output_success({k: v for k, v in data.items() if k != "status"})


def output_error(error_code: str, message: str, exit_code: int = 1, remediation: str = ""):
    """Print JSON error payload to stdout and raise SystemExit."""
    payload = {"status": "error", "error_code": error_code, "message": message}
    if remediation:
        payload["remediation"] = remediation
    print(json.dumps(payload), flush=True)
    raise SystemExit(exit_code)
