"""Brand constants for PPClaw CLI (PPIO variant).

This is the ONLY file that differs between brand variants.
All other source files import from here instead of hardcoding brand strings.
"""

# --- Display names ---
BRAND_NAME = "PPClaw"  # Panel titles, table headers
PROVIDER_NAME = "PPIO"  # Help text, error messages
CLI_NAME = "ppclaw"  # CLI command name
PACKAGE_NAME = "PPClaw"  # PyPI distribution name (for version lookup)
CONFIG_DIR_NAME = ".ppclaw-cli"  # ~/.ppclaw-cli/
VENV_DIR_NAME = "venv"  # ~/.ppclaw-cli/venv/

# --- Environment / config ---
ENV_VAR_API_KEY = "PPIO_API_KEY"  # Environment variable name
API_KEY_URL = "https://ppio.com/docs/support/api-key"

# --- API Server ---
API_SERVER_URL = "https://ppclaw.ppio.com/api"
ENV_VAR_SERVER = "PPCLAW_SERVER"
