"""OpenClaw configuration and service management."""

import json
import logging
import os
import shlex
import threading
import time
import urllib.request
from contextlib import contextmanager
from typing import Optional
from urllib.parse import urlparse

from .const import (
    API_KEY_PLACEHOLDER,
    IDLE_PAUSE_DEFER_SECONDS,
    OPENCLAW_CONFIG_URL,
    OPENCLAW_NODE_LOG,
)
from .errors import GatewayError, GatewayTimeoutError, GatewayUpdateError, NodeStartError
from .sandbox import SandboxManager

logger = logging.getLogger(__name__)

GATEWAY_PORT = 18789
OPENCLAW_CONFIG_PATH = "/home/user/.openclaw/openclaw.json"
_LEGACY_CONFIG_PATH = "/home/user/.openclaw/config.json"
_EXEC_APPROVALS_PATH = "/home/user/.openclaw/exec-approvals.json"
_IDLE_PAUSE_DEFER_SECONDS = IDLE_PAUSE_DEFER_SECONDS
_FATAL_GATEWAY_START_PATTERNS = (
    "gateway failed to start:",
    "gateway already running",
    "lock timeout",
)
_LOCK_CONFLICT_PATTERNS = ("gateway already running", "lock timeout")
_RESTART_MAX_RETRIES = 3
_RESTART_RETRY_DELAY_SECONDS = 6
_gateway_op_locks: dict[str, threading.RLock] = {}
_gateway_op_locks_guard = threading.Lock()


def _get_gateway_lock(sandbox_id: Optional[str]) -> Optional[threading.RLock]:
    """Return the per-sandbox gateway operation lock."""
    if not sandbox_id:
        return None
    with _gateway_op_locks_guard:
        return _gateway_op_locks.setdefault(sandbox_id, threading.RLock())


@contextmanager
def gateway_operation(manager: SandboxManager):
    """Serialize gateway lifecycle changes per sandbox."""
    lock = _get_gateway_lock(manager.sandbox_id)
    if lock is None:
        yield
        return
    logger.debug("Acquiring gateway operation lock for sandbox %s", manager.sandbox_id)
    with lock:
        yield


def load_openclaw_config_template() -> dict:
    try:
        resp = urllib.request.urlopen(OPENCLAW_CONFIG_URL, timeout=10)
        return json.loads(resp.read())
    except Exception:
        logger.info("Could not fetch remote config, using local template.")
        example_path = os.path.join(os.path.dirname(__file__), "openclaw.example.json")
        with open(example_path) as f:
            return json.load(f)


def generate_openclaw_config(api_key: str) -> dict:
    config = load_openclaw_config_template()
    for provider in config.get("models", {}).get("providers", {}).values():
        if provider.get("apiKey") == API_KEY_PLACEHOLDER:
            provider["apiKey"] = api_key
    config.setdefault("gateway", {})
    config["gateway"]["mode"] = "local"
    config["gateway"]["controlUi"] = {
        "dangerouslyAllowHostHeaderOriginFallback": True,
        "dangerouslyDisableDeviceAuth": True,
    }
    config.setdefault("tools", {}).setdefault("exec", {}).update(
        {
            "security": "full",
            "ask": "off",
        }
    )
    return config


def configure_openclaw(manager: SandboxManager, api_key: str):
    config = generate_openclaw_config(api_key)
    config_content = json.dumps(config, indent=2)
    manager.run_command(
        "mkdir -p /home/user/.openclaw && chmod 700 /home/user/.openclaw",
        timeout=10,
    )
    logger.info("Writing OpenClaw configuration to sandbox...")
    manager.write_file(OPENCLAW_CONFIG_PATH, config_content)
    manager.run_command("chmod 600 {config}".format(config=OPENCLAW_CONFIG_PATH), timeout=10)
    logger.info("OpenClaw configuration written")
    _export_env = (
        "grep -q OPENCLAW_CONFIG_PATH /home/user/.bashrc 2>/dev/null"
        " || echo 'export OPENCLAW_CONFIG_PATH=\"{config}\"' >> /home/user/.bashrc"
    ).format(config=OPENCLAW_CONFIG_PATH)
    manager.run_command(_export_env, timeout=10)
    _write_exec_approvals(manager)
    _fix_extensions_permissions(manager)
    stop_gateway(manager)


def _write_exec_approvals(manager: SandboxManager):
    """Write permissive exec-approvals so nodes can run commands without operator UI."""
    approvals = json.dumps(
        {"version": 1, "defaults": {"security": "full", "ask": "off", "askFallback": "full"}},
    )
    manager.write_file(_EXEC_APPROVALS_PATH, approvals)
    manager.run_command("chmod 600 {path}".format(path=_EXEC_APPROVALS_PATH), timeout=10)
    logger.info("Exec approvals written (security=full)")


def _patch_feishu_webhook_signature(manager: SandboxManager):
    """Patch feishu monitor to skip signature validation entirely.

    Feishu may send AES-encrypted payloads without signature headers; the
    ``isFeishuWebhookSignatureValid`` function rejects these with
    ``return false`` when any of timestamp/nonce/signature is missing.

    We ``grep -rl`` for the function name to locate the file (works for
    both source and bundled artifacts), then inject ``return true;``
    right after the function signature so the original body never runs.
    """
    func = "isFeishuWebhookSignatureValid"
    cmd = (
        f"TARGET=$(grep -rl '{func}'"
        " /usr/local/lib/node_modules/openclaw/ 2>/dev/null"
        " | head -1)"
        ' && if [ -n "$TARGET" ]; then'
        " sed -i"
        f" 's/function {func}([^)]*) {{/& return true;/'"
        ' "$TARGET" && echo patched; fi'
    )
    result = manager.run_command(cmd, timeout=15)
    if result and result.stdout and "patched" in result.stdout:
        logger.info("Feishu webhook signature patch applied")
    else:
        logger.info("Feishu webhook signature patch skipped (file not found or already patched)")


def launch_gateway(manager: SandboxManager):
    logger.info("Starting OpenClaw Gateway...")
    _patch_feishu_webhook_signature(manager)
    manager.run_command(
        "nohup bash -c 'OPENCLAW_CONFIG_PATH={config} openclaw gateway run"
        " --port {port} --bind lan'"
        " > /tmp/gateway.log 2>&1 &".format(config=OPENCLAW_CONFIG_PATH, port=GATEWAY_PORT),
        timeout=10,
    )


def _defer_idle_pause(manager: SandboxManager, seconds: int = _IDLE_PAUSE_DEFER_SECONDS):
    """Delay idle auto-pause while gateway management is in progress."""
    sandbox_id = manager.sandbox_id
    if sandbox_id:
        from .idle_monitor import defer_pause_for_sandbox

        defer_pause_for_sandbox(sandbox_id, seconds=seconds)


def _process_running(manager: SandboxManager, process_name: str) -> bool:
    """Return True when an exact process name is present in the sandbox."""
    result = manager.run_command(
        "pgrep -x {name} >/dev/null 2>&1 && echo ok || true".format(name=shlex.quote(process_name)),
        timeout=5,
        silent=True,
    )
    return bool(result and result.stdout and "ok" in result.stdout)


def _gateway_listener_running(manager: SandboxManager) -> bool:
    """Return True while the gateway port is still listening."""
    result = manager.run_command(
        "ss -ltn '( sport = :{port} )' 2>/dev/null | awk 'NR>1 {{print \"ok\"; exit}}'".format(
            port=GATEWAY_PORT
        ),
        timeout=5,
        silent=True,
    )
    return bool(result and result.stdout and "ok" in result.stdout)


def _gateway_runtime_active(manager: SandboxManager) -> bool:
    """Return True while the gateway supervisor, worker, or listener is still active."""
    return (
        _process_running(manager, "openclaw")
        or _process_running(manager, "openclaw-gateway")
        or _gateway_listener_running(manager)
    )


def get_gateway_pid(manager: SandboxManager) -> str:
    """Return the newest gateway worker PID, or an empty string if absent."""
    result = manager.run_command(
        "pgrep -x openclaw-gateway | tail -1 || true",
        timeout=5,
        silent=True,
    )
    if result and result.stdout:
        return result.stdout.strip()
    return ""


def _collect_gateway_runtime_state(manager: SandboxManager) -> str:
    """Capture process and listener state to help diagnose lifecycle races."""
    processes = manager.run_command(
        "pgrep -af openclaw 2>/dev/null || true",
        timeout=5,
        silent=True,
    )
    listeners = manager.run_command(
        "ss -ltnp '( sport = :{port} )' 2>/dev/null || true".format(port=GATEWAY_PORT),
        timeout=5,
        silent=True,
    )
    parts = []
    if processes and processes.stdout and processes.stdout.strip():
        parts.append("OpenClaw processes:\n{out}".format(out=processes.stdout.strip()))
    if listeners and listeners.stdout and listeners.stdout.strip():
        parts.append("Gateway listeners:\n{out}".format(out=listeners.stdout.strip()))
    return "\n".join(parts)


def _wait_for_gateway_shutdown(manager: SandboxManager, max_checks: int = 15):
    """Give the previous gateway runtime time to release its startup lock."""
    for i in range(max_checks):
        if not _gateway_runtime_active(manager):
            return
        logger.info("  Waiting for Gateway to stop (%d/%d)...", i + 1, max_checks)
        time.sleep(1)
    state_text = _collect_gateway_runtime_state(manager)
    message = "Gateway did not stop cleanly before restart."
    if state_text:
        message += "\n" + state_text
    raise GatewayError(message)


def start_gateway(manager: SandboxManager):
    with gateway_operation(manager):
        _defer_idle_pause(manager)
        launch_gateway(manager)
        wait_for_gateway(manager)


def _read_log_tail(manager: SandboxManager, log_path: str) -> str:
    """Read the last 30 lines of a log file inside the sandbox."""
    result = manager.run_command("tail -30 {log} 2>&1 || true".format(log=log_path), timeout=5)
    if result and result.stdout and result.stdout.strip():
        return result.stdout.strip()
    return ""


def _collect_log_tail(manager: SandboxManager, log_path: str) -> str:
    """Read and log the last 30 lines of a log file inside the sandbox."""
    text = _read_log_tail(manager, log_path)
    if text:
        logger.error("Log tail (%s):\n%s", log_path, text)
    return text


def _gateway_start_failed(log_text: str) -> bool:
    """Return True when the gateway log shows a fatal startup failure."""
    normalized = log_text.lower()
    return any(pattern in normalized for pattern in _FATAL_GATEWAY_START_PATTERNS)


def _is_lock_conflict(error: BaseException) -> bool:
    """Return True when the error indicates a gateway process lock conflict."""
    msg = str(error).lower()
    return any(pattern in msg for pattern in _LOCK_CONFLICT_PATTERNS)


def wait_for_gateway(manager: SandboxManager, max_checks: int = 120):
    for i in range(max_checks):
        result = manager.run_command(
            'curl -s --max-time 2 -o /dev/null -w "%{{http_code}}"'
            " http://localhost:{port}/ 2>/dev/null; echo".format(port=GATEWAY_PORT),
            timeout=10,
        )
        if result and result.stdout and result.stdout.strip() == "200":
            logger.info("OpenClaw Gateway is listening on port %d", GATEWAY_PORT)
            return
        # Only check logs every 10 iterations to avoid expensive remote reads
        log_text = _read_log_tail(manager, "/tmp/gateway.log") if (i + 1) % 10 == 0 else None
        if log_text and _gateway_start_failed(log_text):
            state_text = _collect_gateway_runtime_state(manager)
            logger.error("Gateway startup fatal log:\n%s", log_text)
            if state_text:
                logger.error("Gateway runtime state:\n%s", state_text)
            raise GatewayError(
                "Gateway failed to start."
                + ("\n" + log_text if log_text else "")
                + ("\n" + state_text if state_text else "")
            )
        logger.info("  Waiting for Gateway to start (%d/%d)...", i + 1, max_checks)
        time.sleep(1)
    log_text = _collect_log_tail(manager, "/tmp/gateway.log")
    state_text = _collect_gateway_runtime_state(manager)
    raise GatewayTimeoutError(
        "Gateway did not start in time. Check sandbox logs."
        + ("\n" + log_text if log_text else "")
        + ("\n" + state_text if state_text else "")
    )


def wait_for_gateway_auto_restart(
    manager: SandboxManager,
    previous_pid: str,
    max_checks: int = 20,
    startup_checks: int = 12,
) -> bool:
    """Wait briefly for OpenClaw's config watcher to restart the gateway for us."""
    if not previous_pid:
        return False

    for i in range(max_checks):
        current_pid = get_gateway_pid(manager)
        if current_pid and current_pid != previous_pid:
            logger.info(
                "Detected automatic gateway restart after config write (%s -> %s)",
                previous_pid,
                current_pid,
            )
            wait_for_gateway(manager, max_checks=startup_checks)
            return True
        logger.info(
            "  Waiting for automatic gateway restart (%d/%d)...",
            i + 1,
            max_checks,
        )
        time.sleep(1)
    return False


def stop_gateway(manager: SandboxManager):
    with gateway_operation(manager):
        logger.info("Stopping OpenClaw Gateway...")
        _defer_idle_pause(manager)
        _env = "OPENCLAW_CONFIG_PATH={config}".format(config=OPENCLAW_CONFIG_PATH)
        manager.run_command(
            "{env} openclaw daemon stop 2>/dev/null || true".format(env=_env),
            timeout=30,
            silent=True,
        )
        manager.run_command(
            "{env} openclaw gateway stop 2>/dev/null || true".format(env=_env),
            timeout=30,
            silent=True,
        )
        manager.run_command(
            "pkill -9 -f 'openclaw' 2>/dev/null || true",
            timeout=10,
            silent=True,
        )
        _wait_for_gateway_shutdown(manager)
        logger.info("OpenClaw Gateway stopped")


def restart_gateway(manager: SandboxManager):
    """Restart gateway with retries to handle lock conflicts from concurrent auto-restarts."""
    last_exc: BaseException | None = None
    for attempt in range(_RESTART_MAX_RETRIES):
        try:
            with gateway_operation(manager):
                stop_gateway(manager)
                start_gateway(manager)
            return
        except (GatewayError, GatewayTimeoutError) as exc:
            if not _is_lock_conflict(exc) or attempt == _RESTART_MAX_RETRIES - 1:
                raise
            last_exc = exc
            logger.warning(
                "Gateway lock conflict on restart attempt %d/%d, retrying in %ds: %s",
                attempt + 1,
                _RESTART_MAX_RETRIES,
                _RESTART_RETRY_DELAY_SECONDS,
                exc,
            )
            time.sleep(_RESTART_RETRY_DELAY_SECONDS)
    if last_exc is not None:
        raise last_exc


def update_openclaw(manager: SandboxManager) -> str:
    with gateway_operation(manager):
        _env = "OPENCLAW_CONFIG_PATH={config}".format(config=OPENCLAW_CONFIG_PATH)
        logger.info("Updating OpenClaw...")
        result = manager.run_command(
            "{env} openclaw update --yes --no-restart 2>&1".format(env=_env),
            timeout=600,
        )
        if result is None:
            raise GatewayUpdateError("Failed to run openclaw update. Check sandbox connectivity.")
        output_text = result.stdout.strip() if result.stdout else ""
        logger.info("OpenClaw updated")
        _fix_extensions_permissions(manager)
        restart_gateway(manager)
        return output_text


def _fix_extensions_permissions(manager: SandboxManager):
    logger.info("Fixing OpenClaw extensions permissions...")
    fix_cmd = (
        "EXT=/usr/local/lib/node_modules/openclaw/extensions"
        ' && if [ -d "$EXT" ]; then'
        '   cp -r "$EXT" /tmp/_oc_ext_fix'
        '   && rm -rf "$EXT"'
        '   && mv /tmp/_oc_ext_fix "$EXT"'
        '   && find "$EXT" -type d -exec chmod 755 {} +'
        '   && find "$EXT" -type f -exec chmod 644 {} +'
        "   && echo ok; fi"
    )
    fix_result = manager.run_command(fix_cmd, timeout=30)
    if fix_result and fix_result.stdout and "ok" in fix_result.stdout:
        logger.info("OpenClaw extensions permissions fixed")
    else:
        logger.info("Extensions directory not found or already fixed")


def _read_config(manager: SandboxManager) -> str:
    try:
        content = manager.read_file(OPENCLAW_CONFIG_PATH)
        if content:
            return content
    except Exception:
        pass
    try:
        content = manager.read_file(_LEGACY_CONFIG_PATH)
        if content:
            return content
    except Exception:
        pass
    return ""


def get_gateway_token(manager: SandboxManager) -> str:
    content = _read_config(manager)
    if content:
        try:
            config = json.loads(content)
            return config.get("gateway", {}).get("auth", {}).get("token", "")
        except (json.JSONDecodeError, AttributeError):
            pass
    return ""


def get_public_urls(manager: SandboxManager) -> dict:
    host = manager.sandbox.get_host(GATEWAY_PORT)
    return {
        "gateway_ws": "wss://{host}".format(host=host),
        "webui": "https://{host}".format(host=host),
    }


# --- Node mode ---


def _parse_ws_host_port(gateway_url: str) -> tuple:
    """Extract (host, port, use_tls) from a wss://host:port or wss://host URL.

    Returns the default WSS port (443) when no explicit port is given for
    wss:// URLs, since the sandbox proxy terminates TLS on 443.
    Uses urlparse for robust parsing. Raises ValueError on invalid input.
    """
    parsed = urlparse(gateway_url)
    host = parsed.hostname
    use_tls = parsed.scheme == "wss"
    if parsed.port:
        port = parsed.port
    elif use_tls:
        port = 443
    else:
        port = GATEWAY_PORT
    if not host:
        raise ValueError("Invalid gateway URL: no host found in '{url}'".format(url=gateway_url))
    return host, port, use_tls


def _write_node_config(manager: SandboxManager):
    """Write openclaw config with exec security settings for the node."""
    node_config = {"tools": {"exec": {"security": "full", "ask": "off"}}}
    config = json.dumps(node_config, indent=2)
    result = manager.run_command(
        "mkdir -p /home/user/.openclaw && chmod 700 /home/user/.openclaw",
        timeout=10,
    )
    if result is None:
        raise NodeStartError("Failed to create config directory in sandbox.")
    manager.write_file(OPENCLAW_CONFIG_PATH, config)
    manager.run_command("chmod 600 {config}".format(config=OPENCLAW_CONFIG_PATH), timeout=10)
    logger.info("Node config written")


def launch_node(
    manager: SandboxManager, gateway_url: str, display_name: str, gateway_token: str = ""
):
    """Start the openclaw node process connecting to a gateway."""
    _write_node_config(manager)
    host, port, use_tls = _parse_ws_host_port(gateway_url)
    logger.info(
        "Starting OpenClaw Node (gateway=%s:%d, tls=%s, name=%s)...",
        host,
        port,
        use_tls,
        display_name,
    )
    tls_flag = " --tls" if use_tls else ""
    token_env = (
        " OPENCLAW_GATEWAY_TOKEN={tok}".format(tok=shlex.quote(gateway_token))
        if gateway_token
        else ""
    )
    cmd = (
        "nohup bash -c 'OPENCLAW_CONFIG_PATH={config}{token_env} openclaw node run"
        " --host {host} --port {port}{tls}"
        " --display-name {name}'"
        " > {log} 2>&1 &"
    ).format(
        config=OPENCLAW_CONFIG_PATH,
        token_env=token_env,
        host=shlex.quote(host),
        port=port,
        tls=tls_flag,
        name=shlex.quote(display_name),
        log=OPENCLAW_NODE_LOG,
    )
    result = manager.run_command(cmd, timeout=10)
    if result is None:
        raise NodeStartError("Failed to launch node process in sandbox.")


def _is_node_alive(manager: SandboxManager) -> bool:
    """Check if the openclaw node process is running."""
    proc = manager.run_command(
        "pgrep '[o]penclaw' > /dev/null 2>&1 && echo ok || true",
        timeout=5,
        silent=True,
    )
    return bool(proc and proc.stdout and "ok" in proc.stdout)


def _node_exited_for_pairing(manager: SandboxManager) -> bool:
    """Return True when the node log shows exit due to ``pairing required``.

    Newer OpenClaw versions exit immediately when the gateway rejects the
    handshake with NOT_PAIRED instead of retrying.  This is expected on
    first connect — the pairing request has been registered and the caller
    should proceed to approve it.
    """
    log = _read_log_tail(manager, OPENCLAW_NODE_LOG)
    return bool(log and "pairing required" in log.lower())


def wait_for_node(
    manager: SandboxManager,
    max_checks: int = 30,
    stable_count: int = 3,
):
    """Wait for the node process to start or confirm it registered a pairing request.

    Confirms the process is alive across several consecutive pgrep checks.
    If the process exits because the gateway requires pairing (expected on
    first connect with newer OpenClaw), this is treated as success — the
    pairing request has been registered and the caller can approve it.
    """
    alive_streak = 0
    for i in range(max_checks):
        if _is_node_alive(manager):
            alive_streak += 1
            if alive_streak >= stable_count:
                logger.info("OpenClaw Node process is running (stable)")
                return
            logger.info("  Node alive (%d/%d stable checks)...", alive_streak, stable_count)
        else:
            if alive_streak > 0 and _node_exited_for_pairing(manager):
                logger.info("Node exited due to pairing required — treating as success")
                return
            alive_streak = 0
            logger.info("  Waiting for Node process (%d/%d)...", i + 1, max_checks)
        time.sleep(2)

    log_text = _collect_log_tail(manager, OPENCLAW_NODE_LOG)
    raise NodeStartError("Node failed to start." + ("\n" + log_text if log_text else ""))


def check_node_status(manager: SandboxManager, gateway_url: str) -> dict:
    """Check node process and pairing status.

    Returns a dict with:
      - ``alive``: node process is running
      - ``paired``: TCP connection to gateway is established

    Before pairing the gateway rejects the connect handshake with
    NOT_PAIRED and closes the WebSocket, so there is no persistent TCP
    connection.  After pairing approval the next reconnect succeeds and
    the connection stays up — an established TCP socket to the gateway
    port is the signal that pairing is complete.
    """
    alive = _is_node_alive(manager)

    paired = False
    if alive:
        _, port, _ = _parse_ws_host_port(gateway_url)
        conn = manager.run_command(
            "ss -tn state established '( dport = :{port} )' 2>/dev/null"
            " | tail -n +2 | grep -q . && echo ok || true".format(port=port),
            timeout=5,
            silent=True,
        )
        if conn and conn.stdout and "ok" in conn.stdout:
            paired = True

    return {"alive": alive, "paired": paired}


def reconnect_node(
    manager: SandboxManager, gateway_url: str, display_name: str, gateway_token: str = ""
):
    """Re-launch node only if the process has died. Skip if still alive."""
    if _is_node_alive(manager):
        logger.info("Node process still alive, skipping reconnect")
        return
    logger.info("Node process dead, relaunching...")
    launch_node(manager, gateway_url, display_name, gateway_token=gateway_token)


def stop_node(manager: SandboxManager):
    """Stop the openclaw node process inside the sandbox."""
    logger.info("Stopping OpenClaw Node...")
    manager.run_command(
        "pkill -9 openclaw 2>/dev/null || true",
        timeout=10,
        silent=True,
    )
    time.sleep(1)
    logger.info("OpenClaw Node stopped")
