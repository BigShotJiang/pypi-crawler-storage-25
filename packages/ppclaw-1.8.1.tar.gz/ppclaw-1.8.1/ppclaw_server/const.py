"""Brand constants for PPClaw Server (PPIO variant).

This is the ONLY file that differs between brand variants on the server side.
"""

import os

# --- Brand ---
BRAND_NAME = "PPClaw"
SERVER_TITLE = "PPClaw API Server"
SERVER_DESCRIPTION = "API Server for PPClaw sandbox management"

# --- Sandbox ---
TEMPLATE_ID = os.environ.get("PPCLAW_TEMPLATE_ID", "ppclaw")
SANDBOX_APP_LABEL = "ppclaw"
SDK_PACKAGE = "ppio_sandbox"

# --- OpenClaw config ---
API_KEY_PLACEHOLDER = "PPIO_API_KEY"
OPENCLAW_CONFIG_URL = (
    "https://raw.githubusercontent.com/PPIO/ppclaw-config/main/openclaw.example.json"
)

# --- Sandbox services ---
SERVICES_DIR = "/home/user/.ppclaw"
TTYD_PORT = 7681
FILE_MANAGER_PORT = 7682
SERVICES_USERNAME = "admin"
FEISHU_WEBHOOK_PORT = 3000
FEISHU_WEBHOOK_PATH = "/feishu/events"

# --- OpenClaw node ---
OPENCLAW_NODE_LOG = "/tmp/node.log"

# --- Sandbox mode & type ---
MODE_GATEWAY = "gateway"
MODE_NODE = "node"
TYPE_ALWAYS_ON = "always-on"
TYPE_ON_DEMAND = "on-demand"

# --- On-demand ---
DEFAULT_IDLE_TIMEOUT = 300
MIN_IDLE_TIMEOUT = 60
MAX_IDLE_TIMEOUT = 86400  # 24 hours
MIN_TIMEOUT = 300
MAX_TIMEOUT = 30 * 86400  # 30 days
IDLE_CHECK_INTERVAL = 60
IDLE_CHECKS_BEFORE_PAUSE = 2
AGENT_STATUS_PATH = "/tmp/.ppclaw-status.json"
AGENT_CONFIG_PATH = "/tmp/.ppclaw-agent-config.json"
AGENT_SCRIPT_FILE = "ppclaw_agent.py"
AGENT_SCRIPT_PATH = SERVICES_DIR + "/" + AGENT_SCRIPT_FILE
AGENT_LOG_PATH = "/tmp/ppclaw-agent.log"
MONITOR_CONCURRENCY = 10
MONITOR_PAGE_SIZE = 50
AGENT_STALENESS_MULTIPLIER = 3
IDLE_PAUSE_DEFER_SECONDS = 180

# --- Test host (pre-release routes only served on this host) ---
TEST_HOST = "test-ppclaw.ppio.com"

# --- Cron wakeup scheduler ---
CRON_WAKEUP_INTERVAL = 30  # seconds between wakeup checks
CRON_WAKEUP_LEAD_TIME = 120  # resume this many seconds before cron fires
CRON_RESUME_COOLDOWN = 300  # avoid re-resuming same sandbox within this window


def agent_check_interval(idle_timeout: int) -> int:
    """Compute the agent's check interval from an idle timeout."""
    return max(idle_timeout // 5, 30)


def default_node_name(sandbox_id: str) -> str:
    """Generate a default node display name from sandbox ID."""
    return "node-{id}".format(id=sandbox_id[:8])
