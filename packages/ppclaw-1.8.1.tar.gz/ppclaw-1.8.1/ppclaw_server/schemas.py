"""Pydantic request/response models for the API Server."""

from __future__ import annotations

from typing import List, Literal, Optional

from pydantic import BaseModel, Field, model_validator

from .const import FEISHU_WEBHOOK_PATH, FEISHU_WEBHOOK_PORT

# --- Requests ---


class LaunchRequest(BaseModel):
    timeout: int = Field(default=180, description="Sandbox creation timeout in seconds")
    template_id: Optional[str] = Field(default=None, description="Override template ID")
    mode: Literal["gateway", "node"] = Field(
        default="gateway",
        description="Launch mode: 'gateway' (default) or 'node'",
    )
    display_name: Optional[str] = Field(
        default=None,
        description="Node display name shown in the gateway (node mode only).",
    )
    sandbox_type: Literal["always-on", "on-demand"] = Field(
        default="always-on",
        description="Sandbox type: 'always-on' (default) runs continuously; "
        "'on-demand' auto-pauses when idle and auto-resumes on HTTP access.",
    )
    idle_timeout: Optional[int] = Field(
        default=None,
        description="Seconds of inactivity before auto-pause (on-demand only, default 300).",
    )


class NodeConnectRequest(BaseModel):
    gateway_url: str = Field(
        description="Target gateway WebSocket URL (wss://...) to connect the node to.",
    )
    gateway_token: Optional[str] = Field(
        default=None,
        description="Gateway auth token for authenticating with the gateway.",
    )

    @model_validator(mode="after")
    def check_gateway_url_scheme(self):
        if not self.gateway_url.startswith(("wss://", "ws://")):
            raise ValueError("gateway_url must use wss:// or ws:// scheme.")
        return self


class PairingApproveRequest(BaseModel):
    channel: str = Field(description="Channel name (telegram, discord, etc.)")
    code: str = Field(description="Pairing code to approve")


class DeviceApproveRequest(BaseModel):
    request_id: Optional[str] = Field(
        default=None,
        description="Request ID to approve. If omitted, all pending devices are approved.",
    )


# --- Responses ---


class ErrorResponse(BaseModel):
    status: str = "error"
    error_code: str
    message: str


class HealthResponse(BaseModel):
    status: str = "ok"


class SandboxInfo(BaseModel):
    sandbox_id: str
    state: str
    mode: Literal["gateway", "node"] = "gateway"
    sandbox_type: Optional[str] = None
    cpu: Optional[int] = None
    memory_mb: Optional[int] = None
    started_at: Optional[str] = None


class SandboxListResponse(BaseModel):
    status: str = "ok"
    sandboxes: List[SandboxInfo]


class SandboxResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    mode: Literal["gateway", "node"] = "gateway"
    sandbox_type: Optional[str] = None
    idle_timeout: Optional[int] = None
    keep_alive: Optional[int] = None
    # Gateway mode fields
    webui: Optional[str] = None
    gateway_ws: Optional[str] = None
    gateway_token: Optional[str] = None
    feishu_webhook_url: Optional[str] = None
    # Node mode fields
    node_display_name: Optional[str] = None
    # Shared fields
    terminal_url: Optional[str] = None
    filemanager_url: Optional[str] = None
    services_username: Optional[str] = None
    services_password: Optional[str] = None
    state: Optional[str] = None
    message: Optional[str] = None
    paused_notice: Optional[str] = None


class NodeResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    node_display_name: Optional[str] = None
    gateway_url: Optional[str] = None
    message: Optional[str] = None


class NodeStatusResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    alive: bool = False
    paired: bool = False


class MessageResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    message: str


class GatewayResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    output: Optional[str] = None
    restarted: Optional[bool] = None
    webui: Optional[str] = None
    gateway_ws: Optional[str] = None
    gateway_token: Optional[str] = None
    message: Optional[str] = None


class DoctorResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    output: str


class PairingResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    channel: Optional[str] = None
    code: Optional[str] = None
    output: str


class DevicesResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    approved: Optional[List[str]] = None
    output: str


class ServiceResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    terminal_url: Optional[str] = None
    filemanager_url: Optional[str] = None
    services_username: Optional[str] = None
    services_password: Optional[str] = None
    already_configured: Optional[bool] = None


class ConfigSetRequest(BaseModel):
    key: str = Field(description="Configuration key to update (e.g. 'idle-timeout', 'timeout').")
    value: str = Field(description="New value for the configuration key.")


class ConfigSetResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    key: str
    value: str
    message: str


class FeishuConfigRequest(BaseModel):
    app_id: str = Field(description="Feishu app ID")
    app_secret: str = Field(description="Feishu app secret")
    connection_mode: Literal["webhook", "event"] = Field(
        default="event",
        description="Connection mode: 'webhook' (HTTP push) or 'event' (default, long-poll)",
    )
    verification_token: Optional[str] = Field(
        default=None, description="Verification token (required for webhook mode)"
    )
    encrypt_key: Optional[str] = Field(
        default=None, description="Encrypt key (required for webhook mode)"
    )
    webhook_host: str = Field(
        default="0.0.0.0",
        description="Webhook bind host (webhook mode only)",  # noqa: S104
    )
    webhook_port: int = Field(
        default=FEISHU_WEBHOOK_PORT, description="Webhook listen port (webhook mode only)"
    )
    webhook_path: str = Field(
        default=FEISHU_WEBHOOK_PATH, description="Webhook URL path (webhook mode only)"
    )
    dm_policy: str = Field(default="pairing", description="DM policy (default: pairing)")

    @model_validator(mode="after")
    def check_webhook_fields(self):
        if self.connection_mode == "webhook":
            if not self.verification_token:
                raise ValueError("verification_token is required for webhook mode.")
            if not self.encrypt_key:
                raise ValueError("encrypt_key is required for webhook mode.")
        return self


class FeishuConfigResponse(BaseModel):
    status: str = "ok"
    sandbox_id: str
    channel: str = "feishu"
    connection_mode: str
    message: str
