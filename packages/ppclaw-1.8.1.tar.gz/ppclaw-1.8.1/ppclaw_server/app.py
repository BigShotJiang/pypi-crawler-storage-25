"""FastAPI application entry point for the API Server."""

import contextlib
import logging
import pathlib

import starlette.middleware
from fastapi import FastAPI
from starlette.applications import Starlette
from starlette.responses import Response
from starlette.routing import Mount, Route

from .const import SERVER_DESCRIPTION, SERVER_TITLE, TEST_HOST
from .errors import ServerError
from .logging import LOG_FMT, LOG_RENAME, CleanJsonFormatter, HealthCheckFilter, build_log_config
from .middleware import generic_error_handler, server_error_handler
from .routes import config, devices, gateway, health, node, pairing, sandboxes, services
from .trace import TraceMiddleware

# Patch any handlers that uvicorn has already created before this module was imported.
# Covers the bare "uvicorn ... app:app" case (no --log-config).
_JSON_FMT = CleanJsonFormatter(fmt=LOG_FMT, rename_fields=LOG_RENAME)
_HEALTH_FILTER = HealthCheckFilter()
for _name in (None, "uvicorn", "uvicorn.access", "uvicorn.error"):
    _logger = logging.getLogger(_name)
    for _h in _logger.handlers:
        _h.setFormatter(_JSON_FMT)
    if _name == "uvicorn.access":
        _logger.addFilter(_HEALTH_FILTER)
logging.getLogger().setLevel(logging.INFO)

# MCP server (optional — requires mcp package, Python >=3.10)
_mcp_available = False
try:
    from .mcp import get_mcp_app  # noqa: I001
    from .mcp import mcp as _mcp_server

    _mcp_available = True
except ImportError:
    pass


# --- FastAPI app (REST API at /api) ---

api_app = FastAPI(
    title=SERVER_TITLE,
    description=SERVER_DESCRIPTION,
    root_path="/api",
)

# Register error handlers
api_app.add_exception_handler(ServerError, server_error_handler)
api_app.add_exception_handler(Exception, generic_error_handler)

# Include routers
api_app.include_router(health.router)
api_app.include_router(sandboxes.router)
api_app.include_router(gateway.router)
api_app.include_router(node.router)
api_app.include_router(services.router)
api_app.include_router(pairing.router)
api_app.include_router(devices.router)
api_app.include_router(config.router)


# --- Top-level Starlette app: mounts REST at /api and MCP at /mcp ---


@contextlib.asynccontextmanager
async def _lifespan(a: Starlette):
    import asyncio

    from dotenv import load_dotenv

    from .database import db_init

    load_dotenv()
    try:
        db_init()
    except RuntimeError:
        logging.getLogger(__name__).warning(
            "Database not configured — on-demand features disabled", exc_info=True
        )

    monitor_task = None
    wakeup_task = None
    try:
        from .idle_monitor import idle_monitor_loop

        monitor_task = asyncio.create_task(idle_monitor_loop())
    except Exception:
        logging.getLogger(__name__).warning("Failed to start idle monitor", exc_info=True)

    try:
        from .cron_wakeup import cron_wakeup_loop

        wakeup_task = asyncio.create_task(cron_wakeup_loop())
    except Exception:
        logging.getLogger(__name__).warning("Failed to start cron wakeup scheduler", exc_info=True)

    try:
        if _mcp_available:
            # StreamableHTTPSessionManager.run() can only be called once per
            # instance.  When the app is re-entered (e.g. in tests), create a
            # fresh session manager so the lifespan succeeds again.
            if _mcp_server.session_manager._has_started:
                _mcp_server.session_manager._has_started = False
            async with _mcp_server.session_manager.run():
                yield
        else:
            yield
    finally:
        for task in (monitor_task, wakeup_task):
            if task:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task


# --- Static doc endpoints ---

_DOCS_DIR = pathlib.Path(__file__).resolve().parent.parent / "docs"

_STATIC_FILES = [
    ("install.sh", "text/x-shellscript; charset=utf-8"),
    ("install.ps1", "text/plain; charset=utf-8"),
    ("skill.md", "text/markdown; charset=utf-8"),
]

# Pre-release files — only served when Host matches TEST_HOST.
# Wheel is built during Docker image build; may not exist in dev.
_PRE_RELEASE_DIR = _DOCS_DIR / "pre-release"
_TEST_STATIC_FILES = [
    ("test-install.sh", "text/x-shellscript; charset=utf-8"),
    ("test-install.ps1", "text/plain; charset=utf-8"),
]


def _static_route(filename, media_type, base_dir=_DOCS_DIR, host_gate=None):
    """Build a Starlette Route that serves a single file.

    Args:
        base_dir: directory containing the file.
        host_gate: if set, only serve when the Host header matches (case-insensitive).
                   Files that may not exist at startup are read lazily per request.
    """
    path = base_dir / filename

    # Eagerly cache when no host gate (production files must exist at startup).
    # Lazily read when host-gated (file may be absent in dev).
    cached: bytes | None = None
    if host_gate is None:
        cached = path.read_bytes()  # fail loudly at startup if missing
    elif path.exists():
        cached = path.read_bytes()

    is_text = not media_type.startswith("application/octet")

    async def handler(request):
        if host_gate is not None:
            host = request.headers.get("host", "").split(":")[0].lower()
            if host != host_gate:
                return Response("Not Found", status_code=404)
        content = cached
        if content is None:
            if not path.exists():
                return Response("Not Found", status_code=404)
            content = path.read_bytes()
        if is_text:
            return Response(content.decode(), media_type=media_type)
        return Response(content, media_type=media_type)

    return Route("/{f}".format(f=filename), handler)


def _whl_route(base_dir, host_gate):
    """Serve *.whl files from base_dir, gated by Host header."""

    async def handler(request):
        host = request.headers.get("host", "").split(":")[0].lower()
        if host != host_gate:
            return Response("Not Found", status_code=404)
        name = request.path_params["name"]
        path = base_dir / "{n}.whl".format(n=name)
        if not path.exists() or path.resolve().parent != base_dir.resolve():
            return Response("Not Found", status_code=404)
        return Response(path.read_bytes(), media_type="application/octet-stream")

    return Route("/{name}.whl", handler)


_test_host = TEST_HOST.lower()

_routes = (
    [_static_route(f, mt, _PRE_RELEASE_DIR, _test_host) for f, mt in _TEST_STATIC_FILES]
    + [_whl_route(_PRE_RELEASE_DIR, _test_host)]
    + [_static_route(f, mt) for f, mt in _STATIC_FILES]
    + [
        Mount("/api", app=api_app),
    ]
)
if _mcp_available:
    _routes.append(Mount("", app=get_mcp_app()))

# MCP SDK removes its RichHandler above, which may leave the root logger with
# no handlers at all.  Ensure it always has a JSON-formatted one so that
# third-party loggers (mcp.*, sandbox SDK, httpx) still emit JSON.
_root_logger = logging.getLogger()
if not _root_logger.handlers:
    _json_handler = logging.StreamHandler()
    _json_handler.setFormatter(_JSON_FMT)
    _root_logger.addHandler(_json_handler)

app = Starlette(
    routes=_routes,
    lifespan=_lifespan,
    middleware=[
        starlette.middleware.Middleware(TraceMiddleware),
    ],
)


def main():
    """Entry point for the API server command."""
    import uvicorn

    app_path = "{pkg}.app:app".format(pkg=__package__)
    uvicorn.run(app_path, host="0.0.0.0", port=8000, reload=False, log_config=build_log_config())
