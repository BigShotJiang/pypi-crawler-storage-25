"""Background cron wakeup scheduler for on-demand sandboxes.

Periodically checks paused on-demand sandboxes that have cron schedules.
When a cron job is about to fire (within CRON_WAKEUP_LEAD_TIME), the
scheduler proactively resumes the sandbox so the Gateway can run the job.
"""

import asyncio
import json
import logging
import time
from datetime import datetime, timezone

from .const import (
    CRON_RESUME_COOLDOWN,
    CRON_WAKEUP_INTERVAL,
    CRON_WAKEUP_LEAD_TIME,
    MONITOR_CONCURRENCY,
    MONITOR_PAGE_SIZE,
)
from .database import (
    db_available,
    db_get_api_key,
    db_list_on_demand_active,
    to_prefix,
)
from .sandbox import SandboxManager, SandboxState

logger = logging.getLogger(__name__)

_recently_resumed: dict[str, float] = {}

_semaphore = None


def _get_semaphore() -> asyncio.Semaphore:
    global _semaphore  # noqa: PLW0603
    if _semaphore is None:
        _semaphore = asyncio.Semaphore(MONITOR_CONCURRENCY)
    return _semaphore


def _compute_next_run(schedule: dict, tz_name: str = None) -> float:
    """Return the earliest next-run epoch (seconds) for a schedule, or None."""
    kind = schedule.get("kind")

    if kind == "cron":
        expr = schedule.get("expr")
        if not expr:
            return None
        try:
            from croniter import croniter

            tz_obj = None
            if tz_name:
                try:
                    import zoneinfo

                    tz_obj = zoneinfo.ZoneInfo(tz_name)
                except Exception:
                    pass
            now = datetime.now(tz_obj or timezone.utc)
            return croniter(expr, now).get_next(float)
        except Exception:
            return None

    if kind == "at":
        at_val = schedule.get("at")
        if at_val:
            try:
                dt = datetime.fromisoformat(str(at_val).replace("Z", "+00:00"))
                ts = dt.timestamp()
                if ts > time.time():
                    return ts
            except Exception:
                pass
        at_ms = schedule.get("atMs")
        if at_ms:
            try:
                ts = float(at_ms) / 1000.0
                if ts > time.time():
                    return ts
            except (ValueError, TypeError):
                pass
        return None

    return None


def _entry_next_run(entry: dict) -> float:
    """Resolve the next-run timestamp for one cron entry.

    Prefer the agent-provided ``nextRunAt`` snapshot from the database; fall
    back to recomputing from the schedule when that snapshot is missing.
    """
    if not isinstance(entry, dict) or not entry.get("enabled", True):
        return None

    next_run = entry.get("nextRunAt")
    if next_run is not None:
        try:
            ts = float(next_run)
            if ts > time.time():
                return ts
        except (ValueError, TypeError):
            pass

    next_run_ms = entry.get("nextRunAtMs")
    if next_run_ms is not None:
        try:
            ts = float(next_run_ms) / 1000.0
            if ts > time.time():
                return ts
        except (ValueError, TypeError):
            pass

    schedule = entry.get("schedule", {})
    tz_name = entry.get("tz") or schedule.get("tz")
    return _compute_next_run(schedule, tz_name)


def _earliest_next_run(cron_schedules: list) -> float:
    """Find the soonest next-run across all enabled cron schedules."""
    earliest = None
    for entry in cron_schedules:
        nxt = _entry_next_run(entry)
        if nxt is not None and (earliest is None or nxt < earliest):
            earliest = nxt
    return earliest


async def cron_wakeup_loop(interval: int = 0):
    """Main loop: resume paused on-demand sandboxes before their cron fires."""
    interval = interval or CRON_WAKEUP_INTERVAL
    logger.info(
        "Cron wakeup scheduler started (interval=%ds, lead=%ds)",
        interval,
        CRON_WAKEUP_LEAD_TIME,
    )
    while True:
        try:
            await asyncio.sleep(interval)
            if not db_available():
                continue

            now = time.time()
            expired = [k for k, t in _recently_resumed.items() if now - t > CRON_RESUME_COOLDOWN]
            for k in expired:
                _recently_resumed.pop(k, None)
            # Safety cap: if dict grows beyond 10k entries, clear oldest half
            if len(_recently_resumed) > 10000:
                by_time = sorted(_recently_resumed.items(), key=lambda x: x[1])
                for k, _ in by_time[: len(by_time) // 2]:
                    _recently_resumed.pop(k, None)

            offset = 0
            live_cache: dict[str, dict[str, str]] = {}
            state_cache: dict[str, object] = {}
            while True:
                entries = await asyncio.to_thread(
                    db_list_on_demand_active, MONITOR_PAGE_SIZE, offset
                )
                if not entries:
                    break

                candidates = [
                    e
                    for e in entries
                    if e.on_demand_config
                    and e.on_demand_config.cron_schedules
                    and e.sandbox_id_prefix not in _recently_resumed
                ]

                if candidates:
                    # Reuse cached key to avoid redundant DB lookups
                    api_key = next(iter(live_cache), None)
                    if api_key is None:
                        api_key = await asyncio.to_thread(
                            db_get_api_key, candidates[0].sandbox_id_prefix
                        )
                    if api_key and api_key not in live_cache:
                        live = await asyncio.to_thread(SandboxManager.list_app_sandboxes, api_key)
                        live_cache[api_key] = {to_prefix(s.sandbox_id): s.sandbox_id for s in live}
                        state_cache.update({to_prefix(s.sandbox_id): s.state for s in live})
                    prefix_map = live_cache.get(api_key, {}) if api_key else {}

                    tasks = [
                        _maybe_resume_limited(e, prefix_map, state_cache, api_key)
                        for e in candidates
                    ]
                    await asyncio.gather(*tasks, return_exceptions=True)

                if len(entries) < MONITOR_PAGE_SIZE:
                    break
                offset += MONITOR_PAGE_SIZE

        except asyncio.CancelledError:
            logger.info("Cron wakeup scheduler stopped")
            raise
        except Exception:
            logger.exception("Cron wakeup loop error")


async def _maybe_resume_limited(sbx, prefix_map, state_cache, api_key):
    async with _get_semaphore():
        await _maybe_resume(sbx, prefix_map, state_cache, api_key)


async def _maybe_resume(sbx, prefix_map, state_cache, api_key):
    """Resume a paused sandbox if its next cron job fires within the lead time."""
    prefix = sbx.sandbox_id_prefix
    sandbox_id = prefix_map.get(prefix)
    if not sandbox_id or not api_key:
        return

    if prefix in _recently_resumed:
        return

    state = state_cache.get(prefix)
    if state != SandboxState.PAUSED:
        return

    try:
        raw = sbx.on_demand_config.cron_schedules
        schedules = json.loads(raw) if isinstance(raw, str) else raw
        if not isinstance(schedules, list) or not schedules:
            return
    except (json.JSONDecodeError, TypeError):
        return

    earliest = _earliest_next_run(schedules)
    if earliest is None:
        return

    seconds_until = earliest - time.time()
    if seconds_until > CRON_WAKEUP_LEAD_TIME:
        logger.debug(
            "Sandbox %s next cron in %ds — not yet (lead=%ds)",
            sandbox_id,
            int(seconds_until),
            CRON_WAKEUP_LEAD_TIME,
        )
        return

    logger.info(
        "Sandbox %s cron fires in %ds — resuming (lead=%ds)",
        sandbox_id,
        int(seconds_until),
        CRON_WAKEUP_LEAD_TIME,
    )
    manager = None
    try:
        manager = SandboxManager(api_key=api_key)
        await asyncio.to_thread(manager.connect, sandbox_id)
        _recently_resumed[prefix] = time.time()
        logger.info("Sandbox %s resumed for upcoming cron job", sandbox_id)
    except Exception:
        logger.exception("Failed to resume sandbox %s for cron", sandbox_id)
    finally:
        # Release SDK connection reference
        if manager is not None:
            manager._sandbox = None
