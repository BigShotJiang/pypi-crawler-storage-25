"""Sandbox operations wrapper."""

import importlib
import logging
from typing import Optional

from .const import MODE_GATEWAY, SANDBOX_APP_LABEL, SDK_PACKAGE, TYPE_ALWAYS_ON, TYPE_ON_DEMAND
from .errors import SandboxConnectError, SandboxCreateError, SandboxPauseError

logger = logging.getLogger(__name__)

# Dynamic SDK import based on brand config
_sandbox_mod = importlib.import_module(SDK_PACKAGE + ".code_interpreter")
_api_mod = importlib.import_module(SDK_PACKAGE + ".core.sandbox.sandbox_api")
_state_mod = importlib.import_module(SDK_PACKAGE + ".core.api.client.models.sandbox_state")
Sandbox = _sandbox_mod.Sandbox
SandboxQuery = _api_mod.SandboxQuery
SandboxState = _state_mod.SandboxState

SANDBOX_METADATA = {"app": SANDBOX_APP_LABEL, "long_running": "true"}
SANDBOX_KEEP_ALIVE = 50 * 365 * 24 * 3600  # 50 years, effectively permanent


class SandboxManager:
    """Manages sandbox instances for OpenClaw."""

    def __init__(self, template_id: str = None, api_key: str = None):
        self.template_id = template_id
        self._api_key = api_key
        self._sandbox: Optional[Sandbox] = None

    def _api_opts(self) -> dict:
        """Return api_key kwarg if set, for passing to SDK calls."""
        if self._api_key:
            return {"api_key": self._api_key}
        return {}

    def create(
        self,
        template_id: str = None,
        timeout: int = None,
        mode: str = MODE_GATEWAY,
        display_name: str = None,
        sandbox_type: str = TYPE_ALWAYS_ON,
        idle_timeout: int = None,
    ) -> Sandbox:
        tid = template_id or self.template_id
        if not tid:
            raise SandboxCreateError("No template ID provided. Build a template first.")
        try:
            metadata = dict(SANDBOX_METADATA)
            metadata["mode"] = mode
            if display_name:
                metadata["display_name"] = display_name
            create_kwargs = dict(
                timeout=timeout,
                metadata=metadata,
                **self._api_opts(),
            )
            if sandbox_type == TYPE_ON_DEMAND:
                metadata["on_demand"] = "true"
                metadata["auto_resume"] = "true"
                create_kwargs["auto_pause"] = True
            self._sandbox = Sandbox.create(tid, **create_kwargs)
        except Exception as e:
            raise SandboxCreateError(f"Failed to create sandbox: {e}") from e
        return self._sandbox

    def connect(self, sandbox_id: str) -> Sandbox:
        try:
            self._sandbox = Sandbox.connect(
                sandbox_id, timeout=SANDBOX_KEEP_ALIVE, **self._api_opts()
            )
            return self._sandbox
        except Exception as e:
            raise SandboxConnectError(f"Failed to connect to sandbox {sandbox_id}: {e}") from e

    def run_command(
        self,
        command: str,
        timeout: int = 30,
        background: bool = False,
        envs: dict = None,
        silent: bool = False,
    ):
        if not self._sandbox:
            if not silent:
                logger.error("No active sandbox. Create or connect first.")
            return None
        try:
            result = self._sandbox.commands.run(
                command,
                timeout=timeout,
                background=background,
                envs=envs,
            )
            return result
        except Exception as e:
            if not silent:
                logger.error(f"Command failed: {e}")
            return None

    def write_file(self, path: str, content: str):
        if not self._sandbox:
            logger.error("No active sandbox.")
            return
        self._sandbox.files.write(path, content)

    def read_file(self, path: str) -> Optional[str]:
        if not self._sandbox:
            logger.error("No active sandbox.")
            return None
        try:
            return self._sandbox.files.read(path)
        except Exception as e:
            if "not exist" in str(e) or "NotFound" in type(e).__name__:
                return None
            raise

    def upload_file(self, local_path: str, sandbox_path: str):
        if not self._sandbox:
            logger.error("No active sandbox.")
            return
        with open(local_path, "rb") as f:
            self._sandbox.files.write(sandbox_path, f)
        logger.info(f"Uploaded {local_path} -> {sandbox_path}")

    def get_status(self) -> Optional[str]:
        if not self._sandbox:
            return None
        try:
            result = self._sandbox.commands.run("echo ok", timeout=5)
            return "running" if result else "unknown"
        except Exception:
            return "unreachable"

    def pause(self):
        if not self._sandbox:
            raise SandboxPauseError("No active sandbox to pause.")
        sandbox_id = self._sandbox.sandbox_id
        try:
            self._sandbox.beta_pause(**self._api_opts())
        except Exception as e:
            raise SandboxPauseError(f"Failed to pause sandbox {sandbox_id}: {e}") from e
        logger.info(f"Sandbox paused: {sandbox_id}")

    def kill(self):
        if not self._sandbox:
            logger.error("No active sandbox.")
            return
        sandbox_id = self._sandbox.sandbox_id
        try:
            self._sandbox.kill(**self._api_opts())
        except Exception as e:
            logger.warning(f"Error during sandbox termination: {e}")
        logger.info(f"Sandbox terminated: {sandbox_id}")
        self._sandbox = None

    def get_info(self):
        """Get full sandbox info via SDK get_info() API."""
        if not self._sandbox:
            return None
        try:
            return self._sandbox.get_info(**self._api_opts())
        except Exception as e:
            logger.warning(f"Failed to get sandbox info: {e}")
            return None

    @property
    def sandbox(self) -> Optional[Sandbox]:
        return self._sandbox

    @property
    def sandbox_id(self) -> Optional[str]:
        return self._sandbox.sandbox_id if self._sandbox else None

    @staticmethod
    def get_sandbox_info(sandbox_id: str, api_key: str = None):
        """Get sandbox info without connecting (does not resume paused sandboxes)."""
        opts = {"api_key": api_key} if api_key else {}
        try:
            return Sandbox.get_info(sandbox_id, **opts)
        except Exception as e:
            raise SandboxConnectError(f"Failed to get info for sandbox {sandbox_id}: {e}") from e

    @staticmethod
    def list_app_sandboxes(api_key: str = None) -> list:
        query = SandboxQuery(
            metadata=SANDBOX_METADATA,
            state=[SandboxState.RUNNING, SandboxState.PAUSED],
        )
        opts = {"api_key": api_key} if api_key else {}
        paginator = Sandbox.list(query=query, **opts)
        sandboxes = []
        while paginator.has_next:
            sandboxes.extend(paginator.next_items())
        return sandboxes
