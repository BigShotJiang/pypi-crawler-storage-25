"""Error handling middleware for the API Server."""

import logging

from fastapi import Request
from fastapi.responses import JSONResponse

from .errors import ServerError

logger = logging.getLogger(__name__)


async def server_error_handler(request: Request, exc: ServerError) -> JSONResponse:
    """Convert ServerError to JSON response with appropriate HTTP status."""
    logger.error("[%s] %s %s — %s", exc.error_code, request.method, request.url.path, exc)
    content = {
        "status": "error",
        "error_code": exc.error_code,
        "message": str(exc),
    }
    if exc.remediation:
        content["remediation"] = exc.remediation
    return JSONResponse(status_code=exc.http_status, content=content)


async def generic_error_handler(request: Request, exc: Exception) -> JSONResponse:
    """Convert unhandled exceptions to 500 JSON response."""
    logger.exception("Unhandled error: %s", exc)
    return JSONResponse(
        status_code=500,
        content={
            "status": "error",
            "error_code": "INTERNAL_ERROR",
            "message": "An unexpected error occurred.",
        },
    )
