"""Sandbox configuration endpoints."""

import json
import logging

from fastapi import APIRouter, Depends

from ..const import (
    AGENT_CONFIG_PATH,
    MAX_IDLE_TIMEOUT,
    MAX_TIMEOUT,
    MIN_IDLE_TIMEOUT,
    MIN_TIMEOUT,
    TYPE_ON_DEMAND,
    agent_check_interval,
)
from ..database import db_available, db_get_sandbox, db_update_on_demand_config, decrypt_api_key
from ..deps import get_api_key
from ..errors import ConfigError
from ..sandbox import SandboxManager, SandboxState
from ..schemas import ConfigSetRequest, ConfigSetResponse
from ._helpers import connect_sandbox

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/sandboxes", tags=["config"])

_SUPPORTED_KEYS = {"idle-timeout", "timeout"}


@router.post("/{sandbox_id}/config", response_model=ConfigSetResponse)
def config_set(
    sandbox_id: str,
    body: ConfigSetRequest,
    api_key: str = Depends(get_api_key),
):
    """Update a sandbox configuration value."""
    key = body.key
    value = body.value

    if key not in _SUPPORTED_KEYS:
        raise ConfigError(
            "Unsupported key '{key}'. Supported keys: {keys}".format(
                key=key, keys=", ".join(sorted(_SUPPORTED_KEYS))
            )
        )

    if not db_available():
        raise ConfigError("Database not configured — on-demand features unavailable.")

    entry = db_get_sandbox(sandbox_id)
    if not entry or entry.sandbox_type != TYPE_ON_DEMAND:
        raise ConfigError("Sandbox '{id}' is not an on-demand sandbox.".format(id=sandbox_id))

    # Verify the caller owns this sandbox
    stored_key = decrypt_api_key(entry.api_key_encrypted)
    if stored_key != api_key:
        raise ConfigError("Not authorized to modify sandbox '{id}'.".format(id=sandbox_id))

    if key == "idle-timeout":
        return _set_idle_timeout(sandbox_id, value, api_key)
    elif key == "timeout":
        return _set_timeout(sandbox_id, value, api_key)


def _set_idle_timeout(sandbox_id: str, value: str, api_key: str):
    try:
        idle_timeout = int(value)
    except ValueError as e:
        raise ConfigError("idle-timeout must be an integer, got '{v}'.".format(v=value)) from e

    if idle_timeout < MIN_IDLE_TIMEOUT:
        raise ConfigError(
            "idle-timeout must be at least {min} seconds.".format(min=MIN_IDLE_TIMEOUT)
        )
    if idle_timeout > MAX_IDLE_TIMEOUT:
        raise ConfigError(
            "idle-timeout must be at most {max} seconds.".format(max=MAX_IDLE_TIMEOUT)
        )

    # Update DB
    db_update_on_demand_config(sandbox_id, idle_timeout=idle_timeout)

    # Update agent config in sandbox (skip if paused to avoid triggering resume)
    try:
        info = SandboxManager.get_sandbox_info(sandbox_id, api_key)
        if info.state == SandboxState.PAUSED:
            logger.info("Sandbox %s is paused — config saved to DB only", sandbox_id)
        else:
            manager = connect_sandbox(sandbox_id, api_key)
            check_interval = agent_check_interval(idle_timeout)
            config = json.dumps({"idle_timeout": idle_timeout, "check_interval": check_interval})
            manager.write_file(AGENT_CONFIG_PATH, config)
            logger.info("Updated agent config for %s: idle_timeout=%d", sandbox_id, idle_timeout)
    except Exception as e:
        logger.warning("Failed to update agent config in sandbox: %s", e)

    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "key": "idle-timeout",
        "value": str(idle_timeout),
        "message": "Idle timeout updated to {t}s".format(t=idle_timeout),
    }


def _set_timeout(sandbox_id: str, value: str, api_key: str):
    try:
        timeout = int(value)
    except ValueError as e:
        raise ConfigError("timeout must be an integer, got '{v}'.".format(v=value)) from e

    if timeout < MIN_TIMEOUT:
        raise ConfigError("timeout must be at least {min} seconds.".format(min=MIN_TIMEOUT))
    if timeout > MAX_TIMEOUT:
        raise ConfigError("timeout must be at most {max} seconds.".format(max=MAX_TIMEOUT))

    # Update DB
    db_update_on_demand_config(sandbox_id, timeout=timeout)

    # Update sandbox timeout via SDK (skip if paused to avoid triggering resume)
    try:
        info = SandboxManager.get_sandbox_info(sandbox_id, api_key)
        if info.state == SandboxState.PAUSED:
            logger.info("Sandbox %s is paused — config saved to DB only", sandbox_id)
        else:
            manager = connect_sandbox(sandbox_id, api_key)
            manager.sandbox.set_timeout(timeout)
            logger.info("Updated sandbox timeout for %s: %d", sandbox_id, timeout)
    except Exception as e:
        logger.warning("Failed to update sandbox timeout: %s", e)

    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "key": "timeout",
        "value": str(timeout),
        "message": "Timeout updated to {t}s".format(t=timeout),
    }
