"""Sandbox CRUD endpoints."""

import json
import logging
import pathlib

from fastapi import APIRouter, Depends

from ..const import (
    AGENT_CONFIG_PATH,
    AGENT_LOG_PATH,
    AGENT_SCRIPT_FILE,
    AGENT_SCRIPT_PATH,
    AGENT_STATUS_PATH,
    DEFAULT_IDLE_TIMEOUT,
    FEISHU_WEBHOOK_PATH,
    FEISHU_WEBHOOK_PORT,
    FILE_MANAGER_PORT,
    MIN_IDLE_TIMEOUT,
    MODE_GATEWAY,
    MODE_NODE,
    SERVICES_USERNAME,
    TEMPLATE_ID,
    TTYD_PORT,
    TYPE_ALWAYS_ON,
    TYPE_ON_DEMAND,
    agent_check_interval,
    default_node_name,
)
from ..database import (
    db_available,
    db_get_sandbox,
    db_register_sandbox,
    db_unregister_sandbox,
    decrypt_token,
)
from ..deps import get_api_key
from ..errors import SandboxConnectError, SandboxResumeError, ServerError
from ..logging import sandbox_id_var
from ..openclaw import (
    GATEWAY_PORT,
    configure_openclaw,
    gateway_operation,
    get_gateway_token,
    get_public_urls,
    launch_gateway,
    wait_for_gateway,
)
from ..sandbox import SANDBOX_KEEP_ALIVE, SandboxManager, SandboxState
from ..schemas import (
    LaunchRequest,
    MessageResponse,
    SandboxListResponse,
    SandboxResponse,
)
from ..services import configure_services, get_service_credentials, get_service_urls
from ._helpers import build_webui_url, connect_sandbox

logger = logging.getLogger(__name__)

_AGENT_SCRIPT_PATH = pathlib.Path(__file__).resolve().parent.parent / "scripts" / AGENT_SCRIPT_FILE
_AGENT_SCRIPT = None

router = APIRouter(prefix="/sandboxes", tags=["sandboxes"])


def _state_str(state) -> str:
    """Convert a SandboxState enum (or fallback) to a plain string."""
    return str(state.value) if hasattr(state, "value") else str(state)


def _get_sandbox_metadata(manager: SandboxManager) -> dict:
    """Get sandbox metadata via get_info() API."""
    info = manager.get_info()
    if info:
        return getattr(info, "metadata", None) or {}
    return {}


def _detect_mode_from_meta(meta: dict) -> str:
    """Extract sandbox mode from a metadata dict, defaulting to 'gateway'."""
    mode = meta.get("mode")
    return mode if mode in (MODE_GATEWAY, MODE_NODE) else MODE_GATEWAY


def _build_urls_from_info(sandbox_id: str, sandbox_domain: str, mode: str) -> dict:
    """Build service URLs from sandbox info without connecting (no resume)."""

    def _host(port):
        return "{port}-{sid}.{domain}".format(port=port, sid=sandbox_id, domain=sandbox_domain)

    urls = {}
    if mode == MODE_GATEWAY:
        gw_host = _host(GATEWAY_PORT)
        urls["gateway_ws"] = "wss://{h}".format(h=gw_host)
        urls["webui"] = "https://{h}".format(h=gw_host)
        urls["feishu_webhook_url"] = "https://{h}{p}".format(
            h=_host(FEISHU_WEBHOOK_PORT), p=FEISHU_WEBHOOK_PATH
        )
    urls["terminal_url"] = "https://{h}".format(h=_host(TTYD_PORT))
    urls["filemanager_url"] = "https://{h}".format(h=_host(FILE_MANAGER_PORT))
    return urls


@router.post("", response_model=SandboxResponse)
def create_sandbox(body: LaunchRequest, api_key: str = Depends(get_api_key)):
    """Create a new sandbox (mirrors CLI launch flow)."""
    template_id = body.template_id or TEMPLATE_ID
    sandbox_type = body.sandbox_type
    idle_timeout = body.idle_timeout

    if body.mode == MODE_NODE and sandbox_type == TYPE_ON_DEMAND:
        raise ServerError(
            "On-demand mode is not supported with node sandboxes.",
            error_code="INVALID_COMBINATION",
            http_status=400,
            remediation="Use --type always-on with --mode node, "
            "or use --mode gateway with --type on-demand.",
        )

    # Resolve idle_timeout default for on-demand
    if sandbox_type == TYPE_ON_DEMAND:
        if idle_timeout is None:
            idle_timeout = DEFAULT_IDLE_TIMEOUT
        elif idle_timeout < MIN_IDLE_TIMEOUT:
            idle_timeout = MIN_IDLE_TIMEOUT

    manager = SandboxManager(template_id, api_key=api_key)
    sandbox = manager.create(
        timeout=body.timeout,
        mode=body.mode,
        display_name=body.display_name,
        sandbox_type=sandbox_type,
        idle_timeout=idle_timeout,
    )
    sandbox_id_var.set(sandbox.sandbox_id)
    logger.info("Sandbox %s created (mode=%s)", sandbox.sandbox_id, body.mode)
    sandbox.set_timeout(SANDBOX_KEEP_ALIVE)

    try:
        if body.mode == MODE_NODE:
            node_name = body.display_name or default_node_name(sandbox.sandbox_id)
            result = _launch_node(manager, sandbox, node_name)
        else:
            result = _launch_gateway(manager, sandbox, api_key)

        # Register in DB (save domain + gateway_token + credentials for paused status)
        if db_available():
            db_register_sandbox(
                sandbox.sandbox_id,
                api_key,
                sandbox_type,
                body.mode,
                idle_timeout,
                timeout=body.timeout,
                sandbox_domain=sandbox.sandbox_domain,
                gateway_token=result.get("gateway_token"),
                services_password=result.get("services_password"),
            )

        # Deploy agent for on-demand sandboxes
        if sandbox_type == TYPE_ON_DEMAND:
            _deploy_agent(manager, idle_timeout)
            result["sandbox_type"] = TYPE_ON_DEMAND
            result["idle_timeout"] = idle_timeout
        else:
            result["sandbox_type"] = TYPE_ALWAYS_ON

        return result
    except Exception:
        manager.kill()
        raise


def _launch_gateway(manager, sandbox, api_key):
    with gateway_operation(manager):
        configure_openclaw(manager, api_key)
        launch_gateway(manager)
        service_creds = configure_services(manager)
        wait_for_gateway(manager)
        urls = get_public_urls(manager)
        gw_token = get_gateway_token(manager)
        service_urls = get_service_urls(manager)
        webui_url = build_webui_url(urls, gw_token)

        result = {
            "status": "ok",
            "sandbox_id": sandbox.sandbox_id,
            "mode": MODE_GATEWAY,
            "keep_alive": SANDBOX_KEEP_ALIVE,
            "webui": webui_url,
            "gateway_ws": urls["gateway_ws"],
            "feishu_webhook_url": "https://{h}{p}".format(
                h=manager.sandbox.get_host(FEISHU_WEBHOOK_PORT), p=FEISHU_WEBHOOK_PATH
            ),
            "terminal_url": service_urls["terminal"],
            "filemanager_url": service_urls["filemanager"],
            "services_username": service_creds["username"],
            "services_password": service_creds["password"],
        }
        if gw_token:
            result["gateway_token"] = gw_token
        return result


def _launch_node(manager, sandbox, display_name):
    # Node sandboxes only get services configured at launch time.
    # Gateway connection is done separately via POST /sandboxes/{id}/node/connect.
    service_creds = configure_services(manager)
    service_urls = get_service_urls(manager)

    return {
        "status": "ok",
        "sandbox_id": sandbox.sandbox_id,
        "mode": MODE_NODE,
        "node_display_name": display_name,
        "keep_alive": SANDBOX_KEEP_ALIVE,
        "terminal_url": service_urls["terminal"],
        "filemanager_url": service_urls["filemanager"],
        "services_username": service_creds["username"],
        "services_password": service_creds["password"],
    }


def _deploy_agent(manager: SandboxManager, idle_timeout: int):
    """Deploy the on-demand idle-monitoring agent into the sandbox."""
    global _AGENT_SCRIPT  # noqa: PLW0603
    if _AGENT_SCRIPT is None:
        _AGENT_SCRIPT = _AGENT_SCRIPT_PATH.read_text()

    # Inject brand-specific paths from const.py into the agent template.
    script = _AGENT_SCRIPT.replace("__AGENT_CONFIG_PATH__", AGENT_CONFIG_PATH)
    script = script.replace("__AGENT_STATUS_PATH__", AGENT_STATUS_PATH)

    check_interval = agent_check_interval(idle_timeout)
    config = json.dumps({"idle_timeout": idle_timeout, "check_interval": check_interval})
    try:
        manager.write_file(AGENT_SCRIPT_PATH, script)
        manager.write_file(AGENT_CONFIG_PATH, config)
        manager.run_command(
            "nohup python3 {script} > {log} 2>&1 &".format(
                script=AGENT_SCRIPT_PATH, log=AGENT_LOG_PATH
            ),
            timeout=10,
            background=True,
        )
        logger.info("On-demand agent deployed in sandbox %s", manager.sandbox_id)
    except Exception as e:
        logger.warning("Failed to deploy on-demand agent: %s", e)


def _sandbox_type_from_meta(meta: dict) -> str:
    """Extract sandbox type from metadata."""
    return TYPE_ON_DEMAND if meta.get("on_demand") == "true" else TYPE_ALWAYS_ON


@router.get("", response_model=SandboxListResponse)
def list_sandboxes(api_key: str = Depends(get_api_key)):
    """List all active sandboxes."""
    sandboxes = SandboxManager.list_app_sandboxes(api_key=api_key)
    items = []
    for sbx in sandboxes:
        meta = sbx.metadata if hasattr(sbx, "metadata") and sbx.metadata else {}
        items.append(
            {
                "sandbox_id": sbx.sandbox_id,
                "state": _state_str(sbx.state),
                "mode": meta.get("mode", MODE_GATEWAY),
                "sandbox_type": _sandbox_type_from_meta(meta),
                "cpu": sbx.cpu_count,
                "memory_mb": sbx.memory_mb,
                "started_at": sbx.started_at.isoformat(),
            }
        )
    return {"status": "ok", "sandboxes": items}


@router.get("/{sandbox_id}", response_model=SandboxResponse)
def get_sandbox(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Get sandbox status and access URLs (mirrors CLI status flow).

    For paused sandboxes this returns basic info without connecting,
    so it will NOT resume the sandbox.
    """
    # Fetch info without connecting to avoid resuming paused sandboxes
    info = SandboxManager.get_sandbox_info(sandbox_id, api_key=api_key)
    meta = info.metadata if info.metadata else {}
    mode = _detect_mode_from_meta(meta)

    stype = _sandbox_type_from_meta(meta)
    result = {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "mode": mode,
        "sandbox_type": stype,
        "state": _state_str(info.state),
    }

    # Fetch DB entry for saved domain, gateway_token, and on-demand config
    db_entry = db_get_sandbox(sandbox_id) if db_available() else None

    if stype == TYPE_ON_DEMAND and db_entry and db_entry.on_demand_config:
        result["idle_timeout"] = db_entry.on_demand_config.idle_timeout

    if mode == MODE_NODE:
        result["node_display_name"] = meta.get("display_name", default_node_name(sandbox_id))

    # Paused sandboxes: include URLs (constructed from domain) but add notice
    if info.state == SandboxState.PAUSED:
        domain = info.sandbox_domain or (db_entry.sandbox_domain if db_entry else None)
        if domain:
            _apply_db_urls(result, sandbox_id, domain, mode, db_entry)
        result["paused_notice"] = "Sandbox is paused. Resume to access these URLs."
        return result

    # Running sandbox: prefer DB info (avoids expensive connect call)
    if db_entry and db_entry.sandbox_domain:
        _apply_db_urls(result, sandbox_id, db_entry.sandbox_domain, mode, db_entry)
        return result

    # Fallback: connect to sandbox directly (old sandboxes without DB record)
    return _status_from_connect(result, sandbox_id, api_key, mode)


def _apply_db_urls(result: dict, sandbox_id: str, domain: str, mode: str, db_entry) -> None:
    """Populate URLs, credentials, and tokens from saved DB data."""
    result.update(_build_urls_from_info(sandbox_id, domain, mode))
    if mode == MODE_GATEWAY and db_entry and db_entry.gateway_token_encrypted:
        gw_token = decrypt_token(db_entry.gateway_token_encrypted)
        if gw_token:
            result["gateway_token"] = gw_token
            result["webui"] = build_webui_url(result, gw_token)
    if db_entry and db_entry.services_password_encrypted:
        svc_pw = decrypt_token(db_entry.services_password_encrypted)
        if svc_pw:
            result["services_username"] = SERVICES_USERNAME
            result["services_password"] = svc_pw


def _status_from_connect(result: dict, sandbox_id: str, api_key: str, mode: str) -> dict:
    """Build running-sandbox status by connecting (fallback for old sandboxes)."""
    manager = connect_sandbox(sandbox_id, api_key)

    if mode == MODE_GATEWAY:
        urls = get_public_urls(manager)
        gw_token = get_gateway_token(manager)
        webui_url = build_webui_url(urls, gw_token)
        result["webui"] = webui_url
        result["gateway_ws"] = urls["gateway_ws"]
        if gw_token:
            result["gateway_token"] = gw_token
        feishu_host = manager.sandbox.get_host(FEISHU_WEBHOOK_PORT)
        result["feishu_webhook_url"] = "https://{h}{p}".format(h=feishu_host, p=FEISHU_WEBHOOK_PATH)

    service_creds = get_service_credentials(manager)
    service_urls = get_service_urls(manager) if service_creds else {}
    if service_urls:
        result["terminal_url"] = service_urls["terminal"]
        result["filemanager_url"] = service_urls["filemanager"]
    if service_creds:
        result["services_username"] = service_creds["username"]
        result["services_password"] = service_creds["password"]
    return result


@router.post("/{sandbox_id}/pause", response_model=MessageResponse)
def pause_sandbox(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Pause a running sandbox. All filesystem and memory state are preserved."""
    manager = connect_sandbox(sandbox_id, api_key)
    manager.pause()
    return {"status": "ok", "sandbox_id": sandbox_id, "message": "Sandbox paused"}


@router.post("/{sandbox_id}/resume", response_model=MessageResponse)
def resume_sandbox(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Resume a paused sandbox."""
    try:
        connect_sandbox(sandbox_id, api_key)
    except SandboxConnectError as e:
        raise SandboxResumeError(str(e)) from e
    return {"status": "ok", "sandbox_id": sandbox_id, "message": "Sandbox resumed"}


@router.delete("/{sandbox_id}", response_model=MessageResponse)
def delete_sandbox(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Stop and terminate a sandbox."""
    manager = connect_sandbox(sandbox_id, api_key)
    manager.kill()
    if db_available():
        db_unregister_sandbox(sandbox_id)
    return {"status": "ok", "sandbox_id": sandbox_id, "message": "Sandbox terminated"}
