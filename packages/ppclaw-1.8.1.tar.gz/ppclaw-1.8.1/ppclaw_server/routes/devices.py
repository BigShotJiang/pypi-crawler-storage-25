"""Device management endpoints (gateway-side node pairing)."""

import json
import shlex

from fastapi import APIRouter, Depends

from ..deps import get_api_key
from ..errors import DeviceError
from ..openclaw import OPENCLAW_CONFIG_PATH
from ..sandbox import SandboxManager
from ..schemas import DeviceApproveRequest
from ._helpers import connect_sandbox

router = APIRouter(prefix="/sandboxes/{sandbox_id}/devices", tags=["devices"])


def _run_devices_cmd(manager: SandboxManager, raw_cmd: str) -> str:
    cmd = "OPENCLAW_CONFIG_PATH={config} {raw}".format(
        config=OPENCLAW_CONFIG_PATH,
        raw=raw_cmd,
    )
    result = manager.run_command(cmd, timeout=30)
    if result is None:
        raise DeviceError(
            "Device command failed to execute. "
            "Check sandbox connectivity and that openclaw is installed."
        )
    output = result.stdout.strip() if result.stdout else ""
    if hasattr(result, "exit_code") and result.exit_code != 0:
        raise DeviceError(
            output
            or "Device command failed (exit code {code}).".format(
                code=result.exit_code,
            )
        )
    return output


@router.get("")
def devices_list(
    sandbox_id: str,
    json: bool = False,
    api_key: str = Depends(get_api_key),
):
    """List all devices (paired and pending) on the gateway."""
    manager = connect_sandbox(sandbox_id, api_key)
    cmd = "openclaw devices list --json 2>&1" if json else "openclaw devices list 2>&1"
    output_text = _run_devices_cmd(manager, cmd)
    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "output": output_text,
    }


def _approve_one(manager: SandboxManager, rid: str) -> str:
    return _run_devices_cmd(
        manager,
        "openclaw devices approve {rid} 2>&1".format(rid=shlex.quote(rid)),
    )


@router.post("/approve")
def devices_approve(
    sandbox_id: str,
    body: DeviceApproveRequest,
    api_key: str = Depends(get_api_key),
):
    """Approve a pending device. If request_id is omitted, approves all pending devices."""
    manager = connect_sandbox(sandbox_id, api_key)

    if body.request_id:
        output_text = _approve_one(manager, body.request_id)
        return {
            "status": "ok",
            "sandbox_id": sandbox_id,
            "approved": [body.request_id],
            "output": output_text,
        }

    # No request_id — find and approve all pending devices
    list_output = _run_devices_cmd(manager, "openclaw devices list --json 2>&1")
    pending_ids = _parse_pending_request_ids(list_output)

    if not pending_ids:
        return {
            "status": "ok",
            "sandbox_id": sandbox_id,
            "approved": [],
            "output": "No pending devices found.",
        }

    outputs = [_approve_one(manager, rid) for rid in pending_ids]

    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "approved": pending_ids,
        "output": "\n".join(outputs),
    }


def _parse_pending_request_ids(json_text: str) -> list:
    """Extract requestId values from pending devices in JSON output."""
    try:
        data = json.loads(json_text)
    except (json.JSONDecodeError, ValueError):
        return []

    # Handle both list and dict formats
    items = []
    if isinstance(data, list):
        items = data
    elif isinstance(data, dict):
        items = data.get("pending", data.get("devices", []))

    return [
        item["requestId"]
        for item in items
        if isinstance(item, dict)
        and item.get("requestId")
        and item.get("status", "pending").lower() in ("pending", "")
    ]
