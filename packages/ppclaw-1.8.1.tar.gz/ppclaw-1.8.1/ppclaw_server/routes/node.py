"""Node connect/disconnect/status endpoints."""

import logging

from fastapi import APIRouter, Depends

from ..const import default_node_name
from ..deps import get_api_key
from ..openclaw import (
    check_node_status,
    launch_node,
    reconnect_node,
    stop_node,
    wait_for_node,
)
from ..routes.sandboxes import _get_sandbox_metadata
from ..schemas import NodeConnectRequest, NodeResponse, NodeStatusResponse
from ._helpers import connect_sandbox

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/sandboxes/{sandbox_id}/node", tags=["node"])


def _get_display_name(manager, sandbox_id: str) -> str:
    """Read node display name from sandbox metadata."""
    meta = _get_sandbox_metadata(manager)
    return meta.get("display_name", default_node_name(sandbox_id))


@router.post("/connect", response_model=NodeResponse)
def node_connect(sandbox_id: str, body: NodeConnectRequest, api_key: str = Depends(get_api_key)):
    """Connect a node sandbox to a gateway.

    Launches the node process and waits for it to stabilise.  Pairing
    detection is left to the caller — poll GET /node/status until
    ``paired`` is true.
    """
    manager = connect_sandbox(sandbox_id, api_key)
    display_name = _get_display_name(manager, sandbox_id)

    # Stop any existing node process before starting a new one
    stop_node(manager)

    launch_node(manager, body.gateway_url, display_name, gateway_token=body.gateway_token or "")
    wait_for_node(manager)

    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "node_display_name": display_name,
        "gateway_url": body.gateway_url,
        "message": "Node started, waiting for pairing",
    }


@router.get("/status", response_model=NodeStatusResponse)
def node_status(sandbox_id: str, gateway_url: str, api_key: str = Depends(get_api_key)):
    """Check node process and pairing status.

    Pass the same ``gateway_url`` used in /connect so the server can
    check for an established TCP connection to the gateway port.
    ``paired`` is true when the connection is up (pairing complete).
    """
    manager = connect_sandbox(sandbox_id, api_key)
    status = check_node_status(manager, gateway_url)
    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "alive": status["alive"],
        "paired": status["paired"],
    }


@router.post("/reconnect", response_model=NodeResponse)
def node_reconnect(sandbox_id: str, body: NodeConnectRequest, api_key: str = Depends(get_api_key)):
    """Lightweight reconnect: re-run node if process has died.

    Used by the CLI poll loop when the node process is no longer alive.
    """
    manager = connect_sandbox(sandbox_id, api_key)
    display_name = _get_display_name(manager, sandbox_id)
    logger.info("Reconnect requested for sandbox %s", sandbox_id)
    reconnect_node(manager, body.gateway_url, display_name, gateway_token=body.gateway_token or "")
    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "node_display_name": display_name,
        "gateway_url": body.gateway_url,
        "message": "Node reconnecting",
    }


@router.post("/disconnect", response_model=NodeResponse)
def node_disconnect(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Disconnect a node from its gateway (stops the openclaw node process)."""
    manager = connect_sandbox(sandbox_id, api_key)
    stop_node(manager)

    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "message": "Node disconnected from gateway",
    }
