"""Gateway management endpoints."""

from fastapi import APIRouter, Depends, Query

from ..deps import get_api_key
from ..errors import DoctorError
from ..openclaw import (
    OPENCLAW_CONFIG_PATH,
    get_gateway_token,
    get_public_urls,
    restart_gateway,
    start_gateway,
    stop_gateway,
    update_openclaw,
)
from ..sandbox import SandboxManager
from ._helpers import build_webui_url, connect_sandbox

router = APIRouter(prefix="/sandboxes/{sandbox_id}/gateway", tags=["gateway"])


def _gateway_response(manager: SandboxManager, sandbox_id: str, message: str, **extra) -> dict:
    """Build a standard gateway response with URLs and optional token."""
    urls = get_public_urls(manager)
    gw_token = get_gateway_token(manager)
    webui_url = build_webui_url(urls, gw_token)
    result = {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "message": message,
        "webui": webui_url,
        "gateway_ws": urls["gateway_ws"],
        **extra,
    }
    if gw_token:
        result["gateway_token"] = gw_token
    return result


@router.post("/start")
def gateway_start(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Start the OpenClaw Gateway."""
    manager = connect_sandbox(sandbox_id, api_key)
    start_gateway(manager)
    return _gateway_response(manager, sandbox_id, "Gateway started")


@router.post("/stop")
def gateway_stop(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Stop the OpenClaw Gateway."""
    manager = connect_sandbox(sandbox_id, api_key)
    stop_gateway(manager)
    return {"status": "ok", "sandbox_id": sandbox_id, "message": "Gateway stopped"}


@router.post("/restart")
def gateway_restart(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Restart the OpenClaw Gateway."""
    manager = connect_sandbox(sandbox_id, api_key)
    restart_gateway(manager)
    return _gateway_response(manager, sandbox_id, "Gateway restarted")


@router.post("/update")
def gateway_update(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Update OpenClaw and restart the gateway."""
    manager = connect_sandbox(sandbox_id, api_key)
    output_text = update_openclaw(manager)
    return _gateway_response(
        manager, sandbox_id, "Gateway updated", output=output_text, restarted=True
    )


@router.get("/doctor")
def gateway_doctor(
    sandbox_id: str,
    api_key: str = Depends(get_api_key),
    deep: bool = Query(False),
    fix: bool = Query(False),
    force: bool = Query(False),
    generate_gateway_token: bool = Query(False),
    no_workspace_suggestions: bool = Query(False),
    repair: bool = Query(False),
    yes: bool = Query(False),
):
    """Run OpenClaw doctor inside a sandbox."""
    manager = connect_sandbox(sandbox_id, api_key)

    cmd_parts = [
        "OPENCLAW_CONFIG_PATH={config}".format(config=OPENCLAW_CONFIG_PATH),
        "openclaw",
        "doctor",
        "--non-interactive",
    ]
    flags = {
        "--deep": deep,
        "--fix": fix,
        "--force": force,
        "--generate-gateway-token": generate_gateway_token,
        "--no-workspace-suggestions": no_workspace_suggestions,
        "--repair": repair,
        "--yes": yes,
    }
    cmd_parts.extend(flag for flag, enabled in flags.items() if enabled)
    cmd = " ".join(cmd_parts) + " 2>&1"

    result = manager.run_command(cmd, timeout=120)
    if result is None:
        raise DoctorError(
            "Doctor command failed to execute in sandbox. "
            "Check sandbox connectivity and that openclaw is installed."
        )

    output_text = ""
    if result.stdout:
        output_text = result.stdout.strip()

    return {"status": "ok", "sandbox_id": sandbox_id, "output": output_text}
