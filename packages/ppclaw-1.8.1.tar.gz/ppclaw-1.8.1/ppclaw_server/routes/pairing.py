"""Pairing management endpoints."""

import json
import logging

from fastapi import APIRouter, Depends, Query

from ..deps import get_api_key
from ..errors import ChannelConfigError, PairingError
from ..openclaw import (
    OPENCLAW_CONFIG_PATH,
    gateway_operation,
    get_gateway_pid,
    restart_gateway,
    wait_for_gateway_auto_restart,
)
from ..sandbox import SandboxManager
from ..schemas import FeishuConfigRequest, FeishuConfigResponse, PairingApproveRequest
from ._helpers import connect_sandbox

router = APIRouter(prefix="/sandboxes/{sandbox_id}/pairing", tags=["pairing"])
logger = logging.getLogger(__name__)


def _run_pairing_cmd(manager: SandboxManager, raw_cmd: str) -> str:
    cmd = "OPENCLAW_CONFIG_PATH={config} {raw}; true".format(
        config=OPENCLAW_CONFIG_PATH,
        raw=raw_cmd,
    )
    result = manager.run_command(cmd, timeout=30)
    if result is None:
        raise PairingError(
            "Pairing command failed to execute. "
            "Check sandbox connectivity and that openclaw is installed."
        )
    return result.stdout.strip() if result.stdout else ""


@router.get("")
def pairing_list(
    sandbox_id: str,
    channel: str = Query(..., description="Channel name"),
    api_key: str = Depends(get_api_key),
):
    """List pending pairing requests for a channel."""
    manager = connect_sandbox(sandbox_id, api_key)

    output_text = _run_pairing_cmd(
        manager,
        "openclaw pairing list {channel} 2>&1".format(channel=channel),
    )
    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "channel": channel,
        "output": output_text,
    }


@router.post("/approve")
def pairing_approve(
    sandbox_id: str,
    body: PairingApproveRequest,
    api_key: str = Depends(get_api_key),
):
    """Approve a pending pairing request."""
    manager = connect_sandbox(sandbox_id, api_key)

    output_text = _run_pairing_cmd(
        manager,
        "openclaw pairing approve {channel} {code} 2>&1".format(
            channel=body.channel, code=body.code
        ),
    )
    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "channel": body.channel,
        "code": body.code,
        "output": output_text,
    }


@router.post("/feishu", response_model=FeishuConfigResponse)
def feishu_config(
    sandbox_id: str,
    body: FeishuConfigRequest,
    api_key: str = Depends(get_api_key),
):
    """Configure Feishu channel on a sandbox."""
    manager = connect_sandbox(sandbox_id, api_key)

    with gateway_operation(manager):
        try:
            content = manager.read_file(OPENCLAW_CONFIG_PATH)
            config = json.loads(content) if content else {}
        except Exception as exc:
            raise ChannelConfigError(
                "Failed to read openclaw.json. "
                "Ensure the sandbox is running and openclaw is installed."
            ) from exc

        previous_gateway_pid = get_gateway_pid(manager)

        feishu = {
            "appId": body.app_id,
            "appSecret": body.app_secret,
            "connectionMode": body.connection_mode,
            "dm": {"policy": body.dm_policy},
        }
        if body.connection_mode == "webhook":
            feishu["verificationToken"] = body.verification_token
            feishu["encryptKey"] = body.encrypt_key
            feishu["webhookHost"] = body.webhook_host
            feishu["webhookPort"] = body.webhook_port
            feishu["webhookPath"] = body.webhook_path

        config.setdefault("channels", {})["feishu"] = feishu

        try:
            manager.write_file(OPENCLAW_CONFIG_PATH, json.dumps(config, indent=2))
        except Exception as exc:
            raise ChannelConfigError("Failed to write openclaw.json.") from exc

        try:
            auto_restarted = wait_for_gateway_auto_restart(manager, previous_gateway_pid)
            if auto_restarted:
                logger.info(
                    "Feishu config applied via automatic gateway restart for sandbox %s",
                    sandbox_id,
                )
            else:
                logger.info(
                    "Automatic gateway restart not detected for sandbox %s; running manual restart",
                    sandbox_id,
                )
                restart_gateway(manager)
        except Exception as exc:
            logger.exception(
                "Gateway restart failed during Feishu config for sandbox %s",
                sandbox_id,
            )
            raise ChannelConfigError(
                "Feishu channel configured but gateway restart failed: {err}".format(err=exc)
            ) from exc

    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "channel": "feishu",
        "connection_mode": body.connection_mode,
        "message": "Feishu channel configured successfully.",
    }
