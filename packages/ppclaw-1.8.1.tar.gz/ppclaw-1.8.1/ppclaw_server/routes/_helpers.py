"""Shared helpers for route handlers."""

from ..sandbox import SandboxManager


def connect_sandbox(sandbox_id: str, api_key: str) -> SandboxManager:
    """Create a SandboxManager and connect to an existing sandbox."""
    manager = SandboxManager(api_key=api_key)
    manager.connect(sandbox_id)
    return manager


def build_webui_url(urls: dict, gw_token: str) -> str:
    """Append gateway token fragment to WebUI URL."""
    webui_url = urls["webui"]
    if gw_token:
        webui_url = "{base}#token={token}".format(base=webui_url, token=gw_token)
    return webui_url
