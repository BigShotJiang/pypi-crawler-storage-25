"""Service management endpoints (Web Terminal, File Manager)."""

from fastapi import APIRouter, Depends

from ..deps import get_api_key
from ..services import (
    check_services_running,
    configure_services,
    get_service_credentials,
    get_service_urls,
    install_services,
)
from ._helpers import connect_sandbox

router = APIRouter(prefix="/sandboxes/{sandbox_id}/services", tags=["services"])


@router.post("/setup")
def services_setup(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Install and start Web Terminal + File Manager."""
    manager = connect_sandbox(sandbox_id, api_key)

    existing_creds = get_service_credentials(manager)
    if existing_creds:
        if not check_services_running(manager):
            configure_services(manager, password=existing_creds["password"])
        service_urls = get_service_urls(manager)
        return {
            "status": "ok",
            "sandbox_id": sandbox_id,
            "terminal_url": service_urls["terminal"],
            "filemanager_url": service_urls["filemanager"],
            "services_username": existing_creds["username"],
            "services_password": existing_creds["password"],
            "already_configured": True,
        }

    install_services(manager)
    service_creds = configure_services(manager)
    service_urls = get_service_urls(manager)
    return {
        "status": "ok",
        "sandbox_id": sandbox_id,
        "terminal_url": service_urls["terminal"],
        "filemanager_url": service_urls["filemanager"],
        "services_username": service_creds["username"],
        "services_password": service_creds["password"],
        "already_configured": False,
    }


@router.get("")
def services_list(sandbox_id: str, api_key: str = Depends(get_api_key)):
    """Get service URLs and credentials."""
    manager = connect_sandbox(sandbox_id, api_key)

    service_creds = get_service_credentials(manager)
    service_urls = get_service_urls(manager) if service_creds else {}

    result = {"status": "ok", "sandbox_id": sandbox_id}
    if service_urls:
        result["terminal_url"] = service_urls["terminal"]
        result["filemanager_url"] = service_urls["filemanager"]
    if service_creds:
        result["services_username"] = service_creds["username"]
        result["services_password"] = service_creds["password"]
    return result
