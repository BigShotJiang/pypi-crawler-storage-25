"""Background idle monitor for on-demand sandboxes.

Periodically reads the in-sandbox agent's status file to determine
if a sandbox is idle. Pauses sandboxes that have been idle for
consecutive checks exceeding the threshold.
"""

import asyncio
import json
import logging
import time

from .const import (
    AGENT_STALENESS_MULTIPLIER,
    AGENT_STATUS_PATH,
    CRON_WAKEUP_LEAD_TIME,
    DEFAULT_IDLE_TIMEOUT,
    IDLE_CHECK_INTERVAL,
    IDLE_CHECKS_BEFORE_PAUSE,
    IDLE_PAUSE_DEFER_SECONDS,
    MONITOR_CONCURRENCY,
    MONITOR_PAGE_SIZE,
)
from .database import (
    db_available,
    db_get_api_key,
    db_list_on_demand_active,
    db_update_on_demand_config,
    to_prefix,
)
from .sandbox import SandboxManager, SandboxState

logger = logging.getLogger(__name__)

# In-memory counter for consecutive idle checks (resets on server restart — safe default)
_idle_counts: dict[str, int] = {}
_pause_deferred_until: dict[str, float] = {}

_semaphore = None


def _get_semaphore() -> asyncio.Semaphore:
    global _semaphore  # noqa: PLW0603
    if _semaphore is None:
        _semaphore = asyncio.Semaphore(MONITOR_CONCURRENCY)
    return _semaphore


def defer_pause_for_sandbox(sandbox_id: str, seconds: int = IDLE_PAUSE_DEFER_SECONDS):
    """Temporarily prevent idle-monitor pauses for a sandbox.

    This is used around management operations like gateway restarts, where a
    concurrent auto-pause can interrupt stop/start sequencing.
    """
    prefix = to_prefix(sandbox_id)
    _pause_deferred_until[prefix] = max(_pause_deferred_until.get(prefix, 0), time.time() + seconds)


def _is_pause_deferred(prefix: str) -> bool:
    """Return True while a sandbox is within its temporary pause defer window."""
    deferred_until = _pause_deferred_until.get(prefix, 0)
    if deferred_until <= time.time():
        _pause_deferred_until.pop(prefix, None)
        return False
    return True


def _cron_is_imminent(cron_schedules) -> bool:
    """Return True when a cron job is about to fire or has just started."""
    if not cron_schedules:
        return False
    try:
        from .cron_wakeup import _earliest_next_run

        earliest = _earliest_next_run(cron_schedules)
    except Exception:
        return False
    if earliest is None:
        return False
    seconds_until = earliest - time.time()
    return -IDLE_CHECK_INTERVAL <= seconds_until <= CRON_WAKEUP_LEAD_TIME


async def idle_monitor_loop(interval: int = 0):
    """Main loop: check all on-demand sandboxes periodically."""
    interval = interval or IDLE_CHECK_INTERVAL
    logger.info("Idle monitor started (interval=%ds)", interval)
    while True:
        try:
            await asyncio.sleep(interval)
            if not db_available():
                continue

            offset = 0
            live_cache: dict[str, dict[str, str]] = {}  # api_key → prefix_map
            while True:
                entries = await asyncio.to_thread(
                    db_list_on_demand_active, MONITOR_PAGE_SIZE, offset
                )
                if not entries:
                    break
                # Resolve API key from first entry (all entries share the same key in
                # single-tenant deployments) and build prefix_map (cached per key).
                # Check live_cache values first to avoid redundant DB lookups.
                api_key = next(iter(live_cache), None)
                if api_key is None:
                    api_key = await asyncio.to_thread(db_get_api_key, entries[0].sandbox_id_prefix)
                if api_key and api_key not in live_cache:
                    live = await asyncio.to_thread(SandboxManager.list_app_sandboxes, api_key)
                    live_cache[api_key] = {to_prefix(s.sandbox_id): s.sandbox_id for s in live}
                prefix_map = live_cache.get(api_key, {}) if api_key else {}
                tasks = [_check_sandbox_limited(e, prefix_map, api_key) for e in entries]
                await asyncio.gather(*tasks, return_exceptions=True)
                if len(entries) < MONITOR_PAGE_SIZE:
                    break
                offset += MONITOR_PAGE_SIZE

        except asyncio.CancelledError:
            logger.info("Idle monitor stopped")
            raise
        except Exception:
            logger.exception("Idle monitor loop error")


async def _check_sandbox_limited(sbx, prefix_map, api_key):
    """Rate-limited wrapper around _check_sandbox."""
    async with _get_semaphore():
        await _check_sandbox(sbx, prefix_map, api_key)


async def _check_sandbox(sbx, prefix_map, api_key):
    """Check a single sandbox's idle status and pause if needed."""
    prefix = sbx.sandbox_id_prefix
    sandbox_id = prefix_map.get(prefix)
    if not sandbox_id:
        _idle_counts.pop(prefix, None)
        return
    if _is_pause_deferred(prefix):
        _idle_counts.pop(prefix, None)
        logger.debug("Sandbox %s pause deferred by recent management activity", sandbox_id)
        return
    if not api_key:
        return

    confirmed_idle = False
    manager = None
    try:
        info = await asyncio.to_thread(SandboxManager.get_sandbox_info, sandbox_id, api_key)
        if info.state != SandboxState.RUNNING:
            return

        manager = SandboxManager(api_key=api_key)
        await asyncio.to_thread(manager.connect, sandbox_id)
        status_raw = await asyncio.to_thread(manager.read_file, AGENT_STATUS_PATH)

        if not status_raw:
            return

        try:
            status = json.loads(status_raw)
        except (json.JSONDecodeError, TypeError):
            return

        last_check = status.get("last_check", 0)
        staleness = time.time() - last_check
        idle_timeout = (
            sbx.on_demand_config.idle_timeout if sbx.on_demand_config else DEFAULT_IDLE_TIMEOUT
        )
        max_staleness = idle_timeout * AGENT_STALENESS_MULTIPLIER
        if staleness > max_staleness:
            logger.warning(
                "Sandbox %s agent stale (last_check %ds ago) — treating as active",
                sandbox_id,
                int(staleness),
            )
            return

        cron_schedules = status.get("cron_schedules")
        if not status.get("idle", False):
            return

        if _cron_is_imminent(cron_schedules):
            logger.debug(
                "Sandbox %s has an imminent cron job — treating as active",
                sandbox_id,
            )
            return

        confirmed_idle = True
        count = _idle_counts.get(prefix, 0) + 1
        _idle_counts[prefix] = count
        logger.debug("Sandbox %s idle check %d/%d", sandbox_id, count, IDLE_CHECKS_BEFORE_PAUSE)

        if count < IDLE_CHECKS_BEFORE_PAUSE:
            return

        logger.info("Sandbox %s idle for %d checks — pausing", sandbox_id, count)

        # Re-check state to avoid racing with a user resume/connect
        info2 = await asyncio.to_thread(SandboxManager.get_sandbox_info, sandbox_id, api_key)
        if info2.state != SandboxState.RUNNING:
            logger.info("Sandbox %s state changed to %s — skipping pause", sandbox_id, info2.state)
            return

        if cron_schedules:
            await asyncio.to_thread(
                db_update_on_demand_config,
                prefix,
                cron_schedules=json.dumps(cron_schedules),
            )

        # Clear counter before attempting pause — if pause() throws, we still
        # want to reset so the next cycle re-evaluates from scratch instead of
        # immediately retrying.
        confirmed_idle = False
        await asyncio.to_thread(manager.pause)
        logger.info("Sandbox %s paused successfully", sandbox_id)

    except Exception:
        logger.exception("Error checking sandbox %s", sandbox_id)
    finally:
        if not confirmed_idle:
            _idle_counts.pop(prefix, None)
        # Release SDK connection reference
        if manager is not None:
            manager._sandbox = None
