"""MCP (Model Context Protocol) server.

Exposes sandbox management tools via Streamable HTTP at /api/mcp.
Each tool mirrors a CLI command and reuses the corresponding route handler.
"""

import asyncio
import functools
import inspect
import json
import logging
from contextvars import ContextVar

from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings

from .const import (
    BRAND_NAME,
    FEISHU_WEBHOOK_PATH,
    FEISHU_WEBHOOK_PORT,
    MODE_GATEWAY,
    TYPE_ALWAYS_ON,
)
from .errors import ServerError
from .logging import sandbox_id_var
from .routes import config, devices, gateway, node, pairing, sandboxes, services
from .schemas import (
    ConfigSetRequest,
    DeviceApproveRequest,
    FeishuConfigRequest,
    LaunchRequest,
    NodeConnectRequest,
    PairingApproveRequest,
)

# -- Per-request API key via ContextVar (set by AuthMiddleware) --

_api_key_var: ContextVar[str] = ContextVar("_api_key_var")


def _get_api_key() -> str:
    """Read the API key set by AuthMiddleware for the current request."""
    try:
        return _api_key_var.get()
    except LookupError:
        raise ValueError(
            "[MISSING_API_KEY] API key is required. "
            "Suggested fix: Pass an Authorization: Bearer <key> header."
        ) from None


# -- Auth middleware: extracts Bearer token into ContextVar --


_INVALID_TOKEN_BODY = json.dumps(
    {"error": "invalid_api_key", "error_description": "Missing or invalid API key"}
).encode()


class _AuthMiddleware:
    """ASGI middleware that requires Authorization: Bearer <token> on every request."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http":
            auth = next(
                (v for k, v in scope.get("headers", []) if k == b"authorization"),
                b"",
            ).decode()
            if auth.startswith("Bearer "):
                token = auth[7:].strip()
                if token:
                    _api_key_var.set(token)
                    await self.app(scope, receive, send)
                    return
            # Reject: no valid Bearer token
            await send(
                {
                    "type": "http.response.start",
                    "status": 401,
                    "headers": [
                        [b"content-type", b"application/json"],
                        [b"content-length", str(len(_INVALID_TOKEN_BODY)).encode()],
                    ],
                }
            )
            await send({"type": "http.response.body", "body": _INVALID_TOKEN_BODY})
            return
        await self.app(scope, receive, send)


# -- FastMCP instance --

mcp = FastMCP(
    BRAND_NAME,
    stateless_http=True,
    json_response=True,
    streamable_http_path="/mcp",
    # DNS rebinding protection is handled by the reverse proxy (nginx);
    # disabling here avoids host-header mismatches in tests and when
    # mounted behind /api.
    transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False),
)


logger = logging.getLogger(__name__)

# -- Helper: call sync route handler from async tool --


def _strip_status(result) -> dict:
    """Convert route response to dict and remove the 'status' key."""
    if isinstance(result, dict):
        d = dict(result)
    else:
        d = result.model_dump() if hasattr(result, "model_dump") else dict(result)
    d.pop("status", None)
    return d


@functools.lru_cache(maxsize=None)
def _sandbox_id_index(fn):
    """Return the positional index of 'sandbox_id' in fn's signature, or -1."""
    params = list(inspect.signature(fn).parameters)
    return params.index("sandbox_id") if "sandbox_id" in params else -1


def _extract_sandbox_id(fn, args, kwargs):
    """Extract sandbox_id from function arguments if the parameter exists."""
    if "sandbox_id" in kwargs:
        return kwargs["sandbox_id"]
    idx = _sandbox_id_index(fn)
    if 0 <= idx < len(args):
        return args[idx]
    return None


async def _call(fn, *args, **kwargs):
    """Call a sync route handler in a thread and return JSON string."""
    try:
        sid = _extract_sandbox_id(fn, args, kwargs)
        if sid:
            sandbox_id_var.set(sid)
        api_key = _api_key_var.get("")
        logger.info(
            "Calling %s (api_key=%s…%s)",
            fn.__name__,
            api_key[:4] if len(api_key) >= 16 else "****",
            api_key[-4:] if len(api_key) >= 16 else "****",
        )
        result = await asyncio.to_thread(fn, *args, **kwargs)
        return json.dumps(_strip_status(result))
    except ServerError as exc:
        parts = ["[{code}] {msg}".format(code=exc.error_code, msg=str(exc))]
        if exc.remediation:
            parts.append("Suggested fix: {r}".format(r=exc.remediation))
        raise ValueError(" ".join(parts)) from None
    except (TypeError, ValueError) as exc:
        raise ValueError("[VALIDATION_ERROR] {msg}".format(msg=str(exc))) from None


# -- Tool definitions --


@mcp.tool()
async def launch(
    timeout: int = 180,
    mode: str = MODE_GATEWAY,
    display_name: str = None,
    sandbox_type: str = TYPE_ALWAYS_ON,
    idle_timeout: int = None,
) -> str:
    """Launch a new OpenClaw sandbox environment.

    Use this when the user wants to create/start a new sandbox.

    Gateway mode (default): starts a full OpenClaw gateway. Returns sandbox_id,
    WebUI URL, Gateway WebSocket URL, and service credentials. Takes ~60-120s.

    Node mode: creates a bare node sandbox with services (terminal, file manager).
    After launch, use node_connect to connect it to a gateway. Takes ~30-60s.

    Args:
        timeout: Sandbox creation timeout in seconds (default 180).
        mode: Launch mode — 'gateway' (default) or 'node'.
        display_name: Node display name shown in the gateway (node mode only).
        sandbox_type: 'always-on' (default) runs continuously; 'on-demand'
            auto-pauses when idle and auto-resumes on HTTP access.
        idle_timeout: Seconds of inactivity before auto-pause (on-demand only,
            default 300, minimum 60).
    """
    api_key = _get_api_key()
    return await _call(
        sandboxes.create_sandbox,
        LaunchRequest(
            timeout=timeout,
            mode=mode,
            display_name=display_name,
            sandbox_type=sandbox_type,
            idle_timeout=idle_timeout,
        ),
        api_key,
    )


@mcp.tool()
async def node_connect(
    sandbox_id: str,
    gateway_url: str,
    gateway_token: str = None,
) -> str:
    """Connect a node sandbox to a gateway.

    Use this after launching a sandbox in node mode. Can also be used to rebind
    a node to a different gateway without recreating the sandbox.

    Args:
        sandbox_id: The node sandbox ID to connect.
        gateway_url: WebSocket URL of the target gateway (wss://...).
        gateway_token: Optional gateway auth token.
    """
    api_key = _get_api_key()
    return await _call(
        node.node_connect,
        sandbox_id,
        NodeConnectRequest(
            gateway_url=gateway_url,
            gateway_token=gateway_token,
        ),
        api_key,
    )


@mcp.tool()
async def node_status(sandbox_id: str, gateway_url: str) -> str:
    """Check node process and pairing status.

    Returns alive (process running) and paired (TCP connection established).
    Use this to poll for pairing completion after node_connect.

    Args:
        sandbox_id: The node sandbox ID to check.
        gateway_url: The gateway URL used in node_connect (needed to check the connection).
    """
    api_key = _get_api_key()
    return await _call(node.node_status, sandbox_id, gateway_url, api_key)


@mcp.tool()
async def node_reconnect(
    sandbox_id: str,
    gateway_url: str,
    gateway_token: str = None,
) -> str:
    """Re-launch the node process if it has died.

    Has no effect if the process is still alive. Use this when node_status
    returns alive=false in the CLI poll loop, to restart the node without
    the full stability wait of node_connect.

    Args:
        sandbox_id: The node sandbox ID to reconnect.
        gateway_url: WebSocket URL of the target gateway (wss://...).
        gateway_token: Optional gateway auth token.
    """
    api_key = _get_api_key()
    return await _call(
        node.node_reconnect,
        sandbox_id,
        NodeConnectRequest(
            gateway_url=gateway_url,
            gateway_token=gateway_token,
        ),
        api_key,
    )


@mcp.tool()
async def node_disconnect(sandbox_id: str) -> str:
    """Disconnect a node from its gateway.

    Stops the openclaw node process inside the sandbox. The sandbox stays alive
    and can be reconnected to a different gateway with node_connect.

    Args:
        sandbox_id: The node sandbox ID to disconnect.
    """
    api_key = _get_api_key()
    return await _call(node.node_disconnect, sandbox_id, api_key)


@mcp.tool()
async def pause(sandbox_id: str) -> str:
    """Pause a running sandbox to save costs while preserving all state.

    All filesystem contents, memory state, and running processes are preserved.
    The sandbox incurs no runtime charges while paused. Use resume to restart it.
    Pause duration scales with RAM (~4s per GB). Resume takes ~1s.

    Args:
        sandbox_id: The sandbox ID to pause.
    """
    api_key = _get_api_key()
    return await _call(sandboxes.pause_sandbox, sandbox_id, api_key)


@mcp.tool()
async def resume(sandbox_id: str) -> str:
    """Resume a previously paused sandbox.

    Restores the sandbox to its exact state before pausing, including
    filesystem contents, memory, and running processes. Takes ~1s.
    After resuming, services are accessible again but clients may need
    to reconnect.

    Args:
        sandbox_id: The sandbox ID to resume.
    """
    api_key = _get_api_key()
    return await _call(sandboxes.resume_sandbox, sandbox_id, api_key)


@mcp.tool()
async def stop(sandbox_id: str) -> str:
    """Stop and permanently destroy a running sandbox.

    Use this when the user wants to terminate/delete a sandbox.
    This action cannot be undone — all data in the sandbox will be lost.

    Args:
        sandbox_id: The sandbox ID returned by launch or list.
    """
    api_key = _get_api_key()
    return await _call(sandboxes.delete_sandbox, sandbox_id, api_key)


@mcp.tool()
async def list_sandboxes() -> str:
    """List all active sandboxes.

    Use this to discover running sandboxes, check their states,
    or find a sandbox_id for subsequent operations.
    """
    api_key = _get_api_key()
    return await _call(sandboxes.list_sandboxes, api_key)


@mcp.tool()
async def status(sandbox_id: str) -> str:
    """Get detailed status and access URLs for a specific sandbox.

    Use this to check if a sandbox is running and retrieve its WebUI URL,
    Gateway WebSocket URL, and service credentials. Safe to call on paused
    sandboxes — returns basic info without resuming them.

    Args:
        sandbox_id: The sandbox ID to query.
    """
    api_key = _get_api_key()
    return await _call(sandboxes.get_sandbox, sandbox_id, api_key)


@mcp.tool()
async def doctor(
    sandbox_id: str,
    deep: bool = False,
    fix: bool = False,
    force: bool = False,
    generate_gateway_token: bool = False,
    no_workspace_suggestions: bool = False,
    repair: bool = False,
    yes: bool = False,
) -> str:
    """Run OpenClaw diagnostics inside a sandbox to detect and repair issues.

    Use this when the gateway is unhealthy, WebUI is inaccessible,
    or after a failed operation. Pass fix=True to auto-repair detected issues.

    Args:
        sandbox_id: The sandbox ID to diagnose.
        deep: Run deep diagnostic checks.
        fix: Automatically fix detected issues.
        force: Force operations even if checks pass.
        generate_gateway_token: Generate a new gateway token.
        no_workspace_suggestions: Suppress workspace suggestions.
        repair: Run repair mode.
        yes: Auto-confirm prompts.
    """
    api_key = _get_api_key()
    return await _call(
        gateway.gateway_doctor,
        sandbox_id,
        api_key,
        deep=deep,
        fix=fix,
        force=force,
        generate_gateway_token=generate_gateway_token,
        no_workspace_suggestions=no_workspace_suggestions,
        repair=repair,
        yes=yes,
    )


@mcp.tool()
async def gateway_update(sandbox_id: str) -> str:
    """Update OpenClaw to the latest version inside a sandbox and restart the gateway.

    Use this when the user wants to upgrade OpenClaw or when doctor suggests an update.

    Args:
        sandbox_id: The sandbox ID to update.
    """
    api_key = _get_api_key()
    return await _call(gateway.gateway_update, sandbox_id, api_key)


@mcp.tool()
async def gateway_restart(sandbox_id: str) -> str:
    """Restart the OpenClaw Gateway process inside a sandbox.

    Use this when the gateway is stuck or after configuration changes.
    Lighter than gateway_update — just restarts without upgrading.

    Args:
        sandbox_id: The sandbox ID to restart the gateway in.
    """
    api_key = _get_api_key()
    return await _call(gateway.gateway_restart, sandbox_id, api_key)


@mcp.tool()
async def services_setup(sandbox_id: str) -> str:
    """Install and start Web Terminal (ttyd) and File Manager (gohttpserver) on a sandbox.

    Use this when the user needs browser-based shell access or file management.
    Idempotent — safe to call multiple times.

    Args:
        sandbox_id: The sandbox ID to set up services on.
    """
    api_key = _get_api_key()
    return await _call(services.services_setup, sandbox_id, api_key)


@mcp.tool()
async def pair_list(sandbox_id: str, channel: str) -> str:
    """List pending pairing requests for a messaging channel.

    Use this when the user wants to see which pairing codes are waiting for approval.

    Args:
        sandbox_id: The sandbox ID to check.
        channel: Channel name (telegram, discord, whatsapp, signal, slack).
    """
    api_key = _get_api_key()
    return await _call(pairing.pairing_list, sandbox_id, channel=channel, api_key=api_key)


@mcp.tool()
async def pair_approve(sandbox_id: str, channel: str, code: str) -> str:
    """Approve a pending pairing request to connect a messaging channel to OpenClaw.

    Use this after pair_list shows a pending request that the user wants to approve.

    Args:
        sandbox_id: The sandbox ID.
        channel: Channel name (telegram, discord, whatsapp, signal, slack).
        code: The pairing code from pair_list.
    """
    api_key = _get_api_key()
    return await _call(
        pairing.pairing_approve,
        sandbox_id,
        PairingApproveRequest(channel=channel, code=code),
        api_key,
    )


@mcp.tool()
async def devices_list(sandbox_id: str) -> str:
    """List all devices (paired and pending) on a gateway sandbox.

    Use this to check node pairing status on the gateway side.

    Args:
        sandbox_id: The gateway sandbox ID.
    """
    api_key = _get_api_key()
    return await _call(devices.devices_list, sandbox_id, json=True, api_key=api_key)


@mcp.tool()
async def devices_approve(sandbox_id: str, request_id: str = None) -> str:
    """Approve pending node devices on a gateway sandbox.

    Approves a specific device by request_id, or all pending devices
    when request_id is omitted.

    Args:
        sandbox_id: The gateway sandbox ID.
        request_id: Request ID of a specific device to approve. Omit to approve all.
    """
    api_key = _get_api_key()
    return await _call(
        devices.devices_approve,
        sandbox_id,
        DeviceApproveRequest(request_id=request_id),
        api_key,
    )


@mcp.tool()
async def feishu_config(
    sandbox_id: str,
    app_id: str,
    app_secret: str,
    connection_mode: str = "event",
    verification_token: str = None,
    encrypt_key: str = None,
    webhook_host: str = "0.0.0.0",
    webhook_port: int = FEISHU_WEBHOOK_PORT,
    webhook_path: str = FEISHU_WEBHOOK_PATH,
    dm_policy: str = "pairing",
) -> str:
    """Configure Feishu channel on a sandbox.

    Writes Feishu app credentials into openclaw.json and restarts the gateway.
    Use this when the user wants to connect a Feishu bot to their OpenClaw instance.

    Args:
        sandbox_id: The sandbox ID to configure.
        app_id: Feishu app ID.
        app_secret: Feishu app secret.
        connection_mode: 'event' (default, long-poll) or 'webhook' (HTTP push).
        verification_token: Verification token (required for webhook mode).
        encrypt_key: Encrypt key (required for webhook mode).
        webhook_host: Webhook bind host (webhook mode only, default 0.0.0.0).
        webhook_port: Webhook listen port (webhook mode only, default 3000).
        webhook_path: Webhook URL path (webhook mode only, default /feishu/events).
        dm_policy: DM policy (default: pairing).
    """
    api_key = _get_api_key()
    return await _call(
        pairing.feishu_config,
        sandbox_id,
        FeishuConfigRequest(
            app_id=app_id,
            app_secret=app_secret,
            connection_mode=connection_mode,
            verification_token=verification_token,
            encrypt_key=encrypt_key,
            webhook_host=webhook_host,
            webhook_port=webhook_port,
            webhook_path=webhook_path,
            dm_policy=dm_policy,
        ),
        api_key,
    )


@mcp.tool()
async def config_set(sandbox_id: str, key: str, value: str) -> str:
    """Update a configuration value on an on-demand sandbox.

    Supported keys:
    - idle-timeout: Seconds of inactivity before auto-pause (minimum 60).
    - timeout: Total sandbox lifecycle in seconds (minimum 300).

    Args:
        sandbox_id: The sandbox to configure.
        key: Configuration key (e.g. 'idle-timeout', 'timeout').
        value: New value for the key.
    """
    api_key = _get_api_key()
    return await _call(
        config.config_set,
        sandbox_id,
        ConfigSetRequest(key=key, value=value),
        api_key,
    )


# -- ASGI app factory --


def get_mcp_app():
    """Return an ASGI app for mounting: MCP HTTP app with auth middleware."""
    app = mcp.streamable_http_app()
    # The MCP SDK injects a RichHandler on the root logger; remove it so all
    # output stays in the JSON format configured by our logging module.
    root = logging.getLogger()
    root.handlers = [h for h in root.handlers if type(h).__name__ != "RichHandler"]
    app.add_middleware(_AuthMiddleware)
    return app
