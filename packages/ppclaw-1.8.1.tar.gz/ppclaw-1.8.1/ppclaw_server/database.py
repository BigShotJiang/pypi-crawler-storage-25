"""Database layer for sandbox management.

Two tables:
- openclaw_sandbox: tracks ALL sandboxes (always-on and on-demand)
- on_demand_config: on-demand specific config, linked via sandbox_id_prefix

Sandbox IDs have the format ``{prefix}-{suffix}`` (e.g.
``iy60pw1xtlv6e7cj00s7y-00000000``).  The suffix changes on every
resume, so the DB stores only the stable *prefix* as a unique key.
All public functions accept a full ``sandbox_id`` and extract the prefix
internally via ``to_prefix()``.
"""

import logging
import os
from datetime import datetime, timezone

from sqlalchemy import (
    Column,
    DateTime,
    Integer,
    String,
    Text,
    create_engine,
)
from sqlalchemy.orm import Session, declarative_base, relationship, sessionmaker

from .const import MODE_GATEWAY, TYPE_ALWAYS_ON, TYPE_ON_DEMAND

logger = logging.getLogger(__name__)

Base = declarative_base()

# --- Encryption helpers ---

_fernet = None


def _get_fernet():
    global _fernet  # noqa: PLW0603
    if _fernet is not None:
        return _fernet
    key = os.environ.get("DB_ENCRYPTION_KEY")
    if not key:
        return None
    from cryptography.fernet import Fernet

    _fernet = Fernet(key.encode() if isinstance(key, str) else key)
    return _fernet


def _encrypt(value: str) -> str:
    """Encrypt a string with Fernet. Raises if no key is configured."""
    f = _get_fernet()
    if f is None:
        raise RuntimeError("DB_ENCRYPTION_KEY is not set — refusing to store plaintext secrets.")
    return f.encrypt(value.encode()).decode()


def _decrypt(value: str, *, label: str = "value", silent: bool = False) -> str:
    """Decrypt a Fernet token.

    If *silent* is True, logs a warning and returns None on failure.
    Otherwise raises ValueError.
    """
    f = _get_fernet()
    if f is None:
        raise RuntimeError("DB_ENCRYPTION_KEY is not set — cannot decrypt secrets.")
    try:
        return f.decrypt(value.encode()).decode()
    except Exception as exc:
        if silent:
            logger.warning("Failed to decrypt %s — data corrupt or wrong encryption key", label)
            return None
        raise ValueError(
            "Failed to decrypt {l} — data corrupt or wrong encryption key".format(l=label)
        ) from exc


def encrypt_api_key(api_key: str) -> str:
    return _encrypt(api_key)


def decrypt_api_key(token: str) -> str:
    return _decrypt(token, label="API key")


def encrypt_token(value: str) -> str:
    """Encrypt a token (gateway token, etc.) using Fernet."""
    return _encrypt(value)


def decrypt_token(value: str) -> str:
    """Decrypt a token; returns None on failure (non-critical field)."""
    return _decrypt(value, label="token", silent=True)


# --- Prefix helpers ---


def to_prefix(sandbox_id: str) -> str:
    """Extract the stable prefix from a sandbox ID (everything before the last '-')."""
    idx = sandbox_id.rfind("-")
    return sandbox_id[:idx] if idx > 0 else sandbox_id


# --- Models ---


class OpenClawSandbox(Base):
    """All sandboxes (always-on and on-demand)."""

    __tablename__ = "openclaw_sandbox"

    id = Column(Integer, primary_key=True, autoincrement=True)
    sandbox_id_prefix = Column(String(128), unique=True, nullable=False)
    api_key_encrypted = Column(String(512), nullable=False)
    sandbox_type = Column(String(32), nullable=False)
    mode = Column(String(32), nullable=False)
    sandbox_domain = Column(String(256), nullable=True)
    gateway_token_encrypted = Column(String(512), nullable=True)
    services_password_encrypted = Column(String(512), nullable=True)
    created_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, nullable=True)
    deleted_at = Column(DateTime, nullable=True)

    on_demand_config = relationship(
        "OnDemandConfig",
        uselist=False,
        back_populates="sandbox",
        primaryjoin="OpenClawSandbox.sandbox_id_prefix == OnDemandConfig.sandbox_id_prefix",
        foreign_keys="[OnDemandConfig.sandbox_id_prefix]",
        cascade="all, delete-orphan",
    )


class OnDemandConfig(Base):
    """On-demand specific configuration (linked to openclaw_sandbox via sandbox_id_prefix)."""

    __tablename__ = "on_demand_config"

    id = Column(Integer, primary_key=True, autoincrement=True)
    sandbox_id_prefix = Column(String(128), unique=True, nullable=False)
    idle_timeout = Column(Integer, nullable=False)
    timeout = Column(Integer, nullable=True)
    cron_schedules = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, nullable=True)
    deleted_at = Column(DateTime, nullable=True)

    sandbox = relationship(
        "OpenClawSandbox",
        back_populates="on_demand_config",
        primaryjoin="OnDemandConfig.sandbox_id_prefix == OpenClawSandbox.sandbox_id_prefix",
        foreign_keys="[OnDemandConfig.sandbox_id_prefix]",
    )


# --- Engine & session ---

_engine = None
_SessionLocal = None


def _get_session() -> Session:
    if _SessionLocal is None:
        raise RuntimeError("Database not initialized. Call db_init() first.")
    return _SessionLocal()


def db_init():
    """Initialize database engine and create tables."""
    global _engine, _SessionLocal  # noqa: PLW0603
    url = os.environ.get("DATABASE_URL")
    if not url:
        # Assemble from individual MySQL env vars (K8s secret-style deployment).
        user = os.environ.get("mysql_server_username")  # noqa: SIM112 — K8s injects lowercase
        password = os.environ.get("mysql_server_password")  # noqa: SIM112 — K8s injects lowercase
        host = os.environ.get("MYSQL_HOST")
        db = os.environ.get("MYSQL_DB")
        if user and password and host and db:
            from urllib.parse import quote_plus

            url = f"mysql+pymysql://{quote_plus(user)}:{quote_plus(password)}@{host}/{db}"
        else:
            raise RuntimeError(
                "DATABASE_URL is required (or set mysql_server_username, "
                "mysql_server_password, MYSQL_HOST, MYSQL_DB). "
                "For local dev use: DATABASE_URL=sqlite:///./dev.db"
            )
    if not os.environ.get("DB_ENCRYPTION_KEY"):
        raise RuntimeError(
            "DB_ENCRYPTION_KEY is required when DATABASE_URL is set. "
            "Generate one with: python3 -c "
            '"from cryptography.fernet import Fernet; '
            'print(Fernet.generate_key().decode())"'
        )
    _engine = create_engine(url, pool_pre_ping=True)
    _SessionLocal = sessionmaker(bind=_engine)
    Base.metadata.create_all(_engine)
    logger.info("Database initialized")


def db_available() -> bool:
    """Check if the database is configured and available."""
    return _engine is not None


# --- Sandbox CRUD ---


def db_register_sandbox(
    sandbox_id: str,
    api_key: str,
    sandbox_type: str = TYPE_ALWAYS_ON,
    mode: str = MODE_GATEWAY,
    idle_timeout: int = None,
    timeout: int = None,
    sandbox_domain: str = None,
    gateway_token: str = None,
    services_password: str = None,
):
    """Register a sandbox. Creates on_demand_config row if type is on-demand."""
    prefix = to_prefix(sandbox_id)
    session = _get_session()
    try:
        now = datetime.now(timezone.utc)
        encrypted_key = encrypt_api_key(api_key)
        encrypted_token = encrypt_token(gateway_token) if gateway_token else None
        encrypted_password = encrypt_token(services_password) if services_password else None

        sbx = session.query(OpenClawSandbox).filter_by(sandbox_id_prefix=prefix).first()
        if not sbx:
            sbx = OpenClawSandbox(sandbox_id_prefix=prefix, created_at=now)
            session.add(sbx)
        sbx.api_key_encrypted = encrypted_key
        sbx.sandbox_type = sandbox_type
        sbx.mode = mode
        sbx.sandbox_domain = sandbox_domain
        sbx.gateway_token_encrypted = encrypted_token
        sbx.services_password_encrypted = encrypted_password
        sbx.updated_at = now
        sbx.deleted_at = None
        session.flush()

        if sandbox_type == TYPE_ON_DEMAND and idle_timeout is not None:
            od = session.query(OnDemandConfig).filter_by(sandbox_id_prefix=prefix).first()
            if not od:
                od = OnDemandConfig(sandbox_id_prefix=prefix, created_at=now)
                session.add(od)
            od.idle_timeout = idle_timeout
            od.timeout = timeout
            od.updated_at = now
            od.deleted_at = None

        session.commit()
    finally:
        session.close()


def db_unregister_sandbox(sandbox_id: str):
    """Soft-delete a sandbox (sets deleted_at on sandbox and its on-demand config)."""
    prefix = to_prefix(sandbox_id)
    session = _get_session()
    try:
        sbx = session.query(OpenClawSandbox).filter_by(sandbox_id_prefix=prefix).first()
        if sbx:
            now = datetime.now(timezone.utc)
            sbx.deleted_at = now
            sbx.updated_at = now
            if sbx.on_demand_config:
                sbx.on_demand_config.deleted_at = now
                sbx.on_demand_config.updated_at = now
            session.commit()
    finally:
        session.close()


def db_get_sandbox(sandbox_id: str, include_deleted: bool = False):
    """Get a sandbox record by sandbox_id (prefix extracted automatically).

    By default, soft-deleted records are excluded. Pass include_deleted=True
    to retrieve them (e.g. for verifying soft-delete in tests).
    """
    prefix = to_prefix(sandbox_id)
    session = _get_session()
    try:
        q = session.query(OpenClawSandbox).filter_by(sandbox_id_prefix=prefix)
        if not include_deleted:
            q = q.filter(OpenClawSandbox.deleted_at.is_(None))
        sbx = q.first()
        if sbx:
            # Eagerly load relationship before detaching
            _ = sbx.on_demand_config
            session.expunge(sbx)
        return sbx
    finally:
        session.close()


def db_get_api_key(sandbox_id: str) -> str:
    """Get decrypted API key for a sandbox."""
    sbx = db_get_sandbox(sandbox_id)
    if not sbx:
        return None
    return decrypt_api_key(sbx.api_key_encrypted)


# --- On-demand specific queries ---


def db_list_on_demand_active(limit: int = 50, offset: int = 0) -> list:
    """List all non-deleted on-demand sandboxes (with config), paginated."""
    session = _get_session()
    try:
        entries = (
            session.query(OpenClawSandbox)
            .join(
                OnDemandConfig,
                OpenClawSandbox.sandbox_id_prefix == OnDemandConfig.sandbox_id_prefix,
            )
            .filter(OpenClawSandbox.deleted_at.is_(None))
            .filter(OnDemandConfig.deleted_at.is_(None))
            .order_by(OpenClawSandbox.sandbox_id_prefix)
            .limit(limit)
            .offset(offset)
            .all()
        )
        for e in entries:
            _ = e.on_demand_config
            session.expunge(e)
        return entries
    finally:
        session.close()


_SANDBOX_UPDATABLE_FIELDS = {
    "sandbox_type",
    "mode",
    "sandbox_domain",
    "gateway_token_encrypted",
    "services_password_encrypted",
}


def db_update_sandbox(sandbox_id: str, **fields):
    """Update fields on a sandbox record."""
    prefix = to_prefix(sandbox_id)
    session = _get_session()
    try:
        sbx = (
            session.query(OpenClawSandbox)
            .filter_by(sandbox_id_prefix=prefix)
            .filter(OpenClawSandbox.deleted_at.is_(None))
            .first()
        )
        if not sbx:
            return
        for key, value in fields.items():
            if key in _SANDBOX_UPDATABLE_FIELDS:
                setattr(sbx, key, value)
        sbx.updated_at = datetime.now(timezone.utc)
        session.commit()
    finally:
        session.close()


_ON_DEMAND_UPDATABLE_FIELDS = {"idle_timeout", "timeout", "cron_schedules"}


def db_update_on_demand_config(sandbox_id: str, **fields):
    """Update fields on an on-demand config record."""
    prefix = to_prefix(sandbox_id)
    session = _get_session()
    try:
        config = (
            session.query(OnDemandConfig)
            .filter_by(sandbox_id_prefix=prefix)
            .join(
                OpenClawSandbox,
                OnDemandConfig.sandbox_id_prefix == OpenClawSandbox.sandbox_id_prefix,
            )
            .filter(OpenClawSandbox.deleted_at.is_(None))
            .first()
        )
        if not config:
            return
        for key, value in fields.items():
            if key in _ON_DEMAND_UPDATABLE_FIELDS:
                setattr(config, key, value)
        config.updated_at = datetime.now(timezone.utc)
        session.commit()
    finally:
        session.close()
