"""Web Terminal (ttyd) and File Manager (gohttpserver) service management."""

import json
import logging
import secrets

from .const import FILE_MANAGER_PORT, SERVICES_DIR, SERVICES_USERNAME, TTYD_PORT
from .errors import ServiceConfigError

logger = logging.getLogger(__name__)

SERVICES_CONFIG_PATH = "{dir}/services.json".format(dir=SERVICES_DIR)

_SERVICE_BINARIES = ["ttyd", "gohttpserver"]

_TTYD_INSTALL_CMD = (
    "curl -sSL -o /usr/local/bin/ttyd"
    " https://github.com/tsl0922/ttyd/releases/latest/download/ttyd.x86_64"
    " && chmod +x /usr/local/bin/ttyd"
)

_GOHTTPSERVER_INSTALL_CMD = (
    "curl -sSL -o-"
    " https://github.com/codeskyblue/gohttpserver/releases/download/1.3.0/"
    "gohttpserver_1.3.0_linux_amd64.tar.gz"
    " | tar -zxf - -C /usr/local/bin/ gohttpserver"
    " && chmod +x /usr/local/bin/gohttpserver"
)


def generate_password(length=16) -> str:
    return secrets.token_urlsafe(length)


def configure_services(manager, password=None) -> dict:
    username = SERVICES_USERNAME
    if password is None:
        password = generate_password()
    credentials = {"username": username, "password": password}
    manager.run_command("mkdir -p {dir}".format(dir=SERVICES_DIR), timeout=10)
    manager.write_file(SERVICES_CONFIG_PATH, json.dumps(credentials, indent=2))
    manager.run_command("chmod 600 {path}".format(path=SERVICES_CONFIG_PATH), timeout=10)
    _start_service(
        manager,
        name="Web Terminal",
        binary="ttyd",
        cmd="nohup ttyd -p {port} -W -O -c {user}:{pw} bash > /tmp/ttyd.log 2>&1 &".format(
            port=TTYD_PORT,
            user=username,
            pw=password,
        ),
        port=TTYD_PORT,
    )
    _start_service(
        manager,
        name="File Manager",
        binary="gohttpserver",
        cmd=(
            "nohup gohttpserver --port {port} --upload --delete"
            " --root /home/user --auth-type http --auth-http {user}:{pw}"
            " > /tmp/gohttpserver.log 2>&1 &"
        ).format(port=FILE_MANAGER_PORT, user=username, pw=password),
        port=FILE_MANAGER_PORT,
    )
    return credentials


def _start_service(manager, name, binary, cmd, port):
    logger.info("Starting %s...", name)
    kill_cmd = "pkill -9 {bin} 2>/dev/null || true".format(bin=binary)
    manager.run_command(kill_cmd, timeout=10, silent=True)
    result = manager.run_command(cmd, timeout=10)
    if result is None:
        raise ServiceConfigError(
            "Failed to start {name} ({bin}). "
            "The binary may not be installed in this sandbox.".format(name=name, bin=binary)
        )
    logger.info("%s started on port %d", name, port)


def restart_services(manager):
    credentials = get_service_credentials(manager)
    if not credentials:
        raise ServiceConfigError(
            "No saved service credentials found. Run launch to configure services first."
        )
    configure_services(manager, password=credentials["password"])


def stop_services(manager):
    logger.info("Stopping services...")
    for binary in _SERVICE_BINARIES:
        kill_cmd = "pkill -9 {bin} 2>/dev/null || true".format(bin=binary)
        manager.run_command(kill_cmd, timeout=10, silent=True)
    logger.info("Services stopped")


def check_services_running(manager) -> bool:
    """Check if ttyd and gohttpserver processes are running."""
    proc = manager.run_command(
        "pgrep -f '[t]tyd' > /dev/null 2>&1 && pgrep -f '[g]ohttpserver' > /dev/null 2>&1"
        " && echo ok || true",
        timeout=5,
        silent=True,
    )
    return bool(proc and proc.stdout and "ok" in proc.stdout)


def get_service_credentials(manager) -> dict:
    try:
        content = manager.read_file(SERVICES_CONFIG_PATH)
        if content:
            return json.loads(content)
    except Exception:
        pass
    return {}


def install_services(manager):
    for binary, cmd in [("ttyd", _TTYD_INSTALL_CMD), ("gohttpserver", _GOHTTPSERVER_INSTALL_CMD)]:
        check = manager.run_command("which {bin}".format(bin=binary), timeout=10, silent=True)
        if check and check.stdout and check.stdout.strip():
            logger.info("%s already installed, skipping.", binary)
            continue
        logger.info("Installing %s...", binary)
        result = manager.run_command(cmd, timeout=120)
        if result is None:
            raise ServiceConfigError("Failed to install {bin}.".format(bin=binary))
        logger.info("%s installed.", binary)


def get_service_urls(manager) -> dict:
    ttyd_host = manager.sandbox.get_host(TTYD_PORT)
    fm_host = manager.sandbox.get_host(FILE_MANAGER_PORT)
    return {
        "terminal": "https://{host}".format(host=ttyd_host),
        "filemanager": "https://{host}".format(host=fm_host),
    }
