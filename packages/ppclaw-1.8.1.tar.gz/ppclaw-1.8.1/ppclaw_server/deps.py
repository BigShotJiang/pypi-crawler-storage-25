"""Dependency injection for the API Server."""

from fastapi import Request

from .errors import MissingApiKeyError


def get_api_key(request: Request) -> str:
    """Extract API key from Authorization: Bearer header."""
    auth = request.headers.get("authorization", "")
    if auth.startswith("Bearer "):
        key = auth[7:].strip()
        if key:
            return key
    raise MissingApiKeyError()
