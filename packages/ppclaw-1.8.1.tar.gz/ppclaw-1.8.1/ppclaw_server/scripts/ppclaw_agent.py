#!/usr/bin/env python3
"""In-sandbox agent for on-demand idle detection and cron job monitoring.

This script runs as a background daemon inside the sandbox. It periodically
checks OpenClaw session activity and monitors cron job configuration,
writing status to a well-known JSON file that the API server reads.

No external dependencies — stdlib only.
"""

import json
import os
import subprocess
import time

CONFIG_PATH = "__AGENT_CONFIG_PATH__"
STATUS_PATH = "__AGENT_STATUS_PATH__"
JOBS_PATH = os.path.expanduser("~/.openclaw/cron/jobs.json")

DEFAULT_IDLE_TIMEOUT = 300
DEFAULT_CHECK_INTERVAL = 60


def load_config():
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def _load_cron_jobs():
    """Load raw OpenClaw cron jobs from disk."""
    try:
        with open(JOBS_PATH) as f:
            data = json.load(f)
        if isinstance(data, list):
            jobs = data
        elif isinstance(data, dict):
            jobs = data.get("jobs", [])
        else:
            return []
        return jobs if isinstance(jobs, list) else []
    except (OSError, json.JSONDecodeError):
        return []


def _extract_sessions_json(text):
    """Extract the first valid sessions JSON object from command output."""
    decoder = json.JSONDecoder()
    payload = text.lstrip()

    for idx, char in enumerate(payload):
        if char not in "{[":
            continue
        try:
            obj, _ = decoder.raw_decode(payload[idx:])
        except json.JSONDecodeError:
            continue
        if (
            isinstance(obj, dict)
            and isinstance(obj.get("count"), int)
            and isinstance(obj.get("sessions"), list)
        ):
            return obj

    raise ValueError("No valid sessions JSON found in command output")


def check_sessions_active(idle_timeout):
    """Run openclaw sessions --active --json and return True if sessions are active."""
    try:
        idle_minutes = max(idle_timeout // 60, 1)
        result = subprocess.run(
            ["openclaw", "sessions", "--active", str(idle_minutes), "--json"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            return True
        data = _extract_sessions_json(result.stdout)
        return data.get("count", 0) > 0
    except (
        subprocess.TimeoutExpired,
        FileNotFoundError,
        OSError,
        json.JSONDecodeError,
        ValueError,
        KeyError,
    ):
        return True


def _cron_job_may_still_be_running(job, now_ms=None):
    """Return True while a cron job is within its configured timeout window."""
    if not isinstance(job, dict) or not job.get("enabled", True):
        return False
    state = job.get("state", {})
    payload = job.get("payload", {})
    if not isinstance(state, dict) or not isinstance(payload, dict):
        return False
    last_run_at_ms = state.get("lastRunAtMs")
    timeout_seconds = payload.get("timeoutSeconds")
    try:
        last_run_at_ms = float(last_run_at_ms)
        timeout_seconds = float(timeout_seconds)
    except (TypeError, ValueError):
        return False
    if timeout_seconds <= 0:
        return False
    now_ms = float(now_ms) if now_ms is not None else time.time() * 1000.0
    return now_ms < last_run_at_ms + (timeout_seconds * 1000.0)


def read_cron_state(now=None):
    """Read cron schedules plus a conservative running-job signal."""
    jobs = _load_cron_jobs()
    now_ms = (now if now is not None else time.time()) * 1000.0
    schedules = []
    running = False
    for job in jobs:
        if not isinstance(job, dict) or not job.get("enabled", True):
            continue
        entry = {
            "jobId": job.get("jobId", job.get("id", "")),
            "schedule": job.get("schedule", {}),
            "enabled": True,
        }
        state = job.get("state", {})
        if isinstance(state, dict) and state.get("nextRunAtMs"):
            entry["nextRunAt"] = state["nextRunAtMs"] / 1000.0
        tz = job.get("tz")
        if tz:
            entry["tz"] = tz
        schedules.append(entry)
        if _cron_job_may_still_be_running(job, now_ms=now_ms):
            running = True
    return schedules, running


def read_cron_schedules():
    """Read cron job schedules from OpenClaw jobs.json.

    The file may be a plain list (legacy) or ``{"version": N, "jobs": [...]}``.
    """
    schedules, _ = read_cron_state()
    return schedules


def write_status(idle, idle_since, cron_schedules):
    """Write current status to the status file."""
    status = {
        "idle": idle,
        "idle_since": idle_since,
        "last_check": int(time.time()),
        "cron_schedules": cron_schedules,
    }
    tmp_path = STATUS_PATH + ".tmp"
    try:
        with open(tmp_path, "w") as f:
            json.dump(status, f)
        os.replace(tmp_path, STATUS_PATH)
    except OSError:
        pass


def main():
    config = load_config()
    idle_timeout = config.get("idle_timeout", DEFAULT_IDLE_TIMEOUT)
    check_interval = config.get("check_interval", DEFAULT_CHECK_INTERVAL)

    idle_since = None

    while True:
        time.sleep(check_interval)

        # Reload config in case it was updated
        config = load_config()
        idle_timeout = config.get("idle_timeout", idle_timeout)
        check_interval = config.get("check_interval", check_interval)

        active = check_sessions_active(idle_timeout)
        cron_schedules, cron_running = read_cron_state()
        if not active and cron_running:
            active = True

        if active:
            idle_since = None
        elif idle_since is None:
            idle_since = int(time.time())

        write_status(
            idle=not active,
            idle_since=idle_since,
            cron_schedules=cron_schedules,
        )


if __name__ == "__main__":
    main()
