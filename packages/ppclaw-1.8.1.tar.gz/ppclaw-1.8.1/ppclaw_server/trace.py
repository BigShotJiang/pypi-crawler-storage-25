"""Request tracing middleware — sets trace_id and sandbox_id ContextVars."""

import re
import uuid

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

from .logging import sandbox_id_var, trace_id_var

_SANDBOX_ID_RE = re.compile(r"/sandboxes/([^/]+)(?:/|$)")
_SAFE_HEADER_RE = re.compile(r"[^\x20-\x7E]")


class TraceMiddleware(BaseHTTPMiddleware):
    """Populate trace_id and sandbox_id ContextVars for each request."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        # trace_id: prefer X-Request-ID, then X-Trace-ID, then auto-generate.
        # Sanitize to printable ASCII to prevent CRLF injection.
        raw = request.headers.get("x-request-id") or request.headers.get("x-trace-id") or ""
        trace_id = _SAFE_HEADER_RE.sub("", raw)[:128] or str(uuid.uuid4())
        trace_id_var.set(trace_id)

        # sandbox_id: always reset to avoid bleeding across requests.
        sandbox_id_var.set("")
        match = _SANDBOX_ID_RE.search(request.url.path)
        if match:
            sandbox_id_var.set(match.group(1))

        response = await call_next(request)
        response.headers["x-trace-id"] = trace_id
        return response
