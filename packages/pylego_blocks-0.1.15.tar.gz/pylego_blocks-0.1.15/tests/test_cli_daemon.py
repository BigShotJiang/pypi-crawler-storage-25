"""pylego schedule start/stop/status daemon CLI 테스트 (#267)."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch


# ── daemon.py 유틸리티 테스트 ─────────────────────────────────────────────────

def test_write_and_read_pid(tmp_path: Path) -> None:
    from pylego_blocks.core.daemon import read_pid, write_pid
    pid_file = tmp_path / "test.pid"
    write_pid(pid_file)
    assert read_pid(pid_file) == os.getpid()


def test_read_pid_missing_returns_none(tmp_path: Path) -> None:
    from pylego_blocks.core.daemon import read_pid
    assert read_pid(tmp_path / "no.pid") is None


def test_read_pid_corrupt_returns_none(tmp_path: Path) -> None:
    from pylego_blocks.core.daemon import read_pid
    bad = tmp_path / "bad.pid"
    bad.write_text("not-a-number", encoding="utf-8")
    assert read_pid(bad) is None


def test_is_running_current_process() -> None:
    from pylego_blocks.core.daemon import is_running
    assert is_running(os.getpid()) is True


def test_is_running_invalid_pid() -> None:
    from pylego_blocks.core.daemon import is_running
    assert is_running(999999999) is False


def test_default_pid_path() -> None:
    from pylego_blocks.core.daemon import default_pid_path
    p = default_pid_path("my_job")
    assert p.name == "my_job.pid"
    assert ".pylego" in str(p)


def test_list_running_empty(tmp_path: Path) -> None:
    from pylego_blocks.core.daemon import list_running
    assert list_running(str(tmp_path)) == []


def test_list_running_with_pid(tmp_path: Path) -> None:
    from pylego_blocks.core.daemon import list_running, write_pid
    pid_file = tmp_path / "myjob.pid"
    write_pid(pid_file)
    entries = list_running(str(tmp_path))
    assert len(entries) == 1
    label, pid, running = entries[0]
    assert label == "myjob"
    assert pid == os.getpid()
    assert running is True


def test_stop_pid_missing_file(tmp_path: Path) -> None:
    from pylego_blocks.core.daemon import stop_pid_file
    success, msg = stop_pid_file(tmp_path / "missing.pid")
    assert success is False
    assert "없" in msg


def test_daemonize_raises_on_windows() -> None:
    from pylego_blocks.core.daemon import daemonize
    with patch.object(sys, "platform", "win32"):
        try:
            daemonize()
        except NotImplementedError as exc:
            assert "Windows" in str(exc)


# ── CLI schedule status 테스트 ────────────────────────────────────────────────

def test_cli_schedule_status_empty(tmp_path: Path, capsys: object) -> None:
    from pylego_blocks.cli import main
    rc = main(["schedule", "status", "--pid-dir", str(tmp_path)])
    assert rc == 0


def test_cli_schedule_stop_no_args(capsys: object) -> None:
    from pylego_blocks.cli import main
    rc = main(["schedule", "stop"])
    assert rc == 2


def test_cli_schedule_stop_missing_pid(tmp_path: Path) -> None:
    from pylego_blocks.cli import main
    rc = main(["schedule", "stop", "--pid", str(tmp_path / "no.pid")])
    assert rc == 1


def test_cli_schedule_start_missing_trigger(tmp_path: Path) -> None:
    """--interval / --cron 없이 start 호출 시 오류."""
    yaml_file = tmp_path / "pipe.yaml"
    yaml_file.write_text(
        "assembly:\n  name: Test\n  blocks:\n    - class: pylego_blocks.core.stud.EmptyStud\n",
        encoding="utf-8",
    )
    from pylego_blocks.cli import main
    rc = main(["schedule", "start", str(yaml_file)])
    assert rc == 2


def test_cli_schedule_start_daemon_windows_error(tmp_path: Path) -> None:
    """Windows 에서 --daemon 사용 시 오류 반환."""
    yaml_file = tmp_path / "pipe.yaml"
    yaml_file.write_text(
        "assembly:\n  name: T\n  blocks:\n    - class: pylego_blocks.blocks.subprocess_block.SubprocessBlock\n",
        encoding="utf-8",
    )
    from pylego_blocks.core import daemon as daemon_mod
    with patch.object(daemon_mod, "daemonize", side_effect=NotImplementedError("Windows")):
        from pylego_blocks.cli import main
        rc = main(["schedule", "start", str(yaml_file), "--interval", "60", "--daemon"])
    assert rc == 2
