"""Stud 기본 동작 검증."""

from __future__ import annotations

from pydantic import ConfigDict

from pylego_blocks.core import Stud


class _DefaultStud(Stud):
    value: str


class _MutableStud(Stud):
    model_config = ConfigDict(extra="forbid", frozen=False)
    value: str


class _ExplicitFrozenStud(Stud):
    model_config = ConfigDict(extra="forbid", frozen=True)
    value: str


class TestStudIsFrozen:
    def test_base_class_is_frozen(self) -> None:
        assert Stud.is_frozen is True

    def test_default_subclass_is_frozen(self) -> None:
        assert _DefaultStud.is_frozen is True

    def test_override_to_mutable(self) -> None:
        assert _MutableStud.is_frozen is False

    def test_explicit_frozen_override(self) -> None:
        assert _ExplicitFrozenStud.is_frozen is True


class TestEmptyStud:
    def test_instantiation(self) -> None:
        from pylego_blocks import EmptyStud
        s = EmptyStud()
        assert isinstance(s, EmptyStud)

    def test_no_fields(self) -> None:
        from pylego_blocks import EmptyStud
        assert EmptyStud.model_fields == {}

    def test_frozen(self) -> None:
        from pylego_blocks import EmptyStud
        assert EmptyStud.is_frozen is True

    def test_void_stud_alias(self) -> None:
        from pylego_blocks import EmptyStud, VoidStud
        assert VoidStud is EmptyStud

    def test_equality(self) -> None:
        from pylego_blocks import EmptyStud
        assert EmptyStud() == EmptyStud()

    def test_usable_as_block_io(self) -> None:
        import asyncio
        from pylego_blocks import Block, EmptyStud

        class NoopBlock(Block[EmptyStud, EmptyStud]):
            input_model = EmptyStud
            output_model = EmptyStud

            async def run(self, inp: EmptyStud) -> EmptyStud:
                return EmptyStud()

        result = asyncio.run(NoopBlock().run(EmptyStud()))
        assert isinstance(result, EmptyStud)
