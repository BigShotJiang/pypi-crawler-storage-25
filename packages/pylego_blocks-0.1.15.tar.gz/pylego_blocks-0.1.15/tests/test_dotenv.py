"""pylego_blocks dotenv 자동 로드 테스트 (#266)."""

from __future__ import annotations

import importlib
import os
import sys
from unittest.mock import MagicMock, patch


def test_dotenv_not_called_when_not_installed() -> None:
    """python-dotenv 미설치 시 load_dotenv 가 호출되지 않는다."""
    with patch.dict(sys.modules, {"dotenv": None}):
        import pylego_blocks as pb_mod
        importlib.reload(pb_mod)
        # 오류 없이 임포트 완료 — 단순 연기(pass-through) 확인


def test_dotenv_load_called_when_installed() -> None:
    """python-dotenv 설치 시 load_dotenv() 가 자동 호출된다."""
    import pylego_blocks as pb_mod  # ensure module is cached before patching
    mock_dotenv = MagicMock()
    mock_dotenv.load_dotenv = MagicMock()

    with patch.dict(sys.modules, {"dotenv": mock_dotenv}):
        importlib.reload(pb_mod)

    mock_dotenv.load_dotenv.assert_called_once()


def test_dotenv_extras_map_contains_dotenv() -> None:
    """PYLEGO_EXTRAS_MAP 에 dotenv 항목이 있다."""
    from pylego_blocks.compat import PYLEGO_EXTRAS_MAP
    assert "dotenv" in PYLEGO_EXTRAS_MAP
    assert PYLEGO_EXTRAS_MAP["dotenv"] == "dotenv"


def test_is_available_dotenv_false_when_not_installed() -> None:
    """dotenv 미설치 시 is_available('dotenv') 는 False 다."""
    with patch.dict(sys.modules, {"dotenv": None}):
        from pylego_blocks.compat import is_available
        # find_spec 은 None 인 모듈을 미설치로 처리
        assert is_available("dotenv") is False


def test_dotenv_respects_existing_env_vars() -> None:
    """load_dotenv 기본 동작은 기존 환경변수를 덮어쓰지 않는다."""
    import pylego_blocks as pb_mod  # ensure module is cached before patching
    os.environ["PYLEGO_TEST_KEY"] = "existing"
    mock_dotenv = MagicMock()

    def _fake_load_dotenv(**_kwargs: object) -> None:
        # load_dotenv override=False(기본값): 기존 값 유지
        pass

    mock_dotenv.load_dotenv = _fake_load_dotenv

    with patch.dict(sys.modules, {"dotenv": mock_dotenv}):
        importlib.reload(pb_mod)

    assert os.environ.get("PYLEGO_TEST_KEY") == "existing"
    del os.environ["PYLEGO_TEST_KEY"]
