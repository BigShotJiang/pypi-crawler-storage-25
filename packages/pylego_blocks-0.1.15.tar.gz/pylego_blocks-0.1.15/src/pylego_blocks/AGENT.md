# pylego — AI 개발자 참조 가이드

이 파일은 AI 에이전트(Claude Code, GPT 등)가 pylego 코드베이스를 즉시 이해하고
신규 블록·파이프라인·테스트를 작성할 수 있도록 설계된 단일 참조 문서입니다.

---

## 0. 신규 프로젝트 설정 (필독)

> **패키지명 vs 임포트명 — 반드시 구분할 것**
> - 설치: `pip install pylego-blocks` 또는 `uv add pylego-blocks`
> - 임포트: `from pylego_blocks import Block, Stud, Assembly` (패키지명과 다름)

### uv 프로젝트 초기 설정

```bash
uv init my_project
cd my_project
uv add pylego-blocks
uv add --dev pytest pytest-asyncio
```

### pyproject.toml 필수 설정

```toml
[tool.pytest.ini_options]
asyncio_mode = "auto"   # 비동기 테스트 자동 인식 (필수)
```

### 실행 명령

```bash
uv run python main.py        # 실행
uv run pytest                # 전체 테스트
uv run pytest tests/test_my.py -v  # 특정 파일
```

### 선택적 의존성 설치

```bash
uv add "pylego-blocks[anthropic]"   # Claude API
uv add "pylego-blocks[scheduler]"   # 스케줄러 (apscheduler)
uv add "pylego-blocks[serve]"       # FastAPI HTTP 서빙
uv add "pylego-blocks[slack]"       # Slack 알림
uv add "pylego-blocks[dotenv]"      # .env 자동 로드 (python-dotenv)
```

---

## 1. 핵심 추상화 3개만 기억

```
Stud   → 블록 간 I/O 계약 (pydantic BaseModel, frozen, extra="forbid")
Block  → 단일 책임 실행 단위 (async run(Stud) → Stud)
Assembly → 블록 체인 (조립 시점 계약 자동 검증)
```

> **설계 원칙: 단순한 파이프라인에는 단순한 구조를.**
> `MultiPerspectiveBlock`·`SemanticRetryBlock`은 복잡성 비용(토큰·지연·디버깅)을
> 수반한다. 단순 변환 파이프라인에는 단순 블록을 사용하고,
> 다층 검증이 실제로 필요한 곳에만 선택적으로 적용한다.

**설계 원칙 전체 목록:**

| # | 원칙 |
|---|------|
| 21 | 파이프라인은 예산을 인식한다 |
| 22 | 관측성 비용도 제어 대상이다 |
| 23 | 단순한 파이프라인에는 단순한 구조를 |
| 24 | 감시자도 감시받는다 |
| 25 | 루프는 스스로 끊는다 |
| 26 | 파이프라인 구조는 눈에 보여야 한다 |
| 27 | 함수도 블록이 될 수 있다 |
| 28 | 래퍼는 선언 순서대로 쌓인다 |
| 29 | 신뢰는 투명성에서 나온다 |
| 30 | LLM 백엔드는 교체 가능해야 한다 |
| 31 | AI는 조합하고, 사람은 검토한다 |
| 32 | 프레임워크가 멈출 수 있어야 한다 — 실패한 파이프라인은 자동으로 격리된다 |
| 33 | 진단은 요약이 아니라 증거에서 나온다 |
| 34 | 레지스트리는 과거를 기억한다 |
| 35 | 통계는 추세를 이야기한다 |
| 36 | 글로벌 정책이 개별 정책을 감시한다 |
| 37 | 입력 계약은 실행 직전에도 검증된다 |
| 38 | 통계적 신뢰도가 의사결정의 전제다 — 샘플 크기가 적을수록 판단을 유보한다 |
| 39 | 격리는 관찰에서 통제로 진화한다 — 경보는 차단으로 이어져야 의미가 있다 |
| 40 | 원인 없는 진단은 절반의 지혜다 — 변화량 뒤에 숨겨진 맥락을 추적한다 |
| 41 | 오류의 무게가 다르다 — 심각도가 신뢰도를 결정한다 |
| 42 | 시스템은 스스로 회복의 가능성을 타진한다 |
| 43 | 원인은 하나가 아니다 — 복합 인과를 추적한다 |
| 44 | 우선순위가 심각도를 결정한다 — 비즈니스 임팩트에 따라 위험 가중치가 달라진다 |
| 45 | 동결 해제는 관찰에서 신뢰로 이어진다 — 회복 구간이 완전 재개보다 안전하다 |
| 46 | 반복은 증거다 — 재현되는 원인이 유력 원인이다 |
| 50 | 망각은 선택적이어야 한다 — 위험의 유통기한은 블록의 성격이 결정한다 |
| 51 | 복구의 속도는 신뢰의 증거가 결정한다 — 실시간 품질이 확장 속도를 결정한다 |
| 52 | 연결의 강도가 인과의 진실성을 결정한다 — 상관계수 없는 인과 사슬은 추측이다 |
| 53 | 코드베이스 구조는 역할 경계를 드러낸다 — 빌더 도구와 운영 도구는 분리된다 |
| 54 | 발견성이 사용성을 결정한다 — 레지스트리는 사용자 언어로 말한다 |
| 55 | 파일 크기는 복잡성의 증거다 — 1000줄을 넘는 파일은 분리 신호다 |
| 56 | 복잡성은 옵트인이어야 한다 — 기본 경로는 항상 단순하게 |
| 57 | 갱생은 증명으로 완성된다 — 연속 성공이 과거 실패의 가중치를 경감한다 |
| 58 | 진단은 대화로 완성된다 — AI의 항변이 인과 스코어를 교정한다 |
| 59 | 경계 없는 설계는 책임 없는 설계다 — 하위 호환 브릿지는 경고와 함께 유지기한을 선언한다 |

---

## 2. 새 블록 작성 — 최소 템플릿

```python
from pylego_blocks import Block, Stud

class MyInput(Stud):       # 입력 계약
    value: int

class MyOutput(Stud):      # 출력 계약
    result: str

class MyBlock(Block[MyInput, MyOutput]):
    input_model = MyInput   # 필수 — 생략 시 TypeError
    output_model = MyOutput # 필수 — 생략 시 TypeError

    async def run(self, inp: MyInput) -> MyOutput:
        return MyOutput(result=str(inp.value))
```

**규칙:**
- `input_model` / `output_model` 은 반드시 선언 (클래스 속성)
- `run()` 은 반드시 `async def` (동기 로직도 await 없이 반환 가능)
- `Stud` 는 frozen=True — `.model_copy(update={...})` 로 변경값 생성
- 블록은 다른 블록을 직접 참조하지 않음 (Stud 계약만 본다)

### 입출력이 없는 블록 — EmptyStud / VoidStud

입력 또는 출력이 필요 없는 블록(DB 초기화, 알림 단순 전송 등)에
더미 Stud를 직접 선언할 필요 없이 내장 타입을 사용한다.

```python
from pylego_blocks import Block, EmptyStud  # VoidStud 는 EmptyStud 의 별칭

class InitDbBlock(Block[EmptyStud, EmptyStud]):
    input_model  = EmptyStud
    output_model = EmptyStud

    async def run(self, inp: EmptyStud) -> EmptyStud:
        await db.initialize()
        return EmptyStud()
```

### Stud 의미론적 검증 — @field_validator / @model_validator

```python
from pydantic import field_validator, model_validator
from pylego_blocks import Stud

class AiResponse(Stud):
    verdict: str
    confidence: float

    @field_validator("confidence")          # 단일 필드 범위 검증
    @classmethod
    def confidence_in_range(cls, v: float) -> float:
        if not (0.0 <= v <= 1.0):
            raise ValueError(f"confidence는 0~1 범위: {v}")
        return v

    @model_validator(mode="after")          # 교차 필드 일관성 검증
    def unknown_needs_low_confidence(self) -> "AiResponse":
        if self.verdict == "UNKNOWN" and self.confidence > 0.5:
            raise ValueError("UNKNOWN은 confidence ≤ 0.5 이어야 합니다")
        return self
```

**검증 계층 선택 기준:**

| 검증 유형 | 위치 | 이유 |
|----------|------|------|
| 숫자 범위·형식·열거형 | `Stud @field_validator` | 즉시, 비용 없음 |
| 교차 필드 일관성 | `Stud @model_validator` | 즉시, 비용 없음 |
| DB/캐시/외부 서비스 | `Unit.validate()` | async 필요 |
| 실행 후 출력 의미 검증 | `Unit.verify()` | 출력이 있어야 확인 가능 |

---

## 3. Assembly 조립

```python
from pylego_blocks import Assembly

pipeline = Assembly([BlockA(), BlockB(), BlockC()])
# BlockA.output_model == BlockB.input_model 이어야 함 — 불일치 시 조립 시점 오류

result = pipeline.run_sync(MyInput(value=1))  # 동기
result = await pipeline.run(MyInput(value=1)) # 비동기
```

**조립 오류:**
- `IncompatibleSnapError`: 블록 간 Stud 불일치
- `CyclicAssemblyError`: 동일 인스턴스 재사용 또는 순환 참조
- `ValueError("Assembly 는 최소 한 개의 블록")`: 빈 리스트

---

## 4. 파일 맵

```
src/pylego/
├── core/
│   ├── stud.py          # Stud 베이스 클래스
│   ├── block.py         # Block 베이스 클래스 + __init_subclass__ 검증
│   ├── assembly.py      # Assembly (체인 + 체크포인팅 + 이벤트)
│   ├── branch.py        # Branch (조건 분기)
│   ├── fanout.py        # FanOut (병렬 분기) + Gathered
│   ├── events.py        # BlockEvent / EventBus / LoggingEventBus / CollectingEventBus / NestedEventBus
│   ├── otel.py          # OtelEventBus (optional: pylego[otel])
│   ├── graph.py         # 하위 호환 shim — ops.health / ops.causal / ops.diff / core.visualize 재익스포트
│   ├── visualize.py     # BlockStat / build_stats / to_mermaid / to_dot / to_html (v0.1.3 분리)
│   ├── queue.py         # Queue[T] / WorkerPool[T,R] / DeadLetterQueue[T]
│   ├── redis_queue.py   # RedisQueue / RedisWorkerPool / RedisDeadLetterQueue / make_queue
│   ├── resilience.py    # RetryBlock / FallbackBlock / TimeoutBlock / CircuitBreakerBlock
│   ├── builder.py       # BlockBuilder / wrap() 플루언트 빌더
│   ├── callable_block.py# CallableBlock (함수 기반 블록)
│   ├── tap.py           # TapBlock (비차단 관찰 블록)
│   ├── semantic_retry.py# SemanticRetryBlock (의미론적 실패 재시도)
│   ├── runtime.py       # AsyncRuntime / SyncRuntime / ProcessRuntime
│   ├── store.py         # Store / InMemoryStore / FileStore / StoreBlock
│   ├── stream.py        # StreamBlock (AsyncGenerator 기반)
│   ├── checkpoint.py    # Checkpoint / MemoryCheckpoint / FileCheckpoint
│   └── compat.py        # check_chain / check_connection / CompatibilityError / CompatibilityResult / AssemblyValidator / SemanticCompatibilityError
├── blocks/
│   ├── db/
│   │   ├── base.py      # QueryBlock / QueryInput / QueryResult (추상 베이스)
│   │   ├── duckdb.py    # DuckDbBlock (asyncio.to_thread, pylego[duckdb])
│   │   ├── sqlite.py    # SqliteBlock (aiosqlite, pylego[sqlite])
│   │   ├── mysql.py     # MySqlBlock (aiomysql + 환경변수, pylego[mysql])
│   │   ├── mysql_pool.py# PooledMySqlBlock (aiomysql 커넥션 풀, pylego[mysql])
│   │   ├── transactional.py# TransactionalQueryBlock (BEGIN/COMMIT/ROLLBACK, pylego[mysql])
│   │   └── db_to_excel.py  # DbToExcelUnit (대용량 DB→Excel, pylego[mysql,excel])
│   ├── llm/
│   │   ├── anthropic.py     # AnthropicBlock (Claude API, pylego[anthropic])
│   │   ├── openai.py        # OpenAiBlock (Chat Completions, pylego[openai])
│   │   ├── ollama.py        # OllamaBlock (로컬 LLM, pylego[ollama])
│   │   ├── base.py          # BaseLlmBlock / LlmInput / LlmResult / _LLM_REGISTRY
│   │   ├── anthropic_llm.py # AnthropicLlmBlock (LlmInput → AnthropicBlock 어댑터)
│   │   ├── openai_llm.py    # OpenAiLlmBlock (LlmInput → OpenAiBlock 어댑터)
│   │   ├── ollama_llm.py    # OllamaLlmBlock (LlmInput → OllamaBlock 어댑터)
│   │   └── router.py        # LlmRouter (PYLEGO_LLM_BACKEND/MODEL 환경변수 라우팅)
│   ├── file/
│   │   ├── csv.py       # CsvReadBlock / CsvWriteBlock (표준 csv, 추가 의존성 없음)
│   │   ├── excel.py     # ExcelReadBlock / ExcelWriteBlock (pylego[excel])
│   │   └── pdf.py       # PdfReadBlock / PdfWriteBlock (pylego[pdf])
│   ├── cache/
│   │   └── redis_cache.py# RedisCacheBlock get/set/delete (pylego[redis])
│   ├── search/
│   │   └── duckduckgo.py# DuckDuckGoSearchBlock (API 키 불필요, pylego[duckduckgo])
│   ├── http_base.py     # BaseHttpBlock (공통 HTTP 기반 클래스)
│   ├── http_request.py  # HttpRequestBlock (범용 REST, pylego[http])
│   ├── http_session.py  # HttpSessionUnit (로그인·쿠키·토큰 취득, pylego[http])
│   ├── template.py      # TemplateBlock (Jinja2 렌더링, pylego[jinja2])
│   ├── subprocess_block.py# SubprocessBlock (외부 프로세스 비동기 실행)
│   ├── llm/
│   │   └── embedding.py # EmbeddingBlock (OpenAI/Ollama 텍스트 임베딩, pylego[openai|ollama])
│   ├── text/
│   │   └── chunk.py     # ChunkTextBlock (재귀적 텍스트 청킹, 의존성 없음)
│   └── vector/
│       └── chromadb_store.py# VectorUpsertBlock / VectorQueryBlock (pylego[chromadb])
├── unit.py              # Unit / UnitResult / UnitPipeline / ConfigBlock / ResultUnit
├── serve.py             # build_app(assembly) → FastAPI / serve()
├── registry.py          # BlockRegistry / BlockRuntimeStat / BlockInfo / default_registry / register
├── declarative.py       # load_assembly_from_yaml(path)
├── compat.py            # is_available() / @requires() / PYLEGO_EXTRAS_MAP
├── scheduler.py         # Scheduler / SchedulerPolicy / JobStatus / run_once() (pylego[scheduler])
├── inspect/             # CLI inspect 서브커맨드 구현
├── cli.py               # CLI 진입점 (run / serve / assemble / inspect / run-unit / schedule)
└── ops/                 # 운영 도구 패키지 — Builder(core)와 분리된 Operator 계층 (v0.1.3, 설계 원칙 53)
    ├── causal.py        # EnvironmentContext / CausalFactor / VersionContext
    ├── diff.py          # HealthDiff (파이프라인 상태 시맨틱 비교)
    └── health.py        # PipelineHealth / build_health_summary
```

> **v0.1.3 아키텍처 — Builder / Operator 임포트 가이드 (설계 원칙 53)**
>
> pylego는 두 계층으로 분리된다:
>
> | 계층 | 패키지 | 역할 | 예시 임포트 |
> |------|--------|------|------------|
> | **Builder** | `pylego.core` / `pylego` | 블록·파이프라인 구성 | `from pylego_blocks import Block, Assembly` |
> | **Operator** | `pylego.ops` | 진단·비교·인과 분석 | `from pylego_blocks.ops.health import build_health_summary` |
>
> `from pylego_blocks import build_health_summary` 와 `from pylego_blocks.core.graph import PipelineHealth` 는
> 하위 호환을 위해 유지되지만, 신규 코드에서는 `pylego.ops.*` 직접 임포트를 권장한다.
> `pylego.core.graph` 경유 임포트는 **v0.2.0부터 `DeprecationWarning` 을 발생**시키며
> **v1.0.0에서 완전 제거** 예정이다.
>
> ```python
> # Builder 계층 — 파이프라인 구성 (변경 없음)
> from pylego_blocks import Block, Stud, Assembly, observe
> from pylego_blocks.core.events import CollectingEventBus
>
> # Operator 계층 — 진단·분석 (v0.1.3 권장 경로)
> from pylego_blocks.ops.health import PipelineHealth, build_health_summary
> from pylego_blocks.ops.causal import CausalFactor, VersionContext, EnvironmentContext
> from pylego_blocks.ops.diff import HealthDiff
>
> # 하위 호환 경로 (DeprecationWarning 발생, v1.0.0에서 제거 예정)
> from pylego_blocks import build_health_summary, PipelineHealth  # graph.py shim 경유
> from pylego_blocks.core.graph import BlockStat, build_stats     # DeprecationWarning!
> ```

---

## 5. 주요 패턴 — 복사해서 바로 사용

### FanOut (병렬 분기)
```python
from pylego_blocks import FanOut, Gathered

fan = FanOut([BlockA(), BlockB()])  # 동일 입력 → 두 블록 병렬 실행
result = fan.run_sync(inp)
a_out, b_out = result.results  # Gathered.results: tuple[Any, ...]
```

### Branch (조건 분기)
```python
from pylego_blocks import Branch

# predicate True → on_true 블록, False → on_false 블록
branch = Branch(
    predicate=lambda inp: inp.flag,
    on_true=TrueBlock(),
    on_false=FalseBlock(),
)
```

### 에러 복구
```python
from pylego_blocks import RetryBlock, RetryPolicy, FallbackBlock, TimeoutBlock, CircuitBreakerBlock

retry   = RetryBlock(MyBlock(), policy=RetryPolicy(max_attempts=3, delay_sec=1.0, backoff=2.0))
fallbk  = FallbackBlock(primary=MyBlock(), fallback=CacheBlock())
timeout = TimeoutBlock(MyBlock(), timeout_sec=5.0)
breaker = CircuitBreakerBlock(MyBlock(), failure_threshold=3, reset_timeout=30.0)
```

### TapBlock (비차단 감시)
```python
from pylego_blocks import TapBlock

# 흐름을 방해하지 않고 데이터를 관찰한다. observer 실패는 무시됨(기본값).
pipeline = Assembly([
    AiBlock(),
    TapBlock(SignalBlock()),   # 의심 지수 기록 등 사이드 채널
    VerdictBlock(),            # AiBlock의 출력이 그대로 전달됨
])

# callable 버전
TapBlock(lambda inp: store.record(inp), item_type=MyStud)
# observer 실패를 파이프라인 오류로 처리하려면:
TapBlock(SignalBlock(), ignore_errors=False)
```

### wrap() 플루언트 빌더 (설계 원칙 28)
```python
from pylego_blocks import wrap

# 래퍼는 선언 순서대로 바깥에서 안쪽으로 적용된다.
block = (
    wrap(MyBlock())
    .retry()                        # RetryBlock (기본 RetryPolicy)
    .timeout(5.0)                   # TimeoutBlock
    .circuit_breaker(failure_threshold=3)  # CircuitBreakerBlock
    .build()
)

# SemanticRetryBlock 포함
block = (
    wrap(AiBlock())
    .semantic_retry(verify_fn=check, enrich_fn=inject, max_attempts=3)
    .timeout(10.0)
    .build()
)

# FallbackBlock
block = wrap(PrimaryBlock()).fallback(CacheBlock()).build()
```

> **래퍼 중첩 제약:** 동일 종류 래퍼 중첩 금지 (`RetryBlock(RetryBlock(...))` 금지).
> `wrap()` 체인에서도 동일 메서드를 두 번 호출하지 않는다.

```python
# 래퍼 스택 확인 (설계 원칙 29 — 신뢰는 투명성에서 나온다)
builder = wrap(MyBlock()).retry().timeout(5.0).circuit_breaker()
builder.inspect()
# → ["CircuitBreakerBlock", "TimeoutBlock", "RetryBlock", "MyBlock"]

# 그래프에서 래퍼를 서브그래프로 전개
from pylego_blocks import to_mermaid, to_dot
block = builder.build()
print(to_mermaid(block, expand_wrappers=True))   # 서브그래프 포함 Mermaid
print(to_dot(block, expand_wrappers=True))       # cluster 포함 DOT
```

### CallableBlock (설계 원칙 27)
```python
from pylego_blocks import CallableBlock

# 클래스 없이 함수 하나로 블록 생성
async def double(inp: MyInput) -> MyOutput:
    return MyOutput(result=inp.value * 2)

block = CallableBlock(fn=double, input_model=MyInput, output_model=MyOutput)

# Assembly에서 직접 사용
pipeline = Assembly([
    CallableBlock(fn=preprocess, input_model=RawInput, output_model=CleanInput),
    MyHeavyBlock(),
])
```

> **fn 시그니처 검증 (생성 시점).**
> `CallableBlock`은 생성 시점에 `fn`의 첫 파라미터 타입과 반환 타입을
> `input_model` / `output_model`과 비교한다.
> 불일치 시 즉시 `TypeError`가 발생하므로 런타임 실행 전에 오류를 잡을 수 있다.
> 타입 어노테이션이 없으면 검증을 건너뛴다.

### SemanticRetryBlock (AI 의미론적 실패 재시도)
```python
from pylego_blocks import SemanticRetryBlock

# verify_fn이 예외를 raise하면 enrich_fn으로 새 입력을 만들어 재시도한다.
def check(inp: AiRequest, out: AiResponse) -> None:
    if out.verdict == "UNKNOWN":
        raise ValueError("판정 불가 — 형식을 지켜 재응답하라")

def inject(inp: AiRequest, out: AiResponse, error: str) -> AiRequest:
    return inp.model_copy(update={"error_context": f"이전 오류: {error}"})

block = SemanticRetryBlock(AiBlock(), verify_fn=check, enrich_fn=inject, max_attempts=3)
# 모든 재시도는 BlockRetryEvent로 관찰 가능

# 환각 루프 차단: 동일 오류 N회 연속 시 MaxRepeatedErrorError 발생
block = SemanticRetryBlock(
    AiBlock(), verify_fn=check, enrich_fn=inject,
    max_attempts=5, abort_on_repeated_error=2,
)

# error_similarity_fn: 사용자 정의 오류 유사도 판단 (기본: 문자열 동일 비교)
def fuzzy_same(a: str, b: str) -> bool:
    return a[:50] == b[:50]  # 앞 50자가 같으면 동일 오류로 판정

block = SemanticRetryBlock(
    AiBlock(), verify_fn=check, enrich_fn=inject,
    max_attempts=5, abort_on_repeated_error=2,
    error_similarity_fn=fuzzy_same,
)

# on_abort_fn: MaxRepeatedErrorError 대신 폴백 결과 반환
async def fallback(inp: AiRequest, error: str) -> AiResponse:
    return AiResponse(verdict="FALLBACK", confidence=0.0)

block = SemanticRetryBlock(
    AiBlock(), verify_fn=check, enrich_fn=inject,
    max_attempts=5, abort_on_repeated_error=2,
    on_abort_fn=fallback,
)
# 동일 오류 2회 연속 시 예외 대신 fallback() 결과 반환

# verify_after_abort=True(기본값): on_abort_fn 결과에도 verify_fn 적용
# 검증 실패 시 AbortVerificationError 발생 — MaxRepeatedErrorError와 구분됨
block = SemanticRetryBlock(
    AiBlock(), verify_fn=check, enrich_fn=inject,
    max_attempts=5, abort_on_repeated_error=2,
    on_abort_fn=fallback,
    verify_after_abort=True,   # 기본값 — on_abort_fn 결과도 verify_fn 통과 필수
)
# verify_after_abort=False 이면 on_abort_fn 결과를 검증 없이 그대로 반환
```

> **enrich_fn 주기적 갱신 권장.**
> AI 실패 양상은 모델 버전·프롬프트 변화에 따라 진화한다.
> `OtelEventBus(include_failed_payload=True)` 로 실패 페이로드를 수집하고,
> 누적된 사례를 분석하여 `enrich_fn` 의 컨텍스트 주입 전략을 주기적으로 갱신한다.
> 변경된 `enrich_fn` 은 반드시 인간이 검토 후 배포한다
> (AI가 자신의 재시도 전략을 스스로 수정하는 구조 금지).

> **환각 방어: ExecutionBudget 조합 권장.**
> AI가 완전히 환각(Hallucination) 상태일 때는 `enrich_fn`이 잘못된 컨텍스트를
> 주입하여 재시도를 낭비할 수 있다. `ExecutionBudget`과 조합하면 최악의
> 환각 루프를 예산 한계로 조기 차단할 수 있다:
>
> ```python
> with observe(ExecutionBudget(max_block_calls=5, max_total_seconds=10.0)):
>     result = await SemanticRetryBlock(
>         AiBlock(), verify_fn=check, enrich_fn=inject, max_attempts=3,
>     ).run(inp)
> # 환각 루프가 예산 초과 시 BudgetExceededError 로 조기 종료
> ```

### MultiPerspectiveBlock (다관점 합의)
```python
from pylego_blocks import MultiPerspectiveBlock, MajorityVote, ConsensusPolicy

block = MultiPerspectiveBlock(
    perspectives=[PerspA(), PerspB(), PerspC()],
    vote_fn=MajorityVote(min_agreement=2),
    policy=ConsensusPolicy(raise_error=True),
)
# 합의 실패 → ConsensusError (policy 미설정 시 기본 raise)
```

> **관점 다양성 경고.**
> 동일 기반 모델을 여러 관점으로 사용할 경우 모델 고유의 편향이 공유되어
> "정중하고 논리적인 합의된 오답"에 도달할 수 있다.
> 다양성이 중요한 검증에는 프롬프트·온도·모델을 의도적으로 달리 설정할 것.
> 모델 다양성 확보는 프레임워크가 아닌 **사용자의 설계 책임**이다.

### DuckDuckGoSearchBlock (API 키 불필요)
```python
from pylego_blocks import DuckDuckGoSearchBlock, DuckDuckGoSearchInput

# API 키 없이 바로 사용 (pip install pylego-blocks[duckduckgo])
block = DuckDuckGoSearchBlock()
result = await block.run(DuckDuckGoSearchInput(query="pylego framework", num=5))
for item in result.items:
    print(item.title, item.link, item.snippet)
```

**Stud 요약:**

| 클래스 | 필드 |
|--------|------|
| `DuckDuckGoSearchInput` | `query`, `num=5` |
| `GoogleSearchResult` (공유) | `items: list[SearchItem]`, `total_results` |
| `SearchItem` | `title`, `link`, `snippet` |

### DB 쿼리 블록 (QueryBlock / DuckDbBlock / SqliteBlock / MySqlBlock / PooledMySqlBlock / TransactionalQueryBlock)
```python
from pylego_blocks import DuckDbBlock, SqliteBlock, MySqlBlock, PooledMySqlBlock, TransactionalQueryBlock, TransactionalInput
from pylego_blocks.blocks.db.base import QueryInput

# ── DuckDbBlock (pip install pylego-blocks[duckdb]) ─────────────────────────────────
block = DuckDbBlock()                    # 기본: 인메모리 DB
block = DuckDbBlock(database="data.db") # 파일 DB
result = await block.run(QueryInput(query="SELECT 1 AS n"))
# result.rows == [{"n": 1}], result.row_count == 1

# 파라미터 바인딩 ($1, $2, ...)
result = await block.run(QueryInput(
    query="SELECT * FROM t WHERE id = $1", params=[42]
))

# ── SqliteBlock (pip install pylego-blocks[sqlite]) ─────────────────────────────────
block = SqliteBlock(database=":memory:")
block = SqliteBlock(database="app.db")
result = await block.run(QueryInput(
    query="SELECT ? AS v", params=["hello"]
))
# result.rows == [{"v": "hello"}]

# ── MySqlBlock (pip install pylego-blocks[mysql]) ───────────────────────────────────
# 생성자 인수로 직접 지정
block = MySqlBlock(host="localhost", port=3306, user="root", password="secret", db="mydb")
# 또는 환경변수로 지정 (PYLEGO_MYSQL_HOST/PORT/USER/PASSWORD/DB)
block = MySqlBlock()

result = await block.run(QueryInput(
    query="SELECT id, name FROM users WHERE id = %s", params=[1]
))

# ── PooledMySqlBlock (pip install pylego-blocks[mysql]) ─────────────────────────────
# 커넥션 풀 기반 — 고부하 환경에서 MySqlBlock 대신 사용
block = PooledMySqlBlock(host="localhost", user="root", password="secret", db="mydb",
                         min_size=1, max_size=10)
# 또는 환경변수 (PYLEGO_MYSQL_HOST/PORT/USER/PASSWORD/DB)
block = PooledMySqlBlock()

result = await block.run(QueryInput(query="SELECT id FROM users LIMIT 10"))
await block.close()   # 풀 반환 (프로세스 종료 전 호출 권장)

# ── TransactionalQueryBlock (pip install pylego-blocks[mysql]) ─────────────────────
# 단일 커넥션에서 여러 쿼리를 BEGIN/COMMIT/ROLLBACK 트랜잭션으로 실행
block = TransactionalQueryBlock(host="localhost", user="root", password="secret", db="mydb")
result = await block.run(TransactionalInput(queries=[
    QueryInput(query="INSERT INTO t VALUES (%s)", params=[1]),
    QueryInput(query="UPDATE t SET x=1 WHERE id=%s", params=[1]),
]))
# result.committed == True, result.results: list[QueryResult]
# 예외 발생 시 자동 ROLLBACK 후 예외 재전파

# ── 파이프라인에 DB 블록 통합 ────────────────────────────────────────────────
pipeline = Assembly([
    FetchBlock(),          # QueryInput 출력
    DuckDbBlock(),         # QueryResult 출력
    TransformBlock(),
])
```

**Stud 요약:**

| 클래스 | 필드 |
|--------|------|
| `QueryInput` | `query: str`, `params: list[Any] = []` |
| `QueryResult` | `rows: list[dict[str, Any]]`, `row_count: int` |
| `TransactionalInput` | `queries: list[QueryInput]` |
| `TransactionalResult` | `results: list[QueryResult]`, `committed: bool` |

### 알림·검색·번역 블록

```python
from pylego_blocks import (
    TelegramBlock, TelegramInput,
    GmailBlock, GmailInput,
    SlackBlock, SlackInput,
    DiscordBlock, DiscordInput,
    GoogleSearchBlock, GoogleSearchInput,
    GoogleTranslateBlock, GoogleTranslateInput,
)

# ── TelegramBlock (pip install pylego-blocks[telegram]) ─────────────────────────────
block = TelegramBlock(token="BOT_TOKEN")  # 또는 PYLEGO_TELEGRAM_TOKEN
await block.run(TelegramInput(chat_id="123456", text="<b>완료</b>", parse_mode="HTML"))

# ── GmailBlock (pip install pylego-blocks[gmail]) ───────────────────────────────────
block = GmailBlock(smtp_user="sender@gmail.com", smtp_password="앱비밀번호")
await block.run(GmailInput(to="recv@example.com", subject="제목", body="내용", html=False))

# ── SlackBlock (pip install pylego-blocks[slack]) ───────────────────────────────────
block = SlackBlock(webhook_url="https://hooks.slack.com/services/...")  # 또는 PYLEGO_SLACK_WEBHOOK_URL
await block.run(SlackInput(text="파이프라인 완료", channel="#alerts"))

# ── DiscordBlock (pip install pylego-blocks[discord]) ───────────────────────────────
block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/...")  # 또는 PYLEGO_DISCORD_WEBHOOK_URL
await block.run(DiscordInput(content="완료", embeds=[{"title": "결과", "color": 0x00FF00}]))

# ── GoogleSearchBlock (pip install pylego-blocks[google-search]) ────────────────────
block = GoogleSearchBlock(api_key="AIza...", search_engine_id="abc123")
# 또는 PYLEGO_GOOGLE_SEARCH_API_KEY / PYLEGO_GOOGLE_SEARCH_ENGINE_ID
result = await block.run(GoogleSearchInput(query="pylego framework", num=5))
for item in result.items:
    print(item.title, item.link)

# ── GoogleTranslateBlock (pip install pylego-blocks[google-translate]) ──────────────
block = GoogleTranslateBlock(api_key="AIza...")  # 또는 PYLEGO_GOOGLE_API_KEY
result = await block.run(GoogleTranslateInput(text="안녕하세요", target="en"))
print(result.translated_text, result.detected_source)

# ── 사이드채널 알림 (파이프라인 흐름 유지) ─────────────────────────────────
pipeline = Assembly([
    ProcessBlock(),
    TapBlock(TelegramBlock(token="BOT_TOKEN")),
    TapBlock(SlackBlock(webhook_url="...")),
])
```

**Stud 요약:**

| 클래스 | 필드 |
|--------|------|
| `TelegramInput` | `chat_id`, `text`, `parse_mode="HTML"` |
| `TelegramResult` | `message_id`, `chat_id` |
| `GmailInput` | `to`, `subject`, `body`, `html=False` |
| `GmailResult` | `accepted: list[str]` |
| `SlackInput` | `text`, `channel?`, `username?`, `icon_emoji?` |
| `SlackResult` | `ok: bool` |
| `DiscordInput` | `content`, `username?`, `embeds=[]` |
| `DiscordResult` | `ok: bool` |
| `GoogleSearchInput` | `query`, `num=5`, `lang="ko"` |
| `GoogleSearchResult` | `items: list[SearchItem]`, `total_results` |
| `SearchItem` | `title`, `link`, `snippet` |
| `GoogleTranslateInput` | `text`, `target`, `source?` |
| `GoogleTranslateResult` | `translated_text`, `detected_source?` |

### LLM 블록 (AnthropicBlock / OpenAiBlock / OllamaBlock)
```python
from pylego_blocks import AnthropicBlock, AnthropicInput
from pylego_blocks import OpenAiBlock, OpenAiInput
from pylego_blocks import OllamaBlock, OllamaInput

# ── AnthropicBlock (pip install pylego-blocks[anthropic]) ───────────────────────────
block = AnthropicBlock()  # ANTHROPIC_API_KEY 환경변수 사용
result = await block.run(AnthropicInput(
    model="claude-opus-4-5",
    messages=[{"role": "user", "content": "안녕하세요"}],
    system="당신은 도움이 되는 어시스턴트입니다.",
    max_tokens=256,
))
print(result.content, result.input_tokens, result.output_tokens)

# ── OpenAiBlock (pip install pylego-blocks[openai]) ─────────────────────────────────
block = OpenAiBlock()  # OPENAI_API_KEY 환경변수 사용
result = await block.run(OpenAiInput(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello"}],
    system="Be concise.",
    max_tokens=128,
))
print(result.content, result.finish_reason)

# ── OllamaBlock (pip install pylego-blocks[ollama], Ollama 서버 필요) ────────────────
block = OllamaBlock()
result = await block.run(OllamaInput(
    model="llama3.2",
    prompt="파이썬으로 Hello World 를 출력하는 코드를 작성해줘.",
    base_url="http://localhost:11434",  # 기본값
))
print(result.response)

# ── AI 파이프라인 예시 ───────────────────────────────────────────────────────
pipeline = Assembly([
    TemplateBlock(),          # 프롬프트 생성
    AnthropicBlock(),         # AI 응답
    TapBlock(SlackBlock()),   # 결과 알림 (사이드채널)
])
```

**Stud 요약:**

| 클래스 | 필드 |
|--------|------|
| `AnthropicInput` | `model`, `messages`, `system?`, `max_tokens=1024`, `temperature=1.0` |
| `AnthropicResult` | `content`, `model`, `stop_reason?`, `input_tokens`, `output_tokens` |
| `OpenAiInput` | `model`, `messages`, `system?`, `temperature=1.0`, `max_tokens?` |
| `OpenAiResult` | `content`, `model`, `finish_reason?`, `prompt_tokens`, `completion_tokens` |
| `OllamaInput` | `model`, `prompt`, `system?`, `base_url`, `temperature?`, `num_predict?` |
| `OllamaResult` | `response`, `model`, `done`, `prompt_eval_count?`, `eval_count?` |

### LLM 통합 추상화 계층 — BaseLlmBlock / LlmRouter (설계 원칙 30)
```python
from pylego_blocks import BaseLlmBlock, LlmInput, LlmResult
from pylego_blocks import AnthropicLlmBlock, OpenAiLlmBlock, OllamaLlmBlock
from pylego_blocks import LlmRouter

# ── LlmInput / LlmResult — 백엔드 독립 공통 Stud ─────────────────────────────
inp = LlmInput(
    prompt="파이썬 비동기의 장점을 설명해줘.",
    system="당신은 프로그래밍 교사입니다.",
    model="claude-opus-4-5",   # None이면 백엔드 기본값 사용
    max_tokens=512,
    temperature=0.7,
)
# LlmResult.content, .model, .input_tokens, .output_tokens

# ── 명시적 어댑터 직접 사용 ──────────────────────────────────────────────────
block = AnthropicLlmBlock()   # AnthropicBlock 위임, LlmInput/LlmResult 사용
block = OpenAiLlmBlock()      # OpenAiBlock 위임
block = OllamaLlmBlock()      # OllamaBlock 위임

result = await block.run(inp)
print(result.content, result.input_tokens)

# ── LlmRouter — 환경변수로 백엔드 선택 ──────────────────────────────────────
# PYLEGO_LLM_BACKEND=anthropic  (또는 openai / ollama)
# PYLEGO_LLM_MODEL=claude-opus-4-5  (선택적 — inp.model이 None이면 사용)
router = LlmRouter()           # env var 기반 자동 라우팅
result = await router.run(inp) # 런타임에 백엔드 결정

# 명시적 백엔드 고정 (테스트·특정 파이프라인)
router = LlmRouter(backend="openai")

# ── 백엔드 교체 패턴 — 코드 변경 없이 환경변수만 변경 ────────────────────────
import os
os.environ["PYLEGO_LLM_BACKEND"] = "anthropic"
os.environ["PYLEGO_LLM_MODEL"] = "claude-opus-4-5"

pipeline = Assembly([
    TemplateBlock(),         # TemplateResult (rendered 필드)
    PromptAdapter(),         # TemplateResult → LlmInput
    LlmRouter(),             # LlmResult — 백엔드 env var 으로 교체 가능
    TapBlock(SlackBlock()),  # 결과 알림
])

# ── 커스텀 백엔드 등록 ────────────────────────────────────────────────────────
class MyLlmBlock(BaseLlmBlock):
    backend_name = "mybackend"   # __init_subclass__ 에서 _LLM_REGISTRY에 자동 등록

    async def run(self, inp: LlmInput) -> LlmResult:
        ...  # 직접 구현
# 이후 LlmRouter(backend="mybackend") 로 사용 가능
```

**Stud 요약:**

| 클래스 | 필드 |
|--------|------|
| `LlmInput` | `prompt: str`, `system?`, `model?`, `max_tokens=1024`, `temperature=1.0` |
| `LlmResult` | `content: str`, `model: str`, `input_tokens: int`, `output_tokens: int` |

> **설계 원칙 30 — LLM 백엔드는 교체 가능해야 한다.**
> `LlmRouter`는 `PYLEGO_LLM_BACKEND` 환경변수 하나로 백엔드를 전환한다.
> 개발·스테이징·프로덕션 환경마다 다른 백엔드를 코드 변경 없이 사용할 수 있다.
> 백엔드별 어댑터는 `BaseLlmBlock` 상속 + `backend_name` 클래스 속성 선언으로 등록한다.

### CsvReadBlock / CsvWriteBlock
```python
from pylego_blocks import CsvReadBlock, CsvReadInput, CsvWriteBlock, CsvWriteInput

# ── 읽기 ─────────────────────────────────────────────────────────────────────
result = await CsvReadBlock().run(CsvReadInput(path="data.csv", delimiter=","))
for row in result.rows:
    print(row)  # dict[str, str]

# ── 쓰기 ─────────────────────────────────────────────────────────────────────
rows = [{"name": "홍길동", "age": "30"}, {"name": "김철수", "age": "25"}]
result = await CsvWriteBlock().run(CsvWriteInput(
    path="output.csv",
    rows=rows,
    fieldnames=["name", "age"],  # 미설정 시 첫 행 키 순서 사용
))
print(result.row_count)

# ── 헤더 없는 CSV ─────────────────────────────────────────────────────────────
result = await CsvReadBlock().run(CsvReadInput(path="raw.csv", has_header=False))
# rows[i]["0"], rows[i]["1"], ... (컬럼 인덱스 문자열 키)
```

**Stud 요약:**

| 클래스 | 필드 |
|--------|------|
| `CsvReadInput` | `path`, `delimiter=","`, `encoding="utf-8"`, `has_header=True` |
| `CsvReadResult` | `rows: list[dict[str, Any]]`, `row_count` |
| `CsvWriteInput` | `path`, `rows`, `fieldnames?`, `delimiter=","`, `encoding="utf-8"` |
| `CsvWriteResult` | `path`, `row_count` |

### TemplateBlock (Jinja2)
```python
from pylego_blocks import TemplateBlock, TemplateInput

block = TemplateBlock()
result = await block.run(TemplateInput(
    template="안녕하세요, {{ name }}님! 총 {{ count }}개의 항목이 있습니다.",
    context={"name": "홍길동", "count": 42},
))
print(result.rendered)
# → 안녕하세요, 홍길동님! 총 42개의 항목이 있습니다.

# AI 프롬프트 생성 파이프라인에서 TemplateBlock 사용
# (DB 결과 → 프롬프트 → AI → 알림)
pipeline = Assembly([
    SqliteBlock(),          # QueryResult 반환
    PromptBuilderBlock(),   # QueryResult → TemplateInput 변환
    TemplateBlock(),        # TemplateResult 반환
    AnthropicBlock(),       # AnthropicResult 반환
])
```

### RedisCacheBlock
```python
from pylego_blocks import RedisCacheBlock, CacheInput

cache = RedisCacheBlock()  # PYLEGO_REDIS_URL 또는 redis://localhost:6379

# 저장 (TTL 초 단위)
await cache.run(CacheInput(operation="set", key="user:1", value="홍길동", ttl=300))

# 조회
result = await cache.run(CacheInput(operation="get", key="user:1"))
print(result.value, result.hit)  # 홍길동 True

# 삭제
await cache.run(CacheInput(operation="delete", key="user:1"))

# 네임스페이스 — 저장 키: "session:abc"
await cache.run(CacheInput(operation="set", key="abc", value="data", namespace="session"))
```

**Stud 요약:**

| 클래스 | 필드 |
|--------|------|
| `CacheInput` | `operation: "get"\|"set"\|"delete"`, `key`, `value?`, `ttl?`, `namespace=""` |
| `CacheResult` | `value?`, `hit: bool`, `ok: bool` |

### SubprocessBlock
```python
from pylego_blocks import SubprocessBlock, SubprocessInput

block = SubprocessBlock()

# 기본 실행
result = await block.run(SubprocessInput(cmd=["git", "log", "--oneline", "-5"]))
if result.success:
    print(result.stdout)
else:
    print(result.stderr, result.returncode)

# 타임아웃 + 작업 디렉터리
result = await block.run(SubprocessInput(
    cmd=["python", "script.py"],
    cwd="/path/to/project",
    timeout=30.0,
))

# stdin 데이터 전달
result = await block.run(SubprocessInput(
    cmd=["python", "-c", "import sys; print(sys.stdin.read())"],
    stdin_data="hello",
))
```

**Stud 요약:**

| 클래스 | 필드 |
|--------|------|
| `SubprocessInput` | `cmd: list[str]`, `cwd?`, `env?`, `timeout?`, `stdin_data?` |
| `SubprocessResult` | `stdout`, `stderr`, `returncode`, `success` |

### EmbeddingBlock (텍스트 임베딩)
```python
from pylego_blocks import EmbeddingBlock, EmbeddingInput, EmbeddingResult

# ── OpenAI 백엔드 (pip install pylego-blocks[openai]) ────────────────────────────────
block = EmbeddingBlock()  # OPENAI_API_KEY 환경변수
result = await block.run(EmbeddingInput(
    texts=["안녕하세요", "반갑습니다"],
    model="text-embedding-3-small",  # 기본값
    backend="openai",                # 기본값
))
print(result.embeddings)  # list[list[float]]
print(result.total_tokens)

# ── Ollama 백엔드 (pip install pylego-blocks[ollama], Ollama 서버 필요) ──────────────
block = EmbeddingBlock(base_url="http://localhost:11434")
result = await block.run(EmbeddingInput(
    texts=["hello world"],
    model="nomic-embed-text",
    backend="ollama",
))

# ── VectorUpsertBlock 와 조합 (텍스트 → 임베딩 → 저장) ──────────────────────
pipeline = Assembly([
    EmbeddingBlock(),
    VectorUpsertBlock(),
])
```

**Stud 요약:**

| 클래스 | 필드 |
|--------|------|
| `EmbeddingInput` | `texts: list[str]`, `model="text-embedding-3-small"`, `backend="openai"` |
| `EmbeddingResult` | `embeddings: list[list[float]]`, `model: str`, `total_tokens: int` |

### ChunkTextBlock (재귀적 텍스트 청킹)
```python
from pylego_blocks import ChunkTextBlock, ChunkTextInput, ChunkTextResult

block = ChunkTextBlock()

# 기본 청킹 (단락 → 줄 → 공백 → 문자 순서 재귀 분할)
result = await block.run(ChunkTextInput(
    text="긴 문서 내용...",
    chunk_size=1000,    # 기본값: 문자 단위 최대 크기
    chunk_overlap=200,  # 기본값: 인접 청크 간 오버랩
))
print(result.chunks)       # list[str]
print(result.chunk_count)  # int

# 커스텀 구분자
result = await block.run(ChunkTextInput(
    text="a|b|c|d",
    chunk_size=50,
    chunk_overlap=10,
    separators=["|", ""],  # | 먼저 시도 → 실패 시 문자 단위
))

# RAG 파이프라인 조합 예시
pipeline = Assembly([
    ChunkTextBlock(),    # ChunkTextResult 반환
    ChunkToEmbedAdapter(), # list[str] → EmbeddingInput 변환
    EmbeddingBlock(),
    VectorUpsertBlock(),
])
```

**Stud 요약:**

| 클래스 | 필드 |
|--------|------|
| `ChunkTextInput` | `text: str`, `chunk_size=1000`, `chunk_overlap=200`, `separators=["\n\n","\n"," ",""]` |
| `ChunkTextResult` | `chunks: list[str]`, `chunk_count: int` |

### VectorUpsertBlock / VectorQueryBlock (ChromaDB 벡터 저장·검색)
```python
from pylego_blocks import VectorUpsertBlock, VectorUpsertInput, VectorQueryBlock, VectorQueryInput

# ── 저장 (pip install pylego-blocks[chromadb]) ──────────────────────────────────────
upsert = VectorUpsertBlock()                          # EphemeralClient (인메모리)
upsert = VectorUpsertBlock(persist_directory="./db") # PersistentClient (파일)

result = await upsert.run(VectorUpsertInput(
    collection="my_docs",
    ids=["doc1", "doc2"],
    embeddings=[[0.1, 0.2, ...], [0.3, 0.4, ...]],
    documents=["문서 내용 A", "문서 내용 B"],   # 선택적
    metadatas=[{"source": "wiki"}, {"source": "blog"}],  # 선택적
))
print(result.upserted_count, result.collection)

# ── 검색 ─────────────────────────────────────────────────────────────────────
query = VectorQueryBlock()

result = await query.run(VectorQueryInput(
    collection="my_docs",
    query_embeddings=[[0.1, 0.2, ...]],
    top_k=5,
    where={"source": {"$eq": "wiki"}},  # 메타데이터 필터 (선택적)
))
print(result.ids)        # list[list[str]]
print(result.distances)  # list[list[float]]
print(result.documents)  # list[list[str]] | None
```

**Stud 요약:**

| 클래스 | 필드 |
|--------|------|
| `VectorUpsertInput` | `collection="default"`, `ids`, `embeddings`, `documents?`, `metadatas?` |
| `VectorUpsertResult` | `upserted_count: int`, `collection: str` |
| `VectorQueryInput` | `collection="default"`, `query_embeddings`, `top_k=5`, `where?` |
| `VectorQueryResult` | `ids`, `distances`, `documents?`, `metadatas?` |

### 이벤트 관찰
```python
from pylego_blocks import observe, LoggingEventBus, CollectingEventBus, OtelEventBus, build_stats, build_health_summary, PipelineHealth

# 로깅 (실제 입출력값 기록)
with observe(LoggingEventBus()):
    result = await pipeline.run(inp)

# 수집 후 통계
bus = CollectingEventBus()
with observe(bus):
    result = await pipeline.run(inp)
stats = build_stats(bus.events)  # dict[block_name, BlockStat]

# 파이프라인 헬스 요약 + 드릴다운 (bus 전달 시 error_details 자동 채움)
health: PipelineHealth = build_health_summary(bus.events, bus=bus)
# health.overall          — "ok" | "degraded" | "critical"
# health.error_blocks     — 실패한 블록 이름 목록
# health.error_details    — dict[block_name, BlockFailedEvent] (원인 이벤트)
# health.slowest_block    — 가장 오래 걸린 블록 이름
# health.avg_elapsed_sec  — 블록 평균 실행 시간

# 블록별 이벤트 드릴다운
failed = bus.failed_events()              # list[BlockFailedEvent]
completed = bus.completed_events()        # list[BlockCompletedEvent]
events_for_a = bus.events_for("BlockA")  # 특정 블록 이벤트만

# to_html() 에 health 뱃지 + 에러 툴팁 삽입
from pylego_blocks import to_html
html = to_html(pipeline, health=health)

# OTEL (기본: 해시만 기록 / 실패 시 페이로드 기록 옵션)
otel_bus = OtelEventBus(include_failed_payload=True, max_payload_chars=500)
# BlockFailedEvent 발생 시 block.failed_input span attribute에 실제 입력 기록
```

> **고부하 환경 운용 경고.**
> `OtelEventBus`는 비동기 익스포터라도 span 객체 생성 비용이 이벤트마다 누적된다.
> `CollectingEventBus`는 이벤트 객체를 메모리에 계속 쌓는다.
> 지연에 민감한 고처리량 파이프라인에서는 감시 레이어 자체의 오버헤드를 고려해야 한다:
> - OTEL: 익스포터 수준의 샘플링 필터 또는 `payload_filter` 활용
> - 수집: `build_stats()` 호출 후 `bus.events` 를 즉시 비워 메모리 해제
> - 감시 완전 비활성화: `observe()` 블록 자체를 생략 (이벤트 전파 없음)

### NestedEventBus (중첩 파이프라인 이벤트 격리)
```python
from pylego_blocks import NestedEventBus, CollectingEventBus, observe

# NestedEventBus — 서브 파이프라인 이벤트를 네임스페이스로 분리하여 상위 버스에 전달
parent_bus = CollectingEventBus()
nested_bus = NestedEventBus(parent=parent_bus, namespace="sub")

with observe(parent_bus):
    # 직접 실행 — 서브 파이프라인 이벤트를 nested_bus 로 라우팅
    with observe(nested_bus):
        result = await sub_pipeline.run(inp)

# parent_bus.events 에는 "sub/BlockName" 형식으로 전달됨
# nested_bus.events 에는 원래 이름 그대로 저장됨

# build_health_summary 는 네임스페이스를 자동 분리
from pylego_blocks import build_health_summary
health = build_health_summary(parent_bus.events)
# health.sub_health["sub"]  — 서브 파이프라인 PipelineHealth
# health.sub_health["sub"].overall — "ok" | "degraded" | "critical"

# caused_by — 오류 인과 체인
from pylego_blocks.core.events import BlockFailedEvent
root_failure = BlockFailedEvent(
    block_name="DownstreamBlock", error=RuntimeError("DB error"),
    elapsed_sec=0.1, timestamp=0.0,
)
derived = BlockFailedEvent(
    block_name="WrapperBlock", error=RuntimeError("pipeline failed"),
    elapsed_sec=0.2, timestamp=0.1,
    caused_by=root_failure,   # 원인 이벤트 연결
)
# to_html() 에서 caused_by 가 있으면 점선 화살표(stroke-dasharray)로 시각화
```

### pylego.compat — 선택적 의존성 검사
```python
from pylego_blocks.compat import is_available, requires, PYLEGO_EXTRAS_MAP

# ── is_available — 런타임 extras 설치 여부 확인 ───────────────────────────────
if is_available("anthropic"):
    from pylego_blocks import AnthropicBlock

if is_available("chromadb"):
    from pylego_blocks import VectorUpsertBlock, VectorQueryBlock

# extras 이름 또는 패키지 이름 모두 허용
is_available("jinja2")    # True/False
is_available("openai")    # True/False

# ── @requires — async 함수 실행 전 extras 존재 보장 ──────────────────────────
from pylego_blocks import Block, Stud
from pylego_blocks.compat import requires

class MyBlock(Block[MyInput, MyOutput]):
    @requires("anthropic")
    async def run(self, inp: MyInput) -> MyOutput:
        import anthropic  # 안전하게 임포트
        ...

# 여러 extras 동시 검사
@requires("openai", "chromadb")
async def run_rag(inp: RagInput) -> RagResult:
    ...
# 미설치 시: ImportError("chromadb 가 설치되어 있지 않습니다. `pip install pylego-blocks[chromadb]`")

# ── PYLEGO_EXTRAS_MAP — extras → 실제 패키지 이름 매핑 테이블 ─────────────────
print(PYLEGO_EXTRAS_MAP["anthropic"])  # "anthropic"
print(PYLEGO_EXTRAS_MAP["jinja2"])     # "jinja2"
print(PYLEGO_EXTRAS_MAP["sqlite"])     # "aiosqlite"
```

### 비동기 큐 파이프라인
```python
from pylego_blocks import Queue, WorkerPool

src: Queue[MyInput] = Queue()
pool: WorkerPool[MyInput, MyOutput] = WorkerPool(MyBlock(), concurrency=4)

async with asyncio.TaskGroup() as tg:
    tg.create_task(pool.run(src))
    for item in items:
        await src.put(item)
    await src.close()
```

### HTTP API 서빙
```python
from pylego_blocks.serve import build_app
import uvicorn

app = build_app(assembly)          # FastAPI 앱 반환
uvicorn.run(app, host="0.0.0.0", port=8000)
# POST /run  — assembly.run(body) 실행
# GET  /health — 헬스체크
# GET  /openapi.json — OpenAPI 스키마
```

### Redis 분산 큐
```python
from pylego_blocks import RedisQueue, RedisWorkerPool, make_queue
import os

# 직접 생성
q = RedisQueue(MyInput, url="redis://localhost:6379", queue_name="jobs")

# 환경변수 기반 팩토리 (asyncio ↔ Redis 교체 한 줄)
os.environ["PYLEGO_QUEUE_BACKEND"] = "redis"
os.environ["PYLEGO_REDIS_URL"] = "redis://localhost:6379"
q = make_queue(MyInput, queue_name="jobs")
```

### Unit 계층 (3단계 생명주기)
```python
from pylego_blocks import Unit, UnitPipeline, UnitResult, ResultUnit, Stud

class MyUnit(Unit[MyInput]):
    name = "MyUnit"
    input_model = MyInput

    async def validate(self, inp: MyInput) -> None:   # 선택: 입력 검증
        if inp.value < 0:
            raise ValueError("음수 불가")

    async def run(self, inp: MyInput) -> MyOutput:    # 필수: 실행
        return MyOutput(result=str(inp.value))

    async def verify(self, inp: MyInput, result: MyOutput) -> None:  # 선택: 출력 검증
        pass

class MyResult(ResultUnit):
    async def on_success(self, result: object) -> UnitResult:
        return UnitResult(status="success", result=result)
    async def on_failure(self, reason: str | None, failed_at: str | None) -> UnitResult:
        return UnitResult(status="failure", reason=reason, failed_at=failed_at)

pipeline = UnitPipeline([MyUnit()], result_unit=MyResult())
result = pipeline.run_sync(MyInput(value=42))
```

### HTTP 블록 — 선택 기준 및 사용 패턴

| 상황 | 선택 |
|------|------|
| 단순 REST API 호출 (인증 불필요) | `HttpRequestBlock` |
| 로그인 → 쿠키·토큰 취득 | `HttpSessionUnit` |
| 인증 후 반복 API 호출 | `HttpSession` + `HttpRequestBlock` 조합 |
| 공통 헤더(Auth) + 다양한 엔드포인트 | `HttpRequestBlock(default_headers={"Authorization": "..."})` |

```python
from pylego_blocks import HttpRequestBlock, HttpRequestInput, HttpSessionUnit, HttpSessionInput, BaseHttpBlock

# ── 단순 REST 호출 ────────────────────────────────────────────────────────────
block = HttpRequestBlock()
result = await block.run(HttpRequestInput(
    method="GET",
    url="https://api.example.com/users",
    headers={"Authorization": "Bearer token"},
))
# result.status_code, result.json_data, result.ok

# ── 공통 헤더를 생성자에 등록 (반복 호출 편의) ──────────────────────────────
block = HttpRequestBlock(default_headers={"Authorization": "Bearer token"})
# 이후 요청마다 Authorization 헤더 자동 포함
result = await block.run(HttpRequestInput(url="https://api.example.com/users"))

# ── HttpSessionUnit: 로그인 → HttpSession(쿠키·토큰) 취득 ───────────────────
unit = HttpSessionUnit()
session = await unit.run(HttpSessionInput(
    login_url="https://example.com/api/login",
    credentials={"username": "admin", "password": "secret"},
    method="POST",
    token_field="access_token",    # JSON 응답에서 토큰 추출
    token_header="Authorization",  # 이후 요청 헤더명
    token_prefix="Bearer",
    verify_url="https://example.com/api/me",
))
# session.headers["Authorization"] == "Bearer <token>"
# session.cookies  — 쿠키 기반 인증이면 쿠키 포함

# ── BaseHttpBlock 상속으로 커스텀 HTTP 블록 작성 ─────────────────────────────
class MyApiBlock(BaseHttpBlock[MyInput, MyOutput]):
    input_model = MyInput
    output_model = MyOutput

    def __init__(self) -> None:
        super().__init__(
            default_headers={"X-Api-Key": "secret"},
            timeout=10.0,
        )

    async def run(self, inp: MyInput) -> MyOutput:
        merged = self._merge_headers({"Content-Type": "application/json"})
        ...
```

### Unit 확장 — 대용량·복합 작업 패턴

**Block/Assembly** 는 메모리에 올려도 무방한 단순 변환에 적합하다.  
**Unit** 은 사전 검증·후처리 보장·대용량 처리가 필요한 작업 단위에 적합하다.

| 기준 | Block/Assembly | Unit |
|------|---------------|------|
| 메모리 | 전량 적재 | 청크 루프 가능 |
| 검증 | 없음 | validate / verify 3단계 |
| 오류 추적 | 예외 전파 | `failed_at` 컨텍스트 포함 |
| 외부 리소스 관리 | 블록마다 분산 | Unit 내 통합 관리 |

#### DbToExcelUnit — 대용량 DB → Excel 저장 예제

```python
from pylego_blocks import DbToExcelUnit, DbToExcelInput, UnitPipeline, ResultUnit, UnitResult

# Unit 생성 — DB 연결 정보는 생성자에서 (Stud 데이터 흐름에 포함하지 않음)
unit = DbToExcelUnit(host="localhost", user="root", password="secret", db="mydb")

class MyResult(ResultUnit):
    async def on_success(self, result: object) -> UnitResult:
        return UnitResult(status="success", result=result)
    async def on_failure(self, reason: str | None, failed_at: str | None) -> UnitResult:
        return UnitResult(status="failure", reason=reason, failed_at=failed_at)

pipeline = UnitPipeline([unit], result_unit=MyResult())
result = pipeline.run_sync(DbToExcelInput(
    query="SELECT id, name, score FROM users WHERE active = %s",
    params=[1],
    output_path="/data/users.xlsx",
    chunk_size=2000,   # fetchmany 청크 크기 — 메모리 상한 조절
    sheet_name="Users",
))
# result.status == "success"
# result.result.row_count  — 실제 저장된 행 수
```

**내부 동작 (3단계):**
```
validate()  출력 디렉터리 존재·쓰기 가능, chunk_size ≥ 1
    ↓
run()       aiomysql DictCursor.fetchmany(chunk_size) 루프
            openpyxl write_only 모드 — 전체 워크북을 메모리에 쌓지 않음
            청크마다 ws.append() → 완료 후 asyncio.to_thread(wb.save)
    ↓
verify()    파일 존재 여부 + 크기 > 0 확인
```

**커스텀 Unit 작성 체크리스트:**
1. `input_model = MyInput` 선언 (생략 시 런타임 경고)
2. `validate()` — 비싼 작업 실행 전 선행 조건 검사
3. `run()` — 핵심 로직. 대용량이면 청크·스트림·페이지네이션 사용
4. `verify()` — 출력물이 실제로 유효한지 검사 (파일 존재, 카운트 일치 등)
5. 연결 정보·설정은 `__init__` 에 — Stud 는 순수 데이터만 담는다

### YAML 선언형 Assembly
```python
from pylego_blocks.declarative import load_assembly_from_yaml
assembly = load_assembly_from_yaml("pipeline.yaml")
```
```yaml
# pipeline.yaml
assembly:
  name: MyPipeline
  blocks:
    - class: mypackage.blocks.BlockA
    - class: mypackage.blocks.BlockB
      init:
        param: value
```

### BlockRegistry v2 — 검색·메타데이터·Stud 탐색 (M88/M125)
```python
from pylego_blocks.registry import BlockRegistry, default_registry, register

# ── 메타데이터와 함께 등록 ────────────────────────────────────────────────────
# description / tags 미설정 시 UserWarning 발생 (M125 — 설계 원칙 54)
@register(tags=["llm", "nlp"], description="텍스트를 Claude API로 처리한다")
class MyLlmBlock(Block[MyInput, MyOutput]):
    input_model = MyInput
    output_model = MyOutput
    async def run(self, inp: MyInput) -> MyOutput: ...

# ── describe — 단일 블록 메타데이터 ──────────────────────────────────────────
info = default_registry.describe("MyLlmBlock")
# info.name, info.description, info.tags, info.input_model, info.output_model, info.module

# ── search — 이름·설명·태그 전문 검색 (대소문자 무시) ─────────────────────────
results = default_registry.search("llm")          # 이름·설명·태그 OR 검색
results = default_registry.search_by_tag("llm", "nlp")  # AND 조건

# ── compatible_with — 특정 Stud를 입력으로 받는 블록 발견 ──────────────────
matching = default_registry.compatible_with(MyStud)              # input_model == MyStud 인 블록
matching = default_registry.compatible_with(BaseStud, subclass=True)  # 서브클래스 허용 (M125)
all_infos = default_registry.all_info()  # list[BlockInfo] (이름순)

# ── update_stat 미등록 블록 경고 (M125) ──────────────────────────────────────
# 등록되지 않은 블록 이름으로 update_stat() 호출 시 UserWarning
default_registry.update_stat("UnknownBlock", success=True, elapsed_sec=0.1)
# UserWarning: "UnknownBlock 은 레지스트리에 등록되지 않았습니다"
```

### check_chain / check_connection — Stud 호환성 사전 검사 (M89)
```python
from pylego_blocks import check_chain, check_connection, CompatibilityError, CompatibilityResult

# ── 단일 연결 검사 ─────────────────────────────────────────────────────────────
ok = check_connection(BlockA, BlockB)  # BlockA.output_model is BlockB.input_model

# ── 체인 전체 검사 ─────────────────────────────────────────────────────────────
result: CompatibilityResult = check_chain([BlockA(), BlockB(), BlockC()])
if not result.compatible:
    for err in result.errors:
        print(f"위치 {err.position}: {err.left_block}.{err.expected} → {err.right_block}.{err.got}")

# Assembly 조립 전 사전 검사 → 불일치 원인 파악
assert check_chain([A, B, C]).compatible, "Stud 불일치"
pipeline = Assembly([A(), B(), C()])
```

### PipelineHealth.to_ai_summary() / to_dict() (M90)
```python
from pylego_blocks.core.events import CollectingEventBus

bus = CollectingEventBus()
with observe(bus):
    result = await pipeline.run(inp)

health = build_health_summary(bus.events, bus=bus)

summary = health.to_ai_summary()
# 전체 상태: 위험 (3개 블록 중 2개 실패)
# 실패 블록: WrapperBlock, RootBlock
#   - WrapperBlock: pipeline failed (caused_by: RootBlock)
# 가장 느린 블록: WrapperBlock (2.30s)
# 권장 조치: TimeoutBlock 또는 FallbackBlock 추가 검토

import json
data = health.to_dict()   # JSON 직렬화 가능
json.dumps(data)
```

### Scheduler — cron/interval 실행 (M91)
```python
from pylego_blocks import Scheduler, run_once

# 동기 단발 실행 (apscheduler 불필요)
result = run_once(pipeline, input=MyInput(value=1))

# 스케줄러 (pip install pylego-blocks[scheduler])
scheduler = Scheduler()
scheduler.add(pipeline, input=MyInput(), interval_seconds=300, job_id="check")
scheduler.add(pipeline, input=MyInput(), cron="0 9 * * *", job_id="daily")

async def main() -> None:
    await scheduler.start()
    await scheduler.stop()

# 데몬 프로세스 keep-alive (Ctrl+C / SIGTERM 까지 실행 유지)
import asyncio
from pylego_blocks import Scheduler, run_forever

scheduler = Scheduler()
scheduler.add(pipeline, input=MyInput(), interval_seconds=60, job_id="job")
asyncio.run(scheduler.run_forever())
# start() 단독 호출 시 이벤트 루프가 즉시 종료되는 문제를 해결한다.
# Ctrl+C 또는 SIGTERM 수신 시 stop() 자동 호출 후 종료.
```

### BlockRuntimeStat — 블록 런타임 통계 (M93/M98/M103/M107/M111/M128, 설계 원칙 34/35/38/41/44/57)
```python
from pylego_blocks.registry import BlockRegistry, BlockRuntimeStat, RegistryPolicy, default_registry
from pylego_blocks import observe
from pylego_blocks.core.events import CollectingEventBus

# ── RegistryPolicy — 신뢰도·추세 임계값 설정 (M103) ──────────────────────────
policy = RegistryPolicy(
    min_samples=10,                  # confidence=1.0 에 필요한 최소 샘플 (기본 5)
    trend_window=20,                 # 추세 분석 롤링 윈도 크기 (기본 20)
    trend_worsening_threshold=0.2,   # recent_fail - overall_fail >= N 이면 degrading (기본 0.2)
    trend_improvement_threshold=0.1, # overall_fail - recent_fail >= N 이면 improving (기본 0.1)
    # M107 — 오류 타입별 심각도 매핑 (설계 원칙 41)
    error_severity_map={
        "ValidationError": 0.2,   # 경미 — 입력 오류, 재시도로 해결 가능
        "TimeoutError":    0.5,   # 중간 — 네트워크 불안정
        "ConnectionError": 0.8,   # 심각 — 의존성 장애
        "RuntimeError":    1.0,   # 치명 — 내부 버그
    },
    default_error_severity=1.0,     # 미등록 오류 타입의 기본 심각도
)

reg = BlockRegistry()
reg.set_policy(policy)  # 기존 stat + 이후 신규 stat 모두 동일 정책 적용

# ── RegistryPolicy 프리셋 — 환경별 권장 설정 (M125, 설계 원칙 56) ─────────────
policy = RegistryPolicy.development()   # min_samples=3,  trend_window=10  — 빠른 피드백
policy = RegistryPolicy.production()    # min_samples=20, trend_window=30  — 안정적 신뢰도
policy = RegistryPolicy.strict()        # min_samples=50, trend_window=50  — 높은 신뢰도 기준

# ── 등록된 블록의 런타임 통계 조회 ────────────────────────────────────────────
info = default_registry.describe("MyBlock")
stat = info.runtime  # BlockRuntimeStat | None
if stat:
    print(stat.success_rate)        # float: 누적 성공률 (0.0~1.0)
    print(stat.avg_elapsed_sec)     # float: 평균 실행 시간
    print(stat.failure_count)       # int: 누적 실패 횟수
    print(stat.last_error)          # str | None: 마지막 오류 메시지
    # M98 추세 분석 (최근 trend_window 회 롤링 윈도)
    print(stat.recent_failure_rate) # float: 최근 실패율
    print(stat.trend)               # "improving" | "stable" | "degrading"
    print(stat.is_degrading)        # bool: 추세가 악화 중이면 True
    # M103 신뢰도 가중 UCB 점수
    print(stat.confidence)          # float: 0.0~1.0, total_runs / (min_samples * 2)
    print(stat.total_runs)          # int: 총 실행 횟수
    # M107 — 심각도 조정 신뢰도 (설계 원칙 41)
    print(stat.weighted_failure_sum)      # float: 누적 심각도 가중 실패 합계
    print(stat.weighted_failure_rate)     # float: weighted_failure_sum / total_runs
    print(stat.risk_adjusted_confidence) # float: confidence × (1 - weighted_failure_rate)
    print(stat.ucb_score)                # float: risk_adjusted_confidence × log1p(total_runs)

# CollectingEventBus 이벤트로 자동 갱신 (BlockFailedEvent.error_type 자동 연동)
bus = CollectingEventBus()
with observe(bus):
    result = await pipeline.run(inp)
default_registry.ingest_events(bus.events)

# 성공률·지연·스마트 기준 정렬 검색
results = default_registry.search("mysql", sort_by="success_rate")  # 높은 순
results = default_registry.search("mysql", sort_by="latency")       # 낮은 순
results = default_registry.search("mysql", sort_by="smart")         # risk_adjusted UCB순 (M107)

# 수동 갱신 — error_type / severity 파라미터 (M107)
default_registry.update_stat("MyBlock", success=True, elapsed_sec=0.5)
default_registry.update_stat("MyBlock", success=False, elapsed_sec=1.2, error="oops")
default_registry.update_stat(
    "MyBlock", success=False, elapsed_sec=0.3,
    error_type="ValidationError",   # policy.error_severity_map 으로 심각도 자동 추론
)
default_registry.update_stat(
    "MyBlock", success=False, elapsed_sec=0.3,
    severity=0.9,                   # 명시적 심각도 (policy 추론보다 우선)
)

# ── M128 — Redemption Mechanism (설계 원칙 57) ───────────────────────────────
policy = RegistryPolicy(
    redemption_window=5,    # 5회 연속 성공 시 redemption 트리거 (0이면 비활성화)
    redemption_rate=0.5,    # redemption 1회당 weighted_failure_sum을 50% 경감
)
reg = BlockRegistry()
reg.set_policy(policy)
# 성공 시: consecutive_successes += 1, 도달 시 weighted_failure_sum *= (1 - redemption_rate)
# 실패 시: consecutive_successes = 0 (카운터 초기화)
reg.update_stat("MyBlock", success=True, elapsed_sec=0.1)  # ×5 반복 시 redemption 트리거

stat = reg.describe("MyBlock").runtime
if stat:
    print(stat.consecutive_successes)  # int: 연속 성공 횟수 (실패 시 0 초기화)
    print(stat.redemption_count)       # int: 갱생 발생 횟수 (감사 이력)
    print(stat.risk_adjusted_confidence)  # redemption 후 상승
```

> **설계 원칙 35 — 통계는 추세를 이야기한다.**
> `success_rate` 는 전체 누적 평균이므로 최근 장애를 희석할 수 있다.
> `trend` 는 최근 `trend_window` 회 롤링 윈도로 현재 상태를 더 정확히 반영한다.
> `ucb_score` 는 성공률과 실행 횟수를 조합해 실적 없는 블록이 과소평가되거나
> 특정 블록만 반복 선택되는 에코 챔버를 방지한다.

> **설계 원칙 38 — 통계적 신뢰도가 의사결정의 전제다.**
> 샘플이 적은 블록은 성공률이 높아도 신뢰할 수 없다. `confidence` 는
> `min(1.0, total_runs / (min_samples * 2))` 로 계산되어 샘플 부족 블록을
> 자동으로 페널티 처리한다. `sort_by="smart"` 은 confidence 가 낮을수록
> UCB 점수를 낮춰 서비스 안정성이 검증되지 않은 블록의 과도한 선택을 막는다.

> **설계 원칙 41 — 오류의 무게가 다르다.**
> `ValidationError` 와 `RuntimeError` 가 동일한 실패 가중치를 가지면 신뢰도 점수가
> 왜곡된다. `RegistryPolicy.error_severity_map` 으로 오류 타입별 심각도(0.0~1.0)를
> 정의하면 `weighted_failure_rate` 와 `risk_adjusted_confidence` 가 질적 차이를
> 반영한다. `sort_by="smart"` 은 이 위험 조정 신뢰도 기반 UCB 순으로 정렬한다.

### AssemblyValidator — 시맨틱 조립 시점 검증 (M94)
```python
from pylego_blocks import Assembly, AssemblyValidator, SemanticCompatibilityError, check_chain
from pylego_blocks import Stud

# 검증 함수 바인딩
def require_non_empty_query(inp: QueryInput) -> None:
    if not inp.query.strip():
        raise ValueError("query 가 비어 있습니다")

validator = AssemblyValidator({
    0: require_non_empty_query,   # 0번 블록 입력 검증
    1: lambda x: None,            # 1번 블록 입력 검증
})

# Assembly 에 바인딩 — run() 시 각 블록 실행 직전 호출
pipeline = Assembly([BlockA(), BlockB()], validator=validator)
# 검증 실패 시: SemanticCompatibilityError(position=0, reason="query 가 비어 있습니다")

# check_chain 에서 validator 위치 범위 검사
result = check_chain([BlockA(), BlockB()], validator=validator)
# validator 위치가 체인 범위를 벗어나면 SemanticCompatibilityError 발생

try:
    await pipeline.run(QueryInput(query=""))
except SemanticCompatibilityError as e:
    print(e.position, e.reason)
```

### SchedulerPolicy — 좀비 파이프라인 격리 (M95, 설계 원칙 32)
```python
from pylego_blocks import Scheduler, SchedulerPolicy, JobStatus

def on_kill(job_id: str, reason: str) -> None:
    print(f"[ALERT] 잡 '{job_id}' 비활성화: {reason}")

policy = SchedulerPolicy(
    max_consecutive_failures=3,   # N회 연속 실패 시 잡 비활성화
    max_runs_per_hour=60,         # 시간당 최대 실행 횟수
    on_kill=on_kill,              # 비활성화 시 콜백
    # M99 적응형 복구
    suspended_retry_seconds=300,  # suspended 후 재시도 간격 (초)
    max_recovery_attempts=3,      # 최대 복구 시도 횟수 (초과 시 killed 영구화)
)

scheduler = Scheduler()
scheduler.add(
    pipeline,
    input=MyInput(),
    interval_seconds=60,
    job_id="check",
    policy=policy,
)

# 잡 상태 조회
status: JobStatus = scheduler.job_status("check")
# status.state: "active" | "suspended" | "killed"
# status.consecutive_failures: int
# status.total_runs: int
# status.recovery_attempts: int  — M99 복구 시도 횟수
```

### GlobalSchedulerPolicy — 글로벌 스케줄러 감시 + Active Freeze + Post-thaw + Adaptive Ramp-up (M99/M104/M112/M120, 설계 원칙 36/39/45/51)
```python
from pylego_blocks import Scheduler, GlobalSchedulerPolicy, SchedulerPolicy

def on_alert(msg: str) -> None:
    print(f"[GLOBAL ALERT] {msg}")

def on_freeze(reason: str) -> None:
    print(f"[FREEZE] {reason}")

global_policy = GlobalSchedulerPolicy(
    max_killed_ratio=0.5,               # killed 잡 비율이 50% 초과 시 경고
    max_global_consecutive_failures=10, # 전체 잡의 연속 실패 누계가 N 초과 시 경고
    on_global_alert=on_alert,           # 경보 콜백
    # M104 Active Freeze
    freeze_on_alert=True,               # 경보 발생 시 스케줄러 자동 동결
    on_freeze=on_freeze,                # 동결 시 콜백
)

scheduler = Scheduler()
scheduler.set_global_policy(global_policy)

# 개별 잡 정책과 독립 적용 — 글로벌 감시가 먼저 경고, 잡 정책이 격리
scheduler.add(pipeline_a, input=MyInput(), interval_seconds=60, job_id="a")
scheduler.add(pipeline_b, input=MyInput(), interval_seconds=60, job_id="b")

# ── M104 수동 동결 / 해제 ──────────────────────────────────────────────────
scheduler.freeze("긴급 배포 중단")   # 모든 잡 신규 실행 차단 (진행 중인 실행은 완료 허용)
scheduler.unfreeze()                 # 동결 해제 후 정상 실행 재개

# ── 글로벌 상태 조회 ───────────────────────────────────────────────────────
summary = scheduler.global_status()
# summary["active"], summary["killed"], summary["suspended"], summary["total"]
# summary["frozen"]: bool, summary["freeze_reason"]: str | None

# ── M104 Circuit Probe — 복구 실행 전 라이브니스 체크 ────────────────────
async def probe_db() -> bool:
    try:
        await db.ping()
        return True
    except Exception:
        return False

policy = SchedulerPolicy(
    max_consecutive_failures=3,
    suspended_retry_seconds=300.0,   # 5분 후 복구 재시도
    max_recovery_attempts=3,
    probe_fn=probe_db,               # False 반환 시 이번 주기 건너뜀 + 타이머 리셋
    # M108 — probe 결과를 BlockRegistry 에 연동 (설계 원칙 42)
    probe_updates_registry=True,     # True: probe 성공/실패를 default_registry 에 기록
)
scheduler.add(pipeline, input=MyInput(), interval_seconds=60, job_id="j", policy=policy)

# ── M108 Autonomous Thaw — 자율 동결 해제 (설계 원칙 42) ──────────────────
from pylego_blocks.scheduler import ThawPolicy

def on_thaw(reason: str) -> None:
    print(f"[THAW] {reason}")

# canary: 300초마다 단일 잡 시험 실행, 3회 연속 성공 시 전체 해제
thaw_policy = ThawPolicy(
    strategy="canary",          # "manual"(기본·하위호환) | "canary" | "gradual"
    canary_interval_sec=300.0,  # 카나리 시도 간격 (초)
    success_threshold=3,        # 연속 성공 횟수 → 전체 해제
)

global_policy_with_thaw = GlobalSchedulerPolicy(
    freeze_on_alert=True,
    on_freeze=on_freeze,
    thaw_policy=thaw_policy,    # None(기본값)이면 unfreeze() 수동 호출 필요
    on_thaw=on_thaw,            # 자율 해제 시 콜백
)
scheduler.set_global_policy(global_policy_with_thaw)
# 이제 freeze 후 300초마다 카나리 잡 실행 → 3회 연속 성공 시 자동 해제
```

> **설계 원칙 36 — 글로벌 정책이 개별 정책을 감시한다.**
> 개별 `SchedulerPolicy`가 단일 잡을 격리한다면,
> `GlobalSchedulerPolicy`는 스케줄러 전체의 건강 상태를 감시한다.
> killed 잡 비율이 임계값을 넘으면 시스템 수준 장애 신호로 해석하고
> `on_global_alert`으로 즉시 알린다.

> **설계 원칙 39 — 격리는 관찰에서 통제로 진화한다.**
> 경보만 보내는 시스템은 절반의 안전장치다. `freeze_on_alert=True` 는
> 임계 초과 경보를 즉각적인 실행 차단으로 연결한다. `probe_fn` 은
> 복구 재시도 전에 외부 의존성(DB, 큐, API)의 생존 여부를 먼저 확인해
> 무의미한 복구 시도가 누적되는 것을 막는다.

> **설계 원칙 42 — 시스템은 스스로 회복의 가능성을 타진한다.**
> `ThawPolicy(strategy="manual")` 은 기본값으로, 기존 `unfreeze()` 워크플로를
> 변경하지 않는다. `"canary"` 또는 `"gradual"` 로 옵트인하면 동결 후 일정 간격마다
> 단일 잡을 시험 실행해 연속 성공 시 자동으로 전체 해제한다.
> `probe_updates_registry=True` 는 probe 결과를 `BlockRegistry` 통계에 반영해
> 외부 의존성 복구 여부가 `risk_adjusted_confidence` 에 즉시 반영되도록 한다.

```python
# ── M120 — max_global_recovery_ratio + adaptive_ramp_up ──────────────────
from pylego_blocks.scheduler import GlobalSchedulerPolicy, ThawPolicy, Scheduler

tp = ThawPolicy(strategy="canary", canary_interval_sec=60.0, success_threshold=3)
gp = GlobalSchedulerPolicy(
    freeze_on_alert=True,
    thaw_policy=tp,
    post_thaw_observation_sec=300.0,
    # 전체 recovering 잡의 동시 실행 허용 비율 상한 (잡이 2개면 각 25%)
    max_global_recovery_ratio=0.5,
    # 실행 결과에 따라 ratio 를 동적으로 조정
    adaptive_ramp_up=True,
    adaptive_min_ratio=0.1,    # 시작값·하한값 (0 방지)
    adaptive_step_up=0.1,      # 성공 시 ratio 상향폭
    adaptive_step_down=0.2,    # 실패 시 ratio 하향폭 (빠른 제동)
)
sched = Scheduler()
sched.set_global_policy(gp)

# global_status() 에서 실효 비율 확인
status = sched.global_status()
# status["max_global_recovery_ratio"] — 설정된 전역 상한
# status["effective_recovery_ratio"]  — 현재 실효 비율 (recovering 중일 때만 의미)
```

> **설계 원칙 51 — 복구의 속도는 신뢰의 증거가 결정한다.**
> `recovery_traffic_ratio` 가 고정 비율이라면 `adaptive_ramp_up=True` 는
> 실시간 성공률에 따라 ratio 를 동적으로 조정한다. 성공이 누적되면 `adaptive_step_up`
> 만큼 비율을 올리고, 실패 시 `adaptive_step_down` 만큼 빠르게 낮춘다.
> `max_global_recovery_ratio` 는 개별 ratio 가 아무리 높아도 전체 recovering 잡의
> 합산 트래픽이 임계값을 넘지 않도록 상한을 보장한다.

### to_ai_summary(include_payload=True) — 근거 중심 진단 (M96, 설계 원칙 33)
```python
from pylego_blocks import observe, build_health_summary
from pylego_blocks.core.events import CollectingEventBus, BlockFailedEvent

bus = CollectingEventBus()
with observe(bus):
    try:
        result = await pipeline.run(inp)
    except Exception:
        pass

health = build_health_summary(bus.events, bus=bus)

# 기본 (보안 민감 환경 — 입력 샘플 미포함)
summary = health.to_ai_summary()

# 입력 샘플 포함 (근거 중심 진단)
summary = health.to_ai_summary(include_payload=True)
# 실패 블록: MyBlock
#   - MyBlock: [ValidationError] field required
#     입력 샘플: {'query': ''}
#     권장 조치: 입력 Stud 필드 검증 강화 또는 @field_validator 추가 검토

# M100: max_payload_chars — 입력 샘플 최대 길이 제어 (기본 200)
summary = health.to_ai_summary(include_payload=True, max_payload_chars=500)

# M100: diff — 이전 실행 대비 변경 사항 포함
prev_health = build_health_summary(prev_bus.events, bus=prev_bus)
diff = health.diff(prev_health)
summary = health.to_ai_summary(include_payload=True, diff=diff)
# → 새 실패: [...], 복구: [...], 느려진 블록: {...}, 빨라진 블록: {...}

# BlockFailedEvent 에 자동 채워지는 필드 (Assembly가 처리)
# ev.error_type    — type(error).__name__
# ev.input_sample  — str(input)[:max_payload_chars]

# 오류 타입 → 권장 조치 매핑:
# TimeoutError       → TimeoutBlock 설정 또는 timeout_sec 조정 검토
# ValidationError    → 입력 Stud @field_validator 강화 검토
# ConnectionError    → RetryBlock 또는 FallbackBlock 추가 검토
# OSError            → RetryBlock 또는 FallbackBlock 추가 검토
# CircuitOpenError   → CircuitBreakerBlock 파라미터 조정 검토
# 기타               → FallbackBlock 추가 또는 오류 로그 확인
```

### HealthDiff — 파이프라인 상태 시맨틱 비교 + VersionContext + CausalFactor (M100/M105/M109/M113/M129, 설계 원칙 40/43/46/58)
```python
from pylego_blocks import build_health_summary, HealthDiff, VersionContext, EnvironmentContext, CausalFactor
from pylego_blocks.core.events import CollectingEventBus

# ── EnvironmentContext — 코드 외 환경 변화 맥락 (M109) ────────────────────────
ec = EnvironmentContext(
    infra_changes=["Redis 7.2 → 8.0 업그레이드", "K8s 노드 재시작"],
    metric_snapshot={"p99_latency_ms": 420.0, "error_rate": 0.03},
    external_changes=["OpenAI API v2 전환"],
    baseline_metrics={"p99_latency_ms": 120.0, "error_rate": 0.005},
)
# metric_anomalies(): baseline 대비 1.5× 이상 변화된 지표 반환
anomalies = ec.metric_anomalies()  # {"p99_latency_ms": (120.0, 420.0)}

# ── VersionContext — 배포 버전 메타데이터 (M105) ──────────────────────────────
vc = VersionContext(
    version="2.3.0",
    deployed_at="2026-04-27T12:00:00Z",
    changed_blocks=["MySqlBlock", "CacheBlock"],  # 이번 배포에서 변경된 블록
    notes="Redis 연결 풀 교체",
    env_context=ec,   # M109 — 환경 맥락 연결
)

# 두 실행의 건강 요약 비교
prev_bus = CollectingEventBus()
with observe(prev_bus):
    await pipeline.run(inp)
prev_health = build_health_summary(prev_bus.events, bus=prev_bus)

curr_bus = CollectingEventBus()
with observe(curr_bus):
    await pipeline.run(inp)
# version_context 전달 시 to_ai_summary() 에서 인과 힌트 자동 포함
curr_health = build_health_summary(curr_bus.events, bus=curr_bus, version_context=vc)

diff: HealthDiff = curr_health.diff(prev_health)
print(diff.new_failures)       # list[str]: 이전에 없던 새 실패 블록
print(diff.recovered)          # list[str]: 이전 실패에서 복구된 블록
print(diff.slower_blocks)      # dict[str, tuple[float, float]]: 느려진 블록 {name: (prev, curr)}
print(diff.faster_blocks)      # dict[str, tuple[float, float]]: 빨라진 블록
print(diff.error_type_changes) # dict[str, tuple[str|None, str|None]]: 오류 타입 변경
# M105 우선순위 필드
print(diff.severity)           # "ok" | "minor" | "major" | "critical"
print(diff.critical_changes)   # list[str]: 우선순위 순 변화 메시지 (최대 5개)
# severity 판정 기준:
#   critical — new_failures 존재
#   major    — error_type_changes 존재 또는 50% 이상 급격한 지연
#   minor    — slower_blocks 존재 (50% 미만)
#   ok       — 복구만 있거나 변화 없음

# M109 다요인 원인 후보 (causal_factors)
print(diff.causal_factors)     # list[CausalFactor]: confidence_score 내림차순
for factor in diff.causal_factors:
    # factor.source: "code" | "env" | "metric"
    # factor.name: 블록명 / 변경 설명 / 지표명
    # factor.confidence_score: 0.0~1.0 (code=0.7, metric=0.6, env=0.5)
    # factor.description: 상세 설명
    print(f"[{factor.source}/{factor.confidence_score:.2f}] {factor.name}: {factor.description}")

# to_ai_summary 에 diff 전달 시 심각도 + 우선순위 변화 + 다요인 인과 후보 자동 포함
summary = curr_health.to_ai_summary(diff=diff)
# → "[이전 대비 변화] 심각도: 위험"
# → "  [CRITICAL] 신규 실패: MySqlBlock"
# → "  [MAJOR] 오류 변화: CacheBlock ..."
# → "[인과 후보 목록] (높은 것이 유력)"
# → "  [code/0.70] MySqlBlock — 버전 2.3.0에서 변경됨"
# → "  [metric/0.60] p99_latency_ms — 기준 120.00 → 현재 420.00"
# → "  [env/0.50] Redis 7.2 → 8.0 업그레이드 — 환경 변경 후보"
# → "  ※ 목록에 없는 블록 간 상호작용(Side Effect)도 확인하세요."
```

> **설계 원칙 40 — 원인 없는 진단은 절반의 지혜다.**
> 어떤 블록이 실패했는지 아는 것만으로는 충분하지 않다.
> `VersionContext.changed_blocks` 와 `error_blocks` 의 교집합을 찾아
> "이번 배포에서 변경된 블록이 실패했다"는 인과 힌트를 진단에 포함한다.
> `diff.severity` 는 변화의 위급도를 단일 값으로 요약해 알림 우선순위 결정에 사용한다.

> **설계 원칙 43 — 원인은 하나가 아니다.**
> `changed_blocks` 힌트는 "최근 전과자"를 지목하는 강력한 신호이지만,
> AI의 확증 편향을 심화시킬 수 있다. `EnvironmentContext` 로 인프라/지표/외부 의존성
> 변화를 함께 전달하면 `diff.causal_factors` 에 코드·환경·지표 요인이 통합된다.
> `to_ai_summary()` 는 "목록에 없는 Side Effect도 확인하세요" disclaimer를
> 자동으로 포함해 단일 원인에 고착되지 않도록 안내한다.

### Causal Feedback API — apply_feedback + adjusted_confidence (M129, 설계 원칙 58)
```python
from pylego_blocks.ops.causal import CausalFactor
from pylego_blocks.ops.diff import HealthDiff

# diff.causal_factors 에 이미 요인이 채워진 상태로 가정
# factor.confidence_score 는 통계 기반 초기값 (0.0~1.0)

# ── apply_feedback — 운영자/AI 피드백으로 인과 스코어 조정 ──────────────────
diff.apply_feedback(
    factor_name="MySqlBlock",   # causal_factors 에 있는 name
    delta=-0.3,                  # 하향 조정 (해당 요인이 실제 원인이 아니라 판단)
    source="human",              # "human" | "ai"
    reason="배포 전부터 발생한 오류 — 무관",
)
diff.apply_feedback("RedisBlock", delta=0.2, source="ai", reason="프로파일러 결과 일치")

# delta=0.0은 feedback_log에 이력을 남기지 않는다
diff.apply_feedback("LogBlock", delta=0.0)  # no-op

# ── CausalFactor.adjusted_confidence — 피드백 반영 신뢰도 ──────────────────
for factor in diff.causal_factors:
    print(factor.name, factor.confidence_score, factor.adjusted_confidence)
    # adjusted_confidence = confidence_score + feedback_delta (0~1 클램핑)
    # feedback_delta != 0 이면 to_ai_summary()에서 "[피드백 반영]" 레이블 표시

# ── feedback_log — 감사 이력 ─────────────────────────────────────────────
for entry in diff.feedback_log:
    print(entry["timestamp"], entry["factor_name"], entry["delta"], entry["source"])

# ── to_ai_summary() 피드백 반영 출력 예시 ────────────────────────────────────
summary = health.to_ai_summary(diff=diff)
# → "[인과 후보 목록] (높은 것이 유력)"
# → "  [code/0.70] RedisBlock — 배포 변경 [피드백 반영: +0.20]"
# → "  [code/0.70] MySqlBlock — [피드백 반영: -0.30]"   ← adjusted_confidence 낮아짐
# (adjusted_confidence 내림차순 재정렬 후 출력)

# ── apply_feedback 없는 factor_name → KeyError ───────────────────────────
try:
    diff.apply_feedback("NoSuchBlock", delta=0.1)
except KeyError as e:
    print(e)  # 'NoSuchBlock' 은 causal_factors 에 없습니다.
```

> **설계 원칙 58 — 진단은 대화로 완성된다.**
> `compute_correlations()` 는 이력 기반 통계이지만, 운영 담당자나 AI가
> "이 요인은 실제로 무관했다"는 도메인 지식을 주입할 채널이 없었다.
> `apply_feedback()` 은 `CausalFactor.feedback_delta` 를 누적 조정하고
> `adjusted_confidence` 로 피드백이 반영된 신뢰도를 표현한다.
> `feedback_log` 는 who·what·why 를 기록해 피드백 이력의 감사 가능성을 보장한다.

### RegistryPolicy 우선순위 기반 위험 가중치 (M111, 설계 원칙 44)
```python
from pylego_blocks.registry import BlockRegistry, RegistryPolicy, default_registry

# ── block_priority_map — 비즈니스 임팩트별 블록 우선순위 ─────────────────────
policy = RegistryPolicy(
    block_priority_map={
        "PaymentBlock":  5.0,   # 결제 — 실패 시 매출 손실
        "AuthBlock":     4.0,   # 인증 — 실패 시 서비스 전체 차단
        "ReportBlock":   1.0,   # 보고서 — 실패 시 임팩트 낮음
    },
    cumulative_risk_threshold=10.0,   # 누적 위험 합계 초과 시 경보
)
reg = BlockRegistry()
reg.set_policy(policy)

# 위험 경보 콜백 등록
alerts: list[str] = []
reg.set_risk_alert(lambda name, risk: alerts.append(f"{name}: {risk:.1f}"))

# 실패 기록 — 우선순위가 높을수록 위험 누적이 빠름
reg.update_stat("PaymentBlock", success=False, elapsed_sec=0.5,
                error_type="ConnectionError")   # severity=0.8, priority=5.0 → 4.0 누적
reg.update_stat("ReportBlock", success=False, elapsed_sec=0.1,
                error_type="ConnectionError")   # severity=0.8, priority=1.0 → 0.8 누적

info = default_registry.describe("PaymentBlock")
if info.runtime:
    print(info.runtime.priority_adjusted_risk)    # 누적 우선순위 위험 합계
    print(info.runtime.risk_adjusted_confidence)  # priority_adjusted_risk 반영 신뢰도

# 명시적 우선순위 오버라이드 (policy보다 우선)
reg.update_stat("PaymentBlock", success=False, elapsed_sec=0.3, priority=10.0)
```

> **설계 원칙 44 — 우선순위가 심각도를 결정한다.**
> 동일한 `ConnectionError` 라도 결제 블록과 보고서 블록의 비즈니스 임팩트는 다르다.
> `block_priority_map` 으로 블록별 가중치를 정의하면 `priority_adjusted_risk` 가
> 비즈니스 중요도를 반영한 누적 위험을 표현한다. `risk_adjusted_confidence` 는
> 이 우선순위 조정 위험률을 신뢰도 계산에 반영해 고우선순위 블록의 반복 실패를
> 더 빠르게 신뢰도 하락으로 연결한다.

### RegistryPolicy Criticality-aware Risk Decay (M119, 설계 원칙 50)
```python
from pylego_blocks.registry import BlockRegistry, RegistryPolicy

# ── decay_overrides — 블록별 개별 반감기 (초) ──────────────────────────────
policy = RegistryPolicy(
    risk_decay_half_life_sec=3600.0,   # 전역 기본 반감기 1시간
    decay_overrides={
        "PaymentBlock": 86400.0,       # 결제 — 24시간 동안 위험 유지
        "LogBlock":     600.0,         # 로그 — 10분 후 빠르게 망각
    },
    oscillation_penalty=2.0,          # oscillation 1회마다 반감기 2배 억제
)
reg = BlockRegistry()
reg.set_policy(policy)
reg.register(PaymentBlock)
reg.register(LogBlock)

# ── effective_half_life — oscillation_count 반영 실효 반감기 ─────────────────
# oscillation_count=0 → 기본 half_life
# oscillation_count=1 → half_life × penalty^1 = 2배 → 더 천천히 망각
assert reg._effective_half_life("PaymentBlock") == 86400.0   # oscillation 0
# oscillation 1회 발생 후: 86400.0 × 2.0^1 = 172800.0

# ── oscillation 감지 ──────────────────────────────────────────────────────────
# 조건: 직전 failure 이후 decayed_risk < original × 0.5 (충분히 망각)
#       + 동일 error_type 재발 → oscillation_count += 1
reg.update_stat("PaymentBlock", success=False, elapsed_sec=0.5,
                error_type="TimeoutError")
# 반감기 이상 경과 후 동일 오류 재발 → oscillation_count = 1
reg.update_stat("PaymentBlock", success=False, elapsed_sec=0.5,
                error_type="TimeoutError")
info = reg.describe("PaymentBlock")
if info.runtime:
    print(info.runtime.oscillation_count)         # 반감기 경과 시 1
    print(info.runtime.risk_adjusted_confidence)  # oscillation_penalty 반영
```

> **설계 원칙 50 — 망각은 선택적이어야 한다.**
> `risk_decay_half_life_sec` 는 모든 블록을 동일한 속도로 망각한다.
> `decay_overrides` 로 블록별 반감기를 다르게 설정하면 결제·인증 같은 핵심 블록은
> 위험을 오래 기억하고, 로그·보고서 블록은 빠르게 회복할 수 있다.
> `oscillation_penalty` 는 위험이 감쇠했다가 동일 오류로 재발할 때 반감기를 늘려
> "금방 고쳐지는 척하는" 반복 장애를 더 엄격하게 추적한다.

### Post-thaw Observation + Smart Canary (M112, 설계 원칙 45)
```python
from pylego_blocks.scheduler import GlobalSchedulerPolicy, SchedulerPolicy, ThawPolicy, Scheduler

# ── post_thaw_observation_sec — 동결 해제 후 회복 관찰 구간 ─────────────────
thaw_policy = ThawPolicy(strategy="canary", canary_interval_sec=60.0, success_threshold=3)
gp = GlobalSchedulerPolicy(
    freeze_on_alert=True,
    thaw_policy=thaw_policy,
    post_thaw_observation_sec=300.0,       # 카나리 성공 후 5분 관찰
    post_thaw_max_failure_rate=0.2,        # 관찰 기간 중 실패율 20% 초과 시 재동결
    on_recovering=lambda msg: print(f"[RECOVERING] {msg}"),
    on_thaw=lambda msg: print(f"[THAW] {msg}"),
)

sched = Scheduler()
sched.set_global_policy(gp)

# 상태 흐름: frozen → recovering (canary 성공) → active (관찰 기간 통과)
#           recovering → frozen (관찰 기간 중 실패율 초과 → 재동결)
status = sched.global_status()
# status["frozen"]    — bool
# status["recovering"] — bool
# status["freeze_reason"] — str | None

# ── Smart Canary — canary_priority 가 낮은 잡이 먼저 선택됨 ─────────────────
sched.add(pipeline_heavy, input=inp, interval_seconds=60.0, job_id="heavy",
          policy=SchedulerPolicy(canary_priority=10))  # 우선순위 낮음 — 카나리로 선택 안됨
sched.add(pipeline_light, input=inp, interval_seconds=60.0, job_id="light",
          policy=SchedulerPolicy(canary_priority=1))   # 우선순위 높음 — 카나리 1순위
# 동점이면 BlockRegistry 평균 지연이 낮은 잡이 우선
```

> **설계 원칙 45 — 동결 해제는 관찰에서 신뢰로 이어진다.**
> 카나리 성공만으로 즉시 전체 재개하면 회복 착각(false recovery) 위험이 있다.
> `post_thaw_observation_sec > 0` 이면 `recovering` 중간 상태를 거쳐
> 실제 운영 트래픽에서 실패율을 측정한 뒤 전체 재개를 결정한다.
> `post_thaw_max_failure_rate` 초과 시 즉시 재동결해 반쪽짜리 회복을 차단한다.

### CausalFactor.aggregate_causes() + Probabilistic Causal Graph (M113/M121, 설계 원칙 46/52)
```python
from pylego_blocks import build_health_summary, VersionContext, EnvironmentContext
from pylego_blocks.core.graph import HealthDiff, CausalFactor
from pylego_blocks.core.events import CollectingEventBus

# ── aggregate_causes() — 이력 기반 최유력 원인 결정 ────────────────────────
# source 가중치: code×1.2, metric×1.0, env×0.8
# 반복 등장 보너스: adjusted = confidence × min(2.0, 1 + 0.1 × recurrence_count)

prev_diff = HealthDiff()
prev_diff.causal_factors = [
    CausalFactor(source="env", name="Redis", confidence_score=0.5),
]

curr_bus = CollectingEventBus()
with observe(curr_bus):
    await pipeline.run(inp)
vc = VersionContext(version="3.0.0", changed_blocks=["BlockA"])
curr_health = build_health_summary(curr_bus.events, bus=curr_bus, version_context=vc)
diff = curr_health.diff(prev_health)

# 이전 diff 이력을 전달 → 반복 등장 요인의 점수 자동 상향
primary = diff.aggregate_causes(history=[prev_diff])
# primary.name             — 최유력 원인 블록/지표/환경 이름
# primary.source           — "code" | "env" | "metric"
# primary.confidence_score — 원래 신뢰도 (조정 전)
# primary.recurrence_count — 이력에서 등장한 횟수

# diff.primary_cause 에도 동일 객체 저장됨
assert diff.primary_cause is primary

# to_ai_summary() 에 [최유력 원인] 섹션 자동 포함
summary = curr_health.to_ai_summary(diff=diff)
# → "[최유력 원인] [code/0.70] BlockA — 버전 3.0.0에서 변경됨"
# → "  반복 등장 1회"

# aggregate_causes() 미호출 시 [최유력 원인] 섹션 없음 — [인과 후보 목록]만 출력
```

> **설계 원칙 46 — 반복은 증거다.**
> 단일 실행에서 나온 `causal_factors` 는 후보일 뿐이다.
> 동일 요인이 여러 이력에 걸쳐 반복 등장할수록 우연이 아닌 구조적 원인일 가능성이 높다.
> `aggregate_causes(history)` 는 반복 횟수에 비례해 최대 2× 보너스를 부여하고
> `primary_cause` 로 확정함으로써 AI 진단이 가장 유력한 단서를 먼저 검토하도록 안내한다.

```python
# ── M121 — residual_decay_factor + compute_correlation + to_causal_mermaid ──
from pylego_blocks.core.graph import HealthDiff, CausalFactor

# aggregate_causes 확장 파라미터
# recurrence_window: 최근 N개만 window로, 나머지는 residual 처리
# residual_decay_factor: window 밖 이력 감쇠 계수
# top_k: 상위 K개 요인만 평가 (기본 3)
# compute_correlation: True이면 compute_correlations(history) 를 먼저 호출

old_history = [prev_diff_1, prev_diff_2, prev_diff_3]   # 오래된 이력
recent_history = [prev_diff_4]                           # 최근 이력
history = old_history + recent_history

primary = diff.aggregate_causes(
    history=history,
    recurrence_window=1,          # recent_history 만 window
    residual_decay_factor=0.1,    # old_history 등장 횟수 × 0.1 가산
    top_k=5,
    compute_correlation=True,     # factor.correlation 자동 계산
)
# primary.residual_weight — window 밖 이력의 잔류 가중치
# primary.correlation     — co-occurrence 비율 (compute_correlation=True 시 채워짐)

# ── compute_correlations — 독립 호출 ─────────────────────────────────────────
diff.compute_correlations(history)
for factor in diff.causal_factors:
    # factor.correlation: 이 요인이 등장한 diff 중 다른 요인도 함께 등장한 비율
    # 0.0 = 독립 원인, 1.0 = 항상 복합 장애의 연쇄 고리
    print(f"{factor.name}: corr={factor.correlation:.2f}")

# ── to_causal_mermaid — correlation 기반 엣지 시각화 ──────────────────────────
mermaid = diff.to_causal_mermaid()
# flowchart LR
#   N0["BlockA"]
#   N1["Redis (잔류)"]         ← residual_weight > 0
#   N0 -. corr=0.10 .->N1    ← correlation < 0.3 → 점선
#
# correlation >= 0.7이면 굵은 엣지: N0 == corr=0.85 ==>N1
# 0.3 <= correlation < 0.7이면 일반 엣지: N0 -->|corr=0.50| N1
print(mermaid)
```

> **설계 원칙 52 — 연결의 강도가 인과의 진실성을 결정한다.**
> `causal_factors` 는 후보를 나열하지만 요인 간 관계는 드러내지 않는다.
> `compute_correlations(history)` 는 과거 diff 에서 요인들이 얼마나 자주 함께 등장했는지를
> 측정해 `factor.correlation` 에 반영한다. `to_causal_mermaid()` 는 상관계수를 엣지 굵기로
> 시각화해 독립 원인(점선)과 연쇄 고리(굵은 선)를 한눈에 구분할 수 있게 한다.

### Assembly auto_validate — pydantic 검증 우회 방지 (M101, 설계 원칙 37)
```python
from pydantic import model_validator
from pylego_blocks import Assembly, Block, Stud
from pylego_blocks.core.compat import AssemblyValidator, SemanticCompatibilityError

class QueryInput(Stud):
    query: str
    max_rows: int = 100

    @model_validator(mode="after")
    def query_not_empty(self) -> "QueryInput":
        if not self.query.strip():
            raise ValueError("query 가 비어 있습니다")
        return self

# auto_validate=True — run() 직전 각 블록 입력에 model_validate 재실행
pipeline = Assembly([MyBlock()], auto_validate=True)

# model_construct로 검증을 우회한 입력도 SemanticCompatibilityError로 잡힌다
bad = QueryInput.model_construct(query="", max_rows=100)
try:
    await pipeline.run(bad)
except SemanticCompatibilityError as e:
    print(e.position, e.reason)  # 0, "query 가 비어 있습니다"

# 명시적 validator와 병합 — 동일 위치에서 명시적 validator가 우선
from pylego_blocks.core.compat import AssemblyValidator
explicit_v = AssemblyValidator({0: lambda inp: None})  # noop — auto 검증 덮어씀
pipeline = Assembly([MyBlock()], validator=explicit_v, auto_validate=True)

# AssemblyValidator.merge — 두 검증기 합성 (self 우선)
v1 = AssemblyValidator({0: check_fn_a, 1: check_fn_b})
v2 = AssemblyValidator({0: check_fn_x, 2: check_fn_c})
merged = v1.merge(v2)
# 위치 0: check_fn_a (v1 우선), 위치 1: check_fn_b, 위치 2: check_fn_c
```

> **설계 원칙 37 — 입력 계약은 실행 직전에도 검증된다.**
> pydantic의 `model_construct()`는 검증을 우회한다.
> `auto_validate=True`는 `run()` 직전에 `model_validate(inp.model_dump())`를 재실행해
> 우회된 제약 조건도 포착한다. 성능에 민감한 파이프라인에서는 필요한 경우에만 활성화한다.

---

## 6. 제약 조건 & 자주 하는 실수

| 제약 | 내용 |
|------|------|
| `input_model` / `output_model` 누락 | `TypeError` — 클래스 정의 시점에 발생 |
| `run()` 동기 def | 허용되지 않음 — 반드시 `async def run()` |
| Stud 필드 변경 | `ValidationError` — `frozen=True` 이므로 `.model_copy(update={})` 사용 |
| 동일 블록 인스턴스 재사용 | `CyclicAssemblyError` — 인스턴스를 분리 생성 |
| Redis 없이 RedisQueue 인스턴스화 | `ImportError` — `pip install pylego-blocks[redis]` |
| FastAPI 없이 build_app() 호출 | `ImportError` — `pip install pylego-blocks[serve]` |
| OtelEventBus 사용 | `ImportError` — `pip install pylego-blocks[otel]` |
| `from __future__ import annotations` + FastAPI | serve.py 에서 사용 금지 — annotation 지연 평가가 FastAPI 라우트 파라미터 해석 방해 |
| **래퍼 중첩 경고** | 동일 종류의 래퍼를 중첩하지 않는다 (`RetryBlock(RetryBlock(...))` 금지). 세 래퍼 이상 중첩 시 별도 블록으로 분리를 권고. 각 래퍼의 이벤트는 `CollectingEventBus`로 독립 관찰 가능. `wrap()` 체인에서도 동일 메서드 두 번 호출 금지. |
| `wrap()` 체인 순서 | 래퍼는 **선언 순서대로** 바깥에서 안쪽으로 감싼다. `.retry().timeout(5)` → `TimeoutBlock(RetryBlock(...))`. 순서에 따라 동작이 달라지므로 의도 확인 필수. |
| `CallableBlock` fn 타입 | `fn`은 반드시 `async def` — 동기 함수는 `asyncio.to_thread`로 래핑 후 전달. |
| `CallableBlock` fn 시그니처 불일치 | 생성 시점에 `TypeError` 발생 — 첫 파라미터·반환 타입이 `input_model`/`output_model`과 달라야 하지 않음. 어노테이션 없으면 검증 생략. |
| `PooledMySqlBlock.close()` 미호출 | 프로세스 종료 전 `await block.close()` 호출 권장 — 풀 미반환 시 DB 연결 누수 가능. |
| `MaxRepeatedErrorError` | `SemanticRetryBlock`의 `abort_on_repeated_error` 초과 시 발생. 동일 오류 N회 연속 감지 → 환각 루프 조기 종료. |
| `AbortVerificationError` | `on_abort_fn` 결과가 `verify_fn`을 통과하지 못할 때 발생 (`verify_after_abort=True` 기본값). |
| `verify_after_abort` 기본값 | `True` — on_abort_fn 결과도 verify_fn 검증 필수. 폴백이 환각 결과를 조용히 통과시키지 않도록 방지. |
| `LlmRouter` 백엔드 미설정 | `ValueError` — `PYLEGO_LLM_BACKEND` 환경변수 또는 `LlmRouter(backend=...)` 명시 필요 |
| `LlmRouter` 미지원 백엔드 | `ValueError` — `_LLM_REGISTRY` 에 없는 이름 사용 시. 커스텀 백엔드는 `BaseLlmBlock` 상속 + `backend_name` 선언 필요 |
| `@requires` 비동기 전용 | `requires()` 는 `async def` 함수에만 적용 가능. 동기 함수에 적용 시 `TypeError` |
| `NestedEventBus` 네임스페이스 | 슬래시(`/`) 포함 금지 — `build_health_summary` 가 첫 `/` 를 기준으로 분리하므로 중첩 네임스페이스는 최대 깊이 3 |
| `probe_updates_registry` 기본값 | `False` — probe 결과가 BlockRegistry 통계에 반영되지 않음. 명시적으로 `SchedulerPolicy(probe_updates_registry=True)` 설정 시에만 연동 |
| `pylego.ops` vs `pylego.core.graph` | v0.1.3부터 `PipelineHealth` / `build_health_summary` / `CausalFactor` 등의 정식 위치는 `pylego.ops.*`. `from pylego_blocks.core.graph import ...` 는 shim으로 유지되지만 신규 코드에서는 비권장 |
| `from pylego_blocks.core.graph import ...` | **v0.2.0부터 `DeprecationWarning` 발생** — v1.0.0에서 제거 예정. 신규 코드에서는 `pylego.ops.*` 또는 `pylego.core.visualize` 직접 임포트 사용 |

---

## 7. 테스트 작성 규칙

```python
# 동기 테스트
def test_my_block() -> None:
    block = MyBlock()
    result = asyncio.run(block.run(MyInput(value=1)))
    assert result.result == "1"

# 비동기 테스트 (pytest-asyncio, asyncio_mode="auto")
async def test_my_block_async() -> None:
    result = await MyBlock().run(MyInput(value=1))
    assert result.result == "1"

# Assembly 테스트
def test_pipeline() -> None:
    pipeline = Assembly([MyBlock()])
    result = pipeline.run_sync(MyInput(value=1))
    assert result.result == "1"
```

**테스트 파일 위치:** `tests/core/test_*.py` (코어) | `tests/test_*.py` (통합)

---

## 8. 명령어

```bash
uv run pytest -q                        # 전체 테스트
uv run pytest tests/core/test_block.py  # 특정 파일
uv run mypy --strict src/               # 타입 검사
uv run mkdocs serve                     # 문서 로컬 미리보기
pylego inspect list                     # 등록 블록 목록
pylego inspect graph pipeline.yaml      # DAG 시각화
pylego serve pipeline.yaml --port 8000  # HTTP 서빙
pylego run-unit myapp.blocks.MyBlock --input '{"value":1}'
```

---

## 9. 환경변수 일람

| 변수 | 기본값 | 설명 |
|------|--------|------|
| `PYLEGO_LLM_BACKEND` | — | LlmRouter 기본 백엔드 (`anthropic` / `openai` / `ollama`) |
| `PYLEGO_LLM_MODEL` | — | LlmRouter 기본 모델 (LlmInput.model이 None일 때 사용) |
| `PYLEGO_LOG_LEVEL` | — | 설정 시 LoggingEventBus 자동 활성화 |
| `PYLEGO_OTEL_ENDPOINT` | — | OTLP HTTP 익스포터 URL |
| `PYLEGO_OTEL_SERVICE_NAME` | `pylego` | OTEL 서비스명 |
| `PYLEGO_CHECKPOINT_DIR` | — | 전역 체크포인트 디렉터리 |
| `PYLEGO_QUEUE_BACKEND` | `asyncio` | `redis` 로 설정 시 make_queue() → RedisQueue |
| `PYLEGO_REDIS_URL` | `redis://localhost:6379` | Redis 연결 URL |
| `PYLEGO_TELEGRAM_TOKEN` | — | TelegramBlock 토큰 fallback |
| `PYLEGO_GMAIL_USER` | — | GmailBlock 계정 주소 fallback |
| `PYLEGO_GMAIL_PASSWORD` | — | GmailBlock 앱 비밀번호 fallback |
| `PYLEGO_SLACK_WEBHOOK_URL` | — | SlackBlock Incoming Webhook URL fallback |
| `PYLEGO_DISCORD_WEBHOOK_URL` | — | DiscordBlock Webhook URL fallback |
| `PYLEGO_GOOGLE_SEARCH_API_KEY` | — | GoogleSearchBlock API 키 fallback |
| `PYLEGO_GOOGLE_SEARCH_ENGINE_ID` | — | GoogleSearchBlock 검색 엔진 ID fallback |
| `PYLEGO_GOOGLE_API_KEY` | — | GoogleTranslateBlock API 키 fallback |
| `PYLEGO_MYSQL_HOST` | `localhost` | MySqlBlock / PooledMySqlBlock 호스트 fallback |
| `PYLEGO_MYSQL_PORT` | `3306` | MySqlBlock / PooledMySqlBlock 포트 fallback |
| `PYLEGO_MYSQL_USER` | `root` | MySqlBlock / PooledMySqlBlock 사용자명 fallback |
| `PYLEGO_MYSQL_PASSWORD` | `""` | MySqlBlock / PooledMySqlBlock 비밀번호 fallback |
| `PYLEGO_MYSQL_DB` | `""` | MySqlBlock / PooledMySqlBlock 데이터베이스명 fallback |

---

## 10. 의존성 extras

```bash
pip install pylego-blocks              # 코어 (pydantic + pyyaml)
pip install pylego-blocks[serve]       # + fastapi + uvicorn
pip install pylego-blocks[otel]        # + opentelemetry-sdk
pip install pylego-blocks[redis]       # + redis>=5.0
pip install pylego-blocks[telegram]        # + httpx (TelegramBlock)
pip install pylego-blocks[gmail]           # + aiosmtplib (GmailBlock)
pip install pylego-blocks[slack]           # + httpx (SlackBlock)
pip install pylego-blocks[discord]         # + httpx (DiscordBlock)
pip install pylego-blocks[google-search]   # + httpx (GoogleSearchBlock)
pip install pylego-blocks[google-translate] # + httpx (GoogleTranslateBlock)
pip install pylego-blocks[duckduckgo]      # + duckduckgo-search (DuckDuckGoSearchBlock)
pip install pylego-blocks[duckdb]          # + duckdb>=0.10 (DuckDbBlock)
pip install pylego-blocks[sqlite]          # + aiosqlite>=0.20 (SqliteBlock)
pip install pylego-blocks[mysql]           # + aiomysql>=0.2 (MySqlBlock)
pip install pylego-blocks[excel]           # + openpyxl>=3.0 (ExcelReadBlock/ExcelWriteBlock)
pip install pylego-blocks[pdf]             # + pypdf + reportlab (PdfReadBlock/PdfWriteBlock)
pip install pylego-blocks[anthropic]       # + anthropic>=0.25 (AnthropicBlock)
pip install pylego-blocks[openai]          # + openai>=1.0 (OpenAiBlock)
pip install pylego-blocks[ollama]          # + httpx (OllamaBlock — Ollama 로컬 서버 필요)
pip install pylego-blocks[jinja2]          # + jinja2>=3.0 (TemplateBlock)
pip install pylego-blocks[chromadb]        # + chromadb>=0.5 (VectorUpsertBlock/VectorQueryBlock)
pip install pylego-blocks[scheduler]       # + apscheduler>=3.10 (Scheduler)
pip install pylego-blocks[dotenv]          # + python-dotenv>=1.0 (.env 자동 로드)
pip install pylego-blocks[all]             # 전체
```

---

## 11. AI 업무 수행 표준 워크플로 (M92)

AI가 자연어 업무 설명을 받아 파이프라인을 구성하고 실행하는 표준 절차.

```python
from pylego_blocks import Assembly, Scheduler, run_once, check_chain, build_health_summary, observe
from pylego_blocks.core.events import CollectingEventBus
from pylego_blocks.registry import default_registry

# Step 1 — 블록 발견
db_blocks = default_registry.search("mysql")
excel_blocks = default_registry.search("excel write")
candidates = default_registry.compatible_with(QueryResult)  # Stud 타입 기반

# Step 2 — 조합 검증
from pylego_blocks import MySqlBlock, ExcelWriteBlock, SlackBlock
result = check_chain([MySqlBlock, ExcelWriteBlock, SlackBlock])
if not result.compatible:
    for err in result.errors:
        print(f"  {err.left_block} → {err.right_block}: {err.expected} ≠ {err.got}")

# Step 3 — 파이프라인 구성
pipeline = Assembly([MySqlBlock(), ExcelWriteBlock(), SlackBlock()])

# Step 4 — 실행
output = run_once(pipeline, input=QueryInput(query="SELECT ..."))  # 단발
scheduler = Scheduler()
scheduler.add(pipeline, input=QueryInput(query="SELECT ..."), cron="0 8 * * 1-5")
await scheduler.start()  # 반복

# Step 5 — 결과 해석
bus = CollectingEventBus()
with observe(bus):
    output = await pipeline.run(QueryInput(query="SELECT ..."))
health = build_health_summary(bus.events, bus=bus)
ai_report = health.to_ai_summary()
```

**워크플로 요약:**

| 단계 | API | 목적 |
|------|-----|------|
| 1. 발견 | `registry.search()` / `compatible_with()` | 자연어 → 블록 후보 |
| 2. 검증 | `check_chain()` | 조합 가능 여부 확인 |
| 3. 조립 | `Assembly([...])` | 파이프라인 구성 |
| 4. 실행 | `run_once()` / `Scheduler` | 단발 또는 반복 실행 |
| 5. 해석 | `health.to_ai_summary()` | 결과·오류·권장 조치 |

> **설계 원칙 31 — AI는 조합하고, 사람은 검토한다.**
> AI가 블록을 발견·조합·실행하더라도 `check_chain()` 검증 결과와
> `to_ai_summary()` 진단을 사람이 확인한 뒤 프로덕션 스케줄에 등록한다.
> 자동화 비율을 높이되, 감시 루프는 반드시 유지한다.

---

## 12. 순환 임포트 방지 가이드 (#269)

pylego_blocks 소스 내부와 사용자 코드에서 순환 임포트가 발생하는 패턴과 예방법.

### 원칙: 패키지 내부는 직접 경로만 사용

`src/pylego_blocks/**/*.py` 파일은 **최상위 패키지(`from pylego_blocks import ...`)를 임포트하지 않는다.**
`__init__.py` 가 해당 파일을 임포트하기 때문에 역참조 순환이 생긴다.

```python
# ❌ 금지 — blocks/ 내부에서 최상위 패키지 참조
from pylego_blocks import Block, Stud          # 순환 임포트!

# ✅ 올바른 방법 — 직접 모듈 경로 사용
from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud
```

### 패턴별 예방법

```python
# ── 1. 런타임 임포트 (일반 사용) ───────────────────────────────────────────
from pylego_blocks.core.block import Block
from pylego_blocks.core.assembly import Assembly

# ── 2. 타입 전용 임포트 — TYPE_CHECKING 가드 사용 ──────────────────────────
from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pylego_blocks.core.events import BlockEvent  # 런타임에 임포트 안됨

# ── 3. 선택적 의존성 — 함수 내부 지연 임포트 ─────────────────────────────
def _load_optional() -> None:
    try:
        import chromadb  # 함수 내부에서만 임포트 → 순환 없음
    except ImportError:
        pass

# ── 4. 사용자 코드 — 최상위 패키지 사용 가능 ────────────────────────────────
# 사용자 코드는 pylego_blocks.__init__ 에 의해 임포트되지 않으므로 안전하다
from pylego_blocks import Block, Stud, Assembly  # 사용자 코드에서는 OK
```

### 순환 임포트 진단

```bash
# 임포트 오류 재현
python -c "import pylego_blocks"

# 임포트 순서 추적 (verbose)
python -v -c "import pylego_blocks" 2>&1 | grep "pylego_blocks"
```

**자주 하는 실수:**

| 상황 | 잘못된 방법 | 올바른 방법 |
|------|------------|------------|
| 블록 파일에서 Block 상속 | `from pylego_blocks import Block` | `from pylego_blocks.core.block import Block` |
| 블록 파일에서 Stud 상속 | `from pylego_blocks import Stud` | `from pylego_blocks.core.stud import Stud` |
| 타입 힌트만 필요한 경우 | 런타임 임포트 | `TYPE_CHECKING` 가드 |
| 선택적 패키지 | 모듈 최상단 임포트 | 함수 내 지연 임포트 + `try/except ImportError` |

---

## 13. Stud 설계 빠른 시작 (#270)

Stud 를 처음 접할 때 자주 막히는 포인트를 정리한다.

### Stud 란?

```python
from pylego_blocks import Stud

# Stud = pydantic BaseModel + frozen=True + extra="forbid"
# frozen=True  → 생성 후 필드 값 변경 불가 (불변 데이터 계약)
# extra="forbid" → 선언되지 않은 필드 전달 시 ValidationError
class MyInput(Stud):
    query: str
    max_rows: int = 100  # 기본값 선언 가능
```

### 가장 흔한 실수 Top 5

```python
# ── 실수 1: Stud 필드를 직접 수정 ───────────────────────────────────────────
inp = MyInput(query="SELECT 1")
inp.query = "SELECT 2"          # ❌ FrozenInstanceError

# ✅ .model_copy(update={}) 로 새 인스턴스 생성
inp2 = inp.model_copy(update={"query": "SELECT 2"})

# ── 실수 2: 선언되지 않은 필드 전달 ─────────────────────────────────────────
inp = MyInput(query="Q", typo_field="x")  # ❌ ValidationError: extra fields not permitted

# ✅ 필드를 먼저 선언
class MyInput(Stud):
    query: str
    extra_info: str = ""  # 필요한 필드를 미리 선언

# ── 실수 3: 파이프라인 중간에 데이터 추가 ────────────────────────────────────
# 블록 A 출력에 없는 필드를 블록 B 입력에서 요구 → IncompatibleSnapError
# ✅ 데이터를 추가해야 한다면 새 Stud 타입 설계:
class EnrichedInput(Stud):
    query: str
    extra_context: str   # A 에서 B 로 전달할 추가 데이터

# ── 실수 4: input_model / output_model 이 같아야 한다고 착각 ─────────────────
# 입력과 출력은 같은 타입일 수도 있고 다를 수도 있다. Assembly 가 연결을 검증한다.
class PassThroughBlock(Block[MyInput, MyInput]):  # 동일 타입도 가능
    input_model = MyInput
    output_model = MyInput
    async def run(self, inp: MyInput) -> MyInput:
        return inp

# ── 실수 5: Stud 에 메서드를 많이 추가 ──────────────────────────────────────
# Stud 는 순수 데이터 계약이다. 로직은 Block 에 둔다.
class MyInput(Stud):
    value: int
    def doubled(self) -> int:   # ❌ Stud 에 비즈니스 로직 금지
        return self.value * 2
```

### 중첩 Stud

```python
from pylego_blocks import Stud
from typing import Any

class Item(Stud):
    name: str
    score: float

class BatchInput(Stud):
    items: list[Item]      # Stud 안에 Stud 리스트
    metadata: dict[str, Any] = {}

inp = BatchInput(
    items=[Item(name="a", score=0.9), Item(name="b", score=0.7)],
)
# items 는 자동으로 Item 인스턴스로 변환됨 (pydantic 검증)
```

### 검증 추가 시점 결정 기준

```
값이 어디서 오는가?
  ├── 사용자 입력 / 외부 API → @field_validator 또는 @model_validator (즉시, 무료)
  ├── DB / 캐시 / 파일 조회 필요 → Unit.validate() (async 필요)
  └── 블록 실행 결과 검증 → Unit.verify() (출력이 생긴 후)
```

### Assembly 연결 오류 해결

```python
from pylego_blocks import check_chain, Assembly

# 조립 전에 Stud 연결 검증
result = check_chain([BlockA(), BlockB(), BlockC()])
if not result.compatible:
    for err in result.errors:
        # err.position: 오류 위치, err.expected: 기대 타입, err.got: 실제 타입
        print(f"위치 {err.position}: {err.left_block} → {err.right_block}")
        print(f"  기대: {err.expected.__name__}, 실제: {err.got.__name__}")
# Assembly 조립 전에 오류 원인을 확인한다
```

---

## 14. Core / Blocks 디렉토리 수정 규칙

### 디렉토리별 역할과 수정 정책

| 디렉토리 | 규칙 | 이유 |
|---------|------|------|
| `src/pylego_blocks/core/` | **수정 금지** — 서브클래스로 확장 | 모든 블록의 상속 기반. 수정 시 프레임워크 전체에 영향 |
| `src/pylego_blocks/blocks/` | 버그 수정만 허용. 동작 추가는 서브클래스로 | 참고 구현체. 그대로 사용하거나 상속 |
| 사용자 프로젝트 파일 | 자유롭게 작성 | 서브클래스 또는 `CallableBlock` 으로 새 블록 정의 |

> **AI 에이전트 규칙:** `src/pylego_blocks/core/` 파일은 절대 수정하지 않는다.
> 동작 변경이 필요하면 반드시 서브클래스를 만들어 메서드를 오버라이드한다.

### 올바른 확장 패턴

```python
# ❌ 금지 — core/ 또는 blocks/ 파일을 직접 수정
# ✅ 사용자 프로젝트 파일에서 서브클래스로 확장

from pylego_blocks import Block, Stud
from pylego_blocks.blocks.llm.anthropic import AnthropicBlock, AnthropicInput, AnthropicResult

# core/ 확장 — Block 상속으로 새 블록 작성
class MyBlock(Block[MyInput, MyOutput]):
    input_model = MyInput
    output_model = MyOutput
    async def run(self, inp: MyInput) -> MyOutput: ...

# blocks/ 확장 — 기존 블록 상속으로 동작 추가
class MyAnthropicBlock(AnthropicBlock):
    async def run(self, inp: AnthropicInput) -> AnthropicResult:
        # 전처리 또는 후처리 추가
        return await super().run(inp)
```

### 파일별 역할 요약

```
core/block.py       → Block 추상 클래스     — 상속만, 수정 금지
core/stud.py        → Stud 베이스 클래스    — 상속만, 수정 금지
core/assembly.py    → Assembly 조립 엔진    — 사용만, 수정 금지
core/resilience.py  → Retry/Fallback 등    — 사용만, 수정 금지
core/events.py      → EventBus 계층        — 사용만, 수정 금지
blocks/**/*.py      → 구체 블록 구현체      — 사용 또는 서브클래스
```
