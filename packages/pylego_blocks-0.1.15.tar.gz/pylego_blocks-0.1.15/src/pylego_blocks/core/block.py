"""Block — pylego 의 최소 실행 단위.

모든 블록은:
- `input_model` / `output_model` 로 Stud 계약을 선언한다.
- `run(inp)` 을 `async def` 로 구현한다 (동기 로직은 await 없이 반환).
- 다른 블록의 내부를 참조하지 않는다 — Stud 만 본다.
- 단독 실행·단독 테스트 가능해야 한다 (외부 의존은 생성자 주입).

Runtime 은 블록과 분리되어 있어, 동일 블록을 sync/async 런타임 모두에서 실행할 수 있다.

CORE INTERFACE — 이 파일을 직접 수정하지 않는다. 새 블록은 Block 을 상속해 작성한다.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from pylego_blocks.core.stud import Stud


class Block[InputT: Stud, OutputT: Stud](ABC):
    """pylego 최소 실행 단위. 모든 파이프라인 컴포넌트의 베이스 클래스.

    서브클래스 작성 규칙:
        1. `input_model = MyInputStud` 선언 필수 (Stud 서브클래스)
        2. `output_model = MyOutputStud` 선언 필수 (Stud 서브클래스)
        3. `async def run(self, inp: InputT) -> OutputT` 구현 필수
        4. `name` 은 생략 시 클래스명 자동 설정

    Example:
        ```python
        class MyInput(Stud):
            value: int

        class MyOutput(Stud):
            result: str

        class MyBlock(Block[MyInput, MyOutput]):
            input_model = MyInput
            output_model = MyOutput

            async def run(self, inp: MyInput) -> MyOutput:
                return MyOutput(result=str(inp.value * 2))
        ```

    Raises:
        TypeError: `input_model` 또는 `output_model` 이 선언되지 않은 경우 (클래스 정의 시점).
        TypeError: `input_model` / `output_model` 이 Stud 서브클래스가 아닌 경우.

    Note:
        `input_model`/`output_model` 은 ClassVar 가 아닌 일반 클래스 속성이므로,
        Assembly 같은 합성 블록에서 인스턴스별로 섀도잉할 수 있다.
    """

    name: str = ""
    input_model: type[Stud]
    output_model: type[Stud]

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        # 구체 클래스(ABC가 아닌)에만 검증 적용
        if getattr(cls, "__abstractmethods__", None):
            return
        if not cls.name:
            cls.name = cls.__name__
        if not hasattr(cls, "input_model") or not hasattr(cls, "output_model"):
            raise TypeError(
                f"Block '{cls.__name__}' 는 input_model / output_model 을 선언해야 합니다."
            )
        if not (isinstance(cls.input_model, type) and issubclass(cls.input_model, Stud)):
            raise TypeError(f"Block '{cls.__name__}'.input_model 은 Stud 서브클래스여야 합니다.")
        if not (isinstance(cls.output_model, type) and issubclass(cls.output_model, Stud)):
            raise TypeError(f"Block '{cls.__name__}'.output_model 은 Stud 서브클래스여야 합니다.")

    @classmethod
    def describe(cls) -> str:
        """블록 계약을 사람이 읽기 좋은 한 줄로 반환."""
        return f"{cls.name}: {cls.input_model.__name__} → {cls.output_model.__name__}"

    @abstractmethod
    async def run(self, inp: InputT) -> OutputT:
        """블록 실행 로직. 구체 클래스에서 반드시 구현.

        Args:
            inp: 입력 데이터. `input_model` 로 선언된 Stud 인스턴스.
                 Assembly.run() 이 자동으로 유효성을 검증한 후 전달한다.

        Returns:
            `output_model` 로 선언된 Stud 인스턴스.
            동기 로직만 있어도 `async def` 로 선언해야 한다.

        Raises:
            임의의 예외: 상위 Assembly 에서 BlockFailedEvent 로 변환된다.
                RetryBlock / FallbackBlock / CircuitBreakerBlock 으로 감싸면 자동 복구.
        """
