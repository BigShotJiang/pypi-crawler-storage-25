"""Daemon process utilities — PID file management.

Used by `pylego schedule start --daemon` to manage background scheduler processes.
"""

from __future__ import annotations

import os
import signal
import sys
from pathlib import Path

_DEFAULT_PID_DIR = ".pylego"


def default_pid_path(label: str) -> Path:
    """Return default PID file path under `.pylego/` in the current directory."""
    return Path(_DEFAULT_PID_DIR) / f"{label}.pid"


def write_pid(path: Path) -> None:
    """Write current PID to *path*."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(str(os.getpid()), encoding="utf-8")


def read_pid(path: Path) -> int | None:
    """Read PID from *path*. Returns ``None`` if the file is absent or unreadable."""
    if not path.exists():
        return None
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return None


def is_running(pid: int) -> bool:
    """Return ``True`` if a process with *pid* is alive."""
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def stop_pid_file(path: Path) -> tuple[bool, str]:
    """Send SIGTERM to the process recorded in *path*.

    Returns:
        (success, message)
    """
    pid = read_pid(path)
    if pid is None:
        return False, "PID 파일이 없거나 읽을 수 없습니다."
    if not is_running(pid):
        path.unlink(missing_ok=True)
        return False, f"프로세스 {pid} 가 이미 종료되어 있습니다."
    try:
        os.kill(pid, signal.SIGTERM)
        path.unlink(missing_ok=True)
        return True, f"프로세스 {pid} 에 SIGTERM 전송 완료."
    except PermissionError:
        return False, f"프로세스 {pid} 를 종료할 권한이 없습니다."
    except ProcessLookupError:
        path.unlink(missing_ok=True)
        return False, f"프로세스 {pid} 가 이미 종료되어 있습니다."


def daemonize() -> None:
    """Fork current process into background (Unix only). Parent exits immediately."""
    if sys.platform == "win32":
        raise NotImplementedError(
            "--daemon 옵션은 Windows 에서 지원되지 않습니다. "
            "WSL 또는 Linux 환경을 사용하세요."
        )
    pid = os.fork()
    if pid > 0:
        sys.exit(0)
    os.setsid()


def list_running(pid_dir: str | None = None) -> list[tuple[str, int, bool]]:
    """Return list of (label, pid, is_running) for all PID files in *pid_dir*."""
    base = Path(pid_dir) if pid_dir else Path(_DEFAULT_PID_DIR)
    if not base.exists():
        return []
    results: list[tuple[str, int, bool]] = []
    for pid_file in sorted(base.glob("*.pid")):
        label = pid_file.stem
        pid = read_pid(pid_file)
        if pid is not None:
            results.append((label, pid, is_running(pid)))
    return results
