"""pylego CLI."""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from collections.abc import Sequence

from pydantic import ValidationError

from pylego_blocks.inspect.cli import inspect_list, inspect_matrix, inspect_show
from pylego_blocks.inspect.graph import inspect_graph
from pylego_blocks.pipelines import AiPiPipelineConfig, build_ai_pi_pipeline, run_ai_pi
from pylego_blocks.pipelines.ai_pi import DEFAULT_COPILOT_SOCKET_PATH, DEFAULT_GEMINI_SOCKET_PATH


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m pylego")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="Run the ai-pi pipeline")
    run_parser.add_argument("issue_number", type=int)
    run_parser.add_argument("--dry-run", action="store_true", help="Build without executing")

    run_unit_parser = subparsers.add_parser("run-unit", help="Run a Unit standalone")
    run_unit_parser.add_argument("unit", help="Fully-qualified class name (e.g. mypackage.MyUnit)")
    run_unit_parser.add_argument("--input", default=None, help="JSON input string")
    run_unit_parser.add_argument("--schema", action="store_true", help="Print input JSON Schema")

    inspect_parser = subparsers.add_parser("inspect", help="Inspect registered blocks")
    inspect_subparsers = inspect_parser.add_subparsers(dest="inspect_command", required=True)

    list_parser = inspect_subparsers.add_parser("list", help="List registered blocks")
    list_parser.add_argument("--module", default="pylego_blocks.blocks")
    list_parser.add_argument("--format", choices=("tty", "json"), default="tty")
    list_parser.add_argument(
        "--installed",
        action="store_true",
        help="entry-points(pylego.blocks)로 설치된 모든 블록 포함",
    )

    show_parser = inspect_subparsers.add_parser("show", help="Show a block contract")
    show_parser.add_argument("name")
    show_parser.add_argument("--module", default="pylego_blocks.blocks")

    matrix_parser = inspect_subparsers.add_parser("matrix", help="Show compatibility matrix")
    matrix_parser.add_argument("--module", default="pylego_blocks.blocks")
    matrix_parser.add_argument("--format", choices=("tty", "json"), default="tty")

    graph_parser = inspect_subparsers.add_parser("graph", help="Visualize assembly graph")
    graph_parser.add_argument("file", help="YAML file describing the assembly")
    graph_parser.add_argument(
        "--format",
        choices=("mermaid", "dot", "html"),
        default="mermaid",
        help="Output format (default: mermaid)",
    )
    graph_parser.add_argument("--output", default=None, help="Output file (default: stdout)")

    assemble_parser = subparsers.add_parser("assemble", help="Load Assembly from YAML")
    assemble_parser.add_argument("file", help="YAML file describing the assembly")
    assemble_parser.add_argument("--dry-run", action="store_true", help="Parse and print assembly without executing")

    serve_parser = subparsers.add_parser("serve", help="Serve an Assembly as HTTP API")
    serve_parser.add_argument("file", help="YAML file describing the assembly")
    serve_parser.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    serve_parser.add_argument("--port", type=int, default=8000, help="Listen port (default: 8000)")
    serve_parser.add_argument("--reload", action="store_true", help="Auto-reload on code change (dev)")

    schedule_parser = subparsers.add_parser("schedule", help="Run a YAML assembly on a schedule")
    schedule_subparsers = schedule_parser.add_subparsers(dest="schedule_command", required=True)

    schedule_once_parser = schedule_subparsers.add_parser("run-once", help="Execute assembly once synchronously")
    schedule_once_parser.add_argument("file", help="YAML file describing the assembly")
    schedule_once_parser.add_argument("--input", default=None, help="JSON input for the first block")

    schedule_start_parser = schedule_subparsers.add_parser("start", help="Start a scheduler for a YAML assembly")
    schedule_start_parser.add_argument("file", help="YAML file describing the assembly")
    schedule_start_parser.add_argument("--interval", type=float, default=None, metavar="SECONDS", help="Run interval in seconds")
    schedule_start_parser.add_argument("--cron", default=None, metavar="EXPR", help="Cron expression (e.g. '0 9 * * *')")
    schedule_start_parser.add_argument("--input", default=None, help="JSON input for the first block")
    schedule_start_parser.add_argument("--daemon", action="store_true", help="Run as background daemon process")
    schedule_start_parser.add_argument("--pid", default=None, metavar="FILE", help="PID file path (default: .pylego/<name>.pid)")

    schedule_stop_parser = schedule_subparsers.add_parser("stop", help="Stop a running daemon scheduler")
    schedule_stop_parser.add_argument("--pid", default=None, metavar="FILE", help="PID file path")
    schedule_stop_parser.add_argument("--name", default=None, metavar="NAME", help="Scheduler label (uses default PID path)")

    schedule_status_parser = schedule_subparsers.add_parser("status", help="Show running schedulers")
    schedule_status_parser.add_argument("--pid-dir", default=None, metavar="DIR", help="Directory to scan for PID files (default: .pylego/)")

    docs_parser = subparsers.add_parser("docs", help="Show bundled documentation")
    docs_parser.add_argument(
        "section",
        nargs="?",
        default=None,
        metavar="SECTION",
        help="Section keyword to filter (e.g. 'assembly', 'resilience', 'patterns')",
    )
    docs_parser.add_argument(
        "--open",
        dest="open_browser",
        action="store_true",
        help="Open documentation in browser as HTML",
    )
    docs_parser.add_argument(
        "--copy",
        dest="copy_dest",
        nargs="?",
        const=".",
        default=None,
        metavar="DEST",
        help="Copy AGENT.md to DEST directory (default: current directory) for agent auto-discovery",
    )

    return parser


# #35/#37 후속: env var fallback 을 AiPiPipelineConfig 기본값(600s) 과 동일하게
# 맞춤. 이전엔 여기서 300.0 을 하드코딩해 모델 기본값이 덮어써져 운영 시 5 min
# 시점에 Dev timeout 이 발동 → #27 false FAIL 의 직접 원인.
_DEFAULT_DEV_TIMEOUT_SEC = 600.0
_DEFAULT_QA_TIMEOUT_SEC = 600.0


def _read_float_env(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None:
        return default
    return float(raw)


def _load_config(issue_number: int) -> AiPiPipelineConfig:
    repo = os.getenv("GITHUB_REPO")
    if repo is None or repo == "":
        raise ValueError("GITHUB_REPO 환경변수를 설정하세요.")

    return AiPiPipelineConfig(
        repo=repo,
        issue_number=issue_number,
        copilot_socket_path=os.getenv("COPILOT_DAEMON_SOCK", DEFAULT_COPILOT_SOCKET_PATH),
        gemini_socket_path=os.getenv("GEMINI_DAEMON_SOCK", DEFAULT_GEMINI_SOCKET_PATH),
        base_branch=os.getenv("PYLEGO_BASE_BRANCH", "main"),
        dev_prompt_timeout_sec=_read_float_env("PYLEGO_DEV_TIMEOUT", _DEFAULT_DEV_TIMEOUT_SEC),
        qa_prompt_timeout_sec=_read_float_env("PYLEGO_QA_TIMEOUT", _DEFAULT_QA_TIMEOUT_SEC),
        prompt_backend=os.getenv("PYLEGO_PROMPT_BACKEND", "copilot"),  # type: ignore[arg-type]
    )


def _run_command(args: argparse.Namespace) -> int:
    config = _load_config(args.issue_number)

    if args.dry_run:
        pipeline = build_ai_pi_pipeline(config)
        print(repr(pipeline))
        return 0

    result = asyncio.run(run_ai_pi(config))
    if result.final_state == "merged":
        return 0
    if result.final_state == "failed":
        return 1
    if result.final_state == "escalated":
        return 2
    raise RuntimeError(f"알 수 없는 final_state: {result.final_state!r}")

def _assemble_command(args: argparse.Namespace) -> int:
    # Lazy import to avoid pulling pyyaml requirement unless used.
    try:
        from pylego_blocks.declarative import load_assembly_from_yaml
    except Exception as exc:
        print(f"error: cannot load declarative loader: {exc}")
        return 2
    try:
        assembly = load_assembly_from_yaml(args.file)
    except Exception as exc:
        print(f"error: failed to parse assembly: {exc}")
        return 2
    if args.dry_run:
        print(repr(assembly))
        return 0
    # For now, assemble command only parses and prints the assembly.
    print(repr(assembly))
    return 0


def _inspect_command(args: argparse.Namespace) -> int:
    if args.inspect_command == "list":
        installed: bool = getattr(args, "installed", False)
        return inspect_list(root=args.module, output_format=args.format, installed=installed)
    if args.inspect_command == "show":
        return inspect_show(args.name, root=args.module)
    if args.inspect_command == "matrix":
        return inspect_matrix(root=args.module, output_format=args.format)
    if args.inspect_command == "graph":
        return inspect_graph(args.file, output_format=args.format, output_file=args.output)
    raise ValueError(f"알 수 없는 inspect 명령: {args.inspect_command}")


def _serve_command(args: argparse.Namespace) -> int:
    """pylego serve <yaml> [--host H] [--port P] [--reload]"""
    try:
        from pylego_blocks.declarative import load_assembly_from_yaml
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    try:
        assembly = load_assembly_from_yaml(args.file)
    except Exception as exc:
        print(f"error: failed to load assembly: {exc}", file=sys.stderr)
        return 2
    try:
        from pylego_blocks.serve import serve
    except ImportError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    serve(assembly, host=args.host, port=args.port, reload=args.reload)
    return 0


def _run_unit_command(args: argparse.Namespace) -> int:
    """pylego run-unit <module.Class> [--input '{}'] [--schema]"""
    import importlib

    qualified = args.unit
    parts = qualified.rsplit(".", 1)
    if len(parts) != 2:
        print(f"error: expected module.ClassName, got {qualified!r}", file=sys.stderr)
        return 2

    module_name, class_name = parts
    try:
        mod = importlib.import_module(module_name)
    except ImportError as exc:
        print(f"error: cannot import {module_name!r}: {exc}", file=sys.stderr)
        return 2

    cls = getattr(mod, class_name, None)
    if cls is None:
        print(f"error: {class_name!r} not found in {module_name!r}", file=sys.stderr)
        return 2

    from pylego_blocks.unit import Unit, run_unit_main, unit_schema

    if not (isinstance(cls, type) and issubclass(cls, Unit)):
        print(f"error: {qualified!r} is not a Unit subclass", file=sys.stderr)
        return 2

    unit = cls()

    if args.schema:
        import json
        print(json.dumps(unit_schema(unit), ensure_ascii=False, indent=2))
        return 0

    if args.input is None:
        print("error: --input JSON is required (or use --schema)", file=sys.stderr)
        return 2

    run_unit_main(unit, argv=[args.input])
    return 0


def _schedule_command(args: argparse.Namespace) -> int:
    """pylego schedule <subcommand>"""
    if args.schedule_command == "start":
        return _schedule_start_command(args)

    if args.schedule_command == "stop":
        return _schedule_stop_command(args)

    if args.schedule_command == "status":
        return _schedule_status_command(args)

    if args.schedule_command == "run-once":
        import json

        try:
            from pylego_blocks.declarative import load_assembly_from_yaml
        except Exception as exc:
            print(f"error: cannot load declarative loader: {exc}", file=sys.stderr)
            return 2

        try:
            assembly = load_assembly_from_yaml(args.file)
        except Exception as exc:
            print(f"error: failed to load assembly: {exc}", file=sys.stderr)
            return 2

        from pylego_blocks.scheduler import run_once

        first_block = assembly._blocks[0]
        input_model = getattr(first_block, "input_model", None)
        if input_model is None:
            print("error: first block has no input_model", file=sys.stderr)
            return 2
        raw = args.input or "{}"
        try:
            inp = input_model.model_validate(json.loads(raw))
        except Exception as exc:
            print(f"error: invalid input: {exc}", file=sys.stderr)
            return 2
        result = run_once(assembly, input=inp)
        print(result.model_dump_json(indent=2))
        return 0

    print(f"error: unknown schedule subcommand: {args.schedule_command!r}", file=sys.stderr)
    return 2


def _schedule_start_command(args: argparse.Namespace) -> int:
    """pylego schedule start <yaml> [--interval N | --cron EXPR] [--daemon] [--pid FILE]"""
    import json
    from pathlib import Path

    try:
        from pylego_blocks.declarative import load_assembly_from_yaml
    except Exception as exc:
        print(f"error: cannot load declarative loader: {exc}", file=sys.stderr)
        return 2

    try:
        assembly = load_assembly_from_yaml(args.file)
    except Exception as exc:
        print(f"error: failed to load assembly: {exc}", file=sys.stderr)
        return 2

    if args.interval is None and args.cron is None:
        print("error: --interval 또는 --cron 을 지정하세요.", file=sys.stderr)
        return 2

    first_block = assembly._blocks[0]
    input_model = getattr(first_block, "input_model", None)
    if input_model is None:
        print("error: first block has no input_model", file=sys.stderr)
        return 2
    raw = getattr(args, "input", None) or "{}"
    try:
        inp = input_model.model_validate(json.loads(raw))
    except Exception as exc:
        print(f"error: invalid input: {exc}", file=sys.stderr)
        return 2

    label = Path(args.file).stem
    pid_file_str: str | None = getattr(args, "pid", None)

    from pylego_blocks.core.daemon import daemonize, default_pid_path, write_pid
    from pylego_blocks.scheduler import Scheduler

    pid_path = Path(pid_file_str) if pid_file_str else default_pid_path(label)

    if getattr(args, "daemon", False):
        try:
            daemonize()
        except NotImplementedError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        write_pid(pid_path)

    scheduler = Scheduler()
    scheduler.add(
        assembly,
        input=inp,
        job_id=label,
        interval_seconds=getattr(args, "interval", None),
        cron=getattr(args, "cron", None),
    )

    if getattr(args, "daemon", False):
        asyncio.run(scheduler.run_forever())
    else:
        print(f"Starting scheduler for '{label}' (Ctrl+C to stop)...")
        try:
            asyncio.run(scheduler.run_forever())
        except KeyboardInterrupt:
            pass
    return 0


def _schedule_stop_command(args: argparse.Namespace) -> int:
    """pylego schedule stop [--pid FILE | --name NAME]"""
    from pathlib import Path

    from pylego_blocks.core.daemon import default_pid_path, stop_pid_file

    pid_file_str: str | None = getattr(args, "pid", None)
    name: str | None = getattr(args, "name", None)

    if pid_file_str:
        pid_path = Path(pid_file_str)
    elif name:
        pid_path = default_pid_path(name)
    else:
        print("error: --pid FILE 또는 --name NAME 을 지정하세요.", file=sys.stderr)
        return 2

    success, msg = stop_pid_file(pid_path)
    print(msg)
    return 0 if success else 1


def _schedule_status_command(args: argparse.Namespace) -> int:
    """pylego schedule status [--pid-dir DIR]"""
    from pylego_blocks.core.daemon import list_running

    pid_dir: str | None = getattr(args, "pid_dir", None)
    entries = list_running(pid_dir)
    if not entries:
        print("실행 중인 스케줄러가 없습니다.")
        return 0
    print(f"{'이름':<24} {'PID':>8}  상태")
    print("-" * 40)
    for label, pid, running in entries:
        status = "실행 중" if running else "종료됨"
        print(f"{label:<24} {pid:>8}  {status}")
    return 0


def _md_inline(text: str) -> str:
    """Convert inline markdown elements to HTML (no external deps)."""
    import html as _html
    import re as _re

    text = _html.escape(text)
    text = _re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = _re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = _re.sub(r"\*(.+?)\*", r"<em>\1</em>", text)
    text = _re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', text)
    return text


def _md_to_html(md: str) -> str:
    """Convert a subset of Markdown to a self-contained HTML page."""
    import html as _html
    import re as _re

    _CSS = (
        "body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;"
        "max-width:960px;margin:40px auto;padding:0 20px;color:#24292e;line-height:1.6}"
        "h1,h2,h3,h4{border-bottom:1px solid #eaecef;padding-bottom:.3em;margin-top:24px}"
        "code{background:#f6f8fa;padding:.2em .4em;border-radius:3px;"
        "font-family:monospace;font-size:85%}"
        "pre{background:#f6f8fa;padding:16px;border-radius:6px;overflow:auto}"
        "pre code{background:none;padding:0;font-size:100%}"
        "table{border-collapse:collapse;width:100%;margin:16px 0}"
        "th,td{border:1px solid #dfe2e5;padding:6px 13px;text-align:left}"
        "th{background:#f6f8fa}"
        "tr:nth-child(even){background:#f6f8fa}"
        "hr{border:0;border-top:1px solid #eaecef;margin:24px 0}"
        "blockquote{color:#6a737d;border-left:4px solid #dfe2e5;padding:0 1em;margin:0}"
        "a{color:#0366d6;text-decoration:none}"
        "ul,ol{padding-left:2em}"
    )

    lines = md.splitlines()
    parts: list[str] = [
        f"<html><head><meta charset='utf-8'>"
        f"<style>{_CSS}</style></head><body>"
    ]
    i = 0
    list_open = False

    def close_list() -> None:
        nonlocal list_open
        if list_open:
            parts.append("</ul>")
            list_open = False

    while i < len(lines):
        line = lines[i]

        # Fenced code block
        if line.startswith("```"):
            close_list()
            lang = _html.escape(line[3:].strip())
            block_lines: list[str] = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                block_lines.append(_html.escape(lines[i]))
                i += 1
            cls = f' class="language-{lang}"' if lang else ""
            parts.append(f"<pre><code{cls}>{chr(10).join(block_lines)}</code></pre>")
            i += 1  # skip closing ```
            continue

        # Heading
        if line.startswith("#"):
            close_list()
            stripped = line.lstrip("#")
            level = min(len(line) - len(stripped), 6)
            parts.append(f"<h{level}>{_md_inline(stripped.strip())}</h{level}>")

        # Horizontal rule
        elif _re.match(r"^[-*_]{3,}$", line.strip()):
            close_list()
            parts.append("<hr>")

        # Table (detect by separator on next line)
        elif "|" in line:
            next_line = lines[i + 1] if i + 1 < len(lines) else ""
            if _re.match(r"^\|[-|: ]+\|$", next_line.strip()):
                close_list()
                headers = [c.strip() for c in line.strip("|").split("|")]
                parts.append("<table><thead><tr>")
                for h in headers:
                    parts.append(f"<th>{_md_inline(h)}</th>")
                parts.append("</tr></thead><tbody>")
                i += 2  # skip header + separator
                while i < len(lines) and "|" in lines[i]:
                    cells = [c.strip() for c in lines[i].strip("|").split("|")]
                    parts.append("<tr>")
                    for c in cells:
                        parts.append(f"<td>{_md_inline(c)}</td>")
                    parts.append("</tr>")
                    i += 1
                parts.append("</tbody></table>")
                continue  # i already at next unprocessed line
            else:
                close_list()
                parts.append(f"<p>{_md_inline(line)}</p>")

        # Blockquote
        elif line.startswith("> "):
            close_list()
            parts.append(f"<blockquote><p>{_md_inline(line[2:])}</p></blockquote>")

        # List item (unordered or ordered)
        elif _re.match(r"^[-*] ", line) or _re.match(r"^\d+\. ", line):
            if not list_open:
                parts.append("<ul>")
                list_open = True
            text = _re.sub(r"^[-*] |^\d+\. ", "", line)
            parts.append(f"<li>{_md_inline(text.strip())}</li>")

        # Blank line
        elif not line.strip():
            close_list()

        # Paragraph
        else:
            close_list()
            parts.append(f"<p>{_md_inline(line)}</p>")

        i += 1

    close_list()
    parts.append("</body></html>")
    return "\n".join(parts)


def _docs_extract_section(content: str, keyword: str) -> str | None:
    """Extract the first section whose heading contains keyword (case-insensitive)."""
    kw = keyword.lower()
    lines = content.splitlines(keepends=True)
    result: list[str] = []
    in_section = False
    section_level = 0

    for line in lines:
        stripped = line.lstrip("#")
        level = len(line) - len(stripped)
        if level > 0:
            heading = stripped.strip().lower()
            if kw in heading:
                in_section = True
                section_level = level
                result.append(line)
            elif in_section and level <= section_level:
                break
            elif in_section:
                result.append(line)
        elif in_section:
            result.append(line)

    return "".join(result).strip() if result else None


def _docs_list_headings(content: str) -> list[str]:
    return [line.lstrip("#").strip() for line in content.splitlines() if line.startswith("## ")]


def _docs_open_html(content: str) -> int:
    import tempfile
    import webbrowser

    html = _md_to_html(content)
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".html", delete=False, encoding="utf-8"
    ) as f:
        f.write(html)
        tmp_path = f.name

    webbrowser.open(f"file://{tmp_path}")
    return 0


def _docs_command(args: argparse.Namespace) -> int:
    """pylego docs [SECTION] [--open] [--copy [DEST]]"""
    import shutil
    from pathlib import Path

    from pylego_blocks import docs_path

    src = docs_path()

    copy_dest: str | None = getattr(args, "copy_dest", None)
    if copy_dest is not None:
        dest_dir = Path(copy_dest)
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest_file = dest_dir / "AGENT.md"
        shutil.copy2(src, dest_file)
        print(f"AGENT.md copied to {dest_file.resolve()}")
        print("AI agents (Claude Code, Cursor, etc.) will auto-discover this file.")
        return 0

    content = src.read_text(encoding="utf-8")

    section: str | None = getattr(args, "section", None)
    if section:
        extracted = _docs_extract_section(content, section)
        if extracted is None:
            print(f"error: section '{section}' not found in docs", file=sys.stderr)
            print("available sections:", file=sys.stderr)
            for heading in _docs_list_headings(content):
                print(f"  {heading}", file=sys.stderr)
            return 1
        content = extracted

    if getattr(args, "open_browser", False):
        return _docs_open_html(content)

    import pydoc
    pydoc.pager(content)
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "run":
        try:
            return _run_command(args)
        except ValueError as exc:
            parser.error(str(exc))
        except ValidationError as exc:
            parser.error(str(exc))
    if args.command == "run-unit":
        return _run_unit_command(args)
    if args.command == "inspect":
        try:
            return _inspect_command(args)
        except ValueError as exc:
            parser.error(str(exc))
    if args.command == "assemble":
        return _assemble_command(args)
    if args.command == "serve":
        return _serve_command(args)
    if args.command == "schedule":
        return _schedule_command(args)
    if args.command == "docs":
        return _docs_command(args)
    parser.error(f"알 수 없는 명령: {args.command}")
