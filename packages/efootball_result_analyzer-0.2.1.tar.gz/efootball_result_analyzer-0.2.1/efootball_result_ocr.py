"""
eFootball Match Result and Stats Announcer (OCR-only)
=====================================================
Reads eFootball (Konami) match result screenshots using pytesseract OCR.
Extracts the scoreline, winner or loser, and match statistics locally.

Requirements:
    pip install pytesseract pillow opencv-python

Also install the Tesseract OCR engine:
  - Windows: https://github.com/UB-Mannheim/tesseract/wiki
  - Mac:     brew install tesseract
  - Linux:   sudo apt install tesseract-ocr

Usage:
    python efootball_result_ocr.py --image result.jpg
    python efootball_result_ocr.py --image result.jpg --username "I clear ball"
    python efootball_result_ocr.py --image result.jpg --team "United"
"""

from __future__ import annotations

import argparse
import re
import sys
from collections import Counter
from difflib import SequenceMatcher
from pathlib import Path

import cv2
import numpy as np
import pytesseract
from PIL import Image


TESSERACT_INSTALL_HELP = (
    "Tesseract OCR is not installed or is not available on PATH. "
    "Install it first, or pass --tesseract-cmd with the full executable path."
)


STAT_LABELS = [
    "possession",
    "total shots",
    "shots on target",
    "fouls",
    "offsides",
    "corner kicks",
    "free kicks",
    "passes",
    "successful passes",
    "crosses",
    "interceptions",
    "tackles",
    "saves",
    "yellow cards",
    "red cards",
]

STAT_ALIASES = {
    "possession": ["possession"],
    "total shots": ["total shots", "shots"],
    "shots on target": ["shots on target"],
    "fouls": ["fouls", "foul"],
    "offsides": ["offsides", "offsides"],
    "corner kicks": ["corner kicks", "corners", "corner kick"],
    "free kicks": ["free kicks", "free kick"],
    "passes": ["passes", "pass"],
    "successful passes": ["successful passes", "completed passes"],
    "crosses": ["crosses", "cross"],
    "interceptions": ["interceptions", "interception"],
    "tackles": ["tackles", "tackle"],
    "saves": ["saves", "save"],
    "yellow cards": ["yellow cards", "yellow card"],
    "red cards": ["red cards", "red card"],
}

RESULT_KEYWORDS = {
    "Full Time": r"full\s*time",
    "Half Time": r"half\s*time",
    "Extra Time": r"extra\s*time",
    "Penalties": r"penalt",
    "Abandoned": r"abandon",
}

GENERIC_OCR_CONFIGS = [
    "--psm 6",
    "--psm 11",
    "--psm 3",
]

LABEL_OCR_CONFIGS = [
    "--psm 6",
    "--psm 11",
]

NUMBER_OCR_CONFIGS = [
    "--psm 6 -c tessedit_char_whitelist=0123456789%",
    "--psm 11 -c tessedit_char_whitelist=0123456789%",
    "--psm 4 -c tessedit_char_whitelist=0123456789%",
]

NAME_OCR_CONFIGS = [
    "--psm 7",
    "--psm 6",
    "--psm 11",
]

SCORE_BOX_OCR_CONFIGS = [
    "--psm 10 -c tessedit_char_whitelist=0123456789",
    "--psm 13 -c tessedit_char_whitelist=0123456789",
    "--psm 6 -c tessedit_char_whitelist=0123456789",
]

SCORE_PATTERNS = [
    re.compile(
        r"(?P<team1>[A-Za-z][A-Za-z0-9 _\-'&\.]{1,30}?)\s+"
        r"(?P<score1>\d{1,2})\s*[^A-Za-z0-9]{0,6}\s*"
        r"(?P<score2>\d{1,2})\s+"
        r"(?P<team2>[A-Za-z][A-Za-z0-9 _\-'&\.]{1,30})"
    ),
    re.compile(
        r"(?P<team1>[A-Za-z][A-Za-z0-9 _\-'&\.]{1,30}?)\s+"
        r"(?P<score1>\d{1,2})\s+"
        r"(?P<score2>\d{1,2})\s+"
        r"(?P<team2>[A-Za-z][A-Za-z0-9 _\-'&\.]{1,30})"
    ),
]


def read_image(image_path: str) -> np.ndarray:
    """Load an image or raise a friendly file error."""
    img = cv2.imread(image_path)
    if img is None:
        raise FileNotFoundError(f"Could not read image: {image_path}")
    return img


def preprocess_image(image_path: str) -> list[tuple[str, np.ndarray]]:
    """
    Return multiple preprocessed image variants optimized for eFootball's UI.
    The scoreboard usually lives in the upper band, while stats live in the
    center table with white labels and numeric side columns.
    """
    img = read_image(image_path)
    height, width = img.shape[:2]
    variants: list[tuple[str, np.ndarray]] = []

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    variants.append(("gray", gray))

    top = img[: int(height * 0.25), :]
    top_gray = cv2.cvtColor(top, cv2.COLOR_BGR2GRAY)
    top_upscaled = cv2.resize(
        top_gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC
    )
    _, top_thresh = cv2.threshold(
        top_upscaled, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    variants.append(("top_strip_thresh", top_thresh))

    stats_region = img[
        int(height * 0.2) : int(height * 0.92),
        int(width * 0.35) : int(width * 0.72),
    ]
    stats_gray = cv2.cvtColor(stats_region, cv2.COLOR_BGR2GRAY)
    stats_upscaled = cv2.resize(
        stats_gray, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC
    )
    _, stats_thresh = cv2.threshold(
        stats_upscaled, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    variants.append(("stats_centre", stats_thresh))

    left_numbers = img[
        int(height * 0.2) : int(height * 0.92),
        int(width * 0.35) : int(width * 0.46),
    ]
    left_gray = cv2.cvtColor(left_numbers, cv2.COLOR_BGR2GRAY)
    left_upscaled = cv2.resize(
        left_gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC
    )
    _, left_thresh = cv2.threshold(
        left_upscaled, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    variants.append(("left_numbers", left_thresh))

    right_numbers = img[
        int(height * 0.2) : int(height * 0.92),
        int(width * 0.62) : int(width * 0.73),
    ]
    right_gray = cv2.cvtColor(right_numbers, cv2.COLOR_BGR2GRAY)
    right_upscaled = cv2.resize(
        right_gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC
    )
    _, right_thresh = cv2.threshold(
        right_upscaled, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    variants.append(("right_numbers", right_thresh))

    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    yellow_mask = cv2.inRange(hsv, (15, 70, 70), (45, 255, 255))
    yellow_text = cv2.bitwise_and(gray, gray, mask=yellow_mask)
    yellow_upscaled = cv2.resize(
        yellow_text, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC
    )
    variants.append(("yellow_text", yellow_upscaled))

    white_mask = cv2.inRange(hsv, (0, 0, 200), (180, 35, 255))
    white_text = cv2.bitwise_and(gray, gray, mask=white_mask)
    white_upscaled = cv2.resize(
        white_text, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC
    )
    variants.append(("white_text", white_upscaled))

    inverted = cv2.bitwise_not(gray)
    inverted_upscaled = cv2.resize(
        inverted, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC
    )
    _, inverted_thresh = cv2.threshold(
        inverted_upscaled, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    variants.append(("inverted_thresh", inverted_thresh))

    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    variants.append(("clahe", clahe.apply(gray)))

    return variants


def run_ocr_configs(img_variant: np.ndarray, configs: list[str]) -> list[str]:
    """Run OCR with several configs and return unique text blocks."""
    pil_img = Image.fromarray(img_variant)
    blocks: list[str] = []
    seen: set[str] = set()

    for config in configs:
        try:
            text = pytesseract.image_to_string(pil_img, config=config)
        except pytesseract.TesseractNotFoundError as exc:
            raise RuntimeError(TESSERACT_INSTALL_HELP) from exc
        except Exception:
            continue

        normalized = collapse_whitespace(text)
        if normalized and normalized not in seen:
            seen.add(normalized)
            blocks.append(text)

    return blocks


def collapse_whitespace(text: str) -> str:
    """Collapse repeated whitespace for comparisons and display."""
    return re.sub(r"\s+", " ", text).strip()


def normalize_text(text: str) -> str:
    """Normalize OCR text into a lowercase search-friendly form."""
    cleaned = re.sub(r"[^a-z0-9%&]+", " ", text.lower())
    return re.sub(r"\s+", " ", cleaned).strip()


def clean_label(value: str | None) -> str | None:
    """Trim OCR noise from a parsed label without changing its casing."""
    if value is None:
        return None

    cleaned = re.sub(r"\s+", " ", value).strip(" .:-|")
    return cleaned or None


def clean_optional_text(value: object) -> str | None:
    """Convert unknown values into a clean optional string."""
    if not isinstance(value, str):
        return None
    return clean_label(value)


def simplify_competitor_name(value: str | None) -> str | None:
    """Convert a scoreboard label into a cleaner username-like display name."""
    cleaned = clean_label(value)
    if not cleaned:
        return None

    simplified = re.sub(r"\b(?:fc|fe)\b$", "", cleaned, flags=re.IGNORECASE).strip()
    simplified = re.sub(r"\s{2,}", " ", simplified)
    return simplified or cleaned


def extract_projection_runs(
    values: np.ndarray,
    min_value: int,
    min_length: int = 1,
) -> list[tuple[int, int]]:
    """Return inclusive index runs whose values stay above a threshold."""
    runs: list[tuple[int, int]] = []
    start: int | None = None

    for idx, value in enumerate(values.tolist()):
        if value >= min_value and start is None:
            start = idx
        elif value < min_value and start is not None:
            if idx - start >= min_length:
                runs.append((start, idx - 1))
            start = None

    if start is not None and len(values) - start >= min_length:
        runs.append((start, len(values) - 1))

    return runs


def build_yellow_mask(region: np.ndarray) -> np.ndarray:
    """Isolate the bright yellow scoreboard text and score boxes."""
    hsv = cv2.cvtColor(region, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, (15, 70, 70), (45, 255, 255))
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    return cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)


def choose_best_name(candidates: list[str]) -> str | None:
    """Pick the strongest OCR candidate for a username or team name."""
    best_value: str | None = None
    best_score = -1

    for candidate in candidates:
        cleaned = clean_label(candidate)
        if not cleaned:
            continue

        cleaned = re.sub(r"[^A-Za-z0-9 _\-'&\.]+", " ", cleaned)
        cleaned = re.sub(r"(?<=[A-Za-z])\d(?=[A-Za-z])", "", cleaned)
        cleaned = re.sub(r"\s+", " ", cleaned).strip(" .:-|")
        if not cleaned:
            continue
        if normalize_text(cleaned) in {"full time", "half time", "extra time"}:
            continue
        if best_stat_label(cleaned):
            continue

        alpha_count = len(re.findall(r"[A-Za-z]", cleaned))
        if alpha_count < 3:
            continue

        score = (alpha_count * 4) + len(cleaned)
        if " " in cleaned:
            score += 2
        if score > best_score:
            best_score = score
            best_value = cleaned

    return best_value


def extract_name_from_region(region: np.ndarray) -> str | None:
    """OCR a yellow scoreboard name from a left or right header region."""
    gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
    yellow_mask = build_yellow_mask(region)

    up_gray = cv2.resize(gray, None, fx=6, fy=6, interpolation=cv2.INTER_CUBIC)
    _, up_thresh = cv2.threshold(
        up_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    yellow_inv = 255 - cv2.resize(
        yellow_mask, None, fx=6, fy=6, interpolation=cv2.INTER_NEAREST
    )

    candidates: list[str] = []
    for variant in (up_gray, up_thresh, yellow_inv):
        for block in run_ocr_configs(variant, NAME_OCR_CONFIGS):
            candidates.append(block)
            candidates.extend(line for line in block.splitlines() if line.strip())

    return choose_best_name(candidates)


def extract_score_from_region(region: np.ndarray) -> int | None:
    """OCR a score digit from a detected yellow score box."""
    candidates: list[str] = []
    for bottom_trim in (0, 2, 4, 6):
        if bottom_trim >= region.shape[0] - 8:
            continue
        cropped = region[: region.shape[0] - bottom_trim, :]
        gray = cv2.cvtColor(cropped, cv2.COLOR_BGR2GRAY)
        up_gray = cv2.resize(
            gray, None, fx=10, fy=10, interpolation=cv2.INTER_CUBIC
        )
        _, up_thresh = cv2.threshold(
            up_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
        )

        for variant in (up_gray, up_thresh):
            for block in run_ocr_configs(variant, SCORE_BOX_OCR_CONFIGS):
                digits = re.sub(r"\D", "", block)
                if 1 <= len(digits) <= 2:
                    candidates.append(digits)

    if not candidates:
        return None

    best_digits = Counter(candidates).most_common(1)[0][0]
    try:
        return int(best_digits)
    except ValueError:
        return None


def detect_score_box(
    yellow_mask: np.ndarray,
    run: tuple[int, int],
) -> tuple[int, int, int, int] | None:
    """Resolve a score-box x-run into a full crop rectangle inside the header."""
    x1, x2 = run
    column_slice = yellow_mask[:, x1 : x2 + 1]
    y_projection = (column_slice.sum(axis=1) // 255).astype(int)
    min_y_value = max(8, int((x2 - x1 + 1) * 0.55))
    y_runs = extract_projection_runs(
        y_projection,
        min_value=min_y_value,
        min_length=max(10, int(yellow_mask.shape[0] * 0.30)),
    )
    if not y_runs:
        return None

    y1, y2 = max(y_runs, key=lambda item: item[1] - item[0])
    trim_bottom = max(1, int((y2 - y1 + 1) * 0.08))
    return (x1, y1, x2 + 1, max(y1 + 1, y2 + 1 - trim_bottom))


def detect_scoreboard_header(img: np.ndarray) -> dict[str, object]:
    """
    Detect the top scoreboard band and OCR the two names and two score boxes.

    eFootball consistently places the usernames and score boxes in the upper
    yellow-on-navy header, so we treat that region as a first-class OCR target
    instead of relying on full-page OCR alone.
    """
    height, width = img.shape[:2]
    header_x1 = int(width * 0.26)
    header_x2 = int(width * 0.76)
    header_y1 = int(height * 0.08)
    header_y2 = int(height * 0.24)

    header = img[header_y1:header_y2, header_x1:header_x2]
    if header.size == 0:
        return {"detected": False, "regions": {}}

    yellow_mask = build_yellow_mask(header)
    header_height, header_width = yellow_mask.shape[:2]
    x_projection = (yellow_mask.sum(axis=0) // 255).astype(int)

    score_runs = extract_projection_runs(
        x_projection,
        min_value=max(10, int(header_height * 0.30)),
        min_length=max(12, int(header_width * 0.03)),
    )
    if len(score_runs) < 2:
        score_runs = extract_projection_runs(
            x_projection,
            min_value=max(8, int(header_height * 0.24)),
            min_length=max(10, int(header_width * 0.025)),
        )

    if len(score_runs) < 2:
        return {
            "detected": False,
            "regions": {
                "header": [header_x1, header_y1, header_x2, header_y2],
            },
        }

    center = header_width / 2
    score_runs = sorted(
        sorted(
            score_runs,
            key=lambda run: (
                abs(((run[0] + run[1]) / 2) - center),
                -(run[1] - run[0]),
            ),
        )[:2]
    )

    left_box = detect_score_box(yellow_mask, score_runs[0])
    right_box = detect_score_box(yellow_mask, score_runs[1])
    if not left_box or not right_box:
        return {
            "detected": False,
            "regions": {
                "header": [header_x1, header_y1, header_x2, header_y2],
            },
        }

    gap = max(6, int(header_width * 0.01))
    left_name_x1 = max(0, left_box[0] - int(header_width * 0.26))
    left_name_x2 = max(left_name_x1 + 10, left_box[0] - gap)
    right_name_x1 = min(header_width - 10, right_box[2] + gap)
    right_name_x2 = min(header_width, right_name_x1 + int(header_width * 0.30))

    left_name_region = header[:, left_name_x1:left_name_x2]
    right_name_region = header[:, right_name_x1:right_name_x2]
    left_score_region = header[left_box[1] : left_box[3], left_box[0] : left_box[2]]
    right_score_region = header[
        right_box[1] : right_box[3], right_box[0] : right_box[2]
    ]

    team1_label = clean_label(extract_name_from_region(left_name_region))
    team2_label = clean_label(extract_name_from_region(right_name_region))
    score1 = extract_score_from_region(left_score_region)
    score2 = extract_score_from_region(right_score_region)

    header_gray = cv2.cvtColor(header, cv2.COLOR_BGR2GRAY)
    header_text = "\n".join(run_ocr_configs(header_gray, ["--psm 6", "--psm 11"]))

    regions = {
        "header": [header_x1, header_y1, header_x2, header_y2],
        "left_name": [
            header_x1 + left_name_x1,
            header_y1,
            header_x1 + left_name_x2,
            header_y2,
        ],
        "score1": [
            header_x1 + left_box[0],
            header_y1 + left_box[1],
            header_x1 + left_box[2],
            header_y1 + left_box[3],
        ],
        "score2": [
            header_x1 + right_box[0],
            header_y1 + right_box[1],
            header_x1 + right_box[2],
            header_y1 + right_box[3],
        ],
        "right_name": [
            header_x1 + right_name_x1,
            header_y1,
            header_x1 + right_name_x2,
            header_y2,
        ],
    }

    return {
        "detected": bool(team1_label or team2_label or score1 is not None or score2 is not None),
        "team1_label": team1_label,
        "team2_label": team2_label,
        "team1": simplify_competitor_name(team1_label),
        "team2": simplify_competitor_name(team2_label),
        "score1": score1,
        "score2": score2,
        "header_text": header_text,
        "regions": regions,
    }


def extract_text_bundle(image_path: str) -> dict[str, object]:
    """OCR all variants and keep both merged and region-specific text."""
    variants = preprocess_image(image_path)
    variant_lookup = {name: img for name, img in variants}

    bundle: dict[str, object] = {}
    merged_blocks: list[str] = []
    merged_seen: set[str] = set()

    for name, img_variant in variants:
        blocks = run_ocr_configs(img_variant, GENERIC_OCR_CONFIGS)
        bundle[name] = "\n".join(blocks)
        for block in blocks:
            normalized = collapse_whitespace(block)
            if normalized and normalized not in merged_seen:
                merged_seen.add(normalized)
                merged_blocks.append(block)

    bundle["left_numbers_numeric"] = "\n".join(
        run_ocr_configs(variant_lookup["left_numbers"], NUMBER_OCR_CONFIGS)
    )
    bundle["right_numbers_numeric"] = "\n".join(
        run_ocr_configs(variant_lookup["right_numbers"], NUMBER_OCR_CONFIGS)
    )
    bundle["stats_centre_labels"] = "\n".join(
        run_ocr_configs(variant_lookup["stats_centre"], LABEL_OCR_CONFIGS)
    )
    bundle["white_text_labels"] = "\n".join(
        run_ocr_configs(variant_lookup["white_text"], LABEL_OCR_CONFIGS)
    )
    bundle["raw_text"] = "\n".join(merged_blocks)
    bundle["header_detection"] = detect_scoreboard_header(read_image(image_path))
    return bundle


def clean_team_name(value: str | None) -> str | None:
    """Normalize extracted names without overcorrecting OCR output."""
    cleaned = clean_label(value)
    if not cleaned:
        return None

    cleaned = re.sub(r"(?<=[A-Za-z])\d(?=[A-Za-z])", "", cleaned)
    normalized = normalize_text(cleaned)
    if not normalized:
        return None

    if best_stat_label(cleaned):
        return None

    return cleaned


def find_score_and_teams(bundle: dict[str, object]) -> dict[str, int | str | None]:
    """
    Parse the scoreline from the header area.
    eFootball often renders: TeamName 1 [logo] 4 TeamName
    """
    header_info = bundle.get("header_detection")
    if isinstance(header_info, dict):
        header_team1 = clean_team_name(clean_optional_text(header_info.get("team1")))
        header_team2 = clean_team_name(clean_optional_text(header_info.get("team2")))
        header_label1 = clean_team_name(clean_optional_text(header_info.get("team1_label")))
        header_label2 = clean_team_name(clean_optional_text(header_info.get("team2_label")))
        score1 = header_info.get("score1")
        score2 = header_info.get("score2")

        if (
            isinstance(score1, int)
            and isinstance(score2, int)
            and (header_team1 or header_label1)
            and (header_team2 or header_label2)
        ):
            return {
                "team1": header_team1 or header_label1,
                "team1_label": header_label1 or header_team1,
                "score1": score1,
                "team2": header_team2 or header_label2,
                "team2_label": header_label2 or header_team2,
                "score2": score2,
            }

    result: dict[str, int | str | None] = {
        "team1": None,
        "team1_label": None,
        "score1": None,
        "team2": None,
        "team2_label": None,
        "score2": None,
    }

    search_blocks = [
        str(bundle.get("top_strip_thresh") or ""),
        str(bundle.get("yellow_text") or ""),
        str(bundle.get("raw_text") or ""),
    ]
    if isinstance(header_info, dict):
        search_blocks.insert(0, str(header_info.get("header_text") or ""))

    searchable_lines: list[str] = []
    for block in search_blocks:
        if not block:
            continue
        searchable_lines.extend(
            line.strip() for line in block.splitlines() if line.strip()
        )
        condensed = collapse_whitespace(block)
        if condensed:
            searchable_lines.append(condensed)

    for line in searchable_lines:
        for pattern in SCORE_PATTERNS:
            match = pattern.search(line)
            if not match:
                continue

            label1 = clean_team_name(match.group("team1"))
            label2 = clean_team_name(match.group("team2"))
            if not label1 or not label2:
                continue

            result["team1_label"] = label1
            result["team1"] = simplify_competitor_name(label1) or label1
            result["score1"] = int(match.group("score1"))
            result["score2"] = int(match.group("score2"))
            result["team2_label"] = label2
            result["team2"] = simplify_competitor_name(label2) or label2
            return result

    raw_text = str(bundle.get("raw_text") or "")
    score_candidates = re.findall(r"\b(\d{1,2})\b", raw_text)
    name_candidates = re.findall(r"\b([A-Z][A-Za-z0-9 ]{2,24})\b", raw_text)

    if len(score_candidates) >= 2:
        result["score1"] = int(score_candidates[0])
        result["score2"] = int(score_candidates[1])

    cleaned_names: list[str] = []
    seen: set[str] = set()
    for candidate in name_candidates:
        team_label = clean_team_name(candidate)
        if not team_label or team_label in seen:
            continue
        seen.add(team_label)
        cleaned_names.append(team_label)
        if len(cleaned_names) == 2:
            break

    if cleaned_names:
        result["team1_label"] = cleaned_names[0]
        result["team1"] = simplify_competitor_name(cleaned_names[0]) or cleaned_names[0]
    if len(cleaned_names) > 1:
        result["team2_label"] = cleaned_names[1]
        result["team2"] = simplify_competitor_name(cleaned_names[1]) or cleaned_names[1]

    return result


def find_match_period(text: str) -> str:
    """Detect Full Time, Half Time, Extra Time, and related result states."""
    searchable = normalize_text(text)
    for label, pattern in RESULT_KEYWORDS.items():
        if re.search(pattern, searchable):
            return label
    return "Full Time"


def best_stat_label(text: str) -> str | None:
    """Return the best-matching known stat label for an OCR line."""
    normalized = normalize_text(re.sub(r"\b\d+%?\b", " ", text))
    if not normalized:
        return None

    for canonical, aliases in STAT_ALIASES.items():
        for alias in aliases:
            if alias in normalized or normalized in alias:
                return canonical

    best_label: str | None = None
    best_score = 0.0

    for canonical, aliases in STAT_ALIASES.items():
        score = max(
            SequenceMatcher(None, normalized, alias).ratio() for alias in aliases
        )
        if score > best_score:
            best_score = score
            best_label = canonical

    if best_label and best_score >= 0.72:
        return best_label
    return None


def extract_column_values(text: str) -> list[str]:
    """Extract ordered numeric values from a left or right stats column."""
    values: list[str] = []

    for line in text.splitlines():
        line_values = re.findall(r"\b(\d+%?)\b", line)
        if not line_values:
            continue
        values.extend(line_values)

    if values:
        return values

    return re.findall(r"\b(\d+%?)\b", text)


def extract_labels_in_order(bundle: dict[str, object]) -> list[str]:
    """Read center-label OCR and return stat labels in screen order."""
    labels: list[str] = []
    seen: set[str] = set()
    label_sources = [
        str(bundle.get("stats_centre_labels") or ""),
        str(bundle.get("white_text_labels") or ""),
        str(bundle.get("stats_centre") or ""),
        str(bundle.get("raw_text") or ""),
    ]

    for source in label_sources:
        for line in source.splitlines():
            label = best_stat_label(line)
            if not label or label in seen:
                continue
            seen.add(label)
            labels.append(label)

    return labels


def _scan_nearby_value(
    lines: list[str],
    idx: int,
    direction: int,
    window: int = 2,
) -> str | None:
    """Scan nearby OCR lines for a numeric value when a line only has a label."""
    for offset in range(1, window + 1):
        target = idx + (direction * offset)
        if 0 <= target < len(lines):
            match = re.search(r"\b(\d+%?)\b", lines[target])
            if match:
                return match.group(1)
    return None


def find_inline_stat_values(text: str, label: str) -> dict[str, str] | None:
    """Fallback extraction when ordered column OCR is incomplete."""
    lines = [line.strip() for line in text.splitlines() if line.strip()]

    for idx, line in enumerate(lines):
        best_label = best_stat_label(line)
        if best_label != label:
            continue

        values = re.findall(r"\b(\d+%?)\b", line)
        if len(values) >= 2:
            return {"left": values[0], "right": values[-1]}

        left_value = _scan_nearby_value(lines, idx, direction=-1)
        right_value = _scan_nearby_value(lines, idx, direction=1)
        if values:
            return {
                "left": left_value or values[0],
                "right": right_value or "?",
            }
        if left_value or right_value:
            return {
                "left": left_value or "?",
                "right": right_value or "?",
            }

    return None


def find_stats(bundle: dict[str, object]) -> dict[str, dict[str, str]]:
    """
    Extract match statistics from the eFootball stats table.
    Uses the dedicated left and right numeric columns first, then falls back
    to searching the merged OCR text around recognized stat labels.
    """
    stats: dict[str, dict[str, str]] = {}
    ordered_labels = extract_labels_in_order(bundle)

    left_values = extract_column_values(str(bundle.get("left_numbers_numeric") or ""))
    right_values = extract_column_values(str(bundle.get("right_numbers_numeric") or ""))

    for index, label in enumerate(ordered_labels):
        left_value = left_values[index] if index < len(left_values) else None
        right_value = right_values[index] if index < len(right_values) else None
        if not left_value and not right_value:
            continue
        stats[label] = {
            "left": left_value or "?",
            "right": right_value or "?",
        }

    raw_text = str(bundle.get("raw_text") or "")
    for label in STAT_LABELS:
        if label in stats:
            continue
        inline_values = find_inline_stat_values(raw_text, label)
        if inline_values:
            stats[label] = inline_values

    return stats


def determine_winner(
    team1: str | None,
    score1: int | None,
    team2: str | None,
    score2: int | None,
) -> dict[str, int | str | None]:
    """Return winner, loser, and goal margin from the parsed score."""
    if score1 is None or score2 is None:
        return {"winner": None, "loser": None, "margin": None}

    if score1 > score2:
        return {"winner": team1, "loser": team2, "margin": score1 - score2}
    if score2 > score1:
        return {"winner": team2, "loser": team1, "margin": score2 - score1}
    return {"winner": "Draw", "loser": "Draw", "margin": 0}


def matches_candidate(needle: str | None, haystack: str | None) -> bool:
    """Tolerant string comparison for usernames and team names."""
    if not needle or not haystack:
        return False

    normalized_needle = normalize_text(needle)
    normalized_haystack = normalize_text(haystack)
    if not normalized_needle or not normalized_haystack:
        return False

    return (
        normalized_needle == normalized_haystack
        or normalized_needle in normalized_haystack
        or normalized_haystack in normalized_needle
    )


def find_user_team(
    username: str | None,
    team_input: str | None,
    team1: str | None,
    team2: str | None,
    team1_label: str | None = None,
    team2_label: str | None = None,
) -> str | None:
    """Determine which parsed competitor belongs to the requested player."""
    options = [
        (team1, team1_label),
        (team2, team2_label),
    ]

    for candidate in (team_input, username):
        for primary, secondary in options:
            if matches_candidate(candidate, primary) or matches_candidate(candidate, secondary):
                return primary or secondary
    return None


def user_found_in_text(username: str | None, raw_text: str) -> bool:
    """Check whether the requested username appears anywhere in OCR output."""
    if not username:
        return False
    return normalize_text(username) in normalize_text(raw_text)


def build_announcement(
    team1: str | None,
    score1: int | None,
    team2: str | None,
    score2: int | None,
    period: str,
    winner_info: dict[str, int | str | None],
    username: str | None = None,
    user_team: str | None = None,
    user_detected: bool = False,
) -> str:
    """Build a natural-language announcement for the parsed result."""
    left_team = team1 or "Team 1"
    right_team = team2 or "Team 2"
    left_score = score1 if score1 is not None else "?"
    right_score = score2 if score2 is not None else "?"
    winner = winner_info.get("winner")
    loser = winner_info.get("loser")
    margin = winner_info.get("margin")

    score_text = f"{left_score} - {right_score}"
    margin_text = ""
    if isinstance(margin, int) and margin > 0:
        suffix = "goal" if margin == 1 else "goals"
        margin_text = f" by {margin} {suffix}"

    if winner == "Draw":
        base = f"It ends {score_text} at {period}. The points are shared."
    elif winner:
        base = f"{winner} wins {score_text} at {period}{margin_text}."
        if loser:
            base += f" {loser} falls short."
    else:
        base = f"Match result: {left_team} {left_score} - {right_score} {right_team} at {period}."

    if username and user_team:
        user_won = user_team == winner
        user_drew = winner == "Draw"
        if user_drew:
            return (
                f"It's a draw, {username}. Your team ({user_team}) shares the points "
                f"at {score_text}."
            )
        if user_won:
            return (
                f"Strong result, {username}. Your team ({user_team}) wins "
                f"{score_text}{margin_text} at {period}."
            )

        opponent = right_team if user_team == left_team else left_team
        return (
            f"Tough one, {username}. Your team ({user_team}) loses "
            f"{score_text}{margin_text} at {period}. {opponent} takes the win."
        )

    if username and user_detected:
        return f"{base} I found {username} in the screenshot, but could not map them to a team."

    return base


def build_match_status(user_result: str | None, winner: str | None) -> str:
    """Return a user-friendly status label for UI and module consumers."""
    if user_result:
        return user_result
    if winner == "Draw":
        return "Draw"
    if winner:
        return "Winner detected"
    return "Unknown"


def build_scoreline(score1: object, score2: object) -> str:
    """Build a scoreline string from parsed scores."""
    if score1 is None or score2 is None:
        return "Unknown"
    return f"{score1} - {score2}"


def announce_result(
    image_path: str,
    username: str | None = None,
    team: str | None = None,
) -> dict[str, object]:
    """Full OCR pipeline: preprocess, extract, parse, and announce."""
    bundle = extract_text_bundle(image_path)
    raw_text = str(bundle.get("raw_text") or "")
    teams = find_score_and_teams(bundle)
    period = find_match_period(raw_text)
    stats = find_stats(bundle)
    header_info = bundle.get("header_detection")

    team1 = clean_optional_text(teams.get("team1"))
    team2 = clean_optional_text(teams.get("team2"))
    team1_label = clean_optional_text(teams.get("team1_label")) or team1
    team2_label = clean_optional_text(teams.get("team2_label")) or team2
    score1 = teams.get("score1")
    score2 = teams.get("score2")

    winner_info = determine_winner(team1, score1, team2, score2)
    user_team = find_user_team(
        username,
        team,
        team1,
        team2,
        team1_label=team1_label,
        team2_label=team2_label,
    )
    user_detected = user_found_in_text(username, raw_text)
    announcement = build_announcement(
        team1,
        score1,
        team2,
        score2,
        period,
        winner_info,
        username=username,
        user_team=user_team,
        user_detected=user_detected,
    )

    user_result: str | None = None
    winner = winner_info.get("winner")
    if user_team and winner:
        if winner == "Draw":
            user_result = "Drew"
        elif user_team == winner:
            user_result = "Won"
        else:
            user_result = "Lost"

    confidence = "High"
    if team1 is None or score1 is None or team2 is None or score2 is None:
        confidence = "Low"
    elif not stats or len(stats) < max(4, len(STAT_LABELS) // 2):
        confidence = "Medium"

    scoreboard_regions: dict[str, object] = {}
    header_detected = False
    if isinstance(header_info, dict):
        scoreboard_regions = dict(header_info.get("regions") or {})
        header_detected = bool(header_info.get("detected"))

    return {
        "image_path": image_path,
        "team1": team1,
        "team1_label": team1_label,
        "score1": score1,
        "team2": team2,
        "team2_label": team2_label,
        "score2": score2,
        "period": period,
        "winner": winner,
        "loser": winner_info.get("loser"),
        "margin": winner_info.get("margin"),
        "stats": stats,
        "queried_username": username,
        "queried_team": team,
        "user_team": user_team,
        "user_result": user_result,
        "user_detected": "Yes" if user_detected else None,
        "announcement": announcement,
        "confidence": confidence,
        "raw_text": raw_text,
        "analysis_engine": "ocr",
        "scoreline": build_scoreline(score1, score2),
        "match_status": build_match_status(
            user_result,
            winner if isinstance(winner, str) else None,
        ),
        "header_detected": header_detected,
        "scoreboard_regions": scoreboard_regions,
    }


def analyze_match_result(
    image_path: str,
    username: str | None = None,
    team: str | None = None,
    **_ignored: object,
) -> dict[str, object]:
    """
    Public reusable API for other apps.

    Extra keyword arguments are ignored so older callers do not crash after the
    OCR-only cleanup.
    """
    return announce_result(image_path, username=username, team=team)


def print_result(data: dict[str, object], show_raw: bool = False) -> None:
    """Print the parsed result in a readable terminal format."""
    reset = "\033[0m"
    bold = "\033[1m"
    green = "\033[92m"
    red = "\033[91m"
    yellow = "\033[93m"
    cyan = "\033[96m"
    white = "\033[97m"

    winner = data.get("winner")
    user_result = data.get("user_result")

    if user_result == "Won" or (
        not data.get("queried_username") and winner and winner != "Draw"
    ):
        banner_color = green
    elif user_result == "Lost":
        banner_color = red
    elif user_result == "Drew" or winner == "Draw":
        banner_color = yellow
    else:
        banner_color = white

    print(f"\n{bold}{'=' * 60}{reset}")
    print(
        f"{banner_color}{bold}  eFOOTBALL - MATCH RESULT "
        f"({str(data.get('period') or 'FULL TIME').upper()}){reset}"
    )
    print(f"{bold}{'=' * 60}{reset}")

    team1 = data.get("team1") or "Team 1"
    team2 = data.get("team2") or "Team 2"
    score1 = data.get("score1") if data.get("score1") is not None else "?"
    score2 = data.get("score2") if data.get("score2") is not None else "?"

    print(f"\n  Left:   {str(team1):<22} {score1:>3}  vs  {score2:<3} {team2}")
    print(f"  Status: {data.get('match_status') or 'Unknown'}")
    print(f"  Engine: {data.get('analysis_engine') or 'ocr'}")

    team1_label = data.get("team1_label")
    team2_label = data.get("team2_label")
    if team1_label and team1_label != team1:
        print(f"  Left label:  {team1_label}")
    if team2_label and team2_label != team2:
        print(f"  Right label: {team2_label}")

    if winner and winner != "Draw":
        winner_line = f"\n  Winner: {banner_color}{bold}{winner}{reset}"
        if data.get("margin"):
            goal_label = "goal" if data["margin"] == 1 else "goals"
            winner_line += f"  (+{data['margin']} {goal_label})"
        print(winner_line)
    elif winner == "Draw":
        print(f"\n  Result: {yellow}{bold}Draw{reset}")

    if data.get("queried_username") or data.get("queried_team"):
        label = data.get("queried_username") or data.get("queried_team")
        print(f"\n  Player: {cyan}{bold}{label}{reset}", end="")
        if data.get("user_team"):
            print(f"  ->  {data['user_team']}", end="")
        elif data.get("user_detected"):
            print("  ->  found in image, team unclear", end="")
        print()

        if data.get("user_result"):
            outcome_color = (
                green
                if data["user_result"] == "Won"
                else red
                if data["user_result"] == "Lost"
                else yellow
            )
            print(f"  Result: {outcome_color}{bold}{data['user_result']}{reset}")

    stats = data.get("stats")
    if isinstance(stats, dict) and stats:
        short_team1 = str(team1)[:12]
        short_team2 = str(team2)[:12]
        print(f"\n  {'-' * 54}")
        print(f"  {'STAT':<22}  {short_team1:>12}  {short_team2:<12}")
        print(f"  {'-' * 54}")
        for label, values in stats.items():
            if not isinstance(values, dict):
                continue
            left_value = values.get("left", "?")
            right_value = values.get("right", "?")
            print(f"  {label.title():<22}  {left_value:>12}  {right_value:<12}")
        print(f"  {'-' * 54}")

    if data.get("scoreboard_regions"):
        print(f"\n  Scoreboard regions: {data['scoreboard_regions']}")

    print(f"\n{'-' * 60}")
    print(f"  {bold}{data['announcement']}{reset}")
    print(f"{'-' * 60}")

    confidence = str(data.get("confidence") or "Unknown")
    confidence_color = (
        green if confidence == "High" else yellow if confidence == "Medium" else red
    )
    print(f"\n  Confidence: {confidence_color}{confidence}{reset}")

    if show_raw:
        raw_text = str(data.get("raw_text") or "")
        print(f"\n  Raw OCR text:\n{raw_text[:1200]}")

    print(f"\n{bold}{'=' * 60}{reset}\n")


def parse_args() -> argparse.Namespace:
    """Build and parse CLI arguments."""
    parser = argparse.ArgumentParser(
        description="Announce eFootball results and stats from screenshots using OCR",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python efootball_result_ocr.py --image result.jpg
  python efootball_result_ocr.py --image result.jpg --username "I clear ball"
  python efootball_result_ocr.py --image result.jpg --team "United"
  python efootball_result_ocr.py --image result.jpg --team "United" --debug
        """,
    )
    parser.add_argument("--image", required=True, help="Path to the eFootball screenshot")
    parser.add_argument("--username", help="Your in-game username (optional)")
    parser.add_argument("--team", help="Your club or team name (optional)")
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Show raw OCR text output",
    )
    parser.add_argument(
        "--tesseract-cmd",
        help="Optional full path to the tesseract executable",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    if args.tesseract_cmd:
        pytesseract.pytesseract.tesseract_cmd = args.tesseract_cmd

    image_path = Path(args.image)
    if not image_path.exists():
        print(f"Image not found: {args.image}")
        sys.exit(1)

    print(f"Reading: {args.image}")
    if args.username:
        print(f"Player:  {args.username}")
    if args.team:
        print(f"Team:    {args.team}")
    print("Running OCR analysis...\n")

    try:
        data = analyze_match_result(
            str(image_path),
            username=args.username,
            team=args.team,
        )
        print_result(data, show_raw=args.debug)
    except FileNotFoundError as exc:
        print(exc)
        sys.exit(1)
    except RuntimeError as exc:
        print(exc)
        sys.exit(1)
    except Exception as exc:
        print(f"Error: {exc}")
        sys.exit(1)


if __name__ == "__main__":
    main()
