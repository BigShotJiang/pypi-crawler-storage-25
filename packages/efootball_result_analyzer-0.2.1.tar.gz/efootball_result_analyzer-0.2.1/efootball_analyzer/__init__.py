"""Import-friendly package facade for the OCR-only eFootball analyzer."""

from efootball_result_ocr import (
    TESSERACT_INSTALL_HELP,
    analyze_match_result,
    announce_result,
    print_result,
)

__all__ = [
    "TESSERACT_INSTALL_HELP",
    "analyze_match_result",
    "announce_result",
    "print_result",
]

__version__ = "0.2.1"
