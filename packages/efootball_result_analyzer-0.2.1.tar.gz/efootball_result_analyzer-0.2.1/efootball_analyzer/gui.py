"""GUI exports for consumers that want the desktop uploader."""

from efootball_result_gui import EFootballResultGUI, main

__all__ = ["EFootballResultGUI", "main"]
