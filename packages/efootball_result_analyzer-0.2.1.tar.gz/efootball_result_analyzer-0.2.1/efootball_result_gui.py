"""
Simple desktop GUI for analyzing eFootball match result screenshots with OCR.

Requirements:
    pip install pytesseract pillow opencv-python

Run:
    python3 efootball_result_gui.py
"""

from __future__ import annotations

import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import pytesseract
from PIL import Image, ImageTk, UnidentifiedImageError

from efootball_result_ocr import TESSERACT_INSTALL_HELP, analyze_match_result


class EFootballResultGUI(tk.Tk):
    """Simple upload-based GUI for eFootball OCR result analysis."""

    def __init__(self) -> None:
        super().__init__()

        self.title("eFootball Match Result Analyzer")
        self.geometry("1180x780")
        self.minsize(980, 680)

        self.image_path_var = tk.StringVar()
        self.username_var = tk.StringVar()
        self.team_var = tk.StringVar()
        self.tesseract_path_var = tk.StringVar()
        self.status_var = tk.StringVar(
            value="Choose an eFootball result screenshot, then click Analyze."
        )

        self.result_vars: dict[str, tk.StringVar] = {
            "status": tk.StringVar(value="-"),
            "period": tk.StringVar(value="-"),
            "scoreline": tk.StringVar(value="-"),
            "left_side": tk.StringVar(value="-"),
            "right_side": tk.StringVar(value="-"),
            "winner": tk.StringVar(value="-"),
            "loser": tk.StringVar(value="-"),
            "margin": tk.StringVar(value="-"),
            "queried_user": tk.StringVar(value="-"),
            "queried_team": tk.StringVar(value="-"),
            "detected_side": tk.StringVar(value="-"),
            "confidence": tk.StringVar(value="-"),
            "analysis_engine": tk.StringVar(value="-"),
            "header_regions": tk.StringVar(value="-"),
        }

        self.preview_image: ImageTk.PhotoImage | None = None
        self.preview_label: ttk.Label | None = None
        self.announcement_text: tk.Text | None = None
        self.analyze_button: ttk.Button | None = None
        self.stats_tree: ttk.Treeview | None = None
        self.raw_text: tk.Text | None = None

        self._configure_styles()
        self._build_ui()

    def _configure_styles(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("Title.TLabel", font=("Helvetica", 18, "bold"))
        style.configure("Section.TLabelframe.Label", font=("Helvetica", 11, "bold"))
        style.configure("FieldName.TLabel", font=("Helvetica", 10, "bold"))
        style.configure("Status.TLabel", font=("Helvetica", 10))

    def _build_ui(self) -> None:
        container = ttk.Frame(self, padding=16)
        container.pack(fill="both", expand=True)

        container.columnconfigure(0, weight=1)
        container.rowconfigure(2, weight=1)

        header = ttk.Frame(container)
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)

        ttk.Label(header, text="eFootball Match Result Analyzer", style="Title.TLabel").grid(
            row=0,
            column=0,
            sticky="w",
        )
        ttk.Label(
            header,
            text="Upload an eFootball result screenshot and inspect scoreline, winner, loser, stats, and detected scoreboard regions.",
        ).grid(row=1, column=0, sticky="w", pady=(4, 0))

        controls = ttk.LabelFrame(container, text="Inputs", style="Section.TLabelframe")
        controls.grid(row=1, column=0, sticky="ew", pady=(16, 12))
        controls.columnconfigure(1, weight=1)
        controls.columnconfigure(3, weight=1)
        controls.columnconfigure(5, weight=1)

        ttk.Label(controls, text="Screenshot", style="FieldName.TLabel").grid(
            row=0,
            column=0,
            sticky="w",
            padx=(12, 8),
            pady=(12, 8),
        )
        ttk.Entry(
            controls,
            textvariable=self.image_path_var,
            state="readonly",
        ).grid(row=0, column=1, columnspan=4, sticky="ew", pady=(12, 8))
        ttk.Button(controls, text="Browse", command=self.choose_image).grid(
            row=0,
            column=5,
            sticky="ew",
            padx=(8, 12),
            pady=(12, 8),
        )

        ttk.Label(controls, text="Username", style="FieldName.TLabel").grid(
            row=1,
            column=0,
            sticky="w",
            padx=(12, 8),
            pady=8,
        )
        ttk.Entry(controls, textvariable=self.username_var).grid(
            row=1,
            column=1,
            sticky="ew",
            pady=8,
        )

        ttk.Label(controls, text="Team or club", style="FieldName.TLabel").grid(
            row=1,
            column=2,
            sticky="w",
            padx=(16, 8),
            pady=8,
        )
        ttk.Entry(controls, textvariable=self.team_var).grid(
            row=1,
            column=3,
            sticky="ew",
            pady=8,
        )

        ttk.Label(controls, text="Tesseract path", style="FieldName.TLabel").grid(
            row=1,
            column=4,
            sticky="w",
            padx=(16, 8),
            pady=8,
        )
        ttk.Entry(controls, textvariable=self.tesseract_path_var).grid(
            row=1,
            column=5,
            sticky="ew",
            pady=8,
            padx=(0, 12),
        )

        ttk.Label(
            controls,
            text="The analyzer reads the top scoreboard band first so names and scores come from the actual result header.",
        ).grid(row=2, column=0, columnspan=6, sticky="w", padx=12, pady=(0, 8))

        actions = ttk.Frame(controls)
        actions.grid(row=3, column=0, columnspan=6, sticky="ew", padx=12, pady=(0, 12))
        actions.columnconfigure(3, weight=1)

        self.analyze_button = ttk.Button(actions, text="Analyze", command=self.start_analysis)
        self.analyze_button.grid(row=0, column=0, sticky="w")
        ttk.Button(actions, text="Locate Tesseract", command=self.choose_tesseract).grid(
            row=0,
            column=1,
            sticky="w",
            padx=(8, 0),
        )
        ttk.Button(actions, text="Clear", command=self.clear_all).grid(
            row=0,
            column=2,
            sticky="w",
            padx=(8, 0),
        )
        ttk.Label(actions, textvariable=self.status_var, style="Status.TLabel").grid(
            row=0,
            column=3,
            sticky="e",
            padx=(12, 0),
        )

        content = ttk.Frame(container)
        content.grid(row=2, column=0, sticky="nsew")
        content.columnconfigure(0, weight=1)
        content.columnconfigure(1, weight=1)
        content.rowconfigure(0, weight=1)

        preview_frame = ttk.LabelFrame(
            content,
            text="Screenshot Preview",
            style="Section.TLabelframe",
        )
        preview_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        preview_frame.columnconfigure(0, weight=1)
        preview_frame.rowconfigure(0, weight=1)

        self.preview_label = ttk.Label(
            preview_frame,
            text="No image selected",
            anchor="center",
            justify="center",
        )
        self.preview_label.grid(row=0, column=0, sticky="nsew", padx=12, pady=12)

        right_panel = ttk.Frame(content)
        right_panel.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        right_panel.columnconfigure(0, weight=1)
        right_panel.rowconfigure(1, weight=1)
        right_panel.rowconfigure(2, weight=1)

        results_frame = ttk.LabelFrame(
            right_panel,
            text="Match Analysis",
            style="Section.TLabelframe",
        )
        results_frame.grid(row=0, column=0, sticky="ew")
        results_frame.columnconfigure(1, weight=1)

        result_fields = [
            ("Status", "status"),
            ("Match period", "period"),
            ("Scoreline", "scoreline"),
            ("Left username/team", "left_side"),
            ("Right username/team", "right_side"),
            ("Winner", "winner"),
            ("Loser", "loser"),
            ("Goal margin", "margin"),
            ("Queried username", "queried_user"),
            ("Queried team", "queried_team"),
            ("Detected side", "detected_side"),
            ("Confidence", "confidence"),
            ("Analysis engine", "analysis_engine"),
            ("Header regions", "header_regions"),
        ]

        for row_index, (label_text, key) in enumerate(result_fields):
            ttk.Label(results_frame, text=label_text, style="FieldName.TLabel").grid(
                row=row_index,
                column=0,
                sticky="nw",
                padx=(12, 10),
                pady=5,
            )
            ttk.Label(
                results_frame,
                textvariable=self.result_vars[key],
                wraplength=390,
                justify="left",
            ).grid(row=row_index, column=1, sticky="nw", padx=(0, 12), pady=5)

        ttk.Label(results_frame, text="Announcement", style="FieldName.TLabel").grid(
            row=len(result_fields),
            column=0,
            sticky="nw",
            padx=(12, 10),
            pady=(10, 6),
        )
        self.announcement_text = tk.Text(
            results_frame,
            height=5,
            wrap="word",
            relief="solid",
            borderwidth=1,
        )
        self.announcement_text.grid(
            row=len(result_fields),
            column=1,
            sticky="ew",
            padx=(0, 12),
            pady=(10, 12),
        )
        self.announcement_text.insert("1.0", "Analysis will appear here.")
        self.announcement_text.configure(state="disabled")

        stats_frame = ttk.LabelFrame(
            right_panel,
            text="Match Stats",
            style="Section.TLabelframe",
        )
        stats_frame.grid(row=1, column=0, sticky="nsew", pady=(12, 12))
        stats_frame.columnconfigure(0, weight=1)
        stats_frame.rowconfigure(0, weight=1)

        self.stats_tree = ttk.Treeview(
            stats_frame,
            columns=("stat", "left", "right"),
            show="headings",
            height=9,
        )
        self.stats_tree.heading("stat", text="Stat")
        self.stats_tree.heading("left", text="Left side")
        self.stats_tree.heading("right", text="Right side")
        self.stats_tree.column("stat", width=180, anchor="w")
        self.stats_tree.column("left", width=100, anchor="center")
        self.stats_tree.column("right", width=100, anchor="center")
        self.stats_tree.grid(row=0, column=0, sticky="nsew", padx=(12, 0), pady=12)

        stats_scroll = ttk.Scrollbar(
            stats_frame,
            orient="vertical",
            command=self.stats_tree.yview,
        )
        stats_scroll.grid(row=0, column=1, sticky="ns", padx=(0, 12), pady=12)
        self.stats_tree.configure(yscrollcommand=stats_scroll.set)

        raw_frame = ttk.LabelFrame(
            right_panel,
            text="Raw OCR Text",
            style="Section.TLabelframe",
        )
        raw_frame.grid(row=2, column=0, sticky="nsew")
        raw_frame.columnconfigure(0, weight=1)
        raw_frame.rowconfigure(0, weight=1)

        self.raw_text = tk.Text(
            raw_frame,
            height=10,
            wrap="word",
            relief="solid",
            borderwidth=1,
        )
        self.raw_text.grid(row=0, column=0, sticky="nsew", padx=(12, 0), pady=12)
        self.raw_text.insert("1.0", "Raw OCR output will appear here.")
        self.raw_text.configure(state="disabled")

        raw_scroll = ttk.Scrollbar(raw_frame, orient="vertical", command=self.raw_text.yview)
        raw_scroll.grid(row=0, column=1, sticky="ns", padx=(0, 12), pady=12)
        self.raw_text.configure(yscrollcommand=raw_scroll.set)

    def choose_image(self) -> None:
        path = filedialog.askopenfilename(
            title="Choose an eFootball result screenshot",
            filetypes=[
                ("Image files", "*.png *.jpg *.jpeg *.webp *.bmp"),
                ("All files", "*.*"),
            ],
        )
        if not path:
            return

        self.image_path_var.set(path)
        self.status_var.set("Image selected. Ready to analyze.")
        self._load_preview(path)

    def choose_tesseract(self) -> None:
        path = filedialog.askopenfilename(
            title="Locate the Tesseract executable",
            filetypes=[
                ("Executable", "*.exe"),
                ("All files", "*.*"),
            ],
        )
        if path:
            self.tesseract_path_var.set(path)

    def _load_preview(self, image_path: str) -> None:
        if not self.preview_label:
            return

        try:
            image = Image.open(image_path)
            image.thumbnail((460, 460))
            self.preview_image = ImageTk.PhotoImage(image)
            self.preview_label.configure(image=self.preview_image, text="")
        except (FileNotFoundError, UnidentifiedImageError, OSError) as exc:
            self.preview_image = None
            self.preview_label.configure(image="", text=f"Unable to preview image.\n{exc}")

    def start_analysis(self) -> None:
        image_path = self.image_path_var.get().strip()
        if not image_path:
            messagebox.showwarning("Missing screenshot", "Please choose an image first.")
            return

        if not Path(image_path).exists():
            messagebox.showerror("File not found", "The selected image could not be found.")
            return

        tesseract_path = self.tesseract_path_var.get().strip()
        if tesseract_path and not Path(tesseract_path).exists():
            messagebox.showerror(
                "Invalid Tesseract path",
                "The Tesseract executable path does not exist.",
            )
            return

        self._set_busy(True)
        self.status_var.set("Running OCR analysis...")
        self._set_announcement("Analyzing screenshot. This may take a few seconds.")
        self._set_raw_text("Collecting OCR output...")

        worker = threading.Thread(
            target=self._run_analysis,
            args=(
                image_path,
                self.username_var.get().strip() or None,
                self.team_var.get().strip() or None,
                tesseract_path or None,
            ),
            daemon=True,
        )
        worker.start()

    def _run_analysis(
        self,
        image_path: str,
        username: str | None,
        team: str | None,
        tesseract_path: str | None,
    ) -> None:
        try:
            if tesseract_path:
                pytesseract.pytesseract.tesseract_cmd = tesseract_path

            data = analyze_match_result(
                image_path,
                username=username,
                team=team,
            )
        except Exception as exc:
            self.after(0, self._show_error, str(exc))
            return

        self.after(0, self._render_result, data)

    def _render_result(self, data: dict[str, object]) -> None:
        winner = str(data.get("winner") or "")
        user_result = str(data.get("user_result") or "")
        score1 = data.get("score1")
        score2 = data.get("score2")
        scoreline = (
            f"{score1} - {score2}"
            if score1 is not None and score2 is not None
            else "Unknown"
        )

        if user_result:
            status = user_result
        elif winner == "Draw":
            status = "Draw"
        elif winner:
            status = "Winner detected"
        else:
            status = "Unknown"

        margin = data.get("margin")
        margin_text = f"{margin} goal" if margin == 1 else f"{margin} goals" if margin else "-"
        if winner == "Draw":
            margin_text = "0 goals"

        self.result_vars["status"].set(status)
        self.result_vars["period"].set(str(data.get("period") or "-"))
        self.result_vars["scoreline"].set(scoreline)
        self.result_vars["left_side"].set(str(data.get("team1") or "Unknown"))
        self.result_vars["right_side"].set(str(data.get("team2") or "Unknown"))
        self.result_vars["winner"].set(winner or "Unknown")
        self.result_vars["loser"].set(str(data.get("loser") or "Unknown"))
        self.result_vars["margin"].set(margin_text)
        self.result_vars["queried_user"].set(str(data.get("queried_username") or "None"))
        self.result_vars["queried_team"].set(str(data.get("queried_team") or "None"))
        self.result_vars["detected_side"].set(str(data.get("user_team") or "Unknown"))
        self.result_vars["confidence"].set(str(data.get("confidence") or "-"))
        self.result_vars["analysis_engine"].set(str(data.get("analysis_engine") or "ocr"))
        self.result_vars["header_regions"].set(
            self._format_header_regions(data.get("scoreboard_regions"))
        )

        self._set_announcement(str(data.get("announcement") or "No summary available."))
        self._set_raw_text(str(data.get("raw_text") or ""))
        self._populate_stats(data.get("stats"))

        self.status_var.set("Analysis complete.")
        self._set_busy(False)

    def _format_header_regions(self, regions: object) -> str:
        if not isinstance(regions, dict) or not regions:
            return "Not detected"
        ordered = []
        for key in ("left_name", "score1", "score2", "right_name"):
            if key in regions:
                ordered.append(f"{key}: {regions[key]}")
        return " | ".join(ordered) if ordered else str(regions)

    def _populate_stats(self, stats: object) -> None:
        if not self.stats_tree:
            return

        for item in self.stats_tree.get_children():
            self.stats_tree.delete(item)

        if not isinstance(stats, dict) or not stats:
            self.stats_tree.insert("", "end", values=("No stats detected", "-", "-"))
            return

        for label, values in stats.items():
            if not isinstance(values, dict):
                continue
            self.stats_tree.insert(
                "",
                "end",
                values=(
                    str(label).title(),
                    str(values.get("left", "?")),
                    str(values.get("right", "?")),
                ),
            )

    def _show_error(self, error_message: str) -> None:
        if TESSERACT_INSTALL_HELP in error_message:
            message = TESSERACT_INSTALL_HELP
        else:
            message = error_message

        self.status_var.set("Analysis failed.")
        self._set_busy(False)
        self._set_announcement(message)
        self._set_raw_text("")
        self._populate_stats({})
        messagebox.showerror("Analysis failed", message)

    def clear_all(self) -> None:
        self.image_path_var.set("")
        self.username_var.set("")
        self.team_var.set("")
        self.tesseract_path_var.set("")
        self.status_var.set("Choose an eFootball result screenshot, then click Analyze.")

        for value in self.result_vars.values():
            value.set("-")

        if self.preview_label:
            self.preview_label.configure(image="", text="No image selected")
        self.preview_image = None

        self._set_announcement("Analysis will appear here.")
        self._set_raw_text("Raw OCR output will appear here.")
        self._populate_stats({})

    def _set_busy(self, is_busy: bool) -> None:
        if self.analyze_button:
            self.analyze_button.configure(state="disabled" if is_busy else "normal")

    def _set_announcement(self, text: str) -> None:
        if not self.announcement_text:
            return

        self.announcement_text.configure(state="normal")
        self.announcement_text.delete("1.0", "end")
        self.announcement_text.insert("1.0", text)
        self.announcement_text.configure(state="disabled")

    def _set_raw_text(self, text: str) -> None:
        if not self.raw_text:
            return

        self.raw_text.configure(state="normal")
        self.raw_text.delete("1.0", "end")
        self.raw_text.insert("1.0", text or "No OCR text available.")
        self.raw_text.configure(state="disabled")


def main() -> None:
    app = EFootballResultGUI()
    app.mainloop()


if __name__ == "__main__":
    main()
