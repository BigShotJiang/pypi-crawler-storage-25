# eFootball Result Analyzer

OCR-only eFootball screenshot analysis with dedicated scoreboard-region detection.

## Features

- Local OCR extraction for usernames, scoreline, winner, loser, and match stats
- Explicit detection of the top scoreboard regions for:
  - left username
  - left score box
  - right score box
  - right username
- Importable Python API
- Desktop GUI uploader
- CLI entrypoints

## Install

```bash
pip install efootball-result-analyzer
```

You also need the native Tesseract executable installed on your machine.

## Python Usage

```python
from efootball_analyzer import analyze_match_result

result = analyze_match_result(
    "result.jpg",
    team="United",
)

print(result["winner"], result["scoreline"])
print(result["scoreboard_regions"])
```

## CLI

```bash
efootball-analyze --image result.jpg
efootball-analyze --image result.jpg --team "United"
efootball-analyze --image result.jpg --username "I clear ball"
efootball-analyze-gui
```

## Output

The analyzer returns a dictionary with:

- `team1`, `team2`
- `score1`, `score2`
- `winner`, `loser`, `margin`
- `scoreline`
- `stats`
- `scoreboard_regions`
- `raw_text`
