"""``building`` / ``building3d`` commands and helpers."""

from __future__ import annotations

import json
import shlex
import subprocess
import sys
import tempfile
from dataclasses import asdict
from pathlib import Path

from batem.core.building import Building, BuildingData, ContextData, variation

from batem.baterm.deserialize import building_data_from_json_str_data, run_python
from batem.baterm.completion_utils import completion_fragment_looks_pathish
from batem.baterm.scripts import (
    BUILDING_3D_SCRIPT,
    BUILDING_FORM_SCRIPT,
    BUILDING_VARIATION_PLOT_SCRIPT,
)

_BUILDING_SUBCOMMANDS: tuple[str, ...] = (
    "new",
    "edit",
    "load",
    "save",
    "delete",
    "3d",
    "heliodons",
    "footprint",
    "simulate",
    "results",
    "plot",
    "variation",
)


class BuildingCommandsMixin:
    @staticmethod
    def _with_building_suffix(path: Path) -> Path:
        """Ensure ``path`` ends with the ``.building`` extension."""
        return path if path.suffix == ".building" else path.with_suffix(path.suffix + ".building")

    def _load_building_file(self, path: Path) -> bool:
        path = self._with_building_suffix(path.expanduser())
        if not path.exists():
            self.perror(f"File not found: {path}")
            return False
        try:
            self.building_data = building_data_from_json_str_data(json.loads(path.read_text(encoding="utf-8")))
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not load building from {path}: {exc}")
            return False
        self.poutput(f"Building loaded: {path}")
        self._refresh_building()
        return True

    def _save_building_file(self, path: Path) -> bool:
        if self.building_data is None:
            self.perror("No building data to save. Use 'building new', 'building edit', or 'building load <path>' first.")
            return False
        path = self._with_building_suffix(path.expanduser())
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(asdict(self.building_data), indent=2), encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not save building to {path}: {exc}")
            return False
        self.poutput(f"Building saved: {path}")
        return True

    def _open_building_form(self, *, blank: bool = False) -> BuildingData | None:
        """Open :meth:`BuildingData.form` in a child Python process and return the result."""
        with tempfile.TemporaryDirectory(prefix="baterm_building_") as tmp_dir:
            inp = Path(tmp_dir) / "input.json"
            out = Path(tmp_dir) / "output.json"
            if blank:
                initial = None
            else:
                initial = asdict(self.building_data) if self.building_data is not None else None
            inp.write_text(json.dumps(initial), encoding="utf-8")
            if run_python(BUILDING_FORM_SCRIPT, str(inp), str(out)) != 0 or not out.exists():
                return None
            return building_data_from_json_str_data(json.loads(out.read_text(encoding="utf-8")))

    def _new_building(self) -> None:
        building_data: BuildingData | None = self._open_building_form(blank=True)
        if building_data is None:
            self.poutput("Building creation canceled.")
            return
        self.building_data = building_data
        self.poutput("Building created from GUI editor.")
        self._refresh_building()

    def _edit_building(self) -> None:
        building_data: BuildingData | None = self._open_building_form()
        if building_data is None:
            self.poutput("Building edit canceled.")
            return
        self.building_data = building_data
        self.poutput("Building updated from GUI editor.")
        self._refresh_building()

    def _delete_building(self) -> None:
        if self.building_data is None:
            self.poutput("No building loaded.")
            return
        self.building_data = None
        self._refresh_building()
        self.poutput("Building deleted from memory.")

    def _require_building(self) -> Building | None:
        """Return the current Building, rebuilding it when possible."""
        if self.building is None:
            self._refresh_building()
        if self.building is None:
            self.perror("No building available. Load or edit both a context and a building first.")
            return None
        return self.building

    def _building_3d(self) -> None:
        if self.context_data is None or self.building_data is None:
            self.perror("No building available. Load or edit both a context and a building first.")
            return
        payload = {
            "context_data": asdict(self.context_data),
            "building_data": asdict(self.building_data),
        }
        with tempfile.TemporaryDirectory(prefix="baterm_building3d_") as tmp_dir:
            inp = Path(tmp_dir) / "input.json"
            inp.write_text(json.dumps(payload), encoding="utf-8")
            try:
                run_python(BUILDING_3D_SCRIPT, str(inp))
            except Exception as exc:  # noqa: BLE001
                self.perror(f"Could not render building 3D view: {exc}")

    def _building_heliodons(self) -> None:
        bld = self._require_building()
        if bld is not None:
            bld.plot_heliodons()

    def _building_footprint(self) -> None:
        if self.building_data is None:
            self.perror("No building data loaded. Use 'building new', 'building edit', or 'building load <path>' first.")
            return
        self.building_data.plot_footprint()

    def _building_simulate(self) -> None:
        bld = self._require_building()
        if bld is None:
            return
        bld.simulate()
        bld.print_results()

    def _building_results(self) -> None:
        bld = self._require_building()
        if bld is None:
            return
        try:
            bld.print_results()
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not print building results. Run 'building simulate' first if needed: {exc}")

    def _building_plot(self) -> None:
        """Same as ``DataProvider.plot()`` with no args, via :meth:`_time_series_plot_worker_subprocess`."""
        bld = self._require_building()
        if bld is None:
            return
        self._time_series_plot_worker_subprocess(
            bld.dp,
            empty_message=(
                "No plottable variables. Run 'building simulate' first if you expect simulation series."
            ),
        )

    @staticmethod
    def _parse_building_variation_options(rest: list[str]) -> tuple[bool, int | None, int | None] | None:
        """Parse ``--quick``, ``--max-jobs N``, ``--max-workers M``. Return ``None`` on error."""
        quick: bool = False
        max_jobs: int | None = None
        max_workers: int | None = None
        i: int = 0
        while i < len(rest):
            tok: str = rest[i]
            if tok == "--quick":
                quick = True
                i += 1
            elif tok == "--max-jobs":
                if i + 1 >= len(rest):
                    return None
                try:
                    max_jobs = int(rest[i + 1])
                except ValueError:
                    return None
                if max_jobs < 1:
                    return None
                i += 2
            elif tok == "--max-workers":
                if i + 1 >= len(rest):
                    return None
                try:
                    max_workers = int(rest[i + 1])
                except ValueError:
                    return None
                if max_workers < 1:
                    return None
                i += 2
            else:
                return None
        return quick, max_jobs, max_workers

    def _variation_figure_save_dir(self) -> Path:
        """Directory for PNG exports (next to the current workspace file, or under cwd)."""
        base: Path = self.current_file.parent if self.current_file is not None else Path.cwd()
        return base / ".baterm" / "variation_figures"

    def _building_variation(self, rest: list[str]) -> None:
        """Run :func:`~batem.core.building.variation` and open dual-axis sweep figures (last floor)."""
        if self.context_data is None or self.building_data is None:
            self.perror("Need both context and building. Load or edit context and building first.")
            return
        opts = self._parse_building_variation_options(rest)
        if opts is None and rest:
            self.perror(
                "Invalid options. Usage: building variation [--quick] [--max-jobs N] [--max-workers M]"
            )
            return
        quick, max_jobs, max_workers = opts if opts is not None else (False, None, None)
        ctx: ContextData = self.context_data
        bd: BuildingData = self.building_data
        self.poutput(
            "Running parametric annual simulations (last floor metrics). "
            "This can take a long time without --quick / --max-jobs. Progress prints one dot per completed case."
        )
        performances = variation(
            ctx,
            bd,
            max_workers=max_workers,
            progress=True,
            quick=quick,
            max_jobs=max_jobs,
        )
        if not performances:
            self.perror("No simulation results collected; cannot draw figures.")
            return
        self.poutput(f"Collected {len(performances)} case(s). Opening figures in a child process…")
        out_dir: Path = self._variation_figure_save_dir()
        out_dir.mkdir(parents=True, exist_ok=True)
        payload = {
            "performances": [
                {
                    "name": pname,
                    "instance": int(inst),
                    "value": float(pval),
                    "perf": [float(v) for v in perf],
                }
                for (pname, inst, pval), perf in performances.items()
            ],
            "building_data": asdict(bd),
            "suptitle_prefix": f"{ctx.location or 'site'} — year {ctx.simulated_year}",
            "save_dir": str(out_dir.resolve()),
        }
        with tempfile.TemporaryDirectory(prefix="baterm_building_variation_") as tmp_dir:
            payload_path = Path(tmp_dir) / "payload.json"
            payload_path.write_text(json.dumps(payload), encoding="utf-8")
            try:
                code = run_python(BUILDING_VARIATION_PLOT_SCRIPT, str(payload_path))
            except Exception as exc:  # noqa: BLE001
                self.perror(f"Could not render variation figures: {exc}")
                return
        if code != 0:
            self.perror(
                f"Variation plot worker exited with code {code}. "
                f"PNGs (if any) are under {out_dir.resolve()}."
            )
            return
        self.poutput(f"Variation figures closed. PNGs saved under:\n  {out_dir.resolve()}")
        if sys.platform == "darwin":
            subprocess.run(["open", str(out_dir.resolve())], check=False)

    def help_building(self) -> None:
        """Detailed help for the ``building`` command."""
        lines: list[str] = [
            "building — manage the active BuildingData and run simulations.",
            "",
            "Usage:",
            "  building                                Print a summary of the current BuildingData.",
            "",
            "State management:",
            "  building new                            GUI editor to create a fresh BuildingData.",
            "  building edit                           GUI editor to modify the current BuildingData.",
            "  building load <path>                    Load a .building JSON file (.building appended if missing).",
            "  building save <path>                    Save the current BuildingData to a .building JSON file.",
            "  building delete                         Forget the current BuildingData (keeps the context).",
            "",
            "Geometry views:",
            "  building footprint                      Plan-view footprint of the current BuildingData.",
            "  building 3d                             Interactive 3D view (runs in a separate process).",
            "  building heliodons                      One heliodon per glazed facade.",
            "",
            "Simulation:",
            "  building simulate                       Run the annual hourly simulation and print results.",
            "  building results                        Reprint the last simulation results.",
            "  building plot                           Pick any DataProvider series to plot (post-simulation).",
            "",
            "Parametric sweeps:",
            "  building variation [opts...]            Run last-floor parameter sweeps and open dual-axis figures.",
            "      --quick                               Cap at 8 cases for fast iteration.",
            "      --max-jobs N                          Hard cap on total cases.",
            "      --max-workers M                       Number of parallel processes used.",
            "    Outputs (PNGs) are saved under '<workspace>/.baterm/variation_figures/' and the",
            "    folder is opened in Finder on macOS.",
            "",
            "Notes:",
            "  - Most subcommands need BOTH a context AND a building loaded; load the context first.",
            "  - File-based subcommands accept absolute or workspace-relative paths and auto-append '.building'.",
            "  - GUI / plot subcommands run in a child Python process; closing a window does not exit baterm.",
            "  - See 'help context', 'help sidemask', 'help script' for related workflows.",
        ]
        self.poutput("\n".join(lines))

    def do_building(self, arg: str) -> None:
        """Manage the current BuildingData (see ``help building`` for the full subcommand list)."""
        tokens = shlex.split(arg)
        if not tokens:
            if self.building_data is None:
                self.poutput("No building loaded.")
                return
            self._print_dataclass_summary("BuildingData:", self.building_data)
            return

        action, *rest = tokens
        if action == "new":
            if rest:
                self.perror("Usage: building new")
                return
            self._new_building()
            return
        if action == "edit":
            if rest:
                self.perror("Usage: building edit")
                return
            self._edit_building()
            return
        if action == "load":
            if len(rest) != 1:
                self.perror("Usage: building load <path>")
                return
            self._load_building_file(Path(rest[0]))
            return
        if action == "save":
            if len(rest) != 1:
                self.perror("Usage: building save <path>")
                return
            self._save_building_file(Path(rest[0]))
            return
        if action == "delete":
            if rest:
                self.perror("Usage: building delete")
                return
            self._delete_building()
            return
        if action == "3d":
            if rest:
                self.perror("Usage: building 3d")
                return
            self._building_3d()
            return
        if action == "heliodons":
            if rest:
                self.perror("Usage: building heliodons")
                return
            self._building_heliodons()
            return
        if action == "footprint":
            if rest:
                self.perror("Usage: building footprint")
                return
            self._building_footprint()
            return
        if action == "simulate":
            if rest:
                self.perror("Usage: building simulate")
                return
            self._building_simulate()
            return
        if action == "results":
            if rest:
                self.perror("Usage: building results")
                return
            self._building_results()
            return
        if action == "plot":
            if rest:
                self.perror("Usage: building plot")
                return
            self._building_plot()
            return
        if action == "variation":
            self._building_variation(rest)
            return

        self.perror(
            "Usage: building | building new | building edit | building load <path> | building save <path> | "
            "building delete | building 3d | building heliodons | building footprint | "
            "building simulate | building results | building plot | "
            "building variation [--quick] [--max-jobs N] [--max-workers M]"
        )

    def do_building3d(self) -> None:
        self._building_3d()

    def complete_building(self, text: str, line: str, begidx: int, endidx: int) -> list[str]:
        """Tab-complete ``building`` subcommands and paths for ``load`` / ``save``."""
        tokens, _raw = self.tokens_for_completion(line, begidx, endidx)
        if not tokens:
            return []
        if len(tokens) == 2:
            frag = tokens[1]
            if frag == "":
                return list(_BUILDING_SUBCOMMANDS)
            if completion_fragment_looks_pathish(frag):
                return self.path_complete(text, line, begidx, endidx)
            return [v for v in _BUILDING_SUBCOMMANDS if v.startswith(frag)]
        if len(tokens) >= 3 and tokens[1] in ("load", "save"):
            return self.path_complete(text, line, begidx, endidx)
        return []
