"""``context`` command and helpers (load/save/GUI/plot/heliodon)."""

from __future__ import annotations

import json
import shlex
import tempfile
from dataclasses import asdict
from pathlib import Path

from batem.core.building import ContextData

from batem.baterm.completion_utils import completion_fragment_looks_pathish
from batem.baterm.deserialize import context_data_from_json_str_data, run_python
from batem.baterm.scripts import CONTEXT_FORM_SCRIPT

_CONTEXT_SUBCOMMANDS: tuple[str, ...] = (
    "new",
    "edit",
    "load",
    "save",
    "delete",
    "3d",
    "plot",
    "heliodon",
    "temperature",
    "rain",
    "solar",
    "wind",
    "psychro",
    "heatwave",
    "evolution",
)


class ContextCommandsMixin:
    def _open_context_form(self, *, blank: bool = False) -> ContextData | None:
        """Open the context GUI form; with ``blank=True``, ignore any loaded context."""
        with tempfile.TemporaryDirectory(prefix="baterm_context_") as tmp_dir:
            inp = Path(tmp_dir) / "input.json"
            out = Path(tmp_dir) / "output.json"
            if blank:
                initial = None
            else:
                initial = asdict(self.context_data) if self.context_data is not None else None
            inp.write_text(json.dumps(initial), encoding="utf-8")
            if run_python(CONTEXT_FORM_SCRIPT, str(inp), str(out)) != 0 or not out.exists():
                return None
            return context_data_from_json_str_data(json.loads(out.read_text(encoding="utf-8")))

    @staticmethod
    def _with_context_suffix(path: Path) -> Path:
        """Ensure ``path`` ends with the ``.context`` extension."""
        return path if path.suffix == ".context" else path.with_suffix(path.suffix + ".context")

    def _load_context_file(self, path: Path) -> bool:
        path = self._with_context_suffix(path.expanduser())
        if not path.exists():
            self.perror(f"File not found: {path}")
            return False
        try:
            self.context_data = context_data_from_json_str_data(json.loads(path.read_text(encoding="utf-8")))
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not load context from {path}: {exc}")
            return False
        self.poutput(f"Context loaded: {path}")
        self._refresh_building()
        return True

    def _save_context_file(self, path: Path) -> bool:
        if self.context_data is None:
            self.perror("No context data to save. Use 'context new', 'context load <path>', or 'context <path>' first.")
            return False
        path = self._with_context_suffix(path.expanduser())
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(asdict(self.context_data), indent=2), encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not save context to {path}: {exc}")
            return False
        self.poutput(f"Context saved: {path}")
        return True

    def _new_context(self) -> None:
        context_data: ContextData | None = self._open_context_form(blank=True)
        if context_data is None:
            self.poutput("Context creation canceled.")
            return
        self.context_data = context_data
        self.poutput("Context created from GUI editor.")
        self._refresh_building()

    def _edit_context(self) -> None:
        if self.context_data is None:
            self.perror("No context loaded. Use 'context new' or 'context load <path>' first.")
            return
        context_data: ContextData | None = self._open_context_form()
        if context_data is None:
            self.poutput("Context edit canceled.")
            return
        self.context_data = context_data
        self.poutput("Context updated from GUI editor.")
        self._refresh_building()

    def _delete_context(self) -> None:
        if self.context_data is None:
            self.poutput("No context loaded.")
            return
        self.context_data = None
        self._refresh_building()
        self.poutput("Context deleted from memory.")

    def _context_3d(self, names: list[str] | None = None) -> None:
        """Show a 3D plot of the side masks known from the session/context."""
        self._plot_side_masks_3d(names=names)

    def help_context(self) -> None:
        """Detailed help for the ``context`` command."""
        lines: list[str] = [
            "context — manage the active ContextData (site, year, weather).",
            "",
            "Usage:",
            "  context                         Print a summary of the current ContextData.",
            "  context <path>                  Shorthand for 'context load <path>'.",
            "",
            "State management:",
            "  context new                     GUI editor to create a fresh ContextData.",
            "  context edit                    GUI editor to modify the current ContextData.",
            "  context load <path>             Load a .context JSON file (.context appended if missing).",
            "  context save <path>             Save the current ContextData to a .context JSON file.",
            "  context delete                  Forget the current ContextData (also clears the building).",
            "",
            "Geometry & sun:",
            "  context 3d [<name> ...]         3D view of session side masks (all, or by name).",
            "  context heliodon                Sun paths + horizon + side masks for the site.",
            "",
            "Climate & weather figures (use the active DataProvider):",
            "  context plot                    Generic time-series picker (any DataProvider variable).",
            "  context temperature             Outdoor temperature: time series + monotone curve.",
            "  context rain                    Precipitation & cloudiness (2 x 2 grid).",
            "  context solar                   Unit-area solar gains by orientation (1 x 2).",
            "  context wind                    Wind rose + speed / direction distributions.",
            "  context psychro                 Outdoor Givoni psychrometric diagram.",
            "  context heatwave                3-day min / max / avg felt-temperature extremes.",
            "  context evolution               Full-archive annual temperature & rainfall trends.",
            "",
            "Notes:",
            "  - Most subcommands require a context to be loaded first (use 'context load' or 'context new').",
            "  - File-based subcommands accept absolute or workspace-relative paths and auto-append '.context'.",
            "  - GUI / plot subcommands run in a separate process; closing a figure does not exit baterm.",
            "  - See 'help building', 'help sidemask', 'help script' for related workflows.",
        ]
        self.poutput("\n".join(lines))

    def do_context(self, arg: str) -> None:
        """Manage the current ContextData (see ``help context`` for the full subcommand list)."""
        usage = (
            "Usage: context | context new | context edit | context load <path> | context save <path> | "
            "context delete | context 3d [<name> ...] | context plot | context heliodon | context temperature | "
            "context rain | context solar | context wind | context psychro | context heatwave | context evolution | context <path>"
        )
        tokens = shlex.split(arg)
        if not tokens:
            if self.context_data is None:
                self.poutput("No context loaded.")
                return
            self._print_dataclass_summary("ContextData:", self.context_data)
            return

        action, *rest = tokens
        if action == "new":
            if rest:
                self.perror("Usage: context new")
                return
            self._new_context()
            return
        if action == "edit":
            if rest:
                self.perror("Usage: context edit")
                return
            self._edit_context()
            return
        if action == "load":
            if len(rest) != 1:
                self.perror("Usage: context load <path>")
                return
            self._load_context_file(Path(rest[0]))
            return
        if action == "save":
            if len(rest) != 1:
                self.perror("Usage: context save <path>")
                return
            self._save_context_file(Path(rest[0]))
            return
        if action == "delete":
            if rest:
                self.perror("Usage: context delete")
                return
            self._delete_context()
            return
        if action == "3d":
            self._context_3d(rest)
            return
        if action == "plot":
            if rest:
                self.perror("Usage: context plot")
                return
            self._context_plot()
            return
        if action == "heliodon":
            if rest:
                self.perror("Usage: context heliodon")
                return
            self._context_heliodon()
            return
        if action == "temperature":
            if rest:
                self.perror("Usage: context temperature")
                return
            self._context_temperature()
            return
        if action == "rain":
            if rest:
                self.perror("Usage: context rain")
                return
            self._context_rain()
            return
        if action == "solar":
            if rest:
                self.perror("Usage: context solar")
                return
            self._context_solar()
            return
        if action == "wind":
            if rest:
                self.perror("Usage: context wind")
                return
            self._context_wind()
            return
        if action == "psychro":
            if rest:
                self.perror("Usage: context psychro")
                return
            self._context_psychro()
            return
        if action == "heatwave":
            if rest:
                self.perror("Usage: context heatwave")
                return
            self._context_heatwave()
            return
        if action == "evolution":
            if rest:
                self.perror("Usage: context evolution")
                return
            self._context_evolution()
            return

        if len(tokens) != 1:
            self.perror(usage)
            return
        self._load_context_file(Path(action))

    def _context_plot(self) -> None:
        """``DataProvider.plot()`` for the active context (or building) :attr:`data_provider`, subprocess UI."""
        dp = self.data_provider
        if dp is None:
            self.perror("No DataProvider. Load a context with 'context load ...' (or 'context new') first.")
            return
        self._time_series_plot_worker_subprocess(
            dp,
            empty_message="No plottable series in the current DataProvider.",
        )

    def _context_temperature(self) -> None:
        """Outdoor temperature overview (lambdahouse-style): time series + monotone in one figure."""
        if self.context_data is None:
            self.perror("No context loaded. Use 'context load ...' (or 'context new') first.")
            return
        ctx = self.building.context if self.building is not None else self._context_shell
        if ctx is None:
            self.perror("No weather context. Reload the context.")
            return
        try:
            from batem.baterm.climate_figures import lambda_parametric_from_site_weather, show_context_temperature_figure

            year = int(self.context_data.simulated_year)
            swd = ctx.dp.weather_data
            lpd = lambda_parametric_from_site_weather(swd, year)
            show_context_temperature_figure(lpd)
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not build temperature figure: {exc}")

    def _context_rain(self) -> None:
        """Precipitation / cloudiness overview (lambdahouse climate plots) in one (2, 2) figure."""
        if self.context_data is None:
            self.perror("No context loaded. Use 'context load ...' (or 'context new') first.")
            return
        ctx = self.building.context if self.building is not None else self._context_shell
        if ctx is None:
            self.perror("No weather context. Reload the context.")
            return
        try:
            from batem.baterm.climate_figures import lambda_parametric_from_site_weather
            from batem.baterm.rain_figures import show_context_rain_figure

            year = int(self.context_data.simulated_year)
            swd = ctx.dp.weather_data
            lpd = lambda_parametric_from_site_weather(swd, year)
            show_context_rain_figure(lpd)
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not build rain / cloudiness figure: {exc}")

    def _context_solar(self) -> None:
        """Unit 1 m² solar gains: daily horizontal heatmap + annual totals per orientation (1×2)."""
        if self.context_data is None:
            self.perror("No context loaded. Use 'context load ...' (or 'context new') first.")
            return
        ctx = self.building.context if self.building is not None else self._context_shell
        if ctx is None:
            self.perror("No weather context. Reload the context.")
            return
        try:
            from batem.baterm.solar_figures import show_context_solar_figure

            show_context_solar_figure(ctx.solar_model)
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not build solar figure: {exc}")

    def _context_wind(self) -> None:
        """Windrose + wind speed / direction distributions (lambdahouse climate plots)."""
        if self.context_data is None:
            self.perror("No context loaded. Use 'context load ...' (or 'context new') first.")
            return
        ctx = self.building.context if self.building is not None else self._context_shell
        if ctx is None:
            self.perror("No weather context. Reload the context.")
            return
        try:
            from batem.baterm.climate_figures import lambda_parametric_from_site_weather
            from batem.baterm.wind_figures import show_context_wind_figure

            year = int(self.context_data.simulated_year)
            swd = ctx.dp.weather_data
            lpd = lambda_parametric_from_site_weather(swd, year)
            show_context_wind_figure(lpd)
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not build wind figure: {exc}")

    def _context_psychro(self) -> None:
        """Outdoor psychrometric (Givoni) diagram from lambdahouse climate / outdoor comfort."""
        if self.context_data is None:
            self.perror("No context loaded. Use 'context load ...' (or 'context new') first.")
            return
        ctx = self.building.context if self.building is not None else self._context_shell
        if ctx is None:
            self.perror("No weather context. Reload the context.")
            return
        try:
            from batem.baterm.climate_figures import lambda_parametric_from_site_weather
            from batem.baterm.psychro_figures import show_context_psychro_figure

            year = int(self.context_data.simulated_year)
            swd = ctx.dp.weather_data
            lpd = lambda_parametric_from_site_weather(swd, year)
            show_context_psychro_figure(lpd)
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not build psychrometric figure: {exc}")

    def _context_heatwave(self) -> None:
        """3-day min/max/avg felt temperature (lambdahouse outdoor comfort, second plot)."""
        if self.context_data is None:
            self.perror("No context loaded. Use 'context load ...' (or 'context new') first.")
            return
        ctx = self.building.context if self.building is not None else self._context_shell
        if ctx is None:
            self.perror("No weather context. Reload the context.")
            return
        try:
            from batem.baterm.climate_figures import lambda_parametric_from_site_weather
            from batem.baterm.heatwave_figures import show_context_heatwave_figure

            year = int(self.context_data.simulated_year)
            swd = ctx.dp.weather_data
            lpd = lambda_parametric_from_site_weather(swd, year)
            show_context_heatwave_figure(lpd)
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not build heatwave / felt-temperature figure: {exc}")

    def _context_evolution(self) -> None:
        """Full-archive annual temperature + rainfall trends (same plots as ``Analyzes.evolution``)."""
        if self.context_data is None:
            self.perror("No context loaded. Use 'context load ...' (or 'context new') first.")
            return
        try:
            from batem.baterm.evolution_figures import show_context_evolution_figure

            show_context_evolution_figure(self.context_data)
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not build evolution figure: {exc}")

    def _context_heliodon(self) -> None:
        """Matplotlib heliodon for the site (sun paths + horizon + context ``side_masks``)."""
        if self.context_data is None:
            self.perror("No context loaded. Use 'context load ...' (or 'context new') first.")
            return
        if self.building is not None:
            solar_model = self.building.context.solar_model
        elif self._context_shell is not None:
            solar_model = self._context_shell.solar_model
        else:
            self.perror("No solar model available. Reload the context.")
            return
        import matplotlib.pyplot as plt

        solar_model.plot_heliodon(
            name=self.context_data.location or "site",
            year=int(self.context_data.simulated_year),
            observer_elevation_m=0.0,
            mask=None,
        )
        plt.show()

    def complete_context(self, text: str, line: str, begidx: int, endidx: int) -> list[str]:
        """Tab-complete ``context`` subcommands (e.g. ``temp`` → ``temperature``) and paths for ``load``/``save``."""
        tokens, _raw = self.tokens_for_completion(line, begidx, endidx)
        if not tokens:
            return []
        if len(tokens) == 2:
            frag = tokens[1]
            if frag == "":
                return list(_CONTEXT_SUBCOMMANDS)
            if completion_fragment_looks_pathish(frag):
                return self.path_complete(text, line, begidx, endidx)
            return [v for v in _CONTEXT_SUBCOMMANDS if v.startswith(frag)]
        if len(tokens) >= 3 and tokens[1] in ("load", "save"):
            return self.path_complete(text, line, begidx, endidx)
        return []
