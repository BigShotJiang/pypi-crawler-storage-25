"""Subprocess time-series plotter (Tk + Plotly) shared by ``context plot`` / ``building plot``."""

from __future__ import annotations

import os
import pickle
import subprocess
import sys
import tempfile
from pathlib import Path

from batem.core.data import DataProvider

from batem.baterm.config import BATEM_REPO_ROOT


class PlottingMixin:
    def _time_series_plot_worker_subprocess(self, dp: DataProvider, *, empty_message: str) -> None:
        """Open the same Tk + Plotly UI as ``DataProvider.plot()`` in a **child Python process**."""
        variable_values: dict[str, list[float]] = {}
        for v in dp.variable_names:
            try:
                variable_values[v] = dp.series(v)
            except (ValueError, KeyError):
                continue
        if not variable_values:
            self.perror(empty_message)
            return

        tmp_path: str | None = None
        try:
            fd, tmp_path = tempfile.mkstemp(suffix=".pkl")
            os.close(fd)
            Path(tmp_path).write_bytes(pickle.dumps({"variable_values": variable_values, "datetimes": dp.datetimes}, protocol=pickle.HIGHEST_PROTOCOL))

            pp = os.environ.get("PYTHONPATH", "")
            env = {**os.environ, "PYTHONPATH": str(BATEM_REPO_ROOT) + (os.pathsep + pp if pp else "")}

            completed = subprocess.run(
                [sys.executable, "-m", "batem.tools.time_series_plot_worker", tmp_path],
                cwd=str(BATEM_REPO_ROOT),
                env=env,
                check=False,
            )
            if completed.returncode != 0:
                self.perror(f"Time-series plot worker exited with code {completed.returncode}.")
        except Exception as exc:  # noqa: BLE001
            self.perror(f"Could not start the time-series plotter: {exc}")
        finally:
            if tmp_path:
                try:
                    Path(tmp_path).unlink(missing_ok=True)
                except OSError:
                    pass
