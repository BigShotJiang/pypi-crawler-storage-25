"""Workspace helpers: ``load``, ``dir``, ``status``, ``script``, ``pyscript``, ``run``."""

from __future__ import annotations

import os
import shlex
import subprocess
import sys
from pathlib import Path

import prettytable
from cmd2 import Cmd2ArgumentParser, with_argparser
from prettytable.prettytable import PrettyTable

from batem.baterm.config import BATEM_PACKAGE_DIR, BATEM_REPO_ROOT


class WorkspaceCommandsMixin:
    load_parser: Cmd2ArgumentParser = Cmd2ArgumentParser()
    load_parser.add_argument("path", help="Path to a file to load")

    _DIR_SCRIPT_SUFFIXES: frozenset[str] = frozenset({".context", ".building", ".baterm"})
    _SHELL_SCRIPT_SUFFIXES: frozenset[str] = frozenset({".sh", ".bash", ".zsh", ".bat", ".cmd"})

    @with_argparser(load_parser)
    def do_load(self, args) -> None:
        """Load a file."""
        path = Path(args.path).expanduser()
        if not path.exists():
            self.perror(f"File not found: {path}")
            return
        self.current_file = path
        self.poutput(f"Loaded: {path}")

    def do_dir(self, arg: str) -> None:
        """List workspace script files (.context, .building, .baterm)."""
        tokens: list[str] = shlex.split(arg)
        if len(tokens) > 1:
            self.perror("Usage: dir [folder]")
            return

        folder: Path = Path(tokens[0]).expanduser() if tokens else Path.cwd()
        if not folder.exists():
            self.perror(f"Folder not found: {folder}")
            return
        if not folder.is_dir():
            self.perror(f"Not a folder: {folder}")
            return

        files: list[Path] = sorted(
            [path for path in folder.iterdir() if path.is_file() and path.suffix in self._DIR_SCRIPT_SUFFIXES],
            key=lambda path: (path.suffix, path.name.lower()),
        )
        if not files:
            self.poutput(f"No .context, .building, or .baterm files found in {folder}.")
            return

        table: PrettyTable = prettytable.PrettyTable()
        table.field_names = ["#", "name", "type", "size"]
        for index, path in enumerate(files, start=1):
            table.add_row([index, path.stem, path.suffix.lstrip("."), path.stat().st_size])
        table.align["name"] = "l"
        table.align["type"] = "l"
        table.align["size"] = "r"
        self.poutput(f"Files in {folder}:")
        self.poutput(table)

    def do_status(self, arg: str) -> None:
        """Show current state."""
        self.poutput(f"Current file: {self.current_file}" if self.current_file else "No file loaded.")
        self.poutput(
            f"Context location: {self.context_data.location}" if self.context_data else "No context loaded."
        )
        if self.building is not None:
            self.poutput("Model: full Building (simulation-ready).")
        elif self.data_provider is not None:
            self.poutput("Weather: loaded (context-only DataProvider).")
        else:
            self.poutput("Weather: not loaded (load a context first).")
        self.poutput(f"Side masks (session): {len(self.side_masks)}")

    def _resolve_script_path(self, raw: str) -> Path | None:
        """Resolve a user-supplied script reference.

        Search order:

        1. The path as given (after ``~`` expansion), against cwd or as absolute.
        2. The same path with ``.baterm`` appended when no suffix is provided.
        3. Both of the above resolved relative to :data:`BATEM_REPO_ROOT`.
        """
        candidate = Path(raw).expanduser()
        candidates: list[Path] = [candidate]
        if candidate.suffix == "":
            candidates.append(candidate.with_suffix(".baterm"))
        if not candidate.is_absolute():
            candidates.append(BATEM_REPO_ROOT / candidate)
            if candidate.suffix == "":
                candidates.append(BATEM_REPO_ROOT / candidate.with_suffix(".baterm"))
        for path in candidates:
            if path.is_file():
                return path.resolve()
        return None

    def do_script(self, arg: str) -> None:
        """Run a baterm batch file (``.baterm``) or a shell script (``.sh``)."""
        parts: list[str] = shlex.split(arg)
        if not parts:
            self.perror("Usage: script <path> [arg ...]")
            return
        path = self._resolve_script_path(parts[0])
        if path is None:
            self.perror(f"Not a file: {parts[0]}")
            return
        extra: list[str] = parts[1:]

        if path.suffix in self._SHELL_SCRIPT_SUFFIXES:
            self._run_shell_script(path, extra)
            return

        if extra:
            self.pwarning(f"Ignoring extra arguments for baterm batch: {extra}")

        try:
            with path.open(encoding="utf-8") as source:
                lines: list[str] = [line.rstrip("\n") for line in source]
        except OSError as exc:
            self.perror(f"Could not read script {path}: {exc}")
            return

        commands: list[str] = [line for line in lines if line.strip() and not line.lstrip().startswith("#")]
        if not commands:
            self.poutput(f"No commands to run in {path}.")
            return

        self.poutput(f"Running baterm script: {path}")
        self.runcmds_plus_hooks(commands, stop_on_keyboard_interrupt=True)

    def _run_shell_script(self, path: Path, extra: list[str]) -> None:
        """Execute *path* as a shell script with cwd at the repo root."""
        root = str(BATEM_PACKAGE_DIR)
        try:
            if os.name == "nt":
                cmd_line = subprocess.list2cmdline([str(path), *extra])
                completed = subprocess.run(cmd_line, cwd=root, shell=True, check=False)
            else:
                completed = subprocess.run(["/bin/sh", str(path), *extra], cwd=root, check=False)
        except OSError as exc:
            self.perror(f"Could not run script: {exc}")
            return
        if completed.returncode != 0:
            self.perror(f"Script exited with code {completed.returncode}.")

    def do_pyscript(self, arg: str) -> None:
        """Run a Python file with this interpreter, cwd = package root."""
        parts: list[str] = shlex.split(arg)
        if not parts:
            self.perror("Usage: pyscript <path> [arg ...]")
            return
        path = Path(parts[0]).expanduser()
        if not path.is_file():
            self.perror(f"Not a file: {path}")
            return
        extra: list[str] = parts[1:]
        root = str(BATEM_PACKAGE_DIR)
        try:
            completed = subprocess.run(
                [sys.executable, str(path.resolve()), *extra],
                cwd=root,
                check=False,
            )
        except OSError as exc:
            self.perror(f"Could not run Python script: {exc}")
            return
        if completed.returncode != 0:
            self.perror(f"Python script exited with code {completed.returncode}.")

    def do_run(self, arg: str) -> None:
        """Run a simple command."""
        parts: list[str] = shlex.split(arg)
        if not parts:
            self.perror("Usage: run <command>")
            return
        command, *arguments = parts
        if command == "echo":
            self.poutput(" ".join(arguments))
        else:
            self.perror(f"Unknown internal command: {command}")

    def do_exit(self, arg: str) -> bool:
        """Exit the terminal."""
        self.poutput("Goodbye.")
        return True

    do_quit = do_exit
