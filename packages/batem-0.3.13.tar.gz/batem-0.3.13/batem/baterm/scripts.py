"""Inline ``python -c`` snippets run in child interpreters (forms, PyVista, building 3D)."""

CONTEXT_FORM_SCRIPT = """\
import json, sys
from dataclasses import asdict, fields
from pathlib import Path
from batem.core.building import ContextData, SideMaskData

inp, out = Path(sys.argv[1]), Path(sys.argv[2])
data = json.loads(inp.read_text(encoding='utf-8'))
initial = None
if data is not None:
    data = dict(data)
    sm_allowed = {f.name for f in fields(SideMaskData)}
    data['side_masks'] = [
        SideMaskData(**{k: v for k, v in m.items() if k in sm_allowed})
        for m in data.get('side_masks', [])
    ]
    ctx_allowed = {f.name for f in fields(ContextData)}
    initial = ContextData(**{k: v for k, v in data.items() if k in ctx_allowed})
result = ContextData.form(initial)
if result is not None:
    out.write_text(json.dumps(asdict(result), indent=2), encoding='utf-8')
"""

SIDEMASK_FORM_SCRIPT = """\
import json, sys
from dataclasses import asdict
from pathlib import Path
from batem.core.building import SideMaskData

inp, out = Path(sys.argv[1]), Path(sys.argv[2])
data = json.loads(inp.read_text(encoding='utf-8'))
initial = SideMaskData(**data) if data is not None else None
result = SideMaskData.form(initial)
if result is not None:
    out.write_text(json.dumps(asdict(result), indent=2), encoding='utf-8')
"""

BUILDING_FORM_SCRIPT = """\
import json, sys
from dataclasses import asdict, fields
from pathlib import Path
from batem.core.building import BuildingData

inp, out = Path(sys.argv[1]), Path(sys.argv[2])
data = json.loads(inp.read_text(encoding='utf-8'))
initial = None
if data is not None:
    allowed = {f.name for f in fields(BuildingData)}
    initial = BuildingData(**{k: v for k, v in dict(data).items() if k in allowed})
result = BuildingData.form(initial)
if result is not None:
    out.write_text(json.dumps(asdict(result), indent=2), encoding='utf-8')
"""

PLOT_SIDE_MASKS_SCRIPT = """\
import json, sys
from pathlib import Path
import pyvista as pv
from batem.core.building import SideMaskData, SideMaskView, _pyvista_show_then_destroy

payload = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
highlight = payload.get('highlight')

plotter = pv.Plotter(window_size=(1024, 768))
plotter.set_background('white')
for raw in payload['masks']:
    view = SideMaskView(SideMaskData(**raw))
    if highlight is not None and raw == highlight:
        view.color = 'orange'
        view.draw(plotter, opacity=0.65)
    else:
        view.draw(plotter)
plotter.add_mesh(
    pv.Plane(center=(0, 0, 0), direction=(0, 0, 1), i_size=60, j_size=60),
    color='#DDDDDD', opacity=1,
)
plotter.add_axes(line_width=2)
plotter.show_bounds(
    grid='front', location='outer', all_edges=True,
    xtitle='X (West -> East)', ytitle='Y (South -> North)', ztitle='Z (Up)',
)
plotter.camera_position = [(25, -35, 25), (0, 0, 5), (0, 0, 1)]
_pyvista_show_then_destroy(plotter, auto_close=True)
"""

BUILDING_3D_SCRIPT = """\
import json, sys
from dataclasses import fields
from pathlib import Path
from batem.core.building import Building, BuildingData, ContextData, SideMaskData

payload = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
ctx_raw = dict(payload['context_data'])
sm_allowed = {f.name for f in fields(SideMaskData)}
ctx_raw['side_masks'] = [
    SideMaskData(**{k: v for k, v in m.items() if k in sm_allowed})
    for m in ctx_raw.get('side_masks', [])
]
ctx_allowed = {f.name for f in fields(ContextData)}
context_data = ContextData(**{k: v for k, v in ctx_raw.items() if k in ctx_allowed})
bd_allowed = {f.name for f in fields(BuildingData)}
building_data = BuildingData(
    **{k: v for k, v in dict(payload['building_data']).items() if k in bd_allowed}
)
Building(context_data=context_data, building_data=building_data).plot3D()
"""


# Worker that shows + saves the parametric ``building variation`` figures.
# Runs in a child Python process so the macOS / Tk GUI event loop is free
# (the cmd2 input loop in the parent process otherwise blocks ``plt.show``).
BUILDING_VARIATION_PLOT_SCRIPT = """\
import json, sys
from dataclasses import fields
from pathlib import Path

# Force a GUI matplotlib backend in this child process (parent baterm sets one too,
# but the worker is a fresh interpreter).
import matplotlib
for _be in ('macosx', 'tkagg', 'qt5agg', 'qtagg'):
    try:
        matplotlib.use(_be, force=True)
        break
    except Exception:
        continue

from batem.core.building import BuildingData
from batem.core.building_variation_figures import plot_building_variation_figures

payload = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
performances = {
    (row['name'], int(row['instance']), float(row['value'])): tuple(row['perf'])
    for row in payload['performances']
}
allowed = {f.name for f in fields(BuildingData)}
raw = {k: v for k, v in dict(payload['building_data']).items() if k in allowed}
building_data = BuildingData(**raw)
save_dir = payload.get('save_dir')
plot_building_variation_figures(
    performances,
    building_data,
    show=True,
    suptitle_prefix=payload.get('suptitle_prefix', ''),
    save_dir=Path(save_dir) if save_dir else None,
)
"""
