"""Building model construction and simulation orchestration utilities.

.. module:: batem.core.building

This module provides the high-level orchestration logic required to build a
BATEM building model from contextual data, generate thermal networks, configure
HVAC controllers, and run coupled simulations. It binds together solar,
thermal, control, and model-making subsystems to offer a cohesive workflow.

The dataclasses defined here use reStructuredText field lists so that automated
documentation can surface every parameter accepted by the simulation pipeline.

:Author: stephane.ploix@grenoble-inp.fr
:License: GNU General Public License v3.0
Common geometry/view primitives (window/floor data classes and PyVista views)
are imported from :mod:`batem.core.building` to avoid duplication with
``batem.core.basicbuilding``.
"""
import base64
import re
from functools import cached_property
from pathlib import Path
from datetime import datetime
from urllib.parse import unquote, urlparse
from pyvista.core.pointset import PolyData
import html
from dataclasses import asdict, dataclass, field, fields, is_dataclass, replace
from pyvista.plotting.plotter import Plotter
from xhtml2pdf import pisa
from math import sqrt, atan2, radians, cos, sin, degrees, isfinite
import ast
import json
import pyvista as pv
import time
import warnings
import os
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import types
import prettytable
from typing import Any, Mapping, Self, Sequence, TypeAlias

from batem.core.data import DataProvider, Bindings
from batem.core.control import HeatingPeriod, CoolingPeriod, OccupancyProfile, SignalGenerator, TemperatureController, Simulation, TemperatureSetpointPort, HVACcontinuousModePort, LongAbsencePeriod
from batem.core.inhabitants import Preference
from batem.core.model import ModelMaker
from batem.core.components import Side
from batem.core.library import SIDE_TYPES, SLOPES, properties
from batem.core.solar import SolarModel, SolarSystem, Collector, SideMask, Mask, StackedMask, InvertedMask
from batem.core.statemodel import StateModel
from batem.core.utils import FilePathBuilder


def _facade_absorptance_from_wall_side(side: Side) -> float:
    """Solar absorptance of the outdoor-most layer of a wall composition (``propertiesDB.xlsx`` thermal sheet)."""
    if not side.layers:
        return 0.65
    outer_material: str = side.layers[-1][0]
    try:
        mat: dict = properties.get(outer_material)
        a = mat.get('absorptance', 0.65)
        if a is None or (isinstance(a, float) and np.isnan(a)):
            return 0.65
        return float(a)
    except (KeyError, ValueError, TypeError):
        return 0.65


def _glazing_only_solar_powers_W(solar_system: SolarSystem) -> list[float]:
    """Sum collector powers for glazing only (exclude ``PSOLW:*`` opaque-wall inputs injected at wall mass nodes)."""
    n: int = len(solar_system.datetimes)
    total: list[float] = [0.0] * n
    for name, coll in solar_system.collectors.items():
        if name.startswith('PSOLW:'):
            continue
        pw: list[float] = coll.powers_W()
        for k in range(n):
            total[k] += pw[k]
    return total


Vertices: TypeAlias = list[tuple[float, float]]
Vertex: TypeAlias = tuple[float, float]

pv.set_jupyter_backend('html')
# shared geometry/view data classes are imported from batem.core.building


def footprint_from_rectangular_building(east_west_length: float, north_south_length: float) -> Vertices:
    return [(-east_west_length / 2, -north_south_length / 2), (east_west_length / 2, -north_south_length / 2), (east_west_length / 2, north_south_length / 2), (-east_west_length / 2, north_south_length / 2)]


def rotate(footprint: Vertices, angle_deg: float) -> Vertices:
    """Rotate footprint points around origin by ``angle_deg`` degrees."""
    if abs(angle_deg) <= 1e-12:
        return list(footprint)
    angle_rad = radians(angle_deg)
    cos_a = cos(angle_rad)
    sin_a = sin(angle_rad)
    return [(cos_a * x - sin_a * y, sin_a * x + cos_a * y) for x, y in footprint]


def shoelace_area_m2(closed_footprint: Vertices) -> float:
    """Signed-area formula for a closed vertex ring (last point may repeat the first)."""
    n = len(closed_footprint)
    twice_area = 0.0
    for i in range(n):
        x1, y1 = closed_footprint[i]
        x2, y2 = closed_footprint[(i + 1) % n]
        twice_area += x1 * y2 - x2 * y1
    return abs(twice_area) / 2.0


def edge_length_m(vertex_a: Vertex, vertex_b: Vertex) -> float:
    return sqrt((vertex_b[0] - vertex_a[0]) ** 2 + (vertex_b[1] - vertex_a[1]) ** 2)


def _rotate_vector_around_axis(vector: np.ndarray, axis_unit: np.ndarray, angle_rad: float) -> np.ndarray:
    """Apply Rodrigues' rotation of ``vector`` around a unit axis ``axis_unit``."""
    c = cos(angle_rad)
    s = sin(angle_rad)
    v = np.asarray(vector, dtype=float)
    k = np.asarray(axis_unit, dtype=float)
    return v * c + np.cross(k, v) * s + k * float(np.dot(k, v)) * (1.0 - c)


@dataclass
class SideMaskData:
    """Obstacle mask in the site plane."""
    name: str
    x_center: float
    y_center: float
    width: float
    height: float
    elevation: float
    exposure_deg: float
    slope_deg: float = 90.0
    #: Roll of the mask rectangle around the outward normal (degrees), after
    #: the width axis has been fixed in the façade plane (see
    #: ``tangent_x`` / ``tangent_y``). Distant masks in :class:`ContextData` leave
    #: the tangents as NaN and use the exposure-based width from
    #: :class:`~batem.core.solar.SideMask` instead.
    normal_angle_with_south_deg: float = 0.0
    #: Backward-compatible alias for ``normal_angle_with_south_deg`` kept for
    #: older scripts/notebooks.
    normal_rotation_angle_deg: float | None = None
    #: Unit tangent of the footprint edge (horizontal, site ``x,y``), when the
    #: mask is tied to a real façade segment; otherwise NaN.
    tangent_x: float = float("nan")
    tangent_y: float = float("nan")
    #: Unit outward normal of the façade in the site horizontal plane; NaN when
    #: not derived from a footprint edge.
    facade_normal_x: float = float("nan")
    facade_normal_y: float = float("nan")

    def __post_init__(self) -> None:
        # Accept both historical and current naming conventions.
        if self.normal_rotation_angle_deg is not None:
            self.normal_angle_with_south_deg = self.normal_rotation_angle_deg

    @staticmethod
    def help(attribute_name: str) -> str:
        """Return a short explanation for one :class:`SideMaskData` attribute."""
        explanations: dict[str, str] = {
            "name": "Optional display name for this side mask, shown as a label in 3D plots.",
            "x_center": "X coordinate of the rectangle center in the site plan, in metres.",
            "y_center": "Y coordinate of the rectangle center in the site plan, in metres.",
            "width": "Rectangle width in metres, along the in-plane horizontal axis (or rotated by normal_angle_with_south_deg).",
            "height": "Rectangle height in metres, along the vertical axis when normal_angle_with_south_deg is 0.",
            "elevation": "Elevation of the rectangle base above ground in metres.",
            "exposure_deg": "Outward normal azimuth in degrees (0=South, +90=West, -90=East, 180=North).",
            "slope_deg": "Surface slope in degrees: 0=horizontal facing ground, 90=vertical, 180=horizontal facing sky.",
            "normal_angle_with_south_deg": "In-plane roll of the rectangle around the outward normal, in degrees. 0 keeps height vertical for a vertical mask.",
            "normal_rotation_angle_deg": "Backward-compatible alias for normal_angle_with_south_deg. Prefer the new name.",
            "tangent_x": "Optional X component of the unit tangent of the footprint edge tying the mask to a facade. NaN for distant masks.",
            "tangent_y": "Optional Y component of the unit tangent of the footprint edge tying the mask to a facade. NaN for distant masks.",
            "facade_normal_x": "Optional X component of the unit outward normal of the facade. NaN for distant masks.",
            "facade_normal_y": "Optional Y component of the unit outward normal of the facade. NaN for distant masks.",
        }
        try:
            return explanations[attribute_name]
        except KeyError as exc:
            valid_names = ", ".join(sorted(explanations))
            raise ValueError(f"Unknown SideMaskData attribute '{attribute_name}'. Expected one of: {valid_names}") from exc

    @classmethod
    def form(cls, initial: "SideMaskData | None" = None, parent: Any | None = None) -> "SideMaskData | None":
        """Open a Tkinter form and return a configured :class:`SideMaskData`.

        Returns ``None`` when the user cancels the dialog. Optional facade-related
        fields (``tangent_x``, ``tangent_y``, ``facade_normal_x``, ``facade_normal_y``)
        accept an empty value, which is interpreted as NaN (distant mask).
        """
        try:
            import tkinter as tk
            from tkinter import messagebox, ttk
        except ImportError as exc:
            raise RuntimeError("Tkinter is required to open SideMaskData.form().") from exc

        created_root = parent is None
        root_window = tk.Tk() if created_root else parent
        if created_root:
            root_window.withdraw()
        window = tk.Toplevel(root_window)
        window.title("SideMaskData")
        window.geometry("680x560")
        window.resizable(True, True)
        if not created_root:
            window.transient(parent)

        entries: dict[str, tk.Entry] = {}
        result: dict[str, SideMaskData | None] = {"value": None}
        pending_values: dict[str, Any] | None = None
        field_order: list[str] = [
            "name",
            "x_center",
            "y_center",
            "width",
            "height",
            "elevation",
            "exposure_deg",
            "slope_deg",
            "normal_angle_with_south_deg",
            "tangent_x",
            "tangent_y",
            "facade_normal_x",
            "facade_normal_y",
        ]
        defaults: dict[str, Any] = {
            "name": "side_mask",
            "x_center": 15.0,
            "y_center": 0.0,
            "width": 5.0,
            "height": 10.0,
            "elevation": 0.0,
            "exposure_deg": 0.0,
            "slope_deg": 90.0,
            "normal_angle_with_south_deg": 0.0,
            "tangent_x": float("nan"),
            "tangent_y": float("nan"),
            "facade_normal_x": float("nan"),
            "facade_normal_y": float("nan"),
        }

        def initial_value(name: str) -> str:
            if initial is not None:
                value = getattr(initial, name, defaults.get(name, ""))
            else:
                value = defaults.get(name, "")
            if value is None:
                return ""
            if isinstance(value, float) and value != value:
                return ""
            return str(value)

        outer_frame = ttk.Frame(window, padding=12)
        outer_frame.grid(row=0, column=0, sticky="nsew")
        window.columnconfigure(0, weight=1)
        window.rowconfigure(0, weight=1)
        outer_frame.columnconfigure(0, weight=1)
        outer_frame.rowconfigure(0, weight=1)

        canvas = tk.Canvas(outer_frame, highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer_frame, orient="vertical", command=canvas.yview)
        frame = ttk.Frame(canvas)
        frame_window = canvas.create_window((0, 0), window=frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        frame.columnconfigure(1, weight=1)

        def update_scroll_region(_event: Any = None) -> None:
            canvas.configure(scrollregion=canvas.bbox("all"))

        def update_inner_width(event: Any) -> None:
            canvas.itemconfigure(frame_window, width=event.width)

        def scroll_with_mousewheel(event: Any) -> None:
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        frame.bind("<Configure>", update_scroll_region)
        canvas.bind("<Configure>", update_inner_width)
        canvas.bind_all("<MouseWheel>", scroll_with_mousewheel)

        def cleanup_mousewheel_binding() -> None:
            try:
                canvas.unbind_all("<MouseWheel>")
            except tk.TclError:
                pass

        tooltip_window: tk.Toplevel | None = None

        def hide_tooltip() -> None:
            nonlocal tooltip_window
            if tooltip_window is not None:
                tooltip_window.destroy()
                tooltip_window = None

        def show_tooltip(event: Any, text: str) -> None:
            nonlocal tooltip_window
            hide_tooltip()
            tooltip_window = tk.Toplevel(window)
            tooltip_window.wm_overrideredirect(True)
            tooltip_window.wm_geometry(f"+{event.x_root + 12}+{event.y_root + 12}")
            label = tk.Label(
                tooltip_window,
                text=text,
                justify="left",
                background="#FFFFE0",
                relief="solid",
                borderwidth=1,
                padx=6,
                pady=4,
                wraplength=360,
            )
            label.pack()

        def move_tooltip(event: Any) -> None:
            if tooltip_window is not None:
                tooltip_window.wm_geometry(f"+{event.x_root + 12}+{event.y_root + 12}")

        def close_window() -> None:
            cleanup_mousewheel_binding()
            hide_tooltip()
            try:
                window.grab_release()
            except tk.TclError:
                pass
            try:
                window.destroy()
                if created_root:
                    root_window.quit()
            except tk.TclError:
                pass

        for row, name in enumerate(field_order):
            label = ttk.Label(frame, text=name)
            label.grid(row=row, column=0, padx=(0, 8), pady=3, sticky="e")
            help_text = cls.help(name)
            label.bind("<Enter>", lambda event, text=help_text: show_tooltip(event, text))
            label.bind("<Motion>", move_tooltip)
            label.bind("<Leave>", lambda _event: hide_tooltip())
            entry = ttk.Entry(frame, width=54)
            entry.insert(0, initial_value(name))
            entry.grid(row=row, column=1, pady=3, sticky="we")
            entries[name] = entry
            ttk.Button(frame, text="?", width=3, command=lambda n=name: messagebox.showinfo(n, cls.help(n), parent=window)).grid(row=row, column=2, padx=(6, 0), pady=3)

        def parse_float(name: str) -> float:
            text = entries[name].get().strip()
            if not text:
                raise ValueError(f"{name} is required.")
            return float(text)

        def parse_optional_nan(name: str) -> float:
            text = entries[name].get().strip()
            return float("nan") if not text else float(text)

        def submit() -> None:
            nonlocal pending_values
            try:
                values: dict[str, Any] = {
                    "name": entries["name"].get().strip(),
                    "x_center": parse_float("x_center"),
                    "y_center": parse_float("y_center"),
                    "width": parse_float("width"),
                    "height": parse_float("height"),
                    "elevation": parse_float("elevation"),
                    "exposure_deg": parse_float("exposure_deg"),
                    "slope_deg": parse_float("slope_deg"),
                    "normal_angle_with_south_deg": parse_float("normal_angle_with_south_deg"),
                    "tangent_x": parse_optional_nan("tangent_x"),
                    "tangent_y": parse_optional_nan("tangent_y"),
                    "facade_normal_x": parse_optional_nan("facade_normal_x"),
                    "facade_normal_y": parse_optional_nan("facade_normal_y"),
                }
            except (TypeError, ValueError) as exc:
                messagebox.showerror("Invalid SideMaskData", str(exc), parent=window)
                return
            pending_values = values
            close_window()

        def cancel() -> None:
            nonlocal pending_values
            result["value"] = None
            pending_values = None
            close_window()

        button_frame = ttk.Frame(frame)
        button_frame.grid(row=len(field_order), column=0, columnspan=3, pady=(10, 0), sticky="e")
        ttk.Button(button_frame, text="Cancel", command=cancel).grid(row=0, column=0, padx=(0, 8))
        ttk.Button(button_frame, text="OK", command=submit).grid(row=0, column=1)
        window.protocol("WM_DELETE_WINDOW", cancel)
        window.grab_set()
        entries["x_center"].focus_set()
        if created_root:
            root_window.mainloop()
        else:
            window.wait_window()
        cleanup_mousewheel_binding()
        try:
            root_window.destroy() if created_root else window.destroy()
        except tk.TclError:
            pass
        if pending_values is not None:
            result["value"] = cls(**pending_values)
        return result["value"]


@dataclass
class WindowData:
    floor_index: int
    mid_elevation_m: float
    exposure_deg: float
    surface_m2: float
    solar_factor: float


@dataclass
class FloorData:
    floor_index: int
    mid_elevation_m: float
    hsurface_m2: Vertices
    plain_vsurface_m2: float = 0.0
    windows_data: list[WindowData] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.glazing_vsurface_m2: float = 0.0
        for window_data in self.windows_data:
            self.glazing_vsurface_m2 += window_data.surface_m2


@dataclass(frozen=True)
class WallContactSpec:
    """Adiabatic-adjacent façade strip: same wall composition as :attr:`BuildingData.wall`, other side at fixed temperature.

    The strip is the footprint edge from vertex ``vertex_id`` to ``vertex_id+1`` (see :attr:`BuildingData.wall_contacts`),
    spanning ``n_floors`` occupied storeys upward from ``base_elevation`` (no glazing on that band).
    """

    zone_name: str
    side_index: int
    temperature_C: float
    n_floors: int


@dataclass
class ContextData:
    """Common context metadata shared by basic and complex building pipelines."""

    latitude_north_deg: float
    longitude_east_deg: float
    location: str
    albedo: float
    pollution: float
    ground_temperature: float
    starting_stringdate: str = None
    ending_stringdate: str = None
    number_of_levels: int = 3
    side_masks: list[SideMaskData] = field(default_factory=list)
    simulated_year: int = 2022

    @staticmethod
    def help(attribute_name: str) -> str:
        """Return a short explanation for one :class:`ContextData` attribute."""
        explanations: dict[str, str] = {
            "latitude_north_deg": "Site latitude in degrees north. Used to compute solar position and weather context.",
            "longitude_east_deg": "Site longitude in degrees east. Used with latitude and timezone-aware weather data for solar position.",
            "location": "Location name used to select or label weather data and reports.",
            "albedo": "Ground shortwave reflectance, from 0 to 1. Higher values increase reflected solar radiation.",
            "pollution": "Atmospheric pollution/aerosol factor used by the solar model when estimating clear-sky irradiance.",
            "ground_temperature": "Reference ground temperature in degrees Celsius for ground-contact heat exchange.",
            "starting_stringdate": "Optional simulation start date string. If omitted, it defaults to January 1 of simulated_year.",
            "ending_stringdate": "Optional simulation end date string. If omitted, it defaults to December 31 of simulated_year.",
            "number_of_levels": "Number of vertical levels requested from the weather/data provider when applicable.",
            "side_masks": "Distant/context shading obstacles applied globally to the solar model, independently of building facade indices.",
            "simulated_year": "Calendar year used for default simulation dates and heliodon plots.",
        }
        try:
            return explanations[attribute_name]
        except KeyError as exc:
            valid_names = ", ".join(sorted(explanations))
            raise ValueError(f"Unknown ContextData attribute '{attribute_name}'. Expected one of: {valid_names}") from exc

    @classmethod
    def form(cls, initial: "ContextData | None" = None, parent: Any | None = None) -> "ContextData | None":
        """Open a Tkinter form and return a configured :class:`ContextData`.

        Returns ``None`` when the user cancels the dialog. ``side_masks`` is
        edited as a JSON list of objects matching :class:`SideMaskData` fields.
        """
        try:
            import tkinter as tk
            from tkinter import messagebox, ttk
        except ImportError as exc:
            raise RuntimeError("Tkinter is required to open ContextData.form().") from exc

        created_root = parent is None
        root_window = tk.Tk() if created_root else parent
        if created_root:
            root_window.withdraw()
        window = tk.Toplevel(root_window)
        window.title("ContextData")
        window.geometry("760x520")
        window.resizable(True, True)
        if not created_root:
            window.transient(parent)

        entries: dict[str, tk.Entry] = {}
        result: dict[str, ContextData | None] = {"value": None}
        pending_values: dict[str, Any] | None = None
        field_order: list[str] = [
            "latitude_north_deg",
            "longitude_east_deg",
            "location",
            "albedo",
            "pollution",
            "ground_temperature",
            "starting_stringdate",
            "ending_stringdate",
            "number_of_levels",
            "side_masks",
            "simulated_year",
        ]

        def initial_value(name: str) -> str:
            if initial is not None:
                value = getattr(initial, name)
            else:
                value = {
                    "latitude_north_deg": 45.1916,
                    "longitude_east_deg": 5.7174,
                    "location": "Grenoble",
                    "albedo": 0.1,
                    "pollution": 0.1,
                    "ground_temperature": 13.0,
                    "starting_stringdate": "",
                    "ending_stringdate": "",
                    "number_of_levels": 3,
                    "side_masks": [],
                    "simulated_year": 2022,
                }.get(name, "")
            if name == "side_masks":
                masks: list[dict[str, float]] = [asdict(mask) for mask in value]
                return json.dumps(masks, indent=2)
            if value is None:
                return ""
            return str(value)

        outer_frame = ttk.Frame(window, padding=12)
        outer_frame.grid(row=0, column=0, sticky="nsew")
        window.columnconfigure(0, weight=1)
        window.rowconfigure(0, weight=1)
        outer_frame.columnconfigure(0, weight=1)
        outer_frame.rowconfigure(0, weight=1)

        canvas = tk.Canvas(outer_frame, highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer_frame, orient="vertical", command=canvas.yview)
        frame = ttk.Frame(canvas)
        frame_window = canvas.create_window((0, 0), window=frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        frame.columnconfigure(1, weight=1)

        def update_scroll_region(_event: Any = None) -> None:
            canvas.configure(scrollregion=canvas.bbox("all"))

        def update_inner_width(event: Any) -> None:
            canvas.itemconfigure(frame_window, width=event.width)

        def scroll_with_mousewheel(event: Any) -> None:
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        frame.bind("<Configure>", update_scroll_region)
        canvas.bind("<Configure>", update_inner_width)
        canvas.bind_all("<MouseWheel>", scroll_with_mousewheel)

        def cleanup_mousewheel_binding() -> None:
            try:
                canvas.unbind_all("<MouseWheel>")
            except tk.TclError:
                pass

        tooltip_window: tk.Toplevel | None = None

        def hide_tooltip() -> None:
            nonlocal tooltip_window
            if tooltip_window is not None:
                tooltip_window.destroy()
                tooltip_window = None

        def show_tooltip(event: Any, text: str) -> None:
            nonlocal tooltip_window
            hide_tooltip()
            tooltip_window = tk.Toplevel(window)
            tooltip_window.wm_overrideredirect(True)
            tooltip_window.wm_geometry(f"+{event.x_root + 12}+{event.y_root + 12}")
            label = tk.Label(
                tooltip_window,
                text=text,
                justify="left",
                background="#FFFFE0",
                relief="solid",
                borderwidth=1,
                padx=6,
                pady=4,
                wraplength=360,
            )
            label.pack()

        def move_tooltip(event: Any) -> None:
            if tooltip_window is not None:
                tooltip_window.wm_geometry(f"+{event.x_root + 12}+{event.y_root + 12}")

        def close_window() -> None:
            cleanup_mousewheel_binding()
            hide_tooltip()
            try:
                window.grab_release()
            except tk.TclError:
                pass
            try:
                window.destroy()
                if created_root:
                    root_window.quit()
            except tk.TclError:
                pass

        for row, name in enumerate(field_order):
            label = ttk.Label(frame, text=name)
            label.grid(row=row, column=0, padx=(0, 8), pady=3, sticky="e")
            help_text = cls.help(name)
            label.bind("<Enter>", lambda event, text=help_text: show_tooltip(event, text))
            label.bind("<Motion>", move_tooltip)
            label.bind("<Leave>", lambda _event: hide_tooltip())
            entry = ttk.Entry(frame, width=54)
            entry.insert(0, initial_value(name))
            entry.grid(row=row, column=1, pady=3, sticky="we")
            entries[name] = entry
            ttk.Button(frame, text="?", width=3, command=lambda n=name: messagebox.showinfo(n, cls.help(n), parent=window)).grid(row=row, column=2, padx=(6, 0), pady=3)

        def parse_float(name: str) -> float:
            text = entries[name].get().strip()
            if not text:
                raise ValueError(f"{name} is required.")
            return float(text)

        def parse_int(name: str) -> int:
            text = entries[name].get().strip()
            if not text:
                raise ValueError(f"{name} is required.")
            return int(text)

        def parse_optional_str(name: str) -> str | None:
            text = entries[name].get().strip()
            return text or None

        def parse_side_masks() -> list[SideMaskData]:
            text = entries["side_masks"].get().strip()
            if not text:
                return []
            raw_masks = json.loads(text)
            if not isinstance(raw_masks, list):
                raise ValueError("side_masks must be a JSON list of objects.")
            masks: list[SideMaskData] = []
            for index, raw_mask in enumerate(raw_masks):
                if not isinstance(raw_mask, dict):
                    raise ValueError(f"side_masks[{index}] must be an object.")
                masks.append(SideMaskData(**raw_mask))
            return masks

        def submit() -> None:
            nonlocal pending_values
            try:
                values: dict[str, Any] = {
                    "latitude_north_deg": parse_float("latitude_north_deg"),
                    "longitude_east_deg": parse_float("longitude_east_deg"),
                    "location": entries["location"].get().strip(),
                    "albedo": parse_float("albedo"),
                    "pollution": parse_float("pollution"),
                    "ground_temperature": parse_float("ground_temperature"),
                    "starting_stringdate": parse_optional_str("starting_stringdate"),
                    "ending_stringdate": parse_optional_str("ending_stringdate"),
                    "number_of_levels": parse_int("number_of_levels"),
                    "side_masks": parse_side_masks(),
                    "simulated_year": parse_int("simulated_year"),
                }
            except (TypeError, ValueError, json.JSONDecodeError) as exc:
                messagebox.showerror("Invalid ContextData", str(exc), parent=window)
                return
            pending_values = values
            close_window()

        def cancel() -> None:
            nonlocal pending_values
            result["value"] = None
            pending_values = None
            close_window()

        button_frame = ttk.Frame(frame)
        button_frame.grid(row=len(field_order), column=0, columnspan=3, pady=(10, 0), sticky="e")
        ttk.Button(button_frame, text="Cancel", command=cancel).grid(row=0, column=0, padx=(0, 8))
        ttk.Button(button_frame, text="OK", command=submit).grid(row=0, column=1)
        window.protocol("WM_DELETE_WINDOW", cancel)
        window.grab_set()
        entries["latitude_north_deg"].focus_set()
        if created_root:
            root_window.mainloop()
        else:
            window.wait_window()
        cleanup_mousewheel_binding()
        try:
            root_window.destroy() if created_root else window.destroy()
        except tk.TclError:
            pass
        if pending_values is not None:
            result["value"] = cls(**pending_values)
        return result["value"]


@dataclass
class BuildingData:
    """Physical and operational parameters defining a BATEM building model.

    This dataclass stores the geometry, material compositions, HVAC capacities,
    and occupant-related assumptions used when generating thermal networks and
    control systems.

    :param footprint: Closed or open polygon ``(x, y)`` points in meters (first
        point is repeated when closing the loop).
    :param side_glazing_ratios: One ratio per façade segment after closure, or a single
        value broadcast to all sides. Drives ``ref_glazing_ratio`` … ``left_glazing_ratio``
        (indices ``0 … 3`` modulo ``n_sides``) for the rectangular :class:`ZoneFloor` model.
    :param n_floors: Number of occupied floors (excluding the basement zone).
    :param floor_height: Storey height in metres for regular floors.
    :param base_elevation: Basement height in metres.
    :param z_rotation_angle_deg: Clockwise rotation of the building footprint.
    :param glazing_solar_factor: Solar heat gain coefficient applied to glazing.
    :param shutter_closed_temperature: Outdoor temperature threshold (°C) above which
        shutters are closed and solar gains are set to 0. If None, shutters are never closed.
    :param compositions: Mapping of envelope component names to layer tuples
        ``(material_name, thickness_m)``.
    :param max_heating_power: Maximum heating power available per zone in watts.
    :param max_cooling_power: Maximum cooling power available per zone in watts.
    :param body_metabolism: Basal metabolic heat production per occupant in watts (typically 100W).
    :param occupant_consumption: Additional heat gains per occupant from activities and appliances in watts (typically 150W).
    :param body_PCO2: CO₂ production per occupant in litres per hour.
    :param density_occupants_per_100m2: Occupant density used for gain profiles.
    :param regular_air_renewal_rate_vol_per_hour: Baseline ventilation rate used
        for nominal operation (volumes per hour).
    :param super_air_renewal_rate_vol_per_hour: Ventilation rate applied during
        forced ventilation or free-cooling strategies (volumes per hour).
    :param initial_temperature: Initial temperature (°C) for all thermal states.
    :param low_heating_setpoint: Setback heating setpoint in degrees Celsius.
    :param normal_heating_setpoint: Comfort heating setpoint in degrees Celsius.
    :param high_heating_setpoint: Boost heating setpoint in degrees Celsius.
    :param state_model_order_max: Optional upper bound for balanced-truncation ROM order.
        **Very small values** (e.g. 3) can yield an unusable reduced model (near-zero
        temperatures and zero ``PHVAC``). Prefer ``None`` (full order) or a moderate
        bound (often ≥ 8–12) until the reduction pipeline is tuned for your case.
    :param periodic_depth_seconds: Maximum penetration depth for periodic inputs.
    :param wall_contacts: Optional façades in contact with a fixed-temperature boundary (e.g. built
        against an unmodeled adjacent volume). Each entry is a mapping with ``vertex_id`` (footprint
        edge index, side from vertex ``vertex_id`` to ``vertex_id+1``), ``temperature_C``, and
        ``n_floors`` (number of occupied storeys spanned from ``base_elevation``, same composition as
        ``inout_wall``, no glazing on that vertical band). ``None`` or empty disables the feature.
    :param max_control_delta_W: Optional maximum absolute per-hour change of HVAC control
        command (W). ``None`` disables ramp limiting.
    :param max_abs_control_W: Optional absolute cap on HVAC command magnitude (W)
        applied by the controller. ``None`` disables the cap.
    :param temperature_smoothing_alpha: Optional exponential smoothing of the **stored**
        time series for ``TZ:*#sim`` / ``TZ_OP:*#sim`` only: each sample is
        ``alpha * (model output) + (1-alpha) * (previous stored sample)``. The simulation
        state update still uses the unsmoothed model; smoothing only **lags and damps**
        the recorded curve, so use ``None`` (or ``1.0``) when you need trajectories that
        match the RC outputs (e.g. flat indoor temperature under a flat setpoint).
        Must be in ``(0, 1]`` when set. ``None`` disables smoothing.
    :param temperature_anti_windup_deadband_deg: Passed to :class:`~batem.core.control.Simulation`:
        margin (°C) before anti-windup clips extra HVAC against the preview setpoint.
        ``None`` disables that clipping. Default ``0.3`` avoids fighting the k+1 inverse.
    :param compositions: mapping with keys such as ``wall``, ``roof``, ``glazing``, ``ground_floor``,
        and optionally ``intermediate_floor``, ``basement_floor``; values are layer tuples
        ``(material_name, thickness_m)``.
    """
    footprint: Vertices
    side_glazing_ratios: list[float]    # Variations
    n_floors: int
    floor_height: float
    base_elevation: float
    z_rotation_angle_deg: float    # Variations
    glazing_solar_factor: float    # Variations
    compositions: dict[str, tuple[tuple[str, float], ...]]
    max_floor_heating_power: float
    max_floor_cooling_power: float
    density_occupants_per_100m2: float
    initial_temperature: float
    low_heating_setpoint: float    # Variations
    normal_heating_setpoint: float    # Variations
    normal_cooling_setpoint: float    # Variations
    regular_air_renewal_rate_vol_per_hour: float    # Variations
    super_air_renewal_rate_vol_per_hour: float | None = None
    body_metabolism: float = 100.0
    occupant_consumption: float = 150.0
    body_PCO2: float = 7.0
    shutter_closed_temperature: float | None = None  # if not None, shutters are closed and solar gains are set to 0 when outdoor temperature exceeds this threshold
    free_cooling_setpoint_margin: float | None = None
    long_absence_period: tuple[str, str] = ('1/8', '15/8')
    heating_period: tuple[str, str] = ('1/11', '1/5')
    cooling_period: tuple[str, str] = ('1/6', '30/9')
    hvac_cop_heating: float = 3.5
    hvac_cop_cooling: float = 3.5
    regular_ventilation_heat_recovery_efficiency: float = 0.8      # Variations
    state_model_order_max: int | None = None
    periodic_depth_seconds: int = 3600
    wall_contacts: Sequence[Mapping[str, int | float]] | None = None
    max_control_delta_W: float | None = None
    max_abs_control_W: float | None = None
    temperature_smoothing_alpha: float | None = None
    temperature_anti_windup_deadband_deg: float | None = None

    @staticmethod
    def help(attribute_name: str) -> str:
        """Return a short explanation for one :class:`BuildingData` attribute."""
        explanations: dict[str, str] = {
            "footprint": (
                "Building polygon vertices in metres (plan view). The ring may be open or "
                "already closed; the first point is repeated automatically if needed.\n\n"
                "Allowed string (whole text box), either form:\n"
                "  JSON — list of [x,y] pairs, numbers in strict JSON, e.g.\n"
                "    [[0,0],[10,0],[10,10],[20,10],[20,0],[30,0],[30,4],[20,4],[20,2],[10,20],[10,40],[0,40]]\n"
                "  Python literal — list of (x,y) tuples, e.g.\n"
                "    [(0,0),(10,0),(10,10),(0,10)]\n\n"
                "The editor tries JSON first, then a safe Python literal (ast.literal_eval)."
            ),
            "side_glazing_ratios": "Glazing ratio per facade segment, or one value broadcast to all segments. This controls window area, not glazing solar factor.",
            "n_floors": "Number of occupied floors above the optional basement/base elevation.",
            "floor_height": "Height of each regular occupied floor in metres.",
            "base_elevation": "Elevation of the first occupied floor above ground in metres. A positive value creates a basement/base zone.",
            "z_rotation_angle_deg": "Clockwise rotation angle applied to the footprint in plan before geometry is computed.",
            "glazing_solar_factor": "Solar heat gain factor applied to glazing collectors. A value of 0 keeps windows but gives them zero solar gain.",
            "compositions": (
                "Envelope multilayer stacks: one object mapping component names to lists of "
                "[material_name, thickness_metres]. Material names must exist in the BATEM library.\n\n"
                "Keys used by the model: inout_wall, inout_roof, inout_glazing, floor_ground; "
                "basement_ground and lowup_floor when those zones apply.\n\n"
                "Allowed string (whole text box), either form:\n"
                "  JSON — strict JSON (thickness as 0.15, not .15), e.g. one line or pretty-printed:\n"
                '    {"inout_wall":[["plaster",0.013],["insulation",0.15],["brick",0.1]],\n'
                '     "inout_roof":[["plaster",0.013],["insulation",0.15],["concrete",0.1]],\n'
                '     "inout_glazing":[["glass",0.004],["air",0.016],["glass",0.004]],\n'
                '     "floor_ground":[["wood",0.01],["insulation",0.15],["concrete",0.2]],\n'
                '     "basement_ground":[["concrete",0.2],["insulation",0.15],["wood",0.01]],\n'
                '     "lowup_floor":[["plaster",0.013],["concrete",0.13],["wood",0.01]]}\n'
                "  Python dict literal — same keys and lists; .15 is allowed, e.g.\n"
                '    {"inout_wall": [["plaster", 0.013], ["insulation", .15], ["brick", 0.1]]}\n\n'
                "The editor tries JSON first, then ast.literal_eval for Python literals."
            ),
            "max_floor_heating_power": "Maximum available heating power per occupied floor, in watts.",
            "max_floor_cooling_power": "Maximum available cooling power per occupied floor, in watts.",
            "density_occupants_per_100m2": "Occupant density used to derive internal gains and CO2 production, expressed per 100 m2 of floor area.",
            "initial_temperature": "Initial indoor temperature in degrees Celsius for thermal states at simulation start.",
            "low_heating_setpoint": "Reduced heating setpoint in degrees Celsius, used during low-demand periods.",
            "normal_heating_setpoint": "Normal heating comfort setpoint in degrees Celsius.",
            "normal_cooling_setpoint": "Normal cooling comfort setpoint in degrees Celsius.",
            "regular_air_renewal_rate_vol_per_hour": "Nominal outdoor air renewal rate, in building volumes per hour.",
            "super_air_renewal_rate_vol_per_hour": "Optional boosted air renewal rate, in volumes per hour, for forced ventilation or free-cooling.",
            "body_metabolism": "Basal sensible heat production per occupant in watts.",
            "occupant_consumption": "Additional heat gains per occupant from activities and appliances, in watts.",
            "body_PCO2": "CO2 production per occupant, in litres per hour.",
            "shutter_closed_temperature": "Outdoor temperature threshold in degrees Celsius above which shutters close and glazing solar gains are set to zero. None disables this rule.",
            "free_cooling_setpoint_margin": "Optional temperature margin used to trigger free-cooling around the cooling setpoint. None disables free-cooling logic.",
            "long_absence_period": "Date range for long absence behavior, as start/end strings such as ('1/8', '15/8').",
            "heating_period": "Date range during which heating control is active, as start/end strings.",
            "cooling_period": "Date range during which cooling control is active, as start/end strings.",
            "hvac_cop_heating": "Coefficient of performance used to convert delivered heating to electrical energy.",
            "hvac_cop_cooling": "Coefficient of performance used to convert delivered cooling to electrical energy.",
            "regular_ventilation_heat_recovery_efficiency": "Efficiency of heat recovery on regular ventilation airflow, from 0 to 1.",
            "state_model_order_max": "Optional maximum order for thermal state-model reduction. None keeps the full-order model.",
            "periodic_depth_seconds": "Maximum penetration depth in seconds used for periodic thermal inputs.",
            "wall_contacts": "Optional facade segments in contact with fixed-temperature adjacent zones. Entries define vertex_id, temperature_C, and n_floors.",
            "max_control_delta_W": "Optional maximum absolute per-hour change of HVAC control command (W). None disables ramp limiting.",
            "max_abs_control_W": "Optional absolute cap on HVAC command magnitude (W). None disables the cap.",
            "temperature_smoothing_alpha": "Optional exponential smoothing of stored TZ simulation traces; None or 1.0 disables.",
            "temperature_anti_windup_deadband_deg": "Anti-windup margin (°C) for HVAC preview clipping; None disables.",
        }
        try:
            return explanations[attribute_name]
        except KeyError as exc:
            valid_names = ", ".join(sorted(explanations))
            raise ValueError(f"Unknown BuildingData attribute '{attribute_name}'. Expected one of: {valid_names}") from exc

    @classmethod
    def form(cls, initial: "BuildingData | None" = None, parent: Any | None = None) -> "BuildingData | None":
        """Open a Tkinter form and return a configured :class:`BuildingData`.

        Returns ``None`` when the user cancels the dialog. Structured fields use
        JSON in the text boxes; ``footprint`` and ``compositions`` also accept
        Python literals if JSON parsing fails (e.g. ``(x,y)`` tuples for footprint,
        ``.15`` for thickness in a dict). Other structured fields are
        ``side_glazing_ratios``, date periods, and ``wall_contacts``.
        """
        try:
            import tkinter as tk
            from tkinter import messagebox, ttk
        except ImportError as exc:
            raise RuntimeError("Tkinter is required to open BuildingData.form().") from exc

        created_root = parent is None
        root_window = tk.Tk() if created_root else parent
        if created_root:
            root_window.withdraw()
        window = tk.Toplevel(root_window)
        window.title("BuildingData")
        window.geometry("960x760")
        window.resizable(True, True)
        if not created_root:
            window.transient(parent)

        result: dict[str, BuildingData | None] = {"value": None}
        pending_values: dict[str, Any] | None = None
        widgets: dict[str, Any] = {}
        field_order: list[str] = [
            "footprint",
            "side_glazing_ratios",
            "n_floors",
            "floor_height",
            "base_elevation",
            "z_rotation_angle_deg",
            "glazing_solar_factor",
            "compositions",
            "max_floor_heating_power",
            "max_floor_cooling_power",
            "density_occupants_per_100m2",
            "initial_temperature",
            "low_heating_setpoint",
            "normal_heating_setpoint",
            "normal_cooling_setpoint",
            "regular_air_renewal_rate_vol_per_hour",
            "super_air_renewal_rate_vol_per_hour",
            "body_metabolism",
            "occupant_consumption",
            "body_PCO2",
            "shutter_closed_temperature",
            "free_cooling_setpoint_margin",
            "long_absence_period",
            "heating_period",
            "cooling_period",
            "hvac_cop_heating",
            "hvac_cop_cooling",
            "regular_ventilation_heat_recovery_efficiency",
            "state_model_order_max",
            "periodic_depth_seconds",
            "wall_contacts",
        ]
        structured_fields: set[str] = {
            "footprint",
            "side_glazing_ratios",
            "compositions",
            "long_absence_period",
            "heating_period",
            "cooling_period",
            "wall_contacts",
        }
        defaults: dict[str, Any] = {
            "footprint": [(0.0, 0.0), (0.0, 5.0), (10.0, 5.0), (10.0, 0.0)],
            "side_glazing_ratios": [0.25],
            "n_floors": 4,
            "floor_height": 3.0,
            "base_elevation": 1.0,
            "z_rotation_angle_deg": 0.0,
            "glazing_solar_factor": 0.6,
            "compositions": {
                "inout_wall": (("plaster", 0.013), ("insulation", 0.15), ("brick", 0.1)),
                "inout_roof": (("plaster", 0.013), ("insulation", 0.15), ("concrete", 0.1)),
                "inout_glazing": (("glass", 0.004), ("air", 0.016), ("glass", 0.004)),
                "floor_ground": (("wood", 0.01), ("insulation", 0.15), ("concrete", 0.2)),
                "basement_ground": (("concrete", 0.2), ("insulation", 0.15), ("wood", 0.01)),
                "lowup_floor": (("plaster", 0.013), ("concrete", 0.13), ("wood", 0.01)),
            },
            "max_floor_heating_power": None,
            "max_floor_cooling_power": None,
            "density_occupants_per_100m2": 4.0,
            "initial_temperature": 19.0,
            "low_heating_setpoint": 16.0,
            "normal_heating_setpoint": 19.0,
            "normal_cooling_setpoint": 26.0,
            "regular_air_renewal_rate_vol_per_hour": 3.0,
            "super_air_renewal_rate_vol_per_hour": None,
            "body_metabolism": 100.0,
            "occupant_consumption": 150.0,
            "body_PCO2": 7.0,
            "shutter_closed_temperature": None,
            "free_cooling_setpoint_margin": None,
            "long_absence_period": ('1/8', '15/8'),
            "heating_period": ('1/11', '1/5'),
            "cooling_period": ('1/6', '30/9'),
            "hvac_cop_heating": 3.5,
            "hvac_cop_cooling": 3.5,
            "regular_ventilation_heat_recovery_efficiency": 0.8,
            "state_model_order_max": None,
            "periodic_depth_seconds": 3600,
            "wall_contacts": None,
        }

        def initial_value(name: str) -> str:
            if initial is not None:
                value = getattr(initial, name)
            else:
                value = defaults.get(name, "")
            if name in structured_fields:
                return "" if value is None else json.dumps(value)
            return "" if value is None else str(value)

        outer_frame = ttk.Frame(window, padding=12)
        outer_frame.grid(row=0, column=0, sticky="nsew")
        window.columnconfigure(0, weight=1)
        window.rowconfigure(0, weight=1)
        outer_frame.columnconfigure(0, weight=1)
        outer_frame.rowconfigure(0, weight=1)

        canvas = tk.Canvas(outer_frame, highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer_frame, orient="vertical", command=canvas.yview)
        frame = ttk.Frame(canvas)
        frame_window = canvas.create_window((0, 0), window=frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        frame.columnconfigure(1, weight=1)

        def update_scroll_region(_event: Any = None) -> None:
            canvas.configure(scrollregion=canvas.bbox("all"))

        def update_inner_width(event: Any) -> None:
            canvas.itemconfigure(frame_window, width=event.width)

        def scroll_with_mousewheel(event: Any) -> None:
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        frame.bind("<Configure>", update_scroll_region)
        canvas.bind("<Configure>", update_inner_width)
        canvas.bind_all("<MouseWheel>", scroll_with_mousewheel)

        def cleanup_mousewheel_binding() -> None:
            try:
                canvas.unbind_all("<MouseWheel>")
            except tk.TclError:
                pass

        tooltip_window: tk.Toplevel | None = None

        def hide_tooltip() -> None:
            nonlocal tooltip_window
            if tooltip_window is not None:
                tooltip_window.destroy()
                tooltip_window = None

        def show_tooltip(event: Any, text: str) -> None:
            nonlocal tooltip_window
            hide_tooltip()
            tooltip_window = tk.Toplevel(window)
            tooltip_window.wm_overrideredirect(True)
            tooltip_window.wm_geometry(f"+{event.x_root + 12}+{event.y_root + 12}")
            label = tk.Label(
                tooltip_window,
                text=text,
                justify="left",
                background="#FFFFE0",
                relief="solid",
                borderwidth=1,
                padx=6,
                pady=4,
                wraplength=420,
            )
            label.pack()

        def move_tooltip(event: Any) -> None:
            if tooltip_window is not None:
                tooltip_window.wm_geometry(f"+{event.x_root + 12}+{event.y_root + 12}")

        def close_window() -> None:
            cleanup_mousewheel_binding()
            hide_tooltip()
            try:
                window.grab_release()
            except tk.TclError:
                pass
            try:
                window.destroy()
                if created_root:
                    root_window.quit()
            except tk.TclError:
                pass

        for row, name in enumerate(field_order):
            label = ttk.Label(frame, text=name)
            label.grid(row=row, column=0, padx=(0, 8), pady=3, sticky="ne")
            help_text = cls.help(name)
            label.bind("<Enter>", lambda event, text=help_text: show_tooltip(event, text))
            label.bind("<Motion>", move_tooltip)
            label.bind("<Leave>", lambda _event: hide_tooltip())

            if name in structured_fields:
                height = 8 if name == "compositions" else 3
                widget = tk.Text(frame, width=70, height=height, wrap="none")
                widget.insert("1.0", initial_value(name))
                widget.grid(row=row, column=1, pady=3, sticky="we")
            else:
                widget = ttk.Entry(frame, width=70)
                widget.insert(0, initial_value(name))
                widget.grid(row=row, column=1, pady=3, sticky="we")
            widgets[name] = widget
            ttk.Button(frame, text="?", width=3, command=lambda n=name: messagebox.showinfo(n, cls.help(n), parent=window)).grid(row=row, column=2, padx=(6, 0), pady=3, sticky="n")

        def value_text(name: str) -> str:
            widget = widgets[name]
            if isinstance(widget, tk.Text):
                return widget.get("1.0", "end").strip()
            return widget.get().strip()

        def parse_float(name: str) -> float:
            text = value_text(name)
            if not text:
                raise ValueError(f"{name} is required.")
            return float(text)

        def parse_optional_float(name: str) -> float | None:
            text = value_text(name)
            return None if not text else float(text)

        def parse_int(name: str) -> int:
            text = value_text(name)
            if not text:
                raise ValueError(f"{name} is required.")
            return int(text)

        def parse_optional_int(name: str) -> int | None:
            text = value_text(name)
            return None if not text else int(text)

        class FormParseError(ValueError):
            """User-facing parse/validation error with field context."""

            def __init__(self, field_name: str, detail: str) -> None:
                super().__init__(detail)
                self.field_name = field_name
                self.detail = detail

        def _format_parser_location(exc: BaseException) -> str:
            """Return compact parser location/type details when available."""
            if isinstance(exc, json.JSONDecodeError):
                return f"{type(exc).__name__} at line {exc.lineno}, column {exc.colno}: {exc.msg}"
            if isinstance(exc, SyntaxError):
                line = exc.lineno if exc.lineno is not None else "?"
                col = exc.offset if exc.offset is not None else "?"
                msg = exc.msg if exc.msg else "invalid syntax"
                return f"{type(exc).__name__} at line {line}, column {col}: {msg}"
            return f"{type(exc).__name__}: {str(exc)}"

        def _raise_form_parse_error(field_name: str, detail: str, *, cause: BaseException | None = None) -> None:
            if cause is not None:
                detail = f"{detail}\nCause: {_format_parser_location(cause)}"
            raise FormParseError(field_name, detail) from cause

        def parse_json(name: str, *, required: bool = True) -> Any:
            text = value_text(name)
            if not text:
                if required:
                    _raise_form_parse_error(name, f"{name} is required.")
                return None
            try:
                return json.loads(text)
            except json.JSONDecodeError as exc:
                _raise_form_parse_error(name, f"{name} must be valid JSON.", cause=exc)

        def parse_footprint() -> Vertices:
            text = value_text("footprint")
            if not text:
                _raise_form_parse_error("footprint", "footprint is required.")
            try:
                raw = json.loads(text)
            except json.JSONDecodeError as json_exc:
                try:
                    raw = ast.literal_eval(text)
                except (ValueError, SyntaxError) as py_exc:
                    _raise_form_parse_error(
                        "footprint",
                        "footprint must be valid JSON (e.g. [[0,0],[10,0],...]) "
                        "or a Python literal list of (x,y) or [x,y] pairs.\n"
                        f"JSON parser: {_format_parser_location(json_exc)}",
                        cause=py_exc,
                    )
            if not isinstance(raw, list):
                _raise_form_parse_error("footprint", "footprint must be a list of [x, y] or (x, y) points.")
            vertices: Vertices = []
            for index, point in enumerate(raw):
                if isinstance(point, (list, tuple)) and len(point) >= 2:
                    vertices.append((float(point[0]), float(point[1])))
                else:
                    _raise_form_parse_error("footprint", f"footprint[{index}] must be [x, y] or (x, y), got {point!r}.")
            return vertices

        def parse_float_list(name: str) -> list[float]:
            raw = parse_json(name)
            if not isinstance(raw, list):
                _raise_form_parse_error(name, f"{name} must be a JSON list of numbers.")
            return [float(value) for value in raw]

        def parse_compositions() -> dict[str, tuple[tuple[str, float], ...]]:
            text = value_text("compositions")
            if not text:
                _raise_form_parse_error("compositions", "compositions is required.")
            try:
                raw = json.loads(text)
            except json.JSONDecodeError as json_exc:
                try:
                    raw = ast.literal_eval(text)
                except (ValueError, SyntaxError) as py_exc:
                    _raise_form_parse_error(
                        "compositions",
                        "compositions must be valid JSON (object mapping keys to lists of "
                        "[material, thickness], use 0.15 not .15) or an equivalent Python dict literal.\n"
                        f"JSON parser: {_format_parser_location(json_exc)}",
                        cause=py_exc,
                    )
            if not isinstance(raw, dict):
                _raise_form_parse_error("compositions", "compositions must be a JSON object or Python dict.")
            compositions: dict[str, tuple[tuple[str, float], ...]] = {}
            for component_name, layers in raw.items():
                if not isinstance(layers, list):
                    _raise_form_parse_error("compositions", f"compositions[{component_name!r}] must be a list of [material, thickness] layers.")
                compositions[str(component_name)] = tuple((str(layer[0]), float(layer[1])) for layer in layers)
            return compositions

        def parse_period(name: str) -> tuple[str, str]:
            raw = parse_json(name)
            if not isinstance(raw, list) or len(raw) != 2:
                _raise_form_parse_error(name, f"{name} must be a JSON list with two date strings.")
            return (str(raw[0]), str(raw[1]))

        def parse_wall_contacts() -> Sequence[Mapping[str, int | float]] | None:
            raw = parse_json("wall_contacts", required=False)
            if raw is None:
                return None
            if not isinstance(raw, list):
                _raise_form_parse_error("wall_contacts", "wall_contacts must be empty or a JSON list of objects.")
            for index, spec in enumerate(raw):
                if not isinstance(spec, dict):
                    _raise_form_parse_error("wall_contacts", f"wall_contacts[{index}] must be an object.")
            return raw

        def submit() -> None:
            nonlocal pending_values
            try:
                values: dict[str, Any] = {
                    "footprint": parse_footprint(),
                    "side_glazing_ratios": parse_float_list("side_glazing_ratios"),
                    "n_floors": parse_int("n_floors"),
                    "floor_height": parse_float("floor_height"),
                    "base_elevation": parse_float("base_elevation"),
                    "z_rotation_angle_deg": parse_float("z_rotation_angle_deg"),
                    "glazing_solar_factor": parse_float("glazing_solar_factor"),
                    "compositions": parse_compositions(),
                    "max_floor_heating_power": parse_optional_float("max_floor_heating_power"),
                    "max_floor_cooling_power": parse_optional_float("max_floor_cooling_power"),
                    "density_occupants_per_100m2": parse_float("density_occupants_per_100m2"),
                    "initial_temperature": parse_float("initial_temperature"),
                    "low_heating_setpoint": parse_float("low_heating_setpoint"),
                    "normal_heating_setpoint": parse_float("normal_heating_setpoint"),
                    "normal_cooling_setpoint": parse_float("normal_cooling_setpoint"),
                    "regular_air_renewal_rate_vol_per_hour": parse_float("regular_air_renewal_rate_vol_per_hour"),
                    "super_air_renewal_rate_vol_per_hour": parse_optional_float("super_air_renewal_rate_vol_per_hour"),
                    "body_metabolism": parse_float("body_metabolism"),
                    "occupant_consumption": parse_float("occupant_consumption"),
                    "body_PCO2": parse_float("body_PCO2"),
                    "shutter_closed_temperature": parse_optional_float("shutter_closed_temperature"),
                    "free_cooling_setpoint_margin": parse_optional_float("free_cooling_setpoint_margin"),
                    "long_absence_period": parse_period("long_absence_period"),
                    "heating_period": parse_period("heating_period"),
                    "cooling_period": parse_period("cooling_period"),
                    "hvac_cop_heating": parse_float("hvac_cop_heating"),
                    "hvac_cop_cooling": parse_float("hvac_cop_cooling"),
                    "regular_ventilation_heat_recovery_efficiency": parse_float("regular_ventilation_heat_recovery_efficiency"),
                    "state_model_order_max": parse_optional_int("state_model_order_max"),
                    "periodic_depth_seconds": parse_int("periodic_depth_seconds"),
                    "wall_contacts": parse_wall_contacts(),
                }
            except FormParseError as exc:
                messagebox.showerror("Invalid BuildingData", f"Field: {exc.field_name}\n{exc.detail}", parent=window)
                widget = widgets.get(exc.field_name)
                if widget is not None:
                    widget.focus_set()
                    if isinstance(widget, tk.Text):
                        widget.mark_set("insert", "1.0")
                        widget.see("insert")
                return
            except (IndexError, TypeError, ValueError, json.JSONDecodeError) as exc:
                messagebox.showerror(
                    "Invalid BuildingData",
                    f"{type(exc).__name__}: {exc}",
                    parent=window,
                )
                return
            pending_values = values
            close_window()

        def cancel() -> None:
            nonlocal pending_values
            result["value"] = None
            pending_values = None
            close_window()

        button_frame = ttk.Frame(frame)
        button_frame.grid(row=len(field_order), column=0, columnspan=3, pady=(10, 0), sticky="e")
        ttk.Button(button_frame, text="Cancel", command=cancel).grid(row=0, column=0, padx=(0, 8))
        ttk.Button(button_frame, text="OK", command=submit).grid(row=0, column=1)
        window.protocol("WM_DELETE_WINDOW", cancel)
        window.grab_set()
        widgets["footprint"].focus_set()
        if created_root:
            root_window.mainloop()
        else:
            window.wait_window()
        cleanup_mousewheel_binding()
        try:
            root_window.destroy() if created_root else window.destroy()
        except tk.TclError:
            pass
        if pending_values is not None:
            result["value"] = cls(**pending_values)
        return result["value"]

    def __post_init__(self) -> None:
        """Close and rotate the footprint, validate inputs, then fill derived geometry."""
        self._close_footprint()
        if self.z_rotation_angle_deg != 0:
            self.footprint = rotate(self.footprint, self.z_rotation_angle_deg)
        polygon: Polygon = Polygon(self.footprint)
        if not polygon.is_simple():
            polygon.footprint_plot(False)
            raise ValueError("Footprint is not forming a simple polygon")
        self.has_basement: bool = self.base_elevation > 0

        self.n_sides = len(self.footprint) - 1
        self._normalize_side_glazing_ratios()
        self._require_composition_keys()
        self._attach_composition_sides()
        self._compute_geometry()
        self._apply_wall_contacts()
        self._compute_window_local_masks()

    def plot_footprint(self) -> None:
        polygon: Polygon = Polygon(self.footprint)
        polygon.footprint_plot()

    def copy(self) -> Self:
        return BuildingData(
            footprint=self.footprint,
            side_glazing_ratios=self.side_glazing_ratios,
            n_floors=self.n_floors,
            floor_height=self.floor_height,
            base_elevation=self.base_elevation,
            z_rotation_angle_deg=self.z_rotation_angle_deg,
            glazing_solar_factor=self.glazing_solar_factor,
            compositions=self.compositions,
            max_floor_heating_power=self.max_floor_heating_power,
            max_floor_cooling_power=self.max_floor_cooling_power,
            density_occupants_per_100m2=self.density_occupants_per_100m2,
            initial_temperature=self.initial_temperature,
            low_heating_setpoint=self.low_heating_setpoint,
            normal_heating_setpoint=self.normal_heating_setpoint,
            normal_cooling_setpoint=self.normal_cooling_setpoint,
            regular_air_renewal_rate_vol_per_hour=self.regular_air_renewal_rate_vol_per_hour,
            super_air_renewal_rate_vol_per_hour=self.super_air_renewal_rate_vol_per_hour,
            body_metabolism=self.body_metabolism,
            occupant_consumption=self.occupant_consumption,
            body_PCO2=self.body_PCO2,
            shutter_closed_temperature=self.shutter_closed_temperature,
            free_cooling_setpoint_margin=self.free_cooling_setpoint_margin,
            long_absence_period=self.long_absence_period,
            heating_period=self.heating_period,
            cooling_period=self.cooling_period,
            hvac_cop_heating=self.hvac_cop_heating,
            hvac_cop_cooling=self.hvac_cop_cooling,
            regular_ventilation_heat_recovery_efficiency=self.regular_ventilation_heat_recovery_efficiency,
            state_model_order_max=self.state_model_order_max,
            periodic_depth_seconds=self.periodic_depth_seconds,
            wall_contacts=self.wall_contacts,
            # max_control_delta_W=self.max_control_delta_W,
            # max_abs_control_W=self.max_abs_control_W,
            # temperatue_smoothing_alpha=self.temperature_smoothing_alpha,
            # temperature_anti_windup_deadband_deg=self.temperature_anti_windup_deadband_deg,
        )

    def _close_footprint(self) -> None:
        if self.footprint[0] != self.footprint[-1]:
            self.footprint.append(self.footprint[0])

    def _normalize_side_glazing_ratios(self) -> None:
        ratios: list[float] = self.side_glazing_ratios
        if len(ratios) == 1:
            self.side_glazing_ratios = [float(ratios[0])] * self.n_sides
        elif len(ratios) == self.n_sides:
            self.side_glazing_ratios = [float(x) for x in ratios]
        else:
            raise ValueError(
                f"Number of sides ({self.n_sides}) does not match number of glazing ratios ({len(ratios)})"
            )

    def _require_composition_keys(self) -> None:
        required: list[str] = ['inout_wall', 'inout_roof', 'inout_glazing', 'floor_ground']
        if self.n_floors > 1:
            required.append('lowup_floor')
        if self.base_elevation > 0:
            required.append('basement_ground')
        missing: list[str] = [key for key in required if key not in self.compositions]
        if missing:
            raise ValueError(f"Missing compositions for: {', '.join(missing)}")

    def _attach_composition_sides(self) -> None:
        self.wall: Side = Side(*self.compositions['inout_wall'])
        self.roof: Side = Side(*self.compositions['inout_roof'])
        self.glazing: Side = Side(*self.compositions['inout_glazing'])
        self.ground_floor: Side = Side(*self.compositions['floor_ground'])
        if 'lowup_floor' in self.compositions:
            self.intermediate_floor = Side(*self.compositions['lowup_floor'])
        else:
            self.intermediate_floor = None
        if 'basement_ground' in self.compositions:
            self.basement_floor = Side(*self.compositions['basement_ground'])
        else:
            self.basement_floor = None

    def _compute_geometry(self) -> None:
        if len(self.footprint) < 3:
            raise ValueError(f"Perimeter points must have at least 3 points, got {len(self.footprint)}")

        # Use footprint winding to pick the outward normal consistently:
        # - CCW polygon: outside is on the right of each directed edge
        # - CW polygon:  outside is on the left of each directed edge
        signed_twice_area = 0.0
        for i in range(self.n_sides):
            x1, y1 = self.footprint[i]
            x2, y2 = self.footprint[i + 1]
            signed_twice_area += x1 * y2 - x2 * y1
        is_ccw_polygon = signed_twice_area > 0

        self.sides_length_m: list[float] = []
        self.sides_exposure_deg: list[float] = []
        self.sides_plain_floor_vsurface_m2: list[float] = []
        self.sides_glazing_floor_vsurface_m2: list[float] = []
        self.sides_plain_basement_vsurface_m2: list[float] = []
        self.sides_mask: list[SideMaskData] = []
        self.floors_data: list[FloorData] = []

        self.footprint_surface_m2: float = shoelace_area_m2(self.footprint)
        self.building_height_m: float = self.base_elevation + self.floor_height * self.n_floors

        for side_id in range(self.n_sides):
            x1, y1 = self.footprint[side_id]
            x2, y2 = self.footprint[side_id + 1]
            dx, dy = x2 - x1, y2 - y1
            side_length_m: float = edge_length_m((x1, y1), (x2, y2))
            if is_ccw_polygon:
                normal_x, normal_y = dy, -dx
            else:
                normal_x, normal_y = -dy, dx

            # Convert normal from math frame (0°=east, CCW+) to BATEM solar frame:
            # 0°=south, +90°=west, -90°=east.
            normal_angle_math_deg = degrees(atan2(normal_y, normal_x))
            exposure_deg = -normal_angle_math_deg - 90.0
            exposure_deg = ((exposure_deg + 180.0) % 360.0) - 180.0
            glazing_ratio: float = self.side_glazing_ratios[side_id]

            self.sides_length_m.append(side_length_m)
            self.sides_exposure_deg.append(exposure_deg)
            self.sides_plain_floor_vsurface_m2.append(side_length_m * self.floor_height * (1.0 - glazing_ratio))
            self.sides_glazing_floor_vsurface_m2.append(side_length_m * self.floor_height * glazing_ratio)
            self.sides_plain_basement_vsurface_m2.append(side_length_m * self.base_elevation)
            tangent_x = dx / side_length_m
            tangent_y = dy / side_length_m
            facade_normal_x = normal_x / side_length_m
            facade_normal_y = normal_y / side_length_m
            self.sides_mask.append(
                SideMaskData(
                    name=f"side_{side_id}",
                    x_center=(x1 + x2) / 2.0,
                    y_center=(y1 + y2) / 2.0,
                    width=side_length_m,
                    height=self.building_height_m,
                    elevation=0.0,
                    exposure_deg=exposure_deg,
                    normal_angle_with_south_deg=0.0,
                    tangent_x=tangent_x,
                    tangent_y=tangent_y,
                    facade_normal_x=facade_normal_x,
                    facade_normal_y=facade_normal_y,
                )
            )

        self.perimeter_m: float = sum(
            edge_length_m(self.footprint[i], self.footprint[i + 1]) for i in range(self.n_sides)
        )
        self.plain_floor_vsurface_m2: float = sum(self.sides_plain_floor_vsurface_m2)
        self.glazing_floor_vsurface_m2: float = sum(self.sides_glazing_floor_vsurface_m2)
        self.plain_basement_vsurface_m2: float = sum(self.sides_plain_basement_vsurface_m2)

    def _wall_contact_entries_normalized(self) -> list[dict[str, int | float]]:
        raw: Sequence[Mapping[str, int | float]] | None = self.wall_contacts
        if raw is None:
            return []
        if isinstance(raw, Mapping):
            return [dict(raw)]
        return [dict(entry) for entry in raw]

    def _apply_wall_contacts(self) -> None:
        """Split façade areas per occupied floor, remove outdoor wall/glazing where contacts apply, build :attr:`floors_data`."""
        nf: int = self.n_floors
        ns: int = self.n_sides
        plain_pf: list[list[float]] = [[self.sides_plain_floor_vsurface_m2[s] for s in range(ns)] for _ in range(nf)]
        gl_pf: list[list[float]] = [[self.sides_glazing_floor_vsurface_m2[s] for s in range(ns)] for _ in range(nf)]
        self.wall_contact_specs: list[WallContactSpec] = []
        entries: list[dict[str, int | float]] = self._wall_contact_entries_normalized()
        covered: list[list[bool]] = [[False] * ns for _ in range(nf)]

        for idx, entry in enumerate(entries):
            if "vertex_id" not in entry or "temperature_C" not in entry or "n_floors" not in entry:
                raise ValueError(
                    f"wall_contacts[{idx}] must contain keys 'vertex_id', 'temperature_C', 'n_floors'; got {entry!r}"
                )
            vid: int = int(entry["vertex_id"])
            t_c: float = float(entry["temperature_C"])
            nc: int = int(entry["n_floors"])
            if not (0 <= vid < ns):
                raise ValueError(f"wall_contacts[{idx}]: vertex_id {vid} out of range [0, {ns - 1}]")
            if not (1 <= nc <= nf):
                raise ValueError(f"wall_contacts[{idx}]: n_floors {nc} must be in [1, {nf}]")
            zone_name: str = f"wall_contact_{idx}"
            self.wall_contact_specs.append(
                WallContactSpec(zone_name=zone_name, side_index=vid, temperature_C=t_c, n_floors=nc)
            )
            for f in range(nc):
                if covered[f][vid]:
                    raise ValueError(
                        f"wall_contacts overlap on footprint side {vid} (floor index {f}); merge definitions or use disjoint bands"
                    )
                covered[f][vid] = True

        for f in range(nf):
            for s in range(ns):
                if covered[f][s]:
                    plain_pf[f][s] = 0.0
                    gl_pf[f][s] = 0.0

        self.sides_plain_floor_vsurface_m2_by_floor: list[list[float]] = plain_pf
        self.sides_glazing_floor_vsurface_m2_by_floor: list[list[float]] = gl_pf
        # Floor0 row matches the nominal per-side lists used where a single storey template is enough.
        self.sides_plain_floor_vsurface_m2 = plain_pf[0][:]
        self.sides_glazing_floor_vsurface_m2 = gl_pf[0][:]
        self.plain_floor_vsurface_m2 = sum(self.sides_plain_floor_vsurface_m2)
        self.glazing_floor_vsurface_m2 = sum(self.sides_glazing_floor_vsurface_m2)

        self.floors_data = []
        for floor_index in range(nf):
            mid_floor_elevation_m: float = self.base_elevation + (floor_index + 0.5) * self.floor_height
            floor_windows: list[WindowData] = [
                WindowData(
                    floor_index=floor_index,
                    mid_elevation_m=mid_floor_elevation_m,
                    exposure_deg=self.sides_exposure_deg[side_index],
                    surface_m2=gl_pf[floor_index][side_index],
                    solar_factor=self.glazing_solar_factor,
                )
                for side_index in range(ns)
            ]
            plain_vf: float = sum(plain_pf[floor_index][s] for s in range(ns))
            self.floors_data.append(
                FloorData(
                    floor_index=floor_index,
                    mid_elevation_m=mid_floor_elevation_m,
                    hsurface_m2=self.footprint_surface_m2,
                    plain_vsurface_m2=plain_vf,
                    windows_data=floor_windows,
                )
            )

    def _compute_window_local_masks(self) -> None:
        """Build local self-obstruction masks for façade collectors.

        The baseline collector already applies the façade visibility band
        (``exposure_deg - 90`` to ``exposure_deg + 90``). This method adds
        *near-field* masks from **all other** footprint façades so convex blocks
        (and mixed footprints) shade each other at corners, not only re-entrant
        courtyards.

        Strategy:
        - For each edge ``i`` and every other edge ``j != i``, build several
          ``SideMask`` instances from observer samples along edge ``i`` (0, 25,
          50, 75, 100% of the segment).
        - The obstructing orientation of wall ``j`` is **outer** vs **inner**
          (``exposure_deg`` vs ``exposure_deg + 180°``, and the same for roll)
          according to the half-space of the observer relative to wall ``j``'s
          outward normal: if the vector from ``j``'s centre to the observer has
          positive dot product with the outward normal, use the outer face;
          otherwise use the inner face (courtyard / interior side of that wall).

        The resulting list is later combined with ``StackedMask`` in
        ``RegularZone.__init__``; intersecting masks across observer samples
        yields a conservative obstruction envelope and avoids non-physical
        angular holes for polygonal façades.
        """
        self.window_local_masks: list[list[Mask]] = []
        plane_eps = 1e-6

        def wrap_deg_180(angle_deg: float) -> float:
            return ((angle_deg + 180.0) % 360.0) - 180.0

        for i in range(self.n_sides):
            local_masks: list[Mask] = []
            x1, y1 = self.footprint[i]
            x2, y2 = self.footprint[i + 1]
            observer_points_xy: list[tuple[float, float]] = [
                (x1 + t * (x2 - x1), y1 + t * (y2 - y1))
                for t in (0.0, 0.25, 0.5, 0.75, 1.0)
            ]
            for j, other in enumerate(self.sides_mask):
                if i == j:
                    continue
                nx = other.facade_normal_x
                ny = other.facade_normal_y
                if not isfinite(nx) or not isfinite(ny):
                    ang = radians(-other.exposure_deg - 90.0)
                    nx, ny = cos(ang), sin(ang)
                for observer_x, observer_y in observer_points_xy:
                    vx = observer_x - other.x_center
                    vy = observer_y - other.y_center
                    dot = vx * nx + vy * ny
                    if abs(dot) <= plane_eps:
                        continue
                    if dot > 0.0:
                        exposure_deg = other.exposure_deg
                        normal_rot_deg = other.normal_angle_with_south_deg
                    else:
                        exposure_deg = wrap_deg_180(other.exposure_deg + 180.0)
                        normal_rot_deg = wrap_deg_180(other.normal_angle_with_south_deg + 180.0)
                    local_masks.append(
                        SideMask(
                            x_center=other.x_center - observer_x,
                            y_center=other.y_center - observer_y,
                            width=other.width,
                            height=other.height,
                            exposure_deg=exposure_deg,
                            slope_deg=other.slope_deg,
                            elevation=other.elevation,
                            normal_rotation_angle_deg=normal_rot_deg,
                        )
                    )
            self.window_local_masks.append(local_masks)


@dataclass
class EnhancedBuildingData(BuildingData):
    """Enhanced building data with window local masks, directed walls with different compositions, wall contacts."""

    wall_segment_compositions: dict[tuple[int, int], dict[str, tuple[str, float]]] = field(default_factory=dict)
    wall_segment_contacts: dict[tuple[int, int], float] = field(default_factory=dict)


@dataclass
class FloorResult:
    """Per-zone HVAC summary after simulation.

    ``zone_key`` matches the thermal zone name (``basement``, ``floor0``, …).
    ``floor_surface_m2`` is the horizontal conditioned footprint used for kWh/m²
    intensities. ``envelope_surface_m2`` is the external envelope area of the zone
    (façades, glazing, roof/slab as modeled) for reference tables.
    """

    zone_key: str
    floor_surface_m2: float
    envelope_surface_m2: float
    heat_production_Wh: list[float]

    @cached_property
    def heat_production_heating_Wh(self) -> list[float]:
        return [p if p > 0 else 0 for p in self.heat_production_Wh]

    @cached_property
    def heat_production_cooling_Wh(self) -> list[float]:
        return [p if p < 0 else 0 for p in self.heat_production_Wh]


@dataclass
class BuildingResult:
    datetimes: list[datetime]
    hvac_cop_heating: float
    hvac_cop_cooling: float
    floor_results: list[FloorResult]

    @cached_property
    def external_envelope_surface_m2(self) -> float:
        return sum(floor_result.envelope_surface_m2 for floor_result in self.floor_results)

    @cached_property
    def heat_production_Wh(self) -> list[float]:
        return [sum(floor_result.heat_production_Wh[i] for floor_result in self.floor_results) for i in range(len(self.floor_results[0].heat_production_Wh))]

    @cached_property
    def heat_production_heating_Wh(self) -> list[float]:
        return [p if p > 0 else 0 for p in self.heat_production_Wh]

    @cached_property
    def heat_production_cooling_Wh(self) -> list[float]:
        return [p if p < 0 else 0 for p in self.heat_production_Wh]


class Polygon:

    def __init__(self, footprint: Vertices, eps: float = 1e-12) -> None:
        self.footprint: Vertices = footprint
        self.eps: float = eps

    def __repr__(self) -> str:
        return f"Polygon(footprint={self.footprint}, is_simple={self.is_simple()!r})"

    def is_simple(self) -> bool:
        """
        Check whether a closed polygonal chain defined by footprint points is simple:
        no self-intersection except consecutive edges meeting at shared endpoints.

        A footprint may repeat the first vertex at the end to close the ring; that
        duplicate is ignored for the test.
        """
        footprint: Vertices = self.footprint[0:-1]
        n_vertices: int = len(footprint)
        if n_vertices < 3:
            return False

        for i in range(n_vertices):
            vertex1: Vertex = footprint[i]
            vertex2: Vertex = footprint[(i + 1) % n_vertices]
            if abs(vertex1[0] - vertex2[0]) <= self.eps and abs(vertex1[1] - vertex2[1]) <= self.eps:
                return False

        for i in range(n_vertices):
            vertex1: Vertex = footprint[i]
            vertex2: Vertex = footprint[(i + 1) % n_vertices]

            for j in range(i + 1, n_vertices):
                if j == i:
                    continue
                if j == (i + 1) % n_vertices:
                    continue
                if i == (j + 1) % n_vertices:
                    continue
                vertex3: Vertex = footprint[j]
                vertex4: Vertex = footprint[(j + 1) % n_vertices]

                if self._segments_intersect(vertex1, vertex2, vertex3, vertex4, self.eps):
                    return False
        return True

    def footprint_plot(self, simple: bool = True) -> None:
        """Plot footprint and closed edge chain in the plane."""
        if len(self.footprint) < 1:
            return

        xs: list[float] = [vertex[0] for vertex in self.footprint]
        ys: list[float] = [vertex[1] for vertex in self.footprint]

        fig, ax = plt.subplots(figsize=(7.0, 7.0))
        ax.plot(xs, ys, color="C0", linewidth=1.8, alpha=0.85, zorder=1)
        ax.scatter(xs, ys, c="C0", s=90, zorder=3, edgecolors="black", linewidths=1.0)
        for i, (x, y) in enumerate(self.footprint):
            ax.annotate(str(i), (x, y), xytext=(5, 5), textcoords="offset points", fontsize=11, fontweight="bold")
        for i in range(len(self.footprint) - 1):
            x1, y1 = self.footprint[i]
            x2, y2 = self.footprint[i + 1]
            ax.annotate(
                f"[{i}]",
                ((x1 + x2) / 2.0, (y1 + y2) / 2.0),
                xytext=(0, 0),
                textcoords="offset points",
                fontsize=10,
                fontweight="bold",
                color="C3",
                ha="center",
                va="center",
                bbox={"boxstyle": "round,pad=0.18", "fc": "white", "ec": "C3", "alpha": 0.85},
            )
        ax.set_aspect("equal", adjustable="box")
        ax.grid(True, alpha=0.35)
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        if not simple:
            ax.set_title("ERROR: footprint is not forming a simple polygon")
        else:
            ax.set_title("Footprint")
        fig.tight_layout()
        backend: str = matplotlib.get_backend().lower()
        out: str | None = os.environ.get("SIMPLE_POLYNOME_FIG_PATH")
        if out or "agg" in backend:
            path: str = out or "/tmp/simple_polynome_complex_building.png"
            fig.savefig(path, dpi=150)
            print(f"Saved figure to {path}")
        else:
            plt.show()
        plt.close(fig)

    @staticmethod
    def _orient(vertex1: Vertex, vertex2: Vertex, vertex3: Vertex) -> float:
        """Signed area / 2D cross product."""
        return (vertex2[0] - vertex1[0]) * (vertex3[1] - vertex1[1]) - (vertex2[1] - vertex1[1]) * (vertex3[0] - vertex1[0])

    @staticmethod
    def _almost_equal(x: float, y: float, eps: float = 1e-12) -> bool:
        return abs(x - y) <= eps

    @staticmethod
    def _vertex_on_segment(vertex1: Vertex, vertex2: Vertex, vertex3: Vertex, eps: float) -> bool:
        """Return True iff p is collinear with [a,b] and lies in its bounding box."""
        if abs(Polygon._orient(vertex1, vertex2, vertex3)) > eps:
            return False
        return (
            min(vertex1[0], vertex2[0]) - eps <= vertex3[0] <= max(vertex1[0], vertex2[0]) + eps
            and min(vertex1[1], vertex2[1]) - eps <= vertex3[1] <= max(vertex1[1], vertex2[1]) + eps
        )

    @staticmethod
    def _segments_intersect(vertex1: Vertex, vertex2: Vertex, vertex3: Vertex, vertex4: Vertex, eps: float) -> bool:
        """Return True iff closed segments [a,b] and [c,d] intersect."""
        orient1: float = Polygon._orient(vertex1, vertex2, vertex3)
        orient2: float = Polygon._orient(vertex1, vertex2, vertex4)
        orient3: float = Polygon._orient(vertex3, vertex4, vertex1)
        orient4: float = Polygon._orient(vertex3, vertex4, vertex2)

        # Proper intersection
        if ((orient1 > eps and orient2 < -eps) or (orient1 < -eps and orient2 > eps)) and (
            (orient3 > eps and orient4 < -eps) or (orient3 < -eps and orient4 > eps)
        ):
            return True

        # Degenerate / collinear cases
        if abs(orient1) <= eps and Polygon._vertex_on_segment(vertex1, vertex2, vertex3, eps):
            return True
        if abs(orient2) <= eps and Polygon._vertex_on_segment(vertex1, vertex2, vertex4, eps):
            return True
        if abs(orient3) <= eps and Polygon._vertex_on_segment(vertex3, vertex4, vertex1, eps):
            return True
        if abs(orient4) <= eps and Polygon._vertex_on_segment(vertex3, vertex4, vertex2, eps):
            return True
        return False


def _pyvista_show_then_destroy(plotter: pv.Plotter, *, auto_close: bool = True) -> None:
    """Run ``plotter.show`` and release VTK resources.

    On some systems (especially macOS), closing a window that still has eye-dome
    lighting enabled can leave the process or the window stuck. Disabling eye
    dome in ``before_close_callback`` and calling ``close`` / ``deep_clean`` in
    ``finally`` matches PyVista guidance for a clean teardown after interactive
    ``show``.
    """

    def _ease_vtk_teardown(p: pv.Plotter) -> None:
        try:
            p.disable_eye_dome_lighting()
        except Exception:
            pass

    try:
        try:
            plotter.show(auto_close=auto_close, before_close_callback=_ease_vtk_teardown)
        except TypeError:
            # Older PyVista without ``before_close_callback`` on ``show``.
            plotter.show(auto_close=auto_close)
    finally:
        for fn in (plotter.close, plotter.deep_clean):
            try:
                fn()
            except Exception:
                pass


class BuildingView:
    """Polygon-based 3D view for :class:`BuildingData` footprints."""

    def __init__(self, building_data: BuildingData) -> None:
        self.building_data: BuildingData = building_data
        self.building_color: str = "#B0BEC5"
        self.base_color: str = "#5D4037"
        self.glass_color: str = "#42A5F5"
        self.edge_color: str = "#37474F"
        self.slab_color: str = "#78909C"
        self.wall_contact_color: str = "#000000"

    @staticmethod
    def _footprint_ring_xy(footprint: Vertices) -> list[tuple[float, float]]:
        """Unique horizontal polygon vertices (drop repeated closing point)."""
        if len(footprint) >= 2 and footprint[0] == footprint[-1]:
            return list(footprint[:-1])
        return list(footprint)

    @staticmethod
    def _polygon_xy_triangulation(ring_xy: list[tuple[float, float]]) -> np.ndarray:
        """Return ``(m, 3)`` triangle vertex indices for a simple (possibly concave) polygon.

        Triangulation uses VTK via PyVista (``PolyData.triangulate``). A previous ear-clipping
        implementation could admit invalid ears on highly concave footprints (for example
        H-shaped plans), producing triangles that crossed the exterior and filled courtyard
        voids between the legs.
        """
        n: int = len(ring_xy)
        if n < 3:
            return np.zeros((0, 3), dtype=np.int64)
        pts = np.array([[float(x), float(y), 0.0] for x, y in ring_xy], dtype=float)
        faces = np.hstack((np.array([n], dtype=np.int32), np.arange(n, dtype=np.int32)))
        poly = pv.PolyData(pts, faces=faces)
        tri_mesh = poly.triangulate()
        if tri_mesh.n_cells == 0:
            return np.zeros((0, 3), dtype=np.int64)
        flat = tri_mesh.faces
        if flat.size == 0 or flat[0] != 3:
            return np.zeros((0, 3), dtype=np.int64)
        tris = flat.reshape(-1, 4)[:, 1:4].astype(np.int64)
        return tris

    @staticmethod
    def _horizontal_tri_sheet_polydata(ring_xy: list[tuple[float, float]], z: float, outward_up: bool) -> PolyData:
        """Horizontal sheet at *z* as triangles; normals point ±Z depending on *outward_up*."""
        tris = BuildingView._polygon_xy_triangulation(ring_xy)
        if tris.shape[0] == 0:
            return PolyData()
        pts = np.array([[x, y, z] for x, y in ring_xy], dtype=float)
        for ti in range(tris.shape[0]):
            i, j, k = int(tris[ti, 0]), int(tris[ti, 1]), int(tris[ti, 2])
            p0, p1, p2 = pts[i], pts[j], pts[k]
            cz = float(np.cross(p1 - p0, p2 - p0)[2])
            if (outward_up and cz < 0.0) or ((not outward_up) and cz > 0.0):
                tris[ti, 1], tris[ti, 2] = tris[ti, 2], tris[ti, 1]
        faces = np.empty(4 * tris.shape[0], dtype=np.int32)
        faces[0::4] = 3
        faces[1::4] = tris[:, 0].astype(np.int32)
        faces[2::4] = tris[:, 1].astype(np.int32)
        faces[3::4] = tris[:, 2].astype(np.int32)
        return PolyData(pts, faces=faces)

    @staticmethod
    def _footprint_polydata(footprint: Vertices, elevation: float) -> PolyData:
        ring = BuildingView._footprint_ring_xy(footprint)
        if len(ring) < 3:
            return PolyData()
        return BuildingView._horizontal_tri_sheet_polydata(ring, elevation, outward_up=True)

    @staticmethod
    def _vertical_prism_polydata(footprint: Vertices, z0: float, z1: float) -> PolyData:
        ring = BuildingView._footprint_ring_xy(footprint)
        n_vertices: int = len(ring)
        if n_vertices < 3 or z1 <= z0 + 1e-9:
            return PolyData()
        pts_arr = np.zeros((2 * n_vertices, 3), dtype=float)
        for i, (x, y) in enumerate(ring):
            pts_arr[i, :] = (x, y, z0)
            pts_arr[i + n_vertices, :] = (x, y, z1)
        faces: list[int] = [n_vertices] + list(range(n_vertices - 1, -1, -1))
        faces += [n_vertices] + list(range(n_vertices, 2 * n_vertices))
        for i in range(n_vertices):
            j: int = (i + 1) % n_vertices
            faces += [4, i, j, j + n_vertices, i + n_vertices]
        return PolyData(pts_arr, faces=np.asarray(faces, dtype=np.int32))

    @staticmethod
    def _merge_polys(parts: list[PolyData]) -> PolyData:
        ok: list[PolyData] = [p for p in parts if p.n_points > 0]
        if not ok:
            return PolyData()
        out: PolyData = ok[0].copy(deep=True)
        for p in ok[1:]:
            out = out.merge(p)
        return out

    @staticmethod
    def _horizontal_cap_polydata(footprint: Vertices, z: float, outward_up: bool) -> PolyData:
        ring = BuildingView._footprint_ring_xy(footprint)
        n_vertices: int = len(ring)
        if n_vertices < 3:
            return PolyData()
        order = range(n_vertices) if outward_up else range(n_vertices - 1, -1, -1)
        ordered_ring = [ring[i] for i in order]
        return BuildingView._horizontal_tri_sheet_polydata(ordered_ring, z, outward_up=outward_up)

    @staticmethod
    def _quad_uz(x1: float, y1: float, x2: float, y2: float, edge_len: float, u_a: float, u_b: float, z_a: float, z_b: float) -> PolyData:
        if u_b <= u_a + 1e-9 or z_b <= z_a + 1e-9 or edge_len < 1e-9:
            return PolyData()

        def p_at(u: float) -> Vertex:
            t = u / edge_len
            return x1 + t * (x2 - x1), y1 + t * (y2 - y1)

        xa, ya = p_at(u_a)
        xb, yb = p_at(u_b)
        corners = np.array([[xa, ya, z_a], [xb, yb, z_a], [xb, yb, z_b], [xa, ya, z_b]], dtype=float)
        return PolyData(corners, faces=np.array([4, 0, 1, 2, 3], dtype=np.int32))

    def _wall_facade_with_window_hole(self, x1: float, y1: float, x2: float, y2: float, z0: float, z1: float, glazing_ratio: float) -> tuple[list[PolyData], PolyData]:
        dx, dy = x2 - x1, y2 - y1
        elen: float = sqrt(dx * dx + dy * dy)
        if elen < 1e-9 or z1 <= z0 + 1e-9:
            return [], PolyData()
        nx, ny = dy / elen, -dx / elen
        strips: list[PolyData] = []
        if glazing_ratio <= 1e-6:
            strips.append(self._quad_uz(x1, y1, x2, y2, elen, 0.0, elen, z0, z1))
            return strips, PolyData()

        ww: float = elen * sqrt(glazing_ratio)
        zh: float = (z1 - z0) * sqrt(glazing_ratio)
        uc: float = 0.5 * elen
        zc: float = 0.5 * (z0 + z1)
        u_lo: float = max(0.0, uc - 0.5 * ww)
        u_hi: float = min(elen, uc + 0.5 * ww)
        z_lo_w: float = max(z0, zc - 0.5 * zh)
        z_hi_w: float = min(z1, zc + 0.5 * zh)
        if u_hi <= u_lo + 1e-6 or z_hi_w <= z_lo_w + 1e-6:
            strips.append(self._quad_uz(x1, y1, x2, y2, elen, 0.0, elen, z0, z1))
            return strips, PolyData()

        if z_lo_w > z0 + 1e-6:
            strips.append(self._quad_uz(x1, y1, x2, y2, elen, 0.0, elen, z0, z_lo_w))
        if z1 > z_hi_w + 1e-6:
            strips.append(self._quad_uz(x1, y1, x2, y2, elen, 0.0, elen, z_hi_w, z1))
        if u_lo > 1e-6:
            strips.append(self._quad_uz(x1, y1, x2, y2, elen, 0.0, u_lo, z_lo_w, z_hi_w))
        if elen - u_hi > 1e-6:
            strips.append(self._quad_uz(x1, y1, x2, y2, elen, u_hi, elen, z_lo_w, z_hi_w))

        eps: float = 0.04

        def p_at(u: float) -> Vertex:
            t: float = u / elen
            return x1 + t * (x2 - x1), y1 + t * (y2 - y1)

        xa, ya = p_at(u_lo)
        xb, yb = p_at(u_hi)
        glass = np.array(
            [
                [xa + nx * eps, ya + ny * eps, z_lo_w],
                [xb + nx * eps, yb + ny * eps, z_lo_w],
                [xb + nx * eps, yb + ny * eps, z_hi_w],
                [xa + nx * eps, ya + ny * eps, z_hi_w],
            ],
            dtype=float,
        )
        return strips, PolyData(glass, faces=np.array([4, 0, 1, 2, 3], dtype=np.int32))

    def _floor_storey_mesh_with_openings(self, footprint: Vertices, z0: float, z1: float, ratios: list[float]) -> tuple[PolyData, list[PolyData]]:
        ring = self._footprint_ring_xy(footprint)
        n_ring: int = len(ring)
        wall_parts: list[PolyData] = [
            self._horizontal_cap_polydata(footprint, z0, outward_up=False),
            self._horizontal_cap_polydata(footprint, z1, outward_up=True),
        ]
        glass_list: list[PolyData] = []
        for i in range(n_ring):
            x1, y1 = ring[i]
            x2, y2 = ring[(i + 1) % n_ring]
            g = ratios[i] if i < len(ratios) else 0.0
            strips, glass = self._wall_facade_with_window_hole(x1, y1, x2, y2, z0, z1, g)
            wall_parts.extend(strips)
            if glass.n_points > 0:
                glass_list.append(glass)
        return self._merge_polys(wall_parts), glass_list

    def _glazing_ratios_for_floor_visualization(self, floor_index: int) -> list[float]:
        """Per-edge glazing ratios for one occupied storey: 0 on façades with a wall contact (no window)."""
        bd: BuildingData = self.building_data
        out: list[float] = [float(r) for r in bd.side_glazing_ratios]
        for spec in bd.wall_contact_specs:
            if floor_index >= spec.n_floors:
                continue
            si: int = spec.side_index
            if 0 <= si < len(out):
                out[si] = 0.0
        return out

    def _add_cardinal_direction_labels(self, plotter: pv.Plotter) -> None:
        """Annotate the horizontal plane with South / North / East / West.

        Convention (exposure-style azimuth, degrees from South):

        - South: 0°
        - East: −90°
        - West: +90°
        - North: 180°

        World axes in the plot: **+X is East**, **+Y is North** (South is −Y).
        """
        footprint = self.building_data.footprint
        if not footprint:
            return
        xs: list[float] = [p[0] for p in footprint]
        ys: list[float] = [p[1] for p in footprint]
        cx: float = (min(xs) + max(xs)) / 2.0
        cy: float = (min(ys) + max(ys)) / 2.0
        dx: float = max(xs) - min(xs)
        dy: float = max(ys) - min(ys)
        span_xy: float = max(dx, dy, 1.0)
        radius: float = 0.55 * span_xy + 0.15 * span_xy
        elevation: float = max(0.12, 0.05 * max(self.building_data.base_elevation, 1.0))

        # Unit vectors in plan: +X East, +Y North
        label_spec: list[tuple[str, float, float]] = [
            ("South (0°)", 0.0, -1.0),
            ("North (180°)", 0.0, 1.0),
            ("East (-90°)", 1.0, 0.0),
            ("West (90°)", -1.0, 0.0),
        ]
        pts_arr = np.array(
            [[cx + radius * ux, cy + radius * uy, elevation] for _, ux, uy in label_spec],
            dtype=float,
        )
        labels = [text for text, _, _ in label_spec]
        cloud = pv.PolyData(pts_arr)
        plotter.add_point_labels(
            cloud,
            labels,
            font_size=28,
            point_size=14,
            text_color="white",
            point_color="#212121",
            always_visible=True,
        )

    def draw(self, plotter: pv.Plotter) -> None:
        footprint: Vertices = self.building_data.footprint
        if footprint:
            xs: list[float] = [point[0] for point in footprint]
            ys: list[float] = [point[1] for point in footprint]
            min_x, max_x = min(xs), max(xs)
            min_y, max_y = min(ys), max(ys)
            dx = max_x - min_x
            dy = max_y - min_y
            pad_x = 0.1 * dx if dx > 1e-9 else 0.1
            pad_y = 0.1 * dy if dy > 1e-9 else 0.1
            ground_rect = pv.Plane(
                center=((min_x + max_x) / 2.0, (min_y + max_y) / 2.0, 0.0),
                direction=(0, 0, 1),
                i_size=dx + 2.0 * pad_x,
                j_size=dy + 2.0 * pad_y,
            )
            plotter.add_mesh(ground_rect, color="#2E7D32", opacity=0.35, show_edges=False)
        floor_height: float = self.building_data.floor_height
        base_elevation: float = self.building_data.base_elevation
        n_floors: int = self.building_data.n_floors

        if base_elevation > 1e-6:
            base_mesh = self._vertical_prism_polydata(footprint, 0.0, base_elevation)
            if base_mesh.n_cells > 0:
                plotter.add_mesh(base_mesh, color=self.base_color, opacity=1.0, smooth_shading=True, show_edges=True, edge_color="black", line_width=1.2)

        for k in range(n_floors):
            z0: float = base_elevation + k * floor_height
            z1: float = base_elevation + (k + 1) * floor_height
            ratios_k: list[float] = self._glazing_ratios_for_floor_visualization(k)
            cell, glass_panes = self._floor_storey_mesh_with_openings(footprint, z0, z1, ratios_k)
            if cell.n_cells > 0:
                plotter.add_mesh(cell, color=self.building_color, opacity=1.0, smooth_shading=True, show_edges=True, edge_color=self.edge_color, line_width=1.0)
            for gmesh in glass_panes:
                plotter.add_mesh(gmesh, color=self.glass_color, opacity=0.55, smooth_shading=True, show_edges=True, edge_color="#0D47A1", line_width=1.0)
            slab = self._footprint_polydata(footprint, elevation=z1 - 0.04)
            if slab.n_points > 0:
                thick = slab.extrude((0.0, 0.0, 0.08), capping=True, inplace=False)
                plotter.add_mesh(thick, color=self.slab_color, opacity=0.35, show_edges=False)

        ring_wc = self._footprint_ring_xy(footprint)
        n_ring_wc = len(ring_wc)
        if n_ring_wc >= 2 and self.building_data.wall_contact_specs:
            # Stand off the envelope enough to avoid z-fighting with the merged storey mesh.
            off_m = 0.18
            for spec in self.building_data.wall_contact_specs:
                si = spec.side_index
                if si < 0 or si >= n_ring_wc:
                    continue
                x1, y1 = ring_wc[si]
                x2, y2 = ring_wc[(si + 1) % n_ring_wc]
                z0_wc = base_elevation
                z1_wc = base_elevation + spec.n_floors * floor_height
                if z1_wc <= z0_wc + 1e-9:
                    continue
                dx_e = x2 - x1
                dy_e = y2 - y1
                elen_e = sqrt(dx_e * dx_e + dy_e * dy_e)
                if elen_e < 1e-9:
                    continue
                nx_o = dy_e / elen_e
                ny_o = -dx_e / elen_e
                patch = self._quad_uz(x1, y1, x2, y2, elen_e, 0.0, elen_e, z0_wc, z1_wc)
                if patch.n_points > 0:
                    patch = patch.translate((nx_o * off_m, ny_o * off_m, 0.0), inplace=False)
                    # Black + Phong/smooth shading often reads as invisible; flat unlit reads as true black.
                    plotter.add_mesh(
                        patch,
                        color=self.wall_contact_color,
                        opacity=1.0,
                        smooth_shading=False,
                        lighting=False,
                        show_edges=True,
                        edge_color="#9E9E9E",
                        line_width=2.0,
                    )

        self._add_cardinal_direction_labels(plotter)


class SideMaskView:
    """Draw helper for one distant side mask (obstacle + normal arrow + label)."""

    def __init__(self, side_mask_data: SideMaskData) -> None:
        self.color = "red"
        self.opacity: float = 0.35
        self.name: str = (getattr(side_mask_data, "name", "") or "").strip()
        self.x_center: float = side_mask_data.x_center
        self.y_center: float = side_mask_data.y_center
        self.z_center: float = side_mask_data.elevation + side_mask_data.height / 2
        self.center_ref: tuple[float, float, float] = (self.x_center, self.y_center, self.z_center)
        self.width: float = side_mask_data.width
        self.height: float = side_mask_data.height
        self.elevation: float = side_mask_data.elevation
        self.exposure_deg: float = side_mask_data.exposure_deg
        self.slope_deg: float = side_mask_data.slope_deg
        self.normal_rotation_deg: float = side_mask_data.normal_angle_with_south_deg
        self.tangent_x: float = side_mask_data.tangent_x
        self.tangent_y: float = side_mask_data.tangent_y
        self.facade_normal_x: float = side_mask_data.facade_normal_x
        self.facade_normal_y: float = side_mask_data.facade_normal_y
        self._use_footprint_facade_axes: bool = (
            isfinite(self.tangent_x)
            and isfinite(self.tangent_y)
            and isfinite(self.facade_normal_x)
            and isfinite(self.facade_normal_y)
        )
        slope_rad: float = radians(self.slope_deg)
        exposure_rad: float = radians(side_mask_data.exposure_deg)
        if self._use_footprint_facade_axes:
            self.normal = (self.facade_normal_x, self.facade_normal_y, 0.0)
        else:
            # BATEM exposure convention: 0°=South, +90°=West, -90°=East, 180°=North.
            # World axes: +X=East, +Y=North. Horizontal normal components therefore
            # are (-sin(exposure), -cos(exposure)).
            self.normal = (-sin(exposure_rad) * sin(slope_rad), -cos(exposure_rad) * sin(slope_rad), -cos(slope_rad))
        self.azimuth_deg: float = degrees(atan2(self.y_center, self.x_center))
        self.altitude_deg: float = degrees(atan2(self.elevation, sqrt(self.x_center**2 + self.y_center**2)))
        self.distance_m: float = sqrt(self.x_center**2 + self.y_center**2)

    def make(self) -> pv.PolyData:
        if abs(self.slope_deg - 90.0) < 1e-6:
            return self._vertical_mask_quad_polydata()
        plane: pv.PolyData = pv.Plane(
            center=self.center_ref,
            direction=self.normal,
            i_size=self.height,
            j_size=self.width,
        )
        if abs(self.normal_rotation_deg + 90.0) > 1e-9:
            plane.rotate_vector(
                vector=self.normal,
                angle=self.normal_rotation_deg + 90.0,
                point=self.center_ref,
                inplace=True,
            )
        return plane

    def _vertical_mask_quad_polydata(self) -> pv.PolyData:
        """Quad mesh for a vertical façade: footprint-based axes when available."""
        up = np.array([0.0, 0.0, 1.0], dtype=float)
        if self._use_footprint_facade_axes:
            w0 = np.array([self.tangent_x, self.tangent_y, 0.0], dtype=float)
            n = np.array([self.facade_normal_x, self.facade_normal_y, 0.0], dtype=float)
            w0n = float(np.linalg.norm(w0))
            nn = float(np.linalg.norm(n))
            if w0n < 1e-12 or nn < 1e-12:
                return PolyData()
            w0 = w0 / w0n
            n = n / nn
            if abs(float(np.dot(w0, n))) > 1e-5:
                return PolyData()
        else:
            e = radians(self.exposure_deg)
            n = np.array([-sin(e), -cos(e), 0.0], dtype=float)
            n_norm = float(np.linalg.norm(n))
            if n_norm < 1e-12:
                return PolyData()
            n = n / n_norm
            w0 = np.cross(up, n)
            w0n = float(np.linalg.norm(w0))
            if w0n < 1e-12:
                return PolyData()
            w0 = w0 / w0n
        # Match PyVista / wall strip convention: rotate the in-plane basis by +90°
        # around the outward normal, then assign width along the horizontal in-plane
        # axis and height along the vertical axis (see :class:`~batem.core.solar.SideMask`).
        roll_rad = radians(90.0 + self.normal_rotation_deg)
        w_vert = _rotate_vector_around_axis(w0, n, roll_rad)
        h_horiz = np.cross(n, w_vert)
        hh = float(np.linalg.norm(h_horiz))
        if hh < 1e-12:
            return PolyData()
        h_horiz = h_horiz / hh
        if w_vert[2] < 0.0:
            w_vert = -w_vert
            h_horiz = -h_horiz
        c = np.array([self.x_center, self.y_center, self.elevation + 0.5 * self.height], dtype=float)
        half_w = 0.5 * self.width
        half_h = 0.5 * self.height
        corners = np.array(
            [
                c - half_w * h_horiz - half_h * w_vert,
                c + half_w * h_horiz - half_h * w_vert,
                c + half_w * h_horiz + half_h * w_vert,
                c - half_w * h_horiz + half_h * w_vert,
            ],
            dtype=float,
        )
        faces = np.array([4, 0, 1, 2, 3], dtype=np.int32)
        return PolyData(corners, faces=faces)

    def draw(self, plotter: pv.Plotter, *, opacity: float | None = None) -> None:
        """Add mask quad, outward-normal arrow and (when available) a name label.

        :param opacity: Overrides :attr:`opacity` for this draw call.
        """
        plane = self.make()
        op = self.opacity if opacity is None else opacity
        tail: tuple[float, float, float] = self.center_ref
        head: tuple[float, float, float] = (self.center_ref[0] + 3.0 * self.normal[0], self.center_ref[1] + 3.0 * self.normal[1], self.center_ref[2] + 3.0 * self.normal[2])
        arrow = pv.Arrow(start=tail, direction=[head[i] - tail[i] for i in range(3)], tip_length=0.2, tip_radius=0.15, shaft_radius=0.05)
        plotter.add_mesh(plane, color=self.color, opacity=op, smooth_shading=True)
        plotter.add_mesh(arrow, color="black")
        if self.name:
            # Anchor slightly in front of the panel along the outward normal so the
            # label is readable from the lit side.
            label_offset_m: float = 0.5
            label_anchor = (
                self.center_ref[0] + label_offset_m * self.normal[0],
                self.center_ref[1] + label_offset_m * self.normal[1],
                self.center_ref[2] + label_offset_m * self.normal[2] + 0.5 * self.height,
            )
            try:
                plotter.add_point_labels(
                    [label_anchor],
                    [self.name],
                    point_size=0,
                    font_size=14,
                    text_color="black",
                    fill_shape=False,
                    shape=None,
                    always_visible=True,
                    name=f"side_mask_label_{id(self)}",
                )
            except TypeError:
                # Older PyVista versions reject some kwargs (``shape``/``always_visible``).
                plotter.add_point_labels(
                    [label_anchor],
                    [self.name],
                    point_size=0,
                    font_size=14,
                    text_color="black",
                    name=f"side_mask_label_{id(self)}",
                )


class Context:

    def __init__(self, context_data: ContextData) -> None:
        self.context_data: ContextData = context_data
        self.distant_masks: list[SideMask] = list()
        self.side_mask_views: list[SideMaskView] = list()
        for side_mask in context_data.side_masks:
            self.distant_masks.append(SideMask(side_mask.x_center, side_mask.y_center, side_mask.width, side_mask.height,
                                      side_mask.exposure_deg, side_mask.slope_deg, side_mask.elevation, side_mask.normal_angle_with_south_deg))
            side_mask_view: SideMaskView = SideMaskView(side_mask)
            side_mask_view.make()
            self.side_mask_views.append(side_mask_view)

        bindings: Bindings = Bindings()
        bindings('TZ:outdoor', 'weather_temperature')
        if context_data.starting_stringdate is None:
            context_data.starting_stringdate = f"01/01/{context_data.simulated_year}"
        if context_data.ending_stringdate is None:
            context_data.ending_stringdate = f"31/12/{context_data.simulated_year}"
        self.dp: DataProvider = DataProvider(location=context_data.location, latitude_north_deg=context_data.latitude_north_deg, longitude_east_deg=context_data.longitude_east_deg, starting_stringdate=context_data.starting_stringdate,
                                             ending_stringdate=context_data.ending_stringdate, bindings=bindings, albedo=context_data.albedo, pollution=context_data.pollution, number_of_levels=context_data.number_of_levels, initial_year=context_data.simulated_year)
        self.solar_model: SolarModel = SolarModel(self.dp.weather_data, distant_masks=self.distant_masks)


class PrismBasementZone:
    """Below-grade thermal zone for a polygon prism (:class:`BuildingData`).

    Modeled like other zones in the RC network, but **without** occupants, glazing,
    HVAC, or outdoor ventilation. Heat balance uses ``PZ = GAIN`` with ``GAIN = 0`` and
    ``PHVAC = 0``. Boundaries: slab to **ground** (``TZ:ground``, typically ~13 °C from
    context), façades to **outdoor** (weather), and slab/ceiling to **floor0** (occupied
    ground storey).
    """

    def __init__(self, building_data: BuildingData, solar_model: SolarModel) -> None:  # floor_number: int,
        self.name: str = "basement"
        self.building_data: BuildingData = building_data
        self.solar_model: SolarModel = solar_model
        self.solar_system: SolarSystem = SolarSystem(solar_model)
        # self.n_floors: int = building_data.n_floors
        # self.floor_height: float = building_data.floor_height
        self.elevation_m: float = building_data.base_elevation
        self.hsurface_m2: float = building_data.footprint_surface_m2
        self.volume_m3: float = self.hsurface_m2 * self.elevation_m
        self.plain_vsurface_m2: float = sum(building_data.sides_plain_basement_vsurface_m2)
        # Below-grade envelope for reporting (façade toward outdoor + slab on ground)
        self.external_envelope_surface_m2: float = self.plain_vsurface_m2 + self.hsurface_m2

    # def window_masks(self) -> dict[str, Mask]:
    #     return {}

    def make(self, model_maker: ModelMaker, dp: DataProvider) -> None:
        model_maker.make_side(self.building_data.basement_floor(self.name, 'ground', SIDE_TYPES.FLOOR, self.hsurface_m2))
        observer_z_m: float = max(self.elevation_m * 0.5, 0.0)
        for side_index in range(self.building_data.n_sides):
            plain_m2: float = self.building_data.sides_plain_basement_vsurface_m2[side_index]
            if plain_m2 <= 0:
                continue
            wside: Side = self.building_data.wall(self.name, 'outdoor', SIDE_TYPES.WALL, plain_m2)
            absorb: float = _facade_absorptance_from_wall_side(wside)
            wside.opaque_solar_exposure_deg = self.building_data.sides_exposure_deg[side_index]
            wside.opaque_solar_slope_deg = SLOPES.VERTICAL.value
            wside.opaque_solar_absorptance = absorb
            wside.opaque_solar_power_name = f'PSOLW:{self.name}:side{side_index}'
            model_maker.make_side(wside)
            side_local_masks: list[Mask] = self.building_data.window_local_masks[side_index]
            close_mask: Mask | None = StackedMask(*side_local_masks) if side_local_masks else None
            Collector(
                self.solar_system,
                wside.opaque_solar_power_name,
                surface_m2=plain_m2,
                exposure_deg=wside.opaque_solar_exposure_deg,
                slope_deg=wside.opaque_solar_slope_deg,
                solar_factor=absorb,
                close_mask=close_mask,
                observer_elevation_m=observer_z_m,
            )
        # Slab between basement and ground occupied storey (zones are floor0 … floor{n-1})
        model_maker.make_side(self.building_data.ground_floor(self.name, 'floor0', SIDE_TYPES.FLOOR, self.hsurface_m2))


class PrismZoneFloor:
    """Occupied storey for polygon-prism buildings: one solar collector per façade segment."""

    def __init__(self, floor_index: int, building_data: BuildingData, solar_model: SolarModel) -> None:
        """``floor_index`` is 0-based: ground occupied storey is ``floor0``."""
        self.floor_index: int = floor_index
        self.name: str = f"floor{floor_index}"
        self.building_data: BuildingData = building_data
        self.solar_model: SolarModel = solar_model
        self.solar_system: SolarSystem = SolarSystem(solar_model)
        self.n_floors: int = building_data.n_floors
        self.base_elevation: float = building_data.base_elevation
        self.floor_height: float = building_data.floor_height
        self.z_rotation_angle_deg: float = building_data.z_rotation_angle_deg
        self.floor_surface: float = building_data.footprint_surface_m2
        self.volume: float = self.floor_surface * self.floor_height
        self.volume_m3: float = self.volume
        self.mid_elevation: float = self.base_elevation + self.floor_height * (floor_index + 0.5)
        fi: int = self.floor_index
        self.window_surfaces: list[float] = [
            building_data.sides_glazing_floor_vsurface_m2_by_floor[fi][i] for i in range(building_data.n_sides)
        ]
        self.window_angles_deg: list[float] = list(building_data.sides_exposure_deg)
        self.windows_names: list[str] = [f"side{i}" for i in range(building_data.n_sides)]
        self.glazing_surface: float = sum(self.window_surfaces)
        self.wall_surface: float = sum(building_data.sides_plain_floor_vsurface_m2_by_floor[fi])
        self._window_masks: dict[str, Mask] = {}
        self.zone_window_collectors: list[Collector] = []
        contact_envelope_m2: float = sum(
            building_data.sides_length_m[spec.side_index] * building_data.floor_height
            for spec in building_data.wall_contact_specs
            if fi < spec.n_floors
        )
        self.external_envelope_surface_m2: float = self.wall_surface + self.glazing_surface + contact_envelope_m2
        if self.floor_index == self.n_floors - 1:
            self.external_envelope_surface_m2 += self.floor_surface
        self.hvac_heat_production_kWh_per_year_cooling: float = 0.0
        self.hvac_heat_production_kWh_per_year_heating: float = 0.0
        self.hvac_electric_consumption_kWh_per_year_cooling: float = 0.0
        self.hvac_electric_consumption_kWh_per_year_heating: float = 0.0

    def window_masks(self) -> dict[str, Mask]:
        return self._window_masks

    def make(self, model_maker: ModelMaker, dp: DataProvider) -> None:
        if self.floor_index == self.n_floors - 1:
            # Roof exchange surface is plan area, not zone volume.
            model_maker.make_side(self.building_data.roof(self.name, 'outdoor', SIDE_TYPES.CEILING, self.floor_surface))
        else:
            assert self.building_data.intermediate_floor is not None, "intermediate_floor should be defined when n_floors > 1"
            model_maker.make_side(self.building_data.intermediate_floor(self.name, f'floor{self.floor_index + 1}', SIDE_TYPES.FLOOR, self.floor_surface))
        if self.floor_index == 0 and self.base_elevation == 0:
            model_maker.make_side(self.building_data.ground_floor(self.name, 'ground', SIDE_TYPES.FLOOR, self.floor_surface))
        fi = self.floor_index
        for side_index in range(self.building_data.n_sides):
            plain_m2: float = self.building_data.sides_plain_floor_vsurface_m2_by_floor[fi][side_index]
            if plain_m2 <= 0:
                continue
            wside: Side = self.building_data.wall(self.name, 'outdoor', SIDE_TYPES.WALL, plain_m2)
            absorb: float = _facade_absorptance_from_wall_side(wside)
            wside.opaque_solar_exposure_deg = self.building_data.sides_exposure_deg[side_index]
            wside.opaque_solar_slope_deg = SLOPES.VERTICAL.value
            wside.opaque_solar_absorptance = absorb
            wside.opaque_solar_power_name = f'PSOLW:{self.name}:side{side_index}'
            model_maker.make_side(wside)
            side_local_masks: list[Mask] = self.building_data.window_local_masks[side_index]
            close_mask: Mask | None = StackedMask(*side_local_masks) if side_local_masks else None
            Collector(
                self.solar_system,
                wside.opaque_solar_power_name,
                surface_m2=plain_m2,
                exposure_deg=wside.opaque_solar_exposure_deg,
                slope_deg=wside.opaque_solar_slope_deg,
                solar_factor=absorb,
                close_mask=close_mask,
                observer_elevation_m=self.mid_elevation,
            )
        for spec in self.building_data.wall_contact_specs:
            if fi >= spec.n_floors:
                continue
            contact_area: float = self.building_data.sides_length_m[spec.side_index] * self.floor_height
            if contact_area <= 0:
                continue
            # ``building_data.wall`` is one mutable :class:`~batem.core.components.Side`; the outdoor loop
            # above sets opaque_solar_* on it. Clear those so contact walls are not mistaken for sunlit façades.
            w_contact: Side = self.building_data.wall(self.name, spec.zone_name, SIDE_TYPES.WALL, contact_area)
            w_contact.opaque_solar_exposure_deg = None
            w_contact.opaque_solar_slope_deg = None
            w_contact.opaque_solar_absorptance = None
            w_contact.opaque_solar_power_name = None
            model_maker.make_side(w_contact)
        if self.glazing_surface > 0:
            model_maker.make_side(self.building_data.glazing(self.name, 'outdoor', SIDE_TYPES.GLAZING, self.glazing_surface))
        regular_rate = self.building_data.regular_air_renewal_rate_vol_per_hour
        nominal_airflow = (regular_rate * self.volume / 3600) if regular_rate is not None else 0.0
        model_maker.connect_airflow(self.name, 'outdoor', nominal_value=nominal_airflow)

        for side_index, (window_name, window_angle, window_surface) in enumerate(zip(self.windows_names, self.window_angles_deg, self.window_surfaces)):
            side_local_masks: list[Mask] = self.building_data.window_local_masks[side_index]
            close_mask: Mask | None = StackedMask(*side_local_masks) if side_local_masks else None
            if window_surface > 0:
                collector: Collector = Collector(
                    self.solar_system,
                    window_name,
                    surface_m2=window_surface,
                    exposure_deg=window_angle,
                    slope_deg=SLOPES.VERTICAL.value,
                    solar_factor=self.building_data.glazing_solar_factor,
                    close_mask=close_mask,
                    observer_elevation_m=self.mid_elevation,
                )
                self.zone_window_collectors.append(collector)
                self._window_masks[window_name] = collector.mask
            else:
                self._window_masks[window_name] = InvertedMask(StackedMask())


def _horizontal_conditioned_floor_area_m2(zone_floor: PrismBasementZone | PrismZoneFloor) -> float:
    """Horizontal footprint area (m²) for per-floor energy intensity, not façade envelope."""
    if isinstance(zone_floor, PrismZoneFloor):
        return float(zone_floor.floor_surface)
    return float(zone_floor.hsurface_m2)


class Building:
    """High-level orchestrator for generating and simulating a BATEM building.

    The class assembles the context, solar model, thermal network, HVAC
    controllers, and simulation engine required to execute a full-year building
    simulation.

    :param context_data: Geographic and climatic context description.
    :param building_data: Physical parameters and HVAC capacities.
    :ivar context: Instantiated :class:`Context` wrapping weather and bindings.
    :ivar dp: Shared :class:`~batem.core.data.DataProvider` used across modules.
    :ivar simulation: Configured :class:`~batem.core.control.Simulation` object.
    :ivar floors: Zone layers (basement + one per occupied storey) for the polygon prism model.
    """

    def __init__(self, context_data: ContextData, building_data: BuildingData) -> None:
        self.context: Context = Context(context_data)
        self.context_data: ContextData = context_data
        self.dp: DataProvider = self.context.dp
        self.datetimes: list[datetime] = self.dp.datetimes
        self.building_data: BuildingData = building_data
        self.building_view = BuildingView(building_data)
        # self.building_view.make()
        self.dp.add_param('CCO2:outdoor', 400)
        self.dp.add_param('TZ:ground', context_data.ground_temperature)
        for _wc in building_data.wall_contact_specs:
            self.dp.add_param(f'TZ:{_wc.zone_name}', _wc.temperature_C)

        solar_model: SolarModel = self.context.solar_model

        zone_floors: list[PrismBasementZone | PrismZoneFloor] = []
        zone_name_volumes: dict[str, float] = {}
        if building_data.has_basement:
            zone_floors.append(PrismBasementZone(building_data, solar_model))
            zone_name_volumes[zone_floors[0].name] = zone_floors[0].volume_m3
        # n_floors = number of occupied storeys (excluding basement). Zone names: floor0 … floor{n_floors-1}.
        for floor_index in range(0, building_data.n_floors):
            zone_floor = PrismZoneFloor(floor_index, building_data, solar_model)
            zone_floors.append(zone_floor)
            zone_name_volumes[zone_floor.name] = zone_floor.volume
        for _wc in building_data.wall_contact_specs:
            zone_name_volumes[_wc.zone_name] = None
        zone_name_volumes['outdoor'] = None
        zone_name_volumes['ground'] = None
        self.zone_names: list[str] = [zone_floor.name for zone_floor in zone_floors]
        self.zone_floors: list[PrismBasementZone | PrismZoneFloor] = zone_floors
        self.zone_outdoor_regular_airflows_m3_per_s: dict[str, float] = {}
        airflow_defaults: dict[str, float] = {}
        airflow_bounds: dict[str, float] = {}
        airflow_names: list[str] = []
        # Set up airflow for each occupied storey (basement has no regular outdoor airflow)
        for zone_floor in zone_floors:
            if isinstance(zone_floor, PrismBasementZone):
                continue
            volume: float | None = getattr(zone_floor, 'volume', None)
            if volume is None:
                continue
            airflow_name = f'Q:{zone_floor.name}-outdoor'
            base_value: float | None = None
            bound_upper: float = 0.0
            if self.building_data.regular_air_renewal_rate_vol_per_hour is not None:
                # print(f"Floor {zone_floor.name} has a regular airflow: {self.building_data.regular_air_renewal_rate_vol_per_hour} vol/h")
                regular_airflow_m3_per_s: float = (self.building_data.regular_air_renewal_rate_vol_per_hour * volume) / 3600.0
                self.zone_outdoor_regular_airflows_m3_per_s[zone_floor.name] = regular_airflow_m3_per_s
                base_value = regular_airflow_m3_per_s
                bound_upper = max(bound_upper, regular_airflow_m3_per_s)
            if base_value is None:
                base_value = 0.0
            bound_upper = max(bound_upper, base_value)
            airflow_defaults[airflow_name] = base_value
            airflow_bounds[airflow_name] = bound_upper
            airflow_names.append(airflow_name)
        if airflow_names:
            self.dp.add_data_names_in_fingerprint(*airflow_names)
            for airflow_name, default_value in airflow_defaults.items():
                values = [default_value for _ in self.dp.ks]
                if airflow_name in self.dp:
                    self.dp.add_var(airflow_name, values, force=True)
                else:
                    self.dp.add_var(airflow_name, values)
                bound_upper = airflow_bounds.get(airflow_name, default_value)
                if bound_upper <= 0.0:
                    bound_upper = 1e-6
                if hasattr(self.dp, 'independent_variable_set'):
                    self.dp.independent_variable_set.variable_bounds[airflow_name] = (0.0, bound_upper)

        # Store initial heat recovery efficiency as parameter (will be updated as time series after simulation)
        # The actual time-varying efficiency will be set in _update_ventilation_heat_recovery_efficiency()
        self.dp.add_param('ventilation_heat_recovery_efficiency', building_data.regular_ventilation_heat_recovery_efficiency)

        # #### STATE MODEL MAKER AND SURFACES ####
        model_maker: ModelMaker = ModelMaker(data_provider=self.dp, periodic_depth_seconds=building_data.periodic_depth_seconds,
                                             state_model_order_max=building_data.state_model_order_max, **zone_name_volumes)

        # Calculate max occupancy per floor based on floor area and density
        # density_occupants_per_100m2 is per unit area, applied to each floor independently
        max_occupancy_per_floor: float = (
            building_data.density_occupants_per_100m2 * building_data.footprint_surface_m2 / 100.0
        )

        # Realistic default occupancy profile (low at night, peak during daytime).
        # This prevents unrealistically large internal gains (and winter overheating).
        siggen: SignalGenerator = SignalGenerator(
            self.dp,
            OccupancyProfile(
                weekday_profile={
                    0: max_occupancy_per_floor * 0.10,
                    6: max_occupancy_per_floor * 0.15,
                    8: max_occupancy_per_floor * 0.45,
                    9: max_occupancy_per_floor * 0.70,
                    12: max_occupancy_per_floor * 0.55,
                    14: max_occupancy_per_floor * 0.70,
                    18: max_occupancy_per_floor * 0.45,
                    21: max_occupancy_per_floor * 0.20,
                    23: max_occupancy_per_floor * 0.10,
                },
                weekend_profile={
                    0: max_occupancy_per_floor * 0.12,
                    8: max_occupancy_per_floor * 0.20,
                    12: max_occupancy_per_floor * 0.35,
                    18: max_occupancy_per_floor * 0.22,
                    23: max_occupancy_per_floor * 0.12,
                },
            ),
        )
        siggen.add_hvac_period(HeatingPeriod(building_data.heating_period[0], building_data.heating_period[1], weekday_profile={
                               0: building_data.low_heating_setpoint, 7: building_data.normal_heating_setpoint}, weekend_profile={00: building_data.low_heating_setpoint, 7: building_data.normal_heating_setpoint}))
        siggen.add_hvac_period(CoolingPeriod(building_data.cooling_period[0], building_data.cooling_period[1], weekday_profile={
                               0: None, 10: building_data.normal_cooling_setpoint, 18: None}, weekend_profile={0: None, 10: building_data.normal_cooling_setpoint, 18: None}))
        if building_data.long_absence_period is not None:
            siggen.add_long_absence_period(LongAbsencePeriod(building_data.long_absence_period[0], building_data.long_absence_period[1]))
        else:
            siggen.add_long_absence_period(LongAbsencePeriod(building_data.long_absence_period[0], building_data.long_absence_period[1]))
        # Create per-floor signals
        controllers: dict[str, TemperatureController] = {}

        for zone_floor in zone_floors:
            zone_floor.make(model_maker, self.dp)
            self._register_opaque_wall_solar_series(zone_floor, building_data.shutter_closed_temperature)
            # Occupancy profile and HVAC seasons
            if isinstance(zone_floor, PrismBasementZone):
                # Unoccupied, no windows, no HVAC; no Q:basement-outdoor (see airflow loop above).
                # RC links: basement ↔ ground (TZ:ground), ↔ outdoor, ↔ floor0 — see PrismBasementZone.make.
                # PZ = GAIN with GAIN = 0; PHVAC = 0. Basement never uses siggen.generate (no MODE/SETPOINT schedule).
                n_steps: int = len(self.dp.ks)
                zeros: list[float] = [0.0] * n_steps
                self.dp.add_var(f'GAIN_SOLAR:{zone_floor.name}', zeros)
                self.dp.add_var(f'OCCUPANCY:{zone_floor.name}', zeros)
                self.dp.add_var(f'PRESENCE:{zone_floor.name}', [0] * n_steps)
                self.dp.add_var(f'GAIN_OCCUPANCY:{zone_floor.name}', zeros)
                self.dp.add_var(f'GAIN:{zone_floor.name}', zeros)
                self.dp.add_var(f'PCO2:{zone_floor.name}', zeros)
            else:
                # Regular floors: generate signals (SETPOINT, MODE, OCCUPANCY, PRESENCE)
                siggen.generate(zone_floor.name)
                # Glazing solar only (opaque-wall absorption enters via PSOLW:* state-model inputs).
                solar_gain: list[float] = _glazing_only_solar_powers_W(zone_floor.solar_system)
                if not solar_gain:
                    solar_gain = [0.0 for _ in self.dp.ks]
                # Apply shutter control: set solar gains to 0 when outdoor temperature exceeds threshold
                if building_data.shutter_closed_temperature is not None:
                    weather_temperature = self.dp.series('weather_temperature')
                    solar_gain = [0.0 if weather_temperature[k] > building_data.shutter_closed_temperature else solar_gain[k] for k in self.dp.ks]
                self.dp.add_var(f'GAIN_SOLAR:{zone_floor.name}', solar_gain)
                # Add solar to gains
                zone_occupancy: list[float | None] = self.dp.series(f'OCCUPANCY:{zone_floor.name}')

                # Handle None values in occupancy (convert None to 0 for gain calculation)
                # OCCUPANCY contains the actual number of occupants (0 to max_occupancy), not a ratio
                # Total occupancy gain = body_metabolism + occupant_consumption (activities/appliances)
                occupancy_gain: list[float] = [(building_data.body_metabolism + building_data.occupant_consumption) * (_ if _ is not None else 0.0) for _ in zone_occupancy]
                self.dp.add_var(f'GAIN_OCCUPANCY:{zone_floor.name}', occupancy_gain)
                self.dp.add_var(f'GAIN:{zone_floor.name}', [occupancy_gain[k] + solar_gain[k] for k in self.dp.ks])
                self.dp.add_var(f'PCO2:{zone_floor.name}', (siggen.filter(zone_occupancy, lambda x: x * building_data.body_PCO2 if x is not None else 0)))

        model_maker.zones_to_simulate({floor.name: floor.volume_m3 for floor in zone_floors})
        # Nominal state model - must be created before TemperatureControllers
        model_maker.nominal
        if self.building_data.initial_temperature is not None:
            self._initialize_state_models(model_maker, self.building_data.initial_temperature)

        # Create HVAC controllers after nominal state model is ready
        for zone_floor in zone_floors:
            if isinstance(zone_floor, PrismZoneFloor):
                hvac_port: HVACcontinuousModePort = HVACcontinuousModePort(
                    data_provider=self.dp, zone_name=zone_floor.name, max_floor_heating_power=building_data.max_floor_heating_power, max_floor_cooling_power=building_data.max_floor_cooling_power)
                temperature_setpoint_port: TemperatureSetpointPort = TemperatureSetpointPort(data_provider=self.dp, zone_name=zone_floor.name, heating_levels=[
                                                                                             16, 19, 20, 21, 22, 23, 24], cooling_levels=[24, 25, 26, 27, 28])
                controllers[zone_floor.name] = TemperatureController(hvac_heat_port=hvac_port, temperature_setpoint_port=temperature_setpoint_port, model_maker=model_maker)

        self.simulation: Simulation = Simulation(
            model_maker,
            body_metabolism=building_data.body_metabolism,
            occupant_consumption=building_data.occupant_consumption,
            max_control_delta_W=None,
            max_abs_control_W=None,
            temperature_smoothing_alpha=None,
            temperature_anti_windup_deadband_deg=None,
        )
        for zone_floor in zone_floors:
            if isinstance(zone_floor, PrismZoneFloor):
                self.simulation.add_temperature_controller(zone_name=zone_floor.name, temperature_controller=controllers[zone_floor.name])

    def _register_opaque_wall_solar_series(self, zone_floor: Any, shutter_closed_temperature: float | None) -> None:
        """Time series for absorbed solar on opaque façades (state inputs ``PSOLW:*`` matching :meth:`ThermalNetwork.HEAT`)."""
        solar_system: SolarSystem | None = getattr(zone_floor, 'solar_system', None)
        if solar_system is None:
            return
        weather_temperature: list[float] | None = None
        if shutter_closed_temperature is not None:
            weather_temperature = self.dp.series('weather_temperature')
        for cname in solar_system.collector_names:
            if not cname.startswith('PSOLW:'):
                continue
            coll: Collector = solar_system.collector(cname)
            series: list[float] = list(coll.powers_W())
            if weather_temperature is not None:
                series = [
                    0.0 if weather_temperature[k] > shutter_closed_temperature else series[k]
                    for k in self.dp.ks
                ]
            self.dp.add_var(cname, series)

    def _initialize_state_models(self, model_maker: ModelMaker, temperature: float) -> None:
        def _set_uniform_initial_state(state_model: StateModel, temp: float) -> StateModel:
            if state_model is None or state_model.n_states == 0:
                return state_model
            target_state: np.ndarray = np.full((state_model.n_states, 1), float(temp))
            state_model.set_state(target_state)
            return state_model

        if hasattr(model_maker, "state_models_cache"):
            model_maker.state_models_cache = {
                key: _set_uniform_initial_state(sm, temperature) for key, sm in model_maker.state_models_cache.items()
            }

        nominal_model: StateModel | None = getattr(model_maker, "nominal_state_model", None)
        if nominal_model is not None:
            _set_uniform_initial_state(nominal_model, temperature)

        original_make_k = model_maker.make_k

        def make_k_with_initial_state(self, *args, **kwargs):
            state_model: StateModel = original_make_k(*args, **kwargs)
            return _set_uniform_initial_state(state_model, temperature)

        model_maker.make_k = types.MethodType(make_k_with_initial_state, model_maker)

    def _calculate_hvac_electric_consumption(self, heat_production_Wh: list[float]) -> list[float]:
        """Calculate HVAC electrical consumption from heat production using appropriate COP.

        Heating ``PHVAC > 0`` and cooling ``PHVAC < 0`` both map to **positive** electrical
        power (same convention as :meth:`_print_hvac_power_recommendations`).
        """
        cop_h = self.building_data.hvac_cop_heating
        cop_c = self.building_data.hvac_cop_cooling
        out: list[float] = []
        for production in heat_production_Wh:
            if production > 0:
                out.append(production / cop_h)
            elif production < 0:
                out.append(abs(production) / cop_c)
            else:
                out.append(0.0)
        return out

    def _initialize_ventilation_heat_recovery_efficiency(self, suffix: str = 'sim') -> None:
        """Initialize ventilation heat recovery efficiency with default values per floor.

        Initializes RECOV variables with regular_ventilation_heat_recovery_efficiency.
        These will be updated during simulation based on free cooling conditions.
        Adds RECOV variables to fingerprint so model is rebuilt when they change.
        """
        # Format suffix with # prefix if not empty (e.g., 'sim' -> '#sim')
        if suffix:
            suffix_formatted = f'#{suffix}' if not suffix.startswith('#') else suffix
        else:
            suffix_formatted = ''

        # Process each floor separately
        recovery_var_names = []
        for floor in self.zone_floors:
            if isinstance(floor, PrismBasementZone):
                continue

            recovery_var_name = f'RECOV:{floor.name}{suffix_formatted}'
            recovery_var_names.append(recovery_var_name)
            # Initialize with regular efficiency for all time steps
            efficiency_values = [self.building_data.regular_ventilation_heat_recovery_efficiency] * len(self.dp.ks)
            self.dp.add_var(recovery_var_name, efficiency_values)
            # Set bounds for fingerprint calculation (efficiency ranges from 0.0 to 1.0)
            # Use a small range to avoid division by zero, but allow for 0.0 to 1.0
            if hasattr(self.dp, 'independent_variable_set'):
                self.dp.independent_variable_set.variable_bounds[recovery_var_name] = (0.0, 1.0)

        # Add RECOV variables to fingerprint so model is rebuilt when they change
        if recovery_var_names:
            self.dp.add_data_names_in_fingerprint(*recovery_var_names)
            # Also add to model maker's fingerprint list (accessed through simulation)
            if hasattr(self, 'simulation') and self.simulation is not None:
                model_maker = self.simulation.model_maker
                for recovery_var_name in recovery_var_names:
                    if recovery_var_name not in model_maker.data_names_in_fingerprint:
                        model_maker.data_names_in_fingerprint = recovery_var_name

    def _update_ventilation_heat_recovery_efficiency_at_k(self, k: int, suffix: str = 'sim', pre_control_outputs: dict = None) -> None:
        """Update ventilation heat recovery efficiency at time step k based on previous time step conditions.

        Updates RECOV[k] based on conditions from time step k-1 (or k=0 for first time step).
        This allows RECOV[k] to affect the model at time step k.

        Free cooling (RECOV=0) is active when:
        - HVAC mode is not heating (mode != 1) AND
        - Indoor temperature > normal_heating_setpoint + free_cooling_setpoint_margin (too hot) AND
        - (outdoor temperature + free_cooling_setpoint_margin) < indoor temperature (outdoor is cooler)

        Otherwise sets it to regular_ventilation_heat_recovery_efficiency.
        """
        if self.building_data.free_cooling_setpoint_margin is None:
            return

        # Format suffix with # prefix if not empty
        if suffix:
            suffix_formatted = f'#{suffix}' if not suffix.startswith('#') else suffix
        else:
            suffix_formatted = ''

        # Process each floor separately
        for floor in self.zone_floors:
            if isinstance(floor, PrismBasementZone):
                continue

            recovery_var_name = f'RECOV:{floor.name}{suffix_formatted}'
            mode_var_name = f'MODE:{floor.name}{suffix_formatted}'
            indoor_temp_var_name = f'TZ_OP:{floor.name}{suffix_formatted}'

            try:
                # Use previous time step's conditions to determine RECOV[k]
                # For k=0, use k=0 (will use defaults if not available)
                prev_k = max(0, k - 1)

                # Get outdoor temp for current time step k
                outdoor_temp_k = self.dp('weather_temperature', k)

                # Try to get mode from previous time step
                try:
                    mode = self.dp(mode_var_name, prev_k)
                except Exception:
                    # If not available, default to heating mode
                    mode = 1

                # Try to get indoor temp from previous time step
                try:
                    indoor_temp = self.dp(indoor_temp_var_name, prev_k)
                except Exception:
                    # If not available, use outdoor temp as fallback
                    indoor_temp = self.dp('weather_temperature', prev_k) if prev_k >= 0 else outdoor_temp_k

                # Free cooling condition:
                # 1. Mode is not heating (mode != 1) AND
                # 2. Indoor temp > normal_heating_setpoint + free_cooling_setpoint_margin (too hot) AND
                # 3. (outdoor temp + free_cooling_setpoint_margin) < indoor temp (outdoor is cooler)
                if (mode != 1 and  # mode 1 is heating
                        indoor_temp > (self.building_data.normal_heating_setpoint + self.building_data.free_cooling_setpoint_margin) and
                        (outdoor_temp_k + self.building_data.free_cooling_setpoint_margin) < indoor_temp):
                    # Free cooling active: disable heat recovery
                    efficiency_k = 0.0
                else:
                    # Use regular efficiency
                    efficiency_k = self.building_data.regular_ventilation_heat_recovery_efficiency

                # Update RECOV at time step k (this will be used for the model at time step k)
                # Note: This updates RECOV[k] which affects the fingerprint, so the model will be rebuilt
                self.dp(recovery_var_name, k, efficiency_k)
            except Exception:
                # If update fails, keep existing value
                pass

    def simulate(self, suffix: str = 'sim', verbose: bool = True) -> BuildingResult:
        """Run the building simulation and return results.

        If free_cooling_setpoint_margin is defined, RECOV is updated during simulation
        at each time step based on previous time step conditions (to avoid circular dependency).
        """
        tic: float = time.time()
        if verbose:
            print("=" * 20, "Context data", "=" * 20)
            print(json.dumps(asdict(self.context_data), ensure_ascii=False, separators=(",", ":")))
            print("=" * 20, "Building data", "=" * 20)
            print(json.dumps(asdict(self.building_data), ensure_ascii=False, separators=(",", ":")))
            print("=" * 20, "Building simulation", "=" * 20)

            print('Simulation started')
        # Initialize RECOV variables with default values before simulation
        self._initialize_ventilation_heat_recovery_efficiency(suffix=suffix)

        # Define action rule to update RECOV at each time step (called before state model is built)
        def update_recovery_action_rule(simulation, k: int) -> None:
            """Action rule to update RECOV[k] based on previous time step (k-1) conditions."""
            self._update_ventilation_heat_recovery_efficiency_at_k(k, suffix=suffix)

        # Run simulation with action rule to update RECOV during simulation
        if self.building_data.free_cooling_setpoint_margin is not None:
            self.simulation.run(suffix=suffix, action_rule=update_recovery_action_rule)
        else:
            self.simulation.run(suffix=suffix)

        floor_results: list[FloorResult] = []

        # Calculate HVAC consumption for each floor
        for floor in self.zone_floors:
            if isinstance(floor, PrismZoneFloor):
                phvac_var_name: str = f'PHVAC:{floor.name}#sim'
                phvac_production_Wh: list[float] = self.dp.series(phvac_var_name)
            else:
                phvac_production_Wh = [0.0] * len(self.dp.ks)

            floor_results.append(FloorResult(
                zone_key=floor.name,
                floor_surface_m2=_horizontal_conditioned_floor_area_m2(floor),
                envelope_surface_m2=float(floor.external_envelope_surface_m2),
                heat_production_Wh=phvac_production_Wh
            ))

        self.building_result: BuildingResult = BuildingResult(
            datetimes=self.datetimes,
            hvac_cop_heating=self.building_data.hvac_cop_heating,
            hvac_cop_cooling=self.building_data.hvac_cop_cooling,
            floor_results=floor_results
        )

        # Store building-level results
        building_heat_production_Wh: list[float] = self.building_result.heat_production_Wh
        self.dp.add_var('PHVAC:building#sim', building_heat_production_Wh)  # , force=True
        self.dp.add_var('HVAC_ELEC:building#sim', self._calculate_hvac_electric_consumption(building_heat_production_Wh))

        # Store floor-level results
        for floor_result in floor_results:
            # Use force=True to allow overwriting variables that may have been created during simulation
            # self.dp.add_var(f'PHVAC:{floor_result.zone_key}#sim', floor_result.heat_production_Wh) # , force=True
            self.dp.add_var(f'HVAC_ELEC:{floor_result.zone_key}#sim', self._calculate_hvac_electric_consumption(floor_result.heat_production_Wh))
        toc = time.time()
        if verbose:
            print(f"Simulation time: {toc - tic:.2f} seconds")
        return self.building_result

    def _collect_floor_hvac_power_recommendations_kW(self) -> dict[str, dict[str, float]]:
        """Peak and top-5%-average PHVAC per zone (kW), from ``PHVAC:<zone>#sim``."""
        out: dict[str, dict[str, float]] = {}
        for floor in self.zone_floors:
            name = floor.name
            if f'PHVAC:{name}#sim' not in self.dp:
                out[name] = {
                    'max_heating_kW': 0.0,
                    'avg5_heating_kW': 0.0,
                    'max_cooling_kW': 0.0,
                    'avg5_cooling_kW': 0.0,
                }
                continue
            phvac_series: list[float] = self.dp.series(f'PHVAC:{name}#sim')
            floor_heating_powers: list[float] = [p for p in phvac_series if p > 0]
            floor_cooling_powers: list[float] = [abs(p) for p in phvac_series if p < 0]
            rec: dict[str, float] = {}
            if floor_heating_powers:
                max_heating = max(floor_heating_powers)
                sorted_heating = sorted(floor_heating_powers, reverse=True)
                top_5_count = max(1, int(len(sorted_heating) * 0.05))
                avg_top_5_heating = sum(sorted_heating[:top_5_count]) / top_5_count
                rec['max_heating_kW'] = max_heating / 1000.0
                rec['avg5_heating_kW'] = avg_top_5_heating / 1000.0
            else:
                rec['max_heating_kW'] = 0.0
                rec['avg5_heating_kW'] = 0.0
            if floor_cooling_powers:
                max_cooling = max(floor_cooling_powers)
                sorted_cooling = sorted(floor_cooling_powers, reverse=True)
                top_5_count = max(1, int(len(sorted_cooling) * 0.05))
                avg_top_5_cooling = sum(sorted_cooling[:top_5_count]) / top_5_count
                rec['max_cooling_kW'] = max_cooling / 1000.0
                rec['avg5_cooling_kW'] = avg_top_5_cooling / 1000.0
            else:
                rec['max_cooling_kW'] = 0.0
                rec['avg5_cooling_kW'] = 0.0
            out[name] = rec
        return out

    def _print_hvac_power_recommendations(self) -> None:
        """Print recommended HVAC power sizing based on peak and top 5% average demands.

        Analyzes the HVAC power time series to recommend appropriate heating and cooling
        capacities. The maximum value represents absolute peak demand, while the top 5%
        average provides a more robust sizing recommendation that avoids over-sizing for
        rare extreme events.
        """
        print("=" * 20, "RECOMMENDED HVAC POWER SIZING", "=" * 20)

        recs = self._collect_floor_hvac_power_recommendations_kW()
        floor_recommendations: list[dict] = []
        for floor in self.zone_floors:
            r = recs.get(floor.name)
            if r is None:
                continue
            floor_recommendations.append({
                'floor_name': floor.name,
                'max_heating_kW': r['max_heating_kW'],
                'avg5_heating_kW': r['avg5_heating_kW'],
                'max_cooling_kW': r['max_cooling_kW'],
                'avg5_cooling_kW': r['avg5_cooling_kW'],
            })

        if floor_recommendations:
            for floor_recommendation in floor_recommendations:
                floor_name = floor_recommendation['floor_name']

                if floor_recommendation['max_heating_kW'] > 0:
                    print(f"  {floor_name:15s} - Heating:{floor_recommendation['max_heating_kW']:.1f}kW ({floor_recommendation['avg5_heating_kW']:.1f}kW@5%)", end="")
                else:
                    print(f"  {floor_name:15s} - Heating: None", end="")

                if floor_recommendation['max_cooling_kW'] > 0:
                    print(f"   |   Cooling:{floor_recommendation['max_cooling_kW']:.1f}kW ({floor_recommendation['avg5_cooling_kW']:.1f}kW@5%)")
                else:
                    print("   |   Cooling: None")

        print("=" * 30 + "\n")

    def _hvac_summary_floor_names_and_data(self) -> tuple[list[str], list[dict]]:
        """Annual HVAC / electricity / sizing summary per zone (same numbers as :meth:`print_results`)."""
        if self.building_result is None:
            try:
                floor_results: list[FloorResult] = []
                for floor in self.zone_floors:
                    phvac_var_name: str = f'PHVAC:{floor.name}#sim'
                    if phvac_var_name in self.dp:
                        phvac_production_Wh: list[float] = self.dp.series(phvac_var_name)
                    else:
                        phvac_production_Wh: list[float] = [0.0] * len(self.dp.ks)

                    floor_results.append(FloorResult(
                        zone_key=floor.name,
                        floor_surface_m2=_horizontal_conditioned_floor_area_m2(floor),
                        envelope_surface_m2=float(floor.external_envelope_surface_m2),
                        heat_production_Wh=phvac_production_Wh
                    ))

                self.building_result = BuildingResult(
                    datetimes=self.datetimes,
                    hvac_cop_heating=self.building_data.hvac_cop_heating,
                    hvac_cop_cooling=self.building_data.hvac_cop_cooling,
                    floor_results=floor_results,
                )
            except Exception:
                raise ValueError(
                    "No building_result provided and cannot reconstruct from stored data. "
                    "Please run simulate() first or provide a BuildingResult."
                ) from None

        floor_data: list[dict] = []
        floor_names: list[str] = []

        for floor_result in self.building_result.floor_results:
            heat_heating_kWh: float = sum(floor_result.heat_production_heating_Wh) / 1000.0
            heat_cooling_kWh: float = sum(floor_result.heat_production_cooling_Wh) / 1000.0
            heat_total_kWh: float = abs(heat_heating_kWh) + abs(heat_cooling_kWh)

            elec_heating_kWh = heat_heating_kWh / self.building_result.hvac_cop_heating if heat_heating_kWh > 0 else 0.0
            elec_cooling_kWh = abs(heat_cooling_kWh) / self.building_result.hvac_cop_cooling if heat_cooling_kWh < 0 else 0.0
            elec_total_kWh = elec_heating_kWh + elec_cooling_kWh

            total_floor_surface: float = floor_result.floor_surface_m2
            heat_total_per_m2: float = heat_total_kWh / total_floor_surface if total_floor_surface > 0 else 0.0
            heat_heating_per_m2: float = heat_heating_kWh / total_floor_surface if total_floor_surface > 0 else 0.0
            heat_cooling_per_m2: float = heat_cooling_kWh / total_floor_surface if total_floor_surface > 0 else 0.0
            elec_total_per_m2: float = elec_total_kWh / total_floor_surface if total_floor_surface > 0 else 0.0
            elec_heating_per_m2: float = elec_heating_kWh / total_floor_surface if total_floor_surface > 0 else 0.0
            elec_cooling_per_m2: float = elec_cooling_kWh / total_floor_surface if total_floor_surface > 0 else 0.0

            floor_names.append(floor_result.zone_key)
            floor_data.append({
                'surface': total_floor_surface,
                'envelope_surface': floor_result.envelope_surface_m2,
                'heat_total_kWh': heat_total_kWh,
                'heat_heating_kWh': heat_heating_kWh,
                'heat_cooling_kWh': heat_cooling_kWh,
                'elec_total_kWh': elec_total_kWh,
                'elec_heating_kWh': elec_heating_kWh,
                'elec_cooling_kWh': elec_cooling_kWh,
                'heat_total_per_m2': heat_total_per_m2,
                'heat_heating_per_m2': heat_heating_per_m2,
                'heat_cooling_per_m2': heat_cooling_per_m2,
                'elec_total_per_m2': elec_total_per_m2,
                'elec_heating_per_m2': elec_heating_per_m2,
                'elec_cooling_per_m2': elec_cooling_per_m2
            })

        sizing_by_zone = self._collect_floor_hvac_power_recommendations_kW()
        for data, floor_result in zip(floor_data, self.building_result.floor_results):
            rec = sizing_by_zone.get(floor_result.zone_key, {})
            data['max_heating_kW'] = float(rec.get('max_heating_kW', 0.0))
            data['avg5_heating_kW'] = float(rec.get('avg5_heating_kW', 0.0))
            data['max_cooling_kW'] = float(rec.get('max_cooling_kW', 0.0))
            data['avg5_cooling_kW'] = float(rec.get('avg5_cooling_kW', 0.0))

        building_heat_heating_kWh = sum(data['heat_heating_kWh'] for name, data in zip(floor_names, floor_data) if name != "basement")
        building_heat_cooling_kWh = sum(
            abs(data['heat_cooling_kWh']) for name, data in zip(floor_names, floor_data) if name != "basement"
        )
        building_heat_total_kWh = sum(data['heat_total_kWh'] for name, data in zip(floor_names, floor_data) if name != "basement")

        building_elec_heating_kWh = sum(data['elec_heating_kWh'] for name, data in zip(floor_names, floor_data) if name != "basement")
        building_elec_cooling_kWh = sum(data['elec_cooling_kWh'] for name, data in zip(floor_names, floor_data) if name != "basement")
        building_elec_total_kWh = sum(data['elec_total_kWh'] for name, data in zip(floor_names, floor_data) if name != "basement")

        building_surface = sum(data['surface'] for name, data in zip(floor_names, floor_data) if name != "basement")
        building_envelope_surface = sum(data['envelope_surface'] for name, data in zip(floor_names, floor_data) if name != "basement")
        building_heat_total_per_m2 = building_heat_total_kWh / building_surface if building_surface > 0 else 0.0
        building_heat_heating_per_m2 = building_heat_heating_kWh / building_surface if building_surface > 0 else 0.0
        building_heat_cooling_per_m2 = building_heat_cooling_kWh / building_surface if building_surface > 0 else 0.0
        building_elec_total_per_m2 = building_elec_total_kWh / building_surface if building_surface > 0 else 0.0
        building_elec_heating_per_m2 = building_elec_heating_kWh / building_surface if building_surface > 0 else 0.0
        building_elec_cooling_per_m2 = building_elec_cooling_kWh / building_surface if building_surface > 0 else 0.0

        occupied_zone_names = [fr.zone_key for fr in self.building_result.floor_results if fr.zone_key != "basement"]
        building_max_heating_kW = sum(sizing_by_zone.get(n, {}).get('max_heating_kW', 0.0) for n in occupied_zone_names)
        building_avg5_heating_kW = sum(sizing_by_zone.get(n, {}).get('avg5_heating_kW', 0.0) for n in occupied_zone_names)
        building_max_cooling_kW = sum(sizing_by_zone.get(n, {}).get('max_cooling_kW', 0.0) for n in occupied_zone_names)
        building_avg5_cooling_kW = sum(sizing_by_zone.get(n, {}).get('avg5_cooling_kW', 0.0) for n in occupied_zone_names)

        floor_names.append("BUILDING TOTAL")
        floor_data.append({
            'surface': building_surface,
            'envelope_surface': building_envelope_surface,
            'heat_total_kWh': building_heat_total_kWh,
            'heat_heating_kWh': building_heat_heating_kWh,
            'heat_cooling_kWh': building_heat_cooling_kWh,
            'elec_total_kWh': building_elec_total_kWh,
            'elec_heating_kWh': building_elec_heating_kWh,
            'elec_cooling_kWh': building_elec_cooling_kWh,
            'heat_total_per_m2': building_heat_total_per_m2,
            'heat_heating_per_m2': building_heat_heating_per_m2,
            'heat_cooling_per_m2': building_heat_cooling_per_m2,
            'elec_total_per_m2': building_elec_total_per_m2,
            'elec_heating_per_m2': building_elec_heating_per_m2,
            'elec_cooling_per_m2': building_elec_cooling_per_m2,
            'max_heating_kW': building_max_heating_kW,
            'avg5_heating_kW': building_avg5_heating_kW,
            'max_cooling_kW': building_max_cooling_kW,
            'avg5_cooling_kW': building_avg5_cooling_kW,
        })
        return floor_names, floor_data

    def _collect_floor_comfort_data(self) -> list[dict]:
        """Time series per zone for :meth:`~batem.core.inhabitants.Preference.print_comfort` / reports."""
        floor_comfort_data: list[dict] = []
        for floor in self.zone_floors:
            if f'PHVAC:{floor.name}#sim' in self.dp:
                modes_data = self.dp.series(f'MODE:{floor.name}') if f'MODE:{floor.name}' in self.dp else None
                floor_comfort_data.append({
                    'floor_name': floor.name,
                    'datetimes': self.dp.datetimes,
                    'PHVAC': self.dp.series(f'PHVAC:{floor.name}#sim'),
                    'temperatures': self.dp.series(f'TZ_OP:{floor.name}#sim'),
                    'CO2_concentrations': self.dp.series(f'CCO2:{floor.name}#sim'),
                    'occupancies': self.dp.series(f'OCCUPANCY:{floor.name}'),
                    'modes': modes_data,
                })
            elif f'TZ_OP:{floor.name}#sim' in self.dp:
                temps = self.dp.series(f'TZ_OP:{floor.name}#sim')
                cco2_key = f'CCO2:{floor.name}#sim'
                cco2_series: list[float] = self.dp.series(cco2_key) if cco2_key in self.dp else [0.0] * len(self.dp.ks)
                phvac_zeros = [0.0] * len(self.dp.ks)
                comfort_row: dict = {
                    'floor_name': floor.name,
                    'datetimes': self.dp.datetimes,
                    'PHVAC': phvac_zeros,
                    'temperatures': temps,
                    'CO2_concentrations': cco2_series,
                    'occupancies': self.dp.series(f'OCCUPANCY:{floor.name}'),
                    'modes': None,
                }
                if floor.name == "basement":
                    v = np.asarray(cco2_series, dtype=float)
                    if v.size == 0 or not np.any(np.isfinite(v) & (v > 1.0)):
                        outdoor_co2 = self.dp.series('CCO2:outdoor') if 'CCO2:outdoor' in self.dp else None
                        if outdoor_co2:
                            comfort_row['average_CO2_concentration'] = float(np.nanmean(np.asarray(outdoor_co2, dtype=float)))
                        else:
                            comfort_row['average_CO2_concentration'] = 400.0
                floor_comfort_data.append(comfort_row)
        return floor_comfort_data

    def print_results(self, preference: Preference = Preference(
            preferred_temperatures=(19, 26),
            extreme_temperatures=(16, 30),
            preferred_CO2_concentration=(500, 1700),
            temperature_weight_wrt_CO2=0.5,
            power_weight_wrt_comfort=0.5,
            sleeping_hours=(23, 0, 1, 2, 3, 4, 5, 6),
            power_unit='Wh')) -> None:
        """Print building and floor-level HVAC results in a formatted table.

        Displays heat needs (total, heating, cooling), electric consumption, and
        recommended HVAC sizing (peak and top-5% average power in kW) for each floor
        and the building total. The first area row is **conditioned floor footprint**
        (used for all kWh/m² columns); the second row is **external envelope** area for
        reference only. Building sizing totals sum occupied floors (excluding basement).

        :param augmented: If True, includes detailed comfort assessment per floor
        :type augmented: bool
        :param report_name: If provided, generates a markdown report with this name in the results folder
        :type report_name: str | None
        """
        preference.mode_cop = {
            1: self.building_data.hvac_cop_heating,
            -1: self.building_data.hvac_cop_cooling
        }

        floor_names, floor_data = self._hvac_summary_floor_names_and_data()

        # Create transposed table with metrics as rows and floors as columns
        table = prettytable.PrettyTable()
        table.field_names = ["Metric"] + floor_names

        # Add rows for each metric with both kWh and kWh/m²
        table.add_row(["Floor area (m²)"] + [f"{int(round(data['surface']))}" for data in floor_data])
        table.add_row(["External envelope (m²)"] + [f"{int(round(data['envelope_surface']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing

        table.add_row(["Heat Total (kWh)"] + [f"{int(round(data['heat_total_kWh']))}" for data in floor_data])
        table.add_row(["Heat Total (kWh/m²)"] + [f"{int(round(data['heat_total_per_m2']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing

        table.add_row(["Heat Heating (kWh)"] + [f"{int(round(data['heat_heating_kWh']))}" for data in floor_data])
        table.add_row(["Heat Heating (kWh/m²)"] + [f"{int(round(data['heat_heating_per_m2']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing

        table.add_row(["Heat Cooling (kWh)"] + [f"{int(round(data['heat_cooling_kWh']))}" for data in floor_data])
        table.add_row(["Heat Cooling (kWh/m²)"] + [f"{int(round(data['heat_cooling_per_m2']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing

        table.add_row(["Elec Total (kWh)"] + [f"{int(round(data['elec_total_kWh']))}" for data in floor_data])
        table.add_row(["Elec Total (kWh/m²)"] + [f"{int(round(data['elec_total_per_m2']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing

        table.add_row(["Elec Heating (kWh)"] + [f"{int(round(data['elec_heating_kWh']))}" for data in floor_data])
        table.add_row(["Elec Heating (kWh/m²)"] + [f"{int(round(data['elec_heating_per_m2']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing

        table.add_row(["Elec Cooling (kWh)"] + [f"{int(round(data['elec_cooling_kWh']))}" for data in floor_data])
        table.add_row(["Elec Cooling (kWh/m²)"] + [f"{int(round(data['elec_cooling_per_m2']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing
        table.add_row(["Sizing heating peak (kW)"] + [f"{data['max_heating_kW']:.1f}" for data in floor_data])
        table.add_row(["Sizing heating top 5% avg (kW)"] + [f"{data['avg5_heating_kW']:.1f}" for data in floor_data])
        table.add_row(["Sizing cooling peak (kW)"] + [f"{data['max_cooling_kW']:.1f}" for data in floor_data])
        table.add_row(["Sizing cooling top 5% avg (kW)"] + [f"{data['avg5_cooling_kW']:.1f}" for data in floor_data])

        # Set alignment - left for metric column, right for all floor columns
        table.align["Metric"] = "l"
        for floor_name in floor_names:
            table.align[floor_name] = "r"

        # Print table
        print()
        print('='*20, f"BUILDING HVAC RESULTS (COP Heating: {self.building_result.hvac_cop_heating:.2f} | COP Cooling: {self.building_result.hvac_cop_cooling:.2f})", "=" * 20)
        print(table)
        print("* Sizing: peak = max instantaneous PHVAC; top 5% avg = mean of highest 5% of heating or cooling demand samples.\n")

        floor_comfort_data = self._collect_floor_comfort_data()

        if floor_comfort_data:
            preference.print_comfort(floor_comfort_data)

    @staticmethod
    def _report_format_field_value(value: Any, max_len: int = 900) -> str:
        """Readable one-line value for report bullet lists (truncates huge structures)."""
        if value is None:
            return "—"
        if isinstance(value, float):
            if value != value:  # NaN
                return "NaN"
            return f"{value:.6g}".rstrip("0").rstrip(".")
        if isinstance(value, (list, tuple)):
            s = json.dumps(value, default=str)
        else:
            s = str(value)
        if len(s) > max_len:
            return s[: max_len - 1] + "…"
        return s

    def _report_dataclass_section_markdown(self, heading: str, obj: Any) -> str:
        """Markdown ``##`` section with one bullet per dataclass field."""
        if not is_dataclass(obj):
            return ""
        lines: list[str] = [f"## {heading}\n\n"]
        data = asdict(obj)
        for f in fields(obj):
            lines.append(f"- **{f.name}**: {self._report_format_field_value(data[f.name])}\n")
        lines.append("\n")
        return "".join(lines)

    def plot_heliodons(self) -> None:
        """Plot heliodons for every floor/window pair with positive glazing area."""
        windows_to_plot: list[tuple[PrismZoneFloor, int]] = []
        for floor in self.zone_floors:
            if not hasattr(floor, "window_surfaces"):
                continue
            for side_index, window_surface in enumerate(floor.window_surfaces):
                if window_surface > 0.0:
                    windows_to_plot.append((floor, side_index))

        if not windows_to_plot:
            return

        n_plots = len(windows_to_plot)
        n_cols = min(3, n_plots)
        n_rows = (n_plots + n_cols - 1) // n_cols
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(6 * n_cols, 5 * n_rows))
        if hasattr(axes, "ravel"):
            axes_flat = list(axes.ravel())
        else:
            axes_flat = [axes]

        for plot_index, (target_floor, side_index) in enumerate(windows_to_plot):
            # Use the actual window collector mask: façade visibility band
            # (d-90° -> d+90°) + local masks.
            window_mask = target_floor.window_masks()[f"side{side_index}"]
            self.context.solar_model.plot_heliodon(
                name=f"floor{target_floor.floor_index} side{side_index}",
                year=self.context_data.simulated_year,
                observer_elevation_m=target_floor.mid_elevation,
                mask=window_mask,
                axes=axes_flat[plot_index],
            )
            axes_flat[plot_index].set_title(f"Floor {target_floor.floor_index} - Side {side_index}")

        for idx in range(n_plots, len(axes_flat)):
            axes_flat[idx].axis("off")

        fig.tight_layout()
        plt.show()

    def plot3D(self) -> None:
        """Plot 3D view of the building with context side masks."""
        plotter: Plotter = Plotter(off_screen=False, window_size=(1024, 768))
        for side_mask_data in self.building_data.sides_mask:
            side_mask_view: SideMaskView = SideMaskView(side_mask_data)
            side_mask_view.draw(plotter)
        plotter.set_background("white")
        self.building_view.draw(plotter)
        self.draw_context_side_masks(plotter)
        _pyvista_show_then_destroy(plotter, auto_close=True)

    def _report_hvac_markdown_table(self, floor_names: list[str], floor_data: list[dict]) -> str:
        """Markdown pipe table matching the HVAC PrettyTable in :meth:`print_results`."""
        lines: list[str] = []
        lines.append("| Metric | " + " | ".join(floor_names) + " |\n")
        lines.append("|" + "---|" * (len(floor_names) + 1) + "\n")
        lines.append("| **Floor area (m²)** | " + " | ".join([f"{int(round(d['surface']))}" for d in floor_data]) + " |\n")
        lines.append("| **External envelope (m²)** | " + " | ".join([f"{int(round(d['envelope_surface']))}" for d in floor_data]) + " |\n")
        lines.append("|  | " + " | ".join([""] * len(floor_names)) + " |\n")
        lines.append("| **Heat Total (kWh)** | " + " | ".join([f"{int(round(d['heat_total_kWh']))}" for d in floor_data]) + " |\n")
        lines.append("| **Heat Total (kWh/m²)** | " + " | ".join([f"{int(round(d['heat_total_per_m2']))}" for d in floor_data]) + " |\n")
        lines.append("|  | " + " | ".join([""] * len(floor_names)) + " |\n")
        lines.append("| **Heat Heating (kWh)** | " + " | ".join([f"{int(round(d['heat_heating_kWh']))}" for d in floor_data]) + " |\n")
        lines.append("| **Heat Heating (kWh/m²)** | " + " | ".join([f"{int(round(d['heat_heating_per_m2']))}" for d in floor_data]) + " |\n")
        lines.append("|  | " + " | ".join([""] * len(floor_names)) + " |\n")
        lines.append("| **Heat Cooling (kWh)** | " + " | ".join([f"{int(round(d['heat_cooling_kWh']))}" for d in floor_data]) + " |\n")
        lines.append("| **Heat Cooling (kWh/m²)** | " + " | ".join([f"{int(round(d['heat_cooling_per_m2']))}" for d in floor_data]) + " |\n")
        lines.append("|  | " + " | ".join([""] * len(floor_names)) + " |\n")
        lines.append("| **Elec Total (kWh)** | " + " | ".join([f"{int(round(d['elec_total_kWh']))}" for d in floor_data]) + " |\n")
        lines.append("| **Elec Total (kWh/m²)** | " + " | ".join([f"{int(round(d['elec_total_per_m2']))}" for d in floor_data]) + " |\n")
        lines.append("|  | " + " | ".join([""] * len(floor_names)) + " |\n")
        lines.append("| **Elec Heating (kWh)** | " + " | ".join([f"{int(round(d['elec_heating_kWh']))}" for d in floor_data]) + " |\n")
        lines.append("| **Elec Heating (kWh/m²)** | " + " | ".join([f"{int(round(d['elec_heating_per_m2']))}" for d in floor_data]) + " |\n")
        lines.append("|  | " + " | ".join([""] * len(floor_names)) + " |\n")
        lines.append("| **Elec Cooling (kWh)** | " + " | ".join([f"{int(round(d['elec_cooling_kWh']))}" for d in floor_data]) + " |\n")
        lines.append("| **Elec Cooling (kWh/m²)** | " + " | ".join([f"{int(round(d['elec_cooling_per_m2']))}" for d in floor_data]) + " |\n")
        lines.append("|  | " + " | ".join([""] * len(floor_names)) + " |\n")
        lines.append("| **Sizing heating peak (kW)** | " + " | ".join([f"{d['max_heating_kW']:.1f}" for d in floor_data]) + " |\n")
        lines.append("| **Sizing heating top 5% avg (kW)** | " + " | ".join([f"{d['avg5_heating_kW']:.1f}" for d in floor_data]) + " |\n")
        lines.append("| **Sizing cooling peak (kW)** | " + " | ".join([f"{d['max_cooling_kW']:.1f}" for d in floor_data]) + " |\n")
        lines.append("| **Sizing cooling top 5% avg (kW)** | " + " | ".join([f"{d['avg5_cooling_kW']:.1f}" for d in floor_data]) + " |\n")
        return "".join(lines)

    @staticmethod
    def _report_safe_filename_component(name: str) -> str:
        s = "".join(c if (c.isalnum() or c in "-_") else "_" for c in name.strip())
        return s[:96] if s else "window"

    def _save_footprint_figure_png(self, output_path: str) -> bool:
        """Save a 2D footprint plot (same style as :meth:`BuildingData.plot_footprint`)."""
        try:
            footprint = self.building_data.footprint
            if len(footprint) < 1:
                return False
            xs: list[float] = [vertex[0] for vertex in footprint]
            ys: list[float] = [vertex[1] for vertex in footprint]
            fig, ax = plt.subplots(figsize=(7.0, 7.0))
            ax.plot(xs, ys, color="C0", linewidth=1.8, alpha=0.85, zorder=1)
            ax.scatter(xs, ys, c="C0", s=90, zorder=3, edgecolors="black", linewidths=1.0)
            for i, (x, y) in enumerate(footprint):
                ax.annotate(str(i), (x, y), xytext=(5, 5), textcoords="offset points", fontsize=11, fontweight="bold")
            ax.set_aspect("equal", adjustable="box")
            ax.grid(True, alpha=0.35)
            ax.set_xlabel("x (m)")
            ax.set_ylabel("y (m)")
            ax.set_title("Footprint")
            fig.tight_layout()
            fig.savefig(output_path, dpi=150, bbox_inches="tight")
            plt.close(fig)
            return True
        except Exception:
            return False

    def _save_heliodon_figures_per_window(self, figures_dir: str, base: str) -> list[tuple[str, str]]:
        """One PNG per façade window; returns ``(markdown_title, relative_path)`` entries (paths under ``figures/``)."""
        entries: list[tuple[str, str]] = []
        first_date: datetime = self.dp.weather_data.datetimes[0]
        year: int = int(first_date.year)

        for floor in self.zone_floors:
            if not isinstance(floor, PrismZoneFloor):
                continue
            window_masks_dict: dict[str, Mask] = floor.window_masks()
            if not window_masks_dict:
                continue

            windows_with_surface: dict[str, Mask] = {}
            if hasattr(floor, "window_surfaces") and hasattr(floor, "windows_names"):
                for window_name, window_surface in zip(floor.windows_names, floor.window_surfaces):
                    if window_name in window_masks_dict and window_surface > 0:
                        windows_with_surface[window_name] = window_masks_dict[window_name]
            else:
                windows_with_surface = dict(window_masks_dict)

            if not windows_with_surface:
                continue

            for window_name, window_mask in windows_with_surface.items():
                try:
                    fig, ax = plt.subplots(figsize=(6.5, 5.5))
                    self.context.solar_model.plot_heliodon(
                        name=f"{floor.name} {window_name}",
                        year=year,
                        observer_elevation_m=floor.mid_elevation,
                        mask=window_mask,
                        axes=ax,
                    )
                    ax.set_title(f"{floor.name} — {window_name}")
                    ax.set_xlabel("Azimuth (°; 0° = South, +90° = West)")
                    fig.tight_layout()
                    fn = (
                        f"{base}_heliodon_{self._report_safe_filename_component(floor.name)}_"
                        f"{self._report_safe_filename_component(window_name)}.png"
                    )
                    out_abs = os.path.join(figures_dir, fn)
                    fig.savefig(out_abs, dpi=150, bbox_inches="tight")
                    plt.close(fig)
                    entries.append((f"{floor.name} — {window_name}", f"figures/{fn}"))
                except Exception:
                    try:
                        plt.close("all")
                    except Exception:
                        pass
                    continue

        return entries

    def _report_zone_sim_trajectories_markdown(self, results_folder: str, base: str) -> str:
        """Per-zone PNGs: **PZ** alone (kW), then temperatures/setpoint/operative on a second chart."""
        figures_dir = os.path.join(results_folder, "figures")
        os.makedirs(figures_dir, exist_ok=True)
        lines: list[str] = [
            "## Zone simulation trajectories\n\n",
            "Two figures per zone: **PZ:*#sim** (kW) on its own plot; **TZ:*#sim**, **SETPOINT:**…, and "
            "**PZ_OP:*#sim** or **TZ_OP:*#sim** when applicable (°C). "
            "Setpoints use the `#sim` name only when that series exists in the data provider.\n\n",
        ]
        try:
            datetimes = self.dp.datetimes
        except Exception:
            lines.append("*Could not read simulation datetimes; zone trajectories skipped.*\n\n")
            return "".join(lines)

        for floor in self.zone_floors:
            z = floor.name
            pz_key = f"PZ:{z}#sim"
            if pz_key not in self.dp:
                lines.append(f"### {z}\n\n*{pz_key} not in DataProvider — skipped.*\n\n")
                continue

            tz_sim = f"TZ:{z}#sim"
            tz_op_sim = f"TZ_OP:{z}#sim"
            set_sim = f"SETPOINT:{z}#sim"
            set_plain = f"SETPOINT:{z}"
            pz_op_sim = f"PZ_OP:{z}#sim"

            temp_traces: list[tuple[str, str]] = []
            if tz_sim in self.dp:
                temp_traces.append((tz_sim, tz_sim))
            elif tz_op_sim in self.dp:
                temp_traces.append((tz_op_sim, tz_op_sim))
            if set_sim in self.dp:
                temp_traces.append((set_sim, set_sim))
            elif set_plain in self.dp:
                temp_traces.append((set_plain, set_plain))
            if pz_op_sim in self.dp:
                if all(k != pz_op_sim for _, k in temp_traces):
                    temp_traces.append((pz_op_sim, pz_op_sim))
            elif tz_sim in self.dp and tz_op_sim in self.dp:
                if all(k != tz_op_sim for _, k in temp_traces):
                    temp_traces.append((tz_op_sim, tz_op_sim))

            fn_pz = f"{base}_zone_PZ_{self._report_safe_filename_component(z)}.png"
            fn_t = f"{base}_zone_T_{self._report_safe_filename_component(z)}.png"
            out_pz = os.path.join(figures_dir, fn_pz)
            out_t = os.path.join(figures_dir, fn_t)
            try:
                pz_w = self.dp.series(pz_key)
                pz_kw = [(w / 1000.0) if w is not None and not (isinstance(w, float) and np.isnan(w)) else float("nan") for w in pz_w]

                fig_pz, ax_pz = plt.subplots(figsize=(11.0, 3.6))
                ax_pz.plot(datetimes, pz_kw, color="#b45309", linewidth=0.95, label=f"{pz_key} (kW)")
                ax_pz.set_ylabel("kW")
                ax_pz.set_title(f"{z} — {pz_key}")
                ax_pz.grid(True, alpha=0.35)
                ax_pz.legend(loc="upper left", fontsize=8, framealpha=0.92)
                fig_pz.autofmt_xdate()
                fig_pz.tight_layout()
                fig_pz.savefig(out_pz, dpi=140, bbox_inches="tight")
                plt.close(fig_pz)

                fig_t, ax_t = plt.subplots(figsize=(11.0, 4.2))
                colors_t = ("#1d4ed8", "#15803d", "#7c3aed", "#be185d")
                for i, (lab, key) in enumerate(temp_traces):
                    vals = self.dp.series(key)
                    ax_t.plot(
                        datetimes,
                        vals,
                        color=colors_t[i % len(colors_t)],
                        linewidth=0.85,
                        label=lab,
                    )
                ax_t.set_ylabel("Temperature (°C)")
                ax_t.set_title(f"{z} — temperatures & setpoint")
                ax_t.grid(True, alpha=0.35)
                if temp_traces:
                    ax_t.legend(loc="upper left", fontsize=7, framealpha=0.92, ncol=2)
                fig_t.autofmt_xdate()
                fig_t.tight_layout()
                fig_t.savefig(out_t, dpi=140, bbox_inches="tight")
                plt.close(fig_t)

                lines.append(f"### {z}\n\n")
                lines.append(f"![{z} — {pz_key}](figures/{fn_pz})\n\n")
                lines.append(f"![{z} — temperatures](figures/{fn_t})\n\n")
            except Exception as exc:
                try:
                    plt.close("all")
                except Exception:
                    pass
                lines.append(f"### {z}\n\n*Figure could not be generated: {exc}*\n\n")

        return "".join(lines)

    def _report_geometry_figures_markdown(self, results_folder: str, base: str) -> str:
        """Generate footprint, 3D, and per-window heliodon PNGs; return trailing Markdown sections."""
        figures_dir = os.path.join(results_folder, "figures")
        os.makedirs(figures_dir, exist_ok=True)
        lines: list[str] = [
            "## Footprint\n\n",
        ]
        fp_name = f"{base}_footprint.png"
        fp_abs = os.path.join(figures_dir, fp_name)
        if self._save_footprint_figure_png(fp_abs):
            lines.append(f"![Footprint plan](figures/{fp_name})\n\n")
        else:
            lines.append("*Footprint figure could not be generated.*\n\n")

        lines.append("## Building 3D view\n\n")
        b3d_name = f"{base}_building_3d.png"
        b3d_abs = os.path.join(figures_dir, b3d_name)
        try:
            self.save_building_plot(b3d_abs)
            lines.append(f"![Building 3D](figures/{b3d_name})\n\n")
        except Exception as exc:
            lines.append(f"*3D view could not be generated: {exc}*\n\n")

        lines.append("## Heliodons (one chart per window)\n\n")
        helios = self._save_heliodon_figures_per_window(figures_dir, base)
        if helios:
            for title, rel in helios:
                lines.append(f"### {title}\n\n")
                lines.append(f"![Heliodon {title}]({rel})\n\n")
        else:
            lines.append("*No heliodon figures (no windows with solar masks on simulated storeys).*\n\n")

        return "".join(lines)

    _REPORT_PDF_CSS: str = """
    @page { size: A4; margin: 16mm 14mm 18mm 14mm; }
    html { font-size: 10.5pt; }
    body {
      font-family: "Helvetica Neue", Helvetica, Arial, "DejaVu Sans", sans-serif;
      line-height: 1.42;
      color: #1b1f24;
      max-width: 100%;
    }
    h1 {
      font-size: 1.55rem; font-weight: 700; letter-spacing: -0.02em;
      margin: 0 0 0.5em 0; padding-bottom: 0.25em;
      border-bottom: 2px solid #c5ccd6; color: #0f172a;
    }
    h2 {
      font-size: 1.18rem; font-weight: 650; margin: 1.35em 0 0.45em 0;
      color: #1e3a5f; page-break-after: avoid;
    }
    h3 {
      font-size: 1.02rem; font-weight: 600; margin: 1em 0 0.35em 0;
      color: #334155; page-break-after: avoid;
    }
    p { margin: 0.4em 0; orphans: 3; widows: 3; }
    ul { margin: 0.35em 0 0.6em 1.1em; padding: 0; }
    li { margin: 0.15em 0; }
    em { color: #475569; }
    table {
      border-collapse: collapse; width: 100%; margin: 0.65em 0;
      font-size: 0.92rem; page-break-inside: auto;
    }
    thead { display: table-header-group; }
    tr { page-break-inside: avoid; page-break-after: auto; }
    th, td {
      border: 1px solid #b8c4d4; padding: 0.35em 0.45em;
      vertical-align: top; text-align: left;
    }
    th { background: #e8edf4; font-weight: 600; color: #0f172a; }
    tbody tr:nth-child(even) { background: #f8fafc; }
    tbody tr:nth-child(odd) { background: #fff; }
    img {
      max-width: 100%; height: auto; display: block; margin: 0.5em auto;
      page-break-inside: avoid; border: 1px solid #e2e8f0; border-radius: 2px;
    }
    pre {
      font-family: ui-monospace, "Cascadia Code", Consolas, monospace;
      font-size: 0.86rem; line-height: 1.35;
      background: #f1f5f9; border: 1px solid #e2e8f0; border-radius: 4px;
      padding: 0.65em 0.85em; white-space: pre-wrap; overflow-wrap: anywhere;
      page-break-inside: avoid;
    }
    code { font-family: inherit; font-size: 0.95em; background: #f1f5f9; padding: 0.08em 0.25em; border-radius: 3px; }
    hr { border: none; border-top: 1px solid #e2e8f0; margin: 1.2em 0; }
    a { color: #0c4a6e; text-decoration: none; }
    blockquote {
      margin: 0.5em 0; padding: 0.35em 0.75em; border-left: 3px solid #94a3b8;
      background: #f8fafc; color: #334155;
    }
    """

    def _markdown_to_report_html_fragment(self, markdown_text: str) -> str:
        """Markdown → HTML body fragment (pandoc); falls back to escaped pre."""
        try:
            import pypandoc
            return pypandoc.convert_text(
                markdown_text,
                to="html5",
                format="gfm",
                extra_args=["--syntax-highlighting=none"],
            )
        except Exception:
            try:
                import pypandoc
                return pypandoc.convert_text(markdown_text, to="html5", format="markdown")
            except Exception:
                return f"<pre>{html.escape(markdown_text)}</pre>"

    @staticmethod
    def _rewrite_img_src_to_file_urls(html_fragment: str, results_folder: str) -> str:
        """Turn ``<img src=\"figures/...\">`` into ``file://`` URLs so xhtml2pdf resolves them."""
        root = Path(results_folder).resolve()

        def sub(match: re.Match) -> str:
            src = match.group(1).strip()
            if src.startswith(("http://", "https://", "file:")):
                return match.group(0)
            p = (root / src).resolve()
            if p.is_file():
                return f'src="{p.as_uri()}"'
            return match.group(0)

        return re.sub(r'(?i)src="([^"]+)"', sub, html_fragment)

    @staticmethod
    def _embed_report_img_tags_as_data_uri(
        html_fragment: str, results_folder: str, max_image_bytes: int = 20_000_000
    ) -> str:
        """Inline local PNG/JPEG images under ``results_folder`` as data URIs.

        WeasyPrint and xhtml2pdf sometimes omit raster figures when resolving
        relative ``figures/…`` paths or ``file://`` URLs; embedding avoids that.
        """
        root = Path(results_folder).resolve()
        mime_by_suffix: dict[str, str] = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".gif": "image/gif",
            ".webp": "image/webp",
        }

        def _under_results(path: Path) -> bool:
            try:
                path.resolve().relative_to(root)
                return True
            except ValueError:
                return False

        def _resolve_src(src_raw: str) -> Path | None:
            s = (src_raw or "").strip()
            if not s or s.lower().startswith("data:"):
                return None
            if s.startswith(("http://", "https://")):
                return None
            if s.startswith("file:"):
                parsed = urlparse(s)
                path_part = unquote(parsed.path or "")
                p = Path(path_part) if path_part else None
                if p is None or not p.is_file():
                    return None
            else:
                p = (root / s).resolve()
            if not p.is_file() or not _under_results(p):
                return None
            return p

        img_tag_re = re.compile(r"(?is)<img\b([^>]*?)(/?)>")

        def repl(m: re.Match[str]) -> str:
            attrs, void = m.group(1), m.group(2) or ""
            src_m = re.search(r'(?is)\bsrc\s*=\s*(["\'])(.*?)\1', attrs)
            if not src_m:
                return m.group(0)
            quote = src_m.group(1)
            p = _resolve_src(src_m.group(2))
            if p is None:
                return m.group(0)
            try:
                if p.stat().st_size > max_image_bytes:
                    return m.group(0)
            except OSError:
                return m.group(0)
            mime = mime_by_suffix.get(p.suffix.lower())
            if mime is None:
                return m.group(0)
            try:
                raw = p.read_bytes()
            except OSError:
                return m.group(0)
            b64 = base64.standard_b64encode(raw).decode("ascii")
            new_src = f"data:{mime};base64,{b64}"
            new_attrs = attrs[: src_m.start()] + f"src={quote}{new_src}{quote}" + attrs[src_m.end():]
            return f"<img{new_attrs}{void}>"

        return img_tag_re.sub(repl, html_fragment)

    def _try_write_report_pdf_from_markdown(self, markdown_text: str, pdf_path: str, results_folder: str) -> bool:
        """Build a print-styled HTML report and render PDF (WeasyPrint preferred).

        ``results_folder`` is used as WeasyPrint ``base_url`` so ``figures/…`` paths
        in the Markdown resolve correctly.
        """
        body_html = self._markdown_to_report_html_fragment(markdown_text)
        body_for_pdf = self._embed_report_img_tags_as_data_uri(body_html, results_folder)
        full_html = (
            "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"/>"
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>"
            f"<style>{self._REPORT_PDF_CSS}</style></head><body>{body_for_pdf}</body></html>"
        )
        base_uri = Path(results_folder).resolve().as_uri() + "/"
        results_abs = str(Path(results_folder).resolve()) + os.sep

        # 1) WeasyPrint (best typography + CSS; images via base_url)
        try:
            from weasyprint import HTML  # noqa: PLC0415 — optional heavy deps (Pango/GTK on some hosts)

            HTML(string=full_html, base_url=base_uri).write_pdf(pdf_path)
            if os.path.isfile(pdf_path) and os.path.getsize(pdf_path) > 0:
                return True
        except (ImportError, OSError, Exception):
            try:
                if os.path.isfile(pdf_path):
                    os.remove(pdf_path)
            except OSError:
                pass

        # 2) Pandoc → PDF (needs a LaTeX engine when available)
        try:
            import pypandoc

            pypandoc.convert_text(
                markdown_text,
                to="pdf",
                format="gfm",
                outputfile=pdf_path,
                extra_args=[
                    "--resource-path=" + str(Path(results_folder).resolve()),
                    "-V", "geometry:margin=0.85in",
                    "-V", "fontsize=10pt",
                    "-V", "documentclass=article",
                ],
            )
            if os.path.isfile(pdf_path) and os.path.getsize(pdf_path) > 0:
                return True
        except Exception:
            try:
                if os.path.isfile(pdf_path):
                    os.remove(pdf_path)
            except OSError:
                pass

        # 3) xhtml2pdf: same CSS; data-URI images from embedding + file:// for any remainder
        body_for_pisa = self._rewrite_img_src_to_file_urls(body_for_pdf, results_folder)
        doc = (
            "<!DOCTYPE html><html><head><meta charset=\"utf-8\"/>"
            f"<style>{self._REPORT_PDF_CSS}</style></head><body>"
            f"{body_for_pisa}</body></html>"
        )
        try:
            with open(pdf_path, "wb") as pdf_file:
                status = pisa.CreatePDF(doc, dest=pdf_file, path=results_abs)
            if getattr(status, "err", 0):
                try:
                    os.remove(pdf_path)
                except OSError:
                    pass
                return False
            return os.path.isfile(pdf_path) and os.path.getsize(pdf_path) > 0
        except Exception:
            try:
                if os.path.isfile(pdf_path):
                    os.remove(pdf_path)
            except OSError:
                pass
            return False

    def print_report(self, file_name: str, preference: Preference) -> tuple[str, str | None]:
        """Write a readable Markdown report (and PDF when conversion succeeds).

        Output files are written under the ``results`` work folder (see
        :class:`~batem.core.utils.FilePathBuilder`). The Markdown file is always
        produced as ``<base>.md``. A ``<base>.pdf`` is written when **WeasyPrint**
        can render styled HTML (preferred), or pandoc can emit PDF (LaTeX), or
        :mod:`xhtml2pdf` succeeds as a last resort.

        :param file_name: Base name or path ending in ``.md`` / ``.pdf`` / no extension
        :param preference: Comfort / cost preferences (COP is taken from :attr:`building_data`)
        :return: ``(path_to_md, path_to_pdf_or_None)``
        """
        preference.mode_cop = {
            1: self.building_data.hvac_cop_heating,
            -1: self.building_data.hvac_cop_cooling,
        }

        base = os.path.basename(file_name)
        if base.lower().endswith(".md"):
            base = base[:-3]
        elif base.lower().endswith(".pdf"):
            base = base[:-4]
        base = base.strip() or "building_report"

        results_folder = FilePathBuilder().get_work_folder("results")
        os.makedirs(results_folder, exist_ok=True)
        md_path = os.path.join(results_folder, f"{base}.md")
        pdf_path = os.path.join(results_folder, f"{base}.pdf")

        floor_names, floor_data = self._hvac_summary_floor_names_and_data()
        floor_comfort = self._collect_floor_comfort_data()

        parts: list[str] = [
            "# Building simulation report\n\n",
            f"*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*\n\n",
            self._report_dataclass_section_markdown("Site and climate (ContextData)", self.context_data),
            self._report_dataclass_section_markdown("Building definition (BuildingData)", self.building_data),
            "## HVAC system configuration\n\n",
            f"- **Heating COP**: {self.building_result.hvac_cop_heating:.2f}\n",
            f"- **Cooling COP**: {self.building_result.hvac_cop_cooling:.2f}\n\n",
            "## Energy and sizing summary\n\n",
            "Conditioned floor footprint is used for all kWh/m² columns; the second area row is external envelope.\n\n",
            self._report_hvac_markdown_table(floor_names, floor_data),
            "\n*Sizing: peak = max instantaneous PHVAC; top 5% avg = mean of highest 5% of heating or cooling demand samples.*\n\n",
        ]
        if floor_comfort:
            parts.append("## Comfort assessment summary\n\n")
            parts.append(preference.comfort_summary_markdown(floor_comfort))
            parts.append("\n")
        parts.append(self._report_zone_sim_trajectories_markdown(results_folder, base))
        parts.append("## Occupant preference (used for comfort table)\n\n")
        parts.append(f"```\n{preference!s}\n```\n")
        parts.append(self._report_geometry_figures_markdown(results_folder, base))

        md_text = "".join(parts)
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(md_text)

        pdf_written: str | None = None
        if self._try_write_report_pdf_from_markdown(md_text, pdf_path, results_folder):
            pdf_written = pdf_path

        return md_path, pdf_written

    def draw_context_side_masks(self, plotter: Plotter, *, mask_opacity: float | None = None) -> None:
        """Draw 3D obstacles from ``ContextData.side_masks`` (``Context.side_mask_views``).

        :param mask_opacity: If set, passed to each :class:`SideMaskView` draw (e.g. higher opacity for PNG export).
        """
        for side_mask_view in self.context.side_mask_views:
            side_mask_view.draw(plotter, opacity=mask_opacity)

    def draw(self, window_size: tuple[int, int] = (1024, 768)) -> None:
        """Display the 3D building visualization in an interactive window.

        :param window_size: Window size in pixels (width, height)
        :type window_size: tuple[int, int]
        """
        plotter: Plotter = pv.Plotter(window_size=window_size)
        plotter.set_background("white")
        plotter.clear()
        if self.building_view is not None:
            self.building_view.draw(plotter)
        ground: PolyData = pv.Plane(center=(0, 0, 0), direction=(0, 0, 1), i_size=60, j_size=60)
        plotter.add_mesh(ground, color="#DDDDDD", opacity=1)
        self.draw_context_side_masks(plotter)
        plotter.add_axes(line_width=2)
        plotter.show_bounds(grid="front", location="outer", all_edges=True, xtitle="X (West -> East)", ytitle="Y (South -> North)", ztitle="Z (Up)")
        plotter.enable_eye_dome_lighting()
        plotter.camera_position = [(25, -35, 25), (0, 0, 5), (0, 0, 1)]
        _pyvista_show_then_destroy(plotter, auto_close=False)

    def save_building_plot(self, output_path: str, window_size: tuple[int, int] = (1600, 1200)) -> None:
        """Save the 3D building visualization to an image file.

        Automatically frames the entire building in view with a 3/4 perspective angle.

        :param output_path: Path where the image will be saved
        :type output_path: str
        :param window_size: Window size in pixels (width, height) for rendering
        :type window_size: tuple[int, int]
        """
        plotter: Plotter = pv.Plotter(off_screen=True, window_size=window_size)
        plotter.set_background("white")
        plotter.clear()
        if self.building_view is not None:
            self.building_view.draw(plotter)
        ground: PolyData = pv.Plane(center=(0, 0, 0), direction=(0, 0, 1), i_size=60, j_size=60)
        plotter.add_mesh(ground, color="#DDDDDD", opacity=1)
        # Slightly higher opacity for off-screen PNG: eye-dome + default 0.35 often makes masks vanish.
        self.draw_context_side_masks(plotter, mask_opacity=0.58)
        plotter.add_axes(line_width=2)
        plotter.show_bounds(grid="front", location="outer", all_edges=True, xtitle="X (West -> East)", ytitle="Y (South -> North)", ztitle="Z (Up)")
        # Do not use eye-dome lighting here: with translucent meshes it often drops masks from the saved image.

        # Reset camera to fit all actors (building, ground, masks, etc.)
        plotter.reset_camera()

        # Get the bounds of all actors to calculate building center and size
        bounds = plotter.renderer.ComputeVisiblePropBounds()
        if bounds[0] < bounds[1]:  # Check if we have valid bounds
            # Calculate building center
            center_x = (bounds[0] + bounds[1]) / 2
            center_y = (bounds[2] + bounds[3]) / 2
            center_z = (bounds[4] + bounds[5]) / 2

            # Calculate building dimensions
            size_x = bounds[1] - bounds[0]
            size_y = bounds[3] - bounds[2]
            size_z = bounds[5] - bounds[4]
            max_size = max(size_x, size_y, size_z)

            # Set camera position for a 3/4 perspective view
            # Position camera at a distance proportional to building size
            distance = max_size * 2.5
            camera_position = [
                center_x + distance * 0.7,  # Offset in X
                center_y - distance * 0.7,   # Offset in Y (negative for better angle)
                center_z + distance * 0.4     # Offset in Z (elevated view)
            ]
            focal_point = [center_x, center_y, center_z + size_z * 0.3]  # Focus slightly above ground
            view_up = [0, 0, 1]  # Z-axis is up

            plotter.camera_position = [camera_position, focal_point, view_up]

            # Zoom out slightly to ensure everything is visible with some margin
            plotter.camera.zoom(0.9)

        plotter.render()
        plotter.screenshot(output_path)
        plotter.close()

    def plot_heliodon(self, floor_index: int) -> Any | None:
        """Plot heliodon charts for every window on one occupied storey.

        For each façade glazing, calls :meth:`~batem.core.solar.SolarModel.plot_heliodon` with that
        collector’s mask, ``observer_elevation_m`` at the floor mid-elevation, and the weather year.
        The combined mask is horizon + context distant masks + the window mask.

        :param floor_index: Occupied storey index to plot: ``0`` = ground storey (``floor0``), …, ``n_floors - 1`` = top storey.
        :return: List-like of subplot axes, or ``None`` if the floor has no windows to plot.
        """
        # Get year from weather data if not provided

        first_date: datetime = self.dp.weather_data.datetimes[0]
        year: int = first_date.year
        floor: Any = None
        for f in self.zone_floors:
            if isinstance(f, PrismZoneFloor) and f.floor_index == floor_index:
                floor = f
                break
        if floor is None:
            raise ValueError(f'Occupied storey index {floor_index} not found in building (expected 0 … {self.building_data.n_floors - 1})')
        window_masks_dict: dict[str, Mask] = floor.window_masks()
        if len(window_masks_dict) == 0:
            # Skip floors with no windows (e.g., basement)
            return None

        # Filter windows to only include those with surface > 0
        # Check if floor has window_surfaces attribute (RegularZone) and filter accordingly
        windows_with_surface: dict[str, Mask] = {}
        if hasattr(floor, 'window_surfaces') and hasattr(floor, 'windows_names'):
            for window_name, window_surface in zip(floor.windows_names, floor.window_surfaces):
                if window_name in window_masks_dict and window_surface > 0:
                    windows_with_surface[window_name] = window_masks_dict[window_name]
        else:
            # Fallback: use all windows if we can't check surface
            windows_with_surface = window_masks_dict

        if len(windows_with_surface) == 0:
            # Skip floors with no windows with surface > 0
            return None

        # Calculate grid size based on number of windows
        n_windows = len(windows_with_surface)
        if n_windows == 1:
            n_rows, n_cols = 1, 1
        elif n_windows == 2:
            n_rows, n_cols = 1, 2
        elif n_windows == 3:
            n_rows, n_cols = 2, 2
        else:  # 4 or more
            n_rows, n_cols = 2, 2

        fig, axes = plt.subplots(n_rows, n_cols, figsize=(12, 8))
        if n_windows == 1:
            axes = [axes]  # Make it a list for consistent iteration
        else:
            axes = axes.flatten()  # Flatten 2D array to 1D for easier indexing
        fig.suptitle(f'Heliodon for {floor.name}, Elevation: {floor.mid_elevation:.1f}m', fontsize=12)

        for i, (window_name, window_mask) in enumerate(windows_with_surface.items()):
            if i >= len(axes):
                break  # Safety check: don't exceed available subplots
            self.context.solar_model.plot_heliodon(name=f'Window {window_name}', year=year, observer_elevation_m=floor.mid_elevation, mask=window_mask, axes=axes[i])
            axes[i].set_title(f'Window {window_name}')
            axes[i].set_xlabel('Azimuth in degrees (0° = South, +90° =West)')

        # Hide unused subplots
        for i in range(len(windows_with_surface), len(axes)):
            axes[i].set_visible(False)

        plt.tight_layout()
        return axes


# Consolidated API aliases to indicate unified module ownership.
ComplexBuilding = Building
ComplexBuildingData = BuildingData


def _variator_simulate_one_job(
    payload: tuple[ContextData, BuildingData, str, int, float, int],
) -> tuple[tuple[str, int, float], tuple[float, float, float, float, float]]:
    """Run a single Variator case in a worker process (must stay top-level for pickling).

    Returns ``((parameter_name, instance, parameter_value), (heat, cool, total, avginf5, avgsup5))``.
    """
    try:
        context_data, reference, parameter_name, instance, parameter_value, floor_index = payload
        modified_building_data = _clone_with_parameter(
            reference, parameter_name, instance, float(parameter_value)
        )
        modified_building = Building(context_data, modified_building_data)
        modified_building.simulate(verbose=False)
        phvac: list[float] = modified_building.dp.series(f"PHVAC:floor{floor_index}#sim")
        phvac_heat_total: float = sum(p if p > 0 else 0.0 for p in phvac)
        phvac_cool_total: float = sum(-p if p < 0 else 0.0 for p in phvac)
        phvac_total: float = phvac_heat_total + phvac_cool_total
        occupancy: list[float] = modified_building.dp.series(f"OCCUPANCY:floor{floor_index}")
        temperatures: list[float] = modified_building.dp.series(f"TZ_OP:floor{floor_index}#sim")
        temperatures_when_occupied: list[float] = []
        for i in range(len(temperatures)):
            if occupancy[i] > 0:
                temperatures_when_occupied.append(temperatures[i])
        temperatures_when_occupied.sort()
        if not temperatures_when_occupied:
            avginf5 = float("nan")
            avgsup5 = float("nan")
        else:
            n = max(1, int(len(temperatures_when_occupied) * 0.05))
            avginf5 = sum(temperatures_when_occupied[0:n]) / n
            avgsup5 = sum(temperatures_when_occupied[len(temperatures_when_occupied) - n :]) / n
        key = (parameter_name, instance, float(parameter_value))
        perf = (phvac_heat_total, phvac_cool_total, phvac_total, avginf5, avgsup5)
        return key, perf
    finally:
        try:
            plt.close("all")
        except Exception:
            pass


def _clone_with_parameter(reference: BuildingData, parameter_name: str, side_index: int, parameter_value: float) -> BuildingData:
    """Return a copy of ``reference`` with one field (or one glazing ratio) changed."""
    if parameter_name == "side_glazing_ratios":
        new_ratios = list(reference.side_glazing_ratios)
        if not (0 <= side_index < len(new_ratios)):
            raise ValueError(f"side_glazing_ratios index {side_index} out of range for {len(new_ratios)} sides")
        new_ratios[side_index] = float(parameter_value)
        return replace(reference, side_glazing_ratios=new_ratios)
    return replace(reference, **{parameter_name: float(parameter_value)})


def variation(
    context_data: ContextData,
    reference_building_data: BuildingData,
    floor_index: int = -1,
    *,
    max_workers: int | None = None,
    progress: bool = False,
    quick: bool = False,
    max_jobs: int | None = None,
) -> dict[tuple[str, int, float], tuple[float, float, float, float, float]]:
    """Sweep selected :class:`BuildingData` parameters and collect simple performance metrics.

    Use ``max_workers`` > 1 to run independent simulations in parallel processes (each case
    pickles :class:`ContextData` + reference :class:`BuildingData`). Set ``max_workers`` to 1
    to force sequential execution (easier debugging). ``None`` uses ``min(os.cpu_count() or 1, 16)``.

    The full grid is large (many annual simulations). For scripts and notebooks, pass
    ``quick=True`` to cap the run at ``max_jobs`` (default 8 when ``quick`` is set and
    ``max_jobs`` is omitted), or set ``max_jobs`` explicitly without ``quick``.
    """

    if floor_index == -1:
        floor_index = reference_building_data.n_floors - 1
    varying_parameter_values: dict[tuple[str, int], list[float]] = {("side_glazing_ratios", i): (
        0, 0.2, 0.4, 0.6, 0.8, 1.0) for i in range(reference_building_data.n_sides)}
    varying_parameter_values[("z_rotation_angle_deg", 0)] = (0, 45, 90, 135, 180, 225, 270, 315)
    varying_parameter_values[("glazing_solar_factor", 0)] = (0, 0.25, 0.5, 0.75, 1.0)
    varying_parameter_values[("normal_heating_setpoint", 0)] = (18, 19, 20, 21, 22)
    varying_parameter_values[("normal_cooling_setpoint", 0)] = (18, 20, 22, 24, 26, 28, 30, 32)
    varying_parameter_values[("low_heating_setpoint", 0)] = (12, 14, 16, 18, 20)
    varying_parameter_values[("regular_air_renewal_rate_vol_per_hour", 0)] = (0, 1, 2, 3, 4, 5, 6)
    varying_parameter_values[("regular_ventilation_heat_recovery_efficiency", 0)] = (0.0, 0.25, 0.5, 0.75, 1.0)

    performances: dict[tuple[str, int, float], tuple[float, float, float, float, float]] = {}

    jobs: list[tuple[ContextData, BuildingData, str, int, float, int]] = []
    for varying_parameter in varying_parameter_values:
        parameter_name, instance = varying_parameter
        for parameter_value in varying_parameter_values[varying_parameter]:
            jobs.append(
                (
                    context_data,
                    reference_building_data,
                    parameter_name,
                    instance,
                    float(parameter_value),
                    floor_index,
                )
            )

    if quick and max_jobs is None:
        max_jobs = 8
    if max_jobs is not None:
        cap = int(max_jobs)
        if cap < 1:
            raise ValueError("max_jobs must be >= 1 when set")
        if len(jobs) > cap:
            warnings.warn(
                f"variation: running {cap} of {len(jobs)} jobs (max_jobs). "
                "Pass max_jobs=None and quick=False for the full grid.",
                RuntimeWarning,
                stacklevel=2,
            )
            jobs = jobs[:cap]

    n_workers: int = min(os.cpu_count() or 1, 16) if max_workers is None else int(max_workers)
    if n_workers <= 1:
        try:
            for job in jobs:
                key, perf = _variator_simulate_one_job(job)
                performances[key] = perf
                if progress:
                    print(".", end="", flush=True)
        except KeyboardInterrupt:
            if progress:
                print()
            warnings.warn(
                f"variation interrupted after {len(performances)} job(s); returning partial results.",
                RuntimeWarning,
                stacklevel=2,
            )
            return performances
    else:
        parallel_ok = True
        interrupted: bool = False
        futures: list[Any] = []
        executor: ProcessPoolExecutor | None = None
        try:
            executor = ProcessPoolExecutor(max_workers=n_workers)
            futures = [executor.submit(_variator_simulate_one_job, job) for job in jobs]
            for fut in as_completed(futures):
                try:
                    key, perf = fut.result()
                except Exception as exc:
                    parallel_ok = False
                    warnings.warn(
                        f"Variator worker failed ({type(exc).__name__}: {exc}); "
                        "falling back to sequential execution for all cases.",
                        RuntimeWarning,
                        stacklevel=2,
                    )
                    break
                performances[key] = perf
                if progress:
                    print(".", end="", flush=True)
        except KeyboardInterrupt:
            interrupted = True
            parallel_ok = False
            warnings.warn(
                f"variation interrupted after {len(performances)} parallel job(s); "
                "cancelling remaining pool work and returning partial results.",
                RuntimeWarning,
                stacklevel=2,
            )
        except Exception as exc:
            parallel_ok = False
            warnings.warn(
                f"Variator parallel pool failed ({type(exc).__name__}: {exc}); "
                "falling back to sequential execution.",
                RuntimeWarning,
                stacklevel=2,
            )
        finally:
            if executor is not None:
                if interrupted:
                    if sys.version_info >= (3, 9):
                        executor.shutdown(wait=False, cancel_futures=True)
                    else:
                        executor.shutdown(wait=False)
                else:
                    pool_incomplete: bool = len(performances) != len(jobs)
                    if sys.version_info >= (3, 9):
                        executor.shutdown(wait=True, cancel_futures=pool_incomplete)
                    else:
                        executor.shutdown(wait=True)
        if interrupted:
            if progress:
                print()
            return performances
        if not parallel_ok or len(performances) != len(jobs):
            performances.clear()
            for job in jobs:
                key, perf = _variator_simulate_one_job(job)
                performances[key] = perf
                if progress:
                    print(".", end="", flush=True)
    if progress:
        print()
    return performances