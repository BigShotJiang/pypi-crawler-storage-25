"""Tests for the swarm reconciliation module.

Reconciliation is read-only: it walks Beads in-progress state and the
worktree filesystem to produce a typed `ReconciliationReport`, never
mutating Beads / git / GitHub. These tests exercise each finding
category against stubs that track every method call so the read-only
invariant is checked, not assumed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import pytest

from turma.swarm.reconciliation import (
    CompletionPending,
    CompletionPendingWithPr,
    FailurePending,
    MissingWorktree,
    OrphanBranch,
    ReconciliationReport,
    StaleNoSentinels,
    reconcile_feature,
)
from turma.transcription.beads import BeadsTaskRef


# ---------------------------------------------------------------------
# Stubs — track every call so the read-only invariant is checkable.
# ---------------------------------------------------------------------


@dataclass
class StubBeadsAdapter:
    in_progress: tuple[BeadsTaskRef, ...] = ()
    calls: list[tuple] = field(default_factory=list)

    def list_in_progress_tasks(
        self, feature: str
    ) -> tuple[BeadsTaskRef, ...]:
        self.calls.append(("list_in_progress_tasks", feature))
        return self.in_progress

    # Mutation surfaces — never called by reconciliation.
    def claim_task(self, task_id: str) -> None:
        self.calls.append(("claim_task", task_id))

    def close_task(self, task_id: str) -> None:
        self.calls.append(("close_task", task_id))

    def fail_task(self, *args, **kwargs) -> None:
        self.calls.append(("fail_task", args, kwargs))

    def retries_so_far(self, task_id: str) -> int:
        self.calls.append(("retries_so_far", task_id))
        return 0


@dataclass
class StubWorktreeManager:
    repo_root: Path
    task_branches: tuple[str, ...] = ()
    calls: list[tuple] = field(default_factory=list)

    def worktree_path_for(self, feature: str, task_id: str) -> Path:
        self.calls.append(("worktree_path_for", feature, task_id))
        return self.repo_root / ".worktrees" / feature / task_id

    def branch_name_for(self, feature: str, task_id: str) -> str:
        self.calls.append(("branch_name_for", feature, task_id))
        return f"task/{feature}/{task_id}"

    def list_task_branches(self, feature: str) -> tuple[str, ...]:
        self.calls.append(("list_task_branches", feature))
        return self.task_branches

    # Mutation surfaces — never called by reconciliation.
    def setup(self, **kwargs):
        self.calls.append(("setup", kwargs))

    def cleanup(self, *args, **kwargs):
        self.calls.append(("cleanup", args, kwargs))


@dataclass
class StubGitAdapter:
    calls: list[tuple] = field(default_factory=list)

    def status_is_dirty(self, worktree: Path) -> bool:
        self.calls.append(("status_is_dirty", worktree))
        return False

    def commit_all(self, worktree: Path, message: str) -> str:
        self.calls.append(("commit_all", worktree, message))
        return ""

    def push_branch(self, *args, **kwargs) -> None:
        self.calls.append(("push_branch", args, kwargs))


@dataclass
class StubPullRequestAdapter:
    """Stub PR adapter. `urls_by_branch` maps branch → URL when a PR
    is "open" for that branch; anything absent resolves to None."""

    urls_by_branch: dict[str, str] = field(default_factory=dict)
    calls: list[tuple] = field(default_factory=list)

    def find_open_pr_url_for_branch(self, branch: str) -> str | None:
        self.calls.append(("find_open_pr_url_for_branch", branch))
        return self.urls_by_branch.get(branch)

    # Mutation surface — never called by reconciliation.
    def open_pr(self, *args, **kwargs) -> str:
        self.calls.append(("open_pr", args, kwargs))
        return ""


def _ref(
    task_id: str,
    title: str = "",
    *,
    extra_labels: tuple[str, ...] = (),
) -> BeadsTaskRef:
    return BeadsTaskRef(
        id=task_id,
        title=title,
        labels=("feature:oauth", *extra_labels),
    )


def _make_worktree(
    repo_root: Path, feature: str, task_id: str
) -> Path:
    """Create an empty per-task worktree directory under `repo_root`."""
    path = repo_root / ".worktrees" / feature / task_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def _reconcile(
    tmp_path: Path,
    *,
    in_progress: tuple[BeadsTaskRef, ...] = (),
    task_branches: tuple[str, ...] = (),
    pr_urls: dict[str, str] | None = None,
) -> tuple[
    ReconciliationReport,
    StubBeadsAdapter,
    StubWorktreeManager,
    StubGitAdapter,
    StubPullRequestAdapter,
]:
    bd = StubBeadsAdapter(in_progress=in_progress)
    wt = StubWorktreeManager(repo_root=tmp_path, task_branches=task_branches)
    git = StubGitAdapter()
    pr = StubPullRequestAdapter(urls_by_branch=pr_urls or {})
    report = reconcile_feature(
        "oauth",
        adapter=bd,
        worktree_manager=wt,
        git_adapter=git,
        pr_adapter=pr,
        repo_root=tmp_path,
    )
    return report, bd, wt, git, pr


# ---------------------------------------------------------------------
# Empty / happy path
# ---------------------------------------------------------------------


def test_no_in_progress_tasks_produces_empty_report(tmp_path: Path) -> None:
    report, bd, wt, git, pr = _reconcile(tmp_path)
    assert report.findings == ()
    # Only the read methods were touched on any stub.
    assert bd.calls == [("list_in_progress_tasks", "oauth")]
    assert wt.calls == [("list_task_branches", "oauth")]
    assert git.calls == []


def test_returns_report_dataclass(tmp_path: Path) -> None:
    report, *_ = _reconcile(tmp_path)
    assert isinstance(report, ReconciliationReport)
    assert isinstance(report.findings, tuple)


# ---------------------------------------------------------------------
# missing-worktree
# ---------------------------------------------------------------------


def test_missing_worktree_finding(tmp_path: Path) -> None:
    """bd says in_progress, worktree directory absent."""
    report, bd, wt, git, pr = _reconcile(
        tmp_path, in_progress=(_ref("bd-1"),)
    )
    assert len(report.findings) == 1
    finding = report.findings[0]
    assert isinstance(finding, MissingWorktree)
    assert finding.task_id == "bd-1"
    assert finding.suggested_repair
    # Read-only invariant: no mutation stubs were called.
    assert all(c[0] != "close_task" for c in bd.calls)
    assert all(c[0] != "fail_task" for c in bd.calls)
    assert all(c[0] != "setup" for c in wt.calls)
    assert all(c[0] != "cleanup" for c in wt.calls)
    assert git.calls == []


# ---------------------------------------------------------------------
# completion-pending
# ---------------------------------------------------------------------


def test_completion_pending_finding_on_task_complete_sentinel(
    tmp_path: Path,
) -> None:
    worktree = _make_worktree(tmp_path, "oauth", "bd-2")
    (worktree / ".task_complete").write_text("DONE\n")

    report, bd, wt, git, pr = _reconcile(
        tmp_path, in_progress=(_ref("bd-2"),)
    )
    assert len(report.findings) == 1
    finding = report.findings[0]
    assert isinstance(finding, CompletionPending)
    assert finding.task_id == "bd-2"
    assert finding.suggested_repair
    # Read-only invariant.
    assert all(c[0] != "close_task" for c in bd.calls)
    assert git.calls == []


def test_completion_pending_wins_over_failure_when_both_sentinels_present(
    tmp_path: Path,
) -> None:
    """If both sentinels exist, completion wins (matches worker.py)."""
    worktree = _make_worktree(tmp_path, "oauth", "bd-3")
    (worktree / ".task_complete").write_text("DONE\n")
    (worktree / ".task_failed").write_text("oops\n")

    report, *_ = _reconcile(
        tmp_path, in_progress=(_ref("bd-3"),)
    )
    assert len(report.findings) == 1
    assert isinstance(report.findings[0], CompletionPending)


# ---------------------------------------------------------------------
# failure-pending
# ---------------------------------------------------------------------


def test_failure_pending_finding_surfaces_worker_reason(
    tmp_path: Path,
) -> None:
    worktree = _make_worktree(tmp_path, "oauth", "bd-4")
    (worktree / ".task_failed").write_text(
        "could not resolve import turma.foo\n"
    )

    report, bd, wt, git, pr = _reconcile(
        tmp_path, in_progress=(_ref("bd-4"),)
    )
    assert len(report.findings) == 1
    finding = report.findings[0]
    assert isinstance(finding, FailurePending)
    assert finding.task_id == "bd-4"
    assert "could not resolve import" in finding.reason
    # Read-only: fail_task is the repair phase's job, not reconciliation's.
    assert all(c[0] != "fail_task" for c in bd.calls)


def test_failure_pending_uses_unspecified_when_reason_blank(
    tmp_path: Path,
) -> None:
    worktree = _make_worktree(tmp_path, "oauth", "bd-5")
    (worktree / ".task_failed").write_text("   \n")

    report, *_ = _reconcile(
        tmp_path, in_progress=(_ref("bd-5"),)
    )
    assert len(report.findings) == 1
    finding = report.findings[0]
    assert isinstance(finding, FailurePending)
    assert finding.reason == "unspecified"


# ---------------------------------------------------------------------
# stale-no-sentinels
# ---------------------------------------------------------------------


def test_stale_no_sentinels_when_worktree_present_but_empty(
    tmp_path: Path,
) -> None:
    _make_worktree(tmp_path, "oauth", "bd-6")  # no sentinels written

    report, bd, wt, git, pr = _reconcile(
        tmp_path, in_progress=(_ref("bd-6"),)
    )
    assert len(report.findings) == 1
    finding = report.findings[0]
    assert isinstance(finding, StaleNoSentinels)
    assert finding.task_id == "bd-6"
    # Read-only invariant still holds.
    assert all(c[0] != "close_task" for c in bd.calls)
    assert git.calls == []


# ---------------------------------------------------------------------
# orphan-branch
# ---------------------------------------------------------------------


def test_orphan_branch_finding_when_branch_has_no_in_progress_task(
    tmp_path: Path,
) -> None:
    report, bd, wt, git, pr = _reconcile(
        tmp_path,
        in_progress=(),
        task_branches=("task/oauth/bd-old",),
    )
    assert len(report.findings) == 1
    finding = report.findings[0]
    assert isinstance(finding, OrphanBranch)
    assert finding.branch == "task/oauth/bd-old"
    assert finding.suggested_repair


def test_in_progress_branch_is_not_treated_as_orphan(tmp_path: Path) -> None:
    """A branch matching an in_progress task id must not appear as orphan."""
    _make_worktree(tmp_path, "oauth", "bd-7")  # worktree present
    (tmp_path / ".worktrees" / "oauth" / "bd-7" / ".task_complete").write_text(
        "DONE\n"
    )

    report, *_ = _reconcile(
        tmp_path,
        in_progress=(_ref("bd-7"),),
        task_branches=("task/oauth/bd-7",),
    )
    assert len(report.findings) == 1
    assert isinstance(report.findings[0], CompletionPending)
    # No orphan alongside.
    assert not any(
        isinstance(f, OrphanBranch) for f in report.findings
    )


# ---------------------------------------------------------------------
# Composite scenarios
# ---------------------------------------------------------------------


def test_multiple_findings_preserve_in_progress_order(tmp_path: Path) -> None:
    """Findings over in_progress tasks are returned in iteration order,
    with orphan branches appended afterward."""
    worktree_b = _make_worktree(tmp_path, "oauth", "bd-b")
    (worktree_b / ".task_complete").write_text("DONE\n")
    worktree_c = _make_worktree(tmp_path, "oauth", "bd-c")
    (worktree_c / ".task_failed").write_text("blocker\n")

    report, *_ = _reconcile(
        tmp_path,
        in_progress=(_ref("bd-a"), _ref("bd-b"), _ref("bd-c")),
        task_branches=(
            "task/oauth/bd-a",  # will be skipped (matches in_progress task)
            "task/oauth/bd-b",  # skipped
            "task/oauth/bd-c",  # skipped
            "task/oauth/bd-orphan",  # orphan
        ),
    )
    kinds = [type(f).__name__ for f in report.findings]
    assert kinds == [
        "MissingWorktree",    # bd-a (no dir)
        "CompletionPending",  # bd-b
        "FailurePending",     # bd-c
        "OrphanBranch",       # bd-orphan
    ]


# ---------------------------------------------------------------------
# Read-only invariant (explicit, end-to-end)
# ---------------------------------------------------------------------


def test_reconciliation_never_calls_any_mutation_surface(
    tmp_path: Path,
) -> None:
    """Cover every finding category at once and assert zero mutations."""
    _make_worktree(tmp_path, "oauth", "bd-complete")
    (tmp_path / ".worktrees" / "oauth" / "bd-complete" / ".task_complete").write_text("DONE\n")
    _make_worktree(tmp_path, "oauth", "bd-fail")
    (tmp_path / ".worktrees" / "oauth" / "bd-fail" / ".task_failed").write_text("why\n")
    _make_worktree(tmp_path, "oauth", "bd-stale")  # no sentinels

    _, bd, wt, git, pr = _reconcile(
        tmp_path,
        in_progress=(
            _ref("bd-missing"),    # no worktree dir
            _ref("bd-complete"),
            _ref("bd-fail"),
            _ref("bd-stale"),
        ),
        task_branches=("task/oauth/bd-orphan",),
    )
    mutating_bd_methods = {
        "claim_task", "close_task", "fail_task",
        "mark_pr_open", "unmark_pr_open",
    }
    assert not any(c[0] in mutating_bd_methods for c in bd.calls)
    mutating_wt_methods = {"setup", "cleanup"}
    assert not any(c[0] in mutating_wt_methods for c in wt.calls)
    mutating_git_methods = {"commit_all", "push_branch"}
    assert not any(c[0] in mutating_git_methods for c in git.calls)
    mutating_pr_methods = {"open_pr"}
    assert not any(c[0] in mutating_pr_methods for c in pr.calls)


# ---------------------------------------------------------------------
# completion-pending-with-pr
# ---------------------------------------------------------------------


def test_completion_pending_with_pr_emitted_when_open_pr_exists(
    tmp_path: Path,
) -> None:
    """`.task_complete` + open PR for the task branch → CompletionPendingWithPr."""
    worktree = _make_worktree(tmp_path, "oauth", "bd-pr")
    (worktree / ".task_complete").write_text("DONE\n")

    report, bd, wt, git, pr = _reconcile(
        tmp_path,
        in_progress=(_ref("bd-pr"),),
        pr_urls={
            "task/oauth/bd-pr": "https://github.com/turma-dev/turma/pull/42"
        },
    )
    assert len(report.findings) == 1
    finding = report.findings[0]
    assert isinstance(finding, CompletionPendingWithPr)
    assert finding.task_id == "bd-pr"
    assert finding.pr_url == "https://github.com/turma-dev/turma/pull/42"
    assert finding.suggested_repair
    # PR lookup happened exactly once, for the completed task's branch.
    assert pr.calls == [
        ("find_open_pr_url_for_branch", "task/oauth/bd-pr")
    ]


def test_completion_pending_emitted_when_no_open_pr(
    tmp_path: Path,
) -> None:
    """`.task_complete` + no open PR → plain CompletionPending."""
    worktree = _make_worktree(tmp_path, "oauth", "bd-solo")
    (worktree / ".task_complete").write_text("DONE\n")

    report, bd, wt, git, pr = _reconcile(
        tmp_path,
        in_progress=(_ref("bd-solo"),),
        pr_urls={},  # no PR for any branch
    )
    assert len(report.findings) == 1
    assert isinstance(report.findings[0], CompletionPending)
    # Lookup still happened — that's how we learn "no PR".
    assert pr.calls == [
        ("find_open_pr_url_for_branch", "task/oauth/bd-solo")
    ]


def test_pr_lookup_only_runs_for_completed_tasks(tmp_path: Path) -> None:
    """fail / stale / missing-worktree tasks must not trigger a PR query."""
    _make_worktree(tmp_path, "oauth", "bd-fail")
    (tmp_path / ".worktrees" / "oauth" / "bd-fail" / ".task_failed").write_text("x")
    _make_worktree(tmp_path, "oauth", "bd-stale")

    _, _, _, _, pr = _reconcile(
        tmp_path,
        in_progress=(
            _ref("bd-missing"),
            _ref("bd-fail"),
            _ref("bd-stale"),
        ),
    )
    # No PR lookups happened — none of those are completion-pending.
    assert pr.calls == []


def test_completion_pending_with_pr_is_importable() -> None:
    """The dataclass is exported from the module and constructible."""
    finding = CompletionPendingWithPr(
        task_id="bd-pr",
        pr_url="https://github.com/example/repo/pull/1",
    )
    assert finding.pr_url.endswith("/1")
    assert finding.suggested_repair  # has a default


# ---------------------------------------------------------------------
# Stdout summary
# ---------------------------------------------------------------------


def test_summary_prints_count_when_no_findings(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _reconcile(tmp_path)
    captured = capsys.readouterr()
    assert "reconcile:" in captured.out
    assert "0 in-progress" in captured.out


def test_summary_prints_findings_breakdown(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    worktree = _make_worktree(tmp_path, "oauth", "bd-done")
    (worktree / ".task_complete").write_text("DONE\n")

    _reconcile(
        tmp_path,
        in_progress=(_ref("bd-done"),),
        task_branches=("task/oauth/bd-orphan",),
    )
    captured = capsys.readouterr()
    # One line per finding category or a rolled-up summary; in either
    # case the task id + branch should appear somewhere.
    assert "bd-done" in captured.out
    assert "bd-orphan" in captured.out or "orphan" in captured.out


# ---------------------------------------------------------------------
# Merge-tracked skip (swarm-merge-advancement-stabilization Task 1)
# ---------------------------------------------------------------------


def test_merge_tracked_task_is_skipped_from_findings(
    tmp_path: Path,
) -> None:
    """An in_progress task carrying `turma-pr:<N>` is owned by the
    merge-advancement sweep, not reconciliation. It must not appear
    in any finding list — even if its worktree state would otherwise
    classify it (e.g. .task_complete present)."""
    worktree = _make_worktree(tmp_path, "oauth", "bd-tracked")
    (worktree / ".task_complete").write_text("DONE\n")

    report, *_ = _reconcile(
        tmp_path,
        in_progress=(_ref("bd-tracked", extra_labels=("turma-pr:42",)),),
    )

    # No findings at all — the task is merge-tracked.
    assert report.findings == ()
    # Surfaced via the new informational field instead.
    assert report.merge_tracked == (("bd-tracked", 42),)


def test_merge_tracked_skip_does_not_call_pr_adapter(
    tmp_path: Path,
) -> None:
    """Skipping happens BEFORE the PR-state lookup that would
    otherwise misclassify a merged-PR task as `completion-pending`.
    Pin that the gh call doesn't fire for merge-tracked tasks."""
    worktree = _make_worktree(tmp_path, "oauth", "bd-tracked")
    (worktree / ".task_complete").write_text("DONE\n")

    _, _, _, _, pr = _reconcile(
        tmp_path,
        in_progress=(_ref("bd-tracked", extra_labels=("turma-pr:7",)),),
    )

    assert not any(
        c[0] == "find_open_pr_url_for_branch" for c in pr.calls
    )


def test_merge_tracked_skip_log_line_format(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Exactly one `reconcile: <id> → skipped (merge-tracked at PR
    #<N>)` line per skipped task. Format must match the existing
    `reconcile:   <id> → ...` pattern (two-space indent, arrow,
    description) so operator log filters keep working."""
    _make_worktree(tmp_path, "oauth", "bd-1")
    _make_worktree(tmp_path, "oauth", "bd-2")

    _reconcile(
        tmp_path,
        in_progress=(
            _ref("bd-1", extra_labels=("turma-pr:42",)),
            _ref("bd-2", extra_labels=("turma-pr:7",)),
        ),
    )

    captured = capsys.readouterr()
    assert (
        "reconcile:   bd-1 → skipped (merge-tracked at PR #42)"
        in captured.out
    )
    assert (
        "reconcile:   bd-2 → skipped (merge-tracked at PR #7)"
        in captured.out
    )


def test_mixed_merge_tracked_and_regular_classification(
    tmp_path: Path,
) -> None:
    """A merge-tracked task and a regular in_progress task in the
    same run: skip the labelled one, classify the other normally.
    Critical: the merge-tracked task's branch must still count as a
    claimed branch so the orphan-branch loop doesn't misclassify it."""
    # bd-tracked is merge-tracked; bd-stale has no sentinels.
    _make_worktree(tmp_path, "oauth", "bd-tracked")
    _make_worktree(tmp_path, "oauth", "bd-stale")

    report, *_ = _reconcile(
        tmp_path,
        in_progress=(
            _ref("bd-tracked", extra_labels=("turma-pr:5",)),
            _ref("bd-stale"),
        ),
        task_branches=(
            "task/oauth/bd-tracked",
            "task/oauth/bd-stale",
        ),
    )

    # Only bd-stale is classified.
    assert len(report.findings) == 1
    assert isinstance(report.findings[0], StaleNoSentinels)
    assert report.findings[0].task_id == "bd-stale"
    # bd-tracked surfaces via merge_tracked, NOT findings.
    assert report.merge_tracked == (("bd-tracked", 5),)
    # bd-tracked's branch is NOT classified as orphan, even though
    # the task wasn't classified — it's still a claimed branch.
    assert not any(
        isinstance(f, OrphanBranch) and f.branch == "task/oauth/bd-tracked"
        for f in report.findings
    )


def test_finding_1_regression_merged_pr_not_classified_as_completion_pending(
    tmp_path: Path,
) -> None:
    """**Finding 1 regression**: an in_progress task with
    `.task_complete` AND `turma-pr:<N>` AND no open PR for the
    branch (because the PR was just merged on GitHub) must NOT be
    classified as `completion-pending`. Pre-fix, the missing open
    PR caused `_classify_task` to return `CompletionPending`, which
    the repair phase then "fixed" by opening a duplicate PR.

    With the skip in place, the task is owned by merge-advancement
    and the report contains zero findings for it."""
    worktree = _make_worktree(tmp_path, "oauth", "bd-merged")
    (worktree / ".task_complete").write_text("DONE\n")

    # Critically: the stub PR adapter has no entry for this branch
    # — simulating a merged (not-OPEN) PR that
    # find_open_pr_url_for_branch can't see.
    report, _, _, _, pr = _reconcile(
        tmp_path,
        in_progress=(_ref("bd-merged", extra_labels=("turma-pr:99",)),),
        pr_urls={},  # no open PR for this branch
    )

    # No CompletionPending. No CompletionPendingWithPr either.
    assert not any(
        isinstance(f, (CompletionPending, CompletionPendingWithPr))
        for f in report.findings
    )
    assert report.findings == ()
    assert report.merge_tracked == (("bd-merged", 99),)
    # The defensive check: the gh adapter was NOT consulted, so
    # there's no risk of an "open PR not found" path firing.
    assert not any(
        c[0] == "find_open_pr_url_for_branch" for c in pr.calls
    )


def test_malformed_turma_pr_label_falls_through_to_classification(
    tmp_path: Path,
) -> None:
    """A label like `turma-pr:not-a-number` is corrupt.
    `_extract_pr_number` returns None for it, which means "not
    merge-tracked" — the task falls through to normal classification.
    Mirrors the defensive shape `_extract_pr_number` pins at the
    adapter level."""
    worktree = _make_worktree(tmp_path, "oauth", "bd-corrupt")
    (worktree / ".task_complete").write_text("DONE\n")

    report, *_ = _reconcile(
        tmp_path,
        in_progress=(
            _ref("bd-corrupt", extra_labels=("turma-pr:not-a-number",)),
        ),
    )

    # Falls through: normal completion-pending classification fires.
    assert len(report.findings) == 1
    assert isinstance(report.findings[0], CompletionPending)
    assert report.findings[0].task_id == "bd-corrupt"
    # And it's NOT in merge_tracked.
    assert report.merge_tracked == ()
