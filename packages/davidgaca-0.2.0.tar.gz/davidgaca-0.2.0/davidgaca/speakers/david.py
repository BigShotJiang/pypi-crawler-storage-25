# This is a relative import:
# from ..speaker import Speaker

# This is an absolute import:
from davidgaca.speaker import Speaker

class David(Speaker):
    name = "David Gaca"