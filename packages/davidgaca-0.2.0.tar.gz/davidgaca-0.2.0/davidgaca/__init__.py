from .speaker import Speaker
# from .speakers.david import David
from .speakers import David