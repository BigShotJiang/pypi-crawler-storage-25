from .speakers import David

def main():
   David().print_name()

if __name__ == "__main__":
    main()