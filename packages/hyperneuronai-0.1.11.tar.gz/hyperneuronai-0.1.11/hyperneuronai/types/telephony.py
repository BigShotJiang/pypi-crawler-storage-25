from __future__ import annotations

import re
from typing import Literal, Optional
from pydantic import BaseModel, Field, field_validator


CallState = Literal["queued", "ringing", "in_progress", "completed", "failed", "cancelled"]

_E164_RE = re.compile(r"^\+[1-9]\d{6,14}$")


class OutboundCallRequest(BaseModel):
    """Request model for a one-way outbound call."""

    to: str = Field(..., description="E.164 phone number, e.g. '+919876543210'.")
    text: str = Field(..., min_length=1, max_length=4096, description="Message text to synthesize and deliver.")
    voice: str = Field(default="sanjana")
    language: str = Field(default="en", description="BCP-47 language code or 'auto'.")
    metadata: dict = Field(
        default_factory=dict,
        description="Arbitrary key/value pairs for your own tracking.",
    )

    @field_validator("to")
    @classmethod
    def _validate_e164(cls, v: str) -> str:
        if not _E164_RE.match(v):
            raise ValueError(
                f"Phone number must be in E.164 format (e.g. '+919876543210'), got {v!r}."
            )
        return v


class CallResponse(BaseModel):
    call_uuid: str
    state: CallState
    to: str
    voice: str
    created_at: str


class CallStatus(BaseModel):
    call_uuid: str
    state: CallState
    to: str
    duration_seconds: Optional[float] = None
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
