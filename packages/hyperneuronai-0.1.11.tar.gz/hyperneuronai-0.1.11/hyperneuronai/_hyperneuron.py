from __future__ import annotations

from typing import Optional

import httpx

from hyperneuronai._client import (
    SyncHTTPClient,
    AsyncHTTPClient,
    _DEFAULT_BASE_URL,
    _DEFAULT_TIMEOUT,
)
from hyperneuronai.resources.tts import TTS, AsyncTTS
from hyperneuronai.resources.telephony import Telephony, AsyncTelephony


class HyperNeuron:
    """
    Synchronous HyperNeuron AI client.

    Parameters
    ----------
    api_key:
        Your HyperNeuron API key (starts with ``hn_key_``).
    base_url:
        Server base URL. Defaults to ``https://ai.hyperneuron.in``.
        Override to point at a self-hosted instance.
    timeout:
        Custom ``httpx.Timeout``. Defaults to 10 s connect / 120 s read.
    http_client:
        Bring your own ``httpx.Client`` (useful for proxies, custom SSL, etc.).
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: Optional[httpx.Timeout] = None,
        http_client: Optional[httpx.Client] = None,
        # Telephony endpoint paths — override to match your server routes
        outbound_path: str = "/telephony/outbound",
        call_path: str = "/telephony/call",
        calls_path: str = "/telephony/calls",
    ) -> None:
        if not api_key:
            raise ValueError("api_key must not be empty.")
        self._http = SyncHTTPClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            http_client=http_client,
        )
        self.tts = TTS(self._http)
        self.telephony = Telephony(
            self._http,
            outbound_path=outbound_path,
            call_path=call_path,
            calls_path=calls_path,
        )

    def __repr__(self) -> str:
        return f"HyperNeuron(base_url={self._http._base_url!r}, api_key='***')"

    def health(self) -> dict:
        """Check server health and model loading status."""
        return self._http.get("/health")

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> "HyperNeuron":
        return self

    def __exit__(self, *_) -> None:
        self.close()


class AsyncHyperNeuron:
    """
    Async HyperNeuron AI client.

    Parameters
    ----------
    api_key:
        Your HyperNeuron API key (starts with ``hn_key_``).
    base_url:
        Server base URL. Defaults to ``https://ai.hyperneuron.in``.
    timeout:
        Custom ``httpx.Timeout``.
    http_client:
        Bring your own ``httpx.AsyncClient``.
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: Optional[httpx.Timeout] = None,
        http_client: Optional[httpx.AsyncClient] = None,
        # Telephony endpoint paths — override to match your server routes
        outbound_path: str = "/telephony/outbound",
        call_path: str = "/telephony/call",
        calls_path: str = "/telephony/calls",
    ) -> None:
        if not api_key:
            raise ValueError("api_key must not be empty.")
        self._http = AsyncHTTPClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            http_client=http_client,
        )
        self.tts = AsyncTTS(self._http)
        self.telephony = AsyncTelephony(
            self._http,
            outbound_path=outbound_path,
            call_path=call_path,
            calls_path=calls_path,
        )

    def __repr__(self) -> str:
        return f"AsyncHyperNeuron(base_url={self._http._base_url!r}, api_key='***')"

    async def health(self) -> dict:
        """Check server health and model loading status."""
        return await self._http.get("/health")

    async def aclose(self) -> None:
        """Close the underlying HTTP connection pool."""
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncHyperNeuron":
        return self

    async def __aexit__(self, *_) -> None:
        await self.aclose()
