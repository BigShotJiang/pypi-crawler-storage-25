from __future__ import annotations

import re
from typing import Optional

from hyperneuronai._client import SyncHTTPClient, AsyncHTTPClient
from hyperneuronai.types.telephony import OutboundCallRequest, CallResponse, CallStatus

_UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)

_AGENT_CALL_NOT_IMPLEMENTED = (
    "agent_call() is not yet available in this SDK version. "
    "It will be enabled in an upcoming release."
)


def _validate_call_uuid(call_uuid: str) -> None:
    if not _UUID_RE.match(call_uuid):
        raise ValueError(f"Invalid call_uuid: {call_uuid!r}. Must be a UUID string.")


def _validate_pagination(limit: int, offset: int) -> None:
    if not (1 <= limit <= 100):
        raise ValueError(f"limit must be between 1 and 100, got {limit}.")
    if offset < 0:
        raise ValueError(f"offset must be >= 0, got {offset}.")


# ── Sync ──────────────────────────────────────────────────────────────────────


class Telephony:
    """
    Synchronous telephony resource.

    Enabled
    -------
    ``outbound()`` — one-way call: synthesizes ``text`` via TTS and delivers
    the audio to the recipient. No interaction from the called party.

    Coming soon
    -----------
    ``agent_call()`` — two-way AI voice conversation. Currently raises
    ``NotImplementedError``.

    Usage::

        call = client.telephony.outbound(
            to="+919876543210",
            text="Hi! Your order has been shipped and will arrive tomorrow.",
            voice="sanjana",
        )
        print(call.call_uuid, call.state)

        status = client.telephony.status(call.call_uuid)
        client.telephony.end(call.call_uuid)
    """

    def __init__(
        self,
        http: SyncHTTPClient,
        *,
        outbound_path: str = "/telephony/outbound",
        call_path: str = "/telephony/call",
        calls_path: str = "/telephony/calls",
    ) -> None:
        self._http = http
        self._outbound_path = outbound_path
        self._call_path = call_path
        self._calls_path = calls_path

    def outbound(
        self,
        to: str,
        text: str,
        *,
        voice: str = "sanjana",
        language: str = "en",
        metadata: Optional[dict] = None,
    ) -> CallResponse:
        """
        Initiate a one-way outbound call.

        The TTS model synthesizes ``text`` and plays the audio to the
        recipient. The called party cannot speak back.

        Parameters
        ----------
        to:
            E.164 phone number, e.g. ``"+919876543210"``.
        text:
            Message to synthesize and deliver (1–4096 characters).
        voice:
            TTS voice name, e.g. ``"sanjana"``.
        language:
            BCP-47 language code for synthesis, e.g. ``"en"``, ``"hi"``.
        metadata:
            Arbitrary key/value pairs for your own tracking.
        """
        req = OutboundCallRequest(
            to=to,
            text=text,
            voice=voice,
            language=language,
            metadata=metadata or {},
        )
        data = self._http.post(self._outbound_path, json_body=req.model_dump())
        return CallResponse(**data)

    def agent_call(self) -> None:
        """Two-way AI voice call — not yet implemented."""
        raise NotImplementedError(_AGENT_CALL_NOT_IMPLEMENTED)

    def status(self, call_uuid: str) -> CallStatus:
        """Fetch the current status of a call."""
        _validate_call_uuid(call_uuid)
        data = self._http.get(f"{self._call_path}/{call_uuid}")
        return CallStatus(**data)

    def end(self, call_uuid: str) -> dict:
        """Terminate an active call immediately."""
        _validate_call_uuid(call_uuid)
        return self._http.delete(f"{self._call_path}/{call_uuid}")

    def list_calls(self, limit: int = 20, offset: int = 0) -> list[CallStatus]:
        """List recent calls for this API key."""
        _validate_pagination(limit, offset)
        data = self._http.get(f"{self._calls_path}?limit={limit}&offset={offset}")
        calls = data if isinstance(data, list) else data.get("calls", [])
        return [CallStatus(**c) for c in calls]


# ── Async ─────────────────────────────────────────────────────────────────────


class AsyncTelephony:
    """
    Async telephony resource.

    Usage::

        call = await client.telephony.outbound(
            to="+919876543210",
            text="Hi! Your order has been shipped and will arrive tomorrow.",
            voice="sanjana",
        )

        status = await client.telephony.status(call.call_uuid)
        await client.telephony.end(call.call_uuid)
    """

    def __init__(
        self,
        http: AsyncHTTPClient,
        *,
        outbound_path: str = "/telephony/outbound",
        call_path: str = "/telephony/call",
        calls_path: str = "/telephony/calls",
    ) -> None:
        self._http = http
        self._outbound_path = outbound_path
        self._call_path = call_path
        self._calls_path = calls_path

    async def outbound(
        self,
        to: str,
        text: str,
        *,
        voice: str = "sanjana",
        language: str = "en",
        metadata: Optional[dict] = None,
    ) -> CallResponse:
        """Initiate a one-way outbound call (async)."""
        req = OutboundCallRequest(
            to=to,
            text=text,
            voice=voice,
            language=language,
            metadata=metadata or {},
        )
        data = await self._http.post(self._outbound_path, json_body=req.model_dump())
        return CallResponse(**data)

    async def agent_call(self) -> None:
        """Two-way AI voice call — not yet implemented."""
        raise NotImplementedError(_AGENT_CALL_NOT_IMPLEMENTED)

    async def status(self, call_uuid: str) -> CallStatus:
        """Fetch the current status of a call."""
        _validate_call_uuid(call_uuid)
        data = await self._http.get(f"{self._call_path}/{call_uuid}")
        return CallStatus(**data)

    async def end(self, call_uuid: str) -> dict:
        """Terminate an active call immediately."""
        _validate_call_uuid(call_uuid)
        return await self._http.delete(f"{self._call_path}/{call_uuid}")

    async def list_calls(self, limit: int = 20, offset: int = 0) -> list[CallStatus]:
        """List recent calls for this API key."""
        _validate_pagination(limit, offset)
        data = await self._http.get(f"{self._calls_path}?limit={limit}&offset={offset}")
        calls = data if isinstance(data, list) else data.get("calls", [])
        return [CallStatus(**c) for c in calls]
