"""Airtable integration using Fused-managed OAuth tokens.

No extra dependencies are required -- Airtable's REST API uses a plain
Bearer token over HTTPS.
"""

from __future__ import annotations

from typing import Any

from fused._global_api import get_api
from fused._options import options as OPTIONS
from fused._request import raise_for_status, session_with_retries

AIRTABLE_API_BASE = "https://api.airtable.com/v0"
AIRTABLE_META_BASE = "https://api.airtable.com/v0/meta"


class FusedAirtableConnection:
    """Airtable integration using Fused-managed OAuth tokens.

    The connection lazily fetches a short-lived OAuth access token from the
    Fused server and uses the Airtable REST API directly.

    Args:
        base_id: Default Airtable base ID (e.g. ``"appXXXXXXXXXXXXXX"``).
            When provided, methods that accept a ``base_id`` parameter will
            fall back to this value.
    """

    def __init__(self, base_id: str | None = None):
        self._base_id = base_id

    def _get_token(self) -> str:
        """Fetch a short-lived access token from the Fused server."""
        api = get_api()
        payload = api._airtable_token()
        return payload["access_token"]

    def _headers(self) -> dict[str, str]:
        token = self._get_token()
        return {"Authorization": f"Bearer {token}"}

    def _resolve_base_id(self, base_id: str | None) -> str:
        bid = base_id or self._base_id
        if not bid:
            raise ValueError(
                "base_id is required. Pass it to the method or set a default "
                "via FusedAirtableConnection(base_id=...)."
            )
        return bid

    # ── Metadata ──────────────────────────────────────────────────────

    def list_bases(self) -> list[dict[str, Any]]:
        """Return the list of bases the token has access to."""
        url = f"{AIRTABLE_META_BASE}/bases"
        with session_with_retries() as session:
            r = session.get(
                url=url,
                headers=self._headers(),
                timeout=OPTIONS.request_timeout,
            )
        raise_for_status(r)
        return r.json().get("bases", [])

    def list_tables(self, base_id: str | None = None) -> list[dict[str, Any]]:
        """Return the tables in a base.

        Args:
            base_id: Airtable base ID. Falls back to the default.
        """
        bid = self._resolve_base_id(base_id)
        url = f"{AIRTABLE_META_BASE}/bases/{bid}/tables"
        with session_with_retries() as session:
            r = session.get(
                url=url,
                headers=self._headers(),
                timeout=OPTIONS.request_timeout,
            )
        raise_for_status(r)
        return r.json().get("tables", [])

    # ── Records ───────────────────────────────────────────────────────

    def list_records(
        self,
        table: str,
        *,
        base_id: str | None = None,
        **params: Any,
    ) -> list[dict[str, Any]]:
        """List records from a table (auto-paginates).

        Args:
            table: Table name or ID.
            base_id: Airtable base ID. Falls back to the default.
            **params: Extra query parameters forwarded to the Airtable
                List Records endpoint (e.g. ``maxRecords``, ``view``,
                ``filterByFormula``).
        """
        bid = self._resolve_base_id(base_id)
        url = f"{AIRTABLE_API_BASE}/{bid}/{table}"
        records: list[dict[str, Any]] = []
        offset: str | None = None

        while True:
            req_params = {**params}
            if offset:
                req_params["offset"] = offset
            with session_with_retries() as session:
                r = session.get(
                    url=url,
                    headers=self._headers(),
                    params=req_params,
                    timeout=OPTIONS.request_timeout,
                )
            raise_for_status(r)
            data = r.json()
            records.extend(data.get("records", []))
            offset = data.get("offset")
            if not offset:
                break

        return records

    def get_record(
        self,
        table: str,
        record_id: str,
        *,
        base_id: str | None = None,
    ) -> dict[str, Any]:
        """Fetch a single record by ID.

        Args:
            table: Table name or ID.
            record_id: Airtable record ID (e.g. ``"recXXXXXXXXXXXXXX"``).
            base_id: Airtable base ID. Falls back to the default.
        """
        bid = self._resolve_base_id(base_id)
        url = f"{AIRTABLE_API_BASE}/{bid}/{table}/{record_id}"
        with session_with_retries() as session:
            r = session.get(
                url=url,
                headers=self._headers(),
                timeout=OPTIONS.request_timeout,
            )
        raise_for_status(r)
        return r.json()

    def create_records(
        self,
        table: str,
        records: list[dict[str, Any]],
        *,
        base_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Create one or more records.

        Args:
            table: Table name or ID.
            records: List of ``{"fields": {...}}`` dicts.
            base_id: Airtable base ID. Falls back to the default.
        """
        bid = self._resolve_base_id(base_id)
        url = f"{AIRTABLE_API_BASE}/{bid}/{table}"
        with session_with_retries() as session:
            r = session.post(
                url=url,
                headers={**self._headers(), "Content-Type": "application/json"},
                json={"records": records},
                timeout=OPTIONS.request_timeout,
            )
        raise_for_status(r)
        return r.json().get("records", [])

    def update_records(
        self,
        table: str,
        records: list[dict[str, Any]],
        *,
        base_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Update one or more records (PATCH -- partial update).

        Args:
            table: Table name or ID.
            records: List of ``{"id": "rec...", "fields": {...}}`` dicts.
            base_id: Airtable base ID. Falls back to the default.
        """
        bid = self._resolve_base_id(base_id)
        url = f"{AIRTABLE_API_BASE}/{bid}/{table}"
        with session_with_retries() as session:
            r = session.patch(
                url=url,
                headers={**self._headers(), "Content-Type": "application/json"},
                json={"records": records},
                timeout=OPTIONS.request_timeout,
            )
        raise_for_status(r)
        return r.json().get("records", [])

    def delete_records(
        self,
        table: str,
        record_ids: list[str],
        *,
        base_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Delete one or more records by ID.

        Args:
            table: Table name or ID.
            record_ids: List of record IDs to delete.
            base_id: Airtable base ID. Falls back to the default.
        """
        bid = self._resolve_base_id(base_id)
        url = f"{AIRTABLE_API_BASE}/{bid}/{table}"
        # Airtable expects repeated ``records[]`` query params for DELETE.
        params = [("records[]", rid) for rid in record_ids]
        with session_with_retries() as session:
            r = session.delete(
                url=url,
                headers=self._headers(),
                params=params,
                timeout=OPTIONS.request_timeout,
            )
        raise_for_status(r)
        return r.json().get("records", [])
