"""Notion integration using Fused-managed OAuth tokens.

No extra dependencies are required -- Notion's REST API uses a plain
Bearer token over HTTPS.

For the full SDK experience, install the optional ``notion-client`` package::

    pip install notion-client
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from fused._global_api import get_api
from fused._options import options as OPTIONS
from fused._request import raise_for_status, session_with_retries

if TYPE_CHECKING:
    from notion_client import Client as NotionClient

NOTION_API_BASE = "https://api.notion.com/v1"
NOTION_API_VERSION = "2026-03-11"


class FusedNotionConnection:
    """Notion integration using Fused-managed OAuth tokens.

    The connection lazily fetches a short-lived OAuth access token from the
    Fused server and uses the Notion REST API directly.
    """

    def _get_token(self) -> str:
        """Fetch a short-lived access token from the Fused server."""
        api = get_api()
        payload = api._notion_token()
        return payload["access_token"]

    def client(self) -> NotionClient:
        """Return a configured ``notion_client.Client`` using the Fused-managed OAuth token.

        Requires the ``notion-client`` package::

            pip install notion-client
        """
        try:
            from notion_client import Client
        except ImportError:
            raise ImportError(
                "notion-client is required for the SDK client. "
                "Install it with: pip install notion-client"
            ) from None
        return Client(auth=self._get_token())

    def _headers(self) -> dict[str, str]:
        token = self._get_token()
        return {
            "Authorization": f"Bearer {token}",
            "Notion-Version": NOTION_API_VERSION,
            "Content-Type": "application/json",
        }

    # ── Pages ──────────────────────────────────────────────────────

    def get_page(self, page_id: str) -> dict[str, Any]:
        """Retrieve a page by ID.

        Args:
            page_id: Notion page ID.
        """
        url = f"{NOTION_API_BASE}/pages/{page_id}"
        with session_with_retries() as session:
            r = session.get(
                url=url,
                headers=self._headers(),
                timeout=OPTIONS.request_timeout,
            )
        raise_for_status(r)
        return r.json()

    def create_page(
        self,
        parent: dict[str, Any],
        properties: dict[str, Any],
        *,
        children: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Create a new page.

        Args:
            parent: Parent object, e.g. ``{"page_id": "..."}`` or
                ``{"database_id": "..."}``.
            properties: Page properties matching the parent schema.
            children: Optional list of block objects for the page body.
        """
        url = f"{NOTION_API_BASE}/pages"
        body: dict[str, Any] = {"parent": parent, "properties": properties}
        if children is not None:
            body["children"] = children
        with session_with_retries() as session:
            r = session.post(
                url=url,
                headers=self._headers(),
                json=body,
                timeout=OPTIONS.request_timeout,
            )
        raise_for_status(r)
        return r.json()

    def update_page(
        self,
        page_id: str,
        *,
        properties: dict[str, Any] | None = None,
        in_trash: bool | None = None,
    ) -> dict[str, Any]:
        """Update a page's properties or trash/restore it.

        Args:
            page_id: Notion page ID.
            properties: Property values to update.
            in_trash: Set ``True`` to move to trash, ``False`` to restore.
        """
        url = f"{NOTION_API_BASE}/pages/{page_id}"
        body: dict[str, Any] = {}
        if properties is not None:
            body["properties"] = properties
        if in_trash is not None:
            body["in_trash"] = in_trash
        with session_with_retries() as session:
            r = session.patch(
                url=url,
                headers=self._headers(),
                json=body,
                timeout=OPTIONS.request_timeout,
            )
        raise_for_status(r)
        return r.json()

    def delete_page(self, page_id: str) -> dict[str, Any]:
        """Move a page to the trash.

        Notion does not support permanent deletion via the API.

        Args:
            page_id: Notion page ID.
        """
        return self.update_page(page_id, in_trash=True)

    # ── Comments ───────────────────────────────────────────────────

    def list_comments(
        self,
        block_id: str,
        *,
        page_size: int = 100,
    ) -> list[dict[str, Any]]:
        """List comments on a block or page (auto-paginates).

        Args:
            block_id: The block or page ID to list comments for.
            page_size: Number of results per request (max 100).
        """
        url = f"{NOTION_API_BASE}/comments"
        comments: list[dict[str, Any]] = []
        start_cursor: str | None = None

        while True:
            params: dict[str, Any] = {
                "block_id": block_id,
                "page_size": page_size,
            }
            if start_cursor:
                params["start_cursor"] = start_cursor
            with session_with_retries() as session:
                r = session.get(
                    url=url,
                    headers=self._headers(),
                    params=params,
                    timeout=OPTIONS.request_timeout,
                )
            raise_for_status(r)
            data = r.json()
            comments.extend(data.get("results", []))
            if not data.get("has_more"):
                break
            start_cursor = data.get("next_cursor")

        return comments

    def create_comment(
        self,
        rich_text: list[dict[str, Any]],
        *,
        parent_id: str | None = None,
        discussion_id: str | None = None,
    ) -> dict[str, Any]:
        """Create a comment on a page or as a reply in a discussion.

        Provide exactly one of ``parent_id`` (top-level comment on a page)
        or ``discussion_id`` (reply to an existing discussion thread).

        Args:
            rich_text: List of rich text objects for the comment body.
            parent_id: Page ID for a new top-level comment.
            discussion_id: Discussion ID to reply to.
        """
        if not parent_id and not discussion_id:
            raise ValueError("Provide either parent_id or discussion_id")
        body: dict[str, Any] = {"rich_text": rich_text}
        if parent_id:
            body["parent"] = {"page_id": parent_id}
        if discussion_id:
            body["discussion_id"] = discussion_id
        url = f"{NOTION_API_BASE}/comments"
        with session_with_retries() as session:
            r = session.post(
                url=url,
                headers=self._headers(),
                json=body,
                timeout=OPTIONS.request_timeout,
            )
        raise_for_status(r)
        return r.json()

    # ── Users ──────────────────────────────────────────────────────

    def list_users(self, *, _page_size: int = 100) -> list[dict[str, Any]]:
        """List all users in the workspace (auto-paginates).

        Args:
            page_size: Number of results per request (max 100).
        """
        url = f"{NOTION_API_BASE}/users"
        users: list[dict[str, Any]] = []
        start_cursor: str | None = None

        while True:
            params: dict[str, Any] = {"page_size": _page_size}
            if start_cursor:
                params["start_cursor"] = start_cursor
            with session_with_retries() as session:
                r = session.get(
                    url=url,
                    headers=self._headers(),
                    params=params,
                    timeout=OPTIONS.request_timeout,
                )
            raise_for_status(r)
            data = r.json()
            users.extend(data.get("results", []))
            if not data.get("has_more"):
                break
            start_cursor = data.get("next_cursor")

        return users

    def get_user(self, user_id: str) -> dict[str, Any]:
        """Retrieve a user by ID.

        Args:
            user_id: Notion user ID.
        """
        url = f"{NOTION_API_BASE}/users/{user_id}"
        with session_with_retries() as session:
            r = session.get(
                url=url,
                headers=self._headers(),
                timeout=OPTIONS.request_timeout,
            )
        raise_for_status(r)
        return r.json()

    # ── Search ─────────────────────────────────────────────────────

    def search(
        self,
        query: str | None = None,
        *,
        filter: dict[str, Any] | None = None,
        sort: dict[str, Any] | None = None,
        _page_size: int = 100,
    ) -> list[dict[str, Any]]:
        """Search pages and databases by title (auto-paginates).

        Args:
            query: Text to search for in page/database titles.
            filter: Optional filter object, e.g.
                ``{"value": "page", "property": "object"}``.
            sort: Optional sort object, e.g.
                ``{"direction": "descending", "timestamp": "last_edited_time"}``.
            _page_size: Number of results per request (max 100).
        """
        url = f"{NOTION_API_BASE}/search"
        results: list[dict[str, Any]] = []
        start_cursor: str | None = None

        while True:
            body: dict[str, Any] = {"page_size": _page_size}
            if query is not None:
                body["query"] = query
            if filter is not None:
                body["filter"] = filter
            if sort is not None:
                body["sort"] = sort
            if start_cursor:
                body["start_cursor"] = start_cursor
            with session_with_retries() as session:
                r = session.post(
                    url=url,
                    headers=self._headers(),
                    json=body,
                    timeout=OPTIONS.request_timeout,
                )
            raise_for_status(r)
            data = r.json()
            results.extend(data.get("results", []))
            if not data.get("has_more"):
                break
            start_cursor = data.get("next_cursor")

        return results
