from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import modal


def ensure_modal_connector() -> None:
    """Raise a helpful error if modal is not installed."""
    try:
        import modal  # noqa: F401
    except ImportError:
        raise ImportError(
            "modal is required for Modal integration. "
            "Install it with: pip install modal"
        ) from None


def modal_connect() -> modal.Client:
    ensure_modal_connector()

    import modal

    from fused._secrets import secrets

    return modal.Client.from_credentials(
        token_id=secrets["MODAL_TOKEN_ID"],
        token_secret=secrets["MODAL_TOKEN_SECRET"],
    )
