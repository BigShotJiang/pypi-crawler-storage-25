"""HubSpot CRM integration using Fused-managed OAuth tokens."""

from __future__ import annotations

from fused._global_api import get_api


def _get_hubspot_token() -> str:
    """Fetch a short-lived HubSpot access token from the Fused server."""
    api = get_api()
    payload = api._hubspot_token()
    return payload["access_token"]


def hubspot_client():
    """Return an official HubSpot SDK client initialized with the Fused-managed token.

    Returns an instance of ``hubspot.HubSpot`` from the ``hubspot-api-client``
    package, pre-authenticated with a short-lived OAuth access token.
    """
    from hubspot import HubSpot

    return HubSpot(access_token=_get_hubspot_token())
