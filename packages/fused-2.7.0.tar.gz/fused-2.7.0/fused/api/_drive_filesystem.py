from __future__ import annotations

import tempfile
from typing import Any, cast

from fsspec.implementations.http import HTTPFileSystem
from fsspec.registry import register_implementation
from fsspec.spec import AbstractBufferedFile, AbstractFileSystem
from fsspec.utils import DEFAULT_BLOCK_SIZE
from typing_extensions import override

from fused._global_api import get_api
from fused._options import options as OPTIONS
from fused._request import raise_for_status, session_with_retries


class DriveFileSystem(AbstractFileSystem):
    """fsspec filesystem for ``gdrive://`` paths using server OAuth and Google media URLs."""

    protocol = "gdrive"

    def __init__(self, client_id: str | None = None, **kwargs: Any):
        super().__init__(**kwargs)
        self._client_id = client_id

    def _full_gdrive_path(self, path: str) -> str:
        stripped = self._strip_protocol(path).lstrip("/")
        if stripped:
            return f"gdrive://{stripped}"
        return "gdrive://"

    def _token_payload(self, path: str) -> dict[str, Any]:
        api = get_api()
        full = api._validate_file_path_schema(self._full_gdrive_path(path))
        request_url = f"{api.base_url}/files/drive/token"
        params: dict[str, str] = {"path": full}
        cid = self._client_id
        if cid is None:
            from fused._auth import AUTHORIZATION

            if AUTHORIZATION.is_configured():
                cid = api._automatic_realtime_client_id()
        if cid:
            params["client_id"] = cid
        with session_with_retries() as session:
            r = session.get(
                request_url,
                params=params,
                headers=api._generate_headers(credentials_needed=False),
                timeout=OPTIONS.request_timeout,
            )
        raise_for_status(r)
        return r.json()

    def ls(
        self, path: str, detail: bool = False, **kwargs: Any
    ) -> list[str] | list[dict[str, Any]]:
        _ = kwargs
        api = get_api()
        full = api._validate_file_path_schema(self._full_gdrive_path(path))
        out = api.list(full, details=detail, client_id=self._client_id)
        if not detail:
            return out
        return [
            {
                "name": d.url,
                "size": d.size or 0,
                "type": "directory" if d.is_directory else "file",
            }
            for d in out
        ]

    @override
    def _open(
        self,
        path: str,
        mode: str = "rb",
        block_size: int | None = None,
        autocommit: bool = True,
        cache_options: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> AbstractBufferedFile:
        """Open a ``gdrive://`` object for reading.

        Behavior:
        - Defaults to seek-capable reads when callers do not pass a block size.
        - If ``block_size > 0``, uses range-capable HTTP reads when available.
        - If ``block_size > 0`` but the server explicitly disables partial/range reads,
          falls back to a temporary local seekable file.

        Notes:
        - This filesystem is read-only; write modes are not supported.
        - Streaming mode is not seekable and may not work for random-access readers.
        """
        if mode != "rb":
            raise NotImplementedError(
                "gdrive:// is read-only via this filesystem; use upload APIs for writes."
            )
        _ = autocommit, cache_options
        payload = self._token_payload(path)
        token = payload["access_token"]
        download_url = payload["download_url"]
        block_size = kwargs.get("block_size", block_size)
        if block_size is None:
            block_size = DEFAULT_BLOCK_SIZE
        if block_size > 0:
            # Google Drive download URLs do not support HTTP range requests, so
            # any random-access reader (openpyxl, pyarrow, zipfile, …) would fail
            # with a ValueError mid-read. Download the whole file up front into a
            # seekable SpooledTemporaryFile instead.
            return cast(
                AbstractBufferedFile,
                self._download_seekable_file(download_url, token),
            )
        http = HTTPFileSystem(
            headers={"Authorization": f"Bearer {token}"},
            block_size=0,
        )
        return cast(AbstractBufferedFile, http.open(download_url, mode=mode))

    def _download_seekable_file(self, download_url: str, token: str) -> Any:
        """Download to a temporary seekable file-like object.

        This fallback is used when random-access reads are requested
        (``block_size > 0``) but the remote endpoint does not support byte ranges.
        """
        # Keep the returned handle seekable for readers like pandas/openpyxl.
        # Small files stay in memory; larger ones spill to an OS temp file.
        out = tempfile.SpooledTemporaryFile(max_size=64 * 2**20, mode="w+b")
        with session_with_retries() as session:
            with session.get(
                download_url,
                headers={"Authorization": f"Bearer {token}"},
                stream=True,
                timeout=OPTIONS.request_timeout,
            ) as r:
                raise_for_status(r)
                for chunk in r.iter_content(chunk_size=2**20):
                    if chunk:
                        out.write(chunk)
        out.seek(0)
        return out


register_implementation("gdrive", DriveFileSystem, clobber=True)
