"""Snowflake integration using Fused-managed OAuth tokens.

Requires the optional ``snowflake`` extras group::

    pip install fused[snowflake]
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from fused._global_api import get_api

if TYPE_CHECKING:
    import pandas as pd
    import snowflake.connector


def _ensure_snowflake_connector() -> None:
    """Raise a helpful error if snowflake-connector-python is not installed."""
    try:
        import snowflake.connector  # noqa: F401
    except ImportError:
        raise ImportError(
            "snowflake-connector-python is required for Snowflake integration. "
            "Install it with: pip install fused[snowflake]"
        ) from None


class FusedSnowflakeConnection:
    """Snowflake integration using Fused-managed OAuth tokens.

    The connection lazily fetches a short-lived OAuth access token from the Fused
    server and uses ``snowflake-connector-python`` with ``authenticator='oauth'``
    to talk directly to Snowflake.

    Args:
        role: Snowflake role to USE after connecting.
        warehouse: Snowflake warehouse to USE after connecting.
        database: Default database context.
        schema: Default schema context.
    """

    def __init__(
        self,
        role: str | None = None,
        warehouse: str | None = None,
        database: str | None = None,
        schema: str | None = None,
    ):
        _ensure_snowflake_connector()
        self._role = role
        self._warehouse = warehouse
        self._database = database
        self._schema = schema

    def _get_token(self) -> tuple[str, str]:
        """Fetch ``(access_token, account_identifier)`` from the Fused server."""
        api = get_api()
        payload = api._snowflake_token()
        return payload["access_token"], payload["account_identifier"]

    def connect(self, **kwargs: Any) -> snowflake.connector.SnowflakeConnection:
        """Create a Snowflake connection using OAuth token."""
        import snowflake.connector as sf

        token, account = self._get_token()

        # snowflake-connector-python expects the account without the
        # ``.snowflakecomputing.com`` suffix.
        account_clean = account.replace(".snowflakecomputing.com", "")

        conn = sf.connect(
            account=account_clean,
            token=token,
            authenticator="oauth",
            database=self._database,
            schema=self._schema,
            warehouse=self._warehouse,
            **kwargs,
        )

        if self._role:
            conn.cursor().execute(f"USE ROLE {self._role}")
        if self._warehouse:
            conn.cursor().execute(f"USE WAREHOUSE {self._warehouse}")

        return conn

    # ── Query helpers ────────────────────────────────────────────────

    def query(self, sql: str, *args, **kwargs) -> pd.DataFrame:
        """Execute SQL and return results as a DataFrame."""
        import pandas as pd
        from snowflake.connector.errors import NotSupportedError

        conn = self.connect()
        try:
            cur = conn.cursor()
            cur.execute(sql, *args, **kwargs)
            try:
                return cur.fetch_pandas_all()
            except NotSupportedError:
                # SHOW / DDL commands return JSON-format results which
                # fetch_pandas_all() cannot handle.  Fall back to fetchall().
                rows = cur.fetchall()
                columns = (
                    [desc[0] for desc in cur.description] if cur.description else []
                )
                return pd.DataFrame(rows, columns=columns)
        finally:
            conn.close()

    def execute(self, sql: str, *args, **kwargs):
        """Execute SQL without returning results (DDL, DML)."""
        conn = self.connect()
        try:
            return conn.cursor().execute(sql, *args, **kwargs)
        finally:
            conn.close()

    # ── Metadata browsing ────────────────────────────────────────────

    def list_databases(self) -> list[str]:
        """Return a list of database names (``SHOW DATABASES``)."""
        df = self.query("SHOW DATABASES")
        return df["name"].tolist() if "name" in df.columns else []

    def list_schemas(self, database: str | None = None) -> list[str]:
        """Return schema names. Optionally scoped to *database*.

        Note: database is not escaped."""
        sql = f"SHOW SCHEMAS IN DATABASE {database}" if database else "SHOW SCHEMAS"
        df = self.query(sql)
        return df["name"].tolist() if "name" in df.columns else []

    def list_tables(
        self, database: str | None = None, schema: str | None = None
    ) -> list[str]:
        """Return table names. Optionally scoped to *database*/*schema*.

        Note: database and schema are not escaped."""
        if database and schema:
            sql = f"SHOW TABLES IN SCHEMA {database}.{schema}"
        elif database:
            sql = f"SHOW TABLES IN DATABASE {database}"
        elif schema:
            sql = f"SHOW TABLES IN SCHEMA {schema}"
        else:
            sql = "SHOW TABLES"
        df = self.query(sql)
        return df["name"].tolist() if "name" in df.columns else []

    def list_stages(
        self, database: str | None = None, schema: str | None = None
    ) -> list[str]:
        """Return stage names. Optionally scoped to *database*/*schema*.

        Note: database and schema are not escaped."""
        if database and schema:
            sql = f"SHOW STAGES IN SCHEMA {database}.{schema}"
        elif database:
            sql = f"SHOW STAGES IN DATABASE {database}"
        elif schema:
            sql = f"SHOW STAGES IN SCHEMA {schema}"
        else:
            sql = "SHOW STAGES"
        df = self.query(sql)
        return df["name"].tolist() if "name" in df.columns else []

    # ── Stage file operations ────────────────────────────────────────

    def list_stage_files(self, stage: str, pattern: str | None = None) -> list[str]:
        """List files in a stage (``LIST @stage``).

        Args:
            stage: Stage reference, e.g. ``"@my_stage"`` or ``"@db.schema.stage"``.
            pattern: Optional SQL LIKE pattern to filter files.

        Note: stage and pattern are not escaped.
        """
        if not stage.startswith("@"):
            stage = f"@{stage}"
        sql = f"LIST {stage}"
        if pattern:
            sql += f" PATTERN = '{pattern}'"
        df = self.query(sql)
        return df["name"].tolist() if "name" in df.columns else []

    def read_stage(self, stage_path: str) -> pd.DataFrame:
        """Read a file from a stage into a DataFrame.

        Uses ``SELECT $1, $2, ... FROM @stage/path`` which works for
        CSV / semi-structured data that Snowflake can auto-detect.

        Args:
            stage_path: Full stage path, e.g. ``"@my_stage/data.csv"``.

        Note: stage_path is not escaped.
        """
        if not stage_path.startswith("@"):
            stage_path = f"@{stage_path}"
        return self.query(f"SELECT * FROM {stage_path}")

    # ── Write ────────────────────────────────────────────────────────

    def write(
        self,
        df: pd.DataFrame,
        table: str,
        mode: str = "append",
        **kwargs: Any,
    ):
        """Write a DataFrame to a Snowflake table using ``write_pandas``.

        Args:
            df: DataFrame to write.
            table: Fully-qualified or simple table name.
            mode: ``"append"`` (default) or ``"overwrite"``.
            **kwargs: Extra keyword arguments forwarded to
                ``snowflake.connector.pandas_tools.write_pandas``.
        """
        from snowflake.connector.pandas_tools import write_pandas

        conn = self.connect()
        try:
            parts = table.rsplit(".", maxsplit=2)
            tbl = parts[-1]
            db = parts[0] if len(parts) == 3 else self._database
            sch = parts[1] if len(parts) >= 2 else self._schema

            overwrite = mode == "overwrite"
            return write_pandas(
                conn,
                df,
                table_name=tbl,
                database=db,
                schema=sch,
                overwrite=overwrite,
                **kwargs,
            )
        finally:
            conn.close()
