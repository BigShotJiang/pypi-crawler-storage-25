from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional, TypeVar

if TYPE_CHECKING:
    import geopandas as gpd
    import mercantile
    import shapely

Tile = TypeVar("Tile", bound="gpd.GeoDataFrame")
Bounds = TypeVar("Bounds", bound=list)
TileXYZ = TypeVar("TileXYZ", bound="mercantile.Tile")
TileGDF = TypeVar("TileGDF", bound="gpd.GeoDataFrame")
ViewportGDF = TypeVar("ViewportGDF", bound="gpd.GeoDataFrame")
Bbox = TypeVar("Bbox", bound="shapely.geometry.polygon.Polygon")


class UdfRuntimeError(RuntimeError):
    def __init__(self, *args, child_exception_class: Optional[str] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.child_exception_class = child_exception_class


class UdfSerializationError(Exception):
    pass


class UdfTimeoutError(RuntimeError):
    pass


class JobPoolTailTimeoutError(TimeoutError):
    """Raised when a :class:`~fused._submit.JobPool` ``tail()`` exceeds its time limit.

    The pool is stopped. Use :attr:`not_succeeded_args` to resubmit work that did not finish.
    """

    def __init__(
        self,
        message: str,
        *,
        timeout: float,
        not_succeeded_args: list[Any],
    ) -> None:
        super().__init__(message)
        self.timeout = timeout
        self.not_succeeded_args = not_succeeded_args


class UdfSelfRecursionError(Exception):
    """Raised when attempting to submit the same UDF that is currently running."""

    pass
