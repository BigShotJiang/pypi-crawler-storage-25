# workhub-bot-sdk

Workhub 협업 플랫폼용 Python Bot SDK

## 설치

```bash
pip install workhub-bot-sdk
```

## 빠른 시작

```python
from workhub_bot_sdk import WorkhubBot

bot = WorkhubBot(
    base_url="https://your-workhub.com",
    api_key="whb_xxxxxxxx_live_xxxxxxxxxxxxxxxx",
)

# 메시지 보내기
bot.send_message(channel_id="...", content="안녕하세요!")

# 태스크 생성
bot.create_task(topic_id="...", title="새 태스크", priority="high")

# 검색
result = bot.search("배포", type="tasks")
print(f"{result.total}건 검색됨")
```

## 웹훅 이벤트 수신

```python
from workhub_bot_sdk import WorkhubBot, WebhookServer

bot = WorkhubBot(base_url="http://localhost:8080", api_key="whb_xxx")
webhook = WebhookServer(port=9000, secret="your-secret")

@webhook.on("message.created")
def on_message(event):
    bot.send_message(channel_id=event.data["channel_id"], content="수신 확인!")

webhook.start()
```

## API

| 메서드 | 설명 |
|--------|------|
| `send_message()` | 메시지 발송 |
| `read_messages()` | 메시지 읽기 |
| `list_channels()` | 채널/프로젝트/토픽 목록 |
| `create_task()` | 태스크 생성 |
| `update_task()` | 태스크 수정 |
| `list_tasks()` | 태스크 목록 |
| `search()` | 통합 검색 |
| `get_user()` | 사용자 정보 |
| `list_users()` | 사용자 목록 |
| `upload_file()` | 파일 업로드 |
| `download_file()` | 파일 다운로드 |
| `authenticate()` | API key 인증 확인 |

## 라이선스

MIT
