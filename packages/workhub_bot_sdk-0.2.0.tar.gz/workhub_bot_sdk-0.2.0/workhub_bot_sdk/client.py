"""Main Workhub Bot client using MCP JSON-RPC 2.0 protocol."""

from __future__ import annotations

import json
import uuid
from typing import Any, Optional
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from .types import (
    BotCommand,
    BotInfo,
    BotSchedule,
    Bookmark,
    BookmarkMessage,
    ChannelFile,
    ChannelFileListResponse,
    ChannelMemberInfo,
    CommandDef,
    DMRoom,
    DMRoomMember,
    ExecuteCommandResult,
    HashtagPreview,
    HashtagTarget,
    InteractiveMessageResult,
    MentionTarget,
    MessageActionResponse,
    SearchResult,
)


class WorkhubBotError(Exception):
    """Error from Workhub API."""

    def __init__(self, code: int, message: str):
        self.code = code
        super().__init__(f"[{code}] {message}")


class WorkhubBot:
    """Workhub Bot SDK client.

    Communicates with the Workhub platform via MCP (JSON-RPC 2.0) protocol.

    Usage:
        bot = WorkhubBot(
            base_url="https://your-workhub.com",
            api_key="whb_xxxxxxxx_live_xxxxxxxxxxxxxxxx",
        )

        # Send a message
        bot.send_message(channel_id="...", content="Hello from bot!")

        # Read messages
        messages = bot.read_messages(channel_id="...", limit=10)

        # Create a task
        bot.create_task(topic_id="...", title="New task", priority="high")
    """

    def __init__(self, base_url: str, api_key: str, timeout: int = 30):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self._mcp_url = f"{self.base_url}/api/mcp"
        self._api_url = f"{self.base_url}/api"

    # ── MCP JSON-RPC Transport ───────────────────────────────────

    def _rpc(self, method: str, params: Optional[dict] = None) -> Any:
        """Send a JSON-RPC 2.0 request to the MCP endpoint."""
        payload = {
            "jsonrpc": "2.0",
            "id": str(uuid.uuid4()),
            "method": method,
            "params": params or {},
        }

        data = json.dumps(payload).encode("utf-8")
        req = Request(
            self._mcp_url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )

        try:
            with urlopen(req, timeout=self.timeout) as resp:
                body = json.loads(resp.read().decode("utf-8"))
        except HTTPError as e:
            error_body = e.read().decode("utf-8", errors="replace")
            raise WorkhubBotError(e.code, error_body) from e

        if "error" in body and body["error"]:
            err = body["error"]
            raise WorkhubBotError(err.get("code", -1), err.get("message", "Unknown"))

        return body.get("result")

    def _call_tool(self, name: str, arguments: dict) -> str:
        """Call an MCP tool and return the text content."""
        result = self._rpc("tools/call", {"name": name, "arguments": arguments})
        if result and "content" in result:
            texts = [c["text"] for c in result["content"] if c.get("type") == "text"]
            return "\n".join(texts)
        return ""

    # ── Authentication ───────────────────────────────────────────

    def authenticate(self) -> BotInfo:
        """Verify API key and return bot info."""
        req = Request(
            f"{self._api_url}/bots/auth",
            data=b"{}",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )
        with urlopen(req, timeout=self.timeout) as resp:
            body = json.loads(resp.read().decode("utf-8"))

        data = body.get("data", body)
        return BotInfo(
            bot_id=data.get("bot_id", ""),
            org_id=data.get("org_id", ""),
            scopes=data.get("scopes", []),
        )

    # ── MCP Tools ────────────────────────────────────────────────

    def initialize(self) -> dict:
        """Initialize MCP session. Returns server capabilities."""
        return self._rpc("initialize", {
            "protocolVersion": "2025-03-26",
            "capabilities": {},
            "clientInfo": {"name": "workhub-bot-sdk-python", "version": "0.1.0"},
        })

    def list_tools(self) -> list[dict]:
        """List available MCP tools."""
        result = self._rpc("tools/list")
        return result.get("tools", []) if result else []

    def ping(self) -> bool:
        """Ping the MCP server."""
        try:
            self._rpc("ping")
            return True
        except Exception:
            return False

    # ── Messages ─────────────────────────────────────────────────

    def send_message(
        self,
        content: str,
        *,
        channel_id: Optional[str] = None,
        topic_id: Optional[str] = None,
        dm_room_id: Optional[str] = None,
    ) -> str:
        """Send a message to a channel, topic, or DM room.

        Returns the message ID.
        """
        args: dict[str, Any] = {"content": content}
        if channel_id:
            args["channel_id"] = channel_id
        if topic_id:
            args["topic_id"] = topic_id
        if dm_room_id:
            args["dm_room_id"] = dm_room_id
        return self._call_tool("send_message", args)

    def read_messages(
        self,
        *,
        channel_id: Optional[str] = None,
        topic_id: Optional[str] = None,
        dm_room_id: Optional[str] = None,
        limit: int = 20,
    ) -> str:
        """Read recent messages. Returns formatted text."""
        args: dict[str, Any] = {"limit": min(limit, 100)}
        if channel_id:
            args["channel_id"] = channel_id
        if topic_id:
            args["topic_id"] = topic_id
        if dm_room_id:
            args["dm_room_id"] = dm_room_id
        return self._call_tool("read_messages", args)

    # ── Channels ─────────────────────────────────────────────────

    def list_channels(
        self,
        *,
        type: str = "all",
        project_id: Optional[str] = None,
    ) -> str:
        """List channels, projects, and/or topics. Returns formatted text."""
        args: dict[str, Any] = {"type": type}
        if project_id:
            args["project_id"] = project_id
        return self._call_tool("list_channels", args)

    # ── Tasks ────────────────────────────────────────────────────

    def create_task(
        self,
        topic_id: str,
        title: str,
        *,
        description: Optional[str] = None,
        priority: str = "medium",
        assignee_id: Optional[str] = None,
        due_date: Optional[str] = None,
    ) -> str:
        """Create a new task. Returns task ID."""
        args: dict[str, Any] = {
            "topic_id": topic_id,
            "title": title,
            "priority": priority,
        }
        if description:
            args["description"] = description
        if assignee_id:
            args["assignee_id"] = assignee_id
        if due_date:
            args["due_date"] = due_date
        return self._call_tool("create_task", args)

    def update_task(
        self,
        task_id: str,
        *,
        status: Optional[str] = None,
        title: Optional[str] = None,
        priority: Optional[str] = None,
        assignee_id: Optional[str] = None,
        due_date: Optional[str] = None,
    ) -> str:
        """Update an existing task."""
        args: dict[str, Any] = {"task_id": task_id}
        if status:
            args["status"] = status
        if title:
            args["title"] = title
        if priority:
            args["priority"] = priority
        if assignee_id:
            args["assignee_id"] = assignee_id
        if due_date:
            args["due_date"] = due_date
        return self._call_tool("update_task", args)

    def list_tasks(
        self,
        topic_id: str,
        *,
        status: str = "all",
        assignee_id: Optional[str] = None,
    ) -> str:
        """List tasks in a topic. Returns formatted text."""
        args: dict[str, Any] = {"topic_id": topic_id, "status": status}
        if assignee_id:
            args["assignee_id"] = assignee_id
        return self._call_tool("list_tasks", args)

    # ── Search ───────────────────────────────────────────────────

    def search(
        self,
        query: str,
        *,
        type: str = "all",
        limit: int = 10,
    ) -> SearchResult:
        """Search messages, users, tasks, channels."""
        text = self._call_tool("search", {
            "query": query,
            "type": type,
            "limit": min(limit, 50),
        })
        # Parse total from "총 N건"
        total = 0
        for line in text.split("\n"):
            if "총 " in line and "건" in line:
                try:
                    total = int(line.split("총 ")[1].split("건")[0])
                except (ValueError, IndexError):
                    pass
        return SearchResult(query=query, total=total, raw_text=text)

    # ── Users ────────────────────────────────────────────────────

    def get_user(
        self,
        *,
        user_id: Optional[str] = None,
        email: Optional[str] = None,
    ) -> str:
        """Get user info by ID or email. Returns formatted text."""
        args: dict[str, Any] = {}
        if user_id:
            args["user_id"] = user_id
        if email:
            args["email"] = email
        return self._call_tool("get_user_info", args)

    def list_users(
        self,
        *,
        department: Optional[str] = None,
        role: Optional[str] = None,
        limit: int = 50,
    ) -> str:
        """List users. Returns formatted text."""
        args: dict[str, Any] = {"limit": min(limit, 200)}
        if department:
            args["department"] = department
        if role:
            args["role"] = role
        return self._call_tool("list_users", args)

    # ── File Upload (REST API) ───────────────────────────────────

    def upload_file(
        self,
        filepath: str,
        *,
        message_id: Optional[str] = None,
        task_id: Optional[str] = None,
    ) -> dict:
        """Upload a file via REST API (not MCP).

        Returns file metadata dict with id, download_url, etc.
        """
        import mimetypes
        from pathlib import Path

        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {filepath}")

        boundary = uuid.uuid4().hex
        content_type = mimetypes.guess_type(filepath)[0] or "application/octet-stream"

        body_parts = []
        # File field
        body_parts.append(f"--{boundary}\r\n".encode())
        body_parts.append(
            f'Content-Disposition: form-data; name="file"; filename="{path.name}"\r\n'.encode()
        )
        body_parts.append(f"Content-Type: {content_type}\r\n\r\n".encode())
        body_parts.append(path.read_bytes())
        body_parts.append(b"\r\n")

        # Optional fields
        for field_name, field_value in [("message_id", message_id), ("task_id", task_id)]:
            if field_value:
                body_parts.append(f"--{boundary}\r\n".encode())
                body_parts.append(
                    f'Content-Disposition: form-data; name="{field_name}"\r\n\r\n'.encode()
                )
                body_parts.append(f"{field_value}\r\n".encode())

        body_parts.append(f"--{boundary}--\r\n".encode())
        body = b"".join(body_parts)

        req = Request(
            f"{self._api_url}/files/upload",
            data=body,
            headers={
                "Content-Type": f"multipart/form-data; boundary={boundary}",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )

        with urlopen(req, timeout=self.timeout) as resp:
            result = json.loads(resp.read().decode("utf-8"))
        return result.get("data", result)

    def download_file(self, file_id: str, dest_path: str) -> str:
        """Download a file by ID to a local path.

        Returns the destination path.
        """
        from pathlib import Path

        req = Request(
            f"{self._api_url}/files/{file_id}/download",
            headers={"Authorization": f"Bearer {self.api_key}"},
        )
        with urlopen(req, timeout=self.timeout) as resp:
            Path(dest_path).write_bytes(resp.read())
        return dest_path

    # ── REST Helper ──────────────────────────────────────────────

    def _rest(self, method: str, path: str, body: Optional[dict] = None) -> Any:
        """Send a REST API request and return parsed JSON data."""
        data = json.dumps(body).encode("utf-8") if body else None
        req = Request(
            f"{self._api_url}{path}",
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method=method,
        )

        try:
            with urlopen(req, timeout=self.timeout) as resp:
                resp_body = resp.read().decode("utf-8")
                if not resp_body:
                    return None
                result = json.loads(resp_body)
                return result.get("data", result)
        except HTTPError as e:
            error_body = e.read().decode("utf-8", errors="replace")
            raise WorkhubBotError(e.code, error_body) from e

    # ── Bot Commands (#48) ───────────────────────────────────────

    def list_bot_commands(self, bot_id: str) -> list[BotCommand]:
        """List custom commands registered for this bot."""
        data = self._rest("GET", f"/bots/{bot_id}/commands") or []
        return [BotCommand(**c) for c in data]

    def create_bot_command(
        self,
        bot_id: str,
        command: str,
        description: str,
        *,
        usage_hint: Optional[str] = None,
    ) -> BotCommand:
        """Register a new custom command for this bot."""
        body: dict[str, Any] = {"command": command, "description": description}
        if usage_hint:
            body["usage_hint"] = usage_hint
        data = self._rest("POST", f"/bots/{bot_id}/commands", body)
        return BotCommand(**data)

    def delete_bot_command(self, bot_id: str, command_name: str) -> None:
        """Delete a custom command."""
        from urllib.parse import quote
        self._rest("DELETE", f"/bots/{bot_id}/commands/{quote(command_name)}")

    # ── Bookmarks (#51) ─────────────────────────────────────────

    def create_bookmark(self, channel_id: str, message_id: str) -> None:
        """Bookmark a message in a channel."""
        self._rest("POST", f"/channels/{channel_id}/bookmarks", {"message_id": message_id})

    def delete_bookmark(self, channel_id: str, message_id: str) -> None:
        """Remove a bookmark."""
        self._rest("DELETE", f"/channels/{channel_id}/bookmarks/{message_id}")

    def list_bookmarks(
        self,
        channel_id: str,
        *,
        user_id: Optional[str] = None,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        sort: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[Bookmark]:
        """List bookmarks in a channel with optional filters."""
        from urllib.parse import urlencode

        params: dict[str, str] = {}
        if user_id:
            params["user_id"] = user_id
        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date
        if sort:
            params["sort"] = sort
        if limit:
            params["limit"] = str(min(limit, 100))
        qs = f"?{urlencode(params)}" if params else ""
        data = self._rest("GET", f"/channels/{channel_id}/bookmarks{qs}") or []
        bookmarks = []
        for item in data:
            msg_data = item.pop("message", None)
            msg = BookmarkMessage(**msg_data) if msg_data else None
            bookmarks.append(Bookmark(**item, message=msg))
        return bookmarks

    # ── Channel Files (#52) ─────────────────────────────────────

    def list_channel_files(
        self,
        channel_id: str,
        *,
        q: Optional[str] = None,
        type: Optional[str] = None,
        sort: Optional[str] = None,
        order: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> ChannelFileListResponse:
        """List files in a channel with search, filter, and sort."""
        from urllib.parse import urlencode

        params: dict[str, str] = {}
        if q:
            params["q"] = q
        if type:
            params["type"] = type
        if sort:
            params["sort"] = sort
        if order:
            params["order"] = order
        if limit:
            params["limit"] = str(min(limit, 100))
        if offset is not None:
            params["offset"] = str(offset)
        qs = f"?{urlencode(params)}" if params else ""
        data = self._rest("GET", f"/channels/{channel_id}/files{qs}") or {}
        files = [ChannelFile(**f) for f in data.get("files", [])]
        return ChannelFileListResponse(
            files=files,
            total=data.get("total", 0),
            page=data.get("page", 1),
            per_page=data.get("per_page", 20),
        )

    # ── Mentions (#47) ──────────────────────────────────────────

    def search_mentions(
        self,
        q: str,
        *,
        channel_id: Optional[str] = None,
    ) -> list[MentionTarget]:
        """Search for mention targets (users, departments, @all, @here)."""
        from urllib.parse import urlencode

        params: dict[str, str] = {"q": q}
        if channel_id:
            params["channel_id"] = channel_id
        data = self._rest("GET", f"/mentions/users?{urlencode(params)}") or []
        return [MentionTarget(**t) for t in data]

    # ── Hashtags (#49) ──────────────────────────────────────────

    def search_hashtags(self, q: str) -> list[HashtagTarget]:
        """Search for hashtag targets (channels, tasks, projects, tags)."""
        from urllib.parse import urlencode

        data = self._rest("GET", f"/hashtags/search?{urlencode({'q': q})}") or []
        return [HashtagTarget(**t) for t in data]

    def get_hashtag_preview(self, type: str, id: str) -> HashtagPreview:
        """Get a preview card for a hashtag-linked resource."""
        data = self._rest("GET", f"/hashtags/preview/{type}/{id}")
        return HashtagPreview(**data)

    # ── Slash Commands (#46) ────────────────────────────────────

    def list_slash_commands(self) -> list[CommandDef]:
        """List available slash commands."""
        data = self._rest("GET", "/commands") or []
        return [CommandDef(**c) for c in data]

    def execute_slash_command(
        self,
        text: str,
        *,
        channel_id: Optional[str] = None,
        topic_id: Optional[str] = None,
        dm_room_id: Optional[str] = None,
    ) -> ExecuteCommandResult:
        """Execute a slash command."""
        body: dict[str, Any] = {"text": text}
        if channel_id:
            body["channel_id"] = channel_id
        if topic_id:
            body["topic_id"] = topic_id
        if dm_room_id:
            body["dm_room_id"] = dm_room_id
        data = self._rest("POST", "/commands/execute", body)
        return ExecuteCommandResult(
            text=data.get("text", ""),
            ephemeral=data.get("ephemeral", False),
        )

    # ── DM Room (#62) ──────────────────────────────────────────

    def get_dm_room(self, user_id: str) -> DMRoom:
        """Get or create a DM room by user ID."""
        from urllib.parse import quote

        data = self._rest("GET", f"/dms/by-user?user_id={quote(user_id)}")
        members = None
        if data.get("members"):
            members = [DMRoomMember(**m) for m in data["members"]]
        return DMRoom(
            id=data["id"],
            org_id=data["org_id"],
            is_group=data["is_group"],
            name=data.get("name"),
            members=members,
        )

    # ── Channel Members (#62) ──────────────────────────────────

    def list_channel_members(self, channel_id: str) -> list[ChannelMemberInfo]:
        """List channel members with enhanced user info."""
        data = self._rest("GET", f"/channels/{channel_id}/members") or []
        return [ChannelMemberInfo(**m) for m in data]

    # ── Schedules (#62) ────────────────────────────────────────

    def create_schedule(
        self,
        bot_id: str,
        name: str,
        schedule_type: str,
        *,
        cron_expr: Optional[str] = None,
        run_at: Optional[str] = None,
        timezone: Optional[str] = None,
        payload: Optional[dict] = None,
        max_runs: Optional[int] = None,
    ) -> BotSchedule:
        """Create a new bot schedule."""
        body: dict[str, Any] = {
            "bot_id": bot_id,
            "name": name,
            "schedule_type": schedule_type,
        }
        if cron_expr:
            body["cron_expr"] = cron_expr
        if run_at:
            body["run_at"] = run_at
        if timezone:
            body["timezone"] = timezone
        if payload:
            body["payload"] = payload
        if max_runs is not None:
            body["max_runs"] = max_runs
        data = self._rest("POST", "/schedules", body)
        return BotSchedule(**data)

    def list_schedules(
        self,
        bot_id: str,
        *,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> list[BotSchedule]:
        """List schedules for a bot."""
        from urllib.parse import urlencode

        params: dict[str, str] = {"bot_id": bot_id}
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)
        data = self._rest("GET", f"/schedules?{urlencode(params)}") or []
        return [BotSchedule(**s) for s in data]

    def update_schedule(
        self,
        schedule_id: str,
        *,
        name: Optional[str] = None,
        cron_expr: Optional[str] = None,
        run_at: Optional[str] = None,
        timezone: Optional[str] = None,
        payload: Optional[dict] = None,
        is_active: Optional[bool] = None,
        max_runs: Optional[int] = None,
    ) -> BotSchedule:
        """Update a schedule."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if cron_expr is not None:
            body["cron_expr"] = cron_expr
        if run_at is not None:
            body["run_at"] = run_at
        if timezone is not None:
            body["timezone"] = timezone
        if payload is not None:
            body["payload"] = payload
        if is_active is not None:
            body["is_active"] = is_active
        if max_runs is not None:
            body["max_runs"] = max_runs
        data = self._rest("PUT", f"/schedules/{schedule_id}", body)
        return BotSchedule(**data)

    def delete_schedule(self, schedule_id: str) -> None:
        """Delete a schedule."""
        self._rest("DELETE", f"/schedules/{schedule_id}")

    # ── Interactive Messages (#62) ─────────────────────────────

    def send_interactive_message(
        self,
        bot_id: str,
        content: str,
        action_type: str,
        actions: list[dict],
        *,
        channel_id: Optional[str] = None,
        topic_id: Optional[str] = None,
        dm_room_id: Optional[str] = None,
        expires_at: Optional[str] = None,
    ) -> InteractiveMessageResult:
        """Send an interactive message with actions."""
        body: dict[str, Any] = {
            "bot_id": bot_id,
            "content": content,
            "action_type": action_type,
            "actions": actions,
        }
        if channel_id:
            body["channel_id"] = channel_id
        if topic_id:
            body["topic_id"] = topic_id
        if dm_room_id:
            body["dm_room_id"] = dm_room_id
        if expires_at:
            body["expires_at"] = expires_at
        data = self._rest("POST", "/interactive-messages", body)
        return InteractiveMessageResult(**data)

    def record_action(
        self,
        message_id: str,
        action_id: str,
        *,
        action_value: Optional[str] = None,
    ) -> None:
        """Record a user action on an interactive message."""
        body: dict[str, Any] = {"action_id": action_id}
        if action_value:
            body["action_value"] = action_value
        self._rest("POST", f"/interactive-messages/{message_id}/actions", body)

    def get_message_actions(self, message_id: str) -> list[MessageActionResponse]:
        """Get action responses for an interactive message."""
        data = self._rest("GET", f"/interactive-messages/{message_id}/actions") or []
        return [MessageActionResponse(**a) for a in data]

    # ── Message Reactions / Pin / Thread ─────────────────────────

    def add_reaction(self, message_id: str, emoji: str) -> None:
        """Add a reaction emoji to a message."""
        self._rest("POST", f"/messages/{message_id}/reactions", {"emoji": emoji})

    def remove_reaction(self, message_id: str, emoji: str) -> None:
        """Remove a reaction emoji from a message."""
        from urllib.parse import quote

        self._rest("DELETE", f"/messages/{message_id}/reactions/{quote(emoji)}")

    def get_reactions(self, message_id: str) -> list[dict]:
        """Get all reactions on a message."""
        return self._rest("GET", f"/messages/{message_id}/reactions") or []

    def pin_message(self, message_id: str) -> None:
        """Pin a message."""
        self._rest("POST", f"/messages/{message_id}/pin")

    def unpin_message(self, message_id: str) -> None:
        """Unpin a message."""
        self._rest("POST", f"/messages/{message_id}/unpin")

    def list_thread(self, message_id: str) -> list[dict]:
        """List replies in a thread."""
        return self._rest("GET", f"/messages/{message_id}/thread") or []

    # ── Task (Advanced) ──────────────────────────────────────────

    def update_task_status(self, task_id: str, status: str) -> dict:
        """Update task status (todo/in_progress/review/done)."""
        return self._rest("PUT", f"/tasks/{task_id}/status", {"status": status}) or {}

    def set_task_dependencies(self, task_id: str, depends_on: list[str]) -> dict:
        """Set task dependencies (list of prerequisite task IDs)."""
        return self._rest("PUT", f"/tasks/{task_id}/dependencies", {"depends_on": depends_on}) or {}

    def delete_task(self, task_id: str) -> None:
        """Delete a task."""
        self._rest("DELETE", f"/tasks/{task_id}")

    def add_task_assignee(self, task_id: str, user_id: str) -> None:
        """Add an assignee to a task."""
        self._rest("POST", f"/tasks/{task_id}/assignees", {"user_id": user_id})

    def remove_task_assignee(self, task_id: str, user_id: str) -> None:
        """Remove an assignee from a task."""
        self._rest("DELETE", f"/tasks/{task_id}/assignees/{user_id}")

    # ── Work Logs ─────────────────────────────────────────────────

    def list_work_logs(
        self,
        *,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        task_id: Optional[str] = None,
    ) -> list[dict]:
        """List my work logs within a date range."""
        params: list[str] = []
        if from_date:
            params.append(f"from={from_date}")
        if to_date:
            params.append(f"to={to_date}")
        if task_id:
            params.append(f"task_id={task_id}")
        qs = ("?" + "&".join(params)) if params else ""
        return self._rest("GET", f"/my-tasks/work-logs{qs}") or []

    def create_work_log(
        self,
        task_id: str,
        work_date: str,
        start_time: str,
        end_time: str,
        *,
        memo: Optional[str] = None,
    ) -> dict:
        """Create a work log entry."""
        body: dict[str, Any] = {
            "task_id": task_id,
            "work_date": work_date,
            "start_time": start_time,
            "end_time": end_time,
        }
        if memo:
            body["memo"] = memo
        return self._rest("POST", "/my-tasks/work-logs", body) or {}

    def delete_work_log(self, work_log_id: str) -> None:
        """Delete a work log entry by ID."""
        self._rest("DELETE", f"/my-tasks/work-logs/{work_log_id}")

    # ── Channel Management ──────────────────────────────────────

    def create_channel(
        self,
        name: str,
        *,
        description: Optional[str] = None,
        channel_type: str = "general",
        is_public: bool = True,
    ) -> dict:
        """Create a new channel."""
        body: dict[str, Any] = {
            "name": name,
            "channel_type": channel_type,
            "is_public": is_public,
        }
        if description:
            body["description"] = description
        return self._rest("POST", "/channels", body) or {}

    def update_channel(
        self,
        channel_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        channel_type: Optional[str] = None,
    ) -> dict:
        """Update channel info."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if channel_type is not None:
            body["channel_type"] = channel_type
        return self._rest("PUT", f"/channels/{channel_id}", body) or {}

    def delete_channel(self, channel_id: str) -> None:
        """Delete a channel."""
        self._rest("DELETE", f"/channels/{channel_id}")

    def join_channel(self, channel_id: str) -> None:
        """Join a channel."""
        self._rest("POST", f"/channels/{channel_id}/join")

    def leave_channel(self, channel_id: str) -> None:
        """Leave a channel."""
        self._rest("POST", f"/channels/{channel_id}/leave")

    def add_channel_member(self, channel_id: str, user_id: str) -> None:
        """Add a member to a channel."""
        self._rest("POST", f"/channels/{channel_id}/members", {"user_id": user_id})

    def remove_channel_member(self, channel_id: str, user_id: str) -> None:
        """Remove a member from a channel."""
        self._rest("DELETE", f"/channels/{channel_id}/members/{user_id}")

    # ── DM Operations ───────────────────────────────────────────

    def create_dm_room(self, user_ids: list[str], *, name: Optional[str] = None) -> dict:
        """Create a new DM room (1:1 or group)."""
        body: dict[str, Any] = {"user_ids": user_ids}
        if name:
            body["name"] = name
        return self._rest("POST", "/dms", body) or {}

    def list_dm_rooms(self) -> list[dict]:
        """List all DM rooms the bot is a member of."""
        return self._rest("GET", "/dms") or []

    def send_dm_message(self, room_id: str, content: str) -> dict:
        """Send a message in a DM room."""
        return self._rest("POST", f"/dms/{room_id}/messages", {"content": content}) or {}

    def list_dm_messages(
        self,
        room_id: str,
        *,
        limit: Optional[int] = None,
        before: Optional[str] = None,
    ) -> list[dict]:
        """List messages in a DM room."""
        params: list[str] = []
        if limit:
            params.append(f"limit={limit}")
        if before:
            params.append(f"before={before}")
        qs = ("?" + "&".join(params)) if params else ""
        return self._rest("GET", f"/dms/{room_id}/messages{qs}") or []

    def leave_dm_room(self, room_id: str) -> None:
        """Leave a DM room."""
        self._rest("POST", f"/dms/{room_id}/leave")

    # ── Topic Management ───────────────────────────────────────

    def list_topics(self, project_id: str) -> list[dict]:
        """List topics in a project."""
        return self._rest("GET", f"/projects/{project_id}/topics") or []

    def update_topic_status(self, topic_id: str, status: str) -> dict:
        """Update topic status (active/completed/archived)."""
        return self._rest("PUT", f"/topics/{topic_id}/status", {"status": status}) or {}

    def delete_topic(self, topic_id: str, confirm_name: str) -> None:
        """Delete a topic (with confirmation name)."""
        self._rest("DELETE", f"/topics/{topic_id}", {"confirm_name": confirm_name})

    # ── Project Management ──────────────────────────────────────

    def list_projects(
        self,
        *,
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[dict]:
        """List projects."""
        params: list[str] = []
        if status:
            params.append(f"status={status}")
        if limit:
            params.append(f"per_page={limit}")
        qs = ("?" + "&".join(params)) if params else ""
        return self._rest("GET", f"/projects{qs}") or []

    def get_project(self, project_id: str) -> dict:
        """Get project details."""
        return self._rest("GET", f"/projects/{project_id}") or {}

    # ── User / Org ──────────────────────────────────────────────

    def get_me(self) -> dict:
        """Get current authenticated user (bot's context)."""
        return self._rest("GET", "/users/me") or {}

    def list_departments(self) -> list[dict]:
        """List departments in the organization."""
        return self._rest("GET", "/departments") or []

    # ── Notifications ───────────────────────────────────────────

    def list_notifications(
        self,
        *,
        limit: Optional[int] = None,
        unread_only: bool = False,
    ) -> list[dict]:
        """List notifications for the current user/bot."""
        params: list[str] = []
        if limit:
            params.append(f"limit={limit}")
        if unread_only:
            params.append("unread_only=true")
        qs = ("?" + "&".join(params)) if params else ""
        return self._rest("GET", f"/notifications{qs}") or []

    def mark_notification_read(self, notification_id: str) -> None:
        """Mark a notification as read."""
        self._rest("POST", f"/notifications/{notification_id}/read")

    def get_unread_count(self) -> dict:
        """Get unread notification count."""
        return self._rest("GET", "/notifications/unread-count") or {"count": 0}
