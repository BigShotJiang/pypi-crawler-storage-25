"""Webhook server for receiving events from Workhub."""

from __future__ import annotations

import hashlib
import hmac
import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Any, Callable, Optional

from .types import WebhookEvent


EventHandler = Callable[[WebhookEvent], None]


class WebhookServer:
    """Simple HTTP server for receiving Workhub webhook events.

    Usage:
        server = WebhookServer(port=8000, secret="your-webhook-secret")

        @server.on("message.created")
        def handle_message(event: WebhookEvent):
            print(f"New message: {event.data}")

        @server.on("task.status_changed")
        def handle_task(event: WebhookEvent):
            print(f"Task changed: {event.data}")

        server.start()  # Blocks
    """

    def __init__(self, port: int = 8000, secret: Optional[str] = None, path: str = "/webhook"):
        self.port = port
        self.secret = secret
        self.path = path
        self._handlers: dict[str, list[EventHandler]] = {}
        self._catch_all: list[EventHandler] = []

    def on(self, event_type: Optional[str] = None) -> Callable[[EventHandler], EventHandler]:
        """Register an event handler.

        Args:
            event_type: Event type to handle (e.g., "message.created").
                       If None, handles all events.
        """
        def decorator(func: EventHandler) -> EventHandler:
            if event_type is None:
                self._catch_all.append(func)
            else:
                self._handlers.setdefault(event_type, []).append(func)
            return func
        return decorator

    def _verify_signature(self, body: bytes, signature: str) -> bool:
        """Verify HMAC-SHA256 webhook signature."""
        if not self.secret:
            return True
        expected = "sha256=" + hmac.new(
            self.secret.encode(), body, hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(expected, signature)

    def _dispatch(self, event: WebhookEvent) -> None:
        """Dispatch event to registered handlers."""
        handlers = self._handlers.get(event.event_type, [])
        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                print(f"[WebhookServer] Handler error for {event.event_type}: {e}")

        for handler in self._catch_all:
            try:
                handler(event)
            except Exception as e:
                print(f"[WebhookServer] Catch-all handler error: {e}")

    def start(self) -> None:
        """Start the webhook server (blocking)."""
        server_ref = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                if self.path != server_ref.path:
                    self.send_response(404)
                    self.end_headers()
                    return

                content_length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(content_length)

                # Verify signature
                signature = self.headers.get("X-Workhub-Signature", "")
                if server_ref.secret and not server_ref._verify_signature(body, signature):
                    self.send_response(401)
                    self.end_headers()
                    self.wfile.write(b'{"error":"invalid signature"}')
                    return

                try:
                    data = json.loads(body)
                except json.JSONDecodeError:
                    self.send_response(400)
                    self.end_headers()
                    return

                event = WebhookEvent(
                    event_type=self.headers.get("X-Workhub-Event", data.get("event_type", "")),
                    timestamp=self.headers.get("X-Workhub-Timestamp", ""),
                    bot_id=self.headers.get("X-Workhub-Bot-ID", ""),
                    data=data.get("data", data),
                    signature=signature,
                )

                server_ref._dispatch(event)

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"ok":true}')

            def log_message(self, format, *args):
                pass  # Suppress default logging

        httpd = HTTPServer(("0.0.0.0", self.port), Handler)
        print(f"[WebhookServer] Listening on :{self.port}{self.path}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n[WebhookServer] Shutting down.")
            httpd.server_close()
