"""Type definitions for Workhub Bot SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional


@dataclass
class Message:
    """A chat message."""

    id: str
    sender: str
    content: str
    created_at: str
    channel_id: Optional[str] = None
    topic_id: Optional[str] = None
    dm_room_id: Optional[str] = None

    @classmethod
    def from_text(cls, text: str) -> list["Message"]:
        """Parse formatted message text from MCP response."""
        messages = []
        for line in text.strip().split("\n"):
            line = line.strip()
            if not line or line.startswith("---") or line.startswith("총 "):
                continue
            if ": " in line and line.startswith("•"):
                parts = line.lstrip("• ").split(": ", 1)
                sender = parts[0].strip()
                rest = parts[1] if len(parts) > 1 else ""
                messages.append(cls(id="", sender=sender, content=rest, created_at=""))
        return messages


@dataclass
class Channel:
    """A channel."""

    name: str
    channel_type: str
    description: str = ""
    id: Optional[str] = None


@dataclass
class Project:
    """A project."""

    name: str
    description: str = ""
    id: Optional[str] = None


@dataclass
class Topic:
    """A topic within a project."""

    name: str
    project: str = ""
    status: str = ""
    id: Optional[str] = None


@dataclass
class Task:
    """A task."""

    id: str
    title: str
    status: str = "todo"
    priority: str = "medium"
    assignee: Optional[str] = None
    due_date: Optional[str] = None
    description: Optional[str] = None


@dataclass
class User:
    """A user."""

    name: str
    email: str
    role: str = ""
    department: Optional[str] = None
    phone: Optional[str] = None
    id: Optional[str] = None


@dataclass
class SearchResult:
    """Search result container."""

    query: str
    total: int = 0
    raw_text: str = ""


@dataclass
class WebhookEvent:
    """An incoming webhook event."""

    event_type: str
    timestamp: str
    bot_id: str
    data: dict[str, Any] = field(default_factory=dict)
    signature: Optional[str] = None


@dataclass
class BotInfo:
    """Bot information returned from auth."""

    bot_id: str
    org_id: str
    scopes: list[str] = field(default_factory=list)


# ── Bot Commands (#48) ─────────────────────────────────────


@dataclass
class BotCommand:
    """A bot custom command."""

    id: str
    bot_id: str
    command: str
    description: str
    usage_hint: str = ""
    created_at: str = ""


# ── Bookmarks (#51) ────────────────────────────────────────


@dataclass
class BookmarkMessage:
    """Message data embedded in a bookmark."""

    id: str
    content: str
    sender_name: str
    created_at: str


@dataclass
class Bookmark:
    """A channel bookmark."""

    id: str
    channel_id: str
    message_id: str
    user_id: str
    created_at: str
    message: Optional[BookmarkMessage] = None


# ── Channel Files (#52) ────────────────────────────────────


@dataclass
class ChannelFile:
    """A file attached in a channel."""

    id: str
    filename: str
    mime_type: str
    file_size: int
    uploader_id: str
    uploader_name: str
    created_at: str
    thumbnail_url: Optional[str] = None


@dataclass
class ChannelFileListResponse:
    """Paginated file list response."""

    files: list[ChannelFile] = field(default_factory=list)
    total: int = 0
    page: int = 1
    per_page: int = 20


# ── Mentions (#47) ─────────────────────────────────────────


@dataclass
class MentionTarget:
    """A mention target (user, department, @all, @here)."""

    id: str
    type: str  # user, all, here, department, bot
    name: str
    display_name: str
    avatar_url: Optional[str] = None
    department: Optional[str] = None


# ── Hashtags (#49) ─────────────────────────────────────────


@dataclass
class HashtagTarget:
    """A hashtag search result."""

    id: str
    type: str  # channel, task, project, tag
    name: str
    status: Optional[str] = None
    icon: Optional[str] = None


@dataclass
class HashtagPreview:
    """A hashtag preview card."""

    id: str
    type: str
    name: str
    description: Optional[str] = None
    status: Optional[str] = None
    member_count: Optional[int] = None
    assignee: Optional[str] = None
    due_date: Optional[str] = None
    progress: Optional[float] = None


# ── Slash Commands (#46) ───────────────────────────────────


@dataclass
class CommandDef:
    """A slash command definition."""

    name: str
    description: str
    usage: str = ""
    category: str = ""


@dataclass
class ExecuteCommandResult:
    """Result of executing a slash command."""

    text: str
    ephemeral: bool = False


# ── DM Room (#62) ─────────────────────────────────────────


@dataclass
class DMRoomMember:
    """A member of a DM room."""

    user_id: str
    display_name: str
    email: str
    avatar_url: Optional[str] = None


@dataclass
class DMRoom:
    """A DM room."""

    id: str
    org_id: str
    is_group: bool
    name: Optional[str] = None
    members: Optional[list["DMRoomMember"]] = None


# ── Channel Members (#62) ─────────────────────────────────


@dataclass
class ChannelMemberInfo:
    """Enhanced channel member info."""

    user_id: str
    display_name: str
    email: str
    role: str
    joined_at: str
    avatar_url: Optional[str] = None


# ── Schedules (#62) ───────────────────────────────────────


@dataclass
class BotSchedule:
    """A bot schedule."""

    id: str
    bot_id: str
    name: str
    schedule_type: str  # "cron" | "once"
    timezone: str
    payload: dict[str, Any] = field(default_factory=dict)
    is_active: bool = True
    run_count: int = 0
    cron_expr: Optional[str] = None
    run_at: Optional[str] = None
    last_run_at: Optional[str] = None
    next_run_at: Optional[str] = None
    max_runs: Optional[int] = None


# ── Interactive Messages (#62) ────────────────────────────


@dataclass
class InteractiveAction:
    """An action button/option in an interactive message."""

    id: str
    label: str
    style: Optional[str] = None  # "primary" | "danger" | "default"
    value: Optional[str] = None


@dataclass
class InteractiveMessageResult:
    """Result of sending an interactive message."""

    message_id: str
    interactive_message_id: str


@dataclass
class MessageActionResponse:
    """A user's action response on an interactive message."""

    id: str
    user_id: str
    action_id: str
    created_at: str
    action_value: Optional[str] = None
