"""Echo bot example — replies to every message with the same content."""

from workhub_bot_sdk import WorkhubBot, WebhookServer, WebhookEvent

# 1. Initialize the bot client
bot = WorkhubBot(
    base_url="http://localhost:8080",
    api_key="whb_xxxxxxxx_live_xxxxxxxxxxxxxxxx",  # Replace with your API key
)

# 2. Set up webhook listener for incoming events
webhook = WebhookServer(port=9000, secret="your-webhook-secret")


@webhook.on("message.created")
def on_message(event: WebhookEvent):
    """Echo back the received message."""
    data = event.data
    content = data.get("content", "")
    channel_id = data.get("channel_id")

    # Don't echo bot's own messages
    sender_type = data.get("sender_type", "")
    if sender_type == "bot":
        return

    if channel_id and content:
        bot.send_message(
            channel_id=channel_id,
            content=f"🤖 Echo: {content}",
        )


if __name__ == "__main__":
    print("Echo bot starting...")
    print("Listening for webhook events on :9000/webhook")
    webhook.start()
