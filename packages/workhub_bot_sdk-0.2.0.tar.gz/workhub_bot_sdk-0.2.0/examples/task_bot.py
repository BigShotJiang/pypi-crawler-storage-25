"""Task management bot example — creates tasks from chat messages."""

from workhub_bot_sdk import WorkhubBot

bot = WorkhubBot(
    base_url="http://localhost:8080",
    api_key="whb_xxxxxxxx_live_xxxxxxxxxxxxxxxx",
)


def main():
    # Verify connection
    info = bot.authenticate()
    print(f"Connected as bot: {info.bot_id} (org: {info.org_id})")
    print(f"Scopes: {info.scopes}")

    # List available tools
    tools = bot.list_tools()
    print(f"\nAvailable MCP tools ({len(tools)}):")
    for tool in tools:
        print(f"  - {tool['name']}: {tool.get('description', '')}")

    # List channels to find a topic
    print("\n--- Channels ---")
    channels = bot.list_channels(type="topics")
    print(channels)

    # Search for existing tasks
    print("\n--- Search ---")
    result = bot.search("배포", type="tasks")
    print(f"Found {result.total} results")
    print(result.raw_text)

    # Create a task (uncomment and set topic_id)
    # task_result = bot.create_task(
    #     topic_id="your-topic-uuid",
    #     title="SDK에서 생성한 태스크",
    #     priority="high",
    #     description="Python SDK 테스트 태스크입니다.",
    # )
    # print(f"\nCreated task: {task_result}")


if __name__ == "__main__":
    main()
