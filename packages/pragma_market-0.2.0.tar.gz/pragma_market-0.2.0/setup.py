from setuptools import setup

VERSION = "0.2.0"


if __name__ == "__main__":
    setup()
