from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

from pragma_market.cli import cli


class FakeClient:
    def __init__(self, *args, **kwargs):
        self.owner = kwargs.get("owner") or "demo-agent"
        self.wallet_path = Path(tempfile.gettempdir()) / "pragma-wallet.json"

    def get_network(self):
        return {
            "network": "devnet",
            "programId": "DemoProgram1111111111111111111111111111111111",
            "api_version": "1.0.0",
            "sdk_min_version": "0.1.0",
        }

    def get_open_markets(self, category=None, limit=None):
        markets = [
            {
                "marketId": "demo-market",
                "question": "Will Demo ship by Apr 20?",
                "category": "AI",
                "status": "open",
                "yesPriceCents": 54,
                "noPriceCents": 46,
                "fillCount": 2,
                "activeOwners": 3,
                "volumeMatchedCents": 1200,
                "closeTs": "2026-04-20T18:00:00.000Z",
                "resolutionSource": "https://example.com",
            }
        ]
        return {"count": len(markets[:limit]), "markets": markets[:limit]}

    def get_positions(self, owner=None, market_id=None):
        return {
            "positions": [
                {
                    "marketId": market_id or "demo-market",
                    "yes": {"quantity": 2},
                    "no": {"quantity": 0},
                    "claimablePayoutCents": 0,
                }
            ]
        }

    def get_portfolio(self, owner=None):
        return {"portfolio": {"freeCollateralCents": 1000, "lockedCollateralCents": 200}}

    def get_agent_profile(self, agent_name_or_id=None):
        return {"agent": {"id": "demo-agent", "name": agent_name_or_id or "demo-agent", "origin": "external"}}

    def get_leaderboard(self, limit=None):
        rows = [{"agentId": "demo-agent", "agentName": "demo-agent", "volumeMatchedCents": 1200}]
        return {"leaderboard": rows[:limit], "count": len(rows[:limit])}


class CliTests(unittest.TestCase):
    def setUp(self):
        self.runner = CliRunner()

    @patch("pragma_market.cli._client", return_value=FakeClient())
    def test_open_markets_outputs_agent_friendly_json(self, _client_factory):
        result = self.runner.invoke(cli, ["open-markets", "--limit", "1"])
        self.assertEqual(result.exit_code, 0, result.output)
        payload = json.loads(result.output)
        self.assertEqual(payload["command"], "open-markets")
        self.assertEqual(payload["network"]["mode"], "devnet")
        self.assertEqual(payload["markets"][0]["marketId"], "demo-market")

    @patch("pragma_market.cli._client", return_value=FakeClient())
    def test_my_positions_outputs_owner_snapshot(self, _client_factory):
        result = self.runner.invoke(cli, ["my-positions"])
        self.assertEqual(result.exit_code, 0, result.output)
        payload = json.loads(result.output)
        self.assertEqual(payload["command"], "my-positions")
        self.assertEqual(payload["owner"], "demo-agent")
        self.assertIn("portfolio", payload)

    @patch("pragma_market.cli._client", return_value=FakeClient())
    def test_leaderboard_outputs_json(self, _client_factory):
        result = self.runner.invoke(cli, ["leaderboard"])
        self.assertEqual(result.exit_code, 0, result.output)
        payload = json.loads(result.output)
        self.assertEqual(payload["command"], "leaderboard")
        self.assertEqual(payload["count"], 1)

    def test_quickstart_scaffolds_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            target = Path(tmpdir) / "starter"
            result = self.runner.invoke(cli, ["quickstart", "--dir", str(target)])
            self.assertEqual(result.exit_code, 0, result.output)
            self.assertTrue((target / "agent.py").exists())
            self.assertTrue((target / "README.md").exists())
            self.assertTrue((target / ".env.example").exists())

    def test_example_agent_exports_template(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            target = Path(tmpdir) / "agent.py"
            result = self.runner.invoke(
                cli,
                ["example-agent", "--template", "polymarket-style", "--output", str(target)],
            )
            self.assertEqual(result.exit_code, 0, result.output)
            self.assertIn("PragmaClient", target.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
