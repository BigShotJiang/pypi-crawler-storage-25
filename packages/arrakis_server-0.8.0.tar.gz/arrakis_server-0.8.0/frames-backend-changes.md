# Frames Backend Changes Needed

Changes required in `arrakis-backend-frames` to support issue 3 (stride/max_latency
for historical data) and complete issue 2 (describe for historical streams).

## 1. Add configurable default stride

The backend needs a `default_stride` parameter (in nanoseconds) representing the
natural block size for serving data from frame files. This is global to the backend,
not per-publisher or per-channel.

**Where channels are created without stride:**
- `MetadataServer.json_to_channel()` (`metadata.py:242-246`) — used by
  `list_channels()` and `describe_channels()`
- `ChanInfoBuilder.add_ngdd_chan_and_avail()` (`metadata.py:187`) — used by
  `create_data_plan_and_info()` for streaming

Both paths create `Channel(name=..., data_type=..., sample_rate=...)` with no
stride. The default stride should be injected so that channels returned by `find()`,
`describe()`, and used in `stream()` all carry it.

**Suggested approach:** Add a `default_stride` parameter to `FrameBackend.__init__()`
(default: 1s = `1_000_000_000` ns). Expose it as a CLI argument via
`add_arguments()`. Apply it when building Channel objects — either in
`MetadataServer` or by wrapping channels in the `FrameBackend` methods.

## 2. Leave max_latency as None

Do NOT set max_latency on historical channels. The client and mux layer are being
updated to treat `max_latency=None` as "no timeout constraint", which is the correct
semantic for historical data (data either exists or it doesn't — there is no
real-time arrival expectation).

## 3. Fix retention defaults

`mds_to_scope_map()` (`metadata.py:55-62`) currently creates `Retention()` which
defaults to `newest=0, oldest=inf` — this incorrectly claims the backend serves
live data. It should be configured to reflect that the frames backend serves
historical data only, e.g.:

```python
Retention(newest=900, oldest=math.inf)
```

The `newest` value should be configurable (it represents the boundary between
"live" and "historical" and must match the live backend's `oldest` retention for
correct routing).

## 4. Publisher field (future)

No action needed now. As the metadata service evolves to track publisher provenance
for historical data, it can populate the `publisher` field on Channel objects
returned by `list_channels()` / `describe_channels()`. This should come from the
metadata service, not from static config files.
