import math

import gpstime
import pytest
from arrakis import Time

from ..scope import Retention, ScopeInfo, ScopeMap

GPS_NOW = 1_400_000_000
GPS_NOW_DATETIME = gpstime.gpstime.fromgps(GPS_NOW)


@pytest.fixture
def live_scope_info():
    return ScopeInfo(
        scopes={"H1": [{"subsystem": "CAL"}, {"subsystem": "DAQ"}]},
        retention=Retention(newest=0, oldest=900),
    )


@pytest.fixture
def historical_scope_info():
    return ScopeInfo(
        scopes={"H1": [{"subsystem": "CAL"}, {"subsystem": "DAQ"}]},
        retention=Retention(newest=900, oldest=math.inf),
    )


@pytest.fixture
def scope_map(live_scope_info, historical_scope_info):
    return ScopeMap(
        servers={
            "grpc://live:31206": live_scope_info,
            "grpc://historical:31206": historical_scope_info,
        }
    )


class TestFilterByTime:
    def test_none_routes_to_live(self, scope_map, freezer):
        freezer.move_to(GPS_NOW_DATETIME)
        filtered = scope_map.filter_by_time(None)
        assert "grpc://live:31206" in filtered.servers
        assert "grpc://historical:31206" not in filtered.servers

    def test_recent_time_routes_to_live(self, scope_map, freezer):
        freezer.move_to(GPS_NOW_DATETIME)
        # 5 minutes ago -- within the live window (oldest=900s)
        time_ns = (GPS_NOW - 300) * Time.SECONDS
        filtered = scope_map.filter_by_time(time_ns)
        assert "grpc://live:31206" in filtered.servers
        assert "grpc://historical:31206" not in filtered.servers

    def test_old_time_routes_to_historical(self, scope_map, freezer):
        freezer.move_to(GPS_NOW_DATETIME)
        # 1 hour ago -- outside live window, inside historical
        time_ns = (GPS_NOW - 3600) * Time.SECONDS
        filtered = scope_map.filter_by_time(time_ns)
        assert "grpc://live:31206" not in filtered.servers
        assert "grpc://historical:31206" in filtered.servers

    def test_boundary_time_matches_both(self, scope_map, freezer):
        freezer.move_to(GPS_NOW_DATETIME)
        # Exactly at the boundary (900s ago) -- both backends cover this
        time_ns = (GPS_NOW - 900) * Time.SECONDS
        filtered = scope_map.filter_by_time(time_ns)
        assert "grpc://live:31206" in filtered.servers
        assert "grpc://historical:31206" in filtered.servers

    def test_future_time_routes_to_live(self, scope_map, freezer):
        freezer.move_to(GPS_NOW_DATETIME)
        time_ns = (GPS_NOW + 100) * Time.SECONDS
        filtered = scope_map.filter_by_time(time_ns)
        assert "grpc://live:31206" in filtered.servers
        assert "grpc://historical:31206" not in filtered.servers

    def test_no_match_returns_empty(self, freezer):
        freezer.move_to(GPS_NOW_DATETIME)
        live_only = ScopeInfo(
            scopes={"H1": [{"subsystem": "CAL"}]},
            retention=Retention.from_live_only(),
        )
        scope_map = ScopeMap(servers={"grpc://live:31206": live_only})

        # Historical time won't match a live-only backend
        time_ns = (GPS_NOW - 3600) * Time.SECONDS
        filtered = scope_map.filter_by_time(time_ns)
        assert len(filtered.servers) == 0


class TestSplitByRange:
    def test_fully_within_live(self, scope_map, freezer):
        """Request fully within live window returns single slice."""
        freezer.move_to(GPS_NOW_DATETIME)
        start = (GPS_NOW - 300) * Time.SECONDS
        end = GPS_NOW * Time.SECONDS
        result = scope_map.split_by_range(start, end)

        assert len(result) == 1
        s, e, sm = result[0]
        assert s == start
        assert e == end
        assert "grpc://live:31206" in sm.servers

    def test_fully_historical(self, scope_map, freezer):
        """Request fully within historical window returns single slice."""
        freezer.move_to(GPS_NOW_DATETIME)
        start = (GPS_NOW - 7200) * Time.SECONDS
        end = (GPS_NOW - 3600) * Time.SECONDS
        result = scope_map.split_by_range(start, end)

        assert len(result) == 1
        s, e, sm = result[0]
        assert s == start
        assert e == end
        assert "grpc://historical:31206" in sm.servers

    def test_spanning_boundary_splits(self, scope_map, freezer):
        """Request spanning the retention boundary splits into two slices."""
        freezer.move_to(GPS_NOW_DATETIME)
        start = (GPS_NOW - 1800) * Time.SECONDS  # 30 min ago
        end = GPS_NOW * Time.SECONDS
        result = scope_map.split_by_range(start, end)

        assert len(result) == 2
        # first slice: historical portion
        s1, e1, sm1 = result[0]
        assert s1 == start
        assert e1 == (GPS_NOW - 900) * Time.SECONDS
        assert "grpc://historical:31206" in sm1.servers
        # second slice: live portion
        s2, e2, sm2 = result[1]
        assert s2 == (GPS_NOW - 900) * Time.SECONDS
        assert e2 == end
        assert "grpc://live:31206" in sm2.servers

    def test_boundary_overlap(self, scope_map, freezer):
        """Both backends serve the boundary point (overlap, not gap)."""
        freezer.move_to(GPS_NOW_DATETIME)
        start = (GPS_NOW - 1800) * Time.SECONDS
        end = GPS_NOW * Time.SECONDS
        result = scope_map.split_by_range(start, end)

        # The split point is at the boundary — both slices include it
        _, e1, sm1 = result[0]
        s2, _, sm2 = result[1]
        assert e1 == s2  # contiguous
        # both backends cover the boundary timestamp
        boundary = (GPS_NOW - 900) * Time.SECONDS
        assert sm1.filter_by_time(boundary).servers
        assert sm2.filter_by_time(boundary).servers

    def test_none_start_no_split(self, scope_map, freezer):
        """start=None (live stream) returns single slice, no splitting."""
        freezer.move_to(GPS_NOW_DATETIME)
        result = scope_map.split_by_range(None, None)
        assert len(result) == 1
        s, e, sm = result[0]
        assert s is None
        assert e is None
        assert "grpc://live:31206" in sm.servers

    def test_none_end_no_split(self, scope_map, freezer):
        """end=None (open-ended live) returns single slice."""
        freezer.move_to(GPS_NOW_DATETIME)
        start = (GPS_NOW - 300) * Time.SECONDS
        result = scope_map.split_by_range(start, None)
        assert len(result) == 1
        s, e, _sm = result[0]
        assert s == start
        assert e is None
