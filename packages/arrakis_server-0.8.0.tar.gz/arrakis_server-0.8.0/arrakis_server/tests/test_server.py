import json
import math

import pytest
from arrakis import schemas
from arrakis.constants import DEFAULT_MATCH
from arrakis.flight import RequestType, RequestValidator, create_command
from pyarrow import flight

from .. import constants
from ..scope import Retention, ScopeInfo, ScopeMap
from ..server import parse_url


@pytest.fixture(scope="module")
def validator():
    return RequestValidator()


def test_parse_url():
    assert parse_url(None) is None
    assert parse_url("0") is None
    assert parse_url("-") is None
    assert parse_url("grpc://0.0.0.0:0") == ("0.0.0.0", 0)  # noqa S104
    assert parse_url("//0.0.0.0:0") == ("0.0.0.0", 0)  # noqa S104
    assert parse_url("0.0.0.0:0") == ("0.0.0.0", 0)  # noqa S104
    assert parse_url(("0.0.0.0", 0)) == ("0.0.0.0", 0)  # noqa S104
    assert parse_url(("12.234.434.3", 0)) == ("12.234.434.3", 0)
    assert parse_url(("12.234.434.3", 340)) == ("12.234.434.3", 340)
    assert parse_url("12.234.434.3:340") == ("12.234.434.3", 340)
    assert parse_url("//12.234.434.3:340") == ("12.234.434.3", 340)
    assert parse_url("grpc://12.234.434.3:340") == ("12.234.434.3", 340)
    # FIXME: would be nice to handle string port specifiers as well
    # assert parse_url(("12.234.434.3", "340")) == ("12.234.434.3", 340)


def test_count_flight_info(mock_server, validator):
    cmd = create_command(
        RequestType.Count,
        pattern=DEFAULT_MATCH,
        data_type=[],
        min_rate=0,
        max_rate=16384,
        publisher=[],
        time=None,
        validator=validator,
    )

    info = mock_server.make_flight_info(cmd)
    assert info.schema == schemas.count()


def test_find_flight_info(mock_server, validator):
    cmd = create_command(
        RequestType.Find,
        pattern=DEFAULT_MATCH,
        data_type=[],
        min_rate=0,
        max_rate=16384,
        publisher=[],
        time=None,
        validator=validator,
    )

    info = mock_server.make_flight_info(cmd)
    assert info.schema == schemas.metadata()


def test_describe_flight_info(mock_server, mock_channels, validator):
    channels = list(mock_channels.keys())
    cmd = create_command(
        RequestType.Describe, channels=channels, time=None, validator=validator
    )

    info = mock_server.make_flight_info(cmd)
    assert info.schema == schemas.metadata()


def test_stream_flight_info(mock_server, mock_channels, validator):
    channels = list(mock_channels.keys())
    cmd = create_command(
        RequestType.Stream,
        channels=channels,
        start=None,
        end=None,
        validator=validator,
    )

    info = mock_server.make_flight_info(cmd)
    assert info.schema == schemas.stream(list(mock_channels.values()))


def test_get_count(mock_server, validator):
    cmd = create_command(
        RequestType.Count,
        pattern=DEFAULT_MATCH,
        data_type=[],
        min_rate=0,
        max_rate=16384,
        publisher=[],
        time=None,
        validator=validator,
    )
    endpoint = flight.FlightEndpoint(cmd, [constants.DEFAULT_LOCATION])

    # FIXME: find out how to parse a RecordBatchStream if possible
    mock_server.process_get_request(None, endpoint.ticket)


def test_get_find(mock_server, validator):
    cmd = create_command(
        RequestType.Find,
        pattern=DEFAULT_MATCH,
        data_type=[],
        min_rate=0,
        max_rate=16384,
        publisher=[],
        time=None,
        validator=validator,
    )
    endpoint = flight.FlightEndpoint(cmd, [constants.DEFAULT_LOCATION])

    # FIXME: find out how to parse a RecordBatchStream if possible
    mock_server.process_get_request(None, endpoint.ticket)


def test_get_describe(mock_server, mock_channels, validator):
    channels = list(mock_channels.keys())
    cmd = create_command(
        RequestType.Describe, channels=channels, time=None, validator=validator
    )
    endpoint = flight.FlightEndpoint(cmd, [constants.DEFAULT_LOCATION])

    # FIXME: find out how to parse a RecordBatchStream if possible
    mock_server.process_get_request(None, endpoint.ticket)


def test_get_stream(mock_server, mock_channels, validator):
    channels = list(mock_channels.keys())
    cmd = create_command(
        RequestType.Stream,
        channels=channels,
        start=1187000000,
        end=1187001000,
        validator=validator,
    )
    endpoint = flight.FlightEndpoint(cmd, [constants.DEFAULT_LOCATION])

    # FIXME: find out how to parse a RecordBatchStream if possible
    mock_server.process_get_request(None, endpoint.ticket)


def test_retention_as_dict():
    r = Retention(newest=0, oldest=3600)
    d = r.as_dict()
    assert d == {"newest": 0, "oldest": 3600}


def test_retention_as_dict_inf():
    r = Retention(newest=0, oldest=math.inf)
    d = r.as_dict()
    assert d == {"newest": 0, "oldest": "inf"}
    assert float(d["oldest"]) == math.inf


def test_scope_info_as_dict():
    info = ScopeInfo(
        scopes={"H1": [{"subsystem": "CAL"}]},
        retention=Retention(newest=0, oldest=3600),
    )
    d = info.as_dict()
    assert d == {
        "scopes": {"H1": [{"subsystem": "CAL"}]},
        "retention": {"newest": 0, "oldest": 3600},
    }


def test_scope_map_as_dict():
    scope_map = ScopeMap(
        servers={
            "grpc://server1:8815": ScopeInfo(
                scopes={"H1": [{"subsystem": "CAL"}]},
                retention=Retention(newest=0, oldest=3600),
            ),
        },
        local_endpoint="grpc://localhost:8815",
    )
    d = scope_map.as_dict()
    assert d["local_endpoint"] == "grpc://localhost:8815"
    assert "grpc://server1:8815" in d["endpoints"]
    assert d["endpoints"]["grpc://server1:8815"]["scopes"] == {
        "H1": [{"subsystem": "CAL"}]
    }
    # verify it's JSON-serializable
    json.dumps(d)


def test_list_actions(mock_server):
    actions = mock_server.list_actions(None)
    action_names = [name for name, _ in actions]
    assert "server-info" in action_names
    assert "scope-map" in action_names


def test_server_info_action(mock_server):
    action = flight.Action("server-info", b"")
    results = list(mock_server.do_action(None, action))
    assert len(results) == 1
    info = json.loads(results[0])
    assert "server_version" in info
    assert "arrakis_version" in info
    assert "arrakis_schema_version" in info
    assert "backend" in info
    assert "backend_version" in info
    assert "capabilities" in info
    assert "domains" in info
    assert "find" in info["capabilities"]
    assert "stream" in info["capabilities"]


def test_scope_map_action(mock_server):
    action = flight.Action("scope-map", b"")
    results = list(mock_server.do_action(None, action))
    assert len(results) == 1
    service_map = json.loads(results[0])
    assert "endpoints" in service_map
    assert "local_endpoint" in service_map
