# Multi-Backend Issues: Status Tracker

Cross-references `multi-backend-issues.md`. Updated as issues are resolved.

## Issue 1: Time-spanning requests don't split across backends

**Status:** Resolved
**What changed:**
- Added `Retention.boundaries_ns()` to compute absolute GPS timestamps of
  retention boundaries.
- Added `ScopeMap.split_by_range(start, end)` which collects retention
  boundaries within the requested range and splits it into sub-intervals,
  each with a scope map filtered to servers that fully cover that slice.
  Sub-intervals share the boundary point (overlap, not gap).
- `_construct_endpoints` now uses `split_by_range` for Stream requests,
  generating separate endpoints with adjusted start/end times for each
  time slice. Each backend gets only the portion of the range it can serve.
- For `start=None` or `end=None` (live streams), no splitting occurs — the
  request routes to the live backend as before.
- If a single backend covers the full range, no splitting occurs (fast path).

## Issue 2: `describe` lacks time context but `stream` depends on it

**Status:** Resolved (pending frames backend providing stride)
**What changed:**
- `describe` accepts an optional `time` parameter (schema, server, client).
  The info server uses `filter_by_time()` to route describe requests to a
  single backend based on retention ranges. `time=None` routes to the live
  backend only.
- The nondeterministic race condition where the frames backend's incomplete
  metadata could win over the kafka backend's response is eliminated — only
  the live backend responds when `time=None`.
- The `max_latency` assertion has been removed from `stream()` — channels
  with `max_latency=None` (historical) are now accepted.
- `stream()` now passes `start_ns` as the time context to `_describe()`, so
  historical requests route describe to the frames backend and live requests
  route to the live backend.

**Depends on:** The frames backend must provide stride on Channel objects
(see issue 3 / `frames-backend-changes.md`) for historical streams to work
end-to-end.

## Issue 3: `stride` and `max_latency` semantics don't apply to offline data

**Status:** Partially resolved (client-side done, frames backend pending)

**What changed (client/mux):**
- `stream()` no longer asserts `max_latency` — channels with
  `max_latency=None` are accepted, meaning "no real-time constraint."
- `BlockMuxStream` collects timeouts only from channels that have
  `max_latency` set. When no channels have a latency constraint, timeouts
  are disabled entirely (`_use_timeouts=False`), preventing spurious
  gap-filling against historical data.
- Stride is still required — historical backends must provide it.

**What remains (frames backend):**
- The frames backend needs to populate a configurable default stride on
  Channel objects (global to the backend, not per-publisher).
- `max_latency` should be left as `None` on historical channels.
- Retention defaults need to be fixed (`newest=900` instead of `newest=0`).
- See `frames-backend-changes.md` for full details.

## Issue 4: Kafka endpoint assertion blocks multi-endpoint streaming

**Status:** Won't fix
**Notes:** In practice, data is served exclusively through Flight or
exclusively through Kafka — never mixed in the same request. The assertion
is a reasonable guard for now. May revisit if the deployment model changes.

## Issue 5: `find`/`count` return duplicates across backends

**Status:** Resolved
**What changed:** `find`, `count`, and `describe` commands now include a
required `time` parameter in their schemas. The info server's
`_construct_endpoints` calls `filter_by_time(time)` to select only the
backend(s) whose retention window covers the requested point in time.
`time=None` routes to the live backend, so queries for current state no
longer broadcast to all backends.

## Issue 6: `describe` could return conflicting metadata

**Status:** Resolved
**What changed:** Same routing as issue 5. Describe requests are routed to a
single backend based on the `time` parameter, eliminating the
nondeterministic last-writer-wins behavior from `MultiFlightReader`'s
threaded execution.
