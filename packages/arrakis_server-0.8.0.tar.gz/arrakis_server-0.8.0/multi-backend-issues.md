# Multi-Backend Issues: Info Server + Live (Kafka) + Historical (Frames)

This document captures known issues with running an information server that routes
requests across multiple backends with different time retention ranges (e.g., a
live kafka server and a historical frames server).

## Scenario

```
                          scope_map.yaml
                    ┌─────────────────────────┐
                    │ arrakis-online1:31206    │
                    │   retention: {oldest:900}│
                    │   (kafka, live <=15min)  │
                    │                         │
                    │ arrakis-frames:31206     │
                    │   retention: {newest:900}│
                    │   (frames, historical)   │
                    └─────────────────────────┘
                               │
                    ┌──────────┴──────────┐
                    │  arrakis:31206      │
                    │  (info server,      │
                    │   no backend)       │
                    └─────────────────────┘
```

## Background: Frames Backend

The frames backend (`arrakis-backend-frames`) derives channel metadata from frame
files via an HTTP metadata service, not from publisher TOML configs. Key
characteristics:

- **Metadata is minimal:** Only `name`, `sample_rate`, and `data_type` are populated
  on Channel objects. `stride`, `max_latency`, and `publisher` are not set.
- **Scopes are dynamic:** Domains/subsystems are discovered from the metadata
  service (`/api/ngdd/v0/channels/scopes/`), not from static config.
- **Retention is unset (bug):** The backend currently initializes `Retention()`
  with defaults (`newest=0, oldest=inf`). This is a bug — the frames backend
  should set retention to reflect that it serves historical data only (e.g.,
  `newest=900` to indicate it doesn't serve data newer than 15 minutes). Without
  this, the scope map cannot correctly distinguish live from historical servers
  for routing purposes.
- **Time ranges are per-request:** Availability is queried dynamically for each
  stream request via the metadata service, not derived from retention config.

### Metadata Divergence Between Backends

The live (kafka) and historical (frames) backends represent different snapshots of
channel metadata. They don't necessarily match:

- Channels are created and removed over time — the live server only knows about
  currently-active channels, while the frames backend has historical channels that
  may no longer exist.
- Channel metadata itself can change (sample rate, data type) — a given channel
  may have different properties at different points in time. The `time` field on
  `Channel` was intended for tracking this but is not currently used.
- Publishers are a live concept (who is actively publishing data), but the data
  they published eventually gets archived into frames. The publisher provenance
  still exists conceptually in the archived data, even if the publisher itself is
  gone.
- Partition IDs are not relevant for the frames backend.

### Historical Publishers

While publishers are currently only configured for the live (kafka) server, the
concept of a publisher extends to archived data — the data was originally
published by someone. We could introduce "historical publisher" configs for the
frames backend, similar to the existing TOML publisher configs, that assign
domain-subsystem scopes to publishers retroactively. This would:

- Provide a way to attach stride, max_latency defaults, and other metadata to
  channels served by the frames backend.
- Allow find/describe queries to filter by publisher even for historical data.
- Maintain provenance of who originally published data into the system.

These historical publisher configs can be constructed from known publisher
assignments.

### Stride for Historical Data

While `max_latency` is irrelevant for historical data, `stride` may still be
meaningful as a global property of the frames backend — it represents the natural
block size for serving data from frames (e.g., frame file duration). The client's
`stream()` uses stride to know what block size to expect from the reader. The
frames backend could expose a configurable default stride, potentially through
historical publisher configs, without needing per-channel configuration.

### Time-Aware Metadata Queries

Metadata queries (find, count, describe) should support an optional time parameter
indicating when the request is valid. Default is `None` (meaning "now" — current
state). This would allow the info server to route the query to the appropriate
backend based on the requested point in time:

- `describe(channels, time=None)` → routes to the live server (current metadata)
- `describe(channels, time=1200000000)` → routes to the frames backend (historical)

This approach naturally resolves issues #5 and #6 (duplicates and conflicts) by
making metadata queries time-aware rather than broadcasting to all backends.

## Issues

### 1. Time-spanning requests don't split across backends

**Severity:** Critical
**Affects:** `stream`, `fetch`
**Location:** `arrakis_server/server.py` (`_construct_endpoints`), `arrakis_server/scope.py` (`filter_by_range`)

When a request spans both live and historical time (e.g., "last 30 minutes"),
`filter_by_range` checks `in_range(start) AND in_range(end)` for each server.
With non-overlapping retention ranges, **neither** server matches:

- Kafka: `in_range(start)` fails (start is 30min ago, outside 15min window)
- Frames: `in_range(end)` fails (end is now, but `newest=900` excludes recent data)

Result: `"Could not find channel(s) at any known endpoint."` error.

**What's needed:** The info server needs to split the time range at the retention
boundary, creating separate endpoints for each backend covering its portion. This
requires changes to `_construct_endpoints` to:

1. Detect when no single server covers the full range but partial coverage exists.
2. Split the time range at retention boundaries.
3. Generate separate endpoints with adjusted start/end times in their tickets.

Note: There may be a gap or overlap at the boundary depending on how retention is
configured and how quickly data gets archived to frames. An overlap is generally
preferable (let both backends return data and deduplicate) over a gap (data loss).

### 2. `describe` lacks time context but `stream` depends on it

**Severity:** Medium
**Affects:** `stream`, `fetch` (via the describe pre-flight in `client.py`)
**Location:** `arrakis/client.py:244-247`

`stream()` calls `self._describe(client, channels)` before the stream request to
get stride/max_latency metadata. This describe has no time range, so the info
server routes it using the unfiltered scope map. Both backends may respond:

- The kafka backend returns stride/max_latency (from publisher configs).
- The frames backend returns only name/sample_rate/data_type — no stride or
  max_latency.

If the frames backend's response wins the race (nondeterministic threading in
`MultiFlightReader`), the client hits:

```python
assert channel.stride, "Channels do not include stride info."
assert channel.max_latency, "Channels do not include latency info."
```

This is also a problem for purely historical requests — even if only the frames
backend responds, the assertions still fail.

**What's needed:** A combination of:

- The frames backend should provide a sensible default stride (via historical
  publisher configs or a global default). `max_latency` could be set to a large
  value indicating "no real-time constraint."
- For purely historical `fetch()` requests, the client could bypass the
  stride/max_latency assertions and the `BlockMuxStream` timeout machinery (see
  issue #3).
- Time-aware metadata queries (see above) would allow the info server to route
  describe to the appropriate backend based on the intended time context.

### 3. `stride` and `max_latency` semantics don't apply to offline data

**Severity:** Medium
**Affects:** `stream`, `fetch`, `BlockMuxStream`
**Location:** `arrakis/mux.py:305-316`

`stride` (how often data arrives) and `max_latency` (how late it can be) are
publisher/kafka concepts for live streaming. For frames data:

- Data either exists or it doesn't — there's no "expected arrival time."
- `BlockMuxStream` uses stride/max_latency to set timeouts and determine when to
  gap-fill. Timeouts racing against frame reads (which involve disk I/O and
  potentially memcache) can cause spurious drops.
- `fetch()` calls `stream()` internally, so it inherits the same problem.

However, stride is still meaningful as a block size hint — the frames backend
needs to know what chunk size to yield SeriesBlocks in, and the client needs to
know what to expect.

**What's needed:**

- The frames backend should set a stride (configurable default, possibly through
  historical publisher configs or derived from frame file duration).
- `max_latency` could be set to a large value or `BlockMuxStream` could disable
  timeout-based gap-filling for historical requests. The mux already has logic to
  disable timeouts for single-queue scenarios (line 333:
  `self._use_timeouts = len(self._queues) > 1`), which may naturally handle the
  single-frames-endpoint case.
- For `fetch()` specifically, the `concatenate_blocks` approach may be sufficient
  without muxing at all — the data arrives in order from frames.

### 4. Kafka endpoint assertion blocks multi-endpoint streaming

**Severity:** Medium
**Affects:** `stream`, `fetch`
**Location:** `arrakis/client.py:261-264`

```python
if len(flight_info.endpoints) > 1:
    for endpoint in flight_info.endpoints:
        assert not _endpoint_is_kafka(endpoint)
```

If the info server returns endpoints for both kafka and frames backends (after
fixing issue #1), this assertion fails. The kafka reader (`KafkaReader`) has
fundamentally different semantics from `MultiFlightReader` — it connects directly
to kafka brokers rather than using Arrow Flight `do_get`.

**What's needed:** For time-spanning requests, the client needs to:

1. Separate kafka endpoints from Flight endpoints.
2. Create a `KafkaReader` for the live portion and a `MultiFlightReader` for the
   historical portion.
3. Merge the two streams in the mux layer.

This is architecturally significant — the current client assumes a single reader
type per request.

### 5. `find`/`count` return duplicates across backends

**Severity:** Low
**Affects:** `find`, `count`
**Location:** `arrakis_server/server.py` (`_construct_endpoints`, Find/Count path)

If both backends serve the same domains/subsystems (which they will — archived
data comes from the same publishers), `find` through the info server queries both
and concatenates results. The client sees duplicate channels, and `count` returns
inflated numbers.

The duplicates may also have differing metadata (e.g., a channel whose sample rate
changed, or a historical channel no longer on the live server) — these aren't true
duplicates but represent different temporal snapshots of the same channel.

**What's needed:** Time-aware metadata queries (see "Time-Aware Metadata Queries"
above) would resolve this naturally — `find(time=None)` routes to the live server
for current state, `find(time=<gps>)` routes to the frames backend for historical
state. Without the time parameter, routing to a single preferred backend (e.g.,
live for current state) would avoid duplicates at the cost of not surfacing
historical-only channels.

### 6. `describe` could return conflicting metadata

**Severity:** Low
**Affects:** `describe`
**Location:** `arrakis/client.py` (`_describe`)

If both backends serve the same channel, two describe responses arrive via
`MultiFlightReader`'s threaded execution. The dict comprehension in `_describe`
keeps whichever comes last, which is nondeterministic.

Since the backends represent different metadata snapshots (see "Metadata
Divergence" above), the "correct" metadata depends on what the caller intends —
current state vs. historical state.

**What's needed:** Time-aware metadata queries would resolve this — route describe
to the appropriate backend based on the requested point in time.
