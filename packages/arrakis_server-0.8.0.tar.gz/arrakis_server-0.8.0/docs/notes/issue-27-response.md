# Issue 27: Channel retention info in find/describe responses

Draft response for https://git.ligo.org/ngdd/arrakis-server/-/issues/27

---

Recent work on multi-backend routing (time-aware metadata queries + time-range splitting) puts us in a good position to address this.

## Current state

`find`/`describe` now accept an optional `time` parameter that routes the query to the backend whose retention window covers that point in time. The server already has `Retention` info (newest/oldest) for each backend in the scope map. However, this retention info is not currently surfaced in the channel metadata response — it's only used for routing.

## Proposed approach

Use the existing `time` field on `Channel` to indicate when a channel's metadata became active. This field already exists in the dataclass but is currently unpopulated. Rather than adding new fields, we populate `time` to give users a complete picture of metadata validity.

### Why not `available_to`?

An end time for metadata validity is not well-defined. A channel's metadata is valid "from this point forward until superseded by a newer snapshot." Retention info is a sliding window relative to now, not a fixed time range — coupling it with a metadata end time would be contradictory.

### What this enables

A `find` or `describe` query over a time range could return multiple entries for the same channel name, each with a different `time` value. This gives users a full accounting of metadata changes (sample rate, data type, etc.) within the queried window, which is essential for understanding how to stitch data together across changes.

### Implementation

**Schema** (`arrakis-schema`):
- Add `time: int64` to `find/schema.txt` and `describe/schema.txt` response schemas (it already exists on the `Channel` dataclass but is not in the wire schema)

**Channel model** (`arrakis-python`):
- Add a `time` entry to `METADATA_FIELDS` in `schemas.py` so it gets serialized in metadata responses

**Server** (`arrakis-server`):
- Backends populate `time` on Channel objects to indicate when the metadata became active
- For the live backend, `time` could be the current GPS time (metadata is the current snapshot)
- For the frames backend, `time` comes from the metadata service as it tracks historical metadata changes

**Info server path**: No changes needed — the info server routes to the correct backend via `filter_by_time`, and the backend's response carries `time` natively.

This is a natural extension of the time-aware routing already in place — the same temporal model used for routing gets exposed to the user in the response.
