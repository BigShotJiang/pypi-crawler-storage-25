"""Optional integrations (FastAPI, etc.)."""
