"""Unified configuration system for reveal.

Supports multi-level precedence with deep merge semantics:
1. Command line flags (--select, --ignore, --config)
2. Environment variables (REVEAL_CONFIG, REVEAL_RULES_DISABLE)
3. Project config (.reveal.yaml - walks up directory tree)
4. User config (~/.config/reveal/config.yaml)
5. System config (/etc/reveal/config.yaml)
6. Built-in defaults (hardcoded in rules)

Configuration files are discovered by walking up the directory tree from the
target path until a config with root:true is found or the filesystem root.

YAML is the primary format. TOML support via pyproject.toml [tool.reveal] section.
"""

from pathlib import Path
import os
import sys
import logging
import json
import re
from typing import Optional, List, Dict, Any, cast
from dataclasses import dataclass
import fnmatch
import functools

try:
    import yaml
except ImportError:
    yaml = None  # type: ignore[assignment]

try:
    import tomllib  # Python 3.11+
except ImportError:
    try:
        import tomli as tomllib  # Backport
    except ImportError:
        tomllib = None

try:
    import jsonschema
except ImportError:
    jsonschema = None

logger = logging.getLogger(__name__)


def _apply_int_rule_env(config: dict, env_var: str, rule_key: str, field_key: str) -> None:
    """Read an integer from an env var and set config['rules'][rule_key][field_key]."""
    value = os.getenv(env_var)
    if not value:
        return
    try:
        config.setdefault('rules', {})[rule_key] = {field_key: int(value)}
    except ValueError:
        logger.warning(f"Invalid {env_var} value: {value}")


_path_resolve_cache: Dict[Path, Path] = {}


def _cached_resolve(path: Path) -> Path:
    """Resolve a path, caching the result to avoid repeated lstat chains.

    Path.resolve() traverses every path component via lstat to canonicalize
    symlinks. With many files and override patterns this adds up fast.
    """
    resolved = _path_resolve_cache.get(path)
    if resolved is None:
        resolved = path.resolve()
        _path_resolve_cache[path] = resolved
    return resolved


# Null bytes cannot appear in filesystem paths on any OS, making this the
# safest possible placeholder for the ** glob wildcard during fnmatch.translate.
_GLOB_STAR_PLACEHOLDER = '\x00\x00'


@functools.lru_cache(maxsize=512)
def _compile_glob_regex(pattern: str) -> re.Pattern:
    """Compile a glob pattern to a regex object (cached).

    Patterns are fixed across a run, so compiling them once eliminates
    thousands of redundant fnmatch.translate + re.compile calls.
    """
    ph = _GLOB_STAR_PLACEHOLDER
    if '**' in pattern:
        p = pattern.replace('/**/', f'/{ph}/')  # Middle position
        p = p.replace('**/', f'{ph}/')           # Start position
        p = p.replace('/**', f'/{ph}')           # End position
        p = p.replace('**', ph)                  # Standalone
        p = fnmatch.translate(p)
        p = p.replace(f'/{ph}/', '(/|/.*/)')
        p = p.replace(f'{ph}/', '(.*/)?')
        p = p.replace(f'/{ph}', '(/.*)?')
        p = p.replace(ph, '.*')
    else:
        p = fnmatch.translate(pattern)
    return re.compile(p)


def glob_match(path: Path, pattern: str) -> bool:
    """Match a path against a glob pattern with ** support (gitignore-style).

    Supports:
    - * matches anything except /
    - ** matches zero or more path components
    - ? matches any single character except /

    Args:
        path: Path to match (can be relative or absolute)
        pattern: Glob pattern

    Returns:
        True if path matches pattern
    """
    path_str = str(path).replace(os.sep, '/')
    return _compile_glob_regex(pattern).match(path_str) is not None


# JSON Schema for .reveal.yaml validation
CONFIG_SCHEMA = {
    "type": "object",
    "properties": {
        "root": {"type": "boolean"},
        "extends": {"type": "string"},
        "ignore": {
            "type": "array",
            "items": {"type": "string"}
        },
        "include": {
            "type": "array",
            "items": {"type": "string"}
        },
        "rules": {
            "type": "object",
            "properties": {
                "enabled": {"type": "boolean"},
                "disable": {
                    "type": "array",
                    "items": {"type": "string"}
                },
                "select": {
                    "type": "array",
                    "items": {"type": "string"}
                }
            },
            "additionalProperties": True  # Per-rule configs
        },
        "overrides": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["files"],
                "properties": {
                    "files": {"type": "string"},
                    "rules": {"type": "object"}
                }
            }
        },
        "architecture": {
            "type": "object",
            "properties": {
                "layers": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["name", "paths"],
                        "properties": {
                            "name": {"type": "string"},
                            "paths": {"type": "array"},
                            "allow_imports": {"type": "array"},
                            "deny_imports": {"type": "array"}
                        }
                    }
                }
            }
        },
        "imports": {"type": "object"},
        "adapters": {"type": "object"},
        "plugins": {"type": "object"},
        "output": {"type": "object"},
        "cache": {"type": "object"},
        "display": {
            "type": "object",
            "properties": {
                "breadcrumbs": {"type": "boolean"}
            },
            "additionalProperties": False
        }
    },
    "additionalProperties": False
}


def _lookup_rule_config(config: Dict[str, Any], rule_code: str, key: str,
                        default: Optional[Any] = None) -> Any:
    """Get configuration value for a rule from a config dict."""
    rules = config.get('rules', {})
    rule_config = rules.get(rule_code, {})
    return rule_config.get(key, default)


@dataclass
class Override:
    """Per-directory configuration override."""

    files_pattern: str
    config: Dict[str, Any]

    def matches(self, file_path: Path, project_root: Optional[Path] = None) -> bool:
        """Check if this override matches the given file path.

        Args:
            file_path: File to check
            project_root: Project root for relative matching

        Returns:
            True if pattern matches file_path
        """
        if project_root:
            try:
                # Resolve both paths to handle symlinks consistently (macOS /var vs /private/var)
                resolved_file = _cached_resolve(file_path)
                resolved_root = _cached_resolve(project_root)
                rel_path = resolved_file.relative_to(resolved_root)
            except ValueError:
                rel_path = file_path
        else:
            rel_path = file_path

        # Use glob_match for proper ** support
        return glob_match(rel_path, self.files_pattern)


def _check_rule_enabled(rules: Dict[str, Any], rule_code: str) -> bool:
    """Return True if rule_code is enabled under the given rules config dict."""
    if not rules.get('enabled', True):
        return False
    if rule_code in rules.get('disable', []):
        return False
    selected = rules.get('select', [])
    if selected:
        if rule_code not in selected:
            prefix = rule_code[0] if rule_code else ""
            if prefix not in selected:
                return False
    return True


@dataclass
class FileConfig:
    """Configuration effective for a specific file (after applying overrides)."""

    _config: Dict[str, Any]
    _file_path: Path

    def is_rule_enabled(self, rule_code: str) -> bool:
        """Check if a rule is enabled for this file.

        Args:
            rule_code: Rule code (e.g., "E501", "C901")

        Returns:
            True if rule should run on this file
        """
        return _check_rule_enabled(self._config.get('rules', {}), rule_code)

    def get_rule_config(self, rule_code: str, key: str, default: Optional[Any] = None) -> Any:
        """Get configuration value for a specific rule.

        Args:
            rule_code: Rule code (e.g., "E501")
            key: Config key (e.g., "max_length")
            default: Default value if not set

        Returns:
            Config value or default
        """
        return _lookup_rule_config(self._config, rule_code, key, default)


class RevealConfig:
    """Unified configuration manager with multi-level precedence."""

    # Config instance cache: (resolved_path, cli_overrides_repr) -> RevealConfig.
    # Avoids re-parsing config files for the same project root within one process.
    _cache: Dict[Any, 'RevealConfig'] = {}

    # Project-root cache: resolved start_path -> project_root.
    # _find_project_root walks the filesystem; this avoids repeating that
    # traversal for files in the same directory (once per unique dir, O(n) total
    # without caching; O(unique_dirs) with caching).
    _root_cache: Dict[Path, Path] = {}

    # Path resolution is handled by module-level _cached_resolve() (shared with
    # FileConfig.matches) so there is no separate _resolve_cache here.

    def __init__(self, merged_config: Dict[str, Any], project_root: Optional[Path] = None):
        """Initialize with merged configuration.

        Args:
            merged_config: Final merged configuration dict
            project_root: Project root directory (where root:true config lives)
        """
        self._config = merged_config
        self._project_root = project_root or Path.cwd()
        self._overrides = self._parse_overrides()

    def _parse_overrides(self) -> List[Override]:
        """Parse override sections into Override objects."""
        overrides = []
        for override in self._config.get('overrides', []):
            overrides.append(Override(
                files_pattern=override['files'],
                config=override
            ))
        return overrides

    @classmethod
    def get(cls,
            start_path: Optional[Path] = None,
            cli_overrides: Optional[Dict[str, Any]] = None,
            no_config: bool = False) -> 'RevealConfig':
        """Get or create config instance (singleton per project root).

        Args:
            start_path: Starting path for config discovery (default: cwd)
            cli_overrides: Command-line overrides (highest precedence)
            no_config: If True, use only defaults (skip all config files)

        Environment variables:
            REVEAL_NO_CONFIG: Set to '1' to skip all config files (like --no-config)
            REVEAL_CONFIG: Path to a specific config file to load instead of discovery

        Returns:
            RevealConfig instance
        """
        # Check REVEAL_NO_CONFIG environment variable
        if os.getenv('REVEAL_NO_CONFIG') == '1':
            no_config = True

        if start_path is None:
            start_path = Path.cwd()

        # Normalize to absolute path (module-level _cached_resolve avoids repeated lstat chains)
        start_path = _cached_resolve(start_path)
        if start_path.is_file():
            start_path = start_path.parent

        # Check cache (unless no_config mode)
        if not no_config:
            project_root = cls._find_project_root(start_path)
            # Make cli_overrides hashable by converting to JSON string
            cli_key = json.dumps(cli_overrides or {}, sort_keys=True)
            cache_key = (project_root, cli_key)
            if cache_key in cls._cache:
                return cls._cache[cache_key]
        else:
            project_root = start_path

        # Load and merge configs
        merged = cls._load_and_merge(start_path, cli_overrides, no_config)

        # Create instance
        instance = cls(merged, project_root)

        # Cache it
        if not no_config:
            cls._cache[cache_key] = instance

        return instance

    @classmethod
    def _find_project_root(cls, start_path: Path) -> Path:
        """Find project root (where root:true config lives or git root).

        Results are cached by start_path so filesystem traversal runs once per
        unique directory instead of once per file checked.
        """
        if start_path in cls._root_cache:
            return cls._root_cache[start_path]

        result = cls._find_project_root_uncached(start_path)
        cls._root_cache[start_path] = result
        return result

    @classmethod
    def _reveal_yaml_is_root(cls, config_file: Path) -> bool:
        """Return True if the .reveal.yaml file at path declares root:true."""
        if not yaml:
            return False
        try:
            with open(config_file, encoding='utf-8') as f:
                config = yaml.safe_load(f) or {}
            return bool(config.get('root'))
        except (OSError, yaml.YAMLError):
            return False

    @classmethod
    def _find_project_root_uncached(cls, start_path: Path) -> Path:
        """Filesystem traversal for _find_project_root (no caching)."""
        _system_roots = frozenset({Path('/'), Path('/tmp'), Path('/var'), Path('/var/tmp')})
        current = start_path
        while current != current.parent:
            config_file = current / '.reveal.yaml'
            if config_file.exists() and cls._reveal_yaml_is_root(config_file):
                return current.resolve()
            if (current / '.git').exists() and current.resolve() not in _system_roots:
                return current.resolve()
            current = current.parent
        return start_path.resolve()

    @classmethod
    def _load_and_merge(cls,
                        start_path: Path,
                        cli_overrides: Optional[Dict[str, Any]] = None,
                        no_config: bool = False) -> Dict[str, Any]:
        """Load all configs and merge with precedence rules.

        Precedence (high to low):
        1. CLI overrides
        2. Environment variables
        3. REVEAL_CONFIG custom file (if specified)
        4. Project configs (walk up tree)
        5. User config
        6. System config
        7. Built-in defaults
        """
        configs = []

        if not no_config:
            # Check for REVEAL_CONFIG environment variable
            custom_config_path = os.getenv('REVEAL_CONFIG')

            if custom_config_path:
                # Load only the specified config file
                custom_config = cls._load_file(Path(custom_config_path))
                if custom_config:
                    configs.append(custom_config)
                else:
                    logger.warning(
                        f"REVEAL_CONFIG specified but file not found: {custom_config_path}"
                    )
            else:
                # Normal config discovery
                # 1. System config
                system_config = cls._load_file(Path('/etc/reveal/config.yaml'))
                if system_config:
                    configs.append(system_config)

                # 2. User config
                user_config_path = cls._get_user_config_path()
                user_config = cls._load_file(user_config_path) if user_config_path.exists() else None
                if user_config:
                    configs.append(user_config)

                # 3. Project configs (walk up from start_path)
                project_configs = cls._discover_project_configs(start_path)
                configs.extend(reversed(project_configs))  # Reverse so nearest is last

            # 4. Environment variables (always loaded, even with REVEAL_CONFIG)
            env_config = cls._load_from_env()
            if env_config:
                configs.append(env_config)

        # 5. CLI overrides (highest precedence)
        if cli_overrides:
            configs.append(cli_overrides)

        # Merge all configs (later configs override earlier)
        merged: Dict[str, Any] = {}
        for config in configs:
            merged = deep_merge(merged, config)

        return merged

    @classmethod
    def _try_load_pyproject_reveal(cls, pyproject: Path) -> Optional[Dict[str, Any]]:
        """Load [tool.reveal] section from a pyproject.toml, returning None on error."""
        if not pyproject.exists() or not tomllib:
            return None
        try:
            with open(pyproject, 'rb') as f:
                data = tomllib.load(f)
            return data.get('tool', {}).get('reveal')
        except Exception as e:
            logger.debug(f"Failed to load {pyproject}: {e}")
            return None

    @classmethod
    def _discover_project_configs(cls, start_path: Path) -> List[Dict[str, Any]]:
        """Walk up directory tree finding .reveal.yaml files.

        Returns:
            List of configs from root to start_path (furthest to nearest)
        """
        configs = []
        current = start_path

        while current != current.parent:
            # Check .reveal.yaml first
            config_file = current / '.reveal.yaml'
            if config_file.exists():
                config = cls._load_file(config_file)
                if config:
                    configs.append(config)
                if config and config.get('root'):
                    break

            pyproject_config = cls._try_load_pyproject_reveal(current / 'pyproject.toml')
            if pyproject_config:
                configs.append(pyproject_config)
            if pyproject_config and pyproject_config.get('root'):
                break

            current = current.parent

        return configs

    @classmethod
    def _validate_config_schema(cls, config: Dict[str, Any], path: Path) -> None:
        """Validate config against schema if jsonschema is available (warns, never raises)."""
        if not jsonschema:
            return
        try:
            jsonschema.validate(config, CONFIG_SCHEMA)
        except jsonschema.ValidationError as e:
            logger.warning(f"Invalid config in {path}: {e.message}")

    @classmethod
    def _load_file(cls, path: Path) -> Optional[Dict[str, Any]]:
        """Load and validate a config file."""
        if not path.exists():
            return None
        if not yaml:
            logger.warning(f"PyYAML not installed, cannot load {path}")
            return None
        try:
            with open(path, encoding='utf-8') as f:
                config = yaml.safe_load(f)
            if config is None:
                return {}
            cls._validate_config_schema(config, path)
            return cast(Dict[str, Any], config)
        except Exception as e:
            logger.error(f"Failed to load config {path}: {e}")
            return None

    @classmethod
    def _get_user_config_path(cls) -> Path:
        """Get user config path following XDG spec."""
        xdg_config = os.getenv('XDG_CONFIG_HOME')
        if xdg_config:
            return Path(xdg_config) / 'reveal' / 'config.yaml'
        return Path.home() / '.config' / 'reveal' / 'config.yaml'

    @classmethod
    def _load_from_env(cls) -> Dict[str, Any]:
        """Load configuration from environment variables.

        Supported environment variables:
        - REVEAL_RULES_DISABLE: Comma-separated list of rules to disable
        - REVEAL_RULES_SELECT: Comma-separated list of rules/categories to select
        - REVEAL_FORMAT: Output format (json, yaml, etc.)
        - REVEAL_IGNORE: Comma-separated glob patterns to ignore
        - REVEAL_C901_THRESHOLD: Complexity threshold for C901 rule
        - REVEAL_E501_MAX_LENGTH: Max line length for E501 rule
        - REVEAL_BREADCRUMBS: Enable/disable breadcrumbs (0/1, false/true, no/yes)

        Examples:
            export REVEAL_RULES_DISABLE="E501,D001"
            export REVEAL_RULES_SELECT="B,S"
            export REVEAL_FORMAT=json
            export REVEAL_IGNORE="*.min.js,vendor/**"
            export REVEAL_C901_THRESHOLD=20
            export REVEAL_E501_MAX_LENGTH=120
            export REVEAL_BREADCRUMBS=0
        """
        config: Dict[str, Any] = {}

        # REVEAL_RULES_DISABLE="E501,D001"
        if disable := os.getenv('REVEAL_RULES_DISABLE'):
            config['rules'] = {'disable': [r.strip() for r in disable.split(',')]}

        # REVEAL_RULES_SELECT="B,S"
        if select := os.getenv('REVEAL_RULES_SELECT'):
            config.setdefault('rules', {})['select'] = [r.strip() for r in select.split(',')]

        # REVEAL_FORMAT=json
        if fmt := os.getenv('REVEAL_FORMAT'):
            config['output'] = {'format': fmt}

        # REVEAL_IGNORE="*.min.js,vendor/**"
        if ignore := os.getenv('REVEAL_IGNORE'):
            config['ignore'] = [p.strip() for p in ignore.split(',')]

        _apply_int_rule_env(config, 'REVEAL_C901_THRESHOLD', 'C901', 'threshold')
        _apply_int_rule_env(config, 'REVEAL_E501_MAX_LENGTH', 'E501', 'max_length')

        # REVEAL_BREADCRUMBS=0 (or 1, false, true, no, yes)
        if breadcrumbs_env := os.getenv('REVEAL_BREADCRUMBS'):
            config.setdefault('display', {})['breadcrumbs'] = (
                breadcrumbs_env.lower() not in ('0', 'false', 'no')
            )

        return config

    def get_file_config(self, file_path: Path) -> FileConfig:
        """Get effective configuration for a specific file.

        Applies overrides matching the file path.

        Args:
            file_path: File to get config for

        Returns:
            FileConfig instance with merged configuration
        """
        # Start with base config
        effective = self._config.copy()

        # Apply matching overrides
        for override in self._overrides:
            if override.matches(file_path, self._project_root):
                effective = deep_merge(effective, override.config)

        return FileConfig(effective, file_path)

    def is_rule_enabled(self, rule_code: str, file_path: Optional[Path] = None) -> bool:
        """Check if a rule is globally enabled.

        Args:
            rule_code: Rule code (e.g., "E501")
            file_path: Optional file path for per-file config

        Returns:
            True if rule should run
        """
        if file_path:
            return self.get_file_config(file_path).is_rule_enabled(rule_code)
        return _check_rule_enabled(self._config.get('rules', {}), rule_code)

    def get_rule_config(self, rule_code: str, key: str, default: Optional[Any] = None) -> Any:
        """Get configuration for a specific rule.

        Args:
            rule_code: Rule code (e.g., "C901")
            key: Config key (e.g., "threshold")
            default: Default value

        Returns:
            Configuration value or default
        """
        return _lookup_rule_config(self._config, rule_code, key, default)

    def should_ignore(self, path: Path) -> bool:
        """Check if a path should be ignored.

        Args:
            path: Path to check

        Returns:
            True if path matches ignore patterns
        """
        ignore_patterns = self._config.get('ignore', [])

        # Normalize to relative path
        if self._project_root:
            try:
                # Resolve both paths to handle symlinks consistently (macOS /var vs /private/var)
                resolved_path = _cached_resolve(path)
                resolved_root = _cached_resolve(self._project_root)
                rel_path = resolved_path.relative_to(resolved_root)
            except ValueError:
                rel_path = path
        else:
            rel_path = path

        # Use glob_match for proper ** support
        for pattern in ignore_patterns:
            if glob_match(rel_path, pattern):
                return True

        return False

    def get_layers(self) -> List[Dict[str, Any]]:
        """Get architectural layers configuration (for I003).

        Returns:
            List of layer definitions
        """
        arch = self._config.get('architecture', {})
        return cast(List[Dict[str, Any]], arch.get('layers', []))

    def get_adapter_config(self, adapter_name: str, section: Optional[str] = None) -> Dict[str, Any]:
        """Get adapter-specific configuration.

        Args:
            adapter_name: Adapter name (e.g., "mysql")
            section: Optional section within adapter config

        Returns:
            Adapter configuration dict
        """
        adapters = self._config.get('adapters', {})
        adapter_config = adapters.get(adapter_name, {})

        if section:
            return cast(Dict[str, Any], adapter_config.get(section, {}))
        return cast(Dict[str, Any], adapter_config)

    def get_plugin_config(self, plugin_name: str) -> Dict[str, Any]:
        """Get plugin-specific configuration (namespace isolated).

        Args:
            plugin_name: Plugin name

        Returns:
            Plugin configuration dict
        """
        plugins = self._config.get('plugins', {})
        return cast(Dict[str, Any], plugins.get(plugin_name, {}))

    def dump(self) -> str:
        """Dump merged configuration as YAML for debugging.

        Returns:
            YAML string of merged config
        """
        if yaml:
            return yaml.dump(self._config, default_flow_style=False)
        return str(self._config)

    @property
    def project_root(self) -> Path:
        """Get project root directory."""
        return self._project_root

    @property
    def user_data_dir(self) -> Path:
        """Get user data directory (backwards compatibility for rule discovery)."""
        return get_data_path('').parent

    @property
    def project_config_dir(self) -> Path:
        """Get project config directory (backwards compatibility for rule discovery)."""
        return Path.cwd() / '.reveal'

    def get_legacy_paths(self) -> Dict[str, Path]:
        """Get legacy config paths for migration (backwards compatibility).

        Returns:
            Dict mapping old locations to their purposes
        """
        return {
            'rules_user': Path.home() / '.reveal' / 'rules',
            'rules_project': Path.cwd() / '.reveal' / 'rules',
        }

    def is_breadcrumbs_enabled(self) -> bool:
        """Check if breadcrumbs are enabled.

        Breadcrumbs are navigation hints printed after reveal output.
        They can be disabled via config, environment, or CLI.

        TTY Detection:
            When stdout is not a TTY (piped to file, AI agent, etc.),
            breadcrumbs are automatically suppressed.

        First-run hint:
            On first use in a terminal, shows a hint about --no-breadcrumbs.

        Returns:
            True if breadcrumbs should be displayed (default: True for TTY)
        """
        display_config = self._config.get('display', {})

        # Explicit config always wins
        if 'breadcrumbs' in display_config:
            return cast(bool, display_config['breadcrumbs'])

        # TTY detection: suppress breadcrumbs when output is piped
        if not sys.stdout.isatty():
            return False

        return True


def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Deeply merge two configuration dictionaries.

    Merge rules:
    - Scalars (str, int, bool): override replaces base
    - Lists: override extends base (concatenate)
    - Dicts: recursive deep merge

    Args:
        base: Base configuration (lower precedence)
        override: Override configuration (higher precedence)

    Returns:
        Merged configuration dict
    """
    result = base.copy()

    for key, value in override.items():
        if key not in result:
            # New key from override
            result[key] = value

        elif isinstance(value, dict) and isinstance(result[key], dict):
            # Both dicts: recursive merge
            result[key] = deep_merge(result[key], value)

        elif isinstance(value, list) and isinstance(result[key], list):
            # Both lists: extend (concatenate)
            result[key] = result[key] + value

        else:
            # Scalar or type mismatch: override wins
            result[key] = value

    return result


# Global singleton instance
_config: Optional[RevealConfig] = None


def get_config(start_path: Optional[Path] = None, **kwargs) -> RevealConfig:
    """Get global config instance (convenience function).

    Args:
        start_path: Starting path for discovery
        **kwargs: Additional arguments passed to RevealConfig.get()

    Returns:
        RevealConfig instance
    """
    global _config
    if _config is None or start_path is not None:
        _config = RevealConfig.get(start_path, **kwargs)
    return _config


def _try_load_yaml_file(path: Path) -> Optional[Dict[str, Any]]:
    """Try to load a YAML file; return parsed dict or None on failure."""
    try:
        with open(path, encoding='utf-8') as f:
            loaded = yaml.safe_load(f)
            return cast(Dict[str, Any], loaded) if loaded is not None else None
    except Exception:
        return None


# Backwards compatibility functions (for existing code)
def load_config(name: str, default: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """DEPRECATED: Load YAML config file with defaults.

    This function maintains backwards compatibility with old code.
    New code should use RevealConfig.get() instead.

    Args:
        name: Config filename (e.g., 'mysql-health-checks.yaml')
        default: Default config if not found

    Returns:
        Config dict
    """
    logger.warning(f"load_config('{name}') is deprecated. Use RevealConfig.get() instead.")

    config_paths = [
        Path.cwd() / '.reveal' / name,
        Path.home() / '.config' / 'reveal' / name,
        Path('/etc/reveal') / name,
    ]

    for path in config_paths:
        if path.exists() and yaml:
            result = _try_load_yaml_file(path)
            if result is not None:
                return result

    return default or {}


def get_cache_path(name: str) -> Path:
    """Get cache file path (convenience function).

    Args:
        name: Cache filename

    Returns:
        Path to cache file in ~/.cache/reveal/
    """
    cache_dir = Path(os.getenv('XDG_CACHE_HOME', Path.home() / '.cache')) / 'reveal'
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir / name


def get_data_path(name: str) -> Path:
    """Get data file path (convenience function).

    Args:
        name: Data filename

    Returns:
        Path to data file in ~/.local/share/reveal/
    """
    data_dir = Path(os.getenv('XDG_DATA_HOME', Path.home() / '.local' / 'share')) / 'reveal'
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / name


def disable_breadcrumbs_permanently() -> bool:
    """Disable breadcrumbs by updating user config file.

    Creates or updates ~/.config/reveal/config.yaml with:
        display:
          breadcrumbs: false

    Returns:
        True if successful, False otherwise
    """
    config_path = RevealConfig._get_user_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    # Load existing config or start fresh
    config: Dict[str, Any] = {}
    if config_path.exists():
        try:
            with open(config_path, encoding='utf-8') as f:
                config = yaml.safe_load(f) or {}
        except (OSError, yaml.YAMLError):
            pass

    # Update display.breadcrumbs
    config.setdefault('display', {})['breadcrumbs'] = False

    # Write back
    try:
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.dump(config, f, default_flow_style=False)
        print(f"Breadcrumbs disabled in {config_path}")
        return True
    except Exception as e:
        print(f"Failed to update config: {e}", file=sys.stderr)
        return False
