"""Cross-session content search for the claude:// adapter."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from ....utils.parallel import grep_files
from .messages import _content_to_blocks, _collect_block_matches


def _extract_first_snippet(jsonl_path: Path, term: str, *, whole_word: bool = False) -> Dict[str, Any]:
    """Scan a JSONL file line-by-line and return the first matching excerpt.

    Parses every valid JSON line to maintain an accurate ``message_index`` that
    matches what ``reveal claude://session/NAME/message/N`` expects.  Returns a
    dict with ``excerpt``, ``role``, ``timestamp``, and ``message_index``.
    Falls back to empty strings / ``None`` on any error so a missing snippet
    never breaks the search result.

    Args:
        jsonl_path: Path to the session ``.jsonl`` file.
        term: Search term (case-insensitive).
        whole_word: If True, only match whole words (word-boundary semantics).

    Returns:
        Dict with keys ``excerpt``, ``role``, ``timestamp``, ``message_index``.
        ``message_index`` is ``None`` when no match is found.
    """
    lower = term.lower()
    message_index = 0
    try:
        with open(jsonl_path, encoding='utf-8', errors='replace') as fh:
            for raw_line in fh:
                line = raw_line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    continue
                role = msg.get('type', '')
                if role in ('user', 'assistant') and lower in line.lower():
                    content = msg.get('message', {}).get('content', [])
                    blocks = _content_to_blocks(content)
                    ts = (msg.get('timestamp') or '')[:16].replace('T', ' ')
                    matches = _collect_block_matches(blocks, lower, term, message_index, role, ts, whole_word=whole_word)
                    if matches:
                        return {
                            'excerpt': matches[0].get('excerpt', ''),
                            'role': role,
                            'timestamp': ts,
                            'message_index': message_index,
                        }
                message_index += 1
    except Exception:  # noqa: BLE001 — file read errors must never surface in search results
        pass
    return {'excerpt': '', 'role': '', 'timestamp': '', 'message_index': None}


def search_sessions_for_term(
    sessions: List[Dict[str, Any]],
    term: str,
    *,
    workers: int = 8,
    whole_word: bool = False,
) -> List[Dict[str, Any]]:
    """Search across multiple sessions for a term and return one snippet per match.

    Uses a two-phase approach:

    * **Phase 1** — ``grep_files()`` runs a parallel byte-level pre-filter
      across all JSONL files.  Only sessions whose file contains the term bytes
      proceed to phase 2.

    * **Phase 2** — parse only the matching files line-by-line to extract one
      representative snippet per session.

    Args:
        sessions: List of session dicts (each must have ``path``, ``session``,
            ``modified``, ``project``).  Produced by
            ``_collect_sessions_from_dir``.
        term: Search term (case-insensitive substring match).
        workers: Parallel workers for phase 1.  Defaults to 8.
        whole_word: If True, only return sessions where the term appears as a
            whole word (word-boundary semantics).  Phase 1 grep is still
            substring for speed; whole-word filtering happens in phase 2.

    Returns:
        List of match dicts, sorted most-recent-first, each containing:
        ``session``, ``modified``, ``project``, ``size_kb``,
        ``readme_present``, ``excerpt``, ``role``, ``timestamp``,
        ``message_index`` (0-based index for ``claude://session/NAME/message/N``).
    """
    if not sessions or not term:
        return []

    # Build a path → session-dict index for quick lookup after grep.
    path_to_session: Dict[Path, Dict[str, Any]] = {
        Path(s['path']): s for s in sessions if s.get('path')
    }
    all_paths = list(path_to_session)

    # Phase 1: parallel byte-level pre-filter (always substring — fast).
    matching_paths = grep_files(all_paths, term, workers=workers)

    # Phase 2: extract one snippet per matching session.
    # With whole_word=True, sessions that only contain the term as a substring
    # (e.g. "ict" inside "picture") are filtered out here.
    results = []
    for path in matching_paths:
        session = path_to_session[path]
        snippet = _extract_first_snippet(path, term, whole_word=whole_word)
        if whole_word and not snippet['excerpt']:
            continue  # no word-boundary match found in this session
        results.append({
            'session':       session['session'],
            'modified':      session['modified'],
            'project':       session.get('project', ''),
            'size_kb':       session.get('size_kb', 0),
            'readme_present': session.get('readme_present', False),
            'excerpt':       snippet['excerpt'],
            'role':          snippet['role'],
            'timestamp':     snippet['timestamp'],
            'message_index': snippet.get('message_index'),
        })

    results.sort(key=lambda x: x['modified'], reverse=True)
    return results
