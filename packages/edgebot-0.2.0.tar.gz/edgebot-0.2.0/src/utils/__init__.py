"""
Общие утилиты EdgeBot SDK.

Здесь живут маленькие зависимости-лёгкие хелперы без привязки к Pyodide/js.
Всё, что требует JS-рантайма Cloudflare Workers (fetch, sleep и т.п.),
вынесено в подмодуль edgebot.utils.http.
"""

from datetime import datetime, timezone


def now() -> str:
    """
    Текущее UTC-время в ISO-8601 с суффиксом Z (точность до секунд).

    Returns:
        Строка вида "2026-04-20T12:34:56Z".
    """
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


__all__ = ["now"]
