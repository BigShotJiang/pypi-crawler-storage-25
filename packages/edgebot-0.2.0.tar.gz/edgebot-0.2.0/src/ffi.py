"""
Ядро JS ↔ Python мостов для Cloudflare Workers runtime (Pyodide).

Инкапсулирует работу с pyodide.ffi, чтобы остальной SDK и прикладной код
не знали про детали Pyodide и не повторяли одни и те же преобразования.
"""

from typing import Any

from js import Object  # type: ignore[attr-defined]
from pyodide.ffi import to_js as _to_js  # type: ignore[attr-defined]


def to_js_object(value: Any) -> Any:
    """
    Python dict/list -> plain JS Object/Array (рекурсивно).

    Нужно там, где Cloudflare API требует именно Object, а не Map
    (KV options, D1 bindings, R2 options, Queues body, DO stub RPC и т.д.).
    """
    return _to_js(value, dict_converter=Object.fromEntries)


def to_py(value: Any) -> Any:
    """
    Универсальный JsProxy -> Python.

    - None-safe: возвращает None для None.
    - Возвращает value как есть, если это уже Python-значение.
    """
    if value is None:
        return None
    convert = getattr(value, "to_py", None)
    return convert() if callable(convert) else value
