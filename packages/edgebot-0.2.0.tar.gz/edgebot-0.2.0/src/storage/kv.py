"""
Тонкая обёртка над Cloudflare KV-биндингом.

Убирает ручные json.dumps / json.loads / to_js / .to_py на стороне прикладного кода.
Ничего не знает про домен бота — только KV-операции.
"""

from json import dumps, loads, JSONDecodeError
from typing import Any, Optional, NamedTuple, AsyncIterator

from ..ffi import to_js_object, to_py
from .exceptions import KVError


class KVKey(NamedTuple):
    """
    Элемент результата list().

    Attributes:
        name: полное имя ключа (включая префикс).
        expiration: unix-время истечения TTL в секундах или None.
        metadata: прикладные метаданные ключа или None.
    """
    name: str
    expiration: Optional[int]
    metadata: Optional[dict]


class KVListResult(NamedTuple):
    """
    Результат одной страницы list().

    Attributes:
        keys: ключи текущей страницы.
        cursor: курсор для следующей страницы или None.
        list_complete: True, если больше страниц нет.
    """
    keys: list[KVKey]
    cursor: Optional[str]
    list_complete: bool


class KVStore:
    """
    Универсальная обёртка над KV-биндингом.

    get/put сами решают по типу:
      put:  bytes -> как есть; str -> как есть; всё остальное -> json.dumps
      get:  None если нет ключа; dict/list если value — JSON-объект/массив;
            иначе str.
    """

    def __init__(self, kv: Any):
        """
        Обернуть KV-биндинг из env Cloudflare Workers.

        Args:
            kv: объект KV-неймспейса из env (например, env.USERS).
        """
        self._kv = kv

    @staticmethod
    def decode(raw: Optional[str]) -> Any:
        """
        Сырое значение из KV -> Python.

        Парсит JSON только если строка выглядит как полный JSON-объект/массив:
        обрамлена парой {...} или [...] (с учётом пробелов по краям). Это
        защищает от случайных попыток парсить произвольные строки, которые
        начинаются с { или [, но JSON-ом не являются.

        Args:
            raw: сырое строковое значение из KV или None.

        Returns:
            None если raw=None; dict/list при валидном JSON-объекте/массиве;
            иначе исходная строка.
        """
        if raw is None:
            return None
        stripped = raw.strip()
        looks_like_json = (
            (stripped.startswith("{") and stripped.endswith("}"))
            or (stripped.startswith("[") and stripped.endswith("]"))
        )
        if looks_like_json:
            try:
                return loads(raw)
            except JSONDecodeError:
                return raw
        return raw

    @staticmethod
    def encode(value: Any) -> Any:
        """
        Python-значение -> форма, пригодная для KV.put.

        Правила:
          bytes/bytearray/memoryview -> Uint8Array;
          str                        -> как есть;
          остальное                  -> json.dumps.

        Args:
            value: произвольное Python-значение.

        Returns:
            Значение в формате, принимаемом KV.put.
        """
        if isinstance(value, (bytes, bytearray, memoryview)):
            return to_js_object(bytes(value))
        if isinstance(value, str):
            return value
        return dumps(value)

    async def get(self, key: str) -> Any:
        """
        Прочитать значение по ключу.

        Args:
            key: ключ.

        Returns:
            Декодированное значение (см. KVStore.decode) или None, если ключа нет.

        Raises:
            KVError: при ошибке обращения к KV.
        """
        try:
            raw = await self._kv.get(key)
            return self.decode(raw)
        except Exception as e:
            raise KVError(f"KV get failed for key={key!r}: {e}") from e

    async def get_with_metadata(
        self, key: str,
    ) -> tuple[Any, Optional[dict]]:
        """
        Прочитать значение вместе с метаданными.

        Args:
            key: ключ.

        Returns:
            Пара (value, metadata). Оба элемента могут быть None,
            если ключа нет или метаданных не было.

        Raises:
            KVError: при ошибке обращения к KV.
        """
        try:
            result = await self._kv.getWithMetadata(key)
            value = self.decode(getattr(result, "value", None))
            metadata = to_py(getattr(result, "metadata", None))
            return value, metadata
        except Exception as e:
            raise KVError(f"KV getWithMetadata failed for key={key!r}: {e}") from e

    async def exists(self, key: str) -> bool:
        """
        Проверить наличие ключа.

        Внимание: под капотом выполняет get(), т.е. читает и сам value.

        Args:
            key: ключ.

        Returns:
            True, если ключ присутствует в KV.

        Raises:
            KVError: при ошибке обращения к KV.
        """
        try:
            raw = await self._kv.get(key)
            return raw is not None
        except Exception as e:
            raise KVError(f"KV exists failed for key={key!r}: {e}") from e

    async def put(
        self,
        key: str,
        value: Any,
        *,
        ttl: Optional[int] = None,
        metadata: Optional[dict] = None,
    ) -> None:
        """
        Записать значение по ключу.

        Args:
            key: ключ.
            value: значение, сериализуется через KVStore.encode.
            ttl: время жизни в секундах; None — хранить вечно.
            metadata: небольшие метаданные ключа, возвращаются в list()
                без чтения value.

        Raises:
            KVError: при ошибке обращения к KV.
        """
        try:
            js_value = self.encode(value)
            options: dict[str, Any] = {}
            if ttl is not None:
                options["expirationTtl"] = ttl
            if metadata is not None:
                options["metadata"] = metadata
            if not options:
                await self._kv.put(key, js_value)
            else:
                await self._kv.put(key, js_value, options)
        except Exception as e:
            raise KVError(f"KV put failed for key={key!r}: {e}") from e

    async def delete(self, key: str) -> None:
        """
        Удалить ключ. Идемпотентно: не падает, если ключа не было.

        Args:
            key: ключ.

        Raises:
            KVError: при ошибке обращения к KV.
        """
        try:
            await self._kv.delete(key)
        except Exception as e:
            raise KVError(f"KV delete failed for key={key!r}: {e}") from e

    async def list(
        self,
        *,
        prefix: Optional[str] = None,
        limit: int = 1000,
        cursor: Optional[str] = None,
    ) -> KVListResult:
        """
        Перечислить одну страницу ключей (без чтения значений).

        Args:
            prefix: вернуть только ключи с этим префиксом.
            limit: максимум ключей на страницу (KV ограничивает сверху).
            cursor: курсор продолжения от предыдущей страницы.

        Returns:
            KVListResult со списком ключей и курсором на следующую страницу.

        Raises:
            KVError: при ошибке обращения к KV.
        """
        try:
            options: dict[str, Any] = {"limit": limit}
            if prefix is not None:
                options["prefix"] = prefix
            if cursor is not None:
                options["cursor"] = cursor

            res = await self._kv.list(to_js_object(options))
            keys: list[KVKey] = []
            for k in res.keys:
                metadata = to_py(getattr(k, "metadata", None))
                expiration = getattr(k, "expiration", None)
                keys.append(KVKey(name=k.name, expiration=expiration, metadata=metadata))

            return KVListResult(
                keys=keys,
                cursor=getattr(res, "cursor", None),
                list_complete=bool(getattr(res, "list_complete", True)),
            )
        except Exception as e:
            raise KVError(f"KV list failed (prefix={prefix!r}): {e}") from e

    async def iter_keys(
        self,
        *,
        prefix: Optional[str] = None,
        cursor: Optional[str] = None,
        batch: int = 1000,
    ) -> AsyncIterator[KVKey]:
        """
        Асинхронно итерировать ключи, автоматически листая страницы.

        Args:
            prefix: вернуть только ключи с этим префиксом.
            cursor: опциональный стартовый курсор (продолжение с сохранённой позиции).
            batch: размер одной страницы (limit в list()).

        Yields:
            KVKey по одному, пока страницы не закончатся.

        Raises:
            KVError: при ошибке обращения к KV.
        """
        while True:
            page = await self.list(prefix=prefix, limit=batch, cursor=cursor)
            for key in page.keys:
                yield key
            if page.list_complete:
                return
            cursor = page.cursor
