"""
Слой хранилищ EdgeBot SDK.
"""

from .kv import KVStore, KVKey, KVListResult
from .users import UserRegistry
from .exceptions import (
    StorageError,
    KVError,
    UsersError,
    UserAlreadyExists,
)

__all__ = [
    "KVStore",
    "KVKey",
    "KVListResult",
    "UserRegistry",
    "StorageError",
    "KVError",
    "UsersError",
    "UserAlreadyExists",
]
