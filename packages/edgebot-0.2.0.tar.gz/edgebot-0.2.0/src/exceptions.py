"""
Базовые исключения EdgeBot SDK.

Все исключения SDK наследуются от EdgeBotError, чтобы прикладной код
мог ловить любую ошибку библиотеки одним except.
"""


class EdgeBotError(Exception):
    """Корень иерархии исключений EdgeBot SDK."""
