"""
EdgeBot - SDK для создания Telegram ботов на Cloudflare Workers
"""

__version__ = "0.2.0"

from .bot import Bot
from .context import Context
from .keyboard import InlineKeyboard
from .utils.http import sleep
from .ffi import to_js_object, to_py
from .exceptions import EdgeBotError
from .storage import (
    KVStore,
    KVKey,
    KVListResult,
    UserRegistry,
    StorageError,
    KVError,
    UsersError,
    UserAlreadyExists,
)

__all__ = [
    "Bot",
    "Context",
    "InlineKeyboard",
    "sleep",
    "to_js_object",
    "to_py",
    "__version__",
    "EdgeBotError",
    "KVStore",
    "KVKey",
    "KVListResult",
    "UserRegistry",
    "StorageError",
    "KVError",
    "UsersError",
    "UserAlreadyExists",
]
