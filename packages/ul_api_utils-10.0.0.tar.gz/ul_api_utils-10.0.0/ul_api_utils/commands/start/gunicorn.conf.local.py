import gc
from typing import Any

from ul_py_tool.utils.write_stdout import write_stdout

try:
    import gevent.monkey  # type: ignore
    _gevent_available = True
except ImportError:
    _gevent_available = False


def post_fork(server: Any, worker: Any) -> None:
    """
    Called just after a worker has been forked.
    Applies gevent monkey-patching so that all stdlib I/O is cooperative
    from the very start of the worker process (local / debug mode).
    https://docs.gunicorn.org/en/20.1.0/settings.html?highlight=preload#post-fork
    """
    if _gevent_available and not gevent.monkey.is_module_patched('os'):
        gevent.monkey.patch_all()
        write_stdout("gevent monkey-patching applied for worker", worker.pid)
    write_stdout("Enabling GC for worker", worker.pid)
    gc.enable()


def post_worker_init(worker: Any) -> None:
    """
    Called just after a worker has been initialized (inside the worker process).
    Patches psycopg2 to use a gevent-friendly wait callback so that database I/O
    through libpq (C extension) yields to the gevent event loop instead of blocking.
    https://docs.gunicorn.org/en/stable/settings.html#post-worker-init
    """
    if _gevent_available and gevent.monkey.is_module_patched('socket'):
        try:
            from psycogreen.gevent import patch_psycopg  # type: ignore
            patch_psycopg()
            write_stdout("psycogreen patch applied for worker", worker.pid)
        except ImportError:
            pass
