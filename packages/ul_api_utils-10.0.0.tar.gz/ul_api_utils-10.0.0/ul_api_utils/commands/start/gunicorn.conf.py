import gc
from typing import Any

from ul_py_tool.utils.write_stdout import write_stdout

try:
    import gevent.monkey  # type: ignore
    _gevent_available = True
except ImportError:
    _gevent_available = False


def when_ready(server: Any) -> None:
    """
    Use only with --preload option.
    Called just after the server is started.
    Freeze garbage collector objects after preloading the application.
    https://docs.gunicorn.org/en/20.1.0/settings.html?highlight=preload#when-ready
    """
    gc.freeze()
    write_stdout("Objects frozen in permanent generation: ", gc.get_freeze_count())


def post_fork(server: Any, worker: Any) -> None:
    """
    Works only with --preload.
    Called just after a worker has been forked.
    Enable garbage collection on each worker if it's not enabled for some reason.
    Also applies gevent monkey-patching when using a gevent-based worker class so
    that all stdlib I/O is cooperative from the very start of the worker process.
    https://docs.gunicorn.org/en/20.1.0/settings.html?highlight=preload#post-fork
    """
    if _gevent_available and not gevent.monkey.is_module_patched('os'):
        gevent.monkey.patch_all()
        write_stdout("gevent monkey-patching applied for worker", worker.pid)
    write_stdout("Enabling GC for worker", worker.pid)
    gc.enable()


def post_worker_init(worker: Any) -> None:
    """
    Called just after a worker has been initialized (inside the worker process).
    Patches psycopg2 to use a gevent-friendly wait callback so that database I/O
    through libpq (C extension) yields to the gevent event loop instead of blocking.
    https://docs.gunicorn.org/en/stable/settings.html#post-worker-init
    """
    if _gevent_available and gevent.monkey.is_module_patched('socket'):
        try:
            from psycogreen.gevent import patch_psycopg  # type: ignore
            patch_psycopg()
            write_stdout("psycogreen patch applied for worker", worker.pid)
        except ImportError:
            pass
