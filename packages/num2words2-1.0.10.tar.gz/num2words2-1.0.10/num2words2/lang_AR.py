# -*- coding: utf-8 -*-
# Copyright (c) 2003, Taro Ogawa.  All Rights Reserved.
# Copyright (c) 2013, Savoir-faire Linux inc.  All Rights Reserved.
# Copyright (c) 2018, Abdullah Alhazmy, Alhazmy13.  All Rights Reserved.


# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# Lesser General Public License for more details.
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301 USA

import decimal
import math
import re
from decimal import Decimal
from math import floor

from .base import Num2Word_Base

CURRENCY_SR = [
    ("ريال", "ريالان", "ريالات", "ريالاً"),
    ("هللة", "هللتان", "هللات", "هللة"),
]
CURRENCY_EGP = [("جنيه", "جنيهان", "جنيهات", "جنيهاً"), ("قرش", "قرشان", "قروش", "قرش")]
CURRENCY_KWD = [
    ("دينار", "ديناران", "دينارات", "ديناراً"),
    ("فلس", "فلسان", "فلس", "فلس"),
]
CURRENCY_LBP = [
    ("ليرة", "ليرتان", "ليرات", "ليرة"),
    ("قرش", "قرشان", "قروش", "قرش"),
]
CURRENCY_YER = [
    ("ريال", "ريالان", "ريالات", "ريالاً"),
    ("فلس", "فلسان", "فلس", "فلس"),
]
CURRENCY_USD = [
    ("دولار", "دولارين", "دولارات", "دولاراً"),
    ("سنت", "سنتان", "سنتا", "سنتاٌ"),
]
CURRENCY_TND = [
    ("دينار", "ديناران", "دينارات", "ديناراً"),
    ("مليماً", "ميلمان", "مليمات", "مليم"),
]

ARABIC_ONES = [
    "",
    "واحد",
    "اثنان",
    "ثلاثة",
    "أربعة",
    "خمسة",
    "ستة",
    "سبعة",
    "ثمانية",
    "تسعة",
    "عشرة",
    "أحد عشر",
    "اثنا عشر",
    "ثلاثة عشر",
    "أربعة عشر",
    "خمسة عشر",
    "ستة عشر",
    "سبعة عشر",
    "ثمانية عشر",
    "تسعة عشر",
]


class Num2Word_AR(Num2Word_Base):
    errmsg_toobig = "abs(%s) must be less than %s."
    MAXVAL = 10**51

    def __init__(self):
        super().__init__()

        self.number = 0
        self.arabicPrefixText = ""
        self.arabicSuffixText = ""
        self.integer_value = 0
        self._decimalValue = ""
        self.partPrecision = 2
        self.currency_unit = CURRENCY_SR[0]
        self.currency_subunit = CURRENCY_SR[1]
        self.isCurrencyPartNameFeminine = True
        self.isCurrencyNameFeminine = False
        self.separator = "و"

        self.arabicOnes = ARABIC_ONES
        self.arabicFeminineOnes = [
            "",
            "إحدى",
            "اثنتان",
            "ثلاث",
            "أربع",
            "خمس",
            "ست",
            "سبع",
            "ثمان",
            "تسع",
            "عشر",
            "إحدى عشرة",
            "اثنتا عشرة",
            "ثلاث عشرة",
            "أربع عشرة",
            "خمس عشرة",
            "ست عشرة",
            "سبع عشرة",
            "ثماني عشرة",
            "تسع عشرة",
        ]
        self.arabicOrdinal = [
            "",
            "اول",
            "ثاني",
            "ثالث",
            "رابع",
            "خامس",
            "سادس",
            "سابع",
            "ثامن",
            "تاسع",
            "عاشر",
            "حادي عشر",
            "ثاني عشر",
            "ثالث عشر",
            "رابع عشر",
            "خامس عشر",
            "سادس عشر",
            "سابع عشر",
            "ثامن عشر",
            "تاسع عشر",
        ]
        self.arabicTens = [
            "عشرون",
            "ثلاثون",
            "أربعون",
            "خمسون",
            "ستون",
            "سبعون",
            "ثمانون",
            "تسعون",
        ]
        self.arabicHundreds = [
            "",
            "مائة",
            "مئتان",
            "ثلاثمائة",
            "أربعمائة",
            "خمسمائة",
            "ستمائة",
            "سبعمائة",
            "ثمانمائة",
            "تسعمائة",
        ]

        self.arabicAppendedTwos = [
            "مئتا",
            "ألفا",
            "مليونا",
            "مليارا",
            "تريليونا",
            "كوادريليونا",
            "كوينتليونا",
            "سكستيليونا",
            "سبتيليونا",
            "أوكتيليونا ",
            "نونيليونا",
            "ديسيليونا",
            "أندسيليونا",
            "دوديسيليونا",
            "تريديسيليونا",
            "كوادريسيليونا",
            "كوينتينيليونا",
        ]
        self.arabicTwos = [
            "مئتان",
            "ألفان",
            "مليونان",
            "ملياران",
            "تريليونان",
            "كوادريليونان",
            "كوينتليونان",
            "سكستيليونان",
            "سبتيليونان",
            "أوكتيليونان ",
            "نونيليونان ",
            "ديسيليونان",
            "أندسيليونان",
            "دوديسيليونان",
            "تريديسيليونان",
            "كوادريسيليونان",
            "كوينتينيليونان",
        ]
        self.arabicGroup = [
            "مائة",
            "ألف",
            "مليون",
            "مليار",
            "تريليون",
            "كوادريليون",
            "كوينتليون",
            "سكستيليون",
            "سبتيليون",
            "أوكتيليون",
            "نونيليون",
            "ديسيليون",
            "أندسيليون",
            "دوديسيليون",
            "تريديسيليون",
            "كوادريسيليون",
            "كوينتينيليون",
        ]
        self.arabicAppendedGroup = [
            "",
            "ألفاً",
            "مليوناً",
            "ملياراً",
            "تريليوناً",
            "كوادريليوناً",
            "كوينتليوناً",
            "سكستيليوناً",
            "سبتيليوناً",
            "أوكتيليوناً",
            "نونيليوناً",
            "ديسيليوناً",
            "أندسيليوناً",
            "دوديسيليوناً",
            "تريديسيليوناً",
            "كوادريسيليوناً",
            "كوينتينيليوناً",
        ]
        self.arabicPluralGroups = [
            "",
            "آلاف",
            "ملايين",
            "مليارات",
            "تريليونات",
            "كوادريليونات",
            "كوينتليونات",
            "سكستيليونات",
            "سبتيليونات",
            "أوكتيليونات",
            "نونيليونات",
            "ديسيليونات",
            "أندسيليونات",
            "دوديسيليونات",
            "تريديسيليونات",
            "كوادريسيليونات",
            "كوينتينيليونات",
        ]
        assert len(self.arabicAppendedGroup) == len(self.arabicGroup)
        assert len(self.arabicPluralGroups) == len(self.arabicGroup)
        assert len(self.arabicAppendedTwos) == len(self.arabicTwos)

    def number_to_arabic(self, arabic_prefix_text, arabic_suffix_text):
        self.arabicPrefixText = arabic_prefix_text
        self.arabicSuffixText = arabic_suffix_text
        self.extract_integer_and_decimal_parts()

    def extract_integer_and_decimal_parts(self):
        splits = re.split("\\.", str(self.number))

        self.integer_value = int(splits[0])
        if len(splits) > 1:
            self._decimalValue = int(self.decimal_value(splits[1]))
        else:
            self._decimalValue = 0

    def decimal_value(self, decimal_part):
        if self.partPrecision is not len(decimal_part):
            decimal_part_length = len(decimal_part)

            decimal_part_builder = decimal_part
            for i in range(0, self.partPrecision - decimal_part_length):
                decimal_part_builder += "0"
            decimal_part = decimal_part_builder

            if len(decimal_part) <= self.partPrecision:
                dec = len(decimal_part)
            else:
                dec = self.partPrecision
            result = decimal_part[0:dec]
        else:
            result = decimal_part

        # The following is useless (never happens)
        # for i in range(len(result), self.partPrecision):
        #     result += '0'
        return result

    def digit_feminine_status(self, digit, group_level):
        if group_level == -1:
            if self.isCurrencyPartNameFeminine:
                return self.arabicFeminineOnes[int(digit)]
            else:
                # Note: this never happens
                return self.arabicOnes[int(digit)]
        elif group_level == 0:
            if self.isCurrencyNameFeminine:
                return self.arabicFeminineOnes[int(digit)]
            else:
                return self.arabicOnes[int(digit)]
        else:
            return self.arabicOnes[int(digit)]

    def process_arabic_group(self, group_number, group_level, remaining_number):
        tens = Decimal(group_number) % Decimal(100)
        hundreds = Decimal(group_number) / Decimal(100)
        ret_val = ""

        if int(hundreds) > 0:
            if tens == 0 and int(hundreds) == 2:
                ret_val = "{}".format(self.arabicAppendedTwos[0])
            else:
                ret_val = "{}".format(self.arabicHundreds[int(hundreds)])
                if ret_val != "" and tens != 0:
                    ret_val += " و"

        if tens > 0:
            if tens < 20:
                # if int(group_level) >= len(self.arabicTwos):
                #     raise OverflowError(self.errmsg_toobig %
                #                         (self.number, self.MAXVAL))
                assert int(group_level) < len(self.arabicTwos)
                if tens == 2 and int(hundreds) == 0 and group_level > 0:
                    pow = int(math.log10(self.integer_value))
                    if (
                        self.integer_value > 10
                        and pow % 3 == 0
                        and self.integer_value == 2 * (10**pow)
                    ):
                        ret_val = "{}".format(self.arabicAppendedTwos[int(group_level)])
                    else:
                        ret_val = "{}".format(self.arabicTwos[int(group_level)])
                else:
                    if tens == 1 and group_level > 0 and hundreds == 0:
                        # Note: this never happens
                        # (hundreds == 0 only if group_number is 0)
                        ret_val += ""
                    elif (
                        (tens == 1 or tens == 2)
                        and (group_level == 0 or group_level == -1)
                        and hundreds == 0
                        and remaining_number == 0
                    ):
                        # Note: this never happens (idem)
                        ret_val += ""
                    elif tens == 1 and group_level > 0:
                        ret_val += self.arabicGroup[int(group_level)]
                    else:
                        ret_val += self.digit_feminine_status(int(tens), group_level)
            else:
                ones = tens % 10
                tens = (tens / 10) - 2
                if ones > 0:
                    ret_val += self.digit_feminine_status(ones, group_level)
                if ret_val != "" and ones != 0:
                    ret_val += " و"

                ret_val += self.arabicTens[int(tens)]

        return ret_val

    # We use this instead of built-in `abs` function,
    # because `abs` suffers from loss of precision for big numbers
    def abs(self, number):
        return number if number >= 0 else -number

    # We use this instead of `"{:09d}".format(number)`,
    # because the string conversion suffers from loss of
    # precision for big numbers
    def to_str(self, number):
        integer = int(number)
        if integer == number:
            return str(integer)
        decimal = round((number - integer) * 10**9)
        return str(integer) + "." + "{:09d}".format(decimal).rstrip("0")

    def convert(self, value):
        self.number = self.to_str(value)
        self.number_to_arabic(self.arabicPrefixText, self.arabicSuffixText)
        return self.convert_to_arabic()

    def convert_to_arabic(self):
        temp_number = Decimal(self.number)

        if temp_number == Decimal(0):
            return "صفر"

        decimal_string = self.process_arabic_group(self._decimalValue, -1, Decimal(0))
        ret_val = ""
        group = 0

        while temp_number > Decimal(0):
            temp_number_dec = Decimal(str(temp_number))
            try:
                number_to_process = int(temp_number_dec % Decimal(str(1000)))
            except decimal.InvalidOperation:
                decimal.getcontext().prec = len(temp_number_dec.as_tuple().digits)
                number_to_process = int(temp_number_dec % Decimal(str(1000)))

            temp_number = int(temp_number_dec / Decimal(1000))

            group_description = self.process_arabic_group(
                number_to_process, group, Decimal(floor(temp_number))
            )
            if group_description != "":
                if group > 0:
                    if ret_val != "":
                        ret_val = "و{}".format(ret_val)
                    if number_to_process != 2 and number_to_process != 1:
                        # if group >= len(self.arabicGroup):
                        #     raise OverflowError(self.errmsg_toobig %
                        #                         (self.number, self.MAXVAL)
                        #     )
                        assert group < len(self.arabicGroup)
                        if number_to_process % 100 != 1:
                            if 3 <= number_to_process <= 10:
                                ret_val = "{} {}".format(
                                    self.arabicPluralGroups[group], ret_val
                                )
                            else:
                                if ret_val != "":
                                    ret_val = "{} {}".format(
                                        self.arabicAppendedGroup[group], ret_val
                                    )
                                else:
                                    ret_val = "{} {}".format(
                                        self.arabicGroup[group], ret_val
                                    )

                        else:
                            ret_val = "{} {}".format(self.arabicGroup[group], ret_val)
                ret_val = "{} {}".format(group_description, ret_val)
            group += 1
        formatted_number = ""
        if self.arabicPrefixText != "":
            formatted_number += "{} ".format(self.arabicPrefixText)
        formatted_number += ret_val
        if self.integer_value != 0:
            remaining100 = int(self.integer_value % 100)

            if remaining100 == 0:
                formatted_number += self.currency_unit[0]
            elif remaining100 == 1:
                formatted_number += self.currency_unit[0]
            elif remaining100 == 2:
                if self.integer_value == 2:
                    formatted_number += self.currency_unit[1]
                else:
                    formatted_number += self.currency_unit[0]
            elif 3 <= remaining100 <= 10:
                formatted_number += self.currency_unit[2]
            elif 11 <= remaining100 <= 99:
                formatted_number += self.currency_unit[3]
        if self._decimalValue != 0:
            # Trim any trailing whitespace before injecting the separator,
            # otherwise we get double spaces in the join. Issue #53 ports
            # savoirfairelinux/num2words#265.
            formatted_number = formatted_number.rstrip()
            if self.separator == "و":
                formatted_number += " و"
            else:
                formatted_number += " {} ".format(self.separator)
            formatted_number += decimal_string

        if self._decimalValue != 0:
            formatted_number += " "
            remaining100 = int(self._decimalValue % 100)

            if remaining100 == 0:
                formatted_number += self.currency_subunit[0]
            elif remaining100 == 1:
                formatted_number += self.currency_subunit[0]
            elif remaining100 == 2:
                formatted_number += self.currency_subunit[1]
            elif 3 <= remaining100 <= 10:
                formatted_number += self.currency_subunit[2]
            elif 11 <= remaining100 <= 99:
                formatted_number += self.currency_subunit[3]

        if self.arabicSuffixText != "":
            formatted_number += " {}".format(self.arabicSuffixText)

        return formatted_number

    def validate_number(self, number):
        if number >= self.MAXVAL:
            raise OverflowError(self.errmsg_toobig % (number, self.MAXVAL))
        return number

    def set_currency_prefer(self, currency):
        if currency == "TND":
            self.currency_unit = CURRENCY_TND[0]
            self.currency_subunit = CURRENCY_TND[1]
            self.partPrecision = 3
        elif currency == "EGP":
            self.currency_unit = CURRENCY_EGP[0]
            self.currency_subunit = CURRENCY_EGP[1]
            self.partPrecision = 2
        elif currency == "KWD":
            self.currency_unit = CURRENCY_KWD[0]
            self.currency_subunit = CURRENCY_KWD[1]
            self.partPrecision = 2
        elif currency == "LBP":
            self.currency_unit = CURRENCY_LBP[0]
            self.currency_subunit = CURRENCY_LBP[1]
            self.partPrecision = 2
        elif currency == "YER":
            self.currency_unit = CURRENCY_YER[0]
            self.currency_subunit = CURRENCY_YER[1]
            self.partPrecision = 2
        elif currency == "USD":
            self.currency_unit = CURRENCY_USD[0]
            self.currency_subunit = CURRENCY_USD[1]
            self.partPrecision = 2
        else:
            self.currency_unit = CURRENCY_SR[0]
            self.currency_subunit = CURRENCY_SR[1]
            self.partPrecision = 2

    # Definite-article ordinal forms for 1-19 with masculine/feminine pairs.
    # Issue #54 ports savoirfairelinux/num2words#403.
    _AR_ORDINALS_DEF = {
        1: ("الأول", "الأولى"),
        2: ("الثاني", "الثانية"),
        3: ("الثالث", "الثالثة"),
        4: ("الرابع", "الرابعة"),
        5: ("الخامس", "الخامسة"),
        6: ("السادس", "السادسة"),
        7: ("السابع", "السابعة"),
        8: ("الثامن", "الثامنة"),
        9: ("التاسع", "التاسعة"),
        10: ("العاشر", "العاشرة"),
        11: ("الحادي عشر", "الحادية عشرة"),
        12: ("الثاني عشر", "الثانية عشرة"),
        13: ("الثالث عشر", "الثالثة عشرة"),
        14: ("الرابع عشر", "الرابعة عشرة"),
        15: ("الخامس عشر", "الخامسة عشرة"),
        16: ("السادس عشر", "السادسة عشرة"),
        17: ("السابع عشر", "السابعة عشرة"),
        18: ("الثامن عشر", "الثامنة عشرة"),
        19: ("التاسع عشر", "التاسعة عشرة"),
    }
    _AR_TENS_DEF = {
        20: "العشرون",
        30: "الثلاثون",
        40: "الأربعون",
        50: "الخمسون",
        60: "الستون",
        70: "السبعون",
        80: "الثمانون",
        90: "التسعون",
    }
    _AR_HUNDREDS_DEF = {
        100: "المائة",
        200: "المئتان",
        300: "الثلاثمائة",
        400: "الأربعمائة",
        500: "الخمسمائة",
        600: "الستمائة",
        700: "السبعمائة",
        800: "الثمانمائة",
        900: "التسعمائة",
    }
    _AR_AFTER_HUNDRED = {
        100: "بعد المائة",
        200: "بعد المئتين",
        300: "بعد الثلاثمائة",
        400: "بعد الأربعمائة",
        500: "بعد الخمسمائة",
        600: "بعد الستمائة",
        700: "بعد السبعمائة",
        800: "بعد الثمانمائة",
        900: "بعد التسعمائة",
    }

    def to_ordinal(self, number, gender="m", prefix=""):
        """Return the Arabic ordinal form of ``number``.

        ``gender`` is "m" (masculine, default) or "f" (feminine). For values
        above 999 the implementation currently falls back to the cardinal
        form (the upstream issue covers 1-999 only).
        """
        number = int(number)
        gender_idx = 0 if gender == "m" else 1
        if 1 <= number <= 19:
            return self._AR_ORDINALS_DEF[number][gender_idx]
        if 20 <= number <= 99:
            tens = (number // 10) * 10
            ones = number % 10
            if ones == 0:
                return self._AR_TENS_DEF[tens]
            ones_form = self._AR_ORDINALS_DEF[ones][gender_idx]
            return "{} و{}".format(ones_form, self._AR_TENS_DEF[tens])
        if 100 <= number <= 999:
            hundreds = (number // 100) * 100
            remainder = number % 100
            if remainder == 0:
                return self._AR_HUNDREDS_DEF[hundreds]
            # ordinal-of-remainder + بعد + ال + cardinal-hundreds
            inner = self.to_ordinal(remainder, gender=gender)
            return "{} {}".format(inner, self._AR_AFTER_HUNDRED[hundreds])
        # >= 1000 or 0/negative: not yet covered by the ordinal patterns,
        # fall back to the cardinal form so callers don't break.
        if number < 100:
            self.isCurrencyNameFeminine = True
        else:
            self.isCurrencyNameFeminine = False
        self.currency_subunit = ("", "", "", "")
        self.currency_unit = ("", "", "", "")
        self.arabicPrefixText = prefix
        self.arabicSuffixText = ""
        return "{}".format(self.convert(self.abs(number)).strip())

    def to_year(self, value):
        value = self.validate_number(value)
        return self.to_cardinal(value)

    def to_ordinal_num(self, value):
        return self.to_ordinal(value).strip()

    # Aliases accepted by the case= kwarg. Issue #55 ports
    # savoirfairelinux/num2words#557.
    _AR_NOMINATIVE = {"n", "nominative", "رفع", "مرفوع"}
    _AR_OBLIQUE = {  # accusative + genitive both use the ين dual ending
        "a", "accusative", "نصب", "منصوب",
        "g", "genitive", "جر", "مجرور",
        "o", "oblique",
    }
    # Dual-noun endings that switch between nominative (ان) and oblique (ين).
    # Order matters: longer-stem matches must come first so we don't
    # accidentally rewrite a substring of a larger word.
    _AR_DUAL_NOMINATIVE_TO_OBLIQUE = [
        ("كوادريليونان", "كوادريليونين"),
        ("تريليونان", "تريليونين"),
        ("مليونان", "مليونين"),
        ("ملياران", "مليارين"),
        ("ألفان", "ألفين"),
        ("مئتان", "مئتين"),
    ]
    # When the entire output IS the construct form (no following counted
    # noun), normalize to the independent form for the requested case.
    _AR_STANDALONE_DUAL = {
        "مئتا": ("مئتان", "مئتين"),
        "ألفا": ("ألفان", "ألفين"),
        "مليونا": ("مليونان", "مليونين"),
        "مليارا": ("ملياران", "مليارين"),
        "تريليونا": ("تريليونان", "تريليونين"),
        "كوادريليونا": ("كوادريليونان", "كوادريليونين"),
    }

    def to_cardinal(self, number, case="nominative"):
        self.isCurrencyNameFeminine = False
        number = self.validate_number(number)
        minus = ""
        if number < 0:
            minus = "سالب "
        # Arabic uses an Arabic comma U+060C, not a Latin one. Issue #53
        # ports savoirfairelinux/num2words#265.
        self.separator = "،"
        self.currency_subunit = ("", "", "", "")
        self.currency_unit = ("", "", "", "")
        self.arabicPrefixText = ""
        self.arabicSuffixText = ""
        self.arabicOnes = ARABIC_ONES
        self.partPrecision = 2
        out = minus + self.convert(value=self.abs(number)).strip()
        # Decide which dual ending to apply.
        is_oblique = isinstance(case, str) and case.lower() in self._AR_OBLIQUE
        # Standalone (construct) form: number is exactly مئتا / ألفا / مليونا /
        # مليارا / تريليونا / كوادريليونا — switch to the independent form.
        bare = out.lstrip(minus).strip()
        if bare in self._AR_STANDALONE_DUAL:
            nom, obl = self._AR_STANDALONE_DUAL[bare]
            out = (minus + (obl if is_oblique else nom)).strip()
            return out
        # Compound forms (e.g. 205 → مئتان وخمسة): switch ان → ين if oblique.
        if is_oblique:
            for nom, obl in self._AR_DUAL_NOMINATIVE_TO_OBLIQUE:
                out = out.replace(nom, obl)
        return out

    def to_currency(self, n, currency="SR", cents=True, separator=",", adjective=False):
        # Arabic has a special currency implementation
        # Set the currency preference based on the currency code
        self.set_currency_prefer(currency)

        # Reset settings for currency mode
        self.isCurrencyNameFeminine = False
        self.arabicPrefixText = ""
        self.arabicSuffixText = ""
        self.separator = "و"

        # Validate and handle negative numbers
        n = self.validate_number(n)
        minus = ""
        if n < 0:
            minus = "سالب "
            n = -n

        # Convert and return
        result = self.convert(value=n)
        if minus:
            # Need to prepend minus to the result
            return minus + result
        return result
