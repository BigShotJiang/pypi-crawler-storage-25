# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

No unreleased changes.

## [1.2.6] — 2026-05-24

### Changed

- Finalized the style/layout API cleanup around the canonical
  `style` / `reference` / `content` / `export` arguments.
- Renamed the faithful GeoGebra style mapping helper from the legacy adapter
  naming to `style.ggb_resolver.resolve_ggb_style()`.
- Style validation is now stricter: removed legacy top-level sections,
  removed visual aliases, `rendering.scale_export`, and unknown
  `import.policy` keys fail fast instead of being silently accepted.
- Overlay and label-placement documentation now describe the resolver-based
  style path directly.

### Removed

- Removed runtime compatibility shims for deprecated API arguments such as
  `style_file`, `px_size`, `reference_size`, and flat `export_*` kwargs on
  `loadGGB()` / `applyStyle()`.
- Removed the deprecated CLI `--debug` shortcut; use `--verbose` or
  `--log-level DEBUG`.
- Removed the `angle_gap_px` label-placement fallback in favor of explicit
  `angle_gap_arc_px` and `angle_gap_sides_px`.

### Tests

- Updated style/import-policy tests to assert the canonical API and removed
  legacy compatibility behavior.

## [1.2.5] — 2026-05-24

### Fixed

- GeoGebra XML parsing now accepts both the historical misspelling
  `euclidianView` and the correct `euclideanView` element emitted by current
  GeoGebra files.

## [1.2.4] — 2026-05-17

### Added

- Added a unified logging configuration helper and wired CLI verbosity flags
  through it.
- Added GeoGebra custom macro expansion before construction parsing.

### Fixed

- Unsupported command diagnostics are now summarized through structured
  logging instead of ad-hoc console output.

## [1.2.3] — 2026-05-15

### Added

- Imported GeoGebra axes/grid view settings are now preserved and can render as
  a quiet coordinate background layer.
- DSL `Intersect(...)` factories now accept `index=` as a semantic keyword for
  selecting a specific intersection.

### Changed

- `content.infinite_policy` now defaults to `ignore` for `rendered_bounds`;
  use `clip` explicitly to include `Line`/`Ray` bounds clipped by the current
  source camera.
- Style preset references now also accept short forms such as `color.main`,
  `line_width.main`, and `tick.main` where the preset group is unambiguous.
- Value-label precision now defaults to one decimal place and can be set via
  `rendering.label_value_precision`.
- Expanded API docs for the accepted `style`, `reference`, `content`, and
  `export` shapes, values, and defaults.
- Removed the PyPI `Development Status :: 5 - Production/Stable` classifier
  from package metadata.

### Fixed

- Automatic label placement now clips line/ray obstacles to the current scene
  bounds and uses exact segment/bbox clipping instead of dense sampling.

## [1.2.2] — 2026-05-09

### Added

- **Unified layout API** — `loadGGB()` and `applyStyle()` now accept
  `style`, `reference`, `content`, and `export` blocks. `style` can be a JSON
  path, raw style dict, or `StyleConfig`; `reference`, `content`, and `export`
  can be passed as dictionaries for structured runtime layout control.
- **Top-level style reference** — style JSON now uses
  `reference: {size: {width, height}, source}` as the authoring/reference
  canvas metadata.
- **Reference-to-export layout pipeline** — geometry/content placement on the
  reference canvas is separated from physical export placement, preserving
  authored visual scale while still supporting different output sizes.

### Changed

- Public examples, guide snippets, docs, style-guide generated sources, and
  bundled style JSON files now use the new `style` / `content` / `export`
  shape instead of legacy `style_file`, `px_size`, and flat `export_*` fields.
- Runtime export sizing is now expressed through
  `export={'size': {'width': ..., 'height': ...}}`; one side may still be
  `"auto"`.
- Rendered-bounds fitting is now configured as
  `content={'source': 'rendered_bounds', 'padding': ...}`.
- AI construction summaries now report viewport dimensions under
  `viewport.size` instead of `viewport.px_size`.

### Fixed

- `applyStyle(style=...)` now correctly passes the style path/dict into the
  legacy `GeoStyle` container while keeping `StyleConfig` as the canonical
  resolver source.
- Updated the guide render server and standalone style-guide example
  generator to emit runnable snippets with the new API.
- Migrated conics/functions helpers and all example style files away from
  obsolete public export/style fields.

### Tests

- Added and updated coverage for reference/export layout separation, style
  reference parsing, dict-based style loading, guide overlay examples, AI
  summary viewport metadata, label placement behavior, and migrated examples.

## [1.2.1] — 2026-05-08

### Added

- **Split export layout** — `loadGGB()` and `applyStyle()` now support
  `reference_size`, `export_size`, `export_fit`, `export_source_rect`,
  `export_scale`, `export_anchor`, `export_offset`,
  `export_bounds_padding`, and `export_infinite_policy`. This separates the
  style-authoring reference canvas from the physical SVG/MP4 canvas.
- **Rendered-bounds export source** — `export_source_rect='rendered_bounds'`
  measures visible finite geometry and labels before fitting content into the
  export canvas, with `clip`/`ignore` handling for infinite lines and rays.
- **CLI export-layout flags** — the `animageo` command now exposes
  `--reference-size`, `--export-size`, `--fit`, `--source-rect`,
  `--export-scale`, `--anchor`, `--offset`, `--bounds-padding`, and
  `--infinite-policy`.
- **Canvas reference metadata** — style JSON may now include
  `canvas.reference` for preview/export reference dimensions.

### Changed

- Visual `*_px` style values now resolve through `ptUnit_style` in split
  export-layout mode, so strokes, points, labels, tick marks, and angle arcs
  scale with the reference canvas when exporting to a larger physical size.
- `overlay.angle_radius` and `overlay.label_placement` are read directly from
  `StyleConfig`; they are no longer projected through `rendering`.
- Style import maps now require fully-qualified preset references such as
  `presets.color.main`, `presets.point_size.main`, and
  `presets.line_width.main`.

### Fixed

- **Keyframe playback initial state** — `AnimaGeoScene.play_keyframes()` now
  applies the first keyframe's values and `show`/`hide` visibility before
  playback starts, rebuilds geometry, and rerenders touched mobjects. MP4
  exports no longer show the saved `.ggb` editor state before the first
  keyframed motion begins.
- **Measure/AngleSize keyframe updates** — parsed keyframe values now update
  the real `.value` field for measure-like variables and mark dependents
  dirty, so downstream geometry rebuilds from the animated value.

### Removed

- Legacy style JSON migration is no longer part of runtime loading. Old
  top-level sections and legacy visual keys such as `line_width`, `font_size`,
  `ang_rdefault`, and `label_r_offset` now raise validation errors; canonical
  `*_px` fields are required.

### Tests

- Added coverage for export layout math, rendered-bounds export integration,
  CLI export options, canonical style validation, overlay automation access,
  construction-level parsed keyframe application, and scene-level
  first-keyframe state application.

## [1.2.0] — 2026-05-06

AI style-generation support release. This release adds a compact construction
summary exporter, machine-checkable style schema, and LLM prompt context for
generating style JSON plus optional loadCode-compatible DSL.

### Added

- **Compact construction summary exporter** — new
  `animageo.exporters.construction_summary` module with
  `construction_to_ai_summary(...)` and `write_ai_summary(...)`.
- **Scene-level AI summary API** —
  `AnimaGeoScene.exportStylePromptSummary(filepath=None, **kwargs)` exports
  `animageo-construction-summary/v1` as a dict or JSON file. The summary keeps
  names, canonical types, visibility, compact geometry, selected GGB style,
  construction dependencies, vars, groups, and parser diagnostics without raw
  `.ggb` XML.
- **AI style-generation context** —
  `docs/ai_style_generation_context.md` defines the style-layer model,
  resolver priority, when to use `overlay.per_type`, `overlay.per_name`,
  automation blocks, and when optional Python DSL is appropriate.
- **AI output contract** — the context now explicitly separates generated
  `STYLE_JSON`, optional `PYTHON_DSL`, and `NOTES`. `PYTHON_DSL` is limited to
  the body of a file passed to `scene.loadCode(...)`; it must not contain
  `AnimaGeoScene`, `loadGGB`, render/export calls, Manim animation code, or
  scene orchestration.
- **NOTES contract for LLM output** — the AI context now requires notes for
  ambiguity, construction-summary-based selections, overlapping geometry such
  as polygon sides vs. separate segments, DSL usage/avoidance, relative
  numeric changes, visibility changes, automation blocks, out-of-scope
  requests, and other follow-up-relevant assumptions.
- **Style JSON Schema** — `docs/ai_style_json_schema.json` provides a
  Draft 2020-12 schema for validating generated style JSON.
- **Construction summary documentation** —
  `docs/construction_summary.md` documents the
  `animageo-construction-summary/v1` format and exporter options.
- **AI style-generation fixture** — `examples/ai_style_generation_scene10/`
  contains a reproducible GeoGebra-based test setup for AI-generated style JSON
  and optional DSL, with output SVG generated into the same folder.

### Changed

- **Documentation navigation** — README, docs index, and API docs now link to
  the construction summary exporter, AI context, and style JSON schema.
- **AI guidance for layer choice** — the context now prefers `overlay.per_name`
  when a supplied construction summary is sufficient to resolve computed
  requests such as "longest segment", and reserves DSL for missing geometry or
  logic that cannot be represented by style JSON alone.
- **AI guidance for polygon-side highlights** — the context now warns that
  imported polygon outlines can duplicate side segments; highlighted sides
  should be raised above normal stroke layers or the polygon outline should be
  restyled/disabled, with the choice reported in `NOTES`.

### Fixed

- **GeoGebra `Point(Conic)` import** — points constrained to conics now keep
  their canonical curve parameter from GGB XML coordinates. This fixes scenes
  where a point on a hyperbola was imported as `data=None`, causing downstream
  `Line`, `Intersect`, `Segment`, `Distance`, `CircumcircleArc`, and `Angle`
  commands to remain unbuilt.
- **Wrapped arc containment** — `Arc.contains()` now compares point angles in
  the same unwrapped interval as the arc itself. This fixes
  `CircumcircleArc(A, M, B)` choosing the opposite side of chord `AB` when the
  intended arc crosses the `0` angle.
- **GeoGebra arc/ray intersections with Unicode labels** —
  `Intersect(Arc, Ray, index)` and `Intersect(Arc, Segment, index)` are now
  dispatchable, and command inputs such as `β` are treated as simple
  identifiers instead of being rewritten through empty phantom expressions.
- **DSL redefinition redraws dependents** — `loadCode()` and `putCode()` now
  run a final full rebuild before rerendering, so redefining an imported GGB
  element (for example `E = Rotate(...)`) updates downstream elements such as
  `Segment(B, E)` instead of drawing stale geometry.

### Tests

- Added coverage for construction summary export.

## [1.1.1] — 2026-05-01

Patch release for the resolver-based style architecture introduced in 1.1.0.
This release separates GGB import data, project overlay rules, explicit
Python/DSL edits, and construction visibility into distinct layers.

### Fixed

- **Explicit Python/DSL style priority** — `elem.style` is now reserved for
  explicit Python/DSL writes and remains the highest-priority style layer.
  `overlay.per_type` / `overlay.per_name` are no longer materialized into
  `elem.style`; the resolver reads overlay rules lazily from `StyleConfig`.
  This fixes cases like `d.style.stroke_width_px = 10` being overwritten by
  overlay during `addAllGeometry()` / `updateAllGeometry()`.
- **GGB visual import isolation** — GGB visual values are stored in
  `elem.ggb_style` and consumed by the resolver below overlay and above
  defaults. `import.enabled=false` now disables the whole visual import layer
  without clearing `elem.ggb_raw` or seeding defaults into `elem.style`.
- **Construction visibility separation** — GeoGebra `show_object` and
  `ImportPolicy.visible` are treated as geometry/construction visibility
  (`elem.visible`), not visual style. Runtime `Show` / `Hide` /
  `addAllGeometry(show=False)` stay above imported visibility.
- **Label placement resolver call** — label-placement code now consistently
  uses the imported `_resolve_style(...)` helper, preventing the
  `_resolve is not defined` crash when automatic label placement is enabled.
- **Canonical import color remapping** — `import.colors` writes canonical
  `#rrggbb` colors plus optional opacity into `elem.ggb_style`, avoiding raw
  RGB/RGBA arrays and stale-opacity edge cases.
- **Background export parity** — `rendering.background` is applied consistently
  to Manim preview/MP4 and SVG/PNG export.
- **Renderer no longer needs web-side legacy style bridge** — render paths read
  canonical `StyleConfig` defaults and resolver values directly; web clients do
  not need to add legacy `defaults.tick` / `defaults.arrow` / angle aliases.
- **GGB unsupported-command warning cascades** — GGB loading now records root
  unsupported commands in `scene.geo.command_diagnostics`, deduplicates repeats,
  and suppresses downstream `NoneType` warning cascades in non-strict mode.
- **Unicode GGB identifiers in generated expressions** — names such as `α_2`
  now resolve before command dispatch, fixing expression chains like
  `4 * (α_2 - 90°)` that previously degraded into `Sub(str, AngleSize)`.

### Changed

- **Resolver priority is explicit**:
  `elem.style → overlay.per_name → overlay.per_type → elem.ggb_style → defaults`.
- **Overlay API compatibility** — `scene.applyOverlay()` / `StyleOverlay.apply`
  remain as no-op compatibility hooks; rendering uses lazy resolver reads.
- **GGB import/adaptation coverage** — `import.point_size` now maps GGB point
  sizes to `size_px`, and `ImportPolicy` covers raw-derived fields such as
  `stroke_opacity`, `stroke_dash_ratio`, `label_text`, `angle_range`, and
  `tick_count`.
- **Legacy visual fields are input migration only** — `line_width`,
  `ang_width`, `strich_*`, `arrow_*`, `label_r_offset`, and `font_size` in
  style JSON are normalized to canonical pixel-unit keys before resolving.
  Runtime render code reads `stroke_width_px`, `tick_*_px`, `arrow_*_px`,
  `label_radial_offset_px`, and `font_size_px`.
- **Manim baseline updated** — runtime dependency now requires
  `manim>=0.20.1,<0.22`, matching the latest PyPI release tested before
  1.1.1.
- **Documentation refresh** — README, API docs, architecture docs, style guide,
  field-name reference, import-policy docs, examples, and snapshots now
  describe the separate `ggb_raw` / `ggb_style` / `overlay` / `elem.style`
  layers.

### Tests

- Full suite: `1036 passed` with Manim Community `0.20.1`.

## [1.1.0] — 2026-04-29

Style-system release: semantic presets, per-type defaults, overlay parity for
GGB and DSL scenes, and a rewritten style guide. This release completes the
transition to the canonical style schema and removes the temporary alias and
normalization layer.

### Added

- **Semantic `presets` registry** — canonical style constants now live under
  `presets`: `presets.color`, `presets.point_size`, `presets.line_width`,
  `presets.angle_radius`, `presets.tick`, `presets.arrow`, and
  `presets.font_size`. Names such as `main`, `bold`, and `aux` are conventions;
  user-defined names are valid and can be referenced from other blocks.
- **Generic style references** — values like `presets.color.main`,
  `presets.line_width.bold`, and `presets.arrow.main` are resolved
  recursively by `StyleConfig`.
- **Structural preset includes** — per-type style maps can use `$include` to
  merge reusable structured presets, for example vector arrows and segment
  tick marks.
- **Scene background styling** — `rendering.background` accepts a hex color or
  a preset reference such as `presets.color.background` and is applied to the
  Manim camera background.
- **Canonical tick/arrow style keys** — renderers now understand
  `tick_length_px`, `tick_width_px`, `tick_shift_px`, `arrow_length_px`, and
  `arrow_width_px` through the resolver.

### Changed

- **`presets.color` is the only color registry** — builtin styles, examples,
  docs, and runtime access now use `presets.color`.
- **`defaults` is now a per-type baseline** — defaults choose or include
  semantic presets for element types (`point`, `segment`, `vector`, `angle`,
  etc.) instead of storing scene-level `angle` / `tick` / `arrow` / `font`
  knobs directly.
- **Overlay application order** — `overlay.per_type` and `overlay.per_name`
  apply uniformly to GGB-imported and DSL-created elements, with `per_name`
  winning over `per_type`.
- **Style import maps** — `import.colors`, `import.point_size`, and
  `import.line_width` accept fully qualified preset refs as well as bare
  preset names. `import.colors` now normalizes remap results to hex colors and
  applies target opacity separately, preserving the current opacity when the
  target does not specify one.
- **GGB import adaptation** — `import.point_size` is now applied by
  `applyStyle`; `ImportPolicy` can target raw-derived visibility, labels,
  angle range, tick count, line opacity and dash style. `obj_color` raw data
  exposes normalized `hex` and `opacity` aliases for policy callables/remaps.
- **ImportPolicy scope** — `ImportPolicy` is now limited to raw-GGB
  adaptation. Type/name stylization moved fully to `overlay.per_type` and
  `overlay.per_name`, which apply uniformly to GGB and DSL elements.
- **Documentation and examples** — README, style docs, field-name reference,
  migration guide, policy examples, and the HTML style guide were updated to
  the canonical `presets` schema.

### Removed

- Removed top-level `palette` and `palette.*` reference resolution.
  Use `presets.color` and `presets.color.<name>` references.
- Removed normalization of old scene-level `defaults` blocks for tick, arrow,
  font, and angle-radius settings. Use `presets.tick`, `presets.arrow`,
  `presets.font_size`, `presets.angle_radius`, and per-type `defaults`.
- Removed `strich_*_px` per-element aliases. Use `tick_length_px`,
  `tick_width_px`, and `tick_shift_px`.
- Removed public support for automation settings under `rendering`; use
  `overlay.angle_radius` and `overlay.label_placement`.

### Tests

- Full suite: `1013 passed` with Manim Community `0.19.0`.

## [1.0.2] — 2026-04-24

Security, correctness, dead-code cleanup and manim 0.20 compatibility pass.
Driven by a full library audit; every item below has a regression test.

### Removed (breaking)

- **``animageo/_stubs.py``** — 613-line orphan IDE-stub snapshot that
  referenced pre-1.0 field names (``Measure.x``, ``Angle.angle``).
  Unreferenced from package; deleted.
- **``mult_ff`` / ``mult_fm`` / ``mult_mf`` / ``mult_if``** — unreachable from
  dispatch (``f`` was never registered in ``type_to_shortcut``); deleted.
- **Unused Lark parser block in ``ggb_parser.py``** (~130 lines: grammar +
  ``GeoGebraTransformer`` + ``parse_geogebra_xml``). Never called.
  ``lark`` removed from ``pyproject.toml`` dependencies.
- **DSL sandbox**: ``type`` and ``getattr`` removed from ``SAFE_BUILTINS``
  (classic sandbox escape via ``type(x).__mro__[-1].__subclasses__()``).
  Use ``isinstance(x, Cls)`` and the new ``type_name(x)`` DSL helper.
- **CLI ``-d/--debug`` flag** — semantic reversed to ``action='store_true'``
  (intuitive: ``-d`` turns debug ON). Previously was ``store_false`` which
  meant ``-d`` silenced debug output.

### Added

- **``AnimaGeoScene.resetScene()``** — explicit state wipe for reusing one
  scene instance across render jobs. Called automatically by ``loadGGB``.
- **``setElementStyle(..., update=True)`` / ``setVisible(..., update=True)``**
  — auto-rerender by default so changes are visible immediately.
  ``update=False`` defers for bulk operations.
- **``COMMAND_REGISTRY`` + ``list_commands()``** in ``lib_commands``. Dispatch
  uses the explicit registry instead of ``globals()``. Emits a warning when
  a command name doesn't match any implementation (previously silent ``None``).
- **Pixel-invariant decoration overrides** — per-element opt-in keys in
  ``elem.style``: ``strich_len_px`` / ``strich_rshift_px`` / ``arrow_width_px``
  / ``arrow_length_px``. When set, rendered at an absolute pixel size
  regardless of canvas ``ptUnit``. Scene-level defaults keep legacy
  scale-with-canvas semantics (backward-compatible).
- **DSL helper ``type_name(x)``** — returns ``type(x).__name__`` as a string.
  Safe stand-in for the removed ``type(x).__name__`` pattern.

### Fixed

- **Shell / Python injection in ``python -m animageo``** — CLI used
  ``os.system`` with f-string interpolation of user-supplied arguments into
  generated Python source. Rewritten to ``subprocess.run`` with argv-list
  and ``repr()``-escaped placeholders.
- **ZIP slip + zip bomb in ``.ggb`` loader** — ``ZipFile.extractall`` ran
  without path validation. New ``_safe_extract_ggb`` rejects traversal
  paths, absolute paths, archives with >4096 members, and >256 MB
  uncompressed total.
- **``loadGGB`` state leakage** — a second ``loadGGB`` on the same scene
  instance stacked new geometry on top of the old (visible as leftover
  elements from the prior file). Now starts from a fresh ``Construction``.
- **Global ``_bbox_cache`` thread-safety** in ``label_placement`` — added
  ``threading.Lock``; extended cache key with ``tex_template`` identity.
- **``Angle.equivalent`` / ``AngleSize.equivalent``** — used the non-existent
  ``.angle`` attribute; would raise ``AttributeError``. Now use ``.value``.
- **``are_congruent_aa`` / ``are_complementary_aa``** (``lib_commands``) —
  same ``.angle`` bug; 100% crash on any invocation. Fixed.
- **``_apply_interp_value`` for Measure vars** — wrote to ``.x``, which
  doesn't exist on ``Measure`` (phantom attribute created; real ``.value``
  unchanged). Keyframe animations on Measure variables were silently no-ops.
- **``Element.value()`` for Measure/AngleSize/Boolean** — circular import
  between ``lib_vars`` and ``lib_elements`` left those classes unbound at
  method-call time → ``NameError``. Fixed with local imports.
- **``font_size_px`` dead key** — builtin defaults and overlay shipped the
  key, but the renderer only read ``font_size`` (manim units), silently
  dropping pixel-invariant font overrides. Renderer and label placement
  now prefer ``font_size_px`` through the resolver.
- **``label_radial_offset_px``** — name said pixels, code treated value as
  manim units. ``5`` meant 5 MU ≈ 500 px. Now honoured as actual pixels.
- **Sandbox hardening** — see "Removed" above for ``type``/``getattr``.
- **Marching-squares ``_edge_point``** — unguarded divisions by corner-
  difference could yield ``inf``/``nan`` for near-coincident corner values.
  Now collapses to mid-edge.
- **``intersect_*`` near-zero endpoint detection** — ``if a == 0`` on a
  float could miss a true zero rounded to ±1e-17, losing a valid root.
  Replaced with ``abs(a) < 1e-12`` + symmetric case at the other endpoint.
- **``play_keyframes`` on a missing element** — silently skipped via
  ``info is None``; now logs a warning with context so debug traces aren't
  lost.

### Changed

- **Python requirement** relaxed from ``>=3.13`` to ``>=3.10``. Code uses
  PEP 604 unions and PEP 585 generics; no newer syntax.
- **Dependency pins** — ``numpy<3.0``, ``manim<0.20`` upper bounds added
  (manim has had breaking API changes between minor versions).
- **Internal project notes**: stale statistics removed (test count,
  render-method count).
- **``style/schema.py``** doc table split into pixel-invariant vs
  scale-with-canvas unit classes (previously mixed).

### Docs

- ``docs/style_guide/assets/examples/src/anim_scenes.py`` (served download)
  was using pre-1.0 API names (``show_label``, ``stroke_width``,
  ``technic``, ``ggb_export.import_policy``); synced with the current
  source in ``docs/style_guide/examples/``.
- ``examples/main.py``: 15 SyntaxWarnings from invalid escape sequences
  (``'$...\circ...$'``) fixed with raw-string prefix.

### Tests

- 937 → 988 (+51 new regression tests).
- 0 regressions; ``_safe_extract_ggb`` path traversal / bomb prevention,
  DSL sandbox escape vectors, state-reset on ``loadGGB``, overlay reaching
  renderer for stroke/font/size, ``Element.value()`` for each variable
  type, ``Angle.equivalent`` symmetry, float-tolerance edge cases, CLI
  injection payload lock-in, pixel-invariant decoration overrides.

### Compatibility

- Tested against manim 0.19.0 and 0.20.1. Upper bound in ``pyproject.toml``
  relaxed to ``manim>=0.19.0,<0.22``.
- Fixed manim 0.20 deprecations in our code:
  ``VMobject.get_cap_style()`` → direct ``cap_style`` attribute read.
- Fixed NumPy 2.0 deprecations in our code: replaced 2-D ``np.cross``
  calls (``lib_commands.area`` and ``are_concurrent_lll``) with explicit
  scalar ``x1*y2 − y1*x2`` expressions.
- Silenced the startup ``pytest-asyncio`` deprecation via
  ``[tool.pytest.ini_options]``.

## [1.0.1] — 2026-04-24

Patch release: reliability fixes in rendering and DSL re-definition.

### Fixed

- **Arc / CircleSector rendering** (`animageo.py`) — both renderers read `elem.data.sizes`, but the geometry classes expose the attribute as `angles`. Any scene containing Arc or CircleSector crashed during `CreateMObject`, cascading through dependents. Renamed to `elem.data.angles`.
- **`.contains` typos in `lib_commands.py`** — `arc.centerontains(...)` / `line.offsetontains(...)` were pre-1.0 search-and-replace artifacts with no matching method on the target classes. Broke `intersect_Cl` (arc∩line), `circumcircle_arc_ppp` / `circumcircle_sector_ppp`, `contained_by_pc` / `contained_by_pl`. All five call sites now use `.contains(...)`.
- **DSL command failure with forward-ref Vars** — when a command's inputs contain a forward-reference Var with no data yet, `Construction.apply()` only wrote `None` into outputs that *already existed* as elements. Phantom outputs (e.g., intermediate `_3` from `4 + x` arithmetic) were silently skipped, so `element(name)` later returned `None` and `styleGeometry`-style code raised `AttributeError`. Fix: `apply()` now creates placeholder elements for all outputs, including not-yet-existing phantoms.
- **`Construction.rename()` broke downstream dependency graph** — when a DSL file redefined a GGB-loaded element (e.g., `X = A + x * (B - A)` where `X` was already a Point in the GGB), the `_forget(X) + rename(phantom, X)` sequence cleared every `state[downstream].inputs` reference to `X`, but did not restore them for the new command using `X`. Symptom: animating the Var re-computed `X` itself, but `q1`/`g`/… that depended on `X` never rebuilt, so the animation was visually frozen. Fix: `rename()` now re-runs `updateStateLevels` on every command that references the new name.

### Notes

- All 937 unit tests continue to pass.
- No API surface changes.

## [1.0.0] — 2026-04-23

First stable release. Substantial rewrite of the style system, parsers, and geometry core, with three new element types and full animation/labeling pipelines.

### Added

- **Python DSL (`animageo.dsl`, `parsers/dsl/`)** — exec-based mini-DSL replacing the old short-parser. Supports `for`/`if`/`def`, keyword args, tuple unpacking, live `.field` access on elements, proxy arithmetic (`A-B`, `-v`, `abs(x)`), `f(x) = expr` sugar for functions, and auto-generated `.pyi` stubs per scene.
- **Style subsystem (`animageo/style/`)** — three-layer resolver architecture: package-shipped `builtin.json` defaults (pixels), user JSON defaults, `overlay.per_type` / `overlay.per_name` stylization, with explicit `elem.style[...]` writes always winning. Mini-DSL for policy values: `const:`, `scale:`, `quantize:`, `remap:`.
- **`ImportPolicy`** — configurable GGB-to-style mapping. Pass to `loadGGB` or embed under `import.policy` in the style JSON. Supports scalar, callable, and DSL-string rules. `scene.reloadPolicy()` reapplies a new policy without reparsing XML. Type/name overrides belong to `overlay.per_type` / `overlay.per_name`.
- **`Conic` element** — first-class conic stored as a 3×3 symmetric matrix with lazy classification into 9 types (circle / ellipse / parabola / hyperbola / intersecting / parallel / double lines / point / empty). Canonical parametrizations via eigendecomposition. Constructors: `Conic(matrix)`, `from_ggb_matrix`, `from_coeffs`, `from_string`.
- **`Function` element** — explicit `y = f(x)` with sympy parsing: `^` → `**`, Unicode `≤/≥`, chained comparisons, `If[...]` → `Piecewise`. numpy `lambdify` on the hot path.
- **`ImplicitCurve` element** — `F(x, y) = 0` for any sympy expression, rendered by marching squares.
- **Adaptive curve sampling (`geo/curve_sampling.py`)** — viewport-aware sampler with Liang–Barsky clipping, analytic t-ranges for parabola / hyperbola branches, marching squares for implicit curves. Hard `max_samples` caps guarantee no hangs on pathological curves.
- **Intersections across all type pairs** — analytic for `Kl` / `KK` / `Kc` (pencil method); numeric with sympy + `scipy.brentq` / `fsolve` fallbacks for `F*` and `I*`. 150+ commands in `lib_commands.py`.
- **Conic geometric constructors** — `Ellipse`/`Hyperbola` from foci + semi-axis, `Parabola` from focus + directrix, `Conic` from 5 points.
- **Conic properties** — `Center`, `Focus`, `Vertex`, `Axes`, `Directrix`, `Eccentricity`, `Polar`, `Tangent`.
- **Automatic label placement (`label_placement.py`)** — priority-ordered greedy solver with 8 candidate directions, analytic bisector placement for angles, EMA smoothing + anchor hysteresis for dynamic tracking, per-keyframe snapshots with interpolation.
- **Keyframe animation (`keyframes.py`)** — JSON-driven animation: free points, tparam-constrained points, numbers, angles, booleans; linear / smooth / in / out / in\_out easing; per-keyframe `show` / `hide`.
- **Batch API** — `setElementStyle(names, **kwargs)`, `setVisible(names, visible)`, `animating(...)` context manager.
- **Pixel-invariant sizing** — all GGB sizes (point radius, line width, font, arc, label offset) stored in pixel units, divided by `ptUnit` at render time. Same pixel output across canvas sizes.
- **Angle arc auto-sizing** — opt-in `rendering.angle_radius` scales arc radius by `(π/2 / angle) ** exp`, clamped by arm-length fraction. Shared between renderer and label placement.
- **Z-index tiers** — named constants in `constants.py` (`Z_FILL`, `Z_LABEL`, …).
- **`CreateMObject` dispatch** — split into 13 per-type `_render_<typename>` methods plus a small context builder. `CreateMObject` itself is a 20-line dispatcher.
- **Structured logging** — all modules use `logging.getLogger(__name__)`; no stray `print` in library code.
- **`CHANGELOG.md`** (this file).

### Changed

- **Version:** 0.1.11 → 1.0.0.
- **Python requirement:** bumped to `>=3.13`.
- **Metadata:** added MIT license, `Development Status :: 5 - Production/Stable`, audience and topic classifiers. Homepage switched to `https://`.
- **Topological rebuild** — Construction now uses Kahn's algorithm with cycle detection and per-element error recovery, so one broken element no longer aborts the whole scene.
- **CLI entry point** — `animageo` console script remains, unchanged surface.

### Fixed

- **`intersect_cc`** — edge-case reliability (tangent / coincident circles).
- **Angle arc radius units** — no longer collapse to sub-pixel values when `elem.style` is empty (builtin default of 17 px now applies).
- **GGB label offsets** — now scale proportionally with canvas size via `ptUnit_ggb`.

### Removed

- **`animageo/style.py` / `animageo/style_schema.py`** — replaced by the `animageo/style/` subpackage.
- **`animageo/parsers/short_parser.py`** — replaced by the Python DSL.
- **`requests` dependency** — was unused.
- **Legacy `geodynamic/` package** — earlier rename; no longer shipped in the wheel after build hygiene fix.

### Packaging

- **`pyproject.toml`** is now the single source of truth; `setup.py` reduced to a one-line shim.
- **`package-data`** — `style/builtin.json` and `*.pyi` stub files now ship inside the wheel.
- **`find_packages`** — restricted to `animageo*`; `tests/` is no longer included in the distribution.
