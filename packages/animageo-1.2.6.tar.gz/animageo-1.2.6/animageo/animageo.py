import re
import os
import json
import logging
import traceback
from contextlib import contextmanager
from types import SimpleNamespace
import numpy as np
import tempfile

from .geo import construction as geo
from .geo.lib_conic import ConicType
from .geo.curve_sampling import (
    sample_parametric,
    viewport_t_ranges_parabola,
    viewport_t_range_hyperbola_branch,
    make_parabola_param,
    make_hyperbola_branch_param,
    marching_squares,
)
from .style import GeoStyle, isnan, getColorFromDict, updateMin, updateMax, hasParam, GGB_FONT_SCALE, Z_FILL, Z_FILL_LABEL, Z_ANGLE, Z_STROKE, Z_POINT, Z_LABEL
from .style.scaling import (
    ggb_font_px_to_manim_fontsize,
    stroke_width_to_manim,
)
from .style.import_policy import ImportPolicy
from .style.config import StyleConfig
from .style.resolver import resolve as _resolve_style
from .labels import resolve_label_text
from .ui import (
    RusTex, correctedLabel, create_label, round_corners_vmobject,
    ShowText, NumberedFrame, FixedLabel, CustomArrowTip, LABEL_ANCHORS,
)
from manim import *

from .parsers.svg_parser import *
from .parsers import ggb_parser
from .keyframes import KeyframeSequence, apply_parsed_value
from .export_layout import compute_reference_export_layout
from .export_layout import normalize_content_options
from .export_layout import normalize_export_options
from .export_layout import resolve_auto_size
from .export_layout import size_from_config

import xml.etree.ElementTree as ET

SQRT2 = np.sqrt(2)

logger = logging.getLogger(__name__)


def _reference_size_from_config(reference):
    if not isinstance(reference, dict):
        return None
    size = reference.get('size')
    if not isinstance(size, dict):
        return None
    w = size.get('width')
    h = size.get('height')
    if w is None or h is None:
        return None
    return [w, h]


def _style_ptUnit(style):
    export = getattr(style, 'export', {}) or {}
    return export.get('ptUnit_style', export.get('ptUnit', 1))


def _validate_rendered_bounds_policy(value):
    value = str(value)
    if value not in {'clip', 'ignore'}:
        raise ValueError("content.infinite_policy must be 'clip' or 'ignore'")
    return value


def _style_path_for_geostyle(style):
    """Return the style input shape supported by GeoStyle."""
    if isinstance(style, StyleConfig):
        return style.source
    if isinstance(style, dict):
        return style
    if isinstance(style, (str, os.PathLike)):
        return str(style)
    return None


def _merge_reference(style_reference, runtime_reference):
    ref = {}
    if isinstance(style_reference, dict):
        ref.update(style_reference)
    if isinstance(runtime_reference, dict):
        merged_size = {}
        if isinstance(ref.get('size'), dict):
            merged_size.update(ref['size'])
        if isinstance(runtime_reference.get('size'), dict):
            merged_size.update(runtime_reference['size'])
        ref.update(runtime_reference)
        if merged_size:
            ref['size'] = merged_size
    return ref


# Cap/joint lookups used by CreateMObject — lifted to module level so
# every render call doesn't re-allocate the dicts.
_JOINT_MAP = {
    None:      LineJointType.AUTO,
    "auto":    LineJointType.AUTO,
    "bevel":   LineJointType.BEVEL,
    "miter":   LineJointType.MITER,
    "round":   LineJointType.ROUND,
}
_CAP_MAP = {
    None:      CapStyleType.AUTO,
    "auto":    CapStyleType.AUTO,
    "round":   CapStyleType.ROUND,
    "butt":    CapStyleType.BUTT,
    "square":  CapStyleType.SQUARE,
}

# Automatic z-index tier by element type. Applied in ``_build_render_ctx``
# only when ``z_auto=True`` and ``elem.style['z_index']`` is unset.
_Z_AUTO_BY_TYPE = {
    geo.Polygon:      Z_FILL,
    geo.CircleSector: Z_FILL,
    geo.Angle:        Z_ANGLE,
    geo.Segment:      Z_STROKE,
    geo.Circle:       Z_STROKE,
    geo.Arc:          Z_STROKE,
    geo.Point:        Z_POINT,
}



def _scaled_triangle(pos, radius, rotation, col_s, col_f, op_f, op_s, lw, zz):
    """Equilateral triangle scaled so circumradius = *radius*, rotated."""
    tri = Triangle(
        color=col_s, fill_color=col_f, fill_opacity=op_f,
        stroke_width=lw, stroke_opacity=op_s,
    )
    verts = tri.get_vertices()
    cr = float(np.max(np.linalg.norm(verts - tri.get_center(), axis=1)))
    tri.scale(radius / cr)
    tri.move_to(pos)
    if rotation:
        tri.rotate(rotation)
    return tri.set_z_index(zz)


def reorder_objects_by_name(scene, name_order):
    ordered_objects = []
    other_objects = []
    
    for obj in scene.mobjects:
        if hasattr(obj, 'name') and obj.name in name_order:
            ordered_objects.append(obj)
        else:
            other_objects.append(obj)
    
    ordered_objects.sort(key=lambda x: name_order.index(x.name))
    scene.mobjects = ordered_objects + other_objects


def _import_map_lookup(mapping, *values):
    """Find an import-map entry by raw or already-scaled style value."""
    for value in values:
        if value is None:
            continue
        keys = [str(value)]
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            numeric = None
        if numeric is not None and numeric.is_integer():
            keys.append(str(int(numeric)))
        for key in keys:
            if key in mapping:
                return mapping[key]
    return None


def _coerce_import_number(value):
    if isinstance(value, str):
        try:
            numeric = float(value)
        except ValueError:
            return value
        return int(numeric) if numeric.is_integer() else numeric
    return value
    
class NamedValueTracker(ValueTracker):
    def __init__(self, name: str = None, value: float = 0):
        super().__init__(value)
        self.name = name

class AnimaGeoScene(MovingCameraScene):
    def __init__(self):
        super().__init__()
        self.geo = geo.Construction()
        self.style = GeoStyle()
        # New-style unified config. Always populated with builtin defaults so
        # the resolver has a baseline even when applyStyle() is never called.
        # User JSON/dict merges on top when applyStyle(style=...) runs.
        self.style_config = StyleConfig.load()

        self._styles_back = {}
        self._shade_mobjects = {}
        self._construction_source = {'kind': 'unknown'}

        self.cuts = 0
        self._label_tracker = None  # Set by autoPlaceLabels(dynamic=True)
        
    def mobject(self, name): 
        for mobj in self.mobjects: 
            if mobj.name == name: return mobj
        return None
    
    def element(self, name):
        return self.geo.element(name)
    
    def addOrdered(self, mobj):
        name_order = [elem.name for elem in self.geo.elements]
        if mobj.name not in name_order:
            self.add(mobj)
            return
        self.add(mobj)
    
    def addGeoElement(self, elem):
        mobj = self.CreateMObject(elem, z_auto = True)
        if mobj is not None and self._element_visible(elem):
            self.add(mobj)

    def addAllGeometry(self, show = False):
        if not show:
            for el in self.geo.elements: el.visible = False
        self.addCoordinateBackground()

        element_types = [
            [geo.CircleSector, geo.Polygon],
            [geo.Angle],
            [geo.Circle, geo.Arc, geo.Segment, geo.Vector, geo.Line, geo.Ray,
             geo.LocusCurve, geo.Conic, geo.Function, geo.ImplicitCurve],
            [geo.Point]
        ]

        for el_types in element_types:
            for el in self.geo.elements:
                if type(el.data) in el_types: self.addGeoElement(el)

    def _element_visible(self, elem):
        return bool(_resolve_style(self, elem, 'visible', default=getattr(elem, 'visible', True)))

    def _import_enabled(self, style=None):
        style = style or self.style
        return (style.imp or {}).get('enabled', True) is not False

    def getAllGeometryBounds(self, ptUnit = 1):
        bounds = [None,None,None,None]
        for elem in self.geo.elements:
            if self._element_visible(elem) and not isinstance(elem.data, (geo.Line, geo.Ray)):
                mobj = self.CreateMObject(elem, z_auto = True)
                if mobj is not None:
                    bounds[0] = updateMin(bounds[0], mobj.get_left()[0])
                    bounds[1] = updateMin(bounds[1], mobj.get_bottom()[1])
                    bounds[2] = updateMax(bounds[2], mobj.get_right()[0])
                    bounds[3] = updateMax(bounds[3], mobj.get_top()[1])
                    
        if bounds[0] is None:
            bounds = [-10,-10,10,10]
        
        for i in range(4): bounds[i] *= ptUnit
                    
        return bounds

    def _set_camera_from_export(self, export):
        """Set camera frame from an export dict without accumulating shifts."""
        ptUnit = export['ptUnit']
        ratio = float(config.pixel_width) / float(config.pixel_height)
        if export['ptWidth'] / export['ptHeight'] >= ratio:
            self.camera.frame.set(width=export['ptWidth'] / ptUnit)
            dx = self.camera.frame.width / 2 - export['ptXZero'] / ptUnit
            dy = export['ptHeight'] / (2 * ptUnit) - export['ptYZero'] / ptUnit
        else:
            self.camera.frame.set(width=ratio * export['ptHeight'] / ptUnit)
            dx = export['ptWidth'] / (2 * ptUnit) - export['ptXZero'] / ptUnit
            dy = self.camera.frame.height / 2 - export['ptYZero'] / ptUnit
        self.camera.frame.move_to(ORIGIN)
        self.camera.frame.shift(dx * RIGHT + dy * DOWN)

    def _rendered_bounds_source_view(
        self,
        source_view,
        *,
        padding_px=0,
        infinite_policy='ignore',
    ):
        """Return a source_view based on rendered visible mobject bounds.

        Bounds are measured in scene MU after style resolution, then converted
        back to source pixel coordinates using the original GeoGebra view. For
        ``infinite_policy='ignore'`` skips ``Line``/``Ray`` objects so finite
        geometry drives the measured rectangle. ``'clip'`` measures them after
        clipping to the current source camera.
        """
        infinite_policy = _validate_rendered_bounds_policy(infinite_policy)
        padding_px = max(float(padding_px or 0), 0.0)
        bounds = [None, None, None, None]
        for elem in self.geo.elements:
            if not self._element_visible(elem):
                continue
            if infinite_policy == 'ignore' and isinstance(elem.data, (geo.Line, geo.Ray)):
                continue
            mobj = self.CreateMObject(elem, z_auto=True)
            if mobj is None:
                continue
            bounds[0] = updateMin(bounds[0], float(mobj.get_left()[0]))
            bounds[1] = updateMin(bounds[1], float(mobj.get_bottom()[1]))
            bounds[2] = updateMax(bounds[2], float(mobj.get_right()[0]))
            bounds[3] = updateMax(bounds[3], float(mobj.get_top()[1]))

        if bounds[0] is None:
            return dict(source_view)

        left_mu, bottom_mu, right_mu, top_mu = bounds
        unit = float(source_view.get('ptUnit', 1))
        xzero = float(source_view.get('ptXZero', 0))
        yzero = float(source_view.get('ptYZero', 0))

        left_px = xzero + left_mu * unit - padding_px
        right_px = xzero + right_mu * unit + padding_px
        top_px = yzero - top_mu * unit - padding_px
        bottom_px = yzero - bottom_mu * unit + padding_px

        width = max(right_px - left_px, 1.0)
        height = max(bottom_px - top_px, 1.0)
        rendered_view = dict(source_view)
        rendered_view.update({
            'ptWidth': width,
            'ptHeight': height,
            'ptXZero': xzero - left_px,
            'ptYZero': yzero - top_px,
            'sourceLeftPx': left_px,
            'sourceTopPx': top_px,
            'sourceRightPx': right_px,
            'sourceBottomPx': bottom_px,
            'boundsPaddingPx': padding_px,
            'boundsInfinitePolicy': infinite_policy,
        })
        return rendered_view

    #пауза для обрезки видео + отображение ярлыка слева
    def waitCut(self, msg = None, **kwargs):
        self.cuts += 1

        rect = Rectangle(color = RED, fill_opacity = 1, height = self.camera.frame_height, width = self.camera.frame_width/4).move_to(self.camera.frame_center).shift( (3/8) * self.camera.frame_width * LEFT)
        txt = Text(str(msg) if msg is not None else str(self.cuts)).set_color(BLACK).scale(3).move_to(rect)
        
        self.add(rect, txt)
        self.wait(**kwargs)

        self.remove(rect)
        self.remove(txt)

    def updateAllGeometry(self):
        self.updateGeoElements()
    
    def updateGeoElements(self, updates = None):
        for elem in self.geo.elements:
            if updates: 
                if elem.name not in updates: continue

            mobj = self.mobject(elem.name)   
            mobj_new = self.CreateMObject(elem)
            
            if mobj is None and mobj_new is None: continue
         
            needRemove = False if mobj is None     else (mobj_new is None) or (type(elem.data) == geo.Polygon) or (not self._element_visible(elem))
            needAdd = False    if mobj_new is None else (mobj is None)     or (type(elem.data) == geo.Polygon)

            if needRemove:
                mobj.set_opacity(0)
                self.remove(mobj)
            if needAdd:
                self.addOrdered(mobj_new)
            if not needRemove and not needAdd:
                mobj.become(mobj_new)

    def addVar(self, name, value = 0):
        new_tracker = NamedValueTracker(name, value)
        self.add(new_tracker)
        if not self.geo.var(name):
            self.geo.add(geo.Var(name, value))
        else:
            self.geo.update(name, value)

        self.geo.rebuild(full = True)
        self.updateAllGeometry()
        return new_tracker
    
    def addUpdater(self, tracker):
        tracker.add_updater(lambda v, self = self: self.updateVar(tracker))
    def clearUpdater(self, tracker):
        tracker.clear_updaters()

    @contextmanager
    def animating(self, tracker):
        """Context manager for addUpdater/play/clearUpdater pattern.

        Usage:
            x = self.addVar('x', 0)
            with self.animating(x):
                self.play(x.animate.set_value(1), run_time=3)
        """
        self.addUpdater(tracker)
        try:
            yield tracker
        finally:
            self.clearUpdater(tracker)

    def loadCode(self, filepath, debug = False, show = True):
        logger.info("Loading DSL code from %s", filepath)
        with open(filepath) as f:
            code = f.read()
        from .parsers import dsl
        dsl.run(self.geo, code, debug=debug, show=show)
        self._construction_source = {
            'kind': 'dsl_file',
            'name': os.path.basename(filepath),
            'path': os.path.abspath(filepath),
        }
        self.geo.rebuild(debug=debug, full=True)
        self.updateAllGeometry()

    def putCode(self, code, debug = False, show = True):
        """Parse DSL ``code`` against this scene's Construction.

        Uses the exec-based engine in :mod:`animageo.parsers.dsl` —
        full Python (for/if/def/comprehensions/kwargs/tuple-unpack,
        ``A.style.stroke = '#f00'``, field access ``A.x``). See
        ``docs/python_dsl.md`` for the full surface.
        """
        logger.info("Executing DSL code (%d chars)", len(code))
        from .parsers import dsl
        dsl.run(self.geo, code, debug=debug, show=show)
        self._construction_source = {'kind': 'dsl_inline'}
        self.geo.rebuild(debug=debug, full=True)
        self.updateAllGeometry()

    def applyStyle(
        self,
        style = None,
        import_policy = None,
        reference = None,
        content = None,
        export = None,
    ):
        """Apply style and configure the scene viewport.

        The current layout pipeline is:

        ``style.reference`` / runtime ``reference`` -> ``content`` placement
        into that reference canvas -> physical ``export`` size.

        ``content`` controls which source rectangle is placed into the
        reference canvas (``source_view``/``ggb_view``/``rendered_bounds``).
        ``export`` controls the final SVG/PNG/MP4 canvas. Construction
        coordinates and style dictionaries are not mutated by layout.
        """
        style_path = _style_path_for_geostyle(style)
        if style_path == '':
            style_path = None
        style_obj = GeoStyle(style=style_path)
        logger.info("Applying style: %s", style_path or "builtin")
        # Reload unified StyleConfig — merges builtin.json with the optional
        # style input. Resolver and renderer read from this going forward.
        self.style_config = StyleConfig.load(style)

        # Keep scene-level GeoStyle fields in sync for renderer paths that
        # still use the scene container for defaults and export metadata.
        colors = self.style_config.presets.get('color', {})
        style_obj.col              = colors.get('main',         style_obj.col)
        style_obj.col_light        = colors.get('light',        style_obj.col_light)
        style_obj.col_accent       = colors.get('accent',       style_obj.col_accent)
        style_obj.col_accent_light = colors.get('accent_light', style_obj.col_accent_light)
        style_obj.col_shade        = colors.get('shade',        style_obj.col_shade)
        style_obj.strong           = colors.get('strong',       style_obj.strong)
        style_obj.background       = colors.get('background',   style_obj.background)

        bg = self.style_config.rendering.get('background')
        if bg is not None:
            style_obj.background = bg

        if 'polygon_boundary_layer' in style_obj.rendering:
            if style_obj.rendering['polygon_boundary_layer'] == 'top':
                for comm in self.geo.commands:
                    if comm.name == 'Polygon':
                        for segm in comm.outputs[1:]:
                            if self.geo.element(segm):
                                self.geo.element(segm).style['z_index'] = 10
                            
        import_enabled = self._import_enabled(style_obj)

        if import_enabled and 'colors' in style_obj.imp:
            ggb_colors = style_obj.imp['colors']
            for elem in self.geo.elements:
                ggb_style = getattr(elem, 'ggb_style', None)
                if not ggb_style:
                    continue
                col = ggb_style.get('stroke')
                col_opacity = ggb_style.get('stroke_opacity')
                col_new = getColorFromDict(ggb_colors, [col, col_opacity])
                if col_new is not None: 
                    ggb_style['stroke'] = col_new.color
                    if col_new.opacity is not None:
                        ggb_style['stroke_opacity'] = col_new.opacity
            
                col = ggb_style.get('fill')
                col_opacity = ggb_style.get('fill_opacity')
                col_new = getColorFromDict(ggb_colors, [col, col_opacity])
                if col_new is not None: 
                    ggb_style['fill'] = col_new.color
                    if col_new.opacity is not None:
                        ggb_style['fill_opacity'] = col_new.opacity

        point_size_map = style_obj.imp.get('point_size') if import_enabled else None
        if point_size_map:
            for elem in self.geo.elements:
                ggb_style = getattr(elem, 'ggb_style', None)
                if not ggb_style:
                    continue
                raw_size = (getattr(elem, 'ggb_raw', {}) or {}).get('point_size')
                style_size = ggb_style.get('size_px')
                size_new = _import_map_lookup(point_size_map, raw_size, style_size)
                if size_new is not None:
                    ggb_style['size_px'] = _coerce_import_number(size_new)
                        
        line_width_map = style_obj.imp.get('line_width') if import_enabled else None
        if line_width_map:
            for elem in self.geo.elements:
                ggb_style = getattr(elem, 'ggb_style', None)
                if not ggb_style:
                    continue
                raw_wid = (getattr(elem, 'ggb_raw', {}) or {}).get('line_thickness')
                style_wid = ggb_style.get('stroke_width_px')
                wid_new = _import_map_lookup(line_width_map, raw_wid, style_wid)
                if wid_new is not None:
                    ggb_style['stroke_width_px'] = _coerce_import_number(wid_new)

        # Carry over GGB-specific keys before replacing the export dict
        ggb_font_px = self.style.export.get('fontSize')
        ggb_ptUnit = self.style.export.get('ptUnit_ggb')

        def preserve_ggb_metadata():
            export_dict = style_obj.export
            if ggb_font_px:
                export_dict['fontSize'] = ggb_font_px
            if ggb_ptUnit:
                export_dict.setdefault('ptUnit_ggb', ggb_ptUnit)

        def apply_ggb_font_size():
            if not ggb_font_px:
                return
            style_obj.font_size = ggb_font_px_to_manim_fontsize(ggb_font_px, _style_ptUnit(style_obj))
            if import_enabled:
                for elem in self.geo.elements:
                    if getattr(elem, 'ggb_raw', None):
                        elem.ggb_style['font_size_px'] = ggb_font_px

        policy_applied = False
        source_view = dict(self.style.export)
        style_reference = getattr(self.style_config, 'reference', {})
        runtime_reference = _merge_reference(style_reference, reference)
        explicit_reference_size = size_from_config(_reference_size_from_config(runtime_reference))
        reference_size = explicit_reference_size or [source_view.get('ptWidth'), source_view.get('ptHeight')]
        reference_size = resolve_auto_size(reference_size, [source_view.get('ptWidth'), source_view.get('ptHeight')])

        export_options = normalize_export_options(export)
        export_size = resolve_auto_size(
            size_from_config(export_options.get('size')),
            reference_size,
        )

        content_options = normalize_content_options(content)
        _validate_rendered_bounds_policy(content_options.get('infinite_policy', 'ignore'))
        layout_source_view = source_view
        if content_options['source'] == 'rendered_bounds':
            style_obj.export = dict(source_view)
            preserve_ggb_metadata()
            self.setStyle(style_obj)
            self._set_camera_from_export(style_obj.export)
            apply_ggb_font_size()
            self._active_import_policy = self._resolve_import_policy(
                import_policy, import_enabled=import_enabled)
            self._apply_import_policy_overrides(self._active_import_policy)
            policy_applied = True
            layout_source_view = self._rendered_bounds_source_view(
                source_view,
                padding_px=content_options.get('padding', 0),
                infinite_policy=content_options.get('infinite_policy', 'ignore'),
            )
            if explicit_reference_size is None:
                reference_size = [
                    layout_source_view.get('ptWidth'),
                    layout_source_view.get('ptHeight'),
                ]
            content_options = dict(content_options)
            content_options['padding'] = 0

        layout = compute_reference_export_layout(
            layout_source_view,
            reference_size=reference_size,
            export_size=export_size,
            content=content_options,
            export=export_options,
        )
        style_obj.export = dict(layout_source_view)
        style_obj.export.update(layout.to_export_dict())
        style_obj.export['reference'] = runtime_reference

        export_dict = style_obj.export

        # Preserve GGB keys in the new export dict
        preserve_ggb_metadata()

        # Apply GGB font size for imported-scene diagnostics.
        # The renderer reads font_size_px via resolver; for imported GGB
        # scenes the raw view font is exposed as the GGB import layer below.
        apply_ggb_font_size()

        # Camera frame setup — 2D path only. Switching to ThreeDScene will
        # require rewriting both branches to use the 3D camera's
        # orientation/zoom instead of MovingCameraScene.frame.
        self._set_camera_from_export(export_dict)
    
        self.setStyle(style_obj)

        # ImportPolicy: GGB-only raw→import-style transforms
        # (scale:/quantize:/remap:) layered into elem.ggb_style. Skipped for DSL-built
        # elements (empty ggb_raw). Cross-origin stylisation lives in
        # StyleOverlay and is read lazily by the resolver.
        if not policy_applied:
            self._active_import_policy = self._resolve_import_policy(
                import_policy, import_enabled=import_enabled)
            self._apply_import_policy_overrides(self._active_import_policy)

    def _resolve_import_policy(self, import_policy, import_enabled=True):
        if not import_enabled:
            return None
        if import_policy is not None:
            return import_policy
        cfg = (self.style.imp or {}).get('policy')
        if cfg:
            return ImportPolicy.from_dict(cfg)
        return ImportPolicy.faithful()

    def _apply_import_policy_overrides(self, policy):
        """Layer ``policy.resolve_overrides_only()`` on top of ``elem.ggb_style``.

        Only GGB-imported elements are touched — the guard on ``ggb_raw``
        skips DSL-built elements because their raw-GGB values don't exist.
        Cross-origin stylisation (per_type/per_name) is the job of
        :class:`StyleOverlay`, read lazily by the resolver.
        Faithful policy (default) returns an empty override dict.
        """
        if policy is None:
            return
        ptUnit = _style_ptUnit(self.style)
        for elem in self.geo.elements:
            if isinstance(elem, geo.Var):
                continue
            if not getattr(elem, 'ggb_raw', None):
                continue
            overrides = policy.resolve_overrides_only(elem, defaults={}, ptUnit=ptUnit)
            ggb_style = getattr(elem, 'ggb_style', None)
            if ggb_style is None:
                continue
            for key, value in overrides.items():
                if key == 'visible':
                    elem.set_visible(value, explicit=False)
                else:
                    ggb_style[key] = value

    def reloadPolicy(self, import_policy):
        """Apply a new ImportPolicy without re-parsing the .ggb XML.

        Requires a prior loadGGB so elements carry ``ggb_raw``. Rebuilds
        the geometry and recreates mobjects so the new style takes effect.
        """
        self._active_import_policy = import_policy
        self._apply_import_policy_overrides(import_policy)
        self.addAllGeometry(show = True)

    def resetScene(self):
        """Reset construction and rendered state so the scene can load fresh input.

        Wipes ``self.geo`` (Construction), rendered mobjects, and the label
        tracker. Called by ``loadGGB`` so consecutive loads don't bleed
        geometry from earlier files into later renders. Safe to call
        directly when reusing an ``AnimaGeoScene`` across jobs.
        """
        self.geo = geo.Construction()
        self._label_tracker = None
        self._construction_source = {'kind': 'unknown'}
        try:
            self.clear()  # manim Scene.clear() — drop accumulated mobjects
        except Exception:
            pass
        from .label_placement import clear_bbox_cache
        clear_bbox_cache()

    def loadGGB(self, filepath, style = None, import_policy = None,
                debug = False, generate_stubs = True, strict = False,
                reference = None, content = None, export = None):
        """Load a GeoGebra ``.ggb`` file into this scene's Construction.

        Replaces any previously loaded geometry — call ``resetScene`` first
        is not required. To compose multiple sources, load the first via
        ``loadGGB`` then extend with ``putCode``/``loadCode`` which are
        additive.

        ``strict`` controls unsupported GGB command handling. In the default
        non-strict mode unsupported root commands are collected in
        ``scene.geo.command_diagnostics`` and dependency cascades are quiet.
        With ``strict=True`` the first unsupported root command raises.

        ``generate_stubs`` (default True) additionally writes
        ``<basename>_stubs.pyi`` next to the ``.ggb`` with type
        declarations for every loaded element. DSL files can then
        do ``from <basename>_stubs import *`` for one-line IDE
        autocomplete (see ``docs/python_dsl.md``). Pass False to
        disable.

        Layout follows :meth:`applyStyle`: ``style`` provides visual defaults
        and optional authoring ``reference``; runtime ``content`` places the
        construction into that reference canvas; runtime ``export`` chooses the
        physical output.
        """
        self.resetScene()
        logger.info("Loading GGB: %s", filepath)
        self._construction_source = {
            'kind': 'ggb',
            'name': os.path.basename(filepath),
            'path': os.path.abspath(filepath),
        }
        ggb_parser.load(self.geo, self.style.export, filepath, debug = debug, strict = strict)
        old_strict = self.geo.strict_unsupported
        old_log = self.geo.log_unsupported
        self.geo.strict_unsupported = bool(strict)
        self.geo.log_unsupported = bool(debug or strict)
        try:
            self.geo.rebuild(debug = debug, full = True)
        finally:
            self.geo.strict_unsupported = old_strict
            self.geo.log_unsupported = old_log
        self.applyStyle(
            style=style,
            import_policy = import_policy,
            reference = reference,
            content = content,
            export = export,
        )
        self.addAllGeometry(show = True)
        if generate_stubs:
            from .parsers.dsl.stub_gen import write_ggb_stubs
            write_ggb_stubs(self.geo, filepath)
        if self.style_config.overlay.label_placement.get('enabled'):
            self.autoPlaceLabels()

    def autoPlaceLabels(self, dynamic: bool = False):
        """Run automatic label placement to minimize overlaps.

        Args:
            dynamic: when ``True``, after the initial placement installs a
                ``LabelTracker`` on the scene. Subsequent ValueTracker-driven
                animations (``addUpdater(x); play(x.animate.set_value(...))``)
                will re-run the solver per frame with EMA smoothing and
                anchor hysteresis so labels track moving geometry without
                jumping. Off by default.
        """
        from .label_placement import (
            auto_place_labels, compute_label_layout,
        )
        if not dynamic:
            auto_place_labels(self)
            return

        cfg = self.style_config.overlay.label_placement
        canonicalize = bool(cfg.get('canonicalize_anchor', False))

        auto_place_labels(self)

        # Seed the tracker from the just-applied state. Read offsets back
        # from elem.style so prev values match what is actually rendered.
        layout = compute_label_layout(self, cfg=cfg, canonicalize=canonicalize)
        prev_offset = {}
        prev_anchor = {}
        angle_params = {}
        for name, pl in layout.items():
            elem = self.geo.element(name)
            if elem is None:
                continue
            off = _resolve_style(self, elem, 'label_offset_px', default=[0.0, 0.0])
            prev_offset[name] = np.array([float(off[0]), float(off[1])])
            prev_anchor[name] = _resolve_style(self, elem, 'label_anchor', default=pl.label_anchor)
            if pl.kind == 'dynamic_angle':
                angle_params[name] = pl.angle_params

        self._label_tracker = {
            'prev_offset': prev_offset,
            'prev_anchor': prev_anchor,
            'anchor_flip_counter': {},
            'angle_params': angle_params,
            'cfg': cfg,
            'frame_counter': 0,
        }

    def clearLabelTracker(self):
        """Detach the label tracker. Subsequent updateVar calls skip the per-frame solver."""
        self._label_tracker = None

    def _apply_dynamic_labels(self):
        """Re-run the placement solver and apply smoothed updates. Called from updateVar."""
        tracker = self._label_tracker
        if tracker is None:
            return
        from .label_placement import (
            compute_label_layout, compute_angle_label_offset_px,
            apply_ema_step, anchor_hysteresis_step,
        )

        cfg = tracker['cfg']
        canonicalize = bool(cfg.get('canonicalize_anchor', False))
        ema_alpha = float(cfg.get('ema_alpha', 0.2))
        anchor_flip_frames = int(cfg.get('anchor_flip_frames', 6))
        solver_every_n = max(1, int(cfg.get('solver_every_n_frames', 2)))

        tracker['frame_counter'] += 1
        run_solver = (tracker['frame_counter'] % solver_every_n) == 0

        ptUnit = _style_ptUnit(self.style)
        ptUnit_ggb = self.style.export.get('ptUnit_ggb', ptUnit)

        # Solver target (only recompute when due). Between solver runs, the
        # EMA step still advances static labels toward the last target.
        if run_solver or 'last_target_offset' not in tracker:
            layout = compute_label_layout(self, cfg=cfg, canonicalize=canonicalize)
            target_offset = {}
            target_anchor = {}
            kinds = {}
            angle_params = dict(tracker['angle_params'])
            for name, pl in layout.items():
                target_offset[name] = np.asarray(pl.offset_ggb, dtype=float)
                target_anchor[name] = pl.label_anchor
                kinds[name] = pl.kind
                if pl.kind == 'dynamic_angle':
                    angle_params[name] = pl.angle_params
            tracker['last_target_offset'] = target_offset
            tracker['last_target_anchor'] = target_anchor
            tracker['last_kinds'] = kinds
            tracker['angle_params'] = angle_params
        else:
            target_offset = tracker['last_target_offset']
            target_anchor = tracker['last_target_anchor']
            kinds = tracker['last_kinds']
            angle_params = tracker['angle_params']

        changed = []
        prev_offset = tracker['prev_offset']
        prev_anchor = tracker['prev_anchor']
        flip_counter = tracker['anchor_flip_counter']

        for name, kind in kinds.items():
            elem = self.geo.element(name)
            if elem is None or not self._element_visible(elem):
                continue

            if kind == 'dynamic_angle':
                # Continuous bisector — no EMA, no hysteresis.
                ap = angle_params.get(name)
                if ap is None:
                    continue
                new_offset = np.array(
                    compute_angle_label_offset_px(elem.data, ap, ptUnit, ptUnit_ggb),
                    dtype=float,
                )
                new_anchor = target_anchor.get(name, 'MC')
            else:
                tgt = target_offset[name]
                prev = prev_offset.get(name, tgt)
                new_offset = apply_ema_step(prev, tgt, ema_alpha)

                # Anchor hysteresis: require `anchor_flip_frames` consecutive
                # frames of the solver proposing a different anchor before
                # switching. Under canonicalize_anchor=True this is a no-op
                # because every anchor is 'MC'.
                proposed_anchor = target_anchor[name]
                current_anchor = prev_anchor.get(name, proposed_anchor)
                new_anchor, flip_counter[name] = anchor_hysteresis_step(
                    current_anchor, proposed_anchor,
                    flip_counter.get(name, 0), anchor_flip_frames,
                )

            old_off = prev_offset.get(name)
            old_anchor = prev_anchor.get(name)
            if (old_off is None
                    or not np.allclose(old_off, new_offset, atol=1e-6)
                    or old_anchor != new_anchor):
                elem.style['label_offset_px'] = [float(new_offset[0]), float(new_offset[1])]
                elem.style['label_anchor'] = new_anchor
                elem.style['_auto_placed'] = True
                changed.append(name)

            prev_offset[name] = new_offset
            prev_anchor[name] = new_anchor

        if changed:
            self.updateGeoElements(changed)

    def updateVar(self, tracker):
        var_name = tracker.name
        if self.geo.var(var_name).data != tracker.get_value():
            self.geo.update(var_name, float(tracker.get_value()))
            updates = self.geo.rebuild()
            self.updateGeoElements(updates)
            if self._label_tracker is not None:
                self._apply_dynamic_labels()

    def setStyle(self, style):
        self.style = style
        
        self.camera.background_color = self.style.background
        Text.set_default(color = self.style.strong)
        MathTex.set_default(color = self.style.strong)
        MarkupText.set_default(color = self.style.strong)
    
    def Hide(self, names, **kwargs):
        plays = []

        for name in names:
            elem = self.element(name)
            if not elem: continue
            if not self._element_visible(elem): continue
            
            elem.visible = False
            
            mobj = self.mobject(name)
            self.remove(mobj)
            
            if mobj: plays.append(FadeOut(mobj))
        return plays
    
    def HideAll(self, **kwargs):
        return self.Hide([elem.name for elem in self.geo.elements], **kwargs)

    def Update(self, names, **kwargs):
        plays = []

        for name in names:
            elem = self.element(name)
            if not elem: continue
            
            mobj = self.mobject(name)
            self.remove(mobj)
            
            if mobj: plays.append(FadeOut(mobj))

            mobj_new = self.CreateMObject(elem)
            if mobj_new: self.addOrdered(mobj_new)
            
            if mobj_new: plays.append(FadeIn(mobj_new))
            
        return plays
    
    def UpdateAll(self, **kwargs):
        return self.Update([elem.name for elem in self.geo.elements], **kwargs)
    
    def ShowCreate(self, name, **kwargs):
        """Return animations that draw an element: ``Create`` for strokes,
        ``FadeIn`` for the filled first sub-mobject (for types with both)."""
        elem = self.element(name)
        mobj = self.mobject(name)
        if not elem or not mobj: return []
        
        if type(elem.data) in [geo.Polygon, geo.Circle, geo.Angle]:
            plays = [FadeIn(mobj[0], **kwargs)]
            for mo in mobj[1:]:
                plays.append(Create(mo, **kwargs))
            return plays
        else:
            return [Create(mobj, **kwargs)]

    def Show(self, names, mode = 'Fade', **kwargs):
        plays = []

        for name in names:
            elem = self.element(name)
            if not elem: continue
            if self._element_visible(elem): continue
            
            elem.visible = True

            mobj_new = self.CreateMObject(elem)
            if mobj_new: self.addOrdered(mobj_new)
            
            if mobj_new: 
                if mode == 'Create':
                    plays += self.ShowCreate(name, **kwargs)
                else:
                    plays.append(FadeIn(mobj_new, **kwargs))
            
        return plays
    
    def ShowAll(self, **kwargs):
        return self.Show([elem.name for elem in self.geo.elements], **kwargs)
    
    def Shade(self, names, **kwargs):
        plays = []
        for name in names:
            mobj = self.mobject(name)
            if not mobj: continue
            elem = self.geo.element(name)
            if not elem: continue

            self._styles_back[name] = {}

            if elem.style.get('z_index'): 
                self._styles_back[name]['z_index'] = elem.style['z_index']
                elem.style['z_index'] = 0

            if elem.style.get('stroke'): 
                self._styles_back[name]['stroke'] = elem.style['stroke']
                elem.style['stroke'] = self.style.col_shade

            if elem.style.get('fill'):
                self._styles_back[name]['fill'] = elem.style['fill']
                elem.style['fill'] = self.style.col_shade

            if elem.style.get('label_visible'):
                self._styles_back[name]['label_color'] = elem.style['label_color'] if ('label_color' in elem.style) else self.style.strong
                elem.style['label_color'] = self.style.col_shade

            if type(elem.data) == geo.Point:
                self._styles_back[name]['fill_opacity'] = elem.style['fill_opacity'] if ('fill_opacity' in elem.style) else 1
                elem.style['fill_opacity'] = 0

            self._shade_mobjects['_shade_' + name] = self.CreateMObject(elem)
            plays.extend(self.Hide([name], **kwargs))
            plays.append(FadeIn(self._shade_mobjects['_shade_' + name], **kwargs))

        return plays

    def Restore(self, names, **kwargs):
        plays = []
        for name in names:
            mobj = self.mobject(name)
            if not mobj: continue
            if name not in self._styles_back: continue
            elem = self.geo.element(name)
            style_back = self._styles_back[name]
            if (not elem) or (not style_back): continue

            for key in style_back: elem.style[key] = style_back[key]

            plays.extend(self.Show([name], **kwargs))
            plays.append(FadeOut(self._shade_mobjects['_shade_' + name], **kwargs))
            del self._shade_mobjects['_shade_' + name]

        return plays

    def setElementStyle(self, names, *, update=True, **props):
        """Set style properties on multiple elements at once.

        By default, mobjects for the touched elements are rerendered
        immediately so the change is visible in the next frame. Pass
        ``update=False`` to batch several setter calls and then trigger
        one combined rerender via ``updateAllGeometry`` or
        ``updateGeoElements(names)``.

        Example:
            self.setElementStyle(['a', 'b', 'c'], stroke='#ff0000', fill_opacity=0.5)
        """
        touched = []
        for name in names:
            elem = self.element(name)
            if elem is None:
                continue
            for key, value in props.items():
                elem.style[key] = value
            touched.append(name)
        if update and touched:
            self.updateGeoElements(updates=touched)

    def setVisible(self, names, visible, *, update=True):
        """Set visibility on multiple elements at once.

        Rerenders by default — geometry appears/disappears immediately.
        Pass ``update=False`` to defer rendering (combine with explicit
        ``updateGeoElements`` for bulk operations).
        """
        touched = []
        for name in names:
            elem = self.element(name)
            if elem is None:
                continue
            elem.visible = visible
            touched.append(name)
        if update and touched:
            self.updateGeoElements(updates=touched)

    def playHide(self, names, **kwargs):
        plays = self.Hide(names, **kwargs)
        if plays: self.play(*plays)
        
    def playUpdate(self, names, **kwargs):
        plays = self.Update(names, **kwargs)
        if plays: self.play(*plays)

    def playShow(self, names, mode = 'Fade', **kwargs):
        plays = self.Show(names, mode, **kwargs)
        if plays: self.play(*plays)

    def playShade(self, names, mode = 'Fade', **kwargs):
        plays = self.Shade(names, mode, **kwargs)
        if plays: self.play(*plays)

    def playRestore(self, names, mode = 'Fade', **kwargs):
        plays = self.Restore(names, mode, **kwargs)
        if plays: self.play(*plays)

    # ── Keyframe animation ────────────────────────────────────────────

    def get_independent_elements(self):
        """Return dict of independent (animatable) elements for keyframe UI.

        Returns dict: name -> {type, value/coords/tparam, constraint, ...}.
        Designed for web service to build a keyframe editing interface.
        """
        return self.geo.get_independents()

    def _apply_interp_value(self, name, kind, val):
        """Apply a single parsed (kind, val) to the construction in place.

        Shared between ``on_frame`` during keyframe playback and the
        snapshot pass that pre-computes per-keyframe label layouts.
        """
        apply_parsed_value(self.geo, name, kind, val)

    def _snapshot_independents(self):
        """Capture current values of every independent element as raw JSON.

        Returns a dict suitable for feeding back through _parse_value +
        _apply_interp_value to restore state after the snapshot pass.
        """
        info_map = self.geo.get_independents()
        raw = {}
        for name, info in info_map.items():
            etype = info['type']
            if etype == 'free_point':
                raw[name] = list(info['coords'])
            elif etype == 'tparam_point':
                raw[name] = {'tparam': float(info['tparam'])}
            elif etype in ('number', 'measure', 'angle'):
                raw[name] = float(info['value'])
            elif etype == 'boolean':
                raw[name] = bool(info['value'])
        return raw, info_map

    def _apply_keyframe_state(self, kf, element_info, *, update_scene=True):
        """Apply one keyframe's values and visibility before playback starts."""
        from .keyframes import _parse_value

        touched = set()
        for name, raw_value in kf.values.items():
            info = element_info.get(name)
            if info is None:
                logger.warning(
                    "play_keyframes: skipping initial value for '%s' — element "
                    "is no longer independent",
                    name,
                )
                continue
            try:
                kind, val, _dir = _parse_value(name, raw_value, info)
            except (KeyError, ValueError, TypeError) as e:
                logger.warning(
                    "play_keyframes: bad initial keyframe value for '%s' (%r): %s",
                    name, raw_value, e,
                )
                continue
            self._apply_interp_value(name, kind, val)
            touched.add(name)

        for name in kf.show:
            elem = self.geo.element(name)
            if elem is not None:
                elem.visible = True
                touched.add(name)
        for name in kf.hide:
            elem = self.geo.element(name)
            if elem is not None:
                elem.visible = False
                touched.add(name)

        updates = self.geo.rebuild()
        touched.update(updates.keys())
        if update_scene and touched:
            self.updateGeoElements(touched)

    def _compute_keyframe_label_layouts(self, seq, cfg):
        """Run ``compute_label_layout`` at every keyframe. Restores state after.

        Walks keyframes carrying-forward values and visibility (matching the
        semantics of ``_build_intervals``). At each keyframe: apply, rebuild,
        snapshot layout. After the pass, restore saved values + visibility
        and do a full rebuild so the scene is identical to before the call.
        """
        from .label_placement import compute_label_layout, clear_bbox_cache
        from .keyframes import _parse_value

        canonicalize = bool(cfg.get('canonicalize_anchor', False))

        saved_raw, element_info = self._snapshot_independents()
        saved_visibility = {e.name: e.visible for e in self.geo.elements}

        clear_bbox_cache()

        # Carry-forward running state, starting from current construction values
        running_raw = dict(saved_raw)
        running_vis = dict(saved_visibility)

        layouts = []
        for kf in seq.keyframes:
            # Override with this keyframe's values
            for name, raw_value in kf.values.items():
                running_raw[name] = raw_value
            for name in kf.show:
                running_vis[name] = True
            for name in kf.hide:
                running_vis[name] = False

            # Apply to geo
            for name, raw_value in running_raw.items():
                info = element_info.get(name) or seq.element_info.get(name)
                if info is None:
                    logger.warning(
                        "play_keyframes: skipping value for '%s' — element "
                        "is no longer independent (was it rebound or removed "
                        "between sequence parse and playback?)",
                        name,
                    )
                    continue
                try:
                    kind, val, _dir = _parse_value(name, raw_value, info)
                except (KeyError, ValueError, TypeError) as e:
                    logger.warning(
                        "play_keyframes: bad keyframe value for '%s' (%r): %s",
                        name, raw_value, e,
                    )
                    continue
                self._apply_interp_value(name, kind, val)
            for name, vis in running_vis.items():
                e = self.geo.element(name)
                if e is not None:
                    e.visible = vis

            self.geo.rebuild()
            layouts.append(compute_label_layout(
                self, cfg=cfg, canonicalize=canonicalize,
            ))

        # Restore original state
        for name, raw_value in saved_raw.items():
            info = element_info.get(name)
            if info is None:
                logger.warning(
                    "play_keyframes: cannot restore '%s' — element disappeared "
                    "from the construction during the snapshot pass",
                    name,
                )
                continue
            try:
                kind, val, _dir = _parse_value(name, raw_value, info)
            except (KeyError, ValueError, TypeError) as e:
                logger.warning(
                    "play_keyframes: restore parse error for '%s' (%r): %s",
                    name, raw_value, e,
                )
                continue
            self._apply_interp_value(name, kind, val)
        for name, vis in saved_visibility.items():
            e = self.geo.element(name)
            if e is not None:
                e.visible = vis
        self.geo.rebuild(full=True)

        return layouts

    def play_keyframes(self, keyframes_data):
        """Play keyframe animation from JSON data or KeyframeSequence.

        When ``overlay.label_placement.keyframe_snapshots`` is true, runs a
        pre-pass to compute an auto-placed label layout at every keyframe;
        labels then interpolate smoothly between those layouts during
        playback. Angle labels additionally track their bisector per frame
        when ``dynamic_angles`` is true.

        Args:
            keyframes_data: dict (JSON) or KeyframeSequence instance
        """
        if isinstance(keyframes_data, dict):
            seq = KeyframeSequence.from_json(keyframes_data, self.geo)
        else:
            seq = keyframes_data
        logger.info("Playing %d keyframes", len(seq.keyframes))

        cfg = self.style_config.overlay.label_placement
        use_snapshots = bool(cfg.get('keyframe_snapshots', False))

        if use_snapshots:
            layouts = self._compute_keyframe_label_layouts(seq, cfg)
            seq.attach_label_layouts(layouts)

        self._apply_keyframe_state(seq.keyframes[0], seq.element_info)

        if use_snapshots and layouts and layouts[0]:
            from .label_placement import apply_label_layout
            apply_label_layout(self, layouts[0], rerender=True)

        for interval in seq.intervals:
            # Apply visibility changes at start of interval
            if interval.show:
                plays = self.Show(interval.show)
                if plays:
                    self.play(*plays, run_time=0.4)

            if interval.hide:
                plays = self.Hide(interval.hide)
                if plays:
                    self.play(*plays, run_time=0.4)

            has_labels = bool(interval.label_interps) or bool(interval.dynamic_angle_params)
            if not interval.interpolators and not has_labels:
                if interval.duration > 0:
                    self.wait(interval.duration)
                continue

            self._play_keyframe_interval(interval)

    def _play_keyframe_interval(self, interval):
        """Animate a single keyframe interval using ValueTracker + sentinel updater.

        The updater lives on a sentinel Mobject (not on the animated tracker),
        because manim does not deliver intermediate values to updaters attached
        to the mobject being animated.

        Order within ``on_frame``: geometry rebuild first, then label offsets
        (so ``ang.side1/2/p`` are fresh when ``compute_angle_label_center`` runs).
        Label names are merged into the ``updates`` dict so a single
        ``updateGeoElements`` call rebuilds both geometry and labels.
        """
        from .label_placement import compute_angle_label_offset_px

        progress = ValueTracker(0)
        sentinel = Mobject()   # invisible carrier for the updater
        interps = interval.interpolators
        label_interps = interval.label_interps
        dynamic_angle_params = interval.dynamic_angle_params
        geo_ref = self.geo
        scene_ref = self

        ptUnit = _style_ptUnit(self.style)
        ptUnit_ggb = self.style.export.get('ptUnit_ggb', ptUnit)

        def on_frame(mob):
            t = progress.get_value()
            touched = set()
            for interp in interps:
                val = interp.at(t)
                scene_ref._apply_interp_value(interp.name, interp.kind, val)
                touched.add(interp.name)

            updates = geo_ref.rebuild()
            for name in touched:
                updates[name] = updates.get(name, True)

            # Label offsets must be written AFTER geo.rebuild so that
            # ang.side1/2/p are up to date for compute_angle_label_center.
            for li in label_interps:
                elem = geo_ref.element(li.name)
                if elem is None or not scene_ref._element_visible(elem):
                    continue
                ox, oy = li.at(t)
                elem.style['label_offset_px'] = [float(ox), float(oy)]
                updates[li.name] = updates.get(li.name, True)

            for name, ap in dynamic_angle_params.items():
                elem = geo_ref.element(name)
                if elem is None or not scene_ref._element_visible(elem):
                    continue
                elem.style['label_offset_px'] = list(
                    compute_angle_label_offset_px(elem.data, ap, ptUnit, ptUnit_ggb)
                )
                updates[name] = updates.get(name, True)

            scene_ref.updateGeoElements(updates)

        sentinel.add_updater(on_frame)
        self.add(progress, sentinel)
        self.play(
            progress.animate(rate_func=linear).set_value(1),
            run_time=interval.duration,
        )
        sentinel.clear_updaters()
        self.remove(progress, sentinel)

    def exportSVG(self, filepath):
        if filepath is None:
            filepath = tempfile.mkstemp(suffix=".svg")
        filepath = os.path.abspath(filepath)
        logger.info("Exporting SVG to %s", filepath)
        
        with _get_cairo_context(filepath, self.style) as ctx:
            for mobj in extract_mobject_family_members(self.mobjects, True, True):
                if isinstance(mobj, ValueTracker): continue
                _create_svg_from_vmobject_internal(mobj, ctx, style = self.style)
        try:
            size = os.path.getsize(filepath)
            logger.info("SVG exported: %s (%d bytes)", filepath, size)
        except OSError:
            logger.info("SVG exported: %s", filepath)

    def exportStylePromptSummary(self, filepath=None, **kwargs):
        """Export a compact construction summary for AI style generation.

        The summary is versioned as ``animageo-construction-summary/v1`` and
        contains element names, canonical types, compact geometry, visibility,
        selected ``ggb_style`` keys, optional explicit/resolved style layers,
        and parser diagnostics. It deliberately omits raw ``.ggb`` XML.

        Args:
            filepath: optional JSON output path. If omitted, only returns the
                summary dict.
            **kwargs: forwarded to
                :func:`animageo.exporters.construction_summary.construction_to_ai_summary`.

        Returns:
            The summary dict.
        """
        from .exporters.construction_summary import (
            construction_to_ai_summary,
            write_ai_summary,
        )
        from .style.resolver import resolved_style

        viewport = kwargs.pop('viewport', None)
        if viewport is None:
            export = getattr(self.style, 'export', {}) or {}
            viewport = {
                'size': [
                    export.get('ptWidth'),
                    export.get('ptHeight'),
                ],
                'ptUnit': export.get('ptUnit'),
                'ptUnit_style': export.get('ptUnit_style'),
                'ptUnit_ggb': export.get('ptUnit_ggb'),
                'ptXZero': export.get('ptXZero'),
                'ptYZero': export.get('ptYZero'),
                'reference_size': [
                    export.get('referenceWidth'),
                    export.get('referenceHeight'),
                ],
                'contentScale': export.get('contentScale'),
                'fontSize': export.get('fontSize'),
            }

        source = kwargs.pop('source', None) or getattr(self, '_construction_source', None)
        kwargs.setdefault('resolved_style_fn', lambda elem: resolved_style(self, elem))

        if filepath is None:
            return construction_to_ai_summary(
                self.geo,
                source=source,
                viewport=viewport,
                **kwargs,
            )
        return write_ai_summary(
            self.geo,
            filepath,
            source=source,
            viewport=viewport,
            **kwargs,
        )
    
    def addGrid(self, x_range=(-10, 10, 1), y_range=(-10, 10, 1)):
        grid = NumberPlane(
            x_range = x_range,
            y_range = y_range,
            x_length = x_range[1] - x_range[0],
            y_length = y_range[1] - y_range[0],
            background_line_style = {
                "stroke_color": BLACK,
                "stroke_width": stroke_width_to_manim(
                    self.style_config.defaults.get('line', 'stroke_width_px', 1),
                    _style_ptUnit(self.style),
                ),
                "stroke_opacity": 0.1
            },
            x_axis_config = {"stroke_opacity": 0},
            y_axis_config = {"stroke_opacity": 0}
        )

        self.add(grid.shift(-grid.get_origin()))
        return grid

    def addCoordinateBackground(self):
        """Render imported GeoGebra grid/axes as a quiet background layer."""
        export = self.style.export
        if not (export.get('showGrid') or export.get('showAxes')):
            return None

        old = self.mobject('_coordinate_background')
        if old is not None:
            self.remove(old)

        bounds = self._get_scene_bounds(padding=0)
        left, bottom, right, top = bounds
        ptUnit = _style_ptUnit(self.style)

        grid_color = export.get('gridColor', '#c0c0c0')
        axes_color = export.get('axesColor', '#252525')
        grid_width = 0.65 if not export.get('gridIsBold') else 0.9
        axis_width = 1.25
        x_grid_step = float(export.get('gridDistX') or export.get('gridStep', 1) or 1)
        y_grid_step = float(export.get('gridDistY') or export.get('gridStep', 1) or 1)
        if x_grid_step <= 0:
            x_grid_step = 1.0
        if y_grid_step <= 0:
            y_grid_step = 1.0

        group = VGroup(name='_coordinate_background')

        def values_between(lo, hi, step):
            first = np.ceil(lo / step) * step
            last = np.floor(hi / step) * step
            if first > last:
                return []
            count = int(round((last - first) / step)) + 1
            if count > 1000:
                step *= np.ceil(count / 1000)
                first = np.ceil(lo / step) * step
                last = np.floor(hi / step) * step
                count = int(round((last - first) / step)) + 1
            return [first + i * step for i in range(max(count, 0))]

        axes = export.get('axes') or {}
        def axis_visible(axis_key):
            value = (axes.get(axis_key) or {}).get('show')
            return bool(export.get('showAxes') if value is None else value)

        show_x_axis = axis_visible('x')
        show_y_axis = axis_visible('y')

        if export.get('showGrid'):
            for x in values_between(left, right, x_grid_step):
                if show_y_axis and np.isclose(x, 0):
                    continue
                group.add(Line(
                    [x, bottom, 0], [x, top, 0],
                    color=grid_color,
                    stroke_width=stroke_width_to_manim(grid_width, ptUnit),
                    stroke_opacity=0.38,
                ).set_z_index(-20))
            for y in values_between(bottom, top, y_grid_step):
                if show_x_axis and np.isclose(y, 0):
                    continue
                group.add(Line(
                    [left, y, 0], [right, y, 0],
                    color=grid_color,
                    stroke_width=stroke_width_to_manim(grid_width, ptUnit),
                    stroke_opacity=0.38,
                ).set_z_index(-20))

        def add_axis_numbers(axis_key, values, line_coord, horizontal=True):
            axis_cfg = axes.get(axis_key) or {}
            if axis_cfg.get('showNumbers') is False:
                return
            step = x_grid_step if axis_key == 'x' else y_grid_step
            if len(values) > 40 or ptUnit * step < 24:
                return
            font_size = 10 * GGB_FONT_SCALE / ptUnit
            offset = 10 / ptUnit
            for value in values:
                if np.isclose(value, 0):
                    continue
                text = str(int(round(value))) if np.isclose(value, round(value)) else f"{value:.2f}".rstrip('0').rstrip('.')
                label = Text(text, font_size=font_size, color=axes_color)
                label.set_opacity(0.72)
                if horizontal:
                    label.move_to([value, line_coord - offset, 0])
                else:
                    label.move_to([line_coord - offset, value, 0])
                    label.shift(LEFT * label.width / 2)
                group.add(label.set_z_index(-9))

        if export.get('showAxes'):
            tick = 4 / ptUnit
            x_tick_step = float((axes.get('x') or {}).get('tickDistance') or x_grid_step)
            y_tick_step = float((axes.get('y') or {}).get('tickDistance') or y_grid_step)
            if x_tick_step <= 0:
                x_tick_step = x_grid_step
            if y_tick_step <= 0:
                y_tick_step = y_grid_step
            x_values = values_between(left, right, x_tick_step)
            y_values = values_between(bottom, top, y_tick_step)
            if show_x_axis and bottom <= 0 <= top:
                group.add(Line(
                    [left, 0, 0], [right, 0, 0],
                    color=axes_color,
                    stroke_width=stroke_width_to_manim(axis_width, ptUnit),
                    stroke_opacity=0.82,
                ).set_z_index(-10))
                for x in x_values:
                    if np.isclose(x, 0):
                        continue
                    group.add(Line(
                        [x, -tick, 0], [x, tick, 0],
                        color=axes_color,
                        stroke_width=stroke_width_to_manim(0.75, ptUnit),
                        stroke_opacity=0.58,
                    ).set_z_index(-9))
                add_axis_numbers('x', x_values, 0, horizontal=True)

            if show_y_axis and left <= 0 <= right:
                group.add(Line(
                    [0, bottom, 0], [0, top, 0],
                    color=axes_color,
                    stroke_width=stroke_width_to_manim(axis_width, ptUnit),
                    stroke_opacity=0.82,
                ).set_z_index(-10))
                for y in y_values:
                    if np.isclose(y, 0):
                        continue
                    group.add(Line(
                        [-tick, y, 0], [tick, y, 0],
                        color=axes_color,
                        stroke_width=stroke_width_to_manim(0.75, ptUnit),
                        stroke_opacity=0.58,
                    ).set_z_index(-9))
                add_axis_numbers('y', y_values, 0, horizontal=False)

        if len(group) == 0:
            return None
        self.add(group)
        return group
    
    def _get_scene_bounds(self, padding=0.1):
        """Return (left, bottom, right, top) of the current camera viewport in
        scene coordinates.

        Used by Line/Ray clipping to compute endpoints that safely extend
        beyond the visible area. ``padding`` (scene units) is added on each
        side so the stroke's cap never lands on the frame edge. Reads from
        ``self.camera.frame`` (set up by ``applyStyle``), so the bounds
        always reflect the active export size and zero offset.
        """
        frame = self.camera.frame
        return (
            frame.get_left()[0] - padding,
            frame.get_bottom()[1] - padding,
            frame.get_right()[0] + padding,
            frame.get_top()[1] + padding,
        )

    def _getAngRadius(self, ang: geo.Angle):
        r = self.style.ang_rdefault / _style_ptUnit(self.style)
        max_r = min(np.linalg.norm(ang.side1), np.linalg.norm(ang.side2)) * 0.65
        if ang.size > 0.01:
            return min(max_r, r / ang.size**0.25)
        else:
            return min(max_r, r / 0.01**0.25)
 
    def _getRightAngSize(self, ang: geo.Angle):
        r = self.style.ang_right / _style_ptUnit(self.style)
        max_r = min(np.linalg.norm(ang.side1), np.linalg.norm(ang.side2)) * 0.65
        return min(max_r, r)

    # ── CreateMObject helpers ─────────────────────────────────────────

    def _build_render_ctx(self, elem, z_auto):
        """Compute per-element render context: colours, opacities, stroke
        width, label properties, z-index. Called once per ``CreateMObject``;
        values are then read by type-specific ``_render_<type>`` methods.
        """
        style = self.style
        ptUnit = style.export['ptUnit']
        ptUnit_style = _style_ptUnit(style)
        ptUnit_ggb = style.export.get('ptUnit_ggb', ptUnit_style)

        # Colours / opacities through the resolver (elem.style -> overlay ->
        # defaults). Fallback `default=` covers types/keys not yet fully
        # described in builtin defaults.
        stroke_default = str(style.strong)
        fill_default = str(style.strong if type(elem.data) == geo.Point else style.background)
        col_s = ManimColor(_resolve_style(self, elem, 'stroke', default=stroke_default))
        col_f = ManimColor(_resolve_style(self, elem, 'fill', default=fill_default))
        op_s = _resolve_style(self, elem, 'stroke_opacity', default=1)
        op_f = _resolve_style(self, elem, 'fill_opacity', default=1)
        col_label = ManimColor(_resolve_style(self, elem, 'label_color', default=str(style.strong)))

        # Stroke width and all visual sizes below are canonical pixel-unit
        # fields resolved from StyleConfig + GGB import + overlay + explicit
        # elem.style. Scene-level GeoStyle fields are import-time context only
        # and are not a render-time fallback.
        lw = _resolve_style(self, elem, 'stroke_width_px', default=1.0)
        lw = stroke_width_to_manim(lw, ptUnit_style)

        fs_px = _resolve_style(self, elem, 'font_size_px', default=14.0)
        font_size = fs_px * GGB_FONT_SCALE / ptUnit_style
        label_anchor = _resolve_style(
            self, elem, 'label_anchor',
            default=style.rendering.get('label_anchor'),
        )
        ggb_font_px = self.style.export.get('fontSize')
        has_label = (_resolve_style(self, elem, 'label_visible', default=False) is True)
        label_text = resolve_label_text(self, elem)
        label_offset_px = _resolve_style(self, elem, 'label_offset_px', default=None)
        auto_placed = bool(elem.style.get('_auto_placed'))
        lr_px = _resolve_style(self, elem, 'label_radial_offset_px', default=0.0)
        label_roff = float(lr_px) / ptUnit_style

        dash = _resolve_style(self, elem, 'stroke_dash_ratio', default=None)
        cap = _resolve_style(
            self, elem, 'stroke_linecap',
            default=style.rendering.get('line_cap', 'butt'),
        )
        ra_joint = _resolve_style(
            self, elem, 'right_angle_joint',
            default=style.rendering.get('right_angle_joint', 'auto'),
        )

        # Decoration geometry (tick length/shift, vector arrows) uses scene
        # coordinates, so pixel values become MU via /ptUnit_style. Tick width is
        # different: it is passed to Manim's stroke_width/set_stroke(width=...),
        # the same render-unit system as stroke_width_px.
        def _px(elem_key, fallback_px=0.0):
            return float(_resolve_style(self, elem, elem_key, default=fallback_px) or 0.0) / ptUnit_style

        strich_len_mu    = _px('tick_length_px')
        tick_width_px    = _resolve_style(self, elem, 'tick_width_px', default=0.0)
        strich_width     = stroke_width_to_manim(tick_width_px or 0.0, ptUnit_style)
        strich_rshift_mu = _px('tick_shift_px')
        arrow_w_mu       = _px('arrow_width_px')
        arrow_h_mu       = _px('arrow_length_px')

        tick_count = int(_resolve_style(self, elem, 'tick_count', default=0) or 0)
        tick_style = _resolve_style(self, elem, 'tick_style', default='line')
        tick_radius_px = _resolve_style(self, elem, 'tick_radius_px', default=None)
        angle_range = _resolve_style(self, elem, 'angle_range', default='minor') or 'minor'
        arc_shift_px = _resolve_style(self, elem, 'arc_shift_px', default=0.0)
        right_angle_marker = _resolve_style(self, elem, 'right_angle_marker', default=None)
        auto_radius = _resolve_style(self, elem, 'auto_radius', default=True)

        zz = _resolve_style(self, elem, 'z_index', default=None)
        zz_fill = _resolve_style(self, elem, 'z_index_fill', default=Z_FILL)
        if zz is None and z_auto:
            zz = _Z_AUTO_BY_TYPE.get(type(elem.data))
        if zz is None:
            zz = Z_FILL
        zz_label = Z_FILL_LABEL if zz == Z_FILL else Z_LABEL

        return SimpleNamespace(
            style=style,
            ptUnit=ptUnit, ptUnit_style=ptUnit_style, ptUnit_ggb=ptUnit_ggb,
            col_s=col_s, col_f=col_f,
            op_s=op_s, op_f=op_f,
            col_label=col_label,
            lw=lw,
            font_size=font_size,
            label_anchor=label_anchor,
            label_text=label_text,
            label_offset_px=label_offset_px,
            auto_placed=auto_placed,
            ggb_font_px=ggb_font_px,
            has_label=has_label,
            label_roff=label_roff,
            strich_len=strich_len_mu,
            strich_width=strich_width,
            strich_rshift=strich_rshift_mu,
            arrow_width=arrow_w_mu,
            arrow_height=arrow_h_mu,
            tick_count=tick_count,
            tick_style=tick_style,
            tick_radius_px=tick_radius_px,
            angle_range=angle_range,
            arc_shift_px=arc_shift_px,
            right_angle_marker=right_angle_marker,
            auto_radius=auto_radius,
            dash=dash, cap=cap, ra_joint=ra_joint,
            zz=zz, zz_fill=zz_fill,
            zz_stroke=Z_STROKE, zz_label=zz_label,
        )

    def _renderer_for(self, elem):
        """Look up ``_render_<typename>`` on self, or None if no renderer."""
        return getattr(self, '_render_' + type(elem.data).__name__.lower(), None)

    def _make_label(self, elem, pos, ctx):
        """Shortcut for ``create_label`` wiring the ctx fields."""
        return create_label(
            elem, pos, ctx.col_label, ctx.font_size, ctx.zz_label,
            ctx.ptUnit_style, ptUnit_ggb=ctx.ptUnit_ggb, anchor=ctx.label_anchor,
            ggb_font_px=ctx.ggb_font_px, label_text=ctx.label_text,
            label_offset_px=ctx.label_offset_px, auto_placed=ctx.auto_placed,
        )

    # ── Per-type renderers ────────────────────────────────────────────

    def _render_polygon(self, elem, ctx):
        pp = [[p[0], p[1], 0] for p in elem.data.vertices]
        fill_layer = Polygon(
            *pp,
            color=ctx.col_s, fill_color=ctx.col_f, fill_opacity=ctx.op_f,
            stroke_width=0, stroke_opacity=0,
        ).set_z_index(ctx.zz)
        stroke_layer = Polygon(
            *pp, joint_type=LineJointType.ROUND,
            color=ctx.col_s, fill_opacity=0,
            stroke_width=ctx.lw, stroke_opacity=ctx.op_s,
        ).set_z_index(max(ctx.zz_stroke, ctx.zz + 0.1))
        arr = [fill_layer, stroke_layer]
        if ctx.has_label:
            center = np.mean(elem.data.vertices, axis=0)
            arr.append(self._make_label(elem, [center[0], center[1], 0], ctx))
        return VGroup(*arr, name=elem.name)

    def _render_angle(self, elem, ctx):
        style = ctx.style
        ptUnit = ctx.ptUnit_style
        arr = []

        angle_range = ctx.angle_range
        angle = elem.data.size
        is_clockwise = False
        # angle_range='minor': render the non-reflex (≤π) supplementary
        # angle. angle_range='reflex': render the reflex (>π) one.
        # Supplement is 2π − angle (NOT angle − π).
        if angle_range == 'minor' and angle > PI:
            is_clockwise = True
            angle = 2 * PI - angle
        elif angle_range == 'reflex' and angle < PI:
            is_clockwise = True
            angle = 2 * PI - angle

        from .label_placement import compute_effective_arc_size_px
        arc_size_resolved = _resolve_style(self, elem, 'arc_size_px', default=17.0)
        r = compute_effective_arc_size_px(
            elem, elem.data, self, base_px=arc_size_resolved,
            angle_range=ctx.angle_range, auto_radius=ctx.auto_radius,
        ) / ptUnit
        arc_shift_px = ctx.arc_shift_px
        r += (ctx.tick_count - 1) \
             * arc_shift_px / ptUnit
        if r < 0.001:
            r = 0.2

        p = [elem.data.vertex[0], elem.data.vertex[1], 0]
        lines = [None, None]
        lines[0 + is_clockwise] = Line(
            [p[0], p[1], 0],
            [p[0] + elem.data.side1[0], p[1] + elem.data.side1[1], 0],
        )
        lines[1 - is_clockwise] = Line(
            [p[0], p[1], 0],
            [p[0] + elem.data.side2[0], p[1] + elem.data.side2[1], 0],
        )
        # Sector starting direction must match the stroke arc direction:
        # non-flipped — CCW from v1 to v2; flipped — CCW from v2 to v1.
        if is_clockwise:
            rotation_angle = float(np.arctan2(elem.data.side2[1], elem.data.side2[0]))
        else:
            rotation_angle = elem.data.start_angle

        right_mark = ctx.right_angle_marker
        if right_mark is None:
            right_mark = np.isclose(angle, PI / 2)

        if right_mark:
            ar_cfg = self.style_config.overlay.angle_radius
            if ar_cfg.get('enabled', False) and ar_cfg.get('apply_to_right', False):
                base_px = compute_effective_arc_size_px(
                    elem, elem.data, self, base_px=arc_size_resolved,
                    angle_range=ctx.angle_range, auto_radius=ctx.auto_radius,
                )
                r = base_px / SQRT2 / ptUnit
            else:
                right_size_px = _resolve_style(
                    self, elem, 'right_angle_size_px', default=arc_size_resolved,
                )
                r = right_size_px / SQRT2 / ptUnit

            n1 = elem.data.side1 * (r / np.linalg.norm(elem.data.side1))
            n2 = elem.data.side2 * (r / np.linalg.norm(elem.data.side2))
            p1 = [p[0] + n1[0], p[1] + n1[1], 0]
            p2 = [p1[0] + n2[0], p1[1] + n2[1], 0]
            p3 = [p[0] + n2[0], p[1] + n2[1], 0]
            arr.append(Polygon(
                p, p1, p2, p3,
                color=ctx.col_f, stroke_width=0, fill_opacity=ctx.op_f,
            ).set_z_index(ctx.zz))
            arr.append(VMobject(
                color=ctx.col_s, fill_opacity=0,
                stroke_width=ctx.lw, stroke_opacity=ctx.op_s,
                joint_type=_JOINT_MAP[ctx.ra_joint],
            ).set_points_as_corners([p1, p2, p3]).set_z_index(ctx.zz + 0.1))
        else:
            arr.append(AnnularSector(
                inner_radius=0, outer_radius=r, angle=angle,
                color=ctx.col_f, fill_opacity=ctx.op_f,
            ).set_z_index(ctx.zz)
             .rotate(rotation_angle, about_point=ORIGIN)
             .shift([p[0], p[1], 0]))
            for i in range(ctx.tick_count):
                arr.append(Angle(
                    *lines, radius=r - i * arc_shift_px / ptUnit,
                    other_angle=False,
                    color=ctx.col_s, fill_opacity=0,
                    stroke_width=ctx.lw, stroke_opacity=ctx.op_s,
                ).set_z_index(ctx.zz + 0.1))

        if ctx.has_label:
            r += ctx.label_roff
            label_pos = Angle(*lines, radius=r).point_from_proportion(0.5)
            arr.append(self._make_label(elem, label_pos, ctx))
        return VGroup(*arr, name=elem.name)

    def _append_tick_marks(self, arr, p1, p2, m, normal, ctx):
        """Append segment/vector equality tick decorations to ``arr``.

        Tick geometry uses MU, but tick stroke width is already converted to
        Manim stroke units in ``_build_render_ctx``.
        """
        if not ctx.tick_count:
            return

        num = ctx.tick_count
        delta = p2 - p1
        delta_norm = np.linalg.norm(delta)
        normal_norm = np.linalg.norm(normal)
        if np.isclose(delta_norm, 0) or np.isclose(normal_norm, 0):
            return

        v = delta / delta_norm
        n = normal / normal_norm
        dn = n * ctx.strich_len / 2

        if ctx.tick_style == 'wave':
            s = ctx.strich_rshift * 1.7
            l = ctx.strich_len * 0.8
            radius = ctx.tick_radius_px / ctx.ptUnit_style if ctx.tick_radius_px is not None else s * 0.45
            t = (l - 2 * radius) / (s - 2 * radius)
            offset = t * s / 2
            sign = 1

            points = []
            d = s * ((1 - num) * 0.5) + s / 2 - l / (2 * t)
            points.append(list(m + v * d + n * (l / 2) * sign) + [0])
            sign = -sign
            for i in range(1, num, 1):
                d = s * ((1 - num) * 0.5 + i)
                points.append(list(m + v * d + n * offset * sign) + [0])
                sign = -sign
            d = s * ((1 + num) * 0.5) - s / 2 + l / (2 * t)
            points.append(list(m + v * d + n * (l / 2) * sign) + [0])

            arr.append(round_corners_vmobject(
                points, radius=radius, components_per_rounded_corner=8,
            ).set_stroke(
                color=ctx.col_s, width=ctx.strich_width, opacity=ctx.op_s,
            ).set_z_index(ctx.zz))
            return

        line = Line(
            [m[0] + dn[0], m[1] + dn[1], 0],
            [m[0] - dn[0], m[1] - dn[1], 0],
            color=ctx.col_s, stroke_width=ctx.strich_width,
            stroke_opacity=ctx.op_s,
        ).set_z_index(ctx.zz)
        for i in range(num):
            d = ctx.strich_rshift * ((1 - num) * 0.5 + i)
            arr.append(line.copy().shift([v[0] * d, v[1] * d, 0]))

    def _render_segment(self, elem, ctx):
        style = ctx.style
        p1, p2 = elem.data.endpoints
        m = (p1 + p2) / 2
        arr = []

        if ctx.dash:
            arr.append(DashedLine(
                [p1[0], p1[1], 0], [p2[0], p2[1], 0],
                color=ctx.col_s, stroke_opacity=ctx.op_s, stroke_width=ctx.lw,
                cap_style=_CAP_MAP[ctx.cap],
                dash_length=0.17, dashed_ratio=ctx.dash,
            ).set_z_index(ctx.zz))
        else:
            arr.append(Line(
                [p1[0], p1[1], 0], [p2[0], p2[1], 0],
                color=ctx.col_s, stroke_opacity=ctx.op_s, stroke_width=ctx.lw,
                cap_style=_CAP_MAP[ctx.cap],
            ).set_z_index(ctx.zz))

        self._append_tick_marks(arr, p1, p2, m, elem.data.normal, ctx)

        if ctx.has_label:
            arr.append(self._make_label(elem, [m[0], m[1], 0], ctx))
        return VGroup(*arr, name=elem.name)

    def _render_line(self, elem, ctx):
        """Render geo.Line; also handles geo.Ray (shared implementation —
        see ``_render_ray`` alias below).
        """
        left, bottom, right, top = self._get_scene_bounds()
        endpoints = elem.data.get_endpoints([(left, bottom), (right, top)])
        if endpoints is None:
            return None
        p1, p2 = endpoints
        arr = []
        if ctx.dash:
            arr.append(DashedLine(
                [p1[0], p1[1], 0], [p2[0], p2[1], 0],
                color=ctx.col_s, stroke_opacity=ctx.op_s, stroke_width=ctx.lw,
                cap_style=_CAP_MAP[ctx.cap],
                dash_length=0.17, dashed_ratio=ctx.dash,
            ).set_z_index(ctx.zz))
        else:
            arr.append(Line(
                [p1[0], p1[1], 0], [p2[0], p2[1], 0],
                color=ctx.col_s, stroke_opacity=ctx.op_s, stroke_width=ctx.lw,
                cap_style=_CAP_MAP[ctx.cap],
            ).set_z_index(ctx.zz))
        if ctx.has_label:
            m = (p1 + p2) / 2
            arr.append(self._make_label(elem, [m[0], m[1], 0], ctx))
        return VGroup(*arr, name=elem.name)

    # Ray shares Line's clipping/rendering logic verbatim.
    _render_ray = _render_line

    def _render_vector(self, elem, ctx):
        style = ctx.style
        p1, p2 = elem.data.endpoints
        m = (p1 + p2) / 2
        arr = []

        if ctx.dash:
            arr.append(DashedLine(
                [p1[0], p1[1], 0], [p2[0], p2[1], 0],
                color=ctx.col_s, stroke_opacity=ctx.op_s, stroke_width=ctx.lw,
                cap_style=_CAP_MAP[ctx.cap],
                dash_length=0.17, dashed_ratio=ctx.dash,
            ).set_z_index(ctx.zz))
        else:
            arr.append(Arrow(
                [p1[0], p1[1], 0], [p2[0], p2[1], 0],
                buff=0, tip_shape=CustomArrowTip,
                tip_style={'width': ctx.arrow_width,
                           'height': ctx.arrow_height,
                           'fill': ctx.col_s},
                color=ctx.col_s, stroke_opacity=ctx.op_s,
                stroke_width=ctx.lw, cap_style=_CAP_MAP[ctx.cap],
            ).set_z_index(ctx.zz))

        normal = np.array([p1[1] - p2[1], p2[0] - p1[0]])
        self._append_tick_marks(arr, p1, p2, m, normal, ctx)

        if ctx.has_label:
            arr.append(self._make_label(elem, [m[0], m[1], 0], ctx))
        return VGroup(*arr, name=elem.name)

    def _render_circle(self, elem, ctx):
        c = [elem.data.center[0], elem.data.center[1], 0]
        circ_fill = Circle(
            name=elem.name, arc_center=c, radius=elem.data.radius,
            fill_color=ctx.col_f, fill_opacity=ctx.op_f,
            stroke_opacity=0, stroke_width=0,
        ).set_z_index(ctx.zz_fill)
        circ_stroke = Circle(
            name=elem.name, arc_center=c, radius=elem.data.radius,
            color=ctx.col_s, fill_opacity=0,
            stroke_opacity=ctx.op_s, stroke_width=ctx.lw,
        ).set_z_index(ctx.zz)
        if ctx.dash:
            circ_stroke = DashedVMobject(
                circ_stroke,
                num_dashes=int(2 * np.pi * elem.data.radius / 0.17),
                dashed_ratio=ctx.dash,
            ).set_z_index(ctx.zz)
        return VGroup(circ_fill, circ_stroke, name=elem.name)

    def _render_arc(self, elem, ctx):
        c = [elem.data.center[0], elem.data.center[1], 0]
        a1, a2 = elem.data.angles
        angle = (a2 - a1) % (2 * np.pi)
        arr = [
            Arc(arc_center=c, radius=elem.data.radius,
                start_angle=a1, angle=angle,
                fill_color=ctx.col_f, fill_opacity=ctx.op_f,
                stroke_width=0).set_z_index(ctx.zz_fill),
            Arc(arc_center=c, radius=elem.data.radius,
                start_angle=a1, angle=angle,
                color=ctx.col_s, fill_opacity=0,
                stroke_opacity=ctx.op_s, stroke_width=ctx.lw,
                cap_style=_CAP_MAP[ctx.cap]).set_z_index(ctx.zz),
        ]
        if ctx.has_label:
            label_pos = Arc(
                arc_center=c, radius=elem.data.radius + 0.7,
                start_angle=a1, angle=a2 - a1,
            ).point_from_proportion(0.5)
            arr.append(self._make_label(elem, label_pos, ctx))
        return VGroup(*arr, name=elem.name)

    def _render_circlesector(self, elem, ctx):
        c = [elem.data.center[0], elem.data.center[1], 0]
        a1, a2 = elem.data.angles
        angle_diff = a2 - a1

        arr = [
            Sector(arc_center=c, radius=elem.data.radius,
                   start_angle=a1, angle=angle_diff,
                   fill_color=ctx.col_f, fill_opacity=ctx.op_f,
                   stroke_width=0).set_z_index(ctx.zz_fill),
            Arc(arc_center=c, radius=elem.data.radius,
                start_angle=a1, angle=angle_diff,
                color=ctx.col_s, fill_opacity=0,
                stroke_opacity=ctx.op_s, stroke_width=ctx.lw,
                cap_style=_CAP_MAP[ctx.cap]).set_z_index(ctx.zz),
        ]
        if ctx.has_label:
            mid_angle = a1 + angle_diff / 2
            label_pos = c + elem.data.radius * 0.7 * np.array(
                [np.cos(mid_angle), np.sin(mid_angle), 0],
            )
            arr.append(self._make_label(elem, label_pos, ctx))
        return VGroup(*arr, name=elem.name)

    # ── Point shape helper ─────────────────────────────────────────────

    @staticmethod
    def _make_point_mobject(shape, pos, radius, col_s, col_f, op_f, op_s, lw, zz):
        """Create a manim Mobject for a point with the given shape.

        All shapes are sized so their circumradius equals *radius*.
        """
        if shape is None or shape == 'circle':
            return Circle(
                arc_center=pos, radius=radius,
                color=col_s, fill_color=col_f, fill_opacity=op_f,
                stroke_opacity=op_s, stroke_width=lw,
            ).set_z_index(zz)
        if shape == 'square':
            side = radius * np.sqrt(2)
            return Square(
                side_length=side,
                color=col_s, fill_color=col_f, fill_opacity=op_f,
                stroke_opacity=op_s, stroke_width=lw,
            ).move_to(pos).set_z_index(zz)
        if shape == 'triangle_up':
            return _scaled_triangle(pos, radius, 0, col_s, col_f, op_f, op_s, lw, zz)
        if shape == 'triangle_down':
            return _scaled_triangle(pos, radius, PI, col_s, col_f, op_f, op_s, lw, zz)
        if shape == 'triangle_right':
            return _scaled_triangle(pos, radius, -PI / 2, col_s, col_f, op_f, op_s, lw, zz)
        if shape == 'triangle_left':
            return _scaled_triangle(pos, radius, PI / 2, col_s, col_f, op_f, op_s, lw, zz)
        if shape == 'cross':
            d = radius
            return VGroup(
                Line(
                    [pos[0] - d, pos[1] + d, 0],
                    [pos[0] + d, pos[1] - d, 0],
                    color=col_s, stroke_width=lw, stroke_opacity=op_s,
                ),
                Line(
                    [pos[0] - d, pos[1] - d, 0],
                    [pos[0] + d, pos[1] + d, 0],
                    color=col_s, stroke_width=lw, stroke_opacity=op_s,
                ),
            ).set_z_index(zz)
        if shape == 'plus':
            d = radius
            return VGroup(
                Line(
                    [pos[0] - d, pos[1], 0],
                    [pos[0] + d, pos[1], 0],
                    color=col_s, stroke_width=lw, stroke_opacity=op_s,
                ),
                Line(
                    [pos[0], pos[1] - d, 0],
                    [pos[0], pos[1] + d, 0],
                    color=col_s, stroke_width=lw, stroke_opacity=op_s,
                ),
            ).set_z_index(zz)
        # Unknown shape — fall back to circle
        return Circle(
            arc_center=pos, radius=radius,
            color=col_s, fill_color=col_f, fill_opacity=op_f,
            stroke_opacity=op_s, stroke_width=lw,
        ).set_z_index(zz)

    def _render_point(self, elem, ctx):
        style = ctx.style
        ptUnit = ctx.ptUnit_style
        radius = _resolve_style(self, elem, 'size_px', default=style.dot_size) \
                 / 2 / ptUnit
        point_shape = _resolve_style(self, elem, 'point_shape', default='circle')

        pos = [elem.data.coords[0], elem.data.coords[1], 0]
        mobj = self._make_point_mobject(
            point_shape, pos, radius,
            ctx.col_s, ctx.col_f, ctx.op_f, ctx.op_s, ctx.lw, ctx.zz,
        )
        arr = [mobj]

        if style.rendering.get('points_display') == 'only_labels':
            arr[0].set_fill(opacity=0)
            arr[0].set_stroke(opacity=0)
            arr[0].set_phantom(True)

        if ctx.has_label:
            arr.append(self._make_label(elem, pos, ctx))
            if style.rendering.get('points_display') == 'only_points':
                arr[1].set_fill(opacity=0)
                arr[1].set_phantom(True)

        return VGroup(*arr, name=elem.name)

    def _render_conic(self, elem, ctx):
        ptUnit = ctx.ptUnit
        conic = elem.data
        ctype = conic.type
        if ctype == ConicType.EMPTY:
            return None

        left, bottom, right_x, top_y = self._get_scene_bounds()
        viewport = (left, bottom, right_x, top_y)
        segment_mu = 3.0 / ptUnit   # adaptive sampler: ~3 px per segment

        arr = []

        if ctype == ConicType.POINT:
            p = conic.as_point()
            if p is not None:
                pos = [float(p.coords[0]), float(p.coords[1]), 0]
                arr.append(Dot(
                    point=pos, color=ctx.col_s, fill_opacity=ctx.op_f,
                ).set_z_index(ctx.zz))

        elif ctype == ConicType.CIRCLE:
            res = conic.as_circle()
            if res is not None:
                center, radius = res
                circ = Circle(
                    arc_center=[float(center[0]), float(center[1]), 0],
                    radius=radius,
                    color=ctx.col_s, fill_color=ctx.col_f,
                    fill_opacity=ctx.op_f, stroke_opacity=ctx.op_s,
                    stroke_width=ctx.lw,
                ).set_z_index(ctx.zz)
                if ctx.dash:
                    n_dashes = max(4, int(2 * np.pi * radius / 0.17))
                    circ = DashedVMobject(
                        circ, num_dashes=n_dashes, dashed_ratio=ctx.dash,
                    ).set_z_index(ctx.zz)
                arr.append(circ)

        elif ctype == ConicType.ELLIPSE:
            params = conic.as_ellipse()
            if params is not None:
                a_semi, b_semi = params['semi_axes']
                cx, cy = params['center']
                rot = params['rotation']
                ell = Ellipse(
                    width=2 * a_semi, height=2 * b_semi,
                    color=ctx.col_s, fill_color=ctx.col_f,
                    fill_opacity=ctx.op_f, stroke_opacity=ctx.op_s,
                    stroke_width=ctx.lw,
                ).rotate(rot).move_to([float(cx), float(cy), 0]).set_z_index(ctx.zz)
                arr.append(ell)

        elif ctype == ConicType.PARABOLA:
            params = conic.as_parabola()
            if params is not None:
                param_func = make_parabola_param(
                    params['vertex'], params['axis'],
                    params['perp'], params['focal_parameter'],
                )
                t_ranges = viewport_t_ranges_parabola(
                    params['vertex'], params['axis'], params['perp'],
                    params['focal_parameter'], viewport,
                )
                for tr in t_ranges:
                    polys = sample_parametric(
                        param_func, tr, viewport, segment_mu=segment_mu,
                    )
                    for poly in polys:
                        if len(poly) < 2:
                            continue
                        pts_3d = [[float(p[0]), float(p[1]), 0] for p in poly]
                        vm = VMobject(
                            color=ctx.col_s, stroke_opacity=ctx.op_s,
                            stroke_width=ctx.lw, fill_opacity=0,
                        )
                        vm.set_points_as_corners(pts_3d)
                        vm.set_z_index(ctx.zz)
                        arr.append(vm)

        elif ctype == ConicType.HYPERBOLA:
            params = conic.as_hyperbola()
            if params is not None:
                a_semi, b_semi = params['semi_axes']
                center_xy = params['center']
                rot = params['rotation']
                axis_u = np.array([np.cos(rot), np.sin(rot)])
                axis_v = np.array([-np.sin(rot), np.cos(rot)])
                for sign in (+1, -1):
                    tr = viewport_t_range_hyperbola_branch(
                        center_xy, axis_u, axis_v,
                        a_semi, b_semi, sign, viewport,
                    )
                    if tr is None:
                        continue
                    param_func = make_hyperbola_branch_param(
                        center_xy, axis_u, axis_v,
                        a_semi, b_semi, sign,
                    )
                    polys = sample_parametric(
                        param_func, tr, viewport, segment_mu=segment_mu,
                    )
                    for poly in polys:
                        if len(poly) < 2:
                            continue
                        pts_3d = [[float(p[0]), float(p[1]), 0] for p in poly]
                        vm = VMobject(
                            color=ctx.col_s, stroke_opacity=ctx.op_s,
                            stroke_width=ctx.lw, fill_opacity=0,
                        )
                        vm.set_points_as_corners(pts_3d)
                        vm.set_z_index(ctx.zz)
                        arr.append(vm)

        elif ctype in (ConicType.INTERSECTING_LINES,
                       ConicType.PARALLEL_LINES,
                       ConicType.DOUBLE_LINE):
            lines = conic.as_lines() or []
            corners = [(left, bottom), (right_x, top_y)]
            for ln in lines:
                endpoints = ln.get_endpoints(corners)
                if endpoints is None:
                    continue
                p1, p2 = endpoints
                arr.append(Line(
                    [float(p1[0]), float(p1[1]), 0],
                    [float(p2[0]), float(p2[1]), 0],
                    color=ctx.col_s, stroke_opacity=ctx.op_s,
                    stroke_width=ctx.lw,
                ).set_z_index(ctx.zz))

        if not arr:
            return None
        return VGroup(*arr, name=elem.name)

    def _render_function(self, elem, ctx):
        ptUnit = ctx.ptUnit
        func = elem.data
        left, bottom, right_x, top_y = self._get_scene_bounds()
        viewport = (left, bottom, right_x, top_y)
        segment_mu = 3.0 / ptUnit

        x_range = (left, right_x)
        if func.explicit_domain is not None:
            dom_lo, dom_hi = func.explicit_domain
            x_range = (max(x_range[0], dom_lo), min(x_range[1], dom_hi))
        if x_range[0] >= x_range[1]:
            return None

        def _fparam(t, f=func):
            return (float(t), float(f(t)))

        # Split x_range at every singularity that lies inside, stepping
        # back by ε so the sampler never calls f at the exact asymptote.
        sings = sorted(
            s for s in func.natural_singularities
            if x_range[0] < s < x_range[1]
        )
        width = x_range[1] - x_range[0]
        eps = max(width * 1e-3, 1e-6)
        edges = [x_range[0]] + sings + [x_range[1]]

        arr = []
        for k in range(len(edges) - 1):
            lo = edges[k] + (eps if k > 0 else 0.0)
            hi = edges[k + 1] - (eps if k < len(edges) - 2 else 0.0)
            if lo >= hi:
                continue
            polys = sample_parametric(
                _fparam, (lo, hi), viewport, segment_mu=segment_mu,
            )
            for poly in polys:
                if len(poly) < 2:
                    continue
                pts_3d = [[float(p[0]), float(p[1]), 0] for p in poly]
                vm = VMobject(
                    color=ctx.col_s, stroke_opacity=ctx.op_s,
                    stroke_width=ctx.lw, fill_opacity=0,
                )
                vm.set_points_as_corners(pts_3d)
                vm.set_z_index(ctx.zz)
                arr.append(vm)
        if not arr:
            return None
        return VGroup(*arr, name=elem.name)

    def _render_implicitcurve(self, elem, ctx):
        curve = elem.data
        left, bottom, right_x, top_y = self._get_scene_bounds()
        viewport = (left, bottom, right_x, top_y)

        segments = marching_squares(curve, viewport, grid_n=128)
        arr = []
        for seg in segments:
            if seg.shape[0] < 2:
                continue
            p1, p2 = seg[0], seg[1]
            ln = Line(
                [float(p1[0]), float(p1[1]), 0],
                [float(p2[0]), float(p2[1]), 0],
                color=ctx.col_s, stroke_opacity=ctx.op_s, stroke_width=ctx.lw,
            ).set_z_index(ctx.zz)
            arr.append(ln)
        if not arr:
            return None
        return VGroup(*arr, name=elem.name)

    def _render_locuscurve(self, elem, ctx):
        locus = elem.data
        if len(locus.points) < 2:
            return None
        pts_3d = [[float(p[0]), float(p[1]), 0] for p in locus.points]
        vm = VMobject(
            color=ctx.col_s, stroke_opacity=ctx.op_s,
            stroke_width=ctx.lw, fill_opacity=0,
        )
        vm.set_points_as_corners(pts_3d)
        vm.set_z_index(ctx.zz)
        return VGroup(vm, name=elem.name)

    def CreateMObject(self, elem, z_auto = False, debug = False):
        """Build a manim Mobject for a geometry element.

        Thin dispatcher: delegates to ``_render_<typename>`` for the
        per-type work. The shared preamble (colours, stroke, z-index,
        labels, cap/joint/dash) is computed once by
        ``_build_render_ctx`` and passed through a SimpleNamespace.
        All exceptions are caught and logged — failure to render one
        element must not abort the rest of the scene.
        """
        try:
            if not self._element_visible(elem):
                return None
            ctx = self._build_render_ctx(elem, z_auto)
            renderer = self._renderer_for(elem)
            if renderer is None:
                logger.warning(
                    'CreateMObject: no renderer for "%s" (type %s)',
                    elem.name, type(elem.data).__name__,
                )
                return None
            return renderer(elem, ctx)
        except Exception as e:
            logger.warning(
                'CreateMObject failed for "%s" (%s): %s\n%s',
                elem.name,
                type(elem.data).__name__ if elem.data else 'None',
                e,
                traceback.format_exc(),
            )
            return None
