"""Final label text resolution for GeoGebra-like label display modes."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import numpy as np

from .style.resolver import resolve as _resolve_style


LABEL_MODE_LABEL = "label"
LABEL_MODE_VALUE = "value"
LABEL_MODE_LABEL_VALUE = "label_value"
DEFAULT_LABEL_VALUE_PRECISION = 1
LABEL_MODES = frozenset({
    LABEL_MODE_LABEL,
    LABEL_MODE_VALUE,
    LABEL_MODE_LABEL_VALUE,
})


@dataclass(frozen=True)
class LabelValue:
    value: Any
    kind: str = "number"


def normalize_label_mode(value: Any) -> str:
    """Normalize user/GGB label-mode values to AnimaGeo string modes."""
    if value is None:
        return LABEL_MODE_LABEL
    if isinstance(value, bool):
        return LABEL_MODE_LABEL
    if isinstance(value, (int, float)):
        return geogebra_label_mode_to_style(int(value))
    text = str(value).strip().lower().replace("-", "_")
    aliases = {
        "name": LABEL_MODE_LABEL,
        "caption": LABEL_MODE_LABEL,
        "label": LABEL_MODE_LABEL,
        "value": LABEL_MODE_VALUE,
        "name_value": LABEL_MODE_LABEL_VALUE,
        "name_and_value": LABEL_MODE_LABEL_VALUE,
        "caption_value": LABEL_MODE_LABEL_VALUE,
        "caption_and_value": LABEL_MODE_LABEL_VALUE,
        "label_value": LABEL_MODE_LABEL_VALUE,
        "label_and_value": LABEL_MODE_LABEL_VALUE,
    }
    return aliases.get(text, LABEL_MODE_LABEL)


def geogebra_label_mode_to_style(value: int) -> str:
    """Map GeoGebra <labelMode val="..."> to AnimaGeo label modes.

    GeoGebra uses 0=name, 1=name+value, 2=value, 3=caption,
    9=caption+value. Caption text itself remains in ``label_text``.
    """
    if value in (1, 9):
        return LABEL_MODE_LABEL_VALUE
    if value == 2:
        return LABEL_MODE_VALUE
    return LABEL_MODE_LABEL


def resolve_label_text(scene, elem) -> str:
    """Return the final TeX label text for an element."""
    label_text = _resolve_style(scene, elem, "label_text", default="$" + elem.name + "$")
    mode = normalize_label_mode(_resolve_style(scene, elem, "label_mode", default=LABEL_MODE_LABEL))
    if mode == LABEL_MODE_LABEL:
        return str(label_text)

    formatted_value = format_label_value(scene, elem)
    if formatted_value is None:
        return str(label_text)
    if mode == LABEL_MODE_VALUE:
        return _math_wrap(formatted_value)

    separator = _resolve_style(scene, elem, "label_value_separator", default=" = ")
    return _math_wrap(_math_inner(str(label_text)) + str(separator) + _math_inner(formatted_value))


def format_label_value(scene, elem) -> str | None:
    """Format the value part of a label as TeX-safe text."""
    lv = label_value_of(elem)
    if lv is None:
        return None
    if lv.kind == "boolean":
        return r"\mathrm{" + ("true" if bool(lv.value) else "false") + "}"

    precision = _resolve_style(
        scene,
        elem,
        "label_value_precision",
        default=_rendering_default(
            scene,
            "label_value_precision",
            DEFAULT_LABEL_VALUE_PRECISION,
        ),
    )
    strip_zeros = bool(_resolve_style(scene, elem, "label_value_strip_zeros", default=True))
    if lv.kind == "angle":
        unit = _resolve_style(scene, elem, "label_angle_unit", default="degree")
        angle_value = _display_angle_value(scene, elem, float(lv.value))
        if unit == "radian":
            return _format_number(angle_value, precision, strip_zeros)
        degrees = angle_value * 180.0 / math.pi
        return _format_number(degrees, precision, strip_zeros) + r"^{\circ}"
    try:
        return _format_number(float(lv.value), precision, strip_zeros)
    except (TypeError, ValueError):
        return str(lv.value)


def label_value_of(elem) -> LabelValue | None:
    """Extract a scalar display value from an element or variable."""
    from .geo.lib_elements import Angle, Circle, Element, Polygon, Segment, Vector
    from .geo.lib_vars import AngleSize, Boolean, Measure, Var

    data = getattr(elem, "data", elem)
    if isinstance(elem, Var):
        data = elem.data
    if isinstance(elem, Element):
        data = elem.data

    if isinstance(data, AngleSize):
        return LabelValue(data.value, "angle")
    if isinstance(data, Angle):
        return LabelValue(data.value, "angle")
    if isinstance(data, Boolean):
        return LabelValue(data.value, "boolean")
    if isinstance(data, Measure):
        return LabelValue(data.value, "number")
    if isinstance(data, Segment):
        return LabelValue(data.length, "number")
    if isinstance(data, Vector):
        return LabelValue(float(np.linalg.norm(data.direction)), "number")
    if isinstance(data, Circle):
        return LabelValue(data.radius, "number")
    if isinstance(data, Polygon):
        return LabelValue(data.area, "number")
    if isinstance(data, (int, float)):
        return LabelValue(data, "number")
    return None


def _format_number(value: float, precision: Any, strip_zeros: bool) -> str:
    if not math.isfinite(value):
        if math.isnan(value):
            return r"\mathrm{NaN}"
        return r"\infty" if value > 0 else r"-\infty"
    try:
        precision_int = max(0, int(precision))
    except (TypeError, ValueError):
        precision_int = DEFAULT_LABEL_VALUE_PRECISION
    if abs(value) < 0.5 * 10 ** (-precision_int):
        value = 0.0
    text = f"{value:.{precision_int}f}"
    if strip_zeros and "." in text:
        text = text.rstrip("0").rstrip(".")
    return text


def _rendering_default(scene, key: str, default: Any) -> Any:
    cfg = getattr(scene, "style_config", None)
    if cfg is None and hasattr(scene, "rendering"):
        cfg = scene
    rendering = getattr(cfg, "rendering", None)
    if isinstance(rendering, dict) and key in rendering:
        return rendering[key]
    return default


def _display_angle_value(scene, elem, value: float) -> float:
    data = getattr(elem, "data", None)
    if type(data).__name__ != "Angle":
        return value
    angle_range = _resolve_style(scene, elem, "angle_range", default="minor") or "minor"
    if angle_range == "minor" and value > math.pi:
        return 2 * math.pi - value
    if angle_range == "reflex" and value < math.pi:
        return 2 * math.pi - value
    return value


def _math_inner(text: str) -> str:
    if len(text) >= 2 and text[0] == "$" and text[-1] == "$":
        return text[1:-1]
    return text


def _math_wrap(text: str) -> str:
    if len(text) >= 2 and text[0] == "$" and text[-1] == "$":
        return text
    return "$" + text + "$"
