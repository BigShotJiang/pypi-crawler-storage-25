"""Pydantic models for Fine-Tuning validation.

Validates fine-tuning dataset generation and training start requests
with constraints from the ToothFairyAI Fine-Tuning API spec.
"""

from typing import Any, Dict, List, Optional

from pydantic import Field, model_validator

from .base import ToothFairyModel


class FinetuningTrainingType(str):
    CONVERSATIONAL = "conversationalTraining"
    GENERATIVE = "generativeTraining"
    GRPO = "grpoTraining"
    KTO = "ktoTraining"
    CPT = "continuedPretraining"


class DatasetGenerateModel(ToothFairyModel):
    """Validation model for generating a fine-tuning dataset.

    Required fields:
        - name: Human-readable name for the training job
        - training_type: Training method (SFT, DPO, GRPO, KTO, CPT)
        - base_model: Base model canonical ID from /models endpoint

    Optional LoRA and training hyperparameters:
        - lora_r: LoRA rank (default 8)
        - lora_alpha: LoRA alpha (default 8)
        - num_epochs: Training epochs (default 1)
        - batch_size: Batch size per device (default 2)
        - learning_rate: Learning rate string (default '2e-4')
        - max_seq_length: Max sequence length (default 2048)
    """

    name: str = Field(..., min_length=1, max_length=200)
    training_type: str = Field(...)
    base_model: str = Field(..., min_length=1)
    topics: Optional[List[str]] = None
    lora_r: Optional[int] = Field(None, ge=1, le=128)
    lora_alpha: Optional[int] = Field(None, ge=1, le=128)
    num_epochs: Optional[int] = Field(None, ge=1, le=100)
    batch_size: Optional[int] = Field(None, ge=1, le=64)
    learning_rate: Optional[str] = None
    max_seq_length: Optional[int] = Field(None, ge=128, le=8192)

    @model_validator(mode="after")
    def validate_training_type(self) -> "DatasetGenerateModel":
        valid = {
            "conversationalTraining",
            "generativeTraining",
            "grpoTraining",
            "ktoTraining",
            "continuedPretraining",
        }
        if self.training_type not in valid:
            raise ValueError(
                f"training_type must be one of {valid}. Got '{self.training_type}'."
            )
        return self

    def to_api_payload(self, exclude_none: bool = True) -> Dict[str, Any]:
        payload = super().to_api_payload(exclude_none=exclude_none)

        standard_mappings = [
            ("training_type", "trainingType"),
            ("base_model", "baseModel"),
            ("lora_r", "loraR"),
            ("lora_alpha", "loraAlpha"),
            ("num_epochs", "numEpochs"),
            ("batch_size", "batchSize"),
            ("learning_rate", "learningRate"),
            ("max_seq_length", "maxSeqLength"),
        ]

        for snake_key, camel_key in standard_mappings:
            if snake_key in payload:
                payload[camel_key] = payload.pop(snake_key)

        return payload


class StartTrainingModel(ToothFairyModel):
    """Validation model for starting a fine-tuning training job.

    All fields optional — only provided fields override defaults.
    """

    use_spot_instances: Optional[bool] = None
    hyperparameters_override: Optional[Dict[str, Any]] = None
    grpo_reward_funcs: Optional[str] = None
    grpo_num_generations: Optional[int] = Field(None, ge=1, le=16)
    dpo_beta: Optional[float] = Field(None, ge=0.0, le=1.0)
    kto_beta: Optional[float] = Field(None, ge=0.0, le=1.0)

    def to_api_payload(self, exclude_none: bool = True) -> Dict[str, Any]:
        payload = super().to_api_payload(exclude_none=exclude_none)

        standard_mappings = [
            ("use_spot_instances", "useSpotInstances"),
            ("hyperparameters_override", "hyperparametersOverride"),
            ("grpo_reward_funcs", "grpoRewardFuncs"),
            ("grpo_num_generations", "grpoNumGenerations"),
            ("dpo_beta", "dpoBeta"),
            ("kto_beta", "ktoBeta"),
        ]

        for snake_key, camel_key in standard_mappings:
            if snake_key in payload:
                payload[camel_key] = payload.pop(snake_key)

        return payload
