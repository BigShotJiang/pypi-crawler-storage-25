"""Fine-tuning manager for handling training jobs, datasets, and models."""

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..types import (
    TrainableModel,
    TrainingJob,
    TrainingStatusResponse,
)

if TYPE_CHECKING:
    from ..client import ToothFairyClient


class FinetuningManager:
    """Manager for fine-tuning operations.

    This manager provides methods to list trainable models, generate datasets,
    start training, monitor job status, and cancel training jobs.

    Example:
        >>> client = ToothFairyClient(api_key="...", workspace_id="...")
        >>> models = client.finetuning.list_models()
        >>> job = client.finetuning.generate_dataset(
        ...     name="my-sft-job",
        ...     training_type="conversationalTraining",
        ...     base_model="toothfairyai/Llama-3.2-1B-Instruct"
        ... )
        >>> status = client.finetuning.get_status(job["training_log_id"])
    """

    def __init__(self, client: "ToothFairyClient"):
        self._client = client

    def list_models(self) -> List[TrainableModel]:
        """List all trainable models with their configurations.

        This is a public endpoint — no authentication required.

        Returns:
            List of TrainableModel objects with supported training methods,
            instance types, and estimated UoI cost per hour.
        """
        response = self._client.finetuning_request("GET", "/models")
        models = response.get("models", []) if isinstance(response, dict) else []
        return [TrainableModel.from_dict(m) for m in models]

    def list_jobs(self) -> List[TrainingJob]:
        """List all fine-tuning jobs for the authenticated workspace.

        Returns:
            List of TrainingJob objects with status, base model, and
            training type information.
        """
        response = self._client.finetuning_request("GET", "/jobs")
        jobs = response.get("jobs", []) if isinstance(response, dict) else []
        return [TrainingJob.from_dict(j) for j in jobs]

    def generate_dataset(
        self,
        name: str,
        training_type: str,
        base_model: str,
        topics: Optional[List[str]] = None,
        lora_r: Optional[int] = None,
        lora_alpha: Optional[int] = None,
        num_epochs: Optional[int] = None,
        batch_size: Optional[int] = None,
        learning_rate: Optional[str] = None,
        max_seq_length: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Generate a training dataset from workspace documents.

        Args:
            name: Human-readable name for the training job.
            training_type: Training method (conversationalTraining,
                generativeTraining, grpoTraining, ktoTraining,
                continuedPretraining).
            base_model: Base model canonical ID from /models endpoint.
            topics: Optional list of topic IDs to filter documents.
            lora_r: LoRA rank (default 8).
            lora_alpha: LoRA alpha (default 8).
            num_epochs: Number of training epochs (default 1).
            batch_size: Training batch size per device (default 2).
            learning_rate: Learning rate string (default '2e-4').
            max_seq_length: Maximum sequence length (default 2048).

        Returns:
            Dict with training_log_id, status, and message.
        """
        data: Dict[str, Any] = {
            "name": name,
            "trainingType": training_type,
            "baseModel": base_model,
        }

        if topics is not None:
            data["topics"] = topics
        if lora_r is not None:
            data["loraR"] = lora_r
        if lora_alpha is not None:
            data["loraAlpha"] = lora_alpha
        if num_epochs is not None:
            data["numEpochs"] = num_epochs
        if batch_size is not None:
            data["batchSize"] = batch_size
        if learning_rate is not None:
            data["learningRate"] = learning_rate
        if max_seq_length is not None:
            data["maxSeqLength"] = max_seq_length

        return self._client.finetuning_request("POST", "/dataset", data=data)

    def get_status(self, training_log_id: str) -> TrainingStatusResponse:
        """Get detailed status of a fine-tuning job.

        Args:
            training_log_id: The training log ID returned by generate_dataset.

        Returns:
            TrainingStatusResponse with dataset info, training metrics,
            and presigned download URLs when available.
        """
        response = self._client.finetuning_request(
            "GET", f"/status/{training_log_id}"
        )
        return TrainingStatusResponse.from_dict(response)

    def start_training(
        self,
        training_log_id: str,
        use_spot_instances: Optional[bool] = None,
        hyperparameters_override: Optional[Dict[str, Any]] = None,
        grpo_reward_funcs: Optional[str] = None,
        grpo_num_generations: Optional[int] = None,
        dpo_beta: Optional[float] = None,
        kto_beta: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Start a fine-tuning training job.

        The job must be in 'datasetReady' status. Returns estimated UoI cost.

        Args:
            training_log_id: The training log ID to start training for.
            use_spot_instances: Use spot instances for cost savings (default True).
            hyperparameters_override: Optional overrides for training hyperparameters.
            grpo_reward_funcs: Comma-separated reward functions for GRPO.
            grpo_num_generations: Number of completions per prompt for GRPO.
            dpo_beta: DPO beta parameter (default 0.1).
            kto_beta: KTO beta parameter (default 0.1).

        Returns:
            Dict with training_log_id, status, estimated_uoi_cost,
            instance_type, and message.
        """
        data: Dict[str, Any] = {}

        if use_spot_instances is not None:
            data["useSpotInstances"] = use_spot_instances
        if hyperparameters_override is not None:
            data["hyperparametersOverride"] = hyperparameters_override
        if grpo_reward_funcs is not None:
            data["grpoRewardFuncs"] = grpo_reward_funcs
        if grpo_num_generations is not None:
            data["grpoNumGenerations"] = grpo_num_generations
        if dpo_beta is not None:
            data["dpoBeta"] = dpo_beta
        if kto_beta is not None:
            data["ktoBeta"] = kto_beta

        return self._client.finetuning_request(
            "POST", f"/start/{training_log_id}", data=data if data else None
        )

    def cancel_training(self, training_log_id: str) -> Dict[str, Any]:
        """Cancel a running fine-tuning job.

        Args:
            training_log_id: The training log ID to cancel.

        Returns:
            Dict with training_log_id, status, and message.
        """
        return self._client.finetuning_request(
            "POST", f"/cancel/{training_log_id}"
        )

    def generate_training_data(
        self,
        chat_id: Optional[str] = None,
        file_key: Optional[str] = None,
        training_type: str = "conversationalTraining",
        user_id: Optional[str] = None,
        create_document: bool = True,
        system_message: Optional[str] = None,
        instructions: Optional[str] = None,
        title: Optional[str] = None,
        topics: Optional[List[str]] = None,
        status: str = "draft",
        scope: str = "training",
        non_preferred_responses: Optional[List[Dict[str, Any]]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        generate_non_preferred: bool = False,
        chunk_size: Optional[int] = None,
        overlap_percent: Optional[float] = None,
        num_turns: Optional[int] = None,
        samples_per_chunk: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Transform a chat conversation or uploaded file into training data.

        Two mutually exclusive modes:
        - Chat mode: Provide chat_id to transform existing chat messages
        - File mode: Provide file_key to generate training data from an uploaded file

        Args:
            chat_id: Chat UUID to transform (mutually exclusive with file_key).
            file_key: S3 file key to generate from (mutually exclusive with chat_id).
            training_type: Training method (conversationalTraining, generativeTraining,
                grpoTraining, ktoTraining, continuedPretraining).
            user_id: User UUID performing the action.
            create_document: Whether to create a document in the database (default True).
            system_message: Optional custom system message for training data.
            instructions: Optional instructions for LLM-based refinement.
            title: Optional document title.
            topics: Optional list of topic IDs to associate.
            status: Document status - "draft" or "published" (default "draft").
            scope: Document scope - "training" or "validation" (default "training").
            non_preferred_responses: For DPO - list of non-preferred responses.
            tools: Optional function calling tools for training data.
            generate_non_preferred: Auto-generate non-preferred for DPO (default False).
            chunk_size: File mode - characters per chunk (default 2000).
            overlap_percent: File mode - overlap between chunks (default 0.15).
            num_turns: File mode - turns per chunk conversation (default 5).
            samples_per_chunk: File mode - samples per chunk (default 1).

        Returns:
            Dict with rawTrainingData, messageCount, sourceType, documentCreated,
            and optionally document details.
        """
        if not chat_id and not file_key:
            raise ValueError("Either 'chat_id' or 'file_key' is required")
        if chat_id and file_key:
            raise ValueError("Provide either 'chat_id' or 'file_key', not both")

        data: Dict[str, Any] = {
            "training_type": training_type,
            "create_document": create_document,
            "status": status,
            "scope": scope,
        }

        if chat_id is not None:
            data["chatid"] = chat_id
        if file_key is not None:
            data["file_key"] = file_key
        if user_id is not None:
            data["userid"] = user_id
        if system_message is not None:
            data["system_message"] = system_message
        if instructions is not None:
            data["instructions"] = instructions
        if title is not None:
            data["title"] = title
        if topics is not None:
            data["topics"] = topics
        if non_preferred_responses is not None:
            data["non_preferred_responses"] = non_preferred_responses
        if tools is not None:
            data["tools"] = tools
        if generate_non_preferred:
            data["generate_non_preferred"] = True

        if file_key is not None:
            if chunk_size is not None:
                data["chunk_size"] = chunk_size
            if overlap_percent is not None:
                data["overlap_percent"] = overlap_percent
            if num_turns is not None:
                data["num_turns"] = num_turns
            if samples_per_chunk is not None:
                data["samples_per_chunk"] = samples_per_chunk

        return self._client.ai_request("POST", "/magicwand", data=data)
