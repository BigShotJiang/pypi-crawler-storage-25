"""Benchmark manager for handling benchmarks operations."""

import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..types import Benchmark, BenchmarkRun, BenchmarkRunCreateData, ListResponse

if TYPE_CHECKING:
    from ..client import ToothFairyClient


class BenchmarkManager:
    """Manager for benchmarks operations.

    This manager provides methods to create, update, and manage benchmarks,
    as well as run benchmarks and track run status.

    Example:
        >>> client = ToothFairyClient(api_key="...", workspace_id="...")
        >>> benchmark = client.benchmarks.create(...)
        >>> run = client.benchmarks.run(benchmark_id="...", agent_id="...")
        >>> run = client.benchmarks.wait_for_run(run.id)
        >>> print(run.score)
    """

    def __init__(self, client: "ToothFairyClient"):
        self._client = client

    def create(
        self,
        name: str,
        description: Optional[str] = None,
        questions: Optional[List[Dict[str, str]]] = None,
        files: Optional[List[str]] = None,
    ) -> Benchmark:
        """Create a new benchmark.

        Args:
            name: Benchmark name (max 255 chars).
            description: Benchmark description (max 2048 chars).
            questions: List of benchmark questions. Each question dict must have:
                - "question" (required, max 6000 chars): The question to ask the agent
                - "answer" (required, max 6000 chars): The expected correct answer
                - "reasoning" (optional, max 6000 chars): Why this answer is correct
                - "context" (optional, max 6000 chars): Additional context for evaluation

                For convenience, use BenchmarkQuestion.to_dict() to build each item.

                CSV format for file upload (semicolon-delimited, double-quoted):
                    "question";"answer";"reasoning";"context"

                Compatibility:
                    - Standard BM (type="bm"): requires 1+ questions
                    - ABM Static (type="abm", mode="static"): requires 10-200 questions
                    - ABM Dynamic (type="abm", mode="dynamic"): requires 1+ questions
            files: List of S3 file paths associated with the benchmark.

        Returns:
            The created Benchmark object.
        """
        data: Dict[str, Any] = {
            "name": name,
        }

        if description is not None:
            data["description"] = description
        if questions is not None:
            data["questions"] = questions
        if files is not None:
            data["files"] = files

        response = self._client.request("POST", "/benchmark/create", data=data)
        return Benchmark.from_dict(response)

    def update(
        self,
        benchmark_id: str,
        **kwargs: Any,
    ) -> Benchmark:
        """Update a benchmark.

        Args:
            benchmark_id: ID of the benchmark to update.
            **kwargs: Fields to update.

        Returns:
            The updated Benchmark object.
        """
        data: Dict[str, Any] = {"id": benchmark_id}
        data.update(kwargs)
        response = self._client.request("POST", "/benchmark/update", data=data)
        return Benchmark.from_dict(response)

    def delete(self, benchmark_id: str) -> Dict[str, bool]:
        """Delete a benchmark.

        Args:
            benchmark_id: ID of the benchmark to delete.

        Returns:
            A dictionary with success status.
        """
        self._client.request("DELETE", f"/benchmark/delete/{benchmark_id}")
        return {"success": True}

    def get(self, benchmark_id: str) -> Benchmark:
        """Get a benchmark by ID.

        Args:
            benchmark_id: ID of the benchmark to retrieve.

        Returns:
            The Benchmark object.
        """
        response = self._client.request("GET", f"/benchmark/get/{benchmark_id}")
        return Benchmark.from_dict(response)

    def list(
        self,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> ListResponse:
        """List all benchmarks.

        Args:
            limit: Maximum number of benchmarks to return.
            offset: Number of benchmarks to skip.

        Returns:
            A ListResponse containing the benchmarks.
        """
        params: Dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        response = self._client.request("GET", "/benchmark/list", params=params)

        items = []
        if isinstance(response, list):
            items = [Benchmark.from_dict(item) for item in response]
        elif isinstance(response, dict):
            items = [Benchmark.from_dict(item) for item in response.get("items", [])]

        return ListResponse(items=items)

    def search(self, search_term: str) -> List[Benchmark]:
        """Search benchmarks by name.

        Args:
            search_term: Term to search for in benchmark names.

        Returns:
            A list of matching Benchmark objects.
        """
        all_benchmarks = self.list()
        search_lower = search_term.lower()
        return [
            benchmark
            for benchmark in all_benchmarks.items
            if search_lower in benchmark.name.lower()
        ]

    def run(
        self,
        benchmark_id: str,
        agent_id: str,
        type: str = "bm",
        mode: Optional[str] = None,
        reviewer_agent_id: Optional[str] = None,
        weights: Optional[Dict[str, float]] = None,
        passing_score: Optional[float] = None,
        num_questions: Optional[int] = None,
        name: Optional[str] = None,
        userid: Optional[str] = None,
    ) -> BenchmarkRun:
        """Start a benchmark run.

        Args:
            benchmark_id: ID of the benchmark to run.
            agent_id: ID of the agent to test.
            type: Run type - "bm" (standard) or "abm" (consistency).
            mode: ABM mode - "static" or "dynamic". Only for type="abm".
            reviewer_agent_id: ID of the reviewer agent (default: "sorcerer").
            weights: Category weights for scoring (e.g., {"correctness": 0.5, "reasoning": 0.3, "context_usage": 0.2}).
            passing_score: Minimum score to pass (0-1). Default: 0.9.
            num_questions: Number of questions to use. Default: all.
            name: Optional name for the run.
            userid: Optional user ID for the run.

        Returns:
            The created BenchmarkRun with status="dispatched".
        """
        data: Dict[str, Any] = {
            "benchmark_id": benchmark_id,
            "agent_id": agent_id,
            "type": type,
        }
        if mode is not None:
            data["mode"] = mode
        if reviewer_agent_id is not None:
            data["reviewer_agent_id"] = reviewer_agent_id
        if weights is not None:
            data["weights"] = weights
        if passing_score is not None:
            data["passing_score"] = passing_score
        if num_questions is not None:
            data["num_questions"] = num_questions
        if name is not None:
            data["name"] = name
        if userid is not None:
            data["userid"] = userid

        response = self._client.request("POST", "/benchmark/run", data=data)
        return BenchmarkRun.from_dict(response)

    def get_run(self, run_id: str) -> BenchmarkRun:
        """Get a benchmark run by ID.

        Args:
            run_id: ID of the benchmark run.

        Returns:
            The BenchmarkRun object with score and batch_meta populated if completed.
        """
        response = self._client.request("GET", f"/benchmark/run/{run_id}")
        return BenchmarkRun.from_dict(response)

    def list_runs(
        self,
        agent_id: Optional[str] = None,
        benchmark_id: Optional[str] = None,
        type: Optional[str] = None,
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> ListResponse:
        """List benchmark runs for the workspace.

        Args:
            agent_id: Filter by agent ID.
            benchmark_id: Filter by benchmark ID.
            type: Filter by run type ("bm" or "abm").
            status: Filter by status.
            limit: Maximum number of runs to return (default: 20).

        Returns:
            A ListResponse containing BenchmarkRun objects.
        """
        params: Dict[str, Any] = {}
        if agent_id is not None:
            params["agent_id"] = agent_id
        if benchmark_id is not None:
            params["benchmark_id"] = benchmark_id
        if type is not None:
            params["type"] = type
        if status is not None:
            params["status"] = status
        if limit is not None:
            params["limit"] = limit

        response = self._client.request("GET", "/benchmark/runs", params=params)

        items = []
        raw_items = response.get("items", []) if isinstance(response, dict) else response
        if isinstance(raw_items, list):
            items = [BenchmarkRun.from_dict(item) for item in raw_items]

        return ListResponse(items=items)

    def cancel_run(self, run_id: str) -> Dict[str, bool]:
        """Cancel a benchmark run.

        Args:
            run_id: ID of the benchmark run to cancel.

        Returns:
            A dictionary with success status.
        """
        self._client.request("DELETE", f"/benchmark/run/{run_id}")
        return {"success": True}

    def wait_for_run(
        self,
        run_id: str,
        poll_interval: float = 10.0,
        timeout: float = 1800.0,
    ) -> BenchmarkRun:
        """Wait for a benchmark run to complete.

        Polls the run status until it reaches a terminal state
        (completed, inError, cancelled) or the timeout is exceeded.

        Args:
            run_id: ID of the benchmark run to wait for.
            poll_interval: Seconds between status checks (default: 10).
            timeout: Maximum seconds to wait (default: 1800 = 30 min).

        Returns:
            The final BenchmarkRun object.

        Raises:
            TimeoutError: If the run doesn't complete within the timeout.
        """
        terminal_states = {"completed", "inError", "cancelled"}
        start = time.monotonic()

        while True:
            run = self.get_run(run_id)
            if run.status in terminal_states:
                return run

            elapsed = time.monotonic() - start
            if elapsed >= timeout:
                raise TimeoutError(
                    f"Benchmark run {run_id} did not complete within {timeout}s "
                    f"(current status: {run.status})"
                )

            time.sleep(poll_interval)
