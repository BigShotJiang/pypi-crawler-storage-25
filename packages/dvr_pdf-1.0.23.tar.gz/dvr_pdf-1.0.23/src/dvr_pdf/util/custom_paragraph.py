import re

from reportlab.lib.colors import Color
from reportlab.platypus import Paragraph, ParaParser


class _InlineStyle:
    pass


def _parse_css_color(value: str) -> Color | None:
    value = value.strip()
    rgb_match = re.match(r'rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)', value)
    if rgb_match:
        r, g, b = (int(c) for c in rgb_match.groups())
        return Color(r / 255, g / 255, b / 255)
    rgba_match = re.match(r'rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([\d.]+)\s*\)', value)
    if rgba_match:
        r, g, b = (int(c) for c in rgba_match.groups()[:3])
        a = float(rgba_match.group(4))
        return Color(r / 255, g / 255, b / 255, a)
    hex_match = re.match(r'#([0-9a-fA-F]{3,8})$', value)
    if hex_match:
        h = hex_match.group(1)
        if len(h) == 3:
            r, g, b = (int(c * 2, 16) for c in h)
            return Color(r / 255, g / 255, b / 255)
        if len(h) == 6:
            r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
            return Color(r / 255, g / 255, b / 255)
        if len(h) == 8:
            r, g, b, a = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), int(h[6:8], 16)
            return Color(r / 255, g / 255, b / 255, a / 255)
    return None


class CustomParser(ParaParser):
    def findSpanStyle(self, style: str):
        result = _InlineStyle()
        for declaration in style.split(';'):
            declaration = declaration.strip()
            if not declaration:
                continue
            if ':' not in declaration:
                continue
            prop, value = declaration.split(':', 1)
            prop = prop.strip().lower()
            if prop == 'color':
                color = _parse_css_color(value)
                if color:
                    result.textColor = color
            elif prop == 'background-color':
                color = _parse_css_color(value)
                if color:
                    result.backColor = color
        return result


class CustomParagraph(Paragraph):
    def __init__(self, text, style=None, bulletText=None, frags=None, caseSensitive=1, encoding='utf8'):
        super().__init__(text, style, bulletText, frags, caseSensitive, encoding)

    def _setup(self, text, style, bulletText, frags, cleaner):

        # This used to be a global parser to save overhead.
        # In the interests of thread safety it is being instantiated per paragraph.
        # On the next release, we'll replace with a cElementTree parser
        if frags is None:
            text = cleaner(text)
            _parser = CustomParser()
            _parser.caseSensitive = self.caseSensitive
            style, frags, bulletTextFrags = _parser.parse(text, style)
            if frags is None:
                raise ValueError("xml parser error (%s) in paragraph beginning\n'%s'" \
                                 % (_parser.errors[0], text[:min(30, len(text))]))
            textTransformFrags(frags, style)
            if bulletTextFrags: bulletText = bulletTextFrags

        # AR hack
        self.text = text
        self.frags = frags  # either the parse fragments or frag word list
        self.style = style
        self.bulletText = bulletText
        self.debug = 0  # turn this on to see a pretty one with all the margins etc.


def textTransformFrags(frags, style):
    tt = style.textTransform
    if tt:
        tt = tt.lower()
        if tt == 'lowercase':
            tt = str.lower
        elif tt == 'uppercase':
            tt = str.upper
        elif tt == 'capitalize':
            tt = str.title
        elif tt == 'none':
            return
        else:
            raise ValueError('ParaStyle.textTransform value %r is invalid' % style.textTransform)
        n = len(frags)
        if n == 1:
            # single fragment the easy case
            frags[0].text = tt(frags[0].text)
        elif tt is str.title:
            pb = True
            for f in frags:
                u = f.text
                if not u: continue
                if u.startswith(u' ') or pb:
                    u = tt(u)
                else:
                    i = u.find(u' ')
                    if i >= 0:
                        u = u[:i] + tt(u[i:])
                pb = u.endswith(u' ')
                f.text = u
        else:
            for f in frags:
                u = f.text
                if not u:
                    continue
                f.text = tt(u)
