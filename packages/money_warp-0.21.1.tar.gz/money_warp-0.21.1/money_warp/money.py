"""Money class for high-precision financial calculations."""

import numbers
from decimal import ROUND_HALF_UP, Decimal
from typing import Union


class Money:
    """
    Represents a monetary amount with high internal precision.

    Maintains full precision internally for calculations but provides
    'real money' representation rounded to 2 decimal places for display
    and comparisons.
    """

    def __init__(self, amount: Union[Decimal, str, int, float]) -> None:
        """
        Create a Money object with high internal precision.

        Args:
            amount: The monetary amount (will be converted to Decimal)
        """
        if isinstance(amount, float):
            # Convert float to string first to avoid precision issues
            self._amount = Decimal(str(amount))
        else:
            self._amount = Decimal(amount)

    @classmethod
    def zero(cls) -> "Money":
        """Create zero money."""
        return cls(0)

    @classmethod
    def from_cents(cls, cents: int) -> "Money":
        """Create from cents to avoid decimal issues."""
        return cls(Decimal(cents) / 100)

    def __add__(self, other: "Money") -> "Money":
        """Add two Money objects."""
        return Money(self._amount + other._amount)

    def __sub__(self, other: "Money") -> "Money":
        """Subtract two Money objects."""
        return Money(self._amount - other._amount)

    def __mul__(self, factor: Union[Decimal, int, float]) -> "Money":
        """Multiply by a number - keeps high precision."""
        return Money(self._amount * Decimal(str(factor)))

    def __truediv__(self, divisor: Union[Decimal, int, float]) -> "Money":
        """Divide by a number - keeps high precision."""
        return Money(self._amount / Decimal(str(divisor)))

    def __radd__(self, other: Union[Decimal, int, float]) -> "Money":
        """Support numeric + Money (e.g. Decimal + Money)."""
        if isinstance(other, (Decimal, int, float)):
            return Money(Decimal(str(other)) + self._amount)
        return NotImplemented

    def __rsub__(self, other: Union[Decimal, int, float]) -> "Money":
        """Support numeric - Money (e.g. Decimal - Money)."""
        if isinstance(other, (Decimal, int, float)):
            return Money(Decimal(str(other)) - self._amount)
        return NotImplemented

    def __rmul__(self, factor: Union[Decimal, int, float]) -> "Money":
        """Support numeric * Money (e.g. float * Money)."""
        if isinstance(factor, (Decimal, int, float)):
            return Money(self._amount * Decimal(str(factor)))
        return NotImplemented

    def __neg__(self) -> "Money":
        """Negative money."""
        return Money(-self._amount)

    def __abs__(self) -> "Money":
        """Absolute value."""
        return Money(abs(self._amount))

    def __float__(self) -> float:
        """Float representation using full internal precision."""
        return float(self._amount)

    def _compare_value(self, other: object) -> Union[Decimal, type(NotImplemented)]:
        """Extract the Decimal value to compare against, or NotImplemented."""
        if isinstance(other, Money):
            return other.real_amount
        if isinstance(other, (Decimal, int, float)):
            return Decimal(str(other))
        return NotImplemented

    def __eq__(self, other: object) -> bool:
        """Compare at 'real money' precision. Accepts Money or Decimal."""
        value = self._compare_value(other)
        if value is NotImplemented:
            return NotImplemented
        return self.real_amount == value

    def __lt__(self, other: Union["Money", Decimal]) -> bool:
        """Less than comparison at real money precision. Accepts Money or Decimal."""
        value = self._compare_value(other)
        if value is NotImplemented:
            return NotImplemented
        return self.real_amount < value

    def __le__(self, other: Union["Money", Decimal]) -> bool:
        """Less than or equal comparison at real money precision. Accepts Money or Decimal."""
        value = self._compare_value(other)
        if value is NotImplemented:
            return NotImplemented
        return self.real_amount <= value

    def __gt__(self, other: Union["Money", Decimal]) -> bool:
        """Greater than comparison at real money precision. Accepts Money or Decimal."""
        value = self._compare_value(other)
        if value is NotImplemented:
            return NotImplemented
        return self.real_amount > value

    def __ge__(self, other: Union["Money", Decimal]) -> bool:
        """Greater than or equal comparison at real money precision. Accepts Money or Decimal."""
        value = self._compare_value(other)
        if value is NotImplemented:
            return NotImplemented
        return self.real_amount >= value

    @property
    def raw_amount(self) -> Decimal:
        """Get the high-precision internal amount."""
        return self._amount

    @property
    def real_amount(self) -> Decimal:
        """Get the 'real money' amount rounded to 2 decimal places."""
        return self._amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @property
    def cents(self) -> int:
        """Get real amount in cents."""
        return int(self.real_amount * 100)

    def to_real_money(self) -> "Money":
        """Convert to real money (rounded to 2 decimal places)."""
        return Money(self.real_amount)

    def is_positive(self) -> bool:
        """Check if amount is positive."""
        return self.real_amount > 0

    def is_negative(self) -> bool:
        """Check if amount is negative."""
        return self.real_amount < 0

    def is_zero(self) -> bool:
        """Check if amount is zero."""
        return self.real_amount == 0

    def __str__(self) -> str:
        """Display as real money (2 decimal places)."""
        return f"{self.real_amount:,.2f}"

    def __repr__(self) -> str:
        """Developer representation showing internal precision."""
        return f"Money({self._amount})"

    def debug_precision(self) -> str:
        """Show both internal and real amounts for debugging."""
        return f"Internal: {self._amount}, Real: {self.real_amount}"


numbers.Real.register(Money)
