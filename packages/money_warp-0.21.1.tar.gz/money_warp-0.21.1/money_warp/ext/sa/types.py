"""SQLAlchemy TypeDecorators for Money, Rate, InterestRate, and DueDates."""

from datetime import date
from decimal import Decimal
from typing import Any, Dict, List, Optional, Type

from sqlalchemy import JSON, Integer, Numeric, String
from sqlalchemy.types import TypeDecorator

from money_warp.interest_rate import InterestRate
from money_warp.money import Money
from money_warp.rate import CompoundingFrequency, Rate, YearSize

_VALID_MONEY_REPRESENTATIONS = ("raw", "real", "cents")
_VALID_RATE_REPRESENTATIONS = ("string", "json")

_FREQUENCY_TOKEN = {
    CompoundingFrequency.ANNUALLY: "annual",
    CompoundingFrequency.MONTHLY: "monthly",
    CompoundingFrequency.DAILY: "daily",
    CompoundingFrequency.QUARTERLY: "quarterly",
    CompoundingFrequency.SEMI_ANNUALLY: "semi-annual",
}


class MoneyType(TypeDecorator):
    """SQLAlchemy column type for :class:`~money_warp.money.Money`.

    Args:
        precision: Total number of digits for the ``Numeric`` column
            (ignored when *representation* is ``"cents"``).
        scale: Number of fractional digits for the ``Numeric`` column
            (ignored when *representation* is ``"cents"``).
        representation: Controls storage format.
            ``"raw"`` (default) -- ``Numeric`` column storing ``raw_amount``.
            ``"real"`` -- ``Numeric`` column storing ``real_amount``.
            ``"cents"`` -- ``Integer`` column storing cents.
    """

    impl = Numeric
    cache_ok = True

    def __init__(
        self,
        precision: int = 20,
        scale: int = 10,
        representation: str = "raw",
    ) -> None:
        if representation not in _VALID_MONEY_REPRESENTATIONS:
            raise ValueError(
                f"Invalid representation: '{representation}'. Expected one of {_VALID_MONEY_REPRESENTATIONS}"
            )
        self.representation = representation
        self.precision = precision
        self.scale = scale
        super().__init__()

    def load_dialect_impl(self, dialect):
        if self.representation == "cents":
            return dialect.type_descriptor(Integer())
        return dialect.type_descriptor(Numeric(precision=self.precision, scale=self.scale))

    def process_bind_param(self, value, dialect) -> Any:
        if value is None:
            return None
        if isinstance(value, Money):
            if self.representation == "raw":
                return value.raw_amount
            if self.representation == "real":
                return value.real_amount
            return value.cents
        return value

    def process_result_value(self, value: Any, dialect) -> Optional[Money]:
        if value is None:
            return None
        if self.representation == "cents":
            return Money.from_cents(int(value))
        return Money(value)


class RateType(TypeDecorator):
    """SQLAlchemy column type for :class:`~money_warp.rate.Rate`.

    Args:
        representation: Controls storage format.
            ``"string"`` (default) -- ``String`` column like ``"5.250% annual"``.
            ``"json"`` -- ``JSON`` column with full params for lossless round-trip.
        year_size: Default year-size convention for string deserialization.
        precision: Default precision for string deserialization.
        rounding: Default rounding mode for string deserialization.
        str_style: Default str_style for string deserialization.
        str_decimals: Default decimal places for string serialization.
        abbrev_labels: Default abbreviation label overrides for string
            deserialization.
    """

    RATE_CLASS: Type[Rate] = Rate

    impl = String
    cache_ok = True

    def __init__(
        self,
        representation: str = "string",
        year_size: YearSize = YearSize.commercial,
        precision: int | None = None,
        rounding: str = "ROUND_HALF_UP",
        str_style: str = "long",
        str_decimals: int = 3,
        abbrev_labels: Optional[Dict[CompoundingFrequency, str]] = None,
    ) -> None:
        if representation not in _VALID_RATE_REPRESENTATIONS:
            raise ValueError(
                f"Invalid representation: '{representation}'. Expected one of {_VALID_RATE_REPRESENTATIONS}"
            )
        self.representation = representation
        self.rate_year_size = year_size
        self.rate_precision = precision
        self.rate_rounding = rounding
        self.rate_str_style = str_style
        self.rate_str_decimals = str_decimals
        self.rate_abbrev_labels = abbrev_labels
        super().__init__()

    def load_dialect_impl(self, dialect):
        if self.representation == "json":
            return dialect.type_descriptor(JSON())
        return dialect.type_descriptor(String())

    def process_bind_param(self, value: Optional[Rate], dialect) -> Any:
        if value is None:
            return None

        if self.representation == "string":
            is_abbrev = getattr(value, "_str_style", "long") == "abbrev"
            abbrev_map = getattr(value, "_abbrev_map", {})
            token = abbrev_map[value.period] if is_abbrev else _FREQUENCY_TOKEN[value.period]
            decimals = getattr(value, "_str_decimals", 3)
            return f"{value.as_percentage():.{decimals}f}% {token}"

        abbrev_labels = getattr(value, "_abbrev_labels", None)
        serialized_labels = {k.name.lower(): v for k, v in abbrev_labels.items()} if abbrev_labels else None
        return {
            "rate": str(value.as_decimal()),
            "period": value.period.name.lower(),
            "year_size": value.year_size.value,
            "precision": value._precision,
            "rounding": value._rounding,
            "str_style": value._str_style,
            "str_decimals": getattr(value, "_str_decimals", 3),
            "abbrev_labels": serialized_labels,
        }

    def process_result_value(self, value: Any, dialect) -> Optional[Rate]:
        if value is None:
            return None

        if self.representation == "string":
            return self._from_string(value)
        return self._from_dict(value)

    def _from_string(self, value: str) -> Rate:
        return self.RATE_CLASS(
            value,
            year_size=self.rate_year_size,
            precision=self.rate_precision,
            rounding=self.rate_rounding,
            str_style=self.rate_str_style,
            str_decimals=self.rate_str_decimals,
            abbrev_labels=self.rate_abbrev_labels,
        )

    def _from_dict(self, value: dict) -> Rate:
        rate = Decimal(str(value["rate"]))
        period = CompoundingFrequency[value["period"].upper()]
        year_size = YearSize(value["year_size"]) if "year_size" in value else self.rate_year_size
        precision = value.get("precision", self.rate_precision)
        rounding = value.get("rounding", self.rate_rounding)
        str_style = value.get("str_style", self.rate_str_style)
        str_decimals = value.get("str_decimals", self.rate_str_decimals)

        raw_labels = value.get("abbrev_labels")
        if raw_labels:
            abbrev_labels = {CompoundingFrequency[k.upper()]: v for k, v in raw_labels.items()}
        else:
            abbrev_labels = self.rate_abbrev_labels

        return self.RATE_CLASS(
            rate,
            period=period,
            year_size=year_size,
            precision=precision,
            rounding=rounding,
            str_style=str_style,
            str_decimals=str_decimals,
            abbrev_labels=abbrev_labels,
        )


class InterestRateType(RateType):
    """SQLAlchemy column type for :class:`~money_warp.interest_rate.InterestRate`.

    Identical to :class:`RateType` but constructs ``InterestRate`` instances,
    which reject negative values.
    """

    RATE_CLASS = InterestRate
    cache_ok = True


class DueDatesType(TypeDecorator):
    """SQLAlchemy column type for a list of due dates.

    Stores ``list[date]`` as a JSON array of ISO 8601 strings
    (``"YYYY-MM-DD"``).  On load, each string is parsed back to a
    :class:`~datetime.date`.

    Args:
        impl_type: The underlying SQLAlchemy column type.
            Defaults to ``JSON``.  Pass ``JSONB`` for PostgreSQL-native
            binary JSON.
    """

    impl = JSON
    cache_ok = True

    def __init__(self, impl_type: type = JSON) -> None:
        self.impl_type = impl_type
        super().__init__()

    def load_dialect_impl(self, dialect):
        return dialect.type_descriptor(self.impl_type())

    def process_bind_param(self, value: Optional[List[date]], dialect) -> Any:
        if value is None:
            return None
        return [d.isoformat() for d in value]

    def process_result_value(self, value: Any, dialect) -> Optional[List[date]]:
        if value is None:
            return None
        return [date.fromisoformat(s) for s in value]
