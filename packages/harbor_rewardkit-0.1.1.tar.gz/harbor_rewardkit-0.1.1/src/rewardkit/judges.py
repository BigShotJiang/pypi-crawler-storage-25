"""LLM and agent judges for rewardkit."""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import re
import shutil
import subprocess
from importlib import resources
from pathlib import Path
from typing import Any

import litellm

from rewardkit.models import AgentJudge, Criterion, LLMJudge, Score

logger = logging.getLogger(__name__)

_TEMPLATES: dict[str, str] = {}


def _load_template(name: str) -> str:
    if name not in _TEMPLATES:
        _TEMPLATES[name] = (
            resources.files("rewardkit.prompts").joinpath(f"{name}.md").read_text()
        )
    return _TEMPLATES[name]


def _build_criteria_block(criteria: list[Criterion]) -> str:
    lines: list[str] = []
    for c in criteria:
        fmt = c.output_format
        lines.append(f"- '{c.name}': {c.description} (score: {fmt.prompt_fragment()})")
    lines.append("")
    lines.append("Respond with a JSON object. Example:")
    example = {c.name: {"score": 1, "reasoning": "..."} for c in criteria}
    lines.append(json.dumps(example, indent=2))
    return "\n".join(lines)


def build_prompt(
    criteria: list[Criterion],
    template: str | None = None,
    kind: str = "llm",
) -> str:
    criteria_block = _build_criteria_block(criteria)
    tmpl = template if template is not None else _load_template(kind)
    return tmpl.replace("{criteria}", criteria_block)


_SKIP_DIRS = frozenset({"__pycache__", "node_modules", ".git"})
_MAX_FILE_SIZE = 1024 * 1024  # 1MB

_IMAGE_EXTENSIONS = frozenset({".jpg", ".jpeg", ".png", ".gif", ".webp"})
_IMAGE_MEDIA_TYPES: dict[str, str] = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
}
ContentBlock = dict[str, Any]


def _read_file_blocks(p: Path, label: str) -> list[ContentBlock]:
    """Read a single file into content blocks. Returns empty list on skip."""
    if p.name.startswith("."):
        return []
    try:
        size = p.stat().st_size
    except OSError:
        return [{"type": "text", "text": f"--- {label} ---\n[unreadable]"}]

    if size > _MAX_FILE_SIZE:
        return [{"type": "text", "text": f"--- {label} ---\n[skipped: file too large]"}]

    suffix = p.suffix.lower()
    if suffix in _IMAGE_EXTENSIONS:
        try:
            data = base64.b64encode(p.read_bytes()).decode("ascii")
            media_type = _IMAGE_MEDIA_TYPES[suffix]
            return [
                {"type": "text", "text": f"--- {label} ---"},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:{media_type};base64,{data}"},
                },
            ]
        except OSError:
            return [{"type": "text", "text": f"--- {label} ---\n[unreadable image]"}]

    # Try reading as text: binary files raise UnicodeDecodeError and are skipped.
    try:
        return [{"type": "text", "text": f"--- {label} ---\n{p.read_text()}"}]
    except (UnicodeDecodeError, OSError):
        return []


def _build_user_content(files: tuple[str, ...] | list[str]) -> list[ContentBlock]:
    """Build a list of content blocks (text and image) from file paths."""
    if not files:
        return []
    blocks: list[ContentBlock] = []
    for path_str in files:
        p = Path(path_str)
        if not p.exists():
            blocks.append({"type": "text", "text": f"--- {path_str} ---\n[not found]"})
            continue
        if p.is_file():
            blocks.extend(_read_file_blocks(p, path_str))
        elif p.is_dir():
            for child in sorted(p.iterdir()):
                if child.is_dir() and (
                    child.name in _SKIP_DIRS or child.name.startswith(".")
                ):
                    continue
                if child.is_file():
                    blocks.extend(_read_file_blocks(child, str(child)))
    return blocks


def _text_from_blocks(blocks: list[ContentBlock]) -> str:
    """Extract text-only content from blocks (for token counting)."""
    return "\n\n".join(b["text"] for b in blocks if b.get("type") == "text")


def parse_judge_response(
    text: str,
    criteria: list[Criterion],
    weights: list[float] | None,
) -> list[Score]:
    json_match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if json_match:
        data = json.loads(json_match.group(1))
    else:
        brace_match = re.search(r"\{.*\}", text, re.DOTALL)
        if brace_match:
            data = json.loads(brace_match.group(0))
        else:
            raise ValueError(f"Could not parse JSON from judge response: {text[:200]}")

    scores: list[Score] = []
    for i, c in enumerate(criteria):
        cname = c.name or f"criterion_{i}"
        entry = data.get(cname, {})
        raw_score = entry.get("score", 0)
        reasoning = entry.get("reasoning", "")
        value = c.output_format.normalize(raw_score)
        weight = weights[i] if weights else 1.0
        scores.append(
            Score(
                name=cname,
                value=value,
                raw=raw_score,
                weight=weight,
                reasoning=reasoning,
                description=c.description,
            )
        )
    return scores


def _fallback_scores(
    criteria: list[Criterion],
    weights: list[float] | None,
    error: str,
) -> list[Score]:
    return [
        Score(
            name=c.name or f"criterion_{i}",
            value=0.0,
            raw=False,
            weight=weights[i] if weights else 1.0,
            error=error,
            description=c.description,
        )
        for i, c in enumerate(criteria)
    ]


async def arun_llm(
    judge: LLMJudge,
    criteria: list[Criterion],
    weights: list[float] | None = None,
    system_prompt: str | None = None,
) -> tuple[list[Score], str, list[str]]:
    warn_list: list[str] = []
    if system_prompt:
        prompt = build_prompt(criteria, template=system_prompt)
    elif judge.atif_trajectory:
        prompt = build_prompt(criteria, kind="llm_trajectory")
    else:
        prompt = build_prompt(criteria)

    user_blocks = _build_user_content(judge.files)
    if judge.reference:
        ref_blocks = _build_user_content((judge.reference,))
        if ref_blocks:
            user_blocks.append(
                {
                    "type": "text",
                    "text": "## Reference Solution\nThe following is a reference solution. Compare the agent's work against it:",
                }
            )
            user_blocks.extend(ref_blocks)
    if judge.atif_trajectory:
        from rewardkit.trajectory import format_trajectory

        model_info = litellm.get_model_info(judge.model)
        max_input_tokens: int = model_info.get("max_input_tokens") or 200_000
        prompt_tokens = len(litellm.encode(model=judge.model, text=prompt))
        user_text = _text_from_blocks(user_blocks)
        user_tokens = (
            len(litellm.encode(model=judge.model, text=user_text)) if user_text else 0
        )
        available_tokens = max_input_tokens - prompt_tokens - user_tokens - 32_000

        traj_text = format_trajectory(
            judge.atif_trajectory,
            max_tokens=available_tokens,
            model=judge.model,
            warnings_out=warn_list,
        )
        user_blocks.append({"type": "text", "text": traj_text})

    messages: list[dict[str, Any]] = [{"role": "system", "content": prompt}]
    if user_blocks:
        messages.append({"role": "user", "content": user_blocks})
    resp = await litellm.acompletion(
        model=judge.model,
        messages=messages,
        response_format={"type": "json_object"},
        max_tokens=4096,
        timeout=judge.timeout,
        reasoning_effort=judge.reasoning_effort,
    )
    raw_output = resp.choices[0].message.content
    try:
        scores = parse_judge_response(raw_output, criteria, weights)
    except (ValueError, json.JSONDecodeError) as e:
        warn_list.append(f"Judge response parse error: {e}")
        scores = _fallback_scores(
            criteria, weights, f"Failed to parse judge response: {e}"
        )
    return scores, raw_output, warn_list


def _is_alpine() -> bool:
    return Path("/etc/alpine-release").exists()


def _install_npm_package(alpine_pkg: str, posix_script: str) -> None:
    if _is_alpine():
        subprocess.run(
            ["npm", "install", "-g", alpine_pkg],
            check=True,
            capture_output=True,
        )
    else:
        subprocess.run(
            ["bash", "-c", posix_script],
            check=True,
            capture_output=True,
        )
    local_bin = str(Path.home() / ".local" / "bin")
    if local_bin not in os.environ.get("PATH", ""):
        os.environ["PATH"] = f"{local_bin}:{os.environ.get('PATH', '')}"


_INSTALLERS: dict[str, tuple[str, str]] = {
    "claude": (
        "@anthropic-ai/claude-code",
        "curl -fsSL https://claude.ai/install.sh | bash",
    ),
    "codex": (
        "@openai/codex@latest",
        "curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.2/install.sh | bash && "
        'export NVM_DIR="$HOME/.nvm" && . "$NVM_DIR/nvm.sh" && '
        "nvm install 22 && npm install -g @openai/codex@latest && "
        'for bin in node codex; do ln -sf "$(which $bin)" "/usr/local/bin/$bin" 2>/dev/null || true; done',
    ),
}


def _ensure_cli(cmd_name: str) -> None:
    if shutil.which(cmd_name):
        return
    install_args = _INSTALLERS.get(cmd_name)
    if not install_args:
        raise FileNotFoundError(f"Agent CLI '{cmd_name}' not found in PATH")
    logger.info("Installing %s...", cmd_name)
    _install_npm_package(*install_args)
    if not shutil.which(cmd_name):
        raise FileNotFoundError(
            f"Agent CLI '{cmd_name}' not found after install attempt"
        )


async def arun_agent(
    judge: AgentJudge,
    criteria: list[Criterion],
    weights: list[float] | None = None,
    workspace: str | Path | None = None,
    system_prompt: str | None = None,
) -> tuple[list[Score], str, list[str]]:
    warn_list: list[str] = []
    if system_prompt:
        prompt = build_prompt(criteria, template=system_prompt)
    else:
        prompt = build_prompt(criteria, kind="agent")
    if judge.atif_trajectory:
        prompt += f"\n\nThe agent's trajectory is stored at: {judge.atif_trajectory}"
    if judge.agent == "claude-code":
        cmd = ["claude", "-p", prompt, "--output-format", "json"]
        cmd_name = "claude"
    else:
        cmd = ["codex", "-q", prompt]
        cmd_name = "codex"

    if judge.model:
        cmd.extend(["--model", judge.model])

    _ensure_cli(cmd_name)
    cwd = judge.cwd or (
        str(workspace) if workspace and Path(workspace).is_dir() else None
    )
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=cwd,
    )
    try:
        stdout, _stderr = await asyncio.wait_for(
            proc.communicate(), timeout=judge.timeout
        )
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        raise
    raw_output = stdout.decode()
    try:
        scores = parse_judge_response(raw_output, criteria, weights)
    except (ValueError, json.JSONDecodeError) as e:
        warn_list.append(f"Agent judge response parse error: {e}")
        scores = _fallback_scores(
            criteria, weights, f"Failed to parse agent judge response: {e}"
        )
    return scores, raw_output, warn_list
