"""Criterion: compare two images pixel-by-pixel and return similarity ratio."""

from pathlib import Path

from rewardkit.session import criterion


@criterion(description="Pixel similarity: {path1} vs {path2}")
def image_similarity(workspace: Path, path1: str, path2: str) -> float:
    try:
        from PIL import Image, ImageChops  # type: ignore[unresolved-import]
    except ImportError:
        raise ImportError(
            "image_similarity requires Pillow. "
            "Install with: pip install rewardkit[image]"
        )
    try:
        with (
            Image.open(workspace / path1) as img1,
            Image.open(workspace / path2) as img2,
        ):
            if img1.size != img2.size:
                return 0.0
            rgba1 = img1.convert("RGBA")
            rgba2 = img2.convert("RGBA")
            diff = ImageChops.difference(rgba1, rgba2)
            pixel_count = rgba1.size[0] * rgba1.size[1]
            # A pixel matches iff all 4 RGBA channels have zero difference.
            # Use per-channel point() to build a mask in C rather than Python loops.
            r, g, b, a = diff.split()

            def zero_fn(x: int) -> int:
                return 255 if x == 0 else 0

            mask = ImageChops.multiply(
                ImageChops.multiply(r.point(zero_fn), g.point(zero_fn)),
                ImageChops.multiply(b.point(zero_fn), a.point(zero_fn)),
            )
            matching = mask.tobytes().count(b"\xff")
            return matching / pixel_count
    except Exception:
        return 0.0
