"""Criterion: check that a specific CSV cell has the expected value."""

import csv
from pathlib import Path

from rewardkit.session import criterion


@criterion(description="Check that {path}[{row},{col}] == {expected!r}")
def csv_cell_equals(
    workspace: Path,
    path: str,
    row: int,
    col: int | str,
    expected: str,
) -> bool:
    try:
        with (workspace / path).open(newline="") as f:
            if isinstance(col, str):
                reader = csv.DictReader(f)
                for i, r in enumerate(reader):
                    if i == row:
                        return str(r.get(col, "")) == expected
                return False
            else:
                for i, r in enumerate(csv.reader(f)):
                    if i == row:
                        if col < len(r):
                            return r[col] == expected
                        return False
                return False
    except (FileNotFoundError, OSError, csv.Error, KeyError, IndexError):
        return False
