# Vic (v0.2.0)

**Vic** is a library built for "Natural Language Creation." It allows anyone to control their computer or generate fully functional, editable programs using simple English sentences.

## Key Features
- 🚀 **Zero Code**: Control your system or build apps by just describing them.
- 🎨 **Visual Dashboard**: A midnight-themed GUI for peak accessibility.
- 🛠️ **Editable Apps**: Built-in "Open in Editor" support to modify your creations instantly.
- 🧠 **Smarter Engine**: Auto-corrects typos (e.g., "opn calc" works!) and provides suggestions.
- 📦 **No Keys Required**: Advanced features like Weather apps work out-of-the-box using free APIs.

## Installation

```bash
cd "c:\my lib\naturalpy"
pip install -e .
```

Dependencies (recommended):
```bash
pip install psutil requests
```

## Quick Start

### 1. The Dashboard (Highly Recommended)
Launch the visual interface to start creating:
```bash
vic --gui
```

### 2. Command Line
Run quick commands from your terminal:
```bash
vic "open calculator"
vic "make a snake game"
vic "search for vic library documentation"
```

### 3. Interactive Mode
```bash
vic -i
```

## Making & Modifying
Vic is designed to help you learn. When you ask Vic to **"make a calculator"**, it generates a file named `calculator_app.py`. 
- In the Dashboard, click **"Modifice in Editor"** to open it.
- The code is heavily commented so you can see exactly how it works.

## Example Commands
- "open notepad"
- "what is my ip address"
- "make a loop that repeats 10 times"
- "build an inventory system"
- "say welcome to the world of Vic"
