import tkinter as tk
from tkinter import scrolledtext, messagebox
import subprocess
import os
import platform
from vic import Vic

class VicGUI:
    def __init__(self, root):
        self.root = root
        self.vic = Vic()
        self.root.title("Vic - Natural Language Interface")
        self.root.geometry("700x550")
        
        # --- UI DESIGN (Premium Dark Mode) ---
        self.bg_color = "#1e1e1e"
        self.fg_color = "#e0e0e0"
        self.accent_color = "#007acc"
        self.button_bg = "#333333"
        
        self.root.configure(bg=self.bg_color)
        
        # 1. Header
        header = tk.Label(
            root, text="VIC DASHBOARD", font=("Inter", 20, "bold"),
            bg=self.bg_color, fg=self.accent_color, pady=20
        )
        header.pack()

        # 2. Input Section
        input_frame = tk.Frame(root, bg=self.bg_color)
        input_frame.pack(pady=10, fill="x", padx=40)
        
        tk.Label(input_frame, text="Describe what you want:", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10)).pack(anchor="w")
        
        self.entry = tk.Entry(
            input_frame, font=("Inter", 14), bg="#2d2d2d", fg="white", 
            insertbackground="white", bd=0, highlightthickness=1, highlightbackground="#444444"
        )
        self.entry.pack(fill="x", pady=5, ipady=8)
        self.entry.bind("<Return>", lambda e: self.process_command())
        
        # 3. Action Buttons
        btn_frame = tk.Frame(root, bg=self.bg_color)
        btn_frame.pack(pady=10)
        
        self.run_btn = tk.Button(
            btn_frame, text="RUN COMMAND", command=self.process_command,
            bg=self.accent_color, fg="white", font=("Inter", 10, "bold"),
            padx=20, pady=5, bd=0, cursor="hand2"
        )
        self.run_btn.pack(side="left", padx=10)

        # 4. Output Section
        output_frame = tk.Frame(root, bg=self.bg_color)
        output_frame.pack(pady=20, fill="both", expand=True, padx=40)
        
        tk.Label(output_frame, text="Response:", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10)).pack(anchor="w")
        
        self.output_area = scrolledtext.ScrolledText(
            output_frame, font=("Consolas", 11), bg="#2d2d2d", fg="#d4d4d4",
            bd=0, padx=10, pady=10, insertbackground="white"
        )
        self.output_area.pack(fill="both", expand=True)

        # 5. Footer Controls
        footer_frame = tk.Frame(root, bg=self.bg_color)
        footer_frame.pack(pady=15, fill="x", padx=40)
        
        self.modify_btn = tk.Button(
            footer_frame, text="MODIFICE IN EDITOR", command=self.open_in_editor,
            bg=self.button_bg, fg="white", font=("Inter", 9),
            padx=15, pady=3, bd=0, cursor="hand2", state="disabled"
        )
        self.modify_btn.pack(side="left")
        
        self.copy_btn = tk.Button(
            footer_frame, text="COPY CODE", command=self.copy_to_clipboard,
            bg=self.button_bg, fg="white", font=("Inter", 9),
            padx=15, pady=3, bd=0, cursor="hand2"
        )
        self.copy_btn.pack(side="right")

        self.last_generated_file = None

    def process_command(self):
        sentence = self.entry.get().strip()
        if not sentence:
            return
        
        self.output_area.delete(1.0, tk.END)
        self.output_area.insert(tk.END, "Thinking...\n")
        self.root.update()
        
        result = self.vic.run(sentence)
        
        self.output_area.delete(1.0, tk.END)
        self.output_area.insert(tk.END, result)
        
        # Check if an app was built
        if "Successfully built full app:" in result:
            import re
            match = re.search(r'built full app: (\S+)', result)
            if match:
                self.last_generated_file = match.group(1)
                self.modify_btn.config(state="normal")
            else:
                self.modify_btn.config(state="disabled")
        else:
            self.modify_btn.config(state="disabled")

    def open_in_editor(self):
        if not self.last_generated_file:
            return
        
        path = os.path.abspath(self.last_generated_file)
        if platform.system() == "Windows":
            # Try VS Code first, then Notepad
            try:
                subprocess.Popen(["code", path], shell=True)
            except:
                subprocess.Popen(["notepad.exe", path])
        else:
            subprocess.Popen(["open", path])

    def copy_to_clipboard(self):
        text = self.output_area.get(1.0, tk.END)
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo("Vic", "Copied to clipboard!")

def main():
    root = tk.Tk()
    app = VicGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
