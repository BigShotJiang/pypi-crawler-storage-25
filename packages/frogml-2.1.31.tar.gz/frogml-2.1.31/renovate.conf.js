const svcPathParts = process.env.SERVICE_SRC_PATH.split("/");
const svcName = svcPathParts[svcPathParts.length - 1];
const renovatedBranch = process.env.RENOVATED_BRANCH;

module.exports = {
    platform: 'github',
    repositories: ['qwak-ai/qwak-platform'],
    branchPrefix: 'AX-109-' + renovatedBranch + '-' + svcName + '-renovate-',
    commitMessagePrefix: '[AX-109][' + svcName + '] - Renovate: ',
    onboarding: false,
    requireConfig: "ignored",
    enabledManagers: ['poetry'],
    includePaths: [process.env.SERVICE_SRC_PATH + '/**/*'],
    forkProcessing: "disabled",
    persistRepoData: true,
    constraints: {
        python: ">=3.9 <3.12"
    },
    constraintsFiltering: "strict",
    fetchChangeLogs: "off",
    recreateWhen: "always",
    skipInstalls: true,
    prBodyNotes: ["In case of error check https://github.com/qwak-ai/qwak-platform/actions/workflows/weekly.renovate.yml"],
    prConcurrentLimit: 99,
    prHourlyLimit: 99,

    packageRules: [
        {
            description: "ENABLE: Allow minor and patch updates globally (overrides defaults)",
            matchUpdateTypes: ["minor", "patch"],
            enabled: true
        },
        {
            matchDatasources: ['pypi'],
            matchManagers: ['poetry'],
            automerge: false,
            labels: ['python-deps'],
            registryUrls: [
                'https://entplus.jfrog.io/artifactory/api/pypi/pypi-virtual/simple/'
            ]
        },
        {
            matchManagers: ["poetry"],
            allowedVersions: "<3.12",
            groupName: "frogml deps",
            enabled: true
        },
        {
            description: "Frogml dependency",
            matchFileNames: [process.env.SERVICE_SRC_PATH + '/**'],
            groupName: "frogml deps"
        },
        {
            description: "BLOCK: Global major version updates",
            matchUpdateTypes: ["major"],
            enabled: false
        }
    ],

    hostRules: [
        {
            hostType: 'pypi',
            matchHost: 'https://entplus.jfrog.io/',
            username: process.env.ENTPLUS_ARTIFACTORY_USER,
            password: process.env.ENTPLUS_ARTIFACTORY_PASSWORD
        }
    ]
};
