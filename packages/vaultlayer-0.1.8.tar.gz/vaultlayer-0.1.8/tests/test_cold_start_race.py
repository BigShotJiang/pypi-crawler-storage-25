"""
VaultLayer — Cold-Start Race test suite

Validates the three-level cold-start fix for docker image pull latency:

  Level 1: Background docker pull + /tmp/vl_image_ready sentinel
    - UserData backgrounds docker pull so checkpoint prefetch runs concurrently
    - Sentinel file written immediately if image already cached
    - _wait_for_image_ready() polls for sentinel (10s interval, 600s timeout)

  Level 2: Pre-baked AMI map
    - _find_prebaked_ami() matches docker_image substrings to region AMI IDs
    - Placeholder IDs (ami-vl-*) treated as "not yet baked" — fall through
    - _create_launch_template uses pre-baked AMI when available

  Level 3: Wiring
    - _wait_for_image_ready() called in execute_migration() after _prefetch_checkpoint
    - Training start gated on sentinel, enabling max(pull_time, prefetch_time) not sum
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import base64
import asyncio
import pytest
import pytest_asyncio
from unittest.mock import MagicMock, patch, AsyncMock, call


# ── Helpers ─────────────────────────────────────────────────────────────────

def _make_broker():
    from agents.broker.agent import BrokerAgent
    from shared.config import VaultLayerConfig, CloudflareConfig, AWSConfig

    cfg = MagicMock(spec=VaultLayerConfig)
    cfg.cloudflare = MagicMock(spec=CloudflareConfig)
    cfg.cloudflare.r2_bucket = "vaultlayer-test"
    cfg.cloudflare.r2_endpoint = "https://test.r2.cloudflarestorage.com"
    cfg.cloudflare.r2_access_key_id = "AK"
    cfg.cloudflare.r2_secret_access_key = "SK"
    cfg.aws = MagicMock(spec=AWSConfig)
    cfg.aws.access_key_id = "AK"
    cfg.aws.secret_access_key = "SK"
    cfg.aws.region = "us-east-1"

    with patch("shared.config.load_config", return_value=cfg), \
         patch("agents.broker.agent.AgentQueue"):
        broker = BrokerAgent.__new__(BrokerAgent)
        broker.config = cfg
        broker._r2_minter = None
        return broker


def _decode_userdata(b64: str) -> str:
    return base64.b64decode(b64).decode()


def _make_job(docker_image=None, dataset_id=None, env=None):
    from shared.models import Job, Provider, GPUType
    return Job(
        name="test-job",
        provider=Provider.AWS,
        gpu_type=GPUType.H100_80GB_SXM,
        docker_image=docker_image or "",
        dataset_id=dataset_id,
        environment=env or {},
    )


# ── Level 1: Background docker pull + sentinel ───────────────────────────────

def test_userdata_backgrounds_docker_pull_with_nohup():
    """When docker_image is set, pull must be backgrounded (not blocking)."""
    broker = _make_broker()
    job = _make_job(docker_image="pytorch/pytorch:2.5-cuda12.1-cudnn9-devel")
    script = _decode_userdata(broker._build_userdata(job))

    # Pull should be backgrounded with & or nohup
    assert "docker pull" in script
    # The pull command must not be blocking — it must run in background
    assert (
        "docker pull" in script and ("&" in script or "nohup" in script)
    ), "docker pull must be backgrounded"


def test_userdata_creates_sentinel_on_pull_complete():
    """After a successful pull, /tmp/vl_image_ready sentinel must be created."""
    broker = _make_broker()
    job = _make_job(docker_image="pytorch/pytorch:2.5-cuda12.1-cudnn9-devel")
    script = _decode_userdata(broker._build_userdata(job))

    assert "/tmp/vl_image_ready" in script, "Sentinel file must be created after pull"


def test_userdata_skips_pull_if_image_already_cached():
    """If image is already present (docker image inspect succeeds), pull must be skipped."""
    broker = _make_broker()
    job = _make_job(docker_image="pytorch/pytorch:2.5-cuda12.1-cudnn9-devel")
    script = _decode_userdata(broker._build_userdata(job))

    # The script must check if image exists before pulling
    assert "docker image inspect" in script or "docker images -q" in script, \
        "UserData must check for cached image before pulling"
    # On cache hit, sentinel is still written immediately
    assert "touch /tmp/vl_image_ready" in script


def test_userdata_no_docker_pull_when_no_image_set():
    """If no docker_image, UserData must not contain any docker pull."""
    broker = _make_broker()
    job = _make_job()
    script = _decode_userdata(broker._build_userdata(job))

    assert "docker pull" not in script
    assert "vl_image_ready" not in script


def test_userdata_docker_pull_log_captured():
    """docker pull output must be redirected to a log file for debugging."""
    broker = _make_broker()
    job = _make_job(docker_image="nvcr.io/nvidia/pytorch:23.10-py3")
    script = _decode_userdata(broker._build_userdata(job))

    assert "vl_docker_pull.log" in script, "docker pull log must be captured to /tmp/vl_docker_pull.log"


# ── Level 2: Pre-baked AMI map ───────────────────────────────────────────────

def test_find_prebaked_ami_matches_substring():
    """_find_prebaked_ami must return an AMI for a known image substring."""
    from agents.broker.agent import _find_prebaked_ami, PREBAKED_AMI_MAP

    # Pick the first entry from the map and verify we can find it
    first_key = next(iter(PREBAKED_AMI_MAP))
    first_region = next(iter(PREBAKED_AMI_MAP[first_key]))
    expected_ami = PREBAKED_AMI_MAP[first_key][first_region]

    # Build a realistic full image tag containing the key as a substring
    full_image = f"docker.io/{first_key}-extra-tag"
    result = _find_prebaked_ami(full_image, first_region)

    if expected_ami.startswith("ami-vl-"):
        # Placeholder — should not be returned
        assert result is None
    else:
        assert result == expected_ami


def test_find_prebaked_ami_returns_none_for_unknown_image():
    """An image not in PREBAKED_AMI_MAP must return None."""
    from agents.broker.agent import _find_prebaked_ami

    result = _find_prebaked_ami("some-random-image:latest", "us-east-1")
    assert result is None


def test_find_prebaked_ami_skips_placeholder_ids():
    """AMI IDs starting with 'ami-vl-' are placeholders and must not be returned."""
    from agents.broker.agent import _find_prebaked_ami, PREBAKED_AMI_MAP

    # Temporarily inject a placeholder entry to confirm it's skipped
    with patch.dict(PREBAKED_AMI_MAP, {"my-test-image": {"us-east-1": "ami-vl-placeholder-id"}}):
        result = _find_prebaked_ami("my-test-image:latest", "us-east-1")
        assert result is None, "Placeholder AMI IDs must not be returned"


def test_find_prebaked_ami_returns_none_for_unknown_region():
    """If region has no pre-baked AMI even for a known image, return None."""
    from agents.broker.agent import _find_prebaked_ami, PREBAKED_AMI_MAP

    first_key = next(iter(PREBAKED_AMI_MAP))
    # Inject a real AMI for us-east-1 only
    with patch.dict(PREBAKED_AMI_MAP, {first_key: {"us-east-1": "ami-0abc1234def56789a"}}):
        result = _find_prebaked_ami(first_key, "ap-southeast-1")
        assert result is None


def test_find_prebaked_ami_returns_real_ami_not_placeholder():
    """A real AMI ID (not 'ami-vl-*') must be returned when present."""
    from agents.broker.agent import _find_prebaked_ami, PREBAKED_AMI_MAP

    real_ami = "ami-0abc1234def56789a"
    with patch.dict(PREBAKED_AMI_MAP, {"special-framework:1.0": {"us-west-2": real_ami}}):
        result = _find_prebaked_ami("registry.io/special-framework:1.0-extra", "us-west-2")
        assert result == real_ami


def test_create_launch_template_uses_prebaked_ami():
    """_create_launch_template must use pre-baked AMI when _find_prebaked_ami returns one."""
    broker = _make_broker()
    real_ami = "ami-0abc1234def56789a"
    job = _make_job(docker_image="my-framework:2.0")

    ec2_mock = MagicMock()

    from agents.broker.agent import PREBAKED_AMI_MAP
    with patch.dict(PREBAKED_AMI_MAP, {"my-framework": {"us-east-1": real_ami}}), \
         patch("agents.broker.agent._find_prebaked_ami", wraps=__import__("agents.broker.agent", fromlist=["_find_prebaked_ami"])._find_prebaked_ami):
        broker._create_launch_template(ec2_mock, job, job.gpu_type, "us-east-1")

    call_kwargs = ec2_mock.create_launch_template.call_args
    data = call_kwargs.kwargs.get("LaunchTemplateData") or call_kwargs[1].get("LaunchTemplateData") or call_kwargs[0][1]
    image_id = data["ImageId"]
    assert image_id == real_ami, f"Expected pre-baked AMI {real_ami}, got {image_id}"


def test_create_launch_template_falls_back_to_deep_learning_ami():
    """_create_launch_template must resolve Ubuntu 22.04 AMI via ec2:describe_images."""
    broker = _make_broker()
    job = _make_job(docker_image="unknown-image:v99")

    ec2_mock = MagicMock()
    _mock_ami_id = "ami-0c7217cdde317cfec"
    # ec2_mock is passed directly to _create_launch_template — describe_images uses it
    ec2_mock.describe_images.return_value = {
        "Images": [{"ImageId": _mock_ami_id, "CreationDate": "2023-09-19T00:00:00.000Z"}]
    }
    broker._create_launch_template(ec2_mock, job, job.gpu_type, "us-east-1")

    call_kwargs = ec2_mock.create_launch_template.call_args
    data = call_kwargs.kwargs.get("LaunchTemplateData") or call_kwargs[1].get("LaunchTemplateData") or call_kwargs[0][1]
    image_id = data["ImageId"]
    assert image_id == _mock_ami_id, f"Expected Ubuntu 22.04 AMI {_mock_ami_id}, got {image_id}"
    assert not image_id.startswith("ami-vl-"), "Placeholder AMI must not be used as fallback"


def test_create_launch_template_no_image_uses_deep_learning_ami():
    """If job has no docker_image, must resolve Ubuntu 22.04 AMI via ec2:describe_images."""
    broker = _make_broker()
    job = _make_job()  # no docker_image

    ec2_mock = MagicMock()
    _mock_ami_id = "ami-0c7217cdde317cfec"
    ec2_mock.describe_images.return_value = {
        "Images": [{"ImageId": _mock_ami_id, "CreationDate": "2023-09-19T00:00:00.000Z"}]
    }
    broker._create_launch_template(ec2_mock, job, job.gpu_type, "us-east-1")

    call_kwargs = ec2_mock.create_launch_template.call_args
    data = call_kwargs.kwargs.get("LaunchTemplateData") or call_kwargs[1].get("LaunchTemplateData") or call_kwargs[0][1]
    image_id = data["ImageId"]
    assert image_id == _mock_ami_id
    assert not image_id.startswith("ami-vl-")


# ── _wait_for_image_ready ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_wait_for_image_ready_returns_true_when_sentinel_present():
    """Should return True immediately if /tmp/vl_image_ready already exists on node."""
    broker = _make_broker()
    job = _make_job(docker_image="pytorch/pytorch:2.5")

    with patch.object(broker, "_ssh_exec", new_callable=AsyncMock) as mock_ssh:
        mock_ssh.return_value = "READY"
        result = await broker._wait_for_image_ready("10.0.0.1", "/tmp/key", job)

    assert result is True
    mock_ssh.assert_called_once()


@pytest.mark.asyncio
async def test_wait_for_image_ready_returns_true_after_poll():
    """Should return True after sentinel appears on second poll."""
    broker = _make_broker()
    job = _make_job(docker_image="pytorch/pytorch:2.5")

    call_count = 0

    async def _ssh_side_effect(host, key, cmd):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return "WAITING"
        return "READY"

    with patch.object(broker, "_ssh_exec", side_effect=_ssh_side_effect):
        result = await broker._wait_for_image_ready(
            "10.0.0.1", "/tmp/key", job, poll_interval=0.01, timeout=5
        )

    assert result is True
    assert call_count == 2


@pytest.mark.asyncio
async def test_wait_for_image_ready_returns_false_on_timeout():
    """Should return False if sentinel never appears within timeout."""
    broker = _make_broker()
    job = _make_job(docker_image="very-large-image:latest")

    with patch.object(broker, "_ssh_exec", new_callable=AsyncMock) as mock_ssh:
        mock_ssh.return_value = "WAITING"
        result = await broker._wait_for_image_ready(
            "10.0.0.1", "/tmp/key", job, poll_interval=0.01, timeout=0.05
        )

    assert result is False


@pytest.mark.asyncio
async def test_wait_for_image_ready_no_op_when_no_docker_image():
    """If job has no docker_image, _wait_for_image_ready must return True immediately."""
    broker = _make_broker()
    job = _make_job()  # no docker_image

    with patch.object(broker, "_ssh_exec", new_callable=AsyncMock) as mock_ssh:
        result = await broker._wait_for_image_ready("10.0.0.1", "/tmp/key", job)

    assert result is True
    mock_ssh.assert_not_called()


@pytest.mark.asyncio
async def test_wait_for_image_ready_tolerates_ssh_errors():
    """SSH errors during polling must be swallowed — keep polling until timeout."""
    broker = _make_broker()
    job = _make_job(docker_image="pytorch/pytorch:2.5")

    call_count = 0

    async def _ssh_side_effect(host, key, cmd):
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            raise Exception("SSH connection refused")
        return "READY"

    with patch.object(broker, "_ssh_exec", side_effect=_ssh_side_effect):
        result = await broker._wait_for_image_ready(
            "10.0.0.1", "/tmp/key", job, poll_interval=0.01, timeout=5
        )

    assert result is True


# ── Concurrent pull + prefetch (timing model) ─────────────────────────────────

@pytest.mark.asyncio
async def test_migration_waits_for_image_before_restart():
    """execute_migration must call _wait_for_image_ready before _restart_job_on_node."""
    from shared.models import Job, Provider, GPUType, JobStatus
    broker = _make_broker()

    call_order = []

    async def _fake_wait(*args, **kwargs):
        call_order.append("wait_for_image")
        return True

    async def _fake_restart(*args, **kwargs):
        call_order.append("restart_job")

    broker._wait_for_image_ready = _fake_wait
    broker._restart_job_on_node = _fake_restart
    broker._wait_for_ssh = AsyncMock()
    broker._prefetch_checkpoint = AsyncMock()
    broker._probe_cuda = AsyncMock(return_value=(True, "550.xx"))
    broker._fence_old_node = AsyncMock()
    broker._migration_locks = {}
    broker._tel = None

    mock_queue = AsyncMock()
    mock_queue.publish = AsyncMock()
    mock_queue.set_job_state = AsyncMock()
    mock_queue.hget = AsyncMock(return_value=None)
    broker.queue = mock_queue

    # Patch out capacity + price guards and provision so we reach the SSH block
    fake_instance_id = "i-12345678"

    async def _fake_provision(gpu_type, job):
        return fake_instance_id

    broker.provision_aws = _fake_provision
    broker.provision_lambda = _fake_provision
    broker._active_migrations = {}

    job = Job(
        name="test-job",
        provider=Provider.AWS,
        gpu_type=GPUType.H100_80GB_SXM,
        docker_image="pytorch/pytorch:2.5",
        job_id="test-job-id",
        command="python train.py",
        status=JobStatus.RUNNING,
    )

    with patch("agents.broker.agent._PRICE_GUARD", False), \
         patch("agents.broker.agent._HAS_CAPACITY", False), \
         patch("asyncio.sleep", new_callable=AsyncMock), \
         patch.dict(os.environ, {
             "VAULTLAYER_SSH_KEY_PATH": "/tmp/key",
             f"VAULTLAYER_NODE_HOST_{fake_instance_id}": "10.0.0.1",
         }):
        await broker.execute_migration(
            job=job,
            target_provider=Provider.AWS,
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id="dec-00000001",
        )

    # wait_for_image must come BEFORE restart_job
    assert "wait_for_image" in call_order, "_wait_for_image_ready was never called"
    assert "restart_job" in call_order, "_restart_job_on_node was never called"
    assert call_order.index("wait_for_image") < call_order.index("restart_job"), \
        "_wait_for_image_ready must be called before _restart_job_on_node"
