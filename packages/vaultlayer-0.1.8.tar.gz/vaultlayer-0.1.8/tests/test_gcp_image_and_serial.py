"""GCP provider — image swap + serial-console diagnostic helper.

Regression coverage for the 2026-04-19 image swap away from
`ubuntu-accelerator-2204-amd64-with-nvidia-580` (every instance on that
image silently billed 20 min and emitted zero serial output; GCP support
confirmed hypervisor/image-level boot failure).

Covers:
  * GPU path uses plain `ubuntu-2204-lts` + `shieldedInstanceConfig.enableSecureBoot=false`
    + sets VL_GCP_NEEDS_DRIVER_INSTALL=1
  * CPU-only path (_skip_accelerator=True) keeps debian-12 + no shieldedInstanceConfig
  * fetch_serial_console calls compute.instances().getSerialPortOutput(port=1)
    and returns the `contents` field
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from conftest import make_job


def test_gcp_provider_reads_skip_accelerator_from_job_env():
    """CPU-only escape hatch must be triggerable from job.environment,
    not only from the Railway broker process env. When GCP denies GPU
    quota (seen 2026-04-20: GPUS_ALL_REGIONS=0 + 48h wait on approval),
    operators need to smoke-test the full provision path without
    touching Railway config.

    Static check for the getattr chain that reads job.environment first
    then falls back to os.environ. A unit-test of the full provision
    flow lives in tests/test_gcp_zone_fallback.py."""
    import pathlib
    src = pathlib.Path("src/agents/broker/providers/gcp.py").read_text()
    assert 'getattr(job, "environment"' in src, \
        "CPU-only flag must read from job.environment first"
    assert '_job_env.get("VL_GCP_SKIP_ACCELERATOR")' in src, \
        "job.environment lookup must hit the right key"
    # Process-env fallback must still exist (so Railway-set flag
    # remains authoritative for bulk CPU-only modes)
    assert 'os.environ.get("VL_GCP_SKIP_ACCELERATOR"' in src


def test_gcp_provider_source_strings_post_image_swap():
    """Static regression guard on the 2026-04-19 image swap away from
    ubuntu-accelerator-2204-amd64-with-nvidia-580 (every instance on
    that image silently billed 20 min with zero serial output). The
    full provision flow is already covered by tests/test_gcp_zone_fallback.py;
    this test just pins the three literals that encode the swap, so an
    accidental revert shows up as a red test instead of another 20-min
    blind fence in prod."""
    import pathlib
    src = pathlib.Path("src/agents/broker/providers/gcp.py").read_text()
    assert "projects/ubuntu-os-cloud/global/images/family/ubuntu-2204-lts" in src, \
        "GCP GPU path must use plain ubuntu-2204-lts (GCP support mitigation #2)"
    assert '"enableSecureBoot": False' in src, \
        "Secure Boot must be explicitly disabled on the GPU path " \
        "(DKMS nvidia-driver modules are unsigned and blocked by Secure Boot)"
    assert 'setdefault("VL_GCP_NEEDS_DRIVER_INSTALL"' in src, \
        "GCP provider must tag jobs with VL_GCP_NEEDS_DRIVER_INSTALL=1 " \
        "so the bootstrap knows to apt-install the driver"


@pytest.mark.asyncio
async def test_fetch_serial_console_calls_getSerialPortOutput_port_1():
    """Diagnostic: fetch_serial_console must pull serial port 1 (the one
    the Cloud Console "View serial port 1 (console)" button shows)."""
    from agents.broker.providers import gcp as gcp_provider

    call_log = {}

    class _FakeInstances:
        def getSerialPortOutput(self, project, zone, instance, port):
            call_log["project"] = project
            call_log["zone"] = zone
            call_log["instance"] = instance
            call_log["port"] = port
            class _Req:
                def execute(_): return {"contents": "kernel boot logs here", "next": "0"}
            return _Req()

    class _FakeCompute:
        def instances(self): return _FakeInstances()

    broker = MagicMock()
    broker._gcp_sa_info = {
        "vl-abc123-a100": {
            "sa_info": {
                "type": "service_account",
                "project_id": "proj-x",
                "private_key": "xxx",
                "client_email": "sa@proj-x.iam.gserviceaccount.com",
                "token_uri": "https://oauth2.googleapis.com/token",
            },
            "project_id": "proj-x",
            "zone": "us-central1-c",
        },
    }

    with patch("googleapiclient.discovery.build", return_value=_FakeCompute()), \
         patch("google.oauth2.service_account.Credentials.from_service_account_info",
               return_value=MagicMock()):
        result = await gcp_provider.fetch_serial_console(broker, "vl-abc123-a100")

    assert result == "kernel boot logs here"
    assert call_log == {
        "project":  "proj-x",
        "zone":     "us-central1-c",
        "instance": "vl-abc123-a100",
        "port":     1,
    }


@pytest.mark.asyncio
async def test_fetch_serial_console_returns_none_on_failure():
    """Missing credentials / API errors must return None, not raise —
    serial fetch is diagnostic and should never kill the calling flow."""
    from agents.broker.providers import gcp as gcp_provider

    broker = MagicMock()
    broker._gcp_sa_info = {}
    broker.config.gcp = None
    with patch("api.credentials._read_provider_credentials", return_value=None):
        result = await gcp_provider.fetch_serial_console(broker, "vl-abc123-a100")
    assert result is None
