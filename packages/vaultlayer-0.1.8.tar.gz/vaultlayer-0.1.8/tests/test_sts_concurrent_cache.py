"""Sprint-1 PR B: pins that concurrent get_credentials() calls don't
stampede STS.AssumeRole.

AWS TAM noted the STS service has a 600 req/s per-account-per-region
limit. Under concurrent provision load (N threads asking for
credentials at once), the pre-lock code would issue N calls to
AssumeRole on cache miss. With the RLock-guarded double-checked read,
only 1 call goes through; the rest wait and return the cached result.
"""
from __future__ import annotations

import sys
import time
import threading
from pathlib import Path
from unittest.mock import MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import pytest


def _make_manager_with_mock_sts(call_counter: list):
    """Build an STSSessionManager whose _assume_role is replaced with a
    counter-incrementing mock that simulates AssumeRole latency."""
    from shared.sts import STSSessionManager
    # Build a config object just complete enough to pass is_configured
    cfg = MagicMock()
    cfg.sts.role_arn = "arn:aws:iam::111111111111:role/test"
    cfg.sts.external_id = None
    cfg.sts.session_duration = 3600
    cfg.aws.access_key_id = "akid"
    cfg.aws.secret_access_key = "sk"
    cfg.aws.region = "us-east-1"
    m = STSSessionManager(cfg)

    def _fake_assume(job_id):
        call_counter.append(job_id)
        time.sleep(0.05)  # simulate 50ms STS latency
        m._credentials = {
            "aws_access_key_id": "ASIA-cached",
            "aws_secret_access_key": "cached-secret",
            "aws_session_token": "cached-token",
        }
        m._expiry = time.monotonic() + 3600
        return m._credentials

    m._assume_role = _fake_assume
    return m


class TestConcurrentCacheNoStampede:
    def test_20_concurrent_callers_only_1_assume_role(self):
        """20 threads hitting a cold cache simultaneously should result
        in exactly ONE AssumeRole call — the rest wait and return the
        cached credentials."""
        calls = []
        m = _make_manager_with_mock_sts(calls)

        results = []
        errors = []

        def _worker(i):
            try:
                creds = m.get_credentials(f"job-{i}")
                results.append(creds)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=_worker, args=(i,)) for i in range(20)]
        for t in threads: t.start()
        for t in threads: t.join()

        assert not errors, f"unexpected errors: {errors}"
        assert len(results) == 20
        assert len(calls) == 1, (
            f"expected exactly 1 AssumeRole call under concurrent load, "
            f"got {len(calls)}: {calls}"
        )
        # All callers got the same cached credential set
        assert all(r == results[0] for r in results)

    def test_sequential_callers_hit_cache_after_first(self):
        """Sequential callers after the first one should never trigger
        AssumeRole again (as long as expiry is in the future)."""
        calls = []
        m = _make_manager_with_mock_sts(calls)

        # 10 sequential calls
        for i in range(10):
            m.get_credentials(f"job-{i}")

        assert len(calls) == 1

    def test_cache_expiry_triggers_refresh(self):
        """When cached credentials are within the refresh buffer, next
        call should trigger a fresh AssumeRole."""
        from shared.sts import STSSessionManager
        calls = []
        m = _make_manager_with_mock_sts(calls)
        m.get_credentials("first")
        assert len(calls) == 1

        # Force expiry into the refresh buffer window
        m._expiry = time.monotonic() + STSSessionManager.REFRESH_BUFFER_SECONDS - 1

        m.get_credentials("second")
        assert len(calls) == 2, "expired cache should have triggered refresh"
