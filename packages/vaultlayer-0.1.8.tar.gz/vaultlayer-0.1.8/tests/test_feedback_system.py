"""
Tests for the VaultLayer user feedback and autonomous bug-fixing system.

Tests:
  1.  test_scrub_removes_aws_key
  2.  test_scrub_removes_vl_token
  3.  test_scrub_removes_sk_key
  4.  test_scrub_removes_email
  5.  test_error_fingerprint_stable
  6.  test_error_fingerprint_different_errors
  7.  test_is_actionable_with_traceback
  8.  test_is_actionable_vague_message
  9.  test_is_actionable_with_job_id_and_logs
  10. test_save_and_load_crash_report
  11. test_mark_submitted
  12. test_feedback_dedup_same_fingerprint
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import json
import pytest
from pathlib import Path
from unittest.mock import patch


# ── crash_reporter tests ──────────────────────────────────────────────────────

from cli.crash_reporter import (
    scrub,
    error_fingerprint,
    save_crash_report,
    load_crash_report,
    mark_submitted,
)


def test_scrub_removes_aws_key():
    text = "Using key AKIAIOSFODNN7EXAMPLE in production"
    result = scrub(text)
    assert "AKIAIOSFODNN7EXAMPLE" not in result
    assert "[AWS_KEY_REDACTED]" in result


def test_scrub_removes_vl_token():
    text = "Token vl_live_abc123defXYZ890 is invalid"
    result = scrub(text)
    assert "vl_live_abc123defXYZ890" not in result
    assert "[VL_TOKEN_REDACTED]" in result


def test_scrub_removes_vl_test_token():
    text = "Token vl_test_xyz987abc123def is invalid"
    result = scrub(text)
    assert "vl_test_xyz987abc123def" not in result
    assert "[VL_TOKEN_REDACTED]" in result


def test_scrub_removes_sk_key():
    text = "Using anthropic key sk-ant-api03-abcdefghijklmnopqrstuvwxyz0123456789"
    result = scrub(text)
    assert "sk-ant-api03-abcdefghijklmnopqrstuvwxyz0123456789" not in result
    assert "[ANTHROPIC_KEY_REDACTED]" in result


def test_scrub_removes_email():
    text = "Error for user user@example.com during training"
    result = scrub(text)
    assert "user@example.com" not in result
    assert "[EMAIL_REDACTED]" in result


def test_scrub_preserves_non_secrets():
    text = "ConnectionError: timeout after 30 seconds on H100_80GB_SXM"
    result = scrub(text)
    assert "ConnectionError" in result
    assert "H100_80GB_SXM" in result
    assert "30 seconds" in result


def test_error_fingerprint_stable():
    """Same inputs must always produce the same fingerprint."""
    fp1 = error_fingerprint("ConnectionError", "timeout", "src/agents/broker/agent.py")
    fp2 = error_fingerprint("ConnectionError", "timeout", "src/agents/broker/agent.py")
    assert fp1 == fp2
    assert fp1.startswith("fp_")


def test_error_fingerprint_different_errors():
    """Different errors must produce different fingerprints."""
    fp1 = error_fingerprint("ConnectionError", "timeout", "src/agents/broker/agent.py")
    fp2 = error_fingerprint("ValueError", "invalid config", "src/shared/config.py")
    assert fp1 != fp2


def test_error_fingerprint_format():
    fp = error_fingerprint("KeyError", "missing key", "src/shared/models.py")
    assert fp.startswith("fp_")
    # Should be fp_ + 16 hex chars
    assert len(fp) == 19  # "fp_" (3) + 16 hex chars


def test_save_and_load_crash_report(tmp_path, monkeypatch):
    """save_crash_report then load_crash_report returns the same data."""
    # Redirect crash reports to tmp_path
    crash_dir = tmp_path / "crash_reports"
    crash_dir.mkdir()
    monkeypatch.setattr(
        "cli.crash_reporter._crash_reports_dir",
        lambda: crash_dir,
    )

    exc = ValueError("test error: connection refused")
    report_id = save_crash_report(
        exc,
        command=["vaultlayer", "run", "python", "train.py"],
        job_id="job-test-001",
        gpu_type="H100_80GB_SXM",
        provider="lambda_labs",
    )

    assert report_id.startswith("cr_")

    loaded = load_crash_report(report_id)
    assert loaded is not None
    assert loaded["id"] == report_id
    assert loaded["error_type"] == "ValueError"
    assert "connection refused" in loaded["error_message"]
    assert loaded["job_id"] == "job-test-001"
    assert loaded["gpu_type"] == "H100_80GB_SXM"
    assert loaded["provider"] == "lambda_labs"
    assert loaded["submitted"] is False
    assert loaded["fingerprint"].startswith("fp_")
    assert "vaultlayer" in loaded["command"]


def test_mark_submitted(tmp_path, monkeypatch):
    """After mark_submitted, loaded report has submitted=True."""
    crash_dir = tmp_path / "crash_reports"
    crash_dir.mkdir()
    monkeypatch.setattr(
        "cli.crash_reporter._crash_reports_dir",
        lambda: crash_dir,
    )

    exc = RuntimeError("GPU OOM")
    report_id = save_crash_report(exc, command=["vaultlayer", "run", "python", "train.py"])

    loaded_before = load_crash_report(report_id)
    assert loaded_before["submitted"] is False

    mark_submitted(report_id)

    loaded_after = load_crash_report(report_id)
    assert loaded_after["submitted"] is True


def test_load_crash_report_missing_returns_none(tmp_path, monkeypatch):
    """load_crash_report returns None for a non-existent report."""
    crash_dir = tmp_path / "crash_reports"
    crash_dir.mkdir()
    monkeypatch.setattr(
        "cli.crash_reporter._crash_reports_dir",
        lambda: crash_dir,
    )
    result = load_crash_report("cr_nonexistent")
    assert result is None


# ── claude_bug_fixer tests ────────────────────────────────────────────────────

from workers.claude_bug_fixer import is_actionable


def test_is_actionable_with_traceback():
    """Feedback with a full traceback should be actionable."""
    feedback = {
        "traceback": (
            'Traceback (most recent call last):\n'
            '  File "src/agents/broker/agent.py", line 42, in provision\n'
            '    raise ConnectionError("timeout")\n'
            'ConnectionError: timeout'
        ),
        "error_type": "ConnectionError",
        "message": "Got a connection error during provisioning",
        "log_snippet": None,
        "job_id": None,
    }
    actionable, question = is_actionable(feedback)
    assert actionable is True
    assert question == ""


def test_is_actionable_vague_message():
    """Vague feedback with no traceback, no error type, no logs → not actionable."""
    feedback = {
        "traceback": None,
        "error_type": None,
        "message": "it doesn't work",
        "log_snippet": None,
        "job_id": None,
    }
    actionable, question = is_actionable(feedback)
    assert actionable is False
    assert "traceback" in question.lower() or "error" in question.lower() or "info" in question.lower()


def test_is_actionable_with_job_id_and_logs():
    """Feedback with a job_id and log snippet should be actionable."""
    feedback = {
        "traceback": None,
        "error_type": None,
        "message": "training crashed",
        "log_snippet": "Step 100/1000 | loss=2.34\n" * 10,  # > 100 chars
        "job_id": "job-abc123",
    }
    actionable, question = is_actionable(feedback)
    assert actionable is True


def test_is_actionable_score_boundary():
    """Feedback with only error_type (score=1) should not be actionable."""
    feedback = {
        "traceback": None,
        "error_type": "RuntimeError",
        "message": "something went wrong",
        "log_snippet": None,
        "job_id": None,
    }
    actionable, question = is_actionable(feedback)
    assert actionable is False


def test_is_actionable_short_traceback():
    """A very short 'traceback' (< 50 chars) doesn't give full +2 score."""
    feedback = {
        "traceback": "err",  # < 50 chars
        "error_type": "RuntimeError",  # +1
        "message": "short tb test",
        "log_snippet": None,
        "job_id": None,
    }
    # score: error_type=+1, traceback too short = +0 → total 1 → not actionable
    actionable, question = is_actionable(feedback)
    assert actionable is False


# ── Deduplication logic test (unit, no DB) ────────────────────────────────────

def test_feedback_dedup_same_fingerprint():
    """
    Verify the dedup dict logic: if a fingerprint is already seen,
    new entries should reference the primary feedback_id.
    """
    fingerprint = "fp_abc123456789abcd"

    # Simulate existing feedback rows in memory
    existing_rows = [
        {
            "id": "fb_primary01",
            "fingerprint": fingerprint,
            "status": "pending",
            "primary_feedback_id": None,
        }
    ]

    # Logic: if fingerprint matches a non-duplicate, non-resolved row → mark as duplicate
    def resolve_primary(rows, new_fingerprint):
        for row in rows:
            if (row.get("fingerprint") == new_fingerprint
                    and row.get("status") not in ("duplicate", "resolved")):
                return row.get("primary_feedback_id") or row.get("id"), "duplicate"
        return None, "pending"

    primary_id, status = resolve_primary(existing_rows, fingerprint)
    assert status == "duplicate"
    assert primary_id == "fb_primary01"

    # Different fingerprint → not a duplicate
    primary_id2, status2 = resolve_primary(existing_rows, "fp_different12345678")
    assert status2 == "pending"
    assert primary_id2 is None

    # Resolved row should not trigger dedup
    existing_rows[0]["status"] = "resolved"
    primary_id3, status3 = resolve_primary(existing_rows, fingerprint)
    assert status3 == "pending"
    assert primary_id3 is None
