"""IDEM-3: Vault orphan GC on manifest-write failure.

When upload_checkpoint() writes the data bytes successfully but the
_MANIFEST.json write fails, the data is orphaned in R2 — no manifest
means restore won't trust them, but they still cost storage.

These tests pin the cleanup behavior at src/agents/vault/r2.py:183-210.
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import pytest


def _make_r2client_with_mocked_s3(s3_mock, bucket="vl-checkpoints"):
    """Build a minimal R2Client whose underlying boto3 S3 client is a mock."""
    from agents.vault.r2 import R2Client
    # Bypass __init__ since it calls boto3.client(); attach mocked deps directly.
    c = R2Client.__new__(R2Client)
    c._s3 = s3_mock
    c.bucket = bucket
    # Encryption disabled for these tests
    c._encryption_key = None
    return c


@pytest.fixture
def tmp_checkpoint(tmp_path):
    """A small fake checkpoint file."""
    p = tmp_path / "model.pt"
    p.write_bytes(b"x" * 4096)
    return p


def _mock_encryption_disabled(monkeypatch):
    """Make get_encryption() return a no-op encrypter."""
    class _NoopEnc:
        enabled = False
        def encrypt(self, data): return data
    monkeypatch.setattr("agents.vault.r2.get_encryption", lambda: _NoopEnc())


def _mock_audit(monkeypatch):
    monkeypatch.setattr("agents.vault.r2.get_audit", lambda: MagicMock())


class TestOrphanCleanupOnManifestFailure:
    """Manifest write fails → r2_key data is deleted as best-effort cleanup."""

    def test_manifest_failure_triggers_data_delete(self, tmp_checkpoint, monkeypatch):
        """Manifest write failure: upload_checkpoint must raise RuntimeError after
        orphan cleanup (delete_object on the data key) so the caller knows the
        checkpoint was NOT committed. Previously this returned silently, which caused
        the Vault agent to publish CHECKPOINT_COMPLETE on a broken checkpoint."""
        _mock_encryption_disabled(monkeypatch)
        _mock_audit(monkeypatch)

        s3 = MagicMock()
        # First put_object (data) succeeds; second (manifest) raises.
        # Track which Key was the data and which was the manifest.
        put_calls = []
        delete_calls = []

        def _put(**kwargs):
            put_calls.append(kwargs["Key"])
            if "_MANIFEST.json" in kwargs["Key"]:
                raise RuntimeError("simulated manifest write failure")
            return {"ETag": '"deadbeef"'}

        def _delete(**kwargs):
            delete_calls.append(kwargs["Key"])
            return {}

        # head_object is called by _verify_upload — return a successful head
        # with matching size + sha256 metadata so we don't fail there.
        import hashlib
        sha = hashlib.sha256(tmp_checkpoint.read_bytes()).hexdigest()

        def _head(**kwargs):
            import zlib
            compressed = zlib.compress(tmp_checkpoint.read_bytes(), level=6)
            return {
                "ContentLength": len(compressed),
                "Metadata": {"sha256": sha},
            }

        s3.put_object.side_effect = _put
        s3.delete_object.side_effect = _delete
        s3.head_object.side_effect = _head

        c = _make_r2client_with_mocked_s3(s3)
        # mirror_to_backup is a no-op for tests
        c._mirror_to_backup = lambda *a, **k: None

        with pytest.raises(RuntimeError, match="manifest write"):
            c.upload_checkpoint(
                job_id="job-test-orphan",
                step=42,
                local_path=str(tmp_checkpoint),
                model_params_billion=1.1,
            )

        # Data put first, then manifest (retried up to 3× on failure).
        assert len(put_calls) >= 2, f"expected ≥2 put_object calls, got {put_calls}"
        data_key = put_calls[0]
        assert "_MANIFEST.json" not in data_key
        assert all("_MANIFEST.json" in k for k in put_calls[1:]), (
            f"non-data calls should all be manifest attempts: {put_calls}"
        )

        # The data key should have been deleted as cleanup
        assert data_key in delete_calls, (
            f"expected delete_object({data_key!r}); "
            f"only saw deletes for {delete_calls}"
        )

    def test_manifest_failure_with_failed_delete_still_raises(
        self, tmp_checkpoint, monkeypatch
    ):
        """If both manifest write AND data cleanup fail, upload_checkpoint
        must still raise RuntimeError so the caller knows the checkpoint was
        NOT committed. The periodic startup GC will catch the orphan."""
        _mock_encryption_disabled(monkeypatch)
        _mock_audit(monkeypatch)

        s3 = MagicMock()

        def _put(**kwargs):
            if "_MANIFEST.json" in kwargs["Key"]:
                raise RuntimeError("manifest fail")
            return {"ETag": '"x"'}

        def _delete(**kwargs):
            raise RuntimeError("delete also failed")

        import hashlib, zlib
        sha = hashlib.sha256(tmp_checkpoint.read_bytes()).hexdigest()
        s3.head_object.return_value = {
            "ContentLength": len(zlib.compress(tmp_checkpoint.read_bytes(), level=6)),
            "Metadata": {"sha256": sha},
        }
        s3.put_object.side_effect = _put
        s3.delete_object.side_effect = _delete

        c = _make_r2client_with_mocked_s3(s3)
        c._mirror_to_backup = lambda *a, **k: None

        # Must raise — caller must know the checkpoint was not committed,
        # even when orphan cleanup itself also failed.
        with pytest.raises(RuntimeError, match="manifest write"):
            c.upload_checkpoint(
                job_id="job-double-fail",
                step=1,
                local_path=str(tmp_checkpoint),
                model_params_billion=0.1,
            )

    def test_happy_path_no_delete_called(self, tmp_checkpoint, monkeypatch):
        """When manifest write succeeds, delete_object must NOT be called.
        Pins that we don't accidentally delete healthy checkpoints."""
        _mock_encryption_disabled(monkeypatch)
        _mock_audit(monkeypatch)

        s3 = MagicMock()
        s3.put_object.return_value = {"ETag": '"ok"'}

        import hashlib, zlib
        sha = hashlib.sha256(tmp_checkpoint.read_bytes()).hexdigest()
        s3.head_object.return_value = {
            "ContentLength": len(zlib.compress(tmp_checkpoint.read_bytes(), level=6)),
            "Metadata": {"sha256": sha},
        }

        c = _make_r2client_with_mocked_s3(s3)
        c._mirror_to_backup = lambda *a, **k: None

        c.upload_checkpoint(
            job_id="job-happy",
            step=99,
            local_path=str(tmp_checkpoint),
            model_params_billion=1.1,
        )

        s3.delete_object.assert_not_called()
