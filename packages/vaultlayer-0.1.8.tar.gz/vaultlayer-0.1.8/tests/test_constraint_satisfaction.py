"""Tier-1 tests for the provider+region constraint-satisfaction feature.

Covers:
  - Job model: preferred_providers + excluded_providers list fields
  - JobRunStatus enum: new awaiting_expand_consent + cancelled values
  - Dispatcher (_try_provision): preferred/excluded filtering, resume preference
  - Suggestions helper (get_suggestions): nearby vs all, provider list
  - Submit-flow validation: dedupe, unknown-name reject, empty-after-excludes reject
  - Submit awaiting_expand_consent path (HTTP 202 with suggestions payload)
  - Expand-consent endpoint: union, status guard, idempotent no-op
  - Resume flow: same-provider preference + resume_no_capacity terminal cancel

The existing test_server_lifecycle.py uses the same TestClient + require_auth
override pattern; we re-use that here. State-isolation autouse fixture mirrors
the one in that file so a failure here can't leak _active_jobs into siblings.
"""
from __future__ import annotations

import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ── Shared isolation fixture (same pattern as test_server_lifecycle.py) ──────

@pytest.fixture(autouse=True)
def _isolate_env(monkeypatch):
    """Reset module-level state before/after each test so they don't pollute siblings."""
    monkeypatch.setenv("VL_TESTING_MODE", "1")
    monkeypatch.setenv("SUPABASE_URL", os.environ.get("SUPABASE_URL", "https://fake.supabase.co"))
    monkeypatch.setenv("SUPABASE_KEY", os.environ.get("SUPABASE_KEY", "fake-key"))
    import api.flags
    monkeypatch.setattr(api.flags, "TESTING_MODE", True)
    yield
    import api.job_worker as jw
    jw._broker_instance = None
    jw._active_jobs.clear()
    jw._job_queue.clear()
    jw._worker_debug.update({"started": False, "last_error": None,
                             "broker_ok": False, "cycle_count": 0,
                             "last_provision_attempts": []})
    try:
        from api.db import get_db
        get_db.cache_clear()
    except Exception:
        pass


@pytest.fixture
def client():
    """FastAPI TestClient with require_auth bypassed for unit testing."""
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from api.job_routes import jobs_router
    from api.auth import require_auth

    async def _fake_auth():
        return {"user_id": "test-user", "email": "test@test.com"}

    app = FastAPI()
    app.dependency_overrides[require_auth] = _fake_auth
    app.include_router(jobs_router)
    return TestClient(app)


# ===========================================================================
# 1. Job model — preferred_providers field accepts the documented shapes
# ===========================================================================

class TestJobModelPreferredProviders:
    def _base_args(self):
        from shared.models import GPUType, Provider
        return {
            "name": "t",
            "provider": Provider.AWS,
            "gpu_type": GPUType.H100_80GB_SXM,
        }

    def test_default_is_empty_list(self):
        from shared.models import Job
        j = Job(**self._base_args())
        assert j.preferred_providers == []
        assert j.excluded_providers == []

    def test_accepts_single_provider(self):
        from shared.models import Job
        j = Job(**self._base_args(), preferred_providers=["AWS Spot"])
        assert j.preferred_providers == ["AWS Spot"]

    def test_accepts_multi_providers(self):
        from shared.models import Job
        j = Job(**self._base_args(),
                preferred_providers=["AWS Spot", "Lambda Labs", "RunPod"])
        assert j.preferred_providers == ["AWS Spot", "Lambda Labs", "RunPod"]


# ===========================================================================
# 2. JobRunStatus enum — new values exist and round-trip
# ===========================================================================

class TestJobRunStatusEnum:
    def test_has_classic_lifecycle_values(self):
        from shared.models import JobRunStatus
        # The classic provisioning → running → completed path remains valid.
        assert JobRunStatus.PROVISIONING.value == "provisioning"
        assert JobRunStatus.RUNNING.value      == "running"
        assert JobRunStatus.COMPLETED.value    == "completed"

    def test_has_consent_and_cancelled_values(self):
        from shared.models import JobRunStatus
        assert JobRunStatus.AWAITING_EXPAND_CONSENT.value == "awaiting_expand_consent"
        assert JobRunStatus.CANCELLED.value               == "cancelled"

    def test_string_round_trip(self):
        from shared.models import JobRunStatus
        # Both string lookups must work — the migration adds these to the
        # job_runs CHECK constraint and the API persists them as strings.
        assert JobRunStatus("awaiting_expand_consent") == JobRunStatus.AWAITING_EXPAND_CONSENT
        assert JobRunStatus("cancelled")               == JobRunStatus.CANCELLED


# ===========================================================================
# 3. get_suggestions() helper
# ===========================================================================

class TestGetSuggestions:
    def test_nearby_only_includes_routable(self):
        """Adjacency entries that aren't in routable_regions must be filtered.
        We monkeypatch routable_region_codes to return a subset and verify the
        nearby list never escapes that subset."""
        from shared import suggestions
        with patch.object(suggestions, "get_region_adjacency",
                          return_value={"us-east-1": ["us-east-2", "fake-region"]}), \
             patch.object(suggestions, "get_routable_region_codes",
                          return_value=["us-east-1", "us-east-2", "us-west-2"]), \
             patch.object(suggestions, "get_provider_prices", return_value={"AWS Spot": {}}):
            out = suggestions.get_suggestions(["us-east-1"], [])
        assert out["add_regions"]["nearby"] == ["us-east-2"]  # fake-region dropped

    def test_all_excludes_already_constrained(self):
        from shared import suggestions
        with patch.object(suggestions, "get_region_adjacency", return_value={}), \
             patch.object(suggestions, "get_routable_region_codes",
                          return_value=["us-east-1", "us-east-2", "us-west-2"]), \
             patch.object(suggestions, "get_provider_prices", return_value={"AWS Spot": {}}):
            out = suggestions.get_suggestions(["us-east-1"], [])
        assert "us-east-1" not in out["add_regions"]["all"]
        assert sorted(out["add_regions"]["all"]) == ["us-east-2", "us-west-2"]

    def test_add_providers_excludes_constrained_and_skips_non_routable(self):
        """AWS On-Demand / AWS Reserved entries are NOT routable per CLAUDE.md
        rule 10 (job_worker filters them) — they must not appear in suggestions."""
        from shared import suggestions
        prices = {
            "AWS Spot": {}, "AWS On-Demand": {}, "AWS Reserved": {},
            "Lambda Labs": {}, "RunPod": {},
        }
        with patch.object(suggestions, "get_region_adjacency", return_value={}), \
             patch.object(suggestions, "get_routable_region_codes", return_value=[]), \
             patch.object(suggestions, "get_provider_prices", return_value=prices):
            out = suggestions.get_suggestions([], ["AWS Spot"])
        assert "AWS Spot" not in out["add_providers"]["add"]
        assert "AWS On-Demand" not in out["add_providers"]["add"]  # non-routable filtered
        assert "AWS Reserved" not in out["add_providers"]["add"]
        assert sorted(out["add_providers"]["add"]) == ["Lambda Labs", "RunPod"]


# ===========================================================================
# 4. Dispatcher (_try_provision) — preferred/excluded filtering
# ===========================================================================

class TestDispatcherFilters:
    def _make_job(self, **overrides) -> dict:
        base = {
            "job_id": "tj-001",
            "user_id": "u-1",
            "gpu_type": "H100",
            "environment": {},
            "docker_image": "",
            "failover": False,
            "preferred_providers": [],
            "excluded_providers": [],
            "regions": [],
            "excluded_regions": [],
        }
        base.update(overrides)
        return base

    @pytest.mark.asyncio
    async def test_empty_constraint_picks_cheapest_routable(self):
        """No preferred filter → dispatcher iterates by price-asc and picks
        the cheapest provider that has the GPU."""
        from api.job_worker import _try_provision
        from shared.models import GPUType

        broker = MagicMock()
        broker.provision_vast = AsyncMock(return_value="inst-vast")
        broker.provision_runpod = AsyncMock(return_value="inst-rp")
        broker.provision_lambda = AsyncMock(return_value="inst-lambda")

        prices = {
            "Vast.ai":     {"H100": 2.50},  # cheapest
            "RunPod":      {"H100": 3.00},
            "Lambda Labs": {"H100": 3.50},
        }
        with patch("shared.data_loader.get_provider_prices", return_value=prices), \
             patch("shared.data_loader.resolve_gpu_key", return_value="H100"), \
             patch("shared.data_loader.resolve_gpu_enum", return_value=GPUType.H100_80GB_SXM):
            result = await _try_provision(broker, self._make_job())

        assert result == "inst-vast"
        broker.provision_vast.assert_awaited_once()
        broker.provision_runpod.assert_not_awaited()  # cheaper Vast won

    @pytest.mark.asyncio
    async def test_preferred_providers_filter_excludes_others(self):
        """preferred_providers=["RunPod"] → only RunPod considered, even
        though Vast.ai is cheaper."""
        from api.job_worker import _try_provision
        from shared.models import GPUType

        broker = MagicMock()
        broker.provision_vast = AsyncMock(return_value="inst-vast")
        broker.provision_runpod = AsyncMock(return_value="inst-rp")

        prices = {"Vast.ai": {"H100": 2.50}, "RunPod": {"H100": 3.00}}
        job = self._make_job(preferred_providers=["RunPod", "runpod"])
        with patch("shared.data_loader.get_provider_prices", return_value=prices), \
             patch("shared.data_loader.resolve_gpu_key", return_value="H100"), \
             patch("shared.data_loader.resolve_gpu_enum", return_value=GPUType.H100_80GB_SXM):
            result = await _try_provision(broker, job)

        assert result == "inst-rp"
        broker.provision_vast.assert_not_awaited()  # not in preferred list

    @pytest.mark.asyncio
    async def test_excluded_providers_skipped(self):
        """excluded_providers takes priority over preferred."""
        from api.job_worker import _try_provision
        from shared.models import GPUType

        broker = MagicMock()
        broker.provision_vast = AsyncMock(return_value="inst-vast")
        broker.provision_runpod = AsyncMock(return_value="inst-rp")

        prices = {"Vast.ai": {"H100": 2.50}, "RunPod": {"H100": 3.00}}
        job = self._make_job(excluded_providers=["vast_ai"])
        with patch("shared.data_loader.get_provider_prices", return_value=prices), \
             patch("shared.data_loader.resolve_gpu_key", return_value="H100"), \
             patch("shared.data_loader.resolve_gpu_enum", return_value=GPUType.H100_80GB_SXM):
            result = await _try_provision(broker, job)

        assert result == "inst-rp"
        broker.provision_vast.assert_not_awaited()


# ===========================================================================
# 5. Submit-flow validation + awaiting_expand_consent path
# ===========================================================================

class TestSubmitValidation:
    def test_unknown_provider_returns_400(self, client):
        resp = client.post("/api/v1/jobs/run", json={
            "gpu_type": "H100",
            "preferred_providers": ["TotallyMadeUpProvider"],
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        assert resp.status_code == 400
        assert "TotallyMadeUpProvider" in resp.json()["detail"]

    def test_duplicate_providers_dedupe_silently(self, client):
        """Duplicates in the input list collapse to a single entry server-side
        and do NOT cause a 400. Uses production-included providers so the
        three-state allowlist (docs/provider_testing_matrix.md) doesn't
        reject the request for a non-test user."""
        from api.job_worker import _active_jobs
        resp = client.post("/api/v1/jobs/run", json={
            "gpu_type": "H100",
            "preferred_providers": ["RunPod", "RunPod", "Lambda Labs"],
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        assert resp.status_code in (200, 202)
        job_id = resp.json()["job_id"]
        assert _active_jobs[job_id]["preferred_providers"] == ["RunPod", "Lambda Labs"]

    def test_regions_after_excludes_empty_returns_400(self, client):
        """If --regions is fully covered by --excluded-regions, reject."""
        resp = client.post("/api/v1/jobs/run", json={
            "gpu_type": "H100",
            "regions":          ["us-east-1", "us-east-2"],
            "excluded_regions": ["us-east-1", "us-east-2"],
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        assert resp.status_code == 400
        assert "regions after exclusions is empty" in resp.json()["detail"]

    def test_preferred_after_excludes_empty_returns_400(self, client):
        """Symmetric: preferred fully covered by excluded must reject.
        Uses production-included providers so the check being tested is the
        empty-intersection rule, not the three-state allowlist."""
        resp = client.post("/api/v1/jobs/run", json={
            "gpu_type": "H100",
            "preferred_providers": ["RunPod", "Lambda Labs"],
            "excluded_providers":  ["RunPod", "Lambda Labs"],
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        assert resp.status_code == 400
        assert "preferred_providers after exclusions" in resp.json()["detail"]


class TestSubmitAwaitingConsent:
    def test_unsatisfiable_filter_returns_202_with_suggestions(self, client):
        """When _has_dispatchable_candidate returns False, server returns 202
        instead of queuing. The CLI uses this to launch the consent prompt."""
        from api.job_worker import _active_jobs
        with patch("api.job_routes._has_dispatchable_candidate", return_value=False):
            resp = client.post("/api/v1/jobs/run", json={
                "gpu_type": "H100",
                "regions": ["us-east-1"],
            }, headers={"Authorization": "Bearer vl_test_xxx"})
        assert resp.status_code == 202
        body = resp.json()
        assert body["status"] == "awaiting_expand_consent"
        assert "suggestions" in body
        # Job is parked, NOT in the worker queue.
        from api.job_worker import _job_queue
        assert body["job_id"] in _active_jobs
        assert body["job_id"] not in _job_queue
        assert _active_jobs[body["job_id"]]["status"] == "awaiting_expand_consent"


# ===========================================================================
# 6. Expand-consent endpoint
# ===========================================================================

class TestExpandConsentEndpoint:
    def _park_unsatisfiable_job(self, client) -> str:
        # Use a production-included provider so the three-state allowlist
        # (docs/provider_testing_matrix.md) doesn't reject at submit —
        # we need the request to reach the feasibility check which is
        # what the test actually exercises.
        with patch("api.job_routes._has_dispatchable_candidate", return_value=False):
            r = client.post("/api/v1/jobs/run", json={
                "gpu_type": "H100",
                "regions": ["us-east-1"],
                "preferred_providers": ["RunPod"],
            }, headers={"Authorization": "Bearer vl_test_xxx"})
        assert r.status_code == 202
        return r.json()["job_id"]

    def test_unions_added_lists_into_existing(self, client):
        """expand-consent merges add_providers / add_regions into the job's
        existing whitelist (dedupe preserving order) and re-queues."""
        from api.job_worker import _active_jobs, _job_queue
        job_id = self._park_unsatisfiable_job(client)
        # Now make feasibility return True so the consent flips status to queued.
        with patch("api.job_routes._has_dispatchable_candidate", return_value=True):
            r = client.post(f"/api/v1/jobs/{job_id}/expand-consent", json={
                "add_providers": ["Lambda Labs"],
                "add_regions":   ["us-east-2"],
            }, headers={"Authorization": "Bearer vl_test_xxx"})
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "queued"
        assert _active_jobs[job_id]["preferred_providers"] == ["RunPod", "Lambda Labs"]
        assert _active_jobs[job_id]["regions"]            == ["us-east-1", "us-east-2"]
        assert job_id in _job_queue

    def test_rejects_when_status_not_awaiting(self, client):
        """expand-consent on a queued job returns 409 Conflict."""
        # Submit a feasible job (status=queued).
        with patch("api.job_routes._has_dispatchable_candidate", return_value=True):
            r1 = client.post("/api/v1/jobs/run", json={
                "gpu_type": "H100",
            }, headers={"Authorization": "Bearer vl_test_xxx"})
        job_id = r1.json()["job_id"]

        r2 = client.post(f"/api/v1/jobs/{job_id}/expand-consent", json={
            "add_providers": ["Lambda Labs"],
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        assert r2.status_code == 409
        assert "awaiting_expand_consent" in r2.json()["detail"]

    def test_empty_arrays_are_idempotent_noop(self, client):
        """Calling expand-consent with no add_* fields keeps the job parked
        and returns ok+noop=True so the CLI can detect the no-op."""
        from api.job_worker import _active_jobs
        job_id = self._park_unsatisfiable_job(client)
        r = client.post(f"/api/v1/jobs/{job_id}/expand-consent", json={
            "add_providers": [],
            "add_regions":   [],
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        assert r.status_code == 200
        body = r.json()
        assert body.get("noop") is True
        assert _active_jobs[job_id]["status"] == "awaiting_expand_consent"


# ===========================================================================
# 7. Resume flow — same-provider preference + resume_no_capacity cancel
# ===========================================================================

class TestResumeFlow:
    def _make_resume_job(self, **overrides) -> dict:
        base = {
            "job_id": "rj-001",
            "user_id": "u-1",
            "gpu_type": "H100",
            "environment": {},
            "docker_image": "",
            "failover": True,
            "preferred_providers": [],
            "excluded_providers": [],
            "regions": [],
            "excluded_regions": [],
            "_resume_prefer_provider": "runpod",
            "_is_resume_leg": True,
        }
        base.update(overrides)
        return base

    @pytest.mark.asyncio
    async def test_resume_prefers_original_provider(self):
        """When _resume_prefer_provider is set, the dispatcher tries that
        provider first even if a cheaper alternative exists."""
        from api.job_worker import _try_provision
        from shared.models import GPUType

        broker = MagicMock()
        broker.provision_vast = AsyncMock(return_value="inst-vast")
        broker.provision_runpod = AsyncMock(return_value="inst-rp")

        prices = {"Vast.ai": {"H100": 2.50}, "RunPod": {"H100": 3.00}}
        with patch("shared.data_loader.get_provider_prices", return_value=prices), \
             patch("shared.data_loader.resolve_gpu_key", return_value="H100"), \
             patch("shared.data_loader.resolve_gpu_enum", return_value=GPUType.H100_80GB_SXM):
            result = await _try_provision(broker, self._make_resume_job())
        # RunPod should have been tried FIRST despite being more expensive.
        assert result == "inst-rp"
        broker.provision_runpod.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_resume_skips_when_prefer_not_in_provider_prices(self):
        """If _resume_prefer_provider is no longer in provider_prices (config
        changed since the job ran), step (a) is silently skipped and the
        cheapest alternative wins."""
        from api.job_worker import _try_provision
        from shared.models import GPUType

        broker = MagicMock()
        broker.provision_vast = AsyncMock(return_value="inst-vast")

        prices = {"Vast.ai": {"H100": 2.50}}  # RunPod gone from config
        with patch("shared.data_loader.get_provider_prices", return_value=prices), \
             patch("shared.data_loader.resolve_gpu_key", return_value="H100"), \
             patch("shared.data_loader.resolve_gpu_enum", return_value=GPUType.H100_80GB_SXM):
            result = await _try_provision(
                broker, self._make_resume_job(_resume_prefer_provider="runpod")
            )
        assert result == "inst-vast"  # fell through to remaining routable

    @pytest.mark.asyncio
    async def test_resume_relaxes_preferred_filter_for_original(self):
        """Spec step (a): on a resume leg, the original provider is allowed
        through even if it's NOT in preferred_providers."""
        from api.job_worker import _try_provision
        from shared.models import GPUType

        broker = MagicMock()
        broker.provision_runpod = AsyncMock(return_value="inst-rp")
        broker.provision_vast = AsyncMock(return_value="inst-vast")

        prices = {"RunPod": {"H100": 3.00}, "Vast.ai": {"H100": 2.50}}
        # User originally constrained to AWS Spot only — but resume preference
        # is RunPod, so RunPod should still be tried first.
        job = self._make_resume_job(
            preferred_providers=["AWS Spot"],
            _resume_prefer_provider="runpod",
        )
        with patch("shared.data_loader.get_provider_prices", return_value=prices), \
             patch("shared.data_loader.resolve_gpu_key", return_value="H100"), \
             patch("shared.data_loader.resolve_gpu_enum", return_value=GPUType.H100_80GB_SXM):
            result = await _try_provision(broker, job)
        assert result == "inst-rp"
        # Vast.ai must NOT be attempted: it's not in preferred and not the
        # resume preference, so the preferred filter excludes it.
        broker.provision_vast.assert_not_awaited()


# ===========================================================================
# 8. Cancel endpoint — ?reason= param + email body persistence
# ===========================================================================

class TestCancelWithReason:
    def test_cancel_with_reason_param_returns_reason_in_body(self, client):
        with patch("api.job_routes._has_dispatchable_candidate", return_value=True):
            r1 = client.post("/api/v1/jobs/run", json={
                "gpu_type": "H100",
            }, headers={"Authorization": "Bearer vl_test_xxx"})
        job_id = r1.json()["job_id"]

        r2 = client.post(f"/api/v1/jobs/{job_id}/cancel?reason=user_declined",
                         headers={"Authorization": "Bearer vl_test_xxx"})
        assert r2.status_code == 200
        assert r2.json()["reason"] == "user_declined"
        assert r2.json()["status"] == "cancelled"

    def test_cancel_email_body_built_for_consent_timeout(self):
        """build_cancel_email_body produces the spec template verbatim."""
        from shared.email import build_cancel_email_body
        subj, body = build_cancel_email_body(
            job_id="abc-123",
            reason="consent_timeout",
            preferred_providers=["AWS Spot"],
            regions=["us-east-1"],
        )
        assert "abc-123" in subj
        assert "cancelled (no capacity)" in subj
        assert "Providers: AWS Spot" in body
        assert "Regions:   us-east-1" in body
        assert "Nothing was provisioned, no charge applied." in body
        assert "abc-123" in body  # dashboard URL contains the job_id

    def test_cancel_email_body_uses_any_when_lists_empty(self):
        from shared.email import build_cancel_email_body
        _, body = build_cancel_email_body(
            job_id="x", reason="resume_no_capacity",
            preferred_providers=[], regions=[],
        )
        assert "Providers: any" in body
        assert "Regions:   any" in body


# ===========================================================================
# 9. Resend delivery — RESEND_API_KEY gate + log-only fallback
# ===========================================================================

class TestSendCancelEmailDelivery:
    def test_no_api_key_falls_back_to_log_only(self, monkeypatch, caplog):
        """When RESEND_API_KEY is unset, send_cancel_email must NOT call resend
        and MUST emit the [TODO: send email] log line."""
        monkeypatch.delenv("RESEND_API_KEY", raising=False)
        import sys
        import logging
        from shared.email import send_cancel_email
        # Sentinel resend module that fails the test if called.
        fake_resend = type("R", (), {"api_key": "", "Emails": type("E", (), {
            "send": staticmethod(lambda *a, **kw: pytest.fail("resend.Emails.send must NOT run when RESEND_API_KEY is unset")),
        })})()
        monkeypatch.setitem(sys.modules, "resend", fake_resend)
        with caplog.at_level(logging.WARNING):
            send_cancel_email(
                job_id="abc", user_email="a@b.com", reason="consent_timeout",
                preferred_providers=[], regions=[], run_id=None,
            )
        assert any("[TODO: send email]" in rec.message for rec in caplog.records)

    def test_with_api_key_calls_resend_with_html(self, monkeypatch):
        monkeypatch.setenv("RESEND_API_KEY", "re_test_key")
        monkeypatch.setenv("EMAIL_FROM", "VaultLayer <noreply@vaultlayer.ai>")
        import sys
        captured: list[dict] = []
        fake_resend = type("R", (), {"api_key": "", "Emails": type("E", (), {
            "send": staticmethod(lambda payload: captured.append(payload)),
        })})()
        monkeypatch.setitem(sys.modules, "resend", fake_resend)
        from shared.email import send_cancel_email
        send_cancel_email(
            job_id="abc-123", user_email="alice@example.com",
            reason="resume_no_capacity",
            preferred_providers=["AWS Spot", "Lambda Labs"],
            regions=["us-east-1"],
            run_id=None,
        )
        assert len(captured) == 1
        payload = captured[0]
        assert payload["to"] == ["alice@example.com"]
        assert payload["from"] == "VaultLayer <noreply@vaultlayer.ai>"
        assert "abc-123" in payload["subject"]
        assert "cancelled (no capacity)" in payload["subject"]
        # HTML body carries the constraint context
        assert "AWS Spot" in payload["html"]
        assert "Lambda Labs" in payload["html"]
        assert "us-east-1" in payload["html"]
        assert "abc-123" in payload["html"]

    def test_no_email_address_skips_resend(self, monkeypatch, caplog):
        """Empty user_email must skip Resend entirely (no `to: [\"\"]` send)."""
        monkeypatch.setenv("RESEND_API_KEY", "re_test_key")
        import sys
        import logging
        fake_resend = type("R", (), {"api_key": "", "Emails": type("E", (), {
            "send": staticmethod(lambda *a, **kw: pytest.fail("must not call resend with empty email")),
        })})()
        monkeypatch.setitem(sys.modules, "resend", fake_resend)
        from shared.email import send_cancel_email
        with caplog.at_level(logging.WARNING):
            send_cancel_email(
                job_id="abc", user_email="", reason="consent_timeout",
                preferred_providers=[], regions=[], run_id=None,
            )
        assert any("[TODO: send email]" in rec.message for rec in caplog.records)

    def test_resend_exception_falls_through_to_log(self, monkeypatch, caplog):
        """If Resend raises (bad key, network error), we must NOT propagate —
        log it and continue. Cancel flow is best-effort on email."""
        monkeypatch.setenv("RESEND_API_KEY", "re_bad_key")
        import sys
        import logging
        def _boom(*a, **kw):
            raise RuntimeError("Resend says no")
        fake_resend = type("R", (), {"api_key": "", "Emails": type("E", (), {
            "send": staticmethod(_boom),
        })})()
        monkeypatch.setitem(sys.modules, "resend", fake_resend)
        from shared.email import send_cancel_email
        with caplog.at_level(logging.WARNING):
            # Must not raise even though resend.Emails.send blew up.
            send_cancel_email(
                job_id="abc", user_email="a@b.com", reason="consent_timeout",
                preferred_providers=[], regions=[], run_id=None,
            )
        # Both the Resend failure log AND the fallback [TODO: send email] log
        # should be present — the fallback is what makes the body recoverable
        # from Railway logs even when Resend fails.
        msgs = [r.message for r in caplog.records]
        assert any("Resend send failed" in m for m in msgs)
        assert any("[TODO: send email]" in m for m in msgs)
