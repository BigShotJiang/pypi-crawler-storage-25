"""
Tests for src/api/credentials.py — managed credential reader.

The public HTTP endpoints (POST /credentials/provider and GET
/credentials/providers) were removed in the security audit. The module
now exposes only the internal `_read_provider_credentials` helper used
by the broker in-process. These tests cover:

- Helper reads Railway env vars correctly for each supported provider
- Missing env vars → None (graceful)
- Rate-limit helper (kept for future internal callers)
- BrokerAgent._get_managed_credentials delegates to the helper
- main.py does NOT register /api/v1/credentials/provider or
  /api/v1/credentials/providers as routes
"""
from __future__ import annotations

import os
import time
from collections import deque
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ── Env setup for provider-key resolution ────────────────────────────────────

@pytest.fixture()
def test_env(monkeypatch):
    """Set Railway-style VL_* env vars for all configured providers."""
    monkeypatch.setenv("VL_LAMBDA_LABS_API_KEY", "ll-test-key-abc123")
    monkeypatch.setenv("VL_RUNPOD_API_KEY", "rp-test-key-xyz789")
    monkeypatch.setenv("VL_VAST_AI_API_KEY", "vast-test-key-111")
    monkeypatch.setenv("VL_HYPERSTACK_API_KEY", "hs-test-key-222")
    monkeypatch.setenv("VL_CRUSOE_API_KEY", "crusoe-test-key-333")
    monkeypatch.setenv("VL_CRUSOE_API_SECRET", "crusoe-secret-444")
    monkeypatch.setenv("VL_AWS_ACCESS_KEY_ID", "AKIATEST123")
    monkeypatch.setenv("VL_AWS_SECRET_ACCESS_KEY", "secret-test-key")
    monkeypatch.setenv("VL_AWS_DEFAULT_REGION", "us-east-1")
    monkeypatch.setenv("VL_GCP_CLIENT_EMAIL", "vl-sa@vaultlayer-prod.iam.gserviceaccount.com")
    monkeypatch.setenv("VL_GCP_PRIVATE_KEY", "-----BEGIN RSA PRIVATE KEY-----\nMIItest\n-----END RSA PRIVATE KEY-----\n")
    monkeypatch.setenv("VL_GCP_PROJECT_ID", "vaultlayer-prod")
    monkeypatch.setenv("VL_GCP_REGION", "us-central1")
    monkeypatch.setenv("VL_GCP_ZONE", "us-central1-a")
    monkeypatch.setenv("VL_VOLTAGE_PARK_API_KEY", "vp-test-key-555")
    # CoreWeave, Nebius, Azure intentionally NOT set → should appear as unavailable


@pytest.fixture(autouse=True)
def reset_rate_limit():
    """Clear in-memory rate limit state between tests."""
    from api.credentials import _cred_timestamps
    _cred_timestamps.clear()
    yield
    _cred_timestamps.clear()


# ── _read_provider_credentials ────────────────────────────────────────────────

class TestReadProviderCredentials:
    def test_lambda_labs_returns_api_key(self, test_env):
        from api.credentials import _read_provider_credentials
        creds = _read_provider_credentials("lambda_labs")
        assert creds is not None
        assert creds["api_key"] == "ll-test-key-abc123"

    def test_aws_returns_all_three_fields(self, test_env):
        from api.credentials import _read_provider_credentials
        creds = _read_provider_credentials("aws")
        assert creds is not None
        assert creds["access_key_id"] == "AKIATEST123"
        assert creds["secret_access_key"] == "secret-test-key"
        assert creds["region"] == "us-east-1"

    def test_gcp_returns_all_five_fields(self, test_env):
        from api.credentials import _read_provider_credentials
        creds = _read_provider_credentials("gcp")
        assert creds is not None
        assert creds["client_email"] == "vl-sa@vaultlayer-prod.iam.gserviceaccount.com"
        assert "-----BEGIN RSA PRIVATE KEY-----" in creds["private_key"]
        assert creds["project_id"] == "vaultlayer-prod"
        assert creds["region"] == "us-central1"
        assert creds["zone"] == "us-central1-a"

    def test_unknown_provider_returns_none(self, test_env):
        from api.credentials import _read_provider_credentials
        assert _read_provider_credentials("nonexistent") is None

    def test_missing_env_var_returns_none(self, monkeypatch):
        """If any required env var is missing, the whole provider returns None."""
        monkeypatch.setenv("VL_AWS_ACCESS_KEY_ID", "AKIATEST")
        monkeypatch.setenv("VL_AWS_SECRET_ACCESS_KEY", "secret")
        monkeypatch.delenv("VL_AWS_DEFAULT_REGION", raising=False)
        from api.credentials import _read_provider_credentials
        assert _read_provider_credentials("aws") is None

    def test_coreweave_returns_none_when_not_configured(self, test_env):
        """CoreWeave env vars not set → None."""
        from api.credentials import _read_provider_credentials
        assert _read_provider_credentials("coreweave") is None


# ── _check_rate_limit (kept for future internal callers) ─────────────────────

class TestRateLimit:
    def test_allows_up_to_30_requests(self):
        from api.credentials import _check_rate_limit
        for _ in range(30):
            assert _check_rate_limit("user-rl") is True

    def test_blocks_31st_request(self):
        from api.credentials import _check_rate_limit
        for _ in range(30):
            _check_rate_limit("user-31")
        assert _check_rate_limit("user-31") is False

    def test_different_users_have_independent_limits(self):
        from api.credentials import _check_rate_limit
        for _ in range(30):
            _check_rate_limit("user-a")
        assert _check_rate_limit("user-b") is True


# ── HTTP endpoints are REMOVED ────────────────────────────────────────────────

class TestHTTPEndpointsRemoved:
    """The credential-vending endpoints were removed as part of the audit.

    These tests lock in that decision: if a future change re-adds a route
    at the old paths, these tests fail and force a design conversation.
    """

    def test_post_credentials_provider_returns_404(self):
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from api.credentials import router
        app = FastAPI()
        app.include_router(router)
        client = TestClient(app)
        r = client.post("/api/v1/credentials/provider", json={"provider": "aws", "job_id": "x"})
        assert r.status_code == 404

    def test_get_credentials_providers_returns_404(self):
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from api.credentials import router
        app = FastAPI()
        app.include_router(router)
        client = TestClient(app)
        r = client.get("/api/v1/credentials/providers")
        assert r.status_code == 404

    def test_module_no_longer_exposes_get_provider_credentials(self):
        """Module-level symbol check — the function must be gone, not just hidden."""
        import api.credentials as m
        assert not hasattr(m, "get_provider_credentials"), (
            "get_provider_credentials should be removed — it was a public "
            "endpoint that vended VaultLayer's cloud keys to any authed user."
        )
        assert not hasattr(m, "list_available_providers"), (
            "list_available_providers should be removed — it enumerated which "
            "provider keys VaultLayer has configured."
        )


# ── Broker: _get_managed_credentials now reads env vars directly ─────────────

class TestBrokerManagedCredentials:
    """BrokerAgent._get_managed_credentials() now calls _read_provider_credentials
    in-process — no HTTP round trip, no public endpoint."""

    @pytest.fixture()
    def agent(self):
        from agents.broker.agent import BrokerAgent
        agent = BrokerAgent.__new__(BrokerAgent)
        agent.config = MagicMock()
        agent.config.token = "vl-test-token-xyz"
        agent._http_session = None
        return agent

    @pytest.mark.asyncio
    async def test_returns_credentials_for_configured_provider(self, agent, test_env):
        creds = await agent._get_managed_credentials("lambda_labs", "job-mgd-001")
        assert creds is not None
        assert creds["api_key"] == "ll-test-key-abc123"

    @pytest.mark.asyncio
    async def test_returns_none_for_unconfigured_provider(self, agent, monkeypatch):
        # CoreWeave has no env vars set
        monkeypatch.delenv("VL_COREWEAVE_API_KEY", raising=False)
        monkeypatch.delenv("VL_COREWEAVE_NAMESPACE", raising=False)
        creds = await agent._get_managed_credentials("coreweave", "job-mgd-002")
        assert creds is None

    @pytest.mark.asyncio
    async def test_returns_none_for_unknown_provider(self, agent):
        creds = await agent._get_managed_credentials("not-a-real-provider", "job-mgd-003")
        assert creds is None

    @pytest.mark.asyncio
    async def test_does_not_make_http_call(self, agent, test_env):
        """The new implementation reads env vars directly — no network I/O.
        If a future refactor brings back the HTTP round trip, this test fails.
        """
        with patch.object(agent, "_http") as mock_http:
            await agent._get_managed_credentials("aws", "job-mgd-004")
            assert not mock_http.called, (
                "_get_managed_credentials must not make HTTP calls — the public "
                "credential-vending endpoint was removed for security."
            )
