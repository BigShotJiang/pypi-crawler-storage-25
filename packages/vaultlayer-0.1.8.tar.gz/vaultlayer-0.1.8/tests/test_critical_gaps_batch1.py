"""
VaultLayer — Critical Gaps Batch 1 Tests
Tests for all 8 fixes in fix/critical-gaps-batch1.

FIX 1: docker_image in all non-AWS provisioners
FIX 2: Watchdog re-attach after migration (GAP-8)
FIX 3: Redis degraded mode / fallback webhook (GAP-30)
FIX 4: SHA256 verification on download/delta (GAP-27)
FIX 5: IMDSv2 synchronous token support (P1)
FIX 6: STS AssumeRole in provision_aws (P2) — already wired
FIX 7: Launch Templates + delete on failure (P4)
FIX 8: Live AWS Spot Price Monitor (P5)
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
import time
import hashlib
import zlib
from datetime import datetime
from unittest.mock import patch, AsyncMock, MagicMock, call
from conftest import MockAgentQueue, make_job


# ══════════════════════════════════════════════════════════════════════════════
# FIX 1: GAP-18 — docker_image in provisioners
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_provision_runpod_uses_job_docker_image(dummy_config, mock_queue):
    """provision_runpod must use job.docker_image as imageName when set."""
    from agents.broker.agent import BrokerAgent
    from shared.models import GPUType, Provider
    dummy_config.runpod = MagicMock()
    dummy_config.runpod.api_key = "rp-test-key"
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.docker_image = "my-org/custom-pytorch:2.3"

    mock_resp = AsyncMock()
    mock_resp.status = 200
    mock_resp.json = AsyncMock(return_value={"id": "pod-abc123"})
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)

    captured_payloads = []

    class _MockSession:
        def post(self, url, **kwargs):
            captured_payloads.append(kwargs.get("json", {}))
            return mock_resp
        async def __aenter__(self): return self
        async def __aexit__(self, *_): pass

    with patch("aiohttp.ClientSession", return_value=_MockSession()), \
         patch("agents.broker.agent.resolve_gpu_key", return_value="H100_80GB_SXM"), \
         patch("agents.broker.agent.is_gpu_available", return_value=True), \
         patch("agents.broker.agent.get_instance_string", return_value="NVIDIA H100 80GB HBM3"), \
         patch.object(agent.gpu_resolver, "resolve", new_callable=AsyncMock, return_value="NVIDIA H100 80GB HBM3"):
        result = await agent.provision_runpod(GPUType.H100_80GB_SXM, job)

    assert result == "pod-abc123"
    assert len(captured_payloads) == 1
    # REST API payload: imageName is a top-level field
    assert captured_payloads[0]["imageName"] == "my-org/custom-pytorch:2.3"


@pytest.mark.asyncio
async def test_provision_runpod_falls_back_to_default_image(dummy_config, mock_queue):
    """provision_runpod must fall back to 'runpod/pytorch:latest' when docker_image is empty."""
    from agents.broker.agent import BrokerAgent
    from shared.models import GPUType
    dummy_config.runpod = MagicMock()
    dummy_config.runpod.api_key = "rp-test-key"
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.docker_image = ""  # empty — should fall back

    mock_resp = AsyncMock()
    mock_resp.status = 200
    mock_resp.json = AsyncMock(return_value={"id": "pod-def456"})
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)

    captured_payloads = []

    class _MockSession:
        def post(self, url, **kwargs):
            captured_payloads.append(kwargs.get("json", {}))
            return mock_resp
        async def __aenter__(self): return self
        async def __aexit__(self, *_): pass

    with patch("aiohttp.ClientSession", return_value=_MockSession()), \
         patch("agents.broker.agent.resolve_gpu_key", return_value="H100_80GB_SXM"), \
         patch("agents.broker.agent.is_gpu_available", return_value=True), \
         patch("agents.broker.agent.get_instance_string", return_value="NVIDIA H100 80GB HBM3"), \
         patch.object(agent.gpu_resolver, "resolve", new_callable=AsyncMock, return_value="NVIDIA H100 80GB HBM3"):
        result = await agent.provision_runpod(GPUType.H100_80GB_SXM, job)

    assert result == "pod-def456"
    # REST API payload: imageName is a top-level field. Default now pinned
    # to a specific 2.1.0 tag — verified 2026-04-18 to have the /start.sh
    # → /pre_start.sh chain we rely on (pod brb74hkjwqrs5u SSH inspection).
    assert captured_payloads[0]["imageName"] == "runpod/pytorch:2.1.0-py3.10-cuda11.8.0-devel-ubuntu22.04"


@pytest.mark.asyncio
async def test_provision_vast_uses_job_docker_image(dummy_config, mock_queue):
    """provision_vast must use job.docker_image when set."""
    from agents.broker.agent import BrokerAgent
    from shared.models import GPUType
    dummy_config.vast_ai = MagicMock()
    dummy_config.vast_ai.api_key = "vast-test-key"
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.docker_image = "my-org/custom-pytorch:2.3"

    balance_resp = AsyncMock()
    balance_resp.status = 200
    balance_resp.json = AsyncMock(return_value={"credit": 100.0})
    balance_resp.__aenter__ = AsyncMock(return_value=balance_resp)
    balance_resp.__aexit__ = AsyncMock(return_value=False)

    search_resp = AsyncMock()
    search_resp.status = 200
    search_resp.json = AsyncMock(return_value={"offers": [{"id": 42, "dph_total": 2.5}]})
    search_resp.__aenter__ = AsyncMock(return_value=search_resp)
    search_resp.__aexit__ = AsyncMock(return_value=False)

    rent_resp = AsyncMock()
    rent_resp.status = 200
    rent_resp.json = AsyncMock(return_value={"new_contract": 42})
    rent_resp.__aenter__ = AsyncMock(return_value=rent_resp)
    rent_resp.__aexit__ = AsyncMock(return_value=False)

    captured_rent_payloads = []

    class _MockSession:
        def get(self, url, **kwargs):
            if "/users/current" in url:
                return balance_resp
            return search_resp
        def post(self, url, **kwargs):
            # /api/v0/bundles/ search is now POST per current Vast.ai docs.
            return search_resp
        def put(self, url, **kwargs):
            captured_rent_payloads.append(kwargs.get("json", {}))
            return rent_resp
        async def __aenter__(self): return self
        async def __aexit__(self, *_): pass

    with patch("aiohttp.ClientSession", return_value=_MockSession()), \
         patch("agents.broker.agent.resolve_gpu_key", return_value="H100_80GB_SXM"), \
         patch("agents.broker.agent.is_gpu_available", return_value=True), \
         patch("agents.broker.agent.get_instance_string", return_value="H100 SXM5"), \
         patch("agents.broker.agent.asyncio.sleep", new_callable=AsyncMock):
        result = await agent.provision_vast(GPUType.H100_80GB_SXM, job)

    assert result == "42"
    assert len(captured_rent_payloads) == 1
    assert captured_rent_payloads[0]["image"] == "my-org/custom-pytorch:2.3"


@pytest.mark.asyncio
async def test_provision_vast_falls_back_to_default_image(dummy_config, mock_queue):
    """provision_vast must fall back to default image when docker_image is empty."""
    from agents.broker.agent import BrokerAgent
    from shared.models import GPUType
    dummy_config.vast_ai = MagicMock()
    dummy_config.vast_ai.api_key = "vast-test-key"
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.docker_image = ""

    balance_resp = AsyncMock()
    balance_resp.status = 200
    balance_resp.json = AsyncMock(return_value={"credit": 100.0})
    balance_resp.__aenter__ = AsyncMock(return_value=balance_resp)
    balance_resp.__aexit__ = AsyncMock(return_value=False)

    search_resp = AsyncMock()
    search_resp.status = 200
    search_resp.json = AsyncMock(return_value={"offers": [{"id": 99, "dph_total": 2.5}]})
    search_resp.__aenter__ = AsyncMock(return_value=search_resp)
    search_resp.__aexit__ = AsyncMock(return_value=False)

    rent_resp = AsyncMock()
    rent_resp.status = 200
    rent_resp.json = AsyncMock(return_value={"new_contract": 99})
    rent_resp.__aenter__ = AsyncMock(return_value=rent_resp)
    rent_resp.__aexit__ = AsyncMock(return_value=False)

    captured_rent_payloads = []

    class _MockSession:
        def get(self, url, **kwargs):
            if "/users/current" in url:
                return balance_resp
            return search_resp
        def post(self, url, **kwargs):
            # /api/v0/bundles/ search is now POST per current Vast.ai docs.
            return search_resp
        def put(self, url, **kwargs):
            captured_rent_payloads.append(kwargs.get("json", {}))
            return rent_resp
        async def __aenter__(self): return self
        async def __aexit__(self, *_): pass

    with patch("aiohttp.ClientSession", return_value=_MockSession()), \
         patch("agents.broker.agent.resolve_gpu_key", return_value="H100_80GB_SXM"), \
         patch("agents.broker.agent.is_gpu_available", return_value=True), \
         patch("agents.broker.agent.get_instance_string", return_value="H100 SXM5"), \
         patch("agents.broker.agent.asyncio.sleep", new_callable=AsyncMock):
        result = await agent.provision_vast(GPUType.H100_80GB_SXM, job)

    assert result == "99"
    # Updated 2026-04-19 per Vast.ai support guidance: -devel (not -runtime)
    # ships CUDA headers bitsandbytes needs; torch 2.1.2 pairs with triton 2.1.0.
    assert captured_rent_payloads[0]["image"] == "pytorch/pytorch:2.1.2-cuda12.1-cudnn8-devel"


# ══════════════════════════════════════════════════════════════════════════════
# FIX 2: GAP-8 — Watchdog re-attaches after migration
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_watchdog_reattaches_after_migration(dummy_config, mock_queue):
    """After NODE_PROVISIONED with reattach_watchdog=True, watchdog resets last_heartbeat_at."""
    from agents.watchdog.agent import WatchdogAgent
    from shared.models import AgentEvent, EventType
    from datetime import timedelta

    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()

    # Set a stale heartbeat that would normally trigger HEARTBEAT_MISS
    job.last_heartbeat_at = datetime.utcnow() - timedelta(minutes=60)
    agent._active_jobs[job.job_id] = job
    agent._checkpoint_callbacks[job.job_id] = AsyncMock()
    # Register with stale heartbeat
    agent._heartbeat._last_heartbeats[job.job_id] = job.last_heartbeat_at
    agent._heartbeat._miss_counts[job.job_id] = 5

    # Simulate receiving NODE_PROVISIONED with reattach_watchdog
    event = AgentEvent(
        event_type=EventType.NODE_PROVISIONED,
        source_agent="broker_agent",
        job_id=job.job_id,
        payload={
            "new_instance_id": "i-new-node-123",
            "new_provider": "lambda_labs",
            "host": "10.0.1.50",
            "reattach_watchdog": True,
        },
        priority=2,
    )

    before_call = datetime.utcnow()
    await agent.handle_node_provisioned(event)

    # Heartbeat should now be fresh (within a few seconds of now)
    fresh_heartbeat = agent._heartbeat._last_heartbeats.get(job.job_id)
    assert fresh_heartbeat is not None
    assert fresh_heartbeat >= before_call, "Heartbeat must be reset to now (fresh grace period)"
    # Miss count should be reset to 0
    assert agent._heartbeat._miss_counts.get(job.job_id, 0) == 0


@pytest.mark.asyncio
async def test_watchdog_does_not_reattach_without_flag(dummy_config, mock_queue):
    """handle_node_provisioned must be a no-op when reattach_watchdog is not True."""
    from agents.watchdog.agent import WatchdogAgent
    from shared.models import AgentEvent, EventType
    from datetime import timedelta

    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.last_heartbeat_at = datetime.utcnow() - timedelta(minutes=60)
    agent._active_jobs[job.job_id] = job
    stale_time = datetime.utcnow() - timedelta(minutes=60)
    agent._heartbeat._last_heartbeats[job.job_id] = stale_time

    event = AgentEvent(
        event_type=EventType.NODE_PROVISIONED,
        source_agent="broker_agent",
        job_id=job.job_id,
        payload={
            "new_instance_id": "i-new-node",
            "reattach_watchdog": False,  # NOT requesting reattach
        },
        priority=2,
    )

    await agent.handle_node_provisioned(event)

    # Heartbeat should NOT have been reset
    still_stale = agent._heartbeat._last_heartbeats.get(job.job_id)
    assert still_stale == stale_time, "Heartbeat must not be changed when reattach_watchdog is False"


# ══════════════════════════════════════════════════════════════════════════════
# FIX 3: GAP-30 — Redis degraded mode
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_queue_publish_survives_redis_failure():
    """publish() must not raise when Redis is down, and must set _degraded=True."""
    from shared.queue import AgentQueue
    from shared.models import AgentEvent, EventType

    queue = AgentQueue("redis://localhost:6379")
    # Simulate a connected but broken Redis client
    mock_client = MagicMock()
    mock_client.publish = AsyncMock(side_effect=ConnectionError("Redis is down"))
    queue._client = mock_client

    event = AgentEvent(
        event_type=EventType.TERMINATION_SIGNAL,
        source_agent="watchdog_agent",
        job_id="test-job-001",
        payload={"reason": "spot_interruption"},
    )

    # Must NOT raise
    result = await queue.publish("watchdog", event)

    assert result == 0, "Failed publish must return 0"
    assert queue._degraded is True, "Queue must enter degraded mode after Redis failure"


@pytest.mark.asyncio
async def test_queue_publish_degraded_triggers_webhook_for_critical_events():
    """When Redis fails for TERMINATION_SIGNAL, _fallback_notify must be called."""
    from shared.queue import AgentQueue
    from shared.models import AgentEvent, EventType

    queue = AgentQueue("redis://localhost:6379")
    mock_client = MagicMock()
    mock_client.publish = AsyncMock(side_effect=ConnectionError("Redis is down"))
    queue._client = mock_client

    fallback_called = []

    async def _fake_fallback(channel, event):
        fallback_called.append((channel, event))

    queue._fallback_notify = _fake_fallback

    event = AgentEvent(
        event_type=EventType.TERMINATION_SIGNAL,
        source_agent="watchdog_agent",
        job_id="test-job-002",
        payload={"reason": "spot_interruption"},
    )

    with patch.dict(os.environ, {"VAULTLAYER_WEBHOOK_URL": "http://fake-webhook/"}):
        await queue.publish("watchdog", event)

    assert len(fallback_called) == 1, "Fallback must be called for critical events"
    assert fallback_called[0][0] == "watchdog"


@pytest.mark.asyncio
async def test_queue_publish_no_fallback_for_non_critical_events():
    """Non-critical events (PRICE_UPDATE) must NOT trigger fallback on Redis failure."""
    from shared.queue import AgentQueue
    from shared.models import AgentEvent, EventType

    queue = AgentQueue("redis://localhost:6379")
    mock_client = MagicMock()
    mock_client.publish = AsyncMock(side_effect=ConnectionError("Redis is down"))
    queue._client = mock_client

    fallback_called = []

    async def _fake_fallback(channel, event):
        fallback_called.append((channel, event))

    queue._fallback_notify = _fake_fallback

    event = AgentEvent(
        event_type=EventType.PRICE_UPDATE,
        source_agent="pricing_agent",
        job_id=None,
        payload={"prices": []},
    )

    await queue.publish("pricing", event)

    assert len(fallback_called) == 0, "PRICE_UPDATE must not trigger webhook fallback"


# ══════════════════════════════════════════════════════════════════════════════
# FIX 4: GAP-27 — SHA256 verification on download
# ══════════════════════════════════════════════════════════════════════════════

def test_download_raises_on_sha256_mismatch(tmp_path):
    """download_checkpoint must raise ValueError when stored SHA256 doesn't match data."""
    from agents.vault.r2 import R2Client
    from shared.models import CheckpointRecord

    client = R2Client(
        endpoint="https://fake.r2.cloudflarestorage.com",
        access_key_id="fake-key",
        secret_access_key="fake-secret",
        bucket="test-bucket",
    )
    client._s3 = MagicMock()

    # Create valid data but report wrong hash in metadata
    actual_data = b"actual checkpoint data bytes"
    compressed = zlib.compress(actual_data)
    correct_hash = hashlib.sha256(compressed).hexdigest()
    wrong_hash = "a" * 64  # clearly wrong

    client._s3.get_object.return_value = {
        "Body": MagicMock(read=MagicMock(return_value=compressed)),
        "Metadata": {"sha256": wrong_hash},
        "ResponseMetadata": {"HTTPHeaders": {}},
    }

    record = CheckpointRecord(
        job_id="job-sha-test",
        step=100,
        epoch=1.0,
        r2_key="checkpoints/job-sha-test/step-00000100/model.pt",
        size_bytes=len(actual_data),
        sync_duration_seconds=1.0,
        model_params_billion=7.0,
    )

    with pytest.raises(ValueError, match="Checksum mismatch"):
        client.download_checkpoint(record, str(tmp_path))


def test_download_succeeds_on_sha256_match(tmp_path):
    """download_checkpoint must succeed when stored SHA256 matches."""
    from agents.vault.r2 import R2Client
    from shared.models import CheckpointRecord
    from shared.security import get_encryption

    client = R2Client(
        endpoint="https://fake.r2.cloudflarestorage.com",
        access_key_id="fake-key",
        secret_access_key="fake-secret",
        bucket="test-bucket",
    )
    client._s3 = MagicMock()

    actual_data = b"valid checkpoint data"
    compressed = zlib.compress(actual_data)
    correct_hash = hashlib.sha256(compressed).hexdigest()

    client._s3.get_object.return_value = {
        "Body": MagicMock(read=MagicMock(return_value=compressed)),
        "Metadata": {"sha256": correct_hash},
        "ResponseMetadata": {"HTTPHeaders": {}},
    }

    record = CheckpointRecord(
        job_id="job-sha-ok",
        step=200,
        epoch=2.0,
        r2_key="checkpoints/job-sha-ok/step-00000200/model.pt",
        size_bytes=len(actual_data),
        sync_duration_seconds=1.0,
        model_params_billion=7.0,
    )

    # Mock encryption to be a no-op
    mock_enc = MagicMock()
    mock_enc.enabled = False
    mock_enc.decrypt = lambda data: data

    with patch("agents.vault.r2.get_encryption", return_value=mock_enc), \
         patch("agents.vault.r2.get_audit", return_value=MagicMock()):
        result = client.download_checkpoint(record, str(tmp_path))

    assert result is not None
    assert "model.pt" in result


def test_download_skips_sha256_check_when_no_metadata(tmp_path):
    """download_checkpoint must succeed when no SHA256 metadata is stored (backward compat)."""
    from agents.vault.r2 import R2Client
    from shared.models import CheckpointRecord

    client = R2Client(
        endpoint="https://fake.r2.cloudflarestorage.com",
        access_key_id="fake-key",
        secret_access_key="fake-secret",
        bucket="test-bucket",
    )
    client._s3 = MagicMock()

    actual_data = b"old checkpoint without sha256"
    compressed = zlib.compress(actual_data)

    client._s3.get_object.return_value = {
        "Body": MagicMock(read=MagicMock(return_value=compressed)),
        "Metadata": {},  # no sha256
        "ResponseMetadata": {"HTTPHeaders": {}},
    }

    record = CheckpointRecord(
        job_id="job-no-sha",
        step=300,
        epoch=3.0,
        r2_key="checkpoints/job-no-sha/step-00000300/model.pt",
        size_bytes=len(actual_data),
        sync_duration_seconds=1.0,
        model_params_billion=7.0,
    )

    mock_enc = MagicMock()
    mock_enc.enabled = False
    mock_enc.decrypt = lambda data: data

    with patch("agents.vault.r2.get_encryption", return_value=mock_enc), \
         patch("agents.vault.r2.get_audit", return_value=MagicMock()):
        result = client.download_checkpoint(record, str(tmp_path))  # must not raise

    assert result is not None


# ══════════════════════════════════════════════════════════════════════════════
# FIX 5: P1 — IMDSv2 synchronous token methods
# ══════════════════════════════════════════════════════════════════════════════

def test_imdsv2_sync_token_fetched_and_cached():
    """_fetch_imdsv2_token must cache token and use it on second call (urlopen once)."""
    from agents.watchdog.signals import TerminationDetector
    detector = TerminationDetector()

    mock_resp = MagicMock()
    mock_resp.read.return_value = b"sync-imdsv2-token-xyz"
    mock_resp.__enter__ = MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = MagicMock(return_value=False)

    urlopen_call_count = [0]

    def _mock_urlopen(req, timeout=None):
        urlopen_call_count[0] += 1
        return mock_resp

    with patch("urllib.request.urlopen", side_effect=_mock_urlopen):
        token1 = detector._fetch_imdsv2_token()
        token2 = detector._fetch_imdsv2_token()  # should use cache

    assert token1 == "sync-imdsv2-token-xyz"
    assert token2 == "sync-imdsv2-token-xyz"
    assert urlopen_call_count[0] == 1, "urlopen must be called only once (token cached)"


def test_imdsv2_sync_fallback_when_token_fails():
    """_fetch_imdsv2_token must return None when PUT fails (not on EC2 or IMDSv1-only)."""
    from agents.watchdog.signals import TerminationDetector
    detector = TerminationDetector()

    with patch("urllib.request.urlopen", side_effect=Exception("Connection refused")):
        token = detector._fetch_imdsv2_token()

    assert token is None


def test_check_termination_sync_returns_true_on_200():
    """check_termination_sync must return True when IMDS returns 200."""
    from agents.watchdog.signals import TerminationDetector
    detector = TerminationDetector()
    # Pre-set a valid token so token fetch is skipped
    detector._imds_token = "test-token"
    detector._imds_token_expiry = time.monotonic() + 10000

    mock_resp = MagicMock()
    mock_resp.status = 200
    mock_resp.__enter__ = MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = MagicMock(return_value=False)

    with patch("urllib.request.urlopen", return_value=mock_resp):
        result = detector.check_termination_sync()

    assert result is True


def test_check_termination_sync_returns_false_on_404():
    """check_termination_sync must return False when IMDS returns 404 (healthy instance)."""
    import urllib.error
    from agents.watchdog.signals import TerminationDetector
    detector = TerminationDetector()
    detector._imds_token = "test-token"
    detector._imds_token_expiry = time.monotonic() + 10000

    http_error = urllib.error.HTTPError(
        url="http://169.254.169.254/latest/meta-data/spot/termination-time",
        code=404, msg="Not Found", hdrs=None, fp=None
    )

    with patch("urllib.request.urlopen", side_effect=http_error):
        result = detector.check_termination_sync()

    assert result is False


def test_check_termination_sync_no_token_header_when_token_absent():
    """When no IMDSv2 token available, check_termination_sync must not include token header."""
    import urllib.error
    from agents.watchdog.signals import TerminationDetector
    detector = TerminationDetector()
    # No token set, token fetch will fail
    with patch("urllib.request.urlopen", side_effect=[
        Exception("IMDSv2 not supported"),  # token PUT fails
        urllib.error.HTTPError(url="x", code=404, msg="Not Found", hdrs=None, fp=None),  # termination check
    ]):
        result = detector.check_termination_sync()

    assert result is False  # 404 = not terminating, no crash


# ══════════════════════════════════════════════════════════════════════════════
# FIX 6: P2 — STS credentials in provision_aws
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_provision_aws_uses_sts_credentials_when_role_arn_set(dummy_config, mock_queue, monkeypatch):
    """provision_aws must call _sts.get_ec2_client which uses STS when role_arn is set."""
    from agents.broker.agent import BrokerAgent
    from shared.config import STSConfig
    from shared.models import GPUType

    # Pin to primary region only + disable OD fallback — this test asserts
    # a single get_ec2_client call (spot-only, single-region behavior)
    monkeypatch.setenv("VL_AWS_REGION_LOCKED", "1")
    monkeypatch.setenv("VL_AWS_OD_FALLBACK_ENABLED", "false")
    dummy_config.sts = STSConfig(role_arn="arn:aws:iam::123456:role/VaultLayerRole")
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)

    # Mock _sts.get_ec2_client to return a mock EC2 client
    mock_ec2 = MagicMock()
    mock_ec2.create_launch_template.return_value = {}
    mock_ec2.run_instances.return_value = {
        "Instances": [{"InstanceId": "i-sts-test-001"}]
    }
    mock_ec2.describe_instances.return_value = {
        "Reservations": [{"Instances": [{"State": {"Name": "running"}}]}]
    }
    mock_ec2.delete_launch_template.return_value = {}

    sts_calls = []

    def _mock_get_ec2(job_id, region):
        sts_calls.append({"job_id": job_id, "region": region})
        return mock_ec2

    agent._sts.get_ec2_client = _mock_get_ec2
    job = make_job()

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await agent.provision_aws(GPUType.H100_80GB_SXM, job)

    assert len(sts_calls) == 1, "get_ec2_client must be called once"
    assert sts_calls[0]["job_id"] == job.job_id


@pytest.mark.asyncio
async def test_provision_aws_tags_include_project_vaultlayer_managed(dummy_config, mock_queue):
    """provision_aws must include VaultLayer-Managed project tag in TagSpecifications."""
    from agents.broker.agent import BrokerAgent
    from shared.models import GPUType

    agent = BrokerAgent(config=dummy_config, queue=mock_queue)

    mock_ec2 = MagicMock()
    mock_ec2.describe_images.return_value = {
        "Images": [{"ImageId": "ami-0tag0000000000aa", "CreationDate": "2024-01-01T00:00:00.000Z"}]
    }
    mock_ec2.describe_key_pairs.return_value = {"KeyPairs": [{"KeyName": "vaultlayer-us-east-1"}]}
    mock_ec2.create_launch_template.return_value = {}
    captured_run_instances = []

    def _run_instances(**kwargs):
        captured_run_instances.append(kwargs)
        return {"Instances": [{"InstanceId": "i-tag-test-001"}]}

    mock_ec2.run_instances.side_effect = _run_instances
    mock_ec2.describe_instances.return_value = {
        "Reservations": [{"Instances": [{"State": {"Name": "running"}}]}]
    }
    mock_ec2.delete_launch_template.return_value = {}

    agent._sts.get_ec2_client = MagicMock(return_value=mock_ec2)
    job = make_job()

    with patch("asyncio.sleep", new_callable=AsyncMock):
        await agent.provision_aws(GPUType.H100_80GB_SXM, job)

    assert len(captured_run_instances) == 1
    tag_specs = captured_run_instances[0]["TagSpecifications"]
    all_tags = [t for spec in tag_specs for t in spec.get("Tags", [])]
    project_tags = [t for t in all_tags if t.get("Key") == "Project"]
    assert project_tags, "Must include Project tag in TagSpecifications"
    assert project_tags[0]["Value"] == "VaultLayer-Managed"


# ══════════════════════════════════════════════════════════════════════════════
# FIX 7: P4 — Launch Template cleanup on failure
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_provision_aws_uses_run_instances_not_request_spot(dummy_config, mock_queue):
    """provision_aws must call run_instances() (not the deprecated request_spot_instances())."""
    from agents.broker.agent import BrokerAgent
    from shared.models import GPUType

    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()

    mock_ec2 = MagicMock()
    mock_ec2.describe_images.return_value = {
        "Images": [{"ImageId": "ami-0run0000000000bb", "CreationDate": "2024-01-01T00:00:00.000Z"}]
    }
    mock_ec2.describe_key_pairs.return_value = {"KeyPairs": [{"KeyName": "vaultlayer-us-east-1"}]}
    mock_ec2.create_launch_template.return_value = {}
    mock_ec2.run_instances.return_value = {"Instances": [{"InstanceId": "i-run-test-001"}]}
    mock_ec2.describe_instances.return_value = {
        "Reservations": [{"Instances": [{"State": {"Name": "running"}}]}]
    }
    mock_ec2.delete_launch_template.return_value = {}

    agent._sts.get_ec2_client = MagicMock(return_value=mock_ec2)

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await agent.provision_aws(GPUType.H100_80GB_SXM, job)

    mock_ec2.run_instances.assert_called_once(), "provision_aws must call run_instances()"
    assert not hasattr(mock_ec2, 'request_spot_instances') or not mock_ec2.request_spot_instances.called, \
        "provision_aws must NOT call request_spot_instances()"


@pytest.mark.asyncio
async def test_provision_aws_creates_and_deletes_launch_template(dummy_config, mock_queue):
    """provision_aws must call create_launch_template AND delete_launch_template."""
    from agents.broker.agent import BrokerAgent
    from shared.models import GPUType

    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()

    mock_ec2 = MagicMock()
    mock_ec2.describe_images.return_value = {
        "Images": [{"ImageId": "ami-0mock0000000000a1", "CreationDate": "2024-01-01T00:00:00.000Z"}]
    }
    mock_ec2.create_launch_template.return_value = {}
    mock_ec2.run_instances.return_value = {"Instances": [{"InstanceId": "i-lt-test-001"}]}
    mock_ec2.describe_instances.return_value = {
        "Reservations": [{"Instances": [{"State": {"Name": "running"}}]}]
    }
    mock_ec2.delete_launch_template.return_value = {}

    agent._sts.get_ec2_client = MagicMock(return_value=mock_ec2)

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await agent.provision_aws(GPUType.H100_80GB_SXM, job)

    assert result == "i-lt-test-001"
    mock_ec2.create_launch_template.assert_called_once()
    mock_ec2.delete_launch_template.assert_called_once()


@pytest.mark.asyncio
async def test_provision_aws_launch_template_deleted_even_on_failure(dummy_config, mock_queue, monkeypatch):
    """delete_launch_template must be called even if run_instances raises."""
    from agents.broker.agent import BrokerAgent
    from shared.models import GPUType

    # Pin to primary region + disable OD fallback — this test asserts
    # single-region single-call cleanup behavior (spot-only path)
    monkeypatch.setenv("VL_AWS_REGION_LOCKED", "1")
    monkeypatch.setenv("VL_AWS_OD_FALLBACK_ENABLED", "false")
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()

    mock_ec2 = MagicMock()
    mock_ec2.describe_images.return_value = {
        "Images": [{"ImageId": "ami-0fail000000000cc", "CreationDate": "2024-01-01T00:00:00.000Z"}]
    }
    mock_ec2.describe_key_pairs.return_value = {"KeyPairs": [{"KeyName": "vaultlayer-us-east-1"}]}
    mock_ec2.create_launch_template.return_value = {}
    mock_ec2.run_instances.side_effect = Exception("InsufficientInstanceCapacity")
    mock_ec2.delete_launch_template.return_value = {}

    agent._sts.get_ec2_client = MagicMock(return_value=mock_ec2)

    result = await agent.provision_aws(GPUType.H100_80GB_SXM, job)

    assert result is None, "Must return None when run_instances fails"
    mock_ec2.delete_launch_template.assert_called_once(), \
        "delete_launch_template must be called even when run_instances fails"


# ══════════════════════════════════════════════════════════════════════════════
# FIX 8: P5 — Live AWS Spot Price Monitor
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_fetch_aws_spot_returns_gpu_prices(dummy_config, mock_queue):
    """fetch_aws_spot must return GPUPrice objects with is_spot=True."""
    from agents.pricing.agent import PricingAgent
    from shared.models import GPUType, Provider

    agent = PricingAgent(config=dummy_config, queue=mock_queue)

    fake_spot_history = {
        "SpotPriceHistory": [
            {
                "InstanceType": "p5.48xlarge",
                "AvailabilityZone": "us-east-1a",
                "SpotPrice": "18.50",
                "Timestamp": datetime.utcnow(),
                "ProductDescription": "Linux/UNIX",
            },
            {
                "InstanceType": "p4d.24xlarge",
                "AvailabilityZone": "us-east-1b",
                "SpotPrice": "8.20",
                "Timestamp": datetime.utcnow(),
                "ProductDescription": "Linux/UNIX",
            },
        ]
    }

    mock_ec2 = MagicMock()
    mock_ec2.describe_spot_price_history.return_value = fake_spot_history

    with patch("shared.sts.STSSessionManager") as MockSTS:
        MockSTS.return_value.get_ec2_client.return_value = mock_ec2
        prices = await agent.fetch_aws_spot()

    assert len(prices) > 0, "Must return at least one GPUPrice"
    assert all(p.is_spot is True for p in prices), "All returned prices must have is_spot=True"
    assert all(p.provider == Provider.AWS for p in prices), "All prices must be from AWS"
    price_per_hours = [p.price_per_hour for p in prices]
    assert any(abs(p - 18.50) < 0.01 or abs(p - 8.20) < 0.01 for p in price_per_hours), \
        "Must include prices from fake response"


@pytest.mark.asyncio
async def test_fetch_aws_spot_handles_api_failure_gracefully(dummy_config, mock_queue):
    """fetch_aws_spot must return empty list (not crash) when EC2 API fails."""
    from agents.pricing.agent import PricingAgent

    agent = PricingAgent(config=dummy_config, queue=mock_queue)

    mock_ec2 = MagicMock()
    mock_ec2.describe_spot_price_history.side_effect = Exception("AccessDenied")

    with patch("shared.sts.STSSessionManager") as MockSTS:
        MockSTS.return_value.get_ec2_client.return_value = mock_ec2
        prices = await agent.fetch_aws_spot()

    assert isinstance(prices, list), "Must return a list even on failure"
    # With 3 regions all failing, result may be empty or partial
    # Key requirement: no exception raised


def test_find_best_spot_az_for_gpu_picks_lowest_price(dummy_config, mock_queue):
    """find_best_spot_az_for_gpu must return the GPUPrice with the lowest price_per_hour."""
    from agents.pricing.agent import PricingAgent
    from shared.models import GPUPrice, GPUType, Provider

    agent = PricingAgent(config=dummy_config, queue=mock_queue)

    prices = [
        GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.AWS,
                 region="us-east-1a", price_per_hour=25.0, availability="high", is_spot=True),
        GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.AWS,
                 region="us-east-1b", price_per_hour=18.5, availability="high", is_spot=True),  # cheapest
        GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.AWS,
                 region="us-west-2a", price_per_hour=22.0, availability="medium", is_spot=True),
        GPUPrice(gpu=GPUType.A100_80GB_SXM, provider=Provider.AWS,
                 region="us-east-1a", price_per_hour=9.0, availability="high", is_spot=True),  # different GPU
    ]

    best = agent.find_best_spot_az_for_gpu(GPUType.H100_80GB_SXM, prices)

    assert best is not None
    assert best.price_per_hour == 18.5, f"Expected cheapest AZ at $18.5, got {best.price_per_hour}"
    assert best.region == "us-east-1b"
    assert best.gpu == GPUType.H100_80GB_SXM


def test_find_best_spot_az_for_gpu_returns_none_when_no_matching(dummy_config, mock_queue):
    """find_best_spot_az_for_gpu must return None when no AWS spot prices for the GPU."""
    from agents.pricing.agent import PricingAgent
    from shared.models import GPUPrice, GPUType, Provider

    agent = PricingAgent(config=dummy_config, queue=mock_queue)

    prices = [
        GPUPrice(gpu=GPUType.A100_40GB, provider=Provider.AWS,
                 region="us-east-1a", price_per_hour=9.0, availability="high", is_spot=True),
    ]

    best = agent.find_best_spot_az_for_gpu(GPUType.H100_80GB_SXM, prices)
    assert best is None


@pytest.mark.asyncio
async def test_fetch_aws_spot_covers_multiple_regions(dummy_config, mock_queue):
    """fetch_aws_spot must query EC2 API for each of the defined regions."""
    from agents.pricing.agent import PricingAgent, AWS_SPOT_REGIONS

    agent = PricingAgent(config=dummy_config, queue=mock_queue)

    region_calls = []

    def _mock_get_ec2(job_id, region):
        region_calls.append(region)
        mock_ec2 = MagicMock()
        mock_ec2.describe_spot_price_history.return_value = {"SpotPriceHistory": []}
        return mock_ec2

    with patch("shared.sts.STSSessionManager") as MockSTS:
        MockSTS.return_value.get_ec2_client.side_effect = _mock_get_ec2
        await agent.fetch_aws_spot()

    for region in AWS_SPOT_REGIONS:
        assert region in region_calls, f"fetch_aws_spot must query region {region}"
