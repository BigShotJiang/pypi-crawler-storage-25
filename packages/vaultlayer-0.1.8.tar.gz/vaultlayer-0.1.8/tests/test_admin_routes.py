"""
Tests for src/api/admin_routes.py

Covers:
  - GET  /api/v1/jobs/worker/debug  — worker state, auth required
  - POST /api/v1/jobs/admin/cleanup-instances — Vast.ai + RunPod destroy
  - POST /api/v1/jobs/admin/terminate-pods   — direct pod termination
  - POST /api/v1/jobs/{id}/cancel           — cancels job with non-running status
                                               but existing instance_id (billing leak fix)
"""
import asyncio
import os
import sys
import time
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _isolate(monkeypatch):
    # Import all modules that cache TESTING_MODE via `from api.flags import ...`
    # BEFORE setting TESTING_MODE. This lets monkeypatch record the real "before"
    # value so it can restore them properly after the test — preventing global
    # state contamination in subsequent test files.
    import api.flags
    import api.auth
    import api.credits
    import api.stripe_routes

    monkeypatch.setenv("VL_TESTING_MODE", "1")
    monkeypatch.setattr(api.flags, "TESTING_MODE", True)
    monkeypatch.setattr(api.auth, "TESTING_MODE", True)
    monkeypatch.setattr(api.credits, "TESTING_MODE", True)
    monkeypatch.setattr(api.stripe_routes, "TESTING_MODE", True)
    yield
    import api.job_worker as jr
    jr._broker_instance = None
    jr._active_jobs.clear()
    jr._job_queue.clear()
    jr._worker_debug.update({
        "started": False, "last_error": None, "broker_ok": False,
        "cycle_count": 0, "last_provision_attempts": [],
    })
    try:
        from api.db import get_db
        get_db.cache_clear()
    except Exception:
        pass


@pytest.fixture
def admin_client():
    """FastAPI TestClient with admin_jobs_router mounted and auth bypassed."""
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from api.admin_routes import admin_jobs_router
    from api.auth import require_internal_admin

    async def _fake_admin():
        return None  # no-op — passes auth

    app = FastAPI()
    app.dependency_overrides[require_internal_admin] = _fake_admin
    app.include_router(admin_jobs_router)
    return TestClient(app)


@pytest.fixture
def jobs_client():
    """FastAPI TestClient with jobs_router mounted and user auth bypassed."""
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from api.job_routes import jobs_router
    from api.auth import require_auth

    async def _fake_auth():
        return {"user_id": "test-user", "email": "test@test.com"}

    app = FastAPI()
    app.dependency_overrides[require_auth] = _fake_auth
    app.include_router(jobs_router)
    return TestClient(app)


# ===========================================================================
# 1. Worker debug endpoint
# ===========================================================================

class TestWorkerDebug:
    def test_debug_returns_queue_and_job_counts(self, admin_client):
        """GET /worker/debug returns queue_size and active_jobs counts."""
        import api.job_worker as jr
        jr._worker_debug.update({"started": True, "cycle_count": 5})
        r = admin_client.get("/api/v1/jobs/worker/debug")
        assert r.status_code == 200
        data = r.json()
        assert "queue_size" in data
        assert "active_jobs" in data
        assert data["queue_size"] == 0
        assert data["active_jobs"] == 0

    def test_debug_reflects_active_job_count(self, admin_client):
        """active_jobs count matches _active_jobs dict size."""
        import api.job_worker as jr
        jr._active_jobs["job-aaa"] = {"status": "running"}
        jr._active_jobs["job-bbb"] = {"status": "provisioning"}
        r = admin_client.get("/api/v1/jobs/worker/debug")
        assert r.status_code == 200
        assert r.json()["active_jobs"] == 2

    def test_debug_job_ids_capped_at_five(self, admin_client):
        """job_ids in response is capped at 5 entries for privacy."""
        import api.job_worker as jr
        for i in range(10):
            jr._active_jobs[f"job-{i:03d}"] = {"status": "running"}
        r = admin_client.get("/api/v1/jobs/worker/debug")
        assert len(r.json()["job_ids"]) <= 5

    def test_debug_requires_auth(self, monkeypatch):
        """GET /worker/debug without a valid token returns 404 (endpoint hidden)
        or 503 (token not configured). TESTING_MODE must be off for auth to run."""
        import api.auth
        monkeypatch.setattr(api.auth, "TESTING_MODE", False)
        monkeypatch.setenv("VL_INTERNAL_ADMIN_TOKEN", "secret-token")

        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from api.admin_routes import admin_jobs_router

        app = FastAPI()
        app.include_router(admin_jobs_router)
        client = TestClient(app, raise_server_exceptions=False)
        # No token header — expect 404 (endpoint hidden) or 503 (token not set)
        r = client.get("/api/v1/jobs/worker/debug")
        assert r.status_code in (404, 503)


# ===========================================================================
# 2. Cleanup instances endpoint
# ===========================================================================

class TestCleanupInstances:
    @pytest.mark.asyncio
    async def test_cleanup_destroys_vast_instances(self, admin_client):
        """cleanup-instances calls Vast.ai DELETE for each listed instance."""
        mock_broker = MagicMock()
        vast_cfg = SimpleNamespace(api_key="fake-vast-key")
        runpod_cfg = None
        mock_broker._get_provider_config = lambda p: vast_cfg if p == "vast_ai" else runpod_cfg

        import aiohttp
        from aiohttp import ClientSession

        # Simulate Vast.ai: list returns 2 instances; DELETE returns 200
        list_resp = AsyncMock()
        list_resp.status = 200
        list_resp.json = AsyncMock(return_value={
            "instances": [{"id": "11111"}, {"id": "22222"}]
        })

        delete_resp = AsyncMock()
        delete_resp.status = 200

        mock_session = AsyncMock()
        mock_session.get = MagicMock(return_value=AsyncMock(__aenter__=AsyncMock(return_value=list_resp), __aexit__=AsyncMock(return_value=False)))
        mock_session.delete = MagicMock(return_value=AsyncMock(__aenter__=AsyncMock(return_value=delete_resp), __aexit__=AsyncMock(return_value=False)))
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)

        with patch("api.job_worker._init_broker", return_value=mock_broker), \
             patch("api.admin_routes._init_broker", return_value=mock_broker), \
             patch("aiohttp.ClientSession", return_value=mock_session):
            r = admin_client.post("/api/v1/jobs/admin/cleanup-instances")

        assert r.status_code == 200
        data = r.json()
        assert data["ok"] is True

    def test_cleanup_no_broker_returns_error(self, admin_client):
        """cleanup-instances with no broker returns ok=False."""
        with patch("api.admin_routes._init_broker", return_value=None):
            r = admin_client.post("/api/v1/jobs/admin/cleanup-instances")
        assert r.status_code == 200
        assert r.json()["ok"] is False

    def test_cleanup_requires_auth(self, monkeypatch):
        """POST /admin/cleanup-instances without a valid token returns 404 or 503."""
        import api.auth
        monkeypatch.setattr(api.auth, "TESTING_MODE", False)
        monkeypatch.setenv("VL_INTERNAL_ADMIN_TOKEN", "secret-token")

        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from api.admin_routes import admin_jobs_router

        app = FastAPI()
        app.include_router(admin_jobs_router)
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post("/api/v1/jobs/admin/cleanup-instances")
        assert r.status_code in (404, 503)


# ===========================================================================
# 3. Terminate pods endpoint
# ===========================================================================

class TestTerminatePods:
    def test_terminate_pods_no_broker_returns_error(self, admin_client):
        """terminate-pods with no broker returns ok=False."""
        with patch("api.admin_routes._init_broker", return_value=None):
            r = admin_client.post(
                "/api/v1/jobs/admin/terminate-pods",
                json={"pod_ids": ["pod-abc"], "provider": "runpod"}
            )
        assert r.status_code == 200
        assert r.json()["ok"] is False

    def test_terminate_pods_no_runpod_key_returns_error(self, admin_client):
        """terminate-pods with unconfigured RunPod key returns error message."""
        mock_broker = MagicMock()
        mock_broker._get_provider_config = lambda p: None  # no config

        with patch("api.admin_routes._init_broker", return_value=mock_broker):
            r = admin_client.post(
                "/api/v1/jobs/admin/terminate-pods",
                json={"pod_ids": ["pod-xyz"], "provider": "runpod"}
            )
        assert r.status_code == 200
        assert r.json()["ok"] is False
        assert "key" in r.json()["error"].lower() or "configured" in r.json()["error"].lower()

    def test_terminate_pods_requires_auth(self, monkeypatch):
        """POST /admin/terminate-pods without a valid token returns 404 or 503."""
        import api.auth
        monkeypatch.setattr(api.auth, "TESTING_MODE", False)
        monkeypatch.setenv("VL_INTERNAL_ADMIN_TOKEN", "secret-token")

        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from api.admin_routes import admin_jobs_router

        app = FastAPI()
        app.include_router(admin_jobs_router)
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post(
            "/api/v1/jobs/admin/terminate-pods",
            json={"pod_ids": ["pod-abc"], "provider": "runpod"}
        )
        assert r.status_code in (404, 503)


# ===========================================================================
# 4. Cancel endpoint — non-running status with instance_id (billing leak fix)
# ===========================================================================

class TestCancelWithInstanceId:
    """Tests for the billing-leak fix: cancel must terminate instance even when
    prev_status is not 'running' or 'provisioning' (e.g. 'recovering')."""

    @pytest.fixture
    def _setup_jobs(self):
        from api import job_routes as jr
        jr._active_jobs.clear()
        jr._job_queue.clear()
        yield
        jr._active_jobs.clear()
        jr._job_queue.clear()

    def test_cancel_recovering_job_with_instance_terminates(self, jobs_client, _setup_jobs):
        """Cancelling a job in 'recovering' status that has an instance_id
        calls _terminate_and_settle — billing leak fix."""
        from api import job_routes as jr
        from api.auth import require_auth

        # Inject a job directly in "recovering" state with a real instance_id
        job_id = "test-recovering-job"
        jr._active_jobs[job_id] = {
            "job_id": job_id,
            "user_id": "test-user",
            "status": "recovering",
            "instance_id": "inst-recovering-123",
            "provider": "runpod",
            "gpu_type": "H100",
            "script_b64": "", "script_name": "train.py",
            "environment": {},
            "docker_image": "",
            "failover": True,
            "started_at": time.time(),
            "completed_at": None, "duration": None,
            "error": None, "checkpoint_step": None,
        }

        mock_broker = MagicMock()
        mock_broker._hard_fence_runpod = AsyncMock()

        with patch("api.job_routes._init_broker", return_value=mock_broker), \
             patch("api.job_routes._settle_in_db"):
            r = jobs_client.post(f"/api/v1/jobs/{job_id}/cancel")

        assert r.status_code == 200
        assert r.json()["status"] == "cancelled"
        # Termination must have been attempted
        mock_broker._hard_fence_runpod.assert_awaited_once()

    def test_cancel_recovering_job_no_instance_does_not_terminate(self, jobs_client, _setup_jobs):
        """Cancelling a 'recovering' job with no instance_id skips termination (nothing to fence)."""
        from api import job_routes as jr

        job_id = "test-recovering-no-inst"
        jr._active_jobs[job_id] = {
            "job_id": job_id,
            "user_id": "test-user",
            "status": "recovering",
            "instance_id": "",
            "provider": "runpod",
            "gpu_type": "H100",
            "script_b64": "", "script_name": "train.py",
            "environment": {},
            "docker_image": "",
            "failover": True,
            "started_at": time.time(),
            "completed_at": None, "duration": None,
            "error": None, "checkpoint_step": None,
        }

        mock_broker = MagicMock()
        mock_broker._hard_fence_runpod = AsyncMock()

        with patch("api.job_routes._init_broker", return_value=mock_broker), \
             patch("api.job_routes._settle_in_db"):
            r = jobs_client.post(f"/api/v1/jobs/{job_id}/cancel")

        assert r.status_code == 200
        assert r.json()["status"] == "cancelled"
        # No instance — no termination
        mock_broker._hard_fence_runpod.assert_not_awaited()

    def test_cancel_migrated_job_with_instance_terminates(self, jobs_client, _setup_jobs):
        """Cancelling a job in 'migrated' status that has an instance_id terminates it."""
        from api import job_routes as jr

        job_id = "test-migrated-job"
        jr._active_jobs[job_id] = {
            "job_id": job_id,
            "user_id": "test-user",
            "status": "migrated",
            "instance_id": "inst-vast-789",
            "provider": "vast_ai",
            "gpu_type": "A100_40",
            "script_b64": "", "script_name": "train.py",
            "environment": {},
            "docker_image": "",
            "failover": True,
            "started_at": time.time(),
            "completed_at": None, "duration": None,
            "error": None, "checkpoint_step": None,
        }

        mock_broker = MagicMock()
        mock_broker._hard_fence_vast_ai = AsyncMock()

        with patch("api.job_routes._init_broker", return_value=mock_broker), \
             patch("api.job_routes._settle_in_db"):
            r = jobs_client.post(f"/api/v1/jobs/{job_id}/cancel")

        assert r.status_code == 200
        assert r.json()["status"] == "cancelled"
        mock_broker._hard_fence_vast_ai.assert_awaited_once()

    def test_cancel_terminate_failure_still_cancels(self, jobs_client, _setup_jobs):
        """Termination failure during cancel does not prevent job from being marked cancelled."""
        from api import job_routes as jr

        job_id = "test-fence-failure"
        jr._active_jobs[job_id] = {
            "job_id": job_id,
            "user_id": "test-user",
            "status": "recovering",
            "instance_id": "inst-fail-456",
            "provider": "lambda_labs",
            "gpu_type": "H100",
            "script_b64": "", "script_name": "train.py",
            "environment": {},
            "docker_image": "",
            "failover": True,
            "started_at": time.time(),
            "completed_at": None, "duration": None,
            "error": None, "checkpoint_step": None,
        }

        mock_broker = MagicMock()
        mock_broker._hard_fence_lambda = AsyncMock(side_effect=RuntimeError("Lambda API timeout"))

        with patch("api.job_routes._init_broker", return_value=mock_broker), \
             patch("api.job_routes._settle_in_db"):
            r = jobs_client.post(f"/api/v1/jobs/{job_id}/cancel")

        # Job must be cancelled even when fence fails
        assert r.status_code == 200
        assert r.json()["status"] == "cancelled"


# ===========================================================================
# 5. Provisioning orphan cleanup on startup (billing leak fix)
# ===========================================================================

class TestProvisioningOrphanCleanup:
    """Tests for the P0 billing leak fix in job_worker._background_worker:
    provisioning rows with a real instance_id must be terminated before
    being marked failed on Railway restart."""

    @pytest.mark.asyncio
    async def test_provisioning_orphan_with_instance_is_terminated(self):
        """An orphaned provisioning row with instance_id triggers _terminate_and_settle."""
        from api import job_worker as jr

        # Inject a provisioning row with an instance_id into the mock DB
        fake_prov = {
            "run_id": "run-prov-001",
            "job_id": "job-prov-001",
            "account_id": "user-x",
            "instance_id": "inst-orphan-111",
            "provider": "vast_ai",
        }

        mock_db_result = MagicMock()
        mock_db_result.data = [fake_prov]

        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.eq.return_value.execute.return_value = mock_db_result
        mock_db.table.return_value.update.return_value.eq.return_value.execute.return_value = MagicMock(data=[])

        # Also mock the "running" rows query to return empty
        running_result = MagicMock()
        running_result.data = []

        # _db_call passes through the lambda — patch it to execute directly
        terminate_called = []

        async def _fake_terminate(broker, job):
            terminate_called.append(job["instance_id"])

        mock_broker = MagicMock()

        with patch("api.job_worker.get_db", return_value=mock_db), \
             patch("api.job_worker._db_call", side_effect=lambda fn, label="": fn()), \
             patch("api.job_worker._init_broker", return_value=mock_broker), \
             patch("api.job_worker._terminate_and_settle", side_effect=_fake_terminate):

            # Simulate just the provisioning cleanup block
            db = mock_db
            _prov_rows = db.table("job_runs").select(
                "run_id, job_id, account_id, instance_id, provider"
            ).eq("status", "provisioning").execute()

            for _prow in (_prov_rows.data or []):
                _prov_inst = _prow.get("instance_id")
                if _prov_inst and _prov_inst != "pending":
                    broker = _init_broker = mock_broker
                    stub = {
                        "job_id": _prow.get("job_id", ""),
                        "instance_id": _prov_inst,
                        "provider": _prow.get("provider", ""),
                    }
                    await _fake_terminate(broker, stub)

        assert "inst-orphan-111" in terminate_called

    @pytest.mark.asyncio
    async def test_provisioning_row_without_instance_is_not_terminated(self):
        """Provisioning rows with no instance_id (or 'pending') skip termination."""
        terminate_called = []

        async def _fake_terminate(broker, job):
            terminate_called.append(job.get("instance_id"))

        prov_rows = [
            {"job_id": "job-no-inst", "instance_id": "", "provider": "aws"},
            {"job_id": "job-pending", "instance_id": "pending", "provider": "vast_ai"},
            {"job_id": "job-none", "instance_id": None, "provider": "runpod"},
        ]

        for _prow in prov_rows:
            _prov_inst = _prow.get("instance_id")
            if _prov_inst and _prov_inst != "pending":
                await _fake_terminate(None, _prow)

        assert terminate_called == []


# ===========================================================================
# 6. Hard fence timeout raises (P1 billing leak fix)
# ===========================================================================

class TestHardFenceTimeoutRaises:
    """Tests that hard_fence in Vast.ai and Lambda providers raises on 60s confirm timeout,
    allowing the retry loop in _hard_fence_and_confirm to retry."""

    @pytest.mark.asyncio
    async def test_vast_ai_fence_raises_on_confirm_timeout(self):
        """Vast.ai hard_fence raises RuntimeError when confirmation polling times out."""
        import aiohttp
        from agents.broker.providers import vast_ai as vast_provider

        broker = MagicMock()
        vast_cfg = SimpleNamespace(api_key="test-key")
        broker._get_provider_config = lambda p: vast_cfg
        broker._get_managed_credentials = AsyncMock(return_value=None)

        # DELETE returns 200; GET always returns 200 (never 404) -> timeout
        delete_resp = AsyncMock()
        delete_resp.status = 200

        check_resp = AsyncMock()
        check_resp.status = 200
        check_resp.json = AsyncMock(return_value={"actual_status": "running"})

        mock_session = AsyncMock()
        mock_session.delete = MagicMock(return_value=AsyncMock(
            __aenter__=AsyncMock(return_value=delete_resp),
            __aexit__=AsyncMock(return_value=False)
        ))
        mock_session.get = MagicMock(return_value=AsyncMock(
            __aenter__=AsyncMock(return_value=check_resp),
            __aexit__=AsyncMock(return_value=False)
        ))
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)

        with patch("aiohttp.ClientSession", return_value=mock_session), \
             patch("asyncio.sleep", new=AsyncMock()):
            with pytest.raises((RuntimeError, Exception)):
                await vast_provider.hard_fence(broker, "inst-timeout-999")

    @pytest.mark.asyncio
    async def test_lambda_fence_raises_on_confirm_timeout(self):
        """Lambda Labs hard_fence raises RuntimeError when confirmation polling times out."""
        from agents.broker.providers import lambda_labs as ll_provider

        broker = MagicMock()
        ll_cfg = SimpleNamespace(api_key="ll-test-key")
        broker._get_provider_config = lambda p: ll_cfg
        broker._get_managed_credentials = AsyncMock(return_value=None)

        # POST terminate returns 200; GET always returns "active" (not terminated)
        terminate_resp = AsyncMock()
        terminate_resp.status = 200
        terminate_resp.json = AsyncMock(return_value={"data": {"terminated_instances": [{"id": "inst-ll-999"}]}})

        check_resp = AsyncMock()
        check_resp.status = 200
        check_resp.json = AsyncMock(return_value={"data": {"status": "active"}})

        mock_session = AsyncMock()
        mock_session.post = MagicMock(return_value=AsyncMock(
            __aenter__=AsyncMock(return_value=terminate_resp),
            __aexit__=AsyncMock(return_value=False)
        ))
        mock_session.get = MagicMock(return_value=AsyncMock(
            __aenter__=AsyncMock(return_value=check_resp),
            __aexit__=AsyncMock(return_value=False)
        ))
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)

        with patch("aiohttp.ClientSession", return_value=mock_session), \
             patch("asyncio.sleep", new=AsyncMock()):
            with pytest.raises((RuntimeError, Exception)):
                await ll_provider.hard_fence(broker, "inst-ll-timeout-999")
