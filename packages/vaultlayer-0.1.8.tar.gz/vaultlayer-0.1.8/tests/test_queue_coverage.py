"""
Coverage tests for shared/queue.py — AgentQueue and make_event().
Uses mocked Redis clients to avoid network dependencies.
"""
import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from shared.models import AgentEvent, EventType
from shared.queue import AgentQueue, CHANNELS, make_event


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_queue(url: str = "rediss://localhost:6379") -> AgentQueue:
    return AgentQueue(url)


def _make_mock_redis():
    r = AsyncMock()
    r.publish = AsyncMock(return_value=1)
    r.lpush = AsyncMock(return_value=1)
    r.ltrim = AsyncMock(return_value=True)
    r.lrange = AsyncMock(return_value=[])
    r.setex = AsyncMock(return_value=True)
    r.get = AsyncMock(return_value=None)
    r.ping = AsyncMock(return_value=True)
    r.hget = AsyncMock(return_value=None)
    r.hset = AsyncMock(return_value=1)
    r.expire = AsyncMock(return_value=True)
    r.xadd = AsyncMock(return_value="1234-0")
    r.xgroup_create = AsyncMock(return_value=True)
    r.aclose = AsyncMock()
    return r


def _attach_redis(queue: AgentQueue) -> AsyncMock:
    r = _make_mock_redis()
    queue._client = r
    return r


def _make_event(event_type=EventType.PRICE_UPDATE, job_id="job-1") -> AgentEvent:
    return make_event(event_type=event_type, source_agent="test", job_id=job_id)


# ── make_event() ──────────────────────────────────────────────────────────────

class TestMakeEvent:
    def test_returns_agent_event(self):
        ev = make_event(EventType.PRICE_UPDATE, "pricing_agent")
        assert isinstance(ev, AgentEvent)

    def test_sets_event_type(self):
        ev = make_event(EventType.ARBITRAGE_OPPORTUNITY, "pricing_agent")
        assert ev.event_type == EventType.ARBITRAGE_OPPORTUNITY

    def test_sets_source_agent(self):
        ev = make_event(EventType.PRICE_UPDATE, "my_agent")
        assert ev.source_agent == "my_agent"

    def test_sets_job_id(self):
        ev = make_event(EventType.PRICE_UPDATE, "agent", job_id="job-42")
        assert ev.job_id == "job-42"

    def test_sets_payload(self):
        ev = make_event(EventType.PRICE_UPDATE, "agent", payload={"key": "value"})
        assert ev.payload == {"key": "value"}

    def test_defaults_empty_payload(self):
        ev = make_event(EventType.PRICE_UPDATE, "agent")
        assert ev.payload == {}

    def test_default_priority(self):
        ev = make_event(EventType.PRICE_UPDATE, "agent")
        assert ev.priority == 5

    def test_custom_priority(self):
        ev = make_event(EventType.PRICE_UPDATE, "agent", priority=1)
        assert ev.priority == 1


# ── CHANNELS dict ─────────────────────────────────────────────────────────────

class TestChannelsDict:
    def test_required_channels_present(self):
        required = {"pricing", "watchdog", "broker", "vault", "finops",
                    "orchestration", "namespace", "escalate"}
        assert required.issubset(set(CHANNELS.keys()))

    def test_channel_values_are_strings(self):
        for k, v in CHANNELS.items():
            assert isinstance(v, str), f"Channel {k!r} value must be str"

    def test_channel_values_prefixed(self):
        for k, v in CHANNELS.items():
            assert v.startswith("vaultlayer:"), f"Channel {k!r} value should start with vaultlayer:"


# ── AgentQueue: publish() ─────────────────────────────────────────────────────

class TestAgentQueuePublish:
    @pytest.mark.asyncio
    async def test_publish_calls_redis_publish(self):
        q = _make_queue()
        r = _attach_redis(q)
        ev = _make_event()

        await q.publish("pricing", ev)
        r.publish.assert_called_once()
        args = r.publish.call_args[0]
        assert args[0] == CHANNELS["pricing"]

    @pytest.mark.asyncio
    async def test_publish_also_pushes_to_history_list(self):
        q = _make_queue()
        r = _attach_redis(q)
        ev = _make_event()

        await q.publish("pricing", ev)
        r.lpush.assert_called_once()
        r.ltrim.assert_called_once()

    @pytest.mark.asyncio
    async def test_publish_unknown_channel_raises(self):
        q = _make_queue()
        _attach_redis(q)
        ev = _make_event()

        with pytest.raises(ValueError, match="Unknown channel"):
            await q.publish("nonexistent", ev)

    @pytest.mark.asyncio
    async def test_publish_returns_subscriber_count(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.publish = AsyncMock(return_value=3)
        ev = _make_event()

        count = await q.publish("pricing", ev)
        assert count == 3

    @pytest.mark.asyncio
    async def test_publish_returns_zero_on_redis_error(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.publish = AsyncMock(side_effect=Exception("Redis down"))
        ev = _make_event()

        count = await q.publish("pricing", ev)
        assert count == 0

    @pytest.mark.asyncio
    async def test_publish_sets_degraded_on_error(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.publish = AsyncMock(side_effect=Exception("Redis down"))
        ev = _make_event()

        await q.publish("pricing", ev)
        assert q._degraded is True

    @pytest.mark.asyncio
    async def test_publish_all_valid_channels(self):
        q = _make_queue()
        r = _attach_redis(q)

        for channel in CHANNELS.keys():
            ev = _make_event()
            await q.publish(channel, ev)

        assert r.publish.call_count == len(CHANNELS)


# ── AgentQueue: publish_critical() ───────────────────────────────────────────

class TestAgentQueuePublishCritical:
    @pytest.mark.asyncio
    async def test_publish_critical_calls_xadd(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.xgroup_create = AsyncMock(return_value=True)
        ev = _make_event(EventType.MIGRATION_STARTED)

        result = await q.publish_critical("broker", ev)
        r.xadd.assert_called_once()
        assert isinstance(result, str)

    @pytest.mark.asyncio
    async def test_publish_critical_stream_key_per_channel(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.xgroup_create = AsyncMock(return_value=True)
        ev = _make_event(EventType.MIGRATION_STARTED)

        await q.publish_critical("broker", ev)
        call_args = r.xadd.call_args[0]
        assert "broker" in call_args[0]

    @pytest.mark.asyncio
    async def test_publish_critical_busygroup_ignored(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.xgroup_create = AsyncMock(side_effect=Exception("BUSYGROUP already exists"))
        ev = _make_event(EventType.MIGRATION_STARTED)

        # Should not raise
        result = await q.publish_critical("broker", ev)
        assert result == "1234-0"


# ── AgentQueue: healthcheck() ─────────────────────────────────────────────────

class TestAgentQueueHealthcheck:
    @pytest.mark.asyncio
    async def test_healthcheck_returns_true_on_ping(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.ping = AsyncMock(return_value=True)

        result = await q.healthcheck()
        assert result is True

    @pytest.mark.asyncio
    async def test_healthcheck_returns_false_on_exception(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.ping = AsyncMock(side_effect=Exception("connection refused"))

        result = await q.healthcheck()
        assert result is False


# ── AgentQueue: job state ─────────────────────────────────────────────────────

class TestAgentQueueJobState:
    @pytest.mark.asyncio
    async def test_set_job_state_calls_setex(self):
        q = _make_queue()
        r = _attach_redis(q)

        await q.set_job_state("job-1", {"status": "running"})
        r.setex.assert_called_once()
        call_args = r.setex.call_args[0]
        assert "job-1" in call_args[0]

    @pytest.mark.asyncio
    async def test_get_job_state_returns_none_when_missing(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.get = AsyncMock(return_value=None)

        result = await q.get_job_state("job-1")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_job_state_deserializes_json(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.get = AsyncMock(return_value=json.dumps({"status": "running", "step": 100}))

        result = await q.get_job_state("job-1")
        assert result == {"status": "running", "step": 100}


# ── AgentQueue: price cache ───────────────────────────────────────────────────

class TestAgentQueuePriceCache:
    @pytest.mark.asyncio
    async def test_set_price_cache_calls_setex(self):
        q = _make_queue()
        r = _attach_redis(q)

        await q.set_price_cache([{"gpu": "H100", "price": 3.90}])
        r.setex.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_price_cache_returns_none_when_empty(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.get = AsyncMock(return_value=None)

        result = await q.get_price_cache()
        assert result is None

    @pytest.mark.asyncio
    async def test_get_price_cache_deserializes(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.get = AsyncMock(return_value=json.dumps([{"gpu": "H100", "price": 3.90}]))

        result = await q.get_price_cache()
        assert result == [{"gpu": "H100", "price": 3.90}]


# ── AgentQueue: get_history() ─────────────────────────────────────────────────

class TestAgentQueueGetHistory:
    @pytest.mark.asyncio
    async def test_get_history_empty_for_unknown_channel(self):
        q = _make_queue()
        _attach_redis(q)

        result = await q.get_history("nonexistent")
        assert result == []

    @pytest.mark.asyncio
    async def test_get_history_returns_events(self):
        q = _make_queue()
        r = _attach_redis(q)
        ev = _make_event()
        r.lrange = AsyncMock(return_value=[ev.model_dump_json()])

        result = await q.get_history("pricing")
        assert len(result) == 1
        assert isinstance(result[0], AgentEvent)

    @pytest.mark.asyncio
    async def test_get_history_skips_malformed_json(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.lrange = AsyncMock(return_value=["not-valid-json"])

        result = await q.get_history("pricing")
        assert result == []


# ── AgentQueue: hash ops ──────────────────────────────────────────────────────

class TestAgentQueueHashOps:
    @pytest.mark.asyncio
    async def test_hget_returns_none_when_missing(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.hget = AsyncMock(return_value=None)

        result = await q.hget("some-key", "field")
        assert result is None

    @pytest.mark.asyncio
    async def test_hget_returns_value_when_present(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.hget = AsyncMock(return_value="my-value")

        result = await q.hget("some-key", "field")
        assert result == "my-value"

    @pytest.mark.asyncio
    async def test_hset_returns_count(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.hset = AsyncMock(return_value=2)

        result = await q.hset("some-key", {"a": "1", "b": "2"})
        assert result == 2

    @pytest.mark.asyncio
    async def test_expire_returns_bool(self):
        q = _make_queue()
        r = _attach_redis(q)
        r.expire = AsyncMock(return_value=1)

        result = await q.expire("some-key", 3600)
        assert result is True


# ── AgentQueue: connect TLS warning ──────────────────────────────────────────

class TestAgentQueueConnect:
    @pytest.mark.asyncio
    async def test_connect_warns_on_plaintext_non_localhost(self):
        q = AgentQueue("redis://remote.host:6379")
        mock_redis = _make_mock_redis()

        with patch("redis.asyncio.from_url", AsyncMock(return_value=mock_redis)), \
             patch("warnings.warn") as mock_warn:
            await q.connect()
            mock_warn.assert_called_once()
            assert "TLS" in str(mock_warn.call_args)

    @pytest.mark.asyncio
    async def test_connect_no_warn_on_localhost(self):
        q = AgentQueue("redis://localhost:6379")
        mock_redis = _make_mock_redis()

        with patch("redis.asyncio.from_url", AsyncMock(return_value=mock_redis)), \
             patch("warnings.warn") as mock_warn:
            await q.connect()
            mock_warn.assert_not_called()

    @pytest.mark.asyncio
    async def test_connect_no_warn_on_tls(self):
        q = AgentQueue("rediss://upstash.io:6380")
        mock_redis = _make_mock_redis()

        with patch("redis.asyncio.from_url", AsyncMock(return_value=mock_redis)), \
             patch("warnings.warn") as mock_warn:
            await q.connect()
            mock_warn.assert_not_called()

    @pytest.mark.asyncio
    async def test_disconnect_calls_aclose(self):
        q = _make_queue()
        r = _attach_redis(q)

        await q.disconnect()
        r.aclose.assert_called_once()

    @pytest.mark.asyncio
    async def test_disconnect_no_op_when_not_connected(self):
        q = AgentQueue("rediss://host:6380")
        # _client is None — should not crash
        await q.disconnect()


# ── AgentQueue: stream key helpers ───────────────────────────────────────────

class TestAgentQueueStreamKey:
    def test_stream_key_with_channel(self):
        q = _make_queue()
        key = q._stream_key("broker")
        assert "broker" in key
        assert key.startswith("vaultlayer:critical:")

    def test_stream_key_without_channel_returns_legacy(self):
        q = _make_queue()
        key = q._stream_key()
        assert key == q.CRITICAL_STREAM_KEY
