"""
Coverage tests for shared/storage_billing.py
Pure math functions + mocked Stripe / R2 / DB paths.
"""
import pytest
from unittest.mock import MagicMock, patch, AsyncMock


# ── get_current_storage_rate() ────────────────────────────────────────────────

class TestGetCurrentStorageRate:
    def test_default_rate(self):
        from shared.storage_billing import get_current_storage_rate, R2_BASE_COST_PER_GB_MONTH, STORAGE_MARKUP_MULTIPLIER
        rate = get_current_storage_rate()
        assert rate == round(R2_BASE_COST_PER_GB_MONTH * STORAGE_MARKUP_MULTIPLIER, 4)

    def test_custom_base_rate(self):
        from shared.storage_billing import get_current_storage_rate, STORAGE_MARKUP_MULTIPLIER
        rate = get_current_storage_rate(raw_r2_cost=0.010)
        assert rate == round(0.010 * STORAGE_MARKUP_MULTIPLIER, 4)

    def test_zero_base_rate(self):
        from shared.storage_billing import get_current_storage_rate
        assert get_current_storage_rate(raw_r2_cost=0.0) == 0.0

    def test_high_base_rate(self):
        from shared.storage_billing import get_current_storage_rate
        rate = get_current_storage_rate(raw_r2_cost=1.0)
        assert rate > 1.0  # markup applied

    def test_returns_float(self):
        from shared.storage_billing import get_current_storage_rate
        assert isinstance(get_current_storage_rate(), float)

    def test_custom_markup_multiplier(self):
        from shared import storage_billing
        with patch.object(storage_billing, "STORAGE_MARKUP_MULTIPLIER", 2.0):
            rate = storage_billing.get_current_storage_rate(raw_r2_cost=0.015)
        assert rate == round(0.015 * 2.0, 4)

    def test_result_rounded_to_4_dp(self):
        from shared.storage_billing import get_current_storage_rate
        rate = get_current_storage_rate()
        # Rounding to 4dp means no more than 4 decimal digits of precision
        assert rate == round(rate, 4)


# ── get_daily_storage_cost() ──────────────────────────────────────────────────

class TestGetDailyStorageCost:
    def test_zero_gb(self):
        from shared.storage_billing import get_daily_storage_cost
        assert get_daily_storage_cost(0) == 0.0

    def test_one_gb(self):
        from shared.storage_billing import get_daily_storage_cost, get_current_storage_rate
        cost = get_daily_storage_cost(1.0)
        expected = round(get_current_storage_rate() / 30.0, 6)
        assert cost == expected

    def test_100_gb_proportional(self):
        from shared.storage_billing import get_daily_storage_cost
        cost_1 = get_daily_storage_cost(1.0)
        cost_100 = get_daily_storage_cost(100.0)
        assert abs(cost_100 - 100 * cost_1) < 1e-9

    def test_returns_float(self):
        from shared.storage_billing import get_daily_storage_cost
        assert isinstance(get_daily_storage_cost(10.0), float)

    def test_rounded_to_6_dp(self):
        from shared.storage_billing import get_daily_storage_cost
        cost = get_daily_storage_cost(7.5)
        assert cost == round(cost, 6)

    def test_large_storage(self):
        from shared.storage_billing import get_daily_storage_cost
        cost = get_daily_storage_cost(10_000.0)
        assert cost > 0


# ── report_storage_to_stripe() ────────────────────────────────────────────────

class TestReportStorageToStripe:
    def test_no_stripe_key_returns_none(self):
        from shared import storage_billing
        with patch.object(storage_billing, "STRIPE_SECRET_KEY", ""):
            result = storage_billing.report_storage_to_stripe("cus_test", 5.0)
        assert result is None

    def test_stripe_success_returns_event_id(self):
        from shared import storage_billing
        mock_stripe = MagicMock()
        mock_event = {"identifier": "evt_abc123"}
        mock_stripe.billing.MeterEvent.create.return_value = mock_event

        with patch.object(storage_billing, "STRIPE_SECRET_KEY", "sk_test_xxx"), \
             patch.dict("sys.modules", {"stripe": mock_stripe}):
            result = storage_billing.report_storage_to_stripe("cus_test", 5.0)
        assert result == "evt_abc123"

    def test_stripe_fallback_to_id_key(self):
        """If 'identifier' is absent, falls back to 'id'."""
        from shared import storage_billing
        mock_stripe = MagicMock()
        mock_event = MagicMock()
        mock_event.get = lambda k, d=None: ("evt_fallback" if k == "id" else d)
        mock_stripe.billing.MeterEvent.create.return_value = mock_event

        with patch.object(storage_billing, "STRIPE_SECRET_KEY", "sk_test_xxx"), \
             patch.dict("sys.modules", {"stripe": mock_stripe}):
            result = storage_billing.report_storage_to_stripe("cus_test", 5.0)
        assert result == "evt_fallback"

    def test_stripe_exception_returns_none(self):
        from shared import storage_billing
        mock_stripe = MagicMock()
        mock_stripe.billing.MeterEvent.create.side_effect = Exception("Stripe API error")

        with patch.object(storage_billing, "STRIPE_SECRET_KEY", "sk_test_xxx"), \
             patch.dict("sys.modules", {"stripe": mock_stripe}):
            result = storage_billing.report_storage_to_stripe("cus_test", 5.0)
        assert result is None

    def test_rounds_sub_gb_up_to_1(self):
        """Stripe meter value must be >= 1 (integer minimum)."""
        from shared import storage_billing
        captured = {}
        mock_stripe = MagicMock()
        def fake_create(event_name, payload, timestamp):
            captured["value"] = payload["value"]
            return {"identifier": "evt_ok"}
        mock_stripe.billing.MeterEvent.create = fake_create

        with patch.object(storage_billing, "STRIPE_SECRET_KEY", "sk_test_xxx"), \
             patch.dict("sys.modules", {"stripe": mock_stripe}):
            storage_billing.report_storage_to_stripe("cus_test", 0.001)
        assert captured["value"] == "1"

    def test_large_gb_passed_correctly(self):
        from shared import storage_billing
        captured = {}
        mock_stripe = MagicMock()
        def fake_create(event_name, payload, timestamp):
            captured["value"] = payload["value"]
            return {"identifier": "evt_ok"}
        mock_stripe.billing.MeterEvent.create = fake_create

        with patch.object(storage_billing, "STRIPE_SECRET_KEY", "sk_test_xxx"), \
             patch.dict("sys.modules", {"stripe": mock_stripe}):
            storage_billing.report_storage_to_stripe("cus_test", 500.9)
        assert captured["value"] == "500"


# ── _measure_r2_usage_per_user() ──────────────────────────────────────────────

def _make_mock_api_db(supabase_url="https://fake.supabase.co", mock_db=None):
    """Return a mock api.db module for sys.modules patching."""
    m = MagicMock()
    m.SUPABASE_URL = supabase_url
    m.get_db = MagicMock(return_value=mock_db or MagicMock())
    return m


class TestMeasureR2UsagePerUser:
    def test_no_boto3_returns_empty(self):
        from shared import storage_billing
        config = MagicMock()
        with patch.dict("sys.modules", {"boto3": None}):
            result = storage_billing._measure_r2_usage_per_user(config)
        assert result == []

    def test_boto3_client_exception_returns_empty(self):
        from shared import storage_billing
        config = MagicMock()
        mock_boto3 = MagicMock()
        mock_boto3.client.side_effect = Exception("auth error")
        with patch.dict("sys.modules", {"boto3": mock_boto3,
                                         "api.db": _make_mock_api_db()}):
            result = storage_billing._measure_r2_usage_per_user(config)
        assert result == []

    def test_no_supabase_url_returns_empty(self):
        from shared import storage_billing
        config = MagicMock()
        mock_boto3 = MagicMock()
        mock_s3 = MagicMock()
        mock_boto3.client.return_value = mock_s3

        with patch.dict("sys.modules", {"boto3": mock_boto3,
                                         "api.db": _make_mock_api_db(supabase_url="")}):
            result = storage_billing._measure_r2_usage_per_user(config)
        assert result == []

    def test_empty_dataset_rows_returns_empty_list(self):
        from shared import storage_billing
        config = MagicMock()
        mock_boto3 = MagicMock()
        mock_s3 = MagicMock()
        mock_boto3.client.return_value = mock_s3

        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.is_.return_value.execute.return_value.data = []

        with patch.dict("sys.modules", {"boto3": mock_boto3,
                                         "api.db": _make_mock_api_db(mock_db=mock_db)}):
            result = storage_billing._measure_r2_usage_per_user(config)
        assert result == []

    def test_aggregates_bytes_per_user(self):
        from shared import storage_billing
        config = MagicMock()
        config.cloudflare.r2_bucket = "test-bucket"

        mock_boto3 = MagicMock()
        mock_s3 = MagicMock()
        mock_boto3.client.return_value = mock_s3

        mock_page = {"Contents": [{"Size": 500_000_000}, {"Size": 500_000_000}]}
        mock_paginator = MagicMock()
        mock_paginator.paginate.return_value = [mock_page]
        mock_s3.get_paginator.return_value = mock_paginator

        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.is_.return_value.execute.return_value.data = [
            {"user_id": "user-1", "dataset_id": "ds-1", "r2_prefix": "datasets/ds-1/"}
        ]

        with patch.dict("sys.modules", {"boto3": mock_boto3,
                                         "api.db": _make_mock_api_db(mock_db=mock_db)}):
            result = storage_billing._measure_r2_usage_per_user(config)

        assert len(result) == 1
        assert result[0]["user_id"] == "user-1"
        assert result[0]["gb_stored"] == pytest.approx(1.0, rel=0.01)


# ── cron_record_daily_storage() ───────────────────────────────────────────────

class TestCronRecordDailyStorage:
    def _mock_db(self, ledger_id="ledger-1", stripe_customer_id=None):
        db = MagicMock()
        insert_result = MagicMock()
        insert_result.data = [{"id": ledger_id}]
        db.table.return_value.insert.return_value.execute.return_value = insert_result

        user_row = {"stripe_customer_id": stripe_customer_id} if stripe_customer_id else None
        db.table.return_value.select.return_value.eq.return_value.single.return_value.execute.return_value.data = user_row

        update_result = MagicMock()
        db.table.return_value.update.return_value.eq.return_value.execute.return_value = update_result
        return db

    def _api_db_mod(self, supabase_url="https://fake.supabase.co", db=None):
        return _make_mock_api_db(supabase_url=supabase_url, mock_db=db or MagicMock())

    def test_no_supabase_url_returns_error_dict(self):
        from shared import storage_billing
        with patch.dict("sys.modules", {"api.db": self._api_db_mod(supabase_url="")}):
            result = storage_billing.cron_record_daily_storage(config=MagicMock())
        assert "error" in result

    def test_no_datasets_returns_zero_billed(self):
        from shared import storage_billing
        with patch.dict("sys.modules", {"api.db": self._api_db_mod()}), \
             patch.object(storage_billing, "_measure_r2_usage_per_user", return_value=[]):
            result = storage_billing.cron_record_daily_storage(config=MagicMock())
        assert result["users_billed"] == 0
        assert result["total_gb"] == 0.0
        assert "rate" in result

    def test_bills_single_user(self):
        from shared import storage_billing
        storage_data = [
            {"user_id": "u-1", "gb_stored": 10.0, "bucket_path": "datasets/user:u-1/"}
        ]
        db = self._mock_db()
        with patch.dict("sys.modules", {"api.db": self._api_db_mod(db=db)}), \
             patch.object(storage_billing, "_measure_r2_usage_per_user", return_value=storage_data):
            result = storage_billing.cron_record_daily_storage(config=MagicMock())
        assert result["users_billed"] == 1
        assert result["total_gb"] == 10.0

    def test_accumulates_multiple_users(self):
        from shared import storage_billing
        storage_data = [
            {"user_id": "u-1", "gb_stored": 5.0, "bucket_path": "datasets/user:u-1/"},
            {"user_id": "u-2", "gb_stored": 3.0, "bucket_path": "datasets/user:u-2/"},
        ]
        db = self._mock_db()
        with patch.dict("sys.modules", {"api.db": self._api_db_mod(db=db)}), \
             patch.object(storage_billing, "_measure_r2_usage_per_user", return_value=storage_data):
            result = storage_billing.cron_record_daily_storage(config=MagicMock())
        assert result["users_billed"] == 2
        assert result["total_gb"] == 8.0

    def test_reports_stripe_when_customer_id_present(self):
        from shared import storage_billing
        storage_data = [
            {"user_id": "u-1", "gb_stored": 20.0, "bucket_path": "datasets/user:u-1/"}
        ]
        db = self._mock_db(stripe_customer_id="cus_abc")
        with patch.dict("sys.modules", {"api.db": self._api_db_mod(db=db)}), \
             patch.object(storage_billing, "_measure_r2_usage_per_user", return_value=storage_data), \
             patch.object(storage_billing, "report_storage_to_stripe", return_value="evt_test") as mock_report:
            result = storage_billing.cron_record_daily_storage(config=MagicMock())
        mock_report.assert_called_once_with("cus_abc", 20.0)
        assert result["stripe_reported"] == 1

    def test_skips_stripe_when_no_customer_id(self):
        from shared import storage_billing
        storage_data = [
            {"user_id": "u-1", "gb_stored": 20.0, "bucket_path": "datasets/user:u-1/"}
        ]
        db = self._mock_db(stripe_customer_id=None)
        with patch.dict("sys.modules", {"api.db": self._api_db_mod(db=db)}), \
             patch.object(storage_billing, "_measure_r2_usage_per_user", return_value=storage_data), \
             patch.object(storage_billing, "report_storage_to_stripe") as mock_report:
            result = storage_billing.cron_record_daily_storage(config=MagicMock())
        mock_report.assert_not_called()
        assert result["stripe_reported"] == 0

    def test_db_insert_failure_skips_user(self):
        from shared import storage_billing
        storage_data = [
            {"user_id": "u-1", "gb_stored": 5.0, "bucket_path": "datasets/user:u-1/"}
        ]
        db = MagicMock()
        db.table.return_value.insert.return_value.execute.side_effect = Exception("DB error")
        with patch.dict("sys.modules", {"api.db": self._api_db_mod(db=db)}), \
             patch.object(storage_billing, "_measure_r2_usage_per_user", return_value=storage_data):
            result = storage_billing.cron_record_daily_storage(config=MagicMock())
        assert result["users_billed"] == 0

    def test_loads_config_when_none(self):
        from shared import storage_billing
        mock_config = MagicMock()
        with patch.dict("sys.modules", {"api.db": self._api_db_mod()}), \
             patch.object(storage_billing, "_measure_r2_usage_per_user", return_value=[]), \
             patch("shared.config.load_config", return_value=mock_config) as mock_load:
            storage_billing.cron_record_daily_storage(config=None)
        mock_load.assert_called_once()

    def test_summary_contains_expected_keys(self):
        from shared import storage_billing
        with patch.dict("sys.modules", {"api.db": self._api_db_mod()}), \
             patch.object(storage_billing, "_measure_r2_usage_per_user", return_value=[]):
            result = storage_billing.cron_record_daily_storage(config=MagicMock())
        for key in ("users_billed", "total_gb", "rate"):
            assert key in result


# ── Module-level constants ─────────────────────────────────────────────────────

class TestModuleConstants:
    def test_r2_base_cost_is_positive(self):
        from shared.storage_billing import R2_BASE_COST_PER_GB_MONTH
        assert R2_BASE_COST_PER_GB_MONTH > 0

    def test_markup_multiplier_greater_than_1(self):
        from shared.storage_billing import STORAGE_MARKUP_MULTIPLIER
        assert STORAGE_MARKUP_MULTIPLIER > 1.0

    def test_markup_applied_correctly(self):
        """User rate should always be above cost (positive margin)."""
        from shared.storage_billing import get_current_storage_rate, R2_BASE_COST_PER_GB_MONTH
        user_rate = get_current_storage_rate()
        assert user_rate > R2_BASE_COST_PER_GB_MONTH
