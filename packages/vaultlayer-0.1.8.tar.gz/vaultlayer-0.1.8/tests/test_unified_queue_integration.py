"""Integration tests for the 4 HIGH-IMPACT gaps in unit coverage:

  1. `_worker_loop` Phase 1c — does it actually skip when all preferred
     providers are at cap?
  2. `/jobs/run` Phase 1b — does it actually dual-write to unified queue
     when the feature flag is on?
  3. `_handle_provision_result` Phase 2 failover paths — do they enqueue
     with PRIO_FAILOVER when flag on?
  4. SQLite corruption resilience — does `restore_all()` handle a
     corrupt DB without crashing the app?
"""
from __future__ import annotations

import os
import tempfile

import pytest

from api import unified_queue as uq
from api import unified_queue_persist as uqp


# ───────────────────────────────────────────────────────────────────────────
# Gap 1: _worker_loop Phase 1c integration — the inflight-compute +
#   skip-if-capped logic embedded in the loop.
# ───────────────────────────────────────────────────────────────────────────

def _simulate_worker_cycle(active_jobs: dict, job_queue: list, uq_enabled: bool):
    """Pure-function replica of the Phase 1c block in _worker_loop. Keeps
    the loop's decision logic testable in isolation without needing to
    run the actual asyncio loop."""
    per_provider_inflight: dict[str, int] = {}
    if uq_enabled:
        for j in active_jobs.values():
            p = j.get("provider")
            if p and j.get("status") in ("provisioning", "running"):
                per_provider_inflight[p] = per_provider_inflight.get(p, 0) + 1

    skipped = []
    would_provision = []
    for job_id in job_queue:
        job = active_jobs.get(job_id)
        if not job or job["status"] == "cancelled":
            continue

        # Phase 1c gate
        if uq_enabled:
            preferred = job.get("preferred_providers") or []
            if preferred and all(
                per_provider_inflight.get(p, 0) >= uq.cap_for(p)
                for p in preferred
            ):
                skipped.append(job_id)
                continue

        would_provision.append(job_id)
        # Optimistic in-cycle increment (matches _worker_loop's behavior)
        if uq_enabled and (job.get("preferred_providers") or []):
            first = job["preferred_providers"][0]
            per_provider_inflight[first] = per_provider_inflight.get(first, 0) + 1

    return {"skipped": skipped, "provision": would_provision}


def test_worker_loop_cycle_skips_at_cap_when_flag_on():
    # Vast at cap (3 inflight); new Vast-preferred job should be skipped
    active_jobs = {
        f"v-{i}": {"provider": "Vast.ai", "status": "running"}
        for i in range(uq.cap_for("Vast.ai"))
    }
    active_jobs["new-a"] = {
        "status": "queued",
        "preferred_providers": ["Vast.ai"],
    }
    result = _simulate_worker_cycle(active_jobs, ["new-a"], uq_enabled=True)
    assert "new-a" in result["skipped"]
    assert result["provision"] == []


def test_worker_loop_cycle_provisions_when_flag_off():
    """Flag off → no cap check, global MAX_CONCURRENT_PROVISIONS=5 only."""
    active_jobs = {
        f"v-{i}": {"provider": "Vast.ai", "status": "running"}
        for i in range(uq.cap_for("Vast.ai"))
    }
    active_jobs["new-a"] = {
        "status": "queued",
        "preferred_providers": ["Vast.ai"],
    }
    result = _simulate_worker_cycle(active_jobs, ["new-a"], uq_enabled=False)
    # Flag off — no per-provider cap check; this job would provision
    assert result["skipped"] == []
    assert "new-a" in result["provision"]


def test_worker_loop_in_cycle_counter_prevents_burst_launch():
    """Two Vast-preferred jobs in same cycle. First fills the last slot,
    second must be skipped (in-cycle counter increment)."""
    # Vast currently has 2 inflight (cap is 3 — 1 slot open)
    active_jobs = {
        f"v-{i}": {"provider": "Vast.ai", "status": "running"}
        for i in range(uq.cap_for("Vast.ai") - 1)
    }
    active_jobs["new-a"] = {
        "status": "queued",
        "preferred_providers": ["Vast.ai"],
    }
    active_jobs["new-b"] = {
        "status": "queued",
        "preferred_providers": ["Vast.ai"],
    }
    result = _simulate_worker_cycle(active_jobs, ["new-a", "new-b"], uq_enabled=True)
    # First should provision, second should skip
    assert "new-a" in result["provision"]
    assert "new-b" in result["skipped"]


def test_worker_loop_cycle_fallthrough_to_unsaturated_provider():
    """Vast at cap, RunPod empty — job with [Vast, RunPod] should
    provision (RunPod is under cap)."""
    active_jobs = {
        f"v-{i}": {"provider": "Vast.ai", "status": "running"}
        for i in range(uq.cap_for("Vast.ai"))
    }
    active_jobs["new"] = {
        "status": "queued",
        "preferred_providers": ["Vast.ai", "RunPod"],
    }
    result = _simulate_worker_cycle(active_jobs, ["new"], uq_enabled=True)
    assert "new" in result["provision"]


# ───────────────────────────────────────────────────────────────────────────
# Gap 2: /jobs/run Phase 1b dual-write integration
#
# We don't want to spin up the full FastAPI app (heavy). Instead, we
# verify the contract: when `feature_enabled()` is True and `enqueue()`
# is called, the item lands in the heap. The `/jobs/run` handler code at
# src/api/job_routes.py:380-390 does exactly:
#     _job_queue.append(job_id)
#     if _uq.feature_enabled():
#         _uq.enqueue(job_id, priority=_uq.PRIO_NORMAL)
# So the integration surface reduces to verifying enqueue behavior under
# the feature flag on vs off.
# ───────────────────────────────────────────────────────────────────────────

def test_enqueue_visible_in_heap_when_flag_on(monkeypatch):
    monkeypatch.setenv("VL_UNIFIED_QUEUE", "1")
    monkeypatch.setenv("VL_UNIFIED_QUEUE_PERSIST_DISABLE", "1")  # avoid sqlite io
    uq.reset_for_test()
    # The /jobs/run handler would do:
    job_id = "test-job-abc"
    uq.enqueue(job_id, priority=uq.PRIO_NORMAL)
    assert uq.queue_depth() == 1


def test_feature_flag_contract_with_jobs_run(monkeypatch):
    """Verifies the pattern in job_routes.py: check flag, then enqueue.
    The skip-when-flag-off pattern lives in the caller, not unified_queue
    (enqueue always writes regardless). So we just confirm `feature_enabled`
    controls the caller's choice."""
    monkeypatch.setenv("VL_UNIFIED_QUEUE", "0")
    assert uq.feature_enabled() is False  # /jobs/run would skip enqueue
    monkeypatch.setenv("VL_UNIFIED_QUEUE", "1")
    assert uq.feature_enabled() is True   # /jobs/run would call enqueue


# ───────────────────────────────────────────────────────────────────────────
# Gap 3: Phase 2 failover-path integration
#
# _handle_provision_result's two failover branches (stuck_requeue at
# ~line 1650, alive_check_failover at ~line 1715) call:
#     _job_queue.append(job_id)
#     try:
#         from api import unified_queue as _uq
#         if _uq.feature_enabled():
#             _uq.enqueue(job_id, priority=_uq.PRIO_FAILOVER, retry_context={...})
#     except ImportError: pass
#
# We verify the priority + retry_context shape, which is what matters
# for downstream consumers.
# ───────────────────────────────────────────────────────────────────────────

def test_failover_enqueue_uses_failover_priority(monkeypatch):
    monkeypatch.setenv("VL_UNIFIED_QUEUE", "1")
    monkeypatch.setenv("VL_UNIFIED_QUEUE_PERSIST_DISABLE", "1")
    uq.reset_for_test()

    # Simulate stuck_requeue failover path
    job_id = "failover-job-1"
    uq.enqueue(
        job_id,
        priority=uq.PRIO_FAILOVER,
        retry_context={"reason": "stuck_requeue", "prior_provider": "Vast.ai"},
    )
    # Simulate a NORMAL submit that lost the race
    uq.enqueue("normal-job", priority=uq.PRIO_NORMAL)

    # Failover item must come out first
    item = uq.dequeue_for_provider(["RunPod"])
    assert item is not None
    assert item.job_id == job_id
    assert item.priority == uq.PRIO_FAILOVER
    assert item.retry_context["reason"] == "stuck_requeue"
    assert item.retry_context["prior_provider"] == "Vast.ai"


def test_alive_check_failover_retry_context_shape(monkeypatch):
    monkeypatch.setenv("VL_UNIFIED_QUEUE", "1")
    monkeypatch.setenv("VL_UNIFIED_QUEUE_PERSIST_DISABLE", "1")
    uq.reset_for_test()

    # Simulate alive_check_failover path (the second failover block)
    uq.enqueue(
        "alive-check-job",
        priority=uq.PRIO_FAILOVER,
        retry_context={
            "reason": "alive_check_failover",
            "prior_provider": "Lambda Labs",
            "checkpoint_step": 200,
            "migration_count": 1,
        },
    )

    item = uq.dequeue_for_provider(["Vast.ai"])
    assert item is not None
    ctx = item.retry_context
    assert ctx["reason"] == "alive_check_failover"
    assert ctx["checkpoint_step"] == 200
    assert ctx["migration_count"] == 1


# ───────────────────────────────────────────────────────────────────────────
# Gap 4: SQLite corruption resilience
# ───────────────────────────────────────────────────────────────────────────

def test_restore_handles_corrupt_db_gracefully(monkeypatch):
    """If the SQLite file is corrupt at startup, restore_from_persistence
    should NOT crash the app. Ideally returns 0 or an empty list; never
    raises."""
    with tempfile.NamedTemporaryFile(suffix=".sqlite", delete=False) as f:
        path = f.name
    try:
        # Write garbage that isn't valid SQLite
        with open(path, "wb") as f:
            f.write(b"this is not a sqlite database\x00\xFF" * 100)
        monkeypatch.setattr(uqp, "DB_PATH", path)
        monkeypatch.setenv("VL_UNIFIED_QUEUE", "1")
        monkeypatch.delenv("VL_UNIFIED_QUEUE_PERSIST_DISABLE", raising=False)
        uq.reset_for_test()

        # Corrupt DB must NOT crash the app. restore returns 0; the
        # corrupt file is moved aside so next enqueue creates fresh schema.
        count = uq.restore_from_persistence()
        assert count == 0
        # Original DB should have been renamed to .corrupt.<timestamp>
        import glob
        corrupt_files = glob.glob(f"{path}.corrupt.*")
        assert len(corrupt_files) >= 1, "corrupt DB should have been renamed aside"
        # Queue should be usable again — new enqueue succeeds
        uq.enqueue("post-corruption-job", uq.PRIO_NORMAL)
        assert uq.queue_depth() == 1
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def test_missing_db_file_does_not_crash(monkeypatch):
    """If the DB file doesn't exist at startup, restore should just return 0
    (schema gets created fresh on first enqueue)."""
    with tempfile.NamedTemporaryFile(suffix=".sqlite", delete=False) as f:
        path = f.name
    os.unlink(path)  # delete so file doesn't exist
    try:
        monkeypatch.setattr(uqp, "DB_PATH", path)
        monkeypatch.setenv("VL_UNIFIED_QUEUE", "1")
        monkeypatch.delenv("VL_UNIFIED_QUEUE_PERSIST_DISABLE", raising=False)
        uq.reset_for_test()

        count = uq.restore_from_persistence()
        assert count == 0

        # Can still enqueue after missing-file recovery
        uq.enqueue("post-recovery-job", uq.PRIO_NORMAL)
        assert uq.queue_depth() == 1
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def test_db_path_env_var_respected(monkeypatch, tmp_path):
    """Confirm VL_UNIFIED_QUEUE_DB env var routes persistence to a custom
    path. Guards against accidentally writing to the default /tmp path
    in tests."""
    db_file = tmp_path / "custom_queue.sqlite"
    # Must reimport to pick up new env value (module reads at import time —
    # for this test we set the attr directly, mimicking what the env read
    # would do)
    monkeypatch.setattr(uqp, "DB_PATH", str(db_file))
    monkeypatch.setenv("VL_UNIFIED_QUEUE", "1")
    monkeypatch.delenv("VL_UNIFIED_QUEUE_PERSIST_DISABLE", raising=False)
    uq.reset_for_test()

    uq.enqueue("custom-path-job", uq.PRIO_NORMAL)
    assert db_file.exists()
    assert uqp.depth() == 1
