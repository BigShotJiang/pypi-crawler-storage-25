"""
test_scenarios.py — VaultLayer holistic scenario tests.

Covers every major scenario the system must handle before production:
  S1: Normal job completion (happy path)
  S2: Spot preemption + migrate (termination signal)
  S3: Arbitrage opportunity triggers migration
  S4: Checkpoint saved/restored across migration
  S5: Silent zombie (GPU util=0, hung job, CUDA OOM)
  S6: Regional blackout (R2 unavailable, backup bucket, atomic manifest)
  S7: All 9 providers route correctly through execute_migration
  S8: Provider config null-check (missing API key = graceful None)
  S9: Per-channel queue isolation (broker/orch don't steal each other's messages)
  S10: Capacity guard idempotency + AWS unslotted
  S11: Mutex prevents concurrent migrations for same job
  S12: Orchestration rule-based fallback when Claude API down
  S13: Migration pipeline end-to-end (orch → critical stream → broker → provision)
  S14: Infinite loop guard (MIGRATION_REQUESTED not re-processed by orchestration)
  S15: Broker handles MIGRATION_REQUESTED from critical stream
"""
import asyncio
import json
import os
import time
from datetime import datetime, timedelta
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch, call
import pytest

# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def mock_queue():
    q = AsyncMock()
    q.publish = AsyncMock()
    q.publish_critical = AsyncMock(return_value="stream-entry-1")
    q.consume_critical = AsyncMock()
    q.get_job_state = AsyncMock(return_value=None)
    q.set_job_state = AsyncMock()
    q.subscribe = AsyncMock()
    return q

@pytest.fixture
def mock_config():
    cfg = MagicMock()
    cfg.lambda_labs = MagicMock(api_key="test-lambda-key", base_url="https://cloud.lambdalabs.com/api/v1")
    cfg.coreweave = MagicMock(api_key="test-cw-key", namespace="test")
    cfg.runpod = MagicMock(api_key="test-runpod-key")
    cfg.vast_ai = MagicMock(api_key="test-vast-key")
    cfg.voltage_park = MagicMock(api_key="test-vp-key")
    cfg.crusoe = MagicMock(api_key="test-crusoe-key")
    cfg.nebius = MagicMock(api_key="test-nebius-key")
    cfg.hyperstack = MagicMock(api_key="test-hs-key")
    cfg.aws = MagicMock(region="us-east-1", access_key="key", secret_key="secret")
    return cfg

@pytest.fixture
def sample_job():
    from shared.models import Job, JobStatus, Provider, GPUType
    return Job(
        name="test-training-run",
        status=JobStatus.RUNNING,
        provider=Provider.RUNPOD,
        gpu_type=GPUType.H100_80GB_SXM,
        instance_id="pod-abc123",
        user_id="user-1",
        region="us-east-1",
        model_params_billion=7.0,
        command=json.dumps(["python", "train.py", "--epochs", "10"]),
    )


# ── S1: Happy path ────────────────────────────────────────────────────────────

def test_s1_job_model_defaults():
    """Job model instantiates with sensible defaults including instance_id=""."""
    from shared.models import Job, Provider, GPUType, JobStatus
    job = Job(name="test", provider=Provider.RUNPOD, gpu_type=GPUType.H100_80GB_SXM)
    assert job.instance_id == ""
    assert job.status == JobStatus.QUEUED
    assert job.job_id  # auto-generated UUID


def test_s1_migration_requested_in_event_type():
    """MIGRATION_REQUESTED must exist in EventType to drive the migration pipeline."""
    from shared.models import EventType
    assert hasattr(EventType, "MIGRATION_REQUESTED"), (
        "EventType.MIGRATION_REQUESTED missing -- orchestration cannot publish to broker stream"
    )
    assert EventType.MIGRATION_REQUESTED.value == "migration_requested"


# ── S2: Spot preemption ───────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_s2_watchdog_handle_failure_publishes_termination_signal(mock_queue, sample_job):
    """_handle_failure must publish TERMINATION_SIGNAL so orchestration triggers migration."""
    from agents.watchdog.agent import WatchdogAgent
    from shared.models import EventType
    cfg = MagicMock()
    agent = WatchdogAgent(cfg, mock_queue)
    agent.register_job(sample_job, AsyncMock())
    await agent._handle_failure(sample_job, "test_reason", "test detail")
    # Should publish at minimum a CHECKPOINT_REQUESTED and TERMINATION_SIGNAL
    calls = mock_queue.publish.call_args_list
    event_types = []
    for c in calls:
        evt = c.args[1] if c.args else None
        if evt and hasattr(evt, "event_type"):
            event_types.append(evt.event_type)
    assert any(et == EventType.TERMINATION_SIGNAL for et in event_types), (
        f"TERMINATION_SIGNAL not published. Got: {event_types}"
    )


@pytest.mark.asyncio
async def test_s2_health_check_loop_calls_hung_job_check(mock_queue, sample_job):
    """_health_check_loop must invoke check_hung_job on every active job."""
    from agents.watchdog.agent import WatchdogAgent
    cfg = MagicMock()
    agent = WatchdogAgent(cfg, mock_queue)
    sample_job.last_heartbeat_at = datetime.utcnow() - timedelta(seconds=400)
    agent.register_job(sample_job, AsyncMock())
    agent._handle_failure = AsyncMock()
    # Run one iteration: first sleep returns normally, second sleep cancels
    _sleep_calls = [0]
    async def _fake_sleep(t):
        _sleep_calls[0] += 1
        if _sleep_calls[0] > 1:
            raise asyncio.CancelledError()
    with patch("asyncio.sleep", new=_fake_sleep):
        try:
            await agent._health_check_loop()
        except asyncio.CancelledError:
            pass
    agent._handle_failure.assert_called_once()
    call_args = agent._handle_failure.call_args
    assert "hung_job" in call_args.args or "hung_job" in str(call_args)


# ── S5: Silent Zombie ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_s5_gpu_util_zero_fires_after_threshold(mock_queue, sample_job):
    """GPU util=0% for VL_GPU_UTIL_ZERO_SECS should return True (zombie detected)."""
    from agents.watchdog.agent import WatchdogAgent
    cfg = MagicMock()
    agent = WatchdogAgent(cfg, mock_queue)
    agent.register_job(sample_job, AsyncMock())
    os.environ["VL_GPU_UTIL_ZERO_SECS"] = "30"  # short threshold for test
    # Inject 5 zero-util samples spanning > 30s
    from collections import deque
    now = time.monotonic()
    agent._gpu_util_samples[sample_job.job_id] = deque(
        [(now - 35 + i*7, 0.0) for i in range(5)], maxlen=20
    )
    with patch.object(agent, '_poll_gpu_utilization', new_callable=AsyncMock, return_value=0.0):
        result = await agent._check_gpu_zero_utilization(sample_job)
    assert result is True, "Should detect silent zombie with 5 consecutive zero-util samples"
    del os.environ["VL_GPU_UTIL_ZERO_SECS"]


@pytest.mark.asyncio
async def test_s5_gpu_util_nonzero_does_not_fire(mock_queue, sample_job):
    """Non-zero GPU util should not trigger zombie detection."""
    from agents.watchdog.agent import WatchdogAgent
    cfg = MagicMock()
    agent = WatchdogAgent(cfg, mock_queue)
    agent.register_job(sample_job, AsyncMock())
    from collections import deque
    now = time.monotonic()
    # Mix of zero and non-zero -- should not fire
    agent._gpu_util_samples[sample_job.job_id] = deque(
        [(now - 60 + i*10, 0.0 if i < 3 else 75.0) for i in range(6)], maxlen=20
    )
    with patch.object(agent, '_poll_gpu_utilization', new_callable=AsyncMock, return_value=75.0):
        result = await agent._check_gpu_zero_utilization(sample_job)
    assert result is False


@pytest.mark.asyncio
async def test_s5_nvidia_smi_unavailable_returns_minus_one(mock_queue, sample_job):
    """If nvidia-smi is not installed, _poll_gpu_utilization returns -1 (no action)."""
    from agents.watchdog.agent import WatchdogAgent
    cfg = MagicMock()
    agent = WatchdogAgent(cfg, mock_queue)
    with patch("asyncio.create_subprocess_exec", side_effect=FileNotFoundError("nvidia-smi not found")):
        result = await agent._poll_gpu_utilization(sample_job.job_id)
    assert result == -1


def test_s5_hung_job_timeout_is_300s():
    """HUNG_JOB_TIMEOUT_SECONDS must be 300s (5min) not 1800s (30min).
    Market standard: Nebius MTTR=12min, TorchPass migration=2min -> 5min detection."""
    from agents.watchdog.agent import WatchdogAgent
    cfg = MagicMock()
    agent = WatchdogAgent(cfg, MagicMock())
    assert agent.HUNG_JOB_TIMEOUT_SECONDS == 300, (
        f"Hung timeout {agent.HUNG_JOB_TIMEOUT_SECONDS}s is too slow for 12min MTTR target. "
        "Should be 300s (5min). Override with VL_HUNG_JOB_TIMEOUT_SECS env var."
    )


def test_s5_hung_job_timeout_env_override():
    """VL_HUNG_JOB_TIMEOUT_SECS env var syntax -- verify the env var name is correct in source."""
    from agents.watchdog import agent as wmod
    import inspect
    src = inspect.getsource(wmod)
    assert "VL_HUNG_JOB_TIMEOUT_SECS" in src, "Env var name must be VL_HUNG_JOB_TIMEOUT_SECS"
    assert "300" in src, "Default of 300s (5min) must be documented in source"


# ── S6: Regional Blackout ─────────────────────────────────────────────────────

def test_s6_manifest_written_after_upload():
    """R2 upload_checkpoint must write _MANIFEST.json as the final step.
    Only checkpoints with a complete manifest are trusted on restore."""
    from agents.vault.r2 import R2Client
    import inspect
    src = inspect.getsource(R2Client.upload_checkpoint)
    manifest_pos = src.find("_MANIFEST.json")
    return_pos = src.rfind("return record")
    assert manifest_pos != -1, "_MANIFEST.json not found in upload_checkpoint"
    assert manifest_pos < return_pos, (
        "_MANIFEST.json must be written BEFORE return -- it's the completion marker"
    )


def test_s6_backup_bucket_methods_exist():
    """R2Client must have _get_backup_client and _mirror_to_backup methods."""
    from agents.vault.r2 import R2Client
    assert hasattr(R2Client, "_get_backup_client"), "Missing _get_backup_client"
    assert hasattr(R2Client, "_mirror_to_backup"), "Missing _mirror_to_backup"


def test_s6_mirror_returns_false_when_not_configured():
    """_mirror_to_backup must return False (no-op) when backup env vars not set."""
    from agents.vault.r2 import R2Client
    for var in ["VAULTLAYER_BACKUP_R2_ENDPOINT","VAULTLAYER_BACKUP_R2_BUCKET"]:
        os.environ.pop(var, None)
    client = R2Client.__new__(R2Client)
    # Reinitialise class-level env var reads
    client.BACKUP_R2_ENDPOINT = ""
    client.BACKUP_R2_BUCKET = ""
    result = client._mirror_to_backup("some/key", b"data")
    assert result is False


def test_s6_backup_env_vars_documented_in_source():
    """Backup bucket env vars must be documented in r2.py source."""
    from agents.vault import r2 as r2_module
    import inspect
    src = inspect.getsource(r2_module)
    assert "VAULTLAYER_BACKUP_R2_ENDPOINT" in src
    assert "VAULTLAYER_BACKUP_R2_BUCKET" in src


# ── S7: All 9 providers ───────────────────────────────────────────────────────

def test_s7_all_9_providers_in_execute_migration():
    """execute_migration must have routing branches for all 9 Provider enum values."""
    from agents.broker.migration import execute_migration
    from shared.models import Provider
    import inspect
    src = inspect.getsource(execute_migration)
    for p in Provider:
        if p.value in ("gcp", "azure"):  # Phase 2/3 placeholders
            continue
        assert f"Provider.{p.name}" in src, (
            f"Provider.{p.name} missing from execute_migration routing"
        )


def test_s7_provision_methods_exist_for_all_providers():
    """BrokerAgent must have a provision_* method for all active providers."""
    from agents.broker.agent import BrokerAgent
    expected = [
        "provision_lambda", "provision_coreweave", "provision_aws",
        "provision_runpod", "provision_vast", "provision_voltage_park",
        "provision_crusoe", "provision_nebius", "provision_hyperstack",
    ]
    for method in expected:
        assert hasattr(BrokerAgent, method), f"BrokerAgent.{method} missing"


# ── S8: Provider config null-check ────────────────────────────────────────────

@pytest.mark.asyncio
async def test_s8_provision_runpod_returns_none_when_config_missing(mock_queue):
    """provision_runpod must return None gracefully if runpod config is not set."""
    from agents.broker.agent import BrokerAgent
    from shared.models import GPUType
    cfg = MagicMock()
    cfg.runpod = None  # not configured
    broker = BrokerAgent(cfg, mock_queue)
    job = MagicMock()
    result = await broker.provision_runpod(GPUType.H100_80GB_SXM, job)
    assert result is None, "Should return None when provider config is missing"


@pytest.mark.asyncio
async def test_s8_provision_vast_returns_none_when_config_missing(mock_queue):
    """provision_vast must return None gracefully if vast_ai config is not set."""
    from agents.broker.agent import BrokerAgent
    from shared.models import GPUType
    cfg = MagicMock()
    cfg.vast_ai = None
    broker = BrokerAgent(cfg, mock_queue)
    result = await broker.provision_vast(GPUType.H100_80GB_SXM, MagicMock())
    assert result is None


# ── S9: Per-channel queue isolation ──────────────────────────────────────────

def test_s9_queue_has_stream_key_method():
    """AgentQueue must have _stream_key() to isolate broker/orch streams."""
    from shared.queue import AgentQueue
    assert hasattr(AgentQueue, "_stream_key"), "Missing _stream_key -- streams will collide"


def test_s9_broker_stream_key_differs_from_orch_stream_key():
    """publish_critical('broker') and publish_critical('orchestration') must use different keys."""
    from shared.queue import AgentQueue
    q = AgentQueue.__new__(AgentQueue)
    q._CRITICAL_STREAM_PREFIX = "vaultlayer:critical:"
    broker_key = q._stream_key("broker")
    orch_key   = q._stream_key("orchestration")
    assert broker_key != orch_key, "Broker and orchestration are reading from the same stream!"
    assert broker_key == "vaultlayer:critical:broker"
    assert orch_key   == "vaultlayer:critical:orchestration"


# ── S10: Capacity guard ───────────────────────────────────────────────────────

def test_s10_aws_is_unslotted():
    """AWS must never consume a capacity slot -- it has no operator account."""
    from shared.provider_capacity import claim_provider_slot, release_provider_slot
    result = claim_provider_slot("aws", "job-aws-test")
    assert result is True, "AWS claim should always return True (unslotted)"
    # Release should be a no-op (no error, no slot to release)
    release_provider_slot("job-aws-test")


def test_s10_capacity_claim_is_idempotent():
    """Claiming the same job_id + provider twice must not double-count."""
    from shared.provider_capacity import claim_provider_slot, release_provider_slot, get_active_count
    job_id = "job-idem-test-" + str(int(time.time()))
    claim_provider_slot("RunPod", job_id)
    count_after_first = get_active_count("RunPod")
    claim_provider_slot("RunPod", job_id)  # second claim for same job -- should be no-op
    count_after_second = get_active_count("RunPod")
    assert count_after_first == count_after_second, (
        f"Double-claim inflated count: {count_after_first} -> {count_after_second}"
    )
    release_provider_slot(job_id)  # cleanup


def test_s10_canonical_provider_name_normalises_variants():
    """canonical_provider_name must handle all common input formats."""
    from shared.provider_capacity import canonical_provider_name
    assert canonical_provider_name("runpod") == "RunPod"  # enum_val -> meta_key
    assert canonical_provider_name("RUNPOD") == "RunPod"
    assert canonical_provider_name("RunPod") == "RunPod"
    assert canonical_provider_name("aws") == ""       # unslotted
    assert canonical_provider_name("AWS") == ""
    assert canonical_provider_name("Amazon Web Services") == ""


# ── S11: Mutex prevents concurrent migrations ─────────────────────────────────

def test_s11_mutex_infrastructure_exists():
    """execute_migration must use a durable provision lock (Redis SETNX) to prevent
    double-provisioning the same job_id on broker crash-restart."""
    from agents.broker.agent import BrokerAgent
    from agents.broker.migration import execute_migration
    import inspect
    agent_src = inspect.getsource(BrokerAgent)
    migration_src = inspect.getsource(execute_migration)
    assert "_migration_locks" in agent_src, "_migration_locks dict missing from BrokerAgent"
    assert "acquire_provision_lock" in migration_src, (
        "execute_migration must call acquire_provision_lock() — "
        "Redis SETNX guard prevents double-provisioning on crash-restart"
    )
    assert "release_provision_lock" in migration_src, (
        "execute_migration must call release_provision_lock() at every exit path"
    )


# ── S12: Orchestration fallback ───────────────────────────────────────────────

def test_s12_rule_based_decision_exists():
    """OrchestrationAgent must have _rule_based_decision() fallback."""
    from agents.orchestration.agent import OrchestrationAgent
    assert hasattr(OrchestrationAgent, "_rule_based_decision"), (
        "_rule_based_decision missing -- Claude API outage will crash orchestration"
    )


@pytest.mark.asyncio
async def test_s12_rule_based_migrates_on_termination(mock_queue):
    """Rule-based fallback must always migrate on TERMINATION_SIGNAL."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import EventType, AgentEvent
    cfg = MagicMock()
    agent = OrchestrationAgent(cfg, mock_queue)
    event = AgentEvent(
        event_type=EventType.TERMINATION_SIGNAL,
        source_agent="watchdog",
        job_id="job-1",
        payload={"provider": "runpod", "gpu": "h100"},
    )
    decision = agent._rule_based_decision(event)
    assert decision.action in ("migrate", "MIGRATE"), (
        f"Rule-based fallback returned '{decision.action}' on TERMINATION_SIGNAL -- must be 'migrate'"
    )
    assert decision.confidence >= 0.9


@pytest.mark.asyncio
async def test_s12_rule_based_holds_by_default(mock_queue):
    """Rule-based fallback must hold on non-critical events (no Claude needed)."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import EventType, AgentEvent
    cfg = MagicMock()
    agent = OrchestrationAgent(cfg, mock_queue)
    event = AgentEvent(
        event_type=EventType.NODE_HEALTHY,
        source_agent="watchdog",
        job_id="job-1",
        payload={},
    )
    decision = agent._rule_based_decision(event)
    assert decision.action in ("hold", "HOLD")


# ── S13: Migration pipeline E2E ───────────────────────────────────────────────

@pytest.mark.asyncio
async def test_s13_execute_decision_publishes_to_broker_stream(mock_queue, sample_job):
    """_execute_decision must publish MIGRATION_REQUESTED to 'broker' critical stream."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import EventType, AgentEvent
    cfg = MagicMock()
    agent = OrchestrationAgent(cfg, mock_queue)
    trigger = AgentEvent(
        event_type=EventType.TERMINATION_SIGNAL,
        source_agent="watchdog",
        job_id=sample_job.job_id,
        payload={"provider": "lambda_labs", "gpu": "h100"},
    )
    decision = SimpleNamespace(
        action="migrate",
        payload={"provider": "lambda_labs", "gpu": "h100",
                 "target_provider": "lambda_labs", "target_gpu": "h100"},
        confidence=0.95,
        reasoning="spot termination",
        estimated_savings_per_hour=1.20,
    )
    await agent._execute_decision(decision, trigger)
    # Must call publish_critical with "broker" as the first arg
    mock_queue.publish_critical.assert_called_once()
    call_args = mock_queue.publish_critical.call_args
    channel = call_args.args[0] if call_args.args else call_args.kwargs.get("channel_key","")
    assert channel == "broker", (
        f"publish_critical called with channel='{channel}', expected 'broker'. "
        "Migration requests must go to the broker stream."
    )


@pytest.mark.asyncio
async def test_s13_broker_handle_critical_event_calls_execute_migration(mock_queue, sample_job):
    """Broker's _handle_critical_event must call execute_migration when MIGRATION_REQUESTED."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    mock_queue.get_job_state = AsyncMock(return_value=sample_job.model_dump(mode="json"))
    cfg = MagicMock()
    broker = BrokerAgent(cfg, mock_queue)
    broker.execute_migration = AsyncMock()
    fields = {
        "event_type": "migration_requested",
        "job_id": sample_job.job_id,
        "payload": json.dumps({
            "target_provider": "lambda_labs",
            "target_gpu": "h100",
            "decision_confidence": 0.95,
        }),
    }
    await broker._handle_critical_event(fields)
    broker.execute_migration.assert_called_once()
    call_kwargs = broker.execute_migration.call_args
    # Verify the job, provider, and gpu are correctly reconstructed
    job_arg = call_kwargs.args[0]
    provider_arg = call_kwargs.args[1]
    assert job_arg.job_id == sample_job.job_id
    assert provider_arg == Provider.LAMBDA_LABS


# ── S14: Infinite loop guard ──────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_s14_orch_skips_migration_requested_in_critical_handler(mock_queue):
    """OrchestrationAgent._handle_critical_event must skip MIGRATION_REQUESTED events.
    Replaying them would trigger another migration decision -> infinite loop."""
    from agents.orchestration.agent import OrchestrationAgent
    cfg = MagicMock()
    agent = OrchestrationAgent(cfg, mock_queue)
    agent.handle_event = AsyncMock()
    fields = {
        "event_type": "migration_requested",
        "job_id": "job-1",
        "payload": "{}",
    }
    await agent._handle_critical_event(fields)
    # handle_event must NOT be called for outbound event types
    agent.handle_event.assert_not_called()


@pytest.mark.asyncio
async def test_s14_orch_skips_migration_started_in_critical_handler(mock_queue):
    """OrchestrationAgent._handle_critical_event must also skip MIGRATION_STARTED."""
    from agents.orchestration.agent import OrchestrationAgent
    cfg = MagicMock()
    agent = OrchestrationAgent(cfg, mock_queue)
    agent.handle_event = AsyncMock()
    fields = {
        "event_type": "migration_started",
        "job_id": "job-1",
        "payload": "{}",
    }
    await agent._handle_critical_event(fields)
    agent.handle_event.assert_not_called()


# ── S15: Broker consumes critical stream ─────────────────────────────────────

@pytest.mark.asyncio
async def test_s15_broker_start_runs_both_consumers(mock_queue):
    """Broker start() must run both listen_for_commands AND _consume_critical_loop.
    Without _consume_critical_loop, broker never sees MIGRATION_REQUESTED from orch."""
    from agents.broker.agent import BrokerAgent
    cfg = MagicMock()
    broker = BrokerAgent(cfg, mock_queue)
    broker.listen_for_commands = AsyncMock()
    broker._consume_critical_loop = AsyncMock()
    try:
        await asyncio.wait_for(broker.start(), timeout=0.1)
    except (asyncio.TimeoutError, asyncio.CancelledError):
        pass
    broker.listen_for_commands.assert_called_once()
    broker._consume_critical_loop.assert_called_once()


def test_s15_broker_has_consume_critical_loop():
    """BrokerAgent must have _consume_critical_loop and _handle_critical_event."""
    from agents.broker.agent import BrokerAgent
    assert hasattr(BrokerAgent, "_consume_critical_loop")
    assert hasattr(BrokerAgent, "_handle_critical_event")
