"""
VaultLayer — Vault Agent Tests
Verifies checkpoint creation, restore, and R2 storage behaviour.
"""
import sys, os, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from conftest import MockAgentQueue, make_job


def make_mock_r2(job_id="test-001", step=1000):
    """Build a mock R2Client that doesn't touch real R2."""
    from shared.models import CheckpointRecord
    mock = MagicMock()
    mock.healthcheck.return_value = True
    mock.upload_checkpoint.return_value = CheckpointRecord(
        job_id=job_id, step=step, epoch=1.0,
        r2_key=f"checkpoints/{job_id}/step-{step:08d}/model.pt",
        size_bytes=4096, sync_duration_seconds=0.1,
        model_params_billion=7.0,
    )
    mock.get_latest_checkpoint_key.return_value =         f"checkpoints/{job_id}/step-{step:08d}/model.pt"
    mock.download_checkpoint.return_value = f"/tmp/restored_{job_id}/model.pt"
    mock.sync_namespace_manifest = MagicMock()
    mock.get_namespace_manifest.return_value = None   # no chain — fall back to direct download
    mock.restore_from_chain.return_value = None       # no chain restore in unit tests
    mock.upload_delta.return_value = None             # no delta in unit tests (first checkpoint)
    return mock


# ── 1. Checkpoint creates a CheckpointRecord ─────────────────────────────

@pytest.mark.asyncio
async def test_checkpoint_returns_record(dummy_config, mock_queue):
    """checkpoint() must return a CheckpointRecord with correct job_id/step."""
    from agents.vault.agent import VaultAgent
    from agents.vault.r2 import R2Client

    with tempfile.NamedTemporaryFile(suffix=".pt", delete=False) as f:
        f.write(b"fake weights " * 256)
        model_path = f.name

    try:
        mock_r2 = make_mock_r2(step=5000)
        with patch.object(R2Client, '__new__', return_value=mock_r2):
            agent = VaultAgent(config=dummy_config, queue=mock_queue)
            agent.r2 = mock_r2
            job = make_job()
            job.current_step = 5000
            job.current_epoch = 2.5
            record = await agent.checkpoint(job, model_path)

        assert record.job_id == "test-001"
        assert record.step == 5000
        assert record.r2_key.startswith("checkpoints/test-001/")
    finally:
        os.unlink(model_path)


# ── 2. Checkpoint publishes event to vault channel ───────────────────────

@pytest.mark.asyncio
async def test_checkpoint_publishes_to_vault_channel(dummy_config, mock_queue):
    """After checkpoint, a CHECKPOINT_COMPLETE event must go to vault channel."""
    from agents.vault.agent import VaultAgent
    from agents.vault.r2 import R2Client
    from shared.models import EventType

    with tempfile.NamedTemporaryFile(suffix=".pt", delete=False) as f:
        f.write(b"fake weights " * 256)
        model_path = f.name

    try:
        mock_r2 = make_mock_r2()
        with patch.object(R2Client, '__new__', return_value=mock_r2):
            agent = VaultAgent(config=dummy_config, queue=mock_queue)
            agent.r2 = mock_r2
            job = make_job()
            await agent.checkpoint(job, model_path)

        vault_events = mock_queue.events_on("vault")
        assert len(vault_events) > 0, "Must publish to vault channel after checkpoint"
        event_types = [e.event_type for e in vault_events]
        assert EventType.CHECKPOINT_COMPLETE in event_types
    finally:
        os.unlink(model_path)


# ── 3. Restore returns a local file path ─────────────────────────────────

@pytest.mark.asyncio
async def test_restore_returns_local_path(dummy_config, mock_queue):
    """restore() must return a local path where the checkpoint was saved."""
    from agents.vault.agent import VaultAgent
    from agents.vault.r2 import R2Client

    mock_r2 = make_mock_r2()
    with tempfile.TemporaryDirectory() as tmpdir:
        with patch.object(R2Client, '__new__', return_value=mock_r2):
            agent = VaultAgent(config=dummy_config, queue=mock_queue)
            agent.r2 = mock_r2
            path = await agent.restore("test-001", tmpdir)

    assert path is not None, "restore() must return a path"
    assert isinstance(path, str)


# ── 4. R2 healthcheck used before operations ─────────────────────────────

@pytest.mark.asyncio
async def test_vault_uses_r2_healthcheck(dummy_config, mock_queue):
    """Vault agent must verify R2 is reachable before attempting checkpoint."""
    from agents.vault.agent import VaultAgent
    from agents.vault.r2 import R2Client

    with tempfile.NamedTemporaryFile(suffix=".pt", delete=False) as f:
        f.write(b"fake weights")
        model_path = f.name

    try:
        mock_r2 = make_mock_r2()
        with patch.object(R2Client, '__new__', return_value=mock_r2):
            agent = VaultAgent(config=dummy_config, queue=mock_queue)
            agent.r2 = mock_r2
            await agent.checkpoint(make_job(), model_path)

        mock_r2.healthcheck.assert_called()
    finally:
        os.unlink(model_path)


# ── 5. Checkpoint compresses before upload ───────────────────────────────

def test_r2_client_compresses_with_zlib():
    """R2Client must use zlib to compress checkpoint data before uploading."""
    import inspect
    from agents.vault.r2 import R2Client
    source = inspect.getsource(R2Client)
    assert "zlib" in source, "R2Client must use zlib for compression"
    assert "zstd" not in source.lower(),         "zstd reference should not exist (we use zlib)"


# ── 6. Checkpoint rollback: falls back to previous full snapshot ─────────

@pytest.mark.asyncio
async def test_restore_falls_back_to_previous_full_snapshot(dummy_config, mock_queue):
    """When the requested step fails to restore, vault must roll back to the previous full snapshot."""
    import tempfile
    from agents.vault.agent import VaultAgent
    from agents.vault.r2 import R2Client

    mock_r2 = make_mock_r2(step=5000)
    # Simulate failed restore: restore_from_chain and direct download both return None
    mock_r2.restore_from_chain.return_value = None
    mock_r2.list_checkpoints.return_value = []   # no matching checkpoint for requested step
    # Manifest contains a checkpoint chain with a previous full snapshot at step 4000
    mock_r2.get_namespace_manifest.return_value = {
        "latest_step": 5000,
        "checkpoint_chain": [
            {"step": 4000, "type": "full", "r2_key": "checkpoints/test-001/step-4000/model.pt", "base_step": None},
            {"step": 5000, "type": "delta", "r2_key": "checkpoints/test-001/step-5000/delta.bin", "base_step": 4000},
        ]
    }
    # The rollback download succeeds
    mock_r2.download_checkpoint.return_value = "/tmp/rollback/model.pt"

    with tempfile.TemporaryDirectory() as tmpdir:
        with patch.object(R2Client, '__new__', return_value=mock_r2):
            agent = VaultAgent(config=dummy_config, queue=mock_queue)
            agent.r2 = mock_r2
            path = await agent.restore("test-001", tmpdir, step=5000)

    assert path is not None, "Rollback must return a path to the previous full snapshot"
    assert path == "/tmp/rollback/model.pt"


@pytest.mark.asyncio
async def test_restore_rollback_sets_resume_step_env(dummy_config, mock_queue):
    """Rollback must set VAULTLAYER_RESUME_STEP to the rollback step, not the failed step."""
    import tempfile
    import os
    from agents.vault.agent import VaultAgent
    from agents.vault.r2 import R2Client

    mock_r2 = make_mock_r2(step=5000)
    mock_r2.restore_from_chain.return_value = None
    mock_r2.list_checkpoints.return_value = []
    mock_r2.get_namespace_manifest.return_value = {
        "latest_step": 5000,
        "checkpoint_chain": [
            {"step": 3500, "type": "full", "r2_key": "checkpoints/test-001/step-3500/model.pt", "base_step": None},
        ]
    }
    mock_r2.download_checkpoint.return_value = "/tmp/rollback/model.pt"

    # Remove env var so we can verify it was set by rollback
    os.environ.pop("VAULTLAYER_RESUME_STEP", None)

    with tempfile.TemporaryDirectory() as tmpdir:
        with patch.object(R2Client, '__new__', return_value=mock_r2):
            agent = VaultAgent(config=dummy_config, queue=mock_queue)
            agent.r2 = mock_r2
            await agent.restore("test-001", tmpdir, step=5000)

    resume_step = os.environ.get("VAULTLAYER_RESUME_STEP")
    assert resume_step == "3500", \
        f"VAULTLAYER_RESUME_STEP must be set to rollback step 3500, got {resume_step!r}"


@pytest.mark.asyncio
async def test_restore_selects_most_recent_full_snapshot_for_rollback(dummy_config, mock_queue):
    """Rollback must select the *most recent* full snapshot before the failed step."""
    import tempfile
    from agents.vault.agent import VaultAgent
    from agents.vault.r2 import R2Client

    downloaded_steps = []

    def _record_download(record, target_dir):
        downloaded_steps.append(record.step)
        return f"/tmp/rollback/step-{record.step}/model.pt"

    mock_r2 = make_mock_r2(step=9000)
    mock_r2.restore_from_chain.return_value = None
    mock_r2.list_checkpoints.return_value = []
    mock_r2.get_namespace_manifest.return_value = {
        "latest_step": 9000,
        "checkpoint_chain": [
            {"step": 1000, "type": "full", "r2_key": "ckpt/step-1000/model.pt", "base_step": None},
            {"step": 2500, "type": "full", "r2_key": "ckpt/step-2500/model.pt", "base_step": None},
            {"step": 4000, "type": "full", "r2_key": "ckpt/step-4000/model.pt", "base_step": None},
            {"step": 9000, "type": "delta", "r2_key": "ckpt/step-9000/delta.bin", "base_step": 4000},
        ]
    }
    mock_r2.download_checkpoint.side_effect = _record_download

    with tempfile.TemporaryDirectory() as tmpdir:
        with patch.object(R2Client, '__new__', return_value=mock_r2):
            agent = VaultAgent(config=dummy_config, queue=mock_queue)
            agent.r2 = mock_r2
            path = await agent.restore("test-001", tmpdir, step=9000)

    assert path is not None
    # Must download step 4000 (most recent full snapshot < 9000), not 1000 or 2500
    assert 4000 in downloaded_steps, \
        f"Must roll back to step 4000 (most recent full), got downloaded_steps={downloaded_steps}"


@pytest.mark.asyncio
async def test_restore_returns_none_when_no_usable_checkpoint(dummy_config, mock_queue):
    """When both primary restore and rollback fail, restore() must return None."""
    import tempfile
    from agents.vault.agent import VaultAgent
    from agents.vault.r2 import R2Client

    mock_r2 = make_mock_r2()
    mock_r2.restore_from_chain.return_value = None
    mock_r2.list_checkpoints.return_value = []
    mock_r2.get_namespace_manifest.return_value = {
        "latest_step": 5000,
        "checkpoint_chain": []   # empty chain — no rollback possible
    }
    mock_r2.download_checkpoint.return_value = None

    with tempfile.TemporaryDirectory() as tmpdir:
        with patch.object(R2Client, '__new__', return_value=mock_r2):
            agent = VaultAgent(config=dummy_config, queue=mock_queue)
            agent.r2 = mock_r2
            path = await agent.restore("test-001", tmpdir, step=5000)

    assert path is None, "restore() must return None when no usable checkpoint exists"

# ── R2 multipart cost optimisation tests ─────────────────────────────────────

def _read_r2_source() -> str:
    """Read r2.py and its extracted modules (delta.py, multipart.py) source directly
    (boto3 not installed in test env)."""
    import pathlib
    vault_dir = pathlib.Path(__file__).parent.parent / "src" / "agents" / "vault"
    parts = [vault_dir / "r2.py", vault_dir / "multipart.py", vault_dir / "delta.py"]
    return "\n".join(p.read_text() for p in parts if p.exists())


def test_multipart_chunk_size_is_200mb():
    """MULTIPART_CHUNK_SIZE_BYTES must be ≥200MB to minimise Class A ops.

    Cost math: 20GB checkpoint at 64MB/part = 320 Class A ops × $0.36/M
               20GB checkpoint at 200MB/part = 103 Class A ops — 68% savings.
    S3/R2 allows up to 5GB per part; 200MB is the safe operational sweet spot.
    """
    import re, math
    src = _read_r2_source()

    # Parse the constant values from source
    chunk_match = re.search(r'MULTIPART_CHUNK_SIZE_BYTES\s*=\s*(\d+)\s*\*\s*(\d+)\s*\*\s*(\d+)', src)
    assert chunk_match, "MULTIPART_CHUNK_SIZE_BYTES constant not found in r2.py"
    chunk_bytes = int(chunk_match.group(1)) * int(chunk_match.group(2)) * int(chunk_match.group(3))

    assert chunk_bytes >= 200 * 1024 * 1024, (
        f"MULTIPART_CHUNK_SIZE_BYTES is {chunk_bytes / 1e6:.0f}MB — "
        "must be ≥200MB to keep Class A ops ≤103 for a 20GB checkpoint"
    )
    # Verify part count for 20GB is ≤110 (acceptable Class A op budget)
    parts_for_20gb = math.ceil(20 * 1024 * 1024 * 1024 / chunk_bytes)
    assert parts_for_20gb <= 110, (
        f"20GB file would require {parts_for_20gb} parts — reduce by increasing "
        "MULTIPART_CHUNK_SIZE_BYTES"
    )


def test_ensure_lifecycle_policy_method_exists():
    """R2Client must have ensure_lifecycle_policy() method for bucket-level
    auto-abort of dangling multipart uploads after 24h."""
    src = _read_r2_source()
    assert "def ensure_lifecycle_policy" in src, (
        "R2Client.ensure_lifecycle_policy() is missing from r2.py — "
        "bucket-level lifecycle rule for dangling multipart abort is not configured"
    )
    # Must reference AbortIncompleteMultipartUpload
    assert "AbortIncompleteMultipartUpload" in src, (
        "ensure_lifecycle_policy() must set AbortIncompleteMultipartUpload lifecycle rule"
    )
    # Must set DaysAfterInitiation to 1 (24h)
    assert "DaysAfterInitiation" in src, (
        "Lifecycle rule must specify DaysAfterInitiation"
    )


def test_verify_standard_storage_class_method_exists():
    """R2Client must have verify_standard_storage_class() to warn if Infrequent Access
    is configured (which would charge $9/M Class A ops instead of $0.36/M)."""
    src = _read_r2_source()
    assert "def verify_standard_storage_class" in src, (
        "R2Client.verify_standard_storage_class() is missing from r2.py — "
        "Infrequent Access detection guard is not in place"
    )
    # Must warn about cost impact
    assert "Infrequent Access" in src or "STANDARD" in src, (
        "verify_standard_storage_class() must check for non-STANDARD storage class"
    )


def test_cleanup_uses_paginator_for_large_bucket():
    """cleanup_orphaned_multipart_uploads must use pagination to handle buckets
    with >1000 incomplete uploads (e.g., after a mass crash)."""
    src = _read_r2_source()
    assert "paginator" in src or "get_paginator" in src, (
        "cleanup_orphaned_multipart_uploads() must use a paginator to handle "
        "buckets with >1000 pending uploads"
    )


def test_lifecycle_policy_called_in_start():
    """VaultAgent.start() source must call ensure_lifecycle_policy()."""
    import pathlib
    agent_src = (pathlib.Path(__file__).parent.parent / "src" / "agents" / "vault" / "agent.py").read_text()
    assert "ensure_lifecycle_policy" in agent_src, (
        "VaultAgent.start() must call self.r2.ensure_lifecycle_policy() — "
        "without this, dangling multipart protection only exists in-process"
    )
    assert "verify_standard_storage_class" in agent_src, (
        "VaultAgent.start() must call self.r2.verify_standard_storage_class() — "
        "Infrequent Access cost trap would go undetected"
    )


# ── Dark checkpoint purge ─────────────────────────────────────────────────────

def test_purge_dark_checkpoints_deletes_steps_without_manifest():
    """purge_dark_checkpoints() must delete step dirs that have data but no _MANIFEST.json.

    A crash between the data upload and the manifest write leaves an orphaned
    ('dark') step directory. It will never be restored (no manifest → not trusted)
    but still accrues R2 storage charges. purge_dark_checkpoints() must detect
    and delete these directories while leaving complete steps (with manifest) alone.
    """
    from unittest.mock import MagicMock, patch
    from agents.vault.r2 import R2Client

    job_id = "job-purge-test"
    prefix = f"checkpoints/{job_id}/"

    # R2 contains:
    #   step-00000100/model.pt        ← dark (data, no manifest)
    #   step-00000200/model.pt        ← complete (data + manifest)
    #   step-00000200/_MANIFEST.json  ← completion marker for step 200
    fake_objects = [
        {"Key": f"{prefix}step-00000100/model.pt"},
        {"Key": f"{prefix}step-00000200/model.pt"},
        {"Key": f"{prefix}step-00000200/_MANIFEST.json"},
    ]

    mock_s3 = MagicMock()

    # Paginator returns only objects matching the given Prefix
    def _paginate(**kwargs):
        prefix_filter = kwargs.get("Prefix", "")
        matching = [o for o in fake_objects if o["Key"].startswith(prefix_filter)]
        return [{"Contents": matching}] if matching else [{}]

    mock_paginator = MagicMock()
    mock_paginator.paginate.side_effect = _paginate
    mock_s3.get_paginator.return_value = mock_paginator

    # delete_objects called for dark step; returns no errors
    mock_s3.delete_objects.return_value = {"Errors": []}

    r2 = R2Client.__new__(R2Client)
    r2.bucket = "test-bucket"
    r2._s3 = mock_s3

    deleted = r2.purge_dark_checkpoints(job_id)

    # Only step-00000100 (dark) should be scheduled for deletion
    assert deleted > 0, "purge_dark_checkpoints must delete dark step objects"

    delete_call_args = mock_s3.delete_objects.call_args
    assert delete_call_args is not None, "delete_objects must be called"
    objects_deleted = delete_call_args[1]["Delete"]["Objects"]
    deleted_keys = [o["Key"] for o in objects_deleted]

    # Dark step must be deleted
    assert any("step-00000100" in k for k in deleted_keys), \
        f"Dark step-00000100 was not deleted; deleted_keys={deleted_keys}"

    # Complete step must NOT be touched
    assert not any("step-00000200" in k for k in deleted_keys), \
        f"Complete step-00000200 was incorrectly included in deletion; deleted_keys={deleted_keys}"


def test_purge_dark_checkpoints_noop_when_all_complete():
    """purge_dark_checkpoints() must return 0 and call no deletions when every
    step directory has a _MANIFEST.json."""
    from unittest.mock import MagicMock
    from agents.vault.r2 import R2Client

    job_id = "job-all-complete"
    prefix = f"checkpoints/{job_id}/"

    fake_objects = [
        {"Key": f"{prefix}step-00000500/model.pt"},
        {"Key": f"{prefix}step-00000500/_MANIFEST.json"},
    ]

    mock_s3 = MagicMock()
    mock_paginator = MagicMock()

    def _paginate(**kwargs):
        prefix_filter = kwargs.get("Prefix", "")
        matching = [o for o in fake_objects if o["Key"].startswith(prefix_filter)]
        return [{"Contents": matching}] if matching else [{}]

    mock_paginator.paginate.side_effect = _paginate
    mock_s3.get_paginator.return_value = mock_paginator

    r2 = R2Client.__new__(R2Client)
    r2.bucket = "test-bucket"
    r2._s3 = mock_s3

    deleted = r2.purge_dark_checkpoints(job_id)

    assert deleted == 0, "No deletions expected when all steps have manifests"
    mock_s3.delete_objects.assert_not_called()
