"""
Coverage tests for:
  - src/agents/tester/agent.py
  - src/cli/migrate_keys.py
"""
import sys
import os
import json
import asyncio
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch, mock_open
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))


# ─────────────────────────────────────────────────────────────────────────────
# agents/tester/agent.py
# ─────────────────────────────────────────────────────────────────────────────

from agents.tester.agent import (
    TesterAgent, TestResult,
    PROBLEM_STATEMENT, DISCOVERY_PROMPT, TEST_GENERATION_PROMPT,
    FAILURE_ANALYSIS_PROMPT,
)


def _make_claude_response(text: str):
    """Create a minimal mock Anthropic response."""
    mock_resp = MagicMock()
    mock_content = MagicMock()
    mock_content.text = text
    mock_resp.content = [mock_content]
    return mock_resp


class TestTestResult:
    def test_default_fields(self):
        r = TestResult(name="test_foo", passed=True, duration_seconds=1.5)
        assert r.name == "test_foo"
        assert r.passed is True
        assert r.duration_seconds == 1.5
        assert r.error is None
        assert r.behaviour is None
        assert r.analysis is None

    def test_failed_result(self):
        r = TestResult(name="test_bar", passed=False, duration_seconds=0.1, error="AssertionError")
        assert r.passed is False
        assert r.error == "AssertionError"


class TestTesterAgent:
    def _make_agent(self):
        env = {k: v for k, v in os.environ.items() if k != "ANTHROPIC_API_KEY"}
        env["ANTHROPIC_API_KEY"] = "sk-test"
        with patch.dict("os.environ", env, clear=True):
            with patch("anthropic.Anthropic"):
                agent = TesterAgent()
        return agent

    def test_init_without_api_key_raises(self):
        # Build env without ANTHROPIC_API_KEY
        env = {k: v for k, v in os.environ.items() if k != "ANTHROPIC_API_KEY"}
        with patch.dict("os.environ", env, clear=True):
            with patch("anthropic.Anthropic"):
                # Should raise EnvironmentError if no key
                with pytest.raises(EnvironmentError):
                    TesterAgent()

    def test_init_with_api_key(self):
        env = {k: v for k, v in os.environ.items() if k != "ANTHROPIC_API_KEY"}
        env["ANTHROPIC_API_KEY"] = "sk-test-key"
        with patch.dict("os.environ", env, clear=True):
            with patch("anthropic.Anthropic") as mock_ant:
                agent = TesterAgent()
            assert agent.results == []
            assert agent._discovery == {}
            assert agent._generated_tests == ""

    def test_read_codebase_returns_string(self):
        agent = self._make_agent()
        codebase = agent._read_codebase()
        assert isinstance(codebase, str)
        # Should contain some Python content
        assert len(codebase) > 0

    def test_discover_with_clean_json(self):
        agent = self._make_agent()
        discovery_json = json.dumps({
            "entry_point": "src/cli/main.py",
            "testable_behaviours": ["cost savings", "spot termination handling"],
        })
        agent._claude.messages.create = MagicMock(
            return_value=_make_claude_response(discovery_json)
        )
        with patch.object(agent, "_read_codebase", return_value="# mock codebase"):
            result = agent._discover()
        assert result["entry_point"] == "src/cli/main.py"
        assert len(result["testable_behaviours"]) == 2

    def test_discover_strips_markdown_fences(self):
        agent = self._make_agent()
        discovery_json = "```json\n" + json.dumps({
            "entry_point": "cli",
            "testable_behaviours": ["behaviour1"],
        }) + "\n```"
        agent._claude.messages.create = MagicMock(
            return_value=_make_claude_response(discovery_json)
        )
        with patch.object(agent, "_read_codebase", return_value="# code"):
            result = agent._discover()
        assert result["entry_point"] == "cli"

    def test_discover_strips_python_fences(self):
        agent = self._make_agent()
        discovery_json = "```\n" + json.dumps({
            "entry_point": "cli",
            "testable_behaviours": [],
        }) + "\n```"
        agent._claude.messages.create = MagicMock(
            return_value=_make_claude_response(discovery_json)
        )
        with patch.object(agent, "_read_codebase", return_value="# code"):
            result = agent._discover()
        assert "entry_point" in result

    def test_discover_invalid_json_falls_back_to_raw(self):
        agent = self._make_agent()
        agent._claude.messages.create = MagicMock(
            return_value=_make_claude_response("not valid json at all")
        )
        with patch.object(agent, "_read_codebase", return_value="# code"):
            result = agent._discover()
        assert "raw_discovery" in result
        assert "testable_behaviours" in result

    def test_discover_truncates_large_codebase(self):
        agent = self._make_agent()
        large_codebase = "x" * 90000  # > 80000 chars
        agent._claude.messages.create = MagicMock(
            return_value=_make_claude_response(json.dumps({"testable_behaviours": []}))
        )
        with patch.object(agent, "_read_codebase", return_value=large_codebase):
            agent._discover()
        # The create call should have been made with truncated content
        call_content = agent._claude.messages.create.call_args[1]["messages"][0]["content"]
        assert "[TRUNCATED]" in call_content

    def test_generate_tests_strips_python_fence(self):
        agent = self._make_agent()
        agent._discovery = {"testable_behaviours": ["cost savings"]}
        test_code = "```python\nimport pytest\nasync def test_cost_savings():\n    pass\n```"
        agent._claude.messages.create = MagicMock(
            return_value=_make_claude_response(test_code)
        )
        result = agent._generate_tests()
        assert "import pytest" in result
        assert "```" not in result

    def test_generate_tests_strips_generic_fence(self):
        agent = self._make_agent()
        agent._discovery = {"testable_behaviours": []}
        test_code = "```\ndef test_x():\n    pass\n```"
        agent._claude.messages.create = MagicMock(
            return_value=_make_claude_response(test_code)
        )
        result = agent._generate_tests()
        assert "def test_x" in result

    def test_generate_tests_no_fence(self):
        agent = self._make_agent()
        agent._discovery = {}
        test_code = "import pytest\ndef test_simple():\n    assert True"
        agent._claude.messages.create = MagicMock(
            return_value=_make_claude_response(test_code)
        )
        result = agent._generate_tests()
        assert result == test_code

    def test_execute_tests_with_json_report(self):
        agent = self._make_agent()
        # Create a minimal valid test file
        test_code = "def test_always_passes():\n    assert True\n"
        mock_run_result = MagicMock()
        mock_run_result.returncode = 0
        mock_run_result.stdout = "1 passed"
        mock_run_result.stderr = ""

        report = {
            "tests": [
                {
                    "nodeid": "tmpfile.py::test_always_passes",
                    "outcome": "passed",
                    "duration": 0.01,
                }
            ]
        }

        with patch("subprocess.run", return_value=mock_run_result):
            with patch("builtins.open", mock_open(read_data=json.dumps(report))):
                results = agent._execute_tests(test_code)

        assert len(results) == 1
        assert results[0].passed is True
        assert results[0].name == "test_always_passes"

    def test_execute_tests_json_parse_fails_fallback(self):
        agent = self._make_agent()
        test_code = "def test_x():\n    pass\n"
        mock_run_result = MagicMock()
        mock_run_result.returncode = 0
        mock_run_result.stdout = "tmpfile.py::test_x PASSED\n"
        mock_run_result.stderr = ""

        with patch("subprocess.run", return_value=mock_run_result):
            with patch("builtins.open", side_effect=FileNotFoundError("no report")):
                results = agent._execute_tests(test_code)

        assert len(results) > 0

    def test_execute_tests_no_results_fallback(self):
        """If no tests found in output, creates fallback result from return code."""
        agent = self._make_agent()
        test_code = "# no tests"
        mock_run_result = MagicMock()
        mock_run_result.returncode = 0
        mock_run_result.stdout = ""
        mock_run_result.stderr = ""

        with patch("subprocess.run", return_value=mock_run_result):
            with patch("builtins.open", side_effect=FileNotFoundError("no report")):
                results = agent._execute_tests(test_code)

        assert len(results) == 1
        assert results[0].passed is True

    def test_execute_tests_failed_result(self):
        agent = self._make_agent()
        test_code = "def test_fail():\n    assert False\n"
        mock_run_result = MagicMock()
        mock_run_result.returncode = 1
        mock_run_result.stdout = ""
        mock_run_result.stderr = ""

        report = {
            "tests": [
                {
                    "nodeid": "tmpfile.py::test_fail",
                    "outcome": "failed",
                    "duration": 0.01,
                    "call": {"longrepr": "AssertionError: assert False"},
                }
            ]
        }

        with patch("subprocess.run", return_value=mock_run_result):
            with patch("builtins.open", mock_open(read_data=json.dumps(report))):
                results = agent._execute_tests(test_code)

        assert results[0].passed is False
        assert "AssertionError" in (results[0].error or "")

    def test_execute_tests_longrepr_dict(self):
        """longrepr can be a dict — extract reprtext."""
        agent = self._make_agent()
        report = {
            "tests": [
                {
                    "nodeid": "f.py::test_x",
                    "outcome": "failed",
                    "duration": 0,
                    "call": {"longrepr": {"reprtext": "the error text"}},
                }
            ]
        }
        mock_run_result = MagicMock()
        mock_run_result.returncode = 1
        mock_run_result.stdout = ""
        mock_run_result.stderr = ""
        with patch("subprocess.run", return_value=mock_run_result):
            with patch("builtins.open", mock_open(read_data=json.dumps(report))):
                results = agent._execute_tests("# code")
        assert "the error text" in (results[0].error or "")

    def test_analyze_failures_no_failures(self):
        agent = self._make_agent()
        results = [TestResult("test_ok", True, 0.1)]
        agent._analyze_failures(results)  # should not call claude
        agent._claude.messages.create.assert_not_called()

    def test_analyze_failures_with_failure(self):
        agent = self._make_agent()
        r = TestResult("test_fail", False, 0.1, error="AssertionError")
        agent._claude.messages.create = MagicMock(
            return_value=_make_claude_response("Root cause: missing checkpoint handler")
        )
        agent._analyze_failures([r])
        assert r.analysis == "Root cause: missing checkpoint handler"

    def test_analyze_failures_claude_exception(self):
        agent = self._make_agent()
        r = TestResult("test_fail", False, 0.1, error="Error")
        agent._claude.messages.create = MagicMock(side_effect=Exception("API error"))
        agent._analyze_failures([r])
        assert "unavailable" in (r.analysis or "").lower()

    def test_print_results_all_pass(self, capsys):
        agent = self._make_agent()
        agent.results = [
            TestResult("test_a", True, 0.5),
            TestResult("test_b", True, 0.3),
        ]
        agent._print_results()
        captured = capsys.readouterr()
        assert "2/2 passed" in captured.out

    def test_print_results_with_failures(self, capsys):
        agent = self._make_agent()
        agent.results = [
            TestResult("test_ok", True, 0.1),
            TestResult("test_fail", False, 0.2, error="AssertionError", analysis="Product req broken"),
        ]
        agent._print_results()
        captured = capsys.readouterr()
        assert "1/2 passed" in captured.out
        assert "FAILURES" in captured.out

    def test_report(self):
        agent = self._make_agent()
        agent._discovery = {"testable_behaviours": ["cost savings"]}
        agent.results = [
            TestResult("test_a", True, 0.5),
            TestResult("test_b", False, 0.1, error="fail"),
        ]
        report = agent.report()
        assert report["total"] == 2
        assert report["passed"] == 1
        assert report["failed"] == 1
        assert "discovery" in report
        assert "timestamp" in report
        assert len(report["results"]) == 2

    @pytest.mark.asyncio
    async def test_run_success(self):
        agent = self._make_agent()
        discovery = {"testable_behaviours": ["cost savings"]}
        test_code = "def test_x():\n    assert True"

        with patch.object(agent, "_discover", return_value=discovery):
            with patch.object(agent, "_generate_tests", return_value=test_code):
                with patch.object(agent, "_execute_tests", return_value=[
                    TestResult("test_x", True, 0.1)
                ]):
                    with patch.object(agent, "_analyze_failures"):
                        with patch("builtins.open", mock_open()):
                            result = await agent.run()
        assert result is True

    @pytest.mark.asyncio
    async def test_run_with_failures(self):
        agent = self._make_agent()
        with patch.object(agent, "_discover", return_value={"testable_behaviours": []}):
            with patch.object(agent, "_generate_tests", return_value=""):
                with patch.object(agent, "_execute_tests", return_value=[
                    TestResult("test_fail", False, 0.1, error="failed")
                ]):
                    with patch.object(agent, "_analyze_failures"):
                        with patch("builtins.open", mock_open()):
                            result = await agent.run()
        assert result is False


# ─────────────────────────────────────────────────────────────────────────────
# cli/migrate_keys.py
# ─────────────────────────────────────────────────────────────────────────────

from click.testing import CliRunner
from cli.migrate_keys import migrate_keys


def _make_s3_paginator(pages):
    """Create a mock paginator that returns the given pages."""
    mock_paginator = MagicMock()
    mock_paginator.paginate.return_value = pages
    return mock_paginator


def _make_s3(pages=None):
    """Create a mock boto3 S3 client."""
    mock_s3 = MagicMock()
    mock_paginator = _make_s3_paginator(pages or [])
    mock_s3.get_paginator.return_value = mock_paginator
    return mock_s3


class TestMigrateKeys:
    def test_no_user_exits_1(self):
        runner = CliRunner()
        with patch.dict("os.environ", {}, clear=True):
            result = runner.invoke(migrate_keys, ["--dry-run"])
        assert result.exit_code == 1
        assert "required" in result.output.lower() or "user" in result.output.lower()

    def test_no_mode_exits_1(self):
        runner = CliRunner()
        result = runner.invoke(migrate_keys, ["--user", "alice"])
        assert result.exit_code == 1
        assert "--dry-run" in result.output or "preview" in result.output.lower()

    def test_r2_init_failure_exits_1(self):
        runner = CliRunner()
        with patch("shared.config.load_config", side_effect=Exception("Config error")):
            with patch("dotenv.load_dotenv", return_value=None):
                with patch("pathlib.Path.exists", return_value=False):
                    result = runner.invoke(migrate_keys, ["--user", "alice", "--dry-run"])
        assert result.exit_code == 1
        assert "Failed" in result.output or "failed" in result.output

    def test_dry_run_nothing_to_migrate(self):
        runner = CliRunner()
        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "test-bucket"

        # All objects already migrated (part[1] == user)
        pages = [{"Contents": [
            {"Key": "checkpoints/alice/job123/step-000001/model.pt"}
        ]}]
        mock_s3 = _make_s3(pages)

        with patch("shared.config.load_config", return_value=mock_config):
            with patch("boto3.client", return_value=mock_s3):
                with patch("pathlib.Path.exists", return_value=False):
                    result = runner.invoke(migrate_keys, ["--user", "alice", "--dry-run"])

        assert result.exit_code == 0
        assert "Nothing to migrate" in result.output

    def test_dry_run_shows_migrations(self):
        runner = CliRunner()
        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "test-bucket"

        # Legacy keys: checkpoints/{job_id}/step-xxx
        pages = [{"Contents": [
            {"Key": "checkpoints/job123abc/step-000001/model.pt"},
            {"Key": "checkpoints/job456def/step-000002/optimizer.pt"},
        ]}]
        mock_s3 = _make_s3(pages)

        with patch("shared.config.load_config", return_value=mock_config):
            with patch("boto3.client", return_value=mock_s3):
                with patch("pathlib.Path.exists", return_value=False):
                    result = runner.invoke(migrate_keys, ["--user", "alice", "--dry-run"])

        assert result.exit_code == 0
        assert "[DRY RUN]" in result.output
        assert "checkpoints/alice/job123abc" in result.output

    def test_dry_run_truncates_long_list(self):
        """More than 10 items in dry-run shows truncation message."""
        runner = CliRunner()
        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "test-bucket"

        # 15 legacy keys
        contents = [
            {"Key": f"checkpoints/job{i:03d}/step-000001/model.pt"}
            for i in range(15)
        ]
        pages = [{"Contents": contents}]
        mock_s3 = _make_s3(pages)

        with patch("shared.config.load_config", return_value=mock_config):
            with patch("boto3.client", return_value=mock_s3):
                with patch("pathlib.Path.exists", return_value=False):
                    result = runner.invoke(migrate_keys, ["--user", "alice", "--dry-run"])

        assert result.exit_code == 0
        assert "more" in result.output

    def test_confirm_migration_success(self):
        runner = CliRunner()
        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "test-bucket"

        pages = [{"Contents": [
            {"Key": "checkpoints/job123abc/step-000001/model.pt"},
        ]}]
        mock_s3 = _make_s3(pages)
        mock_s3.copy_object = MagicMock()
        mock_s3.delete_object = MagicMock()

        with patch("shared.config.load_config", return_value=mock_config):
            with patch("boto3.client", return_value=mock_s3):
                with patch("pathlib.Path.exists", return_value=False):
                    result = runner.invoke(migrate_keys, ["--user", "alice", "--confirm"])

        assert result.exit_code == 0
        assert "Migration complete" in result.output
        assert "0 errors" in result.output
        mock_s3.copy_object.assert_called_once()
        mock_s3.delete_object.assert_called_once()

    def test_confirm_migration_with_error(self):
        runner = CliRunner()
        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "test-bucket"

        pages = [{"Contents": [
            {"Key": "checkpoints/job123abc/step-000001/model.pt"},
        ]}]
        mock_s3 = _make_s3(pages)
        mock_s3.copy_object = MagicMock(side_effect=Exception("S3 copy error"))

        with patch("shared.config.load_config", return_value=mock_config):
            with patch("boto3.client", return_value=mock_s3):
                with patch("pathlib.Path.exists", return_value=False):
                    result = runner.invoke(migrate_keys, ["--user", "alice", "--confirm"])

        assert result.exit_code == 0
        assert "[ERROR]" in result.output
        assert "1 errors" in result.output

    def test_confirm_empty_pages(self):
        """Pages with no Contents key — should handle gracefully."""
        runner = CliRunner()
        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "test-bucket"

        pages = [{}]  # No "Contents" key
        mock_s3 = _make_s3(pages)

        with patch("shared.config.load_config", return_value=mock_config):
            with patch("boto3.client", return_value=mock_s3):
                with patch("pathlib.Path.exists", return_value=False):
                    result = runner.invoke(migrate_keys, ["--user", "alice", "--dry-run"])

        assert result.exit_code == 0
        assert "Nothing to migrate" in result.output

    def test_confirm_keys_not_step_format(self):
        """Keys that don't match legacy format (no step- prefix) are skipped."""
        runner = CliRunner()
        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "test-bucket"

        # checkpoints/job123/README.md — part[2] doesn't start with "step-"
        pages = [{"Contents": [
            {"Key": "checkpoints/job123/README.md"},
        ]}]
        mock_s3 = _make_s3(pages)

        with patch("shared.config.load_config", return_value=mock_config):
            with patch("boto3.client", return_value=mock_s3):
                with patch("pathlib.Path.exists", return_value=False):
                    result = runner.invoke(migrate_keys, ["--user", "alice", "--dry-run"])

        assert result.exit_code == 0
        assert "Nothing to migrate" in result.output

    def test_user_from_env(self):
        """--user can be set via VAULTLAYER_USER_ID env var."""
        runner = CliRunner()
        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "test-bucket"

        pages = [{"Contents": []}]
        mock_s3 = _make_s3(pages)

        with patch("shared.config.load_config", return_value=mock_config):
            with patch("boto3.client", return_value=mock_s3):
                with patch("pathlib.Path.exists", return_value=False):
                    result = runner.invoke(
                        migrate_keys, ["--dry-run"],
                        env={"VAULTLAYER_USER_ID": "bob"},
                        catch_exceptions=False,
                    )

        assert result.exit_code == 0
        assert "Nothing to migrate" in result.output

    def test_multiple_pages(self):
        """Paginator returns multiple pages."""
        runner = CliRunner()
        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "test-bucket"

        pages = [
            {"Contents": [{"Key": "checkpoints/job001/step-000001/model.pt"}]},
            {"Contents": [{"Key": "checkpoints/job002/step-000001/model.pt"}]},
        ]
        mock_s3 = _make_s3(pages)
        mock_s3.copy_object = MagicMock()
        mock_s3.delete_object = MagicMock()

        with patch("shared.config.load_config", return_value=mock_config):
            with patch("boto3.client", return_value=mock_s3):
                with patch("pathlib.Path.exists", return_value=False):
                    result = runner.invoke(migrate_keys, ["--user", "alice", "--confirm"])

        assert result.exit_code == 0
        assert mock_s3.copy_object.call_count == 2

    def test_all_already_migrated(self):
        """All objects already have the user_id prefix — nothing to do."""
        runner = CliRunner()
        mock_config = MagicMock()
        mock_config.cloudflare.r2_endpoint = "https://r2.example.com"
        mock_config.cloudflare.r2_access_key_id = "key"
        mock_config.cloudflare.r2_secret_access_key = "secret"
        mock_config.cloudflare.r2_bucket = "test-bucket"

        pages = [{"Contents": [
            {"Key": "checkpoints/alice/job001/step-000001/model.pt"},
            {"Key": "checkpoints/alice/job002/step-000001/model.pt"},
        ]}]
        mock_s3 = _make_s3(pages)

        with patch("shared.config.load_config", return_value=mock_config):
            with patch("boto3.client", return_value=mock_s3):
                with patch("pathlib.Path.exists", return_value=False):
                    result = runner.invoke(migrate_keys, ["--user", "alice", "--dry-run"])

        assert result.exit_code == 0
        assert "Nothing to migrate" in result.output
        assert "Already migrated: 2" in result.output
