"""Phase 3-lite tests: SQLite-backed persistence for unified_queue.

Covers: enqueue persistence, dequeue deletion, restore-after-restart,
feature flag gating, corruption resilience.
"""
from __future__ import annotations

import os
import tempfile
import time

import pytest

from api import unified_queue as uq
from api import unified_queue_persist as uqp


@pytest.fixture
def temp_db(monkeypatch):
    """Fresh SQLite file per test + feature flag on."""
    with tempfile.NamedTemporaryFile(suffix=".sqlite", delete=False) as f:
        path = f.name
    monkeypatch.setenv("VL_UNIFIED_QUEUE", "1")
    monkeypatch.delenv("VL_UNIFIED_QUEUE_PERSIST_DISABLE", raising=False)
    monkeypatch.setattr(uqp, "DB_PATH", path)
    uq.reset_for_test()
    uqp.clear_all()
    yield path
    try:
        os.unlink(path)
    except OSError:
        pass


def test_enqueue_persists_item(temp_db):
    uq.enqueue("job-1", uq.PRIO_NORMAL)
    assert uqp.depth() == 1


def test_dequeue_removes_from_persistence(temp_db):
    uq.enqueue("job-a", uq.PRIO_NORMAL)
    assert uqp.depth() == 1
    item = uq.dequeue_for_provider(["Vast.ai"])
    assert item is not None and item.job_id == "job-a"
    assert uqp.depth() == 0


def test_restore_repopulates_heap_from_persistence(temp_db):
    """Simulate Railway restart: enqueue, clear in-memory, restore."""
    uq.enqueue("job-1", uq.PRIO_NORMAL)
    uq.enqueue("job-2", uq.PRIO_FAILOVER)
    uq.enqueue("job-3", uq.PRIO_LOW)
    assert uqp.depth() == 3

    # Simulate restart: clear in-memory heap but keep DB
    with uq._heap_lock:
        uq._heap.clear()
    assert uq.queue_depth() == 0

    restored = uq.restore_from_persistence()
    assert restored == 3
    assert uq.queue_depth() == 3

    # Priority order should be preserved: FAILOVER first
    item = uq.dequeue_for_provider(["Vast.ai"])
    assert item is not None and item.job_id == "job-2"


def test_retry_context_survives_restart(temp_db):
    uq.enqueue(
        "failover-job",
        uq.PRIO_FAILOVER,
        retry_context={
            "prior_provider": "Vast.ai",
            "checkpoint_step": 200,
            "migration_count": 1,
        },
    )
    with uq._heap_lock:
        uq._heap.clear()
    uq.restore_from_persistence()
    item = uq.dequeue_for_provider(["RunPod"])
    assert item is not None
    assert item.retry_context["prior_provider"] == "Vast.ai"
    assert item.retry_context["checkpoint_step"] == 200
    assert item.retry_context["migration_count"] == 1


def test_backoff_until_survives_restart(temp_db):
    uq.enqueue("delayed", uq.PRIO_NORMAL, backoff_seconds=60)
    with uq._heap_lock:
        uq._heap.clear()
    uq.restore_from_persistence()
    with uq._heap_lock:
        item = uq._heap[0]
    # backoff_until should be ~60s in the future
    assert item.backoff_until > time.time() + 50


def test_feature_flag_off_means_no_persistence(monkeypatch):
    """Unified queue disabled → no persistence."""
    with tempfile.NamedTemporaryFile(suffix=".sqlite", delete=False) as f:
        path = f.name
    try:
        monkeypatch.setattr(uqp, "DB_PATH", path)
        monkeypatch.setenv("VL_UNIFIED_QUEUE", "0")
        assert uqp.feature_enabled() is False
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def test_persist_disable_escape_hatch(monkeypatch):
    """Queue on but persistence explicitly disabled via escape hatch."""
    with tempfile.NamedTemporaryFile(suffix=".sqlite", delete=False) as f:
        path = f.name
    try:
        monkeypatch.setattr(uqp, "DB_PATH", path)
        monkeypatch.setenv("VL_UNIFIED_QUEUE", "1")
        monkeypatch.setenv("VL_UNIFIED_QUEUE_PERSIST_DISABLE", "1")
        assert uqp.feature_enabled() is False
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def test_upsert_same_job_id_replaces(temp_db):
    """Re-enqueuing same job_id should update, not duplicate."""
    uq.enqueue("job-same", uq.PRIO_NORMAL)
    uq.enqueue("job-same", uq.PRIO_FAILOVER)  # upgraded priority
    assert uqp.depth() == 1  # persistence has single row


def test_restore_is_idempotent_returns_zero_when_heap_empty(temp_db):
    # Restore on empty persistence returns 0
    assert uq.restore_from_persistence() == 0


def test_restore_with_flag_off_returns_zero(monkeypatch):
    with tempfile.NamedTemporaryFile(suffix=".sqlite", delete=False) as f:
        path = f.name
    try:
        monkeypatch.setattr(uqp, "DB_PATH", path)
        monkeypatch.setenv("VL_UNIFIED_QUEUE", "0")
        assert uq.restore_from_persistence() == 0
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def test_clear_all_removes_everything(temp_db):
    uq.enqueue("j1", uq.PRIO_NORMAL)
    uq.enqueue("j2", uq.PRIO_FAILOVER)
    assert uqp.depth() == 2
    uqp.clear_all()
    assert uqp.depth() == 0


def test_schema_idempotent(temp_db):
    """_ensure_schema should be safe to call repeatedly."""
    uqp._ensure_schema()
    uqp._ensure_schema()
    uq.enqueue("j", uq.PRIO_NORMAL)
    assert uqp.depth() == 1
