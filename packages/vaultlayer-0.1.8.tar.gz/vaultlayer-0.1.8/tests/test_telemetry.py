"""
VaultLayer -- Telemetry System Tests
Validates the TelemetryCollector for both bug tracking and decision-support metrics.
Run: pytest tests/test_telemetry.py -v
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../', 'src'))

import pytest
import asyncio
import time
from unittest.mock import MagicMock, patch, AsyncMock
from conftest import MockAgentQueue, make_job


# ============================================================
# Fixtures
# ============================================================

@pytest.fixture
def tel(mock_queue):
    from shared.telemetry import make_telemetry
    return make_telemetry(queue=mock_queue, agent_name="test_agent", enabled=True)

@pytest.fixture
def noop_tel():
    from shared.telemetry import make_telemetry
    return make_telemetry(enabled=False)


# ============================================================
# T1: Core metric types emit without raising
# ============================================================

def test_tel_counter_does_not_raise(tel):
    """counter() must never raise -- telemetry is fire-and-forget."""
    tel.counter("test.counter", value=1.0, tags={"component": "broker"})

def test_tel_gauge_does_not_raise(tel):
    """gauge() must never raise."""
    tel.gauge("job.step_rate", 12.4, unit="steps/min", tags={"gpu": "H100"})

def test_tel_timing_does_not_raise(tel):
    """timing() must never raise."""
    tel.timing("checkpoint.duration_ms", 4200.0, tags={"provider": "lambda_labs"})

def test_tel_error_does_not_raise(tel):
    """error() must never raise even with a real exception."""
    try:
        raise ValueError("test provision failure")
    except ValueError as e:
        tel.error("provision.failed", exc=e, tags={"provider": "aws"})

def test_tel_event_does_not_raise(tel):
    """event() must never raise."""
    from shared.telemetry import MetricCategory
    tel.event("job.started", tags={"gpu": "H100"}, category=MetricCategory.JOB)


# ============================================================
# T2: Timer context manager
# ============================================================

def test_tel_timer_measures_duration(tel):
    """Timer context manager must measure elapsed time accurately."""
    with tel.timer("test.operation") as t:
        time.sleep(0.05)  # 50ms
    # Check that a timing metric was buffered
    assert len(tel._buffer) >= 1
    timed = [m for m in tel._buffer if m.name == "test.operation"]
    assert timed, "Timer did not emit a timing metric"
    assert timed[-1].value >= 40, f"Measured {timed[-1].value:.1f}ms, expected ~50ms"

def test_tel_timer_works_as_context_manager_with_exception(tel):
    """Timer must still emit metric even if the block raises."""
    try:
        with tel.timer("test.failing_op"):
            raise RuntimeError("intentional")
    except RuntimeError:
        pass
    timed = [m for m in tel._buffer if m.name == "test.failing_op"]
    assert timed, "Timer must emit metric even on exception"


# ============================================================
# T3: Decision tracking
# ============================================================

def test_tel_decision_records_action_and_confidence(tel):
    """decision() must record action, confidence, and outcome in buffer."""
    tel.decision(
        action="migrate",
        confidence=0.91,
        outcome="executed",
        savings_usd=42.50,
        job_id="test-job-001",
        tags={"tier": "auto"},
    )
    decisions = [m for m in tel._buffer if m.name == "orchestration.decision"]
    assert decisions, "Decision not recorded in buffer"
    d = decisions[0]
    assert d.value == 0.91
    assert d.tags.get("action") == "migrate"
    assert d.tags.get("outcome") == "executed"
    assert d.tags.get("savings_usd") == "42.5"


# ============================================================
# T4: Error tracking
# ============================================================

def test_tel_error_captures_message(tel):
    """error() must capture exception message in the metric."""
    tel.error("broker.provision_failed",
              message="CoreWeave API timeout after 30s",
              tags={"provider": "coreweave"})
    errors = [m for m in tel._buffer if m.name == "broker.provision_failed"]
    assert errors, "Error not buffered"
    assert "CoreWeave" in errors[0].error

def test_tel_error_captures_traceback(tel):
    """error() must include stack trace when given a real exception."""
    try:
        raise ConnectionError("Redis connection refused")
    except ConnectionError as e:
        tel.error("queue.connect_failed", exc=e)
    errors = [m for m in tel._buffer if m.name == "queue.connect_failed"]
    assert errors
    # trace may be None if not in exc context, but error string should be set
    assert errors[0].error is not None


# ============================================================
# T5: NoOp collector
# ============================================================

def test_noop_tel_all_methods_silent(noop_tel):
    """NoOp collector must accept all calls without raising -- safe for test environments."""
    noop_tel.counter("x", 1)
    noop_tel.gauge("y", 2.0)
    noop_tel.timing("z", 100.0)
    noop_tel.error("e", message="test")
    noop_tel.event("ev")
    noop_tel.decision("migrate", 0.9, "executed")
    with noop_tel.timer("t"):
        pass

@pytest.mark.asyncio
async def test_noop_tel_async_methods_silent(noop_tel):
    """NoOp async methods must also be safe."""
    await noop_tel.flush_now()
    summary = await noop_tel.get_summary()
    assert summary == {}


# ============================================================
# T6: Metric to_dict structure
# ============================================================

def test_metric_to_dict_has_required_fields(tel):
    """Every emitted metric must have name, category, type, value, timestamp."""
    tel.counter("broker.migrations", value=1, tags={"provider": "aws"}, job_id="j-001")
    m = tel._buffer[-1]
    d = m.to_dict()
    assert "name" in d
    assert "category" in d
    assert "metric_type" in d
    assert "value" in d
    assert "timestamp" in d
    assert d["name"] == "broker.migrations"
    assert d["value"] == 1.0
    assert d["job_id"] == "j-001"


# ============================================================
# T7: Buffer accumulates metrics
# ============================================================

def test_tel_buffer_accumulates(tel):
    """Multiple emissions must accumulate in buffer before flush."""
    initial = len(tel._buffer)
    tel.counter("a")
    tel.gauge("b", 1.0)
    tel.timing("c", 50.0)
    assert len(tel._buffer) == initial + 3, "Buffer must hold all emitted metrics"