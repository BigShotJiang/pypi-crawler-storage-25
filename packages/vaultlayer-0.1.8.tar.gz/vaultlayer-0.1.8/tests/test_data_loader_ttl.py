"""Regression tests for the data_loader cache TTL.

Root cause of 2026-04-21 prod outage: in-process `_cache` in data_loader.py
never expired, so Railway workers that happened to load config at a bad
moment stayed wrong forever. Lambda Labs intermittently rejected with
"not_in_included_providers" on half of submissions. Fixed by adding a 60s
TTL.

These tests pin the invariants:
  * Cache re-reads after TTL expiry
  * Cache is hit within TTL window
  * TTL is configurable via env var
"""
from __future__ import annotations

import sys
import os
import json
import pathlib
import tempfile
import time as _time_module
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def _reset_cache() -> None:
    import shared.data_loader as dl
    dl._cache = None
    dl._cache_loaded_at = 0.0


import pytest

@pytest.fixture(autouse=True)
def _restore_data_loader_cache():
    """Reset data_loader cache before and after each test to prevent contamination."""
    _reset_cache()
    yield
    _reset_cache()


def test_cache_reread_after_ttl_expiry():
    """If TTL has passed, _load() re-reads the file."""
    import shared.data_loader as dl

    _reset_cache()
    with tempfile.TemporaryDirectory() as tmpdir:
        path = pathlib.Path(tmpdir) / "vaultlayer_data.json"
        initial = {"_meta": {"last_updated": "v1"}, "provider_prices": {"A": 1}}
        path.write_text(json.dumps(initial))

        with patch.object(dl, "_POSSIBLE_PATHS", [path]):
            with patch.object(dl, "_CACHE_TTL_SECONDS", 1):
                # First load.
                d1 = dl._load()
                assert d1["_meta"]["last_updated"] == "v1"

                # Rewrite config mid-flight (simulating a deploy that rolled the file).
                updated = {"_meta": {"last_updated": "v2"}, "provider_prices": {"A": 2}}
                path.write_text(json.dumps(updated))

                # Still within TTL: cached v1 served.
                d2 = dl._load()
                assert d2["_meta"]["last_updated"] == "v1", \
                    "within-TTL call must hit cache, not reload"

                # Past TTL: must re-read.
                with patch.object(dl, "_cache_loaded_at", _time_module.time() - 5):
                    d3 = dl._load()
                    assert d3["_meta"]["last_updated"] == "v2", \
                        "after-TTL call must re-read from disk"


def test_ttl_env_var_override():
    """VL_DATA_CACHE_TTL_SECONDS env var overrides the default 60s."""
    # The module reads this at import time, so test by patching the constant directly.
    import shared.data_loader as dl
    assert dl._CACHE_TTL_SECONDS >= 1, \
        "TTL must be a positive number; 0 would disable caching entirely"
    # Not-too-long default: 60s is the target; tolerate 30-300 as reasonable.
    assert 10 <= dl._CACHE_TTL_SECONDS <= 600, \
        f"TTL {dl._CACHE_TTL_SECONDS}s is outside the sensible 10-600s range"


def test_cache_hit_within_ttl_does_not_reread():
    """Fast path: consecutive calls within TTL don't touch disk."""
    import shared.data_loader as dl

    _reset_cache()
    with tempfile.TemporaryDirectory() as tmpdir:
        path = pathlib.Path(tmpdir) / "vaultlayer_data.json"
        path.write_text(json.dumps({"_meta": {"last_updated": "v1"}, "provider_prices": {}}))

        read_count = {"n": 0}
        orig_open = open

        def counting_open(*args, **kwargs):
            if args and str(args[0]) == str(path):
                read_count["n"] += 1
            return orig_open(*args, **kwargs)

        with patch.object(dl, "_POSSIBLE_PATHS", [path]):
            with patch("builtins.open", counting_open):
                with patch.object(dl, "_CACHE_TTL_SECONDS", 60):
                    dl._load(); dl._load(); dl._load()
                    assert read_count["n"] == 1, \
                        f"expected 1 disk read within TTL, got {read_count['n']}"


def test_empty_fallback_does_not_pin_permanently():
    """If the config file is briefly absent (mid-deploy), the empty fallback
    MUST be retried at the next TTL tick — not cached forever."""
    import shared.data_loader as dl

    _reset_cache()
    # No file exists yet → empty fallback.
    with patch.object(dl, "_POSSIBLE_PATHS", [pathlib.Path("/nonexistent/vaultlayer_data.json")]):
        with patch.object(dl, "_CACHE_TTL_SECONDS", 1):
            d1 = dl._load()
            # Empty fallback.
            assert d1.get("provider_prices") == {}, "empty fallback expected"

    # Now config appears.
    _reset_cache()
    with tempfile.TemporaryDirectory() as tmpdir:
        path = pathlib.Path(tmpdir) / "vaultlayer_data.json"
        path.write_text(json.dumps({"_meta": {"last_updated": "recovered"}, "provider_prices": {"A": 1}}))
        with patch.object(dl, "_POSSIBLE_PATHS", [path]):
            with patch.object(dl, "_CACHE_TTL_SECONDS", 1):
                d2 = dl._load()
                assert d2["_meta"]["last_updated"] == "recovered"
