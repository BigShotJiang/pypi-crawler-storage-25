"""Tests for _handle_provision_result.

Covers two concerns in one file:

1. **Cross-job contamination (fixed 2026-04-21).** _handle_provision_result
   used to fall back to `_worker_debug["last_provision_attempts"]` when the
   per-job list was empty. Under concurrent provisioning, the shared global
   was last-written-by-any-job, so a failing job whose own attempts list was
   empty would surface a sibling's errors as if they were its own. Concretely
   seen on job 7f680ee3 on 2026-04-20: failed with "GCP: unknown" even
   though it never targeted GCP. Fix: read attempts ONLY from the per-job
   dict. The tests below assert the contamination CANNOT re-appear.

2. **Backoff + retry for no-capacity failures (fixed 2026-04-22).** Before,
   preferred_providers=set jobs died on the first capacity failure (losing
   every user job during a transient drought like today's AWS V100 shortage),
   and empty-preferred jobs retried every 3s forever. Now both branches
   share backoff+retry gated by shared.failure_codes.is_retryable().
"""
from __future__ import annotations

import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def _reset_worker_debug() -> None:
    from api import job_worker
    job_worker._worker_debug["last_provision_attempts"] = []


def _stub_sync(monkeypatch=None):
    """Neutralize DB + email side effects — tests run without Supabase."""
    import api.job_worker as _jw
    _jw._sync_job_status = lambda *a, **kw: None
    _jw._record_provision_to_db = lambda *a, **kw: None


# ── Cross-contamination: core invariant ───────────────────────────────────

def test_preferred_all_failed_ignores_sibling_debug_state():
    """Even if _worker_debug is contaminated by a concurrent job, the
    failing job MUST surface its own attempts, never the sibling's."""
    from api.job_worker import _handle_provision_result, _worker_debug

    _reset_worker_debug()
    _stub_sync()
    _worker_debug["last_provision_attempts"] = [
        {"provider": "GCP", "error": "QUOTA_EXCEEDED: GPUS_ALL_REGIONS"},
    ]

    job = {
        "preferred_providers": ["Vast.ai"],
        "_provision_attempts": [],  # empty — the bug trigger
    }
    result = _handle_provision_result(
        job=job, job_id="test-1234", instance_id=None, pref_label="Vast.ai",
    )
    # New contract: capacity failures requeue with backoff, not fail instantly.
    # Either way the error must NOT leak the sibling job's detail.
    assert result == "requeue"
    err = job.get("error") or ""
    assert "GCP" not in err, f"cross-contamination: {err}"
    assert "QUOTA_EXCEEDED" not in err


def test_preferred_all_failed_uses_own_attempts_when_present():
    """The real per-job attempts list — when populated — IS used."""
    from api.job_worker import _handle_provision_result

    _reset_worker_debug()
    _stub_sync()
    job = {
        "preferred_providers": ["Vast.ai", "RunPod"],
        "_provision_attempts": [
            {"provider": "Vast.ai", "error": "bid rejected"},
            {"provider": "RunPod",  "error": "no offers for RTX4090"},
        ],
    }
    result = _handle_provision_result(
        job=job, job_id="test-5678", instance_id=None,
        pref_label="Vast.ai,RunPod",
    )
    # Retryable → requeue (capacity shortage is the default assumption).
    assert result == "requeue"
    # Last attempt's error still surfaces so the UI shows why the job is waiting.
    assert "no offers for RTX4090" in (job.get("error") or "")


def test_resume_leg_ignores_sibling_debug_state():
    """Resume leg with no capacity is still terminal (with email) — separate
    code path from the backoff+retry above."""
    from api.job_worker import _handle_provision_result, _worker_debug

    _reset_worker_debug()
    _stub_sync()
    _worker_debug["last_provision_attempts"] = [
        {"provider": "Lambda Labs", "error": "insufficient-capacity"},
    ]

    job = {
        "_is_resume_leg": True,
        "preferred_providers": ["Vast.ai"],
        "_provision_attempts": [],  # empty
        "_run_id": "run-9999",
        "user_email": "t@test.com",
    }
    from unittest.mock import patch
    with patch("shared.email.send_cancel_email"):
        result = _handle_provision_result(
            job=job, job_id="test-resume", instance_id=None,
            pref_label="Vast.ai",
        )

    assert result == "cancelled_resume"
    err = job.get("error") or ""
    assert "Lambda" not in err, f"cross-contamination: {err}"
    assert "insufficient-capacity" not in err


def test_running_result_clears_retry_state():
    """Happy path: instance_id set → running, and any prior retry
    bookkeeping from a pre-success failure gets cleared so a future
    death on this leg starts with a fresh budget."""
    from api.job_worker import _handle_provision_result

    _reset_worker_debug()
    _stub_sync()
    job = {
        "preferred_providers": ["Vast.ai"],
        "_provision_retry_count": 2,
        "_first_provision_failure_at": time.time() - 300,
        "_next_retry_at": time.time() + 60,
    }
    result = _handle_provision_result(
        job=job, job_id="test-happy", instance_id="inst-abc",
        pref_label="Vast.ai",
    )
    assert result == "running"
    assert job["instance_id"] == "inst-abc"
    assert job["status"] == "running"
    # Critical: leftover retry state must not bleed into the post-success world.
    assert "_provision_retry_count" not in job
    assert "_first_provision_failure_at" not in job
    assert "_next_retry_at" not in job


# ── Backoff + retry: the new contract ─────────────────────────────────────

def test_retryable_failure_requeues_instead_of_failing():
    """preferred_providers=set + no capacity used to mark status=failed on
    first try, killing every user job during a transient drought. Now it
    requeues with a backoff window."""
    from api.job_worker import _handle_provision_result

    _reset_worker_debug()
    _stub_sync()
    job = {
        "preferred_providers": ["AWS Spot"],
        "_provision_attempts": [
            {"provider": "AWS Spot", "error": "InsufficientInstanceCapacity"},
        ],
    }
    result = _handle_provision_result(
        job=job, job_id="test-retry", instance_id=None, pref_label="AWS Spot",
    )
    assert result == "requeue"
    assert job["status"] == "queued"
    assert job["_provision_retry_count"] == 1
    assert job["_first_provision_failure_at"] is not None
    assert job["_next_retry_at"] > time.time()  # scheduled in the future


def test_retry_backoff_schedule_grows():
    """Successive retries consume later slots in the backoff schedule
    (30s → 2m → 10m → 30m → stays at 30m). Validates the clamp logic
    so a day-long drought doesn't overflow the schedule."""
    from api.job_worker import (
        _handle_provision_result,
        _PROVISION_BACKOFF_SCHEDULE,
    )

    _reset_worker_debug()
    _stub_sync()
    delays = []
    job = {
        "preferred_providers": ["AWS Spot"],
        "_provision_attempts": [{"provider": "AWS Spot", "error": "capacity"}],
    }
    for i in range(len(_PROVISION_BACKOFF_SCHEDULE) + 2):
        now = time.time()
        _handle_provision_result(
            job=job, job_id=f"test-{i}", instance_id=None, pref_label="AWS Spot",
        )
        delays.append(round(job["_next_retry_at"] - now))
        # Mimic caller clearing the "can-retry-now" gate so the next call
        # schedules a fresh delay rather than being deduped.
        job["_next_retry_at"] = 0

    # First 4 delays match the schedule; anything after clamps to last bucket.
    for i, expected in enumerate(_PROVISION_BACKOFF_SCHEDULE):
        assert abs(delays[i] - expected) <= 1, f"delays={delays}"
    for delay in delays[len(_PROVISION_BACKOFF_SCHEDULE):]:
        assert abs(delay - _PROVISION_BACKOFF_SCHEDULE[-1]) <= 1


def test_retry_budget_exhaustion_fails_terminally():
    """After _PROVISION_MAX_TOTAL_SECONDS elapsed, the job must flip to
    status=failed with PROV_NO_CAPACITY — preserving the last error so
    the dashboard shows why the drought finally beat us."""
    from api.job_worker import (
        _handle_provision_result,
        _PROVISION_MAX_TOTAL_SECONDS,
    )

    _reset_worker_debug()
    _stub_sync()
    # Simulate a job that's been retrying for longer than the cap.
    job = {
        "preferred_providers": ["AWS Spot"],
        "_provision_attempts": [
            {"provider": "AWS Spot", "error": "InsufficientInstanceCapacity"},
        ],
        "_provision_retry_count": 7,
        "_first_provision_failure_at": time.time() - _PROVISION_MAX_TOTAL_SECONDS - 60,
    }
    result = _handle_provision_result(
        job=job, job_id="test-budget", instance_id=None, pref_label="AWS Spot",
    )
    assert result == "failed"
    assert job["status"] == "failed"
    assert job.get("failure_code") == "prov_no_capacity"
    err = job.get("error") or ""
    assert "InsufficientInstanceCapacity" in err
    assert "no capacity after" in err


def test_non_retryable_failure_fails_immediately():
    """Auth / schema-reject failures don't clear by waiting, so they
    must short-circuit the backoff path and go straight to failed."""
    from api.job_worker import _handle_provision_result

    _reset_worker_debug()
    _stub_sync()
    job = {
        "preferred_providers": ["AWS Spot"],
        "_provision_attempts": [
            {"provider": "AWS Spot", "error": "AuthFailure: bad creds"},
        ],
        "failure_code": "prov_auth_bad",  # the provider classified it as auth
    }
    result = _handle_provision_result(
        job=job, job_id="test-auth", instance_id=None, pref_label="AWS Spot",
    )
    assert result == "failed"
    assert job["status"] == "failed"
    assert "_next_retry_at" not in job or job.get("_next_retry_at") is None
    # Non-retryable shouldn't bump the retry counter — we didn't retry.
    assert job.get("_provision_retry_count", 0) == 0


def test_empty_preferred_also_gets_backoff_not_hammer():
    """Empty preferred_providers used to requeue every 3s forever — now it
    goes through the same backoff path so a multi-hour drought doesn't
    burn millions of provider API calls."""
    from api.job_worker import _handle_provision_result

    _reset_worker_debug()
    _stub_sync()
    job = {
        "preferred_providers": [],  # no preference — try anything
        "_provision_attempts": [
            {"provider": "AWS Spot",     "error": "no capacity"},
            {"provider": "Lambda Labs",  "error": "no offers"},
        ],
    }
    result = _handle_provision_result(
        job=job, job_id="test-empty", instance_id=None, pref_label="auto",
    )
    assert result == "requeue"
    assert job["status"] == "queued"
    assert job["_next_retry_at"] > time.time()
    assert job["_provision_retry_count"] == 1


# ── BFS GPU-type walk tests ───────────────────────────────────────────────────

def test_bfs_walk_triggers_after_threshold_and_switches_gpu():
    """When gpu_auto_selected=True and retry count >= BFS trigger threshold,
    _handle_provision_result should switch to the next GPU in the chain
    and return 'requeue' with a reset retry counter."""
    from api.job_worker import _handle_provision_result, _PROVISION_BFS_TRIGGER_COUNT

    _reset_worker_debug()
    _stub_sync()
    job = {
        "preferred_providers": [],
        "gpu_type": "A100_40GB",
        "gpu_auto_selected": True,
        "min_vram_gb": 20.0,  # A10G (24GB) passes this floor
        "_provision_retry_count": _PROVISION_BFS_TRIGGER_COUNT,  # threshold hit
        "_first_provision_failure_at": time.time() - 200,
        "_provision_attempts": [{"provider": "Lambda Labs", "error": "no capacity"}],
    }
    result = _handle_provision_result(
        job=job, job_id="test-bfs", instance_id=None, pref_label="auto",
    )
    assert result == "requeue"
    # GPU type must have changed to a fallback
    assert job["gpu_type"] != "A100_40GB"
    # Retry counter resets so new GPU gets its own full backoff budget
    assert job["_provision_retry_count"] == 0
    # Original GPU recorded in the tried set
    assert "A100_40GB" in job["_bfs_tried_gpus"]


def test_bfs_walk_respects_vram_floor():
    """BFS skips GPUs with insufficient VRAM and picks the next suitable one."""
    from api.job_worker import _handle_provision_result, _PROVISION_BFS_TRIGGER_COUNT, _JW_GPU_VRAM_GB

    _reset_worker_debug()
    _stub_sync()
    # A100_40GB chain: A100_80GB_SXM (80GB), A10G (24GB), A40 (48GB), L40S (48GB)
    # With a 40GB floor, A10G (24GB) should be skipped
    job = {
        "preferred_providers": [],
        "gpu_type": "A100_40GB",
        "gpu_auto_selected": True,
        "min_vram_gb": 40.0,
        "_provision_retry_count": _PROVISION_BFS_TRIGGER_COUNT,
        "_first_provision_failure_at": time.time() - 200,
        "_provision_attempts": [{"provider": "RunPod", "error": "no capacity"}],
        # Pre-populate tried set so only A10G is next in chain (skipped by VRAM)
        "_bfs_tried_gpus": {"A100_40GB", "A100_80GB_SXM"},
    }
    result = _handle_provision_result(
        job=job, job_id="test-bfs-vram", instance_id=None, pref_label="auto",
    )
    assert result == "requeue"
    selected = job["gpu_type"]
    assert selected != "A10G", "A10G (24GB) should be skipped by 40GB VRAM floor"
    assert _JW_GPU_VRAM_GB.get(selected, 0) >= 40.0


def test_bfs_walk_does_not_trigger_for_resume_legs():
    """Resume legs are not eligible for BFS GPU switching — they target a
    specific GPU for checkpoint restoration."""
    from api.job_worker import _handle_provision_result, _PROVISION_BFS_TRIGGER_COUNT

    _reset_worker_debug()
    _stub_sync()
    job = {
        "preferred_providers": [],
        "gpu_type": "A100_40GB",
        "gpu_auto_selected": True,
        "min_vram_gb": 20.0,
        "_is_resume_leg": True,   # resume leg — BFS must not apply
        "_provision_retry_count": _PROVISION_BFS_TRIGGER_COUNT,
        "_first_provision_failure_at": time.time() - 200,
        "_provision_attempts": [],
        "_run_id": "run-xyz",
        "user_email": "",
    }
    from unittest.mock import patch
    with patch("shared.email.send_cancel_email"):
        result = _handle_provision_result(
            job=job, job_id="test-resume-bfs", instance_id=None, pref_label="auto",
        )
    # Resume legs go to cancelled_resume, not BFS requeue
    assert result == "cancelled_resume"
    assert job["gpu_type"] == "A100_40GB"  # unchanged


def test_bfs_walk_skips_when_not_auto_selected():
    """User-specified GPUs (gpu_auto_selected=False) do not BFS — the hop
    target was already chosen by the user at CLI submission time."""
    from api.job_worker import _handle_provision_result, _PROVISION_BFS_TRIGGER_COUNT

    _reset_worker_debug()
    _stub_sync()
    job = {
        "preferred_providers": [],
        "gpu_type": "H100_80GB_SXM",
        "gpu_auto_selected": False,   # user specified this GPU explicitly
        "min_vram_gb": 20.0,
        "_provision_retry_count": _PROVISION_BFS_TRIGGER_COUNT,
        "_first_provision_failure_at": time.time() - 200,
        "_provision_attempts": [{"provider": "Vast.ai", "error": "no capacity"}],
    }
    result = _handle_provision_result(
        job=job, job_id="test-no-bfs", instance_id=None, pref_label="auto",
    )
    # Falls through to standard backoff, NOT BFS
    assert result == "requeue"
    assert job["gpu_type"] == "H100_80GB_SXM"  # unchanged
    assert "_bfs_tried_gpus" not in job


def test_bfs_walk_exhausts_chain_falls_back_to_backoff():
    """When every chain alternative has already been tried, BFS is skipped
    and the job falls back to the standard exponential backoff path."""
    from api.job_worker import _handle_provision_result, _PROVISION_BFS_TRIGGER_COUNT, _JW_FALLBACK_CHAIN

    _reset_worker_debug()
    _stub_sync()
    # Mark ALL chain members as tried
    gpu = "A100_40GB"
    all_tried = {gpu} | set(_JW_FALLBACK_CHAIN.get(gpu, []))
    job = {
        "preferred_providers": [],
        "gpu_type": gpu,
        "gpu_auto_selected": True,
        "min_vram_gb": 0.0,
        "_bfs_tried_gpus": all_tried,
        "_provision_retry_count": _PROVISION_BFS_TRIGGER_COUNT,
        "_first_provision_failure_at": time.time() - 200,
        "_provision_attempts": [{"provider": "RunPod", "error": "no capacity"}],
    }
    result = _handle_provision_result(
        job=job, job_id="test-bfs-exhaust", instance_id=None, pref_label="auto",
    )
    # Falls back to standard backoff (not BFS), so still requeue but same GPU
    assert result == "requeue"
    assert job["gpu_type"] == gpu  # unchanged — no BFS candidate
