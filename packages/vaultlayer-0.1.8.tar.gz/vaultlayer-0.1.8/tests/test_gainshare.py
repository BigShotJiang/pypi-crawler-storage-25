"""
VaultLayer — Gainshare Pricing Tests

Verifies the dynamic gainshare model:
  Standard Rule  (savings > 25% of baseline): VL takes 40% of spread
  Fallback Rule  (savings ≤ 25% of baseline): VL takes 50% of spread
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from shared.price_guard import (
    gainshare_fee,
    compute_user_charge,
    get_baseline_anchor,
    MarginViolation,
    GAINSHARE_STANDARD_PCT,
    GAINSHARE_FALLBACK_PCT,
    GAINSHARE_THRESHOLD_PCT,
)


# ── Scenario 1: AWS Defector (Standard Rule) ──────────────────────────────────

def test_aws_defector_standard_rule():
    """
    AWS H100 $3.93 → spot $2.00: savings $1.93 > 25% of $3.93 ($0.98)
    → Standard Rule: VL fee = $1.93 × 0.40 = $0.772
    → User billed: $2.00 + $0.772 = $2.772
    """
    baseline = 3.93
    sourced  = 2.00
    fee, billed, rule = gainshare_fee(baseline, sourced)

    assert rule == "standard"
    assert abs(fee - 0.772) < 0.001
    assert abs(billed - 2.772) < 0.001


def test_aws_defector_user_saves():
    """User must save money vs their AWS baseline."""
    baseline = 3.93
    sourced  = 2.00
    _, billed, _ = gainshare_fee(baseline, sourced)
    assert billed < baseline
    savings_pct = (baseline - billed) / baseline * 100
    assert savings_pct > 25  # user saves ~30%


# ── Scenario 2: Lambda Labs Defector (Fallback Rule) ─────────────────────────

def test_lambda_defector_fallback_rule():
    """
    Lambda H100 $2.99 → spot $2.30: savings $0.69 ≤ 25% of $2.99 ($0.7475)
    → Fallback Rule: VL fee = $0.69 × 0.50 = $0.345
    → User billed: $2.30 + $0.345 = $2.645
    """
    baseline = 2.99
    sourced  = 2.30
    fee, billed, rule = gainshare_fee(baseline, sourced)

    assert rule == "fallback"
    assert abs(fee - 0.345) < 0.001
    assert abs(billed - 2.645) < 0.001


def test_lambda_defector_user_saves():
    """User must save money vs their Lambda baseline in tight market."""
    baseline = 2.99
    sourced  = 2.30
    _, billed, _ = gainshare_fee(baseline, sourced)
    assert billed < baseline
    savings_pct = (baseline - billed) / baseline * 100
    assert abs(savings_pct - 11.5) < 0.5  # ~11.5% savings


# ── Threshold boundary ────────────────────────────────────────────────────────

def test_exactly_at_threshold_uses_fallback():
    """Savings exactly equal to 25% of baseline → Fallback (not standard)."""
    baseline = 4.00
    threshold_savings = baseline * GAINSHARE_THRESHOLD_PCT  # exactly 1.00
    sourced = baseline - threshold_savings  # 3.00
    _, _, rule = gainshare_fee(baseline, sourced)
    assert rule == "fallback"


def test_just_above_threshold_uses_standard():
    """Savings just above 25% of baseline → Standard Rule."""
    baseline = 4.00
    sourced  = baseline - (baseline * GAINSHARE_THRESHOLD_PCT) - 0.01  # savings = 1.01
    _, _, rule = gainshare_fee(baseline, sourced)
    assert rule == "standard"


# ── VL always takes correct percentage ───────────────────────────────────────

def test_standard_rule_vl_takes_40_pct():
    """VL fee must be exactly 40% of the savings spread (standard rule)."""
    baseline, sourced = 5.00, 2.00
    savings = baseline - sourced  # $3.00 > 25% of $5.00 ($1.25)
    fee, _, rule = gainshare_fee(baseline, sourced)
    assert rule == "standard"
    assert abs(fee / savings - GAINSHARE_STANDARD_PCT) < 0.0001


def test_fallback_rule_vl_takes_50_pct():
    """VL fee must be exactly 50% of the savings spread (fallback rule)."""
    baseline, sourced = 3.00, 2.80  # savings = 0.20, threshold = 0.75
    savings = baseline - sourced
    fee, _, rule = gainshare_fee(baseline, sourced)
    assert rule == "fallback"
    assert abs(fee / savings - GAINSHARE_FALLBACK_PCT) < 0.0001


# ── User always saves money ───────────────────────────────────────────────────

def test_user_always_pays_less_than_baseline():
    """In all market conditions, user_billed < baseline_anchor."""
    scenarios = [
        (3.93, 2.00),   # AWS defector, wide spread
        (2.99, 2.30),   # Lambda, tight spread
        (4.00, 3.80),   # Very tight: savings = 0.20
        (10.00, 1.00),  # Very wide spread
    ]
    for baseline, sourced in scenarios:
        _, billed, _ = gainshare_fee(baseline, sourced)
        assert billed < baseline, f"User should save: baseline={baseline}, billed={billed}"


# ── Error cases ───────────────────────────────────────────────────────────────

def test_no_savings_raises_margin_violation():
    """If sourced cost >= baseline, raise MarginViolation."""
    with pytest.raises(MarginViolation):
        gainshare_fee(baseline_anchor=2.00, sourced_cost=2.50)


def test_equal_prices_raises_margin_violation():
    with pytest.raises(MarginViolation):
        gainshare_fee(baseline_anchor=3.00, sourced_cost=3.00)


def test_invalid_sourced_cost_raises():
    with pytest.raises(ValueError):
        gainshare_fee(baseline_anchor=3.00, sourced_cost=0)


def test_invalid_baseline_raises():
    with pytest.raises(ValueError):
        gainshare_fee(baseline_anchor=0, sourced_cost=2.00)


# ── compute_user_charge convenience wrapper ───────────────────────────────────

def test_compute_user_charge_aws_h100():
    """compute_user_charge returns full breakdown for AWS H100."""
    result = compute_user_charge("AWS", "H100_80GB_SXM", sourced_cost_per_hr=2.00)
    assert result["rule"] in ("standard", "fallback")
    assert result["user_billed_rate"] < result["baseline_anchor"]
    assert result["user_savings"] > 0
    assert result["vl_fee"] > 0
    assert "user_savings_pct" in result


def test_compute_user_charge_no_savings_fallback():
    """When sourced >= baseline, compute_user_charge returns no_savings (no exception)."""
    # Force sourced cost above anchor
    result = compute_user_charge("AWS", "H100_80GB_SXM",
                                 sourced_cost_per_hr=10.00,
                                 baseline_anchor=3.93)
    assert result["rule"] == "no_savings"
    assert result["vl_fee"] == 0.0
    assert result["user_savings"] == 0.0


# ── Baseline anchor lookup ────────────────────────────────────────────────────

def test_get_baseline_anchor_aws_h100():
    anchor = get_baseline_anchor("AWS", "H100_80GB_SXM")
    assert anchor == pytest.approx(3.93)


def test_get_baseline_anchor_lambda_h100():
    anchor = get_baseline_anchor("Lambda Labs", "H100_80GB_SXM")
    assert anchor == pytest.approx(2.99)


def test_get_baseline_anchor_normalises_provider_name():
    """'lambda_labs' (underscore) should resolve same as 'Lambda Labs'."""
    anchor = get_baseline_anchor("lambda_labs", "H100")
    assert anchor == pytest.approx(2.99)


def test_get_baseline_anchor_unknown_provider_returns_default():
    from shared.price_guard import _DEFAULT_ANCHOR
    anchor = get_baseline_anchor("SomeUnknownCloud", "H100")
    assert anchor == _DEFAULT_ANCHOR


# ── Reproducibility of scenario numbers ──────────────────────────────────────

def test_scenario_1_exact_numbers():
    """Reproduce Scenario 1 table exactly."""
    fee, billed, rule = gainshare_fee(3.93, 2.00)
    assert rule == "standard"
    assert abs(fee - 0.772) < 0.001         # $0.77/hr VL fee
    assert abs(billed - 2.772) < 0.001      # $2.77/hr user billed
    user_savings = 3.93 - billed
    assert abs(user_savings - 1.158) < 0.01 # $1.16/hr saved
    savings_pct = user_savings / 3.93 * 100
    assert abs(savings_pct - 29.5) < 1      # ~30% off AWS


def test_scenario_2_exact_numbers():
    """Reproduce Scenario 2 table exactly."""
    fee, billed, rule = gainshare_fee(2.99, 2.30)
    assert rule == "fallback"
    assert abs(fee - 0.345) < 0.001         # $0.345/hr VL fee
    assert abs(billed - 2.645) < 0.001      # $2.645/hr user billed
    user_savings = 2.99 - billed
    assert abs(user_savings - 0.345) < 0.001 # $0.345/hr saved
    savings_pct = user_savings / 2.99 * 100
    assert abs(savings_pct - 11.5) < 0.5    # 11.5% off Lambda
