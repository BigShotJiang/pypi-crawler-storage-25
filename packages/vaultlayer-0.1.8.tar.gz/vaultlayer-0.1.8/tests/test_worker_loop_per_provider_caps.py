"""Phase 1c tests: _worker_loop respects per-provider caps from
unified_queue when VL_UNIFIED_QUEUE=1.

Doesn't test the full event loop — isolates the per-cycle decision
logic. If the job's preferred providers are all at their cap, the
worker should skip the job for this cycle.
"""
from __future__ import annotations

import os

import pytest


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    # Default flag off; individual tests override.
    monkeypatch.delenv("VL_UNIFIED_QUEUE", raising=False)
    yield


def _per_provider_inflight(active_jobs: dict) -> dict:
    """Replicates the inflight-computation in _worker_loop Phase 1c block."""
    out: dict[str, int] = {}
    for j in active_jobs.values():
        p = j.get("provider")
        if p and j.get("status") in ("provisioning", "running"):
            out[p] = out.get(p, 0) + 1
    return out


def _should_skip(
    job: dict, per_provider_inflight: dict, cap_for
) -> bool:
    """Replicates the skip-decision in _worker_loop Phase 1c block."""
    preferred = job.get("preferred_providers") or []
    if not preferred:
        return False
    return all(
        per_provider_inflight.get(p, 0) >= cap_for(p)
        for p in preferred
    )


def test_skip_when_single_provider_at_cap():
    from api.unified_queue import cap_for

    # Vast cap = 3 by default. Fill 3 running jobs on Vast.
    active_jobs = {
        f"j{i}": {"provider": "Vast.ai", "status": "running"}
        for i in range(cap_for("Vast.ai"))
    }
    inflight = _per_provider_inflight(active_jobs)

    new_job = {"preferred_providers": ["Vast.ai"]}
    assert _should_skip(new_job, inflight, cap_for) is True


def test_dont_skip_when_below_cap():
    from api.unified_queue import cap_for

    active_jobs = {"j1": {"provider": "Vast.ai", "status": "running"}}
    inflight = _per_provider_inflight(active_jobs)

    new_job = {"preferred_providers": ["Vast.ai"]}
    assert _should_skip(new_job, inflight, cap_for) is False


def test_dont_skip_when_one_of_multiple_preferred_has_slot():
    from api.unified_queue import cap_for

    # Vast at cap, RunPod empty
    active_jobs = {
        f"j{i}": {"provider": "Vast.ai", "status": "running"}
        for i in range(cap_for("Vast.ai"))
    }
    inflight = _per_provider_inflight(active_jobs)

    new_job = {"preferred_providers": ["Vast.ai", "RunPod"]}
    # RunPod has capacity — don't skip
    assert _should_skip(new_job, inflight, cap_for) is False


def test_skip_when_all_preferred_providers_at_cap():
    from api.unified_queue import cap_for

    active_jobs = {}
    for p, cap in [("Vast.ai", cap_for("Vast.ai")), ("RunPod", cap_for("RunPod"))]:
        for i in range(cap):
            active_jobs[f"{p}-{i}"] = {"provider": p, "status": "running"}
    inflight = _per_provider_inflight(active_jobs)

    new_job = {"preferred_providers": ["Vast.ai", "RunPod"]}
    assert _should_skip(new_job, inflight, cap_for) is True


def test_empty_preferred_does_not_skip():
    from api.unified_queue import cap_for

    active_jobs = {
        f"j{i}": {"provider": "Vast.ai", "status": "running"}
        for i in range(cap_for("Vast.ai"))
    }
    inflight = _per_provider_inflight(active_jobs)

    # No preferred_providers → job accepts any — don't skip based on per-prov
    new_job = {"preferred_providers": []}
    assert _should_skip(new_job, inflight, cap_for) is False


def test_provisioning_counts_toward_inflight():
    from api.unified_queue import cap_for

    # Job in provisioning (not yet running) should still count toward cap
    active_jobs = {
        f"j{i}": {"provider": "Vast.ai", "status": "provisioning"}
        for i in range(cap_for("Vast.ai"))
    }
    inflight = _per_provider_inflight(active_jobs)
    assert inflight.get("Vast.ai", 0) == cap_for("Vast.ai")

    new_job = {"preferred_providers": ["Vast.ai"]}
    assert _should_skip(new_job, inflight, cap_for) is True


def test_other_statuses_do_not_count():
    from api.unified_queue import cap_for

    # completed / failed / queued shouldn't count toward inflight
    active_jobs = {
        "j1": {"provider": "Vast.ai", "status": "completed"},
        "j2": {"provider": "Vast.ai", "status": "failed"},
        "j3": {"provider": "Vast.ai", "status": "queued"},  # no provider yet
    }
    inflight = _per_provider_inflight(active_jobs)
    assert inflight.get("Vast.ai", 0) == 0


def test_feature_flag_off_means_no_check():
    """When feature flag is off, the production worker_loop doesn't even
    compute inflight or call _should_skip. This test documents that
    contract — the skip logic only applies under VL_UNIFIED_QUEUE=1."""
    from api.unified_queue import feature_enabled

    # Flag not set → disabled
    assert feature_enabled() is False


def test_feature_flag_on_via_env(monkeypatch):
    from api.unified_queue import feature_enabled

    monkeypatch.setenv("VL_UNIFIED_QUEUE", "1")
    assert feature_enabled() is True


def test_cap_for_known_providers():
    from api.unified_queue import cap_for

    assert cap_for("Vast.ai") == 3
    assert cap_for("RunPod") == 5
    assert cap_for("Lambda Labs") == 5
    assert cap_for("AWS Spot") == 20


def test_cap_for_unknown_provider_default():
    from api.unified_queue import cap_for, DEFAULT_PROVIDER_CAP

    assert cap_for("UnknownProvider") == DEFAULT_PROVIDER_CAP
