"""
Tests for the VaultLayer server-side job lifecycle code.

Covers:
  - _init_broker() singleton behavior
  - _try_provision() provider iteration + GPU resolution
  - _check_alive() via mocked httpx
  - _check_completion() via mocked Supabase
  - _terminate_and_settle() fence dispatch
  - API endpoints (POST /jobs/run, GET /jobs/{id}/status, POST /jobs/{id}/cancel)
  - resolve_gpu_enum() mappings
  - CLI thin client run_remote() submit + poll flow
"""
import asyncio
import os
import sys
import time
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock

import pytest

# ---------------------------------------------------------------------------
# Use monkeypatch at module level (cleaned up after test session)
# ---------------------------------------------------------------------------
@pytest.fixture(autouse=True)
def _isolate_env(monkeypatch):
    """Ensure test env vars AND global state don't leak to other test files."""
    monkeypatch.setenv("VL_TESTING_MODE", "1")
    monkeypatch.setenv("SUPABASE_URL", os.environ.get("SUPABASE_URL", "https://fake.supabase.co"))
    monkeypatch.setenv("SUPABASE_KEY", os.environ.get("SUPABASE_KEY", "fake-key"))
    # Force TESTING_MODE=True at module level — flags are cached at import,
    # and prior tests may have toggled api.flags.TESTING_MODE (the audit
    # added a credit pre-flight check on /jobs/run that needs this bypass).
    import api.flags
    monkeypatch.setattr(api.flags, "TESTING_MODE", True)
    yield
    # Reset ALL global state that tests may have modified
    import api.job_worker as jr
    jr._broker_instance = None
    jr._active_jobs.clear()
    jr._job_queue.clear()
    jr._worker_debug.update({"started": False, "last_error": None, "broker_ok": False, "cycle_count": 0, "last_provision_attempts": []})
    # Clear cached Supabase client (lru_cache)
    try:
        from api.db import get_db
        get_db.cache_clear()
    except Exception:
        pass


# ===========================================================================
# 1. _init_broker()
# ===========================================================================

class TestInitBroker:
    """Tests for api.job_routes._init_broker singleton factory."""

    def _reset_singleton(self):
        import api.job_worker as jr
        jr._broker_instance = None

    def test_returns_broker_instance(self):
        """_init_broker returns a BrokerAgent when config + imports succeed."""
        from api.job_worker import _init_broker
        self._reset_singleton()

        fake_broker = MagicMock()
        fake_config = MagicMock()

        with patch("shared.config.load_config", return_value=fake_config), \
             patch("agents.broker.agent.BrokerAgent", return_value=fake_broker):
            result = _init_broker()
        assert result is not None
        assert result is fake_broker
        self._reset_singleton()

    def test_returns_none_on_import_failure(self):
        """_init_broker returns None if required modules are not importable."""
        from api.job_worker import _init_broker
        self._reset_singleton()

        with patch("builtins.__import__", side_effect=ImportError("no module")):
            result = _init_broker()
        assert result is None
        self._reset_singleton()

    def test_singleton_returns_same_object(self):
        """Calling _init_broker twice returns the same cached instance."""
        import api.job_worker as jr
        self._reset_singleton()

        sentinel = object()
        jr._broker_instance = sentinel
        from api.job_worker import _init_broker
        assert _init_broker() is sentinel
        assert _init_broker() is sentinel
        self._reset_singleton()


# ===========================================================================
# 2. _try_provision()
# ===========================================================================

class TestTryProvision:
    """Tests for api.job_routes._try_provision."""

    def _make_job(self, gpu="H100", excluded=None):
        return {
            "job_id": "test-job-001",
            "user_id": "vl_test_user",
            "gpu_type": gpu,
            "environment": {},
            "docker_image": "",
            "failover": False,
            "excluded_providers": excluded or [],
        }

    @pytest.mark.asyncio
    async def test_provision_success_updates_job(self):
        """When a provider succeeds, job dict is updated with instance/provider/price."""
        from api.job_worker import _try_provision
        from shared.models import GPUType

        broker = MagicMock()
        broker.provision_vast = AsyncMock(return_value="inst-abc123")

        job = self._make_job("H100")

        prices = {
            "Vast.ai": {"H100": 2.50},
            "RunPod": {"H100": 3.00},
        }

        with patch("shared.data_loader.get_provider_prices", return_value=prices), \
             patch("shared.data_loader.resolve_gpu_key", return_value="H100"), \
             patch("shared.data_loader.resolve_gpu_enum", return_value=GPUType.H100_80GB_SXM), \
             patch("shared.data_loader.reload"):
            result = await _try_provision(broker, job)

        assert result == "inst-abc123"
        assert job["instance_id"] == "inst-abc123"
        assert job["provider"] == "vast_ai"
        assert job["price_per_hr"] == 2.50

    @pytest.mark.asyncio
    async def test_all_providers_fail_returns_none(self):
        """When all providers return None, _try_provision returns None."""
        from api.job_worker import _try_provision
        from shared.models import GPUType

        broker = MagicMock()
        broker.provision_vast = AsyncMock(return_value=None)
        broker.provision_runpod = AsyncMock(return_value=None)
        broker.provision_lambda = AsyncMock(return_value=None)

        job = self._make_job("H100")
        prices = {
            "Vast.ai": {"H100": 2.50},
            "RunPod": {"H100": 3.00},
            "Lambda Labs": {"H100": 3.50},
        }

        with patch("shared.data_loader.get_provider_prices", return_value=prices), \
             patch("shared.data_loader.resolve_gpu_key", return_value="H100"), \
             patch("shared.data_loader.resolve_gpu_enum", return_value=GPUType.H100_80GB_SXM), \
             patch("shared.data_loader.reload"):
            result = await _try_provision(broker, job)

        assert result is None

    @pytest.mark.asyncio
    async def test_gpu_type_resolution(self):
        """resolve_gpu_enum is called with the raw gpu_type string."""
        from api.job_worker import _try_provision
        from shared.models import GPUType

        broker = MagicMock()
        broker.provision_vast = AsyncMock(return_value="inst-999")

        job = self._make_job("RTX4090")
        prices = {"Vast.ai": {"RTX4090": 0.74}}

        with patch("shared.data_loader.get_provider_prices", return_value=prices), \
             patch("shared.data_loader.resolve_gpu_key", return_value="RTX4090"), \
             patch("shared.data_loader.resolve_gpu_enum", return_value=GPUType.RTX4090) as mock_enum, \
             patch("shared.data_loader.reload"):
            await _try_provision(broker, job)

        mock_enum.assert_called_once_with("RTX4090")

    @pytest.mark.asyncio
    async def test_excluded_providers_skipped(self):
        """Providers in excluded_providers list are not attempted."""
        from api.job_worker import _try_provision
        from shared.models import GPUType

        broker = MagicMock()
        broker.provision_vast = AsyncMock(return_value="inst-vast")
        broker.provision_runpod = AsyncMock(return_value="inst-rp")

        job = self._make_job("H100", excluded=["vast_ai"])
        prices = {
            "Vast.ai": {"H100": 2.00},
            "RunPod": {"H100": 3.00},
        }

        with patch("shared.data_loader.get_provider_prices", return_value=prices), \
             patch("shared.data_loader.resolve_gpu_key", return_value="H100"), \
             patch("shared.data_loader.resolve_gpu_enum", return_value=GPUType.H100_80GB_SXM), \
             patch("shared.data_loader.reload"):
            result = await _try_provision(broker, job)

        # Vast.ai should be skipped, RunPod should be used
        broker.provision_vast.assert_not_awaited()
        assert result == "inst-rp"
        assert job["provider"] == "runpod"


# ===========================================================================
# 3. _check_alive()
# ===========================================================================

class TestCheckAlive:
    """Tests for api.job_routes._check_alive."""

    def _job(self, provider="vast_ai", instance_id="inst-123"):
        return {
            "job_id": "test-job-001",
            "provider": provider,
            "instance_id": instance_id,
        }

    @pytest.mark.asyncio
    async def test_alive_status_returns_true(self):
        """When Vast.ai returns running status, _check_alive returns True."""
        from api.job_worker import _check_alive

        broker = MagicMock()
        broker._get_managed_credentials = AsyncMock(return_value={"api_key": "k"})

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"instances": [{}], "actual_status": "running"}

        with patch("httpx.get", return_value=mock_resp):
            result = await _check_alive(broker, self._job())
        assert result is True

    @pytest.mark.asyncio
    async def test_exited_status_returns_false(self):
        """When Vast.ai reports exited, _check_alive returns False."""
        from api.job_worker import _check_alive

        broker = MagicMock()
        broker._get_managed_credentials = AsyncMock(return_value={"api_key": "k"})

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"instances": [{}], "actual_status": "exited"}

        with patch("httpx.get", return_value=mock_resp):
            result = await _check_alive(broker, self._job())
        assert result is False

    @pytest.mark.asyncio
    async def test_404_returns_false(self):
        """When provider returns 404, instance is gone."""
        from api.job_worker import _check_alive

        broker = MagicMock()
        broker._get_managed_credentials = AsyncMock(return_value={"api_key": "k"})

        mock_resp = MagicMock()
        mock_resp.status_code = 404

        with patch("httpx.get", return_value=mock_resp):
            result = await _check_alive(broker, self._job())
        assert result is False

    @pytest.mark.asyncio
    async def test_unknown_provider_returns_true(self):
        """Unknown provider name returns True (assume alive)."""
        from api.job_worker import _check_alive

        broker = MagicMock()
        result = await _check_alive(broker, self._job(provider="SomeNewCloud"))
        assert result is True

    @pytest.mark.asyncio
    async def test_no_instance_id_returns_true(self):
        """No instance_id means not provisioned yet — assume alive."""
        from api.job_worker import _check_alive

        broker = MagicMock()
        result = await _check_alive(broker, self._job(instance_id=""))
        assert result is True


# ===========================================================================
# 4. _check_completion()
# ===========================================================================

class TestCheckCompletion:
    """Tests for api.job_routes._check_completion."""

    @pytest.mark.asyncio
    async def test_completion_marker_found(self):
        """Returns True when DB contains 'Training finished (exit 0)' log line."""
        from api.job_worker import _check_completion

        mock_result = MagicMock()
        mock_result.data = [{"line": "Training finished (exit 0)"}]

        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.eq.return_value.like.return_value.limit.return_value.execute.return_value = mock_result

        with patch("api.job_worker.get_db", return_value=mock_db):
            assert await _check_completion("job-001") is True

    @pytest.mark.asyncio
    async def test_no_completion_marker(self):
        """Returns False when DB has no matching log line."""
        from api.job_worker import _check_completion

        mock_result = MagicMock()
        mock_result.data = []

        mock_db = MagicMock()
        mock_db.table.return_value.select.return_value.eq.return_value.like.return_value.limit.return_value.execute.return_value = mock_result

        with patch("api.job_worker.get_db", return_value=mock_db):
            assert await _check_completion("job-002") is False

    @pytest.mark.asyncio
    async def test_db_error_returns_false(self):
        """Returns False (not crash) on DB errors."""
        from api.job_worker import _check_completion

        with patch("api.job_worker.get_db", side_effect=Exception("DB down")):
            assert await _check_completion("job-003") is False


# ===========================================================================
# 5. _terminate_and_settle()
# ===========================================================================

class TestTerminateAndSettle:
    """Tests for api.job_routes._terminate_and_settle."""

    @pytest.mark.asyncio
    async def test_calls_fence_for_vast_ai(self):
        """Calls _hard_fence_vast_ai for Vast.ai provider, records success."""
        from api.job_worker import _terminate_and_settle

        broker = MagicMock()
        broker._hard_fence_vast_ai = AsyncMock()

        job = {"provider": "vast_ai", "instance_id": "inst-100"}
        await _terminate_and_settle(broker, job)

        # Worker now tries a 2-arg call first and falls back to 1-arg on
        # TypeError (providers like Vast.ai / RunPod / Lambda don't take
        # a job parameter). The AsyncMock accepts both; verify the fence
        # was awaited and success was recorded on the job dict.
        assert broker._hard_fence_vast_ai.await_count == 1
        assert job.get("_termination_confirmed") is True

    @pytest.mark.asyncio
    async def test_calls_fence_for_runpod(self):
        """Calls _hard_fence_runpod for RunPod provider, records success."""
        from api.job_worker import _terminate_and_settle

        broker = MagicMock()
        broker._hard_fence_runpod = AsyncMock()

        job = {"provider": "runpod", "instance_id": "inst-200"}
        await _terminate_and_settle(broker, job)

        assert broker._hard_fence_runpod.await_count == 1
        assert job.get("_termination_confirmed") is True

    @pytest.mark.asyncio
    async def test_fence_failure_does_not_crash(self):
        """Gracefully handles fence function raising an exception; records failure."""
        from api.job_worker import _terminate_and_settle

        broker = MagicMock()
        broker._hard_fence_vast_ai = AsyncMock(side_effect=RuntimeError("API timeout"))

        job = {"provider": "vast_ai", "instance_id": "inst-300"}
        # Should not raise
        await _terminate_and_settle(broker, job)
        # Failure should be recorded so the DB settle path marks
        # termination_confirmed=False (zombie-sweep eligible).
        assert job.get("_termination_confirmed") is False

    @pytest.mark.asyncio
    async def test_no_instance_id_noop(self):
        """No instance_id means nothing to terminate — returns immediately."""
        from api.job_worker import _terminate_and_settle

        broker = MagicMock()
        job = {"provider": "vast_ai", "instance_id": ""}
        await _terminate_and_settle(broker, job)
        # No fence method should be called
        assert not broker._hard_fence_vast_ai.called


# ===========================================================================
# 6. API Endpoints (FastAPI TestClient)
# ===========================================================================

class TestAPIEndpoints:
    """Integration tests for the job API endpoints using FastAPI TestClient."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        """Reset module-level state before each test."""
        from api import job_routes as jr
        jr._active_jobs.clear()
        jr._job_queue.clear()
        yield
        jr._active_jobs.clear()
        jr._job_queue.clear()

    @pytest.fixture
    def client(self):
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from api.job_routes import jobs_router
        from api.auth import require_auth

        # Override require_auth to bypass Supabase in tests
        async def _fake_auth():
            return {"user_id": "test-user", "email": "test@test.com"}

        app = FastAPI()
        app.dependency_overrides[require_auth] = _fake_auth
        app.include_router(jobs_router)
        return TestClient(app)

    def test_submit_job_returns_queued(self, client):
        """POST /jobs/run returns a job_id and status=queued."""
        resp = client.post("/api/v1/jobs/run", json={
            "gpu_type": "H100",
            "script_b64": "",
            "script_name": "train.py",
            "environment": {},
            "docker_image": "",
            "failover": False,
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        assert resp.status_code == 200
        data = resp.json()
        assert "job_id" in data
        assert data["status"] == "queued"

    def test_get_job_status(self, client):
        """GET /jobs/{id}/status returns full job state."""
        # Submit first
        r1 = client.post("/api/v1/jobs/run", json={
            "gpu_type": "H100",
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        job_id = r1.json()["job_id"]

        # Fetch status
        r2 = client.get(f"/api/v1/jobs/{job_id}/status",
                        headers={"Authorization": "Bearer vl_test_xxx"})
        assert r2.status_code == 200
        data = r2.json()
        assert data["job_id"] == job_id
        assert data["status"] == "queued"
        assert data["queue_position"] == 1

    def test_get_nonexistent_job_returns_404(self, client):
        """GET /jobs/{id}/status for a missing job returns 404."""
        r = client.get("/api/v1/jobs/nonexistent/status",
                       headers={"Authorization": "Bearer vl_test_xxx"})
        assert r.status_code == 404

    def test_cancel_queued_job(self, client):
        """POST /jobs/{id}/cancel removes a queued job from the queue."""
        r1 = client.post("/api/v1/jobs/run", json={
            "gpu_type": "A100_40",
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        job_id = r1.json()["job_id"]

        r2 = client.post(f"/api/v1/jobs/{job_id}/cancel",
                         headers={"Authorization": "Bearer vl_test_xxx"})
        assert r2.status_code == 200
        assert r2.json()["status"] == "cancelled"

        # Verify it's actually cancelled
        r3 = client.get(f"/api/v1/jobs/{job_id}/status",
                        headers={"Authorization": "Bearer vl_test_xxx"})
        assert r3.json()["status"] == "cancelled"

    def test_cancel_running_job(self, client):
        """POST /jobs/{id}/cancel on a running job marks it cancelled and attempts termination."""
        from api import job_routes as jr

        # Submit + manually set to running
        r1 = client.post("/api/v1/jobs/run", json={
            "gpu_type": "H100",
        }, headers={"Authorization": "Bearer vl_test_xxx"})
        job_id = r1.json()["job_id"]
        jr._active_jobs[job_id]["status"] = "running"
        jr._active_jobs[job_id]["instance_id"] = "inst-999"
        jr._active_jobs[job_id]["provider"] = "vast_ai"

        # Mock _init_broker to return a mock broker that has async fence
        mock_broker = MagicMock()
        mock_broker._hard_fence_vast_ai = AsyncMock()

        with patch("api.job_routes._init_broker", return_value=mock_broker):
            r2 = client.post(f"/api/v1/jobs/{job_id}/cancel",
                             headers={"Authorization": "Bearer vl_test_xxx"})

        assert r2.status_code == 200
        assert r2.json()["status"] == "cancelled"

    def test_cancel_nonexistent_job_returns_404(self, client):
        """POST /jobs/{id}/cancel for a missing job returns 404."""
        r = client.post("/api/v1/jobs/nonexistent/cancel",
                        headers={"Authorization": "Bearer vl_test_xxx"})
        assert r.status_code == 404


# ===========================================================================
# 7. resolve_gpu_enum()
# ===========================================================================

class TestResolveGpuEnum:
    """Tests for shared.data_loader.resolve_gpu_enum."""

    def test_h100_maps_to_sxm(self):
        from shared.data_loader import resolve_gpu_enum
        from shared.models import GPUType
        assert resolve_gpu_enum("H100") == GPUType.H100_80GB_SXM

    def test_a100_40_maps_correctly(self):
        from shared.data_loader import resolve_gpu_enum
        from shared.models import GPUType
        assert resolve_gpu_enum("A100_40") == GPUType.A100_40GB

    def test_rtx4090_maps_correctly(self):
        from shared.data_loader import resolve_gpu_enum
        from shared.models import GPUType
        assert resolve_gpu_enum("RTX4090") == GPUType.RTX4090

    def test_fake_falls_back_to_a10g(self):
        from shared.data_loader import resolve_gpu_enum
        from shared.models import GPUType
        assert resolve_gpu_enum("FAKE") == GPUType.A10G

    def test_direct_enum_value_match(self):
        from shared.data_loader import resolve_gpu_enum
        from shared.models import GPUType
        assert resolve_gpu_enum("H100_80GB_SXM") == GPUType.H100_80GB_SXM

    def test_a100_maps_to_80gb_sxm(self):
        from shared.data_loader import resolve_gpu_enum
        from shared.models import GPUType
        assert resolve_gpu_enum("A100") == GPUType.A100_80GB_SXM

    def test_h100_pcie_maps_correctly(self):
        from shared.data_loader import resolve_gpu_enum
        from shared.models import GPUType
        assert resolve_gpu_enum("H100_PCIE") == GPUType.H100_80GB_PCIE


# ===========================================================================
# 8. CLI thin client (run_remote submit + poll flow)
# ===========================================================================

class TestRunRemote:
    """Tests for cli._remote.run_remote submit and poll flow."""

    def _make_run_cmd(self):
        rc = MagicMock()
        rc.command = ["train.py"]
        return rc

    def _make_job(self):
        from shared.models import GPUType, JobStatus, Provider
        job = MagicMock()
        job.gpu_type = GPUType.H100_80GB_SXM
        job.environment = {}
        job.docker_image = ""
        job.failover_enabled = False
        return job

    @pytest.mark.asyncio
    async def test_submit_and_poll_completed(self):
        """run_remote submits, polls twice, then returns 0 on 'completed'."""
        from shared.models import GPUType

        run_cmd = self._make_run_cmd()
        job = self._make_job()
        broker = MagicMock()
        queue = MagicMock()

        # Mock responses
        submit_resp = MagicMock()
        submit_resp.status_code = 200
        submit_resp.json.return_value = {"job_id": "j-001", "status": "queued"}

        # First poll: running, second poll: completed
        poll_responses = [
            MagicMock(status_code=200, json=MagicMock(return_value={
                "status": "running", "provider": "vast_ai",
                "instance_id": "i-1", "price_per_hr": 2.50,
                "log_line_count": 0,
            })),
            MagicMock(status_code=200, json=MagicMock(return_value={
                "status": "completed", "duration": 120.0,
                "price_per_hr": 2.50, "log_line_count": 5,
            })),
        ]

        call_count = {"n": 0}

        def mock_get(url, **kwargs):
            if "/status" in url:
                idx = min(call_count["n"], len(poll_responses) - 1)
                call_count["n"] += 1
                return poll_responses[idx]
            if "/logs" in url:
                return MagicMock(status_code=200, json=MagicMock(return_value={"lines": [], "count": 0}))
            return MagicMock(status_code=404)

        with patch("shared.api_utils.get_api_url", return_value="http://localhost:8000"), \
             patch("shared.api_utils.get_token", return_value="vl_test_xxx"), \
             patch("httpx.post", return_value=submit_resp), \
             patch("httpx.get", side_effect=mock_get), \
             patch("asyncio.sleep", new_callable=AsyncMock), \
             patch("pathlib.Path.exists", return_value=False):
            from cli._remote import run_remote
            result = await run_remote(run_cmd, job, broker, queue)

        assert result == 0

    @pytest.mark.asyncio
    async def test_submit_failure_falls_back(self):
        """run_remote falls back to local provisioning on server error."""
        run_cmd = self._make_run_cmd()
        job = self._make_job()
        broker = MagicMock()
        queue = MagicMock()

        submit_resp = MagicMock()
        submit_resp.status_code = 500
        submit_resp.text = "Internal Server Error"

        with patch("shared.api_utils.get_api_url", return_value="http://localhost:8000"), \
             patch("shared.api_utils.get_token", return_value="vl_test_xxx"), \
             patch("httpx.post", return_value=submit_resp), \
             patch("cli._remote._run_remote_local_fallback", new_callable=AsyncMock, return_value=0) as mock_fb, \
             patch("pathlib.Path.exists", return_value=False):
            from cli._remote import run_remote
            result = await run_remote(run_cmd, job, broker, queue)

        assert result == 0
        mock_fb.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_poll_returns_failed(self):
        """run_remote returns 1 when the job fails."""
        run_cmd = self._make_run_cmd()
        job = self._make_job()
        broker = MagicMock()
        queue = MagicMock()

        submit_resp = MagicMock()
        submit_resp.status_code = 200
        submit_resp.json.return_value = {"job_id": "j-002"}

        poll_resp = MagicMock()
        poll_resp.status_code = 200
        poll_resp.json.return_value = {
            "status": "failed",
            "error": "Instance lost (failover not enabled)",
            "log_line_count": 0,
        }

        with patch("shared.api_utils.get_api_url", return_value="http://localhost:8000"), \
             patch("shared.api_utils.get_token", return_value="vl_test_xxx"), \
             patch("httpx.post", return_value=submit_resp), \
             patch("httpx.get", return_value=poll_resp), \
             patch("asyncio.sleep", new_callable=AsyncMock), \
             patch("pathlib.Path.exists", return_value=False):
            from cli._remote import run_remote
            result = await run_remote(run_cmd, job, broker, queue)

        assert result == 1
