"""
VaultLayer -- New Features Tests
Covers: estimate, notify, SDK, ps, periodic checkpoint, conftest fix.
Run: pytest tests/test_new_features.py -v
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../", "src"))

import pytest
from unittest.mock import patch, AsyncMock, MagicMock
from conftest import MockAgentQueue, make_job
from shared.models import Provider, GPUType


# ============================================================
# conftest.make_job fix verification
# ============================================================

def test_make_job_accepts_gpu_type_param():
    """make_job() must accept gpu_type so scenario tests work."""
    job = make_job(gpu_type=GPUType.A100_40GB)
    assert job.gpu_type == GPUType.A100_40GB

def test_make_job_default_gpu_is_h100():
    """Default GPU must remain H100 for backward compat."""
    job = make_job()
    assert job.gpu_type == GPUType.H100_80GB_SXM

def test_make_job_accepts_provider_and_gpu_together():
    job = make_job(provider=Provider.RUNPOD, gpu_type=GPUType.RTX4090)
    assert job.provider == Provider.RUNPOD
    assert job.gpu_type == GPUType.RTX4090


# ============================================================
# vaultlayer estimate
# ============================================================

def test_estimate_provider_prices_all_have_h100():
    """Every provider dict must have H100 or None -- no KeyError."""
    from cli.estimate import PROVIDER_PRICES
    for provider, prices in PROVIDER_PRICES.items():
        assert "H100" in prices, f"{provider} missing H100 key"

def test_estimate_vl_margin_is_positive():
    from cli.estimate import VL_MARGIN
    assert 1.0 < VL_MARGIN < 2.0, f"VL_MARGIN {VL_MARGIN} must be between 1.0 and 2.0"

def test_estimate_cheapest_provider_voltage_park():
    """Cheapest non-reserved, non-spot H100 provider must be Voltage Park."""
    from cli.estimate import PROVIDER_PRICES
    # Exclude Spot/Reserved since they aren't always available
    h100_prices = {p: v["H100"] for p, v in PROVIDER_PRICES.items()
                   if v.get("H100") and "Spot" not in p and "Reserved" not in p}
    cheapest = min(h100_prices, key=h100_prices.get)
    assert cheapest == "Voltage Park", f"Expected Voltage Park cheapest, got {cheapest}"

def test_estimate_aws_od_among_most_expensive_h100():
    """AWS On-Demand must be among the most expensive H100 providers."""
    from cli.estimate import PROVIDER_PRICES
    h100_prices = {p: v["H100"] for p, v in PROVIDER_PRICES.items() if v.get("H100")}
    aws_price = h100_prices.get("AWS On-Demand", 0)
    # AWS OD should be in the top 3 most expensive
    sorted_prices = sorted(h100_prices.values(), reverse=True)
    rank = sorted_prices.index(aws_price) + 1 if aws_price in sorted_prices else 99
    assert rank <= 3, f"AWS OD H100 (${aws_price}) should be top-3, got rank {rank}"

def test_estimate_savings_positive_for_h100_24h():
    """Running H100 for 24h through VaultLayer must save money vs AWS OD."""
    from cli.estimate import PROVIDER_PRICES, VL_MARGIN
    aws_od = PROVIDER_PRICES["AWS On-Demand"]["H100"]
    non_aws = {p: v["H100"] for p, v in PROVIDER_PRICES.items() if "AWS" not in p and v.get("H100")}
    best = min(non_aws.values())
    vl_price = best * VL_MARGIN
    savings = (aws_od - vl_price) * 24
    assert savings > 0, f"Expected savings > 0, got {savings}"

def test_estimate_gpu_aliases_cover_common_inputs():
    from cli.estimate import GPU_ALIASES
    for alias in ["H100", "h100", "A100", "a100", "A10G", "a10g"]:
        assert alias in GPU_ALIASES, f"GPU alias {alias!r} missing"

def test_estimate_cli_runs_without_error():
    """estimate command must run without raising for valid GPU."""
    from click.testing import CliRunner
    from cli.estimate import estimate
    runner = CliRunner()
    result = runner.invoke(estimate, ["--gpu", "H100", "--hours", "8", "--gpus", "1"])
    assert result.exit_code == 0, f"estimate exited {result.exit_code}: {result.output}"
    assert "VaultLayer" in result.output
    assert "Savings" in result.output

def test_estimate_cli_handles_unknown_gpu():
    from click.testing import CliRunner
    from cli.estimate import estimate
    runner = CliRunner()
    result = runner.invoke(estimate, ["--gpu", "UNKNOWNGPU999"])
    assert result.exit_code == 0
    assert "Unknown" in result.output


# ============================================================
# Slack/Discord Notifier
# ============================================================

@pytest.mark.asyncio
async def test_notifier_disabled_when_no_webhook():
    """Notifier must be disabled when no webhook URL provided."""
    from cli.notify import JobNotifier
    notifier = JobNotifier(webhook_url=None)
    assert not notifier.enabled

@pytest.mark.asyncio
async def test_notifier_enabled_with_webhook():
    from cli.notify import JobNotifier
    notifier = JobNotifier(webhook_url="https://hooks.slack.com/test")
    assert notifier.enabled

@pytest.mark.asyncio
async def test_notifier_sends_job_started():
    """job_started must POST to webhook with correct payload."""
    from cli.notify import JobNotifier
    notifier = JobNotifier(webhook_url="https://hooks.slack.com/test")
    with patch("aiohttp.ClientSession") as mock_session:
        mock_ctx = AsyncMock()
        mock_session.return_value.__aenter__ = AsyncMock(return_value=mock_ctx)
        mock_session.return_value.__aexit__ = AsyncMock(return_value=False)
        mock_ctx.post = AsyncMock(return_value=AsyncMock(__aenter__=AsyncMock(), __aexit__=AsyncMock(return_value=False)))
        await notifier.job_started("my-job", "H100", "lambda_labs", 1200.0)

@pytest.mark.asyncio
async def test_notifier_silent_when_disabled():
    """Disabled notifier must not make any HTTP calls."""
    from cli.notify import JobNotifier
    notifier = JobNotifier(webhook_url=None)
    with patch("aiohttp.ClientSession") as mock_session:
        await notifier.job_started("my-job", "H100", "aws")
        mock_session.assert_not_called()

@pytest.mark.asyncio
async def test_notifier_never_raises():
    """Notifier must never raise even if HTTP call fails."""
    from cli.notify import JobNotifier
    notifier = JobNotifier(webhook_url="https://hooks.slack.com/test")
    with patch("aiohttp.ClientSession", side_effect=Exception("Network down")):
        await notifier.job_complete("job", 24.0, 1200.0, 40.0)


# ============================================================
# Python SDK
# ============================================================

def test_sdk_protect_returns_vaultlayer_context():
    from vaultlayer_sdk import protect, VaultLayerContext
    ctx = protect(gpu="H100")
    assert isinstance(ctx, VaultLayerContext)

def test_sdk_protect_decorator_wraps_function():
    from vaultlayer_sdk import protect
    @protect(gpu="A100", job_name="test-job")
    def my_train():
        return 42
    assert callable(my_train)
    assert my_train.__name__ == "my_train"

def test_sdk_protect_preserves_function_name():
    from vaultlayer_sdk import protect
    @protect(gpu="H100")
    def protein_folding_train():
        pass
    assert protein_folding_train.__name__ == "protein_folding_train"

def test_sdk_context_stores_params():
    from vaultlayer_sdk import VaultLayerContext
    ctx = VaultLayerContext(gpu="A100", checkpoint_every=120, model_params=13.0)
    assert ctx.gpu == "A100"
    assert ctx.checkpoint_every == 120
    assert ctx.model_params == 13.0

def test_sdk_protect_callable_without_credentials():
    """protect() decorator must not raise during decoration (only on call)."""
    from vaultlayer_sdk import protect
    try:
        @protect(gpu="H100")
        def dummy(): pass
    except Exception as e:
        pytest.fail(f"protect() decorator raised during decoration: {e}")


# ============================================================
# New Provider enum values
# ============================================================

def test_all_6_dark_pool_providers_in_enum():
    """All 6 new providers must be in the Provider enum."""
    from shared.models import Provider
    required = ["runpod", "vast_ai", "voltage_park", "crusoe", "nebius", "hyperstack"]
    for p in required:
        assert any(m.value == p for m in Provider), f"Provider.{p} missing from enum"

def test_new_gpu_types_in_enum():
    """New 2025-2026 GPU types must be in GPUType enum."""
    from shared.models import GPUType
    for gpu in [GPUType.RTX4090, GPUType.A40, GPUType.L40S]:
        assert gpu.value is not None


# ============================================================
# Periodic checkpoint config
# ============================================================

def test_checkpoint_interval_env_var_is_parseable():
    """VAULTLAYER_CHECKPOINT_INTERVAL must be readable as int."""
    import os
    os.environ["VAULTLAYER_CHECKPOINT_INTERVAL"] = "600"
    interval = int(os.environ.get("VAULTLAYER_CHECKPOINT_INTERVAL", "300"))
    assert interval == 600
    del os.environ["VAULTLAYER_CHECKPOINT_INTERVAL"]

def test_checkpoint_interval_default_is_300():
    import os
    os.environ.pop("VAULTLAYER_CHECKPOINT_INTERVAL", None)
    interval = int(os.environ.get("VAULTLAYER_CHECKPOINT_INTERVAL", "300"))
    assert interval == 300