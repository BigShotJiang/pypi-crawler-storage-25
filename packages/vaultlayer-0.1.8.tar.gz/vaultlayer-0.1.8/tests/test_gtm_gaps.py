"""
VaultLayer — GTM Gap tests

GTM Gap 1: Hard STONITH via provider terminate API (_hard_fence_and_confirm)
GTM Gap 2: Credential encryption at rest (CredentialVault)
GTM Gap 3: Cloud-side heartbeat monitor in OrchestrationAgent (_heartbeat_monitor_loop)
"""
import sys
import os
import asyncio
import json
import tempfile
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch, call

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from shared.models import Job, JobStatus, Provider, GPUType, AgentEvent, EventType
from shared.config import (
    VaultLayerConfig, AWSConfig, LambdaLabsConfig, CoreWeaveConfig,
    CloudflareConfig, RedisConfig, AnthropicConfig,
)

# ── Helpers ────────────────────────────────────────────────────────────────────


def make_config():
    return VaultLayerConfig(
        token="vl_test_" + "a" * 64,
        user_id="test-user",
        aws=AWSConfig(access_key_id="AKIAIOSFODNN7EXAMPLE", secret_access_key="wJalrXUtnFEMI"),
        lambda_labs=LambdaLabsConfig(api_key="test-lambda-key"),
        coreweave=CoreWeaveConfig(api_key="test-cw-key", namespace="test-ns"),
        cloudflare=CloudflareConfig(
            account_id="test-acct",
            r2_access_key_id="r2-key",
            r2_secret_access_key="r2-secret",
            r2_bucket="test-bucket",
            r2_endpoint="https://test.r2.cloudflarestorage.com",
        ),
        redis=RedisConfig(url="redis://localhost:6379"),
        anthropic=AnthropicConfig(api_key="test-anthropic-key"),
    )


def make_job(job_id="job-001", provider=Provider.AWS, instance_id="i-abc123"):
    return Job(
        job_id=job_id,
        name="test job",
        status=JobStatus.RUNNING,
        provider=provider,
        gpu_type=GPUType.H100_80GB_SXM,
        instance_id=instance_id,
        region="us-east-1",
        model_params_billion=7.0,
        command="python train.py",
        progress_pct=50.0,
    )


class MockQueue:
    """Minimal mock queue for orchestration tests."""
    def __init__(self):
        self.published = []
        self._hash_store = {}

    async def publish(self, channel, event):
        self.published.append((channel, event))

    async def publish_critical(self, channel, event):
        self.published.append((f"critical:{channel}", event))

    async def subscribe(self, channels, handler):
        pass

    async def get_price_cache(self):
        return []

    async def get_history(self, channel, limit=50):
        return []

    async def hget(self, key, field):
        return self._hash_store.get(key, {}).get(field)

    async def hset(self, key, mapping):
        self._hash_store.setdefault(key, {}).update(mapping)
        return len(mapping)

    async def expire(self, key, ttl):
        return True

    def events_on(self, channel):
        return [e for (ch, e) in self.published if ch == channel]


# ═══════════════════════════════════════════════════════════════════════════════
# GTM Gap 1: Hard STONITH via provider terminate API
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.fixture
def broker_agent():
    """BrokerAgent with mocked STS client (anthropic no longer used by broker)."""
    from agents.broker.agent import BrokerAgent
    config = make_config()
    queue = MockQueue()
    with patch("agents.broker.agent.STSSessionManager"):
        agent = BrokerAgent(config, queue)
    return agent


@pytest.mark.asyncio
async def test_hard_fence_calls_ec2_terminate_for_aws_provider(broker_agent):
    """ec2.terminate_instances should be called with the correct instance_id."""
    job = make_job(provider=Provider.AWS, instance_id="i-deadbeef")

    mock_ec2 = MagicMock()
    # Simulate already-terminated after first describe
    mock_ec2.describe_instances.return_value = {
        "Reservations": [{"Instances": [{"State": {"Name": "terminated"}}]}]
    }
    broker_agent._sts.get_ec2_client = MagicMock(return_value=mock_ec2)

    await broker_agent._hard_fence_and_confirm(job)

    mock_ec2.terminate_instances.assert_called_once_with(InstanceIds=["i-deadbeef"])


@pytest.mark.asyncio
async def test_hard_fence_waits_for_terminated_state(broker_agent):
    """Should poll describe_instances until state is terminated/shutting-down."""
    job = make_job(provider=Provider.AWS, instance_id="i-poll123")

    mock_ec2 = MagicMock()
    # First call: still running; second call: shutting-down
    mock_ec2.describe_instances.side_effect = [
        {"Reservations": [{"Instances": [{"State": {"Name": "running"}}]}]},
        {"Reservations": [{"Instances": [{"State": {"Name": "shutting-down"}}]}]},
    ]
    broker_agent._sts.get_ec2_client = MagicMock(return_value=mock_ec2)

    with patch("asyncio.sleep", new_callable=AsyncMock):
        await broker_agent._hard_fence_and_confirm(job)

    assert mock_ec2.describe_instances.call_count >= 1


@pytest.mark.asyncio
async def test_hard_fence_continues_on_api_failure(broker_agent):
    """RuntimeError from terminate_instances must not block migration — just log and return."""
    job = make_job(provider=Provider.AWS, instance_id="i-already-dead")

    mock_ec2 = MagicMock()
    mock_ec2.terminate_instances.side_effect = RuntimeError("InvalidInstanceID.NotFound")
    broker_agent._sts.get_ec2_client = MagicMock(return_value=mock_ec2)

    # Must not raise
    await broker_agent._hard_fence_and_confirm(job)


@pytest.mark.asyncio
async def test_hard_fence_skips_fence_for_spot_termination():
    """When event_type is 'termination_signal', _hard_fence_and_confirm should NOT be called."""
    from agents.broker.agent import BrokerAgent
    config = make_config()
    queue = MockQueue()
    with patch("agents.broker.agent.STSSessionManager"):
        agent = BrokerAgent(config, queue)

    agent._hard_fence_and_confirm = AsyncMock()

    # Simulate the call-site logic: termination_signal skips the fence
    event_type = "termination_signal"
    _is_termination_signal = event_type == "termination_signal"
    if not _is_termination_signal:
        await agent._hard_fence_and_confirm(make_job())

    agent._hard_fence_and_confirm.assert_not_called()


@pytest.mark.asyncio
async def test_hard_fence_calls_lambda_terminate_for_lambda_provider(broker_agent):
    """Lambda Labs terminate API should be called for Provider.LAMBDA_LABS jobs."""
    job = make_job(provider=Provider.LAMBDA_LABS, instance_id="lm-instance-42")

    mock_post_response = MagicMock()
    mock_post_response.status = 200

    # GET /instances/{id} returns 404 (instance gone) on first poll
    mock_get_response = MagicMock()
    mock_get_response.status = 404

    mock_session = AsyncMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=False)
    mock_session.post = AsyncMock(return_value=mock_post_response)
    mock_session.get = AsyncMock(return_value=mock_get_response)

    with patch("agents.broker.agent.aiohttp.ClientSession", return_value=mock_session), \
         patch("asyncio.sleep", new_callable=AsyncMock):
        await broker_agent._hard_fence_and_confirm(job)

    # Verify post was called with instance_id in body
    post_calls = mock_session.post.call_args_list
    assert len(post_calls) >= 1
    _, kwargs = post_calls[0]
    body = kwargs.get("json", {})
    assert "lm-instance-42" in body.get("instance_ids", [])


# ═══════════════════════════════════════════════════════════════════════════════
# GTM Gap 2: Credential Vault — encryption at rest
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.fixture
def vault_dir(tmp_path, monkeypatch):
    """Redirect CredentialVault's default directory to a temp dir."""
    import shared.credential_vault as cv_module
    monkeypatch.setattr(cv_module, "_VAULT_DIR", tmp_path)
    monkeypatch.setattr(cv_module, "_ENC_FILE", tmp_path / "credentials.enc")
    monkeypatch.setattr(cv_module, "_SALT_FILE", tmp_path / "salt")
    return tmp_path


def make_vault(token="test-secret-token", vault_dir=None):
    from shared.credential_vault import CredentialVault
    return CredentialVault(token=token)


def test_credential_vault_store_and_retrieve(vault_dir):
    """Round-trip: store a value and retrieve it back unchanged."""
    from shared.credential_vault import CredentialVault
    vault = CredentialVault(token="mysecret")
    vault.store("AWS_ACCESS_KEY_ID", "AKIAIOSFODNN7EXAMPLE")
    result = vault.retrieve("AWS_ACCESS_KEY_ID")
    assert result == "AKIAIOSFODNN7EXAMPLE"


def test_credential_vault_stores_encrypted_not_plaintext(vault_dir):
    """The raw bytes on disk must not contain the plaintext value."""
    import shared.credential_vault as cv_module
    from shared.credential_vault import CredentialVault

    vault = CredentialVault(token="mysecret")
    vault.store("SECRET", "super_secret_value_12345")

    raw = cv_module._ENC_FILE.read_bytes()
    assert b"super_secret_value_12345" not in raw


def test_credential_vault_store_all_and_retrieve_all(vault_dir):
    """Bulk store/retrieve should round-trip all key-value pairs."""
    from shared.credential_vault import CredentialVault
    vault = CredentialVault(token="bulktoken")
    creds = {
        "AWS_ACCESS_KEY_ID": "key123",
        "AWS_SECRET_ACCESS_KEY": "secret456",
        "ANTHROPIC_API_KEY": "sk-ant-xyz",
    }
    vault.store_all(creds)
    result = vault.retrieve_all()
    assert result == creds


def test_credential_vault_different_tokens_different_keys(vault_dir):
    """Two vaults with different tokens must produce different ciphertext."""
    import shared.credential_vault as cv_module
    from shared.credential_vault import CredentialVault

    vault1 = CredentialVault(token="token-aaa")
    vault1.store("KEY", "same-value")
    ciphertext1 = cv_module._ENC_FILE.read_bytes()

    # Remove vault file so vault2 starts fresh
    cv_module._ENC_FILE.unlink()

    vault2 = CredentialVault(token="token-bbb")
    vault2.store("KEY", "same-value")
    ciphertext2 = cv_module._ENC_FILE.read_bytes()

    assert ciphertext1 != ciphertext2


def test_credential_vault_wrong_token_cannot_decrypt(vault_dir):
    """Wrong token must NOT be able to read the original secret value.
    The vault returns None / empty dict (not the plaintext) when decryption fails —
    the security property is data inaccessibility, not exception propagation."""
    from shared.credential_vault import CredentialVault

    vault_correct = CredentialVault(token="correct-token")
    vault_correct.store("SENSITIVE", "my-api-key")

    vault_wrong = CredentialVault(token="wrong-token")
    # Wrong token must not expose the secret — returns None (key absent after failed decrypt)
    result = vault_wrong.retrieve("SENSITIVE")
    assert result != "my-api-key", "Wrong token must not expose the plaintext secret"


def test_credential_vault_missing_key_returns_none(vault_dir):
    """retrieve() must return None when the key doesn't exist in the vault."""
    from shared.credential_vault import CredentialVault
    vault = CredentialVault(token="sometoken")
    result = vault.retrieve("NONEXISTENT_KEY")
    assert result is None


# ═══════════════════════════════════════════════════════════════════════════════
# GTM Gap 3: Cloud-side heartbeat monitor in OrchestrationAgent
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.fixture
def orchestration_agent():
    """OrchestrationAgent with mocked dependencies."""
    from agents.orchestration.agent import OrchestrationAgent
    config = make_config()
    queue = MockQueue()
    with patch("agents.orchestration.agent.anthropic.Anthropic"), \
         patch("agents.orchestration.agent.NamespaceAgent", MagicMock()), \
         patch("agents.orchestration.agent.make_telemetry", return_value=MagicMock(
             counter=MagicMock(), decision=MagicMock(), event=MagicMock()
         )):
        agent = OrchestrationAgent(config, queue)
    return agent


def test_heartbeat_monitor_loop_exists(orchestration_agent):
    """_heartbeat_monitor_loop must be importable and be a coroutine function."""
    import inspect
    assert hasattr(orchestration_agent, "_heartbeat_monitor_loop")
    assert inspect.iscoroutinefunction(orchestration_agent._heartbeat_monitor_loop)


@pytest.mark.asyncio
async def test_heartbeat_monitor_publishes_miss_when_stale(orchestration_agent):
    """When Redis ts is >90s old, HEARTBEAT_MISS must be published to watchdog channel."""
    from agents.orchestration.agent import HEARTBEAT_TIMEOUT_SECONDS

    job = make_job(job_id="job-stale", provider=Provider.AWS)
    job.status = JobStatus.RUNNING
    orchestration_agent._active_jobs["job-stale"] = job

    stale_ts = str(time.time() - (HEARTBEAT_TIMEOUT_SECONDS + 10))
    orchestration_agent.queue._hash_store[f"vl:heartbeat:job-stale"] = {"ts": stale_ts}

    # Run the loop body directly (skip the sleep) by running the loop in a tight way.
    # We patch asyncio.sleep so it raises StopAsyncIteration after one iteration to break the loop.
    call_count = 0

    async def sleep_once(_):
        nonlocal call_count
        call_count += 1
        if call_count >= 2:
            raise asyncio.CancelledError()

    with patch("agents.orchestration.agent.asyncio.sleep", side_effect=sleep_once):
        try:
            await orchestration_agent._heartbeat_monitor_loop()
        except asyncio.CancelledError:
            pass

    watchdog_events = orchestration_agent.queue.events_on("watchdog")
    miss_types = [e.event_type for e in watchdog_events]
    assert EventType.HEARTBEAT_MISS in miss_types


@pytest.mark.asyncio
async def test_heartbeat_monitor_no_miss_when_fresh(orchestration_agent):
    """Fresh heartbeat (within threshold) must NOT trigger HEARTBEAT_MISS."""
    from agents.orchestration.agent import HEARTBEAT_TIMEOUT_SECONDS

    job = make_job(job_id="job-fresh", provider=Provider.AWS)
    job.status = JobStatus.RUNNING
    orchestration_agent._active_jobs["job-fresh"] = job

    fresh_ts = str(time.time() - 10)  # 10 seconds ago — well within threshold
    orchestration_agent.queue._hash_store[f"vl:heartbeat:job-fresh"] = {"ts": fresh_ts}

    call_count = 0

    async def sleep_once(_):
        nonlocal call_count
        call_count += 1
        if call_count >= 2:
            raise asyncio.CancelledError()

    with patch("agents.orchestration.agent.asyncio.sleep", side_effect=sleep_once):
        try:
            await orchestration_agent._heartbeat_monitor_loop()
        except asyncio.CancelledError:
            pass

    watchdog_events = orchestration_agent.queue.events_on("watchdog")
    assert all(e.event_type != EventType.HEARTBEAT_MISS for e in watchdog_events)


@pytest.mark.asyncio
async def test_heartbeat_monitor_skips_non_running_jobs(orchestration_agent):
    """Completed and queued jobs must be skipped — no HEARTBEAT_MISS published."""
    from agents.orchestration.agent import HEARTBEAT_TIMEOUT_SECONDS

    for status in (JobStatus.COMPLETED, JobStatus.QUEUED, JobStatus.FAILED):
        job = make_job(job_id=f"job-{status.value}", provider=Provider.AWS)
        job.status = status
        orchestration_agent._active_jobs[job.job_id] = job
        # Even stale heartbeat — should be ignored because not RUNNING/MIGRATING
        stale_ts = str(time.time() - (HEARTBEAT_TIMEOUT_SECONDS + 100))
        orchestration_agent.queue._hash_store[f"vl:heartbeat:{job.job_id}"] = {"ts": stale_ts}

    call_count = 0

    async def sleep_once(_):
        nonlocal call_count
        call_count += 1
        if call_count >= 2:
            raise asyncio.CancelledError()

    with patch("agents.orchestration.agent.asyncio.sleep", side_effect=sleep_once):
        try:
            await orchestration_agent._heartbeat_monitor_loop()
        except asyncio.CancelledError:
            pass

    watchdog_events = orchestration_agent.queue.events_on("watchdog")
    assert all(e.event_type != EventType.HEARTBEAT_MISS for e in watchdog_events)


@pytest.mark.asyncio
async def test_heartbeat_monitor_handles_redis_error_gracefully(orchestration_agent):
    """Exception in hget must not crash the monitor loop."""
    job = make_job(job_id="job-redis-err", provider=Provider.AWS)
    job.status = JobStatus.RUNNING
    orchestration_agent._active_jobs["job-redis-err"] = job

    # Make hget always raise
    orchestration_agent.queue.hget = AsyncMock(side_effect=RuntimeError("Redis connection lost"))

    call_count = 0

    async def sleep_once(_):
        nonlocal call_count
        call_count += 1
        if call_count >= 2:
            raise asyncio.CancelledError()

    with patch("agents.orchestration.agent.asyncio.sleep", side_effect=sleep_once):
        try:
            await orchestration_agent._heartbeat_monitor_loop()
        except asyncio.CancelledError:
            pass

    # No HEARTBEAT_MISS published (error was suppressed)
    watchdog_events = orchestration_agent.queue.events_on("watchdog")
    assert all(e.event_type != EventType.HEARTBEAT_MISS for e in watchdog_events)


@pytest.mark.asyncio
async def test_orchestration_start_launches_heartbeat_monitor(orchestration_agent):
    """start() must launch _heartbeat_monitor_loop as an asyncio task."""
    created_tasks = []

    original_create_task = asyncio.create_task

    def mock_create_task(coro, **kwargs):
        task = original_create_task(coro, **kwargs)
        created_tasks.append(kwargs.get("name", ""))
        return task

    with patch("agents.orchestration.agent.asyncio.create_task", side_effect=mock_create_task), \
         patch.object(orchestration_agent.queue, "subscribe", new_callable=AsyncMock):
        # Run start but cancel immediately to avoid blocking
        try:
            task = asyncio.create_task(orchestration_agent.start())
            await asyncio.sleep(0)
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
        except Exception:
            pass

    assert "heartbeat-monitor" in created_tasks
