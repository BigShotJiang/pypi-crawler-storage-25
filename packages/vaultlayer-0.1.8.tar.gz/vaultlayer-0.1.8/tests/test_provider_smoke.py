"""
VaultLayer — All-11-Provider Provision Smoke Test
==================================================
Mirrors the live smoke test:
  vaultlayer run --gpu H100_80GB_SXM python -c "import time; print('job started'); time.sleep(60); print('done')"

…but for all 11 providers, each using the CHEAPEST GPU that provider supports.

Cheapest GPU by provider (2026-04 market prices):
  AWS          A10G            $3.06/hr OD / ~$1.10 spot  (g5.xlarge)
  Lambda Labs  A10G            $1.10/hr
  CoreWeave    A10G            $1.25/hr    (RTX A6000 resource label)
  RunPod       A100_80GB_SXM   $1.59/hr    (40GB SKU retired 2026-04)
  Vast.ai      A100_40GB       $5.60/hr    (auction median)
  Voltage Park A100_80GB_SXM   $10.00/hr   (only H100 + A100_80 available)
  Crusoe       A100_40GB       $7.20/hr
  Nebius       A100_80GB_SXM   $14.40/hr   (only H100 + A100_80 available)
  Hyperstack   A100_40GB       $7.00/hr
  GCP          A10G            $2.80/hr    (T4/n1-standard-8 preemptible)
  Azure        A100_40GB       $16.00/hr   (Standard_ND96asr_v4 spot)

Network boundary mocking only — no agent internals are patched.
Each test asserts provision_*() returns a non-None instance ID.
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import asyncio
import base64
import pytest
from typing import Optional
from unittest.mock import AsyncMock, MagicMock, patch

from conftest import MockAgentQueue, make_job
from shared.models import GPUType, Provider


# ── Shared config fixture (all 11 providers pre-loaded) ───────────────────────

@pytest.fixture
def full_config():
    from shared.config import (
        VaultLayerConfig, AWSConfig, LambdaLabsConfig, CoreWeaveConfig,
        CloudflareConfig, RedisConfig, AnthropicConfig, RunPodConfig,
        VastAiConfig, VoltageParkConfig, CrusoeConfig, NebiusConfig,
        HyperstackConfig, GCPConfig, AzureConfig, STSConfig,
    )
    return VaultLayerConfig(
        token="vl_test_" + "s" * 64,
        user_id="smoke-user",
        aws=AWSConfig(
            access_key_id="AK_SMOKE",
            secret_access_key="SK_SMOKE",
            region="us-east-1",
        ),
        lambda_labs=LambdaLabsConfig(api_key="ll-smoke-key"),
        coreweave=CoreWeaveConfig(api_key="cw-smoke-key", namespace="vaultlayer-smoke"),
        cloudflare=CloudflareConfig(
            account_id="cf-acct",
            r2_access_key_id="R2_KEY",
            r2_secret_access_key="R2_SECRET",
            r2_bucket="vl-smoke",
            r2_endpoint="https://cf-acct.r2.cloudflarestorage.com",
        ),
        redis=RedisConfig(url="redis://localhost:6379"),
        runpod=RunPodConfig(api_key="runpod-smoke-key"),
        vast_ai=VastAiConfig(api_key="vast-smoke-key"),
        voltage_park=VoltageParkConfig(api_key="vp-smoke-key"),
        crusoe=CrusoeConfig(api_key="crusoe-smoke-key", api_secret="crusoe-smoke-secret", project_id="proj-smoke-123"),
        nebius=NebiusConfig(service_account_key="nebius-smoke-key", folder_id="folder-123"),
        hyperstack=HyperstackConfig(api_key="hs-smoke-key"),
        gcp=GCPConfig(
            service_account_json="/tmp/fake-sa.json",
            project_id="vaultlayer-smoke",
            region="us-central1",
            zone="us-central1-a",
        ),
        azure=AzureConfig(
            subscription_id="sub-smoke",
            tenant_id="tenant-smoke",
            client_id="client-smoke",
            client_secret="secret-smoke",
            resource_group="vl-smoke-rg",
            location="eastus",
        ),
        sts=STSConfig(role_arn="arn:aws:iam::123456789012:role/VaultLayerSpot"),
        anthropic=AnthropicConfig(api_key="ant-smoke-key"),
    )


@pytest.fixture
def broker(full_config):
    from agents.broker.agent import BrokerAgent
    return BrokerAgent(full_config, MockAgentQueue())


def _smoke_job():
    """Minimal job that mirrors the live smoke test command."""
    j = make_job(job_id="smoke-job-00000001")
    j.command = "python -c \"import time; print('job started'); time.sleep(60); print('done')\""
    j.docker_image = "pytorch/pytorch:2.3-cuda12.1-cudnn8-runtime"
    j.environment = {"SMOKE_TEST": "1"}
    return j


def _mock_aiohttp_session(get_responses: Optional[dict] = None,
                           post_response=None,
                           put_response=None):
    """
    Build a reusable aiohttp.ClientSession mock.

    get_responses  — dict mapping URL fragments to response payloads (json)
    post_response  — single json payload returned for POST
    put_response   — single json payload returned for PUT
    """
    session = MagicMock()

    def _make_resp(payload, status=200):
        ctx = AsyncMock()
        ctx.__aenter__ = AsyncMock(return_value=ctx)
        ctx.__aexit__ = AsyncMock(return_value=False)
        ctx.status = status
        ctx.json = AsyncMock(return_value=payload)
        ctx.text = AsyncMock(return_value=str(payload))
        return ctx

    # GET — match by URL fragment
    def _get(url, **kw):
        if get_responses:
            for frag, payload in get_responses.items():
                if frag in str(url):
                    return _make_resp(payload)
        return _make_resp({})

    session.get = MagicMock(side_effect=_get)
    session.post = MagicMock(return_value=_make_resp(post_response or {}))
    session.put  = MagicMock(return_value=_make_resp(put_response  or {}))

    # context-manager support for `async with aiohttp.ClientSession() as session:`
    session_ctx = MagicMock()
    session_ctx.__aenter__ = AsyncMock(return_value=session)
    session_ctx.__aexit__  = AsyncMock(return_value=False)
    return session_ctx


# ─────────────────────────────────────────────────────────────────────────────
# 1. AWS Spot — A10G @ ~$1.10/hr spot (g5.xlarge)
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_smoke_aws_spot_a10g(broker):
    """
    SMOKE: AWS Spot A10G (g5.xlarge) — cheapest AWS GPU.
    Validates: STS → create_launch_template → run_instances (spot) → RUNNING.
    """
    job = _smoke_job()
    gpu = GPUType.A10G  # $3.06/hr OD, ~$1.10/hr spot

    mock_ec2 = MagicMock()
    mock_ec2.describe_images.return_value = {
        "Images": [{"ImageId": "ami-0mock0000000000a1", "CreationDate": "2024-01-01T00:00:00.000Z"}]
    }
    mock_ec2.create_launch_template.return_value = {
        "LaunchTemplate": {"LaunchTemplateId": "lt-smoke-a10g", "LatestVersionNumber": 1}
    }
    mock_ec2.run_instances.return_value = {
        "Instances": [{"InstanceId": "i-smoke-a10g-001", "State": {"Name": "pending"}}]
    }
    mock_ec2.describe_instances.return_value = {
        "Reservations": [{"Instances": [{"InstanceId": "i-smoke-a10g-001",
                                          "State": {"Name": "running"},
                                          "PublicIpAddress": "54.1.2.3"}]}]
    }
    mock_ec2.delete_launch_template.return_value = {}

    async def _sleep_noop(*a, **kw): pass

    with patch.object(broker._sts, 'get_ec2_client', return_value=mock_ec2), \
         patch('asyncio.sleep', side_effect=_sleep_noop):
        instance_id = await broker.provision_aws(gpu, job)

    assert instance_id is not None, "AWS Spot A10G: provision returned None"
    assert "smoke-a10g" in instance_id or instance_id.startswith("i-"), \
        f"AWS Spot A10G: unexpected instance_id format: {instance_id}"
    mock_ec2.create_launch_template.assert_called_once()
    mock_ec2.run_instances.assert_called_once()
    lt_data = mock_ec2.create_launch_template.call_args[1]["LaunchTemplateData"]
    # Instance type is asserted against AWS_INSTANCE_MAP (source of truth)
    # rather than a hardcoded string so smoke-test overrides don't break the
    # unit test.
    from agents.broker.providers.aws import AWS_INSTANCE_MAP
    expected_it = AWS_INSTANCE_MAP[gpu]
    assert lt_data["InstanceType"] == expected_it, \
        f"AWS A10G should use {expected_it} (per AWS_INSTANCE_MAP), got: {lt_data['InstanceType']}"
    print(f"  ✓ AWS Spot  A10G  {expected_it}  → {instance_id}")


# ─────────────────────────────────────────────────────────────────────────────
# 2. Lambda Labs — A10G @ $1.10/hr
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_smoke_lambda_a10g(broker):
    """
    SMOKE: Lambda Labs A10G — $1.10/hr, cheapest Lambda GPU.
    Validates: POST /instance-operations/launch → instance_ids returned.
    """
    job = _smoke_job()
    gpu = GPUType.A10G  # $1.10/hr — cheapest Lambda option

    # provision_lambda GETs ssh-keys + instance-types, then POSTs /instance-operations/launch
    post_payload = {"data": {"instance_ids": ["lambda-smoke-inst-001"]}}
    mock_session = _mock_aiohttp_session(
        get_responses={
            "ssh-keys":       {"data": [{"name": "vaultlayer-key"}]},
            "instance-types": {"data": {"gpu_1x_a10": {
                "regions_with_capacity_available": [{"name": "us-east-1"}]}}},
        },
        post_response=post_payload,
    )

    with patch('agents.broker.agent.aiohttp.ClientSession', return_value=mock_session):
        instance_id = await broker.provision_lambda(gpu, job)

    assert instance_id is not None, "Lambda Labs A10G: provision returned None"
    print(f"  ✓ Lambda Labs  A10G  → {instance_id}  ($1.10/hr)")


# ─────────────────────────────────────────────────────────────────────────────
# 3. CoreWeave — A10G @ $1.25/hr
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.skip(reason="CoreWeave not available — pending onboarding")
@pytest.mark.asyncio
async def test_smoke_coreweave_a10g(broker):
    """
    SMOKE: CoreWeave A10G @ $1.25/hr (mapped to RTX_A6000 resource label).
    Validates: Kubernetes-style REST call → pod name returned.
    """
    job = _smoke_job()
    gpu = GPUType.A10G  # $1.25/hr

    post_payload = {
        "metadata": {"name": "vl-smoke-cw-a10g"},
        "status": {"phase": "Running"},
    }
    mock_session = _mock_aiohttp_session(post_response=post_payload)

    with patch('agents.broker.agent.aiohttp.ClientSession', return_value=mock_session):
        instance_id = await broker.provision_coreweave(gpu, job)

    assert instance_id is not None, "CoreWeave A10G: provision returned None"
    print(f"  ✓ CoreWeave  A10G  RTX_A6000  → {instance_id}  ($1.25/hr)")


# ─────────────────────────────────────────────────────────────────────────────
# 4. RunPod — A100 80GB SXM @ $1.59/hr
# ─────────────────────────────────────────────────────────────────────────────
# Note: switched from A100_40GB → A100_80GB_SXM on 2026-04-18. RunPod retired
# the 40GB A100 SKU; the config mapping for A100_40 was dropped, so a
# provision for that key now correctly fails fast ("no matching GPU type
# for A100_40"). 80GB SXM is the cheapest A100 RunPod currently lists.

@pytest.mark.asyncio
async def test_smoke_runpod_a100_80gb(broker):
    """
    SMOKE: RunPod A100 80GB SXM @ $1.59/hr.
    Validates: POST /pod/ → pod ID returned.
    """
    job = _smoke_job()
    gpu = GPUType.A100_80GB_SXM  # $1.59/hr

    post_payload = {"id": "runpod-smoke-pod-001"}
    mock_session = _mock_aiohttp_session(post_response=post_payload)

    with patch('agents.broker.agent.aiohttp.ClientSession', return_value=mock_session):
        instance_id = await broker.provision_runpod(gpu, job)

    assert instance_id is not None, "RunPod A100 80GB: provision returned None"
    print(f"  ✓ RunPod  A100 80GB SXM  → {instance_id}  ($1.59/hr)")


# ─────────────────────────────────────────────────────────────────────────────
# 5. Vast.ai — A100_40GB @ $5.60/hr (auction median)
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_smoke_vast_a100_40gb(broker):
    """
    SMOKE: Vast.ai A100_40GB @ $5.60/hr auction median — cheapest Vast GPU in matrix.
    Validates: POST /bundles → PUT /asks/<id> → bid confirmed (status=running).
    """
    job = _smoke_job()
    gpu = GPUType.A100_40GB  # $5.60/hr median spot

    offer_id = "9988776"
    # /api/v0/bundles/ search is POST per current Vast.ai docs.
    bundles_payload = {"offers": [{"id": offer_id, "dph_total": 0.70,
                                    "gpu_name": "A100_PCIE_40GB", "reliability2": 0.98}]}
    put_payload = {"new_contract": offer_id, "actual_status": "running",
                   "ssh_host": "ssh5.vast.ai", "ssh_port": 22}
    instance_payload = {"actual_status": "running", "ssh_host": "ssh5.vast.ai"}

    mock_session = _mock_aiohttp_session(
        get_responses={
            "users/current": {"credit": 100.0},
            f"instances/{offer_id}": instance_payload,
        },
        post_response=bundles_payload,
        put_response=put_payload,
    )

    async def _sleep_noop(*a, **kw): pass

    with patch('agents.broker.agent.aiohttp.ClientSession', return_value=mock_session), \
         patch('asyncio.sleep', side_effect=_sleep_noop):
        instance_id = await broker.provision_vast(gpu, job)

    assert instance_id is not None, "Vast.ai A100_40GB: provision returned None"
    assert str(offer_id) in str(instance_id), \
        f"Expected offer_id {offer_id} in instance_id, got: {instance_id}"
    print(f"  ✓ Vast.ai  A100_40GB  → {instance_id}  ($5.60/hr auction)")


# ─────────────────────────────────────────────────────────────────────────────
# 6. Voltage Park — A100_80GB_SXM @ $10.00/hr
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_smoke_voltage_park_a100_80gb(broker):
    """
    SMOKE: Voltage Park A100_80GB_SXM @ $10.00/hr — cheapest VP GPU (fixed pricing).
    Validates: POST /instances → instance ID returned.
    """
    job = _smoke_job()
    gpu = GPUType.A100_80GB_SXM  # $10.00/hr — cheapest VP option

    post_payload = {"id": "vp-smoke-inst-001"}
    # GET /instant-deploy-presets/ must return at least one available preset
    preset_data = [{"id": "preset-001", "compute_rate_hourly": "1.89",
                    "location_ids_with_availability": ["loc-001"]}]
    # GET /virtual-machines/instant/locations/{id} returns config_id
    location_data = {"configs": [{"id": "cfg-001"}]}
    mock_session = _mock_aiohttp_session(
        get_responses={"instant-deploy-presets": preset_data,
                       "instant/locations": location_data},
        post_response=post_payload,
    )

    with patch('agents.broker.agent.aiohttp.ClientSession', return_value=mock_session):
        instance_id = await broker.provision_voltage_park(gpu, job)

    assert instance_id is not None, "Voltage Park A100_80GB_SXM: provision returned None"
    print(f"  ✓ Voltage Park  A100_80GB_SXM  → {instance_id}  ($10.00/hr fixed)")


# ─────────────────────────────────────────────────────────────────────────────
# 7. Crusoe — A100_40GB @ $7.20/hr
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_smoke_crusoe_a100_40gb(broker):
    """
    SMOKE: Crusoe A100_40GB @ $7.20/hr — ~30% below AWS equivalent.
    Validates: POST /instances (Basic auth) → instance ID returned.
    """
    job = _smoke_job()
    gpu = GPUType.A100_40GB  # $7.20/hr

    post_payload = {"instance": {"id": "crusoe-smoke-vm-001", "status": "running"}}
    mock_session = _mock_aiohttp_session(post_response=post_payload)

    with patch('agents.broker.agent.aiohttp.ClientSession', return_value=mock_session):
        instance_id = await broker.provision_crusoe(gpu, job)

    assert instance_id is not None, "Crusoe A100_40GB: provision returned None"
    print(f"  ✓ Crusoe  A100_40GB  → {instance_id}  ($7.20/hr energy-optimized)")


# ─────────────────────────────────────────────────────────────────────────────
# 8. Nebius — A100_80GB_SXM @ $14.40/hr (EU Frankfurt)
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.skip(reason="Nebius not available — EU onboarding pending")
@pytest.mark.asyncio
async def test_smoke_nebius_a100_80gb(broker):
    """
    SMOKE: Nebius A100_80GB_SXM @ $14.40/hr — cheapest Nebius GPU (EU Frankfurt).
    Validates: POST /instances (Bearer auth, base64 startup) → metadata.id returned.
    Note: data matrix marks Nebius as limited-availability; patch is_gpu_available
    to simulate in-region capacity being available.
    """
    job = _smoke_job()
    gpu = GPUType.A100_80GB_SXM  # $14.40/hr — cheaper than H100 on Nebius

    post_payload = {"metadata": {"id": "nebius-smoke-inst-001", "status": "RUNNING"}}
    mock_session = _mock_aiohttp_session(post_response=post_payload)

    # Nebius (EU) capacity is marked limited in static data; patch availability for smoke
    with patch('agents.broker.agent.is_gpu_available', return_value=True), \
         patch('agents.broker.agent.aiohttp.ClientSession', return_value=mock_session):
        instance_id = await broker.provision_nebius(gpu, job)

    assert instance_id is not None, "Nebius A100_80GB_SXM: provision returned None"
    print(f"  ✓ Nebius  A100_80GB_SXM  Frankfurt  → {instance_id}  ($14.40/hr GDPR)")


# ─────────────────────────────────────────────────────────────────────────────
# 9. Hyperstack — A100_40GB @ $7.00/hr (UK/Canada)
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_smoke_hyperstack_a100_40gb(broker):
    """
    SMOKE: Hyperstack A100_40GB @ $7.00/hr — cheapest Hyperstack GPU (UK/Canada).
    Validates: POST /core/virtual-machines → VM ID returned.
    """
    job = _smoke_job()
    gpu = GPUType.A100_40GB  # $7.00/hr

    post_payload = {"virtual_machines": [{"id": 88001, "status": "active",
                                           "ip_addresses": [{"address": "1.2.3.4"}]}]}
    mock_session = _mock_aiohttp_session(post_response=post_payload)

    with patch('agents.broker.agent.aiohttp.ClientSession', return_value=mock_session):
        instance_id = await broker.provision_hyperstack(gpu, job)

    assert instance_id is not None, "Hyperstack A100_40GB: provision returned None"
    print(f"  ✓ Hyperstack  A100_40GB  UK/CA  → {instance_id}  ($7.00/hr)")


# ─────────────────────────────────────────────────────────────────────────────
# 10. GCP — A10G (T4) @ $2.80/hr preemptible
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_smoke_gcp_a10g(broker):
    """
    SMOKE: GCP A10G (mapped to T4 / n1-standard-8) @ $2.80/hr preemptible.
    Validates: Compute Engine insert op → RUNNING poll → instance name returned.
    """
    job = _smoke_job()
    gpu = GPUType.A10G  # $2.80/hr preemptible

    # Build compute mock: instances().insert().execute() and instances().get().execute()
    mock_insert_req = MagicMock()
    mock_insert_req.execute.return_value = {"name": "op-smoke-gcp", "status": "DONE"}

    mock_get_req = MagicMock()
    mock_get_req.execute.return_value = {"status": "RUNNING", "name": "vl-smoke-jo-a10g"}

    mock_instances = MagicMock()
    mock_instances.insert.return_value = mock_insert_req
    mock_instances.get.return_value = mock_get_req

    mock_compute = MagicMock()
    mock_compute.instances.return_value = mock_instances

    # discovery.build("compute", "v1", ...) → mock_compute
    mock_discovery_mod = MagicMock()
    mock_discovery_mod.build.return_value = mock_compute

    # service_account.Credentials.from_service_account_file → mock creds
    mock_sa_creds = MagicMock()
    mock_sa_module = MagicMock()
    mock_sa_module.Credentials.from_service_account_file.return_value = mock_sa_creds

    # Build module mocks with explicit sub-attributes so `from X import Y`
    # via getattr() returns the right object (MagicMock auto-attrs would diverge)
    mock_google_oauth2 = MagicMock()
    mock_google_oauth2.service_account = mock_sa_module

    mock_googleapiclient = MagicMock()
    mock_googleapiclient.discovery = mock_discovery_mod

    async def _sleep_noop(*a, **kw): pass

    # Pin to single zone so the new capacity-aware ranker doesn't try
    # to mock acceleratorTypes.list — cross-zone fallback is covered by
    # the live prod smoke.
    import os as _os
    _prev_lock = _os.environ.get("VL_GCP_ZONE_LOCKED")
    _os.environ["VL_GCP_ZONE_LOCKED"] = "1"
    try:
        with patch.dict('sys.modules', {
                'google':                     MagicMock(),
                'google.auth':                MagicMock(),
                'google.oauth2':              mock_google_oauth2,
                'google.oauth2.service_account': mock_sa_module,
                'googleapiclient':            mock_googleapiclient,
                'googleapiclient.discovery':  mock_discovery_mod,
             }), \
             patch('asyncio.sleep', side_effect=_sleep_noop):
            instance_id = await broker.provision_gcp(gpu, job)
    finally:
        if _prev_lock is None:
            _os.environ.pop("VL_GCP_ZONE_LOCKED", None)
        else:
            _os.environ["VL_GCP_ZONE_LOCKED"] = _prev_lock

    assert instance_id is not None, "GCP A10G (T4): provision returned None"
    mock_insert_req.execute.assert_called_once()
    print(f"  ✓ GCP  A10G→T4  n1-standard-8  → {instance_id}  ($2.80/hr preemptible)")


# ─────────────────────────────────────────────────────────────────────────────
# 11. Azure — A100_40GB @ $16.00/hr spot (Standard_ND96asr_v4)
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.skip(reason="Azure not available — subscription onboarding pending")
@pytest.mark.asyncio
async def test_smoke_azure_a100_40gb(broker, tmp_path):
    """
    SMOKE: Azure A100_40GB @ $16.00/hr spot (Standard_ND96asr_v4).
    Validates: VNet → PublicIP → NIC → Spot VM → 'vm_name/public_ip' returned.
    """
    job = _smoke_job()
    gpu = GPUType.A100_40GB  # $16.00/hr — cheapest Azure GPU in price table

    # Write fake SSH public key
    ssh_key_path = tmp_path / "id_rsa.pub"
    ssh_key_path.write_text("ssh-rsa AAAAB3NzaC1yc2EAAA smoke-test-key vaultlayer")

    # ── Azure SDK mocks ───────────────────────────────────────────────────────
    def _make_poller(return_value):
        p = MagicMock()
        p.result.return_value = return_value
        return p

    # Network objects
    mock_subnet   = MagicMock(); mock_subnet.id = "/subscriptions/sub/subnets/default"
    mock_pip      = MagicMock(); mock_pip.id = "/subscriptions/sub/pip/vl-smoke"
    mock_pip.ip_address = "20.1.2.3"
    mock_nic      = MagicMock(); mock_nic.id = "/subscriptions/sub/nics/vl-smoke-nic"

    mock_network_client = MagicMock()
    mock_network_client.virtual_networks.begin_create_or_update.return_value = _make_poller(MagicMock())
    mock_network_client.subnets.get.return_value = mock_subnet
    mock_network_client.public_ip_addresses.begin_create_or_update.return_value = _make_poller(mock_pip)
    mock_network_client.network_interfaces.begin_create_or_update.return_value = _make_poller(mock_nic)

    # Compute VM
    mock_vm = MagicMock()
    mock_vm.name = "vl-smoke-jo"
    mock_compute_client = MagicMock()
    mock_compute_client.virtual_machines.begin_create_or_update.return_value = _make_poller(mock_vm)

    mock_credential = MagicMock()
    mock_identity   = MagicMock()
    mock_identity.ClientSecretCredential.return_value = mock_credential

    mock_compute_module = MagicMock()
    mock_compute_module.ComputeManagementClient.return_value = mock_compute_client
    mock_network_module = MagicMock()
    mock_network_module.NetworkManagementClient.return_value = mock_network_client

    with patch.dict('sys.modules', {
            'azure.identity': mock_identity,
            'azure.mgmt.compute': mock_compute_module,
            'azure.mgmt.network': mock_network_module,
         }), \
         patch.dict(os.environ, {"VAULTLAYER_SSH_PUB_KEY": str(ssh_key_path)}):
        instance_id = await broker.provision_azure(gpu, job)

    assert instance_id is not None, "Azure A100_40GB: provision returned None"
    # provision_azure returns 'vm_name/public_ip'
    assert "/" in instance_id, \
        f"Azure instance_id should be 'vm_name/ip', got: {instance_id}"
    vm_name, public_ip = instance_id.split("/", 1)
    assert vm_name.startswith("vl-"), f"Azure VM name format unexpected: {vm_name}"
    print(f"  ✓ Azure  A100_40GB  ND96asr_v4  → {vm_name}  ip={public_ip}  ($16.00/hr spot)")


# ─────────────────────────────────────────────────────────────────────────────
# Summary table — run all 11 in sequence to see cost ranking
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_cheapest_gpu_cost_ranking():
    """
    Non-provision test: validates the cost ranking table is internally consistent.
    Asserts cheapest-first ordering across all 11 providers.
    """
    from agents.pricing.agent import (
        LAMBDA_PRICES, COREWEAVE_PRICES, RUNPOD_PRICES, VAST_PRICES,
        VOLTAGE_PARK_PRICES, CRUSOE_PRICES, NEBIUS_PRICES, HYPERSTACK_PRICES,
        GCP_PRICES, AZURE_PRICES, AWS_ON_DEMAND,
    )

    cheapest = {
        "AWS (spot ~30% OD)":  min(AWS_ON_DEMAND.values()) * 0.30,   # conservative spot est.
        "Lambda Labs":         min(LAMBDA_PRICES.values()),
        "CoreWeave":           min(COREWEAVE_PRICES.values()),
        "Vast.ai":             min(VAST_PRICES.values()),
        "GCP":                 min(GCP_PRICES.values()),
        "RunPod":              min(RUNPOD_PRICES.values()),
        "Crusoe":              min(CRUSOE_PRICES.values()),
        "Hyperstack":          min(HYPERSTACK_PRICES.values()),
        "Voltage Park":        min(VOLTAGE_PARK_PRICES.values()),
        "Nebius":              min(NEBIUS_PRICES.values()),
        "Azure":               min(AZURE_PRICES.values()),
    }

    ranked = sorted(cheapest.items(), key=lambda x: x[1])

    print("\n  ┌── Cheapest GPU per provider (8× pod, $/hr) ─────────┐")
    for rank, (provider, price) in enumerate(ranked, 1):
        print(f"  │  {rank:2d}.  {provider:<22}  ${price:>7.2f}/hr    │")
    print("  └──────────────────────────────────────────────────────┘")

    # Sanity checks
    assert cheapest["Lambda Labs"]   < cheapest["Azure"],        "Lambda must be cheaper than Azure"
    assert cheapest["CoreWeave"]     < cheapest["Nebius"],       "CoreWeave cheaper than Nebius"
    assert cheapest["Vast.ai"]       < cheapest["Crusoe"],       "Vast.ai cheaper than Crusoe"
    assert cheapest["GCP"]           < cheapest["Voltage Park"], "GCP T4 cheaper than Voltage Park"
