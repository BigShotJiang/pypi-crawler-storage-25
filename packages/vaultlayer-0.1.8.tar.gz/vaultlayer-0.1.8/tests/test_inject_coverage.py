"""
Coverage tests for cli/inject.py — CheckpointInjector, scan_storage_access,
warn_if_storage_unconfigured, and detect_framework.
"""
import textwrap
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch


# ── Fixtures ──────────────────────────────────────────────────────────────────

_PYTORCH_SIMPLE = textwrap.dedent("""\
    import torch
    import torch.nn as nn

    model = nn.Linear(10, 1)
    optimizer = torch.optim.Adam(model.parameters())

    for step in range(1000):
        loss = model(x)
        loss.backward()
        optimizer.step()
""")

_PYTORCH_NO_LOOP = textwrap.dedent("""\
    import torch

    model = torch.nn.Linear(10, 1)
""")

_DEEPSPEED_SIMPLE = textwrap.dedent("""\
    import deepspeed

    model, optimizer, _, _ = deepspeed.initialize(model=model)

    for step in range(500):
        loss = model(batch)
        model.backward(loss)
        model.step()
""")

_JAX_SIMPLE = textwrap.dedent("""\
    import jax
    import jax.numpy as jnp

    params = init_params()

    for step in range(2000):
        grads = jax.grad(loss_fn)(params)
        params = update(params, grads)
        optimizer.step()
""")

_MULTI_LOOP = textwrap.dedent("""\
    import torch

    model = torch.nn.Linear(10, 1)
    opt = torch.optim.SGD(model.parameters(), lr=0.01)

    # warmup
    for step in range(100):
        loss = model(x)
        loss.backward()
        opt.step()

    # main training
    for step in range(10000):
        loss = model(x)
        loss.backward()
        opt.step()
""")

_NESTED_LOOP = textwrap.dedent("""\
    import torch

    model = torch.nn.Linear(10, 1)
    opt = torch.optim.Adam(model.parameters())

    for epoch in range(50):
        for batch in dataloader:
            loss = model(batch)
            loss.backward()
            opt.step()
""")


# ── CheckpointInjector: init ──────────────────────────────────────────────────

class TestCheckpointInjectorInit:
    def test_parses_valid_source(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        assert inj.framework == "pytorch"

    def test_raises_on_syntax_error(self):
        from cli.inject import CheckpointInjector
        with pytest.raises(ValueError, match="Cannot parse script"):
            CheckpointInjector("def broken(:\n    pass\n")

    def test_default_framework_is_pytorch(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        assert inj.framework == "pytorch"

    def test_deepspeed_framework(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_DEEPSPEED_SIMPLE, framework="deepspeed")
        assert inj.framework == "deepspeed"

    def test_jax_framework(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_JAX_SIMPLE, framework="jax")
        assert inj.framework == "jax"


# ── CheckpointInjector: inject() ─────────────────────────────────────────────

class TestCheckpointInjectorInject:
    def test_inject_pytorch_returns_new_source_and_diff(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        new_src, diff = inj.inject()
        assert isinstance(new_src, str)
        assert isinstance(diff, list)
        assert len(diff) > 0

    def test_inject_pytorch_adds_import(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        new_src, diff = inj.inject()
        assert "vaultlayer" in new_src.lower() or "vl_" in new_src

    def test_inject_pytorch_adds_checkpoint_call(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        new_src, diff = inj.inject()
        assert "vl_checkpoint" in new_src or "checkpoint" in new_src

    def test_inject_adds_restore_before_loop(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        new_src, diff = inj.inject()
        # restore should appear before the for loop
        for_pos = new_src.find("for step in range")
        assert for_pos > 0
        restore_pos = new_src.rfind("restore", 0, for_pos)
        assert restore_pos >= 0, "restore() should appear before the training loop"

    def test_inject_pytorch_no_loop_raises_valueerror(self):
        """No-loop scripts must raise ValueError so the caller shows a manual 3-line diff."""
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_NO_LOOP)
        with pytest.raises(ValueError, match="No standard training loop detected"):
            inj.inject()

    def test_inject_deepspeed(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_DEEPSPEED_SIMPLE, framework="deepspeed")
        new_src, diff = inj.inject()
        assert "vl_" in new_src or "vaultlayer" in new_src.lower()

    def test_inject_jax(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_JAX_SIMPLE, framework="jax")
        new_src, diff = inj.inject()
        assert isinstance(new_src, str)
        assert len(diff) > 0

    def test_inject_multi_phase_script(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_MULTI_LOOP)
        new_src, diff = inj.inject()
        # Multi-phase: should reference phase0/phase1
        assert "phase0" in new_src
        assert "phase1" in new_src

    def test_inject_single_loop_no_phase_suffix(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        new_src, diff = inj.inject()
        # Single loop: no phase0 suffix
        assert "phase0" not in new_src

    def test_inject_nested_loop(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_NESTED_LOOP)
        new_src, diff = inj.inject()
        assert isinstance(new_src, str)

    def test_diff_lines_start_with_plus(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        _, diff = inj.inject()
        for line in diff:
            assert line.startswith("+") or line.startswith("~"), \
                f"Unexpected diff line: {line!r}"

    def test_inject_result_is_valid_python(self):
        """The injected source must still parse as valid Python."""
        import ast
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        new_src, _ = inj.inject()
        # Should not raise
        ast.parse(new_src)


# ── CheckpointInjector: detection helpers ────────────────────────────────────

class TestCheckpointInjectorDetection:
    def test_find_all_training_loops_single(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        loops = inj._find_all_training_loops()
        assert len(loops) == 1

    def test_find_all_training_loops_multi(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_MULTI_LOOP)
        loops = inj._find_all_training_loops()
        assert len(loops) == 2

    def test_find_all_training_loops_no_loop(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_NO_LOOP)
        loops = inj._find_all_training_loops()
        assert loops == []

    def test_last_import_line_idx_nonzero(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        idx = inj._last_import_line_idx()
        assert idx >= 0

    def test_last_import_line_idx_zero_when_no_imports(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector("x = 1\n")
        idx = inj._last_import_line_idx()
        assert idx == 0

    def test_checkpoint_freq_small_range(self):
        """range(50) → freq=5 (50//10)."""
        from cli.inject import CheckpointInjector
        import ast
        src = textwrap.dedent("""\
            import torch
            for step in range(50):
                loss.backward()
                optimizer.step()
        """)
        inj = CheckpointInjector(src)
        loops = inj._find_all_training_loops()
        assert loops
        freq = inj._checkpoint_freq(loops[0])
        assert freq == 5

    def test_checkpoint_freq_large_range(self):
        """range(10000): N > 500 → max(500, 10000//20) = 500.
        R2 uploads are separately time-gated to 30 min in _notify_checkpoint().
        """
        from cli.inject import CheckpointInjector
        src = textwrap.dedent("""\
            import torch
            for step in range(10000):
                loss.backward()
                optimizer.step()
        """)
        inj = CheckpointInjector(src)
        loops = inj._find_all_training_loops()
        freq = inj._checkpoint_freq(loops[0])
        assert freq == 500  # ~20 local NVMe saves; R2 uploads ≤ 2/hour

    def test_checkpoint_freq_very_large_range(self):
        """range(100000): N > 500 → max(500, 100000//20) = 5000."""
        from cli.inject import CheckpointInjector
        src = textwrap.dedent("""\
            import torch
            for step in range(100000):
                loss.backward()
                optimizer.step()
        """)
        inj = CheckpointInjector(src)
        loops = inj._find_all_training_loops()
        freq = inj._checkpoint_freq(loops[0])
        assert freq == 5000

    def test_checkpoint_freq_epoch_var_defaults_to_1(self):
        """Epoch-named loop with unknown total → freq=1."""
        from cli.inject import CheckpointInjector
        src = textwrap.dedent("""\
            import torch
            for epoch in loader:
                loss.backward()
                optimizer.step()
        """)
        inj = CheckpointInjector(src)
        loops = inj._find_all_training_loops()
        if loops:
            freq = inj._checkpoint_freq(loops[0])
            assert freq == 1

    def test_loop_info_extracts_loop_var(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        loops = inj._find_all_training_loops()
        assert loops[0]["loop_var"] == "step"

    def test_loop_info_extracts_range_arg(self):
        from cli.inject import CheckpointInjector
        inj = CheckpointInjector(_PYTORCH_SIMPLE)
        loops = inj._find_all_training_loops()
        assert loops[0]["range_arg"] == "1000"


# ── scan_storage_access ───────────────────────────────────────────────────────

class TestScanStorageAccess:
    def test_detects_boto3(self):
        from cli.inject import scan_storage_access
        result = scan_storage_access("import boto3\ns3 = boto3.client('s3')")
        assert "AWS S3 (boto3)" in result

    def test_detects_s3fs(self):
        from cli.inject import scan_storage_access
        result = scan_storage_access("import s3fs\nfs = s3fs.S3FileSystem()")
        assert "AWS S3 (s3fs)" in result

    def test_detects_s3_uri(self):
        from cli.inject import scan_storage_access
        result = scan_storage_access("path = 's3://my-bucket/data.csv'")
        assert "S3 URI (s3://)" in result

    def test_detects_aiobotocore(self):
        from cli.inject import scan_storage_access
        result = scan_storage_access("import aiobotocore")
        assert "AWS S3 (aiobotocore)" in result

    def test_detects_gcs_google_cloud(self):
        from cli.inject import scan_storage_access
        result = scan_storage_access("from google.cloud import storage")
        assert "GCS (google-cloud-storage)" in result

    def test_detects_gcs_uri(self):
        from cli.inject import scan_storage_access
        result = scan_storage_access("path = 'gs://my-bucket/data'")
        assert "GCS URI (gs://)" in result

    def test_detects_gcs_bare(self):
        from cli.inject import scan_storage_access
        result = scan_storage_access("import gcs\nfs = gcs.GCSFileSystem()")
        assert "GCS" in " ".join(result)

    def test_detects_azure_storage(self):
        from cli.inject import scan_storage_access
        result = scan_storage_access("from azure.storage.blob import BlobServiceClient")
        assert any("Azure" in r for r in result)

    def test_detects_blob_service_client(self):
        from cli.inject import scan_storage_access
        result = scan_storage_access("client = BlobServiceClient(url)")
        assert "Azure Blob Storage" in result

    def test_detects_azure_blob_uri(self):
        from cli.inject import scan_storage_access
        result = scan_storage_access("url = 'https://myaccount.blob.core.windows.net/container'")
        assert "Azure Blob Storage URI" in result

    def test_no_storage_returns_empty(self):
        from cli.inject import scan_storage_access
        result = scan_storage_access("import torch\nmodel = torch.nn.Linear(10, 1)")
        assert result == []

    def test_deduplicated_labels(self):
        """Same pattern appearing twice only shows label once."""
        from cli.inject import scan_storage_access
        result = scan_storage_access("import boto3\nboto3.client('s3')\nboto3.resource('s3')")
        assert result.count("AWS S3 (boto3)") == 1

    def test_multiple_providers_detected(self):
        from cli.inject import scan_storage_access
        src = "import boto3\nfrom google.cloud import storage\nfrom azure.storage.blob import BlobServiceClient"
        result = scan_storage_access(src)
        assert len(result) >= 3


# ── warn_if_storage_unconfigured ─────────────────────────────────────────────

class TestWarnIfStorageUnconfigured:
    def test_warns_when_boto3_found_and_no_config(self, tmp_path):
        from cli.inject import warn_if_storage_unconfigured
        script = tmp_path / "train.py"
        script.write_text("import boto3\ns3 = boto3.client('s3')")
        config_env = tmp_path / "config.env"
        # No config file

        with patch("click.echo") as mock_echo:
            warn_if_storage_unconfigured(script, config_env)
        assert mock_echo.called

    def test_suppressed_when_s3_key_configured(self, tmp_path):
        from cli.inject import warn_if_storage_unconfigured
        script = tmp_path / "train.py"
        script.write_text("import boto3")
        config_env = tmp_path / "config.env"
        config_env.write_text("VL_S3_ACCESS_KEY_ID=AKIA...\n")

        with patch("click.echo") as mock_echo:
            warn_if_storage_unconfigured(script, config_env)
        assert not mock_echo.called

    def test_suppressed_when_gcs_configured(self, tmp_path):
        from cli.inject import warn_if_storage_unconfigured
        script = tmp_path / "train.py"
        script.write_text("from google.cloud import storage")
        config_env = tmp_path / "config.env"
        config_env.write_text("VL_GCS_CREDENTIALS_JSON=/path/sa.json\n")

        with patch("click.echo") as mock_echo:
            warn_if_storage_unconfigured(script, config_env)
        assert not mock_echo.called

    def test_suppressed_when_azure_configured(self, tmp_path):
        from cli.inject import warn_if_storage_unconfigured
        script = tmp_path / "train.py"
        script.write_text("from azure.storage.blob import BlobServiceClient")
        config_env = tmp_path / "config.env"
        config_env.write_text("VL_AZURE_CONNECTION_STRING=DefaultEndpointsProtocol=...\n")

        with patch("click.echo") as mock_echo:
            warn_if_storage_unconfigured(script, config_env)
        assert not mock_echo.called

    def test_no_warn_when_no_storage_access(self, tmp_path):
        from cli.inject import warn_if_storage_unconfigured
        script = tmp_path / "train.py"
        script.write_text("import torch\nmodel = torch.nn.Linear(10, 1)")
        config_env = tmp_path / "config.env"

        with patch("click.echo") as mock_echo:
            warn_if_storage_unconfigured(script, config_env)
        assert not mock_echo.called

    def test_no_crash_when_script_missing(self, tmp_path):
        from cli.inject import warn_if_storage_unconfigured
        script = tmp_path / "nonexistent.py"
        config_env = tmp_path / "config.env"
        # Should not raise
        warn_if_storage_unconfigured(script, config_env)


# ── detect_framework ─────────────────────────────────────────────────────────

class TestDetectFramework:
    def test_deepspeed_takes_priority(self):
        from cli.inject import detect_framework
        result = detect_framework({"deepspeed": True, "jax": True})
        assert result == "deepspeed"

    def test_jax_detected(self):
        from cli.inject import detect_framework
        result = detect_framework({"jax": True})
        assert result == "jax"

    def test_defaults_to_pytorch(self):
        from cli.inject import detect_framework
        result = detect_framework({})
        assert result == "pytorch"

    def test_pytorch_when_neither_deepspeed_nor_jax(self):
        from cli.inject import detect_framework
        result = detect_framework({"pytorch": True})
        assert result == "pytorch"


# ── Indent helper ─────────────────────────────────────────────────────────────

class TestIndentHelper:
    def test_indent_of_zero(self):
        from cli.inject import _indent_of
        assert _indent_of("x = 1") == 0

    def test_indent_of_four(self):
        from cli.inject import _indent_of
        assert _indent_of("    x = 1") == 4

    def test_indent_of_eight(self):
        from cli.inject import _indent_of
        assert _indent_of("        x = 1") == 8

    def test_indent_of_empty(self):
        from cli.inject import _indent_of
        assert _indent_of("") == 0
