"""
VaultLayer -- EC4 Weight Storm Tests
Edge Case 4: "Egress-Free Weight Storm"

Problem: 1.2 TB model weights. Sequential put_object times out.
         By the time download finishes, the 30-min Spot window has closed.

Fix: Multipart parallel upload (8 concurrent parts x 64 MB).
     Parallel shard download (8 concurrent shards simultaneously).
     R2 as zero-egress hub -- data never transits between cloud billing domains.

Run: pytest tests/test_ec4_weight_storm.py -v
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../', 'src'))

import math
import time
import pytest
import threading
from unittest.mock import patch, MagicMock, call
from conftest import MockAgentQueue, make_job
from shared.models import Provider, GPUType


# ============================================================
# Helpers
# ============================================================

def make_r2_client(dummy_config):
    from agents.vault.r2 import R2Client
    return R2Client(
        endpoint=dummy_config.cloudflare.r2_endpoint,
        access_key_id=dummy_config.cloudflare.r2_access_key_id,
        secret_access_key=dummy_config.cloudflare.r2_secret_access_key,
        bucket=dummy_config.cloudflare.r2_bucket,
    )


# ============================================================
# EC4-1: Multipart threshold
# ============================================================

def test_ec4_multipart_threshold_is_64mb(dummy_config):
    """Threshold must be ≥64 MB -- small checkpoints use put_object, large use multipart.
    Updated to 200 MB to minimize Class A R2 ops (68% fewer parts per 20 GB checkpoint)."""
    from agents.vault.r2 import MULTIPART_THRESHOLD_BYTES
    assert MULTIPART_THRESHOLD_BYTES >= 64 * 1024 * 1024, (
        f"Threshold is {MULTIPART_THRESHOLD_BYTES} -- must be ≥64 MB"
    )


def test_ec4_chunk_size_is_64mb(dummy_config):
    """Each multipart chunk must be ≥64 MB for optimal throughput.
    Updated to 200 MB to minimize Class A R2 ops (68% fewer parts per 20 GB checkpoint)."""
    from agents.vault.r2 import MULTIPART_CHUNK_SIZE_BYTES
    assert MULTIPART_CHUNK_SIZE_BYTES >= 64 * 1024 * 1024


def test_ec4_concurrency_is_8(dummy_config):
    """Parallel workers for multipart upload. Reduced to 5 (5×200MB=1GB RAM headroom)."""
    from agents.vault.r2 import MULTIPART_MAX_CONCURRENCY, DOWNLOAD_MAX_CONCURRENCY
    assert MULTIPART_MAX_CONCURRENCY >= 4  # ≥4 workers required; was 8 before 200MB chunks
    assert DOWNLOAD_MAX_CONCURRENCY >= 4


# ============================================================
# EC4-2: Small file uses put_object (not multipart)
# ============================================================

def test_ec4_small_checkpoint_uses_put_object(dummy_config):
    """Files under 64 MB must use single put_object -- multipart has overhead."""
    client = make_r2_client(dummy_config)
    small_data = b'x' * (32 * 1024 * 1024)  # 32 MB
    job = make_job()

    with patch.object(client, '_s3') as mock_s3, \
         patch('agents.vault.r2.zlib.compress', return_value=small_data):
        mock_s3.put_object = MagicMock()
        mock_s3.create_multipart_upload = MagicMock()
        with patch('builtins.open', MagicMock()), \
             patch('agents.vault.r2.Path.exists', return_value=True), \
             patch('agents.vault.r2.Path.is_file', return_value=True), \
             patch('agents.vault.r2.Path.read_bytes', return_value=small_data):
            try:
                client.upload_checkpoint(job.job_id, step=100,
                                         local_path='/workspace/model.pt',
                                         model_params_billion=7.0)
            except Exception:
                pass
        mock_s3.create_multipart_upload.assert_not_called()


# ============================================================
# EC4-3: Large file uses multipart
# ============================================================

def test_ec4_large_checkpoint_uses_multipart(dummy_config):
    """Files >= MULTIPART_THRESHOLD_BYTES must use multipart upload (currently 200 MB)."""
    from agents.vault.r2 import MULTIPART_THRESHOLD_BYTES
    client = make_r2_client(dummy_config)
    large_data = b'x' * (MULTIPART_THRESHOLD_BYTES + 1)  # 1 byte above threshold
    job = make_job()

    with patch.object(client, '_s3') as mock_s3, \
         patch('agents.vault.r2.zlib.compress', return_value=large_data):
        mock_s3.create_multipart_upload.return_value = {'UploadId': 'mpu-test-001'}
        mock_s3.upload_part.return_value = {'ETag': 'etag-001'}
        mock_s3.complete_multipart_upload.return_value = {}
        with patch('agents.vault.r2.Path.exists', return_value=True), \
             patch('agents.vault.r2.Path.is_file', return_value=True), \
             patch('agents.vault.r2.Path.read_bytes', return_value=large_data):
            try:
                client.upload_checkpoint(job.job_id, step=1000,
                                         local_path='/workspace/model.pt',
                                         model_params_billion=70.0)
            except Exception:
                pass
        mock_s3.create_multipart_upload.assert_called_once()


# ============================================================
# EC4-4: Multipart splits into correct number of parts
# ============================================================

def test_ec4_multipart_part_count_is_correct(dummy_config):
    """A file of 3× chunk size must create exactly 3 parts."""
    from agents.vault.r2 import MULTIPART_CHUNK_SIZE_BYTES
    client = make_r2_client(dummy_config)

    # Use 3× the current chunk size (200MB → 600MB, or whatever the constant is)
    data_3chunks = b'x' * (3 * MULTIPART_CHUNK_SIZE_BYTES)
    expected_parts = math.ceil(len(data_3chunks) / MULTIPART_CHUNK_SIZE_BYTES)
    assert expected_parts == 3

    parts_uploaded = []
    with patch.object(client._s3, 'create_multipart_upload') as mock_create, \
         patch.object(client._s3, 'upload_part') as mock_part, \
         patch.object(client._s3, 'complete_multipart_upload') as mock_complete:
        mock_create.return_value = {'UploadId': 'mpu-3chunks'}
        mock_part.side_effect = lambda **kw: (parts_uploaded.append(kw['PartNumber']), {'ETag': f'etag-{kw["PartNumber"]}'})[1]
        mock_complete.return_value = {}
        client._upload_multipart(data_3chunks, 'test/model.pt', {})

    assert len(parts_uploaded) == 3, f'Expected 3 parts, got {len(parts_uploaded)}'
    assert sorted(parts_uploaded) == [1, 2, 3]


# ============================================================
# EC4-5: Multipart abort on part failure
# ============================================================

def test_ec4_multipart_aborts_on_part_failure(dummy_config):
    """If any part fails, multipart upload must abort -- no dangling incomplete uploads."""
    client = make_r2_client(dummy_config)
    data = b'x' * (128 * 1024 * 1024)

    with patch.object(client._s3, 'create_multipart_upload') as mock_create, \
         patch.object(client._s3, 'upload_part', side_effect=Exception('Network error')), \
         patch.object(client._s3, 'abort_multipart_upload') as mock_abort, \
         patch.object(client._s3, 'complete_multipart_upload') as mock_complete:
        mock_create.return_value = {'UploadId': 'mpu-fail-001'}
        with pytest.raises(Exception, match='Network error'):
            client._upload_multipart(data, 'test/model.pt', {})
        mock_abort.assert_called_once_with(
            Bucket=dummy_config.cloudflare.r2_bucket,
            Key='test/model.pt',
            UploadId='mpu-fail-001'
        )
        mock_complete.assert_not_called()


# ============================================================
# EC4-6: Parallel shard download method exists
# ============================================================

def test_ec4_parallel_shard_download_method_exists(dummy_config):
    """R2Client must have download_shards_parallel() -- the weight storm fix."""
    client = make_r2_client(dummy_config)
    assert hasattr(client, 'download_shards_parallel'), (
        'download_shards_parallel() missing -- large model downloads will be sequential'
    )


# ============================================================
# EC4-7: Parallel shard download fires all shards concurrently
# ============================================================

def test_ec4_parallel_download_fires_concurrently(dummy_config, tmp_path):
    """All shards must be fetched in parallel -- not one after another."""
    client = make_r2_client(dummy_config)
    shard_keys = [f'weights/shard-{i:03d}.pt' for i in range(10)]
    call_times = []
    call_lock = threading.Lock()

    def fake_get_object(**kwargs):
        with call_lock:
            call_times.append(time.monotonic())
        import zlib
        compressed = zlib.compress(b'weight_data' * 100)
        return {'Body': MagicMock(read=MagicMock(return_value=compressed))}

    with patch.object(client._s3, 'get_object', side_effect=fake_get_object):
        results = client.download_shards_parallel(shard_keys, str(tmp_path))

    assert len(results) == 10, f'Expected 10 results, got {len(results)}'
    assert all(r is not None for r in results)
    # All 10 calls must start within 1 second of each other (concurrent, not sequential)
    if len(call_times) >= 2:
        spread = max(call_times) - min(call_times)
        assert spread < 1.0, (
            f'Shard downloads spread over {spread:.2f}s -- must be concurrent, not sequential'
        )


# ============================================================
# EC4-8: Parallel download preserves shard ordering
# ============================================================

def test_ec4_parallel_download_preserves_order(dummy_config, tmp_path):
    """Results list must be in same order as input keys despite parallel execution."""
    client = make_r2_client(dummy_config)
    shard_keys = [f'weights/shard-{i:03d}.pt' for i in range(5)]

    import zlib
    compressed = zlib.compress(b'data')

    with patch.object(client._s3, 'get_object') as mock_get:
        mock_get.return_value = {'Body': MagicMock(read=MagicMock(return_value=compressed))}
        results = client.download_shards_parallel(shard_keys, str(tmp_path))

    for i, result in enumerate(results):
        assert result is not None, f'Shard {i} result is None'
        assert f'shard-{i:03d}' in result, (
            f'Result[{i}] is {result} -- ordering not preserved from parallel download'
        )


# ============================================================
# EC4-9: 1.2TB model simulation -- multipart beats put_object
# ============================================================

def test_ec4_12tb_model_uses_multipart_not_put_object(dummy_config):
    """
    Simulates the Weight Storm scenario: 1.2 TB model.
    Verifies multipart is selected and correct number of parts computed.
    Does NOT transfer real data -- just validates routing and part math.
    """
    from agents.vault.r2 import MULTIPART_CHUNK_SIZE_BYTES
    model_size_tb = 1.2
    model_size_bytes = int(model_size_tb * 1024**4)
    expected_parts = math.ceil(model_size_bytes / MULTIPART_CHUNK_SIZE_BYTES)

    # Verify the math -- should be ~20,000 parts for 1.2 TB at 64 MB each
    assert expected_parts > 1000, f'Expected >1000 parts for 1.2 TB, got {expected_parts}'
    assert expected_parts < 100000, f'Too many parts: {expected_parts}'

    # Verify the threshold routes correctly
    from agents.vault.r2 import MULTIPART_THRESHOLD_BYTES
    assert model_size_bytes > MULTIPART_THRESHOLD_BYTES, (
        '1.2 TB model must exceed threshold and use multipart upload'
    )


# ============================================================
# EC4-10: Speed calculation -- parallel vs sequential
# ============================================================

def test_ec4_parallel_speedup_math():
    """
    Theoretical speedup validation.
    Sequential 1.2 TB on 10 Gbps = ~960s (~16 min).
    8 parallel shards on same link = ~120s (~2 min). 8x speedup.
    """
    model_bytes = int(1.2 * 1024**4)
    link_gbps = 10
    link_bytes_per_sec = link_gbps * 1e9 / 8

    sequential_sec = model_bytes / link_bytes_per_sec
    parallel_workers = 8
    parallel_sec = sequential_sec / parallel_workers

    assert sequential_sec > 900, f'Sequential should take >15 min, got {sequential_sec:.0f}s'
    assert parallel_sec < 200,   f'Parallel should take <3.5 min, got {parallel_sec:.0f}s'
    speedup = sequential_sec / parallel_sec
    assert speedup == parallel_workers, f'Speedup should be {parallel_workers}x, got {speedup:.1f}x'