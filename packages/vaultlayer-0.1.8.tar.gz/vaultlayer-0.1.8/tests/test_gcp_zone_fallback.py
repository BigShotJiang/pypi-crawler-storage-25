"""Tier-1 tests: GCP cross-zone fallback + cooldown — pure logic.

Mirror of tests/test_aws_ranker_fallback.py for the GCP provider.
Every code path in gcp.py's per-zone loop has a regression test here.

Coverage map:
  * Zone pre-filter drops zones that don't offer the accelerator type
    → test_pre_filter_drops_zones_without_accelerator
  * QUOTA_EXCEEDED / ZONE_RESOURCE_POOL_EXHAUSTED trigger next-zone retry
    → test_quota_exceeded_triggers_cross_zone_retry
  * Sync insert errors route through record_failure + next zone
    → test_sync_insert_failure_cools_down_and_continues
  * Async op failure routes through record_failure + next zone
    → test_async_op_failure_cools_down_and_continues
  * primary_zone honored when it survives filtering
    → test_primary_zone_first_when_supported
  * VL_GCP_ZONE_LOCKED=1 disables fallback
    → test_zone_locked_disables_fallback
  * Instance already exists (409) returns the name (reuse path)
    → test_insert_409_alreadyexists_returns_name
  * All zones exhausted → error message lists per-zone codes
    → test_all_zones_exhausted_error_lists_codes
  * Non-cooldown errors (FORBIDDEN / NOT_FOUND) fail fast
    → test_non_cooldown_error_fails_fast
  * Happy path — insert succeeds on first zone
    → test_happy_path_first_zone_succeeds
"""
from __future__ import annotations

import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from agents.broker.providers import gcp_capacity, region_planner
from conftest import make_job


# ─────────────────────────────────────────────────────────────────────────────
# Harness: fake googleapiclient.compute that routes per-zone
# ─────────────────────────────────────────────────────────────────────────────

def _mk_op(status="DONE", error_code=None, error_msg="mocked"):
    """Build a zoneOperations response dict."""
    op = {"name": "op-test", "status": status}
    if error_code:
        op["error"] = {"errors": [{"code": error_code, "message": error_msg}]}
    return op


def _mk_accelerator_types_response(accel_name: str, present: bool):
    """Build an acceleratorTypes.list() response."""
    return {"items": [{"name": accel_name}] if present else []}


class _ZoneRouter:
    """Fake compute service where insert/op/accelerator responses vary per zone."""
    def __init__(self, *, zones_with_accel: set[str], insert_behaviors: dict):
        """
        Args:
          zones_with_accel: set of zones where acceleratorTypes reports the SKU
          insert_behaviors: {zone: ("success"|"sync_error"|"async_error", code_or_None)}
            "success"     → insert returns op, zoneOp returns DONE no error
            "sync_error"  → insert raises an Exception with the error code
            "async_error" → insert returns op, zoneOp returns DONE with error code
        """
        self.zones_with_accel = zones_with_accel
        self.insert_behaviors = insert_behaviors
        self.insert_calls: list[str] = []
        self.op_calls: list[str] = []
        self.accel_calls: list[str] = []

    def instances(self):
        outer = self
        class _Instances:
            def insert(self, project, zone, body, requestId=None):
                outer.insert_calls.append(zone)
                behavior, code = outer.insert_behaviors.get(zone, ("success", None))
                class _Req:
                    def execute(req_self):
                        if behavior == "sync_error":
                            raise Exception(f'Mocked sync error with reason "{code}"')
                        # success or async_error → return op name
                        return {"name": f"op-{zone}"}
                return _Req()
        return _Instances()

    def zoneOperations(self):
        outer = self
        class _Ops:
            def get(self, project, zone, operation):
                outer.op_calls.append(zone)
                behavior, code = outer.insert_behaviors.get(zone, ("success", None))
                class _Req:
                    def execute(req_self):
                        if behavior == "async_error":
                            return _mk_op("DONE", error_code=code)
                        return _mk_op("DONE")
                return _Req()
        return _Ops()

    def acceleratorTypes(self):
        outer = self
        class _Acc:
            def list(self, project, zone):
                outer.accel_calls.append(zone)
                class _Req:
                    def execute(req_self):
                        return _mk_accelerator_types_response(
                            "nvidia-tesla-t4",
                            zone in outer.zones_with_accel,
                        )
                return _Req()
        return _Acc()


@pytest.fixture(autouse=True)
def _reset_state(monkeypatch):
    """Wipe cross-test state and pin to a small zone list for speed."""
    gcp_capacity._offerings_cache.clear()
    region_planner._cooldown.clear()
    # Trim the candidate zone list so tests don't iterate all 22 T4 zones
    monkeypatch.setattr(
        gcp_capacity, "ZONE_CANDIDATES",
        {"nvidia-tesla-t4": [
            "us-central1-a", "us-central1-b", "us-east1-c", "us-west1-b",
        ]},
    )
    yield


@pytest.fixture
def gcp_broker(dummy_config, mock_queue):
    from shared.config import GCPConfig
    from agents.broker.agent import BrokerAgent
    dummy_config.gcp = GCPConfig(
        service_account_json="/tmp/fake-sa.json",
        project_id="vl-test",
        zone="us-central1-a",
    )
    return BrokerAgent(config=dummy_config, queue=mock_queue)


async def _provision(broker, router: _ZoneRouter):
    """Invoke provision_gcp with the router as the mocked compute service."""
    from shared.models import GPUType

    mock_sa_module = MagicMock()
    mock_sa_module.Credentials.from_service_account_file.return_value = MagicMock()
    mock_sa_module.Credentials.from_service_account_info.return_value = MagicMock()

    mock_discovery = MagicMock()
    mock_discovery.build.return_value = router

    mock_g_oauth2 = MagicMock()
    mock_g_oauth2.service_account = mock_sa_module

    mock_gapiclient = MagicMock()
    mock_gapiclient.discovery = mock_discovery

    with patch.dict("sys.modules", {
        "google":                         MagicMock(),
        "google.auth":                    MagicMock(),
        "google.oauth2":                  mock_g_oauth2,
        "google.oauth2.service_account":  mock_sa_module,
        "googleapiclient":                mock_gapiclient,
        "googleapiclient.discovery":      mock_discovery,
    }), patch("asyncio.sleep", new_callable=AsyncMock):
        instance_id = await broker.provision_gcp(GPUType.A10G, make_job())
    return instance_id


# ═════════════════════════════════════════════════════════════════════════════
# Tests
# ═════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_happy_path_first_zone_succeeds(gcp_broker):
    """Baseline: when first zone works, we land there immediately."""
    router = _ZoneRouter(
        zones_with_accel={"us-central1-a", "us-central1-b", "us-east1-c", "us-west1-b"},
        insert_behaviors={"us-central1-a": ("success", None)},
    )
    instance_id = await _provision(gcp_broker, router)
    assert instance_id is not None
    assert router.insert_calls == ["us-central1-a"], \
        f"should only attempt primary zone on success, got {router.insert_calls}"


@pytest.mark.asyncio
async def test_pre_filter_drops_zones_without_accelerator(gcp_broker):
    """BUG: if acceleratorTypes.list() says no SKU, we should NOT call insert."""
    router = _ZoneRouter(
        zones_with_accel={"us-west1-b"},  # only us-west1-b has T4
        insert_behaviors={"us-west1-b": ("success", None)},
    )
    instance_id = await _provision(gcp_broker, router)
    assert instance_id is not None
    # Only us-west1-b should have had insert called — other 3 zones pre-filtered
    assert router.insert_calls == ["us-west1-b"], \
        f"zones without accel must be skipped, got insert_calls={router.insert_calls}"


@pytest.mark.asyncio
async def test_quota_exceeded_triggers_cross_zone_retry(gcp_broker):
    """BUG check: QUOTA_EXCEEDED must continue to next zone, not hard-fail."""
    router = _ZoneRouter(
        zones_with_accel={"us-central1-a", "us-central1-b", "us-east1-c", "us-west1-b"},
        insert_behaviors={
            "us-central1-a": ("async_error", "QUOTA_EXCEEDED"),
            "us-central1-b": ("async_error", "QUOTA_EXCEEDED"),
            "us-east1-c":    ("success", None),
        },
    )
    instance_id = await _provision(gcp_broker, router)
    assert instance_id is not None, "should land in us-east1-c after two QUOTA_EXCEEDED"
    assert router.insert_calls[:3] == ["us-central1-a", "us-central1-b", "us-east1-c"]


@pytest.mark.asyncio
async def test_zone_resource_pool_exhausted_triggers_retry(gcp_broker):
    """ZONE_RESOURCE_POOL_EXHAUSTED is a transient capacity error — retry."""
    router = _ZoneRouter(
        zones_with_accel={"us-central1-a", "us-central1-b", "us-east1-c", "us-west1-b"},
        insert_behaviors={
            "us-central1-a": ("async_error", "ZONE_RESOURCE_POOL_EXHAUSTED"),
            "us-central1-b": ("success", None),
        },
    )
    instance_id = await _provision(gcp_broker, router)
    assert instance_id is not None
    assert router.insert_calls[:2] == ["us-central1-a", "us-central1-b"]


@pytest.mark.asyncio
async def test_sync_insert_failure_cools_down_and_continues(gcp_broker):
    """Sync-path insert errors must also apply cooldown + continue."""
    router = _ZoneRouter(
        zones_with_accel={"us-central1-a", "us-central1-b", "us-east1-c", "us-west1-b"},
        insert_behaviors={
            "us-central1-a": ("sync_error", "QUOTA_EXCEEDED"),
            "us-central1-b": ("success", None),
        },
    )
    instance_id = await _provision(gcp_broker, router)
    assert instance_id is not None
    assert router.insert_calls[:2] == ["us-central1-a", "us-central1-b"]
    # Cooldown recorded for us-central1-a
    assert region_planner.is_in_cooldown("gcp", "us-central1-a")


@pytest.mark.asyncio
async def test_async_op_failure_cools_down_and_continues(gcp_broker):
    """Async op error (DONE with error body) must apply cooldown + continue."""
    router = _ZoneRouter(
        zones_with_accel={"us-central1-a", "us-central1-b", "us-east1-c", "us-west1-b"},
        insert_behaviors={
            "us-central1-a": ("async_error", "ZONE_RESOURCE_POOL_EXHAUSTED"),
            "us-central1-b": ("success", None),
        },
    )
    instance_id = await _provision(gcp_broker, router)
    assert instance_id is not None
    assert region_planner.is_in_cooldown("gcp", "us-central1-a")


def test_primary_zone_first_when_supported():
    """primary_zone pin: must be attempted first when it passes the pre-filter."""
    def _factory(_z):
        # fake compute: accelerator available in all
        return _ZoneRouter(
            zones_with_accel={"us-central1-a", "us-west1-b", "us-east1-c"},
            insert_behaviors={},
        )
    ordered, dropped = gcp_capacity.rank_zones(
        candidate_zones=["us-east1-c", "us-west1-b", "us-central1-a"],
        accel_type="nvidia-tesla-t4",
        compute=_factory("x"),
        project_id="vl-test",
        primary_zone="us-central1-a",
    )
    assert ordered[0] == "us-central1-a", \
        f"primary zone must be first, got {ordered}"


@pytest.mark.asyncio
async def test_zone_locked_disables_fallback(gcp_broker, monkeypatch):
    """VL_GCP_ZONE_LOCKED=1 → single-zone only, no fallback."""
    monkeypatch.setenv("VL_GCP_ZONE_LOCKED", "1")
    router = _ZoneRouter(
        zones_with_accel=set(),  # would pre-filter if fallback was on
        insert_behaviors={"us-central1-a": ("async_error", "QUOTA_EXCEEDED")},
    )
    instance_id = await _provision(gcp_broker, router)
    assert instance_id is None
    # Only one zone attempted (primary)
    assert router.insert_calls == ["us-central1-a"], \
        f"zone-locked should try only primary, got {router.insert_calls}"


@pytest.mark.asyncio
async def test_zone_cap_limits_iteration_to_5(gcp_broker, monkeypatch):
    """zones_to_try must be capped at 5 post-rank so the per-zone loop
    fits under the worker's 150s wait_for budget. Without the cap, T4 (22
    zones) and A100 (10 zones) worst-case iteration at ~25s/zone blows
    past 150s — broker cancels _try_provision mid-flight and surfaces
    "GCP: provision timed out after 150s" (seen on 2026-04-20 A10G job
    44e3a52b)."""
    # Expand ZONE_CANDIDATES to 8 zones so we can observe the cap
    monkeypatch.setattr(
        gcp_capacity, "ZONE_CANDIDATES",
        {"nvidia-tesla-t4": [
            "us-central1-a", "us-central1-b", "us-central1-c", "us-central1-f",
            "us-east1-c", "us-east1-d",
            "us-west1-a", "us-west1-b",
        ]},
    )
    router = _ZoneRouter(
        zones_with_accel={"us-central1-a", "us-central1-b", "us-central1-c",
                          "us-central1-f", "us-east1-c", "us-east1-d",
                          "us-west1-a", "us-west1-b"},
        # Every zone fails with a cooldown-worthy code → loop iterates to the cap
        insert_behaviors={
            z: ("async_error", "QUOTA_EXCEEDED") for z in [
                "us-central1-a", "us-central1-b", "us-central1-c",
                "us-central1-f", "us-east1-c", "us-east1-d",
                "us-west1-a", "us-west1-b",
            ]
        },
    )
    instance_id = await _provision(gcp_broker, router)
    assert instance_id is None
    assert len(router.insert_calls) <= 5, \
        f"zone loop must cap at 5 attempts, iterated {len(router.insert_calls)}"


@pytest.mark.asyncio
async def test_insert_409_alreadyexists_returns_name(gcp_broker):
    """Pre-existing instance (alreadyExists) should be reused, not fail."""
    router = _ZoneRouter(
        zones_with_accel={"us-central1-a", "us-central1-b", "us-east1-c", "us-west1-b"},
        insert_behaviors={"us-central1-a": ("sync_error", "alreadyExists")},
    )
    instance_id = await _provision(gcp_broker, router)
    assert instance_id is not None, "instance already exists → should return name"
    assert "vl-" in instance_id


@pytest.mark.asyncio
async def test_all_zones_exhausted_error_lists_codes(gcp_broker):
    """When every zone fails, error message must enumerate per-zone codes."""
    router = _ZoneRouter(
        zones_with_accel={"us-central1-a", "us-central1-b", "us-east1-c", "us-west1-b"},
        insert_behaviors={
            "us-central1-a": ("async_error", "QUOTA_EXCEEDED"),
            "us-central1-b": ("async_error", "ZONE_RESOURCE_POOL_EXHAUSTED"),
            "us-east1-c":    ("async_error", "STOCKOUT"),
            "us-west1-b":    ("async_error", "QUOTA_EXCEEDED"),
        },
    )
    from shared.models import GPUType

    job = make_job()
    mock_sa_module = MagicMock()
    mock_sa_module.Credentials.from_service_account_file.return_value = MagicMock()
    mock_discovery = MagicMock()
    mock_discovery.build.return_value = router
    mock_g_oauth2 = MagicMock()
    mock_g_oauth2.service_account = mock_sa_module

    with patch.dict("sys.modules", {
        "google": MagicMock(), "google.auth": MagicMock(),
        "google.oauth2": mock_g_oauth2, "google.oauth2.service_account": mock_sa_module,
        "googleapiclient": MagicMock(discovery=mock_discovery),
        "googleapiclient.discovery": mock_discovery,
    }), patch("asyncio.sleep", new_callable=AsyncMock):
        instance_id = await gcp_broker.provision_gcp(GPUType.A10G, job)

    assert instance_id is None
    err = job.last_provision_error or ""
    for zone, code in [
        ("us-central1-a", "QUOTA_EXCEEDED"),
        ("us-central1-b", "ZONE_RESOURCE_POOL_EXHAUSTED"),
        ("us-east1-c",    "STOCKOUT"),
        ("us-west1-b",    "QUOTA_EXCEEDED"),
    ]:
        assert f"{zone}:{code}" in err, f"missing {zone}:{code} in: {err}"


@pytest.mark.asyncio
async def test_non_cooldown_error_fails_fast(gcp_broker):
    """FORBIDDEN / NOT_FOUND errors should not iterate — fail on first zone."""
    router = _ZoneRouter(
        zones_with_accel={"us-central1-a", "us-central1-b", "us-east1-c", "us-west1-b"},
        insert_behaviors={"us-central1-a": ("sync_error", "403")},
    )
    instance_id = await _provision(gcp_broker, router)
    assert instance_id is None
    assert router.insert_calls == ["us-central1-a"], \
        f"non-retryable error should fail on first zone; got {router.insert_calls}"
