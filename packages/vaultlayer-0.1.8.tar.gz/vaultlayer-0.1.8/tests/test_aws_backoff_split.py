"""Sprint-1 PR A: pins the quota-vs-capacity cooldown split.

AWS support confirmed that MaxSpotInstanceCountExceeded / VcpuLimitExceeded
(quota-class) and InsufficientInstanceCapacity (capacity-class) need
different backoff strategies:
  - Quota: require manual intervention → long cooldown (1h)
  - Capacity: may clear in minutes → short cooldown (10min)

Previously our code treated both identically with a 10-min cooldown,
burning API calls against accounts whose quota was at 0 and would stay
that way until an increase was granted.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import pytest


@pytest.fixture(autouse=True)
def _clean_cooldown_table():
    """Each test starts from a fresh cooldown table."""
    from agents.broker.providers import region_planner
    region_planner._cooldown.clear()
    yield
    region_planner._cooldown.clear()


class TestQuotaClassCooldown:
    """Quota errors → 1h cooldown (would be nonsensical to retry in 10min
    since the account's quota won't magically change)."""

    def test_max_spot_gets_1h_cooldown(self):
        from agents.broker.providers import aws_capacity, region_planner
        t0 = time.time()
        aws_capacity.record_failure("us-east-1", "MaxSpotInstanceCountExceeded")
        expires = region_planner._cooldown[("aws", "us-east-1")]
        # 1h ± a few seconds for clock wobble
        assert 3590 <= expires - t0 <= 3610, (
            f"Expected ~1h cooldown, got {expires - t0:.0f}s"
        )

    def test_vcpu_limit_gets_1h_cooldown(self):
        from agents.broker.providers import aws_capacity, region_planner
        t0 = time.time()
        aws_capacity.record_failure("us-west-2", "VcpuLimitExceeded")
        expires = region_planner._cooldown[("aws", "us-west-2")]
        assert 3590 <= expires - t0 <= 3610

    def test_instance_limit_gets_1h_cooldown(self):
        from agents.broker.providers import aws_capacity, region_planner
        t0 = time.time()
        aws_capacity.record_failure("eu-west-1", "InstanceLimitExceeded")
        expires = region_planner._cooldown[("aws", "eu-west-1")]
        assert 3590 <= expires - t0 <= 3610


class TestCapacityClassCooldown:
    """Capacity errors → 10min cooldown (spot supply can re-appear
    within minutes when demand drops)."""

    def test_insufficient_capacity_gets_10min_cooldown(self):
        from agents.broker.providers import aws_capacity, region_planner
        t0 = time.time()
        aws_capacity.record_failure("us-east-1", "InsufficientInstanceCapacity")
        expires = region_planner._cooldown[("aws", "us-east-1")]
        assert 590 <= expires - t0 <= 610, (
            f"Expected ~10min cooldown, got {expires - t0:.0f}s"
        )

    def test_spot_max_price_gets_10min_cooldown(self):
        from agents.broker.providers import aws_capacity, region_planner
        t0 = time.time()
        aws_capacity.record_failure("us-west-2", "SpotMaxPriceTooLow")
        expires = region_planner._cooldown[("aws", "us-west-2")]
        assert 590 <= expires - t0 <= 610


class TestUnrelatedErrors:
    """Non-cooldown errors (AccessDenied, etc.) must NOT enter cooldown —
    waiting doesn't fix auth issues."""

    def test_access_denied_no_cooldown(self):
        from agents.broker.providers import aws_capacity, region_planner
        aws_capacity.record_failure("us-east-1", "AccessDenied")
        assert ("aws", "us-east-1") not in region_planner._cooldown

    def test_unknown_error_no_cooldown(self):
        from agents.broker.providers import aws_capacity, region_planner
        aws_capacity.record_failure("us-east-1", "Error")
        assert ("aws", "us-east-1") not in region_planner._cooldown


class TestBackwardCompatCooldownErrorCodes:
    """COOLDOWN_ERROR_CODES is still exported as a union — check that
    it contains all 5 codes and other providers' code paths still see
    it as a single tuple."""

    def test_union_contains_all_five(self):
        from agents.broker.providers import aws_capacity
        assert "MaxSpotInstanceCountExceeded" in aws_capacity.COOLDOWN_ERROR_CODES
        assert "VcpuLimitExceeded" in aws_capacity.COOLDOWN_ERROR_CODES
        assert "InstanceLimitExceeded" in aws_capacity.COOLDOWN_ERROR_CODES
        assert "InsufficientInstanceCapacity" in aws_capacity.COOLDOWN_ERROR_CODES
        assert "SpotMaxPriceTooLow" in aws_capacity.COOLDOWN_ERROR_CODES

    def test_union_is_tuple(self):
        from agents.broker.providers import aws_capacity
        assert isinstance(aws_capacity.COOLDOWN_ERROR_CODES, tuple)
        assert len(aws_capacity.COOLDOWN_ERROR_CODES) == 5


class TestOtherProvidersUnaffected:
    """GCP/Azure/etc. use region_planner.record_failure directly, without
    the cooldown_seconds arg — make sure that path still uses the 10min
    default and isn't broken by the new parameter."""

    def test_gcp_record_failure_uses_default_cooldown(self):
        from agents.broker.providers import region_planner
        t0 = time.time()
        region_planner.record_failure(
            provider="gcp",
            region="us-central1-a",
            error_code="QUOTA_EXCEEDED",
            cooldown_error_codes=("QUOTA_EXCEEDED", "ZONE_RESOURCE_POOL_EXHAUSTED"),
            # No cooldown_seconds kwarg — should use default 600s
        )
        expires = region_planner._cooldown[("gcp", "us-central1-a")]
        assert 590 <= expires - t0 <= 610
