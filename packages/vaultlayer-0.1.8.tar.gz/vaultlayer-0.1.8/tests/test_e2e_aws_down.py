"""
VaultLayer — "AWS Goes Down" End-to-End Test Suite
===================================================

Simulates the full agent pipeline for every destination provider when
an AWS Spot instance is preempted.

Full pipeline tested (no shortcuts — real agent logic runs end-to-end):

  1. Watchdog.handle_termination()     — 2-min spot notice received
        ↓  publishes TERMINATION_SIGNAL
  2. Orchestration.handle_event()      — reads price cache, picks target
        ↓  publishes MIGRATION_REQUESTED to broker
  3. Broker.execute_migration()        — STONITH fence → provision → NODE_PROVISIONED
        ↓  publishes MIGRATION_COMPLETE
  4. Watchdog re-attaches heartbeat    — new node monitored (GAP-8)

Mocked at the network boundary only:
  • provider REST APIs (provision_*)      — returns fake instance ID
  • asyncio.sleep                         — instant
  • log_event                             — no-op
  • price_guard / capacity               — disabled in test

The test also captures the EXACT API payload sent to each provider
so you can inspect what VaultLayer would actually PUT to RunPod,
POST to Lambda Labs, etc.
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import contextlib
import pytest
from unittest.mock import patch, AsyncMock, MagicMock, call

from conftest import MockAgentQueue, make_job
from shared.models import (
    AgentEvent, EventType, Job, JobStatus, Provider, GPUType
)
from shared.config import (
    VaultLayerConfig, AWSConfig, LambdaLabsConfig, CoreWeaveConfig,
    CloudflareConfig, RedisConfig, AnthropicConfig,
)


# ── Shared fixtures ───────────────────────────────────────────────────────────

def _cfg():
    cfg = VaultLayerConfig(
        token="vl_test_" + "a" * 64,
        user_id="e2e-user",
        aws=AWSConfig(
            access_key_id="AK_E2E",
            secret_access_key="SK_E2E",
            region="us-east-1",
        ),
        lambda_labs=LambdaLabsConfig(api_key="ll-e2e-key"),
        coreweave=CoreWeaveConfig(api_key="cw-e2e-key", namespace="e2e-ns"),
        cloudflare=CloudflareConfig(
            account_id="e2e-cf-acct",
            r2_access_key_id="R2_E2E_KEY",
            r2_secret_access_key="R2_E2E_SECRET",
            r2_bucket="vl-e2e-checkpoints",
            r2_endpoint="https://e2e-acct.r2.cloudflarestorage.com",
        ),
        redis=RedisConfig(url="redis://localhost:6379"),
        anthropic=AnthropicConfig(api_key="ant-e2e-key"),
    )
    # Attach all provider configs
    for attr, key in [
        ("runpod",        "rp-e2e-key"),
        ("vast_ai",       "vast-e2e-key"),
        ("voltage_park",  "vp-e2e-key"),
        ("crusoe",        "crusoe-e2e-key"),
        ("nebius",        "nebius-e2e-key"),
        ("hyperstack",    "hs-e2e-key"),
    ]:
        m = MagicMock(); m.api_key = key
        setattr(cfg, attr, m)
    gcp = MagicMock()
    gcp.service_account_json = "/fake/sa.json"
    gcp.project_id = "vl-e2e"; gcp.zone = "us-central1-a"
    cfg.gcp = gcp
    az = MagicMock()
    az.tenant_id = "t"; az.client_id = "c"
    az.client_secret = "s"; az.subscription_id = "sub"
    az.resource_group = "rg"; az.location = "eastus"
    cfg.azure = az
    return cfg


def _aws_job():
    """A training job currently running on AWS Spot."""
    j = Job(
        job_id="e2e-aws-job-001",
        name="Llama-3 Fine-tune (AWS Spot)",
        status=JobStatus.RUNNING,
        provider=Provider.AWS,
        gpu_type=GPUType.H100_80GB_SXM,
        instance_id="i-aws-spot-0001",
        region="us-east-1",
        model_params_billion=7.0,
        command="torchrun --nproc_per_node=8 train.py",
        docker_image="pytorch/pytorch:2.3-cuda12.1",
        dataset_id="ds-openwebtext",
        environment={"BATCH_SIZE": "128", "LR": "2e-5"},
        current_step=12500,
        user_id="e2e-user",
    )
    return j


# Price cache: AWS @ $3.20/hr is the "current" provider.
# The target being tested is set cheaper so orchestration picks it.
AWS_PRICE = 3.20

def _price_cache(target_provider: str, target_gpu: str, target_price: float) -> list:
    """Build a minimal price cache with AWS (current) and target cheaper."""
    return [
        {
            "provider": "aws",
            "gpu": "H100_80GB_SXM",
            "price_per_hour": AWS_PRICE,
            "availability": "available",
            "region": "us-east-1",
        },
        {
            "provider": target_provider,
            "gpu": target_gpu,
            "price_per_hour": target_price,
            "availability": "available",
        },
    ]


def _published_types(queue, channel):
    return [
        e.event_type
        for (ch, e) in queue.published
        if ch == channel or ch == f"critical:{channel}"
    ]


def _event_payload(queue, channel, event_type):
    """First matching payload."""
    for (ch, e) in queue.published:
        if (ch == channel or ch == f"critical:{channel}") and e.event_type == event_type:
            return e.payload
    return None


# ── The destination matrix ────────────────────────────────────────────────────

DESTINATIONS = [
    # label           provider               provision_method         new_id                  price
    ("AWS Spot",     Provider.AWS,           "provision_aws",         "i-aws-new-0001",        2.40),
    ("Lambda Labs",  Provider.LAMBDA_LABS,   "provision_lambda",      "ll-inst-0001",           1.89),
    ("CoreWeave",    Provider.COREWEAVE,     "provision_coreweave",   "cw-vm-0001",             1.95),
    ("GCP",          Provider.GCP,           "provision_gcp",         "vl-gcp-0001",            2.10),
    ("Azure",        Provider.AZURE,         "provision_azure",       "vl-az-0001/10.0.0.1",   2.15),
    ("RunPod",       Provider.RUNPOD,        "provision_runpod",      "rp-pod-0001",            1.79),
    ("Vast.ai",      Provider.VAST_AI,       "provision_vast",        "vast-inst-0001",         1.65),
    ("Voltage Park", Provider.VOLTAGE_PARK,  "provision_voltage_park","vp-inst-0001",           2.00),
    ("Crusoe",       Provider.CRUSOE,        "provision_crusoe",      "crusoe-inst-0001",       2.05),
    ("Nebius",       Provider.NEBIUS,        "provision_nebius",      "nebius-inst-0001",       1.99),
    ("Hyperstack",   Provider.HYPERSTACK,    "provision_hyperstack",  "hs-vm-0001",             2.08),
]

DEST_IDS = [row[0] for row in DESTINATIONS]


# ── Test 1: Full pipeline — agent chain (watchdog → orch → broker) ────────────

@pytest.mark.asyncio
@pytest.mark.parametrize(
    "label,target_provider,provision_method,new_instance_id,target_price",
    DESTINATIONS,
    ids=DEST_IDS,
)
async def test_aws_down_full_pipeline(
    label, target_provider, provision_method, new_instance_id, target_price
):
    """
    Full 4-stage pipeline: AWS spot terminates → orchestration picks target →
    broker provisions → watchdog re-attaches.

    Every external network call is mocked; all agent logic runs for real.
    """
    from agents.watchdog.agent import WatchdogAgent
    from agents.orchestration.agent import OrchestrationAgent
    from agents.broker.agent import BrokerAgent

    cfg = _cfg()
    queue = MockAgentQueue()
    job = _aws_job()

    # Seed price cache so orchestration picks target_provider
    queue._price_cache = _price_cache(
        target_provider.value, "H100_80GB_SXM", target_price
    )

    dog   = WatchdogAgent(config=cfg, queue=queue)
    orch  = OrchestrationAgent(config=cfg, queue=queue)
    broker = BrokerAgent(config=cfg, queue=queue)

    # Register the job with watchdog and orchestration
    checkpoint_calls = []
    async def _fake_checkpoint(j):
        checkpoint_calls.append(j.job_id)

    dog.register_job(job, _fake_checkpoint)
    orch.register_job(job)

    provision_mock = AsyncMock(return_value=new_instance_id)
    fence_mock = AsyncMock()

    with contextlib.ExitStack() as stack:
        stack.enter_context(patch.object(broker, provision_method, provision_mock))
        stack.enter_context(patch.object(broker, "_fence_old_node", fence_mock))
        stack.enter_context(patch.object(broker, "_check_quota", AsyncMock(return_value=True)))
        stack.enter_context(patch.object(broker, "_resolve_instance_host", AsyncMock(return_value="")))
        stack.enter_context(patch.object(broker, "_try_same_provider_different_az", AsyncMock(return_value=None)))
        stack.enter_context(patch.object(broker, "_wait_for_ssh", AsyncMock(return_value=True)))
        stack.enter_context(patch.object(broker, "_wait_for_bootstrap", AsyncMock(return_value=True)))
        stack.enter_context(patch.object(broker, "_prefetch_checkpoint", AsyncMock()))
        stack.enter_context(patch.object(broker, "_restart_job_on_node", AsyncMock(return_value=True)))
        stack.enter_context(patch("agents.broker.migration.asyncio.sleep", new_callable=AsyncMock))
        stack.enter_context(patch("agents.broker.migration.log_event", new_callable=AsyncMock))
        stack.enter_context(patch("agents.broker.migration._PRICE_GUARD", False))
        stack.enter_context(patch("agents.broker.migration._HAS_CAPACITY", False))

        # ── Stage 1: AWS spot termination notice ──────────────────────────────
        await dog.handle_termination(
            job,
            signal_type="aws_spot_termination",
            termination_time="2026-04-02T12:00:00Z",
        )

        # Watchdog must have triggered emergency checkpoint
        assert job.job_id in checkpoint_calls, \
            f"[{label}] Emergency checkpoint not triggered on spot termination"

        # ── Stage 2: Orchestration decides where to go ────────────────────────
        termination_event = next(
            e for (ch, e) in queue.published
            if ch == "watchdog" and e.event_type == EventType.TERMINATION_SIGNAL
        )
        await orch.handle_event(termination_event)

        # Orchestration must have issued MIGRATION_REQUESTED
        orch_types = _published_types(queue, "orchestration")
        assert EventType.MIGRATION_REQUESTED in orch_types, \
            f"[{label}] Orchestration did not publish MIGRATION_REQUESTED"

        migration_req = _event_payload(queue, "orchestration", EventType.MIGRATION_REQUESTED)
        assert migration_req is not None
        assert migration_req["target_provider"] == target_provider.value, \
            f"[{label}] Orchestration picked wrong target: {migration_req['target_provider']!r}"

        # ── Stage 3: Broker provisions on target ──────────────────────────────
        await broker.execute_migration(
            job=job,
            target_provider=target_provider,
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id="e2e-decision-001",
            event_type="termination_signal",  # spot → no fence (already dead)
        )

    # ── Assertions ────────────────────────────────────────────────────────────

    # A: New node provisioned on target
    provision_mock.assert_called_once()
    assert job.instance_id == new_instance_id, \
        f"[{label}] job.instance_id not updated — got {job.instance_id!r}"
    assert job.provider == target_provider, \
        f"[{label}] job.provider not updated to target"

    # B: STONITH skipped (spot already dead), but provision still ran
    fence_mock.assert_not_called()

    # C: Full event trail
    broker_types = _published_types(queue, "broker")
    assert EventType.MIGRATION_STARTED in broker_types
    assert EventType.MIGRATION_COMPLETE in broker_types

    # Rule 3: Broker publishes NODE_PROVISIONED to "broker"; OrchestrationAgent
    # forwards it to "orchestration" so VaultAgent can trigger restore.
    assert EventType.NODE_PROVISIONED in broker_types, \
        f"[{label}] NODE_PROVISIONED not published — Vault restore won't trigger"

    # D: NODE_PROVISIONED carries restore command + dataset_id
    np_payload = _event_payload(queue, "broker", EventType.NODE_PROVISIONED)
    assert np_payload["command"] == "restore"
    assert np_payload["dataset_id"] == "ds-openwebtext"

    # E: MIGRATION_COMPLETE names the target
    mc_payload = _event_payload(queue, "broker", EventType.MIGRATION_COMPLETE)
    assert mc_payload["target_provider"] == target_provider.value
    assert mc_payload["instance_id"] == new_instance_id

    # F: Watchdog re-attaches on new node (GAP-8)
    await dog.handle_node_provisioned(AgentEvent(
        event_type=EventType.NODE_PROVISIONED,
        source_agent="broker_agent",
        job_id=job.job_id,
        payload={
            "reattach_watchdog": True,
            "new_instance_id": new_instance_id,
            "new_provider": target_provider.value,
        },
    ))
    assert job.job_id in dog._heartbeat._last_heartbeats, \
        f"[{label}] Watchdog heartbeat not re-registered on {label} after migration"


# ── Test 2: Bootstrap payload inspection ─────────────────────────────────────
#
# Verifies the exact bootstrap content delivered to each provider's API.

@pytest.mark.asyncio
@pytest.mark.parametrize(
    "label,target_provider,provision_method,new_instance_id,target_price",
    DESTINATIONS,
    ids=DEST_IDS,
)
async def test_bootstrap_on_new_node(
    label, target_provider, provision_method, new_instance_id, target_price
):
    """
    After AWS goes down and broker picks target_provider, the bootstrap
    script delivered to that node must have rclone + R2 creds + dataset.

    This is the 'can RunPod actually load the checkpoint?' test.
    """
    import base64
    from agents.broker.agent import BrokerAgent

    cfg = _cfg()
    queue = MockAgentQueue()
    job = _aws_job()
    broker = BrokerAgent(cfg, queue)

    # Build the script directly (same call broker makes internally)
    if target_provider in (Provider.RUNPOD, Provider.VAST_AI):
        script = broker._build_container_onstart(job)
    elif target_provider == Provider.AWS:
        script = base64.b64decode(broker._build_userdata(job)).decode()
    else:
        script = broker._build_vm_startup_script(job)

    # Every provider must have R2 wired in — the new node NEEDS this to
    # read the checkpoint and start training
    assert "rclone" in script, \
        f"[{label}] bootstrap missing rclone — checkpoint restore will fail"
    assert "R2_E2E_KEY" in script, \
        f"[{label}] bootstrap missing R2 access key — can't mount checkpoint store"
    assert "R2_E2E_SECRET" in script, \
        f"[{label}] bootstrap missing R2 secret — can't mount checkpoint store"
    assert "e2e-acct.r2.cloudflarestorage.com" in script, \
        f"[{label}] bootstrap missing R2 endpoint"
    assert "/mnt/vaultlayer" in script, \
        f"[{label}] bootstrap missing /mnt/vaultlayer mount point"
    assert "ds-openwebtext" in script, \
        f"[{label}] bootstrap missing dataset copy — training data won't be on node"
    # Container onstart uses single-quoted values (KEY='value'), VM uses unquoted
    assert "VAULTLAYER_JOB_ID=" in script and "e2e-aws-job-001" in script, \
        f"[{label}] bootstrap missing job ID env var"
    assert "BATCH_SIZE=" in script and "128" in script, \
        f"[{label}] bootstrap missing user env vars"
    assert "LR=" in script and "2e-5" in script, \
        f"[{label}] bootstrap missing user env vars"


# ── Test 3: Orchestration picks cheapest available ────────────────────────────

@pytest.mark.asyncio
async def test_orchestration_picks_cheapest_after_aws_down():
    """
    When AWS goes down, orchestration scans the price cache and picks
    the globally cheapest provider — not a hardcoded fallback.
    """
    from agents.orchestration.agent import OrchestrationAgent

    cfg = _cfg()
    queue = MockAgentQueue()
    job = _aws_job()

    # Price cache: multiple alternatives, Vast.ai is cheapest
    queue._price_cache = [
        {"provider": "aws",          "gpu": "H100_80GB_SXM", "price_per_hour": 3.20, "availability": "available", "region": "us-east-1"},
        {"provider": "lambda_labs",  "gpu": "H100_80GB_SXM", "price_per_hour": 1.89, "availability": "available"},
        {"provider": "runpod",       "gpu": "H100_80GB_SXM", "price_per_hour": 1.79, "availability": "available"},
        {"provider": "vast_ai",      "gpu": "H100_80GB_SXM", "price_per_hour": 1.65, "availability": "available"},  # cheapest
        {"provider": "crusoe",       "gpu": "H100_80GB_SXM", "price_per_hour": 2.05, "availability": "available"},
        {"provider": "nebius",       "gpu": "H100_80GB_SXM", "price_per_hour": 1.99, "availability": "available"},
    ]

    orch = OrchestrationAgent(config=cfg, queue=queue)
    orch.register_job(job)

    termination_event = AgentEvent(
        event_type=EventType.TERMINATION_SIGNAL,
        source_agent="watchdog_agent",
        job_id=job.job_id,
        payload={
            "reason": "aws_spot_termination",
            "termination_time": "2026-04-02T12:00:00Z",
            "checkpoint_success": True,
            "current_step": 12500,
            "requires_migration": True,
        },
        priority=1,
    )
    await orch.handle_event(termination_event)

    req_payload = _event_payload(queue, "orchestration", EventType.MIGRATION_REQUESTED)
    assert req_payload is not None, "Orchestration must publish MIGRATION_REQUESTED"
    assert req_payload["target_provider"] == "vast_ai", \
        f"Orchestration must pick cheapest (vast_ai @ $1.65) not {req_payload['target_provider']!r}"


# ── Test 4: Voluntary STONITH before provision (arbitrage path) ────────────────

@pytest.mark.asyncio
@pytest.mark.parametrize(
    "label,target_provider,provision_method,new_instance_id,target_price",
    DESTINATIONS,
    ids=DEST_IDS,
)
async def test_voluntary_migration_fences_old_node(
    label, target_provider, provision_method, new_instance_id, target_price
):
    """
    For voluntary migrations (cost arbitrage, not spot preemption),
    STONITH must fire BEFORE the new node is provisioned.
    This prevents split-brain checkpoint writes to R2.
    """
    from agents.broker.agent import BrokerAgent

    cfg = _cfg()
    queue = MockAgentQueue()
    job = _aws_job()
    broker = BrokerAgent(cfg, queue)

    fence_order = []
    provision_order = []

    async def _fake_fence(j):
        fence_order.append("fence")

    async def _fake_provision(*args, **kwargs):
        provision_order.append("provision")
        return new_instance_id

    with contextlib.ExitStack() as stack:
        stack.enter_context(patch.object(broker, provision_method, _fake_provision))
        stack.enter_context(patch.object(broker, "_fence_old_node", _fake_fence))
        stack.enter_context(patch.object(broker, "_check_quota", AsyncMock(return_value=True)))
        stack.enter_context(patch.object(broker, "_resolve_instance_host", AsyncMock(return_value="")))
        stack.enter_context(patch.object(broker, "_try_same_provider_different_az", AsyncMock(return_value=None)))
        stack.enter_context(patch.object(broker, "_wait_for_ssh", AsyncMock(return_value=True)))
        stack.enter_context(patch.object(broker, "_wait_for_bootstrap", AsyncMock(return_value=True)))
        stack.enter_context(patch.object(broker, "_prefetch_checkpoint", AsyncMock()))
        stack.enter_context(patch.object(broker, "_restart_job_on_node", AsyncMock(return_value=True)))
        stack.enter_context(patch("agents.broker.migration.asyncio.sleep", new_callable=AsyncMock))
        stack.enter_context(patch("agents.broker.migration.log_event", new_callable=AsyncMock))
        stack.enter_context(patch("agents.broker.migration._PRICE_GUARD", False))
        stack.enter_context(patch("agents.broker.migration._HAS_CAPACITY", False))

        await broker.execute_migration(
            job=job,
            target_provider=target_provider,
            target_gpu=GPUType.H100_80GB_SXM,
            decision_id="arbitrage-decision-001",
            event_type="arbitrage_opportunity",  # voluntary — STONITH must fire
        )

    assert fence_order, f"[{label}] STONITH must fire for voluntary arbitrage migration"
    assert provision_order, f"[{label}] Provision must run after fence"
    assert fence_order[0] == "fence" and provision_order[0] == "provision"

    combined = fence_order + provision_order
    assert combined.index("fence") < combined.index("provision"), \
        f"[{label}] STONITH must occur before provision (split-brain guard)"


# ── Test 5: All providers have a dispatch branch in execute_migration ─────────

def test_all_providers_have_dispatch_branch():
    """
    _provision_on() inside execute_migration must have a branch for every
    Provider enum value.  A missing branch silently returns None and causes
    all provision attempts to fail → escalation → user sees ACTION REQUIRED.
    """
    import inspect
    from agents.broker.migration import execute_migration
    from shared.models import Provider

    src = inspect.getsource(execute_migration)
    missing = []
    for p in Provider:
        # Check for Provider.XYZ or provision_xyz in the dispatch block
        if f"Provider.{p.name}" not in src and f"provision_{p.value}" not in src:
            missing.append(p.value)

    assert not missing, \
        f"Missing dispatch branches in execute_migration for: {missing}. " \
        f"Jobs targeting these providers will fail silently."


# ── Test 6: Rapid failure guard — code bug → escalate, not migrate ────────────

@pytest.mark.asyncio
async def test_rapid_failure_escalates_not_migrates():
    """
    If a job crashes repeatedly in <120s (likely user code bug, not infra),
    orchestration must escalate to human instead of migrating.
    Without this guard, VaultLayer would spin up instances in a loop,
    burning money on a broken training script.
    """
    from agents.orchestration.agent import OrchestrationAgent

    cfg = _cfg()
    queue = MockAgentQueue()
    job = _aws_job()

    queue._price_cache = [
        {"provider": "runpod", "gpu": "H100_80GB_SXM", "price_per_hour": 1.79, "availability": "available"},
    ]

    orch = OrchestrationAgent(config=cfg, queue=queue)
    orch.register_job(job)

    # Simulate 3 rapid crashes (exit code 1, job age 45s each = code bug pattern)
    for i in range(3):
        crash_event = AgentEvent(
            event_type=EventType.TERMINATION_SIGNAL,
            source_agent="watchdog_agent",
            job_id=job.job_id,
            payload={
                "reason": "process_exit",
                "exit_code": 1,           # non-SIGTERM exit
                "job_age_secs": 45,       # died in < 120s
                "current_step": i * 10,
                "requires_migration": True,
            },
            priority=1,
        )
        await orch.handle_event(crash_event)

    # After repeated rapid failures, should escalate, not keep migrating
    escalate_events = [
        e for (ch, e) in queue.published
        if ch == "escalate" and e.event_type == EventType.ESCALATION
    ]
    assert escalate_events, \
        "Repeated rapid failures must trigger ESCALATION, not endless migration. " \
        "Without this guard VaultLayer spins instances in an infinite loop."
