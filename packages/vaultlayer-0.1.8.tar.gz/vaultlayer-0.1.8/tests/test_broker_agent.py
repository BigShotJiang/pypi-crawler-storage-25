"""
VaultLayer — Broker Agent Tests
Verifies migration execution, AWS provisioning, and channel subscription correctness.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
import inspect
from unittest.mock import patch, AsyncMock, MagicMock
from conftest import MockAgentQueue, make_job


# ── 1. Broker subscribes to orchestration channel ────────────────────────

def test_broker_subscribes_to_orchestration_channel():
    """Broker must subscribe to 'orchestration' channel — not stale 'station'."""
    from agents.broker.agent import BrokerAgent
    source = inspect.getsource(BrokerAgent.listen_for_commands)
    assert "orchestration" in source, "Broker must subscribe to 'orchestration' channel"
    assert "station" not in source.lower().replace("orchestration", ""), \
        "Stale 'station' reference found in Broker listen_for_commands"


# ── 2. Migration publishes MIGRATION_STARTED event ───────────────────────

@pytest.mark.asyncio
async def test_migration_publishes_migration_started(dummy_config, mock_queue):
    """execute_migration must publish MIGRATION_STARTED to broker channel."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType, EventType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    with patch.object(agent, 'provision_lambda', new_callable=AsyncMock) as mock_prov, \
             patch.object(agent, '_check_quota', new_callable=AsyncMock, return_value=True), \
             patch.object(agent, '_wait_for_ssh', new_callable=AsyncMock, return_value=True), \
             patch.object(agent, '_wait_for_bootstrap', new_callable=AsyncMock, return_value=True), \
             patch.object(agent, '_prefetch_checkpoint', new_callable=AsyncMock), \
             patch.object(agent, '_restart_job_on_node', new_callable=AsyncMock, return_value=True), \
             patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
             patch('asyncio.sleep', new_callable=AsyncMock):
        mock_prov.return_value = "i-lambda-test-001"
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="dec-001"
        )

    broker_events = mock_queue.events_on("broker")
    assert broker_events, "No events published to broker channel"
    event_types = [e.event_type for e in broker_events]
    assert EventType.MIGRATION_STARTED in event_types


# ── 3. Migration publishes MIGRATION_COMPLETE after success ──────────────

@pytest.mark.asyncio
async def test_migration_publishes_migration_complete(dummy_config, mock_queue):
    """Successful migration must publish MIGRATION_COMPLETE event."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType, EventType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    with patch.object(agent, 'provision_lambda', new_callable=AsyncMock) as mock_prov, \
         patch.object(agent, '_check_quota', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_wait_for_ssh', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_wait_for_bootstrap', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_prefetch_checkpoint', new_callable=AsyncMock), \
         patch.object(agent, '_restart_job_on_node', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch('asyncio.sleep', new_callable=AsyncMock):
        mock_prov.return_value = "i-lambda-test-001"
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="dec-002"
        )

    event_types = [e.event_type for e in mock_queue.events_on("broker")]
    assert EventType.MIGRATION_COMPLETE in event_types


# ── 4. Provisioning failure is handled gracefully ────────────────────────

@pytest.mark.asyncio
async def test_migration_handles_provisioning_failure(dummy_config, mock_queue):
    """If provisioning returns None, migration must not crash and no MIGRATION_COMPLETE."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    with patch.object(agent, 'provision_lambda', new_callable=AsyncMock) as mock_prov, \
         patch.object(agent, '_fence_old_node', new_callable=AsyncMock), \
         patch.object(agent, '_check_quota', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch('asyncio.sleep', new_callable=AsyncMock):
        mock_prov.return_value = None
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="dec-fail-001"
        )

    event_types = mock_queue.event_types_on("broker")
    assert "migration_complete" not in event_types


# ── 5. AWS provisioning branch is called for Provider.AWS ────────────────

@pytest.mark.asyncio
async def test_migration_calls_provision_aws_for_aws_provider(dummy_config, mock_queue):
    """execute_migration must call provision_aws when target is Provider.AWS."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    with patch.object(agent, 'provision_aws', new_callable=AsyncMock) as mock_aws, \
             patch.object(agent, '_wait_for_ssh', new_callable=AsyncMock, return_value=True), \
             patch.object(agent, '_restart_job_on_node', new_callable=AsyncMock, return_value=True), \
             patch('asyncio.sleep', new_callable=AsyncMock):
        mock_aws.return_value = "i-aws-test-001"
        await agent.execute_migration(
            job, Provider.AWS, GPUType.A100_40GB, decision_id="dec-aws-001"
        )

    mock_aws.assert_called_once()


# ── 6. All three providers have provisioning methods ─────────────────────

def test_broker_has_provision_methods_for_all_providers():
    """BrokerAgent must have provision methods for Lambda, CoreWeave, and AWS."""
    from agents.broker.agent import BrokerAgent
    assert hasattr(BrokerAgent, 'provision_lambda'), "Missing provision_lambda"
    assert hasattr(BrokerAgent, 'provision_coreweave'), "Missing provision_coreweave"
    assert hasattr(BrokerAgent, 'provision_aws'), "Missing provision_aws"


# ── 7. AWS instance type map covers all GPU types ────────────────────────

def test_aws_instance_map_covers_all_gpu_types():
    """AWS_INSTANCE_MAP must map every supported GPUType to an EC2 instance type."""
    from agents.broker.agent import AWS_INSTANCE_MAP
    from shared.models import GPUType
    supported = {GPUType.H100_80GB_SXM, GPUType.A100_80GB_SXM, GPUType.A100_40GB, GPUType.A10G}
    for gpu in supported:
        assert gpu in AWS_INSTANCE_MAP, f"GPU {gpu} missing from AWS_INSTANCE_MAP"


# ── 8. CoreWeave provisioning is called for Provider.COREWEAVE ───────────

@pytest.mark.asyncio
async def test_migration_calls_provision_coreweave_for_coreweave_provider(dummy_config, mock_queue):
    """execute_migration must call provision_coreweave when target is Provider.COREWEAVE."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    with patch.object(agent, 'provision_coreweave', new_callable=AsyncMock) as mock_cw, \
             patch.object(agent, '_wait_for_ssh', new_callable=AsyncMock, return_value=True), \
             patch.object(agent, '_restart_job_on_node', new_callable=AsyncMock, return_value=True), \
             patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
             patch('asyncio.sleep', new_callable=AsyncMock):
        mock_cw.return_value = "vaultlayer-cw-test"
        await agent.execute_migration(
            job, Provider.COREWEAVE, GPUType.A100_80GB_SXM, decision_id="dec-cw-001"
        )

    mock_cw.assert_called_once()


# ── 9. Migration sets status to failed on provisioning error ─────────────

@pytest.mark.asyncio
async def test_migration_sets_failed_status_on_provisioning_error(dummy_config, mock_queue):
    """When provisioning raises an exception, migration must not propagate it."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    with patch.object(agent, 'provision_lambda', new_callable=AsyncMock) as mock_prov, \
         patch.object(agent, '_fence_old_node', new_callable=AsyncMock), \
         patch.object(agent, '_check_quota', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch('asyncio.sleep', new_callable=AsyncMock):
        mock_prov.side_effect = Exception("Network timeout")
        try:
            await agent.execute_migration(
                job, Provider.LAMBDA_LABS, GPUType.A10G, decision_id="dec-exc-001"
            )
        except Exception:
            pytest.fail("execute_migration should not raise — it must handle exceptions internally")


# ── 10. Migration ID format is correct ───────────────────────────────────

@pytest.mark.asyncio
async def test_migration_id_format(dummy_config, mock_queue):
    """Migration ID must be formatted as job_id:decision_id[:8]."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    decision_id = "abcdef1234567890"
    with patch.object(agent, 'provision_lambda', new_callable=AsyncMock) as mock_prov, \
         patch('asyncio.sleep', new_callable=AsyncMock):
        mock_prov.return_value = "i-format-test"
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id=decision_id
        )

    expected_migration_id = f"{job.job_id}:{decision_id[:8]}"
    assert expected_migration_id in agent._active_migrations, \
        f"Expected migration ID '{expected_migration_id}' not found in active migrations"


# ── 11. SSH exponential backoff schedule ────────────────────────────────

@pytest.mark.asyncio
async def test_wait_for_ssh_exponential_backoff(dummy_config, mock_queue):
    """_wait_for_ssh must use exponential backoff: delays should double each round."""
    import socket
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)

    sleep_calls = []

    async def _fake_sleep(delay):
        sleep_calls.append(delay)

    # Make socket.create_connection always fail, then succeed on 5th attempt
    attempt_counter = [0]
    original_create_connection = socket.create_connection

    def _fail_then_succeed(addr, timeout=None):
        attempt_counter[0] += 1
        if attempt_counter[0] < 5:
            raise ConnectionRefusedError("not yet")
        # return a mock socket
        mock_sock = MagicMock()
        mock_sock.close = MagicMock()
        return mock_sock

    with patch("agents.broker.agent.asyncio.sleep", side_effect=_fake_sleep), \
         patch("socket.create_connection", side_effect=_fail_then_succeed):
        result = await agent._wait_for_ssh("1.2.3.4", timeout=300)

    assert result is True, "_wait_for_ssh must return True when SSH becomes reachable"
    # Verify exponential backoff: each delay should be >= previous (up to 30s cap)
    assert len(sleep_calls) >= 3, "Must sleep between retries"
    for i in range(1, len(sleep_calls)):
        # Each subsequent delay is double or at the 30s cap
        assert sleep_calls[i] >= sleep_calls[i - 1] or sleep_calls[i] == 30.0, \
            f"Backoff not exponential: sleep_calls={sleep_calls}"


@pytest.mark.asyncio
async def test_wait_for_ssh_returns_false_on_timeout(dummy_config, mock_queue):
    """_wait_for_ssh must return False when timeout is reached without success."""
    import socket
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)

    with patch("agents.broker.agent.asyncio.sleep", new_callable=AsyncMock), \
         patch("socket.create_connection", side_effect=ConnectionRefusedError("never up")), \
         patch("time.monotonic", side_effect=[0.0, 0.1, 0.2, 200.0, 200.1]):
        # monotonic: deadline=0+180, first check=0.1, second check=0.2, third=200 (past deadline)
        result = await agent._wait_for_ssh("1.2.3.4", timeout=180)

    assert result is False


@pytest.mark.asyncio
async def test_wait_for_ssh_succeeds_immediately(dummy_config, mock_queue):
    """_wait_for_ssh must return True without sleeping if SSH is up on first try."""
    import socket
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)

    sleep_calls = []
    async def _fake_sleep(d): sleep_calls.append(d)

    mock_sock = MagicMock()
    mock_sock.close = MagicMock()
    with patch("agents.broker.agent.asyncio.sleep", side_effect=_fake_sleep), \
         patch("socket.create_connection", return_value=mock_sock):
        result = await agent._wait_for_ssh("10.0.0.1", timeout=180)

    assert result is True
    assert sleep_calls == [], "Must not sleep if SSH is reachable on first try"


# ── 12. Provider retry + user notification ──────────────────────────────

@pytest.mark.asyncio
async def test_provision_retries_3_times_before_failover(dummy_config, mock_queue):
    """execute_migration must attempt provisioning MAX_PROVISION_ATTEMPTS times before failover."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    call_count = [0]

    async def _always_fail(gpu, j):
        call_count[0] += 1
        return None

    with patch.object(agent, 'provision_lambda', side_effect=_always_fail), \
         patch.object(agent, '_check_quota', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch.object(mock_queue, 'get_price_cache', new_callable=AsyncMock, return_value=[]), \
         patch('asyncio.sleep', new_callable=AsyncMock):
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="retry-test"
        )

    assert call_count[0] == 3, \
        f"Must retry exactly 3 times (MAX_PROVISION_ATTEMPTS), got {call_count[0]}"


@pytest.mark.asyncio
async def test_provision_retry_publishes_user_notifications(dummy_config, mock_queue):
    """Each provisioning retry must publish a warning notification to the escalate channel."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType, EventType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    with patch.object(agent, 'provision_lambda', new_callable=AsyncMock, return_value=None), \
         patch.object(agent, '_check_quota', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch.object(mock_queue, 'get_price_cache', new_callable=AsyncMock, return_value=[]), \
         patch('asyncio.sleep', new_callable=AsyncMock):
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="notify-test"
        )

    escalate_events = mock_queue.events_on("escalate")
    assert len(escalate_events) >= 2, \
        "Must publish at least 2 escalate events (retries + final failure)"
    event_types = [e.event_type for e in escalate_events]
    assert EventType.ESCALATION in event_types


@pytest.mark.asyncio
async def test_provision_final_escalation_contains_resume_command(dummy_config, mock_queue):
    """Final escalation event must include manual resume instructions with the job ID."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    # P0-C5: pre-exhaust DLQ retries so this single failure escalates to permanent FAILED
    job.provision_failure_count = job.max_provision_failures - 1
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    with patch.object(agent, 'provision_lambda', new_callable=AsyncMock, return_value=None), \
         patch.object(agent, '_check_quota', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch.object(mock_queue, 'get_price_cache', new_callable=AsyncMock, return_value=[]), \
         patch('asyncio.sleep', new_callable=AsyncMock):
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="escalate-test"
        )

    escalate_events = mock_queue.events_on("escalate")
    # The last escalation should be critical and contain resume instructions
    critical_events = [e for e in escalate_events if e.payload.get("level") == "critical"]
    assert critical_events, "Must publish a critical escalation when all providers fail"
    last_detail = critical_events[-1].payload.get("detail", "")
    assert "vaultlayer resume" in last_detail, \
        "Critical escalation must include 'vaultlayer resume' command"
    assert job.job_id in last_detail, \
        "Critical escalation must include the job ID"


@pytest.mark.asyncio
async def test_provision_tries_alternative_providers_after_primary_fails(dummy_config, mock_queue):
    """After primary provider fails, broker must try alternative providers from price cache."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    # Price cache with a CoreWeave alternative
    price_cache = [
        {
            "provider": "coreweave",
            "gpu": GPUType.H100_80GB_SXM.value,
            "price_per_hour": 2.5,
            "availability": "available",
        }
    ]
    coreweave_calls = [0]

    async def _coreweave_success(gpu, j):
        coreweave_calls[0] += 1
        return "cw-fallback-001"

    with patch.object(agent, 'provision_lambda', new_callable=AsyncMock, return_value=None), \
         patch.object(agent, 'provision_coreweave', side_effect=_coreweave_success), \
         patch.object(agent, '_check_quota', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_wait_for_ssh', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_wait_for_bootstrap', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_prefetch_checkpoint', new_callable=AsyncMock), \
         patch.object(agent, '_restart_job_on_node', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch.object(mock_queue, 'get_price_cache', new_callable=AsyncMock, return_value=price_cache), \
         patch('asyncio.sleep', new_callable=AsyncMock):
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="fallback-test"
        )

    assert coreweave_calls[0] >= 1, "Must try CoreWeave as fallback provider"


# ── Region compliance tests ───────────────────────────────────────────────

def test_region_excluded_raises(dummy_config):
    """_check_region_allowed must raise RegionNotAllowedError when region is in excluded_regions."""
    from agents.broker.agent import BrokerAgent, RegionNotAllowedError
    agent = BrokerAgent(config=dummy_config, queue=MagicMock())

    job = make_job()
    job.excluded_regions = ["us-east-1", "eu-west-1"]

    import pytest
    with pytest.raises(RegionNotAllowedError):
        agent._check_region_allowed("us-east-1", job)


def test_region_not_in_regions_raises(dummy_config):
    """_check_region_allowed must raise RegionNotAllowedError when region not in regions whitelist."""
    from agents.broker.agent import BrokerAgent, RegionNotAllowedError
    agent = BrokerAgent(config=dummy_config, queue=MagicMock())

    job = make_job()
    job.regions = ["eu-central-1", "eu-west-1"]  # GDPR-only whitelist

    import pytest
    with pytest.raises(RegionNotAllowedError):
        agent._check_region_allowed("us-east-1", job)


def test_region_in_regions_passes(dummy_config):
    """Region in whitelist must not raise."""
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=MagicMock())

    job = make_job()
    job.regions = ["eu-central-1", "us-east-1"]

    # Must not raise
    agent._check_region_allowed("eu-central-1", job)


def test_no_region_constraints_passes(dummy_config):
    """Empty regions and excluded_regions means any region is allowed."""
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=MagicMock())

    job = make_job()
    # Both lists empty — no restriction

    # Must not raise for any region
    agent._check_region_allowed("ap-southeast-1", job)
    agent._check_region_allowed("us-east-1", job)


def test_excluded_takes_priority_over_regions(dummy_config):
    """excluded_regions wins even when a region also appears in regions whitelist."""
    from agents.broker.agent import BrokerAgent, RegionNotAllowedError
    agent = BrokerAgent(config=dummy_config, queue=MagicMock())

    job = make_job()
    job.regions = ["us-east-1"]
    job.excluded_regions = ["us-east-1"]  # explicitly excluded — wins

    import pytest
    with pytest.raises(RegionNotAllowedError):
        agent._check_region_allowed("us-east-1", job)


# ── Region filter in fallback provider selection ──────────────────────────

@pytest.mark.asyncio
async def test_fallback_excludes_blocked_aws_regions(dummy_config, mock_queue):
    """Fallback provider list must exclude AWS price entries whose region is in excluded_regions."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType

    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.excluded_regions = ["us-east-1"]

    price_cache = [
        # AWS us-east-1 — should be filtered OUT (excluded)
        {"provider": "aws", "gpu": "H100_80GB_SXM", "region": "us-east-1",
         "price_per_hour": 1.50, "availability": "high"},
        # AWS us-west-2 — should remain (not excluded)
        {"provider": "aws", "gpu": "H100_80GB_SXM", "region": "us-west-2",
         "price_per_hour": 1.60, "availability": "high"},
        # Lambda Labs — no region check (non-AWS), should remain
        {"provider": "lambda_labs", "gpu": "H100_80GB_SXM", "region": "",
         "price_per_hour": 1.70, "availability": "high"},
    ]

    with patch.object(agent, 'provision_aws', new_callable=AsyncMock, return_value=None), \
         patch.object(agent, 'provision_lambda', new_callable=AsyncMock, return_value=None), \
         patch.object(agent, 'provision_coreweave', new_callable=AsyncMock, return_value=None), \
         patch.object(mock_queue, 'get_price_cache',
                      new_callable=AsyncMock, return_value=price_cache), \
         patch('asyncio.sleep', new_callable=AsyncMock):
        # Should complete without RegionNotAllowedError propagating to the top
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="region-filter-test"
        )


@pytest.mark.asyncio
async def test_fallback_respects_regions_whitelist(dummy_config, mock_queue):
    """Fallback list must exclude AWS entries whose region is not in job.regions whitelist."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType

    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.regions = ["eu-central-1"]  # GDPR: only EU

    price_cache = [
        # us-east-1 — NOT in whitelist, must be filtered out
        {"provider": "aws", "gpu": "H100_80GB_SXM", "region": "us-east-1",
         "price_per_hour": 1.50, "availability": "high"},
        # eu-central-1 — IN whitelist, must remain
        {"provider": "aws", "gpu": "H100_80GB_SXM", "region": "eu-central-1",
         "price_per_hour": 2.10, "availability": "high"},
    ]

    with patch.object(agent, 'provision_aws', new_callable=AsyncMock, return_value=None), \
         patch.object(agent, 'provision_lambda', new_callable=AsyncMock, return_value=None), \
         patch.object(agent, 'provision_coreweave', new_callable=AsyncMock, return_value=None), \
         patch.object(mock_queue, 'get_price_cache',
                      new_callable=AsyncMock, return_value=price_cache), \
         patch('asyncio.sleep', new_callable=AsyncMock):
        # Should complete without raising RegionNotAllowedError
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="whitelist-test"
        )


# ── Fix 1: Provision errors surfaced in Job.last_provision_error ─────────

def test_job_model_has_last_provision_error():
    """Job model must have last_provision_error field."""
    from shared.models import Job
    job = make_job()
    assert hasattr(job, "last_provision_error")
    assert job.last_provision_error == ""


@pytest.mark.asyncio
async def test_provision_error_surfaced_on_failure(dummy_config, mock_queue):
    """When all providers fail, job.last_provision_error must be set."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    async def _fail_provision(gpu_type, j):
        j.last_provision_error = "Lambda: HTTP 500 — internal error"
        return None

    with patch.object(agent, 'provision_lambda', new=_fail_provision), \
         patch.object(agent, '_check_quota', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch.object(mock_queue, 'get_price_cache', new_callable=AsyncMock, return_value=[]), \
         patch('asyncio.sleep', new_callable=AsyncMock):
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="err-test"
        )
    assert job.last_provision_error != "", "last_provision_error should be set on failure"


@pytest.mark.asyncio
async def test_provision_error_cleared_on_success(dummy_config, mock_queue):
    """On successful provision, last_provision_error must be cleared."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.last_provision_error = "previous error"
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    with patch.object(agent, 'provision_lambda', new_callable=AsyncMock, return_value="i-success-001"), \
         patch.object(agent, '_check_quota', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_wait_for_ssh', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_wait_for_bootstrap', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_prefetch_checkpoint', new_callable=AsyncMock), \
         patch.object(agent, '_restart_job_on_node', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch('asyncio.sleep', new_callable=AsyncMock):
        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="clear-err-test"
        )
    assert job.last_provision_error == "", "last_provision_error should be cleared on success"


# ── Fix 2: Post-delete verification (tested via source inspection) ──────

def test_runpod_fence_has_post_delete_verification():
    """RunPod fence method must poll GET /v1/pods/{id} after DELETE."""
    from agents.broker.providers import runpod
    source = inspect.getsource(runpod.hard_fence)
    assert "/v1/pods/" in source, "Must poll RunPod pod status"
    assert "404" in source, "Must check for 404 (pod gone)"
    assert "confirmed destroyed" in source or "confirmed gone" in source, \
        "Must log confirmation of destruction"


def test_vastai_fence_has_post_delete_verification():
    """Vast.ai fence method must poll GET /api/v0/instances/{id}/ after DELETE."""
    from agents.broker.providers import vast_ai
    source = inspect.getsource(vast_ai.hard_fence)
    assert "/api/v0/instances/" in source, "Must poll Vast.ai instance status"
    assert "404" in source, "Must check for 404 (instance gone)"
    assert "confirmed destroyed" in source, "Must log confirmation of destruction"


def test_lambda_fence_has_post_delete_verification():
    """Lambda fence method must poll GET /instances/{id} after terminate."""
    from agents.broker.providers import lambda_labs
    source = inspect.getsource(lambda_labs.hard_fence)
    assert "/instances/" in source, "Must poll Lambda instance status"
    assert "terminated" in source, "Must check for terminated status"


# ── Fix 3: GPU resolver is wired into broker ────────────────────────────

def test_broker_has_gpu_resolver():
    """BrokerAgent must have a gpu_resolver attribute."""
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=MagicMock(), queue=MagicMock())
    assert hasattr(agent, "gpu_resolver")
    from shared.gpu_resolver import GPUResolver
    assert isinstance(agent.gpu_resolver, GPUResolver)


def test_provision_lambda_uses_gpu_resolver():
    """Lambda provider must call gpu_resolver.resolve."""
    from agents.broker.providers import lambda_labs
    source = inspect.getsource(lambda_labs.provision)
    assert "gpu_resolver.resolve" in source, "Must use dynamic GPU resolver"


def test_provision_runpod_uses_gpu_resolver():
    """RunPod provider must call gpu_resolver.resolve."""
    from agents.broker.providers import runpod
    source = inspect.getsource(runpod.provision)
    assert "gpu_resolver.resolve" in source, "Must use dynamic GPU resolver"


def test_provision_vast_uses_gpu_resolver():
    """Vast.ai provider must call gpu_resolver.resolve."""
    from agents.broker.providers import vast_ai
    source = inspect.getsource(vast_ai.provision)
    assert "gpu_resolver.resolve" in source, "Must use dynamic GPU resolver"


# ── Fix 4: Provider billing is wired into fence settlement ──────────────

def test_fence_settlement_calls_provider_billing():
    """_hard_fence_and_confirm must call fetch_provider_bill before settle."""
    from agents.broker.agent import BrokerAgent
    source = inspect.getsource(BrokerAgent._hard_fence_and_confirm)
    assert "fetch_provider_bill" in source, "Must call provider billing API"
    assert "provider_billed_usd" in source, "Must pass provider_billed_usd to settle"


def test_settle_instance_accepts_provider_billed():
    """settle_instance must accept provider_billed_usd parameter."""
    from shared.spend import settle_instance
    import inspect as _insp
    sig = _insp.signature(settle_instance)
    assert "provider_billed_usd" in sig.parameters


def test_close_run_accepts_provider_billed():
    """close_run must accept provider_billed_usd parameter."""
    from shared.job_run_logger import close_run
    import inspect as _insp
    sig = _insp.signature(close_run)
    assert "provider_billed_usd" in sig.parameters


# ── Provision lock: duplicate migration guard ─────────────────────────────────

@pytest.mark.asyncio
async def test_provision_lock_blocks_duplicate_migration(dummy_config, mock_queue):
    """A second execute_migration call for the same job_id while the first
    is in-flight must return None immediately without calling provision_*.

    Scenario: broker crashes after acquiring the provision lock but before
    provisioning completes. On restart it receives the migration command again.
    The Redis SETNX lock must prevent a second provision call.
    """
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType
    import shared.provider_capacity as pc

    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job(job_id="job-lock-test")
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    provision_call_count = 0

    async def _count_provision(gpu, j):
        nonlocal provision_call_count
        provision_call_count += 1
        return f"i-instance-{provision_call_count}"

    # Simulate lock already held by another process: acquire_provision_lock returns False
    with patch.object(agent, '_check_quota', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, 'provision_lambda', side_effect=_count_provision), \
         patch('agents.broker.migration.acquire_provision_lock', return_value=False) as mock_lock, \
         patch('agents.broker.migration.release_provision_lock') as mock_release:

        result = await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="dec-dup-001"
        )

    assert result is None, \
        "execute_migration must return None when the provision lock is already held"
    assert provision_call_count == 0, \
        f"provision_lambda must not be called when lock is held; called {provision_call_count} time(s)"
    mock_release.assert_not_called(), \
        "release_provision_lock must not be called when lock was never acquired"


@pytest.mark.asyncio
async def test_provision_lock_released_on_success(dummy_config, mock_queue):
    """execute_migration must release the provision lock after a successful migration."""
    from agents.broker.agent import BrokerAgent
    from shared.models import Provider, GPUType

    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job(job_id="job-lock-release")
    await mock_queue.set_job_state(job.job_id, job.model_dump(mode="json"))

    with patch.object(agent, 'provision_lambda', new_callable=AsyncMock, return_value="i-success-001"), \
         patch.object(agent, '_check_quota', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_wait_for_ssh', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_wait_for_bootstrap', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_prefetch_checkpoint', new_callable=AsyncMock), \
         patch.object(agent, '_restart_job_on_node', new_callable=AsyncMock, return_value=True), \
         patch.object(agent, '_try_same_provider_different_az', new_callable=AsyncMock, return_value=None), \
         patch('asyncio.sleep', new_callable=AsyncMock), \
         patch('agents.broker.migration.acquire_provision_lock', return_value=True), \
         patch('agents.broker.migration.release_provision_lock') as mock_release:

        await agent.execute_migration(
            job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="dec-release-001"
        )

    mock_release.assert_called_once_with(job.job_id), \
        "release_provision_lock must be called exactly once after successful migration"
