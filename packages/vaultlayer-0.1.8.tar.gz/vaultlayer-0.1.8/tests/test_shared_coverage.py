"""
Comprehensive coverage tests for shared/ utilities and workers/.
Goal: maximize coverage with mocked external dependencies.
"""
import sys
import os
import json
import asyncio
import time
import tempfile
import threading
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch, mock_open, call
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# ─────────────────────────────────────────────────────────────────────────────
# shared/credits.py
# ─────────────────────────────────────────────────────────────────────────────

from shared.credits import (
    CreditBalance, CreditEventType, CreditLedger,
    MIN_BALANCE_TO_START_USD, LOW_BALANCE_THRESHOLD_USD, GRACE_AMOUNT_USD,
)


def _make_redis(balance=100.0, reserved=0.0, spent=0.0, reservation=0.0, idem_key=None):
    r = AsyncMock()
    r.get = AsyncMock(side_effect=lambda key: {
        f"vl:credits:u1:balance": str(balance),
        f"vl:credits:u1:reserved": str(reserved),
        f"vl:credits:u1:spent": str(spent),
    }.get(key, idem_key))
    r.hget = AsyncMock(return_value=str(reservation) if reservation else None)
    r.incrbyfloat = AsyncMock(return_value=None)
    r.hset = AsyncMock(return_value=None)
    r.hdel = AsyncMock(return_value=None)
    r.set = AsyncMock(return_value=None)
    r.xadd = AsyncMock(return_value="stream-id")
    return r


class TestCreditLedger:
    @pytest.mark.asyncio
    async def test_get_balance(self):
        r = _make_redis(balance=100.0, reserved=20.0, spent=10.0)
        ledger = CreditLedger(r, "u1")
        bal = await ledger.get_balance()
        assert bal.balance_usd == 100.0
        assert bal.reserved_usd == 20.0
        assert bal.spent_usd == 10.0
        assert bal.available_usd == 70.0

    @pytest.mark.asyncio
    async def test_get_balance_clamps_negative(self):
        r = _make_redis(balance=5.0, reserved=10.0, spent=0.0)
        ledger = CreditLedger(r, "u1")
        bal = await ledger.get_balance()
        assert bal.available_usd == 0.0

    @pytest.mark.asyncio
    async def test_get_reservation_none(self):
        r = _make_redis()
        ledger = CreditLedger(r, "u1")
        val = await ledger.get_reservation("job1")
        assert val == 0.0

    @pytest.mark.asyncio
    async def test_get_reservation_value(self):
        r = _make_redis(reservation=12.5)
        ledger = CreditLedger(r, "u1")
        val = await ledger.get_reservation("job1")
        assert val == 12.5

    @pytest.mark.asyncio
    async def test_add_credits_success(self):
        r = _make_redis(balance=50.0)
        # No idempotency key found
        r.get = AsyncMock(return_value=None)
        r.get.side_effect = None
        r.get.return_value = None
        ledger = CreditLedger(r, "u1")
        # re-mock get to return balance correctly after add
        calls = []
        async def get_side_effect(key):
            if "payment" in key:
                return None
            if "balance" in key:
                return "50.0"
            if "reserved" in key:
                return "0"
            if "spent" in key:
                return "0"
            return None
        r.get.side_effect = get_side_effect
        bal = await ledger.add_credits(50.0, "pi_test123")
        r.incrbyfloat.assert_called()
        assert bal is not None

    @pytest.mark.asyncio
    async def test_add_credits_duplicate_payment(self):
        r = _make_redis(balance=100.0)
        async def get_side_effect(key):
            if "payment" in key:
                return "1"  # already processed
            if "balance" in key:
                return "100.0"
            if "reserved" in key:
                return "0"
            if "spent" in key:
                return "0"
            return None
        r.get.side_effect = get_side_effect
        ledger = CreditLedger(r, "u1")
        bal = await ledger.add_credits(50.0, "pi_duplicate")
        r.incrbyfloat.assert_not_called()

    @pytest.mark.asyncio
    async def test_add_credits_invalid_amount(self):
        r = _make_redis()
        ledger = CreditLedger(r, "u1")
        with pytest.raises(ValueError):
            await ledger.add_credits(-10.0, "pi_bad")

    @pytest.mark.asyncio
    async def test_add_credits_zero_raises(self):
        r = _make_redis()
        ledger = CreditLedger(r, "u1")
        with pytest.raises(ValueError):
            await ledger.add_credits(0.0, "pi_zero")

    @pytest.mark.asyncio
    async def test_reserve_success(self):
        r = _make_redis(balance=100.0, reserved=0.0, spent=0.0)
        async def get_side(key):
            if "balance" in key:
                return "100.0"
            if "reserved" in key:
                return "0"
            if "spent" in key:
                return "0"
            return None
        r.get.side_effect = get_side
        r.hget.return_value = None
        ledger = CreditLedger(r, "u1")
        ok = await ledger.reserve("job1", 20.0)
        assert ok is True

    @pytest.mark.asyncio
    async def test_reserve_insufficient_balance(self):
        r = _make_redis(balance=5.0, reserved=0.0, spent=0.0)
        async def get_side(key):
            if "balance" in key:
                return "5.0"
            if "reserved" in key:
                return "0"
            if "spent" in key:
                return "0"
            return None
        r.get.side_effect = get_side
        r.hget.return_value = None
        ledger = CreditLedger(r, "u1")
        ok = await ledger.reserve("job1", 20.0)
        assert ok is False

    @pytest.mark.asyncio
    async def test_reserve_zero_uses_minimum(self):
        r = _make_redis(balance=100.0, reserved=0.0, spent=0.0)
        async def get_side(key):
            if "balance" in key:
                return "100.0"
            if "reserved" in key:
                return "0"
            if "spent" in key:
                return "0"
            return None
        r.get.side_effect = get_side
        r.hget.return_value = None
        ledger = CreditLedger(r, "u1")
        ok = await ledger.reserve("job1", 0.0)
        assert ok is True

    @pytest.mark.asyncio
    async def test_burn_normal_path(self):
        """Burn when reservation covers the amount."""
        r = _make_redis(balance=100.0, reserved=20.0, spent=0.0, reservation=20.0)
        async def get_side(key):
            if "balance" in key:
                return "100.0"
            if "reserved" in key:
                return "20.0"
            if "spent" in key:
                return "0"
            return None
        r.get.side_effect = get_side
        ledger = CreditLedger(r, "u1")
        bal = await ledger.burn("job1", 5.0)
        assert bal is not None

    @pytest.mark.asyncio
    async def test_burn_zero_usd(self):
        """Burn with usd=0 returns balance without modifying anything."""
        r = _make_redis(balance=50.0, reserved=10.0, spent=0.0, reservation=10.0)
        async def get_side(key):
            if "balance" in key:
                return "50.0"
            if "reserved" in key:
                return "10.0"
            if "spent" in key:
                return "0"
            return None
        r.get.side_effect = get_side
        ledger = CreditLedger(r, "u1")
        bal = await ledger.burn("job1", 0.0)
        assert bal is not None
        r.hset.assert_not_called()

    @pytest.mark.asyncio
    async def test_burn_overage_path(self):
        """Burn when reservation is less than burn amount (overage)."""
        r = _make_redis(balance=100.0, reserved=5.0, spent=0.0, reservation=2.0)
        async def get_side(key):
            if "balance" in key:
                return "100.0"
            if "reserved" in key:
                return "5.0"
            if "spent" in key:
                return "0"
            return None
        r.get.side_effect = get_side
        ledger = CreditLedger(r, "u1")
        bal = await ledger.burn("job1", 5.0)
        assert bal is not None

    @pytest.mark.asyncio
    async def test_burn_exhausted_warning(self):
        """Burn that exhausts the balance triggers exhausted log."""
        r = _make_redis(balance=1.0, reserved=1.0, spent=0.4, reservation=0.5)
        async def get_side(key):
            if "balance" in key:
                return "1.0"
            if "reserved" in key:
                return "1.0"
            if "spent" in key:
                return "0.4"
            return None
        r.get.side_effect = get_side
        ledger = CreditLedger(r, "u1")
        bal = await ledger.burn("job1", 0.5)
        assert bal.is_exhausted is True

    @pytest.mark.asyncio
    async def test_burn_low_balance_warning(self):
        """Burn that leaves low balance triggers low warning."""
        r = _make_redis(balance=15.0, reserved=10.0, spent=0.0, reservation=5.0)
        async def get_side(key):
            if "balance" in key:
                return "15.0"
            if "reserved" in key:
                return "10.0"
            if "spent" in key:
                return "0"
            return None
        r.get.side_effect = get_side
        ledger = CreditLedger(r, "u1")
        bal = await ledger.burn("job1", 2.0)
        assert bal is not None

    @pytest.mark.asyncio
    async def test_settle(self):
        r = _make_redis(balance=100.0, reserved=20.0, spent=15.0, reservation=5.0)
        async def get_side(key):
            if "balance" in key:
                return "100.0"
            if "reserved" in key:
                return "20.0"
            if "spent" in key:
                return "15.0"
            return None
        r.get.side_effect = get_side
        ledger = CreditLedger(r, "u1")
        bal = await ledger.settle("job1", 18.0)
        assert bal is not None
        r.incrbyfloat.assert_called()

    @pytest.mark.asyncio
    async def test_settle_no_reservation(self):
        """Settle when there's no reservation (already cleared)."""
        r = _make_redis(balance=80.0, reserved=0.0, spent=20.0, reservation=0.0)
        async def get_side(key):
            if "balance" in key:
                return "80.0"
            if "reserved" in key:
                return "0"
            if "spent" in key:
                return "20.0"
            return None
        r.get.side_effect = get_side
        r.hget.return_value = None  # no reservation
        ledger = CreditLedger(r, "u1")
        bal = await ledger.settle("job1", 10.0)
        assert bal is not None

    @pytest.mark.asyncio
    async def test_release_with_reservation(self):
        r = _make_redis(balance=100.0, reserved=20.0, spent=0.0, reservation=20.0)
        async def get_side(key):
            if "balance" in key:
                return "100.0"
            if "reserved" in key:
                return "20.0"
            if "spent" in key:
                return "0"
            return None
        r.get.side_effect = get_side
        ledger = CreditLedger(r, "u1")
        bal = await ledger.release("job1", "cancelled")
        assert bal is not None
        r.incrbyfloat.assert_called()

    @pytest.mark.asyncio
    async def test_release_no_reservation(self):
        """Release when no reservation exists — no-op."""
        r = _make_redis(balance=100.0, reserved=0.0, spent=0.0, reservation=0.0)
        async def get_side(key):
            if "balance" in key:
                return "100.0"
            if "reserved" in key:
                return "0"
            if "spent" in key:
                return "0"
            return None
        r.get.side_effect = get_side
        r.hget.return_value = None
        ledger = CreditLedger(r, "u1")
        bal = await ledger.release("job1")
        assert bal is not None

    @pytest.mark.asyncio
    async def test_refund(self):
        r = _make_redis(balance=50.0, reserved=0.0, spent=20.0)
        async def get_side(key):
            if "balance" in key:
                return "50.0"
            if "reserved" in key:
                return "0"
            if "spent" in key:
                return "20.0"
            return None
        r.get.side_effect = get_side
        ledger = CreditLedger(r, "u1")
        bal = await ledger.refund("job1", 10.0, "provider_failure")
        assert bal is not None
        r.incrbyfloat.assert_called()

    @pytest.mark.asyncio
    async def test_append_ledger_exception_non_fatal(self):
        """Ledger write failure is non-fatal."""
        r = _make_redis(balance=100.0)
        r.xadd = AsyncMock(side_effect=Exception("Redis stream error"))
        async def get_side(key):
            if "balance" in key:
                return "100.0"
            if "reserved" in key:
                return "0"
            if "spent" in key:
                return "0"
            return None
        r.get.side_effect = get_side
        ledger = CreditLedger(r, "u1")
        # Should not raise
        await ledger._append_ledger(CreditEventType.PURCHASED, 10.0, {})

    def test_estimate_job_cost(self):
        cost = CreditLedger.estimate_job_cost(2.0, 3.0)
        assert cost == round(2.0 * 3.0 * 1.20, 2)

    def test_estimate_job_cost_default_hours(self):
        cost = CreditLedger.estimate_job_cost(3.0)
        assert cost == round(3.0 * 2.0 * 1.20, 2)


# ─────────────────────────────────────────────────────────────────────────────
# shared/queue.py
# ─────────────────────────────────────────────────────────────────────────────

from shared.queue import AgentQueue, CHANNELS, make_event
from shared.models import AgentEvent, EventType


def _make_queue(redis_mock=None):
    q = AgentQueue("rediss://localhost:6380")
    q._client = redis_mock or AsyncMock()
    return q


class TestAgentQueue:
    @pytest.mark.asyncio
    async def test_connect_tls(self):
        def _close_coro(coro):
            coro.close()
            return MagicMock()
        with patch("redis.asyncio.from_url", new=AsyncMock(return_value=AsyncMock())) as mock_from_url:
            q = AgentQueue("rediss://host:6380")
            with patch.object(asyncio, "create_task", side_effect=_close_coro):
                await q.connect()
        mock_from_url.assert_called_once()

    @pytest.mark.asyncio
    async def test_connect_plaintext_warns(self):
        def _close_coro(coro):
            coro.close()
            return MagicMock()
        with patch("redis.asyncio.from_url", new=AsyncMock(return_value=AsyncMock())):
            q = AgentQueue("redis://remote-host:6379")
            import warnings
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                with patch.object(asyncio, "create_task", side_effect=_close_coro):
                    await q.connect()
            assert any("plaintext" in str(warning.message).lower() for warning in w)

    @pytest.mark.asyncio
    async def test_connect_localhost_no_warning(self):
        def _close_coro(coro):
            coro.close()
            return MagicMock()
        with patch("redis.asyncio.from_url", new=AsyncMock(return_value=AsyncMock())):
            q = AgentQueue("redis://localhost:6379")
            import warnings
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                with patch.object(asyncio, "create_task", side_effect=_close_coro):
                    await q.connect()
            assert not any("plaintext" in str(warning.message).lower() for warning in w)

    @pytest.mark.asyncio
    async def test_disconnect(self):
        r = AsyncMock()
        r.aclose = AsyncMock()
        q = _make_queue(r)
        await q.disconnect()
        r.aclose.assert_called_once()

    @pytest.mark.asyncio
    async def test_disconnect_no_client(self):
        q = AgentQueue("rediss://host")
        q._client = None
        await q.disconnect()  # should not raise

    @pytest.mark.asyncio
    async def test_publish_success(self):
        r = AsyncMock()
        r.publish = AsyncMock(return_value=2)
        r.lpush = AsyncMock(return_value=1)
        r.ltrim = AsyncMock()
        q = _make_queue(r)
        event = make_event(EventType.PRICE_UPDATE, "pricing")
        count = await q.publish("pricing", event)
        assert count == 2

    @pytest.mark.asyncio
    async def test_publish_unknown_channel_raises(self):
        q = _make_queue(AsyncMock())
        event = make_event(EventType.PRICE_UPDATE, "pricing")
        with pytest.raises(ValueError, match="Unknown channel"):
            await q.publish("nonexistent_channel", event)

    @pytest.mark.asyncio
    async def test_publish_redis_failure_non_critical(self):
        """Non-critical event failure sets degraded mode but doesn't write disk."""
        r = AsyncMock()
        r.publish = AsyncMock(side_effect=Exception("Redis down"))
        q = _make_queue(r)
        event = make_event(EventType.PRICE_UPDATE, "pricing")
        count = await q.publish("pricing", event)
        assert count == 0
        assert q._degraded is True

    @pytest.mark.asyncio
    async def test_publish_redis_failure_critical_writes_disk(self):
        """Critical event failure writes to disk backup."""
        r = AsyncMock()
        r.publish = AsyncMock(side_effect=Exception("Redis down"))
        q = _make_queue(r)
        event = make_event(EventType.TERMINATION_SIGNAL, "watchdog")
        with patch("builtins.open", mock_open()) as m:
            with patch.object(q, "_fallback_notify", new=AsyncMock()):
                count = await q.publish("watchdog", event)
        assert count == 0
        assert q._degraded is True

    @pytest.mark.asyncio
    async def test_set_and_get_job_state(self):
        r = AsyncMock()
        r.setex = AsyncMock()
        r.get = AsyncMock(return_value='{"status": "running"}')
        q = _make_queue(r)
        await q.set_job_state("job1", {"status": "running"})
        r.setex.assert_called_once()
        state = await q.get_job_state("job1")
        assert state == {"status": "running"}

    @pytest.mark.asyncio
    async def test_get_job_state_none(self):
        r = AsyncMock()
        r.get = AsyncMock(return_value=None)
        q = _make_queue(r)
        state = await q.get_job_state("unknown_job")
        assert state is None

    @pytest.mark.asyncio
    async def test_healthcheck_true(self):
        r = AsyncMock()
        r.ping = AsyncMock(return_value=True)
        q = _make_queue(r)
        assert await q.healthcheck() is True

    @pytest.mark.asyncio
    async def test_healthcheck_false_on_exception(self):
        r = AsyncMock()
        r.ping = AsyncMock(side_effect=Exception("Connection refused"))
        q = _make_queue(r)
        assert await q.healthcheck() is False

    @pytest.mark.asyncio
    async def test_get_history_returns_events(self):
        event = make_event(EventType.PRICE_UPDATE, "pricing")
        r = AsyncMock()
        r.lrange = AsyncMock(return_value=[event.model_dump_json()])
        q = _make_queue(r)
        events = await q.get_history("pricing", limit=5)
        assert len(events) == 1

    @pytest.mark.asyncio
    async def test_get_history_unknown_channel(self):
        q = _make_queue(AsyncMock())
        events = await q.get_history("no_such_channel")
        assert events == []

    @pytest.mark.asyncio
    async def test_get_history_invalid_json_skipped(self):
        r = AsyncMock()
        r.lrange = AsyncMock(return_value=["not_json"])
        q = _make_queue(r)
        events = await q.get_history("pricing", limit=5)
        assert events == []

    @pytest.mark.asyncio
    async def test_set_price_cache(self):
        r = AsyncMock()
        r.setex = AsyncMock()
        q = _make_queue(r)
        await q.set_price_cache([{"gpu": "H100", "price": 2.5}])
        r.setex.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_price_cache_hit(self):
        r = AsyncMock()
        r.get = AsyncMock(return_value='[{"gpu": "H100"}]')
        q = _make_queue(r)
        prices = await q.get_price_cache()
        assert prices == [{"gpu": "H100"}]

    @pytest.mark.asyncio
    async def test_get_price_cache_miss(self):
        r = AsyncMock()
        r.get = AsyncMock(return_value=None)
        q = _make_queue(r)
        prices = await q.get_price_cache()
        assert prices is None

    @pytest.mark.asyncio
    async def test_hget(self):
        r = AsyncMock()
        r.hget = AsyncMock(return_value="value")
        q = _make_queue(r)
        result = await q.hget("mykey", "field")
        assert result == "value"

    @pytest.mark.asyncio
    async def test_hset(self):
        r = AsyncMock()
        r.hset = AsyncMock(return_value=1)
        q = _make_queue(r)
        result = await q.hset("mykey", {"field": "value"})
        assert result == 1

    @pytest.mark.asyncio
    async def test_expire(self):
        r = AsyncMock()
        r.expire = AsyncMock(return_value=True)
        q = _make_queue(r)
        result = await q.expire("mykey", 300)
        assert result is True

    @pytest.mark.asyncio
    async def test_replay_disk_backup_no_file(self):
        q = _make_queue(AsyncMock())
        with patch("os.path.exists", return_value=False):
            await q._replay_disk_backup()

    @pytest.mark.asyncio
    async def test_replay_disk_backup_with_events(self):
        q = _make_queue(AsyncMock())
        q._client.publish = AsyncMock(return_value=1)
        event = make_event(EventType.PRICE_UPDATE, "pricing")
        backup_line = json.dumps({
            "channel_key": "pricing",
            "event": event.model_dump_json(),
        })
        m = mock_open(read_data=backup_line + "\n")
        with patch("os.path.exists", return_value=True):
            with patch("builtins.open", m):
                await q._replay_disk_backup()

    @pytest.mark.asyncio
    async def test_reconnect_loop_recovers(self):
        r = AsyncMock()
        r.ping = AsyncMock(return_value=True)
        q = _make_queue(r)
        q._degraded = True
        # Patch replay and sleep so loop only runs one iteration
        with patch.object(q, "_replay_disk_backup", new=AsyncMock()):
            with patch("asyncio.sleep", new=AsyncMock()) as mock_sleep:
                mock_sleep.side_effect = [None, asyncio.CancelledError()]
                try:
                    await q._reconnect_loop()
                except asyncio.CancelledError:
                    pass
        assert q._degraded is False

    @pytest.mark.asyncio
    async def test_publish_critical(self):
        r = AsyncMock()
        r.xgroup_create = AsyncMock(side_effect=Exception("BUSYGROUP"))
        r.xadd = AsyncMock(return_value="1234-0")
        q = _make_queue(r)
        event = make_event(EventType.MIGRATION_STARTED, "broker", job_id="j1")
        entry_id = await q.publish_critical("broker", event)
        assert entry_id == "1234-0"

    @pytest.mark.asyncio
    async def test_stream_key(self):
        q = _make_queue(AsyncMock())
        assert q._stream_key("pricing") == "vaultlayer:critical:pricing"
        assert q._stream_key() == "vaultlayer:critical:stream"

    @pytest.mark.asyncio
    async def test_process_stream_batch(self):
        r = AsyncMock()
        r.xack = AsyncMock()
        q = _make_queue(r)
        handler = AsyncMock()
        messages = [("stream_key", [("entry1", {"key": "val"})])]
        await q._process_stream_batch(messages, "consumer1", handler, "stream_key")
        handler.assert_awaited_once_with({"key": "val"})
        r.xack.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_process_stream_batch_handler_error(self):
        """Handler error: message stays unacked (not raising)."""
        r = AsyncMock()
        r.xack = AsyncMock()
        q = _make_queue(r)
        handler = AsyncMock(side_effect=Exception("handler failed"))
        messages = [("stream_key", [("entry1", {"key": "val"})])]
        await q._process_stream_batch(messages, "consumer1", handler, "stream_key")
        r.xack.assert_not_awaited()


def test_make_event():
    evt = make_event(EventType.PRICE_UPDATE, "pricing", job_id="j1", payload={"a": 1})
    assert evt.event_type == EventType.PRICE_UPDATE
    assert evt.source_agent == "pricing"
    assert evt.job_id == "j1"
    assert evt.payload == {"a": 1}
    assert evt.priority == 5


# ─────────────────────────────────────────────────────────────────────────────
# shared/price_guard.py
# ─────────────────────────────────────────────────────────────────────────────

from shared.price_guard import (
    gainshare_fee, compute_user_charge, check_margin, get_baseline_anchor,
    PriceChangeDetector, check_price_freshness,
    MarginViolation, PriceStaleError,
    GAINSHARE_STANDARD_PCT, GAINSHARE_FALLBACK_PCT, GAINSHARE_THRESHOLD_PCT,
)


class TestPriceGuard:
    def test_gainshare_fee_standard_rule(self):
        """Savings > 25% of baseline → standard 40% split."""
        baseline = 4.0
        sourced = 1.0  # savings = 3.0 > threshold (1.0)
        fee, billed, rule = gainshare_fee(baseline, sourced)
        assert rule == "standard"
        assert abs(fee - round(3.0 * GAINSHARE_STANDARD_PCT, 4)) < 1e-6
        assert abs(billed - round(sourced + fee, 4)) < 1e-6

    def test_gainshare_fee_fallback_rule(self):
        """Savings ≤ 25% of baseline → fallback 50% split."""
        baseline = 4.0
        sourced = 3.5  # savings = 0.5, threshold = 1.0 → fallback
        fee, billed, rule = gainshare_fee(baseline, sourced)
        assert rule == "fallback"
        assert abs(fee - round(0.5 * GAINSHARE_FALLBACK_PCT, 4)) < 1e-6

    def test_gainshare_fee_no_savings_raises(self):
        with pytest.raises(MarginViolation):
            gainshare_fee(3.0, 4.0)

    def test_gainshare_fee_exact_break_even_raises(self):
        with pytest.raises(MarginViolation):
            gainshare_fee(3.0, 3.0)

    def test_gainshare_fee_zero_sourced_raises(self):
        with pytest.raises(ValueError):
            gainshare_fee(3.0, 0.0)

    def test_gainshare_fee_zero_baseline_raises(self):
        with pytest.raises(ValueError):
            gainshare_fee(0.0, 1.0)

    def test_compute_user_charge_standard(self):
        result = compute_user_charge("AWS", "H100", 1.0, baseline_anchor=4.0)
        assert result["rule"] == "standard"
        assert result["user_savings"] > 0
        assert result["vl_fee"] > 0

    def test_compute_user_charge_no_savings(self):
        """When sourced_cost >= baseline, no_savings rule applies."""
        result = compute_user_charge("AWS", "H100", 5.0, baseline_anchor=4.0)
        assert result["rule"] == "no_savings"
        assert result["vl_fee"] == 0.0
        assert result["user_billed_rate"] == 4.0

    def test_compute_user_charge_uses_anchor_lookup(self):
        result = compute_user_charge("AWS", "H100", 2.0)
        assert "baseline_anchor" in result
        assert result["baseline_anchor"] > 0

    def test_get_baseline_anchor_exact(self):
        anchor = get_baseline_anchor("AWS", "H100")
        assert anchor > 0

    def test_get_baseline_anchor_gpu_family_normalised(self):
        anchor = get_baseline_anchor("AWS", "H100_80GB_SXM")
        assert anchor > 0

    def test_get_baseline_anchor_default_fallback(self):
        anchor = get_baseline_anchor("UnknownProvider", "UnknownGPU")
        assert anchor > 0

    def test_get_baseline_anchor_provider_variant(self):
        anchor = get_baseline_anchor("Lambda Labs", "A100")
        assert anchor > 0

    def test_get_baseline_anchor_first_gpu_family(self):
        """When GPU not found but provider found, returns first GPU."""
        anchor = get_baseline_anchor("AWS", "UNKNOWNGPU")
        assert anchor > 0

    def test_check_margin_safe(self):
        result = check_margin("AWS", "H100", 1.0, 2.0)
        assert result["safe"] is True
        assert result["margin_multiplier"] == 2.0

    def test_check_margin_violation(self):
        with pytest.raises(MarginViolation):
            check_margin("AWS", "H100", 2.0, 1.0)

    def test_check_margin_low_margin_violation(self):
        """Margin < MIN_MARGIN (1.05) raises MarginViolation."""
        with pytest.raises(MarginViolation):
            check_margin("AWS", "H100", 2.0, 2.02)  # 1% margin < 5% floor

    def test_check_margin_thin_warning(self):
        """Margin between 5% and 10% gives warning but not an exception."""
        result = check_margin("AWS", "H100", 2.0, 2.15)  # 7.5% margin
        assert result["safe"] is True

    def test_check_margin_zero_cost(self):
        result = check_margin("AWS", "H100", 0.0, 5.0)
        assert result["safe"] is True

    def test_price_change_detector_no_change(self):
        detector = PriceChangeDetector()
        detector._last_prices["AWS:H100"] = 3.0
        alert = detector.check_and_update("AWS", "H100", 3.0)
        assert alert is None

    def test_price_change_detector_alert(self):
        detector = PriceChangeDetector()
        detector._last_prices["AWS:H100"] = 3.0
        alert = detector.check_and_update("AWS", "H100", 3.5)
        assert alert is not None
        assert alert["direction"] == "UP"

    def test_price_change_detector_critical_alert(self):
        detector = PriceChangeDetector()
        detector._last_prices["AWS:H100"] = 2.0
        alert = detector.check_and_update("AWS", "H100", 2.5)  # 25% change
        assert alert is not None

    def test_price_change_detector_first_call_no_alert(self):
        """First call without existing price: no alert."""
        detector = PriceChangeDetector()
        alert = detector.check_and_update("AWS", "H100", 3.0)
        assert alert is None

    def test_price_change_detector_bootstrap_from_file(self):
        """Bootstrap from data file on first call."""
        detector = PriceChangeDetector()
        data = {"provider_prices": {"AWS": {"H100": 3.0}}}
        with patch("builtins.open", mock_open(read_data=json.dumps(data))):
            with patch("pathlib.Path.exists", return_value=True):
                alert = detector.check_and_update("AWS", "H100", 3.6)  # 20% change
        assert alert is not None

    def test_check_price_freshness_no_file(self):
        """No data file → skip freshness check (no raise)."""
        with patch("pathlib.Path.exists", return_value=False):
            check_price_freshness("AWS")  # should not raise

    def test_check_price_freshness_fresh(self):
        from datetime import datetime, timezone
        fresh_ts = datetime.now(timezone.utc).isoformat()
        data = {"_runtime": {"last_polled_utc": fresh_ts}}
        with patch("builtins.open", mock_open(read_data=json.dumps(data))):
            with patch("pathlib.Path.exists", return_value=True):
                check_price_freshness("AWS")  # no raise

    def test_check_price_freshness_stale(self):
        """Stale price data raises PriceStaleError."""
        from datetime import datetime, timezone, timedelta
        old_ts = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        data = {"_runtime": {"last_polled_utc": old_ts}}
        with patch("builtins.open", mock_open(read_data=json.dumps(data))):
            with patch("pathlib.Path.exists", return_value=True):
                with pytest.raises(PriceStaleError):
                    check_price_freshness("AWS")

    def test_check_price_freshness_no_last_polled(self):
        data = {"_runtime": {}}
        with patch("builtins.open", mock_open(read_data=json.dumps(data))):
            with patch("pathlib.Path.exists", return_value=True):
                check_price_freshness("AWS")  # no raise — no last_polled key


# ─────────────────────────────────────────────────────────────────────────────
# shared/security.py
# ─────────────────────────────────────────────────────────────────────────────

from shared.security import (
    CheckpointEncryption, AuditLog, AuditEvent,
    mask_secrets, SecureLogger, validate_credentials,
    verify_webhook_signature, ApiRateLimiter, get_rate_limiter,
    get_encryption, get_audit,
)


class TestCheckpointEncryption:
    def test_disabled_when_no_key(self):
        enc = CheckpointEncryption(master_key=None)
        with patch.dict("os.environ", {}, clear=True):
            enc2 = CheckpointEncryption()
        assert enc.enabled is False
        assert enc.decrypt(b"hello") == b"hello"
        assert enc.encrypt(b"hello") == b"hello"

    def test_encrypt_decrypt_roundtrip(self):
        enc = CheckpointEncryption(master_key="test-secret-key-12345")
        assert enc.enabled is True
        plaintext = b"checkpoint data here"
        ciphertext = enc.encrypt(plaintext)
        assert ciphertext != plaintext
        assert ciphertext.startswith(b"VLENC1")
        decrypted = enc.decrypt(ciphertext)
        assert decrypted == plaintext

    def test_decrypt_no_magic_returns_plaintext(self):
        enc = CheckpointEncryption(master_key="test-secret-key-12345")
        result = enc.decrypt(b"no magic header data")
        assert result == b"no magic header data"

    def test_stdlib_encrypt_decrypt(self):
        """Test stdlib fallback encryption."""
        enc = CheckpointEncryption(master_key="test-key-for-stdlib")
        enc._enabled = True
        plaintext = b"test plaintext for stdlib"
        ct = enc._encrypt_stdlib(plaintext)
        assert ct.startswith(b"VLENC1")
        recovered = enc._decrypt_stdlib(ct)
        assert recovered == plaintext

    def test_stdlib_decrypt_bad_tag_raises(self):
        enc = CheckpointEncryption(master_key="test-key-for-stdlib")
        enc._enabled = True
        ct = enc._encrypt_stdlib(b"original data")
        # Corrupt the tag
        ct_list = bytearray(ct)
        ct_list[10] ^= 0xFF
        with pytest.raises(ValueError, match="authentication tag mismatch"):
            enc._decrypt_stdlib(bytes(ct_list))


class TestMaskSecrets:
    def test_masks_openai_key(self):
        text = "sk-" + "A" * 48
        result = mask_secrets(text)
        assert "REDACTED" in result

    def test_masks_aws_key(self):
        text = "AKIA" + "A" * 16
        result = mask_secrets(text)
        assert "REDACTED" in result

    def test_no_secrets(self):
        text = "normal log message"
        assert mask_secrets(text) == text


class TestSecureLogger:
    def test_debug_masks(self):
        sl = SecureLogger("test")
        with patch.object(sl._logger, "debug") as mock_debug:
            sl.debug("sk-" + "A" * 48)
            args = mock_debug.call_args[0][0]
            assert "REDACTED" in args

    def test_info(self):
        sl = SecureLogger("test")
        with patch.object(sl._logger, "info") as mock_info:
            sl.info("normal message")
            mock_info.assert_called_once()

    def test_warning(self):
        sl = SecureLogger("test")
        with patch.object(sl._logger, "warning") as m:
            sl.warning("warn")
            m.assert_called_once()

    def test_error(self):
        sl = SecureLogger("test")
        with patch.object(sl._logger, "error") as m:
            sl.error("err")
            m.assert_called_once()

    def test_critical(self):
        sl = SecureLogger("test")
        with patch.object(sl._logger, "critical") as m:
            sl.critical("crit")
            m.assert_called_once()


class TestAuditLog:
    def test_record_creates_event(self):
        log = AuditLog(log_file="/tmp/test_audit.log")
        with patch("builtins.open", mock_open()):
            evt = log.record("test_event", actor="user1", resource="job:123")
        assert evt.event_type == "test_event"
        assert evt.actor == "user1"

    def test_record_file_write_failure_non_fatal(self):
        log = AuditLog(log_file="/tmp/test_audit.log")
        with patch("builtins.open", side_effect=IOError("disk full")):
            evt = log.record("test_event")
        assert evt is not None

    def test_checkpoint_encrypted(self):
        log = AuditLog(log_file="/tmp/test_audit.log")
        with patch("builtins.open", mock_open()):
            log.checkpoint_encrypted("job1", 1024)

    def test_checkpoint_decrypted(self):
        log = AuditLog(log_file="/tmp/test_audit.log")
        with patch("builtins.open", mock_open()):
            log.checkpoint_decrypted("job1")

    def test_provider_provisioned(self):
        log = AuditLog(log_file="/tmp/test_audit.log")
        with patch("builtins.open", mock_open()):
            log.provider_provisioned("AWS", "job1", True)

    def test_credential_access(self):
        log = AuditLog(log_file="/tmp/test_audit.log")
        with patch("builtins.open", mock_open()):
            log.credential_access("AWS", "AKIA1234")

    def test_validation_failed(self):
        log = AuditLog(log_file="/tmp/test_audit.log")
        with patch("builtins.open", mock_open()):
            log.validation_failed("redis_check", "Connection refused")


class TestAuditEvent:
    def test_to_dict(self):
        evt = AuditEvent("test", actor="sys", resource="r", detail="d")
        d = evt.to_dict()
        assert d["event_type"] == "test"
        assert d["actor"] == "sys"

    def test_to_json(self):
        evt = AuditEvent("test")
        j = evt.to_json()
        parsed = json.loads(j)
        assert parsed["event_type"] == "test"

    def test_masks_secrets_in_detail(self):
        evt = AuditEvent("test", detail="sk-" + "A" * 48)
        assert "REDACTED" in evt.detail


class TestValidateCredentials:
    def test_all_valid(self):
        config = MagicMock()
        config.anthropic = MagicMock(api_key="sk-" + "A" * 48)
        config.aws.access_key_id = "AKIA" + "X" * 16
        config.aws.secret_access_key = "X" * 40
        config.lambda_labs.api_key = "X" * 25
        config.cloudflare.r2_access_key_id = "X" * 20
        config.redis.url = "rediss://user:password@host:6380"
        config.runpod = MagicMock(api_key="X" * 25)
        results = validate_credentials(config)
        assert all(ok for _, ok, _ in results)

    def test_missing_anthropic_key(self):
        config = MagicMock()
        config.anthropic = MagicMock(api_key="")
        config.aws.access_key_id = "AKIA" + "X" * 16
        config.aws.secret_access_key = "X" * 40
        config.lambda_labs.api_key = "X" * 25
        config.cloudflare.r2_access_key_id = "X" * 20
        config.redis.url = "rediss://user:password@host:6380"
        config.runpod = None
        results = validate_credentials(config)
        anthropic_result = next(r for r in results if r[0] == "ANTHROPIC_API_KEY")
        assert anthropic_result[1] is False

    def test_no_anthropic_config(self):
        config = MagicMock()
        config.anthropic = None
        config.aws.access_key_id = "AKIA" + "X" * 16
        config.aws.secret_access_key = "X" * 40
        config.lambda_labs.api_key = "X" * 25
        config.cloudflare.r2_access_key_id = "X" * 20
        config.redis.url = "rediss://user:password@host:6380"
        config.runpod = None
        results = validate_credentials(config)
        assert all(name != "ANTHROPIC_API_KEY" for name, _, _ in results)

    def test_wrong_prefix(self):
        config = MagicMock()
        config.anthropic = MagicMock(api_key="bad-prefix-" + "A" * 30)
        config.aws.access_key_id = "AKIA" + "X" * 16
        config.aws.secret_access_key = "X" * 40
        config.lambda_labs.api_key = "X" * 25
        config.cloudflare.r2_access_key_id = "X" * 20
        config.redis.url = "rediss://user:password@host:6380"
        config.runpod = None
        results = validate_credentials(config)
        anthropic_result = next(r for r in results if r[0] == "ANTHROPIC_API_KEY")
        assert anthropic_result[1] is False


class TestWebhookSignature:
    def test_verify_valid_signature(self):
        import hmac as _hmac
        import hashlib
        secret = "mysecret"
        payload = b"payload data"
        sig = _hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
        assert verify_webhook_signature(payload, sig, secret) is True

    def test_verify_invalid_signature(self):
        assert verify_webhook_signature(b"data", "bad_sig", "mysecret") is False

    def test_verify_no_secret(self):
        assert verify_webhook_signature(b"data", "any_sig", "") is True

    def test_verify_with_prefix(self):
        import hmac as _hmac
        import hashlib
        secret = "mysecret"
        payload = b"payload"
        sig = "sha256=" + _hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
        assert verify_webhook_signature(payload, sig, secret) is True


class TestApiRateLimiter:
    def test_check_allows_under_limit(self):
        rl = ApiRateLimiter(max_calls=5, window_seconds=60.0)
        allowed, wait = rl.check()
        assert allowed is True
        assert wait == 0.0

    def test_check_blocks_over_limit(self):
        rl = ApiRateLimiter(max_calls=2, window_seconds=60.0)
        rl.record()
        rl.record()
        allowed, wait = rl.check()
        assert allowed is False
        assert wait > 0

    def test_record_increments(self):
        rl = ApiRateLimiter(max_calls=5, window_seconds=60.0)
        rl.record()
        assert len(rl._calls) == 1

    @pytest.mark.asyncio
    async def test_acquire_allows(self):
        rl = ApiRateLimiter(max_calls=10, window_seconds=60.0)
        await rl.acquire()
        assert len(rl._calls) == 1

    def test_get_rate_limiter_known(self):
        rl = get_rate_limiter("lambda_labs")
        assert isinstance(rl, ApiRateLimiter)

    def test_get_rate_limiter_unknown(self):
        rl = get_rate_limiter("unknown_provider")
        assert isinstance(rl, ApiRateLimiter)


class TestSingletons:
    def test_get_encryption(self):
        import shared.security as sec
        sec._encryption = None
        enc = get_encryption()
        assert isinstance(enc, CheckpointEncryption)

    def test_get_audit(self):
        import shared.security as sec
        sec._audit = None
        audit = get_audit()
        assert isinstance(audit, AuditLog)


# ─────────────────────────────────────────────────────────────────────────────
# shared/data_loader.py
# ─────────────────────────────────────────────────────────────────────────────

import shared.data_loader as dl


MOCK_DATA = {
    "_meta": {"last_updated": "2026-01-01"},
    "provider_prices": {
        "Lambda Labs": {"H100": 2.99, "A100": 1.72},
        "AWS": {"H100": 3.93, "A100": None},
    },
    "gpu_aliases": {
        "H100_80GB_SXM": "H100",
        "H100": "H100",
    },
    "gpu_profiles": {
        "tiers": [
            {
                "label": "Small",
                "params_max_b": 7.0,
                "qlora": {"gpu": "A10G", "vram_gb": 24, "note": "fits easily", "multi_gpu": 1},
                "lora": {"gpu": "A100", "vram_gb": 40, "note": "lora note", "multi_gpu": 1},
                "full": {"gpu": "H100", "vram_gb": 80, "note": "full fine-tune", "multi_gpu": 1},
            },
            {
                "label": "Large",
                "params_max_b": 70.0,
                "qlora": {"gpu": "H100", "vram_gb": 80, "note": "", "multi_gpu": 2},
            },
        ]
    },
    "provider_instance_maps": {
        "RunPod": {"H100": "NVIDIA H100 80GB HBM3"},
    },
    "provider_meta": {
        "Lambda Labs": {"max_concurrent_jobs": 100, "requires_application": False},
        "Voltage Park": {"max_concurrent_jobs": 50, "requires_application": True, "env_key": "VOLTAGE_PARK_API_KEY"},
    },
}


@pytest.fixture(autouse=False)
def reset_data_loader_cache():
    original_cache = dl._cache
    dl._cache = None
    yield
    dl._cache = original_cache


class TestDataLoader:
    def test_get_provider_prices(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        prices = dl.get_provider_prices()
        assert "Lambda Labs" in prices
        assert prices["Lambda Labs"]["H100"] == 2.99

    def test_get_gpu_aliases(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        aliases = dl.get_gpu_aliases()
        assert aliases["H100_80GB_SXM"] == "H100"

    def test_get_gpu_profiles(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        tiers = dl.get_gpu_profiles()
        assert len(tiers) == 2

    def test_get_instance_maps(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        maps = dl.get_instance_maps()
        assert "RunPod" in maps

    def test_get_instance_string(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        s = dl.get_instance_string("RunPod", "H100")
        assert s == "NVIDIA H100 80GB HBM3"

    def test_get_instance_string_missing(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        s = dl.get_instance_string("UnknownProvider", "H100")
        assert s == ""

    def test_is_gpu_available_true(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        assert dl.is_gpu_available("Lambda Labs", "H100") is True

    def test_is_gpu_available_false_null_price(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        assert dl.is_gpu_available("AWS", "A100") is False

    def test_is_gpu_available_missing(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        assert dl.is_gpu_available("AWS", "B200") is False

    def test_get_available_providers_for_gpu(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        providers = dl.get_available_providers_for_gpu("H100")
        assert "Lambda Labs" in providers
        assert "AWS" in providers

    def test_is_provider_accessible_open(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        assert dl.is_provider_accessible("Lambda Labs") is True

    def test_is_provider_accessible_requires_key_missing(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        with patch.dict("os.environ", {}, clear=True):
            assert dl.is_provider_accessible("Voltage Park") is False

    def test_is_provider_accessible_requires_key_present(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        with patch.dict("os.environ", {"VOLTAGE_PARK_API_KEY": "somekey"}):
            assert dl.is_provider_accessible("Voltage Park") is True

    def test_get_accessible_providers_for_gpu(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        providers = dl.get_accessible_providers_for_gpu("H100")
        assert isinstance(providers, list)

    def test_recommend_gpu_qlora(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        gpu, vram, reason, multi = dl.recommend_gpu(7.0, "qlora")
        assert gpu == "A10G"
        assert vram == 24

    def test_recommend_gpu_lora(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        gpu, vram, reason, multi = dl.recommend_gpu(7.0, "lora")
        assert gpu == "A100"

    def test_recommend_gpu_full(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        gpu, vram, reason, multi = dl.recommend_gpu(7.0, "full")
        assert gpu == "H100"

    def test_recommend_gpu_invalid_mode_defaults_qlora(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        gpu, vram, reason, multi = dl.recommend_gpu(7.0, "invalid_mode")
        assert gpu == "A10G"

    def test_recommend_gpu_large_fallback(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        gpu, vram, reason, multi = dl.recommend_gpu(100.0, "qlora")
        assert gpu == "H100_80GB_SXM"
        assert multi == 2

    def test_resolve_gpu_key(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        assert dl.resolve_gpu_key("H100_80GB_SXM") == "H100"

    def test_resolve_gpu_key_a100_40gb(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        assert dl.resolve_gpu_key("A100_40GB") == "A100_40"

    def test_reload(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        # Simulate reload with no file present
        with patch("pathlib.Path.exists", return_value=False):
            result = dl.reload()
        assert result is not None

    def test_load_fallback_empty(self, reset_data_loader_cache):
        with patch("pathlib.Path.exists", return_value=False):
            data = dl._load()
        assert "provider_prices" in data

    def test_get_meta(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        meta = dl.get_meta()
        assert "last_updated" in meta

    def test_get_provider_meta(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        meta = dl.get_provider_meta()
        assert "Lambda Labs" in meta

    def test_is_provider_available_for_new_job(self, reset_data_loader_cache):
        dl._cache = MOCK_DATA
        # Open provider without capacity issues
        result = dl.is_provider_available_for_new_job("Lambda Labs")
        assert result is True


# ─────────────────────────────────────────────────────────────────────────────
# shared/sts.py
# ─────────────────────────────────────────────────────────────────────────────

from shared.sts import STSSessionManager


def _make_sts_config(with_sts=True):
    config = MagicMock()
    config.aws.access_key_id = "AKIAXXXXXXXXXXXXXXXX"
    config.aws.secret_access_key = "secret123"
    config.aws.region = "us-east-1"
    if with_sts:
        config.sts = MagicMock(
            role_arn="arn:aws:iam::123456789012:role/TestRole",
            session_duration=3600,
            external_id=None,
        )
    else:
        config.sts = None
    return config


class TestSTSSessionManager:
    def test_is_configured_true(self):
        mgr = STSSessionManager(_make_sts_config(with_sts=True))
        assert mgr.is_configured is True

    def test_is_configured_false(self):
        mgr = STSSessionManager(_make_sts_config(with_sts=False))
        assert mgr.is_configured is False

    def test_get_credentials_static(self):
        config = _make_sts_config(with_sts=False)
        mgr = STSSessionManager(config)
        creds = mgr.get_credentials("job1")
        assert creds["aws_access_key_id"] == "AKIAXXXXXXXXXXXXXXXX"
        assert "aws_session_token" not in creds

    def test_get_credentials_sts(self):
        config = _make_sts_config(with_sts=True)
        mgr = STSSessionManager(config)
        mock_sts_client = MagicMock()
        mock_sts_client.assume_role.return_value = {
            "Credentials": {
                "AccessKeyId": "ASIA_TEMP",
                "SecretAccessKey": "secret_temp",
                "SessionToken": "token_temp",
            }
        }
        with patch("boto3.client", return_value=mock_sts_client):
            creds = mgr.get_credentials("job1")
        assert creds["aws_session_token"] == "token_temp"

    def test_get_credentials_cached(self):
        config = _make_sts_config(with_sts=True)
        mgr = STSSessionManager(config)
        mgr._credentials = {"aws_access_key_id": "ASIA_CACHED", "aws_secret_access_key": "x"}
        mgr._expiry = time.monotonic() + 1000  # far in future
        creds = mgr.get_credentials("job1")
        assert creds["aws_access_key_id"] == "ASIA_CACHED"

    def test_get_credentials_sts_with_external_id(self):
        config = _make_sts_config(with_sts=True)
        config.sts.external_id = "ext-id-123"
        mgr = STSSessionManager(config)
        mock_client = MagicMock()
        mock_client.assume_role.return_value = {
            "Credentials": {
                "AccessKeyId": "ASIA_EXT",
                "SecretAccessKey": "secret",
                "SessionToken": "tok",
            }
        }
        with patch("boto3.client", return_value=mock_client):
            creds = mgr.get_credentials("job1")
        call_kwargs = mock_client.assume_role.call_args[1]
        assert call_kwargs.get("ExternalId") == "ext-id-123"

    def test_get_credentials_sts_unauthorized_retry(self):
        """UnauthorizedOperation triggers cache clear and retry."""
        import botocore.exceptions
        config = _make_sts_config(with_sts=True)
        mgr = STSSessionManager(config)
        error_response = {"Error": {"Code": "UnauthorizedOperation", "Message": "denied"}}
        client_error = botocore.exceptions.ClientError(error_response, "AssumeRole")
        good_response = {
            "Credentials": {
                "AccessKeyId": "ASIA_RETRY",
                "SecretAccessKey": "secret2",
                "SessionToken": "tok2",
            }
        }
        mock_client = MagicMock()
        mock_client.assume_role.side_effect = [client_error, good_response]
        with patch("boto3.client", return_value=mock_client):
            creds = mgr.get_credentials("job1")
        assert creds["aws_access_key_id"] == "ASIA_RETRY"

    def test_schedule_background_refresh_no_config(self):
        config = _make_sts_config(with_sts=False)
        mgr = STSSessionManager(config)
        mgr._schedule_background_refresh()  # should not raise

    def test_schedule_background_refresh_no_expiry(self):
        config = _make_sts_config(with_sts=True)
        mgr = STSSessionManager(config)
        mgr._expiry = 0
        mgr._schedule_background_refresh()  # should not raise

    def test_get_ec2_client(self):
        config = _make_sts_config(with_sts=False)
        mgr = STSSessionManager(config)
        with patch("boto3.client", return_value=MagicMock()) as mock_bc:
            client = mgr.get_ec2_client("job1", region="us-west-2")
        mock_bc.assert_called_once()

    def test_get_pricing_client(self):
        config = _make_sts_config(with_sts=False)
        mgr = STSSessionManager(config)
        with patch("boto3.client", return_value=MagicMock()) as mock_bc:
            mgr.get_pricing_client("job1")
        mock_bc.assert_called_once()

    @pytest.mark.asyncio
    async def test_start_background_refresh_not_configured(self):
        config = _make_sts_config(with_sts=False)
        mgr = STSSessionManager(config)
        await mgr.start_background_refresh()  # no-op


# ─────────────────────────────────────────────────────────────────────────────
# shared/job_logger.py
# ─────────────────────────────────────────────────────────────────────────────

import shared.job_logger as jl


class TestJobLogger:
    @pytest.mark.asyncio
    async def test_log_event_success(self):
        mock_db = MagicMock()
        mock_table = MagicMock()
        mock_insert = MagicMock()
        mock_insert.execute = MagicMock()
        mock_table.insert.return_value = mock_insert
        mock_db.table.return_value = mock_table

        mock_db_mod = MagicMock()
        mock_db_mod.SUPABASE_URL = "https://example.supabase.co"
        mock_db_mod.get_db = MagicMock(return_value=mock_db)
        with patch.dict(os.environ, {"SUPABASE_URL": "https://example.supabase.co"}):
            with patch.dict("sys.modules", {"api.db": mock_db_mod}):
                await jl.log_event("job1", "u1", "job_started", "Job started", {"gpu": "H100"})
        mock_table.insert.assert_called_once()

    @pytest.mark.asyncio
    async def test_log_event_no_supabase(self):
        mock_db_mod = MagicMock()
        mock_db_mod.SUPABASE_URL = None
        mock_db_mod.get_db = MagicMock(return_value=None)
        with patch.dict("sys.modules", {"api.db": mock_db_mod}):
            await jl.log_event("job1", "u1", "job_started", "msg")
        # Should not raise

    @pytest.mark.asyncio
    async def test_log_event_db_exception_silent(self):
        mock_db = MagicMock()
        mock_db.table.side_effect = Exception("DB error")
        mock_db_mod = MagicMock()
        mock_db_mod.SUPABASE_URL = "https://example.supabase.co"
        mock_db_mod.get_db = MagicMock(return_value=mock_db)
        with patch.dict("sys.modules", {"api.db": mock_db_mod}):
            await jl.log_event("job1", "u1", "job_started", "msg")
        # Should not raise

    @pytest.mark.asyncio
    async def test_log_lines_empty(self):
        mock_db_mod = MagicMock()
        mock_db_mod.SUPABASE_URL = "https://example.supabase.co"
        mock_db_mod.get_db = MagicMock(return_value=MagicMock())
        with patch.dict("sys.modules", {"api.db": mock_db_mod}):
            await jl.log_lines("job1", "u1", [])  # no-op

    @pytest.mark.asyncio
    async def test_log_lines_whitespace_only(self):
        mock_db = MagicMock()
        mock_db_mod = MagicMock()
        mock_db_mod.SUPABASE_URL = "https://example.supabase.co"
        mock_db_mod.get_db = MagicMock(return_value=mock_db)
        with patch.dict("sys.modules", {"api.db": mock_db_mod}):
            await jl.log_lines("job1", "u1", ["   ", "\n", "\t"])  # only whitespace — filtered

    @pytest.mark.asyncio
    async def test_log_lines_success(self):
        mock_db = MagicMock()
        mock_table = MagicMock()
        mock_upsert = MagicMock()
        mock_upsert.execute = MagicMock()
        mock_table.upsert.return_value = mock_upsert
        mock_db.table.return_value = mock_table
        mock_db_mod = MagicMock()
        mock_db_mod.SUPABASE_URL = "https://example.supabase.co"
        mock_db_mod.get_db = MagicMock(return_value=mock_db)
        with patch.dict(os.environ, {"SUPABASE_URL": "https://example.supabase.co"}):
            with patch.dict("sys.modules", {"api.db": mock_db_mod}):
                await jl.log_lines("job1", "u1", ["line 1", "line 2"])
        mock_table.upsert.assert_called()

    @pytest.mark.asyncio
    async def test_log_lines_chunks(self):
        """Lines > _BULK_CHUNK should be split into multiple upserts."""
        mock_db = MagicMock()
        mock_table = MagicMock()
        mock_upsert = MagicMock()
        mock_upsert.execute = MagicMock()
        mock_table.upsert.return_value = mock_upsert
        mock_db.table.return_value = mock_table
        mock_db_mod = MagicMock()
        mock_db_mod.SUPABASE_URL = "https://example.supabase.co"
        mock_db_mod.get_db = MagicMock(return_value=mock_db)
        lines = [f"line {i}" for i in range(250)]  # > 200 chunk size
        with patch.dict(os.environ, {"SUPABASE_URL": "https://example.supabase.co"}):
            with patch.dict("sys.modules", {"api.db": mock_db_mod}):
                await jl.log_lines("job1", "u1", lines)
        assert mock_table.upsert.call_count == 2  # 250 lines → 2 chunks

    @pytest.mark.asyncio
    async def test_log_lines_no_supabase(self):
        mock_db_mod = MagicMock()
        mock_db_mod.SUPABASE_URL = None
        mock_db_mod.get_db = MagicMock(return_value=None)
        with patch.dict("sys.modules", {"api.db": mock_db_mod}):
            await jl.log_lines("job1", "u1", ["line"])


# ─────────────────────────────────────────────────────────────────────────────
# shared/provider_capacity.py
# ─────────────────────────────────────────────────────────────────────────────

import shared.provider_capacity as pc


@pytest.fixture(autouse=False)
def reset_capacity():
    """Reset capacity counters before and after each test."""
    pc._active_counts.clear()
    pc._active_jobs.clear()
    yield
    pc._active_counts.clear()
    pc._active_jobs.clear()


class TestProviderCapacity:
    def test_canonical_aws_returns_empty(self, reset_capacity):
        assert pc.canonical_provider_name("aws") == ""
        assert pc.canonical_provider_name("Amazon Web Services") == ""

    def test_canonical_lambda_labs(self, reset_capacity):
        assert pc.canonical_provider_name("lambda_labs") == "Lambda Labs"

    def test_canonical_coreweave(self, reset_capacity):
        assert pc.canonical_provider_name("coreweave") == "CoreWeave"

    def test_canonical_empty_string(self, reset_capacity):
        assert pc.canonical_provider_name("") == ""

    def test_canonical_fallback_title(self, reset_capacity):
        name = pc.canonical_provider_name("SomeNewProvider")
        assert name == "Somenewprovider"

    def test_get_max_jobs_unslotted(self, reset_capacity):
        assert pc.get_max_jobs("aws") == 0

    def test_get_max_jobs_slotted(self, reset_capacity):
        limit = pc.get_max_jobs("lambda_labs")
        assert limit > 0

    def test_get_active_count_zero(self, reset_capacity):
        assert pc.get_active_count("lambda_labs") == 0

    def test_claim_provider_slot_aws(self, reset_capacity):
        assert pc.claim_provider_slot("aws", "job1") is True

    def test_claim_and_release(self, reset_capacity):
        ok = pc.claim_provider_slot("lambda_labs", "job_abc")
        assert ok is True
        assert pc.get_active_count("lambda_labs") == 1
        released = pc.release_provider_slot("job_abc")
        assert released == "Lambda Labs"
        assert pc.get_active_count("lambda_labs") == 0

    def test_claim_idempotent_same_provider(self, reset_capacity):
        pc.claim_provider_slot("lambda_labs", "job_x")
        count_before = pc.get_active_count("lambda_labs")
        pc.claim_provider_slot("lambda_labs", "job_x")
        assert pc.get_active_count("lambda_labs") == count_before

    def test_claim_different_provider_releases_old(self, reset_capacity):
        pc.claim_provider_slot("lambda_labs", "job_y")
        assert pc.get_active_count("lambda_labs") == 1
        pc.claim_provider_slot("coreweave", "job_y")
        assert pc.get_active_count("lambda_labs") == 0
        assert pc.get_active_count("coreweave") == 1

    def test_release_unknown_job(self, reset_capacity):
        result = pc.release_provider_slot("nonexistent_job")
        assert result is None

    def test_release_clamps_at_zero(self, reset_capacity):
        pc._active_counts["Lambda Labs"] = 0
        pc._active_jobs["job_z"] = "Lambda Labs"
        pc.release_provider_slot("job_z")
        assert pc._active_counts.get("Lambda Labs", 0) == 0

    def test_is_provider_at_capacity_false(self, reset_capacity):
        assert pc.is_provider_at_capacity("lambda_labs") is False

    def test_is_provider_at_capacity_aws_never(self, reset_capacity):
        assert pc.is_provider_at_capacity("aws") is False

    def test_is_provider_at_capacity_true_when_full(self, reset_capacity):
        limit = pc.get_max_jobs("Voltage Park")
        pc._active_counts["Voltage Park"] = limit
        assert pc.is_provider_at_capacity("Voltage Park") is True

    def test_get_capacity_status(self, reset_capacity):
        dl._cache = MOCK_DATA
        pc.claim_provider_slot("lambda_labs", "job_status_1")
        status = pc.get_capacity_status()
        assert isinstance(status, dict)

    def test_claim_at_capacity_returns_false(self, reset_capacity):
        # Fill voltage park to its limit
        limit = pc.get_max_jobs("Voltage Park")
        pc._active_counts["Voltage Park"] = limit
        ok = pc.claim_provider_slot("Voltage Park", "job_over_limit")
        assert ok is False

    def test_acquire_provision_lock_allows_first_caller(self, reset_capacity):
        """acquire_provision_lock returns True when no lock exists (first caller)."""
        # No Redis in test env — falls back to True (allow)
        result = pc.acquire_provision_lock("job-lock-first")
        assert result is True

    def test_acquire_provision_lock_idempotent_no_redis(self, reset_capacity):
        """Without Redis, acquire_provision_lock always returns True (fail-open)
        and release_provision_lock is a safe no-op."""
        pc.acquire_provision_lock("job-lock-noop")
        pc.acquire_provision_lock("job-lock-noop")  # second call — no Redis, no block
        pc.release_provision_lock("job-lock-noop")   # must not raise


# ─────────────────────────────────────────────────────────────────────────────
# shared/job_logger.py — step_number deduplication
# ─────────────────────────────────────────────────────────────────────────────

class TestLogStepDedup:
    """Tests for _parse_step_number and the step-level dedup logic in log_lines."""

    def test_parse_step_number_plain(self):
        """'Step 100 loss=0.42' → 100"""
        from shared.job_logger import _parse_step_number
        assert _parse_step_number("Step 100 loss=0.42") == 100

    def test_parse_step_number_colon(self):
        """'step: 500' → 500"""
        from shared.job_logger import _parse_step_number
        assert _parse_step_number("step: 500") == 500

    def test_parse_step_number_global_step(self):
        """'global_step=1000 lr=1e-4' → 1000"""
        from shared.job_logger import _parse_step_number
        assert _parse_step_number("global_step=1000 lr=1e-4") == 1000

    def test_parse_step_number_case_insensitive(self):
        """'STEP 250' → 250"""
        from shared.job_logger import _parse_step_number
        assert _parse_step_number("STEP 250") == 250

    def test_parse_step_number_none_for_system_log(self):
        """'Bootstrapping node...' → None (no step in system lines)"""
        from shared.job_logger import _parse_step_number
        assert _parse_step_number("Bootstrapping node...") is None

    def test_parse_step_number_none_for_loss_only(self):
        """'loss=0.42 lr=2e-4' → None (no step keyword)"""
        from shared.job_logger import _parse_step_number
        assert _parse_step_number("loss=0.42 lr=2e-4") is None

    @pytest.mark.asyncio
    async def test_log_lines_upserts_with_step_number(self):
        """log_lines() must call upsert (not insert) for training lines so that
        duplicate step rows emitted on resume are silently discarded."""
        from unittest.mock import MagicMock, patch, AsyncMock
        import asyncio

        mock_table = MagicMock()
        mock_upsert_chain = MagicMock()
        mock_table.upsert.return_value = mock_upsert_chain
        mock_upsert_chain.execute.return_value = MagicMock()

        mock_db = MagicMock()
        mock_db.table.return_value = mock_table

        with patch('shared.job_logger._has_direct_db', return_value=True), \
             patch('shared.job_logger._db', return_value=mock_db):
            from shared.job_logger import log_lines
            await log_lines(
                "job-dedup-001", "user-001",
                ["Step 100 loss=0.42", "Step 101 loss=0.40"],
                source="training",
            )

        mock_table.upsert.assert_called(), \
            "log_lines must call upsert() for training lines, not insert()"
        mock_table.insert.assert_not_called(), \
            "log_lines must not call insert() — duplicates would bypass the unique constraint"

        # Verify ignore_duplicates=True is passed so conflicts are DO NOTHING
        call_kwargs = mock_table.upsert.call_args
        assert call_kwargs is not None
        kwargs = call_kwargs[1] if call_kwargs[1] else {}
        assert kwargs.get("ignore_duplicates") is True, \
            "upsert must pass ignore_duplicates=True to get ON CONFLICT DO NOTHING semantics"

    @pytest.mark.asyncio
    async def test_log_lines_includes_step_number_in_row(self):
        """Rows for training lines with a parseable step must include step_number
        so the UNIQUE (job_id, step_number) constraint can deduplicate them."""
        from unittest.mock import MagicMock, patch

        captured_rows = []

        mock_table = MagicMock()
        def _capture_upsert(rows, **kw):
            captured_rows.extend(rows)
            m = MagicMock()
            m.execute.return_value = MagicMock()
            return m
        mock_table.upsert.side_effect = _capture_upsert

        mock_db = MagicMock()
        mock_db.table.return_value = mock_table

        with patch('shared.job_logger._has_direct_db', return_value=True), \
             patch('shared.job_logger._db', return_value=mock_db):
            from shared.job_logger import log_lines
            await log_lines(
                "job-row-check", "user-001",
                ["Step 200 loss=0.35", "Processing batch..."],
                source="training",
            )

        step_rows   = [r for r in captured_rows if r.get("step_number") is not None]
        no_step_rows = [r for r in captured_rows if r.get("step_number") is None]

        assert len(step_rows) == 1, \
            f"Exactly one row should carry step_number; got step_rows={step_rows}"
        assert step_rows[0]["step_number"] == 200, \
            f"step_number must be 200, got {step_rows[0]['step_number']}"
        assert len(no_step_rows) == 1, \
            "Line without step keyword must have step_number=None (inserts normally)"


# ─────────────────────────────────────────────────────────────────────────────
# shared/telemetry.py
# ─────────────────────────────────────────────────────────────────────────────

from shared.telemetry import (
    TelemetryCollector, make_telemetry, Metric, MetricCategory, MetricType,
    _NoOpCollector, NOOP,
)


class TestTelemetry:
    def test_make_telemetry_enabled(self):
        tel = make_telemetry(queue=None, agent_name="test", enabled=True)
        assert isinstance(tel, TelemetryCollector)

    def test_make_telemetry_disabled_returns_noop(self):
        tel = make_telemetry(enabled=False)
        assert isinstance(tel, _NoOpCollector)

    def test_counter_emits(self):
        tel = TelemetryCollector(queue=None, agent_name="test")
        tel.counter("test.counter", 1.0, tags={"env": "test"})
        assert len(tel._buffer) == 1

    def test_gauge_emits(self):
        tel = TelemetryCollector(queue=None, agent_name="test")
        tel.gauge("test.gauge", 42.0, unit="MB")
        assert len(tel._buffer) == 1

    def test_timing_emits(self):
        tel = TelemetryCollector(queue=None, agent_name="test")
        tel.timing("test.duration", 500.0)
        assert len(tel._buffer) == 1

    def test_error_emits(self):
        tel = TelemetryCollector(queue=None, agent_name="test")
        tel.error("test.error", exc=Exception("oops"), tags={"provider": "AWS"})
        assert len(tel._buffer) == 1
        m = tel._buffer[0]
        assert m.category == MetricCategory.ERROR

    def test_error_with_message(self):
        tel = TelemetryCollector(queue=None, agent_name="test")
        tel.error("test.error", message="custom error message")
        assert tel._buffer[-1].error == "custom error message"

    def test_event_emits(self):
        tel = TelemetryCollector(queue=None, agent_name="test")
        tel.event("test.event", 1.0, tags={"gpu": "H100"}, job_id="j1")
        assert len(tel._buffer) == 1

    def test_decision_emits(self):
        tel = TelemetryCollector(queue=None, agent_name="test")
        tel.decision("migrate", 0.9, "success", savings_usd=5.0, job_id="j1")
        m = tel._buffer[-1]
        assert m.category == MetricCategory.DECISION

    def test_timer_context_manager(self):
        tel = TelemetryCollector(queue=None, agent_name="test")
        with tel.timer("test.timer"):
            pass
        assert any(m.name == "test.timer" for m in tel._buffer)

    @pytest.mark.asyncio
    async def test_flush_now_no_queue(self):
        tel = TelemetryCollector(queue=None, agent_name="test")
        tel.counter("x", 1.0)
        await tel.flush_now()

    def test_flush_buffer_large_creates_task(self):
        """When buffer >= 20, tries to create async task."""
        tel = TelemetryCollector(queue=None, agent_name="test")
        for i in range(20):
            tel._buffer.append(Metric(
                name=f"m{i}", category=MetricCategory.OPERATIONAL,
                metric_type=MetricType.COUNTER, value=1.0,
            ))
        # Emit one more — should try to flush (no running loop, so pass)
        tel.counter("trigger", 1.0)

    @pytest.mark.asyncio
    async def test_flush_with_queue(self):
        mock_redis = AsyncMock()
        mock_pipe = AsyncMock()
        mock_pipe.xadd = MagicMock()
        mock_pipe.hincrbyfloat = MagicMock()
        mock_pipe.hset = MagicMock()
        mock_pipe.hincrby = MagicMock()
        mock_pipe.execute = AsyncMock(return_value=[])
        mock_redis.pipeline = MagicMock(return_value=mock_pipe)
        mock_queue = MagicMock()
        mock_queue._redis = mock_redis
        tel = TelemetryCollector(queue=mock_queue, agent_name="test")
        tel.counter("test.counter", 1.0)
        tel.gauge("test.gauge", 5.0)
        tel.error("test.error", message="err")
        await tel._flush()
        mock_pipe.execute.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_flush_empty_buffer(self):
        tel = TelemetryCollector(queue=MagicMock(), agent_name="test")
        await tel._flush()  # nothing to flush

    @pytest.mark.asyncio
    async def test_get_summary_no_queue(self):
        tel = TelemetryCollector(queue=None)
        result = await tel.get_summary()
        assert result == {}

    def test_metric_to_dict(self):
        m = Metric(name="x", category=MetricCategory.JOB,
                   metric_type=MetricType.GAUGE, value=1.0)
        d = m.to_dict()
        assert d["name"] == "x"

    def test_metric_to_json(self):
        m = Metric(name="x", category=MetricCategory.JOB,
                   metric_type=MetricType.GAUGE, value=1.0)
        j = m.to_json()
        parsed = json.loads(j)
        assert parsed["name"] == "x"

    def test_noop_collector_sync_methods(self):
        noop = _NoOpCollector()
        noop.counter("x")
        noop.gauge("x", 1.0)
        noop.timing("x", 100.0)
        noop.error("x")
        noop.event("x")
        noop.decision("migrate", 0.9, "success")
        with noop.timer("x"):
            pass

    @pytest.mark.asyncio
    async def test_noop_collector_async_methods(self):
        noop = _NoOpCollector()
        await noop.flush_now()
        result = await noop.get_summary()
        assert result == {}


# ─────────────────────────────────────────────────────────────────────────────
# workers/feedback_worker.py
# ─────────────────────────────────────────────────────────────────────────────

class TestFeedbackWorker:
    @pytest.mark.asyncio
    async def test_run_worker_one_cycle_no_rows(self):
        """Worker runs one cycle, finds no pending rows, then exits via sleep mock."""
        mock_db = MagicMock()
        mock_table = MagicMock()
        mock_select = MagicMock()
        mock_select.execute.return_value.data = []
        mock_table.select.return_value.eq.return_value.order.return_value.limit.return_value = mock_select
        mock_db.table.return_value = mock_table

        mock_db_module = MagicMock()
        mock_db_module.get_db = MagicMock(return_value=mock_db)

        call_count = 0

        async def mock_sleep(seconds):
            nonlocal call_count
            call_count += 1
            if call_count >= 1:
                raise asyncio.CancelledError()

        import importlib
        import workers.feedback_worker as fw
        with patch.dict("sys.modules", {"api.db": mock_db_module}):
            importlib.reload(fw)
            with patch("workers.claude_bug_fixer.process_feedback", new=AsyncMock()):
                with patch("asyncio.sleep", side_effect=mock_sleep):
                    try:
                        await fw.run_worker()
                    except asyncio.CancelledError:
                        pass

    @pytest.mark.asyncio
    async def test_run_worker_processes_rows(self):
        """Worker finds pending rows and processes them."""
        mock_db = MagicMock()
        mock_table = MagicMock()
        mock_select = MagicMock()
        row = {"id": "fb1", "message": "broken", "status": "pending"}
        mock_select.execute.return_value.data = [row]
        mock_table.select.return_value.eq.return_value.order.return_value.limit.return_value = mock_select
        update_mock = MagicMock()
        update_mock.execute = MagicMock()
        mock_table.update.return_value.eq.return_value = update_mock
        mock_db.table.return_value = mock_table

        mock_db_module = MagicMock()
        mock_db_module.get_db = MagicMock(return_value=mock_db)

        call_count = 0

        async def mock_sleep(seconds):
            nonlocal call_count
            call_count += 1
            raise asyncio.CancelledError()

        mock_process = AsyncMock()
        import importlib
        import workers.feedback_worker as fw
        with patch.dict("sys.modules", {"api.db": mock_db_module}):
            importlib.reload(fw)
            with patch("workers.claude_bug_fixer.process_feedback", mock_process):
                with patch("asyncio.sleep", side_effect=mock_sleep):
                    try:
                        await fw.run_worker()
                    except asyncio.CancelledError:
                        pass

    @pytest.mark.asyncio
    async def test_run_worker_process_exception_rolls_back(self):
        """Processing error rolls status back to pending."""
        mock_db = MagicMock()
        mock_table = MagicMock()
        mock_select = MagicMock()
        row = {"id": "fb2", "message": "error row"}
        mock_select.execute.return_value.data = [row]
        mock_table.select.return_value.eq.return_value.order.return_value.limit.return_value = mock_select
        update_mock = MagicMock()
        update_mock.execute = MagicMock()
        mock_table.update.return_value.eq.return_value = update_mock
        mock_db.table.return_value = mock_table

        mock_db_module = MagicMock()
        mock_db_module.get_db = MagicMock(return_value=mock_db)

        call_count = 0

        async def mock_sleep(seconds):
            nonlocal call_count
            call_count += 1
            raise asyncio.CancelledError()

        async def failing_process(row):
            raise RuntimeError("Processing failed")

        import importlib
        import workers.feedback_worker as fw
        with patch.dict("sys.modules", {"api.db": mock_db_module}):
            importlib.reload(fw)
            with patch("workers.claude_bug_fixer.process_feedback", failing_process):
                with patch("asyncio.sleep", side_effect=mock_sleep):
                    try:
                        await fw.run_worker()
                    except asyncio.CancelledError:
                        pass

    @pytest.mark.asyncio
    async def test_run_worker_poll_exception(self):
        """Poll-level exception is caught, worker continues."""
        mock_db_module = MagicMock()
        mock_db_module.get_db = MagicMock(side_effect=Exception("DB down"))

        call_count = 0

        async def mock_sleep(seconds):
            nonlocal call_count
            call_count += 1
            raise asyncio.CancelledError()

        import importlib
        import workers.feedback_worker as fw
        with patch.dict("sys.modules", {"api.db": mock_db_module}):
            importlib.reload(fw)
            with patch("asyncio.sleep", side_effect=mock_sleep):
                try:
                    await fw.run_worker()
                except asyncio.CancelledError:
                    pass


# ─────────────────────────────────────────────────────────────────────────────
# workers/claude_bug_fixer.py
# ─────────────────────────────────────────────────────────────────────────────

from workers.claude_bug_fixer import (
    is_actionable, find_relevant_files, run_tests, _is_protected,
    _load_runbook, _leave_github_comment, git_create_branch,
    git_commit_and_push, _revert_branch, _check_mergeable,
)


class TestClaudeBugFixer:
    def test_is_actionable_with_traceback(self):
        feedback = {
            "traceback": "Traceback (most recent call last):\n  File 'x.py', line 10, in foo\n    raise ValueError",
            "error_type": "ValueError",
            "message": "oops",
        }
        ok, question = is_actionable(feedback)
        assert ok is True
        assert question == ""

    def test_is_actionable_without_enough_info(self):
        feedback = {"message": "something broke"}
        ok, question = is_actionable(feedback)
        assert ok is False
        assert "traceback" in question.lower()

    def test_is_actionable_with_job_id_and_error_type(self):
        feedback = {"error_type": "RuntimeError", "job_id": "job123"}
        ok, _ = is_actionable(feedback)
        assert ok is True

    def test_is_actionable_long_log_snippet(self):
        feedback = {"log_snippet": "x" * 150, "error_type": "Err"}
        ok, _ = is_actionable(feedback)
        assert ok is True

    def test_find_relevant_files_keyword_match(self):
        feedback = {"message": "provision failed", "traceback": ""}
        files = find_relevant_files(feedback)
        # "provision" keyword maps to broker/agent.py — may or may not exist
        assert isinstance(files, dict)

    def test_find_relevant_files_traceback_path(self):
        feedback = {
            "traceback": 'File "/app/src/shared/queue.py", line 50, in publish\n',
            "message": "",
        }
        files = find_relevant_files(feedback)
        assert isinstance(files, dict)

    def test_is_protected_true(self):
        assert _is_protected(".env") is True
        assert _is_protected(".github/workflows/ci.yml") is True
        assert _is_protected("schema/001.sql") is True

    def test_is_protected_false(self):
        assert _is_protected("src/shared/queue.py") is False
        assert _is_protected("tests/test_x.py") is False

    def test_load_runbook_missing(self):
        with patch("pathlib.Path.read_text", side_effect=OSError("not found")):
            result = _load_runbook()
        assert result == ""

    def test_load_runbook_exists(self):
        with patch("pathlib.Path.read_text", return_value="# Runbook\nstep1"):
            result = _load_runbook()
        assert "Runbook" in result

    def test_leave_github_comment(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/org/repo/issues/1"
        with patch("subprocess.run", return_value=mock_result):
            _leave_github_comment("fb1", "Could not fix: insufficient context")

    def test_leave_github_comment_failure(self):
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "auth error"
        with patch("subprocess.run", return_value=mock_result):
            _leave_github_comment("fb1", "reason")

    def test_run_tests_pass(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "passed"
        mock_result.stderr = ""
        with patch("subprocess.run", return_value=mock_result):
            passed, output = run_tests()
        assert passed is True

    def test_run_tests_fail(self):
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = "FAILED tests/test_x.py"
        mock_result.stderr = ""
        with patch("subprocess.run", return_value=mock_result):
            passed, output = run_tests()
        assert passed is False

    def test_git_create_branch(self):
        with patch("subprocess.run", return_value=MagicMock(returncode=0)) as mock_run:
            git_create_branch("fix/test-branch")
        assert mock_run.call_count == 3

    def test_git_commit_and_push(self):
        with patch("subprocess.run", return_value=MagicMock(returncode=0)) as mock_run:
            git_commit_and_push("fix/branch", "fix: test commit")
        assert mock_run.call_count == 3

    def test_revert_branch(self):
        with patch("subprocess.run", return_value=MagicMock(returncode=0)):
            _revert_branch("fix/test-branch")

    def test_check_mergeable_success(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps({"mergeable": "MERGEABLE", "mergeStateStatus": "CLEAN"})
        with patch("subprocess.run", return_value=mock_result):
            mergeable, reason = _check_mergeable("https://github.com/org/repo/pull/1")
        assert mergeable is True

    def test_check_mergeable_conflict(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps({"mergeable": "CONFLICTING", "mergeStateStatus": "DIRTY"})
        with patch("subprocess.run", return_value=mock_result):
            mergeable, reason = _check_mergeable("https://github.com/org/repo/pull/1")
        assert mergeable is False

    def test_check_mergeable_gh_failure(self):
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "auth error"
        with patch("subprocess.run", return_value=mock_result):
            mergeable, reason = _check_mergeable("https://github.com/org/repo/pull/1")
        assert mergeable is False

    def test_check_mergeable_timeout(self):
        """UNKNOWN response eventually times out."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps({"mergeable": "UNKNOWN"})
        # time is imported inside the function body — patch the module-level time.sleep
        import time as _real_time
        with patch("subprocess.run", return_value=mock_result):
            with patch.object(_real_time, "sleep", return_value=None):
                mergeable, reason = _check_mergeable("https://github.com/org/repo/pull/1")
        assert mergeable is False
        assert "timed out" in reason

    @pytest.mark.asyncio
    async def test_process_feedback_not_actionable(self):
        """Not-actionable feedback → awaiting_user status."""
        feedback = {"id": "fb1", "message": "vague", "user_id": "u1"}
        mock_db = MagicMock()
        mock_table = MagicMock()
        mock_update = MagicMock()
        mock_update.execute = MagicMock()
        mock_table.update.return_value.eq.return_value = mock_update
        user_select = MagicMock()
        user_select.execute.return_value.data = [{"email": "test@test.com"}]
        mock_table.select.return_value.eq.return_value = user_select
        mock_db.table.return_value = mock_table

        mock_db_module = MagicMock()
        mock_db_module.get_db = MagicMock(return_value=mock_db)
        mock_email_module = MagicMock()
        mock_email_module.send_needs_more_info = AsyncMock()

        import workers.claude_bug_fixer as cbf
        with patch.dict("sys.modules", {"api.db": mock_db_module, "api.email": mock_email_module}):
            with patch("anthropic.Anthropic"):
                with patch.object(cbf, "is_actionable", return_value=(False, "need more info")):
                    with patch.object(cbf, "find_relevant_files", return_value={}):
                        # Call the function with mocked internals
                        await cbf.process_feedback(feedback)

        # status should be set to awaiting_user
        calls = [str(c) for c in mock_table.update.call_args_list]
        assert any("awaiting_user" in c for c in calls)

    @pytest.mark.asyncio
    async def test_process_feedback_duplicate(self):
        """Duplicate feedback resolved via primary_feedback_id."""
        feedback = {
            "id": "fb2",
            "primary_feedback_id": "fb1",
            "message": "same bug",
        }
        mock_db = MagicMock()
        mock_table = MagicMock()
        # Primary is resolved
        primary_select = MagicMock()
        primary_select.execute.return_value.data = [{"status": "resolved", "pr_url": "http://pr/1"}]
        mock_table.select.return_value.eq.return_value = primary_select
        update_mock = MagicMock()
        update_mock.execute = MagicMock()
        mock_table.update.return_value.eq.return_value = update_mock
        mock_db.table.return_value = mock_table

        mock_db_module = MagicMock()
        mock_db_module.get_db = MagicMock(return_value=mock_db)
        mock_email_module = MagicMock()
        mock_email_module.send_needs_more_info = AsyncMock()

        import workers.claude_bug_fixer as cbf
        with patch.dict("sys.modules", {"api.db": mock_db_module, "api.email": mock_email_module}):
            with patch("anthropic.Anthropic"):
                with patch.object(cbf, "notify_reporters", new=AsyncMock()):
                    await cbf.process_feedback(feedback)
