"""Regression tests for _find_checkpoint's HF / legacy format recognition.

The 2026-04-21 contract standardized on HF `checkpoint-<N>/` directories
(docs/job_contract.md §3). Before the fix, _find_checkpoint only recognized
the legacy flat-file `ckpt_step_<N>.pt` format, so every post-refactor job
got "Instance lost, no checkpoint found" on failover even when checkpoints
existed in R2. Caught via demo_resume.py run on job 909c4358.

These tests mock boto3.client and pin:
  * HF format is recognized (canonical path today)
  * Legacy format is still recognized (backward compat for mid-migration jobs)
  * Mixed format: latest step wins across formats
  * Empty R2 returns None
  * Job_id containing "checkpoint-" substring isn't mis-parsed
"""
from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def _make_env(monkeypatch):
    monkeypatch.setenv("R2_ENDPOINT", "https://fake.r2.com")
    monkeypatch.setenv("R2_ACCESS_KEY_ID", "k")
    monkeypatch.setenv("R2_SECRET_ACCESS_KEY", "s")
    monkeypatch.setenv("R2_BUCKET", "test-bucket")


def _fake_s3(contents: list[dict]):
    """Return a MagicMock that mimics boto3.client('s3') with the given listing."""
    s3 = MagicMock()
    s3.list_objects_v2 = MagicMock(return_value={"Contents": contents})
    return s3


def test_hf_checkpoint_format_recognized(monkeypatch):
    """`checkpoint-<N>/` subdirs (HF Trainer output) must be detected."""
    _make_env(monkeypatch)
    contents = [
        {"Key": "checkpoints/job-1/checkpoint-50/model.safetensors", "Size": 1000},
        {"Key": "checkpoints/job-1/checkpoint-50/optimizer.pt", "Size": 500},
        {"Key": "checkpoints/job-1/checkpoint-100/model.safetensors", "Size": 1000},
        {"Key": "checkpoints/job-1/checkpoint-100/optimizer.pt", "Size": 500},
    ]
    with patch("boto3.client", return_value=_fake_s3(contents)):
        from api.job_worker import _find_checkpoint
        result = _find_checkpoint("job-1")
    assert result is not None, "HF checkpoint-N/ format must be recognized"
    assert result["step"] == 100, f"expected latest step 100, got {result['step']}"
    assert result["size_bytes"] == 3000


def test_legacy_format_still_recognized(monkeypatch):
    """Pre-2026-04-21 `ckpt_step_<N>.pt` format — backward compat."""
    _make_env(monkeypatch)
    contents = [
        {"Key": "checkpoints/job-2/ckpt_step_50.pt", "Size": 2000},
        {"Key": "checkpoints/job-2/ckpt_step_100.pt", "Size": 2500},
    ]
    with patch("boto3.client", return_value=_fake_s3(contents)):
        from api.job_worker import _find_checkpoint
        result = _find_checkpoint("job-2")
    assert result is not None
    assert result["step"] == 100


def test_mixed_formats_latest_wins(monkeypatch):
    """If both formats coexist (mid-migration job), latest step wins."""
    _make_env(monkeypatch)
    contents = [
        {"Key": "checkpoints/job-3/ckpt_step_50.pt", "Size": 1000},
        {"Key": "checkpoints/job-3/checkpoint-150/model.safetensors", "Size": 2000},
    ]
    with patch("boto3.client", return_value=_fake_s3(contents)):
        from api.job_worker import _find_checkpoint
        result = _find_checkpoint("job-3")
    assert result["step"] == 150


def test_empty_r2_returns_none(monkeypatch):
    _make_env(monkeypatch)
    with patch("boto3.client", return_value=_fake_s3([])):
        from api.job_worker import _find_checkpoint
        assert _find_checkpoint("job-4") is None


def test_job_id_containing_checkpoint_substring(monkeypatch):
    """Edge case: if job_id itself contained 'checkpoint-' the old parser
    would have misread the path. Prefix-stripping protects against this."""
    _make_env(monkeypatch)
    contents = [
        {"Key": "checkpoints/checkpoint-weirdjob/checkpoint-50/model.safetensors", "Size": 100},
    ]
    with patch("boto3.client", return_value=_fake_s3(contents)):
        from api.job_worker import _find_checkpoint
        result = _find_checkpoint("checkpoint-weirdjob")
    assert result is not None
    assert result["step"] == 50, f"expected step 50, got {result}"


def test_no_credentials_returns_none(monkeypatch):
    monkeypatch.delenv("R2_ENDPOINT", raising=False)
    monkeypatch.delenv("R2_ACCESS_KEY_ID", raising=False)
    monkeypatch.delenv("R2_SECRET_ACCESS_KEY", raising=False)
    from api.job_worker import _find_checkpoint
    assert _find_checkpoint("any-job") is None
