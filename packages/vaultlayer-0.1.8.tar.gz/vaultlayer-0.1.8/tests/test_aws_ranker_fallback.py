"""Tier-1 tests: AWS ranker + cross-region fallback + OD fallback — pure logic.

Every bug we've shipped a fix for this cycle has a regression test here.
Runs in <1 sec. Catches the things prod smoke was catching at 30-min-per-bug.

Coverage map (bug → test):
  1. Short-circuit `return None` on last-region retry-worthy error
       → test_od_fallback_invoked_when_spot_exhausts_all_regions
  2. OD error swallowed by generic "fallback unavailable"
       → test_error_message_includes_both_spot_and_od_breakdowns
  3. MaxSpotInstanceCountExceeded not in retry list
       → test_maxspot_triggers_cross_region_retry
  4. VcpuLimitExceeded not in retry list
       → test_vcpulimit_triggers_cross_region_retry
  5. Unsupported instance type burns a RunInstances call
       → test_pre_filter_drops_regions_that_dont_offer_instance_type
  6. Hardcoded region skips user's primary
       → test_primary_region_honored_when_supported
  7. Cooldown not respected → retry same wall
       → test_region_in_cooldown_sorts_last
  8. OD fallback called even when disabled
       → test_od_fallback_skipped_when_env_disabled
  9. All-regions-fail error message doesn't list per-region codes
       → test_per_region_error_codes_accumulated_in_final_message

Fixtures keep the surface tiny: one AWS-configured BrokerAgent, one Job,
then each test controls run_instances() behavior via side_effect per region.
"""
from __future__ import annotations

import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from botocore.exceptions import ClientError

from agents.broker.agent import BrokerAgent
from agents.broker.providers import aws_capacity, region_planner
from conftest import make_job


# ─────────────────────────────────────────────────────────────────────────────
# Shared helpers — per-region control harness
# ─────────────────────────────────────────────────────────────────────────────

def _make_client_error(code: str, op: str = "RunInstances") -> ClientError:
    """Build a boto3 ClientError with a specific error code."""
    return ClientError(
        error_response={"Error": {"Code": code, "Message": f"Mocked {code}"}},
        operation_name=op,
    )


def _ec2_mock(
    *,
    offerings: bool = True,
    spot_price: float = 0.30,
    run_instances_result=None,
    run_instances_error: Exception = None,
):
    """Build an EC2 MagicMock that returns controlled responses.

    offerings            — True = region offers the instance type
    spot_price           — float price for describe_spot_price_history
    run_instances_result — if provided, return this dict on run_instances()
    run_instances_error  — if provided, raise this on run_instances()
    """
    mock = MagicMock()
    mock.describe_instance_type_offerings.return_value = {
        "InstanceTypeOfferings": [{"InstanceType": "g5.xlarge"}] if offerings else [],
    }
    import datetime as _dt
    mock.describe_spot_price_history.return_value = {
        "SpotPriceHistory": [{
            "AvailabilityZone": "us-east-1a",
            "SpotPrice": str(spot_price),
            "Timestamp": _dt.datetime.utcnow(),
            "InstanceType": "g5.xlarge",
        }],
    }
    # For launch-template helpers (VPC endpoint + AMI lookup)
    mock.describe_vpcs.return_value = {"Vpcs": [{"VpcId": "vpc-test"}]}
    mock.describe_vpc_endpoints.return_value = {"VpcEndpoints": [{"VpcEndpointId": "vpce-test"}]}
    mock.describe_images.return_value = {
        "Images": [{"ImageId": "ami-0test", "CreationDate": "2024-01-01T00:00:00Z"}],
    }
    mock.describe_key_pairs.return_value = {"KeyPairs": [{"KeyName": "vl-test"}]}
    mock.create_launch_template.return_value = {}
    mock.delete_launch_template.return_value = {}
    mock.describe_instances.return_value = {
        "Reservations": [{"Instances": [{"State": {"Name": "running"}}]}],
    }
    if run_instances_error is not None:
        mock.run_instances.side_effect = run_instances_error
    else:
        mock.run_instances.return_value = run_instances_result or {
            "Instances": [{"InstanceId": "i-spot-success"}],
        }
    return mock


class _RegionRouter:
    """Route each get_ec2_client(region=X) to a different configured mock.

    Lets a single test set up distinct per-region behavior (e.g. ICE in
    us-east-2, success in us-east-1) without retyping the harness.
    """
    def __init__(self, per_region_mocks: dict):
        self.per_region = per_region_mocks
        self.default = _ec2_mock()
        self.calls: list[str] = []

    def __call__(self, *args, **kwargs):
        region = kwargs.get("region") or (args[1] if len(args) > 1 else None)
        self.calls.append(region)
        return self.per_region.get(region, self.default)


@pytest.fixture(autouse=True)
def _reset_caches():
    """Wipe cross-test state — caches are in-process."""
    aws_capacity._offerings_cache.clear()
    aws_capacity._price_cache.clear()
    region_planner._cooldown.clear()
    yield


@pytest.fixture
def aws_broker(dummy_config, mock_queue, monkeypatch):
    """BrokerAgent wired for AWS tests."""
    monkeypatch.setenv("VL_AWS_REGION_LOCKED", "")  # default: cross-region on
    monkeypatch.setenv("VL_AWS_OD_FALLBACK_ENABLED", "true")
    # Primary region — tests can override via dummy_config.aws.region
    dummy_config.aws.region = "us-east-2"
    return BrokerAgent(config=dummy_config, queue=mock_queue)


async def _provision(broker, **router_kwargs):
    """Run provision_aws with a RegionRouter; return (instance_id, router)."""
    from shared.models import GPUType
    router = _RegionRouter(router_kwargs.get("per_region", {}))
    broker._sts.get_ec2_client = router
    job = make_job()
    with patch("asyncio.sleep", new_callable=AsyncMock):
        instance_id = await broker.provision_aws(GPUType.A10G, job)
    return instance_id, router, job


# ═════════════════════════════════════════════════════════════════════════════
# Regression tests — one per bug we've shipped a fix for
# ═════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_od_fallback_invoked_when_spot_exhausts_all_regions(aws_broker):
    """BUG: last-region retry-worthy error used to `return None` before OD.

    Fix 19e4e06: `break` instead of return so control reaches OD fallback.
    """
    ice_in_every_region = _ec2_mock(
        run_instances_error=_make_client_error("InsufficientInstanceCapacity"),
    )
    # OD request (same mock, different call) succeeds
    # Since we reuse the same mock per region, once spot ICE bubbles up and
    # OD is invoked, we need OD's run_instances to succeed. We do this by
    # making run_instances succeed after N failed spot calls.
    call_count = {"n": 0}
    def _side_effect(*args, **kwargs):
        call_count["n"] += 1
        # First 5 calls = spot attempts in 5 regions → all ICE
        # 6th+ calls = OD attempts → succeed on first OD call
        if call_count["n"] <= 5:
            raise _make_client_error("InsufficientInstanceCapacity")
        return {"Instances": [{"InstanceId": "i-od-success"}]}
    ice_in_every_region.run_instances.side_effect = _side_effect

    instance_id, router, job = await _provision(
        aws_broker,
        per_region={r: ice_in_every_region for r in
                    ["us-east-2", "us-west-2", "us-east-1", "eu-west-1", "ap-southeast-1"]},
    )
    assert instance_id == "i-od-success", (
        f"OD fallback should provision after spot exhausts, "
        f"got {instance_id}, error={getattr(job, 'last_provision_error', None)}"
    )
    assert job.__dict__.get("fallback_reason") == "aws_od_last_resort", \
        "OD leg must be tagged so FinOps skips gainshare markup"


@pytest.mark.asyncio
async def test_error_message_includes_both_spot_and_od_breakdowns(aws_broker):
    """BUG: OD error was overwritten by generic "fallback unavailable"."""
    ice = _ec2_mock(run_instances_error=_make_client_error("InsufficientInstanceCapacity"))
    vcpu = _ec2_mock(run_instances_error=_make_client_error("VcpuLimitExceeded"))
    # Spot ICE in all, OD VcpuLimit in all — we use run_instances side_effect
    # that alternates based on whether SpotOptions is present in kwargs.
    def _side_effect(**kwargs):
        is_spot = "InstanceMarketOptions" in kwargs
        if is_spot:
            raise _make_client_error("InsufficientInstanceCapacity")
        raise _make_client_error("VcpuLimitExceeded")
    combined = _ec2_mock()
    combined.run_instances.side_effect = _side_effect
    instance_id, _, job = await _provision(
        aws_broker,
        per_region={r: combined for r in
                    ["us-east-2", "us-west-2", "us-east-1", "eu-west-1", "ap-southeast-1"]},
    )
    assert instance_id is None
    err = job.last_provision_error or ""
    assert "InsufficientInstanceCapacity" in err, f"spot error missing: {err}"
    assert "VcpuLimitExceeded" in err, f"OD error missing: {err}"
    assert "spot exhausted" in err and "OD fallback also failed" in err, \
        f"final message should chain both breakdowns: {err}"


@pytest.mark.asyncio
@pytest.mark.parametrize("code", [
    "MaxSpotInstanceCountExceeded",
    "VcpuLimitExceeded",
    "InstanceLimitExceeded",
    "InsufficientInstanceCapacity",
])
async def test_retry_codes_trigger_cross_region_retry(aws_broker, code):
    """BUG: MaxSpotInstanceCountExceeded et al. weren't in the retry list.

    Fix 94507c9: added them. This locks that in."""
    # First 2 regions fail, 3rd succeeds → assert 3 calls, instance returned
    call_count = {"n": 0}
    def _side_effect(*args, **kwargs):
        call_count["n"] += 1
        if call_count["n"] <= 2:
            raise _make_client_error(code)
        return {"Instances": [{"InstanceId": "i-spot-win"}]}
    mock = _ec2_mock()
    mock.run_instances.side_effect = _side_effect
    instance_id, router, _ = await _provision(
        aws_broker,
        per_region={r: mock for r in
                    ["us-east-2", "us-west-2", "us-east-1", "eu-west-1", "ap-southeast-1"]},
    )
    assert instance_id == "i-spot-win", f"should succeed on 3rd region for {code}"
    assert call_count["n"] == 3, f"should have attempted exactly 3 regions for {code}"


@pytest.mark.asyncio
async def test_pre_filter_drops_regions_that_dont_offer_instance_type(aws_broker):
    """BUG: ap-southeast-1 was burning RunInstances calls returning 'Unsupported'.

    Fix (3ef2ce1 + 2a2810f): describe_instance_type_offerings pre-filter."""
    # us-east-2 offers, all others don't → only us-east-2 should see run_instances
    supporting = _ec2_mock(offerings=True)
    unsupporting = _ec2_mock(offerings=False)

    router = _RegionRouter({
        "us-east-2":      supporting,
        "us-west-2":      unsupporting,
        "us-east-1":      unsupporting,
        "eu-west-1":      unsupporting,
        "ap-southeast-1": unsupporting,
    })
    aws_broker._sts.get_ec2_client = router
    from shared.models import GPUType
    with patch("asyncio.sleep", new_callable=AsyncMock):
        instance_id = await aws_broker.provision_aws(GPUType.A10G, make_job())
    assert instance_id == "i-spot-success", \
        "us-east-2 (the only supporting region) should succeed"
    supporting.run_instances.assert_called_once()
    unsupporting.run_instances.assert_not_called()


@pytest.mark.asyncio
async def test_primary_region_honored_when_supported(aws_broker):
    """BUG (early-cycle): hardcoded us-west-2 primary ignored user's config."""
    aws_broker.config.aws.region = "us-east-1"  # user pins us-east-1
    mock = _ec2_mock()  # happy path everywhere
    router = _RegionRouter({r: mock for r in
        ["us-east-2", "us-west-2", "us-east-1", "eu-west-1", "ap-southeast-1"]})
    aws_broker._sts.get_ec2_client = router
    from shared.models import GPUType
    with patch("asyncio.sleep", new_callable=AsyncMock):
        await aws_broker.provision_aws(GPUType.A10G, make_job())
    assert router.calls[0] == "us-east-1", \
        f"user's primary region must be first attempt, got {router.calls}"


def test_region_in_cooldown_sorts_last():
    """BUG: after quota failure in region X, next job still tries X first.

    Asserts rank_regions() output directly — the planner contract —
    rather than tracing the provision() attempt sequence.
    """
    # Cool down us-east-2
    aws_capacity.record_failure("us-east-2", "MaxSpotInstanceCountExceeded")

    def _factory(_region):
        return _ec2_mock()

    # Primary = us-west-2 (not cooled). us-east-2 is cooled → should sort LAST.
    ordered, dropped = aws_capacity.rank_regions(
        candidate_regions=["us-west-2", "us-east-1", "us-east-2", "eu-west-1"],
        instance_type="g5.xlarge",
        ec2_factory=_factory,
        primary_region="us-west-2",
    )
    assert dropped == [], f"all regions offer the type, none should be dropped: {dropped}"
    assert ordered[0] == "us-west-2", f"primary first, got {ordered}"
    assert ordered[-1] == "us-east-2", \
        f"cooled region must sort last, got {ordered}"


@pytest.mark.asyncio
async def test_od_fallback_skipped_when_env_disabled(aws_broker, monkeypatch):
    """BUG check: VL_AWS_OD_FALLBACK_ENABLED=false must NOT invoke OD."""
    monkeypatch.setenv("VL_AWS_OD_FALLBACK_ENABLED", "false")
    mock = _ec2_mock(run_instances_error=_make_client_error("InsufficientInstanceCapacity"))
    instance_id, router, job = await _provision(
        aws_broker,
        per_region={r: mock for r in
                    ["us-east-2", "us-west-2", "us-east-1", "eu-west-1", "ap-southeast-1"]},
    )
    assert instance_id is None
    # Call count = 5 (spot only, one per region); no OD attempts
    assert mock.run_instances.call_count == 5, \
        f"OD should not invoke run_instances when disabled; saw {mock.run_instances.call_count}"
    assert "OD fallback disabled" in (job.last_provision_error or "")


@pytest.mark.asyncio
async def test_per_region_error_codes_accumulated_in_final_message(aws_broker, monkeypatch):
    """BUG: earlier versions surfaced only the last region's error."""
    monkeypatch.setenv("VL_AWS_OD_FALLBACK_ENABLED", "false")  # keep msg tight
    codes = {
        "us-east-2":      "MaxSpotInstanceCountExceeded",
        "us-west-2":      "InsufficientInstanceCapacity",
        "us-east-1":      "MaxSpotInstanceCountExceeded",
        "eu-west-1":      "VcpuLimitExceeded",
        "ap-southeast-1": "InsufficientInstanceCapacity",
    }
    per_region = {
        r: _ec2_mock(run_instances_error=_make_client_error(c))
        for r, c in codes.items()
    }
    instance_id, _, job = await _provision(aws_broker, per_region=per_region)
    assert instance_id is None
    err = job.last_provision_error or ""
    # Every region's code must appear in the final message
    for region, code in codes.items():
        assert f"{region}:{code}" in err, f"missing {region}:{code} in: {err}"


@pytest.mark.asyncio
async def test_happy_path_spot_succeeds_on_first_region(aws_broker):
    """Baseline: when spot is available, we land it immediately."""
    mock = _ec2_mock(
        run_instances_result={"Instances": [{"InstanceId": "i-happy"}]},
    )
    instance_id, router, job = await _provision(
        aws_broker,
        per_region={r: mock for r in
                    ["us-east-2", "us-west-2", "us-east-1", "eu-west-1", "ap-southeast-1"]},
    )
    assert instance_id == "i-happy"
    mock.run_instances.assert_called_once()
    # No OD leg — fallback_reason should NOT be set
    assert job.__dict__.get("fallback_reason") is None


@pytest.mark.asyncio
async def test_non_retryable_error_fails_fast(aws_broker):
    """Auth errors should not iterate regions — fail immediately."""
    auth_err = _make_client_error("AuthFailure")
    mock = _ec2_mock(run_instances_error=auth_err)
    instance_id, _, job = await _provision(
        aws_broker,
        per_region={r: mock for r in
                    ["us-east-2", "us-west-2", "us-east-1", "eu-west-1", "ap-southeast-1"]},
    )
    assert instance_id is None
    # Should have tried exactly 1 region, not all 5
    assert mock.run_instances.call_count == 1, \
        f"auth error should fail fast on first region; saw {mock.run_instances.call_count} attempts"
    assert "AuthFailure" in (job.last_provision_error or "")


@pytest.mark.asyncio
async def test_vl_aws_region_locked_disables_fallback(aws_broker, monkeypatch):
    """Region-locked mode: one region only, no fallback."""
    monkeypatch.setenv("VL_AWS_REGION_LOCKED", "1")
    monkeypatch.setenv("VL_AWS_OD_FALLBACK_ENABLED", "false")
    mock = _ec2_mock(run_instances_error=_make_client_error("InsufficientInstanceCapacity"))
    instance_id, _, job = await _provision(
        aws_broker,
        per_region={r: mock for r in
                    ["us-east-2", "us-west-2", "us-east-1", "eu-west-1", "ap-southeast-1"]},
    )
    assert instance_id is None
    assert mock.run_instances.call_count == 1, \
        f"region-locked should not fall back; saw {mock.run_instances.call_count} attempts"
