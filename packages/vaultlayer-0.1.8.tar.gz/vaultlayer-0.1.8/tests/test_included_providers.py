"""Tests for the included_providers allowlist (config-driven dispatcher gate).

Why this exists:
  As of 2026-04-21 the allowlist has three states (see docs/provider_test_matrix.md
  + docs/provider_testing_matrix.md):
    * `providers` (included): Vast.ai / RunPod / Lambda Labs — routable by anyone
    * `testing`: AWS / AWS Spot — routable by VL_TEST_USER_IDS only, never in
       regular-user failover
    * `pending`: GCP / CoreWeave / Crusoe / Nebius / Voltage Park / Hyperstack /
       Azure — fully blocked

Moving between states is a one-line config edit in vaultlayer_data.json.

The three-state behaviors are pinned in test_provider_testing_state.py
(getters, env-var parsing, pool composition, classification). This file
pins the config invariant and the static-import contracts so a regression
in the dispatcher's allowlist plumbing fails here too.
"""
from __future__ import annotations

import json
import pathlib

import pytest


def test_included_providers_config_has_3_validated_providers():
    """Today's allowlist must contain the end-to-end-validated providers.
    Adding more requires recording a green TinyLlama+Qwen sweep in
    docs/provider_test_matrix.md first (promotion criteria documented in
    docs/provider_testing_matrix.md).
    As of 2026-04-22: Vast.ai, RunPod, Lambda Labs, AWS Spot (promoted after
    Lambda→AWS failover 6h+ run c7d713bb)."""
    cfg = json.loads(pathlib.Path("config/vaultlayer_data.json").read_text())
    inc = cfg.get("included_providers", {})
    providers = inc.get("providers", [])
    required = {"Vast.ai", "RunPod", "Lambda Labs", "AWS Spot"}
    assert required.issubset(set(providers)), \
        f"Allowlist missing required providers. Got: {providers}"

    # AWS on-demand lives in `testing` (not yet fully validated).
    testing = set(inc.get("testing", []))
    assert "AWS" in testing, \
        "AWS (on-demand) should be in `testing` state (see docs/provider_testing_matrix.md)"

    # Pending list isn't ordered/exhaustive but should at minimum include the
    # quota-blocked clouds so the validator gives a clear error message.
    pending = set(inc.get("pending", []))
    for must_be_pending in ("GCP", "CoreWeave"):
        assert must_be_pending in pending, \
            f"{must_be_pending} should be listed pending until validated"

    # The three lists must not overlap — a provider is in exactly one state.
    inc_set = set(inc.get("providers", []))
    assert not (inc_set & testing), \
        f"provider in both included AND testing: {inc_set & testing}"
    assert not (inc_set & pending), \
        f"provider in both included AND pending: {inc_set & pending}"
    assert not (testing & pending), \
        f"provider in both testing AND pending: {testing & pending}"


def test_data_loader_returns_included_and_pending_lists():
    from shared.data_loader import (
        get_included_providers, get_pending_providers, get_testing_providers,
    )
    inc = get_included_providers()
    pen = get_pending_providers()
    tst = get_testing_providers()
    assert isinstance(inc, list) and len(inc) >= 3  # 4 as of AWS Spot promotion 2026-04-22
    assert isinstance(pen, list) and len(pen) >= 1
    assert isinstance(tst, list)  # may be empty on deployments that haven't
                                   # opted in to the testing tier
    # No overlap across the three lists — enforced by the invariant above
    # (config-level). Data-loader just reflects whatever the config says.
    assert not (set(inc) & set(pen)), "inc ∩ pen must be empty"
    assert not (set(inc) & set(tst)), "inc ∩ testing must be empty"
    assert not (set(pen) & set(tst)), "pen ∩ testing must be empty"


def test_dispatcher_skips_non_included_providers():
    """Static check: job_worker._try_provision must consult the allowlist.
    Full provision-flow integration is in test_aws_ranker_fallback /
    test_gcp_zone_fallback; here we just pin the inclusion of the filter."""
    src = pathlib.Path("src/api/job_worker.py").read_text()
    assert "get_included_providers" in src, \
        "dispatcher must import get_included_providers"
    # Under the three-state model, failover pool is built from include ∪
    # (testing if user_can_use_testing_providers). Pin both imports so a
    # future refactor can't silently drop the testing-user path.
    assert "user_can_use_testing_providers" in src, \
        "dispatcher must consult user_can_use_testing_providers for failover pool"


def test_submit_validator_rejects_pending_providers():
    """Static check: /jobs/run validator must reject preferred_providers
    that aren't in the allowlist, with a clear error message that
    distinguishes the three states (pending / testing / unknown)."""
    src = pathlib.Path("src/api/job_routes.py").read_text()
    assert "get_included_providers" in src
    # The new validator produces three distinct error messages; pin each
    # substring so we don't accidentally collapse back to one message.
    assert "pending providers" in src, \
        "pending-state rejection must say 'pending providers' (blocked for everyone)"
    assert "testing-state providers" in src, \
        "testing-state rejection must name it so test users know they're not allowlisted"
    assert "unknown providers" in src, \
        "unknown-provider rejection must call out unknown (not in any of the three lists)"
