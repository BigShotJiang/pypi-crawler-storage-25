"""GAP-27: download_shards_parallel() must verify SHA256 on each shard.

Pinned in r2.py at the shard download loop. Previously only
download_checkpoint() verified; bit-flip on a shard slipped past
silently and decompressed to garbage weights.
"""
from __future__ import annotations

import hashlib
import sys
import zlib
from io import BytesIO
from pathlib import Path
from unittest.mock import MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import pytest


def _make_s3_mock(key_to_compressed: dict[str, tuple[bytes, str | None]]):
    """Build a MagicMock S3 client whose get_object returns compressed bytes
    + optional sha256 metadata keyed by the requested Key."""
    s3 = MagicMock()
    def _get(Bucket, Key):
        compressed, sha = key_to_compressed[Key]
        meta = {}
        if sha is not None:
            meta["sha256"] = sha
        return {
            "Body": BytesIO(compressed),
            "Metadata": meta,
            "ResponseMetadata": {"HTTPHeaders": {}},
        }
    s3.get_object.side_effect = _get
    return s3


def _make_client(s3, bucket="vl-checkpoints"):
    from agents.vault.r2 import R2Client
    c = R2Client.__new__(R2Client)
    c._s3 = s3
    c.bucket = bucket
    return c


class TestShardSha256Verification:
    def test_happy_path_matching_sha256_passes(self, tmp_path):
        data = b"valid shard contents" * 64
        compressed = zlib.compress(data)
        sha = hashlib.sha256(compressed).hexdigest()

        s3 = _make_s3_mock({"shard-0.bin": (compressed, sha)})
        client = _make_client(s3)

        paths = client.download_shards_parallel(
            r2_keys=["shard-0.bin"],
            target_dir=str(tmp_path),
            max_workers=1,
        )
        assert len(paths) == 1
        assert Path(paths[0]).read_bytes() == data

    def test_corrupt_shard_raises_value_error(self, tmp_path):
        """Uploader claimed sha=X but R2 returned bytes hashing to Y.
        The download must raise ValueError instead of writing garbage."""
        data = b"original content" * 64
        corrupt = b"tampered content" * 64  # different bytes, different hash
        compressed_corrupt = zlib.compress(corrupt)
        # The metadata claims the hash of the ORIGINAL, not what R2 returned.
        claimed_sha = hashlib.sha256(zlib.compress(data)).hexdigest()

        s3 = _make_s3_mock({"shard-0.bin": (compressed_corrupt, claimed_sha)})
        client = _make_client(s3)

        with pytest.raises(ValueError, match="checksum mismatch"):
            client.download_shards_parallel(
                r2_keys=["shard-0.bin"],
                target_dir=str(tmp_path),
                max_workers=1,
            )

    def test_no_sha256_in_metadata_skips_check(self, tmp_path):
        """Back-compat: shards uploaded by old code without sha256 metadata
        still download — we can't verify what wasn't stored, but we must
        not reject legitimate data."""
        data = b"legacy shard no metadata" * 64
        compressed = zlib.compress(data)

        s3 = _make_s3_mock({"shard-0.bin": (compressed, None)})
        client = _make_client(s3)

        paths = client.download_shards_parallel(
            r2_keys=["shard-0.bin"],
            target_dir=str(tmp_path),
            max_workers=1,
        )
        assert Path(paths[0]).read_bytes() == data

    def test_multiple_shards_one_corrupt_fails(self, tmp_path):
        """Any single shard mismatch must propagate as ValueError
        regardless of other shards succeeding."""
        good_data = b"good shard data" * 64
        good_compressed = zlib.compress(good_data)
        good_sha = hashlib.sha256(good_compressed).hexdigest()

        bad_data = b"bad shard data" * 64
        bad_compressed = zlib.compress(bad_data)
        wrong_sha = hashlib.sha256(b"different").hexdigest()

        s3 = _make_s3_mock({
            "shard-0.bin": (good_compressed, good_sha),
            "shard-1.bin": (bad_compressed, wrong_sha),
        })
        client = _make_client(s3)

        with pytest.raises(ValueError, match="checksum mismatch"):
            client.download_shards_parallel(
                r2_keys=["shard-0.bin", "shard-1.bin"],
                target_dir=str(tmp_path),
                max_workers=2,
            )
