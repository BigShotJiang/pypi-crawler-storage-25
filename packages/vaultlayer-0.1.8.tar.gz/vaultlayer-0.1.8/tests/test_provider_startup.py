"""Tests for provider deployment registry and prepare_startup().

Verifies:
  - Every Provider enum member has a registry entry
  - Lambda produces plain text (NOT base64) — regression test for the bug
  - RunPod produces /pre_start.sh + exec /start.sh — regression test for the bug
  - AWS/Azure/Nebius produce base64
  - Container providers use container builder, VM providers use VM builder
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import base64
import inspect
import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from shared.models import Provider
from agents.broker.provider_startup import (
    PROVIDER_DEPLOY_REGISTRY,
    DeploymentType,
    ScriptEncoding,
    ProviderDeployConfig,
    StartupPayload,
    encode_script,
    build_runpod_docker_args,
)


class TestRegistry:
    def test_every_provider_has_entry(self):
        """Every Provider enum member must have a registry entry."""
        for provider in Provider:
            assert provider in PROVIDER_DEPLOY_REGISTRY, (
                f"Provider {provider.value} missing from PROVIDER_DEPLOY_REGISTRY"
            )

    def test_no_extra_entries(self):
        """Registry should not have entries for non-existent providers."""
        for key in PROVIDER_DEPLOY_REGISTRY:
            assert isinstance(key, Provider), f"Non-Provider key in registry: {key}"

    def test_runpod_is_container(self):
        cfg = PROVIDER_DEPLOY_REGISTRY[Provider.RUNPOD]
        assert cfg.deployment_type == DeploymentType.CONTAINER

    def test_vastai_is_container(self):
        cfg = PROVIDER_DEPLOY_REGISTRY[Provider.VAST_AI]
        assert cfg.deployment_type == DeploymentType.CONTAINER

    def test_lambda_is_vm(self):
        cfg = PROVIDER_DEPLOY_REGISTRY[Provider.LAMBDA_LABS]
        assert cfg.deployment_type == DeploymentType.VM

    def test_lambda_is_plain(self):
        """Lambda must use PLAIN encoding — NOT base64. Regression test for billing bug."""
        cfg = PROVIDER_DEPLOY_REGISTRY[Provider.LAMBDA_LABS]
        assert cfg.encoding == ScriptEncoding.PLAIN, (
            "Lambda user_data must be plain text — base64 causes cloud-init to silently ignore it"
        )

    def test_runpod_uses_pre_start(self):
        cfg = PROVIDER_DEPLOY_REGISTRY[Provider.RUNPOD]
        assert cfg.encoding == ScriptEncoding.RUNPOD_PRE_START

    def test_aws_is_base64(self):
        cfg = PROVIDER_DEPLOY_REGISTRY[Provider.AWS]
        assert cfg.encoding == ScriptEncoding.BASE64

    def test_gcp_is_plain(self):
        cfg = PROVIDER_DEPLOY_REGISTRY[Provider.GCP]
        assert cfg.encoding == ScriptEncoding.PLAIN


class TestEncoding:
    def test_plain_returns_unchanged(self):
        assert encode_script("#!/bin/bash\necho hi", ScriptEncoding.PLAIN) == "#!/bin/bash\necho hi"

    def test_base64_encodes(self):
        result = encode_script("#!/bin/bash\necho hi", ScriptEncoding.BASE64)
        decoded = base64.b64decode(result).decode()
        assert decoded == "#!/bin/bash\necho hi"

    def test_runpod_pre_start_is_base64(self):
        result = encode_script("#!/bin/bash\necho hi", ScriptEncoding.RUNPOD_PRE_START)
        decoded = base64.b64decode(result).decode()
        assert decoded == "#!/bin/bash\necho hi"


class TestRunPodDockerArgs:
    def test_writes_pre_start_sh(self):
        args = build_runpod_docker_args()
        assert "/pre_start.sh" in args, "Must write to /pre_start.sh"

    def test_execs_start_sh(self):
        args = build_runpod_docker_args()
        assert "exec /start.sh" in args, "Must exec /start.sh to preserve RunPod's init"

    def test_chmods_script(self):
        args = build_runpod_docker_args()
        assert "chmod +x" in args, "Must make /pre_start.sh executable"

    def test_does_not_replace_cmd_directly(self):
        """dockerArgs must NOT run the bootstrap directly — it must go through start.sh."""
        args = build_runpod_docker_args()
        assert "bash /tmp/vl_onstart.sh" not in args, (
            "Must NOT run onstart directly — bypasses start.sh"
        )


class TestPrepareStartup:
    def _make_broker(self):
        from agents.broker.agent import BrokerAgent
        b = BrokerAgent.__new__(BrokerAgent)
        b.config = MagicMock()
        b.config.cloudflare = None
        b._r2_minter = None
        from shared.gpu_resolver import GPUResolver
        b.gpu_resolver = GPUResolver()
        return b

    def test_lambda_returns_plain_text(self):
        """Lambda prepare_startup must return plain text starting with #!/bin/bash."""
        broker = self._make_broker()
        from shared.models import Job, GPUType, JobStatus
        job = Job(
            job_id="test-lambda", name="test",
            provider=Provider.LAMBDA_LABS, gpu_type=GPUType.H100_80GB_SXM,
            command="echo test",
        )
        payload = broker.prepare_startup(Provider.LAMBDA_LABS, job)
        assert payload.script.startswith("#!/bin/bash"), (
            f"Lambda script must be plain text, got: {payload.script[:50]}"
        )
        assert payload.encoding == ScriptEncoding.PLAIN

    def test_runpod_returns_docker_args(self):
        """RunPod prepare_startup must include runpod_docker_args and runpod_env."""
        broker = self._make_broker()
        from shared.models import Job, GPUType, JobStatus
        job = Job(
            job_id="test-runpod", name="test",
            provider=Provider.RUNPOD, gpu_type=GPUType.H100_80GB_SXM,
            command="echo test",
        )
        payload = broker.prepare_startup(Provider.RUNPOD, job)
        assert payload.runpod_docker_args is not None
        assert "/pre_start.sh" in payload.runpod_docker_args
        assert payload.runpod_env is not None
        assert "VL_ONSTART_B64" in payload.runpod_env

    def test_vastai_returns_plain_text(self):
        """Vast.ai prepare_startup must return plain text onstart script."""
        broker = self._make_broker()
        from shared.models import Job, GPUType, JobStatus
        job = Job(
            job_id="test-vast", name="test",
            provider=Provider.VAST_AI, gpu_type=GPUType.H100_80GB_SXM,
            command="echo test",
        )
        payload = broker.prepare_startup(Provider.VAST_AI, job)
        assert payload.script.startswith("#!/bin/bash")
        assert payload.encoding == ScriptEncoding.PLAIN

    def test_aws_returns_base64(self):
        """AWS prepare_startup must return base64-encoded script."""
        broker = self._make_broker()
        from shared.models import Job, GPUType, JobStatus
        job = Job(
            job_id="test-aws", name="test",
            provider=Provider.AWS, gpu_type=GPUType.H100_80GB_SXM,
            command="echo test",
        )
        payload = broker.prepare_startup(Provider.AWS, job)
        assert payload.encoding == ScriptEncoding.BASE64
        # Should be valid base64
        decoded = base64.b64decode(payload.script).decode()
        assert decoded.startswith("#!/bin/bash")

    def test_runpod_env_excludes_vl_script_b64(self):
        """RunPod env must not contain VL_SCRIPT_B64 (it's embedded in onstart)."""
        broker = self._make_broker()
        from shared.models import Job, GPUType, JobStatus
        job = Job(
            job_id="test-runpod-env", name="test",
            provider=Provider.RUNPOD, gpu_type=GPUType.H100_80GB_SXM,
            command="echo test",
            environment={"VL_SCRIPT_B64": "huge_base64_blob", "OTHER": "keep"},
        )
        payload = broker.prepare_startup(Provider.RUNPOD, job)
        assert "VL_SCRIPT_B64" not in payload.runpod_env
        assert "OTHER" in payload.runpod_env


class TestProvisionMethodsUseRegistry:
    """Verify that the 3 active provision modules go through prepare_startup."""

    def test_provision_lambda_uses_prepare_startup(self):
        from agents.broker.providers import lambda_labs
        source = inspect.getsource(lambda_labs.provision)
        assert "prepare_startup" in source, "lambda_labs.provision must call prepare_startup"

    def test_provision_runpod_uses_prepare_startup(self):
        from agents.broker.providers import runpod
        source = inspect.getsource(runpod.provision)
        assert "prepare_startup" in source, "runpod.provision must call prepare_startup"
        assert "runpod_env" in source, "Must use payload.runpod_env"

    def test_provision_vast_uses_prepare_startup(self):
        from agents.broker.providers import vast_ai
        source = inspect.getsource(vast_ai.provision)
        assert "prepare_startup" in source, "vast_ai.provision must call prepare_startup"
