"""Pins the three-state provider-allowlist behavior:
   - included    → all users can route
   - testing     → only users in VL_TEST_USER_IDS can route; never in
                   regular users' failover pool
   - pending     → blocked for everyone
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import pytest


# ── Fixtures ──────────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def _clear_data_loader_cache():
    """Make sure each test starts with a fresh data_loader cache so the
    config edits we patched-in are picked up."""
    from shared import data_loader
    if hasattr(data_loader, "_cached_data"):
        data_loader._cached_data = None
    if hasattr(data_loader, "_load"):
        # Bust any LRU-cache attached to _load
        if hasattr(data_loader._load, "cache_clear"):
            data_loader._load.cache_clear()
    yield


@pytest.fixture
def fake_three_state_config(monkeypatch):
    """Patch _load() to return a minimal config with all three lists populated."""
    from shared import data_loader
    fake = {
        "included_providers": {
            "providers": ["Vast.ai", "RunPod", "Lambda Labs"],
            "testing": ["AWS Spot", "AWS"],
            "pending": ["GCP", "CoreWeave"],
        }
    }
    monkeypatch.setattr(data_loader, "_load", lambda: fake)
    return fake


# ── data_loader getters ───────────────────────────────────────────────────

class TestDataLoaderGetters:
    def test_included_providers_returned(self, fake_three_state_config):
        from shared.data_loader import get_included_providers
        assert get_included_providers() == ["Vast.ai", "RunPod", "Lambda Labs"]

    def test_testing_providers_returned(self, fake_three_state_config):
        from shared.data_loader import get_testing_providers
        assert get_testing_providers() == ["AWS Spot", "AWS"]

    def test_pending_providers_returned(self, fake_three_state_config):
        from shared.data_loader import get_pending_providers
        assert get_pending_providers() == ["GCP", "CoreWeave"]

    def test_testing_empty_when_key_missing(self, monkeypatch):
        """Back-compat: configs without the testing key still work."""
        from shared import data_loader
        monkeypatch.setattr(data_loader, "_load", lambda: {
            "included_providers": {"providers": ["X"], "pending": ["Y"]}
        })
        from shared.data_loader import get_testing_providers
        assert get_testing_providers() == []


# ── VL_TEST_USER_IDS env-var allowlist ────────────────────────────────────

class TestUserCanUseTestingProviders:
    def test_unset_env_no_one_allowed(self, monkeypatch):
        monkeypatch.delenv("VL_TEST_USER_IDS", raising=False)
        from shared.data_loader import user_can_use_testing_providers
        assert user_can_use_testing_providers("anyone") is False

    def test_empty_env_no_one_allowed(self, monkeypatch):
        monkeypatch.setenv("VL_TEST_USER_IDS", "")
        from shared.data_loader import user_can_use_testing_providers
        assert user_can_use_testing_providers("anyone") is False

    def test_single_user_allowed(self, monkeypatch):
        monkeypatch.setenv("VL_TEST_USER_IDS", "tester-vaulttester")
        from shared.data_loader import user_can_use_testing_providers
        assert user_can_use_testing_providers("tester-vaulttester") is True
        assert user_can_use_testing_providers("regular-user") is False

    def test_multiple_users_csv(self, monkeypatch):
        monkeypatch.setenv("VL_TEST_USER_IDS", "alice, bob ,charlie")
        from shared.data_loader import user_can_use_testing_providers
        assert user_can_use_testing_providers("alice") is True
        assert user_can_use_testing_providers("bob") is True
        assert user_can_use_testing_providers("charlie") is True
        assert user_can_use_testing_providers("dave") is False

    def test_empty_user_id_never_allowed(self, monkeypatch):
        """An empty user_id must NEVER be allowed even if the allowlist
        is empty (defensive: don't let unauthenticated callers slip through)."""
        monkeypatch.setenv("VL_TEST_USER_IDS", "")
        from shared.data_loader import user_can_use_testing_providers
        assert user_can_use_testing_providers("") is False

    def test_empty_user_id_never_allowed_even_in_list(self, monkeypatch):
        """Even if "" somehow ends up in the allowlist set, an empty user_id
        passed to the check must still return False."""
        monkeypatch.setenv("VL_TEST_USER_IDS", ",,,")
        from shared.data_loader import user_can_use_testing_providers
        assert user_can_use_testing_providers("") is False


# ── Worker-side failover candidate filter ─────────────────────────────────

class TestWorkerFailoverPool:
    """The dispatcher's candidate list should include `testing` providers
    ONLY for test users. This is the safety guarantee — production users'
    failover never picks up an in-development provider."""

    def test_filter_logic_regular_user(self, fake_three_state_config, monkeypatch):
        """Verify the union-builder used in job_worker._provision_to_running.

        We can't easily call the full function in a unit test (it requires
        broker, prices, async loop, etc.) — but the filter is a 3-line
        union and the contract is what matters. Test the contract directly."""
        monkeypatch.setenv("VL_TEST_USER_IDS", "tester-vaulttester")

        from shared.data_loader import (
            get_included_providers, get_testing_providers,
            user_can_use_testing_providers,
        )

        regular_user_pool = set(get_included_providers())
        if user_can_use_testing_providers("regular-bob"):
            regular_user_pool |= set(get_testing_providers())
        # AWS / AWS Spot must NOT be in regular user's pool
        assert "AWS" not in regular_user_pool
        assert "AWS Spot" not in regular_user_pool
        # Production providers must be there
        assert "Vast.ai" in regular_user_pool
        assert "Lambda Labs" in regular_user_pool

    def test_filter_logic_test_user(self, fake_three_state_config, monkeypatch):
        monkeypatch.setenv("VL_TEST_USER_IDS", "tester-vaulttester")

        from shared.data_loader import (
            get_included_providers, get_testing_providers,
            user_can_use_testing_providers,
        )

        test_user_pool = set(get_included_providers())
        if user_can_use_testing_providers("tester-vaulttester"):
            test_user_pool |= set(get_testing_providers())
        # Both production AND testing providers must be there
        assert "AWS Spot" in test_user_pool
        assert "AWS" in test_user_pool
        assert "Vast.ai" in test_user_pool

    def test_pending_providers_never_in_pool(self, fake_three_state_config,
                                             monkeypatch):
        """Pending providers MUST never appear in any user's pool, even
        for test users — those are blocked for everyone."""
        monkeypatch.setenv("VL_TEST_USER_IDS", "tester-vaulttester")

        from shared.data_loader import (
            get_included_providers, get_testing_providers,
            user_can_use_testing_providers,
        )

        test_user_pool = set(get_included_providers())
        if user_can_use_testing_providers("tester-vaulttester"):
            test_user_pool |= set(get_testing_providers())
        assert "GCP" not in test_user_pool
        assert "CoreWeave" not in test_user_pool


# ── API validator semantics ───────────────────────────────────────────────

class TestApiValidatorClassification:
    """Smoke-tests the four classification branches in job_routes.py
    by calling get_*_providers() the same way the validator does."""

    def test_unknown_provider_classified_as_unknown(self, fake_three_state_config):
        from shared.data_loader import (
            get_included_providers, get_testing_providers,
            get_pending_providers,
        )
        included = set(get_included_providers())
        testing = set(get_testing_providers())
        pending = set(get_pending_providers())

        unknown = "Made Up Provider"
        assert unknown not in included | testing | pending

    def test_pending_provider_blocks_for_test_user_too(
        self, fake_three_state_config, monkeypatch
    ):
        """Even a test user can't route to a pending provider."""
        monkeypatch.setenv("VL_TEST_USER_IDS", "tester-vaulttester")

        from shared.data_loader import (
            get_pending_providers, user_can_use_testing_providers,
        )
        # Mirror the validator's logic:
        pending = set(get_pending_providers())
        prefs = ["GCP"]
        is_test_user = user_can_use_testing_providers("tester-vaulttester")

        bad_pending = [n for n in prefs if n in pending]
        assert bad_pending == ["GCP"]
        # Even with is_test_user=True, pending blocks
        assert is_test_user is True  # confirms the gate is independent
