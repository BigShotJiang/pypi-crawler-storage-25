"""Tier-1 tests for issue #74 (P0) — per-leg state reset on migration.

The root cause of #74 was: when a failover job migrated from provider A
to provider B, only `_spend_id` and `_run_id` were cleared. Per-leg state
like `_provider_billed_usd` and `_termination_confirmed` leaked into the
new leg, so settle_instance on the new leg used the PRIOR leg's cost
basis to compute user_charged_usd.

Evidence: stress run 7b1e5737 — GCP leg ran 5069s @ $1.10/hr (should
have charged $2.17), was actually charged $0.0616 (Vast.ai leg's value).

These tests lock in that _reset_job_for_new_leg() clears every per-leg
field, so no matter which migration path triggers re-queue, the new leg
settles with its own numbers.
"""
from __future__ import annotations

from api.job_worker import _reset_job_for_new_leg


def _make_job_dict() -> dict:
    """Realistic post-settle job dict from a Vast.ai leg."""
    return {
        "job_id":                   "abc-1234",
        "user_id":                  "u-1",
        "gpu_type":                 "A10G",
        "script_b64":               "base64-stuff",
        "script_name":              "train.py",
        "docker_image":             "pytorch/pytorch:2.3",
        "failover":                 True,
        "preferred_providers":      [],
        "checkpoint_step":          500,
        "excluded_providers":       [],
        "regions":                  ["us-east-1"],
        # ── per-leg state that MUST be cleared ───────────────────────
        "_spend_id":                "spend-1-vast",
        "_run_id":                  "run-1-vast",
        "_provider_billed_usd":     0.044,         # <-- the bug culprit
        "_termination_confirmed":   True,
        "started_at":               1000,
        "completed_at":             2568,
        "duration":                 1568,
        "instance_id":              "35180402",
        "provider":                 "vast_ai",
        "price_per_hr":             0.09335,
        "actual_gpu_type":          "A100_40",
        "error":                    "stuck_requeue",
    }


def test_reset_clears_spend_and_run_ids():
    job = _make_job_dict()
    _reset_job_for_new_leg(job)
    assert job["_spend_id"] is None
    assert job["_run_id"] is None


def test_reset_clears_provider_billed_usd():
    """THE actual #74 bug — per-leg provider_billed_usd must not carry over."""
    job = _make_job_dict()
    _reset_job_for_new_leg(job)
    assert job["_provider_billed_usd"] is None, \
        "prior leg's provider_billed_usd must NOT leak into next leg"


def test_reset_clears_termination_confirmed():
    """Per-leg termination status is per-leg, not global."""
    job = _make_job_dict()
    _reset_job_for_new_leg(job)
    assert job["_termination_confirmed"] is False


def test_reset_clears_timing_and_instance():
    job = _make_job_dict()
    _reset_job_for_new_leg(job)
    for field in ("started_at", "completed_at", "duration",
                  "instance_id", "provider", "price_per_hr", "actual_gpu_type"):
        assert job[field] is None, f"{field} must be cleared for the next leg"


def test_reset_clears_error_from_prior_leg():
    """Old leg's error shouldn't be visible on the recovered leg."""
    job = _make_job_dict()
    _reset_job_for_new_leg(job)
    assert job["error"] is None


def test_reset_preserves_job_intent():
    """Fields describing the USER's job (not a specific leg) must survive."""
    job = _make_job_dict()
    _reset_job_for_new_leg(job)
    assert job["job_id"]              == "abc-1234"
    assert job["user_id"]             == "u-1"
    assert job["gpu_type"]            == "A10G"
    assert job["script_b64"]          == "base64-stuff"
    assert job["script_name"]         == "train.py"
    assert job["docker_image"]        == "pytorch/pytorch:2.3"
    assert job["failover"]            is True
    assert job["checkpoint_step"]     == 500
    assert job["regions"]             == ["us-east-1"]
    assert job["excluded_providers"]  == []


def test_reset_is_idempotent():
    """Calling twice shouldn't explode (e.g. if a retry path races)."""
    job = _make_job_dict()
    _reset_job_for_new_leg(job)
    _reset_job_for_new_leg(job)
    assert job["_spend_id"] is None
    assert job["_provider_billed_usd"] is None


def test_reset_handles_missing_keys_gracefully():
    """Minimal job dict with no per-leg state set yet — should still work."""
    job = {"job_id": "new-job", "failover": True}
    _reset_job_for_new_leg(job)  # must not raise
    assert job["_spend_id"] is None
    assert job["_provider_billed_usd"] is None
    assert job["job_id"] == "new-job"
    assert job["failover"] is True
