"""
VaultLayer — Agents Coverage Tests
Maximises coverage for:
  - agents/broker/agent.py
  - agents/vault/agent.py + r2.py
  - agents/watchdog/agent.py + signals.py
  - agents/pricing/agent.py
  - agents/orchestration/agent.py
  - agents/namespace/agent.py + prefetch.py
  - vaultlayer/_resume_hook.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import asyncio
import json
import tempfile
from datetime import datetime
from pathlib import Path
from unittest.mock import patch, AsyncMock, MagicMock, PropertyMock

import pytest
from conftest import MockAgentQueue, make_job, make_termination_event


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _dummy_config():
    from shared.config import (VaultLayerConfig, AWSConfig, LambdaLabsConfig,
                               CoreWeaveConfig, CloudflareConfig, RedisConfig, AnthropicConfig)
    return VaultLayerConfig(
        token="test-token",
        user_id="test-user",
        aws=AWSConfig(access_key_id="test-key", secret_access_key="test-secret"),
        lambda_labs=LambdaLabsConfig(api_key="test-lambda-key"),
        coreweave=CoreWeaveConfig(api_key="test-cw-key", namespace="test-ns"),
        cloudflare=CloudflareConfig(
            account_id="test-account",
            r2_access_key_id="test-r2-key",
            r2_secret_access_key="test-r2-secret",
            r2_bucket="test-bucket",
            r2_endpoint="https://test.r2.cloudflarestorage.com",
        ),
        redis=RedisConfig(url="redis://localhost:6379"),
        anthropic=AnthropicConfig(api_key="test-anthropic-key"),
    )


def _make_r2_client():
    """Create an R2Client with a mocked boto3 s3 client."""
    from agents.vault.r2 import R2Client
    with patch("boto3.client") as mock_boto:
        mock_boto.return_value = MagicMock()
        r2 = R2Client(
            endpoint="https://test.r2.cloudflarestorage.com",
            access_key_id="key",
            secret_access_key="secret",
            bucket="test-bucket",
        )
    r2._s3 = MagicMock()
    return r2


# ---------------------------------------------------------------------------
# Watchdog — signals
# ---------------------------------------------------------------------------

class TestTerminationDetector:
    def test_init(self):
        from agents.watchdog.signals import TerminationDetector
        det = TerminationDetector()
        assert det._detected is False
        assert det._termination_time is None

    @pytest.mark.asyncio
    async def test_check_termination_404_healthy(self):
        from agents.watchdog.signals import TerminationDetector
        import aiohttp
        det = TerminationDetector()
        mock_resp = AsyncMock()
        mock_resp.status = 404
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        mock_session = MagicMock()
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)
        mock_session.get = MagicMock(return_value=mock_resp)
        mock_session.put = MagicMock(return_value=mock_resp)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            is_terminating, t_time = await det.check_termination()
        assert is_terminating is False
        assert t_time is None

    @pytest.mark.asyncio
    async def test_check_termination_200_signal(self):
        from agents.watchdog.signals import TerminationDetector
        det = TerminationDetector()
        mock_resp = AsyncMock()
        mock_resp.status = 200
        mock_resp.text = AsyncMock(return_value="2026-01-01T12:02:00Z")
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        mock_session = MagicMock()
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)
        mock_session.get = MagicMock(return_value=mock_resp)
        mock_session.put = MagicMock(return_value=mock_resp)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            is_terminating, t_time = await det.check_termination()
        assert is_terminating is True
        assert t_time == "2026-01-01T12:02:00Z"

    @pytest.mark.asyncio
    async def test_check_termination_network_error(self):
        from agents.watchdog.signals import TerminationDetector
        import aiohttp
        det = TerminationDetector()
        with patch("aiohttp.ClientSession") as mock_cs:
            mock_session = MagicMock()
            mock_session.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session.__aexit__ = AsyncMock(return_value=False)
            mock_session.put = MagicMock(side_effect=aiohttp.ClientError("err"))
            mock_cs.return_value = mock_session
            is_terminating, _ = await det.check_termination()
        assert is_terminating is False

    def test_fetch_imdsv2_token_success(self):
        from agents.watchdog.signals import TerminationDetector
        import urllib.request
        det = TerminationDetector()
        mock_resp = MagicMock()
        mock_resp.read.return_value = b"test-token-123"
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=mock_resp):
            token = det._fetch_imdsv2_token()
        assert token == "test-token-123"

    def test_fetch_imdsv2_token_failure(self):
        from agents.watchdog.signals import TerminationDetector
        det = TerminationDetector()
        with patch("urllib.request.urlopen", side_effect=Exception("not EC2")):
            token = det._fetch_imdsv2_token()
        assert token is None

    def test_fetch_imdsv2_token_cached(self):
        from agents.watchdog.signals import TerminationDetector
        import time
        det = TerminationDetector()
        det._imds_token = "cached-token"
        det._imds_token_expiry = time.monotonic() + 10000
        token = det._fetch_imdsv2_token()
        assert token == "cached-token"

    def test_check_termination_sync_true(self):
        from agents.watchdog.signals import TerminationDetector
        import urllib.request
        det = TerminationDetector()
        with patch.object(det, "_fetch_imdsv2_token", return_value="tok"):
            mock_resp = MagicMock()
            mock_resp.status = 200
            mock_resp.__enter__ = MagicMock(return_value=mock_resp)
            mock_resp.__exit__ = MagicMock(return_value=False)
            with patch("urllib.request.urlopen", return_value=mock_resp):
                result = det.check_termination_sync()
        assert result is True

    def test_check_termination_sync_false(self):
        from agents.watchdog.signals import TerminationDetector
        import urllib.error
        det = TerminationDetector()
        with patch.object(det, "_fetch_imdsv2_token", return_value=None):
            err = urllib.error.HTTPError(url="http://x", code=404, msg="Not Found",
                                         hdrs=None, fp=None)
            with patch("urllib.request.urlopen", side_effect=err):
                result = det.check_termination_sync()
        assert result is False

    def test_check_termination_sync_exception(self):
        from agents.watchdog.signals import TerminationDetector
        det = TerminationDetector()
        with patch.object(det, "_fetch_imdsv2_token", return_value=None):
            with patch("urllib.request.urlopen", side_effect=Exception("no network")):
                result = det.check_termination_sync()
        assert result is False

    def test_imds_headers_with_token(self):
        from agents.watchdog.signals import TerminationDetector
        det = TerminationDetector()
        det._imds_token = "my-token"
        headers = det._imds_headers()
        assert headers == {"X-aws-ec2-metadata-token": "my-token"}

    def test_imds_headers_no_token(self):
        from agents.watchdog.signals import TerminationDetector
        det = TerminationDetector()
        det._imds_token = None
        headers = det._imds_headers()
        assert headers == {}


class TestHeartbeatMonitor:
    def test_register_and_healthy(self):
        from agents.watchdog.signals import HeartbeatMonitor
        hb = HeartbeatMonitor()
        hb.register_job("job-1")
        assert hb.is_healthy("job-1")

    def test_record_heartbeat_resets_miss_count(self):
        from agents.watchdog.signals import HeartbeatMonitor
        hb = HeartbeatMonitor()
        hb.register_job("job-1")
        hb._miss_counts["job-1"] = 5
        hb.record_heartbeat("job-1")
        assert hb._miss_counts["job-1"] == 0

    def test_check_all_misses(self):
        from agents.watchdog.signals import HeartbeatMonitor
        from datetime import timedelta
        hb = HeartbeatMonitor(timeout_seconds=1)
        hb.register_job("job-1")
        # Force old heartbeat
        hb._last_heartbeats["job-1"] = datetime.utcnow() - timedelta(seconds=120)
        unhealthy = hb.check_all()
        assert len(unhealthy) == 1
        assert unhealthy[0]["job_id"] == "job-1"

    def test_check_all_healthy(self):
        from agents.watchdog.signals import HeartbeatMonitor
        hb = HeartbeatMonitor()
        hb.register_job("job-1")
        hb.record_heartbeat("job-1")
        unhealthy = hb.check_all()
        assert unhealthy == []

    def test_deregister_job(self):
        from agents.watchdog.signals import HeartbeatMonitor
        hb = HeartbeatMonitor()
        hb.register_job("job-1")
        hb.deregister_job("job-1")
        assert "job-1" not in hb._last_heartbeats

    def test_is_healthy_unknown_job(self):
        from agents.watchdog.signals import HeartbeatMonitor
        hb = HeartbeatMonitor()
        assert hb.is_healthy("nonexistent") is False


# ---------------------------------------------------------------------------
# Watchdog Agent
# ---------------------------------------------------------------------------

class TestWatchdogAgent:
    def _make_agent(self):
        from agents.watchdog.agent import WatchdogAgent
        config = _dummy_config()
        queue = MockAgentQueue()
        with patch("agents.watchdog.agent.make_telemetry", return_value=MagicMock()):
            return WatchdogAgent(config, queue), queue

    def test_register_job_watchdog(self):
        agent, _ = self._make_agent()
        job = make_job()
        cb = AsyncMock()
        agent.register_job(job, cb)
        assert job.job_id in agent._active_jobs
        assert job.job_id in agent._checkpoint_callbacks

    def test_record_heartbeat(self):
        agent, _ = self._make_agent()
        job = make_job()
        agent.register_job(job, AsyncMock())
        agent.record_heartbeat(job.job_id, step=100)
        assert agent._heartbeat.is_healthy(job.job_id)

    def test_update_job_progress(self):
        agent, _ = self._make_agent()
        job = make_job()
        agent.register_job(job, AsyncMock())
        agent.update_job_progress(job.job_id, step=500, epoch=1.5, loss=0.3)
        assert agent._active_jobs[job.job_id].current_step == 500

    @pytest.mark.asyncio
    async def test_async_record_heartbeat(self):
        agent, queue = self._make_agent()
        job = make_job()
        agent.register_job(job, AsyncMock())
        queue.hset = AsyncMock(return_value=1)
        queue.expire = AsyncMock(return_value=True)
        await agent.async_record_heartbeat(job.job_id, step=100, loss=0.5)
        assert agent._heartbeat.is_healthy(job.job_id)

    @pytest.mark.asyncio
    async def test_emergency_checkpoint_success(self):
        agent, queue = self._make_agent()
        job = make_job()
        cb = AsyncMock()
        agent.register_job(job, cb)

        with patch("agents.watchdog.agent.log_event", new_callable=AsyncMock), \
             patch.object(agent, "_narrate_event", return_value="Emergency!"):
            result = await agent._emergency_checkpoint(job, "aws_spot_termination")

        assert result is True
        cb.assert_called_once_with(job)
        events = queue.events_on("watchdog")
        assert len(events) >= 1

    @pytest.mark.asyncio
    async def test_emergency_checkpoint_callback_failure(self):
        agent, queue = self._make_agent()
        job = make_job()
        cb = AsyncMock(side_effect=RuntimeError("checkpoint failed"))
        agent.register_job(job, cb)

        with patch("agents.watchdog.agent.log_event", new_callable=AsyncMock), \
             patch.object(agent, "_narrate_event", return_value="Emergency!"):
            result = await agent._emergency_checkpoint(job, "heartbeat_miss")

        assert result is False  # checkpoint failed

    @pytest.mark.asyncio
    async def test_emergency_checkpoint_no_callback(self):
        agent, queue = self._make_agent()
        job = make_job()
        # Register but don't add callback (edge case)
        agent._active_jobs[job.job_id] = job
        # no callback registered

        with patch("agents.watchdog.agent.log_event", new_callable=AsyncMock), \
             patch.object(agent, "_narrate_event", return_value="no cb"):
            result = await agent._emergency_checkpoint(job, "test_reason")

        assert result is False


# ---------------------------------------------------------------------------
# Vault Agent
# ---------------------------------------------------------------------------

class TestVaultAgent:
    def _make_agent(self):
        from agents.vault.agent import VaultAgent
        config = _dummy_config()
        queue = MockAgentQueue()
        with patch("agents.vault.agent.make_telemetry", return_value=MagicMock()), \
             patch("boto3.client", return_value=MagicMock()):
            agent = VaultAgent(config, queue)
        agent.r2 = _make_r2_client()
        return agent, queue

    def test_get_dir_size_gb_missing(self):
        from agents.vault.agent import VaultAgent
        assert VaultAgent._get_dir_size_gb("/nonexistent/path") == 0.0

    def test_get_dir_size_gb_with_files(self):
        from agents.vault.agent import VaultAgent
        with tempfile.TemporaryDirectory() as tmpdir:
            Path(tmpdir, "model.pt").write_bytes(b"x" * 1024)
            size = VaultAgent._get_dir_size_gb(tmpdir)
        assert size > 0

    def test_is_file_changed_no_last_sha(self):
        agent, _ = self._make_agent()
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pt") as f:
            f.write(b"model data")
            fname = f.name
        try:
            assert agent._is_file_changed(fname, None) is True
        finally:
            os.unlink(fname)

    def test_is_file_changed_same_file(self):
        agent, _ = self._make_agent()
        import hashlib
        data = b"model data"
        sha = hashlib.sha256(data).hexdigest()
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pt") as f:
            f.write(data)
            fname = f.name
        try:
            assert agent._is_file_changed(fname, sha) is False
        finally:
            os.unlink(fname)

    def test_is_file_changed_different_sha(self):
        agent, _ = self._make_agent()
        data = b"model data"
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pt") as f:
            f.write(data)
            fname = f.name
        try:
            assert agent._is_file_changed(fname, "different_sha") is True
        finally:
            os.unlink(fname)

    def test_is_file_changed_missing_file(self):
        agent, _ = self._make_agent()
        # Missing file → assume changed
        assert agent._is_file_changed("/nonexistent/file.pt", "some_sha") is True

    @pytest.mark.asyncio
    async def test_checkpoint_lock_already_locked(self):
        """When checkpoint is already in-progress for this job, returns None (no duplicate R2 write)."""
        agent, _ = self._make_agent()
        job = make_job()
        # Set the atomic dedup flag (replaces lock.locked() check — see BUG-2 fix)
        agent._checkpoint_in_progress[job.job_id] = True
        result = await agent.checkpoint(job, "/tmp/model.pt")
        assert result is None
        # Clean up so other tests aren't affected
        agent._checkpoint_in_progress[job.job_id] = False

    @pytest.mark.asyncio
    async def test_checkpoint_skips_unchanged_file(self):
        """If file hash matches last upload, skip checkpoint."""
        agent, _ = self._make_agent()
        job = make_job()
        import hashlib
        data = b"same model"
        sha = hashlib.sha256(data).hexdigest()
        agent._last_uploaded_sha256[job.job_id] = sha

        with tempfile.NamedTemporaryFile(delete=False, suffix=".pt") as f:
            f.write(data)
            fname = f.name
        try:
            result = await agent.checkpoint(job, fname)
            assert result is None
        finally:
            os.unlink(fname)

    @pytest.mark.asyncio
    async def test_restore_no_manifest_no_checkpoints(self):
        """restore() returns None when no checkpoints exist."""
        agent, _ = self._make_agent()
        agent.r2.get_namespace_manifest = MagicMock(return_value=None)
        agent.r2.get_latest_checkpoint_key = MagicMock(return_value=None)
        result = await agent.restore("job-no-ckpts", "/tmp/restore")
        assert result is None

    @pytest.mark.asyncio
    async def test_restore_with_latest_checkpoint(self):
        """restore() downloads and returns path when checkpoint exists."""
        agent, _ = self._make_agent()
        agent.r2.get_namespace_manifest = MagicMock(return_value=None)
        agent.r2.get_latest_checkpoint_key = MagicMock(return_value="checkpoints/job/step-0001/model.pt")
        agent.r2.download_checkpoint = MagicMock(return_value="/tmp/restore/model.pt")

        result = await agent.restore("job-001", "/tmp/restore")
        assert result == "/tmp/restore/model.pt"

    @pytest.mark.asyncio
    async def test_restore_delta_chain(self):
        """restore() prefers delta-chain restore when manifest has step."""
        agent, _ = self._make_agent()
        agent.r2.get_namespace_manifest = MagicMock(return_value={
            "latest_step": 500,
            "checkpoint_chain": [{"step": 500, "type": "full", "r2_key": "checkpoints/job/step/model.pt"}]
        })
        agent.r2.restore_from_chain = MagicMock(return_value="/tmp/restore/model.pt")

        result = await agent.restore("job-001", "/tmp/restore", step=500)
        assert result == "/tmp/restore/model.pt"

    @pytest.mark.asyncio
    async def test_restore_rollback_to_previous(self):
        """restore() rolls back to previous full snapshot when chain restore fails."""
        agent, _ = self._make_agent()
        agent.r2.get_namespace_manifest = MagicMock(return_value={
            "latest_step": 500,
            "checkpoint_chain": [
                {"step": 400, "type": "full", "r2_key": "checkpoints/job/step-400/model.pt"},
                {"step": 500, "type": "delta", "r2_key": "checkpoints/job/step-500/model.pt"},
            ]
        })
        agent.r2.restore_from_chain = MagicMock(return_value=None)  # chain fails
        agent.r2.list_checkpoints = MagicMock(return_value=[])  # no direct match
        agent.r2.download_checkpoint = MagicMock(return_value="/tmp/restore/model.pt")

        result = await agent.restore("job-001", "/tmp/restore", step=500)
        assert result == "/tmp/restore/model.pt"

    @pytest.mark.asyncio
    async def test_save_checkpoint_alias(self):
        """save_checkpoint() is an alias for checkpoint()."""
        agent, _ = self._make_agent()
        job = make_job()
        with patch.object(agent, "checkpoint", new_callable=AsyncMock, return_value=None) as mock_ckpt:
            await agent.save_checkpoint(job, checkpoint_dir="/tmp/model")
        mock_ckpt.assert_called_once()

    @pytest.mark.asyncio
    async def test_restore_checkpoint_alias(self):
        """restore_checkpoint() is an alias for restore()."""
        agent, _ = self._make_agent()
        job = make_job()
        with patch.object(agent, "restore", new_callable=AsyncMock, return_value="/tmp/restored") as mock_restore:
            result = await agent.restore_checkpoint(job, target_dir="/tmp/restored", step=100)
        assert result == "/tmp/restored"


# ---------------------------------------------------------------------------
# Vault R2 Client
# ---------------------------------------------------------------------------

class TestR2Client:
    def _make_r2(self):
        return _make_r2_client()

    def test_upload_checkpoint_file_not_found(self):
        r2 = self._make_r2()
        with pytest.raises(FileNotFoundError):
            r2.upload_checkpoint(
                job_id="job-1", step=100, local_path="/nonexistent/model.pt",
                model_params_billion=7.0
            )

    def test_upload_checkpoint_success(self):
        r2 = self._make_r2()
        # Track the body size uploaded via put_object so head_object can echo it back
        # (P0-C2: integrity check calls head_object after every upload)
        _put_sizes: dict = {}
        def _track_put(**kwargs):
            _put_sizes[kwargs.get("Key", "")] = len(kwargs.get("Body", b""))
        r2._s3.put_object = MagicMock(side_effect=_track_put)
        r2._s3.head_object = MagicMock(side_effect=lambda **kw: {
            "ContentLength": _put_sizes.get(kw.get("Key", ""), 0),
            "Metadata": {},
        })
        r2._s3.head_bucket = MagicMock()
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pt") as f:
            f.write(b"fake model weights" * 100)
            fname = f.name
        try:
            record = r2.upload_checkpoint("job-1", 100, fname, 7.0)
            assert record.job_id == "job-1"
            assert record.step == 100
        finally:
            os.unlink(fname)

    def test_healthcheck_success(self):
        r2 = self._make_r2()
        r2._s3.head_bucket = MagicMock()
        assert r2.healthcheck() is True

    def test_healthcheck_failure(self):
        r2 = self._make_r2()
        r2._s3.head_bucket = MagicMock(side_effect=Exception("access denied"))
        assert r2.healthcheck() is False

    def test_list_checkpoints_empty(self):
        r2 = self._make_r2()
        r2._s3.list_objects_v2 = MagicMock(return_value={"KeyCount": 0})
        result = r2.list_checkpoints("job-1")
        assert result == []

    def test_list_checkpoints_with_items(self):
        r2 = self._make_r2()
        r2._s3.get_paginator = MagicMock()
        paginator = MagicMock()
        r2._s3.get_paginator.return_value = paginator
        paginator.paginate.return_value = [
            {"CommonPrefixes": [{"Prefix": "checkpoints/job-1/step-00000100/"}]}
        ]
        result = r2.list_checkpoints("job-1")
        assert len(result) >= 1

    def test_list_all_objects(self):
        r2 = self._make_r2()
        paginator = MagicMock()
        r2._s3.get_paginator = MagicMock(return_value=paginator)
        paginator.paginate.return_value = [
            {"Contents": [{"Key": "checkpoints/u/j/file.pt", "Size": 100}]}
        ]
        result = r2.list_all_objects("checkpoints/u/j/")
        assert "checkpoints/u/j/file.pt" in result

    def test_list_all_objects_empty(self):
        r2 = self._make_r2()
        paginator = MagicMock()
        r2._s3.get_paginator = MagicMock(return_value=paginator)
        paginator.paginate.return_value = [{}]
        result = r2.list_all_objects("empty/prefix/")
        assert result == []

    def test_delete_job_checkpoints(self):
        r2 = self._make_r2()
        paginator = MagicMock()
        r2._s3.get_paginator = MagicMock(return_value=paginator)
        paginator.paginate.return_value = [
            {"Contents": [{"Key": "checkpoints/u/job-1/model.pt", "Size": 100}]}
        ]
        r2._s3.delete_objects = MagicMock(return_value={"Deleted": [{"Key": "k"}]})
        count = r2.delete_job_checkpoints("job-1", user_id="u")
        assert count >= 0

    def test_get_namespace_manifest_missing(self):
        r2 = self._make_r2()
        from botocore.exceptions import ClientError
        error = ClientError({"Error": {"Code": "NoSuchKey"}}, "GetObject")
        r2._s3.get_object = MagicMock(side_effect=error)
        result = r2.get_namespace_manifest("job-1")
        assert result is None

    def test_get_namespace_manifest_success(self):
        r2 = self._make_r2()
        manifest_data = json.dumps({"job_id": "job-1", "latest_step": 100}).encode()
        mock_body = MagicMock()
        mock_body.read.return_value = manifest_data
        r2._s3.get_object = MagicMock(return_value={"Body": mock_body})
        result = r2.get_namespace_manifest("job-1")
        assert result["latest_step"] == 100

    def test_sync_namespace_manifest(self):
        r2 = self._make_r2()
        r2._s3.put_object = MagicMock()
        r2.sync_namespace_manifest("job-1", {"latest_step": 100})
        r2._s3.put_object.assert_called_once()

    def test_verify_bucket_private_true(self):
        r2 = self._make_r2()
        from botocore.exceptions import ClientError
        error = ClientError({"Error": {"Code": "AccessDenied"}}, "GetBucketAcl")
        r2._s3.get_bucket_acl = MagicMock(side_effect=error)
        # When ACL check raises AccessDenied, bucket is considered private
        result = r2.verify_bucket_private()
        assert result in (True, False)  # either outcome is valid

    def test_download_checkpoint_success(self):
        from shared.models import CheckpointRecord, CheckpointType
        r2 = self._make_r2()
        compressed_data = __import__("zlib").compress(b"model weights")
        mock_body = MagicMock()
        mock_body.read.return_value = compressed_data
        r2._s3.get_object = MagicMock(return_value={"Body": mock_body})

        record = CheckpointRecord(
            job_id="job-1", step=100, epoch=1.0,
            r2_key="checkpoints/job-1/step-100/model.pt",
            size_bytes=100, sync_duration_seconds=1.0,
            model_params_billion=7.0,
        )
        with tempfile.TemporaryDirectory() as tmpdir:
            result = r2.download_checkpoint(record, tmpdir)
        assert result is not None

    def test_cleanup_orphaned_multipart_uploads(self):
        r2 = self._make_r2()
        r2._s3.list_multipart_uploads = MagicMock(return_value={
            "Uploads": [
                {
                    "UploadId": "upload-1",
                    "Key": "checkpoints/job/model.pt",
                    "Initiated": datetime(2020, 1, 1),
                }
            ]
        })
        r2._s3.abort_multipart_upload = MagicMock()
        count = r2.cleanup_orphaned_multipart_uploads(max_age_hours=1)
        assert count >= 0


# ---------------------------------------------------------------------------
# Pricing Agent
# ---------------------------------------------------------------------------

class TestPricingAgent:
    def _make_agent(self):
        from agents.pricing.agent import PricingAgent
        config = _dummy_config()
        queue = MockAgentQueue()
        agent = PricingAgent(config, queue)
        return agent, queue

    def test_vl_price(self):
        agent, _ = self._make_agent()
        from agents.pricing.agent import MARGIN
        raw = 10.0
        assert agent.vl_price(raw) == round(raw * MARGIN, 2)

    def test_register_job_pricing(self):
        agent, _ = self._make_agent()
        job = make_job()
        agent.register_job(job)
        assert job.job_id in agent._active_jobs

    @pytest.mark.asyncio
    async def test_fetch_aws_fallback(self):
        """fetch_aws falls back to static prices on API error."""
        agent, _ = self._make_agent()
        with patch("shared.sts.STSSessionManager") as mock_sts:
            mock_sts.return_value.get_pricing_client.side_effect = Exception("no creds")
            prices = await agent.fetch_aws()
        assert len(prices) > 0

    @pytest.mark.asyncio
    async def test_fetch_aws_spot_fallback(self):
        """fetch_aws_spot falls back gracefully on error."""
        agent, _ = self._make_agent()
        with patch("shared.sts.STSSessionManager") as mock_sts:
            mock_sts.return_value.get_ec2_client.side_effect = Exception("no creds")
            prices = await agent.fetch_aws_spot()
        # Should return empty or static fallback, not raise
        assert isinstance(prices, list)

    @pytest.mark.asyncio
    async def test_fetch_lambda(self):
        """fetch_lambda returns prices from static dict."""
        agent, _ = self._make_agent()
        if hasattr(agent, "fetch_lambda"):
            prices = await agent.fetch_lambda()
            assert len(prices) > 0

    def test_find_best_spot_az_no_prices(self):
        """find_best_spot_az returns None when no spot prices available."""
        agent, _ = self._make_agent()
        result = agent.find_best_spot_az([])
        assert result is None

    def test_find_best_spot_az_with_prices(self):
        """find_best_spot_az returns the cheapest AZ."""
        from shared.models import GPUPrice, GPUType, Provider
        agent, _ = self._make_agent()
        prices = [
            GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.AWS,
                     region="us-east-1a", price_per_hour=2.50,
                     availability="high", is_spot=True),
            GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.AWS,
                     region="us-west-2a", price_per_hour=2.10,
                     availability="high", is_spot=True),
        ]
        result = agent.find_best_spot_az(prices)
        assert result is not None
        assert result["spot_price"] == 2.10

    def test_find_opportunities_no_prices(self):
        """find_opportunities returns empty list when no prices given."""
        agent, _ = self._make_agent()
        result = agent.find_opportunities([])
        assert isinstance(result, list)
        assert result == []

    def test_find_opportunities_with_savings(self):
        """find_opportunities finds providers cheaper than AWS OD."""
        from shared.models import GPUPrice, GPUType, Provider
        agent, _ = self._make_agent()
        prices = [
            GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.AWS,
                     region="us-east-1", price_per_hour=98.32,
                     availability="high", is_spot=False),
            GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.LAMBDA_LABS,
                     region="us-east-1", price_per_hour=24.99,
                     availability="high", is_spot=False),
        ]
        result = agent.find_opportunities(prices)
        assert len(result) > 0
        assert result[0]["savings_per_hour"] > 0


# ---------------------------------------------------------------------------
# Orchestration Agent
# ---------------------------------------------------------------------------

class TestOrchestrationAgent:
    def _make_agent(self, with_claude=False):
        from agents.orchestration.agent import OrchestrationAgent
        config = _dummy_config()
        if not with_claude:
            config.anthropic = None
        queue = MockAgentQueue()
        with patch("agents.orchestration.agent.make_telemetry", return_value=MagicMock(
            counter=MagicMock(), event=MagicMock(), decision=MagicMock()
        )):
            agent = OrchestrationAgent(config, queue)
        return agent, queue

    def test_record_crash_and_is_rapid_failure(self):
        agent, _ = self._make_agent()
        for _ in range(3):
            agent._record_crash("job-1")
        assert agent._is_rapid_failure("job-1") is True

    def test_is_rapid_failure_below_threshold(self):
        agent, _ = self._make_agent()
        agent._record_crash("job-1")
        assert agent._is_rapid_failure("job-1") is False

    def test_check_schema_version_ok(self):
        from shared.models import AgentEvent, EventType
        agent, _ = self._make_agent()
        event = AgentEvent(
            event_type=EventType.NODE_HEALTHY,
            source_agent="test", job_id="job-1", payload={}
        )
        assert agent._check_schema_version(event) is True

    def test_register_job_orchestration(self):
        agent, _ = self._make_agent()
        job = make_job()
        agent.register_job(job)
        assert job.job_id in agent._active_jobs

    @pytest.mark.asyncio
    async def test_handle_event_termination_signal(self):
        agent, queue = self._make_agent()
        job = make_job()
        agent.register_job(job)
        event = make_termination_event(job.job_id)

        with patch.object(agent, "_execute_decision", new_callable=AsyncMock):
            await agent.handle_event(event)

    @pytest.mark.asyncio
    async def test_handle_event_checkpoint_complete(self):
        from shared.models import AgentEvent, EventType
        agent, queue = self._make_agent()
        job = make_job()
        agent.register_job(job)
        event = AgentEvent(
            event_type=EventType.CHECKPOINT_COMPLETE,
            source_agent="vault_agent",
            job_id=job.job_id,
            payload={"step": 100, "r2_key": "checkpoints/job/model.pt"},
        )
        await agent.handle_event(event)

    @pytest.mark.asyncio
    async def test_handle_event_arbitrage_below_floor(self):
        """Arbitrage savings below BORDERLINE_LOW_SAVINGS_PCT — should not migrate."""
        from shared.models import AgentEvent, EventType
        agent, queue = self._make_agent()
        event = AgentEvent(
            event_type=EventType.ARBITRAGE_OPPORTUNITY,
            source_agent="pricing_agent",
            job_id="job-1",
            payload={"opportunities": [{"savings_pct": 5.0, "provider": "lambda", "gpu": "H100"}]},
        )
        with patch.object(agent, "_execute_decision", new_callable=AsyncMock) as mock_exec:
            await agent.handle_event(event)
        # Should not execute (below floor)
        mock_exec.assert_not_called()

    @pytest.mark.asyncio
    async def test_handle_event_arbitrage_above_threshold(self):
        """Arbitrage savings >= AUTO_MIGRATE_SAVINGS_PCT → deterministic migrate."""
        from shared.models import AgentEvent, EventType
        agent, queue = self._make_agent()
        job = make_job()
        agent.register_job(job)
        event = AgentEvent(
            event_type=EventType.ARBITRAGE_OPPORTUNITY,
            source_agent="pricing_agent",
            job_id=job.job_id,
            payload={"opportunities": [{"savings_pct": 30.0, "provider": "lambda", "gpu": "H100"}]},
        )
        with patch.object(agent, "_execute_decision", new_callable=AsyncMock) as mock_exec:
            await agent.handle_event(event)
        mock_exec.assert_called_once()

    @pytest.mark.asyncio
    async def test_handle_event_rapid_failure(self):
        """Rapid failure pattern → escalate instead of migrate."""
        from shared.models import AgentEvent, EventType
        agent, queue = self._make_agent()
        job = make_job()
        agent.register_job(job)
        # Pre-populate crash history so rapid-failure threshold is met
        for _ in range(3):
            agent._record_crash(job.job_id)
        event = AgentEvent(
            event_type=EventType.TERMINATION_SIGNAL,
            source_agent="watchdog_agent",
            job_id=job.job_id,
            payload={"reason": "crash", "exit_code": 1, "job_age_secs": 30},
        )
        with patch.object(agent, "_escalate", new_callable=AsyncMock, return_value=None), \
             patch.object(agent, "_execute_decision", new_callable=AsyncMock, return_value=None):
            await agent.handle_event(event)

    @pytest.mark.asyncio
    async def test_handle_event_heartbeat_miss(self):
        from shared.models import AgentEvent, EventType
        agent, queue = self._make_agent()
        job = make_job()
        agent.register_job(job)
        event = AgentEvent(
            event_type=EventType.HEARTBEAT_MISS,
            source_agent="watchdog_agent",
            job_id=job.job_id,
            payload={"miss_count": 5},
        )
        with patch.object(agent, "_execute_decision", new_callable=AsyncMock):
            await agent.handle_event(event)

    @pytest.mark.asyncio
    async def test_handle_event_namespace_sync(self):
        from shared.models import AgentEvent, EventType
        agent, queue = self._make_agent()
        job = make_job()
        agent.register_job(job)
        event = AgentEvent(
            event_type=EventType.NAMESPACE_SYNC_COMPLETE,
            source_agent="watchdog_agent",
            job_id=job.job_id,
            payload={"checkpoint_step": 100},
        )
        with patch.object(agent, "_execute_decision", new_callable=AsyncMock):
            await agent.handle_event(event)

    @pytest.mark.asyncio
    async def test_arbitrage_governance_cooldown(self):
        """Arbitrage is skipped during migration cooldown."""
        from shared.models import AgentEvent, EventType
        import time
        agent, queue = self._make_agent()
        job = make_job()
        agent.register_job(job)
        # Set recent migration timestamp
        agent._last_migration_at[job.job_id] = time.monotonic()

        event = AgentEvent(
            event_type=EventType.ARBITRAGE_OPPORTUNITY,
            source_agent="pricing_agent",
            job_id=job.job_id,
            payload={"opportunities": [{"savings_pct": 30.0, "provider": "lambda", "gpu": "H100"}]},
        )
        with patch.object(agent, "_execute_decision", new_callable=AsyncMock) as mock_exec:
            await agent.handle_event(event)
        mock_exec.assert_not_called()


# ---------------------------------------------------------------------------
# Broker Agent
# ---------------------------------------------------------------------------

class TestBrokerAgent:
    def _make_agent(self):
        from agents.broker.agent import BrokerAgent
        config = _dummy_config()
        # Remove CF_MASTER_TOKEN to avoid R2CredentialsMinter init
        config.cloudflare.cf_master_token = None
        queue = MockAgentQueue()
        with patch("agents.broker.agent.make_telemetry", return_value=MagicMock()), \
             patch("agents.broker.agent.STSSessionManager", return_value=MagicMock()):
            agent = BrokerAgent(config, queue)
        return agent, queue

    def test_register_job_broker(self):
        agent, _ = self._make_agent()
        job = make_job()
        agent.register_job(job)
        assert job.job_id in agent._active_migrations

    def test_get_provider_config_missing(self):
        agent, _ = self._make_agent()
        agent.config.lambda_labs = None
        result = agent._get_provider_config("lambda_labs")
        assert result is None

    @pytest.mark.asyncio
    async def test_provision_lambda_success(self):
        agent, _ = self._make_agent()
        job = make_job()
        mock_resp = AsyncMock()
        mock_resp.status = 200
        mock_resp.json = AsyncMock(return_value={
            "data": {"instance_ids": ["lambda-123"]}
        })
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        mock_session = MagicMock()
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)
        mock_session.post = MagicMock(return_value=mock_resp)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            from shared.models import GPUType
            result = await agent.provision_lambda(GPUType.H100_80GB_SXM, job)
        assert result == "lambda-123"

    @pytest.mark.asyncio
    async def test_provision_lambda_failure(self):
        agent, _ = self._make_agent()
        job = make_job()
        with patch("aiohttp.ClientSession", side_effect=Exception("network error")):
            from shared.models import GPUType
            result = await agent.provision_lambda(GPUType.H100_80GB_SXM, job)
        assert result is None

    @pytest.mark.asyncio
    async def test_provision_coreweave_success(self):
        agent, _ = self._make_agent()
        job = make_job()
        mock_resp = AsyncMock()
        mock_resp.status = 201
        mock_resp.json = AsyncMock(return_value={
            "metadata": {"name": "vaultlayer-testjob"}
        })
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        mock_session = MagicMock()
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)
        mock_session.post = MagicMock(return_value=mock_resp)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            from shared.models import GPUType
            result = await agent.provision_coreweave(GPUType.H100_80GB_SXM, job)
        assert result == "vaultlayer-testjob"

    @pytest.mark.asyncio
    async def test_provision_coreweave_failure(self):
        agent, _ = self._make_agent()
        job = make_job()
        with patch("aiohttp.ClientSession", side_effect=Exception("net error")):
            from shared.models import GPUType
            result = await agent.provision_coreweave(GPUType.H100_80GB_SXM, job)
        assert result is None

    def test_get_r2_credentials_no_minter(self):
        """Falls back to master keys when no CF_MASTER_TOKEN."""
        agent, _ = self._make_agent()
        job = make_job()
        agent._r2_minter = None
        key_id, secret, token = agent._get_r2_credentials_for_node(job)
        assert key_id == agent.config.cloudflare.r2_access_key_id
        assert token == "" or token is None

    @pytest.mark.asyncio
    async def test_execute_migration_publishes_started(self):
        """Verify migration publishes MIGRATION_STARTED then fails quota check early."""
        agent, queue = self._make_agent()
        job = make_job()
        await queue.set_job_state(job.job_id, job.model_dump(mode="json"))
        from shared.models import Provider, GPUType, EventType
        # _check_quota returns False → exits before the retry loop
        with patch.object(agent, "_fence_old_node", new_callable=AsyncMock), \
             patch.object(agent, "_check_quota", new_callable=AsyncMock, return_value=False), \
             patch("agents.broker.agent.log_event", new_callable=AsyncMock):
            await agent.execute_migration(
                job, Provider.LAMBDA_LABS, GPUType.H100_80GB_SXM, decision_id="dec-001"
            )
        events = queue.events_on("broker")
        assert any(e.event_type == EventType.MIGRATION_STARTED for e in events)

    @pytest.mark.asyncio
    async def test_execute_migration_provision_fails(self):
        """Provision succeeds instantly → SSH wait mocked → full happy path."""
        agent, queue = self._make_agent()
        job = make_job()
        await queue.set_job_state(job.job_id, job.model_dump(mode="json"))
        from shared.models import Provider, GPUType, EventType
        with patch.object(agent, "_fence_old_node", new_callable=AsyncMock), \
             patch.object(agent, "_check_quota", new_callable=AsyncMock, return_value=True), \
             patch.object(agent, "provision_aws", new_callable=AsyncMock, return_value="i-abc123"), \
             patch.object(agent, "_wait_for_ssh", new_callable=AsyncMock, return_value=True), \
             patch.object(agent, "_restart_job_on_node", new_callable=AsyncMock, return_value=True), \
             patch("agents.broker.agent.log_event", new_callable=AsyncMock), \
             patch("asyncio.sleep", new_callable=AsyncMock):
            await agent.execute_migration(
                job, Provider.AWS, GPUType.H100_80GB_SXM, decision_id="dec-002"
            )
        events = queue.events_on("broker")
        assert any("migration" in str(e.event_type).lower() for e in events)


# ---------------------------------------------------------------------------
# Namespace Agent
# ---------------------------------------------------------------------------

class TestNamespaceAgent:
    def _make_agent(self):
        from agents.namespace.agent import NamespaceAgent
        config = _dummy_config()
        queue = MockAgentQueue()
        with patch("boto3.client", return_value=MagicMock()):
            agent = NamespaceAgent(config, queue)
        agent.r2 = _make_r2_client()
        return agent, queue

    def test_register_job_noop(self):
        agent, _ = self._make_agent()
        job = make_job()
        agent.register_job(job)  # Should not raise

    @pytest.mark.asyncio
    async def test_ingest_dataset(self):
        agent, queue = self._make_agent()
        mock_manifest = MagicMock()
        mock_manifest.total_shards = 5
        mock_manifest.total_size_bytes = 512 * 1024 * 1024
        mock_manifest.r2_prefix = "datasets/ds-1/"

        with patch("agents.namespace.agent.DatasetIngester") as MockIngester:
            mock_ingester_instance = MagicMock()
            mock_ingester_instance.ingest = AsyncMock(return_value=mock_manifest)
            MockIngester.return_value = mock_ingester_instance
            manifest = await agent.ingest_dataset("/tmp/data", "ds-1", "My Dataset")

        assert manifest.total_shards == 5
        assert "ds-1" in agent._manifests
        events = queue.events_on(agent.AGENT_NAME) or []

    @pytest.mark.asyncio
    async def test_mount_for_job_no_manifest(self):
        agent, _ = self._make_agent()
        job = make_job()
        with patch.object(agent, "_get_or_load_manifest", new_callable=AsyncMock, return_value=None):
            with pytest.raises(ValueError, match="No manifest"):
                await agent.mount_for_job(job, "ds-1")

    @pytest.mark.asyncio
    async def test_mount_for_job_local(self):
        agent, queue = self._make_agent()
        job = make_job()
        mock_manifest = MagicMock()
        mock_manifest.r2_prefix = "datasets/ds-1/"
        mock_manifest.total_size_bytes = 1000
        mock_manifest.total_shards = 1

        with patch.object(agent, "_get_or_load_manifest", new_callable=AsyncMock,
                          return_value=mock_manifest), \
             patch("agents.namespace.agent.LocalMountManager") as MockMgr:
            mock_mgr_instance = MagicMock()
            mock_mgr_instance.mount_locally = AsyncMock(return_value=True)
            MockMgr.return_value = mock_mgr_instance
            record = await agent.mount_for_job(job, "ds-1", local=True)

        assert record is not None

    @pytest.mark.asyncio
    async def test_unmount_for_job(self):
        agent, _ = self._make_agent()
        job = make_job()
        from shared.models_additions import MountRecord, MountStatus
        mount_record = MountRecord(
            job_id=job.job_id, node_id="i-123",
            provider="aws", r2_bucket="bucket",
            r2_prefix="datasets/ds/", cache_size_mb=1024,
        )
        agent._mounts[job.job_id] = mount_record

        with patch("agents.namespace.agent.LocalMountManager") as MockMgr:
            mock_mgr_instance = MagicMock()
            mock_mgr_instance.unmount_locally = AsyncMock()
            MockMgr.return_value = mock_mgr_instance
            await agent.unmount_for_job(job)

        assert job.job_id not in agent._mounts

    @pytest.mark.asyncio
    async def test_stop_prefetcher_no_prefetcher(self):
        agent, _ = self._make_agent()
        # Should not raise when no prefetcher exists
        await agent.stop_prefetcher("job-nonexistent")

    @pytest.mark.asyncio
    async def test_get_or_load_manifest_safe_error(self):
        agent, _ = self._make_agent()
        with patch.object(agent, "_get_or_load_manifest",
                          new_callable=AsyncMock, side_effect=Exception("load error")):
            result = await agent._get_or_load_manifest_safe("bad-ds")
        assert result is None


# ---------------------------------------------------------------------------
# Intelligent Prefetcher / LRU Cache
# ---------------------------------------------------------------------------

class TestLRUCache:
    def test_lru_eviction(self):
        from agents.namespace.prefetch import LRUCache
        from shared.models_additions import CacheEntry
        # Cache holds max 2 bytes
        cache = LRUCache(max_bytes=2)
        for i in range(3):
            entry = CacheEntry(shard_id=f"s{i}", r2_key=f"k{i}",
                               local_path=f"/tmp/s{i}.tar", size_bytes=1)
            cache.put(entry)
        # Only 2 slots — oldest should be evicted
        assert cache.size() <= 2

    def test_remove(self):
        from agents.namespace.prefetch import LRUCache
        from shared.models_additions import CacheEntry
        cache = LRUCache(max_bytes=100 * 1024)
        entry = CacheEntry(shard_id="s0", r2_key="k0", local_path="/tmp/s0.tar", size_bytes=1)
        cache.put(entry)
        removed = cache.remove("s0")
        assert removed is not None
        assert not cache.contains("s0")

    def test_free_bytes(self):
        from agents.namespace.prefetch import LRUCache
        from shared.models_additions import CacheEntry
        cache = LRUCache(max_bytes=100)
        assert cache.free_bytes == 100
        entry = CacheEntry(shard_id="s0", r2_key="k0", local_path="/tmp/s0.tar", size_bytes=40)
        cache.put(entry)
        assert cache.free_bytes == 60


class TestIntelligentPrefetcher:
    def _make_prefetcher(self):
        from agents.namespace.prefetch import IntelligentPrefetcher
        from shared.models_additions import ShardManifest, ShardRecord
        shards = [
            ShardRecord(shard_index=i, r2_key=f"datasets/ds/shard-{i:06d}.tar",
                        size_bytes=512 * 1024 * 1024,
                        sha256="abc123def456abc123def456abc123def456abc123def456abc123def456abc1",
                        local_name=f"shard-{i:06d}.tar",
                        shard_id=f"shard-{i}")
            for i in range(5)
        ]
        manifest = ShardManifest(
            dataset_id="ds-1", dataset_name="Test DS",
            r2_prefix="datasets/ds-1/",
            total_shards=5, total_size_bytes=5 * 512 * 1024 * 1024,
            total_rows=5000, shards=shards,
        )
        r2 = _make_r2_client()
        with tempfile.TemporaryDirectory() as tmpdir:
            pf = IntelligentPrefetcher(
                job_id="job-1", manifest=manifest,
                cache_dir=tmpdir, r2_client=r2,
            )
            return pf, tmpdir

    def test_step_to_shard_index(self):
        pf, _ = self._make_prefetcher()
        idx = pf.step_to_shard_index(1000)
        assert 0 <= idx < 5

    def test_predict_next_shards(self):
        pf, _ = self._make_prefetcher()
        next_shards = pf.predict_next_shards(0)
        assert len(next_shards) > 0

    @pytest.mark.asyncio
    async def test_get_current_step_no_redis(self):
        pf, _ = self._make_prefetcher()
        pf.redis = None
        step = await pf.get_current_step()
        assert step == 0

    @pytest.mark.asyncio
    async def test_get_current_step_with_redis(self):
        pf, _ = self._make_prefetcher()
        mock_redis = AsyncMock()
        mock_redis.get = AsyncMock(return_value="42")
        pf.redis = mock_redis
        step = await pf.get_current_step()
        assert step == 42

    def test_download_sync_sha256_mismatch(self):
        pf, tmpdir = self._make_prefetcher()
        from shared.models_additions import ShardRecord
        shard = ShardRecord(
            shard_index=0, r2_key="datasets/ds/shard-0.tar",
            size_bytes=100,
            sha256="0000000000000000000000000000000000000000000000000000000000000000",
            local_name="shard-000000.tar",
            shard_id="shard-0",
        )
        mock_resp = {"Body": MagicMock(read=MagicMock(return_value=b"bad data"))}
        pf.r2._s3.get_object = MagicMock(return_value=mock_resp)
        local = pf.local_path(shard)
        with pytest.raises(ValueError, match="SHA256"):
            pf._download_sync(shard, local)

    def test_get_stats(self):
        pf, _ = self._make_prefetcher()
        if hasattr(pf, "get_stats"):
            stats = pf.get_stats()
            assert isinstance(stats, dict)

    def test_log_stats(self):
        pf, _ = self._make_prefetcher()
        if hasattr(pf, "log_stats"):
            pf.log_stats()  # should not raise

    def test_stop(self):
        pf, _ = self._make_prefetcher()
        if hasattr(pf, "stop"):
            pf.stop()
            assert pf._running is False


# ---------------------------------------------------------------------------
# Resume Hook
# ---------------------------------------------------------------------------

class TestResumeHook:
    def test_find_model_checkpoint_explicit(self):
        from vaultlayer._resume_hook import _find_model_checkpoint
        with tempfile.TemporaryDirectory() as tmpdir:
            ckpt_dir = Path(tmpdir)
            model_file = ckpt_dir / "model.pt"
            model_file.write_bytes(b"fake model")
            result = _find_model_checkpoint(ckpt_dir)
        assert result is not None
        assert result.name == "model.pt"

    def test_find_model_checkpoint_fallback(self):
        from vaultlayer._resume_hook import _find_model_checkpoint
        with tempfile.TemporaryDirectory() as tmpdir:
            ckpt_dir = Path(tmpdir)
            # Use fallback extension
            custom = ckpt_dir / "checkpoint_step100.pth"
            custom.write_bytes(b"model")
            result = _find_model_checkpoint(ckpt_dir)
        assert result is not None

    def test_find_model_checkpoint_none(self):
        from vaultlayer._resume_hook import _find_model_checkpoint
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _find_model_checkpoint(Path(tmpdir))
        assert result is None

    def test_strip_ddp_prefix_both_plain(self):
        from vaultlayer._resume_hook import _strip_ddp_prefix
        state = {"layer.weight": "val"}
        module = MagicMock()
        module.state_dict.return_value = {"layer.weight": "val2"}
        result = _strip_ddp_prefix(state, module)
        assert result == state

    def test_strip_ddp_prefix_ckpt_has_module(self):
        from vaultlayer._resume_hook import _strip_ddp_prefix
        state = {"module.layer.weight": "val"}
        module = MagicMock()
        module.state_dict.return_value = {"layer.weight": "val2"}
        result = _strip_ddp_prefix(state, module)
        # Should strip 'module.' prefix
        assert "layer.weight" in result

    def test_strip_ddp_prefix_model_has_module(self):
        from vaultlayer._resume_hook import _strip_ddp_prefix
        state = {"layer.weight": "val"}
        module = MagicMock()
        module.state_dict.return_value = {"module.layer.weight": "val2"}
        result = _strip_ddp_prefix(state, module)
        # Should add 'module.' prefix
        assert "module.layer.weight" in result

    def test_strip_ddp_prefix_empty_state(self):
        from vaultlayer._resume_hook import _strip_ddp_prefix
        result = _strip_ddp_prefix({}, MagicMock())
        assert result == {}

    def test_load_optimizer_state_no_file(self):
        from vaultlayer._resume_hook import _load_optimizer_state
        with tempfile.TemporaryDirectory() as tmpdir:
            _load_optimizer_state(Path(tmpdir))  # Should not raise
            # No optimizer file → env var should not be set
            assert "VAULTLAYER_OPT_STATE_PATH" not in os.environ or \
                   not Path(os.environ.get("VAULTLAYER_OPT_STATE_PATH", "")).exists()

    def test_fast_forward_scheduler_zero_step(self):
        from vaultlayer._resume_hook import _fast_forward_scheduler
        mock_scheduler = MagicMock()
        _fast_forward_scheduler("test_sched", mock_scheduler, 0)
        # resume_step=0 → return early, no modification
        mock_scheduler._get_closed_form_lr = MagicMock()

    def test_fast_forward_scheduler_with_step(self):
        from vaultlayer._resume_hook import _fast_forward_scheduler
        mock_scheduler = MagicMock()
        mock_scheduler._get_closed_form_lr.return_value = [0.001]
        mock_scheduler.optimizer.param_groups = [{"lr": 0.01}]
        _fast_forward_scheduler("test_sched", mock_scheduler, 100)
        # Should not raise

    def test_fast_forward_scheduler_exception(self):
        from vaultlayer._resume_hook import _fast_forward_scheduler
        mock_scheduler = MagicMock()
        mock_scheduler.last_epoch = property(lambda s: s)
        # Raise on assignment
        type(mock_scheduler).last_epoch = property(
            lambda s: 0, lambda s, v: (_ for _ in ()).throw(AttributeError("read-only"))
        )
        # Should not raise (logs warning instead)
        _fast_forward_scheduler("sched", mock_scheduler, 100)

    def test_collect_schedulers_from_value_not_scheduler(self):
        from vaultlayer._resume_hook import _collect_schedulers_from_value
        results = []
        # Use a base class that won't match plain dicts
        class FakeBase:
            pass
        _collect_schedulers_from_value({"key": "val"}, FakeBase, set(), results)
        assert results == []

    @pytest.mark.skipif(
        __import__("importlib").util.find_spec("torch") is None,
        reason="torch not installed"
    )
    def test_load_model_weights_no_torch(self):
        from vaultlayer._resume_hook import _load_model_weights
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pt") as f:
            f.write(b"not a valid torch file")
            fname = f.name
        module = MagicMock()
        try:
            with patch("torch.load", side_effect=Exception("load failed")):
                result = _load_model_weights(module, Path(fname))
            assert result is False
        finally:
            os.unlink(fname)

    @pytest.mark.skipif(
        __import__("importlib").util.find_spec("torch") is None,
        reason="torch not installed"
    )
    def test_load_model_weights_with_state_dict(self):
        """_load_model_weights handles dict with state_dict key."""
        from vaultlayer._resume_hook import _load_model_weights
        module = MagicMock()
        result_mock = MagicMock()
        result_mock.missing_keys = []
        result_mock.unexpected_keys = []
        module.load_state_dict.return_value = result_mock
        module.state_dict.return_value = {"layer.weight": None}

        state = {"state_dict": {"layer.weight": "tensor"}}
        with patch("torch.load", return_value=state):
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pt") as f:
                f.write(b"fake")
                fname = f.name
            try:
                result = _load_model_weights(module, Path(fname))
            finally:
                os.unlink(fname)
        assert result is True


# ── Fence failure: ESCALATION published + job_runs marked ────────────────

class TestFenceFailureEscalation:
    """_hard_fence_and_confirm must publish ESCALATION and mark job_runs on all-retry failure."""

    def _make_broker(self):
        from agents.broker.agent import BrokerAgent
        config = _dummy_config()
        config.cloudflare.cf_master_token = None
        queue = MockAgentQueue()
        with patch("agents.broker.agent.make_telemetry", return_value=MagicMock()), \
             patch("agents.broker.agent.STSSessionManager", return_value=MagicMock()):
            agent = BrokerAgent(config, queue)
        return agent, queue

    @pytest.mark.asyncio
    async def test_fence_failure_publishes_escalation(self):
        """When all fence retries fail, ESCALATION must be published to the escalate channel."""
        agent, queue = self._make_broker()
        from shared.models import Provider, Job

        job = make_job()
        job.provider = Provider.LAMBDA_LABS
        job.instance_id = "inst-fail-123"

        # Make _hard_fence_lambda always raise
        with patch.object(agent, "_hard_fence_lambda", side_effect=Exception("API timeout")):
            with patch("shared.spend.mark_termination_failed"), \
                 patch("shared.job_run_logger.mark_termination_failed"):
                with patch("asyncio.sleep", new_callable=AsyncMock):
                    await agent._hard_fence_and_confirm(job)

        escalation_events = queue.events_on("escalate")
        assert escalation_events, "ESCALATION must be published to escalate channel on fence failure"
        payload = escalation_events[0].payload
        assert payload.get("reason") == "termination_failed"
        assert "inst-fail-123" in payload.get("instance_id", "")

    @pytest.mark.asyncio
    async def test_fence_retries_before_escalating(self):
        """Fence must be retried _FENCE_MAX_ATTEMPTS times before giving up."""
        agent, queue = self._make_broker()
        from shared.models import Provider

        job = make_job()
        job.provider = Provider.LAMBDA_LABS
        job.instance_id = "inst-retry-456"

        call_count = 0

        async def _flaky_fence(_inst_id):
            nonlocal call_count
            call_count += 1
            raise Exception("transient error")

        with patch.object(agent, "_hard_fence_lambda", side_effect=_flaky_fence):
            with patch("asyncio.sleep", new_callable=AsyncMock):  # skip actual sleep
                with patch("shared.spend.mark_termination_failed"), \
                     patch("shared.job_run_logger.mark_termination_failed"):
                    await agent._hard_fence_and_confirm(job)

        assert call_count == 3, \
            f"Fence should be attempted 3 times, was attempted {call_count}"

    @pytest.mark.asyncio
    async def test_fence_success_on_second_attempt_no_escalation(self):
        """If fence succeeds on retry, no ESCALATION should be published."""
        agent, queue = self._make_broker()
        from shared.models import Provider

        job = make_job()
        job.provider = Provider.LAMBDA_LABS
        job.instance_id = "inst-ok-789"

        attempt = 0

        async def _flaky_fence(_inst_id):
            nonlocal attempt
            attempt += 1
            if attempt == 1:
                raise Exception("first attempt fails")
            # second attempt succeeds (returns None)

        with patch.object(agent, "_hard_fence_lambda", side_effect=_flaky_fence):
            with patch("asyncio.sleep", new_callable=AsyncMock):
                with patch("shared.spend.settle_instance", return_value=1.0), \
                     patch("shared.job_run_logger.close_run"), \
                     patch("shared.job_run_logger.compute_billing", return_value=(60.0, 0.001, 0.0014, 0)):
                    await agent._hard_fence_and_confirm(job)

        escalation_events = [e for e in queue.published if e.get("channel") == "escalate"]
        assert not escalation_events, \
            "No ESCALATION should be published when fence succeeds on retry"
        assert attempt == 2, f"Fence should succeed on attempt 2, got {attempt}"


# ── Bill auditor: discrepancy detection ──────────────────────────────────

class TestBillAuditor:
    """audit_bill() must flag overcharges, undercharges, zero-cost, and missing bills."""

    def test_within_tolerance_no_discrepancy(self):
        from shared.bill_auditor import audit_bill
        result = audit_bill(
            run_id="r1", provider="lambda_labs", billing_seconds=3600,
            rate_per_hr=2.0, estimated_cost_usd=2.0, provider_billed_usd=2.10,
        )
        assert result is None, "5% overcharge within 10% tolerance should return None"

    def test_overcharge_detected(self):
        from shared.bill_auditor import audit_bill, DiscrepancyKind
        result = audit_bill(
            run_id="r2", provider="aws", billing_seconds=3600,
            rate_per_hr=10.0, estimated_cost_usd=10.0, provider_billed_usd=13.0,
        )
        assert result is not None
        assert result.kind == DiscrepancyKind.OVERCHARGE
        assert abs(result.delta_pct - 0.3) < 0.01  # 30% overcharge

    def test_undercharge_detected(self):
        from shared.bill_auditor import audit_bill, DiscrepancyKind
        result = audit_bill(
            run_id="r3", provider="crusoe", billing_seconds=3600,
            rate_per_hr=5.0, estimated_cost_usd=5.0, provider_billed_usd=3.0,
        )
        assert result is not None
        assert result.kind == DiscrepancyKind.UNDERCHARGE

    def test_zero_cost_flagged(self):
        from shared.bill_auditor import audit_bill, DiscrepancyKind
        result = audit_bill(
            run_id="r4", provider="runpod", billing_seconds=1800,
            rate_per_hr=2.0, estimated_cost_usd=1.0, provider_billed_usd=0.0,
        )
        assert result is not None
        assert result.kind == DiscrepancyKind.ZERO_COST

    def test_missing_bill_returned_when_billed_seconds_nonzero(self):
        from shared.bill_auditor import audit_bill, DiscrepancyKind
        result = audit_bill(
            run_id="r5", provider="nebius", billing_seconds=7200,
            rate_per_hr=3.0, estimated_cost_usd=6.0, provider_billed_usd=None,
        )
        assert result is not None
        assert result.kind == DiscrepancyKind.MISSING_BILL

    def test_missing_bill_not_returned_when_zero_seconds(self):
        from shared.bill_auditor import audit_bill
        result = audit_bill(
            run_id="r6", provider="vast_ai", billing_seconds=0,
            rate_per_hr=2.0, estimated_cost_usd=0.0, provider_billed_usd=None,
        )
        assert result is None


# ── Same-provider-first (Issue #12) ──────────────────────────────────────

class TestSameProviderFirst:
    """_try_same_provider_different_az must retry same provider before going cross-cloud."""

    def _make_broker(self):
        from agents.broker.agent import BrokerAgent
        config = _dummy_config()
        config.cloudflare.cf_master_token = None
        queue = MockAgentQueue()
        with patch("agents.broker.agent.make_telemetry", return_value=MagicMock()), \
             patch("agents.broker.agent.STSSessionManager", return_value=MagicMock()):
            agent = BrokerAgent(config, queue)
        return agent, queue

    @pytest.mark.asyncio
    async def test_aws_same_provider_succeeds_skips_cross_cloud(self):
        """If AWS same-AZ retry succeeds, cross-cloud provision must NOT be called."""
        agent, _ = self._make_broker()
        from shared.models import Provider, GPUType

        job = make_job()
        job.provider = Provider.AWS
        job.instance_id = "i-old"
        job.availability_zone = "us-east-1a"

        aws_call_azs = []

        async def _mock_provision_aws(gpu, j, preferred_az=None):
            aws_call_azs.append(preferred_az)
            if preferred_az == "us-east-1b":
                return "i-new-1b"  # succeeds on first different AZ
            return None

        with patch.object(agent, "provision_aws", side_effect=_mock_provision_aws):
            result = await agent._try_same_provider_different_az(job, GPUType.H100_80GB_SXM)

        assert result == "i-new-1b", "Should return instance from first available AZ"
        assert "us-east-1a" not in aws_call_azs, "Must not retry the same AZ the job was in"

    @pytest.mark.asyncio
    async def test_aws_all_azs_fail_returns_none(self):
        """When all same-region AZs fail, _try_same_provider returns None (cross-cloud proceeds)."""
        agent, _ = self._make_broker()
        from shared.models import Provider, GPUType

        job = make_job()
        job.provider = Provider.AWS
        job.instance_id = "i-old"
        job.availability_zone = "us-east-1a"

        async def _mock_provision_aws(gpu, j, preferred_az=None):
            return None  # all AZs fail

        with patch.object(agent, "provision_aws", side_effect=_mock_provision_aws):
            result = await agent._try_same_provider_different_az(job, GPUType.H100_80GB_SXM)

        assert result is None

    @pytest.mark.asyncio
    async def test_preferred_az_passed_to_provision_aws(self):
        """provision_aws must receive the preferred_az argument."""
        agent, _ = self._make_broker()
        from shared.models import Provider, GPUType

        job = make_job()
        job.provider = Provider.AWS
        job.instance_id = "i-old"
        job.availability_zone = "us-east-1c"

        received_azs = []

        async def _mock_provision_aws(gpu, j, preferred_az=None):
            received_azs.append(preferred_az)
            return None

        with patch.object(agent, "provision_aws", side_effect=_mock_provision_aws):
            await agent._try_same_provider_different_az(job, GPUType.H100_80GB_SXM)

        # Should have tried AZs other than us-east-1c
        assert all(az != "us-east-1c" for az in received_azs), \
            "Must not retry the AZ the job was evicted from"
        assert len(received_azs) > 0, "Must have tried at least one other AZ"

    @pytest.mark.asyncio
    async def test_lambda_same_provider_retry(self):
        """Lambda Labs same-provider retry calls provision_lambda once."""
        agent, _ = self._make_broker()
        from shared.models import Provider, GPUType

        job = make_job()
        job.provider = Provider.LAMBDA_LABS
        job.instance_id = "lambda-old"

        async def _mock_provision_lambda(gpu, j):
            return "lambda-new-123"

        with patch.object(agent, "provision_lambda", side_effect=_mock_provision_lambda):
            result = await agent._try_same_provider_different_az(job, GPUType.H100_80GB_SXM)

        assert result == "lambda-new-123"

    @pytest.mark.asyncio
    async def test_unsupported_provider_returns_none(self):
        """Providers without same-provider retry (e.g. Crusoe) return None immediately."""
        agent, _ = self._make_broker()
        from shared.models import Provider, GPUType

        job = make_job()
        job.provider = Provider.CRUSOE
        job.instance_id = "crusoe-old"

        result = await agent._try_same_provider_different_az(job, GPUType.H100_80GB_SXM)
        assert result is None
