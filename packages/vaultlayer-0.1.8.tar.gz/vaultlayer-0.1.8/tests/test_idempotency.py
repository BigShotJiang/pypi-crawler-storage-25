"""Tests for src/shared/idempotency.py — IDEM-1 P0 helpers."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import pytest

from shared.idempotency import (  # noqa: E402
    provision_idempotency_key,
    provision_resource_name,
)


class TestProvisionIdempotencyKey:
    def test_deterministic_same_input(self):
        """Same (job_id, attempt) → same key — required for retry dedup."""
        k1 = provision_idempotency_key("abc-123", 1)
        k2 = provision_idempotency_key("abc-123", 1)
        assert k1 == k2

    def test_different_attempts_differ(self):
        """Incrementing attempt yields a different key — controlled retry."""
        k1 = provision_idempotency_key("abc-123", 1)
        k2 = provision_idempotency_key("abc-123", 2)
        assert k1 != k2

    def test_different_jobs_differ(self):
        """No collision across jobs even at attempt=1."""
        k1 = provision_idempotency_key("job-a", 1)
        k2 = provision_idempotency_key("job-b", 1)
        assert k1 != k2

    def test_uuid_shaped(self):
        """AWS ClientToken: ≤64 ASCII. GCP requestId: UUID v4 non-zero."""
        import uuid as _u
        k = provision_idempotency_key("abc-123", 1)
        parsed = _u.UUID(k)
        assert str(parsed) == k
        assert len(k) <= 64
        assert k != "00000000-0000-0000-0000-000000000000"  # GCP rejects zero-UUID

    def test_rejects_empty_job_id(self):
        with pytest.raises(ValueError, match="job_id"):
            provision_idempotency_key("", 1)

    def test_rejects_non_positive_attempt(self):
        with pytest.raises(ValueError, match="attempt"):
            provision_idempotency_key("abc-123", 0)
        with pytest.raises(ValueError, match="attempt"):
            provision_idempotency_key("abc-123", -1)


class TestProvisionResourceName:
    def test_deterministic_same_input(self):
        n1 = provision_resource_name("abc-1234-5678", 1)
        n2 = provision_resource_name("abc-1234-5678", 1)
        assert n1 == n2

    def test_different_attempts_differ(self):
        n1 = provision_resource_name("abc-1234-5678", 1)
        n2 = provision_resource_name("abc-1234-5678", 2)
        assert n1 != n2

    def test_length_under_provider_caps(self):
        """Longest provider name cap is 63 (AWS EC2 tag). Stay well under."""
        n = provision_resource_name("0123456789abcdef" * 4, 999)
        # prefix + "-" + "999" + "-" + up-to-8-chars
        assert len(n) <= 20, f"{n!r} too long"

    def test_uses_custom_prefix(self):
        n = provision_resource_name("abc-123", 1, prefix="stage")
        assert n.startswith("stage-"), n

    def test_lowercases_and_sanitizes(self):
        """AWS names: lowercase alphanumeric + hyphens only."""
        n = provision_resource_name("ABC-123_uppercase!", 1)
        # every char must be alphanumeric or hyphen
        assert all(c.isalnum() or c == "-" for c in n), n
        # must be lowercase
        assert n == n.lower(), n

    def test_rejects_empty_job_id(self):
        with pytest.raises(ValueError, match="job_id"):
            provision_resource_name("", 1)

    def test_rejects_non_positive_attempt(self):
        with pytest.raises(ValueError, match="attempt"):
            provision_resource_name("abc-123", 0)


class TestAWSProviderWiring:
    """IDEM-1 wiring into src/agents/broker/providers/aws.py."""

    def test_get_attempt_num_pydantic_fresh_job(self):
        """A fresh Pydantic Job has no _provision_attempts — attempt 1."""
        from shared.models import Job, GPUType, Provider
        from agents.broker.providers.aws import _get_attempt_num

        j = Job(
            job_id="test-123", name="t", script_b64="",
            gpu_type=GPUType.A100_40GB, provider=Provider.AWS,
        )
        assert _get_attempt_num(j) == 1

    def test_get_attempt_num_pydantic_after_attempts(self):
        """After attempts recorded, counter advances."""
        from shared.models import Job, GPUType, Provider
        from agents.broker.providers.aws import _get_attempt_num

        j = Job(
            job_id="test-123", name="t", script_b64="",
            gpu_type=GPUType.A100_40GB, provider=Provider.AWS,
        )
        j.__dict__["_provision_attempts"] = [{"provider": "AWS", "error": "x"}]
        assert _get_attempt_num(j) == 2
        j.__dict__["_provision_attempts"].append({"provider": "AWS", "error": "y"})
        assert _get_attempt_num(j) == 3

    def test_get_attempt_num_dict_fresh_job(self):
        """Worker-side dict-form job: key absent → attempt 1."""
        from agents.broker.providers.aws import _get_attempt_num
        assert _get_attempt_num({"job_id": "x"}) == 1

    def test_get_attempt_num_dict_with_attempts(self):
        from agents.broker.providers.aws import _get_attempt_num
        assert _get_attempt_num({"_provision_attempts": [1, 2, 3]}) == 4

    def test_get_attempt_num_handles_none_value(self):
        """_provision_attempts explicitly None should still return 1."""
        from agents.broker.providers.aws import _get_attempt_num
        assert _get_attempt_num({"_provision_attempts": None}) == 1

    def test_spot_run_instances_includes_client_token(self):
        """Wiring test: ec2.run_instances is called with a ClientToken
        derived from (job_id, attempt, region)."""
        from unittest.mock import MagicMock, patch
        from shared.models import Job, GPUType, Provider
        from agents.broker.providers import aws as aws_mod

        # Read the source and verify the wiring is present. This is a
        # lightweight contract test — a full integration test would need
        # mocking the entire STS + EC2 client surface, which is covered
        # by test_provider_matrix.py indirectly.
        src_path = Path(aws_mod.__file__)
        src = src_path.read_text()
        # Spot path
        assert "ClientToken=_client_token" in src, "Spot path must pass ClientToken"
        assert "aws-spot:" in src, "Spot token key must namespace with aws-spot"
        # OD path
        assert "aws-od:" in src, "OD token key must namespace with aws-od"
        # Both paths must derive token from job_id + region + attempt
        assert "provision_idempotency_key" in src
        assert "_get_attempt_num(job)" in src

    def test_different_regions_get_different_tokens(self):
        """A Spot attempt in us-east-1 and a fallback retry in us-west-2
        MUST produce different ClientTokens — otherwise AWS caches the
        first region's response and blocks the fallback."""
        k_use1 = provision_idempotency_key("job-abc:aws-spot:us-east-1", 1)
        k_usw2 = provision_idempotency_key("job-abc:aws-spot:us-west-2", 1)
        assert k_use1 != k_usw2

    def test_spot_and_od_get_different_tokens_same_region(self):
        """Spot and OD in same region must use different tokens — same
        region name alone is insufficient namespacing since market type
        differs."""
        k_spot = provision_idempotency_key("job-abc:aws-spot:us-east-1", 1)
        k_od = provision_idempotency_key("job-abc:aws-od:us-east-1", 1)
        assert k_spot != k_od
