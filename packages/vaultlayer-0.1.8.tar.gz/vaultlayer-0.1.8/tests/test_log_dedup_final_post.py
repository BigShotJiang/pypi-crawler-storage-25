"""IDEM-2 / log dedup: final-POST-at-exit drains from /tmp/vl_log_offset
instead of re-sending lines[:500] / lines[-100:].

This pins the contract from PR #76 (offset-tracking heartbeat) +
the follow-up that fixed the residual 2x duplication. Verified live
on smoke v3 (job 996bab81): the residual ratio came from the final
POST sending a snapshot on top of what the heartbeat had already
streamed. Both paths now read the same offset_file.
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import pytest


def _build_vm_script_for_test():
    """Generate a real VM startup script with a docker_image set so the
    final-POST-at-exit code path (lines 752-790) is included."""
    from shared.models import Job, GPUType, Provider
    from agents.broker import startup_scripts

    j = Job(
        job_id="test-job-final-post",
        name="t",
        script_b64="QQ==",
        gpu_type=GPUType.A10G,
        provider=Provider.AWS,
        docker_image="ghcr.io/test/img:1.0",
        environment={"VL_SCRIPT_NAME": "train.py", "VL_JOB_TOKEN": "xxx"},
    )
    broker = MagicMock()
    broker._r2_minter = None
    broker.config.cloudflare.r2_access_key_id = "ak"
    broker.config.cloudflare.r2_secret_access_key = "sk"
    broker.config.cloudflare.r2_endpoint = "https://x.r2.cloudflarestorage.com"
    broker.config.cloudflare.r2_bucket = "vlbucket"
    return startup_scripts.build_vm_startup_script(broker, j)


def _build_container_script_for_test():
    """Generate the container-builder onstart script (RunPod / Vast path)."""
    from shared.models import Job, GPUType, Provider
    from agents.broker import startup_scripts

    j = Job(
        job_id="test-job-container",
        name="t",
        script_b64="QQ==",
        gpu_type=GPUType.A10G,
        provider=Provider.RUNPOD,
        docker_image="ghcr.io/test/img:1.0",
        environment={"VL_SCRIPT_NAME": "train.py", "VL_JOB_TOKEN": "xxx"},
    )
    broker = MagicMock()
    broker._r2_minter = None
    broker.config.cloudflare.r2_access_key_id = "ak"
    broker.config.cloudflare.r2_secret_access_key = "sk"
    broker.config.cloudflare.r2_endpoint = "https://x.r2.cloudflarestorage.com"
    broker.config.cloudflare.r2_bucket = "vlbucket"
    return startup_scripts.build_container_onstart(broker, j)


class TestFinalPostUsesOffsetTracker:
    """The two final-POST-at-exit code paths (VM + container) MUST drain
    /tmp/vl_log_offset instead of re-sending a fixed-size snapshot."""

    def test_vm_final_post_reads_offset_file(self):
        script = _build_vm_script_for_test()
        # The final POST block must reference /tmp/vl_log_offset
        assert "/tmp/vl_log_offset" in script
        # Counted: bootstrap heartbeat (1) + final POST (1) — 2 references
        # minimum (more if container-only blocks are included; this is VM
        # script only)
        assert script.count("/tmp/vl_log_offset") >= 2, (
            f"expected >= 2 references to /tmp/vl_log_offset (heartbeat + "
            f"final POST), got {script.count('/tmp/vl_log_offset')}"
        )

    def test_vm_final_post_no_fixed_snapshot(self):
        """Anti-regression: the old code did `splitlines()[-100:]` or
        `splitlines()[:500]` in the final POST. Make sure neither sneaks
        back."""
        script = _build_vm_script_for_test()
        assert "splitlines()[-100:]" not in script, (
            "old final-POST snapshot found in VM script — must use offset"
        )
        assert "splitlines()[:500]" not in script, (
            "old final-POST snapshot found in VM script — must use offset"
        )

    def test_vm_final_post_appends_training_complete(self):
        """The TRAINING_COMPLETE marker must still be appended at exit so
        downstream consumers can detect successful completion."""
        script = _build_vm_script_for_test()
        assert "TRAINING_COMPLETE" in script

    def test_container_final_post_reads_offset_file(self):
        script = _build_container_script_for_test()
        assert "/tmp/vl_log_offset" in script
        # Container path has heartbeat + final POST + completion event POST
        assert script.count("/tmp/vl_log_offset") >= 2, (
            f"container script needs offset tracking on heartbeat AND final "
            f"POST; got {script.count('/tmp/vl_log_offset')} references"
        )

    def test_container_final_post_no_fixed_snapshot(self):
        script = _build_container_script_for_test()
        assert "splitlines()[-100:]" not in script
        assert "splitlines()[:500]" not in script


class TestHeartbeatBehaviorPreserved:
    """PR #76 fix should still be in place — heartbeat tracks offset, only
    advances on POST success, handles partial-line tails."""

    def test_vm_heartbeat_advances_offset_only_on_success(self):
        script = _build_vm_script_for_test()
        # The offset write should be inside the POST-success branch.
        # Specifically: open(offset_file, 'w').write(str(new_offset))
        # appears AFTER urlopen succeeds.
        assert "open(offset_file, 'w').write(str(new_offset))" in script

    def test_vm_heartbeat_handles_partial_line_tail(self):
        """rfind(b'\\n') prevents a partial last line from being POSTed
        and split across two heartbeats."""
        script = _build_vm_script_for_test()
        assert "chunk.rfind(b'\\n')" in script

    def test_vm_heartbeat_skips_when_no_token(self):
        """Heartbeat exits cleanly when no VL_JOB_TOKEN — never crashes."""
        script = _build_vm_script_for_test()
        assert "if not job_token: raise SystemExit(0)" in script
