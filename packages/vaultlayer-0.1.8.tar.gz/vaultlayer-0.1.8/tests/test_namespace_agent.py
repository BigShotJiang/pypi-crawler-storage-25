"""
VaultLayer -- Tests: Namespace Agent (Neutral Zone)
Tests all three pillars:
  Pillar 1: Zero-Egress Storage  (ingestion, manifest building)
  Pillar 2: Global Namespace     (mount config, path consistency)
  Pillar 3: Intelligent Cache    (LRU, prefetch, step mapping)

All external I/O mocked. No real R2 or SSH needed.
Run: pytest tests/test_namespace_agent.py -v
"""

import asyncio
import hashlib
import io
import tarfile
import tempfile
from collections import OrderedDict
from datetime import datetime
from pathlib import Path
from typing import List, Optional
from unittest.mock import AsyncMock, MagicMock

import pytest


# -- Fixtures ----------------------------------------------------------------

@pytest.fixture
def tmp_dataset(tmp_path):
    d = tmp_path / "dataset"
    d.mkdir()
    for i in range(5):
        (d / f"shard_{i:04d}.jsonl").write_bytes(b"x" * (1024 * 1024))
    return d


@pytest.fixture
def mock_r2():
    r2 = MagicMock()
    r2.bucket = "vaultlayer-test"
    r2._s3.put_object = MagicMock(return_value={"ETag": "abc"})
    r2._s3.get_object = MagicMock(return_value={"Body": MagicMock(read=MagicMock(return_value=b"{}"))})
    r2.healthcheck = MagicMock(return_value=True)
    return r2


@pytest.fixture
def sample_manifest():
    from shared.models_additions import ShardManifest, ShardRecord, ShardFormat
    shards = [
        ShardRecord(shard_id=f"s{i}", r2_key=f"datasets/test/shard-{i:06d}.tar",
                    local_name=f"shard-{i:06d}.tar", size_bytes=1024*1024,
                    sha256="abc123", shard_index=i)
        for i in range(10)
    ]
    return ShardManifest(
        dataset_id="test-dataset", dataset_name="Test", total_shards=10,
        total_size_bytes=10*1024*1024, total_rows=10000,
        r2_prefix="datasets/test/", shards=shards,
        sequential=True, shard_size_bytes_avg=1024*1024, recommended_prefetch_count=3,
    )


# -- Pillar 1: Ingestion -----------------------------------------------------

class TestDatasetShardBuilder:
    def test_correct_shard_count(self, tmp_dataset):
        from agents.namespace.ingestion import DatasetShardBuilder
        builder = DatasetShardBuilder(tmp_dataset, shard_size_bytes=2*1024*1024)
        shards = builder.build_shards()
        assert len(shards) == 3  # 5x1MB files, 2MB shard size = ceil(5/2) = 3

    def test_single_shard_small_dataset(self, tmp_dataset):
        from agents.namespace.ingestion import DatasetShardBuilder
        shards = DatasetShardBuilder(tmp_dataset, 100*1024*1024).build_shards()
        assert len(shards) == 1

    def test_files_sorted(self, tmp_dataset):
        from agents.namespace.ingestion import DatasetShardBuilder
        files = DatasetShardBuilder(tmp_dataset, 100*1024*1024).collect_files()
        names = [f.name for f in files]
        assert names == sorted(names)

    def test_shard_is_valid_tar(self, tmp_dataset):
        from agents.namespace.ingestion import DatasetShardBuilder
        shards = DatasetShardBuilder(tmp_dataset, 100*1024*1024).build_shards()
        with tarfile.open(fileobj=io.BytesIO(shards[0]), mode="r") as tar:
            assert len(tar.getnames()) > 0


class TestDatasetIngester:
    @pytest.mark.asyncio
    async def test_returns_manifest(self, tmp_dataset, mock_r2):
        from agents.namespace.ingestion import DatasetIngester
        m = await DatasetIngester(mock_r2, "test-ds").ingest(str(tmp_dataset))
        assert m.dataset_id == "test-ds"
        assert m.total_shards > 0
        assert len(m.shards) == m.total_shards

    @pytest.mark.asyncio
    async def test_uploads_shards_plus_manifest(self, tmp_dataset, mock_r2):
        from agents.namespace.ingestion import DatasetIngester
        m = await DatasetIngester(mock_r2, "test-ds", shard_size_bytes=2*1024*1024).ingest(str(tmp_dataset))
        assert mock_r2._s3.put_object.call_count == m.total_shards + 1  # shards + manifest

    @pytest.mark.asyncio
    async def test_manifest_written_to_correct_key(self, tmp_dataset, mock_r2):
        from agents.namespace.ingestion import DatasetIngester
        await DatasetIngester(mock_r2, "my-dataset").ingest(str(tmp_dataset))
        calls = mock_r2._s3.put_object.call_args_list
        keys = [c.kwargs.get("Key", "") for c in calls]
        assert "datasets/my-dataset/manifest.json" in keys

    @pytest.mark.asyncio
    async def test_raises_on_missing_path(self, mock_r2):
        from agents.namespace.ingestion import DatasetIngester
        with pytest.raises(FileNotFoundError):
            await DatasetIngester(mock_r2, "x").ingest("/nonexistent")

    @pytest.mark.asyncio
    async def test_progress_callback(self, tmp_dataset, mock_r2):
        from agents.namespace.ingestion import DatasetIngester
        calls = []
        m = await DatasetIngester(mock_r2, "x", on_progress=lambda u, t: calls.append((u, t))).ingest(str(tmp_dataset))
        assert len(calls) == m.total_shards
        assert calls[-1][0] == calls[-1][1]

    @pytest.mark.asyncio
    async def test_load_manifest_returns_none_on_missing(self, mock_r2):
        from agents.namespace.ingestion import DatasetIngester
        from botocore.exceptions import ClientError
        mock_r2._s3.get_object.side_effect = ClientError(
            {"Error": {"Code": "NoSuchKey", "Message": "Not found"}}, "GetObject")
        assert await DatasetIngester.load_manifest(mock_r2, "nonexistent") is None


# -- Pillar 2: Mount ---------------------------------------------------------

class TestRcloneMountManager:
    def mgr(self):
        from agents.namespace.mount import RcloneMountManager
        return RcloneMountManager("https://test.r2.example.com", "KEY", "SECRET", "bucket")

    def test_config_contains_required_fields(self):
        cfg = self.mgr().build_rclone_config()
        assert "[r2]" in cfg
        assert "Cloudflare" in cfg
        assert "KEY" in cfg
        assert "SECRET" in cfg

    def test_mount_command_has_required_flags(self):
        cmd = self.mgr().build_mount_command("datasets/my-ds/")
        assert "rclone mount" in cmd
        assert "/mnt/vaultlayer" in cmd
        assert "--vfs-cache-mode full" in cmd
        assert "--daemon" in cmd

    def test_mount_path_consistent_across_providers(self):
        from agents.namespace.mount import MOUNT_PATH
        assert MOUNT_PATH == "/mnt/vaultlayer"
        m1 = self.mgr()
        m2 = self.mgr()
        assert m1.mount_path == m2.mount_path == "/mnt/vaultlayer"

    def test_mount_command_includes_prefix(self):
        cmd = self.mgr().build_mount_command("datasets/my-dataset/")
        assert "datasets/my-dataset" in cmd


# -- Pillar 3: Prefetch ------------------------------------------------------

class TestLRUCache:
    def entry(self, sid, size=10*1024*1024):
        from shared.models_additions import CacheEntry
        return CacheEntry(shard_id=sid, r2_key=f"k/{sid}", local_path=f"/tmp/{sid}", size_bytes=size)

    def test_put_and_get(self):
        from agents.namespace.prefetch import LRUCache
        cache = LRUCache(100*1024*1024)
        cache.put(self.entry("s1"))
        assert cache.get("s1") is not None

    def test_miss_returns_none(self):
        from agents.namespace.prefetch import LRUCache
        assert LRUCache(100*1024*1024).get("nope") is None

    def test_evicts_lru_when_full(self):
        from agents.namespace.prefetch import LRUCache
        cache = LRUCache(20*1024*1024)
        cache.put(self.entry("s1"))
        cache.put(self.entry("s2"))
        evicted = cache.put(self.entry("s3"))
        assert len(evicted) == 1 and evicted[0].shard_id == "s1"
        assert not cache.contains("s1")

    def test_access_promotes_entry(self):
        from agents.namespace.prefetch import LRUCache
        cache = LRUCache(20*1024*1024)
        cache.put(self.entry("s1"))
        cache.put(self.entry("s2"))
        cache.get("s1")
        evicted = cache.put(self.entry("s3"))
        assert evicted[0].shard_id == "s2"
        assert cache.contains("s1")

    def test_size_tracking(self):
        from agents.namespace.prefetch import LRUCache
        cache = LRUCache(100*1024*1024)
        cache.put(self.entry("s1", 15*1024*1024))
        assert cache.used_bytes == 15*1024*1024
        assert cache.free_bytes == 85*1024*1024


class TestIntelligentPrefetcher:
    def make(self, manifest, r2, tmp_path):
        from agents.namespace.prefetch import IntelligentPrefetcher
        return IntelligentPrefetcher(
            job_id="job-001", manifest=manifest, cache_dir=str(tmp_path),
            r2_client=r2, cache_size_bytes=50*1024*1024,
        )

    def test_step_to_shard_index(self, sample_manifest, mock_r2, tmp_path):
        p = self.make(sample_manifest, mock_r2, tmp_path)
        assert p.step_to_shard_index(0) == 0
        assert p.step_to_shard_index(1000) == 1
        assert p.step_to_shard_index(5000) == 5
        assert p.step_to_shard_index(10000) == 0  # wraps

    def test_predict_next_shards(self, sample_manifest, mock_r2, tmp_path):
        p = self.make(sample_manifest, mock_r2, tmp_path)
        indices = [s.shard_index for s in p.predict_next_shards(2)]
        assert indices == [3, 4, 5]

    def test_predict_wraps_at_epoch_boundary(self, sample_manifest, mock_r2, tmp_path):
        p = self.make(sample_manifest, mock_r2, tmp_path)
        indices = [s.shard_index for s in p.predict_next_shards(8)]
        assert indices == [9, 0, 1]

    @pytest.mark.asyncio
    async def test_cache_hit_no_download(self, sample_manifest, mock_r2, tmp_path):
        from shared.models_additions import CacheEntry
        p = self.make(sample_manifest, mock_r2, tmp_path)
        shard = sample_manifest.shards[0]
        local = tmp_path / f"shard-{shard.shard_index:06d}.tar"
        local.write_bytes(b"data")
        p._cache.put(CacheEntry(shard_id=shard.shard_id, r2_key=shard.r2_key,
                                local_path=str(local), size_bytes=4))
        await p.ensure_shard(shard)
        assert p._hits == 1
        mock_r2._s3.get_object.assert_not_called()

    @pytest.mark.asyncio
    async def test_cache_miss_downloads_from_r2(self, sample_manifest, mock_r2, tmp_path):
        fake = b"shard content " * 100
        sha = hashlib.sha256(fake).hexdigest()
        shard = sample_manifest.shards[0]
        shard.sha256 = sha
        mock_r2._s3.get_object.return_value = {"Body": MagicMock(read=MagicMock(return_value=fake))}
        p = self.make(sample_manifest, mock_r2, tmp_path)
        path = await p.ensure_shard(shard)
        assert Path(path).exists()
        assert p._misses == 1

    def test_stats_keys(self, sample_manifest, mock_r2, tmp_path):
        p = self.make(sample_manifest, mock_r2, tmp_path)
        stats = p.get_stats()
        for key in ("job_id", "hit_rate", "cache_used_gb", "prefetched", "evictions"):
            assert key in stats

    def test_stop(self, sample_manifest, mock_r2, tmp_path):
        p = self.make(sample_manifest, mock_r2, tmp_path)
        p._running = True
        p.stop()
        assert not p._running


# -- NVMe path discovery tests ------------------------------------------------

def _load_prefetch_module():
    """Load prefetch.py without triggering the redis chain via __init__.py."""
    import importlib.util
    import sys
    import types
    from pathlib import Path as _P

    # Stub shared.models_additions once — kept in sys.modules across tests
    if "shared.models_additions" not in sys.modules:
        stub = types.ModuleType("shared.models_additions")
        stub.ShardManifest = object
        stub.ShardRecord = object
        stub.CacheEntry = object
        sys.modules["shared.models_additions"] = stub

    spec = importlib.util.spec_from_file_location(
        "prefetch_direct",
        str(_P(__file__).parent.parent / "src/agents/namespace/prefetch.py"),
    )
    pf = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pf)
    return pf


import shutil as _shutil_global
# Capture the disk_usage namedtuple type BEFORE any monkeypatching.
# Re-using this pre-captured type avoids recursion when shutil.disk_usage is patched.
_DiskUsage = type(_shutil_global.disk_usage("/"))


def _make_disk_usage(total, used, free):
    """Build a shutil.disk_usage-compatible namedtuple (safe under monkeypatch)."""
    return _DiskUsage(total, used, free)


class TestNVMeDiscovery:
    """Tests for discover_fast_data_path() and available_cache_bytes()."""

    def test_fallback_to_tmp_when_no_nvme(self, tmp_path, monkeypatch):
        """On a dev machine with no /mnt/nvme, should fall back to /tmp path."""
        pf = _load_prefetch_module()
        fallback = str(tmp_path / "fallback-cache")
        monkeypatch.setattr(pf, "_FAST_PATH_CANDIDATES", ["/nonexistent/path/vl-cache"])
        monkeypatch.setattr(pf, "_FALLBACK_CACHE", fallback)
        result = pf.discover_fast_data_path()
        assert result == fallback

    def test_accepts_large_filesystem(self, tmp_path, monkeypatch):
        """When a candidate's parent exists and has >50 GB, it should be chosen."""
        pf = _load_prefetch_module()
        import shutil as _shutil

        nvme_parent = tmp_path / "nvme"
        nvme_parent.mkdir()
        candidate = str(nvme_parent / "vl-cache")

        _200gb = 200 * 1024 * 1024 * 1024
        monkeypatch.setattr(pf, "_FAST_PATH_CANDIDATES", [candidate])

        def fake_disk_usage(path):
            return _make_disk_usage(_200gb, 0, _200gb)

        # Patch shutil inside the prefetch module's namespace
        monkeypatch.setattr(pf.shutil, "disk_usage", fake_disk_usage)
        result = pf.discover_fast_data_path()
        assert result == candidate

    def test_skips_small_filesystem(self, tmp_path, monkeypatch):
        """Filesystems smaller than 50 GB (likely tmpfs) are skipped."""
        pf = _load_prefetch_module()

        small_parent = tmp_path / "small"
        small_parent.mkdir()
        candidate = str(small_parent / "vl-cache")
        fallback = str(tmp_path / "fallback")

        monkeypatch.setattr(pf, "_FAST_PATH_CANDIDATES", [candidate])
        monkeypatch.setattr(pf, "_FALLBACK_CACHE", fallback)

        _10gb = 10 * 1024 * 1024 * 1024

        def fake_disk_usage(path):
            return _make_disk_usage(_10gb, 0, _10gb)

        monkeypatch.setattr(pf.shutil, "disk_usage", fake_disk_usage)
        result = pf.discover_fast_data_path()
        assert result == fallback

    def test_available_cache_bytes_applies_reserve(self, tmp_path, monkeypatch):
        """available_cache_bytes reserves 15% and caps at 200 GB."""
        pf = _load_prefetch_module()

        _100gb = 100 * 1024 * 1024 * 1024

        def fake_disk_usage(path):
            return _make_disk_usage(_100gb * 2, _100gb, _100gb)

        monkeypatch.setattr(pf.shutil, "disk_usage", fake_disk_usage)
        result = pf.available_cache_bytes(str(tmp_path))
        expected = int(_100gb * (1 - pf._DISK_RESERVE_FRACTION))
        assert result == expected

    def test_available_cache_bytes_caps_at_max(self, tmp_path, monkeypatch):
        """available_cache_bytes never exceeds _MAX_CACHE_BYTES (200 GB)."""
        pf = _load_prefetch_module()

        _1tb = 1024 * 1024 * 1024 * 1024

        def fake_disk_usage(path):
            return _make_disk_usage(_1tb * 8, 0, _1tb * 8)

        monkeypatch.setattr(pf.shutil, "disk_usage", fake_disk_usage)
        result = pf.available_cache_bytes(str(tmp_path))
        assert result == pf._MAX_CACHE_BYTES