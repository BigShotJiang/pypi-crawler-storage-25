"""
VaultLayer — Watchdog Agent Tests
Verifies termination, OOM, GPU failure, and hung-job detection.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from datetime import datetime, timedelta
from unittest.mock import patch, AsyncMock, MagicMock
from conftest import MockAgentQueue, make_job


# ── 1. Job registration ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_register_job_tracks_job(dummy_config, mock_queue):
    from agents.watchdog.agent import WatchdogAgent
    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    async def fake_checkpoint(j): pass
    agent.register_job(job, fake_checkpoint)
    assert job.job_id in agent._active_jobs
    assert job.job_id in agent._checkpoint_callbacks


# ── 2. Heartbeat tracking ─────────────────────────────────────────────────

def test_heartbeat_monitor_marks_healthy_after_record():
    from agents.watchdog.signals import HeartbeatMonitor
    monitor = HeartbeatMonitor()
    monitor.record_heartbeat("job-1")
    assert monitor.is_healthy("job-1") is True


# ── 3. Spot termination detection publishes alert ─────────────────────────

@pytest.mark.asyncio
async def test_termination_signal_publishes_to_watchdog_channel(dummy_config, mock_queue):
    from agents.watchdog.agent import WatchdogAgent
    from shared.models import EventType
    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    checkpoint_called = []

    async def fake_checkpoint(j):
        checkpoint_called.append(j.job_id)

    agent.register_job(job, fake_checkpoint)

    with patch.object(agent, '_narrate_event', return_value="Spot interruption detected.") as mock_narrate:
        await agent.handle_termination(job, reason="spot_interruption", termination_time="2026-03-28T12:00:00Z")

    watchdog_events = mock_queue.events_on("watchdog")
    assert watchdog_events, "No events published to watchdog channel"
    assert EventType.TERMINATION_SIGNAL in [e.event_type for e in watchdog_events]


# ── 4. OOM detection returns True when pattern found ─────────────────────

@pytest.mark.asyncio
async def test_check_oom_detects_cuda_oom(dummy_config, mock_queue):
    from agents.watchdog.agent import WatchdogAgent
    from shared.models import EventType
    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()

    fake_proc = AsyncMock()
    fake_proc.communicate = AsyncMock(return_value=(b"CUDA out of memory. Tried to allocate 2.00 GiB", b""))

    async def _mock_wait_for(coro, timeout=None):
        coro.close()  # close the coroutine to suppress unawaited-coroutine warning
        return (b"CUDA out of memory. Tried to allocate 2.00 GiB", b"")

    with patch('asyncio.create_subprocess_exec', return_value=fake_proc), \
         patch('asyncio.wait_for', side_effect=_mock_wait_for):
        result = await agent.check_oom(job)

    assert result is True
    watchdog_events = mock_queue.events_on("watchdog")
    assert EventType.TERMINATION_SIGNAL in [e.event_type for e in watchdog_events]


# ── 5. OOM detection returns False when clean ────────────────────────────

@pytest.mark.asyncio
async def test_check_oom_returns_false_when_clean(dummy_config, mock_queue):
    from agents.watchdog.agent import WatchdogAgent
    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()

    with patch('asyncio.create_subprocess_exec', side_effect=FileNotFoundError("dmesg not found")):
        result = await agent.check_oom(job)

    assert result is False


# ── 6. GPU failure detected via Xid error ────────────────────────────────

@pytest.mark.asyncio
async def test_check_gpu_failure_detects_xid_error(dummy_config, mock_queue):
    from agents.watchdog.agent import WatchdogAgent
    from shared.models import EventType
    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()

    async def _mock_wait_for(coro, timeout=None):
        coro.close()  # close the coroutine to suppress unawaited-coroutine warning
        return (b"NVRM: Xid (PCI:0000:00:1e): 79, pid='<unknown>' name=<unknown>", b"")

    with patch('asyncio.create_subprocess_exec'), \
         patch('asyncio.wait_for', side_effect=_mock_wait_for):
        result = await agent.check_gpu_failure(job)

    assert result is True


# ── 7. GPU failure returns False when no errors ──────────────────────────

@pytest.mark.asyncio
async def test_check_gpu_failure_returns_false_when_clean(dummy_config, mock_queue):
    from agents.watchdog.agent import WatchdogAgent
    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()

    with patch('asyncio.create_subprocess_exec', side_effect=FileNotFoundError("dmesg not found")):
        result = await agent.check_gpu_failure(job)

    assert result is False


# ── 8. Hung job detected after timeout ──────────────────────────────────

@pytest.mark.asyncio
async def test_check_hung_job_detects_stale_heartbeat(dummy_config, mock_queue):
    from agents.watchdog.agent import WatchdogAgent
    from shared.models import EventType
    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    # Set last heartbeat to 35 minutes ago (beyond 30 min threshold)
    job.last_heartbeat_at = datetime.utcnow() - timedelta(minutes=35)

    result = await agent.check_hung_job(job)

    assert result is True
    watchdog_events = mock_queue.events_on("watchdog")
    assert EventType.TERMINATION_SIGNAL in [e.event_type for e in watchdog_events]


# ── 9. Hung job not triggered for active job ─────────────────────────────

@pytest.mark.asyncio
async def test_check_hung_job_returns_false_for_active_job(dummy_config, mock_queue):
    from agents.watchdog.agent import WatchdogAgent
    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    # Recent heartbeat — 2 minutes ago (well within 5 min threshold)
    job.last_heartbeat_at = datetime.utcnow() - timedelta(minutes=2)

    result = await agent.check_hung_job(job)

    assert result is False


# ── 10. Hung job skipped when no heartbeat attr ──────────────────────────

@pytest.mark.asyncio
async def test_check_hung_job_skips_when_no_heartbeat(dummy_config, mock_queue):
    from agents.watchdog.agent import WatchdogAgent
    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    # No last_heartbeat_at set
    if hasattr(job, 'last_heartbeat_at'):
        job.last_heartbeat_at = None

    result = await agent.check_hung_job(job)

    assert result is False
