"""
VaultLayer — Multi-Node Guard Tests
Verifies that vaultlayer run refuses multi-node distributed jobs in V0.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from cli.run import RunCommand


def _runner(cmd):
    return RunCommand(command=cmd, job_name="test", gpu_type="H100_80GB_SXM")


# ── torchrun --nnodes ─────────────────────────────────────────────────────────

def test_torchrun_nnodes_gt1_aborts(monkeypatch):
    """torchrun --nnodes 4 must be rejected."""
    monkeypatch.delenv("VAULTLAYER_ALLOW_MULTINODE", raising=False)
    runner = _runner(["torchrun", "--nnodes", "4", "--nproc_per_node", "8", "train.py"])
    with pytest.raises(SystemExit) as exc:
        runner._check_multi_node()
    assert exc.value.code == 1


def test_torchrun_nnodes_eq1_passes(monkeypatch):
    """torchrun --nnodes 1 is fine — single-node multi-GPU."""
    monkeypatch.delenv("VAULTLAYER_ALLOW_MULTINODE", raising=False)
    runner = _runner(["torchrun", "--nnodes", "1", "--nproc_per_node", "8", "train.py"])
    runner._check_multi_node()  # must not raise or exit


def test_torchrun_no_nnodes_passes(monkeypatch):
    """torchrun without --nnodes defaults to 1 — single-node."""
    monkeypatch.delenv("VAULTLAYER_ALLOW_MULTINODE", raising=False)
    for key in ("WORLD_SIZE", "NODE_RANK", "RANK"):
        monkeypatch.delenv(key, raising=False)
    runner = _runner(["torchrun", "--nproc_per_node", "8", "train.py"])
    runner._check_multi_node()  # must not raise


# ── deepspeed --num_nodes ─────────────────────────────────────────────────────

def test_deepspeed_num_nodes_gt1_aborts(monkeypatch):
    """deepspeed --num_nodes 2 must be rejected."""
    monkeypatch.delenv("VAULTLAYER_ALLOW_MULTINODE", raising=False)
    runner = _runner(["deepspeed", "--num_nodes", "2", "train.py"])
    with pytest.raises(SystemExit) as exc:
        runner._check_multi_node()
    assert exc.value.code == 1


def test_deepspeed_hostfile_aborts(monkeypatch):
    """deepspeed --hostfile implies multi-node — must be rejected."""
    monkeypatch.delenv("VAULTLAYER_ALLOW_MULTINODE", raising=False)
    runner = _runner(["deepspeed", "--hostfile", "/tmp/hosts", "train.py"])
    with pytest.raises(SystemExit) as exc:
        runner._check_multi_node()
    assert exc.value.code == 1


# ── WORLD_SIZE / NODE_RANK env vars ──────────────────────────────────────────

def test_world_size_gt1_aborts(monkeypatch):
    """WORLD_SIZE > 1 in environment must be rejected."""
    monkeypatch.setenv("WORLD_SIZE", "8")
    monkeypatch.delenv("VAULTLAYER_ALLOW_MULTINODE", raising=False)
    runner = _runner(["python", "train.py"])
    with pytest.raises(SystemExit) as exc:
        runner._check_multi_node()
    assert exc.value.code == 1
    monkeypatch.delenv("WORLD_SIZE")


def test_node_rank_gt0_aborts(monkeypatch):
    """NODE_RANK > 0 means we're a non-primary node in a multi-node job."""
    monkeypatch.setenv("NODE_RANK", "1")
    monkeypatch.delenv("VAULTLAYER_ALLOW_MULTINODE", raising=False)
    runner = _runner(["python", "train.py"])
    with pytest.raises(SystemExit) as exc:
        runner._check_multi_node()
    assert exc.value.code == 1
    monkeypatch.delenv("NODE_RANK")


def test_world_size_eq1_passes(monkeypatch):
    """WORLD_SIZE=1 is single-node — must pass."""
    monkeypatch.setenv("WORLD_SIZE", "1")
    monkeypatch.delenv("NODE_RANK", raising=False)
    monkeypatch.delenv("RANK", raising=False)
    monkeypatch.delenv("VAULTLAYER_ALLOW_MULTINODE", raising=False)
    runner = _runner(["python", "train.py"])
    runner._check_multi_node()  # must not raise


# ── VAULTLAYER_ALLOW_MULTINODE override ───────────────────────────────────────

def test_allow_multinode_override_bypasses_guard(monkeypatch):
    """VAULTLAYER_ALLOW_MULTINODE=1 must let multi-node jobs through with a warning."""
    monkeypatch.setenv("VAULTLAYER_ALLOW_MULTINODE", "1")
    monkeypatch.setenv("WORLD_SIZE", "8")
    runner = _runner(["torchrun", "--nnodes", "4", "train.py"])
    runner._check_multi_node()  # must NOT exit — override is set
    monkeypatch.delenv("WORLD_SIZE")


# ── Plain single-node job ─────────────────────────────────────────────────────

def test_plain_python_passes(monkeypatch):
    """Plain python train.py — no distributed markers — must pass."""
    for key in ("WORLD_SIZE", "NODE_RANK", "RANK", "VAULTLAYER_ALLOW_MULTINODE"):
        monkeypatch.delenv(key, raising=False)
    runner = _runner(["python", "train.py"])
    runner._check_multi_node()  # must not raise
