"""Phase 1 tests for src/api/unified_queue.py — priority ordering,
per-provider caps, backoff, release mechanics."""
from __future__ import annotations

import time

import pytest

from api.unified_queue import (
    PRIO_FAILOVER,
    PRIO_LOW,
    PRIO_NORMAL,
    cap_for,
    dequeue_for_provider,
    enqueue,
    provider_load,
    queue_depth,
    queue_depth_by_priority,
    release,
    reset_for_test,
)


@pytest.fixture(autouse=True)
def _reset() -> None:
    reset_for_test()
    yield
    reset_for_test()


def test_enqueue_then_dequeue_returns_same_item() -> None:
    enqueue("job-a", PRIO_NORMAL)
    item = dequeue_for_provider(["Vast.ai"])
    assert item is not None
    assert item.job_id == "job-a"


def test_priority_ordering_failover_beats_normal() -> None:
    enqueue("normal-1", PRIO_NORMAL)
    enqueue("normal-2", PRIO_NORMAL)
    enqueue("failover-1", PRIO_FAILOVER)
    item = dequeue_for_provider(["Vast.ai"])
    assert item is not None
    assert item.job_id == "failover-1"


def test_within_priority_is_fifo() -> None:
    enqueue("a", PRIO_NORMAL)
    time.sleep(0.01)
    enqueue("b", PRIO_NORMAL)
    first = dequeue_for_provider(["Vast.ai"])
    second = dequeue_for_provider(["Vast.ai"])
    assert first is not None and first.job_id == "a"
    assert second is not None and second.job_id == "b"


def test_provider_cap_blocks_extras() -> None:
    # Vast default cap = 3
    for i in range(5):
        enqueue(f"v-{i}", PRIO_NORMAL)
    picked = []
    for _ in range(5):
        item = dequeue_for_provider(["Vast.ai"])
        if item:
            picked.append(item.job_id)
    # Only 3 should have been claimed — the other 2 blocked by cap
    assert len(picked) == cap_for("Vast.ai")
    assert queue_depth() == 5 - cap_for("Vast.ai")


def test_release_opens_slot_for_queued_item() -> None:
    for i in range(5):
        enqueue(f"v-{i}", PRIO_NORMAL)
    # Drain to cap
    first_batch = [dequeue_for_provider(["Vast.ai"]) for _ in range(3)]
    assert all(it is not None for it in first_batch)
    # 4th would fail — provider at cap
    blocked = dequeue_for_provider(["Vast.ai"])
    assert blocked is None
    # Release one slot; next dequeue should succeed
    release("Vast.ai")
    unblocked = dequeue_for_provider(["Vast.ai"])
    assert unblocked is not None
    assert unblocked.job_id == "v-3"


def test_backoff_skips_item_until_ready() -> None:
    enqueue("delayed", PRIO_NORMAL, backoff_seconds=60)
    enqueue("immediate", PRIO_NORMAL)
    # The delayed item has higher position in heap (same priority, later enqueue),
    # but it's in backoff. Dequeue should return immediate.
    item = dequeue_for_provider(["Vast.ai"])
    assert item is not None
    assert item.job_id == "immediate"
    # Delayed is still in queue
    assert queue_depth() == 1


def test_preferred_provider_fallthrough() -> None:
    # Vast at cap, RunPod has slots
    for _ in range(cap_for("Vast.ai")):
        enqueue("warmup", PRIO_NORMAL)
        dequeue_for_provider(["Vast.ai"])
    # Now enqueue a new job; Vast is at cap so dequeue should pick RunPod
    enqueue("new-job", PRIO_NORMAL)
    item = dequeue_for_provider(["Vast.ai", "RunPod"])
    assert item is not None
    assert item.job_id == "new-job"
    assert item.retry_context["_reserved_provider"] == "RunPod"


def test_all_providers_at_cap_returns_none() -> None:
    # Saturate both Vast and RunPod
    for _ in range(cap_for("Vast.ai")):
        enqueue("v", PRIO_NORMAL)
        dequeue_for_provider(["Vast.ai"])
    for _ in range(cap_for("RunPod")):
        enqueue("r", PRIO_NORMAL)
        dequeue_for_provider(["RunPod"])
    # Now enqueue a new job — both providers are at cap
    enqueue("blocked", PRIO_NORMAL)
    item = dequeue_for_provider(["Vast.ai", "RunPod"])
    assert item is None
    assert queue_depth() == 1


def test_queue_depth_by_priority_reports_lanes() -> None:
    enqueue("f1", PRIO_FAILOVER)
    enqueue("f2", PRIO_FAILOVER)
    enqueue("n1", PRIO_NORMAL)
    enqueue("l1", PRIO_LOW)
    depths = queue_depth_by_priority()
    assert depths[PRIO_FAILOVER] == 2
    assert depths[PRIO_NORMAL] == 1
    assert depths[PRIO_LOW] == 1


def test_provider_load_reports_inflight() -> None:
    enqueue("a", PRIO_NORMAL)
    enqueue("b", PRIO_NORMAL)
    dequeue_for_provider(["Vast.ai"])
    dequeue_for_provider(["Vast.ai"])
    load = provider_load()
    vast_inflight, vast_cap = load["Vast.ai"]
    assert vast_inflight == 2
    assert vast_cap == cap_for("Vast.ai")


def test_release_unknown_provider_safe() -> None:
    # Shouldn't crash even if provider never had inflight
    release("SomeUnknownProvider")
    release("Vast.ai")  # Was 0; shouldn't go negative
    assert provider_load()["Vast.ai"][0] == 0


def test_empty_preferred_provider_list_returns_none() -> None:
    enqueue("job-x", PRIO_NORMAL)
    item = dequeue_for_provider([])
    assert item is None
    # Item is still in the queue
    assert queue_depth() == 1
