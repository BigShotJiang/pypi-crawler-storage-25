"""
VaultLayer — Flow A/B/C Feature Coverage Tests

Tests for features added to close the Flow A/B gaps and Flow C implementation.
Covers: per-leg tier markup, dynamic tier classification, recovery hierarchy,
hop origin chain, back-hop retry/cancel, billing freeze, invoice per-leg tier,
storage validation, dynamic kill switch, job manifest generation.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import json
import asyncio
from datetime import datetime, timezone, timedelta
from unittest.mock import patch, MagicMock, AsyncMock

import pytest


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Per-Leg Tier Markup — get_leg_tier()
# ═══════════════════════════════════════════════════════════════════════════════

class TestGetLegTier:
    """Test compute_tiers.get_leg_tier() with all parameter combinations."""

    def test_standard_gpu_no_hop(self):
        from shared.compute_tiers import get_leg_tier
        tier, markup, label = get_leg_tier("A10G", is_hop_leg=False)
        assert tier == 1
        assert markup == 0.20
        assert label == "Standard"

    def test_scarcity_gpu_no_hop(self):
        from shared.compute_tiers import get_leg_tier
        tier, markup, label = get_leg_tier("H100_80GB_SXM", is_hop_leg=False)
        assert tier == 2
        assert markup == 0.30
        assert label == "Scarcity"

    def test_hop_leg_overrides_to_tier3(self):
        from shared.compute_tiers import get_leg_tier
        # Even a cheap GPU gets Tier 3 if it's a hop leg
        tier, markup, label = get_leg_tier("A10G", is_hop_leg=True)
        assert tier == 3
        assert markup == 0.40
        assert label == "Failover"

    def test_failover_enabled_overrides_to_tier3(self):
        from shared.compute_tiers import get_leg_tier
        # Failover enabled forces Tier 3 even on first leg
        tier, markup, label = get_leg_tier("A10G", is_hop_leg=False, failover_enabled=True)
        assert tier == 3
        assert markup == 0.40

    def test_failover_enabled_overrides_scarcity(self):
        from shared.compute_tiers import get_leg_tier
        # H100 is normally Tier 2 (30%), but failover bumps to Tier 3 (40%)
        tier, markup, label = get_leg_tier("H100_80GB_SXM", is_hop_leg=False, failover_enabled=True)
        assert tier == 3
        assert markup == 0.40

    def test_market_tier_override(self):
        from shared.compute_tiers import get_leg_tier
        # Market says this GPU is Tier 2, even though static set says Tier 1
        tier, markup, label = get_leg_tier("A10G", is_hop_leg=False, market_tier=2)
        assert tier == 2
        assert markup == 0.30

    def test_market_tier_1_override(self):
        from shared.compute_tiers import get_leg_tier
        # Market says Tier 1 for a GPU that's statically Tier 2
        tier, markup, label = get_leg_tier("H100_80GB_SXM", is_hop_leg=False, market_tier=1)
        assert tier == 1
        assert markup == 0.20

    def test_hop_leg_takes_priority_over_market_tier(self):
        from shared.compute_tiers import get_leg_tier
        # is_hop_leg=True always wins
        tier, markup, _ = get_leg_tier("A10G", is_hop_leg=True, market_tier=1)
        assert tier == 3
        assert markup == 0.40

    def test_new_gpu_h200_is_scarcity(self):
        from shared.compute_tiers import get_leg_tier
        tier, markup, label = get_leg_tier("H200", is_hop_leg=False)
        assert tier == 2
        assert label == "Scarcity"

    def test_new_gpu_b200_is_scarcity(self):
        from shared.compute_tiers import get_leg_tier
        tier, markup, _ = get_leg_tier("B200", is_hop_leg=False)
        assert tier == 2

    def test_new_gpu_a6000_is_standard(self):
        from shared.compute_tiers import get_leg_tier
        tier, markup, _ = get_leg_tier("A6000", is_hop_leg=False)
        assert tier == 1
        assert markup == 0.20

    def test_unknown_gpu_defaults_to_tier1(self):
        from shared.compute_tiers import get_leg_tier
        tier, markup, _ = get_leg_tier("FUTURE_GPU_XYZ", is_hop_leg=False)
        assert tier == 1


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Dynamic Tier Classification — classify_gpu_tier_from_market()
# ═══════════════════════════════════════════════════════════════════════════════

class TestDynamicTierClassification:

    def test_cheap_gpu_is_standard(self):
        from shared.compute_tiers import classify_gpu_tier_from_market
        tier, markup, label = classify_gpu_tier_from_market("A10G", median_price=1.50)
        assert tier == 1
        assert markup == 0.20
        assert label == "Standard"

    def test_expensive_gpu_is_scarcity(self):
        from shared.compute_tiers import classify_gpu_tier_from_market
        tier, markup, label = classify_gpu_tier_from_market("H100_80GB_SXM", median_price=8.00)
        assert tier == 2
        assert markup == 0.30
        assert label == "Scarcity"

    def test_threshold_boundary_below(self):
        from shared.compute_tiers import classify_gpu_tier_from_market, SCARCITY_PRICE_THRESHOLD
        tier, _, _ = classify_gpu_tier_from_market("X", median_price=SCARCITY_PRICE_THRESHOLD - 0.01)
        assert tier == 1

    def test_threshold_boundary_at(self):
        from shared.compute_tiers import classify_gpu_tier_from_market, SCARCITY_PRICE_THRESHOLD
        tier, _, _ = classify_gpu_tier_from_market("X", median_price=SCARCITY_PRICE_THRESHOLD)
        assert tier == 2

    def test_low_availability_triggers_scarcity(self):
        from shared.compute_tiers import classify_gpu_tier_from_market
        # Cheap GPU but unavailable on >50% of providers → Scarcity
        tier, _, _ = classify_gpu_tier_from_market("A10G", median_price=1.00, low_availability_ratio=0.6)
        assert tier == 2

    def test_high_availability_stays_standard(self):
        from shared.compute_tiers import classify_gpu_tier_from_market
        tier, _, _ = classify_gpu_tier_from_market("A10G", median_price=1.00, low_availability_ratio=0.3)
        assert tier == 1

    def test_scarcity_threshold_is_five_dollars(self):
        from shared.compute_tiers import SCARCITY_PRICE_THRESHOLD
        assert SCARCITY_PRICE_THRESHOLD == 5.00


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Recovery Hierarchy Enum — classify_recovery_tier()
# ═══════════════════════════════════════════════════════════════════════════════

class TestRecoveryHierarchy:

    def test_same_gpu_same_provider_same_region(self):
        from shared.recovery_tiers import classify_recovery_tier, RecoveryTier
        tier = classify_recovery_tier(
            source_provider="lambda_labs", target_provider="lambda_labs",
            source_gpu="H100_80GB_SXM", target_gpu="H100_80GB_SXM",
            same_region=True,
        )
        assert tier == RecoveryTier.SAME_GPU_SAME_PROVIDER_SAME_REGION
        assert int(tier) == 1

    def test_same_gpu_same_provider_cross_region(self):
        from shared.recovery_tiers import classify_recovery_tier, RecoveryTier
        tier = classify_recovery_tier(
            source_provider="aws", target_provider="aws",
            source_gpu="H100_80GB_SXM", target_gpu="H100_80GB_SXM",
            same_region=False,
        )
        assert tier == RecoveryTier.SAME_GPU_SAME_PROVIDER_CROSS_REGION
        assert int(tier) == 2

    def test_same_gpu_cross_provider(self):
        from shared.recovery_tiers import classify_recovery_tier, RecoveryTier
        tier = classify_recovery_tier(
            source_provider="aws", target_provider="lambda_labs",
            source_gpu="H100_80GB_SXM", target_gpu="H100_80GB_SXM",
            same_region=False,
        )
        assert tier == RecoveryTier.SAME_GPU_CROSS_PROVIDER
        assert int(tier) == 3

    def test_next_best_gpu_same_provider(self):
        from shared.recovery_tiers import classify_recovery_tier, RecoveryTier
        tier = classify_recovery_tier(
            source_provider="aws", target_provider="aws",
            source_gpu="H100_80GB_SXM", target_gpu="A100_80GB_SXM",
            same_region=False,
        )
        assert tier == RecoveryTier.NEXT_BEST_GPU_SAME_PROVIDER
        assert int(tier) == 4

    def test_next_best_gpu_cross_provider(self):
        from shared.recovery_tiers import classify_recovery_tier, RecoveryTier
        tier = classify_recovery_tier(
            source_provider="aws", target_provider="lambda_labs",
            source_gpu="H100_80GB_SXM", target_gpu="A100_80GB_SXM",
            same_region=False,
        )
        assert tier == RecoveryTier.NEXT_BEST_GPU_CROSS_PROVIDER
        assert int(tier) == 5

    def test_tier_ordering(self):
        from shared.recovery_tiers import RecoveryTier
        assert RecoveryTier.SAME_GPU_SAME_PROVIDER_SAME_REGION < RecoveryTier.SAME_GPU_CROSS_PROVIDER
        assert RecoveryTier.SAME_GPU_CROSS_PROVIDER < RecoveryTier.NEXT_BEST_GPU_SAME_PROVIDER
        assert RecoveryTier.NEXT_BEST_GPU_SAME_PROVIDER < RecoveryTier.NEXT_BEST_GPU_CROSS_PROVIDER

    def test_all_five_tiers_exist(self):
        from shared.recovery_tiers import RecoveryTier
        assert len(RecoveryTier) == 5

    def test_labels_defined_for_all_tiers(self):
        from shared.recovery_tiers import RecoveryTier, RECOVERY_TIER_LABELS
        for tier in RecoveryTier:
            assert tier in RECOVERY_TIER_LABELS
            assert len(RECOVERY_TIER_LABELS[tier]) > 0


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Hop Origin Chain — migrated_from_run_id
# ═══════════════════════════════════════════════════════════════════════════════

class TestHopOriginChain:

    def test_open_run_accepts_migrated_from_run_id(self):
        """open_run() should accept migrated_from_run_id parameter."""
        from shared.job_run_logger import open_run
        import inspect
        sig = inspect.signature(open_run)
        assert "migrated_from_run_id" in sig.parameters

    def test_open_run_includes_field_in_row(self):
        """When migrated_from_run_id is provided, it should appear in the DB insert."""
        from shared.job_run_logger import open_run
        mock_db = MagicMock()
        mock_db.table.return_value.insert.return_value.execute.return_value = MagicMock(
            data=[{"run_id": "test-run-123"}]
        )
        with patch("shared.job_run_logger._get_db", return_value=mock_db):
            run_id = open_run(
                job_id="job-1", provider="aws", gpu_type="H100_80GB_SXM",
                instance_id="i-abc", provisioned_at=datetime.now(timezone.utc),
                rate_per_hr=2.50, migrated_from_run_id="prev-run-456",
            )
        # Check the insert call included migrated_from_run_id
        call_args = mock_db.table.return_value.insert.call_args
        row = call_args[0][0] if call_args[0] else call_args[1].get("row", {})
        assert row.get("migrated_from_run_id") == "prev-run-456"

    def test_open_run_omits_field_when_none(self):
        """When migrated_from_run_id is None, it should NOT appear in the row."""
        from shared.job_run_logger import open_run
        mock_db = MagicMock()
        mock_db.table.return_value.insert.return_value.execute.return_value = MagicMock(
            data=[{"run_id": "test-run-789"}]
        )
        with patch("shared.job_run_logger._get_db", return_value=mock_db):
            open_run(
                job_id="job-2", provider="aws", gpu_type="A10G",
                instance_id="i-def", provisioned_at=datetime.now(timezone.utc),
                rate_per_hr=1.00,
            )
        call_args = mock_db.table.return_value.insert.call_args
        row = call_args[0][0] if call_args[0] else call_args[1].get("row", {})
        assert "migrated_from_run_id" not in row

    def test_migration_sql_has_column(self):
        """0013_hop_chain.sql should add migrated_from_run_id column."""
        sql_path = os.path.join(os.path.dirname(__file__), '..', 'schema', 'migrations', '0013_hop_chain.sql')
        with open(sql_path) as f:
            sql = f.read()
        assert "migrated_from_run_id" in sql
        assert "REFERENCES job_runs(run_id)" in sql


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Back-Hop Retry/Cancel
# ═══════════════════════════════════════════════════════════════════════════════

class TestBackHopRetryCancel:

    def test_migration_sql_has_cancel_fields(self):
        """0014 migration should add gpu_hop_cancelled and retry columns."""
        sql_path = os.path.join(os.path.dirname(__file__), '..', 'schema', 'migrations', '0014_gpu_hop_retry_cancel.sql')
        with open(sql_path) as f:
            sql = f.read()
        assert "gpu_hop_cancelled" in sql
        assert "gpu_hop_attempts" in sql
        assert "gpu_hop_last_check_at" in sql
        assert "gpu_hop_cancel_reason" in sql

    def test_cancel_endpoint_exists(self):
        """pricing_routes should have a gpu-hop/cancel endpoint."""
        import importlib
        from api import pricing_routes
        source = open(pricing_routes.__file__).read()
        assert "gpu-hop/cancel" in source
        assert "HopCancelRequest" in source

    def test_hop_watcher_filters_cancelled(self):
        """_check_gpu_hops query should filter out cancelled hops."""
        import agents.pricing.agent as _mod
        source = open(_mod.__file__).read()
        assert 'gpu_hop_cancelled' in source

    def test_24h_consent_ttl_constant(self):
        """PricingAgent should have a 24h consent TTL."""
        from agents.pricing.agent import PricingAgent
        assert hasattr(PricingAgent, "_GPU_HOP_CONSENT_TTL_SECS")
        assert PricingAgent._GPU_HOP_CONSENT_TTL_SECS == 86400


# ═══════════════════════════════════════════════════════════════════════════════
# 6. Billing Freeze
# ═══════════════════════════════════════════════════════════════════════════════

class TestBillingFreeze:

    def test_job_model_has_billing_frozen_at(self):
        from shared.models import Job
        job = Job(
            job_id="test", user_id="u1", name="t", provider="aws",
            gpu_type="H100_80GB_SXM", instance_id="i-1", region="us-east-1",
        )
        assert hasattr(job, "billing_frozen_at")
        assert job.billing_frozen_at is None

    def test_job_model_has_failover_fields(self):
        from shared.models import Job
        job = Job(
            job_id="test", user_id="u1", name="t", provider="aws",
            gpu_type="H100_80GB_SXM", instance_id="i-1", region="us-east-1",
            failover_enabled=True, managed_flow=True,
        )
        assert job.failover_enabled is True
        assert job.managed_flow is True
        assert job.billing_frozen_at is None

    def test_migration_sql_has_billing_frozen_at(self):
        """0015 migration should add billing_frozen_at column."""
        sql_path = os.path.join(os.path.dirname(__file__), '..', 'schema', 'migrations', '0015_flow_c_managed.sql')
        with open(sql_path) as f:
            sql = f.read()
        assert "billing_frozen_at" in sql
        assert "failover_enabled" in sql
        assert "managed_flow" in sql

    def test_credit_burn_skips_frozen_jobs(self):
        """OrchestrationAgent._credit_burn_loop should skip jobs with billing_frozen_at set."""
        source_path = os.path.join(os.path.dirname(__file__), '..', 'src', 'agents', 'orchestration', 'agent.py')
        with open(source_path) as f:
            source = f.read()
        assert "billing_frozen_at" in source


# ═══════════════════════════════════════════════════════════════════════════════
# 7. Invoice Per-Leg Tier
# ═══════════════════════════════════════════════════════════════════════════════

class TestInvoicePerLegTier:

    def test_invoice_uses_per_leg_margin_when_available(self):
        """_build_invoice should use vl_margin_pct from run if set."""
        from shared.invoice import _build_invoice

        runs = [
            {
                "run_id": "run-1", "provider": "lambda_labs", "gpu_type": "A10G",
                "instance_id": "i-1", "region": "us-west-2",
                "provisioned_at": "2026-01-01T00:00:00Z",
                "terminated_at": "2026-01-01T01:00:00Z",
                "billing_seconds": 3600, "rate_per_hr": 1.00,
                "status": "terminated", "vl_margin_pct": 0.20,
                "metadata": {"compute_tier": 1, "compute_tier_label": "Standard"},
            },
            {
                "run_id": "run-2", "provider": "coreweave", "gpu_type": "H100_80GB_SXM",
                "instance_id": "i-2", "region": "us-east-1",
                "provisioned_at": "2026-01-01T01:00:00Z",
                "terminated_at": "2026-01-01T02:00:00Z",
                "billing_seconds": 3600, "rate_per_hr": 2.50,
                "status": "completed", "vl_margin_pct": 0.40,
                "metadata": {"compute_tier": 3, "compute_tier_label": "Failover"},
            },
        ]
        billing_profile = {
            "billing_model": "cost_plus",
            "compute_markup_pct": 0.25,
            "storage_rate_per_gb": 0.020,
        }
        invoice = _build_invoice("job-1", "user-1", runs, billing_profile, storage_gb=0.0)

        legs = invoice["compute"]["legs"]
        assert len(legs) == 2

        # Leg 1: A10G at 20% markup (from vl_margin_pct)
        assert legs[0]["markup_pct"] == 0.20
        assert legs[0]["provider_raw_cost_usd"] == 1.00  # 1hr * $1/hr
        assert legs[0]["billed_usd"] == 1.20  # $1.00 * 1.20

        # Leg 2: H100 at 40% markup (from vl_margin_pct)
        assert legs[1]["markup_pct"] == 0.40
        assert legs[1]["provider_raw_cost_usd"] == 2.50  # 1hr * $2.50/hr
        assert legs[1]["billed_usd"] == 3.50  # $2.50 * 1.40

    def test_invoice_falls_back_to_job_tier_when_no_margin(self):
        """When vl_margin_pct is not set, invoice uses job-level tier."""
        from shared.invoice import _build_invoice

        runs = [{
            "run_id": "run-1", "provider": "aws", "gpu_type": "A10G",
            "instance_id": "i-1", "region": "us-east-1",
            "provisioned_at": "2026-01-01T00:00:00Z",
            "terminated_at": "2026-01-01T01:00:00Z",
            "billing_seconds": 3600, "rate_per_hr": 1.00,
            "status": "completed",
            # No vl_margin_pct set → falls back to job-level
        }]
        billing_profile = {
            "billing_model": "cost_plus",
            "compute_markup_pct": 0.25,
            "storage_rate_per_gb": 0.020,
        }
        invoice = _build_invoice("job-2", "user-1", runs, billing_profile, storage_gb=0.0)
        legs = invoice["compute"]["legs"]
        # Single leg, standard GPU → job-level Tier 1 (20%)
        assert legs[0]["billed_usd"] == 1.20

    def test_invoice_has_compute_tier_per_leg(self):
        """Each leg should have compute_tier and compute_tier_label fields."""
        from shared.invoice import _build_invoice

        runs = [{
            "run_id": "r1", "provider": "aws", "gpu_type": "H100_80GB_SXM",
            "instance_id": "i-1", "region": "us-east-1",
            "provisioned_at": "2026-01-01T00:00:00Z",
            "terminated_at": "2026-01-01T01:00:00Z",
            "billing_seconds": 3600, "rate_per_hr": 2.50,
            "status": "completed", "vl_margin_pct": 0.30,
            "metadata": {"compute_tier": 2, "compute_tier_label": "Scarcity"},
        }]
        billing_profile = {
            "billing_model": "cost_plus",
            "compute_markup_pct": 0.25,
            "storage_rate_per_gb": 0.020,
        }
        invoice = _build_invoice("job-3", "user-1", runs, billing_profile, storage_gb=0.0)
        leg = invoice["compute"]["legs"][0]
        assert "compute_tier" in leg
        assert "compute_tier_label" in leg
        assert leg["compute_tier"] == 2
        assert leg["compute_tier_label"] == "Scarcity"


# ═══════════════════════════════════════════════════════════════════════════════
# 8. Storage Write Validation
# ═══════════════════════════════════════════════════════════════════════════════

class TestStorageValidation:

    def test_s3_validator_exists(self):
        from cli.connect import _validate_s3_credentials
        import inspect
        sig = inspect.signature(_validate_s3_credentials)
        assert "bucket" in sig.parameters

    def test_gcs_validator_exists(self):
        from cli.connect import _validate_gcs_credentials
        import inspect
        sig = inspect.signature(_validate_gcs_credentials)
        assert "creds_path" in sig.parameters
        assert "bucket" in sig.parameters

    def test_azure_validator_exists(self):
        from cli.connect import _validate_azure_credentials
        import inspect
        sig = inspect.signature(_validate_azure_credentials)
        assert "conn_str" in sig.parameters
        assert "container" in sig.parameters

    def test_s3_validator_handles_missing_boto3(self):
        """Should not raise when boto3 is not importable."""
        with patch.dict("sys.modules", {"boto3": None}):
            # Re-import won't work easily, but we can test the function directly
            # by mocking the import inside it
            pass  # The function has try/except ImportError: pass

    def test_s3_validator_warns_on_bad_creds(self):
        """Should print warning, not raise, on invalid credentials."""
        from cli.connect import _validate_s3_credentials
        from unittest.mock import patch as _patch
        from click.testing import CliRunner
        # Mock boto3 to raise
        mock_boto3 = MagicMock()
        mock_boto3.client.return_value.get_caller_identity.side_effect = Exception("InvalidCreds")
        with _patch.dict("sys.modules", {"boto3": mock_boto3}):
            with _patch("botocore.exceptions.ClientError", Exception):
                # Should not raise — just warns
                _validate_s3_credentials("bad", "bad", "us-east-1", "", "")


# ═══════════════════════════════════════════════════════════════════════════════
# 9. Dynamic Kill Switch (10-Minute Threshold)
# ═══════════════════════════════════════════════════════════════════════════════

class TestDynamicKillSwitch:

    def test_kill_switch_uses_dynamic_threshold(self):
        """Burn endpoint should compute 10-min threshold from hourly rate."""
        source_path = os.path.join(os.path.dirname(__file__), '..', 'src', 'api', 'credits.py')
        with open(source_path) as f:
            source = f.read()
        assert "_ten_min_credits" in source
        assert "_dynamic_threshold" in source
        assert "max(EXHAUSTED_THRESHOLD" in source

    def test_10min_threshold_math(self):
        """At $6/hr: 10 min cost = int((10/60) * 6 * 100) = int(100.0) = 100 credits."""
        hourly_rate = 6.0
        ten_min_credits = int((10.0 / 60.0) * hourly_rate * 100)
        # (10/60) * 6 = 1.0; 1.0 * 100 = 100
        assert ten_min_credits == 100

    def test_10min_threshold_floor_at_exhausted(self):
        """At $0.10/hr: 10 min cost = 1.67 credits. Should use EXHAUSTED_THRESHOLD (50) instead."""
        hourly_rate = 0.10
        ten_min_credits = int((10.0 / 60.0) * hourly_rate * 100)
        exhausted_threshold = 50
        dynamic = max(exhausted_threshold, ten_min_credits)
        assert dynamic == exhausted_threshold  # Floor wins

    def test_10min_threshold_at_h100_rate(self):
        """H100 at $3/hr: 10 min = $0.50 = 50 credits. Matches EXHAUSTED_THRESHOLD."""
        hourly_rate = 3.0
        ten_min_credits = int((10.0 / 60.0) * hourly_rate * 100)
        assert ten_min_credits == 50


# ═══════════════════════════════════════════════════════════════════════════════
# 10. Job Manifest Generation
# ═══════════════════════════════════════════════════════════════════════════════

class TestJobManifest:

    def test_format_runtime(self):
        from shared.manifest import _format_runtime
        assert _format_runtime(3661) == "1 hour, 1 minute, 1 second"
        assert _format_runtime(7200) == "2 hours, 0 seconds"
        assert _format_runtime(90) == "1 minute, 30 seconds"
        assert _format_runtime(5) == "5 seconds"

    def test_generate_manifest_with_invoice(self):
        from shared.manifest import generate_manifest

        invoice = {
            "job_name": "test-train",
            "total_billing_seconds": 7261.0,
            "job_started_at": "2026-01-01T00:00:00Z",
            "job_completed_at": "2026-01-01T02:01:01Z",
            "billing_model": "cost_plus",
            "compute_tier_label": "Failover",
            "total_cost_usd": 15.50,
            "savings_usd": 8.00,
            "savings_pct": 34.0,
            "leg_count": 2,
            "framing": "You saved $8.00 (34%) vs AWS.",
            "compute": {
                "total_provider_cost_usd": 10.00,
                "total_orchestration_fee": 5.50,
                "total_billed_usd": 15.50,
                "aws_od_equivalent_usd": 23.50,
                "legs": [
                    {"compute_tier_label": "Standard", "provider_raw_cost_usd": 3.00},
                    {"compute_tier_label": "Failover", "provider_raw_cost_usd": 7.00},
                ],
                "migrations": [{"event": "Live Migration", "cost_usd": 0.0}],
            },
            "storage": {"cost_usd": 0.05},
        }

        # Mock the hop log fetch
        with patch("shared.manifest._fetch_hop_log", return_value=[
            {"event_type": "migration_started", "message": "Migrating to CoreWeave",
             "created_at": "2026-01-01T01:00:00Z"},
        ]):
            manifest = generate_manifest("job-1", "user-1", invoice=invoice)

        assert manifest["manifest_version"] == "1.0"
        assert manifest["job_id"] == "job-1"
        assert manifest["total_runtime"] == "2 hours, 1 minute, 1 second"
        assert manifest["total_cost_usd"] == 15.50
        assert manifest["net_credit_deduction"] == 1550
        assert manifest["storage_cost_usd"] == 0.05
        assert len(manifest["legs"]) == 2
        assert len(manifest["hop_log"]) == 1
        assert manifest["compute_tier"] == "Failover, Standard"
        assert manifest["summary"] == "You saved $8.00 (34%) vs AWS."

    def test_generate_manifest_handles_missing_invoice(self):
        """Should call create_invoice if no invoice provided, return error if it fails."""
        from shared.manifest import generate_manifest
        with patch("shared.invoice.create_invoice", return_value=None):
            result = generate_manifest("bad-job", "user-1")
        assert "error" in result


# ═══════════════════════════════════════════════════════════════════════════════
# 11. Spend Ledger — vl_margin_pct
# ═══════════════════════════════════════════════════════════════════════════════

class TestSpendLedgerMargin:

    def test_record_provision_accepts_vl_margin_pct(self):
        from shared.spend import record_provision
        import inspect
        sig = inspect.signature(record_provision)
        assert "vl_margin_pct" in sig.parameters

    def test_record_provision_includes_margin_in_row(self):
        from shared.spend import record_provision
        mock_db = MagicMock()
        mock_db.table.return_value.insert.return_value.execute.return_value = MagicMock(
            data=[{"id": "spend-123"}]
        )
        with patch("shared.spend._get_db", return_value=mock_db):
            record_provision(
                job_id="j1", provider="aws", gpu_type="H100_80GB_SXM",
                instance_id="i-1", provisioned_at=datetime.now(timezone.utc),
                rate_per_hr=2.50, vl_margin_pct=0.30,
            )
        call_args = mock_db.table.return_value.insert.call_args
        row = call_args[0][0]
        assert row["vl_margin_pct"] == 0.30

    def test_record_provision_omits_margin_when_none(self):
        from shared.spend import record_provision
        mock_db = MagicMock()
        mock_db.table.return_value.insert.return_value.execute.return_value = MagicMock(
            data=[{"id": "spend-456"}]
        )
        with patch("shared.spend._get_db", return_value=mock_db):
            record_provision(
                job_id="j2", provider="aws", gpu_type="A10G",
                instance_id="i-2", provisioned_at=datetime.now(timezone.utc),
                rate_per_hr=1.00,
            )
        call_args = mock_db.table.return_value.insert.call_args
        row = call_args[0][0]
        assert "vl_margin_pct" not in row


# ═══════════════════════════════════════════════════════════════════════════════
# 12. Fallback Ladder
# ═══════════════════════════════════════════════════════════════════════════════

class TestFallbackLadder:

    def test_ladder_h100_falls_to_a100(self):
        from agents.broker.agent import BrokerAgent
        from shared.models import GPUType
        assert BrokerAgent._FALLBACK_LADDER[GPUType.H100_80GB_SXM] == GPUType.A100_80GB_SXM
        assert BrokerAgent._FALLBACK_LADDER[GPUType.H100_80GB_PCIE] == GPUType.A100_80GB_SXM
        assert BrokerAgent._FALLBACK_LADDER[GPUType.H100_80GB_NVL] == GPUType.A100_80GB_SXM

    def test_ladder_h200_b200_fall_to_a100(self):
        from agents.broker.agent import BrokerAgent
        from shared.models import GPUType
        assert BrokerAgent._FALLBACK_LADDER[GPUType.H200] == GPUType.A100_80GB_SXM
        assert BrokerAgent._FALLBACK_LADDER[GPUType.B200] == GPUType.A100_80GB_SXM

    def test_ladder_a100_falls_to_l40s(self):
        from agents.broker.agent import BrokerAgent
        from shared.models import GPUType
        assert BrokerAgent._FALLBACK_LADDER[GPUType.A100_80GB_SXM] == GPUType.L40S
        assert BrokerAgent._FALLBACK_LADDER[GPUType.A100_40GB] == GPUType.L40S

    def test_ladder_l40s_falls_to_a6000(self):
        from agents.broker.agent import BrokerAgent
        from shared.models import GPUType
        assert BrokerAgent._FALLBACK_LADDER[GPUType.L40S] == GPUType.A6000

    def test_ladder_a6000_has_no_fallback(self):
        from agents.broker.agent import BrokerAgent
        from shared.models import GPUType
        assert GPUType.A6000 not in BrokerAgent._FALLBACK_LADDER

    def test_get_fallback_gpu_returns_next(self):
        from agents.broker.agent import BrokerAgent
        from shared.models import GPUType
        broker = BrokerAgent.__new__(BrokerAgent)
        assert broker._get_fallback_gpu(GPUType.H100_80GB_SXM) == GPUType.A100_80GB_SXM
        assert broker._get_fallback_gpu(GPUType.A100_80GB_SXM) == GPUType.L40S
        assert broker._get_fallback_gpu(GPUType.L40S) == GPUType.A6000
        assert broker._get_fallback_gpu(GPUType.A6000) is None

    def test_identical_scan_timeout_is_60s(self):
        from agents.broker.agent import BrokerAgent
        assert BrokerAgent._IDENTICAL_SCAN_TIMEOUT_SECS == 60


# ═══════════════════════════════════════════════════════════════════════════════
# 13. GPU Type Enum Completeness
# ═══════════════════════════════════════════════════════════════════════════════

class TestGPUTypes:

    def test_h200_exists(self):
        from shared.models import GPUType
        assert GPUType.H200.value == "H200"

    def test_b200_exists(self):
        from shared.models import GPUType
        assert GPUType.B200.value == "B200"

    def test_a6000_exists(self):
        from shared.models import GPUType
        assert GPUType.A6000.value == "A6000"

    def test_aws_od_rates_include_new_gpus(self):
        from shared.compute_tiers import AWS_OD_RATES
        assert "H200" in AWS_OD_RATES
        assert "B200" in AWS_OD_RATES
        assert "A6000" in AWS_OD_RATES
        assert AWS_OD_RATES["H200"] > 0
        assert AWS_OD_RATES["B200"] > 0


# ═══════════════════════════════════════════════════════════════════════════════
# 14. Minimum Balance — is_sufficient_for_flow
# ═══════════════════════════════════════════════════════════════════════════════

class TestMinimumBalance:

    def test_min_balance_standard(self):
        from shared.credits import MIN_BALANCE_TO_START_USD
        assert MIN_BALANCE_TO_START_USD == 5.00

    def test_min_balance_managed(self):
        from shared.credits import MIN_BALANCE_MANAGED_USD
        assert MIN_BALANCE_MANAGED_USD == 5.00
