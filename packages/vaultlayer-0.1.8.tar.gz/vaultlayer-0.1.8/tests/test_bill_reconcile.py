"""Tier-1 tests for api/bill_reconcile.py — the daily AWS bill reconciliation.

Covers every behavior a customer-billing engineer would ask about:
  * CE query shape matches AWS's recommended pattern
  * Pagination is drained (NextPageToken followed)
  * Only rows with provider_billed_usd IS NULL get updated (idempotency)
  * Drift > threshold writes audit_status=drift_flagged to metadata
  * Drift ≤ threshold leaves metadata untouched
  * Returns a summary object (not just side effects)
  * CE returning empty → no-op, no crash
  * Hourly cost buckets sum per-instance correctly

Tests run in <1 sec. No real AWS call.
"""
from __future__ import annotations

from datetime import date
from unittest.mock import MagicMock

import pytest

from api.bill_reconcile import reconcile_aws_day, ReconcileSummary


# ─────────────────────────────────────────────────────────────────────────────
# Fake CE client + Supabase stub
# ─────────────────────────────────────────────────────────────────────────────

def _make_ce(pages: list[dict]):
    """Build a fake boto3 ce client that returns `pages` in order.

    Each page is a dict with keys: ResultsByTime, [NextPageToken].
    """
    ce = MagicMock()
    seq = iter(pages)
    def _call(**kwargs):
        return next(seq)
    ce.get_cost_and_usage_with_resources.side_effect = _call
    return ce


def _group(instance_id: str, cost: float):
    return {
        "Keys": [instance_id],
        "Metrics": {"UnblendedCost": {"Amount": str(cost), "Unit": "USD"}},
    }


def _result(groups: list[dict]):
    return {"TimePeriod": {"Start": "x", "End": "y"}, "Groups": groups}


class _FakeDB:
    """Minimal Supabase stub that records writes + returns controlled reads."""
    def __init__(self, rows: dict[str, dict]):
        self.rows = rows           # instance_id -> row_dict
        self.updates: list[dict] = []
        self.select_calls: list[str] = []

    def table(self, name):
        assert name == "job_runs"
        return _TableOp(self)


class _TableOp:
    def __init__(self, db):
        self.db = db
        self._filters: dict = {}
        self._update_payload = None
        self._select_cols = None

    def update(self, payload):
        self._update_payload = payload
        return self

    def select(self, cols):
        self._select_cols = cols
        return self

    def eq(self, col, val):
        self._filters[col] = val
        return self

    def is_(self, col, val):
        self._filters[f"{col}_is"] = val
        return self

    def limit(self, n):
        return self

    def execute(self):
        inst = self._filters.get("instance_id")
        run_id = self._filters.get("run_id")
        row = None
        if inst:
            row = self.db.rows.get(inst)
        elif run_id:
            row = next((r for r in self.db.rows.values() if r.get("run_id") == run_id), None)

        if self._update_payload is not None:
            # Only update if filter "provider_billed_usd_is == null" and the
            # row's provider_billed_usd is None, matching prod WHERE clause.
            if self._filters.get("provider_billed_usd_is") == "null":
                if row and row.get("provider_billed_usd") is None:
                    row.update(self._update_payload)
                    self.db.updates.append({"instance_id": inst, **self._update_payload})
                    return MagicMock(data=[row])
                return MagicMock(data=[])
            # Generic update (metadata writes via run_id filter)
            if row:
                row.update(self._update_payload)
                self.db.updates.append({"run_id": run_id or inst, **self._update_payload})
                return MagicMock(data=[row])
            return MagicMock(data=[])

        if self._select_cols:
            return MagicMock(data=[row]) if row else MagicMock(data=[])
        return MagicMock(data=[])


# ─────────────────────────────────────────────────────────────────────────────
# Tests
# ─────────────────────────────────────────────────────────────────────────────

def test_single_page_updates_matching_rows():
    ce = _make_ce([{
        "ResultsByTime": [_result([_group("i-aaa", 0.35), _group("i-bbb", 0.12)])],
        # no NextPageToken → done after first page
    }])
    db = _FakeDB({
        "i-aaa": {"run_id": "run-1", "instance_id": "i-aaa",
                  "provider_billed_usd": None, "provider": "aws",
                  "billing_seconds": 60, "rate_per_hr": 0.30,
                  "estimated_cost_usd": 0.005, "metadata": {}},
        "i-bbb": {"run_id": "run-2", "instance_id": "i-bbb",
                  "provider_billed_usd": None, "provider": "aws",
                  "billing_seconds": 30, "rate_per_hr": 0.30,
                  "estimated_cost_usd": 0.0025, "metadata": {}},
    })

    summary = reconcile_aws_day(
        target_day=date(2026, 4, 15), ce_client=ce, db=db,
    )

    assert summary.instances_returned == 2
    assert summary.rows_updated == 2
    assert summary.ce_api_calls == 1
    assert db.rows["i-aaa"]["provider_billed_usd"] == 0.35
    assert db.rows["i-bbb"]["provider_billed_usd"] == 0.12


def test_pagination_is_drained():
    """NextPageToken continuation must be followed until drained."""
    ce = _make_ce([
        {"ResultsByTime": [_result([_group("i-p1", 0.10)])], "NextPageToken": "tok-2"},
        {"ResultsByTime": [_result([_group("i-p2", 0.20)])], "NextPageToken": "tok-3"},
        {"ResultsByTime": [_result([_group("i-p3", 0.30)])]},  # terminal page
    ])
    db = _FakeDB({
        inst: {"run_id": inst, "instance_id": inst, "provider_billed_usd": None,
               "provider": "aws", "billing_seconds": 60, "rate_per_hr": 0.30,
               "estimated_cost_usd": 0.005, "metadata": {}}
        for inst in ("i-p1", "i-p2", "i-p3")
    })

    summary = reconcile_aws_day(target_day=date(2026, 4, 15), ce_client=ce, db=db)
    assert summary.ce_api_calls == 3, "must paginate until NextPageToken is None"
    assert summary.rows_updated == 3


def test_idempotency_skips_rows_already_reconciled():
    """If provider_billed_usd is already set (e.g. from a prior run or RunPod-
    style provider API), we must NOT overwrite it."""
    ce = _make_ce([{"ResultsByTime": [_result([_group("i-keep", 0.50)])]}])
    db = _FakeDB({
        "i-keep": {"run_id": "r", "instance_id": "i-keep",
                   "provider_billed_usd": 0.99,  # already set
                   "provider": "aws", "billing_seconds": 60,
                   "rate_per_hr": 0.30, "estimated_cost_usd": 0.005,
                   "metadata": {}},
    })
    summary = reconcile_aws_day(target_day=date(2026, 4, 15), ce_client=ce, db=db)
    assert summary.rows_updated == 0
    assert db.rows["i-keep"]["provider_billed_usd"] == 0.99  # untouched


def test_drift_above_threshold_flags_metadata():
    """OVERCHARGE > 25% must set audit_status=drift_flagged in metadata."""
    # estimated = $0.10, actual = $0.20 → 100% drift → flagged
    ce = _make_ce([{"ResultsByTime": [_result([_group("i-drift", 0.20)])]}])
    db = _FakeDB({
        "i-drift": {"run_id": "run-drift", "instance_id": "i-drift",
                    "provider_billed_usd": None, "provider": "aws",
                    "billing_seconds": 360, "rate_per_hr": 1.00,
                    "estimated_cost_usd": 0.10, "metadata": {}},
    })
    summary = reconcile_aws_day(target_day=date(2026, 4, 15), ce_client=ce, db=db)
    assert summary.drifts_flagged == 1
    meta = db.rows["i-drift"]["metadata"]
    assert meta["audit_status"] == "drift_flagged"
    assert meta["audit_kind"] == "OVERCHARGE"
    assert abs(meta["audit_delta_pct"] - 1.0) < 0.01
    assert "audit_at" in meta


def test_drift_below_threshold_leaves_metadata_clean():
    """Drift within ±10% = in normal rounding band, no flag."""
    # estimated = $0.10, actual = $0.105 → 5% drift → within tolerance, not flagged
    ce = _make_ce([{"ResultsByTime": [_result([_group("i-ok", 0.105)])]}])
    db = _FakeDB({
        "i-ok": {"run_id": "run-ok", "instance_id": "i-ok",
                 "provider_billed_usd": None, "provider": "aws",
                 "billing_seconds": 360, "rate_per_hr": 1.00,
                 "estimated_cost_usd": 0.10, "metadata": {"foo": "bar"}},
    })
    summary = reconcile_aws_day(target_day=date(2026, 4, 15), ce_client=ce, db=db)
    assert summary.drifts_flagged == 0
    assert db.rows["i-ok"]["metadata"] == {"foo": "bar"}


def test_empty_ce_response_is_noop():
    """CE returning no results should complete cleanly with zeros."""
    ce = _make_ce([{"ResultsByTime": [_result([])]}])
    db = _FakeDB({})
    summary = reconcile_aws_day(target_day=date(2026, 4, 15), ce_client=ce, db=db)
    assert summary.instances_returned == 0
    assert summary.rows_updated == 0
    assert summary.drifts_flagged == 0


def test_hourly_buckets_sum_per_instance():
    """Multi-hour instance appears in multiple ResultsByTime entries — must sum."""
    ce = _make_ce([{
        "ResultsByTime": [
            _result([_group("i-long", 0.10)]),  # hour 1
            _result([_group("i-long", 0.12)]),  # hour 2
            _result([_group("i-long", 0.08)]),  # hour 3
        ],
    }])
    db = _FakeDB({
        "i-long": {"run_id": "run-long", "instance_id": "i-long",
                   "provider_billed_usd": None, "provider": "aws",
                   "billing_seconds": 10800, "rate_per_hr": 0.10,
                   "estimated_cost_usd": 0.30, "metadata": {}},
    })
    summary = reconcile_aws_day(target_day=date(2026, 4, 15), ce_client=ce, db=db)
    assert db.rows["i-long"]["provider_billed_usd"] == 0.30, \
        "three hourly buckets must sum to 0.30"


def test_non_ec2_resource_ids_filtered_out():
    """CE occasionally returns non-i-xxx resources if tag matches broadly —
    we should ignore them."""
    ce = _make_ce([{
        "ResultsByTime": [_result([
            _group("i-real", 0.25),
            _group("vol-12345", 0.02),   # EBS volume — ignore
            _group("nat-67890", 0.50),   # NAT — ignore
        ])],
    }])
    db = _FakeDB({
        "i-real": {"run_id": "r", "instance_id": "i-real",
                   "provider_billed_usd": None, "provider": "aws",
                   "billing_seconds": 60, "rate_per_hr": 0.30,
                   "estimated_cost_usd": 0.005, "metadata": {}},
    })
    summary = reconcile_aws_day(target_day=date(2026, 4, 15), ce_client=ce, db=db)
    assert summary.instances_returned == 1, "only i-* resources count"
    assert summary.rows_updated == 1


def test_ce_query_shape_matches_aws_recommendation():
    """Verify the CE call uses the exact shape AWS support told us to use:
      - SERVICE = Amazon Elastic Compute Cloud - Compute
      - Tags: VaultLayerJob STARTS_WITH ""
      - GroupBy: RESOURCE_ID
      - Metric: UnblendedCost
      - Granularity: HOURLY
    """
    captured_kwargs = {}
    ce = MagicMock()
    def _capture(**kwargs):
        captured_kwargs.update(kwargs)
        return {"ResultsByTime": [_result([])]}
    ce.get_cost_and_usage_with_resources.side_effect = _capture

    reconcile_aws_day(target_day=date(2026, 4, 15), ce_client=ce, db=_FakeDB({}))

    assert captured_kwargs["Granularity"] == "HOURLY"
    assert captured_kwargs["Metrics"] == ["UnblendedCost"]
    assert captured_kwargs["GroupBy"] == [{"Type": "DIMENSION", "Key": "RESOURCE_ID"}]
    flt = captured_kwargs["Filter"]["And"]
    service_filter = next(f for f in flt if "Dimensions" in f)
    assert service_filter["Dimensions"]["Values"] == ["Amazon Elastic Compute Cloud - Compute"]
    tag_filter = next(f for f in flt if "Tags" in f)
    assert tag_filter["Tags"]["Key"] == "VaultLayerJob"
    assert tag_filter["Tags"]["MatchOptions"] == ["STARTS_WITH"]


def test_ce_exception_returns_error_summary():
    """CE errors (throttle, quota, creds) shouldn't crash — return error in summary."""
    ce = MagicMock()
    ce.get_cost_and_usage_with_resources.side_effect = Exception("ThrottlingException")
    summary = reconcile_aws_day(target_day=date(2026, 4, 15), ce_client=ce, db=_FakeDB({}))
    assert summary.error is not None
    assert "ThrottlingException" in summary.error


def test_summary_serializable_as_dict():
    """admin endpoint will return this via JSON — must round-trip clean."""
    ce = _make_ce([{"ResultsByTime": [_result([])]}])
    summary = reconcile_aws_day(target_day=date(2026, 4, 15), ce_client=ce, db=_FakeDB({}))
    d = summary.as_dict()
    import json
    json.dumps(d)  # will raise if non-serializable
    assert d["queried_day"] == "2026-04-15"
