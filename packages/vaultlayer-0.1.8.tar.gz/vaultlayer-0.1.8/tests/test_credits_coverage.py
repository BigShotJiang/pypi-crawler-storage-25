"""
Coverage tests for shared/credits.py — CreditBalance, CreditLedger, and constants.
Uses a mocked async Redis client to avoid network dependencies.
"""
import pytest
from unittest.mock import AsyncMock, MagicMock

from shared.credits import (
    CreditBalance, CreditEventType, CreditLedger,
    MIN_BALANCE_TO_START_USD, LOW_BALANCE_THRESHOLD_USD,
    GRACE_AMOUNT_USD, BURN_INTERVAL_SECONDS,
)

def estimate_job_cost(hourly_rate_usd, estimated_hours=2.0):
    return CreditLedger.estimate_job_cost(hourly_rate_usd, estimated_hours)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_redis(balance=0.0, reserved=0.0, spent=0.0, hget_val=None):
    """Return a mock async Redis client with preset values."""
    r = AsyncMock()

    async def _get(key):
        if "balance" in key:
            return str(balance) if balance else None
        if "reserved" in key and "reservations" not in key:
            return str(reserved) if reserved else None
        if "spent" in key:
            return str(spent) if spent else None
        if "payment" in key:
            return None  # idempotency key not set
        return None

    r.get = AsyncMock(side_effect=_get)
    r.incrbyfloat = AsyncMock(return_value=0.0)
    r.set = AsyncMock(return_value=True)
    r.hget = AsyncMock(return_value=str(hget_val) if hget_val is not None else None)
    r.hset = AsyncMock(return_value=1)
    r.hdel = AsyncMock(return_value=1)
    r.xadd = AsyncMock(return_value="1234-0")
    return r


def _make_ledger(balance=0.0, reserved=0.0, spent=0.0, hget_val=None) -> CreditLedger:
    r = _make_redis(balance=balance, reserved=reserved, spent=spent, hget_val=hget_val)
    return CreditLedger(r, "user-test"), r


# ── Constants ─────────────────────────────────────────────────────────────────

class TestCreditConstants:
    def test_min_balance_to_start(self):
        assert MIN_BALANCE_TO_START_USD == 5.00

    def test_low_balance_threshold(self):
        assert LOW_BALANCE_THRESHOLD_USD == 10.00

    def test_grace_amount(self):
        assert GRACE_AMOUNT_USD == 0.50

    def test_burn_interval(self):
        assert BURN_INTERVAL_SECONDS == 60


# ── CreditEventType ───────────────────────────────────────────────────────────

class TestCreditEventType:
    def test_all_event_types_exist(self):
        types = {e.value for e in CreditEventType}
        assert "purchased" in types
        assert "reserved" in types
        assert "burned" in types
        assert "settled" in types
        assert "refunded" in types
        assert "released" in types


# ── CreditBalance ─────────────────────────────────────────────────────────────

class TestCreditBalance:
    def _make_balance(self, balance=100.0, reserved=10.0, spent=5.0):
        available = max(0.0, balance - reserved - spent)
        return CreditBalance(
            user_id="u1",
            balance_usd=balance,
            reserved_usd=reserved,
            spent_usd=spent,
            available_usd=available,
        )

    def test_is_sufficient_to_start_true(self):
        b = self._make_balance(balance=100.0, reserved=0.0, spent=0.0)
        assert b.is_sufficient_to_start is True

    def test_is_sufficient_to_start_false(self):
        b = self._make_balance(balance=4.0, reserved=0.0, spent=0.0)
        b = CreditBalance("u1", 4.0, 0.0, 0.0, 4.0)
        assert b.is_sufficient_to_start is False

    def test_is_low_true(self):
        b = CreditBalance("u1", 20.0, 15.0, 0.0, 5.0)
        assert b.is_low is True

    def test_is_low_false(self):
        b = CreditBalance("u1", 100.0, 0.0, 0.0, 100.0)
        assert b.is_low is False

    def test_is_exhausted_true(self):
        b = CreditBalance("u1", 10.0, 9.8, 0.0, 0.2)
        assert b.is_exhausted is True

    def test_is_exhausted_false(self):
        b = CreditBalance("u1", 100.0, 0.0, 0.0, 100.0)
        assert b.is_exhausted is False

    def test_available_at_grace_boundary(self):
        b = CreditBalance("u1", 10.0, 9.5, 0.0, 0.50)
        # exactly at grace — exhausted since available <= GRACE_AMOUNT_USD
        assert b.is_exhausted is True


# ── CreditLedger.get_balance() ────────────────────────────────────────────────

class TestCreditLedgerGetBalance:
    @pytest.mark.asyncio
    async def test_get_balance_returns_credit_balance(self):
        ledger, r = _make_ledger(balance=100.0, reserved=10.0, spent=5.0)
        bal = await ledger.get_balance()
        assert isinstance(bal, CreditBalance)

    @pytest.mark.asyncio
    async def test_get_balance_computes_available(self):
        ledger, r = _make_ledger(balance=100.0, reserved=10.0, spent=5.0)
        bal = await ledger.get_balance()
        assert bal.available_usd == pytest.approx(85.0)

    @pytest.mark.asyncio
    async def test_get_balance_zero_when_no_credits(self):
        ledger, r = _make_ledger()
        bal = await ledger.get_balance()
        assert bal.balance_usd == 0.0
        assert bal.available_usd == 0.0

    @pytest.mark.asyncio
    async def test_get_balance_available_not_negative(self):
        ledger, r = _make_ledger(balance=5.0, reserved=10.0, spent=0.0)
        bal = await ledger.get_balance()
        assert bal.available_usd == 0.0  # max(0, 5-10-0)


# ── CreditLedger.get_reservation() ───────────────────────────────────────────

class TestCreditLedgerGetReservation:
    @pytest.mark.asyncio
    async def test_get_reservation_zero_when_absent(self):
        ledger, r = _make_ledger()
        r.hget = AsyncMock(return_value=None)
        result = await ledger.get_reservation("job-1")
        assert result == 0.0

    @pytest.mark.asyncio
    async def test_get_reservation_returns_float(self):
        ledger, r = _make_ledger()
        r.hget = AsyncMock(return_value="12.50")
        result = await ledger.get_reservation("job-1")
        assert result == pytest.approx(12.50)


# ── CreditLedger.add_credits() ────────────────────────────────────────────────

class TestCreditLedgerAddCredits:
    @pytest.mark.asyncio
    async def test_add_credits_increments_balance(self):
        ledger, r = _make_ledger()
        await ledger.add_credits(50.0, stripe_payment_id="pi_abc")
        r.incrbyfloat.assert_called()
        key, amount = r.incrbyfloat.call_args[0]
        assert "balance" in key
        assert amount == 50.0

    @pytest.mark.asyncio
    async def test_add_credits_sets_idempotency_key(self):
        ledger, r = _make_ledger()
        await ledger.add_credits(50.0, stripe_payment_id="pi_abc")
        r.set.assert_called()
        key = r.set.call_args[0][0]
        assert "pi_abc" in key

    @pytest.mark.asyncio
    async def test_add_credits_raises_on_nonpositive_amount(self):
        ledger, _ = _make_ledger()
        with pytest.raises(ValueError, match="positive"):
            await ledger.add_credits(0.0, "pi_abc")

    @pytest.mark.asyncio
    async def test_add_credits_idempotent_on_duplicate_payment(self):
        ledger, r = _make_ledger()
        r.get = AsyncMock(return_value="1")  # already processed

        bal = await ledger.add_credits(50.0, "pi_duplicate")
        # Should NOT call incrbyfloat again
        r.incrbyfloat.assert_not_called()

    @pytest.mark.asyncio
    async def test_add_credits_writes_to_ledger(self):
        ledger, r = _make_ledger()
        await ledger.add_credits(50.0, "pi_abc")
        r.xadd.assert_called()


# ── CreditLedger.reserve() ────────────────────────────────────────────────────

class TestCreditLedgerReserve:
    @pytest.mark.asyncio
    async def test_reserve_returns_true_when_sufficient(self):
        ledger, r = _make_ledger(balance=100.0)
        result = await ledger.reserve("job-1", 10.0)
        assert result is True

    @pytest.mark.asyncio
    async def test_reserve_returns_false_when_insufficient(self):
        ledger, r = _make_ledger(balance=4.0)
        result = await ledger.reserve("job-1", 10.0)
        assert result is False

    @pytest.mark.asyncio
    async def test_reserve_increments_reserved_key(self):
        ledger, r = _make_ledger(balance=100.0)
        await ledger.reserve("job-1", 12.50)
        # At least one incrbyfloat on reserved key
        calls = [c for c in r.incrbyfloat.call_args_list if "reserved" in c[0][0] and "reservations" not in c[0][0]]
        assert len(calls) >= 1

    @pytest.mark.asyncio
    async def test_reserve_stores_per_job_hash(self):
        ledger, r = _make_ledger(balance=100.0)
        await ledger.reserve("job-1", 12.50)
        r.hset.assert_called()
        hset_key = r.hset.call_args[0][0]
        assert "reservations" in hset_key

    @pytest.mark.asyncio
    async def test_reserve_defaults_to_min_balance_when_zero(self):
        ledger, r = _make_ledger(balance=100.0)
        await ledger.reserve("job-1", 0.0)
        # Should have reserved MIN_BALANCE_TO_START_USD
        calls = [c for c in r.incrbyfloat.call_args_list if "reserved" in c[0][0] and "reservations" not in c[0][0]]
        assert any(c[0][1] == MIN_BALANCE_TO_START_USD for c in calls)


# ── CreditLedger.burn() ───────────────────────────────────────────────────────

class TestCreditLedgerBurn:
    @pytest.mark.asyncio
    async def test_burn_returns_credit_balance(self):
        ledger, r = _make_ledger(balance=100.0, hget_val=50.0)
        bal = await ledger.burn("job-1", 0.048)
        assert isinstance(bal, CreditBalance)

    @pytest.mark.asyncio
    async def test_burn_zero_is_noop(self):
        ledger, r = _make_ledger(balance=100.0)
        await ledger.burn("job-1", 0.0)
        r.incrbyfloat.assert_not_called()

    @pytest.mark.asyncio
    async def test_burn_normal_path_reduces_reservation(self):
        ledger, r = _make_ledger(balance=100.0, hget_val=50.0)
        await ledger.burn("job-1", 1.0)
        # hset called to update per-job reservation
        r.hset.assert_called()

    @pytest.mark.asyncio
    async def test_burn_overage_path_when_reservation_exhausted(self):
        ledger, r = _make_ledger(balance=100.0, hget_val=0.5)
        # burn 2.0 with only 0.5 reservation
        await ledger.burn("job-1", 2.0)
        # incrbyfloat should be called for spent key (overage)
        calls = [c for c in r.incrbyfloat.call_args_list if "spent" in c[0][0]]
        assert len(calls) >= 1

    @pytest.mark.asyncio
    async def test_burn_writes_to_ledger(self):
        ledger, r = _make_ledger(balance=100.0, hget_val=50.0)
        await ledger.burn("job-1", 0.5)
        r.xadd.assert_called()


# ── CreditLedger.settle() ─────────────────────────────────────────────────────

class TestCreditLedgerSettle:
    @pytest.mark.asyncio
    async def test_settle_releases_reservation(self):
        ledger, r = _make_ledger(balance=100.0, hget_val=12.50)
        await ledger.settle("job-1", 9.73)
        # Reserved key decremented
        calls = [c for c in r.incrbyfloat.call_args_list if "reserved" in c[0][0] and "reservations" not in c[0][0]]
        assert any(c[0][1] < 0 for c in calls)

    @pytest.mark.asyncio
    async def test_settle_deletes_reservation_hash_entry(self):
        ledger, r = _make_ledger(balance=100.0, hget_val=12.50)
        await ledger.settle("job-1", 9.73)
        r.hdel.assert_called()

    @pytest.mark.asyncio
    async def test_settle_writes_to_ledger(self):
        ledger, r = _make_ledger(balance=100.0, hget_val=12.50)
        await ledger.settle("job-1", 9.73)
        r.xadd.assert_called()

    @pytest.mark.asyncio
    async def test_settle_no_op_when_no_reservation(self):
        ledger, r = _make_ledger(balance=100.0, hget_val=None)
        # Should not crash even if there's no reservation
        await ledger.settle("job-1", 0.0)
        r.hdel.assert_not_called()


# ── CreditLedger.release() ────────────────────────────────────────────────────

class TestCreditLedgerRelease:
    @pytest.mark.asyncio
    async def test_release_decrements_reserved(self):
        ledger, r = _make_ledger(balance=100.0, hget_val=10.0)
        await ledger.release("job-1", "cancelled")
        calls = [c for c in r.incrbyfloat.call_args_list if "reserved" in c[0][0] and "reservations" not in c[0][0]]
        assert any(c[0][1] < 0 for c in calls)

    @pytest.mark.asyncio
    async def test_release_no_op_when_no_reservation(self):
        ledger, r = _make_ledger(balance=100.0, hget_val=None)
        await ledger.release("job-1")
        r.incrbyfloat.assert_not_called()

    @pytest.mark.asyncio
    async def test_release_returns_credit_balance(self):
        ledger, r = _make_ledger(balance=100.0, hget_val=10.0)
        bal = await ledger.release("job-1")
        assert isinstance(bal, CreditBalance)


# ── CreditLedger.refund() ─────────────────────────────────────────────────────

class TestCreditLedgerRefund:
    @pytest.mark.asyncio
    async def test_refund_increments_balance(self):
        ledger, r = _make_ledger(balance=50.0)
        await ledger.refund("job-1", 10.0, "provider failure")
        calls = [c for c in r.incrbyfloat.call_args_list if "balance" in c[0][0]]
        assert any(c[0][1] == 10.0 for c in calls)

    @pytest.mark.asyncio
    async def test_refund_writes_to_ledger(self):
        ledger, r = _make_ledger(balance=50.0)
        await ledger.refund("job-1", 10.0, "provider failure")
        r.xadd.assert_called()

    @pytest.mark.asyncio
    async def test_refund_returns_credit_balance(self):
        ledger, r = _make_ledger(balance=50.0)
        bal = await ledger.refund("job-1", 10.0, "SLA breach")
        assert isinstance(bal, CreditBalance)


# ── estimate_job_cost() static method ────────────────────────────────────────

class TestEstimateJobCost:
    def test_basic_estimate(self):
        cost = CreditLedger.estimate_job_cost(hourly_rate_usd=3.90, estimated_hours=2.0)
        expected = round(3.90 * 2.0 * 1.20, 2)
        assert cost == pytest.approx(expected)

    def test_default_two_hours(self):
        cost_explicit = CreditLedger.estimate_job_cost(3.90, 2.0)
        cost_default = CreditLedger.estimate_job_cost(3.90)
        assert cost_explicit == cost_default

    def test_includes_20_percent_buffer(self):
        cost = CreditLedger.estimate_job_cost(10.0, 1.0)
        assert cost == pytest.approx(12.0)

    def test_zero_hours(self):
        cost = CreditLedger.estimate_job_cost(10.0, 0.0)
        assert cost == 0.0

    def test_also_available_as_module_function(self):
        cost = estimate_job_cost(10.0, 1.0)
        assert cost == pytest.approx(12.0)


# ── Redis key schema ──────────────────────────────────────────────────────────

class TestCreditLedgerKeySchema:
    def test_balance_key_contains_user_id(self):
        ledger = CreditLedger(AsyncMock(), "user-abc123")
        assert "user-abc123" in ledger._balance_key

    def test_reserved_key_contains_user_id(self):
        ledger = CreditLedger(AsyncMock(), "user-abc123")
        assert "user-abc123" in ledger._reserved_key

    def test_reservations_key_is_hash(self):
        ledger = CreditLedger(AsyncMock(), "user-abc123")
        assert "reservations" in ledger._reservations_key

    def test_ledger_key_contains_user_id(self):
        ledger = CreditLedger(AsyncMock(), "user-abc123")
        assert "user-abc123" in ledger._ledger_key

    def test_spent_key_contains_user_id(self):
        ledger = CreditLedger(AsyncMock(), "user-abc123")
        assert "user-abc123" in ledger._spent_key
