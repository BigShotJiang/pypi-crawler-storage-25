"""Admin-invite-token onboarding flow — unit tests.

Covers:
  * Admin endpoint generates plaintext + stores hash
  * Redeem endpoint: valid / already-redeemed / revoked / expired / bad-shape
  * All failure modes collapse to the same 404 so attackers can't
    distinguish the rejection reason via the HTTP response.
"""
from __future__ import annotations

import hashlib
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import pytest


@pytest.fixture(autouse=True)
def _testing_mode(monkeypatch):
    """Force VL_TESTING_MODE so auth is bypassed in tests.

    Important: api.auth imports TESTING_MODE at module load
    (`from api.flags import TESTING_MODE`), so patching api.flags.TESTING_MODE
    alone doesn't propagate — auth.py holds its own local reference captured
    at import time. Works locally if VL_TESTING_MODE was set at first import,
    but fails in CI when a prior test imported auth without the env var.
    Patch BOTH modules so the require_internal_admin check passes regardless
    of import order.
    """
    monkeypatch.setenv("VL_TESTING_MODE", "1")
    import api.flags
    import api.auth
    monkeypatch.setattr(api.flags, "TESTING_MODE", True)
    monkeypatch.setattr(api.auth, "TESTING_MODE", True)
    yield


@pytest.fixture
def client():
    """FastAPI TestClient with invite routers mounted."""
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from api.invite_routes import admin_invites_router, public_invites_router

    app = FastAPI()
    app.include_router(admin_invites_router)
    app.include_router(public_invites_router)
    return TestClient(app)


# ── Helpers ──────────────────────────────────────────────────────────────

def _fake_db_with_invite_row(row: dict):
    """Build a MagicMock db whose invite_tokens select returns `row`."""
    db = MagicMock()

    def _invite_select_result():
        m = MagicMock()
        m.data = [row] if row else []
        return m

    # Chain support for .table("invite_tokens").select(...).eq(...).execute()
    def _configure_select():
        sel = MagicMock()
        sel.select.return_value.eq.return_value.execute.return_value = _invite_select_result()
        return sel

    # Default: invite_tokens.insert / update / select
    db.table.return_value.insert.return_value.execute.return_value = MagicMock(
        data=[{"invite_id": "00000000-0000-0000-0000-000000000001"}]
    )
    db.table.return_value.select.return_value.eq.return_value.execute.return_value = _invite_select_result()
    db.table.return_value.update.return_value.eq.return_value.execute.return_value = MagicMock(data=[])
    return db


# ── Admin endpoint ──────────────────────────────────────────────────────

class TestCreateInvite:
    def test_valid_request_returns_plaintext_token(self, client, monkeypatch):
        from api import invite_routes
        db = _fake_db_with_invite_row(None)
        monkeypatch.setattr(invite_routes, "get_db", lambda: db)

        r = client.post("/api/v1/admin/invites",
                        json={"email": "alice@example.com"},
                        headers={"X-Internal-Admin-Token": "unused-in-test-mode"})
        assert r.status_code == 200
        body = r.json()
        assert body["email"] == "alice@example.com"
        assert body["invite_token"].startswith("vl_invite_")
        # Plaintext should be 32 hex chars after the prefix
        assert len(body["invite_token"]) == len("vl_invite_") + 32
        assert body["credits_cents"] == 1000  # default

    def test_custom_credits_honored(self, client, monkeypatch):
        from api import invite_routes
        db = _fake_db_with_invite_row(None)
        monkeypatch.setattr(invite_routes, "get_db", lambda: db)

        r = client.post("/api/v1/admin/invites",
                        json={"email": "bob@example.com", "credits_cents": 5000},
                        headers={"X-Internal-Admin-Token": "x"})
        assert r.status_code == 200
        assert r.json()["credits_cents"] == 5000

    def test_negative_credits_rejected(self, client, monkeypatch):
        r = client.post("/api/v1/admin/invites",
                        json={"email": "alice@example.com", "credits_cents": -1},
                        headers={"X-Internal-Admin-Token": "x"})
        assert r.status_code == 400

    def test_invalid_email_rejected(self, client, monkeypatch):
        for bad in ["", "no-at-sign", "a@b", "@example.com", "alice@@example.com"]:
            r = client.post("/api/v1/admin/invites",
                            json={"email": bad},
                            headers={"X-Internal-Admin-Token": "x"})
            assert r.status_code == 400, f"expected 400 for email={bad!r}"

    def test_conflict_on_duplicate_active_invite(self, client, monkeypatch):
        from api import invite_routes
        db = MagicMock()
        def _raise_conflict(*a, **kw):
            raise Exception("duplicate key value violates unique constraint active_invite_per_email")
        db.table.return_value.insert.return_value.execute.side_effect = _raise_conflict
        monkeypatch.setattr(invite_routes, "get_db", lambda: db)

        r = client.post("/api/v1/admin/invites",
                        json={"email": "alice@example.com"},
                        headers={"X-Internal-Admin-Token": "x"})
        assert r.status_code == 409

    def test_email_lowercased(self, client, monkeypatch):
        """Prevent UPPER/lower twin-invite collisions."""
        from api import invite_routes
        db = _fake_db_with_invite_row(None)
        monkeypatch.setattr(invite_routes, "get_db", lambda: db)

        r = client.post("/api/v1/admin/invites",
                        json={"email": "Alice@EXAMPLE.com"},
                        headers={"X-Internal-Admin-Token": "x"})
        assert r.status_code == 200
        assert r.json()["email"] == "alice@example.com"


# ── Redeem endpoint ──────────────────────────────────────────────────────

class TestRedeemInvite:
    def _stub_for_redeem(self, monkeypatch, db, user_token="vl_live_0000000000000000"):
        from api import invite_routes
        monkeypatch.setattr(invite_routes, "get_db", lambda: db)
        # create_user / create_api_token live in api.db
        async def _fake_create_user(user_id, email, **kw):
            return {"user_id": user_id, "email": email}
        async def _fake_create_token(uid):
            return user_token
        monkeypatch.setattr(invite_routes, "create_user", _fake_create_user)
        monkeypatch.setattr(invite_routes, "create_api_token", _fake_create_token)
        # add_credit_event is imported inside redeem_invite — patch the
        # db module's attribute so the import inside the handler sees our stub.
        self._credit_calls = []
        import api.db as _db
        def _fake_add_credit(user_id, event_type, amount_credits, **kw):
            self._credit_calls.append({
                "user_id": user_id, "event_type": event_type,
                "amount_credits": amount_credits,
            })
        monkeypatch.setattr(_db, "add_credit_event", _fake_add_credit)

    def test_happy_path_returns_user_token(self, client, monkeypatch):
        db = _fake_db_with_invite_row({
            "invite_id": "11111111-1111-1111-1111-111111111111",
            "email": "alice@example.com",
            "credits_cents": 5000,
            "redeemed_at": None, "revoked_at": None, "expires_at": None,
            "token_prefix": "vl_invite_abcdef1234",
        })
        self._stub_for_redeem(monkeypatch, db)

        r = client.post("/api/v1/auth/redeem-invite",
                        json={"invite_token": "vl_invite_" + "a" * 32})
        assert r.status_code == 200, r.json()
        body = r.json()
        assert body["user_token"].startswith("vl_live_")
        # Invite's credits_cents MUST be granted via add_credit_event.
        grants = [c for c in self._credit_calls if c["event_type"] == "invite_grant"]
        assert len(grants) == 1, f"expected 1 invite_grant event, got {self._credit_calls}"
        assert grants[0]["amount_credits"] == 5000
        assert body["credits_cents"] == 5000
        assert body["email"] == "alice@example.com"

    def test_wrong_prefix_400(self, client):
        r = client.post("/api/v1/auth/redeem-invite",
                        json={"invite_token": "not_an_invite_token"})
        assert r.status_code == 400

    def test_not_found_404(self, client, monkeypatch):
        db = _fake_db_with_invite_row(None)
        self._stub_for_redeem(monkeypatch, db)
        r = client.post("/api/v1/auth/redeem-invite",
                        json={"invite_token": "vl_invite_" + "0" * 32})
        assert r.status_code == 404
        assert "not found" in r.json()["detail"].lower() or "already redeemed" in r.json()["detail"].lower()

    def test_already_redeemed_404(self, client, monkeypatch):
        db = _fake_db_with_invite_row({
            "invite_id": "x", "email": "a@b.com", "credits_cents": 100,
            "redeemed_at": "2026-04-20T00:00:00+00:00",
            "revoked_at": None, "expires_at": None,
            "token_prefix": "vl_invite_x",
        })
        self._stub_for_redeem(monkeypatch, db)
        r = client.post("/api/v1/auth/redeem-invite",
                        json={"invite_token": "vl_invite_" + "1" * 32})
        assert r.status_code == 404

    def test_revoked_404(self, client, monkeypatch):
        db = _fake_db_with_invite_row({
            "invite_id": "x", "email": "a@b.com", "credits_cents": 100,
            "redeemed_at": None,
            "revoked_at": "2026-04-21T00:00:00+00:00",
            "expires_at": None, "token_prefix": "vl_invite_x",
        })
        self._stub_for_redeem(monkeypatch, db)
        r = client.post("/api/v1/auth/redeem-invite",
                        json={"invite_token": "vl_invite_" + "2" * 32})
        assert r.status_code == 404

    def test_expired_404(self, client, monkeypatch):
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        db = _fake_db_with_invite_row({
            "invite_id": "x", "email": "a@b.com", "credits_cents": 100,
            "redeemed_at": None, "revoked_at": None,
            "expires_at": past, "token_prefix": "vl_invite_x",
        })
        self._stub_for_redeem(monkeypatch, db)
        r = client.post("/api/v1/auth/redeem-invite",
                        json={"invite_token": "vl_invite_" + "3" * 32})
        assert r.status_code == 404

    def test_all_failure_modes_have_identical_response_shape(self, client, monkeypatch):
        """Privacy invariant: not-found / revoked / redeemed / expired all
        produce the SAME status code + SAME error body so an attacker
        probing tokens can't distinguish the rejection reason."""
        import json as _json
        from api import invite_routes

        payloads = [
            # not found
            None,
            # already redeemed
            {"invite_id": "x", "email": "a@b.com", "credits_cents": 0,
             "redeemed_at": "2026-04-20T00:00:00+00:00",
             "revoked_at": None, "expires_at": None, "token_prefix": "p"},
            # revoked
            {"invite_id": "x", "email": "a@b.com", "credits_cents": 0,
             "redeemed_at": None,
             "revoked_at": "2026-04-21T00:00:00+00:00",
             "expires_at": None, "token_prefix": "p"},
            # expired
            {"invite_id": "x", "email": "a@b.com", "credits_cents": 0,
             "redeemed_at": None, "revoked_at": None,
             "expires_at": (datetime.now(timezone.utc) - timedelta(days=1)).isoformat(),
             "token_prefix": "p"},
        ]
        responses = []
        for row in payloads:
            db = _fake_db_with_invite_row(row)
            self._stub_for_redeem(monkeypatch, db)
            r = client.post("/api/v1/auth/redeem-invite",
                            json={"invite_token": "vl_invite_" + "f" * 32})
            responses.append((r.status_code, r.json()["detail"]))

        # All four rejection modes produce the same 404 + same message.
        assert all(r == responses[0] for r in responses), (
            f"Rejection responses differ (attacker can distinguish): {responses}"
        )


# ── Shape of generated tokens ───────────────────────────────────────────

class TestListInvites:
    def test_empty_list(self, client, monkeypatch):
        from api import invite_routes
        db = MagicMock()
        db.table.return_value.select.return_value.order.return_value.limit.return_value.execute.return_value = MagicMock(data=[])
        monkeypatch.setattr(invite_routes, "get_db", lambda: db)

        r = client.get("/api/v1/admin/invites",
                       headers={"X-Internal-Admin-Token": "x"})
        assert r.status_code == 200
        body = r.json()
        assert body["count"] == 0
        assert body["invites"] == []

    def test_list_returns_rows(self, client, monkeypatch):
        from api import invite_routes
        db = MagicMock()
        rows = [
            {"invite_id": "i1", "email": "a@b.com", "token_prefix": "vl_invite_ab",
             "credits_cents": 1000, "note": None,
             "created_at": "2026-04-21T00:00:00+00:00",
             "expires_at": None, "redeemed_at": None,
             "redeemed_by_user_id": None, "revoked_at": None},
            {"invite_id": "i2", "email": "c@d.com", "token_prefix": "vl_invite_cd",
             "credits_cents": 2000, "note": "test",
             "created_at": "2026-04-20T00:00:00+00:00",
             "expires_at": None,
             "redeemed_at": "2026-04-21T01:00:00+00:00",
             "redeemed_by_user_id": "vl-xyz", "revoked_at": None},
        ]
        db.table.return_value.select.return_value.order.return_value.limit.return_value.execute.return_value = MagicMock(data=rows)
        monkeypatch.setattr(invite_routes, "get_db", lambda: db)

        r = client.get("/api/v1/admin/invites",
                       headers={"X-Internal-Admin-Token": "x"})
        assert r.status_code == 200
        assert r.json()["count"] == 2
        assert r.json()["invites"][0]["email"] == "a@b.com"
        assert r.json()["invites"][1]["redeemed_by_user_id"] == "vl-xyz"

    def test_status_filter_rejects_unknown(self, client):
        r = client.get("/api/v1/admin/invites?status_filter=garbage",
                       headers={"X-Internal-Admin-Token": "x"})
        assert r.status_code == 400


class TestRevokeInvite:
    def test_revoke_unknown_returns_404(self, client, monkeypatch):
        from api import invite_routes
        db = MagicMock()
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = MagicMock(data=[])
        monkeypatch.setattr(invite_routes, "get_db", lambda: db)
        r = client.post("/api/v1/admin/invites/nonexistent/revoke",
                        headers={"X-Internal-Admin-Token": "x"})
        assert r.status_code == 404

    def test_revoke_already_revoked_is_idempotent(self, client, monkeypatch):
        from api import invite_routes
        db = MagicMock()
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = MagicMock(
            data=[{"invite_id": "x", "redeemed_at": None,
                   "revoked_at": "2026-04-21T00:00:00+00:00",
                   "token_prefix": "vl_invite_x"}]
        )
        monkeypatch.setattr(invite_routes, "get_db", lambda: db)
        r = client.post("/api/v1/admin/invites/x/revoke",
                        headers={"X-Internal-Admin-Token": "x"})
        assert r.status_code == 200
        assert r.json()["already_revoked"] is True

    def test_revoke_already_redeemed_409(self, client, monkeypatch):
        from api import invite_routes
        db = MagicMock()
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = MagicMock(
            data=[{"invite_id": "x",
                   "redeemed_at": "2026-04-21T00:00:00+00:00",
                   "revoked_at": None, "token_prefix": "vl_invite_x"}]
        )
        monkeypatch.setattr(invite_routes, "get_db", lambda: db)
        r = client.post("/api/v1/admin/invites/x/revoke",
                        headers={"X-Internal-Admin-Token": "x"})
        assert r.status_code == 409
        assert "already been redeemed" in r.json()["detail"]

    def test_revoke_happy_path(self, client, monkeypatch):
        from api import invite_routes
        db = MagicMock()
        db.table.return_value.select.return_value.eq.return_value.execute.return_value = MagicMock(
            data=[{"invite_id": "x", "redeemed_at": None,
                   "revoked_at": None, "token_prefix": "vl_invite_x"}]
        )
        db.table.return_value.update.return_value.eq.return_value.execute.return_value = MagicMock(data=[])
        monkeypatch.setattr(invite_routes, "get_db", lambda: db)
        r = client.post("/api/v1/admin/invites/x/revoke",
                        headers={"X-Internal-Admin-Token": "x"})
        assert r.status_code == 200
        assert r.json()["ok"] is True
        assert "revoked_at" in r.json()


class TestTokenShape:
    def test_invite_token_has_entropy_and_prefix(self):
        from api.invite_routes import _generate_invite_token, INVITE_PREFIX
        raw, hashed, prefix = _generate_invite_token()
        assert raw.startswith(INVITE_PREFIX)
        # 10 char prefix + 32 hex char suffix
        assert len(raw) == len(INVITE_PREFIX) + 32
        # Hash is SHA256 hex
        assert len(hashed) == 64
        assert hashed == hashlib.sha256(raw.encode()).hexdigest()
        # Prefix for logs is 20 chars (safe to expose)
        assert prefix == raw[:20]

    def test_two_generations_differ(self):
        from api.invite_routes import _generate_invite_token
        t1 = _generate_invite_token()
        t2 = _generate_invite_token()
        assert t1[0] != t2[0]
        assert t1[1] != t2[1]
