"""
Tests for Phase 2 BYOC: GCP + Azure config, CLI connect commands, broker provisioning,
and pricing agent extensions (GCP/Azure static prices + RunPod live pricing).
"""
import json
import os
import tempfile
import pytest
import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch, mock_open

# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────

TOKEN = "vl_test_" + "a" * 64


def _make_config(**kwargs):
    from shared.config import VaultLayerConfig
    return VaultLayerConfig(token=TOKEN, **kwargs)


# ─────────────────────────────────────────────────────────────────────────────
# 1. Config: GCPConfig and AzureConfig dataclasses
# ─────────────────────────────────────────────────────────────────────────────

class TestGCPConfig:
    def test_gcp_config_fields(self):
        from shared.config import GCPConfig
        cfg = GCPConfig(service_account_json="/tmp/sa.json", project_id="my-project")
        assert cfg.service_account_json == "/tmp/sa.json"
        assert cfg.project_id == "my-project"
        assert cfg.region == "us-central1"
        assert cfg.zone == "us-central1-a"

    def test_gcp_config_custom_region(self):
        from shared.config import GCPConfig
        cfg = GCPConfig(
            service_account_json="/tmp/sa.json",
            project_id="proj",
            region="us-west1",
            zone="us-west1-b",
        )
        assert cfg.region == "us-west1"
        assert cfg.zone == "us-west1-b"


class TestAzureConfig:
    def test_azure_config_fields(self):
        from shared.config import AzureConfig
        cfg = AzureConfig(
            subscription_id="sub-123",
            tenant_id="tenant-456",
            client_id="client-789",
            client_secret="secret-abc",
        )
        assert cfg.subscription_id == "sub-123"
        assert cfg.tenant_id == "tenant-456"
        assert cfg.resource_group == "vaultlayer-rg"
        assert cfg.location == "eastus"

    def test_azure_config_custom_rg(self):
        from shared.config import AzureConfig
        cfg = AzureConfig(
            subscription_id="s", tenant_id="t", client_id="c", client_secret="k",
            resource_group="my-rg", location="westeurope",
        )
        assert cfg.resource_group == "my-rg"
        assert cfg.location == "westeurope"


# ─────────────────────────────────────────────────────────────────────────────
# 2. Config: load_config() populates GCP and Azure from env
# ─────────────────────────────────────────────────────────────────────────────

class TestLoadConfigGCPAzure:
    def test_gcp_loaded_when_env_set(self, monkeypatch):
        monkeypatch.setenv("VAULTLAYER_TOKEN", TOKEN)
        monkeypatch.setenv("GCP_SERVICE_ACCOUNT_JSON", "/tmp/sa.json")
        monkeypatch.setenv("GCP_PROJECT_ID", "my-proj")
        monkeypatch.setenv("GCP_REGION", "us-west1")
        monkeypatch.setenv("GCP_ZONE", "us-west1-b")

        from shared import config as cfg_mod
        with patch.object(cfg_mod, "_load_config_env"):  # skip file loading
            from importlib import reload
            cfg = cfg_mod.load_config()

        assert cfg.gcp is not None
        assert cfg.gcp.project_id == "my-proj"
        assert cfg.gcp.region == "us-west1"

    def test_gcp_absent_when_env_missing(self, monkeypatch):
        monkeypatch.setenv("VAULTLAYER_TOKEN", TOKEN)
        monkeypatch.delenv("GCP_SERVICE_ACCOUNT_JSON", raising=False)
        monkeypatch.delenv("GCP_PROJECT_ID", raising=False)

        from shared import config as cfg_mod
        with patch.object(cfg_mod, "_load_config_env"):
            cfg = cfg_mod.load_config()

        assert cfg.gcp is None

    def test_gcp_absent_when_only_project_set(self, monkeypatch):
        """GCP needs BOTH service_account_json AND project_id."""
        monkeypatch.setenv("VAULTLAYER_TOKEN", TOKEN)
        monkeypatch.delenv("GCP_SERVICE_ACCOUNT_JSON", raising=False)
        monkeypatch.setenv("GCP_PROJECT_ID", "proj")

        from shared import config as cfg_mod
        with patch.object(cfg_mod, "_load_config_env"):
            cfg = cfg_mod.load_config()

        assert cfg.gcp is None

    def test_azure_loaded_when_env_set(self, monkeypatch):
        monkeypatch.setenv("VAULTLAYER_TOKEN", TOKEN)
        monkeypatch.setenv("AZURE_SUBSCRIPTION_ID", "sub-1")
        monkeypatch.setenv("AZURE_TENANT_ID", "ten-2")
        monkeypatch.setenv("AZURE_CLIENT_ID", "cli-3")
        monkeypatch.setenv("AZURE_CLIENT_SECRET", "sec-4")

        from shared import config as cfg_mod
        with patch.object(cfg_mod, "_load_config_env"):
            cfg = cfg_mod.load_config()

        assert cfg.azure is not None
        assert cfg.azure.subscription_id == "sub-1"

    def test_azure_absent_when_partial_env(self, monkeypatch):
        """Azure needs ALL four credentials."""
        monkeypatch.setenv("VAULTLAYER_TOKEN", TOKEN)
        monkeypatch.setenv("AZURE_SUBSCRIPTION_ID", "sub-1")
        monkeypatch.delenv("AZURE_TENANT_ID", raising=False)
        monkeypatch.delenv("AZURE_CLIENT_ID", raising=False)
        monkeypatch.delenv("AZURE_CLIENT_SECRET", raising=False)

        from shared import config as cfg_mod
        with patch.object(cfg_mod, "_load_config_env"):
            cfg = cfg_mod.load_config()

        assert cfg.azure is None


# ─────────────────────────────────────────────────────────────────────────────
# 3. require_provider() knows about gcp and azure
# ─────────────────────────────────────────────────────────────────────────────

class TestRequireProviderGCPAzure:
    def test_require_gcp_raises_when_absent(self):
        from shared.config import require_provider
        cfg = _make_config()
        with pytest.raises(ValueError, match="gcp"):
            require_provider(cfg, "gcp")

    def test_require_azure_raises_when_absent(self):
        from shared.config import require_provider
        cfg = _make_config()
        with pytest.raises(ValueError, match="azure"):
            require_provider(cfg, "azure")

    def test_require_gcp_passes_when_present(self):
        from shared.config import GCPConfig, require_provider
        cfg = _make_config(gcp=GCPConfig(service_account_json="/sa.json", project_id="p"))
        require_provider(cfg, "gcp")  # should not raise

    def test_require_azure_passes_when_present(self):
        from shared.config import AzureConfig, require_provider
        cfg = _make_config(
            azure=AzureConfig(subscription_id="s", tenant_id="t", client_id="c", client_secret="k")
        )
        require_provider(cfg, "azure")  # should not raise

    def test_error_message_contains_env_hint_gcp(self):
        from shared.config import require_provider
        cfg = _make_config()
        with pytest.raises(ValueError, match="GCP_SERVICE_ACCOUNT_JSON"):
            require_provider(cfg, "gcp")

    def test_error_message_contains_env_hint_azure(self):
        from shared.config import require_provider
        cfg = _make_config()
        with pytest.raises(ValueError, match="AZURE_SUBSCRIPTION_ID"):
            require_provider(cfg, "azure")


# ─────────────────────────────────────────────────────────────────────────────
# 4. CLI: vaultlayer connect aws (role mode)
# ─────────────────────────────────────────────────────────────────────────────

class TestConnectAWSCLI:
    def _make_runner(self):
        from click.testing import CliRunner
        return CliRunner()

    def test_connect_aws_role_writes_config(self, tmp_path):
        from click.testing import CliRunner
        from cli.connect import connect_aws

        runner = CliRunner()
        config_env = tmp_path / "config.env"

        with patch("cli.connect.Path.home", return_value=tmp_path), \
             patch("boto3.client") as mock_boto:
            mock_sts = MagicMock()
            mock_boto.return_value = mock_sts
            mock_sts.assume_role.return_value = {"Credentials": {}}

            result = runner.invoke(connect_aws, [
                "--role-arn", "arn:aws:iam::123456789012:role/VaultLayerRole",
                "--external-id", "ext-id-123",
                "--region", "us-east-1",
            ])

        assert result.exit_code == 0, result.output
        assert "AWS connected" in result.output

    def test_connect_aws_invalid_role_arn_exits(self, tmp_path):
        from click.testing import CliRunner
        from cli.connect import connect_aws

        runner = CliRunner()
        with patch("cli.connect.Path.home", return_value=tmp_path):
            result = runner.invoke(connect_aws, [
                "--role-arn", "not-an-arn",
                "--external-id", "placeholder",
                "--region", "us-east-1",
            ])
        assert result.exit_code != 0
        assert "Invalid Role ARN" in result.output

    def test_connect_aws_static_keys_writes_config(self, tmp_path):
        from click.testing import CliRunner
        from cli.connect import connect_aws

        runner = CliRunner()
        with patch("cli.connect.Path.home", return_value=tmp_path), \
             patch("boto3.client") as mock_boto:
            mock_sts = MagicMock()
            mock_boto.return_value = mock_sts
            mock_sts.get_caller_identity.return_value = {"Account": "123"}

            result = runner.invoke(connect_aws, [
                "--access-key", "AKIAIOSFODNN7EXAMPLE",
                "--secret-key", "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
                "--region", "us-west-2",
            ])

        assert result.exit_code == 0, result.output
        assert "AWS connected" in result.output

    def test_connect_aws_boto3_missing_skips_validation(self, tmp_path):
        from click.testing import CliRunner
        from cli.connect import connect_aws

        runner = CliRunner()
        with patch("cli.connect.Path.home", return_value=tmp_path), \
             patch("boto3.client", side_effect=ImportError("No module named 'boto3'")):
            result = runner.invoke(connect_aws, [
                "--role-arn", "arn:aws:iam::123456789012:role/VL",
                "--external-id", "placeholder",
                "--region", "us-east-1",
            ])
        # ImportError from boto3 is caught and skipped — should still write config
        assert "AWS connected" in result.output or "boto3 not installed" in result.output


# ─────────────────────────────────────────────────────────────────────────────
# 5. CLI: vaultlayer connect gcp
# ─────────────────────────────────────────────────────────────────────────────

class TestConnectGCPCLI:
    def test_connect_gcp_valid_json_writes_config(self, tmp_path):
        from click.testing import CliRunner
        from cli.connect import connect_gcp

        sa_file = tmp_path / "sa.json"
        sa_file.write_text(json.dumps({
            "type": "service_account",
            "client_email": "vl@my-proj.iam.gserviceaccount.com",
            "project_id": "my-proj",
        }))

        runner = CliRunner()
        with patch("cli.connect.Path.home", return_value=tmp_path):
            result = runner.invoke(connect_gcp, [
                "--service-account-json", str(sa_file),
                "--project-id", "my-proj",
                "--region", "us-central1",
            ])

        assert result.exit_code == 0, result.output
        assert "GCP connected" in result.output
        config_env = tmp_path / ".vaultlayer" / "config.env"
        content = config_env.read_text()
        assert "GCP_SERVICE_ACCOUNT_JSON" in content
        assert "GCP_PROJECT_ID" in content

    def test_connect_gcp_wrong_type_warns(self, tmp_path):
        from click.testing import CliRunner
        from cli.connect import connect_gcp

        sa_file = tmp_path / "sa.json"
        sa_file.write_text(json.dumps({"type": "user_account"}))

        runner = CliRunner()
        with patch("cli.connect.Path.home", return_value=tmp_path):
            result = runner.invoke(connect_gcp, [
                "--service-account-json", str(sa_file),
                "--project-id", "my-proj",
                "--region", "us-central1",
            ])

        assert result.exit_code != 0
        assert "service account" in result.output.lower()


# ─────────────────────────────────────────────────────────────────────────────
# 6. CLI: vaultlayer connect azure
# ─────────────────────────────────────────────────────────────────────────────

class TestConnectAzureCLI:
    def test_connect_azure_writes_all_fields(self, tmp_path):
        from click.testing import CliRunner
        from cli.connect import connect_azure

        runner = CliRunner()
        with patch("cli.connect.Path.home", return_value=tmp_path):
            result = runner.invoke(connect_azure, [
                "--subscription-id", "sub-123",
                "--tenant-id", "ten-456",
                "--client-id", "cli-789",
                "--client-secret", "sec-abc",
                "--resource-group", "my-rg",
                "--location", "westeurope",
            ])

        assert result.exit_code == 0, result.output
        assert "Azure connected" in result.output

        config_env = tmp_path / ".vaultlayer" / "config.env"
        content = config_env.read_text()
        assert "AZURE_SUBSCRIPTION_ID=sub-123" in content
        assert "AZURE_TENANT_ID=ten-456" in content
        assert "AZURE_CLIENT_ID=cli-789" in content
        assert "AZURE_RESOURCE_GROUP=my-rg" in content
        assert "AZURE_LOCATION=westeurope" in content


# ─────────────────────────────────────────────────────────────────────────────
# 7. Broker: provision_gcp()
# ─────────────────────────────────────────────────────────────────────────────

def _make_cloudflare_config():
    from shared.config import CloudflareConfig
    return CloudflareConfig(
        account_id="acct-test",
        r2_access_key_id="test-key-id",
        r2_secret_access_key="test-secret",
        r2_bucket="test-bucket",
        r2_endpoint="https://test.r2.cloudflarestorage.com",
    )


def _make_broker(config=None):
    """Create a BrokerAgent with a mocked queue."""
    from agents.broker.agent import BrokerAgent
    from shared.queue import AgentQueue
    queue = MagicMock(spec=AgentQueue)
    queue.publish = AsyncMock()
    queue.publish_critical = AsyncMock()
    if config is None:
        config = _make_config(cloudflare=_make_cloudflare_config())
    return BrokerAgent(config=config, queue=queue)


def _make_job(job_id="test-job-1234"):
    from shared.models import Job, Provider, GPUType
    return Job(
        job_id=job_id,
        name="test-job",
        user_id="u1",
        command="python train.py",
        provider=Provider.AWS,
        gpu_type=GPUType.H100_80GB_SXM,
    )


class TestProvisionGCP:
    @pytest.mark.asyncio
    async def test_provision_gcp_returns_none_when_not_configured(self):
        from shared.models import GPUType
        broker = _make_broker()  # no gcp config — cloudflare is included by _make_broker default
        result = await broker.provision_gcp(GPUType.H100_80GB_SXM, _make_job())
        assert result is None

    @pytest.mark.asyncio
    async def test_provision_gcp_returns_none_for_unsupported_gpu(self):
        from shared.config import GCPConfig
        from shared.models import GPUType
        cfg = _make_config(cloudflare=_make_cloudflare_config(),
                           gcp=GCPConfig(service_account_json="/sa.json", project_id="p"))
        broker = _make_broker(cfg)

        # RTX4090 is not in GCP map
        result = await broker.provision_gcp(GPUType.RTX4090, _make_job())
        assert result is None

    @pytest.mark.asyncio
    async def test_provision_gcp_returns_none_on_sdk_exception(self):
        """provision_gcp returns None when GCP SDK raises any exception."""
        from shared.config import GCPConfig
        from shared.models import GPUType
        cfg = _make_config(cloudflare=_make_cloudflare_config(),
                           gcp=GCPConfig(service_account_json="/sa.json", project_id="p"))
        broker = _make_broker(cfg)

        # Simulate SDK exception without patching __import__ (fragile)
        with patch("agents.broker.agent.asyncio.sleep", AsyncMock()):
            # Patch the JSON file read to raise, triggering the except branch
            with patch("builtins.open", side_effect=FileNotFoundError("/sa.json not found")):
                result = await broker.provision_gcp(GPUType.H100_80GB_SXM, _make_job())
        assert result is None

    @pytest.mark.asyncio
    async def test_provision_gcp_happy_path(self):
        """provision_gcp returns an instance name string on success."""
        from shared.config import GCPConfig
        from shared.models import GPUType
        cfg = _make_config(cloudflare=_make_cloudflare_config(), gcp=GCPConfig(
            service_account_json="/sa.json", project_id="my-proj",
            zone="us-central1-a",
        ))
        broker = _make_broker(cfg)

        # Build mock compute service
        mock_instances_resource = MagicMock()
        mock_instances_resource.insert.return_value.execute.return_value = {"name": "op-1"}
        mock_instances_resource.get.return_value.execute.return_value = {"status": "RUNNING"}
        mock_compute_svc = MagicMock()
        mock_compute_svc.instances.return_value = mock_instances_resource

        mock_sa_module = MagicMock()
        mock_sa_module.Credentials.from_service_account_file.return_value = MagicMock()

        mock_discovery_module = MagicMock()
        mock_discovery_module.build.return_value = mock_compute_svc

        mock_googleapi = MagicMock()
        mock_googleapi.discovery = mock_discovery_module

        mock_google_oauth2 = MagicMock()
        mock_google_oauth2.service_account = mock_sa_module

        # Pin to single zone so the new capacity-aware ranker doesn't try
        # to mock acceleratorTypes.list — this test only covers the single-zone
        # happy path; cross-zone fallback is covered by smoke tests.
        import os as _os
        _prev_lock = _os.environ.get("VL_GCP_ZONE_LOCKED")
        _os.environ["VL_GCP_ZONE_LOCKED"] = "1"
        try:
            with patch.dict("sys.modules", {
                "google": MagicMock(),
                "google.auth": MagicMock(),
                "google.oauth2": mock_google_oauth2,
                "google.oauth2.service_account": mock_sa_module,
                "googleapiclient": mock_googleapi,
                "googleapiclient.discovery": mock_discovery_module,
            }):
                result = await broker.provision_gcp(GPUType.H100_80GB_SXM, _make_job())
        finally:
            if _prev_lock is None:
                _os.environ.pop("VL_GCP_ZONE_LOCKED", None)
            else:
                _os.environ["VL_GCP_ZONE_LOCKED"] = _prev_lock

        assert result is not None
        assert "vl-" in result


# ─────────────────────────────────────────────────────────────────────────────
# 8. Broker: provision_azure()
# ─────────────────────────────────────────────────────────────────────────────

class TestProvisionAzure:
    @pytest.mark.asyncio
    async def test_provision_azure_returns_none_when_not_configured(self):
        from shared.models import GPUType
        broker = _make_broker()  # cloudflare included, no azure
        result = await broker.provision_azure(GPUType.H100_80GB_SXM, _make_job())
        assert result is None

    @pytest.mark.asyncio
    async def test_provision_azure_returns_none_for_unsupported_gpu(self):
        from shared.config import AzureConfig
        from shared.models import GPUType
        cfg = _make_config(cloudflare=_make_cloudflare_config(), azure=AzureConfig(
            subscription_id="s", tenant_id="t", client_id="c", client_secret="k"
        ))
        broker = _make_broker(cfg)
        result = await broker.provision_azure(GPUType.RTX4090, _make_job())
        assert result is None

    @pytest.mark.asyncio
    async def test_provision_azure_returns_none_on_sdk_exception(self):
        """provision_azure returns None when Azure SDK is not installed."""
        from shared.config import AzureConfig
        from shared.models import GPUType
        cfg = _make_config(cloudflare=_make_cloudflare_config(), azure=AzureConfig(
            subscription_id="s", tenant_id="t", client_id="c", client_secret="k"
        ))
        broker = _make_broker(cfg)

        # Simulate missing SDK by removing azure modules from sys.modules
        import sys
        azure_modules = {k: v for k, v in sys.modules.items() if "azure" in k}
        for key in azure_modules:
            sys.modules.pop(key, None)

        try:
            result = await broker.provision_azure(GPUType.H100_80GB_SXM, _make_job())
        finally:
            sys.modules.update(azure_modules)  # restore

        assert result is None

    @pytest.mark.asyncio
    async def test_provision_azure_happy_path(self):
        from shared.config import AzureConfig
        from shared.models import GPUType
        cfg = _make_config(cloudflare=_make_cloudflare_config(), azure=AzureConfig(
            subscription_id="sub", tenant_id="ten", client_id="cli", client_secret="sec",
            resource_group="vl-rg", location="eastus",
        ))
        broker = _make_broker(cfg)

        mock_credential = MagicMock()
        mock_compute = MagicMock()
        mock_network = MagicMock()

        # Mock network operations
        mock_network.virtual_networks.begin_create_or_update.return_value.result.return_value = MagicMock()
        mock_subnet = MagicMock()
        mock_subnet.id = "/subscriptions/sub/resourceGroups/rg/providers/subnets/default"
        mock_network.subnets.get.return_value = mock_subnet
        mock_nic = MagicMock()
        mock_nic.id = "/subscriptions/sub/resourceGroups/rg/providers/nic/nic1"
        mock_network.network_interfaces.begin_create_or_update.return_value.result.return_value = mock_nic

        # Mock VM creation
        mock_vm = MagicMock()
        mock_vm.provisioning_state = "Succeeded"
        mock_compute.virtual_machines.begin_create_or_update.return_value.result.return_value = mock_vm

        import tempfile, os as _os
        with tempfile.NamedTemporaryFile(mode="w", suffix=".pub", delete=False) as ssh_f:
            ssh_f.write("ssh-rsa AAAA test-key")
            ssh_key_path = ssh_f.name
        try:
            with patch.dict("sys.modules", {
                "azure": MagicMock(),
                "azure.identity": MagicMock(ClientSecretCredential=lambda **k: mock_credential),
                "azure.mgmt": MagicMock(),
                "azure.mgmt.compute": MagicMock(ComputeManagementClient=lambda *a: mock_compute),
                "azure.mgmt.network": MagicMock(NetworkManagementClient=lambda *a: mock_network),
            }), patch.dict(_os.environ, {"VAULTLAYER_SSH_PUB_KEY": ssh_key_path}):
                result = await broker.provision_azure(GPUType.H100_80GB_SXM, _make_job())
        finally:
            _os.unlink(ssh_key_path)

        assert result is not None
        assert "vl-" in result


# ─────────────────────────────────────────────────────────────────────────────
# 9. Pricing: GCP and Azure price tables
# ─────────────────────────────────────────────────────────────────────────────

class TestPricingTablesGCPAzure:
    def test_gcp_prices_have_expected_gpus(self):
        from agents.pricing.agent import GCP_PRICES
        from shared.models import GPUType
        assert GPUType.H100_80GB_SXM in GCP_PRICES
        assert GPUType.A100_80GB_SXM in GCP_PRICES
        assert GCP_PRICES[GPUType.H100_80GB_SXM] > 0

    def test_azure_prices_have_expected_gpus(self):
        from agents.pricing.agent import AZURE_PRICES
        from shared.models import GPUType
        assert GPUType.H100_80GB_SXM in AZURE_PRICES
        assert GPUType.A100_80GB_SXM in AZURE_PRICES
        assert AZURE_PRICES[GPUType.H100_80GB_SXM] > 0

    @pytest.mark.asyncio
    async def test_fetch_gcp_returns_gpu_prices(self):
        from agents.pricing.agent import PricingAgent
        from shared.queue import AgentQueue
        from shared.models import Provider

        queue = MagicMock(spec=AgentQueue)
        queue.set_price_cache = AsyncMock()
        queue.publish = AsyncMock()
        config = _make_config()
        agent = PricingAgent(config=config, queue=queue)

        prices = await agent.fetch_gcp()
        assert len(prices) > 0
        for p in prices:
            assert p.provider == Provider.GCP
            assert p.price_per_hour > 0
            assert p.is_spot is True

    @pytest.mark.asyncio
    async def test_fetch_azure_returns_gpu_prices(self):
        from agents.pricing.agent import PricingAgent
        from shared.queue import AgentQueue
        from shared.models import Provider

        queue = MagicMock(spec=AgentQueue)
        config = _make_config()
        agent = PricingAgent(config=config, queue=queue)

        prices = await agent.fetch_azure()
        assert len(prices) > 0
        for p in prices:
            assert p.provider == Provider.AZURE
            assert p.price_per_hour > 0

    @pytest.mark.asyncio
    async def test_fetch_gcp_uses_configured_region(self):
        from agents.pricing.agent import PricingAgent
        from shared.config import GCPConfig
        from shared.queue import AgentQueue

        queue = MagicMock(spec=AgentQueue)
        cfg = _make_config(gcp=GCPConfig(
            service_account_json="/sa.json", project_id="p", region="us-west1"
        ))
        agent = PricingAgent(config=cfg, queue=queue)
        prices = await agent.fetch_gcp()
        assert all(p.region == "us-west1" for p in prices)

    @pytest.mark.asyncio
    async def test_fetch_azure_uses_configured_location(self):
        from agents.pricing.agent import PricingAgent
        from shared.config import AzureConfig
        from shared.queue import AgentQueue

        queue = MagicMock(spec=AgentQueue)
        cfg = _make_config(azure=AzureConfig(
            subscription_id="s", tenant_id="t", client_id="c", client_secret="k",
            location="westeurope",
        ))
        agent = PricingAgent(config=cfg, queue=queue)
        prices = await agent.fetch_azure()
        assert all(p.region == "westeurope" for p in prices)


# ─────────────────────────────────────────────────────────────────────────────
# 10. Pricing: RunPod live pricing
# ─────────────────────────────────────────────────────────────────────────────

class TestRunPodLivePricing:
    @pytest.mark.asyncio
    async def test_fetch_runpod_live_falls_back_when_no_api_key(self):
        from agents.pricing.agent import PricingAgent
        from shared.queue import AgentQueue
        from shared.models import Provider

        queue = MagicMock(spec=AgentQueue)
        config = _make_config()  # no runpod config
        agent = PricingAgent(config=config, queue=queue)

        prices = await agent.fetch_runpod_live()
        assert len(prices) > 0
        for p in prices:
            assert p.provider == Provider.RUNPOD

    @pytest.mark.asyncio
    async def test_fetch_runpod_live_uses_graphql_when_key_present(self):
        from agents.pricing.agent import PricingAgent
        from shared.config import RunPodConfig
        from shared.queue import AgentQueue
        from shared.models import Provider, GPUType

        queue = MagicMock(spec=AgentQueue)
        cfg = _make_config(runpod=RunPodConfig(api_key="rp-test-key"))
        agent = PricingAgent(config=cfg, queue=queue)

        mock_response = {
            "data": {
                "gpuTypes": [
                    {
                        "id": "NVIDIA_H100_80GB_HBM3",
                        "displayName": "NVIDIA H100 80GB HBM3",
                        "lowestPrice": {"minimumBidPrice": 2.49, "uninterruptablePrice": 2.99},
                    },
                    {
                        "id": "NVIDIA_A100_SXM4_80GB",
                        "displayName": "NVIDIA A100-SXM4-80GB",
                        "lowestPrice": {"minimumBidPrice": 1.39, "uninterruptablePrice": 1.59},
                    },
                ]
            }
        }

        mock_session = AsyncMock()
        mock_resp = AsyncMock()
        mock_resp.status = 200
        mock_resp.json = AsyncMock(return_value=mock_response)
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)
        mock_session.post = MagicMock(return_value=MagicMock(
            __aenter__=AsyncMock(return_value=mock_resp),
            __aexit__=AsyncMock(return_value=False),
        ))

        with patch("aiohttp.ClientSession", return_value=mock_session):
            prices = await agent.fetch_runpod_live()

        assert len(prices) >= 1
        h100 = next((p for p in prices if p.gpu == GPUType.H100_80GB_SXM), None)
        assert h100 is not None
        assert h100.price_per_hour == 2.49

    @pytest.mark.asyncio
    async def test_fetch_runpod_live_falls_back_on_api_error(self):
        from agents.pricing.agent import PricingAgent
        from shared.config import RunPodConfig
        from shared.queue import AgentQueue
        from shared.models import Provider

        queue = MagicMock(spec=AgentQueue)
        cfg = _make_config(runpod=RunPodConfig(api_key="rp-test-key"))
        agent = PricingAgent(config=cfg, queue=queue)

        with patch("aiohttp.ClientSession", side_effect=Exception("network error")):
            prices = await agent.fetch_runpod_live()

        # Should fall back to static prices
        assert len(prices) > 0
        for p in prices:
            assert p.provider == Provider.RUNPOD

    @pytest.mark.asyncio
    async def test_fetch_runpod_live_falls_back_on_bad_status(self):
        from agents.pricing.agent import PricingAgent
        from shared.config import RunPodConfig
        from shared.queue import AgentQueue

        queue = MagicMock(spec=AgentQueue)
        cfg = _make_config(runpod=RunPodConfig(api_key="rp-test-key"))
        agent = PricingAgent(config=cfg, queue=queue)

        mock_session = AsyncMock()
        mock_resp = AsyncMock()
        mock_resp.status = 500
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=False)
        mock_session.post = MagicMock(return_value=MagicMock(
            __aenter__=AsyncMock(return_value=mock_resp),
            __aexit__=AsyncMock(return_value=False),
        ))

        with patch("aiohttp.ClientSession", return_value=mock_session):
            prices = await agent.fetch_runpod_live()

        assert len(prices) > 0


# ─────────────────────────────────────────────────────────────────────────────
# 11. Pricing: GCP/Azure appear in _poll_once
# ─────────────────────────────────────────────────────────────────────────────

class TestPollOnceIncludesGCPAzure:
    @pytest.mark.asyncio
    async def test_poll_once_calls_fetch_gcp_and_azure(self):
        from agents.pricing.agent import PricingAgent
        from shared.queue import AgentQueue
        from shared.models import Provider

        queue = MagicMock(spec=AgentQueue)
        queue.set_price_cache = AsyncMock()
        queue.publish = AsyncMock()
        config = _make_config()
        agent = PricingAgent(config=config, queue=queue)

        # Patch all the network-calling fetchers to return empty
        with patch.object(agent, "fetch_aws", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_aws_spot", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_lambda", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_coreweave", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_runpod_live", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_vast", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_voltage_park", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_crusoe", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_nebius", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_hyperstack", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_gcp", AsyncMock(return_value=[])) as mock_gcp, \
             patch.object(agent, "fetch_azure", AsyncMock(return_value=[])) as mock_azure:
            await agent._poll_once()
            mock_gcp.assert_called_once()
            mock_azure.assert_called_once()

    @pytest.mark.asyncio
    async def test_poll_once_calls_fetch_runpod_live_not_fetch_runpod(self):
        from agents.pricing.agent import PricingAgent
        from shared.queue import AgentQueue

        queue = MagicMock(spec=AgentQueue)
        queue.set_price_cache = AsyncMock()
        queue.publish = AsyncMock()
        config = _make_config()
        agent = PricingAgent(config=config, queue=queue)

        with patch.object(agent, "fetch_aws", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_aws_spot", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_lambda", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_coreweave", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_runpod", AsyncMock(return_value=[])) as mock_old, \
             patch.object(agent, "fetch_runpod_live", AsyncMock(return_value=[])) as mock_live, \
             patch.object(agent, "fetch_vast", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_voltage_park", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_crusoe", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_nebius", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_hyperstack", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_gcp", AsyncMock(return_value=[])), \
             patch.object(agent, "fetch_azure", AsyncMock(return_value=[])):
            await agent._poll_once()
            mock_live.assert_called_once()
            mock_old.assert_not_called()


# ─────────────────────────────────────────────────────────────────────────────
# 12. Billing granularity covers GCP and Azure
# ─────────────────────────────────────────────────────────────────────────────

class TestBillingGranularityGCPAzure:
    def test_gcp_billing_granularity_is_60s(self):
        from agents.pricing.agent import PricingAgent
        from shared.models import Provider
        assert PricingAgent.BILLING_GRANULARITY_SECONDS[Provider.GCP] == 60

    def test_azure_billing_granularity_is_60s(self):
        from agents.pricing.agent import PricingAgent
        from shared.models import Provider
        assert PricingAgent.BILLING_GRANULARITY_SECONDS[Provider.AZURE] == 60


# ─────────────────────────────────────────────────────────────────────────────
# 13. Broker _provision_on routes to GCP and Azure
# ─────────────────────────────────────────────────────────────────────────────

class TestProvisionOnRouting:
    @pytest.mark.asyncio
    async def test_provision_on_routes_to_gcp(self):
        from shared.models import GPUType
        from shared.config import GCPConfig
        cfg = _make_config(cloudflare=_make_cloudflare_config(),
                           gcp=GCPConfig(service_account_json="/sa.json", project_id="p"))
        broker = _make_broker(cfg)
        job = _make_job()

        with patch.object(broker, "provision_gcp", AsyncMock(return_value="vl-instance-1")):
            result = await broker.provision_gcp(GPUType.H100_80GB_SXM, job)
            assert result == "vl-instance-1"

    @pytest.mark.asyncio
    async def test_provision_on_routes_to_azure(self):
        from shared.models import GPUType
        from shared.config import AzureConfig
        cfg = _make_config(cloudflare=_make_cloudflare_config(), azure=AzureConfig(
            subscription_id="s", tenant_id="t", client_id="c", client_secret="k"
        ))
        broker = _make_broker(cfg)
        job = _make_job()

        with patch.object(broker, "provision_azure", AsyncMock(return_value="vl-vm-1")):
            result = await broker.provision_azure(GPUType.H100_80GB_SXM, job)
            assert result == "vl-vm-1"
