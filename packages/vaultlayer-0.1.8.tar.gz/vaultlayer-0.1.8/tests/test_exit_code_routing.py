"""Tier-1 tests for issue #72 — exit_code mapping to job status.

Ensures _parse_training_exit_code() extracts the integer from the
canonical VaultLayer sentinel line and returns it, so the worker can
route non-zero exits to status=failed instead of silently charging users
for crashed jobs as "completed".
"""
from __future__ import annotations

import pytest
from unittest.mock import MagicMock, patch

from api.job_worker import _parse_training_exit_code


@pytest.fixture
def _mock_db():
    """Patch api.job_worker.get_db with a MagicMock supabase client."""
    db = MagicMock()
    with patch("api.job_worker.get_db", return_value=db):
        yield db


def _set_log_line(db, line: str):
    """Configure the mock DB to return `line` for the log query."""
    db.table.return_value.select.return_value.eq.return_value.like.return_value \
        .order.return_value.limit.return_value.execute.return_value = MagicMock(
        data=[{"line": line}] if line else []
    )


@pytest.mark.asyncio
async def test_exit_0_returns_zero(_mock_db):
    _set_log_line(_mock_db, "[VaultLayer] Training finished (exit 0)")
    assert await _parse_training_exit_code("job-abc") == 0


@pytest.mark.asyncio
async def test_exit_1_returns_one(_mock_db):
    _set_log_line(_mock_db, "[VaultLayer] Training finished (exit 1)")
    assert await _parse_training_exit_code("job-abc") == 1


@pytest.mark.asyncio
async def test_exit_137_sigkill_returns_137(_mock_db):
    """137 = SIGKILL → OOM kill. Must be captured distinctly."""
    _set_log_line(_mock_db, "[VaultLayer] Training finished (exit 137)")
    assert await _parse_training_exit_code("job-abc") == 137


@pytest.mark.asyncio
async def test_no_sentinel_returns_none(_mock_db):
    """If the DB has no 'Training finished' line, return None.

    Caller (worker) treats None as "can't determine" → settles as completed
    (existing behavior; no regression).
    """
    _set_log_line(_mock_db, "")
    assert await _parse_training_exit_code("job-abc") is None


@pytest.mark.asyncio
async def test_malformed_sentinel_returns_none(_mock_db):
    """Defensive: malformed sentinel (missing exit N) → None, not crash."""
    _set_log_line(_mock_db, "[VaultLayer] Training finished")
    assert await _parse_training_exit_code("job-abc") is None


@pytest.mark.asyncio
async def test_db_unavailable_returns_none(_mock_db):
    """Supabase errors shouldn't crash the worker — return None, log warn."""
    _mock_db.table.side_effect = Exception("Supabase timeout")
    assert await _parse_training_exit_code("job-abc") is None


@pytest.mark.asyncio
async def test_negative_exit_code_captured(_mock_db):
    """Some processes return negative exit codes (signals). Must not crash."""
    _set_log_line(_mock_db, "[VaultLayer] Training finished (exit -11)")
    assert await _parse_training_exit_code("job-abc") == -11
