"""
VaultLayer — vaultlayer sync S3→R2 mirror tests

Tests for:
  - S3 URI parsing
  - Egress cost estimation
  - Confirmation prompt shown when egress cost > $0
  - Confirmation prompt skipped with --yes
  - S3 objects streamed to R2 (mocked boto3)
  - Failed objects logged but do not abort
  - Manifest written to R2 after mirror
  - Abort on user decline
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import json
import pytest
from unittest.mock import MagicMock, patch, call
from click.testing import CliRunner


# ── Helper: build a mock S3 paginator response ───────────────────────────────

def _make_s3_client_mock(objects: list):
    """
    Returns a mock boto3 S3 client whose list_objects_v2 paginator
    returns the given list of {key, size} objects.
    """
    mock_s3 = MagicMock()

    # Paginator
    mock_paginator = MagicMock()
    mock_s3.get_paginator.return_value = mock_paginator
    mock_paginator.paginate.return_value = [
        {"Contents": [{"Key": o["key"], "Size": o["size"]} for o in objects]}
    ]

    # get_object returns the key name as body so tests can verify
    def fake_get_object(Bucket, Key):
        return {"Body": MagicMock(read=lambda: f"content-of-{Key}".encode())}
    mock_s3.get_object.side_effect = fake_get_object

    return mock_s3


# ── 1. _parse_s3_uri works correctly ─────────────────────────────────────────

def test_parse_s3_uri_bucket_only():
    from cli.sync import _parse_s3_uri
    bucket, prefix = _parse_s3_uri("s3://my-bucket")
    assert bucket == "my-bucket"
    assert prefix == ""


def test_parse_s3_uri_with_prefix():
    from cli.sync import _parse_s3_uri
    bucket, prefix = _parse_s3_uri("s3://my-bucket/data/train")
    assert bucket == "my-bucket"
    assert prefix == "data/train"


# ── 2. Egress cost estimation ─────────────────────────────────────────────────

def test_egress_cost_zero_within_free_tier():
    """Under 100 GB → free."""
    from cli.sync import _estimate_s3_egress_cost
    assert _estimate_s3_egress_cost(50.0) == pytest.approx(0.0)


def test_egress_cost_exactly_at_free_tier_boundary():
    from cli.sync import _estimate_s3_egress_cost
    assert _estimate_s3_egress_cost(100.0) == pytest.approx(0.0)


def test_egress_cost_above_free_tier():
    """200 GB = 100 GB free + 100 GB @ $0.09 = $9.00."""
    from cli.sync import _estimate_s3_egress_cost
    assert _estimate_s3_egress_cost(200.0) == pytest.approx(9.0)


def test_egress_cost_large_dataset():
    """1 TB = 900 GB billable @ $0.09 = $81."""
    from cli.sync import _estimate_s3_egress_cost
    cost = _estimate_s3_egress_cost(1000.0)
    assert cost == pytest.approx(900 * 0.09)


# ── 3. S3 source detected by s3:// prefix ────────────────────────────────────

def _s3_invoke(dummy_config, objects, cmd_args, input_text=None):
    """
    Helper: invoke the sync CLI command with S3 source, mocking all external calls.
    R2Client is patched so its __init__ doesn't consume a boto3.client call.
    boto3.client side_effect: [s3_mock, r2_put_mock, r2_manifest_mock].
    """
    from cli.sync import sync
    runner = CliRunner()
    mock_s3 = _make_s3_client_mock(objects)
    mock_r2_put = MagicMock()

    with patch("boto3.client") as mock_boto3_client, \
         patch("shared.config.load_config", return_value=dummy_config), \
         patch("agents.vault.r2.R2Client", return_value=MagicMock()), \
         patch("agents.namespace.ingestion.DatasetIngester.load_manifest", return_value=None):

        # boto3.client calls inside _sync_from_s3: [S3 lister, R2 put per object, R2 manifest]
        mock_boto3_client.side_effect = [mock_s3] + [mock_r2_put] * 20

        result = runner.invoke(sync, cmd_args, input=input_text)

    return result, mock_r2_put


def test_sync_command_detects_s3_source(dummy_config, mock_queue):
    """'vaultlayer sync s3://bucket/data' must route to the S3 mirror path."""
    objects = [{"key": "data/file1.bin", "size": 1024}]
    result, _ = _s3_invoke(dummy_config, objects, [
        "s3://test-bucket/data", "--dataset-id", "my-dataset", "--yes",
    ])
    assert result.exit_code == 0, f"sync failed:\n{result.output}"
    assert "S3 to R2 Mirror" in result.output
    assert "Mirror complete" in result.output


# ── 4. Confirmation prompt shown when egress cost > $0 ───────────────────────

def test_sync_s3_shows_confirmation_prompt_when_cost_nonzero(dummy_config):
    """Without --yes, user must be asked to confirm non-zero egress cost."""
    # 200 GB → $9 egress
    objects = [{"key": "data/big.bin", "size": int(200e9)}]
    result, _ = _s3_invoke(dummy_config, objects, [
        "s3://test-bucket/data", "--dataset-id", "big-dataset",
    ], input_text="n\n")

    assert "Proceed with S3 mirror" in result.output, \
        "Confirmation prompt not shown for non-zero egress cost"
    assert "Aborted" in result.output


# ── 5. --yes flag skips confirmation ─────────────────────────────────────────

def test_sync_s3_yes_flag_skips_confirmation(dummy_config):
    """--yes must bypass the egress confirmation prompt."""
    objects = [{"key": "data/file.bin", "size": int(500e9)}]  # 500 GB → $36 egress
    result, _ = _s3_invoke(dummy_config, objects, [
        "s3://test-bucket/data", "--dataset-id", "big-ds", "--yes",
    ])
    assert result.exit_code == 0, f"Expected success with --yes:\n{result.output}"
    assert "Aborted" not in result.output


# ── 6. Objects are streamed from S3 to R2 ─────────────────────────────────────

def test_sync_s3_streams_objects_to_r2(dummy_config):
    """Each S3 object must be put to R2 with the correct key."""
    objects = [
        {"key": "train/file_a.bin", "size": 100},
        {"key": "train/file_b.bin", "size": 200},
    ]
    result, mock_r2_put = _s3_invoke(dummy_config, objects, [
        "s3://my-bucket/train", "--dataset-id", "train-ds", "--yes",
    ])
    assert result.exit_code == 0, f"sync failed:\n{result.output}"
    # put_object must have been called at least twice (once per object + manifest)
    assert mock_r2_put.put_object.call_count >= 2


# ── 7. Failed objects logged but do not abort ─────────────────────────────────

def test_sync_s3_continues_after_object_failure(dummy_config):
    """If one S3 object fails to transfer, the rest should still complete."""
    from cli.sync import sync
    runner = CliRunner()

    objects = [
        {"key": "data/good.bin", "size": 100},
        {"key": "data/bad.bin",  "size": 200},
    ]
    mock_s3 = MagicMock()
    mock_s3.get_paginator.return_value.paginate.return_value = [
        {"Contents": [{"Key": o["key"], "Size": o["size"]} for o in objects]}
    ]

    def get_object_side_effect(Bucket, Key):
        if "bad" in Key:
            raise Exception("S3 permission denied")
        return {"Body": MagicMock(read=lambda: b"data")}
    mock_s3.get_object.side_effect = get_object_side_effect
    mock_r2 = MagicMock()

    with patch("boto3.client") as mock_boto3_client, \
         patch("shared.config.load_config", return_value=dummy_config), \
         patch("agents.vault.r2.R2Client", return_value=MagicMock()), \
         patch("agents.namespace.ingestion.DatasetIngester.load_manifest", return_value=None):

        mock_boto3_client.side_effect = [mock_s3] + [mock_r2] * 10
        result = runner.invoke(sync, [
            "s3://my-bucket/data", "--dataset-id", "partial-ds", "--yes",
        ])

    assert "Mirror complete" in result.output
    assert "Warning" in result.output or "failed" in result.output.lower()


# ── 8. Manifest written to R2 ────────────────────────────────────────────────

def test_sync_s3_writes_manifest_to_r2(dummy_config):
    """A JSON manifest must be written to R2 at datasets/{id}/s3_mirror_manifest.json."""
    objects = [{"key": "data/file.bin", "size": 100}]
    result, mock_r2_put = _s3_invoke(dummy_config, objects, [
        "s3://my-bucket/data", "--dataset-id", "manifest-ds", "--yes",
    ])
    assert result.exit_code == 0
    put_calls = mock_r2_put.put_object.call_args_list
    manifest_calls = [c for c in put_calls if "s3_mirror_manifest" in str(c)]
    assert len(manifest_calls) >= 1, "s3_mirror_manifest.json not written to R2"


# ── 9. Egress cost shown in output ───────────────────────────────────────────

def test_sync_s3_shows_egress_cost_in_output(dummy_config):
    """The estimated egress cost in USD must appear in CLI output."""
    objects = [{"key": "d/f.bin", "size": int(200e9)}]  # 200 GB → $9 egress
    result, _ = _s3_invoke(dummy_config, objects, [
        "s3://my-bucket/d", "--dataset-id", "cost-ds",
    ], input_text="n\n")
    assert "$9.00" in result.output or "9.00" in result.output, \
        f"Egress cost not shown in output:\n{result.output}"


# ── 10. Local path still works (no regression) ───────────────────────────────

def test_sync_local_path_still_works(dummy_config, tmp_path):
    """Local path sync must not be broken by S3 changes."""
    from cli.sync import sync
    runner = CliRunner()

    # Create a small local file
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    (data_dir / "train.txt").write_text("hello world\n" * 100)

    mock_ingester = MagicMock()
    mock_manifest = MagicMock()
    mock_manifest.total_shards = 1
    mock_manifest.total_size_bytes = 1200
    mock_ingester.ingest = MagicMock(return_value=mock_manifest)

    with patch("shared.config.load_config", return_value=dummy_config), \
         patch("agents.namespace.ingestion.DatasetIngester.load_manifest", return_value=None), \
         patch("agents.namespace.ingestion.DatasetIngester", return_value=mock_ingester):

        result = runner.invoke(sync, [
            str(data_dir),
            "--dataset-id", "local-ds",
        ])

    # Should NOT show S3 mirror header
    assert "S3 to R2 Mirror" not in result.output
    assert result.exit_code == 0 or "Error" not in result.output
