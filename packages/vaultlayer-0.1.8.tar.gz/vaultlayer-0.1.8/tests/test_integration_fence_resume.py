"""End-to-end integration test for the fence → resume cycle.

Exercises the FULL broker failover path against in-memory/filesystem fakes,
not real providers or real R2. Regression-guards the 4 prod bugs we caught
on 2026-04-21:

  * Bug 1: `_find_checkpoint` recognizes HF `checkpoint-N/` format.
  * Bug 2: bootstrap script pulls prior-leg checkpoints from R2 before training.
  * Bug 3: `_handle_provision_result` doesn't leak sibling-job errors.
  * Bug 5: R2 resume-path survives both HF and legacy checkpoint layouts
           interleaved in the same prefix (mid-migration jobs).

Key design choices:
  * R2 is faked by a `tempfile.TemporaryDirectory` + a `MagicMock` S3 client
    whose `list_objects_v2` walks the tmpdir. No boto3 network calls.
  * No `subprocess` / no `docker` / no `rclone` — we assert on the generated
    bootstrap *text* (static) AND on the broker's own code paths running
    against the fake R2.
  * Runs in the pytest suite alongside other tests. No external services.

If any test here fails after a code change, the deploy is not safe to ship:
the failure shape is exactly one of the four bugs we hit today.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


# ── Fake R2 ─────────────────────────────────────────────────────────────────

class FakeR2:
    """Filesystem-backed fake of the boto3 S3 client surface we actually use.

    Writes land in `self.root`; `list_objects_v2` walks the tree. Only the
    methods called by broker/worker code are implemented. Anything else
    raises — that's intentional: if the broker starts calling a new S3
    method, we want the test to fail loudly so we implement the mock for it.
    """

    def __init__(self, root: Path):
        self.root = root
        self.calls: list[tuple] = []

    def list_objects_v2(self, *, Bucket, Prefix, MaxKeys=1000, **kw):
        self.calls.append(("list_objects_v2", Bucket, Prefix))
        base = self.root / Bucket
        contents = []
        if base.exists():
            prefix_path = base / Prefix.rstrip("/")
            # S3 semantics: Prefix can be a directory OR a partial key prefix.
            # We handle the directory case (every file under it).
            search = base if not Prefix else (prefix_path if prefix_path.is_dir() else base)
            for p in search.rglob("*"):
                if not p.is_file():
                    continue
                rel = str(p.relative_to(base))
                if rel.startswith(Prefix.lstrip("/")) or Prefix == "":
                    contents.append({
                        "Key": rel,
                        "Size": p.stat().st_size,
                    })
                if len(contents) >= MaxKeys:
                    break
        return {"Contents": contents}

    def put_object(self, *, Bucket, Key, Body, **kw):
        base = self.root / Bucket
        target = base / Key
        target.parent.mkdir(parents=True, exist_ok=True)
        data = Body if isinstance(Body, bytes) else Body.encode() if isinstance(Body, str) else b""
        target.write_bytes(data)
        return {"ETag": "fake"}


@pytest.fixture
def fake_r2_env(monkeypatch):
    """Wire env vars + boto3.client to point at a temp-dir fake R2."""
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        fake = FakeR2(root)
        monkeypatch.setenv("R2_ENDPOINT", "https://fake.r2.test")
        monkeypatch.setenv("R2_ACCESS_KEY_ID", "fake-key")
        monkeypatch.setenv("R2_SECRET_ACCESS_KEY", "fake-secret")
        monkeypatch.setenv("R2_BUCKET", "vaultlayer-checkpoints")
        # Patch boto3.client to return our fake.
        with patch("boto3.client", return_value=fake):
            yield fake


# ── Helpers — seed a checkpoint in fake R2 ──────────────────────────────────

def _seed_hf_checkpoint(fake: FakeR2, job_id: str, step: int, bucket="vaultlayer-checkpoints"):
    """Write a realistic HF checkpoint-N/ dir (the files HF Trainer writes)."""
    base = fake.root / bucket / f"checkpoints/{job_id}/checkpoint-{step}"
    base.mkdir(parents=True, exist_ok=True)
    (base / "model.safetensors").write_bytes(b"fake-model-weights")
    (base / "optimizer.pt").write_bytes(b"fake-optimizer-state")
    (base / "scheduler.pt").write_bytes(b"fake-scheduler-state")
    (base / "trainer_state.json").write_text(json.dumps({"global_step": step}))
    (base / "training_args.bin").write_bytes(b"fake-args")


def _seed_legacy_checkpoint(fake: FakeR2, job_id: str, step: int, bucket="vaultlayer-checkpoints"):
    """Write a legacy `ckpt_step_N.pt` flat file (pre-2026-04-21 format)."""
    base = fake.root / bucket / f"checkpoints/{job_id}"
    base.mkdir(parents=True, exist_ok=True)
    (base / f"ckpt_step_{step}.pt").write_bytes(b"fake-legacy-ckpt")


# ── Tests: Bug 1 — _find_checkpoint end-to-end against fake R2 ──────────────

def test_find_checkpoint_discovers_HF_format(fake_r2_env):
    """Bug 1 regression: after 2026-04-21 refactor, HF `checkpoint-N/` is
    the canonical format. Broker must find it in R2 and return latest step.

    Previously _find_checkpoint only parsed `ckpt_step_N.pt` and silently
    returned None when only HF format was present, triggering the
    "Instance lost, no checkpoint found" failure mode."""
    from api.job_worker import _find_checkpoint

    _seed_hf_checkpoint(fake_r2_env, "job-hf", step=50)
    _seed_hf_checkpoint(fake_r2_env, "job-hf", step=100)
    _seed_hf_checkpoint(fake_r2_env, "job-hf", step=150)

    result = _find_checkpoint("job-hf")
    assert result is not None, "HF checkpoint-N/ format must be discovered"
    assert result["step"] == 150, f"latest step should win, got {result}"


def test_find_checkpoint_legacy_format_still_works(fake_r2_env):
    """Backward compat: a mid-migration job that only wrote old ckpt_step_*.pt
    files must still resume."""
    from api.job_worker import _find_checkpoint

    _seed_legacy_checkpoint(fake_r2_env, "job-legacy", step=200)
    result = _find_checkpoint("job-legacy")
    assert result is not None and result["step"] == 200


def test_find_checkpoint_mixed_formats_prefers_newer_step(fake_r2_env):
    """If both formats coexist in the same job prefix, latest step wins
    regardless of format."""
    from api.job_worker import _find_checkpoint

    _seed_legacy_checkpoint(fake_r2_env, "job-mix", step=100)
    _seed_hf_checkpoint(fake_r2_env, "job-mix", step=250)
    assert _find_checkpoint("job-mix")["step"] == 250


def test_find_checkpoint_empty_R2_returns_none(fake_r2_env):
    """First-leg happy path: no checkpoint yet, returns None cleanly."""
    from api.job_worker import _find_checkpoint
    assert _find_checkpoint("job-empty") is None


# ── Tests: Bug 2 — bootstrap script emits restore-then-sync on every leg ────

def test_bootstrap_script_pulls_from_R2_before_training():
    """Bug 2 regression: the FUSE-mount path was removed 2026-04-21. Every
    leg (including first) must run `rclone copy r2:…/checkpoints/{job}/ → $CKPT_DIR`
    before starting training, then a background persist loop. On a resume
    leg, the restore populates CHECKPOINT_DIR so the training script's
    `resume_from_checkpoint` discovery sees prior checkpoints."""
    from agents.broker.startup_scripts import build_container_onstart
    broker = MagicMock()
    broker.config = SimpleNamespace(
        cloudflare=SimpleNamespace(
            r2_bucket="test", r2_access_key_id="k", r2_secret_access_key="s",
            r2_endpoint="https://r2.test",
        ),
        redis=SimpleNamespace(url="redis://test"),
    )
    broker._get_managed_credentials = MagicMock(return_value=None)
    job = SimpleNamespace(
        job_id="job-restore", name="t", environment={},
        docker_image="ghcr.io/hector25/vl-training-base:1.0",
        model_params_billion=None, training_mode="full",
        dataset_size_gb=None, dataset_location="", dataset_region="",
    )
    script = build_container_onstart(broker, job)

    # Must pull from r2 first
    inbound = script.find("rclone copy r2:")
    outbound = script.find("while true; do rclone sync $CHECKPOINT_DIR r2:")
    assert 0 <= inbound < outbound, \
        f"restore-from-r2 must precede persist-sync-loop (inbound={inbound} outbound={outbound})"

    # Must not use FUSE mount (removed per docs/job_contract.md §4)
    assert "rclone mount" not in script, \
        "FUSE mount path re-introduced — violates contract §4"


# ── Tests: Bug 3 — per-job attempts isolation end-to-end ────────────────────

def test_handle_provision_result_isolates_concurrent_jobs():
    """Bug 3 regression: with two jobs provisioning concurrently, job A's
    failure must not surface job B's error message. The _worker_debug global
    used to be the fallback — that leaked."""
    from api.job_worker import _handle_provision_result, _worker_debug

    # Simulate concurrent job B wrote the shared global.
    _worker_debug["last_provision_attempts"] = [
        {"provider": "SomeOther", "error": "this-belongs-to-job-B"},
    ]
    job_a = {
        "preferred_providers": ["Vast.ai"],
        "_provision_attempts": [],  # job A has no attempts yet
    }
    result = _handle_provision_result(
        job=job_a, job_id="job-A", instance_id=None, pref_label="Vast.ai",
    )
    # The real Bug-3 invariant: job A's error must NOT reference job B's
    # state. Accept "failed" OR "requeue" — either is a valid terminal
    # state for this scenario (the upstream provision-retry scheduler
    # now wraps retryable failures in "requeue"). What matters is the
    # cross-job isolation of error text.
    assert result in ("failed", "requeue")
    err = job_a.get("error") or ""
    assert "job-B" not in err and "this-belongs-to-job-B" not in err, \
        f"cross-job leak: {err!r}"


# ── Smoke: the full chain stays wired after future refactors ────────────────

def test_fence_resume_chain_is_reachable(fake_r2_env):
    """Smoke check: the broker's failover code path imports cleanly and
    _find_checkpoint returns a dict shape _handle_provision_result's resume
    branch can consume. If someone refactors _find_checkpoint's return type
    or _handle_provision_result's input expectations, this fails first."""
    from api.job_worker import _find_checkpoint

    _seed_hf_checkpoint(fake_r2_env, "job-smoke", step=42)
    ckpt = _find_checkpoint("job-smoke")
    # _handle_provision_result reads ckpt['step'] on the resume branch.
    assert "step" in ckpt and isinstance(ckpt["step"], int)
    assert ckpt["step"] == 42
