"""Invariant checks for docs/job_contract.md.

If any of these fail, the contract doc and the implementation have drifted.
Fix the drift in the same PR, don't skip these tests.

Contract (2026-04-21): https://…/docs/job_contract.md
  §2  CHECKPOINT_DIR and VAULTLAYER_CHECKPOINT_DIR must be exported together
  §3  Only HF checkpoint-N/ format — no ckpt_step_*.pt legacy helper
  §4  sync-only R2 protocol — no rclone mount, no FUSE fallbacks
  §7  CI checks listed there must all exist
"""
from __future__ import annotations

import pathlib
import re


_ROOT = pathlib.Path(__file__).parent.parent


def _read_startup_scripts() -> str:
    return (_ROOT / "src/agents/broker/startup_scripts.py").read_text()


def _read_training_base_dockerfile() -> str:
    p = _ROOT / "docker/training-base.Dockerfile"
    if not p.exists():
        return ""  # Only present in worktrees that ship the base image
    return p.read_text()


def test_contract_doc_exists():
    p = _ROOT / "docs/job_contract.md"
    assert p.exists(), "docs/job_contract.md must exist as authoritative contract"
    body = p.read_text()
    # Must reference the load-bearing sections so it stays in sync with tests below.
    for section in ("§2", "§3", "§4", "§7"):
        assert section in body or section.replace("§", "") in body, \
            f"contract doc missing section marker {section}"


def test_no_rclone_mount_in_paths_covering_vast_runpod_lambda():
    """§4 — sync-only. rclone mount is out."""
    src = _read_startup_scripts()
    # build_vm_startup_script (Lambda/GCP) and build_container_onstart (RunPod/Vast)
    # are the only two paths in scope for the 3 validated providers today.
    # build_userdata (AWS) is still allowed to use FUSE until AWS is validated
    # end-to-end, so we check the file as a whole minus the AWS function.
    aws_start = src.find("def build_userdata(")
    # Everything before the AWS builder must have no rclone mount.
    in_scope = src[:aws_start] if aws_start != -1 else src
    assert "rclone mount" not in in_scope, \
        "rclone mount removed from Lambda/GCP VM and container-provider paths (§4)"


def test_no_ckpt_step_legacy_helper():
    """§3 — only HF checkpoint-N/ directory format. The old ckpt_step_N.pt
    helper was a parallel format that confused the resume logic."""
    src = _read_startup_scripts()
    assert "ckpt_step_" not in src, "§3: ckpt_step_N.pt legacy helper removed"
    assert "vaultlayer_checkpoint.py" not in src, \
        "§3: helper-module injection removed (was orthogonal to HF Trainer contract)"


def test_both_checkpoint_env_vars_exported_everywhere():
    """§2 — CHECKPOINT_DIR and VAULTLAYER_CHECKPOINT_DIR set together."""
    src = _read_startup_scripts()
    # Every export of CHECKPOINT_DIR should be paired with VAULTLAYER_CHECKPOINT_DIR.
    ckpt_exports = re.findall(r"export CHECKPOINT_DIR=[^\s\"']+", src)
    vl_exports = src.count("export VAULTLAYER_CHECKPOINT_DIR=$CHECKPOINT_DIR")
    assert vl_exports >= len(ckpt_exports), \
        f"every `export CHECKPOINT_DIR=` ({len(ckpt_exports)}) needs a paired " \
        f"`export VAULTLAYER_CHECKPOINT_DIR=$CHECKPOINT_DIR` (found {vl_exports})"


def test_training_base_image_meets_minimum_versions():
    """§7 — HF stack minimums. Old transformers broke Mistral/Qwen tokenizers;
    old peft broke LoRA on some model archs."""
    body = _read_training_base_dockerfile()
    if not body:
        return  # dockerfile not in this worktree slice
    # Accept either == or >= pins; floor is what matters.
    def _require_min(pkg: str, min_major: int, min_minor: int):
        # Match only actual pip-pin lines (quoted, with a version specifier),
        # not prose like "transformers>=4.36 calls into …".
        m = re.search(rf'"{pkg}==([0-9]+)\.([0-9]+)', body) \
            or re.search(rf'"{pkg}>=([0-9]+)\.([0-9]+)', body)
        assert m, f"training-base.Dockerfile missing a quoted pin line for {pkg}"
        maj, minr = int(m.group(1)), int(m.group(2))
        assert (maj, minr) >= (min_major, min_minor), \
            f"{pkg} pinned at {maj}.{minr}; need >= {min_major}.{min_minor} " \
            "(older tokenizers break Mistral/Qwen; older peft breaks some arches)"
    _require_min("transformers", 4, 41)
    _require_min("accelerate", 0, 30)
    _require_min("peft", 0, 11)
    _require_min("trl", 0, 8)
