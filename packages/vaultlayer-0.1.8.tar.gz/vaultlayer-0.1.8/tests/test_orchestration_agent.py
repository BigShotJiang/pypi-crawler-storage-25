"""
VaultLayer — Orchestration Agent Tests
Tests the central decision-making agent without real credentials.

Key behavioural contract after issue #11 (deterministic provider selection):
  - TERMINATION_SIGNAL → always deterministic migrate, Claude NOT called
  - ARBITRAGE savings ≥ 25% → deterministic migrate, Claude NOT called
  - ARBITRAGE savings 15-25% + job >80% done → Claude consulted
  - ARBITRAGE savings < 15% → hold, Claude NOT called
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from shared.models import ActionTier, EventType, AgentEvent, Provider, GPUType
from conftest import (MockAgentQueue, make_mock_anthropic, make_job,
                      make_termination_event, make_info_event,
                      CHECKPOINT_DECISION_JSON, MIGRATE_DECISION_JSON,
                      LOW_CONFIDENCE_DECISION_JSON)


PRICE_CACHE_WITH_LAMBDA = [
    {"provider": "aws", "gpu": "H100_80GB_SXM", "price_per_hour": 32.77, "availability": "high"},
    {"provider": "lambda_labs", "gpu": "H100_80GB_SXM", "price_per_hour": 2.49, "availability": "high"},
    {"provider": "coreweave", "gpu": "H100_80GB_SXM", "price_per_hour": 4.89, "availability": "medium"},
]


@pytest.fixture
def orch_agent(dummy_config, mock_queue):
    from agents.orchestration.agent import OrchestrationAgent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
    return agent


# ── 1. Termination signal triggers a deterministic migrate ────────────────

@pytest.mark.asyncio
async def test_handles_termination_signal(dummy_config, mock_queue):
    """TERMINATION_SIGNAL → deterministic migrate, decision recorded."""
    from agents.orchestration.agent import OrchestrationAgent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())
        await agent.handle_event(make_termination_event())

    assert len(agent._decisions) == 1
    d = agent._decisions[0]
    assert d.action == "migrate", f"Termination signal must always trigger migrate, got {d.action}"
    assert 0.0 <= d.confidence <= 1.0
    assert len(d.reasoning) > 10


# ── 2. Termination signal NEVER calls Claude API ──────────────────────────

@pytest.mark.asyncio
async def test_termination_signal_does_not_call_claude(dummy_config, mock_queue):
    """TERMINATION_SIGNAL is urgent — deterministic path, no LLM call allowed."""
    from agents.orchestration.agent import OrchestrationAgent
    mock_anthropic = make_mock_anthropic(MIGRATE_DECISION_JSON)
    with patch('anthropic.Anthropic', return_value=mock_anthropic):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())
        await agent.handle_event(make_termination_event())

    # Claude API must NOT have been called
    assert not mock_anthropic.messages.create.called, \
        "Claude API must not be called for TERMINATION_SIGNAL — deterministic path only"


# ── 3. Info events do not trigger decisions ────────────────────────────────

@pytest.mark.asyncio
async def test_ignores_info_events(dummy_config, mock_queue):
    """NODE_HEALTHY is informational — must not trigger any decision."""
    from agents.orchestration.agent import OrchestrationAgent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())
        await agent.handle_event(make_info_event())

    assert len(agent._decisions) == 0, \
        f"Info event should produce no decisions, got {len(agent._decisions)}"


# ── 4. CHECKPOINT_COMPLETE does not trigger a decision ────────────────────

@pytest.mark.asyncio
async def test_ignores_checkpoint_complete(dummy_config, mock_queue):
    """CHECKPOINT_COMPLETE is informational — no decision needed."""
    from agents.orchestration.agent import OrchestrationAgent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())
        event = AgentEvent(
            event_type=EventType.CHECKPOINT_COMPLETE,
            source_agent="vault_agent",
            job_id="test-001",
            payload={"step": 5000, "r2_key": "checkpoints/test-001/step-5000"}
        )
        await agent.handle_event(event)

    assert len(agent._decisions) == 0


# ── 5. Termination signal → migrate → publishes to orchestration channel ──

@pytest.mark.asyncio
async def test_migrate_decision_publishes_to_orchestration_channel(dummy_config, mock_queue):
    """A migrate decision must publish a command to the orchestration channel."""
    from agents.orchestration.agent import OrchestrationAgent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(MIGRATE_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())
        await agent.handle_event(make_termination_event())

    orch_events = mock_queue.events_on("orchestration")
    assert len(orch_events) > 0, "Migrate decision must publish to orchestration channel"
    commands = [e.payload.get("command") for e in orch_events]
    assert "migrate" in commands, f"Expected migrate command, got: {commands}"


# ── 6. Claude-path checkpoint decision publishes to orchestration channel ──

@pytest.mark.asyncio
async def test_checkpoint_decision_publishes_to_orchestration_channel(dummy_config, mock_queue):
    """When Claude returns checkpoint, the orchestration channel must receive it.
    Trigger genuine ambiguity path: savings 18% + high availability + job 90% done →
    rules 1-5 all pass → Claude consulted → returns checkpoint decision.
    """
    from agents.orchestration.agent import OrchestrationAgent
    from datetime import datetime, timedelta
    # 18% savings (borderline) + high availability → bypasses all deterministic rules
    # Job started 2h ago at 85% → ~21 min remaining → rule 3 doesn't fire
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        job = make_job(progress=85.0)
        job.started_at = datetime.utcnow() - timedelta(hours=2)
        agent.register_job(job)
        event = AgentEvent(
            event_type=EventType.ARBITRAGE_OPPORTUNITY,
            source_agent="pricing_agent",
            job_id="test-001",
            payload={"opportunities": [
                {"gpu": "H100_80GB_SXM", "to_provider": "lambda_labs",
                 "savings_per_hour": 5.4, "savings_pct": 18.0,
                 "availability": "high"}
            ]}
        )
        await agent.handle_event(event)

    orch_events = mock_queue.events_on("orchestration")
    assert len(orch_events) > 0, "Checkpoint decision must publish to orchestration channel"
    commands = [e.payload.get("command") for e in orch_events]
    assert "checkpoint" in commands, f"Expected checkpoint command, got: {commands}"


# ── 7. Termination signal → deterministic confidence = 0.99, AUTO tier ───

@pytest.mark.asyncio
async def test_termination_signal_produces_high_confidence_auto_tier(dummy_config, mock_queue):
    """Termination signal deterministic path → confidence=0.99, tier=AUTO."""
    from agents.orchestration.agent import OrchestrationAgent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())
        await agent.handle_event(make_termination_event())

    d = agent._decisions[0]
    assert d.confidence == 0.99, f"Termination signal confidence should be 0.99, got {d.confidence}"
    assert d.tier == ActionTier.AUTO, f"Confidence 0.99 should be AUTO tier, got {d.tier}"
    assert d.requires_human_confirmation is False


# ── 8. Multiple jobs tracked independently ────────────────────────────────

@pytest.mark.asyncio
async def test_registers_multiple_jobs(dummy_config, mock_queue):
    """Agent must track multiple jobs independently."""
    from agents.orchestration.agent import OrchestrationAgent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job("job-001"))
        agent.register_job(make_job("job-002"))
        agent.register_job(make_job("job-003"))

    assert len(agent._active_jobs) == 3
    assert "job-001" in agent._active_jobs
    assert "job-002" in agent._active_jobs
    assert "job-003" in agent._active_jobs


# ── 9. Borderline arbitrage + late-stage job + low availability → deterministic hold ──

@pytest.mark.asyncio
async def test_borderline_arbitrage_late_stage_calls_claude(dummy_config, mock_queue):
    """
    Savings 20% (borderline) + job 90% done + low availability →
    rule engine deterministically holds (rule 5 fires before Claude is consulted).
    """
    from agents.orchestration.agent import OrchestrationAgent
    agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
    agent.register_job(make_job(progress=90.0))
    event = AgentEvent(
        event_type=EventType.ARBITRAGE_OPPORTUNITY,
        source_agent="pricing_agent",
        job_id="test-001",
        payload={"opportunities": [
            {"gpu": "H100_80GB_SXM", "to_provider": "lambda_labs",
             "savings_per_hour": 6.0, "savings_pct": 20.0,
             "availability": "low"}
        ]}
    )
    await agent.handle_event(event)

    assert len(agent._decisions) > 0, "Must produce a decision"
    d = agent._decisions[0]
    # Rule 5 (low availability) → hold without consulting Claude
    assert d.action in ("hold", "checkpoint"), \
        f"Low-availability borderline → hold, got {d.action}"


# ── 10. High savings arbitrage → deterministic migrate, no Claude ─────────

@pytest.mark.asyncio
async def test_high_savings_arbitrage_does_not_call_claude(dummy_config, mock_queue):
    """Savings ≥ 25% → deterministic migrate path, Claude must NOT be called."""
    from agents.orchestration.agent import OrchestrationAgent
    mock_claude = make_mock_anthropic(MIGRATE_DECISION_JSON)
    with patch('anthropic.Anthropic', return_value=mock_claude):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        await mock_queue.set_price_cache(PRICE_CACHE_WITH_LAMBDA)
        agent.register_job(make_job())
        event = AgentEvent(
            event_type=EventType.ARBITRAGE_OPPORTUNITY,
            source_agent="pricing_agent",
            job_id="test-001",
            payload={"opportunities": [
                {"gpu": "H100_80GB_SXM", "to_provider": "lambda_labs",
                 "savings_per_hour": 69.58, "savings_pct": 70.8}
            ]}
        )
        await agent.handle_event(event)

    assert not mock_claude.messages.create.called, \
        "Claude must NOT be called for high-savings (>25%) arbitrage"
    assert len(agent._decisions) == 1
    assert agent._decisions[0].action == "migrate"


# ── 11. Low savings arbitrage → hold, no Claude, no decision ─────────────

@pytest.mark.asyncio
async def test_low_savings_arbitrage_is_held(dummy_config, mock_queue):
    """Savings < 15% → not worth migration overhead — hold, no decision."""
    from agents.orchestration.agent import OrchestrationAgent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(MIGRATE_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())
        event = AgentEvent(
            event_type=EventType.ARBITRAGE_OPPORTUNITY,
            source_agent="pricing_agent",
            job_id="test-001",
            payload={"opportunities": [
                {"gpu": "H100_80GB_SXM", "to_provider": "lambda_labs",
                 "savings_per_hour": 2.0, "savings_pct": 8.0}  # < 15%
            ]}
        )
        await agent.handle_event(event)

    assert len(agent._decisions) == 0, \
        f"Low savings (<15%) arbitrage must not create a decision, got {len(agent._decisions)}"


# ── 12. _select_provider picks cheapest available ────────────────────────

def test_select_provider_picks_cheapest(dummy_config, mock_queue):
    """_select_provider must return the cheapest available provider."""
    from agents.orchestration.agent import OrchestrationAgent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        job = make_job(provider=Provider.AWS)
        agent.register_job(job)

    prov, gpu, savings_hr, savings_pct = agent._select_provider(
        PRICE_CACHE_WITH_LAMBDA, "test-001", Provider.AWS
    )
    # Lambda Labs at $2.49 is cheapest (not current AWS at $32.77)
    assert prov == Provider.LAMBDA_LABS, f"Expected lambda_labs, got {prov}"
    assert gpu == GPUType.H100_80GB_SXM
    assert savings_hr > 0, "Must show positive savings vs AWS"


# ── 13. _select_provider skips unavailable nodes ──────────────────────────

def test_select_provider_skips_unavailable(dummy_config, mock_queue):
    """_select_provider must not return providers with availability=unavailable."""
    from agents.orchestration.agent import OrchestrationAgent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job(provider=Provider.AWS))

    # AWS source price must appear in the cache so the egress engine can compute
    # the hourly delta for each candidate (positive delta → CoreWeave is cheaper).
    price_cache = [
        {"provider": "aws",         "gpu": "H100_80GB_SXM", "price_per_hour": 5.00, "availability": "high"},  # source price reference
        {"provider": "lambda_labs", "gpu": "H100_80GB_SXM", "price_per_hour": 2.49, "availability": "unavailable"},  # must be skipped
        {"provider": "coreweave",   "gpu": "H100_80GB_SXM", "price_per_hour": 4.89, "availability": "high"},
    ]
    prov, gpu, _, _ = agent._select_provider(price_cache, "test-001", Provider.AWS)
    # lambda_labs filtered out (unavailable); coreweave selected as cheapest eligible
    assert prov == Provider.COREWEAVE, f"Must skip unavailable lambda_labs, got {prov}"


# ── 14. _select_provider selects cheapest total cost (egress-aware) ────────

def test_select_provider_same_provider_first(dummy_config, mock_queue):
    """
    The egress engine ranks by total resume cost (compute + egress), not by
    same-provider loyalty.  Lambda Labs at $2.49 must beat AWS at $30 for a
    job with no dataset egress cost (dataset_size_gb=0, default).

    Renamed from "same_provider_first" — the pre-egress priority rule has been
    replaced by Golden Ratio cost-first ordering (same-cloud penalty is zero for
    S3→S3 same-cloud, and also zero when dataset_size_gb=0).
    """
    from agents.orchestration.agent import OrchestrationAgent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job(provider=Provider.AWS))

    price_cache = [
        {"provider": "aws", "gpu": "H100_80GB_SXM", "price_per_hour": 32.77,
         "region": "us-east-1", "availability": "high"},  # current (same price → degenerate skip)
        {"provider": "aws", "gpu": "H100_80GB_SXM", "price_per_hour": 30.0,
         "region": "us-west-2", "availability": "high"},  # same provider, cheaper AZ
        {"provider": "lambda_labs", "gpu": "H100_80GB_SXM", "price_per_hour": 2.49,
         "availability": "high"},  # cheapest overall — egress engine picks this first
    ]
    prov, _, savings_hr, _ = agent._select_provider(price_cache, "test-001", Provider.AWS)
    # With zero dataset egress cost, cheapest provider wins regardless of cloud boundary
    assert prov == Provider.LAMBDA_LABS, (
        f"Cost-first selection: lambda_labs ($2.49) should beat aws ($30), got {prov}"
    )
    assert savings_hr > 0


# ── 15. HEARTBEAT_MISS → deterministic migrate, no Claude ────────────────

@pytest.mark.asyncio
async def test_heartbeat_miss_triggers_deterministic_migrate(dummy_config, mock_queue):
    """HEARTBEAT_MISS must trigger a deterministic migrate without calling Claude."""
    from agents.orchestration.agent import OrchestrationAgent
    mock_claude = make_mock_anthropic(MIGRATE_DECISION_JSON)
    with patch('anthropic.Anthropic', return_value=mock_claude):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())
        event = AgentEvent(
            event_type=EventType.HEARTBEAT_MISS,
            source_agent="watchdog_agent",
            job_id="test-001",
            payload={"miss_count": 3, "last_seen_seconds_ago": 90},
        )
        await agent.handle_event(event)

    assert not mock_claude.messages.create.called, "Claude must not be called for HEARTBEAT_MISS"
    assert len(agent._decisions) == 1
    assert agent._decisions[0].action == "migrate"


# ── 16. NAMESPACE_SYNC_COMPLETE → deterministic migrate ──────────────────

@pytest.mark.asyncio
async def test_namespace_sync_complete_triggers_migrate(dummy_config, mock_queue):
    """NAMESPACE_SYNC_COMPLETE means checkpoint is ready — immediately warm-start."""
    from agents.orchestration.agent import OrchestrationAgent
    mock_claude = make_mock_anthropic(CHECKPOINT_DECISION_JSON)
    with patch('anthropic.Anthropic', return_value=mock_claude):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())
        event = AgentEvent(
            event_type=EventType.NAMESPACE_SYNC_COMPLETE,
            source_agent="watchdog_agent",
            job_id="test-001",
            payload={"checkpoint_step": 5000, "checkpoint_r2_key": "ckpt/step-5000"},
        )
        await agent.handle_event(event)

    assert not mock_claude.messages.create.called, \
        "Claude must not be called for NAMESPACE_SYNC_COMPLETE"
    assert len(agent._decisions) == 1
    assert agent._decisions[0].action == "migrate"
    assert agent._decisions[0].confidence == 0.99


# ── 17. OOM_DETECTED → deterministic migrate ─────────────────────────────

@pytest.mark.asyncio
async def test_oom_detected_triggers_deterministic_migrate(dummy_config, mock_queue):
    """OOM_DETECTED must trigger a deterministic migrate without calling Claude."""
    from agents.orchestration.agent import OrchestrationAgent
    mock_claude = make_mock_anthropic(MIGRATE_DECISION_JSON)
    with patch('anthropic.Anthropic', return_value=mock_claude):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())
        event = AgentEvent(
            event_type=EventType.OOM_DETECTED,
            source_agent="watchdog_agent",
            job_id="test-001",
            payload={"error": "CUDA out of memory", "gpu_type": "H100_80GB_SXM"},
        )
        await agent.handle_event(event)

    assert not mock_claude.messages.create.called, "Claude must not be called for OOM_DETECTED"
    assert len(agent._decisions) == 1
    assert agent._decisions[0].action == "migrate"
    assert agent._decisions[0].confidence >= 0.9


# ── 18. GPU_FAILURE → deterministic migrate ──────────────────────────────

@pytest.mark.asyncio
async def test_gpu_failure_triggers_deterministic_migrate(dummy_config, mock_queue):
    """GPU_FAILURE must trigger a deterministic migrate without calling Claude."""
    from agents.orchestration.agent import OrchestrationAgent
    mock_claude = make_mock_anthropic(MIGRATE_DECISION_JSON)
    with patch('anthropic.Anthropic', return_value=mock_claude):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())
        event = AgentEvent(
            event_type=EventType.GPU_FAILURE,
            source_agent="watchdog_agent",
            job_id="test-001",
            payload={"error": "NVRM: Xid (PCI:0000:00:1e): 79", "gpu_index": 0},
        )
        await agent.handle_event(event)

    assert not mock_claude.messages.create.called, "Claude must not be called for GPU_FAILURE"
    assert len(agent._decisions) == 1
    assert agent._decisions[0].action == "migrate"


# ── 19. HUNG_JOB → deterministic migrate ────────────────────────────────

@pytest.mark.asyncio
async def test_hung_job_triggers_deterministic_migrate(dummy_config, mock_queue):
    """HUNG_JOB (no progress for timeout) must trigger a deterministic migrate."""
    from agents.orchestration.agent import OrchestrationAgent
    mock_claude = make_mock_anthropic(MIGRATE_DECISION_JSON)
    with patch('anthropic.Anthropic', return_value=mock_claude):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())
        event = AgentEvent(
            event_type=EventType.HUNG_JOB,
            source_agent="watchdog_agent",
            job_id="test-001",
            payload={"stale_seconds": 360, "last_step": 42},
        )
        await agent.handle_event(event)

    assert not mock_claude.messages.create.called, "Claude must not be called for HUNG_JOB"
    assert len(agent._decisions) == 1
    assert agent._decisions[0].action == "migrate"


# ── 20. Rapid OOM/GPU_FAILURE → escalate instead of migrate ──────────────

@pytest.mark.asyncio
async def test_rapid_gpu_failure_escalates_not_migrates(dummy_config, mock_queue):
    """3 rapid GPU_FAILURE events in short window must escalate, not migrate infinitely."""
    from agents.orchestration.agent import OrchestrationAgent
    mock_claude = make_mock_anthropic(MIGRATE_DECISION_JSON)
    with patch('anthropic.Anthropic', return_value=mock_claude):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())

        def make_gpu_event():
            return AgentEvent(
                event_type=EventType.GPU_FAILURE,
                source_agent="watchdog_agent",
                job_id="test-001",
                payload={"error": "NVRM: Xid 79"},
            )

        # Trigger 3 failures — third should escalate
        for _ in range(3):
            agent._decisions.clear()
            await agent.handle_event(make_gpu_event())

    # Last decision must be escalate
    assert len(agent._decisions) >= 1
    last = agent._decisions[-1]
    assert last.action == "escalate", \
        f"After 3 rapid GPU failures, action should be 'escalate', got '{last.action}'"
