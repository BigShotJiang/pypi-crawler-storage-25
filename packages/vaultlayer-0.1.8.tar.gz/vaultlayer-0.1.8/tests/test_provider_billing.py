"""Tests for provider_billing — actual billing API fetchers."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from unittest.mock import patch, AsyncMock, MagicMock
from datetime import datetime, timezone
from shared.provider_billing import fetch_provider_bill, _fetch_runpod_bill, _fetch_vastai_bill


class TestFetchProviderBill:
    @pytest.mark.asyncio
    async def test_unsupported_provider_returns_none(self):
        result = await fetch_provider_bill(
            provider="unknown_provider",
            instance_id="i-123",
            api_key="key",
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_exception_returns_none(self):
        with patch("shared.provider_billing._fetch_runpod_bill", side_effect=Exception("boom")):
            result = await fetch_provider_bill(
                provider="runpod",
                instance_id="pod-123",
                api_key="key",
            )
        assert result is None


class TestRunPodBilling:
    @pytest.mark.asyncio
    async def test_success(self):
        mock_data = [
            {"amount": 1.50, "time": "2024-01-01T00:00:00Z", "timeBilledMs": 3600000, "podId": "pod-123"},
            {"amount": 0.75, "time": "2024-01-02T00:00:00Z", "timeBilledMs": 1800000, "podId": "pod-123"},
        ]
        with patch("aiohttp.ClientSession") as mock_cls:
            mock_session = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_session)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_resp = AsyncMock()
            mock_resp.status = 200
            mock_resp.json = AsyncMock(return_value=mock_data)
            mock_session.get = MagicMock(return_value=AsyncMock(
                __aenter__=AsyncMock(return_value=mock_resp),
                __aexit__=AsyncMock(return_value=False),
            ))
            result = await _fetch_runpod_bill(
                instance_id="pod-123",
                api_key="test-key",
            )
        assert result == 2.25

    @pytest.mark.asyncio
    async def test_empty_response(self):
        with patch("aiohttp.ClientSession") as mock_cls:
            mock_session = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_session)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_resp = AsyncMock()
            mock_resp.status = 200
            mock_resp.json = AsyncMock(return_value=[])
            mock_session.get = MagicMock(return_value=AsyncMock(
                __aenter__=AsyncMock(return_value=mock_resp),
                __aexit__=AsyncMock(return_value=False),
            ))
            result = await _fetch_runpod_bill(
                instance_id="pod-123",
                api_key="test-key",
            )
        assert result is None

    @pytest.mark.asyncio
    async def test_api_error(self):
        with patch("aiohttp.ClientSession") as mock_cls:
            mock_session = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_session)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_resp = AsyncMock()
            mock_resp.status = 500
            mock_session.get = MagicMock(return_value=AsyncMock(
                __aenter__=AsyncMock(return_value=mock_resp),
                __aexit__=AsyncMock(return_value=False),
            ))
            result = await _fetch_runpod_bill(
                instance_id="pod-123",
                api_key="test-key",
            )
        assert result is None


class TestVastAiBilling:
    @pytest.mark.asyncio
    async def test_success(self):
        mock_data = {
            "invoices": [
                {"amount": "2.50", "instance_id": 12345, "description": "GPU charge"},
                {"amount": "0.10", "instance_id": 12345, "description": "Storage charge"},
            ]
        }
        with patch("aiohttp.ClientSession") as mock_cls:
            mock_session = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_session)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_resp = AsyncMock()
            mock_resp.status = 200
            mock_resp.json = AsyncMock(return_value=mock_data)
            mock_session.get = MagicMock(return_value=AsyncMock(
                __aenter__=AsyncMock(return_value=mock_resp),
                __aexit__=AsyncMock(return_value=False),
            ))
            result = await _fetch_vastai_bill(
                instance_id="12345",
                api_key="test-key",
            )
        assert result == 2.6

    @pytest.mark.asyncio
    async def test_api_error(self):
        with patch("aiohttp.ClientSession") as mock_cls:
            mock_session = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_session)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_resp = AsyncMock()
            mock_resp.status = 401
            mock_session.get = MagicMock(return_value=AsyncMock(
                __aenter__=AsyncMock(return_value=mock_resp),
                __aexit__=AsyncMock(return_value=False),
            ))
            result = await _fetch_vastai_bill(
                instance_id="12345",
                api_key="bad-key",
            )
        assert result is None
