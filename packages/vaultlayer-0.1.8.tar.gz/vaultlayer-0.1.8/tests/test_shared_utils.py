"""Comprehensive tests for VaultLayer shared utility modules.

Covers: api_utils, r2_utils, env_utils, logging_utils, data_loader (dynamic config).
"""

import json
import logging
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _clear_data_loader_cache():
    """Reset the data_loader module-level cache before AND after every test."""
    import shared.data_loader as dl
    dl._cache = None
    yield
    dl._cache = None


@pytest.fixture()
def _clean_env(monkeypatch):
    """Remove all VaultLayer/R2 env vars so tests start from a clean slate."""
    keys_to_clear = [
        "VAULTLAYER_API_URL", "VAULTLAYER_TOKEN",
        "R2_ENDPOINT", "R2_ACCESS_KEY_ID", "R2_SECRET_ACCESS_KEY", "R2_BUCKET",
        "VAULTLAYER_R2_ENDPOINT", "VAULTLAYER_R2_ACCESS_KEY_ID",
        "VAULTLAYER_R2_SECRET_ACCESS_KEY", "VAULTLAYER_R2_BUCKET",
        "VL_DEBUG",
        "VL_EGRESS_AWS_S3", "VL_EGRESS_GCP_GCS", "VL_EGRESS_AZURE_BLOB",
        "VL_EGRESS_R2", "VL_EGRESS_AWS_CROSS_AZ",
        "VL_TIER1_MARKUP", "VL_TIER2_MARKUP", "VL_TIER3_MARKUP",
        "VL_SCARCITY_THRESHOLD",
        "VL_AUTO_MIGRATE_PCT", "VL_MIGRATION_COOLDOWN_SECS",
        "VL_PAYBACK_THRESHOLD_HRS", "VL_PRICING_MARGIN",
        "VL_ARBITRAGE_THRESHOLD",
    ]
    for k in keys_to_clear:
        monkeypatch.delenv(k, raising=False)


# ===========================================================================
# api_utils
# ===========================================================================


class TestGetApiUrl:
    def test_returns_default_url(self, monkeypatch):
        monkeypatch.delenv("VAULTLAYER_API_URL", raising=False)
        from shared.api_utils import get_api_url
        assert get_api_url() == "https://vaultlayer-production.up.railway.app"

    def test_returns_env_override(self, monkeypatch):
        monkeypatch.setenv("VAULTLAYER_API_URL", "https://custom.example.com/")
        from shared.api_utils import get_api_url
        # trailing slash should be stripped
        assert get_api_url() == "https://custom.example.com"


class TestGetToken:
    def test_returns_from_env(self, monkeypatch):
        monkeypatch.setenv("VAULTLAYER_TOKEN", "tok-env-123")
        from shared.api_utils import get_token
        assert get_token() == "tok-env-123"

    def test_returns_from_config_env_file(self, monkeypatch, tmp_path):
        monkeypatch.delenv("VAULTLAYER_TOKEN", raising=False)
        config_dir = tmp_path / ".vaultlayer"
        config_dir.mkdir()
        config_file = config_dir / "config.env"
        config_file.write_text("VAULTLAYER_TOKEN=tok-file-456\n")
        with patch("shared.api_utils.Path.home", return_value=tmp_path):
            from shared.api_utils import get_token
            assert get_token() == "tok-file-456"

    def test_returns_empty_when_nothing_set(self, monkeypatch, tmp_path):
        monkeypatch.delenv("VAULTLAYER_TOKEN", raising=False)
        # Point home to a tmp dir with no config.env
        with patch("shared.api_utils.Path.home", return_value=tmp_path):
            from shared.api_utils import get_token
            assert get_token() == ""


class TestGetAuthHeaders:
    def test_returns_bearer_header(self, monkeypatch):
        monkeypatch.setenv("VAULTLAYER_TOKEN", "tok-hdr")
        from shared.api_utils import get_auth_headers
        h = get_auth_headers()
        assert h == {"Authorization": "Bearer tok-hdr"}


class TestApiRequest:
    def test_success(self, monkeypatch):
        monkeypatch.setenv("VAULTLAYER_TOKEN", "tok")
        monkeypatch.delenv("VAULTLAYER_API_URL", raising=False)

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"ok": True}

        with patch("httpx.request", return_value=mock_resp) as mock_req:
            from shared.api_utils import api_request
            code, body = api_request("GET", "/api/v1/health")
            assert code == 200
            assert body == {"ok": True}
            mock_req.assert_called_once()
            call_args = mock_req.call_args
            assert call_args[0][0] == "GET"
            assert "/api/v1/health" in call_args[0][1]

    def test_handles_timeout(self, monkeypatch):
        monkeypatch.setenv("VAULTLAYER_TOKEN", "tok")
        monkeypatch.delenv("VAULTLAYER_API_URL", raising=False)

        import httpx
        with patch("httpx.request", side_effect=httpx.TimeoutException("timed out")):
            from shared.api_utils import api_request
            code, body = api_request("GET", "/api/v1/health")
            assert code == 0
            assert body is None


# ===========================================================================
# r2_utils
# ===========================================================================


class TestGetR2Credentials:
    def test_from_r2_env_vars(self, monkeypatch, _clean_env):
        monkeypatch.setenv("R2_ENDPOINT", "https://r2.example.com")
        monkeypatch.setenv("R2_ACCESS_KEY_ID", "ak-123")
        monkeypatch.setenv("R2_SECRET_ACCESS_KEY", "sk-456")
        monkeypatch.setenv("R2_BUCKET", "my-bucket")
        from shared.r2_utils import get_r2_credentials
        creds = get_r2_credentials()
        assert creds["endpoint"] == "https://r2.example.com"
        assert creds["access_key_id"] == "ak-123"
        assert creds["secret_access_key"] == "sk-456"
        assert creds["bucket"] == "my-bucket"

    def test_from_vaultlayer_r2_env_vars(self, monkeypatch, _clean_env):
        monkeypatch.setenv("VAULTLAYER_R2_ENDPOINT", "https://vl-r2.example.com")
        monkeypatch.setenv("VAULTLAYER_R2_ACCESS_KEY_ID", "vl-ak")
        monkeypatch.setenv("VAULTLAYER_R2_SECRET_ACCESS_KEY", "vl-sk")
        from shared.r2_utils import get_r2_credentials
        creds = get_r2_credentials()
        assert creds["endpoint"] == "https://vl-r2.example.com"
        assert creds["access_key_id"] == "vl-ak"
        assert creds["secret_access_key"] == "vl-sk"
        # default bucket
        assert creds["bucket"] == "vaultlayer-checkpoints"

    def test_no_api_fallback(self, monkeypatch, _clean_env):
        """API fallback was removed — get_r2_credentials never makes HTTP calls.
        When env vars are absent, returns {} without touching the network."""
        monkeypatch.setenv("VAULTLAYER_TOKEN", "tok-api")
        monkeypatch.delenv("VAULTLAYER_API_URL", raising=False)
        with patch("httpx.post") as mock_post:
            from shared.r2_utils import get_r2_credentials
            creds = get_r2_credentials(job_id="job-42")
            assert creds == {}
            mock_post.assert_not_called()

    def test_returns_empty_when_nothing_available(self, monkeypatch, _clean_env):
        # Ensure no real R2 env vars leak through from the host
        for prefix in ("R2_", "VAULTLAYER_R2_"):
            for suffix in ("ENDPOINT", "ACCESS_KEY_ID", "SECRET_ACCESS_KEY", "BUCKET"):
                monkeypatch.delenv(f"{prefix}{suffix}", raising=False)
        from shared.r2_utils import get_r2_credentials
        assert get_r2_credentials() == {}


# ===========================================================================
# env_utils
# ===========================================================================


class TestLoadVaultlayerEnv:
    def test_loads_config_env(self, monkeypatch, tmp_path):
        config_dir = tmp_path / ".vaultlayer"
        config_dir.mkdir()
        config_file = config_dir / "config.env"
        config_file.write_text("MY_TEST_VAR=hello\n")

        mock_load_dotenv = MagicMock()
        with patch("shared.env_utils.Path.home", return_value=tmp_path):
            # Patch load_dotenv at module level after import
            import shared.env_utils as eu
            with patch.object(eu, "load_dotenv", mock_load_dotenv, create=True), \
                 patch("shared.env_utils.load_dotenv", mock_load_dotenv, create=True):
                # Simpler approach: just call and check load_dotenv was invoked
                # We need dotenv importable
                from unittest.mock import MagicMock as MM
                fake_dotenv = MM()
                fake_dotenv.load_dotenv = mock_load_dotenv
                with patch.dict("sys.modules", {"dotenv": fake_dotenv}):
                    import importlib
                    importlib.reload(eu)
                    eu.load_vaultlayer_env()
                    assert mock_load_dotenv.called
                    # Verify it was called with config.env path
                    first_call_arg = str(mock_load_dotenv.call_args_list[0][0][0])
                    assert "config.env" in first_call_arg

    def test_handles_missing_dotenv_gracefully(self, monkeypatch):
        """When python-dotenv is not installed, load_vaultlayer_env should not raise."""
        with patch.dict("sys.modules", {"dotenv": None}):
            import importlib
            import shared.env_utils as eu
            importlib.reload(eu)
            # Should not raise
            eu.load_vaultlayer_env()


# ===========================================================================
# logging_utils
# ===========================================================================


class TestSetupCliLogging:
    def test_default_is_warning(self, monkeypatch):
        monkeypatch.delenv("VL_DEBUG", raising=False)
        with patch("logging.basicConfig") as mock_bc:
            from shared.logging_utils import setup_cli_logging
            setup_cli_logging(verbose=False)
            mock_bc.assert_called_once()
            assert mock_bc.call_args[1]["level"] == logging.WARNING

    def test_verbose_sets_debug(self, monkeypatch):
        monkeypatch.delenv("VL_DEBUG", raising=False)
        with patch("logging.basicConfig") as mock_bc:
            from shared.logging_utils import setup_cli_logging
            setup_cli_logging(verbose=True)
            mock_bc.assert_called_once()
            assert mock_bc.call_args[1]["level"] == logging.DEBUG

    def test_vl_debug_env_enables_debug(self, monkeypatch):
        monkeypatch.setenv("VL_DEBUG", "1")
        with patch("logging.basicConfig") as mock_bc:
            from shared.logging_utils import setup_cli_logging
            setup_cli_logging(verbose=False)
            mock_bc.assert_called_once()
            assert mock_bc.call_args[1]["level"] == logging.DEBUG


class TestGetLogger:
    def test_returns_named_logger(self):
        from shared.logging_utils import get_logger
        lg = get_logger("test.module.name")
        assert isinstance(lg, logging.Logger)
        assert lg.name == "test.module.name"


# ===========================================================================
# data_loader — dynamic config accessors
# ===========================================================================


@pytest.fixture()
def mock_data_json(tmp_path):
    """Create a minimal vaultlayer_data.json and patch _POSSIBLE_PATHS to find it."""
    data = {
        "_meta": {"last_updated": "2026-01-01"},
        "provider_prices": {"TestProvider": {"H100": 2.50}},
        "gpu_profiles": {"tiers": []},
        "gpu_aliases": {},
        "egress_rates": {
            "aws_s3": 0.09,
            "gcp_gcs": 0.10,
            "r2": 0.0,
        },
        "aws_on_demand_rates": {
            "H100": 12.29,
            "A100": 4.10,
        },
        "tier_config": {
            "tier_1_markup": 0.20,
            "tier_2_markup": 0.30,
            "tier_3_markup": 0.40,
            "scarcity_price_threshold": 5.00,
        },
        "operational": {
            "auto_migrate_savings_pct": 25.0,
            "migration_cooldown_secs": 21600,
            "payback_threshold_hours": 10.0,
            "pricing_margin": 1.15,
            "arbitrage_threshold": 10.0,
        },
    }
    json_path = tmp_path / "vaultlayer_data.json"
    json_path.write_text(json.dumps(data))

    import shared.data_loader as dl
    original = dl._POSSIBLE_PATHS[:]
    dl._POSSIBLE_PATHS.insert(0, json_path)
    dl._cache = None
    yield data
    # Restore
    dl._POSSIBLE_PATHS[:] = original
    dl._cache = None


class TestGetEgressRates:
    def test_returns_from_json(self, mock_data_json):
        from shared.data_loader import get_egress_rates
        rates = get_egress_rates()
        assert rates["aws_s3"] == 0.09
        assert rates["r2"] == 0.0

    def test_env_var_override(self, monkeypatch, mock_data_json):
        monkeypatch.setenv("VL_EGRESS_AWS_S3", "0.15")
        from shared.data_loader import get_egress_rates
        rates = get_egress_rates()
        assert rates["aws_s3"] == 0.15
        # Others unchanged
        assert rates["r2"] == 0.0


class TestGetAwsOdRates:
    def test_returns_from_json(self, mock_data_json):
        from shared.data_loader import get_aws_od_rates
        rates = get_aws_od_rates()
        assert rates["H100"] == 12.29
        assert rates["A100"] == 4.10

    def test_filters_meta_keys(self, mock_data_json):
        from shared.data_loader import get_aws_od_rates
        rates = get_aws_od_rates()
        assert all(not k.startswith("_") for k in rates)


class TestGetTierConfig:
    def test_returns_defaults(self, mock_data_json):
        from shared.data_loader import get_tier_config
        cfg = get_tier_config()
        assert cfg["tier_1_markup"] == 0.20
        assert cfg["tier_2_markup"] == 0.30
        assert cfg["tier_3_markup"] == 0.40
        assert cfg["scarcity_price_threshold"] == 5.00

    def test_env_var_overrides(self, monkeypatch, mock_data_json):
        monkeypatch.setenv("VL_TIER1_MARKUP", "0.25")
        monkeypatch.setenv("VL_SCARCITY_THRESHOLD", "8.0")
        from shared.data_loader import get_tier_config
        cfg = get_tier_config()
        assert cfg["tier_1_markup"] == 0.25
        assert cfg["scarcity_price_threshold"] == 8.0
        # Unset vars keep JSON defaults
        assert cfg["tier_2_markup"] == 0.30


class TestGetOperationalConfig:
    def test_returns_defaults(self, mock_data_json):
        from shared.data_loader import get_operational_config
        cfg = get_operational_config()
        assert cfg["auto_migrate_savings_pct"] == 25.0
        assert cfg["pricing_margin"] == 1.15

    def test_env_var_overrides(self, monkeypatch, mock_data_json):
        monkeypatch.setenv("VL_AUTO_MIGRATE_PCT", "30.0")
        monkeypatch.setenv("VL_PRICING_MARGIN", "1.20")
        from shared.data_loader import get_operational_config
        cfg = get_operational_config()
        assert cfg["auto_migrate_savings_pct"] == 30.0
        assert cfg["pricing_margin"] == 1.20
        # Others unchanged
        assert cfg["migration_cooldown_secs"] == 21600


class TestInvalidateCache:
    def test_forces_reload(self, mock_data_json, tmp_path):
        from shared.data_loader import get_tier_config, invalidate_cache
        import shared.data_loader as dl

        # First load
        cfg1 = get_tier_config()
        assert cfg1["tier_1_markup"] == 0.20

        # Mutate the JSON on disk
        json_path = tmp_path / "vaultlayer_data.json"
        data = json.loads(json_path.read_text())
        data["tier_config"]["tier_1_markup"] = 0.99
        json_path.write_text(json.dumps(data))

        # Without invalidate, cache would still return old value
        # (but we need to reset since get_tier_config copies from _load())
        invalidate_cache()
        cfg2 = get_tier_config()
        assert cfg2["tier_1_markup"] == 0.99
