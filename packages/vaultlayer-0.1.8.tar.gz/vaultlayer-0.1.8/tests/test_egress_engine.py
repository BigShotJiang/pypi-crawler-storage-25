"""
Tests for the Golden Ratio / 10-Hour Rule egress cost engine.

Coverage:
  - egress_rate()             — rate lookup per storage system
  - compute_egress_cost()     — dollar amount per dataset
  - is_same_cloud()           — affinity detection
  - golden_ratio()            — core pass/fail formula
  - compute_resume_cost()     — total cost estimate
  - rank_candidates_by_resume_cost() — sorted eligible list
  - OrchestrationAgent._select_provider() — end-to-end with real agent wiring
  - TERMINATION_SIGNAL path   — resume-cost log fires before decision
"""

import pytest
import math
from unittest.mock import AsyncMock, MagicMock, patch

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from agents.orchestration.egress import (
    EGRESS_RATES_USD_PER_GB,
    PAYBACK_THRESHOLD_HOURS,
    egress_rate,
    compute_egress_cost,
    is_same_cloud,
    golden_ratio,
    compute_resume_cost,
    rank_candidates_by_resume_cost,
    EgressVerdict,
    ResumeCostEstimate,
)
from shared.models import Provider, GPUType, Job, JobStatus


# ── Helpers ───────────────────────────────────────────────────────────────────

def _job(
    provider=Provider.AWS,
    dataset_size_gb=100.0,
    dataset_location="s3",
    dataset_cloud="",
    training_duration_hours=20.0,
) -> Job:
    return Job(
        job_id="test-egress-01",
        name="egress-test",
        provider=provider,
        gpu_type=GPUType.A100_40GB,
        status=JobStatus.RUNNING,
        dataset_size_gb=dataset_size_gb,
        dataset_location=dataset_location,
        dataset_cloud=dataset_cloud,
        training_duration_hours=training_duration_hours,
    )


def _price_entry(provider: str, gpu: str, price: float, avail: str = "high") -> dict:
    return {"provider": provider, "gpu": gpu, "price_per_hour": price, "availability": avail}


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Egress rate table
# ═══════════════════════════════════════════════════════════════════════════════

class TestEgressRateTable:
    def test_s3_rate(self):
        assert egress_rate("s3") == 0.09

    def test_gcs_rate(self):
        assert egress_rate("gcs") == 0.10

    def test_azure_blob_rate(self):
        assert egress_rate("azure_blob") == 0.085

    def test_r2_zero(self):
        assert egress_rate("r2") == 0.00

    def test_local_zero(self):
        assert egress_rate("local") == 0.00

    def test_unknown_falls_back_to_default(self):
        # Unknown storage → conservative AWS-style default
        assert egress_rate("unknown_storage") == 0.09


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Compute egress cost
# ═══════════════════════════════════════════════════════════════════════════════

class TestComputeEgressCost:
    def test_scenario_a_small_dataset(self):
        """Scenario A: 100 GB × $0.09 = $9.00"""
        cost = compute_egress_cost(100.0, "s3")
        assert cost == pytest.approx(9.00, abs=0.001)

    def test_scenario_b_large_dataset(self):
        """Scenario B: 5000 GB × $0.09 = $450.00"""
        cost = compute_egress_cost(5000.0, "s3")
        assert cost == pytest.approx(450.00, abs=0.001)

    def test_r2_always_zero(self):
        assert compute_egress_cost(999_999.0, "r2") == 0.00

    def test_local_always_zero(self):
        assert compute_egress_cost(10_000.0, "local") == 0.00

    def test_gcs_large(self):
        cost = compute_egress_cost(1000.0, "gcs")
        assert cost == pytest.approx(100.00, abs=0.001)

    def test_azure_100gb(self):
        cost = compute_egress_cost(100.0, "azure_blob")
        assert cost == pytest.approx(8.50, abs=0.001)

    def test_zero_dataset_size(self):
        assert compute_egress_cost(0.0, "s3") == 0.00


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Same-cloud detection
# ═══════════════════════════════════════════════════════════════════════════════

class TestIsSameCloud:
    # R2 / local are always zero-egress
    def test_r2_any_target_is_same_cloud(self):
        assert is_same_cloud("runpod", "r2") is True
        assert is_same_cloud("aws", "r2") is True
        assert is_same_cloud("gcp", "r2") is True

    def test_local_any_target_is_same_cloud(self):
        assert is_same_cloud("nebius", "local") is True

    # S3 → only AWS is home cloud
    def test_s3_aws_is_same(self):
        assert is_same_cloud("aws", "s3") is True

    def test_s3_runpod_is_cross(self):
        assert is_same_cloud("runpod", "s3") is False

    def test_s3_lambda_labs_is_cross(self):
        assert is_same_cloud("lambda_labs", "s3") is False

    # GCS → only GCP is home cloud
    def test_gcs_gcp_is_same(self):
        assert is_same_cloud("gcp", "gcs") is True

    def test_gcs_aws_is_cross(self):
        assert is_same_cloud("aws", "gcs") is False

    # Azure Blob → only Azure is home cloud
    def test_azure_blob_azure_is_same(self):
        assert is_same_cloud("azure", "azure_blob") is True

    def test_azure_blob_coreweave_is_cross(self):
        assert is_same_cloud("coreweave", "azure_blob") is False

    # Explicit dataset_cloud override
    def test_explicit_cloud_override_wins(self):
        # dataset_location="s3" but dataset_cloud="aws" → aws is home cloud
        assert is_same_cloud("aws", "s3", dataset_cloud="aws") is True

    def test_explicit_cloud_override_blocks_cross(self):
        assert is_same_cloud("runpod", "s3", dataset_cloud="aws") is False

    def test_explicit_cloud_override_gcp(self):
        assert is_same_cloud("gcp", "s3", dataset_cloud="gcp") is True


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Golden Ratio core formula
# ═══════════════════════════════════════════════════════════════════════════════

class TestGoldenRatio:
    """
    Scenario A — Fine-Tuning (small data, high savings): ALLOWED
    Dataset: 100 GB → egress $9.00
    Delta:   $3.00/hr (source $5.00, target $2.00)
    Payback: 9.00 / 3.00 = 3 hours ≤ 10 → ALLOWED

    Scenario B — Heavy Pre-Training (large data, modest savings): BLOCKED
    Dataset: 5000 GB → egress $450.00
    Delta:   $5.00/hr
    Payback: 450.00 / 5.00 = 90 hours > 10 → BLOCKED
    """

    def test_scenario_a_allowed(self):
        verdict = golden_ratio(
            dataset_size_gb=100.0,
            dataset_location="s3",
            dataset_cloud="",
            source_provider_value="aws",
            target_provider_value="runpod",
            hourly_compute_delta=3.00,
        )
        assert verdict.allowed is True
        assert verdict.egress_cost_usd == pytest.approx(9.00, abs=0.01)
        assert verdict.payback_hours == pytest.approx(3.0, abs=0.01)
        assert verdict.same_cloud is False

    def test_scenario_b_blocked(self):
        verdict = golden_ratio(
            dataset_size_gb=5000.0,
            dataset_location="s3",
            dataset_cloud="",
            source_provider_value="aws",
            target_provider_value="crusoe",
            hourly_compute_delta=5.00,
        )
        assert verdict.allowed is False
        assert verdict.egress_cost_usd == pytest.approx(450.00, abs=0.01)
        assert verdict.payback_hours == pytest.approx(90.0, abs=0.01)
        assert verdict.same_cloud is False

    def test_exact_threshold_boundary_allowed(self):
        """payback = exactly 10 hours → allowed (≤ threshold)"""
        verdict = golden_ratio(
            dataset_size_gb=100.0,
            dataset_location="s3",
            dataset_cloud="",
            source_provider_value="aws",
            target_provider_value="runpod",
            hourly_compute_delta=0.90,   # 9.00 / 0.90 = 10.0 exactly
        )
        assert verdict.allowed is True
        assert verdict.payback_hours == pytest.approx(10.0, abs=0.01)

    def test_one_hour_over_threshold_blocked(self):
        """payback = 11 hours → blocked"""
        verdict = golden_ratio(
            dataset_size_gb=100.0,
            dataset_location="s3",
            dataset_cloud="",
            source_provider_value="aws",
            target_provider_value="runpod",
            hourly_compute_delta=9.00 / 11,  # 11hr payback
        )
        assert verdict.allowed is False

    def test_same_cloud_always_allowed(self):
        """AWS → AWS (spot replacement): zero egress, always allowed"""
        verdict = golden_ratio(
            dataset_size_gb=50_000.0,   # even 50 TB datasets
            dataset_location="s3",
            dataset_cloud="",
            source_provider_value="aws",
            target_provider_value="aws",
            hourly_compute_delta=1.00,
        )
        assert verdict.allowed is True
        assert verdict.egress_cost_usd == 0.0
        assert verdict.payback_hours == 0.0
        assert verdict.same_cloud is True

    def test_r2_dataset_always_allowed_cross_cloud(self):
        """R2 dataset: zero egress regardless of target"""
        verdict = golden_ratio(
            dataset_size_gb=100_000.0,
            dataset_location="r2",
            dataset_cloud="",
            source_provider_value="aws",
            target_provider_value="nebius",
            hourly_compute_delta=0.01,  # tiny delta that would fail ratio if egress > 0
        )
        assert verdict.allowed is True
        assert verdict.egress_cost_usd == 0.0
        assert verdict.same_cloud is True

    def test_negative_delta_blocked(self):
        """Target is MORE expensive than source → always blocked (cross-cloud path)"""
        # source=runpod, target=lambda_labs — both cross-cloud from S3's AWS home
        verdict = golden_ratio(
            dataset_size_gb=1.0,
            dataset_location="s3",
            dataset_cloud="",
            source_provider_value="runpod",
            target_provider_value="lambda_labs",  # cross-cloud (not AWS)
            hourly_compute_delta=-2.00,  # moving to pricier cloud
        )
        assert verdict.allowed is False
        assert math.isinf(verdict.payback_hours)

    def test_zero_delta_blocked(self):
        """Equal price → blocked (no compute savings to fund egress)"""
        verdict = golden_ratio(
            dataset_size_gb=10.0,
            dataset_location="s3",
            dataset_cloud="",
            source_provider_value="aws",
            target_provider_value="crusoe",
            hourly_compute_delta=0.0,
        )
        assert verdict.allowed is False
        assert math.isinf(verdict.payback_hours)

    def test_zero_dataset_always_allowed(self):
        """Zero dataset size → zero egress → always allowed"""
        verdict = golden_ratio(
            dataset_size_gb=0.0,
            dataset_location="s3",
            dataset_cloud="",
            source_provider_value="aws",
            target_provider_value="runpod",
            hourly_compute_delta=0.01,
        )
        assert verdict.allowed is True
        assert verdict.egress_cost_usd == 0.0

    def test_custom_threshold(self):
        """Caller can override the payback threshold"""
        # 9.00 / 3.00 = 3hr payback — blocked under threshold=2, allowed under threshold=5
        base = dict(
            dataset_size_gb=100.0,
            dataset_location="s3",
            dataset_cloud="",
            source_provider_value="aws",
            target_provider_value="runpod",
            hourly_compute_delta=3.00,
        )
        assert golden_ratio(**base, payback_threshold_hours=2.0).allowed is False
        assert golden_ratio(**base, payback_threshold_hours=5.0).allowed is True

    def test_gcs_source_gcp_target_same_cloud(self):
        """GCS dataset migrating to a GCP spot instance → same cloud, zero egress"""
        verdict = golden_ratio(
            dataset_size_gb=500.0,
            dataset_location="gcs",
            dataset_cloud="",
            source_provider_value="gcp",
            target_provider_value="gcp",
            hourly_compute_delta=2.00,
        )
        assert verdict.same_cloud is True
        assert verdict.egress_cost_usd == 0.0

    def test_gcs_source_runpod_target_cross_cloud(self):
        """GCS dataset migrating to RunPod → cross-cloud, rate $0.10/GB"""
        verdict = golden_ratio(
            dataset_size_gb=100.0,
            dataset_location="gcs",
            dataset_cloud="",
            source_provider_value="gcp",
            target_provider_value="runpod",
            hourly_compute_delta=3.00,
        )
        assert verdict.same_cloud is False
        assert verdict.egress_cost_usd == pytest.approx(10.00, abs=0.01)  # 100 × 0.10
        payback = 10.00 / 3.00  # ≈ 3.33 hrs
        assert verdict.payback_hours == pytest.approx(payback, abs=0.05)
        assert verdict.allowed is True  # 3.33 ≤ 10

    def test_reason_string_present(self):
        verdict = golden_ratio(
            dataset_size_gb=100.0, dataset_location="s3", dataset_cloud="",
            source_provider_value="aws", target_provider_value="vast_ai",
            hourly_compute_delta=3.0,
        )
        assert len(verdict.reason) > 10
        assert "payback" in verdict.reason.lower() or "egress" in verdict.reason.lower() or "same" in verdict.reason.lower()


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Resume cost estimate
# ═══════════════════════════════════════════════════════════════════════════════

class TestComputeResumeCost:
    def test_same_cloud_zero_egress(self):
        est = compute_resume_cost(
            destination_provider="aws",
            target_price_per_hour=2.50,
            remaining_hours=5.0,
            dataset_size_gb=100.0,
            dataset_location="s3",
        )
        assert est.egress_cost_usd == 0.0
        assert est.compute_cost_usd == pytest.approx(12.50, abs=0.01)
        assert est.total_cost_usd == pytest.approx(12.50, abs=0.01)

    def test_cross_cloud_includes_egress(self):
        est = compute_resume_cost(
            destination_provider="runpod",
            target_price_per_hour=1.50,
            remaining_hours=10.0,
            dataset_size_gb=100.0,
            dataset_location="s3",
        )
        assert est.egress_cost_usd == pytest.approx(9.00, abs=0.01)   # 100 × 0.09
        assert est.compute_cost_usd == pytest.approx(15.00, abs=0.01)  # 1.50 × 10
        assert est.total_cost_usd == pytest.approx(24.00, abs=0.01)

    def test_r2_dataset_zero_egress_cross_cloud(self):
        est = compute_resume_cost(
            destination_provider="nebius",
            target_price_per_hour=2.00,
            remaining_hours=8.0,
            dataset_size_gb=5000.0,
            dataset_location="r2",
        )
        assert est.egress_cost_usd == 0.0
        assert est.total_cost_usd == pytest.approx(16.00, abs=0.01)


# ═══════════════════════════════════════════════════════════════════════════════
# 6. rank_candidates_by_resume_cost
# ═══════════════════════════════════════════════════════════════════════════════

class TestRankCandidates:
    CANDIDATES = [
        _price_entry("aws",        "A10G",       2.40),
        _price_entry("lambda_labs","A100_40GB",  1.80),
        _price_entry("runpod",     "A100_40GB",  1.20),
        _price_entry("nebius",     "H100_80GB_PCIE", 2.00),
        _price_entry("vast_ai",    "RTX4090",    0.50),
    ]

    def test_same_cloud_candidate_always_first_when_cheapest(self):
        """AWS spot replacement: zero egress → lowest total cost."""
        ranked = rank_candidates_by_resume_cost(
            candidates=[
                _price_entry("aws",    "A10G",    1.50),
                _price_entry("runpod", "A100_40GB", 0.80),
            ],
            source_provider_value="aws",
            dataset_size_gb=5000.0,  # 5TB: cross-cloud egress = $450 — kills payback
            dataset_location="s3",
            dataset_cloud="",
            remaining_hours=5.0,
        )
        # runpod is cheaper on compute but $450 egress makes it total $454 vs AWS $7.50
        eligible = [r for r in ranked if r[2].allowed]
        assert eligible[0][0]["provider"] == "aws"

    def test_cheap_cross_cloud_wins_when_egress_is_small(self):
        """Small dataset: cross-cloud provider with big savings should rank first."""
        ranked = rank_candidates_by_resume_cost(
            candidates=[
                _price_entry("aws",    "A10G",       3.00),
                _price_entry("runpod", "A100_40GB",  0.50),
            ],
            source_provider_value="aws",
            dataset_size_gb=10.0,  # tiny dataset: $0.90 egress
            dataset_location="s3",
            dataset_cloud="",
            remaining_hours=20.0,
        )
        eligible = [r for r in ranked if r[2].allowed]
        assert eligible[0][0]["provider"] == "runpod"  # $0.50×20 + $0.90 = $10.90 < $3×20 = $60

    def test_blocked_candidates_appear_at_end(self):
        """Blocked paths are included in the output but after eligible ones."""
        ranked = rank_candidates_by_resume_cost(
            candidates=[
                _price_entry("aws",    "A10G",       3.00),
                _price_entry("crusoe", "A100_40GB",  2.95),  # barely cheaper: delta $0.05
            ],
            source_provider_value="aws",
            dataset_size_gb=5000.0,  # $450 egress / $0.05 delta = 9000hr payback → blocked
            dataset_location="s3",
            dataset_cloud="",
            remaining_hours=20.0,
        )
        allowed_provs = [r[0]["provider"] for r in ranked if r[2].allowed]
        blocked_provs = [r[0]["provider"] for r in ranked if not r[2].allowed]
        assert "aws" in allowed_provs
        assert "crusoe" in blocked_provs

    def test_all_candidates_blocked_returns_empty_eligible(self):
        """5TB + tiny savings = everything is blocked (except same-cloud)."""
        # Remove the source (aws) from candidates to test pure cross-cloud scenario
        ranked = rank_candidates_by_resume_cost(
            candidates=[
                _price_entry("runpod", "A100_40GB", 2.99),  # $0.01 delta, $450 egress → 45000hr
                _price_entry("crusoe", "A100_40GB", 2.98),  # $0.02 delta → 22500hr
            ],
            source_provider_value="aws",
            dataset_size_gb=5000.0,
            dataset_location="s3",
            dataset_cloud="",
            remaining_hours=10.0,
        )
        eligible = [r for r in ranked if r[2].allowed]
        assert len(eligible) == 0

    def test_r2_dataset_no_cross_cloud_penalty(self):
        """R2 dataset: cross-cloud is free, cheapest compute wins."""
        ranked = rank_candidates_by_resume_cost(
            candidates=[
                _price_entry("aws",    "A10G",       3.00),
                _price_entry("vast_ai","RTX4090",    0.30),
            ],
            source_provider_value="aws",
            dataset_size_gb=100_000.0,
            dataset_location="r2",   # zero egress
            dataset_cloud="",
            remaining_hours=5.0,
        )
        eligible = [r for r in ranked if r[2].allowed]
        # vast_ai cheapest compute, no egress penalty → wins
        assert eligible[0][0]["provider"] == "vast_ai"

    def test_output_length_equals_input_length(self):
        ranked = rank_candidates_by_resume_cost(
            candidates=self.CANDIDATES,
            source_provider_value="aws",
            dataset_size_gb=100.0,
            dataset_location="s3",
            dataset_cloud="",
            remaining_hours=10.0,
        )
        assert len(ranked) == len(self.CANDIDATES)


# ═══════════════════════════════════════════════════════════════════════════════
# 7. OrchestrationAgent._select_provider integration
# ═══════════════════════════════════════════════════════════════════════════════

class TestSelectProviderEgressIntegration:
    """
    End-to-end tests: _select_provider must apply the Golden Ratio gate
    and prefer same-cloud candidates when the cross-cloud payback is too long.
    """

    def _make_agent(self, job: Job):
        from agents.orchestration.agent import OrchestrationAgent
        from shared.config import VaultLayerConfig, AnthropicConfig, CloudflareConfig

        cfg = MagicMock(spec=VaultLayerConfig)
        cfg.anthropic = None
        cfg.confidence_threshold_auto = 0.9
        cfg.cloudflare = MagicMock()

        queue = MagicMock()

        agent = OrchestrationAgent(config=cfg, queue=queue)
        agent._active_jobs[job.job_id] = job
        return agent

    def test_large_dataset_prefers_same_cloud(self):
        """
        5 TB dataset on S3: cross-cloud egress = $450.
        AWS same-cloud candidate at $2.40/hr must win over Crusoe at $2.00/hr
        because 450 / 0.40 = 1125hr payback > 10hr threshold.
        """
        job = _job(
            provider=Provider.AWS,
            dataset_size_gb=5000.0,
            dataset_location="s3",
            training_duration_hours=50.0,
        )
        agent = self._make_agent(job)
        price_cache = [
            _price_entry("aws",   "A10G",     3.00),  # source price
            _price_entry("aws",   "A10G",     2.40),  # same-cloud cheaper spot AZ
            _price_entry("crusoe","A100_40GB", 2.00),  # cross-cloud, but egress kills it
        ]
        prov, gpu, savings, pct = agent._select_provider(price_cache, job.job_id, Provider.AWS)
        assert prov == Provider.AWS   # same-cloud wins
        assert savings > 0

    def test_small_dataset_allows_cross_cloud(self):
        """
        100 GB dataset on S3: egress = $9.
        RunPod at $1.20/hr saves $1.80/hr vs AWS at $3.00: payback = 9/1.80 = 5hr ≤ 10.
        RunPod should win (lower total resume cost).
        """
        job = _job(
            provider=Provider.AWS,
            dataset_size_gb=100.0,
            dataset_location="s3",
            training_duration_hours=20.0,
        )
        agent = self._make_agent(job)
        price_cache = [
            _price_entry("aws",    "A10G",     3.00),
            _price_entry("runpod", "A100_40GB", 1.20),
        ]
        prov, gpu, savings, pct = agent._select_provider(price_cache, job.job_id, Provider.AWS)
        assert prov == Provider.RUNPOD

    def test_r2_dataset_allows_any_cross_cloud(self):
        """R2 dataset: zero egress → cheapest provider always wins."""
        job = _job(
            provider=Provider.AWS,
            dataset_size_gb=999_999.0,  # massive dataset, irrelevant for R2
            dataset_location="r2",
            training_duration_hours=10.0,
        )
        agent = self._make_agent(job)
        price_cache = [
            _price_entry("aws",    "A10G",     5.00),
            _price_entry("vast_ai","RTX4090",  0.30),
        ]
        prov, gpu, savings, pct = agent._select_provider(price_cache, job.job_id, Provider.AWS)
        assert prov == Provider.VAST_AI

    def test_no_candidates_returns_none_tuple(self):
        job = _job()
        agent = self._make_agent(job)
        prov, gpu, s, p = agent._select_provider([], job.job_id, Provider.AWS)
        assert prov is None
        assert gpu is None
        assert s == 0.0
        assert p == 0.0

    def test_all_blocked_returns_none(self):
        """If every cross-cloud candidate fails the ratio and no same-cloud exists."""
        job = _job(
            provider=Provider.AWS,
            dataset_size_gb=5000.0,
            dataset_location="s3",
            training_duration_hours=1.0,
        )
        agent = self._make_agent(job)
        price_cache = [
            # All cross-cloud, all fail 10hr rule (delta $0.01 → payback 45000hr)
            _price_entry("runpod", "A100_40GB", 2.99),
            _price_entry("vast_ai","RTX4090",   2.98),
        ]
        prov, gpu, s, p = agent._select_provider(price_cache, job.job_id, Provider.AWS)
        assert prov is None

    def test_egress_verdict_stashed_on_instance(self):
        """After _select_provider(), _last_egress_verdict must be populated."""
        job = _job(
            provider=Provider.AWS,
            dataset_size_gb=100.0,
            dataset_location="s3",
            training_duration_hours=20.0,
        )
        agent = self._make_agent(job)
        price_cache = [
            _price_entry("aws",    "A10G",     3.00),
            _price_entry("runpod", "A100_40GB", 1.20),
        ]
        agent._select_provider(price_cache, job.job_id, Provider.AWS)
        assert agent._last_egress_verdict is not None
        assert agent._last_resume_estimate is not None

    def test_scenario_a_full_path(self):
        """Scenario A from the spec: 100 GB, $3/hr savings → payback 3hr → cross-cloud ALLOWED."""
        job = _job(
            provider=Provider.AWS,
            dataset_size_gb=100.0,
            dataset_location="s3",
            training_duration_hours=20.0,
        )
        agent = self._make_agent(job)
        price_cache = [
            _price_entry("aws",    "A10G",      5.00),  # source
            _price_entry("runpod", "A100_40GB", 2.00),  # saves $3/hr
        ]
        prov, gpu, savings, pct = agent._select_provider(price_cache, job.job_id, Provider.AWS)
        assert prov == Provider.RUNPOD
        verdict = agent._last_egress_verdict
        assert verdict.allowed is True
        assert verdict.payback_hours == pytest.approx(3.0, abs=0.05)

    def test_scenario_b_full_path(self):
        """Scenario B from the spec: 5000 GB, $5/hr savings → payback 90hr → BLOCKED."""
        job = _job(
            provider=Provider.AWS,
            dataset_size_gb=5000.0,
            dataset_location="s3",
            training_duration_hours=20.0,
        )
        agent = self._make_agent(job)
        price_cache = [
            _price_entry("aws",    "A10G",      8.00),  # source
            _price_entry("crusoe", "A100_40GB", 3.00),  # saves $5/hr, but $450 egress
        ]
        # No same-cloud spot available → returns None
        prov, gpu, savings, pct = agent._select_provider(price_cache, job.job_id, Provider.AWS)
        assert prov is None  # Crusoe blocked, no AWS spot alternative


# ═══════════════════════════════════════════════════════════════════════════════
# 8. OrchestrationDecision carries egress fields
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_decision_carries_egress_fields():
    """
    _make_deterministic_decision() must embed egress_cost_usd, payback_hours,
    same_cloud_hop, and resume_total_cost_usd in the returned decision.
    """
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType, OrchestrationDecision
    from shared.config import VaultLayerConfig

    job = _job(
        provider=Provider.AWS,
        dataset_size_gb=100.0,
        dataset_location="s3",
        training_duration_hours=20.0,
    )

    cfg = MagicMock(spec=VaultLayerConfig)
    cfg.anthropic = None
    cfg.confidence_threshold_auto = 0.9
    cfg.cloudflare = MagicMock()

    queue = AsyncMock()
    queue.get_price_cache = AsyncMock(return_value=[
        _price_entry("aws",    "A10G",      5.00),
        _price_entry("runpod", "A100_40GB", 2.00),  # saves $3/hr, 3hr payback → allowed
    ])

    agent = OrchestrationAgent(config=cfg, queue=queue)
    agent._active_jobs[job.job_id] = job

    event = AgentEvent(
        event_type=EventType.TERMINATION_SIGNAL,
        source_agent="watchdog_agent",
        job_id=job.job_id,
        payload={"exit_code": -15, "job_age_secs": 3600},
    )

    decision = await agent._make_deterministic_decision(event, "test reason", confidence=0.99)

    assert isinstance(decision, OrchestrationDecision)
    assert decision.target_provider == Provider.RUNPOD
    assert decision.egress_cost_usd == pytest.approx(9.00, abs=0.05)
    assert decision.payback_hours == pytest.approx(3.0, abs=0.1)
    assert decision.same_cloud_hop is False
    assert decision.resume_total_cost_usd > 0
    assert "egress" in decision.egress_verdict.lower() or "payback" in decision.egress_verdict.lower()


@pytest.mark.asyncio
async def test_same_cloud_decision_has_zero_egress():
    """Same-cloud replacement must have egress_cost=0 and same_cloud_hop=True."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    from shared.config import VaultLayerConfig

    job = _job(
        provider=Provider.AWS,
        dataset_size_gb=5000.0,  # massive dataset, but same-cloud
        dataset_location="s3",
        training_duration_hours=50.0,
    )

    cfg = MagicMock(spec=VaultLayerConfig)
    cfg.anthropic = None
    cfg.confidence_threshold_auto = 0.9
    cfg.cloudflare = MagicMock()

    queue = AsyncMock()
    queue.get_price_cache = AsyncMock(return_value=[
        _price_entry("aws", "A10G", 3.00),   # source
        _price_entry("aws", "A10G", 2.40),   # same-cloud cheaper AZ
    ])

    agent = OrchestrationAgent(config=cfg, queue=queue)
    agent._active_jobs[job.job_id] = job

    event = AgentEvent(
        event_type=EventType.TERMINATION_SIGNAL,
        source_agent="watchdog_agent",
        job_id=job.job_id,
        payload={"exit_code": -15, "job_age_secs": 3600},
    )

    decision = await agent._make_deterministic_decision(event, "spot termination", confidence=0.99)

    assert decision.target_provider == Provider.AWS
    assert decision.same_cloud_hop is True
    assert decision.egress_cost_usd == 0.0
    assert "zero egress" in decision.reasoning or "same-cloud" in decision.reasoning


# ═══════════════════════════════════════════════════════════════════════════════
# 9. Emergency egress gate — TERMINATION_SIGNAL / HEARTBEAT_MISS
# ═══════════════════════════════════════════════════════════════════════════════

class TestGoldenRatioEmergency:
    """
    Emergency migrations (TERMINATION_SIGNAL, HEARTBEAT_MISS) must bypass the
    10-Hour payback gate entirely.  The egress cost is still calculated and
    recorded for FinOps but NEVER blocks the hop.
    """

    def test_emergency_allows_cross_cloud_despite_high_payback(self):
        """5 TB dataset on S3 → RunPod.  Payback ≈ 90 hrs normally blocked; allowed in emergency."""
        # 5000 GB × $0.09 = $450 egress; delta = $1/hr → payback = 450 hrs
        verdict = golden_ratio(
            dataset_size_gb=5000.0,
            dataset_location="s3",
            dataset_cloud="aws",
            source_provider_value="aws",
            target_provider_value="runpod",
            hourly_compute_delta=1.0,   # source costs $1/hr more
            payback_threshold_hours=10.0,
            emergency=True,
        )
        assert verdict.allowed is True
        assert verdict.same_cloud is False
        assert verdict.egress_cost_usd == 450.0
        assert verdict.payback_hours == 450.0
        assert "emergency" in verdict.reason.lower()
        assert "egress gate suspended" in verdict.reason.lower()

    def test_emergency_records_egress_cost_for_finops(self):
        """Egress cost must be non-zero and embedded in verdict even under emergency."""
        verdict = golden_ratio(
            dataset_size_gb=1000.0,
            dataset_location="gcs",
            dataset_cloud="gcp",
            source_provider_value="gcp",
            target_provider_value="lambda_labs",
            hourly_compute_delta=2.0,
            emergency=True,
        )
        # 1000 GB × $0.10 = $100 egress
        assert verdict.egress_cost_usd == 100.0
        assert verdict.allowed is True
        assert "100.00" in verdict.reason or "FinOps" in verdict.reason

    def test_emergency_with_negative_delta_still_allowed(self):
        """
        Emergency migration to a MORE expensive cross-cloud provider must still be
        allowed — the source node is dead, there is no choice.
        Use GCS → RunPod (genuinely cross-cloud) to avoid the same-cloud short-circuit.
        """
        verdict = golden_ratio(
            dataset_size_gb=200.0,
            dataset_location="gcs",
            dataset_cloud="gcp",
            source_provider_value="gcp",
            target_provider_value="runpod",  # cross-cloud from GCS's home (GCP)
            hourly_compute_delta=-1.0,        # target costs more
            emergency=True,
        )
        assert verdict.allowed is True
        assert verdict.payback_hours == float("inf")
        assert "emergency" in verdict.reason.lower()

    def test_voluntary_large_dataset_still_blocked(self):
        """Same 5TB dataset but VOLUNTARY migration — payback gate must reject it."""
        verdict = golden_ratio(
            dataset_size_gb=5000.0,
            dataset_location="s3",
            dataset_cloud="aws",
            source_provider_value="aws",
            target_provider_value="runpod",
            hourly_compute_delta=1.0,
            payback_threshold_hours=10.0,
            emergency=False,   # voluntary
        )
        assert verdict.allowed is False
        assert verdict.payback_hours == 450.0
        assert "blocked" in verdict.reason.lower()

    def test_emergency_same_cloud_unchanged(self):
        """Same-cloud hops are always allowed regardless of emergency flag."""
        for emerg in (True, False):
            verdict = golden_ratio(
                dataset_size_gb=5000.0,
                dataset_location="s3",
                dataset_cloud="aws",
                source_provider_value="aws",
                target_provider_value="aws",
                hourly_compute_delta=0.5,
                emergency=emerg,
            )
            assert verdict.allowed is True
            assert verdict.same_cloud is True
            assert verdict.egress_cost_usd == 0.0


class TestRankCandidatesEmergency:
    """rank_candidates_by_resume_cost() must thread emergency flag through to golden_ratio."""

    def _large_s3_candidates(self):
        return [
            {"provider": "aws",          "gpu": "A100_40GB", "price_per_hour": 5.00},
            {"provider": "runpod",        "gpu": "A100_40GB", "price_per_hour": 4.00},
            {"provider": "lambda_labs",   "gpu": "A100_40GB", "price_per_hour": 3.50},
        ]

    def test_emergency_all_candidates_eligible(self):
        """
        5 TB on S3.  In normal mode only aws (same-cloud) is eligible.
        In emergency mode all 3 must be allowed.
        """
        candidates = self._large_s3_candidates()
        results = rank_candidates_by_resume_cost(
            candidates=candidates,
            source_provider_value="aws",
            dataset_size_gb=5000.0,
            dataset_location="s3",
            dataset_cloud="aws",
            remaining_hours=10.0,
            payback_threshold_hours=10.0,
            emergency=True,
        )
        allowed = [r for r in results if r[2].allowed]
        assert len(allowed) == 3, "All 3 providers must be eligible under emergency"

    def test_voluntary_only_same_cloud_eligible(self):
        """Same setup, voluntary — only aws is eligible (same-cloud)."""
        candidates = self._large_s3_candidates()
        results = rank_candidates_by_resume_cost(
            candidates=candidates,
            source_provider_value="aws",
            dataset_size_gb=5000.0,
            dataset_location="s3",
            dataset_cloud="aws",
            remaining_hours=10.0,
            payback_threshold_hours=10.0,
            emergency=False,
        )
        allowed = [r for r in results if r[2].allowed]
        assert len(allowed) == 1
        assert allowed[0][0]["provider"] == "aws"

    def test_emergency_cheapest_wins_after_egress(self):
        """
        Under emergency the cheapest total (compute + egress) must be ranked first.
        AWS (same-cloud) wins at $50 total because it has zero egress:
          aws:         5.00 × 10 + 0   = $50  ← cheapest
          lambda_labs: 3.50 × 10 + 450 = $485
          runpod:      4.00 × 10 + 450 = $490

        Among the pure cross-cloud candidates lambda_labs ranks above runpod.
        """
        candidates = self._large_s3_candidates()
        results = rank_candidates_by_resume_cost(
            candidates=candidates,
            source_provider_value="aws",
            dataset_size_gb=5000.0,
            dataset_location="s3",
            dataset_cloud="aws",
            remaining_hours=10.0,
            payback_threshold_hours=10.0,
            emergency=True,
        )
        allowed = [r for r in results if r[2].allowed]
        # Overall cheapest is AWS (same-cloud, zero egress)
        assert allowed[0][0]["provider"] == "aws"
        # Among cross-cloud candidates lambda_labs beats runpod ($485 vs $490)
        cross_cloud = [r for r in allowed if r[0]["provider"] != "aws"]
        assert cross_cloud[0][0]["provider"] == "lambda_labs"


@pytest.mark.asyncio
async def test_termination_signal_bypasses_egress_gate():
    """
    End-to-end: TERMINATION_SIGNAL with a 5 TB S3 dataset where only cross-cloud
    providers are available.  The orchestration agent must select a provider
    (not return None) because emergency=True suspends the payback gate.
    """
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    from shared.config import VaultLayerConfig

    # 5 TB dataset on S3 — cross-cloud egress cost = $450
    # Only RunPod is available (cross-cloud from AWS)
    job = _job(
        provider=Provider.AWS,
        dataset_size_gb=5000.0,
        dataset_location="s3",
        dataset_cloud="aws",
        training_duration_hours=40.0,
    )

    cfg = MagicMock(spec=VaultLayerConfig)
    cfg.anthropic = None
    cfg.confidence_threshold_auto = 0.9
    cfg.cloudflare = MagicMock()

    queue = AsyncMock()
    queue.get_price_cache = AsyncMock(return_value=[
        # No AWS capacity — only cross-cloud available
        _price_entry("runpod",      "A100_40GB", 3.00),
        _price_entry("lambda_labs", "A100_40GB", 3.50),
    ])

    agent = OrchestrationAgent(config=cfg, queue=queue)
    agent._active_jobs[job.job_id] = job

    event = AgentEvent(
        event_type=EventType.TERMINATION_SIGNAL,
        source_agent="watchdog_agent",
        job_id=job.job_id,
        payload={"exit_code": -15},
    )

    decision = await agent._make_deterministic_decision(event, "spot termination", confidence=0.99)

    # Must pick a provider — not None — even though egress payback is 450 hrs
    assert decision.target_provider is not None, (
        "TERMINATION_SIGNAL must select a provider even with high egress payback"
    )
    assert decision.target_provider in (Provider.RUNPOD, Provider.LAMBDA_LABS)
    # Egress cost must be recorded
    assert decision.egress_cost_usd == 450.0
    assert decision.same_cloud_hop is False


@pytest.mark.asyncio
async def test_heartbeat_miss_bypasses_egress_gate():
    """
    HEARTBEAT_MISS (unresponsive node) is also an emergency — same bypass logic.
    """
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    from shared.config import VaultLayerConfig

    job = _job(
        provider=Provider.GCP,
        dataset_size_gb=2000.0,
        dataset_location="gcs",
        dataset_cloud="gcp",
        training_duration_hours=10.0,
    )

    cfg = MagicMock(spec=VaultLayerConfig)
    cfg.anthropic = None
    cfg.confidence_threshold_auto = 0.9
    cfg.cloudflare = MagicMock()

    queue = AsyncMock()
    queue.get_price_cache = AsyncMock(return_value=[
        # No GCP capacity — only cross-cloud available
        _price_entry("runpod", "A100_40GB", 3.00),
    ])

    agent = OrchestrationAgent(config=cfg, queue=queue)
    agent._active_jobs[job.job_id] = job

    event = AgentEvent(
        event_type=EventType.HEARTBEAT_MISS,
        source_agent="watchdog_agent",
        job_id=job.job_id,
        payload={"missed_beats": 3},
    )

    decision = await agent._make_deterministic_decision(event, "heartbeat miss", confidence=0.99)

    # 2000 GB × $0.10 = $200 egress — gate suspended → RunPod selected
    assert decision.target_provider is not None, "HEARTBEAT_MISS must bypass egress gate"
    assert decision.target_provider == Provider.RUNPOD
    assert decision.egress_cost_usd == 200.0


@pytest.mark.asyncio
async def test_arbitrage_opportunity_still_enforces_gate():
    """
    ARBITRAGE_OPPORTUNITY is voluntary — large dataset cross-cloud must be blocked.
    """
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    from shared.config import VaultLayerConfig

    job = _job(
        provider=Provider.AWS,
        dataset_size_gb=5000.0,
        dataset_location="s3",
        dataset_cloud="aws",
        training_duration_hours=5.0,
    )

    cfg = MagicMock(spec=VaultLayerConfig)
    cfg.anthropic = None
    cfg.confidence_threshold_auto = 0.9
    cfg.cloudflare = MagicMock()

    queue = AsyncMock()
    queue.get_price_cache = AsyncMock(return_value=[
        _price_entry("aws",    "A10G",      5.00),  # source (no same-cloud alternative cheaper)
        _price_entry("runpod", "A100_40GB", 1.00),  # delta = $4/hr, payback = 450/4 = 112.5 hrs > 10
    ])

    agent = OrchestrationAgent(config=cfg, queue=queue)
    agent._active_jobs[job.job_id] = job

    event = AgentEvent(
        event_type=EventType.ARBITRAGE_OPPORTUNITY,
        source_agent="pricing_agent",
        job_id=job.job_id,
        payload={},
    )

    decision = await agent._make_deterministic_decision(event, "arbitrage", confidence=0.80)

    # No eligible provider — egress gate correctly blocks the voluntary cross-cloud hop
    assert decision.target_provider is None, (
        "ARBITRAGE_OPPORTUNITY must NOT bypass egress gate for large cross-cloud datasets"
    )
