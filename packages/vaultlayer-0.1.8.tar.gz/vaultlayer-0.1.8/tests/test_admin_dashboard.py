"""Tests for admin dashboard API endpoint."""
import pytest
from unittest.mock import MagicMock, patch
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def test_dashboard_stub_when_no_supabase():
    """Dashboard returns zeroed stub when Supabase is not configured."""
    from api.admin_dashboard import _stub_dashboard
    result = _stub_dashboard()
    assert result.hero.total_jobs == 0
    assert result.hero.total_users == 0
    assert result.daily_30d == []
    assert result.providers == []


def test_dashboard_requires_admin_secret(monkeypatch):
    """Endpoint returns 403 when X-Admin-Secret header is wrong."""
    monkeypatch.setenv("VAULTLAYER_ADMIN_SECRET", "correct-secret")
    from api.admin_dashboard import _require_admin, HTTPException
    with pytest.raises(HTTPException) as exc_info:
        _require_admin("wrong-secret")
    assert exc_info.value.status_code == 403


def test_dashboard_requires_admin_secret_passes(monkeypatch):
    """Endpoint passes when X-Admin-Secret header is correct."""
    monkeypatch.setenv("VAULTLAYER_ADMIN_SECRET", "correct-secret")
    from api.admin_dashboard import _require_admin
    # Should not raise
    _require_admin("correct-secret")


def test_dashboard_503_when_secret_not_configured(monkeypatch):
    """Endpoint returns 503 when VAULTLAYER_ADMIN_SECRET is not set."""
    monkeypatch.setenv("VAULTLAYER_ADMIN_SECRET", "")
    from api.admin_dashboard import _require_admin, HTTPException
    with pytest.raises(HTTPException) as exc_info:
        _require_admin("")
    assert exc_info.value.status_code == 503


def test_safe_float_helpers():
    """_safe_float and _safe_int handle None and invalid values."""
    from api.admin_dashboard import _safe_float, _safe_int
    assert _safe_float(None) == 0.0
    assert _safe_float("3.14") == pytest.approx(3.14)
    assert _safe_float("invalid") == 0.0
    assert _safe_int(None) == 0
    assert _safe_int("42") == 42
    assert _safe_int("not_int") == 0


def test_hero_metrics_model():
    """HeroMetrics Pydantic model validates correctly."""
    from api.admin_dashboard import HeroMetrics
    h = HeroMetrics(
        total_jobs=100, active_jobs=5, completed_jobs=90, failed_jobs=5,
        total_users=50, active_users_30d=30, total_gpu_hours=1000.0,
        total_data_processed_gb=500.0, total_gross_savings_usd=50000.0,
        total_vl_revenue_usd=20000.0, total_net_savings_usd=30000.0,
        total_migrations=25, total_spot_interruptions=10,
        avg_savings_pct=65.0, job_success_rate_pct=90.0,
    )
    assert h.total_jobs == 100
    assert h.avg_savings_pct == 65.0


def test_dashboard_response_model():
    """DashboardResponse can be constructed from stub data."""
    from api.admin_dashboard import _stub_dashboard
    r = _stub_dashboard()
    assert hasattr(r, "hero")
    assert hasattr(r, "daily_30d")
    assert hasattr(r, "providers")
    assert hasattr(r, "regions")
    assert hasattr(r, "cohort_retention")
    assert hasattr(r, "gpu_breakdown")
    assert hasattr(r, "model_segments")
    assert hasattr(r, "top_users_by_ltv")
    assert r.generated_at != ""
