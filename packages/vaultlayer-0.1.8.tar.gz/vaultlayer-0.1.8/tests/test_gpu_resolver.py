"""Tests for GPUResolver — dynamic GPU name resolution with caching."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
import time
from unittest.mock import patch, AsyncMock, MagicMock
from shared.gpu_resolver import GPUResolver, _extract_gpu_keys, CACHE_TTL_SECONDS


class TestExtractGPUKeys:
    def test_h100(self):
        keys = _extract_gpu_keys("nvidia h100 80gb hbm3")
        assert "h100" in keys
        assert "h100 80gb" in keys

    def test_a100(self):
        keys = _extract_gpu_keys("nvidia a100-sxm4-80gb")
        assert "a100" in keys

    def test_rtx4090(self):
        keys = _extract_gpu_keys("rtx 4090")
        assert "rtx4090" in keys

    def test_no_match(self):
        keys = _extract_gpu_keys("some unknown gpu")
        assert keys == []


class TestGPUResolver:
    @pytest.mark.asyncio
    async def test_cache_hit(self):
        resolver = GPUResolver()
        resolver._cache["RunPod"] = {"h100": "NVIDIA H100 80GB HBM3"}
        resolver._cache_ts["RunPod"] = time.time()        # wall-clock for disk persistence
        resolver._cache_mono["RunPod"] = time.monotonic() # monotonic for TTL check
        result = await resolver.resolve("RunPod", "H100")
        assert result == "NVIDIA H100 80GB HBM3"

    @pytest.mark.asyncio
    async def test_cache_expired_falls_through(self):
        resolver = GPUResolver()
        resolver._cache["RunPod"] = {"h100": "NVIDIA H100 80GB HBM3"}
        _expired = time.monotonic() - CACHE_TTL_SECONDS - 1
        resolver._cache_ts["RunPod"] = _expired
        resolver._cache_mono["RunPod"] = _expired  # must expire both clocks
        # No API key → falls through to static fallback
        with patch("shared.gpu_resolver.GPUResolver._refresh_provider", new_callable=AsyncMock, return_value=False):
            with patch("shared.data_loader.get_instance_string", return_value="static-h100"):
                result = await resolver.resolve("RunPod", "H100")
        assert result == "static-h100"

    @pytest.mark.asyncio
    async def test_api_refresh_success(self):
        resolver = GPUResolver()
        with patch.object(resolver, "_refresh_provider", new_callable=AsyncMock, return_value=True):
            resolver._cache["RunPod"] = {"h100": "NVIDIA H100 80GB HBM3"}
            resolver._cache_ts["RunPod"] = time.monotonic()
            result = await resolver.resolve("RunPod", "H100", api_key="test-key")
        assert result == "NVIDIA H100 80GB HBM3"

    @pytest.mark.asyncio
    async def test_fallback_to_static(self):
        resolver = GPUResolver()
        with patch("shared.data_loader.get_instance_string", return_value="STATIC_VALUE"):
            result = await resolver.resolve("UnknownProvider", "H100")
        assert result == "STATIC_VALUE"

    @pytest.mark.asyncio
    async def test_invalidate_provider(self):
        resolver = GPUResolver()
        resolver._cache["RunPod"] = {"h100": "test"}
        resolver._cache_ts["RunPod"] = time.monotonic()
        resolver.invalidate("RunPod")
        assert "RunPod" not in resolver._cache
        assert "RunPod" not in resolver._cache_ts

    @pytest.mark.asyncio
    async def test_invalidate_all(self):
        resolver = GPUResolver()
        resolver._cache["RunPod"] = {"h100": "test"}
        resolver._cache["Vast.ai"] = {"h100": "test2"}
        resolver._cache_ts["RunPod"] = time.monotonic()
        resolver._cache_ts["Vast.ai"] = time.monotonic()
        resolver.invalidate()
        assert len(resolver._cache) == 0
        assert len(resolver._cache_ts) == 0

    @pytest.mark.asyncio
    async def test_fetch_runpod_gpus_success(self):
        """_fetch_runpod_gpus reads gpuTypeIds enum from the public OpenAPI spec."""
        resolver = GPUResolver()
        # Minimal OpenAPI spec shape the resolver walks.
        openapi_spec = {
            "paths": {
                "/pods": {
                    "post": {
                        "requestBody": {
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/PodCreate"}
                                }
                            }
                        }
                    }
                }
            },
            "components": {
                "schemas": {
                    "PodCreate": {
                        "properties": {
                            "gpuTypeIds": {
                                "type": "array",
                                "items": {
                                    "type": "string",
                                    "enum": [
                                        "NVIDIA H100 80GB HBM3",
                                        "NVIDIA A100-SXM4-80GB",
                                        "NVIDIA GeForce RTX 4090",
                                    ],
                                },
                            }
                        }
                    }
                }
            },
        }
        with patch("aiohttp.ClientSession") as mock_session_cls:
            mock_session = AsyncMock()
            mock_session_cls.return_value.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session_cls.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_resp = AsyncMock()
            mock_resp.status = 200
            mock_resp.json = AsyncMock(return_value=openapi_spec)
            mock_session.get = MagicMock(return_value=AsyncMock(
                __aenter__=AsyncMock(return_value=mock_resp),
                __aexit__=AsyncMock(return_value=False),
            ))
            result = await resolver._fetch_runpod_gpus("unused-key")
        assert result["h100"] == "NVIDIA H100 80GB HBM3"
        assert result["a100"] == "NVIDIA A100-SXM4-80GB"
        assert result["rtx4090"] == "NVIDIA GeForce RTX 4090"

    @pytest.mark.asyncio
    async def test_fetch_lambda_gpus_success(self):
        resolver = GPUResolver()
        mock_response = {
            "data": {
                "gpu_1x_h100_sxm5": {
                    "instance_type": {
                        "specs": {
                            "gpus": [{"description": "H100 SXM5 80GB"}]
                        }
                    }
                }
            }
        }
        with patch("aiohttp.ClientSession") as mock_session_cls:
            mock_session = AsyncMock()
            mock_session_cls.return_value.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session_cls.return_value.__aexit__ = AsyncMock(return_value=False)
            mock_resp = AsyncMock()
            mock_resp.status = 200
            mock_resp.json = AsyncMock(return_value=mock_response)
            mock_session.get = MagicMock(return_value=AsyncMock(
                __aenter__=AsyncMock(return_value=mock_resp),
                __aexit__=AsyncMock(return_value=False),
            ))
            result = await resolver._fetch_lambda_gpus("test-key")
        assert "gpu_1x_h100_sxm5" in result
