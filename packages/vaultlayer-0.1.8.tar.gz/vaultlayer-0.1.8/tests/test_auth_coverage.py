"""
Coverage tests for api/auth.py — require_auth, validate_token,
_verify_clerk_signature, and parse_clerk_webhook.
"""
import hashlib
import hmac
import base64
import json
import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from fastapi import HTTPException


TOKEN = "vl_test_" + "a" * 64
LIVE_TOKEN = "vl_live_" + "b" * 64


# ── _verify_clerk_signature() ────────────────────────────────────────────────

class TestVerifyClerkSignature:
    def _sign(self, secret: str, svix_id: str, svix_ts: str, body: bytes) -> str:
        """Produce a valid Svix signature."""
        signed = f"{svix_id}.{svix_ts}.{body.decode()}".encode()
        digest = hmac.new(secret.encode(), signed, hashlib.sha256).digest()
        return "v1," + base64.b64encode(digest).decode()

    def test_valid_signature_returns_true(self):
        from api.auth import _verify_clerk_signature
        secret = "whsec_test_secret"
        body = b'{"type": "user.created"}'
        sig = self._sign(secret, "svix-id-1", "1234567890", body)

        with patch("api.auth.CLERK_WEBHOOK_SECRET", secret):
            result = _verify_clerk_signature(body, "svix-id-1", "1234567890", sig)
        assert result is True

    def test_invalid_signature_returns_false(self):
        from api.auth import _verify_clerk_signature
        secret = "whsec_test_secret"
        body = b'{"type": "user.created"}'

        with patch("api.auth.CLERK_WEBHOOK_SECRET", secret):
            result = _verify_clerk_signature(body, "svix-id-1", "1234567890", "v1,invalidsig==")
        assert result is False

    def test_no_secret_returns_false(self):
        """When CLERK_WEBHOOK_SECRET is empty, fail-closed and return False."""
        from api.auth import _verify_clerk_signature
        with patch("api.auth.CLERK_WEBHOOK_SECRET", ""):
            result = _verify_clerk_signature(b"body", "id", "ts", "sig")
        assert result is False

    def test_multiple_sig_parts_checked(self):
        """Multiple space-separated sigs — at least one valid is enough."""
        from api.auth import _verify_clerk_signature
        secret = "whsec_test_secret"
        body = b'{"type": "user.created"}'
        valid_sig = self._sign(secret, "svix-id-1", "ts", body)
        combined = "v1,invalid_sig " + valid_sig

        with patch("api.auth.CLERK_WEBHOOK_SECRET", secret):
            result = _verify_clerk_signature(body, "svix-id-1", "ts", combined)
        assert result is True

    def test_bare_base64_sig_without_prefix(self):
        """Signature without v1, prefix still validated."""
        from api.auth import _verify_clerk_signature
        secret = "whsec_test_secret"
        body = b'{"type": "user.created"}'
        signed = f"svix-id-1.ts.{body.decode()}".encode()
        digest = hmac.new(secret.encode(), signed, hashlib.sha256).digest()
        bare_sig = base64.b64encode(digest).decode()

        with patch("api.auth.CLERK_WEBHOOK_SECRET", secret):
            result = _verify_clerk_signature(body, "svix-id-1", "ts", bare_sig)
        assert result is True

    def test_malformed_base64_does_not_crash(self):
        from api.auth import _verify_clerk_signature
        secret = "whsec_test_secret"
        with patch("api.auth.CLERK_WEBHOOK_SECRET", secret):
            result = _verify_clerk_signature(b"body", "id", "ts", "v1,!!NOT_BASE64!!")
        assert result is False


# ── require_auth() ────────────────────────────────────────────────────────────

class TestRequireAuth:
    @pytest.mark.asyncio
    async def test_raises_401_when_no_bearer_prefix(self):
        from api.auth import require_auth
        with pytest.raises(HTTPException) as exc_info:
            await require_auth(authorization="InvalidToken")
        assert exc_info.value.status_code == 401

    @pytest.mark.asyncio
    async def test_raises_401_on_invalid_token_format(self):
        from api.auth import require_auth
        with pytest.raises(HTTPException) as exc_info:
            await require_auth(authorization="Bearer invalid_format_token")
        assert exc_info.value.status_code == 401
        assert "format" in exc_info.value.detail.lower()

    @pytest.mark.asyncio
    async def test_raises_401_when_token_not_found(self):
        from api.auth import require_auth
        with patch("api.auth.get_user_by_token", AsyncMock(return_value=None)):
            with pytest.raises(HTTPException) as exc_info:
                await require_auth(authorization=f"Bearer {TOKEN}")
        assert exc_info.value.status_code == 401
        assert "not found" in exc_info.value.detail.lower()

    @pytest.mark.asyncio
    async def test_returns_user_on_valid_token(self):
        from api.auth import require_auth
        user = {"user_id": "u1", "email": "test@example.com"}
        with patch("api.auth.get_user_by_token", AsyncMock(return_value=user)):
            result = await require_auth(authorization=f"Bearer {TOKEN}")
        assert result == user

    @pytest.mark.asyncio
    async def test_accepts_vl_live_token(self):
        from api.auth import require_auth
        user = {"user_id": "u1", "email": "prod@example.com"}
        with patch("api.auth.get_user_by_token", AsyncMock(return_value=user)):
            result = await require_auth(authorization=f"Bearer {LIVE_TOKEN}")
        assert result == user

    @pytest.mark.asyncio
    async def test_strips_whitespace_from_token(self):
        from api.auth import require_auth
        user = {"user_id": "u1", "email": "test@example.com"}
        with patch("api.auth.get_user_by_token", AsyncMock(return_value=user)) as mock_fn:
            await require_auth(authorization=f"Bearer {TOKEN}  ")
        # Should pass stripped token to get_user_by_token
        mock_fn.assert_called_once_with(TOKEN)


# ── validate_token() ─────────────────────────────────────────────────────────

class TestValidateToken:
    @pytest.mark.asyncio
    async def test_invalid_format_returns_invalid_response(self):
        from api.auth import validate_token
        resp = await validate_token("not_a_valid_token")
        assert resp.valid is False
        assert "format" in resp.message.lower()

    @pytest.mark.asyncio
    async def test_token_not_found_returns_invalid(self):
        from api.auth import validate_token
        with patch("api.auth.get_user_by_token", AsyncMock(return_value=None)):
            resp = await validate_token(TOKEN)
        assert resp.valid is False
        assert "not found" in resp.message.lower()

    @pytest.mark.asyncio
    async def test_valid_token_returns_valid_response(self):
        from api.auth import validate_token
        user = {"user_id": "u1", "email": "test@example.com"}
        with patch("api.auth.get_user_by_token", AsyncMock(return_value=user)), \
             patch("api.auth.get_balance", return_value={"available_credits": 100.0}):
            resp = await validate_token(TOKEN)
        assert resp.valid is True
        assert resp.user_id == "u1"
        assert resp.email == "test@example.com"
        assert resp.balance_credits == 100.0

    @pytest.mark.asyncio
    async def test_vl_live_prefix_accepted(self):
        from api.auth import validate_token
        user = {"user_id": "u1", "email": "prod@example.com"}
        with patch("api.auth.get_user_by_token", AsyncMock(return_value=user)), \
             patch("api.auth.get_balance", return_value={"available_credits": 50.0}):
            resp = await validate_token(LIVE_TOKEN)
        assert resp.valid is True

    @pytest.mark.asyncio
    async def test_vl_test_prefix_accepted(self):
        from api.auth import validate_token
        user = {"user_id": "u1", "email": "test@example.com"}
        with patch("api.auth.get_user_by_token", AsyncMock(return_value=user)), \
             patch("api.auth.get_balance", return_value={"available_credits": 25.0}):
            resp = await validate_token(TOKEN)
        assert resp.valid is True

    @pytest.mark.asyncio
    async def test_random_prefix_rejected(self):
        from api.auth import validate_token
        resp = await validate_token("sk_live_something_else")
        assert resp.valid is False


# ── parse_clerk_webhook() ─────────────────────────────────────────────────────

class TestParseClerkWebhook:
    def _make_request(self, body: bytes, svix_id="id-1", svix_ts="12345",
                      svix_sig="v1,invalidsig"):
        req = MagicMock()
        req.body = AsyncMock(return_value=body)
        req.headers = {
            "svix-id": svix_id,
            "svix-timestamp": svix_ts,
            "svix-signature": svix_sig,
        }
        return req

    @pytest.mark.asyncio
    async def test_raises_400_on_bad_signature(self):
        from api.auth import parse_clerk_webhook
        body = b'{"type": "user.created"}'
        req = self._make_request(body, svix_sig="v1,bad==")

        with patch("api.auth.CLERK_WEBHOOK_SECRET", "whsec_real_secret"), \
             pytest.raises(HTTPException) as exc_info:
            await parse_clerk_webhook(req)
        assert exc_info.value.status_code == 400

    @pytest.mark.asyncio
    async def test_returns_parsed_json_on_valid_signature(self):
        """With a valid HMAC signature + fresh timestamp, returns parsed JSON."""
        import hmac, hashlib, base64, time
        import api.auth as auth_mod
        from api.auth import parse_clerk_webhook
        body = b'{"type": "user.created", "data": {"email": "x@y.com"}}'
        req = self._make_request(body)
        secret = "testsecretkey"
        svix_id = "test-svix-id-fresh"
        # Use a current-time timestamp so the staleness check (5 min max age)
        # passes. The old hardcoded '1234567890' would now be rejected as
        # too old, which is the desired security behavior.
        svix_ts = str(int(time.time()))
        signed_content = f"{svix_id}.{svix_ts}.{body.decode()}".encode()
        expected = hmac.new(secret.encode(), signed_content, hashlib.sha256).digest()
        sig_b64 = base64.b64encode(expected).decode()

        req.headers = {
            "svix-id": svix_id,
            "svix-timestamp": svix_ts,
            "svix-signature": f"v1,{sig_b64}",
        }

        # Clear seen-ids so this test's svix_id isn't a replay from a sibling test
        auth_mod._clerk_seen_ids.discard(svix_id)

        with patch("api.auth.CLERK_WEBHOOK_SECRET", secret):
            result = await parse_clerk_webhook(req)

        assert result["type"] == "user.created"

    @pytest.mark.asyncio
    async def test_missing_svix_headers_dont_crash(self):
        """Missing svix headers with secret configured → 400, not crash."""
        from api.auth import parse_clerk_webhook
        from fastapi import HTTPException
        body = b'{"type": "user.created"}'
        req = MagicMock()
        req.body = AsyncMock(return_value=body)
        req.headers = {}  # no svix headers

        with patch("api.auth.CLERK_WEBHOOK_SECRET", "somesecret"):
            with pytest.raises(HTTPException) as exc:
                await parse_clerk_webhook(req)
        assert exc.value.status_code == 400
