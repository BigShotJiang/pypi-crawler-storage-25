"""
VaultLayer Resume Hook Tests
Tests the zero-code-change checkpoint injection mechanism.
"""
import sys
import os
import importlib
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import json
import pathlib
import tempfile
import pytest
from unittest.mock import MagicMock, patch, call

# Most tests in this file mock torch internals — skip the whole module if torch absent
pytestmark = pytest.mark.skipif(
    importlib.util.find_spec("torch") is None,
    reason="torch not installed — resume hook tests require torch"
)


# ══════════════════════════════════════════════════════════════════════════════
# Helper: build a fake checkpoint directory
# ══════════════════════════════════════════════════════════════════════════════

def _make_ckpt_dir(tmp_path: pathlib.Path, step: int = 5000, epoch: float = 2.5,
                   write_model: bool = True, write_optimizer: bool = False) -> pathlib.Path:
    ckpt = tmp_path / "checkpoint" / "latest"
    ckpt.mkdir(parents=True)
    if write_model:
        # Fake model weights blob — torch.load not called in these tests so content doesn't matter
        (ckpt / "model.pt").write_bytes(b"\x00\x01\x02")
    manifest = {"step": step, "epoch": epoch, "complete": True, "job_id": "test-job"}
    (ckpt / "_MANIFEST.json").write_text(json.dumps(manifest))
    if write_optimizer:
        (ckpt / "optimizer.pt").write_bytes(b"\x00\x01")
    return ckpt


# ══════════════════════════════════════════════════════════════════════════════
# 1. Module structure
# ══════════════════════════════════════════════════════════════════════════════

def test_resume_hook_module_exists():
    """vaultlayer._resume_hook must be importable."""
    # Import without triggering the torch patch (no VAULTLAYER_RESUME_CHECKPOINT)
    import importlib
    spec = importlib.util.find_spec("vaultlayer._resume_hook")
    assert spec is not None, "vaultlayer._resume_hook not found on sys.path"


def test_resume_hook_noop_when_no_env(monkeypatch):
    """Hook must be a no-op when VAULTLAYER_RESUME_CHECKPOINT is unset."""
    monkeypatch.delenv("VAULTLAYER_RESUME_CHECKPOINT", raising=False)
    # Re-import with clean env
    import importlib
    import vaultlayer._resume_hook as hook
    importlib.reload(hook)
    assert hook.RESUME_PATH == ""
    assert hook._state_injected is False


# ══════════════════════════════════════════════════════════════════════════════
# 2. _find_model_checkpoint
# ══════════════════════════════════════════════════════════════════════════════

def test_find_model_checkpoint_finds_model_pt(tmp_path):
    """_find_model_checkpoint must prefer model.pt over other patterns."""
    from vaultlayer._resume_hook import _find_model_checkpoint
    ckpt = tmp_path / "ckpt"
    ckpt.mkdir()
    (ckpt / "model.pt").write_bytes(b"")
    (ckpt / "optimizer.pt").write_bytes(b"")
    result = _find_model_checkpoint(ckpt)
    assert result is not None
    assert result.name == "model.pt"


def test_find_model_checkpoint_finds_pytorch_model_bin(tmp_path):
    """_find_model_checkpoint must find pytorch_model.bin (HuggingFace format)."""
    from vaultlayer._resume_hook import _find_model_checkpoint
    ckpt = tmp_path / "ckpt"
    ckpt.mkdir()
    (ckpt / "pytorch_model.bin").write_bytes(b"")
    result = _find_model_checkpoint(ckpt)
    assert result is not None
    assert result.name == "pytorch_model.bin"


def test_find_model_checkpoint_returns_none_when_empty(tmp_path):
    """_find_model_checkpoint must return None for an empty directory."""
    from vaultlayer._resume_hook import _find_model_checkpoint
    ckpt = tmp_path / "ckpt"
    ckpt.mkdir()
    result = _find_model_checkpoint(ckpt)
    assert result is None


# ══════════════════════════════════════════════════════════════════════════════
# 3. _restore_step_from_manifest
# ══════════════════════════════════════════════════════════════════════════════

def test_restore_step_sets_env_var(tmp_path, monkeypatch):
    """_restore_step_from_manifest must set VAULTLAYER_RESUME_STEP from manifest."""
    monkeypatch.delenv("VAULTLAYER_RESUME_STEP", raising=False)
    ckpt = _make_ckpt_dir(tmp_path, step=7500, epoch=3.0)
    from vaultlayer._resume_hook import _restore_step_from_manifest
    _restore_step_from_manifest(ckpt)
    assert os.environ["VAULTLAYER_RESUME_STEP"] == "7500"


def test_restore_epoch_sets_env_var(tmp_path, monkeypatch):
    """_restore_step_from_manifest must also set VAULTLAYER_RESUME_EPOCH."""
    monkeypatch.delenv("VAULTLAYER_RESUME_EPOCH", raising=False)
    ckpt = _make_ckpt_dir(tmp_path, step=1000, epoch=1.5)
    from vaultlayer._resume_hook import _restore_step_from_manifest
    _restore_step_from_manifest(ckpt)
    assert os.environ["VAULTLAYER_RESUME_EPOCH"] == "1.5"


def test_restore_step_no_crash_on_missing_manifest(tmp_path):
    """_restore_step_from_manifest must not raise if manifest is absent."""
    from vaultlayer._resume_hook import _restore_step_from_manifest
    ckpt = tmp_path / "empty"
    ckpt.mkdir()
    _restore_step_from_manifest(ckpt)  # must not raise


# ══════════════════════════════════════════════════════════════════════════════
# 4. _load_model_weights
# ══════════════════════════════════════════════════════════════════════════════

def test_load_model_weights_calls_load_state_dict(tmp_path):
    """_load_model_weights must call module.load_state_dict with the loaded state."""
    from vaultlayer._resume_hook import _load_model_weights
    ckpt_file = tmp_path / "model.pt"
    fake_state = {"layer.weight": MagicMock()}

    mock_module = MagicMock()
    mock_module.load_state_dict.return_value = MagicMock(missing_keys=[], unexpected_keys=[])

    with patch("torch.load", return_value=fake_state):
        result = _load_model_weights(mock_module, ckpt_file)

    assert result is True
    mock_module.load_state_dict.assert_called_once_with(fake_state, strict=False)


def test_load_model_weights_unwraps_state_dict_key(tmp_path):
    """_load_model_weights must unwrap {'state_dict': ...} wrapper."""
    from vaultlayer._resume_hook import _load_model_weights
    ckpt_file = tmp_path / "model.pt"
    inner_state = {"fc.weight": MagicMock()}
    wrapped = {"state_dict": inner_state, "epoch": 3}

    mock_module = MagicMock()
    mock_module.load_state_dict.return_value = MagicMock(missing_keys=[], unexpected_keys=[])

    with patch("torch.load", return_value=wrapped):
        result = _load_model_weights(mock_module, ckpt_file)

    assert result is True
    mock_module.load_state_dict.assert_called_once_with(inner_state, strict=False)


def test_load_model_weights_returns_false_on_load_state_dict_error(tmp_path):
    """_load_model_weights must return False if load_state_dict raises."""
    from vaultlayer._resume_hook import _load_model_weights
    ckpt_file = tmp_path / "model.pt"
    fake_state = {"x": 1}

    mock_module = MagicMock()
    mock_module.load_state_dict.side_effect = RuntimeError("size mismatch")

    with patch("torch.load", return_value=fake_state):
        result = _load_model_weights(mock_module, ckpt_file)

    assert result is False


# ══════════════════════════════════════════════════════════════════════════════
# 5. _inject_state (integration of model load + manifest)
# ══════════════════════════════════════════════════════════════════════════════

def test_inject_state_loads_weights_and_step(tmp_path, monkeypatch):
    """_inject_state must load model weights and set step env var."""
    import importlib
    import vaultlayer._resume_hook as hook
    ckpt = _make_ckpt_dir(tmp_path, step=9000)

    monkeypatch.setenv("VAULTLAYER_RESUME_CHECKPOINT", str(ckpt))
    monkeypatch.delenv("VAULTLAYER_RESUME_STEP", raising=False)

    # Reset module state
    hook._state_injected = False
    hook.RESUME_PATH = str(ckpt)

    mock_module = MagicMock()
    mock_module.load_state_dict.return_value = MagicMock(missing_keys=[], unexpected_keys=[])

    fake_state = {"layer.weight": MagicMock()}
    with patch("torch.load", return_value=fake_state):
        hook._inject_state(mock_module)

    assert hook._state_injected is True
    assert os.environ.get("VAULTLAYER_RESUME_STEP") == "9000"
    mock_module.load_state_dict.assert_called_once()


def test_inject_state_idempotent(tmp_path, monkeypatch):
    """_inject_state must not load weights a second time if already injected."""
    import vaultlayer._resume_hook as hook
    ckpt = _make_ckpt_dir(tmp_path, step=1000)
    hook.RESUME_PATH = str(ckpt)
    hook._state_injected = True  # already done

    mock_module = MagicMock()
    with patch("torch.load") as mock_load:
        hook._inject_state(mock_module)

    mock_load.assert_not_called()
    mock_module.load_state_dict.assert_not_called()


def test_inject_state_no_crash_on_missing_checkpoint_dir(monkeypatch):
    """_inject_state must not raise if checkpoint dir does not exist."""
    import vaultlayer._resume_hook as hook
    hook._state_injected = False
    hook.RESUME_PATH = "/nonexistent/path/to/checkpoint"
    mock_module = MagicMock()
    hook._inject_state(mock_module)  # must not raise
    assert hook._state_injected is True  # marked done to prevent retries


# ══════════════════════════════════════════════════════════════════════════════
# 6. _patch_torch — Module.__call__ wrapping
# ══════════════════════════════════════════════════════════════════════════════

def test_patch_torch_wraps_module_call():
    """_patch_torch must wrap torch.nn.Module.__call__ so inject runs on first forward."""
    import torch
    import vaultlayer._resume_hook as hook

    original_call = torch.nn.Module.__call__
    hook._state_injected = False
    inject_calls = []

    with patch.object(hook, "_inject_state", side_effect=lambda m: inject_calls.append(m)):
        hook._patch_torch()
        # Simulate a forward pass through a tiny model
        model = torch.nn.Linear(2, 2)
        import torch as _t
        x = _t.randn(1, 2)
        model(x)

    assert len(inject_calls) >= 1, "_inject_state was not called on first forward"
    # Restore
    torch.nn.Module.__call__ = original_call


# Section 7 removed: CLI sitecustomize injection test was always skipped
# (PYTHONPATH injection moved to server-side container onstart)

# 8. Broker SSH command includes hook injection
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_broker_ssh_restart_injects_hook(dummy_config, mock_queue):
    """_restart_job_on_node must prepend sitecustomize hook creation to SSH command when resuming."""
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)

    captured_commands = []

    mock_client = MagicMock()
    mock_stdout = MagicMock()
    mock_stdout.channel.recv_exit_status.return_value = 0
    mock_stdout.read.return_value = b""
    mock_stderr = MagicMock()
    mock_stderr.read.return_value = b""
    mock_client.exec_command.return_value = (None, mock_stdout, mock_stderr)

    def _fake_exec(cmd):
        captured_commands.append(cmd)
        return (None, mock_stdout, mock_stderr)

    mock_client.exec_command.side_effect = _fake_exec

    with patch("agents.broker.ssh._HAS_PARAMIKO", True), \
         patch("agents.broker.ssh._paramiko") as mock_paramiko:
        mock_paramiko.SSHClient.return_value = mock_client
        mock_paramiko.AutoAddPolicy.return_value = MagicMock()
        await agent._restart_job_on_node(
            host="10.0.0.1",
            ssh_key="/path/key",
            command="python train.py",
            job_id="job-restart-001",
            resume_checkpoint="/workspace/checkpoint/job-restart-001/latest",
        )

    assert len(captured_commands) >= 1
    full_cmd = captured_commands[0]
    assert "sitecustomize.py" in full_cmd, "Hook injection (sitecustomize.py) not found in SSH command"
    assert "PYTHONPATH" in full_cmd, "PYTHONPATH not set in SSH command"
    assert "VAULTLAYER_RESUME_CHECKPOINT" in full_cmd, "Resume checkpoint not exported in SSH command"


# ══════════════════════════════════════════════════════════════════════════════
# DDP prefix normalisation tests
# ══════════════════════════════════════════════════════════════════════════════

def test_strip_ddp_prefix_strips_when_ckpt_ddp_model_bare():
    """Keys starting with 'module.' must be stripped when the live model is bare."""
    from vaultlayer._resume_hook import _strip_ddp_prefix
    import torch

    model = torch.nn.Linear(4, 4)  # bare model — keys like 'weight', 'bias'
    ckpt_state = {"module.weight": model.weight.data, "module.bias": model.bias.data}

    fixed = _strip_ddp_prefix(ckpt_state, model)

    assert "weight" in fixed
    assert "bias" in fixed
    assert "module.weight" not in fixed
    assert "module.bias" not in fixed


def test_strip_ddp_prefix_adds_when_ckpt_bare_model_ddp():
    """Keys must gain 'module.' prefix when the live model is DDP-wrapped."""
    from vaultlayer._resume_hook import _strip_ddp_prefix
    import torch

    inner = torch.nn.Linear(4, 4)
    # Simulate a DDP-wrapped model by monkey-patching state_dict to return prefixed keys
    ddp_state = {"module.weight": inner.weight.data, "module.bias": inner.bias.data}
    mock_ddp = MagicMock()
    mock_ddp.state_dict.return_value = ddp_state

    bare_ckpt = {"weight": inner.weight.data, "bias": inner.bias.data}
    fixed = _strip_ddp_prefix(bare_ckpt, mock_ddp)

    assert "module.weight" in fixed
    assert "module.bias" in fixed
    assert "weight" not in fixed


def test_strip_ddp_prefix_noop_when_both_bare():
    """No change when both checkpoint and model are bare (no DDP on either side)."""
    from vaultlayer._resume_hook import _strip_ddp_prefix
    import torch

    model = torch.nn.Linear(4, 4)
    state = {"weight": model.weight.data, "bias": model.bias.data}

    fixed = _strip_ddp_prefix(state, model)

    assert list(fixed.keys()) == list(state.keys())


def test_strip_ddp_prefix_noop_when_both_ddp():
    """No change when both checkpoint and model are DDP-wrapped."""
    from vaultlayer._resume_hook import _strip_ddp_prefix
    import torch

    inner = torch.nn.Linear(4, 4)
    ddp_keys = {"module.weight": inner.weight.data, "module.bias": inner.bias.data}
    mock_ddp = MagicMock()
    mock_ddp.state_dict.return_value = {"module.weight": inner.weight.data, "module.bias": inner.bias.data}

    fixed = _strip_ddp_prefix(ddp_keys, mock_ddp)

    assert "module.weight" in fixed
    assert "module.bias" in fixed


def test_load_model_weights_strips_ddp_prefix_automatically(tmp_path):
    """_load_model_weights must call _strip_ddp_prefix and succeed despite prefix mismatch."""
    from vaultlayer._resume_hook import _load_model_weights
    import torch

    model = torch.nn.Linear(4, 4)
    ckpt_file = tmp_path / "model.pt"
    # Save checkpoint with DDP prefix even though model is bare
    ddp_state = {f"module.{k}": v for k, v in model.state_dict().items()}

    with patch("torch.load", return_value=ddp_state):
        result = _load_model_weights(model, ckpt_file)

    assert result is True  # must not fail due to prefix mismatch


# ══════════════════════════════════════════════════════════════════════════════
# LR Scheduler restoration tests
# ══════════════════════════════════════════════════════════════════════════════

def test_fast_forward_scheduler_sets_last_epoch(tmp_path):
    """_fast_forward_scheduler must set last_epoch and recompute lr."""
    import torch
    from vaultlayer._resume_hook import _fast_forward_scheduler

    model = torch.nn.Linear(2, 2)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=100, gamma=0.5)

    _fast_forward_scheduler("scheduler", scheduler, resume_step=200)

    assert scheduler.last_epoch == 200
    # After 200 steps with step_size=100, gamma=0.5 → lr should be 0.1 * 0.5^2 = 0.025
    # (allow floating point tolerance)
    assert abs(optimizer.param_groups[0]["lr"] - 0.025) < 1e-6


def test_fast_forward_scheduler_noop_on_zero_step():
    """_fast_forward_scheduler must be a no-op when resume_step is 0."""
    import torch
    from vaultlayer._resume_hook import _fast_forward_scheduler

    model = torch.nn.Linear(2, 2)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=100, gamma=0.5)

    original_epoch = scheduler.last_epoch
    _fast_forward_scheduler("scheduler", scheduler, resume_step=0)

    assert scheduler.last_epoch == original_epoch  # unchanged


def test_restore_lr_schedulers_loads_from_file(tmp_path, monkeypatch):
    """_restore_lr_schedulers must call scheduler.load_state_dict when scheduler.pt exists."""
    import torch
    from vaultlayer._resume_hook import _restore_lr_schedulers

    model = torch.nn.Linear(2, 2)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.5)

    # Save scheduler state
    sched_state = scheduler.state_dict()
    torch.save(sched_state, tmp_path / "scheduler.pt")

    # Advance scheduler so we can verify it was restored
    for _ in range(5):
        scheduler.step()

    # Now "restore" — should rewind back to saved state
    with patch("sys._getframe") as mock_frame:
        # Build a fake frame chain with the scheduler in locals
        fake_frame = MagicMock()
        fake_frame.f_locals = {"scheduler": scheduler}
        fake_frame.f_back = None
        mock_frame.return_value = fake_frame

        _restore_lr_schedulers(tmp_path, resume_step=0)

    # After load_state_dict, last_epoch should match the saved state
    assert scheduler.last_epoch == sched_state["last_epoch"]


def test_patch_optimizer_step_restores_optimizer_on_first_step(tmp_path, monkeypatch):
    """
    After the first optimizer.step(), optimizer state must be loaded.

    The hook patches Optimizer.__init__ (not the class-level step), so the optimizer
    must be created AFTER _patch_optimizer_step() is called to pick up the wrapper.
    This mirrors real-world usage where sitecustomize patches __init__ before train.py runs.
    """
    import torch
    from vaultlayer._resume_hook import _patch_optimizer_step

    model = torch.nn.Linear(2, 2)

    # Save a reference optimizer state to restore from
    ref_opt = torch.optim.SGD(model.parameters(), lr=0.1)
    torch.save(ref_opt.state_dict(), tmp_path / "optimizer.pt")
    torch.save(
        torch.optim.lr_scheduler.StepLR(ref_opt, step_size=10).state_dict(),
        tmp_path / "scheduler.pt",
    )

    monkeypatch.setenv("VAULTLAYER_RESUME_STEP", "50")

    # Patch BEFORE creating the optimizer (mirrors sitecustomize load order)
    _patch_optimizer_step(tmp_path / "optimizer.pt")

    # Create optimizer AFTER patching — __init__ wrapper installs one-shot step
    optimizer = torch.optim.SGD(model.parameters(), lr=0.1)

    opt_load_calls = []
    orig_load = optimizer.__class__.load_state_dict

    def _track(self, s):
        opt_load_calls.append(s)
        return orig_load(self, s)

    optimizer.__class__.load_state_dict = _track
    try:
        x = torch.randn(1, 2)
        loss = model(x).sum()
        loss.backward()
        optimizer.step()
    finally:
        optimizer.__class__.load_state_dict = orig_load

    assert len(opt_load_calls) == 1, (
        "optimizer.load_state_dict should have been called exactly once on first step()"
    )


# ══════════════════════════════════════════════════════════════════════════════
# Frame-walker: instance attribute scheduler detection
# ══════════════════════════════════════════════════════════════════════════════

def test_collect_schedulers_finds_instance_attribute():
    """Scheduler stored as self.scheduler must be found via attribute traversal."""
    import torch
    from vaultlayer._resume_hook import _collect_schedulers_from_value
    try:
        base_cls = torch.optim.lr_scheduler.LRScheduler
    except AttributeError:
        base_cls = torch.optim.lr_scheduler._LRScheduler

    model = torch.nn.Linear(2, 2)
    opt = torch.optim.SGD(model.parameters(), lr=0.1)
    sched = torch.optim.lr_scheduler.StepLR(opt, step_size=10)

    class Trainer:
        def __init__(self):
            self.optimizer = opt
            self.scheduler = sched
            self.epoch = 0

    trainer = Trainer()
    results = []
    seen = set()
    _collect_schedulers_from_value(trainer, base_cls, seen, results, prefix="trainer")
    names = [n for n, _ in results]
    assert any("scheduler" in n for n in names), \
        f"scheduler not found via attribute walk, got: {names}"


def test_collect_schedulers_finds_nested_attribute():
    """Scheduler nested two levels deep (self.loop.scheduler) must be found."""
    import torch
    from vaultlayer._resume_hook import _collect_schedulers_from_value
    try:
        base_cls = torch.optim.lr_scheduler.LRScheduler
    except AttributeError:
        base_cls = torch.optim.lr_scheduler._LRScheduler

    model = torch.nn.Linear(2, 2)
    opt = torch.optim.SGD(model.parameters(), lr=0.1)
    sched = torch.optim.lr_scheduler.StepLR(opt, step_size=10)

    class InnerLoop:
        def __init__(self):
            self.scheduler = sched

    class OuterTrainer:
        def __init__(self):
            self.loop = InnerLoop()

    trainer = OuterTrainer()
    results = []
    seen = set()
    _collect_schedulers_from_value(trainer, base_cls, seen, results, prefix="trainer")
    names = [n for n, _ in results]
    assert any("scheduler" in n for n in names), \
        f"nested scheduler not found, got: {names}"


def test_restore_lr_schedulers_finds_scheduler_in_class(tmp_path, monkeypatch):
    """
    _restore_lr_schedulers must restore a scheduler stored as self.scheduler
    even when called from inside a heavily-abstracted class training loop.
    This is the 'frame-walker race condition' scenario.
    """
    import torch
    from vaultlayer._resume_hook import _restore_lr_schedulers

    model = torch.nn.Linear(2, 2)
    opt = torch.optim.SGD(model.parameters(), lr=0.1)
    sched = torch.optim.lr_scheduler.StepLR(opt, step_size=10, gamma=0.5)

    # Save scheduler state at step 0
    torch.save(sched.state_dict(), tmp_path / "scheduler.pt")

    # Advance scheduler 5 steps to simulate diverged state
    for _ in range(5):
        opt.step()
        sched.step()
    assert sched.last_epoch == 5

    class DeepTrainer:
        """Simulates a heavily abstracted training loop."""
        def __init__(self):
            self.model = model
            self.optimizer = opt
            self.scheduler = sched  # stored as instance attribute

        def inner_loop(self):
            self.batch_loop()

        def batch_loop(self):
            # 3 frames deep from the scheduler — should still be found
            _restore_lr_schedulers(tmp_path, resume_step=0)

    trainer = DeepTrainer()
    trainer.inner_loop()

    # Scheduler should be restored to last_epoch=0 (saved state)
    assert sched.last_epoch == 0, \
        f"Scheduler not restored: last_epoch={sched.last_epoch}, expected 0"


def test_collect_schedulers_does_not_infinite_loop_on_circular_ref():
    """Circular object references must not cause infinite recursion."""
    import torch
    from vaultlayer._resume_hook import _collect_schedulers_from_value
    try:
        base_cls = torch.optim.lr_scheduler.LRScheduler
    except AttributeError:
        base_cls = torch.optim.lr_scheduler._LRScheduler

    class Circular:
        pass

    a = Circular()
    b = Circular()
    a.other = b
    b.other = a  # circular reference

    results = []
    seen = set()
    _collect_schedulers_from_value(a, base_cls, seen, results, prefix="a")
    # Must complete without RecursionError
    assert results == []  # no schedulers in this graph


# ══════════════════════════════════════════════════════════════════════════════
# RNG state restore (zero-code path)
# ══════════════════════════════════════════════════════════════════════════════

def test_restore_rng_from_ckpt_restores_torch_state(tmp_path):
    """_restore_rng_from_ckpt must restore torch RNG state from checkpoint.pt."""
    import torch, random
    from vaultlayer._resume_hook import _restore_rng_from_ckpt

    # Advance RNG past some draws, then capture state and the *next* expected value
    torch.manual_seed(42)
    torch.rand(5)  # advance state
    rng_state = torch.get_rng_state()           # capture here
    expected = torch.rand(1).item()             # first value FROM this captured state

    # Save that captured state in a fake checkpoint
    fake_ckpt = {
        "model": {}, "step": 100,
        "rng": {"torch": rng_state, "python": random.getstate()},
    }
    ckpt_file = tmp_path / "checkpoint.pt"
    torch.save(fake_ckpt, ckpt_file)

    # Scramble RNG to simulate a different process/node
    torch.manual_seed(999)
    torch.rand(10)

    # Restore — RNG must snap back to the captured state
    _restore_rng_from_ckpt(ckpt_file)
    actual = torch.rand(1).item()  # first draw after restore must equal expected

    assert abs(actual - expected) < 1e-5, (
        f"torch RNG not restored: expected {expected:.6f}, got {actual:.6f}"
    )


def test_restore_rng_from_ckpt_noop_when_no_rng_key(tmp_path):
    """_restore_rng_from_ckpt must silently do nothing if checkpoint has no 'rng' key."""
    import torch
    from vaultlayer._resume_hook import _restore_rng_from_ckpt

    # Old-format checkpoint without RNG state
    fake_ckpt = {"model": {}, "step": 50}
    ckpt_file = tmp_path / "checkpoint.pt"
    torch.save(fake_ckpt, ckpt_file)

    torch.manual_seed(77)
    val_before = torch.rand(1).item()

    # Must not raise, and should not touch RNG state
    torch.manual_seed(77)
    _restore_rng_from_ckpt(ckpt_file)
    val_after = torch.rand(1).item()

    assert abs(val_after - val_before) < 1e-5, "RNG should be untouched when no rng key"


def test_restore_rng_from_ckpt_noop_on_missing_file(tmp_path):
    """_restore_rng_from_ckpt must not raise if checkpoint file does not exist."""
    from vaultlayer._resume_hook import _restore_rng_from_ckpt
    _restore_rng_from_ckpt(tmp_path / "nonexistent.pt")  # must not raise


def test_inject_state_restores_rng(tmp_path, monkeypatch):
    """_inject_state must call _restore_rng_from_ckpt after loading weights."""
    import vaultlayer._resume_hook as hook
    import torch

    ckpt = _make_ckpt_dir(tmp_path, step=500)
    hook._state_injected = False
    hook.RESUME_PATH = str(ckpt)

    mock_module = MagicMock()
    mock_module.load_state_dict.return_value = MagicMock(missing_keys=[], unexpected_keys=[])

    rng_restore_calls = []
    fake_state = {"layer.weight": MagicMock()}

    with patch("torch.load", return_value=fake_state):
        with patch.object(hook, "_restore_rng_from_ckpt",
                          side_effect=lambda f: rng_restore_calls.append(f)) as mock_rng:
            hook._inject_state(mock_module)

    assert len(rng_restore_calls) == 1, "_restore_rng_from_ckpt must be called once per inject"


# ══════════════════════════════════════════════════════════════════════════════
# PyTorch Lightning Trainer clock patch
# ══════════════════════════════════════════════════════════════════════════════

def test_patch_lightning_trainer_injects_callback(tmp_path, monkeypatch):
    """_patch_lightning_trainer must inject a callback into Trainer.__init__."""
    import vaultlayer._resume_hook as hook
    import json

    # Write a manifest with step/epoch
    ckpt_dir = tmp_path / "checkpoint"
    ckpt_dir.mkdir()
    (ckpt_dir / "_MANIFEST.json").write_text(json.dumps({"step": 3000, "epoch": 5}))

    monkeypatch.setattr(hook, "RESUME_PATH", str(ckpt_dir))

    # Simulate pytorch_lightning being available with a mock Trainer
    class _FakeCallback:
        pass

    class _FakeTrainer:
        def __init__(self, *args, **kwargs):
            self.callbacks = []

    fake_pl = MagicMock()
    fake_pl.Callback = _FakeCallback
    fake_pl.Trainer = _FakeTrainer

    with patch.dict("sys.modules", {"pytorch_lightning": fake_pl}):
        hook._patch_lightning_trainer()

    # Trainer.__init__ should now be patched — instantiating injects callback
    t = fake_pl.Trainer()
    assert len(t.callbacks) == 1, (
        f"Expected 1 VaultLayerLightningResume callback, got {len(t.callbacks)}"
    )


def test_patch_lightning_trainer_skips_when_step_zero(tmp_path, monkeypatch):
    """_patch_lightning_trainer must be a no-op when manifest has step=0."""
    import vaultlayer._resume_hook as hook
    import json

    ckpt_dir = tmp_path / "checkpoint_zero"
    ckpt_dir.mkdir()
    (ckpt_dir / "_MANIFEST.json").write_text(json.dumps({"step": 0, "epoch": 0}))

    monkeypatch.setattr(hook, "RESUME_PATH", str(ckpt_dir))

    class _FakeTrainer:
        _init_called = False
        def __init__(self, *args, **kwargs):
            _FakeTrainer._init_called = True
            self.callbacks = []

    fake_pl = MagicMock()
    fake_pl.Trainer = _FakeTrainer

    with patch.dict("sys.modules", {"pytorch_lightning": fake_pl}):
        hook._patch_lightning_trainer()

    # __init__ should NOT have been patched (no resume needed)
    assert fake_pl.Trainer.__init__ is _FakeTrainer.__init__, \
        "Trainer.__init__ should not be patched when step=0"


def test_patch_lightning_trainer_skips_when_no_pytorch_lightning(monkeypatch):
    """_patch_lightning_trainer must not raise if pytorch_lightning is not installed."""
    import vaultlayer._resume_hook as hook
    import sys

    monkeypatch.setattr(hook, "RESUME_PATH", "/some/path")

    # Remove pytorch_lightning from sys.modules to simulate it not being installed
    with patch.dict("sys.modules", {"pytorch_lightning": None}):
        hook._patch_lightning_trainer()  # must not raise


def test_lightning_resume_callback_restores_trainer_clock():
    """VaultLayerLightningResume.on_train_start must set global_step and current_epoch."""
    import vaultlayer._resume_hook as hook

    # Build the callback class inline (mirrors what _patch_lightning_trainer creates)
    resume_step = 2500
    resume_epoch = 4

    class _VaultLayerLightningResume:
        def on_train_start(self, trainer, pl_module):
            try:
                trainer.fit_loop.epoch_loop.batch_progress.total.completed = resume_step
                trainer.fit_loop.epoch_loop.batch_progress.current.completed = resume_step
                trainer.fit_loop.epoch_progress.current.completed = resume_epoch
                trainer.fit_loop.epoch_progress.total.completed = resume_epoch
            except AttributeError:
                try:
                    trainer.fit_loop.current_epoch = resume_epoch
                    trainer.global_step = resume_step
                except Exception:
                    pass
            try:
                trainer.callbacks = [c for c in trainer.callbacks
                                     if not isinstance(c, _VaultLayerLightningResume)]
            except Exception:
                pass

    # Build a mock trainer with Lightning >= 1.6 fit_loop structure
    batch_progress = MagicMock()
    epoch_progress = MagicMock()
    epoch_loop = MagicMock()
    epoch_loop.batch_progress = batch_progress
    fit_loop = MagicMock()
    fit_loop.epoch_loop = epoch_loop
    fit_loop.epoch_progress = epoch_progress

    trainer = MagicMock()
    trainer.fit_loop = fit_loop
    cb = _VaultLayerLightningResume()
    trainer.callbacks = [cb]

    cb.on_train_start(trainer, MagicMock())

    assert batch_progress.total.completed == resume_step
    assert batch_progress.current.completed == resume_step
    assert epoch_progress.current.completed == resume_epoch
    assert epoch_progress.total.completed == resume_epoch
    # Callback must remove itself
    assert cb not in trainer.callbacks
