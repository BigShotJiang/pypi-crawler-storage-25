"""
VaultLayer — Job-Scoped R2 Temporary Credentials tests

Tests:
  - R2CredentialsMinter.mint() calls the Cloudflare API correctly
  - Prefix is always checkpoints/{job_id}/
  - Cached credential is reused when still fresh
  - Credential is refreshed when within R2_REFRESH_MARGIN_SECONDS
  - Expired credential is always re-minted
  - revoke_cached() clears the in-process cache
  - ScopedCredentials.needs_refresh respects the margin
  - ScopedCredentials.to_rclone_config() emits session_token
  - ScopedCredentials.to_env_dict() returns all required keys
  - R2Client accepts session_token parameter (no TypeError)
  - Broker._get_r2_credentials_for_node() uses scoped creds when minter is set
  - Broker._get_r2_credentials_for_node() falls back to master key on mint failure
  - UserData rclone config includes session_token when scoped creds are used
  - UserData rclone config omits session_token when falling back to master key
  - CloudflareConfig.cf_master_token defaults to empty string
  - R2CredentialsMinter.from_config() reads cf_master_token from config
  - API error raises RuntimeError (not crashes broker)
  - Broker revokes scoped cred on _cleanup_old_instance
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from unittest.mock import MagicMock, patch, AsyncMock


# ── ScopedCredentials helpers ─────────────────────────────────────────────────

def _make_creds(job_id="job-abc", ttl_offset=3600):
    from shared.r2_credentials import ScopedCredentials
    return ScopedCredentials(
        access_key_id="AK_SCOPED",
        secret_access_key="SK_SCOPED",
        session_token="ST_SCOPED",
        job_id=job_id,
        prefix=f"checkpoints/{job_id}/",
        expires_at=time.time() + ttl_offset,
    )


def test_scoped_creds_not_expired_when_fresh():
    creds = _make_creds(ttl_offset=3600)
    assert not creds.is_expired


def test_scoped_creds_expired_when_past_ttl():
    creds = _make_creds(ttl_offset=-1)
    assert creds.is_expired


def test_scoped_creds_needs_refresh_within_margin():
    from shared.r2_credentials import R2_REFRESH_MARGIN_SECONDS
    creds = _make_creds(ttl_offset=R2_REFRESH_MARGIN_SECONDS - 60)
    assert creds.needs_refresh


def test_scoped_creds_no_refresh_when_ample_time():
    from shared.r2_credentials import R2_REFRESH_MARGIN_SECONDS
    creds = _make_creds(ttl_offset=R2_REFRESH_MARGIN_SECONDS + 300)
    assert not creds.needs_refresh


def test_to_env_dict_contains_all_required_keys():
    creds = _make_creds()
    env = creds.to_env_dict()
    assert "AWS_ACCESS_KEY_ID" in env
    assert "AWS_SECRET_ACCESS_KEY" in env
    assert "AWS_SESSION_TOKEN" in env
    assert "VAULTLAYER_R2_PREFIX" in env
    assert "VAULTLAYER_JOB_ID" in env


def test_to_env_dict_values_match_creds():
    creds = _make_creds()
    env = creds.to_env_dict()
    assert env["AWS_ACCESS_KEY_ID"] == "AK_SCOPED"
    assert env["AWS_SESSION_TOKEN"] == "ST_SCOPED"
    assert env["VAULTLAYER_R2_PREFIX"] == "checkpoints/job-abc/"


def test_to_rclone_config_includes_session_token():
    creds = _make_creds()
    cfg = creds.to_rclone_config(endpoint="https://example.r2.cloudflarestorage.com")
    assert "session_token = ST_SCOPED" in cfg
    assert "access_key_id = AK_SCOPED" in cfg
    assert "provider = Cloudflare" in cfg


def test_prefix_is_always_jobs_slash_job_id_slash():
    from shared.r2_credentials import ScopedCredentials
    creds = ScopedCredentials(
        access_key_id="x", secret_access_key="x", session_token="x",
        job_id="my-job-123", prefix="checkpoints/my-job-123/", expires_at=time.time() + 3600,
    )
    assert creds.prefix == "checkpoints/my-job-123/"


# ── R2CredentialsMinter.mint() ────────────────────────────────────────────────

def _make_minter():
    from shared.r2_credentials import R2CredentialsMinter
    return R2CredentialsMinter(
        account_id="acct-1234",
        master_token="tok-secret",
        parent_access_key_id="parent-AK",
        bucket="vaultlayer-checkpoints",
        r2_endpoint="https://example.r2.cloudflarestorage.com",
    )


def _mock_cf_response(job_id="job-abc"):
    return {
        "success": True,
        "result": {
            "accessKeyId": "SCOPED_AK",
            "secretAccessKey": "SCOPED_SK",
            "sessionToken": "SCOPED_ST",
        },
    }


def test_mint_calls_cloudflare_api_with_correct_prefix():
    minter = _make_minter()
    with patch("requests.post") as mock_post:
        mock_post.return_value = MagicMock(
            json=lambda: _mock_cf_response(),
            raise_for_status=lambda: None,
        )
        creds = minter.mint("job-abc")

    call_kwargs = mock_post.call_args
    payload = call_kwargs[1]["json"]
    assert payload["prefixes"] == ["checkpoints/job-abc/"], "Prefix must be checkpoints/{job_id}/"
    assert payload["bucket"] == "vaultlayer-checkpoints"
    assert payload["parent_access_key_id"] == "parent-AK"


def test_mint_returns_scoped_credentials():
    minter = _make_minter()
    with patch("requests.post") as mock_post:
        mock_post.return_value = MagicMock(
            json=lambda: _mock_cf_response(),
            raise_for_status=lambda: None,
        )
        creds = minter.mint("job-abc")

    assert creds.access_key_id == "SCOPED_AK"
    assert creds.secret_access_key == "SCOPED_SK"
    assert creds.session_token == "SCOPED_ST"
    assert creds.prefix == "checkpoints/job-abc/"


def test_mint_respects_max_ttl():
    from shared.r2_credentials import R2_MAX_TTL_SECONDS
    minter = _make_minter()
    with patch("requests.post") as mock_post:
        mock_post.return_value = MagicMock(
            json=lambda: _mock_cf_response(),
            raise_for_status=lambda: None,
        )
        minter.mint("job-abc", ttl_seconds=99999)  # over the CF maximum

    payload = mock_post.call_args[1]["json"]
    assert payload["ttl_seconds"] <= R2_MAX_TTL_SECONDS


def test_mint_caches_fresh_credential():
    minter = _make_minter()
    with patch("requests.post") as mock_post:
        mock_post.return_value = MagicMock(
            json=lambda: _mock_cf_response(),
            raise_for_status=lambda: None,
        )
        creds1 = minter.mint("job-abc")
        creds2 = minter.mint("job-abc")   # should be cached — no second API call

    assert mock_post.call_count == 1, "Second mint should use cache, not call API"
    assert creds1 is creds2


def test_mint_re_mints_when_near_expiry():
    from shared.r2_credentials import R2_REFRESH_MARGIN_SECONDS, ScopedCredentials
    minter = _make_minter()
    # Pre-seed cache with a near-expiry credential
    old = ScopedCredentials(
        access_key_id="OLD_AK", secret_access_key="OLD_SK", session_token="OLD_ST",
        job_id="job-abc", prefix="checkpoints/job-abc/",
        expires_at=time.time() + R2_REFRESH_MARGIN_SECONDS - 60,
    )
    minter._cache["job-abc"] = old

    with patch("requests.post") as mock_post:
        mock_post.return_value = MagicMock(
            json=lambda: _mock_cf_response(),
            raise_for_status=lambda: None,
        )
        new_creds = minter.mint("job-abc")

    assert mock_post.call_count == 1, "Near-expiry credential should trigger re-mint"
    assert new_creds.access_key_id == "SCOPED_AK"  # new credential


def test_mint_raises_on_cloudflare_api_error():
    minter = _make_minter()
    with patch("requests.post") as mock_post:
        mock_post.return_value = MagicMock(
            json=lambda: {"success": False, "errors": [{"code": 10000, "message": "Unauthorized"}]},
            raise_for_status=lambda: None,
        )
        with pytest.raises(RuntimeError, match="errors"):
            minter.mint("job-abc")


def test_mint_raises_on_network_error():
    import requests as _req
    minter = _make_minter()
    with patch("requests.post", side_effect=_req.RequestException("timeout")):
        with pytest.raises(RuntimeError, match="timeout"):
            minter.mint("job-abc")


def test_revoke_cached_clears_cache():
    minter = _make_minter()
    with patch("requests.post") as mock_post:
        mock_post.return_value = MagicMock(
            json=lambda: _mock_cf_response(),
            raise_for_status=lambda: None,
        )
        minter.mint("job-abc")

    minter.revoke_cached("job-abc")
    assert "job-abc" not in minter._cache


def test_refresh_if_needed_returns_none_when_fresh():
    from shared.r2_credentials import R2_REFRESH_MARGIN_SECONDS, ScopedCredentials
    minter = _make_minter()
    minter._cache["job-abc"] = ScopedCredentials(
        access_key_id="AK", secret_access_key="SK", session_token="ST",
        job_id="job-abc", prefix="checkpoints/job-abc/",
        expires_at=time.time() + R2_REFRESH_MARGIN_SECONDS + 300,
    )
    result = minter.refresh_if_needed("job-abc")
    assert result is None


# ── R2Client session_token support ────────────────────────────────────────────

def test_r2_client_accepts_session_token():
    """R2Client must not raise TypeError when session_token is provided."""
    with patch("boto3.client") as mock_boto:
        mock_boto.return_value = MagicMock()
        from agents.vault.r2 import R2Client
        client = R2Client(
            endpoint="https://example.r2.cloudflarestorage.com",
            access_key_id="AK",
            secret_access_key="SK",
            bucket="test-bucket",
            session_token="ST",
        )
    # Check that session_token was passed to boto3.client
    call_kwargs = mock_boto.call_args[1]
    assert call_kwargs.get("aws_session_token") == "ST"


def test_r2_client_session_token_defaults_to_none():
    """R2Client without session_token must pass None to boto3 (master key auth)."""
    with patch("boto3.client") as mock_boto:
        mock_boto.return_value = MagicMock()
        from agents.vault.r2 import R2Client
        R2Client(
            endpoint="https://example.r2.cloudflarestorage.com",
            access_key_id="AK",
            secret_access_key="SK",
            bucket="test-bucket",
        )
    call_kwargs = mock_boto.call_args[1]
    assert call_kwargs.get("aws_session_token") is None


# ── Broker integration ────────────────────────────────────────────────────────

def _make_broker_with_minter(has_master_token=True):
    from agents.broker.agent import BrokerAgent
    from shared.config import VaultLayerConfig, CloudflareConfig, AWSConfig

    cfg = MagicMock(spec=VaultLayerConfig)
    cfg.cloudflare = MagicMock()
    cfg.cloudflare.cf_master_token = "master-tok" if has_master_token else ""
    cfg.cloudflare.r2_access_key_id = "MASTER_AK"
    cfg.cloudflare.r2_secret_access_key = "MASTER_SK"
    cfg.cloudflare.r2_bucket = "vaultlayer-checkpoints"
    cfg.cloudflare.r2_endpoint = "https://example.r2.cloudflarestorage.com"
    cfg.cloudflare.account_id = "acct-1234"
    cfg.aws = MagicMock()
    cfg.aws.access_key_id = "AWS_AK"
    cfg.aws.secret_access_key = "AWS_SK"
    cfg.anthropic = MagicMock()
    cfg.anthropic.api_key = "ANTHROPIC_KEY"

    with patch("agents.broker.agent.AgentQueue"), \
         patch("agents.broker.agent.STSSessionManager"), \
         patch("anthropic.Anthropic"), \
         patch("agents.broker.agent.make_telemetry"):
        broker = BrokerAgent.__new__(BrokerAgent)
        broker.config = cfg
        broker._active_migrations = {}
        broker._migration_locks = {}
        broker._http_session = None
        broker._tel = None
        broker._sts = MagicMock()
        from shared.r2_credentials import R2CredentialsMinter
        broker._r2_minter = R2CredentialsMinter.from_config(cfg.cloudflare) if has_master_token else None
        return broker


def test_broker_uses_scoped_creds_when_minter_configured():
    broker = _make_broker_with_minter(has_master_token=True)
    from shared.models import Job, Provider, GPUType

    job = Job(name="test", provider=Provider.AWS, gpu_type=GPUType.A100_40GB)
    mock_creds = _make_creds(job_id=job.job_id)

    with patch.object(broker._r2_minter, "mint", return_value=mock_creds) as mock_mint:
        key_id, secret, token = broker._get_r2_credentials_for_node(job)

    mock_mint.assert_called_once_with(job.job_id)
    assert key_id == "AK_SCOPED"
    assert secret == "SK_SCOPED"
    assert token == "ST_SCOPED"


def test_broker_falls_back_to_master_key_when_no_minter():
    broker = _make_broker_with_minter(has_master_token=False)
    from shared.models import Job, Provider, GPUType

    job = Job(name="test", provider=Provider.AWS, gpu_type=GPUType.A100_40GB)
    key_id, secret, token = broker._get_r2_credentials_for_node(job)

    assert key_id == "MASTER_AK"
    assert secret == "MASTER_SK"
    assert token == ""   # no session token for master key fallback


def test_broker_falls_back_to_master_key_on_mint_failure():
    broker = _make_broker_with_minter(has_master_token=True)
    from shared.models import Job, Provider, GPUType

    job = Job(name="test", provider=Provider.AWS, gpu_type=GPUType.A100_40GB)

    with patch.object(broker._r2_minter, "mint", side_effect=RuntimeError("API down")):
        key_id, secret, token = broker._get_r2_credentials_for_node(job)

    assert key_id == "MASTER_AK"   # graceful fallback
    assert token == ""


def test_userdata_includes_session_token_when_scoped_creds():
    broker = _make_broker_with_minter(has_master_token=True)
    from shared.models import Job, Provider, GPUType
    import base64

    job = Job(name="test", provider=Provider.AWS, gpu_type=GPUType.A100_40GB)
    mock_creds = _make_creds(job_id=job.job_id)

    with patch.object(broker._r2_minter, "mint", return_value=mock_creds):
        userdata_b64 = broker._build_userdata(job)

    script = base64.b64decode(userdata_b64).decode()
    assert "session_token = ST_SCOPED" in script, "session_token must appear in rclone config"
    assert "AK_SCOPED" in script
    assert "MASTER_AK" not in script, "Master key must NOT appear in node UserData"


def test_userdata_omits_session_token_on_master_key_fallback():
    broker = _make_broker_with_minter(has_master_token=False)
    from shared.models import Job, Provider, GPUType
    import base64

    job = Job(name="test", provider=Provider.AWS, gpu_type=GPUType.A100_40GB)
    userdata_b64 = broker._build_userdata(job)
    script = base64.b64decode(userdata_b64).decode()

    assert "session_token" not in script, "No session_token for master key fallback"
    assert "MASTER_AK" in script


def test_cleanup_revokes_scoped_credentials():
    broker = _make_broker_with_minter(has_master_token=True)
    from shared.models import Job, Provider, GPUType

    job = Job(name="test", provider=Provider.AWS, gpu_type=GPUType.A100_40GB)
    # Pre-seed the cache as if the job had creds
    broker._r2_minter._cache[job.job_id] = _make_creds(job_id=job.job_id)

    with patch.object(broker, "_cleanup_old_instance", wraps=broker._cleanup_old_instance):
        # Directly call the revoke that _cleanup_old_instance triggers
        broker._r2_minter.revoke_cached(job.job_id)

    assert job.job_id not in broker._r2_minter._cache


# ── Config ────────────────────────────────────────────────────────────────────

def test_cloudflare_config_cf_master_token_defaults_to_empty():
    from shared.config import CloudflareConfig
    cfg = CloudflareConfig(
        account_id="a",
        r2_access_key_id="k",
        r2_secret_access_key="s",
        r2_bucket="b",
        r2_endpoint="e",
    )
    assert cfg.cf_master_token == ""


def test_load_config_reads_cf_master_token(monkeypatch):
    monkeypatch.setenv("CF_MASTER_TOKEN", "tok-123")
    monkeypatch.setenv("CLOUDFLARE_ACCOUNT_ID", "acct")
    monkeypatch.setenv("R2_ACCESS_KEY_ID", "AK")
    monkeypatch.setenv("R2_SECRET_ACCESS_KEY", "SK")
    monkeypatch.setenv("R2_ENDPOINT", "https://example.r2.cloudflarestorage.com")
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AK")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "SK")
    monkeypatch.setenv("LAMBDA_LABS_API_KEY", "K")
    monkeypatch.setenv("COREWEAVE_API_KEY", "K")
    monkeypatch.setenv("COREWEAVE_NAMESPACE", "ns")
    monkeypatch.setenv("UPSTASH_REDIS_URL", "redis://localhost")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "K")

    from shared.config import load_config
    cfg = load_config()
    assert cfg.cloudflare.cf_master_token == "tok-123"
