"""
VaultLayer — FinOps Agent Tests
Verifies savings calculations, report generation, and CLI summary formatting.
FinOps uses deterministic templates — no LLM required.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from conftest import MockAgentQueue, make_job


# ── 1. Savings report generated with correct math ────────────────────────

@pytest.mark.asyncio
async def test_savings_report_math(dummy_config, mock_queue):
    """SavingsReport must calculate savings_usd and savings_pct correctly."""
    from agents.finops.agent import FinOpsAgent
    agent = FinOpsAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.total_spend_usd = 57.48
    job.aws_equivalent_usd = 196.64
    report = await agent.generate_job_report(job)

    assert report.savings_usd > 0, "savings_usd must be positive"
    assert report.savings_pct > 60,         f"Expected >60% savings, got {report.savings_pct:.1f}%"
    assert abs(report.savings_usd - (196.64 - 57.48)) < 0.01


# ── 2. Report published to finops channel ────────────────────────────────

@pytest.mark.asyncio
async def test_report_published_to_finops_channel(dummy_config, mock_queue):
    """generate_job_report() must publish a SAVINGS_REPORT to finops channel."""
    from agents.finops.agent import FinOpsAgent
    from shared.models import EventType
    agent = FinOpsAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.total_spend_usd = 57.48
    job.aws_equivalent_usd = 196.64
    await agent.generate_job_report(job)

    finops_events = mock_queue.events_on("finops")
    assert len(finops_events) > 0, "Must publish to finops channel"
    event_types = [e.event_type for e in finops_events]
    assert EventType.SAVINGS_REPORT in event_types


# ── 3. CLI summary contains dashboard URL ────────────────────────────────

@pytest.mark.asyncio
async def test_cli_summary_contains_dashboard_url(dummy_config, mock_queue):
    """format_cli_summary() must include the dashboard URL."""
    from agents.finops.agent import FinOpsAgent
    from shared.models import SavingsReport, Provider
    agent = FinOpsAgent(config=dummy_config, queue=mock_queue)

    report = SavingsReport(
        job_id="test-001", job_name="Test Job",
        narrative="Completed successfully.",
        duration_hours=2.0, actual_spend_usd=57.48,
        aws_equivalent_usd=196.64, savings_usd=139.16,
        savings_pct=70.8, interruptions_recovered=1,
        progress_lost_minutes=0.0,
        dashboard_url="https://dashboard.vaultlayer.io/jobs/test-001",
        providers_used=[Provider.LAMBDA_LABS],
    )
    summary = agent.format_cli_summary(report)
    assert "dashboard.vaultlayer.io" in summary, \
        "CLI summary must include the dashboard URL"


# ── 4. CLI summary contains actual cost and savings ──────────────────────

@pytest.mark.asyncio
async def test_cli_summary_contains_cost_info(dummy_config, mock_queue):
    """format_cli_summary() must show actual cost and savings amount."""
    from agents.finops.agent import FinOpsAgent
    from shared.models import SavingsReport, Provider
    agent = FinOpsAgent(config=dummy_config, queue=mock_queue)

    report = SavingsReport(
        job_id="test-001", job_name="Test Job",
        narrative="Completed.", duration_hours=2.0,
        actual_spend_usd=57.48, aws_equivalent_usd=196.64,
        savings_usd=139.16, savings_pct=70.8,
        interruptions_recovered=0, progress_lost_minutes=0.0,
        dashboard_url="https://dashboard.vaultlayer.io/jobs/test-001",
        providers_used=[Provider.LAMBDA_LABS],
    )
    summary = agent.format_cli_summary(report)
    assert "57" in summary, "CLI summary must show actual spend"
    assert "139" in summary or "70" in summary, "CLI summary must show savings"


# ── 5. Deterministic narrative — no LLM needed ───────────────────────────

@pytest.mark.asyncio
async def test_finops_fallback_on_claude_error(dummy_config, mock_queue):
    """FinOps generates narrative without any LLM — must succeed regardless."""
    from agents.finops.agent import FinOpsAgent
    agent = FinOpsAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.total_spend_usd = 57.48
    job.aws_equivalent_usd = 196.64
    report = await agent.generate_job_report(job)

    assert report is not None, "Must return report"
    assert len(report.narrative) > 0, "Narrative must not be empty"
    assert report.savings_usd > 0
