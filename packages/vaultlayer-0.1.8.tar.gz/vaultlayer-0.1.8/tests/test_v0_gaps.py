"""
VaultLayer — V0 Gap Closure Tests
Tests for: IMDSv2, STS AssumeRole, Launch Templates, Spot Pricing,
Sync Complete trigger, Job environment fields, Tag RBAC.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
import time
from unittest.mock import patch, AsyncMock, MagicMock, PropertyMock
from conftest import MockAgentQueue, make_job, make_mock_anthropic, CHECKPOINT_DECISION_JSON


# ══════════════════════════════════════════════════════════════════════════════
# Phase 1: IMDSv2 Token Upgrade
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_imdsv2_token_fetch():
    """TerminationDetector must acquire IMDSv2 token via PUT before metadata GET."""
    from agents.watchdog.signals import TerminationDetector
    detector = TerminationDetector()

    mock_resp = AsyncMock()
    mock_resp.status = 200
    mock_resp.text = AsyncMock(return_value="test-imdsv2-token-abc123")
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)

    mock_session = AsyncMock()
    mock_session.put = MagicMock(return_value=mock_resp)
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=False)

    with patch('aiohttp.ClientSession', return_value=mock_session):
        token = await detector._get_imdsv2_token()

    assert token == "test-imdsv2-token-abc123"
    assert detector._imds_token == "test-imdsv2-token-abc123"


@pytest.mark.asyncio
async def test_imdsv2_token_cached():
    """Token should be cached and reused within TTL."""
    from agents.watchdog.signals import TerminationDetector
    detector = TerminationDetector()
    detector._imds_token = "cached-token"
    detector._imds_token_expiry = time.monotonic() + 10000  # far future

    token = await detector._get_imdsv2_token()
    assert token == "cached-token"


@pytest.mark.asyncio
async def test_imdsv2_fallback_to_v1():
    """When IMDSv2 PUT fails, should fall back gracefully (return None)."""
    from agents.watchdog.signals import TerminationDetector
    detector = TerminationDetector()

    mock_session = AsyncMock()
    mock_session.put = MagicMock(side_effect=Exception("Connection refused"))
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=False)

    with patch('aiohttp.ClientSession', return_value=mock_session):
        token = await detector._get_imdsv2_token()

    assert token is None
    assert detector._imds_token is None


def test_imds_headers_with_token():
    """When token is available, headers should include it."""
    from agents.watchdog.signals import TerminationDetector
    detector = TerminationDetector()
    detector._imds_token = "my-token-123"
    headers = detector._imds_headers()
    assert headers == {"X-aws-ec2-metadata-token": "my-token-123"}


def test_imds_headers_without_token():
    """When no token, headers should be empty (IMDSv1 fallback)."""
    from agents.watchdog.signals import TerminationDetector
    detector = TerminationDetector()
    detector._imds_token = None
    headers = detector._imds_headers()
    assert headers == {}


# ══════════════════════════════════════════════════════════════════════════════
# Phase 2: STS AssumeRole + Tag RBAC
# ══════════════════════════════════════════════════════════════════════════════

def test_sts_not_configured_uses_static(dummy_config):
    """When no STS role ARN, should use static AWS credentials."""
    from shared.sts import STSSessionManager
    mgr = STSSessionManager(dummy_config)
    assert mgr.is_configured is False
    creds = mgr.get_credentials("test-job")
    assert creds["aws_access_key_id"] == "test-key"
    assert creds["aws_secret_access_key"] == "test-secret"
    assert "aws_session_token" not in creds


def test_sts_configured_when_role_arn_set(dummy_config):
    """When STS role ARN is set, is_configured should be True."""
    from shared.config import STSConfig
    from shared.sts import STSSessionManager
    dummy_config.sts = STSConfig(role_arn="arn:aws:iam::123456:role/VaultLayerCrossAccount")
    mgr = STSSessionManager(dummy_config)
    assert mgr.is_configured is True


def test_sts_assume_role_returns_temp_creds(dummy_config):
    """STS assume_role should return temporary credentials with session token."""
    from shared.config import STSConfig
    from shared.sts import STSSessionManager
    dummy_config.sts = STSConfig(
        role_arn="arn:aws:iam::123456:role/VaultLayerCrossAccount",
        external_id="vaultlayer-ext-id",
    )
    mgr = STSSessionManager(dummy_config)

    mock_sts = MagicMock()
    mock_sts.assume_role.return_value = {
        "Credentials": {
            "AccessKeyId": "ASIA-TEMP-KEY",
            "SecretAccessKey": "temp-secret",
            "SessionToken": "temp-session-token",
            "Expiration": "2026-03-29T12:00:00Z",
        }
    }
    with patch('boto3.client', return_value=mock_sts):
        creds = mgr.get_credentials("job-123")

    assert creds["aws_access_key_id"] == "ASIA-TEMP-KEY"
    assert creds["aws_secret_access_key"] == "temp-secret"
    assert creds["aws_session_token"] == "temp-session-token"
    mock_sts.assume_role.assert_called_once()
    call_kwargs = mock_sts.assume_role.call_args[1]
    assert call_kwargs["RoleArn"] == "arn:aws:iam::123456:role/VaultLayerCrossAccount"
    assert call_kwargs["ExternalId"] == "vaultlayer-ext-id"


def test_sts_caches_credentials(dummy_config):
    """Repeated calls should return cached creds without re-calling STS."""
    from shared.config import STSConfig
    from shared.sts import STSSessionManager
    dummy_config.sts = STSConfig(role_arn="arn:aws:iam::123456:role/Test")
    mgr = STSSessionManager(dummy_config)

    mock_sts = MagicMock()
    mock_sts.assume_role.return_value = {
        "Credentials": {
            "AccessKeyId": "ASIA-CACHED",
            "SecretAccessKey": "cached-secret",
            "SessionToken": "cached-token",
            "Expiration": "2026-03-29T12:00:00Z",
        }
    }
    with patch('boto3.client', return_value=mock_sts):
        creds1 = mgr.get_credentials("job-1")
        creds2 = mgr.get_credentials("job-1")

    assert creds1 == creds2
    assert mock_sts.assume_role.call_count == 1  # only called once


def test_sts_get_ec2_client(dummy_config):
    """get_ec2_client should return a boto3 EC2 client with correct credentials."""
    from shared.sts import STSSessionManager
    mgr = STSSessionManager(dummy_config)

    with patch('boto3.client') as mock_boto3:
        mock_boto3.return_value = MagicMock()
        client = mgr.get_ec2_client(job_id="test-job", region="us-west-2")

    mock_boto3.assert_called_with(
        "ec2",
        region_name="us-west-2",
        aws_access_key_id="test-key",
        aws_secret_access_key="test-secret",
    )


# ══════════════════════════════════════════════════════════════════════════════
# Phase 3: Job Model Environment Fields
# ══════════════════════════════════════════════════════════════════════════════

def test_job_has_docker_image_field():
    """Job model should have docker_image field."""
    from shared.models import Job, Provider, GPUType
    job = Job(name="test", provider=Provider.AWS, gpu_type=GPUType.H100_80GB_SXM)
    assert hasattr(job, "docker_image")
    assert job.docker_image == ""


def test_job_docker_image_settable():
    """Job model docker_image should be settable."""
    from shared.models import Job, Provider, GPUType
    job = Job(name="test", provider=Provider.AWS, gpu_type=GPUType.H100_80GB_SXM,
              docker_image="nvcr.io/nvidia/pytorch:24.01-py3")
    assert job.docker_image == "nvcr.io/nvidia/pytorch:24.01-py3"


def test_job_has_environment_field():
    """Job model should have environment dict field."""
    from shared.models import Job, Provider, GPUType
    job = Job(name="test", provider=Provider.AWS, gpu_type=GPUType.H100_80GB_SXM)
    assert hasattr(job, "environment")
    assert job.environment == {}


def test_job_environment_settable():
    """Job model environment should accept dict of env vars."""
    from shared.models import Job, Provider, GPUType
    env = {"WANDB_API_KEY": "abc123", "HF_TOKEN": "hf_xyz"}
    job = Job(name="test", provider=Provider.AWS, gpu_type=GPUType.H100_80GB_SXM,
              environment=env)
    assert job.environment == env


def test_job_has_mount_config_field():
    """Job model should have mount_config dict field."""
    from shared.models import Job, Provider, GPUType
    job = Job(name="test", provider=Provider.AWS, gpu_type=GPUType.H100_80GB_SXM)
    assert hasattr(job, "mount_config")
    assert job.mount_config == {}


def test_job_serializes_with_new_fields():
    """Job with new fields should serialize/deserialize correctly."""
    from shared.models import Job, Provider, GPUType
    job = Job(
        name="test", provider=Provider.AWS, gpu_type=GPUType.H100_80GB_SXM,
        docker_image="pytorch:latest",
        environment={"KEY": "VALUE"},
        mount_config={"bucket": "my-data"},
    )
    data = job.model_dump(mode="json")
    restored = Job(**data)
    assert restored.docker_image == "pytorch:latest"
    assert restored.environment == {"KEY": "VALUE"}
    assert restored.mount_config == {"bucket": "my-data"}


# ══════════════════════════════════════════════════════════════════════════════
# Phase 4: Dynamic Launch Templates + Tag RBAC
# ══════════════════════════════════════════════════════════════════════════════

def test_broker_has_managed_tag():
    """BrokerAgent must define the MANAGED_TAG constant."""
    from agents.broker.agent import BrokerAgent
    assert hasattr(BrokerAgent, "MANAGED_TAG")
    assert BrokerAgent.MANAGED_TAG["Key"] == "Project"
    assert BrokerAgent.MANAGED_TAG["Value"] == "VaultLayer-Managed"


def test_broker_has_build_userdata_method():
    """BrokerAgent must have _build_userdata method."""
    from agents.broker.agent import BrokerAgent
    assert hasattr(BrokerAgent, "_build_userdata")


def test_broker_has_create_launch_template_method():
    """BrokerAgent must have _create_launch_template method."""
    from agents.broker.agent import BrokerAgent
    assert hasattr(BrokerAgent, "_create_launch_template")


def test_build_userdata_contains_rclone(dummy_config, mock_queue):
    """UserData script must install rclone and mount R2."""
    import base64
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    userdata_b64 = agent._build_userdata(job)
    userdata = base64.b64decode(userdata_b64).decode()
    assert "rclone" in userdata
    assert "/mnt/vaultlayer" in userdata
    assert job.job_id in userdata


def test_build_userdata_includes_docker_image(dummy_config, mock_queue):
    """UserData must pull Docker image when configured on job."""
    import base64
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.docker_image = "nvcr.io/nvidia/pytorch:24.01-py3"
    userdata_b64 = agent._build_userdata(job)
    userdata = base64.b64decode(userdata_b64).decode()
    assert "docker pull nvcr.io/nvidia/pytorch:24.01-py3" in userdata


def test_build_userdata_includes_env_vars(dummy_config, mock_queue):
    """UserData must export job environment variables."""
    import base64
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()
    job.environment = {"WANDB_KEY": "test123"}
    userdata_b64 = agent._build_userdata(job)
    userdata = base64.b64decode(userdata_b64).decode()
    assert "export WANDB_KEY='test123'" in userdata


def test_create_launch_template_includes_managed_tag(dummy_config, mock_queue):
    """Launch template must include Project: VaultLayer-Managed tag."""
    from agents.broker.agent import BrokerAgent
    from shared.models import GPUType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()

    mock_ec2 = MagicMock()
    mock_ec2.describe_images.return_value = {
        "Images": [{"ImageId": "ami-0mock0000000000a1", "CreationDate": "2024-01-01T00:00:00.000Z"}]
    }
    agent._create_launch_template(mock_ec2, job, GPUType.H100_80GB_SXM, "us-east-1")

    mock_ec2.create_launch_template.assert_called_once()
    call_kwargs = mock_ec2.create_launch_template.call_args[1]
    # Check instance tags in LaunchTemplateData
    instance_tags = call_kwargs["LaunchTemplateData"]["TagSpecifications"][0]["Tags"]
    tag_keys = {t["Key"]: t["Value"] for t in instance_tags}
    assert tag_keys.get("Project") == "VaultLayer-Managed"
    assert tag_keys.get("VaultLayerJob") == job.job_id


@pytest.mark.asyncio
async def test_provision_aws_uses_run_instances(dummy_config, mock_queue):
    """provision_aws must use run_instances (not request_spot_instances)."""
    from agents.broker.agent import BrokerAgent
    from shared.models import GPUType
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)
    job = make_job()

    mock_ec2 = MagicMock()
    mock_ec2.describe_images.return_value = {
        "Images": [{"ImageId": "ami-0mock0000000000b2", "CreationDate": "2024-01-01T00:00:00.000Z"}]
    }
    mock_ec2.describe_key_pairs.return_value = {"KeyPairs": [{"KeyName": "vaultlayer-us-east-1"}]}
    mock_ec2.create_launch_template.return_value = {}
    mock_ec2.run_instances.return_value = {
        "Instances": [{"InstanceId": "i-test-new-api"}]
    }
    mock_ec2.describe_instances.return_value = {
        "Reservations": [{"Instances": [{"State": {"Name": "running"}}]}]
    }
    mock_ec2.delete_launch_template.return_value = {}

    with patch.object(agent._sts, 'get_ec2_client', return_value=mock_ec2), \
         patch('asyncio.sleep', new_callable=AsyncMock):
        result = await agent.provision_aws(GPUType.H100_80GB_SXM, job)

    assert result == "i-test-new-api"
    mock_ec2.run_instances.assert_called_once()
    call_kwargs = mock_ec2.run_instances.call_args[1]
    assert "LaunchTemplate" in call_kwargs
    assert call_kwargs["InstanceMarketOptions"]["MarketType"] == "spot"
    # Verify tag RBAC
    instance_tags = call_kwargs["TagSpecifications"][0]["Tags"]
    tag_keys = {t["Key"]: t["Value"] for t in instance_tags}
    assert tag_keys.get("Project") == "VaultLayer-Managed"


# ══════════════════════════════════════════════════════════════════════════════
# Phase 5: Live Spot Price Monitor
# ══════════════════════════════════════════════════════════════════════════════

def test_pricing_has_aws_spot_instance_types():
    """Module should define AWS_SPOT_INSTANCE_TYPES mapping."""
    from agents.pricing.agent import AWS_SPOT_INSTANCE_TYPES
    from shared.models import GPUType
    assert GPUType.H100_80GB_SXM in AWS_SPOT_INSTANCE_TYPES
    assert GPUType.A100_80GB_SXM in AWS_SPOT_INSTANCE_TYPES


def test_pricing_has_aws_spot_regions():
    """Module should define AWS_SPOT_REGIONS list."""
    from agents.pricing.agent import AWS_SPOT_REGIONS
    assert "us-east-1" in AWS_SPOT_REGIONS
    assert "us-west-2" in AWS_SPOT_REGIONS
    assert len(AWS_SPOT_REGIONS) >= 2


@pytest.mark.asyncio
async def test_fetch_aws_spot_returns_prices(dummy_config, mock_queue):
    """fetch_aws_spot should return GPUPrice objects with is_spot=True."""
    from agents.pricing.agent import PricingAgent
    from shared.models import GPUType, Provider
    from datetime import datetime
    agent = PricingAgent(config=dummy_config, queue=mock_queue)

    mock_ec2 = MagicMock()
    mock_ec2.describe_spot_price_history.return_value = {
        "SpotPriceHistory": [
            {
                "InstanceType": "p5.48xlarge",
                "AvailabilityZone": "us-east-1a",
                "SpotPrice": "45.50",
                "Timestamp": datetime(2026, 3, 29, 10, 0),
            },
            {
                "InstanceType": "p5.48xlarge",
                "AvailabilityZone": "us-east-1b",
                "SpotPrice": "42.00",
                "Timestamp": datetime(2026, 3, 29, 10, 0),
            },
        ]
    }

    with patch('shared.sts.STSSessionManager.get_ec2_client', return_value=mock_ec2):
        prices = await agent.fetch_aws_spot()

    spot_prices = [p for p in prices if p.is_spot]
    assert len(spot_prices) > 0
    assert all(p.provider == Provider.AWS for p in spot_prices)
    assert all(p.is_spot is True for p in spot_prices)


def test_find_best_spot_az(dummy_config, mock_queue):
    """find_best_spot_az should return the cheapest AZ."""
    from agents.pricing.agent import PricingAgent
    from shared.models import GPUPrice, GPUType, Provider
    agent = PricingAgent(config=dummy_config, queue=mock_queue)

    prices = [
        GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.AWS,
                 region="us-east-1a", price_per_hour=48.0, availability="high", is_spot=True),
        GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.AWS,
                 region="us-west-2c", price_per_hour=38.0, availability="medium", is_spot=True),
    ]
    best = agent.find_best_spot_az(prices)
    assert best is not None
    assert best["az"] == "us-west-2c"
    assert best["spot_price"] == 38.0


@pytest.mark.asyncio
async def test_fetch_aws_spot_handles_api_failure(dummy_config, mock_queue):
    """fetch_aws_spot should return empty list on API failure, not crash."""
    from agents.pricing.agent import PricingAgent
    agent = PricingAgent(config=dummy_config, queue=mock_queue)

    mock_ec2 = MagicMock()
    mock_ec2.describe_spot_price_history.side_effect = Exception("Access denied")

    with patch('shared.sts.STSSessionManager.get_ec2_client', return_value=mock_ec2):
        prices = await agent.fetch_aws_spot()

    assert prices == []


# ══════════════════════════════════════════════════════════════════════════════
# Phase 6: NAMESPACE_SYNC_COMPLETE Auto-trigger
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_emergency_checkpoint_publishes_sync_complete(dummy_config, mock_queue):
    """After successful checkpoint, watchdog must publish NAMESPACE_SYNC_COMPLETE."""
    from agents.watchdog.agent import WatchdogAgent
    from shared.models import EventType
    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()

    async def fake_checkpoint(j):
        pass  # success

    agent.register_job(job, fake_checkpoint)

    with patch.object(agent, '_narrate_event', return_value="Test narration"):
        await agent._emergency_checkpoint(job, reason="spot_termination", termination_time="2026-03-29T12:00:00Z")

    watchdog_events = mock_queue.events_on("watchdog")
    event_types = [e.event_type for e in watchdog_events]
    assert EventType.NAMESPACE_SYNC_COMPLETE in event_types

    sync_event = [e for e in watchdog_events if e.event_type == EventType.NAMESPACE_SYNC_COMPLETE][0]
    assert sync_event.payload["checkpoint_step"] == job.current_step
    assert sync_event.payload["reason"] == "spot_termination"


@pytest.mark.asyncio
async def test_failed_checkpoint_no_sync_complete(dummy_config, mock_queue):
    """If checkpoint fails, NAMESPACE_SYNC_COMPLETE should NOT be published."""
    from agents.watchdog.agent import WatchdogAgent
    from shared.models import EventType
    agent = WatchdogAgent(config=dummy_config, queue=mock_queue)
    job = make_job()

    async def failing_checkpoint(j):
        raise Exception("Checkpoint failed")

    agent.register_job(job, failing_checkpoint)

    with patch.object(agent, '_narrate_event', return_value="Checkpoint failed"):
        await agent._emergency_checkpoint(job, reason="spot_termination")

    watchdog_events = mock_queue.events_on("watchdog")
    event_types = [e.event_type for e in watchdog_events]
    assert EventType.NAMESPACE_SYNC_COMPLETE not in event_types


@pytest.mark.asyncio
async def test_orchestration_handles_sync_complete(dummy_config, mock_queue):
    """Orchestration agent must handle NAMESPACE_SYNC_COMPLETE as action event."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import EventType, AgentEvent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(
        '{"action":"migrate","reasoning":"Sync complete, warm-start needed",'
        '"action_plan":["Provision new node"],"confidence":0.95,"tier":"auto",'
        '"target_provider":"lambda_labs","target_gpu":"H100_80GB_SXM",'
        '"estimated_savings_per_hour":50.0,"estimated_downtime_minutes":2.0,'
        '"requires_human_confirmation":false}'
    )):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job())

        event = AgentEvent(
            event_type=EventType.NAMESPACE_SYNC_COMPLETE,
            source_agent="watchdog_agent",
            job_id="test-001",
            payload={"checkpoint_step": 5000, "reason": "spot_termination"},
            priority=1,
        )
        await agent.handle_event(event)

    assert len(agent._decisions) == 1
    assert agent._decisions[0].action == "migrate"


@pytest.mark.asyncio
async def test_rule_based_handles_sync_complete(dummy_config, mock_queue):
    """Rule-based fallback must handle NAMESPACE_SYNC_COMPLETE with migrate action."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import EventType, AgentEvent
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)

    # Directly test the rule-based decision path
    event = AgentEvent(
        event_type=EventType.NAMESPACE_SYNC_COMPLETE,
        source_agent="watchdog_agent",
        job_id="test-001",
        payload={"checkpoint_step": 5000, "reason": "spot_termination"},
        priority=1,
    )
    decision = agent._rule_based_decision(event)
    assert decision.action == "migrate"
    assert decision.confidence == 0.99


# ══════════════════════════════════════════════════════════════════════════════
# Phase 2+4 Integration: STS Config in load_config
# ══════════════════════════════════════════════════════════════════════════════

def test_sts_config_loads_from_env():
    """STSConfig should load from VL_STS_ROLE_ARN env var."""
    from shared.config import STSConfig
    assert hasattr(STSConfig, "__dataclass_fields__")
    fields = STSConfig.__dataclass_fields__
    assert "role_arn" in fields
    assert "external_id" in fields
    assert "session_duration" in fields


def test_vaultlayer_config_has_sts_field():
    """VaultLayerConfig should have optional sts field."""
    from shared.config import VaultLayerConfig
    import dataclasses
    field_names = [f.name for f in dataclasses.fields(VaultLayerConfig)]
    assert "sts" in field_names


# ══════════════════════════════════════════════════════════════════════════════
# Polling integration: _poll_once includes all providers
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_poll_once_includes_all_providers(dummy_config, mock_queue):
    """_poll_once must fetch from all providers including spot prices."""
    from agents.pricing.agent import PricingAgent
    agent = PricingAgent(config=dummy_config, queue=mock_queue)

    with patch.object(agent, 'fetch_aws', new_callable=AsyncMock, return_value=[]), \
         patch.object(agent, 'fetch_aws_spot', new_callable=AsyncMock, return_value=[]) as mock_spot, \
         patch.object(agent, 'fetch_lambda', new_callable=AsyncMock, return_value=[]), \
         patch.object(agent, 'fetch_coreweave', new_callable=AsyncMock, return_value=[]), \
         patch.object(agent, 'fetch_runpod', new_callable=AsyncMock, return_value=[]), \
         patch.object(agent, 'fetch_vast', new_callable=AsyncMock, return_value=[]), \
         patch.object(agent, 'fetch_voltage_park', new_callable=AsyncMock, return_value=[]), \
         patch.object(agent, 'fetch_crusoe', new_callable=AsyncMock, return_value=[]), \
         patch.object(agent, 'fetch_nebius', new_callable=AsyncMock, return_value=[]), \
         patch.object(agent, 'fetch_hyperstack', new_callable=AsyncMock, return_value=[]):
        await agent._poll_once()

    mock_spot.assert_called_once()


# ══════════════════════════════════════════════════════════════════════════════
# Gap 1: Dataset Egress Cost in Arbitrage Calculation
# ══════════════════════════════════════════════════════════════════════════════

def test_egress_cost_reduces_arbitrage_savings():
    """find_opportunities must subtract amortised S3 egress from savings_per_hour."""
    from agents.pricing.agent import PricingAgent, AWS_EGRESS_RATE_PER_GB
    from shared.models import GPUPrice, GPUType, Provider
    from shared.config import VaultLayerConfig, AWSConfig, LambdaLabsConfig, CoreWeaveConfig, CloudflareConfig, RedisConfig, AnthropicConfig
    cfg = VaultLayerConfig(
        token="vl_test_" + "a" * 64,
        user_id="test",
        aws=AWSConfig(access_key_id="k", secret_access_key="s"),
        lambda_labs=LambdaLabsConfig(api_key="lk"),
        coreweave=CoreWeaveConfig(api_key="ck", namespace="ns"),
        cloudflare=CloudflareConfig(account_id="a", r2_access_key_id="r", r2_secret_access_key="rs", r2_bucket="b", r2_endpoint="https://e"),
        redis=RedisConfig(url="redis://localhost"),
        anthropic=AnthropicConfig(api_key="ak"),
    )
    agent = PricingAgent(config=cfg, queue=None)
    prices = [
        GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.AWS, region="us-east-1",
                 price_per_hour=98.32, availability="high", is_spot=False),
        GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.LAMBDA_LABS, region="us-east-1",
                 price_per_hour=24.99, availability="high", is_spot=False),
    ]
    # Without egress
    opps_no_egress = agent.find_opportunities(prices, dataset_size_gb=0.0)
    assert len(opps_no_egress) > 0
    raw_savings = opps_no_egress[0]["savings_per_hour"]

    # With 50 TB dataset, 100h training -> egress cost = 50000 * 0.09 / 100 = 45/hr
    opps_with_egress = agent.find_opportunities(
        prices,
        dataset_size_gb=50_000.0,
        dataset_location="s3",
        training_duration_hours=100.0,
    )
    assert len(opps_with_egress) > 0
    adjusted_savings = opps_with_egress[0]["savings_per_hour"]
    expected_egress_per_hour = (50_000.0 * AWS_EGRESS_RATE_PER_GB) / 100.0
    assert abs((raw_savings - adjusted_savings) - expected_egress_per_hour) < 0.01, \
        f"Egress deduction incorrect: raw={raw_savings}, adjusted={adjusted_savings}, expected_deduction={expected_egress_per_hour}"


def test_egress_cost_zero_for_r2_dataset():
    """No egress penalty when dataset is already in R2 (not S3)."""
    from agents.pricing.agent import PricingAgent
    from shared.models import GPUPrice, GPUType, Provider
    from shared.config import VaultLayerConfig, AWSConfig, LambdaLabsConfig, CoreWeaveConfig, CloudflareConfig, RedisConfig, AnthropicConfig
    cfg = VaultLayerConfig(
        token="vl_test_" + "a" * 64,
        user_id="test",
        aws=AWSConfig(access_key_id="k", secret_access_key="s"),
        lambda_labs=LambdaLabsConfig(api_key="lk"),
        coreweave=CoreWeaveConfig(api_key="ck", namespace="ns"),
        cloudflare=CloudflareConfig(account_id="a", r2_access_key_id="r", r2_secret_access_key="rs", r2_bucket="b", r2_endpoint="https://e"),
        redis=RedisConfig(url="redis://localhost"),
        anthropic=AnthropicConfig(api_key="ak"),
    )
    agent = PricingAgent(config=cfg, queue=None)
    prices = [
        GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.AWS, region="us-east-1",
                 price_per_hour=98.32, availability="high", is_spot=False),
        GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.LAMBDA_LABS, region="us-east-1",
                 price_per_hour=24.99, availability="high", is_spot=False),
    ]
    opps_r2 = agent.find_opportunities(prices, dataset_size_gb=50_000.0, dataset_location="r2")
    opps_no_egress = agent.find_opportunities(prices, dataset_size_gb=0.0)
    # Savings should be identical when dataset is in R2
    assert opps_r2[0]["savings_per_hour"] == opps_no_egress[0]["savings_per_hour"]


def test_egress_cost_fields_in_opportunity():
    """Opportunity dict must include egress_cost_per_hour and egress_cost_total_usd."""
    from agents.pricing.agent import PricingAgent, AWS_EGRESS_RATE_PER_GB
    from shared.models import GPUPrice, GPUType, Provider
    from shared.config import VaultLayerConfig, AWSConfig, LambdaLabsConfig, CoreWeaveConfig, CloudflareConfig, RedisConfig, AnthropicConfig
    cfg = VaultLayerConfig(
        token="vl_test_" + "a" * 64,
        user_id="test",
        aws=AWSConfig(access_key_id="k", secret_access_key="s"),
        lambda_labs=LambdaLabsConfig(api_key="lk"),
        coreweave=CoreWeaveConfig(api_key="ck", namespace="ns"),
        cloudflare=CloudflareConfig(account_id="a", r2_access_key_id="r", r2_secret_access_key="rs", r2_bucket="b", r2_endpoint="https://e"),
        redis=RedisConfig(url="redis://localhost"),
        anthropic=AnthropicConfig(api_key="ak"),
    )
    agent = PricingAgent(config=cfg, queue=None)
    prices = [
        GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.AWS, region="us-east-1",
                 price_per_hour=98.32, availability="high", is_spot=False),
        GPUPrice(gpu=GPUType.H100_80GB_SXM, provider=Provider.LAMBDA_LABS, region="us-east-1",
                 price_per_hour=24.99, availability="high", is_spot=False),
    ]
    opps = agent.find_opportunities(prices, dataset_size_gb=1000.0, dataset_location="s3", training_duration_hours=10.0)
    assert len(opps) > 0
    opp = opps[0]
    assert "egress_cost_per_hour" in opp
    assert "egress_cost_total_usd" in opp
    assert "raw_savings_per_hour" in opp
    expected_total = round(1000.0 * AWS_EGRESS_RATE_PER_GB, 2)
    assert opp["egress_cost_total_usd"] == expected_total


def test_job_model_has_dataset_fields():
    """Job model must have dataset_size_gb, dataset_location, training_duration_hours."""
    from shared.models import Job, Provider, GPUType
    job = Job(name="test", provider=Provider.AWS, gpu_type=GPUType.H100_80GB_SXM)
    assert hasattr(job, "dataset_size_gb")
    assert hasattr(job, "dataset_location")
    assert hasattr(job, "training_duration_hours")
    assert job.dataset_size_gb == 0.0
    assert job.dataset_location == "s3"
    assert job.training_duration_hours == 1.0


# ══════════════════════════════════════════════════════════════════════════════
# Gap 4: CUDA Driver Probe
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_probe_cuda_passes_with_compatible_driver(dummy_config, mock_queue):
    """_probe_cuda must return (True, version) when driver meets minimum."""
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)

    mock_client = MagicMock()
    mock_stdout = MagicMock()
    mock_stdout.read.return_value = b"535.104.05\n"
    mock_stderr = MagicMock()
    mock_stderr.read.return_value = b""
    mock_client.exec_command.return_value = (None, mock_stdout, mock_stderr)
    mock_client.connect.return_value = None
    mock_client.close.return_value = None

    with patch('agents.broker.ssh._HAS_PARAMIKO', True), \
         patch('agents.broker.ssh._paramiko') as mock_paramiko:
        mock_paramiko.SSHClient.return_value = mock_client
        mock_paramiko.AutoAddPolicy.return_value = MagicMock()
        ok, ver = await agent._probe_cuda("10.0.0.1", "/path/to/key", min_driver_version="525.0")

    assert ok is True
    assert ver == "535.104.05"


@pytest.mark.asyncio
async def test_probe_cuda_fails_with_old_driver(dummy_config, mock_queue):
    """_probe_cuda must return (False, version) when driver is below minimum."""
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)

    mock_client = MagicMock()
    mock_stdout = MagicMock()
    mock_stdout.read.return_value = b"470.82.01\n"
    mock_stderr = MagicMock()
    mock_stderr.read.return_value = b""
    mock_client.exec_command.return_value = (None, mock_stdout, mock_stderr)
    mock_client.connect.return_value = None
    mock_client.close.return_value = None

    with patch('agents.broker.ssh._HAS_PARAMIKO', True), \
         patch('agents.broker.ssh._paramiko') as mock_paramiko:
        mock_paramiko.SSHClient.return_value = mock_client
        mock_paramiko.AutoAddPolicy.return_value = MagicMock()
        ok, ver = await agent._probe_cuda("10.0.0.1", "/path/to/key", min_driver_version="525.0")

    assert ok is False
    assert ver == "470.82.01"


@pytest.mark.asyncio
async def test_probe_cuda_returns_true_when_no_paramiko(dummy_config, mock_queue):
    """When paramiko is unavailable, _probe_cuda must not block — returns (True, 'unknown')."""
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)

    with patch('agents.broker.agent._HAS_PARAMIKO', False):
        ok, ver = await agent._probe_cuda("10.0.0.1", "/path/to/key")

    assert ok is True
    assert ver == "unknown"


@pytest.mark.asyncio
async def test_probe_cuda_returns_true_on_ssh_exception(dummy_config, mock_queue):
    """SSH failures during probe must not block migration — returns (True, 'unknown')."""
    from agents.broker.agent import BrokerAgent
    agent = BrokerAgent(config=dummy_config, queue=mock_queue)

    mock_client = MagicMock()
    mock_client.connect.side_effect = Exception("Connection refused")

    with patch('agents.broker.ssh._HAS_PARAMIKO', True), \
         patch('agents.broker.ssh._paramiko') as mock_paramiko:
        mock_paramiko.SSHClient.return_value = mock_client
        mock_paramiko.AutoAddPolicy.return_value = MagicMock()
        ok, ver = await agent._probe_cuda("10.0.0.1", "/path/to/key")

    assert ok is True
    assert ver == "unknown"


# ══════════════════════════════════════════════════════════════════════════════
# Gap 5: Migration Governance (6-hr cooldown + 20% savings floor)
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_governance_blocks_migration_within_cooldown(dummy_config, mock_queue):
    """Orchestration must skip arbitrage events within the 6-hour cooldown window."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    from unittest.mock import patch
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job("job-001"))

    # Simulate a recent migration by injecting a timestamp inside the cooldown
    import time
    agent._last_migration_at["job-001"] = time.monotonic() - 100  # only 100s ago

    event = AgentEvent(
        event_type=EventType.ARBITRAGE_OPPORTUNITY,
        source_agent="pricing_agent",
        job_id="job-001",
        payload={"opportunities": [
            {"gpu": "H100_80GB_SXM", "to_provider": "lambda_labs",
             "savings_per_hour": 60.0, "savings_pct": 65.0}
        ]},
        priority=3,
    )
    await agent.handle_event(event)

    # No new decisions should have been made (event was blocked by cooldown)
    assert len(agent._decisions) == 0, \
        f"Cooldown should have blocked the arbitrage event, got {len(agent._decisions)} decisions"


@pytest.mark.asyncio
async def test_governance_allows_migration_after_cooldown(dummy_config, mock_queue):
    """Orchestration must allow arbitrage events after the 6-hour cooldown expires."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    from unittest.mock import patch
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job("job-001"))

    # Simulate a migration that happened 7 hours ago (past the 6h cooldown)
    import time
    agent._last_migration_at["job-001"] = time.monotonic() - (7 * 3600)

    event = AgentEvent(
        event_type=EventType.ARBITRAGE_OPPORTUNITY,
        source_agent="pricing_agent",
        job_id="job-001",
        payload={"opportunities": [
            {"gpu": "H100_80GB_SXM", "to_provider": "lambda_labs",
             "savings_per_hour": 60.0, "savings_pct": 65.0}
        ]},
        priority=3,
    )
    await agent.handle_event(event)

    # Decision should have been made (cooldown expired)
    assert len(agent._decisions) >= 1, "Event should have passed the cooldown gate"


@pytest.mark.asyncio
async def test_governance_blocks_low_savings_arbitrage(dummy_config, mock_queue):
    """Orchestration must skip arbitrage events below the 20% savings floor."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    from unittest.mock import patch
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job("job-001"))

    event = AgentEvent(
        event_type=EventType.ARBITRAGE_OPPORTUNITY,
        source_agent="pricing_agent",
        job_id="job-001",
        payload={"opportunities": [
            {"gpu": "H100_80GB_SXM", "to_provider": "lambda_labs",
             "savings_per_hour": 5.0, "savings_pct": 10.0}  # only 10% — below 20% floor
        ]},
        priority=3,
    )
    await agent.handle_event(event)

    assert len(agent._decisions) == 0, \
        "10% savings is below the 20% floor — should have been blocked by governance"


@pytest.mark.asyncio
async def test_governance_cooldown_does_not_block_termination_signal(dummy_config, mock_queue):
    """The 6-hour cooldown must NOT apply to emergency TERMINATION_SIGNAL events."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    from unittest.mock import patch
    from conftest import make_termination_event
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(CHECKPOINT_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job("test-001"))

    # Record a very recent migration — cooldown is active
    import time
    agent._last_migration_at["test-001"] = time.monotonic() - 60  # only 60s ago

    # TERMINATION_SIGNAL must bypass cooldown
    await agent.handle_event(make_termination_event("test-001"))

    assert len(agent._decisions) >= 1, \
        "TERMINATION_SIGNAL must bypass governance cooldown — job must be protected"


@pytest.mark.asyncio
async def test_governance_records_migration_timestamp(dummy_config, mock_queue):
    """After a migrate decision is dispatched, _last_migration_at must be updated."""
    from agents.orchestration.agent import OrchestrationAgent
    from shared.models import AgentEvent, EventType
    from unittest.mock import patch
    from conftest import make_termination_event, MIGRATE_DECISION_JSON
    with patch('anthropic.Anthropic', return_value=make_mock_anthropic(MIGRATE_DECISION_JSON)):
        agent = OrchestrationAgent(config=dummy_config, queue=mock_queue)
        agent.register_job(make_job("test-001"))
        await agent.handle_event(make_termination_event("test-001"))

    assert "test-001" in agent._last_migration_at, \
        "Migration timestamp must be recorded after migrate decision is dispatched"
