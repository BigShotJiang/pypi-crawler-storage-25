"""Sprint-1 PR C: pins the 2-phase terminate-and-retry behavior.

Real leak caught 2026-04-20: instance i-0889b5a0214be229f was still
`running` 17 hours after its job failed. `_termination_confirmed=False`
was set but nothing retried the terminate call. ~$17 of credits burned
before a manual sweep noticed.

Fix: hard_fence now does two phases:
  1. Retry transient terminate_instances failures via sync_retry (3x
     with exponential backoff)
  2. If instance is still running after 60s poll, issue a second
     terminate and poll another 120s
Only after both phases exhaust does it raise — and the raise surfaces
the instance state so the caller can escalate.
"""
from __future__ import annotations

import sys
import asyncio
from pathlib import Path
from unittest.mock import MagicMock, AsyncMock, patch, call

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import pytest
pytest_plugins = ["pytest_asyncio"]


def _make_broker(region="us-east-1"):
    """Broker stub with STS-backed ec2 client and config.aws.region."""
    broker = MagicMock()
    broker.config.aws.region = region
    ec2 = MagicMock()
    broker._sts.get_ec2_client.return_value = ec2
    return broker, ec2


@pytest.mark.asyncio
async def test_happy_path_terminate_once_polled_ok():
    """Instance terminates quickly on first call — no retry needed."""
    from agents.broker.providers.aws import hard_fence

    broker, ec2 = _make_broker()
    ec2.terminate_instances.return_value = {}
    # First describe shows shutting-down → success
    ec2.describe_instances.return_value = {
        "Reservations": [{"Instances": [{"State": {"Name": "shutting-down"}}]}]
    }

    # Patch the poll interval to 0 so test runs fast
    with patch("agents.broker.providers.aws.asyncio.sleep", new=AsyncMock()), \
         patch("shared.retry.time.sleep", lambda x: None):
        await hard_fence(broker, "i-abc123", _phase1_seconds=1, _phase2_seconds=1)

    assert ec2.terminate_instances.call_count == 1
    # At least one describe was issued
    assert ec2.describe_instances.call_count >= 1


@pytest.mark.asyncio
async def test_already_gone_returns_clean():
    """terminate_instances raises InvalidInstanceID.NotFound on first
    call → instance is already gone, return clean."""
    from agents.broker.providers.aws import hard_fence

    broker, ec2 = _make_broker()
    ec2.terminate_instances.side_effect = RuntimeError(
        "An error occurred (InvalidInstanceID.NotFound) when calling "
        "the TerminateInstances operation"
    )

    with patch("agents.broker.providers.aws.asyncio.sleep", new=AsyncMock()), \
         patch("shared.retry.time.sleep", lambda x: None):
        await hard_fence(broker, "i-gone", _phase1_seconds=1, _phase2_seconds=1)

    # describe_instances should NOT have been called — terminate returned early
    assert ec2.describe_instances.call_count == 0


@pytest.mark.asyncio
async def test_transient_terminate_error_retried():
    """First terminate_instances fails transiently (timeout), second
    succeeds. Instance then confirms terminated on poll."""
    from agents.broker.providers.aws import hard_fence

    broker, ec2 = _make_broker()
    _term_calls = {"n": 0}

    def _terminate(**kwargs):
        _term_calls["n"] += 1
        if _term_calls["n"] == 1:
            raise RuntimeError("connection timeout")
        return {}

    ec2.terminate_instances.side_effect = _terminate
    ec2.describe_instances.return_value = {
        "Reservations": [{"Instances": [{"State": {"Name": "terminated"}}]}]
    }

    with patch("agents.broker.providers.aws.asyncio.sleep", new=AsyncMock()), \
         patch("shared.retry.time.sleep", lambda x: None):
        with patch("shared.retry.time.sleep", lambda x: None):  # sync_retry sleeps
            await hard_fence(broker, "i-xyz", _phase1_seconds=1, _phase2_seconds=1)

    assert _term_calls["n"] >= 2, "transient error should trigger retry"


@pytest.mark.asyncio
async def test_phase2_reissues_terminate_when_still_running():
    """Instance stays `running` through phase 1 (60s). Fix must issue
    a SECOND terminate_instances call in phase 2."""
    from agents.broker.providers.aws import hard_fence

    broker, ec2 = _make_broker()
    ec2.terminate_instances.return_value = {}
    # Always running — never transitions. Phase 2 fires; both phases
    # exhaust → escalation raise.
    ec2.describe_instances.return_value = {
        "Reservations": [{"Instances": [{"State": {"Name": "running"}}]}]
    }

    with patch("agents.broker.providers.aws.asyncio.sleep", new=AsyncMock()), \
         patch("shared.retry.time.sleep", lambda x: None):
        with pytest.raises(RuntimeError, match="NOT confirmed"):
            await hard_fence(broker, "i-stubborn", _phase1_seconds=1, _phase2_seconds=1)

    # Phase 1 + phase 2 = 2 terminate_instances calls minimum
    assert ec2.terminate_instances.call_count >= 2, (
        f"expected ≥2 terminate_instances calls across 2 phases, "
        f"got {ec2.terminate_instances.call_count}"
    )


@pytest.mark.asyncio
async def test_both_phases_exhausted_raises_escalation():
    """Instance never transitions — both phases exhaust their polls.
    hard_fence must raise with a clear escalation message."""
    from agents.broker.providers.aws import hard_fence

    broker, ec2 = _make_broker()
    ec2.terminate_instances.return_value = {}
    # Always returns running — never transitions
    ec2.describe_instances.return_value = {
        "Reservations": [{"Instances": [{"State": {"Name": "running"}}]}]
    }

    with patch("agents.broker.providers.aws.asyncio.sleep", new=AsyncMock()), \
         patch("shared.retry.time.sleep", lambda x: None):
        with patch("shared.retry.time.sleep", lambda x: None):
            with pytest.raises(RuntimeError, match="NOT confirmed"):
                await hard_fence(broker, "i-zombie", _phase1_seconds=1, _phase2_seconds=1)


@pytest.mark.asyncio
async def test_instance_disappears_mid_poll_treated_as_terminated():
    """If describe_instances returns empty Reservations (instance gone),
    treat as successfully terminated."""
    from agents.broker.providers.aws import hard_fence

    broker, ec2 = _make_broker()
    ec2.terminate_instances.return_value = {}
    # First poll: empty — instance already disappeared
    ec2.describe_instances.return_value = {"Reservations": []}

    with patch("agents.broker.providers.aws.asyncio.sleep", new=AsyncMock()), \
         patch("shared.retry.time.sleep", lambda x: None):
        await hard_fence(broker, "i-vanished", _phase1_seconds=1, _phase2_seconds=1)

    # Only one terminate call — phase 1 confirmed success
    assert ec2.terminate_instances.call_count == 1
