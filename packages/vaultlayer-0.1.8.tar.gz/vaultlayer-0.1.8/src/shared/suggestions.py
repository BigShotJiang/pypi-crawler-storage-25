"""Expand-consent suggestion generator.

When a job's --provider/--regions filter yields no provider with capacity, the
server returns HTTP 202 with a list of nearby region codes and other routable
provider names so the CLI can prompt the user to widen the search.

This module is the single source of truth for "what should we suggest." It
reads from config/vaultlayer_data.json (region_adjacency + routable_regions +
provider_prices) so adding a new region or provider needs only a config edit.
"""
from __future__ import annotations

from typing import TypedDict

from shared.data_loader import (
    get_provider_prices,
    get_region_adjacency,
    get_routable_region_codes,
)


class RegionSuggestion(TypedDict):
    nearby: list[str]  # adjacency-map neighbours of the constrained set, deduped, sorted
    all: list[str]     # every routable region not already in the constrained set, sorted


class ProviderSuggestion(TypedDict):
    add: list[str]  # every routable provider not already in the constrained set, sorted


class Suggestions(TypedDict):
    add_regions: RegionSuggestion
    add_providers: ProviderSuggestion


def routable_provider_names() -> list[str]:
    """Provider names the dispatcher will actually attempt.

    Per CLAUDE.md rule 10, the keys of provider_prices gate routing — but
    src/api/job_worker.py also explicitly skips entries containing 'Reserved'
    or 'On-Demand' (those are reference rates for savings comparison, not
    dispatch targets). We mirror that filter here so suggestions and
    submit-flow validation surface only providers that can actually accept a
    job. Keep this in sync with the loop guard in job_worker.py.
    """
    return sorted(
        p for p in get_provider_prices().keys()
        if not p.startswith("_")
        and "Reserved" not in p
        and "On-Demand" not in p
    )


def get_suggestions(
    constrained_regions: list[str],
    constrained_providers: list[str],
) -> Suggestions:
    """Build the expand-consent suggestion payload.

    Args:
        constrained_regions: the user's current --regions filter (post-dedupe).
        constrained_providers: the user's current --provider filter (post-dedupe).

    Returns:
        {
          "add_regions":   {"nearby": [...], "all": [...]},
          "add_providers": {"add":    [...]},
        }

    Behaviour:
      - `nearby` is the union of region_adjacency[r] for each r in
        constrained_regions, intersected with the routable_regions set, minus
        any region already in constrained_regions. Sorted ascending so
        suggestions are deterministic across calls (important for CLI numbering
        and for snapshot tests).
      - `all` is every routable region not already in constrained_regions.
      - `add` (providers) is every routable provider not already in
        constrained_providers.
      - All inputs are normalised via set() so duplicates from the caller are
        silently absorbed.
    """
    constrained_r = set(constrained_regions)
    constrained_p = set(constrained_providers)

    routable_regions = set(get_routable_region_codes())
    adjacency = get_region_adjacency()

    nearby_set: set[str] = set()
    for r in constrained_r:
        for neighbour in adjacency.get(r, []):
            if neighbour in routable_regions and neighbour not in constrained_r:
                nearby_set.add(neighbour)

    all_set = routable_regions - constrained_r
    add_providers = [p for p in routable_provider_names() if p not in constrained_p]

    return {
        "add_regions": {
            "nearby": sorted(nearby_set),
            "all":    sorted(all_set),
        },
        "add_providers": {
            "add": add_providers,
        },
    }
