"""
VaultLayer — AWS STS Session Manager
Cross-account IAM bridge via AssumeRole for least-privilege access.
"""

import asyncio
import logging
import threading
import time
from typing import Optional

import boto3

from shared.config import VaultLayerConfig

logger = logging.getLogger(__name__)


class STSSessionManager:
    """
    Manages temporary AWS credentials via STS AssumeRole.
    Caches credentials and refreshes 5 minutes before expiry.
    Falls back to static credentials when STS is not configured.
    """

    REFRESH_BUFFER_SECONDS = 300  # refresh 5 min before expiry

    def __init__(self, config: VaultLayerConfig):
        self.config = config
        self._credentials: Optional[dict] = None
        self._expiry: float = 0  # monotonic timestamp
        self._refresh_timer: Optional[threading.Timer] = None
        # Lock around cache read/_assume_role so concurrent provision calls
        # don't stampede STS on cache miss. AWS STS has a 600 req/s per-account
        # limit (per TAM); under concurrent load a stampede could exhaust it.
        # Reentrant so _assume_role can be called from within a locked read
        # section without deadlocking.
        self._lock = threading.RLock()

    @property
    def is_configured(self) -> bool:
        """Return True if STS cross-account access is configured."""
        return self.config.sts is not None and bool(self.config.sts.role_arn)

    def get_credentials(self, job_id: str = "unknown") -> dict:
        """
        Return AWS credentials dict for boto3 clients.
        Uses STS AssumeRole if configured, otherwise static credentials.

        Returns dict with keys: aws_access_key_id, aws_secret_access_key,
        and optionally aws_session_token (when using STS).
        """
        if not self.is_configured:
            if not self.config.aws:
                raise RuntimeError(
                    "AWS credentials not configured — set AWS_ACCESS_KEY_ID / "
                    "AWS_SECRET_ACCESS_KEY or a VL_STS_ROLE_ARN in your config."
                )
            return {
                "aws_access_key_id": self.config.aws.access_key_id,
                "aws_secret_access_key": self.config.aws.secret_access_key,
            }

        # Lock-protected read: concurrent callers see the same cache.
        # Double-checked locking: first read without lock (fast path), then
        # confirm under lock before issuing a fresh AssumeRole.
        now = time.monotonic()
        if self._credentials and now < (self._expiry - self.REFRESH_BUFFER_SECONDS):
            return self._credentials

        with self._lock:
            # Re-check under lock — another thread may have refreshed while
            # we waited. This is the "double-checked" part; prevents a
            # stampede where N concurrent callers all trigger AssumeRole.
            now = time.monotonic()
            if self._credentials and now < (self._expiry - self.REFRESH_BUFFER_SECONDS):
                return self._credentials
            try:
                return self._assume_role(job_id)
            except Exception as e:
                import botocore.exceptions
                if isinstance(e, botocore.exceptions.ClientError):
                    code = e.response.get("Error", {}).get("Code", "")
                    if code == "UnauthorizedOperation":
                        logger.warning(f"[STS] UnauthorizedOperation — forcing token refresh and retrying")
                        self._credentials = None
                        self._expiry = 0
                        return self._assume_role(job_id)
                raise

    def _assume_role(self, job_id: str) -> dict:
        """Call STS AssumeRole and cache the temporary credentials."""
        sts_config = self.config.sts
        sts_client = boto3.client(
            "sts",
            aws_access_key_id=self.config.aws.access_key_id,
            aws_secret_access_key=self.config.aws.secret_access_key,
            region_name=self.config.aws.region,
        )

        assume_kwargs = {
            "RoleArn": sts_config.role_arn,
            "RoleSessionName": f"vaultlayer-{job_id[:32]}",
            "DurationSeconds": sts_config.session_duration,
        }
        if sts_config.external_id:
            assume_kwargs["ExternalId"] = sts_config.external_id

        logger.info(f"STS AssumeRole: {sts_config.role_arn} (session: vaultlayer-{job_id[:32]})")
        response = sts_client.assume_role(**assume_kwargs)
        creds = response["Credentials"]

        self._credentials = {
            "aws_access_key_id": creds["AccessKeyId"],
            "aws_secret_access_key": creds["SecretAccessKey"],
            "aws_session_token": creds["SessionToken"],
        }
        self._expiry = time.monotonic() + sts_config.session_duration
        logger.info("STS credentials acquired, valid for "
                     f"{sts_config.session_duration}s")
        return self._credentials

    def _schedule_background_refresh(self):
        """Schedule a threading.Timer to refresh credentials before they expire."""
        if not self.is_configured or self._expiry == 0:
            return
        now = time.monotonic()
        sleep_seconds = max(self._expiry - now - self.REFRESH_BUFFER_SECONDS, 1)
        if self._refresh_timer is not None:
            self._refresh_timer.cancel()
        self._refresh_timer = threading.Timer(sleep_seconds, self._proactive_refresh)
        self._refresh_timer.daemon = True
        self._refresh_timer.start()
        logger.debug(f"[STS] Background refresh scheduled in {sleep_seconds:.0f}s")

    def _proactive_refresh(self):
        """Called by background timer to refresh credentials before expiry."""
        try:
            self._assume_role("background-refresh")
            logger.info("[STS] Proactive credential refresh succeeded")
            self._schedule_background_refresh()
        except Exception as e:
            logger.error(f"[STS] Proactive refresh failed: {e} — will retry at next get_credentials() call")

    async def _background_refresh_loop(self):
        """Async background refresh loop — sleeps until REFRESH_BUFFER_SECONDS before expiry."""
        while True:
            if not self.is_configured or self._expiry == 0:
                await asyncio.sleep(60)
                continue
            now = time.monotonic()
            sleep_seconds = max(self._expiry - now - self.REFRESH_BUFFER_SECONDS, 1)
            await asyncio.sleep(sleep_seconds)
            try:
                self._assume_role("background-refresh")
                logger.info("[STS] Proactive credential refresh succeeded")
            except Exception as e:
                logger.error(f"[STS] Proactive refresh failed: {e}")

    async def start_background_refresh(self):
        """Start the async background refresh task (call from broker agent start())."""
        if not self.is_configured:
            return
        asyncio.create_task(self._background_refresh_loop())
        logger.info("[STS] Background credential refresh task started")

    def get_ec2_client(self, job_id: str = "unknown", region: str = None):
        """Return a boto3 EC2 client using the appropriate credentials."""
        creds = self.get_credentials(job_id)
        resolved_region = region or (self.config.aws.region if self.config.aws else "us-east-1")
        return boto3.client(
            "ec2",
            region_name=resolved_region,
            **creds,
        )

    def get_pricing_client(self, job_id: str = "unknown"):
        """Return a boto3 Pricing client. Pricing API is only in us-east-1."""
        creds = self.get_credentials(job_id)
        return boto3.client("pricing", region_name="us-east-1", **creds)
