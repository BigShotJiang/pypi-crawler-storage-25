"""
VaultLayer — Shared Data Models
Pydantic models used across all agents via the Redis message queue.
"""

from __future__ import annotations
from enum import Enum
from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field
import uuid


# ── Enums ─────────────────────────────────────────────────────────────────────

class Provider(str, Enum):
    AWS = "aws"
    LAMBDA_LABS = "lambda_labs"
    COREWEAVE = "coreweave"
    GCP = "gcp"
    AZURE = "azure"
    # Dark pool / regional providers
    RUNPOD = "runpod"            # Spot-market REST API, H100 at ~$2.49/hr
    VAST_AI = "vast_ai"          # True spot auction, cheapest off-peak
    VOLTAGE_PARK = "voltage_park" # Fixed ~$2/hr H100 SXM5, stable floor
    CRUSOE = "crusoe"            # Stranded-energy pricing, ~30% below AWS
    NEBIUS = "nebius"            # EU-native (Frankfurt), GDPR-compliant H100s
    HYPERSTACK = "hyperstack"    # UK/EU cloud, H100/A100 spot pricing


class GPUType(str, Enum):
    H100_80GB_SXM = "H100_80GB_SXM"
    H100_80GB_PCIE = "H100_80GB_PCIE"
    A100_80GB_SXM = "A100_80GB_SXM"
    A100_40GB = "A100_40GB"
    A10G = "A10G"
    # 2025-2026 GPU types
    H100_80GB_NVL = "H100_80GB_NVL"    # NVLink multi-GPU (RunPod, Vast.ai)
    H200 = "H200"                       # Next-gen Hopper (Lambda, CoreWeave)
    B200 = "B200"                       # Blackwell (emerging availability)
    A6000 = "A6000"                     # Professional Ampere (Vast.ai, Hyperstack)
    RTX4090 = "RTX4090"                 # Vast.ai consumer-grade spot
    RTX3090 = "RTX3090"                 # Vast.ai legacy spot
    A40 = "A40"                         # RunPod / Vast.ai mid-tier
    L40S = "L40S"                       # Ada Lovelace, inference-optimised
    V100_16GB = "V100_16GB"             # AWS p3.2xlarge (8 vCPU, 1× V100-16GB) — fits P-Spot 8 vCPU quota


class JobStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    CHECKPOINTING = "checkpointing"
    MIGRATING = "migrating"
    COMPLETED = "completed"
    INTERRUPTED = "interrupted"
    FAILED = "failed"


class JobRunStatus(str, Enum):
    """Status values for a single job_run row (one entry per provisioning attempt).

    Mirrors the CHECK constraint on job_runs.status in
    schema/migrations/0009_job_runs.sql + 0021_job_runs_consent_statuses.sql.
    Distinct from JobStatus, which tracks the parent jobs row.
    """
    PROVISIONING = "provisioning"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    TERMINATED = "terminated"
    TERMINATION_FAILED = "termination_failed"
    AWAITING_EXPAND_CONSENT = "awaiting_expand_consent"
    CANCELLED = "cancelled"


class ActionTier(str, Enum):
    AUTO = "auto"               # execute immediately
    AUTO_NOTIFY = "auto_notify" # execute + notify human
    CONFIRM = "confirm"         # wait for human confirmation


class EventType(str, Enum):
    # Watchdog events
    TERMINATION_SIGNAL = "termination_signal"
    HEARTBEAT_MISS = "heartbeat_miss"
    CHECKPOINT_COMPLETE = "checkpoint_complete"
    NODE_HEALTHY = "node_healthy"
    # Pricing events
    PRICE_UPDATE = "price_update"
    ARBITRAGE_OPPORTUNITY = "arbitrage_opportunity"
    # Broker events
    MIGRATION_STARTED = "migration_started"
    MIGRATION_COMPLETE = "migration_complete"
    MIGRATION_REQUESTED = "migration_requested"  # orchestration -> broker
    CHECKPOINT_READY = "checkpoint_ready"         # orchestration -> broker: checkpoint in R2
    NODE_PROVISIONED = "node_provisioned"
    # Watchdog failure events
    CHECKPOINT_REQUESTED = "checkpoint_requested"
    OOM_DETECTED = "oom_detected"
    GPU_FAILURE = "gpu_failure"
    HUNG_JOB = "hung_job"
    # Namespace events
    NAMESPACE_SYNC_COMPLETE = "namespace_sync_complete"
    # Orchestration events
    DECISION_MADE = "decision_made"
    ESCALATION = "escalation"
    # FinOps events
    JOB_COST_UPDATE = "job_cost_update"
    SAVINGS_REPORT = "savings_report"
    # CLI events
    STOP_REQUESTED = "stop_requested"
    # Credits events
    CREDITS_LOW = "credits_low"               # available balance < LOW_BALANCE_THRESHOLD_USD
    CREDITS_EXHAUSTED = "credits_exhausted"   # job must be suspended, checkpoint first
    CREDITS_TOPPED_UP = "credits_topped_up"   # Stripe payment confirmed, job may resume
    # GPU hot-swap events
    GPU_HOP_AVAILABLE = "gpu_hop_available"   # target GPU is now available — trigger migration
    GPU_HOP_COMPLETE  = "gpu_hop_complete"    # hot-swap finished, billing switches to target rate


class RecoveryLevel(str, Enum):
    """Five-level recovery hierarchy, in escalation order.

    When a job fails or loses its node, OrchestrationAgent climbs this
    ladder until the job resumes or is escalated to the user.

    Level 1 — DLQ_RETRY: Transient failure. Retry on the same provider +
        region + GPU (up to 3 attempts, exponential backoff). Covers network
        blips, spot evictions with immediate re-availability.

    Level 2 — REGION_HOP: Persistent failure in one region. Move to a
        different region on the same provider (e.g. us-east-1 → us-west-2).
        Checkpoint is in R2 (zero egress); compute cost is marginally different.

    Level 3 — PROVIDER_HOP: GPU type available but not on this provider.
        Cross-provider migration, same GPU. Egress payback rule applies
        (10-hour threshold in egress.py). Tier 3 markup applied.

    Level 4 — GPU_HOP: Target GPU unavailable everywhere. Migrate to the
        next-cheapest GPU type the user has consented to. Triggers
        gpu_hop_consented flow in OrchestrationAgent. Tier 3 markup applied.

    Level 5 — HUMAN_ESCALATION: All automatic options exhausted or user
        consent required for a destructive action. Publishes to the
        "escalate" channel. Job halts pending user response.
    """
    DLQ_RETRY          = "dlq_retry"           # Level 1: same provider/region/GPU, backoff retry
    REGION_HOP         = "region_hop"           # Level 2: different region, same provider + GPU
    PROVIDER_HOP       = "provider_hop"         # Level 3: different provider, same GPU
    GPU_HOP            = "gpu_hop"              # Level 4: different GPU type, any provider
    HUMAN_ESCALATION   = "human_escalation"     # Level 5: user consent required / halt


# ── Core Models ────────────────────────────────────────────────────────────────

class GPUPrice(BaseModel):
    """Normalized price record from any provider."""
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    gpu: GPUType
    provider: Provider
    region: str = ""
    price_per_hour: float
    availability: str  # "high" | "medium" | "low" | "unavailable"
    queue_depth_minutes: int = 0
    is_spot: bool = False


class CheckpointType(str, Enum):
    FULL = "full"    # complete weight snapshot — the base keyframe
    DELTA = "delta"  # XOR diff against a previous full snapshot


class CheckpointRecord(BaseModel):
    """Metadata for a checkpoint stored in R2."""
    checkpoint_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    job_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    step: int
    epoch: float
    r2_key: str               # path in R2 bucket
    size_bytes: int           # original (uncompressed) file size
    sync_duration_seconds: float
    model_params_billion: float
    training_loss: Optional[float] = None
    # Delta fields — None for full snapshots
    checkpoint_type: CheckpointType = CheckpointType.FULL
    base_step: Optional[int] = None        # full-snapshot step this delta chains from
    delta_size_bytes: Optional[int] = None # compressed delta bytes actually stored in R2


class Job(BaseModel):
    """Represents a running or completed training job."""
    job_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    status: JobStatus = JobStatus.QUEUED
    provider: Provider
    gpu_type: GPUType
    user_id: str = ""          # owner identity for RBAC namespace isolation
    instance_id: str = ""      # cloud provider instance ID (empty until provisioned)
    region: str = ""
    model_params_billion: float = 0.0
    command: str = ""          # original user command
    docker_image: str = ""     # container image for environment replication
    environment: Dict[str, str] = Field(default_factory=dict)  # env vars for replication
    mount_config: Dict[str, Any] = Field(default_factory=dict)  # R2/FUSE mount config
    dataset_size_gb: float = 0.0     # training dataset size; used to compute egress cost
    dataset_location: str = "s3"     # source storage system:
    # "s3"          → AWS S3 (playbook: stay in AWS; cross-hop only if dataset<100GB or savings>egress)
    # "gcs"         → GCP Cloud Storage (playbook: prefer GCP Preemptible; egress $0.10/GB to others)
    # "azure_blob"  → Azure Blob Storage (playbook: prefer Azure Spot; egress $0.085/GB, 100GB free)
    # "r2"          → Cloudflare R2 (zero egress to any provider — use freely)
    # "local"       → NVMe/local disk (zero egress — portable)
    dataset_cloud: str = ""          # explicit source cloud override: "aws" | "gcp" | "azure" | ""
    # When set, overrides the cloud inferred from dataset_location. Used when a job's data
    # lives in a managed cloud service that isn't directly expressed by dataset_location
    # (e.g., BigQuery ML → "gcp", Azure ML → "azure", SageMaker → "aws").
    enterprise_compliance: bool = False  # True = job has security compliance constraints (HIPAA/FedRAMP)
    # When True, the Azure and GCP playbooks suppress cross-cloud migration suggestions
    # since moving data off the source cloud may violate BAA, FedRAMP, or data residency rules.
    training_duration_hours: float = 1.0  # estimated total training time; used to amortise egress
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    current_step: int = 0
    current_epoch: float = 0.0
    total_steps: Optional[int] = None
    progress_pct: float = 0.0
    last_checkpoint: Optional[CheckpointRecord] = None
    last_heartbeat_at: Optional[datetime] = None
    dataset_id: Optional[str] = None
    total_spend_usd: float = 0.0
    aws_equivalent_usd: float = 0.0     # what this would cost on AWS OD
    interruption_count: int = 0
    progress_lost_minutes: float = 0.0
    # GAP-6: SSH host for STONITH fencing on voluntary migration
    ssh_host: Optional[str] = None
    # GAP-19: Source GPU compute capability for parity check on target node
    source_compute_cap: Optional[float] = None
    # GAP-24: Billing rate and dataset region for sunk-cost/cross-region calculations
    current_hourly_rate: float = 0.0
    dataset_region: str = ""
    # Training mode: "qlora" | "lora" | "full" — used for cost recommendations
    training_mode: str = "qlora"
    # Credits: reservation held at job start; released on settle/cancel
    credits_reserved_usd: float = 0.0
    # Region compliance — empty list = no restriction (any region is allowed)
    regions: List[str] = Field(default_factory=list)           # whitelist; provision only in these regions
    excluded_regions: List[str] = Field(default_factory=list)  # denylist (OFAC, GDPR, export controls)
    # Provider constraint — empty preferred list = any routable provider is allowed.
    # Values are provider_prices keys ("AWS Spot", "Lambda Labs", ...) so they round-trip
    # through unknown-provider validation in src/api/job_routes.py.
    preferred_providers: List[str] = Field(default_factory=list)  # whitelist; expandable via consent UX
    excluded_providers: List[str] = Field(default_factory=list)   # denylist; never relaxed (compliance/cost guardrail)
    # Migration tracking — updated by BrokerAgent on each successful migration
    migration_count: int = 0
    first_migration_at: Optional[datetime] = None
    # P0-C5: Dead-letter queue / provision retry budget
    provision_failure_count: int = 0      # incremented each time all providers fail
    dlq_at: Optional[datetime] = None     # timestamp when job entered DLQ (INTERRUPTED)
    max_provision_failures: int = 5       # escalate to permanent FAILED after this many DLQ cycles
    # Same-provider retry (Issue #12): track current AZ so retry skips the failed one
    availability_zone: str = ""           # AZ the instance is running in (e.g. "us-east-1b")
    # Flow C: Fully Managed — VaultLayer provides compute + storage
    managed_flow: bool = False            # True = Flow C (VaultLayer provisions from corporate accounts)
    failover_enabled: bool = False        # True = auto-recover on interruption using fallback ladder
    billing_frozen_at: Optional[datetime] = None  # set during migration window, cleared on resume
    # Provision error tracking — surfaces the actual failure reason to users
    last_provision_error: str = ""  # human-readable reason for last provision failure (cleared on success)
    # Lifecycle Gate framework (see src/shared/failure_codes.py). When a job
    # ends with status=failed, `failure_code` SHOULD be one of JobFailureCode
    # values; the free-form `failure_detail` carries specifics. Older code
    # paths still write `error` / `last_provision_error` only — those are
    # read-compatible but don't populate the code field yet. New code sites
    # should set both.
    failure_code:   Optional[str] = None  # JobFailureCode value (string enum)
    failure_detail: Optional[str] = None  # <500 chars of specifics
    # Chain-walk checkpoint forwarding: when the runner creates a new job after
    # a capacity/infra failure, it sets this to the previous job_id so the
    # broker can pull prior checkpoints from R2 before training starts.
    resume_from_job_id: Optional[str] = None


class AgentEvent(BaseModel):
    """Message passed between agents via Redis."""
    schema_version: int = 1    # GAP-31: protocol version for forward-compat checks
    event_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    event_type: EventType
    source_agent: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    job_id: Optional[str] = None
    payload: Dict[str, Any] = {}
    priority: int = 5          # 1 = highest, 10 = lowest


class OrchestrationDecision(BaseModel):
    """Decision made by the Orchestration Agent (Claude)."""
    decision_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    job_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    action: str                # "checkpoint" | "migrate" | "wait" | "escalate"
    reasoning: str             # Claude's plain-English reasoning
    action_plan: List[str] = []
    confidence: float          # 0.0–1.0
    tier: ActionTier
    target_provider: Optional[Provider] = None
    target_gpu: Optional[GPUType] = None
    estimated_savings_per_hour: float = 0.0
    estimated_downtime_minutes: float = 0.0
    requires_human_confirmation: bool = False
    executed: bool = False
    executed_at: Optional[datetime] = None
    # ── Egress cost analysis (Golden Ratio / 10-Hour Rule) ────────────────────
    egress_cost_usd: float = 0.0          # one-time dataset transfer cost for this hop
    payback_hours: float = 0.0            # hours until egress fee is earned back
    same_cloud_hop: bool = False          # True → zero egress (same cloud or R2/local)
    egress_verdict: str = ""              # human-readable reason from EgressCostEngine
    resume_compute_cost_usd: float = 0.0  # target_price × estimated_remaining_hours
    resume_total_cost_usd: float = 0.0    # compute + egress (total cost of this hop)


class MigrationPlan(BaseModel):
    """Human-readable migration plan shown before execution."""
    job_id: str
    job_name: str
    from_provider: Provider
    to_provider: Provider
    to_gpu: GPUType
    steps: List[str]
    estimated_downtime_minutes: float
    progress_at_risk_pct: float = 0.0   # always 0 if checkpoint completes
    savings_per_hour: float
    savings_total_usd: float
    is_reversible: bool = True
    revert_window_minutes: int = 5


class SavingsReport(BaseModel):
    """Per-job savings summary generated by FinOps Agent."""
    job_id: str
    job_name: str
    narrative: str             # Claude-generated human-readable summary
    duration_hours: float
    actual_spend_usd: float
    aws_equivalent_usd: float
    savings_usd: float
    savings_pct: float
    interruptions_recovered: int
    progress_lost_minutes: float
    dashboard_url: str
    providers_used: List[Provider] = []
