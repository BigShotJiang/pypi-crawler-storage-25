"""Bill Auditor — validates received provider bills against VaultLayer expectations.

Called from job_run_logger.close_run() when provider_billed_usd is set,
and can be called ad-hoc against historical job_runs records.

Discrepancy categories:
  OVERCHARGE   — provider charged more than expected (> tolerance)
  UNDERCHARGE  — provider charged less (possible credit/promo — still log it)
  MISSING_BILL — provider_billed_usd not set but job is terminated
  ZERO_COST    — billing_seconds > 0 but billed amount is 0 (possible API/billing bug)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)

# Tolerance band: discrepancies within ±10% are silently accepted as normal rounding / per-second billing.
DEFAULT_TOLERANCE_PCT = 0.10
# Alert threshold: discrepancies > 25% get a WARNING log (candidate for manual review).
ALERT_THRESHOLD_PCT = 0.25


class DiscrepancyKind(str, Enum):
    OVERCHARGE = "OVERCHARGE"
    UNDERCHARGE = "UNDERCHARGE"
    MISSING_BILL = "MISSING_BILL"
    ZERO_COST = "ZERO_COST"


@dataclass
class BillDiscrepancy:
    run_id: str
    kind: DiscrepancyKind
    expected_usd: float
    actual_usd: Optional[float]
    delta_usd: float
    delta_pct: float
    provider: str
    billing_seconds: int
    message: str


def audit_bill(
    run_id: str,
    provider: str,
    billing_seconds: int,
    rate_per_hr: float,
    estimated_cost_usd: float,
    provider_billed_usd: Optional[float],
    tolerance_pct: float = DEFAULT_TOLERANCE_PCT,
) -> Optional[BillDiscrepancy]:
    """Check a single job run's received bill against the VaultLayer estimate.

    Returns a BillDiscrepancy if an issue is detected, otherwise None.
    Logs warnings for any discrepancy above ALERT_THRESHOLD_PCT.
    """
    # Missing bill — job is closed but we have no provider charge yet
    if provider_billed_usd is None:
        # Not necessarily an error — some providers send invoices async.
        # Return a MISSING_BILL only if billing_seconds > 0.
        if billing_seconds > 0:
            disc = BillDiscrepancy(
                run_id=run_id,
                kind=DiscrepancyKind.MISSING_BILL,
                expected_usd=estimated_cost_usd,
                actual_usd=None,
                delta_usd=estimated_cost_usd,
                delta_pct=1.0,
                provider=provider,
                billing_seconds=billing_seconds,
                message=(
                    f"No provider bill received for {run_id} "
                    f"(billed {billing_seconds}s @ ${rate_per_hr}/hr, "
                    f"expected ~${estimated_cost_usd:.4f})"
                ),
            )
            logger.debug(disc.message)
            return disc
        return None

    # Zero-cost anomaly
    if provider_billed_usd == 0.0 and billing_seconds > 0:
        disc = BillDiscrepancy(
            run_id=run_id,
            kind=DiscrepancyKind.ZERO_COST,
            expected_usd=estimated_cost_usd,
            actual_usd=0.0,
            delta_usd=estimated_cost_usd,
            delta_pct=1.0,
            provider=provider,
            billing_seconds=billing_seconds,
            message=(
                f"Provider {provider} billed $0 for {billing_seconds}s run "
                f"(expected ~${estimated_cost_usd:.4f}). Possible billing API bug."
            ),
        )
        logger.warning(disc.message)
        return disc

    delta = provider_billed_usd - estimated_cost_usd
    delta_pct = abs(delta) / estimated_cost_usd if estimated_cost_usd > 0 else 0.0

    # Within tolerance — all good
    if delta_pct <= tolerance_pct:
        return None

    kind = DiscrepancyKind.OVERCHARGE if delta > 0 else DiscrepancyKind.UNDERCHARGE
    message = (
        f"{kind.value}: provider={provider}, run={run_id}, "
        f"expected=${estimated_cost_usd:.4f}, billed=${provider_billed_usd:.4f}, "
        f"delta=${delta:+.4f} ({delta_pct*100:.1f}%), "
        f"billing_seconds={billing_seconds}"
    )

    disc = BillDiscrepancy(
        run_id=run_id,
        kind=kind,
        expected_usd=estimated_cost_usd,
        actual_usd=provider_billed_usd,
        delta_usd=delta,
        delta_pct=delta_pct,
        provider=provider,
        billing_seconds=billing_seconds,
        message=message,
    )

    if delta_pct > ALERT_THRESHOLD_PCT:
        logger.warning(message)
    else:
        logger.info(message)

    return disc


def audit_run_record(record: dict, tolerance_pct: float = DEFAULT_TOLERANCE_PCT) -> Optional[BillDiscrepancy]:
    """Convenience wrapper: pass a job_runs row dict directly.

    Expected keys: run_id, provider, billing_seconds, rate_per_hr,
                   estimated_cost_usd, provider_billed_usd
    """
    return audit_bill(
        run_id=record.get("run_id", ""),
        provider=record.get("provider", "unknown"),
        billing_seconds=record.get("billing_seconds") or 0,
        rate_per_hr=record.get("rate_per_hr") or 0.0,
        estimated_cost_usd=record.get("estimated_cost_usd") or 0.0,
        provider_billed_usd=record.get("provider_billed_usd"),
        tolerance_pct=tolerance_pct,
    )
