from __future__ import annotations
"""
VaultLayer -- Price Guard
Protects VaultLayer margin when provider prices change.

Three protection layers:
  1. Gainshare fee      -- compute user charge via dynamic spread-based gainshare
  2. Price change alert -- publish to Redis when price moves > threshold
  3. Staleness guard    -- refuse to provision if price data is too old

Gainshare model (no monthly subscription fee):
  Baseline Anchor = on-demand rate of the user's current/target provider (per GPU/hr)
  Sourced Cost    = rate VaultLayer secures on spot/dark-pool (per GPU/hr)

  Standard Rule (savings > 25% of baseline):
    VL Fee = (Baseline - Sourced) × 0.40
    User pays: Sourced + VL Fee

  Fallback Rule (savings ≤ 25% of baseline — tight market):
    VL Fee = (Baseline - Sourced) × 0.50
    User pays: Sourced + VL Fee

  In both cases the user saves money vs their baseline; VaultLayer captures
  40% or 50% of the savings as its revenue.

Used by BrokerAgent before every provision call.
Used by PricingAgent after every poll to write live prices back to data file.
"""

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ── Configuration ─────────────────────────────────────────────────────────────

VL_MARGIN          = float(os.getenv("VL_MARGIN", "1.15"))       # legacy flat markup (kept for check_margin)
MIN_MARGIN         = float(os.getenv("VL_MIN_MARGIN", "1.05"))   # 5% floor -- block below this
PRICE_ALERT_PCT    = float(os.getenv("VL_PRICE_ALERT_PCT", "5")) # alert if price moves >5%
MAX_PRICE_AGE_SECS = int(os.getenv("VL_MAX_PRICE_AGE_SECS", "600"))  # 10 min staleness limit

# Gainshare parameters (configurable for experimentation)
GAINSHARE_STANDARD_PCT  = float(os.getenv("VL_GAINSHARE_STANDARD_PCT",  "0.40"))  # 40% of savings
GAINSHARE_FALLBACK_PCT  = float(os.getenv("VL_GAINSHARE_FALLBACK_PCT",  "0.50"))  # 50% when tight
GAINSHARE_THRESHOLD_PCT = float(os.getenv("VL_GAINSHARE_THRESHOLD_PCT", "0.25"))  # 25% of baseline

# On-demand baseline anchors per provider, per GPU (single-GPU $/hr, March 2026).
# These are the rates users currently pay on their "home" provider.
# Used as the anchor in the gainshare formula.
# Override any value via VL_ANCHOR_{PROVIDER}_{GPU}=X.xx env var.
BASELINE_ANCHORS: dict[str, dict[str, float]] = {
    "AWS": {
        "H100":  float(os.getenv("VL_ANCHOR_AWS_H100",  "3.93")),
        "A100":  float(os.getenv("VL_ANCHOR_AWS_A100",  "4.10")),  # p4d.24xlarge /8
        "A10G":  float(os.getenv("VL_ANCHOR_AWS_A10G",  "1.01")),  # g5.xlarge
    },
    "Lambda Labs": {
        "H100":  float(os.getenv("VL_ANCHOR_LAMBDA_H100", "2.99")),
        "A100":  float(os.getenv("VL_ANCHOR_LAMBDA_A100", "1.72")),
        "A10G":  float(os.getenv("VL_ANCHOR_LAMBDA_A10G", "0.75")),
    },
    "CoreWeave": {
        "H100":  float(os.getenv("VL_ANCHOR_COREWEAVE_H100", "3.25")),
        "A100":  float(os.getenv("VL_ANCHOR_COREWEAVE_A100", "1.81")),
        "A10G":  float(os.getenv("VL_ANCHOR_COREWEAVE_A10G", "0.78")),
    },
    "RunPod": {
        "H100":  float(os.getenv("VL_ANCHOR_RUNPOD_H100", "2.99")),
        "A100":  float(os.getenv("VL_ANCHOR_RUNPOD_A100", "1.59")),
        "A10G":  float(os.getenv("VL_ANCHOR_RUNPOD_A10G", "0.44")),
    },
    "Vast.ai": {
        "H100":  float(os.getenv("VL_ANCHOR_VAST_H100", "2.49")),
        "A100":  float(os.getenv("VL_ANCHOR_VAST_A100", "1.29")),
        "A10G":  float(os.getenv("VL_ANCHOR_VAST_A10G", "0.44")),
    },
}
# Default anchor when provider/GPU not found — use AWS H100 (most common baseline)
_DEFAULT_ANCHOR = float(os.getenv("VL_ANCHOR_DEFAULT", "3.93"))

_DATA_PATHS = [
    Path(__file__).parent.parent.parent / "config" / "vaultlayer_data.json",
    Path("config/vaultlayer_data.json"),
]


# ── Gainshare Engine ──────────────────────────────────────────────────────────

class MarginViolation(Exception):
    """Raised when provisioning would cause VaultLayer to lose money."""
    pass


class PriceStaleError(Exception):
    """Raised when price data is too old to safely provision."""
    pass


def get_baseline_anchor(provider: str, gpu: str) -> float:
    """
    Return the on-demand anchor price ($/hr per GPU) for a provider/GPU pair.
    Normalises provider name and GPU key for fuzzy matching.
    Falls back to _DEFAULT_ANCHOR if not found.
    """
    # Normalise GPU key: "H100_80GB_SXM" → "H100"
    gpu_family = gpu.split("_")[0].upper()

    # Try exact provider name, then stripped/title-cased variants
    for prov_key in (provider, provider.replace("_", " ").title(), provider.upper()):
        if prov_key in BASELINE_ANCHORS:
            anchors = BASELINE_ANCHORS[prov_key]
            if gpu_family in anchors:
                return anchors[gpu_family]
            # Fall back to first available GPU family for this provider
            if anchors:
                return next(iter(anchors.values()))

    logger.debug(f"No baseline anchor for {provider}/{gpu} — using default ${_DEFAULT_ANCHOR:.2f}/hr")
    return _DEFAULT_ANCHOR


def gainshare_fee(
    baseline_anchor: float,
    sourced_cost: float,
) -> tuple[float, float, str]:
    """
    Compute VaultLayer's gainshare fee and the user's billed rate.

    Args:
        baseline_anchor: On-demand rate user was paying ($/hr per GPU).
        sourced_cost:    Rate VaultLayer secured on spot/dark-pool ($/hr per GPU).

    Returns:
        (vl_fee, user_billed_rate, rule_applied)
        rule_applied is "standard" (40% split) or "fallback" (50% split).

    Raises:
        MarginViolation if sourced_cost >= baseline_anchor (no savings to share).
    """
    if sourced_cost <= 0:
        raise ValueError(f"sourced_cost must be > 0, got {sourced_cost}")
    if baseline_anchor <= 0:
        raise ValueError(f"baseline_anchor must be > 0, got {baseline_anchor}")

    savings = baseline_anchor - sourced_cost

    if savings <= 0:
        raise MarginViolation(
            f"No savings: sourced ${sourced_cost:.2f}/hr >= baseline ${baseline_anchor:.2f}/hr. "
            f"Cannot apply gainshare — provisioning would not benefit the user."
        )

    threshold = baseline_anchor * GAINSHARE_THRESHOLD_PCT  # 25% of baseline

    if savings > threshold:
        # Standard Rule: 40% of savings
        fee = round(savings * GAINSHARE_STANDARD_PCT, 4)
        rule = "standard"
    else:
        # Fallback Rule: 50% of remaining spread (tight market)
        fee = round(savings * GAINSHARE_FALLBACK_PCT, 4)
        rule = "fallback"

    billed = round(sourced_cost + fee, 4)

    logger.debug(
        f"Gainshare [{rule}]: baseline=${baseline_anchor:.2f}, "
        f"sourced=${sourced_cost:.2f}, savings=${savings:.2f}, "
        f"fee=${fee:.2f} ({fee/savings*100:.0f}% of spread), "
        f"user_billed=${billed:.2f}"
    )
    return fee, billed, rule


def compute_user_charge(
    provider: str,
    gpu: str,
    sourced_cost_per_hr: float,
    baseline_anchor: Optional[float] = None,
) -> dict:
    """
    Full gainshare computation for a provider/GPU/sourced_cost combination.
    Returns a dict with all pricing components for transparency.

    Args:
        provider:            The provider being migrated FROM (baseline anchor source).
        gpu:                 GPU type string (e.g. "H100_80GB_SXM").
        sourced_cost_per_hr: What VaultLayer pays the target spot/dark-pool provider.
        baseline_anchor:     Override the anchor price ($/hr). Uses BASELINE_ANCHORS if None.
    """
    anchor = baseline_anchor if baseline_anchor is not None else get_baseline_anchor(provider, gpu)

    try:
        fee, billed, rule = gainshare_fee(anchor, sourced_cost_per_hr)
        savings_for_user = round(anchor - billed, 4)
        savings_pct = round((savings_for_user / anchor) * 100, 1) if anchor > 0 else 0
        return {
            "baseline_anchor":    anchor,
            "sourced_cost":       sourced_cost_per_hr,
            "vl_fee":             fee,
            "user_billed_rate":   billed,
            "user_savings":       savings_for_user,
            "user_savings_pct":   savings_pct,
            "rule":               rule,
            "provider":           provider,
            "gpu":                gpu,
        }
    except MarginViolation:
        # No savings available — charge baseline anchor (user pays same as before)
        logger.warning(
            f"Gainshare: no savings available for {provider}/{gpu} "
            f"(sourced ${sourced_cost_per_hr:.2f} >= baseline ${anchor:.2f}). "
            f"Falling back to baseline anchor as user charge."
        )
        return {
            "baseline_anchor":    anchor,
            "sourced_cost":       sourced_cost_per_hr,
            "vl_fee":             0.0,
            "user_billed_rate":   anchor,
            "user_savings":       0.0,
            "user_savings_pct":   0.0,
            "rule":               "no_savings",
            "provider":           provider,
            "gpu":                gpu,
        }


def check_margin(provider: str, gpu: str, live_cost_per_hour: float,
                 user_charge_per_hour: float) -> dict:
    """
    Verify provisioning will not lose money.

    Args:
        provider:             Provider name (for logging)
        gpu:                  GPU type (for logging)
        live_cost_per_hour:   What we actually pay the provider RIGHT NOW
        user_charge_per_hour: What we charge the user (from pricing agreement)

    Returns:
        dict with margin, margin_pct, safe: bool

    Raises:
        MarginViolation if margin < MIN_MARGIN
    """
    if live_cost_per_hour <= 0:
        return {"margin": 0, "margin_pct": 0, "safe": True}

    actual_margin = user_charge_per_hour / live_cost_per_hour
    margin_pct    = (actual_margin - 1) * 100

    result = {
        "provider":             provider,
        "gpu":                  gpu,
        "live_cost_per_hour":   live_cost_per_hour,
        "user_charge_per_hour": user_charge_per_hour,
        "margin_multiplier":    actual_margin,
        "margin_pct":           margin_pct,
        "safe":                 actual_margin >= MIN_MARGIN,
    }

    if actual_margin < 1.0:
        msg = (
            f"MARGIN VIOLATION: {provider} {gpu} -- "
            f"paying ${live_cost_per_hour:.2f}/hr, charging ${user_charge_per_hour:.2f}/hr "
            f"({margin_pct:.1f}% margin). Blocking provision."
        )
        logger.critical(msg)
        raise MarginViolation(msg)

    if actual_margin < MIN_MARGIN:
        msg = (
            f"LOW MARGIN WARNING: {provider} {gpu} -- "
            f"margin {margin_pct:.1f}% below floor {(MIN_MARGIN-1)*100:.0f}%. Blocking."
        )
        logger.error(msg)
        raise MarginViolation(msg)

    if margin_pct < 10:
        logger.warning(
            f"Thin margin on {provider} {gpu}: {margin_pct:.1f}% "
            f"(live=${live_cost_per_hour:.2f}, charge=${user_charge_per_hour:.2f})"
        )

    return result


# ?? Staleness Guard ??????????????????????????????????????????????????????????

def check_price_freshness(provider: str = "") -> None:
    """
    Raise PriceStaleError if price data is older than MAX_PRICE_AGE_SECS.
    Called by BrokerAgent before provisioning.
    """
    for path in _DATA_PATHS:
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                last_polled = data.get("_runtime", {}).get("last_polled_utc")
                if not last_polled:
                    logger.warning("Price freshness: no last_polled_utc in data file -- skipping staleness check")
                    return
                polled_dt = datetime.fromisoformat(last_polled)
                if polled_dt.tzinfo is None:
                    polled_dt = polled_dt.replace(tzinfo=timezone.utc)
                age_secs = (datetime.now(timezone.utc) - polled_dt).total_seconds()
                if age_secs > MAX_PRICE_AGE_SECS:
                    msg = (
                        f"Price data is {age_secs/60:.1f} minutes old "
                        f"(max: {MAX_PRICE_AGE_SECS/60:.0f} min). "
                        f"PricingAgent may be down. Blocking {provider} provision."
                    )
                    logger.error(msg)
                    raise PriceStaleError(msg)
                logger.debug(f"Price freshness OK: {age_secs:.0f}s old")
            except (PriceStaleError, json.JSONDecodeError):
                raise
            except Exception as e:
                logger.warning(f"Price freshness check failed (non-blocking): {e}")
            return
    logger.warning("config/vaultlayer_data.json not found -- skipping freshness check")


# ?? Price Change Detector ?????????????????????????????????????????????????????

class PriceChangeDetector:
    """
    Compares live prices against the last known values in vaultlayer_data.json.
    Emits alerts when prices move more than PRICE_ALERT_PCT.
    Called by PricingAgent after every poll.
    """

    def __init__(self):
        self._last_prices: dict = {}

    def check_and_update(self, provider: str, gpu: str, new_price: float) -> Optional[dict]:
        """
        Compare new_price against stored price.
        Returns an alert dict if change exceeds threshold, else None.
        """
        key = f"{provider}:{gpu}"
        old_price = self._last_prices.get(key)

        # Bootstrap from data file on first call
        if old_price is None:
            for path in _DATA_PATHS:
                if path.exists():
                    try:
                        d = json.load(open(path))
                        old_price = d.get("provider_prices", {}).get(provider, {}).get(gpu)
                    except Exception:
                        pass
                    break

        self._last_prices[key] = new_price

        if old_price is None or old_price <= 0:
            return None

        change_pct = abs(new_price - old_price) / old_price * 100
        direction  = "UP" if new_price > old_price else "DOWN"

        if change_pct >= PRICE_ALERT_PCT:
            alert = {
                "type":       "price_change",
                "provider":   provider,
                "gpu":        gpu,
                "old_price":  old_price,
                "new_price":  new_price,
                "change_pct": change_pct,
                "direction":  direction,
                "detected_at": datetime.now(timezone.utc).isoformat(),
            }
            lvl = "CRITICAL" if change_pct > 20 else "WARNING"
            logger.log(
                logging.CRITICAL if lvl == "CRITICAL" else logging.WARNING,
                f"PRICE CHANGE {lvl}: {provider} {gpu} {direction} "
                f"${old_price:.2f} -> ${new_price:.2f} ({change_pct:.1f}%)"
            )
            return alert
        return None


# ?? Live Price Writer ?????????????????????????????????????????????????????????

def write_live_prices_to_data_file(live_prices: dict) -> None:
    """
    Write freshly polled prices back to vaultlayer_data.json.
    Called by PricingAgent after every successful poll.

    KEY INVARIANT: price absent from API == GPU unavailable.
    If a GPU was previously priced but is NOT in live_prices this poll,
    its price is set to null. BrokerAgent treats null price as unavailable
    and will not attempt to provision that GPU.

    live_prices format: {provider_name: {gpu_key: price_or_null}}
    """
    for path in _DATA_PATHS:
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                pp = data.setdefault("provider_prices", {})
                changes = []
                nulled  = []
                for provider, gpu_prices in live_prices.items():
                    if provider not in pp:
                        pp[provider] = {}
                    # GPUs returned by this poll -- update price
                    for gpu, price in gpu_prices.items():
                        old = pp[provider].get(gpu)
                        if old != price:
                            changes.append(f"{provider}/{gpu}: {old}->{price}")
                        pp[provider][gpu] = price  # price=None means unavailable
                        if isinstance(price, (int, float)) and price > 0:
                            mark_gpu_seen(provider, gpu)
                    # GPUs previously in JSON but NOT returned this poll = unavailable.
                    # Only null if we previously SAW this GPU from this provider.
                    # Static fetchers return a fixed subset -- never null types they never track.
                    for gpu, old_price in list(pp.get(provider, {}).items()):
                        if gpu not in gpu_prices and old_price is not None:
                            if was_gpu_seen(provider, gpu):
                                pp[provider][gpu] = None
                                nulled.append(f"{provider}/{gpu} (was ${old_price})")
                                logger.warning(
                                    f"GPU UNAVAILABLE: {provider} {gpu} no longer in API response "
                                    f"-- set to null, blocking provision"
                                )
                            # else: provider never reported this GPU -- leave unchanged
                # Stamp runtime metadata
                data.setdefault("_runtime", {})["last_polled_utc"] = datetime.now(timezone.utc).isoformat()
                data["_runtime"]["poll_count"] = data["_runtime"].get("poll_count", 0) + 1
                if changes:
                    data["_runtime"]["last_price_changes"] = changes
                    logger.info(f"Price update: {len(changes)} change(s)")
                if nulled:
                    data["_runtime"]["last_unavailable"] = nulled
                    logger.warning(f"GPU availability change: {len(nulled)} GPU(s) went unavailable: {nulled}")
                with open(path, "w") as f:
                    json.dump(data, f, indent=2)
                return
            except Exception as e:
                logger.error(f"Failed to write live prices to data file: {e}")
            return
    logger.warning("config/vaultlayer_data.json not found -- live prices not persisted")