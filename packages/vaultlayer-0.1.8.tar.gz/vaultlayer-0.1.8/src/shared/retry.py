"""
VaultLayer — Retry utilities for external API calls.

Provides exponential-backoff retry for both sync and async callables.
Default policy: 3 attempts, delays [1s, 5s, 10s], retries on transient errors.

Usage (sync):
    result = sync_retry(lambda: stripe.Customer.retrieve(cid))

Usage (async):
    result = await async_retry(lambda: some_async_call())

Usage (decorator):
    @with_async_retry(attempts=3, delays=(1, 5, 10))
    async def my_function():
        ...
"""
from __future__ import annotations

import asyncio
import functools
import logging
import time
from typing import Any, Callable, Sequence, Tuple, Type

logger = logging.getLogger(__name__)

# Default retry policy
DEFAULT_ATTEMPTS = 3
DEFAULT_DELAYS: Tuple[float, ...] = (1.0, 5.0, 10.0)

# Transient error substrings — always retry these regardless of exception type
_TRANSIENT_MESSAGES = (
    "timeout",
    "timed out",
    "connection reset",
    "connection refused",
    "too many requests",
    "rate limit",
    "service unavailable",
    "internal server error",
    "bad gateway",
    "gateway timeout",
    "temporarily unavailable",
    "throttl",
    "502",
    "503",
    "504",
)


def _is_transient(exc: Exception) -> bool:
    """Heuristic: is this exception likely transient (worth retrying)?"""
    msg = str(exc).lower()
    return any(kw in msg for kw in _TRANSIENT_MESSAGES)


def sync_retry(
    fn: Callable[[], Any],
    *,
    attempts: int = DEFAULT_ATTEMPTS,
    delays: Sequence[float] = DEFAULT_DELAYS,
    retryable_exceptions: Tuple[Type[Exception], ...] = (Exception,),
    label: str = "",
) -> Any:
    """
    Run a synchronous callable with exponential backoff retry.

    Raises the last exception if all attempts fail.
    """
    last_exc: Exception = RuntimeError("No attempts made")
    for i in range(attempts):
        try:
            return fn()
        except retryable_exceptions as exc:
            last_exc = exc
            if i == attempts - 1:
                break  # last attempt — re-raise below
            if not _is_transient(exc):
                raise  # non-transient — fail fast
            delay = delays[i] if i < len(delays) else delays[-1]
            logger.warning(
                f"[retry] {'(' + label + ') ' if label else ''}attempt {i+1}/{attempts} "
                f"failed: {exc!r} — retrying in {delay}s"
            )
            time.sleep(delay)
    logger.error(
        f"[retry] {'(' + label + ') ' if label else ''}all {attempts} attempts failed: {last_exc!r}"
    )
    raise last_exc


async def async_retry(
    fn: Callable[[], Any],
    *,
    attempts: int = DEFAULT_ATTEMPTS,
    delays: Sequence[float] = DEFAULT_DELAYS,
    retryable_exceptions: Tuple[Type[Exception], ...] = (Exception,),
    label: str = "",
) -> Any:
    """
    Run an async callable (or sync callable returning a coroutine) with
    exponential backoff retry.

    Raises the last exception if all attempts fail.
    """
    last_exc: Exception = RuntimeError("No attempts made")
    for i in range(attempts):
        try:
            result = fn()
            if asyncio.iscoroutine(result):
                return await result
            return result
        except retryable_exceptions as exc:
            last_exc = exc
            if i == attempts - 1:
                break
            if not _is_transient(exc):
                raise
            delay = delays[i] if i < len(delays) else delays[-1]
            logger.warning(
                f"[retry] {'(' + label + ') ' if label else ''}attempt {i+1}/{attempts} "
                f"failed: {exc!r} — retrying in {delay}s"
            )
            await asyncio.sleep(delay)
    logger.error(
        f"[retry] {'(' + label + ') ' if label else ''}all {attempts} attempts failed: {last_exc!r}"
    )
    raise last_exc


def with_sync_retry(
    attempts: int = DEFAULT_ATTEMPTS,
    delays: Sequence[float] = DEFAULT_DELAYS,
    retryable_exceptions: Tuple[Type[Exception], ...] = (Exception,),
):
    """Decorator: wrap a sync function with retry logic."""
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            return sync_retry(
                lambda: fn(*args, **kwargs),
                attempts=attempts,
                delays=delays,
                retryable_exceptions=retryable_exceptions,
                label=fn.__name__,
            )
        return wrapper
    return decorator


def with_async_retry(
    attempts: int = DEFAULT_ATTEMPTS,
    delays: Sequence[float] = DEFAULT_DELAYS,
    retryable_exceptions: Tuple[Type[Exception], ...] = (Exception,),
):
    """Decorator: wrap an async function with retry logic."""
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        async def wrapper(*args, **kwargs):
            return await async_retry(
                lambda: fn(*args, **kwargs),
                attempts=attempts,
                delays=delays,
                retryable_exceptions=retryable_exceptions,
                label=fn.__name__,
            )
        return wrapper
    return decorator
