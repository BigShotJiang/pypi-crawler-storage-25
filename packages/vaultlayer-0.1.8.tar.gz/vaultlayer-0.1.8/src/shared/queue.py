"""
VaultLayer ?????? Shared Redis Queue (Upstash)
Inter-agent message bus. Orchestration Agent subscribes to all channels.
Specialist agents publish events, never consume from each other.
"""

import json
import asyncio
import logging
import os
from typing import Callable, Optional, List
from datetime import datetime

import redis.asyncio as aioredis
from shared.models import AgentEvent, EventType

logger = logging.getLogger(__name__)

_DISK_BACKUP_PATH = "/tmp/vaultlayer_queue_backup.jsonl"

_CRITICAL_EVENT_TYPES = frozenset({
    EventType.TERMINATION_SIGNAL,
    EventType.HEARTBEAT_MISS,
    EventType.GPU_FAILURE,
    EventType.OOM_DETECTED,
})

# Redis channel names
CHANNELS = {
    "pricing":  "vaultlayer:pricing.update",
    "watchdog": "vaultlayer:watchdog.alert",
    "broker":   "vaultlayer:broker.status",
    "vault":    "vaultlayer:vault.checkpoint",
    "finops":   "vaultlayer:finops.report",
    "orchestration":  "vaultlayer:orchestration.command",   # Orchestration Agent ?????? Broker/Vault
    "namespace": "vaultlayer:namespace.sync",
    "escalate": "vaultlayer:orchestration.escalate",  # Orchestration Agent ?????? Human
}


class AgentQueue:
    """
    Thin wrapper around Upstash Redis for inter-agent messaging.
    Uses Redis pub/sub for real-time events and Redis lists for durability.
    """

    def __init__(self, redis_url: str):
        self._url = redis_url
        self._client: Optional[aioredis.Redis] = None
        self._degraded: bool = False  # GAP-30: set True on Redis failures
        self._reconnect_task: Optional[asyncio.Task] = None

    @property
    def _redis(self) -> Optional[aioredis.Redis]:
        """Alias for self._client — kept for backward compatibility with callers
        that pre-date the _client rename (ps.py, delete.py, telemetry.py)."""
        return self._client

    async def connect(self):
        # Enforce TLS: Upstash uses rediss:// scheme. Warn if plain redis://
        url = self._url
        if url.startswith("redis://") and not url.startswith("redis://localhost"):
            import warnings
            warnings.warn(
                "AgentQueue: Redis URL uses plaintext redis:// -- "
                "use rediss:// for TLS (required for Upstash production). "
                "Set UPSTASH_REDIS_URL=rediss://...",
                UserWarning, stacklevel=2,
            )
            logger.warning("AgentQueue: plaintext Redis connection detected")
        self._client = await aioredis.from_url(
            url,
            encoding="utf-8",
            decode_responses=True,
            socket_connect_timeout=10,
            socket_timeout=30,
            retry_on_timeout=True,
        )
        logger.info(f"AgentQueue connected to Redis ({'TLS' if url.startswith('rediss://') else 'plaintext'})")
        self._reconnect_task = asyncio.create_task(self._reconnect_loop())

    async def _reconnect_loop(self):
        """Background task: if degraded, ping Redis every 10s (exponential backoff, max 60s) and recover."""
        delay = 10
        while True:
            await asyncio.sleep(delay)
            if not self._degraded:
                delay = 10
                continue
            try:
                await self._client.ping()
                self._degraded = False
                delay = 10
                logger.info("[Queue] Redis connection recovered — exiting degraded mode")
                await self._replay_disk_backup()
            except Exception:
                delay = min(delay * 2, 60)

    async def _replay_disk_backup(self):
        """Replay events stored in the disk backup file after Redis recovers."""
        if not os.path.exists(_DISK_BACKUP_PATH):
            return
        try:
            with open(_DISK_BACKUP_PATH, "r") as fh:
                lines = [l.strip() for l in fh if l.strip()]
            if not lines:
                return
            replayed = 0
            for line in lines:
                try:
                    data = json.loads(line)
                    channel_key = data.get("channel_key", "")
                    event = AgentEvent.model_validate_json(data.get("event", "{}"))
                    if channel_key and channel_key in CHANNELS:
                        channel = CHANNELS[channel_key]
                        await self._client.publish(channel, event.model_dump_json())
                        replayed += 1
                except Exception as e:
                    logger.warning(f"[Queue] Failed to replay backup event: {e}")
            # Truncate after replay
            with open(_DISK_BACKUP_PATH, "w"):
                pass
            logger.info(f"[Queue] Replayed {replayed} events from disk backup")
        except Exception as e:
            logger.error(f"[Queue] Disk backup replay error: {e}")

    async def disconnect(self):
        if self._reconnect_task and not self._reconnect_task.done():
            self._reconnect_task.cancel()
            try:
                await self._reconnect_task
            except (asyncio.CancelledError, Exception):
                pass
        if self._client:
            await self._client.aclose()

    async def publish(self, channel_key: str, event: AgentEvent) -> int:
        # Fire-and-forget pub/sub. Use publish_critical() for migration/failure events.
        # Missed messages (agent restarting) are NOT replayed with this method.
        """Publish an event to a named channel. Returns subscriber count."""
        if channel_key not in CHANNELS:
            raise ValueError(f"Unknown channel: {channel_key}. Valid: {list(CHANNELS.keys())}")
        channel = CHANNELS[channel_key]
        payload = event.model_dump_json()
        try:
            # Pub/sub for real-time delivery
            delivered = await self._client.publish(channel, payload)
            # Also push to list for durability (last 1000 events per channel)
            list_key = f"{channel}:history"
            await self._client.lpush(list_key, payload)
            await self._client.ltrim(list_key, 0, 999)
            logger.debug(f"Published {event.event_type} to {channel} ({delivered} subscribers)")
            return delivered
        except Exception as e:
            is_critical = event.event_type in _CRITICAL_EVENT_TYPES
            if is_critical:
                logger.error(
                    f"[Queue] Redis publish FAILED on channel '{channel_key}' "
                    f"(event: {event.event_type}): {e}. Switching to degraded mode."
                )
                # Persist to disk so it can be replayed on reconnect
                try:
                    with open(_DISK_BACKUP_PATH, "a") as fh:
                        fh.write(json.dumps({
                            "channel_key": channel_key,
                            "event": event.model_dump_json(),
                        }) + "\n")
                except Exception as disk_err:
                    logger.error(f"[Queue] Disk backup write failed: {disk_err}")
                await self._fallback_notify(channel_key, event)
            else:
                logger.warning(
                    f"[Queue] Redis publish FAILED on channel '{channel_key}' "
                    f"(event: {event.event_type}): {e}. Switching to degraded mode."
                )
            self._degraded = True
            return 0

    async def _fallback_notify(self, channel: str, event: AgentEvent) -> None:
        """Fire-and-forget webhook when Redis is unreachable (GAP-30 degraded mode)."""
        import aiohttp as _aiohttp
        import os as _os
        webhook_url = _os.environ.get("VAULTLAYER_WEBHOOK_URL")
        if not webhook_url:
            return
        try:
            async with _aiohttp.ClientSession() as session:
                await asyncio.wait_for(
                    session.post(webhook_url, json={
                        "source": "vaultlayer_degraded_mode",
                        "channel": channel,
                        "event": event.model_dump(mode="json"),
                    }),
                    timeout=5.0,
                )
        except Exception:
            pass  # webhook also failed — we tried

    async def subscribe(
        self,
        channel_keys: List[str],
        handler: Callable[[AgentEvent], asyncio.Future],
    ):
        """Subscribe to one or more channels and call handler for each event."""
        channels = [CHANNELS[k] for k in channel_keys if k in CHANNELS]
        pubsub = self._client.pubsub()
        await pubsub.subscribe(*channels)
        logger.info(f"Subscribed to channels: {channels}")

        async for message in pubsub.listen():
            if message["type"] != "message":
                continue
            try:
                event = AgentEvent.model_validate_json(message["data"])
                await handler(event)
            except Exception as e:
                logger.error(f"Error handling message: {e}", exc_info=True)

    async def get_history(self, channel_key: str, limit: int = 50) -> List[AgentEvent]:
        """Retrieve recent events from a channel's history list."""
        channel = CHANNELS.get(channel_key)
        if not channel:
            return []
        list_key = f"{channel}:history"
        raw = await self._client.lrange(list_key, 0, limit - 1)
        events = []
        for r in raw:
            try:
                events.append(AgentEvent.model_validate_json(r))
            except Exception:
                pass
        return events

    async def set_job_state(self, job_id: str, state: dict):
        """Store current job state in Redis (used by Orchestration Agent for context)."""
        key = f"vaultlayer:job:{job_id}:state"
        await self._client.setex(key, 86400, json.dumps(state, default=str))

    async def get_job_state(self, job_id: str) -> Optional[dict]:
        """Retrieve job state from Redis."""
        key = f"vaultlayer:job:{job_id}:state"
        raw = await self._client.get(key)
        return json.loads(raw) if raw else None

    async def set_price_cache(self, prices: list):
        """Cache latest prices for Orchestration Agent to query synchronously."""
        await self._client.setex(
            "vaultlayer:prices:latest",
            120,  # 2 min TTL
            json.dumps([p if isinstance(p, dict) else p.model_dump(mode="json") for p in prices], default=str)
        )

    async def get_price_cache(self) -> Optional[list]:
        """Get cached prices."""
        raw = await self._client.get("vaultlayer:prices:latest")
        return json.loads(raw) if raw else None

    async def healthcheck(self) -> bool:
        """Check Redis connection health."""
        try:
            return bool(await self._client.ping())
        except Exception:
            return False

    async def hget(self, key: str, field: str) -> Optional[str]:
        """Get a single hash field value. Returns None if the key or field does not exist."""
        return await self._client.hget(key, field)

    async def hset(self, key: str, mapping: dict) -> int:
        """Set multiple hash fields. Returns number of fields added."""
        return await self._client.hset(key, mapping=mapping)

    async def expire(self, key: str, ttl_seconds: int) -> bool:
        """Set a TTL on a key. Returns True if the timeout was set."""
        return bool(await self._client.expire(key, ttl_seconds))
    # -- Durable messaging via Redis Streams (at-least-once delivery) ----------
    # Used for critical events: migration, job failure, node provisioned.
    # Regular pub/sub is still used for high-frequency price updates.
    # Redis Streams persist messages -- missed messages are replayed on reconnect.

    _CRITICAL_STREAM_PREFIX = "vaultlayer:critical:"
    CRITICAL_STREAM_KEY = "vaultlayer:critical:stream"  # legacy
    CONSUMER_GROUP      = "vaultlayer:agents"
    STREAM_MAX_LEN      = 1000   # keep last 1000 critical events

    def _stream_key(self, channel_key: str = "") -> str:
        """Per-channel stream key. publish_critical("broker",...) -> vaultlayer:critical:broker"""
        if channel_key:
            return f"{self._CRITICAL_STREAM_PREFIX}{channel_key}"
        return self.CRITICAL_STREAM_KEY

    async def _ensure_consumer_group(self, channel_key: str = "") -> None:
        """Create consumer group if it does not exist (idempotent)."""
        try:
            _sk = self._stream_key(channel_key)
            await self._client.xgroup_create(
                _sk, self.CONSUMER_GROUP,
                id="0", mkstream=True
            )
        except Exception as e:
            if "BUSYGROUP" not in str(e):
                logger.warning(f"Consumer group create (non-fatal): {e}")

    async def publish_critical(self, channel_key: str, event: "AgentEvent") -> str:
        """
        Publish a critical event to a Redis Stream for at-least-once delivery.
        Returns the stream entry ID. Unlike pub/sub, this message persists
        until explicitly acknowledged -- agents that restart will replay it.

        Use for: MIGRATION_STARTED, NODE_PROVISIONED, JOB_FAILED, PRICE_CHANGE_ALERTS.
        Use regular publish() for: PRICE_UPDATE (high frequency, loss acceptable).
        """
        await self._ensure_consumer_group(channel_key)
        payload = {
            "channel":    channel_key,
            "event_type": event.event_type.value,
            "job_id":     event.job_id or "",
            "source":     event.source_agent,
            "payload":    json.dumps(event.payload or {}),
            "ts":         event.timestamp.isoformat() if event.timestamp else "",
        }
        entry_id = await self._client.xadd(
            self._stream_key(channel_key), payload, maxlen=self.STREAM_MAX_LEN
        )
        logger.debug(f"Critical event {event.event_type.value} -> stream {entry_id}")
        return entry_id

    async def consume_critical(
        self,
        consumer_name: str,
        handler: "Callable",
        batch_size: int = 10,
        block_ms: int = 2000,
        channel_key: str = "orchestration",
    ) -> None:
        """
        Consume critical events from the Redis Stream.
        Automatically ACKs after successful handler execution.
        Unacked messages are replayed on agent restart (PEL recovery).

        Args:
            consumer_name: Unique name for this agent instance (e.g. "broker-1")
            handler:       Async callable(event_dict) -> None
            batch_size:    Max messages per read
            block_ms:      How long to block waiting for new messages
        """
        stream_key = self._stream_key(channel_key)
        await self._ensure_consumer_group(channel_key)
        # First: recover any unacked messages from previous run (PEL)
        pending = await self._client.xreadgroup(
            self.CONSUMER_GROUP, consumer_name,
            {stream_key: "0"},  # "0" = read pending (unacked) messages
            count=batch_size
        )
        if pending:
            logger.info(f"Replaying {sum(len(m) for _,m in pending)} unacked critical messages")
            await self._process_stream_batch(pending, consumer_name, handler, stream_key)
        # Then: read new messages
        while True:
            try:
                messages = await self._client.xreadgroup(
                    self.CONSUMER_GROUP, consumer_name,
                    {stream_key: ">"},  # ">" = new messages only
                    count=batch_size, block=block_ms
                )
                if messages:
                    await self._process_stream_batch(messages, consumer_name, handler, stream_key)
            except Exception as e:
                logger.error(f"Critical stream consume error: {e}")
                await asyncio.sleep(1)

    async def _process_stream_batch(
        self, messages: list, consumer_name: str, handler: "Callable",
        stream_key: str = ""
    ) -> None:
        """Process a batch of stream messages, ACK each after successful handling."""
        default_stream_key = stream_key or self.CRITICAL_STREAM_KEY
        for msg_stream_key, entries in messages:
            ack_key = msg_stream_key or default_stream_key
            for entry_id, fields in entries:
                try:
                    await handler(fields)
                    await self._client.xack(ack_key, self.CONSUMER_GROUP, entry_id)
                    logger.debug(f"ACKed critical event {entry_id}")
                except Exception as e:
                    # Do NOT ack -- message stays in PEL for retry on next startup
                    logger.error(f"Critical event handler failed (will retry): {entry_id} {e}")


def make_event(
    event_type: EventType,
    source_agent: str,
    job_id: Optional[str] = None,
    payload: Optional[dict] = None,
    priority: int = 5,
) -> AgentEvent:
    """Convenience factory for building AgentEvent objects."""
    return AgentEvent(
        event_type=event_type,
        source_agent=source_agent,
        job_id=job_id,
        payload=payload or {},
        priority=priority,
    )
