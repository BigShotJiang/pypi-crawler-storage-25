"""
VaultLayer -- Neutral Zone Models
New Pydantic models for the NamespaceAgent (Pillar 2 + 3).
Append to end of src/shared/models.py
"""

from __future__ import annotations
from enum import Enum
from typing import Optional, List, Dict
from datetime import datetime
from pydantic import BaseModel, Field
import uuid


class ShardFormat(str, Enum):
    TAR = "tar"
    PARQUET = "parquet"
    JSONL = "jsonl"
    HDF5 = "hdf5"
    RAW = "raw"


class ShardRecord(BaseModel):
    shard_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    r2_key: str
    local_name: str
    size_bytes: int
    sha256: str
    shard_index: int
    row_count: Optional[int] = None
    format: ShardFormat = ShardFormat.RAW
    uploaded_at: datetime = Field(default_factory=datetime.utcnow)


class ShardManifest(BaseModel):
    """
    Global Namespace index. Stored in R2 at:
    namespace/{dataset_id}/manifest.json

    Every compute node (AWS, CoreWeave, Lambda) reads this
    to find every shard via the same path -- /mnt/vaultlayer.
    """
    manifest_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    dataset_id: str
    dataset_name: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    total_shards: int
    total_size_bytes: int
    total_rows: Optional[int] = None
    r2_prefix: str
    mount_path: str = "/mnt/vaultlayer"
    shards: List[ShardRecord] = []
    format: ShardFormat = ShardFormat.RAW
    sequential: bool = True
    shard_size_bytes_avg: int = 0
    recommended_prefetch_count: int = 3


class MountStatus(str, Enum):
    PENDING = "pending"
    MOUNTING = "mounting"
    MOUNTED = "mounted"
    FAILED = "failed"
    UNMOUNTED = "unmounted"


class MountRecord(BaseModel):
    mount_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    job_id: str
    node_id: str
    provider: str
    mount_path: str = "/mnt/vaultlayer"
    r2_bucket: str
    r2_prefix: str
    status: MountStatus = MountStatus.PENDING
    pid: Optional[int] = None
    mounted_at: Optional[datetime] = None
    error: Optional[str] = None
    cache_dir: str = "/tmp/vaultlayer-cache"
    cache_size_mb: int = 10240


class CacheEntry(BaseModel):
    shard_id: str
    r2_key: str
    local_path: str
    size_bytes: int
    last_accessed: datetime = Field(default_factory=datetime.utcnow)
    access_count: int = 0
    prefetched: bool = False


class NVMeCacheState(BaseModel):
    job_id: str
    node_id: str
    cache_dir: str
    max_size_bytes: int
    used_bytes: int = 0
    entries: Dict[str, CacheEntry] = {}
    hits: int = 0
    misses: int = 0
    evictions: int = 0
    prefetch_count: int = 0
    last_updated: datetime = Field(default_factory=datetime.utcnow)

    @property
    def hit_rate(self) -> float:
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0

    @property
    def free_bytes(self) -> int:
        return self.max_size_bytes - self.used_bytes