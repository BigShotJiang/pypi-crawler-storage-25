"""Shared logging utilities with --verbose / VL_DEBUG support."""
import logging
import os
import sys

def setup_cli_logging(verbose: bool = False):
    """Set up CLI logging. VL_DEBUG=1 enables full debug output."""
    level = logging.DEBUG if (verbose or os.environ.get("VL_DEBUG", "") == "1") else logging.WARNING
    logging.basicConfig(level=level, format="  [%(name)s] %(message)s", stream=sys.stderr)
    # Never fully suppress broker/pricing -- use WARNING minimum for visibility
    if not verbose and os.environ.get("VL_DEBUG", "") != "1":
        for name in ["agents.broker.agent", "agents.pricing.agent"]:
            logging.getLogger(name).setLevel(logging.WARNING)

def get_logger(name: str) -> logging.Logger:
    """Get a logger with consistent naming."""
    return logging.getLogger(name)
