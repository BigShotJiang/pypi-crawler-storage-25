"""Provider billing API fetchers — retrieve actual billed amounts from providers.

Populates the provider_billed_usd field in spend_ledger and job_runs so the
bill_auditor can compare estimates vs actuals.

Each provider fetcher is best-effort: returns None on failure (caller proceeds
with estimate-only billing). This is intentional — billing APIs can be delayed,
unavailable, or not supported by a provider.

Supported providers:
  - RunPod: GET /v1/billing/pods?podId=X&grouping=podId
    Source: https://docs.runpod.io/api-reference/billing/GET/billing/pods
  - Vast.ai: GET /api/v0/invoices (filter by instance_id)
    Source: https://vast.ai/docs/api
  - Lambda Labs: No billing API exists (uses time-based estimate)
    Source: https://cloud.lambda.ai/api/v1/openapi.json
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)


async def fetch_provider_bill(
    provider: str,
    instance_id: str,
    api_key: str,
    provisioned_at: Optional[datetime] = None,
    terminated_at: Optional[datetime] = None,
    billing_seconds: float = 0,
    rate_per_hr: float = 0,
) -> Optional[float]:
    """Fetch actual billed amount from a provider's billing API.

    Args:
        provider: Provider name (e.g. "runpod", "vast_ai")
        instance_id: Provider-specific instance/pod ID
        api_key: Provider API key
        provisioned_at: When the instance was provisioned (for time range queries)
        terminated_at: When the instance was terminated
        billing_seconds: Duration in seconds (fallback for providers without billing API)
        rate_per_hr: Hourly rate (fallback for providers without billing API)

    Returns:
        Actual billed amount in USD, or None if billing API unavailable/failed.
    """
    _provider = provider.lower().replace(" ", "_")
    fetcher = _FETCHERS.get(_provider)
    if not fetcher:
        return None

    try:
        return await fetcher(
            instance_id=instance_id,
            api_key=api_key,
            provisioned_at=provisioned_at,
            terminated_at=terminated_at,
        )
    except Exception as e:
        logger.warning(f"[billing] {provider} billing fetch failed for {instance_id}: {e}")
        return None


async def _fetch_runpod_bill(
    instance_id: str,
    api_key: str,
    provisioned_at: Optional[datetime] = None,
    terminated_at: Optional[datetime] = None,
) -> Optional[float]:
    """Fetch actual RunPod pod billing via REST API.

    Endpoint: GET https://rest.runpod.io/v1/billing/pods
    Params: podId, grouping=podId, bucketSize=year (single aggregated row)
    Source: https://docs.runpod.io/api-reference/billing/GET/billing/pods

    Response: array of { amount, time, timeBilledMs, podId }
    Total cost = sum of all amount values.
    """
    import aiohttp

    params: dict[str, str] = {
        "podId": instance_id,
        "grouping": "podId",
        "bucketSize": "year",
    }
    if provisioned_at:
        params["startTime"] = provisioned_at.isoformat()
    if terminated_at:
        params["endTime"] = terminated_at.isoformat()

    async with aiohttp.ClientSession() as session:
        async with session.get(
            "https://rest.runpod.io/v1/billing/pods",
            headers={"Authorization": f"Bearer {api_key}"},
            params=params,
            timeout=aiohttp.ClientTimeout(total=10),
        ) as r:
            if r.status != 200:
                logger.warning(f"[billing] RunPod billing API returned {r.status}")
                return None
            data = await r.json()
            if not isinstance(data, list) or not data:
                return None
            total = sum(float(entry.get("amount", 0)) for entry in data)
            logger.info(
                f"[billing] RunPod pod {instance_id}: "
                f"provider_billed=${total:.4f} "
                f"(from {len(data)} billing entries)"
            )
            return round(total, 4)


async def _fetch_vastai_bill(
    instance_id: str,
    api_key: str,
    provisioned_at: Optional[datetime] = None,
    terminated_at: Optional[datetime] = None,
) -> Optional[float]:
    """Fetch actual Vast.ai instance billing via invoices API.

    Endpoint: GET https://console.vast.ai/api/v0/invoices
    Source: https://vast.ai/docs/api

    The v0 invoices endpoint accepts JSON filters and returns per-instance charges.
    Each invoice has: instance_id, amount, quantity, rate, description, timestamp.
    Total cost = sum of all amount values for the given instance.
    """
    import aiohttp
    import json

    async with aiohttp.ClientSession() as session:
        async with session.get(
            "https://console.vast.ai/api/v0/invoices",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "type": "charge",
                "select_filters": {"instance_id": {"eq": int(instance_id)}},
            },
            timeout=aiohttp.ClientTimeout(total=15),
        ) as r:
            if r.status != 200:
                logger.warning(f"[billing] Vast.ai invoices API returned {r.status}")
                return None
            data = await r.json()
            invoices = data if isinstance(data, list) else data.get("invoices", [])
            if not invoices:
                return None
            total = sum(float(inv.get("amount", 0)) for inv in invoices)
            logger.info(
                f"[billing] Vast.ai instance {instance_id}: "
                f"provider_billed=${total:.4f} "
                f"(from {len(invoices)} invoice entries)"
            )
            return round(total, 4)


# Registry of provider billing fetchers
_FETCHERS = {
    "runpod": _fetch_runpod_bill,
    "vast_ai": _fetch_vastai_bill,
    # Lambda Labs: no billing API exists — returns None (time-based estimate used)
    # AWS: Cost Explorer API is async and not real-time — omitted for now
    # GCP: Cloud Billing API requires separate IAM — omitted for now
}
