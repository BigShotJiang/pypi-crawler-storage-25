"""
VaultLayer -- Shared Configuration
Loads all environment variables and provider credentials.

CLI users only need VAULTLAYER_TOKEN (set by `vaultlayer init`).
Provider credentials (AWS, Lambda Labs, etc.) are optional and only
required when the relevant compute provider is actually used.
Backend/agent deployments load all credentials via environment variables.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class AWSConfig:
    access_key_id: str
    secret_access_key: str
    region: str = "us-east-1"


@dataclass
class LambdaLabsConfig:
    api_key: str
    base_url: str = "https://cloud.lambdalabs.com/api/v1"


@dataclass
class CoreWeaveConfig:
    api_key: str
    namespace: str
    base_url: str = "https://rest.coreweave.com"


@dataclass
class RunPodConfig:
    api_key: str
    base_url: str = "https://rest.runpod.io/v1"  # /v2 does not exist; current REST API is /v1


@dataclass
class VastAiConfig:
    api_key: str
    base_url: str = "https://console.vast.ai/api/v0"


@dataclass
class VoltageParkConfig:
    api_key: str
    base_url: str = "https://cloud-api.voltagepark.com/api/v1"


@dataclass
class CrusoeConfig:
    api_key: str                                          # API Key ID (used as HMAC signer identity)
    api_secret: str = ""                                  # API Secret Key (HMAC signing key)
    project_id: str = ""                                  # Crusoe project ID (required for instance paths)
    base_url: str = "https://api.crusoecloud.com/v1alpha5"


@dataclass
class NebiusConfig:
    service_account_key: str  # RSA private key PEM (PKCS#8) for JWT signing
    folder_id: str
    key_id: str = ""           # NEBIUS_KEY_ID — authorized key ID registered in Nebius IAM
    service_account_id: str = ""  # NEBIUS_SA_ID — Nebius service account ID (iss/sub in JWT)
    region: str = "eu"         # Nebius region prefix: eu, il, us, etc.
    base_url: str = "https://compute.api.eu.nebius.cloud/compute/v1"


@dataclass
class HyperstackConfig:
    api_key: str
    base_url: str = "https://infrahub-api.nexgencloud.com/v1"


@dataclass
class CloudflareConfig:
    account_id: str
    r2_access_key_id: str
    r2_secret_access_key: str
    r2_bucket: str
    r2_endpoint: str
    # High-privilege token for minting job-scoped temp credentials.
    # Stays on VaultLayer Broker infrastructure — never sent to GPU nodes.
    # Set via CF_MASTER_TOKEN env var.  Falls back to master keys when absent
    # (backward compat for self-hosted deployments).
    cf_master_token: str = ""


@dataclass
class RedisConfig:
    url: str


@dataclass
class AnthropicConfig:
    api_key: str
    model: str = "claude-sonnet-4-20250514"


@dataclass
class STSConfig:
    """AWS STS AssumeRole configuration for cross-account access."""
    role_arn: str                      # ARN of role in customer's account
    external_id: str = ""              # External ID for secure cross-account access
    session_duration: int = 3600       # Session duration in seconds (1 hour default)


@dataclass
class GCPConfig:
    """GCP credentials for BYOC compute provisioning."""
    service_account_json: str           # path to service account JSON file
    project_id: str
    region: str = "us-central1"
    zone: str = "us-central1-a"


@dataclass
class AzureConfig:
    """Azure credentials for BYOC compute provisioning."""
    subscription_id: str
    tenant_id: str
    client_id: str
    client_secret: str
    resource_group: str = "vaultlayer-rg"
    location: str = "eastus"


@dataclass
class StorageConfig:
    """User-provided data storage credentials (S3, GCS, Azure).
    Used to forward access to migrated compute nodes so training data
    stays wherever the user already has it.
    VaultLayer never stores or migrates training data — only checkpoint data.
    """
    # AWS S3 / compatible
    s3_access_key_id: str = ""
    s3_secret_access_key: str = ""
    s3_region: str = "us-east-1"
    s3_endpoint: str = ""          # non-empty for S3-compatible (MinIO, etc.)
    # GCS
    gcs_credentials_json: str = ""  # path to service account JSON file
    gcs_project: str = ""
    # Azure Blob
    azure_connection_string: str = ""
    azure_account_name: str = ""
    azure_account_key: str = ""

    def has_s3(self) -> bool:
        return bool(self.s3_access_key_id and self.s3_secret_access_key)

    def has_gcs(self) -> bool:
        return bool(self.gcs_credentials_json or self.gcs_project)

    def has_azure(self) -> bool:
        return bool(self.azure_connection_string or self.azure_account_name)

    def has_any(self) -> bool:
        return self.has_s3() or self.has_gcs() or self.has_azure()


@dataclass
class VaultLayerConfig:
    # ── Required ──────────────────────────────────────────────────────────────
    token: str                           # VAULTLAYER_TOKEN — always required
    user_id: str = "default"            # derived from token or VAULTLAYER_USER_ID

    # ── Optional provider creds (BYOC / backend use) ──────────────────────────
    aws: Optional[AWSConfig] = None
    lambda_labs: Optional[LambdaLabsConfig] = None
    coreweave: Optional[CoreWeaveConfig] = None
    cloudflare: Optional[CloudflareConfig] = None
    redis: Optional[RedisConfig] = None
    runpod: Optional[RunPodConfig] = None
    vast_ai: Optional[VastAiConfig] = None
    voltage_park: Optional[VoltageParkConfig] = None
    crusoe: Optional[CrusoeConfig] = None
    nebius: Optional[NebiusConfig] = None
    hyperstack: Optional[HyperstackConfig] = None
    sts: Optional[STSConfig] = None
    gcp: Optional[GCPConfig] = None
    azure: Optional[AzureConfig] = None
    anthropic: Optional[AnthropicConfig] = None

    # ── User data storage (vaultlayer connect storage) ─────────────────────────
    storage: Optional[StorageConfig] = None

    # ── Tunable thresholds ─────────────────────────────────────────────────────
    dashboard_base_url: str = ""
    confidence_threshold_auto: float = 0.85
    confidence_threshold_notify: float = 0.70
    supported_max_params_billion: float = 30.0


def _load_config_env() -> None:
    """Load ~/.vaultlayer/config.env into os.environ (if it exists and dotenv is available)."""
    config_env = Path.home() / ".vaultlayer" / "config.env"
    if not config_env.exists():
        return
    try:
        from dotenv import load_dotenv
        load_dotenv(config_env, override=False)  # env vars already set take priority
    except ImportError:
        # dotenv not installed — parse manually
        for line in config_env.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = val


def load_config() -> VaultLayerConfig:
    """
    Load VaultLayer config from environment variables.

    For CLI users: only VAULTLAYER_TOKEN is required (set by `vaultlayer init`).
    Provider credentials are loaded when present and only needed by agents/broker.

    Raises ValueError with a helpful message if VAULTLAYER_TOKEN is not set.
    """
    # Load ~/.vaultlayer/config.env first so env vars take priority
    _load_config_env()

    def optional(key: str, default: str = "") -> str:
        return os.getenv(key, default)

    # ── Token — the only required field for CLI users ──────────────────────────
    token = os.getenv("VAULTLAYER_TOKEN", "")
    if not token:
        raise ValueError(
            "VAULTLAYER_TOKEN is not set. Run: vaultlayer init"
        )

    user_id = os.getenv("VAULTLAYER_USER_ID", "default")

    # ── AWS (optional — needed for AWS spot provisioning) ─────────────────────
    aws = None
    if os.getenv("AWS_ACCESS_KEY_ID") and os.getenv("AWS_SECRET_ACCESS_KEY"):
        aws = AWSConfig(
            access_key_id=os.environ["AWS_ACCESS_KEY_ID"],
            secret_access_key=os.environ["AWS_SECRET_ACCESS_KEY"],
            region=optional("AWS_REGION", optional("AWS_DEFAULT_REGION", "us-east-1")),
        )

    # ── Lambda Labs (optional) ────────────────────────────────────────────────
    lambda_labs = None
    if os.getenv("LAMBDA_LABS_API_KEY"):
        lambda_labs = LambdaLabsConfig(api_key=os.environ["LAMBDA_LABS_API_KEY"])

    # ── CoreWeave (optional) ──────────────────────────────────────────────────
    coreweave = None
    if os.getenv("COREWEAVE_API_KEY") and os.getenv("COREWEAVE_NAMESPACE"):
        coreweave = CoreWeaveConfig(
            api_key=os.environ["COREWEAVE_API_KEY"],
            namespace=os.environ["COREWEAVE_NAMESPACE"],
        )

    # ── Cloudflare R2 (optional — needed by agents for checkpoint storage) ────
    cloudflare = None
    if (os.getenv("CLOUDFLARE_ACCOUNT_ID") and os.getenv("R2_ACCESS_KEY_ID")
            and os.getenv("R2_SECRET_ACCESS_KEY") and os.getenv("R2_ENDPOINT")):
        cloudflare = CloudflareConfig(
            account_id=os.environ["CLOUDFLARE_ACCOUNT_ID"],
            r2_access_key_id=os.environ["R2_ACCESS_KEY_ID"],
            r2_secret_access_key=os.environ["R2_SECRET_ACCESS_KEY"],
            r2_bucket=optional("R2_BUCKET", "vaultlayer-checkpoints"),
            r2_endpoint=os.environ["R2_ENDPOINT"],
            cf_master_token=optional("CF_MASTER_TOKEN", ""),
        )

    # ── Redis (optional — needed by agents for pub/sub) ───────────────────────
    redis = None
    if os.getenv("UPSTASH_REDIS_URL"):
        redis = RedisConfig(url=os.environ["UPSTASH_REDIS_URL"])

    # ── Other optional providers ──────────────────────────────────────────────
    runpod = RunPodConfig(api_key=os.environ["RUNPOD_API_KEY"]) \
        if os.getenv("RUNPOD_API_KEY") else None
    vast_ai = VastAiConfig(api_key=os.environ["VAST_AI_API_KEY"]) \
        if os.getenv("VAST_AI_API_KEY") else None
    voltage_park = VoltageParkConfig(api_key=os.environ["VOLTAGE_PARK_API_KEY"]) \
        if os.getenv("VOLTAGE_PARK_API_KEY") else None
    crusoe = CrusoeConfig(
        api_key=os.environ["CRUSOE_API_KEY"],
        api_secret=os.environ.get("CRUSOE_API_SECRET", ""),
        project_id=os.environ.get("CRUSOE_PROJECT_ID", ""),
    ) if os.getenv("CRUSOE_API_KEY") else None
    _nebius_region = os.environ.get("NEBIUS_REGION", "eu")
    nebius = NebiusConfig(
        service_account_key=os.environ["NEBIUS_SA_KEY"],
        folder_id=os.getenv("NEBIUS_FOLDER_ID", ""),
        key_id=os.getenv("NEBIUS_KEY_ID", ""),
        service_account_id=os.getenv("NEBIUS_SA_ID", ""),
        region=_nebius_region,
        base_url=f"https://compute.api.{_nebius_region}.nebius.cloud/compute/v1",
    ) if os.getenv("NEBIUS_SA_KEY") else None
    hyperstack = HyperstackConfig(api_key=os.environ["HYPERSTACK_API_KEY"]) \
        if os.getenv("HYPERSTACK_API_KEY") else None

    # ── STS cross-account (optional) ─────────────────────────────────────────
    sts = STSConfig(
        role_arn=os.environ["VL_STS_ROLE_ARN"],
        external_id=optional("VL_STS_EXTERNAL_ID", ""),
        session_duration=int(optional("VL_STS_SESSION_DURATION", "3600")),
    ) if os.getenv("VL_STS_ROLE_ARN") else None

    # ── GCP (optional — needed for GCP BYOC provisioning) ────────────────────
    gcp = None
    if os.getenv("GCP_SERVICE_ACCOUNT_JSON") and os.getenv("GCP_PROJECT_ID"):
        gcp = GCPConfig(
            service_account_json=os.environ["GCP_SERVICE_ACCOUNT_JSON"],
            project_id=os.environ["GCP_PROJECT_ID"],
            region=optional("GCP_REGION", "us-central1"),
            zone=optional("GCP_ZONE", "us-central1-a"),
        )

    # ── Azure (optional — needed for Azure BYOC provisioning) ────────────────
    azure = None
    if (os.getenv("AZURE_SUBSCRIPTION_ID") and os.getenv("AZURE_TENANT_ID")
            and os.getenv("AZURE_CLIENT_ID") and os.getenv("AZURE_CLIENT_SECRET")):
        azure = AzureConfig(
            subscription_id=os.environ["AZURE_SUBSCRIPTION_ID"],
            tenant_id=os.environ["AZURE_TENANT_ID"],
            client_id=os.environ["AZURE_CLIENT_ID"],
            client_secret=os.environ["AZURE_CLIENT_SECRET"],
            resource_group=optional("AZURE_RESOURCE_GROUP", "vaultlayer-rg"),
            location=optional("AZURE_LOCATION", "eastus"),
        )

    # ── Anthropic (optional — Claude for ambiguous decisions) ─────────────────
    anthropic = AnthropicConfig(api_key=os.environ["ANTHROPIC_API_KEY"]) \
        if os.getenv("ANTHROPIC_API_KEY") else None

    # ── User data storage credentials (vaultlayer connect storage) ───────────
    storage = None
    if (os.getenv("VL_S3_ACCESS_KEY_ID") or os.getenv("VL_GCS_CREDENTIALS_JSON")
            or os.getenv("VL_AZURE_CONNECTION_STRING")):
        storage = StorageConfig(
            s3_access_key_id=optional("VL_S3_ACCESS_KEY_ID"),
            s3_secret_access_key=optional("VL_S3_SECRET_ACCESS_KEY"),
            s3_region=optional("VL_S3_REGION", "us-east-1"),
            s3_endpoint=optional("VL_S3_ENDPOINT"),
            gcs_credentials_json=optional("VL_GCS_CREDENTIALS_JSON"),
            gcs_project=optional("VL_GCS_PROJECT"),
            azure_connection_string=optional("VL_AZURE_CONNECTION_STRING"),
            azure_account_name=optional("VL_AZURE_ACCOUNT_NAME"),
            azure_account_key=optional("VL_AZURE_ACCOUNT_KEY"),
        )

    return VaultLayerConfig(
        token=token,
        user_id=user_id,
        aws=aws,
        lambda_labs=lambda_labs,
        coreweave=coreweave,
        cloudflare=cloudflare,
        redis=redis,
        runpod=runpod,
        vast_ai=vast_ai,
        voltage_park=voltage_park,
        crusoe=crusoe,
        nebius=nebius,
        hyperstack=hyperstack,
        sts=sts,
        gcp=gcp,
        azure=azure,
        anthropic=anthropic,
        storage=storage,
    )


def require_provider(config: VaultLayerConfig, provider: str) -> None:
    """
    Assert that a provider config is present, raising a clear error if not.
    Call this in agent code before accessing provider-specific credentials.

    Example:
        require_provider(config, "aws")
        # safe to use config.aws now
    """
    mapping = {
        "aws":          config.aws,
        "lambda_labs":  config.lambda_labs,
        "coreweave":    config.coreweave,
        "cloudflare":   config.cloudflare,
        "redis":        config.redis,
        "runpod":       config.runpod,
        "vast_ai":      config.vast_ai,
        "voltage_park": config.voltage_park,
        "crusoe":       config.crusoe,
        "nebius":       config.nebius,
        "hyperstack":   config.hyperstack,
        "gcp":          config.gcp,
        "azure":        config.azure,
    }
    if provider not in mapping:
        raise ValueError(f"Unknown provider: {provider!r}")
    if mapping[provider] is None:
        env_hint = {
            "aws":          "AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY",
            "lambda_labs":  "LAMBDA_LABS_API_KEY",
            "coreweave":    "COREWEAVE_API_KEY + COREWEAVE_NAMESPACE",
            "cloudflare":   "CLOUDFLARE_ACCOUNT_ID + R2_ACCESS_KEY_ID + R2_SECRET_ACCESS_KEY + R2_ENDPOINT",
            "redis":        "UPSTASH_REDIS_URL",
            "runpod":       "RUNPOD_API_KEY",
            "vast_ai":      "VAST_AI_API_KEY",
            "voltage_park": "VOLTAGE_PARK_API_KEY",
            "crusoe":       "CRUSOE_API_KEY",
            "nebius":       "NEBIUS_SA_KEY",
            "hyperstack":   "HYPERSTACK_API_KEY",
            "gcp":          "GCP_SERVICE_ACCOUNT_JSON + GCP_PROJECT_ID",
            "azure":        "AZURE_SUBSCRIPTION_ID + AZURE_TENANT_ID + AZURE_CLIENT_ID + AZURE_CLIENT_SECRET",
        }.get(provider, provider.upper() + "_API_KEY")
        raise ValueError(
            f"Provider {provider!r} is not configured. "
            f"Set: {env_hint}"
        )
