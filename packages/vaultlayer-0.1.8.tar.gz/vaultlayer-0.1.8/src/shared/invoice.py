"""
VaultLayer — Invoice Generator

Two billing models, one invoice format:

  gainshare  (default) — user migrated FROM AWS/GCP/Azure.
    Revenue = % of savings vs hyperscaler baseline.
    Framing: "You saved $X (Y%) vs AWS On-Demand."

  cost_plus — native VaultLayer user, no existing cloud account.
    Revenue = raw provider cost × (1 + compute_markup_pct).
    Framing: "AWS public rate $4.10/hr. Your VaultLayer rate $1.25/hr."
    The AWS OD comparison still anchors value — user sees they're
    getting hyperscaler compute at a fraction of the price.

Invoice structure:
  - compute: aggregated legs (one per node/interruption), with breakdown
  - storage: single line item (dataset GB × storage_rate × months)
  - total: compute + storage
  - savings_vs_aws_od: how much cheaper than AWS OD either way

Flow:
  Job completes → create_invoice(job_id, user_id)
    → fetch all job_runs for job_id
    → fetch user billing_model, compute_markup_pct, storage_rate_per_gb
    → fetch storage usage for job
    → build invoice document
    → INSERT into invoices table
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# AWS On-Demand reference rates — loaded from config/vaultlayer_data.json
def _get_aws_od():
    try:
        from shared.data_loader import get_aws_od_rates
        return get_aws_od_rates()
    except Exception:
        return {"H100": 12.29, "A100": 4.10, "A10G": 3.21}

_AWS_OD_RATES: dict[str, float] = _get_aws_od()

# Default compute markup for cost_plus users (25%)
DEFAULT_COMPUTE_MARKUP_PCT: float = 0.25
# Default storage rate $/GB/month (R2 $0.015 × 1.33 ≈ $0.020)
DEFAULT_STORAGE_RATE_PER_GB: float = 0.020


def _get_db():
    try:
        from api.db import get_db
        return get_db()
    except Exception:
        return None


def _db_call(fn, label: str):
    try:
        from api.db import _db_call as _retry
        return _retry(fn, label=label)
    except ImportError:
        return fn()


def _aws_od_rate(gpu_type: str) -> float:
    return _AWS_OD_RATES.get(gpu_type, 0.0)


def _fetch_user_billing_profile(user_id: str) -> dict:
    """
    Return billing_model, compute_markup_pct, storage_rate_per_gb for the user.
    Falls back to defaults if Supabase not configured or user not found.
    """
    if not user_id:
        return {
            "billing_model": "gainshare",
            "compute_markup_pct": DEFAULT_COMPUTE_MARKUP_PCT,
            "storage_rate_per_gb": DEFAULT_STORAGE_RATE_PER_GB,
        }
    db = _get_db()
    if db is None:
        return {
            "billing_model": "gainshare",
            "compute_markup_pct": DEFAULT_COMPUTE_MARKUP_PCT,
            "storage_rate_per_gb": DEFAULT_STORAGE_RATE_PER_GB,
        }
    try:
        res = _db_call(
            lambda: db.table("users")
                .select("billing_model, compute_markup_pct, storage_rate_per_gb")
                .eq("user_id", user_id)
                .execute(),
            label="invoice:fetch_user_billing",
        )
        if res.data:
            row = res.data[0]
            return {
                "billing_model":       row.get("billing_model") or "gainshare",
                "compute_markup_pct":  float(row.get("compute_markup_pct") or DEFAULT_COMPUTE_MARKUP_PCT),
                "storage_rate_per_gb": float(row.get("storage_rate_per_gb") or DEFAULT_STORAGE_RATE_PER_GB),
            }
    except Exception as e:
        logger.debug(f"[invoice] Could not fetch user billing profile: {e}")
    return {
        "billing_model": "gainshare",
        "compute_markup_pct": DEFAULT_COMPUTE_MARKUP_PCT,
        "storage_rate_per_gb": DEFAULT_STORAGE_RATE_PER_GB,
    }


def _fetch_storage_gb(job_id: str, user_id: str) -> float:
    """
    Return GB stored in R2 for this job (dataset + checkpoints).
    Pulls from storage_billing records if available, falls back to job.dataset_size_gb.
    """
    db = _get_db()
    if db is None:
        return 0.0
    try:
        res = _db_call(
            lambda: db.table("storage_billing")
                .select("gb_stored")
                .eq("job_id", job_id)
                .order("recorded_at", desc=True)
                .limit(1)
                .execute(),
            label="invoice:fetch_storage",
        )
        if res.data:
            return float(res.data[0].get("gb_stored") or 0.0)
        # Fallback: read from jobs table
        res2 = _db_call(
            lambda: db.table("jobs")
                .select("dataset_size_gb")
                .eq("job_id", job_id)
                .execute(),
            label="invoice:fetch_job_storage_gb",
        )
        if res2.data:
            return float(res2.data[0].get("dataset_size_gb") or 0.0)
    except Exception as e:
        logger.debug(f"[invoice] Could not fetch storage GB: {e}")
    return 0.0


def _build_invoice(
    job_id: str,
    user_id: str,
    runs: list[dict],
    billing_profile: dict,
    storage_gb: float,
) -> dict:
    """
    Build the full invoice document.

    Compute tier is determined at the JOB level (not per-leg):
      leg_count > 1 → Tier 3 (Zero-Downtime Hop, 40%) — all legs billed at 40%.
      H100/A100 GPU → Tier 2 (Scarcity Hunt, 30%).
      Standard GPU  → Tier 1 (Raw Match, 20%).

    Migration event itself shows as $0.00 — covered by the Tier 3 premium.
    AWS OD rate is always shown for anchoring, in both billing models.
    """
    from shared.compute_tiers import (
        get_job_tier, get_leg_tier, get_aws_od_rate, markup_description,
    )

    billing_model = billing_profile["billing_model"]
    storage_rate_per_gb = billing_profile["storage_rate_per_gb"]

    sorted_runs = sorted(runs, key=lambda r: r.get("provisioned_at") or "")

    # ── Job-level compute tier (fallback for legacy runs without per-leg margin) ─
    gpu_types = [r.get("gpu_type") or "" for r in sorted_runs]
    _job_tier_num, _job_tier_markup, _job_tier_label = get_job_tier(
        gpu_types=gpu_types,
        leg_count=len(sorted_runs),
    )
    # gainshare users: markup is the global VL margin, not the tiered one
    _job_effective_markup = (
        _job_tier_markup if billing_model == "cost_plus"
        else billing_profile["compute_markup_pct"]
    )

    # ── Compute legs ──────────────────────────────────────────────────────────
    legs = []
    migrations = []          # $0.00 migration event line items
    total_provider_cost_usd = 0.0
    total_compute_cost_usd = 0.0
    total_credits_charged = 0.0  # NUMERIC(12,4) — sum of fractional leg credits
    total_billing_seconds = 0.0
    total_aws_od_usd = 0.0

    for i, run in enumerate(sorted_runs, start=1):
        billing_seconds = float(run.get("billing_seconds") or 0)
        rate_per_hr = float(run.get("rate_per_hr") or 0)
        provider_raw_usd = round((billing_seconds / 3600) * rate_per_hr, 4)
        gpu_type = run.get("gpu_type") or ""

        # ── Per-leg tier: prefer stored vl_margin_pct, fall back to job-level ─
        _run_margin = run.get("vl_margin_pct")
        if _run_margin is not None and billing_model == "cost_plus":
            # Per-leg tier was set at provision time by _record_provision_spend
            leg_markup = float(_run_margin)
            _meta = run.get("metadata") or {}
            leg_tier_num = int(_meta.get("compute_tier", 0)) or 0
            leg_tier_label = str(_meta.get("compute_tier_label", "")) or ""
            # Reconstruct from markup if metadata missing
            if not leg_tier_num:
                leg_tier_num, _, leg_tier_label = get_leg_tier(gpu_type, is_hop_leg=(i > 1))
        else:
            # Legacy: no per-leg margin stored, use job-level fallback
            leg_markup = _job_effective_markup
            leg_tier_num = _job_tier_num
            leg_tier_label = _job_tier_label

        billed_usd = round(provider_raw_usd * (1.0 + leg_markup), 4)
        orchestration_fee_usd = round(billed_usd - provider_raw_usd, 4)
        # credits_charged is NUMERIC(12,4) post-migration 0019; fall back
        # to computed value if the DB row is missing (legacy pre-migration).
        credits = float(run.get("credits_charged") or round(billed_usd * 100, 4))

        aws_od_hr = get_aws_od_rate(gpu_type)
        aws_od_leg_usd = round(aws_od_hr * billing_seconds / 3600, 4) if aws_od_hr else 0.0

        is_last = (i == len(sorted_runs))
        if is_last:
            status_label = "completed"
        elif run.get("status") == "terminated":
            status_label = "spot_termination"
        else:
            status_label = "migration"

        legs.append({
            "leg_number":            i,
            "run_id":                run.get("run_id") or "",
            "provider":              run.get("provider") or "",
            "gpu_type":              gpu_type,
            "instance_id":           run.get("instance_id") or "",
            "region":                run.get("region") or "",
            "provisioned_at":        run.get("provisioned_at") or "",
            "terminated_at":         run.get("terminated_at") or "",
            "billing_hours":         round(billing_seconds / 3600, 3),
            "rate_per_hr":           rate_per_hr,
            "provider_raw_cost_usd": provider_raw_usd,
            "orchestration_fee_usd": orchestration_fee_usd,
            "billed_usd":            billed_usd,
            "credits_charged":       credits,
            "status":                status_label,
            "compute_tier":          leg_tier_num,
            "compute_tier_label":    leg_tier_label,
            "markup_pct":            leg_markup,
            "aws_od_rate_per_hr":    aws_od_hr,
            "aws_od_equivalent_usd": aws_od_leg_usd,
            "billing_description":   markup_description(
                gpu_type, leg_tier_num, leg_tier_label, rate_per_hr,
                round(rate_per_hr * (1 + leg_markup), 4),
            ),
        })

        # After each non-final leg, insert a $0.00 migration event
        if not is_last:
            migrations.append({
                "event":       "Live Migration / Zero-Downtime Hop",
                "after_leg":   i,
                "cost_usd":    0.0,
                "description": (
                    "NVMe checkpoint written, new node provisioned, job resumed. "
                    "Covered by Tier 3 orchestration premium — no extra charge."
                ),
            })

        total_provider_cost_usd += provider_raw_usd
        total_compute_cost_usd += billed_usd
        total_credits_charged += credits
        total_billing_seconds += billing_seconds
        total_aws_od_usd += aws_od_leg_usd

    total_provider_cost_usd = round(total_provider_cost_usd, 4)
    total_compute_cost_usd = round(total_compute_cost_usd, 4)
    total_aws_od_usd = round(total_aws_od_usd, 4)
    total_orchestration_fee_usd = round(total_compute_cost_usd - total_provider_cost_usd, 4)

    # ── Storage line item ─────────────────────────────────────────────────────
    # Pro-rate for job duration (billing_seconds / seconds_per_month)
    seconds_per_month = 30 * 24 * 3600
    storage_months = total_billing_seconds / seconds_per_month if total_billing_seconds > 0 else 0
    storage_cost_usd = round(storage_gb * storage_rate_per_gb * storage_months, 4)
    r2_raw_cost_usd = round(storage_gb * 0.015 * storage_months, 4)

    storage_line = {
        "service":           "Storage (Cloudflare R2 — zero egress)",
        "gb_stored":         round(storage_gb, 3),
        "rate_per_gb_month": storage_rate_per_gb,
        "duration_months":   round(storage_months, 4),
        "cost_usd":          storage_cost_usd,
        "r2_raw_cost_usd":   r2_raw_cost_usd,
        "margin_usd":        round(storage_cost_usd - r2_raw_cost_usd, 4),
    }

    # ── Totals ────────────────────────────────────────────────────────────────
    total_cost_usd = round(total_compute_cost_usd + storage_cost_usd, 4)
    savings_usd = round(max(0.0, total_aws_od_usd - total_cost_usd), 4)
    savings_pct = round(savings_usd / total_aws_od_usd * 100, 1) if total_aws_od_usd > 0 else 0.0

    first_run = sorted_runs[0] if sorted_runs else {}
    last_run = sorted_runs[-1] if sorted_runs else {}

    # ── Framing — both models anchor against AWS OD ───────────────────────────
    # Collect distinct tiers used across legs for summary
    _leg_tiers = sorted(set(l.get("compute_tier", 0) for l in legs))
    _tier_summary = ", ".join(f"Tier {t}" for t in _leg_tiers if t) or f"Tier {_job_tier_num}"
    if billing_model == "cost_plus":
        framing = (
            f"{_tier_summary} — per-leg tiered markup. "
            f"Provider raw cost: ${total_provider_cost_usd:.2f}. "
            f"VaultLayer rate: ${total_compute_cost_usd:.2f}. "
            f"AWS On-Demand equivalent: ${total_aws_od_usd:.2f}. "
            f"You saved ${savings_usd:.2f} ({savings_pct}%) vs AWS."
        )
    else:
        framing = (
            f"Compared to AWS On-Demand (${total_aws_od_usd:.2f}), "
            f"you saved ${savings_usd:.2f} ({savings_pct}%) by using VaultLayer."
        )

    return {
        "invoice_id":              str(uuid.uuid4()),
        "user_id":                 user_id,
        "job_id":                  job_id,
        "job_name":                first_run.get("job_name") or job_id,
        "created_at":              datetime.now(timezone.utc).isoformat(),
        "status":                  "finalized",
        "billing_model":           billing_model,
        "compute_tier":            _job_tier_num,
        "compute_tier_label":      _job_tier_label,
        "compute_markup_pct":      _job_effective_markup,
        "leg_count":               len(legs),
        "job_started_at":          first_run.get("provisioned_at") or "",
        "job_completed_at":        last_run.get("terminated_at") or "",
        "total_billing_seconds":   round(total_billing_seconds, 1),
        # Compute section
        "compute": {
            "tier":                    _job_tier_num,
            "tier_label":              _job_tier_label,
            "markup_pct":              _job_effective_markup,
            "total_provider_cost_usd": total_provider_cost_usd,
            "total_orchestration_fee": total_orchestration_fee_usd,
            "total_billed_usd":        total_compute_cost_usd,
            "total_billing_hours":     round(total_billing_seconds / 3600, 3),
            "aws_od_equivalent_usd":   total_aws_od_usd,
            "legs":                    legs,
            "migrations":              migrations,   # $0.00 event line items between legs
        },
        # Storage section
        "storage": storage_line,
        # Invoice totals
        "total_cost_usd":          total_cost_usd,
        "total_credits_charged":   round(total_credits_charged, 4),
        "aws_od_equivalent_usd":   total_aws_od_usd,
        "savings_usd":             savings_usd,
        "savings_pct":             savings_pct,
        "framing":                 framing,
    }


def create_invoice(job_id: str, user_id: str) -> Optional[str]:
    """
    Generate and store an invoice for a completed job.
    Returns invoice_id on success, None on error or if DB not configured.
    """
    db = _get_db()
    if db is None:
        logger.debug("[invoice] Supabase not configured — invoice not stored")
        return None

    try:
        res = _db_call(
            lambda: db.table("job_runs")
                .select(
                    "run_id, provider, gpu_type, instance_id, region, job_name, "
                    "provisioned_at, terminated_at, billing_seconds, rate_per_hr, "
                    "estimated_cost_usd, credits_charged, status"
                )
                .eq("job_id", job_id)
                .neq("run_type", "smoke_test")
                .order("provisioned_at")
                .execute(),
            label="invoice:fetch_runs",
        )
    except Exception as e:
        logger.warning(f"[invoice] Failed to fetch job_runs for {job_id}: {e}")
        return None

    runs = res.data or []
    if not runs:
        logger.warning(f"[invoice] No job_runs found for job_id={job_id}")
        return None

    billing_profile = _fetch_user_billing_profile(user_id)
    storage_gb = _fetch_storage_gb(job_id, user_id)

    invoice = _build_invoice(
        job_id=job_id,
        user_id=user_id,
        runs=runs,
        billing_profile=billing_profile,
        storage_gb=storage_gb,
    )
    invoice_id = invoice["invoice_id"]

    try:
        _db_call(
            lambda: db.table("invoices").insert({
                "invoice_id":     invoice_id,
                "user_id":        user_id,
                "job_id":         job_id,
                "invoice":        invoice,
                "created_at":     invoice["created_at"],
                "total_cost_usd": invoice["total_cost_usd"],
                "leg_count":      invoice["leg_count"],
                "status":         invoice["status"],
            }).execute(),
            label="invoice:insert",
        )
        logger.info(
            f"[invoice] Created invoice_id={invoice_id}  job_id={job_id}  "
            f"user_id={user_id}  model={invoice['billing_model']}  "
            f"legs={invoice['leg_count']}  compute=${invoice['compute']['total_cost_usd']}  "
            f"storage=${invoice['storage']['cost_usd']}  "
            f"total=${invoice['total_cost_usd']}  "
            f"savings=${invoice['savings_usd']} ({invoice['savings_pct']}%)"
        )
        return invoice_id
    except Exception as e:
        logger.warning(f"[invoice] Failed to store invoice for {job_id}: {e}")
        return None


def get_invoice(invoice_id: str) -> Optional[dict]:
    """Fetch a single invoice by invoice_id."""
    db = _get_db()
    if db is None:
        return None
    try:
        res = _db_call(
            lambda: db.table("invoices").select("*").eq("invoice_id", invoice_id).execute(),
            label="invoice:get",
        )
        return res.data[0] if res.data else None
    except Exception as e:
        logger.warning(f"[invoice] get_invoice failed: {e}")
        return None


def get_invoices_for_user(user_id: str, limit: int = 50) -> list[dict]:
    """Fetch all invoices for a user, newest first."""
    db = _get_db()
    if db is None:
        return []
    try:
        res = _db_call(
            lambda: db.table("invoices")
                .select("invoice_id, job_id, created_at, total_cost_usd, leg_count, status, invoice")
                .eq("user_id", user_id)
                .order("created_at", desc=True)
                .limit(limit)
                .execute(),
            label="invoice:list",
        )
        return res.data or []
    except Exception as e:
        logger.warning(f"[invoice] get_invoices_for_user failed: {e}")
        return []


def get_invoice_for_job(job_id: str, user_id: str) -> Optional[dict]:
    """Fetch the invoice for a specific job (user-scoped)."""
    db = _get_db()
    if db is None:
        return None
    try:
        res = _db_call(
            lambda: db.table("invoices")
                .select("*")
                .eq("job_id", job_id)
                .eq("user_id", user_id)
                .execute(),
            label="invoice:get_for_job",
        )
        return res.data[0] if res.data else None
    except Exception as e:
        logger.warning(f"[invoice] get_invoice_for_job failed: {e}")
        return None
