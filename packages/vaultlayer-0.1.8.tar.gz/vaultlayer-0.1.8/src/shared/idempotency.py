"""Provider-provisioning idempotency helpers.

Background — IDEM-1 (see TODO.md + docs/IDEM1_PROVIDER_KEYS.md):
ec2.run_instances has historically been called without a ClientToken, so
a broker retry after a transient failure could double-provision and
double-bill. This module produces a stable, deterministic key usable as:

  * AWS EC2       — `ClientToken` (body/query, ≤64 ASCII)
  * GCP Compute   — `requestId` (query, UUID v4, non-zero)
  * Nebius        — `X-Idempotency-Key` (header, UUID-shaped)

For providers without documented idempotency (Lambda Labs, RunPod,
Vast.ai, CoreWeave non-K8s, Voltage Park, Crusoe, Hyperstack), use
`provision_resource_name()` as a deterministic resource name and pair it
with a list-then-create pre-check.

The key is uuid5(namespace, f"{job_id}:{attempt}") so:
  * same (job_id, attempt) always produces the same key — safe retry
  * different attempts produce different keys — controlled new-provision
  * no cross-job collisions
"""
from __future__ import annotations

import uuid

# Stable namespace UUID for VaultLayer provisioning keys. Generated via
# uuid.uuid4() on 2026-04-20. Any UUID works — what matters is that it
# stays stable across deployments so the key is deterministic.
_VL_PROVISION_NS = uuid.UUID("7f42ce9a-5e3b-4b8c-9d1e-8a3c5b7e2f4a")


def provision_idempotency_key(job_id: str, attempt: int) -> str:
    """Return a stable UUID5 for (job_id, attempt).

    Used as AWS ClientToken / GCP requestId / Nebius X-Idempotency-Key.

    Examples:
        >>> k1 = provision_idempotency_key("abc-123", 1)
        >>> k2 = provision_idempotency_key("abc-123", 1)
        >>> assert k1 == k2  # deterministic
        >>> k3 = provision_idempotency_key("abc-123", 2)
        >>> assert k1 != k3  # attempts differ
    """
    if not job_id:
        raise ValueError("job_id is required for idempotency key")
    if attempt < 1:
        raise ValueError(f"attempt must be >= 1, got {attempt}")
    return str(uuid.uuid5(_VL_PROVISION_NS, f"{job_id}:{attempt}"))


def provision_resource_name(job_id: str, attempt: int, prefix: str = "vl") -> str:
    """Return a deterministic resource name for providers without a native
    idempotency key.

    Pairs with a list-then-create pre-check: before calling create, query
    the provider for any resource with this exact name; if found, reuse
    it rather than creating a duplicate.

    Format: {prefix}-{attempt}-{first-8-of-job_id}
    Keeps length <= 20 chars, well under every provider's name-length cap
    (AWS: 63, GCP: 63, Azure: 64, Lambda: 60).
    """
    if not job_id:
        raise ValueError("job_id is required for resource name")
    if attempt < 1:
        raise ValueError(f"attempt must be >= 1, got {attempt}")
    # Sanitize job_id: keep alphanumerics + hyphens, lowercase.
    short = "".join(c for c in job_id.lower() if c.isalnum() or c == "-")[:8]
    return f"{prefix}-{attempt}-{short}"
