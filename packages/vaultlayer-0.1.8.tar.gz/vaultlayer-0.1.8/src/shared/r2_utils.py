"""Shared R2 credential utilities — env var lookup only.

The managed /api/v1/credentials/provider endpoint was removed as a security
redesign: it was a customer-facing endpoint vending company cloud-account keys.
R2 credentials are now always supplied via environment variables. BYOC users
supply their own via `vaultlayer connect storage`.
"""
import os

def get_r2_credentials(job_id: str = "default") -> dict:
    """Get R2 credentials from environment variables.

    Returns dict with keys: endpoint, access_key_id, secret_access_key, bucket.
    Returns empty dict if env vars are not set.
    """
    endpoint = os.environ.get("R2_ENDPOINT", os.environ.get("VAULTLAYER_R2_ENDPOINT", ""))
    key = os.environ.get("R2_ACCESS_KEY_ID", os.environ.get("VAULTLAYER_R2_ACCESS_KEY_ID", ""))
    secret = os.environ.get("R2_SECRET_ACCESS_KEY", os.environ.get("VAULTLAYER_R2_SECRET_ACCESS_KEY", ""))
    bucket = os.environ.get("R2_BUCKET", os.environ.get("VAULTLAYER_R2_BUCKET", "vaultlayer-checkpoints"))

    if endpoint and key and secret:
        return {"endpoint": endpoint, "access_key_id": key, "secret_access_key": secret, "bucket": bucket}
    return {}
