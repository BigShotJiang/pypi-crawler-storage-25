"""
VaultLayer — CredentialVault

Encrypts credentials at rest using Fernet symmetric encryption (AES-128-CBC + HMAC-SHA256).
The encryption key is derived from a machine-specific secret (VAULTLAYER_TOKEN) using
PBKDF2-HMAC-SHA256 with a per-user salt.

For the managed service: VAULTLAYER_TOKEN is the signed token issued at vaultlayer init.
For self-hosted: VAULTLAYER_TOKEN can be any secret string; falls back to machine UUID.

Files:
  ~/.vaultlayer/credentials.enc  — encrypted credential store (JSON encrypted with Fernet)
  ~/.vaultlayer/salt             — per-installation random salt (16 bytes, hex-encoded)
"""

import os
import json
import logging
from base64 import urlsafe_b64encode
from pathlib import Path
from typing import Optional

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

logger = logging.getLogger(__name__)

_VAULT_DIR = Path.home() / ".vaultlayer"
_ENC_FILE = _VAULT_DIR / "credentials.enc"
_SALT_FILE = _VAULT_DIR / "salt"


class CredentialVault:
    """
    Encrypts and decrypts credentials at rest using Fernet (AES-128-CBC + HMAC-SHA256).

    Usage::

        vault = CredentialVault()               # uses VAULTLAYER_TOKEN env var
        vault.store("AWS_ACCESS_KEY_ID", "...")
        key = vault.retrieve("AWS_ACCESS_KEY_ID")

    The vault file is stored at ~/.vaultlayer/credentials.enc.
    The per-installation salt is stored at ~/.vaultlayer/salt.
    """

    def __init__(self, token: str = "") -> None:
        """
        Derive the Fernet key from *token* (or VAULTLAYER_TOKEN env var).

        If no token is available, a random key is generated and a warning is logged —
        the vault will not be portable across sessions in that case.
        """
        _VAULT_DIR.mkdir(parents=True, exist_ok=True)
        salt = self._load_or_create_salt()

        effective_token = token or os.environ.get("VAULTLAYER_TOKEN", "")
        if not effective_token:
            # Fall back to a random key (non-portable)
            raw_key = Fernet.generate_key()
            self._fernet = Fernet(raw_key)
            logger.warning(
                "CredentialVault: credentials stored with random key — "
                "set VAULTLAYER_TOKEN for portability"
            )
        else:
            derived = self._derive_key(effective_token, salt)
            self._fernet = Fernet(derived)

    # -- Public API ----------------------------------------------------------------

    def store(self, key: str, value: str) -> None:
        """Encrypt *value* and save it under *key* in the credential store."""
        creds = self._load_encrypted_store()
        creds[key] = value
        self._save_encrypted_store(creds)

    def retrieve(self, key: str) -> Optional[str]:
        """Decrypt and return the value for *key*; returns None if not found."""
        creds = self._load_encrypted_store()
        return creds.get(key)

    def store_all(self, creds: dict) -> None:
        """Bulk store — merges *creds* into the existing credential store."""
        existing = self._load_encrypted_store()
        existing.update(creds)
        self._save_encrypted_store(existing)

    def retrieve_all(self) -> dict:
        """Return all stored credentials; returns empty dict if vault not initialized."""
        return self._load_encrypted_store()

    # -- Internal helpers ----------------------------------------------------------

    def _derive_key(self, token: str, salt: bytes) -> bytes:
        """PBKDF2-HMAC-SHA256 → 32-byte key → URL-safe base64 for Fernet."""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100_000,
        )
        raw = kdf.derive(token.encode("utf-8"))
        return urlsafe_b64encode(raw)

    def _load_or_create_salt(self) -> bytes:
        """Read ~/.vaultlayer/salt or create a new 16-byte random salt."""
        if _SALT_FILE.exists():
            return bytes.fromhex(_SALT_FILE.read_text().strip())
        salt = os.urandom(16)
        _SALT_FILE.write_text(salt.hex())
        _SALT_FILE.chmod(0o600)  # owner-only read/write
        return salt

    def _load_encrypted_store(self) -> dict:
        """Decrypt and parse the credential store; returns {} on any error."""
        if not _ENC_FILE.exists():
            return {}
        try:
            ciphertext = _ENC_FILE.read_bytes()
            plaintext = self._fernet.decrypt(ciphertext)
            return json.loads(plaintext.decode("utf-8"))
        except InvalidToken:
            logger.warning(
                "CredentialVault: decryption failed — wrong VAULTLAYER_TOKEN or corrupted vault. "
                "Starting fresh (previous credentials lost). "
                "Set VAULTLAYER_TOKEN to the correct token and retry to recover."
            )
            return {}  # overwrite on next store() call rather than crash
        except Exception as e:
            logger.error(f"CredentialVault: failed to load credential store: {e}")
            return {}

    def _save_encrypted_store(self, creds: dict) -> None:
        """Serialize *creds* to JSON, encrypt, and write to disk."""
        plaintext = json.dumps(creds).encode("utf-8")
        ciphertext = self._fernet.encrypt(plaintext)
        _ENC_FILE.write_bytes(ciphertext)
        _ENC_FILE.chmod(0o600)  # owner-only read/write
