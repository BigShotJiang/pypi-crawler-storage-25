"""Dynamic GPU name resolution with persistent disk cache.

Resolves canonical GPU keys (e.g. "H100", "A100") to provider-specific names
by querying provider APIs. Falls back to static provider_instance_maps in
config/vaultlayer_data.json ONLY when both the API call AND the disk cache miss.

Resolution priority:
  1. In-memory cache (if < CACHE_TTL old)
  2. Disk cache at config/gpu_cache.json (if < CACHE_TTL old)
  3. Provider API call (writes to both memory + disk on success)
  4. Static fallback via data_loader.get_instance_string() (last resort)

Cache persists across restarts so the resolver works even if a provider API
is temporarily down at boot time. TTL is 24 hours.

Usage:
  resolver = GPUResolver()
  gpu_name = await resolver.resolve("RunPod", "H100", api_key="...")
  # Returns "NVIDIA H100 80GB HBM3" (from cache or API)
"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Cache expires after 24 hours — provider GPU catalogs rarely change more often.
CACHE_TTL_SECONDS = 86400

# Disk cache location (relative to repo root, next to vaultlayer_data.json)
_CACHE_DIR = Path(__file__).resolve().parent.parent.parent / "config"
_CACHE_FILE = _CACHE_DIR / "gpu_cache.json"


class GPUResolver:
    """Resolve canonical GPU keys to provider-specific names via API with cache."""

    def __init__(self) -> None:
        # {provider: {gpu_key_lower: provider_name}}
        self._cache: dict[str, dict[str, str]] = {}
        # {provider: epoch_seconds (wall clock for disk persistence)}
        self._cache_ts: dict[str, float] = {}
        # monotonic timestamps for in-process TTL checks
        self._cache_mono: dict[str, float] = {}
        # Load disk cache on init
        self._load_disk_cache()

    def _load_disk_cache(self) -> None:
        """Load cached GPU mappings from disk if available and fresh."""
        try:
            if not _CACHE_FILE.exists():
                return
            data = json.loads(_CACHE_FILE.read_text())
            now = time.time()
            loaded = 0
            for provider, entry in data.items():
                ts = entry.get("_ts", 0)
                if (now - ts) < CACHE_TTL_SECONDS:
                    gpu_map = {k: v for k, v in entry.items() if k != "_ts"}
                    self._cache[provider] = gpu_map
                    self._cache_ts[provider] = ts
                    self._cache_mono[provider] = time.monotonic()
                    loaded += 1
            if loaded:
                logger.info(f"[GPUResolver] Loaded {loaded} providers from disk cache")
        except Exception as e:
            logger.debug(f"[GPUResolver] Disk cache load failed (non-fatal): {e}")

    def _save_disk_cache(self) -> None:
        """Persist current cache to disk."""
        try:
            data = {}
            for provider, gpu_map in self._cache.items():
                entry = dict(gpu_map)
                entry["_ts"] = self._cache_ts.get(provider, time.time())
                data[provider] = entry
            _CACHE_DIR.mkdir(parents=True, exist_ok=True)
            _CACHE_FILE.write_text(json.dumps(data, indent=2, sort_keys=True))
        except Exception as e:
            logger.debug(f"[GPUResolver] Disk cache save failed (non-fatal): {e}")

    async def resolve(
        self,
        provider: str,
        gpu_key: str,
        api_key: str = "",
    ) -> str:
        """Return provider-specific GPU name for a canonical key.

        Args:
            provider: Provider name (e.g. "RunPod", "Vast.ai", "Lambda Labs")
            gpu_key: Canonical GPU key (e.g. "H100", "A100_40")
            api_key: Provider API key for dynamic lookup

        Returns:
            Provider-specific GPU name string, or empty string if not found.
        """
        key_lower = gpu_key.lower()

        # 1. Check in-memory cache (fast path)
        if provider in self._cache:
            age = time.monotonic() - self._cache_mono.get(provider, 0)
            if age < CACHE_TTL_SECONDS:
                cached = self._cache[provider].get(key_lower, "")
                if cached:
                    return cached

        # 2. Try API refresh (only if we have credentials)
        if api_key:
            refreshed = await self._refresh_provider(provider, api_key)
            if refreshed:
                cached = self._cache.get(provider, {}).get(key_lower, "")
                if cached:
                    return cached

        # 3. Fall back to static mapping (last resort — may be stale)
        from shared.data_loader import get_instance_string
        static = get_instance_string(provider, gpu_key)
        if static:
            logger.debug(
                f"[GPUResolver] Using static fallback for {provider}/{gpu_key} → {static}"
            )
        return static

    async def _refresh_provider(self, provider: str, api_key: str) -> bool:
        """Query provider API for all GPU types and update cache.

        Returns True if cache was updated, False on failure.
        """
        fetcher = {
            "RunPod": self._fetch_runpod_gpus,
            "Vast.ai": self._fetch_vastai_gpus,
            "Lambda Labs": self._fetch_lambda_gpus,
        }.get(provider)

        if not fetcher:
            return False

        try:
            gpu_map = await fetcher(api_key)
            if gpu_map:
                self._cache[provider] = gpu_map
                self._cache_ts[provider] = time.time()
                self._cache_mono[provider] = time.monotonic()
                self._save_disk_cache()
                logger.info(
                    f"[GPUResolver] Refreshed {provider} GPU cache: "
                    f"{len(gpu_map)} types (persisted to disk)"
                )
                return True
        except Exception as e:
            logger.warning(f"[GPUResolver] {provider} GPU fetch failed: {e}")
        return False

    async def warm(self, providers: dict[str, str]) -> None:
        """Pre-warm cache for multiple providers at startup.

        Args:
            providers: {provider_name: api_key} dict. Skips providers whose
                       cache is already fresh (< TTL).
        """
        for provider, api_key in providers.items():
            if not api_key:
                continue
            # Skip if cache is fresh
            if provider in self._cache_mono:
                age = time.monotonic() - self._cache_mono[provider]
                if age < CACHE_TTL_SECONDS:
                    continue
            await self._refresh_provider(provider, api_key)

    async def _fetch_runpod_gpus(self, api_key: str) -> dict[str, str]:
        """Fetch RunPod's valid gpuTypeIds enum from the REST OpenAPI spec.

        Returns: {gpu_key_lower: canonical_enum_value}

        RunPod has two incompatible GPU-name conventions:
          - GraphQL `gpuTypes { displayName }`  → "A100 SXM", "H100 PCIe"
          - REST POST /v1/pods gpuTypeIds enum  → "NVIDIA A100-SXM4-80GB"
        The broker uses the REST POST endpoint; a value from GraphQL is
        rejected with HTTP 400 "value must be one of ...". No dedicated
        REST catalog endpoint exists (confirmed from /v1/openapi.json on
        2026-04-17), so we read the enum straight from the OpenAPI spec
        the API itself ships. api_key is unused — the spec is public.

        Source: https://rest.runpod.io/v1/openapi.json
        """
        import aiohttp

        gpu_map: dict[str, str] = {}
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://rest.runpod.io/v1/openapi.json",
                timeout=aiohttp.ClientTimeout(total=15),
            ) as r:
                if r.status != 200:
                    return gpu_map
                spec = await r.json()

        # Walk the spec: paths./pods.post.requestBody → schema (may be
        # a $ref to components.schemas.<name>) → properties.gpuTypeIds
        # .items.enum — that array holds every valid REST GPU name.
        def _resolve_schema(schema: dict) -> dict:
            if "$ref" in schema:
                ref = schema["$ref"].rsplit("/", 1)[-1]
                return spec.get("components", {}).get("schemas", {}).get(ref, {})
            return schema

        try:
            post_op = spec["paths"]["/pods"]["post"]
            body_schema = post_op["requestBody"]["content"]["application/json"]["schema"]
            props = _resolve_schema(body_schema).get("properties", {})
            items = _resolve_schema(props.get("gpuTypeIds", {})).get("items", {})
            enum = _resolve_schema(items).get("enum", []) or []
        except (KeyError, TypeError):
            return gpu_map

        for display in enum:
            if not isinstance(display, str) or not display:
                continue
            _name_lower = display.lower()
            gpu_map[_name_lower] = display
            for _short in _extract_gpu_keys(_name_lower):
                gpu_map[_short] = display
        return gpu_map

    async def _fetch_vastai_gpus(self, api_key: str) -> dict[str, str]:
        """Query Vast.ai marketplace for unique GPU names.

        Source: https://vast.ai/docs/api
        Endpoint: GET /api/v0/bundles/ — searches ALL offers (not just rentable)
                  to catch GPUs that are temporarily out of stock.

        Returns: {gpu_key_lower: gpu_name}
        """
        import aiohttp
        import json as _json

        gpu_map: dict[str, str] = {}
        async with aiohttp.ClientSession() as session:
            # Search all offers (not just rentable) to get complete GPU catalog
            _q = _json.dumps({})
            async with session.get(
                "https://console.vast.ai/api/v0/bundles/",
                headers={"Authorization": f"Bearer {api_key}", "Accept-Encoding": "identity"},
                params={"q": _q, "limit": "500"},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as r:
                if r.status != 200:
                    return gpu_map
                data = await r.json()
                offers = data.get("offers", [])
                seen: set[str] = set()
                for o in offers:
                    gpu_name = o.get("gpu_name", "")
                    if gpu_name and gpu_name not in seen:
                        seen.add(gpu_name)
                        _name_lower = gpu_name.lower()
                        gpu_map[_name_lower] = gpu_name
                        for _short in _extract_gpu_keys(_name_lower):
                            gpu_map[_short] = gpu_name
        return gpu_map

    async def _fetch_lambda_gpus(self, api_key: str) -> dict[str, str]:
        """Query Lambda Labs for available instance types.

        Source: https://cloud.lambda.ai/api/v1/openapi.json
        Endpoint: GET /api/v1/instance-types (Basic Auth)

        Returns: {gpu_key_lower: instance_type_name}

        Lambda has multi-GPU variants (1x, 2x, 4x, 8x). We prefer the 1x
        variant for single-GPU jobs since it's cheaper and more available.
        The 8x variant is mapped under explicit keys like "h100_8x".
        """
        import aiohttp
        import base64

        gpu_map: dict[str, str] = {}
        _auth = base64.b64encode(f"{api_key}:".encode()).decode()
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://cloud.lambdalabs.com/api/v1/instance-types",
                headers={"Authorization": f"Basic {_auth}"},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as r:
                if r.status != 200:
                    return gpu_map
                data = await r.json()
                # Response: {"data": {"gpu_1x_h100_sxm5": {...}, ...}}
                # Group by GPU model, preferring 1x variants
                _by_model: dict[str, list[tuple[int, str]]] = {}
                for type_name in data.get("data", {}).keys():
                    # Always store exact type_name for direct lookup
                    gpu_map[type_name.lower()] = type_name
                    # Parse GPU count: "gpu_1x_h100_sxm5" → count=1, model="h100"
                    parts = type_name.lower().split("_")
                    if len(parts) >= 3 and parts[0] == "gpu":
                        count_str = parts[1].rstrip("x")
                        try:
                            count = int(count_str)
                        except ValueError:
                            count = 1
                        model_parts = parts[2:]  # ["h100", "sxm5"]
                        model_key = model_parts[0]  # "h100"
                        if model_key not in _by_model:
                            _by_model[model_key] = []
                        _by_model[model_key].append((count, type_name))

                # For each GPU model, map the canonical key to the 1x variant
                for model_key, variants in _by_model.items():
                    variants.sort(key=lambda x: x[0])  # sort by GPU count ascending
                    # 1x variant → canonical key (e.g. "h100" → gpu_1x_h100_sxm5)
                    smallest = variants[0]
                    gpu_map[model_key] = smallest[1]
                    # Also extract more specific keys from the type name
                    desc = data.get("data", {}).get(smallest[1], {}).get(
                        "instance_type", {}
                    ).get("description", "").lower()
                    for source in [desc, smallest[1].lower()]:
                        for _short in _extract_gpu_keys(source):
                            if _short not in gpu_map:
                                gpu_map[_short] = smallest[1]
                    # Map explicit multi-GPU keys: "h100_8x" → gpu_8x_h100_sxm5
                    for count, tname in variants:
                        if count > 1:
                            gpu_map[f"{model_key}_{count}x"] = tname
        return gpu_map

    def invalidate(self, provider: str | None = None) -> None:
        """Clear cache for a provider (or all providers)."""
        if provider:
            self._cache.pop(provider, None)
            self._cache_ts.pop(provider, None)
            self._cache_mono.pop(provider, None)
        else:
            self._cache.clear()
            self._cache_ts.clear()
            self._cache_mono.clear()
        self._save_disk_cache()


def _extract_gpu_keys(name_lower: str) -> list[str]:
    """Extract common GPU key forms from a display name.

    "nvidia h100 80gb hbm3" → ["h100", "h100 80gb"]
    "nvidia a100-sxm4-80gb" → ["a100", "a100 80gb", "a100_80"]
    "rtx 4090" → ["rtx4090", "4090"]
    """
    keys: list[str] = []
    import re
    m = re.search(
        r'(gh200|h100|h200|b200|a100|a6000|a10g|a10|a40|l40s|l40|'
        r'rtx\s*5090|rtx\s*5080|rtx\s*5070|rtx\s*4090|rtx\s*3090|'
        r'5090|5080|4090|3090|v100)',
        name_lower,
    )
    if m:
        base = m.group(1).replace(" ", "")
        keys.append(base)
        # Try to find memory suffix: "80gb", "40gb"
        mem = re.search(r'(\d+)\s*gb', name_lower)
        if mem:
            keys.append(f"{base} {mem.group(1)}gb")
            keys.append(f"{base}_{mem.group(1)}")
    return keys
