"""
VaultLayer -- Telemetry System
Two purposes:
  1. Bug/error tracking  -- structured error events with full context for debugging
  2. Internal metrics    -- operational data fed to Orchestration Agent for better decisions

Design principles:
  - Zero external dependencies at core (no Datadog/Sentry SDK required to run)
  - Structured JSON logs always -- every event is machine-parseable
  - Fire-and-forget async -- telemetry never blocks the hot path
  - Opt-in external sinks -- Sentry, Prometheus, PostHog via env vars
  - All metrics stored in Redis so Orchestration Agent can read them

Metric categories:
  OPERATIONAL  -- agent health, queue latency, Redis connectivity
  JOB          -- per-job timing, step rate, checkpoint durations
  PROVIDER     -- per-provider reliability, provisioning latency, spot interruption rate
  ERROR        -- exceptions, failure counts, error rates per component
  DECISION     -- Orchestration Agent decision outcomes (for Claude's own feedback loop)
"""

import json
import time
import logging
import asyncio
import traceback
from enum import Enum
from typing import Optional, Any
from datetime import datetime, timezone
from dataclasses import dataclass, field, asdict

logger = logging.getLogger(__name__)


# ── Metric categories ──────────────────────────────────────────────────────

class MetricCategory(str, Enum):
    OPERATIONAL = "operational"   # agent health, latency, connectivity
    JOB         = "job"           # per-job progress, step rate, timing
    PROVIDER    = "provider"      # provider reliability, interruption rate
    ERROR       = "error"         # exceptions, failure counts
    DECISION    = "decision"      # orchestration outcomes for feedback loop


class MetricType(str, Enum):
    COUNTER   = "counter"     # monotonically increasing (errors, jobs completed)
    GAUGE     = "gauge"       # point-in-time value (step rate, active jobs)
    TIMING    = "timing"      # duration in ms (checkpoint time, migration time)
    EVENT     = "event"       # discrete occurrence with context (interruption, error)


# ── Core metric dataclass ─────────────────────────────────────────────────

@dataclass
class Metric:
    name: str
    category: MetricCategory
    metric_type: MetricType
    value: float
    unit: str = ""
    tags: dict = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    job_id: Optional[str] = None
    agent: Optional[str] = None
    error: Optional[str] = None
    trace: Optional[str] = None  # stack trace for error events

    def to_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v is not None}

    def to_json(self) -> str:
        return json.dumps(self.to_dict())


# ── Telemetry collector ────────────────────────────────────────────────────

class TelemetryCollector:
    """
    Central telemetry hub. All agents emit metrics through this.

    Usage:
        tel = TelemetryCollector(queue=queue, agent_name="watchdog_agent")
        tel.timing("checkpoint.duration_ms", 4200, job_id=job.job_id)
        tel.error("provision.failed", exc, tags={"provider": "aws"})
        tel.gauge("job.step_rate", 12.4, tags={"gpu": "H100"}, job_id=job.job_id)
    """

    # Redis key patterns
    KEY_METRICS_STREAM  = "vaultlayer:telemetry:stream"       # recent events (XADD)
    KEY_COUNTER_PREFIX  = "vaultlayer:telemetry:counter:"     # persistent counters
    KEY_GAUGE_PREFIX    = "vaultlayer:telemetry:gauge:"       # latest gauge values
    KEY_PROVIDER_STATS  = "vaultlayer:telemetry:provider:"    # per-provider reliability
    KEY_JOB_STATS       = "vaultlayer:telemetry:job:"         # per-job metrics
    KEY_ERROR_COUNTS    = "vaultlayer:telemetry:errors"       # error frequency hash
    KEY_DECISION_STATS  = "vaultlayer:telemetry:decisions"    # orchestration outcomes

    # How many recent events to keep in the stream
    STREAM_MAX_LEN = 10000

    def __init__(self, queue=None, agent_name: str = "unknown"):
        self.queue = queue          # AgentQueue -- used for Redis access
        self.agent_name = agent_name
        self._buffer: list = []     # local buffer for batch flush
        self._lock = None  # Lock created lazily when needed in async context
        logger.info(f"TelemetryCollector initialised for agent: {agent_name}")

    # ── Metric emission methods ──────────────────────────────────────────

    def counter(self, name: str, value: float = 1.0, tags: dict = None,
                job_id: str = None) -> None:
        """Increment a counter. Fire-and-forget."""
        self._emit(Metric(
            name=name, category=MetricCategory.OPERATIONAL,
            metric_type=MetricType.COUNTER, value=value,
            tags=tags or {}, job_id=job_id, agent=self.agent_name,
        ))

    def gauge(self, name: str, value: float, unit: str = "",
              tags: dict = None, job_id: str = None,
              category: MetricCategory = MetricCategory.JOB) -> None:
        """Record a point-in-time value."""
        self._emit(Metric(
            name=name, category=category,
            metric_type=MetricType.GAUGE, value=value, unit=unit,
            tags=tags or {}, job_id=job_id, agent=self.agent_name,
        ))

    def timing(self, name: str, duration_ms: float, tags: dict = None,
               job_id: str = None,
               category: MetricCategory = MetricCategory.JOB) -> None:
        """Record a duration in milliseconds."""
        self._emit(Metric(
            name=name, category=category,
            metric_type=MetricType.TIMING, value=duration_ms, unit="ms",
            tags=tags or {}, job_id=job_id, agent=self.agent_name,
        ))

    def error(self, name: str, exc: Exception = None, tags: dict = None,
              job_id: str = None, message: str = None) -> None:
        """Record an error event with full traceback."""
        trace = traceback.format_exc() if exc else None
        err_msg = message or (str(exc) if exc else "unknown error")
        self._emit(Metric(
            name=name, category=MetricCategory.ERROR,
            metric_type=MetricType.EVENT, value=1.0,
            tags=tags or {}, job_id=job_id, agent=self.agent_name,
            error=err_msg, trace=trace,
        ))
        logger.error(f"[telemetry] {name}: {err_msg}", extra={"tags": tags})

    def event(self, name: str, value: float = 1.0, tags: dict = None,
              job_id: str = None,
              category: MetricCategory = MetricCategory.OPERATIONAL) -> None:
        """Record a discrete event."""
        self._emit(Metric(
            name=name, category=category,
            metric_type=MetricType.EVENT, value=value,
            tags=tags or {}, job_id=job_id, agent=self.agent_name,
        ))

    def decision(self, action: str, confidence: float, outcome: str,
                 savings_usd: float = 0.0, job_id: str = None,
                 tags: dict = None) -> None:
        """
        Record an Orchestration Agent decision and its outcome.
        This is the feedback loop: did the decision actually save money / work?
        """
        self._emit(Metric(
            name="orchestration.decision",
            category=MetricCategory.DECISION,
            metric_type=MetricType.EVENT,
            value=confidence,
            tags={**(tags or {}), "action": action, "outcome": outcome,
                  "savings_usd": str(round(savings_usd, 2))},
            job_id=job_id, agent=self.agent_name,
        ))

    # ── Timer context manager ─────────────────────────────────────────────

    class Timer:
        """Context manager for timing code blocks."""
        def __init__(self, collector, name: str, tags: dict = None,
                     job_id: str = None, category=None):
            self.collector = collector
            self.name = name
            self.tags = tags or {}
            self.job_id = job_id
            self.category = category or MetricCategory.JOB
            self._start = None

        def __enter__(self):
            self._start = time.monotonic()
            return self

        def __exit__(self, *args):
            elapsed_ms = (time.monotonic() - self._start) * 1000
            self.collector.timing(self.name, elapsed_ms,
                                  tags=self.tags, job_id=self.job_id,
                                  category=self.category)

    def timer(self, name: str, tags: dict = None, job_id: str = None,
              category: MetricCategory = None) -> Timer:
        """Usage: with tel.timer('checkpoint.upload'): ..."""
        return self.Timer(self, name, tags, job_id, category)

    # ── Internal ──────────────────────────────────────────────────────────

    def _emit(self, metric: Metric) -> None:
        """Emit metric to structured log + queue buffer. Never raises."""
        try:
            logger.info(json.dumps({
                "telemetry": True,
                **metric.to_dict(),
            }))
            self._buffer.append(metric)
            # Flush if buffer is large enough to batch
            if len(self._buffer) >= 20:
                try:
                    loop = asyncio.get_running_loop()
                    loop.create_task(self._flush())
                except RuntimeError:
                    pass  # No running event loop -- sync context, flush will be called manually
        except Exception as e:
            logger.debug(f"Telemetry emit failed (non-fatal): {e}")

    async def _flush(self) -> None:
        """Flush buffered metrics to Redis. Non-blocking, never raises."""
        if not self.queue or not self._buffer:
            return
        batch = self._buffer[:]
        self._buffer = []
        try:
            redis = self.queue._redis
            if not redis:
                return
            pipe = redis.pipeline()
            for m in batch:
                data = m.to_dict()
                # Stream: recent events for debugging
                pipe.xadd(self.KEY_METRICS_STREAM, data,
                           maxlen=self.STREAM_MAX_LEN, approximate=True)
                # Counters: persistent increment
                if m.metric_type == MetricType.COUNTER:
                    pipe.hincrbyfloat(self.KEY_COUNTER_PREFIX + m.name,
                                      m.agent or 'global', m.value)
                # Gauges: latest value only
                if m.metric_type == MetricType.GAUGE:
                    pipe.hset(self.KEY_GAUGE_PREFIX + m.name,
                               m.agent or 'global', m.value)
                # Errors: increment error counts for dashboarding
                if m.category == MetricCategory.ERROR:
                    pipe.hincrby(self.KEY_ERROR_COUNTS, m.name, 1)
                # Provider reliability stats
                if m.category == MetricCategory.PROVIDER and m.tags.get('provider'):
                    pipe.hincrbyfloat(
                        self.KEY_PROVIDER_STATS + m.tags['provider'],
                        m.name, m.value
                    )
                # Decision outcomes
                if m.category == MetricCategory.DECISION:
                    pipe.hincrbyfloat(self.KEY_DECISION_STATS,
                                      m.tags.get('action', 'unknown'), 1)
            await pipe.execute()
        except Exception as e:
            logger.debug(f"Telemetry flush failed (non-fatal): {e}")

    async def flush_now(self) -> None:
        """Force-flush all buffered metrics. Call on agent shutdown."""
        await self._flush()

    async def get_summary(self) -> dict:
        """
        Return a snapshot of key metrics for the Orchestration Agent's decision context.
        This is what Claude reads when making migration/checkpoint decisions.
        """
        if not self.queue:
            return {}
        try:
            redis = self.queue._redis
            if not redis:
                return {}
            pipe = redis.pipeline()
            pipe.hgetall(self.KEY_ERROR_COUNTS)
            pipe.hgetall(self.KEY_DECISION_STATS)
            results = await pipe.execute()
            return {
                "error_counts": {k.decode(): int(v) for k, v in (results[0] or {}).items()},
                "decision_outcomes": {k.decode(): int(v) for k, v in (results[1] or {}).items()},
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except Exception as e:
            logger.debug(f"Telemetry summary failed: {e}")
            return {}


# ── Convenience: module-level no-op collector for import safety ──────────

class _NoOpCollector:
    """Drop-in replacement when telemetry is disabled (e.g. in tests)."""
    def counter(self, *a, **kw): pass
    def gauge(self, *a, **kw): pass
    def timing(self, *a, **kw): pass
    def error(self, *a, **kw): pass
    def event(self, *a, **kw): pass
    def decision(self, *a, **kw): pass
    def timer(self, name, **kw):
        import contextlib
        return contextlib.nullcontext()
    async def flush_now(self): pass
    async def get_summary(self): return {}

NOOP = _NoOpCollector()


def make_telemetry(queue=None, agent_name: str = "unknown",
                   enabled: bool = True) -> TelemetryCollector:
    """Factory. Returns NoOp if disabled (useful for tests)."""
    if not enabled:
        return NOOP
    return TelemetryCollector(queue=queue, agent_name=agent_name)
