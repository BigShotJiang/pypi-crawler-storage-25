"""
VaultLayer — Storage Billing

Pricing model:
  Base cost (Cloudflare R2):  $0.015 / GB / month
  Markup:                     30%  (multiplier 1.30)
  Markup rate:                $0.0195 / GB / month  (= R2 × 1.30)
  Price floor (Big 3 min):    $0.018 / GB / month   (Azure Blob standard, March 2026)
  User rate:                  Max(markup_rate, CHEAPEST_BIG3_STORAGE)
                              = $0.0195 at current R2 pricing (above the floor)
  Margin:                     23–30% (scales with Cloudflare's rate automatically)

The floor ensures VaultLayer is never priced below commodity cloud storage
(AWS S3 / GCP GCS / Azure Blob). The rate is NEVER hardcoded at the call
site — all code that needs the price calls get_current_storage_rate() so
that a Cloudflare or Big-3 price change only requires updating the constants
here.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# ── Pricing constants ─────────────────────────────────────────────────────────

# Cloudflare R2 standard storage rate (update here if Cloudflare changes pricing)
R2_BASE_COST_PER_GB_MONTH: float = float(
    os.getenv("VL_R2_BASE_COST_PER_GB", "0.015")
)

# Markup multiplier — 1.30 = 30% above our raw cost
STORAGE_MARKUP_MULTIPLIER: float = float(
    os.getenv("VL_STORAGE_MARKUP", "1.30")
)

# Cheapest of AWS S3 / GCP / Azure standard storage (March 2026)
# Used as price floor so VaultLayer is never cheaper than commodity cloud storage
BIG3_STORAGE_RATES: dict[str, float] = {
    "aws_s3":     0.023,
    "gcp_gcs":    0.020,
    "azure_blob": 0.018,
}
CHEAPEST_BIG3_STORAGE: float = min(BIG3_STORAGE_RATES.values())  # 0.018

# Stripe env vars
STRIPE_SECRET_KEY: str = os.getenv("STRIPE_SECRET_KEY", "")
STRIPE_STORAGE_PRICE_ID: str = os.getenv("STRIPE_STORAGE_PRICE_ID", "")  # metered price ID


def get_current_storage_rate(raw_r2_cost: Optional[float] = None) -> float:
    """
    Return the per-GB/month rate charged to users.

    Always calculated as raw_r2_cost * STORAGE_MARKUP_MULTIPLIER so that
    margin is preserved automatically if Cloudflare changes their pricing.

    Args:
        raw_r2_cost: Override the base R2 cost (for testing). Defaults to
                     R2_BASE_COST_PER_GB_MONTH from env/constant.

    Returns:
        User rate in $/GB/month, rounded to 3 decimal places.
        Example: 0.015 * 1.30 = 0.0195 → $0.020/GB/month displayed.
    """
    base = raw_r2_cost if raw_r2_cost is not None else R2_BASE_COST_PER_GB_MONTH
    # Round to 4 decimal places for precision ($0.0195); Stripe handles 4dp fine.
    # 3dp would give $0.020 but introduces float ambiguity (0.015 * 1.30 is not
    # exactly representable in IEEE 754 — can produce 0.019 instead of 0.020).
    return round(base * STORAGE_MARKUP_MULTIPLIER, 4)


def get_daily_storage_cost(gb_stored: float) -> float:
    """
    Pro-rated daily charge for gb_stored gigabytes.
    monthly_rate / 30 days.
    """
    monthly = gb_stored * get_current_storage_rate()
    return round(monthly / 30.0, 6)


# ── R2 usage measurement ──────────────────────────────────────────────────────

def _measure_r2_usage_per_user(config) -> list[dict]:
    """
    Query Cloudflare R2 to get current GB stored per user dataset prefix.

    Returns list of dicts: [{user_id, bucket_path, gb_stored}]

    Uses boto3 S3-compatible client against the R2 endpoint and lists all
    objects under datasets/ grouped by user_id prefix.
    """
    try:
        import boto3
    except ImportError:
        logger.error("boto3 not installed — cannot measure R2 usage")
        return []

    try:
        s3 = boto3.client(
            "s3",
            endpoint_url=config.cloudflare.r2_endpoint,
            aws_access_key_id=config.cloudflare.r2_access_key_id,
            aws_secret_access_key=config.cloudflare.r2_secret_access_key,
            region_name="auto",
        )
        paginator = s3.get_paginator("list_objects_v2")

        # Group total bytes per user_id by reading the datasets/ prefix tree.
        # Layout in R2: datasets/{dataset_id}/ (dataset_id registered in DB with user_id)
        # We resolve user→datasets from Supabase, then sum sizes per user.
        from api.db import get_db, SUPABASE_URL
        if not SUPABASE_URL:
            logger.warning("SUPABASE_URL not set — skipping R2 usage measurement")
            return []

        db = get_db()
        rows = db.table("datasets") \
                 .select("user_id, dataset_id, r2_prefix") \
                 .is_("deleted_at", "null") \
                 .execute().data or []

        # Aggregate bytes per user
        user_bytes: dict[str, float] = {}
        for row in rows:
            uid = row["user_id"]
            prefix = row["r2_prefix"]  # e.g. "datasets/my-dataset/"
            total = 0
            try:
                pages = paginator.paginate(Bucket=config.cloudflare.r2_bucket, Prefix=prefix)
                for page in pages:
                    for obj in page.get("Contents", []):
                        total += obj.get("Size", 0)
            except Exception as e:
                logger.warning(f"R2 list failed for {prefix}: {e}")
            user_bytes[uid] = user_bytes.get(uid, 0) + total

        return [
            {
                "user_id": uid,
                "bucket_path": f"datasets/user:{uid}/",
                "gb_stored": bytes_total / 1e9,
            }
            for uid, bytes_total in user_bytes.items()
        ]

    except Exception as e:
        logger.error(f"R2 usage measurement failed: {e}")
        return []


# ── Stripe metered billing ────────────────────────────────────────────────────

def report_storage_to_stripe(stripe_customer_id: str, gb_used: float) -> Optional[str]:
    """
    Report daily GB storage usage to Stripe as a metered billing event.

    Uses Stripe Billing Meter Events API (stripe-python v5+):
        stripe.billing.MeterEvent.create(event_name, payload, timestamp)

    The meter is configured in the Stripe dashboard with event_name matching
    STRIPE_STORAGE_METER_NAME. Stripe aggregates events and bills monthly.

    Returns the Stripe meter event identifier, or None on failure.
    """
    stripe_meter_name: str = os.getenv("STRIPE_STORAGE_METER_NAME", "vaultlayer_storage_gb")

    if not STRIPE_SECRET_KEY:
        logger.warning("STRIPE_SECRET_KEY not set — skipping Stripe storage report")
        return None

    try:
        import stripe
        stripe.api_key = STRIPE_SECRET_KEY

        # Stripe Billing Meter Events (v5+ API — replaces create_usage_record)
        event = stripe.billing.MeterEvent.create(
            event_name=stripe_meter_name,
            payload={
                "stripe_customer_id": stripe_customer_id,
                "value": str(max(1, int(gb_used))),  # Stripe expects string integer
            },
            timestamp=int(datetime.now(timezone.utc).timestamp()),
        )
        event_id = event.get("identifier") or event.get("id") or "ok"
        logger.info(f"Stripe storage meter reported: customer={stripe_customer_id} "
                    f"gb={gb_used:.3f} event={event_id}")
        return event_id

    except Exception as e:
        logger.error(f"Stripe storage report failed for {stripe_customer_id}: {e}")
        return None


# ── Daily cron job ────────────────────────────────────────────────────────────

def cron_record_daily_storage(config=None) -> dict:
    """
    Nightly cron: measure R2 storage per user, write to storage_ledger,
    report to Stripe metered billing.

    Designed to be called by:
        - A cron job (GitHub Actions, Render cron, etc.) at 00:00 UTC daily
        - Or a Supabase Edge Function on a schedule

    Returns summary dict with counts for monitoring.
    """
    from api.db import get_db, SUPABASE_URL

    if not SUPABASE_URL:
        logger.error("SUPABASE_URL not set — cannot run storage cron")
        return {"error": "SUPABASE_URL not configured"}

    if config is None:
        from shared.config import load_config
        config = load_config()

    current_rate = get_current_storage_rate()
    db = get_db()

    storage_data = _measure_r2_usage_per_user(config)
    if not storage_data:
        logger.info("cron_record_daily_storage: no active datasets found")
        return {"users_billed": 0, "total_gb": 0.0, "rate": current_rate}

    users_billed = 0
    total_gb = 0.0
    stripe_reported = 0

    for record in storage_data:
        user_id = record["user_id"]
        gb = record["gb_stored"]
        bucket_path = record["bucket_path"]

        # 1. Write daily snapshot to storage_ledger
        try:
            result = db.table("storage_ledger").insert({
                "user_id":        user_id,
                "bucket_path":    bucket_path,
                "gb_stored":      gb,
                "calculated_rate": current_rate,
                "recorded_at":    datetime.now(timezone.utc).isoformat(),
            }).execute()
            ledger_id = result.data[0]["id"] if result.data else None
        except Exception as e:
            logger.error(f"storage_ledger insert failed for {user_id}: {e}")
            continue

        users_billed += 1
        total_gb += gb

        # 2. Report to Stripe metered billing
        try:
            user_row = db.table("users") \
                         .select("stripe_customer_id") \
                         .eq("user_id", user_id) \
                         .single().execute().data
            stripe_customer_id = user_row.get("stripe_customer_id") if user_row else None
        except Exception:
            stripe_customer_id = None

        stripe_event_id = None
        if stripe_customer_id:
            stripe_event_id = report_storage_to_stripe(stripe_customer_id, gb)
            if stripe_event_id and ledger_id:
                try:
                    db.table("storage_ledger").update({
                        "stripe_reported": True,
                        "stripe_meter_event_id": stripe_event_id,
                    }).eq("id", ledger_id).execute()
                    stripe_reported += 1
                except Exception as e:
                    logger.warning(f"Could not update stripe_reported for {ledger_id}: {e}")

        logger.info(
            f"[storage cron] user={user_id} gb={gb:.3f} "
            f"rate=${current_rate}/GB/mo daily=${get_daily_storage_cost(gb):.6f} "
            f"stripe={'ok' if stripe_event_id else 'skipped'}"
        )

    summary = {
        "users_billed": users_billed,
        "total_gb":     round(total_gb, 3),
        "rate":         current_rate,
        "stripe_reported": stripe_reported,
        "recorded_at":  datetime.now(timezone.utc).isoformat(),
    }
    logger.info(f"[storage cron] complete: {summary}")
    return summary
