"""
VaultLayer -- Credit Ledger

Pre-paid credit system. Users buy credits (USD) upfront via Stripe before
running any job. Jobs are gated on available balance. Credits are reserved
at job start, burned in real-time every 60 seconds, and settled at job end.

This eliminates bad debt: VaultLayer never extends compute credit. If a user's
balance hits zero mid-job, the job is checkpointed and suspended -- not killed.
They top up, then resume. Zero progress lost, zero bad debt.

Redis key schema (all values stored as strings):
  vl:credits:{user_id}:balance       float  -- total purchased credits (USD)
  vl:credits:{user_id}:reserved      float  -- sum across all active reservations
  vl:credits:{user_id}:reservations  hash   -- {job_id: reserved_usd}
  vl:credits:{user_id}:ledger        stream -- append-only audit log of every debit/credit

Available balance = balance - reserved
"""

import logging
import time
from dataclasses import dataclass
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)

# Minimum credits required to start any job (prevents micro-balance abuse)
MIN_BALANCE_TO_START_USD = 5.00

# Same minimum for all flows — unified $5 threshold
MIN_BALANCE_MANAGED_USD = 5.00

# If available balance drops below this, publish LOW_CREDITS warning
LOW_BALANCE_THRESHOLD_USD = 10.00

# Grace amount: don't suspend a job over tiny overruns (clock skew, rounding)
GRACE_AMOUNT_USD = 0.50

# How often the burn loop ticks (seconds) -- must match orchestration heartbeat cadence
BURN_INTERVAL_SECONDS = 60


class CreditEventType(str, Enum):
    PURCHASED   = "purchased"    # Stripe payment confirmed
    RESERVED    = "reserved"     # credits locked at job start
    BURNED      = "burned"       # real-time consumption during job
    SETTLED     = "settled"      # final debit at job end (releases reservation)
    REFUNDED    = "refunded"     # job failed before any compute consumed
    RELEASED    = "released"     # reservation released without settlement (job cancelled)


@dataclass
class CreditBalance:
    """Snapshot of a user's credit position."""
    user_id: str
    balance_usd: float       # total purchased, never decremented (audit trail)
    reserved_usd: float      # locked by active jobs
    spent_usd: float         # settled (burned + finalized) -- derived from ledger
    available_usd: float     # balance - reserved - spent  (what new jobs can use)

    @property
    def is_sufficient_to_start(self) -> bool:
        return self.available_usd >= MIN_BALANCE_TO_START_USD

    def is_sufficient_for_flow(self, managed_flow: bool = False) -> bool:
        """Check if balance meets the minimum for the given flow type."""
        threshold = MIN_BALANCE_MANAGED_USD if managed_flow else MIN_BALANCE_TO_START_USD
        return self.available_usd >= threshold

    @property
    def is_low(self) -> bool:
        return self.available_usd < LOW_BALANCE_THRESHOLD_USD

    @property
    def is_exhausted(self) -> bool:
        return self.available_usd <= GRACE_AMOUNT_USD


class CreditLedger:
    """
    Manages the credit lifecycle for a single user.

    All state lives in Redis so it survives process restarts and is accessible
    from any VaultLayer service (Railway orchestrator, CLI sidecar, billing webhook).

    Usage:
        ledger = CreditLedger(redis_client, user_id="usr_abc123")
        await ledger.add_credits(50.00, stripe_payment_id="pi_xyz")
        ok = await ledger.reserve(job_id, estimated_usd=12.00)
        await ledger.burn(job_id, usd=0.048)   # called every 60s
        await ledger.settle(job_id, actual_usd=9.73)
    """

    def __init__(self, redis_client, user_id: str):
        self._r = redis_client
        self.user_id = user_id
        self._balance_key      = f"vl:credits:{user_id}:balance"
        self._reserved_key     = f"vl:credits:{user_id}:reserved"
        self._reservations_key = f"vl:credits:{user_id}:reservations"
        self._ledger_key       = f"vl:credits:{user_id}:ledger"
        self._spent_key        = f"vl:credits:{user_id}:spent"

    # ── Read ──────────────────────────────────────────────────────────────────

    async def get_balance(self) -> CreditBalance:
        """Return the current credit position for this user."""
        balance  = float(await self._r.get(self._balance_key)  or 0)
        reserved = float(await self._r.get(self._reserved_key) or 0)
        spent    = float(await self._r.get(self._spent_key)    or 0)
        available = max(0.0, balance - reserved - spent)
        return CreditBalance(
            user_id=self.user_id,
            balance_usd=balance,
            reserved_usd=reserved,
            spent_usd=spent,
            available_usd=available,
        )

    async def get_reservation(self, job_id: str) -> float:
        """Return how many credits are currently reserved for a specific job."""
        val = await self._r.hget(self._reservations_key, job_id)
        return float(val) if val else 0.0

    # ── Write ─────────────────────────────────────────────────────────────────

    async def add_credits(self, amount_usd: float, stripe_payment_id: str) -> CreditBalance:
        """
        Credit a user's account after Stripe confirms payment.
        Called from the Stripe webhook handler -- idempotent on payment_id.
        """
        if amount_usd <= 0:
            raise ValueError(f"Credit amount must be positive, got {amount_usd}")

        # Idempotency: check if this payment_id was already processed
        idem_key = f"vl:credits:{self.user_id}:payment:{stripe_payment_id}"
        already = await self._r.get(idem_key)
        if already:
            logger.warning(f"[credits] Duplicate payment {stripe_payment_id} ignored")
            return await self.get_balance()

        await self._r.incrbyfloat(self._balance_key, amount_usd)
        await self._r.set(idem_key, "1", ex=60 * 60 * 24 * 90)  # 90-day dedup window
        await self._append_ledger(CreditEventType.PURCHASED, amount_usd, {
            "stripe_payment_id": stripe_payment_id,
        })

        bal = await self.get_balance()
        logger.info(f"[credits] {self.user_id} +${amount_usd:.2f} purchased "
                    f"(payment {stripe_payment_id}). Available: ${bal.available_usd:.2f}")
        return bal

    async def reserve(self, job_id: str, estimated_usd: float) -> bool:
        """
        Reserve credits at job start. Returns False if insufficient balance.

        The reservation prevents the user from starting more jobs than they
        can afford. The reserved amount is an estimate; settle() handles the
        true final cost.

        If estimated_usd is unknown (open-ended job), reserve MIN_BALANCE_TO_START_USD
        as a deposit and top up via burn() in real time.
        """
        if estimated_usd <= 0:
            estimated_usd = MIN_BALANCE_TO_START_USD

        bal = await self.get_balance()
        if bal.available_usd < estimated_usd:
            logger.warning(
                f"[credits] {self.user_id} insufficient credits for job {job_id}: "
                f"need ${estimated_usd:.2f}, available ${bal.available_usd:.2f}"
            )
            return False

        # Atomic increment of reserved counter + store per-job reservation
        await self._r.incrbyfloat(self._reserved_key, estimated_usd)
        await self._r.hset(self._reservations_key, job_id, str(estimated_usd))
        await self._append_ledger(CreditEventType.RESERVED, estimated_usd, {
            "job_id": job_id,
            "estimated_usd": estimated_usd,
        })

        logger.info(f"[credits] {self.user_id} reserved ${estimated_usd:.2f} for job {job_id}")
        return True

    async def burn(self, job_id: str, usd: float) -> CreditBalance:
        """
        Real-time credit consumption. Called every BURN_INTERVAL_SECONDS by the
        orchestration heartbeat loop.

        Burn debits from both the reservation and the global spent counter.
        If the reservation is exhausted (job runs longer than estimated),
        burn continues against available balance until GRACE_AMOUNT_USD.

        Returns current balance so callers can check is_exhausted.
        """
        if usd <= 0:
            return await self.get_balance()

        reservation = await self.get_reservation(job_id)

        if reservation >= usd:
            # Normal path: burn from reservation
            new_reservation = reservation - usd
            await self._r.hset(self._reservations_key, job_id, str(new_reservation))
            await self._r.incrbyfloat(self._reserved_key, -usd)
        else:
            # Reservation exhausted — burn remainder from available balance directly
            # (job is running longer than estimated)
            overage = usd - reservation
            await self._r.hset(self._reservations_key, job_id, "0")
            if reservation > 0:
                await self._r.incrbyfloat(self._reserved_key, -reservation)
            # Overage comes out of balance as direct spend
            await self._r.incrbyfloat(self._spent_key, overage)
            logger.warning(
                f"[credits] {self.user_id} job {job_id} exceeded reservation by ${overage:.4f}. "
                f"Charging directly."
            )

        await self._r.incrbyfloat(self._spent_key, min(usd, reservation))
        await self._append_ledger(CreditEventType.BURNED, usd, {"job_id": job_id})

        bal = await self.get_balance()
        if bal.is_exhausted:
            logger.warning(
                f"[credits] {self.user_id} credits exhausted. "
                f"Available: ${bal.available_usd:.4f}. Job {job_id} will be suspended."
            )
        elif bal.is_low:
            logger.info(
                f"[credits] {self.user_id} low balance warning: ${bal.available_usd:.2f} remaining"
            )
        return bal

    async def settle(self, job_id: str, actual_usd: float) -> CreditBalance:
        """
        Final settlement at job end.

        1. Release the remaining reservation for this job
        2. Debit the actual cost from spent
        3. The difference (reservation - actual) is freed back to available balance

        If actual_usd > reservation (open-ended job ran long), the overage
        was already handled by burn() -- no double-charging.
        """
        reservation = await self.get_reservation(job_id)

        # Release remaining reservation
        if reservation > 0:
            await self._r.incrbyfloat(self._reserved_key, -reservation)
            await self._r.hdel(self._reservations_key, job_id)

        # The burn() calls already moved real spend into _spent_key.
        # settle() is idempotent for the actual cost -- nothing more to deduct.
        await self._append_ledger(CreditEventType.SETTLED, actual_usd, {
            "job_id": job_id,
            "reservation_released": reservation,
            "actual_usd": actual_usd,
        })

        bal = await self.get_balance()
        logger.info(
            f"[credits] {self.user_id} job {job_id} settled. "
            f"Actual cost: ${actual_usd:.4f}. Remaining balance: ${bal.available_usd:.2f}"
        )
        return bal

    async def release(self, job_id: str, reason: str = "cancelled") -> CreditBalance:
        """
        Release a reservation without settlement (job cancelled before any compute ran).
        Full reservation is returned to available balance.
        """
        reservation = await self.get_reservation(job_id)
        if reservation > 0:
            await self._r.incrbyfloat(self._reserved_key, -reservation)
            await self._r.hdel(self._reservations_key, job_id)
            await self._append_ledger(CreditEventType.RELEASED, reservation, {
                "job_id": job_id,
                "reason": reason,
            })
            logger.info(f"[credits] {self.user_id} released ${reservation:.4f} reservation "
                        f"for job {job_id} ({reason})")
        return await self.get_balance()

    async def refund(self, job_id: str, amount_usd: float, reason: str) -> CreditBalance:
        """
        Issue a credit refund (e.g. provider failure, VaultLayer SLA breach).
        Adds back to balance -- not to reservation.
        """
        await self._r.incrbyfloat(self._balance_key, amount_usd)
        await self._append_ledger(CreditEventType.REFUNDED, amount_usd, {
            "job_id": job_id,
            "reason": reason,
        })
        bal = await self.get_balance()
        logger.info(f"[credits] {self.user_id} refund ${amount_usd:.4f} for job {job_id} ({reason}). "
                    f"New available: ${bal.available_usd:.2f}")
        return bal

    # ── Helpers ───────────────────────────────────────────────────────────────

    async def _append_ledger(self, event_type: CreditEventType,
                              amount_usd: float, metadata: dict):
        """Append an immutable audit record to the Redis stream ledger."""
        try:
            fields = {
                "event_type":  event_type.value,
                "amount_usd":  f"{amount_usd:.6f}",
                "ts":          str(int(time.time())),
                **{k: str(v) for k, v in metadata.items()},
            }
            await self._r.xadd(self._ledger_key, fields, maxlen=10_000)
        except Exception as e:
            # Ledger write failure is non-fatal -- balance keys are the source of truth
            logger.warning(f"[credits] Ledger append failed (non-fatal): {e}")

    @staticmethod
    def estimate_job_cost(hourly_rate_usd: float,
                          estimated_hours: float = 2.0) -> float:
        """
        Calculate the credit reservation amount for a new job.

        For open-ended jobs (no estimated_hours), defaults to 2 hours.
        The burn loop will extend the effective credit consumption in real time.
        Adds 20% buffer for migration overhead (new node provisioning costs ~$0.03).
        """
        raw = hourly_rate_usd * estimated_hours
        buffer = raw * 0.20
        return round(raw + buffer, 2)
