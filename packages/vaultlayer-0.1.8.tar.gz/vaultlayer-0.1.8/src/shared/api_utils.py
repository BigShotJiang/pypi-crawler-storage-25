"""Shared API utilities -- single source for API URL, token, auth headers."""
import os
from pathlib import Path

_DEFAULT_API_URL = "https://vaultlayer-production.up.railway.app"

def get_api_url() -> str:
    return os.environ.get("VAULTLAYER_API_URL", _DEFAULT_API_URL).rstrip("/")

def get_token() -> str:
    """Load token from env, then config.env, then return empty string."""
    t = os.environ.get("VAULTLAYER_TOKEN", "")
    if t: return t
    config_env = Path.home() / ".vaultlayer" / "config.env"
    if config_env.exists():
        for line in config_env.read_text().splitlines():
            if line.startswith("VAULTLAYER_TOKEN="):
                return line.split("=", 1)[1].strip()
    return ""

def get_auth_headers() -> dict:
    """Return Authorization header dict for API calls."""
    return {"Authorization": f"Bearer {get_token()}"}

def api_request(method, path, **kwargs):
    """Make an authenticated API request. Returns (status_code, json_or_none)."""
    import httpx
    url = f"{get_api_url()}{path}"
    headers = {**get_auth_headers(), **kwargs.pop("headers", {})}
    try:
        resp = httpx.request(method, url, headers=headers, timeout=kwargs.pop("timeout", 10), **kwargs)
        return resp.status_code, resp.json() if resp.status_code == 200 else None
    except Exception as e:
        return 0, None
