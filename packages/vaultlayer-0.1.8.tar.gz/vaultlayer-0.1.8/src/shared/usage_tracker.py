"""
VaultLayer — GPU-Hour Usage Tracker (Issue #30)

Tracks GPU-hour usage per user per month using Redis INCRBYFLOAT.
Persists monthly summaries to Cloudflare R2 at job end.

Redis key scheme:
  vaultlayer:usage:{user_id}:{YYYY-MM}          → float (GPU-hours this month)
  vaultlayer:usage:{user_id}:{YYYY-MM}:usd      → float (USD spend this month)
  vaultlayer:usage:{user_id}:{YYYY-MM}:jobs     → int   (job count this month)
  vaultlayer:usage:{user_id}:current_spend       → float (running USD for live job)

R2 path for persisted monthly records:
  billing/{user_id}/{YYYY-MM}.json

Non-fatal: all functions log and return 0/None on failure.
Redis is optional — if not configured, usage is returned as 0.
"""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

_KEY_HOURS = "vaultlayer:usage:{user_id}:{month}"
_KEY_USD   = "vaultlayer:usage:{user_id}:{month}:usd"
_KEY_JOBS  = "vaultlayer:usage:{user_id}:{month}:jobs"
_KEY_LIVE  = "vaultlayer:usage:{user_id}:current_spend"


def _month() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m")


def _get_redis():
    url = os.environ.get("UPSTASH_REDIS_URL") or os.environ.get("REDIS_URL", "")
    if not url:
        return None
    try:
        import redis as _redis
        client = _redis.from_url(url, decode_responses=True, socket_timeout=2)
        client.ping()
        return client
    except Exception as e:
        logger.debug(f"[usage] Redis unavailable: {e}")
        return None


# ── Tick: called from heartbeat loop every 60s ────────────────────────────────

def tick_usage(user_id: str, rate_per_hr: float, interval_seconds: float = 60.0) -> float:
    """Increment GPU-hour and USD counters for user by one heartbeat interval.

    Called from the heartbeat loop (every 60s) while a job is running.
    Returns the new total GPU-hours for this month, or 0.0 on failure.

    Args:
        user_id:          Job owner identifier (Clerk user_id or "smoke-test").
        rate_per_hr:      Current GPU spot price in USD/hour.
        interval_seconds: Heartbeat interval (default 60s).
    """
    if not user_id:
        return 0.0

    r = _get_redis()
    if not r:
        return 0.0

    month = _month()
    gpu_hours_increment = interval_seconds / 3600.0
    usd_increment = gpu_hours_increment * rate_per_hr

    try:
        pipe = r.pipeline()
        pipe.incrbyfloat(_KEY_HOURS.format(user_id=user_id, month=month), gpu_hours_increment)
        pipe.incrbyfloat(_KEY_USD.format(user_id=user_id, month=month), usd_increment)
        pipe.incrbyfloat(_KEY_LIVE.format(user_id=user_id), usd_increment)
        results = pipe.execute()
        return float(results[0])
    except Exception as e:
        logger.debug(f"[usage] tick_usage failed for {user_id}: {e}")
        return 0.0


def reset_live_spend(user_id: str) -> None:
    """Reset the running live spend counter when a job ends."""
    if not user_id:
        return
    r = _get_redis()
    if not r:
        return
    try:
        r.delete(_KEY_LIVE.format(user_id=user_id))
    except Exception as e:
        logger.debug(f"[usage] reset_live_spend failed for {user_id}: {e}")


# ── Job end: persist to Redis + R2 ───────────────────────────────────────────

def record_job_end(
    user_id: str,
    billing_seconds: float,
    rate_per_hr: float,
    estimated_cost_usd: float,
) -> None:
    """Finalize usage counters when a job terminates and persist to R2.

    Increments the monthly job count and persists a JSON summary to R2 at
    billing/{user_id}/{YYYY-MM}.json for audit and billing purposes.
    """
    if not user_id:
        return

    r = _get_redis()
    month = _month()

    if r:
        try:
            pipe = r.pipeline()
            pipe.incr(_KEY_JOBS.format(user_id=user_id, month=month))
            # Ensure GPU-hours and USD are in sync (in case tick missed some intervals)
            gpu_hours = billing_seconds / 3600.0
            pipe.incrbyfloat(_KEY_HOURS.format(user_id=user_id, month=month), 0)  # read
            pipe.incrbyfloat(_KEY_USD.format(user_id=user_id, month=month), 0)    # read
            results = pipe.execute()
            total_jobs = int(results[0])
            total_hours = float(results[1])
            total_usd = float(results[2])
        except Exception as e:
            logger.debug(f"[usage] record_job_end Redis failed for {user_id}: {e}")
            total_jobs = 1
            total_hours = billing_seconds / 3600.0
            total_usd = estimated_cost_usd
    else:
        total_jobs = 1
        total_hours = billing_seconds / 3600.0
        total_usd = estimated_cost_usd

    reset_live_spend(user_id)
    _persist_to_r2(user_id, month, total_hours, total_usd, total_jobs)


def _persist_to_r2(
    user_id: str,
    month: str,
    total_gpu_hours: float,
    total_usd: float,
    total_jobs: int,
) -> None:
    """Write monthly usage summary to R2 at billing/{user_id}/{month}.json."""
    try:
        import boto3, botocore
        r2_account  = os.environ.get("CLOUDFLARE_ACCOUNT_ID", "")
        r2_bucket   = os.environ.get("R2_BUCKET_NAME", "vaultlayer-checkpoints")
        r2_key_id   = os.environ.get("R2_ACCESS_KEY_ID", "")
        r2_secret   = os.environ.get("R2_SECRET_ACCESS_KEY", "")
        if not (r2_account and r2_key_id and r2_secret):
            return

        s3 = boto3.client(
            "s3",
            endpoint_url=f"https://{r2_account}.r2.cloudflarestorage.com",
            aws_access_key_id=r2_key_id,
            aws_secret_access_key=r2_secret,
            config=botocore.config.Config(signature_version="s3v4"),
        )
        r2_path = f"billing/{user_id}/{month}.json"
        payload = json.dumps({
            "user_id":        user_id,
            "month":          month,
            "gpu_hours":      round(total_gpu_hours, 4),
            "total_usd":      round(total_usd, 4),
            "total_jobs":     total_jobs,
            "updated_at":     datetime.now(timezone.utc).isoformat(),
        }, indent=2)
        s3.put_object(
            Bucket=r2_bucket,
            Key=r2_path,
            Body=payload.encode(),
            ContentType="application/json",
        )
        logger.info(f"[usage] R2 billing record updated: {r2_path}")
    except Exception as e:
        logger.debug(f"[usage] R2 persist failed for {user_id}/{month}: {e}")


# ── Read helpers ──────────────────────────────────────────────────────────────

def get_monthly_usage(user_id: str, month: Optional[str] = None) -> dict:
    """Return current month's usage summary for a user.

    Returns:
        {gpu_hours, total_usd, total_jobs, live_spend_usd, month}
    """
    month = month or _month()
    r = _get_redis()
    result = {
        "user_id":       user_id,
        "month":         month,
        "gpu_hours":     0.0,
        "total_usd":     0.0,
        "total_jobs":    0,
        "live_spend_usd": 0.0,
    }
    if not r or not user_id:
        return result
    try:
        pipe = r.pipeline()
        pipe.get(_KEY_HOURS.format(user_id=user_id, month=month))
        pipe.get(_KEY_USD.format(user_id=user_id, month=month))
        pipe.get(_KEY_JOBS.format(user_id=user_id, month=month))
        pipe.get(_KEY_LIVE.format(user_id=user_id))
        vals = pipe.execute()
        result["gpu_hours"]      = round(float(vals[0] or 0), 4)
        result["total_usd"]      = round(float(vals[1] or 0), 4)
        result["total_jobs"]     = int(vals[2] or 0)
        result["live_spend_usd"] = round(float(vals[3] or 0), 4)
    except Exception as e:
        logger.debug(f"[usage] get_monthly_usage failed for {user_id}: {e}")
    return result
