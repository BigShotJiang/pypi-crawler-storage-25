"""
VaultLayer — Recovery Hierarchy Tiers

When an interruption occurs (spot reclamation, heartbeat miss, GPU failure),
VaultLayer follows this strict priority to minimise downtime and egress costs.

Each tier represents a progressively wider search for replacement capacity.
The tier number is logged in OrchestrationDecision metadata so the dashboard
and Job Manifest can show exactly which recovery strategy was used per hop.

See also: src/agents/orchestration/egress.py rank_candidates_by_resume_cost()
"""
from __future__ import annotations

from enum import IntEnum


class RecoveryTier(IntEnum):
    """Recovery strategy priority — lower number = preferred."""

    # Tier 1: Exact same GPU, same provider, same region (different AZ).
    # Zero egress, near-instant resume, reuses VPC/endpoint.
    SAME_GPU_SAME_PROVIDER_SAME_REGION = 1

    # Tier 2: Exact same GPU, same provider, different region.
    # Minor egress (intra-provider), consistent performance.
    SAME_GPU_SAME_PROVIDER_CROSS_REGION = 2

    # Tier 3: Exact same GPU, different provider.
    # Cross-cloud egress, but proves VaultLayer's "Scarce Silicon" value.
    SAME_GPU_CROSS_PROVIDER = 3

    # Tier 4: Next best GPU, same provider.
    # Training continues at reduced speed. Back-Hop Watchdog starts.
    NEXT_BEST_GPU_SAME_PROVIDER = 4

    # Tier 5: Next best GPU, different provider.
    # Final safety net — ensures zero downtime SLA.
    NEXT_BEST_GPU_CROSS_PROVIDER = 5


# Human-readable labels for dashboard / Job Manifest
RECOVERY_TIER_LABELS: dict[RecoveryTier, str] = {
    RecoveryTier.SAME_GPU_SAME_PROVIDER_SAME_REGION:  "Same GPU / Same Provider / Same Region",
    RecoveryTier.SAME_GPU_SAME_PROVIDER_CROSS_REGION: "Same GPU / Same Provider / Cross-Region",
    RecoveryTier.SAME_GPU_CROSS_PROVIDER:             "Same GPU / Cross-Provider",
    RecoveryTier.NEXT_BEST_GPU_SAME_PROVIDER:         "Next Best GPU / Same Provider",
    RecoveryTier.NEXT_BEST_GPU_CROSS_PROVIDER:        "Next Best GPU / Cross-Provider",
}


def classify_recovery_tier(
    *,
    source_provider: str,
    target_provider: str,
    source_gpu: str,
    target_gpu: str,
    same_region: bool,
) -> RecoveryTier:
    """
    Classify a candidate migration into the recovery hierarchy.

    Args:
        source_provider: Provider the job is currently running on.
        target_provider: Candidate provider for the replacement node.
        source_gpu:      GPU type the job was running on.
        target_gpu:      GPU type being offered by the candidate.
        same_region:     True if candidate is in the same region as source.
    """
    same_provider = source_provider == target_provider
    same_gpu = source_gpu == target_gpu

    if same_gpu and same_provider and same_region:
        return RecoveryTier.SAME_GPU_SAME_PROVIDER_SAME_REGION
    if same_gpu and same_provider:
        return RecoveryTier.SAME_GPU_SAME_PROVIDER_CROSS_REGION
    if same_gpu:
        return RecoveryTier.SAME_GPU_CROSS_PROVIDER
    if same_provider:
        return RecoveryTier.NEXT_BEST_GPU_SAME_PROVIDER
    return RecoveryTier.NEXT_BEST_GPU_CROSS_PROVIDER
