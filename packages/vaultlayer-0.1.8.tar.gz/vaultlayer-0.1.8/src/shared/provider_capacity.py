"""
VaultLayer -- Provider Capacity Guard

Tracks concurrent active jobs per provider using Redis atomic counters.
Providers with a max_concurrent_jobs limit (e.g. Voltage Park) are excluded
from recommendations when their threshold is reached, and re-admitted
automatically when jobs finish and slots free up.

This is the v1 solution using Redis atomic counters (INCR/DECR + SET NX) for
correctness across multiple Broker processes (horizontal scaling).

Falls back to in-process counters when Redis is not configured (local dev /
single-process deployments).  The interface is identical either way.

Configuration (via vaultlayer_data.json provider_meta):
  max_concurrent_jobs: int   -- max jobs VaultLayer will route to this provider
                                at the same time. null = unlimited.
  requires_operator_account: bool -- operator must configure API key in .env

Environment overrides:
  VL_VOLTAGE_PARK_MAX_JOBS=50   -- override threshold at runtime without JSON edit
  VL_PROVIDER_MAX_JOBS_DEFAULT=200  -- default threshold for unconfigured providers
  UPSTASH_REDIS_URL              -- Redis connection; falls back to in-memory if unset
"""

_UNSLOTTED_PROVIDERS = {
    "aws", "amazon", "amazon web services",
    "aws on-demand", "aws reserved", "aws spot",
}

import os
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# ── Default thresholds ─────────────────────────────────────────────────────────
_DEFAULT_MAX_JOBS = int(os.environ.get("VL_PROVIDER_MAX_JOBS_DEFAULT", "200"))

_ENV_OVERRIDES = {
    "Voltage Park": int(os.environ.get("VL_VOLTAGE_PARK_MAX_JOBS", "50")),
    "CoreWeave":    int(os.environ.get("VL_COREWEAVE_MAX_JOBS",    str(_DEFAULT_MAX_JOBS))),
    "Nebius (EU)":  int(os.environ.get("VL_NEBIUS_MAX_JOBS",       str(_DEFAULT_MAX_JOBS))),
}

# ── Redis key scheme ───────────────────────────────────────────────────────────
# vaultlayer:capacity:{provider}:count   — INCR/DECR atomic counter (int)
# vaultlayer:capacity:job:{job_id}       — which provider a job occupies (string)
#
# Both keys have no TTL; they are managed explicitly by claim/release.
# In the unlikely event of a crash mid-INCR without a matching DECR, a manual
# `redis-cli del` on the counter key is sufficient to reset.  Counts cannot
# go below 0 because release_provider_slot uses MAX(0, count-1) logic.

_REDIS_KEY_COUNT   = "vaultlayer:capacity:{provider}:count"
_REDIS_KEY_JOB     = "vaultlayer:capacity:job:{job_id}"

# ── In-process fallback (single-process deployments / local dev) ───────────────
_active_counts: dict = {}
_active_jobs:   dict = {}   # job_id -> provider


# ── Redis connection (lazy, optional) ─────────────────────────────────────────

def _get_redis():
    """Return a synchronous Redis client or None if not configured."""
    url = os.environ.get("UPSTASH_REDIS_URL") or os.environ.get("REDIS_URL", "")
    if not url:
        return None
    try:
        import redis as _redis
        client = _redis.from_url(url, decode_responses=True, socket_timeout=2)
        client.ping()   # verify connection is live
        return client
    except Exception as e:
        logger.debug(f"[capacity] Redis unavailable, using in-process counter: {e}")
        return None


# ── Provider name normalisation ───────────────────────────────────────────────
_ENUM_TO_META_KEY = {
    "aws":           None,
    "lambda_labs":   "Lambda Labs",
    "coreweave":     "CoreWeave",
    "runpod":        "RunPod",
    "vast_ai":       "Vast.ai",
    "voltage_park":  "Voltage Park",
    "crusoe":        "Crusoe",
    "nebius":        "Nebius (EU)",
    "hyperstack":    "Hyperstack",
    "gcp":           "GCP",
    "azure":         "Azure",
}

def canonical_provider_name(raw: str) -> str:
    """Convert any provider string to the canonical key used in provider_meta.
    Returns empty string for unslotted providers (AWS).
    """
    if not raw:
        return ""
    low = raw.lower().strip()
    if low in _UNSLOTTED_PROVIDERS or low.startswith("aws") or low.startswith("amazon"):
        return ""
    normalised = low.replace("-", "_").replace(" ", "_")
    for enum_val, meta_key in _ENUM_TO_META_KEY.items():
        if normalised == enum_val or (meta_key and low == meta_key.lower()):
            return meta_key or ""
    return raw.strip().title()


def get_max_jobs(provider: str) -> int:
    """Return the concurrent job limit for this provider. Returns 0 for unslotted (AWS)."""
    key = canonical_provider_name(provider)
    if not key:
        return 0
    try:
        from shared.data_loader import get_provider_meta
        meta = get_provider_meta()
        configured = meta.get(key, {}).get("max_concurrent_jobs")
        if configured is not None:
            return int(configured)
    except Exception:
        pass
    return _ENV_OVERRIDES.get(key, _DEFAULT_MAX_JOBS)


# ── Redis-backed counter operations ───────────────────────────────────────────

def _redis_get_count(r, provider: str) -> int:
    try:
        val = r.get(_REDIS_KEY_COUNT.format(provider=provider))
        return int(val) if val is not None else 0
    except Exception:
        return 0


def _redis_incr(r, provider: str) -> int:
    """Atomically increment counter; returns new value."""
    try:
        return int(r.incr(_REDIS_KEY_COUNT.format(provider=provider)))
    except Exception as e:
        logger.warning(f"[capacity] Redis INCR failed for {provider}: {e}")
        return 0


def _redis_decr(r, provider: str) -> int:
    """Atomically decrement counter, floor at 0. Returns new value."""
    key = _REDIS_KEY_COUNT.format(provider=provider)
    try:
        # Lua script: atomically decrement but floor at 0
        script = """
        local v = tonumber(redis.call('GET', KEYS[1])) or 0
        if v > 0 then
            return redis.call('DECRBY', KEYS[1], 1)
        else
            return 0
        end
        """
        result = r.eval(script, 1, key)
        return int(result)
    except Exception as e:
        logger.warning(f"[capacity] Redis DECR failed for {provider}: {e}")
        return 0


def _redis_set_job(r, job_id: str, provider: str) -> None:
    try:
        r.set(_REDIS_KEY_JOB.format(job_id=job_id), provider)
    except Exception as e:
        logger.warning(f"[capacity] Redis SET job failed for {job_id}: {e}")


def _redis_get_job(r, job_id: str) -> Optional[str]:
    try:
        return r.get(_REDIS_KEY_JOB.format(job_id=job_id))
    except Exception:
        return None


def _redis_del_job(r, job_id: str) -> None:
    try:
        r.delete(_REDIS_KEY_JOB.format(job_id=job_id))
    except Exception as e:
        logger.warning(f"[capacity] Redis DEL job failed for {job_id}: {e}")


# ── Public API ─────────────────────────────────────────────────────────────────

def get_active_count(provider: str) -> int:
    """Return number of currently active jobs on this provider."""
    key = canonical_provider_name(provider)
    if not key:
        return 0
    r = _get_redis()
    if r:
        return _redis_get_count(r, key)
    return _active_counts.get(key, 0)


def is_provider_at_capacity(provider: str) -> bool:
    """Return True if provider has reached its concurrent job threshold."""
    provider = canonical_provider_name(provider)
    if not provider:
        return False
    active = get_active_count(provider)
    limit  = get_max_jobs(provider)
    if limit > 0 and active >= limit:
        logger.info(
            f"Provider {provider} at capacity: {active}/{limit} concurrent jobs."
        )
        return True
    return False


def claim_provider_slot(provider: str, job_id: str) -> bool:
    """Reserve a slot on this provider for job_id.

    Returns False if provider is at capacity (caller should pick a different provider).
    Returns True and increments counter if slot claimed.
    Idempotent: safe to call twice for the same job_id.
    """
    provider = canonical_provider_name(provider)
    if not provider:
        return True  # AWS or unslotted — no tracking

    r = _get_redis()

    # Idempotent: release old slot if job already tracked on a different provider
    if r:
        old_provider = _redis_get_job(r, job_id)
    else:
        old_provider = _active_jobs.get(job_id)

    if old_provider:
        if old_provider == provider:
            return True  # already claimed on this provider — no-op
        release_provider_slot(job_id)  # moving to different provider

    if is_provider_at_capacity(provider):
        return False

    if r:
        _redis_incr(r, provider)
        _redis_set_job(r, job_id, provider)
        count = _redis_get_count(r, provider)
    else:
        _active_counts[provider] = _active_counts.get(provider, 0) + 1
        _active_jobs[job_id] = provider
        count = _active_counts[provider]

    logger.debug(f"Slot claimed: {provider} now has {count} active jobs")
    return True


def release_provider_slot(job_id: str) -> Optional[str]:
    """Release the slot held by job_id.

    Called on job completion, failure, or migration away from this provider.
    Returns the provider name if a slot was released, None if job_id was unknown.
    """
    r = _get_redis()

    if r:
        provider = _redis_get_job(r, job_id)
        if provider is None:
            logger.debug(f"release_provider_slot: job {job_id} not tracked (Redis)")
            return None
        _redis_del_job(r, job_id)
        new_count = _redis_decr(r, provider)
    else:
        provider = _active_jobs.pop(job_id, None)
        if provider is None:
            logger.debug(f"release_provider_slot: job {job_id} not tracked")
            return None
        _active_counts[provider] = max(0, _active_counts.get(provider, 0) - 1)
        new_count = _active_counts[provider]

    logger.debug(f"Slot released: {provider} now has {new_count} active jobs")
    return provider


def acquire_provision_lock(job_id: str, ttl_seconds: int = 300) -> bool:
    """Acquire a distributed provision lock for job_id using Redis SETNX.

    Returns True if the lock was acquired (safe to provision).
    Returns False if the lock is already held — another process is already
    provisioning this job_id (crash-restart double-provision scenario).

    TTL of 5 minutes (default) auto-expires the lock if the process crashes
    before calling release_provision_lock(), preventing permanent lockout.

    Falls back to True (allow) when Redis is not configured.
    """
    r = _get_redis()
    if r is None:
        return True  # no Redis — single-process mode, asyncio lock is sufficient
    try:
        acquired = r.set(f"vaultlayer:provlock:{job_id}", "1", nx=True, ex=ttl_seconds)
        return bool(acquired)
    except Exception as e:
        logger.warning(f"[capacity] acquire_provision_lock Redis error for {job_id}: {e}")
        return True  # fail open — don't block provisioning on Redis error


def release_provision_lock(job_id: str) -> None:
    """Release the provision lock for job_id.

    Safe to call even if the lock was never acquired or already expired.
    """
    r = _get_redis()
    if r is None:
        return
    try:
        r.delete(f"vaultlayer:provlock:{job_id}")
    except Exception as e:
        logger.warning(f"[capacity] release_provision_lock Redis error for {job_id}: {e}")


def get_capacity_status() -> dict:
    """Return a summary of all tracked providers and their current usage."""
    try:
        from shared.data_loader import get_provider_meta
        meta = get_provider_meta()
    except Exception:
        meta = {}

    r = _get_redis()

    # Collect all known provider keys
    if r:
        try:
            pattern = "vaultlayer:capacity:*:count"
            redis_keys = r.keys(pattern)
            redis_providers = {
                k.replace("vaultlayer:capacity:", "").replace(":count", "")
                for k in redis_keys
            }
        except Exception:
            redis_providers = set()
        all_providers = set(list(meta.keys())) | redis_providers
    else:
        all_providers = set(list(meta.keys()) + list(_active_counts.keys()))

    result = {}
    for p in all_providers:
        if p.startswith("_"):
            continue
        active = get_active_count(p)
        limit  = get_max_jobs(p)
        result[p] = {
            "active_jobs":      active,
            "max_jobs":         limit,
            "at_capacity":      limit > 0 and active >= limit,
            "available_slots":  max(0, limit - active) if limit > 0 else 999,
            "backend":          "redis" if r else "in_process",
        }
    return result
