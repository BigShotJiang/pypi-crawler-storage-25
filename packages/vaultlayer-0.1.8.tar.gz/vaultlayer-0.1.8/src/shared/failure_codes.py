"""Standardized job-failure taxonomy for the Job Lifecycle Gate framework.

Every job that fails should end with one of these codes in `job.failure_code`,
plus a free-form `job.failure_detail` with specifics.

Replaces the historical pattern of free-form `job.error` strings, which
made dashboard aggregation impossible and turned every new failure mode
into an ad-hoc debug session. Old `job.error` is still populated for
back-compat; new `failure_code` is the canonical signal.

Codes group by lifecycle stage (PRE_ / PROV_ / BOOT_ / RUN_) so retry,
migration, and alerting logic can route by prefix.
"""
from __future__ import annotations

from enum import Enum


class JobFailureCode(str, Enum):
    # Stage 1 — Pre-submit gate (client / API gateway)
    PRE_SCRIPT_SYNTAX         = "pre_script_syntax"
    PRE_GPU_UNSUPPORTED       = "pre_gpu_unsupported"
    PRE_NO_CREDITS            = "pre_no_credits"
    PRE_IMAGE_UNPULLABLE      = "pre_image_unpullable"
    PRE_REGION_UNSATISFIABLE  = "pre_region_unsatisfiable"

    # Stage 2 — Pre-provision gate (after queue pop, before provider API)
    PROV_AUTH_BAD             = "prov_auth_bad"
    PROV_QUOTA_EXCEEDED       = "prov_quota_exceeded"
    PROV_STORAGE_DOWN         = "prov_storage_down"
    PROV_SCRIPT_UPLOAD_FAILED = "prov_script_upload_failed"
    PROV_NO_CAPACITY          = "prov_no_capacity"
    PROV_SCHEMA_REJECT        = "prov_schema_reject"
    PROV_MANAGED_BALANCE      = "prov_managed_balance"  # VaultLayer's managed provider account has $0

    # Stage 3 — Post-boot gate (on GPU node, before user script)
    BOOT_GPU_MISSING          = "boot_gpu_missing"
    BOOT_CUDA_MISMATCH        = "boot_cuda_mismatch"
    BOOT_IMPORT_FAIL          = "boot_import_fail"
    BOOT_R2_UNWRITABLE        = "boot_r2_unwritable"
    BOOT_DISK_FULL            = "boot_disk_full"
    BOOT_HEARTBEAT_SILENT     = "boot_heartbeat_silent"

    # Stage 4 — Runtime
    RUN_HEARTBEAT_LOST        = "run_heartbeat_lost"
    RUN_OOM                   = "run_oom"
    RUN_CHECKPOINT_WRITE_FAIL = "run_checkpoint_write_fail"
    RUN_EXITED_NONZERO        = "run_exited_nonzero"

    # Catch-all for unclassified failures. Every UNKNOWN over time should
    # motivate a new specific code — don't leave a bug filed just under here.
    UNKNOWN                   = "unknown"


# Stage-prefix groupings for retry / routing logic without string-matching.
PRE_CODES  = {c for c in JobFailureCode if c.value.startswith("pre_")}
PROV_CODES = {c for c in JobFailureCode if c.value.startswith("prov_")}
BOOT_CODES = {c for c in JobFailureCode if c.value.startswith("boot_")}
RUN_CODES  = {c for c in JobFailureCode if c.value.startswith("run_")}


def is_retryable(code: JobFailureCode) -> bool:
    """Should the broker attempt a retry (same or different provider)?

    Retryable: capacity/quota, transient storage, heartbeat-lost (migration).
    Not retryable: bad user input (script syntax, unsupported GPU), terminal
    user-side errors (OOM on the largest GPU, disk full).
    """
    retryable = {
        JobFailureCode.PROV_NO_CAPACITY,
        JobFailureCode.PROV_QUOTA_EXCEEDED,
        JobFailureCode.PROV_STORAGE_DOWN,
        JobFailureCode.PROV_SCRIPT_UPLOAD_FAILED,
        JobFailureCode.RUN_HEARTBEAT_LOST,
    }
    return code in retryable


def prefers_different_provider(code: JobFailureCode) -> bool:
    """When retrying, should we avoid the same provider?

    Yes for schema-rejects (provider doesn't support this GPU), auth-bad
    (our key is broken for this provider), quota-exceeded (we're out on
    this one). No for no-capacity — a retry on the same provider minutes
    later may succeed as the spot pool fluctuates.
    """
    return code in {
        JobFailureCode.PROV_AUTH_BAD,
        JobFailureCode.PROV_QUOTA_EXCEEDED,
        JobFailureCode.PROV_SCHEMA_REJECT,
        JobFailureCode.PROV_MANAGED_BALANCE,
        JobFailureCode.PRE_GPU_UNSUPPORTED,
    }
