"""
VaultLayer — Job Manifest Generator

Wraps the existing invoice builder with additional metadata to produce a
complete audit-ready manifest for each job. Used by:
  - `vaultlayer download` (saved as manifest.json alongside checkpoints)
  - Dashboard job detail page
  - FinOps reconciliation pipeline

The manifest includes everything from the invoice PLUS:
  - Human-readable total runtime string
  - Hop log with timestamps and reasons (from job_events table)
  - Net credit deduction
  - Recovery tier used per hop
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)


def _format_runtime(total_seconds: float) -> str:
    """Convert seconds to 'X hours, Y minutes, Z seconds' string."""
    hours = int(total_seconds // 3600)
    minutes = int((total_seconds % 3600) // 60)
    seconds = int(total_seconds % 60)
    parts = []
    if hours:
        parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
    if minutes:
        parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
    parts.append(f"{seconds} second{'s' if seconds != 1 else ''}")
    return ", ".join(parts)


def _fetch_hop_log(job_id: str) -> list[dict]:
    """Fetch migration events from job_events table for the hop log."""
    try:
        from api.db import get_db, _db_call
        db = get_db()
        result = _db_call(
            lambda: db.table("job_events")
                .select("event_type, message, metadata, created_at")
                .eq("job_id", job_id)
                .in_("event_type", [
                    "migration_started", "migration_complete",
                    "interruption_detected", "checkpoint_saved",
                    "checkpoint_restored",
                ])
                .order("created_at")
                .execute(),
            label="manifest:fetch_hop_log",
        )
        return result.data or []
    except Exception as e:
        logger.debug(f"[manifest] Could not fetch hop log for {job_id}: {e}")
        return []


def generate_manifest(
    job_id: str,
    user_id: str,
    invoice: Optional[dict] = None,
) -> dict:
    """
    Generate a Job Manifest combining invoice data with hop log and runtime summary.

    If invoice is not provided, calls create_invoice() to build it.
    """
    if invoice is None:
        from shared.invoice import create_invoice
        invoice = create_invoice(job_id, user_id)
        if not invoice:
            return {"error": f"Could not generate invoice for job {job_id}"}

    total_seconds = invoice.get("total_billing_seconds", 0)
    hop_log = _fetch_hop_log(job_id)

    # Determine effective compute tier label
    legs = invoice.get("compute", {}).get("legs", [])
    tier_labels = sorted(set(
        leg.get("compute_tier_label", "") for leg in legs if leg.get("compute_tier_label")
    ))
    compute_tier_display = ", ".join(tier_labels) if tier_labels else invoice.get("compute_tier_label", "")

    # Calculate net credit deduction
    total_cost = invoice.get("total_cost_usd", 0.0)
    net_credits = int(total_cost * 100)  # 100 credits = $1

    return {
        "manifest_version": "1.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        # Job identity
        "job_id": job_id,
        "user_id": user_id,
        "job_name": invoice.get("job_name", job_id),
        # Runtime summary
        "total_runtime": _format_runtime(total_seconds),
        "total_billing_seconds": round(total_seconds, 1),
        "job_started_at": invoice.get("job_started_at", ""),
        "job_completed_at": invoice.get("job_completed_at", ""),
        # Billing
        "billing_model": invoice.get("billing_model", ""),
        "compute_tier": compute_tier_display,
        "total_provider_cost_usd": invoice.get("compute", {}).get("total_provider_cost_usd", 0.0),
        "total_orchestration_fee_usd": invoice.get("compute", {}).get("total_orchestration_fee", 0.0),
        "total_compute_cost_usd": invoice.get("compute", {}).get("total_billed_usd", 0.0),
        "storage_cost_usd": invoice.get("storage", {}).get("cost_usd", 0.0),
        "total_cost_usd": total_cost,
        "net_credit_deduction": net_credits,
        # AWS comparison
        "aws_od_equivalent_usd": invoice.get("compute", {}).get("aws_od_equivalent_usd", 0.0),
        "savings_usd": invoice.get("savings_usd", 0.0),
        "savings_pct": invoice.get("savings_pct", 0.0),
        # Compute legs (from invoice)
        "legs": legs,
        "migrations": invoice.get("compute", {}).get("migrations", []),
        "leg_count": invoice.get("leg_count", 0),
        # Hop log (from job_events)
        "hop_log": hop_log,
        # Framing
        "summary": invoice.get("framing", ""),
    }
