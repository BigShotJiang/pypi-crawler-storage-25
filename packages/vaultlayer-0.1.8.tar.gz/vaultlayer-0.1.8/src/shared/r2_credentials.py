"""
VaultLayer — Job-Scoped R2 Temporary Credentials

Generates short-lived, prefix-scoped Cloudflare R2 credentials for each job.
Master API keys NEVER leave VaultLayer's secure Broker infrastructure.
GPU nodes receive only a token that is cryptographically restricted to:

    jobs/{job_id}/

Any attempt by a compromised node to access jobs/{other_job_id}/ or list the
bucket root returns a 403 Forbidden from the Cloudflare R2 edge — no VaultLayer
code is involved in the rejection.

API Reference:
    POST /accounts/{account_id}/r2/temp-credentials
    https://developers.cloudflare.com/r2/api/s3/tokens/#create-temporary-credentials
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Optional

import requests

logger = logging.getLogger(__name__)

# Cloudflare R2 maximum TTL for temporary credentials
R2_MAX_TTL_SECONDS = 4 * 3600          # 4 hours (CF hard limit)
# Default TTL — 2 hours, giving plenty of headroom for long checkpoints
R2_DEFAULT_TTL_SECONDS = 2 * 3600
# Proactive refresh margin: re-mint credentials this many seconds before expiry
R2_REFRESH_MARGIN_SECONDS = 15 * 60    # 15 minutes


@dataclass
class ScopedCredentials:
    """
    Short-lived R2 credentials scoped to a single job prefix.
    Compatible with the AWS S3 STS credential format so rclone / boto3 / AWS
    SDKs accept them without modification (just set session_token alongside
    the access_key_id and secret_access_key).
    """
    access_key_id: str
    secret_access_key: str
    session_token: str
    job_id: str
    prefix: str                   # e.g. "jobs/abc123/"
    expires_at: float             # Unix timestamp (UTC)

    @property
    def is_expired(self) -> bool:
        return time.time() >= self.expires_at

    @property
    def needs_refresh(self) -> bool:
        """True when within R2_REFRESH_MARGIN_SECONDS of expiry."""
        return time.time() >= (self.expires_at - R2_REFRESH_MARGIN_SECONDS)

    def to_env_dict(self) -> dict[str, str]:
        """
        Return a dict suitable for injecting into a subprocess environment or
        a UserData script.  These are the canonical AWS STS env var names —
        rclone, boto3, and the AWS CLI all recognise them automatically.
        """
        return {
            "AWS_ACCESS_KEY_ID":     self.access_key_id,
            "AWS_SECRET_ACCESS_KEY": self.secret_access_key,
            "AWS_SESSION_TOKEN":     self.session_token,
            "VAULTLAYER_R2_PREFIX":  self.prefix,
            "VAULTLAYER_JOB_ID":     self.job_id,
        }

    def to_rclone_config(self, endpoint: str) -> str:
        """
        Produce an rclone `[r2]` stanza using scoped credentials + session_token.
        The session_token line is required — without it, Cloudflare R2 rejects
        STS-style credentials (it looks for the X-Amz-Security-Token header).
        """
        return (
            "[r2]\n"
            "type = s3\n"
            "provider = Cloudflare\n"
            f"access_key_id = {self.access_key_id}\n"
            f"secret_access_key = {self.secret_access_key}\n"
            f"session_token = {self.session_token}\n"
            f"endpoint = {endpoint}\n"
        )


class R2CredentialsMinter:
    """
    Calls the Cloudflare API to mint job-scoped temporary R2 credentials.

    Instantiated once per Broker Agent process.  Master credentials are held
    only here, in VaultLayer's secure infrastructure — they never appear in
    UserData scripts, environment variables on GPU nodes, or log files.

    Usage:
        minter = R2CredentialsMinter.from_config(config.cloudflare)
        creds = await minter.mint(job_id="abc123", ttl_seconds=7200)
        # Inject creds.to_rclone_config() into the GPU node UserData
    """

    CF_TEMP_CREDS_URL = (
        "https://api.cloudflare.com/client/v4/accounts/{account_id}/r2/temp-credentials"
    )

    def __init__(
        self,
        account_id: str,
        master_token: str,
        parent_access_key_id: str,
        bucket: str,
        r2_endpoint: str,
    ):
        self._account_id = account_id
        self._master_token = master_token
        self._parent_access_key_id = parent_access_key_id
        self._bucket = bucket
        self._r2_endpoint = r2_endpoint
        self._cache: dict[str, ScopedCredentials] = {}

    @classmethod
    def from_config(cls, cf_config) -> "R2CredentialsMinter":
        """Construct from a CloudflareConfig dataclass."""
        return cls(
            account_id=cf_config.account_id,
            master_token=cf_config.cf_master_token,
            parent_access_key_id=cf_config.r2_access_key_id,
            bucket=cf_config.r2_bucket,
            r2_endpoint=cf_config.r2_endpoint,
        )

    def mint(
        self,
        job_id: str,
        ttl_seconds: int = R2_DEFAULT_TTL_SECONDS,
        permission: str = "objectReadWrite",
    ) -> ScopedCredentials:
        """
        Mint short-lived R2 credentials scoped exclusively to checkpoints/{job_id}/.

        The scoped prefix matches the actual data layout used by every
        read/write path in the codebase:
          - agents/broker/startup_scripts.py   (rclone push/pull)
          - agents/vault/r2.py                 (checkpoint uploader, list)
          - api/restart_routes.py              (checkpoint recovery)

        Previously the mint prefix was jobs/{job_id}/ while reads/writes
        used checkpoints/{job_id}/ — so if Cloudflare's bucket policy
        enforced the declared prefix, every checkpoint write would 403.
        It didn't 403 only because the broker silently falls back to
        master keys when scoped minting fails (see
        get_r2_credentials_for_node in startup_scripts.py). Unifying the
        prefix on checkpoints/{job_id}/ means the scope actually works.

        The credential is cached in-process and reused until it enters the
        refresh window (15 min before expiry), at which point a new token is
        minted transparently.

        Args:
            job_id:      VaultLayer job UUID — used as the prefix component.
            ttl_seconds: Lifetime for the token (max 4h per Cloudflare limits).
            permission:  "objectReadWrite" (default) or "objectRead" for
                         read-only nodes (e.g. inference replicas).

        Returns:
            ScopedCredentials — contains accessKeyId, secretAccessKey,
            sessionToken, and helpers for rclone config + env injection.

        Raises:
            RuntimeError: If the Cloudflare API returns an error response.
        """
        # Return cached token if still fresh
        cached = self._cache.get(job_id)
        if cached and not cached.needs_refresh:
            return cached

        ttl_seconds = min(ttl_seconds, R2_MAX_TTL_SECONDS)
        # Match the data layout in agents/vault/r2.py and startup_scripts.py
        prefix = f"checkpoints/{job_id}/"
        url = self.CF_TEMP_CREDS_URL.format(account_id=self._account_id)

        payload = {
            "bucket": self._bucket,
            "parent_access_key_id": self._parent_access_key_id,
            "permission": permission,
            "ttl_seconds": ttl_seconds,
            "prefixes": [prefix],           # ← cryptographic isolation
        }
        headers = {
            "Authorization": f"Bearer {self._master_token}",
            "Content-Type": "application/json",
        }

        logger.info(
            f"[R2Credentials] Minting scoped token for job={job_id} "
            f"prefix={prefix!r} ttl={ttl_seconds}s"
        )

        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=10)
            resp.raise_for_status()
        except requests.RequestException as e:
            raise RuntimeError(
                f"Cloudflare R2 temp-credentials API error for job {job_id}: {e}"
            ) from e

        body = resp.json()
        if not body.get("success"):
            errors = body.get("errors", [])
            raise RuntimeError(
                f"Cloudflare R2 temp-credentials API returned errors for job {job_id}: {errors}"
            )

        result = body["result"]
        creds = ScopedCredentials(
            access_key_id=result["accessKeyId"],
            secret_access_key=result["secretAccessKey"],
            session_token=result["sessionToken"],
            job_id=job_id,
            prefix=prefix,
            expires_at=time.time() + ttl_seconds,
        )
        self._cache[job_id] = creds
        logger.info(
            f"[R2Credentials] Token minted for job={job_id} "
            f"expires_in={ttl_seconds//60}m  access_key={creds.access_key_id[:8]}..."
        )
        return creds

    def revoke_cached(self, job_id: str) -> None:
        """
        Remove the cached credential for a job (called on job termination).
        The Cloudflare token itself expires at TTL — this just prevents reuse
        within the Broker process after the job ends.
        """
        self._cache.pop(job_id, None)
        logger.info(f"[R2Credentials] Cleared cached token for job={job_id}")

    def refresh_if_needed(self, job_id: str) -> Optional[ScopedCredentials]:
        """
        Return a fresh credential if the current one is within the refresh
        window.  Returns None if the cached credential is still healthy.
        Called by the Broker's heartbeat loop for long-running jobs.
        """
        cached = self._cache.get(job_id)
        if cached and cached.needs_refresh:
            logger.info(f"[R2Credentials] Proactively refreshing token for job={job_id}")
            return self.mint(job_id)
        return None
