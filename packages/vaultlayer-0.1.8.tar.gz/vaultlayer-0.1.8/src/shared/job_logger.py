"""
VaultLayer — job_logger.py

Writes structured job events and raw log lines to the database.

Dual-path architecture:
  - On Railway (SUPABASE_URL set): writes directly to Supabase (fast, no network hop)
  - On user's machine (no SUPABASE_URL): routes through Railway API (no DB creds needed)

Usage:
    from shared.job_logger import log_event, log_lines

    await log_event(job_id, user_id, "checkpoint_saved",
                    "Checkpoint saved at step 500",
                    metadata={"step": 500, "r2_key": "checkpoints/job_xyz/step-500/"})

    await log_lines(job_id, user_id, ["Epoch 1/10 loss=0.42", "..."], source="training")
"""
from __future__ import annotations

import logging
import os
import re as _re
from datetime import datetime, timezone
from typing import Any

# Matches "step 100", "step: 100", "Step 100", "global_step 100", etc.
_STEP_RE = _re.compile(r'\b(?:global_)?step[_\s:=]+(\d+)', _re.IGNORECASE)


def _parse_step_number(line: str) -> "int | None":
    """Extract training step number from a log line, or None if not found."""
    m = _STEP_RE.search(line)
    return int(m.group(1)) if m else None

logger = logging.getLogger(__name__)

_BULK_CHUNK = 200


def _has_direct_db() -> bool:
    """True if we can write to Supabase directly (running on Railway)."""
    return bool(os.environ.get("SUPABASE_URL"))


def _api_url() -> str:
    return os.environ.get("VAULTLAYER_API_URL",
                          "https://vaultlayer-production.up.railway.app").rstrip("/")


def _api_token() -> str:
    """Get the user's API token for authenticating with Railway API."""
    # Try env var first, then config file
    token = os.environ.get("VAULTLAYER_TOKEN", "")
    if not token:
        try:
            from pathlib import Path
            cfg = Path.home() / ".vaultlayer" / "config.env"
            if cfg.exists():
                for line in cfg.read_text().splitlines():
                    if line.startswith("VAULTLAYER_TOKEN="):
                        token = line.split("=", 1)[1].strip()
                        break
        except Exception:
            pass
    return token


def _db():
    """Get direct Supabase client (Railway-side only)."""
    if not _has_direct_db():
        return None
    try:
        from api.db import get_db
        return get_db()
    except Exception:
        return None


async def log_event(
    job_id: str,
    user_id: str,
    event_type: str,
    message: str,
    metadata: dict[str, Any] | None = None,
) -> None:
    """
    Insert a single structured event into job_events.
    Routes through API on user's machine, direct DB on Railway.
    Silently logs and returns on any error — never raises.
    """
    if _has_direct_db():
        # Direct path (Railway)
        try:
            db = _db()
            if db is None:
                return
            db.table("job_events").insert({
                "job_id":     job_id,
                "user_id":    user_id,
                "event_type": event_type,
                "message":    message,
                "metadata":   metadata or {},
                "created_at": datetime.now(timezone.utc).isoformat(),
            }).execute()
        except Exception as exc:
            logger.warning("[job_logger] log_event direct failed for job %s (%s): %s",
                           job_id, event_type, exc)
    else:
        # API path (user's machine)
        token = _api_token()
        if not token:
            return
        try:
            import httpx
            httpx.post(
                f"{_api_url()}/api/v1/jobs/{job_id}/events",
                headers={"Authorization": f"Bearer {token}"},
                json={"event_type": event_type, "message": message, "metadata": metadata or {}},
                timeout=8,
            )
        except Exception as exc:
            logger.warning("[job_logger] log_event API failed for job %s (%s): %s",
                           job_id, event_type, exc)


async def log_lines(
    job_id: str,
    user_id: str,
    lines: list[str],
    source: str = "training",
) -> None:
    """
    Bulk-insert raw log lines into job_logs.
    Routes through API on user's machine, direct DB on Railway.
    Silently logs and returns on any error — never raises.
    """
    if not lines:
        return

    clean_lines = [line for line in lines if line.strip()]
    if not clean_lines:
        return

    if _has_direct_db():
        # Direct path (Railway)
        now = datetime.now(timezone.utc).isoformat()
        rows = []
        for line in clean_lines:
            row: dict = {"job_id": job_id, "user_id": user_id,
                         "line": line, "source": source, "created_at": now}
            if source == "training":
                step = _parse_step_number(line)
                if step is not None:
                    row["step_number"] = step
            rows.append(row)
        try:
            db = _db()
            if db is None:
                return
            import asyncio as _asyncio
            loop = _asyncio.get_event_loop()
            def _upsert():
                for i in range(0, len(rows), _BULK_CHUNK):
                    # ignore_duplicates=True → ON CONFLICT (job_id, step_number) DO NOTHING
                    # Rows with step_number=None are never in conflict (NULLs don't match).
                    db.table("job_logs").upsert(
                        rows[i: i + _BULK_CHUNK],
                        on_conflict="job_id,step_number",
                        ignore_duplicates=True,
                    ).execute()
            await loop.run_in_executor(None, _upsert)
        except Exception as exc:
            logger.warning("[job_logger] log_lines direct failed for job %s: %s", job_id, exc)
    else:
        # API path (user's machine) — send in chunks
        token = _api_token()
        if not token:
            return
        try:
            import httpx
            for i in range(0, len(clean_lines), _BULK_CHUNK):
                chunk = clean_lines[i:i + _BULK_CHUNK]
                httpx.post(
                    f"{_api_url()}/api/v1/jobs/{job_id}/logs",
                    headers={"Authorization": f"Bearer {token}"},
                    json={"lines": chunk, "source": source},
                    timeout=10,
                )
        except Exception as exc:
            logger.warning("[job_logger] log_lines API failed for job %s: %s", job_id, exc)
