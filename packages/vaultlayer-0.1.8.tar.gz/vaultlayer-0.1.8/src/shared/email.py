"""Cancel-notification email.

Public entry point: send_cancel_email(). Called from:
  - src/api/job_routes.py:cancel_job — when the user-facing CLI cancels a job
    with reason=consent_timeout (15-min prompt expired) or reason=user_declined.
  - src/api/job_worker.py:_handle_provision_result — when a resume leg
    exhausts every routable provider (reason=resume_no_capacity).

Delivery path: when RESEND_API_KEY is set in env, send via Resend (same
provider that powers the existing welcome / verification / top-up / job-
suspended emails in src/api/email.py). When unset, fall back to log-only
(useful for local/dev where outbound email is undesirable). In BOTH paths we
also persist the rendered body to job_runs.metadata so the dashboard surfaces
the message even if delivery silently fails.
"""
from __future__ import annotations

import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)

DASHBOARD_URL = os.environ.get("DASHBOARD_URL", "https://vaultlayer.ai").rstrip("/")
FROM_ADDRESS  = os.environ.get("EMAIL_FROM", "VaultLayer <noreply@vaultlayer.ai>")


def _format_list(items: list[str]) -> str:
    """Render a list of provider/region names for the email body. Empty → 'any'."""
    return ", ".join(items) if items else "any"


def build_cancel_email_body(
    *,
    job_id: str,
    reason: str,
    preferred_providers: list[str],
    regions: list[str],
) -> tuple[str, str]:
    """Return (subject, plaintext_body) tuple matching the spec template.

    Pure function — exposed separately so tests can assert on the literal
    text and so callers can persist the body to job_runs.metadata before any
    delivery attempt. The HTML version used by Resend is built by
    _build_cancel_html() from this same data; keep them in lockstep.
    """
    subject = f"VaultLayer — job {job_id} cancelled (no capacity)"
    body = (
        f"Your job was cancelled because we couldn't find GPU capacity within:\n"
        f"  Providers: {_format_list(preferred_providers)}\n"
        f"  Regions:   {_format_list(regions)}\n"
        f"\n"
        f"Nothing was provisioned, no charge applied.\n"
        f"\n"
        f"To rerun with wider search:\n"
        f"  vaultlayer run --provider <list> --regions <wider list> ...\n"
        f"\n"
        f"See logs: {DASHBOARD_URL}/dashboard/jobs/{job_id}\n"
    )
    return subject, body


def _build_cancel_html(
    *,
    job_id: str,
    preferred_providers: list[str],
    regions: list[str],
) -> str:
    """HTML body for Resend — visual style mirrors src/api/email.py templates."""
    providers_str = _format_list(preferred_providers)
    regions_str   = _format_list(regions)
    return f"""
        <p>Your job <code>{job_id}</code> was cancelled because we couldn't
        find GPU capacity within your filter.</p>

        <table style="border-collapse:collapse;margin:16px 0;">
            <tr>
                <td style="padding:6px 16px 6px 0;color:#666;">Providers</td>
                <td style="padding:6px 0;"><strong>{providers_str}</strong></td>
            </tr>
            <tr>
                <td style="padding:6px 16px 6px 0;color:#666;">Regions</td>
                <td style="padding:6px 0;"><strong>{regions_str}</strong></td>
            </tr>
        </table>

        <p><strong>Nothing was provisioned, no charge applied.</strong></p>

        <p>To rerun with a wider search:</p>
        <pre style="background:#f4f4f4;padding:12px;border-radius:4px;">vaultlayer run --provider &lt;list&gt; --regions &lt;wider list&gt; ...</pre>

        <p>
            <a href="{DASHBOARD_URL}/dashboard/jobs/{job_id}"
               style="background:#6366f1;color:white;padding:10px 20px;
                      border-radius:6px;text-decoration:none;font-weight:bold;">
                View job details
            </a>
        </p>
    """


def _deliver_via_resend(*, to: str, subject: str, html: str) -> bool:
    """Best-effort send through Resend. Returns True iff the SDK call succeeded.

    Mirrors src/api/email.py:_send (sync `resend.Emails.send` wrapped in
    try/except + logging). We don't go through that helper because it's
    declared `async def` while every cancel-email caller here is sync —
    and the underlying Resend call is sync anyway, so wrapping it in a
    coroutine adds no value.
    """
    api_key = os.environ.get("RESEND_API_KEY", "")
    if not api_key:
        return False
    try:
        import resend
        resend.api_key = api_key
        resend.Emails.send({
            "from":    FROM_ADDRESS,
            "to":      [to],
            "subject": subject,
            "html":    html,
        })
        logger.info(f"[email] Sent '{subject}' to {to}")
        return True
    except Exception as e:
        logger.warning(f"[email] Resend send failed for '{subject}' to {to}: {e}")
        return False


def send_cancel_email(
    *,
    job_id: str,
    user_email: str,
    reason: str,
    preferred_providers: list[str],
    regions: list[str],
    run_id: Optional[str] = None,
) -> None:
    """Notify the user that their job was cancelled with no charge.

    Best-effort: never raises. Three side effects, in order:
      1. Persist the rendered body to job_runs.metadata (always, audit trail
         for the dashboard).
      2. Send via Resend if RESEND_API_KEY is set AND user_email is non-empty.
      3. If Resend was skipped or failed, log the body with a [TODO: send email]
         prefix so the message is recoverable from Railway logs.
    """
    subject, plaintext = build_cancel_email_body(
        job_id=job_id,
        reason=reason,
        preferred_providers=preferred_providers,
        regions=regions,
    )

    if run_id:
        try:
            from shared.job_run_logger import update_run
            update_run(
                run_id,
                metadata={
                    "cancel_email_subject": subject,
                    "cancel_email_body":    plaintext,
                    "cancel_reason":        reason,
                },
            )
        except Exception as e:
            logger.warning(f"[email] persist to job_runs failed: {e}")

    sent = False
    if user_email:
        html = _build_cancel_html(
            job_id=job_id,
            preferred_providers=preferred_providers,
            regions=regions,
        )
        sent = _deliver_via_resend(to=user_email, subject=subject, html=html)

    if not sent:
        # Either no email address, no RESEND_API_KEY, or Resend rejected the
        # send. Log the body so the message is recoverable from Railway logs.
        logger.warning(
            "[TODO: send email] to=%s subject=%s reason=%s\n%s",
            user_email or "<no-email>", subject, reason, plaintext,
        )
