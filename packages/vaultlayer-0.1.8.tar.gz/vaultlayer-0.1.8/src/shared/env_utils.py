"""Shared environment utilities."""
import os
from pathlib import Path

def load_vaultlayer_env():
    """Load env vars from ~/.vaultlayer/config.env and .env (if exists)."""
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    config_env = Path.home() / ".vaultlayer" / "config.env"
    if config_env.exists():
        load_dotenv(config_env)
    if Path(".env").exists():
        load_dotenv(".env")
