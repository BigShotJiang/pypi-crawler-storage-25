"""
VaultLayer Resume Hook — Generic state management
===================================================
RNG state save/restore, manifest reading, loss sanity checking,
emergency checkpoint signal handler, and auto-model discovery.

Extracted from _resume_hook.py to keep the main entry point focused on
framework detection and delegation.
"""
from __future__ import annotations

import json
import logging
import os
import pathlib

logger = logging.getLogger("vaultlayer.resume_hook")


# ---------------------------------------------------------------------------
# RNG state save / restore
# ---------------------------------------------------------------------------

def _snapshot_rng_state() -> dict:
    """Lightweight RNG snapshot for emergency checkpoint (no external deps beyond torch)."""
    rng: dict = {}
    try:
        import torch
        rng["torch"] = torch.get_rng_state()
        if torch.cuda.is_available():
            rng["torch_cuda"] = torch.cuda.get_rng_state_all()
    except Exception:
        pass
    try:
        import numpy as _np
        rng["numpy"] = _np.random.get_state()
    except Exception:
        pass
    try:
        import random as _r
        rng["python"] = _r.getstate()
    except Exception:
        pass
    return rng


def _restore_rng_from_ckpt(ckpt_file: pathlib.Path) -> None:
    """Restore RNG states from a VaultLayer checkpoint.pt (zero-code path).

    Must NOT use weights_only=True -- numpy/python RNG states are pickled objects.
    If the checkpoint was not saved with RNG state (pre-feature), this is a no-op.
    """
    try:
        import torch
        state = torch.load(ckpt_file, map_location="cpu")
    except Exception as e:
        logger.debug(f"[VaultLayer] Could not load checkpoint for RNG restore: {e}")
        return

    rng = state.get("rng") if isinstance(state, dict) else None
    if not rng:
        logger.debug("[VaultLayer] No RNG state in checkpoint -- skipping RNG restore")
        return

    try:
        if "torch" in rng:
            torch.set_rng_state(rng["torch"])
    except Exception as e:
        logger.warning(f"[VaultLayer] Failed to restore torch RNG state: {e}")
    try:
        if "torch_cuda" in rng and torch.cuda.is_available():
            torch.cuda.set_rng_state_all(rng["torch_cuda"])
    except Exception as e:
        logger.warning(f"[VaultLayer] Failed to restore CUDA RNG state: {e}")
    try:
        import numpy as _np
        if "numpy" in rng:
            _np.random.set_state(rng["numpy"])
    except Exception as e:
        logger.warning(f"[VaultLayer] Failed to restore numpy RNG state: {e}")
    try:
        import random as _random
        if "python" in rng:
            _random.setstate(rng["python"])
    except Exception as e:
        logger.warning(f"[VaultLayer] Failed to restore Python RNG state: {e}")
    logger.info("[VaultLayer] RNG states restored (torch / cuda / numpy / python)")


# ---------------------------------------------------------------------------
# Manifest / step restoration
# ---------------------------------------------------------------------------

def _restore_step_from_manifest(ckpt_dir: pathlib.Path) -> None:
    """Read the VaultLayer manifest and set VAULTLAYER_RESUME_STEP + VAULTLAYER_LAST_LOSS."""
    from vaultlayer._resume_torch import _patch_distributed_sampler, _patch_dataloader_skip

    for manifest_name in ("_MANIFEST.json", "manifest.json"):
        manifest = ckpt_dir / manifest_name
        if manifest.exists():
            try:
                data = json.loads(manifest.read_text())
                step = data.get("step") or data.get("global_step") or data.get("checkpoint_step")
                epoch = data.get("epoch") or data.get("checkpoint_epoch")
                if step is not None:
                    os.environ["VAULTLAYER_RESUME_STEP"] = str(step)
                    logger.info(f"[VaultLayer] Resume step: {step}")
                if epoch is not None:
                    os.environ["VAULTLAYER_RESUME_EPOCH"] = str(epoch)
                    logger.info(f"[VaultLayer] Resume epoch: {epoch}")
                    # Patch DistributedSampler to reproduce the correct epoch shuffle
                    _patch_distributed_sampler(int(epoch))
                # GAP-4: Patch DataLoader to skip already-seen within-epoch batches.
                # Use explicit batch_idx if the checkpoint recorded it; otherwise
                # fall back to 0 (epoch boundary -- no skip needed, just right shuffle).
                _batch_idx = data.get("batch_idx")
                _within_epoch_step = int(_batch_idx) if _batch_idx is not None else 0
                _patch_dataloader_skip(_within_epoch_step)
                # Crack-3: Store last known loss so check_loss() can validate it after resume
                loss = data.get("training_loss") or data.get("loss")
                if loss is not None:
                    os.environ["VAULTLAYER_LAST_LOSS"] = str(float(loss))
                    logger.info(f"[VaultLayer] Last recorded loss: {loss:.6f} -- "
                                "call vaultlayer.check_loss(loss) after first forward to validate")
            except Exception as e:
                logger.warning(f"[VaultLayer] Could not read manifest: {e}")
            return


# ---------------------------------------------------------------------------
# Auto-model discovery via gc heap walk
# ---------------------------------------------------------------------------

def _auto_find_model():
    """
    Walk the Python heap via gc.get_objects() to find the outermost nn.Module.

    Used by zero-code mode (VAULTLAYER_AUTO_CHECKPOINT=true) when the user has
    not called vaultlayer_checkpoint() explicitly.  Returns the Module with the
    most parameters -- heuristically this is the root model, not a sub-layer.

    Limitations (documented in User_Journey.md Zero-Code Caveats):
    - If multiple top-level models are live in the same process (e.g., generator +
      discriminator in a GAN), the larger one is selected.  Use explicit 3-line
      integration for multi-model training.
    - gc.get_objects() is O(all live objects) -- adds ~5ms on a 7B model.  Called
      only at checkpoint time (every N steps), never in the hot training loop.
    """
    try:
        import gc
        import torch.nn as nn
    except ImportError:
        return None

    # Collect all live nn.Module instances that are NOT sub-components of another
    # (i.e. not referenced as children of another Module in gc).
    all_modules = {id(obj): obj for obj in gc.get_objects() if isinstance(obj, nn.Module)}

    # Find modules that ARE referenced as children of other live modules
    child_ids: set[int] = set()
    for mod in all_modules.values():
        for child in mod.children():
            child_ids.add(id(child))

    root_candidates = [m for mid, m in all_modules.items() if mid not in child_ids]

    if not root_candidates:
        # Fall back: pick by parameter count
        root_candidates = list(all_modules.values())

    if not root_candidates:
        return None

    def _param_count(m):
        try:
            return sum(p.numel() for p in m.parameters())
        except Exception:
            return 0

    best = max(root_candidates, key=_param_count)
    logger.debug(f"[VaultLayer] gc heap walk found model: {type(best).__name__} "
                 f"({_param_count(best):,} params)")
    return best


# ---------------------------------------------------------------------------
# Loss sanity check (Crack-3)
# ---------------------------------------------------------------------------

def check_loss(current_loss: float, threshold_multiplier: float = 2.0) -> bool:
    """
    Crack-3: Hardware determinism sanity check.

    Call this once after the first loss computation on the resumed node:

        loss = criterion(outputs, labels)
        vaultlayer.check_loss(loss.item())

    Compares current_loss against VAULTLAYER_LAST_LOSS (injected from checkpoint
    manifest by the resume hook).  If the loss is more than threshold_multiplier
    times the last recorded value, the weights likely did not transfer cleanly --
    common causes:
      - cuDNN math mode differences between A100 (TF32 default on) and H100
      - FP8 vs FP16 AMP mismatches across CUDA architectures
      - NVLink / PCIe bandwidth errors causing silent tensor corruption

    Returns:
        True  -- loss is within expected range, training is healthy
        False -- loss is suspicious; a WARNING is logged and a Redis event is
                 published on the "watchdog" channel so the operator is alerted.
                 Training continues (non-fatal) -- humans decide whether to roll back.

    If VAULTLAYER_LAST_LOSS is not set (first-ever checkpoint has no history),
    the check is skipped and True is returned.
    """
    last_loss_str = os.environ.get("VAULTLAYER_LAST_LOSS")
    if last_loss_str is None:
        return True  # no baseline -- skip check

    try:
        last_loss = float(last_loss_str)
    except ValueError:
        return True

    if last_loss <= 0:
        return True  # can't meaningfully compare

    ratio = current_loss / last_loss
    if ratio > threshold_multiplier:
        logger.warning(
            f"[VaultLayer] Loss spike detected after migration: "
            f"current={current_loss:.4f}, last={last_loss:.4f}, ratio={ratio:.2f}x "
            f"(threshold={threshold_multiplier}x). Possible hardware precision drift "
            f"(cuDNN TF32 mode, FP8 AMP mismatch, or tensor corruption). "
            f"Consider rolling back to previous checkpoint."
        )
        # Publish a non-blocking watchdog alert so the operator is notified
        _publish_loss_spike_alert(current_loss, last_loss, ratio)
        return False

    logger.info(f"[VaultLayer] Loss sanity check passed: "
                f"current={current_loss:.4f}, last={last_loss:.4f}, ratio={ratio:.2f}x")
    return True


def _publish_loss_spike_alert(current_loss: float, last_loss: float, ratio: float) -> None:
    """Fire-and-forget Redis event so orchestration knows about the loss spike."""
    try:
        import threading
        job_id = os.environ.get("VAULTLAYER_JOB_ID", "unknown")

        def _publish():
            try:
                import redis
                url = os.environ.get("UPSTASH_REDIS_URL", "")
                if not url:
                    return
                r = redis.from_url(url, decode_responses=True)
                import json as _json
                import time
                payload = _json.dumps({
                    "event_type": "LOSS_SPIKE_DETECTED",
                    "schema_version": 1,
                    "job_id": job_id,
                    "timestamp": time.time(),
                    "payload": {
                        "current_loss": current_loss,
                        "last_loss": last_loss,
                        "ratio": ratio,
                        "message": (
                            f"Loss rose {ratio:.1f}x after migration "
                            f"({last_loss:.4f} -> {current_loss:.4f}). "
                            "Possible hardware precision drift."
                        ),
                    },
                })
                r.publish("watchdog", payload)
            except Exception:
                pass  # non-fatal; the logger.warning above is the primary signal

        threading.Thread(target=_publish, daemon=True).start()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Graceful shutdown signal handler (Fix-3: Signal Problem)
# ---------------------------------------------------------------------------

def _emergency_save_on_signal(signum, frame) -> None:  # noqa: ARG001
    """
    SIGTERM / SIGUSR1 handler.

    Saves an emergency checkpoint immediately (in the signal handler frame, which
    Python delivers between bytecodes -- safe for file I/O) then exits with code 0
    so the Watchdog knows the process ended cleanly and can upload the checkpoint.

    Flow:
      1. Watchdog detects spot-termination -> sends SIGUSR1 to VAULTLAYER_TRAINING_PID
      2. This handler fires between the next two Python bytecodes
      3. Model weights saved to VAULTLAYER_MODEL_PATH (or ./checkpoints/emergency/)
      4. sys.exit(0) -> Watchdog on_checkpoint callback uploads to R2 -> Broker
         provisions replacement -> training resumes from this checkpoint
    """
    import sys, json, time, pathlib, os as _os
    sig_name = {2: "SIGINT", 15: "SIGTERM"}.get(signum, f"SIG{signum}")
    logger.warning(f"[VaultLayer] {sig_name} received -- saving emergency checkpoint")

    try:
        import torch
        model = _auto_find_model()
        state: dict = {"step": int(_os.environ.get("VAULTLAYER_RESUME_STEP", "0")),
                       "rng": _snapshot_rng_state()}

        if model is not None:
            try:
                unwrapped = getattr(model, "module", model)
                state["model"] = {k: v.cpu() for k, v in unwrapped.state_dict().items()}
            except Exception as e:
                logger.warning(f"[VaultLayer] Emergency: model save failed: {e}")

        # Save path: VAULTLAYER_MODEL_PATH env var (set by run.py) or fallback
        save_path = _os.environ.get("VAULTLAYER_MODEL_PATH", "")
        if save_path:
            save_dir = pathlib.Path(save_path)
            if save_dir.is_file():
                save_dir = save_dir.parent
        else:
            save_dir = pathlib.Path("./checkpoints/emergency")
        save_dir.mkdir(parents=True, exist_ok=True)

        ckpt_file = save_dir / "checkpoint.pt"
        torch.save(state, ckpt_file)
        (save_dir / "_MANIFEST.json").write_text(json.dumps(
            {"step": state["step"], "saved_at": time.time(),
             "path": str(ckpt_file), "emergency": True}
        ))
        logger.info(f"[VaultLayer] Emergency checkpoint saved: {ckpt_file}")
    except Exception as e:
        logger.error(f"[VaultLayer] Emergency checkpoint failed: {e}")

    sys.exit(0)  # clean exit -- Watchdog will upload what we saved


def _register_signal_handlers() -> None:
    """
    Register SIGTERM and SIGUSR1 handlers for graceful checkpoint-on-termination.

    Called unconditionally at import time (not just on resume) so that even
    first-run jobs can save a checkpoint before being hard-killed.

    SIGUSR1 is sent by the Watchdog when it detects a spot-termination notice
    via IMDSv2, giving the training process up to 90s before the OS SIGTERM
    arrives.  Handling SIGUSR1 lets us save sooner and more reliably.
    """
    import signal as _sig
    try:
        _sig.signal(_sig.SIGUSR1, _emergency_save_on_signal)
        logger.debug("[VaultLayer] SIGUSR1 handler registered")
    except (OSError, ValueError, AttributeError):
        pass  # SIGUSR1 not available on Windows or non-main thread
    try:
        _sig.signal(_sig.SIGTERM, _emergency_save_on_signal)
        logger.debug("[VaultLayer] SIGTERM handler registered")
    except (OSError, ValueError):
        pass
