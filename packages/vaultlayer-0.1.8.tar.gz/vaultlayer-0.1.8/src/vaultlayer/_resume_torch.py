"""
VaultLayer Resume Hook — PyTorch-specific functions
====================================================
Model weight loading, optimizer state restoration, GradScaler/LR scheduler
restoration, and all torch.nn.Module patching logic.

Extracted from _resume_hook.py to keep the main entry point focused on
framework detection and delegation.
"""
from __future__ import annotations

import logging
import os
import pathlib

logger = logging.getLogger("vaultlayer.resume_hook")


# ---------------------------------------------------------------------------
# Model checkpoint discovery & loading
# ---------------------------------------------------------------------------

def _find_model_checkpoint(ckpt_dir: pathlib.Path) -> pathlib.Path | None:
    """Return the first model weight file found under ckpt_dir, or None."""
    candidates = [
        ckpt_dir / "model.pt",
        ckpt_dir / "model.pth",
        ckpt_dir / "pytorch_model.bin",
        ckpt_dir / "model" / "pytorch_model.bin",
        ckpt_dir / "checkpoint.pt",
    ]
    for c in candidates:
        if c.exists():
            return c
    # Fallback: any single .pt/.pth file in the dir
    for ext in ("*.pt", "*.pth", "*.bin"):
        matches = sorted(ckpt_dir.glob(ext))
        if matches:
            return matches[-1]  # latest by name sort
    return None


def _strip_ddp_prefix(state: dict, module) -> dict:
    """
    Normalise DataParallel / DistributedDataParallel 'module.' prefix mismatches.

    DDP saves weights as 'module.layer.weight'; a bare model uses 'layer.weight'.
    If the checkpoint and the live model disagree, fix the checkpoint keys so
    load_state_dict() does not raise RuntimeError: missing/unexpected keys.

    Four cases:
      ckpt has prefix,  model has prefix  -> no change (both DDP)
      ckpt has prefix,  model bare        -> strip 'module.' from ckpt keys
      ckpt bare,        model has prefix  -> prepend 'module.' to ckpt keys
      ckpt bare,        model bare        -> no change
    """
    if not state:
        return state

    ckpt_has_prefix = any(k.startswith("module.") for k in state)
    try:
        model_keys = set(module.state_dict().keys())
        model_has_prefix = any(k.startswith("module.") for k in model_keys)
    except Exception:
        return state  # can't inspect model -- leave as-is

    if ckpt_has_prefix and not model_has_prefix:
        # Checkpoint saved from DDP model, loading into bare model -> strip prefix
        fixed = {(k[len("module."):] if k.startswith("module.") else k): v
                 for k, v in state.items()}
        logger.info("[VaultLayer] Stripped 'module.' DDP prefix from checkpoint keys "
                    "(checkpoint=DDP, model=bare)")
        return fixed

    if not ckpt_has_prefix and model_has_prefix:
        # Checkpoint saved from bare model, loading into DDP model -> add prefix
        fixed = {f"module.{k}": v for k, v in state.items()}
        logger.info("[VaultLayer] Added 'module.' DDP prefix to checkpoint keys "
                    "(checkpoint=bare, model=DDP)")
        return fixed

    return state  # prefixes already match


def _load_model_weights(module, ckpt_file: pathlib.Path) -> bool:
    """Load state dict from ckpt_file into module.  Returns True on success."""
    try:
        import torch
        raw = torch.load(ckpt_file, map_location="cpu", weights_only=True)
    except TypeError:
        # weights_only not available in older torch versions
        try:
            import torch
            raw = torch.load(ckpt_file, map_location="cpu")
        except Exception as e:
            logger.warning(f"[VaultLayer] torch.load failed for {ckpt_file}: {e}")
            return False
    except Exception as e:
        logger.warning(f"[VaultLayer] torch.load failed for {ckpt_file}: {e}")
        return False

    # Unwrap common state-dict wrappers
    if isinstance(raw, dict):
        state = (
            raw.get("state_dict")
            or raw.get("model_state_dict")
            or raw.get("model")
            or raw
        )
    else:
        state = raw

    # Fix DDP prefix mismatch before loading
    if isinstance(state, dict):
        state = _strip_ddp_prefix(state, module)

    try:
        result = module.load_state_dict(state, strict=False)
        missing = len(result.missing_keys) if hasattr(result, "missing_keys") else "?"
        unexpected = len(result.unexpected_keys) if hasattr(result, "unexpected_keys") else "?"
        logger.info(
            f"[VaultLayer] Resumed model weights from {ckpt_file} "
            f"(missing={missing}, unexpected={unexpected})"
        )
        return True
    except Exception as e:
        logger.warning(f"[VaultLayer] load_state_dict failed: {e}")
        return False


# ---------------------------------------------------------------------------
# Optimizer state deferred loading
# ---------------------------------------------------------------------------

def _load_optimizer_state(ckpt_dir: pathlib.Path) -> None:
    """
    If an optimizer checkpoint exists, store a deferred load callback in
    VAULTLAYER_OPT_STATE_PATH so that user code (or the hook below) can pick
    it up.  We cannot load optimizer state here because the optimizer object
    hasn't been created yet.
    """
    opt_candidates = [
        ckpt_dir / "optimizer.pt",
        ckpt_dir / "optimizer_state.pt",
        ckpt_dir / "optimizer.pth",
    ]
    for c in opt_candidates:
        if c.exists():
            os.environ["VAULTLAYER_OPT_STATE_PATH"] = str(c)
            logger.info(f"[VaultLayer] Optimizer state available at {c} -- "
                        "will be loaded on first optimizer.step()")
            _patch_optimizer_step(c)
            return


# ---------------------------------------------------------------------------
# LR Scheduler restoration
# ---------------------------------------------------------------------------

def _fast_forward_scheduler(name: str, scheduler, resume_step: int) -> None:
    """
    Fast-forward an LR scheduler to resume_step without calling step() in a loop
    (which would be O(N) and extremely slow for large step counts).

    Strategy: directly set last_epoch and _step_count, then recompute the current
    learning rate via _get_closed_form_lr() (available on all standard schedulers)
    or fall back to get_lr().
    """
    if resume_step <= 0:
        return
    try:
        scheduler.last_epoch = resume_step
        scheduler._step_count = resume_step + 1
        # Recompute LR in-place
        if hasattr(scheduler, "_get_closed_form_lr"):
            new_lrs = scheduler._get_closed_form_lr()
        elif hasattr(scheduler, "get_lr"):
            new_lrs = scheduler.get_lr()
        else:
            logger.warning(f"[VaultLayer] Cannot recompute LR for scheduler '{name}' -- "
                           "neither _get_closed_form_lr nor get_lr found")
            return
        for param_group, lr in zip(scheduler.optimizer.param_groups, new_lrs):
            param_group["lr"] = lr
        logger.info(f"[VaultLayer] Fast-forwarded LR scheduler '{name}' to step {resume_step} "
                    f"(lr={new_lrs})")
    except Exception as e:
        logger.warning(f"[VaultLayer] LR scheduler fast-forward failed for '{name}': {e}")


def _collect_schedulers_from_value(obj, base_cls, seen_ids, results, prefix=""):
    """
    Recursively collect LR scheduler instances from an arbitrary Python object.

    Handles the common case where schedulers are stored as instance attributes
    (self.scheduler, self.lr_scheduler, trainer.scheduler, etc.) rather than
    bare local variables -- the frame-walk's f_locals only sees locals, not attrs.

    Depth-limited to 3 levels to avoid traversing entire object graphs.
    """
    if id(obj) in seen_ids:
        return
    seen_ids.add(id(obj))
    if isinstance(obj, base_cls):
        results.append((prefix or type(obj).__name__, obj))
        return
    # Recurse into instance __dict__ (covers self.scheduler patterns)
    obj_dict = getattr(obj, "__dict__", None)
    if obj_dict and prefix.count(".") < 3:
        for attr_name, attr_val in list(obj_dict.items()):  # list() snapshot -- avoids RuntimeError if obj mutates __dict__ during iteration (e.g. torch lazy attrs)
            if attr_name.startswith("_"):
                continue  # skip private/dunder attrs
            _collect_schedulers_from_value(
                attr_val, base_cls, seen_ids, results,
                prefix=f"{prefix}.{attr_name}" if prefix else attr_name,
            )


def _restore_lr_schedulers(ckpt_dir: pathlib.Path, resume_step: int) -> None:
    """
    Find all LR schedulers reachable from the call stack and restore their state.

    Two-phase strategy:
    1. If scheduler.pt exists in checkpoint dir -> load_state_dict() (exact restore)
    2. Otherwise -> fast-forward via last_epoch + _get_closed_form_lr()

    Without this, Adam's momentum buffers are restored but the learning rate
    starts at its initial value (often too high), causing gradient explosion
    on the first batch after migration.

    Search strategy (handles both bare locals and class-abstracted training loops):
    - Walk up to 25 call-stack frames inspecting f_locals
    - For every local that is an object with __dict__, recurse into its attributes
      up to 3 levels deep -- catches self.scheduler, trainer.lr_scheduler, etc.

    Frame scanning depth is capped at 25 frames to avoid infinite loops on
    recursive models or unusual call stacks.
    """
    import sys
    try:
        import torch.optim.lr_scheduler as _sched_mod
        # Support both old _LRScheduler (torch < 2.0) and new LRScheduler (torch >= 2.0)
        base_cls = getattr(_sched_mod, "LRScheduler", None) or \
                   getattr(_sched_mod, "_LRScheduler", None)
        if base_cls is None:
            return
    except ImportError:
        return

    # Walk the call stack collecting scheduler objects from local scopes
    # AND from instance attributes of objects in those scopes.
    schedulers_found: list[tuple[str, object]] = []
    seen_ids: set[int] = set()
    frame = sys._getframe(1)
    depth = 0
    while frame is not None and depth < 25:
        for var_name, obj in frame.f_locals.items():
            _collect_schedulers_from_value(
                obj, base_cls, seen_ids, schedulers_found, prefix=var_name
            )
        frame = frame.f_back
        depth += 1

    if not schedulers_found:
        logger.debug("[VaultLayer] No LR schedulers found in call stack or object attributes")
        return

    scheduler_ckpt = ckpt_dir / "scheduler.pt"
    for name, scheduler in schedulers_found:
        if scheduler_ckpt.exists():
            try:
                import torch
                state = torch.load(scheduler_ckpt, map_location="cpu")
                scheduler.load_state_dict(state)
                logger.info(f"[VaultLayer] Restored LR scheduler '{name}' from {scheduler_ckpt}")
            except Exception as e:
                logger.warning(f"[VaultLayer] scheduler.load_state_dict failed ({e}), "
                               "falling back to fast-forward")
                _fast_forward_scheduler(name, scheduler, resume_step)
        else:
            logger.info(f"[VaultLayer] No scheduler.pt found -- fast-forwarding '{name}' "
                        f"to step {resume_step}")
            _fast_forward_scheduler(name, scheduler, resume_step)


def _patch_optimizer_step(opt_ckpt: pathlib.Path) -> None:
    """
    Arrange for optimizer state + LR scheduler restore on the first optimizer.step().

    Strategy: patch torch.optim.Optimizer.__init__ so that every optimizer created
    AFTER this call gets a per-instance step wrapper.  Using __init__ (not the class
    step method) is required because all major optimizers (SGD, Adam, AdamW, ...) override
    step() at the subclass level -- patching Optimizer.step has no effect on them.

    The per-instance wrapper fires once, loads state, restores schedulers, then
    replaces itself with the original bound method to avoid any per-step overhead.
    """
    try:
        import torch.optim
    except ImportError:
        return

    _orig_init = torch.optim.Optimizer.__init__
    _restore_done = [False]  # list so nested closures can mutate it

    def _vl_init(self, params, defaults):
        _orig_init(self, params, defaults)
        if _restore_done[0]:
            return  # already did the restore for a previous optimizer instance

        _orig_bound_step = self.step  # the subclass-specific step (bound method)

        def _one_shot_step(*args, **kwargs):
            if not _restore_done[0]:
                _restore_done[0] = True
                # 1. Restore optimizer state (Adam m/v buffers, SGD momentum, ...)
                try:
                    import torch
                    state = torch.load(opt_ckpt, map_location="cpu")
                    self.load_state_dict(state)
                    logger.info(f"[VaultLayer] Resumed optimizer state from {opt_ckpt}")
                except Exception as e:
                    logger.warning(f"[VaultLayer] Optimizer state load failed: {e}")
                # 2. Restore LR scheduler(s) from the training script's scope
                resume_step = int(os.environ.get("VAULTLAYER_RESUME_STEP", "0"))
                ckpt_dir = pathlib.Path(opt_ckpt).parent
                _restore_lr_schedulers(ckpt_dir, resume_step)
                # Unpatch: restore original step and __init__ to avoid overhead
                self.step = _orig_bound_step
                torch.optim.Optimizer.__init__ = _orig_init
            return _orig_bound_step(*args, **kwargs)

        self.step = _one_shot_step

    torch.optim.Optimizer.__init__ = _vl_init


# ---------------------------------------------------------------------------
# Extra states (TransformerEngine FP8, Apex AMP)
# ---------------------------------------------------------------------------

def _save_extra_states(model, save_dir: pathlib.Path) -> int:
    """Save TransformerEngine / custom extra states that aren't in state_dict (GAP-16).

    Returns the count of successfully saved modules.
    """
    try:
        import torch
    except ImportError:
        return 0
    extra_states: dict = {}
    failed = 0
    for module_name, module in model.named_modules():
        if hasattr(module, "get_extra_state"):
            try:
                extra_states[module_name] = module.get_extra_state()
            except Exception as e:
                logger.warning(f"[VaultLayer] Could not save extra state for {module_name}: {e}")
                failed += 1

    # Apex AMP / torch AMP grad scaler
    try:
        try:
            import apex.amp as _apex_amp
            scaler = getattr(_apex_amp, "_amp_state", None)
            if scaler is None:
                scaler = getattr(_apex_amp, "GradScaler", None)
                if scaler is not None and callable(scaler):
                    scaler = None  # it's a class, not an instance
            if scaler is not None and hasattr(scaler, "state_dict"):
                extra_states["_amp_grad_scaler"] = scaler.state_dict()
        except ImportError:
            pass
        # torch.cuda.amp.GradScaler accessible via model attribute walk
        try:
            import torch.cuda.amp as _torch_amp
            for attr_val in vars(model).values():
                if isinstance(attr_val, _torch_amp.GradScaler):
                    extra_states["_amp_grad_scaler"] = attr_val.state_dict()
                    break
        except Exception:
            pass
    except Exception as e:
        logger.warning(f"[VaultLayer] Could not save AMP grad scaler state: {e}")

    # TransformerEngine FP8 stats
    try:
        import transformer_engine as te  # type: ignore
        fp8_stats = None
        get_stats = getattr(te.fp8, "get_fp8_te_module_stats", None)
        if get_stats is not None:
            fp8_stats = get_stats()
        elif hasattr(te, "fp8") and hasattr(te.fp8, "FP8GlobalStateManager"):
            fp8_stats = te.fp8.FP8GlobalStateManager.get_fp8_state()
        if fp8_stats is not None:
            extra_states["_te_fp8_stats"] = fp8_stats
    except ImportError:
        pass
    except Exception as e:
        logger.warning(f"[VaultLayer] Could not save TransformerEngine FP8 stats: {e}")

    if extra_states:
        torch.save(extra_states, save_dir / "extra_states.pt")
        logger.info(f"[VaultLayer] Saved extra states for {len(extra_states)} module(s)")
    return len(extra_states)


def _load_extra_states(model, save_dir: pathlib.Path) -> None:
    """Restore TransformerEngine / custom extra states (GAP-16)."""
    extra_path = save_dir / "extra_states.pt"
    if not extra_path.exists():
        return
    try:
        import torch
        extra_states = torch.load(extra_path, map_location="cpu")
        n_restored = 0
        amp_scaler_restored = False
        for name, module in model.named_modules():
            if name in extra_states and hasattr(module, "set_extra_state"):
                try:
                    module.set_extra_state(extra_states[name])
                    n_restored += 1
                except Exception as e:
                    logger.warning(
                        f"[VaultLayer] Could not restore extra state for {name}: {e}"
                    )

        # Restore AMP grad scaler if saved
        if "_amp_grad_scaler" in extra_states:
            scaler_state = extra_states["_amp_grad_scaler"]
            try:
                import apex.amp as _apex_amp
                scaler = getattr(_apex_amp, "_amp_state", None)
                if scaler is not None and hasattr(scaler, "load_state_dict"):
                    scaler.load_state_dict(scaler_state)
                    amp_scaler_restored = True
            except ImportError:
                pass
            if not amp_scaler_restored:
                try:
                    import torch.cuda.amp as _torch_amp
                    for attr_val in vars(model).values():
                        if isinstance(attr_val, _torch_amp.GradScaler):
                            attr_val.load_state_dict(scaler_state)
                            amp_scaler_restored = True
                            break
                except Exception:
                    pass

        logger.info(
            f"[VaultLayer] Extra states restored: {n_restored} modules, "
            f"amp_scaler={'yes' if amp_scaler_restored else 'no'}"
        )
    except Exception as e:
        logger.warning(f"[VaultLayer] Extra states load failed: {e}")


# ---------------------------------------------------------------------------
# DataLoader skip & DistributedSampler patches
# ---------------------------------------------------------------------------

def _patch_dataloader_skip(within_epoch_step: int) -> None:
    """
    Wrap DataLoader.__iter__ so the FIRST call skips `within_epoch_step` batches.

    `within_epoch_step` is the number of batches already consumed within the
    current epoch at the time of the last checkpoint.  It comes from the
    `batch_idx` field written by vaultlayer_checkpoint.checkpoint().

    - within_epoch_step == 0 -> no skip (epoch boundary, or unknown position)
    - within_epoch_step  > 0 -> islice skips that many batches on first iter only

    Only the FIRST DataLoader iteration is affected.  Subsequent calls (e.g.
    validation DataLoaders that run later) see unmodified behaviour.
    """
    if within_epoch_step <= 0:
        return  # nothing to skip -- epoch boundary or unknown position

    try:
        import torch.utils.data
        import itertools
    except ImportError:
        return

    original_iter = torch.utils.data.DataLoader.__iter__
    _skipped = [False]

    def _patched_iter(self):
        if not _skipped[0]:
            _skipped[0] = True
            logger.info(
                f"[VaultLayer] Skipping first {within_epoch_step} batches "
                f"(within-epoch position from checkpoint)"
            )
            # Restore original __iter__ so later DataLoaders are unaffected
            torch.utils.data.DataLoader.__iter__ = original_iter
            return itertools.islice(original_iter(self), within_epoch_step, None)
        return original_iter(self)

    torch.utils.data.DataLoader.__iter__ = _patched_iter
    logger.info(
        f"[VaultLayer] DataLoader skip patch active -- "
        f"will skip {within_epoch_step} batches on first iter"
    )


def _patch_distributed_sampler(resume_epoch: int) -> None:
    """
    Auto-call DistributedSampler.set_epoch(resume_epoch) before the first iteration.

    DistributedSampler uses the epoch number as a seed to generate a deterministic
    shuffle.  Without calling set_epoch(), the sampler defaults to epoch=0, causing
    the resumed run to see the epoch-0 shuffle order instead of the epoch it left off
    at -- a subtle but real form of DataLoader bias.

    We patch __iter__ rather than calling set_epoch() immediately because the
    DistributedSampler object may not exist yet at module-load time.
    """
    if resume_epoch <= 0:
        return  # epoch 0 is the default -- no patch needed

    try:
        from torch.utils.data.distributed import DistributedSampler
    except ImportError:
        return

    original_iter = DistributedSampler.__iter__
    _epoch_set = [False]

    def _epoch_aware_iter(self):
        if not _epoch_set[0]:
            _epoch_set[0] = True
            try:
                self.set_epoch(resume_epoch)
                logger.info(
                    f"[VaultLayer] DistributedSampler.set_epoch({resume_epoch}) called "
                    f"-- shuffle order matches checkpoint epoch"
                )
            except Exception as e:
                logger.warning(f"[VaultLayer] DistributedSampler.set_epoch failed: {e}")
            # Restore original __iter__ -- patch fires only once
            DistributedSampler.__iter__ = original_iter
        return original_iter(self)

    DistributedSampler.__iter__ = _epoch_aware_iter
    logger.info(
        f"[VaultLayer] DistributedSampler epoch patch armed (resume_epoch={resume_epoch})"
    )


# ---------------------------------------------------------------------------
# Gradient NaN/Inf check (Crack-3 zero-code path)
# ---------------------------------------------------------------------------

def _patch_gradient_nan_check() -> None:
    """
    Crack-3 (zero-code path): Register a post-step hook that checks for NaN/Inf
    gradients after the first optimizer step on the resumed node.

    This is weaker than check_loss() (which requires the user's loss value) but
    requires zero user code changes.  NaN/Inf gradients are a reliable proxy for
    weight corruption across CUDA architectures.

    The hook fires once (after the first step post-resume) and then unregisters
    itself to avoid any per-step overhead.
    """
    # Import here to avoid circular dependency
    from vaultlayer._resume_state import _publish_loss_spike_alert

    try:
        import torch.optim
    except ImportError:
        return

    resume_step = int(os.environ.get("VAULTLAYER_RESUME_STEP", "0"))
    if resume_step == 0:
        return  # not a resume -- nothing to check

    _orig_init = torch.optim.Optimizer.__init__
    _checked = [False]

    def _nan_guard_init(self, params, defaults):
        _orig_init(self, params, defaults)
        if _checked[0]:
            return

        _orig_step = self.step

        def _guarded_step(*args, **kwargs):
            result = _orig_step(*args, **kwargs)
            if not _checked[0]:
                _checked[0] = True
                # Unregister -- restore pristine step and __init__
                self.step = _orig_step
                torch.optim.Optimizer.__init__ = _orig_init
                # Check all parameter gradients for NaN/Inf
                try:
                    bad_params = []
                    for group in self.param_groups:
                        for p in group["params"]:
                            if p.grad is not None and not torch.isfinite(p.grad).all():
                                bad_params.append(p.shape)
                    if bad_params:
                        logger.warning(
                            f"[VaultLayer] NaN/Inf gradients detected in {len(bad_params)} "
                            f"parameter tensor(s) on first step after migration. "
                            f"Shapes: {bad_params[:5]}. This indicates hardware precision "
                            f"incompatibility (e.g. cuDNN TF32 vs non-TF32). "
                            f"Consider rolling back or switching providers."
                        )
                        _publish_loss_spike_alert(float("nan"), float("nan"), float("nan"))
                    else:
                        logger.info("[VaultLayer] Gradient NaN/Inf check passed")
                except Exception:
                    pass
            return result

        self.step = _guarded_step

    torch.optim.Optimizer.__init__ = _nan_guard_init


# ---------------------------------------------------------------------------
# PyTorch Lightning Trainer clock patch
# ---------------------------------------------------------------------------

def _patch_lightning_trainer(resume_path: str) -> None:
    """
    Patch pytorch_lightning.Trainer to restore its internal step/epoch counters
    from the VaultLayer manifest after a migration.

    Problem: Module.__call__ intercept already loads weights correctly, but
    Lightning's Trainer internally tracks current_epoch and global_step separately.
    After migration the Trainer thinks it is at Epoch 0 / Step 0, causing:
      - ModelCheckpoint to save files with wrong names (epoch=0-step=0.ckpt)
      - ReduceLROnPlateau to reset patience counter from scratch
      - WandB/TensorBoard to show a discontinuous training curve

    Fix: inject a one-shot Callback via Trainer.__init__ that sets the Trainer's
    fit_loop progress counters from the manifest in on_train_start -- which fires
    before the first batch but after the Trainer is fully initialised.

    The manifest is read at patch-install time (not at callback execution time)
    so the step/epoch values are available before any forward pass occurs.
    """
    import json

    try:
        import pytorch_lightning as pl
    except ImportError:
        logger.debug("[VaultLayer] pytorch_lightning not installed -- Lightning clock patch skipped")
        return

    if not resume_path:
        return

    # Read step/epoch directly from manifest (env vars not set yet at patch-install time)
    ckpt_dir = pathlib.Path(resume_path)
    resume_step, resume_epoch = 0, 0
    for manifest_name in ("_MANIFEST.json", "manifest.json"):
        mfile = ckpt_dir / manifest_name
        if mfile.exists():
            try:
                data = json.loads(mfile.read_text())
                resume_step = int(data.get("step") or data.get("global_step") or 0)
                resume_epoch = int(data.get("epoch") or data.get("checkpoint_epoch") or 0)
            except Exception:
                pass
            break

    if resume_step == 0 and resume_epoch == 0:
        logger.debug("[VaultLayer] Lightning patch: manifest has step=0, epoch=0 -- skipping")
        return

    class _VaultLayerLightningResume(pl.Callback):
        """Restores Trainer's internal clock on train_start, then removes itself."""

        def on_train_start(self, trainer, pl_module):
            try:
                # Lightning >= 1.6: fit_loop.epoch_loop.batch_progress
                trainer.fit_loop.epoch_loop.batch_progress.total.completed = resume_step
                trainer.fit_loop.epoch_loop.batch_progress.current.completed = resume_step
                trainer.fit_loop.epoch_progress.current.completed = resume_epoch
                trainer.fit_loop.epoch_progress.total.completed = resume_epoch
                logger.info(
                    f"[VaultLayer] Lightning Trainer clock restored: "
                    f"global_step={resume_step}, current_epoch={resume_epoch}"
                )
            except AttributeError:
                # Lightning < 1.6 legacy API
                try:
                    trainer.fit_loop.current_epoch = resume_epoch
                    trainer.global_step = resume_step
                    logger.info(
                        f"[VaultLayer] Lightning Trainer clock restored (legacy API): "
                        f"global_step={resume_step}, epoch={resume_epoch}"
                    )
                except Exception as exc:
                    logger.warning(
                        f"[VaultLayer] Could not restore Lightning Trainer clock: {exc}"
                    )
            # Self-remove -- no overhead on subsequent epochs
            try:
                trainer.callbacks = [
                    c for c in trainer.callbacks
                    if not isinstance(c, _VaultLayerLightningResume)
                ]
            except Exception:
                pass

    # Patch Trainer.__init__ to inject the callback into the first Trainer instance
    _orig_trainer_init = pl.Trainer.__init__
    _injected = [False]

    def _vl_trainer_init(self, *args, **kwargs):
        _orig_trainer_init(self, *args, **kwargs)
        if not _injected[0]:
            _injected[0] = True
            self.callbacks.append(_VaultLayerLightningResume())
            # Restore original __init__ -- only the first Trainer instance needs the callback
            pl.Trainer.__init__ = _orig_trainer_init
            logger.info("[VaultLayer] VaultLayerLightningResume callback injected into Trainer")

    pl.Trainer.__init__ = _vl_trainer_init
    logger.info(
        f"[VaultLayer] Lightning Trainer clock patch armed "
        f"(step={resume_step}, epoch={resume_epoch})"
    )


# ---------------------------------------------------------------------------
# Module.__call__ patch (entry point for weight injection)
# ---------------------------------------------------------------------------

def _patch_torch(inject_state_fn) -> None:
    """
    Wrap torch.nn.Module.__call__ to inject checkpoint on the first forward.
    We use __call__ (not forward) so we catch both nn.Module.forward overrides
    and raw Module() invocations uniformly.

    inject_state_fn: callable(module) that loads weights into the module.
    """
    try:
        import torch.nn
    except ImportError:
        logger.debug("[VaultLayer] torch not available -- resume hook is a no-op")
        return

    _orig_call = torch.nn.Module.__call__
    _injected = [False]

    def _vl_call(self, *args, **kwargs):
        if not _injected[0]:
            _injected[0] = True
            inject_state_fn(self)
        return _orig_call(self, *args, **kwargs)

    torch.nn.Module.__call__ = _vl_call
    logger.info("[VaultLayer] Resume hook active -- checkpoint will be loaded on first forward pass")
