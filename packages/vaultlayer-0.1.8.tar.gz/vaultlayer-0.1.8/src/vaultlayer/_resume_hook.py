"""
VaultLayer Resume Hook
======================
Provides zero-code-change checkpoint resumption for PyTorch training scripts.

How it works
------------
Injected via a sitecustomize.py written to a temp directory that is prepended
to PYTHONPATH by `vaultlayer run` and by the broker's SSH restart command.
Python imports sitecustomize before any user code, so the patch is in place
by the time `python train.py` starts executing.

On the first torch.nn.Module forward call, the hook:
1. Reads the checkpoint from VAULTLAYER_RESUME_CHECKPOINT
2. Loads model weights via load_state_dict(strict=False)
3. Loads optimizer state if an optimizer .pt file is present
4. Reads step/epoch from the VaultLayer manifest and sets VAULTLAYER_RESUME_STEP

Framework coverage
------------------
- HuggingFace Trainer   : already works via RESUME_FROM_CHECKPOINT (no hook needed)
- Raw PyTorch           : Module.__call__ intercept (weights) + _load() (RNG, optimizer, scheduler)
- PyTorch Lightning     : Module.__call__ (weights) + Trainer.__init__ callback (epoch/step clock)
- JAX/Flax              : not covered by this hook (env vars only)

Invisible-state coverage (as of this version)
----------------------------------------------
- Optimizer state       : Adam m/v buffers, SGD momentum -- deferred load on first optimizer.step()
- LR scheduler          : exact restore via scheduler.pt or fast-forward via _get_closed_form_lr()
- GradScaler (AMP)      : saved in checkpoint.pt, restored in _load()
- RNG states            : torch CPU, CUDA (all devices), numpy, python random -- restored on resume
- Lightning Trainer clock: epoch/step counters restored via one-shot on_train_start callback
- DataLoader position   : islice skip of already-seen batches (GAP-4)
- TransformerEngine FP8 : extra_states.pt saved/restored (GAP-16)
- Apex AMP              : _amp_grad_scaler saved/restored (GAP-16)

Module structure
----------------
- _resume_torch.py  : PyTorch-specific hook functions (model weights, optimizer,
                      LR scheduler, GradScaler, DataLoader, Lightning patches)
- _resume_state.py  : Generic state management (RNG, manifest, loss check,
                      emergency checkpoint, signal handlers)
- _resume_hook.py   : This file -- entry point, framework detection, delegation
"""
from __future__ import annotations

import logging
import os
import pathlib

logger = logging.getLogger("vaultlayer.resume_hook")

RESUME_PATH: str = os.environ.get("VAULTLAYER_RESUME_CHECKPOINT", "")

# ---------------------------------------------------------------------------
# Re-export all public & semi-public names from sub-modules so that existing
# imports like `from vaultlayer._resume_hook import check_loss` keep working.
# ---------------------------------------------------------------------------

# PyTorch-specific functions (from _resume_torch)
from vaultlayer._resume_torch import (  # noqa: F401,E402
    _find_model_checkpoint,
    _strip_ddp_prefix,
    _load_model_weights,
    _load_optimizer_state,
    _fast_forward_scheduler,
    _collect_schedulers_from_value,
    _restore_lr_schedulers,
    _patch_optimizer_step,
    _save_extra_states,
    _load_extra_states,
    _patch_dataloader_skip,
    _patch_distributed_sampler,
    _patch_gradient_nan_check,
    _patch_lightning_trainer as _patch_lightning_trainer_impl,
    _patch_torch as _patch_torch_impl,
)

# Generic state management (from _resume_state)
from vaultlayer._resume_state import (  # noqa: F401,E402
    _snapshot_rng_state,
    _restore_rng_from_ckpt,
    _restore_step_from_manifest,
    _auto_find_model,
    check_loss as _state_check_loss,
    _publish_loss_spike_alert,
    _emergency_save_on_signal,
    _register_signal_handlers,
)


# ---------------------------------------------------------------------------
# _patch_torch wrapper -- defaults inject_state_fn to _inject_state for
# backward compatibility with code that calls _patch_torch() with no args.
# ---------------------------------------------------------------------------

def _patch_torch(inject_state_fn=None):
    """Wrap torch.nn.Module.__call__. Defaults to _inject_state if no fn given."""
    if inject_state_fn is None:
        inject_state_fn = _inject_state
    _patch_torch_impl(inject_state_fn)


def _patch_lightning_trainer(resume_path=None):
    """Patch Lightning Trainer. Defaults to RESUME_PATH if no path given."""
    if resume_path is None:
        resume_path = RESUME_PATH
    _patch_lightning_trainer_impl(resume_path)


def check_loss(current_loss: float, threshold_multiplier: float = 2.0) -> bool:
    """Crack-3 loss sanity check. Wraps _resume_state.check_loss so that patching
    vaultlayer._resume_hook._publish_loss_spike_alert works in tests."""
    last_loss_str = os.environ.get("VAULTLAYER_LAST_LOSS")
    if last_loss_str is None:
        return True
    try:
        last_loss = float(last_loss_str)
    except ValueError:
        return True
    if last_loss <= 0:
        return True
    ratio = current_loss / last_loss
    if ratio > threshold_multiplier:
        logger.warning(
            f"[VaultLayer] Loss spike detected after migration: "
            f"current={current_loss:.4f}, last={last_loss:.4f}, ratio={ratio:.2f}x "
            f"(threshold={threshold_multiplier}x). Possible hardware precision drift "
            f"(cuDNN TF32 mode, FP8 AMP mismatch, or tensor corruption). "
            f"Consider rolling back to previous checkpoint."
        )
        _publish_loss_spike_alert(current_loss, last_loss, ratio)
        return False
    logger.info(f"[VaultLayer] Loss sanity check passed: "
                f"current={current_loss:.4f}, last={last_loss:.4f}, ratio={ratio:.2f}x")
    return True


# ---------------------------------------------------------------------------
# State injection -- called on the first forward pass of any Module
# ---------------------------------------------------------------------------

# Sentinel: once we have injected state we must not do it again (avoids double-load
# if the same module's __call__ is hit multiple times before weights are frozen).
_state_injected: bool = False


def _inject_state(module) -> None:
    """
    Called on the first forward pass of any Module.
    Loads model weights and schedules optimizer state load.
    """
    global _state_injected
    if _state_injected or not RESUME_PATH:
        return
    # Mark immediately to prevent re-entrant calls (submodule forwards etc.)
    _state_injected = True

    ckpt_dir = pathlib.Path(RESUME_PATH)
    if not ckpt_dir.exists():
        logger.warning(f"[VaultLayer] Checkpoint dir not found: {ckpt_dir} -- starting from scratch")
        return

    ckpt_file = _find_model_checkpoint(ckpt_dir)
    if ckpt_file:
        _load_model_weights(module, ckpt_file)
        # GAP-16: Restore TransformerEngine / Apex AMP extra states after weights
        _load_extra_states(module, ckpt_dir)
        # Restore RNG states so dropout/augmentation/shuffling are deterministic on resume
        _restore_rng_from_ckpt(ckpt_file)
    else:
        logger.warning(f"[VaultLayer] No model checkpoint found in {ckpt_dir} -- starting from scratch")

    _load_optimizer_state(ckpt_dir)
    _restore_step_from_manifest(ckpt_dir)


# ---------------------------------------------------------------------------
# Entry point -- runs at import time (called from sitecustomize.py)
# ---------------------------------------------------------------------------

# Signal handlers are always registered -- even on first run, SIGUSR1/SIGTERM
# should trigger an emergency checkpoint rather than hard-killing the process.
_register_signal_handlers()

if RESUME_PATH:
    _patch_torch()  # defaults to _inject_state
    _patch_gradient_nan_check()    # Crack-3: zero-code NaN/Inf guard on first post-resume step
    _patch_lightning_trainer(RESUME_PATH)  # Restore Lightning Trainer's step/epoch clock after migration
    logger.debug(f"[VaultLayer] Resume hook armed for checkpoint: {RESUME_PATH}")
else:
    logger.debug("[VaultLayer] VAULTLAYER_RESUME_CHECKPOINT not set -- hook is a no-op")
