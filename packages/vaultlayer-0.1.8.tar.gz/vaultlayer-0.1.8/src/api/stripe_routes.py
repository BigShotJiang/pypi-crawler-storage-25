"""
Stripe Checkout + webhook handler.

Flow:
  1. User clicks "Buy Credits" on dashboard
  2. POST /api/v1/stripe/checkout  →  returns Stripe Checkout URL
  3. User pays on Stripe-hosted page
  4. Stripe calls POST /api/v1/stripe/webhook (payment_intent.succeeded)
  5. We add credits to user's ledger + send confirmation email

Credit packages:
  starter  $10  → 1,000 credits
  growth   $50  → 5,500 credits  (+10% bonus)
  scale    $200 → 24,000 credits (+20% bonus)
"""
from __future__ import annotations

import logging
import os

import stripe
from fastapi import APIRouter, Depends, HTTPException, Request, status

from api.auth import require_auth
from api.db import add_credit_event, get_balance, get_db, get_user
from api.email import send_topup_confirmation
from api.flags import TESTING_MODE, TESTING_CREDITS_BALANCE
from api.fraud import check_card_fingerprint
from api.models import CheckoutRequest, CheckoutResponse

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/stripe", tags=["stripe"])

stripe.api_key = os.environ.get("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")

# Stripe Price IDs — create these in your Stripe dashboard
STRIPE_PRICES = {
    "starter": os.environ.get("STRIPE_PRICE_STARTER", ""),   # $10
    "growth":  os.environ.get("STRIPE_PRICE_GROWTH",  ""),   # $50
    "scale":   os.environ.get("STRIPE_PRICE_SCALE",   ""),   # $200
}

# Credits per package (including bonus)
CREDITS_PER_PACKAGE = {
    "starter": 1_000,
    "growth":  5_500,
    "scale":   24_000,
}

PACKAGE_USD = {
    "starter": 10,
    "growth":  50,
    "scale":   200,
}


# ── Checkout session ──────────────────────────────────────────────────────────

@router.post("/checkout", response_model=CheckoutResponse)
async def create_checkout(req: CheckoutRequest, user: dict = Depends(require_auth)):
    # ── Testing mode: return a dummy checkout URL, no Stripe API call ─────────
    if TESTING_MODE:
        logger.info(f"[stripe] TESTING_MODE: checkout no-op for {user['user_id']} package={req.package}")
        return CheckoutResponse(
            checkout_url="https://stripe.com/testing-mode-disabled",
            session_id="cs_test_TESTING_MODE_DISABLED",
        )

    if req.package not in STRIPE_PRICES:
        raise HTTPException(status_code=400, detail=f"Unknown package: {req.package}")

    price_id = STRIPE_PRICES[req.package]
    if not price_id:
        raise HTTPException(status_code=503, detail="Stripe price not configured")

    try:
        session = stripe.checkout.Session.create(
            mode="payment",
            line_items=[{"price": price_id, "quantity": 1}],
            customer_email=user["email"],
            client_reference_id=user["user_id"],
            metadata={
                "user_id":  user["user_id"],
                "package":  req.package,
                "credits":  str(CREDITS_PER_PACKAGE[req.package]),
            },
            success_url=req.success_url + "?session_id={CHECKOUT_SESSION_ID}",
            cancel_url=req.cancel_url,
            # Collect card for fingerprinting
            payment_method_types=["card"],
        )
    except stripe.error.StripeError as e:
        logger.error(f"[stripe] Checkout session creation failed: {e}")
        raise HTTPException(status_code=502, detail="Failed to create checkout session")

    return CheckoutResponse(checkout_url=session.url, session_id=session.id)


# ── Webhook ───────────────────────────────────────────────────────────────────

@router.post("/webhook")
async def stripe_webhook(request: Request):
    # ── Testing mode: acknowledge without processing ───────────────────────────
    if TESTING_MODE:
        logger.info("[stripe] TESTING_MODE: webhook no-op")
        return {"received": True, "testing_mode": True}

    payload = await request.body()
    sig_header = request.headers.get("stripe-signature", "")

    try:
        event = stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)
    except stripe.error.SignatureVerificationError:
        raise HTTPException(status_code=400, detail="Invalid Stripe signature")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

    if event["type"] == "checkout.session.completed":
        await _handle_checkout_completed(event["data"]["object"])
    elif event["type"] == "payment_intent.payment_failed":
        await _handle_payment_failed(event["data"]["object"])
    # All other event types are acknowledged but not processed
    return {"received": True}


async def _handle_checkout_completed(session: dict):
    """Credit the user's account after a successful Stripe payment."""
    user_id = session.get("metadata", {}).get("user_id")
    package = session.get("metadata", {}).get("package")
    credits = int(session.get("metadata", {}).get("credits", 0))
    payment_intent_id = session.get("payment_intent", "")

    if not user_id or not package or credits <= 0:
        logger.error(f"[stripe] Incomplete metadata on session {session.get('id')}")
        return

    user = await get_user(user_id)
    if not user:
        logger.error(f"[stripe] Unknown user {user_id} on checkout session")
        return

    # ── Fraud: card fingerprint dedup ────────────────────────────────────────
    # Retrieve payment intent to get card fingerprint
    stripe_card_fp = None
    try:
        pi = stripe.PaymentIntent.retrieve(payment_intent_id, expand=["payment_method"])
        stripe_card_fp = pi.payment_method.card.fingerprint
        allowed, reason = await check_card_fingerprint(user_id, stripe_card_fp)
        if not allowed:
            logger.warning(f"[stripe] Card dedup block for {user_id}: {reason}")
            # Refund the payment rather than crediting
            stripe.Refund.create(payment_intent=payment_intent_id,
                                  reason="fraudulent")
            return
    except Exception as e:
        logger.warning(f"[stripe] Could not retrieve card fingerprint: {e}")

    # ── Idempotency: skip if this payment_intent was already processed ────────
    db = get_db()
    existing = (
        db.table("credit_events")
        .select("id")
        .eq("stripe_payment_id", payment_intent_id)
        .execute()
    )
    if existing.data:
        logger.info(f"[stripe] Duplicate webhook for {payment_intent_id}, skipping")
        return

    # ── Credit the account ────────────────────────────────────────────────────
    add_credit_event(
        user_id=user_id,
        event_type="purchased",
        amount_credits=credits,
        stripe_payment_id=payment_intent_id,
        stripe_card_fp=stripe_card_fp,
        description=f"{package.capitalize()} pack — {credits:,} credits (${PACKAGE_USD[package]})",
    )

    # Store stripe_customer_id for future payments
    customer_id = session.get("customer")
    if customer_id:
        try:
            db.table("users").update({"stripe_customer_id": customer_id}).eq("user_id", user_id).execute()
        except Exception as e:
            logger.error(f"[stripe] Failed to store customer_id for {user_id}: {e}")

    bal = get_balance(user_id)
    await send_topup_confirmation(
        email=user["email"],
        credits_added=credits,
        available_credits=bal["available_credits"],
        package=package,
    )

    logger.info(f"[stripe] {user_id} purchased {credits:,} credits ({package}). "
                f"Available: {bal['available_credits']}")


async def _handle_payment_failed(payment_intent: dict):
    """Log failed payments — email sent by Stripe's own failed-payment emails."""
    logger.warning(
        f"[stripe] Payment failed: {payment_intent.get('id')} "
        f"for {payment_intent.get('receipt_email')}"
    )
