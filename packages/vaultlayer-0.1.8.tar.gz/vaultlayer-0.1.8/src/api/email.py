"""
Transactional email via Resend.
https://resend.com/docs/send-with-python

Templates:
  - low_balance    : balance < $10 warning
  - job_suspended  : credits exhausted, job paused, no progress lost
  - topup_confirm  : payment confirmed, credits added
  - welcome        : first token issued after signup

All sends are fire-and-forget — email failure is never fatal to the job flow.
"""
from __future__ import annotations

import logging
import os

import resend

logger = logging.getLogger(__name__)

resend.api_key = os.environ.get("RESEND_API_KEY", "")
FROM_ADDRESS = os.environ.get("EMAIL_FROM", "VaultLayer <noreply@vaultlayer.ai>")
DASHBOARD_URL = os.environ.get("DASHBOARD_URL", "https://vaultlayer.ai")


async def _send(to: str, subject: str, html: str):
    """Send an email. Swallows all errors — email is never on the critical path."""
    try:
        resend.Emails.send({
            "from":    FROM_ADDRESS,
            "to":      [to],
            "subject": subject,
            "html":    html,
        })
        logger.info(f"[email] Sent '{subject}' to {to}")
    except Exception as e:
        logger.warning(f"[email] Failed to send '{subject}' to {to}: {e}")


async def send_welcome(email: str, raw_token: str, initial_credits: int):
    """Sent once after account creation — contains the API token (shown only here)."""
    await _send(
        to=email,
        subject="Welcome to VaultLayer — your API token",
        html=f"""
        <p>Welcome to VaultLayer!</p>
        <p>Your account is ready. You have <strong>{initial_credits:,} free credits</strong>
        to get started (${initial_credits / 100:.0f} of free compute).</p>

        <p><strong>Your API token (copy this — it won't be shown again):</strong></p>
        <pre style="background:#f4f4f4;padding:12px;border-radius:4px;font-size:14px;">{raw_token}</pre>

        <p>Set it in your terminal:</p>
        <pre style="background:#f4f4f4;padding:12px;border-radius:4px;">export VAULTLAYER_TOKEN={raw_token}</pre>

        <p>Then get started:</p>
        <pre style="background:#f4f4f4;padding:12px;border-radius:4px;">pip install vaultlayer
vaultlayer init
vaultlayer run python train.py</pre>

        <p>You'll get 800 more free credits after your first job runs for 10 minutes.</p>
        <p><a href="{DASHBOARD_URL}/dashboard">View your dashboard</a></p>
        """,
    )


async def send_credits_low(email: str, available_credits: int):
    """Sent when balance drops below LOW_CREDITS_THRESHOLD (1000 credits / $10)."""
    available_usd = available_credits / 100
    await _send(
        to=email,
        subject=f"VaultLayer — low credit balance ({available_credits} credits remaining)",
        html=f"""
        <p>Your VaultLayer credit balance is running low.</p>
        <p><strong>Available: {available_credits:,} credits (${available_usd:.2f})</strong></p>
        <p>Top up now to keep your jobs running without interruption.</p>
        <p>
            <a href="{DASHBOARD_URL}/credits"
               style="background:#6366f1;color:white;padding:10px 20px;
                      border-radius:6px;text-decoration:none;font-weight:bold;">
                Top up credits
            </a>
        </p>
        <p style="color:#666;font-size:12px;">
            When your balance reaches $0.50, your active jobs will be
            checkpointed and paused — no progress lost.
        </p>
        """,
    )


async def send_job_suspended(email: str, job_id: str, available_credits: int):
    """Sent when a job is suspended due to credit exhaustion."""
    await _send(
        to=email,
        subject="VaultLayer — job paused (credits exhausted)",
        html=f"""
        <p>Your job <code>{job_id}</code> has been <strong>paused</strong>
        because your credit balance reached zero.</p>

        <p><strong>Your progress is safe.</strong> An emergency checkpoint was saved
        before the job was paused.</p>

        <p>Current balance: <strong>{available_credits} credits</strong></p>

        <p><strong>To resume:</strong></p>
        <ol>
            <li>Top up credits at <a href="{DASHBOARD_URL}/credits">vaultlayer.ai/credits</a></li>
            <li>Run: <code>vaultlayer restart --job-id {job_id}</code></li>
        </ol>

        <p>Training will continue from exactly where it left off — no code changes needed.</p>

        <p>
            <a href="{DASHBOARD_URL}/credits"
               style="background:#6366f1;color:white;padding:10px 20px;
                      border-radius:6px;text-decoration:none;font-weight:bold;">
                Top up credits
            </a>
        </p>
        """,
    )


async def send_verification_code(email: str, code: str):
    """Sent when user runs `vaultlayer signup` or `vaultlayer login`."""
    await _send(
        to=email,
        subject="VaultLayer — your verification code",
        html=f"""
        <p>Your verification code is:</p>

        <p style="font-size:32px;font-weight:bold;letter-spacing:8px;
                  font-family:monospace;color:#6366f1;margin:20px 0;">
            {code}
        </p>

        <p>Enter this code in your terminal to continue.</p>
        <p>This code expires in <strong>10 minutes</strong>.</p>

        <p style="color:#888;font-size:12px;margin-top:20px;">
            If you didn't request this, ignore this email.
        </p>
        """,
    )


async def send_needs_more_info(email: str, feedback_id: str, question: str):
    """Sent when a bug report lacks enough info for Claude to act on."""
    await _send(
        to=email,
        subject="VaultLayer — we need more info to fix your bug",
        html=f"""
        <p>Hi,</p>
        <p>Thanks for reporting a bug (ID: <code>{feedback_id}</code>).
        We want to fix it, but we need a bit more information.</p>

        <p><strong>To help us investigate:</strong></p>
        <pre style="background:#f4f4f4;padding:12px;border-radius:4px;white-space:pre-wrap;">{question}</pre>

        <p>Reply to this email or re-run with <code>vaultlayer feedback</code>
        after gathering the info above.</p>

        <p>Thanks for helping us improve VaultLayer!</p>
        <p><a href="{DASHBOARD_URL}/dashboard">View your dashboard</a></p>
        """,
    )


async def send_bug_fixed(email: str, feedback_id: str, pr_url: str):
    """Sent to all reporters when a bug is fixed via auto-PR."""
    await _send(
        to=email,
        subject="VaultLayer — your reported issue is fixed!",
        html=f"""
        <p>Hi,</p>
        <p>Great news! The bug you reported (ID: <code>{feedback_id}</code>)
        has been fixed and merged.</p>

        <p>To get the fix, run:</p>
        <pre style="background:#f4f4f4;padding:12px;border-radius:4px;">pip install --upgrade vaultlayer</pre>

        <p>Fix details: <a href="{pr_url}">{pr_url}</a></p>

        <p>Thank you for helping us improve VaultLayer!</p>
        <p><a href="{DASHBOARD_URL}/dashboard">View your dashboard</a></p>
        """,
    )


async def send_topup_confirmation(
    email: str,
    credits_added: int,
    available_credits: int,
    package: str,
):
    """Sent after a successful Stripe payment."""
    usd_paid = {"starter": 10, "growth": 50, "scale": 200}.get(package, 0)
    await _send(
        to=email,
        subject=f"VaultLayer — {credits_added:,} credits added",
        html=f"""
        <p>Payment confirmed. Your account has been credited.</p>
        <table style="border-collapse:collapse;margin:16px 0;">
            <tr>
                <td style="padding:6px 16px 6px 0;color:#666;">Package</td>
                <td style="padding:6px 0;"><strong>{package.capitalize()}</strong></td>
            </tr>
            <tr>
                <td style="padding:6px 16px 6px 0;color:#666;">Amount paid</td>
                <td style="padding:6px 0;"><strong>${usd_paid}</strong></td>
            </tr>
            <tr>
                <td style="padding:6px 16px 6px 0;color:#666;">Credits added</td>
                <td style="padding:6px 0;"><strong>{credits_added:,} credits</strong></td>
            </tr>
            <tr>
                <td style="padding:6px 16px 6px 0;color:#666;">Available balance</td>
                <td style="padding:6px 0;"><strong>{available_credits:,} credits
                (${available_credits / 100:.2f})</strong></td>
            </tr>
        </table>
        <p><a href="{DASHBOARD_URL}/dashboard">View your dashboard</a></p>
        """,
    )
