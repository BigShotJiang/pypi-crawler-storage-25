"""
src/api/admin_dashboard.py — Investor/admin dashboard metrics API

Single endpoint: GET /admin/dashboard
Returns all metrics needed for the investor dashboard:
  - Hero metrics (jobs, savings, revenue, users)
  - 30-day daily time series
  - Provider breakdown
  - Geographic distribution
  - User cohort retention
  - GPU type / model size segmentation
  - Top users by LTV

Protected by service-role Supabase key or admin JWT.
"""

from __future__ import annotations

import os
import time
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, List, Optional

try:
    from fastapi import APIRouter, Depends, HTTPException, Header
    from pydantic import BaseModel
    _FASTAPI_AVAILABLE = True
except ImportError:  # pragma: no cover — fastapi not installed in test env
    # Provide minimal stubs so the module can be imported for unit tests
    class _Stub:  # type: ignore
        def __init__(self, *a, **kw): pass
        def __call__(self, *a, **kw): return self
        def get(self, *a, **kw): return lambda f: f

    class HTTPException(Exception):  # type: ignore
        def __init__(self, status_code: int, detail: str = ""):
            self.status_code = status_code
            self.detail = detail
            super().__init__(detail)

    def Depends(dep=None):  # type: ignore
        return None

    def Header(default=""):  # type: ignore
        return default

    class BaseModel:  # type: ignore
        def __init__(self, **kw):
            for k, v in kw.items():
                setattr(self, k, v)

    APIRouter = _Stub  # type: ignore
    _FASTAPI_AVAILABLE = False

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/admin", tags=["admin-dashboard"])

# ── Auth guard ────────────────────────────────────────────────────────────────


def _require_admin(x_admin_secret: str = Header(default="")):
    """Simple shared-secret guard for the admin dashboard endpoint.
    Replace with proper Clerk JWT admin role check in production.
    Reads VAULTLAYER_ADMIN_SECRET at call-time (not import-time) so that
    monkeypatching env vars in tests works correctly.
    """
    admin_secret = os.environ.get("VAULTLAYER_ADMIN_SECRET", "")
    if not admin_secret:
        raise HTTPException(503, "Admin dashboard not configured (VAULTLAYER_ADMIN_SECRET not set)")
    if x_admin_secret != admin_secret:
        raise HTTPException(403, "Forbidden")


# ── Response models ────────────────────────────────────────────────────────────

class HeroMetrics(BaseModel):
    total_jobs: int
    active_jobs: int
    completed_jobs: int
    failed_jobs: int
    total_users: int
    active_users_30d: int
    total_gpu_hours: float
    total_data_processed_gb: float
    total_gross_savings_usd: float
    total_vl_revenue_usd: float
    total_net_savings_usd: float
    total_migrations: int
    total_spot_interruptions: int
    avg_savings_pct: float
    job_success_rate_pct: float


class DailyPoint(BaseModel):
    date: str
    jobs_started: int
    jobs_completed: int
    gpu_hours: float
    data_processed_gb: float
    gross_savings_usd: float
    vl_revenue_usd: float
    new_users: int
    active_users: int
    spot_interruptions: int
    migrations_executed: int


class ProviderRow(BaseModel):
    provider: str
    total_jobs: int
    completed_jobs: int
    success_rate_pct: float
    total_gpu_hours: float
    avg_savings_pct: float
    total_gross_savings_usd: float
    total_vl_revenue_usd: float
    total_interruptions: int
    avg_interruptions_per_job: float


class RegionRow(BaseModel):
    region: str
    provider: str
    total_jobs: int
    total_gpu_hours: float
    total_data_gb: float
    total_gross_savings_usd: float


class CohortRow(BaseModel):
    cohort_label: str
    month_offset: int
    cohort_size: int
    returning_users: int
    retention_pct: float


class GpuRow(BaseModel):
    gpu_type: str
    total_jobs: int
    total_gpu_hours: float
    avg_model_params_b: float
    total_gross_savings_usd: float
    avg_savings_pct: float


class ModelSegmentRow(BaseModel):
    model_size_bucket: str
    total_jobs: int
    total_gpu_hours: float
    total_gross_savings_usd: float


class TopUserRow(BaseModel):
    user_id: str
    total_jobs: int
    completed_jobs: int
    total_gpu_hours: float
    total_data_gb: float
    lifetime_gross_savings_usd: float
    lifetime_vl_revenue_usd: float
    lifetime_net_savings_usd: float
    avg_savings_pct: float
    tenure_days: int
    first_job_at: Optional[str]
    last_job_at: Optional[str]


class SmokeTestRow(BaseModel):
    provider: str
    gpu_type: str
    status: str          # "terminated" = passed, "failed" = no capacity
    instance_id: str
    billing_seconds: float
    estimated_cost_usd: float
    created_at: str


class SmokeTestSummaryRow(BaseModel):
    provider: str
    total_runs: int
    passed: int
    failed: int
    pass_rate_pct: float
    total_cost_usd: float
    last_run_at: str


class BillDriftRow(BaseModel):
    """One job_runs row flagged by the daily AWS bill reconciliation.

    metadata.audit_status='drift_flagged' means AWS charged materially more
    (or less) than our estimate. We never modify user_charged_usd — these
    rows are margin-impact for ops review, not user-visible billing changes.
    """
    run_id: str
    provider: str
    region: str
    instance_id: str
    terminated_at: str
    estimated_cost_usd: float
    provider_billed_usd: float
    user_charged_usd: float
    audit_kind: str            # OVERCHARGE | UNDERCHARGE | ZERO_COST
    audit_delta_usd: float
    audit_delta_pct: float
    audit_at: str


class FeedbackRow(BaseModel):
    id: str
    type: str
    message: str
    status: str
    email: Optional[str]
    submitted_at: Optional[str]
    resolved_at: Optional[str]
    pr_url: Optional[str]
    needs_more_info: bool


class FeedbackDashboardResponse(BaseModel):
    generated_at: str
    total: int
    pending: int
    resolved: int
    items: list[FeedbackRow]


class DashboardResponse(BaseModel):
    generated_at: str
    hero: HeroMetrics
    daily_30d: list[DailyPoint]
    providers: list[ProviderRow]
    regions: list[RegionRow]
    cohort_retention: list[CohortRow]
    gpu_breakdown: list[GpuRow]
    model_segments: list[ModelSegmentRow]
    top_users_by_ltv: list[TopUserRow]
    smoke_tests: list[SmokeTestRow]
    smoke_test_summary: list[SmokeTestSummaryRow]
    bill_drift_flagged: list[BillDriftRow]


# ── Supabase query helper ──────────────────────────────────────────────────────

def _get_supabase():
    """Return a Supabase client using the service role key (admin access)."""
    try:
        from supabase import create_client
        url = os.environ.get("SUPABASE_URL", "")
        key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "") or os.environ.get("SUPABASE_KEY", "")
        if not url or not key:
            return None
        return create_client(url, key)
    except Exception as e:
        logger.warning(f"[dashboard] Supabase client unavailable: {e}")
        return None


def _safe_float(v, default=0.0) -> float:
    try:
        return float(v) if v is not None else default
    except (TypeError, ValueError):
        return default


def _safe_int(v, default=0) -> int:
    try:
        return int(v) if v is not None else default
    except (TypeError, ValueError):
        return default


def _safe_str(v, default=None):
    if v is None:
        return default
    if isinstance(v, datetime):
        return v.isoformat()
    return str(v)


# ── Fallback: in-memory stub for dev/demo ─────────────────────────────────────

def _stub_dashboard() -> DashboardResponse:
    """Return a zeroed dashboard when Supabase is unavailable (dev mode)."""
    now = datetime.now(timezone.utc).isoformat()
    return DashboardResponse(
        generated_at=now,
        hero=HeroMetrics(
            total_jobs=0, active_jobs=0, completed_jobs=0, failed_jobs=0,
            total_users=0, active_users_30d=0, total_gpu_hours=0.0,
            total_data_processed_gb=0.0, total_gross_savings_usd=0.0,
            total_vl_revenue_usd=0.0, total_net_savings_usd=0.0,
            total_migrations=0, total_spot_interruptions=0,
            avg_savings_pct=0.0, job_success_rate_pct=0.0,
        ),
        daily_30d=[], providers=[], regions=[], cohort_retention=[],
        gpu_breakdown=[], model_segments=[], top_users_by_ltv=[],
        smoke_tests=[], smoke_test_summary=[], bill_drift_flagged=[],
    )


# ── Main endpoint ─────────────────────────────────────────────────────────────

@router.get("/dashboard", response_model=DashboardResponse)
async def get_dashboard(_=Depends(_require_admin)) -> DashboardResponse:
    """
    Return all investor/admin dashboard metrics in a single call.

    Requires X-Admin-Secret header matching VAULTLAYER_ADMIN_SECRET env var.

    Response sections:
      - hero: Platform-wide lifetime totals
      - daily_30d: Last 30 days of daily activity (for charts)
      - providers: Per-provider breakdown (AWS vs Lambda vs CoreWeave etc.)
      - regions: Geographic distribution
      - cohort_retention: Monthly cohort retention table
      - gpu_breakdown: GPU type usage & savings
      - model_segments: Model size distribution (<1B, 1-7B, 7-13B, etc.)
      - top_users_by_ltv: Top 20 users by lifetime value to VaultLayer
    """
    t0 = time.perf_counter()
    sb = _get_supabase()
    if sb is None:
        logger.warning("[dashboard] Returning stub (no Supabase connection)")
        return _stub_dashboard()

    now_utc = datetime.now(timezone.utc)
    thirty_days_ago = (now_utc - timedelta(days=30)).date().isoformat()

    try:
        # ── Hero metrics ─────────────────────────────────────────────────────
        # platform_summary view (from migration 0004)
        ps = sb.table("platform_summary").select("*").execute()
        ps_row = ps.data[0] if ps.data else {}

        total_jobs      = _safe_int(ps_row.get("total_jobs"))
        active_jobs     = _safe_int(ps_row.get("active_jobs"))
        total_users     = _safe_int(ps_row.get("total_users"))
        gpu_hours       = _safe_float(ps_row.get("total_gpu_hours"))
        gross_savings   = _safe_float(ps_row.get("platform_gross_savings"))
        vl_revenue      = _safe_float(ps_row.get("platform_revenue"))
        net_savings     = _safe_float(ps_row.get("platform_net_delivered"))
        avg_savings_pct = _safe_float(ps_row.get("avg_savings_pct"))

        # Aggregate jobs table for additional hero stats
        jobs_agg = sb.table("jobs").select(
            "status, dataset_size_gb, interruption_count, migration_count"
        ).execute()
        jobs_rows = jobs_agg.data or []

        completed_jobs      = sum(1 for r in jobs_rows if r.get("status") == "completed")
        failed_jobs         = sum(1 for r in jobs_rows if r.get("status") == "failed")
        total_data_gb       = sum(_safe_float(r.get("dataset_size_gb")) for r in jobs_rows)
        total_interruptions = sum(_safe_int(r.get("interruption_count")) for r in jobs_rows)
        total_migrations    = sum(_safe_int(r.get("migration_count")) for r in jobs_rows)

        success_rate = (completed_jobs / max(total_jobs, 1)) * 100

        # Active users in last 30 days
        au_res = sb.table("jobs").select("user_id").gte(
            "started_at", (now_utc - timedelta(days=30)).isoformat()
        ).execute()
        active_users_30d = len({r["user_id"] for r in (au_res.data or [])})

        hero = HeroMetrics(
            total_jobs=total_jobs,
            active_jobs=active_jobs,
            completed_jobs=completed_jobs,
            failed_jobs=failed_jobs,
            total_users=total_users,
            active_users_30d=active_users_30d,
            total_gpu_hours=round(gpu_hours, 2),
            total_data_processed_gb=round(total_data_gb, 2),
            total_gross_savings_usd=round(gross_savings, 2),
            total_vl_revenue_usd=round(vl_revenue, 2),
            total_net_savings_usd=round(net_savings, 2),
            total_migrations=total_migrations,
            total_spot_interruptions=total_interruptions,
            avg_savings_pct=round(avg_savings_pct, 1),
            job_success_rate_pct=round(success_rate, 1),
        )

        # ── 30-day daily time series ──────────────────────────────────────────
        daily_res = sb.table("platform_daily_summary").select("*").gte(
            "summary_date", thirty_days_ago
        ).order("summary_date").execute()

        daily_30d = [
            DailyPoint(
                date=str(r["summary_date"]),
                jobs_started=_safe_int(r.get("jobs_started")),
                jobs_completed=_safe_int(r.get("jobs_completed")),
                gpu_hours=_safe_float(r.get("gpu_hours")),
                data_processed_gb=_safe_float(r.get("data_processed_gb")),
                gross_savings_usd=_safe_float(r.get("gross_savings_usd")),
                vl_revenue_usd=_safe_float(r.get("vl_revenue_usd")),
                new_users=_safe_int(r.get("new_users")),
                active_users=_safe_int(r.get("active_users")),
                spot_interruptions=_safe_int(r.get("spot_interruptions")),
                migrations_executed=_safe_int(r.get("migrations_executed")),
            )
            for r in (daily_res.data or [])
        ]

        # ── Provider breakdown ────────────────────────────────────────────────
        prov_res = sb.table("provider_scorecard").select("*").execute()
        providers = [
            ProviderRow(
                provider=r["provider"],
                total_jobs=_safe_int(r.get("total_jobs")),
                completed_jobs=_safe_int(r.get("completed_jobs")),
                success_rate_pct=_safe_float(r.get("success_rate_pct")),
                total_gpu_hours=_safe_float(r.get("total_gpu_hours")),
                avg_savings_pct=_safe_float(r.get("avg_savings_pct")),
                total_gross_savings_usd=_safe_float(r.get("total_gross_savings_usd")),
                total_vl_revenue_usd=_safe_float(r.get("total_vl_revenue_usd")),
                total_interruptions=_safe_int(r.get("total_interruptions")),
                avg_interruptions_per_job=_safe_float(r.get("avg_interruptions_per_job")),
            )
            for r in (prov_res.data or [])
        ]

        # ── Geographic breakdown ─────────────────────────────────────────────
        geo_res = sb.table("region_scorecard").select("*").execute()
        regions = [
            RegionRow(
                region=r["region"],
                provider=r["provider"],
                total_jobs=_safe_int(r.get("total_jobs")),
                total_gpu_hours=_safe_float(r.get("total_gpu_hours")),
                total_data_gb=_safe_float(r.get("total_data_gb")),
                total_gross_savings_usd=_safe_float(r.get("total_gross_savings_usd")),
            )
            for r in (geo_res.data or [])
        ]

        # ── Cohort retention ─────────────────────────────────────────────────
        cohort_res = sb.table("user_cohort_retention").select("*").order(
            "signup_cohort"
        ).limit(120).execute()  # 10 cohorts × 12 months

        cohort_retention = [
            CohortRow(
                cohort_label=str(r["cohort_label"]),
                month_offset=_safe_int(r.get("month_offset")),
                cohort_size=_safe_int(r.get("cohort_size")),
                returning_users=_safe_int(r.get("returning_users")),
                retention_pct=_safe_float(r.get("retention_pct")),
            )
            for r in (cohort_res.data or [])
        ]

        # ── GPU type breakdown ────────────────────────────────────────────────
        gpu_res = sb.table("gpu_type_breakdown").select("*").execute()
        gpu_breakdown = [
            GpuRow(
                gpu_type=r["gpu_type"],
                total_jobs=_safe_int(r.get("total_jobs")),
                total_gpu_hours=_safe_float(r.get("total_gpu_hours")),
                avg_model_params_b=_safe_float(r.get("avg_model_params_b")),
                total_gross_savings_usd=_safe_float(r.get("total_gross_savings_usd")),
                avg_savings_pct=_safe_float(r.get("avg_savings_pct")),
            )
            for r in (gpu_res.data or [])
        ]

        # ── Model size segmentation ───────────────────────────────────────────
        seg_res = sb.table("model_size_segments").select("*").execute()
        model_segments = [
            ModelSegmentRow(
                model_size_bucket=r["model_size_bucket"],
                total_jobs=_safe_int(r.get("total_jobs")),
                total_gpu_hours=_safe_float(r.get("total_gpu_hours")),
                total_gross_savings_usd=_safe_float(r.get("total_gross_savings_usd")),
            )
            for r in (seg_res.data or [])
        ]

        # ── Top users by lifetime value ───────────────────────────────────────
        ltv_res = sb.table("user_lifetime_value").select("*").order(
            "lifetime_vl_revenue_usd", desc=True
        ).limit(20).execute()

        top_users_by_ltv = [
            TopUserRow(
                user_id=r["user_id"],
                total_jobs=_safe_int(r.get("total_jobs")),
                completed_jobs=_safe_int(r.get("completed_jobs")),
                total_gpu_hours=_safe_float(r.get("total_gpu_hours")),
                total_data_gb=_safe_float(r.get("total_data_gb")),
                lifetime_gross_savings_usd=_safe_float(r.get("lifetime_gross_savings_usd")),
                lifetime_vl_revenue_usd=_safe_float(r.get("lifetime_vl_revenue_usd")),
                lifetime_net_savings_usd=_safe_float(r.get("lifetime_net_savings_usd")),
                avg_savings_pct=_safe_float(r.get("avg_savings_pct")),
                tenure_days=_safe_int(r.get("tenure_days")),
                first_job_at=_safe_str(r.get("first_job_at")),
                last_job_at=_safe_str(r.get("last_job_at")),
            )
            for r in (ltv_res.data or [])
        ]

        # ── Smoke tests (from job_runs where run_type='smoke_test') ──────────
        try:
            smoke_res = sb.table("job_runs").select(
                "provider, gpu_type, status, instance_id, billing_seconds, "
                "estimated_cost_usd, created_at"
            ).eq("run_type", "smoke_test").order("created_at", desc=True).limit(50).execute()
            smoke_rows = smoke_res.data or []
        except Exception as _smoke_err:
            logger.warning(f"[dashboard] Smoke test query failed (non-fatal): {_smoke_err}")
            smoke_rows = []

        smoke_tests = [
            SmokeTestRow(
                provider=r.get("provider", ""),
                gpu_type=r.get("gpu_type", ""),
                status="passed" if r.get("status") == "terminated" else "failed",
                instance_id=r.get("instance_id", ""),
                billing_seconds=_safe_float(r.get("billing_seconds")),
                estimated_cost_usd=_safe_float(r.get("estimated_cost_usd")),
                created_at=_safe_str(r.get("created_at")),
            )
            for r in smoke_rows
        ]

        # Build per-provider summary
        from collections import defaultdict
        _smoke_by_prov: dict[str, dict] = defaultdict(
            lambda: {"total": 0, "passed": 0, "failed": 0, "cost": 0.0, "last": ""}
        )
        for r in smoke_rows:
            p = r.get("provider", "unknown")
            _smoke_by_prov[p]["total"] += 1
            if r.get("status") == "terminated":
                _smoke_by_prov[p]["passed"] += 1
            else:
                _smoke_by_prov[p]["failed"] += 1
            _smoke_by_prov[p]["cost"] += _safe_float(r.get("estimated_cost_usd"))
            _ts = _safe_str(r.get("created_at"))
            if _ts > _smoke_by_prov[p]["last"]:
                _smoke_by_prov[p]["last"] = _ts

        smoke_test_summary = [
            SmokeTestSummaryRow(
                provider=prov,
                total_runs=s["total"],
                passed=s["passed"],
                failed=s["failed"],
                pass_rate_pct=round((s["passed"] / max(s["total"], 1)) * 100, 1),
                total_cost_usd=round(s["cost"], 4),
                last_run_at=s["last"],
            )
            for prov, s in sorted(_smoke_by_prov.items())
        ]

        # ── Bill-drift flagged rows (from job_runs where bill reconciliation
        #    found a delta > 25%). These never affect user charges — purely
        #    ops/margin signal. Limited to 20 most recent to keep response fast.
        bill_drift_flagged: list[BillDriftRow] = []
        try:
            drift_res = (
                supabase.table("job_runs")
                .select("run_id, provider, region, instance_id, terminated_at, "
                        "estimated_cost_usd, provider_billed_usd, user_charged_usd, metadata")
                .filter("metadata->>audit_status", "eq", "drift_flagged")
                .order("terminated_at", desc=True)
                .limit(20)
                .execute()
            )
            for r in (drift_res.data or []):
                meta = r.get("metadata") or {}
                bill_drift_flagged.append(BillDriftRow(
                    run_id=r.get("run_id", ""),
                    provider=r.get("provider") or "",
                    region=r.get("region") or "",
                    instance_id=r.get("instance_id") or "",
                    terminated_at=_safe_str(r.get("terminated_at")) or "",
                    estimated_cost_usd=_safe_float(r.get("estimated_cost_usd")),
                    provider_billed_usd=_safe_float(r.get("provider_billed_usd")),
                    user_charged_usd=_safe_float(r.get("user_charged_usd")),
                    audit_kind=str(meta.get("audit_kind", "")),
                    audit_delta_usd=_safe_float(meta.get("audit_delta_usd")),
                    audit_delta_pct=_safe_float(meta.get("audit_delta_pct")),
                    audit_at=str(meta.get("audit_at", "")),
                ))
        except Exception as e:
            logger.warning(f"[dashboard] bill_drift_flagged query failed (non-fatal): {e}")

        elapsed_ms = round((time.perf_counter() - t0) * 1000)
        logger.info(f"[dashboard] Built in {elapsed_ms}ms")

        return DashboardResponse(
            generated_at=now_utc.isoformat(),
            hero=hero,
            daily_30d=daily_30d,
            providers=providers,
            regions=regions,
            cohort_retention=cohort_retention,
            gpu_breakdown=gpu_breakdown,
            model_segments=model_segments,
            top_users_by_ltv=top_users_by_ltv,
            smoke_tests=smoke_tests,
            smoke_test_summary=smoke_test_summary,
            bill_drift_flagged=bill_drift_flagged,
        )

    except Exception as e:
        logger.error(f"[dashboard] Error building dashboard: {e}", exc_info=True)
        raise HTTPException(500, f"Dashboard query failed: {e}")


# ── Feedback dashboard ─────────────────────────────────────────────────────────

@router.get("/feedback", response_model=FeedbackDashboardResponse)
async def get_feedback_dashboard(_=Depends(_require_admin)) -> FeedbackDashboardResponse:
    """
    Return all feedback submissions with submitter email.

    Requires X-Admin-Secret header matching VAULTLAYER_ADMIN_SECRET env var.
    """
    sb = _get_supabase()
    if sb is None:
        raise HTTPException(503, "Database unavailable")

    try:
        # Fetch unique (non-duplicate) feedback rows newest first
        fb_res = sb.table("feedback").select(
            "id, type, message, status, created_at, resolved_at, pr_url, needs_more_info"
        ).neq("status", "duplicate").order("created_at", desc=True).limit(500).execute()
        fb_rows = fb_res.data or []

        # Fetch reporters (feedback_id → user_id)
        fb_ids = [r["id"] for r in fb_rows]
        reporters_by_fb: dict[str, str] = {}
        if fb_ids:
            rep_res = sb.table("feedback_reporters").select(
                "feedback_id, user_id"
            ).in_("feedback_id", fb_ids).execute()
            for rep in (rep_res.data or []):
                reporters_by_fb[rep["feedback_id"]] = rep["user_id"]

        # Fetch emails for those user_ids
        user_ids = list(set(reporters_by_fb.values()))
        email_by_user: dict[str, str] = {}
        if user_ids:
            users_res = sb.table("users").select(
                "user_id, email"
            ).in_("user_id", user_ids).execute()
            for u in (users_res.data or []):
                email_by_user[u["user_id"]] = u.get("email", "")

        items = []
        for r in fb_rows:
            uid = reporters_by_fb.get(r["id"])
            email = email_by_user.get(uid) if uid else None
            items.append(FeedbackRow(
                id=r["id"],
                type=r.get("type", ""),
                message=r.get("message", ""),
                status=r.get("status", ""),
                email=email,
                submitted_at=_safe_str(r.get("created_at")),
                resolved_at=_safe_str(r.get("resolved_at")),
                pr_url=r.get("pr_url"),
                needs_more_info=bool(r.get("needs_more_info", False)),
            ))

        pending  = sum(1 for i in items if i.status == "pending")
        resolved = sum(1 for i in items if i.status == "resolved")

        return FeedbackDashboardResponse(
            generated_at=datetime.now(timezone.utc).isoformat(),
            total=len(items),
            pending=pending,
            resolved=resolved,
            items=items,
        )

    except Exception as e:
        logger.error(f"[feedback-dashboard] Error: {e}", exc_info=True)
        raise HTTPException(500, f"Feedback dashboard query failed: {e}")
