"""
Fraud prevention for the free-credit tier.

Controls implemented at launch:
  1. IP /24 subnet rate-limit  — max 3 accounts per subnet per 30 days
  2. Staged credit release     — 200 credits immediate, 800 after first job >10 min
  3. Card fingerprint dedup    — one card per unique user (checked at top-up)
  4. Disposable email block    — handled by Clerk (configured in Clerk dashboard)
  5. GitHub/Google OAuth only  — enforced in Clerk dashboard, no email signup
"""
from __future__ import annotations

import logging
import os
from typing import Optional

from api.db import get_db, release_staged_bonus

logger = logging.getLogger(__name__)

# Max accounts per /24 subnet in a 30-day rolling window
MAX_ACCOUNTS_PER_SUBNET = int(os.environ.get("FRAUD_MAX_ACCOUNTS_PER_SUBNET", "3"))


def _extract_subnet(ip: str) -> Optional[str]:
    """Return the /24 prefix of an IPv4 address ('192.168.1.5' → '192.168.1')."""
    if not ip:
        return None
    parts = ip.split(".")
    if len(parts) == 4:
        return ".".join(parts[:3])
    return None  # IPv6 or invalid — skip subnet check


async def check_ip_rate_limit(ip: str) -> tuple[bool, str]:
    """
    Check if this IP's /24 subnet has too many recent signups.
    Returns (allowed: bool, reason: str).
    Updates the counter in Supabase on allowed signups.
    """
    subnet = _extract_subnet(ip)
    if not subnet:
        return True, "ok"  # IPv6 / unknown — allow

    db = get_db()
    res = db.table("signup_rate_limit").select("*").eq("subnet", subnet).execute()

    if not res.data:
        # First account from this subnet — insert and allow
        db.table("signup_rate_limit").insert({
            "subnet":        subnet,
            "account_count": 1,
        }).execute()
        return True, "ok"

    row = res.data[0]
    count = int(row["account_count"])

    if count >= MAX_ACCOUNTS_PER_SUBNET:
        logger.warning(f"[fraud] IP rate limit hit for subnet {subnet}: {count} accounts")
        return False, (
            f"Too many accounts created from this network ({count} in the last 30 days). "
            f"Contact support@vaultlayer.ai if this is a mistake."
        )

    # Increment counter
    db.table("signup_rate_limit").update({
        "account_count": count + 1,
        "last_seen_at":  "now()",
    }).eq("subnet", subnet).execute()
    return True, "ok"


async def check_card_fingerprint(user_id: str, stripe_card_fp: str) -> tuple[bool, str]:
    """
    Check if this Stripe card fingerprint has been used by a different user.
    Returns (allowed: bool, reason: str).
    """
    db = get_db()

    res = (
        db.table("stripe_card_fingerprints")
        .select("user_id")
        .eq("fingerprint", stripe_card_fp)
        .execute()
    )

    existing_users = {row["user_id"] for row in (res.data or [])}
    existing_users.discard(user_id)  # same user reusing their own card is fine

    if existing_users:
        logger.warning(
            f"[fraud] Card fingerprint {stripe_card_fp[:8]}… already used by "
            f"{len(existing_users)} other account(s). Blocking top-up for {user_id}."
        )
        return False, (
            "This payment method is already associated with another VaultLayer account. "
            "Contact support@vaultlayer.ai if you believe this is an error."
        )

    # Record this (user_id, fingerprint) pair
    db.table("stripe_card_fingerprints").upsert({
        "fingerprint": stripe_card_fp,
        "user_id":     user_id,
    }).execute()
    return True, "ok"


async def maybe_release_staged_bonus(user_id: str, job_runtime_seconds: float):
    """
    Called on every burn tick. Releases the 800 staged signup credits
    once the user's first job has been running for >10 minutes (600 seconds).
    """
    if job_runtime_seconds >= 600:
        await release_staged_bonus(user_id)
