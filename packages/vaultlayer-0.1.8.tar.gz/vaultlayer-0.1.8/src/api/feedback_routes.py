"""
VaultLayer API — feedback submission and status routes.

POST /api/v1/feedback        Submit crash report or feedback
GET  /api/v1/feedback/{id}/status  Check resolution status
"""
from __future__ import annotations

import logging
import os
from typing import Optional

from fastapi import APIRouter, Header, HTTPException, Request

from api.db import get_db

logger = logging.getLogger(__name__)

router = APIRouter()

_MAX_MESSAGE = 5_000
_MAX_LOG_SNIPPET = 10_000
_MAX_TRACEBACK = 5_000


async def _resolve_user_id(authorization: Optional[str]) -> Optional[str]:
    """
    Resolve a user_id from a Bearer token header.
    Returns None if token is missing or invalid (feedback is still accepted anonymously).
    """
    if not authorization or not authorization.startswith("Bearer "):
        return None
    raw_token = authorization.removeprefix("Bearer ").strip()
    if not raw_token:
        return None
    import hashlib
    token_hash = hashlib.sha256(raw_token.encode()).hexdigest()
    try:
        db = get_db()
        result = (
            db.table("api_tokens")
            .select("user_id")
            .eq("token_hash", token_hash)
            .is_("revoked_at", "null")
            .execute()
        )
        rows = result.data or []
        if rows:
            return rows[0].get("user_id")
    except Exception as exc:
        logger.warning("[feedback] Token resolution error: %s", exc)
    return None


@router.post("/api/v1/feedback")
async def submit_feedback(
    request: Request,
    authorization: Optional[str] = Header(default=None),
):
    """
    Accept a crash report or user feedback.
    Deduplicates via fingerprint. Returns feedback_id.
    """
    body = await request.json()

    # Extract and truncate fields
    fb_type = body.get("type", "feedback")
    if fb_type not in ("bug", "feedback", "auto_crash", "auto_agent"):
        fb_type = "feedback"

    message = str(body.get("message", ""))[:_MAX_MESSAGE]
    if not message:
        raise HTTPException(status_code=422, detail="message is required")

    log_snippet = body.get("log_snippet")
    if log_snippet:
        log_snippet = str(log_snippet)[:_MAX_LOG_SNIPPET]

    traceback_text = body.get("traceback")
    if traceback_text:
        traceback_text = str(traceback_text)[:_MAX_TRACEBACK]

    job_id = body.get("job_id")
    command = body.get("command")
    gpu_type = body.get("gpu_type")
    provider = body.get("provider")
    error_type = body.get("error_type")
    fingerprint = body.get("fingerprint")
    source = body.get("source", "unknown")

    user_id = await _resolve_user_id(authorization)

    db = get_db()

    # ── Deduplication ─────────────────────────────────────────────────────────
    primary_feedback_id: Optional[str] = None
    status = "pending"

    if fingerprint:
        try:
            dup_result = (
                db.table("feedback")
                .select("id, status, primary_feedback_id")
                .eq("fingerprint", fingerprint)
                .not_.in_("status", ["duplicate", "resolved"])
                .order("created_at", desc=True)
                .limit(1)
                .execute()
            )
            existing = dup_result.data or []
            if existing:
                primary = existing[0]
                primary_feedback_id = primary.get("primary_feedback_id") or primary.get("id")
                status = "duplicate"
        except Exception as exc:
            logger.warning("[feedback] Dedup query error: %s", exc)

    # ── Insert feedback row ───────────────────────────────────────────────────
    row = {
        "type": fb_type,
        "message": message,
        "status": status,
    }
    if user_id:
        row["user_id"] = user_id
    if job_id:
        row["job_id"] = str(job_id)
    if log_snippet:
        row["log_snippet"] = log_snippet
    if command:
        row["command"] = str(command)
    if gpu_type:
        row["gpu_type"] = str(gpu_type)
    if provider:
        row["provider"] = str(provider)
    if error_type:
        row["error_type"] = str(error_type)
    if traceback_text:
        row["traceback"] = traceback_text
    if fingerprint:
        row["fingerprint"] = str(fingerprint)
    if primary_feedback_id:
        row["primary_feedback_id"] = primary_feedback_id

    try:
        insert_result = db.table("feedback").insert(row).execute()
        inserted = insert_result.data or []
        feedback_id = inserted[0]["id"] if inserted else "fb_unknown"
    except Exception as exc:
        logger.error("[feedback] Insert error: %s", exc)
        raise HTTPException(status_code=500, detail="Could not save feedback")

    # ── Upsert feedback_reporters ─────────────────────────────────────────────
    if user_id:
        # Link this reporter to the primary (or this) feedback for dedup notification
        target_id = primary_feedback_id or feedback_id
        try:
            db.table("feedback_reporters").upsert(
                {"feedback_id": target_id, "user_id": user_id},
                on_conflict="feedback_id,user_id",
            ).execute()
        except Exception as exc:
            logger.warning("[feedback] feedback_reporters upsert error: %s", exc)

    logger.info("[feedback] Saved %s (%s) status=%s", feedback_id, fb_type, status)
    return {"id": feedback_id, "status": "received"}


@router.get("/api/v1/feedback/{feedback_id}/status")
async def get_feedback_status(feedback_id: str):
    """Return resolution status for a feedback item."""
    db = get_db()
    try:
        result = (
            db.table("feedback")
            .select("id, status, pr_url, resolved_at, needs_more_info")
            .eq("id", feedback_id)
            .execute()
        )
        rows = result.data or []
    except Exception as exc:
        logger.error("[feedback] Status query error: %s", exc)
        raise HTTPException(status_code=500, detail="Database error")

    if not rows:
        raise HTTPException(status_code=404, detail="Feedback not found")

    row = rows[0]
    return {
        "id": row.get("id"),
        "status": row.get("status"),
        "pr_url": row.get("pr_url"),
        "resolved_at": row.get("resolved_at"),
        "needs_more_info": row.get("needs_more_info"),
    }
