"""Phase 3-lite: SQLite-backed persistence for unified_queue.

Replaces in-memory `asyncio.PriorityQueue` with a persistent heap
backed by SQLite. Survives Railway restart without needing Redis infra.

Feature-flagged via `VL_UNIFIED_QUEUE_PERSIST=1` (on top of
`VL_UNIFIED_QUEUE=1`). Default off — in-memory behavior unchanged.

Not multi-worker-safe (SQLite file lock contention). Phase 3 full
(Redis Streams + consumer groups) comes later. This is a stopgap.

Design: small-surface-area module; `unified_queue.py` imports and
calls `persist_enqueue`/`persist_dequeue` when flag is on.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
from typing import Any, Optional

logger = logging.getLogger(__name__)

DB_PATH = os.environ.get(
    "VL_UNIFIED_QUEUE_DB",
    "/tmp/vl_unified_queue.sqlite",
)

_db_lock = threading.Lock()


def feature_enabled() -> bool:
    """Persistence is enabled whenever the unified queue is enabled.
    One flag, not two — we don't want a user flipping `VL_UNIFIED_QUEUE=1`
    and accidentally running with non-durable in-memory state.

    (If you explicitly need to disable persistence without disabling the
    queue — e.g. an ephemeral test harness — set
    `VL_UNIFIED_QUEUE_PERSIST_DISABLE=1`. Default off.)
    """
    if os.environ.get("VL_UNIFIED_QUEUE", "0") != "1":
        return False
    return os.environ.get("VL_UNIFIED_QUEUE_PERSIST_DISABLE", "0") != "1"


def _get_conn() -> sqlite3.Connection:
    """One connection per call — SQLite cross-thread shenanigans avoided."""
    # check_same_thread=False because we might serve multiple asyncio tasks
    # in the same thread via the same module (single-process deploy).
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=10.0)
    conn.execute("PRAGMA journal_mode=WAL")  # concurrent readers + one writer
    conn.execute("PRAGMA synchronous=NORMAL")  # WAL makes NORMAL safe
    return conn


def _ensure_schema() -> None:
    with _db_lock:
        conn = _get_conn()
        try:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS queue_items (
                    job_id        TEXT PRIMARY KEY,
                    priority      INTEGER NOT NULL,
                    enqueued_at   REAL    NOT NULL,
                    attempt       INTEGER NOT NULL DEFAULT 0,
                    backoff_until REAL    NOT NULL DEFAULT 0,
                    retry_context TEXT    NOT NULL DEFAULT '{}'
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS queue_items_prio "
                "ON queue_items (priority, enqueued_at)"
            )
            conn.commit()
        finally:
            conn.close()


def persist_enqueue(
    job_id: str,
    priority: int,
    enqueued_at: float,
    attempt: int = 0,
    backoff_until: float = 0.0,
    retry_context: Optional[dict[str, Any]] = None,
) -> None:
    """Write / upsert an item into the persistent queue."""
    if not feature_enabled():
        return
    _ensure_schema()
    with _db_lock:
        conn = _get_conn()
        try:
            conn.execute(
                """
                INSERT OR REPLACE INTO queue_items
                    (job_id, priority, enqueued_at, attempt, backoff_until, retry_context)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    job_id,
                    priority,
                    enqueued_at,
                    attempt,
                    backoff_until,
                    json.dumps(retry_context or {}),
                ),
            )
            conn.commit()
        finally:
            conn.close()


def persist_dequeue(job_id: str) -> None:
    """Remove an item from persistence when it's picked up by a worker."""
    if not feature_enabled():
        return
    _ensure_schema()
    with _db_lock:
        conn = _get_conn()
        try:
            conn.execute("DELETE FROM queue_items WHERE job_id = ?", (job_id,))
            conn.commit()
        finally:
            conn.close()


def restore_all() -> list[dict[str, Any]]:
    """Read every persisted item on startup. Returned items should be
    re-pushed into the in-memory heap by `unified_queue` during init.

    If the DB file is corrupt or unreadable, log + rename the corrupt
    file aside and return an empty list — the queue falls back to
    in-memory empty and startup continues. Better to lose queued work
    than crash the whole app.
    """
    if not feature_enabled():
        return []
    try:
        _ensure_schema()
        with _db_lock:
            conn = _get_conn()
            try:
                rows = conn.execute(
                    "SELECT job_id, priority, enqueued_at, attempt, backoff_until, retry_context "
                    "FROM queue_items ORDER BY priority ASC, enqueued_at ASC"
                ).fetchall()
                result = []
                for row in rows:
                    try:
                        ctx = json.loads(row[5]) if row[5] else {}
                    except json.JSONDecodeError:
                        ctx = {}
                    result.append(
                        {
                            "job_id": row[0],
                            "priority": row[1],
                            "enqueued_at": row[2],
                            "attempt": row[3],
                            "backoff_until": row[4],
                            "retry_context": ctx,
                        }
                    )
                return result
            finally:
                conn.close()
    except sqlite3.DatabaseError as e:
        # File is corrupt ("file is not a database", "database disk image
        # is malformed", etc.) — move it aside so next run starts fresh.
        import time as _time
        corrupt_path = f"{DB_PATH}.corrupt.{int(_time.time())}"
        try:
            if os.path.exists(DB_PATH):
                os.rename(DB_PATH, corrupt_path)
                logger.error(
                    f"unified_queue_persist: DB file at {DB_PATH} is corrupt "
                    f"({e!s}). Moved to {corrupt_path}. Starting with empty queue."
                )
        except OSError as rename_err:
            logger.error(
                f"unified_queue_persist: DB at {DB_PATH} corrupt AND could "
                f"not be moved aside: {rename_err!s}. Original error: {e!s}"
            )
        return []
    except Exception as e:
        # Any other error (OSError, PermissionError, etc.) — log and
        # fall back to empty. Don't take down the app over queue state.
        logger.error(
            f"unified_queue_persist: unexpected error reading DB at {DB_PATH}: "
            f"{e!s}. Starting with empty queue."
        )
        return []


def clear_all() -> None:
    """Drop everything from persistence. Test-only."""
    _ensure_schema()
    with _db_lock:
        conn = _get_conn()
        try:
            conn.execute("DELETE FROM queue_items")
            conn.commit()
        finally:
            conn.close()


def depth() -> int:
    """Count of items currently persisted."""
    if not feature_enabled():
        return 0
    _ensure_schema()
    with _db_lock:
        conn = _get_conn()
        try:
            row = conn.execute("SELECT COUNT(*) FROM queue_items").fetchone()
            return int(row[0]) if row else 0
        finally:
            conn.close()
