"""
VaultLayer — Managed Credential Reader (internal only)

Previously this module also exposed `POST /api/v1/credentials/provider`
and `GET  /api/v1/credentials/providers` as public, user-authenticated
HTTP endpoints that vended VaultLayer's raw provider API keys (AWS
access keys, Lambda Labs API key, RunPod API key, Vast.ai API key,
GCP service-account JSON, etc.) to any user with a positive credit
balance. That was a standing credential-exfiltration surface:

  * The trust boundary was wrong — this was a customer-facing endpoint
    that handed back company cloud-account credentials.
  * The only real caller was the Railway worker itself, which doesn't
    need an HTTP round-trip to read its own environment variables.
  * CLI BYOC users should supply their own provider keys.

The endpoints have been removed. `_read_provider_credentials()` is
still exported for in-process use by the broker (see
`BrokerAgent._get_managed_credentials` in agents/broker/agent.py).
"""
from __future__ import annotations

import logging
import os
import time
from collections import defaultdict, deque
from typing import Optional

from fastapi import APIRouter

logger = logging.getLogger(__name__)

# Retain an empty APIRouter for backward compatibility with main.py's
# `app.include_router(credentials.router)` call. No routes are registered.
router = APIRouter(prefix="/api/v1", tags=["credentials"])

# ── Rate limiting (in-memory sliding window, 30 fetches/min per user) ─────────
# Kept for any future internal caller that wants to throttle itself; not wired
# to an HTTP route today.
_CRED_LIMIT = 30
_WINDOW_SEC = 60
_cred_timestamps: defaultdict[str, deque] = defaultdict(lambda: deque())


def _check_rate_limit(user_id: str) -> bool:
    """Return True if allowed, False if rate limit exceeded."""
    now = time.monotonic()
    dq = _cred_timestamps[user_id]
    while dq and now - dq[0] > _WINDOW_SEC:
        dq.popleft()
    if len(dq) >= _CRED_LIMIT:
        return False
    dq.append(now)
    return True


# ── Provider → Railway env var mapping ───────────────────────────────────────
# Each provider maps to the env vars needed. The broker reads these directly
# via _read_provider_credentials() (no HTTP round-trip).
#
# Format: provider_name → dict of credential_key → env_var_name
_PROVIDER_ENV_MAP: dict[str, dict[str, str]] = {
    "lambda_labs": {
        "api_key": "VL_LAMBDA_LABS_API_KEY",
    },
    "runpod": {
        "api_key": "VL_RUNPOD_API_KEY",
    },
    "vast_ai": {
        "api_key": "VL_VAST_AI_API_KEY",
    },
    "hyperstack": {
        "api_key": "VL_HYPERSTACK_API_KEY",
    },
    "crusoe": {
        # Crusoe uses HTTP Basic auth: base64(api_key_id:api_secret_key)
        "api_key":    "VL_CRUSOE_API_KEY",     # API Key ID from Crusoe console
        "api_secret": "VL_CRUSOE_API_SECRET",  # API Secret Key from Crusoe console
    },
    "aws": {
        "access_key_id":     "VL_AWS_ACCESS_KEY_ID",
        "secret_access_key": "VL_AWS_SECRET_ACCESS_KEY",
        "region":            "VL_AWS_DEFAULT_REGION",
    },
    "gcp": {
        # Split SA JSON into individual fields — Railway UI truncates large JSON blobs.
        # Broker reconstructs service_account_info dict from these three values.
        "client_email": "VL_GCP_CLIENT_EMAIL",
        "private_key":  "VL_GCP_PRIVATE_KEY",
        "project_id":   "VL_GCP_PROJECT_ID",
        "region":       "VL_GCP_REGION",
        "zone":         "VL_GCP_ZONE",
    },
    "coreweave": {
        "api_key":   "VL_COREWEAVE_API_KEY",
        "namespace": "VL_COREWEAVE_NAMESPACE",
    },
    "nebius": {
        "service_account_key": "VL_NEBIUS_SA_KEY",
        "folder_id":           "VL_NEBIUS_FOLDER_ID",
    },
    "azure": {
        "subscription_id": "VL_AZURE_SUBSCRIPTION_ID",
        "tenant_id":       "VL_AZURE_TENANT_ID",
        "client_id":       "VL_AZURE_CLIENT_ID",
        "client_secret":   "VL_AZURE_CLIENT_SECRET",
        "resource_group":  "VL_AZURE_RESOURCE_GROUP",
        "location":        "VL_AZURE_LOCATION",
    },
    "voltage_park": {
        "api_key": "VL_VOLTAGE_PARK_API_KEY",
    },
    "r2": {
        "access_key_id":     "R2_ACCESS_KEY_ID",
        "secret_access_key": "R2_SECRET_ACCESS_KEY",
        "endpoint":          "R2_ENDPOINT",
        "bucket":            "R2_BUCKET",
    },
}

SUPPORTED_PROVIDERS = set(_PROVIDER_ENV_MAP.keys())


def _read_provider_credentials(provider: str) -> Optional[dict[str, str]]:
    """
    Read credentials for *provider* from Railway environment variables.

    Returns None if any required var is missing (provider not configured).
    Never raises — missing vars → None, which the caller should treat as
    "this provider isn't available on this deployment".

    Callers: `BrokerAgent._get_managed_credentials` (in-process), and
    internal ops tooling. NOT exposed via HTTP; the public endpoint that
    used to wrap this was removed after the security audit.
    """
    env_map = _PROVIDER_ENV_MAP.get(provider)
    if not env_map:
        return None

    creds: dict[str, str] = {}
    for cred_key, env_var in env_map.items():
        value = os.environ.get(env_var, "")
        if not value:
            logger.warning(
                "[credentials] %s env var missing for provider=%s — "
                "add it to Railway Variables",
                env_var, provider,
            )
            return None
        creds[cred_key] = value

    return creds
