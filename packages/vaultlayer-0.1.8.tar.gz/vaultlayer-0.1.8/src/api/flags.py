"""
VaultLayer — Feature Flags
==========================
Single source of truth for runtime feature flags.

Usage
-----
    from api.flags import TESTING_MODE

    if TESTING_MODE:
        # skip auth / billing
        ...

Flags
-----
VL_TESTING_MODE=1
    Disables authentication AND revenue tracking.
    When ON:
      • require_auth()  — accepts any token (or no token); returns a mock user
      • Clerk webhook   — skipped (no Supabase user creation)
      • Credits         — all balance/reserve/burn/settle calls are no-ops;
                          balance always returns TESTING_CREDITS_BALANCE
      • Stripe          — checkout and webhook are no-ops; no Stripe API calls
      • Gainshare       — not reported to Stripe
    When OFF (default / production):
      • Full auth via Supabase + Clerk
      • Full credit accounting via Supabase
      • Full Stripe billing

    Safe to toggle mid-deploy — the flag is read once at startup.
    Set VL_TESTING_MODE=0 or unset to re-enable everything.

TESTING_CREDITS_BALANCE
    Credits returned by the mock balance in testing mode.
    Default: 1_000_000 (=$10,000) — never blocks any job.
"""

import logging
import os

logger = logging.getLogger(__name__)

# ── Primary flag ──────────────────────────────────────────────────────────────

_raw = os.environ.get("VL_TESTING_MODE", "0").strip().lower()
TESTING_MODE: bool = _raw in ("1", "true", "yes", "on")

# ── Testing-mode defaults ─────────────────────────────────────────────────────

#: Mock user returned by require_auth() in testing mode.
TESTING_USER: dict = {
    "user_id": "vl_test_user",
    "email":   "test@vaultlayer.dev",
    "plan":    "pro",
}

#: Credits balance returned by all balance queries in testing mode.
TESTING_CREDITS_BALANCE: int = int(os.environ.get("VL_TESTING_CREDITS", "1_000_000"))

# ── Startup announcement ──────────────────────────────────────────────────────

if TESTING_MODE:
    logger.warning(
        "\n"
        "┌─────────────────────────────────────────────────────────┐\n"
        "│         VL_TESTING_MODE = ON                            │\n"
        "│                                                         │\n"
        "│  ✗ Authentication  — DISABLED (all tokens accepted)     │\n"
        "│  ✗ Revenue / Billing — DISABLED (no Supabase / Stripe)  │\n"
        "│                                                         │\n"
        "│  To re-enable: unset VL_TESTING_MODE or set it to 0    │\n"
        "└─────────────────────────────────────────────────────────┘"
    )
else:
    logger.info("[flags] VL_TESTING_MODE=OFF — authentication and revenue ENABLED")
