"""Admin-issued invite tokens for closed-beta onboarding.

Flow:
  1. Admin calls POST /api/v1/admin/invites with {email, credits_cents?, note?}
     and the X-Internal-Admin-Token header. Server generates a fresh
     vl_invite_... token, stores only its hash, and returns the plaintext
     once. Admin emails this out-of-band.
  2. User stores VL_TOKEN=vl_invite_... in their local .env and runs
     `vaultlayer init`, which POSTs to /api/v1/auth/redeem-invite.
  3. Server validates the invite, creates a users row, issues a long-lived
     vl_live_... token, marks redeemed_at, and returns the user's token.

Design notes:
  * Plaintext tokens are never logged. We log prefix-only ("vl_invite_ab12…")
    to make audit trails usable without leaking secrets.
  * Admin endpoint is fail-closed: require_internal_admin returns 503 when
    VL_INTERNAL_ADMIN_TOKEN isn't set; 404 when the header is wrong.
  * Redeem endpoint is public (no prior auth) — the invite token itself is
    the credential.
  * Email validation is intentionally light (regex) — RFC-compliant parsing
    belongs in a deps pkg; we just reject obvious junk.
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import os
import re
import secrets
import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr

from api.auth import require_internal_admin
from api.db import _db_call, create_api_token, create_user, get_db, hash_token

logger = logging.getLogger(__name__)

admin_invites_router = APIRouter(prefix="/api/v1/admin", tags=["admin", "invites"])
public_invites_router = APIRouter(prefix="/api/v1/auth", tags=["auth", "invites"])

# ── Constants ────────────────────────────────────────────────────────────────

INVITE_PREFIX = "vl_invite_"
# 32 hex chars = 128 bits of entropy. Same as api_tokens (40-char suffix).
INVITE_ENTROPY_HEX_CHARS = 32

# Default initial credit grant on redemption (cents). $10 of trial credit.
DEFAULT_INVITE_CREDITS_CENTS = 1000

# Very light email shape check — rejects obvious junk (no @, no TLD). Full
# RFC-822 validation requires a real library; keep lightweight for now.
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$")


# ── Payload models ──────────────────────────────────────────────────────────

class CreateInviteRequest(BaseModel):
    email: str
    credits_cents: Optional[int] = None  # defaults to 1000 ($10)
    note: Optional[str] = None           # admin-facing memo
    # Optional TTL — caller passes an ISO8601 timestamp or None for no expiry
    expires_at: Optional[datetime] = None


class CreateInviteResponse(BaseModel):
    invite_id: str
    email: str
    invite_token: str    # plaintext — shown once
    token_prefix: str
    credits_cents: int
    expires_at: Optional[datetime] = None


class RedeemInviteRequest(BaseModel):
    invite_token: str


class RedeemInviteResponse(BaseModel):
    user_id: str
    email: str
    user_token: str       # long-lived vl_live_... — store in .env
    credits_cents: int


class InviteListItem(BaseModel):
    invite_id: str
    email: str
    token_prefix: str     # e.g. "vl_invite_ab12cd34ef" — safe for display
    credits_cents: int
    note: Optional[str] = None
    created_at: datetime
    expires_at: Optional[datetime] = None
    redeemed_at: Optional[datetime] = None
    redeemed_by_user_id: Optional[str] = None
    revoked_at: Optional[datetime] = None


class InviteListResponse(BaseModel):
    invites: list[InviteListItem]
    count: int


# ── Helpers ─────────────────────────────────────────────────────────────────

def _generate_invite_token() -> tuple[str, str, str]:
    """Return (plaintext, sha256_hash, prefix_for_logging)."""
    raw = INVITE_PREFIX + secrets.token_hex(INVITE_ENTROPY_HEX_CHARS // 2 * 2)
    # Wait — token_hex(n) returns 2n hex chars. Want 32 hex chars = 16 bytes.
    # Recompute to be explicit:
    raw = INVITE_PREFIX + secrets.token_hex(16)  # 32 hex chars
    hashed = hashlib.sha256(raw.encode()).hexdigest()
    # First 20 chars e.g. "vl_invite_ab12cd34ef" — safe for audit logs.
    prefix = raw[:20]
    return raw, hashed, prefix


def _validate_email_shape(email: str) -> None:
    if not email or not _EMAIL_RE.match(email):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid email format: {email!r}",
        )


# ── Admin endpoint ──────────────────────────────────────────────────────────

@admin_invites_router.post(
    "/invites",
    response_model=CreateInviteResponse,
    dependencies=[Depends(require_internal_admin)],
)
async def create_invite(body: CreateInviteRequest) -> CreateInviteResponse:
    """Generate a fresh invite token for `email`. Plaintext is returned once.

    The DB stores only the SHA256 hash. Use GET /admin/invites (future) to
    list outstanding invites without leaking the token.

    Rejects if an active (un-redeemed, un-revoked) invite already exists for
    this email — admins should revoke the old one first with
    POST /admin/invites/{invite_id}/revoke (future).
    """
    email = body.email.strip().lower()
    _validate_email_shape(email)

    raw, hashed, prefix = _generate_invite_token()
    credits = body.credits_cents if body.credits_cents is not None else DEFAULT_INVITE_CREDITS_CENTS
    if credits < 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="credits_cents must be >= 0",
        )

    invite_row = {
        "email":         email,
        "token_hash":    hashed,
        "token_prefix":  prefix,
        "credits_cents": credits,
        "note":          body.note,
        "expires_at":    body.expires_at.isoformat() if body.expires_at else None,
    }
    try:
        db = get_db()
        res = _db_call(
            lambda: db.table("invite_tokens").insert(invite_row).execute(),
            label="invite:create",
        )
        # The insert may "succeed" HTTP-wise but return no data when the
        # returning=minimal PostgREST default is active. In that case we
        # need to re-fetch the row we just wrote via the token_hash.
        if res and res.data:
            row = res.data[0]
        else:
            # Fallback: look up the row we just inserted by its hash.
            logger.info(f"[invite:create] Insert returned empty data for {email}; re-fetching by token_hash")
            fetch = _db_call(
                lambda: db.table("invite_tokens")
                    .select("invite_id, email, credits_cents, token_prefix")
                    .eq("token_hash", hashed)
                    .execute(),
                label="invite:refetch",
            )
            if not fetch or not fetch.data:
                # Insert neither returned data nor landed in DB — real failure
                raise RuntimeError(
                    f"Insert returned no data and row not found post-insert "
                    f"(email={email}, prefix={prefix}). "
                    f"res={res!r}"
                )
            row = fetch.data[0]
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        msg = str(e)
        err_class = type(e).__name__
        # The EXCLUDE constraint active_invite_per_email blocks double-invite.
        if "active_invite_per_email" in msg or "conflict" in msg.lower():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    f"An active invite already exists for {email}. "
                    f"Revoke the old invite before issuing a new one."
                ),
            )
        # Diagnostic: admin endpoints are safe to surface the underlying
        # error (gated by X-Internal-Admin-Token, no public info leak). A
        # generic "Invite storage unavailable" 503 was hiding real errors
        # like schema-cache mismatches, missing columns, RLS blocks.
        logger.error(
            f"[invite:create] DB insert failed for {email}: "
            f"{err_class}: {msg}\n{traceback.format_exc()}"
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Invite storage failed ({err_class}): {msg[:300]}",
        )

    logger.info(
        f"[invite:create] Issued invite for {email} "
        f"(prefix={prefix}, credits_cents={credits}, "
        f"invite_id={row.get('invite_id')})"
    )
    return CreateInviteResponse(
        invite_id=str(row.get("invite_id", "")),
        email=email,
        invite_token=raw,
        token_prefix=prefix,
        credits_cents=credits,
        expires_at=body.expires_at,
    )


# ── Admin: list invites ─────────────────────────────────────────────────────

@admin_invites_router.get(
    "/invites",
    response_model=InviteListResponse,
    dependencies=[Depends(require_internal_admin)],
)
async def list_invites(
    status_filter: Optional[str] = None,
    limit: int = 50,
) -> InviteListResponse:
    """List invites with optional status filter.

    `status_filter`:
      * None  — all invites (default)
      * "open" — not-redeemed AND not-revoked (excludes expired; check client-side)
      * "redeemed" — redeemed_at IS NOT NULL
      * "revoked" — revoked_at IS NOT NULL
    """
    # Validate status_filter BEFORE touching the DB so a bad value gives
    # a clean 400 without going through connection setup.
    if status_filter is not None and status_filter not in ("open", "redeemed", "revoked"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"status_filter must be one of: open, redeemed, revoked (got {status_filter!r})",
        )
    limit = max(1, min(limit, 200))
    try:
        db = get_db()
        q = db.table("invite_tokens").select(
            "invite_id, email, token_prefix, credits_cents, note, "
            "created_at, expires_at, redeemed_at, redeemed_by_user_id, revoked_at"
        )
        if status_filter == "open":
            q = q.is_("redeemed_at", "null").is_("revoked_at", "null")
        elif status_filter == "redeemed":
            q = q.not_.is_("redeemed_at", "null")
        elif status_filter == "revoked":
            q = q.not_.is_("revoked_at", "null")
        res = _db_call(
            lambda: q.order("created_at", desc=True).limit(limit).execute(),
            label="invite:list",
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[invite:list] DB query failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Invite list unavailable.",
        )
    return InviteListResponse(
        invites=[InviteListItem(**r) for r in (res.data or [])],
        count=len(res.data or []),
    )


# ── Admin: revoke invite ────────────────────────────────────────────────────

@admin_invites_router.post(
    "/invites/{invite_id}/revoke",
    dependencies=[Depends(require_internal_admin)],
)
async def revoke_invite(invite_id: str) -> dict:
    """Mark an invite revoked. Irreversible. After revocation the token is
    permanently un-redeemable; admin may issue a fresh invite for the same
    email.

    Returns 404 for unknown invite_id (same shape as /redeem for
    enumeration-resistance). Returns 409 if already redeemed — redeemed
    invites can't be revoked (the user already has a working account; use
    /api/v1/admin/users/{id}/deactivate for that instead)."""
    try:
        db = get_db()
        res = _db_call(
            lambda: db.table("invite_tokens")
                .select("invite_id, redeemed_at, revoked_at, token_prefix")
                .eq("invite_id", invite_id)
                .execute(),
            label="invite:revoke_lookup",
        )
    except Exception as e:
        logger.error(f"[invite:revoke] Lookup failed for {invite_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Invite service temporarily unavailable.",
        )
    if not res.data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Invite not found.",
        )
    row = res.data[0]
    if row.get("revoked_at"):
        # Idempotent — revoking an already-revoked invite is a no-op.
        return {"ok": True, "already_revoked": True,
                "revoked_at": row["revoked_at"]}
    if row.get("redeemed_at"):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                "Invite has already been redeemed. Deactivate the user "
                "account instead of revoking the spent invite."
            ),
        )
    try:
        now = datetime.now(timezone.utc).isoformat()
        _db_call(
            lambda: db.table("invite_tokens").update({
                "revoked_at": now,
            }).eq("invite_id", invite_id).execute(),
            label="invite:revoke_mark",
        )
    except Exception as e:
        logger.error(f"[invite:revoke] Update failed for {invite_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Invite revoke failed.",
        )
    logger.info(
        f"[invite:revoke] Revoked invite {row.get('token_prefix', '?')} "
        f"(invite_id={invite_id})"
    )
    return {"ok": True, "revoked_at": now}


# ── Redemption endpoint (public — invite token IS the credential) ───────────

@public_invites_router.post(
    "/redeem-invite",
    response_model=RedeemInviteResponse,
)
async def redeem_invite(body: RedeemInviteRequest) -> RedeemInviteResponse:
    """Exchange an invite token for a long-lived user token.

    Called by `vaultlayer init` during first-time setup. Performs all checks
    server-side (existence, not-redeemed, not-revoked, not-expired) and
    returns a fresh vl_live_... token plus the user's id/email.

    After a successful redemption:
      * `users` row exists keyed to the invite's email
      * `api_tokens` row exists for the new long-lived token
      * `invite_tokens.redeemed_at` is set
      * Invite token (vl_invite_...) becomes permanently un-reusable
    """
    raw = (body.invite_token or "").strip()
    if not raw.startswith(INVITE_PREFIX):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invite token must start with {INVITE_PREFIX!r}",
        )

    hashed = hashlib.sha256(raw.encode()).hexdigest()
    try:
        db = get_db()
        res = _db_call(
            lambda: db.table("invite_tokens")
                .select("invite_id, email, credits_cents, redeemed_at, revoked_at, expires_at, token_prefix")
                .eq("token_hash", hashed)
                .execute(),
            label="invite:redeem_lookup",
        )
    except Exception as e:
        logger.error(f"[invite:redeem] DB lookup failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Invite service temporarily unavailable.",
        )
    if not res.data:
        # Constant-time-ish: same 404 shape regardless of which failure mode
        # the attacker is probing. Don't leak whether it's "not found" vs
        # "already redeemed" vs "expired" at the network level.
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Invite not found, already redeemed, or revoked.",
        )

    row = res.data[0]
    prefix = row.get("token_prefix", "unknown")

    # Now check lifecycle flags. We deliberately collapse all failure modes
    # to the same HTTP 404 + message so attackers can't distinguish.
    def _reject(reason: str):
        logger.warning(
            f"[invite:redeem] Rejected (reason={reason}) for invite {prefix}"
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Invite not found, already redeemed, or revoked.",
        )

    if row.get("redeemed_at"):
        _reject("already_redeemed")
    if row.get("revoked_at"):
        _reject("revoked")

    expires_at_str = row.get("expires_at")
    if expires_at_str:
        expires_at = None
        try:
            expires_at = datetime.fromisoformat(expires_at_str.replace("Z", "+00:00"))
        except Exception:
            # Malformed expiry — treat as no-expiry for safety rather than
            # locking out a user for server-side bad data.
            logger.warning(f"[invite:redeem] Could not parse expires_at={expires_at_str!r}")
        # _reject raises HTTPException, so the check must live OUTSIDE the
        # try/except above — otherwise the raised 404 gets swallowed and
        # an expired invite silently passes.
        if expires_at is not None and datetime.now(timezone.utc) >= expires_at:
            _reject("expired")

    email = row["email"]
    invite_id = row["invite_id"]
    credits_cents = int(row.get("credits_cents") or 0)

    # Create user + token. Any DB error here leaves the invite in an awkward
    # partially-consumed state (row not marked redeemed, but user may or may
    # not exist). For the MVP we rely on the user_id = f"vl-{uuid4()}"
    # convention being unique per attempt — a retry generates a new user_id.
    user_id = f"vl-{uuid.uuid4().hex[:24]}"
    try:
        await create_user(
            user_id=user_id,
            email=email,
            signup_ip=None,
            signup_device_fp="invite",
            referred_by_code=None,
        )
    except Exception as e:
        msg = str(e)
        # If this email already has a user (someone redeemed a prior invite
        # for the same address under a different user_id), we still want to
        # issue a token to them — look up the existing user_id.
        if "users_email_key" in msg or "duplicate" in msg.lower():
            try:
                res = db.table("users").select("user_id").eq("email", email).execute()
                if res.data:
                    user_id = res.data[0]["user_id"]
                else:
                    raise
            except Exception:
                logger.error(f"[invite:redeem] Could not recover existing user for {email}: {e}")
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="Invite redemption failed — contact support.",
                )
        else:
            logger.error(f"[invite:redeem] create_user failed for {email}: {e}")
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Invite redemption failed — contact support.",
            )

    try:
        user_token = await create_api_token(user_id)
    except Exception as e:
        logger.error(f"[invite:redeem] create_api_token failed for {user_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Invite redemption failed — contact support.",
        )

    # Grant the invite's credit allotment. create_user auto-adds a default
    # signup bonus (SIGNUP_BONUS_IMMEDIATE_CREDITS from api/db.py); this
    # adds the invite-specified amount on top. credits_cents is measured
    # in cents (1 cent = 1 credit today per config). Non-fatal if it fails —
    # admin can reconcile from credit_events and the invite row.
    if credits_cents > 0:
        try:
            from api.db import add_credit_event
            add_credit_event(
                user_id=user_id,
                event_type="invite_grant",
                amount_credits=credits_cents,
                description=f"Invite redemption ({prefix}) — {credits_cents}¢",
            )
            logger.info(
                f"[invite:redeem] Granted {credits_cents} credits to user_id={user_id} "
                f"via invite {prefix}"
            )
        except Exception as e:
            logger.error(
                f"[invite:redeem] Credit grant failed for user_id={user_id}, "
                f"invite={prefix}: {e}. User has a working token but no invite credits — "
                f"manual reconciliation needed via admin."
            )

    # Mark invite redeemed. Done AFTER user + token creation so a failure
    # above doesn't burn the invite. If this last write fails, the user
    # has a working token but the invite is still marked open — admins can
    # reconcile via the list endpoint.
    try:
        _db_call(
            lambda: db.table("invite_tokens").update({
                "redeemed_at":         datetime.now(timezone.utc).isoformat(),
                "redeemed_by_user_id": user_id,
            }).eq("invite_id", invite_id).execute(),
            label="invite:redeem_mark",
        )
    except Exception as e:
        # Non-fatal for the caller — they have their token. Log for manual cleanup.
        logger.error(
            f"[invite:redeem] Failed to mark invite_id={invite_id} redeemed "
            f"by user_id={user_id}: {e}. User has a working token, invite row is stale."
        )

    logger.info(
        f"[invite:redeem] Redeemed invite {prefix} → user_id={user_id}, "
        f"email={email}, credits_cents={credits_cents}"
    )
    return RedeemInviteResponse(
        user_id=user_id,
        email=email,
        user_token=user_token,
        credits_cents=credits_cents,
    )
