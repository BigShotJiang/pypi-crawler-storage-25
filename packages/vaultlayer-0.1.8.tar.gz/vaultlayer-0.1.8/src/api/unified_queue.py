"""Unified provisioning queue with priority lanes + per-provider concurrency caps.

Phase 1: introduces the priority/enqueue primitives. Workers stay in
`_worker_loop` and continue consuming `_job_queue` until Phase 2 wires
them to this module.

Feature-flagged via env `VL_UNIFIED_QUEUE=1`. Off by default — current
behavior is unchanged.

Design doc: docs/architecture/unified_queue.md.
"""
from __future__ import annotations

import heapq
import logging
import os
import time
from dataclasses import dataclass, field
from threading import Lock
from typing import Any, Optional

logger = logging.getLogger(__name__)

# ─── Priority lanes ─────────────────────────────────────────────────────────
# Lower integer = higher priority (heapq semantics).
# Spec: failover-retries get served within 1 s SLA; new submits within 10 s.
PRIO_FAILOVER = 0
PRIO_NORMAL = 10
PRIO_LOW = 100

# ─── Per-provider concurrency caps ──────────────────────────────────────────
# Numbers calibrated from 2026-04-22 stress test:
#   Vast bid market saturated at >5 concurrent A100_40 submits → cap=3
#   RunPod, Lambda handled 5-7 concurrent fine → cap=5
#   AWS Spot has much higher quota → cap=20
# Docs: docs/stress_testing_lessons_2026_04_22.md §"Vast dispatcher queues"
PROVIDER_CONCURRENCY: dict[str, int] = {
    "Vast.ai": int(os.environ.get("VL_VAST_WORKERS", "3")),
    "RunPod": int(os.environ.get("VL_RUNPOD_WORKERS", "5")),
    "Lambda Labs": int(os.environ.get("VL_LAMBDA_WORKERS", "5")),
    "AWS Spot": int(os.environ.get("VL_AWS_SPOT_WORKERS", "20")),
    "AWS": int(os.environ.get("VL_AWS_WORKERS", "20")),
    "CoreWeave": int(os.environ.get("VL_COREWEAVE_WORKERS", "10")),
    "Crusoe": int(os.environ.get("VL_CRUSOE_WORKERS", "10")),
    "Nebius (EU)": int(os.environ.get("VL_NEBIUS_WORKERS", "10")),
    "Voltage Park": int(os.environ.get("VL_VOLTPARK_WORKERS", "10")),
    "Hyperstack": int(os.environ.get("VL_HYPERSTACK_WORKERS", "10")),
    "GCP": int(os.environ.get("VL_GCP_WORKERS", "20")),
    "Azure": int(os.environ.get("VL_AZURE_WORKERS", "20")),
}
DEFAULT_PROVIDER_CAP = 5


def cap_for(provider: str) -> int:
    """Return the concurrency cap for a provider, defaulting when unknown."""
    return PROVIDER_CONCURRENCY.get(provider, DEFAULT_PROVIDER_CAP)


# ─── Queue item ─────────────────────────────────────────────────────────────
@dataclass(order=True)
class QueueItem:
    """One entry in the priority queue. Orders by (priority, enqueued_at)."""
    priority: int
    enqueued_at: float
    job_id: str = field(compare=False)
    attempt: int = field(compare=False, default=0)
    backoff_until: float = field(compare=False, default=0.0)
    retry_context: dict[str, Any] = field(compare=False, default_factory=dict)

    def is_ready(self, now: Optional[float] = None) -> bool:
        """False if item is in backoff and shouldn't be picked yet."""
        return (now or time.time()) >= self.backoff_until


# ─── Queue state ────────────────────────────────────────────────────────────
_heap: list[QueueItem] = []
_heap_lock = Lock()
_provider_inflight: dict[str, int] = {}
_inflight_lock = Lock()


def feature_enabled() -> bool:
    """Phase 1 is gated by env flag. Off by default."""
    return os.environ.get("VL_UNIFIED_QUEUE", "0") == "1"


def enqueue(
    job_id: str,
    priority: int = PRIO_NORMAL,
    retry_context: Optional[dict[str, Any]] = None,
    backoff_seconds: float = 0.0,
) -> int:
    """Add a job to the priority queue. Returns queue position (1-indexed).

    Safe to call when the feature flag is OFF — the item goes in the heap
    but the legacy `_worker_loop` continues consuming `_job_queue` instead,
    so on-flag-off this is a no-op observable.

    Phase 3-lite: if `VL_UNIFIED_QUEUE_PERSIST=1` (on top of
    `VL_UNIFIED_QUEUE=1`), item is also persisted to SQLite so the queue
    survives Railway restart.
    """
    now = time.time()
    item = QueueItem(
        priority=priority,
        enqueued_at=now,
        job_id=job_id,
        retry_context=retry_context or {},
        backoff_until=now + backoff_seconds,
    )
    with _heap_lock:
        heapq.heappush(_heap, item)
        pos = sum(1 for it in _heap if it.priority <= priority)
    # Phase 3-lite persistence (no-op when VL_UNIFIED_QUEUE_PERSIST=0)
    try:
        from api import unified_queue_persist as _uqp
        _uqp.persist_enqueue(
            job_id=item.job_id,
            priority=item.priority,
            enqueued_at=item.enqueued_at,
            attempt=item.attempt,
            backoff_until=item.backoff_until,
            retry_context=item.retry_context,
        )
    except ImportError:
        pass
    logger.debug(f"enqueued {job_id[:8]} prio={priority} pos={pos}")
    return pos


def dequeue_for_provider(
    preferred_providers: list[str],
    all_known_providers: Optional[list[str]] = None,
) -> Optional[QueueItem]:
    """Pull the highest-priority ready item whose preferred provider is
    under its concurrency cap. Callers are responsible for:

      1. Starting the provisioning call themselves (this function only
         returns the item + increments inflight).
      2. Calling `release(provider)` when the provisioning terminates
         (success, failure, or timeout).

    Returns None if:
      - Queue is empty
      - All ready items belong to providers currently at cap
    """
    with _heap_lock, _inflight_lock:
        # Scan heap for the first ready item whose provider has slots.
        # heapq doesn't support this natively; we do a linear sweep in
        # priority order, then re-heapify. Queue stays small (≤1000 items).
        not_ready: list[QueueItem] = []
        picked: Optional[QueueItem] = None
        now = time.time()
        while _heap:
            item = heapq.heappop(_heap)
            if not item.is_ready(now):
                not_ready.append(item)
                continue
            # Pick first preferred provider that's under cap
            for p in preferred_providers or []:
                if _provider_inflight.get(p, 0) < cap_for(p):
                    _provider_inflight[p] = _provider_inflight.get(p, 0) + 1
                    item.retry_context["_reserved_provider"] = p
                    picked = item
                    break
            if picked:
                break
            else:
                # All preferred providers at cap → put item back and move on
                not_ready.append(item)
        # Restore the heap
        for it in not_ready:
            heapq.heappush(_heap, it)
    if picked is not None:
        # Phase 3-lite: remove from persistence since a worker took ownership
        try:
            from api import unified_queue_persist as _uqp
            _uqp.persist_dequeue(picked.job_id)
        except ImportError:
            pass
    return picked


def restore_from_persistence() -> int:
    """Phase 3-lite startup hook: re-populate in-memory heap from SQLite.

    Call once on app startup, BEFORE `_worker_loop` starts consuming. Safe
    to call when feature flag is off — returns 0.

    Returns count of items restored.
    """
    try:
        from api import unified_queue_persist as _uqp
    except ImportError:
        return 0
    if not _uqp.feature_enabled():
        return 0
    rows = _uqp.restore_all()
    with _heap_lock:
        for row in rows:
            item = QueueItem(
                priority=row["priority"],
                enqueued_at=row["enqueued_at"],
                job_id=row["job_id"],
                attempt=row["attempt"],
                backoff_until=row["backoff_until"],
                retry_context=row["retry_context"],
            )
            heapq.heappush(_heap, item)
    logger.info(f"unified_queue: restored {len(rows)} items from SQLite persistence")
    return len(rows)


def release(provider: str) -> None:
    """Decrement the in-flight counter for a provider. Call this when a
    provisioning attempt terminates (regardless of outcome)."""
    with _inflight_lock:
        cur = _provider_inflight.get(provider, 0)
        _provider_inflight[provider] = max(0, cur - 1)


def queue_depth() -> int:
    """Total items in the queue (both ready and in-backoff)."""
    with _heap_lock:
        return len(_heap)


def queue_depth_by_priority() -> dict[int, int]:
    """Breakdown of queue depth per priority lane — for observability."""
    with _heap_lock:
        result: dict[int, int] = {}
        for item in _heap:
            result[item.priority] = result.get(item.priority, 0) + 1
        return result


def provider_load() -> dict[str, tuple[int, int]]:
    """Per-provider (inflight, cap) — for observability."""
    with _inflight_lock:
        return {p: (_provider_inflight.get(p, 0), cap_for(p)) for p in PROVIDER_CONCURRENCY}


def reset_for_test() -> None:
    """Clear all queue state. Test-only."""
    with _heap_lock, _inflight_lock:
        _heap.clear()
        _provider_inflight.clear()
