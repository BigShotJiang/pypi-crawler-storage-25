"""
VaultLayer — Job Data API Endpoints

Receives job events, logs, dataset metadata, and invoice requests from the
CLI running on the user's machine. All writes go through this API so users
never need Supabase credentials.

The server-side job worker lives in api/job_worker.py.
Admin endpoints live in api/admin_routes.py.

Endpoints:
  POST /api/v1/jobs/run                — Submit a training job (server provisions)
  GET  /api/v1/jobs/{job_id}/status    — Full job status
  POST /api/v1/jobs/{job_id}/cancel    — Cancel a job
  POST /api/v1/jobs/{job_id}/events    — Structured job event
  POST /api/v1/jobs/{job_id}/logs      — Bulk training log lines
  GET  /api/v1/jobs/{job_id}/logs      — Fetch training log lines
  POST /api/v1/jobs/{job_id}/invoice   — Generate invoice after completion
  GET  /api/v1/jobs                    — List jobs
  DELETE /api/v1/jobs/{job_id}/queue   — Remove job from queue (legacy compat)
  POST /api/v1/datasets               — Register uploaded dataset
  DELETE /api/v1/datasets/{dataset_id} — Soft-delete a dataset
"""
import asyncio
import hmac
import logging
import os
import time
import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field

from api.auth import require_auth, require_internal_admin, require_job_ownership
from api.db import get_db, _db_call

# Import shared state and worker functions from job_worker
from api.job_worker import (
    _active_jobs,
    _job_queue,
    _job_lock,
    _worker_debug,
    _job_worker,
    _init_broker,
    _generate_job_token,
    _terminate_and_settle,
    _settle_in_db,
    _sync_job_status,
)

logger = logging.getLogger(__name__)

jobs_router = APIRouter(prefix="/api/v1/jobs", tags=["jobs"])
config_router = APIRouter(prefix="/api/v1/config", tags=["config"])
datasets_router = APIRouter(prefix="/api/v1/datasets", tags=["datasets"])


# ── Request models ───────────────────────────────────────────────────────────

class EventRequest(BaseModel):
    event_type: str
    message: str = ""
    metadata: dict = {}


class LogsRequest(BaseModel):
    lines: list[str]
    source: str = "training"


class DatasetRequest(BaseModel):
    dataset_id: str
    name: str = ""
    source_type: str = "local"
    source_uri: Optional[str] = None
    total_bytes: int = 0
    total_shards: int = 0
    r2_prefix: str = ""


class RunJobRequest(BaseModel):
    gpu_type: str
    script_b64: str = ""
    script_name: str = ""
    environment: dict = {}
    docker_image: str = ""
    failover: bool = False
    # Provider+region constraint-satisfaction (replaces the old singular
    # `preferred_provider: str`). Empty list means "no constraint". Both filters
    # are AND-combined. Unknown provider names are rejected with HTTP 400 by
    # the submit handler. Region/provider exclusions are hard — never relaxed
    # by the expand-consent flow.
    preferred_providers: list[str] = Field(default_factory=list)
    excluded_providers: list[str] = Field(default_factory=list)
    regions:            list[str] = Field(default_factory=list)
    excluded_regions:   list[str] = Field(default_factory=list)
    # Chain-walk checkpoint forwarding: set to the prior job_id when the runner
    # is resubmitting after a capacity/infra failure, so the broker can restore
    # that job's R2 checkpoints before training starts on the new instance.
    resume_from_job_id: str = ""
    # GPU selection metadata — used by job_worker for BFS GPU-type walking
    # when the initial GPU is unavailable.
    min_vram_gb: float = 0.0        # minimum VRAM (GB) derived from model size
    gpu_auto_selected: bool = False  # True when CLI auto-selected GPU (user didn't specify --gpu)


class ExpandConsentRequest(BaseModel):
    """Body for POST /api/v1/jobs/{id}/expand-consent.

    Sent by the CLI after the user picks a widening option from the suggestion
    prompt. The server unions these into the existing preferred_providers /
    regions arrays and re-queues the job. Empty arrays are a no-op.
    """
    add_providers: list[str] = Field(default_factory=list)
    add_regions:   list[str] = Field(default_factory=list)


# ── Helpers ──────────────────────────────────────────────────────────────────

def _dedupe_preserve_order(items: list[str]) -> list[str]:
    """Dedupe a list of strings, preserving first-occurrence order.

    Used so the user sees the same ordering they typed (`--provider aws,gcp`
    becomes `["aws","gcp"]`, not `["gcp","aws"]` from a set conversion). Empty
    strings and pure whitespace are dropped.
    """
    seen: set[str] = set()
    out: list[str] = []
    for raw in items:
        v = raw.strip() if isinstance(raw, str) else raw
        if not v or v in seen:
            continue
        seen.add(v)
        out.append(v)
    return out


def _validate_provider_names(names: list[str], field: str) -> None:
    """Reject names that aren't keys in provider_prices.

    Per the constraint-satisfaction spec, validation is against the literal
    keys of config/vaultlayer_data.json:provider_prices (excluding metadata
    keys). This is broader than the routable subset on purpose — accepting
    non-routable values like "AWS On-Demand" is fine; the dispatcher will
    skip them and the job will end up in awaiting_expand_consent if nothing
    else matches. The point of validation is just to catch typos.
    """
    if not names:
        return
    from shared.data_loader import get_provider_prices
    valid = {p for p in get_provider_prices().keys() if not p.startswith("_")}
    bad = [n for n in names if n not in valid]
    if bad:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown provider name(s) in {field}: {bad}. "
                   f"Valid: {sorted(valid)}",
        )


def _has_dispatchable_candidate(
    gpu_type: str,
    preferred_providers: list[str],
    excluded_providers: list[str],
    regions: list[str],
    excluded_regions: list[str],
) -> bool:
    """Cheap pre-flight check: is there at least one (provider, region) pair
    the dispatcher could try?

    Coarse — we don't query live capacity here. This only checks:
      - some routable provider with GPU price > 0 survives the preferred ∩
        non-excluded filter, AND
      - some routable region survives the regions ∩ non-excluded filter.

    True ≠ "will provision". False guarantees "no point trying" → submit
    handler returns 202 awaiting_expand_consent instead of kicking off a
    worker that would burn cycles failing.
    """
    from shared.data_loader import (
        get_provider_prices,
        get_routable_region_codes,
        resolve_gpu_key,
    )
    from shared.suggestions import routable_provider_names

    excl_p = set(excluded_providers)
    excl_r = set(excluded_regions)

    # Region feasibility
    routable_r = set(get_routable_region_codes())
    eff_r = (set(regions) if regions else routable_r) - excl_r
    if not eff_r:
        return False

    # Provider feasibility — must have at least one provider with the GPU
    # priced > 0 and not excluded.
    routable_p = set(routable_provider_names()) - excl_p
    eff_p = (set(preferred_providers) & routable_p) if preferred_providers else routable_p
    if not eff_p:
        return False

    gpu_key = resolve_gpu_key(gpu_type)
    prices = get_provider_prices()
    for p in eff_p:
        price = prices.get(p, {}).get(gpu_key) if isinstance(prices.get(p), dict) else None
        if isinstance(price, (int, float)) and price > 0:
            return True
    return False


# ── Submit job ───────────────────────────────────────────────────────────────

@jobs_router.post("/run")
async def submit_job(body: RunJobRequest, user: dict = Depends(require_auth)):
    """Submit a training job. Server handles provisioning and lifecycle.

    Credit pre-flight check: reject with 402 if the caller has zero or
    negative available credits. Previously /jobs/run queued work with no
    balance validation — the server eventually caught insufficient funds
    in the provisioning path, but there was a window where a user with
    no balance could submit arbitrary numbers of jobs. The check here
    mirrors the reservation gate that /credits/jobs/start has used all
    along; rather than compute a full estimate, we require a positive
    balance and defer exact reservation to the worker.

    Bypasses:
      * TESTING_MODE skips the check (unit tests use synthetic users).
      * A dedicated config toggle could allow staff/internal jobs — not
        added today, but the shape exists for it.
    """
    # Re-read TESTING_MODE each call (not import-time cached) so test
    # monkeypatches on api.flags.TESTING_MODE take effect for this check.
    import api.flags as _flags
    if not _flags.TESTING_MODE:
        try:
            from api.db import get_balance
            bal = get_balance(user["user_id"])
            if (bal.get("available_credits") or 0) <= 0:
                logger.warning(
                    "[submit] Rejecting job for user=%s: insufficient credits (available=%s)",
                    user.get("user_id"), bal.get("available_credits"),
                )
                raise HTTPException(
                    status_code=402,
                    detail="Insufficient credits. Top up at vaultlayer.ai/dashboard.",
                )
        except HTTPException:
            raise
        except Exception as e:
            # Fail closed on balance-check errors: a user whose balance
            # cannot be resolved should not be able to start compute.
            logger.error("[submit] Balance check failed for user=%s: %s", user.get("user_id"), e)
            raise HTTPException(
                status_code=503,
                detail="Credit service temporarily unavailable.",
            )

    # Constraint-satisfaction validation (provider/region filters).
    # Order matters: dedupe → unknown-name reject → empty-after-excludes reject
    # → feasibility check. Each step's error is more specific than the next, so
    # surfacing the earliest applicable one gives the most useful message.
    pref_providers = _dedupe_preserve_order(body.preferred_providers)
    excl_providers = _dedupe_preserve_order(body.excluded_providers)
    regions        = _dedupe_preserve_order(body.regions)
    excl_regions   = _dedupe_preserve_order(body.excluded_regions)

    _validate_provider_names(pref_providers, "preferred_providers")
    _validate_provider_names(excl_providers, "excluded_providers")

    # Three-state allowlist (config/vaultlayer_data.json:included_providers):
    #   - providers (`included`)  — any user can route here
    #   - testing                — only users in VL_TEST_USER_IDS may route here
    #   - pending                — fully blocked (always 400)
    #
    # We classify each entry in pref_providers and reject only on a real
    # mismatch. Test users get more permissive routing without exposing
    # production users to broken testing-state providers.
    from shared.data_loader import (
        get_included_providers,
        get_pending_providers,
        get_testing_providers,
        user_can_use_testing_providers,
    )
    _included = set(get_included_providers())
    _testing = set(get_testing_providers())
    _pending = set(get_pending_providers())
    _is_test_user = user_can_use_testing_providers(user.get("user_id", ""))

    if _included and pref_providers:
        # Anything in `pending` is rejected for everyone.
        _bad_pending = [n for n in pref_providers if n in _pending]
        # Anything in `testing` is rejected unless caller is a test user.
        _bad_testing = [
            n for n in pref_providers
            if n in _testing and not _is_test_user
        ]
        # Anything not in any of the three lists is unknown — reject.
        _allowed_for_user = _included | (_testing if _is_test_user else set())
        _bad_unknown = [
            n for n in pref_providers
            if n not in _included and n not in _testing and n not in _pending
        ]

        if _bad_pending:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"preferred_providers contains pending providers "
                    f"(blocked for all users): {_bad_pending}. "
                    f"Currently included: {sorted(_included)}. "
                    f"See docs/provider_testing_matrix.md for promotion status."
                ),
            )
        if _bad_testing:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"preferred_providers contains testing-state providers "
                    f"({_bad_testing}) — only allowlisted test users may route "
                    f"here. Currently included: {sorted(_included)}. "
                    f"See docs/provider_testing_matrix.md."
                ),
            )
        if _bad_unknown:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"preferred_providers contains unknown providers: "
                    f"{_bad_unknown}. Allowed for you: {sorted(_allowed_for_user)}. "
                    f"Pending: {sorted(_pending)}."
                ),
            )

    if pref_providers and set(pref_providers) <= set(excl_providers):
        raise HTTPException(
            status_code=400,
            detail="preferred_providers after exclusions is empty — every "
                   "requested provider is also in excluded_providers.",
        )
    if regions and set(regions) <= set(excl_regions):
        raise HTTPException(
            status_code=400,
            detail="regions after exclusions is empty — every requested "
                   "region is also in excluded_regions.",
        )

    job_id = str(uuid.uuid4())

    feasible = _has_dispatchable_candidate(
        gpu_type=body.gpu_type,
        preferred_providers=pref_providers,
        excluded_providers=excl_providers,
        regions=regions,
        excluded_regions=excl_regions,
    )

    async with _job_lock:
        _active_jobs[job_id] = {
            "job_id": job_id,
            "user_id": user["user_id"],
            "gpu_type": body.gpu_type,
            "script_b64": body.script_b64,
            "script_name": body.script_name,
            "environment": body.environment,
            "docker_image": body.docker_image,
            "failover": body.failover,
            "status": "queued" if feasible else "awaiting_expand_consent",
            "instance_id": None,
            "provider": None,
            "price_per_hr": None,
            "actual_gpu_type": None,
            "log_line_count": 0,
            "started_at": None,
            "completed_at": None,
            "duration": None,
            "error": None,
            "checkpoint_step": None,
            "preferred_providers": pref_providers,
            "excluded_providers": excl_providers,
            "regions":            regions,
            "excluded_regions":   excl_regions,
            "resume_from_job_id": body.resume_from_job_id or None,
            "min_vram_gb":        float(body.min_vram_gb or 0),
            "gpu_auto_selected":  bool(body.gpu_auto_selected),
            "queued_at": time.time(),
        }
        if feasible:
            _job_queue.append(job_id)
            # Phase 1b of unified_queue rollout (design doc:
            # docs/architecture/unified_queue.md). When the feature flag is
            # on, ALSO enqueue into the priority queue. _worker_loop still
            # drains from _job_queue for now; Phase 1c will swap the consumer.
            # Off by default — this line is a no-op for current behavior.
            try:
                from api import unified_queue as _uq
                if _uq.feature_enabled():
                    _uq.enqueue(job_id, priority=_uq.PRIO_NORMAL)
            except ImportError:
                pass  # module optional during staged rollout

    # Persist to DB so the job survives deploys and shows up in the dashboard
    # immediately. We pass the first preferred provider (if any) just so the
    # row has a meaningful provider label during the provisioning phase
    # instead of the literal "pending" placeholder. instance_id stays empty
    # until the real instance is provisioned; _record_provision_to_db patches
    # provider+rate later if dispatch picks a different provider.
    _submit_provider = pref_providers[0] if pref_providers else ""
    initial_status = "provisioning" if feasible else "awaiting_expand_consent"
    try:
        from shared.job_run_logger import open_run
        run_id = open_run(
            job_id=job_id,
            provider=_submit_provider,
            gpu_type=body.gpu_type,
            instance_id="",
            provisioned_at=datetime.now(timezone.utc),
            rate_per_hr=0,
            run_type="real",
            account_id=user["user_id"],
            job_name=f"job-{job_id[:8]}",
            docker_image=body.docker_image,
        )
        if run_id:
            _active_jobs[job_id]["_run_id"] = run_id
            _sync_job_status(run_id, initial_status)
    except Exception as e:
        logger.warning(f"[submit] DB write failed (non-fatal): {e}")

    if not feasible:
        from shared.suggestions import get_suggestions
        sugg = get_suggestions(regions, pref_providers)
        return Response(
            status_code=202,
            content=_jsonify({
                "job_id": job_id,
                "status": "awaiting_expand_consent",
                "suggestions": sugg,
            }),
            media_type="application/json",
        )

    return {"job_id": job_id, "status": "queued"}


def _jsonify(payload: dict) -> str:
    """Stable JSON for the 202 response. Encapsulated so tests can patch it."""
    import json
    return json.dumps(payload)


# ── Job status ───────────────────────────────────────────────────────────────

@jobs_router.get("/{job_id}/status")
async def get_job_status(job_id: str, user: dict = Depends(require_auth)):
    """Full job status including instance, provider, logs, duration.

    Returns 404 for jobs the caller does not own — same response code as
    a missing job so attackers cannot enumerate other users' job IDs.
    """
    job = require_job_ownership(job_id, user, _active_jobs)

    # Include queue position if queued
    result = dict(job)
    if job["status"] == "queued" and job_id in _job_queue:
        result["queue_position"] = _job_queue.index(job_id) + 1
    return result


# ── Cancel job ───────────────────────────────────────────────────────────────

@jobs_router.post("/{job_id}/cancel")
async def cancel_job(
    job_id: str,
    reason: Optional[str] = None,
    user: dict = Depends(require_auth),
):
    """Cancel a job. If queued/awaiting_expand_consent: drop from queue and
    record the cancel reason. If running: terminate the instance and settle
    billing.

    The optional `?reason=` query param tags WHY the job was cancelled. Known
    values used by the system: `user_declined` (CLI Cancel option),
    `consent_timeout` (CLI 15-min prompt timeout), `resume_no_capacity`
    (broker exhausted providers on a resume leg). Free-form reasons from
    other callers are stored verbatim. The reason ends up in
    job_runs.failure_reason (visible in the dashboard) and triggers a
    cancel-notification email.

    Returns 404 (not 403) for jobs the caller does not own.
    """
    job = require_job_ownership(job_id, user, _active_jobs)
    cancel_reason = (reason or "user_request").strip() or "user_request"

    async with _job_lock:
        prev_status = job.get("status")
        if prev_status in ("queued", "awaiting_expand_consent"):
            if job_id in _job_queue:
                _job_queue.remove(job_id)
            job["status"] = "cancelled"
            job["cancel_reason"] = cancel_reason
            # No instance was provisioned — settle as a no-op so the DB row
            # transitions cleanly to terminal state without billing.
            _settle_in_db(job, status="cancelled")
        elif prev_status in ("running", "provisioning"):
            job["status"] = "cancelled"
            job["cancel_reason"] = cancel_reason
            job["completed_at"] = time.time()
            if job.get("started_at"):
                job["duration"] = job["completed_at"] - job["started_at"]
            try:
                broker = _init_broker()
                await _terminate_and_settle(broker, job)
            except Exception as e:
                logger.warning(f"Cancel-terminate failed for {job_id}: {e}")
            _settle_in_db(job, status="cancelled")
        else:
            job["status"] = "cancelled"
            job["cancel_reason"] = cancel_reason
            job["completed_at"] = time.time()
            # If an instance exists (e.g. status was "recovering" or "migrated"),
            # terminate it — any status with an instance_id can keep billing.
            if job.get("instance_id") and job.get("provider"):
                try:
                    broker = _init_broker()
                    await _terminate_and_settle(broker, job)
                except Exception as e:
                    logger.warning(f"Cancel-terminate (status={prev_status}) failed for {job_id}: {e}")
            _settle_in_db(job, status="cancelled")

        # Persist failure_reason on the job_runs row so the dashboard
        # surfaces WHY this job ended.
        run_id = job.get("_run_id")
        if run_id:
            try:
                _sync_job_status(run_id, "cancelled", failure_reason=cancel_reason)
            except Exception as e:
                logger.warning(f"[cancel] failure_reason sync failed for {job_id}: {e}")

    # Fire the cancel-notification email (log-only fallback for v0).
    if cancel_reason in ("consent_timeout", "resume_no_capacity"):
        try:
            from shared.email import send_cancel_email
            send_cancel_email(
                job_id=job_id,
                user_email=user.get("email", ""),
                reason=cancel_reason,
                preferred_providers=job.get("preferred_providers") or [],
                regions=job.get("regions") or [],
                run_id=job.get("_run_id"),
            )
        except Exception as e:
            logger.warning(f"[cancel] email send failed for {job_id}: {e}")

    return {"ok": True, "status": "cancelled", "reason": cancel_reason}


# ── Expand consent ───────────────────────────────────────────────────────────

@jobs_router.post("/{job_id}/expand-consent")
async def expand_consent(
    job_id: str,
    body: ExpandConsentRequest,
    user: dict = Depends(require_auth),
):
    """Widen a job's provider/region filter and re-queue it.

    Only valid when the job is in `awaiting_expand_consent`. Adds the new
    provider/region values into the existing whitelist arrays (union, dedupe
    preserving order) and flips the status back to `queued` so the worker
    picks it up. Empty arrays are a no-op (200 with the current state).

    Validation matches the submit flow — unknown provider names are rejected
    with HTTP 400 against the same provider_prices keys. Excluded_providers /
    excluded_regions are NEVER widened by this endpoint; the spec is explicit
    that those are hard constraints.
    """
    job = require_job_ownership(job_id, user, _active_jobs)

    if job.get("status") != "awaiting_expand_consent":
        raise HTTPException(
            status_code=409,
            detail=f"Job is in status '{job.get('status')}'; expand-consent is "
                   f"only valid for jobs in 'awaiting_expand_consent'.",
        )

    add_providers = _dedupe_preserve_order(body.add_providers)
    add_regions   = _dedupe_preserve_order(body.add_regions)
    _validate_provider_names(add_providers, "add_providers")

    if not add_providers and not add_regions:
        # Idempotent no-op: keep the job parked, don't re-queue.
        return {"ok": True, "status": job["status"], "noop": True}

    async with _job_lock:
        merged_providers = _dedupe_preserve_order(
            (job.get("preferred_providers") or []) + add_providers
        )
        merged_regions = _dedupe_preserve_order(
            (job.get("regions") or []) + add_regions
        )
        # Excluded sets are never widened here — re-check feasibility against
        # the merged whitelists + existing exclusions before we re-queue.
        excl_providers = job.get("excluded_providers") or []
        excl_regions   = job.get("excluded_regions") or []

        feasible = _has_dispatchable_candidate(
            gpu_type=job.get("gpu_type", ""),
            preferred_providers=merged_providers,
            excluded_providers=excl_providers,
            regions=merged_regions,
            excluded_regions=excl_regions,
        )

        job["preferred_providers"] = merged_providers
        job["regions"] = merged_regions

        if feasible:
            job["status"] = "queued"
            if job_id not in _job_queue:
                _job_queue.append(job_id)
            run_id = job.get("_run_id")
            if run_id:
                try:
                    _sync_job_status(run_id, "provisioning")
                except Exception as e:
                    logger.warning(f"[expand-consent] status sync failed: {e}")
            return {
                "ok": True,
                "status": "queued",
                "preferred_providers": merged_providers,
                "regions": merged_regions,
            }

        # Still infeasible after widening — return 202 with fresh suggestions.
        from shared.suggestions import get_suggestions
        sugg = get_suggestions(merged_regions, merged_providers)
        return Response(
            status_code=202,
            content=_jsonify({
                "job_id": job_id,
                "status": "awaiting_expand_consent",
                "preferred_providers": merged_providers,
                "regions": merged_regions,
                "suggestions": sugg,
            }),
            media_type="application/json",
        )


# ── List jobs ────────────────────────────────────────────────────────────────

@jobs_router.get("")
async def list_jobs(
    limit: int = 20,
    include_completed: str = "false",
    user: dict = Depends(require_auth),
):
    """List user's recent jobs from job_runs table."""
    try:
        db = get_db()
        query = db.table("job_runs").select(
            "job_id, provider, gpu_type, status, provisioned_at, terminated_at, "
            "billing_seconds, estimated_cost_usd, instance_id, run_type"
        ).eq("account_id", user["user_id"]).order("provisioned_at", desc=True).limit(limit)

        if include_completed != "true":
            query = query.neq("status", "completed")

        result = _db_call(lambda: query.execute(), label="job_routes:list_jobs")
        return {"jobs": result.data or []}
    except Exception as e:
        logger.warning(f"[job-routes] list jobs failed: {e}")
        return {"jobs": []}


# ── Legacy queue endpoint (backward compat) ──────────────────────────────────

@jobs_router.delete("/{job_id}/queue")
async def dequeue_job(job_id: str, user: dict = Depends(require_auth)):
    """Remove a job from the queue (cancelled by user). Legacy compat."""
    # Verify ownership before any mutation
    require_job_ownership(job_id, user, _active_jobs)
    async with _job_lock:
        if job_id in _job_queue:
            _job_queue.remove(job_id)
        job = _active_jobs.get(job_id)
        if job:
            job["status"] = "cancelled"
    return {"ok": True}


# ── Job events ───────────────────────────────────────────────────────────────

@jobs_router.post("/{job_id}/events")
async def post_job_event(job_id: str, req: EventRequest, request: Request):
    """Record a structured job event. Accepts Bearer auth OR X-Job-Token.

    Bearer-auth callers must own the job (404 if not). The X-Job-Token
    path is HMAC-bound to the job_id so cross-job access is impossible
    by construction.
    """
    # Try job token first (container auth)
    job_token = request.headers.get("x-job-token", "")
    if job_token:
        expected = _generate_job_token(job_id)
        if not hmac.compare_digest(job_token, expected):
            raise HTTPException(401, "Invalid job token")
        user = {"user_id": _active_jobs.get(job_id, {}).get("user_id", "system")}
    else:
        # Normal auth + ownership check
        user = await require_auth(authorization=request.headers.get("authorization", ""))
        require_job_ownership(job_id, user, _active_jobs)

    try:
        db = get_db()
        _db_call(
            lambda: db.table("job_events").insert({
                "job_id": job_id,
                "user_id": user["user_id"],
                "event_type": req.event_type,
                "message": req.message,
                "metadata": req.metadata,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }).execute(),
            label="job_routes:event",
        )
    except Exception as e:
        logger.warning(f"[job-routes] event insert failed (non-fatal): {e}")
    return {"ok": True}


# ── Job logs ─────────────────────────────────────────────────────────────────

@jobs_router.get("/{job_id}/logs")
async def get_job_logs(job_id: str, limit: int = 500, user: dict = Depends(require_auth)):
    """Fetch training log lines for a job.

    Two-layer ownership check: in-memory dict (for active jobs) AND a
    user_id filter on the SQL query (for completed jobs no longer in
    _active_jobs). Either layer alone could be bypassed; together they
    cover the full job lifetime.
    """
    # Layer 1: if the job is still active, enforce ownership now
    if job_id in _active_jobs:
        require_job_ownership(job_id, user, _active_jobs)

    try:
        db = get_db()
        # Layer 2: SQL filter on user_id catches completed jobs that
        # have aged out of _active_jobs. Returns an empty list (not
        # 403/404) for cross-tenant access — same shape as "no logs yet".
        result = _db_call(
            lambda: db.table("job_logs")
                .select("line, source, created_at")
                .eq("job_id", job_id)
                .eq("user_id", user["user_id"])
                .order("created_at")
                .limit(limit)
                .execute(),
            label="job_routes:get_logs",
        )
        return {"lines": result.data or [], "count": len(result.data or [])}
    except Exception as e:
        logger.warning(f"[job-routes] get logs failed: {e}")
        return {"lines": [], "count": 0}


@jobs_router.post("/{job_id}/simulate-instance-death")
async def simulate_instance_death(job_id: str, user: dict = Depends(require_auth)):
    """Force-fence the underlying VM/container WITHOUT marking the job
    cancelled. Used to test the broker's failover/resume path without
    waiting for natural preemption.

    Flow that should follow:
      1. This endpoint calls the provider's hard_fence on `instance_id`
      2. Job stays in "running" status
      3. Broker's alive-check eventually notices missing heartbeat
      4. If `failover=true` was set on submit AND a checkpoint exists in
         R2, broker re-queues with `_resume_prefer_provider` set, picks
         a new instance (same provider first), and resumes from the
         checkpoint — `_handle_provision_result` line ~1508.

    Diagnostic-only — never fires automatically. Requires the job's owner
    to authenticate. Returns 404 for unowned jobs (same as cancel).
    """
    job = require_job_ownership(job_id, user, _active_jobs)
    instance_id = job.get("instance_id")
    if not instance_id:
        return {"ok": False, "error": "no instance_id on job (not running?)"}
    provider = (job.get("provider") or "").lower()
    if not provider:
        return {"ok": False, "error": "no provider on job"}

    try:
        from agents.broker.providers import (
            vast_ai as _vast_ai,
            runpod as _runpod,
            lambda_labs as _lambda,
            aws as _aws,
            gcp as _gcp,
            coreweave as _cw,
            crusoe as _crusoe,
            nebius as _nebius,
            voltage_park as _vp,
            hyperstack as _hs,
        )
        _PROV_FENCE = {
            "vast_ai":      _vast_ai.hard_fence,
            "runpod":       _runpod.hard_fence,
            "lambda_labs":  _lambda.hard_fence,
            "aws":          _aws.hard_fence,
            "gcp":          _gcp.hard_fence,
            "coreweave":    _cw.hard_fence,
            "crusoe":       _crusoe.hard_fence,
            "nebius":       _nebius.hard_fence,
            "voltage_park": _vp.hard_fence,
            "hyperstack":   _hs.hard_fence,
        }
        fence = _PROV_FENCE.get(provider)
        if not fence:
            return {"ok": False, "error": f"no fence handler for provider={provider}"}
        broker = _init_broker()
        if not broker:
            return {"ok": False, "error": "broker unavailable"}
        await fence(broker, instance_id, job=job)
        # NOTE: do NOT touch job["status"] here. The whole point is to leave
        # it as "running" so the broker's alive-check fires the failover
        # branch (which requires status=running + missing heartbeat).
        logger.info(f"[simulate-instance-death] fenced {provider} instance {instance_id} "
                    f"for job {job_id} — failover should fire next alive-check cycle")
        return {
            "ok": True,
            "fenced_instance": instance_id,
            "provider": provider,
            "next": "broker alive-check will detect missing heartbeat and trigger failover (if failover=true on submit)",
        }
    except Exception as e:
        logger.warning(f"[simulate-instance-death] failed for {job_id}: {e}")
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


@jobs_router.get("/{job_id}/gcp-serial-console")
async def get_gcp_serial_console(job_id: str, user: dict = Depends(require_auth)):
    """Pull GCE serial-port-1 output for a GCP job's instance.

    Diagnostic-only. Used when a GCP VM silently fails with 0 log lines
    (20-min platform auto-fence): serial console captures kernel + bash
    output even when our heartbeat can't reach the API (seen 2026-04-20
    on plain ubuntu-2204-lts — identical silent-fence pattern as the
    ubuntu-accelerator image it replaced, meaning the root cause is NOT
    the image).

    Returns the same bytes the Cloud Console's "View serial port 1
    (console)" button shows. Never raises — returns empty string on
    credential / API failure.
    """
    # Layer 1: if the job is still active, enforce ownership now
    if job_id in _active_jobs:
        require_job_ownership(job_id, user, _active_jobs)

    try:
        db = get_db()
        result = _db_call(
            lambda: db.table("job_runs")
                .select("account_id, provider, instance_id, metadata")
                .eq("job_id", job_id)
                .eq("account_id", user["user_id"])
                .limit(1)
                .execute(),
            label="job_routes:gcp_serial_console_ownership",
        )
        if not result.data:
            return {"contents": "", "error": "job not found or not owned"}
        row = result.data[0]
        if (row.get("provider") or "").lower() != "gcp":
            return {"contents": "", "error": f"not a GCP job (provider={row.get('provider')})"}
        if not row.get("instance_id"):
            return {"contents": "", "error": "no instance_id on job_run"}

        from agents.broker.providers import gcp as gcp_provider
        from api.job_worker import _init_broker
        broker = _init_broker()
        if not broker:
            return {"contents": "", "error": "broker unavailable"}
        _zone = (row.get("metadata") or {}).get("zone")
        contents = await gcp_provider.fetch_serial_console(
            broker, row["instance_id"], zone=_zone,
        )
        return {"contents": contents or "", "instance_id": row["instance_id"]}
    except Exception as e:
        logger.warning(f"[job-routes] gcp-serial-console failed for {job_id}: {e}")
        return {"contents": "", "error": f"{type(e).__name__}: {e}"}


@jobs_router.post("/{job_id}/logs")
async def post_job_logs(job_id: str, req: LogsRequest, request: Request):
    """Bulk-insert training log lines. Accepts Bearer auth OR X-Job-Token.

    Bearer-auth callers must own the job. The X-Job-Token path is
    HMAC-bound to the job_id so cross-job posts are impossible.
    """
    # Try job token first (container auth)
    job_token = request.headers.get("x-job-token", "")
    if job_token:
        expected = _generate_job_token(job_id)
        if not hmac.compare_digest(job_token, expected):
            raise HTTPException(401, "Invalid job token")
        user = {"user_id": _active_jobs.get(job_id, {}).get("user_id", "system")}
    else:
        # Normal auth + ownership check
        user = await require_auth(authorization=request.headers.get("authorization", ""))
        require_job_ownership(job_id, user, _active_jobs)

    if not req.lines:
        return {"ok": True, "count": 0}

    now = datetime.now(timezone.utc).isoformat()
    rows = []
    for line in req.lines:
        if not line.strip():
            continue
        row: dict = {"job_id": job_id, "user_id": user["user_id"],
                     "line": line, "source": req.source, "created_at": now}
        if req.source == "training":
            from shared.job_logger import _parse_step_number
            step = _parse_step_number(line)
            if step is not None:
                row["step_number"] = step
        rows.append(row)
    if not rows:
        return {"ok": True, "count": 0}

    inserted = 0
    try:
        db = get_db()
        # Chunk to stay within Supabase payload limits.
        # Use upsert with ignore_duplicates so resumed jobs don't double-log steps.
        chunk_size = 200
        for i in range(0, len(rows), chunk_size):
            _db_call(
                lambda i=i: db.table("job_logs").upsert(
                    rows[i:i + chunk_size],
                    on_conflict="job_id,step_number",
                    ignore_duplicates=True,
                ).execute(),
                label="job_routes:logs",
            )
            inserted += len(rows[i:i + chunk_size])
    except Exception as e:
        logger.warning(f"[job-routes] logs insert failed after {inserted}/{len(rows)} rows: {e}")
    return {"ok": inserted == len(rows), "count": inserted, "total": len(rows)}


# ── Invoice generation ───────────────────────────────────────────────────────

@jobs_router.post("/{job_id}/invoice")
async def post_job_invoice(job_id: str, user: dict = Depends(require_auth)):
    """Generate and store an invoice for a completed job.

    create_invoice() filters by user_id internally, but we also gate at
    the API layer so a cross-tenant call is rejected before any DB work.
    """
    if job_id in _active_jobs:
        require_job_ownership(job_id, user, _active_jobs)
    try:
        from shared.invoice import create_invoice
        invoice_id = create_invoice(job_id=job_id, user_id=user["user_id"])
        if invoice_id:
            return {"ok": True, "invoice_id": invoice_id}
        return {"ok": False, "error": "Could not generate invoice"}
    except Exception as e:
        logger.warning(f"[job-routes] invoice generation failed: {e}")
        raise HTTPException(500, f"Invoice generation failed: {e}")


# ── Dataset registration ─────────────────────────────────────────────────────

@datasets_router.post("")
async def register_dataset(req: DatasetRequest, user: dict = Depends(require_auth)):
    """Register a dataset uploaded to R2."""
    try:
        db = get_db()
        _db_call(
            lambda: db.table("datasets").upsert({
                "dataset_id": req.dataset_id,
                "user_id": user["user_id"],
                "name": req.name or req.dataset_id,
                "source_type": req.source_type,
                "source_uri": req.source_uri,
                "r2_prefix": req.r2_prefix or f"datasets/{req.dataset_id}/",
                "total_bytes": req.total_bytes,
                "total_shards": req.total_shards,
                "last_synced_at": "now()",
            }, on_conflict="dataset_id,user_id").execute(),
            label="job_routes:dataset_register",
        )
    except Exception as e:
        logger.warning(f"[job-routes] dataset register failed: {e}")
        raise HTTPException(500, f"Dataset registration failed: {e}")
    return {"ok": True, "dataset_id": req.dataset_id}


# ── Runtime config for CLI ────────────────────────────────────────────────────

@config_router.get("/runtime")
async def get_runtime_config(user: dict = Depends(require_auth)):
    """Return runtime config needed by CLI agents (R2 endpoint, bucket).

    Previously also returned redis_url. That leaked the company's full
    pub/sub access — any authed user could SUBSCRIBE * to all VaultLayer
    channels (orchestration commands, billing events, watchdog signals).
    Removed. CLI run path falls back to local Redis or skips agent
    pub/sub entirely if not configured.
    """
    return {
        "r2_endpoint": os.environ.get("R2_ENDPOINT", os.environ.get("VAULTLAYER_R2_ENDPOINT", "")),
        "r2_bucket": os.environ.get("R2_BUCKET", os.environ.get("VAULTLAYER_R2_BUCKET", "vaultlayer-checkpoints")),
    }


class TestEmailRequest(BaseModel):
    to: str = ""  # Optional override — defaults to user's email


@config_router.post("/test-email")
async def test_email(
    body: TestEmailRequest = TestEmailRequest(),
    user: dict = Depends(require_auth),
):
    """Send a test email — restricted to the caller's own email.

    Previously accepted an arbitrary `to` address while only requiring
    user auth, which was a free spam vector with VaultLayer-branded
    sender. Now we ignore body.to and always send to user.email; if the
    user has no email on file the request fails 400.
    """
    try:
        from api.email import send_credits_low
        email = user.get("email", "")
        if not email:
            return {"ok": False, "error": "No email on account — cannot send test."}
        if body.to and body.to.strip().lower() != email.strip().lower():
            logger.warning(
                "[email] test-email cross-recipient blocked: user=%s tried to send to=%s",
                user.get("user_id"), body.to,
            )
            raise HTTPException(
                status_code=403,
                detail="Test emails can only be sent to the account's own email address.",
            )
        await send_credits_low(email, 999)
        return {"ok": True, "sent_to": email, "template": "credits_low"}
    except HTTPException:
        raise
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}


@config_router.get("/provider-status")
async def provider_status(_admin: None = Depends(require_internal_admin)):
    """Test connectivity to each provider API. Returns which providers are reachable.

    Operator-only. Previously exposed `has_key: true/false` and
    `key_prefix: "rpa_1ZVJ..."` to any authenticated user, which
    fingerprinted VaultLayer's ops setup.
    """
    broker = _init_broker()
    if not broker:
        return {"ok": False, "error": "Broker not available"}

    results = {}
    providers = ["vast_ai", "runpod", "lambda_labs", "coreweave",
                 "voltage_park", "crusoe", "nebius", "hyperstack"]
    for prov in providers:
        cfg = broker._get_provider_config(prov)
        if cfg and getattr(cfg, "api_key", ""):
            key = cfg.api_key
            results[prov] = {"has_key": True, "key_prefix": key[:8] + "..."}
        else:
            results[prov] = {"has_key": False}

    # AWS: check via env
    results["aws"] = {"has_key": bool(os.environ.get("AWS_ACCESS_KEY_ID"))}
    # GCP: check via config
    gcp_cfg = getattr(broker.config, "gcp", None)
    results["gcp"] = {"has_key": bool(gcp_cfg and getattr(gcp_cfg, "project_id", ""))}
    # Azure: check via config
    az_cfg = getattr(broker.config, "azure", None)
    results["azure"] = {"has_key": bool(az_cfg and getattr(az_cfg, "subscription_id", ""))}

    return {"providers": results}


@datasets_router.delete("/{dataset_id}")
async def delete_dataset(dataset_id: str, user: dict = Depends(require_auth)):
    """Soft-delete a dataset (sets deleted_at timestamp)."""
    try:
        db = get_db()
        _db_call(
            lambda: db.table("datasets").update({
                "deleted_at": datetime.now(timezone.utc).isoformat(),
            }).eq("dataset_id", dataset_id).eq("user_id", user["user_id"]).execute(),
            label="job_routes:dataset_delete",
        )
    except Exception as e:
        logger.warning(f"[job-routes] dataset delete failed: {e}")
        raise HTTPException(500, f"Dataset deletion failed: {e}")
    return {"ok": True}
