"""
Credits API routes — reserve, burn, settle, balance.

Called by:
  - CLI (vaultlayer run)     → POST /api/v1/jobs/start
  - OrchestrationAgent       → POST /api/v1/jobs/{job_id}/burn  (every 60s)
  - OrchestrationAgent       → POST /api/v1/jobs/{job_id}/settle (job end)
  - CLI / dashboard          → GET  /api/v1/credits
"""
from __future__ import annotations

import logging
import math
import os
import time
from collections import defaultdict, deque
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status

from api.auth import require_auth
from api.db import (
    add_credit_event,
    get_balance,
    update_job,
    upsert_job,
)
from api.email import send_credits_low, send_job_suspended
from api.flags import TESTING_MODE, TESTING_CREDITS_BALANCE, TESTING_USER
from api.fraud import maybe_release_staged_bonus
from api.models import (
    BurnRequest,
    BurnResponse,
    CreditBalanceResponse,
    JobCredentialsRequest,
    JobCredentialsResponse,
    JobStartRequest,
    JobStartResponse,
    SettleRequest,
    SettleResponse,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1", tags=["credits"])

# Lazy-initialized R2 minter (requires Cloudflare config at startup)
_r2_minter = None


def _get_r2_minter():
    global _r2_minter
    if _r2_minter is None:
        cf_account_id  = os.environ.get("CLOUDFLARE_ACCOUNT_ID", "")
        cf_master_token = os.environ.get("CF_MASTER_TOKEN", "")
        r2_access_key  = os.environ.get("R2_ACCESS_KEY_ID", "")
        r2_secret_key  = os.environ.get("R2_SECRET_ACCESS_KEY", "")
        r2_bucket      = os.environ.get("R2_BUCKET", "vaultlayer-checkpoints")
        r2_endpoint    = os.environ.get("R2_ENDPOINT", "")

        if not (cf_account_id and r2_endpoint and (cf_master_token or r2_access_key)):
            return None

        from shared.r2_credentials import R2CredentialsMinter

        class _FakeCFConfig:
            account_id       = cf_account_id
            cf_master_token  = cf_master_token
            r2_access_key_id = r2_access_key
            r2_bucket        = r2_bucket
            r2_endpoint      = r2_endpoint

        _r2_minter = R2CredentialsMinter.from_config(_FakeCFConfig())
    return _r2_minter

# ── Per-token rate limiting (Redis sliding window, in-memory fallback) ────────
# burn: max 10 calls/min per token (OrchestrationAgent ticks every 60s — 10 is generous)
# start: max 5 calls/min per token (burst protection)
_BURN_LIMIT  = int(os.environ.get("RATE_LIMIT_BURN_PER_MIN",  "10"))
_START_LIMIT = int(os.environ.get("RATE_LIMIT_START_PER_MIN", "5"))
_WINDOW_SEC  = 60

# In-memory fallback (single-replica only — resets on restart)
_burn_timestamps:  defaultdict[str, deque] = defaultdict(lambda: deque())
_start_timestamps: defaultdict[str, deque] = defaultdict(lambda: deque())

# Lazy Redis client for distributed rate limiting
_rl_redis = None
_rl_redis_url = os.environ.get("UPSTASH_REDIS_URL", "") or os.environ.get("REDIS_URL", "")


async def _get_rl_redis():
    """Return the shared Redis client for rate limiting, or None if unavailable."""
    global _rl_redis
    if _rl_redis is None and _rl_redis_url:
        try:
            import redis.asyncio as aioredis
            _rl_redis = aioredis.from_url(
                _rl_redis_url, decode_responses=True, socket_connect_timeout=2
            )
            await _rl_redis.ping()
        except Exception as _e:
            logger.warning(f"[rate-limit] Redis unavailable, using in-memory fallback: {_e}")
            _rl_redis = None
    return _rl_redis


def _check_rate_limit_local(store: defaultdict, user_id: str, limit: int) -> bool:
    """In-process sliding window (fallback when Redis is unavailable)."""
    now = time.monotonic()
    dq = store[user_id]
    while dq and now - dq[0] > _WINDOW_SEC:
        dq.popleft()
    if len(dq) >= limit:
        return False
    dq.append(now)
    return True


async def _check_rate_limit(store: defaultdict, user_id: str, limit: int, key_prefix: str) -> bool:
    """
    Distributed sliding-window rate limit backed by Redis sorted sets.
    Falls back to in-memory if Redis is unavailable.
    Returns True if the request is allowed.
    """
    r = await _get_rl_redis()
    if r is None:
        return _check_rate_limit_local(store, user_id, limit)

    now = time.time()
    window_start = now - _WINDOW_SEC
    redis_key = f"vaultlayer:rl:{key_prefix}:{user_id}"
    try:
        pipe = r.pipeline()
        pipe.zremrangebyscore(redis_key, 0, window_start)   # evict expired entries
        pipe.zcard(redis_key)                                # count remaining
        pipe.zadd(redis_key, {str(now): now})               # record this request
        pipe.expire(redis_key, _WINDOW_SEC + 5)             # auto-expire key
        results = await pipe.execute()
        count_before = results[1]  # count BEFORE this request is added
        if count_before >= limit:
            # Undo the optimistic zadd — this request is rejected
            await r.zrem(redis_key, str(now))
            return False
        return True
    except Exception as _e:
        logger.warning(f"[rate-limit] Redis error, falling back to in-memory: {_e}")
        return _check_rate_limit_local(store, user_id, limit)


# Credits below this trigger LOW warning (1000 credits = $10)
LOW_CREDITS_THRESHOLD = int(os.environ.get("LOW_CREDITS_THRESHOLD", "1000"))
# Credits below this trigger EXHAUSTED / job suspension (50 credits = $0.50 grace)
EXHAUSTED_THRESHOLD = int(os.environ.get("EXHAUSTED_THRESHOLD", "50"))


def _usd_to_credits(usd: float) -> int:
    """Convert USD to credits (1 credit = $0.01). Always rounds up."""
    return math.ceil(usd * 100)


def _credits_to_usd(credits: int) -> float:
    return round(credits / 100, 4)


def _estimate_credits(hourly_rate_usd: float, hours: float) -> int:
    """Estimate credits needed including 20% buffer for migration overhead."""
    raw_usd = hourly_rate_usd * hours
    buffered_usd = raw_usd * 1.20
    return _usd_to_credits(buffered_usd)


# ── Balance ───────────────────────────────────────────────────────────────────

@router.get("/credits", response_model=CreditBalanceResponse)
async def get_credits(user: dict = Depends(require_auth)):
    if TESTING_MODE:
        return CreditBalanceResponse(
            user_id=user["user_id"],
            balance_credits=TESTING_CREDITS_BALANCE,
            reserved_credits=0,
            spent_credits=0,
            available_credits=TESTING_CREDITS_BALANCE,
            available_usd=TESTING_CREDITS_BALANCE / 100,
        )
    try:
        bal = get_balance(user["user_id"])
    except Exception:
        from api.db import SIGNUP_BONUS_IMMEDIATE_CREDITS
        bal = {
            "user_id": user["user_id"],
            "balance_credits": SIGNUP_BONUS_IMMEDIATE_CREDITS,
            "reserved_credits": 0,
            "spent_credits": 0,
            "available_credits": SIGNUP_BONUS_IMMEDIATE_CREDITS,
            "available_usd": SIGNUP_BONUS_IMMEDIATE_CREDITS / 100,
        }
    return CreditBalanceResponse(**bal)


# ── Job start (reserve) ───────────────────────────────────────────────────────

@router.post("/jobs/start", response_model=JobStartResponse)
async def start_job(req: JobStartRequest, user: dict = Depends(require_auth)):
    user_id = user["user_id"]

    # ── Testing mode: approve immediately, skip all DB / credit logic ─────────
    if TESTING_MODE:
        logger.info(f"[credits] TESTING_MODE: start_job approved for {req.job_id} (no DB write)")
        return JobStartResponse(
            approved=True,
            job_id=req.job_id,
            credits_reserved=0,
            available_after=TESTING_CREDITS_BALANCE,
        )

    if not await _check_rate_limit(_start_timestamps, user_id, _START_LIMIT, "start"):
        raise HTTPException(status_code=429, detail="Too many job start requests. Slow down.")
    bal = get_balance(user_id)
    credits_to_reserve = _estimate_credits(req.hourly_rate_usd, req.estimated_hours)

    # TESTING PHASE: credit check is a soft warning — never block job start.
    # Once payments go live, replace this block with a hard 402 raise.
    if bal["available_credits"] < credits_to_reserve:
        needed_usd = _credits_to_usd(credits_to_reserve)
        available_usd = _credits_to_usd(bal["available_credits"])
        logger.warning(
            f"[credits] SOFT CHECK: {user_id} has insufficient credits "
            f"({bal['available_credits']} available, {credits_to_reserve} needed) — "
            f"allowing during testing phase."
        )
        # Allow the job but reserve whatever is available (could be 0)
        credits_to_reserve = min(credits_to_reserve, bal["available_credits"])

    # Reserve credits (negative = debit from available)
    add_credit_event(
        user_id=user_id,
        event_type="reserved",
        amount_credits=-credits_to_reserve,
        job_id=req.job_id,
        description=f"Reserved for job {req.job_id} ({req.estimated_hours}h @ ${req.hourly_rate_usd}/hr)",
    )

    # Write job row to Supabase (powers dashboard from day 1)
    upsert_job(req.job_id, user_id, {
        "name":                 req.name or req.job_id,
        "status":               "queued",
        "provider":             req.provider,
        "gpu_type":             req.gpu_type,
        "command":              req.command,
        "training_mode":        req.training_mode,
        "model_params_billion": req.model_params_billion,
        "docker_image":         req.docker_image,
        "credits_reserved":     credits_to_reserve,
        "hourly_rate_credits":  _usd_to_credits(req.hourly_rate_usd),
    })

    bal_after = get_balance(user_id)
    logger.info(
        f"[credits] {user_id} reserved {credits_to_reserve} credits for job {req.job_id}. "
        f"Available: {bal_after['available_credits']}"
    )
    return JobStartResponse(
        approved=True,
        job_id=req.job_id,
        credits_reserved=credits_to_reserve,
        available_after=bal_after["available_credits"],
    )


# ── Burn (real-time consumption) ──────────────────────────────────────────────

@router.post("/jobs/{job_id}/burn", response_model=BurnResponse)
async def burn_credits(job_id: str, req: BurnRequest, user: dict = Depends(require_auth)):
    user_id = user["user_id"]

    # ── Testing mode: no-op burn, return unlimited balance ───────────────────
    if TESTING_MODE:
        logger.debug(f"[credits] TESTING_MODE: burn no-op for job {job_id}")
        return BurnResponse(
            job_id=job_id,
            credits_burned=0,
            available_credits=TESTING_CREDITS_BALANCE,
            status="ok",
        )

    if not await _check_rate_limit(_burn_timestamps, user_id, _BURN_LIMIT, "burn"):
        raise HTTPException(status_code=429, detail="Burn rate limit exceeded.")

    hours_elapsed = req.elapsed_seconds / 3600
    credits_burned = _usd_to_credits(req.hourly_rate_usd * hours_elapsed)

    if credits_burned <= 0:
        bal = get_balance(user_id)
        return BurnResponse(
            job_id=job_id,
            credits_burned=0,
            available_credits=bal["available_credits"],
            status="ok",
        )

    add_credit_event(
        user_id=user_id,
        event_type="burned",
        amount_credits=-credits_burned,
        job_id=job_id,
        description=f"Burn {req.elapsed_seconds:.0f}s @ ${req.hourly_rate_usd}/hr",
    )

    # Check staged bonus release (first job >10 min)
    await maybe_release_staged_bonus(user_id, req.elapsed_seconds)

    bal = get_balance(user_id)
    available = bal["available_credits"]

    # Dynamic kill switch: suspend if balance can't cover 10 more minutes at current rate.
    # Falls back to EXHAUSTED_THRESHOLD ($0.50) if the dynamic threshold is lower.
    _ten_min_credits = int((10.0 / 60.0) * req.hourly_rate_usd * 100)  # 100 credits = $1
    _dynamic_threshold = max(EXHAUSTED_THRESHOLD, _ten_min_credits)
    if available <= _dynamic_threshold:
        update_job(job_id, {"status": "suspended", "suspended_at": "now()"})
        await send_job_suspended(user["email"], job_id, available)
        logger.warning(
            f"[credits] {user_id} EXHAUSTED ({available} credits, "
            f"threshold={_dynamic_threshold}). Job {job_id} suspended."
        )
        return BurnResponse(job_id=job_id, credits_burned=credits_burned,
                            available_credits=available, status="exhausted")

    if available <= LOW_CREDITS_THRESHOLD:
        await send_credits_low(user["email"], available)
        logger.info(f"[credits] {user_id} LOW ({available} credits).")
        return BurnResponse(job_id=job_id, credits_burned=credits_burned,
                            available_credits=available, status="low")

    return BurnResponse(job_id=job_id, credits_burned=credits_burned,
                        available_credits=available, status="ok")


# ── Gainshare Stripe reporting ────────────────────────────────────────────────

def _report_gainshare_to_stripe(stripe_customer_id: str, gainshare_usd: float, job_id: str) -> None:
    """Push compute gainshare to Stripe metered billing. Non-fatal."""
    stripe_key = os.getenv("STRIPE_SECRET_KEY", "")
    meter_name = os.getenv("STRIPE_GAINSHARE_METER_NAME", "vaultlayer_gainshare_usd")
    if not stripe_key or gainshare_usd <= 0:
        return
    try:
        import stripe
        from datetime import datetime, timezone
        stripe.api_key = stripe_key
        cents = max(1, int(gainshare_usd * 100))
        stripe.billing.MeterEvent.create(
            event_name=meter_name,
            payload={"stripe_customer_id": stripe_customer_id, "value": str(cents)},
            timestamp=int(datetime.now(timezone.utc).timestamp()),
        )
        logger.info(f"[gainshare] Stripe event: job={job_id} usd={gainshare_usd:.4f} cents={cents}")
    except Exception as e:
        logger.error(f"[gainshare] Stripe report failed for job {job_id}: {e}")


# ── Settle (job end) ──────────────────────────────────────────────────────────

@router.post("/jobs/{job_id}/settle", response_model=SettleResponse)
async def settle_job(job_id: str, req: SettleRequest, user: dict = Depends(require_auth)):
    user_id = user["user_id"]

    # ── Testing mode: no-op settle, skip DB writes and Stripe gainshare ──────
    if TESTING_MODE:
        actual_hours = req.actual_seconds / 3600
        actual_credits = _usd_to_credits(req.hourly_rate_usd * actual_hours)
        logger.info(
            f"[credits] TESTING_MODE: settle no-op for job {job_id} "
            f"({actual_credits} credits, gainshare skipped)"
        )
        return SettleResponse(
            job_id=job_id,
            credits_charged=actual_credits,
            credits_released=0,
            available_credits=TESTING_CREDITS_BALANCE,
        )

    actual_hours = req.actual_seconds / 3600
    actual_credits = _usd_to_credits(req.hourly_rate_usd * actual_hours)

    # Release any remaining reservation
    # (burn() already debited consumed credits; reservation that wasn't burned is freed)
    add_credit_event(
        user_id=user_id,
        event_type="settled",
        amount_credits=0,       # net zero — reservation release + actual already in burn
        job_id=job_id,
        description=(
            f"Settled job {job_id}: {req.actual_seconds:.0f}s actual, "
            f"{actual_credits} credits total"
        ),
    )

    update_job(job_id, {
        "status":              req.final_status,
        "completed_at":        "now()",
        "credits_spent":       actual_credits,
        "current_step":        req.final_step,
        "checkpoint_count":    req.checkpoint_count,
        "interruption_count":  req.interruption_count,
    })

    # Report gainshare to Stripe — use actual AWS OD rate for the GPU, not a hardcoded multiplier
    actual_spend_usd = req.hourly_rate_usd * actual_hours
    if req.aws_equivalent_usd:
        aws_equivalent_usd = req.aws_equivalent_usd
    else:
        # Fallback: look up the real AWS OD rate for this GPU type
        try:
            from shared.compute_tiers import get_aws_od_rate
            _aws_rate = get_aws_od_rate(req.gpu_type) if hasattr(req, "gpu_type") and req.gpu_type else 0.0
            aws_equivalent_usd = _aws_rate * actual_hours if _aws_rate > 0 else actual_spend_usd * 2.5
        except Exception:
            aws_equivalent_usd = actual_spend_usd * 2.5  # conservative fallback
    gross_savings = aws_equivalent_usd - actual_spend_usd
    gainshare_usd = round(gross_savings * 0.40, 4) if gross_savings > 0 else 0.0

    try:
        from api.db import get_db
        user_row = get_db().table("users").select("stripe_customer_id") \
                       .eq("user_id", user_id).single().execute().data
        stripe_cid = (user_row or {}).get("stripe_customer_id")
        if stripe_cid:
            _report_gainshare_to_stripe(stripe_cid, gainshare_usd, job_id)
    except Exception as e:
        logger.warning(f"[gainshare] Could not fetch stripe_customer_id for {user_id}: {e}")

    bal = get_balance(user_id)
    logger.info(
        f"[credits] {user_id} job {job_id} settled. "
        f"Actual: {actual_credits} credits. Gainshare: ${gainshare_usd:.4f}. "
        f"Available: {bal['available_credits']}"
    )
    return SettleResponse(
        job_id=job_id,
        credits_charged=actual_credits,
        credits_released=0,
        available_credits=bal["available_credits"],
    )


# ── Per-job scoped credentials ────────────────────────────────────────────────

@router.post("/jobs/credentials", response_model=JobCredentialsResponse)
async def get_job_credentials(
    req: JobCredentialsRequest,
    user: dict = Depends(require_auth),
):
    """
    Vend short-lived, prefix-scoped R2 credentials for a job the caller owns.

    Called by the broker when provisioning a GPU node. The node receives
    credentials restricted to checkpoints/{job_id}/* (the actual data
    layout — see r2.py). The Redis URL is no longer returned: it was a
    pub/sub access leak (any authed user could SUBSCRIBE * to all
    VaultLayer channels). Job ownership is verified to prevent
    cross-tenant credential minting.
    """
    minter = _get_r2_minter()
    if minter is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="R2 credential minting is not configured on this deployment.",
        )

    # Ownership check: same pattern as POST /credentials/provider.
    from api.job_worker import _active_jobs
    job = _active_jobs.get(req.job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    if job.get("user_id") != user.get("user_id"):
        logger.warning(
            "[credentials] Cross-tenant R2 mint blocked: user=%s job=%s owner=%s",
            user.get("user_id"), req.job_id, job.get("user_id"),
        )
        raise HTTPException(status_code=404, detail="Job not found")
    if job.get("status") not in ("queued", "provisioning", "running"):
        raise HTTPException(
            status_code=409,
            detail=f"Job is in status '{job.get('status')}' — R2 credentials "
                   "are only minted for active jobs.",
        )

    ttl = min(max(req.ttl_seconds, 300), 4 * 3600)  # clamp: 5min – 4hr

    try:
        creds = minter.mint(job_id=req.job_id, ttl_seconds=ttl)
    except RuntimeError as e:
        logger.error(f"[credentials] Mint failed for job {req.job_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Failed to mint R2 credentials: {e}",
        )

    r2_endpoint = os.environ.get("R2_ENDPOINT", "")
    r2_bucket = os.environ.get("R2_BUCKET", "vaultlayer-checkpoints")

    logger.info(
        f"[credentials] Issued scoped R2 token for user={user['user_id']} "
        f"job={req.job_id} ttl={ttl}s prefix={creds.prefix}"
    )

    return JobCredentialsResponse(
        job_id=req.job_id,
        r2_access_key_id=creds.access_key_id,
        r2_secret_access_key=creds.secret_access_key,
        r2_session_token=creds.session_token,
        r2_endpoint=r2_endpoint,
        r2_bucket=r2_bucket,
        r2_prefix=creds.prefix,
        expires_at=creds.expires_at,
    )
