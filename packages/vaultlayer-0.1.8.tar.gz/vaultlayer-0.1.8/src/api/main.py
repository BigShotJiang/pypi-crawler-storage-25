"""
VaultLayer API — FastAPI service deployed on Railway.

Routes:
  POST /api/v1/auth/clerk-webhook   Clerk user.created → create user + issue token
  POST /api/v1/auth/validate        CLI token validation (vaultlayer init)
  GET  /api/v1/credits              Balance for authenticated user
  POST /api/v1/jobs/start           Reserve credits + create job row (soft-check during testing)
  POST /api/v1/jobs/{id}/burn       Real-time credit consumption (60s tick)
  POST /api/v1/jobs/{id}/settle     Final settlement at job end
  GET  /health                      Railway health check

  POST /api/v1/stripe/checkout       Create Stripe checkout session (buy credits)
  POST /api/v1/stripe/webhook        Stripe payment_intent.succeeded → add credits

  POST /api/v1/credentials/provider  Serve VaultLayer's managed provider API key to agents
  GET  /api/v1/credentials/providers List which providers are currently available

  GET  /api/v1/pricing/gpu                      All GPU types — live rates + AWS OD anchoring (public)
  GET  /api/v1/pricing/gpu/{gpu_type}           Single GPU — best rate, tier, comparison banner data
  GET  /api/v1/pricing/compare                  Job-cost estimate: VaultLayer vs AWS OD for N hours
  GET  /api/v1/pricing/gpu/{gpu_type}/availability  Availability check + fallback offer
  POST /api/v1/jobs/{job_id}/hop-consent        Record user consent for GPU hot-swap (Zero-Downtime Hop)

NOTE: Stripe payment routes are gated by TESTING_MODE flag (disabled during testing phase).
"""
from __future__ import annotations

import asyncio
import logging
import os
import time

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware

from api.admin_dashboard import router as admin_router
from api.auth import parse_clerk_webhook, validate_token
from api.credentials import router as credentials_router
from api.credits import router as credits_router
from api.db import create_api_token, create_user, get_db, add_credit_event
from api.email import send_welcome
from api.feedback_routes import router as feedback_router
from api.flags import TESTING_MODE
from api.fraud import check_ip_rate_limit
from api.models import TokenValidateResponse
from api.pricing_routes import router as pricing_router, jobs_router as pricing_jobs_router
from api.job_routes import jobs_router as job_data_router, datasets_router as dataset_data_router, config_router
from api.admin_routes import admin_jobs_router, admin_gcp_router
from api.invite_routes import admin_invites_router, public_invites_router
from api.smoke_routes import router as smoke_router
from api.stripe_routes import router as stripe_router

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="VaultLayer API",
    version="0.1.0",
    docs_url="/docs" if os.environ.get("ENV") != "production" else None,
    redoc_url=None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://vaultlayer.ai", "https://vaultlayer.pages.dev",
                   "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(credentials_router)
app.include_router(credits_router)
app.include_router(feedback_router)
app.include_router(admin_router)
app.include_router(stripe_router)
app.include_router(pricing_router)
app.include_router(pricing_jobs_router)
app.include_router(smoke_router)
app.include_router(job_data_router)
app.include_router(dataset_data_router)
app.include_router(config_router)
app.include_router(admin_jobs_router)
app.include_router(admin_gcp_router)
app.include_router(admin_invites_router)
app.include_router(public_invites_router)


# ── Background provision worker ──────────────────────────────────────────────

@app.on_event("startup")
async def _start_job_worker():
    """Launch the server-side job lifecycle worker as a background task."""
    # Skip when running under pytest or VL_TESTING_MODE
    import sys
    if "pytest" in sys.modules or os.environ.get("VL_TESTING_MODE"):
        return
    from api.job_worker import _job_worker
    asyncio.get_event_loop().create_task(_job_worker())
    logger.info("Job lifecycle worker started")

    # Daily AWS bill reconciliation — fills in provider_billed_usd on
    # job_runs rows 48h after termination, flags drift > 25% for admin review.
    # Gated by VL_RECONCILE_ENABLED so it can be disabled without code changes
    # (e.g. if AWS creds are misconfigured on a given Railway env).
    if os.environ.get("VL_RECONCILE_ENABLED", "true").lower() in ("true", "1", "yes"):
        from api.bill_reconcile import _reconcile_loop
        asyncio.get_event_loop().create_task(_reconcile_loop())
        logger.info("Bill reconciliation loop started")
    else:
        logger.info("Bill reconciliation disabled (VL_RECONCILE_ENABLED=false)")


# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    """
    Liveness probe for Railway.
    Always returns 200 if the process is running — Railway only needs to know
    the service is alive. Dependency status (Supabase, Redis) is reported in
    the response body for observability but never causes a 503, which would
    trigger unnecessary redeploys.

    Use GET /status for a strict readiness check (returns 503 on dep failure).
    """
    checks: dict = {}
    start = time.monotonic()

    # ── Redis check ───────────────────────────────────────────────────────────
    redis_url = os.environ.get("UPSTASH_REDIS_URL", "") or os.environ.get("REDIS_URL", "")
    if redis_url:
        try:
            import redis.asyncio as aioredis
            r = aioredis.from_url(redis_url, socket_connect_timeout=2, socket_timeout=2)
            await asyncio.wait_for(r.ping(), timeout=3.0)
            await r.aclose()
            checks["redis"] = {"status": "ok"}
        except Exception as _e:
            checks["redis"] = {"status": "error", "detail": str(_e)[:120]}
    else:
        checks["redis"] = {"status": "unconfigured"}

    # ── Supabase check ────────────────────────────────────────────────────────
    supabase_url = os.environ.get("SUPABASE_URL", "")
    supabase_key = os.environ.get("SUPABASE_SERVICE_KEY", "")
    if supabase_url and supabase_key:
        try:
            from api.db import get_db
            db = get_db()
            loop = asyncio.get_event_loop()
            await asyncio.wait_for(
                loop.run_in_executor(
                    None,
                    lambda: db.table("credit_events").select("user_id").limit(1).execute(),
                ),
                timeout=5.0,
            )
            checks["supabase"] = {"status": "ok"}
        except Exception as _e:
            checks["supabase"] = {"status": "error", "detail": str(_e)[:120]}
    else:
        checks["supabase"] = {"status": "unconfigured"}

    elapsed_ms = round((time.monotonic() - start) * 1000, 1)
    deps_ok = all(v.get("status") in ("ok", "unconfigured") for v in checks.values())
    return {
        "status": "ok" if deps_ok else "degraded",
        "checks": checks,
        "elapsed_ms": elapsed_ms,
    }


@app.get("/status")
async def status():
    """
    Strict readiness check — returns 503 if any configured dependency is down.
    Use this for uptime monitors, not for Railway's healthcheck path.
    """
    checks: dict = {}
    overall_ok = True
    start = time.monotonic()

    redis_url = os.environ.get("UPSTASH_REDIS_URL", "") or os.environ.get("REDIS_URL", "")
    if redis_url:
        try:
            import redis.asyncio as aioredis
            r = aioredis.from_url(redis_url, socket_connect_timeout=2, socket_timeout=2)
            await asyncio.wait_for(r.ping(), timeout=3.0)
            await r.aclose()
            checks["redis"] = {"status": "ok"}
        except Exception as _e:
            checks["redis"] = {"status": "error", "detail": str(_e)[:120]}
            overall_ok = False
    else:
        checks["redis"] = {"status": "unconfigured"}

    supabase_url = os.environ.get("SUPABASE_URL", "")
    supabase_key = os.environ.get("SUPABASE_SERVICE_KEY", "")
    if supabase_url and supabase_key:
        try:
            from api.db import get_db
            db = get_db()
            loop = asyncio.get_event_loop()
            await asyncio.wait_for(
                loop.run_in_executor(
                    None,
                    lambda: db.table("credit_events").select("user_id").limit(1).execute(),
                ),
                timeout=5.0,
            )
            checks["supabase"] = {"status": "ok"}
        except Exception as _e:
            checks["supabase"] = {"status": "error", "detail": str(_e)[:120]}
            overall_ok = False
    else:
        checks["supabase"] = {"status": "unconfigured"}

    elapsed_ms = round((time.monotonic() - start) * 1000, 1)
    response = {
        "status": "ok" if overall_ok else "degraded",
        "checks": checks,
        "elapsed_ms": elapsed_ms,
    }
    if not overall_ok:
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=503, content=response)
    return response


# ── Auth: Clerk webhook (user.created) ────────────────────────────────────────

@app.post("/api/v1/auth/clerk-webhook")
async def clerk_webhook(request: Request):
    """
    Called by Clerk when a new user signs up.
    Creates the user row, issues API token, sends welcome email.
    """
    # ── Testing mode: skip user creation entirely ─────────────────────────────
    if TESTING_MODE:
        logger.info("[auth] TESTING_MODE: clerk-webhook no-op")
        return {"received": True, "testing_mode": True}

    event = await parse_clerk_webhook(request)
    if not event or event.get("type") != "user.created":
        return {"received": True}

    data = event.get("data", {})
    user_id = data.get("id")
    email_addresses = data.get("email_addresses", [])
    email = email_addresses[0]["email_address"] if email_addresses else ""

    if not user_id or not email:
        raise HTTPException(status_code=400, detail="Missing user_id or email")

    # Extract signup IP from Clerk event metadata
    signup_ip = data.get("unsafe_metadata", {}).get("signup_ip") or \
                request.headers.get("x-forwarded-for", "").split(",")[0].strip()

    # ── Fraud: IP rate limit ─────────────────────────────────────────────────
    if signup_ip:
        allowed, reason = await check_ip_rate_limit(signup_ip)
        if not allowed:
            logger.warning(f"[auth] Signup blocked for {email} from {signup_ip}: {reason}")
            # Return 200 to Clerk (don't reveal the block) but don't create the user
            # The user won't receive a token and will see an error in the dashboard
            return {"received": True, "action": "blocked", "reason": reason}

    # ── Create user + issue token ────────────────────────────────────────────
    referred_by_code = data.get("unsafe_metadata", {}).get("referred_by_code")
    await create_user(
        user_id=user_id,
        email=email,
        signup_ip=signup_ip,
        signup_device_fp=data.get("unsafe_metadata", {}).get("device_fp"),
        referred_by_code=referred_by_code,
    )

    raw_token = await create_api_token(user_id)

    from api.db import SIGNUP_BONUS_IMMEDIATE_CREDITS
    await send_welcome(email, raw_token, SIGNUP_BONUS_IMMEDIATE_CREDITS)

    logger.info(f"[auth] New user {user_id} ({email}) created, token issued")
    return {"received": True, "user_id": user_id}


# ── Auth: CLI signup / login with email verification code ───────────────────

import hashlib as _hashlib
import secrets as _secrets
from datetime import datetime as _dt, timezone as _tz, timedelta as _td

_CODE_EXPIRY_MINUTES = 10
_CODE_RATE_LIMIT = 3  # max codes per email per hour


def _hash_code(code: str) -> str:
    return _hashlib.sha256(code.encode()).hexdigest()


def _generate_code() -> str:
    return f"{_secrets.randbelow(1000000):06d}"


async def _send_code(email: str, action: str) -> dict:
    """Generate a 6-digit code, store hash in DB, send via email."""
    try:
        db = get_db()
    except Exception as e:
        logger.error(f"[auth] DB connection failed: {e}")
        raise HTTPException(503, "Database temporarily unavailable")

    # Rate limit: max 3 codes per email per hour
    try:
        one_hour_ago = (_dt.now(_tz.utc) - _td(hours=1)).isoformat()
        recent = db.table("verification_codes").select("id").eq(
            "email", email.lower()
        ).gte("created_at", one_hour_ago).execute()
        if len(recent.data or []) >= _CODE_RATE_LIMIT:
            raise HTTPException(429, "Too many attempts. Try again in an hour.")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[auth] Rate limit check failed: {e}")
        # Proceed without rate limit check rather than block signup

    code = _generate_code()
    code_hash = _hash_code(code)
    expires_at = (_dt.now(_tz.utc) + _td(minutes=_CODE_EXPIRY_MINUTES)).isoformat()

    try:
        db.table("verification_codes").insert({
            "email": email.lower(),
            "code_hash": code_hash,
            "action": action,
            "expires_at": expires_at,
        }).execute()
    except Exception as e:
        logger.error(f"[auth] Failed to store verification code: {e}")
        raise HTTPException(503, f"Could not store verification code: {e}")

    # Send code via email
    try:
        from api.email import send_verification_code
        await send_verification_code(email, code)
    except Exception as e:
        logger.error(f"[auth] Failed to send verification email to {email}: {e}")
        raise HTTPException(503, f"Could not send verification email. Check RESEND_API_KEY is configured.")

    return {"message": "Verification code sent to your email", "expires_in": _CODE_EXPIRY_MINUTES * 60}


@app.post("/api/v1/auth/signup")
async def cli_signup(request: Request):
    """Send a verification code for new account creation."""
    try:
        body = await request.json()
        email = (body.get("email") or "").strip().lower()
        if not email or "@" not in email:
            raise HTTPException(400, "Valid email required")

        # Check if email already registered
        db = get_db()
        existing = db.table("users").select("user_id").eq("email", email).execute()
        if existing.data:
            raise HTTPException(409, "Account already exists. Use 'vaultlayer login' instead.")

        return await _send_code(email, "signup")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[auth] signup failed: {e}", exc_info=True)
        raise HTTPException(500, f"Signup failed: {e}")


@app.post("/api/v1/auth/login")
async def cli_login(request: Request):
    """Send a verification code for existing account login."""
    try:
        body = await request.json()
        email = (body.get("email") or "").strip().lower()
        if not email or "@" not in email:
            raise HTTPException(400, "Valid email required")

        db = get_db()
        existing = db.table("users").select("user_id").eq("email", email).execute()
        if not existing.data:
            raise HTTPException(404, "No account found. Use 'vaultlayer signup' to create one.")

        return await _send_code(email, "login")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[auth] login failed: {e}", exc_info=True)
        raise HTTPException(500, f"Login failed: {e}")


@app.post("/api/v1/auth/verify")
async def cli_verify(request: Request):
    """Verify a 6-digit code and return an API token."""
    body = await request.json()
    email = (body.get("email") or "").strip().lower()
    code = (body.get("code") or "").strip()
    action = body.get("action", "signup")

    if not email or not code:
        raise HTTPException(400, "Email and code required")
    if len(code) != 6 or not code.isdigit():
        raise HTTPException(400, "Code must be 6 digits")

    db = get_db()
    code_hash = _hash_code(code)
    now = _dt.now(_tz.utc).isoformat()

    # Find matching unused code
    result = db.table("verification_codes").select("id, expires_at").eq(
        "email", email
    ).eq("code_hash", code_hash).eq("action", action).is_(
        "used_at", "null"
    ).execute()

    if not result.data:
        raise HTTPException(401, "Invalid code. Check your email and try again.")

    row = result.data[0]

    # Check expiry
    expires_at = row["expires_at"].replace("Z", "+00:00")
    if _dt.fromisoformat(expires_at) < _dt.now(_tz.utc):
        raise HTTPException(410, f"Code expired. Run 'vaultlayer {action}' again to get a new code.")

    # Mark as used
    db.table("verification_codes").update({"used_at": now}).eq("id", row["id"]).execute()

    if action == "signup":
        # Create new user
        user_id = f"cli-{_secrets.token_hex(8)}"
        await create_user(user_id=user_id, email=email)
        raw_token = await create_api_token(user_id)
        from api.db import SIGNUP_BONUS_IMMEDIATE_CREDITS
        logger.info(f"[auth] CLI signup: {email} → {user_id}, {SIGNUP_BONUS_IMMEDIATE_CREDITS} credits")
        return {
            "token": raw_token,
            "email": email,
            "user_id": user_id,
            "balance_credits": SIGNUP_BONUS_IMMEDIATE_CREDITS,
            "is_new": True,
            "message": f"Account created! {SIGNUP_BONUS_IMMEDIATE_CREDITS} credits (${SIGNUP_BONUS_IMMEDIATE_CREDITS/100:.0f}) added.",
        }
    else:
        # Existing user — issue new token
        user_row = db.table("users").select("user_id").eq("email", email).execute()
        if not user_row.data:
            raise HTTPException(404, "User not found")
        user_id = user_row.data[0]["user_id"]
        raw_token = await create_api_token(user_id)
        # Get balance
        from api.db import add_credit_event
        bal_res = db.table("credit_events").select("amount_credits").eq("user_id", user_id).execute()
        balance = sum(r["amount_credits"] for r in (bal_res.data or []))
        logger.info(f"[auth] CLI login: {email} → {user_id}, balance={balance}")
        return {
            "token": raw_token,
            "email": email,
            "user_id": user_id,
            "balance_credits": balance,
            "is_new": False,
            "message": f"Welcome back! Balance: {balance} credits (${balance/100:.2f})",
        }


# ── Auth: token validation (CLI vaultlayer init) ──────────────────────────────

@app.post("/api/v1/auth/validate", response_model=TokenValidateResponse)
async def validate(request: Request):
    body = await request.json()
    raw_token = body.get("token", "")
    return await validate_token(raw_token)
