"""
VaultLayer — Smoke Test Tracking API

Provides visibility into prod smoke test results stored in job_runs + spend_ledger.
Every provider smoke test (VL_PROD_TEST=1) writes to these tables with:
  - job_runs.run_type = 'smoke_test'
  - spend_ledger.is_test = True

Endpoints:
  GET /api/v1/admin/smoke-tests           — All smoke test runs (with filters)
  GET /api/v1/admin/smoke-tests/summary   — Per-provider summary (pass rate, cost, latency)
"""
import logging
import os
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from typing import Optional

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/admin/smoke-tests", tags=["admin-smoke"])


def _require_admin(x_admin_secret: str = Header("", alias="X-Admin-Secret")):
    """Require X-Admin-Secret header matching VAULTLAYER_ADMIN_SECRET."""
    expected = os.environ.get("VAULTLAYER_ADMIN_SECRET", "")
    if not expected:
        raise HTTPException(503, "VAULTLAYER_ADMIN_SECRET not configured")
    if x_admin_secret != expected:
        raise HTTPException(401, "Invalid admin secret")
    return True


@router.get("")
async def list_smoke_tests(
    provider: Optional[str] = Query(None, description="Filter by provider name"),
    status: Optional[str] = Query(None, description="Filter by status (terminated, failed, etc.)"),
    days: int = Query(30, description="Look back N days"),
    limit: int = Query(50, description="Max results"),
    _=Depends(_require_admin),
):
    """
    List all smoke test runs from job_runs table.

    Returns each run with: provider, GPU, instance_id, billing_seconds,
    estimated_cost_usd, provider_billed_usd, status, timestamps.
    """
    try:
        from api.db import get_db, _db_call
        db = get_db()
        if not db:
            raise HTTPException(503, "Database not configured")

        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        query = (
            db.table("job_runs")
            .select("*")
            .eq("run_type", "smoke_test")
            .gte("created_at", cutoff)
            .order("created_at", desc=True)
            .limit(limit)
        )
        if provider:
            query = query.eq("provider", provider)
        if status:
            query = query.eq("status", status)

        result = _db_call(lambda: query.execute(), label="smoke:list")
        return {
            "count": len(result.data or []),
            "runs": result.data or [],
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[smoke-api] list failed: {e}")
        raise HTTPException(500, f"Failed to query smoke tests: {e}")


@router.get("/summary")
async def smoke_test_summary(
    days: int = Query(90, description="Look back N days"),
    _=Depends(_require_admin),
):
    """
    Per-provider summary of smoke test results.

    For each provider returns: total runs, passed, failed, pass rate,
    average provision latency, total cost, average cost per run.
    """
    try:
        from api.db import get_db, _db_call
        db = get_db()
        if not db:
            raise HTTPException(503, "Database not configured")

        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        result = _db_call(
            lambda: db.table("job_runs")
                .select("provider, gpu_type, status, billing_seconds, "
                        "estimated_cost_usd, provider_billed_usd, "
                        "provisioned_at, terminated_at, created_at")
                .eq("run_type", "smoke_test")
                .gte("created_at", cutoff)
                .execute(),
            label="smoke:summary",
        )
        rows = result.data or []

        # Group by provider
        from collections import defaultdict
        by_provider: dict[str, list] = defaultdict(list)
        for r in rows:
            by_provider[r.get("provider", "unknown")].append(r)

        summary = []
        for prov, runs in sorted(by_provider.items()):
            total = len(runs)
            passed = sum(1 for r in runs if r.get("status") == "terminated")
            failed = sum(1 for r in runs if r.get("status") in ("failed", "termination_failed"))
            total_cost = sum(float(r.get("estimated_cost_usd") or 0) for r in runs)
            total_billed = sum(float(r.get("provider_billed_usd") or 0) for r in runs
                               if r.get("provider_billed_usd") is not None)
            avg_billing_s = (
                sum(float(r.get("billing_seconds") or 0) for r in runs) / max(total, 1)
            )
            gpu_types = sorted(set(r.get("gpu_type", "") for r in runs))
            last_run = max((r.get("created_at", "") for r in runs), default="")

            summary.append({
                "provider": prov,
                "gpu_types_tested": gpu_types,
                "total_runs": total,
                "passed": passed,
                "failed": failed,
                "pass_rate_pct": round((passed / max(total, 1)) * 100, 1),
                "avg_billing_seconds": round(avg_billing_s, 1),
                "total_estimated_cost_usd": round(total_cost, 4),
                "total_provider_billed_usd": round(total_billed, 4),
                "cost_discrepancy_usd": round(abs(total_billed - total_cost), 4) if total_billed > 0 else None,
                "last_run_at": last_run,
            })

        return {
            "period_days": days,
            "total_providers_tested": len(summary),
            "total_runs": len(rows),
            "total_cost_usd": round(sum(s["total_estimated_cost_usd"] for s in summary), 4),
            "providers": summary,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[smoke-api] summary failed: {e}")
        raise HTTPException(500, f"Failed to build smoke test summary: {e}")
