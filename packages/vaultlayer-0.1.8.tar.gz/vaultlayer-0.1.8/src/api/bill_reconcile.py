"""AWS bill reconciliation — daily cron that fills in provider_billed_usd.

Flow (per AWS support guidance, locked in 2026-04-17):

  1. Daily at 08:00 UTC (Railway cron).
  2. Query Cost Explorer GetCostAndUsageWithResources for all terminations
     from T-2 days UTC (waits the 48h stability window).
  3. One paginated call with:
       Filter: Tags {Key: "VaultLayerJob", MatchOptions: [STARTS_WITH], Values: [""]}
       GroupBy: [{Type: DIMENSION, Key: RESOURCE_ID}]
       Metrics: ["UnblendedCost"]
       Granularity: HOURLY
       Service filter: "Amazon Elastic Compute Cloud - Compute"
  4. For each (instance_id, unblended_cost), UPDATE job_runs SET
     provider_billed_usd = cost WHERE instance_id = resource_id AND
     provider_billed_usd IS NULL.
  5. Call audit_bill() on every updated row; rows with delta_pct > 25%
     get audit_status='drift_flagged' for admin review.
  6. User-facing user_charged_usd is NOT modified — we honor the quoted
     rate. Drift is absorbed onto VL margin. Admin dashboard surfaces
     drift_flagged rows so ops can review.

Cost: ~$0.01 per call at $0.01/request. With 1,000 rows per page
cap, we need N_instances/1000 calls per day. At launch volume
(~1k/day) = 1 call = $0.01/day. At target volume (50k/day) = 50 calls =
$0.50/day.

Idempotency: values can shift after 48h due to late credits / SP
reallocation (rare). The monthly CUR reconciliation pass catches those.

AWS API reference:
https://docs.aws.amazon.com/aws-cost-management/latest/APIReference/API_GetCostAndUsageWithResources.html
"""
from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from typing import Optional

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

# Stability window before querying. AWS said T+48h is the earliest for
# stable numbers (credit/SP/RI reallocation can still shift earlier data).
RECONCILE_LAG_DAYS = int(os.environ.get("VL_RECONCILE_LAG_DAYS", "2"))

# Drift threshold — anything above gets flagged for ops review. Matches
# bill_auditor.ALERT_THRESHOLD_PCT.
DRIFT_FLAG_PCT = float(os.environ.get("VL_RECONCILE_DRIFT_PCT", "0.25"))

# Throttle ceiling per AWS. CE shared budget is 5 TPS; we pace at 3 TPS
# to leave headroom for ad-hoc admin queries running concurrently.
CE_PACE_SECONDS = float(os.environ.get("VL_CE_PACE_SECONDS", "0.35"))  # ~3 TPS

# Daily cron schedule — 08:00 UTC matches the existing admin dashboard's
# morning-report window. Change via VL_RECONCILE_HOUR_UTC=N for testing.
RECONCILE_HOUR_UTC = int(os.environ.get("VL_RECONCILE_HOUR_UTC", "8"))


# ─────────────────────────────────────────────────────────────────────────────
# Types
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ReconcileSummary:
    """Return value so callers (admin endpoint, cron worker) can log / display."""
    queried_day: date
    instances_returned: int
    rows_updated: int
    drifts_flagged: int
    ce_api_calls: int
    error: Optional[str] = None

    def as_dict(self) -> dict:
        return {
            "queried_day":        self.queried_day.isoformat(),
            "instances_returned": self.instances_returned,
            "rows_updated":       self.rows_updated,
            "drifts_flagged":     self.drifts_flagged,
            "ce_api_calls":       self.ce_api_calls,
            "error":              self.error,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def reconcile_aws_day(
    target_day: Optional[date] = None,
    ce_client=None,
    db=None,
    tag_key: str = "VaultLayerJob",
) -> ReconcileSummary:
    """Run one pass of AWS bill reconciliation for a single UTC day.

    Args:
      target_day: The UTC day to reconcile. Defaults to today - RECONCILE_LAG_DAYS.
      ce_client:  boto3 ce client. If None, built from env AWS creds.
      db:         Supabase client. If None, resolved via api.db.get_db().
      tag_key:    The tag whose presence identifies our instances.

    Returns a ReconcileSummary — safe to log or serialize as JSON.
    """
    if target_day is None:
        target_day = (datetime.now(timezone.utc).date() - timedelta(days=RECONCILE_LAG_DAYS))

    summary = ReconcileSummary(
        queried_day=target_day,
        instances_returned=0,
        rows_updated=0,
        drifts_flagged=0,
        ce_api_calls=0,
    )

    if ce_client is None:
        ce_client = _default_ce_client()
        if ce_client is None:
            summary.error = "no AWS credentials for Cost Explorer"
            return summary

    if db is None:
        try:
            from api.db import get_db
            db = get_db()
        except Exception as e:
            summary.error = f"supabase unavailable: {e}"
            return summary

    try:
        resource_costs = _query_ce_for_day(ce_client, target_day, tag_key, summary)
    except Exception as e:
        summary.error = f"CE query failed: {e}"
        logger.error(f"[reconcile] CE query failed for {target_day}: {e}")
        return summary

    summary.instances_returned = len(resource_costs)
    if not resource_costs:
        logger.info(f"[reconcile] {target_day}: no VaultLayer-tagged instances returned by CE")
        return summary

    # Apply each (instance_id, billed_usd) back onto job_runs
    for instance_id, billed_usd in resource_costs.items():
        try:
            if _apply_reconciliation(db, instance_id, billed_usd, summary):
                # Audit against our estimate; flag if drift exceeds threshold
                _audit_and_maybe_flag(db, instance_id, billed_usd, summary)
        except Exception as e:
            logger.warning(f"[reconcile] apply failed for {instance_id}: {e}")

    logger.info(
        f"[reconcile] {target_day}: returned={summary.instances_returned} "
        f"updated={summary.rows_updated} flagged={summary.drifts_flagged} "
        f"ce_calls={summary.ce_api_calls}"
    )
    return summary


# ─────────────────────────────────────────────────────────────────────────────
# Internals
# ─────────────────────────────────────────────────────────────────────────────

def _default_ce_client():
    """Build a boto3 ce client from env credentials. Returns None on failure."""
    ak = os.environ.get("AWS_ACCESS_KEY_ID", "") or os.environ.get("VL_AWS_ACCESS_KEY_ID", "")
    sk = os.environ.get("AWS_SECRET_ACCESS_KEY", "") or os.environ.get("VL_AWS_SECRET_ACCESS_KEY", "")
    if not (ak and sk):
        logger.warning("[reconcile] AWS creds missing — set AWS_ACCESS_KEY_ID / _SECRET")
        return None
    try:
        import boto3
        # Cost Explorer is a global service; region defaults to us-east-1
        return boto3.client(
            "ce",
            region_name="us-east-1",
            aws_access_key_id=ak,
            aws_secret_access_key=sk,
        )
    except Exception as e:
        logger.error(f"[reconcile] failed to build ce client: {e}")
        return None


def _query_ce_for_day(
    ce_client,
    target_day: date,
    tag_key: str,
    summary: ReconcileSummary,
) -> dict[str, float]:
    """Call CE GetCostAndUsageWithResources for one UTC day, return {instance_id: cost}.

    Uses the tag-filter + group-by-RESOURCE_ID pattern AWS recommended.
    Paginates until drained, pacing at 3 TPS to stay under the 5 TPS ceiling.
    """
    start = target_day.isoformat()
    end = (target_day + timedelta(days=1)).isoformat()

    kwargs = {
        "TimePeriod": {"Start": start, "End": end},
        "Granularity": "HOURLY",
        "Metrics": ["UnblendedCost"],
        "GroupBy": [{"Type": "DIMENSION", "Key": "RESOURCE_ID"}],
        "Filter": {
            "And": [
                {"Dimensions": {"Key": "SERVICE",
                                "Values": ["Amazon Elastic Compute Cloud - Compute"]}},
                {"Tags": {"Key": tag_key, "MatchOptions": ["STARTS_WITH"],
                          "Values": [""]}},
            ],
        },
    }

    out: dict[str, float] = {}
    next_token: Optional[str] = None
    while True:
        if next_token:
            kwargs["NextPageToken"] = next_token
        elif "NextPageToken" in kwargs:
            kwargs.pop("NextPageToken", None)

        resp = ce_client.get_cost_and_usage_with_resources(**kwargs)
        summary.ce_api_calls += 1

        # Each "ResultsByTime" entry has Groups with Keys=[resource_id] and
        # Metrics={"UnblendedCost": {"Amount": "0.1234", "Unit": "USD"}}
        for result in resp.get("ResultsByTime", []):
            for group in result.get("Groups", []):
                keys = group.get("Keys", [])
                if not keys:
                    continue
                instance_id = keys[0]
                if not instance_id.startswith("i-"):
                    continue  # skip non-EC2-instance resources
                amt = float(group.get("Metrics", {}).get("UnblendedCost", {}).get("Amount", "0"))
                # Sum across hourly buckets (one instance may appear in many hours)
                out[instance_id] = out.get(instance_id, 0.0) + amt

        next_token = resp.get("NextPageToken")
        if not next_token:
            break
        # Pace calls to stay under the 5-TPS CE ceiling
        time.sleep(CE_PACE_SECONDS)

    return out


def _apply_reconciliation(
    db,
    instance_id: str,
    billed_usd: float,
    summary: ReconcileSummary,
) -> bool:
    """Write provider_billed_usd onto the matching job_runs row.

    Only updates rows where provider_billed_usd IS NULL to avoid clobbering
    a value written by a more recent admin sweep or provider-API callback
    (RunPod / Vast.ai set it via their own billing APIs — we don't want to
    step on that).

    Returns True if a row was updated.
    """
    try:
        res = (
            db.table("job_runs")
            .update({"provider_billed_usd": round(billed_usd, 6)})
            .eq("instance_id", instance_id)
            .is_("provider_billed_usd", "null")
            .execute()
        )
        if res.data:
            summary.rows_updated += 1
            logger.debug(
                f"[reconcile] {instance_id}: provider_billed_usd={billed_usd:.6f}"
            )
            return True
        return False
    except Exception as e:
        logger.warning(f"[reconcile] db update failed for {instance_id}: {e}")
        return False


def _audit_and_maybe_flag(
    db,
    instance_id: str,
    billed_usd: float,
    summary: ReconcileSummary,
) -> None:
    """Run bill_auditor against the updated row; flag audit_status if drift > threshold."""
    try:
        row = (
            db.table("job_runs")
            .select("run_id, provider, billing_seconds, rate_per_hr, estimated_cost_usd")
            .eq("instance_id", instance_id)
            .limit(1)
            .execute()
        )
        if not row.data:
            return
        rec = row.data[0]

        from shared.bill_auditor import audit_bill, DiscrepancyKind
        disc = audit_bill(
            run_id=rec["run_id"],
            provider=rec.get("provider") or "aws",
            billing_seconds=int(rec.get("billing_seconds") or 0),
            rate_per_hr=float(rec.get("rate_per_hr") or 0.0),
            estimated_cost_usd=float(rec.get("estimated_cost_usd") or 0.0),
            provider_billed_usd=billed_usd,
        )
        if disc is None or disc.delta_pct <= DRIFT_FLAG_PCT:
            return

        # Flag for ops review. We store both the kind (OVERCHARGE / UNDERCHARGE /
        # ZERO_COST) and the delta% in metadata so the admin dashboard can sort
        # by magnitude.
        try:
            existing_meta = rec.get("metadata") or {}
            existing_meta.update({
                "audit_status":   "drift_flagged",
                "audit_kind":     disc.kind.value,
                "audit_delta_pct": round(disc.delta_pct, 4),
                "audit_delta_usd": round(disc.delta_usd, 6),
                "audit_at":       datetime.now(timezone.utc).isoformat(),
            })
            db.table("job_runs").update({"metadata": existing_meta}).eq(
                "run_id", rec["run_id"]
            ).execute()
            summary.drifts_flagged += 1
            logger.warning(
                f"[reconcile] DRIFT FLAGGED run_id={rec['run_id']} "
                f"kind={disc.kind.value} delta_pct={disc.delta_pct*100:.1f}% "
                f"delta=${disc.delta_usd:+.4f}"
            )
        except Exception as e:
            logger.warning(f"[reconcile] flag-write failed for {rec['run_id']}: {e}")
    except Exception as e:
        logger.warning(f"[reconcile] audit lookup failed for {instance_id}: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# Background daily-cron loop (launched from api/main.py on startup)
# ─────────────────────────────────────────────────────────────────────────────

async def _reconcile_loop():
    """Daily reconciliation loop. Sleeps until RECONCILE_HOUR_UTC, runs once,
    repeats. Safe to run on multiple Railway replicas — the idempotency check
    (provider_billed_usd IS NULL) ensures only one actually writes the row.
    """
    import asyncio as _asyncio
    logger.info(f"[reconcile] loop started — daily at {RECONCILE_HOUR_UTC:02d}:00 UTC")
    while True:
        try:
            now = datetime.now(timezone.utc)
            next_run = now.replace(hour=RECONCILE_HOUR_UTC, minute=0, second=0, microsecond=0)
            if next_run <= now:
                next_run = next_run + timedelta(days=1)
            sleep_s = (next_run - now).total_seconds()
            logger.info(f"[reconcile] next run in {sleep_s/3600:.1f}h at {next_run.isoformat()}")
            await _asyncio.sleep(sleep_s)

            summary = reconcile_aws_day()  # default = today - RECONCILE_LAG_DAYS
            logger.info(f"[reconcile] pass complete: {summary.as_dict()}")
        except Exception as e:
            logger.error(f"[reconcile] loop iteration failed (non-fatal): {e}")
            await _asyncio.sleep(3600)  # back off 1h then retry
