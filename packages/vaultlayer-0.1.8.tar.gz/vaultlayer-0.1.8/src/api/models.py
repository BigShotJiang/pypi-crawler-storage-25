"""
API request/response models (Pydantic v2).
Separate from shared/models.py — these are HTTP boundary models, not agent models.
"""
from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, EmailStr, field_validator


# ── Auth ──────────────────────────────────────────────────────────────────────

class SignupWebhookPayload(BaseModel):
    """Received from Clerk's user.created webhook."""
    user_id: str       # "usr_abc123"
    email: str
    signup_ip: Optional[str] = None
    signup_device_fp: Optional[str] = None
    referred_by_code: Optional[str] = None


class TokenValidateResponse(BaseModel):
    valid: bool
    user_id: Optional[str] = None
    email: Optional[str] = None
    balance_credits: Optional[int] = None
    message: Optional[str] = None


# ── Credits ───────────────────────────────────────────────────────────────────

class CreditBalanceResponse(BaseModel):
    user_id: str
    balance_credits: int       # total purchased (gross)
    reserved_credits: int      # locked by active jobs
    spent_credits: int         # consumed
    available_credits: int     # balance - reserved - spent
    available_usd: float       # available_credits / 100

    @property
    def is_low(self) -> bool:
        return self.available_credits < 1000   # < $10


class JobStartRequest(BaseModel):
    job_id: str
    gpu_type: str
    provider: str
    estimated_hours: float = 2.0
    hourly_rate_usd: float
    name: Optional[str] = None
    command: Optional[str] = None
    training_mode: Optional[str] = None
    model_params_billion: Optional[float] = None
    docker_image: Optional[str] = None


class JobStartResponse(BaseModel):
    approved: bool
    job_id: str
    credits_reserved: int
    available_after: int
    message: Optional[str] = None


class BurnRequest(BaseModel):
    job_id: str
    elapsed_seconds: float     # seconds since last burn tick
    hourly_rate_usd: float


class BurnResponse(BaseModel):
    job_id: str
    credits_burned: int
    available_credits: int
    status: str                # "ok" | "low" | "exhausted"


class SettleRequest(BaseModel):
    job_id: str
    actual_seconds: float
    hourly_rate_usd: float
    final_status: str          # "completed" | "failed" | "cancelled"
    final_step: Optional[int] = None
    checkpoint_count: Optional[int] = None
    interruption_count: Optional[int] = None
    aws_equivalent_usd: Optional[float] = None  # for gainshare calc; defaults to actual × 3.2


class SettleResponse(BaseModel):
    job_id: str
    credits_charged: int
    credits_released: int
    available_credits: int


# ── Job credentials ───────────────────────────────────────────────────────────

class JobCredentialsRequest(BaseModel):
    job_id: str
    ttl_seconds: int = 7200       # 2 hours default; max 4h (Cloudflare limit)


class JobCredentialsResponse(BaseModel):
    job_id: str
    # R2 scoped credentials (S3-compatible) for checkpoints/{job_id}/*
    r2_access_key_id: str
    r2_secret_access_key: str
    r2_session_token: str
    r2_endpoint: str
    r2_bucket: str
    r2_prefix: str                # e.g. "jobs/abc123/"
    expires_at: float             # Unix timestamp (UTC)
    # Redis URL was previously vended here for the watchdog to subscribe
    # to control channels. That leaked the company's full pub/sub access
    # to any authenticated user. Removed — watchdog now uses an HTTP
    # heartbeat to the API instead, and any future Redis access goes
    # through a server-side mediator.


# ── Stripe ────────────────────────────────────────────────────────────────────

class CheckoutRequest(BaseModel):
    package: str    # "starter" | "growth" | "scale"
    success_url: str
    cancel_url: str


class CheckoutResponse(BaseModel):
    checkout_url: str
    session_id: str
