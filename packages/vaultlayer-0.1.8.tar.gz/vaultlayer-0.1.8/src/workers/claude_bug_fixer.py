"""
VaultLayer — autonomous Claude bug fixer.

Analyzes user feedback, fixes bugs in the repo, runs tests, and creates PRs.
Uses Anthropic tool use for agentic file editing.
"""
from __future__ import annotations

import json
import logging
import os
import re
import subprocess
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Repo root: go up from src/workers/ to repo root in dev; use /app in prod
REPO_ROOT = Path(os.environ.get("VAULTLAYER_REPO_PATH", "")) or Path(__file__).parent.parent.parent

MODEL = "claude-opus-4-6"

# Files we must never let Claude overwrite
PROTECTED_PATHS: list[str] = [
    ".env",
    ".env.example",
    "railway.toml",
    ".github/",
    "schema/",
    "secrets/",
]

# Keyword → relevant source file mapping for context loading
_KEYWORD_FILE_MAP: list[tuple[str, str]] = [
    ("provision",   "src/agents/broker/agent.py"),
    ("checkpoint",  "src/agents/vault/agent.py"),
    ("pricing",     "src/agents/pricing/agent.py"),
    ("watchdog",    "src/agents/watchdog/agent.py"),
    ("finops",      "src/agents/finops/agent.py"),
    ("namespace",   "src/agents/namespace/agent.py"),
    ("orchestrat",  "src/agents/orchestration/agent.py"),
    ("migration",   "src/agents/broker/agent.py"),
    ("r2",          "src/agents/vault/r2.py"),
    ("config",      "src/shared/config.py"),
    ("queue",       "src/shared/queue.py"),
    ("model",       "src/shared/models.py"),
]


# ── Actionability scoring ─────────────────────────────────────────────────────

def is_actionable(feedback: dict) -> tuple[bool, str]:
    """
    Score feedback and decide whether Claude can act on it.
    Returns (True, "") if actionable, (False, follow-up question) otherwise.
    """
    score = 0

    tb = feedback.get("traceback") or ""
    message = feedback.get("message") or ""
    log_snippet = feedback.get("log_snippet") or ""
    error_type = feedback.get("error_type") or ""
    job_id = feedback.get("job_id") or ""

    if tb and len(tb) > 50:
        score += 2
    if error_type:
        score += 1
    if len(log_snippet) > 100:
        score += 1
    if job_id:
        score += 1

    if score >= 2:
        return True, ""

    question = (
        "To help us fix this, could you share:\n"
        "- The full error traceback (copy from your terminal)\n"
        "- The job ID if you have one (shown in 'vaultlayer ps')\n"
        "- What GPU type and provider you were using\n"
        "- The last few lines of output before the error"
    )
    return False, question


# ── File context loading ──────────────────────────────────────────────────────

def find_relevant_files(feedback: dict) -> dict[str, str]:
    """
    Return {relative_path: content} for files relevant to this feedback.
    Max 8000 chars per file. Only includes files under src/.
    """
    tb = feedback.get("traceback") or ""
    message = (feedback.get("message") or "") + " " + (feedback.get("error_type") or "")

    candidate_paths: set[str] = set()

    # Extract file paths from traceback frames
    for match in re.finditer(r'File "([^"]+)", line \d+', tb):
        raw_path = match.group(1)
        # Normalise to relative path under src/
        if "/src/" in raw_path:
            rel = "src/" + raw_path.split("/src/", 1)[1]
            candidate_paths.add(rel)

    # Keyword → file mapping
    for keyword, file_path in _KEYWORD_FILE_MAP:
        if keyword.lower() in message.lower():
            candidate_paths.add(file_path)

    result: dict[str, str] = {}
    for rel_path in list(candidate_paths)[:15]:  # cap candidates
        abs_path = REPO_ROOT / rel_path
        if abs_path.exists() and abs_path.is_file():
            try:
                content = abs_path.read_text(errors="replace")[:8000]
                result[rel_path] = content
            except OSError:
                pass

    return result


# ── Test runner ───────────────────────────────────────────────────────────────

def run_tests() -> tuple[bool, str]:
    """
    Run pytest. Returns (passed: bool, last 3000 chars of output).
    """
    result = subprocess.run(
        [
            "python", "-m", "pytest", "tests/", "-q",
            "--timeout=60", "-x",
            "--ignore=tests/test_auth_credits.py",
        ],
        capture_output=True,
        text=True,
        cwd=str(REPO_ROOT),
    )
    combined = result.stdout + result.stderr
    return result.returncode == 0, combined[-3000:]


# ── Git helpers ───────────────────────────────────────────────────────────────

def git_create_branch(branch_name: str) -> None:
    subprocess.run(["git", "checkout", "main"], cwd=str(REPO_ROOT), check=True)
    subprocess.run(["git", "pull", "--ff-only"], cwd=str(REPO_ROOT), check=True)
    subprocess.run(["git", "checkout", "-b", branch_name], cwd=str(REPO_ROOT), check=True)


def git_commit_and_push(branch_name: str, message: str) -> None:
    subprocess.run(["git", "add", "-A"], cwd=str(REPO_ROOT), check=True)
    subprocess.run(
        ["git", "commit", "-m", message],
        cwd=str(REPO_ROOT), check=True,
    )
    subprocess.run(
        ["git", "push", "-u", "origin", branch_name],
        cwd=str(REPO_ROOT), check=True,
    )


def _revert_branch(branch_name: str) -> None:
    """Abort changes and return to main."""
    try:
        subprocess.run(["git", "checkout", "main"], cwd=str(REPO_ROOT), check=False)
        subprocess.run(
            ["git", "branch", "-D", branch_name], cwd=str(REPO_ROOT), check=False
        )
    except Exception as exc:
        logger.warning("[bug_fixer] Could not revert branch %s: %s", branch_name, exc)


def _check_mergeable(pr_url: str) -> tuple[bool, str]:
    """
    Poll GitHub until the PR mergeability is determined (not UNKNOWN).
    Returns (mergeable: bool, reason: str).
    Waits up to 60s for GitHub to compute merge status.
    """
    import time
    for _ in range(12):  # 12 × 5s = 60s max
        result = subprocess.run(
            ["gh", "pr", "view", pr_url, "--json", "mergeable,mergeStateStatus"],
            capture_output=True, text=True, cwd=str(REPO_ROOT),
        )
        if result.returncode != 0:
            return False, f"gh pr view failed: {result.stderr.strip()}"
        try:
            data = json.loads(result.stdout)
            mergeable = data.get("mergeable", "UNKNOWN")
            state = data.get("mergeStateStatus", "UNKNOWN")
            if mergeable == "UNKNOWN":
                time.sleep(5)
                continue
            if mergeable == "CONFLICTING":
                return False, f"PR has merge conflicts (mergeStateStatus={state})"
            return True, ""
        except (json.JSONDecodeError, TypeError):
            return False, "Could not parse mergeability response"
    return False, "Mergeability check timed out after 60s"


def create_and_merge_pr(branch_name: str, title: str, body: str) -> str:
    """
    Deterministic PR lifecycle:
      1. gh pr create
      2. Verify no merge conflicts (poll up to 60s)
      3. gh pr merge --squash --auto --delete-branch
         GitHub waits for CI to pass then merges automatically.
    Raises RuntimeError if the PR has conflicts.
    Returns PR URL.
    """
    # Step 1: Create PR
    create_result = subprocess.run(
        ["gh", "pr", "create", "--title", title, "--body", body,
         "--head", branch_name, "--base", "main"],
        capture_output=True, text=True, cwd=str(REPO_ROOT), check=True,
    )
    pr_url = create_result.stdout.strip().split("\n")[-1].strip()
    logger.info("[bug_fixer] PR created: %s", pr_url)

    # Step 2: Verify mergeable (no conflicts)
    mergeable, reason = _check_mergeable(pr_url)
    if not mergeable:
        logger.error("[bug_fixer] PR %s not mergeable: %s", pr_url, reason)
        raise RuntimeError(f"PR not mergeable: {reason}")

    # Step 3: Enable auto-merge — GitHub handles CI gate and merges automatically.
    # This is the single, deterministic merge path for every PR we create.
    merge_result = subprocess.run(
        ["gh", "pr", "merge", pr_url, "--squash", "--auto", "--delete-branch"],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    if merge_result.returncode == 0:
        logger.info("[bug_fixer] Auto-merge enabled for %s", pr_url)
    else:
        # Auto-merge requires branch protection. Fall back to direct merge.
        logger.warning(
            "[bug_fixer] Auto-merge unavailable (%s), merging directly.",
            merge_result.stderr.strip(),
        )
        subprocess.run(
            ["gh", "pr", "merge", pr_url, "--squash", "--delete-branch"],
            cwd=str(REPO_ROOT), check=True,
        )
        logger.info("[bug_fixer] Direct merge completed for %s", pr_url)

    return pr_url


# ── Notification ──────────────────────────────────────────────────────────────

async def notify_reporters(primary_feedback_id: str, pr_url: str, db) -> None:
    """
    Email all users who reported the same bug (via feedback_reporters table).
    """
    from api.email import send_bug_fixed

    try:
        result = (
            db.table("feedback_reporters")
            .select("user_id, notified_at, feedback_id")
            .eq("feedback_id", primary_feedback_id)
            .is_("notified_at", None)
            .execute()
        )
        reporters = result.data or []

        for reporter in reporters:
            user_id = reporter.get("user_id")
            if not user_id:
                continue
            try:
                # Fetch user email
                user_result = db.table("users").select("email").eq("id", user_id).execute()
                users = user_result.data or []
                if not users:
                    continue
                email = users[0].get("email")
                if not email:
                    continue

                await send_bug_fixed(email, primary_feedback_id, pr_url)

                # Mark notified
                from datetime import datetime, timezone
                db.table("feedback_reporters").update(
                    {"notified_at": datetime.now(timezone.utc).isoformat()}
                ).eq("feedback_id", primary_feedback_id).eq("user_id", user_id).execute()

            except Exception as exc:
                logger.warning("[bug_fixer] Could not notify user %s: %s", user_id, exc)

    except Exception as exc:
        logger.warning("[bug_fixer] notify_reporters error: %s", exc)


# ── Runbook loader ────────────────────────────────────────────────────────────

def _load_runbook() -> str:
    """Load CLAUDE_RUNBOOK.md from repo root. Returns empty string if missing."""
    runbook_path = REPO_ROOT / "CLAUDE_RUNBOOK.md"
    try:
        return runbook_path.read_text(errors="replace")
    except OSError:
        logger.warning("[bug_fixer] CLAUDE_RUNBOOK.md not found at %s", runbook_path)
        return ""


# ── GitHub comment helper ─────────────────────────────────────────────────────

def _leave_github_comment(feedback_id: str, summary: str) -> None:
    """
    Open a GitHub issue to surface unfixable feedback so a human can review it.
    Uses gh issue create so it appears in the repo's issue tracker.
    """
    title = f"[auto] Cannot auto-fix feedback {feedback_id}"
    body = (
        f"**Feedback ID**: `{feedback_id}`\n\n"
        f"**Reason Claude could not fix this automatically**:\n\n"
        f"{summary}\n\n"
        f"---\n"
        f"*This issue was opened automatically by the VaultLayer bug-fixer worker.*\n"
        f"*Please review and fix manually, or gather more information from the reporter.*"
    )
    result = subprocess.run(
        ["gh", "issue", "create", "--title", title, "--body", body,
         "--label", "bug,needs-human-review"],
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    if result.returncode == 0:
        logger.info("[bug_fixer] GitHub issue created for %s: %s",
                    feedback_id, result.stdout.strip())
    else:
        logger.warning("[bug_fixer] Could not create GitHub issue for %s: %s",
                       feedback_id, result.stderr.strip())


# ── Path protection ───────────────────────────────────────────────────────────

def _is_protected(path: str) -> bool:
    """Return True if the path matches a protected prefix."""
    for protected in PROTECTED_PATHS:
        if path == protected or path.startswith(protected):
            return True
    return False


# ── Main entry point ──────────────────────────────────────────────────────────

async def process_feedback(feedback: dict) -> None:
    """
    Main entry: analyze feedback with Claude, fix the bug, run tests, create PR.
    Follows CLAUDE_RUNBOOK.md protocol.
    """
    import anthropic
    from api.db import get_db
    from api.email import send_needs_more_info

    db = get_db()
    feedback_id = feedback.get("id", "unknown")
    logger.info("[bug_fixer] Processing feedback %s", feedback_id)

    # ── Deduplication: skip if already resolved via primary_feedback_id ───────
    primary_id = feedback.get("primary_feedback_id")
    if primary_id and primary_id != feedback_id:
        try:
            primary = db.table("feedback").select("status, pr_url").eq("id", primary_id).execute()
            rows = primary.data or []
            if rows and rows[0].get("status") == "resolved":
                pr_url = rows[0].get("pr_url", "")
                logger.info(
                    "[bug_fixer] Feedback %s is duplicate of resolved %s (PR: %s), skipping.",
                    feedback_id, primary_id, pr_url,
                )
                from datetime import datetime, timezone
                db.table("feedback").update({
                    "status": "resolved",
                    "pr_url": pr_url,
                    "claude_analysis": f"Duplicate of {primary_id}, already resolved.",
                    "resolved_at": datetime.now(timezone.utc).isoformat(),
                }).eq("id", feedback_id).execute()
                await notify_reporters(feedback_id, pr_url, db)
                return
        except Exception as exc:
            logger.warning("[bug_fixer] Dedup check failed for %s: %s", feedback_id, exc)

    # ── Step 1: Check actionability ───────────────────────────────────────────
    actionable, follow_up_question = is_actionable(feedback)
    if not actionable:
        logger.info("[bug_fixer] Feedback %s not actionable, requesting more info.", feedback_id)

        # Email user if we have their info
        user_id = feedback.get("user_id")
        if user_id:
            try:
                user_result = db.table("users").select("email").eq("id", user_id).execute()
                users = user_result.data or []
                if users:
                    email = users[0].get("email")
                    if email:
                        await send_needs_more_info(email, feedback_id, follow_up_question)
            except Exception as exc:
                logger.warning("[bug_fixer] Could not email user %s: %s", user_id, exc)

        db.table("feedback").update({
            "status": "awaiting_user",
            "needs_more_info": follow_up_question,
        }).eq("id", feedback_id).execute()
        return

    # ── Step 2: Load relevant files ───────────────────────────────────────────
    relevant_files = find_relevant_files(feedback)

    file_listing = "\n".join(
        f"### {path}\n```python\n{content}\n```"
        for path, content in relevant_files.items()
    )

    # ── Step 3: Build Anthropic client + tools ────────────────────────────────
    client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))

    tools = [
        {
            "name": "read_file",
            "description": "Read a file from the repository. Path is relative to repo root.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative path from repo root"}
                },
                "required": ["path"],
            },
        },
        {
            "name": "write_file",
            "description": "Write content to a file in the repository. Cannot write protected paths.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative path from repo root"},
                    "content": {"type": "string", "description": "Full file content to write"},
                },
                "required": ["path", "content"],
            },
        },
        {
            "name": "run_tests",
            "description": "Run pytest on the test suite. Returns pass/fail and output.",
            "input_schema": {
                "type": "object",
                "properties": {},
            },
        },
        {
            "name": "analysis_complete",
            "description": "Signal that analysis and fixing is complete.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "can_fix": {
                        "type": "boolean",
                        "description": "True if a fix was successfully applied and tests pass.",
                    },
                    "summary": {
                        "type": "string",
                        "description": "Summary of the fix or reason it cannot be fixed.",
                    },
                    "pr_title": {
                        "type": "string",
                        "description": "Short PR title (if can_fix=True).",
                    },
                    "pr_body": {
                        "type": "string",
                        "description": "PR body with fix description (if can_fix=True).",
                    },
                },
                "required": ["can_fix", "summary"],
            },
        },
    ]

    runbook = _load_runbook()
    system_prompt = f"""You are the VaultLayer autonomous bug fixer.

## Runbook (follow exactly)
{runbook}

---

## Bug Report
- Feedback ID: {feedback_id}
- Error Type: {feedback.get('error_type', 'Unknown')}
- Message: {feedback.get('message', '')}
- Job ID: {feedback.get('job_id', 'N/A')}
- GPU: {feedback.get('gpu_type', 'N/A')}
- Provider: {feedback.get('provider', 'N/A')}
- Command: {feedback.get('command', 'N/A')}

## Traceback
```
{feedback.get('traceback', 'No traceback provided')}
```

## Log Snippet
```
{feedback.get('log_snippet', 'No logs available')}
```

## Pre-loaded Source Files
{file_listing or 'No files pre-loaded.'}

## Mandatory Workflow — follow these steps in order, no skipping

STEP 1 — IDENTIFY
  Read the traceback. Identify the exact file and line number where the error originates.
  If the file is not pre-loaded above, call read_file on it now (max 3 additional files).

STEP 2 — DIAGNOSE
  State in one sentence what the root cause is before touching any file.
  Do not write any fix until you have a clear diagnosis.

STEP 3 — FIX (one file at a time)
  Call write_file with the minimal targeted change. Do not refactor unrelated code.
  Do not add comments, docstrings, or logging beyond what is needed for the fix.
  NEVER write to protected paths: {PROTECTED_PATHS}

STEP 4 — TEST
  Call run_tests immediately after every write_file call.
  If tests fail: read the failure output, make one more targeted fix (write_file), run_tests again.
  Maximum 1 retry. If tests still fail after the retry, proceed to STEP 5 with can_fix=False.

STEP 5 — CONCLUDE
  Call analysis_complete exactly once as your final tool call.
  Set can_fix=True only if run_tests returned PASSED in STEP 4.
  Set can_fix=False if: root cause unclear, fix requires architecture change,
    tests still failing after retry, or protected files need editing.
  Always fill in pr_title and pr_body when can_fix=True.

RULES
- Call tools in order: read_file(s) → write_file → run_tests → [write_file → run_tests] → analysis_complete
- Never call analysis_complete before run_tests has returned PASSED
- Never call write_file more than twice total
- Never call run_tests more than twice total
- Keep pr_title under 72 chars, starting with "fix: "
"""

    messages = [{"role": "user", "content": "Please analyze and fix this bug."}]

    branch_name = f"fix/auto-{feedback_id}"
    can_fix = False
    summary = "No analysis completed."
    pr_title = f"fix: auto-fix for {feedback_id}"
    pr_body = ""
    files_written: list[str] = []

    # Create branch for potential fix
    try:
        git_create_branch(branch_name)
    except Exception as exc:
        logger.warning("[bug_fixer] Could not create branch %s: %s", branch_name, exc)
        db.table("feedback").update({"status": "not_actionable",
                                     "claude_analysis": f"Git error: {exc}"}).eq("id", feedback_id).execute()
        return

    # ── Step 4: Agentic loop (max 3 tool-call rounds) ────────────────────────
    MAX_ROUNDS = 3
    analysis_done = False

    db.table("feedback").update({"status": "fixing"}).eq("id", feedback_id).execute()

    for _attempt in range(MAX_ROUNDS):
        try:
            response = client.messages.create(
                model=MODEL,
                max_tokens=4096,
                system=system_prompt,
                tools=tools,
                messages=messages,
            )
        except Exception as exc:
            logger.exception("[bug_fixer] Anthropic API error: %s", exc)
            break

        # Append assistant response to message history
        messages.append({"role": "assistant", "content": response.content})

        tool_results = []
        for block in response.content:
            if block.type != "tool_use":
                continue

            tool_name = block.name
            tool_input = block.input
            tool_use_id = block.id

            if tool_name == "read_file":
                path = tool_input.get("path", "")
                abs_path = REPO_ROOT / path
                if abs_path.exists() and abs_path.is_file():
                    content = abs_path.read_text(errors="replace")[:8000]
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": tool_use_id,
                        "content": content,
                    })
                else:
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": tool_use_id,
                        "content": f"File not found: {path}",
                        "is_error": True,
                    })

            elif tool_name == "write_file":
                path = tool_input.get("path", "")
                content = tool_input.get("content", "")
                if _is_protected(path):
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": tool_use_id,
                        "content": f"ERROR: {path} is a protected path and cannot be written.",
                        "is_error": True,
                    })
                else:
                    abs_path = REPO_ROOT / path
                    abs_path.parent.mkdir(parents=True, exist_ok=True)
                    abs_path.write_text(content)
                    files_written.append(path)
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": tool_use_id,
                        "content": f"Written {path} ({len(content)} chars).",
                    })

            elif tool_name == "run_tests":
                passed, output = run_tests()
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": tool_use_id,
                    "content": f"Tests {'PASSED' if passed else 'FAILED'}:\n{output}",
                })

            elif tool_name == "analysis_complete":
                can_fix = tool_input.get("can_fix", False)
                summary = tool_input.get("summary", "")
                pr_title = tool_input.get("pr_title", pr_title)
                pr_body = tool_input.get("pr_body", "")
                analysis_done = True
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": tool_use_id,
                    "content": "Analysis recorded.",
                })

        if tool_results:
            messages.append({"role": "user", "content": tool_results})

        if analysis_done:
            break

    # ── Step 5: Handle result ─────────────────────────────────────────────────

    if not can_fix:
        logger.info("[bug_fixer] Cannot fix %s: %s", feedback_id, summary)
        _revert_branch(branch_name)
        db.table("feedback").update({
            "status": "not_actionable",
            "claude_analysis": summary,
        }).eq("id", feedback_id).execute()
        # Leave a GitHub issue so a human can review
        _leave_github_comment(feedback_id, summary)
        return

    # Run final test verification before committing
    tests_pass, test_output = run_tests()
    if not tests_pass:
        logger.warning("[bug_fixer] Final tests failed for %s, reverting.", feedback_id)
        _revert_branch(branch_name)
        db.table("feedback").update({
            "status": "not_actionable",
            "claude_analysis": f"Fix applied but tests failed:\n{test_output[-1000:]}",
        }).eq("id", feedback_id).execute()
        return

    # Commit, push, create PR, enable auto-merge
    try:
        commit_message = f"fix: auto-fix for feedback {feedback_id}\n\n{summary[:500]}"
        git_commit_and_push(branch_name, commit_message)

        if not pr_body:
            pr_body = f"Auto-fix for feedback {feedback_id}.\n\n{summary}"

        pr_url = create_and_merge_pr(branch_name, pr_title, pr_body)

        from datetime import datetime, timezone
        db.table("feedback").update({
            "status": "resolved",
            "claude_analysis": summary,
            "pr_url": pr_url,
            "resolved_at": datetime.now(timezone.utc).isoformat(),
        }).eq("id", feedback_id).execute()

        logger.info("[bug_fixer] Resolved feedback %s with PR %s", feedback_id, pr_url)

        # Notify all reporters of the same bug
        await notify_reporters(feedback_id, pr_url, db)

    except RuntimeError as exc:
        # Merge conflict detected — revert and surface the error
        logger.error("[bug_fixer] Merge conflict for %s: %s", feedback_id, exc)
        _revert_branch(branch_name)
        db.table("feedback").update({
            "status": "not_actionable",
            "claude_analysis": f"Fix applied but PR had conflicts: {exc}",
        }).eq("id", feedback_id).execute()

    except Exception as exc:
        logger.exception("[bug_fixer] PR creation failed for %s: %s", feedback_id, exc)
        _revert_branch(branch_name)
        db.table("feedback").update({
            "status": "not_actionable",
            "claude_analysis": f"Fix applied but PR creation failed: {exc}",
        }).eq("id", feedback_id).execute()
