"""
Railway background worker — polls Supabase for pending feedback every 5 min.
Run with: python -m workers.feedback_worker
"""
from __future__ import annotations

import asyncio
import logging
import os

logger = logging.getLogger(__name__)

POLL_INTERVAL_SECONDS = 28800  # 8 hours
BATCH_SIZE = 5


async def run_worker() -> None:
    """
    Poll the feedback table for status='pending', pick up to BATCH_SIZE rows,
    and process each one via claude_bug_fixer.process_feedback.
    """
    from api.db import get_db
    from workers.claude_bug_fixer import process_feedback

    logger.info("[feedback_worker] Starting. Polling every %ds.", POLL_INTERVAL_SECONDS)

    while True:
        try:
            db = get_db()
            result = (
                db.table("feedback")
                .select("*")
                .eq("status", "pending")
                .order("created_at", desc=False)
                .limit(BATCH_SIZE)
                .execute()
            )
            rows = result.data or []

            if rows:
                logger.info("[feedback_worker] Found %d pending items.", len(rows))

            for row in rows:
                feedback_id = row.get("id", "unknown")
                try:
                    # Mark as analyzing before processing so we don't double-pick
                    db.table("feedback").update({"status": "analyzing"}).eq("id", feedback_id).execute()
                    await process_feedback(row)
                except Exception as exc:
                    logger.exception(
                        "[feedback_worker] Error processing feedback %s: %s", feedback_id, exc
                    )
                    # Roll back to pending so it can be retried later
                    try:
                        db.table("feedback").update({"status": "pending"}).eq("id", feedback_id).execute()
                    except Exception:
                        pass

        except Exception as exc:
            logger.exception("[feedback_worker] Poll error: %s", exc)

        await asyncio.sleep(POLL_INTERVAL_SECONDS)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    asyncio.run(run_worker())
