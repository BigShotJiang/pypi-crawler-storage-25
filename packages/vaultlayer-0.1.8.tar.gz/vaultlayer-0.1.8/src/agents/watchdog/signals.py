from __future__ import annotations
"""
VaultLayer — Watchdog Agent: Termination Signal Detection
Polls AWS EC2 metadata endpoint every 5 seconds.
AWS gives a 2-minute Spot termination warning.
"""

import asyncio
import logging
import time
import urllib.request
import urllib.error
from typing import Optional
from datetime import datetime

import aiohttp

logger = logging.getLogger(__name__)

IMDS_TOKEN_URL = "http://169.254.169.254/latest/api/token"
IMDS_TERMINATION_URL = "http://169.254.169.254/latest/meta-data/spot/termination-time"
IMDS_TOKEN_TTL_SECONDS = 21600  # 6 hours

# AWS EC2 instance metadata endpoint for Spot termination
AWS_TERMINATION_ENDPOINT = "http://169.254.169.254/latest/meta-data/spot/termination-time"
AWS_INSTANCE_ID_ENDPOINT = "http://169.254.169.254/latest/meta-data/instance-id"
POLL_INTERVAL_SECONDS = 5


class TerminationDetector:
    """
    Polls AWS EC2 metadata endpoint (IMDSv2) to detect imminent Spot termination.
    Returns 200 with a timestamp when termination is ~2 minutes away.
    Returns 404 when the instance is healthy.

    Uses IMDSv2 token-based auth (PUT to acquire token, pass via header).
    Falls back to IMDSv1 (no token) when not on EC2.
    """

    IMDS_TOKEN_ENDPOINT = "http://169.254.169.254/latest/api/token"
    IMDS_TOKEN_TTL_SECONDS = 21600  # 6 hours

    def __init__(self):
        self._detected = False
        self._termination_time: Optional[str] = None
        self._instance_id: Optional[str] = None
        self._imds_token: Optional[str] = None
        self._imds_token_expiry: float = 0  # monotonic timestamp

    async def _get_imdsv2_token(self) -> Optional[str]:
        """Acquire or return cached IMDSv2 session token."""
        import time
        now = time.monotonic()
        # Return cached token if still valid (refresh 5 min before expiry)
        if self._imds_token and now < (self._imds_token_expiry - 300):
            return self._imds_token
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=2)) as session:
                async with session.put(
                    self.IMDS_TOKEN_ENDPOINT,
                    headers={"X-aws-ec2-metadata-token-ttl-seconds": str(self.IMDS_TOKEN_TTL_SECONDS)},
                ) as resp:
                    if resp.status == 200:
                        self._imds_token = await resp.text()
                        self._imds_token_expiry = now + self.IMDS_TOKEN_TTL_SECONDS
                        logger.debug("IMDSv2 token acquired")
                        return self._imds_token
        except Exception:
            logger.debug("IMDSv2 token request failed (not on EC2 or IMDSv2 disabled)")
        self._imds_token = None
        return None

    def _imds_headers(self) -> dict:
        """Return headers for IMDS requests, including token if available."""
        if self._imds_token:
            return {"X-aws-ec2-metadata-token": self._imds_token}
        return {}

    async def get_instance_id(self) -> Optional[str]:
        """Get current EC2 instance ID from metadata (IMDSv2)."""
        await self._get_imdsv2_token()
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=1)) as session:
                async with session.get(AWS_INSTANCE_ID_ENDPOINT, headers=self._imds_headers()) as resp:
                    if resp.status == 200:
                        self._instance_id = await resp.text()
                        return self._instance_id
        except Exception:
            pass
        return None

    async def check_termination(self) -> tuple[bool, Optional[str]]:
        """
        Check if AWS has issued a Spot termination signal via IMDSv2.
        Returns (is_terminating, termination_time_str).

        AWS signals ~2 minutes before actual termination.
        HTTP 200 = termination imminent.
        HTTP 404 = healthy, no signal.
        """
        await self._get_imdsv2_token()
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=2)) as session:
                async with session.get(AWS_TERMINATION_ENDPOINT, headers=self._imds_headers()) as resp:
                    if resp.status == 200:
                        termination_time = await resp.text()
                        if not self._detected:
                            logger.critical(
                                f"AWS SPOT TERMINATION SIGNAL DETECTED! "
                                f"Scheduled: {termination_time}"
                            )
                            self._detected = True
                            self._termination_time = termination_time
                        return True, termination_time
                    else:
                        # 404 = healthy
                        return False, None
        except aiohttp.ClientError:
            # Metadata endpoint unreachable — not on EC2 or network issue
            logger.debug("Metadata endpoint unreachable (not on EC2 or local dev)")
            return False, None
        except Exception as e:
            logger.debug(f"Termination check skipped (not on EC2): {type(e).__name__}")
            return False, None

    def _fetch_imdsv2_token(self) -> Optional[str]:
        """
        P1 (GAP-5): Fetch IMDSv2 token with 6h TTL using synchronous urllib.
        Returns None on non-EC2 environments or when IMDSv1-only.
        Caches the token and reuses it until 60s before expiry.
        """
        now = time.monotonic()
        if self._imds_token and now < self._imds_token_expiry - 60:
            return self._imds_token  # cached, still valid
        try:
            req = urllib.request.Request(
                IMDS_TOKEN_URL,
                method="PUT",
                headers={"X-aws-ec2-metadata-token-ttl-seconds": str(IMDS_TOKEN_TTL_SECONDS)},
            )
            with urllib.request.urlopen(req, timeout=2) as resp:
                token = resp.read().decode("utf-8").strip()
                self._imds_token = token
                self._imds_token_expiry = now + IMDS_TOKEN_TTL_SECONDS
                return token
        except Exception:
            return None  # not on EC2, or IMDSv1-only; fall through

    def check_termination_sync(self) -> bool:
        """
        P1 (GAP-5): Synchronous check for AWS spot termination via IMDSv2.
        Returns True if AWS spot termination notice is active (HTTP 200).
        Falls back gracefully to IMDSv1 (no token header) if token fetch fails.
        """
        token = self._fetch_imdsv2_token()
        headers = {}
        if token:
            headers["X-aws-ec2-metadata-token"] = token
        try:
            req = urllib.request.Request(IMDS_TERMINATION_URL, headers=headers)
            with urllib.request.urlopen(req, timeout=2) as resp:
                return resp.status == 200
        except urllib.error.HTTPError as e:
            return e.code == 200  # 404 = no termination
        except Exception:
            return False

    async def poll(self, on_signal: callable, interval: int = POLL_INTERVAL_SECONDS):
        """
        Continuously poll for termination signals.
        Calls on_signal(termination_time) when a signal is detected.
        Stops polling after signal is detected (AWS only signals once).
        """
        logger.info(f"Termination detector polling every {interval}s")
        while True:
            is_terminating, termination_time = await self.check_termination()
            if is_terminating and termination_time:
                await on_signal(termination_time)
                # Keep polling to maintain signal — don't break
                # AWS re-confirms signal on each request until termination
            await asyncio.sleep(interval)


class HeartbeatMonitor:
    """
    Monitors heartbeat signals from training processes.
    Triggers escalation if heartbeat is missed N times.
    """

    HEARTBEAT_INTERVAL = 30    # seconds between expected heartbeats
    MISS_THRESHOLD_WARN = 1    # warn after 1 missed heartbeat
    MISS_THRESHOLD_CHECKPOINT = 3  # force checkpoint after 3 missed

    def __init__(self, timeout_seconds: int = None):
        if timeout_seconds is not None:
            self.HEARTBEAT_INTERVAL = timeout_seconds
        self._last_heartbeat: dict[str, datetime] = {}
        self._last_heartbeats = self._last_heartbeat  # alias for backward compat
        self._miss_counts: dict[str, int] = {}

    def record_heartbeat(self, job_id: str):
        """Call this when a heartbeat is received from a training process."""
        self._last_heartbeats[job_id] = datetime.utcnow()
        self._miss_counts[job_id] = 0

    def check_all(self) -> list[dict]:
        """
        Check all registered jobs for missed heartbeats.
        Returns list of {job_id, miss_count, last_seen} for unhealthy jobs.
        """
        now = datetime.utcnow()
        unhealthy = []
        for job_id, last_hb in self._last_heartbeats.items():
            elapsed = (now - last_hb).total_seconds()
            if elapsed > self.HEARTBEAT_INTERVAL:
                missed = int(elapsed / self.HEARTBEAT_INTERVAL)
                self._miss_counts[job_id] = missed
                unhealthy.append({
                    "job_id": job_id,
                    "miss_count": missed,
                    "last_seen_seconds_ago": int(elapsed),
                })
        return unhealthy

    def register_job(self, job_id: str):
        """Start tracking a job's heartbeat."""
        self._last_heartbeats[job_id] = datetime.utcnow()
        self._miss_counts[job_id] = 0
        logger.info(f"Heartbeat monitoring started for job {job_id}")

    def is_healthy(self, job_id: str) -> bool:
        """Return True if a job has a recorded heartbeat and is not missed."""
        if job_id not in self._last_heartbeats:
            return False
        return self._miss_counts.get(job_id, 0) == 0

    def deregister_job(self, job_id: str):
        """Stop tracking a job (completed or failed)."""
        self._last_heartbeats.pop(job_id, None)
        self._miss_counts.pop(job_id, None)
