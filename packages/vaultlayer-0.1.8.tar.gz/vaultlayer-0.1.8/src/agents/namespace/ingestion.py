"""
VaultLayer -- Neutral Zone: Dataset Ingestion
Pillar 1: Zero-Egress S3-compatible storage.
Pillar 2: Builds the Global Namespace manifest.

Uploads a local dataset to Cloudflare R2 in parallel shards.
Writes a ShardManifest JSON that becomes the namespace index
every compute node reads on startup.
"""

import asyncio
import hashlib
import json
import logging
import tarfile
import io
import time
from pathlib import Path
from typing import List, Optional, Callable
from datetime import datetime

from agents.vault.r2 import R2Client
from shared.models_additions import ShardRecord, ShardManifest, ShardFormat

logger = logging.getLogger(__name__)

DEFAULT_SHARD_SIZE_BYTES = 512 * 1024 * 1024   # 512 MB per shard
MAX_PARALLEL_UPLOADS = 8


def detect_format(path: Path) -> ShardFormat:
    exts = {f.suffix.lower() for f in path.rglob("*") if f.is_file()}
    if ".parquet" in exts:      return ShardFormat.PARQUET
    if ".jsonl" in exts:        return ShardFormat.JSONL
    if ".h5" in exts:           return ShardFormat.HDF5
    return ShardFormat.TAR


def estimate_row_count(path: Path, fmt: ShardFormat) -> Optional[int]:
    if fmt == ShardFormat.JSONL:
        count = 0
        for f in path.rglob("*.jsonl"):
            try:
                with open(f) as fh:
                    count += sum(1 for _ in fh)
            except Exception:
                pass
        return count if count > 0 else None
    return None


def sha256_of_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class DatasetShardBuilder:
    """
    Splits a dataset directory into fixed-size .tar shards.
    Sequential ordering preserves epoch structure for the prefetcher.
    """

    def __init__(self, source_path: Path, shard_size_bytes: int = DEFAULT_SHARD_SIZE_BYTES):
        self.source = source_path
        self.shard_size = shard_size_bytes
        self._files: List[Path] = []

    def collect_files(self) -> List[Path]:
        files = sorted([f for f in self.source.rglob("*") if f.is_file()], key=str)
        self._files = files
        total = sum(f.stat().st_size for f in files)
        logger.info(f"Dataset scan: {len(files)} files, {total / 1e9:.2f} GB")
        return files

    def build_shards(self) -> List[bytes]:
        if not self._files:
            self.collect_files()
        shards = []
        current_buf = io.BytesIO()
        current_tar = tarfile.open(fileobj=current_buf, mode="w")
        current_size = 0
        for fpath in self._files:
            fsize = fpath.stat().st_size
            if current_size > 0 and current_size + fsize > self.shard_size:
                current_tar.close()
                shards.append(current_buf.getvalue())
                current_buf = io.BytesIO()
                current_tar = tarfile.open(fileobj=current_buf, mode="w")
                current_size = 0
            current_tar.add(fpath, arcname=str(fpath.relative_to(self.source)))
            current_size += fsize
        if current_size > 0:
            current_tar.close()
            shards.append(current_buf.getvalue())
        logger.info(f"Built {len(shards)} shards from {len(self._files)} files")
        return shards


class DatasetIngester:
    """
    Uploads a local dataset to Cloudflare R2.
    Builds a ShardManifest that acts as the Global Namespace index.
    All compute nodes read this manifest to find every shard
    via the same /mnt/vaultlayer path, regardless of provider.
    """

    def __init__(
        self,
        r2: R2Client,
        dataset_id: str,
        dataset_name: Optional[str] = None,
        shard_size_bytes: int = DEFAULT_SHARD_SIZE_BYTES,
        on_progress: Optional[Callable[[int, int], None]] = None,
    ):
        self.r2 = r2
        self.dataset_id = dataset_id
        self.dataset_name = dataset_name or dataset_id
        self.shard_size = shard_size_bytes
        self.on_progress = on_progress

    async def ingest(self, source_path: str) -> ShardManifest:
        source = Path(source_path)
        if not source.exists():
            raise FileNotFoundError(f"Dataset path not found: {source_path}")

        logger.info(f"Ingesting dataset: {source_path}")
        start = time.monotonic()

        fmt = detect_format(source)
        row_count = estimate_row_count(source, fmt)
        r2_prefix = f"datasets/{self.dataset_id}/"

        builder = DatasetShardBuilder(source, self.shard_size)
        shard_data_list = await asyncio.get_event_loop().run_in_executor(
            None, builder.build_shards
        )
        total_shards = len(shard_data_list)
        total_bytes = sum(len(s) for s in shard_data_list)

        logger.info(f"Uploading {total_shards} shards ({total_bytes / 1e9:.2f} GB)...")
        shard_records = await self._upload_parallel(shard_data_list, r2_prefix, fmt)

        manifest = ShardManifest(
            dataset_id=self.dataset_id,
            dataset_name=self.dataset_name,
            total_shards=total_shards,
            total_size_bytes=total_bytes,
            total_rows=row_count,
            r2_prefix=r2_prefix,
            shards=shard_records,
            format=fmt,
            sequential=True,
            shard_size_bytes_avg=total_bytes // total_shards if total_shards else 0,
            recommended_prefetch_count=3,
        )
        await self._write_manifest(manifest)

        elapsed = time.monotonic() - start
        logger.info(f"Ingestion complete in {elapsed:.1f}s")
        return manifest

    async def _upload_parallel(self, shard_data_list, r2_prefix, fmt):
        semaphore = asyncio.Semaphore(MAX_PARALLEL_UPLOADS)
        uploaded = 0

        async def upload_one(index: int, data: bytes) -> ShardRecord:
            nonlocal uploaded
            async with semaphore:
                r2_key = f"{r2_prefix}shard-{index:06d}.tar"
                sha = sha256_of_bytes(data)
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(None, lambda: self.r2._s3.put_object(
                    Bucket=self.r2.bucket, Key=r2_key, Body=data,
                    ContentType="application/octet-stream",
                    Metadata={"dataset_id": self.dataset_id, "shard_index": str(index),
                               "sha256": sha, "size_bytes": str(len(data))},
                ))
                uploaded += 1
                if self.on_progress:
                    self.on_progress(uploaded, len(shard_data_list))
                logger.debug(f"Shard {index:04d}/{len(shard_data_list):04d} uploaded")
                return ShardRecord(
                    r2_key=r2_key, local_name=f"shard-{index:06d}.tar",
                    size_bytes=len(data), sha256=sha, shard_index=index, format=fmt,
                )

        return await asyncio.gather(*[upload_one(i, d) for i, d in enumerate(shard_data_list)])

    async def _write_manifest(self, manifest: ShardManifest):
        key = f"datasets/{self.dataset_id}/manifest.json"
        data = manifest.model_dump_json(indent=2).encode()
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: self.r2._s3.put_object(
            Bucket=self.r2.bucket, Key=key, Body=data, ContentType="application/json",
        ))
        logger.info(f"Manifest written: r2://{self.r2.bucket}/{key}")

    @staticmethod
    async def load_manifest(r2: R2Client, dataset_id: str) -> Optional[ShardManifest]:
        key = f"datasets/{dataset_id}/manifest.json"
        try:
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None, lambda: r2._s3.get_object(Bucket=r2.bucket, Key=key)
            )
            return ShardManifest.model_validate_json(response["Body"].read())
        except Exception as e:
            logger.warning(f"Manifest not found for {dataset_id}: {e}")
            return None