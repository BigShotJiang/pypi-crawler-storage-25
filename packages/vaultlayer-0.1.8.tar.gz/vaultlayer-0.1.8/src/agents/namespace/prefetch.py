"""
VaultLayer -- Neutral Zone: Intelligent NVMe Prefetcher
Pillar 3: Pre-warms dataset shards onto local NVMe ahead of the dataloader.

How it works:
1. Reads current training step from Redis (set by CLI sidecar)
2. Maps step -> shard index (which shard the dataloader is currently reading)
3. Predicts next N shards needed
4. Downloads them from R2 to NVMe in background async tasks
5. LRU eviction when NVMe cache fills up
6. SHA256 integrity verification on every download

Result: dataloader always reads from local NVMe, never waiting on R2 latency.
Effective throughput matches a local disk.
"""

import asyncio
import hashlib
import logging
import time
from collections import OrderedDict
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict

from shared.models_additions import ShardManifest, ShardRecord, CacheEntry

import shutil

logger = logging.getLogger(__name__)

STEP_KEY = "vaultlayer:job:{job_id}:training_step"
PREFETCH_INTERVAL = 10          # seconds between prefetch checks
DEFAULT_CACHE_BYTES = 10 * 1024 * 1024 * 1024  # 10 GB

# Known NVMe / fast-local mount candidates in priority order.
# GPU instances typically mount instance-store NVMe at one of these paths.
# The broker's UserData script formats + mounts at /mnt/nvme.
_FAST_PATH_CANDIDATES = [
    "/mnt/nvme/vl-cache",        # AWS/GCP/Azure instance-store NVMe (set by UserData)
    "/mnt/local/vl-cache",       # some Lambda Labs configs
    "/mnt/resource/vl-cache",    # Azure temporary disk
    "/local_disk/vl-cache",      # CoreWeave local NVMe
    "/scratch/vl-cache",         # HPC / RunPod scratch
]
_FALLBACK_CACHE = "/tmp/vaultlayer-nvme-cache"
# Reserve this fraction of disk for the OS/other processes
_DISK_RESERVE_FRACTION = 0.15
# Hard cap: never allocate more than this per job
_MAX_CACHE_BYTES = 200 * 1024 * 1024 * 1024  # 200 GB


def discover_fast_data_path() -> str:
    """Return the fastest available local storage path for NVMe shard cache.

    Walks *_FAST_PATH_CANDIDATES* in priority order. A candidate is accepted
    when its parent directory exists (the directory itself is created if absent)
    and the underlying filesystem is not tmpfs (i.e. it's a real block device).
    Falls back to /tmp if nothing is found.
    """
    import os
    for candidate in _FAST_PATH_CANDIDATES:
        parent = str(Path(candidate).parent)
        if not os.path.isdir(parent):
            continue
        try:
            # Reject tmpfs mounts (type = 'tmpfs') — those live in RAM.
            stat = shutil.disk_usage(parent)
            # On tmpfs the total is typically <= physical RAM (a few GB).
            # Real NVMe drives on GPU instances are ≥ 400 GB.
            if stat.total < 50 * 1024 * 1024 * 1024:
                continue  # likely tmpfs or tiny root partition
            Path(candidate).mkdir(parents=True, exist_ok=True)
            return candidate
        except Exception:
            continue
    return _FALLBACK_CACHE


def available_cache_bytes(cache_dir: str) -> int:
    """Return how many bytes VaultLayer should use for the shard cache.

    Takes 85% of free space on the filesystem, capped at *_MAX_CACHE_BYTES*.
    """
    try:
        usage = shutil.disk_usage(cache_dir)
        usable = int(usage.free * (1 - _DISK_RESERVE_FRACTION))
        return min(usable, _MAX_CACHE_BYTES)
    except Exception:
        return DEFAULT_CACHE_BYTES


class LRUCache:
    """LRU cache tracking which shards are on NVMe."""

    def __init__(self, max_bytes: int):
        self.max_bytes = max_bytes
        self.used_bytes = 0
        self._entries: OrderedDict[str, CacheEntry] = OrderedDict()

    def get(self, shard_id: str) -> Optional[CacheEntry]:
        if shard_id in self._entries:
            self._entries.move_to_end(shard_id)
            e = self._entries[shard_id]
            e.last_accessed = datetime.utcnow()
            e.access_count += 1
            return e
        return None

    def put(self, entry: CacheEntry) -> List[CacheEntry]:
        """Add entry. Returns evicted entries."""
        evicted = []
        while self.used_bytes + entry.size_bytes > self.max_bytes and self._entries:
            k, v = self._entries.popitem(last=False)
            self.used_bytes -= v.size_bytes
            evicted.append(v)
        self._entries[entry.shard_id] = entry
        self._entries.move_to_end(entry.shard_id)
        self.used_bytes += entry.size_bytes
        return evicted

    def contains(self, shard_id: str) -> bool:
        return shard_id in self._entries

    def remove(self, shard_id: str) -> Optional[CacheEntry]:
        e = self._entries.pop(shard_id, None)
        if e:
            self.used_bytes -= e.size_bytes
        return e

    @property
    def free_bytes(self) -> int:
        return self.max_bytes - self.used_bytes

    def size(self) -> int:
        return len(self._entries)


class IntelligentPrefetcher:
    """
    Reads training progress from Redis and pre-fetches the next N shards
    from R2 to local NVMe before the dataloader needs them.

    For sequential workloads (most fine-tuning): trivially predict next shard.
    Wraps around at epoch boundary.
    """

    def __init__(self, job_id, manifest: ShardManifest, cache_dir, r2_client,
                 redis_client=None, cache_size_bytes=DEFAULT_CACHE_BYTES,
                 prefetch_count=None):
        self.job_id = job_id
        self.manifest = manifest
        self.cache_dir = Path(cache_dir)
        self.r2 = r2_client
        self.redis = redis_client
        self.prefetch_count = prefetch_count or manifest.recommended_prefetch_count
        self._cache = LRUCache(cache_size_bytes)
        self._downloading: set = set()
        self._hits = self._misses = self._prefetch_count = self._eviction_count = 0
        self._running = False
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    # -- Step tracking -------------------------------------------------------

    async def get_current_step(self) -> int:
        if not self.redis:
            return 0
        try:
            key = STEP_KEY.format(job_id=self.job_id)
            val = await self.redis.get(key)
            return int(val) if val else 0
        except Exception:
            return 0

    async def set_current_step(self, step: int):
        if not self.redis:
            return
        try:
            await self.redis.set(STEP_KEY.format(job_id=self.job_id), str(step), ex=3600)
        except Exception:
            pass

    def step_to_shard_index(self, step: int) -> int:
        if not self.manifest.total_rows or self.manifest.total_shards == 0:
            return 0
        rows_per_shard = self.manifest.total_rows / self.manifest.total_shards
        return min(int(step / rows_per_shard) % self.manifest.total_shards,
                   self.manifest.total_shards - 1)

    def predict_next_shards(self, current_idx: int) -> List[ShardRecord]:
        shards = self.manifest.shards
        if not shards:
            return []
        return [shards[(current_idx + i + 1) % len(shards)]
                for i in range(self.prefetch_count)]

    # -- Cache / download ----------------------------------------------------

    def local_path(self, shard: ShardRecord) -> Path:
        return self.cache_dir / f"shard-{shard.shard_index:06d}.tar"

    async def ensure_shard(self, shard: ShardRecord) -> str:
        entry = self._cache.get(shard.shard_id)
        if entry and Path(entry.local_path).exists():
            self._hits += 1
            return entry.local_path
        self._misses += 1
        local = await self._download_shard(shard)
        return str(local)

    async def _download_shard(self, shard: ShardRecord) -> Path:
        local = self.local_path(shard)
        if local.exists():
            size = local.stat().st_size
            evicted = self._cache.put(CacheEntry(
                shard_id=shard.shard_id, r2_key=shard.r2_key,
                local_path=str(local), size_bytes=size))
            await self._cleanup_evicted(evicted)
            return local
        start = time.monotonic()
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, lambda: self._download_sync(shard, local))
        elapsed = time.monotonic() - start
        size = local.stat().st_size
        logger.debug(f"Shard {shard.shard_index} downloaded: {size/1e6:.1f}MB in {elapsed:.1f}s")
        evicted = self._cache.put(CacheEntry(
            shard_id=shard.shard_id, r2_key=shard.r2_key,
            local_path=str(local), size_bytes=size, prefetched=True))
        await self._cleanup_evicted(evicted)
        return local

    def _download_sync(self, shard: ShardRecord, local: Path):
        resp = self.r2._s3.get_object(Bucket=self.r2.bucket, Key=shard.r2_key)
        data = resp["Body"].read()
        if shard.sha256:
            actual = hashlib.sha256(data).hexdigest()
            if actual != shard.sha256:
                raise ValueError(f"SHA256 mismatch for shard {shard.shard_index}")
        local.write_bytes(data)

    async def _cleanup_evicted(self, evicted):
        for e in evicted:
            try:
                Path(e.local_path).unlink(missing_ok=True)
                self._eviction_count += 1
            except Exception:
                pass

    # -- Prefetch loop -------------------------------------------------------

    async def prefetch_loop(self):
        self._running = True
        logger.info(f"[{self.job_id}] Prefetcher started "
                    f"(cache: {self._cache.max_bytes/1e9:.1f}GB, ahead: {self.prefetch_count} shards)")
        last_shard_idx = -1
        while self._running:
            try:
                step = await self.get_current_step()
                current_idx = self.step_to_shard_index(step)
                if current_idx != last_shard_idx:
                    last_shard_idx = current_idx
                    tasks = []
                    for shard in self.predict_next_shards(current_idx):
                        if not self._cache.contains(shard.shard_id) and shard.shard_id not in self._downloading:
                            self._downloading.add(shard.shard_id)
                            tasks.append(self._prefetch_one(shard))
                    if tasks:
                        await asyncio.gather(*tasks, return_exceptions=True)
            except Exception as e:
                logger.error(f"[{self.job_id}] Prefetch loop error: {e}")
            await asyncio.sleep(PREFETCH_INTERVAL)

    async def _prefetch_one(self, shard: ShardRecord):
        try:
            await self._download_shard(shard)
            self._prefetch_count += 1
        except Exception as e:
            logger.warning(f"Prefetch failed for shard {shard.shard_index}: {e}")
        finally:
            self._downloading.discard(shard.shard_id)

    def stop(self):
        self._running = False

    # -- Metrics -------------------------------------------------------------

    def get_stats(self) -> dict:
        total = self._hits + self._misses
        return {
            "job_id": self.job_id,
            "cache_entries": self._cache.size(),
            "cache_used_gb": round(self._cache.used_bytes / 1e9, 2),
            "cache_free_gb": round(self._cache.free_bytes / 1e9, 2),
            "hits": self._hits, "misses": self._misses,
            "hit_rate": round(self._hits / total, 3) if total > 0 else 0.0,
            "prefetched": self._prefetch_count,
            "evictions": self._eviction_count,
        }

    def log_stats(self):
        s = self.get_stats()
        hit_rate   = s.get('hit_rate', 0)
        cache_gb   = s.get('cache_used_gb', 0)
        prefetched = s.get('prefetched', 0)
        evictions  = s.get('evictions', 0)
        logger.info(f"[{self.job_id}] Prefetch: hit_rate={hit_rate:.1%} "
                    f"cache={cache_gb:.1f}GB prefetched={prefetched} evictions={evictions}")