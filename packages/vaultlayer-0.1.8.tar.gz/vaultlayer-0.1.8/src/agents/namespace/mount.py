"""
VaultLayer -- Neutral Zone: Global Namespace Mount
Pillar 2: rclone FUSE mount manager.

Mounts Cloudflare R2 at /mnt/vaultlayer on every compute node.
The training script sees the same path on AWS, CoreWeave, Lambda Labs --
it never knows it is reading from R2. Switching providers costs $0 in egress.
"""

import asyncio
import logging
import os
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from datetime import datetime

from shared.models_additions import MountRecord, MountStatus

logger = logging.getLogger(__name__)

MOUNT_PATH = "/mnt/vaultlayer"

RCLONE_CONFIG_TEMPLATE = """[r2]
type = s3
provider = Cloudflare
access_key_id = {access_key_id}
secret_access_key = {secret_access_key}
endpoint = {endpoint}
acl = private""".strip()

RCLONE_INSTALL = "command -v rclone || curl https://rclone.org/install.sh | sudo bash"
FUSE_INSTALL   = "dpkg -l fuse3 &>/dev/null || sudo apt-get install -y fuse3 2>/dev/null || sudo yum install -y fuse3 2>/dev/null || true"


@dataclass
class SSHConfig:
    host: str
    user: str = "ubuntu"
    key_path: str = "~/.ssh/vaultlayer-key"
    port: int = 22


class RcloneMountManager:
    """
    Manages rclone FUSE mounts on remote compute nodes via SSH.
    Same mount path on every provider -- that is the Global Namespace guarantee.
    """

    def __init__(self, r2_endpoint, r2_access_key, r2_secret_key, r2_bucket,
                 mount_path=MOUNT_PATH, cache_dir="/tmp/vaultlayer-cache",
                 cache_size_mb=10240):
        self.r2_endpoint   = r2_endpoint
        self.r2_access_key = r2_access_key
        self.r2_secret_key = r2_secret_key
        self.r2_bucket     = r2_bucket
        self.mount_path    = mount_path
        self.cache_dir     = cache_dir
        self.cache_size_mb = cache_size_mb

    def build_rclone_config(self) -> str:
        return RCLONE_CONFIG_TEMPLATE.format(
            access_key_id=self.r2_access_key,
            secret_access_key=self.r2_secret_key,
            endpoint=self.r2_endpoint,
        )

    def build_mount_command(self, r2_prefix: str = "") -> str:
        """
        Full rclone mount command with VFS caching enabled.
        --vfs-cache-mode full  = full file caching for random read perf
        --vfs-read-ahead 128M  = sequential read-ahead for dataloaders
        --daemon               = run in background, return immediately
        """
        remote = f"r2:{self.r2_bucket}"
        if r2_prefix:
            remote = f"{remote}/{r2_prefix.strip('/')}"
        return (
            f"rclone mount {shlex.quote(remote)} {shlex.quote(self.mount_path)} "
            f"--config /tmp/vaultlayer-rclone.conf "
            f"--vfs-cache-mode full "
            f"--vfs-cache-max-size {self.cache_size_mb}M "
            f"--cache-dir {shlex.quote(self.cache_dir)} "
            f"--vfs-read-ahead 128M "
            f"--buffer-size 256M "
            f"--transfers 16 "
            f"--checkers 8 "
            f"--log-level INFO "
            f"--log-file /tmp/vaultlayer-rclone.log "
            f"--daemon"
        )

    async def mount_on_node(self, ssh: SSHConfig, record: MountRecord,
                             r2_prefix: str = "") -> MountRecord:
        record.status = MountStatus.MOUNTING
        logger.info(f"[{record.job_id}] Mounting R2 on {ssh.host} at {self.mount_path}")
        try:
            await self._ssh(ssh, FUSE_INSTALL)
            await self._ssh(ssh, RCLONE_INSTALL)
            await self._ssh(ssh, f"echo {shlex.quote(self.build_rclone_config())} > /tmp/vaultlayer-rclone.conf")
            _mp = shlex.quote(str(self.mount_path))
            _cd = shlex.quote(str(self.cache_dir))
            await self._ssh(ssh, f"sudo mkdir -p {_mp} && sudo chmod 777 {_mp} && mkdir -p {_cd}")
            await self._ssh(ssh, self.build_mount_command(r2_prefix))
            await asyncio.sleep(5)
            result = await self._ssh(ssh, f"mountpoint -q {shlex.quote(str(self.mount_path))} && echo MOUNTED")
            if "MOUNTED" not in result:
                raise RuntimeError("Mount verification failed")
            pid_result = await self._ssh(ssh, "pgrep -f 'rclone mount' | head -1")
            record.status = MountStatus.MOUNTED
            record.pid = int(pid_result.strip()) if pid_result.strip().isdigit() else None
            record.mounted_at = datetime.utcnow()
            logger.info(f"[{record.job_id}] Mount established on {ssh.host} (PID: {record.pid})")
        except Exception as e:
            record.status = MountStatus.FAILED
            record.error = str(e)
            logger.error(f"[{record.job_id}] Mount failed: {e}")
        return record

    async def unmount_on_node(self, ssh: SSHConfig, record: MountRecord):
        logger.info(f"[{record.job_id}] Unmounting {self.mount_path}")
        try:
            await self._ssh(ssh, f"fusermount -u {shlex.quote(str(self.mount_path))} 2>/dev/null || sudo umount {shlex.quote(str(self.mount_path))} 2>/dev/null || true")
            record.status = MountStatus.UNMOUNTED
        except Exception as e:
            logger.warning(f"Unmount warning: {e}")

    async def verify_mount(self, ssh: SSHConfig, record: MountRecord) -> bool:
        try:
            result = await self._ssh(ssh, f"mountpoint -q {shlex.quote(str(self.mount_path))} && echo OK")
            return "OK" in result
        except Exception:
            return False

    async def _ssh(self, ssh: SSHConfig, command: str) -> str:
        key = os.path.expanduser(ssh.key_path)
        cmd = ["ssh", "-i", key, "-o", "StrictHostKeyChecking=no",
               "-o", "ConnectTimeout=30", "-p", str(ssh.port),
               f"{ssh.user}@{ssh.host}", command]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=120)
            return stdout.decode().strip()
        except asyncio.TimeoutError:
            raise RuntimeError(f"SSH timed out: {command[:60]}")


class LocalMountManager(RcloneMountManager):
    """Mount manager for the local machine (dev mode -- no SSH needed)."""

    async def mount_locally(self, r2_prefix: str = "") -> bool:
        logger.info(f"Mounting R2 locally at {self.mount_path}...")
        Path("/tmp/vaultlayer-rclone.conf").write_text(self.build_rclone_config())
        Path(self.mount_path).mkdir(parents=True, exist_ok=True)
        Path(self.cache_dir).mkdir(parents=True, exist_ok=True)
        proc = await asyncio.create_subprocess_shell(
            self.build_mount_command(r2_prefix),
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        await asyncio.sleep(5)
        verify = await asyncio.create_subprocess_shell(
            f"mountpoint -q {shlex.quote(str(self.mount_path))} && echo MOUNTED",
            stdout=asyncio.subprocess.PIPE)
        stdout, _ = await verify.communicate()
        success = "MOUNTED" in stdout.decode()
        if success:
            logger.info(f"Local mount established at {self.mount_path}")
        else:
            logger.error("Local mount failed. Check /tmp/vaultlayer-rclone.log")
        return success

    async def unmount_locally(self):
        proc = await asyncio.create_subprocess_shell(
            f"fusermount -u {shlex.quote(str(self.mount_path))} 2>/dev/null || sudo umount {shlex.quote(str(self.mount_path))} 2>/dev/null || true")
        await proc.wait()
        logger.info(f"Local unmount complete: {self.mount_path}")