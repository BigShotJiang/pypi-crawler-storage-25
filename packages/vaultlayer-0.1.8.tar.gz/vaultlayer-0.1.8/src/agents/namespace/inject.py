"""
VaultLayer — AST Injection Abort
Rejects payloads containing executable AST nodes before any processing.
This is a security guardrail for the Namespace Agent's event handler.
"""
from __future__ import annotations

import ast
import logging
from typing import Any

logger = logging.getLogger(__name__)

# AST node types that indicate executable / dangerous payloads
_DANGEROUS_NODE_TYPES = (
    ast.FunctionDef,
    ast.AsyncFunctionDef,
    ast.ClassDef,
    ast.Import,
    ast.ImportFrom,
    ast.Global,
    ast.Nonlocal,
    ast.Call,
    ast.Attribute,
)


def _contains_executable_ast(value: str) -> bool:
    """
    Return True if *value* parses as Python and contains executable AST nodes.
    Non-parseable strings are safe (they're plain data, not code).
    """
    try:
        tree = ast.parse(value, mode="exec")
    except SyntaxError:
        return False  # not valid Python — safe

    for node in ast.walk(tree):
        if isinstance(node, _DANGEROUS_NODE_TYPES):
            return True
        # Detect eval/exec/compile/open built-in calls by name
        if isinstance(node, ast.Name) and node.id in ("eval", "exec", "compile", "open", "__import__"):
            return True
    return False


def abort_if_injected(payload: dict[str, Any], source: str = "unknown") -> None:
    """
    Scan all string values in *payload* for executable AST nodes.
    Raises ``ValueError`` and logs a critical alert if any are found.
    Operates recursively on nested dicts and lists.

    :param payload: The event payload dict to validate.
    :param source: Label for log messages (e.g. job_id or event_type).
    """
    _scan(payload, source, path="payload")


def _scan(obj: Any, source: str, path: str) -> None:
    if isinstance(obj, str):
        if _contains_executable_ast(obj):
            logger.critical(
                f"[SECURITY] AST injection detected in {source} at {path!r}: "
                f"payload value looks like executable code. Aborting."
            )
            raise ValueError(
                f"AST injection abort: executable code detected in payload field {path!r}"
            )
    elif isinstance(obj, dict):
        for k, v in obj.items():
            _scan(v, source, path=f"{path}.{k}")
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            _scan(v, source, path=f"{path}[{i}]")
