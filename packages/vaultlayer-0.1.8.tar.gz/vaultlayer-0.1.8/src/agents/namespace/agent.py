"""
VaultLayer -- Namespace Agent
Neutral Zone orchestrator. Coordinates all three pillars:

Pillar 1: Zero-Egress Storage  -- delegates to R2Client + DatasetIngester
Pillar 2: Global Namespace     -- delegates to RcloneMountManager
Pillar 3: Intelligent Cache    -- delegates to IntelligentPrefetcher

Publishes to:  vaultlayer:namespace.status
Listens to:    vaultlayer:orchestration.command
               vaultlayer:broker.status  (NODE_PROVISIONED -> auto-remount)

Claude coverage: ~10% -- pure infrastructure coordination, no reasoning needed.
"""

import asyncio
import hashlib
import json
import logging
import os
from datetime import datetime
from typing import Optional, Dict

from shared.config import VaultLayerConfig
from shared.models import AgentEvent, EventType, Job
from shared.queue import AgentQueue
from agents.vault.r2 import R2Client
from agents.namespace.ingestion import DatasetIngester
from agents.namespace.inject import abort_if_injected
from agents.namespace.mount import RcloneMountManager, LocalMountManager, SSHConfig
from agents.namespace.prefetch import IntelligentPrefetcher, discover_fast_data_path, available_cache_bytes
from shared.models_additions import ShardManifest, MountRecord, MountStatus

logger = logging.getLogger(__name__)

NAMESPACE_CHANNEL = "vaultlayer:namespace.status"


class NamespaceAgent:
    """
    Agent 7 -- The Namespace Agent.

    This agent is what makes provider switching free.
    Without it: switching from AWS to CoreWeave costs egress fees on every GB.
    With it: dataset stays in R2, only compute moves. Switching costs $0.
    """

    AGENT_NAME = "namespace_agent"

    def __init__(self, config: VaultLayerConfig, queue: AgentQueue):
        self.config = config
        self.queue = queue
        self.r2 = R2Client(
            endpoint=config.cloudflare.r2_endpoint,
            access_key_id=config.cloudflare.r2_access_key_id,
            secret_access_key=config.cloudflare.r2_secret_access_key,
            bucket=config.cloudflare.r2_bucket,
        )
        self._mount_manager = RcloneMountManager(
            r2_endpoint=config.cloudflare.r2_endpoint,
            r2_access_key=config.cloudflare.r2_access_key_id,
            r2_secret_key=config.cloudflare.r2_secret_access_key,
            r2_bucket=config.cloudflare.r2_bucket,
        )
        self._manifests: Dict[str, ShardManifest] = {}
        self._mounts: Dict[str, MountRecord] = {}
        self._prefetchers: Dict[str, IntelligentPrefetcher] = {}
        self._prefetch_tasks: Dict[str, asyncio.Task] = {}

    # -- Public API ----------------------------------------------------------

    def register_job(self, job) -> None:
        """Called by CLI to associate a job; no-op for NamespaceAgent."""
        pass

    async def ingest_dataset(self, source_path: str, dataset_id: str,
                              dataset_name: Optional[str] = None,
                              on_progress=None) -> ShardManifest:
        """Upload dataset to R2 and build Global Namespace manifest."""
        ingester = DatasetIngester(
            r2=self.r2, dataset_id=dataset_id,
            dataset_name=dataset_name or dataset_id, on_progress=on_progress,
        )
        manifest = await ingester.ingest(source_path)
        self._manifests[dataset_id] = manifest
        await self._publish("dataset_ingested", {
            "dataset_id": dataset_id,
            "total_shards": manifest.total_shards,
            "total_size_bytes": manifest.total_size_bytes,
        })
        return manifest

    async def _get_or_load_manifest_safe(self, dataset_id: str):
        """Load manifest with error logging — returns None on failure instead of raising."""
        try:
            return await self._get_or_load_manifest(dataset_id)
        except Exception as e:
            logger.error(f"Failed to load manifest for dataset {dataset_id}: {e}")
            return None

    async def mount_for_job(self, job: Job, dataset_id: str,
                             ssh: Optional[SSHConfig] = None,
                             local: bool = False) -> MountRecord:
        """Mount Neutral Zone on compute node. Same path on every provider."""
        manifest = await self._get_or_load_manifest(dataset_id)
        if not manifest:
            raise ValueError(f"No manifest found for dataset: {dataset_id}")

        record = MountRecord(
            job_id=job.job_id, node_id=job.instance_id,
            provider=job.provider.value,
            r2_bucket=self.config.cloudflare.r2_bucket,
            r2_prefix=manifest.r2_prefix, cache_size_mb=10240,
        )

        if local:
            mgr = LocalMountManager(
                r2_endpoint=self.config.cloudflare.r2_endpoint,
                r2_access_key=self.config.cloudflare.r2_access_key_id,
                r2_secret_key=self.config.cloudflare.r2_secret_access_key,
                r2_bucket=self.config.cloudflare.r2_bucket,
            )
            success = await mgr.mount_locally(manifest.r2_prefix)
            record.status = MountStatus.MOUNTED if success else MountStatus.FAILED
        elif ssh:
            record = await self._mount_manager.mount_on_node(ssh, record, manifest.r2_prefix)
        else:
            record.status = MountStatus.MOUNTED

        version_hash = hashlib.sha256(
            f"{dataset_id}:{manifest.total_size_bytes}:{manifest.total_shards}".encode()
        ).hexdigest()[:12]
        dataset_version = f"v-{version_hash}"
        os.environ["VAULTLAYER_DATASET_VERSION"] = dataset_version

        self._mounts[job.job_id] = record
        await self._publish("dataset_mounted", {
            "job_id": job.job_id, "dataset_id": dataset_id,
            "mount_path": record.mount_path, "status": record.status.value,
            "dataset_version": dataset_version,
        })
        return record

    async def start_prefetcher(self, job: Job, dataset_id: str,
                                cache_dir: str = "",
                                cache_size_bytes: int = 0) -> IntelligentPrefetcher:
        """Start intelligent NVMe prefetcher as background task.

        *cache_dir* defaults to the fastest available local storage discovered
        at runtime (NVMe instance store → fast SSD mount → /tmp fallback).
        *cache_size_bytes* defaults to 85% of free space on that filesystem,
        capped at 200 GB per job.
        """
        manifest = await self._get_or_load_manifest(dataset_id)
        if not manifest:
            raise ValueError(f"No manifest for dataset: {dataset_id}")

        if not cache_dir:
            cache_dir = discover_fast_data_path()
        if not cache_size_bytes:
            cache_size_bytes = available_cache_bytes(cache_dir)

        logger.info(
            f"[{job.job_id}] NVMe cache: {cache_dir} "
            f"({cache_size_bytes / 1e9:.1f} GB allocated)"
        )

        prefetcher = IntelligentPrefetcher(
            job_id=job.job_id, manifest=manifest, cache_dir=cache_dir,
            r2_client=self.r2, redis_client=self.queue._client,
            cache_size_bytes=cache_size_bytes,
        )
        self._prefetchers[job.job_id] = prefetcher
        task = asyncio.create_task(
            prefetcher.prefetch_loop(), name=f"prefetch-{job.job_id[:8]}"
        )
        self._prefetch_tasks[job.job_id] = task
        logger.info(f"[{job.job_id}] Prefetcher started for dataset {dataset_id}")
        return prefetcher

    async def stop_prefetcher(self, job_id: str):
        """Stop prefetcher and log final cache stats."""
        if p := self._prefetchers.get(job_id):
            p.stop()
            p.log_stats()
            await self._publish("prefetch_complete", {"job_id": job_id, **p.get_stats()})
        if task := self._prefetch_tasks.pop(job_id, None):
            if not task.done():
                task.cancel()
        self._prefetchers.pop(job_id, None)

    async def unmount_for_job(self, job: Job, ssh: Optional[SSHConfig] = None):
        """Cleanly unmount Neutral Zone from compute node."""
        await self.stop_prefetcher(job.job_id)
        if record := self._mounts.get(job.job_id):
            if ssh:
                await self._mount_manager.unmount_on_node(ssh, record)
            else:
                mgr = LocalMountManager(
                    r2_endpoint=self.config.cloudflare.r2_endpoint,
                    r2_access_key=self.config.cloudflare.r2_access_key_id,
                    r2_secret_key=self.config.cloudflare.r2_secret_access_key,
                    r2_bucket=self.config.cloudflare.r2_bucket,
                )
                await mgr.unmount_locally()
        self._mounts.pop(job.job_id, None)

    # -- Command listener ----------------------------------------------------

    mount_dataset = mount_for_job  # compat alias

    async def listen_for_commands(self):
        async def handle(event: AgentEvent):
            try:
                abort_if_injected(event.payload, source=f"{event.event_type}:{event.job_id}")
            except ValueError as _exc:
                logger.error(f"[SECURITY] Dropping event: {_exc}")
                return

            target = event.payload.get("target_agent")
            cmd    = event.payload.get("command")
            if target == self.AGENT_NAME:
                if cmd == "ingest":
                    src = event.payload.get("source_path")
                    did = event.payload.get("dataset_id")
                    if src and did:
                        await self.ingest_dataset(src, did)
                elif cmd == "mount" and event.job_id:
                    js = await self.queue.get_job_state(event.job_id)
                    if js:
                        await self.mount_for_job(Job(**js), event.payload.get("dataset_id", ""), local=True)
                elif cmd == "unmount" and event.job_id:
                    js = await self.queue.get_job_state(event.job_id)
                    if js:
                        await self.unmount_for_job(Job(**js))

            # Migration started: tear down the old node's prefetcher + mount.
            # The new NODE_PROVISIONED event (fired after broker spins up the
            # replacement) will remount and restart the prefetcher from scratch.
            if event.event_type == EventType.MIGRATION_STARTED and event.job_id:
                logger.info(
                    f"[{event.job_id}] Migration started — stopping prefetcher on old node"
                )
                await self.stop_prefetcher(event.job_id)
                # Clear the mount record so NODE_PROVISIONED idempotency guard
                # doesn't skip the remount on the new node.
                self._mounts.pop(event.job_id, None)

            # Auto-remount + restart NVMe prefetcher when Broker provisions a
            # new node (initial provision OR migration target node).
            if event.event_type == EventType.NODE_PROVISIONED and event.job_id:
                did = event.payload.get("dataset_id")
                # Skip if already mounted for this job (idempotency guard).
                # MIGRATION_STARTED clears the record above so we always remount.
                if did and event.job_id not in self._mounts:
                    js = await self.queue.get_job_state(event.job_id)
                    if js:
                        job = Job(**js)
                        node_ip = event.payload.get("node_ip")
                        ssh = SSHConfig(host=node_ip) if node_ip else None
                        await self.mount_for_job(job, did, ssh=ssh)
                        # cache_dir: broker UserData mounts instance-store NVMe
                        # at /mnt/nvme; use that when the event provides it,
                        # otherwise fall back to auto-discovery on this host.
                        nvme_path = event.payload.get("nvme_cache_path", "")
                        await self.start_prefetcher(job, did, cache_dir=nvme_path)

        await self.queue.subscribe(["orchestration", "broker"], handle)

    # -- Helpers -------------------------------------------------------------

    async def _get_or_load_manifest(self, dataset_id: str) -> Optional[ShardManifest]:
        if dataset_id in self._manifests:
            return self._manifests[dataset_id]
        manifest = await DatasetIngester.load_manifest(self.r2, dataset_id)
        if manifest:
            self._manifests[dataset_id] = manifest
        return manifest

    async def _publish(self, event_name: str, payload: dict):
        try:
            await self.queue._client.publish(
                NAMESPACE_CHANNEL,
                json.dumps({"event": event_name, "agent": self.AGENT_NAME,
                            "timestamp": datetime.utcnow().isoformat(), **payload})
            )
        except Exception as e:
            logger.debug(f"Namespace publish failed: {e}")

    def get_mount_status(self, job_id: str) -> Optional[MountRecord]:
        return self._mounts.get(job_id)

    def get_prefetch_stats(self, job_id: str) -> Optional[dict]:
        p = self._prefetchers.get(job_id)
        return p.get_stats() if p else None

    # -- Lifecycle -----------------------------------------------------------

    async def start(self):
        logger.info("Namespace Agent starting -- Neutral Zone ready")
        if not self.r2.healthcheck():
            raise RuntimeError("R2 bucket inaccessible.")
        await self.listen_for_commands()

    async def stop(self):
        for job_id in list(self._prefetch_tasks):
            await self.stop_prefetcher(job_id)
        logger.info("Namespace Agent stopped")