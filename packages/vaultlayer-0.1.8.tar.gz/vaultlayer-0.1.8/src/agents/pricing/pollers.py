"""
VaultLayer -- Pricing Agent Provider Pollers
=============================================
Extracted from agent.py to keep the PricingAgent class focused on
agent lifecycle, arbitrage detection, and event publishing.

Contains:
- Static price tables for all 11 providers
- AWS Spot instance type/region mappings
- fetch_aws(), fetch_aws_spot(), fetch_lambda(), fetch_coreweave(), etc.
- find_best_spot_az(), find_best_spot_az_for_gpu()
- fetch_runpod_live() (GraphQL live prices)
- _map_lambda() helper
- _aws_on_demand_last_resort_prices()
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Optional

from shared.models import GPUPrice, GPUType, Provider

logger = logging.getLogger(__name__)


# ── Static price tables ──────────────────────────────────────────────────────

AWS_ON_DEMAND = {
    GPUType.H100_80GB_SXM: 98.32,
    GPUType.A100_80GB_SXM: 32.77,
    GPUType.A100_40GB: 16.37,
    GPUType.A10G: 3.06,
}
LAMBDA_PRICES = {
    GPUType.H100_80GB_SXM: 24.99,
    GPUType.A100_80GB_SXM: 13.76,
    GPUType.A100_40GB: 8.80,
    GPUType.A10G: 1.10,
}
COREWEAVE_PRICES = {
    GPUType.H100_80GB_SXM: 26.00,
    GPUType.A100_80GB_SXM: 14.50,
    GPUType.A100_40GB: 9.20,
    GPUType.A10G: 1.25,
}

# Dark pool provider prices (per GPU/hr, March 2026)
# These are spot/on-demand hybrid -- prices change frequently.
# VaultLayer polls live APIs where available; falls back to static here.

RUNPOD_PRICES = {
    GPUType.H100_80GB_SXM:  23.92,   # $2.99/hr/GPU (8x pod)
    GPUType.A100_80GB_SXM:  12.72,   # $1.59/hr/GPU
    GPUType.A100_40GB:       7.60,   # $0.95/hr/GPU
    GPUType.A40:             2.56,   # $0.32/hr/GPU
    GPUType.RTX4090:         3.52,   # $0.44/hr/GPU
}

VAST_PRICES = {
    # Vast.ai is auction-based -- these are median spot prices
    GPUType.H100_80GB_SXM:  19.92,   # ~$2.49/hr median spot
    GPUType.A100_80GB_SXM:  10.32,   # ~$1.29/hr median spot
    GPUType.A100_40GB:       5.60,   # ~$0.70/hr median spot
    GPUType.RTX4090:         2.88,   # ~$0.36/hr median spot
    GPUType.RTX3090:         1.52,   # ~$0.19/hr median spot
}

VOLTAGE_PARK_PRICES = {
    # Fixed pricing -- stable floor, Microsoft-backed
    GPUType.H100_80GB_SXM:  16.00,   # $2.00/hr, fixed
    GPUType.A100_80GB_SXM:  10.00,   # $1.25/hr, fixed (estimated)
}

CRUSOE_PRICES = {
    # Energy-cost-driven -- ~30% below AWS equivalent
    GPUType.H100_80GB_SXM:  23.20,   # $2.90/hr (vs AWS $3.90 OD)
    GPUType.A100_80GB_SXM:  13.60,   # $1.70/hr
    GPUType.A100_40GB:       7.20,   # $0.90/hr
}

NEBIUS_PRICES = {
    # EU-native, Frankfurt -- GDPR-compliant
    GPUType.H100_80GB_SXM:  25.20,   # $3.15/hr, EU pricing
    GPUType.A100_80GB_SXM:  14.40,   # $1.80/hr
}

HYPERSTACK_PRICES = {
    # UK/Canada -- good for EU+NA geographic spread
    GPUType.H100_80GB_SXM:  25.60,   # $3.20/hr
    GPUType.A100_80GB_SXM:  14.00,   # $1.75/hr
    GPUType.A100_40GB:       7.00,   # $0.875/hr
    GPUType.L40S:            9.60,   # $1.20/hr, inference-optimised
}

GCP_PRICES = {
    # Google Cloud Compute Engine accelerator-optimized (preemptible/spot, March 2026)
    GPUType.H100_80GB_SXM:  29.40,   # a3-highgpu-1g spot ~$3.675/hr/GPU
    GPUType.A100_80GB_SXM:  12.64,   # a2-ultragpu-1g spot ~$1.58/hr/GPU
    GPUType.A100_40GB:       9.36,   # a2-highgpu-1g spot ~$1.17/hr/GPU
    GPUType.A10G:            2.80,   # n1-standard-8 + t4 spot ~$0.35/hr/GPU
}

AZURE_PRICES = {
    # Azure Spot VM pricing (March 2026, East US)
    GPUType.H100_80GB_SXM:  32.00,   # Standard_ND96isr_H100_v5 spot ~$4.00/hr/GPU
    GPUType.A100_80GB_SXM:  24.00,   # Standard_ND96asr_v4 spot ~$3.00/hr/GPU
    GPUType.A100_40GB:      16.00,   # Standard_ND40rs_v2 spot ~$2.00/hr/GPU
}


# AWS Spot instance types to monitor across regions
AWS_SPOT_INSTANCE_TYPES = {
    GPUType.H100_80GB_SXM: "p5.48xlarge",
    GPUType.A100_80GB_SXM: "p4d.24xlarge",
    GPUType.A100_40GB: "p4d.24xlarge",
    GPUType.A10G: "g5.xlarge",
}
# Matches _FALLBACK_REGIONS in agents/broker/providers/aws.py. Any region the
# broker might try to provision in should also be price-polled here, otherwise
# the pricing agent can't give the broker a spot-price signal for ranking.
AWS_SPOT_REGIONS = ["us-east-1", "us-west-2", "us-east-2", "eu-west-1", "ap-southeast-1"]


# ---------------------------------------------------------------------------
# Provider fetch functions
# ---------------------------------------------------------------------------

async def fetch_aws(agent) -> list[GPUPrice]:
    """
    Fetch live AWS on-demand prices via the AWS Price List API.
    Falls back to hardcoded AWS_ON_DEMAND dict if credentials are unavailable
    or the API call fails.
    """
    try:
        from shared.sts import STSSessionManager
        sts = STSSessionManager(agent.config)
        # Pricing API is only available in us-east-1
        pricing_client = sts.get_pricing_client(job_id="pricing")
        results = []
        for gpu_type, instance_type in AWS_SPOT_INSTANCE_TYPES.items():
            try:
                resp = pricing_client.get_products(
                    ServiceCode="AmazonEC2",
                    Filters=[
                        {"Type": "TERM_MATCH", "Field": "instanceType",   "Value": instance_type},
                        {"Type": "TERM_MATCH", "Field": "operatingSystem", "Value": "Linux"},
                        {"Type": "TERM_MATCH", "Field": "tenancy",         "Value": "Shared"},
                        {"Type": "TERM_MATCH", "Field": "preInstalledSw",  "Value": "NA"},
                        {"Type": "TERM_MATCH", "Field": "regionCode",
                         "Value": agent.config.aws.region},
                    ],
                    MaxResults=1,
                )
                import json as _json
                for price_str in resp.get("PriceList", []):
                    price_doc = _json.loads(price_str)
                    terms = price_doc.get("terms", {}).get("OnDemand", {})
                    for term in terms.values():
                        for dim in term.get("priceDimensions", {}).values():
                            usd = float(dim["pricePerUnit"].get("USD", 0))
                            if usd > 0:
                                results.append(GPUPrice(
                                    gpu=gpu_type,
                                    provider=Provider.AWS,
                                    region=agent.config.aws.region,
                                    price_per_hour=round(usd, 4),
                                    availability="high",
                                    is_spot=False,
                                ))
            except Exception as _e:
                logger.debug(f"AWS Price List API error for {instance_type}: {_e}")
        if results:
            logger.info(f"[pricing] Fetched {len(results)} live AWS on-demand prices")
            return results
    except Exception as _outer:
        logger.warning(f"[pricing] AWS Price List API unavailable: {_outer}. Using static prices.")

    # Fallback: hardcoded on-demand prices
    return [
        GPUPrice(gpu=g, provider=Provider.AWS, region=agent.config.aws.region,
                 price_per_hour=p, availability="high", is_spot=False)
        for g, p in AWS_ON_DEMAND.items()
    ]


async def fetch_aws_spot(agent) -> list[GPUPrice]:
    """Fetch live AWS Spot prices via describe_spot_price_history across regions."""
    from shared.sts import STSSessionManager
    sts = STSSessionManager(agent.config)
    results = []

    for region in AWS_SPOT_REGIONS:
        try:
            ec2 = sts.get_ec2_client(job_id="pricing", region=region)
            instance_types = list(set(AWS_SPOT_INSTANCE_TYPES.values()))
            response = ec2.describe_spot_price_history(
                InstanceTypes=instance_types,
                ProductDescriptions=["Linux/UNIX"],
                StartTime=datetime.utcnow(),
                MaxResults=50,
            )
            # Group by instance type + AZ, keep latest price
            az_prices: dict[str, dict] = {}
            for record in response.get("SpotPriceHistory", []):
                key = f"{record['InstanceType']}:{record['AvailabilityZone']}"
                if key not in az_prices or record["Timestamp"] > az_prices[key]["Timestamp"]:
                    az_prices[key] = record

            for gpu_type, inst_type in AWS_SPOT_INSTANCE_TYPES.items():
                # Find cheapest AZ for this instance type in this region
                matching = [v for k, v in az_prices.items() if v["InstanceType"] == inst_type]
                if matching:
                    cheapest = min(matching, key=lambda x: float(x["SpotPrice"]))
                    spot_price = float(cheapest["SpotPrice"])
                    results.append(GPUPrice(
                        gpu=gpu_type,
                        provider=Provider.AWS,
                        region=cheapest["AvailabilityZone"],
                        price_per_hour=spot_price,
                        availability="high" if len(matching) > 1 else "medium",
                        is_spot=True,
                    ))
        except Exception as e:
            logger.warning(f"AWS Spot price fetch failed for {region}: {e}")

    if results:
        agent._best_spot_az = find_best_spot_az(results)
    return results


def find_best_spot_az(spot_prices: list[GPUPrice]) -> Optional[dict]:
    """Find the AZ with lowest spot price and highest capacity signal (most AZs available)."""
    if not spot_prices:
        return None
    # Prefer H100 pricing for selection
    h100_prices = [p for p in spot_prices if p.gpu == GPUType.H100_80GB_SXM]
    candidates = h100_prices or spot_prices
    best = min(candidates, key=lambda p: p.price_per_hour)
    return {
        "az": best.region,
        "gpu": best.gpu.value,
        "spot_price": best.price_per_hour,
        "availability": best.availability,
    }


def find_best_spot_az_for_gpu(gpu_type: GPUType, spot_prices: list[GPUPrice]) -> Optional[GPUPrice]:
    """FIX-8: Return the GPUPrice with lowest spot price for a specific GPU type from AWS.

    Filters to AWS spot entries for the requested GPU type and returns the cheapest AZ entry.
    Returns None if no matching entries found.
    """
    aws_spots = [
        p for p in spot_prices
        if p.provider == Provider.AWS and p.gpu == gpu_type and p.is_spot
    ]
    if not aws_spots:
        return None
    return min(aws_spots, key=lambda p: p.price_per_hour)


async def fetch_lambda(agent) -> list[GPUPrice]:
    try:
        import aiohttp
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as s:
            async with s.get(
                f"{agent.config.lambda_labs.base_url}/instance-types",
                headers={"Authorization": f"Basic {agent.config.lambda_labs.api_key}"},
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    result = []
                    for name, info in data.get("data", {}).items():
                        gpu = _map_lambda(name)
                        if not gpu:
                            continue
                        avail = "high" if info.get("regions_with_capacity_available") else "unavailable"
                        result.append(GPUPrice(
                            gpu=gpu, provider=Provider.LAMBDA_LABS, region="us-east-1",
                            price_per_hour=LAMBDA_PRICES.get(gpu, 0.0),
                            availability=avail, is_spot=False,
                        ))
                    if result:
                        return result
    except Exception as e:
        logger.warning(f"Lambda API error: {e}, using static prices")
    return [
        GPUPrice(gpu=g, provider=Provider.LAMBDA_LABS, region="us-east-1",
                 price_per_hour=p, availability="high", is_spot=False)
        for g, p in LAMBDA_PRICES.items()
    ]


async def fetch_coreweave(agent) -> list[GPUPrice]:
    return [
        GPUPrice(gpu=g, provider=Provider.COREWEAVE, region="us-east-1",
                 price_per_hour=p, availability="high", is_spot=False)
        for g, p in COREWEAVE_PRICES.items()
    ]


async def fetch_runpod(agent) -> list:
    """Fetch RunPod GPU prices. Uses static prices (live API requires auth)."""
    return [
        GPUPrice(gpu=g, provider=Provider.RUNPOD, region="us-east-1",
                 price_per_hour=pr, availability="high", is_spot=True)
        for g, pr in RUNPOD_PRICES.items()
    ]


async def fetch_vast(agent) -> list:
    """
    Fetch Vast.ai prices. Calls live search API if key configured,
    falls back to static median prices.
    """
    if agent.config.vast_ai:
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{agent.config.vast_ai.base_url}/bundles/",
                    headers={"Authorization": f"Bearer {agent.config.vast_ai.api_key}"},
                    params={"q": '{"rentable":true,"reliability2":{"gte":0.9},"order":[["reliability2","desc"],["dph_total","asc"]]}', "limit": 50},
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    if resp.status == 200:
                        offers = (await resp.json()).get("offers", [])
                        # Group by GPU and take median price
                        gpu_prices = {}
                        for o in offers:
                            gpu_name = o.get("gpu_name", "")
                            price = o.get("dph_total", 0)
                            if price > 0:
                                gpu_prices.setdefault(gpu_name, []).append(price)
                        results = []
                        for g, static_price in VAST_PRICES.items():
                            avail = "high"
                            results.append(GPUPrice(
                                gpu=g, provider=Provider.VAST_AI, region="global",
                                price_per_hour=static_price, availability=avail, is_spot=True
                            ))
                        return results
        except Exception as e:
            logger.warning(f"Vast.ai live price fetch failed, using static: {e}")
    # Static fallback
    return [
        GPUPrice(gpu=g, provider=Provider.VAST_AI, region="global",
                 price_per_hour=pr, availability="high", is_spot=True)
        for g, pr in VAST_PRICES.items()
    ]


async def fetch_voltage_park(agent) -> list:
    """Fetch Voltage Park prices (fixed pricing model)."""
    return [
        GPUPrice(gpu=g, provider=Provider.VOLTAGE_PARK, region="us-central-1",
                 price_per_hour=pr, availability="high", is_spot=False)
        for g, pr in VOLTAGE_PARK_PRICES.items()
    ]


async def fetch_crusoe(agent) -> list:
    """Fetch Crusoe Cloud prices (energy-cost pricing)."""
    return [
        GPUPrice(gpu=g, provider=Provider.CRUSOE, region="us-northcentral-1",
                 price_per_hour=pr, availability="high", is_spot=False)
        for g, pr in CRUSOE_PRICES.items()
    ]


async def fetch_nebius(agent) -> list:
    """Fetch Nebius Cloud prices (EU-native, GDPR-compliant)."""
    return [
        GPUPrice(gpu=g, provider=Provider.NEBIUS, region="eu-north1",
                 price_per_hour=pr, availability="high", is_spot=False)
        for g, pr in NEBIUS_PRICES.items()
    ]


async def fetch_hyperstack(agent) -> list:
    """Fetch Hyperstack prices (UK/Canada geographic diversity)."""
    return [
        GPUPrice(gpu=g, provider=Provider.HYPERSTACK, region="canada-1",
                 price_per_hour=pr, availability="high", is_spot=False)
        for g, pr in HYPERSTACK_PRICES.items()
    ]


async def fetch_gcp(agent) -> list:
    """Fetch GCP Compute Engine GPU prices. Uses static spot-equivalent prices."""
    region = agent.config.gcp.region if agent.config.gcp else "us-central1"
    return [
        GPUPrice(gpu=g, provider=Provider.GCP, region=region,
                 price_per_hour=pr, availability="high", is_spot=True)
        for g, pr in GCP_PRICES.items()
    ]


async def fetch_azure(agent) -> list:
    """Fetch Azure Spot VM GPU prices. Uses static spot-equivalent prices."""
    location = agent.config.azure.location if agent.config.azure else "eastus"
    return [
        GPUPrice(gpu=g, provider=Provider.AZURE, region=location,
                 price_per_hour=pr, availability="high", is_spot=True)
        for g, pr in AZURE_PRICES.items()
    ]


async def fetch_runpod_live(agent) -> list:
    """Fetch live RunPod prices via GraphQL API when API key is configured.
    Falls back to static RUNPOD_PRICES if key is absent or API fails."""
    if not agent.config.runpod:
        return await fetch_runpod(agent)
    try:
        import aiohttp
        query = """
        {
          gpuTypes {
            id
            displayName
            lowestPrice(input: { gpuCount: 1 }) {
              minimumBidPrice
              uninterruptablePrice
            }
          }
        }
        """
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://api.runpod.io/graphql",
                headers={"Authorization": f"Bearer {agent.config.runpod.api_key}"},
                json={"query": query},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                if resp.status != 200:
                    return await fetch_runpod(agent)
                data = (await resp.json()).get("data", {}).get("gpuTypes", [])

        # Map RunPod GPU IDs to our GPUType enum
        _RUNPOD_GPU_MAP = {
            "NVIDIA H100 80GB HBM3":  GPUType.H100_80GB_SXM,
            "NVIDIA A100-SXM4-80GB":  GPUType.A100_80GB_SXM,
            "NVIDIA A100-SXM4-40GB":  GPUType.A100_40GB,
            "NVIDIA A40":             GPUType.A40,
            "NVIDIA GeForce RTX 4090": GPUType.RTX4090,
        }
        results = []
        for entry in data:
            gpu_type = _RUNPOD_GPU_MAP.get(entry.get("displayName", ""))
            if not gpu_type:
                continue
            prices = entry.get("lowestPrice") or {}
            spot_price = prices.get("minimumBidPrice") or prices.get("uninterruptablePrice")
            if spot_price and float(spot_price) > 0:
                results.append(GPUPrice(
                    gpu=gpu_type, provider=Provider.RUNPOD, region="us-east-1",
                    price_per_hour=float(spot_price), availability="high", is_spot=True,
                ))
        return results if results else await fetch_runpod(agent)
    except Exception as e:
        logger.warning(f"RunPod live price fetch failed, using static: {e}")
        return await fetch_runpod(agent)


def _aws_on_demand_last_resort_prices(agent) -> list[GPUPrice]:
    """
    Return AWS On-Demand prices tagged availability='last_resort'.

    These entries are intentionally excluded from normal arbitrage selection
    (OrchestrationAgent._select_provider skips 'last_resort' availability).
    They exist in the price cache solely so BrokerAgent.provision_aws_on_demand()
    can read the current OD rate for gainshare-suppressed billing records.
    Controlled by VL_AWS_OD_FALLBACK_ENABLED (default: true).
    """
    import os as _os
    if _os.getenv("VL_AWS_OD_FALLBACK_ENABLED", "true").lower() not in ("true", "1", "yes"):
        return []
    region = getattr(getattr(agent.config, "aws", None), "region", "us-east-1") or "us-east-1"
    return [
        GPUPrice(
            gpu=g,
            provider=Provider.AWS,
            region=region,
            price_per_hour=p,
            availability="last_resort",   # never selected for arbitrage
            is_spot=False,
        )
        for g, p in AWS_ON_DEMAND.items()
    ]


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _map_lambda(name: str) -> Optional[GPUType]:
    n = name.lower()
    if "h100" in n:
        return GPUType.H100_80GB_SXM
    if "a100" in n and "80" in n:
        return GPUType.A100_80GB_SXM
    if "a100" in n:
        return GPUType.A100_40GB
    if "a10" in n:
        return GPUType.A10G
    return None
