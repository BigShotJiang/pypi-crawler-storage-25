"""
VaultLayer - Pricing Agent
Polls AWS, Lambda Labs, CoreWeave every 60s.
Normalises to unified schema. Alerts Orchestration on arbitrage.
Claude coverage: ~30% (anomaly narration only)

Module structure
----------------
- pollers.py : Provider-specific price fetching and static price tables
- agent.py   : This file -- agent lifecycle, arbitrage detection, event publishing
"""
import asyncio
import logging
import os
import pathlib
import sys
import time
import aiohttp
import boto3
from datetime import datetime
from typing import Optional
from shared.config import VaultLayerConfig
from shared.models import AgentEvent, EventType, GPUPrice, GPUType, Provider
from shared.queue import AgentQueue, make_event

# Re-export price tables and pollers for backward compatibility
from agents.pricing.pollers import (  # noqa: F401
    AWS_ON_DEMAND, LAMBDA_PRICES, COREWEAVE_PRICES,
    RUNPOD_PRICES, VAST_PRICES, VOLTAGE_PARK_PRICES,
    CRUSOE_PRICES, NEBIUS_PRICES, HYPERSTACK_PRICES,
    GCP_PRICES, AZURE_PRICES,
    AWS_SPOT_INSTANCE_TYPES, AWS_SPOT_REGIONS,
    fetch_aws as _pollers_fetch_aws,
    fetch_aws_spot as _pollers_fetch_aws_spot,
    fetch_lambda as _pollers_fetch_lambda,
    fetch_coreweave as _pollers_fetch_coreweave,
    fetch_runpod as _pollers_fetch_runpod,
    fetch_vast as _pollers_fetch_vast,
    fetch_voltage_park as _pollers_fetch_voltage_park,
    fetch_crusoe as _pollers_fetch_crusoe,
    fetch_nebius as _pollers_fetch_nebius,
    fetch_hyperstack as _pollers_fetch_hyperstack,
    fetch_gcp as _pollers_fetch_gcp,
    fetch_azure as _pollers_fetch_azure,
    fetch_runpod_live as _pollers_fetch_runpod_live,
    find_best_spot_az as _pollers_find_best_spot_az,
    find_best_spot_az_for_gpu as _pollers_find_best_spot_az_for_gpu,
    _map_lambda as _pollers_map_lambda,
    _aws_on_demand_last_resort_prices as _pollers_aws_od_last_resort,
)

logger = logging.getLogger(__name__)

# Price guard -- auto-imported; no crash if unavailable
_DATA_PATH_OVERRIDE = os.environ.get("VAULTLAYER_DATA_PATH", "")
if _DATA_PATH_OVERRIDE:
    sys.path.insert(0, str(pathlib.Path(_DATA_PATH_OVERRIDE).parent))
try:
    from shared.price_guard import write_live_prices_to_data_file, PriceChangeDetector
    if _DATA_PATH_OVERRIDE:
        logger.info(f"Using custom data path: {_DATA_PATH_OVERRIDE}")
    _PRICE_GUARD = True
except ImportError:
    _PRICE_GUARD = False
    logger.debug("price_guard not available")
POLL_INTERVAL = 60
ARBITRAGE_THRESHOLD = 10.0
MARGIN = 1.15

# AWS data egress rate (USD/GB) charged when streaming a dataset out of S3 to ANOTHER PROVIDER.
AWS_EGRESS_RATE_PER_GB = 0.09

# S3 -> EC2 in the SAME AWS REGION: $0.00 egress
AWS_SAME_REGION_S3_EGRESS_PER_GB = 0.0

# Cross-AZ charge: $0.01/GB when S3 bucket and EC2 instance are in different AZs
AWS_CROSS_AZ_RATE_PER_GB = 0.01

# GCP egress
GCP_EGRESS_RATE_PER_GB = 0.10

# Azure egress
AZURE_EGRESS_RATE_PER_GB = 0.085
AZURE_FREE_EGRESS_GB = 100.0

# Cross-hop thresholds
AWS_CROSS_HOP_SMALL_DATASET_GB = 100.0


class PricingAgent:
    AGENT_NAME = "pricing_agent"

    def __init__(self, config: VaultLayerConfig, queue: AgentQueue):
        self.config = config
        self.queue = queue
        self._last: dict[str, float] = {}
        self._best_spot_az: Optional[dict] = None
        # Job registry: job_id -> Job.  Populated by register_job() so arbitrage
        # calculations can apply per-job egress costs.
        self._active_jobs: dict = {}

    def register_job(self, job) -> None:
        """Register a job so find_opportunities() can factor in its dataset egress cost."""
        self._active_jobs[job.job_id] = job

    def vl_price(self, raw: float) -> float:
        return round(raw * MARGIN, 2)

    # -- Provider fetchers (delegated to pollers module) --

    async def fetch_aws(self) -> list[GPUPrice]:
        return await _pollers_fetch_aws(self)

    async def fetch_aws_spot(self) -> list[GPUPrice]:
        return await _pollers_fetch_aws_spot(self)

    def find_best_spot_az(self, spot_prices: list[GPUPrice]) -> Optional[dict]:
        return _pollers_find_best_spot_az(spot_prices)

    def find_best_spot_az_for_gpu(self, gpu_type: GPUType, spot_prices: list[GPUPrice]) -> Optional[GPUPrice]:
        return _pollers_find_best_spot_az_for_gpu(gpu_type, spot_prices)

    async def fetch_lambda(self) -> list[GPUPrice]:
        return await _pollers_fetch_lambda(self)

    async def fetch_coreweave(self) -> list[GPUPrice]:
        return await _pollers_fetch_coreweave(self)

    async def fetch_runpod(self) -> list:
        return await _pollers_fetch_runpod(self)

    async def fetch_vast(self) -> list:
        return await _pollers_fetch_vast(self)

    async def fetch_voltage_park(self) -> list:
        return await _pollers_fetch_voltage_park(self)

    async def fetch_crusoe(self) -> list:
        return await _pollers_fetch_crusoe(self)

    async def fetch_nebius(self) -> list:
        return await _pollers_fetch_nebius(self)

    async def fetch_hyperstack(self) -> list:
        return await _pollers_fetch_hyperstack(self)

    async def fetch_gcp(self) -> list:
        return await _pollers_fetch_gcp(self)

    async def fetch_azure(self) -> list:
        return await _pollers_fetch_azure(self)

    async def fetch_runpod_live(self) -> list:
        return await _pollers_fetch_runpod_live(self)

    # -- GAP-24: Billing granularity / sunk cost model -------------------------

    BILLING_GRANULARITY_SECONDS: dict = {
        Provider.AWS: 60,
        Provider.LAMBDA_LABS: 3600,
        Provider.RUNPOD: 60,
        Provider.COREWEAVE: 60,
        Provider.VAST_AI: 60,
        Provider.VOLTAGE_PARK: 3600,
        Provider.CRUSOE: 3600,
        Provider.NEBIUS: 3600,
        Provider.HYPERSTACK: 3600,
        Provider.GCP: 60,       # GCP bills per-second (rounded to 1 min minimum)
        Provider.AZURE: 60,     # Azure spot bills per-minute
    }

    def compute_sunk_cost_usd(self, job, from_provider: Provider) -> float:
        """Calculate how much billing is already committed in the current billing period."""
        granularity = self.BILLING_GRANULARITY_SECONDS.get(from_provider, 60)
        elapsed_in_job = 0.0
        if hasattr(job, "started_at") and job.started_at:
            import time as _t
            elapsed_in_job = (_t.time() - job.started_at.timestamp())
        time_in_current_period = elapsed_in_job % granularity
        wasted_seconds = granularity - time_in_current_period
        hourly_rate = getattr(job, "current_hourly_rate", 0.0) or 0.0
        return (wasted_seconds / 3600.0) * hourly_rate

    # -- GAP-29: Cross-region latency penalty ----------------------------------

    CROSS_REGION_PENALTY_USD_PER_HR: dict = {
        ("us-east-1", "eu-west-1"): 0.50,
        ("us-east-1", "ap-southeast-1"): 1.00,
        ("us-west-2", "eu-west-1"): 0.75,
        ("us-east-1", "us-west-2"): 0.10,
    }

    def _cross_region_penalty(self, dataset_region: str, target_region: str) -> float:
        key = (dataset_region, target_region)
        return self.CROSS_REGION_PENALTY_USD_PER_HR.get(key, 0.0)

    # ── Source-cloud egress helpers ───────────────────────────────────────────

    @staticmethod
    def _source_cloud(dataset_location: str, dataset_cloud: str = "") -> str:
        """Resolve the source cloud from dataset_location and optional override.

        Returns one of: "aws", "gcp", "azure", "free"
        "free" means the dataset has no egress cost regardless of target provider
        (Cloudflare R2 has zero egress; local/NVMe has zero egress).
        """
        if dataset_cloud:
            return dataset_cloud.lower()
        loc = dataset_location.lower()
        if loc in ("s3",):
            return "aws"
        if loc in ("gcs", "gcp"):
            return "gcp"
        if loc in ("azure_blob", "azure"):
            return "azure"
        # r2, local, nvme, "" → no egress charge
        return "free"

    @staticmethod
    def _egress_cost_for_target(
        source: str,
        target_provider: "Provider",
        dataset_size_gb: float,
        dataset_aws_region: str = "",
        vpc_gateway_endpoint: bool = False,
        enterprise_compliance: bool = False,
    ) -> "tuple[float, str]":
        """Return (egress_cost_total_usd, egress_type) for moving data from source to target.

        ┌──────────┬─────────────────────────────────────────────────────────┐
        │ Source   │ Target     │ Cost                    │ egress_type        │
        ├──────────┼────────────┼─────────────────────────┼────────────────────┤
        │ aws (S3) │ AWS Spot   │ $0.00 (w/ GW endpoint)  │ free               │
        │          │ (same rgn) │ $0.01/GB (w/o endpoint) │ cross_az           │
        │          │ Non-AWS    │ $0.09/GB                │ aws_internet_egress│
        ├──────────┼────────────┼─────────────────────────┼────────────────────┤
        │ gcp(GCS) │ GCP Prem.  │ $0.00 (internal)        │ free               │
        │          │ Non-GCP    │ $0.10/GB                │ gcp_internet_egress│
        ├──────────┼────────────┼─────────────────────────┼────────────────────┤
        │ azure    │ Azure Spot │ $0.00 (internal)        │ free               │
        │          │ Non-Azure  │ $0.085/GB (>100GB free) │ azure_egress       │
        ├──────────┼────────────┼─────────────────────────┼────────────────────┤
        │ free     │ any        │ $0.00 (R2/local)        │ free               │
        └──────────┴────────────┴─────────────────────────┴────────────────────┘
        """
        if dataset_size_gb <= 0 or source == "free":
            return 0.0, "free"

        is_aws_target = target_provider == Provider.AWS
        is_gcp_target = target_provider == Provider.GCP
        is_azure_target = target_provider == Provider.AZURE

        if source == "aws":
            if is_aws_target:
                # Same-cloud: only Cross-AZ charge (if no Gateway Endpoint)
                if vpc_gateway_endpoint or not dataset_aws_region:
                    return 0.0, "free"
                return dataset_size_gb * AWS_CROSS_AZ_RATE_PER_GB, "cross_az"
            # Cross-cloud: full internet egress
            return dataset_size_gb * AWS_EGRESS_RATE_PER_GB, "aws_internet_egress"

        if source == "gcp":
            if is_gcp_target:
                return 0.0, "free"  # GCS → GCP Preemptible: internal transfer, free
            return dataset_size_gb * GCP_EGRESS_RATE_PER_GB, "gcp_internet_egress"

        if source == "azure":
            if is_azure_target:
                return 0.0, "free"  # Azure Blob → Azure Spot: internal transfer, free
            # First 100 GB/month free tier; remainder at $0.085/GB
            billable_gb = max(0.0, dataset_size_gb - AZURE_FREE_EGRESS_GB)
            return billable_gb * AZURE_EGRESS_RATE_PER_GB, "azure_egress"

        return 0.0, "free"

    def recommend_strategy(
        self,
        dataset_location: str,
        dataset_size_gb: float,
        training_duration_hours: float,
        enterprise_compliance: bool = False,
        dataset_cloud: str = "",
    ) -> dict:
        """Return the recommended arbitrage playbook for a given dataset source.

        Three playbooks:
        ──────────────────────────────────────────────────────────────────────
        AWS Playbook (Highest Risk for cross-hop)
          Data in S3: keep job on AWS Spot = zero egress.
          Cross-hop to cheaper provider ONLY when:
            (a) Dataset is tiny (< 100 GB) → egress ≤ $9 → almost always worth it, OR
            (b) Total compute savings > total egress cost over the training run.

        GCP Playbook (Moderate Risk)
          Data in GCS: prefer GCP Preemptible VMs first (zero egress).
          GCP has an incredibly fast global network — Preemptible discounts are
          30-70% off On-Demand. Cross-hop to non-GCP only if savings > $0.10/GB egress.

        Azure Playbook (Highest Friction)
          Data in Azure Blob: strongly prefer Azure Spot VMs (zero egress, compliance-safe).
          Azure has massive Tier 1/Tier 2 enterprise contracts with HIPAA, FedRAMP,
          SOC 2 Type II requirements. Cross-cloud migration almost always breaks these.
          enterprise_compliance=True forces Azure-only routing regardless of pricing.
        ──────────────────────────────────────────────────────────────────────

        Returns a dict with:
          playbook: "aws" | "gcp" | "azure" | "free"
          preferred_providers: list of Provider values to try first (in order)
          cross_hop_ok: bool — whether cross-cloud migration is recommended
          cross_hop_threshold_usd: minimum total savings required to justify cross-hop
          egress_rate_per_gb: applicable egress rate for cross-cloud moves
          rationale: human-readable explanation
        """
        source = self._source_cloud(dataset_location, dataset_cloud)
        egress_total_cross = 0.0
        egress_rate = 0.0

        if source == "aws":
            egress_rate = AWS_EGRESS_RATE_PER_GB
            egress_total_cross = dataset_size_gb * egress_rate
            is_tiny = dataset_size_gb <= AWS_CROSS_HOP_SMALL_DATASET_GB
            cross_hop_ok = is_tiny  # always ok for small; large = check savings vs egress
            rationale = (
                f"AWS Playbook: data in S3 ({dataset_size_gb:.0f} GB). "
                f"Prefer AWS Spot (zero egress). "
                + (
                    f"Dataset is tiny ({dataset_size_gb:.0f} GB ≤ {AWS_CROSS_HOP_SMALL_DATASET_GB:.0f} GB) "
                    f"→ cross-hop egress tax ≤ ${egress_total_cross:.0f} — acceptable."
                    if is_tiny else
                    f"Dataset is large — cross-hop costs ${egress_total_cross:,.0f} in S3 egress. "
                    f"Only cross-hop if total compute savings over {training_duration_hours:.0f}h exceed this."
                )
            )
            return {
                "playbook": "aws",
                "preferred_providers": [Provider.AWS],
                "cross_hop_ok": cross_hop_ok,
                "cross_hop_threshold_usd": egress_total_cross,
                "egress_rate_per_gb": egress_rate,
                "egress_total_usd": round(egress_total_cross, 2),
                "rationale": rationale,
            }

        if source == "gcp":
            egress_rate = GCP_EGRESS_RATE_PER_GB
            egress_total_cross = dataset_size_gb * egress_rate
            rationale = (
                f"GCP Playbook: data in GCS ({dataset_size_gb:.0f} GB). "
                f"Prefer GCP Preemptible VMs (30-70% off On-Demand, zero egress). "
                f"Cross-hop to non-GCP costs ${egress_total_cross:,.0f} at ${egress_rate}/GB. "
                f"Only recommend if total compute savings exceed ${egress_total_cross:,.0f}."
            )
            if enterprise_compliance:
                rationale += " COMPLIANCE: enterprise_compliance=True — GCP-only routing enforced."
            return {
                "playbook": "gcp",
                "preferred_providers": [Provider.GCP],
                "cross_hop_ok": not enterprise_compliance and dataset_size_gb <= AWS_CROSS_HOP_SMALL_DATASET_GB,
                "cross_hop_threshold_usd": egress_total_cross,
                "egress_rate_per_gb": egress_rate,
                "egress_total_usd": round(egress_total_cross, 2),
                "rationale": rationale,
            }

        if source == "azure":
            billable_gb = max(0.0, dataset_size_gb - AZURE_FREE_EGRESS_GB)
            egress_rate = AZURE_EGRESS_RATE_PER_GB
            egress_total_cross = billable_gb * egress_rate
            compliance_block = enterprise_compliance
            rationale = (
                f"Azure Playbook: data in Azure Blob ({dataset_size_gb:.0f} GB). "
                f"First {AZURE_FREE_EGRESS_GB:.0f} GB free; billable egress: "
                f"{billable_gb:.0f} GB × ${egress_rate}/GB = ${egress_total_cross:,.0f}. "
                f"Prefer Azure Spot VMs (zero egress, compliance-safe). "
            )
            if compliance_block:
                rationale += (
                    "COMPLIANCE BLOCK: enterprise_compliance=True — Azure-only routing enforced. "
                    "Cross-cloud migration suppressed (HIPAA/FedRAMP/SOC2 data residency)."
                )
            else:
                rationale += (
                    "No compliance flag — cross-hop permitted if savings > "
                    f"${egress_total_cross:,.0f} egress cost."
                )
            return {
                "playbook": "azure",
                "preferred_providers": [Provider.AZURE],
                "cross_hop_ok": not compliance_block and dataset_size_gb <= AWS_CROSS_HOP_SMALL_DATASET_GB,
                "cross_hop_threshold_usd": egress_total_cross,
                "egress_rate_per_gb": egress_rate,
                "egress_total_usd": round(egress_total_cross, 2),
                "rationale": rationale,
            }

        # "free" source (R2, local, NVMe) — no egress constraints
        return {
            "playbook": "free",
            "preferred_providers": [],  # no preference — pick cheapest globally
            "cross_hop_ok": True,
            "cross_hop_threshold_usd": 0.0,
            "egress_rate_per_gb": 0.0,
            "egress_total_usd": 0.0,
            "rationale": (
                f"Free Playbook: data in {dataset_location} — zero egress to any provider. "
                "Select purely on compute cost. No cloud preference."
            ),
        }

    def find_opportunities(
        self,
        prices: list[GPUPrice],
        dataset_size_gb: float = 0.0,
        dataset_location: str = "s3",
        training_duration_hours: float = 1.0,
        dataset_aws_region: str = "",
        vpc_gateway_endpoint: bool = False,
        dataset_cloud: str = "",
        enterprise_compliance: bool = False,
    ) -> list[dict]:
        """Return arbitrage opportunities after applying the correct source-cloud playbook.

        Source-cloud playbooks — egress cost model:
        ┌────────────┬─────────────────────────────────────────────────────────────┐
        │ AWS / S3   │ Same-region AWS Spot: $0 (VPC endpoint) or $0.01/GB Cross-AZ│
        │            │ Cross-cloud (Lambda/CW/RunPod): $0.09/GB internet egress     │
        │            │ Cross-hop OK: dataset < 100GB OR savings > egress total      │
        ├────────────┼─────────────────────────────────────────────────────────────┤
        │ GCP / GCS  │ GCP Preemptible: $0 (internal)                              │
        │            │ Cross-cloud: $0.10/GB internet egress                        │
        │            │ Prefer GCP Preemptible first; only cross-hop if profitable   │
        ├────────────┼─────────────────────────────────────────────────────────────┤
        │ Azure Blob │ Azure Spot: $0 (internal, compliance-safe)                   │
        │            │ Cross-cloud: $0.085/GB (after 100GB free)                    │
        │            │ Prefer Azure Spot; enterprise_compliance=True → Azure-only   │
        ├────────────┼─────────────────────────────────────────────────────────────┤
        │ R2 / local │ No egress cost — pick cheapest provider globally             │
        └────────────┴─────────────────────────────────────────────────────────────┘

        Args:
            prices: live GPU prices from all providers
            dataset_size_gb: training dataset size in GB (0 = no penalty)
            dataset_location: storage system — "s3"|"gcs"|"azure_blob"|"r2"|"local"
            training_duration_hours: total training time (amortises one-time egress cost)
            dataset_aws_region: S3 bucket region (enables Cross-AZ vs internet-egress split)
            vpc_gateway_endpoint: True = VPC S3 Gateway Endpoint active (Cross-AZ → $0)
            dataset_cloud: explicit override — "aws"|"gcp"|"azure"|""
            enterprise_compliance: True = suppress non-Azure suggestions when source=azure,
                and suppress non-GCP suggestions when source=gcp
        """
        source = self._source_cloud(dataset_location, dataset_cloud)
        aws_od = {p.gpu: p.price_per_hour for p in prices
                  if p.provider == Provider.AWS and not p.is_spot}

        result = []
        for p in prices:
            if p.availability == "unavailable":
                continue
            aws = aws_od.get(p.gpu)
            if not aws:
                continue

            # Enterprise compliance: suppress cross-cloud opportunities
            if enterprise_compliance:
                if source == "azure" and p.provider != Provider.AZURE:
                    continue
                if source == "gcp" and p.provider != Provider.GCP:
                    continue

            vl = self.vl_price(p.price_per_hour)
            raw_savings = aws - vl

            egress_total, egress_label = self._egress_cost_for_target(
                source=source,
                target_provider=p.provider,
                dataset_size_gb=dataset_size_gb,
                dataset_aws_region=dataset_aws_region,
                vpc_gateway_endpoint=vpc_gateway_endpoint,
                enterprise_compliance=enterprise_compliance,
            )
            egress_per_hour = egress_total / max(training_duration_hours, 0.1)
            adjusted_savings = raw_savings - egress_per_hour

            if adjusted_savings > ARBITRAGE_THRESHOLD:
                result.append({
                    "gpu": p.gpu.value,
                    "to_provider": p.provider.value,
                    "aws_price": aws,
                    "vaultlayer_price": vl,
                    "savings_per_hour": round(adjusted_savings, 2),
                    "raw_savings_per_hour": round(raw_savings, 2),
                    "egress_cost_per_hour": round(egress_per_hour, 2),
                    "egress_cost_total_usd": round(egress_total, 2),
                    "egress_type": egress_label,
                    "source_cloud": source,
                    "vpc_gateway_endpoint": vpc_gateway_endpoint,
                    "savings_pct": round(adjusted_savings / aws * 100, 1),
                    "availability": p.availability,
                })
        return sorted(result, key=lambda x: x["savings_per_hour"], reverse=True)

    def _map_lambda(self, name: str) -> Optional[GPUType]:
        return _pollers_map_lambda(name)

    def _aws_on_demand_last_resort_prices(self) -> list[GPUPrice]:
        return _pollers_aws_od_last_resort(self)

    async def _poll_once(self):
        all_prices = (
            (await self.fetch_aws_spot()) +         # AWS Spot (live/regional)
            (await self.fetch_lambda()) +
            (await self.fetch_coreweave()) +
            (await self.fetch_runpod_live()) +
            (await self.fetch_vast()) +
            (await self.fetch_voltage_park()) +
            (await self.fetch_crusoe()) +
            (await self.fetch_nebius()) +
            (await self.fetch_hyperstack()) +
            (await self.fetch_gcp()) +
            (await self.fetch_azure()) +
            self._aws_on_demand_last_resort_prices()  # last resort — never arbitraged
        )
        dicts = [p.model_dump(mode="json") for p in all_prices]

        # ── Dynamic tier classification: enrich each price entry ─────────────
        # Group by GPU to compute median price + availability ratio
        from collections import defaultdict
        _gpu_prices: dict[str, list[float]] = defaultdict(list)
        _gpu_avail: dict[str, dict[str, int]] = defaultdict(lambda: {"total": 0, "low": 0})
        for d in dicts:
            _g = d.get("gpu") or d.get("gpu_type") or ""
            if not _g:
                continue
            _p = d.get("price_per_hour", 0)
            if _p and _p > 0:
                _gpu_prices[_g].append(_p)
            _gpu_avail[_g]["total"] += 1
            if d.get("availability") in ("low", "unavailable"):
                _gpu_avail[_g]["low"] += 1

        from shared.compute_tiers import classify_gpu_tier_from_market
        _gpu_tier_cache: dict[str, int] = {}
        for _g, _prices in _gpu_prices.items():
            _sorted = sorted(_prices)
            _n = len(_sorted)
            _median = (_sorted[(_n - 1) // 2] + _sorted[_n // 2]) / 2 if _n else 0
            _avail_info = _gpu_avail.get(_g, {"total": 1, "low": 0})
            _low_ratio = _avail_info["low"] / max(_avail_info["total"], 1)
            _tier_num, _, _ = classify_gpu_tier_from_market(_g, _median, _low_ratio)
            _gpu_tier_cache[_g] = _tier_num

        # Stamp computed_tier onto each price dict
        for d in dicts:
            _g = d.get("gpu") or d.get("gpu_type") or ""
            if _g in _gpu_tier_cache:
                d["computed_tier"] = _gpu_tier_cache[_g]

        await self.queue.set_price_cache(dicts)

        # Check whether any waiting GPU hot-swaps can now be completed
        await self._check_gpu_hops(dicts)

        await self.queue.publish("pricing", make_event(
            event_type=EventType.PRICE_UPDATE,
            source_agent=self.AGENT_NAME,
            payload={"prices": dicts, "timestamp": datetime.utcnow().isoformat()},
            priority=7,
        ))
        # Aggregate dataset egress parameters across all active jobs (worst-case: largest dataset)
        total_dataset_gb = sum(
            getattr(j, "dataset_size_gb", 0.0) for j in self._active_jobs.values()
        )
        # Use "s3" if any job has its dataset there; else "r2" (no egress penalty)
        any_s3 = any(
            getattr(j, "dataset_location", "s3") == "s3" for j in self._active_jobs.values()
        )
        dataset_location = "s3" if any_s3 else "r2"
        avg_training_hours = (
            sum(getattr(j, "training_duration_hours", 1.0) for j in self._active_jobs.values())
            / max(len(self._active_jobs), 1)
        )
        opps = self.find_opportunities(
            all_prices,
            dataset_size_gb=total_dataset_gb,
            dataset_location=dataset_location,
            training_duration_hours=avg_training_hours,
        )
        if opps:
            best = opps[0]
            logger.info(f"Arbitrage: {best['gpu']} save ${best['savings_per_hour']}/hr via {best['to_provider']}")
            await self.queue.publish("pricing", make_event(
                event_type=EventType.ARBITRAGE_OPPORTUNITY,
                source_agent=self.AGENT_NAME,
                payload={"opportunities": opps[:3]},
                priority=3,
            ))

    # Auto-expire consent after 24 hours (86400 seconds)
    _GPU_HOP_CONSENT_TTL_SECS = 86400

    async def _check_gpu_hops(self, cached_prices: list[dict]) -> None:
        """
        GPU hot-swap watcher — runs every poll cycle (60s).

        Queries Supabase for jobs where:
          gpu_hop_consented = true   (user accepted the fallback + auto-upgrade offer)
          gpu_hop_completed = false  (hot-swap hasn't happened yet)
          gpu_hop_cancelled = false  (user hasn't cancelled / hasn't auto-expired)

        For each pending hop:
          - Auto-cancels if consent is older than 24h
          - Increments attempt counter + updates last_check_at
          - If target GPU is available: publishes GPU_HOP_AVAILABLE
        """
        try:
            from api.db import get_db, _db_call
        except ImportError:
            return  # DB client not available in this runtime context

        try:
            db = get_db()
            result = _db_call(
                lambda: db.table("jobs")
                    .select("job_id, user_id, target_gpu, fallback_gpu, "
                            "gpu_hop_consented_at, gpu_hop_attempts, gpu_hop_last_check_at")
                    .eq("gpu_hop_consented", True)
                    .eq("gpu_hop_completed", False)
                    .eq("gpu_hop_cancelled", False)
                    .execute(),
                label="gpu_hop_watcher:query",
            )
            pending_hops = result.data or []
        except Exception as e:
            logger.debug(f"[gpu-hop-watcher] DB query failed (non-fatal): {e}")
            return

        if not pending_hops:
            return

        # Build a set of GPUs currently available in the price cache
        available_gpus: set[str] = {
            r.get("gpu") or r.get("gpu_type") or ""
            for r in cached_prices
            if r.get("availability") not in ("unavailable", "last_resort")
        }
        available_gpus.discard("")

        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)

        for hop in pending_hops:
            job_id    = hop.get("job_id", "")
            target    = hop.get("target_gpu", "")
            fallback  = hop.get("fallback_gpu", "")

            # ── Auto-expire consent after 24h ────────────────────────────────
            consented_at_str = hop.get("gpu_hop_consented_at")
            if consented_at_str:
                try:
                    _ca = consented_at_str.replace("Z", "+00:00")
                    consented_at = datetime.fromisoformat(_ca)
                    if not consented_at.tzinfo:
                        consented_at = consented_at.replace(tzinfo=timezone.utc)
                    if (now - consented_at).total_seconds() > self._GPU_HOP_CONSENT_TTL_SECS:
                        logger.info(
                            f"[gpu-hop-watcher] job={job_id} consent expired (>24h) — auto-cancelling"
                        )
                        try:
                            _db_call(
                                lambda: db.table("jobs").update({
                                    "gpu_hop_cancelled": True,
                                    "gpu_hop_cancelled_at": now.isoformat(),
                                    "gpu_hop_cancel_reason": "consent_expired_24h",
                                }).eq("job_id", job_id).execute(),
                                label="gpu_hop_watcher:auto_cancel",
                            )
                        except Exception:
                            pass
                        continue
                except (ValueError, TypeError):
                    pass  # malformed timestamp, skip expiry check

            if not target or target not in available_gpus:
                # ── Record miss: update attempt counter ──────────────────────
                _attempts = int(hop.get("gpu_hop_attempts") or 0) + 1
                try:
                    _db_call(
                        lambda: db.table("jobs").update({
                            "gpu_hop_attempts": _attempts,
                            "gpu_hop_last_check_at": now.isoformat(),
                        }).eq("job_id", job_id).execute(),
                        label="gpu_hop_watcher:update_attempts",
                    )
                except Exception:
                    pass
                logger.debug(
                    f"[gpu-hop-watcher] job={job_id} target={target} still unavailable "
                    f"(attempt {_attempts})"
                )
                continue

            logger.info(
                f"[gpu-hop-watcher] job={job_id} target={target} is NOW AVAILABLE — "
                f"publishing GPU_HOP_AVAILABLE"
            )

            # Find the best provider for the target GPU
            target_rows = sorted(
                [r for r in cached_prices
                 if (r.get("gpu") or r.get("gpu_type") or "") == target
                 and r.get("availability") not in ("unavailable", "last_resort")],
                key=lambda r: r.get("price_per_hour", 9999),
            )
            best = target_rows[0] if target_rows else {}

            await self.queue.publish("pricing", make_event(
                event_type=EventType.GPU_HOP_AVAILABLE,
                source_agent=self.AGENT_NAME,
                job_id=job_id,
                payload={
                    "job_id":       job_id,
                    "target_gpu":   target,
                    "fallback_gpu": fallback,
                    "provider":     best.get("provider", ""),
                    "region":       best.get("region", ""),
                    "price_per_hour": best.get("price_per_hour", 0.0),
                },
                priority=2,
            ))

    async def start(self):
        logger.info(f"Pricing Agent polling every {POLL_INTERVAL}s")
        while True:
            try:
                await self._poll_once()
            except Exception as e:
                logger.error(f"Poll error: {e}", exc_info=True)
            await asyncio.sleep(POLL_INTERVAL)

    async def stop(self):
        logger.info("Pricing Agent stopping.")
