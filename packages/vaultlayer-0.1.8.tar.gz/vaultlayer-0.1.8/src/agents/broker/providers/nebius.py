"""Nebius AI provider -- provision + fence."""
from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Optional

import aiohttp

if TYPE_CHECKING:
    from shared.models import GPUType, Job

logger = logging.getLogger(__name__)


async def _get_iam_token(broker, cfg) -> Optional[str]:
    """Exchange a Nebius service-account private key for an IAM access token.

    Nebius auth flow (source: https://docs.nebius.com/grpc-api/auth):
      1. Sign a short-lived JWT (RS256, 5-min expiry) with the private key.
         JWT claims: alg=RS256, kid=key_id, iss=service_account_id, sub=service_account_id
      2. POST https://auth.{region}.nebius.com/oauth2/token/exchange
         (form-encoded, grant_type=token-exchange, subject_token=<JWT>)
      3. Response: {"accessToken": "...", "expiresIn": "43200"}  (12h)
      4. Use accessToken as Authorization: Bearer in all API calls.

    The raw service_account_key is NEVER a valid Bearer token -- it is the RSA
    private key used only to sign the JWT.  Passing it directly causes 401.
    """
    import time as _time

    # Return cached token if still valid (with 5-min safety margin)
    if broker._nebius_token_cache:
        token, expiry = broker._nebius_token_cache
        if _time.monotonic() < expiry - 300:
            return token

    private_key = getattr(cfg, "service_account_key", "")
    key_id = getattr(cfg, "key_id", "")
    sa_id = getattr(cfg, "service_account_id", "")
    region = getattr(cfg, "region", "eu")

    if not private_key:
        logger.error("[Broker] Nebius service_account_key not set -- cannot obtain IAM token")
        return None
    if not key_id or not sa_id:
        logger.warning(
            "[Broker] Nebius NEBIUS_KEY_ID or NEBIUS_SA_ID not set -- "
            "cannot sign JWT for IAM token exchange. Set these env vars."
        )
        return None

    try:
        import jwt as _jwt  # PyJWT

        now = int(_time.time())
        payload = {"iss": sa_id, "sub": sa_id, "iat": now, "exp": now + 300}
        token_jwt = _jwt.encode(
            payload,
            private_key,
            algorithm="RS256",
            headers={"kid": key_id},
        )

        auth_url = f"https://auth.{region}.nebius.com/oauth2/token/exchange"
        async with aiohttp.ClientSession() as s:
            resp = await s.post(
                auth_url,
                data={
                    "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
                    "requested_token_type": "urn:ietf:params:oauth:token-type:access_token",
                    "subject_token": token_jwt,
                    "subject_token_type": "urn:ietf:params:oauth:token-type:jwt",
                },
                timeout=aiohttp.ClientTimeout(total=15),
            )
            if resp.status != 200:
                body = await resp.text()
                logger.error(f"[Broker] Nebius IAM token exchange failed ({resp.status}): {body[:200]}")
                return None
            data = await resp.json()
            iam_token = data.get("accessToken") or data.get("access_token")
            expires_in = int(data.get("expiresIn") or data.get("expires_in") or 43200)
            broker._nebius_token_cache = (iam_token, _time.monotonic() + expires_in)
            logger.info(f"[Broker] Nebius IAM token obtained (expires in {expires_in}s)")
            return iam_token
    except ImportError:
        logger.error("[Broker] PyJWT not installed -- run: pip install PyJWT cryptography")
    except Exception as e:
        logger.error(f"[Broker] Nebius IAM token exchange error: {e}")
    return None


async def provision(broker, gpu_type: "GPUType", job: "Job") -> Optional[str]:
    """Provision a Nebius AI instance. Returns instance ID or None."""
    from shared.data_loader import get_instance_string, resolve_gpu_key, is_gpu_available

    _cfg = broker._get_provider_config("nebius")
    if not _cfg:
        _managed = await broker._get_managed_credentials("nebius", job.job_id)
        if not _managed:
            job.last_provision_error = "Nebius: no credentials available"
            return None
        from types import SimpleNamespace
        _cfg = SimpleNamespace(
            api_key=_managed.get("service_account_key", ""),
            folder_id=_managed.get("folder_id", ""),
        )
    _gpu_key = resolve_gpu_key(gpu_type.value)
    if not is_gpu_available("Nebius (EU)", _gpu_key):
        job.last_provision_error = f"Nebius: GPU {_gpu_key} not available"
        return None
    gpu_preset = get_instance_string("Nebius", _gpu_key)
    if not gpu_preset:
        job.last_provision_error = f"Nebius: no preset mapped for {_gpu_key}"
        return None
    # Nebius REST API: compute.api.<region>.nebius.cloud (v1, not v1alpha1)
    # compute.api.nebius.ai is deprecated; base_url from config defaults to EU region.
    _nebius_base = getattr(_cfg, "base_url", "https://compute.api.eu.nebius.cloud/compute/v1")
    try:
        import base64 as _b64
        iam_token = await _get_iam_token(broker, _cfg)
        if not iam_token:
            job.last_provision_error = "Nebius: could not obtain IAM token"
            logger.error("[Broker] Nebius: could not obtain IAM token, aborting provision")
            return None
        nebius_startup = _b64.b64encode(broker._build_vm_startup_script(job).encode()).decode()
        # IDEM-1: Nebius officially supports X-Idempotency-Key header on
        # all mutating calls. Same key on retry returns the cached
        # operation. See docs/IDEM1_PROVIDER_KEYS.md.
        from shared.idempotency import provision_idempotency_key
        _attempts = getattr(job, "_provision_attempts", None) or []
        _idem_key = provision_idempotency_key(
            f"{job.job_id}:nebius", len(_attempts) + 1
        )
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{_nebius_base}/instances",
                headers={
                    "Authorization": f"Bearer {iam_token}",
                    "X-Idempotency-Key": _idem_key,
                },
                json={"name": f"vl-{job.job_id[:8]}", "preset": gpu_preset,
                      "boot_disk": {"type": "NETWORK_SSD", "size": 107374182400},
                      "metadata": {"user-data": nebius_startup}},
                timeout=aiohttp.ClientTimeout(total=30)
            ) as r:
                if r.status not in (200, 201):
                    _err = (await r.text())[:200]
                    job.last_provision_error = f"Nebius: HTTP {r.status} -- {_err[:150]}"
                    return None
                data = await r.json()
                # REST transcoding wraps the response in an Operation object
                return data.get("id") or (data.get("metadata") or {}).get("id")
    except Exception as e:
        job.last_provision_error = f"Nebius: {type(e).__name__}: {str(e)[:150]}"
        logger.error(f"Nebius provision error: {e}"); return None


async def hard_fence(broker, instance_id: str, job=None) -> None:
    """Delete a Nebius AI instance via API.

    Nebius migrated from compute.api.nebius.ai (legacy, deprecated) to
    compute.api.<region>.nebius.cloud. API version is v1 (not v1alpha1).
    Auth: Bearer IAM token (exchanged from service_account_key via Nebius Identity service).
    """
    _cfg = broker._get_provider_config("nebius")
    if not _cfg:
        logger.warning(f"[Broker] Nebius config not found, skipping fence for {instance_id}")
        return
    _base = getattr(_cfg, "base_url", "https://compute.api.eu.nebius.cloud/compute/v1")
    try:
        iam_token = await _get_iam_token(broker, _cfg)
        if not iam_token:
            logger.warning(f"[Broker] Nebius: could not obtain IAM token for fence of {instance_id}, skipping")
            return
        async with aiohttp.ClientSession() as s:
            resp = await s.delete(
                f"{_base}/instances/{instance_id}",
                headers={"Authorization": f"Bearer {iam_token}"},
                timeout=aiohttp.ClientTimeout(total=15),
            )
            if resp.status in (200, 202, 204):
                logger.info(f"[Broker] Nebius instance {instance_id} delete issued (status={resp.status})")
            else:
                body = await resp.text()
                logger.warning(f"[Broker] Nebius fence returned {resp.status}: {body[:200]}")
    except Exception as e:
        logger.warning(f"[Broker] Nebius fence failed for {instance_id} (proceeding): {e}")
