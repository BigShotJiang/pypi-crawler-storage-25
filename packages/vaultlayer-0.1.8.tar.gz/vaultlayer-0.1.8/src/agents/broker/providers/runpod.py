"""RunPod provider — provision + fence.

Provision uses the REST API (POST /v1/pods) which gives:
  - dockerEntrypoint (array) — override ENTRYPOINT
  - dockerStartCmd (array) — override CMD
  - gpuTypeIds (array) — ranked GPU fallback list
  - gpuTypePriority — "availability" for auto-selection

Fence uses DELETE /v1/pods/{podId} with post-delete polling.

Source: https://docs.runpod.io/sdks/graphql/manage-pods
        https://rest.runpod.io/v1/openapi.json
"""
from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Optional

import aiohttp

if TYPE_CHECKING:
    from shared.models import GPUType, Job

logger = logging.getLogger(__name__)

# REST API base
_REST_BASE = "https://rest.runpod.io/v1"


async def provision(broker, gpu_type: "GPUType", job: "Job") -> Optional[str]:
    """Provision a RunPod pod via REST API. Returns pod ID or None.

    Uses REST API instead of GraphQL for:
      - dockerEntrypoint + dockerStartCmd (separate ENTRYPOINT/CMD control)
      - gpuTypeIds (ranked GPU fallback array)
      - gpuTypePriority: "availability" (auto-picks best available)

    Source: https://docs.runpod.io/pods/manage-pods (POST /v1/pods)
    """
    from shared.data_loader import resolve_gpu_key
    from shared.models import Provider

    _cfg = broker._get_provider_config("runpod")
    if not _cfg:
        _managed = await broker._get_managed_credentials("runpod", job.job_id)
        if not _managed:
            job.last_provision_error = "RunPod: no credentials available (BYOC or managed)"
            return None
        from types import SimpleNamespace
        _cfg = SimpleNamespace(api_key=_managed["api_key"])

    _gpu_key = resolve_gpu_key(gpu_type.value)
    # Dynamic GPU resolution: cache → API → static fallback
    gpu_name = await broker.gpu_resolver.resolve("RunPod", _gpu_key, api_key=_cfg.api_key)
    if not gpu_name:
        job.last_provision_error = f"RunPod: no matching GPU type for {_gpu_key}"
        logger.warning(f"RunPod: no matching GPU type for {_gpu_key}")
        return None

    try:
        # Pinned runpod/pytorch tag (not :latest). We SSH-verified 2026-04-18
        # in pod brb74hkjwqrs5u that this tag's /start.sh chains to
        # /pre_start.sh via its documented `execute_script` hook, and that
        # dockerEntrypoint + env vars (VL_JOB_TOKEN, VAULTLAYER_API_URL,
        # VL_ONSTART_B64, PUBLIC_KEY) all reach PID 1's environment. Users
        # who pass docker_image keep full control.
        image = job.docker_image or "runpod/pytorch:2.1.0-py3.10-cuda11.8.0-devel-ubuntu22.04"

        # Use unified prepare_startup() — handles base64 encoding
        _startup_payload = broker.prepare_startup(Provider.RUNPOD, job)

        # Build REST API body.
        # dockerEntrypoint writes our bootstrap to /pre_start.sh then execs
        # the image's /start.sh. /start.sh then:
        #   1. starts nginx + sshd (users can SSH in with PUBLIC_KEY)
        #   2. calls `execute_script /pre_start.sh` — runs our bootstrap
        #   3. starts jupyter (if JUPYTER_PASSWORD set)
        #   4. sleeps — keeps container alive for the session
        #
        # Defensive touches applied 2026-04-18:
        #   - `set -euo pipefail` so silent failures can't mask the entrypoint
        #   - `"$VL_ONSTART_B64"` quoted (no word-splitting if encoding has
        #     whitespace — shouldn't happen but belt-and-suspenders)
        #   - verify /pre_start.sh is non-empty before exec'ing /start.sh
        #     (empty file = env var missing / truncated; fail loudly)
        _entrypoint = [
            "bash", "-c",
            "set -euo pipefail; "
            "echo \"$VL_ONSTART_B64\" | base64 -d > /pre_start.sh; "
            "chmod +x /pre_start.sh; "
            # Fail fast if VL_ONSTART_B64 was missing/truncated.
            "if [ ! -s /pre_start.sh ]; then "
            "  echo '[VL entrypoint] /pre_start.sh empty — VL_ONSTART_B64 missing' >&2; "
            "  exit 42; "
            "fi; "
            "exec /start.sh"
        ]

        # Environment variables
        env_vars = _startup_payload.runpod_env or {}

        body = {
            "name": f"vl-{job.job_id[:8]}",
            "imageName": image,
            "gpuTypeIds": [gpu_name],
            "gpuTypePriority": "availability",
            "gpuCount": 1,
            "volumeInGb": 50,
            "containerDiskInGb": 100,
            "volumeMountPath": "/workspace",
            "dockerEntrypoint": _entrypoint,
            "dockerStartCmd": [],
            "ports": ["8888/http", "22/tcp"],
            "cloudType": "SECURE",
            "supportPublicIp": True,
            "env": {k: str(v) for k, v in env_vars.items()},
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{_REST_BASE}/pods",
                headers={
                    "Authorization": f"Bearer {_cfg.api_key}",
                    "Content-Type": "application/json",
                },
                json=body,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as r:
                if r.status not in (200, 201):
                    # Capture RunPod's error body: 2000 chars into
                    # job.error (schema-validation enums for gpuTypeIds
                    # list 15+ GPU names and exceed 500 chars), and the
                    # full body into Railway logs. Prefix with the
                    # resolved gpu_name so schema-enum rejections name
                    # exactly what we sent.
                    _full_body = await r.text()
                    _err_body = _full_body[:2000]
                    job.last_provision_error = (
                        f"RunPod: HTTP {r.status} sent gpu_name={gpu_name!r} "
                        f"({_gpu_key}) — {_err_body}"
                    )
                    from shared.failure_codes import JobFailureCode
                    # HTTP 402 or body containing "insufficient" / "balance" / "funds"
                    # = VaultLayer's managed RunPod account has $0. Surface as
                    # PROV_MANAGED_BALANCE so the runner/dashboard see the real cause
                    # (not "capacity") and we know to top up the account.
                    _balance_signals = ("insufficient", "balance", "funds", "payment", "credit")
                    if r.status == 402 or any(s in _full_body.lower() for s in _balance_signals):
                        job.failure_code = JobFailureCode.PROV_MANAGED_BALANCE.value
                        job.failure_detail = (
                            f"RunPod managed account has insufficient balance "
                            f"(HTTP {r.status}). Top up console.runpod.io. Body: {_err_body[:200]}"
                        )[:500]
                        logger.error(
                            f"RunPod MANAGED BALANCE EMPTY — provision blocked "
                            f"(HTTP {r.status}): {_full_body[:500]}"
                        )
                    else:
                        # Lifecycle Gate: other 4xx = provider rejected our GPU name.
                        # Needs a different gpu_name (or different provider) on retry.
                        job.failure_code = JobFailureCode.PROV_SCHEMA_REJECT.value
                        job.failure_detail = (
                            f"RunPod rejected gpu_name={gpu_name!r} for canonical "
                            f"{_gpu_key!r} (HTTP {r.status}). Body: {_err_body[:200]}"
                        )[:500]
                        logger.error(
                            f"RunPod REST provision {r.status} "
                            f"sent gpu_name={gpu_name!r} ({_gpu_key}): {_full_body}"
                        )
                    return None
                data = await r.json()
                pod_id = data.get("id")
                if pod_id:
                    # Capture the real hourly cost from the pod response so
                    # the user is billed at the rate RunPod charged us, not
                    # the cached config rate. job_worker.py picks
                    # job.current_hourly_rate over the config price at
                    # settle time (same pattern as Vast.ai). costPerHr is
                    # 1:1 with USD per RunPod's billing model.
                    # Source: https://docs.runpod.io/api-reference/pods/POST/pods
                    try:
                        _rate = float(data.get("costPerHr") or 0)
                    except (TypeError, ValueError):
                        _rate = 0.0
                    if _rate > 0:
                        job.current_hourly_rate = _rate
                    logger.info(
                        f"RunPod pod {pod_id} provisioned via REST API "
                        f"(gpu={gpu_name}, image={image}, costPerHr=${_rate:.4f})"
                    )
                    return pod_id
                job.last_provision_error = f"RunPod: no pod ID in response — {str(data)[:150]}"
                return None
    except Exception as e:
        job.last_provision_error = f"RunPod: {type(e).__name__}: {str(e)[:150]}"
        logger.error(f"RunPod provision error: {e}")
        return None


async def hard_fence(broker, instance_id: str, job=None) -> None:
    """Permanently delete a RunPod pod via REST API and verify destruction.

    Endpoint: DELETE https://rest.runpod.io/v1/pods/{podId}
    Post-delete: polls GET /v1/pods/{podId} until 404 (pod gone).

    Source: https://docs.runpod.io/pods/manage-pods
    """
    _cfg = broker._get_provider_config("runpod")
    if not _cfg:
        _managed = await broker._get_managed_credentials("runpod", f"fence-{instance_id}")
        if _managed:
            from types import SimpleNamespace
            _cfg = SimpleNamespace(api_key=_managed["api_key"])
        else:
            logger.warning(f"[Broker] RunPod config not found, skipping fence for {instance_id}")
            return
    try:
        _headers = {"Authorization": f"Bearer {_cfg.api_key}"}
        async with aiohttp.ClientSession() as s:
            resp = await s.delete(
                f"{_REST_BASE}/pods/{instance_id}",
                headers=_headers,
                timeout=aiohttp.ClientTimeout(total=15),
            )
            body = await resp.text()
            if resp.status in (200, 202, 204):
                logger.info(f"[Broker] RunPod pod {instance_id} deleted (status={resp.status})")
            elif resp.status == 404:
                logger.info(f"[Broker] RunPod pod {instance_id} already gone (404)")
                return
            else:
                logger.warning(f"[Broker] RunPod delete returned {resp.status}: {body[:200]}")

            # Post-delete verification: poll GET /v1/pods/{podId} until 404
            for _attempt in range(12):  # 60s max
                await asyncio.sleep(5)
                try:
                    check = await s.get(
                        f"{_REST_BASE}/pods/{instance_id}",
                        headers=_headers,
                        timeout=aiohttp.ClientTimeout(total=10),
                    )
                    if check.status == 404:
                        logger.info(f"[Broker] RunPod pod {instance_id} confirmed destroyed (404)")
                        return
                    if check.status == 200:
                        _pod_data = await check.json()
                        _status = _pod_data.get("desiredStatus", "")
                        logger.debug(f"[Broker] RunPod pod {instance_id} still exists (desiredStatus={_status})")
                except Exception:
                    pass  # Network blip — keep polling
            raise RuntimeError(
                f"[Broker] RunPod pod {instance_id} NOT confirmed destroyed after 60s — "
                f"potential billing leak"
            )
    except Exception as e:
        logger.error(f"[Broker] RunPod fence failed for {instance_id}: {e}")
        raise
