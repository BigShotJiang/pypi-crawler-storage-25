"""Provider registry — maps Provider enum to provider modules.

Each provider module exposes:
  - provision(broker, gpu_type, job) -> Optional[str]
  - hard_fence(broker, instance_id, job=None) -> None

Adding a new provider:
  1. Create providers/new_provider.py with provision() and hard_fence()
  2. Add one line to PROVIDER_REGISTRY below
  3. Done — dispatch_provision/dispatch_fence will route to it automatically
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from shared.models import Provider

from agents.broker.providers import (
    aws,
    azure,
    coreweave,
    crusoe,
    gcp,
    hyperstack,
    lambda_labs,
    nebius,
    runpod,
    vast_ai,
    voltage_park,
)

if TYPE_CHECKING:
    from shared.models import GPUType, Job

logger = logging.getLogger(__name__)

# ══════════════════════════════════════════════════════════════════════════════
# THE REGISTRY — one line per provider
# ══════════════════════════════════════════════════════════════════════════════

PROVIDER_REGISTRY = {
    Provider.LAMBDA_LABS:   lambda_labs,
    Provider.RUNPOD:        runpod,
    Provider.VAST_AI:       vast_ai,
    Provider.AWS:           aws,
    Provider.GCP:           gcp,
    Provider.AZURE:         azure,
    Provider.COREWEAVE:     coreweave,
    Provider.VOLTAGE_PARK:  voltage_park,
    Provider.CRUSOE:        crusoe,
    Provider.NEBIUS:        nebius,
    Provider.HYPERSTACK:    hyperstack,
}


async def dispatch_provision(
    broker, provider: Provider, gpu_type: "GPUType", job: "Job"
) -> Optional[str]:
    """Route provision call to the correct provider module."""
    mod = PROVIDER_REGISTRY.get(provider)
    if not mod:
        logger.error(f"No provider module for {provider}")
        return None
    return await mod.provision(broker, gpu_type, job)


async def dispatch_fence(
    broker, provider: Provider, instance_id: str, job=None
) -> None:
    """Route fence call to the correct provider module."""
    mod = PROVIDER_REGISTRY.get(provider)
    if not mod:
        logger.warning(f"No provider module for fence: {provider}")
        return
    await mod.hard_fence(broker, instance_id, job)
