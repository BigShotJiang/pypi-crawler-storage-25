"""Azure provider — provision + fence."""
from __future__ import annotations

import asyncio
import logging
import os
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from shared.models import GPUType, Job

from shared.models import GPUType

logger = logging.getLogger(__name__)


async def provision(broker, gpu_type: "GPUType", job: "Job") -> Optional[str]:
    """
    Provision an Azure Spot VM with GPU.

    Returns '<vm_name>/<public_ip>' on success so _resolve_instance_host()
    can extract the IP without an extra API round-trip.  Returns None on failure.
    """
    if not broker.config.azure:
        job.last_provision_error = "Azure: not configured"
        logger.error("Azure not configured. Run: vaultlayer connect azure")
        return None

    # GPU -> Azure VM size
    _AZURE_VM_SIZES: dict[GPUType, str] = {
        GPUType.H100_80GB_SXM: "Standard_ND96isr_H100_v5",
        GPUType.A100_80GB_SXM: "Standard_ND96asr_v4",
        GPUType.A100_40GB:     "Standard_ND96asr_v4",
        GPUType.A10G:          "Standard_NC6s_v3",
    }
    if gpu_type not in _AZURE_VM_SIZES:
        logger.error(f"GPU type {gpu_type} not supported on Azure")
        return None

    vm_size = _AZURE_VM_SIZES[gpu_type]
    az_cfg  = broker.config.azure
    vm_name = f"vl-{job.job_id[:8]}"
    rg      = az_cfg.resource_group
    location = az_cfg.location

    # Read SSH public key — required for VM access
    ssh_pub_key_path = os.path.expanduser(
        os.environ.get("VAULTLAYER_SSH_PUB_KEY", "~/.ssh/id_rsa.pub")
    )
    try:
        with open(ssh_pub_key_path) as _kf:
            ssh_pub_key_data = _kf.read().strip()
    except OSError:
        logger.error(
            f"SSH public key not found at {ssh_pub_key_path}. "
            "Set VAULTLAYER_SSH_PUB_KEY or ensure ~/.ssh/id_rsa.pub exists."
        )
        return None

    try:
        from azure.identity import ClientSecretCredential
        from azure.mgmt.compute import ComputeManagementClient
        from azure.mgmt.network import NetworkManagementClient

        credential = ClientSecretCredential(
            tenant_id=az_cfg.tenant_id,
            client_id=az_cfg.client_id,
            client_secret=az_cfg.client_secret,
        )
        compute_client = ComputeManagementClient(credential, az_cfg.subscription_id)
        network_client = NetworkManagementClient(credential, az_cfg.subscription_id)

        vnet_name   = f"{vm_name}-vnet"
        subnet_name = "default"
        nic_name    = f"{vm_name}-nic"
        pip_name    = f"{vm_name}-pip"   # public IP resource

        # -- 1. VNet + Subnet --
        network_client.virtual_networks.begin_create_or_update(
            rg, vnet_name, {
                "location": location,
                "address_space": {"address_prefixes": ["10.0.0.0/16"]},
                "subnets": [{"name": subnet_name, "address_prefix": "10.0.0.0/24"}],
            }
        ).result()
        subnet = network_client.subnets.get(rg, vnet_name, subnet_name)

        # -- 2. Public IP (Standard SKU for reliable SSH access) --
        pip = network_client.public_ip_addresses.begin_create_or_update(
            rg, pip_name, {
                "location": location,
                "sku": {"name": "Standard"},
                "public_ip_allocation_method": "Static",
                "tags": {"managed-by": "vaultlayer", "vaultlayer-job": job.job_id[:63]},
            }
        ).result()

        # -- 3. NIC (with public IP attached) --
        nic = network_client.network_interfaces.begin_create_or_update(
            rg, nic_name, {
                "location": location,
                "ip_configurations": [{
                    "name": "ipconfig1",
                    "subnet": {"id": subnet.id},
                    "public_ip_address": {"id": pip.id},
                }],
            }
        ).result()

        # -- 4. Spot VM --
        vm_poller = compute_client.virtual_machines.begin_create_or_update(
            rg, vm_name, {
                "location": location,
                "hardware_profile": {"vm_size": vm_size},
                "storage_profile": {
                    "image_reference": {
                        "publisher": "microsoft-dsvm",
                        "offer":     "ubuntu-hpc",
                        "sku":       "2204",
                        "version":   "latest",
                    },
                    "os_disk": {
                        "create_option":  "FromImage",
                        "delete_option":  "Delete",   # auto-delete disk on VM delete
                        "managed_disk":   {"storage_account_type": "Premium_LRS"},
                    },
                },
                "os_profile": {
                    "computer_name":  vm_name,
                    "admin_username": "vaultlayer",
                    "linux_configuration": {
                        "disable_password_authentication": True,
                        "ssh": {
                            "public_keys": [{
                                "path":     "/home/vaultlayer/.ssh/authorized_keys",
                                "key_data": ssh_pub_key_data,
                            }]
                        },
                    },
                    # custom_data runs as cloud-init on first boot (base64-encoded)
                    "custom_data": __import__("base64").b64encode(
                        broker._build_vm_startup_script(job).encode()
                    ).decode(),
                },
                "network_profile": {"network_interfaces": [{"id": nic.id}]},
                "priority":         "Spot",
                "eviction_policy":  "Delete",
                "billing_profile":  {"max_price": -1},  # pay market spot rate
                "tags": {
                    "managed-by":     "vaultlayer",
                    "vaultlayer-job": job.job_id[:63],
                },
            }
        )

        # -- 5. Wait for provisioning to complete (up to 5 min) --
        import time as _time
        deadline = _time.monotonic() + 300
        vm = vm_poller.result()  # blocks until ARM operation finishes
        while _time.monotonic() < deadline:
            state = vm.provisioning_state
            if state == "Succeeded":
                break
            if state == "Failed":
                logger.error(f"Azure VM {vm_name} provisioning failed")
                return None
            await asyncio.sleep(10)
            vm = compute_client.virtual_machines.get(rg, vm_name)

        # -- 6. Retrieve actual public IP --
        pip_info = network_client.public_ip_addresses.get(rg, pip_name)
        public_ip = pip_info.ip_address
        if not public_ip:
            logger.error(f"Azure VM {vm_name} has no public IP after provisioning")
            return None

        logger.info(f"Azure VM {vm_name} running at {public_ip} ({vm_size})")
        # Encode IP into instance_id so _resolve_instance_host can retrieve it
        # without an extra API call: format is  vm_name/public_ip
        return f"{vm_name}/{public_ip}"

    except ImportError:
        job.last_provision_error = "Azure: SDKs not installed (azure-mgmt-compute, azure-mgmt-network, azure-identity)"
        logger.error(
            "Azure SDKs not installed. "
            "Run: pip install azure-mgmt-compute azure-mgmt-network azure-identity"
        )
        return None
    except Exception as e:
        job.last_provision_error = f"Azure: {type(e).__name__}: {str(e)[:150]}"
        logger.error(f"Azure provision error: {e}")
        return None


async def hard_fence(broker, instance_id: str, job=None) -> None:
    """Delete an Azure VM and all associated network resources (NIC, PIP, VNet).
    instance_id is encoded as 'vm_name/public_ip' from provision_azure.
    """
    if not broker.config.azure:
        logger.warning(f"[Broker] Azure not configured, skipping fence for {instance_id}")
        return
    try:
        from azure.identity import ClientSecretCredential
        from azure.mgmt.compute import ComputeManagementClient
        from azure.mgmt.network import NetworkManagementClient
        az_cfg = broker.config.azure
        vm_name = instance_id.split("/", 1)[0]  # strip '/ip' encoding from provision_azure
        credential = ClientSecretCredential(
            tenant_id=az_cfg.tenant_id,
            client_id=az_cfg.client_id,
            client_secret=az_cfg.client_secret,
        )
        loop = asyncio.get_event_loop()
        compute_client = ComputeManagementClient(credential, az_cfg.subscription_id)
        network_client = NetworkManagementClient(credential, az_cfg.subscription_id)
        rg = az_cfg.resource_group

        # Step 1: delete VM (must complete before NIC can be deleted)
        poller = compute_client.virtual_machines.begin_delete(rg, vm_name)
        await asyncio.wait_for(
            loop.run_in_executor(None, lambda: poller.result()),
            timeout=90.0,
        )
        logger.info(f"[Broker] Azure VM {vm_name} confirmed deleted")

        # Step 2: delete associated network resources (NIC -> PIP -> VNet)
        # provision names these: {vm_name}-nic, {vm_name}-pip, {vm_name}-vnet
        _net_resources = [
            ("NIC",  lambda: network_client.network_interfaces.begin_delete(rg, f"{vm_name}-nic")),
            ("PIP",  lambda: network_client.public_ip_addresses.begin_delete(rg, f"{vm_name}-pip")),
            ("VNet", lambda: network_client.virtual_networks.begin_delete(rg, f"{vm_name}-vnet")),
        ]
        for _label, _begin in _net_resources:
            try:
                _poller = _begin()
                await asyncio.wait_for(
                    loop.run_in_executor(None, lambda p=_poller: p.result()),
                    timeout=60.0,
                )
                logger.info(f"[Broker] Azure {_label} for {vm_name} deleted")
            except Exception as _net_err:
                # Non-fatal: log and continue — VM is already gone, billing stops
                logger.warning(f"[Broker] Azure {_label} cleanup failed for {vm_name}: {_net_err}")
    except asyncio.TimeoutError:
        logger.warning(f"[Broker] Azure fence timed out for {instance_id} — proceeding")
    except Exception as e:
        logger.warning(f"[Broker] Azure fence failed for {instance_id} (proceeding): {e}")
