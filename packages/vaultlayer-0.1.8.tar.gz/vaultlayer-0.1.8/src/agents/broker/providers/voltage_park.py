"""Voltage Park provider -- provision + fence."""
from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Optional

import aiohttp

if TYPE_CHECKING:
    from shared.models import GPUType, Job

logger = logging.getLogger(__name__)


async def provision(broker, gpu_type: "GPUType", job: "Job") -> Optional[str]:
    """Provision a Voltage Park instant VM. Returns instance ID or None.

    Voltage Park API: https://cloud-api.voltagepark.com/api/v1
    Flow: GET /instant-deploy-presets/ -> pick cheapest available preset ->
          POST /virtual-machines/instant with preset_id, location_id, config_id
    """
    _cfg = broker._get_provider_config("voltage_park")
    if not _cfg:
        _managed = await broker._get_managed_credentials("voltage_park", job.job_id)
        if not _managed:
            job.last_provision_error = "Voltage Park: no credentials available"
            return None
        from types import SimpleNamespace
        _cfg = SimpleNamespace(api_key=_managed["api_key"])
    try:
        _vp_base = "https://cloud-api.voltagepark.com/api/v1"
        _vp_headers = {"Authorization": f"Bearer {_cfg.api_key}",
                       "Content-Type": "application/json"}
        vp_startup = broker._build_vm_startup_script(job)
        async with aiohttp.ClientSession() as session:
            # -- Find cheapest available preset ------------------------------------
            async with session.get(
                f"{_vp_base}/instant-deploy-presets/",
                headers=_vp_headers, timeout=aiohttp.ClientTimeout(total=10)
            ) as pr:
                if pr.status != 200:
                    _err = (await pr.text())[:200]
                    job.last_provision_error = f"Voltage Park: presets fetch HTTP {pr.status}"
                    logger.error(f"[Voltage Park] presets fetch {pr.status}: {_err}")
                    return None
                presets = await pr.json()

            available = [
                p for p in presets if p.get("location_ids_with_availability")
            ]
            if not available:
                job.last_provision_error = "Voltage Park: no instant VM presets available"
                logger.warning("[Voltage Park] No instant VM presets available (supply constraint)")
                return None
            # Pick cheapest by compute rate
            available.sort(key=lambda p: float(p.get("compute_rate_hourly", 9999)))
            preset = available[0]
            preset_id   = preset["id"]
            location_id = preset["location_ids_with_availability"][0]
            logger.info(f"[Voltage Park] Using preset {preset_id[:8]} @ ${preset['compute_rate_hourly']}/hr, location {location_id[:8]}")

            # -- Fetch config_id for this location ---------------------------------
            config_id = None
            async with session.get(
                f"{_vp_base}/virtual-machines/instant/locations/{location_id}",
                headers=_vp_headers, timeout=aiohttp.ClientTimeout(total=10)
            ) as lr:
                if lr.status == 200:
                    loc_data = await lr.json()
                    configs = loc_data.get("configs", loc_data.get("hardware_configs", []))
                    if configs:
                        config_id = configs[0].get("id")

            # -- POST /virtual-machines/instant ------------------------------------
            # config_id = preset_id (Voltage Park uses preset as config template)
            # organization_ssh_keys mode=all: inject all org SSH keys (must have >=1 registered
            # at dashboard.voltagepark.com -> SSH Keys before provisioning works)
            body: dict = {
                "preset_id":              preset_id,
                "location_id":            location_id,
                "config_id":              config_id or preset_id,
                "name":                   f"vl-{job.job_id[:8]}",
                "user_data":              vp_startup,
                "organization_ssh_keys":  {"mode": "all"},
            }

            async with session.post(
                f"{_vp_base}/virtual-machines/instant",
                headers=_vp_headers,
                json=body,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as r:
                if r.status not in (200, 201, 202):
                    _err = (await r.text())[:300]
                    job.last_provision_error = f"Voltage Park: HTTP {r.status} -- {_err[:150]}"
                    logger.error(f"[Voltage Park] provision {r.status}: {_err}")
                    return None
                data = await r.json()
                return str(data.get("id") or data.get("vm_id") or "")
    except Exception as e:
        job.last_provision_error = f"Voltage Park: {type(e).__name__}: {str(e)[:150]}"
        logger.error(f"Voltage Park provision error: {e}"); return None


async def hard_fence(broker, instance_id: str, job=None) -> None:
    """Terminate a Voltage Park virtual machine via API.

    Correct endpoint: DELETE /api/v1/virtual-machines/{id}
    (NOT /api/v1/instances/{id} -- that path does not exist in the Voltage Park API)
    """
    _cfg = broker._get_provider_config("voltage_park")
    if not _cfg:
        logger.warning(f"[Broker] Voltage Park config not found, skipping fence for {instance_id}")
        return
    _vp_base = getattr(_cfg, "base_url", "https://cloud-api.voltagepark.com/api/v1")
    try:
        async with aiohttp.ClientSession() as s:
            resp = await s.delete(
                f"{_vp_base}/virtual-machines/{instance_id}",
                headers={"Authorization": f"Bearer {_cfg.api_key}"},
                timeout=aiohttp.ClientTimeout(total=15),
            )
            if resp.status in (200, 202, 204):
                logger.info(f"[Broker] Voltage Park VM {instance_id} terminated (status={resp.status})")
            else:
                body = await resp.text()
                logger.warning(f"[Broker] Voltage Park fence returned {resp.status}: {body[:200]}")
    except Exception as e:
        logger.warning(f"[Broker] Voltage Park fence failed for {instance_id} (proceeding): {e}")
