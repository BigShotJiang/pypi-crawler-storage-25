"""AWS provider — provision + fence."""
from __future__ import annotations

import asyncio
import base64
import logging
import os
import shlex
import time
from typing import TYPE_CHECKING, Optional

import boto3

if TYPE_CHECKING:
    from shared.models import GPUType, Job

from shared.models import GPUType
from shared.retry import sync_retry
from shared.idempotency import provision_idempotency_key
from agents.broker.providers import aws_capacity

logger = logging.getLogger(__name__)

MANAGED_TAG = {"Key": "Project", "Value": "VaultLayer-Managed"}

AWS_INSTANCE_MAP = {
    GPUType.H100_80GB_SXM: "p4de.24xlarge",
    GPUType.A100_80GB_SXM: "p4d.24xlarge",
    GPUType.A100_40GB:     "p4d.24xlarge",
    GPUType.A10G:          "g5.xlarge",
    GPUType.V100_16GB:     "p3.2xlarge",   # 8 vCPU, 1× V100-16GB — fits 8 vCPU P-Spot quota (us-east-2)
}

# ---------------------------------------------------------------------------
# Level 2 cold-start fix: Pre-baked AMIs
# ---------------------------------------------------------------------------
PREBAKED_AMI_MAP: dict[str, dict[str, str]] = {
    "pytorch/pytorch:2.1": {
        "us-east-1":      "ami-vl-pytorch21-cuda121-use1",
        "us-west-2":      "ami-vl-pytorch21-cuda121-usw2",
        "eu-west-1":      "ami-vl-pytorch21-cuda121-euw1",
    },
    "nvcr.io/nvidia/pytorch:23.10": {
        "us-east-1":      "ami-vl-ngc2310-use1",
        "us-west-2":      "ami-vl-ngc2310-usw2",
    },
}


def _get_attempt_num(job) -> int:
    """Return the 1-indexed current attempt number for IDEM-1 ClientToken.

    `job` can be either a Pydantic Job model (attribute access) or a dict
    (some worker paths serialize before calling provision_*). Duck-type
    both without importing the Job model here.

    The counter is len(_provision_attempts) + 1 — after the broker
    records the result of this attempt, subsequent calls auto-advance.
    On a broker-crash mid-provision, the list hasn't grown, so the same
    attempt number (and thus same ClientToken) is used on recovery —
    which is exactly what we want for AWS-side dedup.
    """
    attempts = None
    if isinstance(job, dict):
        attempts = job.get("_provision_attempts")
    else:
        attempts = getattr(job, "_provision_attempts", None)
    return len(attempts or []) + 1


class RegionNotAllowedError(Exception):
    """Raised when a target region violates the job's allowed/blocked_regions constraint."""


def _find_prebaked_ami(docker_image: str, region: str) -> Optional[str]:
    """Return a pre-baked AMI ID if the docker_image matches a known cached image
    in the given region.  Returns None if no pre-baked AMI is available."""
    if not docker_image:
        return None
    for image_key, region_map in PREBAKED_AMI_MAP.items():
        if image_key in docker_image:
            ami = region_map.get(region)
            if ami and not ami.startswith("ami-vl-"):   # skip placeholder IDs
                return ami
    return None


def _check_region_allowed(region: str, job: "Job") -> None:
    """Raise RegionNotAllowedError if region violates job's compliance constraints.

    Enforcement order: excluded_regions takes priority, then regions whitelist.
    Empty regions list = no whitelist restriction (any region passes).
    """
    if job.excluded_regions and region in job.excluded_regions:
        raise RegionNotAllowedError(
            f"Region '{region}' is excluded for job {job.job_id} "
            f"(excluded_regions={job.excluded_regions})"
        )
    if job.regions and region not in job.regions:
        raise RegionNotAllowedError(
            f"Region '{region}' is not in allowed regions for job {job.job_id} "
            f"(regions={job.regions})"
        )


def _resolve_target_region(broker, job: "Job") -> str:
    """Return the optimal AWS region for spot provisioning.

    Rule 2 — Read-Only Region Pinning:
    When the job's dataset lives in an S3 bucket, pinning the replacement
    spot instance to the SAME AWS region as the bucket eliminates all
    internet egress charges ($0.09/GB).  The remaining Cross-AZ fee ($0.01/GB)
    is further eliminated by the VPC Gateway Endpoint (Rule 1).

    Priority:
      1. Job's dataset_region (set from the S3 bucket region at job creation)
      2. Configured default region (broker.config.aws.region)
    """
    dataset_region = getattr(job, "dataset_region", "") or ""
    if dataset_region and dataset_region.startswith("us-") or dataset_region.startswith("eu-") or \
            dataset_region.startswith("ap-") or dataset_region.startswith("ca-") or \
            dataset_region.startswith("sa-") or dataset_region.startswith("af-") or \
            dataset_region.startswith("me-"):
        # dataset_region is a valid AWS region — pin to it
        logger.info(
            f"[Broker] Region pinning: targeting {dataset_region} (S3 bucket region) "
            f"for job {job.job_id} to eliminate egress costs"
        )
        return dataset_region
    if broker.config.aws:
        return broker.config.aws.region
    return os.environ.get("AWS_DEFAULT_REGION", "us-west-2")


def _ensure_vpc_s3_gateway_endpoint(ec2, region: str, job_id: str) -> bool:
    """Create (or confirm) an S3 VPC Gateway Endpoint in the target VPC.

    Rule 1 — VPC Gateway Endpoint:
    A Gateway Endpoint routes all EC2->S3 traffic through AWS's private network,
    bypassing the NAT gateway and eliminating Cross-AZ data transfer charges.
    The endpoint itself is FREE (no hourly cost, no per-GB charge).

    Cost impact: 5 TB dataset x $0.01/GB Cross-AZ = $50 eliminated per job.
    For a 1,000-job/month platform: $50,000/month in user savings restored.

    Returns True if an endpoint was found or created, False on error.
    """
    try:
        # Find the default VPC
        vpcs = ec2.describe_vpcs(Filters=[{"Name": "isDefault", "Values": ["true"]}])
        if not vpcs["Vpcs"]:
            logger.warning(f"[Broker] No default VPC found in {region} — skipping Gateway Endpoint")
            return False
        vpc_id = vpcs["Vpcs"][0]["VpcId"]

        # Check if an S3 Gateway Endpoint already exists
        service_name = f"com.amazonaws.{region}.s3"
        existing = ec2.describe_vpc_endpoints(
            Filters=[
                {"Name": "vpc-id", "Values": [vpc_id]},
                {"Name": "service-name", "Values": [service_name]},
                {"Name": "vpc-endpoint-type", "Values": ["Gateway"]},
                {"Name": "vpc-endpoint-state", "Values": ["available", "pending"]},
            ]
        )
        if existing.get("VpcEndpoints"):
            logger.info(
                f"[Broker] S3 Gateway Endpoint already exists in {vpc_id} ({region}) — "
                "Cross-AZ S3 charges eliminated"
            )
            return True

        # Get all route tables in this VPC (endpoint must be associated with them)
        rts = ec2.describe_route_tables(
            Filters=[{"Name": "vpc-id", "Values": [vpc_id]}]
        )
        route_table_ids = [rt["RouteTableId"] for rt in rts.get("RouteTables", [])]

        # Create the Gateway Endpoint (free — no hourly or per-GB charge)
        ec2.create_vpc_endpoint(
            VpcEndpointType="Gateway",
            VpcId=vpc_id,
            ServiceName=service_name,
            RouteTableIds=route_table_ids,
            TagSpecifications=[{
                "ResourceType": "vpc-endpoint",
                "Tags": [
                    MANAGED_TAG,
                    {"Key": "VaultLayerJob", "Value": job_id},
                    {"Key": "Purpose", "Value": "S3-free-egress"},
                ],
            }],
        )
        logger.info(
            f"[Broker] Created S3 VPC Gateway Endpoint in {vpc_id} ({region}). "
            f"S3<->EC2 traffic is now free (Cross-AZ $0.01/GB charge eliminated). "
            f"Route tables updated: {route_table_ids}"
        )
        return True

    except Exception as e:
        # Non-fatal: job still runs, just with potential Cross-AZ charges
        logger.warning(
            f"[Broker] VPC S3 Gateway Endpoint creation failed (non-fatal, "
            f"Cross-AZ charges may apply at $0.01/GB): {e}"
        )
        return False


def _create_launch_template(broker, ec2, job: "Job", gpu_type: "GPUType", region: str) -> str:
    """Create a dynamic EC2 Launch Template for this job. Returns template name."""
    instance_type = AWS_INSTANCE_MAP.get(gpu_type, "p4d.24xlarge")
    template_name = f"vl-{job.job_id[:8]}-{gpu_type.value[:12]}"

    # Level 2 cold-start fix: use pre-baked AMI when available (eliminates docker pull)
    prebaked_ami = _find_prebaked_ami(job.docker_image or "", region) if job.docker_image else None
    if prebaked_ami:
        base_ami = prebaked_ami
        logger.info(f"Cold-start: using pre-baked AMI {prebaked_ami} for {job.docker_image!r}")
    else:
        # Dynamically resolve the latest Ubuntu 22.04 LTS AMI via ec2:DescribeImages
        # (Canonical owner 099720109477). Uses the same ec2 client already created for
        # this provision call — no extra boto3 client, no extra IAM permissions needed
        # beyond what run_instances already requires. SSM removed (needs ssm:GetParameter).
        try:
            _res = ec2.describe_images(
                Owners=["099720109477"],  # Canonical official Ubuntu AMIs
                Filters=[
                    {"Name": "name",         "Values": ["ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-*"]},
                    {"Name": "state",        "Values": ["available"]},
                    {"Name": "architecture", "Values": ["x86_64"]},
                ],
            )
            _imgs = sorted(_res["Images"], key=lambda x: x["CreationDate"], reverse=True)
            if not _imgs:
                raise ValueError("No Ubuntu 22.04 AMIs found in region")
            base_ami = _imgs[0]["ImageId"]
            logger.info(f"[AWS] Resolved Ubuntu 22.04 AMI via ec2:describe_images: {base_ami} ({region})")
        except Exception as _ami_err:
            # Last resort: check for manually-overridden AMI in Railway/env
            # Set VL_AWS_AMI_ID=ami-xxxxx in Railway as override if needed.
            base_ami = os.environ.get("VL_AWS_AMI_ID", "")
            if base_ami:
                logger.warning(f"[AWS] AMI lookup failed ({_ami_err}), using VL_AWS_AMI_ID={base_ami}")
            else:
                logger.error(
                    f"[AWS] Cannot resolve AMI for region {region} ({_ami_err}). "
                    "Set VL_AWS_AMI_ID=ami-xxxxx in Railway or grant ec2:DescribeImages."
                )
                return None
    # IamInstanceProfile is optional — only include if VL_AWS_INSTANCE_PROFILE is set.
    # Avoids InvalidParameterValue when the profile doesn't exist in the account.
    _instance_profile = os.environ.get("VL_AWS_INSTANCE_PROFILE", "")
    # Ensure key pair exists in this region — auto-create if missing
    _key_name = f"vaultlayer-{region}"
    try:
        ec2.describe_key_pairs(KeyNames=[_key_name])
    except Exception:
        try:
            _kp = ec2.create_key_pair(KeyName=_key_name)
            _key_dir = os.path.expanduser("~/.vaultlayer/keys")
            os.makedirs(_key_dir, mode=0o700, exist_ok=True)
            _pem_path = os.path.join(_key_dir, f"{_key_name}.pem")
            with open(_pem_path, "w") as _f:
                _f.write(_kp["KeyMaterial"])
            os.chmod(_pem_path, 0o600)
            logger.info(f"[AWS] Key pair '{_key_name}' created and saved to {_pem_path}")
        except Exception as _kp_err:
            logger.warning(f"[AWS] Key pair auto-create failed ({_kp_err}) — provisioning without SSH key")
            _key_name = ""
    # Use the shared VM startup builder (same path as Lambda / GCP / Crusoe).
    # The legacy broker._build_userdata() had `set -e` (fragile bootstrap),
    # no heartbeat (stuck detector kills instance after 20 min of 0 logs),
    # and never decoded/ran VL_SCRIPT_B64 (so the user's command never
    # executed on AWS). build_vm_startup_script() handles all three
    # correctly. base64-encode per the provider_startup registry's
    # ScriptEncoding.BASE64 contract for AWS UserData.
    _vm_script = broker._build_vm_startup_script(job)
    _launch_template_data: dict = {
        "ImageId": base_ami,
        "InstanceType": instance_type,
        "UserData": base64.b64encode(_vm_script.encode()).decode(),
    }
    if _key_name:
        _launch_template_data["KeyName"] = _key_name
    if _instance_profile:
        _launch_template_data["IamInstanceProfile"] = {"Name": _instance_profile}

    ec2.create_launch_template(
        LaunchTemplateName=template_name,
        LaunchTemplateData={
            **_launch_template_data,
            "TagSpecifications": [{
                "ResourceType": "instance",
                "Tags": [
                    MANAGED_TAG,
                    {"Key": "VaultLayerJob", "Value": job.job_id},
                    {"Key": "VaultLayerName", "Value": job.name},
                ],
            }],
        },
        TagSpecifications=[{
            "ResourceType": "launch-template",
            "Tags": [
                MANAGED_TAG,
                {"Key": "VaultLayerJob", "Value": job.job_id},
            ],
        }],
    )
    logger.info(f"Launch template created: {template_name}")
    return template_name


async def provision(broker, gpu_type: "GPUType", job: "Job",
                    preferred_az: Optional[str] = None) -> Optional[str]:
    """Provision an AWS EC2 Spot instance using Launch Template + STS credentials.

    Uses run_instances() with InstanceMarketOptions (modern API) instead of
    request_spot_instances() for Launch Template support.

    Cost optimisations applied automatically:
      1. Region pinning: spots land in the same region as the S3 dataset bucket
         (eliminates $0.09/GB internet egress)
      2. VPC S3 Gateway Endpoint: eliminates $0.01/GB Cross-AZ fee on S3 reads

    Args:
        preferred_az: If set, requests spot capacity in this specific AZ
                      (e.g. "us-east-1b"). Used by same-provider retry logic
                      to stay in the same region after a spot interruption.
    """
    primary_region = _resolve_target_region(broker, job)
    _check_region_allowed(primary_region, job)

    # Region fallback order: primary first, then alternates ordered by spot
    # availability. The prior gate (BYOC → single region, managed-only →
    # fallback) treated any env-populated config.aws as "user wants to stay
    # pinned." On Railway that's wrong — config.aws is populated from
    # managed AWS env vars, not from a user's compliance requirement, so
    # single g5.xlarge smoke kept failing on us-east-2
    # InsufficientInstanceCapacity even though us-east-1 / us-west-2 had
    # ample spot supply (confirmed via describe_spot_price_history).
    #
    # New gate: cross-region capacity fallback is ON by default. Users who
    # actually need region-pinning (data-residency or compliance) set
    # VL_AWS_REGION_LOCKED=1 in their BYOC config; that disables fallback
    # and fails fast if the requested region has no capacity. Keeps the
    # ability to region-pin while defaulting to the behavior that matches
    # VaultLayer's arbitrage model: "find capacity, prefer cheapest."
    _FALLBACK_REGIONS = ["us-west-2", "us-east-1", "us-east-2", "eu-west-1", "ap-southeast-1"]
    _region_locked = os.environ.get("VL_AWS_REGION_LOCKED", "").lower() in ("1", "true", "yes")

    # Signals that mean "no capacity/quota here, try next region"
    _RETRY_ERRORS = (
        "InsufficientInstanceCapacity",
        "SpotMaxPriceTooLow",
        "InvalidParameterCombination",  # Free Tier / billing restriction
        "RequestLimitExceeded",
        "Unsupported",                  # instance type not available in region
        "MaxSpotInstanceCountExceeded", # per-region spot limit hit — try a different region
        "VcpuLimitExceeded",            # per-region vCPU limit hit — try a different region
        "InstanceLimitExceeded",        # per-region on-demand limit — try a different region
    )

    # Fetch managed creds once (valid across all regions)
    _aws_creds: Optional[dict] = None
    if not broker.config.aws:
        _aws_creds = await broker._get_managed_credentials("aws", job.job_id)
        if not _aws_creds:
            job.last_provision_error = "AWS: no BYOC config and managed credentials unavailable"
            logger.error("[AWS] No BYOC config and managed credentials unavailable")
            return None

    # Factory so aws_capacity can open clients lazily (one per region-we-consider)
    def _ec2_for_region(region: str):
        if broker.config.aws:
            return broker._sts.get_ec2_client(job_id=job.job_id, region=region)
        return boto3.client(
            "ec2", region_name=region,
            aws_access_key_id=_aws_creds["access_key_id"],
            aws_secret_access_key=_aws_creds["secret_access_key"],
        )

    if _region_locked:
        regions_to_try = [primary_region]
        dropped: list[str] = []
        logger.info(f"[AWS] VL_AWS_REGION_LOCKED=1 — single-region provision on {primary_region}")
    else:
        # Dynamic, capacity-aware ordering:
        #   * Skip regions that don't offer this instance type (avoids Unsupported)
        #   * Skip regions in cooldown from a recent quota/capacity failure
        #   * Order remainder by cheapest current spot price
        #   * Honor primary_region pin when it survives filtering
        instance_type = AWS_INSTANCE_MAP.get(gpu_type, "p4d.24xlarge")
        candidate = [primary_region] + [r for r in _FALLBACK_REGIONS if r != primary_region]
        regions_to_try, dropped = aws_capacity.rank_regions(
            candidate_regions=candidate,
            instance_type=instance_type,
            ec2_factory=_ec2_for_region,
            primary_region=primary_region,
        )
        if dropped:
            logger.info(f"[AWS] skipped regions (not offered / unreachable): {dropped}")
        if not regions_to_try:
            job.last_provision_error = (
                f"AWS: no region offers {instance_type} "
                f"(checked {candidate}; dropped {dropped})"
            )
            logger.error(job.last_provision_error)
            return None
        logger.info(
            f"[AWS] provision ordering for {instance_type}: {regions_to_try} "
            f"(primary={primary_region})"
        )

    per_region_errors: list[str] = []
    for region in regions_to_try:
        template_name = None
        ec2 = None
        try:
            if broker.config.aws:
                ec2 = broker._sts.get_ec2_client(job_id=job.job_id, region=region)
            else:
                ec2 = boto3.client(
                    "ec2", region_name=region,
                    aws_access_key_id=_aws_creds["access_key_id"],
                    aws_secret_access_key=_aws_creds["secret_access_key"],
                )

            # Rule 1: Ensure VPC S3 Gateway Endpoint exists to eliminate Cross-AZ charges.
            dataset_in_s3 = getattr(job, "dataset_location", "") in ("s3", "") or \
                            getattr(job, "dataset_region", "") != ""
            if dataset_in_s3:
                _ensure_vpc_s3_gateway_endpoint(ec2, region, job.job_id)

            template_name = _create_launch_template(broker, ec2, job, gpu_type, region)
            if not template_name:
                logger.warning(f"[AWS] Launch template creation failed in {region}, trying next region")
                continue

            # IDEM-1: ClientToken gives AWS idempotency. Same job_id +
            # same attempt → same token → AWS returns the cached response
            # if broker crashes mid-request. Advance attempt on intentional
            # re-provisions (len(_provision_attempts)+1 grows per attempt).
            # Region is part of the token so retries across regions get a
            # fresh request (regions use different endpoints anyway).
            _attempt_num = _get_attempt_num(job)
            _client_token = provision_idempotency_key(
                f"{job.job_id}:aws-spot:{region}", _attempt_num
            )
            try:
                _spot_kwargs = dict(
                    ClientToken=_client_token,
                    MinCount=1,
                    MaxCount=1,
                    LaunchTemplate={"LaunchTemplateName": template_name, "Version": "$Latest"},
                    InstanceMarketOptions={
                        "MarketType": "spot",
                        "SpotOptions": {"SpotInstanceType": "one-time"},
                    },
                    TagSpecifications=[{
                        "ResourceType": "instance",
                        "Tags": [
                            MANAGED_TAG,
                            {"Key": "VaultLayerJob", "Value": job.job_id},
                            {"Key": "VaultLayerName", "Value": job.name},
                        ],
                    }],
                )
                if preferred_az and preferred_az.startswith(region):
                    _spot_kwargs["Placement"] = {"AvailabilityZone": preferred_az}
                response = sync_retry(
                    lambda: ec2.run_instances(**_spot_kwargs),
                    label="ec2.run_instances(spot)",
                )
            finally:
                try:
                    ec2.delete_launch_template(LaunchTemplateName=template_name)
                except Exception:
                    pass

            instance_id = response["Instances"][0]["InstanceId"]
            logger.info(f"AWS EC2 Spot instance {instance_id} launched in {region} for job {job.job_id}")

            # Poll until running (up to 3 min)
            for _ in range(36):
                await asyncio.sleep(5)
                desc = ec2.describe_instances(InstanceIds=[instance_id])
                state = desc["Reservations"][0]["Instances"][0]["State"]["Name"]
                if state == "running":
                    logger.info(f"AWS EC2 instance {instance_id} is running")
                    return instance_id
                if state in ("terminated", "shutting-down"):
                    job.last_provision_error = f"AWS: instance {instance_id} entered {state} during startup"
                    logger.error(f"AWS instance {instance_id} entered {state}")
                    return None

            job.last_provision_error = f"AWS: instance timed out waiting for running state in {region}"
            logger.error(f"AWS Spot instance timed out waiting for running state in {region}")
            return None

        except Exception as e:
            err_str = str(e)
            # Extract the AWS error code for concise per-region tracking
            _code = "Error"
            for sig in _RETRY_ERRORS + ("AccessDenied", "OptInRequired", "AuthFailure"):
                if sig in err_str:
                    _code = sig
                    break
            per_region_errors.append(f"{region}:{_code}")
            # Apply cooldown so the next job skips this region for a while
            aws_capacity.record_failure(region, _code)
            _is_retryable = any(sig in err_str for sig in _RETRY_ERRORS)
            if _is_retryable:
                # Retryable: try next region if any, otherwise fall through
                # to post-loop OD fallback (don't return None here — that
                # short-circuits the on-demand path).
                if region != regions_to_try[-1]:
                    logger.warning(f"[AWS] {region} unavailable ({err_str[:80]}), trying next region")
                    continue
                logger.warning(
                    f"[AWS] {region} (last region) unavailable ({err_str[:80]}), "
                    f"falling through to OD check"
                )
                break
            # Non-retryable error (AccessDenied, AuthFailure, etc.) — hard-stop.
            job.last_provision_error = (
                f"AWS: {type(e).__name__} in {region}: {str(e)[:120]} "
                f"[regions tried: {', '.join(per_region_errors)}]"
            )
            # Surface auth/billing failures with a specific code so the runner
            # and dashboard can distinguish them from capacity issues.
            _billing_signals = ("AuthFailure", "AccessDenied", "OptInRequired",
                                "Unauthorized", "InvalidClientTokenId", "AccountSuspended")
            if any(sig in err_str for sig in _billing_signals):
                from shared.failure_codes import JobFailureCode
                job.failure_code = JobFailureCode.PROV_MANAGED_BALANCE.value
                job.failure_detail = (
                    f"AWS managed credentials rejected ({_code}) in {region}. "
                    "Check IAM permissions or billing status."
                )[:500]
                logger.error(f"AWS MANAGED CREDENTIALS FAILURE ({_code}) in {region}: {e}")
            else:
                logger.error(f"AWS provision error in {region}: {e}")
            return None

    # Spot exhausted across all candidate regions.
    #
    # Goal (per product brief): find GPUs for the user, period. Spot is the
    # preferred cost-optimized path, but when the market is dry we fall
    # through to On-Demand rather than return a failed job. This is the
    # same guarantee failover uses mid-run; we extend it to initial provision.
    #
    # On-Demand is gated by VL_AWS_OD_FALLBACK_ENABLED (default true). Set
    # to "false" for users who explicitly opt out of price-non-optimized
    # capacity. The OD instance is tagged VaultLayerFallback=on_demand_last_resort
    # so FinOps skips gainshare markup for the leg (user pays raw OD price).
    _od_enabled = os.getenv("VL_AWS_OD_FALLBACK_ENABLED", "true").lower() in ("true", "1", "yes")
    if _od_enabled:
        logger.warning(
            f"[AWS] spot exhausted across {per_region_errors} — "
            f"falling through to On-Demand for job {job.job_id}"
        )
        # Reuse the same region list so OD tries wherever the user has
        # presence; cooldowns apply across spot+OD since a MaxSpot in
        # us-east-2 doesn't imply OD is unavailable there (different quota).
        od_instance = await provision_on_demand(
            broker, gpu_type, job,
            regions_hint=regions_to_try,
            ec2_factory=_ec2_for_region,
        )
        if od_instance:
            # Tag job so FinOps skips gainshare markup on this leg
            job.__dict__["fallback_reason"] = "aws_od_last_resort"
            return od_instance
        # OD also failed — preserve its detailed error in last_provision_error
        # so the dashboard shows BOTH spot + OD breakdowns, not a generic
        # "fallback unavailable" that hides the real OD quota/capacity issue.
        _od_error = (getattr(job, "last_provision_error", "") or "").replace("AWS OD: ", "")
        job.last_provision_error = (
            f"AWS: spot exhausted [{', '.join(per_region_errors)}] "
            f"→ OD fallback also failed: {_od_error}"
        )
        # Lifecycle Gate: tag as capacity exhaustion so migration logic
        # retries against a different provider instead of same-AWS churn.
        from shared.failure_codes import JobFailureCode
        job.failure_code = JobFailureCode.PROV_NO_CAPACITY.value
        job.failure_detail = (
            f"AWS spot exhausted across {', '.join(per_region_errors)[:200]}; "
            f"OD fallback also failed: {_od_error[:150]}"
        )[:500]
        logger.error(
            f"[AWS] Job {job.job_id} failed: spot={per_region_errors}, OD={_od_error}"
        )
        return None

    job.last_provision_error = (
        f"AWS: all regions exhausted [{', '.join(per_region_errors)}] "
        f"(OD fallback disabled via VL_AWS_OD_FALLBACK_ENABLED=false)"
    )
    logger.error(f"[AWS] All regions exhausted for job {job.job_id}: {per_region_errors}")
    return None


async def provision_on_demand(
    broker,
    gpu_type: "GPUType",
    job: "Job",
    regions_hint: Optional[list[str]] = None,
    ec2_factory=None,
) -> Optional[str]:
    """
    Provision an AWS EC2 On-Demand instance — guaranteed capacity.

    Used as:
      1. Initial-provision fallback when spot is exhausted (called from
         provision() above; spot is always preferred for cost).
      2. Mid-run migration last-resort (called from migration.py when
         every spot provider across the multicloud pool is dry).

    Identical to provision() except no InstanceMarketOptions, so AWS
    delivers On-Demand capacity (no interruption risk, full OD price).
    Tagged VaultLayerFallback=on_demand_last_resort so FinOps knows
    this leg is not subject to gainshare markup.

    Args:
      regions_hint: Ordered region list from the spot attempt. If None,
        we build our own (same logic as provision()).
      ec2_factory: Callable(region) -> ec2 client, also from the spot
        attempt. If None, we build our own.
    """
    if os.getenv("VL_AWS_OD_FALLBACK_ENABLED", "true").lower() not in ("true", "1", "yes"):
        logger.info("AWS On-Demand fallback disabled (VL_AWS_OD_FALLBACK_ENABLED=false)")
        return None

    # Build our own factory / regions if the caller didn't share them
    # (migration path doesn't).
    if ec2_factory is None:
        _aws_creds: Optional[dict] = None
        if not broker.config.aws:
            _aws_creds = await broker._get_managed_credentials("aws", job.job_id)
            if not _aws_creds:
                job.last_provision_error = "AWS OD: no BYOC config and managed credentials unavailable"
                logger.error("[AWS OD] No BYOC config and managed credentials unavailable")
                return None
        def _ec2_for_region(region: str):
            if broker.config.aws:
                return broker._sts.get_ec2_client(job_id=job.job_id, region=region)
            return boto3.client(
                "ec2", region_name=region,
                aws_access_key_id=_aws_creds["access_key_id"],
                aws_secret_access_key=_aws_creds["secret_access_key"],
            )
        ec2_factory = _ec2_for_region

    if regions_hint is None:
        primary_region = _resolve_target_region(broker, job)
        instance_type = AWS_INSTANCE_MAP.get(gpu_type, "p4d.24xlarge")
        _FALLBACK = ["us-west-2", "us-east-1", "us-east-2", "eu-west-1", "ap-southeast-1"]
        candidates = [primary_region] + [r for r in _FALLBACK if r != primary_region]
        regions_hint, _dropped = aws_capacity.rank_regions(
            candidate_regions=candidates,
            instance_type=instance_type,
            ec2_factory=ec2_factory,
            primary_region=primary_region,
        )
        if not regions_hint:
            job.last_provision_error = f"AWS OD: no region offers {instance_type}"
            return None

    # Error codes that mean "try another region" (quota / capacity / not offered).
    # OD-specific: VcpuLimitExceeded and InstanceLimitExceeded are what OD
    # quotas throw (Spot uses MaxSpotInstanceCountExceeded); share the same
    # fallback behavior.
    _OD_RETRY_ERRORS = (
        "InsufficientInstanceCapacity",
        "VcpuLimitExceeded",
        "InstanceLimitExceeded",
        "RequestLimitExceeded",
        "Unsupported",
        "InvalidParameterCombination",
    )

    per_region_errors: list[str] = []
    for region in regions_hint:
        try:
            _check_region_allowed(region, job)
        except RegionNotAllowedError as e:
            per_region_errors.append(f"{region}:RegionBlocked")
            logger.warning(f"[AWS OD] {region}: {e}")
            continue

        ec2 = None
        template_name = None
        try:
            ec2 = ec2_factory(region)

            # Rule 1: VPC S3 Gateway Endpoint (same as spot path — same savings)
            dataset_in_s3 = getattr(job, "dataset_location", "") in ("s3", "") or \
                            getattr(job, "dataset_region", "") != ""
            if dataset_in_s3:
                _ensure_vpc_s3_gateway_endpoint(ec2, region, job.job_id)

            template_name = _create_launch_template(broker, ec2, job, gpu_type, region)
            if not template_name:
                per_region_errors.append(f"{region}:LaunchTemplateFailed")
                continue

            # IDEM-1: ClientToken for the OD path. Namespace is "aws-od" so
            # a Spot attempt and its OD fallback never share a token (they
            # produce different market-type instances).
            _attempt_num = _get_attempt_num(job)
            _client_token = provision_idempotency_key(
                f"{job.job_id}:aws-od:{region}", _attempt_num
            )
            try:
                _od_kwargs = dict(
                    ClientToken=_client_token,
                    MinCount=1,
                    MaxCount=1,
                    LaunchTemplate={"LaunchTemplateName": template_name, "Version": "$Latest"},
                    # No InstanceMarketOptions -> guaranteed On-Demand capacity
                    TagSpecifications=[{
                        "ResourceType": "instance",
                        "Tags": [
                            MANAGED_TAG,
                            {"Key": "VaultLayerJob",      "Value": job.job_id},
                            {"Key": "VaultLayerName",     "Value": job.name},
                            {"Key": "VaultLayerFallback", "Value": "on_demand_last_resort"},
                        ],
                    }],
                )
                response = sync_retry(
                    lambda: ec2.run_instances(**_od_kwargs),
                    label="ec2.run_instances(on_demand)",
                )
            finally:
                try:
                    ec2.delete_launch_template(LaunchTemplateName=template_name)
                except Exception:
                    pass

            instance_id = response["Instances"][0]["InstanceId"]
            logger.warning(
                f"[AWS OD] instance {instance_id} launched in {region} for job {job.job_id} "
                f"(no gainshare — full OD price applies)"
            )

            for _ in range(36):
                await asyncio.sleep(5)
                desc = ec2.describe_instances(InstanceIds=[instance_id])
                state = desc["Reservations"][0]["Instances"][0]["State"]["Name"]
                if state == "running":
                    return instance_id
                if state in ("terminated", "shutting-down"):
                    job.last_provision_error = f"AWS OD: instance {instance_id} entered {state}"
                    return None

            job.last_provision_error = f"AWS OD: instance timed out in {region}"
            return None

        except Exception as e:
            err_str = str(e)
            _code = "Error"
            for sig in _OD_RETRY_ERRORS + ("AccessDenied", "OptInRequired", "AuthFailure"):
                if sig in err_str:
                    _code = sig
                    break
            per_region_errors.append(f"{region}:{_code}")
            aws_capacity.record_failure(region, _code)
            if any(sig in err_str for sig in _OD_RETRY_ERRORS) and region != regions_hint[-1]:
                logger.warning(f"[AWS OD] {region} unavailable ({err_str[:80]}), trying next region")
                continue
            job.last_provision_error = (
                f"AWS OD: {type(e).__name__} in {region}: {str(e)[:120]} "
                f"[OD regions tried: {', '.join(per_region_errors)}]"
            )
            logger.error(f"[AWS OD] provision error in {region}: {e}")
            return None

    job.last_provision_error = (
        f"AWS OD: all regions exhausted [{', '.join(per_region_errors)}]"
    )
    logger.error(f"[AWS OD] all regions exhausted for job {job.job_id}: {per_region_errors}")
    return None


async def hard_fence(broker, instance_id: str, job=None,
                     _phase1_seconds: int = 60,
                     _phase2_seconds: int = 120) -> None:
    """Terminate an AWS EC2 instance via API and poll until terminated.

    Raises on non-recoverable failure so the caller can record that
    termination_confirmed=False and schedule a zombie sweep. Previously
    this swallowed errors silently, letting the DB claim success while
    the instance kept running (and billing).
    """
    # Resolve region. BYOC path has broker.config.aws.region; managed
    # (Railway) path relies on env var (AWS_DEFAULT_REGION). Fall back
    # to the region shipped in the job object when neither is set.
    region = ""
    if getattr(broker.config, "aws", None):
        region = broker.config.aws.region or ""
    if not region:
        region = os.environ.get("AWS_DEFAULT_REGION") or os.environ.get("AWS_REGION") or ""
    if not region and job is not None:
        region = getattr(job, "region", "") or ""
    if not region:
        raise RuntimeError(
            f"AWS hard_fence: cannot resolve region for {instance_id}. "
            f"Set AWS_DEFAULT_REGION or provide job.region."
        )

    # STS session job_id is only used for audit labelling; a stable fallback
    # is fine when we don't have a job context (e.g. CLI cleanup).
    _job_label = getattr(job, "job_id", None) or f"fence-{instance_id}"
    try:
        ec2 = broker._sts.get_ec2_client(job_id=_job_label, region=region)
    except Exception:
        # Managed path: no STS configured — use plain boto3 with managed creds.
        # We don't have access to the R2/credential server here, but if the
        # worker was able to PROVISION the instance, boto3 config already
        # has the keys via env vars. Create a plain client.
        ec2 = boto3.client("ec2", region_name=region)

    # ── Terminate with retry on transient errors ────────────────────────
    # Previously we issued a single terminate_instances call; any
    # transient RequestLimitExceeded / network blip would leave the
    # instance running and the caller just logged _termination_confirmed=
    # False without retrying. Leaked instance i-0889b5a0214be229f on
    # 2026-04-20 ran ~17 hours before manual sweep caught it.
    #
    # sync_retry handles transient-class errors (timeouts, throttling,
    # 5xx) with exponential backoff. NotFound is treated as success —
    # the instance is already gone.
    def _terminate_once():
        ec2.terminate_instances(InstanceIds=[instance_id])

    try:
        sync_retry(_terminate_once, attempts=3, delays=(2, 5, 10),
                   label=f"ec2.terminate_instances({instance_id})")
    except Exception as e:
        err = str(e)
        if "InvalidInstanceID.NotFound" in err or "does not exist" in err:
            logger.info(f"[Broker] AWS instance {instance_id} already gone")
            return
        logger.error(f"[Broker] AWS terminate_instances FAILED for {instance_id} in {region}: {e}")
        raise

    # ── Phase 1: Wait 60s for state transition ──────────────────────────
    # Billing stops at "shutting-down" per AWS guidance, so we accept
    # either shutting-down or terminated as confirmation.
    async def _poll_until_stopped(budget_seconds: int) -> tuple[str, bool]:
        """Poll describe_instances until state ∈ {shutting-down, terminated}
        or budget exhausts. Returns (last_state, confirmed_stopped)."""
        deadline = time.monotonic() + budget_seconds
        poll_interval = 3
        last_state = "unknown"
        while time.monotonic() < deadline:
            await asyncio.sleep(poll_interval)
            try:
                desc = ec2.describe_instances(InstanceIds=[instance_id])
                reservations = desc.get("Reservations", [])
                if not reservations:
                    return ("gone", True)  # no longer visible — treat as terminated
                state = reservations[0]["Instances"][0]["State"]["Name"]
                last_state = state
                if state in ("terminated", "shutting-down"):
                    return (state, True)
            except Exception as e:
                err = str(e)
                if "InvalidInstanceID.NotFound" in err:
                    return ("not-found", True)
                logger.debug(f"[Broker] describe_instances polling error for {instance_id}: {e}")
                # Don't break — transient describe errors shouldn't abort the wait.
        return (last_state, False)

    state, stopped = await _poll_until_stopped(_phase1_seconds)
    if stopped:
        logger.info(f"[Broker] Instance {instance_id} confirmed terminated (state={state})")
        return

    # ── Phase 2: Re-issue terminate + poll another _phase2_seconds ────────
    # Sometimes the first terminate_instances call is lost (spot
    # instance mid-transition, EC2 control-plane hiccup). A second call
    # is cheap and usually succeeds.
    logger.warning(
        f"[Broker] Instance {instance_id} still {state!r} after 60s — "
        f"re-issuing terminate_instances"
    )
    try:
        sync_retry(_terminate_once, attempts=3, delays=(2, 5, 10),
                   label=f"ec2.terminate_instances({instance_id})[retry]")
    except Exception as e:
        err = str(e)
        if "InvalidInstanceID.NotFound" in err:
            logger.info(f"[Broker] AWS instance {instance_id} gone on retry")
            return

    state, stopped = await _poll_until_stopped(_phase2_seconds)
    if stopped:
        logger.info(
            f"[Broker] Instance {instance_id} confirmed terminated after retry "
            f"(state={state})"
        )
        return

    # Both phases exhausted. Total budget: ~3 min. Raise so the caller
    # knows termination was not confirmed and can escalate (alert, sweep
    # job, etc). Billing may still be live.
    raise RuntimeError(
        f"AWS termination NOT confirmed for {instance_id} in {region} "
        f"after 2 terminate attempts + 180s polling (last state={state!r}). "
        f"Instance may still be running — escalate for manual sweep."
    )
