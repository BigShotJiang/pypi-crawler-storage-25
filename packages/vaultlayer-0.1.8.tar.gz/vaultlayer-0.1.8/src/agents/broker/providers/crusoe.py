"""Crusoe Cloud provider -- provision + fence."""
from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Optional

import aiohttp

if TYPE_CHECKING:
    from shared.models import GPUType, Job

logger = logging.getLogger(__name__)


def _auth_headers(api_key_id: str, api_secret: str, http_path: str,
                  http_verb: str, query_params: str = "") -> dict:
    """Build Crusoe Cloud HMAC-SHA256 signed Bearer auth headers.

    Source: https://docs.crusoecloud.com/reference/authentication/

    Exact format (from official docs):
      payload = http_path + "\\n" + canonicalized_query_params + "\\n"
                + HTTP_VERB + "\\n" + timestamp + "\\n"   <- trailing newline
      key     = base64url_decode(api_secret)              <- secret is b64url-encoded
      sig     = base64url_encode(hmac_sha256(key, payload)).rstrip("=")
      Authorization: Bearer 1.0:<key_id>:<sig>
      X-Crusoe-Timestamp: <YYYY-MM-DDTHH:MM:SS+00:00>    <- +00:00 not Z
    """
    import hmac as _hmac
    import hashlib
    import base64 as _b64
    from datetime import datetime, timezone
    # Timestamp must be +00:00 format (not Z) -- per official Crusoe example
    ts = str(datetime.now(timezone.utc).replace(microsecond=0)).replace(" ", "T")
    # Trailing newline after timestamp is required by the Crusoe signature spec
    payload = http_path + "\n" + query_params + "\n" + http_verb.upper() + "\n" + ts + "\n"
    # api_secret is stored base64url-encoded; decode it before use as HMAC key
    _secret_bytes = _b64.urlsafe_b64decode(api_secret + "=" * (-len(api_secret) % 4))
    sig = _b64.urlsafe_b64encode(
        _hmac.new(_secret_bytes, payload.encode("ascii"), hashlib.sha256).digest()
    ).decode().rstrip("=")
    return {
        "Authorization": f"Bearer 1.0:{api_key_id}:{sig}",
        "X-Crusoe-Timestamp": ts,
        "Content-Type": "application/json",
    }


async def _get_default_project_id(api_key_id: str, api_secret: str) -> Optional[str]:
    """Auto-discover the Crusoe project UUID via GET /v1alpha5/organizations/projects.

    CRUSOE_PROJECT_ID is a UUID (e.g. f058d0db-2fa4-4cf2-8cf1-dfbcfe05a814),
    NOT the human-readable project name. This method fetches it automatically
    so users don't need to configure it manually.

    Returns the first project's UUID, or None on failure.
    """
    _list_path = "/v1alpha5/organizations/projects"
    try:
        _auth = _auth_headers(api_key_id, api_secret, _list_path, "GET")
        async with aiohttp.ClientSession() as s:
            resp = await s.get(
                f"https://api.crusoecloud.com{_list_path}",
                headers=_auth,
                timeout=aiohttp.ClientTimeout(total=10),
            )
            if resp.status == 200:
                data = await resp.json()
                projects = data.get("items", data.get("projects", []))
                if projects:
                    pid = projects[0].get("id") or projects[0].get("project_id")
                    if pid:
                        logger.info(f"[Broker] Crusoe project_id auto-discovered: {pid}")
                        return pid
            else:
                body = await resp.text()
                logger.warning(f"[Broker] Crusoe project list returned {resp.status}: {body[:200]}")
    except Exception as e:
        logger.warning(f"[Broker] Crusoe project_id auto-discover failed: {e}")
    return None


async def provision(broker, gpu_type: "GPUType", job: "Job") -> Optional[str]:
    """Provision a Crusoe Cloud instance. Returns instance ID or None.

    Auth: HMAC-SHA256 signed Bearer token (see _auth_headers).
    Path: POST /v1alpha5/projects/{project_id}/compute/vms/instances
    project_id required -- set CRUSOE_PROJECT_ID env var.
    """
    from shared.data_loader import get_instance_string, resolve_gpu_key, is_gpu_available

    _cfg = broker._get_provider_config("crusoe")
    if not _cfg:
        _managed = await broker._get_managed_credentials("crusoe", job.job_id)
        if not _managed:
            job.last_provision_error = "Crusoe: no credentials available"
            return None
        from types import SimpleNamespace
        _cfg = SimpleNamespace(
            api_key=_managed["api_key"],
            api_secret=_managed.get("api_secret", ""),
            project_id=_managed.get("project_id", ""),
            ssh_public_key=_managed.get("ssh_public_key", ""),
        )
    _gpu_key = resolve_gpu_key(gpu_type.value)
    if not is_gpu_available("Crusoe", _gpu_key):
        job.last_provision_error = f"Crusoe: GPU {_gpu_key} not available"
        return None
    instance_type = get_instance_string("Crusoe", _gpu_key)
    if not instance_type:
        job.last_provision_error = f"Crusoe: no instance type mapped for {_gpu_key}"
        return None
    _project_id = getattr(_cfg, "project_id", "") or ""
    _api_secret = getattr(_cfg, "api_secret", "") or ""
    # Auto-discover project UUID if not configured
    if not _project_id:
        _project_id = await _get_default_project_id(_cfg.api_key, _api_secret)
        if not _project_id:
            job.last_provision_error = "Crusoe: could not resolve project_id"
            logger.error("Crusoe: could not resolve project_id -- set CRUSOE_PROJECT_ID in .env or Railway")
            return None
    _path = f"/v1alpha5/projects/{_project_id}/compute/vms/instances"
    try:
        _auth = _auth_headers(
            _cfg.api_key, _api_secret, _path, "POST"
        )
        async with aiohttp.ClientSession() as session:
            # Source: https://docs.crusoecloud.com/quickstart/creating-a-vm/index.html
            # image: string "name:tag", type: "gpu-model.Nx", location required
            crusoe_os_image = "ubuntu22.04:latest"
            crusoe_location = os.environ.get("VL_CRUSOE_LOCATION", "us-southcentral1-a")
            crusoe_startup = broker._build_vm_startup_script(job)
            # Instance type is the product_name from GET /v1alpha5/.../vms/types
            # e.g. "a100.1x", "h100-80gb-sxm-ib.8x" -- already includes count suffix
            _instance_type_full = instance_type
            _payload: dict = {
                "name": f"vl-{job.job_id[:8]}",
                "type": _instance_type_full,
                "location": crusoe_location,
                "image": crusoe_os_image,
                "startup_script": crusoe_startup,
            }
            # SSH public key -- from managed creds, Railway env, or local key file
            _ssh_pub = (getattr(_cfg, "ssh_public_key", "") or
                        os.environ.get("VL_CRUSOE_SSH_PUBLIC_KEY", "") or
                        _read_pubkey(os.path.expanduser("~/.vaultlayer/keys/vaultlayer-crusoe.pub")))
            if _ssh_pub:
                _payload["ssh_public_key"] = _ssh_pub.strip()
            async with session.post(
                f"https://api.crusoecloud.com{_path}",
                headers=_auth,
                json=_payload,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as r:
                if r.status not in (200, 201):
                    _err = (await r.text())[:300]
                    job.last_provision_error = f"Crusoe: HTTP {r.status} -- {_err[:150]}"
                    logger.error(f"Crusoe provision {r.status}: {_err}")
                    return None
                data = await r.json()
                # Response wraps instance in operation; id is at instance.id or result.id
                return (data.get("instance") or data.get("result") or {}).get("id")
    except Exception as e:
        job.last_provision_error = f"Crusoe: {type(e).__name__}: {str(e)[:150]}"
        logger.error(f"Crusoe provision error: {e}"); return None


async def hard_fence(broker, instance_id: str, job=None) -> None:
    """Terminate a Crusoe Cloud instance via API.

    Crusoe auth: HMAC-SHA256 signed Bearer token (NOT Basic auth).
    Format: Authorization: Bearer 1.0:<key_id>:<base64_hmac>
    Required header: X-Crusoe-Timestamp: <RFC3339>

    Path: DELETE /v1alpha5/projects/{project_id}/compute/vms/instances/{vm_id}
    project_id is required in the path -- the flat /instances/{id} path does not work.
    """
    _cfg = broker._get_provider_config("crusoe")
    if not _cfg:
        logger.warning(f"[Broker] Crusoe config not found, skipping fence for {instance_id}")
        return
    _project_id = getattr(_cfg, "project_id", "") or ""
    _api_secret = getattr(_cfg, "api_secret", "") or ""
    if not _project_id:
        _project_id = await _get_default_project_id(_cfg.api_key, _api_secret)
        if not _project_id:
            logger.warning(f"[Broker] Crusoe project_id not configured and auto-discover failed -- skipping fence for {instance_id}")
            return
    _path = f"/v1alpha5/projects/{_project_id}/compute/vms/instances/{instance_id}"
    try:
        _auth = _auth_headers(_cfg.api_key, getattr(_cfg, "api_secret", "") or "", _path, "DELETE")
        async with aiohttp.ClientSession() as s:
            resp = await s.delete(
                f"https://api.crusoecloud.com{_path}",
                headers=_auth,
                timeout=aiohttp.ClientTimeout(total=15),
            )
            if resp.status in (200, 202, 204):
                logger.info(f"[Broker] Crusoe instance {instance_id} terminated (status={resp.status})")
            else:
                body = await resp.text()
                logger.warning(f"[Broker] Crusoe fence returned {resp.status}: {body[:200]}")
    except Exception as e:
        logger.warning(f"[Broker] Crusoe fence failed for {instance_id} (proceeding): {e}")


def _read_pubkey(path: str) -> str:
    """Read an SSH public key file, returning empty string if not found."""
    try:
        with open(path) as _f:
            return _f.read().strip()
    except Exception:
        return ""
