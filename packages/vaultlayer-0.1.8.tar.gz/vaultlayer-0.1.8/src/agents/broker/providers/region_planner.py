"""Provider-agnostic region/zone ranking + cooldown for the broker.

Why this exists
----------------
Every region-based cloud provider (AWS, GCP, Azure, CoreWeave, Crusoe,
Nebius, Hyperstack) has the same provisioning-fallback shape:

  1. The user picks one target region/zone, or we pick a default.
  2. That region may not offer the requested instance type.
  3. That region may have no capacity right now (spot pool empty).
  4. That region may have a per-region quota hit.
  5. Each has its own per-region spot price that changes over time.

The AWS provider gained a capacity-aware ranker for all four. This module
extracts the part that's identical across providers — cooldown bookkeeping,
sort-by-price, drop-unsupported — so each provider just ships a thin
adapter with its own API calls.

Per-provider adapters supply:
  - supports_fn(region) -> bool          (describe-offerings equivalent)
  - price_fn(region) -> float | None     (spot-price-history equivalent)
  - COOLDOWN_ERROR_CODES: tuple[str]     (error strings that mean cooldown)

Cooldown state is keyed by (provider, region) so AWS's us-east-1 cooldown
doesn't affect GCP's us-east1-c and vice versa. State is in-process —
wiped on Railway redeploy, which is fine; it refills on the next attempt.
"""
from __future__ import annotations

import logging
import time
from typing import Callable, Optional

logger = logging.getLogger(__name__)

# Default cooldown — 10 minutes covers transient capacity pressure.
# Quota-class failures use a longer cooldown (see record_failure below)
# because AWS quotas don't clear in 10 minutes — they require a manual
# increase request which takes hours/days. Retrying in 10 min just burns
# API calls against a known-denied account.
_DEFAULT_COOLDOWN_S = 600  # 10 minutes (capacity-class)
_QUOTA_COOLDOWN_S = 3600   # 1 hour (quota-class — AWS answer recommends "longer backoff")

# Shared cooldown table: {(provider, region): expires_at_unix_ts}
_cooldown: dict[tuple[str, str], float] = {}


def record_failure(
    provider: str,
    region: str,
    error_code: str,
    cooldown_error_codes: tuple[str, ...],
    cooldown_seconds: Optional[int] = None,
) -> None:
    """Put (provider, region) into cooldown if the error indicates capacity/quota pressure.

    Non-matching error codes (auth, config, etc.) are ignored — those
    aren't going to clear up by waiting.

    `cooldown_seconds` overrides the default 10-min cooldown; callers pass a
    longer value (e.g., `_QUOTA_COOLDOWN_S`) for quota-class errors where
    retrying inside 10 min would waste API calls against an unchanged quota.
    """
    if any(sig in error_code for sig in cooldown_error_codes):
        duration = cooldown_seconds if cooldown_seconds is not None else _DEFAULT_COOLDOWN_S
        _cooldown[(provider, region)] = time.time() + duration
        logger.info(
            f"[region_planner] {provider}:{region} in cooldown until "
            f"{time.strftime('%H:%M:%SZ', time.gmtime(_cooldown[(provider, region)]))} "
            f"(reason: {error_code}, duration: {duration}s)"
        )


def is_in_cooldown(provider: str, region: str) -> bool:
    ts = _cooldown.get((provider, region))
    if ts is None:
        return False
    if time.time() < ts:
        return True
    _cooldown.pop((provider, region), None)
    return False


def rank_regions(
    provider: str,
    candidate_regions: list[str],
    primary_region: str,
    supports_fn: Callable[[str], bool],
    price_fn: Callable[[str], Optional[float]],
) -> tuple[list[str], list[str]]:
    """Order candidate regions by (cooldown_ok, price_ascending).

    Regions where `supports_fn()` returns False are dropped entirely.
    `price_fn()` returning None sorts that region to the end (unknown price,
    still try it as a fallback).

    Honors `primary_region` pin: if it survives filtering, it goes first.

    Returns (ordered_regions, dropped_regions_with_reason).
    """
    ordered: list[tuple[bool, float, str]] = []  # (in_cooldown, price, region)
    dropped: list[str] = []

    for region in candidate_regions:
        try:
            if not supports_fn(region):
                dropped.append(f"{region}:not-offered")
                continue
        except Exception as e:
            # Fail open on support check — don't let a transient API blip blacklist a region
            logger.warning(
                f"[region_planner] {provider}:{region} supports-check errored: {e}. "
                f"Assuming supported."
            )

        try:
            price = price_fn(region)
        except Exception as e:
            logger.debug(f"[region_planner] {provider}:{region} price fetch failed: {e}")
            price = None

        price_key = price if price is not None else float("inf")
        ordered.append((is_in_cooldown(provider, region), price_key, region))

    # Sort: out-of-cooldown first (False < True), then price ascending
    ordered.sort(key=lambda t: (t[0], t[1]))

    # Honor primary_region pin when it survived
    regions = [r for _, _, r in ordered]
    if primary_region in regions:
        regions.remove(primary_region)
        regions.insert(0, primary_region)

    return regions, dropped
