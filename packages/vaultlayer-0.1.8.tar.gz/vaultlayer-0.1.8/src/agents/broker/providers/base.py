"""Provider adapter protocol — structural typing for provider modules.

Each provider file (lambda_labs.py, runpod.py, etc.) must expose:
  - provision(broker, gpu_type, job) -> Optional[str]
  - hard_fence(broker, instance_id, job=None) -> None

Provider methods receive the BrokerAgent instance as 'broker' to access:
  - broker.config          — VaultLayerConfig with provider API keys
  - broker.gpu_resolver    — dynamic GPU name resolution
  - broker.prepare_startup — unified startup script builder
  - broker._get_provider_config(attr) — provider config or None
  - broker._get_managed_credentials(provider, job_id) — Railway managed keys
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional, Protocol

if TYPE_CHECKING:
    from shared.models import GPUType, Job


class ProviderAdapter(Protocol):
    """Structural type for provider modules. Not enforced at runtime."""

    async def provision(
        self, broker: object, gpu_type: "GPUType", job: "Job"
    ) -> Optional[str]: ...

    async def hard_fence(
        self, broker: object, instance_id: str, job: "Job | None" = None
    ) -> None: ...
