"""AWS adapter for the provider-agnostic region_planner.

Supplies the AWS-specific pieces:
  - supports_instance_type()  via ec2.describe_instance_type_offerings
  - get_spot_price()          via ec2.describe_spot_price_history
  - COOLDOWN_ERROR_CODES      AWS error-code strings that warrant cooldown

All bookkeeping (cooldown table, ranking, dropping unsupported regions)
lives in region_planner and is shared across providers.

AWS API references
------------------
describe_instance_type_offerings — returns the instance types available
  in a given region or AZ. Docs:
  https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_DescribeInstanceTypeOfferings.html

describe_spot_price_history — returns the current spot price per AZ for
  a given instance type. Docs:
  https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_DescribeSpotPriceHistory.html
"""
from __future__ import annotations

import logging
import time
from datetime import datetime
from typing import Optional

from agents.broker.providers import region_planner

logger = logging.getLogger(__name__)

PROVIDER = "aws"

# AWS error codes are split into two classes per AWS's own guidance
# ("Use longer backoff for quota errors since they require an action;
#  use short backoff for capacity errors since they may clear quickly"):
#
#   QUOTA — an adjustment to the account's vCPU/instance quota is
#   required. Retrying within minutes is guaranteed to fail the same way.
#   Use a 1-hour cooldown so a granted quota increase is picked up
#   reasonably fast without hammering the AWS API in the interim.
#
#   CAPACITY — a spot pool is temporarily empty, or the price is below
#   the current market. Supply can re-appear within minutes; retry
#   quickly in a different region.
_QUOTA_ERROR_CODES = (
    "MaxSpotInstanceCountExceeded",
    "VcpuLimitExceeded",
    "InstanceLimitExceeded",
)
_CAPACITY_ERROR_CODES = (
    "InsufficientInstanceCapacity",
    "SpotMaxPriceTooLow",
)

# Union kept for backward-compat with callers that just want "any cooldown-worthy error"
COOLDOWN_ERROR_CODES = _QUOTA_ERROR_CODES + _CAPACITY_ERROR_CODES

_QUOTA_COOLDOWN_S = 3600   # 1 hour
_CAPACITY_COOLDOWN_S = 600  # 10 minutes

# Local TTL caches for AWS describe-* calls (keyed by region+instance_type)
_OFFERING_TTL_S = 24 * 3600   # offerings rarely change
_PRICE_TTL_S = 300            # spot prices move
_offerings_cache: dict[tuple[str, str], tuple[bool, float]] = {}
_price_cache: dict[tuple[str, str], tuple[float, float]] = {}


def supports_instance_type(ec2, region: str, instance_type: str) -> bool:
    """True if the region offers this instance type. Fails open on API errors."""
    key = (region, instance_type)
    now = time.time()
    hit = _offerings_cache.get(key)
    if hit and now - hit[1] < _OFFERING_TTL_S:
        return hit[0]
    try:
        resp = ec2.describe_instance_type_offerings(
            LocationType="region",
            Filters=[
                {"Name": "instance-type", "Values": [instance_type]},
                {"Name": "location",      "Values": [region]},
            ],
        )
        supported = bool(resp.get("InstanceTypeOfferings"))
        _offerings_cache[key] = (supported, now)
        if not supported:
            logger.info(
                f"[aws_capacity] {region} does not offer {instance_type} — "
                f"region_planner will skip it"
            )
        return supported
    except Exception as e:
        logger.warning(
            f"[aws_capacity] describe_instance_type_offerings failed in "
            f"{region} for {instance_type}: {e}. Failing open."
        )
        return True


def get_spot_price(ec2, region: str, instance_type: str) -> Optional[float]:
    """Cheapest current spot price across AZs in the region. None on error."""
    key = (region, instance_type)
    now = time.time()
    hit = _price_cache.get(key)
    if hit and now - hit[1] < _PRICE_TTL_S:
        return hit[0]
    try:
        resp = ec2.describe_spot_price_history(
            InstanceTypes=[instance_type],
            ProductDescriptions=["Linux/UNIX"],
            StartTime=datetime.utcnow(),
            MaxResults=20,
        )
        rows = resp.get("SpotPriceHistory", [])
        if not rows:
            return None
        by_az: dict[str, dict] = {}
        for r in rows:
            az = r["AvailabilityZone"]
            if az not in by_az or r["Timestamp"] > by_az[az]["Timestamp"]:
                by_az[az] = r
        cheapest = min(float(r["SpotPrice"]) for r in by_az.values())
        _price_cache[key] = (cheapest, now)
        return cheapest
    except Exception as e:
        logger.debug(
            f"[aws_capacity] describe_spot_price_history failed in "
            f"{region} for {instance_type}: {e}"
        )
        return None


def record_failure(region: str, error_code: str) -> None:
    """Shortcut so callers don't have to pass PROVIDER + COOLDOWN_ERROR_CODES.

    Classifies `error_code` as quota-class or capacity-class and passes the
    appropriate cooldown duration (quota = 1 hour, capacity = 10 min).
    Unknown errors use the capacity default (safe fallback).
    """
    is_quota = any(sig in error_code for sig in _QUOTA_ERROR_CODES)
    cooldown = _QUOTA_COOLDOWN_S if is_quota else _CAPACITY_COOLDOWN_S
    region_planner.record_failure(
        PROVIDER, region, error_code, COOLDOWN_ERROR_CODES,
        cooldown_seconds=cooldown,
    )


def rank_regions(
    candidate_regions: list[str],
    instance_type: str,
    ec2_factory,
    primary_region: str,
) -> tuple[list[str], list[str]]:
    """AWS-specific wrapper around region_planner.rank_regions().

    Opens an ec2 client per region lazily via ec2_factory, then delegates
    the ranking itself to the shared planner.
    """
    # Cache clients so repeat calls within one rank_regions() reuse them
    _clients: dict[str, object] = {}

    def _get_ec2(region: str):
        if region not in _clients:
            _clients[region] = ec2_factory(region)
        return _clients[region]

    def _supports(region: str) -> bool:
        try:
            return supports_instance_type(_get_ec2(region), region, instance_type)
        except Exception as e:
            logger.warning(f"[aws_capacity] cannot open ec2 for {region}: {e}")
            return False

    def _price(region: str) -> Optional[float]:
        try:
            return get_spot_price(_get_ec2(region), region, instance_type)
        except Exception:
            return None

    return region_planner.rank_regions(
        provider=PROVIDER,
        candidate_regions=candidate_regions,
        primary_region=primary_region,
        supports_fn=_supports,
        price_fn=_price,
    )
