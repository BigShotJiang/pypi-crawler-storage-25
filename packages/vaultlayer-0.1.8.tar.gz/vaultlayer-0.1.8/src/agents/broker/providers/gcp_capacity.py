"""GCP adapter for the provider-agnostic region_planner.

GCP provisioning is zone-scoped (instances.insert runs against a zone),
but GPU quotas are region-scoped (GPUS_ALL_REGIONS is global, per-family
quotas are per-region). So the fallback candidate list is *zones*, and
when one zone's region hits a quota wall, we cool down every zone in
that region.

Zone selection strategy
-----------------------
For each supported GPU type we list zones known to offer it (per GCP's
Regions and zones doc — https://cloud.google.com/compute/docs/gpus/gpu-regions-zones).
These are pre-vetted so acceleratorTypes.list rarely lies; we still
confirm via the API because Google occasionally deprecates zones.

COOLDOWN_ERROR_CODES
--------------------
Matches the error strings GCE returns in zoneOperations.get(...).error:
  QUOTA_EXCEEDED                 — per-region vCPU or GPU quota hit
  ZONE_RESOURCE_POOL_EXHAUSTED   — zone has no spot capacity right now
  STOCKOUT                       — broader capacity shortage signal
  ZONE_UNAVAILABLE               — zone maintenance / outage

No spot-price-history equivalent
--------------------------------
GCP doesn't expose a live spot-price-history API like AWS does. Spot
pricing is a fixed discount off on-demand, published monthly. So
get_spot_price always returns None and region_planner sorts purely by
(cooldown_ok, zone-order). That's fine — the key value from ranking on
GCP is "don't retry a zone we just got QUOTA_EXCEEDED in."
"""
from __future__ import annotations

import logging
import time
from typing import Optional

from agents.broker.providers import region_planner

logger = logging.getLogger(__name__)

PROVIDER = "gcp"

# GCP error codes from zoneOperations.get(...).error.errors[*].code that
# mean "don't retry this zone for a while."
COOLDOWN_ERROR_CODES = (
    "QUOTA_EXCEEDED",
    "ZONE_RESOURCE_POOL_EXHAUSTED",
    "ZONE_RESOURCE_POOL_EXHAUSTED_WITH_DETAILS",
    "STOCKOUT",
    "ZONE_UNAVAILABLE",
    "RESOURCE_OPERATION_RATE_EXCEEDED",
)

# Known zones per GPU accelerator type. Source:
# https://cloud.google.com/compute/docs/gpus/gpu-regions-zones
# Kept conservative — only zones where the SKU has been available for 6+
# months. We confirm via acceleratorTypes.list at rank time too.
ZONE_CANDIDATES: dict[str, list[str]] = {
    # T4 (A10G maps here in vaultlayer)
    "nvidia-tesla-t4": [
        "us-central1-a", "us-central1-b", "us-central1-c", "us-central1-f",
        "us-east1-c", "us-east1-d",
        "us-east4-a", "us-east4-b", "us-east4-c",
        "us-west1-a", "us-west1-b",
        "us-west4-a", "us-west4-b",
        "europe-west1-b", "europe-west1-c", "europe-west1-d",
        "europe-west4-a", "europe-west4-b", "europe-west4-c",
        "asia-southeast1-a", "asia-southeast1-b", "asia-southeast1-c",
    ],
    # A100 40GB
    "nvidia-tesla-a100": [
        "us-central1-a", "us-central1-b", "us-central1-c", "us-central1-f",
        "us-east1-b",
        "us-west1-b",
        "us-west4-b",
        "europe-west4-a", "europe-west4-b",
        "asia-southeast1-c",
    ],
    # A100 80GB (ultragpu variants)
    "nvidia-a100-80gb": [
        "us-central1-a", "us-central1-c",
        "us-east4-c",
        "europe-west4-a",
    ],
    # H100 80GB
    "nvidia-h100-80gb": [
        "us-central1-a", "us-central1-c",
        "us-east4-a", "us-east4-c",
        "europe-west4-b",
    ],
}

# Offering-check cache (zone, accel_type) -> (supported, ts)
_OFFERING_TTL_S = 24 * 3600
_offerings_cache: dict[tuple[str, str], tuple[bool, float]] = {}


def zones_for_accelerator(accel_type: str) -> list[str]:
    """Return the hardcoded zone list for a GCP accelerator type."""
    return list(ZONE_CANDIDATES.get(accel_type, []))


def supports_accelerator(compute, project_id: str, zone: str, accel_type: str) -> bool:
    """True if `zone` offers `accel_type`, via acceleratorTypes.list.

    Fails open on API errors so a transient list() failure doesn't
    blacklist a viable zone.
    """
    key = (zone, accel_type)
    now = time.time()
    hit = _offerings_cache.get(key)
    if hit and now - hit[1] < _OFFERING_TTL_S:
        return hit[0]
    try:
        resp = compute.acceleratorTypes().list(
            project=project_id, zone=zone
        ).execute()
        items = resp.get("items", [])
        supported = any(a.get("name") == accel_type for a in items)
        _offerings_cache[key] = (supported, now)
        if not supported:
            logger.info(
                f"[gcp_capacity] {zone} does not offer {accel_type} — "
                f"region_planner will skip it"
            )
        return supported
    except Exception as e:
        logger.warning(
            f"[gcp_capacity] acceleratorTypes.list failed in {zone} for "
            f"{accel_type}: {e}. Failing open."
        )
        return True


def record_failure(zone: str, error_code: str) -> None:
    """Shortcut so callers don't have to pass PROVIDER + COOLDOWN_ERROR_CODES.

    Note: GCP quotas are per-region, but we cool down per-zone here
    because the planner is zone-keyed. A quota hit in us-central1-a
    means us-central1-b is also going to fail for the same quota — the
    planner will just rack up the cooldown for each zone independently,
    which yields the right behavior (skip the whole region within the
    10-min window).
    """
    region_planner.record_failure(PROVIDER, zone, error_code, COOLDOWN_ERROR_CODES)


def rank_zones(
    candidate_zones: list[str],
    accel_type: str,
    compute,
    project_id: str,
    primary_zone: str,
) -> tuple[list[str], list[str]]:
    """GCP-specific wrapper around region_planner.rank_regions().

    Delegates the shared ranking logic, filling in GCP-specific offering
    checks. Spot price is unavailable on GCP — all zones sort equally
    unless a cooldown bumps one to the back.
    """
    def _supports(zone: str) -> bool:
        return supports_accelerator(compute, project_id, zone, accel_type)

    def _price(_zone: str) -> Optional[float]:
        # GCP spot pricing is a published discount off on-demand; no
        # per-zone live price feed. Return None so all zones sort equal
        # on price and cooldown is the only differentiator.
        return None

    return region_planner.rank_regions(
        provider=PROVIDER,
        candidate_regions=candidate_zones,
        primary_region=primary_zone,
        supports_fn=_supports,
        price_fn=_price,
    )
