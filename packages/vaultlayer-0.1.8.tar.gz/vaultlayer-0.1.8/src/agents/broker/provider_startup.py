"""Provider deployment registry — single source of truth for script injection.

Maps each Provider to:
  - deployment_type: VM (cloud-init) vs CONTAINER (Docker onstart)
  - encoding: PLAIN, BASE64, or RUNPOD_PRE_START

provision_*() methods call prepare_startup() instead of manually picking
a builder and encoding. Adding a new provider = one line in the registry.

RunPod fix: writes bootstrap to /pre_start.sh then execs /start.sh,
so RunPod's native SSH/nginx/Jupyter setup still runs.

Lambda fix: sends user_data as plain text (not base64), which is what
Lambda's cloud-init expects.
"""

from __future__ import annotations

import base64
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from shared.models import Provider

logger = logging.getLogger(__name__)


class DeploymentType(str, Enum):
    """How the provider runs user code."""
    VM = "vm"              # Bare VM with cloud-init (Lambda, AWS, GCP, Azure, etc.)
    CONTAINER = "container"  # Docker container (RunPod, Vast.ai)


class ScriptEncoding(str, Enum):
    """How the startup script must be encoded for the provider API."""
    PLAIN = "plain"                      # Raw text (GCP, Lambda, Crusoe, VP, Hyperstack, CoreWeave, Vast.ai)
    BASE64 = "base64"                    # Base64-encoded (AWS, Azure, Nebius)
    RUNPOD_PRE_START = "runpod_pre_start"  # Base64 in env var → decoded to /pre_start.sh → exec /start.sh


@dataclass(frozen=True)
class ProviderDeployConfig:
    """Immutable config for how a provider receives its startup script."""
    deployment_type: DeploymentType
    encoding: ScriptEncoding
    api_field: str = ""  # Documentation: which API field carries the script


@dataclass
class StartupPayload:
    """Prepared script + metadata ready for injection into a provider API call."""
    script: str                         # Encoded script string (ready to inject into API field)
    deployment_type: DeploymentType
    encoding: ScriptEncoding
    raw_script: str                     # Unencoded script (for debugging/logging)
    # RunPod-specific
    runpod_env: Optional[dict] = None
    runpod_docker_args: Optional[str] = None


# ══════════════════════════════════════════════════════════════════════════════
# THE REGISTRY — one line per provider, single source of truth
# ══════════════════════════════════════════════════════════════════════════════

PROVIDER_DEPLOY_REGISTRY: dict[Provider, ProviderDeployConfig] = {
    # Container providers
    Provider.RUNPOD:        ProviderDeployConfig(DeploymentType.CONTAINER, ScriptEncoding.RUNPOD_PRE_START, "dockerArgs + env[VL_ONSTART_B64]"),
    Provider.VAST_AI:       ProviderDeployConfig(DeploymentType.CONTAINER, ScriptEncoding.PLAIN,            "onstart"),
    # VM providers — plain text cloud-init
    Provider.LAMBDA_LABS:   ProviderDeployConfig(DeploymentType.VM,        ScriptEncoding.PLAIN,            "user_data"),
    Provider.GCP:           ProviderDeployConfig(DeploymentType.VM,        ScriptEncoding.PLAIN,            "metadata.startup-script"),
    Provider.VOLTAGE_PARK:  ProviderDeployConfig(DeploymentType.VM,        ScriptEncoding.PLAIN,            "user_data"),
    Provider.CRUSOE:        ProviderDeployConfig(DeploymentType.VM,        ScriptEncoding.PLAIN,            "startup_script"),
    Provider.HYPERSTACK:    ProviderDeployConfig(DeploymentType.VM,        ScriptEncoding.PLAIN,            "user_data"),
    Provider.COREWEAVE:     ProviderDeployConfig(DeploymentType.VM,        ScriptEncoding.PLAIN,            "userData"),
    # VM providers — base64 cloud-init
    Provider.AWS:           ProviderDeployConfig(DeploymentType.VM,        ScriptEncoding.BASE64,           "UserData"),
    Provider.AZURE:         ProviderDeployConfig(DeploymentType.VM,        ScriptEncoding.BASE64,           "custom_data"),
    Provider.NEBIUS:        ProviderDeployConfig(DeploymentType.VM,        ScriptEncoding.BASE64,           "metadata.user-data"),
}


def encode_script(raw: str, encoding: ScriptEncoding) -> str:
    """Apply provider-specific encoding to a raw script string."""
    if encoding == ScriptEncoding.PLAIN:
        return raw
    elif encoding in (ScriptEncoding.BASE64, ScriptEncoding.RUNPOD_PRE_START):
        return base64.b64encode(raw.encode()).decode()
    else:
        raise ValueError(f"Unknown encoding: {encoding}")


def build_runpod_docker_args() -> str:
    """Build RunPod dockerArgs string (GraphQL API backward compat).

    Deprecated: REST API uses dockerEntrypoint array instead.
    Kept for tests and any code still using GraphQL.
    """
    return (
        "bash -c '"
        "echo $VL_ONSTART_B64 | base64 -d > /pre_start.sh && "
        "chmod +x /pre_start.sh && "
        "exec /start.sh"
        "'"
    )


def build_runpod_entrypoint() -> list[str]:
    """Build RunPod dockerEntrypoint array for REST API.

    Uses separate ENTRYPOINT override (not CMD) so RunPod's /start.sh
    init sequence runs correctly:
      1. Our entrypoint decodes VL_ONSTART_B64 → /pre_start.sh
      2. Execs /start.sh which runs: nginx → /pre_start.sh → SSH → Jupyter → sleep infinity

    Source: https://docs.runpod.io/pods/templates/create-custom-template
    """
    return [
        "bash", "-c",
        "echo $VL_ONSTART_B64 | base64 -d > /pre_start.sh && "
        "chmod +x /pre_start.sh && "
        "exec /start.sh"
    ]
