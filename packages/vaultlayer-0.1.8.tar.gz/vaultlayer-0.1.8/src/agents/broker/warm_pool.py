"""
VaultLayer — Warm Pool Manager (P0-L3)

Pre-warms standby GPU nodes so that execute_migration can skip cold-start
provisioning entirely.  A warm node is fully bootstrapped: rclone installed,
R2 mounted, docker image pulled, bootstrap sentinel written.  It sits idle
waiting for a job assignment.

Architecture
============
- WarmPoolManager keeps an in-memory registry ``{GPUType: [WarmNode, ...]}``.
- On job registration (BrokerAgent.register_job), `_replenish()` is called to
  provision one idle node of the required GPU type.
- `claim(gpu_type)` atomically pops a warm node and starts async replenishment.
  Returns None (pool miss) if no warm node is available for that GPU type.
- `release(instance_id)` terminates an unclaimed warm node (e.g. the job went
  to a different provider) via the provider's terminate API.
- Warm nodes expire after IDLE_EXPIRY_SECS (default 1800 = 30 min) to bound
  idle cost.  The `_expiry_loop` runs every 60 s and terminates stale nodes.

Cost model
==========
One pre-warmed H100 (Lambda Labs) ≈ $2.49 / hr.  For a job running on a spot
instance interrupted roughly every 2 hours, the warm-pool cost is
~$2.49 × 0.5 hr / 2 hr = ~$0.62 / interruption — much cheaper than the
$15-30 SLA penalty cost of a 5-13 min cold start.

Usage
=====
The BrokerAgent integrates the warm pool in execute_migration:

    node = await self._warm_pool.claim(target_gpu)
    if node:
        instance_id = node.instance_id
        node_host   = node.host
        ssh_key     = node.ssh_key
    else:
        # cold provision path
        instance_id = await self._provision_on(target_provider, target_gpu, job)
"""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from shared.models import GPUType, Provider

logger = logging.getLogger("agents.broker.warm_pool")

# Warm nodes expire after this many seconds idle to control cost.
IDLE_EXPIRY_SECS: int = 1800  # 30 minutes


@dataclass
class WarmNode:
    """A pre-warmed, idle GPU node ready to accept a job."""
    instance_id: str
    provider: Provider
    gpu_type: GPUType
    host: str                    # public IP / hostname
    ssh_key: str                 # path to private key for SSH
    provisioned_at: float = field(default_factory=time.monotonic)

    @property
    def idle_secs(self) -> float:
        return time.monotonic() - self.provisioned_at

    @property
    def is_expired(self) -> bool:
        return self.idle_secs >= IDLE_EXPIRY_SECS


class WarmPoolManager:
    """
    Manages a small pool of pre-warmed standby GPU nodes.

    Thread-safety: all public methods are async and use asyncio primitives.
    Not thread-safe across OS threads.
    """

    def __init__(
        self,
        provision_fn,           # async callable(gpu_type, job) -> Optional[str]  (instance_id)
        terminate_fn,           # async callable(instance_id, provider) -> None
        ssh_key_path: str = "",
        pool_size: int = 1,     # warm nodes to keep per GPU type
    ):
        """
        Args:
            provision_fn: async (gpu_type: GPUType, job: Job) -> Optional[str] — same signature as
                          _provision_on inside BrokerAgent.  We pass a thin wrapper that supplies a
                          "standby" dummy job when pre-warming.
            terminate_fn: async (instance_id: str, provider: Provider) -> None
            ssh_key_path: path to SSH private key written by the provisioning scripts
            pool_size:    target warm-node count per GPU type (default 1)
        """
        self._provision_fn = provision_fn
        self._terminate_fn = terminate_fn
        self._ssh_key_path = ssh_key_path
        self._pool_size = pool_size

        # {GPUType: [WarmNode]}  — ordered FIFO so oldest node is claimed first
        self._pool: Dict[GPUType, List[WarmNode]] = {}
        # Lazily created on first use to avoid binding to the event loop at construction
        # time (Python 3.9 asyncio.Lock() requires a running loop).
        self._lock: Optional[asyncio.Lock] = None

        # Track in-flight replenishment tasks to avoid duplicate provisions
        self._replenishing: Dict[GPUType, bool] = {}

        self._expiry_task: Optional[asyncio.Task] = None

    # ------------------------------------------------------------------
    # Internal: lazy lock (Python 3.9 compat)
    # ------------------------------------------------------------------

    def _get_lock(self) -> asyncio.Lock:
        """Return the asyncio.Lock, creating it lazily inside an event loop."""
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the background expiry loop.  Call from BrokerAgent.start()."""
        self._expiry_task = asyncio.create_task(
            self._expiry_loop(), name="warm-pool-expiry"
        )
        logger.info("[WarmPool] Started (idle expiry = %ds)", IDLE_EXPIRY_SECS)

    async def stop(self) -> None:
        """Cancel the expiry loop and terminate all idle warm nodes."""
        if self._expiry_task and not self._expiry_task.done():
            self._expiry_task.cancel()
            try:
                await self._expiry_task
            except asyncio.CancelledError:
                pass

        # Terminate remaining warm nodes on shutdown
        async with self._get_lock():
            for gpu_type, nodes in list(self._pool.items()):
                for node in nodes:
                    logger.info(
                        "[WarmPool] Shutdown — terminating idle %s node %s",
                        gpu_type.value, node.instance_id,
                    )
                    try:
                        await self._terminate_fn(node.instance_id, node.provider)
                    except Exception as exc:
                        logger.warning(
                            "[WarmPool] Failed to terminate %s on shutdown: %s",
                            node.instance_id, exc,
                        )
            self._pool.clear()
        logger.info("[WarmPool] Stopped")

    # ------------------------------------------------------------------
    # Core API
    # ------------------------------------------------------------------

    async def claim(self, gpu_type: GPUType) -> Optional[WarmNode]:
        """
        Atomically claim a warm node for ``gpu_type``.

        Returns a WarmNode if one is available, or None (pool miss → caller
        falls back to cold provision).  After a successful claim, kicks off
        async replenishment so the pool refills for the next interruption.
        """
        async with self._get_lock():
            nodes = self._pool.get(gpu_type, [])
            # Skip expired nodes (treat as miss — they'll be cleaned by expiry loop)
            live_nodes = [n for n in nodes if not n.is_expired]
            if not live_nodes:
                logger.info(
                    "[WarmPool] Pool miss for %s — falling back to cold provision",
                    gpu_type.value,
                )
                self._pool[gpu_type] = []  # clear any expired entries
                return None

            node = live_nodes[0]
            self._pool[gpu_type] = live_nodes[1:]  # remove claimed node
            logger.info(
                "[WarmPool] Pool HIT for %s — claiming node %s (idle %.0fs)",
                gpu_type.value, node.instance_id, node.idle_secs,
            )

        # Kick off async replenishment outside the lock (provision is slow)
        asyncio.create_task(
            self._replenish(gpu_type, node.provider),
            name=f"warm-pool-replenish-{gpu_type.value}",
        )
        return node

    async def release(self, instance_id: str, provider: Provider) -> None:
        """
        Terminate a warm node that was NOT claimed (e.g. migration went
        to a different provider or job completed normally).
        """
        # Remove from pool if still there
        async with self._get_lock():
            for gpu_type, nodes in self._pool.items():
                before = len(nodes)
                self._pool[gpu_type] = [n for n in nodes if n.instance_id != instance_id]
                if len(self._pool[gpu_type]) < before:
                    break

        logger.info("[WarmPool] Releasing (terminating) warm node %s", instance_id)
        try:
            await self._terminate_fn(instance_id, provider)
        except Exception as exc:
            logger.warning("[WarmPool] Failed to terminate %s: %s", instance_id, exc)

    async def prewarm(self, gpu_type: GPUType, provider: Provider) -> None:
        """
        Explicitly request pre-warming for a GPU type.

        Called by BrokerAgent.register_job() so a warm node is ready before
        the first interruption.  Safe to call multiple times — idempotent if
        the pool already has a live node.
        """
        async with self._get_lock():
            live = [n for n in self._pool.get(gpu_type, []) if not n.is_expired]
            if len(live) >= self._pool_size:
                logger.debug(
                    "[WarmPool] Already have %d live node(s) for %s — skipping prewarm",
                    len(live), gpu_type.value,
                )
                return
            if self._replenishing.get(gpu_type):
                logger.debug(
                    "[WarmPool] Replenishment already in flight for %s", gpu_type.value
                )
                return

        asyncio.create_task(
            self._replenish(gpu_type, provider),
            name=f"warm-pool-prewarm-{gpu_type.value}",
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _replenish(self, gpu_type: GPUType, provider: Provider) -> None:
        """Provision one idle standby node and add it to the pool."""
        async with self._get_lock():
            if self._replenishing.get(gpu_type):
                return  # another task is already replenishing
            self._replenishing[gpu_type] = True

        try:
            logger.info(
                "[WarmPool] Replenishing: provisioning 1 × %s on %s",
                gpu_type.value, provider.value,
            )
            # Build a minimal sentinel Job so _provision_on has a job_id / user_id to tag
            from shared.models import Job, JobStatus
            import uuid as _uuid
            sentinel_job = Job(
                job_id=f"warm-pool-{_uuid.uuid4().hex[:8]}",
                user_id="vaultlayer-system",
                name=f"warm-pool-standby-{gpu_type.value}",
                command="",
                provider=provider,
                gpu_type=gpu_type,
                status=JobStatus.QUEUED,
            )
            instance_id: Optional[str] = await self._provision_fn(gpu_type, sentinel_job)
            if not instance_id:
                logger.warning(
                    "[WarmPool] Replenishment failed for %s — pool empty until next retry",
                    gpu_type.value,
                )
                return

            # TODO: In a full implementation, poll SSH + bootstrap sentinel here
            # so the node is guaranteed ready before being claimed.  For now we
            # optimistically add it and let execute_migration's _wait_for_bootstrap
            # handle any remaining setup time.
            node = WarmNode(
                instance_id=instance_id,
                provider=provider,
                gpu_type=gpu_type,
                host=instance_id,  # BrokerAgent.execute_migration resolves host via describe
                ssh_key=self._ssh_key_path,
            )
            async with self._get_lock():
                self._pool.setdefault(gpu_type, []).append(node)
            logger.info(
                "[WarmPool] Replenishment complete: %s node %s is ready",
                gpu_type.value, instance_id,
            )
        except Exception as exc:
            logger.error("[WarmPool] Replenishment error for %s: %s", gpu_type.value, exc)
        finally:
            async with self._get_lock():
                self._replenishing[gpu_type] = False

    async def _expiry_loop(self) -> None:
        """Every 60 s, terminate warm nodes that have been idle for IDLE_EXPIRY_SECS."""
        while True:
            try:
                await asyncio.sleep(60)
                await self._expire_stale_nodes()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error("[WarmPool] Expiry loop error: %s", exc)

    async def _expire_stale_nodes(self) -> None:
        """Find and terminate expired warm nodes."""
        to_terminate: List[WarmNode] = []
        async with self._get_lock():
            for gpu_type, nodes in list(self._pool.items()):
                live, stale = [], []
                for n in nodes:
                    (stale if n.is_expired else live).append(n)
                self._pool[gpu_type] = live
                to_terminate.extend(stale)

        for node in to_terminate:
            logger.info(
                "[WarmPool] Expiring idle node %s (%s, idle=%.0fs)",
                node.instance_id, node.gpu_type.value, node.idle_secs,
            )
            try:
                await self._terminate_fn(node.instance_id, node.provider)
            except Exception as exc:
                logger.warning(
                    "[WarmPool] Failed to terminate expired node %s: %s",
                    node.instance_id, exc,
                )

    # ------------------------------------------------------------------
    # Introspection (for tests / metrics)
    # ------------------------------------------------------------------

    def pool_size(self, gpu_type: GPUType) -> int:
        """Return the number of live (non-expired) warm nodes for a GPU type."""
        return sum(1 for n in self._pool.get(gpu_type, []) if not n.is_expired)

    def all_nodes(self) -> List[WarmNode]:
        """Return all warm nodes across all GPU types."""
        return [n for nodes in self._pool.values() for n in nodes]
