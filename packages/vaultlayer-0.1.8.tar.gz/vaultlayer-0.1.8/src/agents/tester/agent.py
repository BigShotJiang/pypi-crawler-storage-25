import asyncio, os, sys, json, subprocess, importlib, inspect
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
import anthropic

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'src'))

PROBLEM_STATEMENT = """
VaultLayer wraps AI training commands and provides:
1. Cost savings: 60-70% cheaper than AWS On-Demand by routing to Lambda Labs/CoreWeave
2. Reliability: 99.9% job completion — detect Spot terminations, checkpoint, auto-resume
3. Zero code changes: user just runs 'vaultlayer run python train.py'
4. Autonomous: an Orchestration Agent (Claude-powered) makes all decisions
5. Checkpoints: stored in Cloudflare R2, restorable on any provider
"""

DISCOVERY_PROMPT = """
You are analyzing the VaultLayer codebase to understand how it implements
this product:

{problem_statement}

Here is the codebase:
{codebase}

Answer these questions as JSON:
{{
  "entry_point": "how does 'vaultlayer run' start — file and function",
  "termination_handler": "what handles AWS Spot termination signals — class and method",
  "decision_maker": "what makes migration decisions — class and method",
  "checkpoint_storage": "how/where checkpoints are stored — class and method",
  "savings_calculator": "what calculates cost savings — class and method",
  "agent_communication": "how agents communicate — mechanism and channel names",
  "job_completion_flow": "step by step what happens when a job completes successfully",
  "interruption_flow": "step by step what happens when an interruption is detected",
  "testable_behaviours": [
    "list of specific behaviours that can be tested without real cloud credentials"
  ]
}}
"""

TEST_GENERATION_PROMPT = """
You are a test engineer. Based on this discovery of the VaultLayer codebase:

{discovery}

And this problem statement:
{problem_statement}

Generate Python test code that verifies the key behaviours.
Rules:
- Test BEHAVIOURS not implementation details
- Use unittest.mock to avoid real cloud API calls
- Each test must be a standalone async function
- Tests must be able to run without real AWS/Lambda/R2/Redis credentials
- Mock the anthropic.Anthropic client to return realistic responses
- Name tests after the behaviour they verify, not the class they test

Output a Python file with:
1. All necessary imports (discovered from the codebase)
2. A MockAnthropicClient that returns realistic Claude responses
3. A MockQueue/MockStorage for external I/O
4. Test functions named test_<behaviour_description>
5. A run_tests() async function that runs all tests and returns results

Output ONLY valid Python code, no markdown.
"""

FAILURE_ANALYSIS_PROMPT = """
A VaultLayer test failed. Analyze the failure and explain what behaviour
is broken in terms of the product requirements, not the implementation.

Test name: {test_name}
Error: {error}
Problem statement: {problem_statement}

Explain:
1. Which product requirement is failing (cost savings / reliability / etc.)
2. What the system should have done vs what happened
3. Likely root cause in plain English (not code references)
4. Severity: critical (blocks core value) / major (degrades experience) / minor
"""


@dataclass
class TestResult:
    __test__ = False
    name: str
    passed: bool
    duration_seconds: float
    error: Optional[str] = None
    behaviour: Optional[str] = None  # plain-English behaviour being tested
    analysis: Optional[str] = None   # Claude's failure analysis


class TesterAgent:
    """
    Autonomous Tester Agent for VaultLayer.
    Knows only the problem statement. Discovers the codebase itself.
    Generates and runs behaviour-driven tests using Claude.
    """
    __test__ = False

    def __init__(self):
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise EnvironmentError(
                "ANTHROPIC_API_KEY required for Tester Agent — "
                "it uses Claude to discover the codebase and generate tests"
            )
        self._claude = anthropic.Anthropic(api_key=api_key)
        self.results: list[TestResult] = []
        self._discovery: dict = {}
        self._generated_tests: str = ""

    # ── Phase 1: Discovery ─────────────────────────────────────────────────

    def _read_codebase(self) -> str:
        """Read all Python source files and return as a single string."""
        src_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..')
        src_dir = os.path.abspath(src_dir)
        files_content = []
        for root, dirs, files in os.walk(os.path.join(src_dir, 'src')):
            # Skip __pycache__ and tester itself
            dirs[:] = [d for d in dirs if d != '__pycache__']
            for f in sorted(files):
                if f.endswith('.py') and 'tester' not in root:
                    path = os.path.join(root, f)
                    rel_path = os.path.relpath(path, src_dir)
                    try:
                        content = open(path).read()
                        files_content.append(f"# FILE: {rel_path}\n{content}")
                    except Exception:
                        pass
        return "\n\n" + "="*60 + "\n\n".join(files_content)

    def _discover(self) -> dict:
        """Use Claude to understand the codebase structure."""
        print("  Phase 1: Discovering codebase with Claude...", flush=True)
        codebase = self._read_codebase()

        # Truncate if too long (keep most important files)
        if len(codebase) > 80000:
            codebase = codebase[:80000] + "\n\n[TRUNCATED]"

        response = self._claude.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            messages=[{
                "role": "user",
                "content": DISCOVERY_PROMPT.format(
                    problem_statement=PROBLEM_STATEMENT,
                    codebase=codebase
                )
            }]
        )
        raw = response.content[0].text.strip()
        # Strip markdown fences if present
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
            raw = raw.rstrip("`").strip()
        try:
            self._discovery = json.loads(raw)
        except json.JSONDecodeError:
            # If Claude didn't return clean JSON, use the raw text
            self._discovery = {"raw_discovery": raw, "testable_behaviours": []}
        print(f"  Discovered {len(self._discovery.get('testable_behaviours', []))} testable behaviours")
        return self._discovery

    # ── Phase 2: Test Generation ───────────────────────────────────────────

    def _generate_tests(self) -> str:
        """Use Claude to generate test code based on discovered behaviours."""
        print("  Phase 2: Generating tests with Claude...", flush=True)
        response = self._claude.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            messages=[{
                "role": "user",
                "content": TEST_GENERATION_PROMPT.format(
                    discovery=json.dumps(self._discovery, indent=2),
                    problem_statement=PROBLEM_STATEMENT
                )
            }]
        )
        code = response.content[0].text.strip()
        if code.startswith("```"):
            code = code.split("```")[1]
            if code.startswith("python"):
                code = code[6:]
            code = code.rstrip("`").strip()
        self._generated_tests = code
        # Count test functions
        test_count = code.count("async def test_") + code.count("def test_")
        print(f"  Generated {test_count} test functions")
        return code

    # ── Phase 3: Execution ─────────────────────────────────────────────────

    def _execute_tests(self, test_code: str) -> list[TestResult]:
        """Write generated tests to a temp file and execute them."""
        import tempfile, time
        print("  Phase 3: Running generated tests...\n")

        # Write to temp file
        with tempfile.NamedTemporaryFile(
            mode='w', suffix='_vaultlayer_tests.py',
            delete=False, dir='/tmp'
        ) as f:
            f.write(test_code)
            test_file = f.name

        # Run with pytest and capture output
        result = subprocess.run(
            [sys.executable, "-m", "pytest", test_file, "-v",
             "--tb=short", "--no-header", "--json-report",
             f"--json-report-file=/tmp/vl_test_report.json"],
            capture_output=True, text=True, timeout=120
        )

        # Parse results
        results = []
        try:
            with open("/tmp/vl_test_report.json") as f:
                report = json.load(f)
            for test in report.get("tests", []):
                name = test["nodeid"].split("::")[-1]
                passed = test["outcome"] == "passed"
                duration = test.get("duration", 0)
                error = None
                if not passed:
                    error = test.get("call", {}).get("longrepr", "Unknown error")
                    if isinstance(error, dict):
                        error = error.get("reprtext", str(error))
                results.append(TestResult(
                    name=name,
                    passed=passed,
                    duration_seconds=round(duration, 2),
                    error=error
                ))
        except Exception:
            # pytest-json-report not available — parse output manually
            for line in result.stdout.split("\n"):
                if " PASSED" in line or " FAILED" in line:
                    name = line.split("::")[1].split(" ")[0] if "::" in line else line
                    passed = "PASSED" in line
                    error = None
                    if not passed:
                        error = "See output above"
                    results.append(TestResult(
                        name=name, passed=passed,
                        duration_seconds=0, error=error
                    ))

        if not results:
            # Fallback: check return code
            results.append(TestResult(
                name="test_suite_execution",
                passed=result.returncode == 0,
                duration_seconds=0,
                error=result.stdout[-2000:] + result.stderr[-500:]
                      if result.returncode != 0 else None
            ))

        return results

    def _analyze_failures(self, results: list[TestResult]):
        """Use Claude to analyze failed tests in product terms."""
        failures = [r for r in results if not r.passed]
        if not failures:
            return
        print(f"\n  Analyzing {len(failures)} failure(s) with Claude...")
        for result in failures:
            try:
                response = self._claude.messages.create(
                    model="claude-sonnet-4-20250514",
                    max_tokens=500,
                    messages=[{
                        "role": "user",
                        "content": FAILURE_ANALYSIS_PROMPT.format(
                            test_name=result.name,
                            error=result.error or "Unknown",
                            problem_statement=PROBLEM_STATEMENT
                        )
                    }]
                )
                result.analysis = response.content[0].text.strip()
            except Exception as e:
                result.analysis = f"Analysis unavailable: {e}"

    # ── Main ────────────────────────────────────────────────────────────────

    async def run(self) -> bool:
        print("\n" + "="*60)
        print("  VaultLayer Autonomous Tester Agent")
        print("  " + datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"))
        print("  Mode: Claude-driven discovery + test generation")
        print("="*60 + "\n")

        # Phase 1: Discover
        self._discover()

        # Phase 2: Generate
        test_code = self._generate_tests()

        # Save generated tests for inspection
        with open("/tmp/vaultlayer_generated_tests.py", "w") as f:
            f.write(test_code)
        print("  Generated tests saved to: /tmp/vaultlayer_generated_tests.py\n")

        # Phase 3: Execute
        self.results = self._execute_tests(test_code)

        # Analyze failures
        self._analyze_failures(self.results)

        # Print results
        self._print_results()
        return all(r.passed for r in self.results)

    def _print_results(self):
        passed = sum(1 for r in self.results if r.passed)
        failed = sum(1 for r in self.results if not r.passed)
        total = len(self.results)

        print("\n" + "="*60)
        print(f"  RESULTS: {passed}/{total} passed")

        for r in self.results:
            icon = "✓" if r.passed else "✗"
            print(f"  {icon} {r.name} ({r.duration_seconds}s)")

        if failed:
            print(f"\n  FAILURES ({failed}):")
            for r in self.results:
                if not r.passed:
                    print(f"\n  ✗ {r.name}")
                    print(f"    Error: {(r.error or '')[:200]}")
                    if r.analysis:
                        print(f"    Analysis: {r.analysis[:300]}")

        print("="*60 + "\n")

    def report(self) -> dict:
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "discovery": self._discovery,
            "total": len(self.results),
            "passed": sum(1 for r in self.results if r.passed),
            "failed": sum(1 for r in self.results if not r.passed),
            "results": [
                {"name": r.name, "passed": r.passed,
                 "duration": r.duration_seconds,
                 "error": r.error, "analysis": r.analysis}
                for r in self.results
            ]
        }
