"""
VaultLayer — Orchestration Agent (The Orchestrator)
The central brain. Receives all events, makes all decisions.
Claude coverage: ~20% (borderline arbitrage only — see _is_borderline_arbitrage)

Provider selection is deterministic code, not LLM inference:
  - TERMINATION_SIGNAL / HEARTBEAT_MISS → always migrate, no Claude
  - Arbitrage savings ≥ AUTO_MIGRATE_SAVINGS_PCT → always migrate, no Claude
  - Arbitrage savings in (BORDERLINE_LOW, AUTO_MIGRATE_SAVINGS_PCT) AND job >80% done → Claude
  - Arbitrage savings < BORDERLINE_LOW → hold, no Claude

Renamed from: Station Agent
"""

import asyncio
import os
import json
import logging
import time
from typing import Optional, Tuple, Dict, List
from datetime import datetime

import anthropic

from shared.config import VaultLayerConfig
from shared.models import (
    AgentEvent, EventType, OrchestrationDecision, ActionTier,
    Provider, GPUType, Job, JobStatus
)
from shared.queue import AgentQueue, make_event
from agents.orchestration.prompts import DECISION_PROMPT, MIGRATION_PLAN_PROMPT
from agents.orchestration.egress import (
    golden_ratio, compute_resume_cost, rank_candidates_by_resume_cost,
    PAYBACK_THRESHOLD_HOURS,
)
from agents.orchestration.decisions import (
    _rule_based_decision as _decisions_rule_based,
    _select_provider as _decisions_select_provider,
    _log_resume_cost_breakdown as _decisions_log_resume_cost,
    _make_deterministic_decision as _decisions_make_deterministic,
    _make_borderline_decision as _decisions_make_borderline,
    _make_hold_decision as _decisions_make_hold,
    MIN_MIGRATION_MARGIN_PCT,
    MAX_PRICE_DATA_AGE_SECONDS,
)
from agents.namespace.agent import NamespaceAgent
from shared.telemetry import make_telemetry, MetricCategory

logger = logging.getLogger(__name__)

# GTM Gap 3: Cloud-side heartbeat monitor threshold.
# If no heartbeat is seen from a running job for this many seconds, the
# OrchestrationAgent (running on VaultLayer's secure infra) publishes HEARTBEAT_MISS
# independently -- even if the WatchdogAgent on the node died with the node.
HEARTBEAT_TIMEOUT_SECONDS = 90


class OrchestrationAgent:
    """
    The Orchestration Agent — central brain of VaultLayer.
    Subscribes to ALL channels. The only agent that commands others.

    Provider selection is deterministic code (sorted price cache, availability filter).
    Claude is invoked ONLY for borderline arbitrage (savings 15-25% + job >80% done).
    All other decisions (termination signal, heartbeat miss, clear-cut savings) are
    rule-based with no LLM call — sub-millisecond, no API cost, no rate-limit risk.

    Publishes to:  vaultlayer:orchestration.command  (to Broker, Vault)
                   vaultlayer:orchestration.escalate (to human)
    Listens to:    all channels
    """

    AGENT_NAME = "orchestration_agent"
    LISTEN_CHANNELS = ["pricing", "watchdog", "broker", "vault", "finops", "namespace"]

    # ── Deterministic thresholds (no Claude needed outside these bounds) ─────────
    # Savings ≥ this → always auto-migrate without LLM
    AUTO_MIGRATE_SAVINGS_PCT = 25.0
    # Savings in [BORDERLINE_LOW, AUTO_MIGRATE_SAVINGS_PCT) AND job>80% done → use Claude
    # e.g. 18% savings + job 90% done → Claude; 18% + job 30% done → auto-migrate
    BORDERLINE_LOW_SAVINGS_PCT = 15.0
    # Below BORDERLINE_LOW → hold (not worth migration overhead)
    # Job progress threshold above which Claude evaluates borderline cases
    BORDERLINE_PROGRESS_PCT = 80.0

    # Preferred same-cloud regions to try first before cross-cloud migration
    _SAME_PROVIDER_PRIORITY = True  # try same provider, different AZ/region first

    # GAP-28: Rapid failure detection (code bug vs infra failure)
    RAPID_FAILURE_WINDOW_SECS = 600   # 10 minutes
    RAPID_FAILURE_THRESHOLD = 3       # 3 crashes in window = likely user code bug

    # GAP-31: Event schema version supported by this agent
    SUPPORTED_SCHEMA_VERSION = 1

    def __init__(self, config: VaultLayerConfig, queue: AgentQueue):
        self.config = config
        self.queue = queue
        self._arbitrage_seen: dict = {}   # key: "provider:gpu" -> last_acted_timestamp
        self._arbitrage_this_poll: int = 0
        self._last_poll_ts: float = float("-inf")  # ensures first poll reset always fires
        # Claude is optional — only used when ANTHROPIC_API_KEY is set AND
        # the rule engine hits genuine ambiguity (borderline savings, late-stage job).
        self._claude = (
            anthropic.Anthropic(api_key=config.anthropic.api_key)
            if config.anthropic and config.anthropic.api_key
            else None
        )
        self._namespace_agent: Optional[NamespaceAgent] = None
        self._tel = make_telemetry(queue=queue, agent_name="orchestration_agent")
        self._decisions: list[OrchestrationDecision] = []
        self._active_jobs: dict[str, Job] = {}
        # Governance: tracks when each job last had a voluntary migration executed
        self._last_migration_at: Dict[str, float] = {}  # job_id -> monotonic timestamp
        # GAP-28: Crash history for rapid-failure detection
        self._job_crash_history: Dict[str, List[float]] = {}  # job_id -> [crash_timestamps]
        # Egress verdict stash — set by _select_provider, read by _make_deterministic_decision
        self._last_egress_verdict = None
        self._last_resume_estimate = None

    # -- GAP-28: Rapid failure (code error) detection --------------------------

    def _record_crash(self, job_id: str) -> None:
        if job_id not in self._job_crash_history:
            self._job_crash_history[job_id] = []
        self._job_crash_history[job_id].append(time.time())

    def _is_rapid_failure(self, job_id: str) -> bool:
        now = time.time()
        history = self._job_crash_history.get(job_id, [])
        recent = [t for t in history if now - t < self.RAPID_FAILURE_WINDOW_SECS]
        return len(recent) >= self.RAPID_FAILURE_THRESHOLD

    # -- GAP-31: Schema version check ------------------------------------------

    def _check_schema_version(self, event: AgentEvent) -> bool:
        if getattr(event, "schema_version", 1) > self.SUPPORTED_SCHEMA_VERSION:
            logger.error(
                f"[Orchestration] Received event with schema_version="
                f"{event.schema_version} but only version {self.SUPPORTED_SCHEMA_VERSION} "
                f"is supported. Upgrade VaultLayer CLI."
            )
            return False
        return True

    async def handle_event(self, event: AgentEvent):
        # GAP-31: Reject events from newer (incompatible) CLI versions
        if not self._check_schema_version(event):
            return

        self._tel.counter("orchestration.events_received",
                          tags={"event_type": event.event_type.value})
        logger.info(f"Orchestration received: {event.event_type} from {event.source_agent}")
        action_events = {
            EventType.TERMINATION_SIGNAL, EventType.HEARTBEAT_MISS,
            EventType.ARBITRAGE_OPPORTUNITY, EventType.NAMESPACE_SYNC_COMPLETE,
            EventType.OOM_DETECTED, EventType.GPU_FAILURE, EventType.HUNG_JOB,
            EventType.GPU_HOP_AVAILABLE,
        }
        info_events = {EventType.CHECKPOINT_COMPLETE, EventType.NODE_HEALTHY, EventType.PRICE_UPDATE, EventType.MIGRATION_COMPLETE, EventType.JOB_COST_UPDATE, EventType.NODE_PROVISIONED}
        if event.event_type in action_events:
            decision = await self._route_event(event)
            if decision is None:
                return  # filtered/skipped (backpressure, governance, below threshold)
            await self._execute_decision(decision, event)
            # Escalate low-confidence decisions
            if hasattr(decision, 'requires_human_confirmation') and decision.requires_human_confirmation:
                await self._escalate_to_human(decision, event)
            try:
                self._tel.decision(
                    action=decision.action,
                    confidence=getattr(decision, "confidence", 0),
                    outcome="executed",
                    savings_usd=getattr(decision, "estimated_savings_per_hour", 0),
                    job_id=event.job_id,
                    tags={"tier": decision.tier.value if hasattr(decision, "tier") and decision.tier else "unknown"},
                )
            except Exception:
                pass
        elif event.event_type in info_events:
            await self._update_state(event)

    async def _route_event(self, event: AgentEvent):
        """
        Central routing: decides whether to use deterministic logic or Claude.

        Decision matrix:
          TERMINATION_SIGNAL / HEARTBEAT_MISS / NAMESPACE_SYNC_COMPLETE
            → always migrate deterministically (no Claude)
          ARBITRAGE_OPPORTUNITY with savings ≥ AUTO_MIGRATE_SAVINGS_PCT (25%)
            → always migrate deterministically (no Claude)
          ARBITRAGE_OPPORTUNITY with savings in [BORDERLINE_LOW (15%), 25%) AND job >80%
            → Claude (borderline judgment needed)
          ARBITRAGE_OPPORTUNITY savings < BORDERLINE_LOW (15%)
            → hold (not worth migration overhead)
        """
        import time
        job_id = event.job_id or ""

        # ── Urgent events: always migrate, no Claude ─────────────────────────────
        if event.event_type in (EventType.TERMINATION_SIGNAL, EventType.HEARTBEAT_MISS):
            # GAP-28: Check for rapid failure pattern before migrating
            if event.event_type == EventType.TERMINATION_SIGNAL and job_id:
                self._record_crash(job_id)
                # Also check exit code: non-SIGTERM exit in <120s = likely code bug
                exit_code = event.payload.get("exit_code")
                job_age_secs = event.payload.get("job_age_secs", 999)
                is_code_error = (
                    exit_code is not None
                    and exit_code != -15  # -15 = SIGTERM (expected for spot termination)
                    and job_age_secs < 120
                )
                if self._is_rapid_failure(job_id) or is_code_error:
                    logger.warning(
                        f"[Orchestration] Rapid failure detected for {job_id} — "
                        f"likely user code bug, not infra. Escalating instead of migrating."
                    )
                    escalate_reason = "rapid_failure_suspected_user_code_bug"
                    return await self._escalate(event, reason=escalate_reason)

            reason = (
                "Spot termination signal — immediate migration required"
                if event.event_type == EventType.TERMINATION_SIGNAL
                else "Heartbeat miss — job may be hung or OOM; migrating to healthy node"
            )
            # Emit resume-cost breakdown before migrating so the decision log
            # shows compute + egress for every candidate (Golden Ratio applied).
            job_obj = self._active_jobs.get(job_id)
            if job_obj:
                price_cache_preview = await self.queue.get_price_cache() or []
                self._log_resume_cost_breakdown(job_obj, price_cache_preview)
            return await self._make_deterministic_decision(event, reason, confidence=0.99)

        if event.event_type == EventType.NAMESPACE_SYNC_COMPLETE:
            return await self._make_deterministic_decision(
                event,
                "Checkpoint sync complete — warm-starting on replacement node",
                confidence=0.99,
            )

        # ── Hardware/software failures: migrate to healthy node ──────────────────
        if event.event_type in (EventType.OOM_DETECTED, EventType.GPU_FAILURE, EventType.HUNG_JOB):
            if job_id:
                self._record_crash(job_id)
                if self._is_rapid_failure(job_id):
                    logger.warning(
                        f"[Orchestration] Rapid {event.event_type.value} for {job_id} — "
                        f"escalating instead of infinite migrate."
                    )
                    return await self._escalate(event, reason=f"rapid_{event.event_type.value}")

            _failure_reasons = {
                EventType.OOM_DETECTED:  "GPU out-of-memory — migrating to node with more VRAM",
                EventType.GPU_FAILURE:   "GPU hardware failure — migrating to healthy GPU node",
                EventType.HUNG_JOB:      "Job hung with no progress — migrating to fresh node",
            }
            reason = _failure_reasons[event.event_type]
            job_obj = self._active_jobs.get(job_id)
            if job_obj:
                price_cache_preview = await self.queue.get_price_cache() or []
                self._log_resume_cost_breakdown(job_obj, price_cache_preview)
            return await self._make_deterministic_decision(event, reason, confidence=0.97)

        # ── GPU hot-swap: target GPU is now available, trigger migration ────────────
        if event.event_type == EventType.GPU_HOP_AVAILABLE:
            target_gpu  = event.payload.get("target_gpu", "")
            fallback_gpu = event.payload.get("fallback_gpu", "")
            provider    = event.payload.get("provider", "")
            region      = event.payload.get("region", "")
            logger.info(
                f"[Orchestration] GPU_HOP_AVAILABLE job={job_id} "
                f"target={target_gpu} provider={provider} region={region}"
            )
            return await self._make_deterministic_decision(
                event,
                reason=(
                    f"User-consented GPU hop: {fallback_gpu} → {target_gpu} is now available "
                    f"on {provider} ({region}). Migrating to complete hot-swap. "
                    f"Billing switches to {target_gpu} rate at job resume. Migration is $0.00."
                ),
                confidence=0.99,
            )

        # ── Arbitrage: backpressure + governance gates ────────────────────────────
        if event.event_type == EventType.ARBITRAGE_OPPORTUNITY:
            now = time.monotonic()
            # Reset per-poll counter every 60s
            if now - self._last_poll_ts > 60:
                self._arbitrage_this_poll = 0
                self._last_poll_ts = now
            if self._arbitrage_this_poll >= self._ARBITRAGE_MAX_PER_POLL:
                logger.debug(f"Arbitrage backpressure: skipping (max {self._ARBITRAGE_MAX_PER_POLL}/poll reached)")
                return None
            dedup_key = f"{event.payload.get('provider','?')}:{event.payload.get('gpu','?')}"
            last_acted = self._arbitrage_seen.get(dedup_key, float("-inf"))
            if now - last_acted < self._ARBITRAGE_DEDUP_WINDOW_SECS:
                logger.debug(f"Arbitrage dedup: skipping {dedup_key} (acted {now-last_acted:.0f}s ago)")
                return None
            self._arbitrage_seen[dedup_key] = now
            self._arbitrage_this_poll += 1

            # 6-hour cooldown per job
            last_mig = self._last_migration_at.get(job_id, float("-inf"))
            if now - last_mig < self._MIGRATION_COOLDOWN_SECS:
                cooldown_remaining = int(self._MIGRATION_COOLDOWN_SECS - (now - last_mig))
                logger.info(
                    f"Governance: skipping arbitrage for job {job_id} — "
                    f"cooldown active ({cooldown_remaining}s remaining)"
                )
                return None

            opps = event.payload.get("opportunities", [])
            best_savings_pct = max((o.get("savings_pct", 0.0) for o in opps), default=0.0)

            # ── Price guard: hard-block on stale or negative margin ───────────────
            # Validate that the best opportunity has positive actual savings.
            # A negative margin means target_price >= current_price (stale data).
            # A sub-5% margin means VaultLayer's gainshare cut could turn the user's
            # "savings" into a net loss once egress and secondary costs are factored in.
            best_opp = max(opps, key=lambda o: o.get("savings_pct", 0.0), default={})
            current_pph = best_opp.get("current_price_per_hour", 0.0)
            target_pph  = best_opp.get("target_price_per_hour", 0.0)
            price_data_age = event.payload.get("price_data_age_seconds", 0.0)

            if current_pph > 0 and target_pph >= current_pph:
                logger.warning(
                    f"[price-guard] job {job_id}: target ${target_pph:.3f}/hr >= "
                    f"current ${current_pph:.3f}/hr — migration hard-blocked "
                    f"(negative margin, likely stale prices)"
                )
                return None

            if price_data_age > MAX_PRICE_DATA_AGE_SECONDS:
                logger.warning(
                    f"[price-guard] job {job_id}: price data is {price_data_age:.0f}s old "
                    f"(max {MAX_PRICE_DATA_AGE_SECONDS}s) — migration hard-blocked until refresh"
                )
                return None

            if best_savings_pct < MIN_MIGRATION_MARGIN_PCT:
                logger.warning(
                    f"[price-guard] job {job_id}: savings {best_savings_pct:.2f}% < "
                    f"minimum margin {MIN_MIGRATION_MARGIN_PCT}% — migration hard-blocked "
                    f"(gainshare math: migration would not cover egress+secondary costs)"
                )
                return None
            # ─────────────────────────────────────────────────────────────────────

            # Below floor → not worth migration overhead
            if best_savings_pct < self.BORDERLINE_LOW_SAVINGS_PCT:
                logger.info(
                    f"Governance: holding job {job_id} — "
                    f"savings {best_savings_pct:.1f}% < floor {self.BORDERLINE_LOW_SAVINGS_PCT}%"
                )
                return None

            # Clear win → deterministic migrate, no Claude
            if best_savings_pct >= self.AUTO_MIGRATE_SAVINGS_PCT:
                reason = (
                    f"Arbitrage: {best_savings_pct:.1f}% savings exceeds auto-migrate "
                    f"threshold ({self.AUTO_MIGRATE_SAVINGS_PCT}%) — migrating deterministically"
                )
                logger.info(f"Deterministic migrate: job {job_id} — {reason}")
                return await self._make_deterministic_decision(event, reason, confidence=0.92)

            # Borderline: savings 15-25% — apply rule engine; Claude as optional enhancement
            job = self._active_jobs.get(job_id)
            progress_pct = job.progress_pct if job else 0.0
            if progress_pct > self.BORDERLINE_PROGRESS_PCT:
                return await self._make_borderline_decision(
                    event, job, best_savings_pct, opps
                )
            else:
                # Early-stage job with modest savings → auto-migrate
                reason = (
                    f"Arbitrage: {best_savings_pct:.1f}% savings, job only {progress_pct:.0f}% done "
                    f"— auto-migrating (borderline savings but low progress risk)"
                )
                logger.info(f"Deterministic migrate (early stage): job {job_id} — {reason}")
                return await self._make_deterministic_decision(event, reason, confidence=0.85)

        return None  # unrecognised action event

    def _select_provider(
        self,
        price_cache: list,
        job_id: str,
        current_provider: Optional[Provider] = None,
        emergency: bool = False,
    ) -> Tuple[Optional[Provider], Optional[GPUType], float, float]:
        """Egress-aware provider selection. Delegates to decisions module."""
        return _decisions_select_provider(self, price_cache, job_id, current_provider, emergency)

    def _log_resume_cost_breakdown(self, job: Job, price_cache: list) -> None:
        """Emit structured resume-cost breakdown. Delegates to decisions module."""
        _decisions_log_resume_cost(self, job, price_cache)

    async def _make_deterministic_decision(
        self,
        event: AgentEvent,
        reason: str,
        confidence: float = 0.95,
    ) -> OrchestrationDecision:
        """Build a migration decision without Claude. Delegates to decisions module."""
        return await _decisions_make_deterministic(self, event, reason, confidence)

    async def _make_borderline_decision(
        self,
        event: AgentEvent,
        job: Optional[Job],
        savings_pct: float,
        opps: list,
    ) -> OrchestrationDecision:
        """Borderline arbitrage zone rules. Delegates to decisions module."""
        return await _decisions_make_borderline(self, event, job, savings_pct, opps)

    async def _make_hold_decision(
        self, event: AgentEvent, reason: str, confidence: float = 0.80
    ) -> OrchestrationDecision:
        """Build a hold decision without Claude. Delegates to decisions module."""
        return await _decisions_make_hold(self, event, reason, confidence)

    def _rule_based_decision(self, event) -> object:
        """Legacy fallback -- kept for compatibility with existing test mocks."""
        return _decisions_rule_based(self, event)

    async def _make_decision(self, event: AgentEvent) -> OrchestrationDecision:
        """
        Call Claude for genuinely ambiguous decisions.
        Only reached when the rule engine cannot resolve with confidence.
        Requires ANTHROPIC_API_KEY — callers must check self._claude is not None.
        """
        if not self._claude or not self.config.anthropic:
            raise RuntimeError("Claude not configured (ANTHROPIC_API_KEY not set)")

        jobs_summary = self._summarise_jobs()
        pricing = await self.queue.get_price_cache() or []
        recent_events = await self.queue.get_history("watchdog", limit=5)
        recent_events += await self.queue.get_history("pricing", limit=3)
        tel_summary = await self._tel.get_summary()
        prompt = DECISION_PROMPT.format(
            jobs=json.dumps(jobs_summary, default=str),
            pricing=json.dumps(pricing, default=str),
            availability=json.dumps(self._get_availability(pricing)),
            recent_events=json.dumps([e.model_dump(mode="json") for e in recent_events[-8:]], default=str),
            event=json.dumps(event.model_dump(mode="json"), default=str),
            telemetry_summary=json.dumps(tel_summary, default=str),
        )
        response = self._claude.messages.create(
            model=self.config.anthropic.model,
            max_tokens=600,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = response.content[0].text.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        data = json.loads(raw.strip())
        confidence = data.get("confidence", 0.0)
        tier = (
            ActionTier.AUTO if confidence >= self.config.confidence_threshold_auto
            else ActionTier.AUTO_NOTIFY if confidence >= self.config.confidence_threshold_notify
            else ActionTier.CONFIRM
        )
        tp = data.get("target_provider")
        tg = data.get("target_gpu")
        decision = OrchestrationDecision(
            job_id=event.job_id or "unknown",
            action=data["action"],
            reasoning=data["reasoning"],
            action_plan=data.get("action_plan", []),
            confidence=confidence,
            tier=tier,
            target_provider=Provider(tp) if tp and tp != "null" else None,
            target_gpu=GPUType(tg) if tg and tg != "null" else None,
            estimated_savings_per_hour=data.get("estimated_savings_per_hour", 0.0),
            estimated_downtime_minutes=data.get("estimated_downtime_minutes", 0.0),
            requires_human_confirmation=(tier == ActionTier.CONFIRM),
        )
        self._decisions.append(decision)
        logger.info(f"Claude decision: {decision.action} conf={decision.confidence:.2f} tier={decision.tier}")
        return decision

    async def _execute_decision(self, decision, trigger_event):
        """
        Execute a decision by publishing to the orchestration channel.
        Escalations go to the escalate channel.
        """
        if not hasattr(decision, "action"):
            logger.warning("_execute_decision: invalid decision object")
            return

        job_id = trigger_event.job_id or ""
        action = decision.action
        tier = getattr(decision, "tier", None)

        if action in ("migrate", "MIGRATE"):
            target_provider = getattr(decision, "target_provider", None)
            target_gpu = getattr(decision, "target_gpu", None)

            if not job_id:
                # Arbitrage signals are market data — no specific job to migrate.
                # Migration is only triggered by TERMINATION_SIGNAL / HEARTBEAT_MISS
                # which always carry a job_id. Skip silently.
                logger.debug("_execute_decision: arbitrage signal has no job_id — skipping migrate")
                return

            logger.info(f"Executing migration decision: job={job_id} -> {target_provider} ({target_gpu})")

            migrate_event = make_event(
                event_type=EventType.MIGRATION_REQUESTED,
                source_agent=self.AGENT_NAME,
                job_id=job_id,
                payload={
                    "command": action,
                    "target_provider": target_provider.value if hasattr(target_provider, "value") else (target_provider or ""),
                    "target_gpu": target_gpu.value if hasattr(target_gpu, "value") else (target_gpu or ""),
                    "decision_confidence": getattr(decision, "confidence", 0),
                    "decision_reasoning": getattr(decision, "reasoning", ""),
                },
                priority=1,
            )
            # Publish to orchestration channel for audit/tracking
            await self.queue.publish("orchestration", migrate_event)
            # Publish to broker critical stream for durable delivery
            await self.queue.publish_critical("broker", migrate_event)
            # Record migration timestamp for per-job cooldown governance
            import time as _time
            self._last_migration_at[job_id] = _time.monotonic()
        elif action in ("checkpoint", "CHECKPOINT"):
            logger.info(f"Executing checkpoint decision: job={job_id}")
            await self.queue.publish("orchestration", make_event(
                event_type=EventType.CHECKPOINT_REQUESTED,
                source_agent=self.AGENT_NAME,
                job_id=job_id,
                payload={
                    "command": "checkpoint",
                    "target_agent": "vault_agent",
                    "decision_confidence": getattr(decision, "confidence", 0),
                    "decision_reasoning": getattr(decision, "reasoning", ""),
                },
                priority=1,
            ))
        elif action in ("escalate", "ESCALATE"):
            if hasattr(decision, "job_id"):
                await self._escalate_to_human(decision, trigger_event)
            else:
                await self.queue.publish("escalate", make_event(
                    event_type=EventType.ESCALATION,
                    source_agent=self.AGENT_NAME,
                    job_id=job_id,
                    payload={
                        "reasoning": getattr(decision, "reasoning", ""),
                        "confidence": getattr(decision, "confidence", 0),
                        "action_plan": getattr(decision, "action_plan", []),
                    },
                    priority=1,
                ))
            logger.info(f"Decision escalated to human for job {job_id}")
        elif action in ("hold", "HOLD"):
            logger.debug(f"Decision: hold job {job_id} -- {getattr(decision, 'reasoning', 'no reason')}")
        else:
            logger.warning(f"Unknown decision action: {action}")

        # Always record telemetry
        try:
            self._tel.decision(
                action=action,
                confidence=getattr(decision, "confidence", 0),
                outcome="dispatched",
                savings_usd=getattr(decision, "estimated_savings_per_hour", 0),
                job_id=job_id,
            )
        except Exception:
            pass
    async def _escalate(self, event: AgentEvent, reason: str) -> OrchestrationDecision:
        """Publish escalation event and return a no-op decision object."""
        await self.queue.publish("escalate", make_event(
            event_type=EventType.ESCALATION,
            source_agent=self.AGENT_NAME,
            job_id=event.job_id,
            payload={"reason": reason, "original_event": event.event_type.value},
            priority=2,
        ))
        decision = OrchestrationDecision(
            job_id=event.job_id or "unknown",
            action="escalate",
            reasoning=reason,
            action_plan=[f"Escalated: {reason}"],
            confidence=0.5,
            tier=ActionTier.CONFIRM,
            requires_human_confirmation=True,
        )
        self._decisions.append(decision)
        return decision

    async def _escalate_to_human(self, decision: OrchestrationDecision, event: AgentEvent):
        await self.queue.publish("escalate", make_event(event_type=EventType.ESCALATION, source_agent=self.AGENT_NAME, job_id=decision.job_id, payload={"decision_id": decision.decision_id, "reasoning": decision.reasoning, "action_plan": decision.action_plan, "confidence": decision.confidence}, priority=1))

    async def _update_state(self, event: AgentEvent):
        if event.event_type == EventType.NODE_PROVISIONED and event.job_id:
            # Broker publishes NODE_PROVISIONED to "broker" channel (Rule 3 compliance).
            # OrchestrationAgent forwards it to "orchestration" so VaultAgent can trigger
            # checkpoint restore on the new node.
            logger.info(f"Forwarding NODE_PROVISIONED restore command to orchestration for job {event.job_id}")
            await self.queue.publish("orchestration", make_event(
                event_type=EventType.NODE_PROVISIONED,
                source_agent=self.AGENT_NAME,
                job_id=event.job_id,
                payload=event.payload,
                priority=1,
            ))
            return

        if event.event_type == EventType.CHECKPOINT_COMPLETE and event.job_id:
            logger.info(f"Checkpoint complete: {event.job_id}")
            # P0-L1: Notify broker that the checkpoint is in R2 and safe to prefetch.
            # Broker.execute_migration waits on this event (via _checkpoint_events) before
            # running _prefetch_checkpoint + _restart_job_on_node.  This allows provisioning
            # to happen in parallel with checkpoint upload instead of sequentially after.
            await self.queue.publish("orchestration", make_event(
                event_type=EventType.CHECKPOINT_READY,
                source_agent=self.AGENT_NAME,
                job_id=event.job_id,
                payload={
                    "checkpoint_step": event.payload.get("step", 0),
                    "checkpoint_r2_key": event.payload.get("r2_key", ""),
                    "forwarded_from": "checkpoint_complete",
                },
                priority=1,
            ))

    def _summarise_jobs(self) -> list:
        return [{"job_id": j.job_id, "name": j.name, "status": j.status.value, "provider": j.provider.value, "progress_pct": j.progress_pct, "current_step": j.current_step, "model_params_billion": j.model_params_billion} for j in self._active_jobs.values()]

    def _get_availability(self, prices: list) -> dict:
        return {f"{p.get('provider')}_{p.get('gpu')}": p.get("availability", "unknown") for p in prices if isinstance(p, dict)}

    def register_job(self, job: Job):
        self._active_jobs[job.job_id] = job
        logger.info(f"Tracking: {job.name}")

    async def _consume_critical_loop(self) -> None:
        """Process durable critical events (migration, node provisioned) with at-least-once delivery."""
        consumer_name = f"orchestration-{os.getpid()}"
        try:
            await self.queue.consume_critical(consumer_name, self._handle_critical_event, channel_key="orchestration")
        except Exception as e:
            logger.error(f"Critical event consumer failed: {e}")

    # Event types that come FROM orchestration decisions -- routing these back through
    # handle_event would create an infinite loop (decide -> publish -> decide -> ...)
    _OUTBOUND_EVENT_TYPES = {"migration_requested", "migration_started"}
    _ARBITRAGE_MAX_PER_POLL = 5  # max migrations per poll cycle
    _ARBITRAGE_DEDUP_WINDOW_SECS = 300  # 5 min dedup window

    # Hard governance limits — prevent migration loops and ensure only genuine savings trigger moves
    _MIGRATION_COOLDOWN_SECS = 21600   # 6 hours per job between voluntary (arbitrage) migrations
    _MIGRATION_MIN_SAVINGS_PCT = 15.0  # kept for backward compat; _route_event uses BORDERLINE_LOW_SAVINGS_PCT

    async def _handle_critical_event(self, fields: dict) -> None:
        """Handle a critical event from the Redis Stream."""
        import json
        try:
            event_type_str = fields.get("event_type", "")
            payload = json.loads(fields.get("payload", "{}"))
            job_id = fields.get("job_id", "")
            logger.info(f"Critical event received: {event_type_str} job={job_id}")
            # Guard: skip events that orchestration itself published to avoid infinite loop
            if event_type_str.lower() in self._OUTBOUND_EVENT_TYPES:
                logger.debug(f"Critical stream: skipping outbound event {event_type_str} (would loop)")
                return
            # Route to existing handle_event infrastructure
            from shared.models import AgentEvent, EventType
            try:
                et = EventType(event_type_str)
            except ValueError:
                logger.warning(f"Unknown event type in critical stream: {event_type_str}")
                return
            event = AgentEvent(event_type=et, source_agent="critical_stream",
                               job_id=job_id, payload=payload)
            await self.handle_event(event)
        except Exception as e:
            logger.error(f"Critical event handling failed: {e}")
            raise  # re-raise so consume_critical does NOT ack -- message stays for retry

    # ── Credit burn loop ───────────────────────────────────────────────────────

    async def _credit_burn_loop(self) -> None:
        """
        Calls the VaultLayer API burn endpoint every 60 seconds for each running job.
        If the API returns status="exhausted", publishes CREDITS_EXHAUSTED which
        triggers an emergency checkpoint + job suspension (same path as termination signal).
        """
        import httpx

        api_url = os.environ.get("VAULTLAYER_API_URL", "https://vaultlayer-production.up.railway.app")
        burn_interval = 60

        while True:
            await asyncio.sleep(burn_interval)
            for job_id, job in list(self._active_jobs.items()):
                if job.status != JobStatus.RUNNING:
                    continue
                if not job.user_id or not job.current_hourly_rate:
                    continue
                # Refresh job state from Redis to pick up billing_frozen_at changes
                # made by BrokerAgent during migration
                _fresh_state = await self.queue.get_job_state(job_id)
                if _fresh_state:
                    _frozen = _fresh_state.get("billing_frozen_at")
                    if _frozen is not None:
                        continue  # Skip billing while migration is in progress

                raw_token = await self.queue.hget(f"vl:user:{job.user_id}", "token")
                if not raw_token:
                    continue

                try:
                    resp = await asyncio.get_event_loop().run_in_executor(
                        None,
                        lambda: httpx.post(
                            f"{api_url}/api/v1/jobs/{job_id}/burn",
                            headers={"Authorization": f"Bearer {raw_token}"},
                            json={
                                "job_id": job_id,
                                "elapsed_seconds": float(burn_interval),
                                "hourly_rate_usd": job.current_hourly_rate,
                            },
                            timeout=8,
                        ),
                    )
                    resp.raise_for_status()
                    result = resp.json()
                    burn_status = result.get("status", "ok")

                    if burn_status == "exhausted":
                        logger.warning(
                            f"[Orchestration] Credits exhausted for job {job_id} "
                            f"(user {job.user_id}). Triggering emergency checkpoint + suspend."
                        )
                        await self.queue.publish("watchdog", make_event(
                            event_type=EventType.CREDITS_EXHAUSTED,
                            source_agent="orchestration_credit_burn",
                            job_id=job_id,
                            payload={
                                "available_credits": result.get("available_credits", 0),
                                "user_id": job.user_id,
                            },
                            priority=1,
                        ))
                        self._active_jobs.pop(job_id, None)

                    elif burn_status == "low":
                        logger.info(
                            f"[Orchestration] Low credits for job {job_id}: "
                            f"{result.get('available_credits')} remaining."
                        )
                        await self.queue.publish("orchestration", make_event(
                            event_type=EventType.CREDITS_LOW,
                            source_agent="orchestration_credit_burn",
                            job_id=job_id,
                            payload={"available_credits": result.get("available_credits"),
                                     "user_id": job.user_id},
                        ))

                except Exception as e:
                    logger.debug(f"[Orchestration] Credit burn tick failed for {job_id}: {e}")

    async def _heartbeat_monitor_loop(self) -> None:
        """
        Cloud-side external observer. Polls Redis heartbeat keys for all active jobs.
        If last_heartbeat > HEARTBEAT_TIMEOUT_SECONDS ago, publishes HEARTBEAT_MISS
        event directly (does not wait for the node to self-report).

        This is the "who watches the watchdog" fix: the Orchestration Agent on
        VaultLayer's secure infra is the authoritative heartbeat monitor. The
        WatchdogAgent on the node is redundant defense-in-depth.
        """
        while True:
            await asyncio.sleep(30)  # check every 30 seconds
            now = time.time()
            for job_id, job in list(self._active_jobs.items()):
                if job.status not in (JobStatus.RUNNING, JobStatus.MIGRATING):
                    continue
                try:
                    # Read the last heartbeat from Redis (written by record_heartbeat())
                    # Key format: "vl:heartbeat:{job_id}" → JSON with {"ts": unix_timestamp, "step": N}
                    raw = await self.queue.hget(f"vl:heartbeat:{job_id}", "ts")
                    if raw is None:
                        continue  # no heartbeat yet (job just started)
                    last_ts = float(raw)
                    age = now - last_ts
                    if age > HEARTBEAT_TIMEOUT_SECONDS:
                        logger.warning(
                            f"[Orchestration] External heartbeat monitor: job {job_id} "
                            f"last heartbeat {age:.0f}s ago (threshold={HEARTBEAT_TIMEOUT_SECONDS}s). "
                            f"Node may be dead. Publishing HEARTBEAT_MISS."
                        )
                        miss_event = make_event(
                            event_type=EventType.HEARTBEAT_MISS,
                            source_agent="orchestration_heartbeat_monitor",
                            job_id=job_id,
                            payload={
                                "last_heartbeat_age_seconds": age,
                                "detected_by": "cloud_side_monitor",
                                "job_provider": job.provider.value,
                                "instance_id": job.instance_id,
                            },
                            priority=1,
                        )
                        await self.queue.publish("watchdog", miss_event)
                        # Don't re-trigger: remove from active to prevent spam
                        # (orchestration will re-add if job recovers)
                        self._active_jobs.pop(job_id, None)
                except Exception as e:
                    logger.debug(f"[Orchestration] Heartbeat check failed for {job_id}: {e}")

    async def _dlq_retry_loop(self) -> None:
        """
        P0-C5: Dead-letter queue retry loop.

        Every 30 seconds, scans _active_jobs for jobs in INTERRUPTED state whose
        dlq_at timestamp is older than 5 minutes.  For each such job, re-publishes
        a MIGRATION_REQUESTED event so BrokerAgent will try provisioning again.

        This recovers jobs during transient capacity crunches without human intervention.
        BrokerAgent caps the total number of retries via job.max_provision_failures;
        after that cap is reached, it escalates to permanent FAILED.
        """
        DLQ_RETRY_INTERVAL_SECS = 30      # how often we scan for DLQ jobs
        DLQ_BACKOFF_SECS        = 300     # 5 min between retries per job

        while True:
            await asyncio.sleep(DLQ_RETRY_INTERVAL_SECS)
            try:
                from datetime import datetime as _dt, timezone as _tz
                now = _dt.utcnow()
                for job_id, job in list(self._active_jobs.items()):
                    if job.status != JobStatus.INTERRUPTED:
                        continue
                    if job.dlq_at is None:
                        continue
                    # Strip tzinfo for comparison if needed (dlq_at is naive UTC)
                    dlq_ts = job.dlq_at.replace(tzinfo=None) if job.dlq_at.tzinfo else job.dlq_at
                    age_secs = (now - dlq_ts).total_seconds()
                    if age_secs < DLQ_BACKOFF_SECS:
                        continue  # too soon — wait for backoff to expire

                    logger.info(
                        f"[DLQ] Job {job_id} has been INTERRUPTED for {age_secs:.0f}s "
                        f"(attempt {job.provision_failure_count}/{job.max_provision_failures}) "
                        "— re-publishing MIGRATION_REQUESTED"
                    )
                    # Publish to "broker" channel directly — publishing MIGRATION_REQUESTED
                    # to "orchestration" would be silently dropped by _OUTBOUND_EVENT_TYPES guard
                    retry_event = AgentEvent(
                        event_type=EventType.MIGRATION_REQUESTED,
                        source_agent="orchestration_dlq_retry",
                        job_id=job_id,
                        payload={
                            "reason": "dlq_retry",
                            "provision_failure_count": job.provision_failure_count,
                        },
                    )
                    await self.queue.publish("broker", retry_event.model_dump(mode="json"))
                    # Reset dlq_at so we don't fire again until the next failure
                    job.dlq_at = None
                    await self.queue.set_job_state(job_id, job.model_dump(mode="json"))
            except Exception as e:
                logger.debug(f"[DLQ] Retry loop error (non-fatal): {e}")

    async def start(self):
        logger.info("Orchestration Agent starting")
        await self.queue.subscribe(self.LISTEN_CHANNELS, self.handle_event)
        asyncio.create_task(self._heartbeat_monitor_loop(), name="heartbeat-monitor")
        asyncio.create_task(self._credit_burn_loop(), name="credit-burn")
        asyncio.create_task(self._dlq_retry_loop(), name="dlq-retry")

    async def stop(self):
        logger.info("Orchestration Agent stopping.")
