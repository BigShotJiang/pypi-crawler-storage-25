"""
VaultLayer -- Orchestration Decision Logic
============================================
Extracted from agent.py to keep the OrchestrationAgent class focused on
event handling, lifecycle, and Claude LLM inference.

Contains:
- _rule_based_decision()    -- legacy fallback for test compatibility
- _select_provider()        -- egress-aware provider selection (Golden Ratio)
- _log_resume_cost_breakdown() -- structured resume-cost breakdown logging
- _make_deterministic_decision() -- build migration decision without Claude
- _make_borderline_decision()    -- borderline arbitrage zone rules
- _make_hold_decision()          -- build hold decision without Claude
- MIN_MIGRATION_MARGIN_PCT      -- gainshare price guard constant
- MAX_PRICE_DATA_AGE_SECONDS    -- stale price data threshold
"""
from __future__ import annotations

import logging
import os
import time
from typing import Optional, Tuple

from shared.models import (
    AgentEvent, EventType, OrchestrationDecision, ActionTier,
    Provider, GPUType, Job,
)
from agents.orchestration.egress import (
    rank_candidates_by_resume_cost,
    PAYBACK_THRESHOLD_HOURS,
)

logger = logging.getLogger(__name__)


# Gainshare price guard: migration is hard-blocked when the calculated savings margin
# is below this floor. Guards against stale API prices (e.g. RunPod returning a cached
# price that is actually higher than current spot) causing a loss instead of a gain.
# 5% ensures VaultLayer always earns a positive gainshare, never bills for a loss.
MIN_MIGRATION_MARGIN_PCT: float = float(os.getenv("VL_MIN_MIGRATION_MARGIN_PCT", "5.0"))

# Maximum age of price data (seconds) accepted for a migration decision. Prices older
# than this are treated as stale and the migration is blocked until fresh data arrives.
MAX_PRICE_DATA_AGE_SECONDS: float = float(os.getenv("VL_MAX_PRICE_DATA_AGE_SECS", "300"))


# ---------------------------------------------------------------------------
# Rule-based decision (legacy fallback)
# ---------------------------------------------------------------------------

def _rule_based_decision(agent, event) -> object:
    """Legacy fallback -- kept for compatibility with existing test mocks."""
    from types import SimpleNamespace
    if event.event_type == EventType.TERMINATION_SIGNAL:
        return SimpleNamespace(action="migrate", confidence=0.99,
            reasoning="Rule-based: termination signal always triggers migration",
            payload=event.payload)
    if event.event_type == EventType.NAMESPACE_SYNC_COMPLETE:
        return SimpleNamespace(action="migrate", confidence=0.99,
            reasoning="Rule-based: sync complete -- immediate warm-start",
            payload=event.payload)
    if event.event_type in (EventType.OOM_DETECTED, EventType.GPU_FAILURE, EventType.HUNG_JOB):
        return SimpleNamespace(action="migrate", confidence=0.97,
            reasoning=f"Rule-based: {event.event_type.value} always triggers migration",
            payload=event.payload)
    return SimpleNamespace(action="hold", confidence=0.75,
        reasoning="Rule-based: defaulting to hold",
        payload=event.payload)


# ---------------------------------------------------------------------------
# Provider selection (Golden Ratio / egress-aware)
# ---------------------------------------------------------------------------

def _select_provider(
    agent,
    price_cache: list,
    job_id: str,
    current_provider: Optional[Provider] = None,
    emergency: bool = False,
) -> Tuple[Optional[Provider], Optional[GPUType], float, float]:
    """
    Egress-aware provider selection using the Golden Ratio (10-Hour Rule).

    Algorithm
    ---------
    1. Filter unavailable / last-resort entries.
    2. Find the source (current) spot price for delta calculation.
    3. Run rank_candidates_by_resume_cost():
         a. Same-cloud candidates -> zero egress, always eligible.
         b. Cross-cloud candidates -> apply Golden Ratio:
              payback_hours = (dataset_gb x egress_rate) / hourly_delta
              allowed only when payback_hours <= PAYBACK_THRESHOLD_HOURS (10)
         c. Sort eligible candidates by total_resume_cost (compute + egress) asc.
    4. Return the first eligible candidate that isn't the current price point.

    emergency=True (TERMINATION_SIGNAL / HEARTBEAT_MISS)
    -------------------------------------------------------
    Suspends the payback gate entirely -- every available provider is eligible
    regardless of dataset size or egress cost.  The source node is already dead;
    "don't cross clouds" has no meaning.  Egress cost is still recorded in the
    EgressVerdict for FinOps accounting.  Voluntary arbitrage migrations always
    run the full gate (emergency=False).

    Returns (None, None, 0.0, 0.0) when no valid target is found.
    """
    if not price_cache:
        return None, None, 0.0, 0.0

    job = agent._active_jobs.get(job_id)
    src_provider_val = current_provider.value if current_provider else ""

    # -- Resolve source price --
    current_price = 0.0
    if job and current_provider:
        for p in price_cache:
            if (
                isinstance(p, dict)
                and p.get("provider") == src_provider_val
                and p.get("availability", "unavailable") != "unavailable"
            ):
                current_price = float(p.get("price_per_hour", 0.0))
                break

    # -- Build candidate dicts (filter unavailable / last_resort) --
    raw_candidates: list[dict] = []
    for entry in price_cache:
        if not isinstance(entry, dict):
            continue
        avail = entry.get("availability", "unavailable")
        if avail in ("unavailable", "last_resort"):
            continue
        try:
            Provider(entry["provider"])
            GPUType(entry["gpu"])
        except (KeyError, ValueError):
            continue
        raw_candidates.append(entry)

    if not raw_candidates:
        return None, None, 0.0, 0.0

    # -- Enrich candidates with source context for recovery tier classification
    _src_gpu = job.gpu_type.value if job and job.gpu_type else ""
    _src_region = getattr(job, "region", "") or ""
    for _c in raw_candidates:
        _c["source_gpu"] = _src_gpu
        _c["source_region"] = _src_region

    # -- Resolve job egress metadata --
    dataset_size_gb:  float = getattr(job, "dataset_size_gb",  0.0) if job else 0.0
    dataset_location: str   = getattr(job, "dataset_location", "r2") if job else "r2"
    dataset_cloud:    str   = getattr(job, "dataset_cloud",    "")  if job else ""
    remaining_hours:  float = max(
        getattr(job, "training_duration_hours", 1.0) if job else 1.0,
        0.01,  # floor: avoid division by zero
    )

    # -- Rank by total resume cost (compute + egress), Golden Ratio gated --
    ranked = rank_candidates_by_resume_cost(
        candidates=raw_candidates,
        source_provider_value=src_provider_val,
        dataset_size_gb=dataset_size_gb,
        dataset_location=dataset_location,
        dataset_cloud=dataset_cloud,
        remaining_hours=remaining_hours,
        payback_threshold_hours=PAYBACK_THRESHOLD_HOURS,
        emergency=emergency,
    )

    # Log all rejections so engineers can see why each path was blocked
    for entry, estimate, verdict in ranked:
        prov_val = entry.get("provider", "?")
        gpu_val  = entry.get("gpu", "?")
        if not verdict.allowed:
            logger.info(
                f"[egress-gate] BLOCKED {prov_val} {gpu_val}: {verdict.reason}"
            )

    # -- Pick the first eligible candidate --
    for entry, estimate, verdict in ranked:
        if not verdict.allowed:
            continue  # Golden Ratio rejected this cross-cloud path

        try:
            prov = Provider(entry["provider"])
            gpu  = GPUType(entry["gpu"])
        except (KeyError, ValueError):
            continue

        price = float(entry.get("price_per_hour", 999.0))

        # Skip the degenerate case: same provider at the same price
        if prov == current_provider and abs(price - current_price) < 0.01:
            continue

        savings_per_hour = current_price - price
        savings_pct = (savings_per_hour / current_price * 100) if current_price > 0 else 0.0

        logger.info(
            f"[provider-select] {prov.value} {gpu.value} @ ${price:.4f}/hr "
            f"| saves ${savings_per_hour:.4f}/hr ({savings_pct:.1f}%) "
            f"| egress ${estimate.egress_cost_usd:.2f} "
            f"| resume total ${estimate.total_cost_usd:.2f} "
            f"| recovery_tier={estimate.recovery_tier} "
            f"| {verdict.reason}"
        )

        # Stash egress metadata on the instance so _make_deterministic_decision
        # can embed it in the OrchestrationDecision record.
        agent._last_egress_verdict = verdict
        agent._last_resume_estimate = estimate

        return prov, gpu, savings_per_hour, savings_pct

    if emergency:
        logger.error(
            f"[provider-select] CRITICAL: no provider found for emergency migration "
            f"of job {job_id} -- egress gate was suspended but all providers are "
            f"unavailable. Escalating to human."
        )
    else:
        logger.warning(
            f"[provider-select] No eligible provider found for job {job_id} "
            f"after egress gate (dataset={dataset_size_gb:.1f}GB @ {dataset_location})"
        )
    return None, None, 0.0, 0.0


# ---------------------------------------------------------------------------
# Resume cost breakdown logging
# ---------------------------------------------------------------------------

def _log_resume_cost_breakdown(agent, job: Job, price_cache: list) -> None:
    """
    Emit a structured resume-cost breakdown for every candidate provider.
    Called on TERMINATION_SIGNAL and HEARTBEAT_MISS so the decision log
    always shows the full compute+egress picture before a migration fires.
    """
    src_val = job.provider.value if job.provider else ""
    dataset_size_gb  = getattr(job, "dataset_size_gb",  0.0)
    dataset_location = getattr(job, "dataset_location", "r2")
    dataset_cloud    = getattr(job, "dataset_cloud",    "")
    remaining_hours  = max(getattr(job, "training_duration_hours", 1.0), 0.01)

    raw = [
        e for e in price_cache
        if isinstance(e, dict)
        and e.get("availability", "unavailable") not in ("unavailable", "last_resort")
    ]
    if not raw:
        return

    ranked = rank_candidates_by_resume_cost(
        candidates=raw,
        source_provider_value=src_val,
        dataset_size_gb=dataset_size_gb,
        dataset_location=dataset_location,
        dataset_cloud=dataset_cloud,
        remaining_hours=remaining_hours,
    )

    lines = [
        f"[resume-cost] job={job.job_id} dataset={dataset_size_gb:.1f}GB "
        f"location={dataset_location} remaining~{remaining_hours:.1f}hr"
    ]
    for entry, estimate, verdict in ranked:
        status = "allowed" if verdict.allowed else "blocked"
        lines.append(
            f"  {status:12s} {entry.get('provider','?'):14s} "
            f"compute=${estimate.compute_cost_usd:7.2f} "
            f"egress=${estimate.egress_cost_usd:6.2f} "
            f"total=${estimate.total_cost_usd:7.2f} "
            f"payback={estimate.payback_hours:.1f}hr"
        )
    logger.info("\n".join(lines))


# ---------------------------------------------------------------------------
# Deterministic decision builders
# ---------------------------------------------------------------------------

async def _make_deterministic_decision(
    agent,
    event: AgentEvent,
    reason: str,
    confidence: float = 0.95,
) -> OrchestrationDecision:
    """
    Build a migration OrchestrationDecision without calling Claude.
    Uses _select_provider() to pick the target deterministically.
    """
    job_id = event.job_id or "unknown"
    job = agent._active_jobs.get(job_id)
    current_provider = job.provider if job else None

    is_emergency = event.event_type in (EventType.TERMINATION_SIGNAL, EventType.HEARTBEAT_MISS)
    price_cache = await agent.queue.get_price_cache() or []
    target_provider, target_gpu, savings_per_hour, savings_pct = _select_provider(
        agent, price_cache, job_id, current_provider, emergency=is_emergency
    )

    # Build action plan from template (no LLM narration needed)
    target_str = (
        f"{target_provider.value} {target_gpu.value}"
        if target_provider and target_gpu
        else "best available node"
    )
    action_plan = [
        "Checkpoint current training state to R2",
        f"Provision {target_str}",
        "Restore checkpoint via namespace mount",
        "Resume training from last checkpoint step",
    ]

    tier = ActionTier.AUTO if confidence >= agent.config.confidence_threshold_auto else ActionTier.AUTO_NOTIFY

    # Pull egress metadata stashed by _select_provider() during this call
    verdict  = agent._last_egress_verdict
    estimate = agent._last_resume_estimate
    egress_cost   = verdict.egress_cost_usd   if verdict  else 0.0
    payback_hrs   = verdict.payback_hours      if verdict  else 0.0
    same_cloud    = verdict.same_cloud         if verdict  else False
    egress_reason = verdict.reason             if verdict  else ""
    resume_compute = estimate.compute_cost_usd if estimate else 0.0
    resume_total   = estimate.total_cost_usd   if estimate else 0.0
    recovery_tier  = estimate.recovery_tier     if estimate else 0

    # Enrich reasoning with egress breakdown so humans / Claude can audit it
    egress_note = (
        f" Same-cloud hop -- zero egress cost."
        if same_cloud
        else (
            f" Egress: ${egress_cost:.2f} ({payback_hrs:.1f}hr payback)."
            if egress_cost > 0
            else ""
        )
    )

    decision = OrchestrationDecision(
        job_id=job_id,
        action="migrate",
        reasoning=(
            f"{reason} Savings: ${savings_per_hour:.2f}/hr ({savings_pct:.1f}%)."
            f"{egress_note}"
        ),
        action_plan=action_plan,
        confidence=confidence,
        tier=tier,
        target_provider=target_provider,
        target_gpu=target_gpu,
        estimated_savings_per_hour=savings_per_hour,
        estimated_downtime_minutes=3.0,
        requires_human_confirmation=(tier == ActionTier.CONFIRM),
        # Egress fields
        egress_cost_usd=egress_cost,
        payback_hours=payback_hrs,
        same_cloud_hop=same_cloud,
        egress_verdict=egress_reason,
        resume_compute_cost_usd=resume_compute,
        resume_total_cost_usd=resume_total,
    )
    agent._decisions.append(decision)
    # Reset stash so a subsequent call doesn't inherit stale data
    agent._last_egress_verdict = None
    agent._last_resume_estimate = None

    logger.info(
        f"Deterministic decision: migrate job {job_id} -> {target_str} "
        f"(conf={confidence:.2f} savings=${savings_per_hour:.2f}/hr "
        f"egress=${egress_cost:.2f} resume_total=${resume_total:.2f} "
        f"recovery_tier={recovery_tier})"
    )
    return decision


async def _make_borderline_decision(
    agent,
    event: AgentEvent,
    job: Optional[Job],
    savings_pct: float,
    opps: list,
) -> OrchestrationDecision:
    """
    Deterministic decision for the borderline arbitrage zone:
    savings 15-25%, job is late-stage (>BORDERLINE_PROGRESS_PCT done).

    Rules applied in priority order:
      1. Too many interruptions (>=3) -> hold. Further disruption has diminishing value.
      2. Checkpoint was very recent (<5 min) -> migrate. Progress at risk is near zero.
      3. Very little time remaining (<20 min estimated) -> hold. Migration overhead not worth it.
      4. High availability on target -> migrate if savings >20%.
      5. Medium/low availability -> hold. Risk of a failed provision outweighs savings.
      6. Default -> hold. When in doubt, protect progress.

    If ANTHROPIC_API_KEY is set, Claude is consulted AFTER the rules pass
    the case as genuinely ambiguous (none of rules 1-5 fired). This keeps
    Claude as a genuine second opinion, not a crutch for deterministic math.
    """
    job_id = event.job_id or "unknown"
    interruption_count = job.interruption_count if job else 0
    progress_pct = job.progress_pct if job else 0.0

    # Best opportunity from the payload
    best_opp = max(opps, key=lambda o: o.get("savings_pct", 0), default={})
    availability = best_opp.get("availability", "low")

    # Estimate remaining minutes from progress and elapsed time
    remaining_min: Optional[float] = None
    if job and job.started_at and job.progress_pct and job.progress_pct > 0:
        import datetime as _dt
        elapsed_h = (_dt.datetime.utcnow() - job.started_at).total_seconds() / 3600
        total_h_est = elapsed_h / (job.progress_pct / 100)
        remaining_min = (total_h_est - elapsed_h) * 60

    # -- Rule 1: too many interruptions --
    if interruption_count >= 3:
        reason = (
            f"Holding: job {job_id} already has {interruption_count} interruptions. "
            f"Further migration risk outweighs {savings_pct:.1f}% savings."
        )
        logger.info(f"Borderline -> hold (rule 1 -- interruptions): {reason}")
        return await _make_hold_decision(agent, event, reason, confidence=0.88)

    # -- Rule 2: checkpoint very recent -> migrate (minimal progress at risk) --
    last_cp = job.last_checkpoint if job else None
    if last_cp:
        import datetime as _dt
        cp_age_min = (_dt.datetime.utcnow() - last_cp.timestamp).total_seconds() / 60
        if cp_age_min < 5:
            reason = (
                f"Migrating: last checkpoint only {cp_age_min:.1f} min ago -- "
                f"progress at risk ~0. {savings_pct:.1f}% savings worth the move."
            )
            logger.info(f"Borderline -> migrate (rule 2 -- fresh checkpoint): {reason}")
            return await _make_deterministic_decision(agent, event, reason, confidence=0.87)

    # -- Rule 3: very little time remaining -> hold --
    if remaining_min is not None and remaining_min < 20:
        reason = (
            f"Holding: ~{remaining_min:.0f} min remaining. "
            f"Migration overhead (~3 min) not worth {savings_pct:.1f}% savings on a nearly-done job."
        )
        logger.info(f"Borderline -> hold (rule 3 -- near completion): {reason}")
        return await _make_hold_decision(agent, event, reason, confidence=0.90)

    # -- Rule 4: high availability + >20% savings -> migrate --
    if availability == "high" and savings_pct > 20:
        reason = (
            f"Migrating: {savings_pct:.1f}% savings with high availability on target. "
            f"Job {progress_pct:.0f}% done -- risk acceptable."
        )
        logger.info(f"Borderline -> migrate (rule 4 -- high avail + savings): {reason}")
        return await _make_deterministic_decision(agent, event, reason, confidence=0.83)

    # -- Rule 5: medium/low availability -> hold --
    if availability in ("medium", "low", "unavailable"):
        reason = (
            f"Holding: target availability is '{availability}'. "
            f"Provision failure risk outweighs {savings_pct:.1f}% savings at {progress_pct:.0f}% progress."
        )
        logger.info(f"Borderline -> hold (rule 5 -- availability): {reason}")
        return await _make_hold_decision(agent, event, reason, confidence=0.82)

    # -- Genuine ambiguity: consult Claude if available --
    # Reaches here only if: <3 interruptions, checkpoint not fresh, >20 min
    # remaining, availability is high but savings <=20%. Rare in practice.
    if agent._claude and agent.config.anthropic:
        logger.info(
            f"Borderline arbitrage: job {job_id} is genuinely ambiguous "
            f"({savings_pct:.1f}% savings, {progress_pct:.0f}% done, avail={availability}) "
            f"-- consulting Claude."
        )
        try:
            return await agent._make_decision(event)
        except Exception as e:
            logger.warning(f"Claude unavailable ({e}) -- defaulting to hold.")

    # -- Rule 6: default -> hold --
    reason = (
        f"Holding: borderline savings ({savings_pct:.1f}%) at {progress_pct:.0f}% progress "
        f"-- insufficient signal to migrate."
    )
    logger.info(f"Borderline -> hold (rule 6 -- default): {reason}")
    return await _make_hold_decision(agent, event, reason, confidence=0.75)


async def _make_hold_decision(
    agent, event: AgentEvent, reason: str, confidence: float = 0.80
) -> OrchestrationDecision:
    """Build a hold OrchestrationDecision without calling Claude."""
    job_id = event.job_id or "unknown"
    decision = OrchestrationDecision(
        job_id=job_id,
        action="hold",
        reasoning=reason,
        action_plan=["Continue monitoring -- no migration required"],
        confidence=confidence,
        tier=ActionTier.AUTO,
        target_provider=None,
        target_gpu=None,
        estimated_savings_per_hour=0.0,
        estimated_downtime_minutes=0.0,
        requires_human_confirmation=False,
    )
    agent._decisions.append(decision)
    return decision
