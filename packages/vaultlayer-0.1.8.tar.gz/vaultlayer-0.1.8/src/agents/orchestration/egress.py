"""
VaultLayer — Egress Cost Engine
================================
Golden Ratio formula for cross-cloud hop decisions.

Three numbers, one division, one compare:

    Egress Cost Estimate  =  Dataset Size (GB) × egress_rate_per_gb
    Hourly Compute Delta  =  source_price_per_hour - target_price_per_hour
    Payback Period (hrs)  =  Egress Cost / Hourly Compute Delta

    IF payback_hours ≤ PAYBACK_THRESHOLD_HOURS  →  cross-cloud hop ALLOWED
    ELSE                                         →  stay on same cloud

The threshold is 10 hours (the "10-Hour Rule").  Setting it to 10 means:
"Only cross clouds if the cheaper provider earns back the egress fee within
 10 hours of compute time."  Any job finishing sooner than 10 hours will
 naturally stay on the same cloud — it can never break even in time.

Egress rates used (one-way, first-tier public pricing):
  AWS S3    → non-AWS   :  $0.09 /GB  (first 10 TB/month)
  GCS       → non-GCP   :  $0.10 /GB
  Azure Blob→ non-Azure :  $0.085/GB  (first 100 GB/month free — not modelled here
                                       because jobs > 100 GB are the interesting cases)
  Cloudflare R2 → any   :  $0.00 /GB  (zero egress, always)
  Local/NVMe    → any   :  $0.00 /GB  (portable, no cloud bill)

Checkpoint data always flows through R2 (zero egress) and is never counted here.
This module only prices the *dataset* transfer at the start of a cross-cloud hop.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)

# ── Egress rate table ──────────────────────────────────────────────────────────

#: USD per GB outbound — loaded from config/vaultlayer_data.json (updated by pricing agent)
#: Override with VL_EGRESS_AWS_S3, VL_EGRESS_GCP_GCS, VL_EGRESS_AZURE_BLOB env vars.
def _load_egress():
    try:
        from shared.data_loader import get_egress_rates
        rates = get_egress_rates()
        if rates:
            # Map JSON keys to expected format
            return {
                "s3": rates.get("aws_s3", 0.09),
                "gcs": rates.get("gcp_gcs", 0.10),
                "azure_blob": rates.get("azure_blob", 0.085),
                "r2": rates.get("r2", 0.0),
                "local": 0.0,
            }
    except Exception:
        pass
    return {"s3": 0.09, "gcs": 0.10, "azure_blob": 0.085, "r2": 0.0, "local": 0.0}

EGRESS_RATES_USD_PER_GB: dict[str, float] = _load_egress()

#: Default rate applied when dataset_location is unrecognised.
DEFAULT_EGRESS_RATE_USD_PER_GB: float = EGRESS_RATES_USD_PER_GB.get("s3", 0.09)

# ── Cloud affinity map ────────────────────────────────────────────────────────

#: Which provider.value string is the "home cloud" for each storage location?
#: Migrating TO the home cloud = zero egress (intra-cloud transfer).
#: None means the storage has no home cloud (R2, local) → always zero egress.
DATASET_NATIVE_CLOUD: dict[str, Optional[str]] = {
    "s3":         "aws",
    "gcs":        "gcp",
    "azure_blob": "azure",
    "r2":         None,
    "local":      None,
}

# ── Policy constant ───────────────────────────────────────────────────────────

#: The 10-Hour Rule: cross-cloud hop is allowed only if the egress fee is earned
#: back within this many hours of cheaper compute.
#: Override with VL_PAYBACK_THRESHOLD_HRS env var.
def _load_payback():
    try:
        from shared.data_loader import get_operational_config
        return get_operational_config().get("payback_threshold_hours", 10.0)
    except Exception:
        return 10.0

PAYBACK_THRESHOLD_HOURS: float = _load_payback()


# ── Data classes ──────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class EgressVerdict:
    """Outcome of a Golden Ratio evaluation for a single candidate provider."""
    allowed: bool
    egress_cost_usd: float
    payback_hours: float          # inf when delta ≤ 0
    reason: str                   # human-readable explanation for logs / UI
    same_cloud: bool              # True when no egress cost at all


@dataclass(frozen=True)
class ResumeCostEstimate:
    """Total estimated cost to resume a job on a given destination provider."""
    destination_provider: str
    compute_cost_usd: float       # price_per_hour × estimated_remaining_hours
    egress_cost_usd: float        # one-time dataset transfer cost
    total_cost_usd: float         # compute_cost_usd + egress_cost_usd
    payback_hours: float
    verdict: EgressVerdict
    recovery_tier: int = 0        # RecoveryTier enum value (1-5), 0 = unclassified


# ── Core functions ────────────────────────────────────────────────────────────

def egress_rate(dataset_location: str) -> float:
    """Return the $/GB egress rate for the given storage system."""
    return EGRESS_RATES_USD_PER_GB.get(dataset_location, DEFAULT_EGRESS_RATE_USD_PER_GB)


def compute_egress_cost(dataset_size_gb: float, dataset_location: str) -> float:
    """
    One-time egress cost in USD for moving dataset_size_gb off its home cloud.

    Returns 0.0 when the storage location has zero egress (R2, local).
    """
    rate = egress_rate(dataset_location)
    return round(dataset_size_gb * rate, 4)


def is_same_cloud(
    target_provider_value: str,
    dataset_location: str,
    dataset_cloud: str = "",
) -> bool:
    """
    Return True when the target provider is on the same cloud as the dataset,
    meaning zero egress cost for the dataset hop.

    Args:
        target_provider_value: Provider enum value of the destination (e.g. "aws").
        dataset_location:      Storage system string ("s3", "gcs", "r2", …).
        dataset_cloud:         Explicit cloud override ("aws" | "gcp" | "azure" | "").
                               When non-empty, this takes precedence over dataset_location.
    """
    # R2 and local are always zero-egress — no concept of "home cloud"
    if dataset_location in ("r2", "local"):
        return True

    # Explicit override wins over location-derived cloud
    native = dataset_cloud.lower() if dataset_cloud else (
        DATASET_NATIVE_CLOUD.get(dataset_location) or ""
    )
    if not native:
        return True  # unknown → treat as zero-egress to avoid false blocks

    return target_provider_value.lower() == native


def golden_ratio(
    dataset_size_gb: float,
    dataset_location: str,
    dataset_cloud: str,
    source_provider_value: str,
    target_provider_value: str,
    hourly_compute_delta: float,           # source_price - target_price (positive = savings)
    payback_threshold_hours: float = PAYBACK_THRESHOLD_HOURS,
    emergency: bool = False,
) -> EgressVerdict:
    """
    Apply the Golden Ratio (10-Hour Rule) to a single migration candidate.

    Formula
    -------
        egress_cost   = dataset_size_gb × egress_rate(dataset_location)
        payback_hours = egress_cost / hourly_compute_delta

        allowed = same_cloud OR emergency OR
                  (hourly_compute_delta > 0 AND payback_hours ≤ threshold)

    Emergency mode (TERMINATION_SIGNAL / HEARTBEAT_MISS)
    -----------------------------------------------------
    The payback gate is suspended for forced migrations — the source node is
    already dead or unreachable, so "don't cross clouds" has no meaning.
    The egress cost is still calculated and recorded so FinOps can account for
    it, but it never blocks the migration.  Voluntary arbitrage migrations
    (ARBITRAGE_OPPORTUNITY, NAMESPACE_SYNC_COMPLETE) always run the full gate.

    Returns an EgressVerdict describing whether the cross-cloud hop is allowed
    and the full numeric breakdown for logging and the decision record.
    """
    same = is_same_cloud(target_provider_value, dataset_location, dataset_cloud)

    if same:
        return EgressVerdict(
            allowed=True,
            egress_cost_usd=0.0,
            payback_hours=0.0,
            reason=(
                f"same-cloud hop ({target_provider_value}) — "
                "zero egress cost, always allowed"
            ),
            same_cloud=True,
        )

    egress_cost = compute_egress_cost(dataset_size_gb, dataset_location)

    # Emergency migration: source node is dead — payback gate suspended.
    # Egress cost is recorded for accounting but cannot block the hop.
    if emergency:
        payback_hours = (
            round(egress_cost / hourly_compute_delta, 2)
            if hourly_compute_delta > 0
            else float("inf")
        )
        return EgressVerdict(
            allowed=True,
            egress_cost_usd=egress_cost,
            payback_hours=payback_hours,
            reason=(
                f"emergency migration — egress gate suspended "
                f"(${egress_cost:.2f} egress recorded for FinOps, "
                f"payback {payback_hours:.1f}hr not enforced: source node is dead)"
            ),
            same_cloud=False,
        )

    # Voluntary migration: target is more expensive → never cross clouds for a loss
    if hourly_compute_delta <= 0:
        return EgressVerdict(
            allowed=False,
            egress_cost_usd=egress_cost,
            payback_hours=float("inf"),
            reason=(
                f"cross-cloud blocked: target {target_provider_value} is not cheaper "
                f"than {source_provider_value} (delta ${hourly_compute_delta:.4f}/hr ≤ 0)"
            ),
            same_cloud=False,
        )

    payback_hours = round(egress_cost / hourly_compute_delta, 2)
    allowed = payback_hours <= payback_threshold_hours

    if allowed:
        reason = (
            f"cross-cloud allowed: ${egress_cost:.2f} egress ÷ "
            f"${hourly_compute_delta:.4f}/hr savings = "
            f"{payback_hours:.1f}hr payback ≤ {payback_threshold_hours}hr threshold"
        )
    else:
        reason = (
            f"cross-cloud blocked: ${egress_cost:.2f} egress ÷ "
            f"${hourly_compute_delta:.4f}/hr savings = "
            f"{payback_hours:.1f}hr payback > {payback_threshold_hours}hr threshold — "
            f"keeping job on {source_provider_value}"
        )

    return EgressVerdict(
        allowed=allowed,
        egress_cost_usd=egress_cost,
        payback_hours=payback_hours,
        reason=reason,
        same_cloud=False,
    )


def compute_resume_cost(
    destination_provider: str,
    target_price_per_hour: float,
    remaining_hours: float,
    dataset_size_gb: float,
    dataset_location: str,
    dataset_cloud: str = "",
    source_provider_value: str = "",
) -> ResumeCostEstimate:
    """
    Total estimated cost to resume a job on a destination provider.

    total_cost = compute_cost + egress_cost
               = (target_price_per_hour × remaining_hours) + (dataset_gb × egress_rate)

    The egress_cost is 0.0 when destination is on the same cloud as the dataset.

    Args:
        destination_provider:   Provider enum value of the destination.
        target_price_per_hour:  Spot price on the destination ($/hr).
        remaining_hours:        Estimated remaining training time.
        dataset_size_gb:        Size of the training dataset in GB.
        dataset_location:       Storage system ("s3", "gcs", "r2", …).
        dataset_cloud:          Explicit cloud override (optional).
        source_provider_value:  Current provider (used only for delta in verdict).
    """
    compute_cost = round(target_price_per_hour * remaining_hours, 4)

    same = is_same_cloud(destination_provider, dataset_location, dataset_cloud)
    egress_cost = 0.0 if same else compute_egress_cost(dataset_size_gb, dataset_location)

    total = round(compute_cost + egress_cost, 4)

    # Dummy verdict for inclusion in the estimate (delta not available here)
    verdict = EgressVerdict(
        allowed=True,
        egress_cost_usd=egress_cost,
        payback_hours=0.0,
        reason="resume cost estimate (no delta comparison)",
        same_cloud=same,
    )

    return ResumeCostEstimate(
        destination_provider=destination_provider,
        compute_cost_usd=compute_cost,
        egress_cost_usd=egress_cost,
        total_cost_usd=total,
        payback_hours=0.0,
        verdict=verdict,
    )


def rank_candidates_by_resume_cost(
    candidates: list[dict],           # list of {provider, gpu, price_per_hour, …}
    source_provider_value: str,
    dataset_size_gb: float,
    dataset_location: str,
    dataset_cloud: str,
    remaining_hours: float,
    payback_threshold_hours: float = PAYBACK_THRESHOLD_HOURS,
    emergency: bool = False,
) -> list[tuple[dict, ResumeCostEstimate, EgressVerdict]]:
    """
    Score and rank every candidate provider by total resume cost.

    Algorithm
    ---------
    1. For each candidate, run golden_ratio() using (current_price − target_price) as delta.
       Same-cloud candidates always pass. Cross-cloud candidates must satisfy payback ≤ threshold
       UNLESS emergency=True (TERMINATION_SIGNAL / HEARTBEAT_MISS), in which case the payback
       gate is suspended — every available provider is eligible.
    2. Compute total_resume_cost = compute_cost + egress_cost for eligible candidates.
    3. Return eligible candidates sorted by total_resume_cost ascending (cheapest first).
       Ineligible (blocked) candidates are included at the end with allowed=False so
       callers can log why each path was rejected.

    The caller (OrchestrationAgent._select_provider) picks the first eligible entry.
    """
    # Find source price for delta calculation
    source_price = 0.0
    for c in candidates:
        if c.get("provider") == source_provider_value:
            source_price = float(c.get("price_per_hour", 0.0))
            break

    results: list[tuple[dict, ResumeCostEstimate, EgressVerdict]] = []

    for entry in candidates:
        target_prov = entry.get("provider", "")
        target_price = float(entry.get("price_per_hour", 0.0))
        hourly_delta = source_price - target_price

        verdict = golden_ratio(
            dataset_size_gb=dataset_size_gb,
            dataset_location=dataset_location,
            dataset_cloud=dataset_cloud,
            source_provider_value=source_provider_value,
            target_provider_value=target_prov,
            hourly_compute_delta=hourly_delta,
            payback_threshold_hours=payback_threshold_hours,
            emergency=emergency,
        )

        same = is_same_cloud(target_prov, dataset_location, dataset_cloud)
        egress = 0.0 if same else compute_egress_cost(dataset_size_gb, dataset_location)
        compute = round(target_price * remaining_hours, 4)

        # Classify recovery tier for logging / Job Manifest
        try:
            from shared.recovery_tiers import classify_recovery_tier
            _source_gpu = entry.get("source_gpu", "")
            _target_gpu = entry.get("gpu", entry.get("gpu_type", ""))
            _same_region = entry.get("region", "") == entry.get("source_region", "")
            _tier = classify_recovery_tier(
                source_provider=source_provider_value,
                target_provider=target_prov,
                source_gpu=_source_gpu,
                target_gpu=_target_gpu,
                same_region=_same_region and (source_provider_value == target_prov),
            )
            _tier_val = int(_tier)
        except Exception:
            _tier_val = 0

        estimate = ResumeCostEstimate(
            destination_provider=target_prov,
            compute_cost_usd=compute,
            egress_cost_usd=egress,
            total_cost_usd=round(compute + egress, 4),
            payback_hours=verdict.payback_hours,
            verdict=verdict,
            recovery_tier=_tier_val,
        )

        results.append((entry, estimate, verdict))

    # Sort: allowed first (by total cost asc), then blocked (by payback_hours asc for logging)
    results.sort(key=lambda r: (0 if r[2].allowed else 1, r[1].total_cost_usd))
    return results
