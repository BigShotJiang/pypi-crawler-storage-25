"""
VaultLayer -- Vault Agent: Cloudflare R2 Client
Zero-egress checkpoint storage. S3-compatible via boto3.
"""

import os
import time
import zlib
import hashlib
import logging
from pathlib import Path
from typing import Optional, List
from datetime import datetime

import io
import concurrent.futures

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from shared.models import CheckpointRecord, CheckpointType, GPUType
from shared.retry import sync_retry
from shared.security import get_encryption, get_audit

# Re-export constants from extracted modules so existing imports keep working
from agents.vault.delta import DELTA_CHUNK_SIZE
from agents.vault.multipart import (
    MULTIPART_THRESHOLD_BYTES,
    MULTIPART_CHUNK_SIZE_BYTES,
    MULTIPART_MAX_CONCURRENCY,
    DOWNLOAD_MAX_CONCURRENCY,
)
# Import standalone functions for delegation
from agents.vault.delta import (
    compute_xor_delta as _compute_xor_delta_fn,
    apply_xor_delta as _apply_xor_delta_fn,
    upload_delta as _upload_delta_fn,
    restore_from_chain as _restore_from_chain_fn,
)
from agents.vault.multipart import (
    upload_multipart as _upload_multipart_fn,
    cleanup_orphaned_multipart_uploads as _cleanup_orphaned_fn,
)

logger = logging.getLogger(__name__)


class R2Client:
    """
    Cloudflare R2 client using the S3-compatible API.
    Zero egress fees -- data never leaves R2 to billing domains.
    """

    def __init__(
        self,
        endpoint: str,
        access_key_id: str,
        secret_access_key: str,
        bucket: str,
        session_token: Optional[str] = None,
    ):
        self.bucket = bucket
        self._s3 = boto3.client(
            "s3",
            endpoint_url=endpoint,
            aws_access_key_id=access_key_id,
            aws_secret_access_key=secret_access_key,
            aws_session_token=session_token,   # None → master key auth; str → STS token auth
            config=Config(
                signature_version="s3v4",
                retries={"max_attempts": 3, "mode": "adaptive"},
                max_pool_connections=20,
            ),
            region_name="auto",
        )
        cred_type = "scoped-temp-token" if session_token else "master-key"
        logger.info(f"R2Client initialised bucket={bucket!r} credentials={cred_type}")

    # -- Upload -----------------------------------------------------------------

    def upload_checkpoint(
        self,
        job_id: str,
        step: int,
        local_path: str,
        model_params_billion: float,
        epoch: float = 0.0,
        training_loss: Optional[float] = None,
    ) -> CheckpointRecord:
        """
        Upload a checkpoint file/directory to R2.
        Compresses with zlib before upload.
        Returns a CheckpointRecord with R2 key and metadata.
        """
        local = Path(local_path)
        if not local.exists():
            raise FileNotFoundError(f"Checkpoint path not found: {local_path}")

        # Purge any dark checkpoints (data uploaded but manifest missing) left by
        # a prior crash. Must run before we write so we never restore a corrupt step.
        self.purge_dark_checkpoints(job_id)

        start = time.monotonic()
        r2_key = f"checkpoints/{job_id}/step-{step:08d}/{local.name}"

        # Read and get size
        data = local.read_bytes() if local.is_file() else self._tar_directory(local)
        size_bytes = len(data)

        # Compress
        compressed = zlib.compress(data, level=6)
        compression_ratio = len(compressed) / size_bytes
        logger.info(
            f"Uploading checkpoint: {local.name} "
            f"({size_bytes / 1e9:.2f} GB ? {len(compressed) / 1e9:.2f} GB compressed, "
            f"ratio: {compression_ratio:.2f})"
        )

        # Encrypt if key is configured
        enc = get_encryption()
        if enc.enabled:
            compressed = enc.encrypt(compressed)
            get_audit().checkpoint_encrypted(job_id, size_bytes)

        # Upload -- multipart for large files, single call for small ones
        sha256_hex = hashlib.sha256(data).hexdigest()
        metadata = {
            "job_id": job_id,
            "step": str(step),
            "epoch": str(epoch),
            "model_params_billion": str(model_params_billion),
            "original_size_bytes": str(size_bytes),
            "sha256": sha256_hex,
            "training_loss": str(training_loss) if training_loss else "",
        }
        if enc.enabled:
            metadata["vl-encrypted"] = "1"
            metadata["vl-enc-version"] = "1"
        if len(compressed) >= MULTIPART_THRESHOLD_BYTES:
            logger.info(f"Large checkpoint ({len(compressed)/1e9:.2f} GB) -- using multipart upload")
            self._upload_multipart(compressed, r2_key, metadata)
        else:
            # P0-C1: retry with backoff on transient R2 errors
            _body = compressed
            sync_retry(
                lambda: self._s3.put_object(
                    Bucket=self.bucket, Key=r2_key, Body=_body,
                    ContentType="application/octet-stream",
                    ServerSideEncryption="AES256",
                    Metadata=metadata,
                ),
                attempts=5,
                delays=(1, 2, 5, 10, 30),
                label=f"put_object {r2_key}",
            )

        # P0-C2: Integrity check — verify R2 received the correct number of bytes
        # and the SHA256 in metadata matches what we computed before upload.
        self._verify_upload(r2_key, len(compressed), sha256_hex)

        duration = time.monotonic() - start
        speed_gbps = (size_bytes / 1e9) / duration * 8 if duration > 0 else 0
        logger.info(
            f"Checkpoint uploaded in {duration:.1f}s "
            f"({speed_gbps:.2f} Gbps) ? r2://{self.bucket}/{r2_key}"
        )

        # Atomic completion marker: write manifest LAST.
        # A checkpoint is only "complete" when /_MANIFEST.json exists.
        # On restore, only checkpoints with a manifest are trusted.
        # Pattern used by PyTorch Lightning and HuggingFace Trainer.
        manifest_key = f"checkpoints/{job_id}/step-{step:08d}/_MANIFEST.json"
        import json as _json
        manifest_data = _json.dumps({
            "job_id": job_id,
            "step": step,
            "r2_key": r2_key,
            "size_bytes": size_bytes,
            "complete": True,
        }).encode()
        manifest_meta: dict = {"content-type": "application/json"}
        if enc.enabled:
            manifest_data = enc.encrypt(manifest_data)
            manifest_meta["vl-encrypted"] = "1"
            manifest_meta["vl-enc-version"] = "1"
        # Retry the manifest write up to 3 times. On final failure, best-effort
        # delete the orphan data object (IDEM-3) so it doesn't occupy storage.
        # Startup GC catches anything the delete misses.
        _manifest_written = False
        for _manifest_attempt in range(3):
            try:
                self._s3.put_object(
                    Bucket=self.bucket,
                    Key=manifest_key,
                    Body=manifest_data,
                    ContentType="application/json",
                    Metadata={k: v for k, v in manifest_meta.items() if k != "content-type"},
                )
                _manifest_written = True
                break  # success
            except Exception as _me:
                if _manifest_attempt == 2:
                    logger.error(
                        f"Manifest write failed for {r2_key} after 3 attempts: {_me}. "
                        "Attempting orphan cleanup."
                    )
                    try:
                        self._s3.delete_object(Bucket=self.bucket, Key=r2_key)
                        logger.info(f"Orphan data {r2_key} deleted after manifest failure")
                    except Exception as _de:
                        logger.warning(
                            f"Orphan cleanup also failed for {r2_key}: {_de}. "
                            "Will be reaped by startup GC."
                        )
                    raise RuntimeError(
                        f"Checkpoint upload failed: manifest write for {r2_key} failed after 3 attempts: {_me}"
                    )
                else:
                    logger.warning(
                        f"Manifest write attempt {_manifest_attempt + 1}/3 failed for {r2_key}: {_me}"
                    )
                    time.sleep(1)

        # S6: Mirror to backup bucket (synchronous, failure is non-fatal)
        self._mirror_to_backup(r2_key, compressed)

        record = CheckpointRecord(
            job_id=job_id,
            step=step,
            epoch=epoch,
            r2_key=r2_key,
            size_bytes=size_bytes,
            sync_duration_seconds=duration,
            model_params_billion=model_params_billion,
            training_loss=training_loss,
        )
        return record

    # ── Delta Upload ───────────────────────────────────────────────────────────

    def upload_delta(
        self,
        job_id: str,
        step: int,
        base_step: int,
        prev_local_path: str,
        curr_local_path: str,
        model_params_billion: float,
        epoch: float = 0.0,
        training_loss: Optional[float] = None,
    ) -> Optional[CheckpointRecord]:
        """
        Compute and upload an XOR delta between prev and current checkpoint.
        Delegates to agents.vault.delta.upload_delta().
        """
        return _upload_delta_fn(
            s3_client=self._s3,
            bucket=self.bucket,
            job_id=job_id,
            step=step,
            base_step=base_step,
            prev_local_path=prev_local_path,
            curr_local_path=curr_local_path,
            model_params_billion=model_params_billion,
            epoch=epoch,
            training_loss=training_loss,
            verify_upload_fn=self._verify_upload,
        )

    def restore_from_chain(
        self,
        job_id: str,
        target_step: int,
        target_dir: str,
    ) -> Optional[str]:
        """
        Restore a checkpoint by replaying its delta chain.
        Delegates to agents.vault.delta.restore_from_chain().
        """
        return _restore_from_chain_fn(
            s3_client=self._s3,
            bucket=self.bucket,
            job_id=job_id,
            target_step=target_step,
            target_dir=target_dir,
            get_namespace_manifest_fn=self.get_namespace_manifest,
            download_checkpoint_fn=self.download_checkpoint,
        )

    # ── Delta Internals (thin wrappers) ───────────────────────────────────────

    def _compute_xor_delta(self, prev_path: Path, curr_path: Path) -> Optional[bytes]:
        """Delegate to standalone compute_xor_delta()."""
        return _compute_xor_delta_fn(prev_path, curr_path)

    def _apply_xor_delta(
        self, base_path: Path, delta_compressed: bytes, output_path: Path
    ) -> None:
        """Delegate to standalone apply_xor_delta()."""
        _apply_xor_delta_fn(base_path, delta_compressed, output_path)

    # ── Download ───────────────────────────────────────────────────────────────

    def download_checkpoint(
        self,
        checkpoint: CheckpointRecord,
        target_dir: str,
    ) -> str:
        """
        Download and decompress a checkpoint from R2 to local path.
        Returns the local path of the restored checkpoint.
        """
        target = Path(target_dir)
        target.mkdir(parents=True, exist_ok=True)
        local_path = target / Path(checkpoint.r2_key).name

        start = time.monotonic()
        logger.info(f"Downloading checkpoint from r2://{self.bucket}/{checkpoint.r2_key}")

        response = self._s3.get_object(Bucket=self.bucket, Key=checkpoint.r2_key)
        compressed = response["Body"].read()
        obj_meta = response.get("Metadata", {})

        # GAP-27: Verify SHA256 of compressed data if stored in object metadata
        expected_sha256 = (
            obj_meta.get("sha256")
            or response.get("ResponseMetadata", {}).get("HTTPHeaders", {}).get("x-amz-meta-sha256")
        )
        if expected_sha256:
            actual_sha256 = hashlib.sha256(compressed).hexdigest()
            if actual_sha256 != expected_sha256:
                raise ValueError(
                    f"Checksum mismatch for {checkpoint.r2_key}: "
                    f"expected {expected_sha256}, got {actual_sha256}. "
                    f"Object may be corrupted."
                )

        # Decrypt if the object was encrypted
        enc = get_encryption()
        if obj_meta.get("vl-encrypted") == "1":
            compressed = enc.decrypt(compressed)
            get_audit().checkpoint_decrypted(str(checkpoint.r2_key))

        data = zlib.decompress(compressed)
        local_path.write_bytes(data)

        duration = time.monotonic() - start
        speed_gbps = (len(data) / 1e9) / duration * 8 if duration > 0 else 0
        logger.info(
            f"Checkpoint restored in {duration:.1f}s ({speed_gbps:.2f} Gbps) ? {local_path}"
        )
        return str(local_path)


    # -- Multipart Upload ------------------------------------------------------

    def _verify_upload(self, r2_key: str, expected_size_bytes: int, expected_sha256: str) -> None:
        """
        P0-C2: Post-upload integrity check via head_object.

        Confirms R2 received the correct number of bytes and that the SHA256
        stored in object metadata matches what we computed before upload.
        Raises RuntimeError on mismatch — the caller's retry wrapper will
        re-attempt the full upload rather than silently leaving a corrupt object.

        head_object fetches metadata only (no body transfer), so this costs
        one Class B R2 operation ($0.36/million) with negligible latency.
        """
        try:
            head = self._s3.head_object(Bucket=self.bucket, Key=r2_key)
        except Exception as e:
            # If head_object itself fails, log and continue — don't block migration
            # on a metadata-check network error when the upload likely succeeded.
            logger.warning(f"[R2] Integrity head_object failed for {r2_key} (non-fatal): {e}")
            return

        actual_size = head.get("ContentLength", -1)
        if actual_size != expected_size_bytes:
            raise RuntimeError(
                f"[R2] Upload integrity check FAILED for {r2_key}: "
                f"expected {expected_size_bytes} bytes, R2 reports {actual_size} bytes. "
                "Checkpoint may be truncated — will retry upload."
            )

        actual_sha256 = head.get("Metadata", {}).get("sha256", "")
        if actual_sha256 and actual_sha256 != expected_sha256:
            raise RuntimeError(
                f"[R2] Upload integrity check FAILED for {r2_key}: "
                f"SHA256 mismatch (expected {expected_sha256[:12]}…, got {actual_sha256[:12]}…). "
                "Checkpoint may be corrupted — will retry upload."
            )

        logger.debug(f"[R2] Integrity check passed for {r2_key} ({actual_size} bytes)")

    def _upload_multipart(self, data: bytes, r2_key: str, metadata: dict) -> None:
        """Delegate to standalone upload_multipart()."""
        _upload_multipart_fn(self._s3, self.bucket, data, r2_key, metadata)

    # -- Parallel Shard Download -----------------------------------------------

    def download_shards_parallel(
        self,
        r2_keys: list,
        target_dir: str,
        max_workers: int = DOWNLOAD_MAX_CONCURRENCY,
    ) -> list:
        """
        Download multiple R2 objects (model weight shards) in parallel.
        Reduces time-to-inference for large models from O(N) sequential to O(1) parallel.

        Example: 1.2 TB model in 20 x 64 GB shards -> all pulled simultaneously.
        With 10 Gbps link: sequential=~19min, parallel=~2min (10x speedup).

        Returns list of local file paths in the same order as r2_keys.
        """
        target = Path(target_dir)
        target.mkdir(parents=True, exist_ok=True)
        local_paths = [None] * len(r2_keys)

        def download_shard(idx_key):
            idx, key = idx_key
            local_path = target / Path(key).name
            start = time.monotonic()
            response = self._s3.get_object(Bucket=self.bucket, Key=key)
            compressed = response["Body"].read()

            # GAP-27: Verify SHA256 of compressed bytes if the uploader
            # stored one in object metadata (upload_checkpoint + multipart
            # both do). Bit-flip or truncation in transit is otherwise
            # silent — data decompresses but produces garbage weights.
            # Mirror the same check `download_checkpoint()` does for
            # single-object downloads.
            obj_meta = response.get("Metadata", {})
            expected_sha256 = (
                obj_meta.get("sha256")
                or response.get("ResponseMetadata", {}).get("HTTPHeaders", {}).get("x-amz-meta-sha256")
            )
            if expected_sha256:
                actual_sha256 = hashlib.sha256(compressed).hexdigest()
                if actual_sha256 != expected_sha256:
                    raise ValueError(
                        f"Shard checksum mismatch for {key}: "
                        f"expected {expected_sha256}, got {actual_sha256}. "
                        f"Shard may be corrupted in transit."
                    )

            data = zlib.decompress(compressed)
            local_path.write_bytes(data)
            elapsed = time.monotonic() - start
            speed_gbps = (len(data) / 1e9) / elapsed * 8 if elapsed > 0 else 0
            logger.info(f"Shard [{idx+1}/{len(r2_keys)}] {key} -> {local_path} "
                        f"({len(data)/1e9:.2f} GB, {speed_gbps:.2f} Gbps"
                        f"{', sha256-verified' if expected_sha256 else ''})")
            return idx, str(local_path)

        logger.info(
            f"Parallel shard download: {len(r2_keys)} shards, "
            f"concurrency={max_workers}, target={target_dir}"
        )
        start_total = time.monotonic()

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(download_shard, (i, k)): i for i, k in enumerate(r2_keys)}
            for future in concurrent.futures.as_completed(futures):
                idx, path = future.result()
                local_paths[idx] = path

        elapsed_total = time.monotonic() - start_total
        logger.info(f"All {len(r2_keys)} shards downloaded in {elapsed_total:.1f}s")
        return local_paths


    # -- Dark checkpoint purge -------------------------------------------------

    def purge_dark_checkpoints(self, job_id: str) -> int:
        """Delete step directories that have checkpoint data but no _MANIFEST.json.

        These are left by a crash that happened between the data upload and the
        manifest write. Without this cleanup, restore would silently skip the
        incomplete step (no manifest → not trusted), but the orphaned objects
        still accumulate in R2 and accrue storage charges.

        Called automatically at the start of every upload_checkpoint() call.
        Safe to call at any time — only deletes dirs with no manifest.
        Returns number of objects deleted.
        """
        prefix = f"checkpoints/{job_id}/"
        paginator = self._s3.get_paginator("list_objects_v2")

        step_dirs: set = set()
        manifest_dirs: set = set()
        try:
            for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix):
                for obj in page.get("Contents", []):
                    key = obj["Key"]
                    rel = key[len(prefix):]
                    parts = rel.split("/")
                    if parts and parts[0].startswith("step-"):
                        step_dir = f"{prefix}{parts[0]}/"
                        step_dirs.add(step_dir)
                        if len(parts) > 1 and parts[1] == "_MANIFEST.json":
                            manifest_dirs.add(step_dir)
        except Exception as _list_err:
            logger.warning(f"[R2] purge_dark_checkpoints list failed for {job_id}: {_list_err}")
            return 0

        dark_dirs = step_dirs - manifest_dirs
        if not dark_dirs:
            return 0

        keys_to_delete: list = []
        for dark_dir in dark_dirs:
            keys_to_delete.extend(self.list_all_objects(dark_dir))

        if not keys_to_delete:
            return 0

        logger.warning(
            f"[R2] Purging {len(dark_dirs)} dark checkpoint dir(s) for job {job_id} "
            f"({len(keys_to_delete)} objects): {sorted(dark_dirs)}"
        )
        deleted = 0
        for i in range(0, len(keys_to_delete), 1000):
            chunk = keys_to_delete[i:i + 1000]
            try:
                response = self._s3.delete_objects(
                    Bucket=self.bucket,
                    Delete={"Objects": [{"Key": k} for k in chunk], "Quiet": True},
                )
                errors = response.get("Errors", [])
                for err in errors:
                    logger.error(f"[R2] Failed to delete dark object {err['Key']}: {err['Message']}")
                deleted += len(chunk) - len(errors)
            except Exception as _del_err:
                logger.warning(f"[R2] delete_objects failed during purge: {_del_err}")
        return deleted

    # -- Deletion (GDPR right to erasure) -------------------------------------

    def delete_job_checkpoints(self, job_id: str, user_id: str = "default") -> int:
        """
        Delete all R2 objects for a job (all checkpoint steps).
        Returns number of objects deleted.
        Used by `vaultlayer delete-job` for GDPR right to erasure.

        Prefix must match the write path in save_checkpoint() and
        list_checkpoints(): checkpoints/{job_id}/. The earlier version
        used checkpoints/{user_id}/{job_id}/ which silently missed every
        real checkpoint — a GDPR-delete that deleted nothing. user_id is
        retained in the signature for audit/logging only.
        """
        prefix = f"checkpoints/{job_id}/"
        keys = self.list_all_objects(prefix)
        if not keys:
            logger.info(f"No checkpoints found for job {job_id} (user={user_id})")
            return 0
        # S3 delete_objects accepts up to 1000 keys per call
        deleted = 0
        chunk_size = 1000
        for i in range(0, len(keys), chunk_size):
            chunk = keys[i:i + chunk_size]
            response = self._s3.delete_objects(
                Bucket=self.bucket,
                Delete={"Objects": [{"Key": k} for k in chunk], "Quiet": True},
            )
            errors = response.get("Errors", [])
            if errors:
                for err in errors:
                    logger.error(f"Failed to delete {err['Key']}: {err['Message']}")
            deleted += len(chunk) - len(errors)
        logger.info(f"Deleted {deleted} checkpoint objects for job {job_id}")
        return deleted

    def list_all_objects(self, prefix: str) -> list:
        """List all object keys under a prefix (handles pagination)."""
        keys = []
        paginator = self._s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                keys.append(obj["Key"])
        return keys
    # -- List / Query -----------------------------------------------------------

    def list_checkpoints(self, job_id: str) -> List[dict]:
        """List all checkpoints for a job, sorted newest first."""
        prefix = f"checkpoints/{job_id}/"
        paginator = self._s3.get_paginator("list_objects_v2")
        items = []
        for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix, Delimiter="/"):
            for obj in page.get("CommonPrefixes", []):
                # Each prefix is a step directory
                items.append({
                    "prefix": obj["Prefix"],
                    "step": int(obj["Prefix"].split("step-")[1].rstrip("/")) if "step-" in obj["Prefix"] else 0,
                })
        return sorted(items, key=lambda x: x["step"], reverse=True)

    def get_latest_checkpoint_key(self, job_id: str) -> Optional[str]:
        """Return R2 key of the most recent checkpoint for a job."""
        checkpoints = self.list_checkpoints(job_id)
        if not checkpoints:
            return None
        prefix = checkpoints[0]["prefix"]
        response = self._s3.list_objects_v2(Bucket=self.bucket, Prefix=prefix)
        objects = response.get("Contents", [])
        return objects[0]["Key"] if objects else None

    def checkpoint_exists(self, r2_key: str) -> bool:
        try:
            self._s3.head_object(Bucket=self.bucket, Key=r2_key)
            return True
        except ClientError:
            return False

    # -- Namespace Sync ---------------------------------------------------------

    def sync_namespace_manifest(self, job_id: str, manifest: dict):
        """Write a JSON manifest so all nodes see the same file namespace."""
        import json
        key = f"namespace/{job_id}/manifest.json"
        self._s3.put_object(
            Bucket=self.bucket,
            Key=key,
            Body=json.dumps(manifest, default=str).encode(),
            ContentType="application/json",
        )

    def get_namespace_manifest(self, job_id: str) -> Optional[dict]:
        import json
        key = f"namespace/{job_id}/manifest.json"
        try:
            response = self._s3.get_object(Bucket=self.bucket, Key=key)
            return json.loads(response["Body"].read())
        except ClientError:
            return None

    # GAP-10: Atomic ETag-based namespace manifest update
    async def update_namespace_manifest_atomic(
        self, job_id: str, new_entry: dict, max_retries: int = 5
    ) -> None:
        """Atomically append to namespace manifest using ETag-based CAS (GAP-10)."""
        import asyncio as _asyncio
        import json as _json
        for attempt in range(max_retries):
            try:
                # Read current manifest + its ETag
                try:
                    response = self._s3.get_object(
                        Bucket=self.bucket,
                        Key=f"namespace/{job_id}/manifest.json",
                    )
                    etag = response["ETag"]
                    manifest = _json.loads(response["Body"].read())
                except ClientError:
                    etag = None
                    manifest = {"job_id": job_id, "checkpoint_chain": []}

                chain = manifest.get("checkpoint_chain", [])
                chain.append(new_entry)
                manifest["checkpoint_chain"] = chain
                manifest["latest_step"] = new_entry.get("step")

                put_kwargs: dict = dict(
                    Bucket=self.bucket,
                    Key=f"namespace/{job_id}/manifest.json",
                    Body=_json.dumps(manifest, default=str).encode(),
                    ContentType="application/json",
                )
                if etag:
                    put_kwargs["IfMatch"] = etag
                self._s3.put_object(**put_kwargs)
                return  # success
            except Exception as e:
                if "PreconditionFailed" in str(e) or "412" in str(e):
                    await _asyncio.sleep(0.1 * (2 ** attempt))
                    continue
                raise
        raise RuntimeError(
            f"Failed to update namespace manifest for {job_id} after {max_retries} retries"
        )

    # GAP-11: Orphaned multipart upload cleanup
    def cleanup_orphaned_multipart_uploads(self, max_age_hours: int = 24) -> int:
        """Delegate to standalone cleanup_orphaned_multipart_uploads()."""
        return _cleanup_orphaned_fn(self._s3, self.bucket, max_age_hours)

    def ensure_lifecycle_policy(self) -> bool:
        """Apply an S3 lifecycle rule to auto-abort dangling multipart uploads after 24h.

        COST GUARDRAIL (Cloudflare R2 'Dangling Multipart' problem):
        When a training node hard-crashes mid-upload, incomplete multipart uploads
        persist in R2 and accrue storage charges indefinitely.  This lifecycle rule
        instructs Cloudflare to abort any incomplete upload after 24 hours automatically
        — even if our process is dead and cannot call cleanup_orphaned_multipart_uploads().

        This is idempotent: calling it multiple times is safe (rule is merged/upserted).
        Call once from VaultAgent.start() to set-and-forget.

        Also enforces Standard Storage class: Infrequent Access would charge a flat
        $9.00 for the first million Class A ops (vs $0.36/M on Standard) and impose
        a 30-day minimum retention, making it dramatically more expensive for our
        high-churn checkpoint workload.

        Returns True if policy was applied (or already in place), False on error.
        """
        try:
            rule = {
                "ID": "vaultlayer-abort-incomplete-multipart",
                "Status": "Enabled",
                "Filter": {"Prefix": ""},  # apply to all objects in bucket
                "AbortIncompleteMultipartUpload": {"DaysAfterInitiation": 1},
            }

            # Merge with any existing rules (don't overwrite user rules)
            try:
                existing = self._s3.get_bucket_lifecycle_configuration(Bucket=self.bucket)
                rules = existing.get("Rules", [])
            except self._s3.exceptions.ClientError:
                rules = []
            except Exception:
                rules = []

            # Remove our rule if already present (upsert pattern)
            rules = [r for r in rules if r.get("ID") != rule["ID"]]
            rules.append(rule)

            self._s3.put_bucket_lifecycle_configuration(
                Bucket=self.bucket,
                LifecycleConfiguration={"Rules": rules},
            )
            logger.info(
                f"[R2] Lifecycle policy applied: incomplete multipart uploads "
                f"auto-aborted after 24h on bucket '{self.bucket}'"
            )
            return True

        except Exception as e:
            # Cloudflare R2 supports S3 lifecycle rules (as of 2024), but older
            # accounts or misconfigured endpoints may not. Log and continue.
            logger.warning(
                f"[R2] Could not apply lifecycle policy (non-fatal): {e}. "
                "Dangling multipart cleanup will rely on cleanup_orphaned_multipart_uploads() instead."
            )
            return False

    def verify_standard_storage_class(self) -> None:
        """Warn if any checkpoint objects are on Infrequent Access storage class.

        COST GUARDRAIL: Cloudflare R2 Infrequent Access charges:
          - Flat $9.00 for the FIRST million Class A ops (vs $0.36/M on Standard)
          - High retrieval fees on GET (Class B)
          - 30-day minimum retention (penalizes short-lived training runs)

        Our checkpoints are read immediately on migration (high read frequency)
        and deleted after job completion (short retention). Standard Storage is
        strictly cheaper for this access pattern.

        Note: Cloudflare R2 does not expose a storage-class API endpoint identical
        to AWS S3. This check samples recent objects to detect if IA was applied.
        """
        try:
            resp = self._s3.list_objects_v2(
                Bucket=self.bucket, Prefix="checkpoints/", MaxKeys=10
            )
            for obj in resp.get("Contents", []):
                storage_class = obj.get("StorageClass", "STANDARD")
                if storage_class not in ("STANDARD", "", None):
                    logger.warning(
                        f"[R2] COST ALERT: Object {obj['Key']!r} has storage class "
                        f"'{storage_class}'. VaultLayer checkpoints MUST use Standard "
                        f"Storage. Infrequent Access would charge $9/M Class A ops "
                        f"(vs $0.36/M) and impose 30-day minimum retention fees. "
                        f"Please reconfigure the '{self.bucket}' bucket to Standard."
                    )
        except Exception:
            pass  # non-fatal — best-effort check

    # GAP-13: Bucket privacy verification
    def verify_bucket_private(self) -> bool:
        """Check that the R2 bucket is not publicly accessible (GAP-13)."""
        try:
            response = self._s3.get_bucket_acl(Bucket=self.bucket)
            for grant in response.get("Grants", []):
                grantee = grant.get("Grantee", {})
                uri = grantee.get("URI", "")
                if uri.endswith("AllUsers") or uri.endswith("AuthenticatedUsers"):
                    return False
            return True
        except Exception:
            return True  # can't check → assume private (R2 may not support ACL endpoint)

    # -- Helpers ----------------------------------------------------------------

    def _tar_directory(self, path: Path) -> bytes:
        """Tar a directory into bytes for upload."""
        import tarfile
        import io
        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode="w") as tar:
            tar.add(path, arcname=path.name)
        return buf.getvalue()

    # -- Backup bucket (S6: Regional Blackout protection) -------------------------
    # R2 has no native replication. Two global R2 outages in 2025 (Feb 6: 59min,
    # Mar 21: 67min). Client-side dual-write is the only reliable solution.
    # Configure via env vars. If not set, mirror is a no-op.
    BACKUP_R2_ENDPOINT   = os.environ.get("VAULTLAYER_BACKUP_R2_ENDPOINT", "")
    BACKUP_R2_BUCKET     = os.environ.get("VAULTLAYER_BACKUP_R2_BUCKET", "")
    BACKUP_R2_ACCESS_KEY = os.environ.get("VAULTLAYER_BACKUP_R2_ACCESS_KEY", "")
    BACKUP_R2_SECRET_KEY = os.environ.get("VAULTLAYER_BACKUP_R2_SECRET_KEY", "")

    def _get_backup_client(self):
        """Return (boto3_client, bucket_name) for backup R2, or (None, None) if not configured."""
        if not self.BACKUP_R2_ENDPOINT or not self.BACKUP_R2_BUCKET:
            return None, None
        import boto3 as _boto3
        client = _boto3.client(
            "s3",
            endpoint_url=self.BACKUP_R2_ENDPOINT,
            aws_access_key_id=self.BACKUP_R2_ACCESS_KEY,
            aws_secret_access_key=self.BACKUP_R2_SECRET_KEY,
        )
        return client, self.BACKUP_R2_BUCKET

    def _mirror_to_backup(self, r2_key: str, data: bytes) -> bool:
        """
        Mirror-write compressed checkpoint bytes to backup bucket.
        Returns True on success, False on failure (failure is non-fatal).
        """
        client, bucket = self._get_backup_client()
        if not client:
            return False
        try:
            client.put_object(Bucket=bucket, Key=r2_key, Body=data)
            logger.info(f"Checkpoint {r2_key} mirrored to backup bucket")
            return True
        except Exception as e:
            logger.warning(f"Backup mirror failed for {r2_key}: {e} -- primary copy safe")
            return False
    def healthcheck(self) -> bool:
        """Verify R2 bucket is accessible."""
        try:
            self._s3.head_bucket(Bucket=self.bucket)
            return True
        except Exception as e:
            logger.error(f"R2 healthcheck failed: {e}")
            return False
