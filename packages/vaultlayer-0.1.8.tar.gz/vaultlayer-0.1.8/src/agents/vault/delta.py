"""
VaultLayer -- Vault Agent: Delta Compression

XOR-based delta compression for consecutive training checkpoints.
Consecutive checkpoints share ~95-99% of bytes; XOR produces a sparse
array that compresses to ~1-5% of original size.
"""

import hashlib
import logging
import time
import zlib
from datetime import datetime
from pathlib import Path
from typing import Optional

from shared.models import CheckpointRecord, CheckpointType
from shared.retry import sync_retry

logger = logging.getLogger(__name__)

# Process files in 32 MB chunks so we never load a full 30B model into memory at once
DELTA_CHUNK_SIZE = 32 * 1024 * 1024


def compute_xor_delta(prev_path: Path, curr_path: Path) -> Optional[bytes]:
    """
    Stream-XOR two checkpoint files and return the zlib-compressed delta.

    Why XOR works well here: consecutive training checkpoints share ~95-99%
    of their bytes. XOR produces a sparse array (mostly zeros) that compresses
    to ~1-5% of the original file size.

    Returns None when files are different sizes (architecture changed).
    """
    if prev_path.stat().st_size != curr_path.stat().st_size:
        return None

    try:
        import numpy as np
        _has_numpy = True
    except ImportError:
        _has_numpy = False

    compressor = zlib.compressobj(level=9)
    output_chunks: list[bytes] = []

    with open(prev_path, "rb") as f_prev, open(curr_path, "rb") as f_curr:
        while True:
            prev_chunk = f_prev.read(DELTA_CHUNK_SIZE)
            curr_chunk = f_curr.read(DELTA_CHUNK_SIZE)
            if not prev_chunk:
                break
            if _has_numpy:
                xor_chunk = (
                    np.frombuffer(prev_chunk, dtype=np.uint8) ^
                    np.frombuffer(curr_chunk, dtype=np.uint8)
                ).tobytes()
            else:
                xor_chunk = bytes(a ^ b for a, b in zip(prev_chunk, curr_chunk))
            output_chunks.append(compressor.compress(xor_chunk))

    output_chunks.append(compressor.flush())
    return b"".join(output_chunks)


def apply_xor_delta(
    base_path: Path, delta_compressed: bytes, output_path: Path
) -> None:
    """
    Apply a compressed XOR delta to a base file to recover the original.

    Streams base file in DELTA_CHUNK_SIZE chunks to avoid loading a full
    model snapshot into memory at once.
    """
    try:
        import numpy as np
        _has_numpy = True
    except ImportError:
        _has_numpy = False

    delta = zlib.decompress(delta_compressed)
    delta_view = memoryview(delta)
    offset = 0

    with open(base_path, "rb") as f_in, open(output_path, "wb") as f_out:
        while True:
            base_chunk = f_in.read(DELTA_CHUNK_SIZE)
            if not base_chunk:
                break
            chunk_len = len(base_chunk)
            delta_slice = bytes(delta_view[offset: offset + chunk_len])
            offset += chunk_len

            if _has_numpy:
                restored = (
                    np.frombuffer(base_chunk, dtype=np.uint8) ^
                    np.frombuffer(delta_slice, dtype=np.uint8)
                ).tobytes()
            else:
                restored = bytes(a ^ b for a, b in zip(base_chunk, delta_slice))
            f_out.write(restored)


def upload_delta(
    s3_client,
    bucket: str,
    job_id: str,
    step: int,
    base_step: int,
    prev_local_path: str,
    curr_local_path: str,
    model_params_billion: float,
    epoch: float = 0.0,
    training_loss: Optional[float] = None,
    verify_upload_fn=None,
) -> Optional[CheckpointRecord]:
    """
    Compute and upload an XOR delta between prev and current checkpoint.

    Only the changed bytes are stored: for a 7B model, a typical training
    step touches ~1-5% of weights, so the compressed delta is ~50-300 MB
    instead of ~28 GB -- a 100-300x reduction in transfer size.

    Returns None if a full snapshot is required (model size changed).

    Args:
        s3_client: boto3 S3 client instance
        bucket: R2 bucket name
        job_id: job identifier
        step: current training step
        base_step: step of the base checkpoint for delta
        prev_local_path: path to previous checkpoint file
        curr_local_path: path to current checkpoint file
        model_params_billion: model size in billions of parameters
        epoch: training epoch
        training_loss: current training loss
        verify_upload_fn: optional callable(r2_key, size, sha256) for integrity check
    """
    prev_path = Path(prev_local_path)
    curr_path = Path(curr_local_path)

    if not prev_path.exists() or not curr_path.exists():
        logger.warning(f"[{job_id}] Cannot compute delta: path missing")
        return None

    start = time.monotonic()
    delta_compressed = compute_xor_delta(prev_path, curr_path)

    if delta_compressed is None:
        logger.info(
            f"[{job_id}] Model file size changed at step {step} -- "
            "delta not possible, caller should fall back to full snapshot"
        )
        return None

    full_size = curr_path.stat().st_size
    delta_size = len(delta_compressed)
    reduction_pct = (1 - delta_size / full_size) * 100 if full_size else 0

    # Store alongside the full snapshot key with a .delta suffix
    r2_key = f"checkpoints/{job_id}/step-{step:08d}/{curr_path.name}.delta"

    delta_sha256 = hashlib.sha256(curr_path.read_bytes()).hexdigest()
    _delta_meta = {
        "job_id": job_id,
        "step": str(step),
        "base_step": str(base_step),
        "epoch": str(epoch),
        "model_params_billion": str(model_params_billion),
        "checkpoint_type": "delta",
        "original_size_bytes": str(full_size),
        "delta_size_bytes": str(delta_size),
        "sha256": delta_sha256,
        "training_loss": str(training_loss) if training_loss else "",
    }
    _delta_body = delta_compressed
    # P0-C1: retry delta upload on transient R2 errors
    sync_retry(
        lambda: s3_client.put_object(
            Bucket=bucket,
            Key=r2_key,
            Body=_delta_body,
            ContentType="application/octet-stream",
            Metadata=_delta_meta,
        ),
        attempts=5,
        delays=(1, 2, 5, 10, 30),
        label=f"put_object delta {r2_key}",
    )
    # P0-C2: Verify delta integrity
    if verify_upload_fn:
        verify_upload_fn(r2_key, len(delta_compressed), delta_sha256)

    # GAP-9: Write _DELTA_MANIFEST.json alongside the delta file
    import json as _json
    try:
        delta_manifest = {
            "step": step,
            "base_step": base_step,
            "r2_key": r2_key,
            "sha256": delta_sha256,
            "size_bytes": delta_size,
            "complete": True,
            "created_at": datetime.utcnow().isoformat(),
        }
        manifest_key = r2_key.replace(".delta", "/_DELTA_MANIFEST.json")
        s3_client.put_object(
            Bucket=bucket,
            Key=manifest_key,
            Body=_json.dumps(delta_manifest).encode(),
            ContentType="application/json",
        )
    except Exception as _dm_err:
        logger.warning(f"[{job_id}] Delta manifest write failed (non-fatal): {_dm_err}")

    duration = time.monotonic() - start
    logger.info(
        f"[{job_id}] Delta step {base_step}->{step} uploaded: "
        f"{delta_size / 1e6:.1f} MB ({reduction_pct:.1f}% smaller than "
        f"{full_size / 1e9:.2f} GB full) in {duration:.1f}s "
        f"-> r2://{bucket}/{r2_key}"
    )

    return CheckpointRecord(
        job_id=job_id,
        step=step,
        epoch=epoch,
        r2_key=r2_key,
        size_bytes=full_size,
        sync_duration_seconds=duration,
        model_params_billion=model_params_billion,
        training_loss=training_loss,
        checkpoint_type=CheckpointType.DELTA,
        base_step=base_step,
        delta_size_bytes=delta_size,
    )


def restore_from_chain(
    s3_client,
    bucket: str,
    job_id: str,
    target_step: int,
    target_dir: str,
    get_namespace_manifest_fn,
    download_checkpoint_fn,
) -> Optional[str]:
    """
    Restore a checkpoint by replaying its delta chain.

    Sequence:
      1. Load the manifest to find the base full snapshot.
      2. Download the base to a temp dir.
      3. Download each delta between base and target_step.
      4. Apply deltas in order via XOR, producing the final weights.
      5. Move the result to target_dir.

    Args:
        s3_client: boto3 S3 client instance
        bucket: R2 bucket name
        job_id: job identifier
        target_step: target checkpoint step to restore
        target_dir: directory to write restored checkpoint to
        get_namespace_manifest_fn: callable(job_id) -> dict or None
        download_checkpoint_fn: callable(record, dir) -> str

    Returns local path of the restored file, or None on failure.
    """
    import shutil
    import tempfile

    manifest = get_namespace_manifest_fn(job_id)
    if not manifest or "checkpoint_chain" not in manifest:
        logger.warning(f"[{job_id}] No chain manifest -- falling back to direct restore")
        return None

    chain: list[dict] = manifest["checkpoint_chain"]
    target_entry = next((c for c in chain if c["step"] == target_step), None)
    if not target_entry:
        logger.error(f"[{job_id}] Step {target_step} not found in chain")
        return None

    # Full snapshot -- nothing to chain, just a normal download
    if target_entry["type"] == "full":
        record = CheckpointRecord(
            job_id=job_id, step=target_step, epoch=0,
            r2_key=target_entry["r2_key"],
            size_bytes=0, sync_duration_seconds=0, model_params_billion=0,
        )
        return download_checkpoint_fn(record, target_dir)

    # Delta -- find base full snapshot and all intermediate deltas
    base_step = target_entry["base_step"]
    base_entry = next(
        (c for c in chain if c["step"] == base_step and c["type"] == "full"), None
    )
    if not base_entry:
        logger.error(f"[{job_id}] Base snapshot at step {base_step} not in chain")
        return None

    delta_entries = sorted(
        [c for c in chain
         if c["type"] == "delta"
         and c.get("base_step") == base_step
         and c["step"] <= target_step],
        key=lambda x: x["step"],
    )

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)

        # Step 1: download base full snapshot
        logger.info(f"[{job_id}] Restoring chain: base step {base_step} + {len(delta_entries)} delta(s)")
        base_record = CheckpointRecord(
            job_id=job_id, step=base_step, epoch=0,
            r2_key=base_entry["r2_key"],
            size_bytes=0, sync_duration_seconds=0, model_params_billion=0,
        )
        base_local = Path(download_checkpoint_fn(base_record, str(tmp / "base")))
        current_path = base_local

        # Step 2: apply each delta in sequence
        for entry in delta_entries:
            logger.info(f"[{job_id}] Applying delta step {entry['step']}")
            response = s3_client.get_object(Bucket=bucket, Key=entry["r2_key"])
            delta_compressed = response["Body"].read()

            out_name = Path(entry["r2_key"]).name.replace(".delta", "")
            out_path = tmp / f"step-{entry['step']:08d}" / out_name
            out_path.parent.mkdir(parents=True, exist_ok=True)
            apply_xor_delta(current_path, delta_compressed, out_path)

            # GAP-27: Verify SHA256 of reconstructed file against manifest entry
            result_sha256 = entry.get("sha256")
            if result_sha256:
                actual = hashlib.sha256(out_path.read_bytes()).hexdigest()
                if actual != result_sha256:
                    raise ValueError(
                        f"Delta reconstruction checksum mismatch at step {entry['step']}: "
                        f"expected {result_sha256}, got {actual}. "
                        f"Delta chain may be corrupted."
                    )

            current_path = out_path

        # Step 3: move final result to target_dir
        Path(target_dir).mkdir(parents=True, exist_ok=True)
        final_path = Path(target_dir) / current_path.name
        shutil.copy2(current_path, final_path)

    logger.info(f"[{job_id}] Chain restore complete -> {final_path}")
    return str(final_path)
