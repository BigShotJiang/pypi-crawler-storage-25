"""
VaultLayer -- Vault Agent: Multipart Upload

S3/R2 multipart upload with parallel part transfers and orphaned upload cleanup.
"""

import concurrent.futures
import logging
import math
import threading
from datetime import datetime

from shared.retry import sync_retry

logger = logging.getLogger(__name__)

# -- Multipart upload config ------------------------------------------------
# R2 Class A cost: $0.36/million operations. Each uploaded PART counts as one
# Class A op regardless of size. With 64 MB parts, a 20 GB checkpoint = 320 ops.
# With 200 MB parts, the same file = ~103 ops -- a 68% reduction.
#
# Maximum stable part size for Cloudflare R2 is 5 GB (S3-compatible limit), but
# 200 MB balances throughput vs memory footprint. Never go below 5 MB (S3 minimum
# for non-final parts) or above 5 GB (S3 hard limit).
#
# Part count math for common checkpoint sizes:
#   7B model  (~14 GB compressed) : 200MB -> 72 parts   vs 64MB -> 224 parts
#   13B model (~26 GB compressed) : 200MB -> 133 parts  vs 64MB -> 416 parts
#   70B model (~140 GB compressed): 200MB -> 716 parts  vs 64MB -> 2240 parts
MULTIPART_THRESHOLD_BYTES = 200 * 1024 * 1024       # 200 MB -- use multipart above this
MULTIPART_CHUNK_SIZE_BYTES = 200 * 1024 * 1024       # 200 MB per part (was 64MB -- 68% fewer Class A ops)
MULTIPART_MAX_CONCURRENCY  = 5                        # keep memory footprint bounded: 5 x 200MB = 1 GB RAM
DOWNLOAD_MAX_CONCURRENCY   = 8                        # parallel shard downloads


def upload_multipart(s3_client, bucket: str, data: bytes, r2_key: str, metadata: dict) -> None:
    """
    Upload large objects using S3 multipart upload with parallel part transfers.
    Chunks data into MULTIPART_CHUNK_SIZE_BYTES parts and uploads concurrently.
    Handles models >1 TB that would time out with a single put_object call.

    Args:
        s3_client: boto3 S3 client instance
        bucket: R2 bucket name
        data: compressed checkpoint bytes to upload
        r2_key: S3 key for the object
        metadata: object metadata dict
    """
    total_size = len(data)
    chunk_size = MULTIPART_CHUNK_SIZE_BYTES
    num_parts = math.ceil(total_size / chunk_size)

    logger.info(
        f"Multipart upload: {total_size / 1e9:.2f} GB -> {num_parts} parts "
        f"x {chunk_size / 1e6:.0f} MB, concurrency={MULTIPART_MAX_CONCURRENCY}"
    )

    # Initiate
    mpu = s3_client.create_multipart_upload(
        Bucket=bucket, Key=r2_key,
        ContentType="application/octet-stream",
        Metadata=metadata,
    )
    upload_id = mpu["UploadId"]
    parts = [None] * num_parts
    lock = threading.Lock()

    def upload_part(part_number: int):
        start_byte = (part_number - 1) * chunk_size
        end_byte   = min(start_byte + chunk_size, total_size)
        part_data  = data[start_byte:end_byte]
        # P0-C1: retry each part on transient errors before failing the whole upload
        response = sync_retry(
            lambda: s3_client.upload_part(
                Bucket=bucket, Key=r2_key,
                UploadId=upload_id,
                PartNumber=part_number,
                Body=part_data,
            ),
            attempts=5,
            delays=(1, 2, 5, 10, 30),
            label=f"upload_part {r2_key} #{part_number}",
        )
        with lock:
            parts[part_number - 1] = {
                "PartNumber": part_number,
                "ETag": response["ETag"],
            }
        logger.debug(f"Part {part_number}/{num_parts} uploaded ({len(part_data) / 1e6:.1f} MB)")

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=MULTIPART_MAX_CONCURRENCY) as ex:
            futures = {ex.submit(upload_part, i + 1): i for i in range(num_parts)}
            for future in concurrent.futures.as_completed(futures):
                future.result()  # re-raise any part upload exception

        # P0-C1: retry complete_multipart_upload -- it's idempotent once all parts are present
        sync_retry(
            lambda: s3_client.complete_multipart_upload(
                Bucket=bucket, Key=r2_key,
                UploadId=upload_id,
                MultipartUpload={"Parts": parts},
            ),
            attempts=5,
            delays=(1, 2, 5, 10, 30),
            label=f"complete_multipart {r2_key}",
        )
        logger.info(f"Multipart upload complete -> r2://{bucket}/{r2_key}")

    except Exception as e:
        logger.error(f"Multipart upload failed, aborting: {e}")
        s3_client.abort_multipart_upload(
            Bucket=bucket, Key=r2_key, UploadId=upload_id
        )
        raise


def cleanup_orphaned_multipart_uploads(s3_client, bucket: str, max_age_hours: int = 24) -> int:
    """Abort multipart uploads older than max_age_hours. Returns count aborted (GAP-11).

    COST GUARDRAIL: If a training node hard-crashes mid-upload, Cloudflare holds
    the partial parts and charges storage for them indefinitely until aborted.
    This runs on VaultAgent.start() and periodically to prevent ghost-data billing.

    Two-layer defence:
      1. This function: immediate API-level abort of stale uploads (runs in-process).
      2. ensure_lifecycle_policy(): bucket-level S3 lifecycle rule that auto-aborts
         even if our process is also dead (belt-and-suspenders).

    Args:
        s3_client: boto3 S3 client instance
        bucket: R2 bucket name
        max_age_hours: abort uploads older than this many hours
    """
    from datetime import timezone, timedelta
    cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
    aborted = 0
    try:
        paginator = s3_client.get_paginator("list_multipart_uploads") if hasattr(
            s3_client, "get_paginator") else None
        if paginator:
            pages = paginator.paginate(Bucket=bucket)
            uploads = [u for page in pages for u in page.get("Uploads", [])]
        else:
            response = s3_client.list_multipart_uploads(Bucket=bucket)
            uploads = response.get("Uploads", [])

        for upload in uploads:
            initiated = upload.get("Initiated")
            if initiated and initiated < cutoff:
                s3_client.abort_multipart_upload(
                    Bucket=bucket,
                    Key=upload["Key"],
                    UploadId=upload["UploadId"],
                )
                aborted += 1
                logger.info(f"[R2] Aborted orphaned upload: {upload['Key']}")
    except Exception as e:
        logger.warning(f"[R2] Multipart cleanup failed: {e}")
    return aborted
