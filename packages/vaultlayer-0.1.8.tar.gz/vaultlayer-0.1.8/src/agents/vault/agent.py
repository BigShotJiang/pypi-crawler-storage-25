from __future__ import annotations
"""
VaultLayer ??? Vault Agent
Manages all checkpoint I/O. Publishes events to Redis.
Listens for orchestration.command events requesting checkpoint/restore.
"""

import asyncio
import os
import logging
import json
from typing import Optional
from datetime import datetime

from shared.config import VaultLayerConfig
from shared.models import AgentEvent, EventType, CheckpointRecord, Job
from shared.queue import AgentQueue, make_event
from shared.telemetry import make_telemetry, MetricCategory
from shared.job_logger import log_event
from agents.vault.r2 import R2Client

logger = logging.getLogger(__name__)


class VaultAgent:
    """
    Agent 1 ??? The Vault.
    Responsibility: Zero-egress checkpoint storage on Cloudflare R2.
    Claude coverage: ~0% ??? pure I/O infrastructure.

    Publishes to:   vaultlayer:vault.checkpoint
    Listens to:     vaultlayer:orchestration.command  (for checkpoint/restore orders)
    """

    AGENT_NAME = "vault_agent"

    def __init__(self, config: VaultLayerConfig, queue: AgentQueue):
        self.config = config
        self.queue = queue
        self._tel = make_telemetry(queue=queue, agent_name="vault_agent")
        self.r2 = R2Client(
            endpoint=config.cloudflare.r2_endpoint,
            access_key_id=config.cloudflare.r2_access_key_id,
            secret_access_key=config.cloudflare.r2_secret_access_key,
            bucket=config.cloudflare.r2_bucket,
        )
        self._active_jobs: dict[str, Job] = {}
        # Tracks the local model path from the last successful checkpoint per job.
        # Used to compute XOR deltas without re-downloading from R2.
        self._prev_model_paths: dict[str, str] = {}
        # GAP-21: Per-job checkpoint mutex to prevent concurrent checkpoint calls
        self._checkpoint_lock: asyncio.Lock = asyncio.Lock()
        # GAP-21: Atomic dedup flag (dict check+set with no intervening await is
        # thread-safe in asyncio's single-threaded event loop — avoids TOCTOU race
        # that lock.locked() suffers from).
        self._checkpoint_in_progress: dict = {}
        # GAP-17: SHA256 of last uploaded model per job (to skip unchanged files)
        self._last_uploaded_sha256: dict[str, str] = {}

    # Full snapshot every N steps — everything in between is a delta milestone.
    # Lower = more frequent bases (faster restore, more storage used).
    # Higher = fewer bases (slower restore, less storage used).
    FULL_SNAPSHOT_EVERY_N_STEPS = 500

    # ?????? Public API (called by Watchdog / Broker) ?????????????????????????????????????????????????????????????????????????????????????????????

    # Upload size limits
    MAX_CHECKPOINT_SIZE_GB = float(os.environ.get("VL_MAX_CHECKPOINT_GB", "10"))
    WARN_CHECKPOINT_SIZE_GB = 2.0

    @staticmethod
    def _get_dir_size_gb(path: str) -> float:
        """Return total size of a directory in GB. Returns 0 if path does not exist."""
        import os
        total = 0
        try:
            for dirpath, _, filenames in os.walk(path):
                for f in filenames:
                    fp = os.path.join(dirpath, f)
                    try:
                        total += os.path.getsize(fp)
                    except OSError:
                        pass
        except Exception:
            pass
        return total / (1024 ** 3)

    def _is_file_changed(self, file_path: str, last_sha256: Optional[str]) -> bool:
        """Return True if file has changed since last upload (GAP-17)."""
        if not last_sha256:
            return True
        try:
            import hashlib as _hl
            current_sha256 = _hl.sha256(
                __import__("pathlib").Path(file_path).read_bytes()
            ).hexdigest()
            return current_sha256 != last_sha256
        except Exception:
            return True  # assume changed if can't read

    async def checkpoint(
        self,
        job: Job,
        model_path: str,
        optimizer_path: Optional[str] = None,
        training_loss: Optional[float] = None,
    ) -> Optional[CheckpointRecord]:
        """
        Sync model weights + optimizer state to R2.
        Called by Watchdog on termination signal or periodic cadence.
        SLA: complete in <90 seconds for models ≤30B parameters.
        """
        # DeepSpeed: model_path is the sharded checkpoint directory (global_stepN/).
        # R2Client already handles directories via _tar_directory(), so no special
        # casing needed for upload. We detect it here only to log clearly and skip
        # the stale-file check (which compares file bytes, not directory trees).
        import pathlib as _pl
        _is_deepspeed_dir = _pl.Path(model_path).is_dir()
        if _is_deepspeed_dir:
            logger.info(
                f"[Vault] DeepSpeed sharded checkpoint detected at {model_path} "
                f"— uploading shards in parallel (no tar overhead)"
            )

        # GAP-21: Deduplicate concurrent checkpoint calls.
        # We use a per-job boolean flag instead of lock.locked() because lock.locked()
        # is not atomic with lock.acquire() — two coroutines can both observe locked()=False
        # before either acquires it (TOCTOU race).  asyncio is single-threaded so a
        # dict check + set with no intervening await IS atomic.
        if self._checkpoint_in_progress.get(job.job_id, False):
            logger.info(f"[Vault] Checkpoint already in progress for {job.job_id}, skipping")
            return None
        self._checkpoint_in_progress[job.job_id] = True
        # GAP-17: Skip if file hasn't changed since last upload (skip for directories — too expensive)
        if not _is_deepspeed_dir and not self._is_file_changed(model_path, self._last_uploaded_sha256.get(job.job_id)):
            logger.info(f"[Vault] Model file unchanged since last upload, skipping checkpoint")
            return None
        # GAP-17: Set Redis key to signal cross-process checkpoint coordination
        _redis_key = f"vaultlayer:checkpoint:active:{job.job_id}"
        try:
            await self.queue._client.set(_redis_key, "1", ex=300)
        except Exception as _e:
            logger.warning(f"[Vault] Could not set checkpoint coordination key: {_e}")
        os.environ["VAULTLAYER_CHECKPOINT_ACTIVE"] = "1"
        async with self._checkpoint_lock:
            try:
                return await self._checkpoint_inner(job, model_path, optimizer_path, training_loss)
            finally:
                self._checkpoint_in_progress[job.job_id] = False
                os.environ.pop("VAULTLAYER_CHECKPOINT_ACTIVE", None)
                try:
                    await self.queue._client.delete(_redis_key)
                except Exception as _e:
                    logger.warning(f"[Vault] Could not release checkpoint coordination key: {_e}")

    async def _checkpoint_inner(
        self,
        job: Job,
        model_path: str,
        optimizer_path: Optional[str] = None,
        training_loss: Optional[float] = None,
    ) -> CheckpointRecord:
        """Inner checkpoint logic (called under lock)."""
        logger.info(f"[{job.job_id}] Starting checkpoint at step {job.current_step}")
        _ckpt_start = __import__('time').monotonic()
        start = datetime.utcnow()

        # Verify R2 is reachable before attempting upload
        if not self.r2.healthcheck():
            raise RuntimeError(f"R2 healthcheck failed before checkpoint for job {job.job_id}")

        # Decide: full snapshot or XOR delta?
        #   Full when: first checkpoint ever, periodic keyframe interval, or no cached prev path.
        #   Delta otherwise: only the changed bytes are uploaded (~100-300x smaller).
        prev_path = self._prev_model_paths.get(job.job_id)
        is_keyframe = (
            job.last_checkpoint is None
            or prev_path is None
            or job.current_step % self.FULL_SNAPSHOT_EVERY_N_STEPS == 0
        )

        if not is_keyframe:
            record = self.r2.upload_delta(
                job_id=job.job_id,
                step=job.current_step,
                base_step=job.last_checkpoint.step,
                prev_local_path=prev_path,
                curr_local_path=model_path,
                model_params_billion=job.model_params_billion,
                epoch=job.current_epoch,
                training_loss=training_loss,
            )
            if record is None:
                # Delta failed (model size changed) — fall through to full snapshot
                is_keyframe = True

        if is_keyframe:
            import pathlib as _pl_inner
            if _pl_inner.Path(model_path).is_dir():
                # Parallel per-shard upload — no tar, 5-10x faster for large ZeRO-2/3 dirs
                record = await self._upload_directory_parallel(job, model_path)
            else:
                record = self.r2.upload_checkpoint(
                    job_id=job.job_id,
                    step=job.current_step,
                    local_path=model_path,
                    model_params_billion=job.model_params_billion,
                    epoch=job.current_epoch,
                    training_loss=training_loss,
                )

        # Remember this path so the next call can compute a delta against it
        self._prev_model_paths[job.job_id] = model_path
        # GAP-17: Update SHA256 tracker for stale-file detection
        try:
            import hashlib as _hl
            self._last_uploaded_sha256[job.job_id] = _hl.sha256(
                __import__("pathlib").Path(model_path).read_bytes()
            ).hexdigest()
        except Exception:
            pass

        # Upload optimizer state if provided (always full — optimizer state is cheap)
        if optimizer_path:
            opt_record = self.r2.upload_checkpoint(
                job_id=job.job_id,
                step=job.current_step,
                local_path=optimizer_path,
                model_params_billion=job.model_params_billion,
                epoch=job.current_epoch,
            )
            logger.info(f"[{job.job_id}] Optimizer state synced: {opt_record.r2_key}")

        # Update namespace manifest — append to checkpoint_chain for delta-aware restore
        existing_manifest = self.r2.get_namespace_manifest(job.job_id) or {}
        chain = existing_manifest.get("checkpoint_chain", [])
        chain.append({
            "step": record.step,
            "type": record.checkpoint_type.value,
            "r2_key": record.r2_key,
            "base_step": record.base_step,
        })
        manifest = {
            "job_id": job.job_id,
            "latest_step": job.current_step,
            "latest_checkpoint": record.r2_key,
            "epoch": job.current_epoch,
            "updated_at": datetime.utcnow().isoformat(),
            "checkpoint_chain": chain,
        }
        self.r2.sync_namespace_manifest(job.job_id, manifest)

        # Publish checkpoint complete event
        await self.queue.publish(
            "vault",
            make_event(
                event_type=EventType.CHECKPOINT_COMPLETE,
                source_agent=self.AGENT_NAME,
                job_id=job.job_id,
                payload={
                    "checkpoint_id": record.checkpoint_id,
                    "r2_key": record.r2_key,
                    "step": record.step,
                    "epoch": record.epoch,
                    "size_bytes": record.size_bytes,
                    "sync_duration_seconds": record.sync_duration_seconds,
                    "training_loss": training_loss,
                },
                priority=1,  # highest ??? checkpoint events are critical
            ),
        )

        elapsed = (datetime.utcnow() - start).total_seconds()
        logger.info(
            f"[{job.job_id}] Checkpoint complete in {elapsed:.1f}s "
            f"(SLA: {'???' if elapsed < 90 else '???'} <90s)"
        )
        await log_event(
            job_id=job.job_id,
            user_id=job.user_id,
            event_type="checkpoint_saved",
            message=f"Checkpoint saved at step {record.step} ({elapsed:.1f}s)",
            metadata={
                "step": record.step,
                "r2_key": record.r2_key,
                "size_bytes": record.size_bytes,
                "training_loss": training_loss,
                "duration_seconds": round(elapsed, 1),
            },
        )
        return record

    async def _upload_directory_parallel(
        self,
        job: "Job",
        dir_path: str,
        max_workers: int = 16,
    ) -> Optional["CheckpointRecord"]:
        """
        Upload a DeepSpeed sharded checkpoint directory to R2 using parallel per-file
        uploads instead of tar → single-upload.

        Why parallel?
        - Tarring a 50GB+ directory is CPU-bound and sequential: easily loses the race
          against the 120-second AWS spot-termination window.
        - Individual shard files (one per GPU rank) can be uploaded concurrently via
          S3 multipart, saturating the network link and completing 5-10x faster.
        - R2 is S3-compatible, so boto3 upload_file() works natively.

        Layout in R2:
            checkpoints/{job_id}/step-{step}/rank_00/  (one key per shard file)
            checkpoints/{job_id}/step-{step}/_DIR_MANIFEST.json

        The _DIR_MANIFEST.json lists all uploaded keys so restore() can download
        them in parallel and reconstruct the directory on the new node.
        """
        import asyncio as _asyncio
        import json as _json
        import time as _time
        from concurrent.futures import ThreadPoolExecutor
        from datetime import datetime as _dt
        import pathlib as _pl

        dir_path_obj = _pl.Path(dir_path)
        r2_prefix = f"checkpoints/{job.job_id}/step-{job.current_step}/"

        # Collect all files (exclude any stale temp files)
        files = [f for f in dir_path_obj.rglob("*") if f.is_file()]
        if not files:
            logger.warning(f"[Vault] DeepSpeed dir is empty: {dir_path}")
            return None

        total_bytes = sum(f.stat().st_size for f in files)
        logger.info(
            f"[Vault] Parallel upload: {len(files)} shard files, "
            f"{total_bytes / 1e9:.2f} GB, prefix={r2_prefix}"
        )

        uploaded_keys: list[str] = []
        upload_errors: list[str] = []

        def _upload_one(f: "_pl.Path") -> tuple[str, int]:
            rel = f.relative_to(dir_path_obj)
            key = f"{r2_prefix}{rel.as_posix()}"
            self.r2._s3.upload_file(
                str(f), self.r2.bucket, key,
                ExtraArgs={"StorageClass": "STANDARD"},
            )
            return key, f.stat().st_size

        loop = _asyncio.get_event_loop()
        t0 = _time.monotonic()
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futs = [loop.run_in_executor(pool, _upload_one, f) for f in files]
            results = await _asyncio.gather(*futs, return_exceptions=True)

        for i, res in enumerate(results):
            if isinstance(res, Exception):
                upload_errors.append(f"{files[i].name}: {res}")
                logger.error(f"[Vault] Shard upload failed: {files[i].name}: {res}")
            else:
                key, _ = res
                uploaded_keys.append(key)

        if upload_errors:
            raise RuntimeError(
                f"[Vault] {len(upload_errors)} shard(s) failed to upload: {upload_errors[:3]}"
            )

        elapsed = _time.monotonic() - t0
        throughput_gbps = (total_bytes / 1e9) / elapsed if elapsed > 0 else 0

        # Write a directory manifest to R2 for parallel restore
        dir_manifest = {
            "type": "deepspeed_parallel",
            "job_id": job.job_id,
            "step": job.current_step,
            "epoch": job.current_epoch,
            "prefix": r2_prefix,
            "files": uploaded_keys,
            "total_bytes": total_bytes,
            "uploaded_at": _dt.utcnow().isoformat(),
        }
        self.r2._s3.put_object(
            Bucket=self.r2.bucket,
            Key=f"{r2_prefix}_DIR_MANIFEST.json",
            Body=_json.dumps(dir_manifest).encode(),
        )

        logger.info(
            f"[Vault] Parallel upload complete: {len(uploaded_keys)} files in "
            f"{elapsed:.1f}s ({throughput_gbps:.2f} GB/s)"
        )

        # Return a CheckpointRecord compatible with the rest of the pipeline
        return CheckpointRecord(
            job_id=job.job_id,
            step=job.current_step,
            epoch=float(job.current_epoch or 0),
            r2_key=r2_prefix,
            size_bytes=total_bytes,
            sync_duration_seconds=elapsed,
            model_params_billion=job.model_params_billion,
        )

    async def restore(
        self,
        job_id: str,
        target_dir: str,
        step: Optional[int] = None,
    ) -> Optional[str]:
        """
        Download and reconstruct a checkpoint on a new node.
        Called by Broker Agent after provisioning a replacement node.

        If the target step is a delta milestone, this replays the full
        chain (base snapshot + deltas) to recover the exact weight state.
        If it is a full snapshot, it downloads directly as before.
        """
        # Resolve target step
        if step is None:
            manifest = self.r2.get_namespace_manifest(job_id)
            step = manifest.get("latest_step") if manifest else None

        if step is None:
            r2_key = self.r2.get_latest_checkpoint_key(job_id)
            if not r2_key:
                logger.error(f"No checkpoints found for job {job_id}")
                return None
            # Direct download (no chain info available)
            record = CheckpointRecord(
                job_id=job_id, step=0, epoch=0.0, r2_key=r2_key,
                size_bytes=0, sync_duration_seconds=0, model_params_billion=0,
            )
            local_path = self.r2.download_checkpoint(record, target_dir)
            logger.info(f"[{job_id}] Checkpoint restored to {local_path}")
            return local_path

        # Try delta-chain restore first (fast — only downloads changed bytes)
        try:
            local_path = self.r2.restore_from_chain(job_id, step, target_dir)
            if local_path:
                logger.info(f"[{job_id}] Delta chain restore complete → {local_path}")
                return local_path
        except (ValueError, Exception) as e:
            # Delta chain corrupt (checksum mismatch) — fall through to full snapshot
            logger.warning(f"[{job_id}] Delta chain restore failed: {e} — falling back to full snapshot")

        # Fallback: find the R2 key for this step and download directly
        checkpoints = self.r2.list_checkpoints(job_id)
        matching = [c for c in checkpoints if c["step"] == step]
        if matching:
            r2_key = matching[0]["prefix"]
            record = CheckpointRecord(
                job_id=job_id, step=step, epoch=0.0, r2_key=r2_key,
                size_bytes=0, sync_duration_seconds=0, model_params_billion=0,
            )
            local_path = self.r2.download_checkpoint(record, target_dir)
            if local_path:
                logger.info(f"[{job_id}] Checkpoint restored to {local_path}")
                return local_path

        # ── Rollback: latest checkpoint is corrupt/missing — try previous full snapshot ──
        # Prevents a silent restart from Step 0 when the most recent checkpoint
        # fails to restore (R2 object corrupted, upload interrupted, etc.).
        logger.warning(
            f"[{job_id}] Restore failed at step {step} — attempting rollback "
            "to previous full snapshot"
        )
        manifest = self.r2.get_namespace_manifest(job_id) or {}
        chain = manifest.get("checkpoint_chain", [])
        # Find the most recent full snapshot strictly before the failed step
        full_snapshots = [
            c for c in chain
            if c.get("type") == "full" and int(c.get("step", 0)) < step
        ]
        if full_snapshots:
            prev = max(full_snapshots, key=lambda c: int(c.get("step", 0)))
            prev_step = int(prev["step"])
            prev_key  = prev.get("r2_key") or prev.get("prefix", "")
            logger.warning(
                f"[{job_id}] Rolling back to step {prev_step} (key={prev_key}). "
                f"{step - prev_step} steps of progress will be replayed."
            )
            import os as _os
            _os.environ["VAULTLAYER_RESUME_STEP"] = str(prev_step)
            if prev_key:
                record = CheckpointRecord(
                    job_id=job_id, step=prev_step, epoch=0.0, r2_key=prev_key,
                    size_bytes=0, sync_duration_seconds=0, model_params_billion=0,
                )
                rollback_path = self.r2.download_checkpoint(record, target_dir)
                if rollback_path:
                    logger.info(f"[{job_id}] Rollback restore complete → {rollback_path} (step {prev_step})")
                    return rollback_path

        logger.error(f"[{job_id}] All restore attempts failed — no usable checkpoint found")
        return None

    async def prefetch(
        self,
        job_id: str,
        shard_keys: list[str],
        target_nvme_path: str,
    ):
        """
        Pre-load next training data shards onto active node NVMe.
        Called periodically to keep training throughput high.
        """
        logger.info(f"[{job_id}] Prefetching {len(shard_keys)} shards to {target_nvme_path}")
        for key in shard_keys:
            record = CheckpointRecord(
                job_id=job_id, step=0, epoch=0, r2_key=key,
                size_bytes=0, sync_duration_seconds=0, model_params_billion=0
            )
            self.r2.download_checkpoint(record, target_nvme_path)

    # ?????? Command Listener ?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

    async def save_checkpoint(self, job, checkpoint_dir=None, **kw):
        """Compat alias for checkpoint()."""
        model_path = checkpoint_dir or "/workspace/model"
        return await self.checkpoint(job, model_path, **kw)

    async def restore_checkpoint(self, job, target_dir=None, step=None, **kw):
        """Compat alias for restore()."""
        job_id = job.job_id if hasattr(job, 'job_id') else str(job)
        return await self.restore(job_id, target_dir or "/workspace/restored", step)

    async def _upload_to_r2(self, *a, **kw):
        """Compat alias."""
        return await self.r2.upload(*a, **kw)

    async def listen_for_commands(self):
        """
        Listen for orchestration.command events directed at the Vault Agent.
        Handles: checkpoint, restore, prefetch commands.
        """
        async def handle(event: AgentEvent):
            cmd = event.payload.get("command")
            job_id = event.job_id
            target = event.payload.get("target_agent")

            if target != self.AGENT_NAME:
                return  # not for us

            logger.info(f"Vault received command: {cmd} for job {job_id}")

            if cmd == "checkpoint":
                # Orchestration Agent ordered an immediate checkpoint
                job_data = await self.queue.get_job_state(job_id)
                if job_data:
                    job = Job(**job_data)
                    model_path = event.payload.get("model_path", "/workspace/model")
                    opt_path = event.payload.get("optimizer_path")
                    await self.checkpoint(job, model_path, opt_path)

            elif cmd == "restore":
                target_dir = event.payload.get("target_dir", "/workspace/restored")
                step = event.payload.get("step")
                await self.restore(job_id, target_dir, step)

        await self.queue.subscribe(["orchestration"], handle)

    # ?????? Lifecycle ??????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????

    async def start(self):
        """Start the Vault Agent. Verifies R2 connectivity then begins listening."""
        logger.info("Vault Agent starting...")

        if not self.r2.healthcheck():
            raise RuntimeError("R2 bucket is not accessible. Check Cloudflare credentials.")
        logger.info("R2 healthcheck OK")

        # GAP-13: Warn if R2 bucket has public access enabled
        if not self.r2.verify_bucket_private():
            logger.critical(
                "[Vault] R2 bucket has public access enabled! Checkpoints are exposed. "
                "Disable public access in Cloudflare dashboard."
            )

        # GAP-11: Apply S3 lifecycle rule so R2 auto-aborts dangling multipart uploads
        # after 24h — even if VaultLayer process is dead (belt-and-suspenders vs
        # the programmatic cleanup below). This is the primary defence; the
        # programmatic cleanup is the fallback.
        self.r2.ensure_lifecycle_policy()

        # Warn if any checkpoint objects are on Infrequent Access storage class
        # (would charge $9/M Class A ops instead of $0.36/M — cost catastrophe).
        self.r2.verify_standard_storage_class()

        # GAP-11: Programmatic abort of orphaned multipart uploads from previous
        # crashed sessions (catches uploads that predate the lifecycle rule).
        try:
            aborted = self.r2.cleanup_orphaned_multipart_uploads(max_age_hours=24)
            if aborted > 0:
                logger.info(f"[Vault] Aborted {aborted} orphaned multipart upload(s)")
        except Exception as _e:
            logger.warning(f"[Vault] Orphaned multipart cleanup failed (non-fatal): {_e}")

        # Run command listener
        await self.listen_for_commands()

    async def stop(self):
        logger.info("Vault Agent stopping.")
