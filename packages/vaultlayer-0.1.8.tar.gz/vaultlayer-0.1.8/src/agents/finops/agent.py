"""
VaultLayer — FinOps Agent
Generates savings reports and narratives for completed jobs.
All narratives are produced by deterministic templates — no LLM required.
"""
import logging
import os
from datetime import datetime, timezone
from typing import Dict, Optional

from shared.config import VaultLayerConfig
from shared.models import AgentEvent, EventType, Job, JobStatus, Provider, SavingsReport
from shared.queue import AgentQueue, make_event

logger = logging.getLogger(__name__)


class FinOpsAgent:
    """
    Agent 6 — The FinOps Agent.
    Generates per-job savings reports using deterministic templates.

    Publishes to:  vaultlayer:finops.report
    Listens to:    (passive — called directly by RunCommand)
    """

    AGENT_NAME = "finops_agent"

    def __init__(self, config: VaultLayerConfig, queue: AgentQueue):
        self.config = config
        self.queue = queue
        self._job_costs: dict[str, dict] = {}  # job_id -> {total, hours, providers}

    # GAP-26: Secondary cost constants
    R2_PUT_COST_PER_MILLION = 4.50   # Cloudflare R2 Class A ops
    R2_GET_COST_PER_MILLION = 0.36   # Cloudflare R2 Class B ops
    EC2_PUBLIC_IPV4_PER_HR  = 0.005  # AWS public IPv4

    def _estimate_secondary_costs(self, job: Job) -> Dict[str, float]:
        """Estimate R2 operation costs and EC2 IPv4 fees (GAP-26)."""
        duration_hrs = job.training_duration_hours or 0.0
        checkpoint_count = getattr(job, "interruption_count", 0) + max(1, int(duration_hrs * 12))
        r2_put_ops = checkpoint_count * 1000
        r2_get_ops = checkpoint_count * 100
        return {
            "r2_put_ops_usd": (r2_put_ops / 1_000_000) * self.R2_PUT_COST_PER_MILLION,
            "r2_get_ops_usd": (r2_get_ops / 1_000_000) * self.R2_GET_COST_PER_MILLION,
            "ec2_ipv4_usd": duration_hrs * self.EC2_PUBLIC_IPV4_PER_HR if job.provider == Provider.AWS else 0.0,
        }

    def track_spend(self, job_id: str, provider: str, hours: float, rate: float):
        """Accumulate spend for a running job."""
        if job_id not in self._job_costs:
            self._job_costs[job_id] = {"total": 0.0, "hours": 0.0, "providers": set()}
        self._job_costs[job_id]["total"] += hours * rate
        self._job_costs[job_id]["hours"] += hours
        self._job_costs[job_id]["providers"].add(provider)

    @staticmethod
    def _build_narrative(job: Job, duration_hours: float,
                         savings: float, savings_pct: float,
                         aws_equivalent: float) -> str:
        """Build a 3-sentence savings narrative from structured data. No LLM needed."""
        s1 = (
            f"'{job.name}' ran for {duration_hours:.1f}h on {job.provider.value} "
            f"({job.model_params_billion:.0f}B params, {job.training_mode or 'qlora'} mode)."
        )
        if job.interruption_count == 0:
            s2 = "Job completed with no spot interruptions."
        elif job.interruption_count == 1:
            s2 = (f"One spot interruption was recovered automatically "
                  f"({job.progress_lost_minutes:.1f} min of progress lost).")
        else:
            s2 = (f"{job.interruption_count} spot interruptions were recovered automatically "
                  f"({job.progress_lost_minutes:.1f} min of progress lost total).")
        s3 = (f"Total cost ${job.total_spend_usd:.2f} vs ${aws_equivalent:.2f} AWS On-Demand "
              f"— saved ${savings:.2f} ({savings_pct:.0f}%).")
        if job.interruption_count >= 3:
            rec = "Tip: pre-baked AMI would cut cold-start time on future migrations."
        elif savings_pct < 20:
            rec = "Tip: run during off-peak hours for deeper spot discounts."
        elif (job.training_mode or "") == "full" and (job.model_params_billion or 0) > 30:
            rec = "Tip: switch to QLoRA to reduce checkpoint size and cut migration overhead."
        else:
            rec = "No changes needed — job ran at optimal cost."
        return f"{s1} {s2} {s3} {rec}"

    async def generate_job_report(self, job: Job) -> SavingsReport:
        """Generate a savings report for a completed job using deterministic templates."""
        duration_hours = (
            (job.completed_at - job.started_at).total_seconds() / 3600
            if job.completed_at
            else 0.0
        )
        actual_spend = job.total_spend_usd
        aws_equivalent = job.aws_equivalent_usd if job.aws_equivalent_usd > 0 else actual_spend * 3.2
        savings = aws_equivalent - actual_spend
        savings_pct = (savings / aws_equivalent * 100) if aws_equivalent > 0 else 0.0
        narrative = self._build_narrative(job, duration_hours, savings, savings_pct, aws_equivalent)
        dashboard_url = f"{self.config.dashboard_base_url}/jobs/{job.job_id}"

        # GAP-26: Include secondary cost estimates in the report payload
        secondary_costs = self._estimate_secondary_costs(job)

        report = SavingsReport(
            job_id=job.job_id,
            job_name=job.name,
            narrative=narrative,
            duration_hours=duration_hours,
            actual_spend_usd=actual_spend,
            aws_equivalent_usd=aws_equivalent,
            savings_usd=savings,
            savings_pct=savings_pct,
            interruptions_recovered=job.interruption_count,
            progress_lost_minutes=job.progress_lost_minutes,
            dashboard_url=dashboard_url,
            providers_used=[job.provider],
        )
        # Attach secondary costs as a non-model attribute for CLI display
        report.__dict__["secondary_costs"] = secondary_costs

        await self.queue.publish(
            "finops",
            make_event(
                event_type=EventType.SAVINGS_REPORT,
                source_agent=self.AGENT_NAME,
                job_id=job.job_id,
                payload=report.model_dump(mode="json"),
                priority=5,
            ),
        )

        # Upsert daily summary tables (non-blocking; silently no-ops without Supabase)
        await self._upsert_daily_summary(job, report)

        return report

    def format_cli_summary(self, report: SavingsReport) -> str:
        """Format a savings report for CLI output."""
        secondary = getattr(report, "secondary_costs", {}) or {}
        secondary_total = sum(secondary.values())
        secondary_section = ""
        if secondary:
            secondary_section = (
                f"\n  Secondary costs (estimated):\n"
                f"    R2 PUT ops: ${secondary.get('r2_put_ops_usd', 0):.4f}\n"
                f"    R2 GET ops: ${secondary.get('r2_get_ops_usd', 0):.4f}\n"
                f"    EC2 IPv4:   ${secondary.get('ec2_ipv4_usd', 0):.4f}\n"
                f"    Total sec:  ${secondary_total:.4f}\n"
            )
        return (
            f"\n  Job complete: {report.job_name}\n"
            f"  Duration: {report.duration_hours:.1f} hours\n"
            f"\n  Actual cost:  ${report.actual_spend_usd:.2f}\n"
            f"  AWS equiv:    ${report.aws_equivalent_usd:.2f}\n"
            f"\n  Saved:        ${report.savings_usd:.2f} ({report.savings_pct:.0f}%)\n"
            f"{secondary_section}"
            f"\n  View report:  {report.dashboard_url}\n"
        )

    # ── Daily summary upsert ──────────────────────────────────────────────────

    def _get_supabase(self):
        """Return a Supabase client using the service role key, or None."""
        try:
            from supabase import create_client
            url = os.environ.get("SUPABASE_URL", "")
            key = (os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")
                   or os.environ.get("SUPABASE_KEY", ""))
            if not url or not key:
                return None
            return create_client(url, key)
        except Exception as e:
            logger.warning(f"[finops] Supabase client unavailable: {e}")
            return None

    async def _upsert_daily_summary(self, job: Job, report: "SavingsReport") -> None:
        """
        Upsert today's row in platform_daily_summary and provider_daily_stats.
        Called after generate_job_report() so report fields are ready.
        No-ops silently when Supabase is unavailable.
        """
        sb = self._get_supabase()
        if sb is None:
            return

        today = datetime.now(timezone.utc).date().isoformat()

        try:
            # ── platform_daily_summary ────────────────────────────────────────
            duration_hours = report.duration_hours or 0.0
            gross_savings = report.savings_usd or 0.0
            vl_revenue = gross_savings * 0.4
            net_savings = gross_savings * 0.6
            is_completed = job.status == JobStatus.COMPLETED
            is_failed = job.status == JobStatus.FAILED

            # Fetch existing row (if any) to merge counts
            existing_res = sb.table("platform_daily_summary").select("*").eq(
                "summary_date", today
            ).execute()
            existing = existing_res.data[0] if existing_res.data else {}

            def _inc(field: str, delta: int = 1) -> int:
                return int(existing.get(field) or 0) + delta

            def _inc_f(field: str, delta: float) -> float:
                return float(existing.get(field) or 0.0) + delta

            upsert_row = {
                "summary_date": today,
                "jobs_started": _inc("jobs_started"),
                "jobs_completed": _inc("jobs_completed") if is_completed else int(existing.get("jobs_completed") or 0),
                "jobs_failed": _inc("jobs_failed") if is_failed else int(existing.get("jobs_failed") or 0),
                "migrations_executed": _inc_f("migrations_executed", getattr(job, "migration_count", 0)),
                "gpu_hours": round(_inc_f("gpu_hours", duration_hours), 2),
                "data_processed_gb": round(_inc_f("data_processed_gb", job.dataset_size_gb or 0.0), 2),
                "gross_savings_usd": round(_inc_f("gross_savings_usd", gross_savings), 2),
                "vl_revenue_usd": round(_inc_f("vl_revenue_usd", vl_revenue), 2),
                "net_savings_usd": round(_inc_f("net_savings_usd", net_savings), 2),
                "spot_interruptions": _inc("spot_interruptions", job.interruption_count or 0),
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }

            sb.table("platform_daily_summary").upsert(
                upsert_row, on_conflict="summary_date"
            ).execute()

            # ── provider_daily_stats ──────────────────────────────────────────
            provider_str = job.provider.value if hasattr(job.provider, "value") else str(job.provider)

            prov_res = sb.table("provider_daily_stats").select("*").eq(
                "summary_date", today
            ).eq("provider", provider_str).execute()
            prov_existing = prov_res.data[0] if prov_res.data else {}

            def _pinc(field: str, delta: int = 1) -> int:
                return int(prov_existing.get(field) or 0) + delta

            def _pinc_f(field: str, delta: float) -> float:
                return float(prov_existing.get(field) or 0.0) + delta

            prov_row = {
                "summary_date": today,
                "provider": provider_str,
                "jobs_started": _pinc("jobs_started"),
                "jobs_completed": _pinc("jobs_completed") if is_completed else int(prov_existing.get("jobs_completed") or 0),
                "gpu_hours": round(_pinc_f("gpu_hours", duration_hours), 2),
                "gross_savings_usd": round(_pinc_f("gross_savings_usd", gross_savings), 2),
                "vl_revenue_usd": round(_pinc_f("vl_revenue_usd", vl_revenue), 2),
                "interruptions": _pinc("interruptions", job.interruption_count or 0),
            }

            sb.table("provider_daily_stats").upsert(
                prov_row, on_conflict="summary_date,provider"
            ).execute()

            logger.info(f"[finops] Upserted daily summary for {today} / {provider_str}")

        except Exception as e:
            logger.warning(f"[finops] _upsert_daily_summary failed (non-fatal): {e}")

    async def start(self):
        logger.info("FinOps Agent starting")

    async def stop(self):
        logger.info("FinOps Agent stopping.")
