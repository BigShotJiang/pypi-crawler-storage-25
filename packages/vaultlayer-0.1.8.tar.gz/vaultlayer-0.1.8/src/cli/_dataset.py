"""
VaultLayer CLI — dataset preparation helpers.

Extracted from run.py to keep RunCommand slim.

Public API:
  async mirror_cloud_data(uri, yes, config=None) -> Optional[str]
      Dispatches to the correct mirror function based on URI scheme:
        s3://bucket/prefix  → AWS S3      → R2
        gs://bucket/prefix  → GCP GCS     → R2
        az://container/pfx  → Azure Blob  → R2
      Returns dataset_id on success, None on failure.

  async mirror_s3_data(s3_uri, yes, config)  ← kept for backward compat
"""
from __future__ import annotations

import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)


# ── URI → dataset_id derivation ───────────────────────────────────────────────

def _derive_dataset_id(uri: str) -> str:
    """
    Derive a stable, filesystem-safe dataset_id from any cloud URI.

    s3://my-bucket/data/train  →  my-bucket-data-train
    gs://my-bucket/embeddings  →  my-bucket-embeddings
    az://container/raw         →  container-raw
    """
    # Strip scheme prefix
    for prefix in ("s3://", "gs://", "az://"):
        if uri.startswith(prefix):
            uri = uri[len(prefix):]
            break
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", uri).strip("-")
    return safe[:64]  # R2 key length limit


# ── Dispatcher ────────────────────────────────────────────────────────────────

async def mirror_cloud_data(uri: str, yes: bool = False, config=None) -> Optional[str]:
    """
    Mirror a cloud dataset to R2 before training starts.

    Routes based on URI scheme:
      s3://  →  _sync_from_s3  (boto3 / AWS)
      gs://  →  _sync_from_gcs (google-cloud-storage)
      az://  →  _sync_from_azure (azure-storage-blob)

    Returns dataset_id on success, None on failure.
    """
    if uri.startswith("s3://"):
        return await mirror_s3_data(uri, yes=yes, config=config)
    if uri.startswith("gs://"):
        return await _mirror_gcs_data(uri, yes=yes, config=config)
    if uri.startswith("az://"):
        return await _mirror_azure_data(uri, yes=yes, config=config)
    logger.warning(f"[dataset] Unknown URI scheme: {uri}")
    return None


# ── S3 → R2 ──────────────────────────────────────────────────────────────────

async def mirror_s3_data(s3_uri: str, yes: bool = False, config=None) -> Optional[str]:
    """
    Mirror an S3 dataset to R2 before training starts.
    Kept as the primary public name — also called by RunCommand._maybe_mirror_s3_data.
    """
    from cli.sync import _parse_s3_uri

    bucket, prefix = _parse_s3_uri(s3_uri)
    safe_bucket = re.sub(r"[^a-zA-Z0-9_-]", "-", bucket).strip("-")
    safe_prefix = re.sub(r"[^a-zA-Z0-9_-]", "-", prefix).strip("-")
    dataset_id  = f"{safe_bucket}-{safe_prefix}" if safe_prefix else safe_bucket
    dataset_id  = dataset_id[:64]

    print(f"\n  [--data] Checking R2 for existing mirror of {s3_uri} ...")

    try:
        from shared.config import load_config
        from agents.vault.r2 import R2Client
        from agents.namespace.ingestion import DatasetIngester
        from cli.sync import _sync_from_s3

        cfg = config or load_config()
        r2  = _make_r2_client(cfg)

        existing = await DatasetIngester.load_manifest(r2, dataset_id)
        if existing:
            print(f"  [--data] Dataset '{dataset_id}' already in R2 — skipping mirror.")
            return dataset_id

        print(f"  [--data] Mirroring {s3_uri} to R2 as '{dataset_id}' ...")
        print("  [--data] This is a one-time operation. Training will start after.")
        await _sync_from_s3(
            s3_uri=s3_uri,
            dataset_id=dataset_id,
            name=None,
            shard_size_mb=512,
            config=cfg,
            r2=r2,
            yes=yes,
        )
        return dataset_id
    except SystemExit:
        print("\n  Training aborted (S3 mirror declined).")
        return None
    except Exception as e:
        logger.warning(f"S3 mirror failed: {e}. Training will start without R2 dataset.")
        return None


# ── GCS → R2 ─────────────────────────────────────────────────────────────────

async def _mirror_gcs_data(gcs_uri: str, yes: bool = False, config=None) -> Optional[str]:
    """Mirror a GCS bucket/prefix to R2. Uses google-cloud-storage."""
    from cli.sync import _sync_from_gcs

    dataset_id = _derive_dataset_id(gcs_uri)
    print(f"\n  [--data] Checking R2 for existing mirror of {gcs_uri} ...")

    try:
        from shared.config import load_config
        from agents.namespace.ingestion import DatasetIngester

        cfg = config or load_config()
        r2  = _make_r2_client(cfg)

        existing = await DatasetIngester.load_manifest(r2, dataset_id)
        if existing:
            print(f"  [--data] Dataset '{dataset_id}' already in R2 — skipping mirror.")
            return dataset_id

        print(f"  [--data] Mirroring {gcs_uri} to R2 as '{dataset_id}' ...")
        print("  [--data] This is a one-time operation. Training will start after.")
        await _sync_from_gcs(
            gcs_uri=gcs_uri,
            dataset_id=dataset_id,
            name=None,
            config=cfg,
            r2=r2,
            yes=yes,
        )
        return dataset_id
    except SystemExit:
        print("\n  Training aborted (GCS mirror declined).")
        return None
    except Exception as e:
        logger.warning(f"GCS mirror failed: {e}. Training will start without R2 dataset.")
        return None


# ── Azure → R2 ───────────────────────────────────────────────────────────────

async def _mirror_azure_data(azure_uri: str, yes: bool = False, config=None) -> Optional[str]:
    """Mirror an Azure Blob container/prefix to R2. Uses azure-storage-blob."""
    from cli.sync import _sync_from_azure

    dataset_id = _derive_dataset_id(azure_uri)
    print(f"\n  [--data] Checking R2 for existing mirror of {azure_uri} ...")

    try:
        from shared.config import load_config
        from agents.namespace.ingestion import DatasetIngester

        cfg = config or load_config()
        r2  = _make_r2_client(cfg)

        existing = await DatasetIngester.load_manifest(r2, dataset_id)
        if existing:
            print(f"  [--data] Dataset '{dataset_id}' already in R2 — skipping mirror.")
            return dataset_id

        print(f"  [--data] Mirroring {azure_uri} to R2 as '{dataset_id}' ...")
        print("  [--data] This is a one-time operation. Training will start after.")
        await _sync_from_azure(
            azure_uri=azure_uri,
            dataset_id=dataset_id,
            name=None,
            config=cfg,
            r2=r2,
            yes=yes,
        )
        return dataset_id
    except SystemExit:
        print("\n  Training aborted (Azure mirror declined).")
        return None
    except Exception as e:
        logger.warning(f"Azure mirror failed: {e}. Training will start without R2 dataset.")
        return None


# ── Shared helper ─────────────────────────────────────────────────────────────

def _make_r2_client(config):
    from agents.vault.r2 import R2Client
    return R2Client(
        endpoint=config.cloudflare.r2_endpoint,
        access_key_id=config.cloudflare.r2_access_key_id,
        secret_access_key=config.cloudflare.r2_secret_access_key,
        bucket=config.cloudflare.r2_bucket,
    )
