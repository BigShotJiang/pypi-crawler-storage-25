"""
vaultlayer connect — Provider and storage connection commands.

Extracted from main.py to keep the CLI entry point manageable.
"""
from pathlib import Path

import click


# ── Shared helpers ────────────────────────────────────────────────────────────

def _append_to_config_env(config_env: Path, key: str, value: str) -> None:
    """Append or update a key=value line in ~/.vaultlayer/config.env."""
    existing_lines: list[str] = []
    if config_env.exists():
        existing_lines = config_env.read_text().splitlines()

    new_line = f"{key}={value}"
    new_lines = [l for l in existing_lines if not l.startswith(f"{key}=")]
    new_lines.append(new_line)

    config_env.write_text("\n".join(new_lines) + "\n")
    config_env.chmod(0o600)


_BYOC_PROVIDERS = {
    "lambda-labs":   "Lambda Labs",
    "coreweave":     "CoreWeave",
    "runpod":        "RunPod",
    "vast-ai":       "Vast.ai",
    "voltage-park":  "Voltage Park",
    "crusoe":        "Crusoe Energy",
    "hyperstack":    "Hyperstack",
}


def _validate_provider_key(provider_slug: str, api_key: str) -> bool:
    """
    Best-effort validation of a provider API key by making a lightweight API call.
    Returns True if valid, False if definitely invalid.
    On network error, returns True (assume valid, let the job fail clearly later).
    """
    import httpx
    try:
        if provider_slug == "lambda-labs":
            r = httpx.get(
                "https://cloud.lambdalabs.com/api/v1/instances",
                auth=(api_key, ""),
                timeout=8,
            )
            return r.status_code != 401
        elif provider_slug == "runpod":
            r = httpx.get(
                f"https://rest.runpod.io/v2/user",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=8,
            )
            return r.status_code != 401
        # For providers without a simple ping endpoint, assume valid
        return True
    except httpx.HTTPError:
        return True  # network error — don't block


def _connect_provider(slug: str, api_key: "Optional[str]") -> None:
    """Shared logic: prompt for API key, validate, write to config.env."""
    cfg_dir = Path.home() / ".vaultlayer"
    cfg_dir.mkdir(mode=0o700, exist_ok=True)
    config_env = cfg_dir / "config.env"

    name = _BYOC_PROVIDERS.get(slug, slug)
    if not api_key:
        api_key = click.prompt(f"  {name} API key", hide_input=True)
    api_key = api_key.strip()
    if not api_key:
        click.echo("  API key cannot be empty.")
        raise SystemExit(1)

    valid = _validate_provider_key(slug, api_key)
    if not valid:
        click.echo(f"  Invalid API key for {name}. Check your credentials.")
        raise SystemExit(1)

    env_key = {
        "lambda-labs":  "LAMBDA_LABS_API_KEY",
        "runpod":       "RUNPOD_API_KEY",
        "vast-ai":      "VAST_AI_API_KEY",
        "voltage-park": "VOLTAGE_PARK_API_KEY",
        "crusoe":       "CRUSOE_API_KEY",
        "hyperstack":   "HYPERSTACK_API_KEY",
    }.get(slug, slug.upper().replace("-", "_") + "_API_KEY")

    _append_to_config_env(config_env, env_key, api_key)
    click.echo(f"  {name} connected.")


def _validate_sts_ec2_permissions(creds: dict, region: str) -> None:
    """
    Dry-run EC2 + IMDSv2 permission checks using short-lived STS credentials.

    Checks performed:
      1. ec2:DescribeInstances  — confirms basic EC2 read access
      2. ec2:DescribeLaunchTemplates — confirms launch template permissions
      3. iam:SimulatePrincipalPolicy for ec2:RunInstances — dry-run spot request
         (uses the DryRun=True flag so no real resource is created)

    Prints a per-check pass/fail table and warns on any missing permission.
    Failures are non-fatal: credentials are still saved but the user is warned
    that the job may fail at provisioning time.
    """
    import boto3
    from botocore.exceptions import ClientError

    session = boto3.Session(
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"],
        region_name=region,
    )
    ec2 = session.client("ec2")

    checks = []

    # Check 1: DescribeInstances
    try:
        ec2.describe_instances(MaxResults=5)
        checks.append(("ec2:DescribeInstances", True, ""))
    except ClientError as e:
        checks.append(("ec2:DescribeInstances", False, e.response["Error"]["Code"]))
    except Exception as e:
        checks.append(("ec2:DescribeInstances", False, str(e)[:60]))

    # Check 2: DescribeLaunchTemplates
    try:
        ec2.describe_launch_templates(MaxResults=5)
        checks.append(("ec2:DescribeLaunchTemplates", True, ""))
    except ClientError as e:
        checks.append(("ec2:DescribeLaunchTemplates", False, e.response["Error"]["Code"]))
    except Exception as e:
        checks.append(("ec2:DescribeLaunchTemplates", False, str(e)[:60]))

    # Check 3: RunInstances dry-run (ec2:RunInstances permission probe)
    try:
        ec2.run_instances(
            ImageId="ami-00000000",  # placeholder — DryRun rejects before validation
            MinCount=1,
            MaxCount=1,
            InstanceType="p4de.24xlarge",
            DryRun=True,
        )
        checks.append(("ec2:RunInstances (dry-run)", True, ""))
    except ClientError as e:
        code = e.response["Error"]["Code"]
        # DryRunOperation means the permission check passed (request would have succeeded)
        if code == "DryRunOperation":
            checks.append(("ec2:RunInstances (dry-run)", True, "permission OK"))
        elif code == "UnauthorizedOperation":
            checks.append(("ec2:RunInstances (dry-run)", False, "UnauthorizedOperation — add ec2:RunInstances to role"))
        else:
            # Any other ClientError (e.g. InvalidAMIID) means the call reached EC2 → permission OK
            checks.append(("ec2:RunInstances (dry-run)", True, f"reached EC2 ({code})"))
    except Exception as e:
        checks.append(("ec2:RunInstances (dry-run)", False, str(e)[:60]))

    G, R, Y = "\033[97m", "\033[0m", "\033[97m"
    all_passed = all(ok for _, ok, _ in checks)
    click.echo("")
    click.echo("  Permission dry-run results:")
    for name, ok, note in checks:
        mark = f"{G}✓{R}" if ok else f"{Y}✗{R}"
        suffix = f"  ({note})" if note else ""
        click.echo(f"    {mark}  {name}{suffix}")

    if all_passed:
        click.echo(f"  {G}All permission checks passed.{R}")
    else:
        failed = [name for name, ok, _ in checks if not ok]
        click.echo(f"\n  {Y}Warning: {len(failed)} permission check(s) failed.{R}")
        click.echo("  The node may fail at provisioning time. Fix the role policy and re-run:")
        click.echo("    vaultlayer connect aws --role-arn <ARN>")
    click.echo("")


# ── Storage validation helpers ────────────────────────────────────────────────

def _validate_s3_credentials(access_key: str, secret_key: str, region: str,
                              endpoint: str, bucket: str = "") -> None:
    """Credential + optional write-access check. Warns on failure but doesn't block."""
    try:
        import boto3
        kwargs: dict = {
            "aws_access_key_id": access_key,
            "aws_secret_access_key": secret_key,
            "region_name": region,
        }
        if endpoint:
            kwargs["endpoint_url"] = endpoint
        sts = boto3.client("sts", **kwargs)
        sts.get_caller_identity()
        click.echo("  Credentials valid (STS check passed).")

        # Write-access test: put + delete a tiny object
        if bucket:
            s3 = boto3.client("s3", **kwargs)
            _test_key = ".vaultlayer-write-test"
            s3.put_object(Bucket=bucket, Key=_test_key, Body=b"vl-write-test")
            s3.delete_object(Bucket=bucket, Key=_test_key)
            click.echo(f"  Write access to bucket '{bucket}' verified.")
    except ImportError:
        pass  # boto3 not installed — skip validation
    except Exception as e:
        click.echo(f"  Warning: could not validate S3 credentials: {e}")
        click.echo("  Credentials saved but may not work at job time.")


def _validate_gcs_credentials(creds_path: str, project: str, bucket: str = "") -> None:
    """GCS credential + optional write-access check. Warns on failure but doesn't block."""
    try:
        from google.cloud import storage as gcs_storage
        from google.oauth2 import service_account
        credentials = service_account.Credentials.from_service_account_file(creds_path)
        client = gcs_storage.Client(project=project or None, credentials=credentials)
        click.echo("  GCS credentials loaded successfully.")

        if bucket:
            bkt = client.bucket(bucket)
            _test_blob = bkt.blob(".vaultlayer-write-test")
            _test_blob.upload_from_string("vl-write-test")
            _test_blob.delete()
            click.echo(f"  Write access to bucket '{bucket}' verified.")
    except ImportError:
        pass  # google-cloud-storage not installed — skip validation
    except Exception as e:
        click.echo(f"  Warning: could not validate GCS credentials: {e}")
        click.echo("  Credentials saved but may not work at job time.")


def _validate_azure_credentials(conn_str: str, account_name: str, account_key: str,
                                 container: str = "") -> None:
    """Azure Blob credential + optional write-access check. Warns on failure but doesn't block."""
    try:
        from azure.storage.blob import BlobServiceClient
        if conn_str:
            client = BlobServiceClient.from_connection_string(conn_str.strip())
        elif account_name and account_key:
            client = BlobServiceClient(
                account_url=f"https://{account_name.strip()}.blob.core.windows.net",
                credential=account_key.strip(),
            )
        else:
            click.echo("  Warning: no Azure credentials provided for validation.")
            return
        # Quick connectivity check
        client.get_account_information()
        click.echo("  Azure Blob credentials valid.")

        if container:
            container_client = client.get_container_client(container.strip())
            _test_blob = container_client.get_blob_client(".vaultlayer-write-test")
            _test_blob.upload_blob(b"vl-write-test", overwrite=True)
            _test_blob.delete_blob()
            click.echo(f"  Write access to container '{container}' verified.")
    except ImportError:
        pass  # azure-storage-blob not installed — skip validation
    except Exception as e:
        click.echo(f"  Warning: could not validate Azure credentials: {e}")
        click.echo("  Credentials saved but may not work at job time.")


# ── Connect group ─────────────────────────────────────────────────────────────

@click.group()
def connect():
    """Connect compute providers or data storage to VaultLayer.

    \b
    Examples:
        vaultlayer connect              # interactive provider picker
        vaultlayer connect lambda-labs  # connect Lambda Labs directly
        vaultlayer connect storage      # connect your S3/GCS/Azure storage
    """
    pass


@connect.command(name="lambda-labs")
@click.option("--key", default=None, help="Lambda Labs API key")
def connect_lambda_labs(key):
    """Connect your Lambda Labs account."""
    _connect_provider("lambda-labs", key)


@connect.command(name="coreweave")
@click.option("--key", default=None, help="CoreWeave API key")
@click.option("--namespace", default=None, help="CoreWeave namespace")
def connect_coreweave(key, namespace):
    """Connect your CoreWeave account."""
    cfg_dir = Path.home() / ".vaultlayer"
    cfg_dir.mkdir(mode=0o700, exist_ok=True)
    config_env = cfg_dir / "config.env"

    if not key:
        key = click.prompt("  CoreWeave API key", hide_input=True)
    if not namespace:
        namespace = click.prompt("  CoreWeave namespace")

    key = key.strip()
    namespace = namespace.strip()
    if not key or not namespace:
        click.echo("  Both API key and namespace are required.")
        raise SystemExit(1)

    _append_to_config_env(config_env, "COREWEAVE_API_KEY", key)
    _append_to_config_env(config_env, "COREWEAVE_NAMESPACE", namespace)
    click.echo("  CoreWeave connected.")


@connect.command(name="runpod")
@click.option("--key", default=None, help="RunPod API key")
def connect_runpod(key):
    """Connect your RunPod account."""
    _connect_provider("runpod", key)


@connect.command(name="vast-ai")
@click.option("--key", default=None, help="Vast.ai API key")
def connect_vast_ai(key):
    """Connect your Vast.ai account."""
    _connect_provider("vast-ai", key)


@connect.command(name="voltage-park")
@click.option("--key", default=None, help="Voltage Park API key")
def connect_voltage_park(key):
    """Connect your Voltage Park account."""
    _connect_provider("voltage-park", key)


@connect.command(name="crusoe")
@click.option("--key", default=None, help="Crusoe Energy API key")
def connect_crusoe(key):
    """Connect your Crusoe Energy account."""
    _connect_provider("crusoe", key)


@connect.command(name="hyperstack")
@click.option("--key", default=None, help="Hyperstack API key")
def connect_hyperstack(key):
    """Connect your Hyperstack account."""
    _connect_provider("hyperstack", key)


@connect.command(name="aws")
@click.option("--role-arn", default=None, help="IAM Role ARN to assume (arn:aws:iam::...)")
@click.option("--external-id", default=None, help="External ID for secure cross-account access")
@click.option("--access-key", default=None, help="AWS Access Key ID (if not using STS role)")
@click.option("--secret-key", default=None, help="AWS Secret Access Key")
@click.option("--region", default=None, help="Default AWS region (e.g. us-east-1)")
def connect_aws(role_arn, external_id, access_key, secret_key, region):
    """Connect your AWS account for BYOC GPU provisioning.

    \b
    Two modes:
      STS Role (recommended): VaultLayer assumes a role in your account.
          Required permissions: ec2:RunInstances, ec2:DescribeInstances,
          ec2:TerminateInstances, ec2:CreateLaunchTemplate,
          ec2:DeleteLaunchTemplate, iam:PassRole

      Static keys: Provide AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY directly.
          Not recommended for production — use STS role instead.
    """
    import httpx

    cfg_dir = Path.home() / ".vaultlayer"
    cfg_dir.mkdir(mode=0o700, exist_ok=True)
    config_env = cfg_dir / "config.env"

    click.echo("")
    click.echo("  Connect AWS for BYOC GPU provisioning")
    click.echo("")

    if not role_arn and not access_key:
        mode = click.prompt(
            "  Authentication mode",
            type=click.Choice(["role", "keys"]),
            default="role",
        )
    elif role_arn:
        mode = "role"
    else:
        mode = "keys"

    if mode == "role":
        if not role_arn:
            role_arn = click.prompt("  IAM Role ARN (arn:aws:iam::<account-id>:role/<name>)")
        if not external_id:
            external_id = click.prompt("  External ID (leave blank to skip)", default="")
        if not region:
            region = click.prompt("  Default region", default="us-east-1")

        role_arn = role_arn.strip()
        external_id = external_id.strip()

        if not role_arn.startswith("arn:aws:iam::"):
            click.echo("  Invalid Role ARN. Format: arn:aws:iam::<account-id>:role/<name>")
            raise SystemExit(1)

        # Validate by attempting AssumeRole then dry-run EC2 + launch template checks
        click.echo("  Validating role...")
        try:
            import boto3
            from botocore.exceptions import ClientError
            sts_client = boto3.client("sts", region_name=region)
            assume_kwargs = {
                "RoleArn": role_arn,
                "RoleSessionName": "vaultlayer-connect-validate",
                "DurationSeconds": 900,
            }
            if external_id:
                assume_kwargs["ExternalId"] = external_id
            creds = sts_client.assume_role(**assume_kwargs)["Credentials"]
            click.echo("  Role assumed successfully.")

            # Dry-run: verify EC2 + launch template permissions with assumed credentials
            _validate_sts_ec2_permissions(creds, region or "us-east-1")
        except ImportError:
            click.echo("  boto3 not installed — skipping role validation.")
            click.echo("  Install with: pip install boto3")
        except Exception as e:
            click.echo(f"  Warning: could not validate role: {e}")
            click.echo("  Credentials saved but may not work at job time.")

        _append_to_config_env(config_env, "VL_STS_ROLE_ARN", role_arn)
        if external_id:
            _append_to_config_env(config_env, "VL_STS_EXTERNAL_ID", external_id)
        _append_to_config_env(config_env, "AWS_REGION", region or "us-east-1")

    else:  # mode == "keys"
        if not access_key:
            access_key = click.prompt("  AWS Access Key ID")
        if not secret_key:
            secret_key = click.prompt("  AWS Secret Access Key", hide_input=True)
        if not region:
            region = click.prompt("  Default region", default="us-east-1")

        access_key = access_key.strip()
        secret_key = secret_key.strip()

        # Validate via GetCallerIdentity
        click.echo("  Validating credentials...")
        try:
            import boto3
            sts_client = boto3.client(
                "sts",
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key,
                region_name=region,
            )
            sts_client.get_caller_identity()
            click.echo("  Credentials validated.")
        except ImportError:
            click.echo("  boto3 not installed — skipping credential validation.")
        except Exception as e:
            click.echo(f"  Warning: could not validate credentials: {e}")
            click.echo("  Credentials saved but may not work at job time.")

        _append_to_config_env(config_env, "AWS_ACCESS_KEY_ID", access_key)
        _append_to_config_env(config_env, "AWS_SECRET_ACCESS_KEY", secret_key)
        _append_to_config_env(config_env, "AWS_REGION", region or "us-east-1")

    click.echo("  AWS connected.")
    click.echo("  Run: vaultlayer run python train.py")


@connect.command(name="gcp")
@click.option("--service-account-json", default=None,
              help="Path to GCP service account JSON file")
@click.option("--project-id", default=None, help="GCP project ID")
@click.option("--region", default=None, help="Default GCP region (e.g. us-central1)")
def connect_gcp(service_account_json, project_id, region):
    """Connect your GCP account for BYOC GPU provisioning.

    \b
    Required permissions on the service account:
        compute.instances.create, compute.instances.delete,
        compute.instances.get, compute.instances.list,
        compute.machineTypes.list, iam.serviceAccounts.actAs

    Create a service account key at:
        https://console.cloud.google.com/iam-admin/serviceaccounts
    """
    cfg_dir = Path.home() / ".vaultlayer"
    cfg_dir.mkdir(mode=0o700, exist_ok=True)
    config_env = cfg_dir / "config.env"

    click.echo("")
    click.echo("  Connect GCP for BYOC GPU provisioning")
    click.echo("")

    if not service_account_json:
        service_account_json = click.prompt(
            "  Path to service account JSON file",
            type=click.Path(exists=True, file_okay=True, dir_okay=False),
        )
    if not project_id:
        project_id = click.prompt("  GCP project ID")
    if not region:
        region = click.prompt("  Default region", default="us-central1")

    service_account_json = str(service_account_json).strip()
    project_id = project_id.strip()
    region = region.strip()

    # ── Step 1: Validate JSON format ────────────────────────────────────────────
    click.echo("  Validating credentials...")
    sa_data = {}
    try:
        import json as _json
        with open(service_account_json) as f:
            sa_data = _json.load(f)
        if sa_data.get("type") != "service_account":
            click.echo("  ✗ File does not appear to be a service account JSON.")
            raise SystemExit(1)
        click.echo(f"  Service account: {sa_data.get('client_email', 'unknown')}")
    except (OSError, ValueError) as e:
        click.echo(f"  Warning: could not read service account JSON: {e}")
        click.echo("  Credentials saved but may not work at job time.")

    # ── Step 2: Dry-run API permission checks ────────────────────────────────────
    _REQUIRED_PERMISSIONS = [
        ("compute.instances.list",   "instances().list"),
        ("compute.instances.create", "instances().insert"),
        ("compute.instances.delete", "instances().delete"),
    ]
    if sa_data.get("type") == "service_account":
        click.echo("  Checking required GCP IAM permissions...")
        try:
            from google.oauth2 import service_account as _sa
            from googleapiclient import discovery as _disc
            import googleapiclient.errors as _gerrors

            _creds = _sa.Credentials.from_service_account_file(
                service_account_json,
                scopes=["https://www.googleapis.com/auth/cloud-platform"],
            )
            _crm = _disc.build("cloudresourcemanager", "v1", credentials=_creds)

            # testIamPermissions returns the subset of requested permissions that
            # the service account actually has — anything missing → warning.
            _requested = [p for p, _ in _REQUIRED_PERMISSIONS]
            _res = _crm.projects().testIamPermissions(
                resource=project_id,
                body={"permissions": _requested},
            ).execute()
            _granted = set(_res.get("permissions", []))

            all_ok = True
            for perm, label in _REQUIRED_PERMISSIONS:
                ok = perm in _granted
                mark = "✓" if ok else "✗"
                click.echo(f"    {mark}  {perm}")
                if not ok:
                    all_ok = False

            if not all_ok:
                click.echo("")
                click.echo("  Warning: some permissions missing — provisioning may fail.")
                click.echo("  Grant the 'Compute Instance Admin (v1)' role to fix this.")
            else:
                click.echo("  All required IAM permissions confirmed.")

        except ImportError:
            click.echo("  (skipping IAM check — install google-api-python-client google-auth to enable)")
        except Exception as _iam_err:
            click.echo(f"  Warning: IAM permission check failed: {_iam_err}")
            click.echo("  Credentials saved, but verify permissions manually.")

    _append_to_config_env(config_env, "GCP_SERVICE_ACCOUNT_JSON", service_account_json)
    _append_to_config_env(config_env, "GCP_PROJECT_ID", project_id)
    _append_to_config_env(config_env, "GCP_REGION", region)

    click.echo("  GCP connected.")
    click.echo("  Run: vaultlayer run python train.py")


@connect.command(name="azure")
@click.option("--subscription-id", default=None, help="Azure subscription ID")
@click.option("--tenant-id", default=None, help="Azure tenant (directory) ID")
@click.option("--client-id", default=None, help="Service principal client ID")
@click.option("--client-secret", default=None, help="Service principal client secret")
@click.option("--resource-group", default=None,
              help="Resource group for VaultLayer instances (created if absent)")
@click.option("--location", default=None, help="Azure location (e.g. eastus)")
def connect_azure(subscription_id, tenant_id, client_id, client_secret, resource_group, location):
    """Connect your Azure account for BYOC GPU provisioning.

    \b
    Create a service principal with:
        az ad sp create-for-rbac --name vaultlayer --role Contributor \\
            --scopes /subscriptions/<id>/resourceGroups/<rg>

    Required roles: Contributor (or Virtual Machine Contributor + Network Contributor).
    """
    cfg_dir = Path.home() / ".vaultlayer"
    cfg_dir.mkdir(mode=0o700, exist_ok=True)
    config_env = cfg_dir / "config.env"

    click.echo("")
    click.echo("  Connect Azure for BYOC GPU provisioning")
    click.echo("")

    if not subscription_id:
        subscription_id = click.prompt("  Azure subscription ID")
    if not tenant_id:
        tenant_id = click.prompt("  Tenant (directory) ID")
    if not client_id:
        client_id = click.prompt("  Service principal client ID")
    if not client_secret:
        client_secret = click.prompt("  Service principal client secret", hide_input=True)
    if not resource_group:
        resource_group = click.prompt("  Resource group", default="vaultlayer-rg")
    if not location:
        location = click.prompt("  Location", default="eastus")

    subscription_id = subscription_id.strip()
    tenant_id = tenant_id.strip()
    client_id = client_id.strip()
    client_secret = client_secret.strip()

    # ── Validate credentials + permission dry-run ────────────────────────────────
    click.echo("  Validating Azure credentials...")
    _AZ_REQUIRED_ACTIONS = [
        "Microsoft.Compute/virtualMachines/read",
        "Microsoft.Compute/virtualMachines/write",
        "Microsoft.Compute/virtualMachines/delete",
        "Microsoft.Network/networkInterfaces/write",
        "Microsoft.Network/publicIPAddresses/write",
        "Microsoft.Network/virtualNetworks/write",
    ]
    try:
        from azure.identity import ClientSecretCredential as _AzCred
        from azure.mgmt.authorization import AuthorizationManagementClient as _AuthClient
        _az_cred = _AzCred(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret,
        )
        _auth_client = _AuthClient(_az_cred, subscription_id)
        # Resolve the service principal's object ID for permission check
        _scope = f"/subscriptions/{subscription_id}/resourceGroups/{resource_group}"
        _role_assignments = list(
            _auth_client.role_assignments.list_for_scope(_scope, filter=f"principalId eq '{client_id}'")
        )
        # Get role definition IDs and check for key actions
        _granted_actions: set[str] = set()
        for _ra in _role_assignments:
            try:
                _rd = _auth_client.role_definitions.get_by_id(_ra.role_definition_id)
                for _perm in _rd.permissions:
                    _granted_actions.update(_perm.actions or [])
            except Exception:
                continue
        # Wildcard match (Contributor has */*)
        def _az_perm_ok(action: str) -> bool:
            if "*" in _granted_actions or "*/write" in _granted_actions:
                return True
            ns, _ = action.split("/", 1)
            return action in _granted_actions or f"{ns}/*" in _granted_actions

        all_ok = True
        for _action in _AZ_REQUIRED_ACTIONS:
            ok = _az_perm_ok(_action)
            mark = "✓" if ok else "✗"
            click.echo(f"    {mark}  {_action}")
            if not ok:
                all_ok = False

        if not all_ok:
            click.echo("")
            click.echo("  Warning: some permissions missing — assign the 'Contributor' role.")
        else:
            click.echo("  All required Azure permissions confirmed.")

    except ImportError:
        click.echo("  (skipping permission check — install azure-mgmt-authorization to enable)")
    except Exception as _az_err:
        click.echo(f"  Warning: permission check failed: {_az_err}")
        click.echo("  Credentials saved, but verify role assignments manually.")

    _append_to_config_env(config_env, "AZURE_SUBSCRIPTION_ID", subscription_id)
    _append_to_config_env(config_env, "AZURE_TENANT_ID", tenant_id)
    _append_to_config_env(config_env, "AZURE_CLIENT_ID", client_id)
    _append_to_config_env(config_env, "AZURE_CLIENT_SECRET", client_secret)
    _append_to_config_env(config_env, "AZURE_RESOURCE_GROUP", resource_group)
    _append_to_config_env(config_env, "AZURE_LOCATION", location)

    click.echo("  Azure connected.")
    click.echo("  Run: vaultlayer run python train.py")


@connect.command(name="storage")
@click.option("--provider", type=click.Choice(["s3", "gcs", "azure"]), default=None,
              help="Storage provider (s3, gcs, azure). Prompted if omitted.")
def connect_storage(provider):
    """Connect your data storage so migrated nodes can access training data.

    \b
    Your training data stays where it is — VaultLayer forwards credentials
    to provisioned nodes. Checkpoint storage always uses VaultLayer R2.

    Supported providers:
        s3      AWS S3 or any S3-compatible storage
        gcs     Google Cloud Storage
        azure   Azure Blob Storage
    """
    cfg_dir = Path.home() / ".vaultlayer"
    cfg_dir.mkdir(mode=0o700, exist_ok=True)
    config_env = cfg_dir / "config.env"

    if not provider:
        provider = click.prompt(
            "  Storage provider",
            type=click.Choice(["s3", "gcs", "azure"]),
        )

    if provider == "s3":
        click.echo("")
        click.echo("  Connect S3 (or S3-compatible) storage")
        click.echo("  These credentials will be forwarded to provisioned GPU nodes.")
        click.echo("")
        access_key = click.prompt("  AWS Access Key ID")
        secret_key = click.prompt("  AWS Secret Access Key", hide_input=True)
        region = click.prompt("  Region", default="us-east-1")
        endpoint = click.prompt("  Endpoint URL (leave blank for AWS S3)", default="")
        bucket = click.prompt("  Bucket name (for write validation)", default="")

        access_key = access_key.strip()
        secret_key = secret_key.strip()

        # Validate: attempt STS GetCallerIdentity + optional write test
        _validate_s3_credentials(access_key, secret_key, region, endpoint, bucket)

        _append_to_config_env(config_env, "VL_S3_ACCESS_KEY_ID", access_key)
        _append_to_config_env(config_env, "VL_S3_SECRET_ACCESS_KEY", secret_key)
        _append_to_config_env(config_env, "VL_S3_REGION", region)
        if endpoint:
            _append_to_config_env(config_env, "VL_S3_ENDPOINT", endpoint)
        if bucket:
            _append_to_config_env(config_env, "VL_S3_BUCKET", bucket)

        click.echo("  S3 storage connected.")
        click.echo("  Run: vaultlayer run python train.py")

    elif provider == "gcs":
        click.echo("")
        click.echo("  Connect Google Cloud Storage")
        click.echo("")
        creds_path = click.prompt(
            "  Path to service account JSON",
            type=click.Path(exists=True, file_okay=True, dir_okay=False),
        )
        project = click.prompt("  GCP project ID", default="")
        bucket = click.prompt("  Bucket name (for write validation)", default="")

        _validate_gcs_credentials(creds_path, project, bucket)

        _append_to_config_env(config_env, "VL_GCS_CREDENTIALS_JSON", creds_path)
        if project:
            _append_to_config_env(config_env, "VL_GCS_PROJECT", project)

        click.echo("  GCS storage connected.")

    elif provider == "azure":
        click.echo("")
        click.echo("  Connect Azure Blob Storage")
        click.echo("")
        conn_str = click.prompt("  Connection string (or leave blank to use account key)", default="")
        if not conn_str:
            account_name = click.prompt("  Storage account name")
            account_key = click.prompt("  Storage account key", hide_input=True)
        else:
            account_name = ""
            account_key = ""
        container = click.prompt("  Container name (for write validation)", default="")

        _validate_azure_credentials(conn_str, account_name, account_key, container)

        if not conn_str:
            _append_to_config_env(config_env, "VL_AZURE_ACCOUNT_NAME", account_name.strip())
            _append_to_config_env(config_env, "VL_AZURE_ACCOUNT_KEY", account_key.strip())
        else:
            _append_to_config_env(config_env, "VL_AZURE_CONNECTION_STRING", conn_str.strip())
        if container:
            _append_to_config_env(config_env, "VL_AZURE_CONTAINER", container.strip())

        click.echo("  Azure Blob Storage connected.")
