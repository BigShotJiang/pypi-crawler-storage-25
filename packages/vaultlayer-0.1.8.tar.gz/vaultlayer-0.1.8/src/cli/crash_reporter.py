"""
VaultLayer CLI — crash reporter utility.

Captures exceptions, scrubs secrets, saves crash reports locally.
IMPORTANT: This module must NOT import any vaultlayer modules — it runs
before the rest of the package is loaded (e.g. during import errors).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# ── Secret scrubbing patterns (compiled at module level for performance) ──────

_PATTERNS: list[tuple[re.Pattern, str]] = [
    # AWS access keys: AKIA... (20 chars)
    (re.compile(r'\bAKIA[0-9A-Z]{16}\b'), '[AWS_KEY_REDACTED]'),
    # AWS secret keys: often after "aws_secret" or standalone 40-char base64
    (re.compile(r'(?i)(aws.?secret.?access.?key\s*[=:]\s*)[^\s\'"&]+'), r'\1[AWS_SECRET_REDACTED]'),
    # Anthropic keys: sk-ant-...
    (re.compile(r'\bsk-ant-[A-Za-z0-9_\-]{20,}\b'), '[ANTHROPIC_KEY_REDACTED]'),
    # VaultLayer tokens
    (re.compile(r'\bvl_(?:live|test)_[A-Za-z0-9_\-]{8,}\b'), '[VL_TOKEN_REDACTED]'),
    # Generic key=VALUE patterns (KEY=, key:, token=, secret=, password=, etc.)
    (re.compile(
        r'(?i)\b((?:api[_\-]?key|secret[_\-]?key|access[_\-]?key|auth[_\-]?token|'
        r'password|passwd|token|secret|credential)[s]?)\s*[=:]\s*[^\s\'"&,\]}{]+',
    ), r'\1=[REDACTED]'),
    # S3 signed URL params (X-Amz-Signature, X-Amz-Credential, etc.)
    (re.compile(r'X-Amz-[A-Za-z\-]+=[^&\s]+'), 'X-Amz-[REDACTED]'),
    # Email addresses
    (re.compile(r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b'), '[EMAIL_REDACTED]'),
    # Public IPv4 addresses (skip loopback/private ranges in replacement)
    (re.compile(
        r'\b(?!(?:127\.|10\.|172\.(?:1[6-9]|2\d|3[01])\.|192\.168\.))'
        r'(?:\d{1,3}\.){3}\d{1,3}\b'
    ), '[IP_REDACTED]'),
]


def scrub(text: str) -> str:
    """Remove secrets and PII from text. Returns sanitised copy."""
    if not text:
        return text
    for pattern, replacement in _PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def error_fingerprint(exc_type: str, message: str, tb_last_frame: str) -> str:
    """
    Stable sha256 fingerprint for deduplication.
    Prefix: "fp_"
    """
    raw = f"{exc_type}::{scrub(message)}::{tb_last_frame}"
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return f"fp_{digest[:16]}"


def _crash_reports_dir() -> Path:
    d = Path.home() / ".vaultlayer" / "crash_reports"
    d.mkdir(parents=True, exist_ok=True)
    return d


def save_crash_report(
    exc: BaseException,
    command: list[str],
    job_id: Optional[str] = None,
    gpu_type: Optional[str] = None,
    provider: Optional[str] = None,
) -> str:
    """
    Capture and persist a crash report.
    Returns report_id (e.g. "cr_abc12345").
    """
    import secrets as _secrets

    exc_type = type(exc).__name__
    raw_message = str(exc)
    raw_tb = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))

    message = scrub(raw_message)
    tb_text = scrub(raw_tb)

    # Extract last frame for fingerprinting
    frames = re.findall(r'File "([^"]+)", line \d+', raw_tb)
    last_frame = frames[-1] if frames else ""

    fingerprint = error_fingerprint(exc_type, raw_message, last_frame)

    report_id = f"cr_{_secrets.token_hex(4)}"
    report = {
        "id": report_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "error_type": exc_type,
        "error_message": message,
        "traceback": tb_text,
        "command": [scrub(c) for c in command],
        "job_id": job_id,
        "gpu_type": gpu_type,
        "provider": provider,
        "fingerprint": fingerprint,
        "submitted": False,
    }

    report_path = _crash_reports_dir() / f"{report_id}.json"
    report_path.write_text(json.dumps(report, indent=2))
    return report_id


def load_crash_report(report_id: str) -> Optional[dict]:
    """Load a crash report from disk. Returns None if not found."""
    path = _crash_reports_dir() / f"{report_id}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def mark_submitted(report_id: str) -> None:
    """Mark a crash report as submitted (sets submitted=True in JSON)."""
    path = _crash_reports_dir() / f"{report_id}.json"
    if not path.exists():
        return
    try:
        data = json.loads(path.read_text())
        data["submitted"] = True
        path.write_text(json.dumps(data, indent=2))
    except (json.JSONDecodeError, OSError):
        pass
