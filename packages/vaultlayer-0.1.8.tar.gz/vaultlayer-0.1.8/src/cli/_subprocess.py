"""
VaultLayer CLI — subprocess management for training jobs.

Extracted from run.py to keep RunCommand slim.

Public API:
  async run_subprocess(run_cmd, job, vault, watchdog, orchestration) -> int
      Spawns the user command, streams output, sends heartbeats, runs spinner.
      Returns the process exit code.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cli.run import RunCommand

logger = logging.getLogger(__name__)


async def run_subprocess(
    run_cmd: "RunCommand",
    job,
    vault,
    watchdog,
    orchestration,
) -> int:
    """
    Spawn the user's training command, stream its output, and run the
    watchdog heartbeat + live spinner concurrently.

    Handles:
      - Zero-code checkpoint resume (sitecustomize hook injection)
      - Supabase + R2 log buffering
      - Live progress spinner on stderr
      - Periodic checkpointing every VAULTLAYER_CHECKPOINT_INTERVAL seconds
      - Telemetry step-rate gauging
    """
    # Lazy imports — only needed when actually running a subprocess
    from shared.telemetry import make_telemetry, MetricCategory
    from shared.config import load_config

    # ── Resolve telemetry lazily (already created in execute, re-used here) ──
    tel = getattr(run_cmd, "_tel", None)

    # ── Resume hook injection ─────────────────────────────────────────────────
    ckpt_env = os.environ.copy()
    ckpt_env["PYTHONUNBUFFERED"] = "1"
    resume_path = os.environ.get("VAULTLAYER_RESUME_CHECKPOINT", "")
    if resume_path:
        ckpt_env["CHECKPOINT_DIR"] = resume_path
        ckpt_env["RESUME_FROM_CHECKPOINT"] = resume_path
        logger.info(f"Resuming from checkpoint: {resume_path}")
        import tempfile, textwrap as _tw
        _hook_dir = tempfile.mkdtemp(prefix="vaultlayer_hook_")
        import vaultlayer as _vl_pkg
        _vl_pkg_dir = str(Path(_vl_pkg.__file__).parent.parent)
        _sitecustomize = _tw.dedent(f"""\
            # VaultLayer auto-generated sitecustomize — do not edit
            import os, sys
            _vl_dir = {_vl_pkg_dir!r}
            if _vl_dir not in sys.path:
                sys.path.insert(0, _vl_dir)
            os.environ.setdefault('VAULTLAYER_RESUME_CHECKPOINT', {resume_path!r})
            try:
                import vaultlayer._resume_hook
            except ImportError:
                pass
        """)
        Path(_hook_dir, "sitecustomize.py").write_text(_sitecustomize)
        existing_pypath = ckpt_env.get("PYTHONPATH", "")
        ckpt_env["PYTHONPATH"] = (
            f"{_hook_dir}:{existing_pypath}" if existing_pypath else _hook_dir
        )
        logger.info(f"[VaultLayer] Resume hook injected via {_hook_dir}/sitecustomize.py")

    proc = await asyncio.create_subprocess_exec(
        *run_cmd.command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        env=ckpt_env,
    )
    os.environ["VAULTLAYER_TRAINING_PID"] = str(proc.pid)
    logger.info(f"[RunCommand] Training process PID={proc.pid} registered for graceful shutdown")

    # ── Log buffering ─────────────────────────────────────────────────────────
    from collections import deque as _deque
    from shared.job_logger import log_lines as _log_lines_to_supabase
    _log_buffer: _deque = _deque(maxlen=1000)
    _supabase_batch: list[str] = []
    _SUPABASE_BATCH_SIZE = 50

    async def stream_output():
        nonlocal _supabase_batch
        async for raw_line in proc.stdout:
            if _is_tty:
                sys.stderr.write(f"\r{' ' * 80}\r")
                sys.stderr.flush()
            sys.stdout.buffer.write(raw_line)
            sys.stdout.buffer.flush()
            try:
                line = raw_line.decode("utf-8", errors="replace")
                _log_buffer.append(line)
                _supabase_batch.append(line)
                if len(_supabase_batch) >= _SUPABASE_BATCH_SIZE:
                    await _log_lines_to_supabase(
                        job.job_id, job.user_id, _supabase_batch, source="training"
                    )
                    _supabase_batch = []
            except Exception:
                pass

    async def _flush_log_buffer_to_r2():
        nonlocal _supabase_batch
        if _supabase_batch:
            await _log_lines_to_supabase(
                job.job_id, job.user_id, _supabase_batch, source="training"
            )
            _supabase_batch = []
        try:
            tail_text = "".join(_log_buffer)
            _body = tail_text.encode("utf-8")
            await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: vault.r2._s3.put_object(
                    Bucket=vault.r2.bucket,
                    Key=f"logs/{job.job_id}/tail.txt",
                    Body=_body,
                    ContentType="text/plain",
                )
            )
        except Exception as _le:
            logger.debug(f"Log buffer flush failed (non-fatal): {_le}")

    # ── Spinner ───────────────────────────────────────────────────────────────
    _spinner_chars = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    _spinner_idx = 0
    _is_tty = sys.stderr.isatty()

    class _SpinnerAwareHandler(logging.StreamHandler):
        def emit(self, record):
            if _is_tty:
                sys.stderr.write(f"\r{' ' * 72}\r")
            super().emit(record)

    _spin_handler = _SpinnerAwareHandler(sys.stderr)
    _spin_handler.setFormatter(logging.Formatter("%(levelname)s %(name)s %(message)s"))
    _spin_handler.setLevel(logging.WARNING)
    _root_logger = logging.getLogger()
    _orig_handlers = _root_logger.handlers[:]
    _root_logger.handlers = [_spin_handler]

    async def _spin():
        nonlocal _spinner_idx
        while proc.returncode is None:
            elapsed = (datetime.utcnow() - job.started_at).total_seconds()
            mins, secs = divmod(int(elapsed), 60)
            hrs, mins  = divmod(mins, 60)
            if hrs:
                elapsed_str = f"{hrs}h {mins:02d}m {secs:02d}s"
            elif mins:
                elapsed_str = f"{mins}m {secs:02d}s"
            else:
                elapsed_str = f"{secs}s"
            icon = _spinner_chars[_spinner_idx % len(_spinner_chars)]
            _spinner_idx += 1
            line = f"  {icon}  {elapsed_str} elapsed  |  watchdog active  |  {run_cmd.gpu_type}"
            if _is_tty:
                sys.stderr.write(f"\r\033[0m{line}\033[0m          ")
                sys.stderr.flush()
            await asyncio.sleep(0.5)
        if _is_tty:
            sys.stderr.write(f"\r{' ' * 72}\r")
            sys.stderr.flush()
        _root_logger.handlers = _orig_handlers

    # ── Heartbeat + periodic checkpoint ──────────────────────────────────────
    _HEARTBEAT_TICK = 30

    async def heartbeat():
        _last_checkpoint_at: float = 0.0
        while proc.returncode is None:
            watchdog.record_heartbeat(job.job_id)
            checkpoint_interval = int(os.environ.get("VAULTLAYER_CHECKPOINT_INTERVAL", "300"))
            elapsed_since_start = (datetime.utcnow() - job.started_at).total_seconds()

            if (elapsed_since_start - _last_checkpoint_at) >= checkpoint_interval:
                _last_checkpoint_at = elapsed_since_start
                if run_cmd._training_proc and run_cmd._training_proc.poll() is None:
                    import signal as _sig
                    try:
                        run_cmd._training_proc.send_signal(_sig.SIGTERM)
                        logger.info("SIGTERM sent to training process before checkpoint")
                        await asyncio.sleep(3)
                    except Exception as _se:
                        logger.warning(f"SIGTERM failed (non-fatal): {_se}")
                model_path = os.environ.get("VAULTLAYER_MODEL_PATH", "/workspace/model")
                if Path(model_path).exists():
                    try:
                        await vault.checkpoint(job, model_path)
                        logger.debug(f"Periodic checkpoint at step {job.current_step}")
                        await _flush_log_buffer_to_r2()
                    except Exception as _ce:
                        logger.warning(f"Periodic checkpoint failed: {_ce}")
                if job.current_step > 0 and tel:
                    elapsed_min = elapsed_since_start / 60
                    step_rate = job.current_step / elapsed_min if elapsed_min > 0 else 0
                    tel.gauge("job.step_rate", step_rate, unit="steps/min",
                              tags={"gpu": run_cmd.gpu_type}, job_id=job.job_id)

            await asyncio.sleep(_HEARTBEAT_TICK)

    # ── Agent tasks ───────────────────────────────────────────────────────────
    orch_task      = asyncio.create_task(orchestration.start())
    watch_task     = asyncio.create_task(watchdog.start())
    broker_task    = asyncio.create_task(run_cmd._broker.start())
    pricing_task   = asyncio.create_task(run_cmd._pricing.start())
    namespace_task = asyncio.create_task(run_cmd._namespace.start())
    await asyncio.gather(stream_output(), heartbeat(), _spin())
    for task in (orch_task, watch_task, broker_task, pricing_task, namespace_task):
        task.cancel()
    await asyncio.gather(
        orch_task, watch_task, broker_task, pricing_task, namespace_task,
        return_exceptions=True,
    )
    await proc.wait()
    return proc.returncode or 0
