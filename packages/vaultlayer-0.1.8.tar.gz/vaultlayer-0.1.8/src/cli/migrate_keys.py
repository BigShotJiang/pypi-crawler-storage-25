"""
VaultLayer -- RBAC Migration Script
One-time migration: moves existing R2 checkpoints from
  checkpoints/{job_id}/...
to
  checkpoints/{user_id}/{job_id}/...

Run ONCE after deploying RBAC. Safe to re-run (skips already-migrated keys).

Usage:
    VAULTLAYER_USER_ID=alice python src/cli/migrate_keys.py --dry-run
    VAULTLAYER_USER_ID=alice python src/cli/migrate_keys.py --confirm
"""
import os
import sys
import click
from pathlib import Path


@click.command()
@click.option("--user", default=None, envvar="VAULTLAYER_USER_ID",
              help="User ID to migrate checkpoints to (required)")
@click.option("--dry-run", is_flag=True, default=False,
              help="Preview changes without moving anything")
@click.option("--confirm", is_flag=True, default=False,
              help="Actually perform the migration")
def migrate_keys(user, dry_run, confirm):
    """
    Migrate existing R2 checkpoints to RBAC-namespaced paths.
    Moves checkpoints/{job_id}/... -> checkpoints/{user_id}/{job_id}/...
    """
    if not user:
        click.echo("  Error: --user or VAULTLAYER_USER_ID is required")
        click.echo("  Example: VAULTLAYER_USER_ID=alice python migrate_keys.py --dry-run")
        sys.exit(1)
    if not dry_run and not confirm:
        click.echo("  Use --dry-run to preview, or --confirm to execute.")
        sys.exit(1)

    try:
        from dotenv import load_dotenv
        if Path(".env").exists(): load_dotenv(".env")
        from shared.config import load_config
        config = load_config()
        import boto3
        s3 = boto3.client(
            "s3",
            endpoint_url=config.cloudflare.r2_endpoint,
            aws_access_key_id=config.cloudflare.r2_access_key_id,
            aws_secret_access_key=config.cloudflare.r2_secret_access_key,
        )
        bucket = config.cloudflare.r2_bucket
    except Exception as e:
        click.echo(f"  Failed to initialise R2 client: {e}")
        sys.exit(1)

    # List all objects under checkpoints/ (legacy flat namespace)
    click.echo(f"  Scanning R2 bucket for legacy checkpoint paths...")
    paginator = s3.get_paginator("list_objects_v2")
    to_migrate = []
    already_migrated = 0

    for page in paginator.paginate(Bucket=bucket, Prefix="checkpoints/"):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            parts = key.split("/")
            # Already migrated: checkpoints/{user_id}/{job_id}/...
            # Not migrated:     checkpoints/{job_id}/...
            # Heuristic: if part[1] looks like a UUID (job_id) it needs migration
            # If part[1] is a short word like "alice" it is already namespaced
            if len(parts) >= 3 and parts[1] == user:
                already_migrated += 1
                continue
            # Legacy key: parts[1] is job_id, parts[2] is step-XXXXXXXX
            if len(parts) >= 3 and parts[2].startswith("step-"):
                new_key = f"checkpoints/{user}/{parts[1]}/{'/'.join(parts[2:])}"
                to_migrate.append((key, new_key))

    click.echo(f"  Already migrated: {already_migrated}")
    click.echo(f"  To migrate:       {len(to_migrate)}")
    click.echo("")

    if not to_migrate:
        click.echo("  Nothing to migrate. All checkpoints are already namespaced.")
        return

    if dry_run:
        click.echo("  [DRY RUN] Would migrate:")
        for old, new in to_migrate[:10]:
            click.echo(f"    {old}")
            click.echo(f"    -> {new}")
        if len(to_migrate) > 10:
            click.echo(f"    ... and {len(to_migrate)-10} more")
        return

    # Execute migration: copy to new key, delete old
    migrated = 0
    errors = 0
    for old_key, new_key in to_migrate:
        try:
            # Copy object to new namespaced key
            s3.copy_object(
                Bucket=bucket,
                CopySource={"Bucket": bucket, "Key": old_key},
                Key=new_key,
                ServerSideEncryption="AES256",
            )
            # Delete old key
            s3.delete_object(Bucket=bucket, Key=old_key)
            migrated += 1
            click.echo(f"  [{migrated}/{len(to_migrate)}] {old_key} -> {new_key}")
        except Exception as e:
            click.echo(f"  [ERROR] {old_key}: {e}")
            errors += 1

    click.echo("")
    click.echo(f"  Migration complete: {migrated} moved, {errors} errors")
    if errors == 0:
        click.echo(f"  All checkpoints now under checkpoints/{user}/...")


if __name__ == "__main__":
    migrate_keys()