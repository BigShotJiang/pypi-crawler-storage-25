"""
vaultlayer smoke-history — View production smoke test results.

Queries job_runs (run_type='smoke_test') from Supabase and displays
a tabular summary per provider with pass/fail status, cost, and timing.

Usage:
    vaultlayer smoke-history                   # last 30 days, all providers
    vaultlayer smoke-history --days 7          # last 7 days
    vaultlayer smoke-history --provider aws    # filter by provider
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone, timedelta
from pathlib import Path

import click

logger = logging.getLogger(__name__)


@click.command(hidden=True)
@click.option("--days", default=30, help="Look back N days (default: 30)")
@click.option("--provider", default=None, help="Filter by provider name")
def smoke_history(days: int, provider: str | None):
    """Show production smoke test results from the database (operator-only).

    \b
    Reads SUPABASE_URL + SUPABASE_SERVICE_KEY from .env (repo root)
    or ~/.vaultlayer/config.env. This is an operator command — not
    exposed to end users.

    Queries job_runs WHERE run_type='smoke_test' and displays:
      - Per-provider pass/fail counts
      - Billing seconds and estimated cost
      - Instance IDs for audit trail
    """
    from cli._preflight import require_admin_token
    require_admin_token()
    # Load config BEFORE importing db.py — env vars must be set before
    # db.py reads them at module scope (SUPABASE_URL, SUPABASE_SERVICE_KEY)
    env_file = Path.home() / ".vaultlayer" / "config.env"
    if env_file.exists():
        try:
            from dotenv import load_dotenv
            load_dotenv(env_file, override=False)
        except ImportError:
            pass
    # Also load .env from repo root (where SUPABASE_URL/KEY typically live)
    repo_env = Path(".env")
    if repo_env.exists():
        try:
            from dotenv import load_dotenv
            load_dotenv(repo_env, override=False)
        except ImportError:
            pass

    # Force re-read of env vars (db.py may have been imported with empty values)
    _su = os.environ.get("SUPABASE_URL", "")
    _sk = os.environ.get("SUPABASE_SERVICE_KEY", "")
    if not _su or not _sk:
        click.echo("  Error: SUPABASE_URL and SUPABASE_SERVICE_KEY not configured.")
        click.echo("  Add them to ~/.vaultlayer/config.env or .env:")
        click.echo("    SUPABASE_URL=https://your-project.supabase.co")
        click.echo("    SUPABASE_SERVICE_KEY=eyJ...")
        raise SystemExit(1)

    try:
        from supabase import create_client
        db = create_client(_su, _sk)
    except Exception as e:
        click.echo(f"  Error: Could not connect to Supabase: {e}")
        raise SystemExit(1)

    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

    # Query job_runs for smoke tests
    try:
        query = (
            db.table("job_runs")
            .select("provider, gpu_type, instance_id, status, billing_seconds, "
                    "estimated_cost_usd, provider_billed_usd, provisioned_at, "
                    "terminated_at, created_at, metadata")
            .eq("run_type", "smoke_test")
            .gte("created_at", cutoff)
            .order("created_at", desc=True)
        )
        if provider:
            query = query.eq("provider", provider)
        result = query.execute()
        rows = result.data or []
    except Exception as e:
        click.echo(f"  Error querying database: {e}")
        raise SystemExit(1)

    if not rows:
        click.echo(f"\n  No smoke test records found in the last {days} days.")
        click.echo("  Run prod smoke tests with: VL_PROD_TEST=1 pytest tests/test_provider_smoke_prod.py -v")
        return

    # Display results
    click.echo(f"\n  Smoke Test Results (last {days} days)")
    click.echo(f"  {'='*80}")
    click.echo(f"  {'Provider':<15} {'GPU':<18} {'Status':<12} {'Cost':>8} {'Seconds':>8} {'Instance ID':<28} {'Date'}")
    click.echo(f"  {'-'*15} {'-'*18} {'-'*12} {'-'*8} {'-'*8} {'-'*28} {'-'*10}")

    total_cost = 0.0
    for r in rows:
        status = r.get("status", "?")
        status_icon = "PASS" if status == "terminated" else "FAIL" if status == "failed" else status
        cost = float(r.get("estimated_cost_usd") or 0)
        total_cost += cost
        billing_s = float(r.get("billing_seconds") or 0)
        date_str = (r.get("created_at") or "")[:10]
        click.echo(
            f"  {r.get('provider', '?'):<15} "
            f"{r.get('gpu_type', '?'):<18} "
            f"{status_icon:<12} "
            f"${cost:>7.4f} "
            f"{billing_s:>7.0f}s "
            f"{r.get('instance_id', '?'):<28} "
            f"{date_str}"
        )

    click.echo(f"  {'-'*80}")
    click.echo(f"  Total: {len(rows)} runs | ${total_cost:.4f} estimated cost")

    # Summary by provider
    from collections import defaultdict
    by_prov: dict[str, dict] = defaultdict(lambda: {"pass": 0, "fail": 0, "cost": 0.0})
    for r in rows:
        prov = r.get("provider", "?")
        if r.get("status") == "terminated":
            by_prov[prov]["pass"] += 1
        else:
            by_prov[prov]["fail"] += 1
        by_prov[prov]["cost"] += float(r.get("estimated_cost_usd") or 0)

    click.echo(f"\n  Provider Summary:")
    for prov, stats in sorted(by_prov.items()):
        total = stats["pass"] + stats["fail"]
        rate = (stats["pass"] / total * 100) if total > 0 else 0
        click.echo(
            f"    {prov:<15}  {stats['pass']}/{total} passed ({rate:.0f}%)  "
            f"${stats['cost']:.4f} total cost"
        )


