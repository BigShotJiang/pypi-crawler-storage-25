"""
VaultLayer -- Slack/Discord Notification Support
Sends job lifecycle alerts to a webhook URL.

Usage:
    export VAULTLAYER_NOTIFY_WEBHOOK=https://hooks.slack.com/services/...
    vaultlayer run --notify python train.py

Supports: Slack incoming webhooks, Discord webhooks (same format).
"""
import os
import json
import logging
from datetime import datetime
from typing import Optional

import aiohttp

logger = logging.getLogger(__name__)


class JobNotifier:
    """
    Fire-and-forget async webhook notifier.
    Works with Slack, Discord, and any incoming webhook (JSON POST).
    """

    WEBHOOK_ENV = "VAULTLAYER_NOTIFY_WEBHOOK"

    def __init__(self, webhook_url: Optional[str] = None):
        self.webhook_url = webhook_url or os.getenv(self.WEBHOOK_ENV)
        self._enabled = bool(self.webhook_url)
        if self._enabled:
            logger.info(f"Notifications enabled -> {self.webhook_url[:40]}...")

    @property
    def enabled(self) -> bool:
        return self._enabled

    async def job_started(self, job_name: str, gpu: str, provider: str,
                          estimated_savings: float = 0.0) -> None:
        await self._send({
            "text": f":rocket: *VaultLayer job started*",
            "attachments": [{
                "color": "#36a64f",
                "fields": [
                    {"title": "Job", "value": job_name, "short": True},
                    {"title": "GPU", "value": gpu, "short": True},
                    {"title": "Provider", "value": provider, "short": True},
                    {"title": "Est. savings vs AWS OD", "value": f"${estimated_savings:,.0f}", "short": True},
                ],
                "footer": "VaultLayer | 99.9% SLA",
                "ts": int(datetime.utcnow().timestamp()),
            }]
        })

    async def interruption_detected(self, job_name: str, provider: str,
                                    reason: str, step: int) -> None:
        await self._send({
            "text": f":warning: *Interruption detected -- checkpointing*",
            "attachments": [{
                "color": "#ffa500",
                "fields": [
                    {"title": "Job",      "value": job_name, "short": True},
                    {"title": "Provider", "value": provider, "short": True},
                    {"title": "Reason",   "value": reason,   "short": True},
                    {"title": "Step",     "value": str(step),"short": True},
                ],
                "footer": "Emergency checkpoint triggered automatically",
            }]
        })

    async def migration_complete(self, job_name: str,
                                  from_provider: str, to_provider: str,
                                  downtime_seconds: float) -> None:
        await self._send({
            "text": f":arrows_counterclockwise: *Job migrated successfully*",
            "attachments": [{
                "color": "#36a64f",
                "fields": [
                    {"title": "Job",      "value": job_name,    "short": True},
                    {"title": "From",     "value": from_provider, "short": True},
                    {"title": "To",       "value": to_provider, "short": True},
                    {"title": "Downtime", "value": f"{downtime_seconds:.0f}s", "short": True},
                ],
                "footer": "Training resumed -- zero progress lost",
            }]
        })

    async def job_complete(self, job_name: str, duration_h: float,
                           savings_usd: float, savings_pct: float,
                           interruptions: int = 0) -> None:
        emoji = ":white_check_mark:"
        await self._send({
            "text": f"{emoji} *Job complete*",
            "attachments": [{
                "color": "#36a64f",
                "fields": [
                    {"title": "Job",           "value": job_name,                  "short": True},
                    {"title": "Duration",      "value": f"{duration_h:.1f}h",      "short": True},
                    {"title": "Saved",         "value": f"${savings_usd:,.0f} ({savings_pct:.0f}%)", "short": True},
                    {"title": "Interruptions", "value": f"{interruptions} recovered","short": True},
                ],
                "footer": "VaultLayer | vaultlayer.pages.dev",
                "ts": int(datetime.utcnow().timestamp()),
            }]
        })

    async def job_failed(self, job_name: str, error: str) -> None:
        await self._send({
            "text": f":x: *Job failed* -- {job_name}",
            "attachments": [{
                "color": "#ff0000",
                "fields": [{"title": "Error", "value": error[:200], "short": False}],
            }]
        })

    async def _send(self, payload: dict) -> None:
        """POST to webhook. Never raises -- notifications are best-effort."""
        if not self._enabled:
            return
        try:
            async with aiohttp.ClientSession() as session:
                await session.post(
                    self.webhook_url,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=5),
                )
        except Exception as e:
            logger.debug(f"Notification failed (non-fatal): {e}")