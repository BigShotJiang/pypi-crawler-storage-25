"""
VaultLayer CLI -- Provider-specific log fetching and instance status checks.

Extracted from _remote.py. Each provider has its own API for fetching logs
and checking instance liveness. This module isolates that provider-specific
logic from the generic log orchestration code.
"""
from __future__ import annotations

import logging
import sys
import time
from typing import TYPE_CHECKING, Set

if TYPE_CHECKING:
    from shared.models import Provider

logger = logging.getLogger(__name__)

# Completion markers shared with the log orchestrator
_COMPLETION_MARKERS = {"[VaultLayer] Training finished (exit 0)"}


def fetch_logs_from_provider(
    provider: "Provider",
    instance_id: str,
    api_key: str,
    skip_lines: int,
) -> tuple[int, bool]:
    """
    Fetch logs from a provider-specific API.

    Returns (total_lines_seen, completed) where completed is True if a
    completion marker was found in the log output.

    Only works while the instance is alive. Falls back gracefully if the
    provider API is unavailable.
    """
    import httpx
    from shared.models import Provider as _P

    if not api_key:
        return skip_lines, False

    completed = False
    try:
        if provider == _P.VAST_AI:
            return _fetch_logs_vast_ai(instance_id, api_key, skip_lines)
    except Exception:
        pass
    return skip_lines, completed


def _fetch_logs_vast_ai(
    instance_id: str,
    api_key: str,
    skip_lines: int,
) -> tuple[int, bool]:
    """Fetch logs from Vast.ai instance via their API."""
    import httpx

    completed = False
    resp = httpx.put(
        f"https://console.vast.ai/api/v0/instances/request_logs/{instance_id}",
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        json={"tail": "500"},
        timeout=10,
    )
    if resp.status_code != 200:
        return skip_lines, False
    result_url = resp.json().get("result_url", "")
    if not result_url:
        return skip_lines, False
    time.sleep(2)
    log_resp = httpx.get(result_url, timeout=10)
    if log_resp.status_code != 200:
        return skip_lines, False
    lines = log_resp.text.splitlines()
    for line in lines[skip_lines:]:
        print(f"  {line}")
        if any(m in line for m in _COMPLETION_MARKERS):
            completed = True
    sys.stdout.flush()
    return len(lines), completed


def check_instance_alive(provider: "Provider", instance_id: str, api_key: str) -> bool:
    """
    Check instance status using provider-specific API.
    Returns False if the instance has been terminated/destroyed.
    Returns True if alive or if we cannot determine status.
    """
    from shared.models import Provider as _P
    import httpx

    if not api_key:
        return True

    try:
        if provider == _P.VAST_AI:
            return _check_alive_vast_ai(instance_id, api_key)
        if provider == _P.RUNPOD:
            return _check_alive_runpod(instance_id, api_key)
    except Exception:
        pass
    return True


def _check_alive_vast_ai(instance_id: str, api_key: str) -> bool:
    """Check if a Vast.ai instance is still running."""
    import httpx

    resp = httpx.get(
        f"https://console.vast.ai/api/v0/instances/{instance_id}/",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=10,
    )
    if resp.status_code == 404:
        return False
    if resp.status_code == 200:
        data = resp.json()
        # Vast.ai returns {"instances": null} when instance is gone
        if data.get("instances") is None:
            return False
        status = data.get("actual_status", data.get("status_msg", ""))
        if status in ("exited", "stopped", "destroyed"):
            return False
    return True


def _check_alive_runpod(instance_id: str, api_key: str) -> bool:
    """Check if a RunPod instance is still running."""
    import httpx

    resp = httpx.get(
        f"https://rest.runpod.io/v1/pods/{instance_id}",
        headers={"Authorization": f"Bearer {api_key}", "Accept-Encoding": "identity"},
        timeout=10,
    )
    if resp.status_code == 404:
        return False
    return True
