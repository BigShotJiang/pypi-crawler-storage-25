"""
VaultLayer CLI -- vaultlayer estimate
Shows cost comparison across all providers before running a job.
All price data comes from config/vaultlayer_data.json -- edit that file to update prices.

Usage:
    vaultlayer estimate --gpu H100 --hours 24
    vaultlayer estimate --gpu A100 --hours 168 --gpus 8
"""
import click

# Module-level data tables loaded from config/vaultlayer_data.json at import time.
# Tests import PROVIDER_PRICES and GPU_ALIASES directly from this module.
try:
    from shared.data_loader import get_provider_prices as _get_pp, get_gpu_aliases as _get_ga
    _raw_pp = _get_pp()
    # Filter out non-dict values (e.g. _notes keys)
    PROVIDER_PRICES = {k: v for k, v in _raw_pp.items() if isinstance(v, dict)}
    _raw_ga = _get_ga()
    GPU_ALIASES = {k: v for k, v in _raw_ga.items() if not k.startswith("_")}
except Exception:
    PROVIDER_PRICES = {}
    GPU_ALIASES = {
        "H100": "H100_80GB_SXM",
        "h100": "H100_80GB_SXM",
        "A100": "A100_80GB_SXM",
        "a100": "A100_80GB_SXM",
        "A10G": "A10G",
        "a10g": "A10G",
        "RTX4090": "RTX4090",
    }

# Ensure lowercase aliases are present (normalize for CLI convenience)
for _k in list(GPU_ALIASES.keys()):
    if _k.lower() not in GPU_ALIASES:
        GPU_ALIASES[_k.lower()] = GPU_ALIASES[_k]

VL_MARGIN = 1.15   # VaultLayer adds 15% margin over cheapest spot price


@click.command()
@click.option("--gpu",   default="H100",  show_default=True, help="GPU: H100, A100, A100_40, A10G")
@click.option("--hours", default=24.0, type=float, show_default=True, help="Job duration in hours")
@click.option("--gpus",  default=1,    type=int,   show_default=True, help="Number of GPUs")
def estimate(gpu, hours, gpus):
    """Estimate job cost across all providers. Prices from config/vaultlayer_data.json."""
    try:
        from shared.data_loader import get_provider_prices, get_gpu_aliases, get_meta
        _raw_prices = get_provider_prices()
        _local_prices = {k: v for k, v in _raw_prices.items() if isinstance(v, dict)}
        _local_aliases = get_gpu_aliases()
        _local_aliases = {k: v for k, v in _local_aliases.items() if not k.startswith("_")}
        meta            = get_meta()
    except Exception:
        # Fallback: load directly if run outside src/
        import json
        import pathlib
        for p in [pathlib.Path("config/vaultlayer_data.json"),
                  pathlib.Path(__file__).parent.parent.parent/"config"/"vaultlayer_data.json"]:
            if p.exists():
                d = json.load(open(p))
                _local_prices = {k: v for k, v in d.get("provider_prices", {}).items() if isinstance(v, dict)}
                _local_aliases = {k: v for k, v in d.get("gpu_aliases", {}).items() if not k.startswith("_")}
                meta            = d.get("_meta", {})
                break
        else:
            click.echo("  Error: config/vaultlayer_data.json not found")
            return
    PROVIDER_PRICES = _local_prices
    GPU_ALIASES = _local_aliases

    gpu_key = GPU_ALIASES.get(gpu, gpu)
    available = {p: v[gpu_key] for p, v in PROVIDER_PRICES.items() if isinstance(v, dict) and v.get(gpu_key) is not None}
    if not available:
        click.echo(f"  Unknown GPU: {gpu}. Use: H100, A100, A100_40, A10G"); return

    aws_od = PROVIDER_PRICES.get("AWS On-Demand", {}).get(gpu_key, 0)
    aws_total = aws_od * hours * gpus
    non_aws = {p: v for p, v in available.items() if "AWS" not in p}
    best_p = min(non_aws, key=lambda p: non_aws[p]) if non_aws else list(available.keys())[0]
    vl_price = non_aws.get(best_p, aws_od) * VL_MARGIN
    vl_total = vl_price * hours * gpus
    savings = aws_total - vl_total
    savings_pct = savings / aws_total * 100 if aws_total else 0

    G, Y, B, R, BO = "\033[97m", "\033[97m", "\033[97m", "\033[0m", "\033[1m"
    click.echo("")
    click.echo(f"  {BO}VaultLayer Estimate{R}  GPU={gpu_key}  x{gpus}  {hours:.0f}h")
    if meta.get("last_updated"):
        click.echo(f"  {Y}Prices last updated: {meta['last_updated']}{R}")
    click.echo(f"  {Y}{chr(9472)*54}{R}")
    click.echo(f"  {BO}{'Provider':<22} {'$/hr':>8}  {'Total':>10}  {'vs AWS OD':>10}{R}")
    click.echo(f"  {chr(9472)*54}")
    for provider, price in sorted(available.items(), key=lambda x: x[1]):
        total = price * hours * gpus
        diff = total - aws_total
        ds = f"-${abs(diff):,.0f}" if diff < 0 else f"+${diff:,.0f}"
        col = G if diff < 0 else ""
        tag = f"  {B}<- VaultLayer{R}" if provider == best_p else ""
        click.echo(f"  {provider:<22} ${price:>7.2f}  ${total:>9,.0f}  {col}{ds:>10}{R}{tag}")
    click.echo(f"  {chr(9472)*54}")
    click.echo("")
    click.echo(f"  {BO}VaultLayer:{R} ${vl_price:.2f}/hr  (${vl_total:,.0f} total)")
    click.echo(f"  {G}{BO}Savings:{R}    ${savings:,.0f} ({savings_pct:.0f}% vs AWS OD) | 99.9% SLA")
    click.echo("")
    click.echo(f"  To update prices: edit config/vaultlayer_data.json")
    click.echo(f"  Run:  vaultlayer run --gpu {gpu} python train.py")
    click.echo("")
