"""
VaultLayer — AST-based checkpoint integration injector.

Parses the user's training script and inserts VaultLayer checkpoint calls
at the correct locations. Works on the source lines (not the AST itself)
so comments, formatting, and blank lines are preserved.

Supports:
  - Raw PyTorch  (3 lines: import, restore before loop, checkpoint inside loop)
  - DeepSpeed    (2 lines: import, vl_init after engine init, vl_checkpoint inside loop)
  - JAX / Flax   (3 lines: import, vl_restore before loop, vl_checkpoint inside loop)
"""
from __future__ import annotations

import ast
import re
import textwrap
from pathlib import Path
from typing import Optional


# ── Helpers ───────────────────────────────────────────────────────────────────

def _indent_of(line: str) -> int:
    return len(line) - len(line.lstrip())


def _source_slice(lines: list[str], node: ast.AST) -> str:
    start = node.lineno - 1
    end   = getattr(node, "end_lineno", node.lineno) - 1
    return "".join(lines[start : end + 1])


# ── Core injector ─────────────────────────────────────────────────────────────

class CheckpointInjector:
    """
    AST-aware injector that adds VaultLayer checkpoint integration.

    Usage
    -----
        injector = CheckpointInjector(source, framework="pytorch")
        new_source, diff = injector.inject()
        # show diff to user, write new_source to file if confirmed
    """

    def __init__(self, source: str, framework: str = "pytorch"):
        """
        Parameters
        ----------
        source    : Full text of the training script.
        framework : "pytorch" or "deepspeed"
        """
        self.source    = source
        self.lines     = source.splitlines(keepends=True)
        self.framework = framework
        try:
            self.tree = ast.parse(source)
        except SyntaxError as exc:
            raise ValueError(f"Cannot parse script: {exc}") from exc

        # Variable names detected from the AST (fall back to canonical names)
        self._model_var     = self._detect_model_var()
        self._opt_var       = self._detect_optimizer_var()
        self._engine_var    = self._detect_engine_var()
        self._loss_var      = self._detect_loss_var()
        self._params_var    = self._detect_params_var()
        self._opt_state_var = self._detect_opt_state_var()

    # ── Public API ────────────────────────────────────────────────────────────

    def inject(self) -> tuple[str, list[str]]:
        """
        Insert VaultLayer integration and return (new_source, diff_lines).
        diff_lines is a list of human-readable "+  added line" strings.
        Raises ValueError if no suitable insertion points are found.

        Multi-phase support
        -------------------
        If the script contains more than one training loop (e.g. warmup phase
        followed by main training), each loop gets its own restore call and
        checkpoint directory:
            start_step_phase0 = restore('./checkpoints/phase0', ...)
            for step in range(start_step_phase0, warmup_steps): ...

            start_step_phase1 = restore('./checkpoints/phase1', ...)
            for step in range(start_step_phase1, main_steps): ...
        Single-loop scripts are unaffected — they keep `start_step` and
        `./checkpoints`.
        """
        patches: list[tuple[int, list[str]]] = []   # (insert-before idx, lines)
        replacements: list[tuple[int, str, str]] = [] # (line idx, old, new)
        diff: list[str] = []

        # ── 1. Import ─────────────────────────────────────────────────────────
        import_idx = self._last_import_line_idx()
        import_line = self._make_import_line()
        patches.append((import_idx + 1, [import_line + "\n"]))
        diff.append(f"+  {import_line}")

        # ── 2. All training loops ──────────────────────────────────────────────
        loops = self._find_all_training_loops()
        multi = len(loops) > 1

        def _step_var(i: int) -> str:
            return f"start_step_phase{i}" if multi else "start_step"

        def _ckpt_dir(i: int) -> str:
            # CHECKPOINT_DIR is exported from vaultlayer_checkpoint.py.
            # It resolves to $VL_DATA_ROOT/vl-checkpoints on GPU nodes (NVMe)
            # and ./checkpoints on developer machines without NVMe.
            suffix = f" + '/phase{i}'" if multi else ""
            return f"CHECKPOINT_DIR{suffix}"

        # ── PyTorch ───────────────────────────────────────────────────────────
        if self.framework == "pytorch":
            if not loops:
                raise ValueError(
                    "No standard training loop detected (expected a for-loop containing "
                    "optimizer.step() or backward()). Auto-injection cannot proceed safely — "
                    "use the manual 3-line integration below."
                )
            else:
                for i, loop in enumerate(loops):
                    sv, cd = _step_var(i), _ckpt_dir(i)
                    restore_line = self._make_restore_line(sv, cd)
                    patches.append((loop["start_idx"], ["", restore_line + "\n"]))
                    diff.append(f"+  {restore_line}")

                    old_for, new_for = self._patch_range(loop, sv)
                    if old_for and new_for and old_for != new_for:
                        replacements.append((loop["start_idx"], old_for, new_for))
                        diff.append(f"~  {old_for.strip()}  →  {new_for.strip()}")

                    insert_idx  = self._inner_insert_idx(loop)
                    body_indent = " " * loop["body_indent"]
                    ckpt_lines, ckpt_diff = self._make_checkpoint_block(loop, body_indent, cd)
                    patches.append((insert_idx + 1, ckpt_lines))
                    diff.extend(ckpt_diff)

        # ── JAX ───────────────────────────────────────────────────────────────
        elif self.framework == "jax":
            if not loops:
                raise ValueError(
                    "No standard training loop detected (expected a for-loop containing "
                    "a JAX optimizer update). Auto-injection cannot proceed safely — "
                    "use the manual 3-line integration below."
                )
            else:
                for i, loop in enumerate(loops):
                    sv, cd = _step_var(i), _ckpt_dir(i)
                    restore_line = self._make_jax_restore_line(sv, cd)
                    patches.append((loop["start_idx"], ["", restore_line + "\n"]))
                    diff.append(f"+  {restore_line}")

                    old_for, new_for = self._patch_range(loop, sv)
                    if old_for and new_for and old_for != new_for:
                        replacements.append((loop["start_idx"], old_for, new_for))
                        diff.append(f"~  {old_for.strip()}  →  {new_for.strip()}")

                    insert_idx  = self._inner_insert_idx(loop)
                    body_indent = " " * loop["body_indent"]
                    ckpt_lines, ckpt_diff = self._make_jax_checkpoint_block(loop, body_indent, cd)
                    patches.append((insert_idx + 1, ckpt_lines))
                    diff.extend(ckpt_diff)

        # ── DeepSpeed ─────────────────────────────────────────────────────────
        elif self.framework == "deepspeed":
            # vl_init is tied to engine init (happens once) — single start_step
            init_idx = self._find_deepspeed_init_idx()
            init_line = self._make_vl_init_line()
            anchor = init_idx if init_idx is not None else (
                loops[0]["start_idx"] - 1 if loops else import_idx + 1
            )
            patches.append((anchor + 1, ["", init_line + "\n"]))
            diff.append(f"+  {init_line}")

            # Patch first loop range only (engine start_step is global)
            for i, loop in enumerate(loops):
                sv  = "start_step" if i == 0 else None
                cd  = _ckpt_dir(i)

                if sv:
                    old_for, new_for = self._patch_range(loop, sv)
                    if old_for and new_for and old_for != new_for:
                        replacements.append((loop["start_idx"], old_for, new_for))
                        diff.append(f"~  {old_for.strip()}  →  {new_for.strip()}")

                insert_idx  = self._inner_insert_idx(loop)
                body_indent = " " * loop["body_indent"]
                ckpt_lines, ckpt_diff = self._make_vl_checkpoint_block(loop, body_indent, cd)
                patches.append((insert_idx + 1, ckpt_lines))
                diff.extend(ckpt_diff)

        # ── Apply patches (reverse order so line numbers stay valid) ──────────
        result = list(self.lines)

        for idx, old, new in replacements:
            result[idx] = result[idx].replace(old, new, 1)

        for idx, new_lines in sorted(patches, key=lambda x: x[0], reverse=True):
            result[idx:idx] = new_lines

        return "".join(result), diff

    # ── Detection helpers ─────────────────────────────────────────────────────

    def _last_import_line_idx(self) -> int:
        """0-based index of the last top-level import/from-import line."""
        last = 0
        for node in self.tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                last = (getattr(node, "end_lineno", node.lineno) or node.lineno) - 1
        return last

    def _find_all_training_loops(self) -> list[dict]:
        """
        Return info dicts for every top-level for-loop that looks like a
        training loop, in source order.

        Covers:
        - Single flat step loop:   for step in range(10_000)
        - Nested epoch/batch loop: for epoch in range(100): for batch in ...
        - Multi-phase scripts:     warmup loop followed by main training loop
        """
        loops = []
        for node in self._top_level_statements():
            if isinstance(node, ast.For) and self._is_training_loop(node):
                loops.append(self._loop_info(node))
        return loops

    def _is_training_loop(self, node: ast.For) -> bool:
        """Heuristic: does this for-loop contain training primitives?"""
        for child in ast.walk(node):
            if isinstance(child, ast.Call) and isinstance(child.func, ast.Attribute):
                if child.func.attr in ("backward", "step"):
                    return True
        # Fallback: iterates over range()
        return (
            isinstance(node.iter, ast.Call)
            and isinstance(node.iter.func, ast.Name)
            and node.iter.func.id == "range"
        )

    def _top_level_statements(self):
        """Yield top-level statements, plus bodies of `if __name__ == '__main__'` blocks."""
        for node in self.tree.body:
            yield node
            if isinstance(node, ast.If):
                test = node.test
                # if __name__ == "__main__"
                if (isinstance(test, ast.Compare)
                        and isinstance(test.left, ast.Name)
                        and test.left.id == "__name__"):
                    yield from node.body

    def _loop_info(self, node: ast.For) -> dict:
        """Extract line indices and indentation from a For node."""
        start_idx = node.lineno - 1
        end_idx   = getattr(node, "end_lineno", node.lineno) - 1
        loop_line = self.lines[start_idx]
        indent    = _indent_of(loop_line)

        # Body indentation
        body_indent = indent + 4
        if node.body:
            first = self.lines[node.body[0].lineno - 1]
            body_indent = _indent_of(first)

        # Loop variable name ("step", "epoch", "i", …)
        loop_var = "step"
        if isinstance(node.target, ast.Name):
            loop_var = node.target.id

        # Single-arg range(N) target
        range_arg = None
        if (isinstance(node.iter, ast.Call)
                and isinstance(node.iter.func, ast.Name)
                and node.iter.func.id == "range"):
            args = node.iter.args
            if len(args) == 1:
                range_arg = ast.unparse(args[0])

        # Line index of the last optimizer/engine .step() call inside the loop
        step_idx = None
        for child in ast.walk(node):
            if (isinstance(child, ast.Call)
                    and isinstance(child.func, ast.Attribute)
                    and child.func.attr == "step"):
                step_idx = child.lineno - 1

        return {
            "start_idx":  start_idx,
            "end_idx":    end_idx,
            "indent":     indent,
            "body_indent": body_indent,
            "loop_var":   loop_var,
            "range_arg":  range_arg,
            "step_idx":   step_idx,
            "node":       node,
        }

    def _inner_insert_idx(self, loop: dict) -> int:
        """
        0-based line index after which to insert the checkpoint block.

        Nested-loop awareness
        ---------------------
        If optimizer.step() sits inside a nested for-loop (e.g. the inner
        batch loop), inserting right after it would place the checkpoint
        inside that inner loop and disrupt indentation.  Instead we detect
        the nesting and return the end line of the innermost training-related
        for-loop, so the checkpoint is injected at the outer loop's body level.

            for epoch in range(N):          ← outer (this loop)
                for batch in loader:        ← inner for-loop
                    optimizer.step()        ← step_idx points here
                                            ← we insert HERE (after inner loop)
        """
        if loop["step_idx"] is None:
            return loop["end_idx"]

        step_indent = _indent_of(self.lines[loop["step_idx"]])
        if step_indent > loop["body_indent"]:
            # step is deeper than the outer body → find end of inner for-loop
            return self._inner_loop_end_idx(loop)

        return loop["step_idx"]

    def _inner_loop_end_idx(self, loop: dict) -> int:
        """
        Return the 0-based end-line index of the first nested for-loop
        in loop's body that contains a backward/step call (the batch loop).
        Falls back to loop["end_idx"] if none found.
        """
        for stmt in loop["node"].body:
            if isinstance(stmt, ast.For) and self._is_training_loop(stmt):
                return getattr(stmt, "end_lineno", stmt.lineno) - 1
        return loop["end_idx"]

    def _checkpoint_freq(self, loop: dict) -> int:
        """Return the step/epoch modulo for local NVMe checkpoint saves.

        Cost note
        ---------
        Local NVMe saves are FREE — this modulo only controls how often
        checkpoint.pt is rewritten on the local disk.
        R2 uploads (the actual cost item at $0.36/M Class A ops) are
        independently rate-limited in vaultlayer_checkpoint.py to at most
        once per 30 minutes regardless of this frequency.

        Rules
        -----
        1. Literal range(N):
           - N ≤ 20  (tiny run / quick test)  →  1 (every step/epoch)
           - 20 < N ≤ 500                     →  max(5, N // 20)
             Gives ~20 local snapshots: range(100)→5, range(200)→10, range(500)→25
           - N > 500 (long step loop)          →  max(500, N // 20)
             range(10_000)→500, range(100_000)→5000
           All three tiers generate ≤20 NVMe snapshots per run, keeping disk
           churn low and resume granularity acceptable.

        2. Epoch-named variable without known total  →  1
           (save every epoch — epochs are natural boundaries, typically long).

        3. Step/iter-named or unknown               →  1000
           Conservative default: ~2-4 min between saves on H100 fine-tuning.
        """
        if loop.get("range_arg"):
            try:
                n = int(loop["range_arg"])
                if n <= 20:
                    return 1
                if n <= 500:
                    return max(5, n // 20)
                return max(500, n // 20)
            except (ValueError, TypeError):
                pass

        if "epoch" in loop.get("loop_var", "").lower():
            return 1

        return 1000

    def _patch_range(
        self, loop: dict, step_var: str = "start_step"
    ) -> tuple[Optional[str], Optional[str]]:
        """
        Return (old_text, new_text) to change range(N) → range(<step_var>, N).
        Returns (None, None) if the loop already has a start arg or isn't range-based.
        """
        if not loop["range_arg"]:
            return None, None
        old = f"range({loop['range_arg']})"
        new = f"range({step_var}, {loop['range_arg']})"
        return old, new

    def _find_deepspeed_init_idx(self) -> Optional[int]:
        """0-based line index of the deepspeed.initialize() call, or None."""
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Call):
                func = node.func
                is_ds_init = (
                    (isinstance(func, ast.Attribute) and func.attr == "initialize"
                     and isinstance(func.value, ast.Name) and func.value.id == "deepspeed")
                    or (isinstance(func, ast.Name) and func.id == "initialize")
                )
                if is_ds_init:
                    return (getattr(node, "end_lineno", node.lineno) or node.lineno) - 1
        return None

    # ── Variable detection ────────────────────────────────────────────────────

    def _detect_model_var(self) -> str:
        """Best-guess model variable name from assignments."""
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        name = target.id.lower()
                        if "model" in name or "net" in name or "module" in name:
                            return target.id
        return "model"

    def _detect_optimizer_var(self) -> str:
        """Best-guess optimizer variable name."""
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        name = target.id.lower()
                        if "optim" in name or "optimizer" in name:
                            return target.id
        return "optimizer"

    def _detect_engine_var(self) -> str:
        """Detect engine variable from deepspeed.initialize() return value."""
        for node in ast.walk(self.tree):
            # engine, optimizer, _, _ = deepspeed.initialize(...)
            if isinstance(node, ast.Assign):
                val = node.value
                is_ds = (
                    isinstance(val, ast.Call)
                    and isinstance(val.func, ast.Attribute)
                    and val.func.attr == "initialize"
                )
                if is_ds and isinstance(node.targets[0], ast.Tuple):
                    first = node.targets[0].elts[0]
                    if isinstance(first, ast.Name) and first.id != "_":
                        return first.id
        return "engine"

    def _detect_loss_var(self) -> str:
        """
        Best-guess loss variable name.

        Prefers the shortest name containing "loss" so that plain `loss`
        wins over `train_loss`, `best_val_loss`, etc.
        """
        candidates: list[str] = []
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and "loss" in target.id.lower():
                        candidates.append(target.id)
        if not candidates:
            return "loss"
        # Shortest name wins; break ties alphabetically
        return min(candidates, key=lambda n: (len(n), n))

    def _detect_params_var(self) -> str:
        """Detect JAX params variable (model.init() return value or explicit 'params' assignment)."""
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    # Direct: params = model.init(...) or params = {'params': ...}
                    if isinstance(target, ast.Name) and "param" in target.id.lower():
                        return target.id
                # Tuple unpack: params, opt_state = ...  or  state = TrainState(params=...)
                if isinstance(node.targets[0], ast.Tuple):
                    for elt in node.targets[0].elts:
                        if isinstance(elt, ast.Name) and "param" in elt.id.lower():
                            return elt.id
        return "params"

    def _detect_opt_state_var(self) -> str:
        """Detect optax optimizer state variable."""
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        name = target.id.lower()
                        if "opt_state" in name or "optimizer_state" in name:
                            return target.id
                # Tuple unpack: params, opt_state = init_fn(...)
                if isinstance(node.targets[0], ast.Tuple):
                    for elt in node.targets[0].elts:
                        if isinstance(elt, ast.Name) and "state" in elt.id.lower():
                            return elt.id
        return "opt_state"

    # ── Code generation ───────────────────────────────────────────────────────

    def _make_import_line(self) -> str:
        if self.framework == "pytorch":
            # Import CHECKPOINT_DIR so the generated restore()/checkpoint() calls
            # use the NVMe-aware path ($VL_DATA_ROOT/vl-checkpoints on GPU nodes).
            return "from vaultlayer_checkpoint import checkpoint, restore, CHECKPOINT_DIR"
        if self.framework == "jax":
            return "from vaultlayer_checkpoint_jax import vl_restore, vl_checkpoint, CHECKPOINT_DIR"
        return "from vaultlayer_checkpoint_deepspeed import vl_init, vl_checkpoint, CHECKPOINT_DIR"

    def _make_restore_line(
        self, step_var: str = "start_step", ckpt_dir: str = "CHECKPOINT_DIR"
    ) -> str:
        m, o = self._model_var, self._opt_var
        # ckpt_dir is now a Python expression (CHECKPOINT_DIR or CHECKPOINT_DIR + '/phaseN'),
        # NOT a string literal — do not wrap in quotes.
        return f"{step_var} = restore(save_path={ckpt_dir}, model={m}, optimizer={o})"

    def _make_vl_init_line(self) -> str:
        return f"start_step = vl_init({self._engine_var})"

    def _make_checkpoint_block(
        self, loop: dict, indent: str, ckpt_dir: str = "CHECKPOINT_DIR"
    ) -> tuple[list[str], list[str]]:
        """Return (lines_to_insert, diff_preview) for the checkpoint block.

        ckpt_dir is a Python expression (not a string literal) — on GPU nodes it
        resolves to $VL_DATA_ROOT/vl-checkpoints (NVMe), on dev machines to
        ./checkpoints.

        CPU-hog note: torch.save() pickles tensors on the CPU, causing a spike
        that can double training step time on CPU-limited spot instances.
        We emit async_save=None so VaultLayer auto-enables background saving
        for models >7B params (threshold: VAULTLAYER_ASYNC_CHECKPOINT_THRESHOLD_PARAMS).
        """
        var, m, o = loop["loop_var"], self._model_var, self._opt_var
        freq = self._checkpoint_freq(loop)
        lines = [
            f"{indent}if {var} % {freq} == 0:\n",
            # async_save=None → auto-enabled for >7B param models, preventing CPU spike
            f"{indent}    checkpoint(step={var}, model={m}, optimizer={o},"
            f" save_path={ckpt_dir}, loss={self._loss_var}.item()"
            f" if hasattr({self._loss_var}, 'item') else {self._loss_var})\n",
        ]
        diff = [f"+  {l.rstrip()}" for l in lines]
        return lines, diff

    def _make_jax_restore_line(
        self, step_var: str = "start_step", ckpt_dir: str = "CHECKPOINT_DIR"
    ) -> str:
        p, o = self._params_var, self._opt_state_var
        return f"{p}, {o}, {step_var} = vl_restore({p}, {o}, checkpoint_dir={ckpt_dir})"

    def _make_jax_checkpoint_block(
        self, loop: dict, indent: str, ckpt_dir: str = "CHECKPOINT_DIR"
    ) -> tuple[list[str], list[str]]:
        var   = loop["loop_var"]
        p, o  = self._params_var, self._opt_state_var
        loss  = self._loss_var
        freq  = self._checkpoint_freq(loop)
        lines = [
            f"{indent}if {var} % {freq} == 0:\n",
            f"{indent}    vl_checkpoint({var}, {p}, {o},"
            f" checkpoint_dir={ckpt_dir}, loss=float({loss}))\n",
        ]
        diff = [f"+  {l.rstrip()}" for l in lines]
        return lines, diff

    def _make_vl_checkpoint_block(
        self, loop: dict, indent: str, ckpt_dir: str = "CHECKPOINT_DIR"
    ) -> tuple[list[str], list[str]]:
        """Return (lines_to_insert, diff_preview) for the vl_checkpoint block."""
        var, eng, loss = loop["loop_var"], self._engine_var, self._loss_var
        freq = self._checkpoint_freq(loop)
        lines = [
            f"{indent}if {var} % {freq} == 0:\n",
            f"{indent}    vl_checkpoint({eng}, {var},"
            f" checkpoint_dir={ckpt_dir},"
            f" loss={loss}.item() if hasattr({loss}, 'item') else {loss})\n",
        ]
        diff = [f"+  {l.rstrip()}" for l in lines]
        return lines, diff


# ── Storage scanner ───────────────────────────────────────────────────────────

# Import patterns that signal the script accesses external storage
_STORAGE_IMPORT_PATTERNS: list[tuple[str, str]] = [
    # (regex_pattern, human-readable label)
    (r"\bboto3\b",                                  "AWS S3 (boto3)"),
    (r"\bs3fs\b",                                   "AWS S3 (s3fs)"),
    (r"\baiobotocore\b",                            "AWS S3 (aiobotocore)"),
    (r"s3://",                                      "S3 URI (s3://)"),
    (r"google\.cloud",                               "GCS (google-cloud-storage)"),
    (r"\bgcs\b",                                    "GCS"),
    (r"gs://",                                      "GCS URI (gs://)"),
    (r"\bazure\.storage\b",                         "Azure Blob Storage"),
    (r"\bBlobServiceClient\b",                      "Azure Blob Storage"),
    (r"https?://[^\s]+\.blob\.core\.windows\.net",  "Azure Blob Storage URI"),
]


def scan_storage_access(source: str) -> list[str]:
    """
    Scan script source for storage access patterns (S3, GCS, Azure).
    Returns a deduplicated list of human-readable labels for each detected system.
    """
    found: dict[str, bool] = {}
    for pattern, label in _STORAGE_IMPORT_PATTERNS:
        if re.search(pattern, source):
            found[label] = True
    return list(found.keys())


def warn_if_storage_unconfigured(script_path: "Path", config_env: "Path") -> None:
    """
    Scan script for storage access. If storage is accessed but no credentials
    are configured in config.env, print a one-time warning with the connect command.

    Suppressed if any of VL_S3_ACCESS_KEY_ID / VL_GCS_CREDENTIALS_JSON /
    VL_AZURE_CONNECTION_STRING / VL_AZURE_ACCOUNT_NAME are in config.env.
    """
    import click

    try:
        source = script_path.read_text(errors="replace")
    except OSError:
        return

    detected = scan_storage_access(source)
    if not detected:
        return

    # Check if credentials are already configured
    configured = False
    if config_env.exists():
        env_text = config_env.read_text()
        configured = any(
            key in env_text
            for key in ("VL_S3_ACCESS_KEY_ID", "VL_GCS_CREDENTIALS_JSON",
                        "VL_AZURE_CONNECTION_STRING", "VL_AZURE_ACCOUNT_NAME")
        )

    if configured:
        return

    Y, R, BO = "\033[97m", "\033[0m", "\033[1m"
    click.echo(f"\n  {Y}Storage access detected in {script_path.name}:{R}")
    for label in detected:
        click.echo(f"    · {label}")
    click.echo(
        f"\n  When VaultLayer migrates your job, the new node won't have access\n"
        f"  to your storage unless you forward credentials first.\n"
        f"\n  Run: {BO}vaultlayer connect storage{R}\n"
        f"  (one-time setup — credentials are forwarded to every provisioned node)\n"
    )


# ── CLI helper ────────────────────────────────────────────────────────────────

def detect_framework(integration_result: dict) -> str:
    """Map _check_script_integration() result to injector framework string."""
    if integration_result.get("deepspeed"):
        return "deepspeed"
    if integration_result.get("jax"):
        return "jax"
    return "pytorch"


def run_interactive_injection(script_path: Path, framework: str) -> bool:
    """
    Show a diff of what will be added, ask Y/n, write file if confirmed.

    This is shown BEFORE the pre-flight table so the user's first interaction
    is a simple question: "want me to add checkpoint integration?" — not a wall
    of GPU/cost output followed by an afterthought warning.

    Returns True if the file was modified.
    """
    import click

    try:
        source = script_path.read_text(errors="replace")
        injector = CheckpointInjector(source, framework=framework)
        new_source, diff = injector.inject()
    except ValueError as exc:
        click.echo(f"\n  Could not auto-inject ({exc}). Add the integration manually.")
        return False

    Y, R, BO, G = "\033[97m", "\033[0m", "\033[1m", "\033[97m"

    framework_labels = {
        "pytorch":   "PyTorch",
        "deepspeed": "DeepSpeed",
        "jax":       "JAX/Flax",
    }
    label = framework_labels.get(framework, framework)

    click.echo(f"\n  {BO}VaultLayer checkpoint integration not found in {script_path.name}.{R}")
    click.echo(f"  I can add {label} checkpoint support automatically:\n")
    for line in diff:
        colour = G if line.startswith("+") else Y
        click.echo(f"  {colour}{line}{R}")
    click.echo("")

    confirmed = click.confirm("  Add it?", default=True)

    if not confirmed:
        # Show the exact lines to add manually so the user can copy-paste
        add_lines  = [l[3:] for l in diff if l.startswith("+  ")]   # strip "+  "
        change_lines = [l[3:] for l in diff if l.startswith("~  ")]  # strip "~  "

        click.echo(f"\n  {BO}Add these lines to {script_path.name}:{R}\n")
        for code in add_lines:
            click.echo(f"    {G}{code}{R}")
        if change_lines:
            click.echo(f"\n  {BO}Also update:{R}")
            for change in change_lines:
                click.echo(f"    {Y}{change}{R}")
        click.echo(
            f"\n  Run {BO}vaultlayer init{R} to generate the helper file if you don't have it.\n"
        )
        return False

    backup = script_path.with_suffix(".py.bak")
    backup.write_text(source)
    script_path.write_text(new_source)
    click.echo(f"\n  {G}✓ Done.{R} {script_path.name} updated. Backup → {backup.name}\n")
    return True
