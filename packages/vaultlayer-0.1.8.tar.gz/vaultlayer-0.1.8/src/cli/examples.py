"""
vaultlayer examples — Download ready-to-run training scripts.

Creates a vaultlayer-examples/ directory with training scripts that
can be used immediately with `vaultlayer run`.
"""
from __future__ import annotations

from pathlib import Path

import click


# Scripts are embedded as strings so they ship with the pip package.
# No internet or git clone required.

TRAIN_QUICK = '''"""
VaultLayer Quick Test — runs in ~30 seconds, verifies GPU + checkpoint pipeline.
Usage: vaultlayer run --gpu A10G python vaultlayer-examples/train_quick.py
"""
import os, time, torch, torch.nn as nn

print("=" * 60)
print("VaultLayer Quick Test")
print("=" * 60)

device = "cuda" if torch.cuda.is_available() else "cpu"
if device == "cuda":
    print(f"GPU: {torch.cuda.get_device_name(0)} ({torch.cuda.get_device_properties(0).total_memory / 1e9:.0f} GB)")
else:
    print("GPU: None (CPU)")
print(f"PyTorch: {torch.__version__}")

model = nn.Sequential(nn.Linear(256, 512), nn.ReLU(), nn.Linear(512, 256), nn.ReLU(), nn.Linear(256, 10)).to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
print(f"Model: 3-layer MLP ({sum(p.numel() for p in model.parameters()):,} params)")

start_step = 0
try:
    from vaultlayer_checkpoint import restore, CHECKPOINT_DIR
    start_step = restore(CHECKPOINT_DIR, model=model, optimizer=optimizer)
    if start_step > 0: print(f"Resumed from step {start_step}")
except ImportError: pass

total_steps = 50
print(f"\\nTraining steps {start_step} to {total_steps}...\\n")
t0 = time.time()
for step in range(start_step, total_steps):
    x = torch.randn(32, 256, device=device)
    y = torch.randint(0, 10, (32,), device=device)
    loss = nn.functional.cross_entropy(model(x), y)
    optimizer.zero_grad(); loss.backward(); optimizer.step()
    if (step + 1) % 10 == 0: print(f"  Step {step+1}/{total_steps}  loss={loss.item():.4f}")

try:
    from vaultlayer_checkpoint import checkpoint, CHECKPOINT_DIR
    checkpoint(step=total_steps, model=model, optimizer=optimizer, save_path=CHECKPOINT_DIR, loss=loss.item())
    print(f"\\nCheckpoint saved at step {total_steps}")
except ImportError: pass

print(f"\\n{'='*60}")
print(f"DONE  {total_steps - start_step} steps in {time.time()-t0:.1f}s  |  device={device}")
print(f"{'='*60}")
'''

TRAIN_MNIST = '''"""
VaultLayer MNIST Test — trains a CNN on MNIST for 2 epochs (~2 min).
Usage: vaultlayer run --gpu A10G python vaultlayer-examples/train_mnist.py
MNIST downloads automatically (12 MB). No setup needed.
"""
import os, time, torch, torch.nn as nn, torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

print("=" * 60)
print("VaultLayer MNIST Training")
print("=" * 60)

EPOCHS, BATCH_SIZE, CKPT_EVERY, LR = 2, 64, 200, 1e-3
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Device: {device}")

data_dir = os.environ.get("VL_DATA_ROOT", "/tmp") + "/mnist"
transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
train_ds = datasets.MNIST(data_dir, train=True, download=True, transform=transform)
test_ds = datasets.MNIST(data_dir, train=False, transform=transform)
train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True)
test_loader = DataLoader(test_ds, batch_size=1000)
print(f"Dataset: {len(train_ds)} train, {len(test_ds)} test")

class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1, self.conv2 = nn.Conv2d(1,16,3,1), nn.Conv2d(16,32,3,1)
        self.fc1, self.fc2 = nn.Linear(32*5*5, 128), nn.Linear(128, 10)
    def forward(self, x):
        x = F.max_pool2d(F.relu(self.conv1(x)), 2)
        x = F.max_pool2d(F.relu(self.conv2(x)), 2)
        return self.fc2(F.relu(self.fc1(x.view(x.size(0), -1))))

model = SmallCNN().to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=LR)
print(f"Model: SmallCNN ({sum(p.numel() for p in model.parameters()):,} params)")

start_step, start_epoch = 0, 0
try:
    from vaultlayer_checkpoint import restore, CHECKPOINT_DIR
    start_step = restore(CHECKPOINT_DIR, model=model, optimizer=optimizer)
    if start_step > 0:
        start_epoch = start_step // len(train_loader)
        print(f"Resumed from step {start_step}")
except ImportError: pass

print(f"\\nTraining {EPOCHS} epochs (checkpoint every {CKPT_EVERY} steps)...\\n")
global_step, t0 = start_step, time.time()
for epoch in range(start_epoch, EPOCHS):
    model.train(); epoch_loss = 0
    for data, target in train_loader:
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        loss = F.cross_entropy(model(data), target)
        loss.backward(); optimizer.step()
        global_step += 1; epoch_loss += loss.item()
        if global_step % 100 == 0: print(f"  Epoch {epoch+1}/{EPOCHS}  Step {global_step}  Loss={loss.item():.4f}")
        if global_step % CKPT_EVERY == 0:
            try:
                from vaultlayer_checkpoint import checkpoint, CHECKPOINT_DIR
                checkpoint(step=global_step, model=model, optimizer=optimizer, save_path=CHECKPOINT_DIR, loss=loss.item())
                print(f"  >> Checkpoint at step {global_step}")
            except ImportError: pass
    print(f"  Epoch {epoch+1} done  |  Avg loss: {epoch_loss/len(train_loader):.4f}")

model.eval(); correct = 0
with torch.no_grad():
    for data, target in test_loader:
        data, target = data.to(device), target.to(device)
        correct += (model(data).argmax(1) == target).sum().item()
accuracy = 100.0 * correct / len(test_ds)

print(f"\\n{'='*60}")
print(f"DONE  {EPOCHS} epochs, {global_step} steps, {time.time()-t0:.0f}s  |  Accuracy: {accuracy:.1f}%")
print(f"{'='*60}")
'''

TRAIN_LONG = '''"""
VaultLayer Long-Running Test — ~10 minutes with regular checkpoints.
Use this to test: spot interruption, failover, back-hop, credit exhaustion.
Usage: vaultlayer run --gpu A10G --failover python vaultlayer-examples/train_long.py
"""
import os, time, torch, torch.nn as nn

print("=" * 60)
print("VaultLayer Long-Running Test (10 min)")
print("=" * 60)

TOTAL_STEPS, CKPT_EVERY, PRINT_EVERY = 10000, 500, 100
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Device: {device}")
if device == "cuda": print(f"GPU: {torch.cuda.get_device_name(0)}")

model = nn.Sequential(nn.Linear(512,1024), nn.ReLU(), nn.Linear(1024,1024), nn.ReLU(), nn.Linear(1024,512), nn.ReLU(), nn.Linear(512,10)).to(device)
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
print(f"Model: 4-layer MLP ({sum(p.numel() for p in model.parameters()):,} params)")

start_step = 0
try:
    from vaultlayer_checkpoint import restore, CHECKPOINT_DIR
    start_step = restore(CHECKPOINT_DIR, model=model, optimizer=optimizer)
    if start_step > 0: print(f"Resumed from step {start_step}")
except ImportError: pass

print(f"\\nTraining {start_step} to {TOTAL_STEPS} (checkpoint every {CKPT_EVERY} steps)\\n")
t0 = time.time()
for step in range(start_step, TOTAL_STEPS):
    x = torch.randn(64, 512, device=device); y = torch.randint(0, 10, (64,), device=device)
    loss = nn.functional.cross_entropy(model(x), y)
    optimizer.zero_grad(); loss.backward(); optimizer.step()
    if (step+1) % PRINT_EVERY == 0:
        elapsed = time.time() - t0; sps = (step+1-start_step)/max(elapsed,0.1)
        print(f"  Step {step+1}/{TOTAL_STEPS}  loss={loss.item():.4f}  {sps:.0f} steps/s  ETA {(TOTAL_STEPS-step-1)/max(sps,0.1)/60:.1f}min")
    if (step+1) % CKPT_EVERY == 0:
        try:
            from vaultlayer_checkpoint import checkpoint, CHECKPOINT_DIR
            checkpoint(step=step+1, model=model, optimizer=optimizer, save_path=CHECKPOINT_DIR, loss=loss.item())
            print(f"  >> Checkpoint at step {step+1}")
        except ImportError: pass
    time.sleep(0.05)

print(f"\\n{'='*60}")
print(f"DONE  {TOTAL_STEPS-start_step} steps in {(time.time()-t0)/60:.1f} min  |  device={device}")
print(f"{'='*60}")
'''

STRESS_TINYLLAMA = '''"""
VaultLayer Stress Test: TinyLlama-1.1B QLoRA Fine-Tune
Model: TinyLlama/TinyLlama-1.1B-Chat-v1.0 | Dataset: tatsu-lab/alpaca (52K)
VRAM: ~3 GB | Checkpoint: ~600 MB | Duration: ~15-20 min on A10G

Usage: vaultlayer run --gpu A10G python vaultlayer-examples/stress/train_tinyllama_qlora.py
Env vars: MAX_STEPS=1000, CKPT_EVERY=200, MAX_SEQ_LEN=512

Requires: pip install torch transformers peft trl datasets bitsandbytes accelerate
"""
import os, sys, time
print("=" * 60); print("VaultLayer Stress Test: TinyLlama-1.1B QLoRA"); print("=" * 60)
MODEL_ID = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
MAX_STEPS = int(os.environ.get("MAX_STEPS", "1000"))
CKPT_EVERY = int(os.environ.get("CKPT_EVERY", "200"))
MAX_SEQ_LEN = int(os.environ.get("MAX_SEQ_LEN", "512"))
try:
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, TrainingArguments
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
    from trl import SFTTrainer; from datasets import load_dataset
except ImportError as e: print(f"Missing: {e}\\npip install torch transformers peft trl datasets bitsandbytes accelerate"); sys.exit(1)
device = "cuda" if torch.cuda.is_available() else "cpu"
if device == "cuda": print(f"GPU: {torch.cuda.get_device_name(0)} ({torch.cuda.get_device_properties(0).total_memory/1e9:.0f} GB)")
print(f"Config: steps={MAX_STEPS}, ckpt_every={CKPT_EVERY}")
CKPT_DIR = os.environ.get("VAULTLAYER_CHECKPOINT_DIR", os.path.join(os.environ.get("VL_DATA_ROOT","/tmp"),"vl-checkpoints","tinyllama"))
os.makedirs(CKPT_DIR, exist_ok=True)
resume_from = None
if os.path.isdir(CKPT_DIR):
    existing = sorted([d for d in os.listdir(CKPT_DIR) if d.startswith("checkpoint-")], key=lambda x: int(x.split("-")[-1]) if x.split("-")[-1].isdigit() else 0)
    if existing: resume_from = os.path.join(CKPT_DIR, existing[-1]); print(f"Resuming from: {resume_from}")
print(f"\\nLoading {MODEL_ID} (4-bit QLoRA)..."); t0 = time.time()
bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True)
model = AutoModelForCausalLM.from_pretrained(MODEL_ID, quantization_config=bnb, device_map="auto", trust_remote_code=True)
tok = AutoTokenizer.from_pretrained(MODEL_ID, trust_remote_code=True); tok.pad_token = tok.eos_token; tok.padding_side = "right"
model = prepare_model_for_kbit_training(model)
print(f"Loaded in {time.time()-t0:.0f}s")
lora = LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, bias="none", task_type="CAUSAL_LM", target_modules=["q_proj","k_proj","v_proj","o_proj"])
model = get_peft_model(model, lora)
tp = sum(p.numel() for p in model.parameters() if p.requires_grad); tt = sum(p.numel() for p in model.parameters())
print(f"LoRA: {tp:,} trainable / {tt:,} total ({100*tp/tt:.2f}%)")
print(f"\\nLoading dataset..."); ds = load_dataset("tatsu-lab/alpaca", split="train"); print(f"Dataset: {len(ds)} examples")
def fmt(ex):
    return (f"### Instruction:\\n{ex['instruction']}\\n\\n### Input:\\n{ex['input']}\\n\\n### Response:\\n{ex['output']}" if ex.get("input") else f"### Instruction:\\n{ex['instruction']}\\n\\n### Response:\\n{ex['output']}")
args = TrainingArguments(output_dir=CKPT_DIR, max_steps=MAX_STEPS, per_device_train_batch_size=4, gradient_accumulation_steps=4, learning_rate=2e-4, bf16=torch.cuda.is_available(), logging_steps=50, save_steps=CKPT_EVERY, save_total_limit=3, warmup_steps=50, lr_scheduler_type="cosine", report_to="none", remove_unused_columns=False)
trainer = SFTTrainer(model=model, tokenizer=tok, train_dataset=ds, args=args, formatting_func=fmt, max_seq_length=MAX_SEQ_LEN, packing=True)
print(f"\\nTraining {MAX_STEPS} steps (ckpt every {CKPT_EVERY})...\\n"); t1 = time.time()
trainer.train(resume_from_checkpoint=resume_from); elapsed = time.time()-t1
trainer.save_model(os.path.join(CKPT_DIR, "final"))
print(f"\\n{'='*60}"); print(f"DONE {MAX_STEPS} steps in {elapsed/60:.1f} min")
if torch.cuda.is_available(): print(f"Peak GPU: {torch.cuda.max_memory_allocated()/1e9:.1f} GB")
print(f"{'='*60}")
'''

SCRIPTS = {
    "train_quick.py": TRAIN_QUICK,
    "train_mnist.py": TRAIN_MNIST,
    "train_long.py": TRAIN_LONG,
}

STRESS_SCRIPTS = {
    "stress/train_tinyllama_qlora.py": STRESS_TINYLLAMA,
}


@click.command()
@click.option("--output", "-o", default="vaultlayer-examples",
              help="Output directory (default: ./vaultlayer-examples)")
def examples(output: str):
    """Download ready-to-run training scripts for testing.

    \b
    Creates scripts for basic testing + stress testing:
      train_quick.py                       — 30 seconds, basic GPU test
      train_mnist.py                       — 2 minutes, real CNN on MNIST
      train_long.py                        — 10 minutes, recovery/failover testing
      stress/train_tinyllama_qlora.py      — 15-20 min, real LLM fine-tuning (1.1B params)
    """
    out_dir = Path(output)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Basic scripts
    for name, content in SCRIPTS.items():
        path = out_dir / name
        path.write_text(content.strip() + "\n")

    # Stress test scripts
    for name, content in STRESS_SCRIPTS.items():
        path = out_dir / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content.strip() + "\n")

    click.echo(f"")
    click.echo(f"  Example scripts created in ./{output}/")
    click.echo(f"")
    click.echo(f"  Basic tests:")
    click.echo(f"    vaultlayer run --gpu A10G python {output}/train_quick.py        (30s)")
    click.echo(f"    vaultlayer run --gpu A10G python {output}/train_mnist.py        (2 min)")
    click.echo(f"    vaultlayer run --gpu A10G --failover python {output}/train_long.py  (10 min)")
    click.echo(f"")
    click.echo(f"  Stress tests (real LLM fine-tuning):")
    click.echo(f"    vaultlayer run --gpu A10G python {output}/stress/train_tinyllama_qlora.py  (15 min)")
    click.echo(f"")
    click.echo(f"  Stress tests require: pip install transformers peft trl datasets bitsandbytes accelerate")
    click.echo(f"")
