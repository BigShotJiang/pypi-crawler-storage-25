from __future__ import annotations

import json
from pathlib import Path

import anndata as ad
import pandas as pd
import typer
import yaml

from perturbguard.adversarial.tests import run_adversarial_checks
from perturbguard.benchmark.manifest import check_benchmark_manifest
from perturbguard.benchmark.validation import run_validation_benchmark
from perturbguard.claims.claim_checker import check_claim
from perturbguard.compare.datasets import compare_datasets
from perturbguard.design.checker import check_design
from perturbguard.design.power import check_power
from perturbguard.evaluate.model import evaluate_predictions
from perturbguard.io.config import load_config
from perturbguard.io.config_wizard import infer_config
from perturbguard.io.schema import apply_schema
from perturbguard.io.split_loader import load_split
from perturbguard.leakage.combination_leakage import check_combination_leakage
from perturbguard.leakage.split_leakage import check_split_leakage
from perturbguard.leakage.split_balance import evaluate_split_balance
from perturbguard.qc.confounding import detect_confounding, per_perturbation_concentration
from perturbguard.qc.cell_count import check_cell_counts
from perturbguard.qc.control_balance import check_control_balance
from perturbguard.qc.dataset_validator import validate_anndata, validate_h5ad_file
from perturbguard.qc.guide_consistency import check_guide_consistency
from perturbguard.qc.metadata_shortcut import metadata_shortcut_baseline
from perturbguard.qc.perturbation_summary import summarize_perturbations
from perturbguard.qc.target_effect import check_target_effect
from perturbguard.qc.target_mapping import audit_target_mapping
from perturbguard.repair.anndata import repair_anndata
from perturbguard.reports.dataset_card import build_dataset_card
from perturbguard.reports.html import write_html_report
from perturbguard.reports.plots import write_audit_plots
from perturbguard.reports.preflight import build_preflight_checks
from perturbguard.reports.recommendations import build_recommendations
from perturbguard.reports.summary import build_summary
from perturbguard.simulate.synthetic_anndata import create_synthetic_perturbseq
from perturbguard.splitting.strategies import generate_split
from perturbguard.streaming.profile import profile_h5ad

app = typer.Typer(
    help=(
        "Audit single-cell perturbation AnnData files, generate/check benchmark splits, "
        "and write guardrail reports."
    )
)


@app.command(help="Create a synthetic perturb-seq-like AnnData file for demos and tests.")
def simulate(
    scenario: str = typer.Option("clean", help="Synthetic scenario: clean, batch_confounded, low_cell_count, guide_inconsistent, failed_knockdown, or leaky_combo."),
    out: Path = typer.Option(..., help="Output .h5ad path."),
    n_cells: int = typer.Option(360, help="Number of synthetic cells."),
    n_genes: int = typer.Option(60, help="Number of synthetic genes."),
):
    out.parent.mkdir(parents=True, exist_ok=True)
    create_synthetic_perturbseq(scenario=scenario, n_cells=n_cells, n_genes=n_genes).write_h5ad(out)
    typer.echo(f"Wrote {out}")


@app.command(help="Validate that an AnnData file has the basic structure and metadata needed for audits.")
def validate(
    data: Path = typer.Option(..., help="Input .h5ad file."),
    out: Path | None = typer.Option(None, help="Optional output CSV path."),
    config: Path | None = typer.Option(None, help="Optional YAML schema/control mapping."),
):
    cfg = load_config(config)
    if cfg.schema:
        try:
            df = validate_anndata(apply_schema(ad.read_h5ad(data), cfg.schema, cfg.controls.get("labels")))
        except Exception:
            df = validate_h5ad_file(data)
    else:
        df = validate_h5ad_file(data)
    if out:
        out.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(out, index=False)
    typer.echo(df.to_string(index=False))


def _audit_sections(
    data: Path,
    config: Path | None = None,
    split: Path | None = None,
    claim_name: str | None = None,
):
    cfg = load_config(config)
    adata = apply_schema(ad.read_h5ad(data), cfg.schema, cfg.controls.get("labels"))
    dataset_validation = validate_anndata(adata)
    if dataset_validation.loc[
        dataset_validation["check_id"].eq("obs_perturbation"), "status"
    ].eq("FAIL").any():
        return {
            "dataset_validation": dataset_validation,
            "audit_status": pd.DataFrame(
                [
                    {
                        "status": "FAIL",
                        "message": "Audit stopped because required perturbation metadata is missing.",
                    }
                ]
            ),
        }
    sections = {
        "dataset_validation": dataset_validation,
        "perturbation_summary": summarize_perturbations(adata),
        "control_balance": check_control_balance(adata),
        "cell_count": check_cell_counts(adata),
        "confounding": detect_confounding(adata),
        "metadata_concentration": pd.concat(
            [
                per_perturbation_concentration(adata, column)
                for column in ["batch", "replicate", "donor"]
            ],
            ignore_index=True,
        ),
        "metadata_shortcut": metadata_shortcut_baseline(adata),
        "target_effect": check_target_effect(adata),
        "target_mapping": audit_target_mapping(adata),
        "guide_consistency": check_guide_consistency(adata),
    }
    if split is not None:
        split_df = load_split(split)
        sections["split_leakage"] = check_split_leakage(
            adata,
            split_df,
            claim=claim_name or "unseen_perturbation",
        )
        sections["combination_leakage"] = check_combination_leakage(adata, split_df)
        sections["split_balance"] = evaluate_split_balance(adata, split_df)
        sections["claim_support"] = check_claim(
            adata,
            split_df,
            claim_name or "unseen_perturbation",
        )
    sections["preflight_checks"] = build_preflight_checks(sections)
    return sections


@app.command(help="Run the full PerturbGuard audit and write CSV tables, plots, summary JSON, and HTML.")
def audit(
    data: Path = typer.Option(..., help="Input .h5ad file."),
    out: Path = typer.Option(..., help="Output report directory."),
    config: Path | None = typer.Option(None, help="Optional YAML schema/control mapping."),
    split: Path | None = typer.Option(None, help="Optional split CSV to include leakage/split checks."),
    claim_name: str | None = typer.Option(None, "--claim", help="Optional claim to validate against the split."),
    fail_on: str = typer.Option("never", help="Exit nonzero on audit status: never, fail, warning."),
):
    out.mkdir(parents=True, exist_ok=True)
    tables = out / "tables"
    tables.mkdir(exist_ok=True)
    sections = _audit_sections(data, config, split, claim_name)
    recommendations = build_recommendations(sections)
    sections["recommendations"] = recommendations
    for name, df in sections.items():
        df.to_csv(tables / f"{name}.csv", index=False)
    plot_paths = write_audit_plots(out / "plots", sections)
    write_html_report(out / "report.html", sections, plot_paths)
    summary = build_summary(sections)
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    typer.echo(f"Wrote audit report to {out}")
    normalized_fail_on = fail_on.lower()
    if normalized_fail_on not in {"never", "fail", "warning"}:
        raise typer.BadParameter("--fail-on must be one of: never, fail, warning")
    if normalized_fail_on == "fail" and summary["overall_status"] in {"FAIL", "UNSUPPORTED"}:
        raise typer.Exit(1)
    if normalized_fail_on == "warning" and summary["overall_status"] in {"FAIL", "UNSUPPORTED", "WARNING"}:
        raise typer.Exit(1)


@app.command(name="split", help="Generate train/val/test split CSVs for perturbation benchmark claims.")
def split_cmd(
    data: Path = typer.Option(..., help="Input .h5ad file."),
    out: Path = typer.Option(..., help="Output directory for split.csv."),
    strategy: str = typer.Option(
        "random",
        help=(
            "Split strategy: random, balanced-random, leave-target-gene-out, "
            "leave-perturbation-out, leave-metadata-out, strict-unseen-combination, "
            "or seen-component-unseen-combination."
        ),
    ),
    test_size: float = typer.Option(0.2, help="Approximate fraction for test/evaluation holdout."),
    val_size: float = typer.Option(0.0, help="Optional validation fraction drawn from train cells."),
    random_state: int = typer.Option(0, help="Random seed."),
    metadata_column: str | None = typer.Option(None, help="Metadata column for leave-metadata-out."),
    balance_column: list[str] = typer.Option(None, "--balance-column", help="Extra metadata column for balanced-random stratification; can be repeated."),
    config: Path | None = typer.Option(None, help="Optional YAML schema/control mapping."),
):
    out.mkdir(parents=True, exist_ok=True)
    cfg = load_config(config)
    split_df = generate_split(
        apply_schema(ad.read_h5ad(data), cfg.schema, cfg.controls.get("labels")),
        strategy=strategy,
        test_size=test_size,
        val_size=val_size,
        random_state=random_state,
        metadata_column=metadata_column,
        balance_columns=balance_column or None,
    )
    split_df.to_csv(out / "split.csv", index=False)
    typer.echo(f"Wrote {out / 'split.csv'}")


@app.command(help="Check whether a split supports a declared generalization claim.")
def claim(
    data: Path = typer.Option(..., help="Input .h5ad file."),
    split: Path = typer.Option(..., help="Split CSV with cell_id/perturbation and split columns."),
    claim_name: str = typer.Option("unseen_perturbation", "--claim", help="Claim to check."),
    out: Path = typer.Option(..., help="Output directory."),
    config: Path | None = typer.Option(None, help="Optional YAML schema/control mapping."),
):
    out.mkdir(parents=True, exist_ok=True)
    cfg = load_config(config)
    result = check_claim(
        apply_schema(ad.read_h5ad(data), cfg.schema, cfg.controls.get("labels")),
        load_split(split),
        claim_name,
    )
    result.to_csv(out / "claim_support.csv", index=False)
    typer.echo(result.to_string(index=False))


@app.command(help="Evaluate model prediction CSVs against AnnData cells and metadata groups.")
def evaluate(
    data: Path = typer.Option(..., help="Input .h5ad file."),
    predictions: Path = typer.Option(..., help="CSV with cell_id, y_true, y_pred, and optional confidence."),
    out: Path = typer.Option(..., help="Output report directory."),
    config: Path | None = typer.Option(None, help="Optional YAML schema/control mapping."),
    group_column: list[str] = typer.Option(None, "--group-column", help="Metadata column for per-group metrics; can be repeated."),
    gene_sets: Path | None = typer.Option(None, "--gene-sets", help="Optional YAML gene-set mapping for pathway recovery when predictions include pred_<gene> columns."),
    top_k_de: int = typer.Option(50, help="Top-k genes for differential-expression recovery when evaluating expression predictions."),
):
    out.mkdir(parents=True, exist_ok=True)
    tables = out / "tables"
    tables.mkdir(exist_ok=True)
    cfg = load_config(config)
    adata = apply_schema(ad.read_h5ad(data), cfg.schema, cfg.controls.get("labels"))
    gene_set_map = None
    if gene_sets is not None:
        raw_gene_sets = yaml.safe_load(gene_sets.read_text(encoding="utf-8")) or {}
        gene_set_map = {str(name): list(genes) for name, genes in raw_gene_sets.items()}
    sections = evaluate_predictions(
        adata,
        pd.read_csv(predictions),
        group_columns=group_column or None,
        gene_sets=gene_set_map,
        top_k_de=top_k_de,
    )
    for name, df in sections.items():
        df.to_csv(tables / f"{name}.csv", index=False)
    write_html_report(out / "report.html", sections)
    summary = build_summary(sections)
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    typer.echo(f"Wrote model evaluation to {out}")


@app.command(help="Write a normalized AnnData file with canonical metadata and repaired duplicate IDs.")
def repair(
    data: Path = typer.Option(..., help="Input .h5ad file."),
    out: Path = typer.Option(..., help="Output repaired .h5ad path."),
    config: Path | None = typer.Option(None, help="Optional YAML schema/control mapping."),
):
    out.parent.mkdir(parents=True, exist_ok=True)
    cfg = load_config(config)
    fixed, actions = repair_anndata(
        ad.read_h5ad(data),
        schema=cfg.schema,
        control_labels=cfg.controls.get("labels"),
    )
    fixed.write_h5ad(out)
    actions_path = out.with_suffix(".repair_actions.csv")
    actions.to_csv(actions_path, index=False)
    typer.echo(f"Wrote repaired AnnData to {out}")
    typer.echo(f"Wrote repair actions to {actions_path}")


@app.command(name="infer-config", help="Infer a starter YAML config from common AnnData obs column aliases.")
def infer_config_cmd(
    data: Path = typer.Option(..., help="Input .h5ad file."),
    out: Path = typer.Option(..., help="Output YAML config path."),
):
    out.parent.mkdir(parents=True, exist_ok=True)
    config = infer_config(ad.read_h5ad(data, backed="r"))
    out.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    typer.echo(f"Wrote inferred config to {out}")


@app.command(name="target-map", help="Audit target annotations for genes, drug classes, pathways/classes, and unmapped targets.")
def target_map_cmd(
    data: Path = typer.Option(..., help="Input .h5ad file."),
    out: Path = typer.Option(..., help="Output report directory."),
    config: Path | None = typer.Option(None, help="Optional YAML schema/control mapping."),
    mapping: Path | None = typer.Option(None, help="Optional CSV with perturbation,target,target_type,source."),
):
    out.mkdir(parents=True, exist_ok=True)
    cfg = load_config(config)
    target_map = pd.read_csv(mapping) if mapping else None
    result = audit_target_mapping(
        apply_schema(ad.read_h5ad(data), cfg.schema, cfg.controls.get("labels")),
        target_map,
    )
    result.to_csv(out / "target_mapping.csv", index=False)
    write_html_report(out / "report.html", {"target_mapping": result})
    typer.echo(f"Wrote target mapping audit to {out}")


@app.command(name="compare-datasets", help="Compare high-level composition across multiple AnnData files.")
def compare_datasets_cmd(
    data: list[Path] = typer.Option(..., help="Input .h5ad file; can be repeated."),
    out: Path = typer.Option(..., help="Output report directory."),
):
    out.mkdir(parents=True, exist_ok=True)
    datasets = {path.stem: ad.read_h5ad(path) for path in data}
    result = compare_datasets(datasets)
    result.to_csv(out / "dataset_comparison.csv", index=False)
    write_html_report(out / "report.html", {"dataset_comparison": result})
    typer.echo(f"Wrote dataset comparison to {out}")


@app.command(name="design-check", help="Check a planned experiment design table for controls and cell-count support.")
def design_check_cmd(
    design: Path = typer.Option(..., help="Input design CSV, TSV, or YAML."),
    out: Path = typer.Option(..., help="Output report directory."),
):
    out.mkdir(parents=True, exist_ok=True)
    if design.suffix.lower() in {".yaml", ".yml"}:
        raw = load_config(design).raw
        table = pd.DataFrame(raw.get("design", raw if isinstance(raw, list) else []))
    else:
        table = pd.read_csv(design, sep="\t" if design.suffix.lower() == ".tsv" else ",")
    result = check_design(table)
    result.to_csv(out / "design_validation.csv", index=False)
    write_html_report(out / "report.html", {"design_validation": result})
    typer.echo(f"Wrote design report to {out}")


@app.command(name="power-check", help="Check planned cells, controls, replicate support, and batch support.")
def power_check_cmd(
    design: Path = typer.Option(..., help="Input design CSV, TSV, or YAML."),
    out: Path = typer.Option(..., help="Output report directory."),
):
    out.mkdir(parents=True, exist_ok=True)
    if design.suffix.lower() in {".yaml", ".yml"}:
        raw = load_config(design).raw
        table = pd.DataFrame(raw.get("design", raw if isinstance(raw, list) else []))
    else:
        table = pd.read_csv(design, sep="\t" if design.suffix.lower() == ".tsv" else ",")
    result = check_power(table)
    result.to_csv(out / "power_validation.csv", index=False)
    write_html_report(out / "report.html", {"power_validation": result})
    typer.echo(f"Wrote power report to {out}")


@app.command(name="benchmark-check", help="Validate a benchmark manifest and verify its declared split/claim.")
def benchmark_check_cmd(
    manifest: Path = typer.Option(..., help="Benchmark YAML manifest."),
    out: Path = typer.Option(..., help="Output report directory."),
):
    out.mkdir(parents=True, exist_ok=True)
    result = check_benchmark_manifest(manifest)
    result.to_csv(out / "benchmark_validation.csv", index=False)
    write_html_report(out / "report.html", {"benchmark_validation": result})
    typer.echo(f"Wrote benchmark validation to {out}")


def _run_expected_findings_command(
    manifest: Path = typer.Option(..., help="YAML manifest with cases and expected_findings CSV."),
    out: Path = typer.Option(..., help="Output report directory."),
    fail_on_mismatch: bool = typer.Option(False, help="Exit nonzero if any expected finding is missed."),
):
    out.mkdir(parents=True, exist_ok=True)
    result = run_validation_benchmark(manifest)
    result.to_csv(out / "validation_results.csv", index=False)
    write_html_report(out / "report.html", {"validation_results": result})
    typer.echo(result.to_string(index=False))
    typer.echo(f"Wrote expected-findings check to {out}")
    if fail_on_mismatch and result["status"].eq("FAIL").any():
        raise typer.Exit(1)


@app.command(name="expected-findings", help="Compare audit outputs with curated expected findings.")
def expected_findings_cmd(
    manifest: Path = typer.Option(..., help="YAML manifest with cases and expected_findings CSV."),
    out: Path = typer.Option(..., help="Output report directory."),
    fail_on_mismatch: bool = typer.Option(False, help="Exit nonzero if any expected finding is missed."),
):
    _run_expected_findings_command(manifest, out, fail_on_mismatch)


@app.command(name="validation-benchmark", help="Deprecated alias for expected-findings.")
def validation_benchmark_cmd(
    manifest: Path = typer.Option(..., help="YAML manifest with cases and expected_findings CSV."),
    out: Path = typer.Option(..., help="Output report directory."),
    fail_on_mismatch: bool = typer.Option(False, help="Exit nonzero if any expected finding is missed."),
):
    _run_expected_findings_command(manifest, out, fail_on_mismatch)


@app.command(name="profile-large", help="Open a large .h5ad in backed mode and report shape/storage metadata.")
def profile_large_cmd(
    data: Path = typer.Option(..., help="Input .h5ad file."),
    out: Path = typer.Option(..., help="Output report directory."),
):
    out.mkdir(parents=True, exist_ok=True)
    result = profile_h5ad(data)
    result.to_csv(out / "large_profile.csv", index=False)
    write_html_report(out / "report.html", {"large_profile": result})
    typer.echo(f"Wrote large-file profile to {out}")


@app.command(name="adversarial-check", help="Run shortcut/leakage probes such as metadata-only perturbation prediction.")
def adversarial_check_cmd(
    data: Path = typer.Option(..., help="Input .h5ad file."),
    out: Path = typer.Option(..., help="Output report directory."),
    config: Path | None = typer.Option(None, help="Optional YAML schema/control mapping."),
    split: Path | None = typer.Option(None, help="Optional split CSV for split-label dominance checks."),
):
    out.mkdir(parents=True, exist_ok=True)
    cfg = load_config(config)
    split_df = load_split(split) if split else None
    result = run_adversarial_checks(
        apply_schema(ad.read_h5ad(data), cfg.schema, cfg.controls.get("labels")),
        split_df,
    )
    result.to_csv(out / "adversarial_checks.csv", index=False)
    write_html_report(out / "report.html", {"adversarial_checks": result})
    typer.echo(f"Wrote adversarial checks to {out}")


@app.command(name="dataset-card", help="Write a Markdown dataset card summarizing audit status, uses, and limitations.")
def dataset_card_cmd(
    data: Path = typer.Option(..., help="Input .h5ad file."),
    out: Path = typer.Option(..., help="Output Markdown path."),
    config: Path | None = typer.Option(None, help="Optional YAML schema/control mapping."),
    name: str | None = typer.Option(None, help="Dataset name to show in the card."),
):
    out.parent.mkdir(parents=True, exist_ok=True)
    sections = _audit_sections(data, config)
    cfg = load_config(config)
    adata = apply_schema(ad.read_h5ad(data), cfg.schema, cfg.controls.get("labels"))
    card = build_dataset_card(adata, sections, dataset_name=name or data.stem)
    out.write_text(card, encoding="utf-8")
    typer.echo(f"Wrote dataset card to {out}")
