# src/workpeg/run.py
import subprocess
from pathlib import Path

from workpeg.build import build_image
from workpeg.config import load_config


def resolve_runtime(with_runtime: str | None, config: dict) -> str:
    if with_runtime:
        return with_runtime
    return config.get("runtime", {}).get("default") or "cracker"


def run_with_docker(
    path: str = ".",
    build_first: bool = True,
    network: str | None = None,
    expose: bool = True,
    name: str | None = None,
) -> None:
    project_path = Path(path).resolve()
    cfg = load_config(project_path / "workpeg.json")
    port = cfg.get("runtime", {}).get("docker", {}).get("port", 8000)

    image = build_image(path) if build_first else (
        cfg.get("build", {}).get("image") or project_path.name
    )

    cmd = ["docker", "run", "--rm"]

    if name:
        cmd += ["--name", name]

    if expose:
        cmd += ["-p", f"{port}:{port}"]

    if network:
        cmd += ["--network", network]

    cmd.append(image)

    subprocess.run(cmd, check=True)


def run_with_cracker(path: str = ".") -> None:
    raise NotImplementedError("Cracker runtime is not implemented yet.")


def main(argv=None) -> None:
    import argparse

    parser = argparse.ArgumentParser(prog="workpeg run")
    parser.add_argument("--with", dest="with_runtime", choices=["docker", "cracker"])
    parser.add_argument("--path", default=".")
    parser.add_argument("--no-build", action="store_true")
    parser.add_argument("--network", default=None)
    args = parser.parse_args(argv or [])

    cfg = load_config(Path(args.path) / "workpeg.json")
    runtime = resolve_runtime(args.with_runtime, cfg)

    if runtime == "docker":
        run_with_docker(
            path=args.path,
            build_first=not args.no_build,
            network=args.network,
        )
        return

    if runtime == "cracker":
        run_with_cracker(path=args.path)
        return

    raise ValueError(f"Unsupported runtime: {runtime}")
