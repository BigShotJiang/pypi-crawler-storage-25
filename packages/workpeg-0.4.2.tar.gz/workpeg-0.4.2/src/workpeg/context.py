import re


UUID_REGEX = re.compile(
    r"^[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-"
    r"[89ab][a-f0-9]{3}-[a-f0-9]{12}$",
    re.IGNORECASE,
)


class BaseContext:
    @staticmethod
    def verify(data):
        raise NotImplementedError("Context must implement verify().")


class _TableContext(BaseContext):
    REQUIRED_FIELDS = {
        "uuid",
        "name",
        "owner_id",
        "metadata",
        "columns",
        "namespace",
        "peg",
    }

    @classmethod
    def verify(cls, data):
        if data is None:
            return True

        cls._verify_keys(data)
        cls._verify_uuid_format(data["uuid"])
        cls._verify_owner_id(data["owner_id"])
        cls._verify_columns(data["columns"])
        cls._verify_namespace(data["namespace"])
        cls._verify_peg(data["peg"])

        return True

    @classmethod
    def _verify_keys(cls, data):
        if not isinstance(data, dict):
            raise ValueError("Data must be a dictionary.")

        missing = cls.REQUIRED_FIELDS - data.keys()
        if missing:
            raise ValueError(f"Missing required fields: {missing}")

    @classmethod
    def _verify_uuid_format(cls, uuid_str):
        if not isinstance(uuid_str, str) or not UUID_REGEX.match(uuid_str):
            raise ValueError("Invalid UUID format.")

    @classmethod
    def _verify_owner_id(cls, owner_id):
        if owner_id is not None and (
            not isinstance(owner_id, int) or owner_id <= 0
        ):
            raise ValueError("Owner ID must be a positive integer or None.")

    @classmethod
    def _verify_columns(cls, columns):
        return True  # TODO

    @classmethod
    def _verify_namespace(cls, namespace):
        if namespace is not None and not isinstance(namespace, str):
            raise ValueError("Namespace must be a non-empty string.")

    @classmethod
    def _verify_peg(cls, peg):
        return True  # TODO


class _StaffContext(BaseContext):
    @staticmethod
    def verify(data):
        if data is None:
            return True

        if not isinstance(data, dict):
            raise ValueError("Staff context must be a dictionary.")

        if "email" not in data:
            raise ValueError("Missing required field: 'email'")

        return True


class _MetadataContext(BaseContext):
    @staticmethod
    def verify(data):
        return True


class ContextBuilder:
    registry = {}

    def __init__(self):
        self.context = {}

    @classmethod
    def register(cls, key, handler_class):
        cls.registry[key] = handler_class

    def add(self, key, serialized_data):
        handler = self.registry.get(key)

        if handler is None:
            raise ValueError(f"{key} rejected: no handler registered")

        verify_method = getattr(handler, "verify", None)

        if not callable(verify_method):
            raise ValueError(f"{key} rejected: 'verify' not implemented")

        try:
            if not verify_method(serialized_data):
                raise ValueError(f"{key} rejected: verification failed")
        except Exception as e:
            raise ValueError(f"{key} rejected: verification error - {str(e)}")

        self.context[key] = serialized_data
        return self

    def build(self):
        return self.context


ContextBuilder.register("table", _TableContext)
ContextBuilder.register("staff", _StaffContext)
ContextBuilder.register("metadata", _MetadataContext)
