import pytest
from unittest.mock import patch
from uuid import uuid4

from workpeg.context import (
    ContextBuilder,
    _TableContext, _StaffContext, _MetadataContext
)


@pytest.fixture
def valid_table_data():
    return {
        "uuid": str(uuid4()),
        "name": "Employees",
        "owner_id": 1,
        "metadata": {},
        "columns": [],
        "namespace": "workpeg.hr",
        "peg": 10,
    }


class TestTableContext:

    def test_verify_table_returns_true_for_valid_data(self, valid_table_data):
        assert _TableContext.verify(valid_table_data) is True

    def test_verify_table_returns_true_when_owner_id_is_none(
        self,
        valid_table_data,
    ):
        valid_table_data["owner_id"] = None

        assert _TableContext.verify(valid_table_data) is True

    def test_verify_table_raises_when_required_key_is_missing(
        self,
        valid_table_data,
    ):
        del valid_table_data["uuid"]

        with pytest.raises(ValueError, match="Missing required fields"):
            _TableContext.verify(valid_table_data)

    def test_verify_table_raises_for_invalid_uuid(self, valid_table_data):
        valid_table_data["uuid"] = "bad-uuid"

        with pytest.raises(ValueError, match="Invalid UUID format."):
            _TableContext.verify(valid_table_data)

    def test_verify_table_raises_for_invalid_owner_id(self, valid_table_data):
        valid_table_data["owner_id"] = 0

        with pytest.raises(
            ValueError,
            match="Owner ID must be a positive integer or None.",
        ):
            _TableContext.verify(valid_table_data)

    def test_verify_table_raises_for_invalid_namespace(self, valid_table_data):
        valid_table_data["namespace"] = {}

        with pytest.raises(
            ValueError,
            match="Namespace must be a non-empty string.",
        ):
            _TableContext.verify(valid_table_data)

    def test_verify_keys_accepts_extra_fields(self, valid_table_data):
        valid_table_data["extra"] = "allowed"

        assert _TableContext._verify_keys(valid_table_data) is None

    def test_verify_uuid_format_accepts_valid_uuid(self):
        assert _TableContext._verify_uuid_format(str(uuid4())) is None

    def test_verify_uuid_format_raises_for_invalid_uuid(self):
        with pytest.raises(ValueError, match="Invalid UUID format."):
            _TableContext._verify_uuid_format("123")


class TestContextBuilder:

    def test_adds_valid_table_context(self, valid_table_data):
        builder = ContextBuilder()
        builder.register("table", _TableContext)

        context = builder.add("table", valid_table_data).build()

        assert context["table"] == valid_table_data

    def test_add_returns_self_for_chaining(self, valid_table_data):
        builder = ContextBuilder()
        builder.register("table", _TableContext)

        result = builder.add("table", valid_table_data)

        assert result is builder

    def test_rejects_unregistered_context_key(self, valid_table_data):
        builder = ContextBuilder()

        with pytest.raises(
            ValueError,
            match="unknown rejected: no handler registered",
        ):
            builder.add("unknown", valid_table_data)

    def test_rejects_handler_without_verify_method(self, valid_table_data):
        class BadTableContext:
            pass

        builder = ContextBuilder()
        builder.register("something", BadTableContext)

        with pytest.raises(
            ValueError,
            match="something rejected: 'verify' not implemented",
        ):
            builder.add("something", valid_table_data)

    def test_rejects_invalid_table_context_with_exact_reason(
        self,
        valid_table_data,
    ):
        builder = ContextBuilder()
        builder.register("table", _TableContext)

        valid_table_data["uuid"] = "bad-uuid"

        with pytest.raises(
            ValueError,
            match="table rejected: verification error - Invalid UUID format.",
        ):
            builder.add("table", valid_table_data)

    def test_uses_verify_table_method(self, valid_table_data):
        builder = ContextBuilder()
        builder.register("table", _TableContext)

        with patch.object(_TableContext, "verify", return_value=True) as mock_verify:
            builder.add("table", valid_table_data)

        mock_verify.assert_called_once_with(valid_table_data)


class TestStaffContext:

    def test_verify_staff_allows_none(self):
        assert _StaffContext.verify(None) is True

    def test_verify_staff_accepts_valid_data(self):
        data = {"email": "test@example.com"}

        assert _StaffContext.verify(data) is True

    def test_verify_staff_rejects_non_dict(self):
        with pytest.raises(
            ValueError,
            match="Staff context must be a dictionary.",
        ):
            _StaffContext.verify("not-a-dict")

    def test_verify_staff_rejects_missing_email(self):
        with pytest.raises(
            ValueError,
            match="Missing required field: 'email'",
        ):
            _StaffContext.verify({})

    def test_verify_staff_allows_extra_fields(self):
        data = {
            "email": "test@example.com",
            "name": "John",
            "role": "admin",
        }

        assert _StaffContext.verify(data) is True


class TestMetadataContext:

    def test_verify_extra_accepts_none(self):
        assert _MetadataContext.verify(None) is True

    def test_verify_metadata_accepts_dict(self):
        assert _MetadataContext.verify({"foo": "bar"}) is True

    def test_verify_metadata_accepts_any_type(self):
        test_cases = [
            "string",
            123,
            12.5,
            [],
            (),
            object(),
        ]

        for case in test_cases:
            assert _MetadataContext.verify(case) is True
