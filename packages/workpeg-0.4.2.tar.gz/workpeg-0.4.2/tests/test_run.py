import pytest

from workpeg import run


def test_resolve_runtime_prefers_flag():
    cfg = {"runtime": {"default": "docker"}}
    assert run.resolve_runtime("cracker", cfg) == "cracker"


def test_resolve_runtime_uses_config():
    cfg = {"runtime": {"default": "docker"}}
    assert run.resolve_runtime(None, cfg) == "docker"


def test_resolve_runtime_falls_back_to_cracker():
    assert run.resolve_runtime(None, {}) == "cracker"


def test_run_with_cracker_not_implemented():
    with pytest.raises(NotImplementedError):
        run.run_with_cracker(".")


def test_run_with_docker_builds_first(monkeypatch, tmp_path):
    project = tmp_path / "demo"
    project.mkdir()
    (project / "workpeg.json").write_text(
        '{"runtime": {"docker": {"port": 9000}}}'
    )

    monkeypatch.setattr(run, "build_image", lambda path: "built-image")

    calls = []

    def fake_run(cmd, check):
        calls.append((cmd, check))

    monkeypatch.setattr(run.subprocess, "run", fake_run)

    run.run_with_docker(path=str(project), build_first=True, network="workpeg_net")

    assert len(calls) == 1
    cmd, check = calls[0]
    assert cmd == [
        "docker", "run", "--rm",
        "-p", "9000:9000",
        "--network", "workpeg_net",
        "built-image",
    ]
    assert check is True


def test_run_with_docker_no_build(monkeypatch, tmp_path):
    project = tmp_path / "demo"
    project.mkdir()
    (project / "workpeg.json").write_text(
        '{"build": {"image": "configured-image"}, "runtime": {"docker": {"port": 8000}}}'
    )

    calls = []

    def fake_run(cmd, check):
        calls.append((cmd, check))

    monkeypatch.setattr(run.subprocess, "run", fake_run)

    run.run_with_docker(path=str(project), build_first=False, network="bridge")

    cmd, check = calls[0]
    assert cmd == [
        "docker", "run", "--rm",
        "-p", "8000:8000",
        "--network", "bridge",
        "configured-image",
    ]
    assert check is True


def test_run_main_with_docker(monkeypatch):
    called = {}

    def fake_run_with_docker(path=".", build_first=True, network=None):
        called["path"] = path
        called["build_first"] = build_first
        called["network"] = network

    monkeypatch.setattr(run, "run_with_docker", fake_run_with_docker)

    run.main(["--with", "docker", "--path", "/tmp/demo", "--no-build"])

    assert called == {
        "path": "/tmp/demo",
        "build_first": False,
        "network": None,
    }


def test_run_main_with_cracker(monkeypatch):
    called = {}

    def fake_run_with_cracker(path="."):
        called["path"] = path

    monkeypatch.setattr(run, "run_with_cracker", fake_run_with_cracker)

    run.main(["--with", "cracker", "--path", "/tmp/demo"])

    assert called == {"path": "/tmp/demo"}


def test_run_main_uses_config_default(monkeypatch, tmp_path):
    project = tmp_path / "demo"
    project.mkdir()
    (project / "workpeg.json").write_text(
        '{"runtime": {"default": "docker"}}'
    )

    called = {}

    def fake_run_with_docker(path=".", build_first=True, network=None):
        called["path"] = path
        called["build_first"] = build_first
        called["network"] = network

    monkeypatch.setattr(run, "run_with_docker", fake_run_with_docker)

    run.main(["--path", str(project)])

    assert called == {
        "path": str(project),
        "build_first": True,
        "network": None,
    }


def test_run_main_with_docker_and_network(monkeypatch):
    called = {}

    def fake_run_with_docker(path=".", build_first=True, network=None):
        called["path"] = path
        called["build_first"] = build_first
        called["network"] = network

    monkeypatch.setattr(run, "run_with_docker", fake_run_with_docker)

    run.main([
        "--with", "docker",
        "--path", "/tmp/demo",
        "--network", "workpeg_net",
    ])

    assert called == {
        "path": "/tmp/demo",
        "build_first": True,
        "network": "workpeg_net",
    }


def test_run_with_docker_no_expose(monkeypatch, tmp_path):
    project = tmp_path / "demo"
    project.mkdir()
    (project / "workpeg.json").write_text(
        '{"runtime": {"docker": {"port": 9000}}}'
    )

    calls = []

    def fake_run(cmd, check):
        calls.append((cmd, check))

    monkeypatch.setattr(run.subprocess, "run", fake_run)

    run.run_with_docker(path=str(project), build_first=False, expose=False)

    assert len(calls) == 1
    cmd, check = calls[0]
    assert cmd == [
        "docker", "run", "--rm",
        "demo",
    ]
    assert check is True


def test_run_with_docker_expose(monkeypatch, tmp_path):
    project = tmp_path / "demo"
    project.mkdir()
    (project / "workpeg.json").write_text(
        '{"runtime": {"docker": {"port": 9000}}}'
    )

    calls = []

    def fake_run(cmd, check):
        calls.append((cmd, check))

    monkeypatch.setattr(run.subprocess, "run", fake_run)

    run.run_with_docker(path=str(project), build_first=False, expose=True)

    cmd, check = calls[0]
    assert cmd == [
        "docker", "run", "--rm",
        "-p", "9000:9000",
        "demo",
    ]
    assert check is True


def test_run_with_docker_with_name(monkeypatch, tmp_path):
    project = tmp_path / "demo"
    project.mkdir()
    (project / "workpeg.json").write_text(
        '{"runtime": {"docker": {"port": 8000}}}'
    )

    calls = []

    def fake_run(cmd, check):
        calls.append((cmd, check))

    monkeypatch.setattr(run.subprocess, "run", fake_run)

    run.run_with_docker(
        path=str(project),
        build_first=False,
        expose=False,
        name="foo",
    )

    assert len(calls) == 1
    cmd, check = calls[0]

    assert cmd == [
        "docker", "run", "--rm",
        "--name", "foo",
        "demo",
    ]
    assert check is True


def test_run_with_docker_name_and_network(monkeypatch, tmp_path):
    project = tmp_path / "demo"
    project.mkdir()
    (project / "workpeg.json").write_text(
        '{"runtime": {"docker": {"port": 8000}}}'
    )

    calls = []

    def fake_run(cmd, check):
        calls.append((cmd, check))

    monkeypatch.setattr(run.subprocess, "run", fake_run)

    run.run_with_docker(
        path=str(project),
        build_first=False,
        expose=False,
        name="foo",
        network="workpeg_net",
    )

    cmd, check = calls[0]

    assert cmd == [
        "docker", "run", "--rm",
        "--name", "foo",
        "--network", "workpeg_net",
        "demo",
    ]
    assert check is True
