"""On-disk state for the runner.

Persisted to ``.sota-runner-state.json`` in the working directory by
default. Atomic write (write to .tmp, then os.replace) so a crash
mid-write can't leave a half-written file.

Stored fields:
    - idempotency_keys: dict[str, str] — per-(job_id, kind) UUIDs
    - last_heartbeat_at: ISO-8601 timestamp of last successful heartbeat

Anything else can be written via read()/write() — the runner doesn't
enforce a schema, but downstream code should read defensively.

A corrupt file is silently replaced with an empty dict on next write.
That's the right call here: state is auxiliary, not authoritative.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_STATE_FILE = ".sota-runner-state.json"


class State:
    """Atomic JSON-backed key-value store."""

    def __init__(self, path: str | os.PathLike[str] | None = None) -> None:
        self.path = Path(path or DEFAULT_STATE_FILE)

    def read(self) -> dict[str, Any]:
        """Read the state file, return {} if missing or corrupt."""
        if not self.path.exists():
            return {}
        try:
            with self.path.open("r", encoding="utf-8") as f:
                data = json.load(f)
                if not isinstance(data, dict):
                    logger.warning(
                        "%s: not a dict, ignoring (got %s)",
                        self.path, type(data).__name__,
                    )
                    return {}
                return data
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("%s: corrupt or unreadable (%s); resetting", self.path, e)
            return {}

    def write(self, data: dict[str, Any]) -> None:
        """Atomic write: serialize to .tmp, then os.replace.

        os.replace is atomic on POSIX and on Windows for files in the
        same directory. We use the same directory as the target so the
        guarantee holds.
        """
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        try:
            with tmp.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, sort_keys=True)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
        except OSError as e:
            logger.error("failed to write %s: %s", self.path, e)
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass

    def update(self, **kwargs: Any) -> None:
        """Convenience: read, merge, write."""
        data = self.read()
        data.update(kwargs)
        self.write(data)


__all__ = ["State", "DEFAULT_STATE_FILE"]
