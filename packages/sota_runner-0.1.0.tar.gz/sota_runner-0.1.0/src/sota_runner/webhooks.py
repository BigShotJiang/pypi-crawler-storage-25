"""Webhook signature verification + optional HTTP listener.

The signature scheme is HMAC-SHA256 over the **raw request bytes**, hex-encoded,
sent in the `X-SOTA-Signature` header. The classic footgun — re-serializing
the JSON body and signing the new bytes — is solved here by always operating
on bytes from the wire.

Use cases:
    1. Verifier-only (no HTTP server): import `verify_signature` and call it
       from your existing FastAPI/Flask/etc. handler. Zero deps.
    2. Built-in listener: pass `--webhook-port 8080` to `sota-runner run` and
       a tiny aiohttp server is started. Requires `pip install sota-runner[webhooks]`.

The listener writes verified events to a queue you can consume from
``Runner._on_event``, but in v0.1 it just logs — webhook-driven dispatch is
v3 work.
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import os
from typing import Callable

logger = logging.getLogger(__name__)

SIGNATURE_HEADER = "X-SOTA-Signature"


def verify_signature(raw_body: bytes, signature: str, secret: str) -> bool:
    """Verify an inbound webhook signature.

    Args:
        raw_body: bytes from the wire — DO NOT re-serialize the JSON.
        signature: value of `X-SOTA-Signature` header (hex-encoded HMAC-SHA256).
        secret: the agent's webhook secret (returned at registration as
            `webhook_secret`, also available as `SOTA_WEBHOOK_SECRET` env).

    Returns:
        True if the signature matches, False otherwise. Constant-time compare.
    """
    if not raw_body or not signature or not secret:
        return False
    expected = hmac.new(
        secret.encode("utf-8"),
        raw_body,
        hashlib.sha256,
    ).hexdigest()
    # hmac.compare_digest is constant-time (within accuracy of input length).
    return hmac.compare_digest(expected, signature)


class WebhookServer:
    """Optional aiohttp server that verifies inbound webhooks.

    Lazy-imports aiohttp so a runner installed without the [webhooks] extra
    can still poll without aiohttp present.
    """

    def __init__(
        self,
        port: int,
        secret: str | None = None,
        on_event: Callable[[str, dict], None] | None = None,
    ) -> None:
        self.port = port
        self.secret = secret or os.environ.get("SOTA_WEBHOOK_SECRET", "")
        if not self.secret:
            raise RuntimeError(
                "SOTA_WEBHOOK_SECRET required for --webhook-port. "
                "Get it from POST /api/v1/agents/register/simple response."
            )
        self.on_event = on_event or (lambda event_type, body: None)

    async def run(self, stop) -> None:  # type: ignore[no-untyped-def]
        import asyncio

        from aiohttp import web

        async def handler(request: "web.Request") -> "web.Response":
            raw = await request.read()
            sig = request.headers.get(SIGNATURE_HEADER, "")
            if not verify_signature(raw, sig, self.secret):
                return web.Response(status=401, text="invalid signature")
            try:
                import json as _json
                payload = _json.loads(raw)
            except Exception:  # noqa: BLE001
                return web.Response(status=400, text="invalid json")
            event_type = payload.get("event") or payload.get("type") or "unknown"
            try:
                self.on_event(event_type, payload)
            except Exception:  # noqa: BLE001
                logger.exception("on_event handler raised")
            return web.Response(status=200, text="ok")

        app = web.Application()
        app.router.add_post("/webhook", handler)
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", self.port)
        await site.start()
        logger.info("webhook server listening on :%s/webhook", self.port)
        try:
            await stop.wait()
        finally:
            await runner.cleanup()


__all__ = ["verify_signature", "WebhookServer", "SIGNATURE_HEADER"]
