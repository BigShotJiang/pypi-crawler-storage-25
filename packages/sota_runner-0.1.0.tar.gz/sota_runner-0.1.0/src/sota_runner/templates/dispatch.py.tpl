"""dispatch.py — your SOTA agent's handler.

This template wires every job through `sota-mcp` + an LLM (Claude or OpenAI)
so a fresh agent passes cluster probes with no hand-coding. Replace the
`call_llm` function with whatever model you want; the rest of the contract
is fixed.

Replace this entire file with deterministic Python if you have a non-LLM
worker (web scraping, ETL, OCR, etc.) — see
`sota-runner init --template det <name>` for that flavor.
"""
from __future__ import annotations

import json
import os
from typing import Any

# ---- Replace this with your LLM client of choice ---------------------------
# The default below uses Anthropic via the ANTHROPIC_API_KEY env var. Swap
# to OpenAI / local Ollama / anything that returns text.
def call_llm(prompt: str) -> str:
    """Return the model's text response. Must be JSON-parseable when the
    job has an `expected_schema`."""
    try:
        from anthropic import Anthropic
    except ImportError as e:
        raise RuntimeError(
            "Install: pip install anthropic   (or wire your own LLM here)"
        ) from e

    client = Anthropic()
    msg = client.messages.create(
        model=os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6"),
        max_tokens=4096,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(
        block.text for block in msg.content if getattr(block, "type", "") == "text"
    )


# ---- Prompt template -------------------------------------------------------
PROMPT = """You are {{AGENT_NAME}}, a SOTA marketplace agent.

JOB DESCRIPTION:
{description}

INPUT PARAMETERS (JSON):
{parameters}

EXPECTED OUTPUT SCHEMA (JSON Schema):
{expected_schema}

Generate JSON that conforms to the schema EXACTLY. Return only the JSON,
no markdown fences, no commentary. Required fields must be present.
"""


def dispatch(job: dict[str, Any]) -> dict[str, Any]:
    """Called by sota-runner for every test_job (sandbox) and job (active).

    Args:
        job: the row from GET /api/v1/agents/jobs. Always has `id`,
            `description`, `parameters`. Test jobs additionally have
            `expected_schema`. Active jobs have `tags`, `budget_usdc`, etc.

    Returns:
        {"result": "<JSON string or text>"}            success
        {"error_code": "timeout", "retryable": True}   active-mode error
        {"skip": True}                                 don't deliver
    """
    description = job.get("description", "")
    parameters = job.get("parameters") or {}
    expected_schema = job.get("expected_schema") or {}

    prompt = PROMPT.format(
        description=description,
        parameters=json.dumps(parameters, indent=2),
        expected_schema=json.dumps(expected_schema, indent=2),
    )

    text = call_llm(prompt).strip()
    # Strip accidental markdown fences.
    if text.startswith("```"):
        text = text.split("```", 2)[1]
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()

    # Validate it parses (the server validates the SCHEMA, but we catch
    # malformed JSON before sending so the runner's 422 retry budget
    # doesn't burn on parser failures).
    try:
        json.loads(text)
    except json.JSONDecodeError as e:
        return {
            "error_code": "invalid_input",
            "error_message": f"LLM returned non-JSON: {e}",
            "retryable": True,
        }

    return {"result": text}


if __name__ == "__main__":
    # Local smoke test: run with `python dispatch.py` to dispatch a fake job.
    sample = {
        "id": "smoke-test",
        "description": "Return {\"hello\": \"world\"}",
        "parameters": {},
        "expected_schema": {
            "type": "object",
            "required": ["hello"],
            "properties": {"hello": {"type": "string"}},
        },
    }
    print(dispatch(sample))
