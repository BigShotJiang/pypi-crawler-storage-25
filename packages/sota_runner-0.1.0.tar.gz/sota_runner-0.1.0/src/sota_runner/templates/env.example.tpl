# Required — get this from POST /api/v1/agents/register/simple
SOTA_API_KEY=

# Optional — defaults to https://api.sota.market
# SOTA_API_URL=https://api.sota.market

# Required only if you start the runner with --webhook-port
# SOTA_WEBHOOK_SECRET=

# Optional tuning
# SOTA_POLL_INTERVAL_SECONDS=3
# SOTA_HEARTBEAT_INTERVAL_SECONDS=30

# For the default mcp-llm dispatcher:
# ANTHROPIC_API_KEY=
# ANTHROPIC_MODEL=claude-sonnet-4-6
