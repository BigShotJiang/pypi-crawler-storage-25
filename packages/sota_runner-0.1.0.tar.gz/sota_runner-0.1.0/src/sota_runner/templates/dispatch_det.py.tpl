"""dispatch.py — deterministic SOTA agent handler.

For workers where running an LLM in the loop is wasteful: scrapers, ETL,
OCR, calculation, file conversion. The LLM-driven template (the default)
is in `sota-runner init --template mcp-llm`.

Pattern:
    HANDLERS = {"<tag-slug>": handler_function, ...}
    Anything not in HANDLERS falls through to `_default`, which uses
    `schema_skeleton` to walk `expected_schema` and emit a minimum
    conformant payload — passes most cluster probes with no edits.

Replace the example handlers with your real logic. Drop {{AGENT_NAME}}
into a Docker container and you're done.
"""
from __future__ import annotations

import json
from typing import Any, Callable


# ---- Per-tag handlers ------------------------------------------------------
# Each handler receives the full `job` dict and returns a JSON-serializable
# result dict (or string). Add one entry per tag you registered for.

def handle_web_scraping(job: dict[str, Any]) -> dict[str, Any]:
    """Replace with real scraping. Example just echoes the URL."""
    url = (job.get("parameters") or {}).get("url", "")
    return {"url": url, "title": "TODO: scrape this", "content": "TODO"}


def handle_data_extraction(job: dict[str, Any]) -> dict[str, Any]:
    """Replace with real extraction logic."""
    return {"records": []}


HANDLERS: dict[str, Callable[[dict[str, Any]], Any]] = {
    "web-scraping": handle_web_scraping,
    "data-extraction": handle_data_extraction,
    # Add more here as you register for more tags.
}


# ---- Schema-introspecting fallback -----------------------------------------
# Walks `expected_schema` and produces a minimum conformant payload. Ported
# from sota-sdk so the runner template is self-contained.

def _schema_skeleton(schema: Any) -> Any:
    """Return a minimal value that conforms to the JSON Schema."""
    if not isinstance(schema, dict):
        return None
    typ = schema.get("type")
    if typ == "object":
        out: dict[str, Any] = {}
        props = schema.get("properties", {}) or {}
        for key in (schema.get("required") or []):
            out[key] = _schema_skeleton(props.get(key, {}))
        return out
    if typ == "array":
        item_schema = schema.get("items", {})
        min_items = int(schema.get("minItems") or 0)
        return [_schema_skeleton(item_schema) for _ in range(max(min_items, 1))]
    if typ == "string":
        return schema.get("default", "ok")
    if typ == "integer" or typ == "number":
        return schema.get("default", 0)
    if typ == "boolean":
        return schema.get("default", False)
    if typ == "null":
        return None
    # `enum` without a type
    if isinstance(schema.get("enum"), list) and schema["enum"]:
        return schema["enum"][0]
    return None


def _default(job: dict[str, Any]) -> dict[str, Any]:
    """Schema-introspecting fallback. Passes cluster probes with no edits."""
    schema = job.get("expected_schema") or {}
    skeleton = _schema_skeleton(schema)
    return skeleton if isinstance(skeleton, dict) else {"value": skeleton}


# ---- Entry point -----------------------------------------------------------

def dispatch(job: dict[str, Any]) -> dict[str, Any]:
    """Called by sota-runner for every job. Returns {result: ...} or
    {error_code: ..., retryable: ...}."""
    capability = job.get("capability") or ""
    handler = HANDLERS.get(capability, _default)
    try:
        out = handler(job)
    except Exception as e:  # noqa: BLE001
        return {
            "error_code": "internal_error",
            "error_message": f"{type(e).__name__}: {e}",
            "retryable": True,
        }
    if isinstance(out, dict):
        return {"result": json.dumps(out)}
    return {"result": str(out)}


if __name__ == "__main__":
    sample = {
        "id": "smoke-test",
        "capability": "web-scraping",
        "parameters": {"url": "https://example.com"},
        "expected_schema": {
            "type": "object",
            "required": ["url"],
            "properties": {"url": {"type": "string"}},
        },
    }
    print(dispatch(sample))
