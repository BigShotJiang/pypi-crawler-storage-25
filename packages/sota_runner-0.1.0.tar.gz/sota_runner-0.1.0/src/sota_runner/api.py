"""Thin httpx wrapper for the SOTA REST API.

This is NOT a featureful SDK client. It exists so other modules in the
runner don't repeat URL/header/auth boilerplate. If you need typed
responses, helper methods, or a retry framework, use ``sota-sdk``.
"""
from __future__ import annotations

import os
from typing import Any

import httpx

DEFAULT_API_URL = "https://api.sota.market"


class APIClient:
    """Synchronous httpx wrapper. One instance per Runner.

    Attributes:
        base_url: API root, including scheme. No trailing slash.
        api_key: agent's X-API-Key value.
        timeout: per-request timeout in seconds.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.api_key = api_key or os.environ.get("SOTA_API_KEY", "")
        if not self.api_key:
            raise RuntimeError(
                "SOTA_API_KEY is required. Set it in .env or pass api_key="
            )
        self.base_url = (base_url or os.environ.get("SOTA_API_URL", DEFAULT_API_URL)).rstrip("/")
        self.timeout = timeout
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers={"X-API-Key": self.api_key, "User-Agent": "sota-runner/0.1.0"},
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "APIClient":
        return self

    def __exit__(self, *exc_info: Any) -> None:
        self.close()

    # ---- HTTP primitives ----------------------------------------------------

    def get(self, path: str, **kwargs: Any) -> httpx.Response:
        return self._client.get(path, **kwargs)

    def post(
        self,
        path: str,
        *,
        json: Any = None,
        idempotency_key: str | None = None,
        **kwargs: Any,
    ) -> httpx.Response:
        headers = dict(kwargs.pop("headers", {}) or {})
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        return self._client.post(path, json=json, headers=headers, **kwargs)

    # ---- High-level helpers used by the loop --------------------------------

    def list_jobs(self) -> dict[str, Any]:
        """GET /api/v1/agents/jobs — sandbox or active jobs depending on
        agent status. Returns the parsed JSON body."""
        r = self.get("/api/v1/agents/jobs")
        r.raise_for_status()
        return r.json()

    def get_me(self) -> dict[str, Any]:
        r = self.get("/api/v1/agents/me")
        r.raise_for_status()
        return r.json()

    def get_sandbox_progress(self) -> dict[str, Any]:
        r = self.get("/api/v1/agents/me/sandbox-progress")
        r.raise_for_status()
        return r.json()

    def deliver_test_job(
        self,
        test_job_id: str,
        result: str,
        idempotency_key: str | None = None,
    ) -> tuple[int, dict[str, Any]]:
        """POST /api/v1/agents/test-jobs/{id}/deliver. Returns (status, body).
        200 = pass; 422 = schema violation (body has repair hints)."""
        r = self.post(
            f"/api/v1/agents/test-jobs/{test_job_id}/deliver",
            json={"result": result},
            idempotency_key=idempotency_key,
        )
        return r.status_code, r.json() if r.content else {}

    def deliver_job(
        self,
        job_id: str,
        result: str | None = None,
        *,
        result_hash: str | None = None,
        error_code: str | None = None,
        error_message: str | None = None,
        retryable: bool | None = None,
        idempotency_key: str | None = None,
    ) -> tuple[int, dict[str, Any]]:
        """POST /api/v1/agents/deliver — active-mode delivery."""
        body: dict[str, Any] = {"job_id": job_id}
        if result is not None:
            body["result"] = result
        if result_hash is not None:
            body["result_hash"] = result_hash
        if error_code is not None:
            body["error_code"] = error_code
        if error_message is not None:
            body["error_message"] = error_message
        if retryable is not None:
            body["retryable"] = retryable
        r = self.post(
            "/api/v1/agents/deliver",
            json=body,
            idempotency_key=idempotency_key,
        )
        return r.status_code, r.json() if r.content else {}

    def heartbeat(self) -> int:
        """POST /api/v1/agents/heartbeat. Returns HTTP status. Failures
        don't raise — the heartbeat loop swallows transient errors."""
        try:
            r = self.post("/api/v1/agents/heartbeat")
            return r.status_code
        except httpx.HTTPError:
            return 0

    def request_review(self) -> tuple[int, dict[str, Any]]:
        r = self.post("/api/v1/agents/request-review")
        return r.status_code, r.json() if r.content else {}


__all__ = ["APIClient", "DEFAULT_API_URL"]
