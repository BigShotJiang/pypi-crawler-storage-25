"""Idempotency-Key generation + retry-aware reuse.

Contract (matches packages/backend/src/services/idempotency_service.py from PR-8):

    1. Each (job_id, attempt_kind) gets ONE UUID for its lifetime.
    2. Same key + same body on retry → server replays cached response.
    3. Different body + same key → server returns 409 idempotency_key_mismatch.
       (Should never happen if you don't mutate the body between attempts.)
    4. Different job_id → fresh key.

We keep a small in-memory + on-disk dict keyed by (job_id, kind) so a
restart resumes with the same key. Without this, a restart mid-retry
would generate a fresh UUID and waste server-side cache.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field

from sota_runner.state import State


@dataclass
class KeyStore:
    """In-memory cache backed by State for persistence across restarts."""
    state: State
    _keys: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self._keys = dict(self.state.read().get("idempotency_keys", {}))

    def for_attempt(self, job_id: str, kind: str = "deliver") -> str:
        """Get-or-create the Idempotency-Key for this (job, kind) pair.

        ``kind`` distinguishes e.g. ``deliver`` from ``deliver_error`` from
        ``test_deliver`` so a job that goes from "happy delivery" to
        "error report" doesn't reuse a key with a now-different body.
        """
        cache_key = f"{job_id}:{kind}"
        if cache_key not in self._keys:
            self._keys[cache_key] = str(uuid.uuid4())
            self._persist()
        return self._keys[cache_key]

    def forget(self, job_id: str, kind: str = "deliver") -> None:
        """Drop a key after a terminal success — frees the cache slot."""
        cache_key = f"{job_id}:{kind}"
        if cache_key in self._keys:
            del self._keys[cache_key]
            self._persist()

    def _persist(self) -> None:
        snapshot = self.state.read()
        snapshot["idempotency_keys"] = dict(self._keys)
        self.state.write(snapshot)


__all__ = ["KeyStore"]
