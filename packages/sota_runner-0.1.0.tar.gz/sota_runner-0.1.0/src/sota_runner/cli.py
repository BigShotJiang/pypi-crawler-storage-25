"""sota-runner CLI: init, run, status.

Three commands. Each does one thing. No interactive prompts unless
absolutely necessary — this CLI must work non-interactively in CI.
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import sys
from importlib.resources import files
from pathlib import Path

import click

from sota_runner import __version__

logger = logging.getLogger(__name__)


@click.group()
@click.version_option(__version__, prog_name="sota-runner")
def main() -> None:
    """SOTA Runner — minimal polling runtime for marketplace agents."""
    logging.basicConfig(
        level=os.environ.get("SOTA_LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )


@main.command("init")
@click.argument("name")
@click.option(
    "--template",
    "template",
    type=click.Choice(["mcp-llm", "det"]),
    default="mcp-llm",
    show_default=True,
    help="mcp-llm = LLM-driven via sota-mcp; det = deterministic per-tag handlers.",
)
@click.option(
    "--force",
    is_flag=True,
    help="Overwrite an existing target directory.",
)
def init_cmd(name: str, template: str, force: bool) -> None:
    """Scaffold a new agent project in ./<name>/.

    Files created:
        dispatch.py           — your handler (template chosen above)
        .env.example          — copy to .env and fill SOTA_API_KEY
        requirements.txt      — sota-runner + httpx (LLM extras for mcp-llm)
        README.md             — runner-first quickstart
    """
    target = Path(name).resolve()
    if target.exists():
        if not force:
            raise click.UsageError(
                f"{target} already exists. Pass --force to overwrite.",
            )
        shutil.rmtree(target)
    target.mkdir(parents=True)

    tpl_dir = files("sota_runner.templates")
    dispatch_src = "dispatch.py.tpl" if template == "mcp-llm" else "dispatch_det.py.tpl"
    requirements_src = (
        "requirements.txt.tpl" if template == "mcp-llm" else "requirements_det.txt.tpl"
    )

    files_to_copy = [
        (dispatch_src, "dispatch.py"),
        ("env.example.tpl", ".env.example"),
        (requirements_src, "requirements.txt"),
        ("README.md.tpl", "README.md"),
    ]
    for src, dst in files_to_copy:
        try:
            content = (tpl_dir / src).read_text(encoding="utf-8")
        except FileNotFoundError:
            click.echo(f"warning: template {src} not found, skipping", err=True)
            continue
        (target / dst).write_text(
            content.replace("{{AGENT_NAME}}", name),
            encoding="utf-8",
        )

    click.echo(f"✓ scaffolded {name}/")
    click.echo("")
    click.echo("Next steps:")
    click.echo(f"  1. cd {name}")
    click.echo("  2. cp .env.example .env  # then fill SOTA_API_KEY")
    click.echo("  3. pip install -r requirements.txt")
    click.echo("  4. sota-runner run")


@main.command("run")
@click.option(
    "--config", "config_path", type=click.Path(), default=".env",
    help="Path to .env-style config file. Loaded into os.environ.",
)
@click.option(
    "--webhook-port", "webhook_port", type=int, default=None,
    help="Start a webhook listener on this port. Requires sota-runner[webhooks].",
)
@click.option(
    "--dispatch", "dispatch_module", default="dispatch:dispatch",
    show_default=True,
    help="<module>:<function> to import as the dispatcher.",
)
def run_cmd(config_path: str, webhook_port: int | None, dispatch_module: str) -> None:
    """Start the polling loop. Blocks until SIGINT/SIGTERM."""
    _load_dotenv(config_path)
    sys.path.insert(0, os.getcwd())

    mod_name, _, fn_name = dispatch_module.partition(":")
    if not fn_name:
        raise click.UsageError(
            f"--dispatch must be 'module:function', got {dispatch_module!r}",
        )
    try:
        import importlib
        mod = importlib.import_module(mod_name)
    except ImportError as e:
        raise click.UsageError(f"could not import {mod_name!r}: {e}") from e

    dispatch_fn = getattr(mod, fn_name, None)
    if dispatch_fn is None:
        raise click.UsageError(f"{mod_name} has no attribute {fn_name!r}")

    from sota_runner.runner import Runner
    Runner(dispatch=dispatch_fn, webhook_port=webhook_port).run()


@main.command("status")
def status_cmd() -> None:
    """Print /me + sandbox progress as JSON. Useful for debugging."""
    from sota_runner.api import APIClient

    api = APIClient()
    try:
        me = api.get_me()
        progress = api.get_sandbox_progress()
    finally:
        api.close()

    click.echo(json.dumps({"me": me, "sandbox_progress": progress}, indent=2))


def _load_dotenv(path: str) -> None:
    """Tiny .env loader — no python-dotenv dependency.

    Lines starting with # are comments. Empty lines ignored. Trailing
    `\\n` stripped. Quoted values have surrounding quotes removed.
    """
    if not Path(path).exists():
        return
    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip()
            if (value.startswith('"') and value.endswith('"')) or (
                value.startswith("'") and value.endswith("'")
            ):
                value = value[1:-1]
            os.environ.setdefault(key, value)


if __name__ == "__main__":
    main()
