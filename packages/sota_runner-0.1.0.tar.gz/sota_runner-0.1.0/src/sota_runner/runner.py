"""Main polling loop for SOTA agents.

Public surface:
    Runner(dispatch_fn).run()
    run(dispatch_fn)                # convenience wrapper

The dispatcher is a pure function ``def dispatch(job: dict) -> dict``
provided by the user (typically in their project's ``dispatch.py``).
The runner takes care of:
    1. polling /agents/jobs every POLL_INTERVAL_SECONDS
    2. calling dispatch() per job
    3. POSTing the result with a fresh-but-stable Idempotency-Key
    4. self-correcting on 422 (sandbox) by handing the diagnostic back
       to dispatch on the next iteration
    5. running the heartbeat loop in the background
    6. (optional) running the webhook HTTP server on --webhook-port

If dispatch is async, the runner awaits it. Otherwise it calls the sync
function directly. No asyncio.to_thread overhead unless the dev opts in.

State (idempotency keys, last heartbeat, recent failures) is persisted to
``.sota-runner-state.json`` in the working directory.
"""
from __future__ import annotations

import asyncio
import inspect
import json
import logging
import os
import signal
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Union

import httpx

from sota_runner.api import APIClient
from sota_runner.heartbeat import HeartbeatLoop
from sota_runner.idempotency import KeyStore
from sota_runner.state import State

logger = logging.getLogger(__name__)

DispatchFn = Callable[[dict], Union[dict, Awaitable[dict]]]
"""User-supplied handler signature.

    def dispatch(job: dict) -> dict:
        return {"result": "..."}

Or async:

    async def dispatch(job: dict) -> dict:
        return {"result": await some_async_call(job)}

Return values:
    {"result": "<JSON string or text>"}            → success delivery
    {"error_code": "timeout", "retryable": True}   → active-mode error report
    {"skip": True}                                 → don't deliver this tick
"""

DEFAULT_POLL_INTERVAL_SECONDS = 3.0


@dataclass
class Runner:
    """Polling loop for a SOTA agent.

    Args:
        dispatch: user handler (sync or async).
        api: APIClient. Constructed from env if omitted.
        state: State store. Defaults to ``.sota-runner-state.json``.
        poll_interval_seconds: seconds between /agents/jobs polls.
        webhook_port: if set, starts an HTTP server on this port for
            inbound webhook events. Polling-only mode if None.
        on_error: optional callback for unhandled dispatch exceptions.
    """

    dispatch: DispatchFn
    api: APIClient | None = None
    state: State | None = None
    poll_interval_seconds: float = field(
        default_factory=lambda: float(
            os.environ.get("SOTA_POLL_INTERVAL_SECONDS", DEFAULT_POLL_INTERVAL_SECONDS)
        )
    )
    webhook_port: int | None = None
    on_error: Callable[[BaseException, dict], None] | None = None

    def __post_init__(self) -> None:
        self.api = self.api or APIClient()
        self.state = self.state or State()
        self._keys = KeyStore(self.state)
        self._heartbeat = HeartbeatLoop(self.api, self.state)
        self._stop = asyncio.Event()
        # Per-job retry counter (in-memory only; resets on restart).
        self._retries: dict[str, int] = {}

    # ---- Public entrypoints --------------------------------------------------

    def run(self) -> None:
        """Block until SIGINT/SIGTERM. The single entry point devs use."""
        try:
            asyncio.run(self.run_async())
        except KeyboardInterrupt:
            logger.info("interrupted, shutting down")

    async def run_async(self) -> None:
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, self._stop.set)
            except NotImplementedError:
                # Windows event loop doesn't support add_signal_handler.
                pass

        tasks = [
            asyncio.create_task(self._heartbeat.run(self._stop), name="heartbeat"),
            asyncio.create_task(self._poll_loop(), name="poll"),
        ]
        if self.webhook_port is not None:
            from sota_runner.webhooks import WebhookServer
            server = WebhookServer(port=self.webhook_port)
            tasks.append(asyncio.create_task(server.run(self._stop), name="webhook"))

        try:
            await self._stop.wait()
        finally:
            for t in tasks:
                t.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            assert self.api is not None
            self.api.close()

    # ---- Inner loop ----------------------------------------------------------

    async def _poll_loop(self) -> None:
        while not self._stop.is_set():
            try:
                await self._tick()
            except httpx.HTTPError as e:
                logger.warning("poll tick: HTTP error %s", e)
            except Exception:  # noqa: BLE001
                logger.exception("poll tick: unexpected error")
            try:
                await asyncio.wait_for(
                    self._stop.wait(), timeout=self.poll_interval_seconds
                )
            except asyncio.TimeoutError:
                pass

    async def _tick(self) -> None:
        assert self.api is not None
        body = self.api.list_jobs()
        jobs = body.get("jobs", [])
        sandbox = body.get("sandbox", False)
        for job in jobs:
            await self._handle_one(job, sandbox=sandbox)

    async def _handle_one(self, job: dict, *, sandbox: bool) -> None:
        job_id = job.get("id")
        if not job_id:
            logger.warning("job has no id, skipping: %r", job)
            return

        # Skip jobs we've already retried too many times — backstop in case
        # the server keeps handing them back.
        if self._retries.get(job_id, 0) >= 3:
            logger.warning("job %s exceeded retry budget, skipping", job_id)
            return

        try:
            outcome = await self._call_dispatch(job)
        except Exception as e:  # noqa: BLE001
            logger.exception("dispatch raised on job %s", job_id)
            if self.on_error:
                try:
                    self.on_error(e, job)
                except Exception:  # noqa: BLE001
                    logger.exception("on_error callback raised")
            self._retries[job_id] = self._retries.get(job_id, 0) + 1
            return

        if not isinstance(outcome, dict):
            logger.error("dispatch returned non-dict for job %s: %r", job_id, outcome)
            return
        if outcome.get("skip"):
            return

        await self._deliver(job_id, outcome, sandbox=sandbox)

    async def _call_dispatch(self, job: dict) -> Any:
        """Sync or async dispatch — caller doesn't have to know."""
        result = self.dispatch(job)
        if inspect.isawaitable(result):
            return await result
        return result

    async def _deliver(self, job_id: str, outcome: dict, *, sandbox: bool) -> None:
        assert self.api is not None
        kind = "test_deliver" if sandbox else "deliver"
        idem = self._keys.for_attempt(job_id, kind)

        if sandbox:
            payload = outcome.get("result", "")
            if isinstance(payload, dict):
                payload = json.dumps(payload)
            status, body = self.api.deliver_test_job(
                job_id, str(payload), idempotency_key=idem,
            )
            if status == 200:
                logger.info("test_job %s passed", job_id)
                self._keys.forget(job_id, kind)
                self._retries.pop(job_id, None)
                return
            if status == 422:
                # Self-correction loop: bump retry counter, log, and let
                # the next poll tick hand the same job back to dispatch
                # (the SAME job_id will reappear because we mark it failed
                # only after the dev calls /test-jobs/{id}/retry, but the
                # diagnostic is in `body` for them to inspect).
                logger.info(
                    "test_job %s failed validation: %s",
                    job_id, body.get("code"),
                )
                self._retries[job_id] = self._retries.get(job_id, 0) + 1
                return
            logger.error(
                "test_job %s deliver returned %s: %s",
                job_id, status, body,
            )
            return

        # Active-mode delivery.
        if outcome.get("error_code"):
            status, body = self.api.deliver_job(
                job_id,
                error_code=outcome.get("error_code"),
                error_message=outcome.get("error_message"),
                retryable=outcome.get("retryable"),
                idempotency_key=idem,
            )
        else:
            payload = outcome.get("result", "")
            if isinstance(payload, dict):
                payload = json.dumps(payload)
            status, body = self.api.deliver_job(
                job_id,
                result=str(payload),
                result_hash=outcome.get("result_hash"),
                idempotency_key=idem,
            )
        if status == 200:
            logger.info("job %s delivered", job_id)
            self._keys.forget(job_id, kind)
            self._retries.pop(job_id, None)
        else:
            logger.warning("job %s deliver returned %s: %s", job_id, status, body)


def run(dispatch: DispatchFn, **kwargs: Any) -> None:
    """Convenience wrapper: ``run(my_dispatch)`` instead of
    ``Runner(my_dispatch).run()``."""
    Runner(dispatch=dispatch, **kwargs).run()


__all__ = ["Runner", "run", "DispatchFn"]
