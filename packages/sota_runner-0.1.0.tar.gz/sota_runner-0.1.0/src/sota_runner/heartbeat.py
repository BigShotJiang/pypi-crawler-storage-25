"""Heartbeat loop.

Sends ``POST /api/v1/agents/heartbeat`` every HEARTBEAT_INTERVAL_SECONDS
(default 30s) for as long as the runner is alive. Failures are logged
and ignored — a transient outage shouldn't crash the runner.
"""
from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sota_runner.api import APIClient
    from sota_runner.state import State

logger = logging.getLogger(__name__)

DEFAULT_HEARTBEAT_INTERVAL_SECONDS = 30.0


class HeartbeatLoop:
    """Async heartbeat sender. Owned by Runner."""

    def __init__(
        self,
        api: "APIClient",
        state: "State",
        interval_seconds: float | None = None,
    ) -> None:
        self.api = api
        self.state = state
        self.interval = interval_seconds or float(
            os.environ.get(
                "SOTA_HEARTBEAT_INTERVAL_SECONDS", DEFAULT_HEARTBEAT_INTERVAL_SECONDS,
            )
        )

    async def run(self, stop: asyncio.Event) -> None:
        while not stop.is_set():
            self._tick()
            try:
                await asyncio.wait_for(stop.wait(), timeout=self.interval)
            except asyncio.TimeoutError:
                pass

    def _tick(self) -> None:
        try:
            status = self.api.heartbeat()
            if 200 <= status < 300:
                self.state.update(
                    last_heartbeat_at=datetime.now(timezone.utc).isoformat(),
                )
            else:
                logger.warning("heartbeat returned %s", status)
        except Exception:  # noqa: BLE001
            logger.exception("heartbeat tick failed")


__all__ = ["HeartbeatLoop", "DEFAULT_HEARTBEAT_INTERVAL_SECONDS"]
