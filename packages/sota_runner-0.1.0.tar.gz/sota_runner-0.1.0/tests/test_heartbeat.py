"""Heartbeat loop tests."""
from __future__ import annotations

import asyncio
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from sota_runner.heartbeat import HeartbeatLoop
from sota_runner.state import State


@pytest.mark.asyncio
async def test_tick_writes_last_heartbeat_on_success(tmp_path: Path) -> None:
    api = MagicMock()
    api.heartbeat.return_value = 200
    state = State(tmp_path / "s.json")
    loop = HeartbeatLoop(api, state, interval_seconds=0.01)
    loop._tick()
    assert "last_heartbeat_at" in state.read()


@pytest.mark.asyncio
async def test_tick_does_not_write_on_failure(tmp_path: Path) -> None:
    api = MagicMock()
    api.heartbeat.return_value = 500
    state = State(tmp_path / "s.json")
    loop = HeartbeatLoop(api, state, interval_seconds=0.01)
    loop._tick()
    assert "last_heartbeat_at" not in state.read()


@pytest.mark.asyncio
async def test_tick_swallows_exceptions(tmp_path: Path) -> None:
    api = MagicMock()
    api.heartbeat.side_effect = RuntimeError("network down")
    state = State(tmp_path / "s.json")
    loop = HeartbeatLoop(api, state, interval_seconds=0.01)
    # Must not raise — heartbeat is best-effort.
    loop._tick()


@pytest.mark.asyncio
async def test_run_stops_on_event(tmp_path: Path) -> None:
    api = MagicMock()
    api.heartbeat.return_value = 200
    state = State(tmp_path / "s.json")
    loop = HeartbeatLoop(api, state, interval_seconds=0.01)
    stop = asyncio.Event()

    async def stop_after():
        await asyncio.sleep(0.05)
        stop.set()

    await asyncio.gather(loop.run(stop), stop_after())
    # Loop exited cleanly; heartbeat called at least once.
    assert api.heartbeat.call_count >= 1
