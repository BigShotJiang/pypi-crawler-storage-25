"""Runner main-loop tests.

Strategy: replace APIClient + dispatch with mocks. Drive a single tick
synchronously and assert the outgoing calls match the contract.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from sota_runner.runner import Runner
from sota_runner.state import State


def _make_runner(tmp_path: Path, dispatch_fn, **kwargs):
    api = MagicMock()
    api.list_jobs.return_value = {"jobs": [], "sandbox": True}
    api.deliver_test_job.return_value = (200, {"passed": True})
    api.deliver_job.return_value = (200, {"status": "delivered"})
    state = State(tmp_path / "state.json")
    return Runner(dispatch=dispatch_fn, api=api, state=state, **kwargs), api


@pytest.mark.asyncio
async def test_tick_with_no_jobs_is_noop(tmp_path: Path) -> None:
    dispatch = MagicMock(return_value={"result": "x"})
    runner, api = _make_runner(tmp_path, dispatch)
    await runner._tick()
    api.list_jobs.assert_called_once()
    dispatch.assert_not_called()


@pytest.mark.asyncio
async def test_sandbox_pass_marks_idempotency_key_freed(tmp_path: Path) -> None:
    dispatch = MagicMock(return_value={"result": '{"ok":true}'})
    runner, api = _make_runner(tmp_path, dispatch)
    api.list_jobs.return_value = {
        "jobs": [{"id": "tj1", "expected_schema": {}, "description": "x"}],
        "sandbox": True,
    }
    api.deliver_test_job.return_value = (200, {"passed": True})

    await runner._tick()

    args, kwargs = api.deliver_test_job.call_args
    assert args[0] == "tj1"
    assert "idempotency_key" in kwargs
    # After 200 the key should be forgotten (so a future tick re-uses fresh).
    assert "tj1:test_deliver" not in runner._keys._keys


@pytest.mark.asyncio
async def test_sandbox_422_keeps_key_and_increments_retry(tmp_path: Path) -> None:
    dispatch = MagicMock(return_value={"result": '{}'})
    runner, api = _make_runner(tmp_path, dispatch)
    api.list_jobs.return_value = {
        "jobs": [{"id": "tj1", "expected_schema": {}, "description": "x"}],
        "sandbox": True,
    }
    api.deliver_test_job.return_value = (422, {"code": "schema_violation"})

    await runner._tick()
    assert "tj1:test_deliver" in runner._keys._keys
    assert runner._retries.get("tj1") == 1


@pytest.mark.asyncio
async def test_active_delivery_uses_deliver_endpoint(tmp_path: Path) -> None:
    dispatch = MagicMock(return_value={"result": '{"ok": true}'})
    runner, api = _make_runner(tmp_path, dispatch)
    api.list_jobs.return_value = {
        "jobs": [{"id": "j1", "description": "x"}],
        "sandbox": False,
    }
    api.deliver_job.return_value = (200, {"status": "delivered"})

    await runner._tick()

    api.deliver_test_job.assert_not_called()
    args, kwargs = api.deliver_job.call_args
    assert args[0] == "j1"
    assert "idempotency_key" in kwargs


@pytest.mark.asyncio
async def test_active_error_report_uses_error_fields(tmp_path: Path) -> None:
    dispatch = MagicMock(return_value={
        "error_code": "timeout",
        "error_message": "took too long",
        "retryable": True,
    })
    runner, api = _make_runner(tmp_path, dispatch)
    api.list_jobs.return_value = {
        "jobs": [{"id": "j1", "description": "x"}],
        "sandbox": False,
    }
    api.deliver_job.return_value = (200, {})

    await runner._tick()
    _, kwargs = api.deliver_job.call_args
    assert kwargs["error_code"] == "timeout"
    assert kwargs["retryable"] is True


@pytest.mark.asyncio
async def test_skip_outcome_does_not_deliver(tmp_path: Path) -> None:
    dispatch = MagicMock(return_value={"skip": True})
    runner, api = _make_runner(tmp_path, dispatch)
    api.list_jobs.return_value = {
        "jobs": [{"id": "j1", "description": "x"}],
        "sandbox": False,
    }
    await runner._tick()
    api.deliver_job.assert_not_called()


@pytest.mark.asyncio
async def test_dispatch_exception_does_not_crash_loop(tmp_path: Path) -> None:
    dispatch = MagicMock(side_effect=RuntimeError("kaboom"))
    runner, api = _make_runner(tmp_path, dispatch)
    api.list_jobs.return_value = {
        "jobs": [{"id": "j1", "description": "x"}],
        "sandbox": False,
    }
    # Must not raise.
    await runner._tick()
    api.deliver_job.assert_not_called()
    assert runner._retries.get("j1") == 1


@pytest.mark.asyncio
async def test_dispatch_can_be_async(tmp_path: Path) -> None:
    async def adispatch(job):
        return {"result": '{"ok":true}'}

    runner, api = _make_runner(tmp_path, adispatch)
    api.list_jobs.return_value = {
        "jobs": [{"id": "j1", "description": "x"}],
        "sandbox": False,
    }
    api.deliver_job.return_value = (200, {})

    await runner._tick()
    api.deliver_job.assert_called_once()


@pytest.mark.asyncio
async def test_retry_budget_caps_at_3(tmp_path: Path) -> None:
    dispatch = MagicMock(side_effect=RuntimeError("bad"))
    runner, api = _make_runner(tmp_path, dispatch)
    api.list_jobs.return_value = {
        "jobs": [{"id": "j1", "description": "x"}],
        "sandbox": False,
    }
    for _ in range(5):
        await runner._tick()
    # Retry counter doesn't exceed 3 (skipped once it hits the budget).
    assert runner._retries["j1"] == 3
    # dispatch was called for the first 3 ticks, then skipped.
    assert dispatch.call_count == 3


@pytest.mark.asyncio
async def test_dict_result_is_json_serialized(tmp_path: Path) -> None:
    dispatch = MagicMock(return_value={"result": {"ok": True, "n": 1}})
    runner, api = _make_runner(tmp_path, dispatch)
    api.list_jobs.return_value = {
        "jobs": [{"id": "j1", "description": "x"}],
        "sandbox": False,
    }
    api.deliver_job.return_value = (200, {})
    await runner._tick()
    _, kwargs = api.deliver_job.call_args
    assert isinstance(kwargs["result"], str)
    import json
    assert json.loads(kwargs["result"]) == {"ok": True, "n": 1}
