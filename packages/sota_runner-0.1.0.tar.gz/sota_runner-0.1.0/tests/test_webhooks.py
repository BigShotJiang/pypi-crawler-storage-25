"""Webhook signature verification tests.

Critical correctness property: signature verification operates on the RAW
bytes from the wire. Re-serializing the JSON ANYWHERE in the receive path
breaks the HMAC. These tests pin that down.
"""
from __future__ import annotations

import hashlib
import hmac
import json

from sota_runner.webhooks import verify_signature


SECRET = "whsec_test_abcdef0123456789"


def _sign(raw: bytes, secret: str = SECRET) -> str:
    return hmac.new(secret.encode("utf-8"), raw, hashlib.sha256).hexdigest()


def test_verify_returns_true_for_matching_signature() -> None:
    body = b'{"event": "test_job.passed", "agent_id": "abc"}'
    sig = _sign(body)
    assert verify_signature(body, sig, SECRET) is True


def test_verify_returns_false_for_wrong_signature() -> None:
    body = b'{"event": "test_job.passed"}'
    assert verify_signature(body, "deadbeef" * 8, SECRET) is False


def test_verify_returns_false_for_wrong_secret() -> None:
    body = b'{"event": "test_job.passed"}'
    sig = _sign(body)
    assert verify_signature(body, sig, "different-secret") is False


def test_verify_returns_false_for_empty_inputs() -> None:
    assert verify_signature(b"", "", "") is False
    assert verify_signature(b"x", "", SECRET) is False
    assert verify_signature(b"", _sign(b"x"), SECRET) is False


def test_re_serialized_json_breaks_signature() -> None:
    """The footgun: someone parses the JSON, then re-encodes, then verifies.
    Different whitespace = different bytes = different HMAC. This MUST fail
    so devs reading the test see the principle."""
    original = b'{"event":"test_job.passed","agent_id":"abc"}'
    sig = _sign(original)

    parsed = json.loads(original)
    re_serialized = json.dumps(parsed).encode("utf-8")  # adds whitespace

    assert verify_signature(re_serialized, sig, SECRET) is False
    assert verify_signature(original, sig, SECRET) is True


def test_constant_time_compare() -> None:
    """Sanity: known-good sig + adversarial-len sig both return cleanly,
    no exception."""
    body = b'{"a":1}'
    short_sig = "ab"
    long_sig = "0" * 1000
    assert verify_signature(body, short_sig, SECRET) is False
    assert verify_signature(body, long_sig, SECRET) is False


def test_unicode_payload_round_trip() -> None:
    body = '{"text": "héllo wörld 🚀"}'.encode("utf-8")
    sig = _sign(body)
    assert verify_signature(body, sig, SECRET) is True
