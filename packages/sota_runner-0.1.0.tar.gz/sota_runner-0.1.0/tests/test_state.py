"""State tests: read/write/atomic-replace + corrupt-file recovery."""
from __future__ import annotations

import json
import os
import threading
from pathlib import Path

import pytest

from sota_runner.state import State


def test_read_missing_file_returns_empty(tmp_path: Path) -> None:
    s = State(tmp_path / "missing.json")
    assert s.read() == {}


def test_round_trip_preserves_dict(tmp_path: Path) -> None:
    s = State(tmp_path / "state.json")
    payload = {"a": 1, "b": ["x", "y"], "c": {"nested": True}}
    s.write(payload)
    assert s.read() == payload


def test_corrupt_json_resets_silently(tmp_path: Path) -> None:
    p = tmp_path / "state.json"
    p.write_text("{not valid json", encoding="utf-8")
    s = State(p)
    assert s.read() == {}


def test_non_dict_root_returns_empty(tmp_path: Path) -> None:
    p = tmp_path / "state.json"
    p.write_text(json.dumps([1, 2, 3]), encoding="utf-8")
    assert State(p).read() == {}


def test_update_merges(tmp_path: Path) -> None:
    s = State(tmp_path / "state.json")
    s.write({"a": 1, "b": 2})
    s.update(b=3, c=4)
    assert s.read() == {"a": 1, "b": 3, "c": 4}


def test_atomic_no_partial_file_on_crash(tmp_path: Path) -> None:
    """Simulate write failure mid-flight: the existing file must not be
    corrupted. We can't truly crash mid-write here, but we CAN verify the
    .tmp file goes away after a successful write — the atomic invariant."""
    s = State(tmp_path / "state.json")
    s.write({"original": True})
    s.write({"updated": True})
    assert s.read() == {"updated": True}
    # No leftover .tmp file.
    assert not (tmp_path / "state.json.tmp").exists()


def test_concurrent_writes_dont_corrupt(tmp_path: Path) -> None:
    """Best-effort sanity check: many writes from threads end with
    SOMETHING valid in the file (last writer wins is fine; corruption
    is not)."""
    s = State(tmp_path / "state.json")
    s.write({"counter": 0})

    def writer(n: int) -> None:
        for _ in range(20):
            s.update(**{f"k{n}": n})

    threads = [threading.Thread(target=writer, args=(i,)) for i in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    final = s.read()
    # Only invariant State guarantees under concurrent update(): the file
    # is still parseable JSON-as-dict. "Last writer wins" is fine; a
    # corrupted file (or non-dict / unreadable) is not. The runner doesn't
    # promise that every writer's key survives — that requires locking
    # we don't ship in v0.1 — and asserting it here makes the test flaky
    # under heavy contention.
    assert isinstance(final, dict)
