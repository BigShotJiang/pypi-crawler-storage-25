"""Idempotency-Key store tests."""
from __future__ import annotations

import re
import uuid
from pathlib import Path

from sota_runner.idempotency import KeyStore
from sota_runner.state import State

UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


def test_for_attempt_returns_uuid(tmp_path: Path) -> None:
    ks = KeyStore(State(tmp_path / "s.json"))
    key = ks.for_attempt("job-1", "deliver")
    assert UUID_RE.match(key)


def test_same_job_same_kind_returns_same_key(tmp_path: Path) -> None:
    ks = KeyStore(State(tmp_path / "s.json"))
    a = ks.for_attempt("job-1", "deliver")
    b = ks.for_attempt("job-1", "deliver")
    assert a == b


def test_different_kind_returns_different_key(tmp_path: Path) -> None:
    ks = KeyStore(State(tmp_path / "s.json"))
    a = ks.for_attempt("job-1", "deliver")
    b = ks.for_attempt("job-1", "test_deliver")
    assert a != b


def test_different_job_returns_different_key(tmp_path: Path) -> None:
    ks = KeyStore(State(tmp_path / "s.json"))
    a = ks.for_attempt("job-1", "deliver")
    b = ks.for_attempt("job-2", "deliver")
    assert a != b


def test_keys_persist_across_restart(tmp_path: Path) -> None:
    """Critical: a runner restart mid-retry must reuse the same key."""
    state_path = tmp_path / "s.json"
    ks1 = KeyStore(State(state_path))
    original = ks1.for_attempt("job-1", "deliver")

    # Simulate restart by constructing a new KeyStore on the same state file.
    ks2 = KeyStore(State(state_path))
    assert ks2.for_attempt("job-1", "deliver") == original


def test_forget_drops_key(tmp_path: Path) -> None:
    ks = KeyStore(State(tmp_path / "s.json"))
    a = ks.for_attempt("job-1", "deliver")
    ks.forget("job-1", "deliver")
    b = ks.for_attempt("job-1", "deliver")
    assert a != b


def test_uuid_format_valid(tmp_path: Path) -> None:
    """The server's idempotency_records.idempotency_key column accepts up
    to 255 chars, but the runner always emits standard UUIDs."""
    ks = KeyStore(State(tmp_path / "s.json"))
    for i in range(100):
        key = ks.for_attempt(f"job-{i}", "deliver")
        # Round-trip through uuid.UUID to confirm it's actually valid.
        uuid.UUID(key)
