"""CLI tests: init scaffolds the right files, --version works."""
from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from sota_runner.cli import main


def test_version_flag() -> None:
    r = CliRunner().invoke(main, ["--version"])
    assert r.exit_code == 0
    assert "sota-runner" in r.output


def test_init_creates_default_files(tmp_path: Path) -> None:
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=tmp_path):
        r = runner.invoke(main, ["init", "my-agent"])
        assert r.exit_code == 0, r.output
        target = Path("my-agent")
        assert (target / "dispatch.py").exists()
        assert (target / ".env.example").exists()
        assert (target / "requirements.txt").exists()
        assert (target / "README.md").exists()


def test_init_det_template(tmp_path: Path) -> None:
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=tmp_path):
        r = runner.invoke(main, ["init", "my-agent", "--template", "det"])
        assert r.exit_code == 0, r.output
        dispatch = (Path("my-agent") / "dispatch.py").read_text()
        # Deterministic template has the schema_skeleton helper.
        assert "_schema_skeleton" in dispatch
        assert "HANDLERS" in dispatch


def test_init_mcp_llm_template_default(tmp_path: Path) -> None:
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=tmp_path):
        r = runner.invoke(main, ["init", "my-agent"])
        assert r.exit_code == 0, r.output
        dispatch = (Path("my-agent") / "dispatch.py").read_text()
        # MCP+LLM template uses an LLM client.
        assert "call_llm" in dispatch


def test_init_refuses_existing_dir_without_force(tmp_path: Path) -> None:
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=tmp_path):
        Path("my-agent").mkdir()
        r = runner.invoke(main, ["init", "my-agent"])
        assert r.exit_code != 0
        assert "already exists" in r.output.lower()


def test_init_force_overwrites(tmp_path: Path) -> None:
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=tmp_path):
        Path("my-agent").mkdir()
        (Path("my-agent") / "stale.txt").write_text("old")
        r = runner.invoke(main, ["init", "my-agent", "--force"])
        assert r.exit_code == 0, r.output
        assert not (Path("my-agent") / "stale.txt").exists()


def test_init_substitutes_agent_name(tmp_path: Path) -> None:
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=tmp_path):
        r = runner.invoke(main, ["init", "alpha-bot"])
        assert r.exit_code == 0, r.output
        readme = (Path("alpha-bot") / "README.md").read_text()
        assert "alpha-bot" in readme
        assert "{{AGENT_NAME}}" not in readme
