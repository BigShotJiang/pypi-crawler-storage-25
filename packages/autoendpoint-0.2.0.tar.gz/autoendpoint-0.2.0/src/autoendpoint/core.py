from typing import Any, List, Optional, Type, get_args, get_origin

from fastapi import APIRouter, Body, HTTPException, Path, Query
from sqlalchemy import inspect
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import SQLModel, select
from strawberry.fastapi import GraphQLRouter

from autoendpoint.graphql_utils import generate_graphql_schema
from autoendpoint.models import generate_crud_models
from autoendpoint.utils import is_primary_key


class RelationRouter:
    """Handles the creation and registration of linking routes for m:n relationships.

    Attributes:
        model_a (Type[SQLModel]): The first SQLModel class in the relationship.
        model_b (Type[SQLModel]): The second SQLModel class in the relationship.
        rel_name (str): The name of the relationship on model_a.
        _db_session (AsyncSession): The asynchronous database session.
        router (APIRouter): The FastAPI router for these relationship endpoints.
    """

    def __init__(self, model_a: Type[SQLModel], model_b: Type[SQLModel], rel_name: str, db_session: AsyncSession, link_model: Optional[Type[SQLModel]] = None):
        self.model_a = model_a
        self.model_b = model_b
        self.rel_name = rel_name
        self._db_session = db_session
        self.link_model = link_model
        
        self.router = APIRouter(prefix=f"/{model_a.__name__.lower()}", tags=[model_a.__name__])
        self._setup_routes()

    def _setup_routes(self):
        model = self.model_a
        target_model = self.model_b
        rel_name = self.rel_name
        
        pk_name = next((n for n, f in model.model_fields.items() if is_primary_key(field=f)), "id")
        pk_type = model.model_fields[pk_name].annotation
        model_pk_param = f"{model.__name__.lower()}_{pk_name}"

        target_pk_name = next((n for n, f in target_model.model_fields.items() if is_primary_key(field=f)), "id")
        target_pk_type = target_model.model_fields[target_pk_name].annotation
        target_pk_param = f"{target_model.__name__.lower()}_{target_pk_name}"

        @self.router.post(f"/{{{model_pk_param}}}/{rel_name}/{{{target_pk_param}}}",
                          description=f"Link a {target_model.__name__} to this {model.__name__}",
                          summary=f"Link {target_model.__name__} to {model.__name__}")
        async def link_relationship(
            pk_value: pk_type = Path(..., alias=model_pk_param, description=f"The {model.__name__} {pk_name}"),
            target_pk_value: target_pk_type = Path(..., alias=target_pk_param, description=f"The {target_model.__name__} {target_pk_name}")
        ):
            # Verify both records exist
            parent = await self._db_session.get(model, pk_value)
            if not parent:
                raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
            
            target = await self._db_session.get(target_model, target_pk_value)
            if not target:
                raise HTTPException(status_code=404, detail=f"{target_model.__name__} not found")
            
            # Add to collection
            from sqlalchemy.orm import selectinload
            # Reload with relationship to check if already linked
            stmt = select(model).where(getattr(model, pk_name) == pk_value).options(selectinload(getattr(model, rel_name)))
            results = await self._db_session.execute(stmt)
            parent = results.scalars().first()
            
            collection = getattr(parent, rel_name)
            if target not in collection:
                collection.append(target)
                self._db_session.add(parent)
                await self._db_session.commit()
            
            # If we have a link_model, let's find the link record to return it
            if self.link_model:
                # Find the link record
                # We assume the link model has foreign keys to both models
                # For simplicity, we query by the values we just linked
                # This might return the wrong one if there are multiple links, 
                # but it's better than nothing and often correct.
                # In a more advanced version, we would inspect the link model's foreign keys.
                
                # Try to find the link model mapper to find FK columns
                link_mapper = inspect(self.link_model)
                query = select(self.link_model)
                
                # This is a bit heuristic: find columns that have foreign keys to model or target_model
                for column in link_mapper.columns:
                    for fk in column.foreign_keys:
                        if fk.references(model.__table__):
                            query = query.where(column == pk_value)
                        elif fk.references(target_model.__table__):
                            query = query.where(column == target_pk_value)
                
                link_result = await self._db_session.execute(query)
                link_record = link_result.scalars().first()
                if link_record:
                    return link_record

            return {"detail": f"Linked {target_model.__name__} to {model.__name__}"}

        if self.link_model:
            _, _, PatchModel = generate_crud_models(self.link_model)
            
            @self.router.patch(f"/{{{model_pk_param}}}/{rel_name}/{{{target_pk_param}}}",
                               response_model=self.link_model,
                               description=f"Update the link between {model.__name__} and {target_model.__name__}",
                               summary=f"Update relationship link")
            async def patch_relationship(
                item: PatchModel = Body(..., description="The link data to patch"),
                pk_value: pk_type = Path(..., alias=model_pk_param, description=f"The {model.__name__} {pk_name}"),
                target_pk_value: target_pk_type = Path(..., alias=target_pk_param, description=f"The {target_model.__name__} {target_pk_name}")
            ):
                link_mapper = inspect(self.link_model)
                query = select(self.link_model)
                for column in link_mapper.columns:
                    for fk in column.foreign_keys:
                        if fk.references(model.__table__):
                            query = query.where(column == pk_value)
                        elif fk.references(target_model.__table__):
                            query = query.where(column == target_pk_value)
                
                results = await self._db_session.execute(query)
                db_item = results.scalars().first()
                if not db_item:
                    raise HTTPException(status_code=404, detail="Relationship link not found")
                
                update_data = item.model_dump(exclude_unset=True)
                for key, value in update_data.items():
                    setattr(db_item, key, value)
                
                self._db_session.add(db_item)
                await self._db_session.commit()
                await self._db_session.refresh(db_item)
                return db_item

        @self.router.delete(f"/{{{model_pk_param}}}/{rel_name}/{{{target_pk_param}}}",
                            description=f"Unlink a {target_model.__name__} from this {model.__name__}",
                            summary=f"Unlink {target_model.__name__} from {model.__name__}")
        async def unlink_relationship(
            pk_value: pk_type = Path(..., alias=model_pk_param, description=f"The {model.__name__} {pk_name}"),
            target_pk_value: target_pk_type = Path(..., alias=target_pk_param, description=f"The {target_model.__name__} {target_pk_name}")
        ):
            # Reload with relationship
            from sqlalchemy.orm import selectinload
            stmt = select(model).where(getattr(model, pk_name) == pk_value).options(selectinload(getattr(model, rel_name)))
            results = await self._db_session.execute(stmt)
            parent = results.scalars().first()
            
            if not parent:
                raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
            
            target = await self._db_session.get(target_model, target_pk_value)
            if not target:
                raise HTTPException(status_code=404, detail=f"{target_model.__name__} not found")

            collection = getattr(parent, rel_name)
            if target in collection:
                collection.remove(target)
                self._db_session.add(parent)
                await self._db_session.commit()
                return {"detail": f"Unlinked {target_model.__name__} from {model.__name__}"}
            
            return {"detail": f"{target_model.__name__} was not linked to {model.__name__}"}


class ModelRouter:
    """Handles the creation and registration of CRUD routes for a single SQLModel.

    Attributes:
        model (Type[SQLModel]): The SQLModel class.
        _db_session (AsyncSession): The asynchronous database session.
        router (APIRouter): The FastAPI router for this model's endpoints.
    """

    def __init__(self, model: Type[SQLModel], db_session: AsyncSession):
        self.model = model
        self._db_session = db_session
        self.name = model.__name__.lower()
        self.router = APIRouter(prefix=f"/{self.name}", tags=[model.__name__])
        self._setup_routes()

    def _setup_routes(self):
        """Generates and registers CRUD endpoints for the model."""
        model_fields = self.model.model_fields
        CreateModel, UpdateModel, PatchModel = generate_crud_models(model=self.model)
        # Identify Primary Key
        pks = [n for n, f in model_fields.items() if is_primary_key(field=f)]
        if not pks:
            pk_name = "id"
        elif "id" in pks:
            pk_name = "id"
        else:
            pk_name = pks[0]

        self._add_read_all_route()
        self._add_create_one_route(CreateModel=CreateModel)

        if pk_name:
            pk_type = model_fields[pk_name].annotation
            self._add_read_one_by_id_route(pk_name=pk_name, pk_type=pk_type)
            self._add_update_one_route(pk_name=pk_name, pk_type=pk_type, UpdateModel=UpdateModel)
            self._add_patch_one_route(pk_name=pk_name, pk_type=pk_type, PatchModel=PatchModel)
            self._add_delete_one_route(pk_name=pk_name, pk_type=pk_type)
            self._add_relationship_routes(pk_name=pk_name, pk_type=pk_type)

        self._add_read_one_by_unique_field_route(model_fields=model_fields)
        self._add_read_by_field_route(model_fields=model_fields)

    def _add_read_all_route(self):
        model = self.model
        @self.router.get("",
                         response_model=List[model],
                         description=f"Retrieve all {model.__name__} records",
                         summary=f"Retrieve all {model.__name__}")
        async def read_all(
            limit: int = Query(default=10, description="The maximum number of records to return. Set to 0 to return all records"),
            page: int = Query(default=1, description="The page number to return")
        ):
            stmt = select(model)
            if limit > 0:
                offset = (page - 1) * limit
                stmt = stmt.offset(offset).limit(limit)
            results = await self._db_session.execute(stmt)
            return results.scalars().all()

    def _add_create_one_route(self, CreateModel: Type[SQLModel]):
        model = self.model
        @self.router.post("",
                         response_model=model,
                         description=f"Create a new {model.__name__} record",
                         summary=f"Create {model.__name__}")
        async def create_one(item: CreateModel = Body(..., description=f"The {model.__name__} data to create")):
            db_item = model(**item.model_dump())
            self._db_session.add(db_item)
            await self._db_session.commit()
            await self._db_session.refresh(db_item)
            return db_item

    def _add_read_one_by_id_route(self, pk_name: str, pk_type: Type):
        model = self.model
        @self.router.get(f"/{{{pk_name}}}",
                         response_model=model,
                         description=f"Retrieve a {model.__name__} record by {pk_name}",
                         summary=f"Retrieve {model.__name__} by {pk_name}")
        async def read_one_by_id(pk_value: pk_type = Path(..., alias=pk_name, description=f"The {model.__name__} record to retrieve by {pk_name}")):
            results = await self._db_session.execute(select(model).where(getattr(model, pk_name) == pk_value))
            records = results.scalars().all()
            if not records:
                raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
            if len(records) > 1:
                raise HTTPException(status_code=400, detail=f"Multiple {model.__name__} records found for {pk_name}={pk_value}")
            return records[0]

    def _add_update_one_route(self, pk_name: str, pk_type: Type, UpdateModel: Type[SQLModel]):
        model = self.model
        @self.router.put(f"/{{{pk_name}}}",
                         response_model=model,
                         description=f"Update a {model.__name__} record by {pk_name}",
                         summary=f"Update {model.__name__} by {pk_name}")
        async def update_one(item: UpdateModel = Body(..., description=f"The {model.__name__} data to update"), 
                             pk_value: pk_type = Path(..., alias=pk_name, description=f"The {model.__name__} record to update by {pk_name}")):
            results = await self._db_session.execute(select(model).where(getattr(model, pk_name) == pk_value))
            db_item = results.scalars().first()
            if not db_item:
                raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
            
            update_data = item.model_dump(exclude_unset=False)
            for key, value in update_data.items():
                setattr(db_item, key, value)
            
            self._db_session.add(db_item)
            await self._db_session.commit()
            await self._db_session.refresh(db_item)
            return db_item

    def _add_patch_one_route(self, pk_name: str, pk_type: Type, PatchModel: Type[SQLModel]):
        model = self.model
        @self.router.patch(f"/{{{pk_name}}}",
                           response_model=model,
                           description=f"Partially update a {model.__name__} record by {pk_name}",
                           summary=f"Patch {model.__name__} by {pk_name}")
        async def patch_one(item: PatchModel = Body(..., description=f"The {model.__name__} data to patch"), 
                            pk_value: pk_type = Path(..., alias=pk_name, description=f"The {model.__name__} record to patch by {pk_name}")):
            results = await self._db_session.execute(select(model).where(getattr(model, pk_name) == pk_value))
            db_item = results.scalars().first()
            if not db_item:
                raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
            
            update_data = item.model_dump(exclude_unset=True)
            for key, value in update_data.items():
                setattr(db_item, key, value)
            
            self._db_session.add(db_item)
            await self._db_session.commit()
            await self._db_session.refresh(db_item)
            return db_item

    def _add_delete_one_route(self, pk_name: str, pk_type: Type):
        model = self.model
        @self.router.delete(f"/{{{pk_name}}}",
                            description=f"Delete a {model.__name__} record by {pk_name}",
                            summary=f"Delete {model.__name__} by {pk_name}")
        async def delete_one(pk_value: pk_type = Path(..., alias=pk_name, description=f"The {model.__name__} record to delete by {pk_name}")):
            results = await self._db_session.execute(select(model).where(getattr(model, pk_name) == pk_value))
            db_item = results.scalars().first()
            if not db_item:
                raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
            
            await self._db_session.delete(db_item)
            await self._db_session.commit()
            return {"detail": f"{model.__name__} deleted"}

    def _add_read_one_by_unique_field_route(self, model_fields: dict):
        model = self.model
        @self.router.get("/unique/{field_name}",
                         response_model=model,
                         description=f"Retrieve a {model.__name__} record by a unique field and value",
                         summary=f"Retrieve {model.__name__} by unique field")
        async def read_one_by_unique_field(
            field_name: str = Path(..., description="The name of the unique field to search by"), 
            value: Any = Query(..., description="The value of the unique field to search for")
        ):
            if field_name not in model_fields:
                raise HTTPException(status_code=400, detail=f"Field '{field_name}' not found in {model.__name__}")

            results = await self._db_session.execute(select(model).where(getattr(model, field_name) == value))
            records = results.scalars().all()

            if not records:
                raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
            if len(records) > 1:
                raise HTTPException(status_code=400, detail=f"Multiple {model.__name__} records found for {field_name}={value}")
            return records[0]

    def _add_read_by_field_route(self, model_fields: dict):
        model = self.model
        @self.router.get("/filter/{field_name}",
                         response_model=List[model],
                         description=f"Retrieve {model.__name__} records by a field and value",
                         summary=f"Retrieve {model.__name__} by field")
        async def read_by_field(
            field_name: str = Path(..., description="The name of the field to filter by"), 
            value: Any = Query(..., description="The value of the field to filter for")
        ):
            if field_name not in model_fields:
                raise HTTPException(status_code=400, detail=f"Field '{field_name}' not found in {model.__name__}")

            results = await self._db_session.execute(select(model).where(getattr(model, field_name) == value))
            return results.scalars().all()

    def _add_relationship_routes(self, pk_name: str, pk_type: Type):
        """Adds nested routes for 1:n relationships."""
        model = self.model
        mapper = inspect(model)
        
        for rel in mapper.relationships:
            # Check if it is a 1:n (uselist=True and not m2m)
            # Actually we can keep read-only for m2m here too as nested list
            if rel.uselist:
                rel_name = rel.key
                target_model = rel.mapper.class_
                
                # Define parameter names to avoid duplicates in nested routes
                model_pk_param = f"{model.__name__.lower()}_{pk_name}"

                def make_read_relationship(r_name, t_model, m_pk_param):
                    @self.router.get(f"/{{{m_pk_param}}}/{r_name}",
                                     response_model=List[Any],
                                     description=f"Retrieve all {r_name} for a specific {model.__name__}",
                                     summary=f"Retrieve {r_name} by {model.__name__} {pk_name}")
                    async def read_relationship(
                        pk_value: pk_type = Path(..., alias=m_pk_param, description=f"The {model.__name__} {pk_name}")
                    ):
                        from sqlalchemy.orm import selectinload
                        stmt = select(model).where(getattr(model, pk_name) == pk_value).options(selectinload(getattr(model, r_name)))
                        results = await self._db_session.execute(stmt)
                        parent = results.scalars().first()
                        if not parent:
                            raise HTTPException(status_code=404, detail=f"{model.__name__} not found")
                        return getattr(parent, r_name)
                    return read_relationship
                
                make_read_relationship(rel_name, target_model, model_pk_param)


class AutoEndpoint:
    """Automatic FastAPI endpoint generator for SQLModel models.

    This class takes a database session and a list of SQLModel models and automatically
    generates a set of CRUD (Create, Read, Update, Delete) endpoints for each model.
    The generated endpoints are registered to a FastAPI APIRouter.

    Attributes:
        _db_session (AsyncSession): The asynchronous database session.
        models (List[Type[SQLModel]]): A list of SQLModel classes to generate endpoints for.
        router (APIRouter): The FastAPI router containing the generated endpoints.
    """

    def __init__(self, db_session: AsyncSession, models: List[Type[SQLModel]], enable_graphql: bool = True):
        """Initializes the AutoEndpoint with a database session and models.

        Args:
            db_session (AsyncSession): The asynchronous SQLAlchemy/SQLModel session.
            models (List[Type[SQLModel]]): A list of SQLModel classes to be exposed via API.
            enable_graphql (bool): Whether to enable the GraphQL endpoint. Defaults to True.
        """
        self._db_session = db_session
        self.models = models
        self.enable_graphql = enable_graphql
        self.router = APIRouter()
        self._build_routes()

    def _build_routes(self):
        """Iterates through all models and registers their endpoints."""
        for model in self.models:
            model_router = ModelRouter(model=model, db_session=self._db_session)
            self.router.include_router(model_router.router)
            self._add_relation_routes(model)
        
        if self.enable_graphql:
            self._add_graphql_route()

    def _add_relation_routes(self, model: Type[SQLModel]):
        """Detects m:n relationships and registers RelationRouter for them."""
        mapper = inspect(model)
        for rel in mapper.relationships:
            if rel.secondary is not None:
                # Many-to-Many relationship
                target_model = rel.mapper.class_
                rel_name = rel.key
                
                # Try to find the link model among registered models
                link_model = None
                for m in self.models:
                    if getattr(m, "__table__", None) is rel.secondary:
                        link_model = m
                        break

                # We instantiate a RelationRouter for this specific relationship.
                # Note: This will create routes like /model_a/{id}/rel_name/{target_id}
                relation_router = RelationRouter(
                    model_a=model, 
                    model_b=target_model, 
                    rel_name=rel_name, 
                    db_session=self._db_session,
                    link_model=link_model
                )
                self.router.include_router(relation_router.router)

    def _add_graphql_route(self):
        """Adds a dynamic GraphQL endpoint using Strawberry."""
        schema = generate_graphql_schema(models=self.models, db_session=self._db_session)
        graphql_app = GraphQLRouter(schema)
        self.router.include_router(graphql_app, prefix="/graphql", tags=["GraphQL"])



    def init_app(self, app):
        """Includes the generated router into a FastAPI application.

        Args:
            app: The FastAPI application instance.
        """
        app.include_router(self.router)
