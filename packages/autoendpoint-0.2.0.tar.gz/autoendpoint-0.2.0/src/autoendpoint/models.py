from typing import Optional, Tuple, Type

from pydantic import create_model
from sqlmodel import SQLModel, Field

from autoendpoint.utils import is_primary_key


def generate_crud_models(model: Type[SQLModel]) -> Tuple[Type[SQLModel], Type[SQLModel], Type[SQLModel]]:
    """Generates Pydantic models for Create, Update, and Patch operations.

    Args:
        model: The source SQLModel class.

    Returns:
        A tuple containing (CreateModel, UpdateModel, PatchModel).
    """
    model_fields = model.model_fields

    def should_exclude(name, field):
        """Determines if a field should be excluded from the CreateModel.
        
        Typically excludes fields that are:
        - Named 'id' (for backward compatibility and standard convention).
        - Primary keys with a default (server-side or local), indicating they are auto-generated.
        """
        if name == "id":
            return True
        
        # Check if it is a primary key
        if is_primary_key(field):
            # We only exclude primary keys if they have a non-None, non-Ellipsis default,
            # or a default_factory, or server-side default/autoincrement.
            # If the default is Ellipsis (...) or PydanticUndefined, it means it's required
            # and not necessarily auto-generated (e.g. SKU).
            
            # Use getattr to avoid potential issues with different Pydantic/SQLModel versions
            default = getattr(field, "default", None)
            default_factory = getattr(field, "default_factory", None)

            # Check for PydanticUndefined which is often used instead of Ellipsis
            is_undefined = False
            try:
                from pydantic_core import PydanticUndefined
                if default is PydanticUndefined:
                    is_undefined = True
            except ImportError:
                pass
                
            if default is not None and default is not ... and not is_undefined:
                return True
            if default_factory is not None:
                return True
            
            # Check sa_column for server_default or autoincrement
            sa_column = getattr(field, "sa_column", None)
            if sa_column is not None and sa_column is not ...:
                if getattr(sa_column, "server_default", None) is not None:
                    return True
                if getattr(sa_column, "autoincrement", False) is True:
                    return True
        return False

    # Exclude auto-generated fields and preserve field constraints
    create_fields = {
        name: (field.annotation, field)
        for name, field in model_fields.items()
        if not should_exclude(name, field)
    }

    CreateModel = create_model(f"{model.__name__}Create", __base__=SQLModel, **create_fields)

    # Update fields (PUT) - same as CreateModel but different name for clarity in docs
    update_fields = create_fields.copy()
    UpdateModel = create_model(f"{model.__name__}Update", __base__=SQLModel, **update_fields)

    # Patch fields (PATCH) - all non-auto-generated fields are optional
    patch_fields = {
        name: (Optional[field.annotation], Field(None))
        for name, field in model_fields.items()
        if not should_exclude(name, field)
    }
    PatchModel = create_model(f"{model.__name__}Patch", __base__=SQLModel, **patch_fields)

    return CreateModel, UpdateModel, PatchModel
