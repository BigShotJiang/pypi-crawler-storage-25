"""
Initialize the template tags
"""
