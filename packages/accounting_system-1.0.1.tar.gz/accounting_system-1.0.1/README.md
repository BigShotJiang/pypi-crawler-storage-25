# Accounting System

A simple Python package for managing basic accounting transactions, including journal and ledger entries.

## Features

- Add transactions easily
- Store and view all transactions
- Simple and lightweight design
- Beginner-friendly structure

## Installation

Install from PyPI:

```bash
pip install accounting_system
```
