from accountingsystem.core import AccountingSystem

def test_basic_usage():
    system = AccountingSystem()
    system.add_entry("2026-01-01", "Cash", "Debit", 500)

    assert len(system.all_Transaction) == 1