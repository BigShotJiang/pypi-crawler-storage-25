class Transaction:
    def __init__(self,date,account,entry_type,amount,description=''):
        self.date = date
        self.account = account
        self.entry_type = entry_type
        self.amount = amount
        self.description = description

    def __str__(self):
        return f"{self.date} | {self.account} | {self.entry_type} | {self.amount} | {self.description}"

class AccountingSystem:
    def __init__(self):
        self.all_Transaction = []
        self.journal = []
        self.ledger = []

    def add_entry(self,date,account,entry_type,amount,description=''):
        self.all_Transaction.append(Transaction(date,account,entry_type,amount,description))

    def view_all_Transaction(self):
        for i in self.all_Transaction:
            print(i)
        
