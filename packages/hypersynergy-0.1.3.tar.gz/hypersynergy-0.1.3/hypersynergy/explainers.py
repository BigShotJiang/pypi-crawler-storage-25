"""
HyperSynergy: Topological Explainability (XAI) Suite
Extracts and translates mathematical manifolds into clinical logic.
"""

import torch
import numpy as np

class NeuMapper:
    """
    Extracts topological and hierarchical knowledge from a trained MATG network.
    """
    
    @staticmethod
    def extract_topological_hierarchy(model, node_indices=None):
        """
        Extracts the alpha (topological) attention weights from the MATG gate.
        These weights determine the 'Quân - Thần - Tá - Sứ' role of the herb.
        
        Args:
            model (MATG_Model): The trained model.
            node_indices (list or None): Specific herbs to inspect. If None, extracts all.
            
        Returns:
            np.ndarray: Array of alpha weights corresponding to the nodes.
        """
        # Ensure the model is in evaluation mode
        model.eval()
        
        # If no specific nodes provided, evaluate the entire vocabulary
        if node_indices is None:
            node_indices = list(range(model.node_top_emb.num_embeddings))
            
        with torch.no_grad():
            t_nodes = torch.LongTensor(node_indices)
            # Use baseline context (Formula 0) to evaluate pure structural synergy
            t_forms = torch.LongTensor([0] * len(node_indices)) 
            
            # Forward pass specifically requesting attention weights
            _, attn_weights = model(t_nodes, t_forms, return_attn=True)
            
            # Convert to a flat numpy array
            alpha_weights = attn_weights.detach().cpu().numpy().flatten()
            
        return alpha_weights

    @staticmethod
    def assign_clinical_roles(alpha_weights, herb_names):
        """
        Maps mathematical alpha weights to Traditional Medicine roles.
        """
        roles = []
        for name, alpha in zip(herb_names, alpha_weights):
            if alpha >= 0.80:
                role = "The Architect (Sovereign/Quân)"
            elif alpha >= 0.60:
                role = "The Bridge (Minister/Thần)"
            else:
                role = "The Buffer (Assistant/Tá)"
                
            roles.append({"herb": name, "alpha": round(float(alpha), 3), "role": role})
            
        # Return sorted by highest topological importance
        return sorted(roles, key=lambda x: x['alpha'], reverse=True)