from setuptools import setup, find_packages

# Read the contents of your README file for the long description on PyPI
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="hypersynergy",
    version="0.1.3",
    author="Vo Thi Kim Anh",
    author_email="vothikimanh@tdtu.edu.vn",
    description="A Topological Graph Neural Network framework for Traditional Medicine synergy prediction.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/vothikimanh1007/HyperSynergy-CDSS",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Medical Science Apps."
    ],
    python_requires='>=3.8',
    install_requires=[
        "torch>=2.0.0",
        "numpy>=1.21.0",
        "pandas>=1.3.0",
        "scikit-learn>=1.3.2",
        "networkx>=2.5"
    ],
)