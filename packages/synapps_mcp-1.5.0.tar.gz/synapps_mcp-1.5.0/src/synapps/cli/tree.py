from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class TreeNode:
    label: str
    children: list[TreeNode] = field(default_factory=list)
    annotation: str | None = None


def render_tree(root: TreeNode) -> str:
    lines: list[str] = []
    label = root.label
    if root.annotation:
        label += f" [{root.annotation}]"
    lines.append(label)
    _render_children(lines, root.children, prefix="")
    return "\n".join(lines)


def _render_children(lines: list[str], children: list[TreeNode], prefix: str) -> None:
    for i, child in enumerate(children):
        is_last = i == len(children) - 1
        connector = "└── " if is_last else "├── "
        label = child.label
        if child.annotation:
            label += f" [{child.annotation}]"
        lines.append(f"{prefix}{connector}{label}")
        extension = "    " if is_last else "│   "
        _render_children(lines, child.children, prefix + extension)


def _flat_tree(symbol_name: str, data: list[dict], annotation: str | None = None) -> TreeNode:
    children = [TreeNode(label=item.get("full_name", "?")) for item in data]
    return TreeNode(label=symbol_name, children=children, annotation=annotation)


def callers_tree(symbol_name: str, data: list[dict], annotation: str | None = None) -> TreeNode:
    return _flat_tree(symbol_name, data, annotation)


def callees_tree(symbol_name: str, data: list[dict], annotation: str | None = None) -> TreeNode:
    return _flat_tree(symbol_name, data, annotation)


def _build_depth_tree(root_label: str, items: list[dict], name_key: str = "full_name") -> TreeNode:
    root = TreeNode(label=root_label)
    stack: list[tuple[TreeNode, int]] = [(root, 0)]
    for item in items:
        depth = item["depth"]
        node = TreeNode(label=item.get(name_key, "?"))
        while len(stack) > 1 and stack[-1][1] >= depth:
            stack.pop()
        stack[-1][0].children.append(node)
        stack.append((node, depth))
    return root



def hierarchy_tree(full_name: str, data: dict) -> TreeNode:
    categories: list[TreeNode] = []
    for key, label in [("parents", "Parents"), ("children", "Children"), ("implements", "Implements")]:
        items = data.get(key, [])
        if items:
            children = [TreeNode(label=item.get("full_name", "?")) for item in items]
            categories.append(TreeNode(label=label, children=children))
    return TreeNode(label=full_name, children=categories)


def _merge_paths_into_tree(root_label: str, paths: list[list[str]], skip_first: bool = True) -> TreeNode:
    root = TreeNode(label=root_label)
    for path in paths:
        current = root
        start = 1 if skip_first else 0
        for step in path[start:]:
            existing = next((c for c in current.children if c.label == step), None)
            if existing:
                current = existing
            else:
                new_node = TreeNode(label=step)
                current.children.append(new_node)
                current = new_node
    return root


def trace_tree(data: dict) -> TreeNode:
    return _merge_paths_into_tree(data["start"], data["paths"])


def entry_points_tree(data: dict) -> TreeNode:
    # Paths flow entry→target (caller→callee). Keep natural top-down direction.
    paths = [ep["path"] for ep in data["entry_points"]]
    return _merge_paths_into_tree(f"→ {data['target']}", paths, skip_first=False)


def dependencies_tree(symbol_name: str, data: list[dict], annotation: str | None = None) -> TreeNode:
    items = [{"full_name": item["type"].get("full_name", "?"), "depth": item["depth"]} for item in data]
    root = _build_depth_tree(symbol_name, items)
    root.annotation = annotation
    return root
