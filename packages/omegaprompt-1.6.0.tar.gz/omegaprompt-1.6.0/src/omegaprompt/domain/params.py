"""Provider-neutral prompt parameter space and variants."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from omegaprompt.domain.enums import (
    OutputBudgetBucket,
    ReasoningProfile,
    ResponseSchemaMode,
    ToolPolicyVariant,
)


class PromptVariants(BaseModel):
    """User-supplied discrete pools of prompt components.

    The searcher picks an index into ``system_prompts`` and a count into
    ``few_shot_examples``. Both axes are first-class in every calibration
    run and cannot be fully disabled (set ``len(system_prompts) == 1`` to
    effectively freeze the system prompt).
    """

    model_config = ConfigDict(extra="forbid")

    system_prompts: list[str] = Field(
        default_factory=list,
        description="Ordered list of candidate system prompt strings.",
    )
    few_shot_examples: list[dict[str, str]] = Field(
        default_factory=list,
        description="Pool of {input, output} dicts used as few-shot demos.",
    )

    @field_validator("system_prompts")
    @classmethod
    def _non_empty_variants(cls, v: list[str]) -> list[str]:
        if not v:
            raise ValueError("PromptVariants.system_prompts must contain at least one prompt.")
        if any(not isinstance(s, str) or not s.strip() for s in v):
            raise ValueError("Every system prompt must be a non-empty string.")
        return v

    @field_validator("few_shot_examples")
    @classmethod
    def _few_shot_shape(cls, v: list[dict[str, str]]) -> list[dict[str, str]]:
        """Each few-shot must have ``input`` and ``output`` non-empty strings.

        Reviewer P1 #10: provider ``_messages()`` indexes ``shot["input"]``
        and ``shot["output"]`` directly. A malformed shot (missing either
        key, or an empty value) would either KeyError mid-eval or silently
        send an empty user/assistant turn that confuses the target.
        Catching it at construction time keeps the failure on the user's
        config, not the eval pipeline.
        """
        for i, shot in enumerate(v):
            if not isinstance(shot, dict):
                raise ValueError(
                    f"few_shot_examples[{i}] must be a dict with 'input' "
                    f"and 'output' keys, got {type(shot).__name__}."
                )
            for key in ("input", "output"):
                val = shot.get(key)
                if not isinstance(val, str) or not val.strip():
                    raise ValueError(
                        f"few_shot_examples[{i}].{key} must be a non-empty "
                        f"string, got {val!r}."
                    )
        return v


class MetaAxisSpace(BaseModel):
    """Declarative bounds for every meta-axis.

    The calibration searcher reads this to decide which values to probe.
    Every axis supports a list of allowed values; an empty list means the
    axis is disabled (only the neutral value is used).
    """

    model_config = ConfigDict(extra="forbid")

    system_prompt_idx_max: int = Field(
        ...,
        ge=0,
        description="Upper bound (inclusive) for the system_prompt index. "
        "Typically len(variants.system_prompts) - 1.",
    )
    few_shot_min: int = Field(default=0, ge=0)
    few_shot_max: int = Field(default=3, ge=0)

    reasoning_profiles: list[ReasoningProfile] = Field(
        default_factory=lambda: [
            ReasoningProfile.OFF,
            ReasoningProfile.STANDARD,
            ReasoningProfile.DEEP,
        ],
        description="Which reasoning profiles the searcher may pick from.",
    )
    output_budgets: list[OutputBudgetBucket] = Field(
        default_factory=lambda: [
            OutputBudgetBucket.SMALL,
            OutputBudgetBucket.MEDIUM,
            OutputBudgetBucket.LARGE,
        ],
    )
    response_schema_modes: list[ResponseSchemaMode] = Field(
        default_factory=lambda: [ResponseSchemaMode.FREEFORM],
        description="Target response shape. Only unlock >1 value when the "
        "target semantics actually vary with schema mode.",
    )
    tool_policy_variants: list[ToolPolicyVariant] = Field(
        default_factory=lambda: [ToolPolicyVariant.NO_TOOLS],
        description="Tool-use policy. Leave at NO_TOOLS for plain chat targets.",
    )

    @field_validator("few_shot_max")
    @classmethod
    def _few_shot_range(cls, v: int, info: Any) -> int:
        few_shot_min = info.data.get("few_shot_min", 0)
        if v < few_shot_min:
            raise ValueError(f"few_shot_max ({v}) must be >= few_shot_min ({few_shot_min}).")
        return v

    @field_validator(
        "reasoning_profiles",
        "output_budgets",
        "response_schema_modes",
        "tool_policy_variants",
    )
    @classmethod
    def _non_empty(cls, v: list, info: Any) -> list:
        if not v:
            raise ValueError(f"{info.field_name} must have at least one member.")
        return v

    def axis_names(self) -> list[str]:
        """Names of the meta-axes, in a stable order."""
        return [
            "system_prompt_variant",
            "few_shot_count",
            "reasoning_profile",
            "output_budget_bucket",
            "response_schema_mode",
            "tool_policy_variant",
        ]


def validate_space_against_variants(
    space: MetaAxisSpace, variants: PromptVariants
) -> None:
    """Cross-validate space bounds against the variant pool sizes.

    Reviewer P1 #10: ``MetaAxisSpace`` and ``PromptVariants`` validate
    independently, so a user can declare ``system_prompt_idx_max=99``
    against a 3-prompt pool and get an ``IndexError`` mid-evaluation
    instead of a clean config-time failure. Likewise ``few_shot_max``
    larger than the few-shot pool causes silent slice-shorter behaviour
    that mis-records ``few_shot_count`` in the artifact (claims 3,
    actually used 1).

    Raises ``ValueError`` if either bound exceeds the corresponding pool.
    """
    if space.system_prompt_idx_max >= len(variants.system_prompts):
        raise ValueError(
            f"MetaAxisSpace.system_prompt_idx_max="
            f"{space.system_prompt_idx_max} exceeds the supplied "
            f"PromptVariants.system_prompts pool size "
            f"({len(variants.system_prompts)}). The largest valid index "
            f"is len(system_prompts) - 1 = {len(variants.system_prompts) - 1}."
        )
    if space.few_shot_max > len(variants.few_shot_examples):
        raise ValueError(
            f"MetaAxisSpace.few_shot_max={space.few_shot_max} exceeds "
            f"the supplied PromptVariants.few_shot_examples pool size "
            f"({len(variants.few_shot_examples)}). Either lower few_shot_max "
            f"or extend the few-shot pool — silent short-slicing would "
            f"mis-record few_shot_count in the artifact."
        )


class ResolvedPromptParams(BaseModel):
    """The concrete parameter set after the searcher's choices are resolved.

    This is what a target adapter consumes. It is semi-typed: enums are
    preserved, not flattened to strings, so the adapter can dispatch
    cleanly.
    """

    model_config = ConfigDict(extra="forbid")

    system_prompt_variant: int
    few_shot_count: int
    reasoning_profile: ReasoningProfile = ReasoningProfile.STANDARD
    output_budget_bucket: OutputBudgetBucket = OutputBudgetBucket.MEDIUM
    response_schema_mode: ResponseSchemaMode = ResponseSchemaMode.FREEFORM
    tool_policy_variant: ToolPolicyVariant = ToolPolicyVariant.NO_TOOLS

    @model_validator(mode="before")
    @classmethod
    def _compat_keys(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        data = dict(data)
        if "system_prompt_idx" in data and "system_prompt_variant" not in data:
            data["system_prompt_variant"] = data.pop("system_prompt_idx")
        if "output_budget" in data and "output_budget_bucket" not in data:
            data["output_budget_bucket"] = data.pop("output_budget")
        if "tool_policy" in data and "tool_policy_variant" not in data:
            data["tool_policy_variant"] = data.pop("tool_policy")
        return data

    @property
    def system_prompt_idx(self) -> int:
        return self.system_prompt_variant

    @property
    def output_budget(self) -> OutputBudgetBucket:
        return self.output_budget_bucket

    @property
    def tool_policy(self) -> ToolPolicyVariant:
        return self.tool_policy_variant
