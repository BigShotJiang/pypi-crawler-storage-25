"""
Type annotations for datazone service literal definitions.

[Documentation](https://youtype.github.io/types_boto3_docs/types_boto3_datazone/literals/)

Copyright 2026 Vlad Emelianov

Usage::

    ```python
    from types_boto3_datazone.literals import AcceptRuleBehaviorType

    data: AcceptRuleBehaviorType = "ALL"
    ```
"""

import sys

if sys.version_info >= (3, 12):
    from typing import Literal
else:
    from typing_extensions import Literal


__all__ = (
    "AcceptRuleBehaviorType",
    "AttributeEntityTypeType",
    "AuthTypeType",
    "AuthenticationTypeType",
    "ChangeActionType",
    "ComputeEnvironmentsType",
    "ConfigurableActionTypeAuthorizationType",
    "ConfigurationStatusType",
    "ConnectionScopeType",
    "ConnectionStatusType",
    "ConnectionTypeType",
    "DataAssetActivityStatusType",
    "DataProductItemTypeType",
    "DataProductStatusType",
    "DataSourceErrorTypeType",
    "DataSourceRunStatusType",
    "DataSourceRunTypeType",
    "DataSourceStatusType",
    "DataZoneEntityTypeType",
    "DataZoneServiceName",
    "DeploymentModeType",
    "DeploymentStatusType",
    "DeploymentTypeType",
    "DomainStatusType",
    "DomainUnitDesignationType",
    "DomainVersionType",
    "EdgeDirectionType",
    "EnableSettingType",
    "EntityTypeType",
    "EnvironmentStatusType",
    "FileFormatType",
    "FilterExpressionTypeType",
    "FilterOperatorType",
    "FilterStatusType",
    "FormTypeStatusType",
    "GlossaryStatusType",
    "GlossaryTermStatusType",
    "GlossaryUsageRestrictionType",
    "GlueConnectionTypeType",
    "GovernanceTypeType",
    "GovernedEntityTypeType",
    "GraphEntityTypeType",
    "GroupProfileStatusType",
    "GroupSearchTypeType",
    "HyperPodOrchestratorType",
    "InventorySearchScopeType",
    "JobRunModeType",
    "JobRunStatusType",
    "JobTypeType",
    "LineageEventProcessingStatusType",
    "LineageImportStatusType",
    "ListAccountPoolsPaginatorName",
    "ListAccountsInAccountPoolPaginatorName",
    "ListAssetFiltersPaginatorName",
    "ListAssetRevisionsPaginatorName",
    "ListConnectionsPaginatorName",
    "ListDataProductRevisionsPaginatorName",
    "ListDataSourceRunActivitiesPaginatorName",
    "ListDataSourceRunsPaginatorName",
    "ListDataSourcesPaginatorName",
    "ListDomainUnitsForParentPaginatorName",
    "ListDomainsPaginatorName",
    "ListEntityOwnersPaginatorName",
    "ListEnvironmentActionsPaginatorName",
    "ListEnvironmentBlueprintConfigurationsPaginatorName",
    "ListEnvironmentBlueprintsPaginatorName",
    "ListEnvironmentProfilesPaginatorName",
    "ListEnvironmentsPaginatorName",
    "ListJobRunsPaginatorName",
    "ListLineageEventsPaginatorName",
    "ListLineageNodeHistoryPaginatorName",
    "ListMetadataGenerationRunsPaginatorName",
    "ListNotebookRunsPaginatorName",
    "ListNotebooksPaginatorName",
    "ListNotificationsPaginatorName",
    "ListPolicyGrantsPaginatorName",
    "ListProjectMembershipsPaginatorName",
    "ListProjectProfilesPaginatorName",
    "ListProjectsPaginatorName",
    "ListRulesPaginatorName",
    "ListSubscriptionGrantsPaginatorName",
    "ListSubscriptionRequestsPaginatorName",
    "ListSubscriptionTargetsPaginatorName",
    "ListSubscriptionsPaginatorName",
    "ListTimeSeriesDataPointsPaginatorName",
    "ListingStatusType",
    "ManagedPolicyTypeType",
    "MetadataGenerationRunStatusType",
    "MetadataGenerationRunTypeType",
    "MetadataGenerationTargetTypeType",
    "NetworkAccessTypeType",
    "NotebookExportStatusType",
    "NotebookRunStatusType",
    "NotebookStatusType",
    "NotificationResourceTypeType",
    "NotificationRoleType",
    "NotificationTypeType",
    "OAuth2GrantTypeType",
    "OpenLineageRunStateType",
    "OverallDeploymentStatusType",
    "PackageManagerType",
    "PaginatorName",
    "ProjectDesignationType",
    "ProjectStatusType",
    "ProtocolType",
    "QueryGraphPaginatorName",
    "RegionName",
    "RejectRuleBehaviorType",
    "RelationDirectionType",
    "RelationTypeType",
    "ResolutionStrategyType",
    "ResourceServiceName",
    "ResourceTagSourceType",
    "RuleActionType",
    "RuleScopeSelectionModeType",
    "RuleTargetTypeType",
    "RuleTypeType",
    "S3PermissionType",
    "SearchGroupProfilesPaginatorName",
    "SearchListingsPaginatorName",
    "SearchOutputAdditionalAttributeType",
    "SearchPaginatorName",
    "SearchTypesPaginatorName",
    "SearchUserProfilesPaginatorName",
    "SelfGrantStatusType",
    "ServiceName",
    "SortFieldAccountPoolType",
    "SortFieldConnectionType",
    "SortFieldProjectType",
    "SortKeyType",
    "SortOrderType",
    "StatusType",
    "SubscriptionGrantCreationModeType",
    "SubscriptionGrantOverallStatusType",
    "SubscriptionGrantStatusType",
    "SubscriptionRequestStatusType",
    "SubscriptionStatusType",
    "TargetEntityTypeType",
    "TaskStatusType",
    "TimeSeriesEntityTypeType",
    "TimezoneType",
    "TriggerSourceTypeType",
    "TypesSearchScopeType",
    "UserAssignmentType",
    "UserDesignationType",
    "UserProfileStatusType",
    "UserProfileTypeType",
    "UserSearchTypeType",
    "UserTypeType",
)


AcceptRuleBehaviorType = Literal["ALL", "NONE"]
AttributeEntityTypeType = Literal["ASSET", "LISTING"]
AuthTypeType = Literal["DISABLED", "IAM_IDC"]
AuthenticationTypeType = Literal["BASIC", "CUSTOM", "OAUTH2"]
ChangeActionType = Literal["PUBLISH", "UNPUBLISH"]
ComputeEnvironmentsType = Literal["ATHENA", "PYTHON", "SPARK"]
ConfigurableActionTypeAuthorizationType = Literal["HTTPS", "IAM"]
ConfigurationStatusType = Literal["COMPLETED", "FAILED"]
ConnectionScopeType = Literal["DOMAIN", "PROJECT"]
ConnectionStatusType = Literal[
    "CREATE_FAILED",
    "CREATING",
    "DELETED",
    "DELETE_FAILED",
    "DELETING",
    "READY",
    "UPDATE_FAILED",
    "UPDATING",
]
ConnectionTypeType = Literal[
    "AMAZON_Q",
    "ATHENA",
    "BIGQUERY",
    "DATABRICKS",
    "DOCUMENTDB",
    "DYNAMODB",
    "HYPERPOD",
    "IAM",
    "MLFLOW",
    "MYSQL",
    "OPENSEARCH",
    "ORACLE",
    "POSTGRESQL",
    "REDSHIFT",
    "S3",
    "SAPHANA",
    "SNOWFLAKE",
    "SPARK",
    "SQLSERVER",
    "TERADATA",
    "VERTICA",
    "WORKFLOWS_MWAA",
]
DataAssetActivityStatusType = Literal[
    "FAILED",
    "PUBLISHING_FAILED",
    "SKIPPED_ALREADY_IMPORTED",
    "SKIPPED_ARCHIVED",
    "SKIPPED_NO_ACCESS",
    "SUCCEEDED_CREATED",
    "SUCCEEDED_UPDATED",
    "UNCHANGED",
]
DataProductItemTypeType = Literal["ASSET"]
DataProductStatusType = Literal["CREATED", "CREATE_FAILED", "CREATING"]
DataSourceErrorTypeType = Literal[
    "ACCESS_DENIED_EXCEPTION",
    "CONFLICT_EXCEPTION",
    "INTERNAL_SERVER_EXCEPTION",
    "RESOURCE_NOT_FOUND_EXCEPTION",
    "SERVICE_QUOTA_EXCEEDED_EXCEPTION",
    "THROTTLING_EXCEPTION",
    "VALIDATION_EXCEPTION",
]
DataSourceRunStatusType = Literal[
    "FAILED", "PARTIALLY_SUCCEEDED", "REQUESTED", "RUNNING", "SUCCESS"
]
DataSourceRunTypeType = Literal["PRIORITIZED", "SCHEDULED"]
DataSourceStatusType = Literal[
    "CREATING",
    "DELETING",
    "FAILED_CREATION",
    "FAILED_DELETION",
    "FAILED_UPDATE",
    "READY",
    "RUNNING",
    "UPDATING",
]
DataZoneEntityTypeType = Literal["DOMAIN_UNIT"]
DeploymentModeType = Literal["ON_CREATE", "ON_DEMAND"]
DeploymentStatusType = Literal["FAILED", "IN_PROGRESS", "PENDING_DEPLOYMENT", "SUCCESSFUL"]
DeploymentTypeType = Literal["CREATE", "DELETE", "UPDATE"]
DomainStatusType = Literal[
    "AVAILABLE", "CREATING", "CREATION_FAILED", "DELETED", "DELETING", "DELETION_FAILED"
]
DomainUnitDesignationType = Literal["OWNER"]
DomainVersionType = Literal["V1", "V2"]
EdgeDirectionType = Literal["DOWNSTREAM", "UPSTREAM"]
EnableSettingType = Literal["DISABLED", "ENABLED"]
EntityTypeType = Literal["ASSET", "DATA_PRODUCT"]
EnvironmentStatusType = Literal[
    "ACTIVE",
    "CREATE_FAILED",
    "CREATING",
    "DELETED",
    "DELETE_FAILED",
    "DELETING",
    "DISABLED",
    "EXPIRED",
    "INACCESSIBLE",
    "SUSPENDED",
    "UPDATE_FAILED",
    "UPDATING",
    "VALIDATION_FAILED",
]
FileFormatType = Literal["IPYNB", "PDF"]
FilterExpressionTypeType = Literal["EXCLUDE", "INCLUDE"]
FilterOperatorType = Literal["EQ", "GE", "GT", "LE", "LT", "TEXT_SEARCH"]
FilterStatusType = Literal["INVALID", "VALID"]
FormTypeStatusType = Literal["DISABLED", "ENABLED"]
GlossaryStatusType = Literal["DISABLED", "ENABLED"]
GlossaryTermStatusType = Literal["DISABLED", "ENABLED"]
GlossaryUsageRestrictionType = Literal["ASSET_GOVERNED_TERMS"]
GlueConnectionTypeType = Literal[
    "BIGQUERY",
    "DOCUMENTDB",
    "DYNAMODB",
    "MYSQL",
    "OPENSEARCH",
    "ORACLE",
    "POSTGRESQL",
    "REDSHIFT",
    "SAPHANA",
    "SNOWFLAKE",
    "SQLSERVER",
    "TERADATA",
    "VERTICA",
]
GovernanceTypeType = Literal["AWS_MANAGED", "USER_MANAGED"]
GovernedEntityTypeType = Literal["ASSET"]
GraphEntityTypeType = Literal["LINEAGE_NODE"]
GroupProfileStatusType = Literal["ASSIGNED", "NOT_ASSIGNED"]
GroupSearchTypeType = Literal["DATAZONE_SSO_GROUP", "IAM_ROLE_SESSION_GROUP", "SSO_GROUP"]
HyperPodOrchestratorType = Literal["EKS", "SLURM"]
InventorySearchScopeType = Literal["ASSET", "DATA_PRODUCT", "GLOSSARY", "GLOSSARY_TERM"]
JobRunModeType = Literal["ON_DEMAND", "SCHEDULED"]
JobRunStatusType = Literal[
    "ABORTED",
    "CANCELED",
    "FAILED",
    "IN_PROGRESS",
    "PARTIALLY_SUCCEEDED",
    "SCHEDULED",
    "SUCCESS",
    "TIMED_OUT",
]
JobTypeType = Literal["LINEAGE"]
LineageEventProcessingStatusType = Literal["FAILED", "PROCESSING", "REQUESTED", "SUCCESS"]
LineageImportStatusType = Literal["FAILED", "IN_PROGRESS", "PARTIALLY_SUCCEEDED", "SUCCESS"]
ListAccountPoolsPaginatorName = Literal["list_account_pools"]
ListAccountsInAccountPoolPaginatorName = Literal["list_accounts_in_account_pool"]
ListAssetFiltersPaginatorName = Literal["list_asset_filters"]
ListAssetRevisionsPaginatorName = Literal["list_asset_revisions"]
ListConnectionsPaginatorName = Literal["list_connections"]
ListDataProductRevisionsPaginatorName = Literal["list_data_product_revisions"]
ListDataSourceRunActivitiesPaginatorName = Literal["list_data_source_run_activities"]
ListDataSourceRunsPaginatorName = Literal["list_data_source_runs"]
ListDataSourcesPaginatorName = Literal["list_data_sources"]
ListDomainUnitsForParentPaginatorName = Literal["list_domain_units_for_parent"]
ListDomainsPaginatorName = Literal["list_domains"]
ListEntityOwnersPaginatorName = Literal["list_entity_owners"]
ListEnvironmentActionsPaginatorName = Literal["list_environment_actions"]
ListEnvironmentBlueprintConfigurationsPaginatorName = Literal[
    "list_environment_blueprint_configurations"
]
ListEnvironmentBlueprintsPaginatorName = Literal["list_environment_blueprints"]
ListEnvironmentProfilesPaginatorName = Literal["list_environment_profiles"]
ListEnvironmentsPaginatorName = Literal["list_environments"]
ListJobRunsPaginatorName = Literal["list_job_runs"]
ListLineageEventsPaginatorName = Literal["list_lineage_events"]
ListLineageNodeHistoryPaginatorName = Literal["list_lineage_node_history"]
ListMetadataGenerationRunsPaginatorName = Literal["list_metadata_generation_runs"]
ListNotebookRunsPaginatorName = Literal["list_notebook_runs"]
ListNotebooksPaginatorName = Literal["list_notebooks"]
ListNotificationsPaginatorName = Literal["list_notifications"]
ListPolicyGrantsPaginatorName = Literal["list_policy_grants"]
ListProjectMembershipsPaginatorName = Literal["list_project_memberships"]
ListProjectProfilesPaginatorName = Literal["list_project_profiles"]
ListProjectsPaginatorName = Literal["list_projects"]
ListRulesPaginatorName = Literal["list_rules"]
ListSubscriptionGrantsPaginatorName = Literal["list_subscription_grants"]
ListSubscriptionRequestsPaginatorName = Literal["list_subscription_requests"]
ListSubscriptionTargetsPaginatorName = Literal["list_subscription_targets"]
ListSubscriptionsPaginatorName = Literal["list_subscriptions"]
ListTimeSeriesDataPointsPaginatorName = Literal["list_time_series_data_points"]
ListingStatusType = Literal["ACTIVE", "CREATING", "INACTIVE"]
ManagedPolicyTypeType = Literal[
    "ADD_TO_PROJECT_MEMBER_POOL",
    "CREATE_ASSET_TYPE",
    "CREATE_DOMAIN_UNIT",
    "CREATE_ENVIRONMENT",
    "CREATE_ENVIRONMENT_FROM_BLUEPRINT",
    "CREATE_ENVIRONMENT_PROFILE",
    "CREATE_FORM_TYPE",
    "CREATE_GLOSSARY",
    "CREATE_PROJECT",
    "CREATE_PROJECT_FROM_PROJECT_PROFILE",
    "DELEGATE_CREATE_ENVIRONMENT_PROFILE",
    "OVERRIDE_DOMAIN_UNIT_OWNERS",
    "OVERRIDE_PROJECT_OWNERS",
    "USE_ASSET_TYPE",
]
MetadataGenerationRunStatusType = Literal[
    "CANCELED", "FAILED", "IN_PROGRESS", "PARTIALLY_SUCCEEDED", "SUBMITTED", "SUCCEEDED"
]
MetadataGenerationRunTypeType = Literal[
    "BUSINESS_DESCRIPTIONS", "BUSINESS_GLOSSARY_ASSOCIATIONS", "BUSINESS_NAMES"
]
MetadataGenerationTargetTypeType = Literal["ASSET"]
NetworkAccessTypeType = Literal["PUBLIC_INTERNET_ONLY", "VPC_ONLY"]
NotebookExportStatusType = Literal["FAILED", "IN_PROGRESS", "SUCCEEDED"]
NotebookRunStatusType = Literal[
    "FAILED", "QUEUED", "RUNNING", "STARTING", "STOPPED", "STOPPING", "SUCCEEDED"
]
NotebookStatusType = Literal["ACTIVE", "ARCHIVED"]
NotificationResourceTypeType = Literal["PROJECT"]
NotificationRoleType = Literal[
    "DOMAIN_OWNER", "PROJECT_CONTRIBUTOR", "PROJECT_OWNER", "PROJECT_SUBSCRIBER", "PROJECT_VIEWER"
]
NotificationTypeType = Literal["EVENT", "TASK"]
OAuth2GrantTypeType = Literal["AUTHORIZATION_CODE", "CLIENT_CREDENTIALS", "JWT_BEARER"]
OpenLineageRunStateType = Literal["ABORT", "COMPLETE", "FAIL", "OTHER", "RUNNING", "START"]
OverallDeploymentStatusType = Literal[
    "FAILED_DEPLOYMENT", "FAILED_VALIDATION", "IN_PROGRESS", "PENDING_DEPLOYMENT", "SUCCESSFUL"
]
PackageManagerType = Literal["UV"]
ProjectDesignationType = Literal["CONTRIBUTOR", "OWNER", "PROJECT_CATALOG_STEWARD"]
ProjectStatusType = Literal[
    "ACTIVE", "DELETE_FAILED", "DELETING", "MOVING", "UPDATE_FAILED", "UPDATING"
]
ProtocolType = Literal[
    "ATHENA", "GLUE_INTERACTIVE_SESSION", "HTTPS", "JDBC", "LIVY", "ODBC", "PRISM"
]
QueryGraphPaginatorName = Literal["query_graph"]
RejectRuleBehaviorType = Literal["ALL", "NONE"]
RelationDirectionType = Literal["IN", "OUT"]
RelationTypeType = Literal["LINEAGE"]
ResolutionStrategyType = Literal["MANUAL"]
ResourceTagSourceType = Literal["PROJECT", "PROJECT_PROFILE"]
RuleActionType = Literal["CREATE_LISTING_CHANGE_SET", "CREATE_SUBSCRIPTION_REQUEST"]
RuleScopeSelectionModeType = Literal["ALL", "SPECIFIC"]
RuleTargetTypeType = Literal["DOMAIN_UNIT"]
RuleTypeType = Literal["GLOSSARY_TERM_ENFORCEMENT", "METADATA_FORM_ENFORCEMENT"]
S3PermissionType = Literal["READ", "WRITE"]
SearchGroupProfilesPaginatorName = Literal["search_group_profiles"]
SearchListingsPaginatorName = Literal["search_listings"]
SearchOutputAdditionalAttributeType = Literal[
    "FORMS", "TEXT_MATCH_RATIONALE", "TIME_SERIES_DATA_POINT_FORMS"
]
SearchPaginatorName = Literal["search"]
SearchTypesPaginatorName = Literal["search_types"]
SearchUserProfilesPaginatorName = Literal["search_user_profiles"]
SelfGrantStatusType = Literal[
    "GRANTED",
    "GRANT_FAILED",
    "GRANT_IN_PROGRESS",
    "GRANT_PENDING",
    "REVOKE_FAILED",
    "REVOKE_IN_PROGRESS",
    "REVOKE_PENDING",
]
SortFieldAccountPoolType = Literal["NAME"]
SortFieldConnectionType = Literal["NAME"]
SortFieldProjectType = Literal["NAME"]
SortKeyType = Literal["CREATED_AT", "UPDATED_AT"]
SortOrderType = Literal["ASCENDING", "DESCENDING"]
StatusType = Literal["DISABLED", "ENABLED"]
SubscriptionGrantCreationModeType = Literal["AUTOMATIC", "MANUAL"]
SubscriptionGrantOverallStatusType = Literal[
    "COMPLETED",
    "GRANT_AND_REVOKE_FAILED",
    "GRANT_FAILED",
    "INACCESSIBLE",
    "IN_PROGRESS",
    "PENDING",
    "REVOKE_FAILED",
]
SubscriptionGrantStatusType = Literal[
    "GRANTED",
    "GRANT_FAILED",
    "GRANT_IN_PROGRESS",
    "GRANT_PENDING",
    "REVOKED",
    "REVOKE_FAILED",
    "REVOKE_IN_PROGRESS",
    "REVOKE_PENDING",
]
SubscriptionRequestStatusType = Literal["ACCEPTED", "PENDING", "REJECTED"]
SubscriptionStatusType = Literal["APPROVED", "CANCELLED", "REVOKED"]
TargetEntityTypeType = Literal[
    "ASSET_TYPE", "DOMAIN_UNIT", "ENVIRONMENT_BLUEPRINT_CONFIGURATION", "ENVIRONMENT_PROFILE"
]
TaskStatusType = Literal["ACTIVE", "INACTIVE"]
TimeSeriesEntityTypeType = Literal["ASSET", "LISTING"]
TimezoneType = Literal[
    "AFRICA_JOHANNESBURG",
    "AMERICA_MONTREAL",
    "AMERICA_SAO_PAULO",
    "ASIA_BAHRAIN",
    "ASIA_BANGKOK",
    "ASIA_CALCUTTA",
    "ASIA_DUBAI",
    "ASIA_HONG_KONG",
    "ASIA_JAKARTA",
    "ASIA_KUALA_LUMPUR",
    "ASIA_SEOUL",
    "ASIA_SHANGHAI",
    "ASIA_SINGAPORE",
    "ASIA_TAIPEI",
    "ASIA_TOKYO",
    "AUSTRALIA_MELBOURNE",
    "AUSTRALIA_SYDNEY",
    "CANADA_CENTRAL",
    "CET",
    "CST6CDT",
    "ETC_GMT",
    "ETC_GMT0",
    "ETC_GMT_ADD_0",
    "ETC_GMT_ADD_1",
    "ETC_GMT_ADD_10",
    "ETC_GMT_ADD_11",
    "ETC_GMT_ADD_12",
    "ETC_GMT_ADD_2",
    "ETC_GMT_ADD_3",
    "ETC_GMT_ADD_4",
    "ETC_GMT_ADD_5",
    "ETC_GMT_ADD_6",
    "ETC_GMT_ADD_7",
    "ETC_GMT_ADD_8",
    "ETC_GMT_ADD_9",
    "ETC_GMT_NEG_0",
    "ETC_GMT_NEG_1",
    "ETC_GMT_NEG_10",
    "ETC_GMT_NEG_11",
    "ETC_GMT_NEG_12",
    "ETC_GMT_NEG_13",
    "ETC_GMT_NEG_14",
    "ETC_GMT_NEG_2",
    "ETC_GMT_NEG_3",
    "ETC_GMT_NEG_4",
    "ETC_GMT_NEG_5",
    "ETC_GMT_NEG_6",
    "ETC_GMT_NEG_7",
    "ETC_GMT_NEG_8",
    "ETC_GMT_NEG_9",
    "EUROPE_DUBLIN",
    "EUROPE_LONDON",
    "EUROPE_PARIS",
    "EUROPE_STOCKHOLM",
    "EUROPE_ZURICH",
    "ISRAEL",
    "MEXICO_GENERAL",
    "MST7MDT",
    "PACIFIC_AUCKLAND",
    "US_CENTRAL",
    "US_EASTERN",
    "US_MOUNTAIN",
    "US_PACIFIC",
    "UTC",
]
TriggerSourceTypeType = Literal["MANUAL", "SCHEDULED", "WORKFLOW"]
TypesSearchScopeType = Literal["ASSET_TYPE", "FORM_TYPE", "LINEAGE_NODE_TYPE"]
UserAssignmentType = Literal["AUTOMATIC", "MANUAL"]
UserDesignationType = Literal[
    "PROJECT_CATALOG_CONSUMER",
    "PROJECT_CATALOG_STEWARD",
    "PROJECT_CATALOG_VIEWER",
    "PROJECT_CONTRIBUTOR",
    "PROJECT_OWNER",
]
UserProfileStatusType = Literal["ACTIVATED", "ASSIGNED", "DEACTIVATED", "NOT_ASSIGNED"]
UserProfileTypeType = Literal["IAM", "SSO"]
UserSearchTypeType = Literal["DATAZONE_IAM_USER", "DATAZONE_SSO_USER", "DATAZONE_USER", "SSO_USER"]
UserTypeType = Literal["IAM_ROLE", "IAM_ROLE_SESSION", "IAM_USER", "SSO_USER"]
DataZoneServiceName = Literal["datazone"]
ServiceName = Literal[
    "accessanalyzer",
    "account",
    "acm",
    "acm-pca",
    "aiops",
    "amp",
    "amplify",
    "amplifybackend",
    "amplifyuibuilder",
    "apigateway",
    "apigatewaymanagementapi",
    "apigatewayv2",
    "appconfig",
    "appconfigdata",
    "appfabric",
    "appflow",
    "appintegrations",
    "application-autoscaling",
    "application-insights",
    "application-signals",
    "applicationcostprofiler",
    "appmesh",
    "apprunner",
    "appstream",
    "appsync",
    "arc-region-switch",
    "arc-zonal-shift",
    "artifact",
    "athena",
    "auditmanager",
    "autoscaling",
    "autoscaling-plans",
    "b2bi",
    "backup",
    "backup-gateway",
    "backupsearch",
    "batch",
    "bcm-dashboards",
    "bcm-data-exports",
    "bcm-pricing-calculator",
    "bcm-recommended-actions",
    "bedrock",
    "bedrock-agent",
    "bedrock-agent-runtime",
    "bedrock-agentcore",
    "bedrock-agentcore-control",
    "bedrock-data-automation",
    "bedrock-data-automation-runtime",
    "bedrock-runtime",
    "billing",
    "billingconductor",
    "braket",
    "budgets",
    "ce",
    "chatbot",
    "chime",
    "chime-sdk-identity",
    "chime-sdk-media-pipelines",
    "chime-sdk-meetings",
    "chime-sdk-messaging",
    "chime-sdk-voice",
    "cleanrooms",
    "cleanroomsml",
    "cloud9",
    "cloudcontrol",
    "clouddirectory",
    "cloudformation",
    "cloudfront",
    "cloudfront-keyvaluestore",
    "cloudhsm",
    "cloudhsmv2",
    "cloudsearch",
    "cloudsearchdomain",
    "cloudtrail",
    "cloudtrail-data",
    "cloudwatch",
    "codeartifact",
    "codebuild",
    "codecatalyst",
    "codecommit",
    "codeconnections",
    "codedeploy",
    "codeguru-reviewer",
    "codeguru-security",
    "codeguruprofiler",
    "codepipeline",
    "codestar-connections",
    "codestar-notifications",
    "cognito-identity",
    "cognito-idp",
    "cognito-sync",
    "comprehend",
    "comprehendmedical",
    "compute-optimizer",
    "compute-optimizer-automation",
    "config",
    "connect",
    "connect-contact-lens",
    "connectcampaigns",
    "connectcampaignsv2",
    "connectcases",
    "connecthealth",
    "connectparticipant",
    "controlcatalog",
    "controltower",
    "cost-optimization-hub",
    "cur",
    "customer-profiles",
    "databrew",
    "dataexchange",
    "datapipeline",
    "datasync",
    "datazone",
    "dax",
    "deadline",
    "detective",
    "devicefarm",
    "devops-agent",
    "devops-guru",
    "directconnect",
    "discovery",
    "dlm",
    "dms",
    "docdb",
    "docdb-elastic",
    "drs",
    "ds",
    "ds-data",
    "dsql",
    "dynamodb",
    "dynamodbstreams",
    "ebs",
    "ec2",
    "ec2-instance-connect",
    "ecr",
    "ecr-public",
    "ecs",
    "efs",
    "eks",
    "eks-auth",
    "elasticache",
    "elasticbeanstalk",
    "elb",
    "elbv2",
    "elementalinference",
    "emr",
    "emr-containers",
    "emr-serverless",
    "entityresolution",
    "es",
    "events",
    "evs",
    "finspace",
    "finspace-data",
    "firehose",
    "fis",
    "fms",
    "forecast",
    "forecastquery",
    "frauddetector",
    "freetier",
    "fsx",
    "gamelift",
    "gameliftstreams",
    "geo-maps",
    "geo-places",
    "geo-routes",
    "glacier",
    "globalaccelerator",
    "glue",
    "grafana",
    "greengrass",
    "greengrassv2",
    "groundstation",
    "guardduty",
    "health",
    "healthlake",
    "iam",
    "identitystore",
    "imagebuilder",
    "importexport",
    "inspector",
    "inspector-scan",
    "inspector2",
    "interconnect",
    "internetmonitor",
    "invoicing",
    "iot",
    "iot-data",
    "iot-jobs-data",
    "iot-managed-integrations",
    "iotdeviceadvisor",
    "iotevents",
    "iotevents-data",
    "iotfleetwise",
    "iotsecuretunneling",
    "iotsitewise",
    "iotthingsgraph",
    "iottwinmaker",
    "iotwireless",
    "ivs",
    "ivs-realtime",
    "ivschat",
    "kafka",
    "kafkaconnect",
    "kendra",
    "kendra-ranking",
    "keyspaces",
    "keyspacesstreams",
    "kinesis",
    "kinesis-video-archived-media",
    "kinesis-video-media",
    "kinesis-video-signaling",
    "kinesis-video-webrtc-storage",
    "kinesisanalytics",
    "kinesisanalyticsv2",
    "kinesisvideo",
    "kms",
    "lakeformation",
    "lambda",
    "launch-wizard",
    "lex-models",
    "lex-runtime",
    "lexv2-models",
    "lexv2-runtime",
    "license-manager",
    "license-manager-linux-subscriptions",
    "license-manager-user-subscriptions",
    "lightsail",
    "location",
    "logs",
    "lookoutequipment",
    "m2",
    "machinelearning",
    "macie2",
    "mailmanager",
    "managedblockchain",
    "managedblockchain-query",
    "marketplace-agreement",
    "marketplace-catalog",
    "marketplace-deployment",
    "marketplace-discovery",
    "marketplace-entitlement",
    "marketplace-reporting",
    "marketplacecommerceanalytics",
    "mediaconnect",
    "mediaconvert",
    "medialive",
    "mediapackage",
    "mediapackage-vod",
    "mediapackagev2",
    "mediastore",
    "mediastore-data",
    "mediatailor",
    "medical-imaging",
    "memorydb",
    "meteringmarketplace",
    "mgh",
    "mgn",
    "migration-hub-refactor-spaces",
    "migrationhub-config",
    "migrationhuborchestrator",
    "migrationhubstrategy",
    "mpa",
    "mq",
    "mturk",
    "mwaa",
    "mwaa-serverless",
    "neptune",
    "neptune-graph",
    "neptunedata",
    "network-firewall",
    "networkflowmonitor",
    "networkmanager",
    "networkmonitor",
    "notifications",
    "notificationscontacts",
    "nova-act",
    "oam",
    "observabilityadmin",
    "odb",
    "omics",
    "opensearch",
    "opensearchserverless",
    "organizations",
    "osis",
    "outposts",
    "panorama",
    "partnercentral-account",
    "partnercentral-benefits",
    "partnercentral-channel",
    "partnercentral-selling",
    "payment-cryptography",
    "payment-cryptography-data",
    "pca-connector-ad",
    "pca-connector-scep",
    "pcs",
    "personalize",
    "personalize-events",
    "personalize-runtime",
    "pi",
    "pinpoint",
    "pinpoint-email",
    "pinpoint-sms-voice",
    "pinpoint-sms-voice-v2",
    "pipes",
    "polly",
    "pricing",
    "proton",
    "qapps",
    "qbusiness",
    "qconnect",
    "quicksight",
    "ram",
    "rbin",
    "rds",
    "rds-data",
    "redshift",
    "redshift-data",
    "redshift-serverless",
    "rekognition",
    "repostspace",
    "resiliencehub",
    "resource-explorer-2",
    "resource-groups",
    "resourcegroupstaggingapi",
    "rolesanywhere",
    "route53",
    "route53-recovery-cluster",
    "route53-recovery-control-config",
    "route53-recovery-readiness",
    "route53domains",
    "route53globalresolver",
    "route53profiles",
    "route53resolver",
    "rtbfabric",
    "rum",
    "s3",
    "s3control",
    "s3files",
    "s3outposts",
    "s3tables",
    "s3vectors",
    "sagemaker",
    "sagemaker-a2i-runtime",
    "sagemaker-edge",
    "sagemaker-featurestore-runtime",
    "sagemaker-geospatial",
    "sagemaker-metrics",
    "sagemaker-runtime",
    "savingsplans",
    "scheduler",
    "schemas",
    "sdb",
    "secretsmanager",
    "security-ir",
    "securityagent",
    "securityhub",
    "securitylake",
    "serverlessrepo",
    "service-quotas",
    "servicecatalog",
    "servicecatalog-appregistry",
    "servicediscovery",
    "ses",
    "sesv2",
    "shield",
    "signer",
    "signer-data",
    "signin",
    "simpledbv2",
    "simspaceweaver",
    "snow-device-management",
    "snowball",
    "sns",
    "socialmessaging",
    "sqs",
    "ssm",
    "ssm-contacts",
    "ssm-guiconnect",
    "ssm-incidents",
    "ssm-quicksetup",
    "ssm-sap",
    "sso",
    "sso-admin",
    "sso-oidc",
    "stepfunctions",
    "storagegateway",
    "sts",
    "supplychain",
    "support",
    "support-app",
    "sustainability",
    "swf",
    "synthetics",
    "taxsettings",
    "textract",
    "timestream-influxdb",
    "timestream-query",
    "timestream-write",
    "tnb",
    "transcribe",
    "transfer",
    "translate",
    "trustedadvisor",
    "uxc",
    "verifiedpermissions",
    "voice-id",
    "vpc-lattice",
    "waf",
    "waf-regional",
    "wafv2",
    "wellarchitected",
    "wickr",
    "wisdom",
    "workdocs",
    "workmail",
    "workmailmessageflow",
    "workspaces",
    "workspaces-instances",
    "workspaces-thin-client",
    "workspaces-web",
    "xray",
]
ResourceServiceName = Literal[
    "cloudformation", "cloudwatch", "dynamodb", "ec2", "glacier", "iam", "s3", "sns", "sqs"
]
PaginatorName = Literal[
    "list_account_pools",
    "list_accounts_in_account_pool",
    "list_asset_filters",
    "list_asset_revisions",
    "list_connections",
    "list_data_product_revisions",
    "list_data_source_run_activities",
    "list_data_source_runs",
    "list_data_sources",
    "list_domain_units_for_parent",
    "list_domains",
    "list_entity_owners",
    "list_environment_actions",
    "list_environment_blueprint_configurations",
    "list_environment_blueprints",
    "list_environment_profiles",
    "list_environments",
    "list_job_runs",
    "list_lineage_events",
    "list_lineage_node_history",
    "list_metadata_generation_runs",
    "list_notebook_runs",
    "list_notebooks",
    "list_notifications",
    "list_policy_grants",
    "list_project_memberships",
    "list_project_profiles",
    "list_projects",
    "list_rules",
    "list_subscription_grants",
    "list_subscription_requests",
    "list_subscription_targets",
    "list_subscriptions",
    "list_time_series_data_points",
    "query_graph",
    "search",
    "search_group_profiles",
    "search_listings",
    "search_types",
    "search_user_profiles",
]
RegionName = Literal[
    "af-south-1",
    "ap-east-1",
    "ap-east-2",
    "ap-northeast-1",
    "ap-northeast-2",
    "ap-northeast-3",
    "ap-south-1",
    "ap-south-2",
    "ap-southeast-1",
    "ap-southeast-2",
    "ap-southeast-3",
    "ap-southeast-4",
    "ap-southeast-5",
    "ap-southeast-6",
    "ap-southeast-7",
    "ca-central-1",
    "ca-west-1",
    "eu-central-1",
    "eu-central-2",
    "eu-north-1",
    "eu-south-1",
    "eu-south-2",
    "eu-west-1",
    "eu-west-2",
    "eu-west-3",
    "il-central-1",
    "me-central-1",
    "me-south-1",
    "mx-central-1",
    "sa-east-1",
    "us-east-1",
    "us-east-2",
    "us-west-1",
    "us-west-2",
]
