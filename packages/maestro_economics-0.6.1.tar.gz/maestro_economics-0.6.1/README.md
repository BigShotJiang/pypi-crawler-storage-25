# RA Compute Worker

Private Python runtime, CLI, and Modal worker for RA Suite compute jobs.

This code must stay in the private RA Suite repository. The public `maestro-economics` repository is only a plugin/skill shell and must not contain CLI, runtime, worker, tests, deployment scripts, or implementation references.

Do not mirror this directory into the public `maestro-economics` repository.
That repository's history was rewritten on 2026-04-27 to remove prior CLI and
worker leakage; new runtime work belongs here only.

## Verify

```bash
PYTHONPATH=src pytest -q tests/test_runtime_handler.py tests/test_modal_worker.py tests/test_cli.py
PYTHONPATH=src python3 -m ruff check src/maestro_economics tests
```

## Deploy Modal Worker

```bash
PYTHONPATH=src modal deploy src/maestro_economics/workers/modal_worker.py
```

## Root-Cause Guards

- Workspace-mode submits send `config.workspace_files`; worker copies only the manifest whitelist plus entrypoint.
- Legacy submits use a bounded fallback walk that skips control directories such as `runs/`, `logs/`, `output/`, `checkpoints/`, `.mecon/`, `.git/`, caches, venvs, and build dirs.
- Setup failures send a terminal `failed` callback instead of leaving DB rows stuck in `running`.
- Runtime adds the entrypoint directory to `sys.path` for normal multi-file workspaces, then restores `sys.path`, environment, signal handlers, and user modules between warm-container jobs.
