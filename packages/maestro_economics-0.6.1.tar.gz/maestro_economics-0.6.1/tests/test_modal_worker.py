from __future__ import annotations

import json
from unittest.mock import Mock

import pytest

from maestro_economics.workers import modal_worker


def test_report_status_retries_and_succeeds(monkeypatch):
    calls = {"count": 0}

    def fake_post(url, json, timeout):  # noqa: ANN001
        calls["count"] += 1
        if calls["count"] < 3:
            raise RuntimeError("temporary network failure")
        response = Mock()
        response.raise_for_status.return_value = None
        return response

    monkeypatch.setattr("httpx.post", fake_post)
    monkeypatch.setattr(modal_worker.time, "sleep", lambda *_args, **_kwargs: None)

    modal_worker._report_status(
        "https://callback.example",
        "job_123",
        "running",
        0.5,
        "Working",
    )

    assert calls["count"] == 3


def test_report_status_raises_after_terminal_callback_exhausts_retries(monkeypatch):
    def fake_post(url, json, timeout):  # noqa: ANN001
        raise RuntimeError("callback unavailable")

    monkeypatch.setattr("httpx.post", fake_post)
    monkeypatch.setattr(modal_worker.time, "sleep", lambda *_args, **_kwargs: None)

    with pytest.raises(RuntimeError, match="Callback delivery failed"):
        modal_worker._report_status(
            "https://callback.example",
            "job_terminal",
            "completed",
            1.0,
            "Done",
            gpu_seconds=5.0,
        )


# Phase 3.5 — post-execute bookkeeping switches from mount-to-mount
# shutil.copyfile (which hit upstream mountpoint-s3#785 ESTALE on long
# jobs) to direct R2 CopyObject. These tests exercise the new helpers
# without requiring real R2 credentials or a Modal container.


def _install_fake_s3(monkeypatch, fake_client: Mock) -> None:
    """Short-circuit the lazy boto3 client init so tests don't need the dep."""
    monkeypatch.setattr(modal_worker, "_s3_client", fake_client)


# Locks the contract that bit production on 2026-04-25: Modal's
# `r2-credentials` Secret exposes the access pair under AWS_*-prefixed
# env vars, not R2_*-prefixed. The first deploy used R2_* and crashed
# every workspace job at meta.json with KeyError. This test fails if
# anyone "fixes" the lookup back to R2_-only.
def test_get_s3_reads_modal_aws_prefixed_env(monkeypatch):
    monkeypatch.setattr(modal_worker, "_s3_client", None)
    monkeypatch.delenv("R2_ACCESS_KEY_ID", raising=False)
    monkeypatch.delenv("R2_SECRET_ACCESS_KEY", raising=False)
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "live-aws-id")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "live-aws-secret")

    seen = {}

    def fake_boto3_client(_service, **kwargs):  # noqa: ANN001
        seen.update(kwargs)
        return Mock()

    fake_boto3 = Mock()
    fake_boto3.client = fake_boto3_client
    monkeypatch.setitem(__import__("sys").modules, "boto3", fake_boto3)

    modal_worker._get_s3()
    assert seen["aws_access_key_id"] == "live-aws-id"
    assert seen["aws_secret_access_key"] == "live-aws-secret"
    assert seen["endpoint_url"] == modal_worker.R2_ENDPOINT


def test_get_s3_falls_back_to_r2_prefix_for_local_dev(monkeypatch):
    """A developer running the worker outside Modal can override with R2_*."""
    monkeypatch.setattr(modal_worker, "_s3_client", None)
    monkeypatch.delenv("AWS_ACCESS_KEY_ID", raising=False)
    monkeypatch.delenv("AWS_SECRET_ACCESS_KEY", raising=False)
    monkeypatch.setenv("R2_ACCESS_KEY_ID", "dev-r2-id")
    monkeypatch.setenv("R2_SECRET_ACCESS_KEY", "dev-r2-secret")

    seen = {}
    fake_boto3 = Mock()
    fake_boto3.client = lambda _service, **kwargs: (seen.update(kwargs) or Mock())
    monkeypatch.setitem(__import__("sys").modules, "boto3", fake_boto3)

    modal_worker._get_s3()
    assert seen["aws_access_key_id"] == "dev-r2-id"
    assert seen["aws_secret_access_key"] == "dev-r2-secret"


def test_get_s3_raises_clearly_when_no_creds(monkeypatch):
    monkeypatch.setattr(modal_worker, "_s3_client", None)
    monkeypatch.delenv("AWS_ACCESS_KEY_ID", raising=False)
    monkeypatch.delenv("AWS_SECRET_ACCESS_KEY", raising=False)
    monkeypatch.delenv("R2_ACCESS_KEY_ID", raising=False)
    monkeypatch.delenv("R2_SECRET_ACCESS_KEY", raising=False)
    with pytest.raises(RuntimeError, match="R2 credentials not found"):
        modal_worker._get_s3()


def test_s3_copy_prefix_paginates_and_preserves_relative_layout(monkeypatch):
    fake_s3 = Mock()
    paginator = Mock()
    paginator.paginate.return_value = [
        {
            "Contents": [
                {"Key": "workspaces/u1/ws/output/final.json"},
                {"Key": "workspaces/u1/ws/output/sub/nested.parquet"},
            ],
        },
    ]
    fake_s3.get_paginator.return_value = paginator
    _install_fake_s3(monkeypatch, fake_s3)

    written = modal_worker._s3_copy_prefix(
        "workspaces/u1/ws/output/",
        "workspaces/u1/ws/runs/20260424-050000_a2c6361c/",
    )

    assert written == [
        "workspaces/u1/ws/runs/20260424-050000_a2c6361c/final.json",
        "workspaces/u1/ws/runs/20260424-050000_a2c6361c/sub/nested.parquet",
    ]
    # Both keys copied, with CopyObject pointed at the same R2 bucket on
    # both sides so the copy stays server-side (no egress through the worker).
    assert fake_s3.copy_object.call_count == 2
    for call in fake_s3.copy_object.call_args_list:
        kwargs = call.kwargs
        assert kwargs["Bucket"] == modal_worker.R2_BUCKET
        assert kwargs["CopySource"]["Bucket"] == modal_worker.R2_BUCKET


def test_s3_copy_prefix_is_idempotent_on_empty_source(monkeypatch):
    # Why: the post-execute branch should no-op (not raise) for runs that
    # produced nothing in output/. forceFailJob on the server already
    # handles absent output; the worker must not turn an empty dir into
    # a post-execute crash.
    fake_s3 = Mock()
    paginator = Mock()
    paginator.paginate.return_value = [{"Contents": []}]
    fake_s3.get_paginator.return_value = paginator
    _install_fake_s3(monkeypatch, fake_s3)

    written = modal_worker._s3_copy_prefix("workspaces/u1/ws/output/", "irrelevant/")
    assert written == []
    assert fake_s3.copy_object.call_count == 0


def test_derive_heartbeat_url_preserves_signature():
    """Heartbeat URL must reuse the callback's HMAC (signed on job_id:expires)."""
    callback = (
        "https://ra.maestro.onl/api/ra/compute/v1/callback/worker/j_1?expires=123&sig=abc"
    )
    hb = modal_worker._derive_heartbeat_url(callback)
    assert hb == (
        "https://ra.maestro.onl/api/ra/compute/v1/callback/worker/j_1/heartbeat"
        "?expires=123&sig=abc"
    )


def test_derive_heartbeat_url_strips_trailing_slash():
    callback = "https://x.test/api/cb/j_1/?expires=1&sig=a"
    assert modal_worker._derive_heartbeat_url(callback) == (
        "https://x.test/api/cb/j_1/heartbeat?expires=1&sig=a"
    )


def test_start_heartbeat_runs_on_a_daemon_thread(monkeypatch):
    """Heartbeat must live on its own daemon so it survives main-thread block."""
    import threading

    started = threading.Event()
    received: dict[str, list] = {"urls": [], "json": []}

    def fake_post(url, json, timeout):  # noqa: ANN001
        received["urls"].append(url)
        received["json"].append(json)
        started.set()
        return object()  # we don't raise_for_status on heartbeats

    monkeypatch.setattr(modal_worker.__dict__.get("httpx", None) or __import__("httpx"), "post", fake_post)
    # The combined Phase-2/4.5 sidecar paces on METRICS_SAMPLE_INTERVAL
    # and emits heartbeats conditionally every HEARTBEAT_INTERVAL_SECONDS.
    # Tight both to make the test fast.
    monkeypatch.setattr(modal_worker, "METRICS_SAMPLE_INTERVAL", 0.01)
    monkeypatch.setattr(modal_worker, "HEARTBEAT_INTERVAL_SECONDS", 0)

    stop = threading.Event()
    thread = modal_worker._start_heartbeat(
        "https://ra.maestro.onl/api/ra/compute/v1/callback/worker/j_1?expires=1&sig=a",
        "j_1",
        stop,
    )
    assert thread.daemon is True, "heartbeat MUST be a daemon thread"
    assert started.wait(timeout=2.0), "heartbeat loop never issued its first POST"
    stop.set()
    thread.join(timeout=2.0)

    heartbeat_urls = [url for url in received["urls"] if "/heartbeat?" in url]
    assert heartbeat_urls, "no heartbeat URL was posted"
    assert heartbeat_urls[0].endswith("/heartbeat?expires=1&sig=a")
    # The heartbeat POST has shape {"job_id": job_id}; metric flush has
    # {"samples": [...]}. Assert we saw a heartbeat-shaped payload.
    heartbeat_payloads = [p for p in received["json"] if p == {"job_id": "j_1"}]
    assert heartbeat_payloads, "no heartbeat-shaped payload was posted"


def test_start_heartbeat_swallows_network_errors(monkeypatch):
    """A heartbeat POST that fails must not crash the sidecar thread."""
    import threading

    calls = {"n": 0}

    def fake_post(url, json, timeout):  # noqa: ANN001
        calls["n"] += 1
        raise RuntimeError("network down")

    monkeypatch.setattr(modal_worker.__dict__.get("httpx", None) or __import__("httpx"), "post", fake_post)
    monkeypatch.setattr(modal_worker, "METRICS_SAMPLE_INTERVAL", 0.01)
    monkeypatch.setattr(modal_worker, "HEARTBEAT_INTERVAL_SECONDS", 0)
    monkeypatch.setattr(modal_worker, "METRICS_BATCH_INTERVAL", 0)

    stop = threading.Event()
    thread = modal_worker._start_heartbeat("https://x.test/cb/j_1?expires=1&sig=a", "j_1", stop)

    # Give it a few iterations to prove the swallow is real.
    import time as _time
    _time.sleep(0.1)
    stop.set()
    thread.join(timeout=2.0)

    assert calls["n"] >= 2, "sidecar died after first error — must stay alive"


def test_derive_metrics_url_uses_shared_workers_path():
    """Metrics endpoint is per-account (/workers/metrics?job_id=...), heartbeat is per-id.

    Different shape on purpose: the metrics batch is big enough that a
    per-id path would inflate the URL size on every POST, while the
    heartbeat body is tiny and the per-id path keeps the signed URL
    short.
    """
    callback = (
        "https://ra.maestro.onl/api/ra/compute/v1/callback/worker/j_1?expires=123&sig=abc"
    )
    metrics_url = modal_worker._derive_metrics_url(callback, "j_1")
    assert "/api/ra/compute/workers/metrics" in metrics_url
    assert "job_id=j_1" in metrics_url
    assert "expires=123" in metrics_url
    assert "sig=abc" in metrics_url


def test_sample_metrics_returns_ts_and_phase_even_on_full_failure(monkeypatch):
    """Even with every source broken, a sample row must have ts + phase.

    Why: the profile query PERCENTILE_CONTs over sparse columns so
    missing gpu_util / cpu is fine, but a row with no ts would be
    unusable. Keep the contract: every call returns a dict with at
    least ts and phase.
    """
    # Force psutil / jax / cgroup / nvidia-smi all to raise by pointing
    # them at names that won't exist.
    import builtins

    real_import = builtins.__import__

    def _raise_import(name, *args, **kwargs):
        if name in {"psutil", "jax", "subprocess"}:
            raise ImportError(f"forced failure: {name}")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", _raise_import)
    sample = modal_worker._sample_metrics("warmup")
    assert "ts" in sample and sample["ts"]
    assert sample["phase"] == "warmup"


def test_s3_put_json_writes_with_content_type(monkeypatch):
    fake_s3 = Mock()
    _install_fake_s3(monkeypatch, fake_s3)

    meta = {"job_id": "j1", "gpu_type": "L4", "timeout": 14700, "config": {"simul": 5}}
    modal_worker._s3_put_json("workspaces/u1/ws/runs/ts_j1/meta.json", meta)

    call = fake_s3.put_object.call_args
    kwargs = call.kwargs
    assert kwargs["Bucket"] == modal_worker.R2_BUCKET
    assert kwargs["Key"] == "workspaces/u1/ws/runs/ts_j1/meta.json"
    assert kwargs["ContentType"] == "application/json"
    assert json.loads(kwargs["Body"].decode("utf-8")) == meta


def test_copy_workspace_sources_uses_manifest_without_scanning_control_dirs(tmp_path):
    r2_workspace = tmp_path / "r2" / "workspaces" / "u1" / "ws1"
    local_code = tmp_path / "local"
    (r2_workspace / "pkg").mkdir(parents=True)
    (r2_workspace / "data").mkdir()
    (r2_workspace / "runs" / "old").mkdir(parents=True)
    (r2_workspace / "logs").mkdir()
    (r2_workspace / "output").mkdir()
    (r2_workspace / ".git").mkdir()
    (r2_workspace / "__pycache__").mkdir()

    (r2_workspace / "run.py").write_text("from pkg.helper import value\n", encoding="utf-8")
    (r2_workspace / "pkg" / "helper.py").write_text("value = 7\n", encoding="utf-8")
    (r2_workspace / "data" / "panel.parquet").write_text("data", encoding="utf-8")
    (r2_workspace / "runs" / "old" / "stale.py").write_text("raise RuntimeError\n", encoding="utf-8")
    (r2_workspace / "logs" / "last.txt").write_text("old log", encoding="utf-8")
    (r2_workspace / "output" / "result.json").write_text("{}", encoding="utf-8")
    (r2_workspace / ".git" / "config").write_text("secret", encoding="utf-8")
    (r2_workspace / "__pycache__" / "run.pyc").write_text("cache", encoding="utf-8")

    copied = modal_worker._copy_workspace_sources(
        r2_workspace,
        local_code,
        ["run.py", "pkg/helper.py", "data/panel.parquet"],
        "run.py",
    )

    assert copied == 2
    assert (local_code / "run.py").exists()
    assert (local_code / "pkg" / "helper.py").exists()
    assert not (local_code / "data").exists()
    assert not (local_code / "runs").exists()
    assert not (local_code / "logs").exists()
    assert not (local_code / "output").exists()
    assert not (local_code / ".git").exists()
    assert not (local_code / "__pycache__").exists()


def test_copy_workspace_sources_rejects_unsafe_manifest_paths(tmp_path):
    r2_workspace = tmp_path / "r2"
    r2_workspace.mkdir()
    with pytest.raises(ValueError, match="Unsafe workspace path"):
        modal_worker._copy_workspace_sources(r2_workspace, tmp_path / "local", ["../secret.py"], "run.py")


def test_copy_workspace_sources_fallback_prunes_control_dirs(tmp_path):
    r2_workspace = tmp_path / "r2"
    local_code = tmp_path / "local"
    (r2_workspace / "pkg").mkdir(parents=True)
    (r2_workspace / "runs" / "old").mkdir(parents=True)
    (r2_workspace / "logs").mkdir()
    (r2_workspace / "output").mkdir()
    (r2_workspace / ".mecon").mkdir()

    (r2_workspace / "run.py").write_text("from pkg.helper import value\n", encoding="utf-8")
    (r2_workspace / "pkg" / "helper.py").write_text("value = 7\n", encoding="utf-8")
    (r2_workspace / "runs" / "old" / "stale.py").write_text("raise RuntimeError\n", encoding="utf-8")
    (r2_workspace / "logs" / "last.txt").write_text("old log", encoding="utf-8")
    (r2_workspace / "output" / "result.json").write_text("{}", encoding="utf-8")
    (r2_workspace / ".mecon" / "manifest.json").write_text("{}", encoding="utf-8")

    copied = modal_worker._copy_workspace_sources(r2_workspace, local_code, None, "run.py")

    assert copied == 2
    assert sorted(path.relative_to(local_code).as_posix() for path in local_code.rglob("*") if path.is_file()) == [
        "pkg/helper.py",
        "run.py",
    ]


def test_run_job_sets_heartbeat_stop_on_no_script_error(monkeypatch, tmp_path):
    """The 2026-04-26 incident class: heartbeat sidecar daemon thread must
    not survive into the next warm-container job. Even on the early-error
    path (no script found), `_heartbeat_stop.set()` must fire and the server
    must receive a terminal failure callback."""
    captured: dict[str, object] = {}
    statuses: list[str] = []

    def fake_start_heartbeat(callback_url, job_id, stop_event, phase_source=None):  # noqa: ANN001
        captured["stop_event"] = stop_event
        return None

    monkeypatch.setattr(modal_worker, "_start_heartbeat", fake_start_heartbeat)
    monkeypatch.setattr(
        modal_worker,
        "_report_status",
        lambda _callback_url, _job_id, status, *_args, **_kwargs: statuses.append(status) or True,
    )
    monkeypatch.setattr(modal_worker, "_s3_put_json", lambda key, body: None)
    # Skip JAX import in the worker so test does not require a CUDA build.
    import sys as _sys
    monkeypatch.setitem(_sys.modules, "jax", Mock())
    # Force the "no script found" path: workspace_path absent, no zip in
    # uploads (R2_MOUNT/uploads/job_id does not exist).
    monkeypatch.setattr(modal_worker, "R2_MOUNT", tmp_path)
    monkeypatch.setattr(modal_worker, "LOCAL_WORK", tmp_path / "work")

    payload = {
        "job_id": "test_job_no_script",
        "callback_url": "https://example/cb?expires=1&sig=x",
        "gpu_type": "L4",
        "timeout": 60,
        "config": {},
    }

    result = modal_worker._run_job(payload)

    assert result["status"] == "error"
    assert statuses[-1] == "failed"
    assert "stop_event" in captured
    assert captured["stop_event"].is_set(), (
        "heartbeat_stop must be set before returning; otherwise the daemon "
        "thread leaks into the next warm-container job"
    )
