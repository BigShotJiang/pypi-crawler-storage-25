"""Tests for runtime.handler."""

from __future__ import annotations

import json
import os
import signal
import sys

import pytest

from maestro_economics.runtime.handler import execute_job


def test_execute_job_runs_run_ctx(tmp_path):
    script = tmp_path / "script.py"
    script.write_text('def run(ctx):\n    return {"answer": 42}\n')
    data_dir = tmp_path / "data"
    data_dir.mkdir()

    result = execute_job(
        script_path=str(script),
        data_dir=str(data_dir),
        output_dir=str(tmp_path / "output"),
        config={},
        progress_cb=lambda p, m: None,
    )

    assert result["answer"] == 42


def test_execute_job_captures_progress_and_logs(tmp_path):
    calls: list[tuple[float, str]] = []
    script = tmp_path / "script.py"
    script.write_text(
        'def run(ctx):\n'
        '    ctx.progress(0.5, "half")\n'
        '    print("hello from job")\n'
        '    return {}\n'
    )
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    output_dir = tmp_path / "output"

    execute_job(
        script_path=str(script),
        data_dir=str(data_dir),
        output_dir=str(output_dir),
        config={},
        progress_cb=lambda p, m: calls.append((p, m)),
    )

    assert (0.5, "half") in calls
    assert "hello from job" in (output_dir / "job.log").read_text()


def test_execute_job_reports_log_activity_without_mutating_progress(tmp_path):
    progress_calls: list[tuple[float, str]] = []
    activity_calls: list[tuple[str, str]] = []
    script = tmp_path / "script.py"
    script.write_text(
        'def run(ctx):\n'
        '    ctx.progress(0.5, "half")\n'
        '    print("gen=5 nfev=75 best=0.12 rate=1.0/s")\n'
        '    return {}\n'
    )
    data_dir = tmp_path / "data"
    data_dir.mkdir()

    execute_job(
        script_path=str(script),
        data_dir=str(data_dir),
        output_dir=str(tmp_path / "output"),
        config={},
        progress_cb=lambda p, m: progress_calls.append((p, m)),
        activity_cb=lambda kind, msg: activity_calls.append((kind, msg)),
    )

    assert progress_calls == [(0.5, "half")]
    assert activity_calls == [("log", "gen=5 nfev=75 best=0.12 rate=1.0/s")]


def test_execute_job_requires_run(tmp_path):
    script = tmp_path / "script.py"
    script.write_text("x = 1\n")
    data_dir = tmp_path / "data"
    data_dir.mkdir()

    with pytest.raises(ValueError, match="must define a run"):
        execute_job(
            script_path=str(script),
            data_dir=str(data_dir),
            output_dir=str(tmp_path / "output"),
            config={},
            progress_cb=lambda p, m: None,
        )


def test_execute_job_writes_results_json(tmp_path):
    script = tmp_path / "script.py"
    script.write_text('def run(ctx):\n    return {"beta": 1.5}\n')
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    output_dir = tmp_path / "output"

    execute_job(
        script_path=str(script),
        data_dir=str(data_dir),
        output_dir=str(output_dir),
        config={},
        progress_cb=lambda p, m: None,
    )

    saved = json.loads((output_dir / "results.json").read_text())
    assert saved["beta"] == 1.5


def test_execute_job_purges_user_modules_between_runs(tmp_path):
    """The 2026-04-26 BCH_347 incident root cause: warm-container `sys.modules`
    cache served Job N+1 the previous job's bytecode. After this fix, Job B
    must see Job A's helper module re-loaded fresh from disk."""
    helper = tmp_path / "smom_helper.py"
    helper.write_text("VERSION = 1\n")
    script_a = tmp_path / "run_a.py"
    script_a.write_text(
        "import sys\n"
        f"sys.path.insert(0, {str(tmp_path)!r})\n"
        "import smom_helper\n"
        "def run(ctx):\n"
        "    return {'version': smom_helper.VERSION}\n"
    )
    data_dir = tmp_path / "data"
    data_dir.mkdir()

    result_a = execute_job(
        script_path=str(script_a),
        data_dir=str(data_dir),
        output_dir=str(tmp_path / "out_a"),
        config={},
        progress_cb=lambda p, m: None,
    )
    assert result_a["version"] == 1

    # Mutate helper on disk -- simulates the customer pushing a patch. Bump
    # the mtime explicitly so Python's .pyc cache (mtime-keyed by default)
    # invalidates even when both writes land in the same wall-clock second.
    helper.write_text("VERSION = 2\n")
    new_mtime = os.stat(helper).st_mtime + 5
    os.utime(helper, (new_mtime, new_mtime))

    script_b = tmp_path / "run_b.py"
    script_b.write_text(
        "import sys\n"
        f"sys.path.insert(0, {str(tmp_path)!r})\n"
        "import smom_helper\n"
        "def run(ctx):\n"
        "    return {'version': smom_helper.VERSION}\n"
    )
    result_b = execute_job(
        script_path=str(script_b),
        data_dir=str(data_dir),
        output_dir=str(tmp_path / "out_b"),
        config={},
        progress_cb=lambda p, m: None,
    )
    # Without the sys.modules purge, this would still be 1 (cached).
    assert result_b["version"] == 2


def test_execute_job_imports_sibling_package_without_user_sys_path_patch(tmp_path):
    """Workspace projects commonly have run.py plus package modules. The worker
    must make the entrypoint directory importable before module load."""
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "helper.py").write_text("VALUE = 42\n", encoding="utf-8")
    script = tmp_path / "run.py"
    script.write_text(
        "from pkg.helper import VALUE\n"
        "def run(ctx):\n"
        "    return {'value': VALUE}\n",
        encoding="utf-8",
    )
    data_dir = tmp_path / "data"
    data_dir.mkdir()

    result = execute_job(
        script_path=str(script),
        data_dir=str(data_dir),
        output_dir=str(tmp_path / "out"),
        config={},
        progress_cb=lambda p, m: None,
    )

    assert result["value"] == 42
    assert str(tmp_path) not in sys.path


def test_execute_job_restores_sys_path_after_module_load_error(tmp_path):
    original_sys_path = list(sys.path)
    script = tmp_path / "run.py"
    script.write_text("import missing_workspace_dependency\n", encoding="utf-8")
    data_dir = tmp_path / "data"
    data_dir.mkdir()

    with pytest.raises(ModuleNotFoundError):
        execute_job(
            script_path=str(script),
            data_dir=str(data_dir),
            output_dir=str(tmp_path / "out"),
            config={},
            progress_cb=lambda p, m: None,
        )

    assert sys.path == original_sys_path


def test_execute_job_restores_os_environ(tmp_path):
    """User code mutating os.environ must not leak into the next job. Modal
    warm container reuses the process; without restore the next user sees
    leftover env vars."""
    sentinel = "MECON_TEST_LEAK_KEY_THAT_SHOULD_NOT_PERSIST"
    assert sentinel not in os.environ
    script = tmp_path / "script.py"
    script.write_text(
        "import os\n"
        "def run(ctx):\n"
        f"    os.environ[{sentinel!r}] = 'leaked'\n"
        "    return {}\n"
    )
    data_dir = tmp_path / "data"
    data_dir.mkdir()

    execute_job(
        script_path=str(script),
        data_dir=str(data_dir),
        output_dir=str(tmp_path / "out"),
        config={},
        progress_cb=lambda p, m: None,
    )

    assert sentinel not in os.environ, "env leak: handler must restore os.environ"


def test_execute_job_restores_sigterm_handler(tmp_path):
    """The cancellation SIGTERM handler must be uninstalled after the job
    so the next warm-container job's setup phase does not see SIGTERM as
    cancellation. The modal_worker installs its own setup-phase handler
    around execute_job; if execute_job leaves its handler behind, the
    setup-phase handler is silently overridden."""
    if sys.platform == "win32":
        pytest.skip("signals on Windows differ")
    original = signal.getsignal(signal.SIGTERM)
    script = tmp_path / "script.py"
    script.write_text("def run(ctx):\n    return {}\n")
    data_dir = tmp_path / "data"
    data_dir.mkdir()

    execute_job(
        script_path=str(script),
        data_dir=str(data_dir),
        output_dir=str(tmp_path / "out"),
        config={},
        progress_cb=lambda p, m: None,
    )

    after = signal.getsignal(signal.SIGTERM)
    assert after == original, "SIGTERM handler leaked from execute_job"
