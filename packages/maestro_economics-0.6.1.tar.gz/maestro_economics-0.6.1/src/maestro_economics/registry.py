"""Method registry for econometric estimators."""
from __future__ import annotations
from typing import Any

_METHODS: dict[str, Any] = {}


def register(name: str):
    """Decorator to register an estimation method."""
    def wrapper(cls):
        _METHODS[name] = cls
        return cls
    return wrapper


def get_method(name: str):
    """Get a registered estimation method."""
    if name not in _METHODS:
        available = ", ".join(sorted(_METHODS))
        raise KeyError(f"Unknown method '{name}'. Available: {available}")
    return _METHODS[name]


def list_methods() -> list[str]:
    """List all registered method names."""
    return sorted(_METHODS.keys())
