"""Maestro Economics -- runtime and implementation reference for agents."""
__version__ = "0.6.1"
