"""mecon -- RA Compute CLI for maestro-economics."""

from __future__ import annotations

import atexit
import base64
import glob as globmod
import hashlib
import http.server
import json
import os
import platform
import secrets
import shutil
import socket
import socketserver
import sys
import tempfile
import threading
import time
import tomllib
import urllib.parse
import uuid
import webbrowser
import zipfile
from importlib.metadata import version as pkg_version

import click
import httpx

CONFIG_DIR = os.path.expanduser("~/.mecon")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.toml")

DEFAULT_API_BASE = "https://ra.maestro.onl"
DEFAULT_PROFILE = "default"
API_PREFIX = "/api/ra/compute/v1"

MECONIGNORE_TEMPLATE = """# mecon ignore -- files excluded from job upload
# Raw data (convert to .parquet first)
*.mat
*.h5
*.hdf5
*.dta
*.npz
*.pkl
*.sav

# Results from previous runs
results/
output/
*.log

# Plots and figures
*.png
*.jpg
*.pdf

# OS / editor junk
.DS_Store
Thumbs.db
"""

RUN_PY_TEMPLATE = '''"""GPU estimation job -- edit this file."""


def run(ctx):
    import pandas as pd

    ctx.progress(0.1, "Loading data")
    # df = pd.read_parquet(f"{ctx.data_dir}/panel.parquet")

    ctx.progress(0.5, "Running estimation")
    # ... your code here ...

    ctx.progress(1.0, "Done")
    return {
        "estimates": {},
        "diagnostics": {"converged": True},
    }
'''

DEFAULT_IGNORE_PATTERNS = {
    "__pycache__",
    ".git",
    ".venv",
    "venv",
    "node_modules",
    ".ipynb_checkpoints",
    ".mypy_cache",
    ".pytest_cache",
}
DEFAULT_IGNORE_EXTENSIONS = {
    ".pyc",
    ".pyo",
    ".mat",
    ".npz",
    ".pkl",
    ".h5",
    ".hdf5",
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".svg",
    ".log",
    ".DS_Store",
}
BANNED_EXTENSIONS = {".mat", ".h5", ".hdf5", ".dta", ".npz", ".pkl", ".sav"}

MANIFEST_DIR = ".mecon"
MANIFEST_FILE = os.path.join(MANIFEST_DIR, "manifest.json")


def _read_all_profiles() -> dict:
    if not os.path.exists(CONFIG_FILE):
        return {}
    with open(CONFIG_FILE, "rb") as file:
        return tomllib.load(file)


def _write_all_profiles(profiles: dict) -> None:
    os.makedirs(CONFIG_DIR, mode=0o700, exist_ok=True)
    lines: list[str] = []
    for name, values in profiles.items():
        lines.append(f"[{name}]")
        for key, value in values.items():
            lines.append(f'{key} = "{value}"')
        lines.append("")
    with open(CONFIG_FILE, "w", encoding="utf-8") as file:
        file.write("\n".join(lines))
    os.chmod(CONFIG_FILE, 0o600)


def _get_active_profile() -> str:
    ctx = click.get_current_context(silent=True)
    if ctx and ctx.obj:
        profile = ctx.obj.get("profile")
        if profile:
            return profile
    return os.environ.get("MECON_PROFILE", DEFAULT_PROFILE)


def get_config() -> dict:
    profiles = _read_all_profiles()
    profile_name = _get_active_profile()
    cfg = profiles.get(profile_name, profiles.get(DEFAULT_PROFILE, {}))

    api_key = os.environ.get("MECON_API_KEY") or cfg.get("api_key", "")
    api_base = os.environ.get("MECON_API_BASE") or cfg.get("api_base", DEFAULT_API_BASE)

    ctx = click.get_current_context(silent=True)
    if ctx and ctx.obj:
        endpoint = ctx.obj.get("endpoint_override")
        if endpoint:
            api_base = endpoint

    return {"api_key": api_key, "api_base": api_base}


# Populated by api() on every successful response. The server rides version
# hints along on X-Mecon-Latest / X-Mecon-Min-Supported headers for every
# /api/ra/compute/v1/* reply, so we never pay a dedicated version-check
# round trip. `_maybe_show_upgrade_notice` reads this at the end of
# high-signal commands; `_enforce_min_supported` refuses to proceed if the
# server advertises a floor above the installed version.
_version_hints: dict[str, str | None] = {"latest": None, "min_supported": None}


def _capture_version_hints(response: "httpx.Response") -> None:
    latest = response.headers.get("X-Mecon-Latest") or response.headers.get("x-mecon-latest")
    min_supported = response.headers.get("X-Mecon-Min-Supported") or response.headers.get(
        "x-mecon-min-supported"
    )
    if latest:
        _version_hints["latest"] = latest.strip()
    if min_supported:
        _version_hints["min_supported"] = min_supported.strip()


def _version_tuple(version: str) -> tuple[int, ...]:
    """Parse a dotted version string into a comparable tuple.

    Stops at the first non-integer segment (e.g. `0.4.0rc1` -> (0, 4, 0)) so
    a malformed server hint never raises inside the client.
    """
    parts: list[int] = []
    for segment in version.split("."):
        digits = ""
        for ch in segment:
            if ch.isdigit():
                digits += ch
            else:
                break
        if not digits:
            break
        parts.append(int(digits))
    return tuple(parts)


def _is_older(local: str, remote: str) -> bool:
    try:
        return _version_tuple(local) < _version_tuple(remote)
    except Exception:
        return False


def _maybe_show_upgrade_notice() -> None:
    """Stderr one-liner when installed mecon is behind the server's latest.

    No-op if the server never announced a hint (pre-header servers, or
    network failures that skipped the header capture). Never blocks.
    """
    latest = _version_hints.get("latest")
    if not latest:
        return
    local = _get_version()
    if not _is_older(local, latest):
        return
    click.echo(
        f"mecon {latest} is available (installed: {local}). "
        f"Upgrade: pip install -U maestro-economics",
        err=True,
    )


def _enforce_min_supported() -> None:
    """Refuse to run when the server says we're below the minimum supported.

    Applied at the top of mutating/long-running commands (submit, setup,
    login, sync) so users don't submit jobs through a CLI that could
    deserialize responses incorrectly.
    """
    min_supported = _version_hints.get("min_supported")
    if not min_supported:
        return
    local = _get_version()
    if not _is_older(local, min_supported):
        return
    click.echo(
        f"mecon {local} is below the minimum supported version {min_supported}. "
        f"Upgrade required: pip install -U maestro-economics",
        err=True,
    )
    sys.exit(2)


# Show the upgrade hint at process exit so every command that talked to the
# server surfaces the notice once (including `mecon list`, `mecon status`,
# etc.) without the hint being tied to any specific command handler. No-op
# if no server call was made (hint dict is empty).
atexit.register(_maybe_show_upgrade_notice)


def api(
    method: str,
    path: str,
    json_data: dict | None = None,
    timeout: float = 30,
    raw: bool = False,
    extra_headers: dict | None = None,
) -> dict | httpx.Response:
    """HTTP client for the RA Compute API.

    Retry policy: on transport errors (ConnectError/TimeoutException/HTTPError)
    or 5xx responses, retry up to 3 attempts with exponential backoff
    (1s, 2s). 4xx responses return immediately — they are permanent client
    errors and retrying will not help. POST retries are safe because the
    atomic submission endpoint (/v1/runs) is idempotent when the caller
    provides an `Idempotency-Key` header; GET/DELETE are inherently safe.
    """
    cfg = get_config()
    if not cfg["api_key"]:
        click.echo("Error: No API key. Run 'mecon setup' first.", err=True)
        sys.exit(1)
    url = f"{cfg['api_base']}{API_PREFIX}{path}"
    headers = {"Authorization": f"Bearer {cfg['api_key']}"}
    if extra_headers:
        headers.update(extra_headers)

    MAX_ATTEMPTS = 3
    last_err: Exception | None = None
    response: httpx.Response | None = None

    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            response = httpx.request(
                method,
                url,
                json=json_data,
                headers=headers,
                timeout=timeout,
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError) as exc:
            last_err = exc
            if attempt < MAX_ATTEMPTS:
                click.echo(
                    f"Warning: request failed ({exc.__class__.__name__}: {exc}); "
                    f"retrying {attempt}/{MAX_ATTEMPTS}...",
                    err=True,
                )
                time.sleep(2 ** (attempt - 1))
                continue
            kind = (
                "cannot connect"
                if isinstance(exc, httpx.ConnectError)
                else "timed out"
                if isinstance(exc, httpx.TimeoutException)
                else "network request failed"
            )
            click.echo(
                f"Error: {kind} after {MAX_ATTEMPTS} attempts: {exc}", err=True
            )
            sys.exit(1)

        # Process headers on every response, including those we plan to retry,
        # so the min-version enforcement stays consistent.
        _capture_version_hints(response)
        _enforce_min_supported()

        # 5xx: retryable. Surface the body so operators can see what the
        # server said; treat it as transient only up to MAX_ATTEMPTS.
        if response.status_code >= 500 and attempt < MAX_ATTEMPTS:
            click.echo(
                f"Warning: server returned {response.status_code} "
                f"({response.text[:200] or '<empty body>'}); "
                f"retrying {attempt}/{MAX_ATTEMPTS}...",
                err=True,
            )
            time.sleep(2 ** (attempt - 1))
            continue

        # 4xx or exhausted 5xx: surface and exit.
        if response.status_code >= 400:
            click.echo(
                f"Error {response.status_code}: {response.text or '<empty body>'}",
                err=True,
            )
            sys.exit(1)

        break  # 2xx/3xx: done retrying

    # Defensive: we should have either returned, slept+continued, or sys.exit'd
    # inside the loop. If we ever fall through here without a response, surface
    # the last error loudly.
    if response is None:
        click.echo(
            f"Error: exhausted retries without a response. Last error: {last_err}",
            err=True,
        )
        sys.exit(1)

    if raw:
        return response
    body = response.json()
    if isinstance(body, dict) and "success" in body:
        if body.get("success") is False:
            err = body.get("error") or body.get("message") or "request failed"
            click.echo(f"Error: {err}", err=True)
            sys.exit(1)
        return body.get("data", body)
    return body


def _get_version() -> str:
    try:
        return pkg_version("maestro-economics")
    except Exception:
        return "0.2.0"


def _dir_to_project_name(dir_path: str) -> str:
    abs_path = os.path.abspath(dir_path)
    return abs_path.replace("/", "-").replace("\\", "-")


def _file_md5(path: str) -> str:
    digest = hashlib.md5()
    with open(path, "rb") as file:
        while True:
            chunk = file.read(8192)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _load_manifest() -> dict | None:
    if not os.path.exists(MANIFEST_FILE):
        return None
    with open(MANIFEST_FILE, encoding="utf-8") as file:
        return json.load(file)


def _save_manifest(manifest: dict) -> None:
    os.makedirs(MANIFEST_DIR, exist_ok=True)
    with open(MANIFEST_FILE, "w", encoding="utf-8") as file:
        json.dump(manifest, file, indent=2)


def _validate_project(dir_path: str, entry: str | None = None) -> None:
    entry_file = entry or "run.py"
    errors: list[str] = []

    if not os.path.exists(os.path.join(dir_path, entry_file)):
        errors.append(f"Entry point '{entry_file}' not found. Create it or use --entry.")

    banned_found: list[str] = []
    for root, dirs, files in os.walk(dir_path):
        dirs[:] = [directory for directory in dirs if directory not in DEFAULT_IGNORE_PATTERNS]
        for file_name in files:
            _, ext = os.path.splitext(file_name)
            if ext.lower() in BANNED_EXTENSIONS:
                rel = os.path.relpath(os.path.join(root, file_name), dir_path)
                banned_found.append(rel)

    if banned_found:
        errors.append(
            f"Found {len(banned_found)} raw data file(s) that should be converted to .parquet:\n"
            + "\n".join(f"    {file_name}" for file_name in banned_found[:5])
            + ("\n    ..." if len(banned_found) > 5 else "")
            + "\n  Convert with: df.to_parquet('data/name.parquet')"
            + "\n  Or add to .meconignore if not needed for this job."
        )

    entry_path = os.path.join(dir_path, entry_file)
    if os.path.exists(entry_path):
        with open(entry_path, encoding="utf-8") as file:
            content = file.read()
        if "def run(ctx" not in content and "def run(" not in content:
            errors.append(f"'{entry_file}' must define: def run(ctx) -> dict")

    if errors:
        click.echo("Project validation failed:", err=True)
        for idx, error in enumerate(errors, 1):
            click.echo(f"  {idx}. {error}", err=True)
        click.echo("\nRun 'mecon init' to create a valid project structure.", err=True)
        sys.exit(1)


def _load_meconignore(dir_path: str) -> list[str]:
    ignore_file = os.path.join(dir_path, ".meconignore")
    if not os.path.exists(ignore_file):
        return []
    with open(ignore_file, encoding="utf-8") as file:
        return [line.strip() for line in file if line.strip() and not line.startswith("#")]


def _should_ignore(path: str, ignore_patterns: list[str]) -> bool:
    import fnmatch

    for pattern in ignore_patterns:
        if fnmatch.fnmatch(path, pattern) or fnmatch.fnmatch(os.path.basename(path), pattern):
            return True
    return False


def _zip_directory(dir_path: str) -> str:
    dir_path = os.path.abspath(dir_path)
    base_name = os.path.basename(dir_path.rstrip("/"))
    ignore_patterns = _load_meconignore(dir_path)
    tmp = tempfile.NamedTemporaryFile(suffix=".zip", delete=False, prefix=f"{base_name}_")
    tmp.close()
    file_count = 0
    with zipfile.ZipFile(tmp.name, "w", zipfile.ZIP_DEFLATED) as archive:
        for root, dirs, files in os.walk(dir_path):
            dirs[:] = [
                directory
                for directory in dirs
                if directory not in DEFAULT_IGNORE_PATTERNS and not directory.startswith(".")
            ]
            for file_name in files:
                if file_name.startswith("."):
                    continue
                _, ext = os.path.splitext(file_name)
                if ext in DEFAULT_IGNORE_EXTENSIONS:
                    continue
                full = os.path.join(root, file_name)
                arcname = os.path.relpath(full, dir_path)
                if _should_ignore(arcname, ignore_patterns):
                    continue
                archive.write(full, arcname)
                file_count += 1
    zip_size = os.path.getsize(tmp.name)
    click.echo(f"  {file_count} files, {zip_size / 1024:.0f} KB")

    max_size = 50 * 1024 * 1024
    if zip_size > max_size:
        os.unlink(tmp.name)
        click.echo(
            f"Error: zip is {zip_size / 1024 / 1024:.1f} MB (limit: 50 MB).\n"
            "Reduce data size:\n"
            "  - Convert .mat/.h5 to .parquet (extract only needed columns)\n"
            "  - Add large files to .meconignore\n"
            "  - Use --data for separate data files",
            err=True,
        )
        sys.exit(1)

    return tmp.name


def _submit_workspace(
    manifest: dict,
    gpu: str,
    timeout: int,
    config: dict,
    entry: str | None,
    no_watch: bool,
) -> None:
    """Submit a workspace-mode run via the atomic POST /v1/runs endpoint.

    One request does create + credit-hold + Modal-dispatch atomically. The
    Idempotency-Key header makes the request safe to retry at the transport
    layer (handled inside `api()`); the server deduplicates replays and
    returns the cached run verbatim.
    """
    workspace_id = manifest.get("workspace_id", "")
    files = manifest.get("files", {})

    unsynced = [path for path, info in files.items() if info.get("synced_at") is None]
    if unsynced:
        click.echo(
            f"Error: {len(unsynced)} unsynced files. Run 'mecon sync' before submit.",
            err=True,
        )
        for file_name in unsynced[:5]:
            click.echo(f"  + {file_name}", err=True)
        sys.exit(1)

    entry_file = entry or manifest.get("entry", "run.py")
    workspace_files = sorted(files.keys())
    run_config = {**config, "entry": entry_file, "workspace_files": workspace_files}
    max_time = run_config.get("max_time") or run_config.get("maxTime")
    if isinstance(max_time, (int, float)) and max_time > timeout:
        timeout = int(max_time)
        click.echo(f"Using --timeout {timeout}s from config.max_time")

    # Per-submission idempotency key. Preserved across the `api()` helper's
    # transport-level retries so the server's idempotency_key unique-index
    # recognizes replays and avoids double credit holds / double Modal calls.
    idem_key = str(uuid.uuid4())

    click.echo(f"Submitting run ({len(files)} tracked files)...")
    # 90s timeout accommodates Modal cold-start (typically 20-40s) plus the
    # server's maxDuration ceiling of 60s.
    data = api(
        "POST",
        "/runs",
        json_data={
            "workspace_id": workspace_id,
            "gpu_type": gpu,
            "timeout_seconds": timeout,
            **({"config": run_config} if run_config else {}),
        },
        extra_headers={"Idempotency-Key": idem_key},
        timeout=90,
    )

    if not isinstance(data, dict):
        click.echo(f"Error: unexpected response shape: {data!r}", err=True)
        sys.exit(1)

    run_id = data.get("run_id") or data.get("job_id", "")
    modal_id = data.get("modal_call_id") or "?"
    status = data.get("status", "?")
    replayed = data.get("replayed", False)
    suffix = " (replayed)" if replayed else ""
    # Print the FULL run_id: the customer's agent, CI synthetic tests, and
    # shell scripts all need to feed it back into `mecon status/logs/watch`
    # which requires a full UUID. A prior shortened display (run_id[:8])
    # tripped the api-regression.yml workflow on 2026-04-21.
    click.echo(f"Run {run_id} {status} on Modal ({modal_id}){suffix}.")

    if no_watch:
        click.echo(f"Use 'mecon watch {run_id}' to monitor.")
        return

    click.echo("Watching progress...")
    terminal_states = {"completed", "failed", "cancelled"}
    while True:
        time.sleep(3)
        poll = api("GET", f"/jobs/{run_id}")
        job_resp = poll if isinstance(poll, dict) else {}
        poll_status = job_resp.get("status", "unknown")
        message = job_resp.get("progress_message", "") or ""
        pct = job_resp.get("progress_pct", 0)
        click.echo(f"\r[{run_id[:8]}] {poll_status}  {pct}  {message:<50}", nl=False)
        if poll_status in terminal_states:
            click.echo()
            if poll_status == "completed":
                click.echo("Run completed successfully.")
            elif poll_status == "failed":
                error = job_resp.get("error_message", "") or ""
                click.echo(f"Run failed: {error}")
                _print_failure_advice(run_id, job_resp, include_logs=True)
            break


@click.group()
@click.version_option(version=_get_version(), prog_name="mecon")
@click.option("--profile", envvar="MECON_PROFILE", default=None, help="Config profile (default: 'default')")
@click.option("--endpoint", envvar="MECON_API_BASE", default=None, help="API endpoint URL override")
@click.pass_context
def main(ctx: click.Context, profile: str | None, endpoint: str | None) -> None:
    """mecon -- RA Compute CLI for economists."""
    ctx.ensure_object(dict)
    if profile:
        ctx.obj["profile"] = profile
    if endpoint:
        ctx.obj["endpoint_override"] = endpoint


@main.command()
@click.option("--profile", "profile_name", default=None, help="Profile name (default: 'default')")
@click.option("--api-key", default=None, help="API key value for non-interactive setup")
@click.option("--api-base", default=None, help="API endpoint URL for non-interactive setup")
def setup(profile_name: str | None, api_key: str | None, api_base: str | None) -> None:
    """Set API key and endpoint for a profile."""
    name = profile_name or _get_active_profile()
    profiles = _read_all_profiles()
    existing = profiles.get(name, {})
    interactive = api_key is None and api_base is None

    if api_key is None:
        api_key = click.prompt("API key", default=existing.get("api_key", ""), show_default=False)
    if api_base is None:
        default_base = existing.get("api_base", DEFAULT_API_BASE)
        if interactive:
            api_base = click.prompt("API endpoint", default=default_base)
        else:
            api_base = default_base

    profiles[name] = {"api_key": api_key, "api_base": api_base}
    _write_all_profiles(profiles)
    click.echo(f"Profile [{name}] saved to {CONFIG_FILE}")

    # Ping /balance so the very first mecon command the user runs after
    # `setup` already sees the server's version hints and refuses to proceed
    # if the installed CLI is below the minimum supported version.
    try:
        api("GET", "/balance", timeout=10)
    except SystemExit:
        pass


@main.command()
def profiles() -> None:
    """List all configured profiles."""
    all_profiles = _read_all_profiles()
    active = _get_active_profile()
    if not all_profiles:
        click.echo("No profiles configured. Run 'mecon setup' to create one.")
        return
    for name, values in all_profiles.items():
        marker = "*" if name == active else " "
        base = values.get("api_base", DEFAULT_API_BASE)
        key = values.get("api_key", "")
        key_display = f"{key[:8]}...{key[-4:]}" if len(key) > 12 else "(not set)"
        click.echo(f"  {marker} [{name}]  {base}  key={key_display}")


@main.command()
def balance() -> None:
    """Show credit balance."""
    data = api("GET", "/balance")
    click.echo(json.dumps(data, indent=2))


@main.command()
@click.argument("name", default=".")
def init(name: str) -> None:
    """Initialize a GPU compute project directory."""
    project_dir = os.path.abspath(name)
    if name != "." and os.path.exists(project_dir):
        click.echo(f"Error: {project_dir} already exists.", err=True)
        sys.exit(1)

    os.makedirs(os.path.join(project_dir, "data"), exist_ok=True)
    os.makedirs(os.path.join(project_dir, "output"), exist_ok=True)

    ignore_path = os.path.join(project_dir, ".meconignore")
    if not os.path.exists(ignore_path):
        with open(ignore_path, "w", encoding="utf-8") as file:
            file.write(MECONIGNORE_TEMPLATE)

    run_path = os.path.join(project_dir, "run.py")
    if not os.path.exists(run_path):
        with open(run_path, "w", encoding="utf-8") as file:
            file.write(RUN_PY_TEMPLATE)

    click.echo(f"Initialized project at {project_dir}")
    click.echo("  run.py         -- entry point (edit this)")
    click.echo("  data/          -- put .csv/.parquet here")
    click.echo("  output/        -- results written here (auto-uploaded)")
    click.echo("  .meconignore   -- exclude patterns")
    click.echo()
    click.echo("Next: add data, edit run.py, then: mecon submit .")


def _format_age(seconds: int | None) -> str:
    """Human-friendly age string for last-update / last-heartbeat delta."""
    if seconds is None:
        return "—"
    if seconds < 60:
        return f"{seconds}s"
    if seconds < 3600:
        return f"{seconds // 60}m {seconds % 60:02d}s"
    h, rem = divmod(seconds, 3600)
    return f"{h}h {rem // 60:02d}m"


def _render_liveness_summary(job: dict) -> list[str]:
    """Return the human-readable liveness lines for a status row.

    Why inline and not a single JSON dump: a customer agent polling in
    /loop needs a stable visual cue (⚠ STALLED) that is grep-friendly
    and doesn't require parsing the full response. The server already
    computes is_stalled + heartbeat_stale, so the CLI just surfaces.
    """
    seconds_since_update = job.get("seconds_since_update")
    seconds_since_activity = job.get("seconds_since_activity")
    seconds_since_progress = job.get("seconds_since_progress")
    seconds_since_heartbeat = job.get("seconds_since_heartbeat")
    is_stalled = bool(job.get("is_stalled"))
    heartbeat_stale = bool(job.get("heartbeat_stale"))

    lines = [
        f"Last update:    {_format_age(seconds_since_update)} ago"
        + ("  ⚠ STALLED" if is_stalled else ""),
    ]
    if seconds_since_activity is not None:
        lines.append(f"Last activity:  {_format_age(seconds_since_activity)} ago")
    if seconds_since_progress is not None:
        lines.append(f"Last progress:  {_format_age(seconds_since_progress)} ago")
    if seconds_since_heartbeat is not None:
        lines.append(
            f"Last heartbeat: {_format_age(seconds_since_heartbeat)} ago"
            + ("  ⚠ CONTAINER DEAD" if heartbeat_stale else ""),
        )
    return lines


GPU_UPGRADE_TARGET = {
    "t4": "l4",
    "l4": "l40s",
    "a10g": "l40s",
    "l40s": "a100",
    "a100": "h100",
}

OOM_MARKERS = (
    "out of memory",
    "cuda_error_out_of_memory",
    "cuda out of memory",
    "resource_exhausted",
    "failed to allocate",
    "xla_runtime_error",
    "oom-kill",
    "oom kill",
)

XLA_HANG_MARKERS = (
    "xla jit compile hang",
    "jit warmup",
    "worker progress callback silent",
    "worker activity silent",
    "main python thread blocked",
)


def _gpu_upgrade_target(gpu_type: object) -> str:
    gpu = str(gpu_type or "l4").lower()
    return GPU_UPGRADE_TARGET.get(gpu, "l40s")


def _profile_summary(profile: dict | None) -> dict:
    if not isinstance(profile, dict):
        return {}
    summary = profile.get("summary")
    return summary if isinstance(summary, dict) else {}


def _vram_line(summary: dict) -> str | None:
    used = summary.get("gpu_mem_used_max_mb")
    total = summary.get("gpu_mem_total_mb")
    if not isinstance(used, (int, float)) or not isinstance(total, (int, float)) or total <= 0:
        return None
    pct = (float(used) / float(total)) * 100
    return f"VRAM peak {int(used)} / {int(total)} MB ({pct:.1f}%)."


def _failure_advice_lines(
    job: dict,
    logs_content: str = "",
    profile: dict | None = None,
) -> list[str]:
    error = str(job.get("error_message") or "")
    progress_message = str(job.get("progress_message") or "")
    gpu_type = str(job.get("gpu_type") or (profile or {}).get("gpu_type") or "l4").lower()
    text = "\n".join([error, progress_message, logs_content]).lower()
    summary = _profile_summary(profile)
    vram_line = _vram_line(summary)
    cgroup_oom = any(
        isinstance(summary.get(key), (int, float)) and float(summary.get(key) or 0) > 0
        for key in ("cgroup_oom_count_max", "cgroup_oom_kill_count_max")
    )
    target = _gpu_upgrade_target(gpu_type)

    if cgroup_oom or any(marker in text for marker in OOM_MARKERS):
        lines = [
            f"Diagnosis: GPU/XLA out of memory on {gpu_type}.",
            f"Action: retry with a larger tier, e.g. `mecon submit . --gpu {target}`.",
            "Also reduce the static JAX graph if possible: smaller choice/menu grid, no BIPOP, smaller batch, fewer simultaneous candidates.",
        ]
        if vram_line:
            lines.insert(1, f"Metrics: {vram_line}")
        return lines

    if any(marker in text for marker in XLA_HANG_MARKERS):
        lines = [
            "Diagnosis: XLA/JIT compile hang or blocked main thread; this is not proven GPU OOM.",
            "Action: run `mecon precompile . --timeout 600` before resubmitting and shrink the JAX compile graph if it times out.",
        ]
        if vram_line:
            lines.insert(1, f"Metrics: {vram_line}")
            used = summary.get("gpu_mem_used_max_mb")
            total = summary.get("gpu_mem_total_mb")
            if isinstance(used, (int, float)) and isinstance(total, (int, float)) and total > 0:
                if float(used) / float(total) >= 0.7:
                    lines.append(
                        f"L4 has limited compile headroom here; if precompile passes but GPU still fails, retry with `--gpu {target}`."
                    )
                else:
                    lines.append("Metrics do not show VRAM saturation; upgrading GPU alone may not help.")
        return lines

    recommendation = (profile or {}).get("recommendation") if isinstance(profile, dict) else None
    if isinstance(recommendation, dict) and recommendation.get("suggestion") == "step_up":
        rationale = str(recommendation.get("rationale") or "")
        return [
            f"Diagnosis: this job is saturating {gpu_type}.",
            f"Action: retry with `mecon submit . --gpu {target}`.",
            *([f"Metrics: {rationale}"] if rationale else []),
        ]

    return []


def _try_fetch_dict(path: str) -> dict | None:
    try:
        data = api("GET", path)
    except SystemExit:
        return None
    except Exception:
        return None
    return data if isinstance(data, dict) else None


def _try_fetch_logs(job_id: str) -> str:
    data = _try_fetch_dict(f"/jobs/{job_id}/logs?since=0")
    if not isinstance(data, dict):
        return ""
    return str(data.get("content") or "")


def _print_failure_advice(job_id: str, job: dict, include_logs: bool = False) -> None:
    logs_content = _try_fetch_logs(job_id) if include_logs else ""
    profile = _try_fetch_dict(f"/jobs/{job_id}/profile")
    lines = _failure_advice_lines(job, logs_content, profile)
    if not lines:
        return
    click.echo("\nFailure diagnosis:")
    for line in lines:
        click.echo(f"  {line}")
    if include_logs and logs_content:
        tail = "\n".join(logs_content.splitlines()[-50:])
        click.echo(f"\n  --- last log chunk(s) ---\n{tail}\n  ---")


@main.command()
@click.argument("job_id")
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Dump raw JSON (stable machine-readable shape). Default: human summary.",
)
def status(job_id: str, as_json: bool) -> None:
    """Show job status with liveness summary.

    The human summary surfaces is_stalled + heartbeat_stale so an agent
    polling in /loop never sees a zombie '14%' progress bar without a
    warning. Use --json for stable machine-readable output.
    """
    data = api("GET", f"/jobs/{job_id}")
    if as_json:
        click.echo(json.dumps(data, indent=2))
        return
    if not isinstance(data, dict):
        click.echo(json.dumps(data, indent=2))
        return

    status_value = data.get("status", "unknown")
    progress = data.get("progress_pct", 0)
    message = data.get("progress_message", "") or ""
    click.echo(f"Job {job_id}")
    click.echo(f"  Status:   {status_value}")
    click.echo(f"  Progress: {progress}%  {message}")
    for line in _render_liveness_summary(data):
        click.echo(f"  {line}")
    error_message = data.get("error_message")
    if error_message:
        click.echo("\n  error_message:")
        for line in str(error_message).splitlines():
            click.echo(f"    {line}")
    if status_value == "failed":
        _print_failure_advice(job_id, data, include_logs=False)


@main.command()
@click.argument("job_id")
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Dump raw JSON (stable machine-readable shape). Default: human summary.",
)
def profile(job_id: str, as_json: bool) -> None:
    """Show GPU / CPU / memory profile for a completed job, with tier advice.

    Pulls the per-sample metrics the worker sidecar uploaded (Phase 4.5),
    aggregates to p50/p95/max, and surfaces a tier-down / tier-up / keep
    recommendation. Run after any completed job to right-size the next
    run. No-op when the job is too old (30-day retention) or ran before
    Phase 4.5 shipped (sample_count will be 0).
    """
    data = api("GET", f"/jobs/{job_id}/profile")
    if as_json:
        click.echo(json.dumps(data, indent=2))
        return
    if not isinstance(data, dict):
        click.echo(json.dumps(data, indent=2))
        return

    summary = data.get("summary") or {}
    recommendation = data.get("recommendation") or {}
    gpu_type = data.get("gpu_type", "unknown")

    click.echo(f"Profile for {job_id}  (tier: {gpu_type})")
    click.echo(f"  samples:        {summary.get('sample_count', 0)}")

    def _fmt(v: object, unit: str = "") -> str:
        return "—" if v is None else f"{v}{unit}"

    click.echo(
        f"  gpu_util:       p50={_fmt(summary.get('gpu_util_p50'), '%')}  "
        f"p95={_fmt(summary.get('gpu_util_p95'), '%')}  "
        f"max={_fmt(summary.get('gpu_util_max'), '%')}"
    )
    click.echo(
        f"  vram peak:      {_fmt(summary.get('gpu_mem_used_max_mb'), ' MB')} / "
        f"{_fmt(summary.get('gpu_mem_total_mb'), ' MB')}"
    )
    click.echo(
        f"  cpu_pct:        p50={_fmt(summary.get('cpu_pct_p50'), '%')}  "
        f"p95={_fmt(summary.get('cpu_pct_p95'), '%')}"
    )
    click.echo(f"  rss peak:       {_fmt(summary.get('rss_peak_mb'), ' MB')}")
    click.echo(f"  jax peak:       {_fmt(summary.get('jax_peak_mb'), ' MB')}")
    click.echo(f"  cgroup peak:    {_fmt(summary.get('cgroup_mem_peak_mb'), ' MB')}")
    suggestion = recommendation.get("suggestion", "insufficient_data")
    rationale = recommendation.get("rationale", "")
    marker = {
        "step_down": "↓",
        "step_up": "↑",
        "keep": "=",
        "insufficient_data": "?",
    }.get(suggestion, "?")
    click.echo(f"\n  Recommendation: {marker} {suggestion}")
    if rationale:
        click.echo(f"    {rationale}")


@main.command(name="list")
@click.option("--status", "job_status", default=None, help="Filter by status")
@click.option("--limit", default=10, help="Max jobs to show")
def list_jobs(job_status: str | None, limit: int) -> None:
    """List recent jobs."""
    params: dict[str, str | int] = {"limit": limit}
    if job_status:
        params["status"] = job_status
    query_string = "&".join(f"{key}={value}" for key, value in params.items())
    jobs = api("GET", f"/jobs?{query_string}")
    if not isinstance(jobs, list) or not jobs:
        click.echo("No jobs found.")
        return
    # Show the full UUID so callers (especially agents) can pipe directly into
    # `mecon status <id>` / `mecon logs <id>`. The server matches on exact id,
    # so abbreviated prefixes would always 404.
    for job in jobs:
        job_id = job.get("id") or job.get("job_id") or ""
        status_value = job.get("status", "unknown")
        created = job.get("created_at", "")
        click.echo(f"{job_id}  {status_value:<12}  {created}")


@main.command()
@click.argument("job_id")
def cancel(job_id: str) -> None:
    """Cancel a running job."""
    data = api("POST", f"/jobs/{job_id}/cancel")
    click.echo(json.dumps(data, indent=2))


@main.command()
@click.argument("job_id")
@click.option("--interval", default=3, help="Poll interval in seconds")
@click.option(
    "--no-escalate",
    is_flag=True,
    help="Disable auto-log-pull when the server flips is_stalled/heartbeat_stale.",
)
def watch(job_id: str, interval: int, no_escalate: bool) -> None:
    """Live-poll job progress until completion.

    Auto-escalation (Phase 4): when the server flips is_stalled or
    heartbeat_stale on a poll, pull the last ~50 log lines from the
    worker so the user / agent sees *why* the job froze without having
    to round-trip to `mecon logs`. The escalation fires once per stall
    transition (not every poll) so the output stays readable.
    """
    terminal_states = {"completed", "failed", "cancelled"}
    # Latched so we don't re-dump logs every poll while the stall persists.
    escalated_stall = False
    escalated_heartbeat = False

    while True:
        job = api("GET", f"/jobs/{job_id}")
        if not isinstance(job, dict):
            job = {}
        status_value = job.get("status", "unknown")
        progress = job.get("progress_pct", job.get("progress", 0))
        message = job.get("progress_message", "") or ""
        is_stalled = bool(job.get("is_stalled"))
        heartbeat_stale = bool(job.get("heartbeat_stale"))
        flags = ""
        if heartbeat_stale:
            flags += "  ⚠ CONTAINER DEAD"
        elif is_stalled:
            flags += "  ⚠ STALLED"

        line = f"[{job_id[:8]}] {status_value}  {progress}%  {message}{flags}"
        click.echo(f"\r{line:<100}", nl=False)

        # Auto-escalate on stall transitions. Heartbeat-stale is the
        # stronger signal (container dead) — handle it first so the user
        # sees the right diagnosis when both flips happen on the same poll.
        should_escalate = (
            (heartbeat_stale and not escalated_heartbeat)
            or (is_stalled and not escalated_stall)
        )
        if should_escalate and not no_escalate:
            click.echo()
            if heartbeat_stale:
                click.echo(
                    "⚠  Heartbeat silent for "
                    f"{_format_age(job.get('seconds_since_heartbeat'))}. "
                    "The worker container appears dead (OOM, preempt, node failure)."
                )
                escalated_heartbeat = True
            else:
                click.echo(
                    "⚠  Worker progress silent for "
                    f"{_format_age(job.get('seconds_since_update'))}. "
                    "Likely XLA compile hang or blocked main thread. "
                    "See docs/cases/2026-04-24-xla-jit-compile-hang.md."
                )
                escalated_stall = True
            click.echo("   Pulling last log chunks…")
            try:
                log_resp = api("GET", f"/jobs/{job_id}/logs?since=0")
                content = (
                    log_resp.get("content", "") if isinstance(log_resp, dict) else ""
                )
                if content:
                    tail = "\n".join(content.splitlines()[-50:])
                    click.echo(f"   --- last log chunk(s) ---\n{tail}\n   ---")
                else:
                    click.echo(
                        "   (no log chunks yet — worker never reached ctx.log().  "
                        "Stall likely happened before user code ran.)"
                    )
            except SystemExit:
                # api() exits on its own error path; re-raise to keep
                # watch's outer behaviour intact.
                raise
            except Exception as exc:  # noqa: BLE001
                click.echo(f"   (log pull failed: {exc})")

        if status_value in terminal_states:
            click.echo()
            if status_value == "completed":
                click.echo("Job completed.")
            elif status_value == "failed":
                error = job.get("error_message", "") or ""
                click.echo(f"Job failed: {error}")
                _print_failure_advice(
                    job_id,
                    job,
                    include_logs=(not no_escalate and not (escalated_heartbeat or escalated_stall)),
                )
            else:
                click.echo("Job cancelled.")
            break
        time.sleep(interval)


@main.command()
@click.argument("job_id")
@click.option("-f", "--follow", is_flag=True, help="Follow log output (poll for new chunks)")
@click.option("--interval", default=2, help="Poll interval in seconds (with -f)")
def logs(job_id: str, follow: bool, interval: int) -> None:
    """Display job logs. Use -f to follow in real-time."""
    since = 0
    while True:
        response = api("GET", f"/jobs/{job_id}/logs?since={since}", raw=True)
        if isinstance(response, httpx.Response):
            if response.headers.get("content-type", "").startswith("application/json"):
                data = response.json()
            else:
                data = {"content": response.text, "next_since": since}
        else:
            data = response
        content = data.get("content", "")
        if content:
            click.echo(content, nl=False)
        next_since = data.get("next_since", since)
        if isinstance(next_since, int):
            since = next_since
        if not follow:
            if content:
                click.echo()
            job_status = data.get("status", "unknown") if isinstance(data, dict) else "unknown"
            error_message = data.get("error_message") if isinstance(data, dict) else None
            if error_message:
                click.echo(f"--- Job {job_status} ---")
                click.echo(f"error_message: {error_message}")
                profile = _try_fetch_dict(f"/jobs/{job_id}/profile")
                lines = _failure_advice_lines(
                    {"status": job_status, "error_message": error_message},
                    content,
                    profile,
                )
                if lines:
                    click.echo("\nFailure diagnosis:")
                    for line in lines:
                        click.echo(f"  {line}")
            break
        job_data = api("GET", f"/jobs/{job_id}")
        job_status = job_data.get("status", "unknown") if isinstance(job_data, dict) else "unknown"
        if job_status in {"completed", "failed", "cancelled"}:
            final_response = api("GET", f"/jobs/{job_id}/logs?since={since}", raw=True)
            if isinstance(final_response, httpx.Response):
                if final_response.headers.get("content-type", "").startswith("application/json"):
                    final = final_response.json()
                else:
                    final = {"content": final_response.text}
            else:
                final = final_response
            final_content = final.get("content", "")
            if final_content:
                click.echo(final_content, nl=False)
            click.echo(f"\n--- Job {job_status} ---")
            break
        time.sleep(interval)


@main.command()
@click.argument("job_id")
@click.option("--log-lines", default=200, help="Max trailing log lines to include")
def debug(job_id: str, log_lines: int) -> None:
    """Dump everything needed to diagnose a job in a single call.

    Shows status JSON, highlights `error_message`, and streams the trailing
    worker logs. Designed for agent consumption -- one invocation, all the
    context you'd otherwise need to stitch together from `status` + `logs`.
    """
    status_data = api("GET", f"/jobs/{job_id}")
    click.echo("=== status ===")
    click.echo(json.dumps(status_data, indent=2))

    if isinstance(status_data, dict):
        error_message = status_data.get("error_message") or ""
        if error_message:
            click.echo("\n=== error_message ===")
            click.echo(error_message)

    click.echo("\n=== logs (most recent) ===")
    response = api("GET", f"/jobs/{job_id}/logs?since=0", raw=True)
    if isinstance(response, httpx.Response):
        if response.headers.get("content-type", "").startswith("application/json"):
            data = response.json()
        else:
            data = {"content": response.text}
    else:
        data = response
    content = data.get("content", "") if isinstance(data, dict) else ""
    if not content:
        click.echo("(no logs)")
    else:
        lines = content.splitlines()
        if len(lines) > log_lines:
            click.echo(f"(truncated — showing last {log_lines} of {len(lines)} lines)")
            lines = lines[-log_lines:]
        for line in lines:
            click.echo(line)

    profile_data = _try_fetch_dict(f"/jobs/{job_id}/profile")
    if profile_data is not None:
        click.echo("\n=== profile ===")
        click.echo(json.dumps(profile_data, indent=2))

    if isinstance(status_data, dict):
        lines = _failure_advice_lines(status_data, content, profile_data)
        if lines:
            click.echo("\n=== diagnosis ===")
            for line in lines:
                click.echo(line)


@main.command()
@click.argument("job_id")
@click.option("-o", "--output", default="./results", help="Output directory")
def download(job_id: str, output: str) -> None:
    """Download results for a completed job."""
    job_data = api("GET", f"/jobs/{job_id}")
    job = job_data.get("data", job_data) if isinstance(job_data, dict) else job_data
    status_value = job.get("status", "unknown") if isinstance(job, dict) else "unknown"

    if status_value != "completed":
        click.echo(f"Job status is '{status_value}'. Results available only for completed jobs.", err=True)
        if status_value == "failed":
            error = job.get("error_message", "") if isinstance(job, dict) else ""
            click.echo(f"Error: {error}", err=True)
        sys.exit(1)

    data = api("GET", f"/jobs/{job_id}/results")
    files = data.get("files", []) if isinstance(data, dict) else data
    if not files:
        result_url = job.get("result_url", "") if isinstance(job, dict) else ""
        if result_url:
            files = [{"name": "results.zip", "url": result_url}]
        else:
            click.echo("No result files available.")
            return

    os.makedirs(output, exist_ok=True)
    for file_info in files:
        url = file_info.get("url", "")
        name = file_info.get("name", file_info.get("filename", "result"))
        click.echo(f"Downloading {name}...")
        response = httpx.get(url, timeout=300, follow_redirects=True)
        if response.status_code >= 400:
            click.echo(f"  Download failed: HTTP {response.status_code}", err=True)
            continue
        file_path = os.path.join(output, name)
        with open(file_path, "wb") as file:
            file.write(response.content)
        click.echo(f"  Saved to {file_path}")
        if name.endswith(".zip"):
            with zipfile.ZipFile(file_path, "r") as archive:
                archive.extractall(output)
            os.unlink(file_path)
            click.echo(f"  Extracted to {output}/")
    click.echo("Download complete.")


# ---------------------------------------------------------------------------
# `mecon precompile` — local JIT-compile preflight
#
# Motivation: a customer burned 4 hours of L4 GPU time on 2026-04-24 because
# their JAX graph hit a known XLA compile hang (jax-ml/jax#26767). The hang
# reproduces on CPU, so a local precompile catches it in minutes instead of
# hours of cloud time. See
# ra-suite docs/cases/2026-04-24-xla-jit-compile-hang.md.
#
# Convention: user's `run(ctx)` should fast-exit when `ctx.precompile_only`
# is True, after it has run its first `evaluator.evaluate_single(x)` (the
# step that triggers XLA compile). If `run` is structured this way we
# exercise the compile path; if not, precompile still runs the code under
# a deadline and catches hangs, it just takes longer.
# ---------------------------------------------------------------------------


_PRECOMPILE_HARNESS = r'''
import json, os, signal, sys, time, traceback

os.environ.setdefault("JAX_PLATFORMS", "cpu")
os.environ.setdefault("JAX_DISABLE_JIT", "0")  # we WANT the JIT compile

WORKDIR = {workdir!r}
ENTRY   = {entry_path!r}
CFG     = json.loads({config_json!r})

sys.path.insert(0, WORKDIR)

class PrecompileCtx:
    precompile_only = True
    data_dir = os.path.join(WORKDIR, "data")
    output_dir = "/tmp/mecon_precompile_out"
    checkpoint_dir = "/tmp/mecon_precompile_ckpt"
    log_dir = "/tmp/mecon_precompile_logs"
    config = CFG

    def progress(self, pct, msg=""):
        print(f"[precompile] progress={{pct:.2f}} msg={{msg}}", flush=True)

    def log(self, msg):
        print(f"[precompile] log: {{msg}}", flush=True)

for d in (PrecompileCtx.output_dir, PrecompileCtx.checkpoint_dir, PrecompileCtx.log_dir):
    os.makedirs(d, exist_ok=True)

namespace = {{"__name__": "__main__", "__file__": ENTRY}}
with open(ENTRY) as fh:
    source = fh.read()

try:
    exec(compile(source, ENTRY, "exec"), namespace)
except SystemExit:
    raise
except Exception:
    traceback.print_exc()
    sys.exit(2)

run_fn = namespace.get("run")
if not callable(run_fn):
    print("[precompile] ERROR: no run(ctx) function in", ENTRY, file=sys.stderr)
    sys.exit(3)

t0 = time.time()
try:
    run_fn(PrecompileCtx())
except SystemExit:
    raise
except Exception:
    traceback.print_exc()
    sys.exit(4)
elapsed = time.time() - t0
print(f"[precompile] OK elapsed={{elapsed:.1f}}s")
'''


@main.command()
@click.argument("target", type=click.Path(exists=True), default=None, required=False)
@click.option("--entry", default="run.py", show_default=True, help="Entry point (must define run(ctx))")
@click.option(
    "--timeout",
    "precompile_timeout",
    default=600,
    type=int,
    show_default=True,
    help="Deadline in seconds. JAX JIT compile hangs (jax-ml#26767) always exceed this.",
)
@click.option(
    "--config",
    "run_config",
    default=None,
    help='JSON config forwarded to ctx.config (use a SMALL smoke config, e.g. simul=1)',
)
def precompile(target: str | None, entry: str, precompile_timeout: int, run_config: str | None) -> None:
    """Locally JIT-compile run.py on CPU to catch XLA hangs before submit.

    Runs your `run(ctx)` under JAX_PLATFORMS=cpu with a deadline. If compile
    hangs past the deadline, exit non-zero with a link to the case file.

    Structure `run` to exit early when `ctx.precompile_only` is True:

        def run(ctx):
            evaluator = make_evaluator(...)
            evaluator.evaluate_single(x0)  # JIT compile happens here
            if getattr(ctx, "precompile_only", False):
                ctx.log("precompile OK")
                return {"precompile_ok": True}
            # ... rest of the search ...
    """
    import subprocess

    workdir = os.path.abspath(target) if target else os.getcwd()
    entry_path = os.path.join(workdir, entry)
    if not os.path.exists(entry_path):
        click.echo(f"Error: {entry_path} not found", err=True)
        sys.exit(1)

    config_json = run_config if run_config else "{}"
    try:
        json.loads(config_json)
    except json.JSONDecodeError as exc:
        click.echo(f"Error: --config is not valid JSON: {exc}", err=True)
        sys.exit(1)

    harness = _PRECOMPILE_HARNESS.format(
        workdir=workdir,
        entry_path=entry_path,
        config_json=config_json,
    )

    click.echo(
        f"[precompile] {entry} on CPU (JAX_PLATFORMS=cpu), timeout={precompile_timeout}s",
    )
    try:
        result = subprocess.run(
            [sys.executable, "-c", harness],
            timeout=precompile_timeout,
            cwd=workdir,
        )
    except subprocess.TimeoutExpired:
        click.echo(
            f"\n❌ PRECOMPILE TIMED OUT after {precompile_timeout}s.",
            err=True,
        )
        click.echo(
            "   The JAX/XLA compile is hanging. This job will also hang on GPU.",
            err=True,
        )
        click.echo(
            "   Known upstream bug: https://github.com/jax-ml/jax/issues/26767",
            err=True,
        )
        click.echo(
            "   Workaround: mark non-varying args as static_argnames in your jit;",
            err=True,
        )
        click.echo(
            "   see docs/cases/2026-04-24-xla-jit-compile-hang.md.",
            err=True,
        )
        sys.exit(124)

    sys.exit(result.returncode)


# GPU tiers exposed to `mecon submit --gpu`. Must stay in sync with the
# worker image's GPU_SPECS / @app.function registrations. Source of truth:
# src/maestro_economics/workers/modal_worker.py:GPU_SPECS. VRAM + rough
# price included so the CLI help text is useful at selection time.
GPU_TIERS: list[tuple[str, int, str]] = [
    ("t4", 16, "smoke / CI"),
    ("l4", 24, "small-medium JAX (default)"),
    ("a10g", 24, "same VRAM, faster on some ops"),
    ("l40s", 48, "first safe tier for XLA compile pressure"),
    ("a100", 80, "large structural estimation"),
    ("h100", 80, "parallel / largest"),
]
GPU_CHOICES = [tier[0] for tier in GPU_TIERS]


def _gpu_tier_help() -> str:
    rows = "\n".join(
        f"    {name:<6} {vram:>3}GB  {note}" for name, vram, note in GPU_TIERS
    )
    return f"GPU tier. Valid options:\n{rows}"


@main.command()
@click.argument("target", type=click.Path(exists=True), default=None, required=False)
@click.option("--data", "data_files", multiple=True, type=click.Path(exists=True), help="Data files to upload")
@click.option(
    "--gpu",
    type=click.Choice(GPU_CHOICES, case_sensitive=False),
    default="l4",
    show_default=True,
    help=_gpu_tier_help(),
)
@click.option("--timeout", "job_timeout", default=3600, type=int, help="Job timeout in seconds")
@click.option("--entry", default=None, help="Entry point file inside directory (default: run.py)")
@click.option("--no-watch", is_flag=True, help="Don't poll after submission")
@click.option("--config", "run_config", default=None, help='JSON config passed to ctx.config')
def submit(
    target: str | None,
    data_files: tuple,
    gpu: str,
    job_timeout: int,
    entry: str | None,
    no_watch: bool,
    run_config: str | None,
) -> None:
    """Submit a job. TARGET can be a .py entry point, directory, or omitted."""
    config_dict: dict = {}
    if run_config:
        try:
            config_dict = json.loads(run_config)
        except json.JSONDecodeError as exc:
            click.echo(f"Error: invalid --config JSON: {exc}", err=True)
            sys.exit(1)

    manifest = _load_manifest()
    if manifest:
        if target is None:
            return _submit_workspace(manifest, gpu, job_timeout, config_dict, entry, no_watch)
        if target.endswith(".py") and not os.path.isdir(target):
            if target not in manifest.get("files", {}):
                click.echo(f"Warning: '{target}' is not tracked. Run 'mecon add {target}' first.", err=True)
            return _submit_workspace(manifest, gpu, job_timeout, config_dict, entry or target, no_watch)
        if os.path.isdir(target) and os.path.exists(os.path.join(target, MANIFEST_FILE)):
            os.chdir(target)
            manifest = _load_manifest()
            if manifest:
                return _submit_workspace(manifest, gpu, job_timeout, config_dict, entry, no_watch)

    if target is None:
        click.echo("Error: no workspace and no TARGET. Run 'mecon workspace init' or specify a file/dir.", err=True)
        sys.exit(1)

    is_dir = os.path.isdir(target)
    zip_path = None

    if is_dir:
        _validate_project(target, entry)
        entry_file = entry or "run.py"
        entry_full = os.path.join(target, entry_file)
        if not os.path.exists(entry_full):
            click.echo(f"Error: entry point '{entry_file}' not found in {target}", err=True)
            click.echo("Use --entry to specify the main script.", err=True)
            sys.exit(1)
        click.echo(f"Zipping {target} (entry: {entry_file})...")
        zip_path = _zip_directory(target)
        zip_size = os.path.getsize(zip_path) / 1024
        click.echo(f"  {zip_size:.0f} KB")
        all_files = [zip_path, *data_files]
        file_names = [os.path.basename(zip_path), *(os.path.basename(file_path) for file_path in data_files)]
        job_meta = {"entry": entry_file}
    else:
        all_files = [target, *data_files]
        file_names = [os.path.basename(file_path) for file_path in all_files]
        job_meta = {}

    try:
        click.echo("Creating job...")
        response = api(
            "POST",
            "/jobs",
            json_data={
                "gpu_type": gpu,
                "timeout_seconds": job_timeout,
                "files": file_names,
                **({"meta": job_meta} if job_meta else {}),
                **({"config": config_dict} if config_dict else {}),
            },
        )
        job = response.get("data", response)
        job_id = job["job_id"]
        click.echo(f"Job created: {job_id[:8]}")

        upload_urls = job.get("upload_urls", {})
        for file_path, file_name in zip(all_files, file_names):
            url = upload_urls.get(file_name)
            if not url:
                click.echo(f"Warning: no upload URL for {file_name}, skipping.", err=True)
                continue
            click.echo(f"Uploading {file_name}...")
            with open(file_path, "rb") as file:
                content = file.read()
            put_resp = httpx.put(url, content=content, timeout=120)
            if put_resp.status_code >= 400:
                click.echo(f"Upload failed for {file_name}: {put_resp.status_code}", err=True)
                sys.exit(1)

        click.echo("Starting job...")
        api("POST", f"/jobs/{job_id}/run")

        if no_watch:
            click.echo(f"Job {job_id[:8]} submitted. Use 'mecon watch {job_id}' to monitor.")
            return

        click.echo("Watching progress...")
        terminal_states = {"completed", "failed", "cancelled"}
        while True:
            time.sleep(3)
            data = api("GET", f"/jobs/{job_id}")
            job_resp = data.get("data", data) if isinstance(data, dict) else data
            status_value = job_resp.get("status", "unknown") if isinstance(job_resp, dict) else "unknown"
            message = job_resp.get("progress_message", "") if isinstance(job_resp, dict) else ""
            pct = job_resp.get("progress_pct", 0) if isinstance(job_resp, dict) else 0
            click.echo(f"\r[{job_id[:8]}] {status_value}  {pct}  {message:<50}", nl=False)
            if status_value in terminal_states:
                click.echo()
                if status_value == "completed":
                    click.echo("Job completed successfully.")
                elif status_value == "failed":
                    error = job_resp.get("error_message", "") if isinstance(job_resp, dict) else ""
                    click.echo(f"Job failed: {error}")
                    if isinstance(job_resp, dict):
                        _print_failure_advice(job_id, job_resp, include_logs=True)
                break
    finally:
        if zip_path and os.path.exists(zip_path):
            os.unlink(zip_path)


@main.group()
def workspace() -> None:
    """Manage compute workspaces (git-like file tracking)."""


@workspace.command(name="init")
@click.argument("name", default=".")
def workspace_init(name: str) -> None:
    """Initialize a workspace in the current directory."""
    project_name = _dir_to_project_name(os.getcwd()) if name == "." else name

    if os.path.exists(MANIFEST_FILE):
        manifest = _load_manifest()
        click.echo(f"Workspace already initialized: {manifest.get('project', '?')}")
        click.echo(f"  workspace_id: {manifest.get('workspace_id', '?')}")
        return

    response = api("POST", "/workspace", json_data={"project_name": project_name})
    data = response.get("data", response) if isinstance(response, dict) else response
    workspace_id = data.get("workspace_id", "") if isinstance(data, dict) else ""
    r2_prefix = data.get("r2_prefix", "") if isinstance(data, dict) else ""

    manifest = {
        "project": project_name,
        "workspace_id": workspace_id,
        "r2_prefix": r2_prefix,
        "files": {},
        "entry": "run.py",
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    if os.path.exists("run.py"):
        manifest["files"]["run.py"] = {
            "hash": _file_md5("run.py"),
            "size": os.path.getsize("run.py"),
            "synced_at": None,
        }

    _save_manifest(manifest)
    click.echo(f"Workspace initialized: {project_name}")
    click.echo(f"  workspace_id: {workspace_id}")
    if "run.py" in manifest["files"]:
        click.echo("  auto-added: run.py")
    click.echo("\nNext: mecon add <files> && mecon sync")


@workspace.command(name="status")
def workspace_status() -> None:
    """Show workspace state: tracked files, sync status."""
    manifest = _load_manifest()
    if not manifest:
        click.echo("No workspace. Run 'mecon workspace init' first.", err=True)
        sys.exit(1)

    click.echo(f"Workspace: {manifest['project']}")
    click.echo(f"  ID: {manifest.get('workspace_id', '?')}")
    click.echo(f"  Entry: {manifest.get('entry', 'run.py')}")
    click.echo()

    files = manifest.get("files", {})
    if not files:
        click.echo("  No tracked files. Use 'mecon add <files>' to track.")
        return

    synced = 0
    unsynced = 0
    modified = 0
    for path, info in sorted(files.items()):
        if os.path.exists(path):
            current_hash = _file_md5(path)
            if info.get("synced_at") is None:
                status_icon = "+"
                unsynced += 1
            elif current_hash != info.get("hash", ""):
                status_icon = "M"
                modified += 1
            else:
                status_icon = " "
                synced += 1
        else:
            status_icon = "!"
        size_kb = info.get("size", 0) / 1024
        click.echo(f"  {status_icon} {path:<40} {size_kb:>8.1f} KB")

    click.echo(f"\n  {synced} synced, {modified} modified, {unsynced} new")


@main.command()
@click.argument("files", nargs=-1, required=True)
def add(files: tuple) -> None:
    """Track files for workspace sync."""
    manifest = _load_manifest()
    if not manifest:
        click.echo("No workspace. Run 'mecon workspace init' first.", err=True)
        sys.exit(1)

    added = 0
    updated = 0
    skipped_ignored = 0
    for pattern in files:
        matched = globmod.glob(pattern, recursive=True)
        if not matched:
            click.echo(f"  Warning: no files match '{pattern}'", err=True)
            continue
        for file_path in matched:
            if os.path.isdir(file_path):
                continue
            rel = os.path.relpath(file_path)
            # Apply DEFAULT_IGNORE_PATTERNS and DEFAULT_IGNORE_EXTENSIONS so
            # users who do `mecon workspace add **` do not accidentally ship
            # __pycache__ / .pyc / .git / .DS_Store etc to R2. Stale .pyc
            # in particular can mask a fresh .py update on the worker
            # (incident class 2026-04-26 — Codex 2026-04-27 review).
            parts = set(rel.split(os.sep))
            if parts & DEFAULT_IGNORE_PATTERNS:
                skipped_ignored += 1
                continue
            _, ext = os.path.splitext(rel)
            ext_lower = ext.lower()
            if ext_lower in DEFAULT_IGNORE_EXTENSIONS:
                skipped_ignored += 1
                continue
            if ext_lower in BANNED_EXTENSIONS:
                click.echo(f"  Skipped (banned format): {rel}", err=True)
                continue
            digest = _file_md5(file_path)
            size = os.path.getsize(file_path)
            if rel in manifest["files"]:
                manifest["files"][rel]["hash"] = digest
                manifest["files"][rel]["size"] = size
                manifest["files"][rel]["synced_at"] = None
                updated += 1
            else:
                manifest["files"][rel] = {"hash": digest, "size": size, "synced_at": None}
                added += 1

    _save_manifest(manifest)
    suffix = f", skipped {skipped_ignored} ignored" if skipped_ignored else ""
    click.echo(
        f"Added {added} new, updated {updated} files{suffix}. Total: {len(manifest['files'])} tracked.",
    )


@main.command()
@click.argument("files", nargs=-1, required=True)
def rm(files: tuple) -> None:
    """Untrack files from workspace (does not delete local files)."""
    manifest = _load_manifest()
    if not manifest:
        click.echo("No workspace. Run 'mecon workspace init' first.", err=True)
        sys.exit(1)

    removed = 0
    for file_path in files:
        rel = os.path.relpath(file_path)
        if rel in manifest["files"]:
            del manifest["files"][rel]
            removed += 1
        else:
            click.echo(f"  Not tracked: {rel}", err=True)

    _save_manifest(manifest)
    click.echo(f"Removed {removed} files. Total: {len(manifest['files'])} tracked.")


@main.command()
def sync() -> None:
    """Upload changed files to workspace and pull results."""
    manifest = _load_manifest()
    if not manifest:
        click.echo("No workspace. Run 'mecon workspace init' first.", err=True)
        sys.exit(1)

    workspace_id = manifest.get("workspace_id", "")
    if not workspace_id:
        click.echo("Error: workspace_id not set. Re-run 'mecon workspace init'.", err=True)
        sys.exit(1)

    files_to_sync = []
    for path, _info in manifest["files"].items():
        if not os.path.exists(path):
            click.echo(f"  Warning: {path} missing locally, skipping.", err=True)
            continue
        current_hash = _file_md5(path)
        files_to_sync.append({"path": path, "hash": current_hash})
        manifest["files"][path]["hash"] = current_hash
        manifest["files"][path]["size"] = os.path.getsize(path)

    if not files_to_sync:
        click.echo("No files to sync.")
        return

    click.echo(f"Checking {len(files_to_sync)} files...")
    response = api("POST", f"/workspace/{workspace_id}/sync", json_data={"files": files_to_sync})
    data = response.get("data", response) if isinstance(response, dict) else response
    upload_urls = data.get("upload", {}) if isinstance(data, dict) else {}
    unchanged = data.get("unchanged", []) if isinstance(data, dict) else []
    deleted = data.get("deleted", []) if isinstance(data, dict) else []
    delete_errors = data.get("delete_errors", []) if isinstance(data, dict) else []

    # Show orphan deletes for transparency. Server deletes them server-side
    # (single round-trip, no presigned-DELETE per file) so we just log here.
    if deleted:
        click.echo(f"  Deleted {len(deleted)} orphan files from R2:")
        for path in deleted[:10]:
            click.echo(f"    - {path}")
        if len(deleted) > 10:
            click.echo(f"    ... and {len(deleted) - 10} more")
    if delete_errors:
        click.echo(f"  Warning: {len(delete_errors)} delete(s) failed:", err=True)
        for entry in delete_errors[:5]:
            click.echo(f"    - {entry.get('path')}: {entry.get('error')}", err=True)

    # Mark `synced_at` for BOTH uploaded and server-confirmed-unchanged files.
    # Previously this only updated on upload, so a fresh `.mecon/manifest.json`
    # (new clone, new CI runner, etc.) with files already present in R2 would
    # stay stuck at `synced_at=None`, and the next `mecon submit` would refuse
    # with "N unsynced files" even though R2 was already in sync. Seen in
    # CI synthetic monitoring on 2026-04-21.
    now_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    if upload_urls:
        uploaded_bytes = 0
        for path, url in upload_urls.items():
            with open(path, "rb") as file:
                content = file.read()
            click.echo(f"  -> {path} ({len(content) / 1024:.1f} KB)...")
            put_resp = httpx.put(url, content=content, timeout=120)
            if put_resp.status_code >= 400:
                click.echo(f"  Upload failed: HTTP {put_resp.status_code}", err=True)
                continue
            uploaded_bytes += len(content)
            manifest["files"][path]["synced_at"] = now_iso
        click.echo(f"  Pushed {len(upload_urls)} files ({uploaded_bytes / 1024:.1f} KB)")
    else:
        click.echo(f"  {len(unchanged)} files up to date.")

    # Stamp unchanged files so the manifest reflects "matches R2" state.
    for path in unchanged:
        if path in manifest["files"]:
            manifest["files"][path]["synced_at"] = now_iso

    _save_manifest(manifest)

    click.echo("Pulling results...")
    r2_files_resp = api("GET", f"/workspace/{workspace_id}/files?download=output")
    r2_data = r2_files_resp.get("data", r2_files_resp) if isinstance(r2_files_resp, dict) else r2_files_resp
    download_urls = r2_data.get("download_urls", {}) if isinstance(r2_data, dict) else {}

    if download_urls:
        downloaded = 0
        for remote_path, url in download_urls.items():
            local_path = os.path.join(".", remote_path)
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            response = httpx.get(url, timeout=300, follow_redirects=True)
            if response.status_code < 400:
                with open(local_path, "wb") as file:
                    file.write(response.content)
                click.echo(f"  <- {remote_path} ({len(response.content) / 1024:.1f} KB)")
                downloaded += 1
        click.echo(f"  Pulled {downloaded} output files.")
    else:
        click.echo("  No output files to pull.")


@main.command()
def whoami() -> None:
    """Show current configuration and account info."""
    cfg = get_config()
    api_base = cfg["api_base"]
    api_key = cfg["api_key"]
    if len(api_key) > 12:
        key_display = f"{api_key[:8]}...{api_key[-4:]}"
    else:
        key_display = "(not set)" if not api_key else api_key
    click.echo(f"API base:  {api_base}")
    click.echo(f"API key:   {key_display}")
    if api_key:
        try:
            url = f"{api_base}{API_PREFIX}/balance"
            headers = {"Authorization": f"Bearer {api_key}"}
            response = httpx.request("GET", url, headers=headers, timeout=10)
            if response.status_code < 400:
                data = response.json()
                if "email" in data:
                    click.echo(f"Account:   {data['email']}")
                balance_value = None
                if isinstance(data, dict):
                    payload = data.get("data", data)
                    if isinstance(payload, dict):
                        balance_value = payload.get("balance_credits", payload.get("balance"))
                    else:
                        balance_value = payload
                if balance_value is not None:
                    click.echo(f"Balance:   {balance_value}")
            else:
                click.echo(f"Account:   (could not fetch -- HTTP {response.status_code})")
        except httpx.HTTPError:
            click.echo("Account:   (could not connect)")


app = main


@main.command()
@click.option("--json", "json_output", is_flag=True, help="Emit doctor results as JSON.")
def doctor(json_output: bool) -> None:
    """Diagnose local mecon/runtime readiness for workspace-mode compute."""
    checks: list[tuple[str, bool, str]] = []

    python_path = shutil.which("python3")
    checks.append(("python3 on PATH", python_path is not None, python_path or "missing"))

    mecon_path = shutil.which("mecon")
    checks.append(("mecon on PATH", mecon_path is not None, mecon_path or "missing"))

    cfg = get_config()
    api_key = cfg.get("api_key", "")
    api_base = cfg.get("api_base", DEFAULT_API_BASE)
    key_status = "configured" if api_key else "missing"
    checks.append(("API key configured", bool(api_key), key_status))
    checks.append(("API endpoint", True, api_base))

    whoami_ok = False
    whoami_detail = "skipped (no API key)"
    if api_key:
        try:
            url = f"{api_base}{API_PREFIX}/balance"
            headers = {"Authorization": f"Bearer {api_key}"}
            response = httpx.get(url, headers=headers, timeout=10)
            whoami_ok = response.status_code < 400
            whoami_detail = "reachable" if whoami_ok else f"HTTP {response.status_code}"
        except httpx.HTTPError as exc:
            whoami_detail = f"error: {exc}"
    checks.append(("API reachable", whoami_ok, whoami_detail))

    run_exists = os.path.exists("run.py")
    checks.append(("run.py exists", run_exists, os.path.abspath("run.py") if run_exists else "missing"))

    run_ctx_ok = False
    run_ctx_detail = "skipped (run.py missing)"
    if run_exists:
        with open("run.py", encoding="utf-8") as file:
            content = file.read()
        run_ctx_ok = "def run(ctx" in content or "def run(" in content
        run_ctx_detail = "run(ctx) found" if run_ctx_ok else "run(ctx) missing"
    checks.append(("run(ctx) entrypoint", run_ctx_ok, run_ctx_detail))

    manifest = _load_manifest()
    manifest_exists = manifest is not None
    checks.append(
        (
            "workspace manifest",
            manifest_exists,
            os.path.abspath(MANIFEST_FILE) if manifest_exists else "missing",
        )
    )

    tracked_ok = False
    tracked_detail = "skipped (workspace not initialized)"
    sync_ok = False
    sync_detail = "skipped (workspace not initialized)"
    if manifest:
        files = manifest.get("files", {})
        tracked_ok = len(files) > 0
        tracked_detail = f"{len(files)} tracked file(s)"
        unsynced = [path for path, info in files.items() if info.get("synced_at") is None]
        sync_ok = len(unsynced) == 0 and tracked_ok
        if not tracked_ok:
            sync_detail = "no tracked files"
        elif unsynced:
            sync_detail = f"{len(unsynced)} unsynced file(s)"
        else:
            sync_detail = "all tracked files synced"
    checks.append(("workspace tracked files", tracked_ok, tracked_detail))
    checks.append(("workspace sync state", sync_ok, sync_detail))

    failed = sum(1 for _, ok, _ in checks if not ok)

    fixes: list[str] = []
    if not api_key:
        # OAuth via 'mecon login' is the default — drops the manual API-key
        # copy/paste step that was painful for non-engineer researchers.
        fixes.append("run 'mecon login' to sign in via the browser (recommended)")
        fixes.append("or 'mecon setup --api-key <key>' for manual key entry")
    if not manifest_exists:
        fixes.append("run 'mecon workspace init'")
    elif not tracked_ok:
        fixes.append("run 'mecon add run.py <data files>'")
    elif not sync_ok:
        fixes.append("run 'mecon sync'")

    if json_output:
        payload = {
            "ready": failed == 0,
            "failed_checks": failed,
            "checks": [
                {"name": name, "ok": ok, "detail": detail}
                for name, ok, detail in checks
            ],
            "next_step": "mecon submit run.py --gpu l4" if failed == 0 else None,
            "fixes": fixes,
        }
        click.echo(json.dumps(payload, indent=2))
        return

    print_width = max(len(name) for name, _, _ in checks)
    for name, ok, detail in checks:
        status = "PASS" if ok else "FAIL"
        click.echo(f"{status:<4}  {name:<{print_width}}  {detail}")

    click.echo()
    if failed == 0:
        click.echo("Doctor result: ready for workspace-mode compute.")
        click.echo("Next: mecon submit run.py --gpu l4")
        return

    click.echo(f"Doctor result: {failed} check(s) need attention.")
    for fix in fixes:
        click.echo(f"Fix: {fix}.")


# ---------------------------------------------------------------------------
# OAuth-style "mecon login" — PKCE loopback flow.
# Replaces the manual "create API key in dashboard, paste here" workflow that
# professors found painful. Manual `mecon setup --api-key` still works as the
# escape hatch.
# ---------------------------------------------------------------------------


def _b64url_no_pad(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _start_loopback_server(received: dict) -> tuple[socketserver.TCPServer, int]:
    """Bind 127.0.0.1 on a random port. Returns (server, port)."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()

    class CallbackHandler(http.server.BaseHTTPRequestHandler):
        # Quiet — don't log every request to stderr.
        def log_message(self, format: str, *args) -> None:  # noqa: A002
            return

        def do_GET(self) -> None:  # noqa: N802
            parsed = urllib.parse.urlparse(self.path)

            # Anything other than the OAuth callback (favicon, devtools probes,
            # retries) gets a 404 so it cannot overwrite the captured state.
            if parsed.path != "/callback":
                self.send_response(404)
                self.end_headers()
                return

            params = urllib.parse.parse_qs(parsed.query)
            code = (params.get("code") or [None])[0]
            state = (params.get("state") or [None])[0]
            error = (params.get("error") or [None])[0]

            # First valid callback wins. Don't let a duplicate request (browser
            # back-forward, refresh, or a stray probe) clobber the real values.
            if received["code"] is None and received["error"] is None:
                received["code"] = code
                received["state"] = state
                received["error"] = error

            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            html = (
                "<html><body style='font-family:system-ui;text-align:center;padding:60px'>"
                "<h1 style='color:#0f172a'>You can close this tab.</h1>"
                "<p style='color:#475569'>The CLI now has your API key. Returning you to the terminal…</p>"
                "</body></html>"
            )
            self.wfile.write(html.encode("utf-8"))

    server = socketserver.TCPServer(("127.0.0.1", port), CallbackHandler)
    return server, port


@main.command()
@click.option("--profile", "profile_name", default=None, help="Profile to save credentials to (default: 'default')")
@click.option("--api-base", default=None, help="API endpoint URL (default: configured / production)")
@click.option("--no-browser", is_flag=True, help="Print the URL instead of auto-opening a browser")
@click.option("--label", default=None, help="Override the device label shown on the approve page")
def login(profile_name: str | None, api_base: str | None, no_browser: bool, label: str | None) -> None:
    """Sign in via the browser; auto-creates and stores an API key for this device."""
    name = profile_name or _get_active_profile()
    profiles = _read_all_profiles()
    existing = profiles.get(name, {})
    base = (api_base or existing.get("api_base") or DEFAULT_API_BASE).rstrip("/")

    # PKCE
    verifier = _b64url_no_pad(secrets.token_bytes(32))
    challenge = _b64url_no_pad(hashlib.sha256(verifier.encode("ascii")).digest())
    state = secrets.token_urlsafe(32)
    device_label = (label or f"{platform.node() or 'unknown'} · mecon").strip()[:200]

    received: dict[str, str | None] = {"code": None, "state": None, "error": None}
    server, port = _start_loopback_server(received)
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    callback_url = f"http://127.0.0.1:{port}/callback"
    authorize_url = (
        f"{base}/cli/authorize?"
        + urllib.parse.urlencode(
            {
                "callback": callback_url,
                "state": state,
                "challenge": challenge,
                "challenge_method": "S256",
                "device_label": device_label,
            }
        )
    )

    click.echo(f"Opening browser to {base}/cli/authorize ...")
    if no_browser:
        click.echo(f"\nManual: {authorize_url}\n")
    else:
        opened = webbrowser.open(authorize_url)
        if not opened:
            click.echo(f"(browser did not open; visit manually: {authorize_url})")
        else:
            click.echo(f"(if it didn't open: {authorize_url})")

    click.echo("Waiting for approval (5 min timeout)...")
    deadline = time.time() + 5 * 60
    try:
        while time.time() < deadline and received["code"] is None and received["error"] is None:
            time.sleep(0.5)
    finally:
        server.shutdown()
        server.server_close()

    if received["error"]:
        click.echo(f"Login failed: {received['error']}", err=True)
        sys.exit(1)
    if received["code"] is None:
        click.echo("Login timed out after 5 min. Re-run 'mecon login' to try again.", err=True)
        sys.exit(1)
    if received["state"] != state:
        click.echo("State mismatch — possible CSRF; aborting. Re-run 'mecon login' to try again.", err=True)
        sys.exit(1)

    click.echo("Exchanging code for API key...")
    try:
        response = httpx.post(
            f"{base}/api/cli/auth/exchange",
            json={"code": received["code"], "code_verifier": verifier},
            timeout=30,
        )
    except httpx.HTTPError as exc:
        click.echo(f"Exchange failed: {exc}", err=True)
        sys.exit(1)

    if response.status_code >= 400:
        click.echo(f"Exchange failed (HTTP {response.status_code}): {response.text}", err=True)
        sys.exit(1)
    body = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
    api_key = body.get("api_key") if isinstance(body, dict) else None
    if not api_key:
        click.echo(f"Exchange response missing api_key: {body}", err=True)
        sys.exit(1)

    profiles[name] = {"api_key": api_key, "api_base": base}
    _write_all_profiles(profiles)
    click.echo(f"✓ Logged in. Profile [{name}] saved to {CONFIG_FILE}")
    click.echo(f"  Revoke any time at {base}/settings/keys")


# ---------------------------------------------------------------------------
# Browser openers — let the agent direct the human to the right page rather
# than asking them to navigate. Used by skills when prompting for billing /
# key rotation / job inspection.
# ---------------------------------------------------------------------------


@main.group("open")
def open_group() -> None:
    """Open RA Compute pages in the user's browser."""


def _open_path(path: str) -> None:
    cfg = get_config()
    base = (cfg.get("api_base") or DEFAULT_API_BASE).rstrip("/")
    url = f"{base}{path}"
    click.echo(f"Opening {url}")
    webbrowser.open(url)


@open_group.command(name="dashboard")
def open_dashboard() -> None:
    """Open the RA Compute dashboard."""
    _open_path("/dashboard")


@open_group.command(name="jobs")
def open_jobs() -> None:
    """Open the job history page."""
    _open_path("/dashboard/compute/jobs")


@open_group.command(name="billing")
def open_billing() -> None:
    """Open the billing / subscription page (where the user adds credits)."""
    _open_path("/settings/billing")


@open_group.command(name="keys")
def open_keys() -> None:
    """Open the API keys management page."""
    _open_path("/settings/keys")


@open_group.command(name="job")
@click.argument("job_id")
def open_job(job_id: str) -> None:
    """Open a specific job's detail page."""
    _open_path(f"/dashboard/compute/jobs/{job_id}")
