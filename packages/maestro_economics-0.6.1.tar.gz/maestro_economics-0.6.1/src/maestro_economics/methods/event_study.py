"""Event Study estimation."""
from __future__ import annotations
from maestro_economics.registry import register


@register("event_study")
class EventStudyEstimator:
    """Dynamic treatment effect event study with leads/lags."""
    name = "event_study"
    description = "Event study with dynamic treatment effects"
    requires = ["linearmodels"]

    def estimate(self, df, y: str, treatment_time: str, entity: str = None, **kwargs):
        raise NotImplementedError("Event study estimator -- implementation pending")
