"""Regression Discontinuity Design."""
from __future__ import annotations
from maestro_economics.registry import register


@register("rdd")
class RDDEstimator:
    """Sharp/fuzzy RDD via rdrobust."""
    name = "rdd"
    description = "Regression discontinuity with optimal bandwidth selection"
    requires = ["rdrobust"]

    def estimate(self, df, y: str, running: str, cutoff: float = 0, **kwargs):
        raise NotImplementedError("RDD estimator -- implementation pending")
