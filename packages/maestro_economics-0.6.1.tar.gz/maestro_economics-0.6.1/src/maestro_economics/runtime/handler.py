"""Execution engine for run(ctx) jobs."""

from __future__ import annotations

import importlib.util
import io
import json
import os
import platform
import signal
import sys
import time
from pathlib import Path
from typing import Any, Callable

from .context import GpuInfo, JobContext


LOG_ACTIVITY_INTERVAL_SECONDS = 60.0
LOG_ACTIVITY_MESSAGE_MAX_CHARS = 160


class _CancelledError(Exception):
    """Raised when the job receives SIGTERM."""


class _Timeout:
    """Signal-based timeout guard for Unix platforms."""

    def __init__(self, seconds: int) -> None:
        self.seconds = seconds
        self._is_unix = platform.system() != "Windows"

    def _handler(self, signum: int, frame: Any) -> None:
        raise TimeoutError(f"Job exceeded timeout of {self.seconds} seconds")

    def __enter__(self) -> "_Timeout":
        if self._is_unix and self.seconds > 0:
            signal.signal(signal.SIGALRM, self._handler)
            signal.alarm(self.seconds)
        return self

    def __exit__(self, *exc: Any) -> None:
        if self._is_unix and self.seconds > 0:
            signal.alarm(0)


def _install_sigterm_handler() -> Any:
    """Install the cancellation SIGTERM handler. Returns the previous handler
    so the caller can restore it after the job, otherwise a leaked handler
    would catch SIGTERM in the next job's setup phase or during heartbeat
    teardown — incident class 2026-04-26 (warm-container state pollution)."""
    if platform.system() == "Windows":
        return None

    def _handler(signum: int, frame: Any) -> None:
        raise _CancelledError("Job cancelled by user (SIGTERM)")

    return signal.signal(signal.SIGTERM, _handler)


def _restore_sigterm_handler(prev: Any) -> None:
    if platform.system() == "Windows":
        return
    if prev is None:
        signal.signal(signal.SIGTERM, signal.SIG_DFL)
    else:
        signal.signal(signal.SIGTERM, prev)


def _restore_process_state(
    script_path: str,
    modules_baseline: set[str],
    env_baseline: dict[str, str],
    sys_path_baseline: list[str],
    prev_sigterm: Any,
) -> None:
    try:
        _purge_user_modules(script_path, modules_baseline)
    except Exception:
        pass
    try:
        for key in list(os.environ.keys()):
            if key not in env_baseline:
                os.environ.pop(key, None)
        for key, value in env_baseline.items():
            if os.environ.get(key) != value:
                os.environ[key] = value
    except Exception:
        pass
    try:
        sys.path[:] = sys_path_baseline
    except Exception:
        pass
    try:
        _restore_sigterm_handler(prev_sigterm)
    except Exception:
        pass


def _purge_user_modules(script_path: str, baseline_keys: set[str]) -> None:
    """Drop any module that was imported during this job execution AND whose
    source lives under the user-script directory.

    Modal warm-pools the worker container across job invocations. Without
    this purge, a second job that imports the same package name (e.g.
    `from smom.calculate_distance_jax_r3_v2 import f`) hits Python's
    `sys.modules` cache and re-uses the FIRST job's bytecode — even though
    the worker dutifully re-copied the latest file from R2 to the local
    workspace. This was the root cause of the 2026-04-26 BCH_347 incident
    where the GPU returned a 39 % distance gap vs local re-computation
    after the customer pushed a numerical patch.

    We scope the purge to modules under `script_dir` so that JAX, numpy,
    boto3, etc. stay cached (they are expensive to re-import and the user
    cannot mutate them in a way that survives the env restore in
    `execute_job`'s finally block).
    """
    script_dir = os.path.realpath(os.path.dirname(script_path))
    to_drop: list[str] = []
    for name in list(sys.modules.keys()):
        if name in baseline_keys:
            continue
        mod = sys.modules.get(name)
        if mod is None:
            continue
        mod_file = getattr(mod, "__file__", None)
        if not mod_file:
            continue
        try:
            if os.path.realpath(mod_file).startswith(script_dir):
                to_drop.append(name)
        except OSError:
            # Some module __file__ entries point at deleted paths; skip.
            continue
    for name in to_drop:
        sys.modules.pop(name, None)
    importlib.invalidate_caches()


class _StreamTee(io.TextIOBase):
    """Mirror every newline-terminated line from stdout/stderr to ctx.log()
    while retaining a buffered copy for the post-run `job.log` write.

    Why line-based: each ctx.log() call becomes one R2 object
    (`log_NNNN.txt`). Flushing per character would explode the object count;
    flushing per line is the natural `print()` boundary and stays cheap.
    """

    def __init__(self, buffer: io.StringIO, sink: Callable[[str], None]) -> None:
        super().__init__()
        self.buffer = buffer
        self._sink = sink
        self._partial = ""

    def writable(self) -> bool:
        return True

    def write(self, text: str) -> int:
        if not text:
            return 0
        self.buffer.write(text)
        self._partial += text
        while "\n" in self._partial:
            line, self._partial = self._partial.split("\n", 1)
            try:
                self._sink(line)
            except Exception:
                # Never let a log-sink failure surface in user code.
                pass
        return len(text)

    def flush(self) -> None:
        # Flush any trailing partial line at shutdown so it still reaches R2.
        if self._partial:
            try:
                self._sink(self._partial)
            except Exception:
                pass
            self._partial = ""
        self.buffer.flush()


def execute_job(
    script_path: str,
    data_dir: str,
    output_dir: str,
    config: dict[str, Any],
    progress_cb: Callable[[float, str], None],
    gpu_type: str | None = None,
    gpu_memory_gb: float | None = None,
    timeout: int = 0,
    checkpoint_dir: str | None = None,
    log_dir: str | None = None,
    activity_cb: Callable[[str, str], None] | None = None,
) -> dict[str, Any]:
    """Execute a user script's run(ctx) function."""
    os.makedirs(output_dir, exist_ok=True)
    last_activity_at = 0.0

    def report_log_activity(line: str) -> None:
        nonlocal last_activity_at
        if activity_cb is None:
            return
        message = line.strip()
        if not message:
            return
        now = time.monotonic()
        if now - last_activity_at < LOG_ACTIVITY_INTERVAL_SECONDS:
            return
        last_activity_at = now
        if len(message) > LOG_ACTIVITY_MESSAGE_MAX_CHARS:
            message = message[: LOG_ACTIVITY_MESSAGE_MAX_CHARS - 3] + "..."
        try:
            activity_cb("log", message)
        except Exception:
            # Activity callbacks are liveness hints. They must never surface
            # transport noise into customer code.
            pass

    # Snapshot warm-container state we will mutate so the finally block can
    # restore it. Without this the next job in the same Modal container sees
    # the previous job's signal handlers / env vars / module cache — the
    # 2026-04-26 silent-cache incident class.
    prev_sigterm = _install_sigterm_handler()
    env_baseline = dict(os.environ)
    modules_baseline = set(sys.modules.keys())
    sys_path_baseline = list(sys.path)

    gpu = GpuInfo(type=gpu_type, memory_gb=gpu_memory_gb)
    ctx = JobContext(
        data_dir=Path(data_dir),
        output_dir=Path(output_dir),
        config=config,
        progress_callback=progress_cb,
        gpu=gpu,
        checkpoint_dir=Path(checkpoint_dir) if checkpoint_dir else None,
        log_dir=Path(log_dir) if log_dir else None,
    )

    if not os.path.isfile(script_path):
        raise ValueError(f"Cannot load script: {script_path}")
    script_dir = os.path.realpath(os.path.dirname(script_path))
    if script_dir not in sys.path:
        sys.path.insert(0, script_dir)
    try:
        spec = importlib.util.spec_from_file_location("user_script", script_path)
        if spec is None or spec.loader is None:
            raise ValueError(f"Cannot load script: {script_path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        if not hasattr(module, "run"):
            raise ValueError("Script must define a run(ctx) function")
    except Exception:
        _restore_process_state(
            script_path,
            modules_baseline,
            env_baseline,
            sys_path_baseline,
            prev_sigterm,
        )
        raise

    log_path = os.path.join(output_dir, "job.log")
    old_stdout, old_stderr = sys.stdout, sys.stderr
    # Tee stdout/stderr: keep a buffered copy for `output_dir/job.log` AND mirror
    # every completed line to R2 via ctx.log() immediately. Without this
    # immediate mirror, a SIGKILL from Modal's timeout enforcement would lose
    # every `print(...)` issued before the kill, because the in-memory buffer
    # only hits disk in the finally-block below.
    def mirror_log_line(line: str) -> None:
        try:
            ctx.log(line)
        finally:
            report_log_activity(line)

    log_buffer = _StreamTee(io.StringIO(), mirror_log_line)
    cancelled = False

    try:
        sys.stdout = log_buffer
        sys.stderr = log_buffer
        with _Timeout(timeout):
            result = module.run(ctx)
    except _CancelledError:
        cancelled = True
        result = {"status": "cancelled", "message": "Job cancelled by user"}
        try:
            ctx.log("[system] Job cancelled -- flushing logs and shutting down")
        except Exception:
            pass
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr
        log_buffer.flush()
        with open(log_path, "w", encoding="utf-8") as file:
            file.write(log_buffer.buffer.getvalue())
        # Restore container state in reverse order of mutation. The purge
        # removes user-script modules so the next job re-reads them from disk;
        # env/sys.path restore drops user mutations; signal handler restore
        # drops the cancellation hook before heartbeat teardown or next setup.
        _restore_process_state(
            script_path,
            modules_baseline,
            env_baseline,
            sys_path_baseline,
            prev_sigterm,
        )

    if cancelled:
        results_path = os.path.join(output_dir, "results.json")
        with open(results_path, "w", encoding="utf-8") as file:
            json.dump(result, file, indent=2, default=str)
        raise _CancelledError("Job cancelled by user")

    if not isinstance(result, dict):
        result = {"output": result}

    results_path = os.path.join(output_dir, "results.json")
    with open(results_path, "w", encoding="utf-8") as file:
        json.dump(result, file, indent=2, default=str)

    return result
