"""End-to-end smoke of the deployed maestro-economics Modal worker.

Spawns a minimal L4 job whose `run(ctx)` prints a line and returns a dict,
against the LIVE deployed app. Verifies:

- Modal function spawn via submit_job web endpoint (per-call with_options
  timeout should appear as `call_timeout_seconds` in the response).
- stdout tee in runtime/handler.py: the `print(...)` line must land in R2
  /logs/log_NNNN.txt even though it was not a `ctx.log` call.
- Terminal callback path fires and returns `status=completed`.

Usage: MODAL_TOKEN_ID=... MODAL_TOKEN_SECRET=... python smoke-new-worker.py
"""

from __future__ import annotations

import json
import os
import sys
import time

import httpx
import modal

MODAL_ENDPOINT = "https://founder-64193--maestro-economics-submit-job.modal.run"

USER_SCRIPT = """def run(ctx):
    print('hello from modal worker (via print tee)')
    ctx.log('ctx.log also fired')
    return {'ok': True, 'source': 'smoke-new-worker'}
"""


def main() -> int:
    token = os.environ.get("MODAL_TOKEN_ID")
    secret = os.environ.get("MODAL_TOKEN_SECRET")
    if not token or not secret:
        print("MODAL_TOKEN_ID / MODAL_TOKEN_SECRET must be set", file=sys.stderr)
        return 1

    payload = {
        "job_id": f"smoke-{int(time.time())}",
        "gpu_type": "L4",
        "timeout": 120,
        "config": {"script_code": USER_SCRIPT},
        "upload_files": [],
        "callback_url": "https://httpbin.org/post",
        "workspace_path": None,
    }

    print(f"Submitting to {MODAL_ENDPOINT}")
    print(f"  job_id={payload['job_id']}  timeout={payload['timeout']}s")

    response = httpx.post(
        MODAL_ENDPOINT,
        headers={
            "Authorization": f"Bearer {token}:{secret}",
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=30,
    )

    if not response.is_success:
        print(f"HTTP {response.status_code}: {response.text}", file=sys.stderr)
        return 1

    data = response.json()
    print("\nsubmit_job response:")
    print(json.dumps(data, indent=2))

    if not data.get("call_id"):
        print("\nno call_id in response", file=sys.stderr)
        return 2
    call_id = data["call_id"]
    print(f"\n✓ call_id: {call_id}")
    print("Waiting for terminal result...")
    result = modal.FunctionCall.from_id(call_id).get(timeout=240)
    print(json.dumps(result, indent=2))
    if result.get("status") != "completed":
        print("\nworker smoke did not complete", file=sys.stderr)
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
