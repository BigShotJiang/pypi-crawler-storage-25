"""Resolve env vars via MCP config or AWS Secrets Manager.

Exposed as ``pysae-ai-tools env resolve``. Values are produced by trying, in
order: the current process environment, then the auto-strategies declared in
:mod:`pysae_ai_tools.env.config` (shell command → MCP config).
"""

import contextlib
import io
import json
import os
import subprocess
import sys
from typing import Annotated

import typer

from .config import ENV_CONFIG


def _try_auto_resolve_shell(var: str) -> str | None:
    """Run the configured shell command(s) and capture stdout as the value.

    `auto` may be a single command or a list of commands; commands are tried
    in order and the first one producing non-empty stdout wins.
    """
    cfg = ENV_CONFIG.get(var, {})
    raw = cfg.get("auto")
    if not raw:
        return None
    commands: list[str] = [raw] if isinstance(raw, str) else list(raw)

    for cmd in commands:
        try:
            result = subprocess.run(cmd.split(), capture_output=True, text=True, timeout=15)
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue
        if result.returncode != 0 or not result.stdout.strip():
            continue

        value = result.stdout.strip()
        os.environ[var] = value
        raw_label = cfg.get("auto_label", "automatically")
        label = raw_label if isinstance(raw_label, str) else "automatically"
        print(f"  ✓ ${var} resolved {label}", file=sys.stderr)
        return value
    return None


def _try_auto_resolve_from_mcp(var: str) -> str | None:
    """Try to read an env var from an existing MCP server config in ``~/.claude.json``."""
    ref = ENV_CONFIG.get(var, {}).get("auto_mcp")
    if not isinstance(ref, str) or "." not in ref:
        return None
    server, key = ref.split(".", 1)

    from ..install.common.mcp import get_server

    try:
        srv = get_server(server)
    except (OSError, ValueError):
        return None
    if not srv:
        return None

    env = srv.get("env")
    if not isinstance(env, dict):
        return None
    raw = env.get(key)
    if not isinstance(raw, str):
        return None
    value = raw.strip()
    if not value:
        return None

    os.environ[var] = value
    print(f"  ✓ ${var} resolved from MCP config ({server})", file=sys.stderr)
    return value


def try_auto_resolve(var: str) -> str | None:
    """Try strategies in order: authoritative shell command, then MCP-config fallback."""
    if (value := _try_auto_resolve_shell(var)) is not None:
        return value
    return _try_auto_resolve_from_mcp(var)


def _all_known_env_vars() -> list[str]:
    """Collect the unique env vars declared by any install tool, in tier order."""
    from ..install.all import TOOLS

    seen: list[str] = []
    for tool in TOOLS:
        for var in tool.env_required:
            if var not in seen:
                seen.append(var)
    return seen


_VALID_SHELLS = ("posix", "powershell", "cmd")


def _detect_shell() -> str:
    """Best-effort detection of the invoking shell.

    Non-Windows → posix. Windows → posix if SHELL is set (Git Bash / MSYS2 /
    Cygwin / WSL), else powershell if PSModulePath is set, else cmd.
    """
    if sys.platform != "win32":
        return "posix"
    if os.environ.get("SHELL"):
        return "posix"
    if os.environ.get("PSModulePath"):
        return "powershell"
    return "cmd"


def _format_set_line(shell: str, name: str, value: str) -> str:
    """Format a single variable assignment for the given shell."""
    import shlex

    if shell == "posix":
        return f"export {name}={shlex.quote(value)}"
    if shell == "powershell":
        escaped = value.replace("'", "''")
        return f"$env:{name} = '{escaped}'"
    if shell == "cmd":
        escaped = value.replace("%", "%%").replace('"', '""')
        return f'set "{name}={escaped}"'
    raise ValueError(f"unknown shell: {shell}")


def _set_mode_hint(shell: str) -> str:
    """Shell-compatible comment telling the user how to consume the output."""
    if shell == "posix":
        return '# Pipe into `eval "$(…)"` to apply the exports in your shell.'
    if shell == "powershell":
        return "# Pipe into `Invoke-Expression` (alias `iex`) to apply: `… | iex`."
    if shell == "cmd":
        return ":: Consume via `for /f \"delims=\" %i in ('…') do @%i` to apply."
    raise ValueError(f"unknown shell: {shell}")


def resolve(
    vars: Annotated[
        list[str] | None,
        typer.Argument(
            help=(
                "Env var name(s) to resolve. Supports aliasing via "
                "`OUT=SRC` — e.g. `DATADOG_API_KEY=DD_API_KEY` resolves "
                "DD_API_KEY and emits it under DATADOG_API_KEY."
            ),
        ),
    ] = None,
    all_vars: Annotated[
        bool,
        typer.Option(
            "--all",
            help="Resolve every env var declared by any tool. Best-effort — unresolved vars are silently skipped.",
        ),
    ] = False,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output: {VAR: value, …}")] = False,
    set_mode: Annotated[
        bool,
        typer.Option(
            "--set",
            help=(
                "Emit shell-compatible assignment lines (auto-detected). Safe for "
                '`eval "$(…)"` (posix), `| Invoke-Expression` (powershell), or '
                "`for /f` loops (cmd). Combine with `--shell` to override the format."
            ),
        ),
    ] = False,
    shell: Annotated[
        str | None,
        typer.Option(
            "--shell",
            help="Force the output shell format: `posix`, `powershell`, or `cmd`. Implies `--set`.",
        ),
    ] = None,
) -> None:
    """Resolve env vars via MCP config or AWS Secrets Manager.

    Tries the configured auto-resolve strategies (shell / MCP config) for each
    variable. Values already present in the environment are kept as-is.

    Without `--all`, every named variable must resolve (exits 1 otherwise).
    With `--all`, the command is best-effort: unresolved vars are skipped.
    """
    emit_set_lines = set_mode or shell is not None

    if json_output and emit_set_lines:
        typer.echo("--json and --set/--shell are mutually exclusive", err=True)
        raise typer.Exit(code=2)

    if shell is not None and shell not in _VALID_SHELLS:
        typer.echo(
            f"--shell: invalid value {shell!r} (expected posix|powershell|cmd)",
            err=True,
        )
        raise typer.Exit(code=2)

    resolved_shell = shell or (_detect_shell() if emit_set_lines else None)

    if all_vars:
        if vars:
            typer.echo("--all cannot be combined with positional var names", err=True)
            raise typer.Exit(code=2)
        specs = _all_known_env_vars()
    else:
        if not vars:
            typer.echo("usage: resolve <VAR>... | --all", err=True)
            raise typer.Exit(code=2)
        specs = vars

    # Parse each spec into (output_name, source_name). Plain "VAR" → both equal.
    pairs: list[tuple[str, str]] = []
    for spec in specs:
        out, sep, src = spec.partition("=")
        pairs.append((out, src if sep else out))

    # In --set mode the output is meant to be piped into `eval` (or
    # Invoke-Expression) — the only admissible display is the assignment
    # lines. Suppress every other stderr line (resolver "✓ resolved from …"
    # notices, "Could not resolve" errors); the exit code still conveys the
    # outcome to the caller.
    silence: contextlib.AbstractContextManager[object] = (
        contextlib.redirect_stderr(io.StringIO()) if emit_set_lines else contextlib.nullcontext()
    )

    resolved: dict[str, str] = {}
    missing: list[str] = []
    with silence:
        for out, src in pairs:
            value = os.environ.get(src) or try_auto_resolve(src)
            if value:
                resolved[out] = value
            elif not all_vars:
                missing.append(src)

        if missing:
            typer.echo(f"Could not resolve: {', '.join(missing)}", err=True)
            raise typer.Exit(code=1)

    # Preserve request order; in --all mode, drop unresolved entries silently.
    emit = [(out, resolved[out]) for out, _ in pairs if out in resolved]

    if json_output:
        typer.echo(json.dumps(dict(emit)))
    elif resolved_shell is not None:
        typer.echo(_set_mode_hint(resolved_shell))
        for out, value in emit:
            typer.echo(_format_set_line(resolved_shell, out, value))
    else:
        for _, value in emit:
            typer.echo(value)


if __name__ == "__main__":
    _app = typer.Typer(add_completion=False)
    _app.command()(resolve)
    _app()
