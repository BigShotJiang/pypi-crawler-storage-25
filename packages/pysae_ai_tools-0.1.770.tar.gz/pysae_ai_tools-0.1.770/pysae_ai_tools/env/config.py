"""Centralised help and auto-resolve strategies for known env vars.

Each entry declares how `pysae-ai-tools env resolve` can obtain a value when
the variable is missing from the current environment. Supported keys:

- ``help``       — user-facing description
- ``auto``       — shell command whose stdout becomes the value (timeout 15s).
                   May be a list of commands tried in order; first non-empty
                   stdout wins (used for fallbacks, e.g. local secret first,
                   then shared secret).
- ``auto_label`` — short human label appended to the success message
                   ("from X"). Defaults to "automatically" when missing.
- ``auto_mcp``   — "<server>.<env_key>" read from
                   ``~/.claude.json`` → ``mcpServers[server].env``.

Strategies are tried in this order: shell (authoritative) → MCP config (fallback).
"""

ENV_CONFIG: dict[str, dict[str, str | list[str]]] = {
    "DD_API_KEY": {
        "help": "Datadog → Organization Settings → API Keys → New Key",
        "auto_mcp": "datadog.DD_API_KEY",
    },
    "DD_APP_KEY": {
        "help": "Datadog → Organization Settings → Application Keys → New Key",
        "auto_mcp": "datadog.DD_APP_KEY",
    },
    "POSTMAN_API_KEY": {
        "help": "Postman → Settings → API Keys → Generate API Key",
        "auto_mcp": "postman.POSTMAN_API_KEY",
    },
    "MONGO_URI_DEV": {
        "help": (
            "MongoDB URI de dev (AWS Secrets Manager: "
            "pysae/local-dev/secrets → api-mongo-uri, fallback pysae/dev/secrets)"
        ),
        "auto": [
            "pysae-ai-tools env secret get pysae/local-dev/secrets api-mongo-uri --show-value",
            "pysae-ai-tools env secret get pysae/dev/secrets api-mongo-uri --show-value",
        ],
        "auto_label": "from AWS Secrets Manager",
        "auto_mcp": "mongodb-dev.MDB_MCP_CONNECTION_STRING",
    },
    "MONGO_URI_PROD": {
        "help": (
            "MongoDB URI de prod (AWS Secrets Manager: "
            "pysae/local-prod/secrets → api-mongo-uri, fallback pysae/prod/secrets)"
        ),
        "auto": [
            "pysae-ai-tools env secret get pysae/local-prod/secrets api-mongo-uri --show-value",
            "pysae-ai-tools env secret get pysae/prod/secrets api-mongo-uri --show-value",
        ],
        "auto_label": "from AWS Secrets Manager",
        "auto_mcp": "mongodb-prod.MDB_MCP_CONNECTION_STRING",
    },
}
