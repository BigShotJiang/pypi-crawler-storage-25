"""HTTP routes for the apply / materialize / history endpoints (§F.5).

L2 §7bis.4 + §7bis.6 (6 endpoints) :

* §7bis.4.1 POST /balance-imports/{id}/apply-mapping (builder)
* §7bis.4.2 GET  /balance-imports/{id}/unmapped-accounts (user)
* §7bis.4.3 POST /balance-imports/{id}/materialize-kb (builder)
* §7bis.4.4 DELETE /balance-imports/{id}?delete_kb= (builder)
* §7bis.6.1 GET  /balance-imports (history) (user)
* §7bis.6.2 POST /balance-imports/{id}/replay (builder)
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.balance_apply import (
    ApplyRequest,
    ApplyResult,
    BalanceImportSummary,
    MaterializeRequest,
    MaterializeResult,
    UnmappedAccount,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import balance_apply_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/balance-imports", tags=["compta_esms:balance-apply"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


# ---------------------------------------------------------------------------
# §7bis.6.1 — history list
# ---------------------------------------------------------------------------


@router.get("", response_model=list[BalanceImportSummary])
@limiter.limit("100/minute")
async def list_history(
    request: Request,
    exercice_id: UUID | None = None,
    etablissement_id: UUID | None = None,
    import_status: str | None = None,
    limit: int = 20,
    auth: tuple = Depends(require_user),
) -> list[BalanceImportSummary]:
    """L2 §7bis.6.1 — history of balance imports for the cabinet.

    Returns the compact :class:`BalanceImportSummary` (no JSONB blobs)
    so the listing stays light even when the cabinet has hundreds of
    quarterly imports. Drill-down uses ``GET /balance-imports/{id}``
    (§F.3) for the full payload."""
    company_id = _require_company(auth)
    return await balance_apply_service.list_history(
        company_id,
        exercice_id=exercice_id,
        etablissement_id=etablissement_id,
        status=import_status,
        limit=limit,
    )


# ---------------------------------------------------------------------------
# §7bis.4.1 — apply-mapping
# ---------------------------------------------------------------------------


@router.post("/{import_id}/apply-mapping", response_model=ApplyResult)
@limiter.limit("10/minute")
async def apply_mapping(
    request: Request,
    import_id: UUID,
    payload: ApplyRequest | None = None,
    auth: tuple = Depends(require_builder),
) -> ApplyResult:
    """L2 §7bis.4.1 — apply the company's dictionary to the source file.

    Empty body → defaults (``version_m22bis='2025-2026'``, ``dry_run=False``)."""
    company_id = _require_company(auth)
    body = payload or ApplyRequest()
    try:
        return await balance_apply_service.apply_mapping(company_id, import_id, body)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §7bis.4.2 — unmapped accounts
# ---------------------------------------------------------------------------


@router.get("/{import_id}/unmapped-accounts", response_model=list[UnmappedAccount])
@limiter.limit("100/minute")
async def get_unmapped_accounts(
    request: Request,
    import_id: UUID,
    auth: tuple = Depends(require_user),
) -> list[UnmappedAccount]:
    """L2 §7bis.4.2 — source accounts left unresolved by the last apply.

    Empty list when the last apply succeeded with full coverage —
    that's the cabinet's signal that they can safely materialise."""
    company_id = _require_company(auth)
    try:
        return await balance_apply_service.list_unmapped(company_id, import_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §7bis.4.3 — materialize KB
# ---------------------------------------------------------------------------


@router.post("/{import_id}/materialize-kb", response_model=MaterializeResult)
@limiter.limit("10/minute")
async def materialize_kb(
    request: Request,
    import_id: UUID,
    payload: MaterializeRequest | None = None,
    auth: tuple = Depends(require_builder),
) -> MaterializeResult:
    """L2 §7bis.4.3 — materialise the mapped balance into a KB."""
    company_id = _require_company(auth)
    body = payload or MaterializeRequest()
    try:
        return await balance_apply_service.materialize_kb(company_id, import_id, body)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §7bis.4.4 — delete import
# ---------------------------------------------------------------------------


@router.delete("/{import_id}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_balance_import(
    request: Request,
    import_id: UUID,
    delete_kb: bool = False,
    auth: tuple = Depends(require_builder),
) -> None:
    """L2 §7bis.4.4 — drop the balance import row.

    ``delete_kb=true`` wipes the materialised KB's rows (in-place ; the
    SDK doesn't yet expose ``delete_kb()`` — the KB row stays on
    ``public.knowledge_bases`` until a janitor cleans it)."""
    company_id = _require_company(auth)
    try:
        await balance_apply_service.delete_import(company_id, import_id, delete_kb=delete_kb)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §7bis.6.2 — replay
# ---------------------------------------------------------------------------


@router.post("/{import_id}/replay", response_model=ApplyResult)
@limiter.limit("10/minute")
async def replay_balance_import(
    request: Request,
    import_id: UUID,
    auth: tuple = Depends(require_builder),
) -> ApplyResult:
    """L2 §7bis.6.2 — re-run apply with the current dictionary.

    Useful after the cabinet has corrected some mappings in
    ``balance_mappings`` and wants the snapshot/unmapped report
    refreshed. The materialised KB (if any) is **not** automatically
    rebuilt — the cabinet calls ``:materialize-kb?overwrite_existing=true``
    when they're satisfied with the new apply outcome."""
    company_id = _require_company(auth)
    try:
        return await balance_apply_service.replay_import(company_id, import_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
