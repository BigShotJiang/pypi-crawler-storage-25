"""HTTP routes §AB — exports (L2 §19).

5 endpoints :

* POST ``/documents/{id}/export/xlsx`` user (5/min) — génère + persiste
* POST ``/documents/{id}/export/docx`` user (5/min) — **stub 501** (§AC)
* GET  ``/documents/{id}/exports`` user (100/min) — historique
* GET  ``/exports/{id}/download`` user (60/min) — streaming
* DELETE ``/exports/{id}`` builder (30/min) — soft-delete
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import Response
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import exports_service
from piilot_pack_compta_esms.services.errors import DomainError
from piilot_pack_compta_esms.services.exports_service import (
    ExportDocxRequest,
    ExportRead,
    ExportXlsxRequest,
)

router_under_doc = APIRouter(prefix="/documents/{document_id}", tags=["compta_esms:exports"])
router_flat = APIRouter(prefix="/exports", tags=["compta_esms:exports"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


def _require_user_id(auth: tuple) -> UUID:
    user_id = auth[0]
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "unauthenticated", "message": "auth required"},
        )
    return UUID(str(user_id))


# ---------------------------------------------------------------------------
# POST /documents/{id}/export/xlsx
# ---------------------------------------------------------------------------


@router_under_doc.post("/export/xlsx", response_model=ExportRead)
@limiter.limit("5/minute")
async def export_xlsx_route(
    request: Request,
    document_id: UUID,
    payload: ExportXlsxRequest | None = None,
    auth: tuple = Depends(require_user),
) -> ExportRead:
    """L2 §19.1 — génère le XLSX format DGCS et retourne la row exports.

    Body optionnel :
    ```json
    {"include_recueil_consentement": true}
    ```
    Refuse 422 ``xlsx_only_errd_v02`` si type_document != errd.
    """
    company_id = _require_company(auth)
    user_id = _require_user_id(auth)
    include_recueil = bool(payload.include_recueil_consentement) if payload else False
    try:
        return await exports_service.export_xlsx(
            document_id,
            company_id,
            user_id=user_id,
            include_recueil_consentement=include_recueil,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# POST /documents/{id}/export/docx — stub 501 §AC
# ---------------------------------------------------------------------------


@router_under_doc.post("/export/docx", response_model=ExportRead)
@limiter.limit("5/minute")
async def export_docx_route(
    request: Request,
    document_id: UUID,
    payload: ExportDocxRequest | None = None,
    auth: tuple = Depends(require_user),
) -> ExportRead:
    """L2 §19.2 — génère le rapport DOCX EPRD/ERRD R.314-223.

    Body optionnel :
    ```json
    {"template_version": "2025"}
    ```
    ``template_version`` accepté mais ignoré v0.2 (1 seul template
    from-scratch). Sera dispatché vers Générique ARS / Bretagne short
    en v0.3+.

    Refuse 422 ``docx_only_eprd_errd_v02`` si type_document ∉ {eprd, errd}.
    """
    company_id = _require_company(auth)
    user_id = _require_user_id(auth)
    template_version = payload.template_version if payload else None
    try:
        return await exports_service.export_docx(
            document_id,
            company_id,
            user_id=user_id,
            template_version=template_version,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# GET /documents/{id}/exports — historique
# ---------------------------------------------------------------------------


@router_under_doc.get("/exports", response_model=list[ExportRead])
@limiter.limit("100/minute")
async def list_exports_route(
    request: Request,
    document_id: UUID,
    auth: tuple = Depends(require_user),
) -> list[ExportRead]:
    """L2 §19.3 — historique exports actifs (deleted_at NULL)."""
    company_id = _require_company(auth)
    try:
        return await exports_service.list_exports(document_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# GET /exports/{id}/download — streaming
# ---------------------------------------------------------------------------


@router_flat.get("/{export_id}/download")
@limiter.limit("60/minute")
async def download_export_route(
    request: Request,
    export_id: UUID,
    auth: tuple = Depends(require_user),
) -> Response:
    """L2 §19.4 — download streaming via FastAPI Response.

    Volume v0.2 < 5MB par export — streaming brut suffit, pas besoin
    de signed URL S3.
    """
    company_id = _require_company(auth)
    try:
        bytes_data, filename, content_type = await exports_service.get_download(
            export_id, company_id
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc

    return Response(
        content=bytes_data,
        media_type=content_type,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(bytes_data)),
        },
    )


# ---------------------------------------------------------------------------
# DELETE /exports/{id} — soft-delete
# ---------------------------------------------------------------------------


@router_flat.delete("/{export_id}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_export_route(
    request: Request,
    export_id: UUID,
    auth: tuple = Depends(require_builder),
) -> None:
    """L2 §19.5 — soft-delete idempotent (HTTP 204)."""
    company_id = _require_company(auth)
    try:
        await exports_service.delete_export(export_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
