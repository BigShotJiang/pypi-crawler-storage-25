"""HTTP routes for EPRD tarifs proposés — §BB v0.3 (L2 §23).

Two routers :

* :data:`router_under_doc` at
  ``/plugins/compta_esms/documents/{document_id}/tarifs-proposes`` —
  list + create + bulk-upsert + validate scoped to the parent EPRD.
* :data:`router_flat` at
  ``/plugins/compta_esms/tarifs-proposes/{tarif_id}`` — get / patch /
  delete by-id.

Permissions :
* GET → :func:`require_user`
* POST / PATCH / DELETE → :func:`require_admin` (la validation ARS/CD
  est un acte de direction).

Rate limits :
* GET → 100/min
* mutations standard → 30/min
* bulk-upsert → 10/min
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_admin, require_user

from piilot_pack_compta_esms.models.tarif_propose import (
    TarifProposeBulkItem,
    TarifProposeCreate,
    TarifProposeRead,
    TarifProposeUpdate,
    TarifValidationReport,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import tarifs_service
from piilot_pack_compta_esms.services.errors import DomainError

router_under_doc = APIRouter(
    prefix="/documents/{document_id}/tarifs-proposes",
    tags=["compta_esms:tarifs_proposes"],
)
router_flat = APIRouter(
    prefix="/tarifs-proposes",
    tags=["compta_esms:tarifs_proposes"],
)


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


# --------------------------------------------------------------------
# List + Create + Bulk + Validate
# --------------------------------------------------------------------


@router_under_doc.get("", response_model=list[TarifProposeRead])
@limiter.limit("100/minute")
async def list_tarifs(
    request: Request,
    document_id: UUID,
    auth: tuple = Depends(require_user),
) -> list[TarifProposeRead]:
    """L2 §23.1 — list tarifs proposés of an EPRD-class document."""
    company_id = _require_company(auth)
    try:
        return await tarifs_service.list_by_document(company_id, document_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_under_doc.post("", response_model=TarifProposeRead, status_code=status.HTTP_201_CREATED)
@limiter.limit("30/minute")
async def create_tarif(
    request: Request,
    document_id: UUID,
    payload: TarifProposeCreate,
    auth: tuple = Depends(require_admin),
) -> TarifProposeRead:
    """L2 §23.2 — create a single tarif row (admin only).

    Refuse 409 si une row existe déjà pour le triplet (doc, ETS,
    section) — appeler PATCH ou bulk-upsert pour update.
    """
    company_id = _require_company(auth)
    try:
        return await tarifs_service.create_tarif(company_id, document_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_under_doc.post(":bulk-upsert", response_model=list[TarifProposeRead])
@limiter.limit("10/minute")
async def bulk_upsert_tarifs(
    request: Request,
    document_id: UUID,
    items: list[TarifProposeBulkItem],
    auth: tuple = Depends(require_admin),
) -> list[TarifProposeRead]:
    """L2 §23.3 — upsert N (ETS, section) rows in one batch.

    Refuse 422 si un ETS n'appartient pas au tenant ou si le batch
    contient un doublon (ETS, section). Conserve les champs ATC sur
    les rows existantes — seuls libelle / montant_propose / motif sont
    rafraîchis.
    """
    company_id = _require_company(auth)
    try:
        return await tarifs_service.bulk_upsert(company_id, document_id, items)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_under_doc.get(":validate", response_model=TarifValidationReport)
@limiter.limit("100/minute")
async def validate_tarifs(
    request: Request,
    document_id: UUID,
    auth: tuple = Depends(require_user),
) -> TarifValidationReport:
    """L2 §23.4 — validation report par section.

    Backbone du §BD C1 R.314-222 (``produits_tarif_saisis ==
    produits_tarif_notifies``) et widget UI "tarifs status".
    """
    company_id = _require_company(auth)
    try:
        return await tarifs_service.build_validation_report(company_id, document_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# --------------------------------------------------------------------
# Flat by-id  : get / patch / delete
# --------------------------------------------------------------------


@router_flat.get("/{tarif_id}", response_model=TarifProposeRead)
@limiter.limit("100/minute")
async def get_tarif(
    request: Request,
    tarif_id: UUID,
    auth: tuple = Depends(require_user),
) -> TarifProposeRead:
    """L2 §23.5 — fetch a single tarif row."""
    company_id = _require_company(auth)
    try:
        return await tarifs_service.get_tarif(company_id, tarif_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.patch("/{tarif_id}", response_model=TarifProposeRead)
@limiter.limit("30/minute")
async def update_tarif(
    request: Request,
    tarif_id: UUID,
    payload: TarifProposeUpdate,
    auth: tuple = Depends(require_admin),
) -> TarifProposeRead:
    """L2 §23.6 — patch un tarif row.

    Permet :
      - L'update ESMS-side (libelle / montant_propose / motif) tant
        que statut == PROPOSE.
      - L'update ATC-side (montant_notifie / statut / date_validation /
        valide_par / motif_rejet) à n'importe quel moment.

    Refuse 422 si le statut courant est VALIDE_TRIPARTITE et qu'on
    tente une transition vers un autre statut (la décision tripartite
    est finale).
    """
    company_id = _require_company(auth)
    try:
        return await tarifs_service.update_tarif(company_id, tarif_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.delete("/{tarif_id}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_tarif(
    request: Request,
    tarif_id: UUID,
    auth: tuple = Depends(require_admin),
) -> None:
    """L2 §23.7 — hard-delete a tarif row."""
    company_id = _require_company(auth)
    try:
        await tarifs_service.delete_tarif(company_id, tarif_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
