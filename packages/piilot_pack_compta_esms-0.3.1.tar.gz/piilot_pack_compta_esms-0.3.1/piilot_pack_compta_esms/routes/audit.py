"""HTTP route §AI — audit log admin (L2 §22.1).

1 endpoint :

* GET ``/documents/{doc_id}/audit?action=&limit=50`` admin (100/min) —
  historique audit_events ordonné DESC.
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_admin

from piilot_pack_compta_esms.models.audit import AuditEventRead
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import audit_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{document_id}", tags=["compta_esms:audit"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router.get("/audit", response_model=list[AuditEventRead])
@limiter.limit("100/minute")
async def list_audit_events_route(
    request: Request,
    document_id: UUID,
    action: str | None = None,
    limit: int = 50,
    auth: tuple = Depends(require_admin),
) -> list[AuditEventRead]:
    """L2 §22.1 — historique audit_events admin.

    Query params :

    * ``action`` — filtre exact (ex ``workflow.transmit``,
      ``rgpd.consentement_saisi``, ``export.xlsx``). Omis = pas de filtre.
    * ``limit`` — max rows (défaut 50, max 500).

    Retourne 404 ``document_not_found`` si document inexistant ou
    cross-tenant (pas de leak doc_id). 422 ``audit_limit_out_of_range``
    si limit hors [1, 500].
    """
    company_id = _require_company(auth)
    try:
        return await audit_service.list_for_document(
            document_id,
            company_id,
            action_filter=action,
            limit=limit,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
