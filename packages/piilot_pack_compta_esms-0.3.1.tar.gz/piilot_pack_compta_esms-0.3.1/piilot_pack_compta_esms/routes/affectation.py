"""HTTP routes for affectation résultats (L2 §10, 4 endpoints).

Un router unique qui couvre les 4 endpoints :

* §10.1 GET /documents/{doc_id}/affectations (user) → AffectationsResponse
  (items + A par section + verdict pre-calculé)
* §10.2 PUT /documents/{doc_id}/affectations (builder) → AffectationsResponse
* §10.3 POST /documents/{doc_id}/affectations:validate (user) →
  AllocationValidationResult
* §10.4 GET /documents/{doc_id}/suivi-affectations (user) →
  list[SuiviAffectationRead]

Permissions L2 strict : GET/validate = user, PUT bulk = builder.
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.affectation import (
    AffectationBulkRequest,
    AffectationsResponse,
    AllocationValidationResult,
    SuiviAffectationRead,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import affectation_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{doc_id}", tags=["compta_esms:affectations"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


# ---------------------------------------------------------------------------
# §10.3 :validate — declared before {doc_id}/affectations root for action suffix
# ---------------------------------------------------------------------------


@router.post("/affectations:validate", response_model=AllocationValidationResult)
@limiter.limit("30/minute")
async def validate_affectations(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> AllocationValidationResult:
    """L2 §10.3 — vérifie le contrôle C-79/C-80 (Σ B = A par section,
    tolérance 0,01€). Pas de side-effect."""
    company_id = _require_company(auth)
    try:
        return await affectation_service.validate_allocations(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §10.1 + §10.2 — GET/PUT affectations
# ---------------------------------------------------------------------------


@router.get("/affectations", response_model=AffectationsResponse)
@limiter.limit("100/minute")
async def list_affectations(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> AffectationsResponse:
    """L2 §10.1 — affectations + A calculé par section + verdict
    pré-calculé. L'UI peut tout afficher sans appel séparé."""
    company_id = _require_company(auth)
    try:
        return await affectation_service.list_affectations(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.put("/affectations", response_model=AffectationsResponse)
@limiter.limit("10/minute")
async def put_affectations(
    request: Request,
    doc_id: UUID,
    payload: AffectationBulkRequest,
    auth: tuple = Depends(require_builder),
) -> AffectationsResponse:
    """L2 §10.2 — bulk-upsert by section. Variante + ventilation
    auto-déduites du contexte (Q3 + Q4). suivi_affectations alimenté
    dans la même transaction (Q6)."""
    company_id = _require_company(auth)
    try:
        return await affectation_service.put_affectations_bulk(doc_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §10.4 — GET /suivi-affectations
# ---------------------------------------------------------------------------


@router.get("/suivi-affectations", response_model=list[SuiviAffectationRead])
@limiter.limit("100/minute")
async def list_suivi_affectations(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> list[SuiviAffectationRead]:
    """L2 §10.4 — suivi mouvements par compte d'affectation
    (D-084 triplet solde N-1 / mouvements N / solde N)."""
    company_id = _require_company(auth)
    try:
        return await affectation_service.list_suivi_affectations(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
