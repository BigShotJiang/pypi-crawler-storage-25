"""HTTP routes pour §W RIA — Rapport Infra-Annuel.

L2 §4 — un endpoint dédié à l'onglet exclusif RIA ``Synthèse résultats``
(D-065, D-087, KB23 §3.3 + KB25 §14). Lecture seule, ``user`` 100/min.

Le clone RIA est exposé via §4.8 ``POST /documents/{id}/clone`` (livré
§E.3 + enrichi §V pour héritage CRs). Pas d'endpoint clone spécifique
RIA ici — toute la création passe par le même path polymorphe DM/RIA.

**0 contrôle intégré** (D-087) — RIA est un rapport infra-annuel
informatif sur l'avancement vs EPRD exécutoire, sans modifier
l'EPRD. Donc pas de workflow guard spécifique au-delà de §S.
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_user

from piilot_pack_compta_esms.models.ria import SyntheseResultatsResponse
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import ria_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{ria_id}", tags=["compta_esms:ria"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router.get(
    "/synthese-resultats",
    response_model=SyntheseResultatsResponse,
)
@limiter.limit("100/minute")
async def get_synthese_resultats_route(
    request: Request,
    ria_id: UUID,
    auth: tuple = Depends(require_user),
) -> SyntheseResultatsResponse:
    """§W D-065 — onglet exclusif RIA ``Synthèse résultats``.

    Retourne 1 ligne par CR du RIA + 1 ligne TOTAL, avec :

    * ``resultat_comptable_n_minus_1`` (depuis ERRD N-1 finalisé, optionnel)
    * ``eprd_executoire_n`` (depuis le parent EPRD)
    * ``projection_actualisee_n`` (depuis le RIA lui-même)

    Matching CR par ``(etablissement_id, cr_type)``. Aucune mutation, pas
    d'audit.

    Refuse 409 ``not_a_ria`` si le document n'est pas de type RIA.
    Refuse 409 ``ria_orphan`` si le RIA a ``parent_id`` NULL (data
    corruption — defensive). Refuse 404 ``document_not_found`` si le
    document n'existe pas pour cette company.
    """
    company_id = _require_company(auth)
    try:
        return await ria_service.compute_synthese_resultats(ria_id=ria_id, company_id=company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
