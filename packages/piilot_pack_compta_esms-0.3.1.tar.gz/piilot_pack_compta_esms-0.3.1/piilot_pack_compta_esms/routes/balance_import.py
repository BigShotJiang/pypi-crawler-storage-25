"""HTTP routes for balance imports (L2 §7bis.1 — 4 endpoints).

* §7bis.1.1 ``POST /balance-imports/upload`` (multipart, builder)
* §7bis.1.2 ``POST /balance-imports/{id}/detect-columns`` (builder)
* §7bis.1.3 ``GET /balance-imports/{id}`` (user)
* §7bis.1.4 ``GET /balance-imports/{id}/preview`` (user)
"""

from __future__ import annotations

from uuid import UUID

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Request,
    UploadFile,
    status,
)
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.balance_import import (
    BalanceImportPreview,
    BalanceImportRead,
    ColumnHints,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import balance_import_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/balance-imports", tags=["compta_esms:balance-imports"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router.post("/upload", response_model=BalanceImportRead, status_code=status.HTTP_201_CREATED)
@limiter.limit("10/minute")
async def upload_balance(
    request: Request,
    file: UploadFile = File(...),  # noqa: B008 — FastAPI File() idiom
    source_plan: str = Form(...),
    periode_label: str = Form(...),
    # Optional Form fields default to None (FastAPI infers Form when
    # mixed with multipart). Explicit ``Form(default=None)`` would
    # trigger ruff B008 ; the implicit version produces the same
    # OpenAPI for Optional fields.
    exercice_id: UUID | None = None,
    etablissement_id: UUID | None = None,
    auth: tuple = Depends(require_builder),
) -> BalanceImportRead:
    """L2 §7bis.1.1 — upload a balance source file.

    Multipart fields :

    * ``file`` (required) — ``.xlsx`` / ``.xlsm`` / ``.csv`` / ``.tsv``
      (max 50 Mo, frontend caps the upload).
    * ``source_plan`` (required) — one of PCG/M14/M21/M22Bis/Sage/EBP/
      Cegid/Pennylane/custom.
    * ``periode_label`` (required) — free-form, eg. ``"2025-12"`` or
      ``"2025-Q4"``.
    * ``exercice_id`` / ``etablissement_id`` (optional) — pinning the
      import to a fiscal year and an établissement.

    Returns the freshly-inserted ``balance_imports`` row with the
    sanitized file already on S3 and the column-role auto-detection
    applied."""
    company_id = _require_company(auth)
    user_id = UUID(str(auth[0]))
    body = await file.read()
    try:
        return await balance_import_service.upload_balance(
            company_id=company_id,
            user_id=user_id,
            file_bytes=body,
            filename=file.filename or "balance.xlsx",
            source_plan=source_plan,
            periode_label=periode_label,
            exercice_id=exercice_id,
            etablissement_id=etablissement_id,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
    except ValueError as exc:
        # Parser raised — bad file shape (empty workbook, unsupported ext)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "balance_import_parse_error",
                "message": str(exc),
            },
        ) from exc


@router.post("/{import_id}/detect-columns", response_model=BalanceImportRead)
@limiter.limit("30/minute")
async def detect_columns(
    request: Request,
    import_id: UUID,
    hints: ColumnHints | None = None,
    auth: tuple = Depends(require_builder),
) -> BalanceImportRead:
    """L2 §7bis.1.2 — override the column-role detection.

    Body is optional ; an empty body re-applies the heuristic (useful
    if the cabinet changed the source file's header). When present,
    each role in the body overrides the current detection ; explicit
    ``null`` unsets a role."""
    _require_company(auth)
    try:
        return await balance_import_service.detect_columns(import_id, hints)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/{import_id}", response_model=BalanceImportRead)
@limiter.limit("100/minute")
async def get_balance_import(
    request: Request,
    import_id: UUID,
    auth: tuple = Depends(require_user),
) -> BalanceImportRead:
    """L2 §7bis.1.3 — return the full ``balance_imports`` row."""
    _require_company(auth)
    try:
        return await balance_import_service.get_import(import_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/{import_id}/preview", response_model=BalanceImportPreview)
@limiter.limit("100/minute")
async def get_balance_preview(
    request: Request,
    import_id: UUID,
    auth: tuple = Depends(require_user),
) -> BalanceImportPreview:
    """L2 §7bis.1.4 — return ``{header, rows, column_detection}`` for
    the assistant's step-2 table."""
    _require_company(auth)
    try:
        return await balance_import_service.get_preview(import_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
