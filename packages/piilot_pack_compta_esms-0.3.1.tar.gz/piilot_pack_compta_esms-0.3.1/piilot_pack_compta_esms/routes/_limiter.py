"""Shared :class:`slowapi.Limiter` instance for the plugin.

Defined once at import time so every router decorates against the
same in-memory store. The host application is responsible for
attaching this limiter to its FastAPI ``app.state`` when the plugin's
routers are mounted; in standalone tests, the conftest patches
:func:`piilot.sdk.http.get_real_ip` so the ``key_func`` doesn't trip
on the SDK's ``NotImplementedError`` placeholder.
"""

from __future__ import annotations

from piilot.sdk.http import get_real_ip
from slowapi import Limiter


def _key_func(request) -> str:  # noqa: ANN001 — slowapi requires the raw Request
    """Identify a caller for rate limiting purposes.

    Uses the SDK's :func:`get_real_ip` so we get the Cloudflare-aware
    address rather than the proxy's IP. Falls back to ``"unknown"``
    if the SDK helper hasn't been wired (boot-time edge case).
    """
    try:
        return get_real_ip(request)
    except NotImplementedError:
        return "unknown"


limiter = Limiter(key_func=_key_func)
"""Shared limiter — import from routes and decorate handlers."""
