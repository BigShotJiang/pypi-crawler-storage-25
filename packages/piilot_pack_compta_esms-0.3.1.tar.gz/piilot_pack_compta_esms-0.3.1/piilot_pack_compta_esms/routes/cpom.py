"""HTTP routes for CPOM — §BA v0.3 (L2 §22, D-027).

Three routers, mounted under different prefixes :

* :data:`router_under_og` at
  ``/plugins/compta_esms/orgs/{og_id}/cpoms`` — list + create scoped
  to a parent OG.
* :data:`router_flat` at ``/plugins/compta_esms/cpoms/{cpom_id}`` —
  get / patch / delete by-id, plus link + objectif sub-resources.
* :data:`router_objectifs_flat` at
  ``/plugins/compta_esms/cpoms/{cpom_id}/objectifs/{obj_id}`` — flat
  by-id mutate of an objective (kept separate so FastAPI's path
  resolution doesn't conflate ``{obj_id}`` with the ``etablissements``
  sub-resource on ``router_flat``).

Permissions :
* GET → :func:`piilot.sdk.http.require_user`
* POST / PATCH / DELETE → :func:`piilot.sdk.http.require_admin`
  (CPOMs sont signés par l'OG, mutation = action de direction).

Rate limits :
* GET → 100/min
* mutations standard → 30/min
* bulk-link → 10/min
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_admin, require_user

from piilot_pack_compta_esms.models.cpom import (
    CpomCreate,
    CpomEsmsLinkItem,
    CpomEsmsLinkRead,
    CpomObjectifCreate,
    CpomObjectifRead,
    CpomObjectifUpdate,
    CpomProgress,
    CpomRead,
    CpomUpdate,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import cpom_service
from piilot_pack_compta_esms.services.errors import DomainError

router_under_og = APIRouter(prefix="/orgs/{og_id}/cpoms", tags=["compta_esms:cpoms"])
router_flat = APIRouter(prefix="/cpoms", tags=["compta_esms:cpoms"])
router_objectifs_flat = APIRouter(
    prefix="/cpoms/{cpom_id}/objectifs", tags=["compta_esms:cpom_objectifs"]
)


def _require_company(auth: tuple) -> UUID:
    """Same helper as the OG/ETS routes — extract the company UUID
    from the auth tuple and 400 if it's missing."""
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


# --------------------------------------------------------------------
# CPOM CRUD
# --------------------------------------------------------------------


@router_under_og.get("", response_model=list[CpomRead])
@limiter.limit("100/minute")
async def list_cpoms(
    request: Request,
    og_id: UUID,
    auth: tuple = Depends(require_user),
) -> list[CpomRead]:
    """L2 §22.1 — list CPOMs of an OG."""
    company_id = _require_company(auth)
    try:
        return await cpom_service.list_cpoms_by_og(company_id, og_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_under_og.post("", response_model=CpomRead, status_code=status.HTTP_201_CREATED)
@limiter.limit("30/minute")
async def create_cpom(
    request: Request,
    og_id: UUID,
    payload: CpomCreate,
    auth: tuple = Depends(require_admin),
) -> CpomRead:
    """L2 §22.2 — create CPOM under OG (admin only).

    The body must carry ``og_id`` matching the URL path ; the service
    enforces the match and surfaces a 422 ``og_id_mismatch`` on
    discrepancy.
    """
    company_id = _require_company(auth)
    try:
        return await cpom_service.create_cpom(company_id, og_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.get("/{cpom_id}", response_model=CpomRead)
@limiter.limit("100/minute")
async def get_cpom(
    request: Request,
    cpom_id: UUID,
    auth: tuple = Depends(require_user),
) -> CpomRead:
    """L2 §22.3 — fetch a single CPOM."""
    company_id = _require_company(auth)
    try:
        return await cpom_service.get_cpom(company_id, cpom_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.patch("/{cpom_id}", response_model=CpomRead)
@limiter.limit("30/minute")
async def update_cpom(
    request: Request,
    cpom_id: UUID,
    payload: CpomUpdate,
    auth: tuple = Depends(require_admin),
) -> CpomRead:
    """L2 §22.4 — patch CPOM (admin only).

    Recomputes ``date_fin_theorique`` if ``date_effet`` or
    ``duree_annees`` is in the payload.
    """
    company_id = _require_company(auth)
    try:
        return await cpom_service.update_cpom(company_id, cpom_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.delete("/{cpom_id}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_cpom(
    request: Request,
    cpom_id: UUID,
    auth: tuple = Depends(require_admin),
) -> None:
    """L2 §22.5 — hard-delete CPOM (admin only).

    Returns 204. Cascade-deletes ``cpom_esms_link`` and
    ``cpom_objectifs`` via FK CASCADE.
    """
    company_id = _require_company(auth)
    try:
        await cpom_service.delete_cpom(company_id, cpom_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# --------------------------------------------------------------------
# CPOM ↔ ESMS links
# --------------------------------------------------------------------


@router_flat.get("/{cpom_id}/etablissements", response_model=list[CpomEsmsLinkRead])
@limiter.limit("100/minute")
async def list_links(
    request: Request,
    cpom_id: UUID,
    auth: tuple = Depends(require_user),
) -> list[CpomEsmsLinkRead]:
    """L2 §22.6 — list (ETS, perimetre) pairs of a CPOM."""
    company_id = _require_company(auth)
    try:
        return await cpom_service.list_links_by_cpom(company_id, cpom_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.post(
    "/{cpom_id}/etablissements:bulk-link",
    response_model=list[CpomEsmsLinkRead],
)
@limiter.limit("10/minute")
async def bulk_link_etablissements(
    request: Request,
    cpom_id: UUID,
    items: list[CpomEsmsLinkItem],
    auth: tuple = Depends(require_admin),
) -> list[CpomEsmsLinkRead]:
    """L2 §22.7 — upsert N (ETS, perimetre) pairs in one batch.

    All ETS must belong to the CPOM's OG ; the service rejects the
    whole batch with 422 ``ets_og_mismatch`` if any item violates,
    so the UI can replay after fixing.
    """
    company_id = _require_company(auth)
    try:
        return await cpom_service.bulk_link_etablissements(company_id, cpom_id, items)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.delete(
    "/{cpom_id}/etablissements/{etablissement_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
@limiter.limit("30/minute")
async def unlink_etablissement(
    request: Request,
    cpom_id: UUID,
    etablissement_id: UUID,
    auth: tuple = Depends(require_admin),
) -> None:
    """L2 §22.8 — remove the (cpom, ets) link."""
    company_id = _require_company(auth)
    try:
        await cpom_service.unlink_etablissement(company_id, cpom_id, etablissement_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# --------------------------------------------------------------------
# CPOM Objectifs
# --------------------------------------------------------------------


@router_flat.get("/{cpom_id}/objectifs", response_model=list[CpomObjectifRead])
@limiter.limit("100/minute")
async def list_objectifs(
    request: Request,
    cpom_id: UUID,
    auth: tuple = Depends(require_user),
) -> list[CpomObjectifRead]:
    """L2 §22.9 — list objectives of a CPOM."""
    company_id = _require_company(auth)
    try:
        return await cpom_service.list_objectifs(company_id, cpom_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.post(
    "/{cpom_id}/objectifs",
    response_model=CpomObjectifRead,
    status_code=status.HTTP_201_CREATED,
)
@limiter.limit("30/minute")
async def create_objectif(
    request: Request,
    cpom_id: UUID,
    payload: CpomObjectifCreate,
    auth: tuple = Depends(require_admin),
) -> CpomObjectifRead:
    """L2 §22.10 — create objective under a CPOM."""
    company_id = _require_company(auth)
    try:
        return await cpom_service.create_objectif(company_id, cpom_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_objectifs_flat.patch("/{obj_id}", response_model=CpomObjectifRead)
@limiter.limit("30/minute")
async def update_objectif(
    request: Request,
    cpom_id: UUID,
    obj_id: UUID,
    payload: CpomObjectifUpdate,
    auth: tuple = Depends(require_admin),
) -> CpomObjectifRead:
    """L2 §22.11 — patch an objective.

    Verifies (via service) that ``obj_id`` belongs to the path
    ``cpom_id`` — refuses 422 ``objectif_cpom_mismatch`` otherwise.
    """
    company_id = _require_company(auth)
    try:
        return await cpom_service.update_objectif(company_id, cpom_id, obj_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_objectifs_flat.delete("/{obj_id}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_objectif(
    request: Request,
    cpom_id: UUID,
    obj_id: UUID,
    auth: tuple = Depends(require_admin),
) -> None:
    """L2 §22.12 — delete an objective."""
    company_id = _require_company(auth)
    try:
        await cpom_service.delete_objectif(company_id, cpom_id, obj_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# --------------------------------------------------------------------
# Reporting
# --------------------------------------------------------------------


@router_flat.get("/{cpom_id}/progress", response_model=CpomProgress)
@limiter.limit("100/minute")
async def get_progress(
    request: Request,
    cpom_id: UUID,
    auth: tuple = Depends(require_user),
) -> CpomProgress:
    """L2 §22.13 — return the objectives status histogram."""
    company_id = _require_company(auth)
    try:
        return await cpom_service.compute_progress(company_id, cpom_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
