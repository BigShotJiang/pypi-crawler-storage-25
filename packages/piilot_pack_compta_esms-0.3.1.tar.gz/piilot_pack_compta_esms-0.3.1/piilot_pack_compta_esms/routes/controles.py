"""HTTP routes §Z — contrôles intégrés (L2 §18).

3 endpoints sous ``/documents/{doc_id}/controles`` :

* GET — list (filtres statut/severite)
* POST :run — évalue le catalogue applicable
* GET /summary — synthèse OK/KO/NA

Permissions L2 §307 :

* GET → user (100/min)
* POST :run → builder (5/min — recompute coûteux)
* GET /summary → user (100/min)
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Body, Depends, HTTPException, Query, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import controles_service
from piilot_pack_compta_esms.services.controles_service import (
    ControleResultRead,
    ControlesSummary,
    RunControlesResult,
)
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{document_id}", tags=["compta_esms:controles"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router.get("/controles", response_model=list[ControleResultRead])
@limiter.limit("100/minute")
async def list_controles_route(
    request: Request,
    document_id: UUID,
    statut: str | None = Query(default=None, pattern="^(ok|ko|na)$"),
    severite: str | None = Query(default=None, pattern="^(info|warning|error)$"),
    auth: tuple = Depends(require_user),
) -> list[ControleResultRead]:
    """L2 §18.1 — list controls results pour un document."""
    company_id = _require_company(auth)
    try:
        return await controles_service.list_controles(
            document_id, company_id, statut=statut, severite=severite
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.post("/controles:run", response_model=RunControlesResult)
@limiter.limit("5/minute")
async def run_controles_route(
    request: Request,
    document_id: UUID,
    payload: dict | None = Body(default=None),  # noqa: B008 — FastAPI Body pattern
    auth: tuple = Depends(require_builder),
) -> RunControlesResult:
    """L2 §18.2 — évalue les contrôles applicables + persiste résultats.

    Body optionnel : ``{"controle_keys": ["C-001", "C-002"]}`` pour
    filter sur des codes spécifiques. Si omis → évalue tous les codes
    applicables au type_document.
    """
    company_id = _require_company(auth)
    codes_filter: list[str] | None = None
    if payload and isinstance(payload, dict):
        raw = payload.get("controle_keys") or payload.get("codes")
        if isinstance(raw, list):
            codes_filter = [str(c) for c in raw]
    try:
        return await controles_service.run_controles(
            document_id, company_id, codes_filter=codes_filter
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/controles/summary", response_model=ControlesSummary)
@limiter.limit("100/minute")
async def summary_controles_route(
    request: Request,
    document_id: UUID,
    auth: tuple = Depends(require_user),
) -> ControlesSummary:
    """L2 §18.3 — synthèse compteurs OK/KO/NA."""
    company_id = _require_company(auth)
    try:
        return await controles_service.compute_summary(document_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
