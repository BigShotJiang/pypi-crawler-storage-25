"""HTTP routes for the feature catalog (L2 §8, 2 endpoints).

Catalog is global (no company / no RLS — cf. §D.11), so these routes
don't read ``auth[2]``. They still require an authenticated user
because the catalog leaks the contract surface and the cabinet's
``compta-ESMS`` plan_comptable_cible.

Permissions per L2 :
* §8.1 GET ``/feature-catalog`` → ``require_user``
* §8.2 GET ``/feature-catalog/{feature_key}`` → ``require_user``
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from piilot.sdk.http import require_user

from piilot_pack_compta_esms.models.feature_catalog import (
    DocType,
    FeatureCatalogRead,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import feature_catalog_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/feature-catalog", tags=["compta_esms:feature-catalog"])


@router.get("", response_model=list[FeatureCatalogRead])
@limiter.limit("100/minute")
async def list_features(
    request: Request,
    doc_type: DocType | None = None,
    typologie: str | None = None,
    mandatory_only: bool = False,
    auth: tuple = Depends(require_user),
) -> list[FeatureCatalogRead]:
    """L2 §8.1 — list bindable features filtered by doc_type / typologie.

    Empty filters return the full catalog (16 features, cf. seed
    ``003_seed_feature_catalog.sql``). The Literal ``DocType`` validates
    ``doc_type`` against the polymorphism set; typology is free-form
    text (validated against the PLT-T1 reference catalog in §E.1, but
    here we keep it free to support PLT-T1 extensions without coupling
    the catalog read).
    """
    _ = auth  # accessed for the Depends side-effect only
    try:
        return await feature_catalog_service.list_features(
            doc_type=doc_type,
            typologie=typologie,
            mandatory_only=mandatory_only,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/{feature_key}", response_model=FeatureCatalogRead)
@limiter.limit("100/minute")
async def get_feature(
    request: Request,
    feature_key: str,
    auth: tuple = Depends(require_user),
) -> FeatureCatalogRead:
    """L2 §8.2 — detail of one feature, including ``columns_required``."""
    _ = auth
    try:
        return await feature_catalog_service.get_feature(feature_key)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
