"""HTTP routes for TPER/TER (L2 §11, 4 endpoints).

Permissions L2 strict (Q10) : **user partout** (différent §K/§N).

Rate limits L2 §304-308 (Q11) :

* GET → 100/min
* :bulk-upsert → **10/min** (bulk endpoint L2 §308)
* :prefill → 30/min (POST non-bulk standard)
* :totals → 100/min (GET)
"""

from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from piilot.sdk.http import require_user

from piilot_pack_compta_esms.models.tper_ter import (
    TperTerBulkUpsertRequest,
    TperTerPrefillRequest,
    TperTerPrefillResponse,
    TperTerResponse,
    TperTerTotalsResponse,
    TypeTableau,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import tper_ter_prefill, tper_ter_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{doc_id}", tags=["compta_esms:tper_ter"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


# ---------------------------------------------------------------------------
# Action suffixes (:bulk-upsert, :prefill, :totals) — déclarés AVANT
# GET /tper-ter root pour matching FastAPI
# ---------------------------------------------------------------------------


@router.post("/tper-ter:bulk-upsert", response_model=TperTerResponse)
@limiter.limit("10/minute")
async def bulk_upsert_tper_ter(
    request: Request,
    doc_id: UUID,
    payload: TperTerBulkUpsertRequest,
    auth: tuple = Depends(require_user),
) -> TperTerResponse:
    """L2 §11.2 — replace_by_(doc, ets, type_tableau) (Q3). Auto-déduit
    ``type_etablissement`` via ETS.typologie (Q9). Permissions user
    (L2 strict)."""
    company_id = _require_company(auth)
    try:
        return await tper_ter_service.bulk_upsert_tper_ter(doc_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.post("/tper-ter:prefill", response_model=TperTerPrefillResponse)
@limiter.limit("30/minute")
async def prefill_tper_ter(
    request: Request,
    doc_id: UUID,
    payload: TperTerPrefillRequest,
    auth: tuple = Depends(require_user),
) -> TperTerPrefillResponse:
    """L2 §11.3 — Pré-remplir depuis binding journal paie (mode
    binding only, Q5). Service ``import_tper_to_ter()`` D-047 différé."""
    company_id = _require_company(auth)
    try:
        return await tper_ter_prefill.prefill_from_binding(
            document_id=doc_id,
            company_id=company_id,
            ets_id=payload.ets_id,
            type_tableau=payload.type_tableau,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/tper-ter:totals", response_model=TperTerTotalsResponse)
@limiter.limit("100/minute")
async def get_totals(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> TperTerTotalsResponse:
    """L2 §11.4 — Totaux par catégorie + section (pondéré par
    pct_section)."""
    company_id = _require_company(auth)
    try:
        return await tper_ter_service.compute_totals(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §11.1 — GET /tper-ter
# ---------------------------------------------------------------------------


@router.get("/tper-ter", response_model=TperTerResponse)
@limiter.limit("100/minute")
async def get_tper_ter(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
    ets_id: Annotated[UUID | None, Query()] = None,
    type_tableau: Annotated[TypeTableau | None, Query()] = None,
) -> TperTerResponse:
    """L2 §11.1 — Items TPER/TER complets. Filtres optionnels
    ``?ets_id=...&type_tableau=...``."""
    company_id = _require_company(auth)
    try:
        return await tper_ter_service.list_tper_ter(
            doc_id, company_id, ets_id=ets_id, type_tableau=type_tableau
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
