"""Register every router with the host application.

Called once from ``Plugin.register()``. The SDK's
:func:`piilot.sdk.http.register_router` resolves the plugin namespace
from the ``current_plugin`` contextvar — so the final mount path is
always ``/plugins/compta_esms{router_prefix}/...``.
"""

from __future__ import annotations

from piilot.sdk.http import register_router

from piilot_pack_compta_esms.routes import activite as activite_routes
from piilot_pack_compta_esms.routes import affectation as affectation_routes
from piilot_pack_compta_esms.routes import annexe5 as annexe5_routes
from piilot_pack_compta_esms.routes import audit as audit_routes
from piilot_pack_compta_esms.routes import balance_apply as balance_apply_routes
from piilot_pack_compta_esms.routes import balance_import as balance_import_routes
from piilot_pack_compta_esms.routes import balance_mapping as balance_mapping_routes
from piilot_pack_compta_esms.routes import balance_suggestion as balance_suggestion_routes
from piilot_pack_compta_esms.routes import bilan as bilan_routes
from piilot_pack_compta_esms.routes import binding as binding_routes
from piilot_pack_compta_esms.routes import cles_repartition as cles_repartition_routes
from piilot_pack_compta_esms.routes import controles as controles_routes
from piilot_pack_compta_esms.routes import cpom as cpom_routes
from piilot_pack_compta_esms.routes import cr as cr_routes
from piilot_pack_compta_esms.routes import crp_ligne as crp_ligne_routes
from piilot_pack_compta_esms.routes import dm as dm_routes
from piilot_pack_compta_esms.routes import document as document_routes
from piilot_pack_compta_esms.routes import emprunts as emprunts_routes
from piilot_pack_compta_esms.routes import etablissement as ets_routes
from piilot_pack_compta_esms.routes import exercice as exercice_routes
from piilot_pack_compta_esms.routes import exports as exports_routes
from piilot_pack_compta_esms.routes import feature_catalog as feature_catalog_routes
from piilot_pack_compta_esms.routes import finance as finance_routes
from piilot_pack_compta_esms.routes import meta as meta_routes
from piilot_pack_compta_esms.routes import og as og_routes
from piilot_pack_compta_esms.routes import pgfp as pgfp_routes
from piilot_pack_compta_esms.routes import provisions as provisions_routes
from piilot_pack_compta_esms.routes import ratios as ratios_routes
from piilot_pack_compta_esms.routes import rcc as rcc_routes
from piilot_pack_compta_esms.routes import reference as reference_routes
from piilot_pack_compta_esms.routes import rgpd as rgpd_routes
from piilot_pack_compta_esms.routes import ria as ria_routes
from piilot_pack_compta_esms.routes import tarif_propose as tarif_propose_routes
from piilot_pack_compta_esms.routes import tf as tf_routes
from piilot_pack_compta_esms.routes import tper_ter as tper_ter_routes
from piilot_pack_compta_esms.routes import workflow as workflow_routes


def wire_routes() -> None:
    """Register all plugin routers with the host application.

    Routers carry their own ``/orgs`` or ``/etablissements`` prefix; we
    pass no extra prefix here, so the final mount is exactly the path
    advertised in the L2 spec.
    """
    register_router(og_routes.router)
    register_router(ets_routes.router_under_og)
    register_router(ets_routes.router_flat)
    register_router(exercice_routes.router_under_og)
    register_router(exercice_routes.router_flat)
    register_router(document_routes.router)
    register_router(cr_routes.router_under_doc)
    register_router(cr_routes.router_flat)
    register_router(reference_routes.router)
    register_router(balance_mapping_routes.router)
    register_router(balance_import_routes.router)
    register_router(balance_suggestion_routes.router)
    register_router(balance_apply_routes.router)
    register_router(feature_catalog_routes.router)
    register_router(binding_routes.router)
    register_router(crp_ligne_routes.router_under_cr)
    register_router(crp_ligne_routes.router_flat)
    register_router(affectation_routes.router)
    register_router(bilan_routes.router)
    register_router(tf_routes.router)
    register_router(provisions_routes.router)
    register_router(emprunts_routes.router)
    register_router(rcc_routes.router)
    register_router(pgfp_routes.router)
    register_router(tper_ter_routes.router)
    register_router(activite_routes.router)
    register_router(annexe5_routes.router)
    register_router(workflow_routes.router)
    register_router(rgpd_routes.router)
    register_router(dm_routes.router)
    register_router(ria_routes.router)
    register_router(cles_repartition_routes.router_under_ets)
    register_router(cles_repartition_routes.router_flat)
    register_router(controles_routes.router)
    # §BA v0.3 — CPOM (D-027)
    register_router(cpom_routes.router_under_og)
    register_router(cpom_routes.router_flat)
    register_router(cpom_routes.router_objectifs_flat)
    # §BB v0.3 — EPRD tarifs proposés
    register_router(tarif_propose_routes.router_under_doc)
    register_router(tarif_propose_routes.router_flat)
    register_router(ratios_routes.router)
    register_router(exports_routes.router_under_doc)
    register_router(exports_routes.router_flat)
    register_router(audit_routes.router)
    register_router(finance_routes.router)
    register_router(meta_routes.router)
