"""HTTP routes for Exercice (3 endpoints, L2 §3.x).

Two routers mounted under different prefixes :

* :data:`router_under_og` at ``/plugins/compta_esms/orgs/{og_id}/exercices``
  for list + create (scoped to a parent OG).
* :data:`router_flat` at ``/plugins/compta_esms/exercices/{exercice_id}``
  for get-by-id.

L2 spec §3 does **not** expose PATCH or DELETE — an exercice is
essentially immutable once opened. The cabinet drives the year-end
workflow by adding documents (EPRD/ERRD/DM/RIA), not by editing the
exercice itself.

Permissions :
* ``GET`` → ``require_user``
* ``POST`` → ``require_builder`` (cf. L2 §3.2 — builder can open
  a year, only the admin role is needed for OG-level settings).
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.exercice import ExerciceCreate, ExerciceRead
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import exercice_service
from piilot_pack_compta_esms.services.errors import DomainError

router_under_og = APIRouter(prefix="/orgs/{og_id}/exercices", tags=["compta_esms:exercices"])
router_flat = APIRouter(prefix="/exercices", tags=["compta_esms:exercices"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router_under_og.get("", response_model=list[ExerciceRead])
@limiter.limit("100/minute")
async def list_exercices(
    request: Request,
    og_id: UUID,
    auth: tuple = Depends(require_user),
) -> list[ExerciceRead]:
    """L2 §3.1 — list exercices of an OG (most recent first)."""
    _require_company(auth)
    return await exercice_service.list_exercices(og_id)


@router_under_og.post("", response_model=ExerciceRead, status_code=status.HTTP_201_CREATED)
@limiter.limit("30/minute")
async def create_exercice(
    request: Request,
    og_id: UUID,
    payload: ExerciceCreate,
    auth: tuple = Depends(require_builder),
) -> ExerciceRead:
    """L2 §3.2 — open a budget year on the OG.

    Year window: ``[today.year - 1, today.year + 1]`` (D-104).
    ``millesime_m22bis`` is auto-derived from ``annee`` when omitted
    (e.g. ``annee=2026`` → ``millesime_m22bis="2025-2026"``).
    """
    company_id = _require_company(auth)
    try:
        return await exercice_service.create_exercice(company_id, og_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.get("/{exercice_id}", response_model=ExerciceRead)
@limiter.limit("100/minute")
async def get_exercice(
    request: Request,
    exercice_id: UUID,
    auth: tuple = Depends(require_user),
) -> ExerciceRead:
    """L2 §3.3 — fetch a single exercice.

    The spec mentions "+ documents associés" — those are added by
    §E.3 (documents_budgetaires) and exposed through a dedicated
    endpoint there, not by inflating this response shape.
    """
    _require_company(auth)
    try:
        return await exercice_service.get_exercice(exercice_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
