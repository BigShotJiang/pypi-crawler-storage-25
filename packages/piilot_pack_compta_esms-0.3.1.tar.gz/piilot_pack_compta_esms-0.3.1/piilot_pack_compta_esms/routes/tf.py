"""HTTP routes for Tableau de financement (L2 §15, 3 endpoints).

3 endpoints (vs 4 pour §K bilan — pas de ``:validate`` séparé,
l'équilibre est inclus dans ``:totals`` selon L2 §15.3 explicite).

Permissions L2 standard :
* §15.1 GET → user
* §15.2 POST :bulk-upsert → builder
* §15.3 GET :totals → user
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.tf import (
    TfBulkUpsertRequest,
    TfResponse,
    TfTotalsResponse,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import tf_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{doc_id}", tags=["compta_esms:tf"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


# ---------------------------------------------------------------------------
# §15.2 :bulk-upsert + §15.3 :totals — action suffixes
# ---------------------------------------------------------------------------


@router.post("/tableau-financement:bulk-upsert", response_model=TfResponse)
@limiter.limit("10/minute")
async def bulk_upsert_tf(
    request: Request,
    doc_id: UUID,
    payload: TfBulkUpsertRequest,
    auth: tuple = Depends(require_builder),
) -> TfResponse:
    """L2 §15.2 — replace_all_by_document. Le cabinet renvoie
    l'intégralité du TF (50-100 lignes max) à chaque save (Q2)."""
    company_id = _require_company(auth)
    try:
        return await tf_service.bulk_upsert_tf(doc_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/tableau-financement:totals", response_model=TfTotalsResponse)
@limiter.limit("100/minute")
async def get_totals(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> TfTotalsResponse:
    """L2 §15.3 — totaux ressources/emplois + équilibre par colonne.

    ``type_tf`` est déduit de ``doc.type_document`` côté service.
    L'équilibre est inclus (Q6 — pas de :validate séparé).
    Tolérance 0.01€ (Q5)."""
    company_id = _require_company(auth)
    try:
        return await tf_service.compute_totals(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §15.1 — GET /tableau-financement
# ---------------------------------------------------------------------------


@router.get("/tableau-financement", response_model=TfResponse)
@limiter.limit("100/minute")
async def get_tf(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> TfResponse:
    """L2 §15.1 — TF/TFP complet. ``type_tf`` renseigne l'UI sur le
    set de colonnes à afficher (4 ERRD vs 8 TFP — Q1)."""
    company_id = _require_company(auth)
    try:
        return await tf_service.list_tf(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
