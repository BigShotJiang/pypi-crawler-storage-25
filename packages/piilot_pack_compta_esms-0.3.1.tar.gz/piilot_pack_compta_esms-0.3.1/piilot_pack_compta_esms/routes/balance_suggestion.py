"""HTTP routes for the balance suggestion pipeline (L2 §7bis.2 — 3 endpoints).

* §7bis.2.1 ``POST /balance-imports/{id}/suggest-mappings``
* §7bis.2.2 ``GET /balance-imports/{id}/suggestions``
* §7bis.2.3 ``POST /balance-imports/{id}/suggestions:accept-all-above``

Mounted on a dedicated router so the balance_import router stays
focused on upload + state ; the suggestion routes live in their own
prefix segment but share the ``/balance-imports/{id}/...`` path.
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.balance_import import BalanceImportRead
from piilot_pack_compta_esms.models.balance_mapping import BalanceMappingRead
from piilot_pack_compta_esms.models.suggestion import (
    AcceptAboveRequest,
    SourceAccountSuggestion,
    SuggestRequest,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import balance_suggestion_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/balance-imports", tags=["compta_esms:balance-suggestions"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router.post("/{import_id}/suggest-mappings", response_model=BalanceImportRead)
@limiter.limit("10/minute")
async def suggest_mappings(
    request: Request,
    import_id: UUID,
    payload: SuggestRequest | None = None,
    auth: tuple = Depends(require_builder),
) -> BalanceImportRead:
    """L2 §7bis.2.1 — compute KB+preset+(LLM) suggestions for the import.

    Empty body uses the defaults (``include_llm=False``,
    ``llm_threshold=0.7``, ``source_plan=None`` → use the import's
    stored plan). Result is stored on
    ``balance_imports.suggestions`` ; this endpoint returns the full
    refreshed import row for convenience."""
    company_id = _require_company(auth)
    body = payload or SuggestRequest()
    try:
        return await balance_suggestion_service.suggest_mappings(company_id, import_id, body)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get(
    "/{import_id}/suggestions",
    response_model=list[SourceAccountSuggestion],
)
@limiter.limit("100/minute")
async def list_suggestions(
    request: Request,
    import_id: UUID,
    confidence_min: float | None = Query(default=None, ge=0, le=1.0),
    origin: str | None = Query(default=None),
    auth: tuple = Depends(require_user),
) -> list[SourceAccountSuggestion]:
    """L2 §7bis.2.2 — list the stored suggestions, optionally filtered.

    ``origin`` is a comma-separated list of allowed origins
    (``pcg_to_m22bis_kb,preset,llm,manual``). The filter applies at
    the target level — a source row with multiple targets keeps the
    ones meeting both criteria, and gets dropped only if no target
    survives."""
    company_id = _require_company(auth)
    origins_list = [o.strip() for o in origin.split(",")] if origin else None
    try:
        return await balance_suggestion_service.list_suggestions(
            company_id,
            import_id,
            confidence_min=confidence_min,
            origins=origins_list,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.post(
    "/{import_id}/suggestions:accept-all-above",
    response_model=list[BalanceMappingRead],
)
@limiter.limit("10/minute")
async def accept_all_above(
    request: Request,
    import_id: UUID,
    payload: AcceptAboveRequest,
    auth: tuple = Depends(require_builder),
) -> list[BalanceMappingRead]:
    """L2 §7bis.2.3 — bulk-upsert suggestions ≥ threshold into balance_mappings.

    The threshold filter runs target-by-target ; a 1:N suggestion
    where one target meets the bar and another doesn't keeps the
    qualifying target only (the cabinet handles the rest manually
    in the assistant UI)."""
    company_id = _require_company(auth)
    try:
        return await balance_suggestion_service.accept_all_above(company_id, import_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
