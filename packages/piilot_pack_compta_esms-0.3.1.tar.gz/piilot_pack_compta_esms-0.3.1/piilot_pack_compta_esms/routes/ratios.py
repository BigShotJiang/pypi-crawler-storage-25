"""HTTP routes §AA — ratios financiers (L2 §17).

2 endpoints sous ``/documents/{doc_id}/`` :

* GET ``/ratios`` user (100/min) — calcule à la volée. Param
  ``?type=errd|pgfp|all`` filter optionnel.
* POST ``/ratios:recompute`` builder (5/min) — alias L2.
"""

from __future__ import annotations

from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import ratios_service
from piilot_pack_compta_esms.services.errors import DomainError
from piilot_pack_compta_esms.services.ratios_service import RatiosResponse

router = APIRouter(prefix="/documents/{document_id}", tags=["compta_esms:ratios"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router.get("/ratios", response_model=RatiosResponse)
@limiter.limit("100/minute")
async def get_ratios_route(
    request: Request,
    document_id: UUID,
    type: Literal["errd", "pgfp", "all"] = Query(default="all"),
    auth: tuple = Depends(require_user),
) -> RatiosResponse:
    """L2 §17.1 — ratios calculés avec seuils.

    Query param ``?type=`` filtre le périmètre :

    * ``all`` (défaut) — ERRD + PGFP applicable au doc_type
    * ``errd`` — 15 ratios D-091 only
    * ``pgfp`` — 8 ratios D-095 only (na pour les doc_types non
      prévisionnels comme ERRD/ERCP)
    """
    company_id = _require_company(auth)
    try:
        return await ratios_service.compute_ratios(document_id, company_id, type_filter=type)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.post("/ratios:recompute", response_model=RatiosResponse)
@limiter.limit("5/minute")
async def recompute_ratios_route(
    request: Request,
    document_id: UUID,
    auth: tuple = Depends(require_builder),
) -> RatiosResponse:
    """L2 §17.2 — recalculer les ratios (alias L2 du GET).

    Pas de cache à invalider — :recompute = re-exécution complète.
    Rate limit séparé (5/min) pour protéger du recompute en boucle.
    """
    company_id = _require_company(auth)
    try:
        return await ratios_service.recompute_ratios(document_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
