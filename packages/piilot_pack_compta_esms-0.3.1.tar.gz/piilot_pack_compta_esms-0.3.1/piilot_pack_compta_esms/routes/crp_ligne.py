"""HTTP routes for CRP lignes (§H, L2 §6 — 7 endpoints).

Two routers :

* :data:`router_under_cr` mounted under
  ``/plugins/compta_esms/crs/{cr_id}/lignes`` for list, create,
  :bulk-upsert, :prefill-from-binding, :totals — every op scoped to
  one CR.
* :data:`router_flat` mounted under ``/plugins/compta_esms/lignes/{ligne_id}``
  for PATCH and DELETE by id.

Permissions per L2 : every endpoint is ``user`` — saisie comptable
is the cabinet's daily workflow, not a configuration act. Document
workflow status (BROUILLON gate) is enforced at the document level
in §X, not here.

Rate limiting : 100/min reads, 30/min mutations. The
``:prefill-from-binding`` action is bumped down to 10/min because it
fans out to the §G aggregation pipeline (read-heavy on the bound KB).
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.crp_ligne import (
    BulkUpsertItem,
    CrpLigneCreate,
    CrpLigneRead,
    CrpLigneUpdate,
    CrpTotalsResponse,
    Groupe,
    Nature,
    PrefillFromBindingRequest,
    PrefillFromBindingResponse,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import (
    crp_ligne_service,
    crp_prefill_service,
)
from piilot_pack_compta_esms.services.errors import DomainError

router_under_cr = APIRouter(prefix="/crs/{cr_id}/lignes", tags=["compta_esms:crp-lignes"])
router_flat = APIRouter(prefix="/lignes", tags=["compta_esms:crp-lignes"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


# ---------------------------------------------------------------------------
# §6.7 :totals — declared before {ligne_id}-style routes (action suffix)
# ---------------------------------------------------------------------------


@router_under_cr.get("/totals", response_model=CrpTotalsResponse)
@limiter.limit("100/minute")
async def get_totals(
    request: Request,
    cr_id: UUID,
    auth: tuple = Depends(require_user),
) -> CrpTotalsResponse:
    """L2 §6.7 — totals by groupe + brut ecart.

    Validation R.314-222 (5 conditions) is **not** done here ; only
    the raw arithmetic ``produits − charges`` per column. See §I for
    the equilibrium service."""
    company_id = _require_company(auth)
    try:
        return await crp_ligne_service.totals(cr_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §6.5 :bulk-upsert — also under_cr, action-style suffix
# ---------------------------------------------------------------------------


@router_under_cr.post(":bulk-upsert", response_model=list[CrpLigneRead])
@limiter.limit("10/minute")
async def bulk_upsert_lignes(
    request: Request,
    cr_id: UUID,
    payload: list[BulkUpsertItem],
    auth: tuple = Depends(require_user),
) -> list[CrpLigneRead]:
    """L2 §6.5 — atomic bulk upsert. Each item is upserted by natural
    key ``(cr_id, groupe, nature, compte_m22bis)`` ; ``notes`` and the
    ``override_*`` / ``binding_id`` fields are preserved (COALESCE) when
    the payload omits them. ``compte_m22bis`` is validated permissively
    (Q7 fail-open)."""
    company_id = _require_company(auth)
    try:
        return await crp_ligne_service.bulk_upsert(cr_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §Y :apply-default-ventilation
# ---------------------------------------------------------------------------


@router_under_cr.post(":apply-default-ventilation")
@limiter.limit("5/minute")
async def apply_default_ventilation_route(
    request: Request,
    cr_id: UUID,
    auth: tuple = Depends(require_builder),
) -> dict:
    """§Y — recalcule la ventilation H/D/S/SEA pour toutes les lignes
    de charges du CR dont les 4 cols sont None.

    Pattern post-import balance : le cabinet importe une balance, les
    lignes sont créées sans ventilation, puis il invoque cet endpoint
    pour pousser les règles dures (D-055 65→H, 66→S) et appliquer les
    clés gestionnaires (D-057).

    Pas d'écrasement de saisie manuelle : si une ligne a déjà au moins
    1 col H/D/S/SEA non-None, elle est skipée (bucket
    ``lignes_skipees_manuelles``). Pas d'effet sur les produits (seuls
    les ``nature='charge'`` sont évalués).

    Retourne ``{lignes_ventilees, lignes_skipees_manuelles,
    lignes_sans_regle, total_lignes_evaluees}``.
    """
    company_id = _require_company(auth)
    try:
        report = await crp_ligne_service.apply_default_ventilation_to_cr(cr_id, company_id)
        return {"cr_id": str(cr_id), **report}
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §6.6 :prefill-from-binding
# ---------------------------------------------------------------------------


@router_under_cr.post(":prefill-from-binding", response_model=PrefillFromBindingResponse)
@limiter.limit("10/minute")
async def prefill_from_binding(
    request: Request,
    cr_id: UUID,
    payload: PrefillFromBindingRequest,
    auth: tuple = Depends(require_user),
) -> PrefillFromBindingResponse:
    """L2 §6.6 — pull aggregated amounts from each feature's §G binding
    into the CR. ``target_column`` is **required** (Q3 explicit) — the
    backend does not auto-deduce from doc_type.

    Returns per-feature counters (inserted / updated / skipped_overridden)
    so the UI can show "12 new, 47 refreshed, 3 protected"."""
    company_id = _require_company(auth)
    try:
        return await crp_prefill_service.prefill_from_binding(
            cr_id=cr_id,
            company_id=company_id,
            feature_keys=payload.feature_keys,
            target_column=payload.target_column,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §6.1 list lignes — root of the under_cr prefix
# ---------------------------------------------------------------------------


@router_under_cr.get("", response_model=list[CrpLigneRead])
@limiter.limit("100/minute")
async def list_lignes(
    request: Request,
    cr_id: UUID,
    groupe: Groupe | None = None,
    nature: Nature | None = None,
    auth: tuple = Depends(require_user),
) -> list[CrpLigneRead]:
    """L2 §6.1 — list lignes of a CR with optional groupe / nature filters."""
    company_id = _require_company(auth)
    try:
        return await crp_ligne_service.list_lignes(cr_id, company_id, groupe=groupe, nature=nature)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §6.2 create ligne
# ---------------------------------------------------------------------------


@router_under_cr.post("", response_model=CrpLigneRead, status_code=status.HTTP_201_CREATED)
@limiter.limit("30/minute")
async def create_ligne(
    request: Request,
    cr_id: UUID,
    payload: CrpLigneCreate,
    auth: tuple = Depends(require_user),
) -> CrpLigneRead:
    """L2 §6.2 — create one ligne. 409 if a row already exists for the
    same ``(groupe, nature, compte_m22bis)`` natural key."""
    company_id = _require_company(auth)
    try:
        return await crp_ligne_service.create_ligne(cr_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §6.3 / §6.4 — PATCH / DELETE flat by id
# ---------------------------------------------------------------------------


@router_flat.patch("/{ligne_id}", response_model=CrpLigneRead)
@limiter.limit("30/minute")
async def patch_ligne(
    request: Request,
    ligne_id: UUID,
    payload: CrpLigneUpdate,
    auth: tuple = Depends(require_user),
) -> CrpLigneRead:
    """L2 §6.3 — PATCH montants / label / notes. Q6 auto-flip :
    when the ligne has a ``binding_id`` (prefill source), this patch
    automatically sets ``override_balance=true`` so the next prefill
    skips the row. ``override_reason`` (optional in the payload) is
    captured as audit trail."""
    company_id = _require_company(auth)
    try:
        return await crp_ligne_service.update_ligne(ligne_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.delete("/{ligne_id}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_ligne(
    request: Request,
    ligne_id: UUID,
    auth: tuple = Depends(require_user),
) -> None:
    """L2 §6.4 — hard delete a ligne."""
    company_id = _require_company(auth)
    try:
        await crp_ligne_service.delete_ligne(ligne_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
