"""Proxy routes over core reference KBs (L2 §21).

The plugin exposes thin proxies on top of the core reference KBs so the
frontend can drive its dropdowns without talking to the
``/admin/reference-catalogs/*`` endpoints (which are staff-only) and
without baking the catalog values into the bundle.

Endpoints :

* ``GET /references/typologies-essms`` (L2 §21.3) — list ESMS typologie
  codes (PLT-T1, 46 codes).
* ``GET /references/conventions-collectives-esms`` — list convention
  collective codes (bonus catalogue shipped with PR #188).

Two-tier permission : ``require_user`` (any authenticated member of a
company) — references are read-only metadata, no tenant boundary.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_user

from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import pcg_to_m22bis, reference_lookup

router = APIRouter(prefix="/references", tags=["compta_esms:references"])


def _require_auth(auth: tuple) -> None:
    """Lightweight guard — only checks the auth tuple shape.

    Reference catalogs are cross-tenant ; no ``company_id`` check needed."""
    if auth is None or len(auth) < 1:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "unauthenticated", "message": "auth required"},
        )


@router.get("/typologies-essms", response_model=list[dict[str, Any]])
@limiter.limit("100/minute")
async def list_typologies_essms(
    request: Request,
    auth: tuple = Depends(require_user),
) -> list[dict[str, Any]]:
    """L2 §21.3 — list of ESMS typologie codes (PLT-T1).

    Returns the full catalog rows so the frontend can show the code +
    libellé + secteur etc. in its dropdown. Empty list if the core
    catalog hasn't been synced yet — the frontend shows a friendly
    "sync in progress" hint in that case.
    """
    _require_auth(auth)
    return await reference_lookup.list_all_rows(reference_lookup.TYPOLOGIES_SLUG)


@router.get("/m21", response_model=list[dict[str, Any]])
@limiter.limit("100/minute")
async def list_plan_comptable_m21(
    request: Request,
    version: str | None = None,
    class_num: str | None = None,
    limit: int = 500,
    auth: tuple = Depends(require_user),
) -> list[dict[str, Any]]:
    """§X — proxy plan comptable **M21** (secteur sanitaire, ERCP/EPCP).

    PLT-M21 livré §B.2 — la KB core ``com.piilot.core.plan-comptable-esms``
    contient M22Bis + M21 côte à côte. On filtre ``type='M21'`` ici pour
    que le frontend dropdown ERCP/EPCP n'affiche que les comptes
    sanitaires. ``version`` optionnel (millésime DGCS, ex ``"2024-2025"``).
    ``class_num`` optionnel pour pré-filtrer à un chapitre (ex ``"6"``
    pour les charges).
    """
    _require_auth(auth)
    filters: dict[str, Any] = {"type": "M21"}
    if version:
        filters["version"] = version
    if class_num:
        filters["class_num"] = class_num
    return await reference_lookup.list_filtered_rows(
        reference_lookup.PLAN_COMPTABLE_ESMS_SLUG,
        filters=filters,
        limit=min(limit, 5000),
    )


@router.get("/m22bis", response_model=list[dict[str, Any]])
@limiter.limit("100/minute")
async def list_plan_comptable_m22bis(
    request: Request,
    version: str | None = None,
    class_num: str | None = None,
    limit: int = 500,
    auth: tuple = Depends(require_user),
) -> list[dict[str, Any]]:
    """§X — proxy plan comptable **M22Bis** (médico-social, EPRD/ERRD/DM/RIA).

    Symétrique à :func:`list_plan_comptable_m21`. La KB core est la même,
    on filtre ``type='M22Bis'`` ici."""
    _require_auth(auth)
    filters: dict[str, Any] = {"type": "M22Bis"}
    if version:
        filters["version"] = version
    if class_num:
        filters["class_num"] = class_num
    return await reference_lookup.list_filtered_rows(
        reference_lookup.PLAN_COMPTABLE_ESMS_SLUG,
        filters=filters,
        limit=min(limit, 5000),
    )


@router.get("/conventions-collectives-esms", response_model=list[dict[str, Any]])
@limiter.limit("100/minute")
async def list_conventions_collectives(
    request: Request,
    auth: tuple = Depends(require_user),
) -> list[dict[str, Any]]:
    """List convention collective codes (bonus reference catalog).

    Same shape as :func:`list_typologies_essms` ; the frontend uses
    this for the ``convention_collective`` dropdown on Établissement
    settings.
    """
    _require_auth(auth)
    return await reference_lookup.list_all_rows(reference_lookup.CONVENTIONS_COLLECTIVES_SLUG)


# Allowlist des ``type_etablissement`` query param — alignée sur
# ``deduce_type_etablissement`` (4 valeurs cibles côté ``tper_ter_lignes``
# CHECK). Validation 422 ``type_etablissement_invalid`` sinon.
_CNSA_TYPE_ETS_ALLOWED: frozenset[str] = frozenset(
    {"ehpad_aja", "fam_samsah", "sad_spasad", "autre_essms"}
)


@router.get("/cnsa-fonctions", response_model=list[dict[str, Any]])
@limiter.limit("100/minute")
async def list_cnsa_fonctions(
    request: Request,
    type_etablissement: str | None = None,
    limit: int = 500,
    auth: tuple = Depends(require_user),
) -> list[dict[str, Any]]:
    """L2 §21.4 — proxy CNSA fonctions TPER/TER (PLT-44 KB core).

    Retourne la liste des fonctions CNSA accompagnée des coefficients
    de ventilation (taux soins/dépendance/hébergement, conv. CCN51/CCN66).
    PLT-44 core livre la KB en `com.piilot.core.cnsa-fonctions-esms`
    — tant qu'elle n'est pas seedée côté core, ce endpoint retourne
    une liste vide (le frontend affiche un hint "sync en cours").

    ``type_etablissement`` filtre par catégorie CNSA :

    * ``ehpad_aja`` (10 catégories EHPAD/AJA)
    * ``fam_samsah`` (8 catégories FAM/MAS/SAMSAH)
    * ``sad_spasad``
    * ``autre_essms``

    Mappé sur la colonne ``categorie_code`` de la KB core. Filtre rejeté
    HTTP 422 ``type_etablissement_invalid`` si valeur hors allowlist.
    """
    _require_auth(auth)
    filters: dict[str, Any] = {}
    if type_etablissement:
        if type_etablissement not in _CNSA_TYPE_ETS_ALLOWED:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail={
                    "code": "type_etablissement_invalid",
                    "message": (
                        f"type_etablissement={type_etablissement!r} invalide. "
                        f"Valeurs : {sorted(_CNSA_TYPE_ETS_ALLOWED)}."
                    ),
                },
            )
        filters["categorie_code"] = type_etablissement
    return await reference_lookup.list_filtered_rows(
        reference_lookup.CNSA_FONCTIONS_SLUG,
        filters=filters if filters else None,
        limit=min(limit, 5000),
    )


# ---------------------------------------------------------------------------
# L2 §7bis.5 — pcg_to_m22bis (KB plugin-owned, in-memory at boot)
# ---------------------------------------------------------------------------


@router.get("/pcg-to-m22bis", response_model=list[dict[str, Any]])
@limiter.limit("100/minute")
async def lookup_pcg_to_m22bis(
    request: Request,
    source_plan: str = "PCG",
    source_account: str = "",
    version_m22bis: str = "2025-2026",
    auth: tuple = Depends(require_user),
) -> list[dict[str, Any]]:
    """L2 §7bis.5.1 — look up the M22 bis correspondence for a source account.

    Returns the list of mapping rows for ``(source_plan, source_account)``.
    Multiple rows = 1:N split (each row carries its own ``weight``). Empty
    list when the catalog has no known mapping — the suggestion service
    falls through to presets, then LLM."""
    _require_auth(auth)
    if not source_account:
        return []
    return pcg_to_m22bis.lookup(source_plan, source_account, version_m22bis)


@router.get("/pcg-to-m22bis/search", response_model=list[dict[str, Any]])
@limiter.limit("100/minute")
async def search_pcg_to_m22bis(
    request: Request,
    q: str | None = None,
    class_num: str | None = None,
    limit: int = 20,
    auth: tuple = Depends(require_user),
) -> list[dict[str, Any]]:
    """L2 §7bis.5.2 — search the catalog by libellé or class prefix.

    Powers the assistant's "search" box ("eau" → 60611). Capped at
    ``limit`` rows (default 20, max 100 — anti-abuse)."""
    _require_auth(auth)
    return pcg_to_m22bis.search(q=q, class_num=class_num, limit=min(limit, 100))


@router.get("/presets-outils", response_model=list[dict[str, Any]])
@limiter.limit("100/minute")
async def list_presets_outils(
    request: Request,
    auth: tuple = Depends(require_user),
) -> list[dict[str, Any]]:
    """L2 §7bis.5.3 — list preset names (Pennylane, Sage, EBP, Cegid).

    Returns ``[{name, description}]`` only — the per-preset mapping
    body is fetched via the detail endpoint to keep this payload small."""
    _require_auth(auth)
    return pcg_to_m22bis.list_presets()


@router.get("/presets-outils/{preset_name}", response_model=dict[str, Any])
@limiter.limit("100/minute")
async def get_preset_outil(
    request: Request,
    preset_name: str,
    auth: tuple = Depends(require_user),
) -> dict[str, Any]:
    """L2 §7bis.5.4 — fetch a preset detail (name + description + mappings).

    Returns 404 when the preset name is unknown."""
    _require_auth(auth)
    preset = pcg_to_m22bis.get_preset(preset_name)
    if preset is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"code": "preset_not_found", "message": preset_name},
        )
    return preset
