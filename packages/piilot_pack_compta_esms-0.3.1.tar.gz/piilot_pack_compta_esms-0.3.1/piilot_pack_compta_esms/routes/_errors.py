"""Translate domain errors to ``HTTPException`` at the route boundary.

Services raise :class:`piilot_pack_compta_esms.services.errors.DomainError`
subclasses; this helper converts the exception to a ``HTTPException``
with a structured ``detail`` payload (``{"code": ..., "message": ...}``)
so the frontend can branch on the stable ``code`` without parsing prose.

Used as a small ``try/except`` wrapper inside each route handler — we
deliberately avoid a global exception handler so that a route that
wants to catch a specific error and recover (rather than 4xx) stays
free to do so.
"""

from __future__ import annotations

from fastapi import HTTPException

from piilot_pack_compta_esms.services.errors import DomainError


def domain_error_to_http(exc: DomainError) -> HTTPException:
    """Convert a domain error to its ``HTTPException`` equivalent.

    Preserves the ``code`` field in ``detail`` so the frontend can
    distinguish (e.g.) ``og_finess_taken`` from ``og_has_etablissements``.
    """
    return HTTPException(
        status_code=exc.status_code,
        detail={"code": exc.code, "message": str(exc)},
    )
