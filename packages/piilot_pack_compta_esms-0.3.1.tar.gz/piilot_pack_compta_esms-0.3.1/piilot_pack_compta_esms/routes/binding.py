"""HTTP routes for D-103 bindings (L2 §7, 6 endpoints).

Single flat router mounted under
``/plugins/compta_esms/documents/{doc_id}/bindings/*``. The action-style
suffixes (``:preview`` / ``:validation``) follow Piilot's convention
elsewhere (cf. §F balance-imports).

Permissions per L2 :
* §7.1 GET list → ``require_user``
* §7.2 GET candidate-kbs → ``require_user``
* §7.3 PUT binding → ``require_builder``
* §7.4 DELETE binding → ``require_builder``
* §7.5 POST :preview → ``require_user``
* §7.6 GET :validation → ``require_user``
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.kb_binding import (
    BindingPreviewRequest,
    BindingPreviewResponse,
    BindingValidationResult,
    CandidateKb,
    KbBindingCreate,
    KbBindingRead,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import binding_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(
    prefix="/documents/{doc_id}/bindings",
    tags=["compta_esms:bindings"],
)


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


def _require_user_id(auth: tuple) -> UUID:
    user_id = auth[0]
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "missing_user", "message": "Authentication required"},
        )
    return UUID(str(user_id))


# ---------------------------------------------------------------------------
# §7.6 :validation — must come BEFORE the {feature_key} catch-all so
# FastAPI routes it as a literal path and not as feature_key=":validation".
# ---------------------------------------------------------------------------


@router.get(":validation", response_model=BindingValidationResult)
@limiter.limit("100/minute")
async def get_validation(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> BindingValidationResult:
    """L2 §7.6 — report whether mandatory features are all bound.

    Returns ``ready_to_produce=true`` when every mandatory feature
    applicable to the document (filtered by ``type_document`` and the
    typology of the first CR's établissement) has a binding."""
    company_id = _require_company(auth)
    try:
        return await binding_service.validation(document_id=doc_id, company_id=company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §7.2 candidate-kbs — also a fixed sub-path, declared before {feature_key}.
# ---------------------------------------------------------------------------


@router.get("/candidate-kbs", response_model=list[CandidateKb])
@limiter.limit("100/minute")
async def list_candidate_kbs(
    request: Request,
    doc_id: UUID,
    feature_key: str,
    auth: tuple = Depends(require_user),
) -> list[CandidateKb]:
    """L2 §7.2 — list KBs that satisfy ``feature_key``'s column contract.

    Permissive type matching (Q3.b) : KBs with a type mismatch are
    still returned, but each candidate carries a list of
    :class:`ColumnCompatWarning` so the UI can show a ⚠ badge."""
    company_id = _require_company(auth)
    try:
        return await binding_service.list_candidate_kbs(
            document_id=doc_id,
            feature_key=feature_key,
            company_id=company_id,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §7.1 list bindings (root of the prefix)
# ---------------------------------------------------------------------------


@router.get("", response_model=list[KbBindingRead])
@limiter.limit("100/minute")
async def list_bindings(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> list[KbBindingRead]:
    """L2 §7.1 — list current bindings of a document."""
    company_id = _require_company(auth)
    try:
        return await binding_service.list_bindings(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §7.5 :preview — POST under {feature_key}, declared before the bare
# PUT/DELETE so the path matcher catches the action suffix.
# ---------------------------------------------------------------------------


@router.post(
    "/{feature_key}:preview",
    response_model=BindingPreviewResponse,
)
@limiter.limit("30/minute")
async def preview_binding(
    request: Request,
    doc_id: UUID,
    feature_key: str,
    payload: BindingPreviewRequest | None = None,
    auth: tuple = Depends(require_user),
) -> BindingPreviewResponse:
    """L2 §7.5 — preview the aggregation the binding will produce.

    Body is optional ; an absent body defaults to an empty ``filters``
    dict (= aggregate everything in the bound KB)."""
    company_id = _require_company(auth)
    body = payload or BindingPreviewRequest()
    try:
        return await binding_service.preview_binding(
            document_id=doc_id,
            feature_key=feature_key,
            company_id=company_id,
            filters=body.filters,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §7.3 / §7.4 — PUT / DELETE binding
# ---------------------------------------------------------------------------


@router.put("/{feature_key}", response_model=KbBindingRead)
@limiter.limit("30/minute")
async def put_binding(
    request: Request,
    doc_id: UUID,
    feature_key: str,
    payload: KbBindingCreate,
    auth: tuple = Depends(require_builder),
) -> KbBindingRead:
    """L2 §7.3 — create or replace a binding (idempotent upsert)."""
    company_id = _require_company(auth)
    user_id = _require_user_id(auth)
    try:
        return await binding_service.put_binding(
            document_id=doc_id,
            feature_key=feature_key,
            payload=payload,
            company_id=company_id,
            user_id=user_id,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.delete("/{feature_key}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_binding(
    request: Request,
    doc_id: UUID,
    feature_key: str,
    auth: tuple = Depends(require_builder),
) -> None:
    """L2 §7.4 — drop a binding. 404 if no binding for that pair."""
    company_id = _require_company(auth)
    try:
        await binding_service.delete_binding(doc_id, feature_key, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
