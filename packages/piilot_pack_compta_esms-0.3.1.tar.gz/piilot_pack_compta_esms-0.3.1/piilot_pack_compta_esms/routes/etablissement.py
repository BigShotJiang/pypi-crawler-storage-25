"""HTTP routes for Établissement CRUD.

Two routers mounted under different prefixes (cf. L2 §2.x):

* :data:`router_under_og` at ``/plugins/compta_esms/orgs/{og_id}/etablissements``
  for list + create (scoped to a parent OG).
* :data:`router_flat` at ``/plugins/compta_esms/etablissements/{ets_id}``
  for get / patch / delete (by-id, no parent in path).

Permissions identical to OG : reads = user, writes = admin.
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from piilot.sdk.http import require_admin, require_user

from piilot_pack_compta_esms.models.etablissement import (
    EtablissementCreate,
    EtablissementRead,
    EtablissementUpdate,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import etablissement_service
from piilot_pack_compta_esms.services.errors import DomainError

router_under_og = APIRouter(
    prefix="/orgs/{og_id}/etablissements", tags=["compta_esms:etablissements"]
)
router_flat = APIRouter(prefix="/etablissements", tags=["compta_esms:etablissements"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router_under_og.get("", response_model=list[EtablissementRead])
@limiter.limit("100/minute")
async def list_etablissements(
    request: Request,
    og_id: UUID,
    typologie: str | None = Query(default=None),
    auth: tuple = Depends(require_user),
) -> list[EtablissementRead]:
    """L2 §2.1 — list établissements of an OG."""
    _require_company(auth)
    return await etablissement_service.list_etablissements(og_id, typologie)


@router_under_og.post("", response_model=EtablissementRead, status_code=status.HTTP_201_CREATED)
@limiter.limit("30/minute")
async def create_etablissement(
    request: Request,
    og_id: UUID,
    payload: EtablissementCreate,
    auth: tuple = Depends(require_admin),
) -> EtablissementRead:
    """L2 §2.2 — create établissement under OG (admin only).

    The body must carry ``og_id`` matching the URL path; the service
    enforces the match and 409s on mismatch.
    """
    company_id = _require_company(auth)
    try:
        return await etablissement_service.create_etablissement(company_id, og_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.get("/{ets_id}", response_model=EtablissementRead)
@limiter.limit("100/minute")
async def get_etablissement(
    request: Request,
    ets_id: UUID,
    auth: tuple = Depends(require_user),
) -> EtablissementRead:
    """L2 §2.3 — fetch single établissement."""
    _require_company(auth)
    try:
        return await etablissement_service.get_etablissement(ets_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.patch("/{ets_id}", response_model=EtablissementRead)
@limiter.limit("30/minute")
async def update_etablissement(
    request: Request,
    ets_id: UUID,
    payload: EtablissementUpdate,
    auth: tuple = Depends(require_admin),
) -> EtablissementRead:
    """L2 §2.4 — patch établissement (admin only)."""
    company_id = _require_company(auth)
    try:
        return await etablissement_service.update_etablissement(company_id, ets_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.delete("/{ets_id}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_etablissement(
    request: Request,
    ets_id: UUID,
    auth: tuple = Depends(require_admin),
) -> None:
    """L2 §2.5 — hard-delete établissement (admin only).

    Returns 409 if any Compte de Résultat references the établissement.
    """
    company_id = _require_company(auth)
    try:
        await etablissement_service.delete_etablissement(company_id, ets_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
