"""HTTP routes for Annexe 5 Financière + forfait paramètres (L2 §13,
4 endpoints).

Permissions L2 mixtes (Q11) :

* §13.1 GET /annexe5 → user
* §13.2 POST :bulk-upsert → user
* §13.3 GET /forfait-parametres → user
* §13.4 **PUT /forfait-parametres → builder** (mutation paramètres
  réglementaires GMP/PMP/GMPS sensibles)

Rate limits L2 §304-308 (Q12) :

* GET → 100/min
* :bulk-upsert → 10/min L2 §308
* PUT → 30/min (mutations standard non-bulk)
"""

from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.annexe5 import (
    Annexe5BulkUpsertRequest,
    Annexe5Response,
    ForfaitParametresListResponse,
    ForfaitParametresRead,
    ForfaitParametresUpdate,
    VarianteAnnexe5,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import annexe5_service, forfait_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{doc_id}", tags=["compta_esms:annexe5"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


# ---------------------------------------------------------------------------
# Action suffix (:bulk-upsert) — déclaré AVANT GET /annexe5 root
# ---------------------------------------------------------------------------


@router.post("/annexe5:bulk-upsert", response_model=Annexe5Response)
@limiter.limit("10/minute")
async def bulk_upsert_annexe5(
    request: Request,
    doc_id: UUID,
    payload: Annexe5BulkUpsertRequest,
    auth: tuple = Depends(require_user),
) -> Annexe5Response:
    """L2 §13.2 — replace_by_(doc, ets, variante) (Q1). Refuse 422
    ``annexe5_not_applicable`` si typologie ETS hors EHPAD/FAM/SAD (Q6)."""
    company_id = _require_company(auth)
    try:
        return await annexe5_service.bulk_upsert_annexe5(doc_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §13.1 — GET /annexe5
# ---------------------------------------------------------------------------


@router.get("/annexe5", response_model=Annexe5Response)
@limiter.limit("100/minute")
async def get_annexe5(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
    ets_id: Annotated[UUID | None, Query()] = None,
    variante: Annotated[VarianteAnnexe5 | None, Query()] = None,
) -> Annexe5Response:
    """L2 §13.1 — Items Annexe 5. Filtres optionnels
    ``?ets_id=...&variante=5A_ehpad``."""
    company_id = _require_company(auth)
    try:
        return await annexe5_service.list_annexe5(
            doc_id, company_id, ets_id=ets_id, variante=variante
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §13.4 PUT /forfait-parametres — déclaré AVANT GET pour matching FastAPI
# ---------------------------------------------------------------------------


@router.put("/forfait-parametres", response_model=ForfaitParametresRead)
@limiter.limit("30/minute")
async def put_forfait_parametres(
    request: Request,
    doc_id: UUID,
    payload: ForfaitParametresUpdate,
    auth: tuple = Depends(require_builder),
) -> ForfaitParametresRead:
    """L2 §13.4 — MAJ paramètres forfait (GMP/PMP/GMPS + points GIR).
    DELETE+INSERT par (doc, ets) idempotent (Q7).

    Permissions **builder** (mutation paramètres réglementaires
    sensibles)."""
    company_id = _require_company(auth)
    try:
        return await forfait_service.upsert_forfait_parametres(doc_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §13.3 — GET /forfait-parametres
# ---------------------------------------------------------------------------


@router.get("/forfait-parametres", response_model=ForfaitParametresListResponse)
@limiter.limit("100/minute")
async def get_forfait_parametres(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> ForfaitParametresListResponse:
    """L2 §13.3 — Liste des params forfait du document (1 par ets).

    Q8 fail-open EHPAD-only — retourne toutes les rows, peu importe
    la typologie (frontend filtre selon contexte)."""
    company_id = _require_company(auth)
    try:
        return await forfait_service.list_forfait_parametres(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
