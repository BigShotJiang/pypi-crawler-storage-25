"""HTTP routes §R Q10 — calculs financiers transverses :compute.

3 endpoints qui exposent la biblio §I (`services/finance/*`) via HTTP
REST. La biblio est aussi consommée par les agent tools §AH
(`compute_indicateurs`), les ratios §AA et les services métier
(`indicateurs_service`) — ces endpoints ajoutent juste un point
d'accès direct pour les cabinets qui veulent appeler les calculs
sans passer par un document budgétaire.

3 endpoints sous ``/finance/`` :

* POST ``/finance/forfait-dependance:compute`` — F.DEP.01 + F.GIR.03
  modulation TO. Pure (pas de DB). Input/output Pydantic stricts.
* POST ``/finance/gmp-departemental:compute`` — F.GIR.02 Σ(points × HP)
  / Σ(HP). Pure (pas de DB). Le caller fournit la liste EHPAD.
* POST ``/finance/valeur-point-gir:compute`` — F.GIR.01 R.314-175.
  Async (consomme la KB référentielle core PLT-VG via
  `reference_lookup.valeur_point_gir_with_clapet`).

Tous les endpoints sont **stateless** : pas de mutation DB, pas
d'audit trail. Niveau de permission ``require_user`` (consultation).
Rate limit 100/min (calculs légers, mêmes seuils que les autres
endpoints calculatoires).
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from piilot.sdk.http import require_user

from piilot_pack_compta_esms.models.finance import (
    ForfaitDependanceInput,
    ForfaitDependanceResult,
    GmpDepartementalInput,
    GmpDepartementalResult,
    ValeurPointGirInput,
    ValeurPointGirResult,
)
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services.finance.forfait_dependance_calculator import (
    compute_forfait_dependance_cd,
    compute_gmp_departemental,
)
from piilot_pack_compta_esms.services.finance.valeur_point_gir_resolver import (
    resolve_valeur_point_gir,
)

router = APIRouter(prefix="/finance", tags=["compta_esms:finance"])


@router.post(
    "/forfait-dependance:compute",
    response_model=ForfaitDependanceResult,
)
@limiter.limit("100/minute")
async def compute_forfait_dependance_route(
    request: Request,
    payload: ForfaitDependanceInput,
    _auth: tuple = Depends(require_user),
) -> ForfaitDependanceResult:
    """L2 §R Q10.1 — Forfait dépendance CD d'implantation.

    Formule de base (S03 p.19) :

    ``Forfait_cd = Forfait_global_dep − [(particip × TO_prev)
                                        + (hors_dept × TO_prev)]``

    Modulation R.314-174 (>= 2018) : si TO_realise < seuil →
    abattement = (seuil − TO_realise) / 2 en %, appliqué
    multiplicativement sur le brut. Plafond TO 95% : pas de
    modulation au-dessus.

    Pure function — pas de mutation DB, pas d'audit. Caller fournit
    tous les inputs Pydantic v2 (`extra='forbid'`).
    """
    return compute_forfait_dependance_cd(payload)


@router.post(
    "/gmp-departemental:compute",
    response_model=GmpDepartementalResult,
)
@limiter.limit("100/minute")
async def compute_gmp_departemental_route(
    request: Request,
    payload: GmpDepartementalInput,
    _auth: tuple = Depends(require_user),
) -> GmpDepartementalResult:
    """L2 §R Q10.2 — GMP départemental.

    GMP = Σ(points_GIR × capacite_HP) / Σ(capacite_HP), hors USLD
    (S03 p.21). Le caller doit avoir filtré les USLD avant l'appel.

    Renvoie ``gmp=0`` si la liste est vide ou si Σ(HP)=0 (cas dégénéré
    département sans EHPAD).
    """
    return compute_gmp_departemental(payload)


@router.post(
    "/valeur-point-gir:compute",
    response_model=ValeurPointGirResult,
)
@limiter.limit("100/minute")
async def compute_valeur_point_gir_route(
    request: Request,
    payload: ValeurPointGirInput,
    _auth: tuple = Depends(require_user),
) -> ValeurPointGirResult:
    """L2 §R Q10.3 — Valeur point GIR départemental (R.314-175).

    Lookup KB référentielle core PLT-VG avec clapet anti-retour
    R.314-175 (``valeur(N) >= valeur(N-1)`` enforced). Si
    ``est_prive_commercial=true`` → multiplie par 1,055 (TVA 5,5%
    TTC, S03 p.21).

    Async (consomme la KB ref via `run_in_thread`). Retourne aussi
    la valeur brute (pré-clapet, pré-TVA) pour traçabilité audit +
    flag ``clapet_applique`` + ``fallback_annee`` (N-1 si N pas
    encore publié par le PCD).
    """
    return await resolve_valeur_point_gir(payload)
