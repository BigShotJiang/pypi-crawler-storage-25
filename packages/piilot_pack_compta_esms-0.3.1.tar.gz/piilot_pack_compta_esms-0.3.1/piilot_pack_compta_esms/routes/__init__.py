"""FastAPI routers exposed by the plugin.

The :func:`wire_routes` entry point is called from ``Plugin.register``
and uses :func:`piilot.sdk.http.register_router` to mount each router
under ``/plugins/compta_esms{prefix}/``.

Rate limiting uses a per-plugin :class:`slowapi.Limiter` instance keyed
by :func:`piilot.sdk.http.get_real_ip` (which respects Cloudflare
``CF-Connecting-IP``). The instance is shared across routers — defined
in :mod:`_limiter` rather than per-route so the same backing store
sees all requests from the plugin.
"""

from piilot_pack_compta_esms.routes.wire import wire_routes

__all__ = ["wire_routes"]
