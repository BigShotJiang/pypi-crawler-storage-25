"""HTTP routes for Provisions (L2 §16.1-§16.2, 2 endpoints).

Permissions L2 standard (Q10) :
* §16.1 GET → user
* §16.2 POST :bulk-upsert → builder

Rate limits L2 §304-308 (Q11) :
* GET → 100/min
* :bulk-upsert → 10/min
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.provisions import (
    ProvisionsBulkUpsertRequest,
    ProvisionsResponse,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import provisions_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{doc_id}", tags=["compta_esms:provisions"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router.post("/provisions:bulk-upsert", response_model=ProvisionsResponse)
@limiter.limit("10/minute")
async def bulk_upsert_provisions(
    request: Request,
    doc_id: UUID,
    payload: ProvisionsBulkUpsertRequest,
    auth: tuple = Depends(require_builder),
) -> ProvisionsResponse:
    """L2 §16.2 — replace_all_by_document (Q3). 4 catégories D-099,
    ``montant_fin_n`` calculée par PG."""
    company_id = _require_company(auth)
    try:
        return await provisions_service.bulk_upsert_provisions(doc_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/provisions", response_model=ProvisionsResponse)
@limiter.limit("100/minute")
async def get_provisions(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> ProvisionsResponse:
    """L2 §16.1 — items + totals by_categorie (Q6 — totals inclus
    dans GET, pas d'endpoint :totals séparé)."""
    company_id = _require_company(auth)
    try:
        return await provisions_service.list_provisions(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
