"""HTTP routes for bilan (L2 §14, 4 endpoints).

Un router unique sous ``/documents/{doc_id}/bilan*``. 4 endpoints :

* §14.1 GET ``/bilan?type_bilan=`` (user) — items + plan_comptable OG
* §14.2 POST ``/bilan:bulk-upsert`` (builder) — replace by type_bilan
* §14.3 GET ``/bilan:totals?type_bilan=`` (user) — par section + totaux
* §14.4 POST ``/bilan:validate?type_bilan=`` (user) — C-56/C-57

Permissions L2 strict. Action suffixes ``:bulk-upsert`` / ``:totals`` /
``:validate`` déclarés au même niveau que le path root — l'ordre des
décorateurs n'a pas d'incidence ici car les paths sont littéraux.
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.bilan import (
    BilanBulkUpsertRequest,
    BilanResponse,
    BilanTotalsResponse,
    BilanValidationResult,
    TypeBilan,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import bilan_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{doc_id}", tags=["compta_esms:bilan"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


# ---------------------------------------------------------------------------
# §14.2 :bulk-upsert + §14.3 :totals + §14.4 :validate — action suffixes
# (declared before /bilan root for clarity)
# ---------------------------------------------------------------------------


@router.post("/bilan:bulk-upsert", response_model=BilanResponse)
@limiter.limit("10/minute")
async def bulk_upsert_bilan(
    request: Request,
    doc_id: UUID,
    payload: BilanBulkUpsertRequest,
    auth: tuple = Depends(require_builder),
) -> BilanResponse:
    """L2 §14.2 — replace by type_bilan. Variante comptable PC/PNL
    auto-déduite via og.plan_comptable (Q1, D-067).

    Rejette ``incoherent_comptable_variant`` si le payload mélange
    le mauvais type comptable (ex: pnl alors que og=PC)."""
    company_id = _require_company(auth)
    try:
        return await bilan_service.bulk_upsert_bilan(doc_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/bilan:totals", response_model=BilanTotalsResponse)
@limiter.limit("100/minute")
async def get_totals(
    request: Request,
    doc_id: UUID,
    type_bilan: TypeBilan | None = None,
    auth: tuple = Depends(require_user),
) -> BilanTotalsResponse:
    """L2 §14.3 — totaux par section + total_biens / total_financements
    + écart. Si ``type_bilan`` fourni → seul ce type est rempli. Sinon
    retourne tous les types présents (None pour les absents)."""
    company_id = _require_company(auth)
    try:
        return await bilan_service.compute_totals(doc_id, company_id, type_bilan=type_bilan)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.post("/bilan:validate", response_model=BilanValidationResult)
@limiter.limit("30/minute")
async def validate_bilan(
    request: Request,
    doc_id: UUID,
    type_bilan: TypeBilan | None = None,
    auth: tuple = Depends(require_user),
) -> BilanValidationResult:
    """L2 §14.4 — C-56/C-57 (TOTAL BIENS = TOTAL FINANCEMENTS,
    tolérance 0,01€). Si ``type_bilan`` fourni → valide seulement ce
    type. Sinon valide tous les types présents."""
    company_id = _require_company(auth)
    try:
        return await bilan_service.validate_equilibre(doc_id, company_id, type_bilan=type_bilan)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §14.1 — GET /bilan
# ---------------------------------------------------------------------------


@router.get("/bilan", response_model=BilanResponse)
@limiter.limit("100/minute")
async def get_bilan(
    request: Request,
    doc_id: UUID,
    type_bilan: TypeBilan | None = None,
    auth: tuple = Depends(require_user),
) -> BilanResponse:
    """L2 §14.1 — items du bilan + plan_comptable de l'OG (utile pour
    l'UI : afficher l'onglet PC ou PNL approprié)."""
    company_id = _require_company(auth)
    try:
        return await bilan_service.list_bilan(doc_id, company_id, type_bilan=type_bilan)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
