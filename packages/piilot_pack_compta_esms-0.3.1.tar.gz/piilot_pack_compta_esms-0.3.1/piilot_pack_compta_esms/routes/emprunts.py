"""HTTP routes for Emprunts (L2 §16.3-§16.4, 2 endpoints).

Permissions L2 standard (Q10) :
* §16.3 GET → user
* §16.4 POST :bulk-upsert → builder

Rate limits L2 §304-308 (Q11) :
* GET → 100/min
* :bulk-upsert → 10/min

Sémantique Q4 : ``replace_by_document_and_type_dette`` (précédent §K
Bilan, pas §M replace_all). Le payload du POST porte ``type_dette``
au top-level.
"""

from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.emprunts import (
    EmpruntsBulkUpsertRequest,
    EmpruntsResponse,
    TypeDette,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import emprunts_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{doc_id}", tags=["compta_esms:emprunts"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router.post("/emprunts:bulk-upsert", response_model=EmpruntsResponse)
@limiter.limit("10/minute")
async def bulk_upsert_emprunts(
    request: Request,
    doc_id: UUID,
    payload: EmpruntsBulkUpsertRequest,
    auth: tuple = Depends(require_builder),
) -> EmpruntsResponse:
    """L2 §16.4 — replace_by_document_and_type_dette (Q4). Le save ne
    touche QUE le type_dette du payload — les 8 autres onglets sont
    préservés."""
    company_id = _require_company(auth)
    try:
        return await emprunts_service.bulk_upsert_emprunts(doc_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/emprunts", response_model=EmpruntsResponse)
@limiter.limit("100/minute")
async def get_emprunts(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
    type_dette: Annotated[TypeDette | None, Query()] = None,
) -> EmpruntsResponse:
    """L2 §16.3 — items + totals by_type_dette.

    ``?type_dette=`` (optionnel) filtre les items + restreint les
    totals au seul type demandé. Omis → tous les emprunts du document,
    breakdown sur les 9 types."""
    company_id = _require_company(auth)
    try:
        return await emprunts_service.list_emprunts(doc_id, company_id, type_dette=type_dette)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
