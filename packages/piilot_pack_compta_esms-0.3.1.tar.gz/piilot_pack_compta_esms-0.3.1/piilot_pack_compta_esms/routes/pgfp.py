"""HTTP routes for PGFP (L2 §9, 3 endpoints).

Permissions L2 standard (Q10) :
* §9.1 GET → user
* §9.2 PATCH → builder
* §9.3 POST :recompute → builder

Rate limits L2 §304-308 (Q11) :
* GET → 100/min
* PATCH → 30/min (mutations standard)
* :recompute → **5/min** (PGFP cité nommément L2 §308 — "Recompute
  (PGFP, ratios, controles) : 5 req/min/user")
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.pgfp import (
    PgfpPatchRequest,
    PgfpRecomputeResponse,
    PgfpResponse,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import pgfp_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{doc_id}", tags=["compta_esms:pgfp"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


# ---------------------------------------------------------------------------
# §9.3 POST :recompute — déclaré AVANT GET /pgfp pour matcher l'action
#                         suffix avant le path root
# ---------------------------------------------------------------------------


@router.post("/pgfp:recompute", response_model=PgfpRecomputeResponse)
@limiter.limit("5/minute")
async def recompute_pgfp(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_builder),
) -> PgfpRecomputeResponse:
    """L2 §9.3 — Recalcule auto FRI/FRE/FRNG/BFR/Trésorerie (Q6).

    MVP v0.2 : calcule blocs 2+3+4+5+6+7 à partir des saisies présentes
    en DB. Blocs 8 (contrôles vs Bilan) et 10 (ratios) restent à NULL
    — intégration profonde §H/§J/§K/§N différée.

    Q11 rate-limit explicite L2 §308 : 5/min/user."""
    company_id = _require_company(auth)
    try:
        return await pgfp_service.recompute_pgfp(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §9.2 PATCH /pgfp
# ---------------------------------------------------------------------------


@router.patch("/pgfp", response_model=PgfpResponse)
@limiter.limit("30/minute")
async def patch_pgfp(
    request: Request,
    doc_id: UUID,
    payload: PgfpPatchRequest,
    auth: tuple = Depends(require_builder),
) -> PgfpResponse:
    """L2 §9.2 — Upsert partiel par ligne_key (Q4). Ne touche QUE les
    lignes du payload. Refuse 422 les ligne_key inconnus du template
    ou is_computed=True."""
    company_id = _require_company(auth)
    try:
        return await pgfp_service.patch_pgfp(doc_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §9.1 GET /pgfp
# ---------------------------------------------------------------------------


@router.get("/pgfp", response_model=PgfpResponse)
@limiter.limit("100/minute")
async def get_pgfp(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> PgfpResponse:
    """L2 §9.1 — PGFP complet 148 lignes × 8 exercices. Retourne le
    template merge DB sparse (Q3 option c — lignes à null si pas en DB).

    Q8 guard EPRD-only — refuse 422 si type_document ∉ {eprd, dm, ria}."""
    company_id = _require_company(auth)
    try:
        return await pgfp_service.list_pgfp(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
