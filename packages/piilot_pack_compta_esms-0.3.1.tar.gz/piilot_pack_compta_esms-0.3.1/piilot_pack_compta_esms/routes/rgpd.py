"""HTTP routes pour le recueil consentement RGPD (§T, L2 §20).

Mount sous ``/plugins/compta_esms/exercices/{exercice_id}``.

2 endpoints :

* GET ``/recueil-consentement`` (require_user, 100/min)
* PUT ``/recueil-consentement`` (require_builder, 30/min)

Permissions L2 §20 strict — la mutation est builder (paramètre RGPD
sensible, traçabilité audit). GET reste user (lecture exemptée pour
les contributeurs du cabinet).
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.rgpd import (
    RecueilConsentementRead,
    RecueilConsentementUpdate,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import rgpd_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/exercices/{exercice_id}", tags=["compta_esms:rgpd"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


def _require_user_id(auth: tuple) -> UUID:
    user_id = auth[0]
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_user_context",
                "message": "Auth user_id missing",
            },
        )
    return UUID(str(user_id))


@router.get("/recueil-consentement", response_model=RecueilConsentementRead)
@limiter.limit("100/minute")
async def get_recueil_consentement_route(
    request: Request,
    exercice_id: UUID,
    auth: tuple = Depends(require_user),
) -> RecueilConsentementRead:
    """L2 §20.1 — état du recueil de consentement pour cet exercice.

    Retourne 404 ``consentement_not_found`` si jamais posé (le
    frontend affiche alors le formulaire vide). Retourne 404
    ``exercice_not_found`` si l'exercice n'existe pas pour cette
    company.
    """
    company_id = _require_company(auth)
    try:
        return await rgpd_service.get_consentement(exercice_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.put("/recueil-consentement", response_model=RecueilConsentementRead)
@limiter.limit("30/minute")
async def put_recueil_consentement_route(
    request: Request,
    exercice_id: UUID,
    payload: RecueilConsentementUpdate,
    auth: tuple = Depends(require_builder),
) -> RecueilConsentementRead:
    """L2 §20.2 — sauvegarde le recueil (UPSERT idempotent).

    Le service gère le toggle automatique ``consenti_at`` /
    ``revoque_at`` selon la transition cnsa et pose un audit_event
    ``rgpd.consent`` payload anonymisé léger.
    """
    company_id = _require_company(auth)
    user_id = _require_user_id(auth)
    try:
        return await rgpd_service.put_consentement(
            exercice_id=exercice_id,
            company_id=company_id,
            user_id=user_id,
            payload=payload,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
