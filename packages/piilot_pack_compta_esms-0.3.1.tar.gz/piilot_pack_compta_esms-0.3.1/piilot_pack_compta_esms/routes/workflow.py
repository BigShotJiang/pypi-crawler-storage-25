"""HTTP routes for workflow transitions (§S, L2 §4.6 + §4.7).

2 endpoints sous ``/documents/{doc_id}`` :

* §4.6 POST ``/transitions`` — applique une action ``transmit``,
  ``approve``, ``reject`` ou ``set_affectation``. **Le Depends auth
  est ``require_user``** : la machine d'état + le service décident
  qui peut faire quoi selon l'action (cf.
  :func:`workflow_state_machine.can_apply`). Un appel avec un rôle
  insuffisant → 403 ``role_required``.
* §4.7 GET ``/transitions-allowed`` — liste filtrée par rôle des
  actions applicables + actions bloquées avec raison machine.

Rate limits L2 §307 standard : POST 30/min, GET 100/min.
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_user

from piilot_pack_compta_esms.models.workflow import (
    TransitionRequest,
    TransitionResponse,
    TransitionsAllowedResponse,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import workflow_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{doc_id}", tags=["compta_esms:workflow"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


def _require_user_id(auth: tuple) -> UUID:
    """Le user_id figure en auth[0]. ``require_user`` garantit qu'il
    est non-None ; on remonte 400 quand même en defensive (changements
    de SDK)."""
    user_id = auth[0]
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_user_context",
                "message": "Auth user_id missing",
            },
        )
    return UUID(str(user_id))


@router.post("/transitions", response_model=TransitionResponse)
@limiter.limit("30/minute")
async def apply_transition_route(
    request: Request,
    doc_id: UUID,
    payload: TransitionRequest,
    auth: tuple = Depends(require_user),
) -> TransitionResponse:
    """L2 §4.6 — applique une action workflow.

    Le rôle requis varie par action :

    * ``transmit`` → builder/admin
    * ``set_affectation`` / ``approve`` / ``reject`` → admin

    Le service raise :class:`CrossCompanyError` (HTTP 403) avec code
    ``role_required`` quand le rôle de l'appelant est insuffisant ;
    :class:`ConflictError` (HTTP 409) quand la machine d'état refuse.
    """
    company_id = _require_company(auth)
    user_id = _require_user_id(auth)
    role = auth[1] if len(auth) > 1 else "user"
    try:
        return await workflow_service.apply_transition(
            document_id=doc_id,
            payload=payload,
            company_id=company_id,
            user_id=user_id,
            role=role,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/transitions-allowed", response_model=TransitionsAllowedResponse)
@limiter.limit("100/minute")
async def get_transitions_allowed_route(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> TransitionsAllowedResponse:
    """L2 §4.7 — liste actions applicables + bloquées."""
    company_id = _require_company(auth)
    role = auth[1] if len(auth) > 1 else "user"
    try:
        return await workflow_service.get_transitions_allowed(
            document_id=doc_id,
            company_id=company_id,
            role=role,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
