"""HTTP routes pour §V DM — Décision Modificative.

Endpoint dédié à la validation du bouleversement de l'économie
générale (R.314-229 — D-064 v0.2 squelette soft, enforce v0.5).

Le clone DM est exposé via §4.8 ``POST /documents/{id}/clone`` (livré
§E.3, enrichi §V pour héritage CRs + audit) — pas d'endpoint clone
spécifique DM ici.

Les guards périmètre DM (D-063) vivent transparents dans
:mod:`cr_service` (create + update + delete CR refusés si breach).
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_user

from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import dm_service
from piilot_pack_compta_esms.services.dm_service import EconomyBouleverseResult
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{dm_id}", tags=["compta_esms:dm"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router.post(
    "/economy-bouleversee:validate",
    response_model=EconomyBouleverseResult,
)
@limiter.limit("30/minute")
async def validate_economy_bouleversee_route(
    request: Request,
    dm_id: UUID,
    auth: tuple = Depends(require_user),
) -> EconomyBouleverseResult:
    """§V D-064 — évalue les 2 conditions R.314-229 (bouleversement
    de l'économie générale du budget pour ce DM).

    **v0.2 soft non-bloquant** : ``is_soft_verdict=True``, le verdict
    informe le cabinet / agent IA mais ne bloque pas la transition
    `BROUILLON → TRANSMIS` du DM. En v0.2, les inputs réels (CAF
    projection §I + capital emprunts §N + prélèvement FR §K) ne sont
    pas câblés — les 2 conditions retournent ``evaluable=False``.

    Le wiring complet ship en v0.5 quand le câblage 5 conditions
    R.314-222 §S guard équilibre EPRD aura ouvert le pattern.

    Refuse 409 ``not_a_dm`` si le document n'est pas de type DM.
    Refuse 404 ``document_not_found`` si le document n'existe pas
    pour cette company.
    """
    company_id = _require_company(auth)
    try:
        return await dm_service.validate_economy_bouleversee(dm_id=dm_id, company_id=company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
