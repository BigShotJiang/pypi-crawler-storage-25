"""HTTP routes for Organisme Gestionnaire CRUD.

Mounts under ``/plugins/compta_esms/orgs``. Endpoints follow the L2
spec (§1.x): list, create, get, patch, delete.

Permissions :
* ``GET`` → :func:`piilot.sdk.http.require_user`
* ``POST`` / ``PATCH`` / ``DELETE`` → :func:`piilot.sdk.http.require_admin`
  (cf. L2 §1.x — settings on OG include FINESS and CPOM, admin-only).

Rate limits :
* ``GET`` → 100/min
* mutations → 30/min

(cf. L2 §"Rate limiting").
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_admin, require_user

from piilot_pack_compta_esms.models.og import OGCreate, OGRead, OGUpdate
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import og_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/orgs", tags=["compta_esms:orgs"])


def _require_company(auth: tuple) -> UUID:
    """Extract the company UUID from the auth tuple ``(user_id, role, company_id)``.

    Raises 400 if ``company_id`` is missing (the user hasn't picked a
    company context yet) — this would only happen if the host fails to
    set the ``X-Company-Id`` header.
    """
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router.get("", response_model=list[OGRead])
@limiter.limit("100/minute")
async def list_orgs(
    request: Request,
    auth: tuple = Depends(require_user),
) -> list[OGRead]:
    """L2 §1.1 — list OGs accessible to the caller."""
    company_id = _require_company(auth)
    return await og_service.list_orgs(company_id)


@router.post("", response_model=OGRead, status_code=status.HTTP_201_CREATED)
@limiter.limit("30/minute")
async def create_org(
    request: Request,
    payload: OGCreate,
    auth: tuple = Depends(require_admin),
) -> OGRead:
    """L2 §1.2 — create OG (admin only)."""
    company_id = _require_company(auth)
    try:
        return await og_service.create_org(company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/{og_id}", response_model=OGRead)
@limiter.limit("100/minute")
async def get_org(
    request: Request,
    og_id: UUID,
    auth: tuple = Depends(require_user),
) -> OGRead:
    """L2 §1.3 — fetch a single OG."""
    _require_company(auth)
    try:
        return await og_service.get_org(og_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.patch("/{og_id}", response_model=OGRead)
@limiter.limit("30/minute")
async def update_org(
    request: Request,
    og_id: UUID,
    payload: OGUpdate,
    auth: tuple = Depends(require_admin),
) -> OGRead:
    """L2 §1.4 — patch OG (admin only)."""
    company_id = _require_company(auth)
    try:
        return await og_service.update_org(company_id, og_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.delete("/{og_id}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_org(
    request: Request,
    og_id: UUID,
    auth: tuple = Depends(require_admin),
) -> None:
    """L2 §1.5 — hard-delete OG (admin only).

    Returns 204. Raises 409 if any établissement or exercice still
    references the OG (cf. :func:`og_service.delete_org`).
    """
    _require_company(auth)
    try:
        await og_service.delete_org(og_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
