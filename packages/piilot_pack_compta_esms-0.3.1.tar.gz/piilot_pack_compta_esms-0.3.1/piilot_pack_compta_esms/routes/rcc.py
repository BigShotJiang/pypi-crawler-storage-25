"""HTTP routes for RCC — Répartition Charges Communes (L2 §16.5-§16.7,
3 endpoints).

Permissions L2 standard (Q10) :
* §16.5 GET → user
* §16.6 POST :bulk-upsert → builder
* §16.7 POST :validate → user

Rate limits L2 §304-308 (Q11) :
* GET → 100/min
* :bulk-upsert → 10/min
* :validate → 30/min (POST sans bulk)
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.rcc import (
    RccBulkUpsertRequest,
    RccResponse,
    RccValidateResponse,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import rcc_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{doc_id}", tags=["compta_esms:rcc"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router.post("/rcc:bulk-upsert", response_model=RccResponse)
@limiter.limit("10/minute")
async def bulk_upsert_rcc(
    request: Request,
    doc_id: UUID,
    payload: RccBulkUpsertRequest,
    auth: tuple = Depends(require_builder),
) -> RccResponse:
    """L2 §16.6 — replace_all_by_document (Q5)."""
    company_id = _require_company(auth)
    try:
        return await rcc_service.bulk_upsert_rcc(doc_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.post("/rcc:validate", response_model=RccValidateResponse)
@limiter.limit("30/minute")
async def validate_rcc(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> RccValidateResponse:
    """L2 §16.7 — D-092 : Σ(% par CR) = 100% sur chaque ligne,
    tolérance 0.01 (Q7). Retourne le rapport ligne par ligne avec
    les écarts détaillés."""
    company_id = _require_company(auth)
    try:
        return await rcc_service.validate_rcc(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/rcc", response_model=RccResponse)
@limiter.limit("100/minute")
async def get_rcc(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> RccResponse:
    """L2 §16.5 — Items RCC. Pas de ``totals`` dans la réponse (Q6) —
    la "synthèse" est :validate (Σ% par ligne, pas un total global)."""
    company_id = _require_company(auth)
    try:
        return await rcc_service.list_rcc(doc_id, company_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
