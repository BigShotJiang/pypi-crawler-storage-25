"""HTTP routes pour §Y clés de répartition charges communes (D-057).

Deux routers :

* :data:`router_under_ets` à ``/etablissements/{ets_id}/cles-repartition``
  pour list / create / bulk-upsert (scoped établissement).
* :data:`router_flat` à ``/cles-repartition/{key_id}`` pour patch /
  delete (by-id, no parent in path).

Permissions L2 §307-§310 :

* GET → user (100/min)
* POST/PUT → builder (30/min)
* POST :bulk-upsert → builder (10/min — saisie tabulaire)
* DELETE → admin (30/min)
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from piilot.sdk.http import require_admin, require_builder, require_user

from piilot_pack_compta_esms.models.cles_repartition import (
    ClesRepartitionBulkUpsertRequest,
    ClesRepartitionCreate,
    ClesRepartitionRead,
    ClesRepartitionUpdate,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import cles_repartition_service
from piilot_pack_compta_esms.services.errors import DomainError

router_under_ets = APIRouter(
    prefix="/etablissements/{etablissement_id}/cles-repartition",
    tags=["compta_esms:cles_repartition"],
)
router_flat = APIRouter(prefix="/cles-repartition", tags=["compta_esms:cles_repartition"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router_under_ets.get("", response_model=list[ClesRepartitionRead])
@limiter.limit("100/minute")
async def list_cles_repartition_route(
    request: Request,
    etablissement_id: UUID,
    compte_m22bis: str | None = Query(default=None),
    exercice_annee: int | None = Query(default=None, ge=2020, le=2050),
    auth: tuple = Depends(require_user),
) -> list[ClesRepartitionRead]:
    """§Y — liste les clés d'un établissement, filtrable par compte/année."""
    company_id = _require_company(auth)
    try:
        return await cles_repartition_service.list_cles_repartition(
            etablissement_id,
            company_id,
            compte_m22bis=compte_m22bis,
            exercice_annee=exercice_annee,
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_under_ets.post("", response_model=ClesRepartitionRead, status_code=status.HTTP_201_CREATED)
@limiter.limit("30/minute")
async def create_cle_route(
    request: Request,
    etablissement_id: UUID,
    payload: ClesRepartitionCreate,
    auth: tuple = Depends(require_builder),
) -> ClesRepartitionRead:
    """§Y — créer une nouvelle clé (Σ taux = 100 ± 0.01 validé Pydantic)."""
    company_id = _require_company(auth)
    try:
        return await cles_repartition_service.create_cle(company_id, etablissement_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_under_ets.post(":bulk-upsert", response_model=list[ClesRepartitionRead])
@limiter.limit("10/minute")
async def bulk_upsert_cles_route(
    request: Request,
    etablissement_id: UUID,
    payload: ClesRepartitionBulkUpsertRequest,
    auth: tuple = Depends(require_builder),
) -> list[ClesRepartitionRead]:
    """§Y — saisie tabulaire massive (max 200 par batch)."""
    company_id = _require_company(auth)
    try:
        return await cles_repartition_service.bulk_upsert_cles(
            company_id, etablissement_id, payload
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.put("/{key_id}", response_model=ClesRepartitionRead)
@limiter.limit("30/minute")
async def update_cle_route(
    request: Request,
    key_id: UUID,
    payload: ClesRepartitionUpdate,
    auth: tuple = Depends(require_builder),
) -> ClesRepartitionRead:
    """§Y — patch source/notes ou les 4 taux ensemble."""
    company_id = _require_company(auth)
    try:
        return await cles_repartition_service.update_cle(company_id, key_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.delete("/{key_id}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_cle_route(
    request: Request,
    key_id: UUID,
    auth: tuple = Depends(require_admin),
) -> None:
    """§Y — supprime une clé (admin uniquement)."""
    company_id = _require_company(auth)
    try:
        await cles_repartition_service.delete_cle(company_id, key_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
