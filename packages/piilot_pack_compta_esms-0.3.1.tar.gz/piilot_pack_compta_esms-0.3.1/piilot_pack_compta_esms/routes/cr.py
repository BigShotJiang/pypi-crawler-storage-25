"""HTTP routes for Comptes de Résultat (L2 §5, 5 endpoints).

Two routers mounted under different prefixes :

* :data:`router_under_doc` at ``/plugins/compta_esms/documents/{doc_id}/crs``
  for list + create (scoped to a parent document).
* :data:`router_flat` at ``/plugins/compta_esms/crs/{cr_id}``
  for patch, delete, reorder (by-id).

Permissions per L2 :
* GET → ``require_user``
* POST / PATCH / DELETE / reorder → ``require_builder``
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.cr import (
    CrCreate,
    CrRead,
    CrReorder,
    CrUpdate,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import cr_service
from piilot_pack_compta_esms.services.errors import DomainError

router_under_doc = APIRouter(prefix="/documents/{doc_id}/crs", tags=["compta_esms:crs"])
router_flat = APIRouter(prefix="/crs", tags=["compta_esms:crs"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router_under_doc.get("", response_model=list[CrRead])
@limiter.limit("100/minute")
async def list_crs(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> list[CrRead]:
    """L2 §5.1 — list CRs of a document, ordered by (ordre, created_at)."""
    _require_company(auth)
    return await cr_service.list_crs(doc_id)


@router_under_doc.post("", response_model=CrRead, status_code=status.HTTP_201_CREATED)
@limiter.limit("30/minute")
async def create_cr(
    request: Request,
    doc_id: UUID,
    payload: CrCreate,
    auth: tuple = Depends(require_builder),
) -> CrRead:
    """L2 §5.2 — create an explicit CR (CRPA / CRP_SF / CRA_SF / extra CRPP).

    The default CRPP is auto-created with the document (§E.3, D-073).
    Use this endpoint when the cabinet needs additional CRs.
    """
    company_id = _require_company(auth)
    try:
        return await cr_service.create_cr(company_id, doc_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.patch("/{cr_id}", response_model=CrRead)
@limiter.limit("30/minute")
async def update_cr(
    request: Request,
    cr_id: UUID,
    payload: CrUpdate,
    auth: tuple = Depends(require_builder),
) -> CrRead:
    """L2 §5.3 — patch a CR (rename, reattach, switch ventilation…).

    ``cr_type`` is locked at create time — try to mutate it via
    ``extra='forbid'`` and you get a 422.
    """
    company_id = _require_company(auth)
    try:
        return await cr_service.update_cr(company_id, cr_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.delete("/{cr_id}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_cr(
    request: Request,
    cr_id: UUID,
    auth: tuple = Depends(require_builder),
) -> None:
    """L2 §5.4 — hard delete a CR + cascades its ``crp_lignes``."""
    company_id = _require_company(auth)
    try:
        await cr_service.delete_cr(company_id, cr_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router_flat.post("/{cr_id}/reorder", response_model=CrRead)
@limiter.limit("30/minute")
async def reorder_cr(
    request: Request,
    cr_id: UUID,
    payload: CrReorder,
    auth: tuple = Depends(require_builder),
) -> CrRead:
    """L2 §5.5 — set the CR's ``ordre`` value.

    The endpoint is idempotent — sending the same ``ordre`` twice is
    a no-op rather than an error, which keeps drag-and-drop UIs from
    breaking on eager POST sequences.
    """
    company_id = _require_company(auth)
    try:
        return await cr_service.reorder_cr(company_id, cr_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
