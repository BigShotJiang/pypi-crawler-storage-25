"""HTTP routes for the balance_mappings dictionary (L2 §7bis.3 — 8 endpoints).

* §7bis.3.1 ``GET /balance-mappings``
* §7bis.3.2 ``POST /balance-mappings``
* §7bis.3.3 ``POST /balance-mappings:bulk-upsert``
* §7bis.3.4 ``PATCH /balance-mappings/{id}``
* §7bis.3.5 ``DELETE /balance-mappings/{id}``
* §7bis.3.6 ``POST /balance-mappings:validate``
* §7bis.3.7 ``POST /balance-mappings:export-csv`` (returns text/csv)
* §7bis.3.8 ``POST /balance-mappings:import-csv`` (multipart/form-data, admin)

Permissions follow L2 :
* ``GET`` / ``validate`` / ``export-csv`` → ``require_user``
* ``POST`` / ``PATCH`` / ``DELETE`` / ``bulk-upsert`` → ``require_builder``
* ``import-csv`` → ``require_admin`` (touches every mapping)

Rate limits follow the L2 defaults (100/min reads, 30/min mutations,
10/min bulk endpoints — cf. L2 §304-310).
"""

from __future__ import annotations

import csv
import io
from typing import Any
from uuid import UUID

from fastapi import (
    APIRouter,
    Depends,
    File,
    HTTPException,
    Request,
    Response,
    UploadFile,
    status,
)
from piilot.sdk.http import require_admin, require_builder, require_user

from piilot_pack_compta_esms.models.balance_mapping import (
    BalanceMappingBulkItem,
    BalanceMappingCreate,
    BalanceMappingRead,
    BalanceMappingUpdate,
    BalanceMappingValidationIssue,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import balance_mapping_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/balance-mappings", tags=["compta_esms:balance-mappings"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


# ---------------------------------------------------------------------------
# CRUD (§7bis.3.1, .2, .4, .5)
# ---------------------------------------------------------------------------


@router.get("", response_model=list[BalanceMappingRead])
@limiter.limit("100/minute")
async def list_mappings(
    request: Request,
    source_plan: str | None = None,
    source_account: str | None = None,
    version_m22bis: str | None = None,
    limit: int = 200,
    auth: tuple = Depends(require_user),
) -> list[BalanceMappingRead]:
    """L2 §7bis.3.1 — list mappings with optional filters."""
    company_id = _require_company(auth)
    return await balance_mapping_service.list_mappings(
        company_id,
        source_plan=source_plan,
        source_account=source_account,
        version_m22bis=version_m22bis,
        limit=limit,
    )


@router.post("", response_model=BalanceMappingRead, status_code=status.HTTP_201_CREATED)
@limiter.limit("30/minute")
async def create_mapping(
    request: Request,
    payload: BalanceMappingCreate,
    auth: tuple = Depends(require_builder),
) -> BalanceMappingRead:
    """L2 §7bis.3.2 — create a single mapping row."""
    company_id = _require_company(auth)
    try:
        return await balance_mapping_service.create_mapping(company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.patch("/{mapping_id}", response_model=BalanceMappingRead)
@limiter.limit("30/minute")
async def update_mapping(
    request: Request,
    mapping_id: UUID,
    payload: BalanceMappingUpdate,
    auth: tuple = Depends(require_builder),
) -> BalanceMappingRead:
    """L2 §7bis.3.4 — patch mutable fields. The 5-tuple UNIQUE key is
    immutable — change a target = delete + create instead."""
    company_id = _require_company(auth)
    try:
        return await balance_mapping_service.update_mapping(company_id, mapping_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.delete("/{mapping_id}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_mapping(
    request: Request,
    mapping_id: UUID,
    auth: tuple = Depends(require_builder),
) -> None:
    """L2 §7bis.3.5 — hard delete one mapping row."""
    company_id = _require_company(auth)
    try:
        await balance_mapping_service.delete_mapping(company_id, mapping_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# Actions (§7bis.3.3 + .6 + .7 + .8) — FastAPI accepts ``:action`` in paths
# ---------------------------------------------------------------------------


@router.post(":bulk-upsert", response_model=list[BalanceMappingRead])
@limiter.limit("10/minute")
async def bulk_upsert_mappings(
    request: Request,
    items: list[BalanceMappingBulkItem],
    auth: tuple = Depends(require_builder),
) -> list[BalanceMappingRead]:
    """L2 §7bis.3.3 — atomic upsert of N mapping rows.

    Used by the assistant ``accept-all-above`` flow and by the CSV
    import path. If the DB trigger rejects any row (Σ weight > 1.0),
    the whole batch rolls back."""
    company_id = _require_company(auth)
    try:
        return await balance_mapping_service.bulk_upsert_mappings(company_id, items)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.post(":validate", response_model=list[BalanceMappingValidationIssue])
@limiter.limit("30/minute")
async def validate_mappings(
    request: Request,
    auth: tuple = Depends(require_user),
) -> list[BalanceMappingValidationIssue]:
    """L2 §7bis.3.6 — surface every source key whose Σ weight ≠ 1.0.

    Empty list = the dictionary is consistent and can be applied to a
    balance import."""
    company_id = _require_company(auth)
    return await balance_mapping_service.validate_weights(company_id)


@router.post(":export-csv")
@limiter.limit("10/minute")
async def export_csv(
    request: Request,
    auth: tuple = Depends(require_user),
) -> Response:
    """L2 §7bis.3.7 — export the entire dictionary as ``text/csv``.

    Use case : cabinet réutilise un mapping client A pour onboarder
    client B (same chart of accounts), or audits a year-over-year
    delta. Header :data:`balance_mapping_service.CSV_HEADER` matches
    the import endpoint, so a round-trip is lossless."""
    company_id = _require_company(auth)
    rows = await balance_mapping_service.list_for_export(company_id)
    buf = io.StringIO()
    writer = csv.DictWriter(
        buf, fieldnames=balance_mapping_service.CSV_HEADER, extrasaction="ignore"
    )
    writer.writeheader()
    for row in rows:
        # csv.DictWriter happily writes None — psycopg2 returns ``None``
        # for SQL NULL, which becomes the empty string in CSV.
        writer.writerow({k: row.get(k) for k in balance_mapping_service.CSV_HEADER})
    return Response(
        content=buf.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=balance_mappings.csv"},
    )


@router.post(":import-csv", response_model=list[BalanceMappingRead])
@limiter.limit("10/minute")
async def import_csv(
    request: Request,
    file: UploadFile = File(...),  # noqa: B008 — FastAPI File() idiom
    auth: tuple = Depends(require_admin),
) -> list[BalanceMappingRead]:
    """L2 §7bis.3.8 — bulk-import from a CSV produced by ``:export-csv``.

    Admin-only — overwriting another cabinet's dict by accident is a
    real risk. We parse each row through :class:`BalanceMappingBulkItem`
    so bad CSVs surface as 422 before the bulk_upsert touches the DB.
    """
    company_id = _require_company(auth)

    raw = await file.read()
    try:
        text = raw.decode("utf-8-sig")  # tolerates BOM from Excel exports
    except UnicodeDecodeError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "csv_decode_error",
                "message": f"CSV must be UTF-8: {exc}",
            },
        ) from exc

    reader = csv.DictReader(io.StringIO(text))
    items: list[BalanceMappingBulkItem] = []
    for line_no, row in enumerate(reader, start=2):  # line 1 = header
        # Drop the empty-string projections csv.DictReader emits for
        # NULL-in-CSV — Pydantic happily accepts the absence of the key
        # and applies the field's default (or None for Optional fields).
        cleaned: dict[str, Any] = {k: v for k, v in row.items() if v not in (None, "")}
        # Coerce numerics — DictReader gives us strings.
        if "weight" in cleaned:
            try:
                cleaned["weight"] = float(cleaned["weight"])
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail={
                        "code": "csv_bad_weight",
                        "message": f"line {line_no}: bad weight {cleaned['weight']!r}",
                    },
                ) from exc
        if "confidence" in cleaned:
            try:
                cleaned["confidence"] = float(cleaned["confidence"])
            except ValueError as exc:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail={
                        "code": "csv_bad_confidence",
                        "message": f"line {line_no}: bad confidence " f"{cleaned['confidence']!r}",
                    },
                ) from exc
        try:
            items.append(BalanceMappingBulkItem.model_validate(cleaned))
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail={
                    "code": "csv_row_invalid",
                    "message": f"line {line_no}: {exc}",
                },
            ) from exc

    try:
        return await balance_mapping_service.import_csv_rows(company_id, items)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
