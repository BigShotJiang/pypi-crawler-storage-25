"""HTTP routes for Annexe 4 Activité GIR (L2 §12, 3 endpoints).

Permissions L2 strict (Q12) : **user partout**.

Rate limits L2 §304-310 (Q13) :

* GET → 100/min (lecture standard)
* :bulk-upsert → **10/min** (bulk endpoint L2 §308)
* :compute-theorique → 30/min (POST non-bulk standard L2 §307 —
  PAS dans la liste recompute 5/min L2 §310 qui ne cite que PGFP +
  ratios + controles).
"""

from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from piilot.sdk.http import require_user

from piilot_pack_compta_esms.models.activite import (
    ActiviteBulkUpsertRequest,
    ActiviteComputeTheoriqueRequest,
    ActiviteComputeTheoriqueResponse,
    ActiviteResponse,
    AnnexeVariante,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import activite_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents/{doc_id}", tags=["compta_esms:activite"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


# ---------------------------------------------------------------------------
# Action suffixes (:bulk-upsert, :compute-theorique) — déclarés AVANT
# GET /activite root pour matching FastAPI
# ---------------------------------------------------------------------------


@router.post("/activite:bulk-upsert", response_model=ActiviteResponse)
@limiter.limit("10/minute")
async def bulk_upsert_activite(
    request: Request,
    doc_id: UUID,
    payload: ActiviteBulkUpsertRequest,
    auth: tuple = Depends(require_user),
) -> ActiviteResponse:
    """L2 §12.2 — replace_by_(doc, ets, annexe_variante) (Q1).
    Permissions user (L2 strict)."""
    company_id = _require_company(auth)
    try:
        return await activite_service.bulk_upsert_activite(doc_id, company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.post(
    "/activite:compute-theorique",
    response_model=ActiviteComputeTheoriqueResponse,
)
@limiter.limit("30/minute")
async def compute_theorique_activite(
    request: Request,
    doc_id: UUID,
    payload: ActiviteComputeTheoriqueRequest,
    auth: tuple = Depends(require_user),
) -> ActiviteComputeTheoriqueResponse:
    """L2 §12.3 — D-051 calcule activité théorique = capacite_financee
    × amplitude_ouverture. Idempotent (Q4)."""
    company_id = _require_company(auth)
    try:
        return await activite_service.compute_theorique(
            doc_id, company_id, payload.ets_id, payload.annexe_variante
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


# ---------------------------------------------------------------------------
# §12.1 — GET /activite
# ---------------------------------------------------------------------------


@router.get("/activite", response_model=ActiviteResponse)
@limiter.limit("100/minute")
async def get_activite(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
    ets_id: Annotated[UUID | None, Query()] = None,
    annexe: Annotated[AnnexeVariante | None, Query()] = None,
) -> ActiviteResponse:
    """L2 §12.1 — Items activité. Filtres optionnels ``?ets_id=...&annexe=4A_ehpad_puv``.

    Note Q5 : le query param s'appelle ``annexe`` côté API (L2 spec
    explicite) et est mappé vers la colonne DDL ``annexe_variante``."""
    company_id = _require_company(auth)
    try:
        return await activite_service.list_activite(
            doc_id, company_id, ets_id=ets_id, annexe_variante=annexe
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
