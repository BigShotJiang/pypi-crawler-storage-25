"""HTTP routes for Documents budgétaires (L2 §4).

6 endpoints shipped here :

* §4.1 ``GET /documents`` — filterable list (type, statut, annee, og_id)
* §4.2 ``POST /documents`` — create + auto-CRPP transaction
* §4.3 ``GET /documents/{id}``
* §4.4 ``PATCH /documents/{id}`` — RIA periode + cadre override
* §4.5 ``DELETE /documents/{id}`` — brouillon-only
* §4.8 ``POST /documents/{id}/clone`` — EPRD → DM/RIA

§4.6 (``POST /transitions``) and §4.7 (``GET /transitions-allowed``)
live in the §X workflow chantier — out of §E.3.

Permissions follow L2 :
* ``GET`` → ``require_user``
* ``POST`` / ``PATCH`` / ``DELETE`` / ``POST :clone`` → ``require_builder``
"""

from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_builder, require_user

from piilot_pack_compta_esms.models.document import (
    DocumentClone,
    DocumentCreate,
    DocumentRead,
    DocumentUpdate,
    StatutDocument,
    TypeDocument,
)
from piilot_pack_compta_esms.routes._errors import domain_error_to_http
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import document_service
from piilot_pack_compta_esms.services.errors import DomainError

router = APIRouter(prefix="/documents", tags=["compta_esms:documents"])


def _require_company(auth: tuple) -> UUID:
    company_id = auth[2]
    if company_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "missing_company_context",
                "message": "X-Company-Id header is required",
            },
        )
    return UUID(str(company_id))


@router.get("", response_model=list[DocumentRead])
@limiter.limit("100/minute")
async def list_documents(
    request: Request,
    # FastAPI infers Query() automatically for non-path/body params ;
    # we keep the explicit ``None`` default so ruff B008 stays quiet
    # without needing per-line ``noqa``.
    type: TypeDocument | None = None,
    statut: StatutDocument | None = None,
    annee: int | None = None,
    og_id: UUID | None = None,
    auth: tuple = Depends(require_user),
) -> list[DocumentRead]:
    """L2 §4.1 — filterable document list."""
    company_id = _require_company(auth)
    return await document_service.list_documents(
        company_id,
        type_document=type,
        statut=statut,
        annee=annee,
        og_id=og_id,
    )


@router.post("", response_model=DocumentRead, status_code=status.HTTP_201_CREATED)
@limiter.limit("30/minute")
async def create_document(
    request: Request,
    payload: DocumentCreate,
    auth: tuple = Depends(require_builder),
) -> DocumentRead:
    """L2 §4.2 — create a document and its default CRPP (D-073).

    Both INSERTs happen in one transaction — if the CRPP insert fails
    (CHECK violation, RLS rejection), the document insert rolls back.
    """
    company_id = _require_company(auth)
    try:
        return await document_service.create_document(company_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.get("/{doc_id}", response_model=DocumentRead)
@limiter.limit("100/minute")
async def get_document(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_user),
) -> DocumentRead:
    """L2 §4.3 — fetch single document.

    ``?include=crp_lignes,pgfp_lignes,controles`` is not honored here ;
    sub-table inflation arrives with §E.4 (CRs), §H (lignes), §Z
    (controles) on dedicated endpoints.
    """
    _require_company(auth)
    try:
        return await document_service.get_document(doc_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.patch("/{doc_id}", response_model=DocumentRead)
@limiter.limit("30/minute")
async def update_document(
    request: Request,
    doc_id: UUID,
    payload: DocumentUpdate,
    auth: tuple = Depends(require_builder),
) -> DocumentRead:
    """L2 §4.4 — patch metadata (cadre_version, RIA periode).

    Status mutations and transmis/executoire timestamps belong to the
    workflow chantier (§X). Same for parent_id, exercice_id,
    type_document — those would never change post-create.
    """
    _require_company(auth)
    try:
        return await document_service.update_document(doc_id, payload)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.delete("/{doc_id}", status_code=status.HTTP_204_NO_CONTENT)
@limiter.limit("30/minute")
async def delete_document(
    request: Request,
    doc_id: UUID,
    auth: tuple = Depends(require_builder),
) -> None:
    """L2 §4.5 — hard delete (brouillon-only).

    409 if the document is past ``brouillon``. The cabinet must
    revert state via a workflow transition (§X) to delete a
    transmis/executoire document.
    """
    company_id = _require_company(auth)
    try:
        await document_service.delete_document(company_id, doc_id)
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc


@router.post(
    "/{source_id}/clone",
    response_model=DocumentRead,
    status_code=status.HTTP_201_CREATED,
)
@limiter.limit("30/minute")
async def clone_document(
    request: Request,
    source_id: UUID,
    payload: DocumentClone,
    auth: tuple = Depends(require_builder),
) -> DocumentRead:
    """L2 §4.8 — clone an EPRD into a DM or RIA.

    Le clone est un fresh ``brouillon`` avec ``parent_id = source_id``.
    **§V** : les CRs du parent EPRD sont **automatiquement copiés**
    dans le clone (D-063 héritage immutable du périmètre KB23 §2.3).
    Les ``crp_lignes`` ne sont pas copiées en v0.2 (différé v0.3).
    """
    company_id = _require_company(auth)
    user_id = UUID(str(auth[0])) if auth[0] is not None else None
    try:
        return await document_service.clone_document(
            company_id, source_id, payload, user_id=user_id
        )
    except DomainError as exc:
        raise domain_error_to_http(exc) from exc
