"""HTTP routes §AI — meta endpoints (L2 §23.1 + §23.2).

2 endpoints :

* GET ``/health`` non-auth — healthcheck plugin (status + namespace).
* GET ``/version`` user — version plugin + SDK + display_name.

Le ``/health`` reste **délibérément léger** : pas de SELECT DB. Un
healthcheck qui bloque sur la DB devient instable côté Coolify (faux
positifs sur transient latency PG). La vérif DB est faite par le core
sur ``/health`` racine + le Docker healthcheck conteneur.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, status
from piilot.sdk.http import require_user
from pydantic import BaseModel, ConfigDict

from piilot_pack_compta_esms.routes._limiter import limiter

router = APIRouter(tags=["compta_esms:meta"])


# ---------------------------------------------------------------------------
# Response DTOs
# ---------------------------------------------------------------------------


class HealthResponse(BaseModel):
    """Réponse minimale ``/health`` — léger, pas de check DB."""

    model_config = ConfigDict(extra="forbid")

    status: str
    plugin: str


class VersionResponse(BaseModel):
    """Réponse ``/version`` — métadonnées plugin depuis le manifest TOML."""

    model_config = ConfigDict(extra="forbid")

    plugin_version: str
    namespace: str
    display_name: str
    sdk_compat: str


# ---------------------------------------------------------------------------
# /health — non-auth
# ---------------------------------------------------------------------------


@router.get("/health", response_model=HealthResponse)
async def health_route(request: Request) -> HealthResponse:
    """L2 §23.1 — healthcheck plugin (pas d'auth, pas de check DB).

    Retourne ``status="ok"`` tant que le process FastAPI répond. Le
    healthcheck DB se fait côté core / Docker healthcheck conteneur.
    """
    return HealthResponse(status="ok", plugin="compta_esms")


# ---------------------------------------------------------------------------
# /version — user
# ---------------------------------------------------------------------------


def _read_manifest_metadata() -> dict[str, Any]:
    """Lit ``Plugin.manifest`` (déjà parsé au boot par ``load_manifest``).

    Renvoie un dict avec ``plugin_version``, ``namespace``, ``display_name``,
    ``sdk_compat``. Si le manifest n'est pas parseable (cas dégénéré
    hors host), retourne des valeurs sentinelles.
    """
    try:
        from piilot_pack_compta_esms import Plugin

        manifest = Plugin.manifest
    except Exception:  # noqa: BLE001
        return {
            "plugin_version": "unknown",
            "namespace": "compta_esms",
            "display_name": "Comptabilité ESMS",
            "sdk_compat": "unknown",
        }

    # Le manifest expose des attributs Pydantic / SDK-typed — on accède
    # via getattr pour résister aux variations de typage SDK.
    return {
        "plugin_version": str(getattr(manifest, "version", "0.0.0")),
        "namespace": str(getattr(manifest, "namespace", "compta_esms")),
        "display_name": str(getattr(manifest, "display_name", "Comptabilité ESMS")),
        "sdk_compat": str(getattr(manifest, "sdk_compat", "unknown")),
    }


@router.get("/version", response_model=VersionResponse)
@limiter.limit("100/minute")
async def version_route(
    request: Request,
    auth: tuple = Depends(require_user),
) -> VersionResponse:
    """L2 §23.2 — métadonnées plugin (version + namespace + SDK compat).

    Auth ``require_user`` (n'importe quel membre authentifié d'une
    company). Pas de leak de secret — uniquement métadonnées
    déclarées dans le manifest TOML.
    """
    if auth is None or len(auth) < 1:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "unauthenticated", "message": "auth required"},
        )
    return VersionResponse(**_read_manifest_metadata())
