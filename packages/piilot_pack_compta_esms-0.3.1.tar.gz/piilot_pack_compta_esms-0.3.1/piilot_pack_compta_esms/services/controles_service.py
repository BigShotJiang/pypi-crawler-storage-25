"""Service §Z — orchestration des contrôles intégrés (L2 §18).

Expose :

* :func:`list_controles` — GET §18.1 (filtres statut/severite)
* :func:`run_controles` — POST §18.2 (codes_filter optionnel)
* :func:`compute_summary` — GET §18.3 (synthèse OK/KO/NA)
* :func:`run_bloquants` — helper interne utilisé par §S workflow
  transmit guard (D-034)

Load du catalogue KB core via :mod:`reference_lookup` filtré par
``applicable_doc_types`` du document. Persistance via
:mod:`controles_resultats_repo`. Pattern aligné avec
``cles_repartition_service`` §Y (load + filter + delegate).
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread
from pydantic import BaseModel, ConfigDict

from piilot_pack_compta_esms.controls.engine import ControlsEngine
from piilot_pack_compta_esms.repositories import controles_resultats_repo, document_repo
from piilot_pack_compta_esms.services import reference_lookup
from piilot_pack_compta_esms.services.errors import NotFoundError

logger = logging.getLogger(__name__)

_AUDIT_CONTROLS_SLUG = "com.piilot.core.audit-controls-esms"

# Codes bloquants D-034 (cf. KB core seed v0.2 — is_bloquant_transition=true).
# C-001/2/3 v0.2 §Z. C-004/5 ajoutés v0.3 §BG' pour D-036 / R.314-225 :
# EPRD refusé à la transmission si annexe TPER (6) ou Activité (4) vide.
BLOQUANT_CODES: frozenset[str] = frozenset({"C-001", "C-002", "C-003", "C-004", "C-005"})


# ---------------------------------------------------------------------------
# DTOs publics
# ---------------------------------------------------------------------------


class ControleResultRead(BaseModel):
    """Row de ``controles_resultats`` exposée via API."""

    model_config = ConfigDict(extra="forbid")

    code: str
    statut: str
    severite_observee: str
    message_humain: str | None
    valeurs_observees: dict[str, Any]
    evaluated_at: Any


class ControlesSummary(BaseModel):
    """Réponse GET /controles/summary — synthèse compacte."""

    model_config = ConfigDict(extra="forbid")

    total: int
    ok: int
    ko: int
    na: int
    ko_error: int
    ko_warning: int
    ko_bloquant: int


class RunControlesResult(BaseModel):
    """Réponse POST :run — récap d'exécution."""

    model_config = ConfigDict(extra="forbid")

    document_id: UUID
    nb_codes_evalues: int
    summary: ControlesSummary


# ---------------------------------------------------------------------------
# Helpers internes
# ---------------------------------------------------------------------------


async def _load_doc_or_404(document_id: UUID, company_id: UUID) -> dict[str, Any]:
    row = await run_in_thread(document_repo.get_by_id, document_id)
    if row is None or str(row["company_id"]) != str(company_id):
        raise NotFoundError(
            f"document_not_found:{document_id}",
            code="document_not_found",
        )
    return row


async def _load_applicable_codes(type_document: str) -> set[str]:
    """Filtre le catalogue KB core par doc_type.

    Le champ ``applicable_doc_types`` est un CSV inline (``"errd,eprd"``).
    Le lookup KB core ne sait pas filtrer LIKE — on charge tout et on
    filtre côté Python. Cache mémoire géré par :mod:`reference_lookup`
    (1 SELECT au premier appel, cache infini sauf invalidation admin).
    """
    rows = await reference_lookup.list_all_rows(_AUDIT_CONTROLS_SLUG)
    out: set[str] = set()
    for row in rows:
        applicable = (row.get("applicable_doc_types") or "").strip()
        if not applicable:
            continue
        types = {t.strip() for t in applicable.split(",")}
        if type_document in types:
            code = row.get("code")
            if code:
                out.add(code)
    return out


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


async def list_controles(
    document_id: UUID,
    company_id: UUID,
    *,
    statut: str | None = None,
    severite: str | None = None,
) -> list[ControleResultRead]:
    """L2 §18.1 — list results pour 1 document."""
    await _load_doc_or_404(document_id, company_id)
    rows = await run_in_thread(
        controles_resultats_repo.list_by_document,
        document_id,
        statut=statut,
        severite=severite,
    )
    return [ControleResultRead.model_validate(r) for r in rows]


async def run_controles(
    document_id: UUID,
    company_id: UUID,
    *,
    codes_filter: list[str] | None = None,
) -> RunControlesResult:
    """L2 §18.2 — évalue les contrôles applicables et persiste les résultats."""
    document = await _load_doc_or_404(document_id, company_id)
    applicable = await _load_applicable_codes(document["type_document"])

    engine = ControlsEngine(
        document_id=document_id,
        company_id=company_id,
        document=document,
        codes_filter=codes_filter,
        applicable_codes=applicable,
    )
    results = await engine.run()
    # Persiste
    await run_in_thread(
        controles_resultats_repo.bulk_upsert,
        company_id,
        document_id,
        results,
    )
    # Summary
    summary_raw = await run_in_thread(controles_resultats_repo.compute_summary_for_doc, document_id)
    return RunControlesResult(
        document_id=document_id,
        nb_codes_evalues=len(results),
        summary=ControlesSummary.model_validate(summary_raw),
    )


async def compute_summary(document_id: UUID, company_id: UUID) -> ControlesSummary:
    """L2 §18.3 — synthèse OK/KO/NA."""
    await _load_doc_or_404(document_id, company_id)
    raw = await run_in_thread(controles_resultats_repo.compute_summary_for_doc, document_id)
    return ControlesSummary.model_validate(raw)


# ---------------------------------------------------------------------------
# Helper interne — guard §S workflow transmit
# ---------------------------------------------------------------------------


async def run_bloquants(document_id: UUID, company_id: UUID) -> list[dict[str, Any]]:
    """Évalue uniquement les 3 contrôles bloquants D-034 et retourne
    la liste des KO. Appelé en interne par
    :func:`workflow_service.apply_transition` lors d'une transition
    transmit (D-034 — bloquer si ≥1 contrôle bloquant KO).

    Ne persiste **pas** les résultats — c'est un check rapide
    pré-transition, le cabinet a déjà fait ``:run`` complet avant.
    Si on persistait, on écraserait potentiellement des résultats plus
    riches du dernier :run complet.
    """
    document = await _load_doc_or_404(document_id, company_id)
    engine = ControlsEngine(
        document_id=document_id,
        company_id=company_id,
        document=document,
        codes_filter=list(BLOQUANT_CODES),
        applicable_codes=None,  # bypass filter — on veut les 3 bloquants peu importe doc_type
    )
    results = await engine.run()
    return [r for r in results if r["statut"] == "ko"]
