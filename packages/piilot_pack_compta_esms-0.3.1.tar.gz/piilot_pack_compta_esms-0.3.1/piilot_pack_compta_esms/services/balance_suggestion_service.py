"""Three-tier suggestion pipeline for the assistant mapping (§F.4).

Pipeline applied per distinct source account :

1. **KB ref** — :func:`piilot_pack_compta_esms.services.pcg_to_m22bis.lookup`
   on the pre-shipped catalog (§F.1). Identity matches + class-73
   experts → confidence in [0.7, 1.0], origin ``"pcg_to_m22bis_kb"``.
2. **Preset outil** — :data:`pcg_to_m22bis._PRESETS` for the source_plan
   when it's a known outil (Pennylane / Sage / EBP / Cegid). v0.2 ships
   stubs ; cabinet pilote enrichira via PR upstream sur le plugin repo.
3. **LLM** — **stubbed in v0.2**. The SDK primitive
   ``piilot.sdk.agents.get_company_llm()`` is now available (SDK 0.8.0,
   AICockpit PR #198) — :func:`_score_llm` can dispatch through the
   company's multi-LLM configuration. **What's still deferred** is the
   prompt design (few-shot examples, output schema, hallucination
   guards) and the cache hit logic on
   :class:`compta_esms.llm_suggestion_cache` (migration 005, §F.1).
   Slated for v0.3 once the cabinet pilote validates Tier 1 / 2
   coverage on a real balance.

Tier 1 / 2 cover ~80-90% of a typical balance (identity + classe 73
specials). The remaining 10-20% land in ``targets=[]`` for the
cabinet to map manually in the assistant UI ; once Tier 3 is wired,
those gaps shrink to ~5%.

Persisted shape on ``balance_imports.suggestions`` (migration 007) :

.. code-block:: json

    [
      {
        "source_account": "60611",
        "label_hint": "Eau",
        "targets": [
          {"target_m22bis_account": "60611", "weight": 1.0,
           "confidence": 1.0, "origin": "pcg_to_m22bis_kb"}
        ]
      },
      ...
    ]
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk import storage
from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.balance_import import BalanceImportRead
from piilot_pack_compta_esms.models.balance_mapping import BalanceMappingBulkItem
from piilot_pack_compta_esms.models.suggestion import (
    AcceptAboveRequest,
    SourceAccountSuggestion,
    SuggestionTarget,
    SuggestRequest,
)
from piilot_pack_compta_esms.repositories import balance_import_repo
from piilot_pack_compta_esms.services import (
    balance_file_parser,
    balance_mapping_service,
    pcg_to_m22bis,
)
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)


def _to_read(row: dict[str, Any]) -> BalanceImportRead:
    return BalanceImportRead.model_validate(row)


def _score_kb_ref(
    source_plan: str, source_account: str, version_m22bis: str
) -> list[SuggestionTarget]:
    """Tier 1 — pre-shipped PCG → M22 bis catalog.

    Returns one target per row in the CSV : 1:1 → single target,
    1:N → multiple targets with split weights."""
    rows = pcg_to_m22bis.lookup(source_plan, source_account, version_m22bis)
    return [
        SuggestionTarget(
            target_m22bis_account=row["target_m22bis_account"],
            weight=row["weight"],
            confidence=row["confidence"],
            origin="pcg_to_m22bis_kb",
        )
        for row in rows
    ]


def _score_preset(source_plan: str, source_account: str) -> list[SuggestionTarget]:
    """Tier 2 — outil-specific preset overrides.

    The preset names are exact ``source_plan`` values (``"Pennylane"``,
    ``"Sage"``, ``"EBP"``, ``"Cegid"``). v0.2 stubs ship only a
    placeholder Pennylane entry — the pilote cabinet enriches via PR
    on the plugin repo as their balance imports surface new sub-accounts."""
    preset = pcg_to_m22bis.get_preset(source_plan)
    if preset is None:
        return []
    out: list[SuggestionTarget] = []
    for entry in preset.get("mappings", []):
        if entry.get("source_account") != source_account:
            continue
        out.append(
            SuggestionTarget(
                target_m22bis_account=entry["target_m22bis_account"],
                weight=entry.get("weight", 1.0),
                confidence=entry.get("confidence", 0.9),
                origin="preset",
            )
        )
    return out


def _score_llm(
    source_account: str,
    label_hint: str | None,
    include_llm: bool,
    llm_threshold: float,
) -> list[SuggestionTarget]:
    """Tier 3 — LLM fallback.

    **v0.2 stub** : returns ``[]`` regardless. The SDK primitive
    ``piilot.sdk.agents.get_company_llm()`` is now available (since
    v0.8.0) ; what's left is the prompt + cache wiring. The full
    flow will be :

    1. Hash ``(source_plan, source_account_normalized, label_hint_hash)``,
       SELECT from :class:`compta_esms.llm_suggestion_cache` (TTL 90j,
       migration 005). Cache hit → return rows.
    2. Cache miss → prompt the company's configured LLM with a short
       few-shot of `(label_hint → likely M22 bis target)`. The model
       returns a list of `(target, confidence)` pairs.
    3. Keep only suggestions with ``confidence >= llm_threshold``.
    4. INSERT cache + return.

    For now we ignore ``include_llm`` / ``llm_threshold`` and return
    nothing — the cabinet manually maps the residual ambiguous
    accounts in the assistant UI.
    """
    if not include_llm:
        return []
    # TODO: prompt design + cache wiring (migration 005). The SDK
    # helper ``piilot.sdk.agents.get_company_llm(company_id, usage='chat')``
    # is available since SDK 0.8.0 — slated for v0.3 of this plugin.
    _ = source_account  # silence vulture
    _ = label_hint
    _ = llm_threshold
    return []


def _merge_tiers(
    tier_outputs: list[list[SuggestionTarget]],
) -> list[SuggestionTarget]:
    """Deduplicate targets across tiers — KB > preset > LLM order.

    The earlier tier wins on duplicate ``target_m22bis_account`` —
    we trust the catalog more than the preset more than the LLM."""
    seen: set[str] = set()
    out: list[SuggestionTarget] = []
    for tier in tier_outputs:
        for target in tier:
            if target.target_m22bis_account in seen:
                continue
            seen.add(target.target_m22bis_account)
            out.append(target)
    return out


async def suggest_mappings(
    company_id: UUID, import_id: UUID, request: SuggestRequest
) -> BalanceImportRead:
    """Run the full 3-tier pipeline over a balance import.

    1. Download the source file from S3.
    2. Extract distinct source accounts via the parser (uses the
       cabinet's current column detection).
    3. Score each account through KB ref + preset + LLM stub.
    4. Persist the result on ``balance_imports.suggestions``."""
    current = await run_in_thread(balance_import_repo.get_by_id, import_id)
    if current is None:
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )
    if str(current["company_id"]) != str(company_id):
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )

    storage_key = current["source_storage_key"]
    if not storage_key:
        raise ConflictError(
            f"Balance import {import_id} has no source_storage_key — "
            "re-upload the file before running suggestions.",
            code="balance_import_missing_storage",
        )
    column_detection = current["column_detection"] or {}
    if column_detection.get("compte") is None:
        raise ConflictError(
            "column_detection.compte is unset — call :detect-columns "
            "with the right ``compte`` index before suggesting.",
            code="suggestions_compte_unset",
        )

    body = await storage.get_object(storage_key)
    filename = current["source_filename"] or "balance.xlsx"
    sources = balance_file_parser.extract_source_accounts(
        body, filename=filename, column_detection=column_detection
    )

    source_plan = request.source_plan or current["source_plan"]
    version_m22bis = "2025-2026"

    out_rows: list[dict[str, Any]] = []
    for entry in sources:
        account = entry["source_account"]
        label_hint = entry["label_hint"]
        targets = _merge_tiers(
            [
                _score_kb_ref(source_plan, account, version_m22bis),
                _score_preset(source_plan, account),
                _score_llm(account, label_hint, request.include_llm, request.llm_threshold),
            ]
        )
        out_rows.append(
            SourceAccountSuggestion(
                source_account=account,
                label_hint=label_hint,
                targets=targets,
            ).model_dump()
        )

    row = await run_in_thread(balance_import_repo.update_suggestions, import_id, out_rows)
    if row is None:
        # Should not happen — we just read the row a moment ago.
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )
    return _to_read(row)


async def list_suggestions(
    company_id: UUID,
    import_id: UUID,
    *,
    confidence_min: float | None = None,
    origins: list[str] | None = None,
) -> list[SourceAccountSuggestion]:
    """Filter-aware read of the stored suggestions.

    ``confidence_min`` filters at the target level (a source row with
    multiple targets keeps the ones meeting the threshold). ``origins``
    drops targets whose origin isn't in the allow-list. A source row
    with no surviving target is omitted from the response — keeps the
    payload focused on actionable suggestions."""
    current = await run_in_thread(balance_import_repo.get_by_id, import_id)
    if current is None:
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )
    if str(current["company_id"]) != str(company_id):
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )

    out: list[SourceAccountSuggestion] = []
    for entry in current["suggestions"] or []:
        targets = entry.get("targets", [])
        if confidence_min is not None:
            targets = [t for t in targets if t["confidence"] >= confidence_min]
        if origins:
            targets = [t for t in targets if t["origin"] in origins]
        if not targets:
            continue
        out.append(
            SourceAccountSuggestion(
                source_account=entry["source_account"],
                label_hint=entry.get("label_hint"),
                targets=[SuggestionTarget(**t) for t in targets],
            )
        )
    return out


async def accept_all_above(
    company_id: UUID,
    import_id: UUID,
    request: AcceptAboveRequest,
) -> list[Any]:
    """Bulk-upsert the suggestions whose confidence ≥ threshold into
    ``compta_esms.balance_mappings``.

    Returns the resulting :class:`BalanceMappingRead` rows so the
    frontend can refresh the dictionary view in one round-trip.

    ``source_plan`` carries the import's plan (cabinet doesn't override
    here ; that's what ``:suggest-mappings`` is for). ``label_hint``
    propagates so the dictionary entry shows context."""
    current = await run_in_thread(balance_import_repo.get_by_id, import_id)
    if current is None:
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )
    if str(current["company_id"]) != str(company_id):
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )

    source_plan = current["source_plan"]
    version_m22bis = "2025-2026"
    items: list[BalanceMappingBulkItem] = []
    for entry in current["suggestions"] or []:
        source_account = entry["source_account"]
        label_hint = entry.get("label_hint")
        for target in entry.get("targets", []):
            if target["confidence"] < request.confidence_threshold:
                continue
            items.append(
                BalanceMappingBulkItem(
                    source_plan=source_plan,
                    source_account=source_account,
                    target_m22bis_account=target["target_m22bis_account"],
                    weight=target["weight"],
                    confidence=target["confidence"],
                    label_hint=label_hint,
                    suggestion_origin=target["origin"],
                    version_m22bis=version_m22bis,
                )
            )

    if not items:
        return []
    return await balance_mapping_service.bulk_upsert_mappings(company_id, items)
