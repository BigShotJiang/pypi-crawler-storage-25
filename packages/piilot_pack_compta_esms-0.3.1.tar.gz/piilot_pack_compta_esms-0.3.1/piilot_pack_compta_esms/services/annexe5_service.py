"""Annexe 5 Financière service (§R, L2 §13.1-§13.2).

Orchestre 2 endpoints :

* :func:`list_annexe5` — GET §13.1 (filtres optionnels ets_id + variante)
* :func:`bulk_upsert_annexe5` — POST §13.2 (replace_by_(doc, ets, variante) Q1,
  auto-déduit variante depuis ETS.typologie Q6 + 422 si pas Annexe 5
  applicable)

Permissions L2 §13.1+§13.2 (Q11) : **user**.

Q6 auto-déduction variante via
:func:`reference_lookup.deduce_variante_annexe5` :

* ehpad/aja/puv → 5A_ehpad
* fam/samsah → 5C_fam_samsah
* sad/spasad → 5D_sad_spasad
* **autres → None → 422 ``annexe5_not_applicable``**

Validation cohérence payload variante vs typologie : si le payload
inclut une ``variante`` qui ne correspond pas à la typologie de l'ETS,
on **respecte le payload** (cabinet peut overrider) — pattern §K Bilan
PC/PNL. Seule la déduction sert au routing par défaut quand non
fournie ; ici le payload **doit** fournir ``variante`` (top-level
required, Pydantic), donc on ne fait pas d'auto-déduction silencieuse.

**Reco implémentée** : on valide UNIQUEMENT que l'ETS *est éligible*
à Annexe 5 (typologie déductible vers 5A/5C/5D). On laisse le cabinet
choisir la variante côté payload (un EHPAD pourrait techniquement
basculer en 5C s'il a un forfait soins — cas marginal mais possible).

Validation D-056 (``Σ Résultat = Résultat CRPP``) → différé §Z (Q9).
"""

from __future__ import annotations

import logging
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.annexe5 import (
    Annexe5BulkUpsertRequest,
    Annexe5LigneRead,
    Annexe5Response,
    VarianteAnnexe5,
)
from piilot_pack_compta_esms.repositories import annexe5_repo
from piilot_pack_compta_esms.services import document_freeze, document_scope, reference_lookup
from piilot_pack_compta_esms.services.errors import NotFoundError, ValidationError

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(annexe5_repo.document_belongs_to_company, document_id, company_id)
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


async def _require_ets_annexe5_eligible(etablissement_id: UUID, company_id: UUID) -> str:
    """Q6 — vérifie que l'ETS est éligible à Annexe 5 (typologie
    déductible vers une variante 5A/5C/5D). Retourne la variante
    déduite pour info — le payload prime côté bulk-upsert.

    Refuse 422 ``annexe5_not_applicable`` pour IME/ITEP/ESAT/CMPP/etc."""
    ctx = await run_in_thread(annexe5_repo.get_ets_typologie, etablissement_id, company_id)
    if ctx is None:
        raise NotFoundError(
            f"etablissement {etablissement_id} not found for this company",
            code="etablissement_not_found",
        )
    deduced = reference_lookup.deduce_variante_annexe5(ctx.get("typologie"))
    if deduced is None:
        raise ValidationError(
            f"Annexe 5 not applicable to etablissement typologie "
            f"'{ctx.get('typologie')}'. Annexe 5 is restricted to "
            f"EHPAD/AJA/PUV (5A), FAM/SAMSAH (5C), SAD/SPASAD (5D).",
            code="annexe5_not_applicable",
        )
    return deduced


# ---------------------------------------------------------------------------
# §13.1 — list_annexe5
# ---------------------------------------------------------------------------


async def list_annexe5(
    document_id: UUID,
    company_id: UUID,
    ets_id: UUID | None = None,
    variante: VarianteAnnexe5 | None = None,
) -> Annexe5Response:
    """Liste avec filtres optionnels."""
    await _require_document(document_id, company_id)
    rows = await run_in_thread(annexe5_repo.list_by_filter, document_id, ets_id, variante)
    return Annexe5Response(
        ets_id_filtre=ets_id,
        variante_filtre=variante,
        items=[Annexe5LigneRead.model_validate(r) for r in rows],
    )


# ---------------------------------------------------------------------------
# §13.2 — bulk_upsert_annexe5 (Q1 replace_by_doc_ets_variante)
# ---------------------------------------------------------------------------


async def bulk_upsert_annexe5(
    document_id: UUID,
    company_id: UUID,
    payload: Annexe5BulkUpsertRequest,
) -> Annexe5Response:
    """Replace by (doc, ets, variante) — atomique (Q1).

    Garde Q6 : ETS doit être éligible Annexe 5 (typologie EHPAD/FAM/SAD).
    Sinon 422 ``annexe5_not_applicable``. La variante du payload prime
    sur la déduction (cas marginal EHPAD→5C forfait soins respecté).

    Freeze §S : 409 si document hors brouillon."""
    await document_freeze.require_brouillon(document_id, company_id)
    await document_scope.assert_not_eps_only_doc(document_id)
    await _require_document(document_id, company_id)
    await _require_ets_annexe5_eligible(payload.ets_id, company_id)

    items_dict = [item.model_dump(mode="json") for item in payload.items]
    await run_in_thread(
        annexe5_repo.replace_by_doc_ets_variante,
        company_id=company_id,
        document_id=document_id,
        etablissement_id=payload.ets_id,
        variante=payload.variante,
        items=items_dict,
    )
    return await list_annexe5(
        document_id,
        company_id,
        ets_id=payload.ets_id,
        variante=payload.variante,
    )


__all__ = [
    "list_annexe5",
    "bulk_upsert_annexe5",
]
