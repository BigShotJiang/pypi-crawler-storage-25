"""Domain exceptions raised by services and caught by routes.

Services never raise :class:`fastapi.HTTPException` directly — they're
unit-tested without a request context. The route layer catches these
domain errors and maps them to HTTP responses. Each exception carries
a short stable ``code`` so the frontend can branch on it without
parsing prose.
"""

from __future__ import annotations


class DomainError(Exception):
    """Base class — every service-raised exception inherits from this."""

    code: str = "domain_error"
    status_code: int = 500

    def __init__(self, message: str, *, code: str | None = None) -> None:
        super().__init__(message)
        if code:
            self.code = code


class NotFoundError(DomainError):
    """Resource lookup returned no row."""

    code = "not_found"
    status_code = 404


class ConflictError(DomainError):
    """Operation violates a uniqueness or dependency rule.

    Examples: ``finess_juridique`` already exists for the company,
    delete attempted while child rows still reference the entity.
    """

    code = "conflict"
    status_code = 409


class CrossCompanyError(DomainError):
    """Caller's company does not own the requested resource.

    Raised before the DB even runs to short-circuit a leak. RLS would
    catch it too, but the explicit 403 is more honest than a 404.
    """

    code = "cross_company"
    status_code = 403


class ValidationError(DomainError):
    """Request body is syntactically valid but semantically rejected.

    Differs from a Pydantic validation error : we have a real domain
    rule that says no (e.g. a binding's KB doesn't expose all the
    columns the feature contract requires). Maps to HTTP 422.
    """

    code = "validation_error"
    status_code = 422
