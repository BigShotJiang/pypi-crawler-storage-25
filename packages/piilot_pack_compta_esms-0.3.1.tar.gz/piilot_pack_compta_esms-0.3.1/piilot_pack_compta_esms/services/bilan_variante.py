"""Helper pur — variante de bilan comptable (D-067 + D-086).

Auto-déduction de la variante comptable :

* ``og.plan_comptable = 'PC'`` (commercial) → ``comptable_pc``
  (avec Onglet "Suivi EHPAD")
* ``og.plan_comptable = 'PNL'`` (non lucratif) → ``comptable_pnl``
  (avec Onglet "Comptes de liaison")

Le bilan ``financier`` est toujours autorisé en parallèle (D-066
"2 documents distincts"). Cette fonction ne s'occupe que de la
variante comptable.

Pattern identique à :mod:`affectation_variante` (§J.3).
"""

from __future__ import annotations

from typing import Literal

BilanComptableVariant = Literal["comptable_pc", "comptable_pnl"]
"""2 variantes comptables D-067."""


class UnknownPlanComptableError(ValueError):
    """``plan_comptable`` non reconnu — input à valider en amont."""


def choose_bilan_comptable_variant(plan_comptable: str) -> BilanComptableVariant:
    """Retourne la variante de bilan comptable (D-067).

    Règles :

    * ``PC`` → ``comptable_pc`` (Onglet "Suivi EHPAD")
    * ``PNL`` → ``comptable_pnl`` (Onglet "Comptes de liaison")
    * Autre → :class:`UnknownPlanComptableError`
    """
    if plan_comptable == "PC":
        return "comptable_pc"
    if plan_comptable == "PNL":
        return "comptable_pnl"
    raise UnknownPlanComptableError(
        f"plan_comptable {plan_comptable!r} inconnu — " "valeurs attendues : 'PC' ou 'PNL' (D-086)"
    )
