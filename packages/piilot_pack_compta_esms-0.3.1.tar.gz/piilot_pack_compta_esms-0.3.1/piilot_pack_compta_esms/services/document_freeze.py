"""Document freeze guard — protège les documents post-transition.

Plan-dev L282 + KB 05-workflows.md :

* PATCH document + DELETE + toute mutation des lignes/bilan/TF/PGFP/
  affectations/TPER/TER/activité/annexe5/forfait/etc. **doivent
  refuser** si le document n'est plus en ``brouillon``.
* "Pas de back-transition possible" — un document figé devient
  immuable. Pour modifier, le cabinet doit créer une nouvelle version
  (clone) ou un DM/RIA (EPRD).

Le helper expose une seule entrée publique :

* :func:`require_brouillon` — charge le statut du doc (read léger) et
  raise :class:`ConflictError` ``document_not_editable`` si le statut
  est différent de ``'brouillon'``. Raise :class:`NotFoundError` /
  :class:`CrossCompanyError` aux cas attendus.

Le wiring se fait depuis chaque service mutateur en première
instruction de la méthode. Cf. wire complet en §S commit.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor, run_in_thread

from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
)

# Statuts qui autorisent les mutations. La valeur ``'brouillon'`` est
# la seule prévue par le workflow (cf. plan-dev §4.x). On expose une
# constante pour pouvoir laisser un test paramétriser au besoin.
EDITABLE_STATUTS: frozenset[str] = frozenset({"brouillon"})


def _select_statut_and_company(document_id: UUID) -> dict[str, Any] | None:
    """SELECT léger sur 2 colonnes — pas de JOIN, pas de FK. Plus
    rapide que :func:`workflow_repo.load_snapshot` qui ramène 15
    colonnes. Tradeoff : 1 SELECT par mutation (acceptable, le doc
    est en cache PG pour la session)."""
    with cursor() as cur:
        cur.execute(
            "SELECT statut, company_id " "FROM compta_esms.documents_budgetaires " "WHERE id = %s",
            (str(document_id),),
        )
        return cur.fetchone()


async def require_brouillon(document_id: UUID, company_id: UUID) -> None:
    """Refuse toute mutation sur un document hors ``brouillon``.

    Raises :

    * :class:`NotFoundError` (404) — document inexistant.
    * :class:`CrossCompanyError` (403) — pas dans la company appelante.
    * :class:`ConflictError` (409) avec code ``document_not_editable`` —
      statut ≠ ``brouillon``.

    Idempotence : appel multiple sans side-effect.
    """
    row = await run_in_thread(_select_statut_and_company, document_id)
    if row is None:
        raise NotFoundError(
            f"document_not_found:{document_id}",
            code="document_not_found",
        )
    if str(row["company_id"]) != str(company_id):
        raise CrossCompanyError(
            f"document_cross_company:{document_id}",
            code="document_cross_company",
        )
    statut = row["statut"]
    if statut not in EDITABLE_STATUTS:
        raise ConflictError(
            f"document_not_editable:{statut}",
            code="document_not_editable",
        )


def _select_statut_for_cr(cr_id: UUID) -> dict[str, Any] | None:
    """SELECT léger avec JOIN sur ``comptes_resultat`` pour remonter
    au document statut+company_id. Utilisé par
    :func:`require_brouillon_for_cr`."""
    with cursor() as cur:
        cur.execute(
            "SELECT d.statut, d.company_id, d.id AS document_id "
            "FROM compta_esms.comptes_resultat cr "
            "JOIN compta_esms.documents_budgetaires d ON d.id = cr.document_id "
            "WHERE cr.id = %s",
            (str(cr_id),),
        )
        return cur.fetchone()


async def require_brouillon_for_cr(cr_id: UUID, company_id: UUID) -> UUID:
    """Variante par ``cr_id`` — utilisée par
    :mod:`crp_ligne_service` qui n'a pas le ``document_id`` direct.

    Retourne le ``document_id`` pour usage aval (cohérence avec
    :func:`_require_cr_editable` du service ligne).

    Raises identiques à :func:`require_brouillon`. Code spécifique
    ``cr_not_found`` quand la CR n'existe pas pour le tenant.
    """
    row = await run_in_thread(_select_statut_for_cr, cr_id)
    if row is None:
        raise NotFoundError(
            f"cr_not_found:{cr_id}",
            code="cr_not_found",
        )
    if str(row["company_id"]) != str(company_id):
        raise CrossCompanyError(
            f"cr_cross_company:{cr_id}",
            code="cr_cross_company",
        )
    statut = row["statut"]
    if statut not in EDITABLE_STATUTS:
        raise ConflictError(
            f"document_not_editable:{statut}",
            code="document_not_editable",
        )
    return row["document_id"]


def assert_editable(statut: str) -> None:
    """Variante synchrone pour les services qui ont déjà le statut en
    main (économise le SELECT). Raise :class:`ConflictError` si
    statut ≠ ``brouillon``."""
    if statut not in EDITABLE_STATUTS:
        raise ConflictError(
            f"document_not_editable:{statut}",
            code="document_not_editable",
        )
