"""RCC service — Répartition Charges Communes (§N, L2 §16.5-§16.7).

Orchestre :

* :func:`list_rcc` — GET §16.5
* :func:`bulk_upsert_rcc` — POST §16.6 (replace_all_by_document
  atomique Q5)
* :func:`validate_rcc` — POST §16.7 (D-092 : Σ(% par CR) = 100%
  par ligne, tolérance 0.01 Q7)

Pas de ``totals`` dans GET (Q6) — la "synthèse" RCC est la validation
elle-même : Σ% par ligne. ``totals`` global ne fait pas sens
métier (chaque ligne se valide indépendamment).
"""

from __future__ import annotations

from decimal import Decimal
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.rcc import (
    RccBulkUpsertRequest,
    RccLigneRead,
    RccLigneValidation,
    RccResponse,
    RccValidateResponse,
)
from piilot_pack_compta_esms.repositories import rcc_repo
from piilot_pack_compta_esms.services import document_freeze, document_scope
from piilot_pack_compta_esms.services.errors import NotFoundError

_ZERO = Decimal("0")
_HUNDRED = Decimal("100")
_TOLERANCE = Decimal("0.01")
"""Q7 — cohérent §I/§J/§K/§M. D-092 dit '= 100%' sans tolérance
documentée ; on applique 0.01 par cohérence plugin."""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(rcc_repo.document_belongs_to_company, document_id, company_id)
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


def _safe_decimal(value) -> Decimal:  # noqa: ANN001
    if value is None:
        return _ZERO
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def _normalize_repartition_for_read(row: dict) -> dict:
    """Le repo retourne ``repartition_json`` (clé DB). Le modèle Read
    attend ``repartition`` (clé Pydantic). On renomme."""
    out = dict(row)
    rep_raw = out.pop("repartition_json", None) or {}
    # rep_raw : {cr_id_str: {pct: str, montant: str}}
    out["repartition"] = rep_raw
    return out


# ---------------------------------------------------------------------------
# §16.5 — list_rcc
# ---------------------------------------------------------------------------


async def list_rcc(document_id: UUID, company_id: UUID) -> RccResponse:
    await _require_document(document_id, company_id)
    rows = await run_in_thread(rcc_repo.list_by_document, document_id)
    items = [RccLigneRead.model_validate(_normalize_repartition_for_read(r)) for r in rows]
    return RccResponse(items=items)


# ---------------------------------------------------------------------------
# §16.6 — bulk_upsert_rcc (replace_all_by_document Q5)
# ---------------------------------------------------------------------------


async def bulk_upsert_rcc(
    document_id: UUID,
    company_id: UUID,
    payload: RccBulkUpsertRequest,
) -> RccResponse:
    """Replace all by document — atomique (Q5).

    Freeze §S : 409 si document hors brouillon."""
    await document_freeze.require_brouillon(document_id, company_id)
    await document_scope.assert_not_eps_only_doc(document_id)
    await _require_document(document_id, company_id)
    items_dict = [item.model_dump(mode="json") for item in payload.items]
    await run_in_thread(
        rcc_repo.replace_all_by_document,
        company_id=company_id,
        document_id=document_id,
        items=items_dict,
    )
    return await list_rcc(document_id, company_id)


# ---------------------------------------------------------------------------
# §16.7 — validate_rcc (D-092 Σ%=100 par ligne, tolérance 0.01 Q7)
# ---------------------------------------------------------------------------


async def validate_rcc(document_id: UUID, company_id: UUID) -> RccValidateResponse:
    """Pour chaque ligne RCC, calcule ``Σ pct`` sur toutes les entrées
    ``repartition``. Verdict ``valide`` ssi ``|Σ pct - 100| <= 0.01``.

    Cas particulier : une ligne sans ``repartition`` (dict vide) a
    ``somme_pct = 0`` et ``ecart = -100`` → ``valide = False``."""
    await _require_document(document_id, company_id)
    rows = await run_in_thread(rcc_repo.list_by_document, document_id)
    lignes: list[RccLigneValidation] = []
    for row in rows:
        rep = row.get("repartition_json") or {}
        somme = _ZERO
        for entry in rep.values():
            somme += _safe_decimal(entry.get("pct"))
        ecart = somme - _HUNDRED
        valide = abs(ecart) <= _TOLERANCE
        lignes.append(
            RccLigneValidation(
                rcc_ligne_id=row["id"],
                compte_m22bis=row["compte_m22bis"],
                somme_pct=somme,
                ecart=ecart,
                valide=valide,
            )
        )
    valide_globalement = all(ligne.valide for ligne in lignes)
    return RccValidateResponse(
        lignes=lignes,
        valide_globalement=valide_globalement,
        tolerance_appliquee=_TOLERANCE,
    )


__all__ = [
    "list_rcc",
    "bulk_upsert_rcc",
    "validate_rcc",
]
