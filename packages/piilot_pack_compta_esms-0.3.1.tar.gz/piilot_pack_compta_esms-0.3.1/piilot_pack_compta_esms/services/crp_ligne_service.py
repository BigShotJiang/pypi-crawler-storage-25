"""Service layer for CRP lignes (§H, L2 §6).

Implements :

* the CRUD (list / get / create / update / delete),
* the manual ``:bulk-upsert`` (Q4 — preserving meta on COALESCE),
* the totals (Q5 — flat shape, brut ecart, no R.314-222 validation),
* the Q6 auto-flip of ``override_balance`` when patching a binding-
  sourced row,
* the Q7 permissive validation of ``compte_m22bis`` (fail-open warning
  via :func:`reference_lookup.compte_m22bis_exists`).

The prefill flow (Q3 explicit target_column) lives in
:mod:`.crp_prefill_service` to keep the orchestration with §G
(``binding_service``) out of this file.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any
from uuid import UUID

import psycopg2
from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.crp_ligne import (
    BulkUpsertItem,
    CrpEcart,
    CrpLigneCreate,
    CrpLigneRead,
    CrpLigneUpdate,
    CrpTotalsColumnPair,
    CrpTotalsGroupe,
    CrpTotalsResponse,
)
from piilot_pack_compta_esms.repositories import cr_repo, crp_ligne_repo
from piilot_pack_compta_esms.services import document_freeze, reference_lookup, ventilation_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)

logger = logging.getLogger(__name__)

_ZERO = Decimal("0")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_cr(cr_id: UUID, company_id: UUID) -> None:
    """Defense in depth — refuse any cr-scoped op on a CR of another
    tenant. RLS would catch the read but the explicit 404 keeps the
    surface honest."""
    owns = await run_in_thread(crp_ligne_repo.cr_belongs_to_company, cr_id, company_id)
    if not owns:
        raise NotFoundError(f"cr {cr_id} not found for this company", code="cr_not_found")


async def _require_cr_editable(cr_id: UUID, company_id: UUID) -> UUID:
    """Variante du précédent qui charge aussi le ``document_id`` parent
    + applique le freeze §S. Retourne le ``document_id`` pour usage
    aval (par ex. audit log futur). Raise :class:`NotFoundError` ou
    :class:`ConflictError` (``document_not_editable``) selon le cas.

    Délègue à :func:`document_freeze.require_brouillon_for_cr` —
    1 SELECT qui combine vérif tenant + chargement document_id +
    check statut. La fixture conftest mocke ce helper en passthrough
    par défaut pour les tests existants."""
    return await document_freeze.require_brouillon_for_cr(cr_id, company_id)


_VENTILATION_FIELDS: tuple[str, ...] = (
    "montant_hebergement",
    "montant_dependance",
    "montant_soins",
    "montant_soins_autonomie",
)
"""4 colonnes de ventilation H/D/S/SEA — alignées sur ``crp_lignes.*``."""


async def _apply_ventilation_hook(
    *,
    cr_id: UUID,
    payload: dict[str, Any],
) -> None:
    """§Y — auto-ventile et valide la ligne en place.

    Mutate ``payload`` in-place : si les 4 cols H/D/S/SEA sont
    toutes None **et** ``nature='charge'`` **et** le CR est en
    ventilation ternaire_* **et** un ``montant_basis`` est saisi,
    appelle :func:`ventilation_service.apply_default_ventilation` et
    pose les valeurs résultantes.

    Puis appelle :func:`validate_explicit_ventilation` qui :
    * Refuse 422 si ventilation='simple' et user a saisi H/D/S/SEA.
    * Refuse 422 si SEA renseigné mais ETS non-forfait_global_unique.
    * Refuse 422 si Σ ventilée ≠ montant_basis (tolérance 0.01€).
    """
    ctx = await run_in_thread(cr_repo.get_ventilation_context, cr_id)
    if ctx is None:
        # Defensive — le caller a déjà vérifié l'existence via
        # _require_cr_editable, mais si la DB cassait au milieu, le
        # hook serait no-op plutôt que crash.
        return

    ventilation_type = ctx["ventilation"]
    etablissement_id: UUID | None = ctx["etablissement_id"]
    exercice_annee: int = int(ctx["exercice_annee"])

    nature = payload.get("nature")
    basis = ventilation_service.extract_basis_amount(payload)

    # Auto-ventilation conditionnelle.
    if (
        ventilation_type in {"ternaire_hds", "ternaire_hdsea"}
        and nature == "charge"
        and basis is not None
        and etablissement_id is not None
        and all(payload.get(f) is None for f in _VENTILATION_FIELDS)
    ):
        compte = payload.get("compte_m22bis")
        if compte:
            ventilation = await ventilation_service.apply_default_ventilation(
                compte_m22bis=compte,
                montant_total=basis,
                etablissement_id=etablissement_id,
                exercice_annee=exercice_annee,
                ventilation_type=ventilation_type,
            )
            if ventilation is not None:
                payload["montant_hebergement"] = ventilation["hebergement"]
                payload["montant_dependance"] = ventilation["dependance"]
                payload["montant_soins"] = ventilation["soins"]
                payload["montant_soins_autonomie"] = ventilation["soins_autonomie"]

    # Validation systématique — couvre saisie manuelle ET auto-ventilation.
    await ventilation_service.validate_explicit_ventilation(
        montant_basis=basis,
        montant_hebergement=_dec_or_none(payload.get("montant_hebergement")),
        montant_dependance=_dec_or_none(payload.get("montant_dependance")),
        montant_soins=_dec_or_none(payload.get("montant_soins")),
        montant_soins_autonomie=_dec_or_none(payload.get("montant_soins_autonomie")),
        ventilation_type=ventilation_type,
        etablissement_id=etablissement_id,
    )


def _dec_or_none(value: Any) -> Decimal | None:
    if value is None:
        return None
    return Decimal(str(value))


async def _warn_unknown_compte(compte_m22bis: str) -> None:
    """Q7 permissive validation. Logs WARN if the account isn't in the
    core PLT-M21 catalog. Never raises — the cabinet is free to use a
    compte not yet in the synced catalog.

    **§X (D-101)** : la KB core ``com.piilot.core.plan-comptable-esms``
    contient M22Bis + M21 côte à côte (depuis PLT-M21). Le lookup ne
    filtre PAS sur ``type`` : un compte M21 valide est accepté pour
    ERCP/EPCP exactement comme un compte M22Bis pour EPRD/ERRD. Le
    nom de colonne ``compte_m22bis`` reste legacy — un rename en
    ``compte_normalise`` serait une rupture API hors scope §X (post-v0.2)."""
    try:
        known = await reference_lookup.compte_m22bis_exists(compte_m22bis)
    except Exception:  # noqa: BLE001 — fail-open on any lookup error
        logger.debug(
            "crp_ligne_service: compte_m22bis lookup failed, accepting %r",
            compte_m22bis,
        )
        return
    if not known:
        logger.info(
            "crp_ligne_service: compte_m22bis %r not in core plan-comptable-esms — "
            "accepting (fail-open, Q7)",
            compte_m22bis,
        )


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------


async def list_lignes(
    cr_id: UUID,
    company_id: UUID,
    *,
    groupe: str | None = None,
    nature: str | None = None,
) -> list[CrpLigneRead]:
    await _require_cr(cr_id, company_id)
    rows = await run_in_thread(crp_ligne_repo.list_by_cr, cr_id, groupe=groupe, nature=nature)
    return [CrpLigneRead.model_validate(r) for r in rows]


async def get_ligne(ligne_id: UUID, company_id: UUID) -> CrpLigneRead:
    row = await run_in_thread(crp_ligne_repo.get_by_id, ligne_id)
    if row is None:
        raise NotFoundError(f"ligne {ligne_id} not found", code="ligne_not_found")
    if str(row["company_id"]) != str(company_id):
        # Cross-tenant — surface as 404 (not 403) so we don't leak existence
        raise NotFoundError(f"ligne {ligne_id} not found", code="ligne_not_found")
    return CrpLigneRead.model_validate(row)


async def create_ligne(cr_id: UUID, company_id: UUID, payload: CrpLigneCreate) -> CrpLigneRead:
    await _require_cr_editable(cr_id, company_id)
    await _warn_unknown_compte(payload.compte_m22bis)
    data = payload.model_dump(exclude_unset=False)
    # §Y — auto-ventilation H/D/S/SEA + validation Σ.
    await _apply_ventilation_hook(cr_id=cr_id, payload=data)
    try:
        row = await run_in_thread(
            crp_ligne_repo.create,
            company_id=company_id,
            cr_id=cr_id,
            payload=data,
        )
    except psycopg2.errors.UniqueViolation as exc:
        raise ConflictError(
            f"ligne already exists for ({payload.groupe}, {payload.nature}, "
            f"{payload.compte_m22bis}) on this CR",
            code="ligne_duplicate",
        ) from exc
    return CrpLigneRead.model_validate(row)


async def update_ligne(ligne_id: UUID, company_id: UUID, payload: CrpLigneUpdate) -> CrpLigneRead:
    """PATCH a ligne. Q6 auto-flip : if the row has ``binding_id``
    non-NULL, this patch sets ``override_balance=true`` +
    ``override_at=now()`` so the next ``:prefill-from-binding`` skips
    the row. ``override_reason`` (optional in the payload) is persisted
    as part of the audit trail."""
    existing = await run_in_thread(crp_ligne_repo.get_by_id, ligne_id)
    if existing is None:
        raise NotFoundError(f"ligne {ligne_id} not found", code="ligne_not_found")
    if str(existing["company_id"]) != str(company_id):
        raise NotFoundError(f"ligne {ligne_id} not found", code="ligne_not_found")
    await _require_cr_editable(existing["cr_id"], company_id)

    flip = existing["binding_id"] is not None
    data = payload.model_dump(exclude_unset=True)
    # §Y — merge la ligne existante avec le patch pour évaluer la
    # ventilation sur la donnée finale (le user peut patcher juste H
    # sans toucher D/S — on doit valider sur l'état complet).
    merged: dict[str, Any] = dict(existing)
    merged.update(data)
    await _apply_ventilation_hook(cr_id=existing["cr_id"], payload=merged)
    # Reporter dans ``data`` uniquement les valeurs ventilation que le
    # hook a ajustées (pas écraser le reste avec les valeurs DB).
    for f in _VENTILATION_FIELDS:
        if f in data or merged.get(f) != existing.get(f):
            data[f] = merged.get(f)
    row = await run_in_thread(crp_ligne_repo.update, ligne_id, data, flip_override_balance=flip)
    if row is None:
        # Concurrent delete between the get and the update — surface
        # as 404 like the initial check would.
        raise NotFoundError(f"ligne {ligne_id} not found", code="ligne_not_found")
    return CrpLigneRead.model_validate(row)


async def delete_ligne(ligne_id: UUID, company_id: UUID) -> None:
    existing = await run_in_thread(crp_ligne_repo.get_by_id, ligne_id)
    if existing is None or str(existing["company_id"]) != str(company_id):
        raise NotFoundError(f"ligne {ligne_id} not found", code="ligne_not_found")
    await _require_cr_editable(existing["cr_id"], company_id)
    deleted = await run_in_thread(crp_ligne_repo.delete, ligne_id)
    if not deleted:
        # Race — the row vanished between the check and the delete
        raise NotFoundError(f"ligne {ligne_id} not found", code="ligne_not_found")


# ---------------------------------------------------------------------------
# Bulk upsert (Q4 — manual route)
# ---------------------------------------------------------------------------


async def bulk_upsert(
    cr_id: UUID, company_id: UUID, items: list[BulkUpsertItem]
) -> list[CrpLigneRead]:
    """Manual ``:bulk-upsert``. ``binding_id`` is left None — this is
    cabinet-driven saisie, not a prefill (see
    :mod:`crp_prefill_service` for the binding-sourced path).

    Freeze §S : 409 si document parent hors brouillon."""
    await _require_cr_editable(cr_id, company_id)
    for item in items:
        await _warn_unknown_compte(item.compte_m22bis)
    payload_dicts = [item.model_dump(exclude_unset=False) for item in items]

    # §Y — batch auto-ventilation pour les lignes sans saisie H/D/S/SEA.
    ctx = await run_in_thread(cr_repo.get_ventilation_context, cr_id)
    if ctx is not None:
        ventilation_type = ctx["ventilation"]
        etablissement_id = ctx["etablissement_id"]
        exercice_annee = int(ctx["exercice_annee"])

        # Construire la liste pour le batch en n'envoyant que les
        # candidats à l'auto-ventilation (charge + 4 cols None + basis).
        batch_items: list[dict] = []
        batch_indices: list[int] = []
        for idx, item in enumerate(payload_dicts):
            basis = ventilation_service.extract_basis_amount(item)
            if (
                item.get("nature") == "charge"
                and all(item.get(f) is None for f in _VENTILATION_FIELDS)
                and basis is not None
            ):
                batch_items.append(
                    {
                        "compte_m22bis": item.get("compte_m22bis"),
                        "montant_basis": basis,
                    }
                )
                batch_indices.append(idx)

        if batch_items and etablissement_id is not None:
            results = await ventilation_service.batch_apply_default_ventilation(
                items=batch_items,
                etablissement_id=etablissement_id,
                exercice_annee=exercice_annee,
                ventilation_type=ventilation_type,
            )
            for offset, idx in enumerate(batch_indices):
                ventilation = results[offset]
                if ventilation is not None:
                    payload_dicts[idx]["montant_hebergement"] = ventilation["hebergement"]
                    payload_dicts[idx]["montant_dependance"] = ventilation["dependance"]
                    payload_dicts[idx]["montant_soins"] = ventilation["soins"]
                    payload_dicts[idx]["montant_soins_autonomie"] = ventilation["soins_autonomie"]

        # Validation Σ + SEA conditionnel sur toutes les lignes (auto +
        # saisies explicites). 1 ligne KO → 422 sur le batch entier.
        for item in payload_dicts:
            basis = ventilation_service.extract_basis_amount(item)
            await ventilation_service.validate_explicit_ventilation(
                montant_basis=basis,
                montant_hebergement=_dec_or_none(item.get("montant_hebergement")),
                montant_dependance=_dec_or_none(item.get("montant_dependance")),
                montant_soins=_dec_or_none(item.get("montant_soins")),
                montant_soins_autonomie=_dec_or_none(item.get("montant_soins_autonomie")),
                ventilation_type=ventilation_type,
                etablissement_id=etablissement_id,
            )

    rows = await run_in_thread(
        crp_ligne_repo.bulk_upsert,
        company_id=company_id,
        cr_id=cr_id,
        items=payload_dicts,
        binding_id=None,
    )
    return [CrpLigneRead.model_validate(r) for r in rows]


# ---------------------------------------------------------------------------
# §Y — apply default ventilation on a whole CR (after import balance)
# ---------------------------------------------------------------------------


async def apply_default_ventilation_to_cr(cr_id: UUID, company_id: UUID) -> dict[str, int]:
    """Endpoint :apply-default-ventilation — recalcule la ventilation
    pour toutes les charges du CR dont les 4 cols H/D/S/SEA sont None.

    Retourne un compteur ``{lignes_ventilees, lignes_skipees_manuelles,
    lignes_sans_regle, total_lignes_evaluees}`` pour reporter au caller.

    Pas d'écrasement de saisie : si le cabinet a posé une ventilation
    manuelle, on la respecte. Pas d'écrasement de produits non plus.
    """
    await _require_cr_editable(cr_id, company_id)
    ctx = await run_in_thread(cr_repo.get_ventilation_context, cr_id)
    if ctx is None:
        raise NotFoundError(f"CR {cr_id} not found", code="cr_not_found")
    ventilation_type = ctx["ventilation"]
    etablissement_id = ctx["etablissement_id"]
    exercice_annee = int(ctx["exercice_annee"])

    if ventilation_type not in {"ternaire_hds", "ternaire_hdsea"}:
        # No-op : le CR n'est pas ternaire → aucune ligne à ventiler.
        return {
            "lignes_ventilees": 0,
            "lignes_skipees_manuelles": 0,
            "lignes_sans_regle": 0,
            "total_lignes_evaluees": 0,
        }
    if etablissement_id is None:
        # CR sans ETS (CRP_SF section financière) — aucune clé n'a de
        # sens sans ETS référencé.
        return {
            "lignes_ventilees": 0,
            "lignes_skipees_manuelles": 0,
            "lignes_sans_regle": 0,
            "total_lignes_evaluees": 0,
        }

    rows = await run_in_thread(crp_ligne_repo.list_by_cr, cr_id, groupe=None, nature="charge")
    ventilees = 0
    skipees_manuelles = 0
    sans_regle = 0

    # Préparer le batch en filtrant les lignes éligibles.
    batch_items: list[dict] = []
    batch_ligne_ids: list[UUID] = []
    for row in rows:
        already_ventilated = any(row.get(f) is not None for f in _VENTILATION_FIELDS)
        basis = ventilation_service.extract_basis_amount(row)
        if already_ventilated:
            skipees_manuelles += 1
            continue
        if basis is None:
            sans_regle += 1
            continue
        batch_items.append({"compte_m22bis": row["compte_m22bis"], "montant_basis": basis})
        batch_ligne_ids.append(row["id"])

    if batch_items:
        results = await ventilation_service.batch_apply_default_ventilation(
            items=batch_items,
            etablissement_id=etablissement_id,
            exercice_annee=exercice_annee,
            ventilation_type=ventilation_type,
        )
        for ligne_id, ventilation in zip(batch_ligne_ids, results, strict=True):
            if ventilation is None:
                sans_regle += 1
                continue
            await run_in_thread(
                crp_ligne_repo.update,
                ligne_id,
                {
                    "montant_hebergement": ventilation["hebergement"],
                    "montant_dependance": ventilation["dependance"],
                    "montant_soins": ventilation["soins"],
                    "montant_soins_autonomie": ventilation["soins_autonomie"],
                },
                flip_override_balance=False,
            )
            ventilees += 1

    return {
        "lignes_ventilees": ventilees,
        "lignes_skipees_manuelles": skipees_manuelles,
        "lignes_sans_regle": sans_regle,
        "total_lignes_evaluees": len(rows),
    }


# ---------------------------------------------------------------------------
# Totals (Q5)
# ---------------------------------------------------------------------------


def _empty_pair() -> CrpTotalsColumnPair:
    return CrpTotalsColumnPair(previsions_totales=_ZERO, realise=_ZERO)


def _empty_groupe() -> CrpTotalsGroupe:
    return CrpTotalsGroupe(charges=_empty_pair(), produits=_empty_pair())


def _add_pair(a: CrpTotalsColumnPair, b: CrpTotalsColumnPair) -> CrpTotalsColumnPair:
    return CrpTotalsColumnPair(
        previsions_totales=a.previsions_totales + b.previsions_totales,
        realise=a.realise + b.realise,
    )


async def totals(cr_id: UUID, company_id: UUID) -> CrpTotalsResponse:
    """Aggregate ``previsions_totales`` + ``realise`` by groupe ×
    nature, then pivot to the flat :class:`CrpTotalsResponse` shape.

    R.314-222 equilibrium validation (5 conditions, D-016 + D-034) is
    **not** done here — only the brut ``ecart = produits - charges``
    is returned. ``is_equilibre_required`` is derived from
    ``cr.cr_variante`` so the UI can colour the ecart red when the
    CR is ``soumis_equilibre`` and ecart is negative."""
    await _require_cr(cr_id, company_id)
    ctx = await run_in_thread(crp_ligne_repo.get_cr_context, cr_id)
    if ctx is None:
        # Should not happen — _require_cr already passed, but guard for race
        raise NotFoundError(f"cr {cr_id} not found", code="cr_not_found")

    rows = await run_in_thread(crp_ligne_repo.totals_by_groupe, cr_id)
    by_groupe: dict[str, CrpTotalsGroupe] = {g: _empty_groupe() for g in ("G1", "G2", "G3")}
    for row in rows:
        groupe = row["groupe"]
        if groupe not in by_groupe:
            continue
        pair = CrpTotalsColumnPair(
            previsions_totales=row["previsions_totales"],
            realise=row["realise"],
        )
        if row["nature"] == "charge":
            by_groupe[groupe] = CrpTotalsGroupe(charges=pair, produits=by_groupe[groupe].produits)
        else:
            by_groupe[groupe] = CrpTotalsGroupe(charges=by_groupe[groupe].charges, produits=pair)

    total_charges = _empty_pair()
    total_produits = _empty_pair()
    for groupe in by_groupe.values():
        total_charges = _add_pair(total_charges, groupe.charges)
        total_produits = _add_pair(total_produits, groupe.produits)

    is_equilibre_required = ctx["cr_variante"] == "soumis_equilibre"
    ecart = CrpEcart(
        previsions_totales=total_produits.previsions_totales - total_charges.previsions_totales,
        realise=total_produits.realise - total_charges.realise,
        is_equilibre_required=is_equilibre_required,
    )

    return CrpTotalsResponse(
        cr_id=cr_id,
        cr_variante=ctx["cr_variante"],
        by_groupe=by_groupe,  # type: ignore[arg-type]
        total_charges=total_charges,
        total_produits=total_produits,
        ecart=ecart,
    )


# Surface mute for unused imports — Any kept for repo signatures
_ = Any
