"""Règles dures de ventilation H/D/S (§Y D-055, KB20 §8.1).

Helpers purs sans IO — appelés depuis ``ventilation_service`` pour
résoudre la section d'imputation par défaut d'un compte M22Bis.

Mapping DGCS exhaustif (KB20 §8.1 + D-055) :

* **65***  → Hébergement 100% (charges administration générale, aide #13)
* **66***  → Soins 100% (intérêts emprunts, D.314-205)
* **6021*** → Soins (charges pharmaceutiques)
* **62113*** → Soins (personnel médical/paramédical extérieur)
* **6288*** → Soins (pharmacie logistique, aide #11)
* **602261*** → Dépendance (couches, alèses)

Les autres comptes (60222, 60226, etc.) ne sont **pas** ventilés par
règle dure — c'est la table ``cles_repartition_charges_communes`` qui
prend le relais (D-057, KB20 §8.2 "clé gestionnaire").

Les libellés des sections matchent exactement le nom des colonnes
``crp_lignes.montant_<section>`` — c'est volontaire pour que les
appelants puissent faire directement ``ligne[f"montant_{section}"] =
montant_total`` sans table de traduction.
"""

from __future__ import annotations

from typing import Final, Literal

VentilationSection = Literal["hebergement", "dependance", "soins", "soins_autonomie"]
"""Sections H/D/S/SEA — alignées sur ``crp_lignes.montant_*``."""


# Préfixes "exacts" — match avec ``startswith``. L'ordre n'a pas
# d'importance car les préfixes sont disjoints (aucun n'est préfixe d'un
# autre dans cette liste). Si on ajoute "602" plus tard, attention aux
# conflits avec "602261" qui est plus spécifique.
_RULES_PREFIX: Final[tuple[tuple[str, VentilationSection], ...]] = (
    # Comptes très spécifiques d'abord (priorité plus longue préfixe).
    ("602261", "dependance"),  # Couches, alèses
    ("62113", "soins"),  # Personnel médical/paramédical extérieur
    ("6288", "soins"),  # Pharmacie logistique
    ("6021", "soins"),  # Charges pharmaceutiques
    # Familles entières — D-055 dur.
    ("65", "hebergement"),  # Administration générale (aide #13)
    ("66", "soins"),  # Intérêts emprunts (D.314-205)
)


def resolve_section_dure(compte_m22bis: str) -> VentilationSection | None:
    """Retourne la section d'imputation 100% si le compte est régi par
    une **règle dure D-055**, sinon ``None``.

    Match par prefix le plus long en premier (table ``_RULES_PREFIX``
    triée).
    """
    if not compte_m22bis:
        return None
    code = compte_m22bis.strip()
    for prefix, section in _RULES_PREFIX:
        if code.startswith(prefix):
            return section
    return None


def list_hard_rules() -> list[tuple[str, VentilationSection]]:
    """Retourne la liste exhaustive des règles dures sous forme
    sérialisable. Helper exposé pour la documentation / le frontend
    (affichage "Comptes auto-imputés" en read-only).
    """
    return list(_RULES_PREFIX)
