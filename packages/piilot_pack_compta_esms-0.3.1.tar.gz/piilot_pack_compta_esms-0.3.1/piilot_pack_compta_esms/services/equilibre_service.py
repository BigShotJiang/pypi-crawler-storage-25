"""§BD v0.3 — Equilibre R.314-222 applicator (D-034).

Service applicateur qui orchestre les pure validators de
:mod:`finance.equilibre_validator` (déjà présents v0.2) :

* :func:`compute_equilibre_applicable` — dispatcher per-ETS qui
  retourne ``Literal['REEL', 'STRICT', 'NON_APPLICABLE']`` selon
  ``nature_juridique × inclusion CPOM`` pour un exercice donné.
* :func:`load_equilibre_strict_inputs` — agrège ``crp_lignes`` du
  document (produits vs charges, prévisionnel ou réalisé selon
  ``type_document``).
* :func:`load_equilibre_reel_inputs` — pré-remplit
  :class:`EquilibreReelInput` à partir des données disponibles
  (C1 via §BB ``tarifs_service.build_validation_report``, C2-C5 en
  ``None`` car les inputs vivent dans des annexes pas encore câblées
  en v0.3 — TF §M, CAF §I.4, emprunts §N, affectations §J).
* :func:`apply_equilibre_check_for_document` — calcule le verdict et
  écrit ``equilibre_atteint_o_n`` sur le document (D-034 hook).

Le hook ``workflow_service.transition transmit`` (§S) consomme cette
fonction après les bloquants §Z ; un verdict ``NON`` bloque la
transition côté caller (D-034 "bloque tant que tout n'est pas évalué").
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Literal
from uuid import UUID

from piilot.sdk.db import cursor, run_in_thread

from piilot_pack_compta_esms.models.finance import (
    EquilibreReelInput,
    EquilibreReelResult,
    EquilibreStrictInput,
    EquilibreStrictResult,
    NatureJuridique,
)
from piilot_pack_compta_esms.repositories import (
    etablissement_repo,
    og_repo,
)
from piilot_pack_compta_esms.services import cpom_service, tarifs_service
from piilot_pack_compta_esms.services.errors import (
    NotFoundError,
    ValidationError,
)
from piilot_pack_compta_esms.services.finance import equilibre_validator

_logger = logging.getLogger(__name__)


# --------------------------------------------------------------------
# Public Literal — exposé aux callers (UPPER conforme spec D-016)
# --------------------------------------------------------------------

EquilibreApplicable = Literal["REEL", "STRICT", "NON_APPLICABLE"]
"""3 modes possibles côté API publique (KB B.7 + D-034). v0.2 utilisait
``reel`` / ``strict`` lowercase via ``EquilibreType`` — v0.3 introduit
``NON_APPLICABLE`` pour PRIVE_COMMERCIAL hors CPOM et aligne sur UPPER."""

# Types de documents qui font l'objet du check équilibre (D-034).
# ERRD/ERCP/AVENANT sont rétrospectifs ou modificatifs — l'équilibre
# y est figé par affectation §J et n'a pas à être re-vérifié à transit.
_EQUILIBRE_APPLICABLE_TYPES: frozenset[str] = frozenset({"eprd", "epcp", "dm", "ria"})


# --------------------------------------------------------------------
# compute_equilibre_applicable — dispatcher per-ETS
# --------------------------------------------------------------------


def _dispatch_equilibre(
    nature_juridique: NatureJuridique,
    inclus_dans_cpom: bool,
) -> EquilibreApplicable:
    """Pure helper — règle DGCS S03 p.29 + 05-workflows §équilibre.

    * PRIVE_COMMERCIAL hors CPOM → NON_APPLICABLE (pas d'obligation).
    * Inclus CPOM (toutes natures) → REEL (5 conditions R.314-222).
    * Hors CPOM (public / non lucratif) → STRICT (recettes==dépenses).
    """
    if nature_juridique == "PRIVE_COMMERCIAL" and not inclus_dans_cpom:
        return "NON_APPLICABLE"
    if inclus_dans_cpom:
        return "REEL"
    return "STRICT"


async def compute_equilibre_applicable(
    etablissement_id: UUID,
    exercice_annee: int,
) -> EquilibreApplicable:
    """Per-ETS dispatcher selon ``nature_juridique × CPOM inclusion``.

    Consommé par §BB (annotation côté tarifs_proposes), §BC
    (calcul initial à la création EPRD), §BH (workflow EPRD ARS/CD)
    et toute logique métier qui veut savoir quel équilibre s'applique
    à un ETS pour un exercice donné.

    Raises :class:`NotFoundError` si l'ETS ou son OG n'existe pas.
    """
    ets = await run_in_thread(etablissement_repo.get_by_id, etablissement_id)
    if ets is None:
        raise NotFoundError(
            f"Établissement {etablissement_id} not found",
            code="ets_not_found",
        )
    og = await run_in_thread(og_repo.get_by_id, ets["og_id"])
    if og is None:
        # Defensive — le FK ets.og_id devrait garantir.
        raise NotFoundError(
            f"OG {ets['og_id']} not found for ETS {etablissement_id}",
            code="og_not_found",
        )
    in_cpom = await cpom_service.is_etablissement_in_cpom(etablissement_id, exercice_annee)
    return _dispatch_equilibre(og["nature_juridique"], in_cpom)


# --------------------------------------------------------------------
# load_equilibre_strict_inputs — aggregate crp_lignes
# --------------------------------------------------------------------


def _query_strict_aggregates(document_id: UUID) -> dict[str, Decimal]:
    """SQL helper — SUM produits vs charges sur les ``crp_lignes`` du doc.

    Sélection de la colonne montant selon le type de document :
    * EPRD / EPCP / DM / RIA → ``montant_previsions_totales`` (prévisionnel)
    * ERRD / ERCP / AVENANT  → ``montant_realise`` (réalisé)

    Retourne ``{"total_recettes": Decimal, "total_depenses": Decimal,
    "rows_count": int}``. Si aucun ligne, totaux à 0.
    """
    with cursor() as cur:
        cur.execute(
            """
            SELECT
                l.nature,
                COALESCE(SUM(CASE
                    WHEN d.type_document IN ('eprd', 'epcp', 'dm', 'ria')
                        THEN l.montant_previsions_totales
                    ELSE l.montant_realise
                END), 0) AS total,
                COUNT(*) AS rows_count
            FROM compta_esms.documents_budgetaires d
            JOIN compta_esms.comptes_resultat cr ON cr.document_id = d.id
            JOIN compta_esms.crp_lignes l ON l.cr_id = cr.id
            WHERE d.id = %s
            GROUP BY l.nature
            """,
            (str(document_id),),
        )
        rows = cur.fetchall()

    out = {
        "total_recettes": Decimal("0"),
        "total_depenses": Decimal("0"),
        "rows_count": 0,
    }
    for row in rows:
        total = Decimal(str(row["total"] or "0"))
        out["rows_count"] += int(row["rows_count"])
        if row["nature"] == "produit":
            out["total_recettes"] = total
        elif row["nature"] == "charge":
            out["total_depenses"] = total
    return out


async def load_equilibre_strict_inputs(
    document_id: UUID,
) -> EquilibreStrictInput:
    """Charge l'input strict (SUM produits / SUM charges).

    Retourne ``EquilibreStrictInput(total_recettes=0, total_depenses=0)``
    pour un document sans lignes (laisse le validator décider — `equilibre
    = True` car 0 == 0 dans la tolérance).
    """
    aggregates = await run_in_thread(_query_strict_aggregates, document_id)
    return EquilibreStrictInput(
        total_recettes=aggregates["total_recettes"],
        total_depenses=aggregates["total_depenses"],
    )


# --------------------------------------------------------------------
# load_equilibre_reel_inputs — C1 disponible, C2-C5 best-effort
# --------------------------------------------------------------------


async def load_equilibre_reel_inputs(
    company_id: UUID,
    document_id: UUID,
) -> EquilibreReelInput:
    """Pré-remplit l'input des 5 conditions R.314-222.

    En v0.3 §BD :
    * **C1** est câblée via §BB ``tarifs_service.build_validation_report`` :
      SUM ``montant_propose`` (= ``produits_tarif_saisis``) et SUM
      ``montant_notifie`` (= ``produits_tarif_notifies``) sur l'ensemble
      des sections. Si aucune row ``eprd_tarifs_proposes`` n'existe encore
      pour le doc, on laisse ``None`` (le validator marque
      ``evaluable=False``).
    * **C2-C5** sont laissées ``None`` — leurs inputs vivent dans des
      tables / services pas encore câblés en v0.3 :
        - C2 sincérité — saisie qualitative cabinet (v0.4+)
        - C3 capital remboursé via emprunt — TF §M (v0.4)
        - C4 CAF / IAF — §I.4 calculator existe, mais l'agrégation
          per-document n'a pas de hook v0.3
        - C5 recettes affectées — ``affectations_resultats`` §J existe,
          le matching avec les usages réels demande §K Bilan
    * Conséquence : ``EquilibreReelResult.evaluable_globalement`` reste
      ``False`` v0.3, ce qui bloque la transition transmit (D-034 :
      "bloque tant que tout n'est pas évalué"). Le cabinet doit
      finir les saisies — c'est conservateur et conforme à la spec.

    Le service est best-effort : si tarifs_service échoue (doc sans
    tarifs ou type non-supporté), on retourne un input vide plutôt
    que de propager l'erreur.
    """
    inputs = EquilibreReelInput()

    # C1 — via tarifs_proposes report (§BB)
    try:
        report = await tarifs_service.build_validation_report(company_id, document_id)
        # On agrège total_propose et total_notifie sur toutes les sections.
        # Si **toutes** les sections ont un montant_notifie, on peut
        # produire la condition C1 ; sinon on laisse None pour éviter un
        # faux positif (validator marquera evaluable=False).
        if report.total_rows > 0 and all(s.total_notifie is not None for s in report.sections):
            total_saisis = sum((s.total_propose for s in report.sections), start=Decimal("0"))
            total_notifies = sum(
                (s.total_notifie for s in report.sections),  # type: ignore[misc]
                start=Decimal("0"),
            )
            inputs = inputs.model_copy(
                update={
                    "produits_tarif_saisis": total_saisis,
                    "produits_tarif_notifies": total_notifies,
                }
            )
    except (NotFoundError, ValidationError) as exc:
        # Document sans tarifs proposés ou type incompatible — C1 reste
        # non-évaluable, ce qui fait sens (cabinet n'a pas saisi les
        # tarifs).
        _logger.debug("C1 inputs not loaded for doc %s: %s", document_id, exc)

    # C2-C5 — non câblées en v0.3, restent None.
    return inputs


# --------------------------------------------------------------------
# apply_equilibre_check_for_document — orchestrateur + side effect
# --------------------------------------------------------------------


def _update_equilibre_atteint(
    document_id: UUID, verdict: Literal["OUI", "NON", "NON_APPLICABLE"]
) -> None:
    """Persiste le verdict sur ``documents_budgetaires.equilibre_atteint_o_n``."""
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.documents_budgetaires "
            "SET equilibre_atteint_o_n = %s, updated_at = now() "
            "WHERE id = %s",
            (verdict, str(document_id)),
        )


def _query_doc_context_for_equilibre(
    document_id: UUID,
) -> dict[str, Any] | None:
    """Charge ``{type_document, nature_juridique, any_inclus_cpom}`` du doc.

    Variant simplifié de :func:`workflow_repo.load_equilibre_context` —
    on ne lie pas la query au workflow_repo pour éviter le couplage
    circulaire (equilibre_service est appelé par workflow_service).
    """
    with cursor() as cur:
        cur.execute(
            "SELECT d.type_document, "
            "       og.nature_juridique, "
            "       COALESCE(BOOL_OR(ets.inclus_cpom), false) AS any_inclus_cpom "
            "FROM compta_esms.documents_budgetaires d "
            "JOIN compta_esms.exercices ex ON ex.id = d.exercice_id "
            "JOIN compta_esms.organismes_gestionnaires og ON og.id = ex.og_id "
            "LEFT JOIN compta_esms.etablissements ets ON ets.og_id = og.id "
            "WHERE d.id = %s "
            "GROUP BY d.type_document, og.nature_juridique",
            (str(document_id),),
        )
        row = cur.fetchone()
    if row is None:
        return None
    return {
        "type_document": row["type_document"],
        "nature_juridique": row["nature_juridique"],
        "any_inclus_cpom": bool(row["any_inclus_cpom"]),
    }


class EquilibreCheckResult:
    """Résultat de :func:`apply_equilibre_check_for_document`.

    Pas un BaseModel — simple struct interne. Le hook
    ``workflow_service.transition transmit`` lit ``mode`` et ``verdict``
    pour décider de bloquer ou non.
    """

    __slots__ = ("mode", "verdict", "details")

    def __init__(
        self,
        mode: EquilibreApplicable,
        verdict: Literal["OUI", "NON", "NON_APPLICABLE"],
        details: EquilibreReelResult | EquilibreStrictResult | None = None,
    ) -> None:
        self.mode = mode
        self.verdict = verdict
        self.details = details


async def apply_equilibre_check_for_document(
    company_id: UUID,
    document_id: UUID,
) -> EquilibreCheckResult:
    """Calcule le verdict d'équilibre du document et persiste sur
    ``equilibre_atteint_o_n``.

    Décision :
    1. Si le doc n'est pas un type EPRD-class → return REEL/NON_APPLICABLE
       sans toucher la colonne (ERRD/ERCP/AVENANT — équilibre figé
       par §J affectation, hors scope §BD).
    2. Dispatcher document-level via ``_dispatch_equilibre(nature, any_inclus_cpom)``.
    3. Si NON_APPLICABLE → update ``NON_APPLICABLE`` + return.
    4. Si STRICT → load_strict_inputs + validate_equilibre_strict.
       Update ``OUI`` ou ``NON`` selon le verdict.
    5. Si REEL → load_reel_inputs + validate_equilibre_reel. Update
       ``OUI`` ssi ``evaluable_globalement AND equilibre`` (D-034) ;
       sinon ``NON``.

    Le caller (hook transmit) consomme ``verdict`` pour décider de
    bloquer la transition.

    Raises :class:`NotFoundError` si le document n'existe pas.
    """
    ctx = await run_in_thread(_query_doc_context_for_equilibre, document_id)
    if ctx is None:
        raise NotFoundError(f"Document {document_id} not found", code="document_not_found")

    # Hors scope §BD : ERRD/ERCP/AVENANT ne sont pas re-checkés.
    if ctx["type_document"] not in _EQUILIBRE_APPLICABLE_TYPES:
        return EquilibreCheckResult(mode="NON_APPLICABLE", verdict="NON_APPLICABLE")

    mode = _dispatch_equilibre(ctx["nature_juridique"], ctx["any_inclus_cpom"])

    if mode == "NON_APPLICABLE":
        await run_in_thread(_update_equilibre_atteint, document_id, "NON_APPLICABLE")
        return EquilibreCheckResult(mode=mode, verdict="NON_APPLICABLE")

    if mode == "STRICT":
        strict_inputs = await load_equilibre_strict_inputs(document_id)
        strict_result = equilibre_validator.validate_equilibre_strict(strict_inputs)
        verdict: Literal["OUI", "NON", "NON_APPLICABLE"] = (
            "OUI" if strict_result.equilibre else "NON"
        )
        await run_in_thread(_update_equilibre_atteint, document_id, verdict)
        return EquilibreCheckResult(mode=mode, verdict=verdict, details=strict_result)

    # mode == "REEL"
    reel_inputs = await load_equilibre_reel_inputs(company_id, document_id)
    reel_result = equilibre_validator.validate_equilibre_reel(reel_inputs)
    # D-034 : "bloque tant que tout n'est pas évalué" → un input partiel
    # (evaluable_globalement=False) compte comme NON.
    reel_verdict: Literal["OUI", "NON", "NON_APPLICABLE"] = (
        "OUI" if (reel_result.evaluable_globalement and reel_result.equilibre) else "NON"
    )
    await run_in_thread(_update_equilibre_atteint, document_id, reel_verdict)
    return EquilibreCheckResult(mode=mode, verdict=reel_verdict, details=reel_result)


__all__ = [
    "EquilibreApplicable",
    "EquilibreCheckResult",
    "_dispatch_equilibre",
    "compute_equilibre_applicable",
    "load_equilibre_strict_inputs",
    "load_equilibre_reel_inputs",
    "apply_equilibre_check_for_document",
]
