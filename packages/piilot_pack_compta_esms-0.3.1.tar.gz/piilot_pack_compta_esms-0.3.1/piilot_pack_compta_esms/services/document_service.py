"""Service layer for Documents budgétaires (L2 §4).

Business rules at this layer :

* **Parent-child consistency** — DM/RIA require an EPRD parent in the
  same company ; the parent type and tenant are verified before insert.
* **Default cadre_version** — auto-derived from ``(type, annee)`` of
  the linked exercice when the body omits it. Cabinet can override.
* **Auto-CRPP at create** — D-073. The repo wraps both INSERTs in one
  transaction ; the service supplies the CRPP denomination/variante.
* **EPRD structural CRPA pre-fill** — §BC.6 D-037. Pour les EPRD, après
  le CRPP par défaut, le hook ``_prefill_eprd_structural_crpas`` consomme
  :func:`eprd_structure_service.compute_eprd_structure` et pré-crée les
  CRPA structurels selon ``nature_juridique`` de l'OG.
* **Hard delete brouillon-only** — 409 if the document is already
  ``transmis`` / ``executoire`` / etc. The cabinet must use a workflow
  transition (§X) to roll back instead.
* **Clone** — new_type ∈ {dm,ria}, parent must be an EPRD owned by
  the caller's company, the clone is a fresh ``brouillon`` with the
  parent_id wired up. The clone gets its own auto-CRPP via the same
  ``create_with_default_crpp`` path — sub-table copy (CRs, lignes)
  arrives in §E.4 / §H once those tables ship.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.document import (
    ALLOWED_PARENT_TYPES,
    PARENT_REQUIRED,
    DocumentClone,
    DocumentCreate,
    DocumentRead,
    DocumentUpdate,
)
from piilot_pack_compta_esms.repositories import cr_repo, document_repo, og_repo
from piilot_pack_compta_esms.services import (
    audit_service,
    document_freeze,
    eprd_structure_service,
    rapport_sections_service,
)
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
    ValidationError,
)

_logger = logging.getLogger(__name__)

# Cadre code prefix per document type — DGCS naming convention.
# Pattern : ``#<PREFIX>-{annee_ref}-01#``.
# ``annee_ref`` is the budget year for EPRD/DM/RIA/EPCP/AVENANT and
# the previous year for ERRD/ERCP (those are executed-year reports).
#
# **Suffixe HA vs SA** (KB22 §5) :
# * **HA** (Harmonisé) — ESMS hors EPS (EPRD/ERRD/DM/RIA/AVENANT).
# * **SA** (SAnitaire) — ESMS rattachés à EPS (ERCP/EPCP), cadres
#   distincts DGCS — `#ERRDSA-2022-01#` et `#EPRDSA-2023-01#`. Les
#   millésimes DGCS ne suivent pas l'année courante : ils sont gelés
#   sur le millésime de l'arrêté (2022/2023). Le cabinet peut toujours
#   override via le body.
_CADRE_PREFIX: dict[str, str] = {
    "eprd": "EPRDHA",
    "errd": "ERRDHA",
    "dm": "DMHA",
    "ria": "RIAHA",
    "ercp": "ERRDSA",  # KB22 §5 — cadre sanitaire 2022 (sous-cadre ERRD)
    "epcp": "EPRDSA",  # KB22 §5 — cadre sanitaire 2023 (sous-cadre EPRD)
    "avenant": "AVENANTHA",
}
_PREVIOUS_YEAR_TYPES: frozenset[str] = frozenset({"errd", "ercp"})

# Millésimes figés DGCS pour les cadres SA (KB22 §5). Quand un caller
# ne fournit pas ``cadre_version`` explicitement, on construit le code
# à partir de ces millésimes — pas de l'``annee`` du document.
_SA_FROZEN_MILLESIME: dict[str, int] = {
    "ercp": 2022,
    "epcp": 2023,
}


def _default_cadre(type_document: str, annee: int) -> str:
    """Build the default ``cadre_version`` for ``(type, annee)``.

    The cabinet can override via the request body — useful for
    transitional periods where DGCS publishes a corrected cadre.

    Pour ERCP/EPCP : le millésime du cadre est figé (2022/2023, KB22
    §5), pas l'``annee`` de l'exercice — c'est la version officielle
    DGCS de l'arrêté qui prime."""
    prefix = _CADRE_PREFIX[type_document]
    if type_document in _SA_FROZEN_MILLESIME:
        annee_ref = _SA_FROZEN_MILLESIME[type_document]
    else:
        annee_ref = annee - 1 if type_document in _PREVIOUS_YEAR_TYPES else annee
    return f"#{prefix}-{annee_ref}-01#"


def _is_eps_only_type(type_document: str) -> bool:
    """ERCP/EPCP — réservés aux EPS (D-060 + KB22 §1)."""
    return type_document in {"ercp", "epcp"}


def _default_crpp_denomination(type_document: str, annee: int) -> str:
    """Auto-CRPP denomination — user-editable via PATCH on the CR."""
    return f"CRPP - {type_document.upper()} {annee}"


def _to_read(row: dict[str, Any]) -> DocumentRead:
    return DocumentRead.model_validate(row)


async def list_documents(
    company_id: UUID,
    *,
    type_document: str | None = None,
    statut: str | None = None,
    annee: int | None = None,
    og_id: UUID | None = None,
) -> list[DocumentRead]:
    """Filter-aware listing. Most recent ``created_at`` first."""
    rows = await run_in_thread(
        document_repo.list_documents,
        company_id,
        type_document=type_document,
        statut=statut,
        annee=annee,
        og_id=og_id,
    )
    return [_to_read(r) for r in rows]


async def get_document(doc_id: UUID) -> DocumentRead:
    """Fetch a single document. 404 if missing / cross-tenant."""
    row = await run_in_thread(document_repo.get_by_id, doc_id)
    if row is None:
        raise NotFoundError(f"Document {doc_id} not found", code="document_not_found")
    return _to_read(row)


async def create_document(company_id: UUID, payload: DocumentCreate) -> DocumentRead:
    """Create a new document. Auto-CRPP (D-073) **sauf** ERCP/EPCP.

    Validates :
    1. The exercice exists and is owned by the caller's company
       (404 otherwise — don't leak cross-tenant existence).
    2. For DM/RIA : the ``parent_id`` references an EPRD in the same
       company. Wrong-type parent → 422-style ConflictError.
    3. **§X (D-060 + KB22 §1)** — pour ERCP/EPCP : l'OG sous-jacent
       doit avoir ``nature_juridique='ETABLISSEMENT_PUBLIC_SANTE'``.
       Sinon 422 ``eps_required_for_ercp_epcp``.
    4. Body fields conform to :class:`DocumentCreate` cross-field rules
       (parent required/forbidden, RIA periode consistency) — those
       are checked at parse time by the model validators.

    Pour ERCP/EPCP : pas d'auto-CRPP (D-060 — ces documents n'ont que
    des CRPs ANNEXE, le CRPP sanitaire est dans l'EPRD EPS global).
    Le cabinet créera explicitement ses CRPA/CRA_SF/CRP_SF via §E.4.
    """
    exercice = await run_in_thread(document_repo.exercice_lookup, payload.exercice_id)
    if exercice is None or str(exercice["company_id"]) != str(company_id):
        raise NotFoundError(
            f"Exercice {payload.exercice_id} not found",
            code="exercice_not_found_for_document_create",
        )

    if payload.parent_id is not None:
        parent = await run_in_thread(document_repo.load_parent_for_clone, payload.parent_id)
        if parent is None or str(parent["company_id"]) != str(company_id):
            raise NotFoundError(
                f"Parent document {payload.parent_id} not found",
                code="parent_document_not_found",
            )
        if parent["type_document"] not in ALLOWED_PARENT_TYPES:
            raise ConflictError(
                f"Parent must be of type 'eprd', got '{parent['type_document']}'",
                code="parent_wrong_type",
            )

    # §X — ERCP/EPCP requièrent un OG de statut juridique 'eps'.
    if _is_eps_only_type(payload.type_document):
        og_row = await run_in_thread(og_repo.get_by_id, exercice["og_id"])
        if og_row is None:
            # Defensive — l'exercice référence un og_id qui doit exister.
            raise NotFoundError(
                f"OG {exercice['og_id']} not found for exercice",
                code="og_not_found_for_document_create",
            )
        if og_row["nature_juridique"] != "ETABLISSEMENT_PUBLIC_SANTE":
            raise ValidationError(
                f"ERCP/EPCP are reserved for EPS (got nature_juridique="
                f"'{og_row['nature_juridique']}'). Use EPRD/ERRD instead.",
                code="eps_required_for_ercp_epcp",
            )

    annee = int(exercice["annee"])
    cadre = payload.cadre_version or _default_cadre(payload.type_document, annee)

    # Skip auto-CRPP pour ERCP/EPCP (D-060 — pas de CRP PRINCIPAL).
    if _is_eps_only_type(payload.type_document):
        row = await run_in_thread(
            document_repo.create_without_crpp,
            company_id=company_id,
            exercice_id=payload.exercice_id,
            type_document=payload.type_document,
            cadre_version=cadre,
            parent_id=payload.parent_id,
            periode_observation_debut=payload.periode_observation_debut,
            periode_observation_fin=payload.periode_observation_fin,
        )
        return _to_read(row)

    crpp_denomination = _default_crpp_denomination(payload.type_document, annee)
    row = await run_in_thread(
        document_repo.create_with_default_crpp,
        company_id=company_id,
        exercice_id=payload.exercice_id,
        type_document=payload.type_document,
        cadre_version=cadre,
        parent_id=payload.parent_id,
        periode_observation_debut=payload.periode_observation_debut,
        periode_observation_fin=payload.periode_observation_fin,
        crpp_denomination=crpp_denomination,
        crpp_variante=payload.cr_variante,
    )

    # §BC v0.3 — Pour les EPRD, le service compute_eprd_structure pré-
    # crée les CRPA structurels (1 par ESMS rattaché). Les autres types
    # de documents (ERRD/DM/RIA/AVENANT) gardent uniquement le CRPP par
    # défaut — leurs CRPA sont créés ad hoc par §E.4 selon le besoin.
    if payload.type_document == "eprd":
        await _prefill_eprd_structural_crpas(
            company_id=company_id,
            document_id=row["id"],
            og_id=exercice["og_id"],
        )
        # §BI v0.3 — auto-matérialise la KB rapport_budgetaire_sections
        # (9 rows initiales vides) pour ce nouvel EPRD. Idempotent. Catch
        # défensif : si la matérialisation échoue (SDK indispo, KB
        # corrompue, …), le document est déjà créé et on ne veut pas
        # le perdre. Le cabinet créera les sections manuellement via UI
        # KB core si besoin.
        await _materialize_rapport_sections_kb(
            company_id=company_id,
            document_id=row["id"],
        )

    return _to_read(row)


async def _materialize_rapport_sections_kb(
    *,
    company_id: UUID,
    document_id: UUID,
) -> None:
    """§BI.3 — Auto-matérialise la KB rapport_budgetaire_sections.

    Crée la KB plugin-owned ``rapport_budgetaire_sections`` si elle
    n'existe pas encore pour cette company, puis insère 9 rows
    initiales (1 par ``section_code``, contenu vide) pour ce document.

    Defensive : on log + skip silencieusement si la matérialisation
    échoue (SDK indispo, KB corrompue, schéma désaligné, ...) — le
    document EPRD est déjà créé, on ne veut pas le perdre. Le cabinet
    pourra créer les sections plus tard via l'UI KB core générique.
    """
    try:
        result = await rapport_sections_service.materialize_for_document(
            document_id=document_id,
            company_id=company_id,
        )
    except Exception as exc:  # noqa: BLE001 — best-effort defensive
        _logger.warning(
            "Rapport sections KB materialization skipped for document %s " "(company=%s): %s",
            document_id,
            company_id,
            exc,
        )
        return
    _logger.info(
        "Rapport sections KB ready for document %s (kb=%s, inserted=%d, idempotent=%s)",
        document_id,
        result["kb_id"],
        result["rows_inserted"],
        result["was_idempotent"],
    )


async def _prefill_eprd_structural_crpas(
    *,
    company_id: UUID,
    document_id: UUID,
    og_id: UUID,
) -> None:
    """§BC.6 — Pré-création des CRPA structurels pour un EPRD.

    Délégué à :func:`eprd_structure_service.compute_eprd_structure` qui
    retourne la liste des CrpSpec selon ``nature_juridique`` de l'OG.
    Chaque CrpSpec produit un INSERT dans ``comptes_resultat`` via
    :func:`cr_repo.create`.

    Idempotent côté caller : appelé une seule fois au create. Si un
    cabinet veut ajouter / supprimer des CRPA après coup, il passe par
    §E.4.

    Erreurs : on log + skip silencieusement si la résolution de spec
    échoue pour quelque raison que ce soit (OG manquant, nature
    inconnue, échec de chargement ETS, etc.) — le document est déjà
    créé, on ne veut pas le perdre pour un échec de pré-fill. Le
    cabinet créera les CRPA manuellement via §E.4.
    """
    try:
        spec = await eprd_structure_service.compute_eprd_structure(og_id)
    except Exception as exc:  # noqa: BLE001 — best-effort defensive
        _logger.warning(
            "EPRD CRPA pre-fill skipped for document %s (og=%s): %s",
            document_id,
            og_id,
            exc,
        )
        return

    for crpa_spec in spec.crps:
        payload: dict[str, Any] = {
            "cr_type": crpa_spec.cr_type,
            "cr_variante": crpa_spec.cr_variante,
            "denomination": crpa_spec.denomination,
            "ordre": crpa_spec.ordre,
        }
        if crpa_spec.etablissement_id is not None:
            payload["etablissement_id"] = str(crpa_spec.etablissement_id)
        await run_in_thread(cr_repo.create, company_id, document_id, payload)


async def update_document(doc_id: UUID, payload: DocumentUpdate) -> DocumentRead:
    """Patch document metadata (RIA periode, cadre override). 404 if missing.

    Freeze §S : 409 ``document_not_editable`` si le doc est hors
    brouillon. On lit la valeur ``statut`` directement depuis le row
    déjà chargé (économise un SELECT)."""
    current = await run_in_thread(document_repo.get_by_id, doc_id)
    if current is None:
        raise NotFoundError(f"Document {doc_id} not found", code="document_not_found")
    document_freeze.assert_editable(current["statut"])
    row = await run_in_thread(document_repo.update, doc_id, payload.model_dump(exclude_unset=True))
    if row is None:
        raise NotFoundError(f"Document {doc_id} not found", code="document_not_found")
    return _to_read(row)


async def delete_document(company_id: UUID, doc_id: UUID) -> None:
    """Hard-delete a brouillon document.

    Refuses 409 if the document has moved past ``brouillon`` — the
    cabinet must use a workflow transition (§X) to revert state."""
    current = await run_in_thread(document_repo.get_by_id, doc_id)
    if current is None:
        raise NotFoundError(f"Document {doc_id} not found", code="document_not_found")
    if str(current["company_id"]) != str(company_id):
        raise CrossCompanyError(f"Document {doc_id} not accessible", code="document_cross_company")
    if current["statut"] != "brouillon":
        raise ConflictError(
            f"Document {doc_id} is '{current['statut']}'; only brouillon "
            "can be deleted (use a workflow transition otherwise)",
            code="document_not_brouillon",
        )
    deleted = await run_in_thread(document_repo.delete, doc_id)
    if not deleted:
        raise NotFoundError(f"Document {doc_id} not found", code="document_not_found")


async def clone_document(
    company_id: UUID,
    source_id: UUID,
    payload: DocumentClone,
    *,
    user_id: UUID | None = None,
) -> DocumentRead:
    """Clone an EPRD into a DM or RIA (L2 §4.8).

    The clone is a fresh ``brouillon`` with ``parent_id = source.id``,
    in the same exercice.

    **§V (DM, D-063 héritage immutable périmètre)** : pour
    ``new_type='dm'``, on copie **tous les CRs** du parent EPRD
    (CRPP+CRPA+CRP_SF) dans le DM clone — KB23 §2.3 "DM hérite
    automatiquement de la liste exacte d'établissements du parent".
    Les ``crp_lignes`` ne sont **pas** copiées en v0.2 (le DM démarre
    avec un cadre vide où le cabinet saisit les modifications).

    **Pour ``new_type='ria'``** : pareil — RIA hérite du périmètre EPRD
    parent (KB23 §3.2 — "applicable aux ESMS qui relèvent d'un EPRD
    complet, donc même périmètre que Annexe 1").

    Si le parent n'a aucun CR (cas dégénéré théorique), le clone est
    créé avec un auto-CRPP par défaut comme un document standard
    (fallback safe).

    Audit event ``dm.create`` / ``ria.create`` posé systématiquement
    avec payload anonymisé ``{parent_eprd_id, parent_statut,
    is_simultaneous}`` — KB23 §2.6 "dépôt simultané" : flag à True
    quand le parent n'est pas en ``executoire`` (dépôt en parallèle
    de l'EPRD initial — cas courant chez les EPS).
    """
    if payload.new_type not in PARENT_REQUIRED:
        raise ConflictError(
            f"clone new_type must be one of {sorted(PARENT_REQUIRED)}",
            code="clone_invalid_new_type",
        )

    source = await run_in_thread(document_repo.load_parent_for_clone, source_id)
    if source is None or str(source["company_id"]) != str(company_id):
        raise NotFoundError(
            f"Source document {source_id} not found",
            code="clone_source_not_found",
        )
    if source["type_document"] not in ALLOWED_PARENT_TYPES:
        raise ConflictError(
            f"Source must be 'eprd', got '{source['type_document']}'",
            code="clone_source_wrong_type",
        )

    exercice = await run_in_thread(document_repo.exercice_lookup, source["exercice_id"])
    annee = int(exercice["annee"]) if exercice else 0
    cadre = _default_cadre(payload.new_type, annee)

    # Charge les CRs du parent pour héritage périmètre (D-063).
    parent_crs = await run_in_thread(document_repo.list_crs_of_document, source_id)

    # The UNIQUE constraint (company_id, exercice_id, type_document, parent_id)
    # caps DM/RIA at one per parent EPRD ; a second clone of the same type
    # surfaces as 409 (psycopg2 UniqueViolation) — let psycopg2 raise and
    # translate at the route layer.
    if parent_crs:
        row = await run_in_thread(
            document_repo.clone_with_cr_inheritance,
            company_id=company_id,
            exercice_id=source["exercice_id"],
            type_document=payload.new_type,
            cadre_version=cadre,
            parent_id=source_id,
            periode_observation_debut=payload.periode_observation_debut,
            periode_observation_fin=payload.periode_observation_fin,
            parent_crs=parent_crs,
        )
    else:
        # Fallback dégénéré — parent sans CRs (impossible en pratique car
        # §E.3 auto-CRPP à create_document, mais defensive).
        crpp_denomination = _default_crpp_denomination(payload.new_type, annee)
        row = await run_in_thread(
            document_repo.create_with_default_crpp,
            company_id=company_id,
            exercice_id=source["exercice_id"],
            type_document=payload.new_type,
            cadre_version=cadre,
            parent_id=source_id,
            periode_observation_debut=payload.periode_observation_debut,
            periode_observation_fin=payload.periode_observation_fin,
            crpp_denomination=crpp_denomination,
            crpp_variante=payload.cr_variante,
        )

    # Audit event §V — KB23 §2.6 is_simultaneous quand parent != executoire.
    if user_id is not None:
        is_simultaneous = source["statut"] != "executoire"
        await run_in_thread(
            audit_service.record_event,
            company_id=company_id,
            user_id=user_id,
            action=f"{payload.new_type}.create",
            resource_type="document",
            resource_id=row["id"],
            payload={
                "parent_eprd_id": str(source_id),
                "parent_statut": source["statut"],
                "is_simultaneous": is_simultaneous,
                "inherited_cr_count": len(parent_crs),
            },
            document_id=row["id"],
        )

    return _to_read(row)
