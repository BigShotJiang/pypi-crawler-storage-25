"""Service layer for Exercice CRUD.

Two business rules sit at this layer (not in the model):

* **Year window** — ``annee ∈ [current_year - 1, current_year + 1]``.
  The DB CHECK enforces the same constraint, but raising it here
  yields a clean 422 instead of bouncing on a CheckViolation. The
  reference year is computed at request time so the window slides
  with the calendar — that's why this lives in code, not in a static
  Literal on the model.

* **Auto-derivation of ``millesime_m22bis``** — the DGCS publishes
  the M22Bis plan-comptable each January-February ; the millésime
  applicable during year N is ``f"{N - 1}-{N}"``. We default to this
  when the body omits ``millesime_m22bis``, but accept an explicit
  override for transitional cases (eg. retroactive correction during
  the first weeks of a new millésime).
"""

from __future__ import annotations

from datetime import date
from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.exercice import ExerciceCreate, ExerciceRead
from piilot_pack_compta_esms.repositories import exercice_repo
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)


def _to_read(row: dict[str, Any]) -> ExerciceRead:
    return ExerciceRead.model_validate(row)


def _default_millesime(annee: int) -> str:
    """Derive the M22Bis millésime applicable for budget year ``annee``."""
    return f"{annee - 1}-{annee}"


def _validate_annee_window(annee: int) -> None:
    """Reject years outside ``[today.year - 1, today.year + 1]``.

    Same constraint as the DB CHECK ; raising here yields a clean
    422 with a stable code rather than a generic CheckViolation.
    """
    current = date.today().year
    if not (current - 1 <= annee <= current + 1):
        raise ConflictError(
            f"annee {annee} outside the allowed window " f"[{current - 1}, {current + 1}] (D-104)",
            code="exercice_annee_out_of_window",
        )


async def list_exercices(og_id: UUID) -> list[ExerciceRead]:
    """Return exercices of an OG, most recent year first."""
    rows = await run_in_thread(exercice_repo.list_by_og, og_id)
    return [_to_read(r) for r in rows]


async def get_exercice(exercice_id: UUID) -> ExerciceRead:
    """Fetch a single exercice. 404 if missing or cross-tenant."""
    row = await run_in_thread(exercice_repo.get_by_id, exercice_id)
    if row is None:
        raise NotFoundError(f"Exercice {exercice_id} not found", code="exercice_not_found")
    return _to_read(row)


async def create_exercice(company_id: UUID, og_id: UUID, payload: ExerciceCreate) -> ExerciceRead:
    """Create a new exercice under the given OG.

    Validates :
    1. The OG belongs to the caller's company (404 otherwise — don't
       leak cross-tenant existence).
    2. ``annee`` is in the sliding window (422-style).
    3. No exercice already exists for ``(og_id, annee)`` (409).

    Auto-derives ``millesime_m22bis`` when the body omits it.
    """
    _validate_annee_window(payload.annee)

    og_ok = await run_in_thread(exercice_repo.og_exists_for_company, og_id, company_id)
    if not og_ok:
        raise NotFoundError(f"OG {og_id} not found", code="og_not_found_for_exercice_create")

    existing = await run_in_thread(exercice_repo.find_by_og_annee, og_id, payload.annee)
    if existing is not None:
        raise ConflictError(
            f"Exercice for OG {og_id} year {payload.annee} already exists",
            code="exercice_annee_taken",
        )

    millesime = payload.millesime_m22bis or _default_millesime(payload.annee)
    row = await run_in_thread(exercice_repo.create, company_id, og_id, payload.annee, millesime)
    return _to_read(row)
