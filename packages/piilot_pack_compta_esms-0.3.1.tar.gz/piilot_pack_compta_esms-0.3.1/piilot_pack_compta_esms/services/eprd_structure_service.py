"""§BC v0.3 — ``compute_eprd_structure`` (D-037).

Service utility qui retourne la structure attendue d'un EPRD pour un
OG donné, selon ``nature_juridique`` (KB B.1) et la liste des
établissements rattachés.

Consommé par :func:`document_service.create_document` quand
``type_document='eprd'`` : après la création du document + CRPP par
défaut, le service utilise cette spec pour pré-créer les CRPA
structurels (1 par ETS).

Logique par nature juridique (S03 p.13-14 + 05-workflows §"Cas
particuliers" + 16-annexe1-eprd-structure §14) :

* ``ETABLISSEMENT_PUBLIC_SANTE``
    EPRD géré par l'EPS lui-même. 1 CRPP sanitaire (déjà créé par
    défaut, sans ``etablissement_id`` — le cabinet binde après) +
    1 CRPA médico-social par ESMS rattaché. Annexes 4, 5, 6, 8.

* ``ESMS_PUBLIC_AUTONOME``
    1 CRPP + 1 CRPA par ESMS supplémentaire (le 1er ESMS est porté
    par le CRPP, les autres par les CRPA). Cas 1 de la spec
    (S03 p.14) : 1 OG → 1 EHPAD + 1 SSIAD → 1 EPRD avec CRPP=EHPAD
    + CRPA=SSIAD.

* ``CCAS_CIAS_COLLECTIVITE``
    2 organisations possibles (S03 p.16-17, R.314-78) : (a) 1
    budget annexe global pour les N ESMS → 1 EPRD avec 1 CRP unique ;
    (b) 1 budget annexe par ESMS → N EPRD. Le service retourne la
    variante (a) par défaut (1 CRPP, pas de CRPA — le cabinet éclate
    en plusieurs EPRD via les routes documents si nécessaire).

* ``PRIVE_NON_LUCRATIF``
    Pattern symétrique ``ESMS_PUBLIC_AUTONOME`` (CRPP + CRPA par
    ESMS supplémentaire).

* ``PRIVE_COMMERCIAL``
    EPRD simplifié — pas de CRPA structurels au-delà du CRPP par
    défaut. Annexes minimales (4 et 5 selon typologie). Le service
    retourne une liste vide de CRPA + une note cabinet.

Le service est asynchrone (pattern aligné sur le reste du plugin) et
charge les ETS via :func:`etablissement_repo.list_by_og`. Pure mapping
+ I/O minimal.
"""

from __future__ import annotations

from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.eprd_structure import (
    AnnexeSpec,
    CrpSpec,
    EprdStructureSpec,
    EquilibreApplicableInitial,
)
from piilot_pack_compta_esms.models.og import NatureJuridique
from piilot_pack_compta_esms.repositories import etablissement_repo, og_repo
from piilot_pack_compta_esms.services.errors import (
    NotFoundError,
    ValidationError,
)

# --------------------------------------------------------------------
# Annexes attendues par nature (réf. 16-annexe1-eprd-structure §14)
# --------------------------------------------------------------------


_ANNEXES_FULL: list[AnnexeSpec] = [
    AnnexeSpec(
        code="4",
        obligatoire=True,
        description="Activité GIR (R.314-219) — détail par section",
    ),
    AnnexeSpec(
        code="5",
        obligatoire=True,
        description="Annexe financière forfaits (R.314-223) — H/D/S/SEA",
    ),
    AnnexeSpec(
        code="6",
        obligatoire=True,
        description="TPER — Tableau prévisionnel effectifs rémunérés (R.314-224)",
    ),
    AnnexeSpec(
        code="8",
        obligatoire=True,
        description="Bilan financier",
    ),
]

_ANNEXES_SIMPLIFIED: list[AnnexeSpec] = [
    AnnexeSpec(
        code="4",
        obligatoire=True,
        description="Activité GIR (R.314-219) — détail par section",
    ),
    AnnexeSpec(
        code="5",
        obligatoire=True,
        description="Annexe financière forfaits (R.314-223) — H/D/S/SEA",
    ),
    # 6 et 8 facultatives en PRIVE_COMMERCIAL (EPRD simplifié)
    AnnexeSpec(
        code="6",
        obligatoire=False,
        description="TPER prévisionnel — facultatif (EPRD simplifié)",
    ),
    AnnexeSpec(
        code="8",
        obligatoire=False,
        description="Bilan financier — facultatif (EPRD simplifié)",
    ),
]


# --------------------------------------------------------------------
# Équilibre initial par nature × CPOM
# --------------------------------------------------------------------


def _initial_equilibre(
    nature_juridique: NatureJuridique,
    any_inclus_cpom: bool,
) -> EquilibreApplicableInitial:
    """Équilibre initial au moment de la création EPRD (§BD reraffine
    par-ETS après).

    Règles (05-workflows §équilibre R.314-222) :
    * ESMS inclus CPOM (toutes natures sauf PRIVE_COMMERCIAL) → REEL
    * ESMS public/non-lucratif hors CPOM → STRICT
    * PRIVE_COMMERCIAL hors CPOM → NON_APPLICABLE (pas d'obligation)
    """
    if nature_juridique == "PRIVE_COMMERCIAL" and not any_inclus_cpom:
        return "NON_APPLICABLE"
    if any_inclus_cpom:
        return "REEL"
    return "STRICT"


# --------------------------------------------------------------------
# Dispatcher per nature juridique
# --------------------------------------------------------------------


def _crps_with_one_per_ets(
    ets_rows: list[dict],
    cr_variante: str,
) -> list[CrpSpec]:
    """Pattern par défaut : 1 CRPP générique (etablissement_id=None,
    sera bindé par le cabinet via §E.4) + 1 CRPA par ETS.

    Le CRPP par défaut créé par ``create_with_default_crpp`` couvre
    déjà le 1er CR (ordre=0, sans etablissement_id). Les CRPA structurels
    additionnels commencent à ordre=1, dans l'ordre alphabétique des
    ``raison_sociale`` (ce que retourne :func:`etablissement_repo.list_by_og`).
    """
    return [
        CrpSpec(
            cr_type="CRPA",
            cr_variante=cr_variante,  # type: ignore[arg-type]
            etablissement_id=ets["id"],
            denomination=f"CRPA — {ets['raison_sociale']}",
            ordre=idx + 1,
        )
        for idx, ets in enumerate(ets_rows)
    ]


def _build_spec_eps(
    og_id: UUID,
    ets_rows: list[dict],
    any_inclus_cpom: bool,
) -> EprdStructureSpec:
    """ETABLISSEMENT_PUBLIC_SANTE — CRPP sanitaire + CRPA médico-sociaux.

    Le CRPP représente l'établissement de santé lui-même (sanitaire).
    Les CRPA structurels représentent chaque ESMS rattaché.
    """
    notes = [
        "L'EPRD est porté par l'établissement de santé. Le CRPP par défaut "
        "représente le périmètre sanitaire — bindez-le manuellement à l'EPS "
        "principal via §E.4. Chaque ESMS rattaché reçoit un CRPA "
        "(soumis_equilibre).",
    ]
    return EprdStructureSpec(
        og_id=og_id,
        nature_juridique="ETABLISSEMENT_PUBLIC_SANTE",
        crps=_crps_with_one_per_ets(ets_rows, cr_variante="soumis_equilibre"),
        annexes=_ANNEXES_FULL,
        equilibre_applicable_initial=_initial_equilibre(
            "ETABLISSEMENT_PUBLIC_SANTE", any_inclus_cpom
        ),
        notes=notes,
    )


def _build_spec_esms_public_or_prive_nl(
    og_id: UUID,
    nature_juridique: NatureJuridique,
    ets_rows: list[dict],
    any_inclus_cpom: bool,
) -> EprdStructureSpec:
    """ESMS_PUBLIC_AUTONOME / PRIVE_NON_LUCRATIF — 1 CRPP + N-1 CRPA.

    Le 1er ETS (alphabétique) est porté par le CRPP par défaut ; les
    suivants par des CRPA structurels.
    """
    if not ets_rows:
        # Pas d'ETS → juste le CRPP par défaut, pas de CRPA structurels.
        notes_empty = [
            "OG sans établissement rattaché — l'EPRD démarre avec le seul "
            "CRPP par défaut. Créez des ETS via §AD.4 puis ré-utilisez "
            "compute_eprd_structure pour ajouter les CRPA manquants.",
        ]
        return EprdStructureSpec(
            og_id=og_id,
            nature_juridique=nature_juridique,
            crps=[],
            annexes=_ANNEXES_FULL,
            equilibre_applicable_initial=_initial_equilibre(nature_juridique, any_inclus_cpom),
            notes=notes_empty,
        )

    # 1er ETS bindé manuellement au CRPP par défaut ; les autres deviennent
    # des CRPA structurels. Le CRPP générique sans etablissement_id est
    # déjà créé par ``create_with_default_crpp`` — on n'émet ici que les
    # CRPA.
    crpa_rows = ets_rows[1:]
    notes = [
        f"OG porte {len(ets_rows)} ETS. Le CRPP par défaut est à binder "
        f"au 1er ESMS ({ets_rows[0]['raison_sociale']}) via §E.4. "
        f"{len(crpa_rows)} CRPA structurels sont pré-créés pour les ESMS "
        f"restants.",
    ]
    return EprdStructureSpec(
        og_id=og_id,
        nature_juridique=nature_juridique,
        crps=_crps_with_one_per_ets(crpa_rows, cr_variante="soumis_equilibre"),
        annexes=_ANNEXES_FULL,
        equilibre_applicable_initial=_initial_equilibre(nature_juridique, any_inclus_cpom),
        notes=notes,
    )


def _build_spec_ccas(
    og_id: UUID,
    ets_rows: list[dict],
    any_inclus_cpom: bool,
) -> EprdStructureSpec:
    """CCAS_CIAS_COLLECTIVITE — 1 budget annexe global par défaut.

    S03 p.16-17 (R.314-78) : 2 organisations possibles. Le service
    retourne la variante (a) "1 budget annexe global" → 1 CRPP unique,
    pas de CRPA structurels. Le cabinet peut basculer en variante (b)
    "1 EPRD par ETS" en créant N documents EPRD séparés.
    """
    notes = [
        "CCAS/CIAS — variante par défaut : 1 budget annexe global, 1 EPRD "
        "avec 1 CRP unique (le CRPP par défaut). Si vous préférez la "
        "variante 'N budgets annexes', créez 1 EPRD par ESMS.",
    ]
    return EprdStructureSpec(
        og_id=og_id,
        nature_juridique="CCAS_CIAS_COLLECTIVITE",
        crps=[],
        annexes=_ANNEXES_FULL,
        equilibre_applicable_initial=_initial_equilibre("CCAS_CIAS_COLLECTIVITE", any_inclus_cpom),
        notes=notes,
    )


def _build_spec_prive_commercial(
    og_id: UUID,
    ets_rows: list[dict],
    any_inclus_cpom: bool,
) -> EprdStructureSpec:
    """PRIVE_COMMERCIAL — EPRD simplifié, pas de CRPA structurels.

    S03 p.13 : "opposable mais vision partielle". Le cabinet peut
    ajouter des CRPA manuellement via §E.4 si nécessaire.
    """
    notes = [
        "EPRD simplifié pour ESMS privé commercial (S03 p.13) — opposable "
        "mais vision partielle. Pas de CRPA structurels pré-créés. Annexes "
        "6 et 8 facultatives.",
    ]
    return EprdStructureSpec(
        og_id=og_id,
        nature_juridique="PRIVE_COMMERCIAL",
        crps=[],
        annexes=_ANNEXES_SIMPLIFIED,
        equilibre_applicable_initial=_initial_equilibre("PRIVE_COMMERCIAL", any_inclus_cpom),
        notes=notes,
    )


# --------------------------------------------------------------------
# Public entry point
# --------------------------------------------------------------------


async def compute_eprd_structure(og_id: UUID) -> EprdStructureSpec:
    """Retourne la structure EPRD attendue pour un OG.

    Charge l'OG + la liste de ses ETS + le flag ``any_inclus_cpom``,
    puis dispatche vers le builder par nature juridique.

    Raises :
    * :class:`NotFoundError` si l'OG n'existe pas (RLS-scoped).
    * :class:`ValidationError` si ``nature_juridique`` est inconnu
      (defensive — le CHECK contraint à 5 valeurs).
    """
    og_row = await run_in_thread(og_repo.get_by_id, og_id)
    if og_row is None:
        raise NotFoundError(f"OG {og_id} not found", code="og_not_found")

    ets_rows = await run_in_thread(etablissement_repo.list_by_og, og_id)
    any_inclus_cpom = any(bool(e.get("inclus_cpom")) for e in ets_rows)

    nature: NatureJuridique = og_row["nature_juridique"]

    if nature == "ETABLISSEMENT_PUBLIC_SANTE":
        return _build_spec_eps(og_id, ets_rows, any_inclus_cpom)
    if nature in ("ESMS_PUBLIC_AUTONOME", "PRIVE_NON_LUCRATIF"):
        return _build_spec_esms_public_or_prive_nl(og_id, nature, ets_rows, any_inclus_cpom)
    if nature == "CCAS_CIAS_COLLECTIVITE":
        return _build_spec_ccas(og_id, ets_rows, any_inclus_cpom)
    if nature == "PRIVE_COMMERCIAL":
        return _build_spec_prive_commercial(og_id, ets_rows, any_inclus_cpom)

    raise ValidationError(
        f"nature_juridique '{nature}' unknown — extend "
        f"compute_eprd_structure to handle this case",
        code="nature_juridique_unhandled",
    )
