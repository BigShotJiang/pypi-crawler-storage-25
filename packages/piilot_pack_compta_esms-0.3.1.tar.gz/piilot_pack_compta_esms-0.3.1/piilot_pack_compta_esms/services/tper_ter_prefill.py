"""Prefill TPER/TER lignes from a §G binding (§P.3, L2 §11.3).

L2 §11.3 explicite : "Pré-remplir depuis **binding journal paie**".
Service ``import_tper_to_ter()`` (D-047, TPER N validé → TER N) est
différé à un ticket suivi — §P livre uniquement le mode binding.

Connecte §G's :func:`binding_service.preview_binding` (qui agrège le
KB journal paie selon le contrat de la feature) à
:func:`tper_ter_repo.insert_one` (qui pose une ligne par row preview).

Le contrat d'agrégation des features ``tper_effectifs`` et
``ter_effectifs`` (cf. 003_seed_feature_catalog.sql) :

* dimensions : ``categorie_cnsa``, ``fonction``
* mesures : ``etpr``, ``etpt``, ``remunerations``

→ Mapping ``type_tableau`` → colonnes DB :

* ``TPER`` → ``etpr_prevus`` / ``etpt_prevus`` / ``remunerations_prevues``
* ``TER`` → ``etpr_realises`` / ``etpt_realises`` / ``remunerations_realisees``

**§BJ v0.3** : le contrat KB ``tper_effectifs`` / ``ter_effectifs``
expose désormais ``type_poste`` ('P' Permanent / 'T' Temporaire). Le
binding peut mapper une colonne source vers ``type_poste`` ; le
prefill consomme la valeur mappée avec fallback ``'P'`` quand la
colonne est absente ou que la valeur n'est pas ∈ {'P', 'T'}
(rétrocompat bindings v0.2).

Sémantique Q6 : skip les natural keys (catégorie, fonction, type_poste)
déjà saisies en DB (pattern §H.6 prefill semantics). Pas de
``override_flag`` côté DDL ``tper_ter_lignes`` — soit la row existe
(skip), soit pas (insert).
"""

from __future__ import annotations

import logging
from decimal import Decimal
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.tper_ter import (
    TperTerPrefillResponse,
    TypeTableau,
)
from piilot_pack_compta_esms.repositories import kb_binding_repo, tper_ter_repo
from piilot_pack_compta_esms.services import binding_service, document_freeze, reference_lookup
from piilot_pack_compta_esms.services.errors import NotFoundError

logger = logging.getLogger(__name__)


# Feature key → (type_tableau attendu, colonnes DB target)
_TPER_TER_FEATURES: dict[str, dict[str, str]] = {
    "tper_effectifs": {
        "type_tableau": "TPER",
        "col_etpr": "etpr_prevus",
        "col_etpt": "etpt_prevus",
        "col_rem": "remunerations_prevues",
    },
    "ter_effectifs": {
        "type_tableau": "TER",
        "col_etpr": "etpr_realises",
        "col_etpt": "etpt_realises",
        "col_rem": "remunerations_realisees",
    },
}


def _safe_decimal(value) -> Decimal | None:  # noqa: ANN001
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


_ALLOWED_TYPE_POSTE: frozenset[str] = frozenset({"P", "T"})


def _resolve_type_poste(value) -> str:  # noqa: ANN001 — mapped binding payload
    """§BJ — normalise la valeur ``type_poste`` mappée depuis le binding.

    Retourne 'P' (Permanent) ou 'T' (Temporaire). Toute autre valeur
    (None, vide, casse différente, valeur non-DGCS, type non-str) → 'P'
    par défaut (rétrocompat bindings v0.2 + safe fallback).

    Sémantique CHECK ``tper_ter_lignes_type_poste_check`` côté DB (migration
    012) accepte uniquement {'P', 'T'} — un fallback est obligatoire
    pour ne pas faire échouer l'INSERT en cas de mapping incorrect.
    """
    if not isinstance(value, str):
        return "P"
    upper = value.strip().upper()
    if upper in _ALLOWED_TYPE_POSTE:
        return upper
    return "P"


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(tper_ter_repo.document_belongs_to_company, document_id, company_id)
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


async def _resolve_type_etablissement(etablissement_id: UUID, company_id: UUID) -> str:
    ctx = await run_in_thread(tper_ter_repo.get_ets_typologie, etablissement_id, company_id)
    if ctx is None:
        raise NotFoundError(
            f"etablissement {etablissement_id} not found for this company",
            code="etablissement_not_found",
        )
    return reference_lookup.deduce_type_etablissement(ctx.get("typologie"))


def _feature_key_for(type_tableau: str) -> str:
    """TPER → tper_effectifs, TER → ter_effectifs."""
    for key, cfg in _TPER_TER_FEATURES.items():
        if cfg["type_tableau"] == type_tableau:
            return key
    # Defensive : Pydantic Literal already validates type_tableau,
    # this branch is unreachable in practice.
    raise NotFoundError(  # pragma: no cover
        f"no feature key registered for type_tableau '{type_tableau}'",
        code="feature_not_registered",
    )


async def prefill_from_binding(
    *,
    document_id: UUID,
    company_id: UUID,
    ets_id: UUID,
    type_tableau: TypeTableau,
) -> TperTerPrefillResponse:
    """Run the prefill against the binding journal paie for one
    (doc, ets, type_tableau) tuple.

    Steps :

    1. Defense in depth : doc + ets existent et appartiennent au tenant.
    2. Résoudre la feature_key (tper_effectifs ou ter_effectifs).
    3. Charger le binding via :func:`kb_binding_repo.get_by_feature`
       (à doc_id + feature_key). Si pas de binding → 404
       ``binding_not_configured``.
    4. Charger les natural keys déjà présentes en DB pour skip.
    5. :func:`binding_service.preview_binding` retourne les rows
       agrégées (1 par catégorie+fonction).
    6. Pour chaque preview row :
       a. Résoudre ``type_poste`` depuis la donnée mappée (§BJ) avec
          fallback ``'P'`` si non mappé ou valeur hors {'P', 'T'}.
       b. Skip si natural key (categorie, fonction, type_poste) déjà
          saisie → counter ``skipped``.
       c. Sinon insert via :func:`tper_ter_repo.insert_one` →
          counter ``inserted``.

    §BJ : ``type_poste`` est désormais dans le contrat des features
    ``tper_effectifs`` / ``ter_effectifs`` (migration 023). Les rows
    sans mapping ``type_poste`` (bindings v0.2) tombent en fallback
    ``'P'`` pour rétrocompat. Valeurs autorisées : ``'P'`` (Permanent)
    et ``'T'`` (Temporaire) — toute autre valeur retombe en ``'P'``.

    Freeze §S : 409 si document hors brouillon."""
    await document_freeze.require_brouillon(document_id, company_id)
    await _require_document(document_id, company_id)
    type_etablissement = await _resolve_type_etablissement(ets_id, company_id)
    feature_key = _feature_key_for(type_tableau)
    feature_cfg = _TPER_TER_FEATURES[feature_key]

    # Defense in depth : binding configured ?
    binding = await run_in_thread(kb_binding_repo.get_by_doc_feature, document_id, feature_key)
    if binding is None:
        raise NotFoundError(
            f"binding for feature '{feature_key}' is not configured on " f"document {document_id}",
            code="binding_not_configured",
        )

    existing_keys = await run_in_thread(
        tper_ter_repo.list_existing_keys, document_id, ets_id, type_tableau
    )

    preview = await binding_service.preview_binding(
        document_id=document_id,
        feature_key=feature_key,
        company_id=company_id,
        filters={},
    )

    inserted = 0
    skipped = 0
    for row in preview.rows:
        data = row.data
        categorie = data.get("categorie_cnsa")
        fonction = data.get("fonction")
        if not categorie:
            # Defensive : skip rows without categorie (the binding
            # column_mapping should have provided it, but the KB
            # might be malformed).
            skipped += 1
            continue
        # §BJ — type_poste depuis le mapping (fallback 'P' rétrocompat).
        type_poste = _resolve_type_poste(data.get("type_poste"))
        natural_key = (categorie, fonction, type_poste)
        if natural_key in existing_keys:
            skipped += 1
            continue
        item = {
            "categorie_cnsa": categorie,
            "fonction": fonction,
            "type_poste": type_poste,
            feature_cfg["col_etpr"]: _safe_decimal(data.get("etpr")),
            feature_cfg["col_etpt"]: _safe_decimal(data.get("etpt")),
            feature_cfg["col_rem"]: _safe_decimal(data.get("remunerations")),
        }
        await run_in_thread(
            tper_ter_repo.insert_one,
            company_id=company_id,
            document_id=document_id,
            etablissement_id=ets_id,
            type_tableau=type_tableau,
            type_etablissement=type_etablissement,
            item=item,
        )
        inserted += 1

    return TperTerPrefillResponse(
        inserted=inserted,
        updated=0,  # always 0 — :prefill skip-or-insert, no update path
        skipped=skipped,
    )


__all__ = ["prefill_from_binding"]
