"""Apply + materialize + history pipeline (§F.5).

Closes out the assistant mapping flow :

1. ``apply_mapping`` — re-parses the source file, walks every row,
   resolves it through ``compta_esms.balance_mappings`` (the cabinet's
   per-company dictionary built in §F.2 + populated by §F.4 accept-all).
   Each row generates 0..N output rows (one per matching target ;
   ``weight`` splits the source amount). Unmatched rows accumulate
   in ``unmapped_accounts`` with their montant + occurrence count.

2. ``materialize_kb`` — builds a plugin-owned KB
   ``kbs.compta_esms__balance_m22bis_<period>__<uuid8>`` via the SDK,
   one row per (source_account → target) pair from the snapshot, so
   downstream features (CRP binding, ratios, bilan) read a M22 bis
   balance without re-running the mapping every time.

3. ``list_history`` / ``replay_import`` / ``delete_import`` — admin
   plumbing for the assistant UI.

Per :data:`balance_imports`, the ``status`` column climbs through:

  ``pending`` (post-upload §F.3)
  → ``partial`` (apply with unmapped accounts)
  → ``completed`` (apply with 0 unmapped **or** materialize succeeded)
  → ``failed`` (apply / materialize crashed — error_payload populated)
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from piilot.sdk import knowledge as kb_sdk
from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.balance_apply import (
    ApplyRequest,
    ApplyResult,
    BalanceImportSummary,
    MaterializeRequest,
    MaterializeResult,
    UnmappedAccount,
)
from piilot_pack_compta_esms.repositories import (
    balance_import_repo,
    balance_mapping_repo,
)
from piilot_pack_compta_esms.services import balance_file_parser
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)

# Columns the materialised KB exposes. Order matches the position the
# add_column() loop will use. Keeping the schema minimal — the downstream
# CRP binding (§G) only needs these 7 fields ; richer audit columns
# (raw debit / credit, original line index) can land in a v0.3 schema
# bump if a cabinet feature surfaces the need.
_KB_COLUMNS: tuple[tuple[str, str], ...] = (
    ("source_account", "text"),
    ("source_plan", "text"),
    ("target_m22bis_account", "text"),
    ("label", "text"),
    ("montant", "numeric"),
    ("weight", "numeric"),
    ("periode", "text"),
)


def _extract_montant(row: list[Any], detection: dict[str, int | None]) -> float:
    """Pick the row's amount from the column-detection hints.

    Priority : ``solde`` (single net amount, what cabinets usually
    expose) → ``debit - credit`` (when the export carries both legs
    instead). Returns 0.0 when neither role is mapped — the apply
    still processes the row but the materialised KB carries a zero
    amount, which surfaces visibly in the assistant preview."""
    solde_idx = detection.get("solde")
    if solde_idx is not None and solde_idx < len(row):
        return _coerce_float(row[solde_idx])

    debit_idx = detection.get("debit")
    credit_idx = detection.get("credit")
    debit = _coerce_float(row[debit_idx]) if debit_idx is not None and debit_idx < len(row) else 0.0
    credit = (
        _coerce_float(row[credit_idx]) if credit_idx is not None and credit_idx < len(row) else 0.0
    )
    return debit - credit


def _coerce_float(value: Any) -> float:
    """Best-effort float coercion. Returns 0.0 on garbage — the apply
    pass favours partial success over a hard failure on a single
    malformed row."""
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    s = str(value).strip().replace(" ", "").replace(",", ".")
    if not s or s == "-":
        return 0.0
    try:
        return float(s)
    except ValueError:
        return 0.0


# ---------------------------------------------------------------------------
# apply_mapping
# ---------------------------------------------------------------------------


async def apply_mapping(company_id: UUID, import_id: UUID, request: ApplyRequest) -> ApplyResult:
    """Run the mapping over every row of the source file.

    Steps :

    1. Fetch the import row + column_detection from DB.
    2. Read the source file from S3 (via :func:`balance_file_parser`).
    3. Pull the company's full mapping dictionary for ``version_m22bis``.
    4. For each row : lookup mapping by ``source_account`` → emit 0..N
       mapped rows (one per target, ``montant × weight``) or accumulate
       in ``unmapped_accounts``.
    5. When ``dry_run=False`` : persist the snapshot + counts + status.
    """
    current = await run_in_thread(balance_import_repo.get_by_id, import_id)
    if current is None or str(current["company_id"]) != str(company_id):
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )

    detection = current["column_detection"] or {}
    if detection.get("compte") is None:
        raise ConflictError(
            "column_detection.compte is unset — run :detect-columns first.",
            code="apply_compte_unset",
        )

    storage_key = current["source_storage_key"]
    if not storage_key:
        raise ConflictError(
            "Balance import has no source_storage_key — re-upload required.",
            code="apply_missing_storage",
        )

    # Late import to break the cycle storage <-> services
    from piilot.sdk import storage

    body = await storage.get_object(storage_key)
    filename = current["source_filename"] or "balance.xlsx"
    lower = filename.lower()
    if lower.endswith((".xlsx", ".xlsm")):
        _header, data_rows = balance_file_parser.parse_xlsx(body)
    elif lower.endswith((".csv", ".tsv")):
        _header, data_rows = balance_file_parser.parse_csv(body)
    else:
        raise ConflictError(
            f"Unsupported source file extension : {filename!r}.",
            code="apply_unsupported_format",
        )

    source_plan = current["source_plan"]

    # Pull the dictionary in one shot — filtering on source_plan +
    # version_m22bis. We index in Python rather than per-row DB
    # lookups (5 000 rows * 1 query = unworkable).
    mappings = await run_in_thread(
        balance_mapping_repo.list_filtered,
        company_id,
        source_plan=source_plan,
        version_m22bis=request.version_m22bis,
        limit=10_000,
    )
    by_source: dict[str, list[dict[str, Any]]] = {}
    for row in mappings:
        by_source.setdefault(row["source_account"], []).append(row)

    compte_idx = detection["compte"]
    libelle_idx = detection.get("libelle")
    nb_mapped = 0
    nb_unmapped = 0
    unmapped_agg: dict[str, dict[str, Any]] = {}
    applied_rules: dict[str, list[dict[str, Any]]] = {}

    for row in data_rows:
        if compte_idx >= len(row) or row[compte_idx] is None:
            continue
        source_account = str(row[compte_idx]).strip()
        if not source_account:
            continue
        montant = _extract_montant(row, detection)
        label = None
        if libelle_idx is not None and libelle_idx < len(row):
            label_raw = row[libelle_idx]
            if label_raw is not None:
                label = str(label_raw).strip() or None

        targets = by_source.get(source_account)
        if not targets:
            slot = unmapped_agg.setdefault(
                source_account,
                {
                    "source_account": source_account,
                    "label_hint": label,
                    "montant": 0.0,
                    "nb_lignes": 0,
                },
            )
            slot["montant"] += montant
            slot["nb_lignes"] += 1
            nb_unmapped += 1
            continue

        nb_mapped += 1
        # Record this source_account's resolved targets in the snapshot
        # once — subsequent rows use the same rule.
        if source_account not in applied_rules:
            applied_rules[source_account] = [
                {
                    "target_m22bis_account": t["target_m22bis_account"],
                    "weight": float(t["weight"]),
                    "label_hint": t["label_hint"],
                }
                for t in targets
            ]

    mapping_snapshot: dict[str, Any] = {
        "version_m22bis": request.version_m22bis,
        "source_plan": source_plan,
        "applied_at": datetime.now(UTC).isoformat(),
        "rules": [{"source_account": k, "targets": v} for k, v in sorted(applied_rules.items())],
    }
    unmapped_list = sorted(unmapped_agg.values(), key=lambda x: x["source_account"])
    new_status = "completed" if not unmapped_list else "partial"

    applied_at = None
    if not request.dry_run:
        row = await run_in_thread(
            balance_import_repo.update_apply_result,
            import_id,
            mapping_snapshot=mapping_snapshot,
            unmapped_accounts=unmapped_list,
            nb_lignes_mappees=nb_mapped,
            nb_lignes_non_mappees=nb_unmapped,
            status=new_status,
        )
        if row is None:
            raise NotFoundError(
                f"Balance import {import_id} not found",
                code="balance_import_not_found",
            )
        applied_at = row["applied_at"]

    return ApplyResult(
        import_id=import_id,
        status=new_status,
        nb_lignes_source=current["nb_lignes_source"],
        nb_lignes_mappees=nb_mapped,
        nb_lignes_non_mappees=nb_unmapped,
        nb_unmapped_accounts=len(unmapped_list),
        applied_at=applied_at,
        dry_run=request.dry_run,
    )


async def list_unmapped(company_id: UUID, import_id: UUID) -> list[UnmappedAccount]:
    """Return the unmapped accounts recorded by the last apply pass."""
    current = await run_in_thread(balance_import_repo.get_by_id, import_id)
    if current is None or str(current["company_id"]) != str(company_id):
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )
    return [UnmappedAccount.model_validate(entry) for entry in current["unmapped_accounts"] or []]


# ---------------------------------------------------------------------------
# materialize_kb
# ---------------------------------------------------------------------------


async def materialize_kb(
    company_id: UUID, import_id: UUID, request: MaterializeRequest
) -> MaterializeResult:
    """Build the plugin-owned KB ``kbs.compta_esms__balance_m22bis_…``.

    One KB row per (source_account → target) pair from
    ``mapping_snapshot``. The KB schema is set by :data:`_KB_COLUMNS`
    — fixed across imports so the downstream binding (§G) can rely on
    stable column names.

    When ``overwrite_existing=True`` and the import already has a
    ``materialized_kb_id`` : we delete the previous rows in place
    (cheap, keeps the KB id stable so any open binding doesn't break)
    rather than re-creating a fresh KB. When False, second-materialize
    attempts 409 so the cabinet doesn't accidentally clobber the
    existing KB."""
    current = await run_in_thread(balance_import_repo.get_by_id, import_id)
    if current is None or str(current["company_id"]) != str(company_id):
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )
    snapshot = current["mapping_snapshot"] or {}
    if not snapshot.get("rules"):
        raise ConflictError(
            "No mapping snapshot — run :apply-mapping first.",
            code="materialize_no_snapshot",
        )

    existing_kb_id = current["materialized_kb_id"]
    if existing_kb_id and not request.overwrite_existing:
        raise ConflictError(
            "Balance import already materialised — pass overwrite_existing=True "
            "to replace its rows.",
            code="materialize_already_done",
        )

    # Re-walk the source file with the current snapshot to get the
    # per-row montant. We could store the apply pass's row-level output
    # on the import, but the JSONB payload would balloon to MB on a
    # 5 000-row balance — re-parsing the file is cheaper.
    from piilot.sdk import storage

    body = await storage.get_object(current["source_storage_key"])
    filename = current["source_filename"] or "balance.xlsx"
    lower = filename.lower()
    if lower.endswith((".xlsx", ".xlsm")):
        _header, data_rows = balance_file_parser.parse_xlsx(body)
    else:
        _header, data_rows = balance_file_parser.parse_csv(body)

    detection = current["column_detection"] or {}
    compte_idx = detection["compte"]
    libelle_idx = detection.get("libelle")
    source_plan = snapshot.get("source_plan", current["source_plan"])
    periode_label = current["periode_label"]

    rules_by_source: dict[str, list[dict[str, Any]]] = {
        rule["source_account"]: rule["targets"] for rule in snapshot["rules"]
    }

    kb_rows: list[dict[str, Any]] = []
    for row in data_rows:
        if compte_idx >= len(row) or row[compte_idx] is None:
            continue
        source_account = str(row[compte_idx]).strip()
        if not source_account:
            continue
        targets = rules_by_source.get(source_account)
        if not targets:
            continue
        montant = _extract_montant(row, detection)
        label = None
        if libelle_idx is not None and libelle_idx < len(row):
            label_raw = row[libelle_idx]
            if label_raw is not None:
                label = str(label_raw).strip() or None
        for target in targets:
            weight = float(target.get("weight", 1.0))
            kb_rows.append(
                {
                    "data": {
                        "source_account": source_account,
                        "source_plan": source_plan,
                        "target_m22bis_account": target["target_m22bis_account"],
                        "label": label or target.get("label_hint"),
                        "montant": montant * weight,
                        "weight": weight,
                        "periode": periode_label,
                    }
                }
            )

    # Create / reuse the KB.
    overwritten = False
    if existing_kb_id and request.overwrite_existing:
        # delete_rows_by with an empty filter is refused by the SDK as
        # a safety guard ; we delete by ``periode`` instead — every row
        # this import owns shares the same periode_label.
        await run_in_thread(
            kb_sdk.delete_rows_by,
            str(existing_kb_id),
            {"periode": periode_label},
        )
        kb_id = existing_kb_id
        kb_name = request.kb_label or (f"Balance M22bis - {periode_label} - {source_plan}")
        kb_table_name = current["materialized_kb_table_name"]
        overwritten = True
    else:
        kb_name = request.kb_label or (f"Balance M22bis - {periode_label} - {source_plan}")
        kb = await run_in_thread(
            kb_sdk.create_kb,
            company_id=str(company_id),
            name=kb_name,
            description=(
                f"Balance comptable mappée vers M22 bis pour la période "
                f"{periode_label} (source: {source_plan}). Générée par "
                "compta_esms balance assistant."
            ),
            schema_locked=True,
        )
        kb_id = UUID(str(kb["id"]))
        kb_table_name = kb.get("table_name")
        # Add the columns in the order declared by _KB_COLUMNS so the
        # binding contract is stable.
        for position, (name, column_type) in enumerate(_KB_COLUMNS):
            await run_in_thread(
                kb_sdk.add_column,
                str(kb_id),
                name=name,
                column_type=column_type,
                position=position,
                is_required=(name in {"source_account", "target_m22bis_account"}),
            )

    rows_inserted = 0
    if kb_rows:
        rows_inserted = await run_in_thread(kb_sdk.insert_batch, str(kb_id), kb_rows)

    await run_in_thread(
        balance_import_repo.update_materialized_kb,
        import_id,
        kb_id=kb_id,
        kb_table_name=kb_table_name,
    )

    return MaterializeResult(
        import_id=import_id,
        kb_id=kb_id,
        kb_name=kb_name,
        kb_table_name=kb_table_name,
        rows_inserted=rows_inserted,
        overwritten=overwritten,
    )


# ---------------------------------------------------------------------------
# history + replay + delete
# ---------------------------------------------------------------------------


async def list_history(
    company_id: UUID,
    *,
    exercice_id: UUID | None = None,
    etablissement_id: UUID | None = None,
    status: str | None = None,
    limit: int = 20,
) -> list[BalanceImportSummary]:
    rows = await run_in_thread(
        balance_import_repo.list_history,
        company_id,
        exercice_id=exercice_id,
        etablissement_id=etablissement_id,
        status=status,
        limit=min(limit, 200),
    )
    return [BalanceImportSummary.model_validate(r) for r in rows]


async def replay_import(company_id: UUID, import_id: UUID) -> ApplyResult:
    """Re-run apply with the *current* dictionary.

    Useful after the cabinet has corrected a few mappings : replay
    refreshes the snapshot + the unmapped report. The materialised
    KB is **not** rebuilt automatically — the cabinet runs
    ``:materialize-kb?overwrite_existing=true`` to refresh
    downstream features."""
    current = await run_in_thread(balance_import_repo.get_by_id, import_id)
    if current is None or str(current["company_id"]) != str(company_id):
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )
    snapshot = current["mapping_snapshot"] or {}
    request = ApplyRequest(
        version_m22bis=snapshot.get("version_m22bis", "2025-2026"),
        dry_run=False,
    )
    return await apply_mapping(company_id, import_id, request)


async def delete_import(company_id: UUID, import_id: UUID, *, delete_kb: bool = False) -> None:
    """Drop the balance_imports row.

    When ``delete_kb=True`` and the import owns a materialised KB,
    we wipe the KB's rows in-place — we deliberately don't drop the
    KB itself because the SDK doesn't expose a ``delete_kb()`` primitive
    in v0.7 (the upstream gap is tracked alongside the Tier 3 LLM
    primitive ; see §F.4 docstring TODO). The orphaned KB row stays
    on ``public.knowledge_bases`` but with zero rows — a janitor job
    can mop them up later."""
    current = await run_in_thread(balance_import_repo.get_by_id, import_id)
    if current is None or str(current["company_id"]) != str(company_id):
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )

    if delete_kb and current["materialized_kb_id"]:
        await run_in_thread(
            kb_sdk.delete_rows_by,
            str(current["materialized_kb_id"]),
            {"periode": current["periode_label"]},
        )

    deleted = await run_in_thread(balance_import_repo.delete, import_id)
    if not deleted:
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )


__all__ = [
    "apply_mapping",
    "list_unmapped",
    "materialize_kb",
    "list_history",
    "replay_import",
    "delete_import",
]
