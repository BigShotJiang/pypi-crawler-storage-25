"""Service d'affectation des résultats (§J, L2 §10).

Orchestre :

* :func:`compute_resultats_bruts` — calcule A. RESULTAT A AFFECTER
  par section depuis :func:`crp_ligne_service.totals` (plan-dev §7.5
  simplification v0.2 : ``resultat_brut = produits.realise -
  charges.realise``).
* :func:`list_affectations` / :func:`put_affectations_bulk` /
  :func:`validate_allocations` — endpoints L2 §10.1 / §10.2 / §10.3.
* :func:`list_suivi_affectations` — endpoint L2 §10.4.

Auto-déductions (Q3 + Q4) :

* ``variante`` : depuis l'OG du document via
  :func:`affectation_variante.choose_affectation_variante`.
* ``ventilation`` : depuis le CR (variant_I) ou ``simple`` par défaut
  (variant_II consolidé).

Le PUT alimente :mod:`suivi_affectation_repo` dans la même transaction
(Q6 — auto au PUT) : solde_debut_n vient de l'exercice N-1, mouvements
des affectations elles-mêmes, solde_fin_n calculé. Q5 — tolérance
0.01€ pour C-79/C-80 (cohérent §I équilibre strict).
"""

from __future__ import annotations

import logging
from collections import defaultdict
from decimal import Decimal
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.affectation import (
    AffectationBulkRequest,
    AffectationRead,
    AffectationsResponse,
    AllocationValidationResult,
    ResultatBrutBySection,
    SuiviAffectationRead,
    ValidationIssue,
    Variante,
    Ventilation,
)
from piilot_pack_compta_esms.repositories import (
    affectation_repo,
    cr_repo,
    suivi_affectation_repo,
)
from piilot_pack_compta_esms.services import (
    affectation_variante,
    crp_ligne_service,
    document_freeze,
)
from piilot_pack_compta_esms.services.errors import (
    NotFoundError,
    ValidationError,
)

logger = logging.getLogger(__name__)

_ZERO = Decimal("0")
_TOLERANCE_C79_C80 = Decimal("0.01")
"""Q5 — tolérance arrondi 0.01€ pour le contrôle Σ B = A
(cohérent §I équilibre strict S03 p.29)."""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(
        affectation_repo.document_belongs_to_company, document_id, company_id
    )
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


# §J + §X — Affectation applies to "réalisé" types only :
# * ERRD (médico-social pur) — KB23 §4
# * ERCP (sanitaire EPS, Annexe 11 R.314-233) — KB22 §3.1
# EPCP is prévisionnel (no affectation), EPRD is prévisionnel, DM/RIA
# modify EPRD without re-affecting (the parent EPRD's affectation
# remains the authoritative one).
_AFFECTATION_APPLICABLE_TYPES: frozenset[str] = frozenset({"errd", "ercp"})


async def _load_doc_context(document_id: UUID, company_id: UUID) -> dict:
    ctx = await run_in_thread(affectation_repo.get_doc_affectation_context, document_id, company_id)
    if ctx is None:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )
    return ctx


def _assert_affectation_applicable(ctx: dict, document_id: UUID) -> None:
    """Refuse 422 ``affectation_not_applicable_for_doc_type`` si le
    document n'est pas un ERRD ou un ERCP. KB22 §3.1 + §3.3 + §X."""
    type_document = ctx.get("type_document")
    if type_document not in _AFFECTATION_APPLICABLE_TYPES:
        raise ValidationError(
            f"Affectation des résultats requiert type_document ∈ "
            f"{sorted(_AFFECTATION_APPLICABLE_TYPES)}, "
            f"got '{type_document}' (document {document_id}). "
            f"EPCP est prévisionnel et EPRD/DM/RIA modifient sans ré-affecter.",
            code="affectation_not_applicable_for_doc_type",
        )


def _resolve_variante(ctx: dict) -> Variante:
    """Auto-déduction Q3 (D-082) — appelle le helper pur."""
    return affectation_variante.choose_affectation_variante(
        nature_juridique=ctx["nature_juridique"],
        inclus_cpom=bool(ctx["any_inclus_cpom"]),
    )


# ---------------------------------------------------------------------------
# §J.6 — compute_resultats_bruts (A. RESULTAT A AFFECTER)
# ---------------------------------------------------------------------------


async def compute_resultats_bruts(
    document_id: UUID, company_id: UUID
) -> list[ResultatBrutBySection]:
    """Plan-dev §7.5 simplification v0.2 :
    ``resultat_brut = sum(produits.realise) - sum(charges.realise)``
    par CR (= par section pour variant_I, agrégé pour variant_II côté
    caller).

    Reports antérieurs + diminutions/augmentations = formule complète
    25-deepdive §4.1 reportée à §X workflow transitions (où l'on aura
    accès au suivi_affectations N-1).
    """
    await _require_document(document_id, company_id)
    cr_rows = await run_in_thread(cr_repo.list_by_document, document_id)
    out: list[ResultatBrutBySection] = []
    for cr_row in cr_rows:
        totals = await crp_ligne_service.totals(cr_row["id"], company_id)
        resultat_brut = totals.total_produits.realise - totals.total_charges.realise
        out.append(
            ResultatBrutBySection(
                cr_id=cr_row["id"],
                cr_denomination=cr_row.get("denomination"),
                total_charges_realise=totals.total_charges.realise,
                total_produits_realise=totals.total_produits.realise,
                resultat_brut=resultat_brut,
            )
        )
    return out


# ---------------------------------------------------------------------------
# §J.7 — list / put / validate
# ---------------------------------------------------------------------------


async def list_affectations(document_id: UUID, company_id: UUID) -> AffectationsResponse:
    """GET /affectations — items persistés + A calculé + verdict.

    Lit la variante depuis les rows existantes (toutes les rows
    doivent avoir la même variante = decision documentaire). Si pas
    d'items, on auto-déduit depuis l'OG (rendu cohérent avec un PUT
    futur)."""
    await _require_document(document_id, company_id)
    rows = await run_in_thread(affectation_repo.list_by_document, document_id)
    items = [AffectationRead.model_validate(r) for r in rows]

    variante_active: Variante | None = None
    ventilation_active: Ventilation | None = None
    if items:
        variante_active = items[0].variante
        ventilation_active = items[0].ventilation
    else:
        ctx = await _load_doc_context(document_id, company_id)
        try:
            variante_active = _resolve_variante(ctx)
        except affectation_variante.UnknownNatureJuridiqueError:
            variante_active = None
        ventilation_active = "simple"

    resultats_bruts = await compute_resultats_bruts(document_id, company_id)
    validation = _validate_in_memory(items, resultats_bruts, variante_active)
    return AffectationsResponse(
        variante_active=variante_active,
        ventilation_active=ventilation_active,
        items=items,
        resultats_bruts=resultats_bruts,
        validation=validation,
    )


def _validate_in_memory(
    items: list[AffectationRead],
    resultats_bruts: list[ResultatBrutBySection],
    variante_active: Variante | None,
) -> AllocationValidationResult:
    """Vérification en mémoire — pas de DB. Réutilisée par
    :func:`validate_allocations` et :func:`list_affectations`."""
    issues: list[ValidationIssue] = []

    if variante_active is None:
        issues.append(
            ValidationIssue(
                code="missing_cr_id",
                message="Variante d'affectation indéterminée (statut juridique inconnu)",
            )
        )

    # Σ B by section
    if variante_active and affectation_variante.is_variant_I(variante_active):
        # par cr_id
        sum_by_cr: dict[UUID, Decimal] = defaultdict(lambda: _ZERO)
        for item in items:
            if item.cr_id is None:
                issues.append(
                    ValidationIssue(
                        code="missing_cr_id",
                        message=f"affectation compte {item.compte_m22bis} sans cr_id en variant_I",
                    )
                )
                continue
            sum_by_cr[item.cr_id] += item.montant_total or _ZERO
        for rb in resultats_bruts:
            assert rb.cr_id is not None  # variant_I → cr_id always set in totals
            sum_b = sum_by_cr.get(rb.cr_id, _ZERO)
            if rb.resultat_brut == _ZERO and sum_b == _ZERO:
                continue  # Section vide et pas affectée — OK
            if sum_b == _ZERO and rb.resultat_brut != _ZERO:
                issues.append(
                    ValidationIssue(
                        code="section_unaffected",
                        cr_id=rb.cr_id,
                        message=(
                            f"Section {rb.cr_denomination or rb.cr_id} a un "
                            f"résultat de {rb.resultat_brut:.2f}€ non affecté"
                        ),
                        ecart=rb.resultat_brut,
                    )
                )
                continue
            ecart = sum_b - rb.resultat_brut
            if abs(ecart) > _TOLERANCE_C79_C80:
                issues.append(
                    ValidationIssue(
                        code="ecart_above_tolerance",
                        cr_id=rb.cr_id,
                        message=(
                            f"Σ affectations ({sum_b:.2f}€) ≠ A "
                            f"({rb.resultat_brut:.2f}€) pour "
                            f"{rb.cr_denomination or rb.cr_id} — écart "
                            f"{ecart:.2f}€"
                        ),
                        ecart=ecart,
                    )
                )
    elif variante_active and affectation_variante.is_variant_II(variante_active):
        # Σ items consolidé vs Σ resultats_bruts (tout le document)
        sum_b = sum((item.montant_total or _ZERO for item in items), _ZERO)
        sum_a = sum((rb.resultat_brut for rb in resultats_bruts), _ZERO)
        if sum_a == _ZERO and sum_b == _ZERO:
            pass
        elif sum_b == _ZERO and sum_a != _ZERO:
            issues.append(
                ValidationIssue(
                    code="section_unaffected",
                    message=(f"Document a un résultat consolidé de {sum_a:.2f}€ " "non affecté"),
                    ecart=sum_a,
                )
            )
        else:
            ecart = sum_b - sum_a
            if abs(ecart) > _TOLERANCE_C79_C80:
                issues.append(
                    ValidationIssue(
                        code="ecart_above_tolerance",
                        message=(
                            f"Σ affectations consolidé ({sum_b:.2f}€) ≠ Σ A "
                            f"({sum_a:.2f}€) — écart {ecart:.2f}€"
                        ),
                        ecart=ecart,
                    )
                )

    return AllocationValidationResult(
        valide=not issues,
        issues=issues,
        tolerance_appliquee=_TOLERANCE_C79_C80,
    )


async def put_affectations_bulk(
    document_id: UUID,
    company_id: UUID,
    payload: AffectationBulkRequest,
) -> AffectationsResponse:
    """PUT bulk-upsert by section (Q8). Auto-déduit variante (Q3) +
    ventilation (Q4). Dispatch sur variant_I ou variant_II. Alimente
    ``suivi_affectations`` dans la même transaction (Q6).

    Freeze §S : 409 si document hors brouillon.
    §X : 422 si type_document ∉ {errd, ercp}."""
    await document_freeze.require_brouillon(document_id, company_id)
    ctx = await _load_doc_context(document_id, company_id)
    _assert_affectation_applicable(ctx, document_id)

    # Auto-déduction variante Q3
    try:
        variante = _resolve_variante(ctx)
    except affectation_variante.UnknownNatureJuridiqueError as exc:
        raise ValidationError(
            f"OG nature_juridique inconnu pour le doc {document_id}",
            code="og_nature_juridique_unknown",
        ) from exc

    # Auto-déduction ventilation Q4 (depuis le 1er CR du document si existe)
    cr_rows = await run_in_thread(cr_repo.list_by_document, document_id)
    if cr_rows and cr_rows[0].get("ventilation") in ("ternaire_hds", "ternaire_hdsea"):
        # ternaire_hdsea (SEA expérimentation) tombe dans ternaire_hds côté affectations v0.2
        ventilation: Ventilation = "ternaire_hds"
    else:
        ventilation = "simple"

    # Validation cohérence items vs variante
    is_variant_I = affectation_variante.is_variant_I(variante)
    items_dict: list[dict] = []
    for item in payload.items:
        if is_variant_I and item.cr_id is None:
            raise ValidationError(
                f"variante {variante} requires cr_id sur chaque item "
                f"(compte {item.compte_m22bis})",
                code="missing_cr_id",
            )
        if not is_variant_I and item.cr_id is not None:
            raise ValidationError(
                f"variante {variante} ne supporte pas cr_id (consolidé) — "
                f"compte {item.compte_m22bis}",
                code="cr_id_not_allowed",
            )
        if is_variant_I:
            cr_ok = await run_in_thread(
                affectation_repo.cr_belongs_to_document, item.cr_id, document_id
            )
            if not cr_ok:
                raise ValidationError(
                    f"cr_id {item.cr_id} n'appartient pas au document {document_id}",
                    code="cr_id_not_in_document",
                )
        items_dict.append(item.model_dump(mode="json"))

    # Replace all + bulk upsert distinguer par variante
    await run_in_thread(affectation_repo.delete_by_document, document_id)
    if is_variant_I:
        await run_in_thread(
            affectation_repo.bulk_upsert_variant_I,
            company_id=company_id,
            document_id=document_id,
            variante=variante,
            ventilation=ventilation,
            items=items_dict,
        )
    else:
        await run_in_thread(
            affectation_repo.bulk_upsert_variant_II,
            company_id=company_id,
            document_id=document_id,
            variante=variante,
            ventilation=ventilation,
            items=items_dict,
        )

    # Suivi affectations auto-rempli (Q6)
    await _refresh_suivi_affectations(
        document_id=document_id,
        company_id=company_id,
        ctx=ctx,
        items_dict=items_dict,
    )

    return await list_affectations(document_id, company_id)


async def _refresh_suivi_affectations(
    *,
    document_id: UUID,
    company_id: UUID,
    ctx: dict,
    items_dict: list[dict],
) -> None:
    """Met à jour ``suivi_affectations`` : pour chaque (etablissement,
    compte) affecté, on calcule solde_debut_n (depuis N-1) +
    mouvements depuis les affectations + solde_fin_n.

    Stratégie v0.2 : on prend le 1er ETS de l'OG comme bucket par
    défaut (variant_II consolidé). Pour variant_I, on regarde le
    cr.etablissement_id. Si pas d'ETS résolu → bucket NULL.
    """
    # Charge N-1 balances pour ce compte/ets
    annee = await _get_exercice_annee(ctx)
    n_minus_1 = await run_in_thread(
        suivi_affectation_repo.lookup_n_minus_1_balances,
        company_id=company_id,
        og_id=ctx["og_id"],
        annee_courante=annee,
    )

    # Group items by (etablissement_id, compte_m22bis) avec résolution cr
    cr_to_ets = await _build_cr_to_ets_map(document_id)
    aggregated: dict[tuple[str | None, str], Decimal] = defaultdict(lambda: _ZERO)
    for item in items_dict:
        cr_id = item.get("cr_id")
        ets_id = cr_to_ets.get(str(cr_id)) if cr_id else None
        compte = item["compte_m22bis"]
        montant = item.get("montant_total") or 0
        if isinstance(montant, str):
            montant = Decimal(montant)
        elif not isinstance(montant, Decimal):
            montant = Decimal(str(montant))
        aggregated[(ets_id, compte)] += montant

    # Build suivi rows (mouvements_credit = positive montant, debit = -montant)
    suivi_items: list[dict] = []
    for (ets_id, compte), montant in aggregated.items():
        solde_debut = n_minus_1.get((ets_id, compte), _ZERO)
        if montant >= _ZERO:
            mouvements_credit = montant
            mouvements_debit = _ZERO
        else:
            mouvements_credit = _ZERO
            mouvements_debit = -montant
        solde_fin = solde_debut + mouvements_credit - mouvements_debit
        suivi_items.append(
            {
                "etablissement_id": ets_id,
                "compte_m22bis": compte,
                "solde_debut_n": solde_debut,
                "mouvements_credit": mouvements_credit,
                "mouvements_debit": mouvements_debit,
                "solde_fin_n": solde_fin,
            }
        )

    await run_in_thread(
        suivi_affectation_repo.bulk_replace_by_document,
        company_id=company_id,
        document_id=document_id,
        items=suivi_items,
    )


async def _get_exercice_annee(ctx: dict) -> int:
    """Charge l'année de l'exercice du document via 1 SQL light."""
    from piilot.sdk.db import cursor as _cursor

    def _query() -> int:
        with _cursor() as cur:
            cur.execute(
                "SELECT annee FROM compta_esms.exercices WHERE id = %s",
                (str(ctx["exercice_id"]),),
            )
            row = cur.fetchone()
            return int(row["annee"]) if row else 0

    return await run_in_thread(_query)


async def _build_cr_to_ets_map(document_id: UUID) -> dict[str, str | None]:
    """Map ``{cr_id_str: etablissement_id_str_or_None}`` pour le suivi."""
    cr_rows = await run_in_thread(cr_repo.list_by_document, document_id)
    return {
        str(c["id"]): str(c["etablissement_id"]) if c.get("etablissement_id") else None
        for c in cr_rows
    }


async def validate_allocations(document_id: UUID, company_id: UUID) -> AllocationValidationResult:
    """POST :validate — ré-évalue Σ B = A par section (C-79/C-80).

    Pas de side-effect, juste lecture + vérif."""
    response = await list_affectations(document_id, company_id)
    return response.validation


async def list_suivi_affectations(
    document_id: UUID, company_id: UUID
) -> list[SuiviAffectationRead]:
    """GET /suivi-affectations — read-only, alimenté au PUT."""
    await _require_document(document_id, company_id)
    rows = await run_in_thread(suivi_affectation_repo.list_by_document, document_id)
    return [SuiviAffectationRead.model_validate(r) for r in rows]
