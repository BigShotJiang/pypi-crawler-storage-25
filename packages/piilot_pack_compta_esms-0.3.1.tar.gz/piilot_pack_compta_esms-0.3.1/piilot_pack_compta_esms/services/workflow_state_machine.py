"""Pure state machine for document workflow transitions (§S).

Aucune IO. Le service expose :

* :func:`compute_allowed_actions` — retourne les actions applicables
  depuis (type_document, statut, double_validation_state, role).
* :func:`can_apply` — verdict booléen pour un (action, autorite?)
  donné. Fait le travail de filtrage pour le route POST avant tout
  side effect.
* :func:`derive_target_statut` — calcule le ``statut_after`` à partir
  d'un ``WorkflowSnapshot`` + action + autorite. Le service appelle
  ce helper APRÈS avoir validé que l'action est applicable.

Mapping centralisé :

* **ERRD-family** (ERRD + ERCP — réalisé final, §X) — workflow
  simplifié (D-023, sans état APPROUVE) :
  ``BROUILLON → TRANSMIS → AFFECTATION_DEFINIE``.
* **EPRD-family** (EPRD/DM/RIA/AVENANT/EPCP — prévisionnel ou
  modificatif) — double validation ATC (D-024) avec collapse
  ``brouillon → en_instruction`` au ``transmit`` :
  ``BROUILLON → EN_INSTRUCTION → (auto-flip EXECUTOIRE quand 2
  timestamps remplis) | REJETE (terminal)``.

Cette logique vit ici pour que les tests unitaires l'exercent sans
mock DB et sans Pydantic complexe.
"""

from __future__ import annotations

from typing import Final

from piilot_pack_compta_esms.models.workflow import (
    AllowedAction,
    AutoriteTarif,
    BlockedAction,
    DoubleValidationState,
    TransitionAction,
    WorkflowSnapshot,
)

# ---------------------------------------------------------------------------
# Catégorie de workflow par type_document
# ---------------------------------------------------------------------------

ERRD_TYPES: Final[frozenset[str]] = frozenset({"errd", "ercp"})
"""Workflow simplifié D-023 — réalisé final, avec figement affectation.

ERCP est le pendant sanitaire de l'ERRD (Annexe 11 R.314-233) : il
contient les onglets ``Affectation_Resultats`` + ``Suivi_Affectation_Resultats``
(KB22 §3.1), donc même workflow ``BROUILLON → TRANSMIS →
AFFECTATION_DEFINIE``. §X."""

EPRD_FAMILY_TYPES: Final[frozenset[str]] = frozenset({"eprd", "dm", "ria", "avenant", "epcp"})
"""Workflow double-validation D-024.

DM/RIA modifient un EPRD parent ``EXECUTOIRE`` et passent par leur
propre cycle d'approbation. ``avenant`` suit la même mécanique. EPCP
(Annexe 12 R.314-242) est le pendant prévisionnel sanitaire — pas
d'affectation (KB22 §3.3), même machine que EPRD (double validation
ATC). §X."""


def workflow_family(type_document: str) -> str:
    """Retourne ``'errd'`` ou ``'eprd_family'`` selon le type_document.

    Raises :class:`ValueError` si le type n'est connu d'aucune famille
    — cas qui ne devrait pas se produire (Pydantic ``TypeDocument``
    couvre les 7 valeurs).
    """
    if type_document in ERRD_TYPES:
        return "errd"
    if type_document in EPRD_FAMILY_TYPES:
        return "eprd_family"
    raise ValueError(f"unknown_workflow_family_for_type:{type_document}")


# ---------------------------------------------------------------------------
# Helpers — état des 2 approbations
# ---------------------------------------------------------------------------


def build_double_validation_state(snapshot: WorkflowSnapshot) -> DoubleValidationState:
    """Construit le sous-état des 2 approbations à partir du snapshot.

    Pour ERRD : ``applicable=False`` (pas de double validation), les
    timestamps restent NULL (le DDL les laisse vides).
    """
    family = workflow_family(snapshot.type_document)
    return DoubleValidationState(
        applicable=(family == "eprd_family"),
        approuve_par_ars_at=snapshot.approuve_par_ars_at,
        approuve_par_cd_at=snapshot.approuve_par_cd_at,
        approuve_par_ars_user_id=snapshot.approuve_par_ars_user_id,
        approuve_par_cd_user_id=snapshot.approuve_par_cd_user_id,
    )


def _ars_approved(snapshot: WorkflowSnapshot) -> bool:
    return snapshot.approuve_par_ars_at is not None


def _cd_approved(snapshot: WorkflowSnapshot) -> bool:
    return snapshot.approuve_par_cd_at is not None


# ---------------------------------------------------------------------------
# compute_allowed_actions — endpoint :transitions-allowed
# ---------------------------------------------------------------------------


def compute_allowed_actions(
    snapshot: WorkflowSnapshot,
    *,
    role: str,
) -> tuple[list[AllowedAction], list[BlockedAction]]:
    """Liste les actions applicables et celles bloquées avec leur
    raison machine. Le frontend en déduit les CTAs visibles.

    Le paramètre ``role`` ('user' | 'builder' | 'admin') filtre les
    actions selon les permissions L2 :

    * ``transmit`` → builder/admin
    * ``set_affectation`` → admin
    * ``approve`` → admin
    * ``reject`` → admin
    """
    allowed: list[AllowedAction] = []
    blocked: list[BlockedAction] = []
    family = workflow_family(snapshot.type_document)
    statut = snapshot.statut

    # ----- transmit -------------------------------------------------------
    if statut == "brouillon":
        if role in {"builder", "admin"}:
            allowed.append(
                AllowedAction(
                    action="transmit",
                    label="Transmettre",
                    role_required="builder",
                )
            )
        else:
            blocked.append(BlockedAction(action="transmit", reason="role_required"))
    else:
        blocked.append(
            BlockedAction(
                action="transmit",
                reason="transition_not_allowed_from_statut",
            )
        )

    # ----- approve / reject (EPRD-family only, depuis en_instruction) -----
    if family == "eprd_family":
        for autorite in ("ars", "cd"):
            _appraise_approve(
                snapshot=snapshot,
                autorite=autorite,
                role=role,
                allowed=allowed,
                blocked=blocked,
            )
            _appraise_reject(
                snapshot=snapshot,
                autorite=autorite,
                role=role,
                allowed=allowed,
                blocked=blocked,
            )
    else:
        # ERRD : approve/reject ne s'appliquent pas
        blocked.append(BlockedAction(action="approve", reason="not_applicable_for_type"))
        blocked.append(BlockedAction(action="reject", reason="not_applicable_for_type"))

    # ----- set_affectation (ERRD only, depuis TRANSMIS) -------------------
    if family == "errd":
        if statut == "transmis":
            if role == "admin":
                allowed.append(
                    AllowedAction(
                        action="set_affectation",
                        label="Figer l'affectation",
                        role_required="admin",
                    )
                )
            else:
                blocked.append(BlockedAction(action="set_affectation", reason="role_required"))
        else:
            blocked.append(
                BlockedAction(
                    action="set_affectation",
                    reason="transition_not_allowed_from_statut",
                )
            )
    else:
        blocked.append(
            BlockedAction(
                action="set_affectation",
                reason="not_applicable_for_type",
            )
        )

    return allowed, blocked


def _appraise_approve(
    *,
    snapshot: WorkflowSnapshot,
    autorite: AutoriteTarif,
    role: str,
    allowed: list[AllowedAction],
    blocked: list[BlockedAction],
) -> None:
    """Évalue si ``approve(autorite)`` est applicable et l'ajoute dans
    ``allowed`` ou ``blocked``."""
    already = _ars_approved(snapshot) if autorite == "ars" else _cd_approved(snapshot)
    if snapshot.statut != "en_instruction":
        blocked.append(
            BlockedAction(
                action="approve",
                autorite=autorite,
                reason="transition_not_allowed_from_statut",
            )
        )
        return
    if already:
        blocked.append(
            BlockedAction(
                action="approve",
                autorite=autorite,
                reason="already_approved",
            )
        )
        return
    if role != "admin":
        blocked.append(BlockedAction(action="approve", autorite=autorite, reason="role_required"))
        return
    label = f"Approuver ({autorite.upper()})"
    allowed.append(
        AllowedAction(
            action="approve",
            autorite=autorite,
            label=label,
            role_required="admin",
        )
    )


def _appraise_reject(
    *,
    snapshot: WorkflowSnapshot,
    autorite: AutoriteTarif,
    role: str,
    allowed: list[AllowedAction],
    blocked: list[BlockedAction],
) -> None:
    """Évalue si ``reject(autorite, motif)`` est applicable.

    Reject est possible depuis ``en_instruction`` y compris si
    l'autre autorité a déjà approuvé (rejet par 1 → rejet global,
    plan-dev L317).
    """
    if snapshot.statut != "en_instruction":
        blocked.append(
            BlockedAction(
                action="reject",
                autorite=autorite,
                reason="transition_not_allowed_from_statut",
            )
        )
        return
    if role != "admin":
        blocked.append(BlockedAction(action="reject", autorite=autorite, reason="role_required"))
        return
    label = f"Rejeter ({autorite.upper()})"
    allowed.append(
        AllowedAction(
            action="reject",
            autorite=autorite,
            label=label,
            role_required="admin",
        )
    )


# ---------------------------------------------------------------------------
# can_apply — guard before mutation
# ---------------------------------------------------------------------------


def can_apply(
    snapshot: WorkflowSnapshot,
    *,
    action: TransitionAction,
    autorite: AutoriteTarif | None,
    role: str,
) -> tuple[bool, str | None]:
    """Vérifie si ``(action, autorite)`` est applicable. Retourne
    ``(True, None)`` si oui, ``(False, reason_code)`` sinon.

    Reason codes possibles :
    ``transition_not_allowed_from_statut`` / ``already_approved`` /
    ``role_required`` / ``not_applicable_for_type`` /
    ``autorite_required`` / ``autorite_forbidden``.
    """
    family = workflow_family(snapshot.type_document)
    statut = snapshot.statut

    if action == "transmit":
        if role not in {"builder", "admin"}:
            return False, "role_required"
        if statut != "brouillon":
            return False, "transition_not_allowed_from_statut"
        return True, None

    if action == "set_affectation":
        if family != "errd":
            return False, "not_applicable_for_type"
        if role != "admin":
            return False, "role_required"
        if statut != "transmis":
            return False, "transition_not_allowed_from_statut"
        return True, None

    if action == "approve":
        if family != "eprd_family":
            return False, "not_applicable_for_type"
        if autorite is None:
            return False, "autorite_required"
        if role != "admin":
            return False, "role_required"
        if statut != "en_instruction":
            return False, "transition_not_allowed_from_statut"
        if autorite == "ars" and _ars_approved(snapshot):
            return False, "already_approved"
        if autorite == "cd" and _cd_approved(snapshot):
            return False, "already_approved"
        return True, None

    if action == "reject":
        if family != "eprd_family":
            return False, "not_applicable_for_type"
        if autorite is None:
            return False, "autorite_required"
        if role != "admin":
            return False, "role_required"
        if statut != "en_instruction":
            return False, "transition_not_allowed_from_statut"
        return True, None

    return False, "unknown_action"  # pragma: no cover — guarded by Literal


# ---------------------------------------------------------------------------
# derive_target_statut — calcule statut_after
# ---------------------------------------------------------------------------


def derive_target_statut(
    snapshot: WorkflowSnapshot,
    *,
    action: TransitionAction,
    autorite: AutoriteTarif | None,
) -> str:
    """Calcule le statut résultant. **Pré-condition** : :func:`can_apply`
    a renvoyé ``(True, None)``. Sinon le résultat est indéfini.

    Cas spécial — ``approve`` : si l'autre autorité a déjà approuvé,
    le statut bascule directement à ``executoire``. Sinon il reste à
    ``en_instruction`` (l'attente d'une 2e validation).
    """
    family = workflow_family(snapshot.type_document)

    if action == "transmit":
        # Collapse "transmis → en_instruction (auto système)" pour
        # EPRD-family — on saute directement à en_instruction parce que
        # l'usine n'a pas de système ATC externe qui ferait basculer
        # le statut. ERRD passe à TRANSMIS (puis figement manuel).
        return "en_instruction" if family == "eprd_family" else "transmis"

    if action == "set_affectation":
        return "affectation_definie"

    if action == "reject":
        return "rejete"

    if action == "approve":
        # Si l'autre autorité avait déjà approuvé, flip executoire.
        other_already = _cd_approved(snapshot) if autorite == "ars" else _ars_approved(snapshot)
        return "executoire" if other_already else "en_instruction"

    raise ValueError(f"unknown_action:{action}")  # pragma: no cover
