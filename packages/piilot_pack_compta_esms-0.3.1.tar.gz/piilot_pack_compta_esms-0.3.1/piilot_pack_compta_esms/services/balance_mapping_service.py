"""Service layer for the balance_mappings dictionary (D-108).

Beyond the standard CRUD plumbing, this layer enforces the **Σ weight
≤ 1.0** business rule eagerly. The DB trigger
``tg_check_balance_mapping_weights`` (migration 002 / §D.12) is the
hard guardrail ; raising at the service layer gives the API a clean
409 with a stable code rather than bouncing on a ``RaiseException``.

Tolerance is 1e-4 — matches the trigger's float fudge factor so the
service and the DB agree on what "Σ = 1.0" means.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.balance_mapping import (
    BalanceMappingBulkItem,
    BalanceMappingCreate,
    BalanceMappingRead,
    BalanceMappingUpdate,
    BalanceMappingValidationIssue,
)
from piilot_pack_compta_esms.repositories import balance_mapping_repo
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)

_WEIGHT_TOLERANCE = 1e-4


def _to_read(row: dict[str, Any]) -> BalanceMappingRead:
    return BalanceMappingRead.model_validate(row)


def _validate_sum_after_change(
    rows: list[dict[str, Any]],
    *,
    new_weight: float,
    target_account: str,
    mapping_id_to_replace: UUID | None = None,
) -> None:
    """Simulate the post-write Σ weight and refuse if > 1.0 + tolerance.

    ``rows`` is the current set of mappings for the
    ``(source_plan, source_account, version_m22bis)`` key. We compute
    what Σ would be *after* the change : either replace the row at
    ``mapping_id_to_replace`` with ``new_weight``, or add a fresh row.
    """
    total = 0.0
    replaced = False
    for r in rows:
        if mapping_id_to_replace is not None and str(r["id"]) == str(mapping_id_to_replace):
            total += new_weight
            replaced = True
        elif r["target_m22bis_account"] == target_account:
            # The UNIQUE constraint guarantees a single row per target,
            # but if create_mapping is called with an existing target
            # the DB will reject — we pre-check and route to 409 first.
            total += new_weight
            replaced = True
        else:
            total += float(r["weight"])
    if not replaced:
        total += new_weight

    if total > 1.0 + _WEIGHT_TOLERANCE:
        raise ConflictError(
            f"Σ weight would exceed 1.0 (got {total:.4f}) for this source "
            "account — fix the existing splits before adding another target.",
            code="mapping_weight_overflow",
        )


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------


async def list_mappings(
    company_id: UUID,
    *,
    source_plan: str | None = None,
    source_account: str | None = None,
    version_m22bis: str | None = None,
    limit: int = 200,
) -> list[BalanceMappingRead]:
    """List the company's mappings, optionally filtered."""
    rows = await run_in_thread(
        balance_mapping_repo.list_filtered,
        company_id,
        source_plan=source_plan,
        source_account=source_account,
        version_m22bis=version_m22bis,
        limit=min(limit, 1000),
    )
    return [_to_read(r) for r in rows]


async def get_mapping(mapping_id: UUID) -> BalanceMappingRead:
    row = await run_in_thread(balance_mapping_repo.get_by_id, mapping_id)
    if row is None:
        raise NotFoundError(f"Mapping {mapping_id} not found", code="mapping_not_found")
    return _to_read(row)


async def create_mapping(company_id: UUID, payload: BalanceMappingCreate) -> BalanceMappingRead:
    """Create a single mapping. 409 if it duplicates an existing UNIQUE
    key, or if it would push Σ weight > 1.0 for its source key."""
    existing = await run_in_thread(
        balance_mapping_repo.find_unique,
        company_id,
        payload.source_plan,
        payload.source_account,
        payload.target_m22bis_account,
        payload.version_m22bis,
    )
    if existing is not None:
        raise ConflictError(
            "A mapping already exists for "
            f"({payload.source_plan}, {payload.source_account}, "
            f"{payload.target_m22bis_account}, {payload.version_m22bis}) "
            "— PATCH the existing row instead.",
            code="mapping_already_exists",
        )

    siblings = await run_in_thread(
        balance_mapping_repo.list_filtered,
        company_id,
        source_plan=payload.source_plan,
        source_account=payload.source_account,
        version_m22bis=payload.version_m22bis,
        limit=100,
    )
    _validate_sum_after_change(
        siblings, new_weight=payload.weight, target_account=payload.target_m22bis_account
    )

    row = await run_in_thread(
        balance_mapping_repo.create,
        company_id,
        payload.model_dump(exclude_none=True),
    )
    return _to_read(row)


async def update_mapping(
    company_id: UUID, mapping_id: UUID, payload: BalanceMappingUpdate
) -> BalanceMappingRead:
    current = await run_in_thread(balance_mapping_repo.get_by_id, mapping_id)
    if current is None:
        raise NotFoundError(f"Mapping {mapping_id} not found", code="mapping_not_found")
    if str(current["company_id"]) != str(company_id):
        raise NotFoundError(f"Mapping {mapping_id} not found", code="mapping_not_found")

    if payload.weight is not None and payload.weight != float(current["weight"]):
        siblings = await run_in_thread(
            balance_mapping_repo.list_filtered,
            company_id,
            source_plan=current["source_plan"],
            source_account=current["source_account"],
            version_m22bis=current["version_m22bis"],
            limit=100,
        )
        _validate_sum_after_change(
            siblings,
            new_weight=payload.weight,
            target_account=current["target_m22bis_account"],
            mapping_id_to_replace=mapping_id,
        )

    row = await run_in_thread(
        balance_mapping_repo.update,
        mapping_id,
        payload.model_dump(exclude_unset=True),
    )
    if row is None:
        raise NotFoundError(f"Mapping {mapping_id} not found", code="mapping_not_found")
    return _to_read(row)


async def delete_mapping(company_id: UUID, mapping_id: UUID) -> None:
    current = await run_in_thread(balance_mapping_repo.get_by_id, mapping_id)
    if current is None:
        raise NotFoundError(f"Mapping {mapping_id} not found", code="mapping_not_found")
    if str(current["company_id"]) != str(company_id):
        raise NotFoundError(f"Mapping {mapping_id} not found", code="mapping_not_found")
    deleted = await run_in_thread(balance_mapping_repo.delete, mapping_id)
    if not deleted:
        raise NotFoundError(f"Mapping {mapping_id} not found", code="mapping_not_found")


# ---------------------------------------------------------------------------
# Bulk + validate (L2 §7bis.3.3 + §7bis.3.6)
# ---------------------------------------------------------------------------


async def bulk_upsert_mappings(
    company_id: UUID, items: list[BalanceMappingBulkItem]
) -> list[BalanceMappingRead]:
    """Atomic bulk upsert.

    We **don't** pre-validate Σ weight here : the caller (assistant
    suggestion accept-all-above, CSV import) typically pastes a full
    coherent set where Σ = 1.0 per source after the operation. The DB
    trigger catches violations and rolls back the whole batch — the
    user gets a 422-ish error pointing at the source key that broke.
    """
    if not items:
        return []
    payload = [item.model_dump(exclude_none=True) for item in items]
    rows = await run_in_thread(balance_mapping_repo.bulk_upsert, company_id, payload)
    return [_to_read(r) for r in rows]


async def validate_weights(
    company_id: UUID,
) -> list[BalanceMappingValidationIssue]:
    """Return the keys whose Σ weight is outside [1.0 - tol, 1.0 + tol].

    Empty list = the dictionary is consistent and can be applied as-is.
    """
    rows = await run_in_thread(balance_mapping_repo.sum_weights_by_source, company_id)
    issues: list[BalanceMappingValidationIssue] = []
    for r in rows:
        total = float(r["total_weight"])
        if abs(total - 1.0) > _WEIGHT_TOLERANCE:
            issues.append(
                BalanceMappingValidationIssue(
                    source_plan=r["source_plan"],
                    source_account=r["source_account"],
                    version_m22bis=r["version_m22bis"],
                    total_weight=total,
                    target_count=r["target_count"],
                )
            )
    return issues


# ---------------------------------------------------------------------------
# CSV export / import (L2 §7bis.3.7 + §7bis.3.8)
# ---------------------------------------------------------------------------

CSV_HEADER = [
    "source_plan",
    "source_account",
    "target_m22bis_account",
    "weight",
    "label_hint",
    "confidence",
    "suggestion_origin",
    "version_m22bis",
    "valid_from",
    "valid_to",
]


async def list_for_export(company_id: UUID) -> list[dict[str, Any]]:
    """Return all mapping rows projected onto the CSV columns.

    The route serializes the list to text/csv via the standard ``csv``
    module ; keeping the projection in the service makes the contract
    unit-testable without touching the HTTP layer."""
    return await run_in_thread(balance_mapping_repo.list_for_export, company_id)


async def import_csv_rows(
    company_id: UUID, items: list[BalanceMappingBulkItem]
) -> list[BalanceMappingRead]:
    """Same path as :func:`bulk_upsert_mappings` — exposed under a
    distinct name because the route's permission level is different
    (admin vs builder) and the body shape comes from a parsed CSV
    instead of a JSON list."""
    return await bulk_upsert_mappings(company_id, items)
