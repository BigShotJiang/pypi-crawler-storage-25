"""Service §AA — ratios financiers ERRD (D-091) + PGFP (D-095 bloc 10).

Expose 2 entrées HTTP L2 §17 :

* :func:`compute_ratios` — GET, calcule à la volée.
* :func:`recompute_ratios` — POST :recompute, alias L2 (même path
  recalcule, identique en résultat — utile pour rate-limiter
  séparément les recomputes coûteux côté frontend).

Pas de persistance — chaque appel charge bilan + CRP + emprunts + PGFP
en lazy (1 SELECT par section, mémoïsé dans RatioContext.custom).
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Literal
from uuid import UUID

from piilot.sdk.db import run_in_thread
from pydantic import BaseModel, ConfigDict, Field

from piilot_pack_compta_esms.ratios._base import (
    RatioContext,
    RatioResult,
    RatioResultPgfp,
)
from piilot_pack_compta_esms.ratios.engine import run_ids
from piilot_pack_compta_esms.repositories import document_repo
from piilot_pack_compta_esms.services.errors import NotFoundError

# Ids ERRD D-091 — 15 ratios catalogue KB25 §8.
ERRD_IDS: tuple[str, ...] = (
    "1.1",
    "1.2",
    "1.3",  # endettement
    "2.1",  # patrimoine
    "3.1.a",
    "3.1.b",
    "3.1.c",
    "3.2",  # équilibres bilan
    "4.1",
    "4.2",
    "4.3",
    "4.4",  # rotation
    "5.1",
    "5.2",
    "5.3",  # autres
)

# Ids PGFP D-095 bloc 10 — 8 ratios prévisionnels.
PGFP_IDS: tuple[str, ...] = (
    "pgfp.endettement",
    "pgfp.vetuste",
    "pgfp.taux_caf",
    "pgfp.marge_brute",
    "pgfp.frng_jours",
    "pgfp.bfr_jours",
    "pgfp.tresorerie_jours",
    "pgfp.duree_dette",
)

# Types de documents avec ratios PGFP applicables (D-094 — prévisionnel).
_PGFP_DOC_TYPES: frozenset[str] = frozenset({"eprd", "dm", "ria", "avenant"})

# Types EPS — ratios M21 non couverts v0.2 (cf. Q8 du tableau §AA).
_EPS_DOC_TYPES: frozenset[str] = frozenset({"ercp", "epcp"})


# ---------------------------------------------------------------------------
# DTOs publics
# ---------------------------------------------------------------------------


class RatiosSummary(BaseModel):
    """Compteurs verdict par catégorie de retour."""

    model_config = ConfigDict(extra="forbid")

    nb_ok: int
    nb_atypie: int
    nb_na: int
    total: int


class RatiosResponse(BaseModel):
    """Réponse GET /ratios — list à plat + summary."""

    model_config = ConfigDict(extra="forbid")

    document_id: UUID
    type_document: str
    ratios_errd: list[RatioResult]
    ratios_pgfp: list[RatioResultPgfp] = Field(default_factory=list)
    summary_errd: RatiosSummary
    computed_at: datetime


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


async def _load_doc_or_404(document_id: UUID, company_id: UUID) -> dict:
    row = await run_in_thread(document_repo.get_by_id, document_id)
    if row is None or str(row["company_id"]) != str(company_id):
        raise NotFoundError(
            f"document_not_found:{document_id}",
            code="document_not_found",
        )
    return row


def _summarize(results: list[RatioResult]) -> RatiosSummary:
    nb_ok = sum(1 for r in results if r.verdict == "ok")
    nb_atypie = sum(1 for r in results if r.verdict == "atypie")
    nb_na = sum(1 for r in results if r.verdict == "na")
    return RatiosSummary(nb_ok=nb_ok, nb_atypie=nb_atypie, nb_na=nb_na, total=len(results))


# ---------------------------------------------------------------------------
# compute_ratios — GET endpoint
# ---------------------------------------------------------------------------


async def compute_ratios(
    document_id: UUID,
    company_id: UUID,
    *,
    type_filter: Literal["errd", "pgfp", "all"] = "all",
) -> RatiosResponse:
    """Calcule les ratios à la volée.

    Args :
        type_filter : ``"errd"`` (15 ratios D-091 only), ``"pgfp"`` (8
            ratios prévisionnels D-095 only), ``"all"`` (les deux,
            selon doc_type).
    """
    document = await _load_doc_or_404(document_id, company_id)
    type_document = document["type_document"]
    ctx = RatioContext(document_id=document_id, company_id=company_id, document=document)

    # ERRD ratios — applicables à tous sauf ERCP/EPCP (secteur sanitaire M21).
    errd_results: list[RatioResult] = []
    if type_document not in _EPS_DOC_TYPES and type_filter in {"errd", "all"}:
        raw = await run_ids(ctx, list(ERRD_IDS))
        # Filter à RatioResult only (ERRD_IDS retourne uniquement des RatioResult)
        errd_results = [r for r in raw if isinstance(r, RatioResult)]

    # PGFP ratios — applicables aux types prévisionnels (eprd/dm/ria/avenant).
    pgfp_results: list[RatioResultPgfp] = []
    if type_document in _PGFP_DOC_TYPES and type_filter in {"pgfp", "all"}:
        raw_pgfp = await run_ids(ctx, list(PGFP_IDS))
        pgfp_results = [r for r in raw_pgfp if isinstance(r, RatioResultPgfp)]

    return RatiosResponse(
        document_id=document_id,
        type_document=type_document,
        ratios_errd=errd_results,
        ratios_pgfp=pgfp_results,
        summary_errd=_summarize(errd_results),
        computed_at=datetime.now(UTC),
    )


# ---------------------------------------------------------------------------
# recompute_ratios — POST :recompute (alias L2)
# ---------------------------------------------------------------------------


async def recompute_ratios(
    document_id: UUID,
    company_id: UUID,
) -> RatiosResponse:
    """L2 §17.2 — alias de :func:`compute_ratios` côté API.

    Pas de cache à invalider (pas de persistance) — :recompute = GET
    re-exécuté. Le rate-limit séparé côté route (5/min vs 100/min
    GET) protège du recompute en boucle."""
    return await compute_ratios(document_id, company_id, type_filter="all")
