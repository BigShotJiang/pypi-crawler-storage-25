"""Service §AH — agrégat indicateurs financiers depuis un ``document_id``.

Façade légère qui réutilise :

* ``ratios._base`` lazy loaders (bilan + CRP + emprunts indexés)
* ``services.finance.*`` (CAF, FRNG, BFR, Trésorerie, équilibre R.314-222)

Construit les Pydantic Inputs requis par les calculateurs §I depuis
les rows DB du document, puis appelle les fonctions pures. Quand
l'EPRD/ERRD est incomplet (CRP vide, bilan absent, etc.), retourne
des champs ``None`` + une liste ``missing_inputs`` exploitable par
les tools §AH pour expliquer à l'agent ce qui manque.

Aucune persistance — recalcul à la demande.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.finance import (
    BfrInput,
    CafInput,
    FrngInput,
    TresorerieInput,
)
from piilot_pack_compta_esms.ratios._base import (
    RatioContext,
    _load_bilan_montants,
    _load_emprunts_totals,
    get_caf,
    get_compte_total_bilan,
)
from piilot_pack_compta_esms.repositories import document_repo
from piilot_pack_compta_esms.services.errors import NotFoundError
from piilot_pack_compta_esms.services.finance import (
    caf_calculator,
    structure_financiere,
)

logger = logging.getLogger(__name__)

_ZERO = Decimal("0")


# ---------------------------------------------------------------------------
# DTOs publics
# ---------------------------------------------------------------------------


@dataclass
class IndicateurResult:
    """Un indicateur calculé avec verdict santé.

    ``valeur`` est ``None`` quand les inputs manquent — la liste
    ``missing_inputs`` indique alors quelles rows/feuilles n'ont
    pas été saisies dans le document.
    """

    code: str
    label: str
    valeur: Decimal | None
    unite: str
    sante: str | None
    formule: str
    missing_inputs: list[str]
    details: dict[str, Any]


@dataclass
class IndicateursResponse:
    """Réponse agrégée — CAF + FRNG + BFR + Trésorerie + équilibre.

    Les 4 premiers indicateurs sont des montants absolus. ``equilibre``
    porte la synthèse des 5 conditions R.314-222.
    """

    document_id: UUID
    type_document: str
    caf: IndicateurResult
    frng: IndicateurResult
    bfr: IndicateurResult
    tresorerie: IndicateurResult
    equilibre_status: str
    equilibre_message: str


# ---------------------------------------------------------------------------
# Helpers internes
# ---------------------------------------------------------------------------


async def _load_doc_or_404(document_id: UUID, company_id: UUID) -> dict[str, Any]:
    row = await run_in_thread(document_repo.get_by_id, document_id)
    if row is None or str(row["company_id"]) != str(company_id):
        raise NotFoundError(
            f"document_not_found:{document_id}",
            code="document_not_found",
        )
    return row


def _select_realise_flag(type_document: str) -> bool:
    """ERRD/ERCP = colonnes réalisées · EPRD/DM/RIA/EPCP = prévues."""
    return type_document in {"errd", "ercp"}


async def _build_caf_input(ctx: RatioContext, *, realise: bool) -> CafInput | None:
    """Construit ``CafInput`` simplifié v0.2 — résultat + dotations c/68
    + reprises c/78 + reprises subv c/777.

    Retourne None si CRP entièrement vide (CAF non calculable).
    """
    caf_simplifiee = await get_caf(ctx, realise=realise)
    if caf_simplifiee is None:
        return None

    # CAF simplifiée get_caf = produits décaissables − charges décaissables.
    # On reconstruit ``CafInput`` en mettant tout dans ``resultat_net`` —
    # les autres composantes (amortissements, dotations, reprises) sont
    # déjà neutralisées dans get_caf via l'exclusion des classes 68/675/689
    # côté charges (cf. ratios._base.get_total_charges_decaissables).
    return CafInput(
        resultat_net=caf_simplifiee,
        dotations_amortissements=_ZERO,
        dotations_provisions=_ZERO,
        reprises_provisions=_ZERO,
        reprises_subventions=_ZERO,
        autres_non_decaissables=_ZERO,
        capital_a_rembourser_n=None,
    )


async def _build_frng_input(ctx: RatioContext) -> tuple[FrngInput | None, list[str]]:
    """Construit ``FrngInput`` depuis le Bilan financier.

    Manque sera signalé via la liste retournée.
    """
    bilan = await _load_bilan_montants(ctx)
    if not bilan:
        return None, ["bilan_financier"]

    missing: list[str] = []

    fonds_propres = await get_compte_total_bilan(ctx, "10", field="net_n")
    subv = await get_compte_total_bilan(ctx, "13", field="net_n")
    prov_invest = await get_compte_total_bilan(ctx, "14", field="net_n")
    dettes_lt = await get_compte_total_bilan(ctx, "16", field="net_n")
    immo = await get_compte_total_bilan(ctx, "2", field="net_n")

    if fonds_propres == _ZERO and subv == _ZERO and prov_invest == _ZERO:
        missing.append("fonds_propres_subventions")
    if immo == _ZERO:
        missing.append("immobilisations")

    return (
        FrngInput(
            fonds_propres=fonds_propres,
            subventions_invest=subv,
            provisions_invest=prov_invest,
            dettes_long_terme=dettes_lt,
            immobilisations_nettes=immo,
            fre_ressources=_ZERO,
            fre_emplois=_ZERO,
        ),
        missing,
    )


async def _build_bfr_input(ctx: RatioContext) -> tuple[BfrInput | None, list[str]]:
    """Construit ``BfrInput`` depuis le Bilan financier (postes exploitation)."""
    bilan = await _load_bilan_montants(ctx)
    if not bilan:
        return None, ["bilan_financier"]

    missing: list[str] = []

    creances = await get_compte_total_bilan(ctx, "41", field="net_n")
    stocks = await get_compte_total_bilan(ctx, "3", field="net_n")
    dettes_fourn = await get_compte_total_bilan(ctx, "40", field="net_n")
    dettes_soc = await get_compte_total_bilan(ctx, "42", field="net_n")

    if creances == _ZERO and stocks == _ZERO:
        missing.append("creances_stocks")
    if dettes_fourn == _ZERO and dettes_soc == _ZERO:
        missing.append("dettes_exploitation")

    return (
        BfrInput(
            creances_clients=creances,
            stocks=stocks,
            dettes_fournisseurs=dettes_fourn,
            dettes_sociales=dettes_soc,
        ),
        missing,
    )


# ---------------------------------------------------------------------------
# API publique
# ---------------------------------------------------------------------------


async def compute_indicateurs(
    document_id: UUID,
    company_id: UUID,
) -> IndicateursResponse:
    """Calcule CAF + FRNG + BFR + Trésorerie + équilibre R.314-222.

    Lève :class:`NotFoundError` si le document n'existe pas ou n'est
    pas accessible côté company.
    """
    document = await _load_doc_or_404(document_id, company_id)
    type_document = document["type_document"]
    realise = _select_realise_flag(type_document)
    ctx = RatioContext(
        document_id=document_id,
        company_id=company_id,
        document=document,
    )

    # CAF
    caf_input = await _build_caf_input(ctx, realise=realise)
    if caf_input is None:
        caf_result = IndicateurResult(
            code="CAF",
            label="Capacité d'autofinancement",
            valeur=None,
            unite="EUR",
            sante=None,
            formule="Produits décaissables − Charges décaissables",
            missing_inputs=["crp_lignes"],
            details={},
        )
    else:
        # Tentative — capital_a_rembourser depuis emprunts
        emprunts_totals = await _load_emprunts_totals(ctx)
        iaf = emprunts_totals.get("capital_rembourse_n", _ZERO) or _ZERO
        caf_input = caf_input.model_copy(
            update={"capital_a_rembourser_n": iaf if iaf != _ZERO else None}
        )
        caf_out = caf_calculator.compute_caf(caf_input)
        caf_result = IndicateurResult(
            code="CAF",
            label="Capacité d'autofinancement",
            valeur=caf_out.caf,
            unite="EUR",
            sante=caf_out.sante,
            formule="CAF = Produits décaissables − Charges décaissables",
            missing_inputs=[],
            details={
                "ratio_caf_iaf": (
                    None if caf_out.ratio_caf_iaf is None else float(caf_out.ratio_caf_iaf)
                ),
                "capital_a_rembourser_n": (
                    None
                    if caf_input.capital_a_rembourser_n is None
                    else float(caf_input.capital_a_rembourser_n)
                ),
            },
        )

    # FRNG
    frng_input, frng_missing = await _build_frng_input(ctx)
    if frng_input is None:
        frng_result = IndicateurResult(
            code="FRNG",
            label="Fonds de Roulement Net Global",
            valeur=None,
            unite="EUR",
            sante=None,
            formule="FRNG = (Capitaux + Subv + Provisions LT + Dettes LT) − Immobilisations",
            missing_inputs=frng_missing,
            details={},
        )
        frng_value: Decimal | None = None
    else:
        frng_out = structure_financiere.compute_frng(frng_input)
        frng_result = IndicateurResult(
            code="FRNG",
            label="Fonds de Roulement Net Global",
            valeur=frng_out.frng,
            unite="EUR",
            sante=frng_out.sante,
            formule="FRNG = FRI + FRE — couverture des emplois durables",
            missing_inputs=frng_missing,
            details={
                "fri": float(frng_out.fri),
                "fre": float(frng_out.fre),
            },
        )
        frng_value = frng_out.frng

    # BFR
    bfr_input, bfr_missing = await _build_bfr_input(ctx)
    if bfr_input is None:
        bfr_result = IndicateurResult(
            code="BFR",
            label="Besoin en Fonds de Roulement",
            valeur=None,
            unite="EUR",
            sante=None,
            formule="BFR = (Créances + Stocks) − (Dettes fournisseurs + sociales)",
            missing_inputs=bfr_missing,
            details={},
        )
        bfr_value: Decimal | None = None
    else:
        bfr_out = structure_financiere.compute_bfr(bfr_input)
        bfr_result = IndicateurResult(
            code="BFR",
            label="Besoin en Fonds de Roulement",
            valeur=bfr_out.bfr,
            unite="EUR",
            sante=bfr_out.sante,
            formule="BFR = (Créances + Stocks) − (Dettes fournisseurs + sociales)",
            missing_inputs=bfr_missing,
            details={},
        )
        bfr_value = bfr_out.bfr

    # Trésorerie nette = FRNG − BFR
    if frng_value is None or bfr_value is None:
        tn_result = IndicateurResult(
            code="TRESORERIE",
            label="Trésorerie nette",
            valeur=None,
            unite="EUR",
            sante=None,
            formule="Trésorerie nette = FRNG − BFR",
            missing_inputs=sorted(set((frng_missing or []) + (bfr_missing or []))),
            details={},
        )
    else:
        tn_input = TresorerieInput(frng=frng_value, bfr=bfr_value)
        tn_out = structure_financiere.compute_tresorerie(tn_input)
        tn_result = IndicateurResult(
            code="TRESORERIE",
            label="Trésorerie nette",
            valeur=tn_out.tresorerie,
            unite="EUR",
            sante=tn_out.sante,
            formule="Trésorerie nette = FRNG − BFR",
            missing_inputs=[],
            details={},
        )

    # Équilibre R.314-222 — validation 5 conditions
    # En l'absence d'inputs spécialisés (recettes affectées, sincérité,
    # produits-tarifs détaillés), on rapporte "indeterminable" v0.2 ; le
    # vrai wiring R.314-222 strict est posé en §S+§Z bloquants.
    equilibre_status = "indeterminable"
    equilibre_msg = (
        "L'évaluation R.314-222 stricte requiert la saisie complète "
        "des recettes affectées, du capital remboursé et de la "
        "sincérité commentée. Voir les contrôles bloquants C-001/C-002/"
        "C-003 pour le verdict consolidé."
    )

    return IndicateursResponse(
        document_id=document_id,
        type_document=type_document,
        caf=caf_result,
        frng=frng_result,
        bfr=bfr_result,
        tresorerie=tn_result,
        equilibre_status=equilibre_status,
        equilibre_message=equilibre_msg,
    )
