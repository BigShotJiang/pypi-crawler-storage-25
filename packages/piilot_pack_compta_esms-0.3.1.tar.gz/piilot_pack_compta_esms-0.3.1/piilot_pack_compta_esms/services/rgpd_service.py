"""Service §T — Recueil consentement RGPD (L2 §20, D-090).

Orchestre :

1. GET /recueil-consentement (404 si jamais posé)
2. PUT /recueil-consentement (idempotent via UPSERT) avec :
   * **Toggle automatique** ``consenti_at`` / ``revoque_at`` selon
     transition cnsa (cf. tableau ci-dessous)
   * **Audit log** ``audit_events`` posé systématiquement, payload
     anonymisé léger (transitions cnsa + count fédérations + durée —
     pas la liste détaillée des codes ni les libellés custom).

Toggle ``consenti_at`` / ``revoque_at`` :

================== ==================== ==================
Transition         consenti_at          revoque_at
================== ==================== ==================
∅ → cnsa=True      ``now()``            ``NULL``
cnsa=True → False  inchangé             ``now()``
cnsa=False → True  ``now()`` (reset)    ``NULL``
cnsa=True → True   ``now()`` (re-conf)  inchangé
================== ==================== ==================

Cohérent GDPR : on capte le timeline complet (consenti à T1, révoqué
à T2, re-consenti à T3). Le re-consentement reset ``revoque_at`` à
NULL car cnsa=True à nouveau (cycle de vie clos).
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.rgpd import (
    FederationsConsenties,
    RecueilConsentementRead,
    RecueilConsentementUpdate,
)
from piilot_pack_compta_esms.repositories import rgpd_repo
from piilot_pack_compta_esms.services import audit_service
from piilot_pack_compta_esms.services.errors import (
    CrossCompanyError,
    NotFoundError,
)


def _now_utc() -> datetime:
    """Single source of truth (pratique pour mock côté tests)."""
    return datetime.now(tz=UTC)


def _row_to_read(row: dict[str, Any]) -> RecueilConsentementRead:
    """Convertit un row repo en :class:`RecueilConsentementRead`.

    ``federations_consenties`` est JSONB côté DB. psycopg2 le décode
    automatiquement en dict — on le passe à Pydantic pour validation.
    """
    federations_raw = row["federations_consenties"]
    if isinstance(federations_raw, str):
        # Defensive — certains drivers PG retournent du raw string
        import json

        federations_raw = json.loads(federations_raw)
    federations = FederationsConsenties.model_validate(federations_raw or {})
    return RecueilConsentementRead(
        id=row["id"],
        company_id=row["company_id"],
        exercice_id=row["exercice_id"],
        consentement_cnsa=row["consentement_cnsa"],
        federations=federations,
        duree=row["duree"],
        consenti_par_user_id=row["consenti_par_user_id"],
        consenti_at=row["consenti_at"],
        revoque_at=row["revoque_at"],
    )


async def _require_exercice(exercice_id: UUID, company_id: UUID) -> None:
    """Defense in depth — exercice doit appartenir à la company."""
    owns = await run_in_thread(rgpd_repo.exercice_belongs_to_company, exercice_id, company_id)
    if not owns:
        raise NotFoundError(
            f"exercice_not_found:{exercice_id}",
            code="exercice_not_found",
        )


# ---------------------------------------------------------------------------
# GET — L2 §20.1
# ---------------------------------------------------------------------------


async def get_consentement(exercice_id: UUID, company_id: UUID) -> RecueilConsentementRead:
    """Charge le recueil pour cet exercice. 404 si jamais posé."""
    await _require_exercice(exercice_id, company_id)
    row = await run_in_thread(rgpd_repo.get_by_exercice, exercice_id)
    if row is None:
        raise NotFoundError(
            f"consentement_not_found:{exercice_id}",
            code="consentement_not_found",
        )
    if str(row["company_id"]) != str(company_id):
        # Defense in depth — RLS devrait l'attraper avant nous, mais
        # une 403 explicite est plus honnête qu'un 404 muet.
        raise CrossCompanyError(
            f"consentement_cross_company:{exercice_id}",
            code="consentement_cross_company",
        )
    return _row_to_read(row)


# ---------------------------------------------------------------------------
# PUT — L2 §20.2
# ---------------------------------------------------------------------------


def _resolve_timestamps(
    *,
    previous: dict[str, Any] | None,
    new_cnsa: bool,
    now: datetime,
) -> tuple[datetime | None, datetime | None]:
    """Calcule ``(consenti_at, revoque_at)`` selon la transition.

    Cf. tableau du module docstring.
    """
    prev_cnsa = previous["consentement_cnsa"] if previous else False
    prev_consenti_at = previous["consenti_at"] if previous else None
    prev_revoque_at = previous["revoque_at"] if previous else None

    if previous is None:
        # ∅ → first PUT
        if new_cnsa:
            return now, None
        return None, None

    if prev_cnsa and not new_cnsa:
        # True → False : révocation
        return prev_consenti_at, now
    if not prev_cnsa and new_cnsa:
        # False → True : nouveau cycle (reset revoque_at)
        return now, None
    if prev_cnsa and new_cnsa:
        # True → True : re-confirmation (refresh consenti_at, garde
        # revoque_at intact — il devrait déjà être NULL dans ce cas
        # mais on ne le touche pas par défense).
        return now, prev_revoque_at
    # False → False : no-op temporel
    return prev_consenti_at, prev_revoque_at


async def put_consentement(
    *,
    exercice_id: UUID,
    company_id: UUID,
    user_id: UUID,
    payload: RecueilConsentementUpdate,
) -> RecueilConsentementRead:
    """Crée ou met à jour le recueil pour cet exercice.

    Steps :

    1. Vérifie tenant ownership de l'exercice
    2. Charge le previous row (pour résoudre le toggle timestamps)
    3. Résout ``consenti_at`` / ``revoque_at`` selon la transition cnsa
    4. UPSERT atomique repo
    5. INSERT ``audit_events`` payload anonymisé léger
    6. Retourne le read complet
    """
    await _require_exercice(exercice_id, company_id)

    previous = await run_in_thread(rgpd_repo.get_by_exercice, exercice_id)
    if previous is not None and str(previous["company_id"]) != str(company_id):
        raise CrossCompanyError(
            f"consentement_cross_company:{exercice_id}",
            code="consentement_cross_company",
        )

    now = _now_utc()
    consenti_at, revoque_at = _resolve_timestamps(
        previous=previous,
        new_cnsa=payload.consentement_cnsa,
        now=now,
    )

    federations_dict = payload.federations.model_dump(mode="json")

    row = await run_in_thread(
        rgpd_repo.upsert_by_exercice,
        company_id=company_id,
        exercice_id=exercice_id,
        consentement_cnsa=payload.consentement_cnsa,
        federations_consenties=federations_dict,
        duree=payload.duree,
        consenti_par_user_id=user_id,
        consenti_at=consenti_at,
        revoque_at=revoque_at,
    )

    # Audit léger anonymisé — count + durée + transition cnsa, pas la
    # liste détaillée des codes ni les libellés custom (PII-friendly).
    audit_payload: dict[str, Any] = {
        "from_cnsa": bool(previous["consentement_cnsa"]) if previous else None,
        "to_cnsa": payload.consentement_cnsa,
        "federations_count": (
            len(payload.federations.selected_known) + len(payload.federations.selected_custom)
        ),
        "duree": payload.duree,
    }
    await run_in_thread(
        audit_service.record_event,
        company_id=company_id,
        user_id=user_id,
        action="rgpd.consent",
        resource_type="exercice",
        resource_id=exercice_id,
        payload=audit_payload,
    )

    return _row_to_read(row)
