"""Forfait paramètres service (§R, L2 §13.3-§13.4).

Orchestre 2 endpoints :

* :func:`list_forfait_parametres` — GET §13.3 (liste par ets du
  document)
* :func:`upsert_forfait_parametres` — PUT §13.4 (DELETE+INSERT par
  (doc, ets) idempotent, Q7)

Permissions L2 (Q11) : §13.3 = user, **§13.4 PUT = builder** (mutation
paramètres réglementaires GMP/PMP/GMPS sensibles).

Q8 fail-open EHPAD-only : pas de hard reject typologie. Le cabinet
peut techniquement poser des params sur n'importe quel ets ; sera
typiquement vide pour FAM/SAD (KB20 §5.2 + KB21 §6.1).

Validation D-053 calcul GMPS = f(GMP, PMP, poids soins) → différé
(bloqueur B-33 spec, formule exacte à creuser réglementation).
Calculs F.DEP.01 forfait dépendance via §I ``compute_forfait_dependance_cd``
disponible mais non câblé en endpoint v0.2 (Q10).
"""

from __future__ import annotations

import logging
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.annexe5 import (
    ForfaitParametresListResponse,
    ForfaitParametresRead,
    ForfaitParametresUpdate,
)
from piilot_pack_compta_esms.repositories import forfait_repo
from piilot_pack_compta_esms.services import document_freeze
from piilot_pack_compta_esms.services.errors import NotFoundError

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(forfait_repo.document_belongs_to_company, document_id, company_id)
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


async def _require_ets(etablissement_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(
        forfait_repo.etablissement_belongs_to_company, etablissement_id, company_id
    )
    if not owns:
        raise NotFoundError(
            f"etablissement {etablissement_id} not found for this company",
            code="etablissement_not_found",
        )


# ---------------------------------------------------------------------------
# §13.3 — list_forfait_parametres
# ---------------------------------------------------------------------------


async def list_forfait_parametres(
    document_id: UUID, company_id: UUID
) -> ForfaitParametresListResponse:
    """Liste les params forfait du document (1 entrée par ets).

    Q8 fail-open : retourne toutes les rows, peu importe la typologie
    de l'ets (le frontend filtre selon contexte si besoin)."""
    await _require_document(document_id, company_id)
    rows = await run_in_thread(forfait_repo.list_by_document, document_id)
    return ForfaitParametresListResponse(
        items=[ForfaitParametresRead.model_validate(r) for r in rows]
    )


# ---------------------------------------------------------------------------
# §13.4 — upsert_forfait_parametres (Q7 DELETE+INSERT idempotent)
# ---------------------------------------------------------------------------


async def upsert_forfait_parametres(
    document_id: UUID,
    company_id: UUID,
    payload: ForfaitParametresUpdate,
) -> ForfaitParametresRead:
    """DELETE WHERE (doc, ets) + INSERT 1 row (Q7).

    Pattern §Q :compute-theorique — pas de migration UNIQUE constraint,
    DELETE-by-scope-spécifique évite les doublons par construction.

    Permissions L2 §13.4 = builder (sensibilité réglementaire des
    params GMP/PMP/GMPS).

    Freeze §S : 409 si document hors brouillon."""
    await document_freeze.require_brouillon(document_id, company_id)
    await _require_document(document_id, company_id)
    await _require_ets(payload.ets_id, company_id)
    params = payload.model_dump(mode="json", exclude={"ets_id"})
    row = await run_in_thread(
        forfait_repo.upsert_by_doc_ets,
        company_id=company_id,
        document_id=document_id,
        etablissement_id=payload.ets_id,
        params=params,
    )
    return ForfaitParametresRead.model_validate(row)


__all__ = [
    "list_forfait_parametres",
    "upsert_forfait_parametres",
]
