"""Service §AB — orchestration des exports (L2 §19).

Expose :

* :func:`export_xlsx` — build workbook + upload S3 + persist DB row
* :func:`list_exports` — historique d'un document
* :func:`get_download_bytes` — récupère les bytes depuis S3 pour streaming
* :func:`delete_export` — soft-delete

v0.2 supporte uniquement le cadre ERRD (D-091). Les autres types
retournent 422 ``xlsx_only_errd_v02``. Les types EPS (ERCP/EPCP) et
prévisionnels (EPRD/DM/RIA) seront ajoutés progressivement post-v0.2.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from piilot.sdk import storage
from piilot.sdk.db import run_in_thread
from pydantic import BaseModel, ConfigDict

from piilot_pack_compta_esms.exports.docx import rapport_builder as docx_builder
from piilot_pack_compta_esms.exports.xlsx import workbook_builder
from piilot_pack_compta_esms.repositories import document_repo, exports_repo
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
    ValidationError,
)

logger = logging.getLogger(__name__)

# Types supportés v0.2 — D-091 L5c §1 (XLSX).
_SUPPORTED_DOC_TYPES: frozenset[str] = frozenset({"errd"})

# Types supportés DOCX — §AC : EPRD + ERRD (rapport budgétaire R.314-223).
_SUPPORTED_DOCX_DOC_TYPES: frozenset[str] = frozenset({"eprd", "errd"})

# MIME type officiel XLSX.
XLSX_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

# MIME type officiel DOCX.
DOCX_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"


# ---------------------------------------------------------------------------
# DTOs publics
# ---------------------------------------------------------------------------


class ExportRead(BaseModel):
    """Row exports renvoyée via API."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    type: str
    s3_key: str
    filename: str
    file_size: int
    generated_by_user_id: UUID | None
    generated_at: datetime
    deleted_at: datetime | None
    created_at: datetime
    updated_at: datetime


class ExportXlsxRequest(BaseModel):
    """Body POST /export/xlsx."""

    model_config = ConfigDict(extra="forbid")

    include_recueil_consentement: bool = False


class ExportDocxRequest(BaseModel):
    """Body POST /export/docx — L2 §19.2.

    ``template_version`` accepté pour stabilité API mais ignoré v0.2
    (1 seul template from-scratch). Sera dispatché vers
    Générique/Bretagne en v0.3+."""

    model_config = ConfigDict(extra="forbid")

    template_version: str | None = None


# ---------------------------------------------------------------------------
# Helpers internes
# ---------------------------------------------------------------------------


async def _load_doc_or_404(document_id: UUID, company_id: UUID) -> dict[str, Any]:
    row = await run_in_thread(document_repo.get_by_id, document_id)
    if row is None or str(row["company_id"]) != str(company_id):
        raise NotFoundError(
            f"document_not_found:{document_id}",
            code="document_not_found",
        )
    return row


# ---------------------------------------------------------------------------
# export_xlsx — POST /documents/{id}/export/xlsx
# ---------------------------------------------------------------------------


async def export_xlsx(
    document_id: UUID,
    company_id: UUID,
    *,
    user_id: UUID | None,
    include_recueil_consentement: bool = False,
) -> ExportRead:
    """L2 §19.1 — génère le XLSX + upload S3 + persist DB row.

    Refuse 422 ``xlsx_only_errd_v02`` si type_document != errd.
    """
    document = await _load_doc_or_404(document_id, company_id)
    type_doc = document["type_document"]
    if type_doc not in _SUPPORTED_DOC_TYPES:
        raise ValidationError(
            f"Export XLSX uniquement supporté pour type_document='errd' en "
            f"v0.2 (got '{type_doc}'). Autres types arriveront progressivement.",
            code="xlsx_only_errd_v02",
        )

    # Charger l'exercice (pour le filename)
    exercice = await run_in_thread(document_repo.exercice_lookup, document["exercice_id"])

    # 1. Build le workbook (en bytes)
    try:
        xlsx_bytes = await workbook_builder.build_errd_workbook(
            document_id,
            company_id,
            document,
            include_recueil_consentement=include_recueil_consentement,
        )
    except ValueError as exc:
        # D-075 — pipe char dans une saisie
        raise ValidationError(
            f"Caractère '|' interdit dans une valeur DGCS — {exc}",
            code="pipe_char_forbidden",
        ) from exc

    # 2. Upload S3 — clé namespacée automatiquement par le SDK
    export_id = uuid4()
    filename = workbook_builder.derive_filename(document, exercice)
    s3_key = f"exports/{company_id}/{document_id}/{export_id}/{filename}"
    full_key = await storage.put_object(
        s3_key,
        xlsx_bytes,
        content_type=XLSX_CONTENT_TYPE,
    )

    # 3. Persist en DB (s3_key stocke la clé sans préfixe namespace —
    # le SDK rajoute "plugins/compta_esms/" au put_object, on stocke
    # ce que le SDK a retourné comme effective key MOINS le préfixe).
    # Convention v0.2 : on stocke la clé qu'on a passée (le SDK gère
    # le préfixe en transparent à get_object/delete_object).
    _ = full_key  # full key returned mais on stocke notre clé applicative
    row = await run_in_thread(
        exports_repo.create,
        company_id=company_id,
        document_id=document_id,
        type="xlsx",
        s3_key=s3_key,
        filename=filename,
        file_size=len(xlsx_bytes),
        generated_by_user_id=user_id,
    )
    return ExportRead.model_validate(row)


# ---------------------------------------------------------------------------
# export_docx — POST /documents/{id}/export/docx
# ---------------------------------------------------------------------------


async def export_docx(
    document_id: UUID,
    company_id: UUID,
    *,
    user_id: UUID | None,
    template_version: str | None = None,
) -> ExportRead:
    """L2 §19.2 — génère le rapport DOCX EPRD/ERRD + upload S3 + DB row.

    Refuse 422 ``docx_only_eprd_errd_v02`` si type_document ∉ {eprd, errd}.
    """
    document = await _load_doc_or_404(document_id, company_id)
    type_doc = document["type_document"]
    if type_doc not in _SUPPORTED_DOCX_DOC_TYPES:
        raise ValidationError(
            f"Export DOCX rapport budgétaire supporté pour type_document ∈ "
            f"{{eprd, errd}} en v0.2 (got '{type_doc}'). Autres types "
            f"arriveront progressivement.",
            code="docx_only_eprd_errd_v02",
        )

    # Charger l'exercice (pour le filename)
    exercice = await run_in_thread(document_repo.exercice_lookup, document["exercice_id"])

    # 1. Build le rapport (en bytes)
    try:
        docx_bytes = await docx_builder.build_rapport_docx(
            document_id,
            company_id,
            document,
            template_version=template_version,
        )
    except ValueError as exc:
        # D-075 — pipe char dans une saisie
        raise ValidationError(
            f"Caractère '|' interdit dans une valeur DGCS — {exc}",
            code="pipe_char_forbidden",
        ) from exc

    # 2. Upload S3 — clé namespacée automatiquement par le SDK
    export_id = uuid4()
    filename = docx_builder.derive_filename(document, exercice)
    s3_key = f"exports/{company_id}/{document_id}/{export_id}/{filename}"
    full_key = await storage.put_object(
        s3_key,
        docx_bytes,
        content_type=DOCX_CONTENT_TYPE,
    )
    _ = full_key

    # 3. Persist en DB
    row = await run_in_thread(
        exports_repo.create,
        company_id=company_id,
        document_id=document_id,
        type="docx",
        s3_key=s3_key,
        filename=filename,
        file_size=len(docx_bytes),
        generated_by_user_id=user_id,
    )
    return ExportRead.model_validate(row)


# ---------------------------------------------------------------------------
# list_exports — GET /documents/{id}/exports
# ---------------------------------------------------------------------------


async def list_exports(document_id: UUID, company_id: UUID) -> list[ExportRead]:
    """L2 §19.3 — historique exports actifs."""
    await _load_doc_or_404(document_id, company_id)
    rows = await run_in_thread(exports_repo.list_by_document, document_id)
    return [ExportRead.model_validate(r) for r in rows]


# ---------------------------------------------------------------------------
# get_download — GET /exports/{id}/download
# ---------------------------------------------------------------------------


async def get_download(export_id: UUID, company_id: UUID) -> tuple[bytes, str, str]:
    """L2 §19.4 — download streaming.

    Retourne ``(bytes, filename, content_type)`` pour FastAPI Response.
    Refuse 404 si l'export n'existe pas, est cross-tenant, ou est
    soft-deleted (les fichiers deleted ne sont plus accessibles).
    """
    row = await run_in_thread(exports_repo.get_by_id, export_id)
    if row is None:
        raise NotFoundError(f"export_not_found:{export_id}", code="export_not_found")
    if str(row["company_id"]) != str(company_id):
        raise NotFoundError(f"export_not_found:{export_id}", code="export_not_found")
    if row["deleted_at"] is not None:
        raise ConflictError(
            f"export {export_id} is soft-deleted — bytes no longer downloadable",
            code="export_deleted",
        )

    bytes_data = await storage.get_object(row["s3_key"])
    content_type = XLSX_CONTENT_TYPE if row["type"] == "xlsx" else DOCX_CONTENT_TYPE
    return bytes_data, row["filename"], content_type


# ---------------------------------------------------------------------------
# delete_export — DELETE /exports/{id}
# ---------------------------------------------------------------------------


async def delete_export(export_id: UUID, company_id: UUID) -> None:
    """L2 §19.5 — soft-delete. Idempotent."""
    row = await run_in_thread(exports_repo.get_by_id, export_id)
    if row is None:
        raise NotFoundError(f"export_not_found:{export_id}", code="export_not_found")
    if str(row["company_id"]) != str(company_id):
        raise NotFoundError(f"export_not_found:{export_id}", code="export_not_found")
    # Idempotent : si déjà delete, no-op silencieux (HTTP 204).
    await run_in_thread(exports_repo.soft_delete, export_id)
