"""Service layer for Compte de Résultat CRUD (L2 §5).

The default CRPP is auto-created by the document service (§E.3) at
``POST /documents`` (D-073). This layer exposes the operations on
top : list, explicitly create additional CRs (CRPA / CRP_SF / CRA_SF
or even a second CRPP for unusual setups), patch, delete, reorder.

Cross-tenant guards :

* ``create`` verifies the document belongs to the caller's company
  and, when an ``etablissement_id`` is supplied, that it too belongs
  to the caller's company.
* ``update`` / ``delete`` / ``reorder`` re-check via ``get_by_id`` +
  explicit ``company_id`` comparison (a 404 + 403 dance ; RLS would
  block the SELECT but the explicit check produces clearer errors).
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.cr import (
    CrCreate,
    CrRead,
    CrReorder,
    CrUpdate,
)
from piilot_pack_compta_esms.repositories import cr_repo
from piilot_pack_compta_esms.services import document_freeze, document_scope
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
    ValidationError,
)


def _to_read(row: dict[str, Any]) -> CrRead:
    return CrRead.model_validate(row)


async def list_crs(document_id: UUID) -> list[CrRead]:
    """Return CRs of a document, ordered by ``ordre`` then created_at."""
    rows = await run_in_thread(cr_repo.list_by_document, document_id)
    return [_to_read(r) for r in rows]


async def get_cr(cr_id: UUID) -> CrRead:
    row = await run_in_thread(cr_repo.get_by_id, cr_id)
    if row is None:
        raise NotFoundError(f"CR {cr_id} not found", code="cr_not_found")
    return _to_read(row)


async def create_cr(company_id: UUID, document_id: UUID, payload: CrCreate) -> CrRead:
    """Create an explicit CR under the given document.

    Validates :
    1. The document exists and belongs to the caller's company.
    2. If ``etablissement_id`` is supplied, it too is in the caller's
       company (404 otherwise to avoid leaking cross-tenant existence).
    """
    doc_ok = await run_in_thread(cr_repo.document_exists_for_company, document_id, company_id)
    if not doc_ok:
        raise NotFoundError(
            f"Document {document_id} not found",
            code="document_not_found_for_cr_create",
        )
    # Freeze §S — un CR ne peut être créé que sur un doc en brouillon.
    await document_freeze.require_brouillon(document_id, company_id)

    # §X D-060 — pas de CRPP sur ERCP/EPCP (le sanitaire global vit
    # dans l'EPRD EPS, pas dans l'extrait médico-social). On utilise
    # le helper ``document_scope.get_doc_type`` qui est mocké par la
    # fixture autouse conftest — les tests existants restent verts
    # sans avoir à mocker ``document_repo.get_by_id`` à la main.
    if payload.cr_type == "CRPP":
        doc_type = await document_scope.get_doc_type(document_id)
        if doc_type in document_scope.EPS_ONLY_DOC_TYPES:
            raise ValidationError(
                f"cr_type='CRPP' interdit sur un document '{doc_type}' "
                f"(D-060 — ERCP/EPCP n'ont que des CRs ANNEXE : CRPA, "
                f"CRA_SF, CRP_SF). KB22 §4.",
                code="crpp_forbidden_for_ercp_epcp",
            )

    if payload.etablissement_id is not None:
        ets_ok = await run_in_thread(
            cr_repo.etablissement_belongs_to_company,
            payload.etablissement_id,
            company_id,
        )
        if not ets_ok:
            raise NotFoundError(
                f"Établissement {payload.etablissement_id} not found",
                code="etablissement_not_found_for_cr_create",
            )

    # §V D-063 — Si le document est un DM, l'``etablissement_id`` doit
    # être dans le périmètre hérité du parent EPRD (KB23 §2.3). Pas de
    # guard si etablissement_id est NULL (CRP_SF par exemple).
    if payload.etablissement_id is not None:
        await _assert_dm_perimeter(document_id, payload.etablissement_id)

    row = await run_in_thread(
        cr_repo.create,
        company_id,
        document_id,
        payload.model_dump(exclude_none=True),
    )
    return _to_read(row)


async def _assert_dm_perimeter(document_id: UUID, etablissement_id: UUID) -> None:
    """Guard §V D-063 : pour un DM, l'``etablissement_id`` du CR doit
    appartenir à la liste ETS distincts du parent EPRD.

    No-op pour les autres types_document — seul DM hérite immuablement
    du périmètre du parent (KB23 §2.3).
    """
    ctx = await run_in_thread(cr_repo.get_doc_type_and_dm_perimeter, document_id)
    if ctx is None or ctx["type_document"] != "dm":
        return  # pas DM → pas de guard
    if etablissement_id not in ctx["parent_ets_ids"]:
        raise ValidationError(
            f"etablissement {etablissement_id} hors du périmètre du parent EPRD "
            f"(DM hérite immuablement de la liste d'établissements du parent — "
            f"D-063, KB23 §2.3)",
            code="dm_perimeter_breach",
        )


async def _ensure_company_owned(cr_id: UUID, company_id: UUID) -> dict[str, Any]:
    """Fetch a CR and assert tenant ownership.

    Returns the row on success ; raises :class:`NotFoundError` if the
    CR doesn't exist (or is read-blocked by RLS) and
    :class:`CrossCompanyError` if a defensive read slipped through.
    Centralized helper so the patch / delete / reorder paths stay
    short.
    """
    row = await run_in_thread(cr_repo.get_by_id, cr_id)
    if row is None:
        raise NotFoundError(f"CR {cr_id} not found", code="cr_not_found")
    if str(row["company_id"]) != str(company_id):
        raise CrossCompanyError(f"CR {cr_id} not accessible", code="cr_cross_company")
    return row


async def update_cr(company_id: UUID, cr_id: UUID, payload: CrUpdate) -> CrRead:
    """Patch a CR. ``cr_type`` is locked at create time.

    If the patch flips ``etablissement_id`` to a new value, the new
    établissement must also be in the caller's company.

    Freeze §S : 409 si document parent hors brouillon.
    """
    row_cr = await _ensure_company_owned(cr_id, company_id)
    await document_freeze.require_brouillon(row_cr["document_id"], company_id)

    if payload.etablissement_id is not None:
        ets_ok = await run_in_thread(
            cr_repo.etablissement_belongs_to_company,
            payload.etablissement_id,
            company_id,
        )
        if not ets_ok:
            raise NotFoundError(
                f"Établissement {payload.etablissement_id} not found",
                code="etablissement_not_found_for_cr_update",
            )
        # §V D-063 — si on patche l'ETS d'un CR DM, vérifier périmètre.
        await _assert_dm_perimeter(row_cr["document_id"], payload.etablissement_id)

    row = await run_in_thread(cr_repo.update, cr_id, payload.model_dump(exclude_unset=True))
    if row is None:
        raise NotFoundError(f"CR {cr_id} not found", code="cr_not_found")
    return _to_read(row)


async def delete_cr(company_id: UUID, cr_id: UUID) -> None:
    """Hard delete a CR (and its ``crp_lignes`` via FK CASCADE).

    No "last CRPP" guard — the L2 spec doesn't require one, and a
    cabinet may legitimately delete the auto-created CRPP to recreate
    a custom one. The frontend should warn before letting them ship
    a document without a CRPP, but that's UX not domain.

    Freeze §S : 409 si document parent hors brouillon.

    **§V D-063** : 409 ``dm_cr_immutable`` si le document est un DM —
    le DM hérite immuablement du périmètre du parent EPRD, le cabinet
    ne peut pas supprimer un CR hérité (KB23 §2.3).
    """
    row_cr = await _ensure_company_owned(cr_id, company_id)
    await document_freeze.require_brouillon(row_cr["document_id"], company_id)
    # §V D-063 — refus immutable sur DM
    ctx = await run_in_thread(cr_repo.get_doc_type_and_dm_perimeter, row_cr["document_id"])
    if ctx is not None and ctx["type_document"] == "dm":
        raise ConflictError(
            "CR ne peut pas être supprimé sur un DM (héritage immutable du "
            "périmètre du parent EPRD — D-063, KB23 §2.3). Créez une nouvelle "
            "version corrigée si nécessaire.",
            code="dm_cr_immutable",
        )
    deleted = await run_in_thread(cr_repo.delete, cr_id)
    if not deleted:
        raise NotFoundError(f"CR {cr_id} not found", code="cr_not_found")


async def reorder_cr(company_id: UUID, cr_id: UUID, payload: CrReorder) -> CrRead:
    """Set the CR's ``ordre`` to the requested value (L2 §5.5).

    We don't re-sequence siblings — the frontend computes the target
    position from its drag-and-drop result and sends it. Duplicate
    ``ordre`` values resolve via ``ORDER BY ordre, created_at`` in
    the list query, so insertion order acts as a stable tiebreaker.

    Freeze §S : 409 si document parent hors brouillon.
    """
    current = await _ensure_company_owned(cr_id, company_id)
    await document_freeze.require_brouillon(current["document_id"], company_id)
    if current["ordre"] == payload.ordre:
        # No-op — return the row unchanged to keep the endpoint
        # idempotent. Some frontend libraries fire reorder POSTs
        # eagerly during drag, so a no-op is the right behavior.
        return _to_read(current)

    row = await run_in_thread(cr_repo.update, cr_id, {"ordre": payload.ordre})
    if row is None:
        raise NotFoundError(f"CR {cr_id} not found", code="cr_not_found")
    return _to_read(row)


# Re-export for symmetry with the document service surface.
__all__ = [
    "list_crs",
    "get_cr",
    "create_cr",
    "update_cr",
    "delete_cr",
    "reorder_cr",
    "ConflictError",  # kept so test files can import it from one place
]
