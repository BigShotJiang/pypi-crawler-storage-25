"""Read-only service for ``compta_esms.feature_catalog`` (L2 §8).

The catalog is global (no company / no RLS — cf. §D.11 + §G.2), so
this service is a thin async wrapper around the repo. No write paths :
the catalog evolves through migrations, not API calls.

Filters semantics (matches ``feature_catalog_repo.list_all``) :

* ``doc_type=eprd`` keeps features whose ``applicable_doc_types``
  contains ``'eprd'`` or is empty.
* ``typologie=ehpad`` keeps features whose ``applicable_typologies``
  contains ``'ehpad'`` or is empty.

Empty-array-means-all is the seed convention (cf.
``003_seed_feature_catalog.sql``) — features with no typology
restriction always pass the typology filter.
"""

from __future__ import annotations

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.feature_catalog import FeatureCatalogRead
from piilot_pack_compta_esms.repositories import feature_catalog_repo
from piilot_pack_compta_esms.services.errors import NotFoundError


async def list_features(
    *,
    doc_type: str | None = None,
    typologie: str | None = None,
    mandatory_only: bool = False,
) -> list[FeatureCatalogRead]:
    rows = await run_in_thread(
        feature_catalog_repo.list_all,
        doc_type=doc_type,
        typologie=typologie,
        mandatory_only=mandatory_only,
    )
    return [FeatureCatalogRead.model_validate(r) for r in rows]


async def get_feature(feature_key: str) -> FeatureCatalogRead:
    row = await run_in_thread(feature_catalog_repo.get_by_key, feature_key)
    if row is None:
        raise NotFoundError(
            f"feature {feature_key!r} not in catalog",
            code="feature_not_found",
        )
    return FeatureCatalogRead.model_validate(row)
