"""PGFP service (§O, L2 §9).

Orchestre 3 fonctions :

* :func:`list_pgfp` — GET §9.1 (merge template :data:`PGFP_LINES_TEMPLATE`
  + DB rows, Q3 option (c))
* :func:`patch_pgfp` — PATCH §9.2 (upsert partiel par ``ligne_key``, Q4)
* :func:`recompute_pgfp` — POST §9.3 (recalcule blocs 2+3+4+5+6+7+8+10,
  fallback warnings Q7)

Garde-fous :

* **Q8** EPRD-only — refuser 422 si ``doc.type_document NOT IN ('eprd',
  'dm', 'ria')``.
* PATCH refuse les ``ligne_key`` inconnus du template (422).
* PATCH refuse de toucher les lignes ``is_computed=True`` (422 —
  réservées à :recompute).

Sémantique :recompute (Q6) — MVP v0.2 :

Le service applique les **formules locales** du PGFP (sommes inter-blocs)
à partir des lignes saisies déjà présentes en DB :

* Bloc 2 CAF : ``caf_flux_charges_total = Σ caf_flux_charges_fr*_*``,
  ``caf_flux_produits_total = Σ caf_flux_produits_fr*_*``,
  ``caf_total = caf_resultat_base + caf_flux_charges_total -
  caf_flux_produits_total``, ``caf_part_fri`` / ``caf_part_fre``
  (ventilation lors de la saisie — laissées à 0 si pas saisies)
* Bloc 3 FRI : ``fri_augmentation_total`` (Σ ``fri_aug_*``),
  ``fri_diminution_total`` (Σ ``fri_dim_*``), ``fri_variations =
  augmentation - diminution``, ``fri_cumule_fin = variations + initial``
* Bloc 4 FRE : symétrique
* Bloc 5 FRNG : ``frng_apport_prelevement = fri_variations +
  fre_variations``, ``frng_fin_periode = apport_prelevement + initial``
* Bloc 6 BFR : ``bfr_augmentation_total = Σ bfr_aug_*``,
  ``bfr_diminution_total = Σ bfr_dim_*``, ``bfr_variations =
  augmentation - diminution``, ``bfr_cumule_fin = variations + initial``
* Bloc 7 Trésorerie : ``tresorerie_variations = frng_apport_prelevement
  - bfr_variations``, ``tresorerie_fin_periode = variations + initiale``
* Bloc 8 Contrôles : laissés à NULL en MVP — le calcul vs Bilan est
  différé en §Z (a besoin de récupérer FRNG / Trésorerie du bilan
  financier, intégration profonde)
* Bloc 10 Ratios : laissés à NULL en MVP — la bibliothèque §I expose
  les calculs mais l'orchestration sur 8 exercices avec les inputs
  amont (encours emprunts, immo brut, etc.) est différée à un ticket
  suivi (§O' ou §Z).

L'intégration profonde §H (CRP totals) / §J (affectations) / §K (Bilan)
/ §N (Emprunts/Provisions) → :recompute reste un chantier transverse à
ouvrir séparément. Le MVP v0.2 calcule ce qui se déduit purement des
lignes saisies par le cabinet dans le PGFP lui-même.
"""

from __future__ import annotations

from decimal import Decimal
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.pgfp import (
    PGFP_LINES_TEMPLATE,
    PgfpLigneRead,
    PgfpPatchRequest,
    PgfpRecomputeResponse,
    PgfpRecomputeWarning,
    PgfpResponse,
    template_line,
)
from piilot_pack_compta_esms.repositories import pgfp_repo
from piilot_pack_compta_esms.services import document_freeze, document_scope
from piilot_pack_compta_esms.services.errors import (
    NotFoundError,
    ValidationError,
)

_ZERO = Decimal("0")
_PGFP_DOC_TYPES = ("eprd", "dm", "ria")
"""Q8 — PGFP n'existe que pour EPRD + dérivés (DM, RIA héritent et
révisent). Cf. 16-annexe1 §8 : 'PROJECTION PLURIANNUELLE PGFP ←
SPÉCIFIQUE EPRD'."""

_MONEY_COLUMNS: tuple[str, ...] = (
    "montant_nm1",
    "montant_n",
    "montant_np1",
    "montant_np2",
    "montant_np3",
    "montant_np4",
    "montant_np5",
    "montant_np6",
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(pgfp_repo.document_belongs_to_company, document_id, company_id)
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


async def _require_eprd_family(document_id: UUID, company_id: UUID) -> None:
    """Q8 — refuser 422 si doc.type_document ∉ {eprd, dm, ria}."""
    ctx = await run_in_thread(pgfp_repo.get_doc_type_document, document_id, company_id)
    if ctx is None:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )
    if ctx.get("type_document") not in _PGFP_DOC_TYPES:
        raise ValidationError(
            f"PGFP is only applicable to EPRD/DM/RIA documents, "
            f"got '{ctx.get('type_document')}'",
            code="pgfp_not_applicable",
        )


def _safe_decimal(value) -> Decimal:  # noqa: ANN001
    if value is None:
        return _ZERO
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def _row_to_montants(row: dict | None) -> dict[str, Decimal]:
    """Convert DB row (ou None) into 8-col Decimal dict avec ``_ZERO``
    fallback. Utilisé pour les calculs intra-PGFP."""
    if row is None:
        return {col: _ZERO for col in _MONEY_COLUMNS}
    return {col: _safe_decimal(row.get(col)) for col in _MONEY_COLUMNS}


# ---------------------------------------------------------------------------
# §9.1 — list_pgfp (merge template + DB sparse, Q3)
# ---------------------------------------------------------------------------


async def list_pgfp(document_id: UUID, company_id: UUID) -> PgfpResponse:
    """Merge :data:`PGFP_LINES_TEMPLATE` + DB rows. Toujours retourne
    le template complet (125 lignes), montants à None si pas en DB."""
    await _require_eprd_family(document_id, company_id)
    rows = await run_in_thread(pgfp_repo.list_by_document, document_id)
    by_key = {row["ligne_key"]: row for row in rows}
    items: list[PgfpLigneRead] = []
    for spec in PGFP_LINES_TEMPLATE:
        row = by_key.get(spec.ligne_key)
        if row is None:
            items.append(
                PgfpLigneRead(
                    id=None,
                    ligne_key=spec.ligne_key,
                    section=spec.section,
                    label=spec.label,
                    is_computed=spec.is_computed,
                )
            )
        else:
            items.append(
                PgfpLigneRead(
                    id=row["id"],
                    ligne_key=spec.ligne_key,
                    section=spec.section,
                    label=spec.label,
                    is_computed=spec.is_computed,
                    montant_nm1=row.get("montant_nm1"),
                    montant_n=row.get("montant_n"),
                    montant_np1=row.get("montant_np1"),
                    montant_np2=row.get("montant_np2"),
                    montant_np3=row.get("montant_np3"),
                    montant_np4=row.get("montant_np4"),
                    montant_np5=row.get("montant_np5"),
                    montant_np6=row.get("montant_np6"),
                    created_at=row.get("created_at"),
                    updated_at=row.get("updated_at"),
                )
            )
    return PgfpResponse(items=items)


# ---------------------------------------------------------------------------
# §9.2 — patch_pgfp (upsert partiel, Q4)
# ---------------------------------------------------------------------------


async def patch_pgfp(
    document_id: UUID,
    company_id: UUID,
    payload: PgfpPatchRequest,
) -> PgfpResponse:
    """PATCH partiel par ligne_key. Refuse :

    * ``ligne_key`` inconnu du template → 422 ``unknown_ligne_key``
    * ``ligne_key`` ``is_computed=True`` → 422 ``ligne_is_computed``
      (réservée à :recompute)

    Freeze §S : 409 si document hors brouillon.
    """
    await document_freeze.require_brouillon(document_id, company_id)
    await document_scope.assert_not_eps_only_doc(document_id)
    await _require_eprd_family(document_id, company_id)
    for item in payload.items:
        spec = template_line(item.ligne_key)
        if spec is None:
            raise ValidationError(
                f"unknown ligne_key '{item.ligne_key}'",
                code="unknown_ligne_key",
            )
        if spec.is_computed:
            raise ValidationError(
                f"ligne_key '{item.ligne_key}' is computed by :recompute "
                f"and cannot be PATCHed directly",
                code="ligne_is_computed",
            )
    # All items pass validation — upsert
    for item in payload.items:
        spec = template_line(item.ligne_key)
        assert spec is not None  # checked above
        montants = {
            "montant_nm1": item.montant_nm1,
            "montant_n": item.montant_n,
            "montant_np1": item.montant_np1,
            "montant_np2": item.montant_np2,
            "montant_np3": item.montant_np3,
            "montant_np4": item.montant_np4,
            "montant_np5": item.montant_np5,
            "montant_np6": item.montant_np6,
        }
        await run_in_thread(
            pgfp_repo.upsert_by_ligne_key,
            company_id=company_id,
            document_id=document_id,
            ligne_key=item.ligne_key,
            section=spec.section,
            ligne_label=spec.label,
            montants=montants,
        )
    return await list_pgfp(document_id, company_id)


# ---------------------------------------------------------------------------
# §9.3 — recompute_pgfp (formules locales blocs 2-7, Q6)
# ---------------------------------------------------------------------------


# Listes de saisies à sommer pour chaque agrégat computed
_SUM_GROUPS: dict[str, tuple[str, ...]] = {
    # Bloc 1 — CRP totals (sums Σ saisies G1/G2/G3)
    "crp_total_charges": (
        "crp_g1_charges",
        "crp_g2_charges",
        "crp_g3_charges",
    ),
    "crp_total_produits": (
        "crp_g1_produits_etat",
        "crp_g1_produits_assurance_maladie",
        "crp_g1_produits_departement",
        "crp_g1_produits_usager",
        "crp_g1_produits_autres_financeurs",
        "crp_g2_produits",
        "crp_g3_produits",
    ),
    # Bloc 2 — CAF
    "caf_flux_charges_total": (
        "caf_flux_charges_fri_vc_immo_cedees",
        "caf_flux_charges_fri_dot_amortissements",
        "caf_flux_charges_fri_dot_provisions_reglementees",
        "caf_flux_charges_fri_autres_dotations_68748",
        "caf_flux_charges_fri_reports_fonds_dedies_68921",
        "caf_flux_charges_fre_autres_dot_amort_provisions",
        "caf_flux_charges_fre_reports_fonds_dedies",
    ),
    "caf_flux_produits_total": (
        "caf_flux_produits_fri_reprises_provisions",
        "caf_flux_produits_fri_reprises_amort_78748",
        "caf_flux_produits_fri_quote_part_subventions",
        "caf_flux_produits_fri_quote_part_fonds_associatif",
        "caf_flux_produits_fri_cessions_immo",
        "caf_flux_produits_fri_utilisation_fonds_dedies_78921",
        "caf_flux_produits_fre_reprises_autres_provisions",
        "caf_flux_produits_fre_utilisation_fonds_dedies",
    ),
    # Bloc 3 — FRI augmentation/diminution
    "fri_augmentation_total": (
        "fri_aug_caf_part",
        "fri_aug_reserves_excedents_invest",
        "fri_aug_affectation_reserve_compensation",
        "fri_aug_apports_dotations_reserves_fonds_propres",
        "fri_aug_subventions_invest_c13",
        "fri_aug_emprunts_c16",
        "fri_aug_produits_cessions_immo",
        "fri_aug_comptes_liaison_invest_prives",
        "fri_aug_autres",
    ),
    "fri_diminution_total": (
        "fri_dim_fonds_propres_reserves_reduction",
        "fri_dim_remboursements_emprunts_anterieurs",
        "fri_dim_remboursements_emprunts_prevus_plan",
        "fri_dim_acquisitions_immo_incorporelles",
        "fri_dim_acquisitions_immo_terrains",
        "fri_dim_acquisitions_immo_agencements",
        "fri_dim_acquisitions_immo_constructions",
        "fri_dim_acquisitions_immo_installations",
        "fri_dim_acquisitions_immo_autres_corporelles",
        "fri_dim_acquisitions_immo_en_cours",
        "fri_dim_acquisitions_immo_financieres",
        "fri_dim_reprise_reserves_compensation",
        "fri_dim_charges_a_repartir",
        "fri_dim_comptes_liaison_invest_prives",
    ),
    # Bloc 4 — FRE augmentation/diminution
    "fre_augmentation_total": (
        "fre_aug_caf_part",
        "fre_aug_reprise_reserves_compensation",
        "fre_aug_comptes_liaison_treso_stable_prives",
        "fre_aug_autres",
    ),
    "fre_diminution_total": (
        "fre_dim_reprise_reserves_couverture_bfr_invest",
        "fre_dim_affectation_resultats_invest",
        "fre_dim_affectation_reserve_compensation",
        "fre_dim_comptes_liaison_treso_stable_prives",
        "fre_dim_autres",
    ),
    # Bloc 6 — BFR
    "bfr_augmentation_total": (
        "bfr_aug_stocks",
        "bfr_aug_creances",
        "bfr_aug_diminution_dettes_fournisseurs",
        "bfr_aug_autres",
    ),
    "bfr_diminution_total": (
        "bfr_dim_stocks",
        "bfr_dim_creances",
        "bfr_dim_augmentation_dettes_fournisseurs",
        "bfr_dim_autres",
    ),
}


async def recompute_pgfp(
    document_id: UUID,
    company_id: UUID,
) -> PgfpRecomputeResponse:
    """Recalcule les blocs 2+3+4+5+6+7. Blocs 8 (contrôles vs Bilan) +
    10 (ratios) laissés à NULL en MVP — intégration profonde §H/§J/§K/§N
    différée.

    Freeze §S : 409 si document hors brouillon (le :recompute pose
    des UPDATE sur les lignes calculées).
    """
    await document_freeze.require_brouillon(document_id, company_id)
    await document_scope.assert_not_eps_only_doc(document_id)
    await _require_eprd_family(document_id, company_id)
    rows = await run_in_thread(pgfp_repo.list_by_document, document_id)
    montants_by_key: dict[str, dict[str, Decimal]] = {
        row["ligne_key"]: _row_to_montants(row) for row in rows
    }
    warnings: list[PgfpRecomputeWarning] = []

    def _missing_warning(ligne_key: str, computed_key: str) -> None:
        warnings.append(
            PgfpRecomputeWarning(
                code="upstream_line_not_saisie",
                message=f"input ligne '{ligne_key}' not saisie — "
                f"'{computed_key}' computed with 0",
                ligne_key=ligne_key,
            )
        )

    def _sum_group(target_key: str, source_keys: tuple[str, ...]) -> dict[str, Decimal]:
        totals = {col: _ZERO for col in _MONEY_COLUMNS}
        for src_key in source_keys:
            src = montants_by_key.get(src_key)
            if src is None:
                _missing_warning(src_key, target_key)
                continue
            for col in _MONEY_COLUMNS:
                totals[col] += src[col]
        return totals

    # Compute all simple sums
    computed: dict[str, dict[str, Decimal]] = {}
    for target_key, source_keys in _SUM_GROUPS.items():
        computed[target_key] = _sum_group(target_key, source_keys)
        montants_by_key[target_key] = computed[target_key]

    # Bloc 1 — Résultat prévisionnel = produits - charges (computed)
    computed["crp_resultat_previsionnel"] = {
        col: computed["crp_total_produits"][col] - computed["crp_total_charges"][col]
        for col in _MONEY_COLUMNS
    }
    montants_by_key["crp_resultat_previsionnel"] = computed["crp_resultat_previsionnel"]

    # Bloc 2 — CAF total = résultat + flux charges - flux produits
    resultat_base = montants_by_key.get("caf_resultat_base") or {
        col: _ZERO for col in _MONEY_COLUMNS
    }
    if "caf_resultat_base" not in montants_by_key:
        _missing_warning("caf_resultat_base", "caf_total")
    computed["caf_total"] = {
        col: resultat_base[col]
        + computed["caf_flux_charges_total"][col]
        - computed["caf_flux_produits_total"][col]
        for col in _MONEY_COLUMNS
    }
    montants_by_key["caf_total"] = computed["caf_total"]

    # Bloc 3 — FRI variations + cumulé
    computed["fri_variations"] = {
        col: computed["fri_augmentation_total"][col] - computed["fri_diminution_total"][col]
        for col in _MONEY_COLUMNS
    }
    montants_by_key["fri_variations"] = computed["fri_variations"]
    fri_initial = montants_by_key.get("fri_initial") or {col: _ZERO for col in _MONEY_COLUMNS}
    if "fri_initial" not in montants_by_key:
        _missing_warning("fri_initial", "fri_cumule_fin")
    computed["fri_cumule_fin"] = {
        col: computed["fri_variations"][col] + fri_initial[col] for col in _MONEY_COLUMNS
    }

    # Bloc 4 — FRE variations + cumulé
    computed["fre_variations"] = {
        col: computed["fre_augmentation_total"][col] - computed["fre_diminution_total"][col]
        for col in _MONEY_COLUMNS
    }
    montants_by_key["fre_variations"] = computed["fre_variations"]
    fre_initial = montants_by_key.get("fre_initial") or {col: _ZERO for col in _MONEY_COLUMNS}
    if "fre_initial" not in montants_by_key:
        _missing_warning("fre_initial", "fre_cumule_fin")
    computed["fre_cumule_fin"] = {
        col: computed["fre_variations"][col] + fre_initial[col] for col in _MONEY_COLUMNS
    }

    # Bloc 5 — FRNG = FRI + FRE
    computed["frng_apport_prelevement"] = {
        col: computed["fri_variations"][col] + computed["fre_variations"][col]
        for col in _MONEY_COLUMNS
    }
    montants_by_key["frng_apport_prelevement"] = computed["frng_apport_prelevement"]
    frng_initial = montants_by_key.get("frng_initial") or {col: _ZERO for col in _MONEY_COLUMNS}
    if "frng_initial" not in montants_by_key:
        _missing_warning("frng_initial", "frng_fin_periode")
    computed["frng_fin_periode"] = {
        col: computed["frng_apport_prelevement"][col] + frng_initial[col] for col in _MONEY_COLUMNS
    }

    # Bloc 6 — BFR variations + cumulé
    computed["bfr_variations"] = {
        col: computed["bfr_augmentation_total"][col] - computed["bfr_diminution_total"][col]
        for col in _MONEY_COLUMNS
    }
    bfr_initial = montants_by_key.get("bfr_initial") or {col: _ZERO for col in _MONEY_COLUMNS}
    if "bfr_initial" not in montants_by_key:
        _missing_warning("bfr_initial", "bfr_cumule_fin")
    computed["bfr_cumule_fin"] = {
        col: computed["bfr_variations"][col] + bfr_initial[col] for col in _MONEY_COLUMNS
    }

    # Bloc 7 — Trésorerie
    computed["tresorerie_variations"] = {
        col: computed["frng_apport_prelevement"][col] - computed["bfr_variations"][col]
        for col in _MONEY_COLUMNS
    }
    tresorerie_initiale = montants_by_key.get("tresorerie_initiale") or {
        col: _ZERO for col in _MONEY_COLUMNS
    }
    if "tresorerie_initiale" not in montants_by_key:
        _missing_warning("tresorerie_initiale", "tresorerie_fin_periode")
    computed["tresorerie_fin_periode"] = {
        col: computed["tresorerie_variations"][col] + tresorerie_initiale[col]
        for col in _MONEY_COLUMNS
    }

    # Persist all computed lines (overwrite, not COALESCE)
    for ligne_key, montants in computed.items():
        spec = template_line(ligne_key)
        if spec is None:  # pragma: no cover — defensive
            continue
        await run_in_thread(
            pgfp_repo.overwrite_by_ligne_key,
            company_id=company_id,
            document_id=document_id,
            ligne_key=ligne_key,
            section=spec.section,
            ligne_label=spec.label,
            montants=montants,  # type: ignore[arg-type]
        )

    # Add a global note about Bloc 8 + 10 deferred (MVP v0.2)
    warnings.append(
        PgfpRecomputeWarning(
            code="bloc_8_10_deferred",
            message="Contrôles cohérence (bloc 8) and Ratios prévisionnels "
            "(bloc 10) are not computed in this MVP — deferred to a later "
            "ticket once §H/§J/§K/§N orchestration is wired.",
            ligne_key=None,
        )
    )

    # Re-fetch the full PGFP to return the post-recompute state
    response = await list_pgfp(document_id, company_id)
    return PgfpRecomputeResponse(items=response.items, warnings=warnings)


__all__ = [
    "list_pgfp",
    "patch_pgfp",
    "recompute_pgfp",
]
