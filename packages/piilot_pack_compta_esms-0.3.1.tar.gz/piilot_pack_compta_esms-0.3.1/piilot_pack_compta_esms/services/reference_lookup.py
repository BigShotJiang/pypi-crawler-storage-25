"""Lookups against core reference KBs (``kbs_reference.*``).

The plugin reads core-owned reference catalogs (PLT-T1 typologies,
PLT bonus conventions collectives, PLT-44 CNSA fonctions, PLT-43
audit controls, PLT-VG valeur point GIR, plan comptable ESMS M22Bis+M21)
to validate user input *dynamically* — without hardcoding the list
inside the plugin. When the DGCS publishes a new typologie or
modifies a convention collective, the cabinet picks it up on next
core sync, no plugin redeploy required.

The Piilot SDK doesn't (yet) expose a dedicated ``reference_lookup``
primitive — this module fills the gap by going down to
:func:`piilot.sdk.db.cursor` and reading the metadata tables
``public.knowledge_bases`` (slug → table_name) +
``public.kb_columns`` (logical name → pg_column) before SELECTing
the actual rows from ``kbs_reference.<table_name>``.

Both tables are declared in the plugin manifest's ``reads`` list, so
the future SQL allowlist enforcer won't reject these queries.

Cache policy
------------

Reference catalogs change at most a few times a year (DGCS publication
cycle). We cache the set of natural keys per slug in a module-level
dict, populated on first lookup. To pick up a sync without a process
restart, callers can invoke :func:`invalidate` after the admin sync
endpoint runs. This keeps validation latency at zero per request after
the first warm-up.
"""

from __future__ import annotations

import logging
import threading
from decimal import Decimal
from typing import Any

from piilot.sdk.db import cursor, run_in_thread

logger = logging.getLogger(__name__)

# Map slug → frozenset[natural_key_value]. Initialized lazily on the
# first call to :func:`list_codes`. Guarded by ``_LOCK`` because the
# loader may be threaded.
_CACHE: dict[str, frozenset[str]] = {}
_LOCK = threading.Lock()

# Map (code_departement, annee) → valeur_point_gir Decimal. Loaded
# lazily on first call to :func:`valeur_point_gir`. ``None`` while
# uninitialised so we can distinguish "not yet loaded" from "loaded
# but empty" (the latter is fail-open : the lookup returns None).
_VPG_CACHE: dict[tuple[str, int], Decimal] | None = None
_VPG_LOCK = threading.Lock()


def invalidate(slug: str | None = None) -> None:
    """Drop the cached code set for ``slug`` (or every slug if None).

    Call this after the core admin sync endpoint runs to refresh the
    plugin's view of the catalog without restarting the backend.
    Also clears the valeur-point-GIR cache when called without a slug.
    """
    global _VPG_CACHE
    with _LOCK:
        if slug is None:
            _CACHE.clear()
        else:
            _CACHE.pop(slug, None)
    if slug is None or slug == VALEUR_POINT_GIR_SLUG:
        with _VPG_LOCK:
            _VPG_CACHE = None


def _load_codes_sync(slug: str, natural_key_column: str) -> frozenset[str]:
    """Synchronous loader — read codes from the reference KB.

    Does two short SELECTs :

    1. ``public.knowledge_bases`` for ``(id, table_name)`` keyed by slug.
    2. ``public.kb_columns`` for the physical column name corresponding
       to the logical ``natural_key_column``.

    Then a final ``SELECT DISTINCT <pg_column> FROM
    kbs_reference.<table_name>`` to pull every natural key value.

    Failure modes :
    * Slug not found → empty set (no rows yet seeded — fail-open so
      validation doesn't block, just won't recognise any code).
    * Column not found → empty set with WARN log (schema drift between
      plugin expectation and core catalog).
    * SQL error → propagated to caller (let the service layer decide).
    """
    with cursor() as cur:
        cur.execute(
            "SELECT id, table_name FROM public.knowledge_bases " "WHERE slug = %s",
            (slug,),
        )
        kb_row = cur.fetchone()
        if kb_row is None:
            logger.warning(
                "reference_lookup: slug %r not found in knowledge_bases — "
                "validation will accept any value until the catalog is synced",
                slug,
            )
            return frozenset()

        kb_id = kb_row["id"]
        table_name = kb_row["table_name"]
        if not table_name:
            logger.warning(
                "reference_lookup: slug %r has no physical table_name yet "
                "(catalog not materialized)",
                slug,
            )
            return frozenset()

        cur.execute(
            "SELECT pg_column FROM public.kb_columns " "WHERE kb_id = %s AND name = %s",
            (str(kb_id), natural_key_column),
        )
        col_row = cur.fetchone()
        if col_row is None:
            logger.warning(
                "reference_lookup: column %r missing on KB %r",
                natural_key_column,
                slug,
            )
            return frozenset()

        pg_column = col_row["pg_column"]

        # ``table_name`` is sourced from public.knowledge_bases which is
        # populated by the core sync_service from a hardcoded slug → table
        # mapping. It can't be user-controlled, so the format string here
        # cannot be coerced into SQL injection.
        cur.execute(
            f"SELECT DISTINCT {pg_column} AS code "
            f"FROM kbs_reference.{table_name} "
            f"WHERE {pg_column} IS NOT NULL"
        )
        return frozenset(row["code"] for row in cur.fetchall() if row["code"])


async def list_codes(slug: str, natural_key_column: str = "code") -> frozenset[str]:
    """Return the cached set of natural keys for a reference catalog.

    First call populates the cache via :func:`_load_codes_sync` ;
    subsequent calls return the cached set. Thread-safe.
    """
    with _LOCK:
        cached = _CACHE.get(slug)
    if cached is not None:
        return cached

    loaded = await run_in_thread(_load_codes_sync, slug, natural_key_column)
    with _LOCK:
        _CACHE[slug] = loaded
    return loaded


async def exists(slug: str, value: str, natural_key_column: str = "code") -> bool:
    """Return True if ``value`` is a known natural key in the catalog.

    Falls through to True (fail-open) when the catalog is empty — the
    core sync hasn't run yet, blocking would lock the plugin out for
    the duration of a deployment. Logged at WARN.
    """
    codes = await list_codes(slug, natural_key_column)
    if not codes:
        # Fail-open: the warning has already been logged by ``_load_codes_sync``.
        return True
    return value in codes


# ---------------------------------------------------------------------------
# Catalog-specific helpers — slim API for the service layer
# ---------------------------------------------------------------------------

TYPOLOGIES_SLUG = "com.piilot.core.typologies-essms"
CONVENTIONS_COLLECTIVES_SLUG = "com.piilot.core.conventions-collectives-esms"
PLAN_COMPTABLE_ESMS_SLUG = "com.piilot.core.plan-comptable-esms"
VALEUR_POINT_GIR_SLUG = "com.piilot.core.valeur-point-gir-departemental"
CNSA_FONCTIONS_SLUG = "com.piilot.core.cnsa-fonctions-esms"
"""PLT-44 KB core : 10 catégories EHPAD + 8 FAM-SAMSAH/Autres × ~50
fonctions (D-043+D-044). Lookup naturel par ``categorie_code`` (10/8
valeurs) + ``fonction_libelle`` ou ``code``."""


async def typologie_exists(value: str) -> bool:
    """Validate that ``value`` is a known ESMS typology code (PLT-T1)."""
    return await exists(TYPOLOGIES_SLUG, value, "code")


async def convention_collective_exists(value: str) -> bool:
    """Validate that ``value`` is a known convention collective code."""
    return await exists(CONVENTIONS_COLLECTIVES_SLUG, value, "code")


async def compte_m22bis_exists(value: str) -> bool:
    """Validate that ``value`` is a known account number in the
    ``plan-comptable-esms`` KB ref (covers both M22Bis and M21 via the
    PLT-M21 extension).

    The natural key column in the core catalog is ``account_number``
    (cf. ``backend/services/reference_kb/catalogs/plan_comptable_esms.py``)
    — same numbers appear across both M22Bis and M21, so the
    fail-open check accepts any number that exists *somewhere* in the
    plan. Fine-grained M22Bis-only validation would need to filter on
    ``type='M22Bis'``, which v0.2 doesn't enforce (Q7 permissive).

    Used by §H to permissively check ``crp_lignes.compte_m22bis`` at
    create / patch / bulk-upsert time : a mismatch logs WARN but
    doesn't block (Q7 — fail-open, KB ref might be lagging behind
    DGCS releases and the cabinet is free to anticipate)."""
    return await exists(PLAN_COMPTABLE_ESMS_SLUG, value, "account_number")


async def cnsa_categorie_exists(value: str) -> bool:
    """Validate that ``value`` is a known CNSA category code (D-043+
    D-044). Fail-open : warns + returns True if PLT-44 KB ref is not
    yet synced or empty (cohérent §H.4 pattern)."""
    return await exists(CNSA_FONCTIONS_SLUG, value, "categorie_code")


async def cnsa_fonction_exists(value: str) -> bool:
    """Validate that ``value`` is a known CNSA function label (the
    ``fonction_libelle`` natural key of PLT-44). Fail-open."""
    return await exists(CNSA_FONCTIONS_SLUG, value, "fonction_libelle")


def deduce_variante_annexe5(typologie: str | None) -> str | None:
    """Map ESMS typology code → variante Annexe 5 (D-052+D-058) ou
    None si Annexe 5 ne s'applique pas.

    Mapping (KB20 §2 + KB21) :

    * ``ehpad``, ``aja``, ``puv`` → ``5A_ehpad`` (tarification ternaire)
    * ``fam``, ``samsah`` → ``5C_fam_samsah`` (forfait soins)
    * ``sad``, ``spasad`` → ``5D_sad_spasad`` (D-058 Soins / Aide)
    * **autres** (ime, itep, sessad, cmpp, esat, mas, foyer_*, etc.)
      → ``None`` — pas d'Annexe 5 pour ces typologies (B-31 ne
      propose pas de 5B Autres ESMS)

    Le service appelant lève ``ValidationError(code='annexe5_not_applicable')``
    quand le retour est ``None``."""
    if not typologie:
        return None
    code = typologie.lower().strip()
    if code in {"ehpad", "aja", "puv"} or code.startswith("ehpad_"):
        return "5A_ehpad"
    if code in {"fam", "samsah"} or code.startswith("fam_") or code.startswith("samsah_"):
        return "5C_fam_samsah"
    if code in {"sad", "spasad"} or code.startswith("sad_") or code.startswith("spasad_"):
        return "5D_sad_spasad"
    return None


def deduce_type_etablissement(typologie: str | None) -> str:
    """Map ESMS typology code (PLT-T1, 39+ valeurs) → ``type_etablissement``
    used by ``tper_ter_lignes.type_etablissement`` CHECK (4 valeurs).

    Mapping rules (cohérent D-046 mode_tarification × typologie) :

    * ``ehpad``, ``aja``, ``puv`` → ``ehpad_aja`` (R.314-232 9H, R.314-224 6A)
    * ``fam``, ``samsah`` → ``fam_samsah`` (R.314-232 9I)
    * ``sad``, ``spasad`` → ``sad_spasad``
    * everything else (ime, itep, sessad, cmpp, csapa, bapu, cafs,
      esat, camsp, mas, foyer_*, etc.) → ``autre_essms`` (R.314-232 9J)

    ``typologie`` ``None`` or unknown → ``autre_essms`` (safest fallback :
    8-catégories CNSA referent applies to "Autres ESSMS" too).
    """
    if not typologie:
        return "autre_essms"
    code = typologie.lower().strip()
    if code in {"ehpad", "aja", "puv"} or code.startswith("ehpad_"):
        return "ehpad_aja"
    if code in {"fam", "samsah"} or code.startswith("fam_") or code.startswith("samsah_"):
        return "fam_samsah"
    if code in {"sad", "spasad"} or code.startswith("sad_") or code.startswith("spasad_"):
        return "sad_spasad"
    return "autre_essms"


def _list_all_rows_sync(slug: str) -> list[dict[str, Any]]:
    """Return every row of the reference KB, fully projected.

    Used by the proxy routes ``GET /references/<slug>`` to surface the
    catalog to the frontend dropdowns. Pulls all columns named by
    ``kb_columns`` for the KB, not just the natural key.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT id, table_name FROM public.knowledge_bases " "WHERE slug = %s",
            (slug,),
        )
        kb_row = cur.fetchone()
        if kb_row is None or not kb_row["table_name"]:
            return []

        kb_id = kb_row["id"]
        table_name = kb_row["table_name"]

        cur.execute(
            "SELECT name, pg_column FROM public.kb_columns " "WHERE kb_id = %s ORDER BY position",
            (str(kb_id),),
        )
        columns = cur.fetchall()
        if not columns:
            return []

        # Build SELECT projection : alias each pg_column back to its
        # logical name so the API response is keyed by human-readable
        # fields (``code``, ``libelle``, …) rather than ``c_xxx`` UUIDs.
        select_clause = ", ".join(f'{c["pg_column"]} AS {c["name"]}' for c in columns)
        # Same safety note as ``_load_codes_sync``: table_name / pg_column
        # come from core-managed metadata, not user input.
        cur.execute(f"SELECT {select_clause} FROM kbs_reference.{table_name} " "ORDER BY 1")
        return cur.fetchall()


async def list_all_rows(slug: str) -> list[dict[str, Any]]:
    """Async wrapper around :func:`_list_all_rows_sync` for routes."""
    return await run_in_thread(_list_all_rows_sync, slug)


# Allowlist des colonnes filtrables côté ``list_filtered_rows`` — toute
# colonne non listée est rejetée (anti-injection sur ``pg_column`` du
# WHERE). Aligne avec les colonnes des KBs référentielles core dont la
# valeur est *naturelle* (TEXT discret, pas un blob libre).
_FILTERABLE_COLUMNS: frozenset[str] = frozenset(
    {"type", "version", "class_num", "code", "categorie_code"}
)


def _list_filtered_rows_sync(
    slug: str,
    filters: dict[str, Any] | None,
    limit: int | None,
) -> list[dict[str, Any]]:
    """Variante filtrée de :func:`_list_all_rows_sync` — ajoute WHERE
    sur les colonnes de ``filters`` (ANDés). ``limit`` cap optionnel.

    Pour rester safe vs injection : les clés de ``filters`` doivent
    être dans :data:`_FILTERABLE_COLUMNS`. Le code lève silencieusement
    si une clé non whitelistée est passée — le caller est responsable
    de valider en amont (route layer).
    """
    if filters:
        unknown = set(filters) - _FILTERABLE_COLUMNS
        if unknown:
            raise ValueError(f"unsupported filter columns: {sorted(unknown)}")

    with cursor() as cur:
        cur.execute(
            "SELECT id, table_name FROM public.knowledge_bases WHERE slug = %s",
            (slug,),
        )
        kb_row = cur.fetchone()
        if kb_row is None or not kb_row["table_name"]:
            return []

        kb_id = kb_row["id"]
        table_name = kb_row["table_name"]

        cur.execute(
            "SELECT name, pg_column FROM public.kb_columns WHERE kb_id = %s ORDER BY position",
            (str(kb_id),),
        )
        columns = cur.fetchall()
        if not columns:
            return []

        # Map logical name → pg_column. Vérifie que chaque filter porte
        # sur une colonne définie côté KB (silencieusement skip sinon).
        name_to_pg = {c["name"]: c["pg_column"] for c in columns}
        where_clauses: list[str] = []
        params: list[Any] = []
        if filters:
            for name, value in filters.items():
                if name not in name_to_pg:
                    continue  # filter sur une colonne absente de la KB
                where_clauses.append(f"{name_to_pg[name]} = %s")
                params.append(value)

        select_clause = ", ".join(f'{c["pg_column"]} AS {c["name"]}' for c in columns)
        where_sql = f"WHERE {' AND '.join(where_clauses)} " if where_clauses else ""
        limit_sql = f"LIMIT {int(limit)}" if limit else ""
        # table_name / pg_column from core-managed metadata, not user input.
        cur.execute(
            f"SELECT {select_clause} FROM kbs_reference.{table_name} "
            f"{where_sql}"
            f"ORDER BY 1 {limit_sql}",
            params,
        )
        return cur.fetchall()


async def list_filtered_rows(
    slug: str,
    *,
    filters: dict[str, Any] | None = None,
    limit: int | None = None,
) -> list[dict[str, Any]]:
    """Async wrapper around :func:`_list_filtered_rows_sync`."""
    return await run_in_thread(_list_filtered_rows_sync, slug, filters, limit)


# ---------------------------------------------------------------------------
# Valeur point GIR départemental (PLT-VG) — §I.2
# ---------------------------------------------------------------------------
#
# The core catalog stores one row per (code_departement, annee) with
# the field ``valeur_point_gir``. We cache the full ``(code, annee) →
# Decimal`` table on first lookup since the dataset is tiny (101
# départements × ~3 millésimes ≈ 300 rows) and the calculators in §I
# call this on every dependence-related computation.
#
# Clapet anti-retour R.314-175 : ``valeur(N) >= valeur(N-1)`` is a
# regulatory floor. :func:`valeur_point_gir_with_clapet` enforces it ;
# :func:`valeur_point_gir` returns the raw value (for callers that
# need to inspect a regression).


def _load_valeur_point_gir_sync() -> dict[tuple[str, int], Decimal]:
    """Load every (code_departement, annee) → valeur from the PLT-VG KB.

    Returns an empty dict when the catalog isn't synced yet
    (fail-open : the calculators downstream surface a None valeur and
    flag the estimation)."""
    rows = _list_all_rows_sync(VALEUR_POINT_GIR_SLUG)
    out: dict[tuple[str, int], Decimal] = {}
    for row in rows:
        code = row.get("code_departement")
        annee = row.get("annee")
        valeur = row.get("valeur_point_gir")
        if code is None or annee is None or valeur is None:
            continue
        try:
            out[(str(code), int(annee))] = Decimal(str(valeur))
        except (ValueError, ArithmeticError):
            logger.warning(
                "reference_lookup: bad VPG row (%r, %r, %r) — skipped",
                code,
                annee,
                valeur,
            )
    return out


async def _ensure_vpg_loaded() -> dict[tuple[str, int], Decimal]:
    """Lazy-load the VPG cache. Subsequent calls return the cached
    dict instantly. Thread-safe via :data:`_VPG_LOCK`."""
    global _VPG_CACHE
    with _VPG_LOCK:
        cached = _VPG_CACHE
    if cached is not None:
        return cached
    loaded = await run_in_thread(_load_valeur_point_gir_sync)
    with _VPG_LOCK:
        _VPG_CACHE = loaded
    return loaded


async def valeur_point_gir(code_departement: str, annee: int) -> Decimal | None:
    """Raw lookup — returns the catalog's value for (code, annee) or
    None if absent. The clapet anti-retour is NOT applied here."""
    cache = await _ensure_vpg_loaded()
    return cache.get((code_departement, int(annee)))


async def valeur_point_gir_with_clapet(
    code_departement: str, annee: int
) -> tuple[Decimal | None, bool, int | None]:
    """Apply the R.314-175 anti-retour clapet : the returned value is
    ``max(valeur(N), valeur(N-1))`` if both are present.

    Returns ``(valeur, clapet_applique, fallback_annee)`` where :

    * ``valeur`` is the post-clapet value (None if neither N nor N-1
      is in the catalog),
    * ``clapet_applique`` is True when the floor was raised — i.e. the
      catalog had ``valeur(N) < valeur(N-1)`` and we returned the
      higher N-1 value,
    * ``fallback_annee`` is the year actually used (N or N-1) — None
      when both are absent.
    """
    cache = await _ensure_vpg_loaded()
    raw_n = cache.get((code_departement, int(annee)))
    raw_n_minus_1 = cache.get((code_departement, int(annee) - 1))

    if raw_n is None and raw_n_minus_1 is None:
        return None, False, None
    if raw_n is None:
        return raw_n_minus_1, False, int(annee) - 1
    if raw_n_minus_1 is None:
        return raw_n, False, int(annee)
    if raw_n < raw_n_minus_1:
        return raw_n_minus_1, True, int(annee) - 1
    return raw_n, False, int(annee)
