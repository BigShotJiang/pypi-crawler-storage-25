"""Annexe 4 Activité GIR service (§Q, L2 §12).

Orchestre 3 endpoints :

* :func:`list_activite` — GET §12.1 (filtres optionnels ets_id +
  annexe_variante)
* :func:`bulk_upsert_activite` — POST §12.2 (replace_by_(doc, ets,
  annexe_variante) Q1)
* :func:`compute_theorique` — POST §12.3 (D-051 calcul ``nombre_journees =
  capacite_financee × amplitude_ouverture`` × sections × 5 années,
  idempotent Q4)

Permissions L2 §12 strict (Q12) : **user partout**.

Validation cohérence section ↔ annexe_variante + GIR EHPAD obligatoire
+ R.314-174 modulation absences → **différé §Z** (fail-open §Q comme
§H/§K/§N).

Hors scope §Q (documenté tickets suivi) :

* B-28 Creton 27 cols détail (D-097) — flag ``mode_creton`` seul ici
* B-30 Pondération mensuelle capacité (D-051 raffinement) — différé
* D-048 ETS schema partial — manque ``capacite_autorisee``,
  ``capacite_installee``, décomposition EHPAD ``HP/UHR/PASA/HT/AJ``
"""

from __future__ import annotations

import logging
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.activite import (
    ActiviteBulkUpsertRequest,
    ActiviteComputeTheoriqueResponse,
    ActiviteLigneRead,
    ActiviteResponse,
    AnnexeVariante,
)
from piilot_pack_compta_esms.repositories import activite_repo
from piilot_pack_compta_esms.services import document_freeze, document_scope
from piilot_pack_compta_esms.services.errors import NotFoundError

logger = logging.getLogger(__name__)


# Mapping annexe_variante → sections relevantes pour :compute-theorique
# (KB19 §2 routage). Permissif côté :bulk-upsert (Q7 fail-open),
# strict ici parce qu'on doit savoir QUELLES sections matérialiser.
_SECTIONS_BY_ANNEXE: dict[str, tuple[str, ...]] = {
    # 4A/9A EHPAD-AJA → HP / HT / AJ
    "4A_ehpad_puv": ("hp", "ht", "aj"),
    "9A_ehpad_realise": ("hp", "ht", "aj"),
    # 4B/9B Autres ESSMS → externat / semi_internat / internat
    "4B_autres_essms": ("externat", "semi_internat", "internat"),
    "9B_autres_realise": ("externat", "semi_internat", "internat"),
    # 4C/9C Creton — variante simplifiée v0.2 (mode_creton flag), même
    # sections que 4B/9B (le détail des règles dérogatoires L.242-4
    # est différé v0.5, cf. KB19 §15 B-28)
    "4C_creton": ("externat", "semi_internat", "internat"),
    "9C_creton_realise": ("externat", "semi_internat", "internat"),
    # 4D/9D SAAD → soins_domicile / aide_domicile
    "4D_sad_spasad": ("soins_domicile", "aide_domicile"),
    "9D_sad_realise": ("soins_domicile", "aide_domicile"),
}


# Plage annee_offset pour :compute-theorique (D-098)
_THEORIQUE_OFFSETS_ANNEXE4: tuple[int, ...] = (-4, -3, -2, -1, 0)
"""Annexe 4 (prévisionnel) : N-4 → N. KB19 §6.3.3 tableau."""

_THEORIQUE_OFFSETS_ANNEXE9: tuple[int, ...] = (-3, -2, -1, 0)
"""Annexe 9 (réalisé) : N-3 → N (D-098)."""


def _offsets_for_annexe(annexe_variante: str) -> tuple[int, ...]:
    """Annexe 4* → 5 années (N-4..N), Annexe 9* → 4 années (N-3..N)."""
    return (
        _THEORIQUE_OFFSETS_ANNEXE9
        if annexe_variante.startswith("9")
        else _THEORIQUE_OFFSETS_ANNEXE4
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(activite_repo.document_belongs_to_company, document_id, company_id)
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


async def _require_ets(etablissement_id: UUID, company_id: UUID) -> dict:
    """Defense in depth + retourne capacite pour :compute-theorique."""
    ctx = await run_in_thread(activite_repo.get_ets_capacite, etablissement_id, company_id)
    if ctx is None:
        raise NotFoundError(
            f"etablissement {etablissement_id} not found for this company",
            code="etablissement_not_found",
        )
    return ctx


# ---------------------------------------------------------------------------
# §12.1 — list_activite
# ---------------------------------------------------------------------------


async def list_activite(
    document_id: UUID,
    company_id: UUID,
    ets_id: UUID | None = None,
    annexe_variante: AnnexeVariante | None = None,
) -> ActiviteResponse:
    """Liste avec filtres optionnels (Q5 — query param ``annexe`` côté
    API, map vers ``annexe_variante``)."""
    await _require_document(document_id, company_id)
    rows = await run_in_thread(activite_repo.list_by_filter, document_id, ets_id, annexe_variante)
    return ActiviteResponse(
        ets_id_filtre=ets_id,
        annexe_filtre=annexe_variante,
        items=[ActiviteLigneRead.model_validate(r) for r in rows],
    )


# ---------------------------------------------------------------------------
# §12.2 — bulk_upsert_activite (Q1 replace_by_doc_ets_annexe)
# ---------------------------------------------------------------------------


async def bulk_upsert_activite(
    document_id: UUID,
    company_id: UUID,
    payload: ActiviteBulkUpsertRequest,
) -> ActiviteResponse:
    """Replace by (doc, ets, annexe_variante) — atomique (Q1).

    Validation cohérence section ↔ annexe / GIR EHPAD obligatoire →
    différée §Z (fail-open §Q). Le DDL CHECK couvre la liste globale
    des 8 sections + 9 GIR + 8 annexes.

    Freeze §S : 409 si document hors brouillon."""
    await document_freeze.require_brouillon(document_id, company_id)
    await document_scope.assert_not_eps_only_doc(document_id)
    await _require_document(document_id, company_id)
    await _require_ets(payload.ets_id, company_id)

    items_dict = [item.model_dump(mode="json") for item in payload.items]
    await run_in_thread(
        activite_repo.replace_by_doc_ets_annexe,
        company_id=company_id,
        document_id=document_id,
        etablissement_id=payload.ets_id,
        annexe_variante=payload.annexe_variante,
        items=items_dict,
    )
    return await list_activite(
        document_id,
        company_id,
        ets_id=payload.ets_id,
        annexe_variante=payload.annexe_variante,
    )


# ---------------------------------------------------------------------------
# §12.3 — compute_theorique (Q3+Q4 D-051 idempotent)
# ---------------------------------------------------------------------------


async def compute_theorique(
    document_id: UUID,
    company_id: UUID,
    ets_id: UUID,
    annexe_variante: AnnexeVariante,
) -> ActiviteComputeTheoriqueResponse:
    """D-051 — ``Activité théorique = capacite_financee × jours_ouverture``.

    Matérialise 1 ligne par (section × annee_offset) avec ``gir=NULL``,
    ``nature_donnee='theorique'``, ``nombre_journees`` calculé.

    Idempotent (Q4) : DELETE WHERE (doc, ets, annexe, nature='theorique')
    + INSERT batch. Plusieurs appels successifs produisent le même
    résultat.

    Limitation v0.2 : la pondération mensuelle (cas d'installation en
    cours d'année — KB19 §15 B-30) n'est pas appliquée. Toutes les
    années sortent avec la même valeur ``capacite_financee × amplitude``.

    Freeze §S : 409 si document hors brouillon (même si :compute n'est
    pas un mutateur métier au sens strict, il pose des rows nouvelles).
    """
    await document_freeze.require_brouillon(document_id, company_id)
    await document_scope.assert_not_eps_only_doc(document_id)
    await _require_document(document_id, company_id)
    ets_ctx = await _require_ets(ets_id, company_id)
    capacite_financee = int(ets_ctx.get("capacite_financee") or 0)
    amplitude_ouverture = int(ets_ctx.get("amplitude_ouverture") or 0)
    nombre_journees = capacite_financee * amplitude_ouverture

    sections = _SECTIONS_BY_ANNEXE.get(annexe_variante, ())
    offsets = _offsets_for_annexe(annexe_variante)

    items: list[dict] = []
    for section in sections:
        for offset in offsets:
            items.append(
                {
                    "section": section,
                    "gir": None,
                    "annee_offset": offset,
                    "nature_donnee": "theorique",
                    "mode_creton": annexe_variante
                    in (
                        "4C_creton",
                        "9C_creton_realise",
                    ),
                    "nombre_places": capacite_financee,
                    "nombre_journees": nombre_journees,
                }
            )

    # Capture pre-count for "inserted" vs "updated" semantics. Since
    # we DELETE+INSERT inside one transaction, technically every row
    # is fresh-inserted ; we count the prior rows as "updated" for
    # client-visible idempotency feedback (cohérent §H.6 / §P prefill
    # `{inserted, updated, skipped}` shape).
    existing_count_rows = await run_in_thread(
        activite_repo.list_by_filter, document_id, ets_id, annexe_variante
    )
    prior_theorique = sum(1 for r in existing_count_rows if r.get("nature_donnee") == "theorique")

    await run_in_thread(
        activite_repo.replace_theorique_by_doc_ets_annexe,
        company_id=company_id,
        document_id=document_id,
        etablissement_id=ets_id,
        annexe_variante=annexe_variante,
        items=items,
    )

    total = len(items)
    updated = min(prior_theorique, total)
    inserted = total - updated

    return ActiviteComputeTheoriqueResponse(
        capacite_financee=capacite_financee,
        amplitude_ouverture=amplitude_ouverture,
        nombre_journees_theorique=nombre_journees,
        inserted=inserted,
        updated=updated,
    )


__all__ = [
    "list_activite",
    "bulk_upsert_activite",
    "compute_theorique",
]
