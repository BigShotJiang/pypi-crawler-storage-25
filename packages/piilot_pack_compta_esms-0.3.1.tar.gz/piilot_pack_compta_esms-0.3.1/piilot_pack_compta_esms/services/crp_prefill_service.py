"""Prefill CRP lignes from a §G binding (§H.6, L2 §6.6).

Connects §G's :func:`binding_service.preview_binding` (which runs the
aggregation against the bound KB) to §H's
:func:`crp_ligne_repo.bulk_upsert` (which writes one row per compte).

The feature → ``(groupe, nature)`` mapping is hard-coded here :

* ``crp_charges_g1`` → ``(G1, charge)``
* ``crp_charges_g2`` → ``(G2, charge)``
* ``crp_charges_g3`` → ``(G3, charge)``
* ``crp_produits``   → ``(G1, produit)`` — v0.2 simplification : all
  produits land in G1 (the tarification group, where 95 % of an ESMS's
  produits live anyway). The cabinet can move individual lignes to
  G2/G3 manually via PATCH if needed. A finer-grained "compute groupe
  from compte's class" pass is on the §I roadmap.

Lignes whose ``override_balance`` is true are skipped — the cabinet's
manual edit on a previously-bound row stays untouched (Q6). The
response per feature reports ``inserted`` / ``updated`` / ``skipped_overridden``
so the UI can show "12 new, 47 refreshed, 3 protected".
"""

from __future__ import annotations

import logging
from decimal import Decimal
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.crp_ligne import (
    MontantColumn,
    PrefillFeatureResult,
    PrefillFromBindingResponse,
)
from piilot_pack_compta_esms.repositories import crp_ligne_repo, kb_binding_repo
from piilot_pack_compta_esms.services import binding_service, document_freeze
from piilot_pack_compta_esms.services.errors import NotFoundError

logger = logging.getLogger(__name__)


# Feature → (groupe, nature) for §H. Features outside this map don't
# target compta_esms.crp_lignes (e.g. tper_effectifs targets
# tper_ter_lignes — that prefill flow lives in §Q).
_FEATURE_TO_GROUPE_NATURE: dict[str, tuple[str, str]] = {
    "crp_charges_g1": ("G1", "charge"),
    "crp_charges_g2": ("G2", "charge"),
    "crp_charges_g3": ("G3", "charge"),
    "crp_produits": ("G1", "produit"),
}


def _row_montant(row: dict, montant_field: str = "montant") -> Decimal | None:
    """Extract a Decimal montant from a binding preview row. The
    binding contract for CRP features always names the measure column
    ``montant``, so the lookup is single-key. Returns None when the
    row carries no aggregable value (the bulk-upsert skips it)."""
    value = row.get(montant_field)
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


async def prefill_from_binding(
    *,
    cr_id: UUID,
    company_id: UUID,
    feature_keys: list[str],
    target_column: MontantColumn,
) -> PrefillFromBindingResponse:
    """Run the prefill for one or more features against the CR.

    Steps :

    1. Resolve the CR's ``document_id`` (defense in depth — refuses a
       cr_id of another tenant).
    2. Fetch the set of ``(groupe, nature, compte_m22bis)`` tuples
       already overridden in the CR — these rows are skipped.
    3. For each feature_key :
       a. Reject if not in :data:`_FEATURE_TO_GROUPE_NATURE` (404).
       b. Fetch the binding row from
          :mod:`kb_binding_repo` to grab ``binding_id`` (used as
          provenance on the new lignes).
       c. Call :func:`binding_service.preview_binding` to get the
          aggregated rows (one per compte). Bubble its NotFoundError
          if the binding doesn't exist yet — the cabinet must
          configure §G first.
       d. Build the bulk-upsert payload : each preview row becomes
          one item with the target_column set to the aggregated
          montant. Rows that hit an overridden key are filtered out
          (counter += skipped_overridden).
       e. Bulk-upsert with ``binding_id=<feature's binding id>`` —
          the rows carry the provenance and a future PATCH triggers
          the Q6 auto-flip.
    """
    # 1. CR context
    cr_ctx = await run_in_thread(crp_ligne_repo.get_cr_context, cr_id)
    if cr_ctx is None:
        raise NotFoundError(f"cr {cr_id} not found", code="cr_not_found")
    # _require_cr-style company guard — re-using cr_belongs_to_company
    # is cheaper than another join here.
    owns = await run_in_thread(crp_ligne_repo.cr_belongs_to_company, cr_id, company_id)
    if not owns:
        raise NotFoundError(f"cr {cr_id} not found for this company", code="cr_not_found")
    document_id = cr_ctx["document_id"]

    # Freeze §S — refuse prefill sur un doc qui n'est plus en brouillon
    await document_freeze.require_brouillon(document_id, company_id)

    # 2. Overridden keys to skip
    overridden = await run_in_thread(crp_ligne_repo.list_overridden_keys, cr_id)

    # 3. Per-feature loop
    results: list[PrefillFeatureResult] = []
    for feature_key in feature_keys:
        gn = _FEATURE_TO_GROUPE_NATURE.get(feature_key)
        if gn is None:
            raise NotFoundError(
                f"feature {feature_key!r} does not target compta_esms.crp_lignes "
                "(see §H.6 _FEATURE_TO_GROUPE_NATURE)",
                code="feature_not_prefillable",
            )
        groupe, nature = gn

        binding_row = await run_in_thread(
            kb_binding_repo.get_by_doc_feature, document_id, feature_key
        )
        if binding_row is None:
            raise NotFoundError(
                f"no binding for feature {feature_key!r} on document {document_id} "
                "— configure §G binding first",
                code="binding_not_found",
            )
        binding_id = UUID(str(binding_row["id"]))

        preview = await binding_service.preview_binding(
            document_id=document_id,
            feature_key=feature_key,
            company_id=company_id,
            filters={},
        )

        items: list[dict] = []
        skipped = 0
        for preview_row in preview.rows:
            data = preview_row.data
            compte = data.get("compte")
            if not compte:
                # Defensive — should not happen with the standard CRP
                # contract that requires the ``compte`` column.
                continue
            compte = str(compte)
            if (groupe, nature, compte) in overridden:
                skipped += 1
                continue
            montant = _row_montant(data)
            if montant is None:
                # Nothing to write — skip silently
                continue
            items.append(
                {
                    "groupe": groupe,
                    "nature": nature,
                    "compte_m22bis": compte,
                    "compte_label": data.get("compte_label"),
                    target_column: montant,
                    "saisie_manuelle": False,
                    "notes": None,
                }
            )

        # 3.e Bulk-upsert. We need to distinguish "inserted" from
        # "updated" — easy via the returned row's created_at == updated_at.
        rows = await run_in_thread(
            crp_ligne_repo.bulk_upsert,
            company_id=company_id,
            cr_id=cr_id,
            items=items,
            binding_id=binding_id,
        )
        inserted = sum(1 for r in rows if r["created_at"] == r["updated_at"])
        updated = len(rows) - inserted
        results.append(
            PrefillFeatureResult(
                feature_key=feature_key,
                inserted=inserted,
                updated=updated,
                skipped_overridden=skipped,
            )
        )

    return PrefillFromBindingResponse(target_column=target_column, results=results)
