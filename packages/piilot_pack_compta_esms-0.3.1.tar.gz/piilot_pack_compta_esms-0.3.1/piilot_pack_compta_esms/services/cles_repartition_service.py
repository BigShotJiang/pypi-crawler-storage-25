"""Service §Y CRUD ``cles_repartition_charges_communes`` (D-057).

Encapsule la logique non-DB :

* validation tenant + ETS belongs (404 si cross-tenant)
* conflict-check sur la natural key (409 cles_repartition_duplicate)
* soft WARN stabilité année/année (KB20 §8.2) — compare avec N-1
* bulk-upsert atomique avec batch insert/update via le repo
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.cles_repartition import (
    ClesRepartitionBulkUpsertRequest,
    ClesRepartitionCreate,
    ClesRepartitionRead,
    ClesRepartitionUpdate,
)
from piilot_pack_compta_esms.repositories import cles_repartition_repo
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
)

logger = logging.getLogger(__name__)


def _to_read(row: dict[str, Any]) -> ClesRepartitionRead:
    return ClesRepartitionRead.model_validate(row)


def _warn_year_diff(
    etablissement_id: UUID,
    compte_m22bis: str,
    new_taux: tuple[Decimal, Decimal, Decimal, Decimal],
    n_minus_1: dict[str, Any] | None,
) -> None:
    """KB20 §8.2 stabilité année/année — log WARN si écart vs N-1.

    Pas d'enforcement strict (D-057 reporté v0.3 avec contexte CPOM).
    Le WARN est utile pour les audits et l'agent IA qui pourra
    signaler au cabinet.
    """
    if n_minus_1 is None:
        return
    h, d, s, sea = new_taux
    if (
        Decimal(n_minus_1["taux_hebergement"]) != h
        or Decimal(n_minus_1["taux_dependance"]) != d
        or Decimal(n_minus_1["taux_soins"]) != s
        or Decimal(n_minus_1["taux_soins_autonomie"]) != sea
    ):
        logger.warning(
            "cles_repartition: taux différent de N-1 pour ets=%s compte=%s "
            "(N-1: h=%s d=%s s=%s sea=%s ; N: h=%s d=%s s=%s sea=%s). "
            "KB20 §8.2 — stabilité année/année recommandée.",
            etablissement_id,
            compte_m22bis,
            n_minus_1["taux_hebergement"],
            n_minus_1["taux_dependance"],
            n_minus_1["taux_soins"],
            n_minus_1["taux_soins_autonomie"],
            h,
            d,
            s,
            sea,
        )


async def list_cles_repartition(
    etablissement_id: UUID,
    company_id: UUID,
    *,
    compte_m22bis: str | None = None,
    exercice_annee: int | None = None,
) -> list[ClesRepartitionRead]:
    """GET /etablissements/{ets_id}/cles-repartition — list filtrable."""
    owns = await run_in_thread(
        cles_repartition_repo.etablissement_belongs_to_company,
        etablissement_id,
        company_id,
    )
    if not owns:
        raise NotFoundError(
            f"Établissement {etablissement_id} not found",
            code="etablissement_not_found",
        )
    rows = await run_in_thread(
        cles_repartition_repo.list_by_etablissement,
        etablissement_id,
        compte_m22bis=compte_m22bis,
        exercice_annee=exercice_annee,
    )
    return [_to_read(r) for r in rows]


async def create_cle(
    company_id: UUID,
    etablissement_id: UUID,
    payload: ClesRepartitionCreate,
) -> ClesRepartitionRead:
    """POST /etablissements/{ets_id}/cles-repartition — crée 1 clé.

    Refuse 404 si l'ETS n'est pas dans la company.
    Refuse 409 ``cles_repartition_duplicate`` si une clé existe déjà
    pour (ETS, compte, annee) — natural key UNIQUE.
    """
    # Pydantic accepte un etablissement_id dans le payload, mais la
    # route a déjà résolu l'ETS depuis l'URL. On force la cohérence.
    if str(payload.etablissement_id) != str(etablissement_id):
        raise ConflictError(
            f"etablissement_id du payload ({payload.etablissement_id}) "
            f"diffère de celui de l'URL ({etablissement_id})",
            code="etablissement_id_mismatch",
        )

    owns = await run_in_thread(
        cles_repartition_repo.etablissement_belongs_to_company,
        etablissement_id,
        company_id,
    )
    if not owns:
        raise NotFoundError(
            f"Établissement {etablissement_id} not found",
            code="etablissement_not_found",
        )

    existing = await run_in_thread(
        cles_repartition_repo.find_by_natural_key,
        etablissement_id,
        payload.compte_m22bis,
        payload.exercice_annee,
    )
    if existing is not None:
        raise ConflictError(
            f"clé déjà existante pour (ets={etablissement_id}, "
            f"compte={payload.compte_m22bis}, annee={payload.exercice_annee}) — "
            f"utiliser PUT pour modifier",
            code="cles_repartition_duplicate",
        )

    # Soft WARN stabilité année/année.
    n_minus_1 = await run_in_thread(
        cles_repartition_repo.find_n_minus_1,
        etablissement_id,
        payload.compte_m22bis,
        payload.exercice_annee,
    )
    _warn_year_diff(
        etablissement_id,
        payload.compte_m22bis,
        (
            payload.taux_hebergement,
            payload.taux_dependance,
            payload.taux_soins,
            payload.taux_soins_autonomie,
        ),
        n_minus_1,
    )

    row = await run_in_thread(
        cles_repartition_repo.create,
        company_id,
        payload.model_dump(mode="json"),
    )
    return _to_read(row)


async def update_cle(
    company_id: UUID,
    key_id: UUID,
    payload: ClesRepartitionUpdate,
) -> ClesRepartitionRead:
    """PUT /cles-repartition/{key_id} — patch source/notes ou les 4 taux.

    La validation Σ=100 est faite par Pydantic au parse (cf.
    :class:`ClesRepartitionUpdate._check_all_or_none_taux`).
    """
    existing = await run_in_thread(cles_repartition_repo.get_by_id, key_id)
    if existing is None:
        raise NotFoundError(f"clé {key_id} not found", code="cles_repartition_not_found")
    if str(existing["company_id"]) != str(company_id):
        raise CrossCompanyError(
            f"clé {key_id} not accessible",
            code="cles_repartition_cross_company",
        )

    data = payload.model_dump(exclude_unset=True)
    if not data:
        return _to_read(existing)

    row = await run_in_thread(cles_repartition_repo.update, key_id, data)
    if row is None:
        raise NotFoundError(f"clé {key_id} not found", code="cles_repartition_not_found")
    return _to_read(row)


async def delete_cle(company_id: UUID, key_id: UUID) -> None:
    """DELETE /cles-repartition/{key_id}."""
    existing = await run_in_thread(cles_repartition_repo.get_by_id, key_id)
    if existing is None:
        raise NotFoundError(f"clé {key_id} not found", code="cles_repartition_not_found")
    if str(existing["company_id"]) != str(company_id):
        raise CrossCompanyError(
            f"clé {key_id} not accessible",
            code="cles_repartition_cross_company",
        )
    deleted = await run_in_thread(cles_repartition_repo.delete, key_id)
    if not deleted:
        raise NotFoundError(f"clé {key_id} not found", code="cles_repartition_not_found")


async def bulk_upsert_cles(
    company_id: UUID,
    etablissement_id: UUID,
    payload: ClesRepartitionBulkUpsertRequest,
) -> list[ClesRepartitionRead]:
    """POST /etablissements/{ets_id}/cles-repartition:bulk-upsert —
    saisie tabulaire. Effectue 1 upsert par item (Q9 — pas d'opti N+1
    pour l'instant, max 200 items par batch déjà capé Pydantic).

    Doublons interne au batch (même compte/année 2 fois) sont gérés
    en favorisant le dernier (overwrite at-the-fly).
    """
    owns = await run_in_thread(
        cles_repartition_repo.etablissement_belongs_to_company,
        etablissement_id,
        company_id,
    )
    if not owns:
        raise NotFoundError(
            f"Établissement {etablissement_id} not found",
            code="etablissement_not_found",
        )

    out: list[ClesRepartitionRead] = []
    for item in payload.items:
        existing = await run_in_thread(
            cles_repartition_repo.find_by_natural_key,
            etablissement_id,
            item.compte_m22bis,
            item.exercice_annee,
        )
        # WARN year-diff
        n_minus_1 = await run_in_thread(
            cles_repartition_repo.find_n_minus_1,
            etablissement_id,
            item.compte_m22bis,
            item.exercice_annee,
        )
        _warn_year_diff(
            etablissement_id,
            item.compte_m22bis,
            (
                item.taux_hebergement,
                item.taux_dependance,
                item.taux_soins,
                item.taux_soins_autonomie,
            ),
            n_minus_1,
        )

        item_data = item.model_dump(mode="json")
        if existing is None:
            item_data["etablissement_id"] = str(etablissement_id)
            row = await run_in_thread(cles_repartition_repo.create, company_id, item_data)
        else:
            # Update — uniquement les colonnes mutables.
            row = await run_in_thread(
                cles_repartition_repo.update,
                existing["id"],
                {
                    "taux_hebergement": item.taux_hebergement,
                    "taux_dependance": item.taux_dependance,
                    "taux_soins": item.taux_soins,
                    "taux_soins_autonomie": item.taux_soins_autonomie,
                    "source": item.source,
                    "notes": item.notes,
                },
            )
        if row is not None:
            out.append(_to_read(row))
    return out
