"""Service layer — business logic and async DB orchestration.

Each service module wraps a repository: it converts between
:class:`pydantic.BaseModel` and dict rows, enforces business rules
(uniqueness checks, dependency guards before delete) and lifts the
sync repo calls into async via :func:`piilot.sdk.db.run_in_thread`.

Exceptions raised here are caught by the route layer and translated
to HTTP status codes:

* :class:`ConflictError` → 409
* :class:`NotFoundError` → 404
* :class:`CrossCompanyError` → 403
"""

from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
)

__all__ = ["ConflictError", "CrossCompanyError", "NotFoundError"]
