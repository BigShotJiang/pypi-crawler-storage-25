"""Service layer for Organisme Gestionnaire CRUD.

Wraps :mod:`piilot_pack_compta_esms.repositories.og_repo` with:

* Async via :func:`piilot.sdk.db.run_in_thread` (RLS context propagates
  to the worker thread).
* Business validations (FINESS uniqueness within a company).
* Hard delete with dependency guard (refuses 409 if any établissement
  or exercice still references the OG).
* Pydantic Read serialization at the boundary.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.og import OGCreate, OGRead, OGUpdate
from piilot_pack_compta_esms.repositories import og_repo
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)


def _to_read(row: dict[str, Any]) -> OGRead:
    """Convert a repo dict row to :class:`OGRead`.

    Defined as a module-level helper so tests can assert against the
    same projection the API returns.
    """
    return OGRead.model_validate(row)


async def list_orgs(company_id: UUID) -> list[OGRead]:
    """Return all OGs of the caller's company."""
    rows = await run_in_thread(og_repo.list_by_company, company_id)
    return [_to_read(r) for r in rows]


async def get_org(og_id: UUID) -> OGRead:
    """Fetch a single OG by id. Raises :class:`NotFoundError` if missing.

    RLS scopes the lookup to the caller's company — a 404 here means
    *either* the id doesn't exist *or* it belongs to another tenant,
    both of which we report identically (don't leak existence).
    """
    row = await run_in_thread(og_repo.get_by_id, og_id)
    if row is None:
        raise NotFoundError(f"OG {og_id} not found", code="og_not_found")
    return _to_read(row)


async def create_org(company_id: UUID, payload: OGCreate) -> OGRead:
    """Create a new OG. Raises 409 if FINESS already taken by this company."""
    existing = await run_in_thread(og_repo.find_by_finess, company_id, payload.finess_juridique)
    if existing is not None:
        raise ConflictError(
            f"FINESS juridique {payload.finess_juridique} already exists " "for this company",
            code="og_finess_taken",
        )
    row = await run_in_thread(og_repo.create, company_id, payload.model_dump(exclude_none=True))
    return _to_read(row)


async def update_org(company_id: UUID, og_id: UUID, payload: OGUpdate) -> OGRead:
    """Patch an OG. Raises 404 if missing, 409 on FINESS conflict."""
    current = await run_in_thread(og_repo.get_by_id, og_id)
    if current is None:
        raise NotFoundError(f"OG {og_id} not found", code="og_not_found")

    # FINESS uniqueness: only check if it's actually changing.
    new_finess = payload.finess_juridique
    if new_finess is not None and new_finess != current["finess_juridique"]:
        existing = await run_in_thread(og_repo.find_by_finess, company_id, new_finess)
        if existing is not None and str(existing["id"]) != str(og_id):
            raise ConflictError(
                f"FINESS juridique {new_finess} already exists " "for this company",
                code="og_finess_taken",
            )

    row = await run_in_thread(og_repo.update, og_id, payload.model_dump(exclude_unset=True))
    if row is None:
        # Race: row got deleted between the existence check and the update.
        raise NotFoundError(f"OG {og_id} not found", code="og_not_found")
    return _to_read(row)


async def delete_org(og_id: UUID) -> None:
    """Hard-delete an OG.

    Refuses with 409 if any établissement or exercice still references
    it. The cabinet has to delete those first (intentional friction so
    a stray click doesn't wipe years of accounting history).
    """
    # Existence first — a 404 on a fresh DELETE is more useful than
    # silently returning "0 rows affected".
    current = await run_in_thread(og_repo.get_by_id, og_id)
    if current is None:
        raise NotFoundError(f"OG {og_id} not found", code="og_not_found")

    n_etablissements = await run_in_thread(og_repo.count_etablissements, og_id)
    if n_etablissements > 0:
        raise ConflictError(
            f"OG {og_id} still owns {n_etablissements} établissement(s); " "delete them first",
            code="og_has_etablissements",
        )

    n_exercices = await run_in_thread(og_repo.count_exercices, og_id)
    if n_exercices > 0:
        raise ConflictError(
            f"OG {og_id} still has {n_exercices} exercice(s); " "delete them first",
            code="og_has_exercices",
        )

    deleted = await run_in_thread(og_repo.delete, og_id)
    if not deleted:
        # Race condition with another delete request — treat as already gone.
        raise NotFoundError(f"OG {og_id} not found", code="og_not_found")
