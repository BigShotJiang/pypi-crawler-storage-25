"""Tableau de financement service (§M, L2 §15).

Orchestre :

* :func:`list_tf` — GET §15.1 (retourne TfResponse avec ``type_tf``
  déduit de ``doc.type_document``)
* :func:`bulk_upsert_tf` — POST §15.2 (replace_all_by_document atomique)
* :func:`compute_totals` — GET §15.3 (breakdown par titre +
  équilibre par colonne, tolérance 0.01€)

Pas de ``:validate`` séparé (Q6) — l'équilibre est dans ``:totals``
(L2 §15 = 3 endpoints).

Variantes TF / TFP (Q1 — pas de discriminant DDL) :

* ``doc.type_document='errd'`` → ``type_tf='TF'`` → 4 colonnes
  (budget_initial_n1, realisations_n1, previsions_n, realisations_n)
* ``doc.type_document='eprd'`` → ``type_tf='TFP'`` → 8 colonnes
  (nm1, n, np1..np6 — D-094)
* Autres doc_types → ``TF`` par défaut

Équilibre (25-deepdive §6) : ``Σ ressources == Σ emplois`` par
colonne, tolérance 0.01€ (Q5). Les ajustements "Apport FR" et
"Prélèvement FR" sont des **lignes** du TF (côté emplois et ressources
respectivement), pas des colonnes dérivées — le cabinet les saisit
comme tout autre ligne.
"""

from __future__ import annotations

from decimal import Decimal
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.tf import (
    TfBulkUpsertRequest,
    TfEquilibreByColumn,
    TfLigneRead,
    TfResponse,
    TfTitreSubtotal,
    TfTotalsForCote,
    TfTotalsResponse,
    TypeTf,
    columns_for_type,
)
from piilot_pack_compta_esms.repositories import tf_repo
from piilot_pack_compta_esms.services import document_freeze
from piilot_pack_compta_esms.services.errors import NotFoundError

_ZERO = Decimal("0")
_TOLERANCE = Decimal("0.01")
"""Q5 — cohérent §I/§J/§K."""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(tf_repo.document_belongs_to_company, document_id, company_id)
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


def _deduce_type_tf(type_document: str | None) -> TypeTf:
    """Q1 — TFP si EPRD, sinon TF (incluant ERRD, DM, RIA, ERCP, EPCP)."""
    if type_document == "eprd":
        return "TFP"
    return "TF"


async def _load_type_tf(document_id: UUID, company_id: UUID) -> TypeTf:
    ctx = await run_in_thread(tf_repo.get_doc_type_document, document_id, company_id)
    if ctx is None:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )
    return _deduce_type_tf(ctx.get("type_document"))


# ---------------------------------------------------------------------------
# §15.1 — list_tf
# ---------------------------------------------------------------------------


async def list_tf(document_id: UUID, company_id: UUID) -> TfResponse:
    type_tf = await _load_type_tf(document_id, company_id)
    rows = await run_in_thread(tf_repo.list_by_document, document_id)
    return TfResponse(
        type_tf=type_tf,
        items=[TfLigneRead.model_validate(r) for r in rows],
    )


# ---------------------------------------------------------------------------
# §15.2 — bulk_upsert_tf (replace_all_by_document Q2)
# ---------------------------------------------------------------------------


async def bulk_upsert_tf(
    document_id: UUID,
    company_id: UUID,
    payload: TfBulkUpsertRequest,
) -> TfResponse:
    """Replace all by document — atomique. Le cabinet renvoie
    l'intégralité du TF à chaque save.

    Freeze §S : 409 si document hors brouillon."""
    await document_freeze.require_brouillon(document_id, company_id)
    await _require_document(document_id, company_id)
    items_dict = [item.model_dump(mode="json") for item in payload.items]
    await run_in_thread(
        tf_repo.replace_all_by_document,
        company_id=company_id,
        document_id=document_id,
        items=items_dict,
    )
    return await list_tf(document_id, company_id)


# ---------------------------------------------------------------------------
# §15.3 — compute_totals (Q3 par colonne + Q4 by titre + Q6 équilibre inclus)
# ---------------------------------------------------------------------------


def _safe_decimal(value) -> Decimal:  # noqa: ANN001
    if value is None:
        return _ZERO
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


async def compute_totals(document_id: UUID, company_id: UUID) -> TfTotalsResponse:
    """Aggrège par (cote, titre) + équilibre par colonne.

    Steps :

    1. Charge ``type_tf`` (TF ou TFP).
    2. Récupère les rows agrégées par (cote, titre) via
       :func:`tf_repo.totals_by_titre_cote`.
    3. Filtre les colonnes pertinentes selon ``type_tf`` (4 ERRD ou
       8 TFP).
    4. Construit :class:`TfTotalsForCote` pour ressources + emplois
       avec breakdown by titre + total par colonne.
    5. Calcule :class:`TfEquilibreByColumn` pour chaque colonne :
       ``ecart = total_ressources - total_emplois``, ``valide`` si
       ``|ecart| <= 0.01€``.
    6. ``valide_globalement`` = toutes colonnes équilibrées.
    """
    type_tf = await _load_type_tf(document_id, company_id)
    rows = await run_in_thread(tf_repo.totals_by_titre_cote, document_id)
    cols = columns_for_type(type_tf)

    # Group by cote
    by_cote: dict[str, list[dict]] = {"ressources": [], "emplois": []}
    for row in rows:
        if row["cote"] in by_cote:
            by_cote[row["cote"]].append(row)

    ressources = _build_cote_totals("ressources", by_cote["ressources"], cols)
    emplois = _build_cote_totals("emplois", by_cote["emplois"], cols)

    # Équilibre par colonne (Q3 + Q6)
    equilibre: list[TfEquilibreByColumn] = []
    res_totals = ressources.totals_by_column if ressources else {}
    emp_totals = emplois.totals_by_column if emplois else {}
    for col in cols:
        tot_res = res_totals.get(col, _ZERO)
        tot_emp = emp_totals.get(col, _ZERO)
        ecart = tot_res - tot_emp
        equilibre.append(
            TfEquilibreByColumn(
                column=col,
                total_ressources=tot_res,
                total_emplois=tot_emp,
                ecart=ecart,
                valide=abs(ecart) <= _TOLERANCE,
            )
        )

    valide_globalement = all(eq.valide for eq in equilibre)

    return TfTotalsResponse(
        type_tf=type_tf,
        ressources=ressources,
        emplois=emplois,
        equilibre_by_column=equilibre,
        valide_globalement=valide_globalement,
        tolerance_appliquee=_TOLERANCE,
    )


def _build_cote_totals(
    cote: str, rows: list[dict], cols: tuple[str, ...]
) -> TfTotalsForCote | None:
    """Construit :class:`TfTotalsForCote` pour une cote. Retourne
    None si aucune ligne (le cabinet n'a rien saisi de cette cote).

    Q4 — breakdown par titre : 1 :class:`TfTitreSubtotal` par titre
    distinct ; ``totals_by_column`` cumule sur toutes les lignes de
    la cote (peu importe le titre)."""
    if not rows:
        return None
    by_titre_list: list[TfTitreSubtotal] = []
    total_per_col: dict[str, Decimal] = dict.fromkeys(cols, _ZERO)
    for row in rows:
        titre_totals: dict[str, Decimal] = {}
        for col in cols:
            v = _safe_decimal(row.get(col))
            titre_totals[col] = v
            total_per_col[col] += v
        by_titre_list.append(TfTitreSubtotal(titre=row.get("titre"), totals_by_column=titre_totals))
    return TfTotalsForCote(
        cote=cote,  # type: ignore[arg-type]
        by_titre=by_titre_list,
        totals_by_column=total_per_col,
    )
