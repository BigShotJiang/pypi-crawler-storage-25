"""Workflow transitions service (§S, L2 §4.6 + §4.7).

Orchestre :

1. **Lecture du snapshot** via :mod:`workflow_repo`.
2. **Validation machine d'état** via :mod:`workflow_state_machine.can_apply`
   (pure). Échec → :class:`ConflictError` avec reason code stable.
3. **Guard équilibre R.314-222** (D-034) — câblé pour
   :func:`equilibre_validator.choose_equilibre_type` ; le wiring
   complet (charger les 5 inputs depuis §H/§I/§J/§N) est différé à
   §Z (catalogue 352 contrôles). En v0.2 §S, le transmit ne bloque
   pas sur l'équilibre réel/strict — l'UI E15 mockup E13/E15 indique
   "⚠ 2 contrôles en alerte (non bloquants)" cohérent avec ce trade-off.
4. **Calcul du patch** colonnes side (8 nouvelles ajoutées par
   migration 013 + 3 existantes ``transmis_at``/``executoire_at``/
   ``transmis_par_user_id``) selon (action, autorite).
5. **Mutation atomique** UPDATE document + INSERT audit_events en 1
   transaction via :func:`workflow_repo.apply_transition`.
6. **Construction réponse** :class:`TransitionResponse` self-descriptive.

Côté ``transitions-allowed`` (L2 §4.7), :func:`get_transitions_allowed`
charge le snapshot puis délègue à :func:`workflow_state_machine
.compute_allowed_actions` pour la liste filtrée par rôle.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.workflow import (
    AutoriteTarif,
    TransitionAction,
    TransitionRequest,
    TransitionResponse,
    TransitionsAllowedResponse,
    WorkflowSnapshot,
)
from piilot_pack_compta_esms.repositories import workflow_repo
from piilot_pack_compta_esms.services import workflow_state_machine
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
    ValidationError,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _now_utc() -> datetime:
    """Single source of truth — pratique pour mock dans les tests."""
    return datetime.now(tz=UTC)


def _snapshot_from_row(row: dict[str, Any]) -> WorkflowSnapshot:
    """Build le WorkflowSnapshot Pydantic depuis le row repo."""
    return WorkflowSnapshot(
        document_id=row["id"],
        type_document=row["type_document"],
        statut=row["statut"],
        transmis_at=row["transmis_at"],
        executoire_at=row["executoire_at"],
        approuve_par_ars_at=row["approuve_par_ars_at"],
        approuve_par_cd_at=row["approuve_par_cd_at"],
        approuve_par_ars_user_id=row["approuve_par_ars_user_id"],
        approuve_par_cd_user_id=row["approuve_par_cd_user_id"],
        rejete_at=row["rejete_at"],
        rejete_par_autorite=row["rejete_par_autorite"],
        motif_rejet=row["motif_rejet"],
        affectation_definie_at=row["affectation_definie_at"],
    )


async def _load_snapshot(document_id: UUID, company_id: UUID) -> WorkflowSnapshot:
    """Charge le snapshot — raise NotFoundError si absent, CrossCompanyError
    si le doc n'appartient pas à la company appelante."""
    row = await run_in_thread(workflow_repo.load_snapshot, document_id)
    if row is None:
        raise NotFoundError(f"document_not_found:{document_id}", code="document_not_found")
    if str(row["company_id"]) != str(company_id):
        raise CrossCompanyError(
            f"document_cross_company:{document_id}",
            code="document_cross_company",
        )
    return _snapshot_from_row(row)


# ---------------------------------------------------------------------------
# Public — POST /documents/{doc_id}/transitions
# ---------------------------------------------------------------------------


async def apply_transition(
    *,
    document_id: UUID,
    payload: TransitionRequest,
    company_id: UUID,
    user_id: UUID,
    role: str,
) -> TransitionResponse:
    """Applique la transition demandée.

    Échecs possibles (mappés HTTP via routes/_errors.py) :

    * ``NotFoundError`` (404) — document inexistant.
    * ``CrossCompanyError`` (403) — appelant pas dans la company du doc.
    * ``ConflictError`` (409) — machine d'état refuse l'action.
    * ``ValidationError`` (422) — futur, si le guard équilibre §Z est
      câblé et qu'il bloque la transmission.
    """
    snapshot = await _load_snapshot(document_id, company_id)

    # Permissions + machine d'état (pure, sans IO)
    ok, reason = workflow_state_machine.can_apply(
        snapshot,
        action=payload.action,
        autorite=payload.autorite,
        role=role,
    )
    if not ok:
        # ``role_required`` → 403, sinon 409. C'est plus honnête qu'un
        # 409 unique : la couche route remappe à HTTP 403 si reason
        # == role_required.
        if reason == "role_required":
            raise CrossCompanyError(
                f"role_required_for_action:{payload.action}",
                code="role_required",
            )
        raise ConflictError(
            f"transition_refused:{reason}",
            code=reason or "transition_refused",
        )

    # Guard équilibre — v0.2 journalisait juste le mode. v0.3 §BD
    # durcit avec ``equilibre_service.apply_equilibre_check_for_document``
    # qui charge les inputs, appelle le validator pure et écrit le
    # verdict sur ``documents_budgetaires.equilibre_atteint_o_n``.
    audit_extras: dict[str, Any] = {}
    if payload.action == "transmit":
        eq_mode = await _resolve_equilibre_mode(document_id)
        if eq_mode is not None:
            audit_extras["equilibre_applicable"] = eq_mode

        # §Z guard D-034 — bloque la transition si l'un des 3 contrôles
        # bloquants (C-001 Bilan / C-002 Annexe 5 / C-003 R.314-222)
        # retourne KO. Les NA passent (squelette v0.2). Le service
        # ``run_bloquants`` n'écrit pas en DB — c'est un check rapide
        # pré-transition, le cabinet a déjà fait `:run` complet avant.
        from piilot_pack_compta_esms.services import controles_service

        ko_bloquants = await controles_service.run_bloquants(document_id, company_id)
        if ko_bloquants:
            codes_ko = sorted(r["code"] for r in ko_bloquants)
            raise ValidationError(
                f"Transition transmit bloquée — contrôles KO sur "
                f"{', '.join(codes_ko)} (D-034). Corrigez les anomalies "
                f"avant de transmettre.",
                code="transition_blocked_by_failed_control",
            )

        # §BD v0.3 — calcul + persistance du verdict équilibre R.314-222.
        # Le service applique le dispatcher REEL/STRICT/NON_APPLICABLE
        # selon nature_juridique × CPOM inclusion, charge les inputs,
        # appelle le validator pure et écrit ``equilibre_atteint_o_n``.
        # Verdict NON → on bloque la transition (D-034 hard enforcement).
        from piilot_pack_compta_esms.services import equilibre_service

        equilibre_result = await equilibre_service.apply_equilibre_check_for_document(
            company_id=company_id,
            document_id=document_id,
        )
        audit_extras["equilibre_atteint_o_n"] = equilibre_result.verdict
        if equilibre_result.verdict == "NON":
            raise ValidationError(
                f"Transition transmit bloquée — équilibre {equilibre_result.mode} "
                f"non atteint (R.314-222 D-034). Corrigez les déséquilibres "
                f"avant de transmettre.",
                code="transition_blocked_by_equilibre_check",
            )

    target_statut = workflow_state_machine.derive_target_statut(
        snapshot,
        action=payload.action,
        autorite=payload.autorite,
    )

    patch, audit_action, audit_payload_extra = _build_patch_and_audit(
        snapshot=snapshot,
        action=payload.action,
        autorite=payload.autorite,
        motif=payload.motif,
        target_statut=target_statut,
        user_id=user_id,
    )
    audit_payload: dict[str, Any] = {
        "from": snapshot.statut,
        "to": target_statut,
        **audit_payload_extra,
        **audit_extras,
    }

    row = await run_in_thread(
        workflow_repo.apply_transition,
        document_id=document_id,
        company_id=company_id,
        user_id=user_id,
        patch=patch,
        audit_action=audit_action,
        audit_payload=audit_payload,
    )
    if row is None:
        # Disparu entre le SELECT et l'UPDATE — extrême race, on remonte
        # 404 cohérent avec NotFoundError.
        raise NotFoundError(
            f"document_not_found:{document_id}",
            code="document_not_found",
        )

    updated_snapshot = _snapshot_from_row(row)
    return _build_response(
        snapshot_before=snapshot,
        snapshot_after=updated_snapshot,
        action=payload.action,
        autorite=payload.autorite,
    )


async def _resolve_equilibre_mode(document_id: UUID) -> str | None:
    """Retourne ``'reel'`` / ``'strict'`` selon le contexte OG, ou None
    si le contexte ne peut pas être chargé (ex. doc DM/RIA dont la
    famille n'est pas EPRD-soumise-équilibre — tous les types EPRD-family
    de §S le sont).
    """
    from piilot_pack_compta_esms.services.finance.equilibre_validator import (
        choose_equilibre_type,
    )

    ctx = await run_in_thread(workflow_repo.load_equilibre_context, document_id)
    if ctx is None:
        return None
    return choose_equilibre_type(
        nature_juridique=ctx["nature_juridique"],
        inclus_dans_cpom=ctx["any_inclus_cpom"],
    )


# ---------------------------------------------------------------------------
# Patch builder — décide quelles colonnes side mettre à jour
# ---------------------------------------------------------------------------


def _build_patch_and_audit(
    *,
    snapshot: WorkflowSnapshot,
    action: TransitionAction,
    autorite: AutoriteTarif | None,
    motif: str | None,
    target_statut: str,
    user_id: UUID,
) -> tuple[dict[str, Any], str, dict[str, Any]]:
    """Construit ``(patch, audit_action_key, audit_payload_extra)``.

    Le patch ne touche que les colonnes side strictement requises par
    l'action — pas de pollution croisée.
    """
    now = _now_utc()
    patch: dict[str, Any] = {"statut": target_statut}
    audit_payload_extra: dict[str, Any] = {}

    if action == "transmit":
        patch["transmis_at"] = now
        patch["transmis_par_user_id"] = str(user_id)
        return patch, "workflow.transmit", audit_payload_extra

    if action == "set_affectation":
        patch["affectation_definie_at"] = now
        return patch, "workflow.set_affectation", audit_payload_extra

    if action == "approve":
        assert autorite is not None  # guaranteed by can_apply
        audit_payload_extra["autorite"] = autorite
        if autorite == "ars":
            patch["approuve_par_ars_at"] = now
            patch["approuve_par_ars_user_id"] = str(user_id)
        else:  # cd
            patch["approuve_par_cd_at"] = now
            patch["approuve_par_cd_user_id"] = str(user_id)
        if target_statut == "executoire":
            patch["executoire_at"] = now
            audit_payload_extra["auto_flip_executoire"] = True
        return patch, "workflow.approve", audit_payload_extra

    if action == "reject":
        assert autorite is not None  # guaranteed by can_apply
        assert motif is not None  # guaranteed by Pydantic model_validator
        patch["rejete_at"] = now
        patch["rejete_par_autorite"] = autorite
        patch["motif_rejet"] = motif
        audit_payload_extra["autorite"] = autorite
        audit_payload_extra["motif"] = motif
        return patch, "workflow.reject", audit_payload_extra

    # pragma: no cover — actions sont un Literal Pydantic strict
    raise ValidationError(f"unknown_action:{action}", code="unknown_action")


# ---------------------------------------------------------------------------
# Response builder
# ---------------------------------------------------------------------------


def _build_response(
    *,
    snapshot_before: WorkflowSnapshot,
    snapshot_after: WorkflowSnapshot,
    action: TransitionAction,
    autorite: AutoriteTarif | None,
) -> TransitionResponse:
    return TransitionResponse(
        document_id=snapshot_after.document_id,
        type_document=snapshot_after.type_document,
        statut_before=snapshot_before.statut,
        statut_after=snapshot_after.statut,
        action=action,
        autorite=autorite,
        transmis_at=snapshot_after.transmis_at,
        executoire_at=snapshot_after.executoire_at,
        rejete_at=snapshot_after.rejete_at,
        motif_rejet=snapshot_after.motif_rejet,
        rejete_par_autorite=snapshot_after.rejete_par_autorite,
        affectation_definie_at=snapshot_after.affectation_definie_at,
        double_validation=workflow_state_machine.build_double_validation_state(snapshot_after),
    )


# ---------------------------------------------------------------------------
# Public — GET /documents/{doc_id}/transitions-allowed
# ---------------------------------------------------------------------------


async def get_transitions_allowed(
    *,
    document_id: UUID,
    company_id: UUID,
    role: str,
) -> TransitionsAllowedResponse:
    """Retourne actions applicables + actions bloquées + état double
    validation. Pas de side effect.
    """
    snapshot = await _load_snapshot(document_id, company_id)
    allowed, blocked = workflow_state_machine.compute_allowed_actions(snapshot, role=role)
    return TransitionsAllowedResponse(
        document_id=snapshot.document_id,
        type_document=snapshot.type_document,
        current_statut=snapshot.statut,
        allowed=allowed,
        blocked=blocked,
        double_validation=workflow_state_machine.build_double_validation_state(snapshot),
    )
