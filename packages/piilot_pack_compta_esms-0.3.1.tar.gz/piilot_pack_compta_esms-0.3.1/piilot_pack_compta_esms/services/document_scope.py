"""Helpers §X — periscope autour du type_document.

Centralise les règles de scope qui dépendent du type de document :

* :func:`assert_not_eps_only_doc` — refuse 409 ``feature_not_available_for_eps``
  pour les services qui ne s'appliquent pas aux ERCP/EPCP (Bilan financier,
  TF, PGFP, TPER/TER, Annexe 4 GIR, Annexe 5 financière, Provisions,
  Emprunts, RCC). KB22 §3 + KB25 §15+§16 — ces onglets vivent dans
  l'EPRD EPS global, pas dans l'extrait médico-social du plugin.

* :func:`assert_doc_type_in` — assertion générique pour les guards
  ciblés (ex: Affectation §J — seulement ERRD + ERCP, pas EPCP qui est
  prévisionnel).

* :func:`resolve_plan_comptable` — routing M21 vs M22Bis selon le type
  de document. ERCP/EPCP (secteur sanitaire) → ``M21`` ; tous les autres
  (EPRD/ERRD/DM/RIA/AVENANT, médico-social pur) → ``M22Bis``.
  D-101 — PLT-M21 livré §B.2 dans la KB référentielle core
  ``com.piilot.core.plan-comptable-esms``.

Tous les helpers sont *async* et appellent le repo via ``run_in_thread`` —
c'est le pattern uniforme du plugin.
"""

from __future__ import annotations

from typing import Final
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.repositories import document_repo
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

EPS_ONLY_DOC_TYPES: Final[frozenset[str]] = frozenset({"ercp", "epcp"})
"""Types réservés aux EPS (établissements publics de santé).

Plusieurs onglets EPRD/ERRD n'ont pas leur équivalent dans le cadre
sanitaire simplifié — quand un service détecte ce type, il refuse 409
``feature_not_available_for_eps`` plutôt que d'écrire silencieusement
dans une table dont le contenu ne sera jamais exporté."""


async def assert_not_eps_only_doc(document_id: UUID) -> None:
    """Refuse 409 si le document est un ERCP/EPCP.

    Appelé en début de service par : ``bilan_service``, ``tf_service``,
    ``provisions_service``, ``emprunts_service``, ``rcc_service``,
    ``pgfp_service``, ``tper_ter_service``, ``activite_service``,
    ``annexe5_service``. Pattern aligné §S ``document_freeze``.

    Lève ``NotFoundError`` si le document n'existe pas — defensive,
    car le service appelant a normalement déjà vérifié le tenant via
    le helper standard ``_ensure_company_owned``.
    """
    row = await run_in_thread(document_repo.get_by_id, document_id)
    if row is None:
        raise NotFoundError(
            f"Document {document_id} not found",
            code="document_not_found",
        )
    if row["type_document"] in EPS_ONLY_DOC_TYPES:
        raise ConflictError(
            f"Cette feature n'est pas disponible pour les documents "
            f"ERCP/EPCP (type='{row['type_document']}'). Le sanitaire EPS "
            f"vit dans l'EPRD/ERRD global, hors scope plugin compta-ESMS.",
            code="feature_not_available_for_eps",
        )


async def assert_doc_type_in(document_id: UUID, allowed: frozenset[str]) -> None:
    """Refuse 409 si ``type_document`` n'est pas dans ``allowed``.

    Helper générique pour les guards ciblés — typiquement §J Affectation
    (allowed = ``{'errd', 'ercp'}``, EPCP exclu car prévisionnel).
    """
    row = await run_in_thread(document_repo.get_by_id, document_id)
    if row is None:
        raise NotFoundError(
            f"Document {document_id} not found",
            code="document_not_found",
        )
    if row["type_document"] not in allowed:
        raise ConflictError(
            f"Cette feature requiert type_document ∈ {sorted(allowed)}, "
            f"got '{row['type_document']}'",
            code="feature_not_applicable_for_doc_type",
        )


async def get_doc_type(document_id: UUID) -> str | None:
    """Retourne le ``type_document`` d'un document, ou ``None`` si
    inexistant. Helper léger utilisé par les services qui ont besoin
    de connaître le type sans appliquer de guard (typiquement
    :func:`cr_service.create_cr` qui veut refuser CRPP sur ERCP/EPCP
    mais accepter les autres cr_types).

    Le fixture autouse :func:`_default_eps_scope_passthrough` mocke
    cette fonction pour retourner ``'eprd'`` par défaut — les tests
    dédiés §X la surcharge."""
    row = await run_in_thread(document_repo.get_by_id, document_id)
    return row["type_document"] if row is not None else None


def resolve_plan_comptable(type_document: str) -> str:
    """Retourne le plan comptable à utiliser selon le type de document.

    * ``'M21'`` pour ercp/epcp (secteur sanitaire — D-101)
    * ``'M22Bis'`` pour eprd/errd/dm/ria/avenant (médico-social pur)

    Le caller utilise cette valeur pour filtrer le lookup dans la KB
    core ``com.piilot.core.plan-comptable-esms`` (qui contient les 2
    plans côte à côte via la colonne ``type``).
    """
    return "M21" if type_document in EPS_ONLY_DOC_TYPES else "M22Bis"
