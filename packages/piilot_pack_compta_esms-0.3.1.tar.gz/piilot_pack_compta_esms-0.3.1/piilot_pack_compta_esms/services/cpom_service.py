"""Service layer for CPOM (§BA v0.3, D-027).

Wraps :mod:`cpom_repo` / :mod:`cpom_esms_link_repo` /
:mod:`cpom_objectifs_repo` with:

* Async via :func:`piilot.sdk.db.run_in_thread`
* Date arithmetic (``date_fin_theorique = date_effet + duree_annees``)
* OG cohérence checks (CPOM ↔ OG ↔ ETS cross-table validation)
* Pydantic Read serialization at the boundary
* The §BD helper :func:`is_etablissement_in_cpom` (deterministic
  equilibrium-applicable classification depends on it).

The DB has CHECK constraints on every enum / range — the service
relies on Pydantic to surface a clean 422 before we hit them.
"""

from __future__ import annotations

import calendar
from datetime import date
from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.cpom import (
    CpomCreate,
    CpomEsmsLinkItem,
    CpomEsmsLinkRead,
    CpomObjectifCreate,
    CpomObjectifRead,
    CpomObjectifUpdate,
    CpomProgress,
    CpomRead,
    CpomUpdate,
)
from piilot_pack_compta_esms.repositories import (
    cpom_esms_link_repo,
    cpom_objectifs_repo,
    cpom_repo,
)
from piilot_pack_compta_esms.services.errors import (
    CrossCompanyError,
    NotFoundError,
    ValidationError,
)

# --------------------------------------------------------------------
# Derived value : date_fin_theorique = date_effet + duree_annees
# --------------------------------------------------------------------


def compute_date_fin_theorique(date_effet: date, duree_annees: Decimal) -> date:
    """Return the theorical end date of a CPOM.

    ``duree_annees`` is NUMERIC (up to two decimals) so we can't lean
    on ``dateutil.relativedelta(years=...)``. We split into a whole-
    years bump (calendar-aware via py stdlib) plus a fractional part
    that we translate into a day count against the year that contains
    ``date_effet + whole_years``. This avoids ``timedelta(days=365.25
    * duree)`` drift and stays consistent with how the legal text
    counts duration (one full calendar year, then a remainder of
    days).

    Examples :

    * ``date_effet=2024-01-01, duree=5`` → ``2029-01-01``
    * ``date_effet=2024-01-01, duree=5.5`` → ``2029-07-02`` (half of 2029)
    * ``date_effet=2024-02-29, duree=1`` → ``2025-02-28`` (non-leap year
      collapses to Feb-28 to stay a valid date)
    """
    whole_years = int(duree_annees)
    fraction = duree_annees - Decimal(whole_years)

    target_year = date_effet.year + whole_years
    target_month = date_effet.month
    target_day = date_effet.day

    # Handle Feb-29 collapsing when the target year is non-leap.
    max_day_target_month = calendar.monthrange(target_year, target_month)[1]
    if target_day > max_day_target_month:
        target_day = max_day_target_month

    anchor = date(target_year, target_month, target_day)

    if fraction == 0:
        return anchor

    # Days in the target year (anchor year) used as the resolution.
    days_in_year = 366 if calendar.isleap(target_year) else 365
    days_to_add = int((fraction * Decimal(days_in_year)).to_integral_value())

    # ``date`` doesn't support direct add of a Decimal day count —
    # convert via ``date.fromordinal``.
    return date.fromordinal(anchor.toordinal() + days_to_add)


# --------------------------------------------------------------------
# Serialization helpers
# --------------------------------------------------------------------


def _to_cpom_read(row: dict[str, Any]) -> CpomRead:
    return CpomRead.model_validate(row)


def _to_link_read(row: dict[str, Any]) -> CpomEsmsLinkRead:
    return CpomEsmsLinkRead.model_validate(row)


def _to_objectif_read(row: dict[str, Any]) -> CpomObjectifRead:
    return CpomObjectifRead.model_validate(row)


# --------------------------------------------------------------------
# CPOM CRUD
# --------------------------------------------------------------------


async def list_cpoms_by_og(company_id: UUID, og_id: UUID) -> list[CpomRead]:
    """List CPOMs of an OG. Raises 404 if the OG doesn't belong to the
    caller."""
    if not await run_in_thread(cpom_repo.og_exists_for_company, og_id, company_id):
        raise NotFoundError(f"OG {og_id} not found", code="og_not_found")
    rows = await run_in_thread(cpom_repo.list_by_og, og_id)
    return [_to_cpom_read(r) for r in rows]


async def get_cpom(company_id: UUID, cpom_id: UUID) -> CpomRead:
    """Fetch a single CPOM. Raises 404 if missing (RLS-scoped)."""
    row = await run_in_thread(cpom_repo.get_by_id, cpom_id)
    if row is None:
        raise NotFoundError(f"CPOM {cpom_id} not found", code="cpom_not_found")
    if str(row["company_id"]) != str(company_id):
        # RLS prevents this; explicit for defense-in-depth.
        raise CrossCompanyError(f"CPOM {cpom_id} not accessible", code="cpom_cross_company")
    return _to_cpom_read(row)


async def create_cpom(company_id: UUID, og_id: UUID, payload: CpomCreate) -> CpomRead:
    """Create a new CPOM under the given OG.

    * 404 if the OG doesn't belong to the company.
    * 422 if the body's ``og_id`` doesn't match the path's.
    * Computes ``date_fin_theorique`` from
      ``date_effet + duree_annees``.
    """
    if str(payload.og_id) != str(og_id):
        raise ValidationError(
            "body.og_id must match the path og_id",
            code="og_id_mismatch",
        )
    if not await run_in_thread(cpom_repo.og_exists_for_company, og_id, company_id):
        raise NotFoundError(f"OG {og_id} not found", code="og_not_found")

    body = payload.model_dump(exclude_none=True)
    body["date_fin_theorique"] = compute_date_fin_theorique(
        payload.date_effet, payload.duree_annees
    )
    # ``cosignataires`` must be passed as a real list — psycopg2 maps
    # to TEXT[] automatically. Drop the OG id since the repo injects
    # it from path context.
    body.pop("og_id", None)

    row = await run_in_thread(cpom_repo.create, company_id, og_id, body)
    return _to_cpom_read(row)


async def update_cpom(company_id: UUID, cpom_id: UUID, payload: CpomUpdate) -> CpomRead:
    """Patch a CPOM. Recomputes ``date_fin_theorique`` when either
    ``date_effet`` or ``duree_annees`` is in the payload.

    Raises 404 if missing, 403 if cross-company.
    """
    current = await run_in_thread(cpom_repo.get_by_id, cpom_id)
    if current is None:
        raise NotFoundError(f"CPOM {cpom_id} not found", code="cpom_not_found")
    if str(current["company_id"]) != str(company_id):
        raise CrossCompanyError(f"CPOM {cpom_id} not accessible", code="cpom_cross_company")

    body = payload.model_dump(exclude_none=True)
    if "date_effet" in body or "duree_annees" in body:
        new_date_effet = body.get("date_effet", current["date_effet"])
        new_duree = body.get("duree_annees", current["duree_annees"])
        body["date_fin_theorique"] = compute_date_fin_theorique(
            new_date_effet, Decimal(str(new_duree))
        )

    row = await run_in_thread(cpom_repo.update, cpom_id, body)
    # ``update`` returns ``None`` only if the row vanished mid-flight
    # (unlikely given the get_by_id above) — re-raise NotFound.
    if row is None:
        raise NotFoundError(f"CPOM {cpom_id} not found", code="cpom_not_found")
    return _to_cpom_read(row)


async def delete_cpom(company_id: UUID, cpom_id: UUID) -> None:
    """Cascade-delete a CPOM. Links + objectifs auto-cascade via FK.

    Raises 404 if missing, 403 if cross-company.
    """
    current = await run_in_thread(cpom_repo.get_by_id, cpom_id)
    if current is None:
        raise NotFoundError(f"CPOM {cpom_id} not found", code="cpom_not_found")
    if str(current["company_id"]) != str(company_id):
        raise CrossCompanyError(f"CPOM {cpom_id} not accessible", code="cpom_cross_company")
    deleted = await run_in_thread(cpom_repo.delete, cpom_id)
    if not deleted:
        # Race condition — already deleted by a parallel request.
        raise NotFoundError(f"CPOM {cpom_id} not found", code="cpom_not_found")


# --------------------------------------------------------------------
# CPOM ↔ ESMS links
# --------------------------------------------------------------------


async def list_links_by_cpom(company_id: UUID, cpom_id: UUID) -> list[CpomEsmsLinkRead]:
    """List all (ets, perimetre) pairs of a CPOM."""
    await get_cpom(company_id, cpom_id)  # 404/403 guard
    rows = await run_in_thread(cpom_esms_link_repo.list_by_cpom, cpom_id)
    return [_to_link_read(r) for r in rows]


async def bulk_link_etablissements(
    company_id: UUID,
    cpom_id: UUID,
    items: list[CpomEsmsLinkItem],
) -> list[CpomEsmsLinkRead]:
    """Upsert N (ets, perimetre) pairs in one shot.

    The whole batch is checked first :

    * 404 on the CPOM if missing.
    * 422 if any ETS doesn't belong to the CPOM's OG (refused as a
      single batch error, not per-item — we want a deterministic
      "all or nothing" semantic so the UI can replay the call after
      fixing the offending row).

    The UPSERT then sets ``inclus_dans_perimetre`` to the new value
    on existing rows (idempotent re-import friendly).
    """
    cpom = await get_cpom(company_id, cpom_id)
    if not items:
        return []

    # Cross-OG validation before any write.
    for item in items:
        belongs = await run_in_thread(
            cpom_esms_link_repo.ets_belongs_to_og,
            item.etablissement_id,
            cpom.og_id,
        )
        if not belongs:
            raise ValidationError(
                f"Établissement {item.etablissement_id} does not belong "
                f"to OG {cpom.og_id} of CPOM {cpom_id}",
                code="ets_og_mismatch",
            )

    out: list[CpomEsmsLinkRead] = []
    for item in items:
        row = await run_in_thread(
            cpom_esms_link_repo.upsert,
            company_id,
            cpom_id,
            item.etablissement_id,
            item.inclus_dans_perimetre,
        )
        out.append(_to_link_read(row))
    return out


async def unlink_etablissement(company_id: UUID, cpom_id: UUID, etablissement_id: UUID) -> None:
    """Remove the (cpom, ets) link. 404 if either resource missing."""
    await get_cpom(company_id, cpom_id)  # 404/403 guard
    existing = await run_in_thread(
        cpom_esms_link_repo.get_by_cpom_and_ets, cpom_id, etablissement_id
    )
    if existing is None:
        raise NotFoundError(
            f"No link between CPOM {cpom_id} and ETS {etablissement_id}",
            code="cpom_link_not_found",
        )
    await run_in_thread(cpom_esms_link_repo.delete_by_cpom_and_ets, cpom_id, etablissement_id)


# --------------------------------------------------------------------
# CPOM Objectifs CRUD
# --------------------------------------------------------------------


async def list_objectifs(company_id: UUID, cpom_id: UUID) -> list[CpomObjectifRead]:
    """List all objectives of a CPOM."""
    await get_cpom(company_id, cpom_id)  # 404/403 guard
    rows = await run_in_thread(cpom_objectifs_repo.list_by_cpom, cpom_id)
    return [_to_objectif_read(r) for r in rows]


async def create_objectif(
    company_id: UUID, cpom_id: UUID, payload: CpomObjectifCreate
) -> CpomObjectifRead:
    """Create a new objective under the given CPOM."""
    await get_cpom(company_id, cpom_id)  # 404/403 guard
    body = payload.model_dump(exclude_none=True)
    row = await run_in_thread(cpom_objectifs_repo.create, company_id, cpom_id, body)
    return _to_objectif_read(row)


async def update_objectif(
    company_id: UUID, cpom_id: UUID, obj_id: UUID, payload: CpomObjectifUpdate
) -> CpomObjectifRead:
    """Patch an objective. 404 if missing, 403 if cross-company,
    422 if not owned by the path's CPOM."""
    current = await run_in_thread(cpom_objectifs_repo.get_by_id, obj_id)
    if current is None:
        raise NotFoundError(f"Objectif {obj_id} not found", code="objectif_not_found")
    if str(current["company_id"]) != str(company_id):
        raise CrossCompanyError(f"Objectif {obj_id} not accessible", code="objectif_cross_company")
    if str(current["cpom_id"]) != str(cpom_id):
        raise ValidationError(
            f"Objectif {obj_id} does not belong to CPOM {cpom_id}",
            code="objectif_cpom_mismatch",
        )
    body = payload.model_dump(exclude_none=True)
    if not body:
        return _to_objectif_read(current)
    row = await run_in_thread(cpom_objectifs_repo.update, obj_id, body)
    if row is None:
        raise NotFoundError(f"Objectif {obj_id} not found", code="objectif_not_found")
    return _to_objectif_read(row)


async def delete_objectif(company_id: UUID, cpom_id: UUID, obj_id: UUID) -> None:
    """Hard delete an objective. Cross-table cohérence checks before."""
    current = await run_in_thread(cpom_objectifs_repo.get_by_id, obj_id)
    if current is None:
        raise NotFoundError(f"Objectif {obj_id} not found", code="objectif_not_found")
    if str(current["company_id"]) != str(company_id):
        raise CrossCompanyError(f"Objectif {obj_id} not accessible", code="objectif_cross_company")
    if str(current["cpom_id"]) != str(cpom_id):
        raise ValidationError(
            f"Objectif {obj_id} does not belong to CPOM {cpom_id}",
            code="objectif_cpom_mismatch",
        )
    deleted = await run_in_thread(cpom_objectifs_repo.delete, obj_id)
    if not deleted:
        raise NotFoundError(f"Objectif {obj_id} not found", code="objectif_not_found")


# --------------------------------------------------------------------
# Reporting
# --------------------------------------------------------------------


async def compute_progress(company_id: UUID, cpom_id: UUID) -> CpomProgress:
    """Histogram + realise ratio for a CPOM's objectives."""
    await get_cpom(company_id, cpom_id)  # 404/403 guard
    histogram = await run_in_thread(cpom_objectifs_repo.aggregate_status_by_cpom, cpom_id)
    total = histogram["total"]
    ratio = histogram["realises"] / total if total > 0 else 0.0
    return CpomProgress(
        cpom_id=cpom_id,
        total=total,
        prevus=histogram["prevus"],
        en_cours=histogram["en_cours"],
        realises=histogram["realises"],
        abandonnes=histogram["abandonnes"],
        sans_statut=histogram["sans_statut"],
        ratio_realise=ratio,
    )


# --------------------------------------------------------------------
# §BD pre-req — is_etablissement_in_cpom
# --------------------------------------------------------------------


async def is_etablissement_in_cpom(
    etablissement_id: UUID,
    exercice_annee: int,
) -> bool:
    """Return True if ``etablissement_id`` is dans le périmètre tarifaire
    d'au moins un CPOM actif sur l'exercice ``exercice_annee``.

    Definition (KB B.3 + KB B.4 + S03 p.8-11) :

    * "CPOM actif sur l'exercice ``Y``" = il existe une journée du 1er
      janvier de Y au 31 décembre de Y comprise dans
      ``[date_effet, date_fin_theorique)``. On modélise par "le CPOM
      chevauche l'intervalle ``[Y-01-01, (Y+1)-01-01)``".
    * "ETS dans le périmètre du CPOM" = il existe une row
      ``cpom_esms_link`` avec ``inclus_dans_perimetre = 'OUI'``.

    Cette fonction est la **clé de §BD** ``compute_equilibre_applicable``
    qui décide REEL vs STRICT vs NON_APPLICABLE selon l'inclusion dans
    un CPOM + ``og.nature_juridique`` + ``ets.soumis_equilibre``.

    Implémentation :

    1. Lister tous les links de l'ETS (rapidement filtré côté DB).
    2. Pour chaque CPOM rattaché, vérifier le chevauchement temporel
       et le flag périmètre.
    3. Court-circuiter au premier match.

    On reste agnostique sur la company — c'est appelé depuis un
    contexte where RLS company_id est déjà posé par le caller (le
    routing ou le test setup). En isolation, on accède aux 3 tables
    en lecture seulement, donc aucun risque de leak cross-tenant.
    """
    # Borne de l'exercice (inclusive jan 1, exclusive jan 1 de Y+1).
    exercice_start = date(exercice_annee, 1, 1)
    exercice_end_exclusive = date(exercice_annee + 1, 1, 1)

    links = await run_in_thread(cpom_esms_link_repo.list_by_etablissement, etablissement_id)
    for link in links:
        if link["inclus_dans_perimetre"] != "OUI":
            continue
        cpom = await run_in_thread(cpom_repo.get_by_id, link["cpom_id"])
        if cpom is None:
            # The FK CASCADE should make this unreachable, but a stale
            # row from a parallel delete shouldn't crash the helper.
            continue
        # Half-open interval chevauchement : [date_effet, date_fin) ∩
        # [exercice_start, exercice_end) ≠ ∅ ⇔
        # date_effet < exercice_end_exclusive  AND  date_fin > exercice_start
        if (
            cpom["date_effet"] < exercice_end_exclusive
            and cpom["date_fin_theorique"] > exercice_start
        ):
            return True
    return False


__all__ = [
    "compute_date_fin_theorique",
    "list_cpoms_by_og",
    "get_cpom",
    "create_cpom",
    "update_cpom",
    "delete_cpom",
    "list_links_by_cpom",
    "bulk_link_etablissements",
    "unlink_etablissement",
    "list_objectifs",
    "create_objectif",
    "update_objectif",
    "delete_objectif",
    "compute_progress",
    "is_etablissement_in_cpom",
]
