"""Validators transverses pour le plugin compta-esms.

Ces fonctions sont conçues pour être branchées comme
``@field_validator`` (Pydantic v2) sur les champs string sensibles
des models. Elles n'ont aucune dépendance externe et ne déclenchent
aucune IO.

Décisions sources :

* **D-075** — Caractère ``|`` interdit dans tous les champs de saisie
  utilisateur (compat chaîne SI DGCS). Réservé comme séparateur de
  champs dans les exports CSV/TSV DGCS et dans les chaînes d'import
  CNSA. Si un cabinet saisit ``"FAM Saint-Joseph | 75 places"`` dans
  un libellé, l'export XLSX/CSV v0.6 casserait silencieusement à
  l'autre bout. On rejette dès le PUT pour fail-fast.

Branchement type :

.. code-block:: python

    from pydantic import BaseModel, field_validator
    from piilot_pack_compta_esms.services.validators import reject_pipe_char

    class MyModel(BaseModel):
        libelle: str | None = None

        _validate_libelle = field_validator("libelle")(reject_pipe_char)
"""

from __future__ import annotations


def reject_pipe_char(value: str | None) -> str | None:
    """Rejette une string contenant le caractère ``|``.

    D-075 — réservé chaîne SI DGCS. Le caractère pipe est utilisé
    comme séparateur de champs dans les exports CSV/TSV CNSA. Sa
    présence dans un libellé casserait l'export en v0.6.

    Behaviour :

    * ``None`` → ``None`` (passthrough — le validator ne force pas
      le champ à devenir non-nullable).
    * ``""`` (empty) → ``""`` (autorisé — Pydantic ``min_length`` est
      le bon outil pour interdire la chaîne vide, pas ce validator).
    * String avec ``|`` n'importe où → ``ValueError`` (Pydantic
      convertit en 422 ``value_error``).
    """
    if value is None:
        return value
    if "|" in value:
        raise ValueError(
            "pipe_char_forbidden:le caractère '|' est réservé " "(D-075, compat chaîne SI DGCS)"
        )
    return value
