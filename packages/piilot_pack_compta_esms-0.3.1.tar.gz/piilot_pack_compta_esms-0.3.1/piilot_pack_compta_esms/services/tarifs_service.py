"""Service layer for EPRD tarifs proposés — §BB v0.3.

Wraps :mod:`tarif_propose_repo` with :

* Async via :func:`piilot.sdk.db.run_in_thread`
* Document type gate : seuls les documents prévisionnels
  (``eprd`` / ``epcp`` / ``dm`` / ``ria``) acceptent des tarifs
  proposés. ERRD et avenant sont refusés (422).
* Cross-tenant check sur l'ETS du body (defense-in-depth + RLS).
* Workflow row-level enforcement : refuse les transitions invalides
  (ex: passage direct PROPOSE → REJETE OK, mais
  VALIDE_TRIPARTITE → PROPOSE refusé).
* :func:`build_validation_report` pour §BD C1 R.314-222.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.tarif_propose import (
    TarifProposeBulkItem,
    TarifProposeCreate,
    TarifProposeRead,
    TarifProposeUpdate,
    TarifSectionAggregate,
    TarifValidationReport,
)
from piilot_pack_compta_esms.repositories import tarif_propose_repo
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
    ValidationError,
)

# Types de documents qui ont des tarifs prévisionnels. ERRD est
# rétrospectif (montants notifiés vivent ailleurs, dans crp_lignes
# directement) → refusé ici pour éviter la confusion sémantique.
_DOCUMENT_TYPES_WITH_TARIFS = frozenset({"eprd", "epcp", "dm", "ria"})


def _to_read(row: dict[str, Any]) -> TarifProposeRead:
    return TarifProposeRead.model_validate(row)


async def _check_document(company_id: UUID, document_id: UUID) -> str:
    """Common pre-write guard : document exists, belongs to the tenant,
    is a type that supports tarifs proposés. Returns the document
    type for downstream logic (Annexe 5 dispatch e.g.).
    """
    exists = await run_in_thread(
        tarif_propose_repo.document_exists_for_company,
        document_id,
        company_id,
    )
    if not exists:
        raise NotFoundError(f"Document {document_id} not found", code="document_not_found")
    doc_type = await run_in_thread(tarif_propose_repo.get_document_type, document_id)
    if doc_type not in _DOCUMENT_TYPES_WITH_TARIFS:
        raise ValidationError(
            f"Document type '{doc_type}' does not support tarifs "
            "proposés (only EPRD/EPCP/DM/RIA do)",
            code="document_type_no_tarifs",
        )
    return doc_type


async def _check_ets(company_id: UUID, etablissement_id: UUID) -> None:
    belongs = await run_in_thread(
        tarif_propose_repo.ets_belongs_to_company,
        etablissement_id,
        company_id,
    )
    if not belongs:
        raise NotFoundError(
            f"Établissement {etablissement_id} not found",
            code="ets_not_found",
        )


# --------------------------------------------------------------------
# CRUD
# --------------------------------------------------------------------


async def list_by_document(company_id: UUID, document_id: UUID) -> list[TarifProposeRead]:
    """List every tarif row of a document. 404 if the document doesn't
    exist or belongs to another tenant."""
    await _check_document(company_id, document_id)
    rows = await run_in_thread(tarif_propose_repo.list_by_document, document_id)
    return [_to_read(r) for r in rows]


async def get_tarif(company_id: UUID, tarif_id: UUID) -> TarifProposeRead:
    """Fetch a single row. 404 if missing, 403 if cross-tenant."""
    row = await run_in_thread(tarif_propose_repo.get_by_id, tarif_id)
    if row is None:
        raise NotFoundError(f"Tarif {tarif_id} not found", code="tarif_not_found")
    if str(row["company_id"]) != str(company_id):
        raise CrossCompanyError(
            f"Tarif {tarif_id} not accessible",
            code="tarif_cross_company",
        )
    return _to_read(row)


async def create_tarif(
    company_id: UUID,
    document_id: UUID,
    payload: TarifProposeCreate,
) -> TarifProposeRead:
    """Create a new tarif row.

    * 404 si le document n'existe pas ou n'appartient pas au tenant
    * 422 si le type de document n'accepte pas de tarifs proposés
    * 404 si l'ETS n'existe pas dans le tenant
    * 409 si une row existe déjà pour le triplet (doc, ETS, section)
      — passer par :func:`bulk_upsert` ou PATCH pour mettre à jour.
    """
    await _check_document(company_id, document_id)
    await _check_ets(company_id, payload.etablissement_id)

    # Idempotency : refuse the create if the natural key is already
    # taken. Forces the caller to PATCH if they really want to update.
    existing = await run_in_thread(
        tarif_propose_repo.get_by_natural_key,
        document_id,
        payload.etablissement_id,
        payload.section,
    )
    if existing is not None:
        raise ConflictError(
            f"Tarif already exists for document {document_id}, "
            f"ETS {payload.etablissement_id}, section {payload.section}",
            code="tarif_natural_key_taken",
        )

    body = payload.model_dump(exclude_none=True)
    row = await run_in_thread(tarif_propose_repo.create, company_id, document_id, body)
    return _to_read(row)


async def update_tarif(
    company_id: UUID,
    tarif_id: UUID,
    payload: TarifProposeUpdate,
) -> TarifProposeRead:
    """Patch a tarif row (ESMS-side and/or ATC-side).

    Workflow guard : refuse de passer une row VALIDE_TRIPARTITE en
    arrière (PROPOSE / VALIDE_ARS / VALIDE_CD) — la décision tripartite
    fige le tarif, seul un nouveau cycle (delete + create) le débloque.
    """
    current = await run_in_thread(tarif_propose_repo.get_by_id, tarif_id)
    if current is None:
        raise NotFoundError(f"Tarif {tarif_id} not found", code="tarif_not_found")
    if str(current["company_id"]) != str(company_id):
        raise CrossCompanyError(
            f"Tarif {tarif_id} not accessible",
            code="tarif_cross_company",
        )

    body = payload.model_dump(exclude_none=True)

    # Workflow guard : pas de retour en arrière depuis VALIDE_TRIPARTITE.
    new_statut = body.get("statut")
    if (
        current["statut"] == "VALIDE_TRIPARTITE"
        and new_statut is not None
        and new_statut != "VALIDE_TRIPARTITE"
    ):
        raise ValidationError(
            "Cannot transition a VALIDE_TRIPARTITE tarif back to "
            f"'{new_statut}' (the tripartite decision is final)",
            code="tarif_statut_locked",
        )

    row = await run_in_thread(tarif_propose_repo.update, tarif_id, body)
    if row is None:
        raise NotFoundError(f"Tarif {tarif_id} not found", code="tarif_not_found")
    return _to_read(row)


async def delete_tarif(company_id: UUID, tarif_id: UUID) -> None:
    """Hard delete. 404 if missing, 403 if cross-tenant."""
    current = await run_in_thread(tarif_propose_repo.get_by_id, tarif_id)
    if current is None:
        raise NotFoundError(f"Tarif {tarif_id} not found", code="tarif_not_found")
    if str(current["company_id"]) != str(company_id):
        raise CrossCompanyError(
            f"Tarif {tarif_id} not accessible",
            code="tarif_cross_company",
        )
    deleted = await run_in_thread(tarif_propose_repo.delete, tarif_id)
    if not deleted:
        raise NotFoundError(f"Tarif {tarif_id} not found", code="tarif_not_found")


async def bulk_upsert(
    company_id: UUID,
    document_id: UUID,
    items: list[TarifProposeBulkItem],
) -> list[TarifProposeRead]:
    """Upsert N (ETS, section, ...) rows in one batch.

    Validation cross-table sur tous les items AVANT le 1er write —
    si un item viole, le batch entier est refusé (sémantique
    cohérente avec :func:`cpom_service.bulk_link_etablissements`).

    Sur ON CONFLICT (document, ETS, section) → DO UPDATE des champs
    ESMS-side uniquement (libelle / montant_propose / motif). Les
    champs ATC (montant_notifie / statut / date_validation / ...)
    restent intacts.
    """
    await _check_document(company_id, document_id)
    if not items:
        return []

    # 1) Tous les ETS doivent appartenir au tenant.
    seen_ets: set[UUID] = set()
    for item in items:
        if item.etablissement_id in seen_ets:
            continue
        await _check_ets(company_id, item.etablissement_id)
        seen_ets.add(item.etablissement_id)

    # 2) Les (ETS, section) doivent être uniques dans le batch lui-
    # même — sinon le dernier "écraserait" silencieusement le premier
    # via l'UPSERT et le caller ne le verrait pas.
    seen_keys: set[tuple[UUID, str]] = set()
    for item in items:
        key = (item.etablissement_id, item.section)
        if key in seen_keys:
            raise ValidationError(
                f"Duplicate (ETS, section) in batch: " f"{item.etablissement_id} / {item.section}",
                code="bulk_duplicate_key",
            )
        seen_keys.add(key)

    # 3) Upsert sequence.
    out: list[TarifProposeRead] = []
    for item in items:
        body = item.model_dump(exclude_none=True)
        row = await run_in_thread(
            tarif_propose_repo.upsert,
            company_id,
            document_id,
            item.etablissement_id,
            item.section,
            body,
        )
        out.append(_to_read(row))
    return out


# --------------------------------------------------------------------
# Validation report (§BD C1)
# --------------------------------------------------------------------


async def build_validation_report(company_id: UUID, document_id: UUID) -> TarifValidationReport:
    """Aggregate per section + global flags. Backbone du §BD C1
    R.314-222 et du widget UI "tarifs status".
    """
    await _check_document(company_id, document_id)
    rows = await run_in_thread(tarif_propose_repo.aggregate_by_section, document_id)

    sections = [
        TarifSectionAggregate(
            section=r["section"],
            rows_count=int(r["rows_count"]),
            total_propose=r["total_propose"],
            total_notifie=r["total_notifie"],
            ecart=(
                r["total_notifie"] - r["total_propose"] if r["total_notifie"] is not None else None
            ),
            all_validated_tripartite=bool(r["all_validated_tripartite"]),
        )
        for r in rows
    ]
    total_rows = sum(s.rows_count for s in sections)
    # All sections tripartite ssi (a) au moins une section présente
    # ET (b) toutes sont tripartite ET (c) aucune row REJETE.
    has_rejected = any(bool(r["has_rejected"]) for r in rows)
    all_tripartite = (
        bool(sections) and all(s.all_validated_tripartite for s in sections) and not has_rejected
    )

    return TarifValidationReport(
        document_id=document_id,
        sections=sections,
        total_rows=total_rows,
        all_sections_tripartite=all_tripartite,
        has_rejected_rows=has_rejected,
    )


__all__ = [
    "list_by_document",
    "get_tarif",
    "create_tarif",
    "update_tarif",
    "delete_tarif",
    "bulk_upsert",
    "build_validation_report",
]
