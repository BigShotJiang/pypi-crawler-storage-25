"""Service §V DM — Décision Modificative (D-064 R.314-229).

KB23 §2.5 — "bouleversement de l'économie générale" du budget :

  1. **CAF insuffisante** pour couvrir le remboursement en capital
     des emprunts à échoir.
  2. **Prélèvement sur le fonds de roulement > FRNG disponible** au
     1er janvier de l'exercice.

→ Service ``validate_dm_economy_bouleversee(dm_id)`` qui vérifie ces
2 conditions sur la projection actualisée du DM.

**v0.2 = squelette soft non-bloquant** : retourne le verdict avec
``evaluable=False`` quand les inputs requis ne peuvent pas être
chargés (typique des cabinets pilotes qui n'ont pas encore saisi
toutes les annexes). Pattern aligné sur §I equilibre_validator
(F.EQ.01 — chaque condition porte son flag evaluable).

**v0.5** : enforce strict — bloquer la transition ``BROUILLON →
TRANSMIS`` si l'une des 2 conditions retourne KO évaluable. À ce
moment-là, câbler le verdict dans le guard §S workflow (au lieu de
laisser l'audit_payload journaliser uniquement le mode équilibre).

Pour l'instant, l'endpoint retourne le verdict en lecture seule —
le cabinet ou l'agent IA peut l'appeler à tout moment, c'est
informatif.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread
from pydantic import BaseModel, ConfigDict, Field

from piilot_pack_compta_esms.repositories import document_repo
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)

# ---------------------------------------------------------------------------
# Models — outbound DTO
# ---------------------------------------------------------------------------


class EconomyConditionResult(BaseModel):
    """Une des 2 conditions R.314-229. Pattern aligné §I ConditionResult."""

    model_config = ConfigDict(extra="forbid")

    id: int = Field(..., ge=1, le=2)
    label: str
    evaluable: bool = Field(
        ...,
        description=(
            "True si les inputs nécessaires ont pu être chargés. "
            "False = condition non-évaluable (typiquement annexe pas encore "
            "saisie). Verdict ``bouleverse`` reste False quand ``evaluable=False``."
        ),
    )
    bouleverse: bool = Field(
        ...,
        description=(
            "True si la condition active le bouleversement de l'économie "
            "(KO réglementaire). Toujours False si ``evaluable=False``."
        ),
    )
    message: str
    inputs: dict[str, Any] = Field(default_factory=dict)


class EconomyBouleverseResult(BaseModel):
    """Verdict global pour le DM.

    Le DM "bouleverse l'économie générale" si **au moins une** des 2
    conditions est évaluable ET active (R.314-229).
    """

    model_config = ConfigDict(extra="forbid")

    dm_id: UUID
    parent_eprd_id: UUID
    conditions: list[EconomyConditionResult]
    nb_evaluables: int = Field(..., ge=0, le=2)
    nb_bouleverse: int = Field(..., ge=0, le=2)
    bouleverse_globalement: bool
    is_soft_verdict: bool = Field(
        default=True,
        description=(
            "v0.2 : True (verdict informatif, ne bloque pas la transmission). "
            "v0.5 : False quand câblé en guard §S workflow."
        ),
    )


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------


async def _load_dm_with_parent(dm_id: UUID, company_id: UUID) -> dict[str, Any]:
    """Charge le DM + valide tenant + type='dm' + parent_id non-NULL."""
    row = await run_in_thread(document_repo.get_by_id, dm_id)
    if row is None:
        raise NotFoundError(f"document_not_found:{dm_id}", code="document_not_found")
    if str(row["company_id"]) != str(company_id):
        raise NotFoundError(f"document_not_found:{dm_id}", code="document_not_found")
    if row["type_document"] != "dm":
        raise ConflictError(
            f"document {dm_id} is not a DM (got type='{row['type_document']}')",
            code="not_a_dm",
        )
    if row["parent_id"] is None:
        # Defensive — Pydantic + service §E.3 garantissent parent_id pour DM.
        raise ConflictError(
            f"DM {dm_id} has no parent_id (data corruption)",
            code="dm_orphan",
        )
    return row


def _condition_1_caf_insuffisante(
    *,
    caf_projection: Decimal | None,
    capital_a_rembourser_n: Decimal | None,
) -> EconomyConditionResult:
    """R.314-229 condition 1 — CAF doit couvrir le capital à rembourser N.

    ``caf_projection`` vient du compute §I ``compute_caf`` appliqué à
    la projection actualisée du DM. ``capital_a_rembourser_n`` vient
    de §N ``emprunts_dettes.capital_rembourse_n`` total.

    v0.2 : si l'un des 2 manque, ``evaluable=False``. v0.5 : les 2
    inputs sont câblés depuis les bonnes tables.
    """
    if caf_projection is None or capital_a_rembourser_n is None:
        return EconomyConditionResult(
            id=1,
            label="CAF suffisante pour le capital à rembourser N",
            evaluable=False,
            bouleverse=False,
            message=(
                "Inputs manquants — CAF projection ou capital à rembourser N "
                "non fournis. v0.2 squelette non-bloquant."
            ),
            inputs={
                "caf_projection": _decimal_to_str(caf_projection),
                "capital_a_rembourser_n": _decimal_to_str(capital_a_rembourser_n),
            },
        )
    bouleverse = caf_projection < capital_a_rembourser_n
    return EconomyConditionResult(
        id=1,
        label="CAF suffisante pour le capital à rembourser N",
        evaluable=True,
        bouleverse=bouleverse,
        message=(
            f"CAF projection {caf_projection} < capital N {capital_a_rembourser_n} "
            "— bouleversement"
            if bouleverse
            else f"CAF projection {caf_projection} ≥ capital N {capital_a_rembourser_n} — OK"
        ),
        inputs={
            "caf_projection": str(caf_projection),
            "capital_a_rembourser_n": str(capital_a_rembourser_n),
        },
    )


def _condition_2_prelevement_fr_excessif(
    *,
    prelevement_fr: Decimal | None,
    frng_disponible_1janvier: Decimal | None,
) -> EconomyConditionResult:
    """R.314-229 condition 2 — Prélèvement FR ≤ FRNG disponible 1/1.

    ``prelevement_fr`` = montant prélevé sur le fonds de roulement
    dans le DM. ``frng_disponible_1janvier`` vient du Bilan §K au
    01/01 de l'exercice (FRNG = FRI + FRE — §I structure_financiere).

    v0.2 : si l'un manque, ``evaluable=False``. v0.5 : câblé.
    """
    if prelevement_fr is None or frng_disponible_1janvier is None:
        return EconomyConditionResult(
            id=2,
            label="Prélèvement FR ≤ FRNG disponible au 1er janvier",
            evaluable=False,
            bouleverse=False,
            message=(
                "Inputs manquants — Prélèvement FR ou FRNG disponible au 1/1 "
                "non fournis. v0.2 squelette non-bloquant."
            ),
            inputs={
                "prelevement_fr": _decimal_to_str(prelevement_fr),
                "frng_disponible_1janvier": _decimal_to_str(frng_disponible_1janvier),
            },
        )
    bouleverse = prelevement_fr > frng_disponible_1janvier
    return EconomyConditionResult(
        id=2,
        label="Prélèvement FR ≤ FRNG disponible au 1er janvier",
        evaluable=True,
        bouleverse=bouleverse,
        message=(
            f"Prélèvement FR {prelevement_fr} > FRNG 1/1 {frng_disponible_1janvier} "
            "— bouleversement"
            if bouleverse
            else f"Prélèvement FR {prelevement_fr} ≤ FRNG 1/1 {frng_disponible_1janvier} — OK"
        ),
        inputs={
            "prelevement_fr": str(prelevement_fr),
            "frng_disponible_1janvier": str(frng_disponible_1janvier),
        },
    )


def _decimal_to_str(value: Decimal | None) -> str | None:
    return None if value is None else str(value)


async def validate_economy_bouleversee(
    *,
    dm_id: UUID,
    company_id: UUID,
) -> EconomyBouleverseResult:
    """Évalue les 2 conditions R.314-229 pour ce DM. **Non-bloquant v0.2**.

    Le wiring complet des 2 inputs (CAF projection + capital à rembourser
    N + prélèvement FR + FRNG 1/1) est différé v0.5. En v0.2, le service
    retourne le squelette du verdict avec ``evaluable=False`` partout —
    cela permet au frontend / agent IA d'appeler l'endpoint dès
    maintenant sans crash, et de visualiser la structure du contrôle.
    """
    row = await _load_dm_with_parent(dm_id, company_id)

    # v0.2 squelette — inputs à None forcés. v0.5 : remplacer par le
    # chargement réel depuis §I CAF + §N emprunts_dettes + §K bilan.
    caf_projection: Decimal | None = None
    capital_a_rembourser_n: Decimal | None = None
    prelevement_fr: Decimal | None = None
    frng_disponible_1janvier: Decimal | None = None

    condition_1 = _condition_1_caf_insuffisante(
        caf_projection=caf_projection,
        capital_a_rembourser_n=capital_a_rembourser_n,
    )
    condition_2 = _condition_2_prelevement_fr_excessif(
        prelevement_fr=prelevement_fr,
        frng_disponible_1janvier=frng_disponible_1janvier,
    )
    conditions = [condition_1, condition_2]
    nb_evaluables = sum(1 for c in conditions if c.evaluable)
    nb_bouleverse = sum(1 for c in conditions if c.bouleverse)
    bouleverse_globalement = any(c.bouleverse for c in conditions)

    return EconomyBouleverseResult(
        dm_id=dm_id,
        parent_eprd_id=row["parent_id"],
        conditions=conditions,
        nb_evaluables=nb_evaluables,
        nb_bouleverse=nb_bouleverse,
        bouleverse_globalement=bouleverse_globalement,
        is_soft_verdict=True,
    )
