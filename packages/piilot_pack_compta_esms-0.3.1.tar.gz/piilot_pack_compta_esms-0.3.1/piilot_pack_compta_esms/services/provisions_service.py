"""Provisions service (§N, L2 §16.1-§16.2).

Orchestre :

* :func:`list_provisions` — GET §16.1 (items + totals by_categorie)
* :func:`bulk_upsert_provisions` — POST §16.2 (replace_all_by_document
  atomique Q3)

Pas d'endpoint ``:totals`` séparé (Q6) — l'objet ``totals`` est
inclus dans la réponse GET (L2 §16 n'expose pas de ``:totals`` pour
provisions/emprunts/rcc, contrairement à §15 TF).

Contrôles croisés Conso!B387-B388 (25-deepdive §10) → différés en
§Z (pattern §M, Q8).
"""

from __future__ import annotations

from decimal import Decimal
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.provisions import (
    Categorie,
    ProvisionLigneRead,
    ProvisionsBulkUpsertRequest,
    ProvisionsCategorieTotals,
    ProvisionsMontants,
    ProvisionsResponse,
    ProvisionsTotals,
)
from piilot_pack_compta_esms.repositories import provisions_repo
from piilot_pack_compta_esms.services import document_freeze, document_scope
from piilot_pack_compta_esms.services.errors import NotFoundError

_ZERO = Decimal("0")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(provisions_repo.document_belongs_to_company, document_id, company_id)
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


def _safe_decimal(value) -> Decimal:  # noqa: ANN001
    if value is None:
        return _ZERO
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def _build_totals(rows_by_categorie: list[dict]) -> ProvisionsTotals:
    """Construit :class:`ProvisionsTotals` depuis l'aggregate par
    categorie. ``total_general`` somme toutes les catégories."""
    by_categorie: list[ProvisionsCategorieTotals] = []
    sum_debut = _ZERO
    sum_dot = _ZERO
    sum_rep = _ZERO
    sum_fin = _ZERO
    for row in rows_by_categorie:
        debut = _safe_decimal(row.get("montant_debut_n"))
        dot = _safe_decimal(row.get("dotations"))
        rep = _safe_decimal(row.get("reprises"))
        fin = _safe_decimal(row.get("montant_fin_n"))
        sum_debut += debut
        sum_dot += dot
        sum_rep += rep
        sum_fin += fin
        by_categorie.append(
            ProvisionsCategorieTotals(
                categorie=row["categorie"],  # type: ignore[arg-type]
                montants=ProvisionsMontants(
                    montant_debut_n=debut,
                    dotations=dot,
                    reprises=rep,
                    montant_fin_n=fin,
                ),
            )
        )
    total_general = ProvisionsMontants(
        montant_debut_n=sum_debut,
        dotations=sum_dot,
        reprises=sum_rep,
        montant_fin_n=sum_fin,
    )
    return ProvisionsTotals(by_categorie=by_categorie, total_general=total_general)


# ---------------------------------------------------------------------------
# §16.1 — list_provisions
# ---------------------------------------------------------------------------


async def list_provisions(document_id: UUID, company_id: UUID) -> ProvisionsResponse:
    """Items + totals by_categorie."""
    await _require_document(document_id, company_id)
    rows = await run_in_thread(provisions_repo.list_by_document, document_id)
    totals_rows = await run_in_thread(provisions_repo.totals_by_categorie, document_id)
    return ProvisionsResponse(
        items=[ProvisionLigneRead.model_validate(r) for r in rows],
        totals=_build_totals(totals_rows),
    )


# ---------------------------------------------------------------------------
# §16.2 — bulk_upsert_provisions (replace_all_by_document Q3)
# ---------------------------------------------------------------------------


async def bulk_upsert_provisions(
    document_id: UUID,
    company_id: UUID,
    payload: ProvisionsBulkUpsertRequest,
) -> ProvisionsResponse:
    """Replace all by document — atomique (Q3).

    Freeze §S : 409 si document hors brouillon."""
    await document_freeze.require_brouillon(document_id, company_id)
    await document_scope.assert_not_eps_only_doc(document_id)
    await _require_document(document_id, company_id)
    items_dict = [item.model_dump(mode="json") for item in payload.items]
    await run_in_thread(
        provisions_repo.replace_all_by_document,
        company_id=company_id,
        document_id=document_id,
        items=items_dict,
    )
    return await list_provisions(document_id, company_id)


# Re-export for tests that need it
__all__ = [
    "Categorie",
    "list_provisions",
    "bulk_upsert_provisions",
]
