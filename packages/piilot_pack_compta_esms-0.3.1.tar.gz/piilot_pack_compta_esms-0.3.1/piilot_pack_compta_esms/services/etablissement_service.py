"""Service layer for Établissement CRUD.

Same shape as :mod:`og_service`. Three extra concerns:

* When creating, verify that the path's ``og_id`` belongs to the
  caller's company (defense in depth on top of RLS).
* When deleting, refuse 409 if any Compte de Résultat still references
  the établissement (``etablissement_id`` has ``ON DELETE RESTRICT``).
* Validate ``typologie`` against the core reference KB
  ``com.piilot.core.typologies-essms`` (PLT-T1, 46 codes) and
  ``convention_collective`` against
  ``com.piilot.core.conventions-collectives-esms``. The lookup is
  fail-open : if the core catalog is empty (sync hasn't run), any
  string is accepted with a WARN log — better than locking out
  create endpoints during a fresh deployment.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.etablissement import (
    EtablissementCreate,
    EtablissementRead,
    EtablissementUpdate,
)
from piilot_pack_compta_esms.repositories import etablissement_repo
from piilot_pack_compta_esms.services import reference_lookup
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
)


async def _validate_referenced_codes(
    typologie: str | None, convention_collective: str | None
) -> None:
    """Run both reference lookups in turn — first failure raises 422.

    Each lookup is fail-open (returns True on empty catalog), so this
    function only ever raises when the catalog is *populated* and the
    submitted code is *not* in it. That's the meaningful case: a typo
    or stale frontend dropdown."""
    if typologie is not None:
        if not await reference_lookup.typologie_exists(typologie):
            raise ConflictError(
                f"Unknown typologie code '{typologie}' — must be a code "
                "from com.piilot.core.typologies-essms (PLT-T1).",
                code="ets_typologie_unknown",
            )
    if convention_collective is not None:
        if not await reference_lookup.convention_collective_exists(convention_collective):
            raise ConflictError(
                f"Unknown convention_collective code "
                f"'{convention_collective}' — must be a code from "
                "com.piilot.core.conventions-collectives-esms.",
                code="ets_convention_collective_unknown",
            )


def _to_read(row: dict[str, Any]) -> EtablissementRead:
    return EtablissementRead.model_validate(row)


async def list_etablissements(og_id: UUID, typologie: str | None = None) -> list[EtablissementRead]:
    """Return établissements of an OG, optionally filtered by typologie."""
    rows = await run_in_thread(etablissement_repo.list_by_og, og_id, typologie)
    return [_to_read(r) for r in rows]


async def get_etablissement(ets_id: UUID) -> EtablissementRead:
    """Fetch a single établissement. 404 if missing or cross-tenant."""
    row = await run_in_thread(etablissement_repo.get_by_id, ets_id)
    if row is None:
        raise NotFoundError(f"Établissement {ets_id} not found", code="ets_not_found")
    return _to_read(row)


async def create_etablissement(
    company_id: UUID, og_id: UUID, payload: EtablissementCreate
) -> EtablissementRead:
    """Create an établissement under the given OG.

    Validates :
    1. The body's ``og_id`` matches the URL path (mismatch → 400 via
       :class:`CrossCompanyError`-style guard).
    2. The OG exists and belongs to the caller's company.
    3. The FINESS is not already taken by another établissement in the
       same company.
    """
    if payload.og_id != og_id:
        raise ConflictError(
            "Body og_id does not match URL og_id",
            code="ets_og_id_mismatch",
        )

    og_ok = await run_in_thread(etablissement_repo.og_exists_for_company, og_id, company_id)
    if not og_ok:
        # We don't say "OG belongs to another tenant" — that would leak
        # existence. A 404-like behavior is more honest here.
        raise NotFoundError(f"OG {og_id} not found", code="og_not_found_for_ets_create")

    # Reference KB validation (PLT-T1 typologies + bonus conventions
    # collectives). Fail-open when the catalog isn't synced — see the
    # helper's docstring.
    await _validate_referenced_codes(payload.typologie, payload.convention_collective)

    existing = await run_in_thread(
        etablissement_repo.find_by_finess, company_id, payload.finess_ets
    )
    if existing is not None:
        raise ConflictError(
            f"FINESS établissement {payload.finess_ets} already exists " "for this company",
            code="ets_finess_taken",
        )

    row = await run_in_thread(
        etablissement_repo.create,
        company_id,
        og_id,
        payload.model_dump(exclude={"og_id"}, exclude_none=True),
    )
    return _to_read(row)


async def update_etablissement(
    company_id: UUID, ets_id: UUID, payload: EtablissementUpdate
) -> EtablissementRead:
    """Patch an établissement. 404 / 409 semantics identical to OG.

    Re-validates ``typologie`` / ``convention_collective`` only when the
    patch actually sets them (sparse update — we don't re-check
    fields the caller didn't touch)."""
    current = await run_in_thread(etablissement_repo.get_by_id, ets_id)
    if current is None:
        raise NotFoundError(f"Établissement {ets_id} not found", code="ets_not_found")

    new_finess = payload.finess_ets
    if new_finess is not None and new_finess != current["finess_ets"]:
        existing = await run_in_thread(etablissement_repo.find_by_finess, company_id, new_finess)
        if existing is not None and str(existing["id"]) != str(ets_id):
            raise ConflictError(
                f"FINESS établissement {new_finess} already exists " "for this company",
                code="ets_finess_taken",
            )

    # Validate referenced codes if the patch touches them. ``exclude_unset``
    # below also drops untouched fields, so we test against the model fields
    # directly to avoid validating a field the caller didn't intend to set.
    await _validate_referenced_codes(payload.typologie, payload.convention_collective)

    row = await run_in_thread(
        etablissement_repo.update,
        ets_id,
        payload.model_dump(exclude_unset=True),
    )
    if row is None:
        raise NotFoundError(f"Établissement {ets_id} not found", code="ets_not_found")
    return _to_read(row)


async def delete_etablissement(company_id: UUID, ets_id: UUID) -> None:
    """Hard-delete an établissement.

    Refuses 409 if any Compte de Résultat references it
    (``etablissement_id`` is ``ON DELETE RESTRICT``).
    """
    current = await run_in_thread(etablissement_repo.get_by_id, ets_id)
    if current is None:
        raise NotFoundError(f"Établissement {ets_id} not found", code="ets_not_found")

    # Cross-company guard before the dependency check — RLS already
    # filters reads, but a defensive check keeps the error path clear.
    if str(current["company_id"]) != str(company_id):
        raise CrossCompanyError(
            f"Établissement {ets_id} not accessible",
            code="ets_cross_company",
        )

    n_crs = await run_in_thread(etablissement_repo.count_crs, ets_id)
    if n_crs > 0:
        raise ConflictError(
            f"Établissement {ets_id} is referenced by {n_crs} Compte(s) "
            "de Résultat; detach or delete them first",
            code="ets_has_crs",
        )

    deleted = await run_in_thread(etablissement_repo.delete, ets_id)
    if not deleted:
        raise NotFoundError(f"Établissement {ets_id} not found", code="ets_not_found")
