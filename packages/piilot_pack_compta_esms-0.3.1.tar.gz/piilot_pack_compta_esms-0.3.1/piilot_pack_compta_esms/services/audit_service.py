"""Audit event logger for compta_esms (§S et au-delà).

Émet un row dans ``compta_esms.audit_events`` à chaque action critique
(transitions workflow, exports, suppressions). La table est posée par
la migration 002 §D.11 :

* ``id``, ``company_id``, ``user_id``, ``document_id?``
* ``action`` — clé machine (ex ``workflow.transmit``,
  ``workflow.approve``, ``workflow.reject``)
* ``resource_type`` — ex ``document``
* ``resource_id`` — UUID de la ressource ciblée
* ``payload`` — JSONB (from/to statut, autorite, motif, etc.)
* ``occurred_at`` — TIMESTAMPTZ DEFAULT now()

Le service ne reçoit pas de connection — il en ouvre une via
``piilot.sdk.db.cursor`` autour de l'INSERT. Pour les cas où l'audit
doit être inclus dans la même transaction que l'action (workflow
transitions), passer un curseur ouvert via :func:`record_event_in`.

Côté lecture (§AI L2 §22.1) : :func:`list_for_document` charge le doc
(tenant guard) puis délègue à ``audit_repo.list_by_document``.
"""

from __future__ import annotations

import json
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor, run_in_thread

from piilot_pack_compta_esms.models.audit import AuditEventRead
from piilot_pack_compta_esms.repositories import audit_repo, document_repo
from piilot_pack_compta_esms.services.errors import NotFoundError, ValidationError

try:
    from piilot.sdk.db import Json
except ImportError:  # pragma: no cover — defensive, the SDK ships it
    Json = None  # type: ignore[assignment]


_COLUMNS: tuple[str, ...] = (
    "company_id",
    "user_id",
    "document_id",
    "action",
    "resource_type",
    "resource_id",
    "payload",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)
_PLACEHOLDERS = ", ".join(["%s"] * len(_COLUMNS))


def _wrap_jsonb(value: Any) -> Any:
    """Adapter for psycopg2 JSONB params (pattern rcc_repo + autres)."""
    if Json is not None:
        return Json(value)
    return json.dumps(value)


def record_event_in(
    cur: Any,
    *,
    company_id: UUID,
    user_id: UUID,
    action: str,
    resource_type: str,
    resource_id: UUID,
    payload: dict[str, Any] | None = None,
    document_id: UUID | None = None,
) -> None:
    """Insert un row audit_events en utilisant un curseur existant —
    utile pour rester dans la transaction de l'action courante (ex
    workflow apply_transition).

    Le caller est responsable du ``commit()`` / ``rollback()``. La
    table n'a pas de ``updated_at`` (immutable).
    """
    payload_dict = payload or {}
    cur.execute(
        f"INSERT INTO compta_esms.audit_events ({_COLUMNS_SQL}) " f"VALUES ({_PLACEHOLDERS})",
        (
            str(company_id),
            str(user_id),
            str(document_id) if document_id is not None else None,
            action,
            resource_type,
            str(resource_id),
            _wrap_jsonb(payload_dict),
        ),
    )


def record_event(
    *,
    company_id: UUID,
    user_id: UUID,
    action: str,
    resource_type: str,
    resource_id: UUID,
    payload: dict[str, Any] | None = None,
    document_id: UUID | None = None,
) -> None:
    """Variante standalone — ouvre sa propre connexion. À utiliser
    pour des audits hors transaction métier (export, accès sensible).
    """
    with cursor() as cur:
        record_event_in(
            cur,
            company_id=company_id,
            user_id=user_id,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            payload=payload,
            document_id=document_id,
        )


# ---------------------------------------------------------------------------
# Lecture — L2 §22.1 GET /documents/{doc_id}/audit (admin)
# ---------------------------------------------------------------------------


# Cap dur côté service — la route enforce déjà mais on double-check.
_AUDIT_LIMIT_MAX: int = 500
_AUDIT_LIMIT_MIN: int = 1


async def list_for_document(
    document_id: UUID,
    company_id: UUID,
    *,
    action_filter: str | None = None,
    limit: int = 50,
) -> list[AuditEventRead]:
    """L2 §22.1 — historique d'un document.

    Charge le document d'abord pour vérifier qu'il existe ET qu'il
    appartient à la company (404 sinon — pas de leak de doc_id
    cross-tenant). Délègue ensuite à :func:`audit_repo.list_by_document`.

    Args:
        document_id: UUID du document.
        company_id: UUID de la company appelante (tenant guard).
        action_filter: si non-None, filtre exact sur ``action``.
        limit: rows max (clampé à [1, 500]).

    Returns:
        Liste de :class:`AuditEventRead` ordonnée ``occurred_at DESC``.

    Raises:
        NotFoundError: document inexistant ou cross-tenant.
        ValidationError: limit hors plage.
    """
    if limit < _AUDIT_LIMIT_MIN or limit > _AUDIT_LIMIT_MAX:
        raise ValidationError(
            f"limit={limit} hors plage [{_AUDIT_LIMIT_MIN}, {_AUDIT_LIMIT_MAX}].",
            code="audit_limit_out_of_range",
        )

    doc = await run_in_thread(document_repo.get_by_id, document_id)
    if doc is None or str(doc["company_id"]) != str(company_id):
        raise NotFoundError(
            f"document_not_found:{document_id}",
            code="document_not_found",
        )

    rows = await run_in_thread(
        audit_repo.list_by_document,
        document_id,
        action_filter=action_filter,
        limit=limit,
    )
    return [AuditEventRead.model_validate(r) for r in rows]
