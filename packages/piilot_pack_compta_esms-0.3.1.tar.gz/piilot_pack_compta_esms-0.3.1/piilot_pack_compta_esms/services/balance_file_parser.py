"""Source-file parser + column heuristic for the balance assistant.

The cabinet uploads a balance comptable in one of two formats :
``.xlsx`` (most common, exported from Pennylane / Sage / EBP / Cegid)
or ``.csv`` (rare, but trivially handled). The plugin needs three
things from the file :

1. **A clean copy to store on S3** — XLSX often carries macros, DDE
   formulas and external links. We re-emit the workbook with
   ``data_only=True`` (formula values, not expressions) so the
   archived file is free of executable content.

2. **A row count** — for ``balance_imports.nb_lignes_source``.

3. **A header-based column-role guess** — `{compte, libelle, debit,
   credit, solde, periode}` mapped to 0-based column indices. The
   cabinet overrides via ``:detect-columns``.

Plus a 20-row preview snippet for ``GET .../preview`` so the
frontend renders without re-downloading from S3.

Parsing strategy :

* **XLSX** : ``openpyxl.load_workbook(io.BytesIO(b), data_only=True,
  read_only=True)``. ``data_only=True`` neutralises formulas + DDE
  injection vectors ; ``read_only=True`` streams instead of holding
  the whole sheet in memory (matters at 5 000+ rows). The active
  sheet's first sheet is used unless the cabinet explicitly picks
  another in a future iteration.
* **CSV** : ``csv.Sniffer.sniff`` to guess the dialect (delimiter ;
  Excel French defaults to ``;`` not ``,``), then ``csv.reader``.

Both paths produce a uniform ``(header_row, data_rows)`` tuple keyed
by 0-based column index.
"""

from __future__ import annotations

import csv
import io
import re
import unicodedata
from typing import Any

from openpyxl import load_workbook

PREVIEW_LIMIT = 20
HEADER_SCAN_LIMIT = 5  # how many rows from the top we'll try as header

# Role-aware heuristic : each role lists tokens we expect to find in
# the cabinet's header. We **normalise** both the header cell and the
# tokens (strip accents, lower-case, collapse whitespace) before
# matching, so "Libellé" / "LIBELLE" / "libellé" all hit the same key.
ROLE_TOKENS: dict[str, tuple[str, ...]] = {
    "compte": ("compte", "n compte", "num compte", "numero compte", "n cpt"),
    "libelle": ("libelle", "libelle compte", "intitule", "designation", "nom compte"),
    "debit": ("debit", "total debit", "montant debit", "deb"),
    "credit": ("credit", "total credit", "montant credit", "cre"),
    "solde": ("solde", "solde net", "solde periode", "balance"),
    "periode": ("periode", "exercice", "mois", "date", "annee"),
}


def _normalise(s: str) -> str:
    """Strip accents, lower-case, collapse whitespace.

    Matches the way the cabinet usually exports : "Libellé compte" /
    "LIBELLE COMPTE" / "libelle  compte" → ``"libelle compte"``."""
    if not s:
        return ""
    decomposed = unicodedata.normalize("NFKD", s)
    no_accents = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return re.sub(r"\s+", " ", no_accents).strip().lower()


def detect_roles(header: list[str]) -> dict[str, int | None]:
    """Map each role to the index of the best-matching header cell.

    Two-pass : (1) exact normalised match wins (cell == token), (2)
    substring match for cells like "Solde N" / "Période 2026-01". On a
    tie within a pass, the leftmost column wins (cabinets put compte
    / libellé before the numeric columns).
    """
    norm_header = [_normalise(h or "") for h in header]
    out: dict[str, int | None] = {role: None for role in ROLE_TOKENS}

    # Pass 1 — exact match
    for role, tokens in ROLE_TOKENS.items():
        for idx, cell in enumerate(norm_header):
            if cell in tokens:
                out[role] = idx
                break

    # Pass 2 — substring fallback for roles still unset
    for role, tokens in ROLE_TOKENS.items():
        if out[role] is not None:
            continue
        for idx, cell in enumerate(norm_header):
            if any(tok in cell for tok in tokens):
                out[role] = idx
                break
    return out


def apply_hints(
    detection: dict[str, int | None], hints: dict[str, int | None]
) -> dict[str, int | None]:
    """Overlay user-supplied hints on top of the auto-detection.

    ``hints`` maps role → column index (or None to explicitly unset a
    role). Keys not in :data:`ROLE_TOKENS` are ignored — defends
    against a frontend mistakenly submitting an extra column."""
    out = dict(detection)
    for role, value in hints.items():
        if role in ROLE_TOKENS:
            out[role] = value
    return out


def parse_xlsx(
    body: bytes,
) -> tuple[list[str], list[list[Any]]]:
    """Return ``(header, data_rows)`` from an XLSX file.

    Uses the first sheet. The header is the first non-empty row in
    the first :data:`HEADER_SCAN_LIMIT` rows — cabinets sometimes
    leave a logo or a title above the table. Data rows start
    immediately after the header.
    """
    wb = load_workbook(io.BytesIO(body), data_only=True, read_only=True)
    try:
        ws = wb.active
        # Find the header : first row with ≥ 2 non-null cells.
        header: list[str] = []
        data_rows: list[list[Any]] = []
        header_found = False
        header_row_index = -1
        for row_idx, row in enumerate(ws.iter_rows(values_only=True), start=0):
            if not header_found:
                non_null = [c for c in row if c is not None and str(c).strip()]
                if len(non_null) >= 2 and row_idx < HEADER_SCAN_LIMIT:
                    header = ["" if c is None else str(c) for c in row]
                    header_found = True
                    header_row_index = row_idx
                continue
            # Skip trailing blank rows that openpyxl sometimes emits.
            if all(c is None or (isinstance(c, str) and not c.strip()) for c in row):
                continue
            data_rows.append(list(row))
        if not header_found:
            return [], []
        del header_row_index  # silence unused — kept for future debug
        return header, data_rows
    finally:
        wb.close()


def parse_csv(body: bytes) -> tuple[list[str], list[list[Any]]]:
    """Return ``(header, data_rows)`` from a CSV body.

    Auto-detects the dialect via :class:`csv.Sniffer` — handles French
    Excel exports (``;`` delimiter, double-quote escaping). Falls
    back to ``;`` if sniffing fails (sample too short)."""
    try:
        text = body.decode("utf-8-sig")  # tolerates BOM from Excel
    except UnicodeDecodeError:
        # Latin-1 covers most legacy French Excel exports
        text = body.decode("latin-1")

    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:

        class _Fallback(csv.Dialect):
            delimiter = ";"
            quotechar = '"'
            doublequote = True
            skipinitialspace = True
            lineterminator = "\r\n"
            quoting = csv.QUOTE_MINIMAL

        dialect = _Fallback

    reader = csv.reader(io.StringIO(text), dialect)
    rows = list(reader)
    if not rows:
        return [], []
    return rows[0], rows[1:]


def parse(body: bytes, *, filename: str) -> dict[str, Any]:
    """Parse ``body`` according to ``filename`` extension and return a
    dict ready to persist on ``balance_imports`` :

    .. code-block:: python

        {
            "nb_lignes_source": int,
            "column_detection": {role: col_idx | None, ...},
            "preview_data": [[cell, cell, ...], ...],   # ≤ 20 rows
            "header": [cell, cell, ...],
        }

    The route layer hands the dict straight to the repository.
    """
    lower = filename.lower()
    if lower.endswith(".xlsx") or lower.endswith(".xlsm"):
        header, data_rows = parse_xlsx(body)
    elif lower.endswith(".csv") or lower.endswith(".tsv"):
        header, data_rows = parse_csv(body)
    else:
        raise ValueError(
            f"Unsupported file type {filename!r} — expected .xlsx, .xlsm, .csv or .tsv"
        )

    return {
        "header": header,
        "nb_lignes_source": len(data_rows),
        "column_detection": detect_roles(header),
        # Cast everything to JSON-serialisable types — psycopg2 will
        # complain on date / Decimal otherwise. We store header
        # *inside* the preview payload so :preview can return both
        # without a separate column (the JSONB shape is opaque to PG).
        "preview_data": {
            "header": [_jsonable(cell) for cell in header],
            "rows": [[_jsonable(cell) for cell in row] for row in data_rows[:PREVIEW_LIMIT]],
        },
    }


def _jsonable(value: Any) -> Any:
    """Cast a parsed cell to a JSON-serialisable type.

    Strings, ints, floats, bools, None pass through. dates / decimals
    become ISO strings — psycopg2 ``Json()`` adapter rejects them
    otherwise. We do not try to *interpret* the value (eg. detect
    "12,50" as a French decimal) — that's the parser's job in
    §F.5 when the apply-mapping pass actually consumes the cell."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def extract_source_accounts(
    body: bytes,
    *,
    filename: str,
    column_detection: dict[str, int | None],
) -> list[dict[str, Any]]:
    """Return one ``{source_account, label_hint}`` per **distinct**
    source account in the file.

    Used by the §F.4 suggestion pipeline : the cabinet uploaded the
    full file at §F.3, but we only stored 20 preview rows. The
    suggestion pass needs every distinct account so it can score each
    one through the KB / preset / LLM tiers and persist a row per
    account in ``balance_imports.suggestions``.

    Column indices come from ``column_detection`` (the cabinet may
    have overridden them via ``:detect-columns``). Returns an empty
    list if the ``compte`` role isn't set — there's no way to identify
    accounts without it.
    """
    compte_idx = column_detection.get("compte")
    if compte_idx is None:
        return []
    libelle_idx = column_detection.get("libelle")

    lower = filename.lower()
    if lower.endswith((".xlsx", ".xlsm")):
        _header, data_rows = parse_xlsx(body)
    elif lower.endswith((".csv", ".tsv")):
        _header, data_rows = parse_csv(body)
    else:
        return []

    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for row in data_rows:
        if compte_idx >= len(row):
            continue
        raw = row[compte_idx]
        if raw is None:
            continue
        account = str(raw).strip()
        if not account or account in seen:
            continue
        seen.add(account)
        label = None
        if libelle_idx is not None and libelle_idx < len(row):
            label_raw = row[libelle_idx]
            if label_raw is not None:
                label = str(label_raw).strip() or None
        out.append({"source_account": account, "label_hint": label})
    return out


def sanitize_xlsx(body: bytes) -> bytes:
    """Re-emit the XLSX with formulas replaced by their cached values.

    ``openpyxl.load_workbook(..., data_only=True)`` reads the cached
    last-saved values rather than the formula text — saving back to a
    new BytesIO produces a workbook where every cell is a literal.
    Macros, external links and DDE references don't survive the
    round-trip either."""
    wb = load_workbook(io.BytesIO(body), data_only=True)
    out = io.BytesIO()
    wb.save(out)
    wb.close()
    return out.getvalue()
