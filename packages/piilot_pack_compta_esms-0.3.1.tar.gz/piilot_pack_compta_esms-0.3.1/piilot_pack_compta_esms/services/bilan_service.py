"""Bilan service (§K, L2 §14).

Orchestre :

* :func:`list_bilan` — GET §14.1 (filter ?type_bilan optionnel)
* :func:`bulk_upsert_bilan` — POST §14.2 (replace by type_bilan Q3
  + auto-déduction PC/PNL via og.plan_comptable Q1 + rejet
  incohérent 422)
* :func:`compute_totals` — GET §14.3 (paramètre ?type_bilan optionnel
  Q4 — sinon retourne tous les présents)
* :func:`validate_equilibre` — POST §14.4 (C-56/C-57 TOTAL BIENS =
  TOTAL FINANCEMENTS, tolérance 0.01€ Q5)

Soft validation (Q7 + Q8) : ``type_actif_passif`` manquant log
INFO sans bloquer (DDL nullable). ``montant_soins_n /
dependance_n / hebergement_n`` (Suivi EHPAD) acceptés sur tous
les types_bilan — l'UI les utilise seulement pour comptable_pc
(D-086 onglet exclusif PC).
"""

from __future__ import annotations

import logging
from collections import defaultdict
from decimal import Decimal
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.bilan import (
    BilanBulkUpsertRequest,
    BilanLigneRead,
    BilanResponse,
    BilanSectionTotal,
    BilanTotalsForType,
    BilanTotalsResponse,
    BilanValidationIssue,
    BilanValidationResult,
    PlanComptable,
    TypeBilan,
)
from piilot_pack_compta_esms.repositories import bilan_repo
from piilot_pack_compta_esms.services import bilan_variante, document_freeze, document_scope
from piilot_pack_compta_esms.services.errors import (
    NotFoundError,
    ValidationError,
)

logger = logging.getLogger(__name__)

_ZERO = Decimal("0")
_TOLERANCE_C56_C57 = Decimal("0.01")
"""Q5 — cohérent §I équilibre strict + §J C-79/C-80."""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(bilan_repo.document_belongs_to_company, document_id, company_id)
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


async def _load_plan_comptable(document_id: UUID, company_id: UUID) -> dict:
    ctx = await run_in_thread(bilan_repo.get_doc_plan_comptable, document_id, company_id)
    if ctx is None:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )
    return ctx


# ---------------------------------------------------------------------------
# §14.1 — list bilan
# ---------------------------------------------------------------------------


async def list_bilan(
    document_id: UUID,
    company_id: UUID,
    *,
    type_bilan: str | None = None,
) -> BilanResponse:
    ctx = await _load_plan_comptable(document_id, company_id)
    rows = await run_in_thread(bilan_repo.list_by_document, document_id, type_bilan=type_bilan)
    plan_comptable: PlanComptable | None = ctx.get("plan_comptable")  # type: ignore[assignment]
    return BilanResponse(
        plan_comptable_og=plan_comptable,
        items=[BilanLigneRead.model_validate(r) for r in rows],
    )


# ---------------------------------------------------------------------------
# §14.2 — bulk upsert (replace by type_bilan)
# ---------------------------------------------------------------------------


async def bulk_upsert_bilan(
    document_id: UUID,
    company_id: UUID,
    payload: BilanBulkUpsertRequest,
) -> BilanResponse:
    """Replace-all par type_bilan (Q3).

    Steps :

    1. Charge ``plan_comptable`` de l'OG du document.
    2. Auto-déduit la variante comptable autorisée
       (:func:`bilan_variante.choose_bilan_comptable_variant`).
    3. Vérifie que chaque item du body est cohérent : interdit
       d'envoyer ``comptable_pnl`` si l'OG est PC, et vice versa.
       Le type ``financier`` est toujours autorisé.
    4. Groupe les items par ``type_bilan`` et appelle
       :func:`bilan_repo.replace_by_type_bilan` pour chaque groupe.
    5. Soft-warn si ``type_actif_passif`` manquant (Q8).

    Freeze §S : refuse 409 ``document_not_editable`` si le doc est
    hors ``brouillon`` — toute mutation sur un document transmis
    nécessite une nouvelle version.
    """
    await document_freeze.require_brouillon(document_id, company_id)
    await document_scope.assert_not_eps_only_doc(document_id)
    ctx = await _load_plan_comptable(document_id, company_id)
    plan_comptable = ctx.get("plan_comptable")
    expected_comptable: str | None = None
    if plan_comptable:
        try:
            expected_comptable = bilan_variante.choose_bilan_comptable_variant(plan_comptable)
        except bilan_variante.UnknownPlanComptableError:
            # OG sans plan_comptable valide — on accepte 'financier' mais
            # on refusera tout type comptable plus bas.
            expected_comptable = None

    # Group by type_bilan + check cohérence
    by_type: dict[str, list[dict]] = defaultdict(list)
    items_warn_missing_type_ap = 0
    for item in payload.items:
        if item.type_bilan in ("comptable_pc", "comptable_pnl"):
            if expected_comptable is None:
                raise ValidationError(
                    f"og.plan_comptable manquant ou inconnu — impossible de "
                    f"poser un bilan {item.type_bilan}",
                    code="og_plan_comptable_unknown",
                )
            if item.type_bilan != expected_comptable:
                raise ValidationError(
                    f"variante {item.type_bilan} incohérente avec "
                    f"og.plan_comptable={plan_comptable} (attendu "
                    f"{expected_comptable})",
                    code="incoherent_comptable_variant",
                )
        if item.type_actif_passif is None:
            items_warn_missing_type_ap += 1
        by_type[item.type_bilan].append(item.model_dump(mode="json"))

    if items_warn_missing_type_ap > 0:
        logger.info(
            "bilan_service: %d items reçus sans type_actif_passif " "(soft validation Q8) — doc %s",
            items_warn_missing_type_ap,
            document_id,
        )

    # Replace by type_bilan
    for type_bilan, items in by_type.items():
        await run_in_thread(
            bilan_repo.replace_by_type_bilan,
            company_id=company_id,
            document_id=document_id,
            type_bilan=type_bilan,
            items=items,
        )

    return await list_bilan(document_id, company_id)


# ---------------------------------------------------------------------------
# §14.3 — :totals
# ---------------------------------------------------------------------------


async def compute_totals(
    document_id: UUID,
    company_id: UUID,
    *,
    type_bilan: str | None = None,
) -> BilanTotalsResponse:
    """Aggrège par (type_bilan, section, type_actif_passif). Pivote
    en :class:`BilanTotalsForType` par type_bilan présent."""
    await _require_document(document_id, company_id)
    rows = await run_in_thread(
        bilan_repo.totals_by_type_section, document_id, type_bilan=type_bilan
    )

    # Group by (type_bilan, section) → {actif: Decimal, passif: Decimal}
    by_type: dict[str, dict[str, dict[str, Decimal]]] = defaultdict(
        lambda: defaultdict(lambda: {"actif": _ZERO, "passif": _ZERO})
    )
    for row in rows:
        type_b = row["type_bilan"]
        section = row["section"]
        ap = row["type_actif_passif"]
        total = Decimal(str(row["total"]))
        if ap == "actif":
            by_type[type_b][section]["actif"] += total
        elif ap == "passif":
            by_type[type_b][section]["passif"] += total
        # NULL → on ignore pour le verdict actif/passif (logged au PUT)

    result = BilanTotalsResponse()
    for type_b, sections_dict in by_type.items():
        by_section: list[BilanSectionTotal] = []
        total_biens = _ZERO
        total_financements = _ZERO
        for section_name in sorted(sections_dict.keys()):
            totals = sections_dict[section_name]
            actif = totals["actif"]
            passif = totals["passif"]
            by_section.append(
                BilanSectionTotal(
                    section=section_name,
                    total_actif=actif,
                    total_passif=passif,
                    ecart=actif - passif,
                )
            )
            total_biens += actif
            total_financements += passif
        block = BilanTotalsForType(
            type_bilan=type_b,  # type: ignore[arg-type]
            by_section=by_section,
            total_biens=total_biens,
            total_financements=total_financements,
            ecart=total_biens - total_financements,
        )
        if type_b == "financier":
            result.financier = block
        elif type_b == "comptable_pc":
            result.comptable_pc = block
        elif type_b == "comptable_pnl":
            result.comptable_pnl = block
    return result


# ---------------------------------------------------------------------------
# §14.4 — :validate (C-56/C-57)
# ---------------------------------------------------------------------------


async def validate_equilibre(
    document_id: UUID,
    company_id: UUID,
    *,
    type_bilan: str | None = None,
) -> BilanValidationResult:
    """C-56/C-57 — TOTAL BIENS = TOTAL FINANCEMENTS (25-deepdive §1.3),
    tolérance 0.01€ Q5.

    Si ``type_bilan`` fourni → valide seulement ce type. Sinon valide
    tous les types présents. ``valide=true`` ssi tous les types
    présents passent l'équilibre."""
    totals = await compute_totals(document_id, company_id, type_bilan=type_bilan)
    issues: list[BilanValidationIssue] = []

    checked_blocks: list[tuple[TypeBilan, BilanTotalsForType]] = []
    if totals.financier:
        checked_blocks.append(("financier", totals.financier))
    if totals.comptable_pc:
        checked_blocks.append(("comptable_pc", totals.comptable_pc))
    if totals.comptable_pnl:
        checked_blocks.append(("comptable_pnl", totals.comptable_pnl))

    if not checked_blocks:
        # Rien à valider — pas considéré comme erreur (le doc peut être
        # vide en cours de saisie).
        return BilanValidationResult(valide=True, issues=[], tolerance_appliquee=_TOLERANCE_C56_C57)

    for type_b, block in checked_blocks:
        if abs(block.ecart) > _TOLERANCE_C56_C57:
            issues.append(
                BilanValidationIssue(
                    code="ecart_above_tolerance",
                    type_bilan=type_b,
                    message=(
                        f"TOTAL BIENS ({block.total_biens:.2f}€) ≠ "
                        f"TOTAL FINANCEMENTS ({block.total_financements:.2f}€) "
                        f"pour {type_b} — écart {block.ecart:.2f}€"
                    ),
                    ecart=block.ecart,
                )
            )

    return BilanValidationResult(
        valide=not issues,
        issues=issues,
        tolerance_appliquee=_TOLERANCE_C56_C57,
    )
