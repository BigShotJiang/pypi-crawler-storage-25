"""§BI — service ``rapport_sections_service`` (D-033 / R.314-223).

Orchestre la KB plugin-owned ``rapport_budgetaire_sections`` :

1. :func:`find_or_create_rapport_kb` — idempotent (1 KB per company).
2. :func:`materialize_for_document` — appelé au create EPRD : crée la
   KB si absente et insère 9 rows initiales (1 par section_code, contenu
   vide) pour ce document.
3. :func:`load_sections_by_code` — appelé au DOCX export : retourne le
   mapping ``{section_code → contenu_md}`` pour injection.

Pattern KB plugin-owned : 1 KB par company avec une colonne text
``document_id`` filtre (cf. doc dans
:mod:`kb_templates.rapport_budgetaire_sections`).

Toutes les opérations passent par le SDK ``piilot.sdk.knowledge`` —
aucun appel direct au schéma ``compta_esms.*`` ni au core
``backend.*``.
"""

from __future__ import annotations

import logging
from datetime import date
from typing import Any
from uuid import UUID

from piilot.sdk import knowledge
from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.kb_templates.rapport_budgetaire_sections import (
    SECTION_CODES,
)

logger = logging.getLogger(__name__)

# Nom display KB côté catalogue (1 KB par company, suffixe namespace
# automatique par le core).
_KB_NAME: str = "Rapport budgétaire — Sections"
_KB_DESCRIPTION: str = (
    "Commentaires utilisateur libres par section pour le rapport DOCX "
    "accompagnant les EPRD (R.314-223). 1 row par (document EPRD, "
    "section_code). Auto-matérialisée par le plugin compta_esms."
)

# Contrat colonnes utilisé pour ``find_kbs`` (lookup idempotent).
# Les types sont ceux normalisés par le SDK (``text``/``date``).
_KB_COLUMN_CONTRACT: dict[str, str] = {
    "document_id": "text",
    "section_code": "text",
    "contenu_md": "text",
    "auteur": "text",
    "date_maj": "date",
}


# ---------------------------------------------------------------------------
# find_or_create — idempotent
# ---------------------------------------------------------------------------


def _find_existing_kb(company_id: UUID) -> str | None:
    """Cherche une KB plugin-owned matchant le contrat de colonnes.

    Retourne le ``kb_id`` (str) si trouvée, ``None`` sinon. Filtre par
    ``owner_type='plugin'`` côté Python car ``find_kbs`` retourne toutes
    les KBs matching le contrat (y compris user-created accidentelles).
    """
    candidates = knowledge.find_kbs(
        company_id=str(company_id),
        columns_required=_KB_COLUMN_CONTRACT,
        scope="company",
    )
    for cand in candidates:
        if cand.get("owner_type") == "plugin":
            return str(cand["kb_id"])
    return None


def _create_kb_with_columns(company_id: UUID) -> str:
    """Crée la KB plugin-owned + ajoute les 5 colonnes du contrat.

    Atomique côté logique : si une colonne échoue, le caller doit
    nettoyer (drop_kb). On reste défensif côté ``materialize`` mais ici
    on laisse remonter l'exception SDK.
    """
    kb = knowledge.create_kb(
        company_id=str(company_id),
        name=_KB_NAME,
        description=_KB_DESCRIPTION,
        schema_locked=True,  # plugin owns the schema; user doesn't add columns
    )
    kb_id = str(kb["id"])

    # Ordre des colonnes : document_id (key) → section_code (key) →
    # contenu_md (data) → auteur (meta) → date_maj (meta).
    knowledge.add_column(
        kb_id,
        name="document_id",
        column_type="text",
        description="UUID du document EPRD parent (clé de filtre)",
        position=0,
        is_required=True,
    )
    knowledge.add_column(
        kb_id,
        name="section_code",
        column_type="text",
        description="1 des 9 sections types (enum côté template)",
        position=1,
        is_required=True,
    )
    knowledge.add_column(
        kb_id,
        name="contenu_md",
        column_type="text",
        description="Texte libre injecté dans le DOCX (plain text v0.3)",
        position=2,
        is_required=False,
    )
    knowledge.add_column(
        kb_id,
        name="auteur",
        column_type="text",
        description="Identifiant utilisateur dernière modification",
        position=3,
        is_required=False,
    )
    knowledge.add_column(
        kb_id,
        name="date_maj",
        column_type="date",
        description="Date dernière modification",
        position=4,
        is_required=False,
    )
    return kb_id


def find_or_create_rapport_kb(company_id: UUID) -> str:
    """Retourne le ``kb_id`` de la KB rapport_sections de la company.

    Idempotent : crée la KB si elle n'existe pas, sinon retourne
    l'existante. Appelé en début de :func:`materialize_for_document`.
    """
    existing = _find_existing_kb(company_id)
    if existing is not None:
        return existing
    return _create_kb_with_columns(company_id)


# ---------------------------------------------------------------------------
# materialize_for_document — appelé au create EPRD
# ---------------------------------------------------------------------------


def _initial_rows_for_document(document_id: UUID, user_id: UUID | None) -> list[dict[str, Any]]:
    """Construit les 9 rows initiales (1 par section_code, vides)."""
    today = date.today().isoformat()
    user_str = str(user_id) if user_id else ""
    return [
        {
            "data": {
                "document_id": str(document_id),
                "section_code": section_code,
                "contenu_md": "",
                "auteur": user_str,
                "date_maj": today,
            },
            "position": idx,
        }
        for idx, section_code in enumerate(SECTION_CODES)
    ]


async def materialize_for_document(
    *,
    document_id: UUID,
    company_id: UUID,
    user_id: UUID | None = None,
) -> dict[str, Any]:
    """Idempotent : crée la KB si nécessaire et insère 9 rows initiales
    pour ``document_id`` (1 par ``section_code``).

    Si des rows existent déjà pour ce document (cas re-entrée
    défensive), on no-op (pas de duplication).

    Returns
    -------
    Dict ``{kb_id, rows_inserted, was_idempotent}`` :

    * ``kb_id`` : id de la KB (créée ou retrouvée)
    * ``rows_inserted`` : 0 ou 9
    * ``was_idempotent`` : True si on a no-op (rows déjà présentes)
    """
    kb_id = await run_in_thread(find_or_create_rapport_kb, company_id)

    # Idempotence — on vérifie qu'aucune row n'existe déjà pour ce doc.
    existing_rows = await run_in_thread(
        knowledge.find_rows,
        kb_id=kb_id,
        filters={"document_id": str(document_id)},
        limit=1,
    )
    if existing_rows:
        return {
            "kb_id": kb_id,
            "rows_inserted": 0,
            "was_idempotent": True,
        }

    rows = _initial_rows_for_document(document_id, user_id)
    n_inserted = await run_in_thread(knowledge.insert_batch, kb_id, rows)
    return {
        "kb_id": kb_id,
        "rows_inserted": int(n_inserted),
        "was_idempotent": False,
    }


# ---------------------------------------------------------------------------
# load_sections_by_code — appelé au DOCX export
# ---------------------------------------------------------------------------


async def load_sections_by_code(
    *,
    document_id: UUID,
    company_id: UUID,
) -> dict[str, str]:
    """Charge le ``contenu_md`` par ``section_code`` pour un document.

    Retourne un dict ``{section_code: contenu_md}`` (chaîne vide si la
    section existe mais n'a pas été remplie). Si la KB n'existe pas
    encore (cas EPRDs créés avant §BI), retourne ``{}`` — le DOCX
    s'auto-dégrade en n'injectant rien.

    Pas de raise sur KB manquante : le DOCX doit continuer à se
    générer même sans commentaires.
    """
    kb_id = await run_in_thread(_find_existing_kb, company_id)
    if kb_id is None:
        return {}

    rows = await run_in_thread(
        knowledge.find_rows,
        kb_id=kb_id,
        filters={"document_id": str(document_id)},
        limit=50,  # >9 pour catcher d'éventuelles duplications anormales
    )
    out: dict[str, str] = {}
    for row in rows:
        data = row.get("data") or {}
        section_code = data.get("section_code")
        if not section_code:
            continue
        contenu = data.get("contenu_md") or ""
        # En cas de doublons (anomalie), on garde le 1er trouvé pour
        # reproductibilité — l'UI KB core gère la dédup à la saisie.
        if section_code not in out:
            out[section_code] = contenu
    return out


__all__ = [
    "find_or_create_rapport_kb",
    "load_sections_by_code",
    "materialize_for_document",
]
