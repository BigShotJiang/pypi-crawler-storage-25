"""Helper pur pour la déduction de la variante d'affectation (D-082).

L'affectation a 4 variantes mécaniques (D-082 — "pas de variante
mixte") :

* ``prive_I`` — privé hors CPOM, par ESSMS
* ``prive_II`` — privé inclus CPOM, consolidé document
* ``public_I`` — public hors CPOM, par ESSMS
* ``public_II`` — public inclus CPOM, consolidé document

Valeurs de ``NatureJuridique`` côté OG (cf. ``models/og.py``, KB B.1,
5 valeurs DGCS UPPER, migration 021) :

* ``ETABLISSEMENT_PUBLIC_SANTE`` — Établissement Public de Santé (EPS)
* ``ESMS_PUBLIC_AUTONOME`` — ESMS public médico-social autonome
* ``CCAS_CIAS_COLLECTIVITE`` — CCAS / CIAS / collectivité gestionnaire
* ``PRIVE_NON_LUCRATIF`` — privé non lucratif (association, mutualiste)
* ``PRIVE_COMMERCIAL`` — privé commercial (SARL, SA)

Les 3 premières valeurs produisent ``public_*`` ; les 2 dernières
``prive_*``.

Fonction pure (no I/O). Le service §J.7 résout le contexte
(``inclus_cpom`` au niveau ETS via l'OG du doc) avant d'appeler ce
helper.
"""

from __future__ import annotations

from typing import Literal

Variante = Literal["prive_I", "prive_II", "public_I", "public_II"]
"""4 variantes d'affectation D-082."""

_PUBLIC_NATURES: frozenset[str] = frozenset(
    {
        "ETABLISSEMENT_PUBLIC_SANTE",
        "ESMS_PUBLIC_AUTONOME",
        "CCAS_CIAS_COLLECTIVITE",
    }
)
"""Natures juridiques qui produisent ``public_*``."""

_PRIVE_NATURES: frozenset[str] = frozenset({"PRIVE_NON_LUCRATIF", "PRIVE_COMMERCIAL"})
"""Natures juridiques qui produisent ``prive_*``."""


class UnknownNatureJuridiqueError(ValueError):
    """``nature_juridique`` non reconnu — input à valider en amont."""


def choose_affectation_variante(
    *,
    nature_juridique: str,
    inclus_cpom: bool,
) -> Variante:
    """Retourne la variante d'affectation (D-082).

    Règles :

    * nature ∈ {ETABLISSEMENT_PUBLIC_SANTE, ESMS_PUBLIC_AUTONOME,
      CCAS_CIAS_COLLECTIVITE} → public_*
    * nature ∈ {PRIVE_NON_LUCRATIF, PRIVE_COMMERCIAL} → prive_*
    * inclus_cpom=True → variante II (post-CPOM, consolidé document)
    * inclus_cpom=False → variante I (pré-CPOM, par ESSMS)

    Lève :class:`UnknownNatureJuridiqueError` quand la nature n'est
    dans aucune des 2 catégories — le caller doit avoir validé en
    amont (Pydantic Literal sur ``NatureJuridique``).
    """
    if nature_juridique in _PUBLIC_NATURES:
        return "public_II" if inclus_cpom else "public_I"
    if nature_juridique in _PRIVE_NATURES:
        return "prive_II" if inclus_cpom else "prive_I"
    raise UnknownNatureJuridiqueError(
        f"nature_juridique {nature_juridique!r} inconnu — "
        "vérifier le seed des OG (D-037, D-082, models.og.NatureJuridique)"
    )


def is_variant_I(variante: Variante) -> bool:
    """True si la variante est ``prive_I`` ou ``public_I`` —
    affectation par CR (cr_id obligatoire)."""
    return variante in ("prive_I", "public_I")


def is_variant_II(variante: Variante) -> bool:
    """True si la variante est ``prive_II`` ou ``public_II`` —
    affectation consolidée (cr_id nullable)."""
    return variante in ("prive_II", "public_II")
