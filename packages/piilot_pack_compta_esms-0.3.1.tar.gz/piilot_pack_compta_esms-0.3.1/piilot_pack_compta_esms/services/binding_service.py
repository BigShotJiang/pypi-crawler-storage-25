"""Service layer for D-103 bindings (L2 §7).

A binding wires a (document, feature) pair to a KB. The service :

* validates that the document belongs to the caller's company,
* validates that the KB belongs to the caller's company (or is a
  reference KB) and has a materialised dynamic table,
* validates that the feature's ``columns_required`` resolves to
  columns of the KB (after applying ``column_mapping``) — permissive
  mode (Q3.b) accepts type mismatches with warnings,
* persists the binding (upsert by ``(document, feature)``),
* drives the ``:preview`` aggregation against the bound KB,
* drives the ``:validation`` view that tells the workflow layer
  whether the document is "ready to produce".

Cf. ``models.kb_binding``, ``models.feature_catalog``,
``services.kb_discovery``, ``services.feature_catalog_service``,
``repositories.kb_binding_repo``.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.kb_binding import (
    BindingPreviewResponse,
    BindingPreviewRow,
    BindingValidationResult,
    CandidateKb,
    KbBindingCreate,
    KbBindingRead,
)
from piilot_pack_compta_esms.repositories import kb_binding_repo
from piilot_pack_compta_esms.services import (
    feature_catalog_service,
    kb_discovery,
)
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
    ValidationError,
)

# Logical types that drive the dim/measure split for :preview.
# - text / date → GROUP BY dimensions
# - numeric / integer → SUM measures
_DIMENSION_TYPES: frozenset[str] = frozenset({"text", "date"})
_MEASURE_TYPES: frozenset[str] = frozenset({"numeric", "integer"})


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    """Refuse a binding operation that targets a document of another tenant."""
    owns = await run_in_thread(kb_binding_repo.document_belongs_to_company, document_id, company_id)
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


def _split_dims_measures(
    columns_required: dict[str, str],
) -> tuple[list[str], list[str]]:
    """Partition the contract columns by role for :preview.

    Text / date columns become GROUP BY dimensions; numeric / integer
    columns become SUM measures. Unknown types are treated as
    dimensions (safer default — at worst, the preview shows them
    instead of aggregating).
    """
    dims: list[str] = []
    measures: list[str] = []
    for col, logical_type in columns_required.items():
        if logical_type in _MEASURE_TYPES:
            measures.append(col)
        else:
            dims.append(col)
    return dims, measures


# ---------------------------------------------------------------------------
# List / put / delete
# ---------------------------------------------------------------------------


async def list_bindings(document_id: UUID, company_id: UUID) -> list[KbBindingRead]:
    await _require_document(document_id, company_id)
    rows = await run_in_thread(kb_binding_repo.list_by_document, document_id)
    return [KbBindingRead.model_validate(r) for r in rows]


async def put_binding(
    *,
    document_id: UUID,
    feature_key: str,
    payload: KbBindingCreate,
    company_id: UUID,
    user_id: UUID,
) -> KbBindingRead:
    """Idempotent upsert of a binding.

    Validation steps :

    1. Document belongs to ``company_id`` (else 404).
    2. Feature key exists in the catalog (else 404).
    3. KB resolves to a materialised dynamic table accessible to the
       company (else 404).
    4. After applying ``column_mapping``, every contract column maps to
       a KB column. Missing column → 422 (hard reject). Type mismatch
       → kept implicit (warning surfaced by ``candidate-kbs`` and
       ``:preview``).
    """
    await _require_document(document_id, company_id)
    feature = await feature_catalog_service.get_feature(feature_key)
    kb_meta = await kb_discovery.fetch_kb_meta(payload.kb_id, company_id)
    if kb_meta is None:
        raise NotFoundError(
            f"kb {payload.kb_id} not accessible from this company "
            "(check ownership, plugin activation, or materialised table)",
            code="kb_not_accessible",
        )

    compatible, _warnings = kb_discovery.check_compat(
        feature.columns_required,
        kb_meta["columns"],
        payload.column_mapping,
    )
    if not compatible:
        # Identify the first missing column so the message points to it
        # — usually that's the only correction the cabinet needs.
        kb_col_names = {c["name"] for c in kb_meta["columns"]}
        mapping = payload.column_mapping
        missing = [
            col for col in feature.columns_required if mapping.get(col, col) not in kb_col_names
        ]
        raise ValidationError(
            f"kb {payload.kb_id} does not expose required column(s) "
            f"for feature {feature_key!r}: {missing}",
            code="binding_contract_violation",
        )

    row = await run_in_thread(
        kb_binding_repo.upsert,
        company_id=company_id,
        document_id=document_id,
        feature_key=feature_key,
        kb_id=payload.kb_id,
        kb_table=kb_meta["table_name"],
        column_mapping=payload.column_mapping,
        plan_comptable_source=payload.plan_comptable_source,
        bound_by_user_id=user_id,
    )
    return KbBindingRead.model_validate(row)


async def delete_binding(document_id: UUID, feature_key: str, company_id: UUID) -> None:
    await _require_document(document_id, company_id)
    deleted = await run_in_thread(kb_binding_repo.delete, document_id, feature_key)
    if not deleted:
        raise NotFoundError(
            f"binding {feature_key!r} not found on document {document_id}",
            code="binding_not_found",
        )


# ---------------------------------------------------------------------------
# Candidate KBs (L2 §7.2)
# ---------------------------------------------------------------------------


async def list_candidate_kbs(
    *,
    document_id: UUID,
    feature_key: str,
    company_id: UUID,
) -> list[CandidateKb]:
    await _require_document(document_id, company_id)
    feature = await feature_catalog_service.get_feature(feature_key)
    return await kb_discovery.list_candidate_kbs(
        company_id=company_id,
        columns_required=feature.columns_required,
    )


# ---------------------------------------------------------------------------
# Preview (L2 §7.5)
# ---------------------------------------------------------------------------


async def preview_binding(
    *,
    document_id: UUID,
    feature_key: str,
    company_id: UUID,
    filters: dict[str, Any],
    limit: int = 200,
) -> BindingPreviewResponse:
    """Run the aggregation a binding will produce, without persisting.

    Resolves the binding's KB meta, applies the saved
    ``column_mapping``, splits contract columns into dims/measures,
    delegates the SQL to :func:`kb_discovery.aggregate_preview`.
    """
    await _require_document(document_id, company_id)
    feature = await feature_catalog_service.get_feature(feature_key)
    binding_row = await run_in_thread(kb_binding_repo.get_by_doc_feature, document_id, feature_key)
    if binding_row is None:
        raise NotFoundError(
            f"no binding for feature {feature_key!r} on document {document_id}",
            code="binding_not_found",
        )

    kb_meta = await kb_discovery.fetch_kb_meta(binding_row["kb_id"], company_id)
    if kb_meta is None:
        raise ConflictError(
            "bound KB is no longer accessible — re-create the binding",
            code="binding_kb_dangling",
        )

    column_mapping = binding_row["column_mapping"] or {}
    # Resolve contract → KB logical column names. The aggregator (SDK
    # ``piilot.sdk.knowledge.aggregate`` since 0.8) takes care of the
    # logical → physical (``pg_column``) resolution internally ; we
    # just need to expose the KB-logical mapping so that the
    # plugin-side adapter knows how to re-key the result dict back
    # into contract-space for the frontend.
    kb_column_names = {c["name"] for c in kb_meta["columns"]}
    contract_to_kb_logical: dict[str, str] = {}
    for contract_col in feature.columns_required:
        kb_logical = column_mapping.get(contract_col, contract_col)
        if kb_logical not in kb_column_names:
            raise ConflictError(
                f"contract column {contract_col!r} maps to {kb_logical!r}, "
                "which is no longer in the bound KB — re-create the binding",
                code="binding_column_dangling",
            )
        contract_to_kb_logical[contract_col] = kb_logical

    dims, measures = _split_dims_measures(feature.columns_required)
    _compatible, warnings = kb_discovery.check_compat(
        feature.columns_required, kb_meta["columns"], column_mapping
    )

    rows = await kb_discovery.aggregate_preview(
        kb_id=binding_row["kb_id"],
        contract_to_kb_logical=contract_to_kb_logical,
        dimension_logical_cols=dims,
        measure_logical_cols=measures,
        filters=filters,
        limit=limit,
    )
    truncated = len(rows) >= limit
    return BindingPreviewResponse(
        feature_key=feature_key,
        rows=[BindingPreviewRow(data=dict(r)) for r in rows],
        warnings=warnings,
        row_count=len(rows),
        truncated=truncated,
    )


# ---------------------------------------------------------------------------
# Validation (L2 §7.6)
# ---------------------------------------------------------------------------


async def validation(
    *,
    document_id: UUID,
    company_id: UUID,
) -> BindingValidationResult:
    """Report which mandatory features are bound vs missing on a doc.

    The document's own ``type_document`` and the typology of the first
    CR's établissement (if any) scope the mandatory features. Documents
    without CRs yet (only the auto-CRPP, no établissement attached)
    fall back to ``typologie=None`` — the catalog filter treats this
    as "no typology restriction", so every mandatory feature still
    counts.
    """
    ctx = await run_in_thread(kb_binding_repo.load_document_context, document_id, company_id)
    if ctx is None:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )

    mandatory = await feature_catalog_service.list_features(
        doc_type=ctx["type_document"],
        typologie=ctx.get("typologie"),
        mandatory_only=True,
    )
    mandatory_keys = [f.feature_key for f in mandatory]

    rows = await run_in_thread(kb_binding_repo.list_by_document, document_id)
    bound_keys = [r["feature_key"] for r in rows]
    bound_set = set(bound_keys)
    missing = [k for k in mandatory_keys if k not in bound_set]

    return BindingValidationResult(
        mandatory_features=mandatory_keys,
        bindings_present=bound_keys,
        missing=missing,
        ready_to_produce=not missing,
    )


# Mute unused-import warning for CrossCompanyError — routes might import
# it later when we tighten 403 vs 404 distinction (kept exported here).
__all__ = [
    "delete_binding",
    "list_bindings",
    "list_candidate_kbs",
    "preview_binding",
    "put_binding",
    "validation",
    "CrossCompanyError",
]
