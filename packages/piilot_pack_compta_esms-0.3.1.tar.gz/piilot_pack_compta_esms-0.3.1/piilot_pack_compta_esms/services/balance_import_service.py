"""Service layer for ``balance_imports`` (§F.3 — upload + detection).

The full assistant flow is :

1. ``upload_balance`` — receives the cabinet's file, sanitizes XLSX
   (drops macros/DDE), pushes the clean copy to S3, parses
   header + 20 preview rows, runs the auto column-role heuristic and
   persists everything in ``compta_esms.balance_imports`` with
   ``status='pending'``. (§F.3 — this commit.)
2. ``detect_columns`` — re-runs the heuristic after the cabinet
   pasted hints (eg. "the ``solde`` column is column 4, not 5").
   (§F.3 — this commit.)
3. ``preview`` — returns header + preview rows + current detection
   for the assistant's step-2 table. (§F.3 — this commit.)
4. Suggestion pipeline (§F.4) and apply-mapping + materialisation
   (§F.5) follow.

The service stays format-agnostic ; XLSX vs CSV parsing lives in
:mod:`balance_file_parser`. Storage uses :func:`piilot.sdk.storage.put_object`
under the plugin namespace prefix.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

from piilot.sdk import storage
from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.balance_import import (
    BalanceImportPreview,
    BalanceImportRead,
    ColumnHints,
)
from piilot_pack_compta_esms.repositories import balance_import_repo
from piilot_pack_compta_esms.services import balance_file_parser
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)

# Content types we accept for upload. Reject anything else with a 415
# at the route layer ; parser would fail anyway but a clean error
# beats an obscure openpyxl traceback.
ACCEPTED_EXTENSIONS = (".xlsx", ".xlsm", ".csv", ".tsv")


def _to_read(row: dict[str, Any]) -> BalanceImportRead:
    return BalanceImportRead.model_validate(row)


async def upload_balance(
    *,
    company_id: UUID,
    user_id: UUID,
    file_bytes: bytes,
    filename: str,
    source_plan: str,
    periode_label: str,
    exercice_id: UUID | None = None,
    etablissement_id: UUID | None = None,
) -> BalanceImportRead:
    """Persist a fresh balance import.

    Steps :

    1. Validate extension.
    2. Parse the file (and sanitize XLSX through openpyxl's
       ``data_only=True`` round-trip — see :func:`balance_file_parser.sanitize_xlsx`).
    3. Upload the **sanitized** body to S3 under
       ``balance_imports/{import_id}/{filename}``.
    4. ``INSERT compta_esms.balance_imports`` with the parsed header,
       row count, column detection and 20 preview rows.
    """
    lower = filename.lower()
    if not lower.endswith(ACCEPTED_EXTENSIONS):
        raise ConflictError(
            f"Unsupported file extension for {filename!r}. "
            f"Expected one of {ACCEPTED_EXTENSIONS}.",
            code="balance_import_unsupported_format",
        )

    # Parse + sanitize. For XLSX we re-emit a clean workbook to S3 ;
    # CSV is uploaded as-is (no macros possible).
    parsed = balance_file_parser.parse(file_bytes, filename=filename)
    if parsed["nb_lignes_source"] == 0:
        raise ConflictError(
            "Source file appears empty (no data rows below the header).",
            code="balance_import_empty",
        )

    if lower.endswith((".xlsx", ".xlsm")):
        # Sanitize : re-emit through openpyxl with data_only=True.
        # Macros / external links / formulas don't survive the round-trip.
        sanitized_body = balance_file_parser.sanitize_xlsx(file_bytes)
        content_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    else:
        sanitized_body = file_bytes
        content_type = "text/csv"

    # Pre-allocate the import_id so the S3 key references the same UUID
    # the DB row will carry. ``put_object`` returns the namespaced full
    # key — that's what we persist in ``source_storage_key``.
    import_id = uuid4()
    key = f"balance_imports/{import_id}/{filename}"
    full_key = await storage.put_object(key, sanitized_body, content_type=content_type)

    row = await run_in_thread(
        balance_import_repo.create,
        company_id=company_id,
        user_id=user_id,
        source_plan=source_plan,
        source_filename=filename,
        source_storage_key=full_key,
        periode_label=periode_label,
        nb_lignes_source=parsed["nb_lignes_source"],
        column_detection=parsed["column_detection"],
        preview_data=parsed["preview_data"],
        exercice_id=exercice_id,
        etablissement_id=etablissement_id,
    )
    return _to_read(row)


async def get_import(import_id: UUID) -> BalanceImportRead:
    row = await run_in_thread(balance_import_repo.get_by_id, import_id)
    if row is None:
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )
    return _to_read(row)


async def detect_columns(import_id: UUID, hints: ColumnHints | None = None) -> BalanceImportRead:
    """Override the column detection with cabinet-supplied hints.

    Reads the current row, layers the hints on top via
    :func:`balance_file_parser.apply_hints`, persists the new detection.
    Hints with value ``None`` explicitly unset a role (cabinet says
    "the ``solde`` column doesn't exist in this balance")."""
    current = await run_in_thread(balance_import_repo.get_by_id, import_id)
    if current is None:
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )
    current_detection = current["column_detection"]
    if hints is not None:
        # ``model_dump(exclude_unset=True)`` keeps only the keys the
        # frontend actually sent — None values pass through as
        # explicit unsets.
        hint_payload = hints.model_dump(exclude_unset=True)
        new_detection = balance_file_parser.apply_hints(current_detection, hint_payload)
    else:
        new_detection = current_detection

    row = await run_in_thread(
        balance_import_repo.update_column_detection,
        import_id,
        new_detection,
    )
    if row is None:
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )
    return _to_read(row)


async def get_preview(import_id: UUID) -> BalanceImportPreview:
    """Return header + preview rows + detection for the step-2 table.

    The ``preview_data`` JSONB carries both the parsed header and the
    first 20 data rows (cf. :func:`balance_file_parser.parse`)."""
    row = await run_in_thread(balance_import_repo.get_by_id, import_id)
    if row is None:
        raise NotFoundError(
            f"Balance import {import_id} not found",
            code="balance_import_not_found",
        )
    preview = row["preview_data"] or {}
    return BalanceImportPreview(
        header=preview.get("header", []),
        rows=preview.get("rows", []),
        column_detection=row["column_detection"],
    )
