"""Emprunts service (§N, L2 §16.3-§16.4).

Orchestre :

* :func:`list_emprunts` — GET §16.3 (items + totals by_type_dette,
  optionnellement filtré par ``?type_dette=``)
* :func:`bulk_upsert_emprunts` — POST §16.4 (replace_by_document_and_type_dette
  Q4 — précédent §K Bilan, pas §M)

``totals`` inclus dans GET (Q6). Pas d'endpoint ``:totals`` séparé.

Contrôles croisés vers Bilan (C-66/C-71/C-72) différés en §Z (Q8).
"""

from __future__ import annotations

from decimal import Decimal
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.emprunts import (
    EmpruntRead,
    EmpruntsBulkUpsertRequest,
    EmpruntsMontants,
    EmpruntsResponse,
    EmpruntsTotals,
    EmpruntsTypeDetteTotals,
    TypeDette,
)
from piilot_pack_compta_esms.repositories import emprunts_repo
from piilot_pack_compta_esms.services import document_freeze, document_scope
from piilot_pack_compta_esms.services.errors import NotFoundError

_ZERO = Decimal("0")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(emprunts_repo.document_belongs_to_company, document_id, company_id)
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


def _safe_decimal(value) -> Decimal:  # noqa: ANN001
    if value is None:
        return _ZERO
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def _build_totals(rows_by_type: list[dict]) -> EmpruntsTotals:
    """Construit :class:`EmpruntsTotals` depuis l'aggregate par
    type_dette. ``total_general`` somme tous les types présents
    (ou seulement le type filtré si filter actif)."""
    by_type: list[EmpruntsTypeDetteTotals] = []
    sum_cap_emp = _ZERO
    sum_rem_n1 = _ZERO
    sum_rem_n = _ZERO
    sum_int_n1 = _ZERO
    sum_int_n = _ZERO
    sum_solde = _ZERO
    for row in rows_by_type:
        cap_emp = _safe_decimal(row.get("capital_emprunte_total"))
        rem_n1 = _safe_decimal(row.get("capital_rembourse_n1_total"))
        rem_n = _safe_decimal(row.get("capital_rembourse_n_total"))
        int_n1 = _safe_decimal(row.get("interets_n1_total"))
        int_n = _safe_decimal(row.get("interets_n_total"))
        solde = _safe_decimal(row.get("solde_restant_du_total"))
        sum_cap_emp += cap_emp
        sum_rem_n1 += rem_n1
        sum_rem_n += rem_n
        sum_int_n1 += int_n1
        sum_int_n += int_n
        sum_solde += solde
        by_type.append(
            EmpruntsTypeDetteTotals(
                type_dette=row["type_dette"],  # type: ignore[arg-type]
                nb_lignes=int(row.get("nb_lignes", 0)),
                montants=EmpruntsMontants(
                    capital_emprunte_total=cap_emp,
                    capital_rembourse_n1_total=rem_n1,
                    capital_rembourse_n_total=rem_n,
                    interets_n1_total=int_n1,
                    interets_n_total=int_n,
                    solde_restant_du_total=solde,
                ),
            )
        )
    total_general = EmpruntsMontants(
        capital_emprunte_total=sum_cap_emp,
        capital_rembourse_n1_total=sum_rem_n1,
        capital_rembourse_n_total=sum_rem_n,
        interets_n1_total=sum_int_n1,
        interets_n_total=sum_int_n,
        solde_restant_du_total=sum_solde,
    )
    return EmpruntsTotals(by_type_dette=by_type, total_general=total_general)


# ---------------------------------------------------------------------------
# §16.3 — list_emprunts
# ---------------------------------------------------------------------------


async def list_emprunts(
    document_id: UUID,
    company_id: UUID,
    type_dette: TypeDette | None = None,
) -> EmpruntsResponse:
    """Items + totals, optionnellement filtré par type_dette."""
    await _require_document(document_id, company_id)
    rows = await run_in_thread(emprunts_repo.list_by_document, document_id, type_dette)
    totals_rows = await run_in_thread(emprunts_repo.totals_by_type_dette, document_id, type_dette)
    return EmpruntsResponse(
        type_dette_filtre=type_dette,
        items=[EmpruntRead.model_validate(r) for r in rows],
        totals=_build_totals(totals_rows),
    )


# ---------------------------------------------------------------------------
# §16.4 — bulk_upsert_emprunts (replace_by_document_and_type_dette Q4)
# ---------------------------------------------------------------------------


async def bulk_upsert_emprunts(
    document_id: UUID,
    company_id: UUID,
    payload: EmpruntsBulkUpsertRequest,
) -> EmpruntsResponse:
    """Replace by document AND type_dette — atomique (Q4).

    Ne touche QUE les lignes du type_dette donné. Le GET de retour
    re-filtre sur le même type_dette pour cohérence avec ce qui vient
    d'être saved.

    Freeze §S : 409 si document hors brouillon."""
    await document_freeze.require_brouillon(document_id, company_id)
    await document_scope.assert_not_eps_only_doc(document_id)
    await _require_document(document_id, company_id)
    items_dict = [item.model_dump(mode="json") for item in payload.items]
    await run_in_thread(
        emprunts_repo.replace_by_document_and_type_dette,
        company_id=company_id,
        document_id=document_id,
        type_dette=payload.type_dette,
        items=items_dict,
    )
    return await list_emprunts(document_id, company_id, type_dette=payload.type_dette)


__all__ = [
    "list_emprunts",
    "bulk_upsert_emprunts",
]
