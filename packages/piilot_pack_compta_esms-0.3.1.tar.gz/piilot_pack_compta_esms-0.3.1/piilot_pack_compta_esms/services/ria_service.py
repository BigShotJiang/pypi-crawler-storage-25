"""Service §W RIA — Rapport Infra-Annuel (D-065 + D-087).

Calcul de l'onglet exclusif ``Synthèse résultats`` (KB23 §3.3 + KB25
§14) : 1 ligne par CR du RIA + 1 ligne TOTAL, avec 3 colonnes :

* **Résultat comptable N-1** — pulled from the ERRD N-1 of the same OG
  (executoire/affectation_definie statuses only).
* **Dernier EPRD exécutoire N** — Σ ``crp_lignes.montant_previsions_totales``
  du parent EPRD (forcément exécutoire à l'heure où le RIA est cloné §V).
* **Projection actualisée N** — Σ ``crp_lignes.montant_previsions_totales``
  du RIA lui-même (saisie du cabinet).

Matching CR RIA ↔ CR parent EPRD ↔ CR ERRD N-1 par ``(etablissement_id,
cr_type)`` — le périmètre du RIA est hérité du parent EPRD via §V, donc
le matching parent est garanti 1:1 sauf cas dégénéré (CR sans
etablissement_id, e.g. CRP_SF en cours de configuration).

**0 contrôle intégré** (D-087) — pas de side-effect sur le RIA ni audit
log : lecture seule, read-only.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.ria import (
    SyntheseResultatsCell,
    SyntheseResultatsResponse,
    SyntheseResultatsRow,
    SyntheseResultatsTotal,
)
from piilot_pack_compta_esms.repositories import cr_repo, document_repo
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError


async def _load_ria_with_parent(ria_id: UUID, company_id: UUID) -> dict[str, Any]:
    """Charge le RIA, valide tenant + type='ria' + parent_id non-NULL.

    Pattern aligné §V ``_load_dm_with_parent`` — mêmes 3 codes d'erreur
    avec ``ria_*`` au lieu de ``dm_*`` (404 document_not_found, 409
    not_a_ria, 409 ria_orphan).
    """
    row = await run_in_thread(document_repo.get_by_id, ria_id)
    if row is None:
        raise NotFoundError(f"document_not_found:{ria_id}", code="document_not_found")
    if str(row["company_id"]) != str(company_id):
        raise NotFoundError(f"document_not_found:{ria_id}", code="document_not_found")
    if row["type_document"] != "ria":
        raise ConflictError(
            f"document {ria_id} is not a RIA (got type='{row['type_document']}')",
            code="not_a_ria",
        )
    if row["parent_id"] is None:
        # Defensive — Pydantic + §E.3 garantissent parent_id pour RIA.
        raise ConflictError(
            f"RIA {ria_id} has no parent_id (data corruption)",
            code="ria_orphan",
        )
    return row


def _cell_from_charges_produits(values: dict[str, Decimal]) -> SyntheseResultatsCell:
    charges = values.get("charges", Decimal(0))
    produits = values.get("produits", Decimal(0))
    return SyntheseResultatsCell(
        charges=charges,
        produits=produits,
        resultat=produits - charges,
    )


def _match_key(cr_row: dict[str, Any]) -> tuple[str, str]:
    """Composite key for matching a CR across documents : ``(etablissement_id, cr_type)``.

    NULL ``etablissement_id`` is bucketed under ``""`` so a CRP_SF
    (section financière, no ETS) on the RIA still matches the parent's
    CRP_SF (also no ETS). Two CRs of the same ``cr_type`` without
    ``etablissement_id`` on the same document would collide — that's
    fine, the data model doesn't allow it in practice (one CRPP per
    document, one CRP_SF per document).
    """
    ets = cr_row.get("etablissement_id")
    return (str(ets) if ets is not None else "", cr_row["cr_type"])


def _build_match_index(
    cr_rows: list[dict[str, Any]],
    aggregates: dict[UUID, dict[str, Decimal]],
) -> dict[tuple[str, str], dict[str, Decimal]]:
    """Index CR aggregates by ``(etablissement_id, cr_type)`` for matching.

    ``cr_rows`` is the full CR list of a foreign document (parent EPRD
    or ERRD N-1). ``aggregates`` is the ``{cr_id: {charges, produits}}``
    mapping from the repo. Returns a key→aggregate dict, with empty
    aggregates filled-in for CRs without saisie (LEFT JOIN already
    handled this in the repo, but defensive here).
    """
    index: dict[tuple[str, str], dict[str, Decimal]] = {}
    for cr in cr_rows:
        key = _match_key(cr)
        cr_id = cr.get("id") if "id" in cr else cr.get("cr_id")
        agg = aggregates.get(cr_id, {"charges": Decimal(0), "produits": Decimal(0)})
        index[key] = agg
    return index


async def compute_synthese_resultats(
    *,
    ria_id: UUID,
    company_id: UUID,
) -> SyntheseResultatsResponse:
    """Build the RIA Synthèse résultats response (D-065, KB25 §14).

    Steps :

    1. Load the RIA + its EPRD parent (404/409 defensive).
    2. Load the CR list of the RIA — source of truth for the synthèse rows.
    3. Aggregate ``montant_previsions_totales`` per CR : RIA + parent EPRD.
    4. Optionally find an ERRD N-1 finalised, aggregate ``montant_realise``
       per CR. If absent → ``errd_n_minus_1_id=None`` and every row's
       ``resultat_comptable_n_minus_1`` stays ``None``.
    5. Match RIA CRs to parent CRs and ERRD CRs by ``(etablissement_id, cr_type)``.
    6. Compute the TOTAL row by summing each column.
    """
    ria_row = await _load_ria_with_parent(ria_id, company_id)
    parent_id: UUID = ria_row["parent_id"]

    # CRs du RIA — source de vérité du périmètre de la synthèse.
    ria_crs = await run_in_thread(cr_repo.list_by_document, ria_id)
    ria_aggregates = await run_in_thread(cr_repo.aggregate_charges_produits_by_cr, ria_id)
    parent_aggregates = await run_in_thread(cr_repo.aggregate_charges_produits_by_cr, parent_id)
    parent_crs = await run_in_thread(cr_repo.list_by_document, parent_id)
    parent_index = _build_match_index(parent_crs, parent_aggregates)

    # ERRD N-1 — optionnel. Si absent, on retourne la synthèse sans la
    # colonne N-1 (cas normal de la 1ère année d'opération d'un OG).
    errd_row = await run_in_thread(document_repo.find_errd_n_minus_1_for_ria, ria_id, company_id)
    errd_n_minus_1_id: UUID | None = None
    errd_index: dict[tuple[str, str], dict[str, Decimal]] = {}
    if errd_row is not None:
        errd_n_minus_1_id = errd_row["id"]
        errd_aggregates = await run_in_thread(cr_repo.aggregate_realise_by_cr, errd_n_minus_1_id)
        errd_crs = await run_in_thread(cr_repo.list_by_document, errd_n_minus_1_id)
        errd_index = _build_match_index(errd_crs, errd_aggregates)

    rows: list[SyntheseResultatsRow] = []
    total_proj_charges = Decimal(0)
    total_proj_produits = Decimal(0)
    total_eprd_charges = Decimal(0)
    total_eprd_produits = Decimal(0)
    total_eprd_seen = False
    total_n_minus_1 = Decimal(0)
    total_n_minus_1_seen = False

    for cr in ria_crs:
        key = _match_key(cr)
        proj_agg = ria_aggregates.get(cr["id"], {"charges": Decimal(0), "produits": Decimal(0)})
        projection_cell = _cell_from_charges_produits(proj_agg)
        total_proj_charges += projection_cell.charges
        total_proj_produits += projection_cell.produits

        eprd_cell: SyntheseResultatsCell | None = None
        if key in parent_index:
            eprd_cell = _cell_from_charges_produits(parent_index[key])
            total_eprd_charges += eprd_cell.charges
            total_eprd_produits += eprd_cell.produits
            total_eprd_seen = True

        resultat_n_minus_1: Decimal | None = None
        if key in errd_index:
            agg = errd_index[key]
            resultat_n_minus_1 = agg["produits"] - agg["charges"]
            total_n_minus_1 += resultat_n_minus_1
            total_n_minus_1_seen = True

        rows.append(
            SyntheseResultatsRow(
                cr_id=cr["id"],
                cr_type=cr["cr_type"],
                denomination=cr["denomination"],
                etablissement_id=cr["etablissement_id"],
                resultat_comptable_n_minus_1=resultat_n_minus_1,
                eprd_executoire_n=eprd_cell,
                projection_actualisee_n=projection_cell,
            )
        )

    total = SyntheseResultatsTotal(
        resultat_comptable_n_minus_1=total_n_minus_1 if total_n_minus_1_seen else None,
        eprd_executoire_n=(
            SyntheseResultatsCell(
                charges=total_eprd_charges,
                produits=total_eprd_produits,
                resultat=total_eprd_produits - total_eprd_charges,
            )
            if total_eprd_seen
            else None
        ),
        projection_actualisee_n=SyntheseResultatsCell(
            charges=total_proj_charges,
            produits=total_proj_produits,
            resultat=total_proj_produits - total_proj_charges,
        ),
    )

    return SyntheseResultatsResponse(
        ria_id=ria_id,
        parent_eprd_id=parent_id,
        errd_n_minus_1_id=errd_n_minus_1_id,
        rows=rows,
        total=total,
    )
