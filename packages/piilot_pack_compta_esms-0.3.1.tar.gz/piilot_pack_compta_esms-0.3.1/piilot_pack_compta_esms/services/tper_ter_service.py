"""TPER/TER service (§P, L2 §11).

Orchestre 3 fonctions sur 4 endpoints (le :prefill vit dans
:mod:`tper_ter_prefill` pour isoler la complexité §G binding) :

* :func:`list_tper_ter` — GET §11.1 (filtre ets_id + type_tableau)
* :func:`bulk_upsert_tper_ter` — POST §11.2 (replace_by_doc_ets_type
  Q3, auto-déduit ``type_etablissement`` depuis ``etablissements.typologie``
  Q9)
* :func:`compute_totals` — GET §11.4 (by_categorie + by_section
  pondéré par pct_section + total_general)

Permissions L2 §11 strict : **user partout** (Q10) — y compris bulk
et prefill. C'est la spec qui le dit (différent §K/§N).

Référentiel CNSA D-043+D-044 via PLT-44 KB core. Validation
fail-open par :mod:`reference_lookup` (cohérent §H.4 — warn si KB ref
pas sync mais accepte la valeur).

``type_etablissement`` (Q9) : auto-déduit via
:func:`reference_lookup.deduce_type_etablissement` depuis
``etablissements.typologie``. Mapping :

* ehpad/aja/puv → ehpad_aja
* fam/samsah → fam_samsah
* sad/spasad → sad_spasad
* autres → autre_essms (fallback safe — référent PLT-44 8 catégories
  s'applique aussi à "Autres ESSMS")

Validation P/T ETPR > 0, ETPT < ETPR, "ASG = 100% soins", etc. → §Z
(catalogue 114 lignes contrôles 18-annexe6 §8).
"""

from __future__ import annotations

import logging
from decimal import Decimal
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.models.tper_ter import (
    TperTerBulkUpsertRequest,
    TperTerCategorieTotals,
    TperTerLigneRead,
    TperTerResponse,
    TperTerSectionTotals,
    TperTerTotalsResponse,
    TypeTableau,
)
from piilot_pack_compta_esms.repositories import tper_ter_repo
from piilot_pack_compta_esms.services import document_freeze, document_scope, reference_lookup
from piilot_pack_compta_esms.services.errors import NotFoundError

logger = logging.getLogger(__name__)

_ZERO = Decimal("0")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _require_document(document_id: UUID, company_id: UUID) -> None:
    owns = await run_in_thread(tper_ter_repo.document_belongs_to_company, document_id, company_id)
    if not owns:
        raise NotFoundError(
            f"document {document_id} not found for this company",
            code="document_not_found",
        )


async def _resolve_type_etablissement(etablissement_id: UUID, company_id: UUID) -> str:
    """Q9 — lookup ETS.typologie, map via reference_lookup. 404 si
    ETS inconnu pour cette company (defense in depth)."""
    ctx = await run_in_thread(tper_ter_repo.get_ets_typologie, etablissement_id, company_id)
    if ctx is None:
        raise NotFoundError(
            f"etablissement {etablissement_id} not found for this company",
            code="etablissement_not_found",
        )
    return reference_lookup.deduce_type_etablissement(ctx.get("typologie"))


def _safe_decimal(value) -> Decimal:  # noqa: ANN001
    if value is None:
        return _ZERO
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


async def _warn_unknown_cnsa(categorie: str, fonction: str | None) -> None:
    """Q2 — fail-open lookup PLT-44. Log warning si KB ref non sync
    mais ne bloque pas (cohérent §H.4 compte_m22bis_exists)."""
    if not await reference_lookup.cnsa_categorie_exists(categorie):
        logger.info(
            "tper_ter: cnsa categorie '%s' unknown in PLT-44 KB ref " "(fail-open, accepted)",
            categorie,
        )
    if fonction and not await reference_lookup.cnsa_fonction_exists(fonction):
        logger.info(
            "tper_ter: cnsa fonction '%s' unknown in PLT-44 KB ref " "(fail-open, accepted)",
            fonction,
        )


# ---------------------------------------------------------------------------
# §11.1 — list_tper_ter
# ---------------------------------------------------------------------------


async def list_tper_ter(
    document_id: UUID,
    company_id: UUID,
    ets_id: UUID | None = None,
    type_tableau: TypeTableau | None = None,
) -> TperTerResponse:
    """Liste avec filtres optionnels ets_id + type_tableau."""
    await _require_document(document_id, company_id)
    rows = await run_in_thread(tper_ter_repo.list_by_filter, document_id, ets_id, type_tableau)
    return TperTerResponse(
        ets_id_filtre=ets_id,
        type_tableau_filtre=type_tableau,
        items=[TperTerLigneRead.model_validate(r) for r in rows],
    )


# ---------------------------------------------------------------------------
# §11.2 — bulk_upsert_tper_ter (replace_by_doc_ets_type Q3)
# ---------------------------------------------------------------------------


async def bulk_upsert_tper_ter(
    document_id: UUID,
    company_id: UUID,
    payload: TperTerBulkUpsertRequest,
) -> TperTerResponse:
    """Replace by (doc, ets, type_tableau) — atomique (Q3).

    Auto-déduit type_etablissement via ets.typologie (Q9). Valide les
    catégories CNSA via PLT-44 (fail-open Q2).

    Freeze §S : 409 si document hors brouillon."""
    await document_freeze.require_brouillon(document_id, company_id)
    await document_scope.assert_not_eps_only_doc(document_id)
    await _require_document(document_id, company_id)
    type_etablissement = await _resolve_type_etablissement(payload.ets_id, company_id)
    # Fail-open lookup CNSA pour chaque item (Q2)
    for item in payload.items:
        await _warn_unknown_cnsa(item.categorie_cnsa, item.fonction)

    items_dict = [item.model_dump(mode="json") for item in payload.items]
    await run_in_thread(
        tper_ter_repo.replace_by_doc_ets_type,
        company_id=company_id,
        document_id=document_id,
        etablissement_id=payload.ets_id,
        type_tableau=payload.type_tableau,
        type_etablissement=type_etablissement,
        items=items_dict,
    )
    return await list_tper_ter(
        document_id,
        company_id,
        ets_id=payload.ets_id,
        type_tableau=payload.type_tableau,
    )


# ---------------------------------------------------------------------------
# §11.4 — compute_totals (by_categorie + by_section + general)
# ---------------------------------------------------------------------------


async def compute_totals(document_id: UUID, company_id: UUID) -> TperTerTotalsResponse:
    """L2 §11.4 — Totaux par catégorie + section.

    ``by_categorie`` somme brute (toutes lignes de la catégorie).
    ``by_section`` pondère par ``pct_section`` (ventilation partielle).
    ``total_general`` agrège tout le document (Σ catégorie)."""
    await _require_document(document_id, company_id)
    by_cat_rows = await run_in_thread(tper_ter_repo.totals_by_categorie, document_id)
    by_sec_rows = await run_in_thread(tper_ter_repo.totals_by_section, document_id)

    by_categorie: list[TperTerCategorieTotals] = []
    sum_etpr_prev = _ZERO
    sum_etpt_prev = _ZERO
    sum_etpr_real = _ZERO
    sum_etpt_real = _ZERO
    sum_rem_prev = _ZERO
    sum_rem_real = _ZERO
    for row in by_cat_rows:
        etpr_p = _safe_decimal(row.get("etpr_prevus"))
        etpt_p = _safe_decimal(row.get("etpt_prevus"))
        etpr_r = _safe_decimal(row.get("etpr_realises"))
        etpt_r = _safe_decimal(row.get("etpt_realises"))
        rem_p = _safe_decimal(row.get("remunerations_prevues"))
        rem_r = _safe_decimal(row.get("remunerations_realisees"))
        sum_etpr_prev += etpr_p
        sum_etpt_prev += etpt_p
        sum_etpr_real += etpr_r
        sum_etpt_real += etpt_r
        sum_rem_prev += rem_p
        sum_rem_real += rem_r
        by_categorie.append(
            TperTerCategorieTotals(
                categorie_cnsa=row["categorie_cnsa"],
                etpr_prevus=etpr_p,
                etpt_prevus=etpt_p,
                etpr_realises=etpr_r,
                etpt_realises=etpt_r,
                remunerations_prevues=rem_p,
                remunerations_realisees=rem_r,
            )
        )

    by_section: list[TperTerSectionTotals] = []
    for row in by_sec_rows:
        by_section.append(
            TperTerSectionTotals(
                section_imputation=row["section_imputation"],  # type: ignore[arg-type]
                etpr_prevus_ventile=_safe_decimal(row.get("etpr_prevus_ventile")),
                etpr_realises_ventile=_safe_decimal(row.get("etpr_realises_ventile")),
                remunerations_prevues_ventilees=_safe_decimal(
                    row.get("remunerations_prevues_ventilees")
                ),
                remunerations_realisees_ventilees=_safe_decimal(
                    row.get("remunerations_realisees_ventilees")
                ),
            )
        )

    return TperTerTotalsResponse(
        by_categorie=by_categorie,
        by_section=by_section,
        total_etpr_prevus=sum_etpr_prev,
        total_etpt_prevus=sum_etpt_prev,
        total_etpr_realises=sum_etpr_real,
        total_etpt_realises=sum_etpt_real,
        total_remunerations_prevues=sum_rem_prev,
        total_remunerations_realisees=sum_rem_real,
    )


__all__ = [
    "list_tper_ter",
    "bulk_upsert_tper_ter",
    "compute_totals",
]
