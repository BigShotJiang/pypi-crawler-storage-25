"""Service ventilation H/D/S/SEA (§Y, D-055 + D-083 + D-085 + D-109).

Orchestre les 2 sources de répartition disponibles pour une charge :

1. **Règles dures D-055** (compte 65→H 100%, 66→S 100%, etc.) —
   service pur :mod:`ventilation_rules`.
2. **Clés gestionnaire D-057** stockées par établissement dans
   ``compta_esms.cles_repartition_charges_communes``.

Le service expose 3 entrées :

* :func:`apply_default_ventilation` — calcule la ventilation d'**un**
  compte pour un (ETS, exercice, type_ventilation). Pour un seul appel,
  appelé typiquement depuis ``crp_ligne_service.create_one``.

* :func:`batch_apply_default_ventilation` — variante optimisée pour le
  bulk-upsert §H : 1 batch lookup de toutes les clés en début de
  traitement, puis résolution en mémoire. **À utiliser dans une boucle
  d'upsert pour éviter le N+1**.

* :func:`validate_explicit_ventilation` — quand le cabinet pose
  explicitement H/D/S/SEA sur la ligne, vérifier Σ = montant_basis ±
  0.01€ + SEA seulement si forfait_global_unique.

D-083 — ventilation_type ∈ {simple, ternaire_hds, ternaire_hdsea}.
D-085 — ``ternaire_hdsea`` (SEA expérimentation 2026) n'est accepté
que pour les EHPAD ``forfait_global_unique=true``.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Literal
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.repositories import cles_repartition_repo
from piilot_pack_compta_esms.services import ventilation_rules
from piilot_pack_compta_esms.services.errors import ValidationError

logger = logging.getLogger(__name__)

VentilationType = Literal["simple", "ternaire_hds", "ternaire_hdsea"]
"""Aligné sur ``cr.ventilation`` DDL (003 §D.2)."""

_TERNAIRE_TYPES: frozenset[str] = frozenset({"ternaire_hds", "ternaire_hdsea"})
_TOLERANCE = Decimal("0.01")
_ZERO = Decimal("0")


# ---------------------------------------------------------------------------
# Helper — distribution percentage → section dict
# ---------------------------------------------------------------------------


def _distribute_by_taux(
    montant_total: Decimal,
    taux: dict[str, Decimal],
) -> dict[str, Decimal]:
    """Distribue ``montant_total`` selon les taux donnés ({h, d, s, sea}).

    Arrondi à 2 décimales par section, avec correction du résiduel sur
    la section la plus grosse pour garantir Σ = ``montant_total`` exact
    (évite la dérive de centimes sur les divisions).
    """
    sections = ("hebergement", "dependance", "soins", "soins_autonomie")
    result: dict[str, Decimal] = {}
    cumul = Decimal("0")
    biggest_section = sections[0]
    biggest_value = Decimal("0")
    for section in sections:
        taux_field = f"taux_{section}"
        pct = taux.get(taux_field, Decimal("0"))
        value = (montant_total * pct / Decimal("100")).quantize(Decimal("0.01"))
        result[section] = value
        cumul += value
        if pct > biggest_value:
            biggest_value = pct
            biggest_section = section

    # Correction résiduel sur la section la plus grosse.
    residue = montant_total - cumul
    if residue != Decimal("0"):
        result[biggest_section] += residue
    return result


# ---------------------------------------------------------------------------
# apply_default_ventilation — single compte
# ---------------------------------------------------------------------------


async def apply_default_ventilation(
    *,
    compte_m22bis: str,
    montant_total: Decimal,
    etablissement_id: UUID,
    exercice_annee: int,
    ventilation_type: VentilationType,
) -> dict[str, Decimal] | None:
    """Retourne ``{hebergement, dependance, soins, soins_autonomie}``
    ou ``None`` si aucune règle ne s'applique.

    Algorithme §Y :

    1. ``ventilation_type='simple'`` → return None (pas de ventilation).
    2. Match règle dure D-055 (:func:`ventilation_rules.resolve_section_dure`)
       → 100% dans la section identifiée, 0 ailleurs.
    3. Sinon lookup clé gestionnaire (ETS, compte, annee) → appliquer
       les taux × montant_total.
    4. Sinon return None (saisie manuelle attendue).

    Le caller (``crp_ligne_service``) reçoit None → laisse les 4 cols
    H/D/S/SEA à NULL dans le payload final.
    """
    if ventilation_type not in _TERNAIRE_TYPES:
        return None

    # 1. Règle dure D-055
    section_dure = ventilation_rules.resolve_section_dure(compte_m22bis)
    if section_dure is not None:
        return {
            "hebergement": montant_total if section_dure == "hebergement" else _ZERO,
            "dependance": montant_total if section_dure == "dependance" else _ZERO,
            "soins": montant_total if section_dure == "soins" else _ZERO,
            "soins_autonomie": (montant_total if section_dure == "soins_autonomie" else _ZERO),
        }

    # 2. Clé gestionnaire D-057
    keys = await run_in_thread(
        cles_repartition_repo.batch_lookup,
        etablissement_id,
        exercice_annee,
        [compte_m22bis],
    )
    if compte_m22bis in keys:
        return _distribute_by_taux(montant_total, keys[compte_m22bis])

    # 3. Saisie manuelle
    return None


# ---------------------------------------------------------------------------
# batch_apply_default_ventilation — bulk-upsert §H optimisé
# ---------------------------------------------------------------------------


async def batch_apply_default_ventilation(
    *,
    items: list[dict],
    etablissement_id: UUID,
    exercice_annee: int,
    ventilation_type: VentilationType,
) -> list[dict[str, Decimal] | None]:
    """Variante batch — 1 round-trip pour toutes les clés.

    Pour chaque ``item`` du payload bulk-upsert, retourne le dict de
    ventilation calculé ou None. La position est préservée — l'appelant
    fait ``items[i]["montant_hebergement"] = result[i]["hebergement"]``
    etc. si non-None.

    ``items`` doit contenir au minimum ``compte_m22bis`` et un montant
    de basis. Le caller passe le ``montant_basis`` déjà résolu (helper
    :func:`extract_basis_amount`) pour rester découplé.
    """
    if ventilation_type not in _TERNAIRE_TYPES:
        return [None] * len(items)

    # Collecte des comptes "non-règle-dure" qui auront besoin d'un
    # lookup de clé. Pas la peine de charger la clé d'un compte 65
    # ou 66 — la règle dure s'applique.
    comptes_a_lookup: set[str] = set()
    for item in items:
        compte = item.get("compte_m22bis")
        if compte is None:
            continue
        if ventilation_rules.resolve_section_dure(compte) is None:
            comptes_a_lookup.add(compte)

    keys = (
        await run_in_thread(
            cles_repartition_repo.batch_lookup,
            etablissement_id,
            exercice_annee,
            list(comptes_a_lookup),
        )
        if comptes_a_lookup
        else {}
    )

    result: list[dict[str, Decimal] | None] = []
    for item in items:
        compte = item.get("compte_m22bis")
        montant = item.get("montant_basis")
        if not compte or montant is None:
            result.append(None)
            continue

        # 1. Règle dure
        section_dure = ventilation_rules.resolve_section_dure(compte)
        if section_dure is not None:
            result.append(
                {
                    "hebergement": montant if section_dure == "hebergement" else _ZERO,
                    "dependance": montant if section_dure == "dependance" else _ZERO,
                    "soins": montant if section_dure == "soins" else _ZERO,
                    "soins_autonomie": (montant if section_dure == "soins_autonomie" else _ZERO),
                }
            )
            continue

        # 2. Clé gestionnaire
        if compte in keys:
            result.append(_distribute_by_taux(montant, keys[compte]))
            continue

        # 3. Saisie manuelle
        result.append(None)

    return result


# ---------------------------------------------------------------------------
# validate_explicit_ventilation — saisie utilisateur
# ---------------------------------------------------------------------------


async def validate_explicit_ventilation(
    *,
    montant_basis: Decimal | None,
    montant_hebergement: Decimal | None,
    montant_dependance: Decimal | None,
    montant_soins: Decimal | None,
    montant_soins_autonomie: Decimal | None,
    ventilation_type: VentilationType,
    etablissement_id: UUID | None,
) -> None:
    """Valide la cohérence d'une saisie explicite H/D/S/SEA.

    Règles :

    * ``ventilation_type='simple'`` → aucune des 4 cols ne doit être
      renseignée (422 ``ventilation_forbidden_for_simple``).
    * SEA renseigné mais ``etablissement.forfait_global_unique=false``
      ou ``ventilation_type!='ternaire_hdsea'`` → 422
      ``sea_requires_forfait_global_unique``.
    * Σ(h+d+s[+sea]) = montant_basis ± 0.01€ → sinon 422
      ``ventilation_sum_mismatch``. Tolérance par défaut 0.01.

    Appelée depuis ``crp_ligne_service.create_one`` / ``upsert_one``
    après l'auto-ventilation (qui pose les valeurs si elles étaient
    None) — donc on valide systématiquement, même les valeurs auto.
    """
    any_provided = any(
        v is not None
        for v in (
            montant_hebergement,
            montant_dependance,
            montant_soins,
            montant_soins_autonomie,
        )
    )

    # ventilation_type='simple' interdit la saisie H/D/S/SEA.
    if ventilation_type == "simple":
        if any_provided:
            raise ValidationError(
                "Le CR a ventilation='simple' — les colonnes "
                "montant_hebergement / _dependance / _soins / "
                "_soins_autonomie ne peuvent pas être renseignées. "
                "Changez la ventilation du CR avant de poser ces "
                "valeurs.",
                code="ventilation_forbidden_for_simple",
            )
        return

    # SEA → conditional
    sea = montant_soins_autonomie
    if sea is not None and sea > _ZERO:
        if ventilation_type != "ternaire_hdsea":
            raise ValidationError(
                f"montant_soins_autonomie nécessite ventilation="
                f"'ternaire_hdsea' (got '{ventilation_type}'). D-085 "
                f"SEA est une expérimentation 2026 limitée aux EHPAD "
                f"forfait global unique.",
                code="sea_requires_ternaire_hdsea",
            )
        if etablissement_id is not None:
            forfait = await run_in_thread(
                cles_repartition_repo.get_etablissement_forfait_flag,
                etablissement_id,
            )
            if forfait is False:
                raise ValidationError(
                    "L'établissement n'est pas en forfait global "
                    "unique (D-085). SEA non autorisé.",
                    code="sea_requires_forfait_global_unique",
                )

    # Σ vérification — uniquement si au moins une col est posée et le
    # montant_basis existe. Si aucune col n'est posée mais que
    # ventilation_type est ternaire_*, on ne bloque pas — c'est juste
    # qu'on n'a pas pu auto-ventiler (compte sans règle ni clé) et le
    # cabinet n'a pas encore saisi.
    if not any_provided or montant_basis is None:
        return

    h = montant_hebergement or _ZERO
    d = montant_dependance or _ZERO
    s = montant_soins or _ZERO
    sea_val = montant_soins_autonomie or _ZERO

    total_ventile = h + d + s + sea_val
    if abs(total_ventile - montant_basis) > _TOLERANCE:
        raise ValidationError(
            f"La somme des montants ventilés ({total_ventile}) ne "
            f"correspond pas au montant total ({montant_basis}, "
            f"écart={abs(total_ventile - montant_basis)}). "
            f"Tolérance 0.01€.",
            code="ventilation_sum_mismatch",
        )


# ---------------------------------------------------------------------------
# extract_basis_amount — helper public
# ---------------------------------------------------------------------------


def extract_basis_amount(ligne: dict) -> Decimal | None:
    """Retourne le montant "basis" pour la ventilation d'une ligne :

    * ERRD/réalisé → ``montant_realise``
    * EPRD/prévisionnel → ``montant_previsions_totales``
    * Fallback → ``montant_budget_initial`` (rare)

    Retourne le premier non-None dans cet ordre. ``None`` si aucun
    montant n'est encore saisi (ligne squelette).
    """
    for field in ("montant_realise", "montant_previsions_totales", "montant_budget_initial"):
        value = ligne.get(field)
        if value is not None:
            return Decimal(str(value))
    return None
