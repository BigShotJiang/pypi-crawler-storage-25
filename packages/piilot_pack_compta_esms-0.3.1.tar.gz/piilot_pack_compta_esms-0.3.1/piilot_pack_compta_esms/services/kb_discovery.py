"""Discovery + aggregation primitives for D-103 bindings (L2 §7).

Since SDK v0.8.0 the heavy lifting (KB candidate listing + group-by
aggregation) lives in ``piilot.sdk.knowledge.find_kbs`` /
``piilot.sdk.knowledge.aggregate``. This module is a thin adapter
that :

* Translates the plugin's :class:`CandidateKb` / :class:`ColumnCompatWarning`
  dataclasses to / from the SDK's dict shape ;
* Keeps the in-plugin ``fetch_kb_meta`` helper (used by
  :mod:`binding_service` to grab ``columns`` + ``table_name`` before
  validating a binding create payload — no direct SDK equivalent
  since we don't want to depend on the company being the active
  RLS tenant just for a metadata lookup) ;
* Keeps ``check_compat`` (the matching rule between a feature
  contract and a KB's columns is plugin-specific — the SDK exposes
  a similar permissive matching internally but doesn't return the
  warning shape we surface in the UI).

Pre-0.8 history : this module shipped a ~120-LOC SQL builder for
listing candidates + a ~80-LOC SQL builder for the group-by
aggregation. Both have moved upstream. The plugin's tests pivot to
mocking ``sdk.knowledge.find_kbs`` / ``sdk.knowledge.aggregate``
instead of the deleted internal helpers.

Why permissive type matching (Q3.b)
-----------------------------------

The contract says ``{"compte": "text"}``. A cabinet that imported a
balance CSV might end up with ``compte`` typed ``numeric`` (account
codes that look like numbers). PG casts on read; refusing the KB
hard-locks the cabinet out for cosmetic reasons. So this module
**accepts** the mismatch and emits a :class:`ColumnCompatWarning` —
the UI surfaces a ⚠ badge but the binding still works.

The opposite case (contract says ``numeric``, KB has ``text``) is
also accepted with a warning : the aggregation SELECT casts
``::numeric`` explicitly (SDK side) so SUM works. PG raises at query
time if a value isn't parseable — that's a row-level concern, not a
binding-level concern.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from piilot.sdk import knowledge as sdk_knowledge
from piilot.sdk.db import cursor, run_in_thread

from piilot_pack_compta_esms.models.kb_binding import (
    CandidateKb,
    ColumnCompatWarning,
)

logger = logging.getLogger(__name__)


# Map the contract's logical types → the kb_columns.column_type set.
# Keys are how the feature_catalog seeds describe the type, values are
# the values produced by core ``kb_table_builder``.
_CONTRACT_TYPE_TO_KB_TYPE: dict[str, set[str]] = {
    "text": {"text"},
    "numeric": {"numeric"},
    "integer": {"numeric"},
    "date": {"date"},
}


# ---------------------------------------------------------------------------
# Catalog reads (knowledge_bases + kb_columns) — kept in-plugin because
# no SDK equivalent exposes the full meta in one call.
# ---------------------------------------------------------------------------


def _fetch_kb_meta_sync(kb_id: UUID, company_id: UUID) -> dict[str, Any] | None:
    """Return ``{id, name, table_name, scope, owner_type, owner_ref,
    columns: [{name, column_type, pg_column, pg_type}]}`` for a KB that
    belongs to the caller's company (or is a reference KB).

    Returns None when the KB id doesn't exist, doesn't belong to the
    company (or isn't a reference KB), or has no materialised table
    yet (legacy v1 KBs).
    """
    with cursor() as cur:
        cur.execute(
            "SELECT id, name, table_name, scope, owner_type, owner_ref "
            "FROM public.knowledge_bases "
            "WHERE id = %s "
            "  AND table_name IS NOT NULL "
            "  AND (scope = 'reference' OR organization_id = %s)",
            (str(kb_id), str(company_id)),
        )
        kb_row = cur.fetchone()
        if kb_row is None:
            return None

        cur.execute(
            "SELECT name, column_type, pg_column, pg_type, position "
            "FROM public.kb_columns "
            "WHERE kb_id = %s "
            "ORDER BY position, name",
            (str(kb_id),),
        )
        columns = cur.fetchall()
        return {
            "id": kb_row["id"],
            "name": kb_row["name"],
            "table_name": kb_row["table_name"],
            "scope": kb_row["scope"],
            "owner_type": kb_row["owner_type"],
            "owner_ref": kb_row["owner_ref"],
            "columns": columns,
        }


async def fetch_kb_meta(kb_id: UUID, company_id: UUID) -> dict[str, Any] | None:
    """Async wrapper around :func:`_fetch_kb_meta_sync`."""
    return await run_in_thread(_fetch_kb_meta_sync, kb_id, company_id)


# ---------------------------------------------------------------------------
# Contract compatibility (permissive)
# ---------------------------------------------------------------------------


def check_compat(
    columns_required: dict[str, str],
    kb_columns: list[dict[str, Any]],
    column_mapping: dict[str, str] | None = None,
) -> tuple[bool, list[ColumnCompatWarning]]:
    """Check a KB's columns against a feature contract — permissive (Q3.b).

    Returns ``(compatible, warnings)``. ``compatible`` is True iff
    every contract column resolves to a KB column **by name** (after
    applying ``column_mapping``). Type mismatches don't break
    compatibility, they only emit warnings.

    Resolution rule, for each (contract_col, contract_type) :

    1. Look up the KB column name via ``column_mapping.get(contract_col,
       contract_col)``.
    2. Find that column in the KB's ``kb_columns`` (by ``name``).
    3. If missing → not compatible (no warning, hard reject).
    4. If type doesn't match → emit warning, stay compatible.
    """
    mapping = column_mapping or {}
    by_name = {c["name"]: c for c in kb_columns}
    warnings: list[ColumnCompatWarning] = []

    for contract_col, contract_type in columns_required.items():
        kb_col_name = mapping.get(contract_col, contract_col)
        kb_col = by_name.get(kb_col_name)
        if kb_col is None:
            return False, []
        expected = _CONTRACT_TYPE_TO_KB_TYPE.get(contract_type, {contract_type})
        actual = kb_col["column_type"]
        if actual not in expected:
            warnings.append(
                ColumnCompatWarning(
                    contract_column=contract_col,
                    kb_column=kb_col_name,
                    expected_type=contract_type,
                    actual_type=actual,
                )
            )
    return True, warnings


# ---------------------------------------------------------------------------
# Candidate KB discovery (delegates to SDK ``find_kbs`` since 0.8)
# ---------------------------------------------------------------------------


async def list_candidate_kbs(
    *,
    company_id: UUID,
    columns_required: dict[str, str],
) -> list[CandidateKb]:
    """Return the company-scoped + reference KBs compatible with a
    feature contract. Permissive type matching — see module docstring.

    Since SDK 0.8.0 the SQL lives in :func:`piilot.sdk.knowledge.find_kbs` ;
    this wrapper only adapts the SDK's dict shape to the plugin's
    :class:`CandidateKb` dataclass + re-injects the contract metadata
    into the warnings (the SDK doesn't know the original logical type
    keys, it only sees the comparator result).
    """
    raw = await run_in_thread(
        sdk_knowledge.find_kbs,
        company_id=str(company_id),
        columns_required=columns_required,
        scope="all",
    )
    out: list[CandidateKb] = []
    for kb in raw:
        warnings = [
            ColumnCompatWarning(
                contract_column=w["contract_column"],
                kb_column=w["kb_column"],
                expected_type=w["expected_type"],
                actual_type=w["actual_type"],
            )
            for w in kb.get("warnings", [])
        ]
        out.append(
            CandidateKb(
                kb_id=kb["kb_id"],
                name=kb["name"],
                kb_table=kb["kb_table"],
                row_count=kb["row_count"],
                owner_type=kb.get("owner_type"),
                owner_ref=kb.get("owner_ref"),
                columns=[{"name": c["name"], "type": c["type"]} for c in kb["columns"]],
                warnings=warnings,
            )
        )
    return out


# ---------------------------------------------------------------------------
# Aggregation preview (L2 §7.5 — delegates to SDK ``aggregate`` since 0.8)
# ---------------------------------------------------------------------------


_DEFAULT_PREVIEW_LIMIT = 200


async def aggregate_preview(
    *,
    kb_id: UUID | str,
    contract_to_kb_logical: dict[str, str],
    dimension_logical_cols: list[str],
    measure_logical_cols: list[str],
    filters: dict[str, Any] | None = None,
    limit: int = _DEFAULT_PREVIEW_LIMIT,
) -> list[dict[str, Any]]:
    """Aggregate a KB v2 table by GROUP BY dimensions + SUM measures.

    Since SDK 0.8.0 the SQL builder lives in
    :func:`piilot.sdk.knowledge.aggregate` (with full GROUP BY + SUM
    / COUNT / AVG + HAVING support). This wrapper :

    1. Translates the contract column names to the KB's own logical
       column names (via ``contract_to_kb_logical``) before invoking
       the SDK ;
    2. Re-keys the SDK output dicts from KB logical names back to the
       contract names so the frontend stays in contract-space.

    Used by ``POST .../bindings/{feature_key}:preview`` to show the
    cabinet what the binding will pre-fill into ``crp_lignes`` without
    persisting anything. ``filters`` is an equality filter applied as
    a WHERE clause, ANDed across keys. ``filters`` keys reference the
    contract column names (translated to KB names inside).
    """
    # Translate contract → KB logical for dimensions, measures, filters
    dims_kb = [contract_to_kb_logical[c] for c in dimension_logical_cols]
    measures_kb = [(contract_to_kb_logical[c], "SUM") for c in measure_logical_cols]
    filters_kb: dict[str, Any] = {}
    for contract_col, value in (filters or {}).items():
        kb_logical = contract_to_kb_logical.get(contract_col)
        if kb_logical is None:
            # Filter on a column not in the contract — ignore silently
            # (kept to keep preview tolerant of UI-side state drift).
            continue
        filters_kb[kb_logical] = value

    rows = await run_in_thread(
        sdk_knowledge.aggregate,
        kb_id=str(kb_id),
        dimensions=dims_kb,
        measures=measures_kb,
        filters=filters_kb,
        limit=limit,
    )

    # Re-key the output dicts from KB logical → contract names.
    kb_to_contract = {v: k for k, v in contract_to_kb_logical.items()}
    remapped: list[dict[str, Any]] = []
    for row in rows:
        out_row: dict[str, Any] = {}
        for kb_logical, value in row.items():
            contract_col = kb_to_contract.get(kb_logical, kb_logical)
            out_row[contract_col] = value
        remapped.append(out_row)
    return remapped
