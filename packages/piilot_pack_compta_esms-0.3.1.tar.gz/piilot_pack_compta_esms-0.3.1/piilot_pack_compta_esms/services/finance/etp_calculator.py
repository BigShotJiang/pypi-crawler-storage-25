"""Calculs ETP (F.ETP.01 → F.ETP.05).

Source : ``knowledge-base/07-formules-metier.md`` §16 + ``S20`` CDC TER.

Pure functions. Le caller (§Q TPER/TER) fournit les heures de paie /
heures travaillées / taux d'affectation par section, le service
renvoie les 5 indicateurs ETP normalisés.

Constantes paramétrables (cf. :class:`EtpConstantes` dans
:mod:`models.finance`) :

* ETP_par_defaut = 1 (modifiable manuellement par salarié, 0–1)
* Heures_mensuel_default = 151,67
* Heures_annuel_base = 1820 (F.ETP.01)
* Heures_annuel_base_global = 1820,04 (F.ETP.04 — variante "global"
  selon S20)
"""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.models.finance import (
    EtpGlobalInput,
    EtpGlobalResult,
    EtpImputationInput,
    EtpImputationResult,
    EtpProrataInput,
    EtpProrataResult,
)

_TWELVE = Decimal("12")
_HUNDRED = Decimal("100")
_TOLERANCE_SUM_TAUX = Decimal("0.001")
"""Tolérance d'arrondi sur Σ taux d'affectation par section = 100%."""


# ---------------------------------------------------------------------------
# F.ETP.01 + F.ETP.02 + F.ETP.03 — prorata rémunéré + travaillé
# ---------------------------------------------------------------------------


def compute_etp_prorata(payload: EtpProrataInput) -> EtpProrataResult:
    """Trois indicateurs depuis les heures de paie réelles :

    * F.ETP.01 — Nbre_mois_remun = (heures_reelles_paie / 1820) × 12
    * F.ETP.02 — ETP_prorata_remun = (ETP × Nbre_mois_remun) / 12
    * F.ETP.03 — ETP_prorata_trav = (ETP × Nbre_mois_travaille_saisi) / 12,
      renvoyé ``None`` quand ``nbre_mois_travaille_saisi`` est absent
      (le salarié n'a pas encore de saisie manuelle des mois
      travaillés ; F.ETP.03 reste un nice-to-have).
    """
    heures_annuel = payload.constantes.heures_annuel_base
    nbre_mois_remun = (payload.heures_reelles_paie / heures_annuel) * _TWELVE
    etp_prorata_remun = (payload.etp * nbre_mois_remun) / _TWELVE
    etp_prorata_trav: Decimal | None = None
    if payload.nbre_mois_travaille_saisi is not None:
        etp_prorata_trav = (payload.etp * payload.nbre_mois_travaille_saisi) / _TWELVE
    return EtpProrataResult(
        nbre_mois_remun=nbre_mois_remun,
        etp_prorata_remun=etp_prorata_remun,
        etp_prorata_trav=etp_prorata_trav,
    )


# ---------------------------------------------------------------------------
# F.ETP.04 — ETP global depuis heures travaillées
# ---------------------------------------------------------------------------


def compute_etp_global(payload: EtpGlobalInput) -> EtpGlobalResult:
    """ETP_global = heures_travaillees / 1820,04 (F.ETP.04, S20)."""
    return EtpGlobalResult(
        etp_global=payload.heures_travaillees / payload.constantes.heures_annuel_base_global
    )


# ---------------------------------------------------------------------------
# F.ETP.05 — Imputation par section
# ---------------------------------------------------------------------------


def compute_etp_imputation(
    payload: EtpImputationInput,
) -> EtpImputationResult:
    """Imputation d'un ETP_prorata_remun par section (H/D/S/SEA).

    Contrainte F.ETP.05 : Σ Taux_affectation = 100% par salarié,
    tolérance 0,001 (gérée par :data:`_TOLERANCE_SUM_TAUX`). Si la
    somme dévie, ``valide=False`` et l'imputation est calculée quand
    même — le caller décide s'il bloque la saisie ou affiche un
    warning.

    Les sections absentes du dict d'entrée ne sont pas imputées (taux
    0 implicite). ``taux_par_section`` est en pourcentage (0 à 100),
    pas en fraction (0,0 à 1,0).
    """
    sum_taux = sum(payload.taux_par_section.values(), Decimal("0"))
    valide = abs(sum_taux - _HUNDRED) <= _TOLERANCE_SUM_TAUX
    imputation = {
        section: payload.etp_prorata_remun * (taux / _HUNDRED)
        for section, taux in payload.taux_par_section.items()
    }
    return EtpImputationResult(
        imputation_par_section=imputation,
        sum_taux_pct=sum_taux,
        valide=valide,
    )
