"""Finance calculators (§I) — pure functions, no I/O.

Every public function takes a typed input dataclass and returns a
typed result dataclass (cf. :mod:`piilot_pack_compta_esms.models.finance`).
Callers in §K Bilan, §M TF, §P PGFP, §X workflow transitions are
responsible for collecting the inputs from the DB and acting on the
results.

Why §I is pure : the equilibrium validator + financial indicators + ETP
+ forfait dependance must be testable without a backend (and reusable
across documents that don't all exist yet — Bilan, TF, PGFP are
chantiers ultérieurs). Routing happens elsewhere.
"""

from __future__ import annotations
