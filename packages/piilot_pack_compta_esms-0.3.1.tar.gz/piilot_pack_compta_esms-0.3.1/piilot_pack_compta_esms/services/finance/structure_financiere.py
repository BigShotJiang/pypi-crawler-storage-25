"""FRNG + BFR + Trésorerie nette (F.IND.03, F.IND.04, F.IND.05).

Pure functions. Three indicators that chain together :

* FRNG = Ressources_durables − Emplois_durables (S01 §8)
* BFR  = (Créances + Stocks) − (Dettes_fournisseurs + Dettes_sociales) (S01 §9)
* Trésorerie nette = FRNG − BFR (S01 §10)

Décomposition FRI / FRE :

* FRI (Investissement) = (Fonds_propres + Subventions_invest + Provisions_invest
  + Dettes_LT) − Immobilisations_nettes
* FRE (Exploitation) = Ressources_FRE − Emplois_FRE (souvent 0 quand l'ESMS
  ne distingue pas les deux)
* FRNG = FRI + FRE

Seuils santé indicatifs (à confirmer en §AA Ratios) — pour l'instant
on rapporte ``sain`` / ``attention`` / ``alerte`` / ``critique`` sans
seuil monétaire absolu (le seuil dépend du chiffre d'affaires).
"""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.models.finance import (
    BfrInput,
    BfrResult,
    FrngInput,
    FrngResult,
    TresorerieInput,
    TresorerieResult,
)

_ZERO = Decimal("0")


# ---------------------------------------------------------------------------
# F.IND.03 — FRNG
# ---------------------------------------------------------------------------


def compute_frng(payload: FrngInput) -> FrngResult:
    """Fonds de Roulement Net Global = FRI + FRE.

    FRI = (Fonds_propres + Subv_invest + Prov_invest + Dettes_LT)
          − Immobilisations_nettes

    FRE = Ressources_FRE − Emplois_FRE
    """
    ressources_durables = (
        payload.fonds_propres
        + payload.subventions_invest
        + payload.provisions_invest
        + payload.dettes_long_terme
    )
    fri = ressources_durables - payload.immobilisations_nettes
    fre = payload.fre_ressources - payload.fre_emplois
    frng = fri + fre
    if frng >= _ZERO:
        sante = "sain"
    elif frng > -ressources_durables * Decimal("0.05"):
        # Slight deficit (< 5% of resources) — attention
        sante = "attention"
    elif frng > -ressources_durables * Decimal("0.20"):
        sante = "alerte"
    else:
        sante = "critique"
    return FrngResult(fri=fri, fre=fre, frng=frng, sante=sante)


# ---------------------------------------------------------------------------
# F.IND.04 — BFR
# ---------------------------------------------------------------------------


def compute_bfr(payload: BfrInput) -> BfrResult:
    """Besoin en Fonds de Roulement.

    BFR négatif = exploitation autofinance la structure (sain).
    BFR positif et croissant = signal d'alerte (S01 §9).

    Le seuil "croissant" exigerait deux exercices comparés ; v0.2 ne
    fait que le verdict statique sur BFR :
    * BFR <= 0       → sain
    * 0 < BFR <= 30j de trésorerie typique → attention (placeholder)
    * autre → alerte / critique selon ampleur (à raffiner §AA)
    """
    bfr = (payload.creances_clients + payload.stocks) - (
        payload.dettes_fournisseurs + payload.dettes_sociales
    )
    if bfr <= _ZERO:
        sante = "sain"
    elif bfr < (payload.creances_clients + payload.stocks) * Decimal("0.10"):
        sante = "attention"
    else:
        sante = "alerte"
    return BfrResult(bfr=bfr, sante=sante)


# ---------------------------------------------------------------------------
# F.IND.05 — Trésorerie nette
# ---------------------------------------------------------------------------


def compute_tresorerie(payload: TresorerieInput) -> TresorerieResult:
    """Trésorerie nette = FRNG − BFR (S01 §10).

    Indicateur clé de la solvabilité court-terme. Positive et stable =
    saine. Négative = l'établissement finance ses besoins par dette
    court terme.
    """
    tresorerie = payload.frng - payload.bfr
    if tresorerie > _ZERO:
        sante = "sain"
    elif tresorerie == _ZERO:
        sante = "attention"
    elif tresorerie > -abs(payload.bfr) * Decimal("0.20"):
        sante = "alerte"
    else:
        sante = "critique"
    return TresorerieResult(tresorerie=tresorerie, sante=sante)
