"""CAF + marge brute calculators (F.IND.01, F.IND.02).

Pure functions. The caller fournit les composantes — pas de relecture
de :mod:`crp_lignes` ici. Le résultat porte l'indicateur de santé
(``sain`` / ``attention`` / ``alerte`` / ``critique``) selon les
seuils DGCS.
"""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.models.finance import (
    CafInput,
    CafResult,
    MargeBruteInput,
    MargeBruteResult,
)

_ZERO = Decimal("0")
_CAF_IAF_RATIO_SAIN = Decimal("1.2")
"""S01 §7 — couverture systématique CAF / IAF >= 1,2."""

_MARGE_BRUTE_SEUIL_ALERTE_PCT = Decimal("2")
"""S01 trame VF vKAS — marge brute < 2% = situation tendue."""


# ---------------------------------------------------------------------------
# F.IND.02 — CAF
# ---------------------------------------------------------------------------


def compute_caf(payload: CafInput) -> CafResult:
    """Compute the simplified EPRD CAF (S01, S02 / §7).

    Formule : ``CAF = Résultat + Amortissements + Dotations_prov
    − Reprises_prov − Reprises_subv ± autres_non_décaissables``.

    Le ratio CAF / IAF est retourné quand ``capital_a_rembourser_n``
    est fourni — sert au verdict santé :

    * **sain** : CAF/IAF >= 1,2
    * **attention** : 1,0 <= CAF/IAF < 1,2 (couverture juste)
    * **alerte** : 0 <= CAF/IAF < 1,0
    * **critique** : CAF < 0 (autofinancement négatif)
    """
    caf = (
        payload.resultat_net
        + payload.dotations_amortissements
        + payload.dotations_provisions
        - payload.reprises_provisions
        - payload.reprises_subventions
        + payload.autres_non_decaissables
    )
    ratio: Decimal | None = None
    if payload.capital_a_rembourser_n is not None and payload.capital_a_rembourser_n != _ZERO:
        ratio = caf / payload.capital_a_rembourser_n

    if caf < _ZERO:
        sante = "critique"
    elif ratio is None:
        # CAF positive but no IAF reference — at minimum "sain" by default.
        sante = "sain"
    elif ratio >= _CAF_IAF_RATIO_SAIN:
        sante = "sain"
    elif ratio >= Decimal("1"):
        sante = "attention"
    else:
        sante = "alerte"

    return CafResult(caf=caf, ratio_caf_iaf=ratio, sante=sante)


# ---------------------------------------------------------------------------
# F.IND.01 — Marge brute
# ---------------------------------------------------------------------------


def compute_marge_brute(payload: MargeBruteInput) -> MargeBruteResult:
    """Marge brute = (Résultat / Total_produits) × 100.

    Seuil vigilance < 2% (S01 trame VF vKAS).

    Quand ``total_produits == 0`` on retourne 0% + ``critique`` (un
    établissement sans produit n'a pas de marge mesurable — situation
    extrême)."""
    if payload.total_produits == _ZERO:
        return MargeBruteResult(marge_brute_pct=_ZERO, sante="critique")
    pct = (payload.resultat_net / payload.total_produits) * Decimal("100")
    if pct < _ZERO:
        sante = "critique"
    elif pct < _MARGE_BRUTE_SEUIL_ALERTE_PCT:
        sante = "alerte"
    elif pct < Decimal("5"):
        sante = "attention"
    else:
        sante = "sain"
    return MargeBruteResult(marge_brute_pct=pct, sante=sante)
