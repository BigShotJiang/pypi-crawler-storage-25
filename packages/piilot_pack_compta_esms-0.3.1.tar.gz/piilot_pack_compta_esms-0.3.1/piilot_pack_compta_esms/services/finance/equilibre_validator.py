"""Équilibre validators (F.EQ.01 — réel, F.EQ.02 — strict).

Pure functions. No DB, no async. The caller is responsible for :

* loading the inputs (from ``crp_lignes`` §H, ``tf_lignes`` §M, the
  CAF result of §I.4, ``emprunts_dettes`` §N, ``affectations_resultats``
  §J),
* deciding which validator to call (see :func:`choose_equilibre_type`
  for the D-016 rule),
* persisting the verdict (typically on the document workflow transition
  ``BROUILLON → TRANSMIS`` per D-034).

5 conditions équilibre réel (R.314-222) — cf.
``knowledge-base/07-formules-metier.md`` §4 et `S03` p.29 :

1. Produits tarifs saisis = produits tarifs notifiés.
2. Sincérité (qualitatif — vérification cabinet, surface comme True/False).
3. Remboursement capital N **non couvert** par produit emprunts.
4. CAF suffisante pour le capital à rembourser N.
5. Recettes affectées employées à l'usage prévu.

Each condition emits a :class:`ConditionResult` carrying ``passed`` /
``evaluable`` / human-readable message. The global verdict
(:func:`validate_equilibre_reel`) is ``equilibre=true`` only when
every condition is both evaluable AND passed.
"""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.models.finance import (
    ConditionResult,
    EquilibreReelInput,
    EquilibreReelResult,
    EquilibreStrictInput,
    EquilibreStrictResult,
    EquilibreType,
    NatureJuridique,
)

_ZERO = Decimal("0")
_STRICT_TOLERANCE = Decimal("0.01")
"""S03 p.29 — équilibre strict tolérance arrondi : 0.01 €."""


# ---------------------------------------------------------------------------
# Choix entre équilibre réel et strict (D-016)
# ---------------------------------------------------------------------------


def choose_equilibre_type(
    *,
    nature_juridique: NatureJuridique,
    inclus_dans_cpom: bool,
) -> EquilibreType:
    """Pick the applicable équilibre flavor (D-016).

    Règle DGCS S03 p.29 (R.314-222 + R.314-225) :

    * ESMS inclus dans CPOM (toutes natures) → équilibre **réel**
      (5 conditions, plus de souplesse, l'autorité tarifaire négocie).
    * ESMS hors CPOM → équilibre **strict** (recettes == dépenses).
    * Le type ``financier`` (R.314-225) est livré ici pour la
      complétude mais le validator correspondant vit en §K (Bilan)
      car il croise actif/passif. Non calculable depuis §I seul.
    """
    if inclus_dans_cpom:
        return "reel"
    _ = nature_juridique  # documented but not yet used — kept for future rules
    return "strict"


# ---------------------------------------------------------------------------
# F.EQ.01 — Équilibre réel R.314-222 (5 conditions)
# ---------------------------------------------------------------------------


def _condition_1_produits_tarifs(payload: EquilibreReelInput) -> ConditionResult:
    """Produits tarif saisis == produits tarif notifiés.

    Both values must be supplied — partial input → not evaluable.
    """
    if payload.produits_tarif_saisis is None or payload.produits_tarif_notifies is None:
        return ConditionResult(
            id=1,
            label="Produits tarif = notifiés",
            passed=False,
            evaluable=False,
            message="Produits tarifs saisis ou notifiés non fournis",
        )
    diff = payload.produits_tarif_saisis - payload.produits_tarif_notifies
    passed = diff == _ZERO
    return ConditionResult(
        id=1,
        label="Produits tarif = notifiés",
        passed=passed,
        evaluable=True,
        message=("Conforme" if passed else f"Écart {diff:.2f}€ entre saisis et notifiés"),
    )


def _condition_2_sincerite(payload: EquilibreReelInput) -> ConditionResult:
    """Sincérité — qualitatif. ``sincerite_commentee=True`` signifie
    que le cabinet a fourni des commentaires justifiant les écarts >
    seuil. ``False`` = warning. ``None`` = pas encore évalué."""
    if payload.sincerite_commentee is None:
        return ConditionResult(
            id=2,
            label="Sincérité (qualitatif)",
            passed=False,
            evaluable=False,
            message="Aucune saisie qualitative — relancer le cabinet",
        )
    return ConditionResult(
        id=2,
        label="Sincérité (qualitatif)",
        passed=payload.sincerite_commentee,
        evaluable=True,
        message=(
            "Commentaires fournis"
            if payload.sincerite_commentee
            else "Commentaires manquants sur écarts > seuil"
        ),
    )


def _condition_3_remboursement_capital(payload: EquilibreReelInput) -> ConditionResult:
    """Remboursement capital N non couvert par produit emprunts :
    ``capital_rembourse_via_emprunt <= 0`` (sauf renégociation).
    """
    if payload.capital_rembourse_via_emprunt is None:
        return ConditionResult(
            id=3,
            label="Remboursement capital indépendant du produit emprunts",
            passed=False,
            evaluable=False,
            message="Capital remboursé via emprunt non fourni (TF §M)",
        )
    passed = payload.capital_rembourse_via_emprunt <= _ZERO
    return ConditionResult(
        id=3,
        label="Remboursement capital indépendant du produit emprunts",
        passed=passed,
        evaluable=True,
        message=(
            "Conforme — pas de couverture emprunteuse"
            if passed
            else f"{payload.capital_rembourse_via_emprunt:.2f}€ de capital "
            "couvert par produit emprunts (interdit sauf renégo)"
        ),
    )


def _condition_4_caf_suffisante(payload: EquilibreReelInput) -> ConditionResult:
    """CAF suffisante pour couvrir le capital à rembourser N."""
    if payload.caf_n is None or payload.capital_a_rembourser_n is None:
        return ConditionResult(
            id=4,
            label="CAF >= capital à rembourser N",
            passed=False,
            evaluable=False,
            message="CAF ou capital à rembourser N non fourni",
        )
    passed = payload.caf_n >= payload.capital_a_rembourser_n
    return ConditionResult(
        id=4,
        label="CAF >= capital à rembourser N",
        passed=passed,
        evaluable=True,
        message=(
            f"CAF {payload.caf_n:.2f}€ couvre IAF {payload.capital_a_rembourser_n:.2f}€"
            if passed
            else f"CAF insuffisante : {payload.caf_n:.2f}€ "
            f"< {payload.capital_a_rembourser_n:.2f}€"
        ),
    )


def _condition_5_recettes_affectees(payload: EquilibreReelInput) -> ConditionResult:
    """Recettes affectées employées à l'usage prévu.

    Égalité recettes_affectees == recettes_affectees_utilisees (à 0,01 € près).
    """
    if payload.recettes_affectees is None or payload.recettes_affectees_utilisees is None:
        return ConditionResult(
            id=5,
            label="Recettes affectées utilisées",
            passed=False,
            evaluable=False,
            message="Affectations non fournies (§J)",
        )
    diff = payload.recettes_affectees - payload.recettes_affectees_utilisees
    passed = abs(diff) <= _STRICT_TOLERANCE
    return ConditionResult(
        id=5,
        label="Recettes affectées utilisées",
        passed=passed,
        evaluable=True,
        message=(
            "Toutes les recettes affectées sont utilisées"
            if passed
            else f"Solde non utilisé : {diff:.2f}€"
        ),
    )


def validate_equilibre_reel(payload: EquilibreReelInput) -> EquilibreReelResult:
    """Évalue les 5 conditions R.314-222.

    Verdict ``equilibre=true`` ssi **toutes** les conditions sont
    évaluables ET passées. Un input partiel (par ex. CAF manquante)
    laisse ``evaluable_globalement=false`` — D-034 exige une transition
    `BROUILLON → TRANSMIS` qui bloque tant que tout n'est pas évalué.
    """
    conditions = [
        _condition_1_produits_tarifs(payload),
        _condition_2_sincerite(payload),
        _condition_3_remboursement_capital(payload),
        _condition_4_caf_suffisante(payload),
        _condition_5_recettes_affectees(payload),
    ]
    nb_evaluables = sum(1 for c in conditions if c.evaluable)
    nb_passees = sum(1 for c in conditions if c.passed)
    evaluable_globalement = all(c.evaluable for c in conditions)
    equilibre = evaluable_globalement and all(c.passed for c in conditions)
    return EquilibreReelResult(
        conditions=conditions,
        nb_evaluables=nb_evaluables,
        nb_passees=nb_passees,
        evaluable_globalement=evaluable_globalement,
        equilibre=equilibre,
    )


# ---------------------------------------------------------------------------
# F.EQ.02 — Équilibre strict (hors CPOM)
# ---------------------------------------------------------------------------


def validate_equilibre_strict(
    payload: EquilibreStrictInput,
) -> EquilibreStrictResult:
    """Recettes == dépenses, tolérance 0,01 € (S03 p.29).

    Pas de condition évaluable / non-évaluable : les deux totaux sont
    requis dans l'input. Si un total manque, le caller doit gérer
    l'absence avant l'appel.
    """
    ecart = payload.total_recettes - payload.total_depenses
    equilibre = abs(ecart) <= _STRICT_TOLERANCE
    return EquilibreStrictResult(
        ecart=ecart,
        equilibre=equilibre,
        tolerance_appliquee=_STRICT_TOLERANCE,
    )
