"""Valeur point GIR départemental — F.GIR.01 (R.314-175).

Source : ``knowledge-base/07-formules-metier.md`` §1 + ``S03`` p.21.

**Async** (contrairement aux autres services finance) parce qu'il
consomme la KB référentielle core PLT-VG via
:func:`reference_lookup.valeur_point_gir_with_clapet` qui passe par
``run_in_thread``. C'est un compromis : on garde §I "logique pure"
mais on accepte une lecture DB ici pour aller chercher la valeur
arrêté annuel PCD — pas de manière de l'inclure dans l'input
dataclass sans demander au caller de pré-charger la KB ref complète.

Règles dures appliquées :

* **Clapet anti-retour** (R.314-175) : ``valeur(N) >= valeur(N-1)``.
  Enforce via :func:`reference_lookup.valeur_point_gir_with_clapet`.
  Le résultat porte ``clapet_applique=True`` quand la KB ref avait
  une valeur(N) < valeur(N-1) — info pour l'UI cabinet.
* **TVA 5,5% pour privé commercial** (R.314-175) : charges nettes
  TTC pour les EHPAD privés commerciaux, HT sinon. Le caller fournit
  ``est_prive_commercial`` ; le service applique le facteur 1,055 si
  vrai.

Fallback N-1 : si la KB ref n'a pas de valeur pour l'année demandée
mais en a une pour N-1, le service retourne celle-ci avec
``fallback_annee=N-1`` — flag explicite pour l'UI ("Estimation
basée sur N-1, valeur N pas encore publiée par le PCD").
"""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.models.finance import (
    ValeurPointGirInput,
    ValeurPointGirResult,
)
from piilot_pack_compta_esms.services import reference_lookup

_TVA_PRIVE_COMMERCIAL = Decimal("1.055")
"""S03 p.21 — TVA 5,5% pour EHPAD privés commerciaux. Appliquée au
montant HT pour obtenir le montant TTC."""


async def resolve_valeur_point_gir(
    payload: ValeurPointGirInput,
) -> ValeurPointGirResult:
    """Résout la valeur du point GIR applicable à un EHPAD.

    Étapes :

    1. Lookup KB ref PLT-VG avec clapet anti-retour
       (:func:`reference_lookup.valeur_point_gir_with_clapet`).
       Renvoie ``(valeur_post_clapet, clapet_applique, fallback_annee)``.
    2. Si EHPAD privé commercial → multiplie par 1,055 (TTC).
    3. Retourne un :class:`ValeurPointGirResult` portant à la fois la
       valeur brute (catalog) et la valeur effective (après clapet +
       TVA) pour traçabilité.
    """
    valeur_post_clapet, clapet_applique, fallback_annee = (
        await reference_lookup.valeur_point_gir_with_clapet(payload.code_departement, payload.annee)
    )
    valeur_brute = await reference_lookup.valeur_point_gir(payload.code_departement, payload.annee)

    valeur_finale: Decimal | None = valeur_post_clapet
    if valeur_finale is not None and payload.est_prive_commercial:
        valeur_finale = valeur_finale * _TVA_PRIVE_COMMERCIAL

    return ValeurPointGirResult(
        code_departement=payload.code_departement,
        annee=payload.annee,
        valeur=valeur_finale,
        valeur_brute=valeur_brute,
        clapet_applique=clapet_applique,
        fallback_annee=fallback_annee,
        est_prive_commercial=payload.est_prive_commercial,
    )
