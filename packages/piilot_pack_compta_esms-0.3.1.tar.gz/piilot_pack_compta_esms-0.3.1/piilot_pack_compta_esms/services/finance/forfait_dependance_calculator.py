"""Forfait global dépendance (F.DEP.01 + F.GIR.03 modulation).

Sources :
- ``knowledge-base/07-formules-metier.md`` §1
- ``S03`` FAQ DGCS p.19 (formule de base) + p.22 (R.314-174 modulation TO)

Pure function. Le caller (§S Annexe 5 forfait) fournit les inputs ; ce
service applique :

1. F.DEP.01 — Forfait_dep_CD = Forfait_global_dep − [(particip_residents
   × TO_prev) + (hors_dept × TO_prev)]
2. F.GIR.03 — Modulation TO réalisé (depuis 2018) : si TO_realise <
   seuil → abattement = (seuil − TO_realise) / 2

Note : la modulation est facultative (le CD peut renoncer en cas de
situation exceptionnelle, S03 p.22). Le flag ``apply_modulation``
dans l'input permet de la désactiver explicitement.
"""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.models.finance import (
    ForfaitDependanceInput,
    ForfaitDependanceResult,
    GmpDepartementalInput,
    GmpDepartementalResult,
)

_ZERO = Decimal("0")
_TWO = Decimal("2")
_HUNDRED = Decimal("100")
_TO_MAX_MODULATION = Decimal("0.95")
"""S03 p.22 — pas de modulation à la hausse au-dessus de 95% TO."""


def compute_forfait_dependance_cd(
    payload: ForfaitDependanceInput,
) -> ForfaitDependanceResult:
    """Calcule le forfait dépendance versé par le CD d'implantation.

    Formule de base (S03 p.19) :

    ``Forfait_dep_CD = Forfait_global_dep − [(particip × TO_prev)
                                            + (hors_dept × TO_prev)]``

    Modulation R.314-174 (depuis 2018) :

    * Si ``apply_modulation=False`` ou ``annee < 2018`` ou
      ``to_realise is None`` ou ``seuil_modulation_pct is None`` →
      pas de modulation, ``modulation_appliquee=False``.
    * Si ``to_realise >= 0.95`` → pas de modulation (plafond S03 p.22).
    * Si ``to_realise >= seuil`` → pas de modulation (TO conforme).
    * Sinon → ``abattement_pct = (seuil − to_realise) / 2`` (en
      pourcentage), appliqué multiplicativement sur le forfait brut.
    """
    brut = payload.forfait_global_dependance - (
        (payload.montant_participations_residents * payload.to_previsionnel)
        + (payload.montant_hors_departement * payload.to_previsionnel)
    )

    abattement_pct = _ZERO
    modulation_appliquee = False

    if (
        payload.apply_modulation
        and payload.to_realise is not None
        and payload.seuil_modulation_pct is not None
        and payload.to_realise < _TO_MAX_MODULATION
    ):
        seuil_fraction = payload.seuil_modulation_pct / _HUNDRED
        if payload.to_realise < seuil_fraction:
            # Abattement en pourcentage = (seuil − to_realise) / 2 × 100
            abattement_pct = ((seuil_fraction - payload.to_realise) / _TWO) * _HUNDRED
            modulation_appliquee = True

    module = brut * (_HUNDRED - abattement_pct) / _HUNDRED

    return ForfaitDependanceResult(
        forfait_cd_implantation_brut=brut,
        forfait_cd_implantation_module=module,
        abattement_pct=abattement_pct,
        modulation_appliquee=modulation_appliquee,
    )


# ---------------------------------------------------------------------------
# F.GIR.02 — GMP départemental
# ---------------------------------------------------------------------------


def compute_gmp_departemental(
    payload: GmpDepartementalInput,
) -> GmpDepartementalResult:
    """GMP départemental = Σ(points_GIR × HP) / Σ(HP), hors USLD (S03 p.21).

    Le caller doit avoir filtré les USLD avant l'appel. Chaque
    élément de ``ehpads`` est un dict ``{"points_gir": Decimal,
    "capacite_hp": Decimal}``.

    Renvoie ``gmp=0`` si la liste est vide ou si Σ(HP) == 0.
    """
    total_points_pondere = _ZERO
    total_hp = _ZERO
    for ehpad in payload.ehpads:
        points = ehpad.get("points_gir", _ZERO)
        hp = ehpad.get("capacite_hp", _ZERO)
        total_points_pondere += points * hp
        total_hp += hp
    if total_hp == _ZERO:
        return GmpDepartementalResult(gmp=_ZERO, nb_ehpads=len(payload.ehpads))
    return GmpDepartementalResult(
        gmp=total_points_pondere / total_hp,
        nb_ehpads=len(payload.ehpads),
    )
