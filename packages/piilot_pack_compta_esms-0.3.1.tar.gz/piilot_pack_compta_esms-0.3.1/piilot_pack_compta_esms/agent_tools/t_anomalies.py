"""Tool ``compta_esms.detect_anomalies`` (§AH) — délègue §Z + §AA.

Agrège :
* Contrôles bloquants KO (D-034)
* Ratios atypies (hors seuils DGCS)
* Indicateurs santé alerte/critique (CAF, FRNG, BFR, Trésorerie)
"""

from __future__ import annotations

from piilot_pack_compta_esms.agent_tools._base import (
    format_currency_fr,
    format_domain_error,
    parse_document_id,
    render_markdown_table,
    resolve_company_user,
)
from piilot_pack_compta_esms.services import (
    controles_service,
    indicateurs_service,
    ratios_service,
)

_BAD_SANTES: frozenset[str] = frozenset({"alerte", "critique"})


async def detect_anomalies_fn(
    document_id: str,
    session_id: str = "",
) -> str:
    """Détecte les anomalies sur un document : contrôles KO + ratios atypies
    + indicateurs alerte/critique.

    Args:
        document_id: UUID du document.
        session_id: injecté par bind_session.

    Returns:
        Markdown — 3 sections (contrôles bloquants, ratios atypies,
        indicateurs alerte). Si rien à signaler : message rassurant.
    """
    try:
        company_id, _ = resolve_company_user(session_id)
        doc_uuid = parse_document_id(document_id)

        # 1. Contrôles bloquants KO
        controles_summary = await controles_service.compute_summary(doc_uuid, company_id)
        controles_ko = []
        if controles_summary.ko > 0:
            all_controles = await controles_service.list_controles(
                doc_uuid, company_id, statut="ko"
            )
            controles_ko = all_controles

        # 2. Ratios atypies — type_filter all pour ERRD + PGFP
        ratios_atypies = []
        try:
            ratios_response = await ratios_service.compute_ratios(
                doc_uuid, company_id, type_filter="all"
            )
            ratios_atypies = [r for r in ratios_response.ratios_errd if r.verdict == "atypie"]
        except Exception:  # noqa: BLE001
            # Ratios peuvent être indisponibles selon type doc — pas bloquant
            ratios_response = None

        # 3. Indicateurs alerte/critique
        try:
            indicateurs_response = await indicateurs_service.compute_indicateurs(
                doc_uuid, company_id
            )
            indicateurs_bad = [
                ind
                for ind in (
                    indicateurs_response.caf,
                    indicateurs_response.frng,
                    indicateurs_response.bfr,
                    indicateurs_response.tresorerie,
                )
                if ind.sante in _BAD_SANTES
            ]
        except Exception:  # noqa: BLE001
            indicateurs_bad = []
    except Exception as exc:  # noqa: BLE001
        return format_domain_error(exc)

    parts = [f"**Détection d'anomalies — document {document_id}**", ""]

    nb_anomalies = len(controles_ko) + len(ratios_atypies) + len(indicateurs_bad)
    if nb_anomalies == 0:
        parts.append(
            "✅ Aucune anomalie détectée : pas de contrôle KO, "
            "pas de ratio atypique, indicateurs financiers sains "
            "(ou non évaluables, voir compute_indicateurs)."
        )
        return "\n".join(parts)

    if controles_ko:
        parts.append(f"**🔴 Contrôles KO ({len(controles_ko)})** :")
        headers = ["Code", "Sévérité", "Message"]
        rows = [
            [
                r.code,
                r.severite_observee,
                (r.message_humain or "—")[:120],
            ]
            for r in controles_ko[:20]
        ]
        parts.append(render_markdown_table(headers, rows))
        if controles_summary.ko_bloquant > 0:
            parts.append(
                f"⛔ Dont **{controles_summary.ko_bloquant} bloquants** — "
                f"la transmission du document sera refusée."
            )
        parts.append("")

    if ratios_atypies:
        parts.append(f"**⚠ Ratios atypiques ({len(ratios_atypies)})** :")
        headers = ["Ratio", "Valeur", "Seuil"]
        rows = []
        for r in ratios_atypies[:10]:
            seuil = "—"
            if r.seuil_max is not None:
                seuil = f"≤ {r.seuil_max}"
            elif r.seuil_min is not None:
                seuil = f"≥ {r.seuil_min}"
            valeur_text = "—" if r.valeur is None else f"{float(r.valeur):.2f}".replace(".", ",")
            rows.append([f"{r.id} — {r.label}", valeur_text, seuil])
        parts.append(render_markdown_table(headers, rows))
        parts.append("")

    if indicateurs_bad:
        parts.append(f"**🟠 Indicateurs en alerte ({len(indicateurs_bad)})** :")
        headers = ["Indicateur", "Valeur", "Santé"]
        rows = [
            [ind.label, format_currency_fr(ind.valeur), ind.sante or "—"] for ind in indicateurs_bad
        ]
        parts.append(render_markdown_table(headers, rows))
        parts.append("")

    parts.append(
        f"**Total** : {nb_anomalies} anomalie(s) à investiguer "
        f"(prioriser les contrôles bloquants)."
    )
    return "\n".join(parts)
