"""Tool ``compta_esms.synthese_ria`` (§AH) — délègue §W ria_service.

Récupère la matrice "Synthèse résultats" d'un RIA (Rapport Infra-Annuel) :
3 colonnes par CR (Résultat N-1 / Dernier EPRD exécutoire N / Projection
actualisée N).
"""

from __future__ import annotations

from piilot_pack_compta_esms.agent_tools._base import (
    format_currency_fr,
    format_domain_error,
    parse_document_id,
    render_markdown_table,
    resolve_company_user,
)
from piilot_pack_compta_esms.services import ria_service


async def synthese_ria_fn(
    ria_id: str,
    session_id: str = "",
) -> str:
    """Retourne la matrice Synthèse résultats d'un RIA.

    Args:
        ria_id: UUID du document RIA.
        session_id: injecté par bind_session.

    Returns:
        Markdown — tableau N-1 / EPRD N / Projection N par CR.
        Erreur explicite si le document n'est pas un RIA.
    """
    try:
        company_id, _ = resolve_company_user(session_id)
        ria_uuid = parse_document_id(ria_id)
        response = await ria_service.compute_synthese_resultats(ria_uuid, company_id)
    except Exception as exc:  # noqa: BLE001
        return format_domain_error(exc)

    if not response.rows:
        return (
            "ℹ️ Aucune ligne calculable pour ce RIA. Vérifier que :\n"
            "- Le document parent (EPRD) a des CRs saisis.\n"
            "- Les CRs du RIA matchent les CRs du parent par (ETS+cr_type)."
        )

    headers = [
        "CR",
        "Résultat N-1 (ERRD)",
        "Dernier EPRD N",
        "Projection actualisée N",
    ]
    rows = [
        [
            row.denomination or row.cr_type or "—",
            format_currency_fr(row.resultat_comptable_n_minus_1),
            format_currency_fr(row.eprd_executoire_n.resultat if row.eprd_executoire_n else None),
            format_currency_fr(row.projection_actualisee_n.resultat),
        ]
        for row in response.rows
    ]
    table = render_markdown_table(headers, rows)

    parts = [
        f"**Synthèse résultats RIA — {ria_id}**",
        "",
        table,
        "",
    ]

    total = response.total
    eprd_total = total.eprd_executoire_n.resultat if total.eprd_executoire_n else None
    parts.append(
        f"**Total document** : "
        f"N-1 = {format_currency_fr(total.resultat_comptable_n_minus_1)} · "
        f"EPRD N = {format_currency_fr(eprd_total)} · "
        f"Projection N = {format_currency_fr(total.projection_actualisee_n.resultat)}."
    )

    if response.errd_n_minus_1_id is None:
        parts.append("_Note_ : aucun ERRD N-1 finalisé trouvé — colonne N-1 vide pour ce RIA.")

    return "\n".join(parts)
