"""Helpers partagés §AH — résolution session, format FR, gestion d'erreurs.

Surface autorisée plugin
------------------------

* ``piilot.sdk.session.get(session_id)`` — récupère le ``SessionState``
  (read-only). Le ``state.user_infos`` contient ``_organization_id``
  (= company_id pour les agents plugin-aware) et ``_user_id``.
* ``piilot.sdk.tools.bind_session`` — wrapper qui injecte ``session_id``
  via ``RunnableConfig`` (LangGraph) sans l'exposer au LLM.

Les tools §AH n'importent **jamais** depuis ``backend.*`` — l'AST check
au boot refuserait le plugin sinon.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

# `piilot.sdk.session.get` est wiré au boot par le loader vers le vrai
# session_manager core ; en dehors d'un host (tests unitaires plugin),
# l'appel raise NotImplementedError. Les tools doivent donc gérer ce
# cas — voir ``resolve_company_user`` ci-dessous.
from piilot.sdk import session as session_sdk

# ---------------------------------------------------------------------------
# Résolution session → company_id
# ---------------------------------------------------------------------------


class SessionResolutionError(Exception):
    """Levée quand on ne peut pas extraire un (company_id, user_id) du
    session_id fourni par le LLM via LangGraph."""

    def __init__(self, code: str, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"{code}: {message}")


def resolve_company_user(session_id: str) -> tuple[UUID, UUID | None]:
    """Extrait ``(company_id, user_id?)`` depuis le SessionState courant.

    Le ``session_id`` arrive automatiquement via ``bind_session`` — le
    LLM ne le voit pas. Si la session est inconnue ou si la company
    n'est pas posée, on raise :class:`SessionResolutionError` que les
    tools convertissent en message FR.
    """
    if not session_id:
        raise SessionResolutionError(
            "session_missing",
            "Session introuvable — l'agent doit être démarré dans le contexte d'une company.",
        )

    try:
        state = session_sdk.get(session_id)
    except NotImplementedError:
        # En tests unitaires sans host — pas de session manager wiré.
        raise SessionResolutionError(
            "session_sdk_unwired",
            "SDK session non câblé (contexte hors host).",
        ) from None

    if state is None:
        raise SessionResolutionError(
            "session_unknown",
            f"Session {session_id} inconnue ou expirée.",
        )

    user_infos = getattr(state, "user_infos", None) or {}
    org_id_raw = user_infos.get("_organization_id")
    if not org_id_raw:
        raise SessionResolutionError(
            "company_missing",
            "Aucune company active dans la session courante.",
        )

    try:
        company_id = UUID(str(org_id_raw))
    except (ValueError, TypeError) as exc:
        raise SessionResolutionError(
            "company_invalid",
            f"company_id session malformé : {org_id_raw!r}.",
        ) from exc

    user_id_raw = user_infos.get("_user_id")
    user_id: UUID | None
    if user_id_raw:
        try:
            user_id = UUID(str(user_id_raw))
        except (ValueError, TypeError):
            user_id = None
    else:
        user_id = None

    return company_id, user_id


def parse_document_id(raw: str) -> UUID:
    """Parse un document_id arrivant du LLM en string. Lève
    :class:`SessionResolutionError` avec code ``document_id_invalid``
    si parse impossible — le tool retourne un message FR clair.
    """
    if not raw:
        raise SessionResolutionError(
            "document_id_invalid",
            "document_id manquant.",
        )
    try:
        return UUID(str(raw).strip())
    except (ValueError, TypeError) as exc:
        raise SessionResolutionError(
            "document_id_invalid",
            f"document_id mal formé : {raw!r} (attendu : UUID).",
        ) from exc


# ---------------------------------------------------------------------------
# Format helpers FR — utilisés par les tools pour rendre du texte LLM-ready
# ---------------------------------------------------------------------------


def format_currency_fr(value: Decimal | int | float | None) -> str:
    """``1234.56`` → ``"1 234,56 €"``. ``None`` → ``"—"``."""
    if value is None:
        return "—"
    rounded = round(float(value), 2)
    raw = f"{rounded:,.2f}"
    swapped = raw.replace(",", " ").replace(".", ",")
    return f"{swapped} €"


def format_int_fr(value: int | None) -> str:
    if value is None:
        return "—"
    return f"{int(value):,}".replace(",", " ")


def format_percent_fr(value: Decimal | float | None, *, decimals: int = 1) -> str:
    if value is None:
        return "—"
    fmt = f"{{:.{decimals}f}}".format(float(value))
    return f"{fmt} %".replace(".", ",")


def format_decimal_fr(value: Decimal | float | None, *, decimals: int = 2) -> str:
    if value is None:
        return "—"
    fmt = f"{{:.{decimals}f}}".format(float(value))
    return fmt.replace(".", ",")


# ---------------------------------------------------------------------------
# Markdown table helper — output LLM-friendly
# ---------------------------------------------------------------------------


def render_markdown_table(headers: list[str], rows: list[list[str]]) -> str:
    """Rend un tableau Markdown compact.

    L'agent affiche ça tel quel à l'utilisateur (Piilot chat rend le
    Markdown). Aucune mise en forme excessive — colonnes minimum,
    pas d'alignement explicite.

    ``headers`` ne doit contenir aucun caractère ``|`` (D-075). Les
    valeurs des ``rows`` peuvent contenir des espaces mais sont
    nettoyées via :func:`_sanitize_cell`.
    """
    if not headers:
        return ""
    sanitized_headers = [_sanitize_cell(h) for h in headers]
    line_header = "| " + " | ".join(sanitized_headers) + " |"
    line_sep = "|" + "|".join(["---"] * len(headers)) + "|"
    line_rows = ["| " + " | ".join(_sanitize_cell(c) for c in row) + " |" for row in rows]
    return "\n".join([line_header, line_sep, *line_rows])


def _sanitize_cell(raw: Any) -> str:
    """Strip + remplace ``|`` (réservé Markdown) + ``\n`` par espace."""
    value = "" if raw is None else str(raw)
    return value.replace("|", "/").replace("\n", " ").strip()


# ---------------------------------------------------------------------------
# Error envelope — convertit les exceptions domaine en str user-friendly
# ---------------------------------------------------------------------------


def format_domain_error(exc: Exception) -> str:
    """Convertit une exception côté service en message FR pour le LLM.

    Pattern :

    * ``DomainError`` (NotFoundError, ConflictError, ValidationError) →
      lecture de ``exc.code`` + ``exc.message`` (champs standardisés
      sur services.errors).
    * ``SessionResolutionError`` → format dédié.
    * Autre → message générique "Erreur interne — retry ou contactez
      le support".

    Le LLM doit pouvoir lire la cause et la transmettre à l'utilisateur,
    pas re-tenter en boucle.
    """
    if isinstance(exc, SessionResolutionError):
        return f"⚠️ {exc.message}"

    code = getattr(exc, "code", None)
    message = getattr(exc, "message", None) or str(exc)
    if code:
        return f"⚠️ {message} (code: {code})"
    return f"⚠️ Erreur lors de l'opération : {message}"


# ---------------------------------------------------------------------------
# Verdict / santé label helpers
# ---------------------------------------------------------------------------


_SANTE_LABELS_FR: dict[str, str] = {
    "sain": "✅ sain",
    "attention": "⚠ attention",
    "alerte": "🟠 alerte",
    "critique": "🔴 critique",
}

_VERDICT_LABELS_FR: dict[str, str] = {
    "ok": "✅ OK",
    "atypie": "⚠ atypie",
    "na": "— non évalué",
}


def label_sante(sante: str | None) -> str:
    if sante is None:
        return "—"
    return _SANTE_LABELS_FR.get(sante, sante)


def label_verdict(verdict: str | None) -> str:
    if verdict is None:
        return "—"
    return _VERDICT_LABELS_FR.get(verdict, verdict)
