"""Tool ``compta_esms.suggest_workflow_transition`` (§AH) — délègue §S.

Propose les transitions légales applicables au document (selon doc_type
+ statut courant) et liste les actions bloquées + raisons machine.
"""

from __future__ import annotations

from piilot_pack_compta_esms.agent_tools._base import (
    format_domain_error,
    parse_document_id,
    render_markdown_table,
    resolve_company_user,
)
from piilot_pack_compta_esms.services import workflow_service

_ROLE_DEFAULT = "builder"
_ALLOWED_ROLES: frozenset[str] = frozenset({"user", "builder", "admin"})


async def suggest_workflow_transition_fn(
    document_id: str,
    role: str = _ROLE_DEFAULT,
    session_id: str = "",
) -> str:
    """Liste les transitions workflow possibles + actions bloquées.

    Args:
        document_id: UUID du document.
        role: rôle assumé par l'agent (``"user"`` · ``"builder"`` ·
            ``"admin"``). Défaut ``"builder"`` — le rôle métier
            standard pour un cabinet EC.
        session_id: injecté par bind_session.

    Returns:
        Markdown — état courant + actions allowed + actions blocked
        + double validation EPRD si applicable.
    """
    if role not in _ALLOWED_ROLES:
        return f"⚠️ role invalide : {role!r}. " f"Valeurs : {sorted(_ALLOWED_ROLES)}."

    try:
        company_id, _ = resolve_company_user(session_id)
        doc_uuid = parse_document_id(document_id)
        response = await workflow_service.get_transitions_allowed(
            document_id=doc_uuid,
            company_id=company_id,
            role=role,
        )
    except Exception as exc:  # noqa: BLE001
        return format_domain_error(exc)

    parts = [
        f"**Workflow document {document_id}**",
        "",
        f"_Type_ : {response.type_document.upper()} · "
        f"_Statut actuel_ : `{response.current_statut}`",
        "",
    ]

    if response.allowed:
        parts.append("**✅ Actions autorisées** :")
        headers = ["Action", "Label", "Autorité", "Rôle requis"]
        rows = [
            [
                a.action,
                a.label,
                a.autorite or "—",
                a.role_required,
            ]
            for a in response.allowed
        ]
        parts.append(render_markdown_table(headers, rows))
        parts.append("")

    if response.blocked:
        parts.append("**🔴 Actions bloquées** :")
        headers = ["Action", "Autorité", "Raison (code machine)"]
        rows = [[b.action, b.autorite or "—", b.reason] for b in response.blocked]
        parts.append(render_markdown_table(headers, rows))
        parts.append("")

    dv = response.double_validation
    if dv.applicable:
        parts.append("**Double validation ARS+CD (EPRD-family)** :")
        ars_state = "✅ approuvé" if dv.approuve_par_ars_at else "⏳ en attente"
        cd_state = "✅ approuvé" if dv.approuve_par_cd_at else "⏳ en attente"
        parts.append(f"- ARS : {ars_state}")
        parts.append(f"- CD : {cd_state}")

    if not response.allowed and not response.blocked:
        parts.append("ℹ️ Aucune transition disponible — le document est en état terminal.")

    return "\n".join(parts)
