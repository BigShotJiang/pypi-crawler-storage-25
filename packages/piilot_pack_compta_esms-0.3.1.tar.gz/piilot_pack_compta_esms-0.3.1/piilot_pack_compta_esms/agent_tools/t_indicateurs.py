"""Tool ``compta_esms.compute_indicateurs`` (§AH) — délègue §I biblio.

Calcule CAF + FRNG + BFR + Trésorerie + verdict R.314-222 pour un
document_id. Stateless, async, retourne un str Markdown lisible.
"""

from __future__ import annotations

from piilot_pack_compta_esms.agent_tools._base import (
    format_currency_fr,
    format_domain_error,
    label_sante,
    parse_document_id,
    render_markdown_table,
    resolve_company_user,
)
from piilot_pack_compta_esms.services import indicateurs_service


async def compute_indicateurs_fn(
    document_id: str,
    session_id: str = "",
) -> str:
    """Calcule les 4 indicateurs financiers transverses pour un document.

    Args:
        document_id: UUID du document EPRD/ERRD/DM/RIA/ERCP/EPCP.
        session_id: injecté par ``bind_session`` — invisible au LLM.

    Returns:
        Texte Markdown avec tableau des 4 indicateurs + verdict
        équilibre R.314-222. Si données incomplètes : message FR
        listant les sections manquantes.
    """
    try:
        company_id, _ = resolve_company_user(session_id)
        doc_uuid = parse_document_id(document_id)
        response = await indicateurs_service.compute_indicateurs(doc_uuid, company_id)
    except Exception as exc:  # noqa: BLE001
        return format_domain_error(exc)

    headers = ["Indicateur", "Valeur", "Santé", "Manque"]
    rows: list[list[str]] = []
    for ind in (response.caf, response.frng, response.bfr, response.tresorerie):
        manque = ", ".join(ind.missing_inputs) if ind.missing_inputs else "—"
        rows.append(
            [
                ind.label,
                format_currency_fr(ind.valeur),
                label_sante(ind.sante),
                manque,
            ]
        )

    table = render_markdown_table(headers, rows)

    parts = [
        f"**Indicateurs financiers — {response.type_document.upper()}**",
        "",
        table,
        "",
        f"**Équilibre R.314-222** : {response.equilibre_status}",
        response.equilibre_message,
    ]
    return "\n".join(parts)
