"""Tool ``compta_esms.analyse_affectation_resultat`` (§AH) — délègue §J.

Décrit la variante d'affectation applicable (Prive_I/II/Public_I/II)
+ recommande la répartition des résultats à affecter par CR.
"""

from __future__ import annotations

from piilot_pack_compta_esms.agent_tools._base import (
    format_currency_fr,
    format_domain_error,
    parse_document_id,
    render_markdown_table,
    resolve_company_user,
)
from piilot_pack_compta_esms.services import affectation_service

_VARIANTE_DESCRIPTIONS: dict[str, str] = {
    "prive_I": (
        "Privé hors CPOM (ESSMS privés sans Contrat Pluriannuel d'Objectifs "
        "et de Moyens). Affectation par ESSMS, tableau ternaire H/D/S "
        "pour les EHPAD."
    ),
    "prive_II": (
        "Privé inclus CPOM (ESSMS privés avec CPOM). Affectation "
        "consolidée document, comptes 110/119/10682-10687."
    ),
    "public_I": (
        "Public hors CPOM (ESSMS publics sans CPOM). Affectation par "
        "ESSMS, plan comptable public (comptes 12/110/119/106xx)."
    ),
    "public_II": (
        "Public inclus CPOM (ESSMS publics avec CPOM). Affectation " "consolidée document."
    ),
}


async def analyse_affectation_resultat_fn(
    document_id: str,
    session_id: str = "",
) -> str:
    """Décrit la variante d'affectation + récap des résultats bruts.

    Args:
        document_id: UUID d'un document ERRD/ERCP (pas EPRD).
        session_id: injecté par bind_session.

    Returns:
        Markdown — variante détectée + description + Σ résultats par CR.
        Si pas applicable (EPRD ou statut juridique inconnu), explique
        pourquoi.
    """
    try:
        company_id, _ = resolve_company_user(session_id)
        doc_uuid = parse_document_id(document_id)
        response = await affectation_service.list_affectations(doc_uuid, company_id)
    except Exception as exc:  # noqa: BLE001
        return format_domain_error(exc)

    variante = response.variante_active
    if variante is None:
        return (
            "ℹ️ Variante d'affectation indéterminée. Vérifier que :\n"
            "- Le document est un ERRD ou ERCP (l'EPRD ne porte pas d'affectation).\n"
            "- Le statut juridique de l'organisme gestionnaire est posé "
            "(public vs privé).\n"
            "- Le périmètre CPOM est renseigné (inclus / hors CPOM)."
        )

    description = _VARIANTE_DESCRIPTIONS.get(variante, "—")

    parts = [
        f"**Variante d'affectation active** : `{variante}`",
        "",
        description,
        "",
    ]

    if response.resultats_bruts:
        headers = ["CR", "Charges réalisé", "Produits réalisé", "Résultat brut"]
        rows = [
            [
                f"{rb.cr_denomination or '—'} ({rb.cr_id or 'consolidé'})",
                format_currency_fr(rb.total_charges_realise),
                format_currency_fr(rb.total_produits_realise),
                format_currency_fr(rb.resultat_brut),
            ]
            for rb in response.resultats_bruts
        ]
        parts.append("**Résultats à affecter par CR** :")
        parts.append(render_markdown_table(headers, rows))
    else:
        parts.append("ℹ️ Aucun résultat brut calculable — vérifier que le CRP est saisi.")

    if response.items:
        parts.append("")
        parts.append(
            f"**Affectations déjà saisies** : {len(response.items)} ligne(s) " f"sur ce document."
        )
        if response.validation.valide:
            parts.append("✅ Σ affectations = Σ résultats bruts (validation OK).")
        else:
            parts.append(
                f"⚠ Validation Σ affectations ≠ Σ résultats : "
                f"{len(response.validation.issues)} écart(s) détecté(s)."
            )

    return "\n".join(parts)
