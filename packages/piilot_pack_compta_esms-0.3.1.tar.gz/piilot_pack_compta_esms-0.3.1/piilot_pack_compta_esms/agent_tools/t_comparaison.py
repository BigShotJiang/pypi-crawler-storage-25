"""Tool ``compta_esms.compare_eprd_errd`` (§AH).

Compare 2 documents (EPRD prévi vs ERRD réa) sur les charges/produits
agrégés par CR. Variance absolue + % par poste.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.agent_tools._base import (
    format_currency_fr,
    format_domain_error,
    format_percent_fr,
    parse_document_id,
    render_markdown_table,
    resolve_company_user,
)
from piilot_pack_compta_esms.repositories import cr_repo, document_repo
from piilot_pack_compta_esms.services.errors import NotFoundError


async def _load_doc_or_404(document_id, company_id):
    row = await run_in_thread(document_repo.get_by_id, document_id)
    if row is None or str(row["company_id"]) != str(company_id):
        raise NotFoundError(
            f"document_not_found:{document_id}",
            code="document_not_found",
        )
    return row


async def _aggregate_by_cr_type(
    document_id,
    *,
    use_realise: bool,
) -> dict[str, dict[str, Decimal]]:
    """Σ charges et produits par ``cr_type`` du document.

    ``use_realise=True`` agrège la colonne réalisé (ERRD/ERCP/EPCP).
    ``use_realise=False`` agrège la colonne previsions_totales
    (EPRD/DM/RIA/AVENANT).
    """
    crs = await run_in_thread(cr_repo.list_by_document, document_id)
    if use_realise:
        aggregates = await run_in_thread(cr_repo.aggregate_realise_by_cr, document_id)
    else:
        aggregates = await run_in_thread(cr_repo.aggregate_charges_produits_by_cr, document_id)

    by_type: dict[str, dict[str, Decimal]] = {}
    for cr in crs:
        cr_type = cr.get("cr_type") or "—"
        cr_id: UUID = cr["id"]
        agg = aggregates.get(cr_id, {"charges": Decimal(0), "produits": Decimal(0)})
        slot = by_type.setdefault(
            cr_type,
            {"charges": Decimal(0), "produits": Decimal(0)},
        )
        slot["charges"] += Decimal(agg.get("charges") or 0)
        slot["produits"] += Decimal(agg.get("produits") or 0)
    return by_type


async def compare_eprd_errd_fn(
    eprd_id: str,
    errd_id: str,
    session_id: str = "",
) -> str:
    """Compare un EPRD (prévisionnel) avec un ERRD (réalisé).

    Args:
        eprd_id: UUID du document EPRD.
        errd_id: UUID du document ERRD (généralement sur le même exercice).
        session_id: injecté par bind_session.

    Returns:
        Markdown — tableau écart par cr_type (charges, produits, % variance).
        Erreurs explicites si les documents n'ont pas les bons types.
    """
    try:
        company_id, _ = resolve_company_user(session_id)
        eprd_uuid = parse_document_id(eprd_id)
        errd_uuid = parse_document_id(errd_id)

        eprd_doc = await _load_doc_or_404(eprd_uuid, company_id)
        errd_doc = await _load_doc_or_404(errd_uuid, company_id)

        if eprd_doc["type_document"] != "eprd":
            return (
                f"⚠️ Le premier document ({eprd_id}) doit être un EPRD, "
                f"got '{eprd_doc['type_document']}'."
            )
        if errd_doc["type_document"] != "errd":
            return (
                f"⚠️ Le second document ({errd_id}) doit être un ERRD, "
                f"got '{errd_doc['type_document']}'."
            )

        eprd_by_cr = await _aggregate_by_cr_type(eprd_uuid, use_realise=False)
        errd_by_cr = await _aggregate_by_cr_type(errd_uuid, use_realise=True)
    except Exception as exc:  # noqa: BLE001
        return format_domain_error(exc)

    all_cr_types = sorted(set(eprd_by_cr) | set(errd_by_cr))
    if not all_cr_types:
        return (
            "ℹ️ Aucun CR commun trouvé entre les 2 documents — "
            "vérifier que les CRPs sont saisis."
        )

    parts = [
        "**Comparaison EPRD (prévi) vs ERRD (réa)**",
        "",
    ]

    # Charges
    parts.append("**Charges par CR**")
    headers = ["CR", "Prévi EPRD", "Réa ERRD", "Écart", "Variance"]
    rows_charges = _build_variance_rows(all_cr_types, eprd_by_cr, errd_by_cr, "charges")
    parts.append(render_markdown_table(headers, rows_charges))

    # Produits
    parts.append("")
    parts.append("**Produits par CR**")
    rows_produits = _build_variance_rows(all_cr_types, eprd_by_cr, errd_by_cr, "produits")
    parts.append(render_markdown_table(headers, rows_produits))

    # Total
    total_eprd_charges = sum(
        (v.get("charges", Decimal(0)) for v in eprd_by_cr.values()),
        Decimal(0),
    )
    total_errd_charges = sum(
        (v.get("charges", Decimal(0)) for v in errd_by_cr.values()),
        Decimal(0),
    )
    total_eprd_produits = sum(
        (v.get("produits", Decimal(0)) for v in eprd_by_cr.values()),
        Decimal(0),
    )
    total_errd_produits = sum(
        (v.get("produits", Decimal(0)) for v in errd_by_cr.values()),
        Decimal(0),
    )

    parts.append("")
    parts.append("**Totaux** :")
    parts.append(
        f"- Charges : {format_currency_fr(total_eprd_charges)} prévi → "
        f"{format_currency_fr(total_errd_charges)} réa "
        f"(écart : {format_currency_fr(total_errd_charges - total_eprd_charges)})"
    )
    parts.append(
        f"- Produits : {format_currency_fr(total_eprd_produits)} prévi → "
        f"{format_currency_fr(total_errd_produits)} réa "
        f"(écart : {format_currency_fr(total_errd_produits - total_eprd_produits)})"
    )

    return "\n".join(parts)


def _build_variance_rows(
    all_cr_types: list[str],
    eprd_by_cr: dict[str, dict[str, Decimal]],
    errd_by_cr: dict[str, dict[str, Decimal]],
    key: str,
) -> list[list[str]]:
    rows: list[list[str]] = []
    for cr_type in all_cr_types:
        prevu = eprd_by_cr.get(cr_type, {}).get(key, Decimal(0))
        realise = errd_by_cr.get(cr_type, {}).get(key, Decimal(0))
        ecart = realise - prevu
        if prevu == Decimal(0):
            variance_pct: Any = None
        else:
            variance_pct = (ecart / prevu) * Decimal(100)
        rows.append(
            [
                cr_type,
                format_currency_fr(prevu),
                format_currency_fr(realise),
                format_currency_fr(ecart),
                format_percent_fr(variance_pct, decimals=1),
            ]
        )
    return rows
