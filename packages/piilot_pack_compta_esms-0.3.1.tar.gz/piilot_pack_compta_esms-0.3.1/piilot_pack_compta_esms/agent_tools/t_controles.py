"""Tools ``compta_esms.list_controles`` + ``compta_esms.explain_controle``
(§AH) — délègue §Z controles_service + KB core PLT-43 libellés.
"""

from __future__ import annotations

from typing import Literal

from piilot_pack_compta_esms.agent_tools._base import (
    format_domain_error,
    parse_document_id,
    render_markdown_table,
    resolve_company_user,
)
from piilot_pack_compta_esms.services import controles_service, reference_lookup

_ALLOWED_STATUTS: frozenset[str] = frozenset({"all", "ok", "ko", "na", "warning"})
_AUDIT_CONTROLS_SLUG = "com.piilot.core.audit-controls-esms"


async def list_controles_fn(
    document_id: str,
    statut: Literal["all", "ok", "ko", "na", "warning"] = "all",
    session_id: str = "",
) -> str:
    """Liste les contrôles déjà évalués sur un document, filtrés par statut.

    Args:
        document_id: UUID du document.
        statut: ``"all"`` (défaut) · ``"ok"`` · ``"ko"`` · ``"na"`` ·
            ``"warning"`` (= KO sévérité warning).
        session_id: injecté par bind_session.

    Returns:
        Markdown — tableau code / statut / sévérité / message + synthèse
        (total OK/KO/NA). Si aucun contrôle évalué, message indicatif.
    """
    if statut not in _ALLOWED_STATUTS:
        return f"⚠️ statut invalide : {statut!r}. " f"Valeurs : {sorted(_ALLOWED_STATUTS)}."

    try:
        company_id, _ = resolve_company_user(session_id)
        doc_uuid = parse_document_id(document_id)
        statut_arg = None if statut == "all" else statut
        results = await controles_service.list_controles(doc_uuid, company_id, statut=statut_arg)
        summary = await controles_service.compute_summary(doc_uuid, company_id)
    except Exception as exc:  # noqa: BLE001
        return format_domain_error(exc)

    if not results:
        return (
            f"ℹ️ Aucun contrôle évalué (statut={statut!r}). "
            f"Lancer ``POST /documents/{document_id}/controles:run`` "
            f"pour évaluer les {summary.total} contrôles applicables."
        )

    headers = ["Code", "Statut", "Sévérité", "Message"]
    rows = [
        [
            r.code,
            r.statut.upper(),
            r.severite_observee,
            (r.message_humain or "—")[:100],
        ]
        for r in results
    ]
    table = render_markdown_table(headers, rows)

    parts = [
        f"**Contrôles intégrés ({statut})** — document {document_id}",
        "",
        table,
        "",
        (
            f"**Synthèse globale** : {summary.ok} OK · {summary.ko} KO "
            f"({summary.ko_bloquant} bloquants, {summary.ko_error} errors, "
            f"{summary.ko_warning} warnings) · {summary.na} NA / "
            f"{summary.total} contrôles applicables."
        ),
    ]
    return "\n".join(parts)


async def explain_controle_fn(
    document_id: str,
    code: str,
    session_id: str = "",
) -> str:
    """Détaille un contrôle métier : libellé KB + résultat sur le document.

    Args:
        document_id: UUID du document.
        code: code contrôle (ex ``"C-001"``, ``"C-101"``).
        session_id: injecté par bind_session.

    Returns:
        Texte FR avec :
        - Libellé du contrôle (depuis KB core PLT-43)
        - Description / règle métier
        - Statut actuel sur le doc (OK/KO/NA + message)
        - Pistes de remédiation si KO
    """
    if not code:
        return "⚠️ Le paramètre ``code`` est obligatoire (ex: C-001, C-101)."

    code_normalise = code.strip().upper()

    try:
        company_id, _ = resolve_company_user(session_id)
        doc_uuid = parse_document_id(document_id)

        # KB lookup
        rows = await reference_lookup.list_all_rows(_AUDIT_CONTROLS_SLUG)
        catalog_row = next(
            (r for r in rows if (r.get("code") or "").upper() == code_normalise),
            None,
        )

        # Doc result lookup
        results = await controles_service.list_controles(doc_uuid, company_id)
    except Exception as exc:  # noqa: BLE001
        return format_domain_error(exc)

    if catalog_row is None:
        return (
            f"⚠️ Code contrôle {code_normalise!r} introuvable dans le "
            f"catalogue KB core PLT-43. Codes valides : C-001 à C-320."
        )

    libelle = catalog_row.get("libelle") or "—"
    description = catalog_row.get("description") or "—"
    severite = catalog_row.get("severite") or "—"
    is_bloquant = str(catalog_row.get("is_bloquant_transition") or "").lower() in {
        "true",
        "1",
        "yes",
    }
    applicable = catalog_row.get("applicable_doc_types") or "—"

    parts = [
        f"**Contrôle {code_normalise}** — {libelle}",
        "",
        f"_Description_ : {description}",
        f"_Sévérité catalogue_ : {severite}",
        f"_Applicable sur_ : {applicable}",
        f"_Bloquant transmission_ : {'oui' if is_bloquant else 'non'}",
        "",
    ]

    doc_result = next((r for r in results if r.code == code_normalise), None)
    if doc_result is None:
        parts.append(
            "ℹ️ Ce contrôle n'a pas encore été évalué sur ce document. "
            "Lancer un ``:run`` avant de demander l'explication détaillée."
        )
    else:
        parts.extend(
            [
                f"**Résultat actuel** : {doc_result.statut.upper()} "
                f"(sévérité observée : {doc_result.severite_observee})",
                f"_Message_ : {doc_result.message_humain or '—'}",
            ]
        )
        if doc_result.statut == "ko" and is_bloquant:
            parts.append("")
            parts.append(
                "🔴 **Contrôle bloquant KO** — la transmission du document "
                "sera refusée tant que ce contrôle reste KO. "
                "Vérifier les valeurs saisies + relancer ``:run``."
            )

    return "\n".join(parts)
