"""§AH — Agent tools + agent template (Assistant Compta-ESMS).

9 tools métier propriétaires + 1 template, déclarés au ``Plugin.register()``
via :func:`register_all`. Les tools sont exposés au LLM via
``StructuredTool.from_function(bind_session(_fn), …)`` — le ``session_id``
n'apparaît jamais dans la JSON-schema visible au LLM (LangChain le voit
comme paramètre ``RunnableConfig`` interne).

Architecture :

* ``_base.py`` — helpers communs (session resolution, format FR,
  Markdown table, error envelope, verdict labels).
* ``t_*.py`` — 1 fichier par tool, expose ``_fn`` async + une
  constante ``TOOL_SPEC`` consumée par :func:`register_all`.
* ``assistant_template.py`` — déclare l'agent template `compta_esms.
  assistant_eprd_errd` via :func:`register_template`.
"""

from __future__ import annotations

import logging

from piilot.sdk.tools import bind_session, register_tool

from piilot_pack_compta_esms.agent_tools.assistant_template import (
    register_assistant_template,
)
from piilot_pack_compta_esms.agent_tools.t_affectation import (
    analyse_affectation_resultat_fn,
)
from piilot_pack_compta_esms.agent_tools.t_anomalies import detect_anomalies_fn
from piilot_pack_compta_esms.agent_tools.t_comparaison import compare_eprd_errd_fn
from piilot_pack_compta_esms.agent_tools.t_controles import (
    explain_controle_fn,
    list_controles_fn,
)
from piilot_pack_compta_esms.agent_tools.t_indicateurs import compute_indicateurs_fn
from piilot_pack_compta_esms.agent_tools.t_ratios import compute_ratios_fn
from piilot_pack_compta_esms.agent_tools.t_ria import synthese_ria_fn
from piilot_pack_compta_esms.agent_tools.t_workflow import (
    suggest_workflow_transition_fn,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Catalogue déclaratif — id + description + fn
# ---------------------------------------------------------------------------


def _spec(*, tool_id: str, label_key: str, description: str, fn) -> dict:
    """Builds the tool spec dict consumed by ``StructuredTool.from_function``.

    Lazy local import of ``StructuredTool`` keeps ``langchain_core`` an
    optional dep at module import time — plugin tests that don't touch
    the agent tool layer don't need it installed.
    """
    from langchain_core.tools import StructuredTool

    structured = StructuredTool.from_function(
        coroutine=bind_session(fn),
        name=tool_id.split(".", 1)[1],  # short name côté LLM
        description=description,
    )
    return {
        "id": tool_id,
        "namespace": "compta_esms",
        "label_key": label_key,
        "description_key": f"{label_key}.description",
        "tool": structured,
    }


_TOOLS_CATALOG: list[dict] = []  # rempli par :func:`_build_catalog`


def _build_catalog() -> list[dict]:
    """Build le catalogue à la demande — lazy car ``_spec`` importe
    ``langchain_core`` qui n'est pas nécessaire pendant les imports
    plugin sans agent runtime."""

    return [
        _spec(
            tool_id="compta_esms.compute_indicateurs",
            label_key="compta_esms.tools.compute_indicateurs.label",
            description=(
                "Calcule les 4 indicateurs financiers transverses (CAF, FRNG, "
                "BFR, Trésorerie nette) d'un document budgétaire ESMS et "
                "rapporte le verdict R.314-222. Pour ERRD : valeurs réalisées. "
                "Pour EPRD/DM/RIA : valeurs prévisionnelles. "
                "Params : document_id (UUID str)."
            ),
            fn=compute_indicateurs_fn,
        ),
        _spec(
            tool_id="compta_esms.compute_ratios",
            label_key="compta_esms.tools.compute_ratios.label",
            description=(
                "Calcule les ratios financiers DGCS d'un document : 15 ratios "
                "ERRD (D-091 endettement/patrimoine/équilibres/rotation) et/ou "
                "8 ratios PGFP prévisionnels (D-095). "
                "Params : document_id (UUID str), type_filter ('errd' | "
                "'pgfp' | 'all', défaut 'errd')."
            ),
            fn=compute_ratios_fn,
        ),
        _spec(
            tool_id="compta_esms.list_controles",
            label_key="compta_esms.tools.list_controles.label",
            description=(
                "Liste les contrôles intégrés DGCS déjà évalués sur un "
                "document (catalogue PLT-43, 117 contrôles), filtrés par "
                "statut. Inclut le résumé OK/KO/NA + détail des bloquants. "
                "Params : document_id (UUID str), statut ('all' | 'ok' | "
                "'ko' | 'na' | 'warning', défaut 'all')."
            ),
            fn=list_controles_fn,
        ),
        _spec(
            tool_id="compta_esms.explain_controle",
            label_key="compta_esms.tools.explain_controle.label",
            description=(
                "Explique un contrôle métier précis : libellé + description "
                "depuis le catalogue KB PLT-43, sévérité, applicabilité par "
                "type document, et statut actuel sur le document fourni. "
                "Params : document_id (UUID str), code (str, ex 'C-001')."
            ),
            fn=explain_controle_fn,
        ),
        _spec(
            tool_id="compta_esms.detect_anomalies",
            label_key="compta_esms.tools.detect_anomalies.label",
            description=(
                "Détecte les anomalies d'un document : contrôles KO (avec "
                "highlight bloquants), ratios atypiques hors seuils DGCS, "
                "indicateurs financiers en alerte/critique. Synthèse globale "
                "+ détail par catégorie. "
                "Params : document_id (UUID str)."
            ),
            fn=detect_anomalies_fn,
        ),
        _spec(
            tool_id="compta_esms.analyse_affectation_resultat",
            label_key="compta_esms.tools.analyse_affectation_resultat.label",
            description=(
                "Décrit la variante d'affectation applicable à un ERRD "
                "(Privé I/II / Public I/II — D-082) + récap des résultats "
                "bruts par CR + état de validation. Ne propose pas la "
                "répartition — c'est au cabinet de la définir. "
                "Params : document_id (UUID str)."
            ),
            fn=analyse_affectation_resultat_fn,
        ),
        _spec(
            tool_id="compta_esms.compare_eprd_errd",
            label_key="compta_esms.tools.compare_eprd_errd.label",
            description=(
                "Compare un EPRD (prévi) avec un ERRD (réa), généralement "
                "sur le même exercice. Tableau écart absolu + variance % "
                "par cr_type pour les charges et produits. "
                "Params : eprd_id (UUID str), errd_id (UUID str)."
            ),
            fn=compare_eprd_errd_fn,
        ),
        _spec(
            tool_id="compta_esms.synthese_ria",
            label_key="compta_esms.tools.synthese_ria.label",
            description=(
                "Affiche la matrice Synthèse résultats d'un RIA (3 colonnes "
                "par CR : Résultat ERRD N-1, Dernier EPRD exécutoire N, "
                "Projection actualisée N). "
                "Params : ria_id (UUID str d'un document type='ria')."
            ),
            fn=synthese_ria_fn,
        ),
        _spec(
            tool_id="compta_esms.suggest_workflow_transition",
            label_key="compta_esms.tools.suggest_workflow_transition.label",
            description=(
                "Liste les transitions workflow autorisées + actions "
                "bloquées (avec raison machine) pour un document. Inclut "
                "l'état double validation ARS+CD pour EPRD-family. "
                "Params : document_id (UUID str), role ('user' | 'builder' "
                "| 'admin', défaut 'builder')."
            ),
            fn=suggest_workflow_transition_fn,
        ),
    ]


# ---------------------------------------------------------------------------
# Public — register_all(), appelé depuis Plugin.register()
# ---------------------------------------------------------------------------


def register_all_tools() -> int:
    """Enregistre les 9 agent tools §AH via le SDK.

    Doit être appelé sous ``current_plugin`` contextvar = ``"compta_esms"``
    (auto-géré par le loader autour de ``Plugin.register``).

    Retourne le nombre de tools registered (utile pour les tests).
    """
    catalog = _build_catalog()
    for spec in catalog:
        register_tool(spec, on_duplicate="replace")
    logger.info("compta_esms: %d agent tools registered (§AH)", len(catalog))
    return len(catalog)


__all__ = [
    "register_all_tools",
    "register_assistant_template",
]
