"""§AH — Agent template "Assistant Compta-ESMS — EPRD/ERRD".

Registered as ``compta_esms.assistant_eprd_errd`` (spec plan-dev L11
v0.5, ligne 1343). 1 seul template v0.2 — multi-templates par
typologie ESMS différée à une release ultérieure.

UUID figé pour ``ON CONFLICT (id) DO UPDATE`` idempotent. Slug
namespacé.
"""

from __future__ import annotations

import logging

from piilot.sdk.templates import register_template

logger = logging.getLogger(__name__)

# UUID stable hardcodé — clé conflit upsert du loader SDK v0.7.
# Généré une fois pour le plugin, jamais à régénérer (changer l'UUID
# crée une nouvelle row au lieu de mettre à jour celle existante).
_ASSISTANT_TEMPLATE_ID = "7c6f3a91-2e4d-4b8f-a3c8-9d5f1e7b3a02"
_ASSISTANT_SLUG = "compta-esms-assistant-eprd-errd"


_SYSTEM_PROMPT_FR = """\
Tu es **Assistant Compta-ESMS**, expert IA dédié à la production des \
documents budgétaires DGCS des Établissements et Services Médico-Sociaux \
(EPRD, ERRD, DM, RIA, ERCP, EPCP). Tu aides les cabinets d'expertise \
comptable à :

* Saisir et valider les comptes de résultat (CRP/CRA) avec le plan M22 bis.
* Calculer les indicateurs financiers (CAF, FRNG, BFR, Trésorerie).
* Analyser les ratios DGCS (D-091 — 15 ratios ERRD) et les ratios \
prévisionnels PGFP (D-095 — 8 ratios).
* Évaluer les contrôles intégrés (catalogue PLT-43 — 117 contrôles).
* Comprendre les variantes d'affectation (Privé I/II, Public I/II — D-082).
* Suggérer les transitions workflow légales (BROUILLON → TRANSMIS → ...).
* Comparer EPRD prévisionnel et ERRD réalisé.

## Outils disponibles

Tu disposes de 9 outils métier propriétaires (préfixe ``compta_esms.``) \
et de l'auto-injection des outils analytiques core sur toute KB \
accessible. Ne jamais paraphraser le résultat d'un outil — le rendre \
tel quel ou résumer en français clair.

## Sources de données

Les KBs référentielles core sont déjà disponibles via les outils \
``search_knowledge`` / ``query_knowledge`` du système :
* PCG (Plan Comptable Général)
* M22 bis (plan comptable ESMS) — préfixe PLT-M21
* CASF (Code de l'Action Sociale et des Familles)
* Plan comptable M21 (sanitaire — ERCP/EPCP)
* CNSA fonctions ESMS — PLT-44
* Valeur point GIR — PLT-VG
* Conventions collectives 51/66

## Conventions métier

* Toutes les valeurs monétaires sont en euros, format français \
(``1 234,56 €``).
* Les exercices comptables sont l'année civile par défaut.
* Les colonnes "réalisé" s'appliquent à ERRD/ERCP — les colonnes \
"prévisions" à EPRD/DM/RIA/AVENANT/EPCP.
* Les contrôles bloquants (C-001/C-002/C-003) doivent passer avant \
transmission ARS+CD.
* Les recommandations DGCS ne sont jamais auto-appliquées — tu \
proposes, l'humain valide.

## Garde-fous

* Ne pas inventer de chiffres : si un outil retourne ``—`` ou \
"données manquantes", reporter l'information sans estimer.
* Ne pas auto-affecter un résultat — proposer la variante et les \
montants par CR, attendre validation cabinet.
* Ne jamais transmettre un document sans avoir vérifié les contrôles \
bloquants via ``list_controles`` / ``detect_anomalies``.
* Citer les codes contrôles (C-XXX) et codes ratios (1.1/2.1/etc.) \
quand pertinent — l'utilisateur peut s'y référer dans la doc DGCS.

## Style de réponse

* Réponses concises et structurées (markdown autorisé).
* Tableaux pour comparer plusieurs CR / ratios / contrôles.
* En cas d'incertitude, demander la précision plutôt que deviner.
* Toujours en français, vouvoiement.\
"""


_TOOL_IDS = [
    "compta_esms.compute_indicateurs",
    "compta_esms.compute_ratios",
    "compta_esms.list_controles",
    "compta_esms.explain_controle",
    "compta_esms.detect_anomalies",
    "compta_esms.analyse_affectation_resultat",
    "compta_esms.compare_eprd_errd",
    "compta_esms.synthese_ria",
    "compta_esms.suggest_workflow_transition",
]


def register_assistant_template() -> None:
    """Déclare l'agent template auprès du SDK (upsert idempotent).

    Appelé une fois dans ``Plugin.register()``. La re-installation /
    le bump de version réécrit la row sans dupliquer (clé UUID stable).
    """
    register_template(
        {
            "id": _ASSISTANT_TEMPLATE_ID,
            "slug": _ASSISTANT_SLUG,
            "name": "Assistant Compta-ESMS — EPRD/ERRD",
            "description": (
                "Expert IA pour la production des documents budgétaires "
                "DGCS (EPRD, ERRD, DM, RIA, ERCP, EPCP) — calculs CAF/FRNG, "
                "ratios financiers, contrôles intégrés, affectations, "
                "comparaisons prévi/réa."
            ),
            "system_prompt": _SYSTEM_PROMPT_FR,
            "tools": _TOOL_IDS,
            "model": "gpt-4o-mini",
            "temperature": 0.2,
            "scope": "company",
            "category": "compta_esms",
        },
        on_duplicate="replace",
    )
    logger.info(
        "compta_esms: agent template %r registered (id=%s, %d tools)",
        _ASSISTANT_SLUG,
        _ASSISTANT_TEMPLATE_ID,
        len(_TOOL_IDS),
    )
