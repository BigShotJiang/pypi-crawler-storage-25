"""Tool ``compta_esms.compute_ratios`` (§AH) — délègue §AA ratios_service.

Retourne les 15 ratios ERRD ou 8 ratios PGFP prévisionnels selon
``type_filter``. Détecte automatiquement le type de document si non
fourni.
"""

from __future__ import annotations

from typing import Literal

from piilot_pack_compta_esms.agent_tools._base import (
    format_decimal_fr,
    format_domain_error,
    format_percent_fr,
    label_verdict,
    parse_document_id,
    render_markdown_table,
    resolve_company_user,
)
from piilot_pack_compta_esms.services import ratios_service

_ALLOWED_FILTERS: frozenset[str] = frozenset({"all", "errd", "pgfp"})


def _format_ratio_value(unite: str, valeur) -> str:
    if valeur is None:
        return "—"
    if unite == "%":
        return format_percent_fr(valeur, decimals=1)
    if unite == "jours":
        return f"{float(valeur):.1f} j".replace(".", ",")
    if unite == "annees":
        return f"{float(valeur):.1f} ans".replace(".", ",")
    if unite == "x":
        return f"{float(valeur):.2f} x".replace(".", ",")
    return format_decimal_fr(valeur, decimals=2)


def _format_seuil(seuil_min, seuil_max) -> str:
    if seuil_min is not None and seuil_max is not None:
        return f"[{seuil_min} ; {seuil_max}]"
    if seuil_max is not None:
        return f"≤ {seuil_max}"
    if seuil_min is not None:
        return f"≥ {seuil_min}"
    return "—"


async def compute_ratios_fn(
    document_id: str,
    type_filter: Literal["all", "errd", "pgfp"] = "errd",
    session_id: str = "",
) -> str:
    """Calcule les ratios financiers DGCS d'un document.

    Args:
        document_id: UUID du document.
        type_filter: ``"errd"`` (15 ratios financiers réalisés),
            ``"pgfp"`` (8 ratios prévisionnels par exercice),
            ou ``"all"`` (les deux concaténés).
        session_id: injecté par bind_session.

    Returns:
        Texte Markdown avec tableau des ratios + verdict (OK/atypie/NA).
        Les ratios PGFP renvoient juste l'année N (présent) en table
        compacte — pour la vue 8 exercices complète, appeler
        ``compute_ratios`` sur l'API directement (hors tool).
    """
    if type_filter not in _ALLOWED_FILTERS:
        return (
            f"⚠️ type_filter invalide : {type_filter!r}. "
            f"Valeurs acceptées : {sorted(_ALLOWED_FILTERS)}."
        )

    try:
        company_id, _ = resolve_company_user(session_id)
        doc_uuid = parse_document_id(document_id)
        response = await ratios_service.compute_ratios(
            doc_uuid, company_id, type_filter=type_filter
        )
    except Exception as exc:  # noqa: BLE001
        return format_domain_error(exc)

    sections: list[str] = []

    if response.ratios_errd:
        headers = ["Ratio", "Valeur", "Seuil", "Verdict"]
        rows = [
            [
                f"{r.id} — {r.label}",
                _format_ratio_value(r.unite, r.valeur),
                _format_seuil(r.seuil_min, r.seuil_max),
                label_verdict(r.verdict),
            ]
            for r in response.ratios_errd
        ]
        sections.append("**Ratios ERRD (réalisé exercice N)**")
        sections.append(render_markdown_table(headers, rows))

    if response.ratios_pgfp:
        # Pour les PGFP, on ne montre que la cellule N (annee_offset=0)
        # pour rester lisible côté chat. Le tool full-exercices n'est
        # pas exposé v0.2.
        headers = ["Ratio", "N (présent)", "Verdict"]
        rows: list[list[str]] = []
        for r in response.ratios_pgfp:
            by_offset = {c.annee_offset: c for c in r.par_exercice}
            cell_n = by_offset.get(0)
            if cell_n is None:
                rows.append([r.label, "—", "—"])
            else:
                rows.append(
                    [
                        r.label,
                        _format_ratio_value("", cell_n.valeur),
                        label_verdict(cell_n.verdict),
                    ]
                )
        if sections:
            sections.append("")
        sections.append("**Ratios PGFP (prévisionnel — colonne N)**")
        sections.append(render_markdown_table(headers, rows))

    if not sections:
        return (
            "ℹ️ Aucun ratio évaluable pour ce document. "
            "Vérifier que le Bilan financier et le CRP sont saisis."
        )

    summary = response.summary_errd
    sections.append("")
    sections.append(
        f"**Synthèse ERRD** : {summary.nb_ok} OK · {summary.nb_atypie} atypies · "
        f"{summary.nb_na} non évalués sur {summary.total}."
    )
    return "\n".join(sections)
