"""Module seeds for the compta_esms plugin (v0.2 foundation).

Declares the 8 top-level métier modules listed in ``suivi.md`` §C.2 and the
manifest. Each module is idempotently upserted into ``modules.modules`` on
plugin load (SDK ``register_module`` is keyed on ``slug`` — re-installs
refresh descriptive columns but preserve UUID + user grants + bookmarks).

Status ``published`` so the modules show up in the host UI Modules sidebar
once the company has the plugin activated. Frontend ships 8 placeholder
views (``frontend/src/modules/<slug>/<Slug>ModuleView.tsx``) so the modules
are openable today; the real métier UX lands chantier by chantier per
``suivi.md`` by editing each placeholder file in place.
"""

from __future__ import annotations

from piilot.sdk.modules import register_module

# Module specs — ordered by sidebar position. The i18n keys point at
# ``locales/{fr,en}.json``. Bilingual labels (FR + EN) are mandatory.
_MODULES: list[dict] = [
    {
        "slug": "compta_esms.dashboard",
        "module_name": "Tableau de bord ESMS",
        "description": (
            "Vue d'ensemble cabinet — liste documents budgétaires (EPRD, ERRD, "
            "DM, RIA), KPIs activité, alertes échéances et contrôles."
        ),
        "icon": "layout-dashboard",
        "category": "vertical",
        "status": "published",
    },
    {
        "slug": "compta_esms.documents",
        "module_name": "Documents budgétaires",
        "description": (
            "Saisie polymorphe EPRD/ERRD/DM/RIA : CRPP/CRPA/CRP_SF, bilan "
            "financier + comptable, tableau de financement, PGFP, affectations, "
            "contrôles, exports XLSX/DOCX."
        ),
        "icon": "file-spreadsheet",
        "category": "vertical",
        "status": "published",
    },
    {
        "slug": "compta_esms.sources",
        "module_name": "Sources de données",
        "description": (
            "Binding KB → feature (D-103) et assistant de mapping balance "
            "source → M22 bis (D-108). Connexion aux référentiels core "
            "(PCG, M22 bis, CASF, CNSA fonctions ESMS)."
        ),
        "icon": "database",
        "category": "vertical",
        "status": "published",
    },
    {
        "slug": "compta_esms.etablissements",
        "module_name": "Établissements",
        "description": (
            "Settings organisme gestionnaire + ESMS multi (FINESS, typologie "
            "ref core, capacités triples, CPOM, conventions collectives, "
            "plan comptable PC/PNL D-086)."
        ),
        "icon": "building-2",
        "category": "vertical",
        "status": "published",
    },
    {
        "slug": "compta_esms.effectifs",
        "module_name": "Effectifs",
        "description": (
            "Tableaux prévisionnels et réalisés des effectifs (TPER + TER) "
            "avec ventilation H/D/S/SEA selon typologie (EHPAD, FAM-SAMSAH, "
            "autres ESSMS)."
        ),
        "icon": "users",
        "category": "vertical",
        "status": "published",
    },
    {
        "slug": "compta_esms.activite",
        "module_name": "Activité",
        "description": (
            "Annexe 4 — Activité GIR : capacités, journées, absences, GMP, PMP, "
            "calcul activité théorique."
        ),
        "icon": "activity",
        "category": "vertical",
        "status": "published",
    },
    {
        "slug": "compta_esms.annexes_financieres",
        "module_name": "Annexes financières",
        "description": (
            "Annexes 5 et 5D — forfaits Soins/Dépendance/SEA, paramètres "
            "(GMP, PMP, valeur point GIR, taux d'occupation), SAD-SPASAD."
        ),
        "icon": "wallet",
        "category": "vertical",
        "status": "published",
    },
    {
        "slug": "compta_esms.eps_sanitaire",
        "module_name": "EPS sanitaire",
        "description": (
            "Documents sanitaires ERCP (Annexe 11) et EPCP (Annexe 12) — "
            "nomenclature M21 distincte de M22 bis."
        ),
        "icon": "heart-pulse",
        "category": "vertical",
        "status": "published",
    },
    {
        "slug": "compta_esms.cpom",
        "module_name": "CPOM",
        "description": (
            "Contrats Pluriannuels d'Objectifs et de Moyens (§BA v0.3, "
            "D-027). 1 CPOM = 1 OG × N ESMS — périmètre tarifaire, "
            "cosignataires ARS/CD, durée 1-7 ans, objectifs avec impact "
            "EPRD et dashboard avancement. Pré-requis pour §BD "
            "compute_equilibre_applicable."
        ),
        "icon": "scroll-text",
        "category": "vertical",
        "status": "published",
    },
]


def wire_seeds() -> None:
    """Register the plugin's 8 métier modules.

    Called from ``Plugin.register()``. Buffered by the SDK and upserted
    by the plugin loader after ``register()`` returns — safe to call on
    every boot.
    """
    for spec in _MODULES:
        register_module(spec)
