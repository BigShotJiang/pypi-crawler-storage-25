"""KB binding Pydantic models (L2 §7, D-103).

A binding wires one (document, feature) pair to a KB row. ``kb_id``
points at ``public.knowledge_bases`` (resolved at PUT time, stored
explicitly along with ``kb_table`` for audit / freeze — if the KB
gets renamed / re-mounted later, the original physical table is still
queryable from history).

``column_mapping`` remaps the KB's column names to the contract's
column names. Direction : **keys are the contract columns**, values
are the KB columns. Ex. contract ``{"compte": "text"}``, KB has
``account_number`` → ``column_mapping = {"compte": "account_number"}``.
A 1:1 binding leaves the dict empty, contract names used as-is.

Cf. L1 schema lines 690-710.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

PlanComptableSource = Literal["M22Bis"]
"""Locked (D-106 + D-107) — non-M22Bis sources go through the §F
mapping assistant first."""


class KbBindingCreate(BaseModel):
    """Body of ``PUT /documents/{doc_id}/bindings/{feature_key}``.

    Upsert semantics : the route is idempotent, so PUTting twice with
    the same body replaces the existing binding. ``column_mapping``
    is optional — empty dict means "KB column names match the
    contract names verbatim".
    """

    model_config = ConfigDict(extra="forbid")

    kb_id: UUID
    column_mapping: dict[str, str] = Field(default_factory=dict)
    plan_comptable_source: PlanComptableSource = "M22Bis"


class KbBindingRead(BaseModel):
    """Body of ``GET /documents/{doc_id}/bindings`` (one item).

    ``kb_table`` is the resolved physical table (typically
    ``kbs.<scope>__<slug>__<uuid8>``) — useful client-side to display
    "data comes from <table>" provenance.
    """

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    feature_key: str
    kb_id: UUID
    kb_table: str
    column_mapping: dict[str, str]
    plan_comptable_source: PlanComptableSource
    bound_by_user_id: UUID
    bound_at: datetime


class ColumnCompatWarning(BaseModel):
    """Non-blocking compatibility note emitted by ``kb_discovery``.

    Permissive mode (Q3.b) accepts a KB whose column has a different
    logical type than the contract — PG will cast implicitly when
    reading. The warning surfaces in the candidate list and at preview
    time so the cabinet sees the mismatch without being blocked.
    """

    model_config = ConfigDict(extra="forbid")

    contract_column: str
    kb_column: str
    expected_type: str
    actual_type: str
    severity: Literal["info", "warning"] = "warning"


class CandidateKb(BaseModel):
    """One element of ``GET /documents/{doc_id}/bindings/candidate-kbs``.

    Lists the company-scoped KBs whose schema fits the feature's
    contract (after a permissive type check). Each candidate carries
    the warnings emitted during the check so the UI can show "⚠ types
    sortants" badges next to the dropdown.
    """

    model_config = ConfigDict(extra="forbid")

    kb_id: UUID
    name: str
    kb_table: str
    row_count: int
    owner_type: str | None = None
    owner_ref: str | None = None
    columns: list[dict[str, str]]
    warnings: list[ColumnCompatWarning] = Field(default_factory=list)


class BindingPreviewRow(BaseModel):
    """One aggregated row returned by ``POST .../bindings/{feature_key}:preview``.

    The shape is dynamic — keys mirror the feature's contract (text
    columns become GROUP BY dimensions, numeric columns become SUM
    measures), so we use ``dict[str, Any]`` rather than a typed model
    here. The UI knows which columns to expect from the feature
    catalog.
    """

    model_config = ConfigDict(extra="forbid")

    data: dict[str, Any]


class BindingPreviewResponse(BaseModel):
    """Envelope of ``:preview`` — rows + emitted warnings."""

    model_config = ConfigDict(extra="forbid")

    feature_key: str
    rows: list[BindingPreviewRow]
    warnings: list[ColumnCompatWarning] = Field(default_factory=list)
    row_count: int
    truncated: bool = False


class BindingPreviewRequest(BaseModel):
    """Body of ``POST .../bindings/{feature_key}:preview``.

    ``filters`` is an equality filter dict applied as WHERE clauses
    on the dimension columns (after column_mapping). Use it to scope
    a preview to one période, one établissement, one compte, etc.
    Values are coerced to PG via psycopg2's adapter.
    """

    model_config = ConfigDict(extra="forbid")

    filters: dict[str, Any] = Field(default_factory=dict)


class BindingValidationResult(BaseModel):
    """Body of ``GET /documents/{doc_id}/bindings:validation``.

    Reports which mandatory features (filtered by the document's
    doc_type and the établissement's typologie) are bound vs missing.
    ``ready_to_produce`` is the gate the workflow / export sections
    check before letting the cabinet finalize the document.
    """

    model_config = ConfigDict(extra="forbid")

    mandatory_features: list[str]
    bindings_present: list[str]
    missing: list[str]
    ready_to_produce: bool
