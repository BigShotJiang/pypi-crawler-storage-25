"""PGFP — Plan Global de Financement Pluriannuel (§O, L2 §9).

Document maître prospectif sur **8 exercices** (N-1 → N+6, D-094) structuré
en **10 blocs** (D-095). Spécifique à EPRD/DM/RIA (cf. 16-annexe1 §8).

L2 §9 expose 3 endpoints :

* §9.1 GET /pgfp — Items 148 lignes × 8 colonnes (template merge DB)
* §9.2 PATCH /pgfp — Upsert partiel par ``ligne_key`` (cohérent HTTP PATCH)
* §9.3 POST /pgfp:recompute — Recalcule auto FRI/FRE/FRNG/BFR/Trésorerie
  + CAF + Ratios prévisionnels + Contrôles cohérence (blocs calculés)

Architecture saisies/calculées (Q3) : **option (c)** template statique +
DB sparse. Le template :data:`PGFP_LINES_TEMPLATE` documente les ~130
lignes structurelles (``ligne_key``, ``section``, ``label``,
``is_computed``). Le GET merge template + DB rows. Le PATCH upsert par
``ligne_key`` ne touche QUE les lignes du payload. Le :recompute upsert
les lignes ``is_computed=True``.

Sémantique PATCH (Q4) : pas de replace_all. Cohérent HTTP PATCH semantics.

EPRD-only guard (Q8) : refuser 422 si ``doc.type_document NOT IN
('eprd', 'dm', 'ria')``.

``ligne_key`` convention (Q5) : snake_case dot-free, section-prefixé
(``crp_*``, ``caf_*``, ``fri_*``, ``fre_*``, ``frng_*``, ``bfr_*``,
``tresorerie_*``, ``ctrl_*``, ``dc_*``, ``ratio_*``). Stable, indépendant
du re-numbering DGCS.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

Section = Literal[
    "crp_consolides",
    "caf",
    "fri",
    "fre",
    "frng",
    "bfr",
    "tresorerie",
    "controles_coherence",
    "donnees_complementaires",
    "ratios",
]
"""10 blocs D-095. Le DDL CHECK aligné par migration 011 (initialement 8
valeurs en 002 — bug spec L1)."""


# ---------------------------------------------------------------------------
# Template 148 lignes — structure stable côté backend (Q3+Q5)
# ---------------------------------------------------------------------------


class PgfpLineSpec(BaseModel):
    """Une entrée du template structurel des lignes du PGFP. Décrit où
    se range la ligne et si elle est calculée par :recompute."""

    model_config = ConfigDict(extra="forbid")

    ligne_key: str
    section: Section
    label: str
    is_computed: bool = False


def _saisie(ligne_key: str, section: Section, label: str) -> PgfpLineSpec:
    return PgfpLineSpec(ligne_key=ligne_key, section=section, label=label, is_computed=False)


def _calc(ligne_key: str, section: Section, label: str) -> PgfpLineSpec:
    return PgfpLineSpec(ligne_key=ligne_key, section=section, label=label, is_computed=True)


PGFP_LINES_TEMPLATE: tuple[PgfpLineSpec, ...] = (
    # ------------------------------------------------------------------
    # BLOC 1 — CRP CONSOLIDÉS (Charges + Produits + sous-totaux marges)
    # ------------------------------------------------------------------
    # Charges
    _saisie("crp_g1_charges", "crp_consolides", "Groupe I — Charges exploitation courante"),
    _saisie("crp_g2_charges", "crp_consolides", "Groupe II — Charges personnel"),
    _saisie("crp_g3_charges", "crp_consolides", "Groupe III — Charges structure"),
    _calc("crp_total_charges", "crp_consolides", "Total des charges (A)"),
    _calc(
        "crp_charges_decaissables",
        "crp_consolides",
        "Charges décaissables (c/60 à c/62) — marge intermédiaire",
    ),
    _calc(
        "crp_charges_sociales",
        "crp_consolides",
        "Charges sociales (c/63 et c/645-647) — marge intermédiaire",
    ),
    # Produits
    _saisie("crp_g1_produits_etat", "crp_consolides", "G1 — Produits à charge de l'État"),
    _saisie(
        "crp_g1_produits_assurance_maladie",
        "crp_consolides",
        "G1 — Produits à charge de l'Assurance maladie",
    ),
    _saisie(
        "crp_g1_produits_departement",
        "crp_consolides",
        "G1 — Produits à charge du Département",
    ),
    _saisie("crp_g1_produits_usager", "crp_consolides", "G1 — Produits à charge de l'usager"),
    _saisie(
        "crp_g1_produits_autres_financeurs",
        "crp_consolides",
        "G1 — Produits autres financeurs",
    ),
    _saisie(
        "crp_g1_dont_aides_ars",
        "crp_consolides",
        "G1 — Dont aides ponctuelles ARS (info)",
    ),
    _saisie(
        "crp_g1_dont_aides_prefets",
        "crp_consolides",
        "G1 — Dont aides ponctuelles Préfets (info)",
    ),
    _saisie(
        "crp_g1_dont_aides_cd",
        "crp_consolides",
        "G1 — Dont aides ponctuelles Conseils Départementaux (info)",
    ),
    _saisie(
        "crp_g2_produits",
        "crp_consolides",
        "Groupe II — Autres produits exploitation (hors c/747, c/757)",
    ),
    _saisie(
        "crp_g3_produits",
        "crp_consolides",
        "Groupe III — Produits financiers, exceptionnels, non encaissables",
    ),
    _calc("crp_total_produits", "crp_consolides", "Total des produits (B)"),
    _calc(
        "crp_produits_hors_747_757_775_777_78",
        "crp_consolides",
        "Produits hors c/747, c/757, c/775, c/777, c/78 — marge intermédiaire",
    ),
    _calc(
        "crp_resultat_previsionnel",
        "crp_consolides",
        "Résultat prévisionnel (B - A)",
    ),
    # ------------------------------------------------------------------
    # BLOC 2 — CAF prévisionnelle
    # ------------------------------------------------------------------
    _calc("caf_resultat_base", "caf", "Résultat prévisionnel (FRE) — base CAF"),
    # Flux internes charges
    _saisie(
        "caf_flux_charges_fri_vc_immo_cedees",
        "caf",
        "Flux FRI — Valeur comptable immobilisations cédées (c/675)",
    ),
    _saisie(
        "caf_flux_charges_fri_dot_amortissements",
        "caf",
        "Flux FRI — Dotations amortissements",
    ),
    _saisie(
        "caf_flux_charges_fri_dot_provisions_reglementees",
        "caf",
        "Flux FRI — Dotations provisions réglementées (renouvellement immo)",
    ),
    _saisie(
        "caf_flux_charges_fri_autres_dotations_68748",
        "caf",
        "Flux FRI — Autres dotations FRI (c/68748)",
    ),
    _saisie(
        "caf_flux_charges_fri_reports_fonds_dedies_68921",
        "caf",
        "Flux FRI — Reports fonds dédiés investissement (c/68921, privés)",
    ),
    _saisie(
        "caf_flux_charges_fre_autres_dot_amort_provisions",
        "caf",
        "Flux FRE — Autres dotations amortissements/provisions",
    ),
    _saisie(
        "caf_flux_charges_fre_reports_fonds_dedies",
        "caf",
        "Flux FRE — Reports fonds dédiés (sauf c/68921, privés)",
    ),
    _calc("caf_flux_charges_total", "caf", "Total flux internes charges"),
    # Flux internes produits
    _saisie(
        "caf_flux_produits_fri_reprises_provisions",
        "caf",
        "Flux FRI — Reprises provisions réglementées",
    ),
    _saisie(
        "caf_flux_produits_fri_reprises_amort_78748",
        "caf",
        "Flux FRI — Reprises amortissements/autres (c/78748)",
    ),
    _saisie(
        "caf_flux_produits_fri_quote_part_subventions",
        "caf",
        "Flux FRI — Quote-part subventions investissement",
    ),
    _saisie(
        "caf_flux_produits_fri_quote_part_fonds_associatif",
        "caf",
        "Flux FRI — Quote-part fonds associatif",
    ),
    _saisie(
        "caf_flux_produits_fri_cessions_immo",
        "caf",
        "Flux FRI — Produits cessions immobilisations",
    ),
    _saisie(
        "caf_flux_produits_fri_utilisation_fonds_dedies_78921",
        "caf",
        "Flux FRI — Utilisation fonds dédiés investissement (c/78921)",
    ),
    _saisie(
        "caf_flux_produits_fre_reprises_autres_provisions",
        "caf",
        "Flux FRE — Reprises autres provisions",
    ),
    _saisie(
        "caf_flux_produits_fre_utilisation_fonds_dedies",
        "caf",
        "Flux FRE — Utilisation fonds dédiés (sauf c/78921, privés)",
    ),
    _calc("caf_flux_produits_total", "caf", "Total flux internes produits"),
    _calc("caf_total", "caf", "CAF (+) / IAF (-) prévisionnelle"),
    _calc("caf_part_fri", "caf", "Dont part affectant FRI (3)"),
    _calc("caf_part_fre", "caf", "Dont part affectant FRE (4)"),
    # ------------------------------------------------------------------
    # BLOC 3 — FRI (Fonds de Roulement Investissement)
    # ------------------------------------------------------------------
    _calc("fri_aug_caf_part", "fri", "FRI Aug — CAF/IAF affectée au FRI (3)"),
    _saisie(
        "fri_aug_reserves_excedents_invest",
        "fri",
        "FRI Aug — Réserves/excédents affectés invest. (c/10682 pub / c/106852 priv)",
    ),
    _saisie(
        "fri_aug_affectation_reserve_compensation",
        "fri",
        "FRI Aug — Affectation réserve compensation amort. (c/10687 / c/106857)",
    ),
    _saisie(
        "fri_aug_apports_dotations_reserves_fonds_propres",
        "fri",
        "FRI Aug — Apports/dotations/réserves/fonds propres (sauf c/106)",
    ),
    _saisie(
        "fri_aug_subventions_invest_c13",
        "fri",
        "FRI Aug — Subventions investissement (c/13)",
    ),
    _saisie("fri_aug_emprunts_c16", "fri", "FRI Aug — Emprunts c/16 à plus d'un an"),
    _saisie("fri_aug_produits_cessions_immo", "fri", "FRI Aug — Produits cessions immo"),
    _saisie(
        "fri_aug_comptes_liaison_invest_prives",
        "fri",
        "FRI Aug — Comptes de liaison investissement (privés)",
    ),
    _saisie("fri_aug_autres", "fri", "FRI Aug — Autres"),
    _calc("fri_augmentation_total", "fri", "Augmentation des financements stables FRI (5)"),
    _saisie(
        "fri_dim_fonds_propres_reserves_reduction",
        "fri",
        "FRI Dim — Fonds propres et réserves – Réduction (privés)",
    ),
    _saisie(
        "fri_dim_remboursements_emprunts_anterieurs",
        "fri",
        "FRI Dim — Remboursements emprunts antérieurs (part capital)",
    ),
    _saisie(
        "fri_dim_remboursements_emprunts_prevus_plan",
        "fri",
        "FRI Dim — Remboursements emprunts prévus au plan (part capital)",
    ),
    _saisie(
        "fri_dim_acquisitions_immo_incorporelles",
        "fri",
        "FRI Dim — Acquisitions immobilisations incorporelles",
    ),
    _saisie(
        "fri_dim_acquisitions_immo_terrains",
        "fri",
        "FRI Dim — Acquisitions terrains",
    ),
    _saisie(
        "fri_dim_acquisitions_immo_agencements",
        "fri",
        "FRI Dim — Acquisitions agencements",
    ),
    _saisie(
        "fri_dim_acquisitions_immo_constructions",
        "fri",
        "FRI Dim — Acquisitions constructions",
    ),
    _saisie(
        "fri_dim_acquisitions_immo_installations",
        "fri",
        "FRI Dim — Acquisitions installations",
    ),
    _saisie(
        "fri_dim_acquisitions_immo_autres_corporelles",
        "fri",
        "FRI Dim — Acquisitions autres immobilisations corporelles",
    ),
    _saisie(
        "fri_dim_acquisitions_immo_en_cours",
        "fri",
        "FRI Dim — Acquisitions immobilisations en cours",
    ),
    _saisie(
        "fri_dim_acquisitions_immo_financieres",
        "fri",
        "FRI Dim — Acquisitions immobilisations financières",
    ),
    _saisie(
        "fri_dim_reprise_reserves_compensation",
        "fri",
        "FRI Dim — Reprise sur réserves compensation amortissement",
    ),
    _saisie(
        "fri_dim_charges_a_repartir",
        "fri",
        "FRI Dim — Charges à répartir sur plusieurs exercices",
    ),
    _saisie(
        "fri_dim_comptes_liaison_invest_prives",
        "fri",
        "FRI Dim — Comptes de liaison investissement (privés)",
    ),
    _calc("fri_diminution_total", "fri", "Diminution FRI (6)"),
    _calc("fri_variations", "fri", "Variations FRI (5) - (6) = (7)"),
    _saisie("fri_initial", "fri", "FRI initial (8)"),
    _calc("fri_cumule_fin", "fri", "FRI cumulé fin période = (7) + (8) = (9)"),
    # ------------------------------------------------------------------
    # BLOC 4 — FRE (Fonds de Roulement Exploitation)
    # ------------------------------------------------------------------
    _calc("fre_aug_caf_part", "fre", "FRE Aug — CAF/IAF affectée FRE (4)"),
    _saisie(
        "fre_aug_reprise_reserves_compensation",
        "fre",
        "FRE Aug — Reprise réserves compensation amortissement",
    ),
    _saisie(
        "fre_aug_comptes_liaison_treso_stable_prives",
        "fre",
        "FRE Aug — Comptes liaison trésorerie stable (privés)",
    ),
    _saisie("fre_aug_autres", "fre", "FRE Aug — Autres"),
    _calc("fre_augmentation_total", "fre", "Augmentation FRE (10)"),
    _saisie(
        "fre_dim_reprise_reserves_couverture_bfr_invest",
        "fre",
        "FRE Dim — Reprise réserves couverture BFR à l'investissement",
    ),
    _saisie(
        "fre_dim_affectation_resultats_invest",
        "fre",
        "FRE Dim — Affectation résultats à l'investissement",
    ),
    _saisie(
        "fre_dim_affectation_reserve_compensation",
        "fre",
        "FRE Dim — Affectation à réserve compensation amortissement",
    ),
    _saisie(
        "fre_dim_comptes_liaison_treso_stable_prives",
        "fre",
        "FRE Dim — Comptes liaison trésorerie stable (privés)",
    ),
    _saisie("fre_dim_autres", "fre", "FRE Dim — Autres"),
    _calc("fre_diminution_total", "fre", "Diminution FRE (11)"),
    _calc("fre_variations", "fre", "Variations FRE (10) - (11) = (12)"),
    _saisie("fre_initial", "fre", "FRE initial (13)"),
    _calc("fre_cumule_fin", "fre", "FRE cumulé = (12) + (13) = (14)"),
    # ------------------------------------------------------------------
    # BLOC 5 — FRNG (Fonds de Roulement Net Global)
    # ------------------------------------------------------------------
    _calc("frng_apport_prelevement", "frng", "Apport/prélèvement FRNG = (7) + (12) = (15)"),
    _saisie("frng_initial", "frng", "FRNG initial (16)"),
    _calc("frng_fin_periode", "frng", "FRNG fin période = (15) + (16) = (17)"),
    # ------------------------------------------------------------------
    # BLOC 6 — BFR (Besoin en Fonds de Roulement)
    # ------------------------------------------------------------------
    _saisie("bfr_aug_stocks", "bfr", "BFR Aug — Augmentation stocks"),
    _saisie("bfr_aug_creances", "bfr", "BFR Aug — Augmentation créances (volume/prix)"),
    _saisie(
        "bfr_aug_diminution_dettes_fournisseurs",
        "bfr",
        "BFR Aug — Diminution dettes fournisseurs",
    ),
    _saisie("bfr_aug_autres", "bfr", "BFR Aug — Autres augmentations"),
    _calc("bfr_augmentation_total", "bfr", "Augmentation BFR (18)"),
    _saisie("bfr_dim_stocks", "bfr", "BFR Dim — Diminution stocks"),
    _saisie("bfr_dim_creances", "bfr", "BFR Dim — Diminution créances"),
    _saisie(
        "bfr_dim_augmentation_dettes_fournisseurs",
        "bfr",
        "BFR Dim — Augmentation dettes fournisseurs",
    ),
    _saisie("bfr_dim_autres", "bfr", "BFR Dim — Autres diminutions"),
    _calc("bfr_diminution_total", "bfr", "Diminution BFR (19)"),
    _calc("bfr_variations", "bfr", "Variations BFR (18) - (19) = (20)"),
    _saisie("bfr_initial", "bfr", "BFR initial (21)"),
    _calc("bfr_cumule_fin", "bfr", "BFR cumulé = (20) + (21) = (22)"),
    # ------------------------------------------------------------------
    # BLOC 7 — TRÉSORERIE
    # ------------------------------------------------------------------
    _calc(
        "tresorerie_variations",
        "tresorerie",
        "Variations trésorerie = (7) + (12) - (20) = (23)",
    ),
    _saisie("tresorerie_initiale", "tresorerie", "Trésorerie initiale (24)"),
    _calc(
        "tresorerie_fin_periode",
        "tresorerie",
        "Trésorerie fin période = (23) + (24) = (25)",
    ),
    _saisie(
        "tresorerie_variations_financements_court_terme",
        "tresorerie",
        "Variations financements court terme (26)",
    ),
    _calc(
        "tresorerie_liquidites_fin_periode",
        "tresorerie",
        "Liquidités fin période = Liquidités début + (23) + (26)",
    ),
    # ------------------------------------------------------------------
    # BLOC 8 — Contrôles cohérence (vs Bilan financier)
    # ------------------------------------------------------------------
    _calc(
        "ctrl_frng_vs_bilan",
        "controles_coherence",
        "Contrôle — FRNG calculé PGFP = FRNG Bilan (cellule D96)",
    ),
    _calc(
        "ctrl_tresorerie_vs_bilan",
        "controles_coherence",
        "Contrôle — Trésorerie calculée PGFP = Trésorerie Bilan (cellule D114)",
    ),
    _calc(
        "ctrl_variation_tresorerie_eprd_synthetique",
        "controles_coherence",
        "Contrôle — Variation trésorerie EPRD synthétique = Variation PGFP",
    ),
    # ------------------------------------------------------------------
    # BLOC 9 — Données complémentaires (input ratios)
    # ------------------------------------------------------------------
    _saisie(
        "dc_encours_emprunts_c16_plus_1an",
        "donnees_complementaires",
        "Encours emprunts c/16 (hors c/1688) à plus d'un an",
    ),
    _saisie(
        "dc_comptes_c165_c169_publics",
        "donnees_complementaires",
        "Comptes c/165 et c/169 (publics)",
    ),
    _saisie(
        "dc_remboursements_cautions_c165",
        "donnees_complementaires",
        "Remboursements cautions (c/165, publics)",
    ),
    _saisie(
        "dc_financements_stables_fri_fin",
        "donnees_complementaires",
        "Financements stables FRI fin année (hors amortissements)",
    ),
    _saisie(
        "dc_actif_immobilise_brut_fin",
        "donnees_complementaires",
        "Actif immobilisé brut fin année",
    ),
    _saisie(
        "dc_mesures_correctives_actif",
        "donnees_complementaires",
        "Mesures correctives actif (sorties immo etc.)",
    ),
    _calc(
        "dc_actif_immobilise_brut_calcul_vetuste",
        "donnees_complementaires",
        "Actif immobilisé brut pour calcul vétusté (computed)",
    ),
    _saisie(
        "dc_amortissements_cumules_fin",
        "donnees_complementaires",
        "Amortissements cumulés fin année",
    ),
    _saisie(
        "dc_mesures_correctives_amort",
        "donnees_complementaires",
        "Mesures correctives amortissements",
    ),
    _calc(
        "dc_amortissements_cumules_calcul_vetuste",
        "donnees_complementaires",
        "Amortissements cumulés pour calcul vétusté (computed)",
    ),
    _saisie(
        "dc_valeurs_comptables_immo_cedees_c652",
        "donnees_complementaires",
        "Valeurs comptables immobilisations cédées (c/652)",
    ),
    # ------------------------------------------------------------------
    # BLOC 10 — Ratios prévisionnels (8 ratios calculés)
    # ------------------------------------------------------------------
    _calc("ratio_taux_endettement", "ratios", "Taux d'endettement (seuil < 50%)"),
    _calc("ratio_duree_apparente_dette", "ratios", "Durée apparente dette (seuil < 10 ans)"),
    _calc(
        "ratio_caf_remboursement_capital",
        "ratios",
        "CAF / Remboursement annuel capital (seuil > 1)",
    ),
    _calc("ratio_tresorerie_jours", "ratios", "Trésorerie en jours"),
    _calc(
        "ratio_taux_caf_pourcent_produits",
        "ratios",
        "Taux CAF en % produits (hors c/747, 757, 775, 777, 78)",
    ),
    _calc("ratio_taux_vetuste_immo", "ratios", "Taux de vétusté global des immobilisations"),
    _calc(
        "ratio_marge_brute_exploitation",
        "ratios",
        "Marge brute exploitation (hors c/747, 757)",
    ),
    _calc(
        "ratio_taux_marge_brute_pourcent_produits",
        "ratios",
        "Taux de marge brute en % produits courants",
    ),
)
"""Template structurel des lignes du PGFP. ~135 lignes. Stable.

Le frontend consomme ce template (via le payload ``PgfpResponse.items``)
pour afficher la table 8 colonnes section par section. Les lignes
``is_computed=True`` apparaissent en gras / read-only côté UI."""


# Index by ligne_key for O(1) lookup
_TEMPLATE_BY_KEY: dict[str, PgfpLineSpec] = {spec.ligne_key: spec for spec in PGFP_LINES_TEMPLATE}


def template_line(ligne_key: str) -> PgfpLineSpec | None:
    """Retourne la spec d'une ligne du template, ou None si inconnue.

    Utilisé par le service pour valider qu'un ``ligne_key`` du PATCH
    existe bien et pour récupérer ``section`` / ``is_computed``."""
    return _TEMPLATE_BY_KEY.get(ligne_key)


# ---------------------------------------------------------------------------
# Create / PATCH (Q4 — upsert partiel par ligne_key)
# ---------------------------------------------------------------------------


class PgfpPatchItem(BaseModel):
    """Item du PATCH body. Identifié par ``ligne_key`` (le template
    documente la section + is_computed). Les 8 montants sont nullable
    pour permettre un PATCH partiel sur un sous-ensemble de colonnes."""

    model_config = ConfigDict(extra="forbid")

    ligne_key: str = Field(..., min_length=1, max_length=128)
    montant_nm1: Decimal | None = None
    montant_n: Decimal | None = None
    montant_np1: Decimal | None = None
    montant_np2: Decimal | None = None
    montant_np3: Decimal | None = None
    montant_np4: Decimal | None = None
    montant_np5: Decimal | None = None
    montant_np6: Decimal | None = None


class PgfpPatchRequest(BaseModel):
    """Body de ``PATCH /documents/{doc_id}/pgfp`` — array d'updates
    partiels. Sémantique upsert par ligne_key (Q4)."""

    model_config = ConfigDict(extra="forbid")

    items: list[PgfpPatchItem] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------


class PgfpLigneRead(BaseModel):
    """Une ligne du PGFP retournée par GET.

    Combine la spec template (``ligne_key``, ``section``, ``label``,
    ``is_computed``) + les montants 8 exercices (lus de la DB, ``None``
    si pas encore saisi/calculé).

    ``id`` est ``None`` pour les lignes du template qui n'ont pas
    encore de row en DB (option (c) Q3)."""

    model_config = ConfigDict(extra="forbid")

    id: UUID | None = None
    ligne_key: str
    section: Section
    label: str
    is_computed: bool
    montant_nm1: Decimal | None = None
    montant_n: Decimal | None = None
    montant_np1: Decimal | None = None
    montant_np2: Decimal | None = None
    montant_np3: Decimal | None = None
    montant_np4: Decimal | None = None
    montant_np5: Decimal | None = None
    montant_np6: Decimal | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class PgfpResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/pgfp``. Toujours ~148 items
    (template merge DB)."""

    model_config = ConfigDict(extra="forbid")

    items: list[PgfpLigneRead]


# ---------------------------------------------------------------------------
# :recompute response
# ---------------------------------------------------------------------------


class PgfpRecomputeWarning(BaseModel):
    """Une alerte non-bloquante émise pendant :recompute quand une
    donnée amont manque (CRP vide, Bilan non saisi, etc.)."""

    model_config = ConfigDict(extra="forbid")

    code: str
    message: str
    ligne_key: str | None = None


class PgfpRecomputeResponse(BaseModel):
    """Body de ``POST /documents/{doc_id}/pgfp:recompute``.

    Retourne le PGFP complet post-recompute + la liste des warnings
    pour les données amont manquantes (Q7 — fallback null/0, pas de
    hard fail)."""

    model_config = ConfigDict(extra="forbid")

    items: list[PgfpLigneRead]
    warnings: list[PgfpRecomputeWarning] = Field(default_factory=list)
