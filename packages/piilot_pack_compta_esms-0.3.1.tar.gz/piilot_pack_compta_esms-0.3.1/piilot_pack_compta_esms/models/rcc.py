"""Tableau Rcc — Répartition Charges Communes (§N, L2 §16.5-§16.7).

Onglet Annexe 8 + Annexe 1 — répartition des charges mutualisées
entre CR (25-deepdive §9, D-092).

Structure : pour chaque compte M22Bis on alloue le ``montant_total``
en pourcentages distribués sur N CR cibles. La règle métier dure
(**D-092**) est ``Σ(% par CR) = 100%`` sur chaque ligne — validée
côté ``:validate`` (Q7, tolérance 0.01).

``repartition_json`` est un mapping ``cr_id (UUID) → {pct, montant}``
côté DB (DDL §D.9 ligne 599 = JSONB). Pydantic le valide en
:class:`dict[UUID, RccRepartitionEntry]`. La somme ``Σ pct`` n'est
PAS validée par Pydantic — c'est fait côté service pour pouvoir
retourner un rapport ligne par ligne avec écarts détaillés.

Lignes spéciales (25-deepdive §9 sub-lines 38-41) :

* ``is_frais_siege=True`` → frais de siège
* ``is_quote_part_commune=True`` → quotes-parts opérations communes
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from piilot_pack_compta_esms.services.validators import reject_pipe_char


class RccRepartitionEntry(BaseModel):
    """Une entrée du mapping ``repartition_json`` : pour un CR donné,
    le pourcentage alloué + le montant calculé.

    ``pct`` : 0-100 (pas 0-1). ``montant`` : peut être calculé côté
    UI ``montant_total * pct / 100`` mais on l'accepte tel quel pour
    laisser le client gérer les arrondis."""

    model_config = ConfigDict(extra="forbid")

    pct: Decimal = Field(..., ge=0, le=100)
    montant: Decimal


# ---------------------------------------------------------------------------
# Create / Bulk
# ---------------------------------------------------------------------------


class RccLigneCreate(BaseModel):
    """Item du bulk-upsert RCC."""

    model_config = ConfigDict(extra="forbid")

    compte_m22bis: str = Field(..., min_length=1, max_length=32)
    libelle: str | None = Field(default=None, max_length=255)
    montant_total: Decimal | None = None
    cle_repartition: str | None = Field(default=None, max_length=255)
    repartition: dict[UUID, RccRepartitionEntry] = Field(default_factory=dict)
    """Mapping CR_id → {pct, montant}. Validation Σ pct = 100 faite
    côté ``:validate`` (Q7), pas Pydantic."""
    is_frais_siege: bool = False
    is_quote_part_commune: bool = False

    # D-075 — pipe char interdit dans libellé + clé répartition
    _no_pipe = field_validator("libelle", "cle_repartition")(reject_pipe_char)


class RccBulkUpsertRequest(BaseModel):
    """Body de ``POST /documents/{doc_id}/rcc:bulk-upsert``.

    Sémantique Q5 : **replace_all_by_document** (cohérence §M)."""

    model_config = ConfigDict(extra="forbid")

    items: list[RccLigneCreate] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------


class RccLigneRead(BaseModel):
    """Row complet de ``compta_esms.rcc_lignes``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    compte_m22bis: str
    libelle: str | None
    montant_total: Decimal | None
    cle_repartition: str | None
    repartition: dict[UUID, RccRepartitionEntry]
    is_frais_siege: bool
    is_quote_part_commune: bool
    created_at: datetime
    updated_at: datetime


class RccResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/rcc``."""

    model_config = ConfigDict(extra="forbid")

    items: list[RccLigneRead]


# ---------------------------------------------------------------------------
# Validate (Q7 — Σ%=100% par ligne, D-092, tolérance 0.01)
# ---------------------------------------------------------------------------


class RccLigneValidation(BaseModel):
    """Verdict de validation pour une ligne RCC.

    ``ecart = somme_pct - 100``. ``valide`` ssi ``|ecart| <= 0.01``."""

    model_config = ConfigDict(extra="forbid")

    rcc_ligne_id: UUID
    compte_m22bis: str
    somme_pct: Decimal
    ecart: Decimal
    valide: bool


class RccValidateResponse(BaseModel):
    """Body de ``POST /documents/{doc_id}/rcc:validate``.

    D-092 — Σ(% par CR) = 100% sur chaque ligne. ``valide_globalement``
    = toutes les lignes équilibrées."""

    model_config = ConfigDict(extra="forbid")

    lignes: list[RccLigneValidation]
    valide_globalement: bool
    tolerance_appliquee: Decimal
