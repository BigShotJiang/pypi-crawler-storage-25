"""Emprunts ESSMS privés / Dettes financières publics (§N, L2 §16.3-§16.4).

**9 onglets** (D-093, 25-deepdive §11) :

* ``emprunts_prives`` (1 onglet) — Emprunts ESSMS privés >1 an
* ``dettes_financieres_publics_1..._8`` (8 onglets) — Dettes
  financières ESSMS publics, 1 type par onglet

Pas de variante DDL — la **même table** ``emprunts_dettes`` accommode
les 9 cas via la colonne ``type_dette`` (CHECK DDL §D.9 ligne 564).

Sémantique bulk-upsert Q4 : **replace_by_document_and_type_dette**
— précédent §K Bilan PC/PNL coexistants (pas §M replace_all). Le
payload inclut ``type_dette`` au top-level. Save d'un onglet ne touche
que cet onglet (sinon le builder devrait re-soumettre les 9 onglets
à chaque modif).

GET supporte ``?type_dette=`` (L2 §16.3, optionnel) :

* Fourni → items + totals filtrés sur ce type_dette uniquement
* Omis → tous les items, totals breakdown par type_dette

``totals`` sont **inclus dans GET** (Q6).
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from piilot_pack_compta_esms.services.validators import reject_pipe_char

TypeDette = Literal[
    "emprunts_prives",
    "dettes_financieres_publics_1",
    "dettes_financieres_publics_2",
    "dettes_financieres_publics_3",
    "dettes_financieres_publics_4",
    "dettes_financieres_publics_5",
    "dettes_financieres_publics_6",
    "dettes_financieres_publics_7",
    "dettes_financieres_publics_8",
]
"""DDL §D.9 ligne 564 — CHECK constraint sur 9 valeurs (D-093)."""


# ---------------------------------------------------------------------------
# Create / Bulk
# ---------------------------------------------------------------------------


class EmpruntCreate(BaseModel):
    """Item du bulk-upsert. ``type_dette`` n'est PAS dans l'item — il
    vient du payload top-level (:class:`EmpruntsBulkUpsertRequest`)
    parce qu'un bulk-upsert ne touche qu'un seul type_dette."""

    model_config = ConfigDict(extra="forbid")

    libelle: str | None = Field(default=None, max_length=255)
    capital_emprunte: Decimal | None = None
    taux: Decimal | None = Field(default=None, ge=0, le=100)
    """Taux en %, ex ``2.5`` pour 2,5%."""
    duree_annees: int | None = Field(default=None, ge=0, le=100)
    date_debut: date | None = None
    capital_rembourse_n1: Decimal | None = None
    capital_rembourse_n: Decimal | None = None
    interets_n1: Decimal | None = None
    interets_n: Decimal | None = None
    solde_restant_du: Decimal | None = None

    # D-075 — pipe char interdit dans le libellé
    _no_pipe = field_validator("libelle")(reject_pipe_char)


class EmpruntsBulkUpsertRequest(BaseModel):
    """Body de ``POST /documents/{doc_id}/emprunts:bulk-upsert``.

    Sémantique Q4 : **replace_by_document_and_type_dette** — DELETE
    WHERE doc AND type_dette + INSERT batch atomique."""

    model_config = ConfigDict(extra="forbid")

    type_dette: TypeDette
    items: list[EmpruntCreate] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------


class EmpruntRead(BaseModel):
    """Row complet de ``compta_esms.emprunts_dettes``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    type_dette: TypeDette
    libelle: str | None
    capital_emprunte: Decimal | None
    taux: Decimal | None
    duree_annees: int | None
    date_debut: date | None
    capital_rembourse_n1: Decimal | None
    capital_rembourse_n: Decimal | None
    interets_n1: Decimal | None
    interets_n: Decimal | None
    solde_restant_du: Decimal | None
    created_at: datetime
    updated_at: datetime


# ---------------------------------------------------------------------------
# Totals (Q6 — inclus dans GET)
# ---------------------------------------------------------------------------


class EmpruntsMontants(BaseModel):
    """5 colonnes monétaires agrégées (n1 + n + interets + solde)."""

    model_config = ConfigDict(extra="forbid")

    capital_emprunte_total: Decimal
    capital_rembourse_n1_total: Decimal
    capital_rembourse_n_total: Decimal
    interets_n1_total: Decimal
    interets_n_total: Decimal
    solde_restant_du_total: Decimal


class EmpruntsTypeDetteTotals(BaseModel):
    """Sous-total par type_dette."""

    model_config = ConfigDict(extra="forbid")

    type_dette: TypeDette
    nb_lignes: int
    montants: EmpruntsMontants


class EmpruntsTotals(BaseModel):
    """Totaux emprunts — by_type_dette + total général.

    ``by_type_dette`` contient 1 entrée si filtré, jusqu'à 9 sinon."""

    model_config = ConfigDict(extra="forbid")

    by_type_dette: list[EmpruntsTypeDetteTotals]
    total_general: EmpruntsMontants


class EmpruntsResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/emprunts``.

    ``type_dette_filtre`` est ``None`` si le client n'a pas filtré,
    sinon la valeur demandée."""

    model_config = ConfigDict(extra="forbid")

    type_dette_filtre: TypeDette | None
    items: list[EmpruntRead]
    totals: EmpruntsTotals
