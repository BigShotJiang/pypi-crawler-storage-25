"""Balance import Pydantic models (D-108).

A ``balance_imports`` row tracks one upload of a cabinet balance,
from upload to apply-mapping / KB materialisation. The §F.3 endpoints
deal with the early phase : upload, column detection, preview.
Application + materialisation live in §F.5.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

ImportStatus = Literal["pending", "completed", "failed", "partial"]

SourcePlan = Literal["PCG", "M14", "M21", "M22Bis", "Sage", "EBP", "Cegid", "Pennylane", "custom"]

# Role keys we accept in ``column_detection`` and in user-supplied
# hints. Mirror of :data:`balance_file_parser.ROLE_TOKENS` so the
# OpenAPI schema documents the contract.
ROLE_KEYS = ("compte", "libelle", "debit", "credit", "solde", "periode")


class ColumnDetection(BaseModel):
    """``balance_imports.column_detection`` payload — role → 0-based
    column index (or None when no column matches that role)."""

    model_config = ConfigDict(extra="forbid")

    compte: int | None = Field(default=None, ge=0)
    libelle: int | None = Field(default=None, ge=0)
    debit: int | None = Field(default=None, ge=0)
    credit: int | None = Field(default=None, ge=0)
    solde: int | None = Field(default=None, ge=0)
    periode: int | None = Field(default=None, ge=0)


class ColumnHints(BaseModel):
    """Body of ``POST /balance-imports/{id}/detect-columns``.

    All fields optional — a hint with value ``None`` means "unset
    this role" (e.g. cabinet wants to ignore the ``solde`` column
    because the balance only carries debit/credit)."""

    model_config = ConfigDict(extra="forbid")

    compte: int | None = Field(default=None, ge=0)
    libelle: int | None = Field(default=None, ge=0)
    debit: int | None = Field(default=None, ge=0)
    credit: int | None = Field(default=None, ge=0)
    solde: int | None = Field(default=None, ge=0)
    periode: int | None = Field(default=None, ge=0)


class BalanceImportRead(BaseModel):
    """Body of ``GET /balance-imports/{id}`` — full DB row."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    exercice_id: UUID | None
    etablissement_id: UUID | None
    source_plan: SourcePlan
    source_filename: str | None
    source_storage_key: str | None
    periode_label: str
    nb_lignes_source: int
    nb_lignes_mappees: int
    nb_lignes_non_mappees: int
    column_detection: dict[str, int | None]
    preview_data: dict[str, Any]  # {header: [...], rows: [[...]]}
    suggestions: list[dict[str, Any]] = Field(default_factory=list)
    unmapped_accounts: list[dict[str, Any]] = Field(default_factory=list)
    applied_at: datetime | None = None
    mapping_snapshot: dict[str, Any]
    materialized_kb_id: UUID | None
    materialized_kb_table_name: str | None
    status: ImportStatus
    error_payload: dict[str, Any]
    imported_by_user_id: UUID
    imported_at: datetime
    created_at: datetime
    updated_at: datetime


class BalanceImportPreview(BaseModel):
    """Body of ``GET /balance-imports/{id}/preview``.

    Pulls only the 3 fields the frontend's step-2 table needs ; the
    full ``BalanceImportRead`` is overkill here."""

    model_config = ConfigDict(extra="forbid")

    header: list[str]
    rows: list[list[Any]]
    column_detection: dict[str, int | None]


BalanceImport = BalanceImportRead
