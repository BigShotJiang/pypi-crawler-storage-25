"""CPOM Pydantic models — §BA v0.3 (D-027, KB B.3/B.4/B.5).

A CPOM (Contrat Pluriannuel d'Objectifs et de Moyens) is signed
between one Organisme Gestionnaire and one or more Autorités de
Tarification (ARS, Conseil Départemental, ou les deux en tripartite).
Cardinality: **1 OG × N ESMS** (cf. Q4 — pas multi-OG).

Three entities live here :

* :class:`Cpom*`        — the contract itself
* :class:`CpomEsmsLink*` — N:N relation between a CPOM and the OG's
  établissements ; carries ``inclus_dans_perimetre`` to model the
  S03 p.10-11 case where an ESMS is referenced without being in the
  tarifaire perimeter (e.g. partial conventions).
* :class:`CpomObjectif*` — objectives declared in the CPOM, with an
  ``impact_eprd_o_n`` flag used by §AC DOCX export.

All enum-like fields use ``Literal`` (rejected at parse time + visible
in the OpenAPI schema).
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from piilot_pack_compta_esms.services.validators import reject_pipe_char

# --------------------------------------------------------------------
# Allowed value sets — mirror the DB CHECK constraints (migration 019).
# --------------------------------------------------------------------

CpomCategorie = Literal[
    "EHPAD_IVTER",
    "ESMS_PH_SSIAD",
    "RESIDENCE_AUTONOMIE",
    "EHPAD_PUV",
    "MIXTE",
]
"""S03 p.9-10. ``EHPAD_IVTER`` (L.313-12 IV ter) = libre affectation des
résultats par le gestionnaire (D-082 variant Public_II / Prive_II)."""

CpomCosignataire = Literal["ARS", "CD", "ARS_CD_TRIPARTITE"]
"""S03 p.9. Stocké en TEXT[] côté DB — l'API expose ``list[Literal]``."""

OuiNon = Literal["OUI", "NON"]
"""Réutilisé par ``est_proroge``, ``libre_affectation_resultats_o_n``,
``inclus_dans_perimetre``, ``impact_eprd_o_n``."""

CpomObjectifStatut = Literal["PREVU", "EN_COURS", "REALISE", "ABANDONNE"]
"""KB B.5. NULL toléré côté DB (objectif non encore initié)."""


# --------------------------------------------------------------------
# CPOM
# --------------------------------------------------------------------


class CpomBase(BaseModel):
    """Shared fields between Create / Update / Read.

    ``date_fin_theorique`` est **calculé par le service**
    (``cpom_service.compute_date_fin_theorique``) à partir de
    ``date_effet + duree_annees`` — pas exposé au client.
    """

    # ``extra='forbid'`` only — pas de strict=True (laisser JSON →
    # UUID/date coercion FastAPI faire son travail).
    model_config = ConfigDict(extra="forbid")

    og_id: UUID = Field(..., description="OG signataire (FK)")
    numero: str | None = Field(
        default=None,
        max_length=100,
        description="Identifiant interne ARS du contrat (optionnel)",
    )
    date_signature: date = Field(..., description="Date de signature du CPOM")
    date_effet: date = Field(
        ...,
        description=(
            "Date d'effet — peut être antérieure à date_signature " "(effet rétroactif S03 p.8)."
        ),
    )
    duree_annees: Decimal = Field(
        ...,
        ge=Decimal("1.0"),
        le=Decimal("7.0"),
        description=(
            "Durée signée en années (1.0 à 7.0). NUMERIC pour autoriser "
            "les CPOM PUV prolongés +1 an sans avenant — S03 p.9."
        ),
    )
    categorie: CpomCategorie
    cosignataires: list[CpomCosignataire] = Field(
        ...,
        min_length=1,
        description="Autorités cosignataires (au moins 1). S03 p.9.",
    )
    est_proroge: OuiNon | None = Field(
        default=None,
        description="Drapeau prorogation (PUV +1 an — S03 p.9).",
    )
    motif_prorogation: str | None = Field(
        default=None,
        max_length=500,
        description="Motif libre de la prorogation (optionnel).",
    )
    libre_affectation_resultats_o_n: OuiNon = Field(
        ...,
        description=(
            "OUI pour EHPAD IVter (art. L.313-12), NON sinon. "
            "Détermine la variante Affectation §K (D-082)."
        ),
    )

    # D-075 — pipe char interdit dans les champs de saisie libre.
    _no_pipe = field_validator("numero", "motif_prorogation")(reject_pipe_char)

    @model_validator(mode="after")
    def _validate_cosignataires_unique(self) -> CpomBase:
        """Les cosignataires doivent être uniques (pas de doublon ARS,ARS)."""
        if len(self.cosignataires) != len(set(self.cosignataires)):
            raise ValueError("cosignataires must be unique")
        return self


class CpomCreate(CpomBase):
    """Body of ``POST /og/{og_id}/cpoms`` — ``og_id`` from path is
    matched against the body's ``og_id`` by the route handler."""


class CpomUpdate(BaseModel):
    """Body of ``PATCH /cpoms/{cpom_id}``.

    ``og_id`` is **not** mutable — re-parenting a CPOM would break the
    link rows (cpom_esms_link.etablissement_id might no longer belong
    to the new OG). To "move" a CPOM, delete + recreate.
    """

    model_config = ConfigDict(extra="forbid")

    numero: str | None = Field(default=None, max_length=100)
    date_signature: date | None = None
    date_effet: date | None = None
    duree_annees: Decimal | None = Field(default=None, ge=Decimal("1.0"), le=Decimal("7.0"))
    categorie: CpomCategorie | None = None
    cosignataires: list[CpomCosignataire] | None = Field(default=None, min_length=1)
    est_proroge: OuiNon | None = None
    motif_prorogation: str | None = Field(default=None, max_length=500)
    libre_affectation_resultats_o_n: OuiNon | None = None

    _no_pipe = field_validator("numero", "motif_prorogation")(reject_pipe_char)

    @model_validator(mode="after")
    def _validate_cosignataires_unique(self) -> CpomUpdate:
        if self.cosignataires is not None and len(self.cosignataires) != len(
            set(self.cosignataires)
        ):
            raise ValueError("cosignataires must be unique")
        return self


class CpomRead(CpomBase):
    """Body of ``GET /cpoms/{cpom_id}`` — full DB row."""

    id: UUID
    company_id: UUID
    date_fin_theorique: date = Field(
        ...,
        description=("Date de fin calculée par le service " "(date_effet + duree_annees)."),
    )
    created_at: datetime
    updated_at: datetime


Cpom = CpomRead


# --------------------------------------------------------------------
# CPOM ↔ ESMS link  (N:N)
# --------------------------------------------------------------------


class CpomEsmsLinkItem(BaseModel):
    """Element of the ``POST /cpoms/{cpom_id}/etablissements:bulk-link`` body.

    ``inclus_dans_perimetre`` is required — distinguishes ESMS sous
    périmètre tarifaire CPOM (OUI) vs ESMS référencés mais hors
    périmètre (NON) — S03 p.10-11.
    """

    model_config = ConfigDict(extra="forbid")

    etablissement_id: UUID
    inclus_dans_perimetre: OuiNon


class CpomEsmsLinkRead(BaseModel):
    """Body of ``GET /cpoms/{cpom_id}/etablissements``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    cpom_id: UUID
    etablissement_id: UUID
    inclus_dans_perimetre: OuiNon
    created_at: datetime
    updated_at: datetime


# --------------------------------------------------------------------
# CPOM Objectif
# --------------------------------------------------------------------


class CpomObjectifBase(BaseModel):
    """Shared fields between Create / Update / Read."""

    model_config = ConfigDict(extra="forbid")

    intitule: str = Field(..., min_length=1, max_length=500)
    impact_eprd_o_n: OuiNon = Field(
        ...,
        description=(
            "OUI = l'objectif doit apparaître dans le DOCX §AC rapport " "budgétaire EPRD (KB B.5)."
        ),
    )
    description: str | None = Field(default=None, max_length=2000)
    date_realisation_prevue: date | None = None
    statut: CpomObjectifStatut | None = Field(
        default=None,
        description="NULL toléré pour objectif non encore initié.",
    )

    _no_pipe = field_validator("intitule", "description")(reject_pipe_char)


class CpomObjectifCreate(CpomObjectifBase):
    """Body of ``POST /cpoms/{cpom_id}/objectifs`` — ``cpom_id`` from path."""


class CpomObjectifUpdate(BaseModel):
    """Body of ``PATCH /cpoms/{cpom_id}/objectifs/{obj_id}``."""

    model_config = ConfigDict(extra="forbid")

    intitule: str | None = Field(default=None, min_length=1, max_length=500)
    impact_eprd_o_n: OuiNon | None = None
    description: str | None = Field(default=None, max_length=2000)
    date_realisation_prevue: date | None = None
    statut: CpomObjectifStatut | None = None

    _no_pipe = field_validator("intitule", "description")(reject_pipe_char)


class CpomObjectifRead(CpomObjectifBase):
    """Body of ``GET /cpoms/{cpom_id}/objectifs/{obj_id}``."""

    id: UUID
    company_id: UUID
    cpom_id: UUID
    created_at: datetime
    updated_at: datetime


CpomObjectif = CpomObjectifRead


# --------------------------------------------------------------------
# Reporting
# --------------------------------------------------------------------


class CpomProgress(BaseModel):
    """Returned by ``GET /cpoms/{cpom_id}/progress``.

    Aggregated objectives status — used by the dashboard tab "Avancement"
    of ``CpomModuleView``.
    """

    model_config = ConfigDict(extra="forbid")

    cpom_id: UUID
    total: int = Field(..., ge=0)
    prevus: int = Field(..., ge=0)
    en_cours: int = Field(..., ge=0)
    realises: int = Field(..., ge=0)
    abandonnes: int = Field(..., ge=0)
    sans_statut: int = Field(..., ge=0, description="Objectifs avec statut NULL")
    ratio_realise: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="realises / total (0.0 si total == 0)",
    )
