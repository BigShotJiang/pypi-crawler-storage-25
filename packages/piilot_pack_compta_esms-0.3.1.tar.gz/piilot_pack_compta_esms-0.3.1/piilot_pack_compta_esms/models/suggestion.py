"""Suggestion pipeline Pydantic models (§F.4 — D-108)."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

SuggestionOrigin = Literal["pcg_to_m22bis_kb", "preset", "llm", "manual"]


class SuggestionTarget(BaseModel):
    """One target row inside a :class:`SourceAccountSuggestion`.

    A source account that maps 1:N has several targets, each with its
    own weight ; the 1:1 case is the same shape with a single target
    at ``weight=1.0``."""

    model_config = ConfigDict(extra="forbid")

    target_m22bis_account: str = Field(..., min_length=1, max_length=50)
    weight: float = Field(default=1.0, gt=0, le=1.0)
    confidence: float = Field(..., ge=0, le=1.0)
    origin: SuggestionOrigin


class SourceAccountSuggestion(BaseModel):
    """A complete suggestion bundle for one source account.

    Empty ``targets`` = no tier produced a match. The cabinet handles
    that case manually in the assistant UI."""

    model_config = ConfigDict(extra="forbid")

    source_account: str
    label_hint: str | None = None
    targets: list[SuggestionTarget] = Field(default_factory=list)


class SuggestRequest(BaseModel):
    """Body of ``POST .../suggest-mappings`` (L2 §7bis.2.1)."""

    model_config = ConfigDict(extra="forbid")

    include_llm: bool = Field(
        default=False,
        description=(
            "Run the LLM tier on accounts the KB + preset tiers leave "
            "unmapped. Stubbed in v0.2 — returns no LLM rows until the "
            "SDK exposes a get_company_llm() primitive."
        ),
    )
    llm_threshold: float = Field(default=0.7, ge=0, le=1.0)
    source_plan: str | None = Field(
        default=None,
        description=(
            "Override the balance import's stored source_plan. Useful "
            "when the same file is re-imported as a different outil "
            "(eg. raw Pennylane re-tagged as PCG generic)."
        ),
    )


class AcceptAboveRequest(BaseModel):
    """Body of ``POST .../suggestions:accept-all-above`` (L2 §7bis.2.3)."""

    model_config = ConfigDict(extra="forbid")

    confidence_threshold: float = Field(..., ge=0, le=1.0)
