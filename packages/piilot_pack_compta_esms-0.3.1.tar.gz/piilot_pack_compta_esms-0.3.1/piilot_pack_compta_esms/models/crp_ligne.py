"""CRP ligne Pydantic models (L2 §6, §H).

One row per ``(cr_id, groupe, nature, compte_m22bis)`` — enforced by
migration 009. The model carries :

* the natural key columns (``cr_id`` is on the path),
* five **EPRD/ERRD montants** (budget_initial, virements_credits,
  decisions_modif, previsions_totales, realise),
* four **H/D/S/SEA** columns that §H leaves NULL — they are populated
  later by §T (CRP analytique EHPAD) via the
  ``cles_repartition_charges_communes`` keys + the D-109 hard rules
  (compte 65 → 100% H, compte 66 → 100% S). §H still **accepts** them
  on PATCH so an admin can override the calculated split manually.
* **binding_id** : non-NULL when the row was produced by
  ``:prefill-from-binding``. PATCHing such a row auto-flips
  ``override_balance`` (Q6).
* **override_balance** : when true, ``:prefill-from-binding`` skips the
  row — the cabinet's manual edit is preserved across binding replays.

``compte_m22bis`` is TEXT (no FK on the dynamic ``kbs_reference.*``
table). Validation is permissive (fail-open) via
:func:`reference_lookup.compte_m22bis_exists` — see §H.4 and the
service layer.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from piilot_pack_compta_esms.services.validators import reject_pipe_char

Groupe = Literal["G1", "G2", "G3"]
"""L1 CHECK : G1 (exploitation courante) / G2 (personnel) / G3 (structure)."""

Nature = Literal["charge", "produit"]
"""L1 CHECK : charge vs produit. The contract `crp_charges_g{1,2,3}` is
nature=charge ; `crp_produits` is nature=produit."""

MontantColumn = Literal[
    "montant_budget_initial",
    "montant_virements_credits",
    "montant_decisions_modif",
    "montant_previsions_totales",
    "montant_realise",
]
"""The five montant columns the cabinet can target via
``:prefill-from-binding`` (Q3 explicit — no auto-deduction)."""


class CrpLigneCreate(BaseModel):
    """Body of ``POST /crs/{cr_id}/lignes``.

    All montants are optional — a fresh line can be created with just
    the natural key (groupe + nature + compte_m22bis) and montants
    filled later via PATCH or via a binding prefill.

    H/D/S/SEA are accepted at create time too (Q2 hybrid : §H ignores
    them by default but accepts override on input).
    """

    model_config = ConfigDict(extra="forbid")

    groupe: Groupe
    nature: Nature
    compte_m22bis: str = Field(..., min_length=1, max_length=32)
    compte_label: str | None = Field(default=None, max_length=255)
    # EPRD prévisionnel
    montant_budget_initial: Decimal | None = None
    montant_virements_credits: Decimal | None = None
    montant_decisions_modif: Decimal | None = None
    montant_previsions_totales: Decimal | None = None
    # ERRD réalisé
    montant_realise: Decimal | None = None
    # Ventilation analytique (§T) — admis en saisie manuelle aussi
    montant_hebergement: Decimal | None = None
    montant_dependance: Decimal | None = None
    montant_soins: Decimal | None = None
    montant_soins_autonomie: Decimal | None = None
    # Méta
    saisie_manuelle: bool = True
    notes: str | None = None

    # D-075 — pipe char interdit dans les libellés/notes
    _no_pipe = field_validator("compte_label", "notes")(reject_pipe_char)


class CrpLigneUpdate(BaseModel):
    """Body of ``PATCH /lignes/{ligne_id}``.

    The natural key ``(groupe, nature, compte_m22bis)`` is **not**
    mutable — changing it would orphan the row's binding linkage.
    Switch the type by deleting + re-creating.

    ``override_reason`` is captured on a patch of a binding-sourced
    row to explain *why* the cabinet overrode the auto value (audit
    trail). The auto-flip of ``override_balance`` happens in the
    service layer (Q6).
    """

    model_config = ConfigDict(extra="forbid")

    compte_label: str | None = None
    montant_budget_initial: Decimal | None = None
    montant_virements_credits: Decimal | None = None
    montant_decisions_modif: Decimal | None = None
    montant_previsions_totales: Decimal | None = None
    montant_realise: Decimal | None = None
    montant_hebergement: Decimal | None = None
    montant_dependance: Decimal | None = None
    montant_soins: Decimal | None = None
    montant_soins_autonomie: Decimal | None = None
    notes: str | None = None
    override_reason: str | None = None

    # D-075 — pipe char interdit dans les libellés/notes/reason
    _no_pipe = field_validator("compte_label", "notes", "override_reason")(reject_pipe_char)


class CrpLigneRead(BaseModel):
    """Body of ``GET /lignes/{ligne_id}`` — full row."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    cr_id: UUID
    groupe: Groupe
    nature: Nature
    compte_m22bis: str
    compte_label: str | None
    montant_budget_initial: Decimal | None
    montant_virements_credits: Decimal | None
    montant_decisions_modif: Decimal | None
    montant_previsions_totales: Decimal | None
    montant_realise: Decimal | None
    montant_hebergement: Decimal | None
    montant_dependance: Decimal | None
    montant_soins: Decimal | None
    montant_soins_autonomie: Decimal | None
    binding_id: UUID | None
    saisie_manuelle: bool
    override_balance: bool
    override_reason: str | None
    override_at: datetime | None
    notes: str | None
    created_at: datetime
    updated_at: datetime


class BulkUpsertItem(BaseModel):
    """One item of ``POST /crs/{cr_id}/lignes:bulk-upsert``.

    The bulk takes a list of these. If ``id`` is set we update that
    specific row by primary key ; if absent we upsert by natural key
    ``(cr_id, groupe, nature, compte_m22bis)`` (ON CONFLICT DO UPDATE).
    Either path preserves ``notes``/``override_*``/``binding_id`` if
    those keys are omitted (Q4 — COALESCE in the repo).
    """

    model_config = ConfigDict(extra="forbid")

    id: UUID | None = None
    groupe: Groupe
    nature: Nature
    compte_m22bis: str = Field(..., min_length=1, max_length=32)
    compte_label: str | None = Field(default=None, max_length=255)
    montant_budget_initial: Decimal | None = None
    montant_virements_credits: Decimal | None = None
    montant_decisions_modif: Decimal | None = None
    montant_previsions_totales: Decimal | None = None
    montant_realise: Decimal | None = None
    montant_hebergement: Decimal | None = None
    montant_dependance: Decimal | None = None
    montant_soins: Decimal | None = None
    montant_soins_autonomie: Decimal | None = None
    notes: str | None = None

    # D-075 — pipe char interdit dans les libellés/notes
    _no_pipe = field_validator("compte_label", "notes")(reject_pipe_char)


class PrefillFromBindingRequest(BaseModel):
    """Body of ``POST /crs/{cr_id}/lignes:prefill-from-binding``.

    ``target_column`` is **required** (Q3 explicit) — the backend does
    not auto-deduce from doc_type. The UI proposes a default
    (``montant_realise`` for ERRD, ``montant_budget_initial`` for EPRD)
    but the cabinet sees and confirms the choice. Prevents the
    surprise of "I clicked prefill on an EPRD and it filled my
    realised column".

    Lignes with ``override_balance=true`` are skipped — the response
    reports the skip count per feature.
    """

    model_config = ConfigDict(extra="forbid")

    feature_keys: list[str] = Field(..., min_length=1)
    target_column: MontantColumn


class PrefillFeatureResult(BaseModel):
    """One element of :class:`PrefillFromBindingResponse.results`."""

    model_config = ConfigDict(extra="forbid")

    feature_key: str
    inserted: int
    updated: int
    skipped_overridden: int


class PrefillFromBindingResponse(BaseModel):
    """Body of ``POST .../lignes:prefill-from-binding`` — per-feature
    counters + the target column that was actually used (echoed back
    for the UI's "filled into <column>" confirmation banner)."""

    model_config = ConfigDict(extra="forbid")

    target_column: MontantColumn
    results: list[PrefillFeatureResult]


class CrpTotalsColumnPair(BaseModel):
    """One ``{previsions_totales, realise}`` pair — used in
    :class:`CrpTotalsResponse` everywhere we report a pair of
    EPRD/ERRD numbers."""

    model_config = ConfigDict(extra="forbid")

    previsions_totales: Decimal
    realise: Decimal


class CrpTotalsGroupe(BaseModel):
    """Charges + produits totals for one groupe."""

    model_config = ConfigDict(extra="forbid")

    charges: CrpTotalsColumnPair
    produits: CrpTotalsColumnPair


class CrpEcart(BaseModel):
    """Brut écart (``produits - charges``). Validation R.314-222 (5
    conditions, D-016 + D-034) is **not** done here — it lives in §I
    (calculs financiers transverses). This field is just the raw
    arithmetic result so the UI can colour it green/red.
    """

    model_config = ConfigDict(extra="forbid")

    previsions_totales: Decimal
    realise: Decimal
    is_equilibre_required: bool


class CrpTotalsResponse(BaseModel):
    """Body of ``GET /crs/{cr_id}/totals``.

    Flat shape (Q5) : groupes side-by-side, totals at top level, ecart
    last. Only two montant columns are reported (``previsions_totales``
    + ``realise``) — the intermediate EPRD columns
    (``budget_initial``/``virements``/``decisions_modif``) stay
    visible row-by-row but are summed implicitly into
    ``previsions_totales``.
    """

    model_config = ConfigDict(extra="forbid")

    cr_id: UUID
    cr_variante: Literal["soumis_equilibre", "non_soumis_equil"]
    by_groupe: dict[Literal["G1", "G2", "G3"], CrpTotalsGroupe]
    total_charges: CrpTotalsColumnPair
    total_produits: CrpTotalsColumnPair
    ecart: CrpEcart
