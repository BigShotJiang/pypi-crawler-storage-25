"""Pydantic models for §I — calculs financiers transverses.

All services in :mod:`piilot_pack_compta_esms.services.finance` are
pure : they take a typed input dataclass and return a typed result
dataclass. No I/O, no DB access, no async. The caller (`§K Bilan`,
`§M TF`, `§P PGFP`, `§X workflow transitions`) is responsible for
collecting the inputs and persisting / acting on the results.

Why dataclasses and not direct dicts : Pydantic gives us free input
validation (Decimal coercion, ``extra='forbid'`` for typos) and the
same models are reusable when the calling routes get added in §K/§M/§P.

Sources spec (citées dans chaque docstring) :

* `knowledge-base/07-formules-metier.md` — index F.EQ / F.IND / F.ETP /
  F.DEP / F.GIR
* `S03` FAQ DGCS p.18-22 (forfait dépendance, point GIR)
* `S03` FAQ DGCS p.29 (équilibre réel — R.314-222 5 conditions)
* `S01` / `S02` (CAF, FRNG, BFR, Trésorerie, marge brute)
"""

from __future__ import annotations

from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

Section = Literal["H", "D", "S", "SEA"]
"""Sections analytiques EHPAD (D-083 + D-085). H = Hébergement, D =
Dépendance, S = Soins, SEA = Soins et Entretien Autonomie (expérimentation
2026, fusionne S + un volet "entretien autonomie")."""

NatureJuridique = Literal[
    "ETABLISSEMENT_PUBLIC_SANTE",
    "ESMS_PUBLIC_AUTONOME",
    "CCAS_CIAS_COLLECTIVITE",
    "PRIVE_NON_LUCRATIF",
    "PRIVE_COMMERCIAL",
]
"""D-017 — 5 natures juridiques qui changent la structure de l'EPRD.
Le validator d'équilibre s'en sert pour choisir entre `reel` (CPOM)
et `strict` (hors CPOM)."""

EquilibreType = Literal["reel", "strict", "financier"]
"""D-016 — 3 notions d'équilibre. `reel` = R.314-222 5 conditions (CPOM).
`strict` = recettes == dépenses (hors CPOM). `financier` = équilibre
bilan (R.314-225, livré §K plus tard, exposé ici pour cohérence)."""

SanteIndicateur = Literal["sain", "attention", "alerte", "critique"]
"""Codes santé renvoyés par les calculators FRNG/BFR/Trésorerie/CAF/Marge
brute. Seuils dans chaque service."""


# ---------------------------------------------------------------------------
# F.EQ.01 — Équilibre réel R.314-222 (5 conditions)
# ---------------------------------------------------------------------------


class EquilibreReelInput(BaseModel):
    """Inputs pour les 5 conditions de l'équilibre réel R.314-222.

    Le caller (§X transitions) collecte ces valeurs depuis :
    - condition 1 : ``crp_lignes`` (§H) + saisie manuelle des produits notifiés
    - condition 2 : qualitatif — saisie de ``commentaires_sincerite`` côté UI
    - condition 3 : ``tf_lignes`` (§M) côté financement emprunts
    - condition 4 : CAF calculée (§I.4) + ``emprunts_dettes`` (§N) capital N
    - condition 5 : ``affectations_resultats`` (§J) + suivi affectations

    Les champs optionnels (``None``) correspondent à des inputs non
    encore disponibles à l'instant T — la condition correspondante
    sera marquée ``evaluable=false`` dans le résultat.
    """

    model_config = ConfigDict(extra="forbid")

    # Condition 1
    produits_tarif_saisis: Decimal | None = None
    produits_tarif_notifies: Decimal | None = None
    # Condition 2 — qualitatif : True si le cabinet a fourni des commentaires
    # justifiant les écarts > seuil. False = warning. None = pas encore évalué.
    sincerite_commentee: bool | None = None
    # Condition 3 — capital remboursé via produit emprunt (devrait être <= 0)
    capital_rembourse_via_emprunt: Decimal | None = None
    # Condition 4
    caf_n: Decimal | None = None
    capital_a_rembourser_n: Decimal | None = None
    # Condition 5
    recettes_affectees: Decimal | None = None
    recettes_affectees_utilisees: Decimal | None = None


class ConditionResult(BaseModel):
    """Un des 5 verdicts de l'équilibre réel."""

    model_config = ConfigDict(extra="forbid")

    id: int = Field(..., ge=1, le=5)
    label: str
    passed: bool
    evaluable: bool
    message: str


class EquilibreReelResult(BaseModel):
    """Verdict global équilibre réel.

    ``equilibre`` vrai uniquement si **toutes** les conditions
    évaluables sont passées **ET** chaque condition est évaluable.
    Un input partiel (par ex. CAF non saisie) laisse
    ``evaluable_globalement=false`` — le caller bloque la transition
    `BROUILLON → TRANSMIS` (D-034) tant que tout n'est pas évalué.
    """

    model_config = ConfigDict(extra="forbid")

    conditions: list[ConditionResult]
    nb_evaluables: int
    nb_passees: int
    evaluable_globalement: bool
    equilibre: bool


# ---------------------------------------------------------------------------
# F.EQ.02 — Équilibre strict (hors CPOM)
# ---------------------------------------------------------------------------


class EquilibreStrictInput(BaseModel):
    """Inputs pour l'équilibre strict : recettes vs dépenses.

    Tolérance arrondi : 0,01 € (S03 p.29 — "à 0 € près, tolérance
    arrondis").
    """

    model_config = ConfigDict(extra="forbid")

    total_recettes: Decimal
    total_depenses: Decimal


class EquilibreStrictResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ecart: Decimal
    equilibre: bool
    tolerance_appliquee: Decimal


# ---------------------------------------------------------------------------
# F.IND.02 — CAF (Capacité d'AutoFinancement)
# ---------------------------------------------------------------------------


class CafInput(BaseModel):
    """CAF simplifié EPRD (§7).

    Formule : ``CAF = Résultat + Amortissements + Dotations_provisions
    - Reprises_provisions - Reprises_subventions ± autres_non_decaissables``.

    ``capital_a_rembourser_n`` est optionnel — fourni pour calculer le
    ratio CAF / IAF (>= 1,2 = santé).
    """

    model_config = ConfigDict(extra="forbid")

    resultat_net: Decimal
    dotations_amortissements: Decimal = Decimal("0")
    dotations_provisions: Decimal = Decimal("0")
    reprises_provisions: Decimal = Decimal("0")
    reprises_subventions: Decimal = Decimal("0")
    autres_non_decaissables: Decimal = Decimal("0")
    capital_a_rembourser_n: Decimal | None = None


class CafResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    caf: Decimal
    ratio_caf_iaf: Decimal | None
    sante: SanteIndicateur


# ---------------------------------------------------------------------------
# F.IND.01 — Marge brute
# ---------------------------------------------------------------------------


class MargeBruteInput(BaseModel):
    """Marge brute : ``(Résultat_net / Total_produits) × 100``.

    Seuil vigilance < 2% (S01 trame VF vKAS) — service renvoie
    ``sante='alerte'`` dans ce cas.
    """

    model_config = ConfigDict(extra="forbid")

    resultat_net: Decimal
    total_produits: Decimal


class MargeBruteResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    marge_brute_pct: Decimal
    sante: SanteIndicateur


# ---------------------------------------------------------------------------
# F.IND.03 — FRNG (Fonds de Roulement Net Global)
# ---------------------------------------------------------------------------


class FrngInput(BaseModel):
    """FRNG = Ressources_durables - Emplois_durables.

    Décomposition : FRI (Investissement) + FRE (Exploitation) = FRNG.
    Le caller fournit déjà la décomposition — pas de regroupement
    automatique côté service.
    """

    model_config = ConfigDict(extra="forbid")

    # FRI components
    fonds_propres: Decimal
    subventions_invest: Decimal = Decimal("0")
    provisions_invest: Decimal = Decimal("0")
    dettes_long_terme: Decimal = Decimal("0")
    immobilisations_nettes: Decimal
    # FRE components — empile sur FRI quand ESMS distingue les deux
    fre_ressources: Decimal = Decimal("0")
    fre_emplois: Decimal = Decimal("0")


class FrngResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    fri: Decimal
    fre: Decimal
    frng: Decimal
    sante: SanteIndicateur


# ---------------------------------------------------------------------------
# F.IND.04 — BFR (Besoin en Fonds de Roulement)
# ---------------------------------------------------------------------------


class BfrInput(BaseModel):
    """BFR = (Créances + Stocks) - (Dettes_fournisseurs + Dettes_sociales).

    Pour ESMS fonction publique territoriale, le solde des comptes 45
    (débiteurs/créditeurs) est en trésorerie, pas ici (§9 trame).
    """

    model_config = ConfigDict(extra="forbid")

    creances_clients: Decimal = Decimal("0")
    stocks: Decimal = Decimal("0")
    dettes_fournisseurs: Decimal = Decimal("0")
    dettes_sociales: Decimal = Decimal("0")


class BfrResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    bfr: Decimal
    sante: SanteIndicateur


# ---------------------------------------------------------------------------
# F.IND.05 — Trésorerie nette
# ---------------------------------------------------------------------------


class TresorerieInput(BaseModel):
    """Trésorerie = FRNG - BFR."""

    model_config = ConfigDict(extra="forbid")

    frng: Decimal
    bfr: Decimal


class TresorerieResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tresorerie: Decimal
    sante: SanteIndicateur


# ---------------------------------------------------------------------------
# F.ETP.01→05 — Calculs ETP
# ---------------------------------------------------------------------------


class EtpConstantes(BaseModel):
    """Constantes paramétrables (S20 CDC TER §16)."""

    model_config = ConfigDict(extra="forbid")

    etp_par_defaut: Decimal = Decimal("1")
    heures_mensuel_default: Decimal = Decimal("151.67")
    heures_annuel_base: Decimal = Decimal("1820")
    heures_annuel_base_global: Decimal = Decimal("1820.04")


class EtpProrataInput(BaseModel):
    """Inputs pour F.ETP.01 + F.ETP.02 (ETP prorata rémunéré) + F.ETP.03
    (ETP prorata travaillé)."""

    model_config = ConfigDict(extra="forbid")

    etp: Decimal = Decimal("1")
    heures_reelles_paie: Decimal
    nbre_mois_travaille_saisi: Decimal | None = None
    constantes: EtpConstantes = EtpConstantes()


class EtpProrataResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    nbre_mois_remun: Decimal  # F.ETP.01
    etp_prorata_remun: Decimal  # F.ETP.02
    etp_prorata_trav: Decimal | None  # F.ETP.03 — None si nbre_mois_travaille_saisi absent


class EtpGlobalInput(BaseModel):
    """F.ETP.04 — ETP global depuis heures travaillées."""

    model_config = ConfigDict(extra="forbid")

    heures_travaillees: Decimal
    constantes: EtpConstantes = EtpConstantes()


class EtpGlobalResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    etp_global: Decimal


class EtpImputationInput(BaseModel):
    """F.ETP.05 — Imputation par section.

    ``taux_par_section`` doit avoir ``Σ = 100%`` (tolérance 0.001 pour
    arrondis). Sections autorisées : H / D / S / SEA. Pour FAM-SAMSAH
    et Autres ESSMS, sections vides → ETP non imputé."""

    model_config = ConfigDict(extra="forbid")

    etp_prorata_remun: Decimal
    taux_par_section: dict[Section, Decimal]


class EtpImputationResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    imputation_par_section: dict[Section, Decimal]
    sum_taux_pct: Decimal
    valide: bool


# ---------------------------------------------------------------------------
# F.DEP.01 / F.GIR.03 — Forfait dépendance
# ---------------------------------------------------------------------------


class ForfaitDependanceInput(BaseModel):
    """Inputs pour calcul forfait dépendance CD d'implantation (S03 p.19).

    Modulation R.314-174 (>= 2018) : si TO_realise < seuil →
    abattement = (seuil - TO_realise) / 2 (en %). Pas de modulation
    à la hausse au-dessus de 95% TO.
    """

    model_config = ConfigDict(extra="forbid")

    forfait_global_dependance: Decimal
    montant_participations_residents: Decimal = Decimal("0")
    to_previsionnel: Decimal = Field(..., ge=0, le=1)
    montant_hors_departement: Decimal = Decimal("0")
    # Modulation TO
    annee: int = Field(..., ge=2018)
    to_realise: Decimal | None = Field(default=None, ge=0, le=1)
    seuil_modulation_pct: Decimal | None = None
    apply_modulation: bool = True


class ForfaitDependanceResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    forfait_cd_implantation_brut: Decimal
    forfait_cd_implantation_module: Decimal
    abattement_pct: Decimal
    modulation_appliquee: bool


# ---------------------------------------------------------------------------
# F.GIR.01 / F.GIR.02 — Valeur point GIR + GMP
# ---------------------------------------------------------------------------


class ValeurPointGirInput(BaseModel):
    """Resolution de la valeur du point GIR départemental (R.314-175).

    Si ``est_prive_commercial=True`` → charges nettes TTC (TVA 5,5%).
    Sinon → HT.

    Clapet anti-retour enforcé par le service : si
    ``valeur(N) < valeur(N-1)``, le résultat retourne ``valeur(N-1)``
    et flag ``clapet_applique=true``."""

    model_config = ConfigDict(extra="forbid")

    code_departement: str = Field(..., min_length=2, max_length=3)
    annee: int = Field(..., ge=2010, le=2100)
    est_prive_commercial: bool = False


class ValeurPointGirResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code_departement: str
    annee: int
    valeur: Decimal | None
    valeur_brute: Decimal | None
    clapet_applique: bool
    fallback_annee: int | None
    est_prive_commercial: bool


class GmpDepartementalInput(BaseModel):
    """GMP départemental = Σ(points_GIR × HP) / Σ(HP) hors USLD (S03 p.21).

    Le caller fournit la liste des EHPAD du département avec leurs
    points GIR + capacité HP. USLD doivent déjà être exclus.
    """

    model_config = ConfigDict(extra="forbid")

    ehpads: list[dict[str, Decimal]]


class GmpDepartementalResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    gmp: Decimal
    nb_ehpads: int
