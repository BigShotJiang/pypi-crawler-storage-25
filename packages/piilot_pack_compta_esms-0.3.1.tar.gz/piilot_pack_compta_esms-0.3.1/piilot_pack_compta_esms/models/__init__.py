"""Pydantic v2 models for compta-ESMS plugin entities.

Each entity exposes three schemas:

* ``XxxCreate`` — input for ``POST`` (no id / company_id / timestamps;
  those are injected by the service from the auth context).
* ``XxxUpdate`` — input for ``PATCH`` (all fields optional, ``model_config``
  refuses unknown keys to catch typos at the API boundary).
* ``XxxRead`` — output for ``GET`` (id + company_id + timestamps, populated
  from the row dicts the repositories return).

Common configuration: ``strict=True, extra='forbid'``. Strict catches
implicit coercions (``"42"`` → ``42``) at request parse time; ``forbid``
prevents silent acceptance of unknown fields, which is the kind of
mistake a frontend typo would otherwise hide.
"""

from piilot_pack_compta_esms.models.balance_apply import (
    ApplyRequest,
    ApplyResult,
    BalanceImportSummary,
    MaterializeRequest,
    MaterializeResult,
    UnmappedAccount,
)
from piilot_pack_compta_esms.models.balance_import import (
    BalanceImport,
    BalanceImportPreview,
    BalanceImportRead,
    ColumnDetection,
    ColumnHints,
)
from piilot_pack_compta_esms.models.balance_mapping import (
    BalanceMapping,
    BalanceMappingBulkItem,
    BalanceMappingCreate,
    BalanceMappingRead,
    BalanceMappingUpdate,
    BalanceMappingValidationIssue,
)
from piilot_pack_compta_esms.models.cr import (
    Cr,
    CrCreate,
    CrRead,
    CrReorder,
    CrUpdate,
)
from piilot_pack_compta_esms.models.document import (
    Document,
    DocumentClone,
    DocumentCreate,
    DocumentRead,
    DocumentUpdate,
)
from piilot_pack_compta_esms.models.etablissement import (
    Etablissement,
    EtablissementCreate,
    EtablissementRead,
    EtablissementUpdate,
)
from piilot_pack_compta_esms.models.exercice import (
    Exercice,
    ExerciceCreate,
    ExerciceRead,
)
from piilot_pack_compta_esms.models.og import (
    OG,
    OGCreate,
    OGRead,
    OGUpdate,
)
from piilot_pack_compta_esms.models.suggestion import (
    AcceptAboveRequest,
    SourceAccountSuggestion,
    SuggestionTarget,
    SuggestRequest,
)

__all__ = [
    "OG",
    "OGCreate",
    "OGRead",
    "OGUpdate",
    "Etablissement",
    "EtablissementCreate",
    "EtablissementRead",
    "EtablissementUpdate",
    "Exercice",
    "ExerciceCreate",
    "ExerciceRead",
    "Document",
    "DocumentClone",
    "DocumentCreate",
    "DocumentRead",
    "DocumentUpdate",
    "Cr",
    "CrCreate",
    "CrRead",
    "CrReorder",
    "CrUpdate",
    "BalanceMapping",
    "BalanceMappingBulkItem",
    "BalanceMappingCreate",
    "BalanceMappingRead",
    "BalanceMappingUpdate",
    "BalanceMappingValidationIssue",
    "BalanceImport",
    "BalanceImportPreview",
    "BalanceImportRead",
    "ColumnDetection",
    "ColumnHints",
    "AcceptAboveRequest",
    "SourceAccountSuggestion",
    "SuggestionTarget",
    "SuggestRequest",
    "ApplyRequest",
    "ApplyResult",
    "BalanceImportSummary",
    "MaterializeRequest",
    "MaterializeResult",
    "UnmappedAccount",
]
