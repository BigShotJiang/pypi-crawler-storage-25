"""Apply / materialize / replay request and response models (§F.5)."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class ApplyRequest(BaseModel):
    """Body of ``POST .../apply-mapping`` (L2 §7bis.4.1)."""

    model_config = ConfigDict(extra="forbid")

    version_m22bis: str = Field(
        default="2025-2026",
        max_length=20,
        description="DGCS millésime to filter the balance_mappings dictionary on.",
    )
    dry_run: bool = Field(
        default=False,
        description=(
            "Compute mapped/unmapped without persisting on balance_imports. "
            "Returns the same counts in the response payload — useful for the "
            'frontend\'s "preview before applying" affordance.'
        ),
    )


class ApplyResult(BaseModel):
    """Response body of ``:apply-mapping`` — counts + status summary.

    A successful apply with no unmapped accounts ends in
    ``status='completed'`` ; any unmapped row downgrades to
    ``status='partial'`` so the assistant UI can surface the gap.
    """

    model_config = ConfigDict(extra="forbid")

    import_id: UUID
    status: str
    nb_lignes_source: int
    nb_lignes_mappees: int
    nb_lignes_non_mappees: int
    nb_unmapped_accounts: int
    applied_at: datetime | None
    dry_run: bool


class MaterializeRequest(BaseModel):
    """Body of ``POST .../materialize-kb`` (L2 §7bis.4.3)."""

    model_config = ConfigDict(extra="forbid")

    kb_label: str | None = Field(
        default=None,
        max_length=255,
        description=(
            "Display name for the materialised KB. Defaults to "
            '``f"Balance M22bis - {periode_label} - {source_plan}"``.'
        ),
    )
    overwrite_existing: bool = Field(
        default=False,
        description=(
            "When True and the import already has a ``materialized_kb_id``, "
            "the existing KB's rows are replaced. When False (default), the "
            "endpoint 409s on a second materialization attempt."
        ),
    )


class UnmappedAccount(BaseModel):
    """One entry of ``GET .../unmapped-accounts``."""

    model_config = ConfigDict(extra="forbid")

    source_account: str
    label_hint: str | None = None
    montant: float = 0.0
    nb_lignes: int = 0


class BalanceImportSummary(BaseModel):
    """Compact row of ``GET /balance-imports`` (history listing).

    Drops the heavy JSONB columns (preview_data, suggestions,
    mapping_snapshot) — the list endpoint only needs the metadata to
    populate the history table ; ``GET /balance-imports/{id}`` (from
    §F.3) returns the full row when the cabinet drills in."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    exercice_id: UUID | None
    etablissement_id: UUID | None
    source_plan: str
    source_filename: str | None
    periode_label: str
    nb_lignes_source: int
    nb_lignes_mappees: int
    nb_lignes_non_mappees: int
    status: str
    materialized_kb_id: UUID | None
    imported_by_user_id: UUID
    imported_at: datetime
    applied_at: datetime | None


class MaterializeResult(BaseModel):
    """Response of ``:materialize-kb`` — pointer to the freshly created
    plugin-owned KB plus the cabinet-facing metadata."""

    model_config = ConfigDict(extra="forbid")

    import_id: UUID
    kb_id: UUID
    kb_name: str
    kb_table_name: str | None
    rows_inserted: int
    overwritten: bool


# Re-export for ``balance_apply_service`` consumers that prefer one
# import per concern.
APPLY_MODELS: tuple[type[Any], ...] = (
    ApplyRequest,
    ApplyResult,
    MaterializeRequest,
    MaterializeResult,
    UnmappedAccount,
    BalanceImportSummary,
)
