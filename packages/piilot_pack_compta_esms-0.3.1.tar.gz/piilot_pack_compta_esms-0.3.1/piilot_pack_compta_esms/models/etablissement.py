"""Établissement Pydantic models.

An établissement is a geographic FINESS attached to an OG. The OG can
have N établissements (D-018). Cf. L1 schema lines 51-83.

``typologie`` is a free TEXT in the DB (L1) — the value space lives
in the core reference KB ``com.piilot.core.typologies-essms`` (PLT-T1,
46 codes : EHPAD, FAM, MAS, IME, ITEP, CMPP, SESSAD, CAMSP, SAMSAH,
SAD, SPASAD, ESAT, RA, USLD, SSIAD, AJA, PUV, …). We validate dynamically
at the service layer via
:func:`piilot_pack_compta_esms.services.reference_lookup.typologie_exists`
so the plugin picks up DGCS additions on the next core sync without a
redeploy.

Same pattern for ``convention_collective`` against the
``com.piilot.core.conventions-collectives-esms`` catalog.

Pydantic-level validation is intentionally lax (``str`` + length bounds)
— the service-layer DB lookup is the source of truth. This trade-off
keeps the API surface honest : an empty/non-synced catalog fails open
(any value accepted with a warning log) rather than locking out create
endpoints during a deployment.
"""

from __future__ import annotations

import re
from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from piilot_pack_compta_esms.services.validators import reject_pipe_char

Cofinancement = Literal["ars_cd", "ars_exclusif", "aucun"]
"""Cf. L1 ligne 70."""

# v0.3 — D-030 extended fields (KB 06-data-model §B.2 révisé).
OuiNon = Literal["OUI", "NON"]
"""Used for `eligible_aide_sociale` + `tarification_differenciee_o_n`."""

OptionTarifaire = Literal["GMPS_DROIT_COMMUN", "FORFAIT_SOINS", "CONVENTION_SSIAD_EXT"]
"""Allowed option_tarifaire for EHPAD/PUV (S03 p.25)."""

GmpValidationMode = Literal["MEDECIN_ARS", "MEDECIN_CD", "MEDECIN_COORDONNATEUR_TACITE"]
"""Allowed gmp_validation_mode (S03 p.17)."""

_FINESS_RE = re.compile(r"^\d{9}$")


class EtablissementBase(BaseModel):
    """Shared fields between Create/Update/Read."""

    # Cf. note in ``models.og`` — ``extra='forbid'`` only, strict mode
    # blocks JSON UUID coercion.
    model_config = ConfigDict(extra="forbid")

    og_id: UUID = Field(..., description="OG parent (FK)")
    finess_ets: str = Field(..., description="FINESS géographique — 9 chiffres")
    raison_sociale: str = Field(..., min_length=1, max_length=255)
    typologie: str = Field(
        ...,
        min_length=1,
        max_length=50,
        description=(
            "Code typologie ESSMS — référentiel "
            "``com.piilot.core.typologies-essms`` (PLT-T1, 46 codes). "
            "Validation runtime au service layer via reference_lookup."
        ),
    )
    categorie: str | None = Field(default=None, max_length=10)
    adresse: str | None = Field(default=None, max_length=500)
    date_autorisation: date | None = None
    capacite_autorisee: int = Field(default=0, ge=0)
    capacite_installee: int = Field(default=0, ge=0)
    capacite_financee: int = Field(default=0, ge=0)
    # D-048 — Décomposition EHPAD (HP/UHR/PASA/HT/AJ) et autres ESSMS
    # (externat/semi-internat/internat). 8 colonnes nullable selon
    # typologie (un EHPAD remplit HP/UHR/PASA/HT/AJ et laisse les
    # autres à None, et vice versa). Cf. KB19 §11. Pré-requis §AB
    # ratios vétusté + §R Q10 :compute forfait_dépendance.
    capacite_hp: int | None = Field(default=None, ge=0)
    capacite_uhr: int | None = Field(default=None, ge=0)
    capacite_pasa: int | None = Field(default=None, ge=0)
    capacite_ht: int | None = Field(default=None, ge=0)
    capacite_aj: int | None = Field(default=None, ge=0)
    capacite_externat: int | None = Field(default=None, ge=0)
    capacite_semi_internat: int | None = Field(default=None, ge=0)
    capacite_internat: int | None = Field(default=None, ge=0)
    amplitude_ouverture: int = Field(default=365, ge=1, le=366)
    convention_collective: str | None = Field(
        default=None,
        max_length=50,
        description=(
            "Code convention collective — référentiel "
            "``com.piilot.core.conventions-collectives-esms``. "
            "Validation runtime au service layer."
        ),
    )
    inclus_cpom: bool = False
    soumis_equilibre: bool = False
    tarification_ternaire: bool = False
    forfait_global_unique: bool = False
    cofinancement: Cofinancement | None = None

    # v0.3 — D-030 champs étendus (§BE, KB 06-data-model §B.2). Tous
    # Optional (rétro-compat ETS v0.2 qui ne les saisissent pas).
    eligible_aide_sociale: OuiNon | None = None
    option_tarifaire: OptionTarifaire | None = None
    """EHPAD/PUV uniquement (S03 p.25). Pas de gate par typologie
    côté Pydantic — un usage hors EHPAD/PUV passe (validation différée
    §Z catalogue contrôles si Sylvain veut formaliser)."""
    gmp_valeur: Decimal | None = Field(default=None, ge=0)
    gmp_date_validation: date | None = None
    gmp_validation_mode: GmpValidationMode | None = None
    pmp_valeur: Decimal | None = Field(default=None, ge=0)
    pmp_date_validation: date | None = None
    prix_journee_moyen: Decimal | None = Field(default=None, ge=0)
    tarification_differenciee_o_n: OuiNon | None = None
    nb_chambres_individuelles: int | None = Field(default=None, ge=0)
    nb_chambres_doubles: int | None = Field(default=None, ge=0)

    @field_validator("finess_ets")
    @classmethod
    def _validate_finess(cls, v: str) -> str:
        if not _FINESS_RE.match(v):
            raise ValueError("finess_ets must be exactly 9 digits")
        return v

    # D-075 — pipe char interdit dans les champs de saisie libre
    _no_pipe = field_validator("raison_sociale", "adresse")(reject_pipe_char)


class EtablissementCreate(EtablissementBase):
    """Body of ``POST /orgs/{og_id}/etablissements``.

    The ``og_id`` is also in the URL path — the route handler asserts
    they match before persisting (rejects a client trying to attach an
    ETS to a different OG via the body).
    """


class EtablissementUpdate(BaseModel):
    """Body of ``PATCH /etablissements/{ets_id}``.

    ``og_id`` is **not** mutable — re-parenting an établissement would
    break document history. To "move" an ETS, the cabinet must
    create a new one and migrate the documents (out of scope here).
    """

    # Cf. note in ``models.og`` — ``extra='forbid'`` only, strict mode
    # blocks JSON UUID coercion.
    model_config = ConfigDict(extra="forbid")

    finess_ets: str | None = None
    raison_sociale: str | None = Field(default=None, min_length=1, max_length=255)
    typologie: str | None = Field(default=None, min_length=1, max_length=50)
    categorie: str | None = Field(default=None, max_length=10)
    adresse: str | None = Field(default=None, max_length=500)
    date_autorisation: date | None = None
    capacite_autorisee: int | None = Field(default=None, ge=0)
    capacite_installee: int | None = Field(default=None, ge=0)
    capacite_financee: int | None = Field(default=None, ge=0)
    # D-048 — Décomposition par section (cf. EtablissementBase).
    capacite_hp: int | None = Field(default=None, ge=0)
    capacite_uhr: int | None = Field(default=None, ge=0)
    capacite_pasa: int | None = Field(default=None, ge=0)
    capacite_ht: int | None = Field(default=None, ge=0)
    capacite_aj: int | None = Field(default=None, ge=0)
    capacite_externat: int | None = Field(default=None, ge=0)
    capacite_semi_internat: int | None = Field(default=None, ge=0)
    capacite_internat: int | None = Field(default=None, ge=0)
    amplitude_ouverture: int | None = Field(default=None, ge=1, le=366)
    convention_collective: str | None = Field(default=None, max_length=50)
    inclus_cpom: bool | None = None
    soumis_equilibre: bool | None = None
    tarification_ternaire: bool | None = None
    forfait_global_unique: bool | None = None
    cofinancement: Cofinancement | None = None

    # v0.3 — D-030 champs étendus (§BE, miroir EtablissementBase).
    eligible_aide_sociale: OuiNon | None = None
    option_tarifaire: OptionTarifaire | None = None
    gmp_valeur: Decimal | None = Field(default=None, ge=0)
    gmp_date_validation: date | None = None
    gmp_validation_mode: GmpValidationMode | None = None
    pmp_valeur: Decimal | None = Field(default=None, ge=0)
    pmp_date_validation: date | None = None
    prix_journee_moyen: Decimal | None = Field(default=None, ge=0)
    tarification_differenciee_o_n: OuiNon | None = None
    nb_chambres_individuelles: int | None = Field(default=None, ge=0)
    nb_chambres_doubles: int | None = Field(default=None, ge=0)

    @field_validator("finess_ets")
    @classmethod
    def _validate_finess(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if not _FINESS_RE.match(v):
            raise ValueError("finess_ets must be exactly 9 digits")
        return v

    # D-075 — pipe char interdit dans les champs de saisie libre
    _no_pipe = field_validator("raison_sociale", "adresse")(reject_pipe_char)


class EtablissementRead(EtablissementBase):
    """Body of ``GET /etablissements/{ets_id}`` — full DB row."""

    id: UUID
    company_id: UUID
    created_at: datetime
    updated_at: datetime


Etablissement = EtablissementRead
