"""Pydantic models for §BC — ``compute_eprd_structure`` (D-037).

Décrit la structure attendue d'un EPRD selon ``nature_juridique`` de
l'OG (KB B.1, 5 valeurs DGCS UPPER) :

* ``ETABLISSEMENT_PUBLIC_SANTE`` — EPRD géré par l'établissement de
  santé. CRPP sanitaire + N CRPA médico-sociaux.
* ``ESMS_PUBLIC_AUTONOME``      — CRPP + N CRPA (1 par ESMS sup.).
* ``CCAS_CIAS_COLLECTIVITE``    — Budget annexe : 2 organisations
  possibles (1 EPRD avec 1 CRP global / 1 EPRD par ESMS). Le service
  retourne la variante "1 EPRD avec 1 CRP par ESMS" par défaut ; le
  cabinet peut éclater en plusieurs EPRD ultérieurement (S03 p.16-17).
* ``PRIVE_NON_LUCRATIF``        — CRPP + N CRPA (équilibre réel si CPOM).
* ``PRIVE_COMMERCIAL``          — CRPP simplifié, pas de CRPA structurels
  (opposable mais vision partielle, S03 p.13).

Sources : ``05-workflows.md §"Cas particuliers"`` + ``16-annexe1-eprd-
structure.md §14`` + KB B.1.

Le service consommateur est :func:`document_service.create_document`
qui pré-crée les CRPs structurels en plus du CRPP par défaut.
"""

from __future__ import annotations

from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from piilot_pack_compta_esms.models.og import NatureJuridique

CrType = Literal["CRPP", "CRPA", "CRP_SF"]
"""Cf. L1 §3 — CRPP (principal), CRPA (annexe), CRP_SF (sans FINESS,
spécifique EPRD)."""

CrVariante = Literal["soumis_equilibre", "non_soumis_equil"]
"""Cf. L1 §3."""

EquilibreApplicableInitial = Literal["REEL", "STRICT", "NON_APPLICABLE"]
"""Équilibre R.314-222 calculé initialement au moment de la création
de l'EPRD (§BD ``compute_equilibre_applicable`` peut le re-calculer
per-ETS plus tard avec une logique CPOM-aware plus fine)."""

AnnexeCode = Literal["4", "5", "6", "8"]
"""Annexes structurelles EPRD :
* 4 — Activité GIR (R.314-219)
* 5 — Financière forfaits (R.314-223)
* 6 — TPER personnel prévisionnel (R.314-224)
* 8 — Bilan financier (référence — vit dans Annexe 1 globale)."""


class CrpSpec(BaseModel):
    """Spec d'un CRP structurel à pré-créer dans le document EPRD."""

    model_config = ConfigDict(extra="forbid")

    cr_type: CrType
    cr_variante: CrVariante
    etablissement_id: UUID | None = Field(
        default=None,
        description=(
            "ETS rattaché. ``None`` pour le CRPP générique quand l'OG n'a "
            "qu'1 ESMS principal — le cabinet bind via §E.4 après "
            "création."
        ),
    )
    denomination: str = Field(..., min_length=1, max_length=255)
    ordre: int = Field(..., ge=0)


class AnnexeSpec(BaseModel):
    """Spec d'une annexe attendue (référentielle — la matérialisation
    réelle des lignes vit dans les KBs ``annexe_*`` ou les tables
    ``annexe5_lignes`` / ``activite_lignes`` / ``tper_ter_lignes``)."""

    model_config = ConfigDict(extra="forbid")

    code: AnnexeCode
    obligatoire: bool
    description: str = Field(..., min_length=1, max_length=255)


class EprdStructureSpec(BaseModel):
    """Réponse de :func:`eprd_structure_service.compute_eprd_structure`.

    Décrit la structure complète attendue pour un EPRD selon la
    nature juridique de l'OG : CRPs + annexes + équilibre initial.
    """

    model_config = ConfigDict(extra="forbid")

    og_id: UUID
    nature_juridique: NatureJuridique
    crps: list[CrpSpec] = Field(
        ...,
        description=(
            "1 CRPP + N CRPA. Vide pour le cas dégénéré PRIVE_COMMERCIAL "
            "où le CRPP par défaut suffit (pas de CRPA structurels)."
        ),
    )
    annexes: list[AnnexeSpec]
    equilibre_applicable_initial: EquilibreApplicableInitial = Field(
        ...,
        description=(
            "Équilibre R.314-222 calculé initialement. Sera re-évalué "
            "per-ETS par §BD ``compute_equilibre_applicable`` (avec "
            "logique CPOM/exercice fine)."
        ),
    )
    notes: list[str] = Field(
        default_factory=list,
        description=(
            "Messages cabinet (FR libre) : guidance / warnings / "
            "rappels DGCS (ex. EPRD simplifié pour PRIVE_COMMERCIAL)."
        ),
    )
