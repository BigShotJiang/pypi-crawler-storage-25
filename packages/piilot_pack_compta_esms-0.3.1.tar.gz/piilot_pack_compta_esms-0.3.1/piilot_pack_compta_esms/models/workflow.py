"""Workflow transitions (§S, L2 §4.6 + §4.7, D-023 + D-024).

Ce module modélise la machine d'état des documents budgétaires et les
DTOs HTTP de :

* POST /documents/{doc_id}/transitions — applique une action
  (``transmit``, ``approve``, ``reject``, ``set_affectation``) ;
* GET /documents/{doc_id}/transitions-allowed — liste les actions
  applicables depuis le statut courant + l'état des 2 approbations.

Choix de modélisation (cf. kb/05-workflows.md + plan-dev §4.2) :

* ``approve`` (ARS et CD) est **une seule action HTTP** avec un
  payload discriminé par ``autorite`` ('ars' | 'cd'). On ne crée pas
  de statuts DB intermédiaires ``approuve_ars`` / ``approuve_cd`` :
  le couple (statut='en_instruction', approuve_par_*_at) capte
  l'information complète. Quand les 2 timestamps sont remplis, le
  service flip auto ``statut='executoire'``.
* ``set_affectation`` est ERRD-only (transition
  ``TRANSMIS → AFFECTATION_DEFINIE``). 409 pour tous les autres
  types.
* ``reject`` est EPRD-family only (EPRD/DM/RIA/AVENANT/ERCP/EPCP).
  Motif obligatoire (max 500 chars), autorite obligatoire.
* Idempotence stricte : 2e ``transmit`` sur un document déjà transmis
  → 409 (cf. KB 05 "Pas de back-transition possible").

Le flip ``transmis → en_instruction`` documenté par la KB comme
"transition système automatique" est **collapsé** pour
EPRD/DM/RIA/AVENANT/ERCP/EPCP : on passe directement de ``brouillon``
à ``en_instruction`` au ``transmit``. ERRD garde ``transmis`` comme
état intermédiaire avant ``affectation_definie`` (sémantique distincte
— l'OG fixe lui-même l'affectation, pas d'ATC entre les deux).
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from piilot_pack_compta_esms.models.document import StatutDocument, TypeDocument
from piilot_pack_compta_esms.services.validators import reject_pipe_char

# ---------------------------------------------------------------------------
# Literal types
# ---------------------------------------------------------------------------

TransitionAction = Literal["transmit", "approve", "reject", "set_affectation"]
"""Cf. L2 §4.6 body discriminator."""

AutoriteTarif = Literal["ars", "cd"]
"""Autorité tarifaire — ARS (Agence Régionale de Santé) ou CD
(Conseil Départemental). Posée dans le payload des actions
``approve`` et ``reject`` (EPRD-family double validation, D-024)."""


# ---------------------------------------------------------------------------
# Inbound DTO — POST /documents/{doc_id}/transitions
# ---------------------------------------------------------------------------


class TransitionRequest(BaseModel):
    """Body de ``POST /documents/{doc_id}/transitions`` (L2 §4.6).

    Champs présents/absents selon ``action`` :

    * ``transmit`` : aucun champ supplémentaire (ERRD ou EPRD-family).
    * ``approve``  : ``autorite`` obligatoire (EPRD-family only).
    * ``reject``   : ``autorite`` + ``motif`` obligatoires (EPRD-family
      only).
    * ``set_affectation`` : aucun champ supplémentaire (ERRD only).

    Validation cross-field via ``model_validator`` ci-dessous —
    permet à FastAPI de renvoyer un 422 propre sans qu'on ait à
    construire 4 modèles Pydantic distincts avec un Discriminator
    (qui complique la doc OpenAPI sans bénéfice net ici).
    """

    model_config = ConfigDict(extra="forbid")

    action: TransitionAction
    autorite: AutoriteTarif | None = None
    motif: str | None = Field(default=None, min_length=1, max_length=500)

    # D-075 — pipe char interdit dans le motif de rejet
    _no_pipe = field_validator("motif")(reject_pipe_char)

    @model_validator(mode="after")
    def _validate_action_payload(self) -> TransitionRequest:
        if self.action == "approve":
            if self.autorite is None:
                raise ValueError("autorite_required_for_approve")
            if self.motif is not None:
                raise ValueError("motif_forbidden_for_approve")
        elif self.action == "reject":
            if self.autorite is None:
                raise ValueError("autorite_required_for_reject")
            if self.motif is None:
                raise ValueError("motif_required_for_reject")
        else:  # transmit, set_affectation
            if self.autorite is not None:
                raise ValueError("autorite_forbidden")
            if self.motif is not None:
                raise ValueError("motif_forbidden")
        return self


# ---------------------------------------------------------------------------
# Outbound DTO — POST /documents/{doc_id}/transitions
# ---------------------------------------------------------------------------


class DoubleValidationState(BaseModel):
    """Sous-état des 2 approbations parallèles (EPRD-family).

    Pour ERRD : ``applicable=False`` et les 4 timestamps/user_ids sont
    NULL (la double validation n'est pas applicable au workflow ERRD).
    """

    model_config = ConfigDict(extra="forbid")

    applicable: bool
    approuve_par_ars_at: datetime | None = None
    approuve_par_cd_at: datetime | None = None
    approuve_par_ars_user_id: UUID | None = None
    approuve_par_cd_user_id: UUID | None = None


class TransitionResponse(BaseModel):
    """Retour de POST /transitions — le statut résultant + l'état des
    side columns pertinentes pour rendre la réponse self-descriptive.
    Le frontend n'a pas besoin d'un GET /documents/{id} de relance
    après la transition.
    """

    model_config = ConfigDict(extra="forbid")

    document_id: UUID
    type_document: TypeDocument
    statut_before: StatutDocument
    statut_after: StatutDocument
    action: TransitionAction
    autorite: AutoriteTarif | None = None
    transmis_at: datetime | None = None
    executoire_at: datetime | None = None
    rejete_at: datetime | None = None
    motif_rejet: str | None = None
    rejete_par_autorite: AutoriteTarif | None = None
    affectation_definie_at: datetime | None = None
    double_validation: DoubleValidationState


# ---------------------------------------------------------------------------
# Outbound DTO — GET /documents/{doc_id}/transitions-allowed
# ---------------------------------------------------------------------------


class AllowedAction(BaseModel):
    """Description d'une action applicable depuis l'état courant.

    Le frontend dérive les CTAs visibles (label, role requis) sans
    coder en dur la machine d'état.
    """

    model_config = ConfigDict(extra="forbid")

    action: TransitionAction
    label: str
    role_required: Literal["builder", "admin"]
    autorite: AutoriteTarif | None = None
    """Quand l'action ``approve``/``reject`` est candidate pour ARS
    et CD séparément (double validation), 2 entrées distinctes sont
    renvoyées — chacune avec ``autorite`` posée."""


class BlockedAction(BaseModel):
    """Action théoriquement candidate mais bloquée + raison machine."""

    model_config = ConfigDict(extra="forbid")

    action: TransitionAction
    autorite: AutoriteTarif | None = None
    reason: str
    """Codes machine — ``equilibre_invalid``, ``already_approved``,
    ``transition_not_allowed_from_statut``, ``role_required``,
    ``not_applicable_for_type``. Le frontend mappe vers un message
    i18n."""


class TransitionsAllowedResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    document_id: UUID
    type_document: TypeDocument
    current_statut: StatutDocument
    allowed: list[AllowedAction] = Field(default_factory=list)
    blocked: list[BlockedAction] = Field(default_factory=list)
    double_validation: DoubleValidationState


# ---------------------------------------------------------------------------
# Internal types (used by the state machine + service)
# ---------------------------------------------------------------------------


class WorkflowSnapshot(BaseModel):
    """Snapshot complet de l'état workflow d'un document, lu par le repo
    + passé au state machine pour décider des transitions allowed.

    Ne sert pas de DTO HTTP — uniquement comme structure de passage
    intra-process. Encapsulé en BaseModel pour bénéficier de la
    validation Pydantic au moment du chargement.
    """

    model_config = ConfigDict(extra="forbid")

    document_id: UUID
    type_document: TypeDocument
    statut: StatutDocument
    transmis_at: datetime | None
    executoire_at: datetime | None
    approuve_par_ars_at: datetime | None
    approuve_par_cd_at: datetime | None
    approuve_par_ars_user_id: UUID | None
    approuve_par_cd_user_id: UUID | None
    rejete_at: datetime | None
    rejete_par_autorite: AutoriteTarif | None
    motif_rejet: str | None
    affectation_definie_at: datetime | None
