"""Tableau de financement (§M, L2 §15).

Deux variantes coexistantes selon ``doc.type_document`` :

* **TF** (ERRD) — 4 colonnes : ``budget_initial_n1 / realisations_n1 /
  previsions_n / realisations_n``.
* **TFP** (EPRD) — 8 colonnes : ``nm1 / n / np1 / np2 / np3 / np4 /
  np5 / np6`` (8 exercices N-1 à N+6 — **D-094**).

Le DDL ``tf_lignes`` accommode les 2 cas dans la **même table** —
pas de discriminant ``variante`` (L4 ligne 240 : "TableauFinancementPage
→ TF (ERRD) ou TFP (EPRD)"). Le service expose les colonnes pertinentes
selon ``doc.type_document``.

Structure hiérarchique (25-deepdive §6) :

* ``cote`` (ressources / emplois)
  * ``titre`` (Titre 1 / Titre 2 / Titre 3 — classification métier)
    * ``libelle`` (libellé spécifique)

Lignes calculées sans ``compte_m22bis`` (Q7 nullable) :
"Insuffisance autofinancement", "Capacité autofinancement",
"Apport FR", "Prélèvement FR", "Total emplois", "Total ressources",
"TOTAL ÉQUILIBRE TF" (25-deepdive §23.3).

**Équilibre** (25-deepdive §6) : ``Total ressources + Prélèvement FR
= Total emplois + Apport FR`` — c-à-d Σ ressources (incluant
Prélèvement FR comme ligne) == Σ emplois (incluant Apport FR comme
ligne). Tolérance 0.01€ Q5 (cohérent §I/§J/§K).
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from piilot_pack_compta_esms.services.validators import reject_pipe_char

TypeTf = Literal["TF", "TFP"]
"""Déduit de ``doc.type_document`` au moment du GET/totals.
``errd`` → ``TF`` (4 colonnes). ``eprd`` → ``TFP`` (8 colonnes).
Autres doc_types par défaut → ``TF``."""

Cote = Literal["ressources", "emplois"]
"""DDL ligne 498 — CHECK constraint."""

TfColumn = Literal[
    # ERRD (4 colonnes)
    "montant_budget_initial_n1",
    "montant_realisations_n1",
    "montant_previsions_n",
    "montant_realisations_n",
    # TFP (8 colonnes — D-094)
    "montant_nm1",
    "montant_n",
    "montant_np1",
    "montant_np2",
    "montant_np3",
    "montant_np4",
    "montant_np5",
    "montant_np6",
]
"""Toutes les colonnes monétaires possibles du DDL. Le service expose
les 4 ERRD ou les 8 TFP selon ``doc.type_document``."""

_ERRD_COLUMNS: tuple[str, ...] = (
    "montant_budget_initial_n1",
    "montant_realisations_n1",
    "montant_previsions_n",
    "montant_realisations_n",
)
"""Colonnes ERRD (TF). Exposées quand ``doc.type_document='errd'``."""

_TFP_COLUMNS: tuple[str, ...] = (
    "montant_nm1",
    "montant_n",
    "montant_np1",
    "montant_np2",
    "montant_np3",
    "montant_np4",
    "montant_np5",
    "montant_np6",
)
"""Colonnes TFP (EPRD). D-094 : 8 exercices N-1 à N+6."""


def columns_for_type(type_tf: str) -> tuple[str, ...]:
    """Helper public : retourne le tuple de colonnes pertinent pour
    le type TF. Utilisé par :mod:`tf_service` et :mod:`tf_repo`."""
    return _TFP_COLUMNS if type_tf == "TFP" else _ERRD_COLUMNS


# ---------------------------------------------------------------------------
# Items du bulk
# ---------------------------------------------------------------------------


class TfLigneCreate(BaseModel):
    """Un item du bulk-upsert. Le cabinet remplit les colonnes ERRD
    OU TFP selon le type_document (Q1 — pas de discriminant DDL).

    ``titre`` (Titre 1/2/3) optionnel — utilisé pour le breakdown
    hiérarchique côté ``:totals`` (Q4). Les lignes calculées
    (Apport FR, Total emplois, etc.) peuvent omettre titre."""

    model_config = ConfigDict(extra="forbid")

    cote: Cote
    titre: str | None = Field(default=None, max_length=64)
    libelle: str = Field(..., min_length=1, max_length=255)
    compte_m22bis: str | None = Field(default=None, max_length=32)
    # ERRD (4 colonnes)
    montant_budget_initial_n1: Decimal | None = None
    montant_realisations_n1: Decimal | None = None
    montant_previsions_n: Decimal | None = None
    montant_realisations_n: Decimal | None = None
    # TFP (8 colonnes — D-094)
    montant_nm1: Decimal | None = None
    montant_n: Decimal | None = None
    montant_np1: Decimal | None = None
    montant_np2: Decimal | None = None
    montant_np3: Decimal | None = None
    montant_np4: Decimal | None = None
    montant_np5: Decimal | None = None
    montant_np6: Decimal | None = None

    # D-075 — pipe char interdit dans titre + libellé
    _no_pipe = field_validator("titre", "libelle")(reject_pipe_char)


class TfBulkUpsertRequest(BaseModel):
    """Body de ``POST /documents/{doc_id}/tableau-financement:bulk-upsert``.

    Sémantique Q2 : **replace all by document** — DELETE WHERE doc +
    INSERT batch. Le cabinet renvoie l'intégralité du TF à chaque save."""

    model_config = ConfigDict(extra="forbid")

    items: list[TfLigneCreate] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------


class TfLigneRead(BaseModel):
    """Row complet de ``compta_esms.tf_lignes``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    cote: Cote
    titre: str | None
    libelle: str
    compte_m22bis: str | None
    montant_budget_initial_n1: Decimal | None
    montant_realisations_n1: Decimal | None
    montant_previsions_n: Decimal | None
    montant_realisations_n: Decimal | None
    montant_nm1: Decimal | None
    montant_n: Decimal | None
    montant_np1: Decimal | None
    montant_np2: Decimal | None
    montant_np3: Decimal | None
    montant_np4: Decimal | None
    montant_np5: Decimal | None
    montant_np6: Decimal | None
    created_at: datetime
    updated_at: datetime


class TfResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/tableau-financement``.

    ``type_tf`` est déduit de ``doc.type_document`` côté service.
    Utile à l'UI pour savoir quel set de colonnes afficher (4 ERRD
    vs 8 TFP).
    """

    model_config = ConfigDict(extra="forbid")

    type_tf: TypeTf
    items: list[TfLigneRead]


# ---------------------------------------------------------------------------
# Totals (Q3 par colonne + Q4 breakdown par titre)
# ---------------------------------------------------------------------------


class TfTitreSubtotal(BaseModel):
    """Sous-total par titre, par colonne. ``totals_by_column`` est
    keyed par nom de colonne (ex: ``montant_realisations_n`` pour TF,
    ``montant_np2`` pour TFP)."""

    model_config = ConfigDict(extra="forbid")

    titre: str | None
    totals_by_column: dict[str, Decimal]


class TfTotalsForCote(BaseModel):
    """Sous-total d'une cote (ressources OU emplois).

    ``by_titre`` détaille hiérarchique (25-deepdive §6 Titre 1/2/3).
    ``totals_by_column`` agrège **toutes les lignes de la cote** par
    colonne — utilisé par :func:`tf_service.compute_totals` pour
    calculer l'équilibre par colonne."""

    model_config = ConfigDict(extra="forbid")

    cote: Cote
    by_titre: list[TfTitreSubtotal]
    totals_by_column: dict[str, Decimal]


class TfEquilibreByColumn(BaseModel):
    """Verdict d'équilibre pour une colonne donnée.

    ``ecart = total_ressources - total_emplois``. ``valide`` ssi
    ``|ecart| <= tolerance`` (Q5 — 0.01€)."""

    model_config = ConfigDict(extra="forbid")

    column: str
    total_ressources: Decimal
    total_emplois: Decimal
    ecart: Decimal
    valide: bool


class TfTotalsResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/tableau-financement:totals``.

    Inclut l'équilibre (Q6 — pas de :validate séparé, L2 §15.3 dit
    "Totaux ressources/emplois + équilibre").
    """

    model_config = ConfigDict(extra="forbid")

    type_tf: TypeTf
    ressources: TfTotalsForCote | None = None
    emplois: TfTotalsForCote | None = None
    equilibre_by_column: list[TfEquilibreByColumn]
    valide_globalement: bool
    tolerance_appliquee: Decimal
