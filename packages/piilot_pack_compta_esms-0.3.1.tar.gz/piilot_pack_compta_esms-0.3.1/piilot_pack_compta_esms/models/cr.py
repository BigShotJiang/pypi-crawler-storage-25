"""Compte de Résultat (CR) Pydantic models.

A CR is a profit-and-loss table attached to a budget document. The
default CRPP is auto-created at ``POST /documents`` (D-073, §E.3) ;
this module exposes the user-driven operations on top : list,
explicitly create additional CRPA / CRP_SF / CRA_SF, patch, delete,
reorder.

Cf. L1 schema lines 141-167.

* ``cr_type`` is **immutable** after create — it's the discriminator
  for downstream features (lignes CRP groupings, controles applicables),
  so flipping it post-hoc would orphan the document's history. The
  cabinet must delete and recreate to "change the type".
* ``ventilation`` drives the line-by-line H/D/S/SEA layout (D-083 +
  D-085 — ``ternaire_hdsea`` is the 2026 experimental SEA forfait).
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from piilot_pack_compta_esms.services.validators import reject_pipe_char

CrType = Literal["CRPP", "CRPA", "CRP_SF", "CRA_SF"]
"""Cf. L1 ligne 146."""

CrVariante = Literal["soumis_equilibre", "non_soumis_equil"]
"""Cf. L1 ligne 147-149."""

Ventilation = Literal["simple", "ternaire_hds", "ternaire_hdsea"]
"""Cf. L1 ligne 155-157 + D-083 / D-085.

* ``simple`` : no analytical split.
* ``ternaire_hds`` : EHPAD classical Hébergement / Dépendance / Soins.
* ``ternaire_hdsea`` : EHPAD 2026 with the experimental fused
  ``Soins et entretien autonomie`` (SEA) column.
"""


class CrCreate(BaseModel):
    """Body of ``POST /documents/{doc_id}/crs``.

    The path carries ``doc_id`` — no need to repeat it in the body.
    ``etablissement_id`` is optional ; for CRP_SF / CRA_SF the cabinet
    often leaves it null and identifies the section via
    ``cr_identifiant``.
    """

    model_config = ConfigDict(extra="forbid")

    cr_type: CrType
    cr_variante: CrVariante = "non_soumis_equil"
    denomination: str = Field(..., min_length=1, max_length=255)
    cr_identifiant: str | None = Field(default=None, max_length=80)
    etablissement_id: UUID | None = None
    finess_rattachement: str | None = Field(default=None, max_length=20)
    capacite_installee: int | None = Field(default=None, ge=0)
    amplitude_ouverture: int | None = Field(default=None, ge=1, le=366)
    ventilation: Ventilation = "simple"
    ordre: int = Field(default=0, ge=0)

    # D-075 — pipe char interdit dans les libellés saisis
    _no_pipe = field_validator("denomination", "cr_identifiant")(reject_pipe_char)


class CrUpdate(BaseModel):
    """Body of ``PATCH /crs/{cr_id}`` (L2 §5.3).

    ``cr_type`` is **not** mutable (see module docstring). Everything
    else can be patched — the cabinet may rename, switch variante,
    attach to an établissement after the fact, bump ventilation when
    they realize their EHPAD has analytical needs, etc.
    """

    model_config = ConfigDict(extra="forbid")

    cr_variante: CrVariante | None = None
    denomination: str | None = Field(default=None, min_length=1, max_length=255)
    cr_identifiant: str | None = Field(default=None, max_length=80)
    etablissement_id: UUID | None = None
    finess_rattachement: str | None = Field(default=None, max_length=20)
    capacite_installee: int | None = Field(default=None, ge=0)
    amplitude_ouverture: int | None = Field(default=None, ge=1, le=366)
    ventilation: Ventilation | None = None
    ordre: int | None = Field(default=None, ge=0)

    # D-075 — pipe char interdit dans les libellés saisis
    _no_pipe = field_validator("denomination", "cr_identifiant")(reject_pipe_char)


class CrReorder(BaseModel):
    """Body of ``POST /crs/{cr_id}/reorder`` (L2 §5.5).

    Simple ``ordre`` swap — we don't re-sequence the other CRs in the
    document. The frontend computes the target ``ordre`` from its
    drag-and-drop result and sends it ; duplicate ``ordre`` values
    are tolerated by the DB (no UNIQUE) and resolved by ``ORDER BY
    ordre, created_at`` in the list query.
    """

    model_config = ConfigDict(extra="forbid")

    ordre: int = Field(..., ge=0)


class CrRead(BaseModel):
    """Body of ``GET /crs/{cr_id}`` — full DB row."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    etablissement_id: UUID | None
    cr_type: CrType
    cr_variante: CrVariante
    cr_identifiant: str | None
    denomination: str
    finess_rattachement: str | None
    capacite_installee: int | None
    amplitude_ouverture: int | None
    ventilation: Ventilation
    ordre: int
    created_at: datetime
    updated_at: datetime


Cr = CrRead
