"""EPRD tarifs proposés Pydantic models — §BB v0.3.

Une row par (document EPRD, établissement, section). Workflow
row-level distinct du workflow document (§S) — l'ATC valide chaque
tarif individuellement avant que le document devienne exécutoire.

Sémantique des 4 sections (D-083 + D-085) :

* ``HEBERGEMENT``         — compétence Conseil Départemental
* ``DEPENDANCE``          — compétence Conseil Départemental
* ``SOINS``               — compétence ARS
* ``SOINS_AUTONOMIE_SEA`` — fusion D+S quand l'ETS est en forfait
                            global unique (D-085 expérimentation 2026)

Sémantique des 5 statuts (workflow row-level) :

* ``PROPOSE``           — tarif déposé par l'ESMS (default à l'insert)
* ``VALIDE_ARS``        — ARS a validé (CD pas encore)
* ``VALIDE_CD``         — CD a validé (ARS pas encore)
* ``VALIDE_TRIPARTITE`` — les deux ATC ont validé → row exécutoire
* ``REJETE``            — au moins une ATC a rejeté

``ecart = montant_notifie - montant_propose`` est GENERATED côté DB
(read-only côté plugin).
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from piilot_pack_compta_esms.services.validators import reject_pipe_char

# --------------------------------------------------------------------
# Allowed value sets — mirror the DB CHECK constraints (migration 020).
# --------------------------------------------------------------------

TarifSection = Literal[
    "HEBERGEMENT",
    "DEPENDANCE",
    "SOINS",
    "SOINS_AUTONOMIE_SEA",
]
"""4 sections DGCS (D-083 + D-085)."""

TarifStatut = Literal[
    "PROPOSE",
    "VALIDE_ARS",
    "VALIDE_CD",
    "VALIDE_TRIPARTITE",
    "REJETE",
]
"""Workflow row-level (distinct du workflow document §S)."""


# --------------------------------------------------------------------
# Base + Create + Update + Read
# --------------------------------------------------------------------


class TarifProposeBase(BaseModel):
    """Shared fields between Create / Update / Read."""

    # ``extra='forbid'`` only — pas de strict=True (laisse FastAPI
    # coercer les JSON strings → UUID / date / Decimal).
    model_config = ConfigDict(extra="forbid")

    etablissement_id: UUID = Field(..., description="ESMS rattaché (FK)")
    section: TarifSection
    libelle: str | None = Field(
        default=None,
        max_length=255,
        description="Sous-libellé optionnel (ex: 'GIR 1-2').",
    )
    montant_propose: Decimal = Field(
        ...,
        ge=Decimal("0"),
        description="Tarif prévisionnel saisi par l'ESMS.",
    )
    motif: str | None = Field(
        default=None,
        max_length=500,
        description="Justification libre de la proposition.",
    )

    _no_pipe = field_validator("libelle", "motif")(reject_pipe_char)


class TarifProposeCreate(TarifProposeBase):
    """Body of ``POST /documents/{doc_id}/tarifs-proposes``.

    ``document_id`` provient du path, pas du body. ``statut`` est
    initialisé à ``PROPOSE`` par défaut (pas surchargeable au create —
    une row ne peut pas être créée déjà validée, on passe par PATCH).
    """


class TarifProposeUpdate(BaseModel):
    """Body of ``PATCH /tarifs-proposes/{tarif_id}``.

    Permet à la fois la mise à jour du tarif proposé par l'ESMS (avant
    notification) et celle des champs ATC (``montant_notifie``,
    ``statut``, ``date_validation``, ``valide_par``, ``motif_rejet``).
    L'enforcement "qui peut éditer quoi" est appliqué au service
    layer en fonction du statut courant.

    ``etablissement_id`` et ``section`` ne sont pas mutables — moving
    a row vers un autre ETS ou section briserait l'UNIQUE et les audit
    trails. Pour "déplacer" : delete + create.
    """

    model_config = ConfigDict(extra="forbid")

    libelle: str | None = Field(default=None, max_length=255)
    montant_propose: Decimal | None = Field(default=None, ge=Decimal("0"))
    montant_notifie: Decimal | None = Field(default=None, ge=Decimal("0"))
    motif: str | None = Field(default=None, max_length=500)
    statut: TarifStatut | None = None
    date_validation: date | None = None
    valide_par: str | None = Field(default=None, max_length=255)
    motif_rejet: str | None = Field(default=None, max_length=1000)

    _no_pipe = field_validator("libelle", "motif", "valide_par", "motif_rejet")(reject_pipe_char)


class TarifProposeBulkItem(BaseModel):
    """Element of ``POST /documents/{doc_id}/tarifs-proposes:bulk-upsert``.

    Permet à l'UI d'envoyer la grille tarifaire complète (jusqu'à 4
    rows par ETS × N ETS du document) en un seul appel. ``section``
    + ``etablissement_id`` agissent comme clé naturelle pour
    l'UPSERT côté repo.
    """

    model_config = ConfigDict(extra="forbid")

    etablissement_id: UUID
    section: TarifSection
    libelle: str | None = Field(default=None, max_length=255)
    montant_propose: Decimal = Field(..., ge=Decimal("0"))
    motif: str | None = Field(default=None, max_length=500)

    _no_pipe = field_validator("libelle", "motif")(reject_pipe_char)


class TarifProposeRead(TarifProposeBase):
    """Body of ``GET /tarifs-proposes/{tarif_id}``."""

    id: UUID
    company_id: UUID
    document_id: UUID
    montant_notifie: Decimal | None
    ecart: Decimal | None = Field(
        default=None,
        description="GENERATED — montant_notifie - montant_propose. NULL " "tant que non notifié.",
    )
    statut: TarifStatut
    date_validation: date | None
    valide_par: str | None
    motif_rejet: str | None
    created_at: datetime
    updated_at: datetime


TarifPropose = TarifProposeRead


# --------------------------------------------------------------------
# Validation report (§BD C1 R.314-222)
# --------------------------------------------------------------------


class TarifSectionAggregate(BaseModel):
    """Aggregate par section pour un document EPRD.

    Consommé par §BD C1 ``validate_equilibre_reel(document_id)`` qui
    compare ``total_propose`` et ``total_notifie`` par section pour
    vérifier la condition R.314-222 "produits de la tarification =
    ceux notifiés".
    """

    model_config = ConfigDict(extra="forbid")

    section: TarifSection
    rows_count: int = Field(..., ge=0)
    total_propose: Decimal = Field(..., ge=Decimal("0"))
    total_notifie: Decimal | None = Field(
        default=None,
        description="NULL si au moins une row n'a pas encore été notifiée.",
    )
    ecart: Decimal | None = Field(
        default=None,
        description="total_notifie - total_propose. NULL si non notifié.",
    )
    all_validated_tripartite: bool = Field(
        ...,
        description="True quand chaque row de la section est en " "VALIDE_TRIPARTITE.",
    )


class TarifValidationReport(BaseModel):
    """Returned by ``GET /documents/{doc_id}/tarifs-proposes:validate``.

    Synthèse par section pour le widget UI + entrée du futur §BD C1.
    """

    model_config = ConfigDict(extra="forbid")

    document_id: UUID
    sections: list[TarifSectionAggregate]
    total_rows: int = Field(..., ge=0)
    all_sections_tripartite: bool = Field(
        ...,
        description="True ssi toutes les sections présentes ont "
        "all_validated_tripartite=True. False si une row reste à "
        "valider OU si une row est REJETE.",
    )
    has_rejected_rows: bool = Field(
        ...,
        description="True si au moins une row est en statut REJETE.",
    )
