"""Document budgétaire Pydantic models.

A document is a budgetary act attached to an exercice — EPRD/ERRD
(annual main acts), DM (decision modificative, mid-year adjustment),
RIA (rapport infra-annuel), ERCP/EPCP (sanitary equivalents), AVENANT
(cofinancing amendment). Cf. L1 schema lines 109-138.

Parent-child rules (enforced by the service layer using
:data:`PARENT_REQUIRED` and :data:`PARENT_FORBIDDEN`) :

* DM and RIA **require** an EPRD parent — a DM/RIA without a parent
  has no sense in the budget cycle.
* EPRD, ERRD, ERCP, EPCP, AVENANT have no parent.

Status transitions are managed by §X (workflow chantier). All
documents created here are pinned to ``brouillon`` ; the spec's
``POST /documents/{id}/transitions`` and ``GET /documents/{id}/transitions-allowed``
endpoints (§4.6 + §4.7) live in §X, not §E.3.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator

TypeDocument = Literal["eprd", "errd", "dm", "ria", "ercp", "epcp", "avenant"]
"""Cf. L1 ligne 113-115."""

StatutDocument = Literal[
    "brouillon",
    "transmis",
    "en_instruction",
    "executoire",
    "rejete",
    "affectation_definie",
]
"""Cf. L1 ligne 118-121. ``affectation_definie`` is ERRD-only.

In §E.3 a document is always created with ``brouillon`` ; status
mutations live in §X (transitions workflow).
"""

# Types that must reference an EPRD parent.
PARENT_REQUIRED: frozenset[str] = frozenset({"dm", "ria"})
# Types that must NOT have a parent.
PARENT_FORBIDDEN: frozenset[str] = frozenset({"eprd", "errd", "ercp", "epcp", "avenant"})
# Acceptable parent types for clone targets (only EPRD can spawn DM/RIA).
ALLOWED_PARENT_TYPES: frozenset[str] = frozenset({"eprd"})


class DocumentCreate(BaseModel):
    """Body of ``POST /documents`` (L2 §4.2).

    The body carries ``exercice_id``, ``type_document`` and an
    optional ``parent_id`` (mandatory for DM/RIA, forbidden for the
    others — enforced by the validator below).

    ``cadre_version`` is optional ; the service auto-derives a stable
    default from ``(type, annee)`` when omitted. RIA-specific dates
    (``periode_observation_debut/fin``) sit here too — they're
    irrelevant for other types but FastAPI doesn't have a clean way
    to do per-discriminator-value bodies without a union explosion,
    so we accept them on every type and validate downstream.
    """

    model_config = ConfigDict(extra="forbid")

    exercice_id: UUID
    type_document: TypeDocument
    parent_id: UUID | None = None
    cadre_version: str | None = Field(default=None, max_length=80)
    cr_variante: Literal["soumis_equilibre", "non_soumis_equil"] = Field(
        default="non_soumis_equil",
        description=(
            "Variant of the auto-created CRPP (D-073). 'non_soumis_equil' "
            "is the default — only EPS soumis à équilibre opt into the other."
        ),
    )
    periode_observation_debut: date | None = None
    periode_observation_fin: date | None = None

    @model_validator(mode="after")
    def _enforce_parent_rule(self) -> DocumentCreate:
        """Cross-field rule : DM/RIA require parent_id, others forbid it."""
        if self.type_document in PARENT_REQUIRED and self.parent_id is None:
            raise ValueError(
                f"type_document='{self.type_document}' requires parent_id "
                "(must reference an EPRD)"
            )
        if self.type_document in PARENT_FORBIDDEN and self.parent_id is not None:
            raise ValueError(f"type_document='{self.type_document}' forbids parent_id")
        return self

    @model_validator(mode="after")
    def _ria_periode_consistency(self) -> DocumentCreate:
        """If one RIA date is set, the other must be set too, and start ≤ end."""
        debut = self.periode_observation_debut
        fin = self.periode_observation_fin
        if (debut is None) ^ (fin is None):
            raise ValueError(
                "periode_observation_debut and periode_observation_fin must " "be set together"
            )
        if debut is not None and fin is not None and debut > fin:
            raise ValueError(
                "periode_observation_debut must be on or before " "periode_observation_fin"
            )
        return self


class DocumentUpdate(BaseModel):
    """Body of ``PATCH /documents/{id}`` (L2 §4.4).

    Limited to "metadata" — RIA observation window and the (rare)
    cadre_version override. Anything else (status, transmis_at,
    executoire_at, parent_id, type_document, exercice_id) is either
    immutable or handled by the workflow chantier (§X).
    """

    model_config = ConfigDict(extra="forbid")

    cadre_version: str | None = Field(default=None, max_length=80)
    periode_observation_debut: date | None = None
    periode_observation_fin: date | None = None

    @model_validator(mode="after")
    def _ria_periode_consistency(self) -> DocumentUpdate:
        debut = self.periode_observation_debut
        fin = self.periode_observation_fin
        # Only enforce when both are explicitly provided ; a one-sided
        # patch is rejected because that would leave the doc in an
        # inconsistent state at the DB.
        if debut is not None and fin is not None and debut > fin:
            raise ValueError(
                "periode_observation_debut must be on or before " "periode_observation_fin"
            )
        return self


class DocumentClone(BaseModel):
    """Body of ``POST /documents/{id}/clone`` (L2 §4.8).

    Only DM and RIA can be spawned from an EPRD parent. The spec
    explicitly lists these two as the valid ``new_type`` values.
    """

    model_config = ConfigDict(extra="forbid")

    new_type: Literal["dm", "ria"]
    periode_observation_debut: date | None = None
    periode_observation_fin: date | None = None
    cr_variante: Literal["soumis_equilibre", "non_soumis_equil"] = "non_soumis_equil"

    @model_validator(mode="after")
    def _ria_periode_consistency(self) -> DocumentClone:
        debut = self.periode_observation_debut
        fin = self.periode_observation_fin
        if (debut is None) ^ (fin is None):
            raise ValueError(
                "periode_observation_debut and periode_observation_fin must " "be set together"
            )
        if debut is not None and fin is not None and debut > fin:
            raise ValueError(
                "periode_observation_debut must be on or before " "periode_observation_fin"
            )
        return self


class DocumentRead(BaseModel):
    """Body of ``GET /documents/{id}`` — full DB row.

    The L2 spec's ``?include=crp_lignes,pgfp_lignes,controles`` query
    parameter is not honored in §E.3 — sub-table inflation lands when
    those sub-tables ship (§E.4 for CRs, §H for lignes CRP, §Z for
    controles). The bare document is enough to drive the §AD frontend
    "Documents" tab.
    """

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    exercice_id: UUID
    type_document: TypeDocument
    cadre_version: str
    parent_id: UUID | None
    statut: StatutDocument
    periode_observation_debut: date | None
    periode_observation_fin: date | None
    transmis_at: datetime | None
    executoire_at: datetime | None
    transmis_par_user_id: UUID | None
    created_at: datetime
    updated_at: datetime


Document = DocumentRead
