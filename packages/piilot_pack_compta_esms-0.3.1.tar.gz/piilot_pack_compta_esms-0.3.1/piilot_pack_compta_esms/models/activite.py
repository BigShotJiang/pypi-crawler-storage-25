"""Annexe 4 Activité GIR (§Q, L2 §12).

Annexe 4 (R.314-219 CASF) = activité prévisionnelle de l'EPRD.
Annexe 9 = pendant réalisé de l'ERRD (KB19).

Le DDL :data:`activite_lignes` unifie les 2 via :data:`AnnexeVariante`
(8 valeurs : 4 prévisionnel ``4A_*``..``4D_*`` + 4 réalisé ``9A_*``..``9D_*``).

4 sous-annexes (D-098 colonnes temporelles différenciées) :

* **4A/9A** : EHPAD + AJA — sections HP/HT/AJ, GIR 1-6 obligatoires (D-049)
* **4B/9B** : Autres ESMS (L.313-12-2) — sections externat/semi_internat/internat,
  pas de GIR
* **4C/9C** : Creton (L.242-4) — détail différé v0.5, ``mode_creton``
  flag seul ici (D-097)
* **4D/9D** : SAAD — sections soins_domicile/aide_domicile

Plage ``annee_offset`` (Q10, D-098) :

* Annexe 4 prévisionnel : N-4 → N → ``annee_offset`` ∈ [-4, 0]
* Annexe 9 réalisé : N-3 → N → idem

Sémantique bulk-upsert (Q1) : **replace_by_(doc, ets, annexe_variante)**
(cohérent §P/§K/§N). Le payload top-level scope ``{ets_id,
annexe_variante, items}`` ne touche QUE l'onglet ciblé.

:compute-theorique (Q3+Q4, D-051) : ``nombre_journees = capacite_financee
× amplitude_ouverture``. Idempotent UPSERT par ``(doc, ets, annexe,
section, annee_offset, nature='theorique')``. 1 ligne par section
relevante × 5 années (N-4 → N).

Permissions L2 §12 strict (Q12) : **user partout**.
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

AnnexeVariante = Literal[
    "4A_ehpad_puv",
    "4B_autres_essms",
    "4C_creton",
    "4D_sad_spasad",
    "9A_ehpad_realise",
    "9B_autres_realise",
    "9C_creton_realise",
    "9D_sad_realise",
]
"""DDL §D.6 — CHECK 8 valeurs (4 prévisionnel + 4 réalisé)."""

Section = Literal[
    "hp",
    "ht",
    "aj",
    "externat",
    "semi_internat",
    "internat",
    "soins_domicile",
    "aide_domicile",
]
"""DDL §D.6 — CHECK 8 valeurs. Cohérence section ↔ annexe_variante
fail-open §Q (validée en §Z) — KB19 §2 routage :

* 4A/9A → hp/ht/aj
* 4B/9B → externat/semi_internat/internat
* 4D/9D → soins_domicile/aide_domicile
"""

Gir = Literal[
    "gir1",
    "gir2",
    "gir3",
    "gir4",
    "gir5",
    "gir6",
    "plus_60",
    "moins_60",
    "non_gire",
]
"""DDL §D.6 — CHECK 9 valeurs (D-049). Obligatoire EHPAD (4A/9A),
NULL Autres ESMS (4B/9B)."""

NatureDonnee = Literal["prevu", "realise", "theorique"]
"""DDL §D.6 — CHECK 3 valeurs. ``theorique`` posé par
:compute-theorique uniquement, jamais via :bulk-upsert."""


# ---------------------------------------------------------------------------
# Create / Bulk
# ---------------------------------------------------------------------------


class ActiviteLigneCreate(BaseModel):
    """Item du bulk-upsert. ``ets_id`` et ``annexe_variante`` ne sont
    PAS dans l'item — ils viennent du :class:`ActiviteBulkUpsertRequest`
    top-level (Q2)."""

    model_config = ConfigDict(extra="forbid")

    section: Section
    gir: Gir | None = None
    """Q8 — nullable. EHPAD (4A/9A) doit avoir GIR, Autres NULL.
    Validation cohérence → §Z."""
    annee_offset: int = Field(..., ge=-4, le=0)
    """Q10 — D-098 : Annexe 4 N-4→N, Annexe 9 N-3→N. Range [-4, 0]."""
    nature_donnee: NatureDonnee
    """Q3 — ``theorique`` réservé à :compute-theorique."""
    mode_creton: bool = False
    """Q9 — D-097 flag, seul Creton (4C/9C) doit avoir True."""
    nombre_places: int | None = Field(default=None, ge=0)
    nombre_personnes: int | None = Field(default=None, ge=0)
    nombre_journees: int | None = Field(default=None, ge=0)
    # D-050 — absences <72h vs ≥72h × convenance/hospi
    absences_moins72h_convenance: int | None = Field(default=None, ge=0)
    absences_moins72h_hospi: int | None = Field(default=None, ge=0)
    absences_plus72h_convenance: int | None = Field(default=None, ge=0)
    absences_plus72h_hospi: int | None = Field(default=None, ge=0)
    hors_departement_count: int | None = Field(default=None, ge=0)
    beneficiaires_aide_sociale: int | None = Field(default=None, ge=0)


class ActiviteBulkUpsertRequest(BaseModel):
    """Body de ``POST /documents/{doc_id}/activite:bulk-upsert``.

    Sémantique Q1 : **replace_by_(doc, ets, annexe_variante)** — DELETE
    WHERE doc+ets+annexe + INSERT batch atomique. Ne touche QUE
    l'onglet ciblé."""

    model_config = ConfigDict(extra="forbid")

    ets_id: UUID
    annexe_variante: AnnexeVariante
    items: list[ActiviteLigneCreate] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Compute Théorique (Q3+Q4, D-051)
# ---------------------------------------------------------------------------


class ActiviteComputeTheoriqueRequest(BaseModel):
    """Body de ``POST /documents/{doc_id}/activite:compute-theorique``.

    Q3 — Calcule ``nombre_journees = capacite_financee × amplitude_ouverture``
    pour les 5 années (N-4 → N) × sections relevantes de l'annexe."""

    model_config = ConfigDict(extra="forbid")

    ets_id: UUID
    annexe_variante: AnnexeVariante
    """Détermine les sections à matérialiser : 4A/9A → hp/ht/aj,
    4B/9B → externat/semi_internat/internat, etc."""


class ActiviteComputeTheoriqueResponse(BaseModel):
    """Counts retournés post-compute (pattern §H.6/§P prefill semantics)."""

    model_config = ConfigDict(extra="forbid")

    capacite_financee: int
    amplitude_ouverture: int
    nombre_journees_theorique: int
    """capacite_financee × amplitude_ouverture — valeur identique sur
    toutes les sections × années (avant pondération mensuelle B-30
    différée)."""
    inserted: int
    updated: int


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------


class ActiviteLigneRead(BaseModel):
    """Row complet de ``compta_esms.activite_lignes``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    etablissement_id: UUID
    annexe_variante: AnnexeVariante
    mode_creton: bool
    section: Section
    gir: Gir | None
    annee_offset: int
    nature_donnee: NatureDonnee
    nombre_places: int | None
    nombre_personnes: int | None
    nombre_journees: int | None
    absences_moins72h_convenance: int | None
    absences_moins72h_hospi: int | None
    absences_plus72h_convenance: int | None
    absences_plus72h_hospi: int | None
    hors_departement_count: int | None
    beneficiaires_aide_sociale: int | None
    created_at: datetime
    updated_at: datetime


class ActiviteResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/activite``.

    ``ets_id_filtre`` / ``annexe_filtre`` reflètent les query params
    (``None`` si non filtré)."""

    model_config = ConfigDict(extra="forbid")

    ets_id_filtre: UUID | None
    annexe_filtre: AnnexeVariante | None
    items: list[ActiviteLigneRead]
