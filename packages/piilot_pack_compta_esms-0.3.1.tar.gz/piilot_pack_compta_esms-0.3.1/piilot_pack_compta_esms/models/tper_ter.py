"""TPER / TER (effectifs) — §P, L2 §11.

TPER = Tableau Prévisionnel des Effectifs Rémunérés (annexe 6,
R.314-223) — pendant **prévisionnel** dans l'EPRD.

TER = Tableau des Effectifs Réels (annexe 9H/9I/9J, R.314-232) —
pendant **réalisé** dans l'ERRD.

Le DDL :data:`tper_ter_lignes` unifie les 2 via :data:`TypeTableau`.

3 sous-annexes différentes selon le pendant :

* TPER : 6A (EHPAD), 6B (ESSMS PH cofinancé ARS+CD), 6C (ESMS PH ARS
  exclusif) — D-046
* TER : 9H (EHPAD-AJA), 9I (FAM-SAMSAH), 9J (Autres ESSMS) — D-043
  + D-044

Côté plugin : 1 :data:`TypeEtablissement` Literal 4 valeurs (ehpad_aja,
fam_samsah, autre_essms, sad_spasad) couvre les 2 mappings (TPER 6A
= TER 9H = ``ehpad_aja``, etc.). Le routage UI selon mode_tarification
est différé.

Référentiel CNSA (D-043+D-044) via PLT-44 KB core
``com.piilot.core.cnsa-fonctions-esms`` — 10 catégories EHPAD + 8
FAM-SAMSAH/Autres × ~50 fonctions chacune. Validation fail-open par
:mod:`reference_lookup` (cohérent §H.4).

Sémantique bulk-upsert (Q3) : **replace_by_(document, ets, type_tableau)**
— DELETE WHERE doc+ets+type + INSERT batch atomique (cohérent §K Bilan
+ §N emprunts pour onglets coexistants). Payload top-level
``{ets_id, type_tableau, items: [...]}``.

ETPR/ETPT (D-045) stockés tels quels — formule officielle
``ETPT = ETPR - sur_rem_temps_partiels_publics - personnel_remplacement``
appliquée par le cabinet à la saisie ou validée en §Z.

Permissions L2 §11 strict : **user partout** (différent §K/§N qui
exigent builder pour mutations).
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

TypeTableau = Literal["TPER", "TER"]
"""DDL §D.5 — CHECK constraint. TPER = prévisionnel (annexe 6),
TER = réalisé (annexe 9H/9I/9J)."""

TypeEtablissement = Literal[
    "ehpad_aja",
    "fam_samsah",
    "autre_essms",
    "sad_spasad",
]
"""DDL §D.5 — CHECK 4 valeurs. Auto-déduit par le service via
:func:`reference_lookup.deduce_type_etablissement` depuis
``etablissements.typologie``."""

TypePoste = Literal["P", "T"]
"""P (Permanent) / T (Temporaire). Migration 012 patch DDL
(L1 + plugin omettaient initialement, cf. 18-annexe6 §4.2)."""

SectionImputation = Literal[
    "hebergement",
    "dependance",
    "soins",
    "soins_autonomie",
    "forfait_soins",
    "mixte",
]
"""DDL §D.5 — CHECK 6 valeurs. ``soins_autonomie`` = forfait global
unique D-085 EHPAD (fusion D+S)."""


# ---------------------------------------------------------------------------
# Create / Bulk
# ---------------------------------------------------------------------------


class TperTerLigneCreate(BaseModel):
    """Item du bulk-upsert. ``ets_id`` et ``type_tableau`` ne sont PAS
    dans l'item — ils viennent du :class:`TperTerBulkUpsertRequest`
    top-level parce qu'un bulk-upsert ne touche qu'un seul
    (doc, ets, type_tableau) à la fois."""

    model_config = ConfigDict(extra="forbid")

    categorie_cnsa: str = Field(..., min_length=1, max_length=64)
    fonction: str | None = Field(default=None, max_length=255)
    type_poste: TypePoste
    etpr_prevus: Decimal | None = None
    etpt_prevus: Decimal | None = None
    etpr_realises: Decimal | None = None
    etpt_realises: Decimal | None = None
    remunerations_prevues: Decimal | None = None
    remunerations_realisees: Decimal | None = None
    section_imputation: SectionImputation | None = None
    pct_section: Decimal | None = Field(default=None, ge=0, le=100)


class TperTerBulkUpsertRequest(BaseModel):
    """Body de ``POST /documents/{doc_id}/tper-ter:bulk-upsert``.

    Sémantique Q3 : **replace_by_(doc, ets, type_tableau)** — DELETE
    WHERE doc+ets+type + INSERT batch atomique. Ne touche QUE l'onglet
    cible. Les autres onglets (autre type_tableau ou autre ets) sont
    préservés."""

    model_config = ConfigDict(extra="forbid")

    ets_id: UUID
    type_tableau: TypeTableau
    items: list[TperTerLigneCreate] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Prefill (Q5 — binding journal paie L2 §11.3 strict)
# ---------------------------------------------------------------------------


class TperTerPrefillRequest(BaseModel):
    """Body de ``POST /documents/{doc_id}/tper-ter:prefill``.

    Q5 — §P livre uniquement le **mode binding journal paie** (L2 §11.3
    strict). Service ``import_tper_to_ter()`` (D-047) différé."""

    model_config = ConfigDict(extra="forbid")

    ets_id: UUID
    type_tableau: TypeTableau


class TperTerPrefillResponse(BaseModel):
    """Counts retournés post-prefill (pattern §H.6 cohérent)."""

    model_config = ConfigDict(extra="forbid")

    inserted: int
    updated: int
    skipped: int


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------


class TperTerLigneRead(BaseModel):
    """Row complet de ``compta_esms.tper_ter_lignes``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    etablissement_id: UUID
    type_tableau: TypeTableau
    type_etablissement: TypeEtablissement
    categorie_cnsa: str
    fonction: str | None
    type_poste: TypePoste
    etpr_prevus: Decimal | None
    etpt_prevus: Decimal | None
    etpr_realises: Decimal | None
    etpt_realises: Decimal | None
    remunerations_prevues: Decimal | None
    remunerations_realisees: Decimal | None
    section_imputation: SectionImputation | None
    pct_section: Decimal | None
    created_at: datetime
    updated_at: datetime


class TperTerResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/tper-ter``.

    ``ets_id_filtre`` / ``type_tableau_filtre`` reflètent les query
    params (``None`` si non filtré)."""

    model_config = ConfigDict(extra="forbid")

    ets_id_filtre: UUID | None
    type_tableau_filtre: TypeTableau | None
    items: list[TperTerLigneRead]


# ---------------------------------------------------------------------------
# Totals (Q7 — L2 §11.4 "par catégorie + section")
# ---------------------------------------------------------------------------


class TperTerCategorieTotals(BaseModel):
    """Sous-total par catégorie CNSA. Σ ETPR/ETPT/rémunérations sur
    toutes les fonctions × P/T de la catégorie."""

    model_config = ConfigDict(extra="forbid")

    categorie_cnsa: str
    etpr_prevus: Decimal
    etpt_prevus: Decimal
    etpr_realises: Decimal
    etpt_realises: Decimal
    remunerations_prevues: Decimal
    remunerations_realisees: Decimal


class TperTerSectionTotals(BaseModel):
    """Sous-total par section_imputation. Σ ETPR/rémunérations
    pondérées par ``pct_section`` (l'imputation est partielle —
    une ligne ASH peut être 70% Hébergement + 30% Dépendance)."""

    model_config = ConfigDict(extra="forbid")

    section_imputation: SectionImputation
    etpr_prevus_ventile: Decimal
    etpr_realises_ventile: Decimal
    remunerations_prevues_ventilees: Decimal
    remunerations_realisees_ventilees: Decimal


class TperTerTotalsResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/tper-ter:totals``.

    L2 §11.4 explicite : "Totaux par catégorie + section"."""

    model_config = ConfigDict(extra="forbid")

    by_categorie: list[TperTerCategorieTotals]
    by_section: list[TperTerSectionTotals]
    total_etpr_prevus: Decimal
    total_etpt_prevus: Decimal
    total_etpr_realises: Decimal
    total_etpt_realises: Decimal
    total_remunerations_prevues: Decimal
    total_remunerations_realisees: Decimal
