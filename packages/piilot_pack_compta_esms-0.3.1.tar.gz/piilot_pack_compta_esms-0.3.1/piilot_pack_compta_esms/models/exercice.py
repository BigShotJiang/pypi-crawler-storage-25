"""Exercice (budget year) Pydantic models.

An exercice is a budget year scoped to an OG. The schema enforces
``UNIQUE (company_id, og_id, annee)`` so a single OG can't have two
exercices for the same year, and a CHECK that confines ``annee`` to
``[current_year - 1, current_year + 1]`` (D-104 — the regulator only
ever asks for adjacent-year budget documents).

The ``millesime_m22bis`` column captures which DGCS plan-comptable
millésime applies. The DGCS publishes a new millésime each
January-February, applicable for the rest of the calendar year — so
the default is ``f"{annee - 1}-{annee}"`` (e.g. annee=2026 → 2025-2026).
The service auto-derives it; the API only requires ``annee``. Callers
can override the millésime explicitly if needed (eg. retroactive
correction during a transitional period).

Cf. L1 schema lines 85-102.
"""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class ExerciceCreate(BaseModel):
    """Body of ``POST /orgs/{og_id}/exercices``.

    The path carries the parent ``og_id`` — no need to repeat it in
    the body. ``millesime_m22bis`` is optional ; when omitted, the
    service derives it from ``annee``.
    """

    model_config = ConfigDict(extra="forbid")

    annee: int = Field(..., description="Year of the exercice (D-104: N-1, N, or N+1)")
    millesime_m22bis: str | None = Field(
        default=None,
        max_length=20,
        description=(
            "Optional override for the M22Bis millésime (e.g. '2025-2026'). "
            "Auto-derived from `annee` when omitted."
        ),
    )


class ExerciceRead(BaseModel):
    """Body of ``GET /exercices/{id}`` — full DB row.

    Has only ``created_at`` — :mod:`L1` doesn't put an ``updated_at``
    column on this table (an exercice is essentially immutable once
    opened : changing the year would break document chronology).
    """

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    og_id: UUID
    annee: int
    millesime_m22bis: str
    created_at: datetime


Exercice = ExerciceRead
