"""Affectation résultats (§J, L2 §10, D-082).

L'affectation se fait sur l'ERRD en fin d'exercice : le résultat
réalisé (A. RESULTAT A AFFECTER) est ventilé entre des comptes
d'affectation (reports à nouveau, réserves, charges rejetées…).
Le contrôle C-79/C-80 (DGCS) vérifie que Σ affectations = résultat.

Variantes D-082 (mécaniques, déduites de l'OG) :

* ``prive_I`` — privé hors CPOM, par ESSMS (tableau ternaire H/D/S
  une colonne par établissement). ``cr_id`` obligatoire.
* ``prive_II`` — privé inclus CPOM, consolidé document (globalisation).
  ``cr_id`` NULL.
* ``public_I`` — public hors CPOM, par ESSMS, plan comptable public
  (comptes 12, 110, 119, 10682-10687). ``cr_id`` obligatoire.
* ``public_II`` — public inclus CPOM, consolidé document. ``cr_id`` NULL.

Ventilation D-083 : déduite de ``cr.ventilation`` (``ternaire_hds`` =
EHPAD ternaire H/D/S, ``simple`` = autres). Le service §J.7 valide
la cohérence cr ↔ affectation.

La formule plan-dev §7.5 ``compute_resultats_bruts`` simplifie la
formule complète 25-deepdive §4.1 (qui inclut reports antérieurs +
diminutions/augmentations) pour v0.2 — les "reports antérieurs"
remontent du suivi_affectations N-1 et arrivent en §X workflow.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from piilot_pack_compta_esms.services.validators import reject_pipe_char

Variante = Literal["prive_I", "prive_II", "public_I", "public_II"]
"""D-082 — 4 variantes mécaniques (statut juridique × inclus CPOM)."""

Ventilation = Literal["ternaire_hds", "simple"]
"""D-083 — déduit de ``cr.ventilation`` au moment du PUT."""


# ---------------------------------------------------------------------------
# Items du PUT bulk
# ---------------------------------------------------------------------------


class AffectationItemCreate(BaseModel):
    """Un item du bulk PUT. Le service auto-déduit ``variante`` et
    ``ventilation`` depuis le contexte (OG + CR). ``cr_id`` est :

    * obligatoire pour les variantes ``prive_I`` / ``public_I``
      (validation service),
    * nullable pour ``prive_II`` / ``public_II`` (consolidé).

    Les 3 montants sont des Decimal optionnels :

    * ``montant_soins_dependance`` — colonne S+D du tableau ternaire
      (EHPAD) ou côté Soins (autres ESSMS),
    * ``montant_hebergement`` — colonne H,
    * ``montant_total`` — ligne TOTAL (= S+D + H pour ternaire,
      = colonne unique pour ``simple``).
    """

    model_config = ConfigDict(extra="forbid")

    compte_m22bis: str = Field(..., min_length=1, max_length=32)
    compte_label: str | None = Field(default=None, max_length=255)
    cr_id: UUID | None = None
    montant_soins_dependance: Decimal | None = None
    montant_hebergement: Decimal | None = None
    montant_total: Decimal | None = None

    # D-075 — pipe char interdit dans le libellé compte
    _no_pipe = field_validator("compte_label")(reject_pipe_char)


class AffectationBulkRequest(BaseModel):
    """Body de ``PUT /documents/{doc_id}/affectations``.

    Le service ne lit pas ``variante`` ni ``ventilation`` depuis le
    body — ces deux champs sont **auto-déduits** (Q3 + Q4) depuis le
    contexte. Le cabinet n'envoie que les items + leur cr_id éventuel.
    """

    model_config = ConfigDict(extra="forbid")

    items: list[AffectationItemCreate] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Lecture
# ---------------------------------------------------------------------------


class AffectationRead(BaseModel):
    """Row complet de ``compta_esms.affectations_resultats``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    variante: Variante
    ventilation: Ventilation
    cr_id: UUID | None
    compte_m22bis: str
    compte_label: str | None
    montant_soins_dependance: Decimal | None
    montant_hebergement: Decimal | None
    montant_total: Decimal | None
    created_at: datetime
    updated_at: datetime


# ---------------------------------------------------------------------------
# Résultat à affecter (A) — calculé à la volée (Q1+Q2)
# ---------------------------------------------------------------------------


class ResultatBrutBySection(BaseModel):
    """``A. RESULTAT A AFFECTER`` calculé par section (= par CR pour
    variant_I, agrégé pour variant_II).

    Formule v0.2 (plan-dev §7.5 simplification) :
    ``resultat_brut = sum(produits.realise) - sum(charges.realise)``.

    La formule complète 25-deepdive §4.1 (Reports antérieurs +
    Diminutions/Augmentations) est reportée à §X workflow
    transitions où l'on aura accès au suivi_affectations N-1.
    """

    model_config = ConfigDict(extra="forbid")

    cr_id: UUID | None  # NULL pour le total consolidé (variant_II)
    cr_denomination: str | None
    total_charges_realise: Decimal
    total_produits_realise: Decimal
    resultat_brut: Decimal


# ---------------------------------------------------------------------------
# Validation Σ B == A (Q5 tolérance 0.01€)
# ---------------------------------------------------------------------------


ValidationIssueCode = Literal[
    "section_unaffected",
    "ecart_above_tolerance",
    "missing_cr_id",
    "unknown_compte",
]
"""Code stable pour les issues remontées par :validate.

* ``section_unaffected`` — une section a un resultat_brut != 0 mais
  aucune affectation,
* ``ecart_above_tolerance`` — Σ B ≠ A au-delà de 0,01€,
* ``missing_cr_id`` — variant_I sans cr_id (cabinet a oublié),
* ``unknown_compte`` — compte_m22bis pas dans la KB ref PLT-M21
  (warning, fail-open).
"""


class ValidationIssue(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: ValidationIssueCode
    cr_id: UUID | None = None
    message: str
    ecart: Decimal | None = None


class AllocationValidationResult(BaseModel):
    """Body de ``POST .../affectations:validate``.

    ``valide=true`` ssi toutes les sections sont affectées ET le
    contrôle C-79/C-80 (Σ B = A par section, tolérance 0,01€) passe."""

    model_config = ConfigDict(extra="forbid")

    valide: bool
    issues: list[ValidationIssue]
    tolerance_appliquee: Decimal


# ---------------------------------------------------------------------------
# Réponse GET /affectations — items + A par section + verdict
# ---------------------------------------------------------------------------


class AffectationsResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/affectations`` et de
    ``PUT /affectations``.

    Combine la liste des affectations persistées + le A calculé par
    section + un verdict de validation pré-calculé pour que l'UI
    n'ait pas à appeler ``:validate`` en plus."""

    model_config = ConfigDict(extra="forbid")

    variante_active: Variante | None
    ventilation_active: Ventilation | None
    items: list[AffectationRead]
    resultats_bruts: list[ResultatBrutBySection]
    validation: AllocationValidationResult


# ---------------------------------------------------------------------------
# Suivi affectations (D-084)
# ---------------------------------------------------------------------------


class SuiviAffectationRead(BaseModel):
    """Row de ``compta_esms.suivi_affectations``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    etablissement_id: UUID | None
    compte_m22bis: str
    solde_debut_n: Decimal | None
    mouvements_credit: Decimal | None
    mouvements_debit: Decimal | None
    solde_fin_n: Decimal | None
    created_at: datetime
