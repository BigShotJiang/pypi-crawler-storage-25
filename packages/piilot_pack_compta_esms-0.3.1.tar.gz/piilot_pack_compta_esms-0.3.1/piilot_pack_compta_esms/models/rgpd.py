"""Recueil consentement RGPD (§T, L2 §20, D-090).

Onglet facultatif **HORS CHAMP RÉGLEMENTAIRE** (warning non bloquant)
— stocke la réponse du gestionnaire à la question CNSA : autorise-t-il
la diffusion de son ERRD/EPRD à ses fédérations sectorielles ?

Cf. ``knowledge-base/25-deepdive-complement.md`` §22 + D-090.

Structure :

* Question 1 : ``consentement_cnsa: bool`` — la CNSA peut-elle
  communiquer les données ?
* Question 2 (uniquement si Q1=OUI) : ``federations`` — liste des
  fédérations cibles + 3 lignes libres pour fédérations hors liste.
* Question 3 : ``duree`` — durée du consentement.

Liste 17 fédérations sectorielles ESMS (D-074, plan-dev L1358) — pas
de KB référentielle core dédiée (la liste évolue très rarement, bump
plugin si nécessaire). À valider cabinet pilote ; ajustable v0.2.x
sans casser l'API tant qu'on ne supprime pas un code.

Pas de freeze §S applicable : le recueil RGPD est attaché à
l'exercice (pas à un document), peut être modifié/révoqué à tout
moment même après transmission ERRD.
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from piilot_pack_compta_esms.services.validators import reject_pipe_char

# ---------------------------------------------------------------------------
# Literal types
# ---------------------------------------------------------------------------

FederationCode = Literal[
    "MUTUALITE",
    "UNIOPSS",
    "UNAPEI",
    "NEXEM",
    "FNAQPA",
    "UNA",
    "UNCCAS",
    "FHF",
    "FEHAP",
    "SYNERPA",
    "APF",
    "APAJH",
    "GEPSO",
    "ANDICAT",
    "FNMF",
    "FPEP",
    "UGECAM",
]
"""17 fédérations sectorielles ESMS (D-074, plan-dev L1358).

Liste de référence cabinet pilote — peut évoluer en bump
plugin (ajout de code) sans casser l'API. Suppression d'un code
serait un changement breaking côté frontend.
"""

DureeConsentement = Literal["1_an", "5_ans", "jusqu_revocation"]
"""DDL §D.11 CHECK constraint (KB 25 §22 Q3)."""

_MAX_CUSTOM_FEDERATIONS = 3
"""KB 25 §22 — "3 lignes libres" pour les fédérations hors liste."""


# ---------------------------------------------------------------------------
# Sub-model — federations consenties
# ---------------------------------------------------------------------------


class FederationsConsenties(BaseModel):
    """Subdivision Pydantic du JSONB ``federations_consenties``.

    Sépare les codes Literal (validables côté frontend i18n) des
    libellés libres (3 max, free-form mais sans pipe char D-075).

    Format stocké en DB :

    .. code-block:: json

        {
          "selected_known": ["MUTUALITE", "FEHAP", "SYNERPA"],
          "selected_custom": ["FNADEPA Île-de-France", "Cluster XYZ"]
        }
    """

    model_config = ConfigDict(extra="forbid")

    selected_known: list[FederationCode] = Field(default_factory=list)
    """Codes du référentiel 17 fédérations. Dédoublonnage côté
    frontend ; on accepte les doublons en entrée (pas de validation
    Pydantic dessus — c'est de la cosmétique)."""

    selected_custom: list[str] = Field(
        default_factory=list,
        max_length=_MAX_CUSTOM_FEDERATIONS,
        description=(
            "Libellés libres pour fédérations hors référentiel. "
            "Max 3 (KB 25 §22). Caractère '|' interdit (D-075)."
        ),
    )

    @field_validator("selected_custom")
    @classmethod
    def _validate_custom(cls, values: list[str]) -> list[str]:
        # Chaque libellé : pipe char + non vide (strip).
        out: list[str] = []
        for v in values:
            stripped = v.strip()
            if not stripped:
                raise ValueError("selected_custom_entry_empty")
            if len(stripped) > 255:
                raise ValueError("selected_custom_entry_too_long")
            reject_pipe_char(stripped)
            out.append(stripped)
        return out


# ---------------------------------------------------------------------------
# Body — PUT /recueil-consentement
# ---------------------------------------------------------------------------


class RecueilConsentementUpdate(BaseModel):
    """Body de ``PUT /exercices/{exercice_id}/recueil-consentement``
    (L2 §20.2).

    Cohérence (KB 25 §22) :

    * Si ``consentement_cnsa=False``, ``federations.selected_known`` ET
      ``federations.selected_custom`` doivent être vides.
    * Si ``consentement_cnsa=True``, ``duree`` est obligatoire (l'UI
      DGCS force le choix d'une durée quand la diffusion est autorisée).
    """

    model_config = ConfigDict(extra="forbid")

    consentement_cnsa: bool
    federations: FederationsConsenties = Field(default_factory=FederationsConsenties)
    duree: DureeConsentement | None = None

    @model_validator(mode="after")
    def _validate_coherence(self) -> RecueilConsentementUpdate:
        if not self.consentement_cnsa:
            if self.federations.selected_known or self.federations.selected_custom:
                raise ValueError("federations_forbidden_when_cnsa_false")
            if self.duree is not None:
                # On accepte que la durée soit absente quand cnsa=false,
                # mais on rejette une durée explicite (incohérent).
                raise ValueError("duree_forbidden_when_cnsa_false")
        else:
            if self.duree is None:
                raise ValueError("duree_required_when_cnsa_true")
        return self


# ---------------------------------------------------------------------------
# Read — GET /recueil-consentement
# ---------------------------------------------------------------------------


class RecueilConsentementRead(BaseModel):
    """Row complet de ``compta_esms.recueil_consentement_rgpd``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    exercice_id: UUID
    consentement_cnsa: bool
    federations: FederationsConsenties
    duree: DureeConsentement | None = None
    consenti_par_user_id: UUID | None = None
    consenti_at: datetime | None = None
    revoque_at: datetime | None = None
