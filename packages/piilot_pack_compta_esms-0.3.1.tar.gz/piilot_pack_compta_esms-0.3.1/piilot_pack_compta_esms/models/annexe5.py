"""Annexe 5 Financière + paramètres forfait (§R, L2 §13).

Annexe 5 (R.314-219 CASF) = tableau de présentation tarifaire de
l'EPRD. 3 variantes :

* **5A EHPAD-AJA** — tarification ternaire H/D/S + section SEA
  optionnelle (D-054 forfait global unique)
* **5C FAM-SAMSAH** — forfait soins : 2 colonnes Budget global +
  dont Forfait soins
* **5D SAD-SPASAD** — ventilation Soins (c/731 AM) / Aide
  accompagnement à domicile (c/733 CD) (D-058)

**5B est un bloqueur résiduel B-31** (KB20 §11) : "Annexe 5B :
intégrée à 5A et 5C, ou modèle séparé ? Le fichier S10 ne contient
pas explicitement 5B". On suit le DDL = 3 valeurs.

**Pas d'Annexe 5 pour les autres typologies** (IME, ITEP, SESSAD,
CMPP, ESAT, MAS, etc.) — l'endpoint :bulk-upsert refuse 422
``annexe5_not_applicable`` via :func:`reference_lookup.deduce_variante_annexe5`.

Sémantique bulk-upsert (Q1) : **replace_by_(doc, ets, variante)**
cohérent §P/§Q. Payload top-level scope ``{ets_id, variante, items}``.

``forfait_parametres`` (§13.3/§13.4) : 1 row par (doc, ets). Contient
GMP/PMP/GMPS (forfait soins EHPAD, KB20 §5.2) + points GIR /
personnes girées / valeur point GIR (forfait dépendance EHPAD, D-052).
Spec implicite EHPAD-only mais §R laisse fail-open (Q8) — le cabinet
peut techniquement poser des params sur n'importe quel ets, sera
typiquement vide pour FAM/SAD.

Permissions (Q11) : §13.1+§13.2+§13.3 = user, **§13.4 PUT = builder**.

Validation D-056 (``Σ Résultat(H+D+S+SEA) = Résultat CRPP``) →
**différé §Z** (KB20 §5.7, service `validate_concordance_resultat_annexe5_vs_crp`
non câblé en endpoint §R).
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from piilot_pack_compta_esms.services.validators import reject_pipe_char

VarianteAnnexe5 = Literal["5A_ehpad", "5C_fam_samsah", "5D_sad_spasad"]
"""DDL §D.7 — CHECK 3 valeurs (KB20 §2). 5B = bloqueur B-31."""

NatureLigne = Literal["charge", "produit"]
"""DDL §D.7 — CHECK 2 valeurs."""


# ---------------------------------------------------------------------------
# Annexe 5 lignes — Create / Bulk
# ---------------------------------------------------------------------------


class Annexe5LigneCreate(BaseModel):
    """Item du bulk-upsert. ``ets_id`` et ``variante`` ne sont PAS dans
    l'item — ils viennent du :class:`Annexe5BulkUpsertRequest` top-level
    (Q2).

    Toutes les colonnes monétaires sont nullable (Q4 — le DDL accepte
    tout, le frontend remplit selon la variante : 5A→H/D/S/SEA × N1/N,
    5C→Budget global+Forfait soins × N1/N, 5D→Soins+Aide × N1/N)."""

    model_config = ConfigDict(extra="forbid")

    compte_m22bis: str = Field(..., min_length=1, max_length=32)
    compte_label: str | None = Field(default=None, max_length=255)
    nature: NatureLigne
    # 5A EHPAD — 8 colonnes (H / D / S / SEA × N1 / N)
    montant_hebergement_n1: Decimal | None = None
    montant_hebergement_n: Decimal | None = None
    montant_dependance_n1: Decimal | None = None
    montant_dependance_n: Decimal | None = None
    montant_soins_n1: Decimal | None = None
    montant_soins_n: Decimal | None = None
    montant_sea_n1: Decimal | None = None
    montant_sea_n: Decimal | None = None
    # 5C FAM-SAMSAH — 4 colonnes (Budget global + Forfait soins × N1 / N)
    montant_budget_global_n1: Decimal | None = None
    montant_budget_global_n: Decimal | None = None
    montant_forfait_soins_n1: Decimal | None = None
    montant_forfait_soins_n: Decimal | None = None
    # 5D SAD-SPASAD — 4 colonnes (Soins + Aide accompagnement × N1 / N)
    montant_soins_sad_n1: Decimal | None = None
    montant_soins_sad_n: Decimal | None = None
    montant_aide_acc_n1: Decimal | None = None
    montant_aide_acc_n: Decimal | None = None

    # D-075 — pipe char interdit dans le libellé compte
    _no_pipe = field_validator("compte_label")(reject_pipe_char)


class Annexe5BulkUpsertRequest(BaseModel):
    """Body de ``POST /documents/{doc_id}/annexe5:bulk-upsert``.

    Sémantique Q1 : **replace_by_(doc, ets, variante)** — DELETE
    WHERE doc+ets+variante + INSERT batch atomique."""

    model_config = ConfigDict(extra="forbid")

    ets_id: UUID
    variante: VarianteAnnexe5
    items: list[Annexe5LigneCreate] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Annexe 5 lignes — Read
# ---------------------------------------------------------------------------


class Annexe5LigneRead(BaseModel):
    """Row complet de ``compta_esms.annexe5_lignes``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    etablissement_id: UUID
    variante: VarianteAnnexe5
    compte_m22bis: str
    compte_label: str | None
    nature: NatureLigne
    montant_hebergement_n1: Decimal | None
    montant_hebergement_n: Decimal | None
    montant_dependance_n1: Decimal | None
    montant_dependance_n: Decimal | None
    montant_soins_n1: Decimal | None
    montant_soins_n: Decimal | None
    montant_sea_n1: Decimal | None
    montant_sea_n: Decimal | None
    montant_budget_global_n1: Decimal | None
    montant_budget_global_n: Decimal | None
    montant_forfait_soins_n1: Decimal | None
    montant_forfait_soins_n: Decimal | None
    montant_soins_sad_n1: Decimal | None
    montant_soins_sad_n: Decimal | None
    montant_aide_acc_n1: Decimal | None
    montant_aide_acc_n: Decimal | None
    created_at: datetime
    updated_at: datetime


class Annexe5Response(BaseModel):
    """Body de ``GET /documents/{doc_id}/annexe5``."""

    model_config = ConfigDict(extra="forbid")

    ets_id_filtre: UUID | None
    variante_filtre: VarianteAnnexe5 | None
    items: list[Annexe5LigneRead]


# ---------------------------------------------------------------------------
# Forfait paramètres — Read / Upsert
# ---------------------------------------------------------------------------


class ForfaitParametresUpdate(BaseModel):
    """Body de ``PUT /documents/{doc_id}/forfait-parametres``.

    ``ets_id`` obligatoire top-level (Q7 — DELETE+INSERT WHERE doc+ets).

    Spec implicite EHPAD-only (KB20 §5.2 "paramètres EHPAD") mais §R
    fail-open Q8 — le cabinet peut techniquement poser des params sur
    n'importe quel ets."""

    model_config = ConfigDict(extra="forbid")

    ets_id: UUID
    date_evaluation: date | None = None
    nombre_points_gir: int | None = Field(default=None, ge=0)
    """Forfait dépendance D-052 — Σ par GIR × résidents."""
    nombre_personnes_girees: int | None = Field(default=None, ge=0)
    """Forfait dépendance D-052 — résidents évalués."""
    valeur_point_gir: Decimal | None = Field(default=None, ge=0)
    """Forfait dépendance D-052 — arrêté annuel PCD départemental.
    Disponible via PLT-VG KB core si saisie automatique (§I helper
    :func:`reference_lookup.valeur_point_gir`)."""
    gmp: Decimal | None = Field(default=None, ge=0)
    """Forfait soins D-053 — GIR Moyen Pondéré au 30/06 N-1."""
    pmp: Decimal | None = Field(default=None, ge=0)
    """Forfait soins D-053 — Pathos Moyen Pondéré au 30/06 N-1."""
    gmps: Decimal | None = Field(default=None, ge=0)
    """Forfait soins D-053 — GMP × poids soins (calcul GMPS exact :
    bloqueur B-33 spec)."""


class ForfaitParametresRead(BaseModel):
    """Row complet de ``compta_esms.forfait_parametres``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    etablissement_id: UUID | None
    date_evaluation: date | None
    nombre_points_gir: int | None
    nombre_personnes_girees: int | None
    valeur_point_gir: Decimal | None
    gmp: Decimal | None
    pmp: Decimal | None
    gmps: Decimal | None
    created_at: datetime


class ForfaitParametresListResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/forfait-parametres``.

    Liste par établissement (potentiellement multiple ets pour un doc
    multi-établissement)."""

    model_config = ConfigDict(extra="forbid")

    items: list[ForfaitParametresRead]
