"""Organisme Gestionnaire (OG) Pydantic models.

The OG is the top-level entity — a single juridique structure (FINESS
juridique) managing N établissements. Cf. L1 schema lines 23-48 and
D-018 (multi-établissement) + D-086 (PC/PNL plan comptable).

Enum-like fields are typed with ``Literal`` rather than ``Enum`` so the
generated OpenAPI shows the allowed values inline and Pydantic's strict
mode rejects any other string at parse time.
"""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from piilot_pack_compta_esms.services.validators import reject_pipe_char

NatureJuridique = Literal[
    "ETABLISSEMENT_PUBLIC_SANTE",
    "ESMS_PUBLIC_AUTONOME",
    "CCAS_CIAS_COLLECTIVITE",
    "PRIVE_NON_LUCRATIF",
    "PRIVE_COMMERCIAL",
]
"""Cf. KB B.1 + D-037 + D-082 (détermine variantes Affectation et
``compute_eprd_structure`` §BC). 5 valeurs DGCS UPPER (mise en
conformité v0.3 — v0.2 utilisait 4 valeurs lowercase via la
migration 021)."""

PlanComptable = Literal["PC", "PNL"]
"""Cf. L1 ligne 31 + D-086 (PC = commercial, PNL = non lucratif)."""

_FINESS_RE = re.compile(r"^\d{9}$")
_SIRET_RE = re.compile(r"^\d{14}$")


class OGBase(BaseModel):
    """Shared fields between Create/Update/Read.

    Field constraints mirror the DB CHECK constraints (cf. ``002_compta_esms_core.sql``)
    so a request is rejected at parse time rather than bouncing on a
    ``CheckViolation`` deep in the repo.
    """

    # ``extra='forbid'`` is the load-bearing guard — any unknown body
    # field raises 422. We do **not** pass ``strict=True`` because that
    # blocks JSON string → UUID coercion, which is the standard way
    # FastAPI parses path params and request bodies. Coercion targeted
    # at known security risks (``"42"`` → ``42``) doesn't pay back
    # the operational pain it causes on UUIDs and dates.
    model_config = ConfigDict(extra="forbid")

    finess_juridique: str = Field(..., description="FINESS juridique — 9 chiffres")
    raison_sociale: str = Field(..., min_length=1, max_length=255)
    nature_juridique: NatureJuridique
    plan_comptable: PlanComptable
    adresse: str | None = Field(default=None, max_length=500)
    cpom_date_effet: date | None = None
    representant_legal: str | None = Field(default=None, max_length=255)
    representant_qualite: str | None = Field(default=None, max_length=255)
    siret: str | None = None
    telephone: str | None = Field(default=None, max_length=30)
    email: str | None = Field(default=None, max_length=255)

    @field_validator("finess_juridique")
    @classmethod
    def _validate_finess(cls, v: str) -> str:
        if not _FINESS_RE.match(v):
            raise ValueError("finess_juridique must be exactly 9 digits")
        return v

    @field_validator("siret")
    @classmethod
    def _validate_siret(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if not _SIRET_RE.match(v):
            raise ValueError("siret must be exactly 14 digits")
        return v

    # D-075 — pipe char interdit dans les champs de saisie libre
    _no_pipe = field_validator(
        "raison_sociale",
        "adresse",
        "representant_legal",
        "representant_qualite",
    )(reject_pipe_char)


class OGCreate(OGBase):
    """Body of ``POST /orgs`` — no id, company_id is injected from auth."""


class OGUpdate(BaseModel):
    """Body of ``PATCH /orgs/{og_id}``.

    Defined from scratch (not inheriting :class:`OGBase`) so every field
    can be optional without the base's ``...`` defaults bleeding in.
    """

    # ``extra='forbid'`` is the load-bearing guard — any unknown body
    # field raises 422. We do **not** pass ``strict=True`` because that
    # blocks JSON string → UUID coercion, which is the standard way
    # FastAPI parses path params and request bodies. Coercion targeted
    # at known security risks (``"42"`` → ``42``) doesn't pay back
    # the operational pain it causes on UUIDs and dates.
    model_config = ConfigDict(extra="forbid")

    finess_juridique: str | None = None
    raison_sociale: str | None = Field(default=None, min_length=1, max_length=255)
    nature_juridique: NatureJuridique | None = None
    plan_comptable: PlanComptable | None = None
    adresse: str | None = Field(default=None, max_length=500)
    cpom_date_effet: date | None = None
    representant_legal: str | None = Field(default=None, max_length=255)
    representant_qualite: str | None = Field(default=None, max_length=255)
    siret: str | None = None
    telephone: str | None = Field(default=None, max_length=30)
    email: str | None = Field(default=None, max_length=255)

    @field_validator("finess_juridique")
    @classmethod
    def _validate_finess(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if not _FINESS_RE.match(v):
            raise ValueError("finess_juridique must be exactly 9 digits")
        return v

    # D-075 — pipe char interdit dans les champs de saisie libre
    _no_pipe = field_validator(
        "raison_sociale",
        "adresse",
        "representant_legal",
        "representant_qualite",
    )(reject_pipe_char)

    @field_validator("siret")
    @classmethod
    def _validate_siret(cls, v: str | None) -> str | None:
        if v is None:
            return v
        if not _SIRET_RE.match(v):
            raise ValueError("siret must be exactly 14 digits")
        return v


class OGRead(OGBase):
    """Body of ``GET /orgs/{og_id}`` — full DB row, including timestamps."""

    id: UUID
    company_id: UUID
    created_at: datetime
    updated_at: datetime


# Alias kept so external code can import ``OG`` as the canonical name.
OG = OGRead
