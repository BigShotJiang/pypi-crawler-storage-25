"""Models §Y — clés de répartition charges communes (D-057, KB20 §8.2).

Le cabinet définit, par établissement × compte M22Bis × année, comment
ventiler les charges communes (602xx, 60xx hors règles dures D-055)
entre Hébergement / Dépendance / Soins / Soins-Autonomie SEA.

Stabilité année/année (KB20 §8.2) : le service logge WARN soft quand
une nouvelle clé diffère de celle de N-1 pour le même (ETS, compte).
Pas d'enforcement strict en v0.2 (reporté v0.3 avec contexte CPOM).

Σ taux = 100 ± 0.01 — enforce DB CHECK constraint + Pydantic validator.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator


def _validate_sum_100(h: Decimal, d: Decimal, s: Decimal, sea: Decimal) -> None:
    """Σ = 100 ± 0.01€. Helper partagé entre Create/Update/BulkUpsert."""
    total = h + d + s + sea
    if not (Decimal("99.99") <= total <= Decimal("100.01")):
        raise ValueError(f"taux_sum_must_be_100:got {total} (h={h}, d={d}, s={s}, sea={sea})")


def _validate_each_in_range(h: Decimal, d: Decimal, s: Decimal, sea: Decimal) -> None:
    """Chaque taux ∈ [0, 100]."""
    for name, value in [
        ("taux_hebergement", h),
        ("taux_dependance", d),
        ("taux_soins", s),
        ("taux_soins_autonomie", sea),
    ]:
        if not (Decimal("0") <= value <= Decimal("100")):
            raise ValueError(f"{name}_out_of_range:got {value}, expected [0, 100]")


class ClesRepartitionCreate(BaseModel):
    """Body POST — création d'une nouvelle clé."""

    model_config = ConfigDict(extra="forbid")

    etablissement_id: UUID
    compte_m22bis: str = Field(..., min_length=1, max_length=20)
    exercice_annee: int = Field(..., ge=2020, le=2050)
    taux_hebergement: Decimal = Field(default=Decimal("0"), ge=0, le=100)
    taux_dependance: Decimal = Field(default=Decimal("0"), ge=0, le=100)
    taux_soins: Decimal = Field(default=Decimal("0"), ge=0, le=100)
    taux_soins_autonomie: Decimal = Field(default=Decimal("0"), ge=0, le=100)
    source: str | None = Field(default=None, max_length=200)
    notes: str | None = Field(default=None, max_length=1000)

    @model_validator(mode="after")
    def _check_sum_and_ranges(self) -> ClesRepartitionCreate:
        _validate_each_in_range(
            self.taux_hebergement,
            self.taux_dependance,
            self.taux_soins,
            self.taux_soins_autonomie,
        )
        _validate_sum_100(
            self.taux_hebergement,
            self.taux_dependance,
            self.taux_soins,
            self.taux_soins_autonomie,
        )
        return self


class ClesRepartitionUpdate(BaseModel):
    """Body PUT/PATCH — mise à jour. Tous champs optionnels mais si on
    touche aux taux, Σ doit toujours = 100 ± 0.01 (validateur).

    Pour la rigueur Pydantic v2 + ``exclude_unset``, on demande tous
    les taux ensemble (saisie atomique) plutôt que des patches partiels
    qui rendraient la validation Σ=100 ambiguë."""

    model_config = ConfigDict(extra="forbid")

    taux_hebergement: Decimal | None = Field(default=None, ge=0, le=100)
    taux_dependance: Decimal | None = Field(default=None, ge=0, le=100)
    taux_soins: Decimal | None = Field(default=None, ge=0, le=100)
    taux_soins_autonomie: Decimal | None = Field(default=None, ge=0, le=100)
    source: str | None = Field(default=None, max_length=200)
    notes: str | None = Field(default=None, max_length=1000)

    @model_validator(mode="after")
    def _check_all_or_none_taux(self) -> ClesRepartitionUpdate:
        taux_fields = [
            self.taux_hebergement,
            self.taux_dependance,
            self.taux_soins,
            self.taux_soins_autonomie,
        ]
        provided = [t for t in taux_fields if t is not None]
        if 0 < len(provided) < 4:
            raise ValueError(
                "taux_must_be_all_or_none:patch partiel non supporté, "
                "envoyer les 4 taux ensemble (ou aucun pour modifier "
                "uniquement source/notes)"
            )
        if len(provided) == 4:
            _validate_each_in_range(
                self.taux_hebergement,  # type: ignore[arg-type]
                self.taux_dependance,  # type: ignore[arg-type]
                self.taux_soins,  # type: ignore[arg-type]
                self.taux_soins_autonomie,  # type: ignore[arg-type]
            )
            _validate_sum_100(
                self.taux_hebergement,  # type: ignore[arg-type]
                self.taux_dependance,  # type: ignore[arg-type]
                self.taux_soins,  # type: ignore[arg-type]
                self.taux_soins_autonomie,  # type: ignore[arg-type]
            )
        return self


class ClesRepartitionRead(BaseModel):
    """Row complet renvoyé par les routes GET / POST / PUT."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    etablissement_id: UUID
    compte_m22bis: str
    exercice_annee: int
    taux_hebergement: Decimal
    taux_dependance: Decimal
    taux_soins: Decimal
    taux_soins_autonomie: Decimal
    source: str | None
    notes: str | None
    created_at: datetime
    updated_at: datetime


class ClesRepartitionBulkUpsertItem(BaseModel):
    """1 item de la requête POST :bulk-upsert. Mêmes champs que Create
    mais sans ``etablissement_id`` (fixé par l'URL parent)."""

    model_config = ConfigDict(extra="forbid")

    compte_m22bis: str = Field(..., min_length=1, max_length=20)
    exercice_annee: int = Field(..., ge=2020, le=2050)
    taux_hebergement: Decimal = Field(default=Decimal("0"), ge=0, le=100)
    taux_dependance: Decimal = Field(default=Decimal("0"), ge=0, le=100)
    taux_soins: Decimal = Field(default=Decimal("0"), ge=0, le=100)
    taux_soins_autonomie: Decimal = Field(default=Decimal("0"), ge=0, le=100)
    source: str | None = Field(default=None, max_length=200)
    notes: str | None = Field(default=None, max_length=1000)

    @model_validator(mode="after")
    def _check(self) -> ClesRepartitionBulkUpsertItem:
        _validate_each_in_range(
            self.taux_hebergement,
            self.taux_dependance,
            self.taux_soins,
            self.taux_soins_autonomie,
        )
        _validate_sum_100(
            self.taux_hebergement,
            self.taux_dependance,
            self.taux_soins,
            self.taux_soins_autonomie,
        )
        return self


class ClesRepartitionBulkUpsertRequest(BaseModel):
    """Body POST :bulk-upsert — liste d'items (max 200 par batch)."""

    model_config = ConfigDict(extra="forbid")

    items: list[ClesRepartitionBulkUpsertItem] = Field(..., max_length=200)


class ApplyDefaultVentilationReport(BaseModel):
    """Retour de POST /crs/{cr_id}/lignes:apply-default-ventilation.

    Sépare en 3 buckets pour donner au cabinet une vision claire de ce
    qui s'est passé sur le batch : combien de lignes effectivement
    ventilées, combien restent à saisie manuelle (pas de règle), et
    combien on a sciemment ignorées (déjà ventilées explicitement)."""

    model_config = ConfigDict(extra="forbid")

    cr_id: UUID
    lignes_ventilees: int = Field(..., ge=0)
    lignes_skipees_manuelles: int = Field(..., ge=0)
    lignes_sans_regle: int = Field(..., ge=0)
    total_lignes_evaluees: int = Field(..., ge=0)
