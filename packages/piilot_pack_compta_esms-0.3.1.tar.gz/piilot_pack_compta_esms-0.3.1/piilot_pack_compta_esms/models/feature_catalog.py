"""Feature catalog Pydantic models (L2 §8, D-103).

The catalog is **global** (no ``company_id``, no RLS) — it ships with
the plugin and describes the bindable features (CRP G1/G2/G3,
TPER/TER, Annexe 4, Bilan, etc.) plus the column contract each one
expects from a bound KB.

A "column contract" is a flat ``{column_name: pg_type_logique}`` dict
where the logical type is one of ``text`` / ``numeric`` / ``integer``
/ ``date``. The binding service (§G.6) verifies the KB candidate
exposes at least these columns (cf. ``kb_discovery`` Q3 permissive
mode : a type mismatch yields a warning, not a hard reject).

Cf. L1 schema lines 669-687, migration ``003_seed_feature_catalog.sql``
for the 16 seeded rows.
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

DocType = Literal["eprd", "errd", "dm", "ria", "ercp", "epcp", "avenant"]
"""All document types polymorphism (mirrors L1 ligne 105, §E.3)."""

PlanComptableCible = Literal["M22Bis"]
"""Locked to M22Bis (D-106 + D-107). The plugin never produces another
plan ; if a cabinet imports a balance in a different plan, the §F
mapping assistant projects it onto M22Bis before binding."""


class FeatureCatalogRead(BaseModel):
    """One row of ``compta_esms.feature_catalog``.

    ``columns_required`` is intentionally ``dict[str, str]`` (not a
    typed schema) — the catalog is the source of truth and bumps its
    ``contract_version`` when columns evolve, so a strongly-typed
    schema here would just duplicate the seed migration.
    """

    model_config = ConfigDict(extra="forbid")

    feature_key: str
    label: str
    description: str | None = None
    columns_required: dict[str, str]
    is_mandatory: bool
    applicable_typologies: list[str] = Field(default_factory=list)
    applicable_doc_types: list[str] = Field(default_factory=list)
    plan_comptable_cible: PlanComptableCible = "M22Bis"
    contract_version: int = Field(default=1, ge=1)
    ordre: int = Field(default=0, ge=0)
    created_at: datetime
