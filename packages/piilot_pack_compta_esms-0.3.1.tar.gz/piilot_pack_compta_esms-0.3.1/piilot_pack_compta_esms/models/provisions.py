"""Provisions, dépréciations, subventions (§N, L2 §16.1-§16.2).

Tableau de mouvements sur **4 catégories** (D-099, 25-deepdive §10) :

* ``provisions_reglementees`` — c/14
* ``provisions_risques_charges`` — c/15
* ``depreciations`` — c/29, 39, 49, 59
* ``subventions_investissement`` — c/13

Colonnes : ``compte_imputation`` / ``objet`` / ``montant_debut_n`` (1)
/ ``dotations`` (2) / ``reprises`` (3) / **``montant_fin_n``** (4) =
(1)+(2)-(3) **GENERATED ALWAYS AS** (DDL §D.9 ligne 546).

Pas exposé dans le payload de create — calculé par PG.

Sémantique bulk-upsert Q3 : ``replace_all_by_document`` atomique
(cohérent §M, le tableau est un tout cohérent).

``totals`` sont **inclus dans GET** (Q6 — L2 §16 n'expose pas
``:totals`` séparé contrairement à §15 TF).
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

Categorie = Literal[
    "provisions_reglementees",
    "provisions_risques_charges",
    "depreciations",
    "subventions_investissement",
]
"""DDL §D.9 ligne 534 — CHECK constraint sur 4 valeurs (D-099)."""


# ---------------------------------------------------------------------------
# Create / Bulk
# ---------------------------------------------------------------------------


class ProvisionLigneCreate(BaseModel):
    """Item du bulk-upsert. ``montant_fin_n`` non exposé : calculé par
    PG (GENERATED ALWAYS AS)."""

    model_config = ConfigDict(extra="forbid")

    categorie: Categorie
    cr_id: UUID | None = None
    compte_imputation: str = Field(..., min_length=1, max_length=32)
    objet: str | None = Field(default=None, max_length=255)
    montant_debut_n: Decimal | None = None
    dotations: Decimal | None = None
    reprises: Decimal | None = None


class ProvisionsBulkUpsertRequest(BaseModel):
    """Body de ``POST /documents/{doc_id}/provisions:bulk-upsert``.

    Sémantique Q3 : **replace all by document** — DELETE WHERE doc +
    INSERT batch atomique."""

    model_config = ConfigDict(extra="forbid")

    items: list[ProvisionLigneCreate] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------


class ProvisionLigneRead(BaseModel):
    """Row complet de ``compta_esms.provisions_lignes``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    categorie: Categorie
    cr_id: UUID | None
    compte_imputation: str
    objet: str | None
    montant_debut_n: Decimal | None
    dotations: Decimal | None
    reprises: Decimal | None
    montant_fin_n: Decimal | None
    """Calculée par PG : ``COALESCE(montant_debut_n,0) +
    COALESCE(dotations,0) - COALESCE(reprises,0)``."""
    created_at: datetime
    updated_at: datetime


# ---------------------------------------------------------------------------
# Totals (Q6 — inclus dans GET, pas d'endpoint séparé)
# ---------------------------------------------------------------------------


class ProvisionsMontants(BaseModel):
    """4 colonnes monétaires agrégées. Réutilisé pour total général et
    pour sous-totaux par catégorie (où ``ProvisionsCategorieTotals``
    l'enveloppe avec le champ ``categorie``)."""

    model_config = ConfigDict(extra="forbid")

    montant_debut_n: Decimal
    dotations: Decimal
    reprises: Decimal
    montant_fin_n: Decimal


class ProvisionsCategorieTotals(BaseModel):
    """Sous-total par catégorie."""

    model_config = ConfigDict(extra="forbid")

    categorie: Categorie
    montants: ProvisionsMontants


class ProvisionsTotals(BaseModel):
    """Totaux provisions — by_categorie + total général.

    ``by_categorie`` contient au plus 4 entrées (une par
    :class:`Categorie` présente dans les items). ``total_general``
    est un :class:`ProvisionsMontants` standalone (sans catégorie)."""

    model_config = ConfigDict(extra="forbid")

    by_categorie: list[ProvisionsCategorieTotals]
    total_general: ProvisionsMontants


class ProvisionsResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/provisions``."""

    model_config = ConfigDict(extra="forbid")

    items: list[ProvisionLigneRead]
    totals: ProvisionsTotals
