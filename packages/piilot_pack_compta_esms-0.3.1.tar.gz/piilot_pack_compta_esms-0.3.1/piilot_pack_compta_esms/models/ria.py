"""Models §W RIA — Rapport Infra-Annuel.

KB23 §3.3 + KB25 §14 — onglet exclusif RIA ``Synthèse résultats`` :

  9 lignes × 9 colonnes : ``CRP / Résultat comptable N-1 /
  Dernier EPRD exécutoire N (Charges/Produits/Résultat) /
  Projection actualisée N (Charges/Produits/Résultat)``

  → 1 ligne par CR (CRPP, CRPA, CRP_SF…) + 1 ligne TOTAL.

D-065 + D-087 — règle métier : ``Projection actualisée N`` vient des
``crp_lignes`` du RIA lui-même (qui reste prévisionnel, juste actualisé
en cours d'exercice). ``Dernier EPRD exécutoire N`` vient des
``crp_lignes`` du parent EPRD (forcément exécutoire à l'heure où le
RIA est cloné §V). ``Résultat comptable N-1`` vient des ``crp_lignes``
de l'ERRD N-1 du même OG, si présent en statut ``executoire`` ou
``affectation_definie`` — sinon ``null``.
"""

from __future__ import annotations

from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class SyntheseResultatsCell(BaseModel):
    """3-uplet ``(charges, produits, resultat)`` pour une colonne (EPRD ou RIA).

    Le résultat est dérivé : ``produits - charges``. On le pré-calcule
    côté service pour éviter au frontend de re-fabriquer la soustraction
    avec une précision Decimal différente.
    """

    model_config = ConfigDict(extra="forbid")

    charges: Decimal = Field(..., description="Σ crp_lignes.nature='charge'")
    produits: Decimal = Field(..., description="Σ crp_lignes.nature='produit'")
    resultat: Decimal = Field(..., description="produits - charges")


class SyntheseResultatsRow(BaseModel):
    """Une ligne de la synthèse — 1 CR du RIA.

    ``resultat_comptable_n_minus_1`` est ``None`` s'il n'y a pas d'ERRD
    N-1 finalisé (1ère année d'opération, OG nouvellement créé) ou
    si le CR RIA n'a pas de pendant ERRD N-1 (CR ajouté en cours
    d'exercice). Le frontend affichera "—" dans ces cas.

    ``eprd_executoire_n`` est ``None`` s'il n'y a pas de CR EPRD parent
    correspondant — cas dégénéré, ne devrait pas arriver puisque §V
    clone hérite déjà du périmètre EPRD.
    """

    model_config = ConfigDict(extra="forbid")

    cr_id: UUID = Field(..., description="CR du RIA (source de vérité du périmètre)")
    cr_type: str = Field(..., description="CRPP / CRPA / CRP_SF / CRA_SF")
    denomination: str = Field(..., description="Libellé du CR pour affichage frontend")
    etablissement_id: UUID | None = Field(
        default=None,
        description="ETS rattaché au CR (peut être NULL pour CRP_SF section financière)",
    )
    resultat_comptable_n_minus_1: Decimal | None = Field(
        default=None,
        description=(
            "Résultat comptable de l'ERRD N-1 pour le même ETS+cr_type. "
            "None si pas d'ERRD N-1 finalisé ou pas de pendant côté ERRD."
        ),
    )
    eprd_executoire_n: SyntheseResultatsCell | None = Field(
        default=None,
        description="Σ charges/produits/résultat du parent EPRD (CR matché par ETS+cr_type)",
    )
    projection_actualisee_n: SyntheseResultatsCell = Field(
        ...,
        description="Σ charges/produits/résultat du RIA lui-même (saisie du cabinet)",
    )


class SyntheseResultatsTotal(BaseModel):
    """Ligne TOTAL — somme des ``SyntheseResultatsRow`` sur les 3 colonnes."""

    model_config = ConfigDict(extra="forbid")

    resultat_comptable_n_minus_1: Decimal | None = Field(
        default=None,
        description=(
            "Σ des ``resultat_comptable_n_minus_1`` non-None. None si "
            "aucune ligne n'avait de valeur."
        ),
    )
    eprd_executoire_n: SyntheseResultatsCell | None = Field(
        default=None,
        description="Σ charges/produits/résultat des cellules EPRD non-None",
    )
    projection_actualisee_n: SyntheseResultatsCell = Field(
        ...,
        description="Σ charges/produits/résultat — toutes les lignes contribuent",
    )


class SyntheseResultatsResponse(BaseModel):
    """Réponse complète de ``GET /documents/{ria_id}/synthese-resultats``.

    ``errd_n_minus_1_id`` est ``None`` quand aucun ERRD finalisé N-1
    n'a été trouvé pour l'OG — le frontend l'utilise pour décider
    d'afficher "N-1 : pas d'ERRD finalisé" plutôt que "—" dans chaque
    cellule.
    """

    model_config = ConfigDict(extra="forbid")

    ria_id: UUID
    parent_eprd_id: UUID = Field(..., description="EPRD parent (garanti non-NULL pour un RIA)")
    errd_n_minus_1_id: UUID | None = Field(
        default=None,
        description=(
            "ID de l'ERRD N-1 finalisé (executoire ou affectation_definie). "
            "None si pas d'ERRD finalisé."
        ),
    )
    rows: list[SyntheseResultatsRow]
    total: SyntheseResultatsTotal
