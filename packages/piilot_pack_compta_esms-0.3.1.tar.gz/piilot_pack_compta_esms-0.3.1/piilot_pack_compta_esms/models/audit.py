"""Pydantic models — audit events (§AI L2 §22.1).

DTO read-only pour la route ``GET /documents/{doc_id}/audit``. Pas de
DTO Create — l'écriture passe par ``audit_service.record_event_in``
appelée en interne par les services métier (workflow_service, rgpd_service,
document_service, etc.).
"""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class AuditEventRead(BaseModel):
    """Row de ``compta_esms.audit_events`` exposée côté API admin.

    Inclut le payload JSONB intégral (admin only, trace forensique
    transparente). Les UUID sont stringifiés par Pydantic pour la
    réponse JSON.
    """

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    user_id: UUID
    document_id: UUID | None
    action: str
    resource_type: str
    resource_id: UUID | None
    payload: dict[str, Any]
    occurred_at: datetime
