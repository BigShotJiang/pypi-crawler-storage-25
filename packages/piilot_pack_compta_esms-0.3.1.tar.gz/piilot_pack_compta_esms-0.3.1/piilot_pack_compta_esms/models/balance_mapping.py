"""Balance mapping Pydantic models (D-108 — assistant mapping balance).

The ``balance_mappings`` table holds the per-company dictionary of
source-account → M22-bis-account correspondences. Each ``source_account``
can map to multiple ``target_m22bis_account`` (1:N split with
``weight`` coefficients, Σ weight = 1.0 enforced by a DB trigger
posted in §D — ``tg_check_balance_mapping_weights``).

The mapping outlives any single balance import — once the cabinet
maps ``"60611" → "60611"``, that rule is reused at every monthly /
quarterly re-import (cf. D-108 — assistant léger style CSV→KB).
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

# Source plans recognized by ``balance_mappings.source_plan``. Mirror
# of the L1 CHECK constraint (002_compta_esms_core.sql line ~727).
SourcePlan = Literal[
    "PCG",
    "M14",
    "M21",
    "M22Bis",
    "Sage",
    "EBP",
    "Cegid",
    "Pennylane",
    "custom",
]

# How the mapping ended up in the table — useful for audit and for
# sorting suggestions by trust level in the UI.
SuggestionOrigin = Literal[
    "manual",
    "pcg_to_m22bis_kb",
    "preset",
    "llm",
]


class BalanceMappingBase(BaseModel):
    """Shared fields between Create/Update/Read."""

    model_config = ConfigDict(extra="forbid")

    source_plan: SourcePlan
    source_account: str = Field(..., min_length=1, max_length=50)
    target_m22bis_account: str = Field(..., min_length=1, max_length=50)
    weight: float = Field(
        default=1.0,
        gt=0,
        le=1.0,
        description=(
            "Coefficient pour 1:N. Σ weight = 1.0 enforced by DB trigger "
            "per (company, source_plan, source_account, version_m22bis)."
        ),
    )
    label_hint: str | None = Field(default=None, max_length=255)
    confidence: float | None = Field(default=None, ge=0, le=1.0)
    suggestion_origin: SuggestionOrigin | None = None
    version_m22bis: str = Field(default="2025-2026", max_length=20)
    valid_from: date | None = None
    valid_to: date | None = None


class BalanceMappingCreate(BalanceMappingBase):
    """Body of ``POST /balance-mappings`` (L2 §7bis.3.2)."""


class BalanceMappingUpdate(BaseModel):
    """Body of ``PATCH /balance-mappings/{id}`` (L2 §7bis.3.4).

    ``source_plan`` / ``source_account`` / ``target_m22bis_account`` /
    ``version_m22bis`` are **not** patchable — they form the unique
    key. Changing them would create a fresh mapping (delete + create)
    not a patch, so we force that intent at the API level.
    """

    model_config = ConfigDict(extra="forbid")

    weight: float | None = Field(default=None, gt=0, le=1.0)
    label_hint: str | None = Field(default=None, max_length=255)
    confidence: float | None = Field(default=None, ge=0, le=1.0)
    suggestion_origin: SuggestionOrigin | None = None
    valid_from: date | None = None
    valid_to: date | None = None


class BalanceMappingRead(BalanceMappingBase):
    """Body of ``GET /balance-mappings/{id}`` — full DB row."""

    id: UUID
    company_id: UUID
    created_at: datetime
    updated_at: datetime


BalanceMapping = BalanceMappingRead


class BalanceMappingBulkItem(BaseModel):
    """One entry in the ``POST /balance-mappings:bulk-upsert`` body.

    Mirrors :class:`BalanceMappingCreate` shape, but accepted as a list
    item — semantics : upsert keyed on
    ``(source_plan, source_account, target_m22bis_account, version_m22bis)``
    via the table's UNIQUE constraint.
    """

    model_config = ConfigDict(extra="forbid")

    source_plan: SourcePlan
    source_account: str = Field(..., min_length=1, max_length=50)
    target_m22bis_account: str = Field(..., min_length=1, max_length=50)
    weight: float = Field(default=1.0, gt=0, le=1.0)
    label_hint: str | None = Field(default=None, max_length=255)
    confidence: float | None = Field(default=None, ge=0, le=1.0)
    suggestion_origin: SuggestionOrigin | None = None
    version_m22bis: str = Field(default="2025-2026", max_length=20)


class BalanceMappingValidationIssue(BaseModel):
    """One row of the ``:validate`` response — a source key whose
    Σ weight differs from 1.0 (within a 1e-4 tolerance, matching the
    DB trigger)."""

    model_config = ConfigDict(extra="forbid")

    source_plan: str
    source_account: str
    version_m22bis: str
    total_weight: float
    target_count: int
