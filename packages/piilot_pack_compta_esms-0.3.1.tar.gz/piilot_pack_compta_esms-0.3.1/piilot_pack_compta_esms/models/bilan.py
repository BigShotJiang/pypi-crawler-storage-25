"""Bilan financier + comptable PC/PNL (§K, L2 §14, D-066 + D-086).

Trois variantes coexistantes :

* ``financier`` — bilan financier 8 totaux symétriques BIENS (II+IV+VI+VIII)
  vs FINANCEMENTS (I+III+V+VII). Présent sur EPRD/ERRD. Contrôles C-56/C-57
  (TOTAL BIENS = TOTAL FINANCEMENTS).
* ``comptable_pc`` — Plan Comptable commercial (sociétés). Cadre
  ``#AERRDBCC-2024-01#``. 99 lignes. Onglet exclusif "Suivi EHPAD"
  (Soins/Dépendance/Hébergement).
* ``comptable_pnl`` — Plan Comptable Non Lucratif (associations).
  Cadre ``#AERRDBCN-2023-01#``. 93 lignes. Onglet exclusif "Comptes
  de liaison". 2 autocontrôles supplémentaires (cohérence comptes
  liaison actif/passif).

D-066 : "Bilan comptable (Annexe 3) ≠ Bilan financier (Annexe 8) —
2 documents distincts". Donc `financier` + `comptable_*` coexistent
sur un même document.

D-067 : variante comptable PC vs PNL **auto-déduite** depuis
``og.plan_comptable`` (D-086). Le service refuse une combinaison
incohérente (ex: payload `comptable_pnl` alors que og=PC).

Bulk-upsert sémantique (§K.4 Q3) : **replace by type_bilan** — chaque
type_bilan présent dans le body est intégralement remplacé (DELETE +
INSERT atomique). Les autres types restent intacts.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

TypeBilan = Literal["financier", "comptable_pc", "comptable_pnl"]
"""3 variantes (DDL ligne 472)."""

TypeActifPassif = Literal["actif", "passif"]
"""Discriminant actif/passif (DDL ligne 480)."""

PlanComptable = Literal["PC", "PNL"]
"""``og.plan_comptable`` — D-086. Cherche-clés pour
:func:`bilan_variante.choose_bilan_comptable_variant`."""


# ---------------------------------------------------------------------------
# Bulk upsert items + body
# ---------------------------------------------------------------------------


class BilanLigneCreate(BaseModel):
    """Un item du bulk-upsert. ``type_bilan`` est porté par chaque
    item (le bulk peut mélanger les 3 variantes — le service les
    sépare par type_bilan et fait un DELETE+INSERT atomique par
    groupe).

    Colonnes Suivi EHPAD (Q7 — optionnel) : seules les variantes
    ``comptable_pc`` peuvent les remplir significativement (D-086
    "onglet exclusif PC"). Le service ne les rejette pas si fournies
    sur d'autres types — soft validation only.
    """

    model_config = ConfigDict(extra="forbid")

    type_bilan: TypeBilan
    section: str = Field(..., min_length=1, max_length=64)
    poste_label: str = Field(..., min_length=1, max_length=255)
    compte_m22bis: str | None = Field(default=None, max_length=32)
    montant_brut_n: Decimal | None = None
    montant_amort_n: Decimal | None = None
    montant_net_n: Decimal | None = None
    montant_net_n1: Decimal | None = None
    type_actif_passif: TypeActifPassif | None = None
    montant_soins_n: Decimal | None = None
    montant_dependance_n: Decimal | None = None
    montant_hebergement_n: Decimal | None = None


class BilanBulkUpsertRequest(BaseModel):
    """Body de ``POST /documents/{doc_id}/bilan:bulk-upsert``.

    ``items`` peut mélanger les 3 variantes — chaque type_bilan
    présent est remplacé intégralement (Q3 replace by type_bilan).
    Les types absents du body restent intacts en DB.
    """

    model_config = ConfigDict(extra="forbid")

    items: list[BilanLigneCreate] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------


class BilanLigneRead(BaseModel):
    """Row complet de ``compta_esms.bilan_lignes``."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    company_id: UUID
    document_id: UUID
    type_bilan: TypeBilan
    section: str
    poste_label: str
    compte_m22bis: str | None
    montant_brut_n: Decimal | None
    montant_amort_n: Decimal | None
    montant_net_n: Decimal | None
    montant_net_n1: Decimal | None
    type_actif_passif: TypeActifPassif | None
    montant_soins_n: Decimal | None
    montant_dependance_n: Decimal | None
    montant_hebergement_n: Decimal | None
    created_at: datetime
    updated_at: datetime


class BilanResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/bilan`` — items + plan_comptable
    de l'OG (utile à l'UI pour afficher le bon onglet PC vs PNL).
    """

    model_config = ConfigDict(extra="forbid")

    plan_comptable_og: PlanComptable | None
    items: list[BilanLigneRead]


# ---------------------------------------------------------------------------
# Totals (Q4 — paramètre ?type_bilan= optionnel)
# ---------------------------------------------------------------------------


class BilanSectionTotal(BaseModel):
    """Totaux d'une section (I-VIII pour financier, sections nommées
    pour comptable_*)."""

    model_config = ConfigDict(extra="forbid")

    section: str
    total_actif: Decimal
    total_passif: Decimal
    ecart: Decimal


class BilanTotalsForType(BaseModel):
    """Totaux pour un type_bilan donné."""

    model_config = ConfigDict(extra="forbid")

    type_bilan: TypeBilan
    by_section: list[BilanSectionTotal]
    total_biens: Decimal
    total_financements: Decimal
    ecart: Decimal


class BilanTotalsResponse(BaseModel):
    """Body de ``GET /documents/{doc_id}/bilan:totals``.

    Si la query carry un ``?type_bilan=`` → seul ce type est rempli.
    Sinon retourne tous les types présents en base (les autres = None).
    """

    model_config = ConfigDict(extra="forbid")

    financier: BilanTotalsForType | None = None
    comptable_pc: BilanTotalsForType | None = None
    comptable_pnl: BilanTotalsForType | None = None


# ---------------------------------------------------------------------------
# Validation (C-56/C-57, Q5 tolérance 0.01€)
# ---------------------------------------------------------------------------


ValidationIssueCode = Literal[
    "ecart_above_tolerance",
    "empty_bilan",
    "missing_type_actif_passif",
]


class BilanValidationIssue(BaseModel):
    """Un verdict par type_bilan."""

    model_config = ConfigDict(extra="forbid")

    code: ValidationIssueCode
    type_bilan: TypeBilan
    message: str
    ecart: Decimal | None = None


class BilanValidationResult(BaseModel):
    """Body de ``POST /documents/{doc_id}/bilan:validate``.

    ``valide=true`` ssi tous les types présents passent C-56/C-57
    (TOTAL BIENS = TOTAL FINANCEMENTS, tolérance 0.01€).
    """

    model_config = ConfigDict(extra="forbid")

    valide: bool
    issues: list[BilanValidationIssue]
    tolerance_appliquee: Decimal
