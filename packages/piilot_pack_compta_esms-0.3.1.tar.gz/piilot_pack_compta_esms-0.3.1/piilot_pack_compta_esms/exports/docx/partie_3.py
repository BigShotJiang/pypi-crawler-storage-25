"""§AC Partie 3 — Synthèse et conclusion (L5d §26-32).

* T6 Bilan financier synthétique
* EPRD synthétique (depuis §H/§I)
* Tableau de financement (depuis §M)
* T7 Ratios consolidés (depuis §AA — 15 ratios ERRD)
* PGFP consolidé (squelette §AA r_pgfp)
* Perspectives
"""

from __future__ import annotations

from decimal import Decimal

from docx.document import Document as DocumentT

from piilot_pack_compta_esms.exports.docx._base import (
    RapportContext,
    add_heading_styled,
    add_paragraph_text,
    add_table_styled,
    fill_table_row,
    format_currency_fr,
    format_percent_fr,
    inject_user_section,
    load_bilan,
    load_crp_lignes_by_cr,
    load_crs,
    load_tf,
)


async def fill_partie_3(doc: DocumentT, ctx: RapportContext) -> None:
    """Construit la Partie 3 — Synthèse et conclusion."""
    add_heading_styled(doc, "Partie 3 — Synthèse et conclusion", level=1)

    await _table_bilan_synthese(doc, ctx)
    await _table_eprd_synthetique(doc, ctx)
    await _table_tableau_financement(doc, ctx)
    # §BI — commentaire TF après la section 3.3.
    await inject_user_section(doc, ctx, "TABLEAU_FINANCEMENT")
    await _table_ratios_consolides(doc, ctx)
    # §BI — commentaire analyse financière après les ratios 3.4.
    await inject_user_section(doc, ctx, "ANALYSE_FINANCIERE")
    await _section_pgfp_consolide(doc, ctx)
    # §BI — commentaire PGFP après la section 3.5.
    await inject_user_section(doc, ctx, "PGFP")
    _section_perspectives(doc)
    # §BI — Perspectives (3.6) — le commentaire user enrichit/remplace
    # le texte placeholder par défaut du builder.
    await inject_user_section(doc, ctx, "PERSPECTIVES")


async def _table_bilan_synthese(doc: DocumentT, ctx: RapportContext) -> None:
    """T6 — Bilan financier synthétique (L5d §133)."""
    add_heading_styled(doc, "3.1 Bilan financier synthétique (T6)", level=2)
    bilan = await load_bilan(ctx)
    if not bilan:
        add_paragraph_text(doc, "Aucune ligne Bilan financier saisie.")
        return

    # Agrégation par compte prefix → simplifiée v0.2.
    actif_n = Decimal(0)
    actif_n1 = Decimal(0)
    passif_n = Decimal(0)
    passif_n1 = Decimal(0)
    for ligne in bilan:
        net_n = Decimal(str(ligne.get("montant_net_n") or 0))
        net_n1 = Decimal(str(ligne.get("montant_net_n1") or 0))
        if (ligne.get("type_actif_passif") or "") == "actif":
            actif_n += net_n
            actif_n1 += net_n1
        elif (ligne.get("type_actif_passif") or "") == "passif":
            passif_n += net_n
            passif_n1 += net_n1

    # FRNG ~ Capitaux dettes long terme - Immobilisations.
    # Simplification v0.2 : on présente totaux actif/passif.
    headers = ["Indicateur", "N-1", "N"]
    table = add_table_styled(doc, headers)
    fill_table_row(
        table,
        ["Total actif (biens)", format_currency_fr(actif_n1), format_currency_fr(actif_n)],
    )
    fill_table_row(
        table,
        [
            "Total passif (financements)",
            format_currency_fr(passif_n1),
            format_currency_fr(passif_n),
        ],
    )
    ecart_n = actif_n - passif_n
    ecart_n1 = actif_n1 - passif_n1
    fill_table_row(
        table,
        ["Écart équilibre", format_currency_fr(ecart_n1), format_currency_fr(ecart_n)],
    )


async def _table_eprd_synthetique(doc: DocumentT, ctx: RapportContext) -> None:
    """EPRD synthétique — Σ par groupe (charges G1/G2/G3 + produits G1/G2/G3)."""
    add_heading_styled(doc, "3.2 EPRD synthétique", level=2)
    crs = await load_crs(ctx)
    lignes_by_cr = await load_crp_lignes_by_cr(ctx)

    by_group_nature: dict[tuple[str, str], Decimal] = {}
    for cr in crs:
        for li in lignes_by_cr.get(cr["id"], []):
            key = (li.get("groupe") or "—", li.get("nature") or "—")
            by_group_nature[key] = by_group_nature.get(key, Decimal(0)) + Decimal(
                str(li.get("montant_realise") or 0)
            )

    headers = ["Groupe", "Charges", "Produits"]
    table = add_table_styled(doc, headers)
    for groupe in ("G1", "G2", "G3"):
        charges = by_group_nature.get((groupe, "charge"), Decimal(0))
        produits = by_group_nature.get((groupe, "produit"), Decimal(0))
        fill_table_row(
            table,
            [groupe, format_currency_fr(charges), format_currency_fr(produits)],
        )


async def _table_tableau_financement(doc: DocumentT, ctx: RapportContext) -> None:
    """Tableau de financement N (depuis §M)."""
    add_heading_styled(doc, "3.3 Tableau de financement", level=2)
    rows = await load_tf(ctx)
    if not rows:
        add_paragraph_text(doc, "Aucune ligne Tableau de financement saisie.")
        return

    headers = ["Côté", "Libellé", "Prévisions N", "Réalisations N"]
    table = add_table_styled(doc, headers)
    for r in rows:
        fill_table_row(
            table,
            [
                r.get("cote") or "",
                r.get("libelle") or "",
                format_currency_fr(r.get("montant_previsions_n")),
                format_currency_fr(r.get("montant_realisations_n")),
            ],
        )


async def _table_ratios_consolides(doc: DocumentT, ctx: RapportContext) -> None:
    """T7 — Ratios consolidés via §AA ratios_service.

    Compute les 15 ratios ERRD à la volée pour ce document.
    """
    add_heading_styled(doc, "3.4 Ratios consolidés (T7)", level=2)
    from piilot_pack_compta_esms.services import ratios_service

    try:
        response = await ratios_service.compute_ratios(
            ctx.document_id, ctx.company_id, type_filter="errd"
        )
    except Exception:  # noqa: BLE001
        add_paragraph_text(doc, "Calcul des ratios indisponible (document partiel).")
        return

    if not response.ratios_errd:
        add_paragraph_text(doc, "Aucun ratio évaluable pour ce document.")
        return

    headers = ["Ratio", "Valeur", "Unité", "Seuil", "Statut"]
    table = add_table_styled(doc, headers)
    for r in response.ratios_errd:
        seuil_text = "—"
        if r.seuil_min is not None and r.seuil_max is not None:
            seuil_text = f"[{r.seuil_min} ; {r.seuil_max}]"
        elif r.seuil_max is not None:
            seuil_text = f"≤ {r.seuil_max}"
        elif r.seuil_min is not None:
            seuil_text = f"≥ {r.seuil_min}"

        if r.unite == "%":
            valeur_text = format_percent_fr(r.valeur)
        elif r.unite == "jours":
            valeur_text = "—" if r.valeur is None else f"{float(r.valeur):.1f} j"
        elif r.unite == "annees":
            valeur_text = "—" if r.valeur is None else f"{float(r.valeur):.1f} ans"
        elif r.unite == "x":
            valeur_text = "—" if r.valeur is None else f"{float(r.valeur):.2f} x"
        else:
            valeur_text = "—" if r.valeur is None else f"{float(r.valeur):.2f}"

        statut_label = {"ok": "OK", "atypie": "⚠ Atypie", "na": "Non évalué"}.get(
            r.verdict, r.verdict
        )
        fill_table_row(
            table,
            [r.label, valeur_text, r.unite, seuil_text, statut_label],
        )


async def _section_pgfp_consolide(doc: DocumentT, ctx: RapportContext) -> None:
    """PGFP consolidé — squelette v0.2 (les 8 ratios PGFP §AA r_pgfp
    lisent les lignes PGFP par section/ligne_key, partiellement câblé)."""
    add_heading_styled(doc, "3.5 PGFP consolidé (8 ratios prévisionnels)", level=2)
    from piilot_pack_compta_esms.services import ratios_service

    try:
        response = await ratios_service.compute_ratios(
            ctx.document_id, ctx.company_id, type_filter="pgfp"
        )
    except Exception:  # noqa: BLE001
        add_paragraph_text(doc, "PGFP non évaluable pour ce type de document.")
        return

    if not response.ratios_pgfp:
        add_paragraph_text(
            doc,
            "PGFP applicable uniquement aux documents prévisionnels "
            "(EPRD/DM/RIA/AVENANT). Non applicable à ce document.",
        )
        return

    headers = ["Ratio", "N-1", "N", "N+1", "N+2", "N+3"]
    table = add_table_styled(doc, headers)
    for r in response.ratios_pgfp:
        # par_exercice contient 8 cellules (offsets -1 → 6). On en
        # affiche 5 (N-1 → N+3) pour rester dans le format L5d T5.
        by_offset = {c.annee_offset: c.valeur for c in r.par_exercice}
        cells = []
        for offset in (-1, 0, 1, 2, 3):
            v = by_offset.get(offset)
            cells.append("—" if v is None else format_currency_fr(v))
        fill_table_row(table, [r.label, *cells])


def _section_perspectives(doc: DocumentT) -> None:
    add_heading_styled(doc, "3.6 Perspectives", level=2)
    add_paragraph_text(
        doc,
        "Cette section est destinée à présenter les perspectives "
        "de l'exercice à venir (projets, transformations, mesures "
        "correctrices d'éventuelles atypies signalées). À enrichir "
        "par le cabinet avant transmission.",
    )
