"""Orchestrateur §AC — assemble le rapport budgétaire EPRD complet.

Pattern aligné §AB workbook_builder :

1. Construit un :class:`RapportContext` (alias :class:`ExportContext` §AB).
2. Crée un Document python-docx vide.
3. Configure header/footer + métadonnées core_properties.
4. Appelle les 3 parties dans l'ordre.
5. Sérialise en bytes via BytesIO.

L5d §171-178 — volume cible ≤ 20 pages. python-docx ne sait pas
paginer (c'est Word qui le fait au rendu), donc on ne peut pas
enforce le volume programmatiquement v0.2. Soft note dans la doc.
"""

from __future__ import annotations

from datetime import UTC, datetime
from io import BytesIO
from typing import Any
from uuid import UUID

from docx import Document

from piilot_pack_compta_esms.exports.docx._base import (
    RapportContext,
    set_default_font,
)
from piilot_pack_compta_esms.exports.docx.partie_1 import fill_partie_1
from piilot_pack_compta_esms.exports.docx.partie_2 import fill_partie_2
from piilot_pack_compta_esms.exports.docx.partie_3 import fill_partie_3


async def build_rapport_docx(
    document_id: UUID,
    company_id: UUID,
    document: dict[str, Any],
    *,
    template_version: str | None = None,
    user_label: str = "Piilot",
) -> bytes:
    """Construit le rapport DOCX EPRD et retourne ses bytes.

    Args :
        document_id, company_id, document : tenant validation côté caller.
        template_version : L2 §19.2 param body — accepté mais ignoré
            v0.2 (1 seul template "from-scratch"). Le param est gardé
            pour l'API stable, sera dispatché vers Bretagne short
            quand le 2e template arrivera v0.3+.
        user_label : pour la métadonnée ``last_modified_by``. Par
            défaut "Piilot" si le caller ne le fournit pas.

    Returns :
        Les bytes DOCX prêts à uploader/streamer.

    Raises :
        ValueError si un caractère ``|`` est rencontré (D-075).
    """
    _ = template_version  # accepted but not yet used v0.2

    ctx = RapportContext(
        document_id=document_id,
        company_id=company_id,
        document=document,
    )

    doc = Document()
    set_default_font(doc)
    _set_metadata(doc, ctx, user_label=user_label)
    _set_header_footer(doc, ctx)

    # Titre principal
    type_doc = (document.get("type_document") or "doc").upper()
    cadre = document.get("cadre_version") or ""
    title = doc.add_heading(f"Rapport budgétaire {type_doc}", level=0)
    _ = title
    doc.add_paragraph(f"Cadre DGCS : {cadre}")
    doc.add_paragraph(f"Document Piilot ID : {document_id}")
    doc.add_paragraph("")

    # 3 parties (ordre L5d).
    await fill_partie_1(doc, ctx)
    doc.add_page_break()
    await fill_partie_2(doc, ctx)
    doc.add_page_break()
    await fill_partie_3(doc, ctx)

    buffer = BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


def _set_metadata(doc, ctx: RapportContext, *, user_label: str) -> None:
    """L5d §181-188 — métadonnées core_properties.

    Le titre intègre l'année (depuis le cadre_version ou un fallback)
    et la raison sociale OG (lazy load — mais on est sync ici, donc
    fallback "OG" pour ne pas faire de SELECT à la métadata).
    """
    props = doc.core_properties
    props.author = user_label
    type_doc = (ctx.document.get("type_document") or "doc").upper()
    cadre = ctx.document.get("cadre_version") or ""
    # Extrait l'année du cadre #ERRDHA-2025-01# → "2025"
    annee = ""
    if "-" in cadre:
        parts = cadre.replace("#", "").split("-")
        if len(parts) >= 2:
            annee = parts[1]
    props.title = f"Rapport budgétaire {type_doc} {annee}".strip()
    props.subject = f"{type_doc} R.314-223"
    props.keywords = "ESMS, EPRD, ERRD, médico-social, DGCS, R.314-223"
    props.created = datetime.now(UTC)
    props.last_modified_by = user_label


def _set_header_footer(doc, ctx: RapportContext) -> None:
    """Header + footer simples avec cadre + numéro de page natif Word.

    python-docx ne génère pas la numérotation automatique sans
    XML brut — v0.2 on met juste le cadre dans le header.
    """
    section = doc.sections[0]
    header_para = section.header.paragraphs[0]
    type_doc = (ctx.document.get("type_document") or "doc").upper()
    header_para.text = f"Rapport budgétaire {type_doc} — {ctx.document.get('cadre_version') or ''}"
    footer_para = section.footer.paragraphs[0]
    footer_para.text = "Généré par Piilot — compta_esms plugin"


def derive_filename(document: dict[str, Any], exercice: dict[str, Any] | None) -> str:
    """Génère un nom de fichier ``RAPPORT_<type>_<annee>.docx``."""
    type_doc = (document.get("type_document") or "doc").upper()
    annee = exercice.get("annee") if exercice else None
    if annee:
        return f"RAPPORT_{type_doc}_{annee}.docx"
    return f"RAPPORT_{type_doc}_{document.get('id', 'export')}.docx"
