"""§AC Partie 1 — Présentation (L5d §13-17).

* Organisme gestionnaire (identité, CPOM, périmètre)
* Liste des ESMS du périmètre (T1)
* Observations générales
* Comptes de résultat (synthèse N-1 / N / N+1)
"""

from __future__ import annotations

from decimal import Decimal

from docx.document import Document as DocumentT

from piilot_pack_compta_esms.exports.docx._base import (
    RapportContext,
    add_heading_styled,
    add_paragraph_text,
    add_table_styled,
    fill_table_row,
    format_currency_fr,
    format_date_fr,
    format_int_fr,
    inject_user_section,
    load_crp_lignes_by_cr,
    load_crs,
    load_etablissements,
    load_exercice,
    load_og,
)


async def fill_partie_1(doc: DocumentT, ctx: RapportContext) -> None:
    """Construit la Partie 1 — Présentation."""
    add_heading_styled(doc, "Partie 1 — Présentation", level=1)

    await _section_og(doc, ctx)
    # §BI — AVANCEMENT_CPOM s'insère après l'OG (juste avant la liste ETS).
    await inject_user_section(doc, ctx, "AVANCEMENT_CPOM")
    await _section_etablissements_table(doc, ctx)
    await _section_observations(doc, ctx)
    # §BI — OBSERVATIONS_GENERALES enrichit la section 1.3 (commentaires user).
    await inject_user_section(doc, ctx, "OBSERVATIONS_GENERALES")
    await _section_comptes_synthese(doc, ctx)
    # §BI — COMPTE_RESULTAT commentaire après la synthèse 1.4.
    await inject_user_section(doc, ctx, "COMPTE_RESULTAT")


async def _section_og(doc: DocumentT, ctx: RapportContext) -> None:
    add_heading_styled(doc, "1.1 Organisme gestionnaire", level=2)
    og = await load_og(ctx)
    if og is None:
        add_paragraph_text(doc, "Organisme gestionnaire introuvable.")
        return
    add_paragraph_text(doc, f"Raison sociale : {og.get('raison_sociale') or '—'}")
    add_paragraph_text(doc, f"FINESS juridique : {og.get('finess_juridique') or '—'}")
    add_paragraph_text(doc, f"Statut juridique : {og.get('statut_juridique') or '—'}")
    add_paragraph_text(doc, f"Adresse : {og.get('adresse') or '—'}")
    cpom_date = format_date_fr(og.get("cpom_date_effet"))
    add_paragraph_text(doc, f"CPOM date d'effet : {cpom_date}")
    if og.get("representant_legal"):
        rep = og.get("representant_legal") or ""
        qual = og.get("representant_qualite") or ""
        add_paragraph_text(doc, f"Représentant légal : {rep} ({qual})")


async def _section_etablissements_table(doc: DocumentT, ctx: RapportContext) -> None:
    """T1 — Liste ESMS du périmètre (L5d §107)."""
    add_heading_styled(doc, "1.2 ESMS du périmètre (T1)", level=2)
    etablissements = await load_etablissements(ctx)
    if not etablissements:
        add_paragraph_text(doc, "Aucun ESMS saisi pour cet OG.")
        return

    headers = [
        "FINESS",
        "Raison sociale",
        "Typologie",
        "Capacité installée",
        "Inclus CPOM",
        "Soumis équilibre",
    ]
    table = add_table_styled(doc, headers)
    for ets in etablissements:
        fill_table_row(
            table,
            [
                ets.get("finess_ets") or "",
                ets.get("raison_sociale") or "",
                ets.get("typologie") or "",
                format_int_fr(ets.get("capacite_installee")),
                "Oui" if ets.get("inclus_cpom") else "Non",
                "Oui" if ets.get("soumis_equilibre") else "Non",
            ],
        )


async def _section_observations(doc: DocumentT, ctx: RapportContext) -> None:
    """Observations générales — placeholder v0.2.

    Le frontend permettra d'enrichir le texte dans une future
    fonctionnalité 'écriture libre' (post-v0.2 §AD). Pour l'instant,
    on imprime un texte standard signalant que la section est à
    enrichir par le cabinet."""
    add_heading_styled(doc, "1.3 Observations générales", level=2)
    add_paragraph_text(
        doc,
        "Cette section est destinée aux observations qualitatives "
        "du cabinet sur l'exercice (contexte sectoriel, événements "
        "marquants, projets stratégiques). À enrichir lors de la "
        "transmission aux autorités tarifaires.",
    )


async def _section_comptes_synthese(doc: DocumentT, ctx: RapportContext) -> None:
    """Synthèse comptes de résultat N-1 / N / N+1 — total document."""
    add_heading_styled(doc, "1.4 Comptes de résultat — synthèse", level=2)
    exercice = await load_exercice(ctx)
    annee = exercice.get("annee") if exercice else None

    crs = await load_crs(ctx)
    lignes_by_cr = await load_crp_lignes_by_cr(ctx)

    total_charges_n1 = Decimal(0)
    total_produits_n1 = Decimal(0)
    total_charges_n = Decimal(0)
    total_produits_n = Decimal(0)

    for cr in crs:
        for li in lignes_by_cr.get(cr["id"], []):
            realise = Decimal(str(li.get("montant_realise") or 0))
            previsions = Decimal(str(li.get("montant_previsions_totales") or 0))
            if li.get("nature") == "charge":
                total_charges_n1 += previsions  # approximation pour N-1
                total_charges_n += realise
            elif li.get("nature") == "produit":
                total_produits_n1 += previsions
                total_produits_n += realise

    headers = ["Indicateur", f"N-1 ({(annee or 0) - 1})", f"N ({annee or '—'})"]
    table = add_table_styled(doc, headers)
    fill_table_row(
        table,
        [
            "Total produits",
            format_currency_fr(total_produits_n1),
            format_currency_fr(total_produits_n),
        ],
    )
    fill_table_row(
        table,
        [
            "Total charges",
            format_currency_fr(total_charges_n1),
            format_currency_fr(total_charges_n),
        ],
    )
    fill_table_row(
        table,
        [
            "Résultat",
            format_currency_fr(total_produits_n1 - total_charges_n1),
            format_currency_fr(total_produits_n - total_charges_n),
        ],
    )
