"""§AC — sous-package DOCX rapport budgétaire EPRD (R.314-223).

Approche from-scratch python-docx (pas de templates DGCS officiels
dans le repo). 3 parties + 7 tableaux types — L5d §11-32.
"""

from __future__ import annotations
