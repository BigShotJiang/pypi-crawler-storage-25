"""§AC Partie 2 — Projections par ESMS (L5d §19-24).

Pour chaque ESMS, une sous-section avec :
* T2 Capacités et activité
* T3 Investissements (placeholder v0.2 — saisie pas dans le scope)
* T4 Effectifs et masse salariale (depuis §P TPER/TER)
* T5 CRP-PGFP 5 ans (depuis §H crp_lignes — agrégation par groupe)
"""

from __future__ import annotations

from decimal import Decimal

from docx.document import Document as DocumentT

from piilot_pack_compta_esms.exports.docx._base import (
    RapportContext,
    add_heading_styled,
    add_paragraph_text,
    add_table_styled,
    fill_table_row,
    format_currency_fr,
    format_int_fr,
    inject_user_section,
    load_crp_lignes_by_cr,
    load_crs,
    load_etablissements,
    load_exercice,
)


async def fill_partie_2(doc: DocumentT, ctx: RapportContext) -> None:
    """Construit la Partie 2 — Projections par ESMS."""
    add_heading_styled(doc, "Partie 2 — Projections par ESMS", level=1)
    # §BI — commentaires globaux avant la boucle ESMS. PREVISIONS_RECETTES
    # + PREVISIONS_DEPENSES sont sémantiquement transverses aux ESMS, donc
    # placés en tête de partie (un seul jeu de commentaires par EPRD).
    await inject_user_section(doc, ctx, "PREVISIONS_RECETTES")
    await inject_user_section(doc, ctx, "PREVISIONS_DEPENSES")
    etablissements = await load_etablissements(ctx)
    if not etablissements:
        add_paragraph_text(doc, "Aucun ESMS dans le périmètre.")
        return
    for idx, ets in enumerate(etablissements, start=1):
        await _section_per_esms(doc, ctx, ets, idx)


async def _section_per_esms(
    doc: DocumentT,
    ctx: RapportContext,
    ets: dict,
    idx: int,
) -> None:
    raison = ets.get("raison_sociale") or "ESMS"
    add_heading_styled(doc, f"2.{idx} {raison}", level=2)
    add_paragraph_text(doc, f"FINESS : {ets.get('finess_ets') or '—'}")
    add_paragraph_text(doc, f"Typologie : {ets.get('typologie') or '—'}")
    add_paragraph_text(
        doc,
        f"Convention collective : {ets.get('convention_collective') or '—'}",
    )

    await _table_capacites(doc, ctx, ets, idx)
    await _table_investissements(doc, ctx, ets, idx)
    await _table_effectifs(doc, ctx, ets, idx)
    await _table_crp_pgfp(doc, ctx, ets, idx)


async def _table_capacites(
    doc: DocumentT,
    ctx: RapportContext,
    ets: dict,
    idx: int,
) -> None:
    """T2 — Capacités et activité par ESMS et année (L5d §111)."""
    add_heading_styled(doc, f"2.{idx}.1 Capacités et activité (T2)", level=3)
    exercice = await load_exercice(ctx)
    annee = exercice.get("annee") if exercice else None

    headers = ["Capacité", f"N-1 ({(annee or 0) - 1})", f"N ({annee or '—'})"]
    table = add_table_styled(doc, headers)
    fill_table_row(
        table,
        [
            "Autorisée",
            format_int_fr(ets.get("capacite_autorisee")),
            format_int_fr(ets.get("capacite_autorisee")),
        ],
    )
    fill_table_row(
        table,
        [
            "Installée",
            format_int_fr(ets.get("capacite_installee")),
            format_int_fr(ets.get("capacite_installee")),
        ],
    )
    fill_table_row(
        table,
        [
            "Financée",
            format_int_fr(ets.get("capacite_financee")),
            format_int_fr(ets.get("capacite_financee")),
        ],
    )


async def _table_investissements(
    doc: DocumentT,
    ctx: RapportContext,
    ets: dict,
    idx: int,
) -> None:
    """T3 — Projets d'investissement (L5d §117).

    v0.2 : placeholder car les projets d'investissement ne sont pas
    encore saisis côté plugin (data model dédié reporté). Le rapport
    laisse une section vide à enrichir.
    """
    add_heading_styled(doc, f"2.{idx}.2 Projets d'investissement (T3)", level=3)
    add_paragraph_text(
        doc,
        "Saisie des projets d'investissement reportée v0.3 — le "
        "cabinet peut compléter cette section manuellement avant "
        "transmission.",
    )


async def _table_effectifs(
    doc: DocumentT,
    ctx: RapportContext,
    ets: dict,
    idx: int,
) -> None:
    """T4 — Effectifs et masse salariale (L5d §123).

    Charge les lignes TPER/TER filtrées par etablissement_id.
    """
    add_heading_styled(doc, f"2.{idx}.3 Effectifs et masse salariale (T4)", level=3)
    from piilot.sdk.db import run_in_thread

    from piilot_pack_compta_esms.repositories import tper_ter_repo

    try:
        rows = await run_in_thread(
            tper_ter_repo.list_by_filter,
            ctx.document_id,
            ets_id=ets["id"],
        )
    except Exception:  # noqa: BLE001
        rows = []

    if not rows:
        add_paragraph_text(doc, "Aucune ligne TPER/TER saisie pour cet ESMS.")
        return

    headers = [
        "Catégorie CNSA",
        "Fonction",
        "ETPR prévus",
        "ETPR réalisés",
        "Rémunérations prévues",
        "Rémunérations réalisées",
    ]
    table = add_table_styled(doc, headers)
    for r in rows:
        fill_table_row(
            table,
            [
                r.get("categorie_cnsa") or "",
                r.get("fonction") or "",
                format_int_fr(r.get("etpr_prevus")),
                format_int_fr(r.get("etpr_realises")),
                format_currency_fr(r.get("remunerations_prevues")),
                format_currency_fr(r.get("remunerations_realisees")),
            ],
        )


async def _table_crp_pgfp(
    doc: DocumentT,
    ctx: RapportContext,
    ets: dict,
    idx: int,
) -> None:
    """T5 — CRP-PGFP par groupe sur 5 ans (L5d §127).

    Agrège les crp_lignes par groupe G1/G2/G3 sur les CR de cet ETS.
    v0.2 : on couvre N-1 + N (vs spec L5d N-1→N+3 qui demande PGFP
    complet). Les colonnes N+1/N+2/N+3 viennent du PGFP §O, qu'on
    n'agrège pas par ETS en v0.2 (le PGFP est global au document).
    """
    add_heading_styled(doc, f"2.{idx}.4 CRP par groupe (T5)", level=3)
    crs = await load_crs(ctx)
    crs_ets = [c for c in crs if str(c.get("etablissement_id") or "") == str(ets["id"])]
    if not crs_ets:
        add_paragraph_text(doc, "Aucun CR rattaché à cet ESMS.")
        return

    lignes_by_cr = await load_crp_lignes_by_cr(ctx)
    # Agrège par (groupe, nature)
    sums: dict[tuple[str, str], Decimal] = {}
    sums_prev: dict[tuple[str, str], Decimal] = {}
    for cr in crs_ets:
        for li in lignes_by_cr.get(cr["id"], []):
            key = (li.get("groupe") or "—", li.get("nature") or "—")
            sums[key] = sums.get(key, Decimal(0)) + Decimal(str(li.get("montant_realise") or 0))
            sums_prev[key] = sums_prev.get(key, Decimal(0)) + Decimal(
                str(li.get("montant_previsions_totales") or 0)
            )

    exercice = await load_exercice(ctx)
    annee = exercice.get("annee") if exercice else None
    headers = ["Groupe", f"N-1 ({(annee or 0) - 1})", f"N ({annee or '—'})"]
    table = add_table_styled(doc, headers)
    for nature_label, nature in (("Charges", "charge"), ("Produits", "produit")):
        for groupe in ("G1", "G2", "G3"):
            key = (groupe, nature)
            fill_table_row(
                table,
                [
                    f"{nature_label} {groupe}",
                    format_currency_fr(sums_prev.get(key)),
                    format_currency_fr(sums.get(key)),
                ],
            )
