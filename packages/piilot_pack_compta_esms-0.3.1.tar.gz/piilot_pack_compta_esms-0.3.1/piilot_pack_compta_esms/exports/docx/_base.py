"""Helpers communs §AC DOCX — format français + sanitize + tableaux.

Le ``RapportContext`` réutilise le ``ExportContext`` §AB pour les
lazy loaders (OG, ETS, CRs, lignes, bilan, etc.). On a juste un
besoin minimal d'extension pour les ratios PGFP (§AA).
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from docx.document import Document as DocumentT
from docx.shared import Pt, RGBColor
from docx.table import Table

from piilot_pack_compta_esms.exports.xlsx._base import (
    ExportContext,
    load_affectations,
    load_bilan,
    load_controles,
    load_crp_lignes_by_cr,
    load_crs,
    load_emprunts,
    load_etablissements,
    load_exercice,
    load_og,
    load_provisions,
    load_rcc,
    load_rgpd,
    load_suivi_affectations,
    load_tf,
    sanitize_for_xlsx,
)

# Re-export pour le reste du package DOCX — pattern aligné §AB.
RapportContext = ExportContext

__all__ = [
    "RapportContext",
    "load_affectations",
    "load_bilan",
    "load_controles",
    "load_crp_lignes_by_cr",
    "load_crs",
    "load_emprunts",
    "load_etablissements",
    "load_exercice",
    "load_og",
    "load_provisions",
    "load_rcc",
    "load_rgpd",
    "load_suivi_affectations",
    "load_tf",
    "load_user_sections",
    "inject_user_section",
    "format_currency_fr",
    "format_date_fr",
    "format_int_fr",
    "format_percent_fr",
    "sanitize",
    "add_heading_styled",
    "add_paragraph_text",
    "add_table_styled",
    "fill_table_row",
]


# ---------------------------------------------------------------------------
# Format helpers — locale français
# ---------------------------------------------------------------------------


def format_currency_fr(value: Decimal | int | float | None) -> str:
    """Decimal → "1 234,56 €". L5d §74 format français.

    Espace milliers, virgule décimale, ``"—"`` si None.
    """
    if value is None:
        return "—"
    rounded = round(float(value), 2)
    # f-string → "1,234.56" → on swap les séparateurs.
    raw = f"{rounded:,.2f}"
    swapped = raw.replace(",", " ").replace(".", ",")
    return f"{swapped} €"


def format_int_fr(value: int | None) -> str:
    """Int → "1 234". None → "—"."""
    if value is None:
        return "—"
    return f"{int(value):,}".replace(",", " ")


def format_percent_fr(value: Decimal | float | None) -> str:
    """Decimal → "12,5 %". None → "—".

    Convention : ``value`` est déjà en %, ex: 12.5 pour 12.5%.
    """
    if value is None:
        return "—"
    rounded = round(float(value), 1)
    return f"{rounded:.1f} %".replace(".", ",")


def format_date_fr(value: date | datetime | str | None) -> str:
    """Date → "dd/mm/yyyy" français. None → "—"."""
    if value is None:
        return "—"
    if isinstance(value, datetime):
        value = value.date()
    elif isinstance(value, str):
        try:
            value = date.fromisoformat(value)
        except (ValueError, TypeError):
            return "—"
    if not isinstance(value, date):
        return "—"
    return value.strftime("%d/%m/%Y")


def sanitize(value: Any) -> str:
    """D-075 reject pipe + trim. Wrapper sur :func:`sanitize_for_xlsx`."""
    return sanitize_for_xlsx(value)


# ---------------------------------------------------------------------------
# Structural helpers — heading / paragraph / table
# ---------------------------------------------------------------------------


def add_heading_styled(doc: DocumentT, text: str, level: int = 1) -> None:
    """Ajoute un heading (level 1-3) avec style cohérent.

    Sanitize automatique (D-075). ``level`` correspond à H1/H2/H3
    Word natif — la pagination/numérotation est laissée à Word
    sans intervention manuelle."""
    safe = sanitize(text)
    doc.add_heading(safe, level=level)


def add_paragraph_text(doc: DocumentT, text: str, *, bold: bool = False) -> None:
    """Ajoute un paragraphe simple. ``bold`` met tout le texte en gras."""
    safe = sanitize(text)
    p = doc.add_paragraph()
    run = p.add_run(safe)
    if bold:
        run.bold = True


def add_table_styled(
    doc: DocumentT,
    headers: list[str],
    *,
    style: str = "Light Grid Accent 1",
) -> Table:
    """Crée un tableau avec 1 ligne header pré-remplie.

    Le caller appellera :func:`fill_table_row` pour chaque row de
    donnée. Le style "Light Grid Accent 1" est natif Word, cohérent
    sur Word/LibreOffice/Pages.
    """
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = style
    header_cells = table.rows[0].cells
    for i, header in enumerate(headers):
        cell = header_cells[i]
        cell.text = sanitize(header)
        # Bold via run.font (style "Light Grid Accent 1" met déjà en évidence)
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.bold = True
                run.font.size = Pt(10)
    return table


def fill_table_row(table: Table, values: list[Any]) -> None:
    """Ajoute une row au tableau et remplit ses cellules.

    Chaque valeur est sanitize automatiquement (str() + reject pipe).
    Si la valeur est déjà un str formaté (ex: format_currency_fr),
    on le garde tel quel — sanitize accepte les str sans pipe.
    """
    row = table.add_row()
    for i, value in enumerate(values):
        if i >= len(row.cells):
            break
        row.cells[i].text = sanitize(value)


# ---------------------------------------------------------------------------
# §BI — user sections loader + injection helper
# ---------------------------------------------------------------------------


async def load_user_sections(ctx: ExportContext) -> dict[str, str]:
    """Charge le mapping ``{section_code: contenu_md}`` (mémoïsé).

    Délègue à :func:`rapport_sections_service.load_sections_by_code`. Si
    la KB n'existe pas encore (EPRDs créés avant §BI) ou si le chargement
    échoue (SDK indispo), retourne ``{}`` — le DOCX continue à se générer
    sans commentaires utilisateur. La cache vit dans ``ctx.custom``.
    """
    if "user_sections" in ctx.custom:
        return ctx.custom["user_sections"]
    from piilot_pack_compta_esms.services import rapport_sections_service

    try:
        sections = await rapport_sections_service.load_sections_by_code(
            document_id=ctx.document_id,
            company_id=ctx.company_id,
        )
    except Exception:  # noqa: BLE001 — DOCX must keep generating
        sections = {}
    ctx.custom["user_sections"] = sections
    return sections


async def inject_user_section(
    doc: DocumentT,
    ctx: ExportContext,
    section_code: str,
) -> None:
    """Injecte les commentaires utilisateur d'une ``section_code`` donnée.

    No-op si :

    * la KB ``rapport_budgetaire_sections`` n'existe pas pour cette
      company (cas EPRD créé avant §BI) ;
    * la section n'a pas de row pour ce document ;
    * le ``contenu_md`` est vide ou whitespace-only.

    Rendu v0.3 : **plain text** (pas de Markdown rendering, cf. décision
    Q4 §BI). Le contenu est split par doubles sauts de ligne (paragraphes
    Markdown standard) et chaque morceau devient un ``add_paragraph_text``.

    v0.4+ : un mini-renderer MD → blocs python-docx (gras/italique/listes)
    arrivera quand on aura le feedback cabinet.
    """
    sections = await load_user_sections(ctx)
    contenu = (sections.get(section_code) or "").strip()
    if not contenu:
        return

    add_heading_styled(doc, "Commentaires", level=3)
    # Split par paragraphes Markdown (doubles sauts de ligne).
    paragraphs = [p.strip() for p in contenu.split("\n\n") if p.strip()]
    for paragraph in paragraphs:
        # Préserve les sauts de ligne simples DANS un paragraphe en les
        # convertissant en espaces (python-docx ne soft-wrap pas natif).
        cleaned = " ".join(line.strip() for line in paragraph.split("\n"))
        add_paragraph_text(doc, cleaned)


def set_default_font(doc: DocumentT, *, name: str = "Calibri", size_pt: int = 10) -> None:
    """Configure la police par défaut du document.

    Appelé une fois en début de :func:`rapport_builder.build_rapport_docx`.
    """
    style = doc.styles["Normal"]
    style.font.name = name
    style.font.size = Pt(size_pt)
    style.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
