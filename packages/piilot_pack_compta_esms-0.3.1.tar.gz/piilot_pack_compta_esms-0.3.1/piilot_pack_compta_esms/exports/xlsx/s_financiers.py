"""Onglets états financiers : Tabl. de financement, Bilan financier,
Provisions, Emprunts.

Mapping L5c §107-160.
"""

from __future__ import annotations

from openpyxl import Workbook

from piilot_pack_compta_esms.exports.xlsx import styles
from piilot_pack_compta_esms.exports.xlsx._base import (
    ExportContext,
    load_bilan,
    load_emprunts,
    load_provisions,
    load_tf,
    write_montant,
    write_text,
)

# ---------------------------------------------------------------------------
# Tabl. de financement (L5c §107-115)
# ---------------------------------------------------------------------------


async def fill_tableau_financement(wb: Workbook, ctx: ExportContext) -> None:
    """Tableau de financement R.314-223.

    Structure : ressources (lignes 7-19) puis emplois (lignes 27-47).
    Colonnes D=BI_N1, E=Réal_N1, H=Prév_N, I=Réal_N (extrait L5c §111-115).
    """
    ws = wb.create_sheet("Tabl. de financement")

    headers = [
        ("A", "Ligne TF"),
        ("B", "Libellé"),
        ("C", "Côté"),
        ("D", "Budget initial N-1"),
        ("E", "Réalisations N-1"),
        ("H", "Prévisions N"),
        ("I", "Réalisations N"),
    ]
    for col_letter, header in headers:
        cell = ws[f"{col_letter}6"]
        cell.value = header
        cell.font = styles.FONT_HEADER
        cell.fill = styles.FILL_HEADER

    rows = await load_tf(ctx)
    ressources = [r for r in rows if (r.get("cote") or "") == "ressources"]
    emplois = [r for r in rows if (r.get("cote") or "") == "emplois"]

    # Section ressources lignes 7-19
    row_idx = 7
    for tf in ressources[:13]:
        write_text(ws, f"A{row_idx}", tf.get("ligne_key") or "")
        write_text(ws, f"B{row_idx}", tf.get("libelle") or "")
        write_text(ws, f"C{row_idx}", "Ressources")
        write_montant(ws, f"D{row_idx}", tf.get("montant_budget_initial_n1"))
        write_montant(ws, f"E{row_idx}", tf.get("montant_realisations_n1"))
        write_montant(ws, f"H{row_idx}", tf.get("montant_previsions_n"))
        write_montant(ws, f"I{row_idx}", tf.get("montant_realisations_n"))
        row_idx += 1

    # Section emplois lignes 27-47
    row_idx = 27
    for tf in emplois[:21]:
        write_text(ws, f"A{row_idx}", tf.get("ligne_key") or "")
        write_text(ws, f"B{row_idx}", tf.get("libelle") or "")
        write_text(ws, f"C{row_idx}", "Emplois")
        write_montant(ws, f"D{row_idx}", tf.get("montant_budget_initial_n1"))
        write_montant(ws, f"E{row_idx}", tf.get("montant_realisations_n1"))
        write_montant(ws, f"H{row_idx}", tf.get("montant_previsions_n"))
        write_montant(ws, f"I{row_idx}", tf.get("montant_realisations_n"))
        row_idx += 1

    # Largeurs
    ws.column_dimensions["A"].width = styles.DEFAULT_COL_WIDTH_CODE
    ws.column_dimensions["B"].width = styles.DEFAULT_COL_WIDTH_LABEL
    ws.column_dimensions["C"].width = 12
    for col in ("D", "E", "H", "I"):
        ws.column_dimensions[col].width = styles.DEFAULT_COL_WIDTH_MONTANT


# ---------------------------------------------------------------------------
# Bilan financier (L5c §121-128)
# ---------------------------------------------------------------------------


async def fill_bilan_financier(wb: Workbook, ctx: ExportContext) -> None:
    """Bilan financier — Actif (lignes 7-62) à gauche, Passif à droite.

    L5c §123-128 :
    * F7-F62 = actif montant_net_n1
    * G7-G62 = actif montant_net_n
    * L7-L62 = passif montant_net_n1
    * M7-M62 = passif montant_net_n
    """
    ws = wb.create_sheet("Bilan financier")

    # En-têtes
    write_text(ws, "A5", "ACTIF")
    ws["A5"].font = styles.FONT_HEADER
    ws["A5"].fill = styles.FILL_HEADER
    write_text(ws, "I5", "PASSIF")
    ws["I5"].font = styles.FONT_HEADER
    ws["I5"].fill = styles.FILL_HEADER

    for col_letter, header in (
        ("B", "Section"),
        ("C", "Compte"),
        ("D", "Libellé"),
        ("F", "Net N-1"),
        ("G", "Net N"),
        ("J", "Section"),
        ("K", "Compte"),
        ("L", "Net N-1"),
        ("M", "Net N"),
    ):
        cell = ws[f"{col_letter}6"]
        cell.value = header
        cell.font = styles.FONT_HEADER
        cell.fill = styles.FILL_HEADER

    rows = await load_bilan(ctx)
    actif = [r for r in rows if (r.get("type_actif_passif") or "") == "actif"]
    passif = [r for r in rows if (r.get("type_actif_passif") or "") == "passif"]

    row_idx = 7
    for ligne in actif[:55]:
        write_text(ws, f"B{row_idx}", ligne.get("section") or "")
        write_text(ws, f"C{row_idx}", ligne.get("compte_m22bis") or "")
        write_text(ws, f"D{row_idx}", ligne.get("poste_label") or "")
        write_montant(ws, f"F{row_idx}", ligne.get("montant_net_n1"))
        write_montant(ws, f"G{row_idx}", ligne.get("montant_net_n"))
        row_idx += 1

    row_idx = 7
    for ligne in passif[:55]:
        write_text(ws, f"J{row_idx}", ligne.get("section") or "")
        write_text(ws, f"K{row_idx}", ligne.get("compte_m22bis") or "")
        write_montant(ws, f"L{row_idx}", ligne.get("montant_net_n1"))
        write_montant(ws, f"M{row_idx}", ligne.get("montant_net_n"))
        row_idx += 1


# ---------------------------------------------------------------------------
# Provisions (L5c §141-144)
# ---------------------------------------------------------------------------


async def fill_provisions(wb: Workbook, ctx: ExportContext) -> None:
    """Provisions, dépréciations, subventions.

    L5c §143-144 : tableau de mouvements
    Solde N-1 / Dotations / Reprises / Solde N.
    """
    ws = wb.create_sheet("Provisions")

    headers = [
        ("C", "Compte CR concerné"),
        ("D", "Compte imputation"),
        ("E", "Objet"),
        ("F", "Solde N-1"),
        ("G", "Dotations N"),
        ("H", "Reprises N"),
        ("I", "Solde N"),
        ("J", "Catégorie"),
    ]
    for col_letter, header in headers:
        cell = ws[f"{col_letter}6"]
        cell.value = header
        cell.font = styles.FONT_HEADER
        cell.fill = styles.FILL_HEADER

    rows = await load_provisions(ctx)
    row_idx = 7
    for ligne in rows[:40]:
        write_text(ws, f"C{row_idx}", ligne.get("compte_cr_concerne") or "")
        write_text(ws, f"D{row_idx}", ligne.get("compte_imputation") or "")
        write_text(ws, f"E{row_idx}", ligne.get("objet") or "")
        write_montant(ws, f"F{row_idx}", ligne.get("solde_debut"))
        write_montant(ws, f"G{row_idx}", ligne.get("dotations"))
        write_montant(ws, f"H{row_idx}", ligne.get("reprises"))
        write_montant(ws, f"I{row_idx}", ligne.get("solde_fin"))
        write_text(ws, f"J{row_idx}", ligne.get("categorie") or "")
        row_idx += 1


# ---------------------------------------------------------------------------
# Emprunts (L5c §146-160)
# ---------------------------------------------------------------------------


async def fill_emprunts(wb: Workbook, ctx: ExportContext) -> None:
    """Emprunts ESSMS privés OU Dettes financières publics selon OG.

    L5c §146-160 : 1 onglet seul ``Emprunts ESSMS privés`` pour les
    OG PNL ; 8 onglets ``ESSMS publics Dettes fin.1`` à ``.8`` pour
    EPS/public. En v0.2 on consolide dans un seul onglet ``Emprunts``
    avec colonne ``type_dette`` qui discrimine — simplification
    acceptable du périmètre d'export.
    """
    ws = wb.create_sheet("Emprunts")

    headers = [
        ("A", "Type dette"),
        ("B", "Référence"),
        ("C", "Organisme prêteur"),
        ("D", "Capital emprunté"),
        ("E", "Taux %"),
        ("F", "Durée (mois)"),
        ("G", "Date début"),
        ("H", "Capital remboursé N-1"),
        ("I", "Capital remboursé N"),
        ("J", "Intérêts N-1"),
        ("K", "Intérêts N"),
        ("L", "Solde restant dû"),
    ]
    for col_letter, header in headers:
        cell = ws[f"{col_letter}6"]
        cell.value = header
        cell.font = styles.FONT_HEADER
        cell.fill = styles.FILL_HEADER

    rows = await load_emprunts(ctx)
    row_idx = 7
    for emp in rows:
        write_text(ws, f"A{row_idx}", emp.get("type_dette") or "")
        write_text(ws, f"B{row_idx}", emp.get("reference_contrat") or "")
        write_text(ws, f"C{row_idx}", emp.get("organisme_preteur") or "")
        write_montant(ws, f"D{row_idx}", emp.get("capital_emprunte"))
        write_montant(ws, f"E{row_idx}", emp.get("taux_interet"))
        ws.cell(row=row_idx, column=6).value = emp.get("duree_mois") or 0
        from piilot_pack_compta_esms.exports.xlsx._base import write_date

        write_date(ws, f"G{row_idx}", emp.get("date_debut"))
        write_montant(ws, f"H{row_idx}", emp.get("capital_rembourse_n1"))
        write_montant(ws, f"I{row_idx}", emp.get("capital_rembourse_n"))
        write_montant(ws, f"J{row_idx}", emp.get("interets_n1"))
        write_montant(ws, f"K{row_idx}", emp.get("interets_n"))
        write_montant(ws, f"L{row_idx}", emp.get("solde_restant_du"))
        row_idx += 1
