"""Onglets CRP : 1 feuille par CR (CRP SOUMIS EQUILIBRE, CRP NON
SOUMIS EQUIL, CRA_SF).

L5c §73-97. Lignes 13-107 (charges) + 120-195 (produits) avec montants
par compte M22Bis dans les colonnes D/E/F/G/H/I/J.
"""

from __future__ import annotations

from decimal import Decimal

from openpyxl import Workbook

from piilot_pack_compta_esms.exports.xlsx import styles
from piilot_pack_compta_esms.exports.xlsx._base import (
    ExportContext,
    load_crp_lignes_by_cr,
    load_crs,
    truncate_sheet_name,
    write_montant,
    write_text,
)

_SHEET_PREFIXES = {
    "soumis_equilibre": "CRP_SE_",
    "non_soumis_equil": "CRP_NSE_",
}


async def fill_crp_sheets(wb: Workbook, ctx: ExportContext) -> None:
    """Crée 1 feuille par CR. Le nom suit le pattern
    ``{prefix}{denomination_truncated}``.

    Pour chaque feuille :
    * `D2` = denomination
    * `D3` = finess_rattachement
    * lignes 13+ = montants (charges G1/G2/G3 + produits G1/G2/G3)
    """
    crs = await load_crs(ctx)
    crp_lignes_by_cr = await load_crp_lignes_by_cr(ctx)

    for cr in crs:
        cr_type = cr.get("cr_type") or ""
        cr_variante = cr.get("cr_variante") or ""

        if cr_type == "CRP_SF":
            sheet_name = truncate_sheet_name(f"CRP_SF_{cr.get('denomination', '')}")
        elif cr_type == "CRA_SF":
            sheet_name = truncate_sheet_name(f"CRA_SF_{cr.get('denomination', '')}")
        elif cr_type in ("CRPP", "CRPA"):
            prefix = _SHEET_PREFIXES.get(cr_variante, "CRP_")
            sheet_name = truncate_sheet_name(f"{prefix}{cr.get('denomination', '')}")
        else:
            sheet_name = truncate_sheet_name(f"CR_{cr.get('denomination', '')}")

        ws = wb.create_sheet(sheet_name)
        # En-tête feuille
        write_text(ws, "D2", cr.get("denomination") or "")
        write_text(ws, "D3", cr.get("finess_rattachement") or "")
        write_text(ws, "A5", f"Type : {cr_type} — Variante : {cr_variante}")
        write_text(ws, "A6", f"Ventilation : {cr.get('ventilation') or ''}")
        write_text(ws, "A7", f"Capacité installée : {cr.get('capacite_installee') or 0}")

        # En-têtes colonnes (ligne 12)
        col_headers = [
            ("A", "Compte M22Bis"),
            ("B", "Libellé"),
            ("C", "Groupe"),
            ("D", "Budget initial"),
            ("E", "Virements crédits"),
            ("F", "Décisions modif"),
            ("G", "Prévisions totales"),
            ("H", "Réalisations"),
            ("I", "Écart €"),
            ("J", "Écart %"),
        ]
        for col_letter, header in col_headers:
            cell = ws[f"{col_letter}12"]
            cell.value = header
            cell.font = styles.FONT_HEADER
            cell.fill = styles.FILL_HEADER

        lignes = crp_lignes_by_cr.get(cr["id"], [])
        # Tri : charges d'abord (groupe G1/G2/G3) puis produits, par compte_m22bis.
        charges = sorted(
            [li for li in lignes if li.get("nature") == "charge"],
            key=lambda x: (x.get("groupe") or "", x.get("compte_m22bis") or ""),
        )
        produits = sorted(
            [li for li in lignes if li.get("nature") == "produit"],
            key=lambda x: (x.get("groupe") or "", x.get("compte_m22bis") or ""),
        )

        row_idx = 13
        for ligne in charges:
            _write_crp_row(ws, row_idx, ligne)
            row_idx += 1
        # Espace puis produits à partir de ligne 120 (L5c convention).
        row_idx = 120
        for ligne in produits:
            _write_crp_row(ws, row_idx, ligne)
            row_idx += 1

        # Largeur colonnes
        ws.column_dimensions["A"].width = styles.DEFAULT_COL_WIDTH_CODE
        ws.column_dimensions["B"].width = styles.DEFAULT_COL_WIDTH_LABEL
        ws.column_dimensions["C"].width = 10
        for col_letter in ("D", "E", "F", "G", "H", "I", "J"):
            ws.column_dimensions[col_letter].width = styles.DEFAULT_COL_WIDTH_MONTANT


def _write_crp_row(ws, row_idx: int, ligne: dict) -> None:
    """Écrit une ligne CRP (charges OU produits) — mêmes colonnes."""
    write_text(ws, f"A{row_idx}", ligne.get("compte_m22bis") or "")
    write_text(ws, f"B{row_idx}", ligne.get("compte_label") or "")
    write_text(ws, f"C{row_idx}", ligne.get("groupe") or "")
    write_montant(ws, f"D{row_idx}", ligne.get("montant_budget_initial"))
    write_montant(ws, f"E{row_idx}", ligne.get("montant_virements_credits"))
    write_montant(ws, f"F{row_idx}", ligne.get("montant_decisions_modif"))
    write_montant(ws, f"G{row_idx}", ligne.get("montant_previsions_totales"))
    write_montant(ws, f"H{row_idx}", ligne.get("montant_realise"))

    # Écart € (I) = realise - previsions_totales
    realise = ligne.get("montant_realise")
    previsions = ligne.get("montant_previsions_totales")
    if realise is not None and previsions is not None:
        ecart = Decimal(str(realise)) - Decimal(str(previsions))
        write_montant(ws, f"I{row_idx}", ecart)
        # Écart % = ecart / previsions
        if previsions and Decimal(str(previsions)) != Decimal(0):
            pct = float(ecart / Decimal(str(previsions)))
            cell = ws[f"J{row_idx}"]
            cell.value = pct
            cell.number_format = styles.PERCENT_FORMAT
