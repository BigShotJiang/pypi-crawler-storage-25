"""Constants stylistiques pour les exports XLSX DGCS.

Pattern : ne pas instancier `Font`/`Alignment` à chaque cellule (coût
mémoire + pickling problématique avec openpyxl). On crée des objets
module-level réutilisés.
"""

from __future__ import annotations

from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

# Formats numériques
MONTANT_FORMAT = "#,##0.00"
"""2 décimales + séparateur de milliers. L5c §225."""

PERCENT_FORMAT = "0.0%"
"""1 décimale après la virgule, signe %. L5c §227."""

DATE_FORMAT = "DD/MM/YYYY"
"""Format français standard. L5c §225."""

INTEGER_FORMAT = "#,##0"
"""Entier avec séparateur de milliers."""


# Fonts
FONT_HEADER = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
FONT_BODY = Font(name="Calibri", size=10)
FONT_TOTAL = Font(name="Calibri", size=10, bold=True)


# Fills
FILL_HEADER = PatternFill(start_color="305496", end_color="305496", fill_type="solid")
FILL_SECTION = PatternFill(start_color="B4C7E7", end_color="B4C7E7", fill_type="solid")
FILL_TOTAL = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")


# Alignments
ALIGN_LEFT = Alignment(horizontal="left", vertical="center", wrap_text=False)
ALIGN_CENTER = Alignment(horizontal="center", vertical="center", wrap_text=False)
ALIGN_RIGHT = Alignment(horizontal="right", vertical="center", wrap_text=False)
ALIGN_WRAP = Alignment(horizontal="left", vertical="top", wrap_text=True)


# Borders
_THIN = Side(border_style="thin", color="808080")
BORDER_ALL = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)


# Largeur colonnes par défaut — appliqué en bulk dans le builder.
DEFAULT_COL_WIDTH_LABEL = 40
"""Colonne libellé (A typiquement)."""

DEFAULT_COL_WIDTH_MONTANT = 15
"""Colonnes montants."""

DEFAULT_COL_WIDTH_CODE = 12
"""Colonnes codes comptes."""
