"""Onglets administratifs ERRD : Page de garde, Id_CR_SF, Sommaire.

Mapping L5c §44-72 du dev-package.
"""

from __future__ import annotations

from openpyxl import Workbook

from piilot_pack_compta_esms.exports.xlsx import styles
from piilot_pack_compta_esms.exports.xlsx._base import (
    ExportContext,
    load_etablissements,
    load_exercice,
    load_og,
    write_date,
    write_text,
)


async def fill_page_de_garde(wb: Workbook, ctx: ExportContext) -> None:
    """Onglet 1 : Page de garde. L5c §47-62.

    Cellules clés :
    * ``A1`` = cadre_version (snapshot D-XX traceability)
    * ``D4`` = annee
    * ``D6`` = finess_juridique
    * ``D8`` = raison_sociale
    * ``D10`` = statut_juridique
    * ``D12`` = adresse
    * ``D14`` = telephone
    * ``D18`` = email
    * ``D20`` = représentant legal + qualité
    * ``D22`` = cpom_date_effet
    * ``E26+`` = tableau ETS
    * ``E33`` = convention_collective majoritaire
    """
    ws = wb.create_sheet("Page de garde", index=0)
    ws["A1"] = ctx.document["cadre_version"]
    ws["A1"].font = styles.FONT_HEADER
    ws["A1"].fill = styles.FILL_HEADER

    exercice = await load_exercice(ctx)
    og = await load_og(ctx)
    etablissements = await load_etablissements(ctx)

    if exercice is not None:
        ws["D4"] = exercice["annee"]
    if og is not None:
        write_text(ws, "D6", og.get("finess_juridique"))
        write_text(ws, "D8", og.get("raison_sociale"))
        write_text(ws, "D10", og.get("statut_juridique"))
        write_text(ws, "D12", og.get("adresse"))
        write_text(ws, "D14", og.get("telephone"))
        write_text(ws, "D18", og.get("email"))
        rep_legal = og.get("representant_legal") or ""
        rep_qual = og.get("representant_qualite") or ""
        full_rep = f"{rep_legal} ({rep_qual})" if rep_qual else rep_legal
        write_text(ws, "D20", full_rep)
        write_date(ws, "D22", og.get("cpom_date_effet"))

    # Tableau ETS — ligne par ETS à partir de E26
    headers = ["FINESS", "Raison sociale", "Typologie", "Capacité installée"]
    for col_idx, header in enumerate(headers):
        cell = ws.cell(row=25, column=5 + col_idx, value=header)
        cell.font = styles.FONT_HEADER
        cell.fill = styles.FILL_HEADER
    for row_idx, ets in enumerate(etablissements, start=26):
        ws.cell(row=row_idx, column=5).value = ets.get("finess_ets") or ""
        ws.cell(row=row_idx, column=6).value = ets.get("raison_sociale") or ""
        ws.cell(row=row_idx, column=7).value = ets.get("typologie") or ""
        ws.cell(row=row_idx, column=8).value = ets.get("capacite_installee") or 0

    # Convention collective majoritaire — heuristique : 1ère ETS.
    if etablissements:
        write_text(ws, "E33", etablissements[0].get("convention_collective") or "")

    # Largeurs colonnes
    for col_letter in ("A", "B", "C", "D"):
        ws.column_dimensions[col_letter].width = styles.DEFAULT_COL_WIDTH_LABEL
    for col_letter in ("E", "F", "G", "H"):
        ws.column_dimensions[col_letter].width = styles.DEFAULT_COL_WIDTH_MONTANT


async def fill_id_cr_sf(wb: Workbook, ctx: ExportContext) -> None:
    """Onglet 2 : Id_CR_SF — tableau des CRs sans FINESS rattaché.

    L5c §63-67 : ``B7:HB9 = comptes_resultat WHERE cr_type IN ('CRP_SF',
    'CRA_SF')``.
    """
    ws = wb.create_sheet("Id_CR_SF")
    from piilot_pack_compta_esms.exports.xlsx._base import load_crs

    crs = await load_crs(ctx)
    sf_crs = [c for c in crs if (c.get("cr_type") or "") in {"CRP_SF", "CRA_SF"}]

    headers = ["CR Type", "Dénomination", "Identifiant CR_SF", "Ventilation", "Ordre"]
    for col_idx, h in enumerate(headers):
        cell = ws.cell(row=6, column=2 + col_idx, value=h)
        cell.font = styles.FONT_HEADER
        cell.fill = styles.FILL_HEADER

    for row_idx, cr in enumerate(sf_crs, start=7):
        ws.cell(row=row_idx, column=2).value = cr.get("cr_type") or ""
        ws.cell(row=row_idx, column=3).value = cr.get("denomination") or ""
        ws.cell(row=row_idx, column=4).value = cr.get("cr_identifiant") or ""
        ws.cell(row=row_idx, column=5).value = cr.get("ventilation") or ""
        ws.cell(row=row_idx, column=6).value = cr.get("ordre") or 0


async def fill_sommaire(wb: Workbook, ctx: ExportContext) -> None:
    """Onglet 3 : Sommaire. L5c §69-72 — auto-rempli côté template
    officiel ; nous on liste statiquement les feuilles présentes.

    Pas de formules — on cherche la cohérence visuelle, pas la mécanique
    DGCS originale (les formules `=Conso!Bx` ne fonctionnent que dans
    le vrai template avec macros).
    """
    ws = wb.create_sheet("Sommaire")
    ws["A1"] = "Sommaire — Document " + ctx.document["cadre_version"]
    ws["A1"].font = styles.FONT_HEADER
    ws["A1"].fill = styles.FILL_HEADER

    ws["A3"] = "Feuille"
    ws["B3"] = "Description"
    ws["A3"].font = styles.FONT_TOTAL
    ws["B3"].font = styles.FONT_TOTAL

    # On remplit après création des autres onglets — voir builder.
    # Pour l'instant on pose le scaffolding ; le builder appellera
    # `_finalize_sommaire` après tous les fills.
    ws.column_dimensions["A"].width = 40
    ws.column_dimensions["B"].width = 60


def finalize_sommaire(wb: Workbook) -> None:
    """Liste les feuilles présentes dans le Sommaire. Appelé en fin de
    build_errd_workbook, une fois que toutes les autres feuilles sont
    présentes."""
    if "Sommaire" not in wb.sheetnames:
        return
    ws = wb["Sommaire"]
    descriptions = {
        "Page de garde": "Identification OG + ETS + CPOM",
        "Id_CR_SF": "Identifiant CR sans FINESS rattaché",
        "Sommaire": "Sommaire",
        "Tabl. de financement": "Tableau de financement (R.314-223)",
        "Bilan financier": "Bilan financier (Annexe 8)",
        "Provisions": "Provisions, dépréciations, subventions",
        "Emprunts": "Emprunts ESSMS privés / Dettes financières publics",
        "Affectation Résultats": "Affectation des résultats (4 variantes)",
        "Suivi Affectation": "Suivi des affectations N-1",
        "Tableau Rcc": "Répartition charges communes",
        "onglet_contrôle": "Snapshot des contrôles intégrés (§Z)",
        "Recueil consentement": "Recueil consentement RGPD (optionnel)",
    }

    row_idx = 4
    for sheet_name in wb.sheetnames:
        if sheet_name == "Sommaire":
            continue
        ws.cell(row=row_idx, column=1).value = sheet_name
        # Description = la dict ou le truncate du nom CRP_*
        desc = descriptions.get(sheet_name)
        if desc is None:
            if sheet_name.startswith("CRP_SE_"):
                desc = "Compte de Résultat Prévisionnel — Soumis Équilibre"
            elif sheet_name.startswith("CRP_NSE_"):
                desc = "Compte de Résultat Prévisionnel — Non Soumis Équilibre"
            elif sheet_name.startswith("CRA_SF_"):
                desc = "Compte de Résultat Annexe — Sans FINESS"
            else:
                desc = ""
        ws.cell(row=row_idx, column=2).value = desc
        row_idx += 1


# Re-export pour les tests
__all__ = [
    "fill_page_de_garde",
    "fill_id_cr_sf",
    "fill_sommaire",
    "finalize_sommaire",
]
