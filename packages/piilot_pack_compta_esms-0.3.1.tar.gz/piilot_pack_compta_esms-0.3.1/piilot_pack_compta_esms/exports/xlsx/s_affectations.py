"""Onglets affectations + suivi + Rcc + contrôles + RGPD.

Mapping L5c §134-204.
"""

from __future__ import annotations

from openpyxl import Workbook

from piilot_pack_compta_esms.exports.xlsx import styles
from piilot_pack_compta_esms.exports.xlsx._base import (
    ExportContext,
    load_affectations,
    load_controles,
    load_rcc,
    load_rgpd,
    load_suivi_affectations,
    write_montant,
    write_text,
)

# ---------------------------------------------------------------------------
# Affectations Résultats (L5c §162-181) — 4 variantes consolidées
# ---------------------------------------------------------------------------


async def fill_affectation_resultats(wb: Workbook, ctx: ExportContext) -> None:
    """Affectation des résultats — 4 variantes (Prive_I, Prive_II,
    Public_I, Public_II) en 1 seul onglet avec colonne ``variante``.

    Simplification v0.2 : L5c spec produit 4 onglets séparés ; on
    consolide pour éviter 4 feuilles vides. Le frontend filtre en aval
    par ``variante`` si besoin.
    """
    ws = wb.create_sheet("Affectation Résultats")

    headers = [
        ("A", "Variante"),
        ("B", "Ventilation"),
        ("C", "Compte M22Bis"),
        ("D", "CR"),
        ("E", "Section"),
        ("F", "Soins/Dépendance"),
        ("G", "Hébergement"),
        ("H", "Total"),
    ]
    for col_letter, header in headers:
        cell = ws[f"{col_letter}5"]
        cell.value = header
        cell.font = styles.FONT_HEADER
        cell.fill = styles.FILL_HEADER

    rows = await load_affectations(ctx)
    row_idx = 6
    for aff in rows:
        write_text(ws, f"A{row_idx}", aff.get("variante") or "")
        write_text(ws, f"B{row_idx}", aff.get("ventilation") or "")
        write_text(ws, f"C{row_idx}", aff.get("compte_m22bis") or "")
        write_text(ws, f"D{row_idx}", str(aff.get("cr_id") or ""))
        write_text(ws, f"E{row_idx}", aff.get("section") or "")
        write_montant(ws, f"F{row_idx}", aff.get("montant_soins_dependance"))
        write_montant(ws, f"G{row_idx}", aff.get("montant_hebergement"))
        write_montant(ws, f"H{row_idx}", aff.get("montant_total"))
        row_idx += 1


# ---------------------------------------------------------------------------
# Suivi Affectation (L5c §183-187)
# ---------------------------------------------------------------------------


async def fill_suivi_affectation(wb: Workbook, ctx: ExportContext) -> None:
    """Suivi des affectations N-1 — soldes/mouvements."""
    ws = wb.create_sheet("Suivi Affectation")

    headers = [
        ("A", "Variante"),
        ("B", "Compte"),
        ("C", "CR"),
        ("D", "Solde N-1"),
        ("E", "Mouvements N"),
        ("F", "Solde N"),
    ]
    for col_letter, header in headers:
        cell = ws[f"{col_letter}5"]
        cell.value = header
        cell.font = styles.FONT_HEADER
        cell.fill = styles.FILL_HEADER

    rows = await load_suivi_affectations(ctx)
    row_idx = 6
    for s in rows:
        write_text(ws, f"A{row_idx}", s.get("variante") or "")
        write_text(ws, f"B{row_idx}", s.get("compte_m22bis") or "")
        write_text(ws, f"C{row_idx}", str(s.get("cr_id") or ""))
        write_montant(ws, f"D{row_idx}", s.get("solde_debut_n"))
        write_montant(ws, f"E{row_idx}", s.get("mouvements_n"))
        write_montant(ws, f"F{row_idx}", s.get("solde_fin_n"))
        row_idx += 1


# ---------------------------------------------------------------------------
# Tableau Rcc (L5c §134-138)
# ---------------------------------------------------------------------------


async def fill_tableau_rcc(wb: Workbook, ctx: ExportContext) -> None:
    """Répartition charges communes (L5c §136-138)."""
    ws = wb.create_sheet("Tableau Rcc")

    headers = [
        ("A", "N° compte"),
        ("B", "Libellé"),
        ("C", "Montant total"),
        ("D", "Clé de répartition"),
        ("E", "CR"),
        ("F", "% affecté"),
        ("G", "Montant affecté"),
        ("H", "Hors CPOM"),
    ]
    for col_letter, header in headers:
        cell = ws[f"{col_letter}8"]
        cell.value = header
        cell.font = styles.FONT_HEADER
        cell.fill = styles.FILL_HEADER

    rows = await load_rcc(ctx)
    row_idx = 9
    for rcc in rows[:27]:  # L5c convention A9:M35 = ~27 lignes
        write_text(ws, f"A{row_idx}", rcc.get("compte_m22bis") or "")
        write_text(ws, f"B{row_idx}", rcc.get("libelle") or "")
        write_montant(ws, f"C{row_idx}", rcc.get("montant_total"))
        write_text(ws, f"D{row_idx}", rcc.get("cle_repartition") or "")
        write_text(ws, f"E{row_idx}", str(rcc.get("cr_id") or ""))
        # % affecté → format pourcentage (Decimal exprimé en %, ex: 25.5)
        pct = rcc.get("pct_affecte")
        if pct is not None:
            cell = ws[f"F{row_idx}"]
            cell.value = float(pct) / 100.0  # convention : DB stocke 25.5 pour 25.5%
            cell.number_format = styles.PERCENT_FORMAT
        write_montant(ws, f"G{row_idx}", rcc.get("montant_affecte"))
        write_montant(ws, f"H{row_idx}", rcc.get("hors_cpom"))
        row_idx += 1


# ---------------------------------------------------------------------------
# onglet_contrôle (L5c §196-203)
# ---------------------------------------------------------------------------


async def fill_onglet_controle(wb: Workbook, ctx: ExportContext) -> None:
    """Snapshot des résultats §Z contrôles persistés.

    L5c §198-203 : ``C6:C320 = valeur_observée`` + ``D6:D320 = statut``.
    """
    ws = wb.create_sheet("onglet_contrôle")

    headers = [
        ("A", "Code"),
        ("B", "Libellé court"),
        ("C", "Valeur observée"),
        ("D", "Statut"),
        ("E", "Sévérité"),
        ("F", "Message"),
    ]
    for col_letter, header in headers:
        cell = ws[f"{col_letter}5"]
        cell.value = header
        cell.font = styles.FONT_HEADER
        cell.fill = styles.FILL_HEADER

    rows = await load_controles(ctx)
    row_idx = 6
    for c in rows:
        write_text(ws, f"A{row_idx}", c.get("code") or "")
        write_text(ws, f"B{row_idx}", "")  # libellé court — lookup KB core hors v0.2
        # Valeur observée : dict JSONB → str compact
        valeurs = c.get("valeurs_observees") or {}
        valeurs_text = ", ".join(f"{k}={v}" for k, v in valeurs.items()) if valeurs else ""
        write_text(ws, f"C{row_idx}", valeurs_text)
        # Statut DGCS : OK / KO / "Non saisi" pour NA (L5c §203)
        statut = c.get("statut") or "na"
        statut_label = {"ok": "OK", "ko": "KO", "na": "Non saisi"}.get(statut, statut)
        write_text(ws, f"D{row_idx}", statut_label)
        write_text(ws, f"E{row_idx}", c.get("severite_observee") or "")
        write_text(ws, f"F{row_idx}", c.get("message_humain") or "")
        row_idx += 1

    # Largeurs
    ws.column_dimensions["A"].width = 10
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 40
    ws.column_dimensions["D"].width = 12
    ws.column_dimensions["E"].width = 12
    ws.column_dimensions["F"].width = 60


# ---------------------------------------------------------------------------
# Recueil consentement (L5c §189-194) — optionnel
# ---------------------------------------------------------------------------


async def fill_recueil_consentement(wb: Workbook, ctx: ExportContext) -> None:
    """Recueil consentement RGPD — optionnel via flag
    ``include_recueil_consentement`` du payload export.

    L5c §189-194 : ``B10 = consentement_cnsa``, ``B16-B33`` = 17
    fédérations consenties (X si consenti).
    """
    if not ctx.include_recueil_consentement:
        return

    ws = wb.create_sheet("Recueil consentement")
    write_text(ws, "A1", "Recueil consentement RGPD (HORS CHAMP RÉGLEMENTAIRE)")
    ws["A1"].font = styles.FONT_HEADER
    ws["A1"].fill = styles.FILL_HEADER

    rgpd = await load_rgpd(ctx)
    if rgpd is None:
        write_text(ws, "A3", "Aucun recueil consentement saisi pour cet exercice.")
        return

    # B10 = consentement_cnsa O/N
    consentement = rgpd.get("consentement_cnsa")
    write_text(ws, "A10", "Consentement CNSA")
    if isinstance(consentement, bool):
        write_text(ws, "B10", "O" if consentement else "N")
    else:
        write_text(ws, "B10", str(consentement or ""))

    # Fédérations consenties (JSONB)
    federations = rgpd.get("federations_consenties") or {}
    # L5c §194 : 17 fédérations standardisées D-090
    federations_order = [
        "MUTUALITE",
        "UNIOPSS",
        "UNAPEI",
        "NEXEM",
        "FNAQPA",
        "UNA",
        "UNCCAS",
        "FHF",
        "FEHAP",
        "SYNERPA",
        "APF",
        "APAJH",
        "GEPSO",
        "ANDICAT",
        "FNMF",
        "FPEP",
        "UGECAM",
    ]
    row_idx = 16
    for fed_code in federations_order:
        write_text(ws, f"A{row_idx}", fed_code)
        consented = federations.get(fed_code, False)
        write_text(ws, f"B{row_idx}", "X" if consented else "")
        row_idx += 1
