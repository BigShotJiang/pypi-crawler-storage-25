"""Orchestrateur §AB — assemble le workbook ERRD complet.

Pattern :

1. Construit un :class:`ExportContext` (lazy loaders).
2. Crée un Workbook openpyxl vide (supprime "Sheet" par défaut).
3. Appelle les fill modules dans l'ordre de la spec L5c.
4. Finalise le Sommaire (liste les feuilles présentes).
5. Sérialise en bytes via BytesIO.

L5c §242 — perf cible < 5s pour ERRD 3 ESMS + 5 CRs. Avec lazy loaders
mémoïsés ExportContext → 6-7 SELECTs DB + ~1200 cell writes openpyxl.
"""

from __future__ import annotations

from io import BytesIO
from typing import Any
from uuid import UUID

from openpyxl import Workbook

from piilot_pack_compta_esms.exports.xlsx._base import ExportContext
from piilot_pack_compta_esms.exports.xlsx.s_admin import (
    fill_id_cr_sf,
    fill_page_de_garde,
    fill_sommaire,
    finalize_sommaire,
)
from piilot_pack_compta_esms.exports.xlsx.s_affectations import (
    fill_affectation_resultats,
    fill_onglet_controle,
    fill_recueil_consentement,
    fill_suivi_affectation,
    fill_tableau_rcc,
)
from piilot_pack_compta_esms.exports.xlsx.s_crp import fill_crp_sheets
from piilot_pack_compta_esms.exports.xlsx.s_financiers import (
    fill_bilan_financier,
    fill_emprunts,
    fill_provisions,
    fill_tableau_financement,
)


async def build_errd_workbook(
    document_id: UUID,
    company_id: UUID,
    document: dict[str, Any],
    *,
    include_recueil_consentement: bool = False,
) -> bytes:
    """Construit le workbook XLSX ERRD complet et retourne ses bytes.

    Args :
        document_id : UUID du document ERRD à exporter.
        company_id : tenant — déjà validé par le service appelant.
        document : row complet du document (chargé par le service).
        include_recueil_consentement : si True, ajoute l'onglet
            ``Recueil consentement`` (optionnel, RGPD HORS champ
            réglementaire D-090).

    Returns :
        Les bytes XLSX prêts à uploader/streamer.

    Raises :
        ValueError si un caractère ``|`` est rencontré (D-075).
    """
    ctx = ExportContext(
        document_id=document_id,
        company_id=company_id,
        document=document,
        include_recueil_consentement=include_recueil_consentement,
    )

    wb = Workbook()
    # openpyxl crée une feuille "Sheet" par défaut — la supprimer.
    default_sheet = wb.active
    if default_sheet is not None and default_sheet.title == "Sheet":
        wb.remove(default_sheet)

    # Ordre L5c §44+ — admin / CRPs / financiers / annexes / RGPD / contrôles
    await fill_page_de_garde(wb, ctx)
    await fill_id_cr_sf(wb, ctx)
    await fill_sommaire(wb, ctx)  # rempli après finalize
    await fill_crp_sheets(wb, ctx)  # 1 feuille par CR
    await fill_tableau_financement(wb, ctx)
    await fill_bilan_financier(wb, ctx)
    await fill_provisions(wb, ctx)
    await fill_emprunts(wb, ctx)
    await fill_affectation_resultats(wb, ctx)
    await fill_suivi_affectation(wb, ctx)
    await fill_tableau_rcc(wb, ctx)
    await fill_onglet_controle(wb, ctx)
    await fill_recueil_consentement(wb, ctx)  # no-op si include=False

    # Finalize sommaire avec la liste des feuilles présentes.
    finalize_sommaire(wb)

    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


def derive_filename(document: dict[str, Any], exercice: dict[str, Any] | None) -> str:
    """Génère un nom de fichier ``<finess>_<annee>_<type>.xlsx``.

    Fallback ``export_<doc_id>.xlsx`` si finess/annee absents."""
    type_doc = (document.get("type_document") or "doc").upper()
    annee = exercice.get("annee") if exercice else None
    # Le finess est sur l'OG, qu'on n'a pas ici — fallback document id.
    if annee:
        return f"{type_doc}_{annee}.xlsx"
    return f"{type_doc}_{document.get('id', 'export')}.xlsx"
