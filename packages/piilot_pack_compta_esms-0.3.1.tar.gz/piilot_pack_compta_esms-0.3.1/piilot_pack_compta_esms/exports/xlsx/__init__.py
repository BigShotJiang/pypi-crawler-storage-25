"""§AB — sous-package XLSX builder."""

from __future__ import annotations
