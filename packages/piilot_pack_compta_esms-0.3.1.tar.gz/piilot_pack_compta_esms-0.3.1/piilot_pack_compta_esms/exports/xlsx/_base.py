"""ExportContext + helpers communs aux fill modules §AB.

Le context est construit une fois par export et passé aux fill
fonctions. Lazy loaders mémoïsés via ``custom`` dict pour éviter
les SELECT répétés entre onglets.

Helpers exposés :
* :func:`sanitize_for_xlsx` — D-075 reject pipe + trim
* :func:`format_montant` — Decimal → float 2 décimales
* :func:`write_cell` — wrapper avec sanitize automatique
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal
from typing import Any
from uuid import UUID

from openpyxl.worksheet.worksheet import Worksheet
from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.exports.xlsx import styles

# ---------------------------------------------------------------------------
# ExportContext
# ---------------------------------------------------------------------------


@dataclass
class ExportContext:
    """État de chargement lazy partagé entre tous les onglets d'un export.

    Le builder fournit ``document`` (déjà chargé pour validation tenant).
    Les autres champs sont chargés à la demande via les helpers ``load_*``
    (1 SELECT par section, mémoïsé dans ``custom``).
    """

    document_id: UUID
    company_id: UUID
    document: dict[str, Any]
    include_recueil_consentement: bool = False
    custom: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Lazy loaders — patternless wrappers autour des repos
# ---------------------------------------------------------------------------


async def load_og(ctx: ExportContext) -> dict[str, Any] | None:
    """Charge l'OG du document via l'exercice associé."""
    if "og" in ctx.custom:
        return ctx.custom["og"]
    from piilot_pack_compta_esms.repositories import (
        document_repo,
        og_repo,
    )

    exercice = await run_in_thread(document_repo.exercice_lookup, ctx.document["exercice_id"])
    if exercice is None:
        ctx.custom["og"] = None
        return None
    og = await run_in_thread(og_repo.get_by_id, exercice["og_id"])
    ctx.custom["og"] = og
    ctx.custom["exercice"] = exercice
    return og


async def load_exercice(ctx: ExportContext) -> dict[str, Any] | None:
    """Charge l'exercice du document (mémoïsé via load_og côté custom)."""
    if "exercice" in ctx.custom:
        return ctx.custom["exercice"]
    await load_og(ctx)
    return ctx.custom.get("exercice")


async def load_etablissements(ctx: ExportContext) -> list[dict[str, Any]]:
    """Charge les ETS du même OG que le document."""
    if "etablissements" in ctx.custom:
        return ctx.custom["etablissements"]
    og = await load_og(ctx)
    if og is None:
        ctx.custom["etablissements"] = []
        return []
    from piilot_pack_compta_esms.repositories import etablissement_repo

    ets = await run_in_thread(etablissement_repo.list_by_og, og["id"])
    ctx.custom["etablissements"] = ets
    return ets


async def load_crs(ctx: ExportContext) -> list[dict[str, Any]]:
    """Charge les CRs du document."""
    if "crs" in ctx.custom:
        return ctx.custom["crs"]
    from piilot_pack_compta_esms.repositories import cr_repo

    crs = await run_in_thread(cr_repo.list_by_document, ctx.document_id)
    ctx.custom["crs"] = crs
    return crs


async def load_crp_lignes_by_cr(ctx: ExportContext) -> dict[UUID, list[dict[str, Any]]]:
    """Charge les crp_lignes indexées par cr_id."""
    if "crp_lignes_by_cr" in ctx.custom:
        return ctx.custom["crp_lignes_by_cr"]
    from piilot_pack_compta_esms.repositories import crp_ligne_repo

    crs = await load_crs(ctx)
    index: dict[UUID, list[dict[str, Any]]] = {}
    for cr in crs:
        lignes = await run_in_thread(crp_ligne_repo.list_by_cr, cr["id"], groupe=None, nature=None)
        index[cr["id"]] = lignes
    ctx.custom["crp_lignes_by_cr"] = index
    return index


async def load_bilan(ctx: ExportContext) -> list[dict[str, Any]]:
    """Charge les lignes bilan financier (type_bilan='financier')."""
    if "bilan_financier" in ctx.custom:
        return ctx.custom["bilan_financier"]
    from piilot_pack_compta_esms.repositories import bilan_repo

    rows = await run_in_thread(bilan_repo.list_by_document, ctx.document_id, type_bilan="financier")
    ctx.custom["bilan_financier"] = rows
    return rows


async def load_tf(ctx: ExportContext) -> list[dict[str, Any]]:
    """Charge les lignes Tableau de financement."""
    if "tf_lignes" in ctx.custom:
        return ctx.custom["tf_lignes"]
    from piilot_pack_compta_esms.repositories import tf_repo

    rows = await run_in_thread(tf_repo.list_by_document, ctx.document_id)
    ctx.custom["tf_lignes"] = rows
    return rows


async def load_affectations(ctx: ExportContext) -> list[dict[str, Any]]:
    """Charge les affectations résultats."""
    if "affectations" in ctx.custom:
        return ctx.custom["affectations"]
    from piilot_pack_compta_esms.repositories import affectation_repo

    rows = await run_in_thread(affectation_repo.list_by_document, ctx.document_id)
    ctx.custom["affectations"] = rows
    return rows


async def load_suivi_affectations(ctx: ExportContext) -> list[dict[str, Any]]:
    if "suivi_affectations" in ctx.custom:
        return ctx.custom["suivi_affectations"]
    from piilot_pack_compta_esms.repositories import suivi_affectation_repo

    rows = await run_in_thread(suivi_affectation_repo.list_by_document, ctx.document_id)
    ctx.custom["suivi_affectations"] = rows
    return rows


async def load_provisions(ctx: ExportContext) -> list[dict[str, Any]]:
    if "provisions" in ctx.custom:
        return ctx.custom["provisions"]
    from piilot_pack_compta_esms.repositories import provisions_repo

    rows = await run_in_thread(provisions_repo.list_by_document, ctx.document_id)
    ctx.custom["provisions"] = rows
    return rows


async def load_emprunts(ctx: ExportContext) -> list[dict[str, Any]]:
    if "emprunts" in ctx.custom:
        return ctx.custom["emprunts"]
    from piilot_pack_compta_esms.repositories import emprunts_repo

    rows = await run_in_thread(emprunts_repo.list_by_document, ctx.document_id)
    ctx.custom["emprunts"] = rows
    return rows


async def load_rcc(ctx: ExportContext) -> list[dict[str, Any]]:
    if "rcc" in ctx.custom:
        return ctx.custom["rcc"]
    from piilot_pack_compta_esms.repositories import rcc_repo

    rows = await run_in_thread(rcc_repo.list_by_document, ctx.document_id)
    ctx.custom["rcc"] = rows
    return rows


async def load_controles(ctx: ExportContext) -> list[dict[str, Any]]:
    """Charge les résultats de contrôles §Z déjà persistés."""
    if "controles" in ctx.custom:
        return ctx.custom["controles"]
    from piilot_pack_compta_esms.repositories import controles_resultats_repo

    rows = await run_in_thread(controles_resultats_repo.list_by_document, ctx.document_id)
    ctx.custom["controles"] = rows
    return rows


async def load_rgpd(ctx: ExportContext) -> dict[str, Any] | None:
    """Charge le recueil consentement RGPD pour l'exercice."""
    if "rgpd" in ctx.custom:
        return ctx.custom["rgpd"]
    from piilot_pack_compta_esms.repositories import rgpd_repo

    rgpd = await run_in_thread(rgpd_repo.get_by_exercice, ctx.document["exercice_id"])
    ctx.custom["rgpd"] = rgpd
    return rgpd


# ---------------------------------------------------------------------------
# Sanitize + format helpers
# ---------------------------------------------------------------------------


def sanitize_for_xlsx(value: Any) -> str:
    """D-075 — reject `|` + trim espaces multiples. L5c §211-220.

    Si value est None → "". Si value est non-str → str(value). Le caller
    décide quand appliquer (typiquement avant chaque ``ws.cell(value=)``)."""
    if value is None:
        return ""
    text = str(value)
    if "|" in text:
        raise ValueError("pipe_char_forbidden:caractère '|' interdit dans valeurs DGCS (D-075)")
    # Trim espaces multiples + leading/trailing
    return " ".join(text.split())


def format_montant(value: Decimal | int | float | None) -> float | None:
    """Decimal → float 2 décimales pour écriture XLSX.

    Le formatage visuel (``#,##0.00``) est appliqué via cell.number_format.
    None → None (cellule vide)."""
    if value is None:
        return None
    return round(float(value), 2)


def format_date(value: date | datetime | str | None) -> date | None:
    """Date Python → date openpyxl (format DGCS dd/mm/yyyy via cell.number_format)."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    # str ISO YYYY-MM-DD
    try:
        return date.fromisoformat(str(value))
    except (ValueError, TypeError):
        return None


# ---------------------------------------------------------------------------
# Cell writing helpers
# ---------------------------------------------------------------------------


def write_text(ws: Worksheet, cell_ref: str, value: Any) -> None:
    """Écrit un libellé textuel (sanitize auto)."""
    ws[cell_ref] = sanitize_for_xlsx(value)


def write_montant(ws: Worksheet, cell_ref: str, value: Decimal | int | float | None) -> None:
    """Écrit un montant avec number_format = #,##0.00."""
    cell = ws[cell_ref]
    cell.value = format_montant(value)
    cell.number_format = styles.MONTANT_FORMAT


def write_percent(ws: Worksheet, cell_ref: str, value: Decimal | float | None) -> None:
    """Écrit un pourcentage (0.105 → 10,5%). number_format=0.0%."""
    cell = ws[cell_ref]
    if value is None:
        cell.value = None
    else:
        # Si value est déjà en % (ex: 50 pour 50%), convertir en décimal pour Excel.
        # Convention v0.2 : on stocke en décimal (50% = 0.5).
        cell.value = float(value)
    cell.number_format = styles.PERCENT_FORMAT


def write_date(ws: Worksheet, cell_ref: str, value: date | datetime | str | None) -> None:
    """Écrit une date avec number_format = DD/MM/YYYY."""
    cell = ws[cell_ref]
    cell.value = format_date(value)
    cell.number_format = styles.DATE_FORMAT


def write_integer(ws: Worksheet, cell_ref: str, value: int | None) -> None:
    cell = ws[cell_ref]
    cell.value = value
    cell.number_format = styles.INTEGER_FORMAT


def truncate_sheet_name(name: str, *, max_length: int = 31) -> str:
    """Excel limite les noms de feuilles à 31 caractères + caractères
    interdits ``[\\]:*?/``. Truncate + replace pour respecter."""
    forbidden = set("[]:*?/\\")
    cleaned = "".join("_" if c in forbidden else c for c in name)
    if len(cleaned) <= max_length:
        return cleaned
    return cleaned[: max_length - 3] + "..."
