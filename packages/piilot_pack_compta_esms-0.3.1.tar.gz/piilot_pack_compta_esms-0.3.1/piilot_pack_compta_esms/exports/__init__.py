"""§AB — Exports (XLSX v0.2, DOCX v0.3+).

Package qui assemble les onglets XLSX du cadre ERRD DGCS
(``#ERRDHA-2025-01#``) à partir de la donnée saisie côté plugin.

Approche from-scratch openpyxl (pas de template DGCS officiel à
copier) — choix v0.2 motivé par : absence des templates dans le repo,
tests unitaires triviaux, périmètre v0.2 limité à 1 cadre.

Onglets calculés (Synthèse_CR, Tableau CAF, Ratios) → valeurs directes
écrites via les services §I/§AA, pas de formules Excel.
"""

from __future__ import annotations
