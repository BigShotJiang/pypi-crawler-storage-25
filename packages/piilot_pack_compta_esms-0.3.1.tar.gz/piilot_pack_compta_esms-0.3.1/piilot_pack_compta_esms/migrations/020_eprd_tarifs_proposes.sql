-- Migration 020 — EPRD tarifs proposés (§BB v0.3).
--
-- Une table pour modéliser les tarifs prévisionnels saisis par
-- l'organisme gestionnaire en EPRD + les montants notifiés par les
-- autorités de tarification (ARS / CD) une fois validés. Cardinalité
-- 1 row par (document_id EPRD, etablissement_id, section).
--
-- Sections (D-083 + D-085) :
--   * HEBERGEMENT          — compétence CD
--   * DEPENDANCE           — compétence CD
--   * SOINS                — compétence ARS
--   * SOINS_AUTONOMIE_SEA  — fusion D+S quand forfait_global_unique=true (D-085)
--
-- Workflow row-level (5 statuts) :
--   PROPOSE             — tarif déposé par l'ESMS (default à l'insert)
--   VALIDE_ARS          — ARS a validé (CD pas encore)
--   VALIDE_CD           — CD a validé (ARS pas encore)
--   VALIDE_TRIPARTITE   — les deux ATC ont validé → row exécutoire
--   REJETE              — au moins une ATC a rejeté
--
-- Le workflow row-level coexiste avec le workflow du document EPRD
-- (§S) — pour qu'un EPRD devienne EXECUTOIRE, **tous** ses tarifs
-- proposés doivent être VALIDE_TRIPARTITE (ou les rows manquantes
-- pour les sections non applicables, en laissant à NULL).
--
-- Le service C1 §BD (R.314-222 condition 1 — "produits de la
-- tarification = ceux notifiés") consommera cette table en agrégeant
-- SUM(montant_propose) vs SUM(montant_notifie) par section
-- (cf. ``cpom_service.is_etablissement_in_cpom`` pattern).
--
-- ``ecart = montant_notifie - montant_propose`` est GENERATED ALWAYS
-- AS STORED. NULL si ``montant_notifie`` n'est pas encore renseigné
-- (PostgreSQL gère NULL - x = NULL nativement).

-- UP
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.eprd_tarifs_proposes (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id          UUID NOT NULL,
    document_id         UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    etablissement_id    UUID NOT NULL REFERENCES compta_esms.etablissements(id) ON DELETE CASCADE,
    section             TEXT NOT NULL,
    libelle             TEXT,
    montant_propose     NUMERIC(14, 2) NOT NULL,
    montant_notifie     NUMERIC(14, 2),
    ecart               NUMERIC(14, 2) GENERATED ALWAYS AS (montant_notifie - montant_propose) STORED,
    motif               TEXT,
    statut              TEXT NOT NULL DEFAULT 'PROPOSE',
    date_validation     DATE,
    valide_par          TEXT,
    motif_rejet         TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (document_id, etablissement_id, section)
);

COMMENT ON TABLE compta_esms.eprd_tarifs_proposes IS
    'Tarifs prévisionnels EPRD (§BB v0.3). 1 row par (doc, ETS, section). '
    'montant_propose saisi par l''ESMS, montant_notifie écrit par l''ATC '
    'à validation. ecart = notifie - propose (GENERATED, NULL si non '
    'notifié). Consommé par §BD C1 R.314-222.';
COMMENT ON COLUMN compta_esms.eprd_tarifs_proposes.section IS
    'HEBERGEMENT (CD) / DEPENDANCE (CD) / SOINS (ARS) / SOINS_AUTONOMIE_SEA '
    '(fusion D+S, D-085 forfait_global_unique).';
COMMENT ON COLUMN compta_esms.eprd_tarifs_proposes.statut IS
    'PROPOSE → VALIDE_ARS / VALIDE_CD / VALIDE_TRIPARTITE / REJETE. '
    'Workflow row-level distinct du workflow document EPRD §S.';
COMMENT ON COLUMN compta_esms.eprd_tarifs_proposes.ecart IS
    'GENERATED ALWAYS — montant_notifie - montant_propose. NULL tant '
    'que pas notifié.';

CREATE INDEX IF NOT EXISTS idx_tarifs_proposes_company
    ON compta_esms.eprd_tarifs_proposes(company_id);
CREATE INDEX IF NOT EXISTS idx_tarifs_proposes_document
    ON compta_esms.eprd_tarifs_proposes(document_id);
CREATE INDEX IF NOT EXISTS idx_tarifs_proposes_ets
    ON compta_esms.eprd_tarifs_proposes(etablissement_id);
-- Index partiel pour les rows non encore notifiées (worklist ATC).
CREATE INDEX IF NOT EXISTS idx_tarifs_proposes_pending
    ON compta_esms.eprd_tarifs_proposes(document_id)
    WHERE statut = 'PROPOSE';


-- ============================================================
-- CHECK constraints idempotents
-- ============================================================

DO $$
BEGIN
    -- section : 4 valeurs DGCS (D-083 + D-085)
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'eprd_tarifs_proposes_section_check'
    ) THEN
        ALTER TABLE compta_esms.eprd_tarifs_proposes
            ADD CONSTRAINT eprd_tarifs_proposes_section_check
            CHECK (section IN (
                'HEBERGEMENT', 'DEPENDANCE', 'SOINS', 'SOINS_AUTONOMIE_SEA'
            ));
    END IF;

    -- statut : 5 valeurs workflow row-level
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'eprd_tarifs_proposes_statut_check'
    ) THEN
        ALTER TABLE compta_esms.eprd_tarifs_proposes
            ADD CONSTRAINT eprd_tarifs_proposes_statut_check
            CHECK (statut IN (
                'PROPOSE', 'VALIDE_ARS', 'VALIDE_CD',
                'VALIDE_TRIPARTITE', 'REJETE'
            ));
    END IF;

    -- montant_propose : >= 0 (un tarif négatif n'a pas de sens métier)
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'eprd_tarifs_proposes_montant_propose_positive'
    ) THEN
        ALTER TABLE compta_esms.eprd_tarifs_proposes
            ADD CONSTRAINT eprd_tarifs_proposes_montant_propose_positive
            CHECK (montant_propose >= 0);
    END IF;

    -- montant_notifie : >= 0 si non NULL
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'eprd_tarifs_proposes_montant_notifie_positive'
    ) THEN
        ALTER TABLE compta_esms.eprd_tarifs_proposes
            ADD CONSTRAINT eprd_tarifs_proposes_montant_notifie_positive
            CHECK (montant_notifie IS NULL OR montant_notifie >= 0);
    END IF;

    -- libelle : max 255
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'eprd_tarifs_proposes_libelle_len'
    ) THEN
        ALTER TABLE compta_esms.eprd_tarifs_proposes
            ADD CONSTRAINT eprd_tarifs_proposes_libelle_len
            CHECK (libelle IS NULL OR length(libelle) <= 255);
    END IF;

    -- motif : max 500
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'eprd_tarifs_proposes_motif_len'
    ) THEN
        ALTER TABLE compta_esms.eprd_tarifs_proposes
            ADD CONSTRAINT eprd_tarifs_proposes_motif_len
            CHECK (motif IS NULL OR length(motif) <= 500);
    END IF;

    -- motif_rejet : max 1000
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'eprd_tarifs_proposes_motif_rejet_len'
    ) THEN
        ALTER TABLE compta_esms.eprd_tarifs_proposes
            ADD CONSTRAINT eprd_tarifs_proposes_motif_rejet_len
            CHECK (motif_rejet IS NULL OR length(motif_rejet) <= 1000);
    END IF;

    -- valide_par : max 255
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'eprd_tarifs_proposes_valide_par_len'
    ) THEN
        ALTER TABLE compta_esms.eprd_tarifs_proposes
            ADD CONSTRAINT eprd_tarifs_proposes_valide_par_len
            CHECK (valide_par IS NULL OR length(valide_par) <= 255);
    END IF;
END $$;


-- ============================================================
-- RLS FORCE company-scoped
-- ============================================================

ALTER TABLE compta_esms.eprd_tarifs_proposes ENABLE ROW LEVEL SECURITY;
ALTER TABLE compta_esms.eprd_tarifs_proposes FORCE  ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname = 'compta_esms'
          AND tablename  = 'eprd_tarifs_proposes'
          AND policyname = 'eprd_tarifs_proposes_company_isolation'
    ) THEN
        CREATE POLICY eprd_tarifs_proposes_company_isolation
            ON compta_esms.eprd_tarifs_proposes
            USING (company_id = current_setting('app.current_company_id', true)::uuid)
            WITH CHECK (company_id = current_setting('app.current_company_id', true)::uuid);
    END IF;
END $$;


-- ============================================================
-- Trigger updated_at
-- ============================================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger
        WHERE tgname = 'tg_eprd_tarifs_proposes_updated_at'
    ) THEN
        CREATE TRIGGER tg_eprd_tarifs_proposes_updated_at
            BEFORE UPDATE ON compta_esms.eprd_tarifs_proposes
            FOR EACH ROW EXECUTE FUNCTION compta_esms.tg_set_updated_at();
    END IF;
END $$;


-- ============================================================
-- DOWN  (reference only — pas joué par le runner idempotent)
-- ============================================================
-- DROP TABLE IF EXISTS compta_esms.eprd_tarifs_proposes;
