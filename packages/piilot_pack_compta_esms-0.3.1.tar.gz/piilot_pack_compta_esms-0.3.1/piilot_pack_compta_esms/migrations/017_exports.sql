-- Migration 017 — Historique des exports (§AB L2 §19).
--
-- 1 ligne par export généré (XLSX en v0.2, DOCX en §AC). Le fichier
-- lui-même vit dans le bucket S3 du plugin (clé persistée dans
-- ``s3_key``). Soft-delete via ``deleted_at`` — la ligne reste pour
-- audit, l'objet S3 sera nettoyé par un cron post-v0.2 (hors §AB).
--
-- L2 §19.3 GET /documents/{id}/exports = list (filter deleted_at NULL).
-- L2 §19.4 GET /exports/{id}/download = stream via storage.get_object.
-- L2 §19.5 DELETE /exports/{id} = update deleted_at + (option future :
--   appel storage.delete_object dans le cron cleanup).

-- UP
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.exports (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id          UUID NOT NULL,
    document_id         UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    type                TEXT NOT NULL CHECK (type IN ('xlsx', 'docx')),
    s3_key              TEXT NOT NULL,
    filename            TEXT NOT NULL,
    file_size           BIGINT NOT NULL CHECK (file_size >= 0),
    generated_by_user_id UUID,
    generated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at          TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.exports IS
    'Historique des exports générés (§AB L2 §19). Soft-delete via '
    'deleted_at — la ligne reste pour audit. s3_key pointe vers '
    'plugins/compta_esms/<key> (préfixe ajouté par le SDK).';
COMMENT ON COLUMN compta_esms.exports.s3_key IS
    'Clé S3 sans le préfixe plugins/compta_esms/ — le SDK la rajoute.';
COMMENT ON COLUMN compta_esms.exports.filename IS
    'Nom du fichier proposé au download (Content-Disposition). Format : '
    '<finess>_<annee>_<type>.xlsx.';


-- RLS FORCE
ALTER TABLE compta_esms.exports ENABLE ROW LEVEL SECURITY;
ALTER TABLE compta_esms.exports FORCE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname = 'compta_esms'
          AND tablename  = 'exports'
          AND policyname = 'tenant_isolation'
    ) THEN
        CREATE POLICY tenant_isolation ON compta_esms.exports
            USING (company_id::text = current_setting('app.current_company_id', true))
            WITH CHECK (company_id::text = current_setting('app.current_company_id', true));
    END IF;
END $$;


-- Trigger updated_at
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger
        WHERE tgname = 'exports_set_updated_at'
    ) THEN
        CREATE TRIGGER exports_set_updated_at
            BEFORE UPDATE ON compta_esms.exports
            FOR EACH ROW
            EXECUTE FUNCTION compta_esms.set_updated_at();
    END IF;
END $$;


-- Index : list par doc, by-id (PK natif), filter actifs.
CREATE INDEX IF NOT EXISTS idx_exports_doc
    ON compta_esms.exports (document_id)
    WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_exports_company
    ON compta_esms.exports (company_id);


-- ============================================================
-- DOWN  (reference only — pas joué par le runner idempotent)
-- ============================================================
-- DROP TABLE IF EXISTS compta_esms.exports;
