-- Migration 015 — Clés de répartition des charges communes (§Y, D-057).
--
-- Table support de l'auto-ventilation H/D/S/SEA dans le CRP analytique
-- EHPAD (D-083 + D-085). 1 ligne par couple (établissement, compte
-- M22Bis, exercice_annee) avec les 4 taux qui doivent sommer à 100.
--
-- KB20 §8.2 :
-- > Les clefs effectivement retenues par le gestionnaire doivent être
-- > autant que possibles **constantes d'une année sur l'autre** et
-- > **explicitées** dans le dossier. Leur **évolution devrait être en
-- > cohérence avec les engagements du CPOM**.
--
-- En v0.2 on ne fait pas d'enforcement strict de la stabilité année /
-- année — c'est un soft WARN au niveau service quand le cabinet créé
-- une clé qui diffère de celle de N-1 pour le même (ETS, compte).
-- L'enforcement strict CPOM-aware est reporté v0.3 (D-057).
--
-- D-055 (règles dures) ne touche pas cette table — c'est un mapping
-- statique hard-coded dans services/ventilation_rules.py (compte 65
-- → 100% H, compte 66 → 100% S, etc.). Cette table sert pour TOUS
-- les autres comptes ventilables (charges communes 602xx, 60xx).

-- UP
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.cles_repartition_charges_communes (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id          UUID NOT NULL,
    etablissement_id    UUID NOT NULL REFERENCES compta_esms.etablissements(id) ON DELETE CASCADE,
    compte_m22bis       TEXT NOT NULL,
    exercice_annee      SMALLINT NOT NULL CHECK (exercice_annee BETWEEN 2020 AND 2050),
    taux_hebergement    NUMERIC(5, 2) NOT NULL DEFAULT 0,
    taux_dependance     NUMERIC(5, 2) NOT NULL DEFAULT 0,
    taux_soins          NUMERIC(5, 2) NOT NULL DEFAULT 0,
    taux_soins_autonomie NUMERIC(5, 2) NOT NULL DEFAULT 0,
    source              TEXT,
    notes               TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (etablissement_id, compte_m22bis, exercice_annee)
);

COMMENT ON TABLE compta_esms.cles_repartition_charges_communes IS
    'Clés répartition par établissement × compte M22Bis × exercice. '
    'D-057 KB20 §8.2 — stabilité année/année (soft WARN v0.2). '
    'taux_h+d+s+sea = 100 (tolérance 0.01). SEA seulement pour EHPAD '
    'avec forfait_global_unique=true (D-085).';

COMMENT ON COLUMN compta_esms.cles_repartition_charges_communes.taux_hebergement IS
    'Pourcentage [0..100] vers section Hébergement.';
COMMENT ON COLUMN compta_esms.cles_repartition_charges_communes.taux_dependance IS
    'Pourcentage [0..100] vers section Dépendance.';
COMMENT ON COLUMN compta_esms.cles_repartition_charges_communes.taux_soins IS
    'Pourcentage [0..100] vers section Soins.';
COMMENT ON COLUMN compta_esms.cles_repartition_charges_communes.taux_soins_autonomie IS
    'Pourcentage [0..100] vers Soins-Autonomie (SEA, D-085). '
    'Reste à 0 si l''établissement n''est pas en forfait global unique.';
COMMENT ON COLUMN compta_esms.cles_repartition_charges_communes.source IS
    'Source documentaire de la clé (ex: "CPOM 2024-2028", "Dossier interne v3"). '
    'Helper pour traçabilité D-057 KB20 §8.2.';

-- CHECK constraints — taux nonneg + Σ = 100 ±0.01.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint c
        JOIN pg_class t      ON t.oid = c.conrelid
        JOIN pg_namespace n  ON n.oid = t.relnamespace
        WHERE n.nspname = 'compta_esms'
          AND t.relname = 'cles_repartition_charges_communes'
          AND c.conname = 'cles_repartition_taux_nonneg'
    ) THEN
        ALTER TABLE compta_esms.cles_repartition_charges_communes
            ADD CONSTRAINT cles_repartition_taux_nonneg
            CHECK (
                taux_hebergement     >= 0 AND taux_hebergement     <= 100 AND
                taux_dependance      >= 0 AND taux_dependance      <= 100 AND
                taux_soins           >= 0 AND taux_soins           <= 100 AND
                taux_soins_autonomie >= 0 AND taux_soins_autonomie <= 100
            );
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint c
        JOIN pg_class t      ON t.oid = c.conrelid
        JOIN pg_namespace n  ON n.oid = t.relnamespace
        WHERE n.nspname = 'compta_esms'
          AND t.relname = 'cles_repartition_charges_communes'
          AND c.conname = 'cles_repartition_taux_sum_100'
    ) THEN
        ALTER TABLE compta_esms.cles_repartition_charges_communes
            ADD CONSTRAINT cles_repartition_taux_sum_100
            CHECK (
                (taux_hebergement + taux_dependance + taux_soins + taux_soins_autonomie)
                BETWEEN 99.99 AND 100.01
            );
    END IF;
END $$;


-- RLS FORCE + policy company_id = current_setting('app.current_company_id')
ALTER TABLE compta_esms.cles_repartition_charges_communes
    ENABLE ROW LEVEL SECURITY;
ALTER TABLE compta_esms.cles_repartition_charges_communes
    FORCE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname = 'compta_esms'
          AND tablename  = 'cles_repartition_charges_communes'
          AND policyname = 'tenant_isolation'
    ) THEN
        CREATE POLICY tenant_isolation ON compta_esms.cles_repartition_charges_communes
            USING (company_id::text = current_setting('app.current_company_id', true))
            WITH CHECK (company_id::text = current_setting('app.current_company_id', true));
    END IF;
END $$;


-- Trigger updated_at (réutilise le trigger commun déclaré en 002).
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger
        WHERE tgname = 'cles_repartition_set_updated_at'
    ) THEN
        CREATE TRIGGER cles_repartition_set_updated_at
            BEFORE UPDATE ON compta_esms.cles_repartition_charges_communes
            FOR EACH ROW
            EXECUTE FUNCTION compta_esms.set_updated_at();
    END IF;
END $$;


-- Index pour le batch lookup §Y (ets + annee + compte ANY()).
CREATE INDEX IF NOT EXISTS idx_cles_repartition_ets_annee_compte
    ON compta_esms.cles_repartition_charges_communes (etablissement_id, exercice_annee, compte_m22bis);
CREATE INDEX IF NOT EXISTS idx_cles_repartition_company
    ON compta_esms.cles_repartition_charges_communes (company_id);


-- ============================================================
-- DOWN  (reference only — pas joué par le runner idempotent)
-- ============================================================
-- DROP TABLE IF EXISTS compta_esms.cles_repartition_charges_communes;
