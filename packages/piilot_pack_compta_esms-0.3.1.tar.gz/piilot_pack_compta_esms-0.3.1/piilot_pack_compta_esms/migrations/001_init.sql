-- ============================================================
-- Migration: 001_init.sql
-- Plugin: compta_esms — v0.2 foundation placeholder
-- ============================================================
-- Posts the ``compta_esms`` PG schema so plugin-owned tables can land
-- in subsequent migrations. The real 24-table schema (cf. L1-schema-db.sql
-- in the dev-package spec) is shipped in ``002_compta_esms_core.sql``
-- during chantier §D of ``suivi.md``.
--
-- All plugin migrations MUST be idempotent: the Piilot loader refuses
-- a plugin whose .sql files contain a CREATE TABLE / CREATE INDEX /
-- CREATE SCHEMA without IF NOT EXISTS (static heuristic check).
-- ============================================================

CREATE SCHEMA IF NOT EXISTS compta_esms;

COMMENT ON SCHEMA compta_esms IS
    'Plugin compta-ESMS — verticale comptabilité Établissements Sociaux et '
    'Médico-Sociaux (EPRD, ERRD, DM, RIA, ERCP, EPCP, M22 bis, ventilation H/D/S).';
