-- ============================================================
-- Migration: 003_seed_feature_catalog.sql
-- Plugin: compta_esms — Seed du catalogue features bindables (D-103)
-- ============================================================
-- Seed ~15 features standards. Chacune décrit un contrat de colonnes que
-- la KB source doit exposer pour être bindable sur cette feature (cf. D-103,
-- L2 §7bis routes API + L3 écran E03 "Sources de données").
--
-- Conventions :
--   - feature_key : snake_case stable (sert d'identifiant logique cross-version)
--   - columns_required : JSONB {col_name: pg_type_logique}
--                        Types logiques : "text", "numeric", "integer", "date"
--   - applicable_typologies : ARRAY filtre par typologie ESSMS (vide = toutes)
--   - applicable_doc_types : par défaut ['eprd', 'errd']
--   - plan_comptable_cible : 'M22Bis' (jamais autre — D-106 + D-107)
--   - contract_version : SMALLINT, démarrage à 1 (cf. §D.10bis)
--   - ordre : pour tri stable côté UI
--
-- Idempotence : INSERT ... ON CONFLICT (feature_key) DO NOTHING.
-- Pour modifier un contrat existant, BUMPER contract_version + UPDATE séparé
-- côté code applicatif (pas dans cette migration).
-- ============================================================

-- §G.1 Catalogue des features
-- ----------------------------------------
-- CRP — Charges groupe G1 (Exploitation courante)
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'crp_charges_g1',
    'CRP — Charges groupe G1 (Exploitation courante)',
    'Charges d''exploitation courante par compte M22Bis. Remplit compta_esms.crp_lignes (groupe=G1, nature=charge).',
    '{"compte": "text", "compte_label": "text", "montant": "numeric"}'::jsonb,
    true,
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    11
) ON CONFLICT (feature_key) DO NOTHING;

-- CRP — Charges groupe G2 (Personnel)
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'crp_charges_g2',
    'CRP — Charges groupe G2 (Personnel)',
    'Charges de personnel par compte M22Bis (classe 64). Remplit compta_esms.crp_lignes (groupe=G2, nature=charge).',
    '{"compte": "text", "compte_label": "text", "montant": "numeric"}'::jsonb,
    true,
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    12
) ON CONFLICT (feature_key) DO NOTHING;

-- CRP — Charges groupe G3 (Structure)
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'crp_charges_g3',
    'CRP — Charges groupe G3 (Structure)',
    'Charges de structure (amortissements, intérêts emprunts) par compte M22Bis. Remplit compta_esms.crp_lignes (groupe=G3, nature=charge).',
    '{"compte": "text", "compte_label": "text", "montant": "numeric"}'::jsonb,
    true,
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    13
) ON CONFLICT (feature_key) DO NOTHING;

-- CRP — Produits (toutes natures confondues)
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'crp_produits',
    'CRP — Produits (toutes natures)',
    'Produits d''exploitation par compte M22Bis (classes 70-77). Remplit compta_esms.crp_lignes (nature=produit).',
    '{"compte": "text", "compte_label": "text", "montant": "numeric"}'::jsonb,
    true,
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    14
) ON CONFLICT (feature_key) DO NOTHING;

-- TPER — Effectifs prévisionnels
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'tper_effectifs',
    'TPER — Effectifs prévisionnels',
    'Effectifs prévisionnels par catégorie CNSA + fonction. Remplit compta_esms.tper_ter_lignes (type_tableau=TPER). Réf KB core PLT-44 com.piilot.core.cnsa-fonctions-esms.',
    '{"categorie_cnsa": "text", "fonction": "text", "etpr": "numeric", "etpt": "numeric", "remunerations": "numeric"}'::jsonb,
    false,
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    21
) ON CONFLICT (feature_key) DO NOTHING;

-- TER — Effectifs réalisés
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'ter_effectifs',
    'TER — Effectifs réalisés',
    'Effectifs réalisés par catégorie CNSA + fonction. Remplit compta_esms.tper_ter_lignes (type_tableau=TER).',
    '{"categorie_cnsa": "text", "fonction": "text", "etpr": "numeric", "etpt": "numeric", "remunerations": "numeric"}'::jsonb,
    false,
    ARRAY['errd'],
    'M22Bis',
    1,
    22
) ON CONFLICT (feature_key) DO NOTHING;

-- Annexe 4 — Activité GIR
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_typologies, applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'annexe4_activite',
    'Annexe 4 — Activité GIR',
    'Activité par section + GIR (1-6). Remplit compta_esms.activite_lignes.',
    '{"section": "text", "gir": "text", "nombre_places": "integer", "nombre_personnes": "integer", "nombre_journees": "integer"}'::jsonb,
    false,
    ARRAY['ehpad_aja', 'fam_samsah'],
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    31
) ON CONFLICT (feature_key) DO NOTHING;

-- Annexe 5 — Forfaits Soins / Dépendance / SEA
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_typologies, applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'annexe5_forfait',
    'Annexe 5 — Forfaits Soins/Dépendance/SEA',
    'Ventilation analytique des charges/produits par section (Hébergement, Dépendance, Soins, SEA). Remplit compta_esms.annexe5_lignes (variante 5A EHPAD / 5C FAM-SAMSAH / 5D SAD-SPASAD).',
    '{"compte": "text", "compte_label": "text", "montant_hebergement": "numeric", "montant_dependance": "numeric", "montant_soins": "numeric", "montant_sea": "numeric"}'::jsonb,
    false,
    ARRAY['ehpad_aja', 'fam_samsah', 'sad_spasad'],
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    41
) ON CONFLICT (feature_key) DO NOTHING;

-- Bilan — Actif
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'bilan_actif',
    'Bilan — Actif',
    'Postes d''actif par compte M22Bis. Remplit compta_esms.bilan_lignes (type_actif_passif=actif).',
    '{"compte": "text", "poste_label": "text", "montant_brut_n": "numeric", "montant_amort_n": "numeric", "montant_net_n": "numeric", "montant_net_n1": "numeric"}'::jsonb,
    false,
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    51
) ON CONFLICT (feature_key) DO NOTHING;

-- Bilan — Passif
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'bilan_passif',
    'Bilan — Passif',
    'Postes de passif par compte M22Bis. Remplit compta_esms.bilan_lignes (type_actif_passif=passif).',
    '{"compte": "text", "poste_label": "text", "montant_net_n": "numeric", "montant_net_n1": "numeric"}'::jsonb,
    false,
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    52
) ON CONFLICT (feature_key) DO NOTHING;

-- TF — Ressources
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'tf_ressources',
    'Tableau de financement — Ressources',
    'Ressources du TF (CAF, subventions, emprunts...). Remplit compta_esms.tf_lignes (cote=ressources).',
    '{"compte": "text", "libelle": "text", "montant_n1": "numeric", "montant_n": "numeric"}'::jsonb,
    false,
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    61
) ON CONFLICT (feature_key) DO NOTHING;

-- TF — Emplois
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'tf_emplois',
    'Tableau de financement — Emplois',
    'Emplois du TF (immobilisations, remboursements emprunts...). Remplit compta_esms.tf_lignes (cote=emplois).',
    '{"compte": "text", "libelle": "text", "montant_n1": "numeric", "montant_n": "numeric"}'::jsonb,
    false,
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    62
) ON CONFLICT (feature_key) DO NOTHING;

-- Provisions — Mouvements
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'provisions_mouvements',
    'Provisions / dépréciations / subventions — Mouvements',
    'Mouvements de provisions (dotations / reprises). Remplit compta_esms.provisions_lignes.',
    '{"categorie": "text", "compte_imputation": "text", "objet": "text", "montant_debut_n": "numeric", "dotations": "numeric", "reprises": "numeric"}'::jsonb,
    false,
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    71
) ON CONFLICT (feature_key) DO NOTHING;

-- Emprunts — Principal et intérêts
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'emprunts_principal',
    'Emprunts / dettes — Principal et intérêts',
    'Caractéristiques et remboursements d''emprunts (privés ou publics). Remplit compta_esms.emprunts_dettes.',
    '{"type_dette": "text", "capital_emprunte": "numeric", "taux": "numeric", "duree_annees": "integer", "capital_rembourse_n": "numeric", "interets_n": "numeric", "solde_restant_du": "numeric"}'::jsonb,
    false,
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    81
) ON CONFLICT (feature_key) DO NOTHING;

-- RCC — Répartition charges communes
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'rcc_repartition',
    'RCC — Répartition charges communes',
    'Clés de répartition des charges communes entre CR (D-092 : Σ% = 100%). Remplit compta_esms.rcc_lignes.',
    '{"compte": "text", "libelle": "text", "montant_total": "numeric", "cle_repartition": "text", "repartition": "text"}'::jsonb,
    false,
    ARRAY['eprd', 'errd'],
    'M22Bis',
    1,
    91
) ON CONFLICT (feature_key) DO NOTHING;

-- PGFP — Plan Global de Financement Pluriannuel
INSERT INTO compta_esms.feature_catalog (
    feature_key, label, description, columns_required, is_mandatory,
    applicable_doc_types, plan_comptable_cible, contract_version, ordre
) VALUES (
    'pgfp_lignes',
    'PGFP — Plan Global de Financement Pluriannuel',
    'Projection 8 exercices N-1 → N+6 (D-095). Remplit compta_esms.pgfp_lignes.',
    '{"section": "text", "ligne_key": "text", "montant_nm1": "numeric", "montant_n": "numeric", "montant_np1": "numeric", "montant_np2": "numeric", "montant_np3": "numeric", "montant_np4": "numeric", "montant_np5": "numeric", "montant_np6": "numeric"}'::jsonb,
    false,
    ARRAY['eprd'],
    'M22Bis',
    1,
    101
) ON CONFLICT (feature_key) DO NOTHING;

-- ============================================================
-- FIN 003_seed_feature_catalog.sql — 16 features bindables
-- ============================================================
