-- ============================================================
-- Migration: 023_feature_catalog_type_poste.sql
-- Plugin: compta_esms — §BJ D3 type_poste contract extension
-- ============================================================
-- Étend le ``columns_required`` des features ``tper_effectifs`` et
-- ``ter_effectifs`` pour exposer ``type_poste`` ('P' Permanent / 'T'
-- Temporaire) au contract de binding. La colonne ``type_poste`` existe
-- déjà sur ``compta_esms.tper_ter_lignes`` depuis migration 012, mais
-- elle n'était pas dans le contrat — donc :
--
-- 1. ``binding_service.preview_binding`` ne savait pas mapper une
--    colonne source vers ``type_poste``.
-- 2. ``tper_ter_prefill_service`` hardcodait ``type_poste='P'`` pour
--    toutes les rows insérées via ``:prefill``.
--
-- Cette migration corrige (1) en exposant le contrat ; le code
-- applicatif (cf. ``tper_ter_prefill.py``) consomme désormais la
-- valeur mappée avec fallback 'P' pour rétrocompat.
--
-- Idempotence : UPDATE conditionnel — si la clé existe déjà dans le
-- JSONB, le `||` la garde inchangée (override par la nouvelle valeur).
-- Ré-exécuter cette migration est safe (no-op après 1er run).
--
-- Pas de bump ``contract_version`` : on ne casse pas les bindings
-- existants, on étend juste le contrat (la clé est optionnelle côté
-- résolution — fallback 'P' si non mappée).
-- ============================================================

UPDATE compta_esms.feature_catalog
SET columns_required = columns_required || '{"type_poste": "text"}'::jsonb
WHERE feature_key IN ('tper_effectifs', 'ter_effectifs')
  AND NOT (columns_required ? 'type_poste');

-- Marqueur d'application pour visibilité côté logs migration runner.
SELECT 'compta_esms.feature_catalog.type_poste contract extended (§BJ)' AS marker;
