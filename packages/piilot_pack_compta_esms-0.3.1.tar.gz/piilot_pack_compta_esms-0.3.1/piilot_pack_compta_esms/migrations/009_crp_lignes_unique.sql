-- Migration 009 — UNIQUE constraint on crp_lignes natural key (§H.1).
--
-- ``crp_lignes`` was created in 002 without an explicit UNIQUE on
-- ``(cr_id, groupe, nature, compte_m22bis)``. §H decided one row per
-- (compte × CR × groupe × nature) so that :
--
-- * ``POST /lignes:bulk-upsert`` can rely on ``ON CONFLICT`` for
--   idempotent re-runs of a section's saisie tableau,
-- * ``POST /lignes:prefill-from-binding`` (which aggregates the bound
--   KB ``GROUP BY compte``) never produces collisions inside the same
--   section,
-- * ``POST /lignes`` returns 409 when the cabinet tries to insert a
--   duplicate rather than silently shadowing.
--
-- The L1 spec implicitly assumes this unicity (cf. L3 E04 mockup that
-- shows one row per compte) ; this migration just makes the implicit
-- explicit. Existing seed/test data don't introduce duplicates — the
-- §E.3 auto-CRPP only creates the CR row, lignes are user-driven.
--
-- The constraint is added via a DO block guard so re-running the
-- migration is idempotent (psql 14+ supports ``IF NOT EXISTS`` on
-- ``ALTER TABLE … ADD CONSTRAINT`` but we keep the DO block for
-- portability with the local Docker dev container).

-- UP
-- ============================================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'crp_lignes_natural_key'
          AND conrelid = 'compta_esms.crp_lignes'::regclass
    ) THEN
        ALTER TABLE compta_esms.crp_lignes
            ADD CONSTRAINT crp_lignes_natural_key
            UNIQUE (cr_id, groupe, nature, compte_m22bis);
    END IF;
END $$;

COMMENT ON CONSTRAINT crp_lignes_natural_key
    ON compta_esms.crp_lignes IS
    'One row per (CR, groupe G1/G2/G3, nature charge/produit, compte M22Bis). '
    'Enforces the §H ":bulk-upsert" / ":prefill-from-binding" semantics — '
    'see migration 009.';

-- ============================================================
-- DOWN  (reference only)
-- ============================================================
-- ALTER TABLE compta_esms.crp_lignes DROP CONSTRAINT IF EXISTS crp_lignes_natural_key;
