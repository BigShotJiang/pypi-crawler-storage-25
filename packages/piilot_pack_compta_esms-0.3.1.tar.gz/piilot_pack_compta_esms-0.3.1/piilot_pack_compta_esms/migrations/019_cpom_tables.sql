-- Migration 019 — CPOM (§BA, D-027).
--
-- 3 tables :
--   * ``esms_cpom``        — un Contrat Pluriannuel d'Objectifs et de
--                            Moyens. Cardinalité 1 OG × N ESMS (Q4).
--   * ``cpom_esms_link``   — relation N:N entre CPOM et établissements
--                            de l'OG. Porte le drapeau
--                            ``inclus_dans_perimetre`` (un CPOM peut
--                            référencer un ESMS sans qu'il soit dans
--                            le périmètre tarifaire — S03 p.10-11).
--   * ``cpom_objectifs``   — objectifs déclarés au CPOM avec impact
--                            EPRD éventuel.
--
-- Spec : KB ``06-data-model.md`` §B.3/B.4/B.5 + ``11-decisions.md`` D-027
-- + ``S03`` FAQ DGCS p.8-14.
--
-- Pourquoi cette migration arrive si tard : la v0.2 a livré
-- ``etablissements.inclus_cpom`` (BOOLEAN agrégé) — suffisant pour le
-- drapeau "ETS sous CPOM" mais aveugle sur la cardinalité réelle (un
-- ETS peut être dans plusieurs CPOMs successifs, et la borne temporelle
-- ``date_effet → date_fin_theorique`` détermine si un CPOM est encore
-- actif sur un exercice donné). v0.3 modélise le CPOM comme entité
-- propre + N:N + objectifs pour préparer :
--   * §BD ``compute_equilibre_applicable(ets, exercice)`` qui itère
--     les CPOMs actifs de l'OG sur l'exercice ;
--   * §AC export DOCX du rapport budgétaire qui doit lister les
--     objectifs CPOM (KB B.5).
--
-- ``date_fin_theorique`` est calculée côté service (pas GENERATED) —
-- ``duree_annees`` est NUMERIC pour autoriser les CPOMs prolongés de
-- demi-année (S03 p.9 : "prorogation 1 an PUV"), donc PG ne peut pas
-- calculer une date entière de manière fiable. Le service écrit la
-- valeur au CREATE / UPDATE.

-- UP
-- ============================================================

-- §BA.1 — Table ``esms_cpom``
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.esms_cpom (
    id                              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                      UUID NOT NULL,
    og_id                           UUID NOT NULL REFERENCES compta_esms.organismes_gestionnaires(id) ON DELETE CASCADE,
    numero                          TEXT,
    date_signature                  DATE NOT NULL,
    date_effet                      DATE NOT NULL,
    duree_annees                    NUMERIC(4, 2) NOT NULL,
    date_fin_theorique              DATE NOT NULL,
    categorie                       TEXT NOT NULL,
    cosignataires                   TEXT[] NOT NULL,
    est_proroge                     TEXT,
    motif_prorogation               TEXT,
    libre_affectation_resultats_o_n TEXT NOT NULL,
    created_at                      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.esms_cpom IS
    'Contrat Pluriannuel d''Objectifs et de Moyens (KB B.3, D-027). '
    '1 CPOM = 1 OG × N ESMS (lien N:N via cpom_esms_link). '
    'Borne temporelle : date_effet → date_fin_theorique (calculée par '
    'cpom_service). Catégorie + cosignataires + libre_affectation_resultats '
    'pilotent §BD equilibre_applicable et §K affectation_variante (D-082).';
COMMENT ON COLUMN compta_esms.esms_cpom.duree_annees IS
    'Durée initiale signée (1.0 à 7.0 ans, NUMERIC pour PUV prorogeable '
    '+1 an sans avenant — S03 p.9).';
COMMENT ON COLUMN compta_esms.esms_cpom.date_fin_theorique IS
    'Date de fin calculée par le service (date_effet + duree_annees). '
    'Pas GENERATED car arithmétique sur NUMERIC années non-stable PG.';
COMMENT ON COLUMN compta_esms.esms_cpom.categorie IS
    'EHPAD_IVTER (L.313-12 IV ter) / ESMS_PH_SSIAD / RESIDENCE_AUTONOMIE / '
    'EHPAD_PUV / MIXTE. Pilote la libre affectation des résultats (D-027).';
COMMENT ON COLUMN compta_esms.esms_cpom.cosignataires IS
    'Array d''autorités de tarification. Sous-ensemble de {ARS, CD, '
    'ARS_CD_TRIPARTITE} — S03 p.9. CHECK constraint enforce.';
COMMENT ON COLUMN compta_esms.esms_cpom.libre_affectation_resultats_o_n IS
    'Drapeau "libre affectation des résultats par le gestionnaire" — '
    'OUI pour EHPAD IVter (art. L.313-12), NON sinon. Détermine la '
    'variante Affectation v0.2 §K (D-082 : Prive_I/II vs Public_I/II).';

CREATE INDEX IF NOT EXISTS idx_cpom_company ON compta_esms.esms_cpom(company_id);
CREATE INDEX IF NOT EXISTS idx_cpom_og ON compta_esms.esms_cpom(og_id);
-- Index pour la requête centrale §BD : CPOMs actifs sur un exercice donné.
CREATE INDEX IF NOT EXISTS idx_cpom_periode ON compta_esms.esms_cpom(og_id, date_effet, date_fin_theorique);


-- §BA.2 — Table ``cpom_esms_link``
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.cpom_esms_link (
    id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id               UUID NOT NULL,
    cpom_id                  UUID NOT NULL REFERENCES compta_esms.esms_cpom(id) ON DELETE CASCADE,
    etablissement_id         UUID NOT NULL REFERENCES compta_esms.etablissements(id) ON DELETE CASCADE,
    inclus_dans_perimetre    TEXT NOT NULL,
    created_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (cpom_id, etablissement_id)
);

COMMENT ON TABLE compta_esms.cpom_esms_link IS
    'Relation N:N entre CPOM et établissements de l''OG (KB B.4). '
    'inclus_dans_perimetre permet de référencer un ESMS rattaché à un '
    'CPOM sans qu''il soit dans le périmètre tarifaire (cas conventions '
    'partielles — S03 p.10-11). La cohérence "OG du CPOM == OG de l''ETS" '
    'est validée au niveau service (cpom_service.link_etablissements).';

CREATE INDEX IF NOT EXISTS idx_cpom_link_company ON compta_esms.cpom_esms_link(company_id);
CREATE INDEX IF NOT EXISTS idx_cpom_link_cpom ON compta_esms.cpom_esms_link(cpom_id);
CREATE INDEX IF NOT EXISTS idx_cpom_link_ets ON compta_esms.cpom_esms_link(etablissement_id);


-- §BA.3 — Table ``cpom_objectifs``
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.cpom_objectifs (
    id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id               UUID NOT NULL,
    cpom_id                  UUID NOT NULL REFERENCES compta_esms.esms_cpom(id) ON DELETE CASCADE,
    intitule                 TEXT NOT NULL,
    impact_eprd_o_n          TEXT NOT NULL,
    description              TEXT,
    date_realisation_prevue  DATE,
    statut                   TEXT,
    created_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at               TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.cpom_objectifs IS
    'Objectifs déclarés au CPOM (KB B.5). N par CPOM. impact_eprd_o_n '
    'flag les objectifs qui doivent apparaître dans le DOCX §AC rapport '
    'budgétaire EPRD. statut est libre (NULL accepté pour objectifs '
    'non encore initiés).';

CREATE INDEX IF NOT EXISTS idx_cpom_obj_company ON compta_esms.cpom_objectifs(company_id);
CREATE INDEX IF NOT EXISTS idx_cpom_obj_cpom ON compta_esms.cpom_objectifs(cpom_id);
-- Index partial pour le filtre §AC "objectifs avec impact EPRD".
CREATE INDEX IF NOT EXISTS idx_cpom_obj_impact_eprd
    ON compta_esms.cpom_objectifs(cpom_id)
    WHERE impact_eprd_o_n = 'OUI';


-- §BA.4 — CHECK constraints idempotents
-- ============================================================
-- Allowed values explicites pour chaque enum textuel + bornes
-- numériques + bornes longueur sur les champs libres.

DO $$
BEGIN
    -- esms_cpom.duree_annees : 1.0 .. 7.0 (S03 p.9)
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'esms_cpom_duree_annees_range'
    ) THEN
        ALTER TABLE compta_esms.esms_cpom
            ADD CONSTRAINT esms_cpom_duree_annees_range
            CHECK (duree_annees >= 1.0 AND duree_annees <= 7.0);
    END IF;

    -- esms_cpom.categorie : 5 valeurs S03 p.9-10
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'esms_cpom_categorie_check'
    ) THEN
        ALTER TABLE compta_esms.esms_cpom
            ADD CONSTRAINT esms_cpom_categorie_check
            CHECK (categorie IN (
                'EHPAD_IVTER',
                'ESMS_PH_SSIAD',
                'RESIDENCE_AUTONOMIE',
                'EHPAD_PUV',
                'MIXTE'
            ));
    END IF;

    -- esms_cpom.cosignataires : sous-ensemble non vide de
    -- {ARS, CD, ARS_CD_TRIPARTITE} (S03 p.9)
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'esms_cpom_cosignataires_check'
    ) THEN
        ALTER TABLE compta_esms.esms_cpom
            ADD CONSTRAINT esms_cpom_cosignataires_check
            CHECK (
                array_length(cosignataires, 1) >= 1
                AND cosignataires <@ ARRAY['ARS', 'CD', 'ARS_CD_TRIPARTITE']::TEXT[]
            );
    END IF;

    -- esms_cpom.est_proroge : OUI / NON (NULL toléré)
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'esms_cpom_est_proroge_check'
    ) THEN
        ALTER TABLE compta_esms.esms_cpom
            ADD CONSTRAINT esms_cpom_est_proroge_check
            CHECK (est_proroge IS NULL OR est_proroge IN ('OUI', 'NON'));
    END IF;

    -- esms_cpom.libre_affectation_resultats_o_n : OUI / NON (S03 p.11)
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'esms_cpom_libre_affectation_check'
    ) THEN
        ALTER TABLE compta_esms.esms_cpom
            ADD CONSTRAINT esms_cpom_libre_affectation_check
            CHECK (libre_affectation_resultats_o_n IN ('OUI', 'NON'));
    END IF;

    -- esms_cpom : cohérence des dates (date_effet doit pouvoir être
    -- antérieure ou égale à date_signature — S03 p.8 "rétroactif" —
    -- mais date_fin_theorique doit toujours être strictement postérieure
    -- à date_effet).
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'esms_cpom_fin_apres_effet'
    ) THEN
        ALTER TABLE compta_esms.esms_cpom
            ADD CONSTRAINT esms_cpom_fin_apres_effet
            CHECK (date_fin_theorique > date_effet);
    END IF;

    -- esms_cpom.motif_prorogation : max 500
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'esms_cpom_motif_prorogation_len'
    ) THEN
        ALTER TABLE compta_esms.esms_cpom
            ADD CONSTRAINT esms_cpom_motif_prorogation_len
            CHECK (motif_prorogation IS NULL OR length(motif_prorogation) <= 500);
    END IF;

    -- cpom_esms_link.inclus_dans_perimetre : OUI / NON
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'cpom_esms_link_perimetre_check'
    ) THEN
        ALTER TABLE compta_esms.cpom_esms_link
            ADD CONSTRAINT cpom_esms_link_perimetre_check
            CHECK (inclus_dans_perimetre IN ('OUI', 'NON'));
    END IF;

    -- cpom_objectifs.intitule : 1..500 chars
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'cpom_objectifs_intitule_len'
    ) THEN
        ALTER TABLE compta_esms.cpom_objectifs
            ADD CONSTRAINT cpom_objectifs_intitule_len
            CHECK (length(intitule) BETWEEN 1 AND 500);
    END IF;

    -- cpom_objectifs.impact_eprd_o_n : OUI / NON
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'cpom_objectifs_impact_eprd_check'
    ) THEN
        ALTER TABLE compta_esms.cpom_objectifs
            ADD CONSTRAINT cpom_objectifs_impact_eprd_check
            CHECK (impact_eprd_o_n IN ('OUI', 'NON'));
    END IF;

    -- cpom_objectifs.description : max 2000 chars
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'cpom_objectifs_description_len'
    ) THEN
        ALTER TABLE compta_esms.cpom_objectifs
            ADD CONSTRAINT cpom_objectifs_description_len
            CHECK (description IS NULL OR length(description) <= 2000);
    END IF;

    -- cpom_objectifs.statut : 4 valeurs (NULL toléré pour
    -- "non initié")
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'cpom_objectifs_statut_check'
    ) THEN
        ALTER TABLE compta_esms.cpom_objectifs
            ADD CONSTRAINT cpom_objectifs_statut_check
            CHECK (statut IS NULL OR statut IN (
                'PREVU', 'EN_COURS', 'REALISE', 'ABANDONNE'
            ));
    END IF;
END $$;


-- §BA.5 — RLS FORCE company-scoped
-- ============================================================

ALTER TABLE compta_esms.esms_cpom        ENABLE ROW LEVEL SECURITY;
ALTER TABLE compta_esms.esms_cpom        FORCE  ROW LEVEL SECURITY;
ALTER TABLE compta_esms.cpom_esms_link   ENABLE ROW LEVEL SECURITY;
ALTER TABLE compta_esms.cpom_esms_link   FORCE  ROW LEVEL SECURITY;
ALTER TABLE compta_esms.cpom_objectifs   ENABLE ROW LEVEL SECURITY;
ALTER TABLE compta_esms.cpom_objectifs   FORCE  ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname = 'compta_esms'
          AND tablename  = 'esms_cpom'
          AND policyname = 'esms_cpom_company_isolation'
    ) THEN
        CREATE POLICY esms_cpom_company_isolation ON compta_esms.esms_cpom
            USING (company_id = current_setting('app.current_company_id', true)::uuid)
            WITH CHECK (company_id = current_setting('app.current_company_id', true)::uuid);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname = 'compta_esms'
          AND tablename  = 'cpom_esms_link'
          AND policyname = 'cpom_esms_link_company_isolation'
    ) THEN
        CREATE POLICY cpom_esms_link_company_isolation ON compta_esms.cpom_esms_link
            USING (company_id = current_setting('app.current_company_id', true)::uuid)
            WITH CHECK (company_id = current_setting('app.current_company_id', true)::uuid);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname = 'compta_esms'
          AND tablename  = 'cpom_objectifs'
          AND policyname = 'cpom_objectifs_company_isolation'
    ) THEN
        CREATE POLICY cpom_objectifs_company_isolation ON compta_esms.cpom_objectifs
            USING (company_id = current_setting('app.current_company_id', true)::uuid)
            WITH CHECK (company_id = current_setting('app.current_company_id', true)::uuid);
    END IF;
END $$;


-- §BA.6 — Triggers updated_at
-- ============================================================
-- Réutilise compta_esms.tg_set_updated_at() défini en migration 002.

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'tg_esms_cpom_updated_at'
    ) THEN
        CREATE TRIGGER tg_esms_cpom_updated_at
            BEFORE UPDATE ON compta_esms.esms_cpom
            FOR EACH ROW EXECUTE FUNCTION compta_esms.tg_set_updated_at();
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'tg_cpom_esms_link_updated_at'
    ) THEN
        CREATE TRIGGER tg_cpom_esms_link_updated_at
            BEFORE UPDATE ON compta_esms.cpom_esms_link
            FOR EACH ROW EXECUTE FUNCTION compta_esms.tg_set_updated_at();
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'tg_cpom_objectifs_updated_at'
    ) THEN
        CREATE TRIGGER tg_cpom_objectifs_updated_at
            BEFORE UPDATE ON compta_esms.cpom_objectifs
            FOR EACH ROW EXECUTE FUNCTION compta_esms.tg_set_updated_at();
    END IF;
END $$;


-- ============================================================
-- DOWN  (reference only — pas joué par le runner idempotent)
-- ============================================================
-- DROP TABLE IF EXISTS compta_esms.cpom_objectifs;
-- DROP TABLE IF EXISTS compta_esms.cpom_esms_link;
-- DROP TABLE IF EXISTS compta_esms.esms_cpom;
