-- Migration 007 — suggestions JSONB on balance_imports
--
-- §F.4 (assistant mapping balance — suggestion pipeline). After the
-- cabinet uploads a balance (§F.3) the assistant scores each source
-- account through three tiers :
--
--   1. ``pcg_to_m22bis`` reference catalog lookup  (KB shipped with the
--      plugin wheel — cf. §F.1).
--   2. Outil-specific preset (Pennylane / Sage / EBP / Cegid).
--   3. LLM fallback for ambiguous accounts. **Stubbed in v0.2** — the
--      SDK doesn't yet expose a ``get_company_llm()`` primitive. The
--      cache table (migration 005) is in place, the suggest pipeline
--      walks past Tier 3 by returning ``[]`` until the SDK lands.
--
-- The computed suggestions are persisted on the balance_imports row
-- so ``GET .../suggestions`` returns them without re-running the
-- pipeline. Shape per source account :
--
-- .. code-block:: json
--
--   {
--     "source_account": "60611",
--     "label_hint": "Eau",
--     "targets": [
--       {
--         "target_m22bis_account": "60611",
--         "weight": 1.0,
--         "confidence": 1.0,
--         "origin": "pcg_to_m22bis_kb"
--       }
--     ]
--   }
--
-- DEFAULT `[]` so existing rows from §F.3 stay valid.

-- UP

ALTER TABLE compta_esms.balance_imports
    ADD COLUMN IF NOT EXISTS suggestions JSONB
        NOT NULL DEFAULT '[]'::jsonb;

COMMENT ON COLUMN compta_esms.balance_imports.suggestions IS
    'Computed suggestions per source account : '
    '[{source_account, label_hint, targets: [{target, weight, '
    'confidence, origin}]}]. Populated by POST :suggest-mappings, '
    'read by GET .../suggestions, consumed by :accept-all-above.';
