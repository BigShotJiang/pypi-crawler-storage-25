-- Migration 013 — Workflow transitions side columns (§S).
--
-- Le DDL initial 002 a posé ``statut`` Literal 6 valeurs + 3 colonnes
-- side (``transmis_at``, ``executoire_at``, ``transmis_par_user_id``)
-- mais l'a fait avant que la décision D-024 (double validation
-- ARS+CD parallèle) ne soit modélisée côté DB.
--
-- Cette migration ajoute les 8 colonnes nullable nécessaires pour
-- traquer :
--
-- * Approbation ARS — ``approuve_par_ars_at`` + ``approuve_par_ars_user_id``
-- * Approbation CD  — ``approuve_par_cd_at``  + ``approuve_par_cd_user_id``
-- * Rejet           — ``rejete_at`` + ``rejete_par_autorite`` CHECK
--                     ('ars','cd') + ``motif_rejet``
-- * Figement ERRD   — ``affectation_definie_at``
--
-- La sémantique en jeu (cf. kb/05-workflows.md + plan-dev §4.2) :
--
-- * EPRD/DM/RIA/AVENANT/ERCP/EPCP : statut reste ``en_instruction``
--   tant que les 2 timestamps ``approuve_par_*_at`` ne sont pas
--   simultanément non-NULL. Quand les 2 sont remplis, le service
--   workflow flip auto ``statut = 'executoire'`` + remplit
--   ``executoire_at``. Le statut DB ne porte donc pas explicitement
--   les sous-états ``approuve_ars``/``approuve_cd`` — c'est le
--   couple (statut, approuve_par_*_at) qui constitue l'état complet
--   pour l'UI (cf. plan-dev L326 "approbation partielle à gérer côté
--   UI"). Le frontend lit les 2 timestamps pour afficher
--   "ARS ✓ / CD en attente".
--
-- * ERRD : statut ``transmis`` → ``affectation_definie`` (figement
--   par admin), ``affectation_definie_at`` capte la date. Pas de
--   double validation pour ERRD (D-023 — pas d'état APPROUVE).
--
-- Ajoute aussi un index partiel sur (company_id, statut) WHERE statut
-- IN ('transmis','en_instruction') pour accélérer les listings
-- côté ATC ("documents en attente de validation chez moi").

-- UP
-- ============================================================

ALTER TABLE compta_esms.documents_budgetaires
    ADD COLUMN IF NOT EXISTS approuve_par_ars_at      TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS approuve_par_cd_at       TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS approuve_par_ars_user_id UUID,
    ADD COLUMN IF NOT EXISTS approuve_par_cd_user_id  UUID,
    ADD COLUMN IF NOT EXISTS rejete_at                TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS rejete_par_autorite      TEXT,
    ADD COLUMN IF NOT EXISTS motif_rejet              TEXT,
    ADD COLUMN IF NOT EXISTS affectation_definie_at   TIMESTAMPTZ;


-- CHECK constraint sur rejete_par_autorite (Literal 'ars' | 'cd').
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint c
        JOIN pg_class t      ON t.oid = c.conrelid
        JOIN pg_namespace n  ON n.oid = t.relnamespace
        WHERE n.nspname = 'compta_esms'
          AND t.relname = 'documents_budgetaires'
          AND c.conname = 'documents_budgetaires_rejete_par_autorite_check'
    ) THEN
        ALTER TABLE compta_esms.documents_budgetaires
            ADD CONSTRAINT documents_budgetaires_rejete_par_autorite_check
            CHECK (rejete_par_autorite IS NULL
                   OR rejete_par_autorite IN ('ars', 'cd'));
    END IF;
END $$;


-- Index partiel pour le listing ATC "documents en cours d'instruction".
CREATE INDEX IF NOT EXISTS idx_doc_en_attente
    ON compta_esms.documents_budgetaires (company_id, statut)
    WHERE statut IN ('transmis', 'en_instruction');


-- COMMENTAIRES
-- ============================================================

COMMENT ON COLUMN compta_esms.documents_budgetaires.approuve_par_ars_at IS
    'Timestamp approbation ARS (EPRD/DM/RIA/AVENANT/ERCP/EPCP). '
    'Quand approuve_par_ars_at ET approuve_par_cd_at non-NULL → flip auto statut=executoire.';

COMMENT ON COLUMN compta_esms.documents_budgetaires.approuve_par_cd_at IS
    'Timestamp approbation CD (EPRD/DM/RIA/AVENANT/ERCP/EPCP). '
    'Cf. approuve_par_ars_at pour le flip executoire.';

COMMENT ON COLUMN compta_esms.documents_budgetaires.rejete_par_autorite IS
    'Quelle autorité a rejeté ("ars" ou "cd"). Rejet par 1 → rejet global (D-024).';

COMMENT ON COLUMN compta_esms.documents_budgetaires.motif_rejet IS
    'Motif obligatoire du rejet (max 500 chars côté service). Plan-dev L317.';

COMMENT ON COLUMN compta_esms.documents_budgetaires.affectation_definie_at IS
    'Timestamp figement affectation (ERRD only, transition '
    'TRANSMIS → AFFECTATION_DEFINIE — D-023).';

COMMENT ON INDEX compta_esms.idx_doc_en_attente IS
    'Listing documents en instruction côté ATC (statut transmis|en_instruction).';

-- ============================================================
-- DOWN  (reference only — pas joué par le runner idempotent)
-- ============================================================
-- DROP INDEX  IF EXISTS compta_esms.idx_doc_en_attente;
-- ALTER TABLE compta_esms.documents_budgetaires
--     DROP CONSTRAINT IF EXISTS documents_budgetaires_rejete_par_autorite_check;
-- ALTER TABLE compta_esms.documents_budgetaires
--     DROP COLUMN IF EXISTS approuve_par_ars_at,
--     DROP COLUMN IF EXISTS approuve_par_cd_at,
--     DROP COLUMN IF EXISTS approuve_par_ars_user_id,
--     DROP COLUMN IF EXISTS approuve_par_cd_user_id,
--     DROP COLUMN IF EXISTS rejete_at,
--     DROP COLUMN IF EXISTS rejete_par_autorite,
--     DROP COLUMN IF EXISTS motif_rejet,
--     DROP COLUMN IF EXISTS affectation_definie_at;
