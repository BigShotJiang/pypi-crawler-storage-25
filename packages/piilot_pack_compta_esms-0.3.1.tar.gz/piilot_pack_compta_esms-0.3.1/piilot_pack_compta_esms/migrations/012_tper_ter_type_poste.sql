-- Migration 012 — Add type_poste P/T to tper_ter_lignes (§P).
--
-- L1-schema-db.sql initial + DDL plugin migration 002 oublient la
-- colonne ``type_poste`` (Permanent / Temporaire) alors que :
--
-- * 18-annexe6-tper-structure.md §4.2 explicite : "Pour chaque
--   fonction, 2 lignes (P et T)" — soit ~50 fonctions × 2 (P/T) ≈
--   100 lignes par TPER d'un EHPAD.
-- * 17-annexe9-ter-structure.md §1.1 : "Type de contrat : Permanent
--   / Temporaire" comme axe de ventilation natif.
-- * Référentiel CNSA officiel via PLT-44 KB core distingue P/T.
--
-- Cette migration ajoute ``type_poste`` avec un DEFAULT 'P' rétro-compat
-- (utile si le DDL avait déjà reçu des rows en dev), puis pose le CHECK
-- constraint sur Literal('P', 'T').
--
-- Aussi : ajoute un **UNIQUE partial index** sur (document_id,
-- etablissement_id, type_tableau, categorie_cnsa, fonction, type_poste)
-- pour cibler le ON CONFLICT du replace_by_doc_ets_type (§P.4).
-- ``fonction`` est nullable côté DDL : la clé partielle WHERE fonction
-- IS NOT NULL couvre le cas "1 ligne par catégorie + fonction" ;
-- le cas "agrégat catégorie sans fonction" reste libre (pas d'ON
-- CONFLICT pour ces rows, le repo ne fait que DELETE+INSERT).

-- UP
-- ============================================================

DO $$
BEGIN
    -- Phase 1 — Add type_poste column with default 'P' (rétro-compat).
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema = 'compta_esms'
          AND table_name = 'tper_ter_lignes'
          AND column_name = 'type_poste'
    ) THEN
        ALTER TABLE compta_esms.tper_ter_lignes
            ADD COLUMN type_poste TEXT NOT NULL DEFAULT 'P';

        -- Drop the default after the rétro-compat backfill so that
        -- new INSERTs are forced to specify it explicitly.
        ALTER TABLE compta_esms.tper_ter_lignes
            ALTER COLUMN type_poste DROP DEFAULT;
    END IF;

    -- Phase 2 — Add CHECK constraint on Literal('P', 'T').
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint c
        JOIN pg_class t ON t.oid = c.conrelid
        JOIN pg_namespace n ON n.oid = t.relnamespace
        WHERE n.nspname = 'compta_esms'
          AND t.relname = 'tper_ter_lignes'
          AND c.conname = 'tper_ter_lignes_type_poste_check'
    ) THEN
        ALTER TABLE compta_esms.tper_ter_lignes
            ADD CONSTRAINT tper_ter_lignes_type_poste_check
            CHECK (type_poste IN ('P', 'T'));
    END IF;
END $$;

-- Phase 3 — Partial unique index for replace_by_doc_ets_type semantic.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_indexes
        WHERE schemaname = 'compta_esms'
          AND indexname = 'uq_tper_ter_lignes_natural_key'
    ) THEN
        CREATE UNIQUE INDEX uq_tper_ter_lignes_natural_key
            ON compta_esms.tper_ter_lignes (
                document_id, etablissement_id, type_tableau,
                categorie_cnsa, fonction, type_poste
            )
            WHERE fonction IS NOT NULL;
    END IF;
END $$;

COMMENT ON COLUMN compta_esms.tper_ter_lignes.type_poste IS
    'P (Permanent) / T (Temporaire). 18-annexe6 §4.2 — chaque fonction '
    'a 2 lignes P/T. Bug spec L1 + plugin omis, corrigé en 012.';

COMMENT ON INDEX compta_esms.uq_tper_ter_lignes_natural_key IS
    'Natural key 6-tuple pour replace_by_doc_ets_type semantic du '
    'bulk-upsert §P.4 (catégorie × fonction × P/T par doc/ets/tableau).';

-- ============================================================
-- DOWN  (reference only)
-- ============================================================
-- DROP INDEX IF EXISTS compta_esms.uq_tper_ter_lignes_natural_key;
-- ALTER TABLE compta_esms.tper_ter_lignes
--     DROP CONSTRAINT IF EXISTS tper_ter_lignes_type_poste_check;
-- ALTER TABLE compta_esms.tper_ter_lignes
--     DROP COLUMN IF EXISTS type_poste;
