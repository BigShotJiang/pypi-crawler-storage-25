-- Migration 005 — LLM suggestion cache for the balance mapping assistant
-- (§F.4 — D-108 + suivi.md audit §A.4.2).
--
-- The suggestion service ranks each unmapped account through three tiers :
--   1. KB pcg_to_m22bis lookup (catalog)
--   2. Preset outil (Pennylane / Sage / …)
--   3. LLM fallback for the truly ambiguous accounts
--
-- The LLM tier is the expensive one (1-2 € per balance if every account
-- is re-prompted). Cabinets re-import the same balance several times a
-- year (monthly close, then trimestriel review) ; without cache, each
-- re-import re-pays the LLM for accounts that haven't changed.
--
-- This table memoizes the LLM response keyed by the **content** of the
-- account, not its DB id, so two cabinets with identical PCG account
-- 60611 "Eau" can share the same cached suggestion without leaking
-- tenant data — there's no PII in a PCG code label.
--
-- Cache key columns :
--   * source_plan        — 'PCG' / 'Pennylane' / 'Sage' / …
--   * source_account     — normalised (no whitespace, uppercase)
--   * label_hint_hash    — SHA-256 of the cabinet's libellé compte
--                          (case-folded, whitespace-collapsed) so the
--                          same libellé maps to the same cache row
--                          across cabinets
--   * version_m22bis     — DGCS millésime applicable at lookup time
--   * model_version      — the LLM provider/model that produced the
--                          response (gpt-4o-mini-2024-07-18, mistral-…)
--
-- Cache invalidation : ``cached_at < now() - 90 days`` (TTL). The
-- suggestion service treats expired rows as missing and re-prompts.

-- UP

CREATE TABLE IF NOT EXISTS compta_esms.llm_suggestion_cache (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_plan             TEXT NOT NULL CHECK (source_plan IN (
                                'PCG', 'M14', 'M21', 'M22Bis', 'Sage', 'EBP',
                                'Cegid', 'Pennylane', 'custom'
                            )),
    source_account          TEXT NOT NULL,
    label_hint_hash         TEXT NOT NULL,
    version_m22bis          TEXT NOT NULL DEFAULT '2025-2026',
    target_m22bis_account   TEXT NOT NULL,
    confidence              NUMERIC(4, 3) NOT NULL CHECK (
                                confidence >= 0 AND confidence <= 1.0
                            ),
    weight                  NUMERIC(8, 6) NOT NULL DEFAULT 1.0
                                CHECK (weight > 0 AND weight <= 1.0),
    model_version           TEXT NOT NULL,
    cached_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (source_plan, source_account, label_hint_hash, version_m22bis,
            target_m22bis_account)
);

COMMENT ON TABLE compta_esms.llm_suggestion_cache IS
    'D-108 — memoises LLM suggestions per (source account + libellé hash) '
    'to avoid re-prompting on identical re-imports. TTL = 90 days, '
    'enforced application-side by the suggestion service. '
    'Cross-tenant by design (label is non-PII).';

COMMENT ON COLUMN compta_esms.llm_suggestion_cache.label_hint_hash IS
    'SHA-256 over the case-folded, whitespace-collapsed libellé compte '
    '(eg. "Eau" / "EAU" / "eau " → same hash). Lets two cabinets share '
    'a cache entry without leaking their balance content.';

COMMENT ON COLUMN compta_esms.llm_suggestion_cache.model_version IS
    'LLM provider + model that produced this suggestion, eg. '
    '"openai:gpt-4o-mini-2024-07-18". Used to invalidate cache when '
    'a cabinet upgrades to a stronger model on Piilot multi-LLM.';

-- Hot lookup index : the service queries by (source_plan, source_account,
-- label_hint_hash, version_m22bis) on every unmapped row of a balance.
CREATE INDEX IF NOT EXISTS idx_llm_cache_lookup
    ON compta_esms.llm_suggestion_cache (
        source_plan, source_account, label_hint_hash, version_m22bis
    );

-- TTL sweep : a janitor job (out of scope §F.1) can DELETE WHERE
-- cached_at < now() - interval '90 days'. The index keeps the sweep
-- cheap even when the table grows to millions of rows.
CREATE INDEX IF NOT EXISTS idx_llm_cache_cached_at
    ON compta_esms.llm_suggestion_cache (cached_at);

-- No RLS : cache rows are cross-tenant by design (the libellé hash is
-- non-PII and the savings come from sharing across cabinets).
