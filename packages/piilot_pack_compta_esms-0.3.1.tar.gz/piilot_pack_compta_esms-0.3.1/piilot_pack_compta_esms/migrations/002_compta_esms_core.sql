-- ============================================================
-- Migration: 002_compta_esms_core.sql
-- Plugin: compta_esms — v0.2 core schema (25 tables)
-- ============================================================
-- Transcrit fidèlement docs/docs_dev/dev-package-compta-esms-v0.2/L1-schema-db.sql
-- en idempotent (le loader plugin Piilot refuse les CREATE TABLE / CREATE INDEX
-- sans IF NOT EXISTS, et les CREATE TRIGGER sans guard).
--
-- Conventions :
--   - PK = UUID DEFAULT gen_random_uuid()
--   - created_at + updated_at TIMESTAMPTZ DEFAULT now()
--   - RLS FORCE company-scoped via `app.current_company_id` (différent du core
--     qui utilise `app.current_user_id` — c'est la convention plugin pour
--     les schémas métier, cf. plugins prod pennylane/compta/supabase).
--   - FK ON DELETE choisi selon sémantique métier
--   - Indexes sur FKs + colonnes filtrées fréquemment
--   - Comments PG sur chaque table + colonnes non triviales
--
-- Référence sections (cf. suivi.md §D.1 → §D.13) :
--   §D.1   Entités (3 tables)
--   §D.2   Documents (3 tables)
--   §D.3   PGFP (1)
--   §D.4   Affectations (2)
--   §D.5   Effectifs (1)
--   §D.6   Activité Annexe 4 (1)
--   §D.7   Annexe 5 + forfaits (2)
--   §D.8   Bilan + TF (2)
--   §D.9   Provisions / Emprunts / RCC (3)
--   §D.10  Ratios + Contrôles (2)
--   §D.11  Méta plugin (feature_catalog, kb_bindings, exports, rgpd, audit) (5)
--   §D.12  Balance assistant D-108 (2)
--   §D.13  RLS + triggers transverse (DO blocks)
-- ============================================================

-- ============================================================
-- §D.1 ENTITÉS PRINCIPALES — Organisme gestionnaire, Établissements, Exercices
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.organismes_gestionnaires (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    finess_juridique TEXT NOT NULL,
    raison_sociale  TEXT NOT NULL,
    statut_juridique TEXT NOT NULL CHECK (statut_juridique IN (
        'eps', 'essms_public_non_eps', 'essms_prive_non_lucratif', 'essms_prive_commercial'
    )),
    plan_comptable  TEXT NOT NULL CHECK (plan_comptable IN ('PC', 'PNL')),
    adresse         TEXT,
    cpom_date_effet DATE,
    representant_legal TEXT,
    representant_qualite TEXT,
    siret           TEXT,
    telephone       TEXT,
    email           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (company_id, finess_juridique)
);

COMMENT ON TABLE compta_esms.organismes_gestionnaires IS
    'Organisme gestionnaire (FINESS juridique). N par company (D-018 multi-OG). '
    'plan_comptable PC/PNL détermine variantes Affectation (D-082) + Bilan (D-086).';

CREATE INDEX IF NOT EXISTS idx_og_company ON compta_esms.organismes_gestionnaires(company_id);


CREATE TABLE IF NOT EXISTS compta_esms.etablissements (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    og_id           UUID NOT NULL REFERENCES compta_esms.organismes_gestionnaires(id) ON DELETE CASCADE,
    finess_ets      TEXT NOT NULL,
    raison_sociale  TEXT NOT NULL,
    typologie       TEXT NOT NULL,
    categorie       TEXT,
    adresse         TEXT,
    date_autorisation DATE,
    capacite_autorisee INT NOT NULL DEFAULT 0,
    capacite_installee INT NOT NULL DEFAULT 0,
    capacite_financee INT NOT NULL DEFAULT 0,
    amplitude_ouverture INT NOT NULL DEFAULT 365 CHECK (amplitude_ouverture BETWEEN 1 AND 366),
    convention_collective TEXT,
    inclus_cpom     BOOLEAN NOT NULL DEFAULT false,
    soumis_equilibre BOOLEAN NOT NULL DEFAULT false,
    tarification_ternaire BOOLEAN NOT NULL DEFAULT false,
    forfait_global_unique BOOLEAN NOT NULL DEFAULT false,
    cofinancement   TEXT CHECK (cofinancement IN ('ars_cd', 'ars_exclusif', 'aucun')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (company_id, finess_ets)
);

COMMENT ON TABLE compta_esms.etablissements IS
    'Établissement (FINESS géographique). N par OG. Typologie référence '
    'com.piilot.core.typologies-essms (39 valeurs, PLT-T1 KB core).';
COMMENT ON COLUMN compta_esms.etablissements.forfait_global_unique IS
    'D-085 : expérimentation 2026 → fusion Dépendance + Soins en "SEA".';

CREATE INDEX IF NOT EXISTS idx_ets_company ON compta_esms.etablissements(company_id);
CREATE INDEX IF NOT EXISTS idx_ets_og ON compta_esms.etablissements(og_id);
CREATE INDEX IF NOT EXISTS idx_ets_typologie ON compta_esms.etablissements(typologie);


CREATE TABLE IF NOT EXISTS compta_esms.exercices (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    og_id           UUID NOT NULL REFERENCES compta_esms.organismes_gestionnaires(id) ON DELETE CASCADE,
    annee           SMALLINT NOT NULL CHECK (
        annee BETWEEN EXTRACT(YEAR FROM CURRENT_DATE)::int - 1
                  AND EXTRACT(YEAR FROM CURRENT_DATE)::int + 1
    ),
    millesime_m22bis TEXT NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (company_id, og_id, annee)
);

COMMENT ON TABLE compta_esms.exercices IS
    'Exercice budgétaire pour un OG. Année contrainte N-1, N, N+1 (D-104).';

CREATE INDEX IF NOT EXISTS idx_exercices_company ON compta_esms.exercices(company_id);
CREATE INDEX IF NOT EXISTS idx_exercices_og_annee ON compta_esms.exercices(og_id, annee);


-- ============================================================
-- §D.2 DOCUMENTS BUDGÉTAIRES — EPRD, ERRD, DM, RIA, ERCP, EPCP
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.documents_budgetaires (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    exercice_id     UUID NOT NULL REFERENCES compta_esms.exercices(id) ON DELETE CASCADE,
    type_document   TEXT NOT NULL CHECK (type_document IN (
        'eprd', 'errd', 'dm', 'ria', 'ercp', 'epcp', 'avenant'
    )),
    cadre_version   TEXT NOT NULL,
    parent_id       UUID REFERENCES compta_esms.documents_budgetaires(id) ON DELETE RESTRICT,
    statut          TEXT NOT NULL DEFAULT 'brouillon' CHECK (statut IN (
        'brouillon', 'transmis', 'en_instruction', 'executoire', 'rejete',
        'affectation_definie'
    )),
    periode_observation_debut DATE,
    periode_observation_fin   DATE,
    transmis_at     TIMESTAMPTZ,
    executoire_at   TIMESTAMPTZ,
    transmis_par_user_id UUID,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (company_id, exercice_id, type_document, parent_id)
);

COMMENT ON TABLE compta_esms.documents_budgetaires IS
    'Polymorphe : EPRD/ERRD/DM/RIA/ERCP/EPCP/AVENANT. DM/RIA réfèrent EPRD parent.';
COMMENT ON COLUMN compta_esms.documents_budgetaires.cadre_version IS
    'Millésime cadre DGCS (ex: #EPRDHA-2026-01#, #ERRDHA-2025-01#). Snapshot du cadre '
    'au moment de création du document pour revalider/exporter avec la version dorigine.';

CREATE INDEX IF NOT EXISTS idx_doc_company ON compta_esms.documents_budgetaires(company_id);
CREATE INDEX IF NOT EXISTS idx_doc_exercice ON compta_esms.documents_budgetaires(exercice_id);
CREATE INDEX IF NOT EXISTS idx_doc_parent ON compta_esms.documents_budgetaires(parent_id);
CREATE INDEX IF NOT EXISTS idx_doc_statut ON compta_esms.documents_budgetaires(statut)
    WHERE statut != 'brouillon';


CREATE TABLE IF NOT EXISTS compta_esms.comptes_resultat (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    etablissement_id UUID REFERENCES compta_esms.etablissements(id) ON DELETE RESTRICT,
    cr_type         TEXT NOT NULL CHECK (cr_type IN ('CRPP', 'CRPA', 'CRP_SF', 'CRA_SF')),
    cr_variante     TEXT NOT NULL CHECK (cr_variante IN ('soumis_equilibre', 'non_soumis_equil')),
    cr_identifiant  TEXT,
    denomination    TEXT NOT NULL,
    finess_rattachement TEXT,
    capacite_installee INT,
    amplitude_ouverture INT,
    ventilation     TEXT NOT NULL DEFAULT 'simple' CHECK (ventilation IN (
        'simple', 'ternaire_hds', 'ternaire_hdsea'
    )),
    ordre           INT NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.comptes_resultat IS
    'CR inclus dans un document. 1 CRPP + N CRPA + M CR_SF. Ventilation simple ou '
    'ternaire H/D/S (EHPAD classique, D-083) ou ternaire H/D/S/SEA (EHPAD forfait global unique D-085).';

CREATE INDEX IF NOT EXISTS idx_cr_doc ON compta_esms.comptes_resultat(document_id);
CREATE INDEX IF NOT EXISTS idx_cr_company ON compta_esms.comptes_resultat(company_id);


-- ============================================================
-- §D.2 (suite) LIGNES SAISIES — CRP par compte M22Bis
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.crp_lignes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    cr_id           UUID NOT NULL REFERENCES compta_esms.comptes_resultat(id) ON DELETE CASCADE,
    groupe          TEXT NOT NULL CHECK (groupe IN ('G1', 'G2', 'G3')),
    nature          TEXT NOT NULL CHECK (nature IN ('charge', 'produit')),
    compte_m22bis   TEXT NOT NULL,
    compte_label    TEXT,
    -- Montants colonnes EPRD (prévisionnel)
    montant_budget_initial    NUMERIC(15, 2),
    montant_virements_credits NUMERIC(15, 2),
    montant_decisions_modif   NUMERIC(15, 2),
    montant_previsions_totales NUMERIC(15, 2),
    -- Montants colonnes ERRD (réalisé)
    montant_realise           NUMERIC(15, 2),
    -- Ventilation H/D/S/SEA si CR ternaire
    montant_hebergement       NUMERIC(15, 2),
    montant_dependance        NUMERIC(15, 2),
    montant_soins             NUMERIC(15, 2),
    montant_soins_autonomie   NUMERIC(15, 2),
    -- Source / Provenance
    binding_id      UUID,
    saisie_manuelle BOOLEAN NOT NULL DEFAULT false,
    -- §D.10bis : override balance par saisie manuelle
    override_balance BOOLEAN NOT NULL DEFAULT false,
    override_reason  TEXT,
    override_at      TIMESTAMPTZ,
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.crp_lignes IS
    'Lignes de saisie EPRD/ERRD par compte M22Bis. Stockage à la maille compte × CR × document. '
    'override_balance = true protège la ligne lors d''un replay d''import balance (§D.10bis).';
COMMENT ON COLUMN compta_esms.crp_lignes.compte_m22bis IS
    'Numéro de compte M22Bis (TEXT). PAS de FK PG vers kbs_reference (table dynamique). '
    'Validation par lookup core au runtime.';

CREATE INDEX IF NOT EXISTS idx_crp_cr ON compta_esms.crp_lignes(cr_id);
CREATE INDEX IF NOT EXISTS idx_crp_company ON compta_esms.crp_lignes(company_id);
CREATE INDEX IF NOT EXISTS idx_crp_compte ON compta_esms.crp_lignes(cr_id, compte_m22bis);


-- ============================================================
-- §D.3 PGFP — 148 lignes × 8 exercices N-1 → N+6 (D-095)
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.pgfp_lignes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    cr_id           UUID REFERENCES compta_esms.comptes_resultat(id) ON DELETE CASCADE,
    section         TEXT NOT NULL CHECK (section IN (
        'crp_consolides', 'caf', 'fri', 'fre', 'frng', 'bfr', 'tresorerie', 'ratios'
    )),
    ligne_key       TEXT NOT NULL,
    ligne_label     TEXT,
    montant_nm1     NUMERIC(15, 2),
    montant_n       NUMERIC(15, 2),
    montant_np1     NUMERIC(15, 2),
    montant_np2     NUMERIC(15, 2),
    montant_np3     NUMERIC(15, 2),
    montant_np4     NUMERIC(15, 2),
    montant_np5     NUMERIC(15, 2),
    montant_np6     NUMERIC(15, 2),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.pgfp_lignes IS 'PGFP 148 lignes × 8 exercices (D-095).';

CREATE INDEX IF NOT EXISTS idx_pgfp_doc ON compta_esms.pgfp_lignes(document_id);
CREATE INDEX IF NOT EXISTS idx_pgfp_company ON compta_esms.pgfp_lignes(company_id);


-- ============================================================
-- §D.4 AFFECTATION RÉSULTATS — 4 variantes (D-082)
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.affectations_resultats (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    variante        TEXT NOT NULL CHECK (variante IN (
        'prive_I', 'prive_II', 'public_I', 'public_II'
    )),
    ventilation     TEXT NOT NULL CHECK (ventilation IN ('ternaire_hds', 'simple')),
    cr_id           UUID REFERENCES compta_esms.comptes_resultat(id) ON DELETE CASCADE,
    compte_m22bis   TEXT NOT NULL,
    compte_label    TEXT,
    montant_soins_dependance NUMERIC(15, 2),
    montant_hebergement      NUMERIC(15, 2),
    montant_total            NUMERIC(15, 2),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.affectations_resultats IS
    'Affectation résultats — 4 variantes selon statut OG × CPOM (D-082). Comptes Prive '
    '(11501-11503, 115921-115928, 106852-106857) vs Public (10682-10687, 110, 119).';

CREATE INDEX IF NOT EXISTS idx_affect_doc ON compta_esms.affectations_resultats(document_id);
CREATE INDEX IF NOT EXISTS idx_affect_company ON compta_esms.affectations_resultats(company_id);


CREATE TABLE IF NOT EXISTS compta_esms.suivi_affectations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    etablissement_id UUID REFERENCES compta_esms.etablissements(id) ON DELETE CASCADE,
    compte_m22bis   TEXT NOT NULL,
    solde_debut_n   NUMERIC(15, 2),
    mouvements_credit NUMERIC(15, 2),
    mouvements_debit  NUMERIC(15, 2),
    solde_fin_n     NUMERIC(15, 2),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.suivi_affectations IS
    'Suivi mouvements par compte affectation (D-084) — triplet (Solde N-1 / Mouvements N / Solde N).';

CREATE INDEX IF NOT EXISTS idx_suivi_doc ON compta_esms.suivi_affectations(document_id);


-- ============================================================
-- §D.5 EFFECTIFS — TPER / TER par catégorie CNSA
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.tper_ter_lignes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    etablissement_id UUID REFERENCES compta_esms.etablissements(id) ON DELETE CASCADE,
    type_tableau    TEXT NOT NULL CHECK (type_tableau IN ('TPER', 'TER')),
    type_etablissement TEXT NOT NULL CHECK (type_etablissement IN (
        'ehpad_aja', 'fam_samsah', 'autre_essms', 'sad_spasad'
    )),
    categorie_cnsa  TEXT NOT NULL,
    fonction        TEXT,
    etpr_prevus     NUMERIC(8, 2),
    etpt_prevus     NUMERIC(8, 2),
    etpr_realises   NUMERIC(8, 2),
    etpt_realises   NUMERIC(8, 2),
    remunerations_prevues NUMERIC(15, 2),
    remunerations_realisees NUMERIC(15, 2),
    section_imputation TEXT CHECK (section_imputation IN (
        'hebergement', 'dependance', 'soins', 'soins_autonomie', 'forfait_soins', 'mixte'
    )),
    pct_section     NUMERIC(5, 2),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.tper_ter_lignes IS
    'TPER/TER unifiés : 1 ligne par (document, ETS, catégorie CNSA, fonction). '
    'Référence com.piilot.core.cnsa-fonctions-esms (PLT-44 KB core).';

CREATE INDEX IF NOT EXISTS idx_tper_doc ON compta_esms.tper_ter_lignes(document_id);
CREATE INDEX IF NOT EXISTS idx_tper_ets ON compta_esms.tper_ter_lignes(etablissement_id);
CREATE INDEX IF NOT EXISTS idx_tper_cat ON compta_esms.tper_ter_lignes(categorie_cnsa);


-- ============================================================
-- §D.6 ANNEXE 4 ACTIVITÉ — GIR, journées, places, absences
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.activite_lignes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    etablissement_id UUID REFERENCES compta_esms.etablissements(id) ON DELETE CASCADE,
    annexe_variante TEXT NOT NULL CHECK (annexe_variante IN (
        '4A_ehpad_puv', '4B_autres_essms', '4C_creton', '4D_sad_spasad',
        '9A_ehpad_realise', '9B_autres_realise', '9C_creton_realise', '9D_sad_realise'
    )),
    mode_creton     BOOLEAN NOT NULL DEFAULT false,
    section         TEXT NOT NULL CHECK (section IN (
        'hp', 'ht', 'aj', 'externat', 'semi_internat', 'internat', 'soins_domicile', 'aide_domicile'
    )),
    gir             TEXT CHECK (gir IN (
        'gir1', 'gir2', 'gir3', 'gir4', 'gir5', 'gir6', 'plus_60', 'moins_60', 'non_gire'
    )),
    annee_offset    SMALLINT NOT NULL,
    nature_donnee   TEXT NOT NULL CHECK (nature_donnee IN ('prevu', 'realise', 'theorique')),
    nombre_places   INT,
    nombre_personnes INT,
    nombre_journees INT,
    absences_moins72h_convenance INT,
    absences_moins72h_hospi INT,
    absences_plus72h_convenance INT,
    absences_plus72h_hospi INT,
    hors_departement_count INT,
    beneficiaires_aide_sociale INT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.activite_lignes IS
    'Annexe 4 (prévisionnelle) + Annexe 9 (réalisée). Référentiel GIR 1-6. '
    'Colonnes temporelles différenciées (D-098).';

CREATE INDEX IF NOT EXISTS idx_activite_doc ON compta_esms.activite_lignes(document_id);
CREATE INDEX IF NOT EXISTS idx_activite_ets ON compta_esms.activite_lignes(etablissement_id);


-- ============================================================
-- §D.7 ANNEXE 5 FINANCIÈRE + paramètres forfait
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.annexe5_lignes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    etablissement_id UUID REFERENCES compta_esms.etablissements(id) ON DELETE CASCADE,
    variante        TEXT NOT NULL CHECK (variante IN ('5A_ehpad', '5C_fam_samsah', '5D_sad_spasad')),
    compte_m22bis   TEXT NOT NULL,
    compte_label    TEXT,
    nature          TEXT NOT NULL CHECK (nature IN ('charge', 'produit')),
    -- Ventilation 5A : Hébergement / Dépendance / Soins / SEA
    montant_hebergement_n1 NUMERIC(15, 2),
    montant_hebergement_n  NUMERIC(15, 2),
    montant_dependance_n1  NUMERIC(15, 2),
    montant_dependance_n   NUMERIC(15, 2),
    montant_soins_n1       NUMERIC(15, 2),
    montant_soins_n        NUMERIC(15, 2),
    montant_sea_n1         NUMERIC(15, 2),
    montant_sea_n          NUMERIC(15, 2),
    -- Ventilation 5C : Budget global / Forfait soins
    montant_budget_global_n1 NUMERIC(15, 2),
    montant_budget_global_n  NUMERIC(15, 2),
    montant_forfait_soins_n1 NUMERIC(15, 2),
    montant_forfait_soins_n  NUMERIC(15, 2),
    -- Ventilation 5D : Soins / Aide accompagnement
    montant_soins_sad_n1   NUMERIC(15, 2),
    montant_soins_sad_n    NUMERIC(15, 2),
    montant_aide_acc_n1    NUMERIC(15, 2),
    montant_aide_acc_n     NUMERIC(15, 2),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.annexe5_lignes IS
    'Annexe 5 — forfaits Soins/Dépendance/SEA. Variantes 5A EHPAD / 5C FAM-SAMSAH / 5D SAD-SPASAD.';

CREATE INDEX IF NOT EXISTS idx_annexe5_doc ON compta_esms.annexe5_lignes(document_id);


CREATE TABLE IF NOT EXISTS compta_esms.forfait_parametres (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    etablissement_id UUID REFERENCES compta_esms.etablissements(id) ON DELETE CASCADE,
    date_evaluation DATE,
    nombre_points_gir   INT,
    nombre_personnes_girees INT,
    valeur_point_gir    NUMERIC(8, 4),
    gmp                 NUMERIC(8, 4),
    pmp                 NUMERIC(8, 4),
    gmps                NUMERIC(8, 4),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.forfait_parametres IS
    'Paramètres forfait dépendance + soins (GMP, PMP, GMPS, valeur point GIR). '
    'En l''absence de la KB core valeur-point-gir (PLT-VG, §B.5 suivi.md), '
    'la valeur point GIR peut être saisie manuellement ici.';


-- ============================================================
-- §D.8 BILAN + TABLEAU DE FINANCEMENT
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.bilan_lignes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    type_bilan      TEXT NOT NULL CHECK (type_bilan IN ('financier', 'comptable_pc', 'comptable_pnl')),
    section         TEXT NOT NULL,
    poste_label     TEXT NOT NULL,
    compte_m22bis   TEXT,
    montant_brut_n  NUMERIC(15, 2),
    montant_amort_n NUMERIC(15, 2),
    montant_net_n   NUMERIC(15, 2),
    montant_net_n1  NUMERIC(15, 2),
    type_actif_passif TEXT CHECK (type_actif_passif IN ('actif', 'passif')),
    montant_soins_n NUMERIC(15, 2),
    montant_dependance_n NUMERIC(15, 2),
    montant_hebergement_n NUMERIC(15, 2),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.bilan_lignes IS
    'Bilan unifié — financier (ERRD/EPRD) + comptable PC/PNL (Annexe 3, D-086).';

CREATE INDEX IF NOT EXISTS idx_bilan_doc ON compta_esms.bilan_lignes(document_id);


CREATE TABLE IF NOT EXISTS compta_esms.tf_lignes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    cote            TEXT NOT NULL CHECK (cote IN ('ressources', 'emplois')),
    titre           TEXT,
    compte_m22bis   TEXT,
    libelle         TEXT NOT NULL,
    -- ERRD : 2 colonnes (N-1 + N)
    montant_budget_initial_n1  NUMERIC(15, 2),
    montant_realisations_n1    NUMERIC(15, 2),
    montant_previsions_n       NUMERIC(15, 2),
    montant_realisations_n     NUMERIC(15, 2),
    -- EPRD : 8 colonnes (N-1 à N+6) si TFP
    montant_nm1     NUMERIC(15, 2),
    montant_n       NUMERIC(15, 2),
    montant_np1     NUMERIC(15, 2),
    montant_np2     NUMERIC(15, 2),
    montant_np3     NUMERIC(15, 2),
    montant_np4     NUMERIC(15, 2),
    montant_np5     NUMERIC(15, 2),
    montant_np6     NUMERIC(15, 2),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.tf_lignes IS
    'Tableau de financement (TF ERRD) + Tableau de financement prévisionnel (TFP EPRD).';

CREATE INDEX IF NOT EXISTS idx_tf_doc ON compta_esms.tf_lignes(document_id);


-- ============================================================
-- §D.9 PROVISIONS, DÉPRÉCIATIONS, SUBVENTIONS, EMPRUNTS, RCC
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.provisions_lignes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    categorie       TEXT NOT NULL CHECK (categorie IN (
        'provisions_reglementees',
        'provisions_risques_charges',
        'depreciations',
        'subventions_investissement'
    )),
    cr_id           UUID REFERENCES compta_esms.comptes_resultat(id),
    compte_imputation TEXT NOT NULL,
    objet           TEXT,
    montant_debut_n NUMERIC(15, 2),
    dotations       NUMERIC(15, 2),
    reprises        NUMERIC(15, 2),
    montant_fin_n   NUMERIC(15, 2) GENERATED ALWAYS AS (
        COALESCE(montant_debut_n,0) + COALESCE(dotations,0) - COALESCE(reprises,0)
    ) STORED,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.provisions_lignes IS
    'Provisions / dépréciations / subventions. 4 catégories mouvements (D-099). '
    'montant_fin_n calculée automatiquement.';

CREATE INDEX IF NOT EXISTS idx_provisions_doc ON compta_esms.provisions_lignes(document_id);


CREATE TABLE IF NOT EXISTS compta_esms.emprunts_dettes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    type_dette      TEXT NOT NULL CHECK (type_dette IN (
        'emprunts_prives',
        'dettes_financieres_publics_1', 'dettes_financieres_publics_2',
        'dettes_financieres_publics_3', 'dettes_financieres_publics_4',
        'dettes_financieres_publics_5', 'dettes_financieres_publics_6',
        'dettes_financieres_publics_7', 'dettes_financieres_publics_8'
    )),
    capital_emprunte NUMERIC(15, 2),
    taux            NUMERIC(6, 4),
    duree_annees    SMALLINT,
    date_debut      DATE,
    capital_rembourse_n1 NUMERIC(15, 2),
    capital_rembourse_n  NUMERIC(15, 2),
    interets_n1     NUMERIC(15, 2),
    interets_n      NUMERIC(15, 2),
    solde_restant_du NUMERIC(15, 2),
    libelle         TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.emprunts_dettes IS
    'Emprunts/dettes — 9 onglets (1 Privé + 8 Publics, D-093).';

CREATE INDEX IF NOT EXISTS idx_emprunts_doc ON compta_esms.emprunts_dettes(document_id);


CREATE TABLE IF NOT EXISTS compta_esms.rcc_lignes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    compte_m22bis   TEXT NOT NULL,
    libelle         TEXT,
    montant_total   NUMERIC(15, 2),
    cle_repartition TEXT,
    repartition_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    is_frais_siege  BOOLEAN NOT NULL DEFAULT false,
    is_quote_part_commune BOOLEAN NOT NULL DEFAULT false,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.rcc_lignes IS
    'Répartition charges communes. Contrôle Σ(% par CR) = 100% (D-092). '
    'repartition_json = {cr_id: {pct, montant}}.';

CREATE INDEX IF NOT EXISTS idx_rcc_doc ON compta_esms.rcc_lignes(document_id);


-- ============================================================
-- §D.10 RATIOS + CONTRÔLES
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.ratios_calcules (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    categorie       TEXT NOT NULL CHECK (categorie IN (
        'endettement', 'patrimoine', 'equilibres_bilan', 'rotation_postes', 'autres'
    )),
    ratio_key       TEXT NOT NULL,
    libelle         TEXT,
    valeur_n1       NUMERIC(15, 6),
    valeur_n        NUMERIC(15, 6),
    seuil_min       NUMERIC(15, 6),
    seuil_max       NUMERIC(15, 6),
    statut          TEXT CHECK (statut IN ('ok', 'alerte', 'critique')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (document_id, ratio_key)
);

COMMENT ON TABLE compta_esms.ratios_calcules IS
    'Ratios financiers persistés pour audit + export (15 ratios D-091).';

CREATE INDEX IF NOT EXISTS idx_ratios_doc ON compta_esms.ratios_calcules(document_id);


CREATE TABLE IF NOT EXISTS compta_esms.controles_resultats (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    controle_key    TEXT NOT NULL,
    controle_label  TEXT,
    onglet_source   TEXT,
    severite        TEXT NOT NULL CHECK (severite IN ('info', 'warning', 'error')),
    statut          TEXT NOT NULL CHECK (statut IN ('ok', 'ko', 'na', 'non_evalue')),
    valeur_observee TEXT,
    valeur_attendue TEXT,
    message         TEXT,
    evaluated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (document_id, controle_key)
);

COMMENT ON TABLE compta_esms.controles_resultats IS
    'Résultats des ~352 contrôles (D-077 → D-081). Implémentés en warnings.';

CREATE INDEX IF NOT EXISTS idx_controles_doc ON compta_esms.controles_resultats(document_id);
CREATE INDEX IF NOT EXISTS idx_controles_statut ON compta_esms.controles_resultats(statut)
    WHERE statut IN ('ko');


-- ============================================================
-- §D.11 MÉTA PLUGIN — feature_catalog (global), kb_bindings, exports, rgpd, audit
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.feature_catalog (
    feature_key     TEXT PRIMARY KEY,
    label           TEXT NOT NULL,
    description     TEXT,
    columns_required JSONB NOT NULL,
    is_mandatory    BOOLEAN NOT NULL DEFAULT false,
    applicable_typologies TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
    applicable_doc_types TEXT[] NOT NULL DEFAULT ARRAY['eprd', 'errd'],
    plan_comptable_cible TEXT NOT NULL DEFAULT 'M22Bis',
    -- §D.10bis : versioning contrat colonnes
    contract_version SMALLINT NOT NULL DEFAULT 1,
    ordre           INT NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.feature_catalog IS
    'Catalogue features bindables D-103. Catalogue global plugin (PAS de company_id, PAS de RLS). '
    'Le seed du catalogue vit dans 003_compta_esms_seed_feature_catalog.sql. '
    'contract_version permet d''évoluer un contrat colonnes sans casser les bindings existants.';


CREATE TABLE IF NOT EXISTS compta_esms.kb_bindings (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    feature_key     TEXT NOT NULL REFERENCES compta_esms.feature_catalog(feature_key),
    kb_id           UUID NOT NULL,
    kb_table        TEXT NOT NULL,
    column_mapping  JSONB NOT NULL DEFAULT '{}'::jsonb,
    plan_comptable_source TEXT NOT NULL DEFAULT 'M22Bis',
    bound_by_user_id UUID NOT NULL,
    bound_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (document_id, feature_key)
);

COMMENT ON TABLE compta_esms.kb_bindings IS
    'Binding KB → feature (D-103). 1 binding par (document, feature). plan_comptable_source '
    'filtré sur M22Bis (D-106 + D-107 : le plugin consomme du M22Bis exclusivement, '
    'le mapping balance fait par l''assistant D-108 sinon).';

CREATE INDEX IF NOT EXISTS idx_bindings_doc ON compta_esms.kb_bindings(document_id);
CREATE INDEX IF NOT EXISTS idx_bindings_company ON compta_esms.kb_bindings(company_id);


CREATE TABLE IF NOT EXISTS compta_esms.exports_history (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    document_id     UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    format          TEXT NOT NULL CHECK (format IN ('xlsx_dgcs', 'docx_rapport_budgetaire', 'pdf')),
    nom_fichier     TEXT NOT NULL,
    storage_key     TEXT NOT NULL,
    size_bytes      BIGINT,
    generated_by_user_id UUID NOT NULL,
    generated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    cadre_version   TEXT
);

COMMENT ON TABLE compta_esms.exports_history IS
    'Historique exports XLSX/DOCX/PDF. Storage S3 SeaweedFS. Snapshot cadre_version pour traçabilité.';

CREATE INDEX IF NOT EXISTS idx_exports_doc ON compta_esms.exports_history(document_id);


CREATE TABLE IF NOT EXISTS compta_esms.recueil_consentement_rgpd (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    exercice_id     UUID NOT NULL REFERENCES compta_esms.exercices(id) ON DELETE CASCADE,
    consentement_cnsa BOOLEAN NOT NULL DEFAULT false,
    federations_consenties JSONB NOT NULL DEFAULT '[]'::jsonb,
    duree           TEXT CHECK (duree IN ('1_an', '5_ans', 'jusqu_revocation')),
    consenti_par_user_id UUID,
    consenti_at     TIMESTAMPTZ,
    revoque_at      TIMESTAMPTZ,
    UNIQUE (exercice_id)
);

COMMENT ON TABLE compta_esms.recueil_consentement_rgpd IS
    'D-090 : hors champ réglementaire, warning non bloquant. 17 fédérations.';


CREATE TABLE IF NOT EXISTS compta_esms.audit_events (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL,
    user_id         UUID NOT NULL,
    document_id     UUID REFERENCES compta_esms.documents_budgetaires(id) ON DELETE SET NULL,
    action          TEXT NOT NULL,
    resource_type   TEXT NOT NULL,
    resource_id     UUID,
    payload         JSONB DEFAULT '{}'::jsonb,
    occurred_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.audit_events IS
    'Traçabilité des actions critiques (transitions, exports, suppressions). '
    'Pas de updated_at car immutables.';

CREATE INDEX IF NOT EXISTS idx_audit_company ON compta_esms.audit_events(company_id);
CREATE INDEX IF NOT EXISTS idx_audit_doc ON compta_esms.audit_events(document_id);
CREATE INDEX IF NOT EXISTS idx_audit_at ON compta_esms.audit_events(occurred_at DESC);


-- ============================================================
-- §D.12 BALANCE MAPPING ASSISTANT — D-108 + D-109
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.balance_mappings (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id              UUID NOT NULL,
    source_plan             TEXT NOT NULL CHECK (source_plan IN (
        'PCG', 'M14', 'M21', 'M22Bis', 'Sage', 'EBP', 'Cegid', 'Pennylane', 'custom'
    )),
    source_account          TEXT NOT NULL,
    target_m22bis_account   TEXT NOT NULL,
    weight                  NUMERIC(8,6) NOT NULL DEFAULT 1.0
                            CHECK (weight > 0 AND weight <= 1.0),
    label_hint              TEXT,
    confidence              NUMERIC(4,3)
                            CHECK (confidence IS NULL OR (confidence >= 0 AND confidence <= 1.0)),
    suggestion_origin       TEXT CHECK (suggestion_origin IN (
        'manual', 'pcg_to_m22bis_kb', 'preset', 'llm'
    )),
    version_m22bis          TEXT NOT NULL DEFAULT '2025-2026',
    valid_from              DATE,
    valid_to                DATE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (company_id, source_plan, source_account, target_m22bis_account, version_m22bis)
);

COMMENT ON TABLE compta_esms.balance_mappings IS
    'D-108 : mapping per-company compte source → compte M22Bis. 1 ligne par couple source/cible. '
    'Cas 1:N géré en insérant plusieurs lignes pour le même source_account avec un weight fractionné '
    '(Σ weight = 1.0 par source_account, enforced par trigger). D-109 : la ventilation H/D/S '
    'vit ailleurs (CRP analytique).';

COMMENT ON COLUMN compta_esms.balance_mappings.weight IS
    'Coefficient de répartition pour cas 1:N. weight=1.0 pour 1:1 ou N:1.';

CREATE INDEX IF NOT EXISTS idx_balance_mappings_company
    ON compta_esms.balance_mappings(company_id);
CREATE INDEX IF NOT EXISTS idx_balance_mappings_lookup
    ON compta_esms.balance_mappings(company_id, source_plan, source_account, version_m22bis);


CREATE TABLE IF NOT EXISTS compta_esms.balance_imports (
    id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id                  UUID NOT NULL,
    exercice_id                 UUID REFERENCES compta_esms.exercices(id) ON DELETE SET NULL,
    etablissement_id            UUID REFERENCES compta_esms.etablissements(id) ON DELETE SET NULL,
    source_plan                 TEXT NOT NULL CHECK (source_plan IN (
        'PCG', 'M14', 'M21', 'M22Bis', 'Sage', 'EBP', 'Cegid', 'Pennylane', 'custom'
    )),
    source_filename             TEXT,
    source_storage_key          TEXT,
    periode_label               TEXT NOT NULL,
    nb_lignes_source            INT NOT NULL,
    nb_lignes_mappees           INT NOT NULL,
    nb_lignes_non_mappees       INT NOT NULL DEFAULT 0,
    mapping_snapshot            JSONB NOT NULL DEFAULT '{}'::jsonb,
    materialized_kb_id          UUID,
    materialized_kb_table_name  TEXT,
    status                      TEXT NOT NULL DEFAULT 'completed' CHECK (status IN (
        'pending', 'completed', 'failed', 'partial'
    )),
    error_payload               JSONB DEFAULT '{}'::jsonb,
    imported_by_user_id         UUID NOT NULL,
    imported_at                 TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE compta_esms.balance_imports IS
    'D-108 : historique imports + matérialisation KB plugin-owned M22Bis. '
    'Permet audit (fichier source, mapping appliqué) + reproductibilité (replay).';

CREATE INDEX IF NOT EXISTS idx_balance_imports_company
    ON compta_esms.balance_imports(company_id);
CREATE INDEX IF NOT EXISTS idx_balance_imports_exercice
    ON compta_esms.balance_imports(exercice_id);
CREATE INDEX IF NOT EXISTS idx_balance_imports_periode
    ON compta_esms.balance_imports(company_id, periode_label);
CREATE INDEX IF NOT EXISTS idx_balance_imports_imported_at
    ON compta_esms.balance_imports(imported_at DESC);


-- ============================================================
-- §D.12 (suite) TRIGGER D'INTÉGRITÉ Σ weight ≤ 1.0 (balance_mappings)
-- ============================================================

CREATE OR REPLACE FUNCTION compta_esms.tg_check_balance_mapping_weights()
RETURNS TRIGGER AS $$
DECLARE
    total_weight NUMERIC(8,6);
BEGIN
    SELECT COALESCE(SUM(weight), 0)
      INTO total_weight
      FROM compta_esms.balance_mappings
     WHERE company_id = NEW.company_id
       AND source_plan = NEW.source_plan
       AND source_account = NEW.source_account
       AND version_m22bis = NEW.version_m22bis;
    -- Tolérance 1e-4 pour arrondis flottants
    IF total_weight > 1.0001 THEN
        RAISE EXCEPTION 'Sum of weight for (source_plan=%, source_account=%, version_m22bis=%) exceeds 1.0 (got %)',
            NEW.source_plan, NEW.source_account, NEW.version_m22bis, total_weight;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tg_balance_mapping_weights_check ON compta_esms.balance_mappings;
CREATE TRIGGER tg_balance_mapping_weights_check
    AFTER INSERT OR UPDATE OF weight ON compta_esms.balance_mappings
    FOR EACH ROW EXECUTE FUNCTION compta_esms.tg_check_balance_mapping_weights();


-- ============================================================
-- §D.13 RLS — Row Level Security company-scoped
-- ============================================================
-- Toutes les tables ont une colonne `company_id` sauf `feature_catalog`
-- (catalogue global plugin). On enforce :
--   - ENABLE + FORCE Row Level Security
--   - 1 policy d'isolation par tenant via `app.current_company_id`
-- ============================================================

DO $$
DECLARE
    t TEXT;
BEGIN
    FOR t IN
        -- Apply RLS to every compta_esms table that carries a company_id
        -- column. Skipping feature_catalog (global plugin catalog) is
        -- explicit ; skipping tables without company_id is structural
        -- (future cross-tenant caches like llm_suggestion_cache from
        -- migration 005 land here too — they aren't tenant-scoped).
        SELECT t.table_name
        FROM information_schema.tables t
        JOIN information_schema.columns c
          ON c.table_schema = t.table_schema
         AND c.table_name = t.table_name
        WHERE t.table_schema = 'compta_esms'
          AND t.table_type = 'BASE TABLE'
          AND t.table_name NOT IN ('feature_catalog')
          AND c.column_name = 'company_id'
    LOOP
        EXECUTE format('ALTER TABLE compta_esms.%I ENABLE ROW LEVEL SECURITY;', t);
        EXECUTE format('ALTER TABLE compta_esms.%I FORCE ROW LEVEL SECURITY;', t);
        EXECUTE format('DROP POLICY IF EXISTS %I_company_isolation ON compta_esms.%I;', t, t);
        EXECUTE format(
            'CREATE POLICY %I_company_isolation ON compta_esms.%I
                USING (company_id = current_setting(''app.current_company_id'', true)::uuid)
                WITH CHECK (company_id = current_setting(''app.current_company_id'', true)::uuid);',
            t, t
        );
    END LOOP;
END $$;


-- ============================================================
-- §D.13 (suite) TRIGGERS — updated_at automatique
-- ============================================================

CREATE OR REPLACE FUNCTION compta_esms.tg_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE
    t TEXT;
    trg_name TEXT;
BEGIN
    FOR t IN
        SELECT c.table_name
        FROM information_schema.tables c
        WHERE c.table_schema = 'compta_esms'
          AND c.table_type = 'BASE TABLE'
          AND EXISTS (
              SELECT 1 FROM information_schema.columns col
              WHERE col.table_schema = 'compta_esms'
                AND col.table_name = c.table_name
                AND col.column_name = 'updated_at'
          )
    LOOP
        trg_name := 'tg_' || t || '_updated_at';
        EXECUTE format('DROP TRIGGER IF EXISTS %I ON compta_esms.%I;', trg_name, t);
        EXECUTE format(
            'CREATE TRIGGER %I
                BEFORE UPDATE ON compta_esms.%I
                FOR EACH ROW EXECUTE FUNCTION compta_esms.tg_set_updated_at();',
            trg_name, t
        );
    END LOOP;
END $$;

-- ============================================================
-- FIN 002_compta_esms_core.sql — 25 tables + 28 indexes + RLS + triggers
-- ============================================================
