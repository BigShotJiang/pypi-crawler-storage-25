-- Migration 014 — Décomposition des capacités ETS par typologie (§U, D-048).
--
-- Le DDL initial 002 §D.2 a posé les 3 capacités agrégées (autorisée /
-- installée / financée) suffisantes pour §H→§T. Mais §AB ratios
-- vétusté (D-091) et §R Q10 :compute forfait_dependance ont besoin de
-- la décomposition par section.
--
-- KB19 §11 (annexe 4 activité GIR) confirme la structure spec :
--
-- * **EHPAD / AJA / PUV** — 5 sections : HP (Hébergement Permanent),
--   UHR (Unité Hébergement Renforcée), PASA (Pôle d'Activités et Soins
--   Adaptés), HT (Hébergement Temporaire), AJ (Accueil de Jour).
-- * **Autres ESSMS** (IME, ITEP, SESSAD, CMPP, MAS, FAM, etc.) — 3
--   sections : externat, semi-internat, internat.
--
-- 8 colonnes nullable au total (un EHPAD remplira HP/UHR/PASA/HT/AJ et
-- laissera externat/semi/internat à NULL, et vice versa). Pas de
-- CHECK constraint cross-field (la cohérence typologie ↔ sections
-- relève d'une validation différée §Z catalogue contrôles).
--
-- Pas d'index ajouté — ces colonnes ne servent pas dans des prédicats
-- WHERE de listings. Elles sont lues row-by-row par les calculs §AB /
-- §R Q10.

-- UP
-- ============================================================

ALTER TABLE compta_esms.etablissements
    ADD COLUMN IF NOT EXISTS capacite_hp             INT,
    ADD COLUMN IF NOT EXISTS capacite_uhr            INT,
    ADD COLUMN IF NOT EXISTS capacite_pasa           INT,
    ADD COLUMN IF NOT EXISTS capacite_ht             INT,
    ADD COLUMN IF NOT EXISTS capacite_aj             INT,
    ADD COLUMN IF NOT EXISTS capacite_externat       INT,
    ADD COLUMN IF NOT EXISTS capacite_semi_internat  INT,
    ADD COLUMN IF NOT EXISTS capacite_internat       INT;


-- CHECK constraints : valeurs >= 0 pour les 8 colonnes.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint c
        JOIN pg_class t      ON t.oid = c.conrelid
        JOIN pg_namespace n  ON n.oid = t.relnamespace
        WHERE n.nspname = 'compta_esms'
          AND t.relname = 'etablissements'
          AND c.conname = 'etablissements_capacite_breakdown_nonneg'
    ) THEN
        ALTER TABLE compta_esms.etablissements
            ADD CONSTRAINT etablissements_capacite_breakdown_nonneg
            CHECK (
                (capacite_hp            IS NULL OR capacite_hp            >= 0) AND
                (capacite_uhr           IS NULL OR capacite_uhr           >= 0) AND
                (capacite_pasa          IS NULL OR capacite_pasa          >= 0) AND
                (capacite_ht            IS NULL OR capacite_ht            >= 0) AND
                (capacite_aj            IS NULL OR capacite_aj            >= 0) AND
                (capacite_externat      IS NULL OR capacite_externat      >= 0) AND
                (capacite_semi_internat IS NULL OR capacite_semi_internat >= 0) AND
                (capacite_internat      IS NULL OR capacite_internat      >= 0)
            );
    END IF;
END $$;


-- COMMENTAIRES
-- ============================================================

COMMENT ON COLUMN compta_esms.etablissements.capacite_hp IS
    'EHPAD/AJA/PUV : Hébergement Permanent (KB19 §11, D-048).';
COMMENT ON COLUMN compta_esms.etablissements.capacite_uhr IS
    'EHPAD/AJA/PUV : Unité d''Hébergement Renforcée (KB19 §11, D-048).';
COMMENT ON COLUMN compta_esms.etablissements.capacite_pasa IS
    'EHPAD/AJA/PUV : Pôle d''Activités et Soins Adaptés (KB19 §11, D-048).';
COMMENT ON COLUMN compta_esms.etablissements.capacite_ht IS
    'EHPAD/AJA/PUV : Hébergement Temporaire (KB19 §11, D-048).';
COMMENT ON COLUMN compta_esms.etablissements.capacite_aj IS
    'EHPAD/AJA/PUV : Accueil de Jour (KB19 §11, D-048).';
COMMENT ON COLUMN compta_esms.etablissements.capacite_externat IS
    'Autres ESSMS (IME/ITEP/SESSAD/...) : places externat (KB19 §11, D-048).';
COMMENT ON COLUMN compta_esms.etablissements.capacite_semi_internat IS
    'Autres ESSMS : places semi-internat (KB19 §11, D-048).';
COMMENT ON COLUMN compta_esms.etablissements.capacite_internat IS
    'Autres ESSMS : places internat (KB19 §11, D-048).';

-- ============================================================
-- DOWN  (reference only — pas joué par le runner idempotent)
-- ============================================================
-- ALTER TABLE compta_esms.etablissements
--     DROP CONSTRAINT IF EXISTS etablissements_capacite_breakdown_nonneg;
-- ALTER TABLE compta_esms.etablissements
--     DROP COLUMN IF EXISTS capacite_hp,
--     DROP COLUMN IF EXISTS capacite_uhr,
--     DROP COLUMN IF EXISTS capacite_pasa,
--     DROP COLUMN IF EXISTS capacite_ht,
--     DROP COLUMN IF EXISTS capacite_aj,
--     DROP COLUMN IF EXISTS capacite_externat,
--     DROP COLUMN IF EXISTS capacite_semi_internat,
--     DROP COLUMN IF EXISTS capacite_internat;
