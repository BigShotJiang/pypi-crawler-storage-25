-- Migration 006 — column_detection + preview_data on balance_imports
--
-- The §F.3 upload endpoint sanitizes the cabinet's source file, stores
-- it on S3 (`source_storage_key`) and persists a row in
-- `compta_esms.balance_imports`. The downstream flow (detect-columns →
-- preview → suggest → apply) needs two more pieces of state on that
-- row that aren't in the §D schema :
--
-- * ``column_detection`` — `{compte: int|null, libelle: int|null,
--   debit: int|null, credit: int|null, solde: int|null, periode: int|null}`
--   where each value is the **0-based column index** in the source
--   file (or null when no column matches that role). Populated at
--   upload time by the auto-heuristic ; mutable via ``detect-columns``
--   when the cabinet overrides.
--
-- * ``preview_data`` — the first 20 parsed rows of the source file,
--   stored as `[{col_0: ..., col_1: ...}, ...]`. Lets ``GET .../preview``
--   render the assistant's step-2 table without re-downloading the
--   file from S3 every time.
--
-- Both JSONB so they can grow over time (extra column metadata,
-- preview row count, …) without further migrations. Default `{}` /
-- `[]` so existing rows from migration 002 stay valid.

-- UP

ALTER TABLE compta_esms.balance_imports
    ADD COLUMN IF NOT EXISTS column_detection JSONB
        NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE compta_esms.balance_imports
    ADD COLUMN IF NOT EXISTS preview_data JSONB
        NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN compta_esms.balance_imports.column_detection IS
    '0-based column indices per role (compte/libelle/debit/credit/solde/'
    'periode). Populated at upload + mutable via :detect-columns.';

COMMENT ON COLUMN compta_esms.balance_imports.preview_data IS
    'Parsed preview payload : {"header": [...], "rows": [[...], ...]}. '
    'Header + first 20 data rows. Lets :preview render without '
    're-downloading from S3.';
