-- Migration 022 — Ajout colonne ``equilibre_atteint_o_n`` sur
-- ``documents_budgetaires`` (§BD v0.3, D-034).
--
-- Persistance du verdict d'équilibre R.314-222 calculé à la transition
-- ``brouillon → transmis`` par ``equilibre_service.apply_equilibre_check_for_document``.
--
-- Valeurs (KB B.7) :
-- * ``OUI``             — équilibre atteint (5 conditions réel OK ou
--                          strict recettes==dépenses OK).
-- * ``NON``             — équilibre non atteint (au moins une condition
--                          en échec ou un total déséquilibré). La
--                          transition transmit est bloquée par D-034.
-- * ``NON_APPLICABLE``  — équilibre R.314-222 ne s'applique pas (cas
--                          PRIVE_COMMERCIAL hors CPOM — pas d'obligation).
-- * ``NULL``            — pas encore évalué (état initial, ou doc en
--                          ``brouillon`` qui n'a pas tenté transmit).
--
-- La colonne est mise à jour exclusivement par le service §BD ;
-- l'API ne l'expose pas en saisie directe (read-only côté front).
-- Idempotente : la migration peut être re-jouée sans erreur.

-- UP
-- ============================================================

ALTER TABLE compta_esms.documents_budgetaires
    ADD COLUMN IF NOT EXISTS equilibre_atteint_o_n TEXT;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'documents_budgetaires_equilibre_atteint_check'
    ) THEN
        ALTER TABLE compta_esms.documents_budgetaires
            ADD CONSTRAINT documents_budgetaires_equilibre_atteint_check
            CHECK (equilibre_atteint_o_n IS NULL OR equilibre_atteint_o_n IN (
                'OUI', 'NON', 'NON_APPLICABLE'
            ));
    END IF;
END $$;


COMMENT ON COLUMN compta_esms.documents_budgetaires.equilibre_atteint_o_n IS
    'Verdict équilibre R.314-222 (§BD v0.3, D-034). Calculé par '
    '``equilibre_service.apply_equilibre_check_for_document`` à la '
    'transition brouillon→transmis. OUI = équilibre atteint, NON = '
    'transition bloquée, NON_APPLICABLE = R.314-222 inapplicable '
    '(PRIVE_COMMERCIAL hors CPOM), NULL = pas encore évalué.';


-- Index partiel pour le listing UI "documents NON équilibrés" (filtre
-- dashboard cabinet).
CREATE INDEX IF NOT EXISTS idx_documents_equilibre_non
    ON compta_esms.documents_budgetaires(company_id)
    WHERE equilibre_atteint_o_n = 'NON';


-- ============================================================
-- DOWN  (reference only — pas joué par le runner idempotent)
-- ============================================================
-- DROP INDEX IF EXISTS compta_esms.idx_documents_equilibre_non;
-- ALTER TABLE compta_esms.documents_budgetaires
--     DROP CONSTRAINT IF EXISTS documents_budgetaires_equilibre_atteint_check;
-- ALTER TABLE compta_esms.documents_budgetaires
--     DROP COLUMN IF EXISTS equilibre_atteint_o_n;
