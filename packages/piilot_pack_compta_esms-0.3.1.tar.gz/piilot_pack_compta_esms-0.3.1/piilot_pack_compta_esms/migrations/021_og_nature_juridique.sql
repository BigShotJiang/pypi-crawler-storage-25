-- Migration 021 — Rename `statut_juridique` → `nature_juridique` sur OG
-- (§BC v0.3, conforme spec KB B.1 D-037).
--
-- v0.2 a livré ``compta_esms.organismes_gestionnaires.statut_juridique``
-- avec 4 valeurs lowercase. La spec D-037 (KB ``06-data-model.md``
-- §B.1) impose le nom canonique ``nature_juridique`` avec 5 valeurs
-- UPPER, dont une nouvelle valeur ``CCAS_CIAS_COLLECTIVITE`` qui
-- était mélangée avec ``essms_public_non_eps`` en v0.2.
--
-- Cette migration aligne le schéma sur la spec (clean break) :
--
-- 1. RENAME COLUMN ``statut_juridique`` → ``nature_juridique``
-- 2. DROP l'ancien CHECK constraint (auto-généré par PG sur l'inline
--    CHECK de la migration 002)
-- 3. UPDATE data — mapping 4 valeurs lower → 5 valeurs UPPER. Le cas
--    ``essms_public_non_eps`` est mappé par défaut vers
--    ``ESMS_PUBLIC_AUTONOME``. Les utilisateurs CCAS/CIAS devront
--    éditer leur OG via PATCH pour passer à ``CCAS_CIAS_COLLECTIVITE``
--    (impossible à distinguer automatiquement).
-- 4. ADD CONSTRAINT (5 valeurs UPPER)
--
-- Toutes les étapes sont idempotentes : la migration peut être
-- re-jouée après application sans erreur.

-- UP
-- ============================================================

-- §BC.1.1 — RENAME COLUMN si pas déjà fait.
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'compta_esms'
          AND table_name   = 'organismes_gestionnaires'
          AND column_name  = 'statut_juridique'
    ) THEN
        ALTER TABLE compta_esms.organismes_gestionnaires
            RENAME COLUMN statut_juridique TO nature_juridique;
    END IF;
END $$;


-- §BC.1.2 — DROP les anciens CHECK constraints. PG génère
-- automatiquement le nom sur les inline CHECK comme
-- ``organismes_gestionnaires_statut_juridique_check`` ; après
-- RENAME COLUMN le check garde son nom d'origine.
ALTER TABLE compta_esms.organismes_gestionnaires
    DROP CONSTRAINT IF EXISTS organismes_gestionnaires_statut_juridique_check;

-- Et le nouveau nom au cas où la migration a déjà été appliquée
-- partiellement puis re-jouée.
ALTER TABLE compta_esms.organismes_gestionnaires
    DROP CONSTRAINT IF EXISTS organismes_gestionnaires_nature_juridique_check;


-- §BC.1.3 — UPDATE data : mapping 4 lowercase → 5 UPPER.
-- Idempotent : on ne touche que les rows qui ont encore l'ancienne
-- valeur (UPPER déjà présent = no-op).
UPDATE compta_esms.organismes_gestionnaires
SET nature_juridique = CASE nature_juridique
    WHEN 'eps'                       THEN 'ETABLISSEMENT_PUBLIC_SANTE'
    WHEN 'essms_public_non_eps'      THEN 'ESMS_PUBLIC_AUTONOME'
    WHEN 'essms_prive_non_lucratif'  THEN 'PRIVE_NON_LUCRATIF'
    WHEN 'essms_prive_commercial'    THEN 'PRIVE_COMMERCIAL'
    ELSE nature_juridique
END
WHERE nature_juridique IN (
    'eps',
    'essms_public_non_eps',
    'essms_prive_non_lucratif',
    'essms_prive_commercial'
);


-- §BC.1.4 — ADD CONSTRAINT 5 valeurs UPPER (idempotent via le DROP
-- ci-dessus).
ALTER TABLE compta_esms.organismes_gestionnaires
    ADD CONSTRAINT organismes_gestionnaires_nature_juridique_check
    CHECK (nature_juridique IN (
        'ETABLISSEMENT_PUBLIC_SANTE',
        'ESMS_PUBLIC_AUTONOME',
        'CCAS_CIAS_COLLECTIVITE',
        'PRIVE_NON_LUCRATIF',
        'PRIVE_COMMERCIAL'
    ));


COMMENT ON COLUMN compta_esms.organismes_gestionnaires.nature_juridique IS
    'Nature juridique DGCS (KB B.1, 5 valeurs). Pilote ``compute_eprd_structure`` '
    '(§BC) et ``choose_affectation_variante`` (D-082). '
    'CCAS_CIAS_COLLECTIVITE n''est pas dérivable de l''ancien statut_juridique '
    'lowercase — les OG concernés doivent être ré-saisis manuellement.';


-- ============================================================
-- DOWN  (reference only — pas joué par le runner idempotent)
-- ============================================================
-- ALTER TABLE compta_esms.organismes_gestionnaires
--     DROP CONSTRAINT IF EXISTS organismes_gestionnaires_nature_juridique_check;
-- UPDATE compta_esms.organismes_gestionnaires SET nature_juridique = CASE
--     WHEN nature_juridique = 'ETABLISSEMENT_PUBLIC_SANTE' THEN 'eps'
--     WHEN nature_juridique = 'ESMS_PUBLIC_AUTONOME'       THEN 'essms_public_non_eps'
--     WHEN nature_juridique = 'CCAS_CIAS_COLLECTIVITE'     THEN 'essms_public_non_eps'  -- regroupé
--     WHEN nature_juridique = 'PRIVE_NON_LUCRATIF'         THEN 'essms_prive_non_lucratif'
--     WHEN nature_juridique = 'PRIVE_COMMERCIAL'           THEN 'essms_prive_commercial'
-- END;
-- ALTER TABLE compta_esms.organismes_gestionnaires
--     RENAME COLUMN nature_juridique TO statut_juridique;
-- ALTER TABLE compta_esms.organismes_gestionnaires
--     ADD CONSTRAINT organismes_gestionnaires_statut_juridique_check
--     CHECK (statut_juridique IN ('eps', 'essms_public_non_eps', 'essms_prive_non_lucratif', 'essms_prive_commercial'));
