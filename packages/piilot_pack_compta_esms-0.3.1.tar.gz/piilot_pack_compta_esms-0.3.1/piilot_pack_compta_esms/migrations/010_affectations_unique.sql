-- Migration 010 — UNIQUE partial indexes for affectation upsert by section (§J.1).
--
-- §J's ``PUT /affectations`` is a **bulk upsert by section** (plan-dev §7.5 :
-- ``upsert_affectation(doc_id, payload) → "Bulk upsert des affectations (replace
-- by section)"``). The DDL 002 created ``compta_esms.affectations_resultats``
-- without natural-key UNIQUE — we add two **partial** indexes here, one per
-- D-082 variant family :
--
-- * ``prive_I`` / ``public_I`` — pre-CPOM, per ESSMS (one column per CR) →
--   natural key ``(document_id, variante, cr_id, compte_m22bis)``.
--
-- * ``prive_II`` / ``public_II`` — post-CPOM, consolidé au niveau document
--   (cf. 25-deepdive §4.2 / §4.4 "globalisation post-CPOM") → natural key
--   ``(document_id, variante, compte_m22bis)`` (cr_id reste NULL).
--
-- Postgres handles ``UNIQUE`` differently when a column is NULL : two rows
-- with the same (document_id, variante, NULL, compte_m22bis) tuple are NOT
-- considered duplicates by default. That's why we split into two partial
-- indexes by ``WHERE variante IN (...)`` — each is unambiguous for its
-- variant family.
--
-- Why not a single UNIQUE on the whole table : because ``cr_id`` is
-- nullable, a single ``UNIQUE(document_id, variante, cr_id, compte_m22bis)``
-- wouldn't actually enforce uniqueness for the variant_II case (NULL ≠ NULL
-- in standard PG). The two partial indexes give the strict semantic for
-- each variant.

-- UP
-- ============================================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_indexes
        WHERE schemaname = 'compta_esms'
          AND indexname = 'uq_affectations_variant_i'
    ) THEN
        CREATE UNIQUE INDEX uq_affectations_variant_i
            ON compta_esms.affectations_resultats (
                document_id, variante, cr_id, compte_m22bis
            )
            WHERE variante IN ('prive_I', 'public_I');
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM pg_indexes
        WHERE schemaname = 'compta_esms'
          AND indexname = 'uq_affectations_variant_ii'
    ) THEN
        CREATE UNIQUE INDEX uq_affectations_variant_ii
            ON compta_esms.affectations_resultats (
                document_id, variante, compte_m22bis
            )
            WHERE variante IN ('prive_II', 'public_II');
    END IF;
END $$;

COMMENT ON INDEX compta_esms.uq_affectations_variant_i IS
    'UNIQUE pour les variantes pre-CPOM (par ESSMS / CR). Cible du '
    'bulk-upsert §J.7 ON CONFLICT pour variant_I.';

COMMENT ON INDEX compta_esms.uq_affectations_variant_ii IS
    'UNIQUE pour les variantes post-CPOM (consolidé document). cr_id reste '
    'NULL — partial WHERE évite la collision avec variant_I qui partage le '
    'même prefix de colonnes.';

-- ============================================================
-- DOWN  (reference only)
-- ============================================================
-- DROP INDEX IF EXISTS compta_esms.uq_affectations_variant_i;
-- DROP INDEX IF EXISTS compta_esms.uq_affectations_variant_ii;
