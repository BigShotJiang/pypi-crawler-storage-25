-- Migration 008 — apply-mapping artefacts on balance_imports (§F.5).
--
-- After ``POST .../apply-mapping`` the service needs to surface two
-- post-application reports :
--
-- * ``unmapped_accounts`` — source accounts the dictionary couldn't
--   resolve to any M22 bis target. Shape :
--
--   .. code-block:: json
--
--     [
--       {
--         "source_account": "UNKNOWN999",
--         "label_hint": "Compte inconnu",
--         "montant": 12345.67,
--         "nb_lignes": 3
--       }
--     ]
--
--   Powers ``GET .../unmapped-accounts`` without re-running the apply
--   pipeline ; lets the assistant UI nudge the cabinet toward the
--   accounts that still need attention.
--
-- * ``applied_at`` — last successful apply timestamp. Used by the
--   replay endpoint to detect stale state ("Last applied : Tue 14:32 ;
--   suggestions changed since — re-apply ?").
--
-- DEFAULT empty so existing §F.4 rows stay valid.

-- UP

ALTER TABLE compta_esms.balance_imports
    ADD COLUMN IF NOT EXISTS unmapped_accounts JSONB
        NOT NULL DEFAULT '[]'::jsonb;

ALTER TABLE compta_esms.balance_imports
    ADD COLUMN IF NOT EXISTS applied_at TIMESTAMPTZ;

COMMENT ON COLUMN compta_esms.balance_imports.unmapped_accounts IS
    'Source accounts left unresolved by the last apply-mapping pass. '
    'Shape : [{source_account, label_hint, montant, nb_lignes}]. '
    'Read by GET .../unmapped-accounts.';

COMMENT ON COLUMN compta_esms.balance_imports.applied_at IS
    'UTC timestamp of the last successful apply-mapping run. NULL = '
    'never applied (status=pending). Updated by :apply-mapping and '
    ':replay.';
