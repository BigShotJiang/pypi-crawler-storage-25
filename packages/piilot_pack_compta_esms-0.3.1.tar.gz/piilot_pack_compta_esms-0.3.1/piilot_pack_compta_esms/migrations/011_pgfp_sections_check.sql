-- Migration 011 — Extend pgfp_lignes section CHECK from 8 to 10 values (§O).
--
-- D-095 splits the PGFP in **10 blocs** (CRP consolidés / CAF / FRI / FRE /
-- FRNG / BFR / Trésorerie / **Contrôles cohérence** / **Données complémentaires** /
-- Ratios). The DDL initially shipped in migration 002 only accepted 8 values
-- (the spec L1-schema-db.sql also had this omission). Two sections were
-- missing :
--
-- * ``controles_coherence`` — bloc 8 (cf. KB25 §12.3 + 16-annexe1 §8 Bloc 8) :
--   FRNG inscrit en D96 du Bilan, Trésorerie inscrit en D114, variation
--   trésorerie EPRD synthétique vs PGFP. Calculées par ``:recompute``, le
--   verdict OK/KO sortira en §Z (catalogue contrôles).
--
-- * ``donnees_complementaires`` — bloc 9 (cf. KB25 §12.3 + 16-annexe1 §8
--   Bloc 9) : encours emprunts c/16, immobilisations brutes, amortissements
--   cumulés, valeurs comptables immobilisations cédées (c/652). Saisies
--   cabinet (input du recompute).
--
-- Also adds a **partial unique index** on (document_id, ligne_key) WHERE
-- cr_id IS NULL — required for the PATCH §9.2 upsert by ligne_key (PGFP
-- global). The DDL allows cr_id != NULL for the future CRP_PGFP usage
-- (D-096) which lives in another chantier (§Y) ; the partial index ignores
-- those rows.

-- UP
-- ============================================================

DO $$
DECLARE
    has_old_check BOOLEAN;
    has_new_check BOOLEAN;
BEGIN
    -- Phase 1 — Replace section CHECK from 8 → 10 values.
    SELECT EXISTS (
        SELECT 1
        FROM pg_constraint c
        JOIN pg_class t ON t.oid = c.conrelid
        JOIN pg_namespace n ON n.oid = t.relnamespace
        WHERE n.nspname = 'compta_esms'
          AND t.relname = 'pgfp_lignes'
          AND c.conname = 'pgfp_lignes_section_check'
    ) INTO has_old_check;

    SELECT EXISTS (
        SELECT 1
        FROM pg_constraint c
        JOIN pg_class t ON t.oid = c.conrelid
        JOIN pg_namespace n ON n.oid = t.relnamespace
        WHERE n.nspname = 'compta_esms'
          AND t.relname = 'pgfp_lignes'
          AND c.conname = 'pgfp_lignes_section_check_v2'
    ) INTO has_new_check;

    IF has_old_check AND NOT has_new_check THEN
        ALTER TABLE compta_esms.pgfp_lignes
            DROP CONSTRAINT pgfp_lignes_section_check;
    END IF;

    IF NOT has_new_check THEN
        ALTER TABLE compta_esms.pgfp_lignes
            ADD CONSTRAINT pgfp_lignes_section_check_v2 CHECK (section IN (
                'crp_consolides',
                'caf',
                'fri',
                'fre',
                'frng',
                'bfr',
                'tresorerie',
                'controles_coherence',
                'donnees_complementaires',
                'ratios'
            ));
    END IF;
END $$;

-- Phase 2 — Partial unique index for PGFP global upsert (cr_id IS NULL).
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_indexes
        WHERE schemaname = 'compta_esms'
          AND indexname = 'uq_pgfp_lignes_doc_key_global'
    ) THEN
        CREATE UNIQUE INDEX uq_pgfp_lignes_doc_key_global
            ON compta_esms.pgfp_lignes (document_id, ligne_key)
            WHERE cr_id IS NULL;
    END IF;
END $$;

COMMENT ON CONSTRAINT pgfp_lignes_section_check_v2 ON compta_esms.pgfp_lignes IS
    '10 sections D-095 (bloc 8 controles_coherence + bloc 9 donnees_complementaires '
    'ajoutés en 011 — omission L1-schema-db.sql initial).';

COMMENT ON INDEX compta_esms.uq_pgfp_lignes_doc_key_global IS
    'UNIQUE partiel pour upsert PGFP global (§9.2 PATCH). cr_id IS NULL '
    'écarte les futures rows CRP_PGFP (D-096, §Y) qui auront cr_id défini.';

-- ============================================================
-- DOWN  (reference only)
-- ============================================================
-- DROP INDEX IF EXISTS compta_esms.uq_pgfp_lignes_doc_key_global;
-- ALTER TABLE compta_esms.pgfp_lignes
--     DROP CONSTRAINT pgfp_lignes_section_check_v2;
-- ALTER TABLE compta_esms.pgfp_lignes
--     ADD CONSTRAINT pgfp_lignes_section_check CHECK (section IN (
--         'crp_consolides', 'caf', 'fri', 'fre', 'frng', 'bfr', 'tresorerie', 'ratios'
--     ));
