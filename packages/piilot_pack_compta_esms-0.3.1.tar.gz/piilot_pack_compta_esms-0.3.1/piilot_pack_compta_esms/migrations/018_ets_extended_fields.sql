-- Migration 018 — Champs ETS étendus pour v0.3 (§BE, D-030).
--
-- v0.2 §D.2 a livré le DDL ETS de base (FINESS, dept, capacités HP, GMP
-- agrégé sur Annexe 5 forfait params). v0.3 enrichit l'entité ETS avec
-- 13 colonnes scalaires natives selon KB 06-data-model §B.2 révisé :
--
-- * Inclusion CPOM (clé pour §BD compute_equilibre_applicable)
-- * Obligation d'équilibre + éligibilité aide sociale
-- * Option tarifaire EHPAD/PUV (3 valeurs DGCS S03 p.25)
-- * GMP/PMP valeurs + dates validation + mode (S03 p.17)
-- * Prix journée moyen + tarification différenciée O/N (S01/S02)
-- * Nombre de chambres individuelles/doubles (S02)
-- * Date autorisation (S01)
--
-- Spec : KB 06-data-model.md §B.2 + 11-decisions.md D-030 (révisé
-- 2026-05-13). Tous champs sont **scalaires natifs** (text / numeric /
-- date) avec allowed values explicites — pas de JSONB (cf. suivi Q5).
--
-- Tous sont Optional côté Pydantic (rétro-compat — les ETS v0.2 ne les
-- ont pas saisis). Les CHECK constraints n'autorisent les NULLs (les
-- valeurs hors-allowed-list sont rejetées, mais NULL est OK).
--
-- ATTENTION GMP/PMP : `compta_esms.annexe5_forfaits_params` a déjà
-- `gmp / pmp / gmps` (saisis par exercice côté Annexe 5). v0.3 ajoute
-- les mêmes valeurs côté `etablissements` comme **donnée master** (au
-- niveau ETS, pas exercice). Le snapshot Annexe 5 reste la source per-
-- exercice (peut diverger volontairement après revalidation médecin).
-- Pas de FK 1:1 — duplication assumée.

-- UP
-- ============================================================

-- Note: ``inclus_cpom`` (boolean), ``soumis_equilibre`` (boolean) et
-- ``date_autorisation`` existent déjà sur ``etablissements`` depuis la
-- migration 002 §D.2. v0.3 les réutilise pour la sémantique D-030.
-- Spec textuelle OUI/NON mappée côté Pydantic vers bool.
ALTER TABLE compta_esms.etablissements
    ADD COLUMN IF NOT EXISTS eligible_aide_sociale       TEXT,
    ADD COLUMN IF NOT EXISTS option_tarifaire            TEXT,
    ADD COLUMN IF NOT EXISTS gmp_valeur                  NUMERIC(8, 4),
    ADD COLUMN IF NOT EXISTS gmp_date_validation         DATE,
    ADD COLUMN IF NOT EXISTS gmp_validation_mode         TEXT,
    ADD COLUMN IF NOT EXISTS pmp_valeur                  NUMERIC(8, 4),
    ADD COLUMN IF NOT EXISTS pmp_date_validation         DATE,
    ADD COLUMN IF NOT EXISTS prix_journee_moyen          NUMERIC(10, 2),
    ADD COLUMN IF NOT EXISTS tarification_differenciee_o_n TEXT,
    ADD COLUMN IF NOT EXISTS nb_chambres_individuelles   INT,
    ADD COLUMN IF NOT EXISTS nb_chambres_doubles         INT;

-- CHECK constraints — allowed values explicites (NULL toléré pour
-- rétro-compat des ETS v0.2). Idempotence : DROP CONSTRAINT IF EXISTS
-- avant chaque ADD.

DO $$
BEGIN
    -- eligible_aide_sociale : OUI / NON
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'etablissements_eligible_aide_sociale_check'
    ) THEN
        ALTER TABLE compta_esms.etablissements
            ADD CONSTRAINT etablissements_eligible_aide_sociale_check
            CHECK (eligible_aide_sociale IS NULL OR eligible_aide_sociale IN ('OUI', 'NON'));
    END IF;

    -- option_tarifaire (EHPAD/PUV uniquement, S03 p.25) :
    --   GMPS_DROIT_COMMUN / FORFAIT_SOINS / CONVENTION_SSIAD_EXT
    -- Pas de gate par typologie au DDL (validation différée Pydantic +
    -- éventuel contrôle §Z).
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'etablissements_option_tarifaire_check'
    ) THEN
        ALTER TABLE compta_esms.etablissements
            ADD CONSTRAINT etablissements_option_tarifaire_check
            CHECK (option_tarifaire IS NULL OR option_tarifaire IN (
                'GMPS_DROIT_COMMUN', 'FORFAIT_SOINS', 'CONVENTION_SSIAD_EXT'
            ));
    END IF;

    -- gmp_validation_mode (S03 p.17) :
    --   MEDECIN_ARS / MEDECIN_CD / MEDECIN_COORDONNATEUR_TACITE
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'etablissements_gmp_validation_mode_check'
    ) THEN
        ALTER TABLE compta_esms.etablissements
            ADD CONSTRAINT etablissements_gmp_validation_mode_check
            CHECK (gmp_validation_mode IS NULL OR gmp_validation_mode IN (
                'MEDECIN_ARS', 'MEDECIN_CD', 'MEDECIN_COORDONNATEUR_TACITE'
            ));
    END IF;

    -- tarification_differenciee_o_n : OUI / NON
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'etablissements_tarif_diff_check'
    ) THEN
        ALTER TABLE compta_esms.etablissements
            ADD CONSTRAINT etablissements_tarif_diff_check
            CHECK (tarification_differenciee_o_n IS NULL OR tarification_differenciee_o_n IN ('OUI', 'NON'));
    END IF;

    -- Garde-fous numériques : valeurs ≥ 0 quand non NULL.
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'etablissements_gmp_valeur_positive'
    ) THEN
        ALTER TABLE compta_esms.etablissements
            ADD CONSTRAINT etablissements_gmp_valeur_positive
            CHECK (gmp_valeur IS NULL OR gmp_valeur >= 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'etablissements_pmp_valeur_positive'
    ) THEN
        ALTER TABLE compta_esms.etablissements
            ADD CONSTRAINT etablissements_pmp_valeur_positive
            CHECK (pmp_valeur IS NULL OR pmp_valeur >= 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'etablissements_prix_journee_positive'
    ) THEN
        ALTER TABLE compta_esms.etablissements
            ADD CONSTRAINT etablissements_prix_journee_positive
            CHECK (prix_journee_moyen IS NULL OR prix_journee_moyen >= 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'etablissements_chambres_indiv_positive'
    ) THEN
        ALTER TABLE compta_esms.etablissements
            ADD CONSTRAINT etablissements_chambres_indiv_positive
            CHECK (nb_chambres_individuelles IS NULL OR nb_chambres_individuelles >= 0);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'etablissements_chambres_doubles_positive'
    ) THEN
        ALTER TABLE compta_esms.etablissements
            ADD CONSTRAINT etablissements_chambres_doubles_positive
            CHECK (nb_chambres_doubles IS NULL OR nb_chambres_doubles >= 0);
    END IF;
END $$;

COMMENT ON COLUMN compta_esms.etablissements.option_tarifaire IS
    'EHPAD/PUV uniquement (S03 p.25). Allowed : GMPS_DROIT_COMMUN, FORFAIT_SOINS, CONVENTION_SSIAD_EXT.';
COMMENT ON COLUMN compta_esms.etablissements.gmp_valeur IS
    'GMP master (donnée ETS). annexe5_forfaits_params.gmp en snapshot per-exercice.';
