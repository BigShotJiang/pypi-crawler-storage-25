-- Migration 016 — Résultats des contrôles intégrés (§Z, D-077→D-081).
--
-- Table de persistance des résultats d'évaluation du catalogue DGCS
-- ~352 contrôles (PLT-43 livré côté core, 117 contrôles seedés v0.2,
-- évolution continue par millésime).
--
-- 1 ligne par (document_id, code) — UNIQUE constraint. Le service
-- `:run` écrase le résultat existant à chaque exécution (UPSERT ON
-- CONFLICT) plutôt que d'historiser : le frontend lit toujours le
-- résultat le plus récent et le cabinet peut re-runner sans dette
-- de stockage. Si historisation requise plus tard, ajouter une
-- table `controles_resultats_history` séparée.
--
-- D-077 — la majorité des contrôles sont warning (soft), 3 seulement
-- sont bloquants à la transition `BROUILLON → TRANSMIS` (D-034).
-- `severite_observee` peut différer de la sévérité catalogue par
-- exemple "warning → na" quand une donnée est manquante.
--
-- KB core source : `com.piilot.core.audit-controls-esms` (PLT-43).

-- UP
-- ============================================================

CREATE TABLE IF NOT EXISTS compta_esms.controles_resultats (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id          UUID NOT NULL,
    document_id         UUID NOT NULL REFERENCES compta_esms.documents_budgetaires(id) ON DELETE CASCADE,
    code                TEXT NOT NULL,
    statut              TEXT NOT NULL CHECK (statut IN ('ok', 'ko', 'na')),
    severite_observee   TEXT NOT NULL CHECK (severite_observee IN ('info', 'warning', 'error')),
    valeurs_observees   JSONB NOT NULL DEFAULT '{}'::jsonb,
    message_humain      TEXT,
    evaluated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (document_id, code)
);

COMMENT ON TABLE compta_esms.controles_resultats IS
    'Résultats des contrôles DGCS appliqués à un document (§Z, D-077). '
    '1 ligne par (document_id, code), écrasée au prochain :run. '
    'statut na = non-évaluable (input manquant ou règle pas câblée v0.2).';

COMMENT ON COLUMN compta_esms.controles_resultats.code IS
    'Code stable du catalogue KB core com.piilot.core.audit-controls-esms '
    '(format C-NNN). Pas de FK PG réelle (table KB dynamique).';
COMMENT ON COLUMN compta_esms.controles_resultats.statut IS
    'ok = contrôle satisfait, ko = anomalie détectée, na = non-évaluable.';
COMMENT ON COLUMN compta_esms.controles_resultats.severite_observee IS
    'Sévérité au moment de l''évaluation (peut différer du catalogue '
    'si downgrade vers warning quand la règle bloquante n''est pas '
    'applicable au type de doc).';
COMMENT ON COLUMN compta_esms.controles_resultats.valeurs_observees IS
    'JSON libre avec les valeurs calculées (montants, écarts, comptes '
    'fautifs). Format dépend du contrôle.';


-- RLS FORCE
ALTER TABLE compta_esms.controles_resultats ENABLE ROW LEVEL SECURITY;
ALTER TABLE compta_esms.controles_resultats FORCE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname = 'compta_esms'
          AND tablename  = 'controles_resultats'
          AND policyname = 'tenant_isolation'
    ) THEN
        CREATE POLICY tenant_isolation ON compta_esms.controles_resultats
            USING (company_id::text = current_setting('app.current_company_id', true))
            WITH CHECK (company_id::text = current_setting('app.current_company_id', true));
    END IF;
END $$;


-- Trigger updated_at (réutilise la fonction commune déclarée en 002).
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger
        WHERE tgname = 'controles_resultats_set_updated_at'
    ) THEN
        CREATE TRIGGER controles_resultats_set_updated_at
            BEFORE UPDATE ON compta_esms.controles_resultats
            FOR EACH ROW
            EXECUTE FUNCTION compta_esms.set_updated_at();
    END IF;
END $$;


-- Index pour les queries fréquentes : list par doc, filter statut/severite.
CREATE INDEX IF NOT EXISTS idx_controles_resultats_doc
    ON compta_esms.controles_resultats (document_id);
CREATE INDEX IF NOT EXISTS idx_controles_resultats_doc_statut
    ON compta_esms.controles_resultats (document_id, statut)
    WHERE statut != 'ok';
CREATE INDEX IF NOT EXISTS idx_controles_resultats_company
    ON compta_esms.controles_resultats (company_id);


-- ============================================================
-- DOWN  (reference only — pas joué par le runner idempotent)
-- ============================================================
-- DROP TABLE IF EXISTS compta_esms.controles_resultats;
