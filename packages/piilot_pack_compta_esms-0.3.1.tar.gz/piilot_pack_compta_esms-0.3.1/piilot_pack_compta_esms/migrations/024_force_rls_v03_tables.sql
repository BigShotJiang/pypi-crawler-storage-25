-- ============================================================
-- Migration: 024_force_rls_v03_tables.sql
-- Plugin: compta_esms — Hotfix sécurité RLS sur les tables v0.3
-- ============================================================
-- Les migrations 019 (CPOM §BA) et 020 (tarifs proposés §BB) ont
-- appliqué ``ENABLE ROW LEVEL SECURITY`` mais oublié le
-- ``FORCE ROW LEVEL SECURITY`` complémentaire (convention plugin
-- v0.2 §D/§Y/§Z/§AB — cf. migrations 015/016/017).
--
-- **Pourquoi c'est critique** : sans ``FORCE``, le owner de la
-- table peut bypasser les policies RLS (PostgreSQL doc :
-- https://www.postgresql.org/docs/current/sql-altertable.html#:~:text=FORCE).
-- En multi-tenant, le rôle de l'app (qui n'est pas le owner) est
-- déjà soumis aux policies via ENABLE, mais si jamais un autre
-- chemin d'accès partage le owner, il bypasse — d'où l'obligation
-- de FORCE pour aligner avec la convention v0.2.
--
-- 4 tables concernées :
--   - compta_esms.esms_cpom        (migration 019, §BA)
--   - compta_esms.cpom_esms_link   (migration 019, §BA)
--   - compta_esms.cpom_objectifs   (migration 019, §BA)
--   - compta_esms.eprd_tarifs_proposes (migration 020, §BB)
--
-- Idempotence : ``ALTER TABLE ... FORCE ROW LEVEL SECURITY`` est
-- intrinsèquement idempotent (no-op si déjà FORCE), donc safe à
-- ré-exécuter.
-- ============================================================

ALTER TABLE compta_esms.esms_cpom            FORCE ROW LEVEL SECURITY;
ALTER TABLE compta_esms.cpom_esms_link       FORCE ROW LEVEL SECURITY;
ALTER TABLE compta_esms.cpom_objectifs       FORCE ROW LEVEL SECURITY;
ALTER TABLE compta_esms.eprd_tarifs_proposes FORCE ROW LEVEL SECURITY;

-- Marqueur d'application pour visibilité côté logs migration runner.
SELECT 'compta_esms RLS FORCE applied to 4 v0.3 tables (hotfix §BA + §BB)' AS marker;
