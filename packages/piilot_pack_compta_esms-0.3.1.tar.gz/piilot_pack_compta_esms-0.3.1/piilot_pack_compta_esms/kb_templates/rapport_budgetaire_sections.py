"""§BI — KB template ``rapport_budgetaire_sections`` (D-033 / D-021).

Source réglementaire : ``R.314-223 CASF`` — rapport budgétaire et
financier obligatoire accompagnant l'EPRD. Structuré par les trames
ARS (S01 / S02).

Modèle de données (cf. ``06-data-model.md:402-418`` BLOC D) :

================  ============  ===================================
Colonne           Type SDK      Note
================  ============  ===================================
document_id       text          UUID stringifié du doc EPRD parent
section_code      text+enum     1 des 9 sections (cf. constants)
contenu_md        text          Markdown libre, plain text v0.3
auteur            text          Identifiant user qui a saisi
date_maj          date          Date dernière modification
================  ============  ===================================

**Pourquoi pas `kb_ref` pour ``document_id``** : la cible
``documents_budgetaires`` est une table métier ``compta_esms.*``, pas
une KB plugin-owned ; ``kb_ref`` ne peut pointer que vers des KBs.

**Pourquoi 1 KB per company plutôt que 1 KB per document** : la
matérialisation par document multiplierait les KBs visibles dans le
catalogue core (encombrement UX). 1 KB unique per company avec une
colonne ``document_id`` filtre est plus économique et reste
queryable via :func:`piilot.sdk.knowledge.find_rows`.

**Auto-matérialisation au create EPRD** : cf. :mod:`services
.rapport_sections_service.materialize_for_document` (appelé dans
``document_service.create_document``).
"""

from __future__ import annotations

from typing import Final

from piilot.sdk.kb_templates import register_kb_template

TEMPLATE_SLUG: Final[str] = "rapport_budgetaire_sections"
"""Slug stable côté catalogue core (préfixé namespace ``compta_esms``
automatiquement par le loader)."""

# 9 codes de section conformes au plan du rapport DOCX (L5d §11-32).
SECTION_CODES: Final[tuple[str, ...]] = (
    "AVANCEMENT_CPOM",
    "OBSERVATIONS_GENERALES",
    "COMPTE_RESULTAT",
    "PREVISIONS_RECETTES",
    "PREVISIONS_DEPENSES",
    "TABLEAU_FINANCEMENT",
    "ANALYSE_FINANCIERE",
    "PGFP",
    "PERSPECTIVES",
)

# Libellés FR humains pour l'UI catalogue (parallèles SECTION_CODES).
SECTION_LABELS_FR: Final[dict[str, str]] = {
    "AVANCEMENT_CPOM": "Avancement CPOM",
    "OBSERVATIONS_GENERALES": "Observations générales",
    "COMPTE_RESULTAT": "Compte de résultat",
    "PREVISIONS_RECETTES": "Prévisions de recettes",
    "PREVISIONS_DEPENSES": "Prévisions de dépenses",
    "TABLEAU_FINANCEMENT": "Tableau de financement",
    "ANALYSE_FINANCIERE": "Analyse financière",
    "PGFP": "PGFP",
    "PERSPECTIVES": "Perspectives",
}


def _template_dict() -> dict[str, object]:
    """Construit le dict KB template pour ``register_kb_template``.

    Schéma validé par :class:`backend.services.kb_templates.types.KBTemplate`
    au drain (post-boot).
    """
    return {
        "slug": TEMPLATE_SLUG,
        "display_name": {
            "fr": "Rapport budgétaire et financier (sections)",
            "en": "Budgetary & financial report (sections)",
        },
        "description": {
            "fr": (
                "Commentaires utilisateur libres par section pour le "
                "rapport DOCX accompagnant l'EPRD (R.314-223). "
                "9 sections types : avancement CPOM, observations, "
                "compte de résultat, prévisions recettes/dépenses, "
                "tableau de financement, analyse financière, PGFP, "
                "perspectives. Auto-matérialisée à la création EPRD."
            ),
            "en": (
                "User-edited comments per section for the DOCX budgetary "
                "and financial report attached to the EPRD (R.314-223). "
                "9 section types. Auto-materialized at EPRD creation."
            ),
        },
        "category": "vertical_esms",
        "tier": 2,
        "icon": "📝",
        "columns": (
            {
                "name": "document_id",
                "label": {
                    "fr": "ID document EPRD",
                    "en": "EPRD document ID",
                },
                "column_type": "text",
                "required": True,
                "description": {
                    "fr": "UUID du document EPRD parent (clé de filtre).",
                    "en": "Parent EPRD document UUID (filter key).",
                },
            },
            {
                "name": "section_code",
                "label": {
                    "fr": "Code section",
                    "en": "Section code",
                },
                "column_type": "text",
                "required": True,
                "enum": SECTION_CODES,
                "description": {
                    "fr": "1 des 9 sections types du rapport budgétaire.",
                    "en": "One of the 9 standard report sections.",
                },
            },
            {
                "name": "contenu_md",
                "label": {
                    "fr": "Contenu (Markdown)",
                    "en": "Content (Markdown)",
                },
                "column_type": "text",
                "required": False,
                "description": {
                    "fr": (
                        "Texte libre injecté tel quel dans le DOCX généré. "
                        "Le rendu Markdown (gras/italique/listes) arrive v0.4."
                    ),
                    "en": (
                        "Free-form text inserted verbatim into the generated "
                        "DOCX. Markdown rendering (bold/italic/lists) v0.4+."
                    ),
                },
            },
            {
                "name": "auteur",
                "label": {
                    "fr": "Auteur",
                    "en": "Author",
                },
                "column_type": "text",
                "required": False,
                "description": {
                    "fr": "Identifiant utilisateur de la dernière modification.",
                    "en": "User identifier of the last modification.",
                },
            },
            {
                "name": "date_maj",
                "label": {
                    "fr": "Date mise à jour",
                    "en": "Last updated",
                },
                "column_type": "date",
                "required": False,
                "description": {
                    "fr": "Date de la dernière modification du contenu.",
                    "en": "Date of the last content modification.",
                },
            },
        ),
        "optional_children": (),
    }


def register_template() -> None:
    """Enregistre le template auprès du SDK (idempotent au boot).

    Appelé depuis :func:`kb_templates.register_all_templates` qui
    elle-même est invoquée dans ``Plugin.register``.
    """
    register_kb_template(_template_dict())


__all__ = [
    "SECTION_CODES",
    "SECTION_LABELS_FR",
    "TEMPLATE_SLUG",
    "register_template",
]
