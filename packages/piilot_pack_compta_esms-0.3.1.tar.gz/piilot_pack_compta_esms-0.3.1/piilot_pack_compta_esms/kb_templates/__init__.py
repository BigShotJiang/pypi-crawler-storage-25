"""§BI — KB templates plugin-shipped (SDK v0.7+).

Templates structurels que le plugin expose au catalogue core via
:func:`piilot.sdk.kb_templates.register_kb_template`. Les templates
sont **purement déclaratifs** — la matérialisation (création de la
table PG `kbs.compta_esms__<slug>__<uuid>`) est faite par le core ou
explicitement par le plugin via :mod:`piilot.sdk.knowledge.create_kb`.

Listés :

* :mod:`rapport_budgetaire_sections` — D-033 / D-021 / R.314-223.
  Commentaires utilisateur libres par section pour le rapport
  budgétaire et financier DOCX accompagnant l'EPRD. 9 sections types.
"""

from __future__ import annotations

from piilot_pack_compta_esms.kb_templates import rapport_budgetaire_sections


def register_all_templates() -> None:
    """Enregistre tous les KB templates du plugin auprès du SDK.

    Appelé une fois au boot depuis ``Plugin.register``. Le SDK bufferise
    les déclarations et le loader core les ingère après le boot.
    """
    rapport_budgetaire_sections.register_template()


__all__ = ["register_all_templates", "rapport_budgetaire_sections"]
