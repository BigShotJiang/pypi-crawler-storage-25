"""§AA — Ratios financiers ERRD (D-091) + PGFP (D-095 bloc 10).

Pattern parallèle au package ``controls/`` (§Z) mais sans persistance :

* 23 ratios catalogués (15 ERRD + 8 PGFP)
* Chacun enregistré via ``@register(ratio_id)`` au boot
* Calcul à la volée via :mod:`ratios_service` — pas de table de
  résultats, juste un GET qui réagrège chaque appel

Pattern identique au §Z (controls) : importer le package déclenche
les ``@register`` side-effects.
"""

from __future__ import annotations

# Importer les sous-modules force l'enregistrement.
from piilot_pack_compta_esms.ratios import (  # noqa: F401
    r_autres,
    r_endettement,
    r_equilibres,
    r_patrimoine,
    r_pgfp,
    r_rotation,
)
