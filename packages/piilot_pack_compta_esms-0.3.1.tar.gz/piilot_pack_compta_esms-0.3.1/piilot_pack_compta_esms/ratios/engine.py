"""Engine §AA — orchestre l'évaluation du catalogue ratios.

Pas de persistance — chaque appel re-calcule. Le service appelant
(``ratios_service``) construit un :class:`RatioContext` et lance
:func:`run_all` (ou :func:`run_filtered`) pour récupérer les résultats.

Pattern aligné §Z (``controls.engine.ControlsEngine``) mais simplifié :
* pas de persistance
* pas de filter par doc_type côté engine (le service décide quels
  ratios sont applicables selon ERRD vs EPRD)
* defensive crash → résultat NA (pas de batch break)
"""

from __future__ import annotations

import logging

from piilot_pack_compta_esms.ratios._base import (
    RATIO_HANDLERS,
    RatioContext,
    RatioResult,
    RatioResultPgfp,
    make_na,
)

logger = logging.getLogger(__name__)


async def run_ids(
    ctx: RatioContext,
    ids: list[str],
) -> list[RatioResult | RatioResultPgfp]:
    """Exécute les handlers pour une liste de ratio ids.

    Un handler qui crash retourne un résultat NA defensive — le batch
    ne tombe pas.
    """
    out: list[RatioResult | RatioResultPgfp] = []
    for ratio_id in ids:
        handler = RATIO_HANDLERS.get(ratio_id)
        if handler is None:
            out.append(
                make_na(
                    id=ratio_id,
                    label=f"Ratio {ratio_id}",
                    unite="decimal",
                    formule_textuelle="(handler non enregistré)",
                    reason="Ratio non implémenté côté plugin.",
                )
            )
            continue
        try:
            result = await handler(ctx)
        except Exception as exc:  # noqa: BLE001 — defensive
            logger.exception("ratios engine: handler %r raised — wrapping NA", ratio_id)
            result = make_na(
                id=ratio_id,
                label=f"Ratio {ratio_id}",
                unite="decimal",
                formule_textuelle="(exception)",
                reason=f"Erreur d'évaluation : {type(exc).__name__}",
            )
        out.append(result)
    return out
