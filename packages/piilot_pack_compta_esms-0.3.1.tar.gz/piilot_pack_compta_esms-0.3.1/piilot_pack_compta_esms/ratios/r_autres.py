"""§AA.5 — Ratios autres (D-091 KB25 §8.5).

3 ratios :

* **5.1 Taux de CAF** : CAF × 100 / Produits classe 7. Seuil **5-10%**.
* **5.2 Taux réserve compensation déficits** : c/10686 ou 115923 /
  Produits. Indicatif.
* **5.3 Taux marge brute** : (c/70-75 - c/60-65) × 100 / Produits.
  Indicatif.
"""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.ratios._base import (
    RatioContext,
    RatioResult,
    get_caf,
    get_compte_total_bilan,
    get_compte_total_crp,
    get_total_produits,
    make_na,
    make_result,
    register,
    safe_div,
    serialize_amount,
)

_HUNDRED = Decimal("100")


# ---------------------------------------------------------------------------
# 5.1 Taux CAF
# ---------------------------------------------------------------------------


@register("5.1")
async def r_5_1(ctx: RatioContext) -> RatioResult:
    """CAF × 100 / Produits classe 7. Seuil 5-10%."""
    caf = await get_caf(ctx, realise=True)
    produits = await get_total_produits(ctx, realise=True)

    if produits == Decimal(0):
        return make_na(
            id="5.1",
            label="Taux de CAF",
            unite="%",
            formule_textuelle="CAF × 100 / Produits c/7",
            seuil_min=Decimal("5"),
            seuil_max=Decimal("10"),
            reason="Produits classe 7 = 0.",
            inputs={"caf": serialize_amount(caf), "produits": 0},
        )

    if caf is None:
        return make_na(
            id="5.1",
            label="Taux de CAF",
            unite="%",
            formule_textuelle="CAF × 100 / Produits c/7",
            seuil_min=Decimal("5"),
            seuil_max=Decimal("10"),
            reason="CAF non calculable (charges/produits non saisis).",
            inputs={"produits": serialize_amount(produits)},
        )

    return make_result(
        id="5.1",
        label="Taux de CAF",
        valeur=safe_div(caf * _HUNDRED, produits),
        unite="%",
        formule_textuelle="CAF × 100 / Produits c/7",
        seuil_min=Decimal("5"),
        seuil_max=Decimal("10"),
        inputs={"caf": serialize_amount(caf), "produits": serialize_amount(produits)},
    )


# ---------------------------------------------------------------------------
# 5.2 Taux réserve compensation déficits
# ---------------------------------------------------------------------------


@register("5.2")
async def r_5_2(ctx: RatioContext) -> RatioResult:
    """(c/10686 + c/115923) / Produits classe 7 × 100. Indicatif."""
    reserve = await get_compte_total_bilan(ctx, "10686", field="net_n")
    reserve += await get_compte_total_bilan(ctx, "115923", field="net_n")
    produits = await get_total_produits(ctx, realise=True)

    if produits == Decimal(0):
        return make_na(
            id="5.2",
            label="Taux réserve compensation déficits",
            unite="%",
            formule_textuelle="(c/10686 + c/115923) × 100 / Produits c/7",
            reason="Produits classe 7 = 0.",
            inputs={"reserve": serialize_amount(reserve)},
        )

    return make_result(
        id="5.2",
        label="Taux réserve compensation déficits",
        valeur=safe_div(reserve * _HUNDRED, produits),
        unite="%",
        formule_textuelle="(c/10686 + c/115923) × 100 / Produits c/7",
        inputs={
            "reserve": serialize_amount(reserve),
            "produits": serialize_amount(produits),
        },
    )


# ---------------------------------------------------------------------------
# 5.3 Taux marge brute
# ---------------------------------------------------------------------------


@register("5.3")
async def r_5_3(ctx: RatioContext) -> RatioResult:
    """(Produits c/70-75 − Charges c/60-65) × 100 / Produits c/7.

    KB25 §8.5 formule : marge brute opérationnelle (hors flux internes
    c/68 amortissements, c/675 VNC). Indicatif."""
    # Produits c/70..75 (exclu c/76+ produits financiers/exceptionnels)
    produits_op = Decimal(0)
    for prefix in ("70", "71", "72", "73", "74", "75"):
        produits_op += await get_compte_total_crp(ctx, prefix, field="produits_realise")

    # Charges c/60..65 (exclu c/66+ charges financières, c/68 dotations)
    charges_op = Decimal(0)
    for prefix in ("60", "61", "62", "63", "64", "65"):
        charges_op += await get_compte_total_crp(ctx, prefix, field="charges_realise")

    produits_total = await get_total_produits(ctx, realise=True)
    if produits_total == Decimal(0):
        return make_na(
            id="5.3",
            label="Taux marge brute",
            unite="%",
            formule_textuelle="(Produits c/70-75 − Charges c/60-65) × 100 / Produits c/7",
            reason="Produits classe 7 = 0.",
            inputs={
                "produits_op": serialize_amount(produits_op),
                "charges_op": serialize_amount(charges_op),
            },
        )

    marge = produits_op - charges_op
    return make_result(
        id="5.3",
        label="Taux marge brute",
        valeur=safe_div(marge * _HUNDRED, produits_total),
        unite="%",
        formule_textuelle="(Produits c/70-75 − Charges c/60-65) × 100 / Produits c/7",
        inputs={
            "produits_op": serialize_amount(produits_op),
            "charges_op": serialize_amount(charges_op),
            "marge_brute": serialize_amount(marge),
            "produits_total": serialize_amount(produits_total),
        },
    )
