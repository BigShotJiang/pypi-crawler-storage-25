"""§AA.3 — Ratios équilibres bilan en jours (D-091 KB25 §8.3).

4 ratios indicatifs (pas de seuil DGCS dur — c'est l'évolution qui est
suivie sur plusieurs exercices) :

* **3.1.a FRI/FRE/FRNG en jours d'exploitation** : (FRNG × 365) / Charges
  décaissables
* **3.1.b BFR en jours** : (BFR × 365) / Charges décaissables
* **3.1.c Trésorerie en jours** : (Trésorerie × 365) / Charges décaissables
* **3.2 Réserve couverture BFR** : (c/141 + c/10685) × 365 / Charges
  décaissables
"""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.ratios._base import (
    RatioContext,
    RatioResult,
    get_compte_total_bilan,
    get_total_charges_decaissables,
    make_na,
    make_result,
    register,
    safe_div,
    serialize_amount,
)

_365 = Decimal("365")


async def _compute_frng_bilan(ctx: RatioContext) -> Decimal:
    """FRNG = FRI + FRE — approximation v0.2 via les soldes Bilan.

    FRI = capitaux propres long terme + dettes long terme - immobilisations.
    Approximation : c/1 (capitaux + emprunts) - c/2 (immobilisations).
    """
    capitaux_dettes = await get_compte_total_bilan(ctx, "1", field="net_n")
    immobilisations = await get_compte_total_bilan(ctx, "2", field="net_n")
    return capitaux_dettes - immobilisations


async def _compute_bfr_bilan(ctx: RatioContext) -> Decimal:
    """BFR = Stocks + Créances - Dettes exploitation.

    Approximation : c/3 (stocks) + c/4 actif (créances c/41, c/42, etc.)
    - c/4 passif (dettes c/40, c/43, c/44).
    """
    stocks = await get_compte_total_bilan(ctx, "3", field="net_n")
    creances = await get_compte_total_bilan(ctx, "41", field="net_n")
    creances += await get_compte_total_bilan(ctx, "42", field="net_n")
    dettes_expl = await get_compte_total_bilan(ctx, "401", field="net_n")
    dettes_expl += await get_compte_total_bilan(ctx, "43", field="net_n")
    dettes_expl += await get_compte_total_bilan(ctx, "44", field="net_n")
    return stocks + creances - dettes_expl


# ---------------------------------------------------------------------------
# 3.1.a FRNG en jours
# ---------------------------------------------------------------------------


@register("3.1.a")
async def r_3_1_a(ctx: RatioContext) -> RatioResult:
    """FRNG en jours d'exploitation."""
    frng = await _compute_frng_bilan(ctx)
    charges = await get_total_charges_decaissables(ctx, realise=True)
    if charges == Decimal(0):
        return make_na(
            id="3.1.a",
            label="FRNG en jours d'exploitation",
            unite="jours",
            formule_textuelle="FRNG × 365 / Charges décaissables",
            reason="Charges décaissables = 0.",
            inputs={"frng": serialize_amount(frng), "charges_decaissables": 0},
        )
    return make_result(
        id="3.1.a",
        label="FRNG en jours d'exploitation",
        valeur=safe_div(frng * _365, charges),
        unite="jours",
        formule_textuelle="FRNG × 365 / Charges décaissables",
        inputs={
            "frng": serialize_amount(frng),
            "charges_decaissables": serialize_amount(charges),
        },
    )


# ---------------------------------------------------------------------------
# 3.1.b BFR en jours
# ---------------------------------------------------------------------------


@register("3.1.b")
async def r_3_1_b(ctx: RatioContext) -> RatioResult:
    """BFR en jours d'exploitation."""
    bfr = await _compute_bfr_bilan(ctx)
    charges = await get_total_charges_decaissables(ctx, realise=True)
    if charges == Decimal(0):
        return make_na(
            id="3.1.b",
            label="BFR en jours",
            unite="jours",
            formule_textuelle="BFR × 365 / Charges décaissables",
            reason="Charges décaissables = 0.",
            inputs={"bfr": serialize_amount(bfr)},
        )
    return make_result(
        id="3.1.b",
        label="BFR en jours",
        valeur=safe_div(bfr * _365, charges),
        unite="jours",
        formule_textuelle="BFR × 365 / Charges décaissables",
        inputs={
            "bfr": serialize_amount(bfr),
            "charges_decaissables": serialize_amount(charges),
        },
    )


# ---------------------------------------------------------------------------
# 3.1.c Trésorerie en jours
# ---------------------------------------------------------------------------


@register("3.1.c")
async def r_3_1_c(ctx: RatioContext) -> RatioResult:
    """Trésorerie en jours d'exploitation. Trésorerie = FRNG - BFR."""
    frng = await _compute_frng_bilan(ctx)
    bfr = await _compute_bfr_bilan(ctx)
    tresorerie = frng - bfr
    charges = await get_total_charges_decaissables(ctx, realise=True)
    if charges == Decimal(0):
        return make_na(
            id="3.1.c",
            label="Trésorerie en jours",
            unite="jours",
            formule_textuelle="Trésorerie × 365 / Charges décaissables",
            reason="Charges décaissables = 0.",
            inputs={"tresorerie": serialize_amount(tresorerie)},
        )
    return make_result(
        id="3.1.c",
        label="Trésorerie en jours",
        valeur=safe_div(tresorerie * _365, charges),
        unite="jours",
        formule_textuelle="Trésorerie × 365 / Charges décaissables",
        inputs={
            "tresorerie": serialize_amount(tresorerie),
            "frng": serialize_amount(frng),
            "bfr": serialize_amount(bfr),
            "charges_decaissables": serialize_amount(charges),
        },
    )


# ---------------------------------------------------------------------------
# 3.2 Réserve couverture BFR
# ---------------------------------------------------------------------------


@register("3.2")
async def r_3_2(ctx: RatioContext) -> RatioResult:
    """Réserve couverture BFR : (c/141 + c/10685) × 365 / Charges
    décaissables. KB25 §8.3 — réserve dédiée à la couverture du BFR
    (compte 10685 ou 141 selon plan)."""
    reserve = await get_compte_total_bilan(ctx, "141", field="net_n")
    reserve += await get_compte_total_bilan(ctx, "10685", field="net_n")
    charges = await get_total_charges_decaissables(ctx, realise=True)
    if charges == Decimal(0):
        return make_na(
            id="3.2",
            label="Réserve couverture BFR",
            unite="jours",
            formule_textuelle="(c/141 + c/10685) × 365 / Charges décaissables",
            reason="Charges décaissables = 0.",
            inputs={"reserve": serialize_amount(reserve)},
        )
    return make_result(
        id="3.2",
        label="Réserve couverture BFR",
        valeur=safe_div(reserve * _365, charges),
        unite="jours",
        formule_textuelle="(c/141 + c/10685) × 365 / Charges décaissables",
        inputs={
            "reserve": serialize_amount(reserve),
            "charges_decaissables": serialize_amount(charges),
        },
    )
