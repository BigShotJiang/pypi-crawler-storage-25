"""§AA.4 — Ratios rotation postes exploitation (D-091 KB25 §8.4).

4 ratios :

* **4.1 Stocks** : (Stocks débiteur c/3) × 365 / Achats. Seuil **10-20 jours**.
* **4.2 Créances** : (c/41 débiteur) × 365 / Produits. Seuil **< 30 jours**.
* **4.3 Dettes fournisseurs** : (c/401 créditeur) × 365 / Charges. Seuil
  **< 45 jours**.
* **4.4 Dettes sociales/fiscales** : (c/43+44 créditeur) × 365 / Charges.
  Indicatif (pas de seuil).
"""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.ratios._base import (
    RatioContext,
    RatioResult,
    get_compte_total_bilan,
    get_compte_total_crp,
    make_na,
    make_result,
    register,
    safe_div,
    serialize_amount,
)

_365 = Decimal("365")


# ---------------------------------------------------------------------------
# 4.1 Stocks (j)
# ---------------------------------------------------------------------------


@register("4.1")
async def r_4_1(ctx: RatioContext) -> RatioResult:
    """Rotation des stocks en jours. Seuil 10-20 jours."""
    stocks = await get_compte_total_bilan(ctx, "3", field="net_n")
    achats = await get_compte_total_crp(ctx, "60", field="charges_realise")
    if achats == Decimal(0):
        return make_na(
            id="4.1",
            label="Rotation stocks",
            unite="jours",
            formule_textuelle="Stocks c/3 × 365 / Achats c/60",
            seuil_min=Decimal("10"),
            seuil_max=Decimal("20"),
            reason="Achats c/60 = 0 — pas de mouvements stockables.",
            inputs={"stocks": serialize_amount(stocks)},
        )
    return make_result(
        id="4.1",
        label="Rotation stocks",
        valeur=safe_div(stocks * _365, achats),
        unite="jours",
        formule_textuelle="Stocks c/3 × 365 / Achats c/60",
        seuil_min=Decimal("10"),
        seuil_max=Decimal("20"),
        inputs={"stocks": serialize_amount(stocks), "achats": serialize_amount(achats)},
    )


# ---------------------------------------------------------------------------
# 4.2 Créances clients (j)
# ---------------------------------------------------------------------------


@register("4.2")
async def r_4_2(ctx: RatioContext) -> RatioResult:
    """Rotation créances en jours. Seuil < 30 jours."""
    creances = await get_compte_total_bilan(ctx, "41", field="net_n")
    produits = await get_compte_total_crp(ctx, "7", field="produits_realise")
    if produits == Decimal(0):
        return make_na(
            id="4.2",
            label="Rotation créances clients",
            unite="jours",
            formule_textuelle="Créances c/41 × 365 / Produits c/7",
            seuil_max=Decimal("30"),
            reason="Produits c/7 = 0.",
            inputs={"creances": serialize_amount(creances)},
        )
    return make_result(
        id="4.2",
        label="Rotation créances clients",
        valeur=safe_div(creances * _365, produits),
        unite="jours",
        formule_textuelle="Créances c/41 × 365 / Produits c/7",
        seuil_max=Decimal("30"),
        inputs={
            "creances": serialize_amount(creances),
            "produits": serialize_amount(produits),
        },
    )


# ---------------------------------------------------------------------------
# 4.3 Dettes fournisseurs (j)
# ---------------------------------------------------------------------------


@register("4.3")
async def r_4_3(ctx: RatioContext) -> RatioResult:
    """Rotation dettes fournisseurs en jours. Seuil < 45 jours."""
    dettes = await get_compte_total_bilan(ctx, "401", field="net_n")
    charges = await get_compte_total_crp(ctx, "6", field="charges_realise")
    if charges == Decimal(0):
        return make_na(
            id="4.3",
            label="Rotation dettes fournisseurs",
            unite="jours",
            formule_textuelle="Dettes c/401 × 365 / Charges c/6",
            seuil_max=Decimal("45"),
            reason="Charges c/6 = 0.",
            inputs={"dettes": serialize_amount(dettes)},
        )
    return make_result(
        id="4.3",
        label="Rotation dettes fournisseurs",
        valeur=safe_div(dettes * _365, charges),
        unite="jours",
        formule_textuelle="Dettes c/401 × 365 / Charges c/6",
        seuil_max=Decimal("45"),
        inputs={
            "dettes": serialize_amount(dettes),
            "charges": serialize_amount(charges),
        },
    )


# ---------------------------------------------------------------------------
# 4.4 Dettes sociales/fiscales (j)
# ---------------------------------------------------------------------------


@register("4.4")
async def r_4_4(ctx: RatioContext) -> RatioResult:
    """Rotation dettes sociales/fiscales en jours. Indicatif."""
    dettes_soc = await get_compte_total_bilan(ctx, "43", field="net_n")
    dettes_soc += await get_compte_total_bilan(ctx, "44", field="net_n")
    charges = await get_compte_total_crp(ctx, "6", field="charges_realise")
    if charges == Decimal(0):
        return make_na(
            id="4.4",
            label="Rotation dettes sociales/fiscales",
            unite="jours",
            formule_textuelle="(c/43 + c/44) × 365 / Charges c/6",
            reason="Charges c/6 = 0.",
            inputs={"dettes_sociales": serialize_amount(dettes_soc)},
        )
    return make_result(
        id="4.4",
        label="Rotation dettes sociales/fiscales",
        valeur=safe_div(dettes_soc * _365, charges),
        unite="jours",
        formule_textuelle="(c/43 + c/44) × 365 / Charges c/6",
        inputs={
            "dettes_sociales": serialize_amount(dettes_soc),
            "charges": serialize_amount(charges),
        },
    )
