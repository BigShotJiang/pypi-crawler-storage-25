"""§AA.1 — Ratios endettement (D-091 KB25 §8.1).

3 ratios :

* **1.1 Indépendance financière** : Emprunts (c/16 hors 165/1688/169) /
  Financements stables FRI. **Seuil < 50%**.
* **1.2 Apurement de la dette** : Immobilisations nettes amortissables
  (c/21 net) / Dettes financières. **Seuil > 2**.
* **1.3 Durée apparente de la dette** : Emprunts / CAF (années).
  Indicatif (pas de seuil).
"""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.ratios._base import (
    RatioContext,
    RatioResult,
    get_caf,
    get_compte_total_bilan,
    make_na,
    make_result,
    register,
    safe_div,
    serialize_amount,
)

_HUNDRED = Decimal("100")


# ---------------------------------------------------------------------------
# 1.1 Indépendance financière
# ---------------------------------------------------------------------------


@register("1.1")
async def r_1_1(ctx: RatioContext) -> RatioResult:
    """Emprunts (c/16 hors 165/1688/169) / Financements stables FRI × 100.

    Source DGCS KB25 §8.1. FRI = somme des financements stables passifs
    (capital, réserves, subventions investissement non amorties,
    emprunts à long terme). Pour v0.2 on approxime via le bilan passif
    section ``fri`` si disponible, sinon par le solde des comptes
    c/10-19 (financements propres + emprunts)."""
    emprunts = await get_compte_total_bilan(
        ctx, "16", exclude=("165", "1688", "169"), field="net_n"
    )
    fri = await get_compte_total_bilan(ctx, "1", field="net_n")  # large approximation
    # Plus précis : exclure les comptes non-FRI (résultats N c/12, c/11).
    excl = await get_compte_total_bilan(ctx, "11", field="net_n")
    excl += await get_compte_total_bilan(ctx, "12", field="net_n")
    fri = fri - excl

    if fri == Decimal(0):
        return make_na(
            id="1.1",
            label="Indépendance financière",
            unite="%",
            formule_textuelle="Emprunts (c/16 hors 165/1688/169) / FRI × 100",
            seuil_max=Decimal("50"),
            reason="FRI = 0 — aucun financement stable saisi au Bilan.",
            inputs={"emprunts": serialize_amount(emprunts), "fri": serialize_amount(fri)},
        )

    ratio = safe_div(emprunts * _HUNDRED, fri)
    return make_result(
        id="1.1",
        label="Indépendance financière",
        valeur=ratio,
        unite="%",
        formule_textuelle="Emprunts (c/16 hors 165/1688/169) / FRI × 100",
        seuil_max=Decimal("50"),
        inputs={
            "emprunts": serialize_amount(emprunts),
            "fri": serialize_amount(fri),
        },
    )


# ---------------------------------------------------------------------------
# 1.2 Apurement de la dette
# ---------------------------------------------------------------------------


@register("1.2")
async def r_1_2(ctx: RatioContext) -> RatioResult:
    """Immobilisations nettes amortissables (c/21 net) / Dettes financières.

    Plus le ratio est élevé, mieux la dette est couverte par le
    patrimoine. Seuil > 2 (DGCS)."""
    immo_net = await get_compte_total_bilan(ctx, "21", field="net_n")
    dettes_fin = await get_compte_total_bilan(
        ctx, "16", exclude=("165", "1688", "169"), field="net_n"
    )

    if dettes_fin == Decimal(0):
        return make_na(
            id="1.2",
            label="Apurement de la dette",
            unite="x",
            formule_textuelle="Immobilisations nettes c/21 / Dettes financières c/16",
            seuil_min=Decimal("2"),
            reason="Dettes financières = 0 — pas d'emprunts saisis.",
            inputs={
                "immo_net": serialize_amount(immo_net),
                "dettes_fin": serialize_amount(dettes_fin),
            },
        )

    ratio = safe_div(immo_net, dettes_fin)
    return make_result(
        id="1.2",
        label="Apurement de la dette",
        valeur=ratio,
        unite="x",
        formule_textuelle="Immobilisations nettes c/21 / Dettes financières c/16",
        seuil_min=Decimal("2"),
        inputs={
            "immo_net": serialize_amount(immo_net),
            "dettes_fin": serialize_amount(dettes_fin),
        },
    )


# ---------------------------------------------------------------------------
# 1.3 Durée apparente de la dette
# ---------------------------------------------------------------------------


@register("1.3")
async def r_1_3(ctx: RatioContext) -> RatioResult:
    """Emprunts / CAF — exprimé en années. Indicatif (pas de seuil)."""
    emprunts = await get_compte_total_bilan(
        ctx, "16", exclude=("165", "1688", "169"), field="net_n"
    )
    caf = await get_caf(ctx, realise=True)

    if caf is None or caf <= Decimal(0):
        return make_na(
            id="1.3",
            label="Durée apparente de la dette",
            unite="annees",
            formule_textuelle="Emprunts / CAF",
            reason="CAF nulle ou négative — durée non calculable.",
            inputs={
                "emprunts": serialize_amount(emprunts),
                "caf": serialize_amount(caf),
            },
        )

    return make_result(
        id="1.3",
        label="Durée apparente de la dette",
        valeur=safe_div(emprunts, caf),
        unite="annees",
        formule_textuelle="Emprunts / CAF",
        inputs={
            "emprunts": serialize_amount(emprunts),
            "caf": serialize_amount(caf),
        },
    )
