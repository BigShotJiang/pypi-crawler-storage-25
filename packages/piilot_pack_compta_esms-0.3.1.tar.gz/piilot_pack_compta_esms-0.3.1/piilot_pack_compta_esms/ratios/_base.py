"""Types + registry + helpers communs au catalogue de ratios §AA.

Pattern :

* :class:`RatioContext` — état partagé entre tous les ratios d'un GET.
  Lazy loaders : bilan/crp/emprunts/PGFP/charges_décaissables.
  Mémoization via ``custom`` dict pour partager entre handlers d'un
  même run sans re-charger.
* :class:`RatioResult` — DTO sortant. Inclut formule_textuelle pour
  permettre au frontend d'afficher "comment c'est calculé" en tooltip.
* :class:`RatioResultPgfp` — variante PGFP par exercice (8 colonnes
  N-1 → N+6).
* :func:`register` — décorateur d'enregistrement.

Pas de persistance — chaque ``GET /ratios`` recharge la donnée fraîche.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Literal
from uuid import UUID

from piilot.sdk.db import run_in_thread
from pydantic import BaseModel, ConfigDict, Field

logger = logging.getLogger(__name__)

Verdict = Literal["ok", "atypie", "na"]
"""``ok`` = dans seuil ou ratio indicatif évaluable.
``atypie`` = hors seuil DGCS (signal de vigilance, jamais bloquant).
``na`` = inputs manquants, ratio non-évaluable."""

Unite = Literal["%", "jours", "x", "annees", "decimal"]


# ---------------------------------------------------------------------------
# RatioResult — DTO simple
# ---------------------------------------------------------------------------


class RatioResult(BaseModel):
    """Résultat d'un ratio ERRD (1 valeur sur l'exercice N).

    Le service orchestrateur ajoute ``id`` et ``label`` depuis le
    catalogue avant retour — chaque handler renseigne le payload
    métier (valeur + verdict + inputs)."""

    model_config = ConfigDict(extra="forbid")

    id: str
    label: str
    valeur: Decimal | None
    unite: Unite
    seuil_min: Decimal | None = None
    seuil_max: Decimal | None = None
    verdict: Verdict
    formule_textuelle: str
    inputs: dict[str, Any] = Field(default_factory=dict)
    message: str | None = None


class RatioPgfpExerciceValue(BaseModel):
    """1 cellule du nested PGFP — valeur d'un ratio sur 1 exercice."""

    model_config = ConfigDict(extra="forbid")

    annee_offset: int = Field(..., ge=-1, le=6)
    """-1 = N-1, 0 = N, 1 → 6 = N+1 à N+6."""
    valeur: Decimal | None
    verdict: Verdict


class RatioResultPgfp(BaseModel):
    """Résultat d'un ratio PGFP — 8 cellules (N-1 → N+6).

    D-095 bloc 10 ligne 135-142 = 8 ratios prévisionnels appliqués
    aux 8 exercices PGFP."""

    model_config = ConfigDict(extra="forbid")

    id: str
    label: str
    unite: Unite
    seuil_min: Decimal | None = None
    seuil_max: Decimal | None = None
    formule_textuelle: str
    par_exercice: list[RatioPgfpExerciceValue]


# ---------------------------------------------------------------------------
# RatioContext — partagé entre handlers d'un :run
# ---------------------------------------------------------------------------


@dataclass
class RatioContext:
    """État de chargement lazy partagé entre tous les ratios d'un GET.

    Le service appelant fournit ``document`` (déjà chargé pour validation
    tenant). Les autres champs sont chargés à la demande via les helpers
    `load_*` (1 SELECT par section, mémoïsé dans ``custom``).
    """

    document_id: UUID
    company_id: UUID
    document: dict[str, Any]
    # Cache mémoire — accessible depuis les handlers, clés libres.
    custom: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Registry — décorateur + lookup
# ---------------------------------------------------------------------------


# Async handler — signature `(ctx) → RatioResult | RatioResultPgfp`.
RatioHandler = Callable[[RatioContext], Awaitable[RatioResult | RatioResultPgfp]]

RATIO_HANDLERS: dict[str, RatioHandler] = {}
"""Registry global. Clé = id ratio (ex: ``"1.1"`` / ``"pgfp.endettement"``)."""


def register(ratio_id: str) -> Callable[[RatioHandler], RatioHandler]:
    """Décorateur — enregistre ``handler`` sous ``ratio_id``."""

    def _wrapper(handler: RatioHandler) -> RatioHandler:
        if ratio_id in RATIO_HANDLERS:
            raise RuntimeError(
                f"ratio handler {ratio_id!r} already registered "
                f"(double @register dans le catalogue ratios)"
            )
        RATIO_HANDLERS[ratio_id] = handler
        return handler

    return _wrapper


def list_registered_ids() -> list[str]:
    """Retourne les ids enregistrés (helper tests)."""
    return sorted(RATIO_HANDLERS)


# ---------------------------------------------------------------------------
# Helpers de verdict + résultat
# ---------------------------------------------------------------------------


def _verdict_from_thresholds(
    valeur: Decimal,
    *,
    seuil_min: Decimal | None,
    seuil_max: Decimal | None,
) -> Verdict:
    """Verdict si seuil(s) défini(s). Hors seuil → ``atypie``."""
    if seuil_min is not None and valeur < seuil_min:
        return "atypie"
    if seuil_max is not None and valeur > seuil_max:
        return "atypie"
    return "ok"


def make_result(
    *,
    id: str,
    label: str,
    valeur: Decimal | None,
    unite: Unite,
    formule_textuelle: str,
    seuil_min: Decimal | None = None,
    seuil_max: Decimal | None = None,
    inputs: dict[str, Any] | None = None,
    message: str | None = None,
) -> RatioResult:
    """Factory — calcule le verdict automatiquement à partir des seuils."""
    if valeur is None:
        verdict: Verdict = "na"
    else:
        verdict = _verdict_from_thresholds(valeur, seuil_min=seuil_min, seuil_max=seuil_max)
    return RatioResult(
        id=id,
        label=label,
        valeur=valeur,
        unite=unite,
        seuil_min=seuil_min,
        seuil_max=seuil_max,
        verdict=verdict,
        formule_textuelle=formule_textuelle,
        inputs=inputs or {},
        message=message,
    )


def make_na(
    *,
    id: str,
    label: str,
    unite: Unite,
    formule_textuelle: str,
    seuil_min: Decimal | None = None,
    seuil_max: Decimal | None = None,
    reason: str,
    inputs: dict[str, Any] | None = None,
) -> RatioResult:
    """Factory pour ratio non-évaluable (inputs manquants)."""
    return RatioResult(
        id=id,
        label=label,
        valeur=None,
        unite=unite,
        seuil_min=seuil_min,
        seuil_max=seuil_max,
        verdict="na",
        formule_textuelle=formule_textuelle,
        inputs=inputs or {},
        message=reason,
    )


# ---------------------------------------------------------------------------
# RatioContext — lazy loaders
# ---------------------------------------------------------------------------


async def _load_bilan_montants(ctx: RatioContext) -> dict[str, dict[str, Decimal]]:
    """Charge le Bilan financier et indexe par compte_m22bis.

    Retourne ``{compte: {"brut_n": Decimal, "amort_n": Decimal, "net_n":
    Decimal, "net_n1": Decimal, "type_actif_passif": "actif" | "passif" | None}}``.

    Mémoïsé sous ``ctx.custom["bilan_index"]``.
    """
    if "bilan_index" in ctx.custom:
        return ctx.custom["bilan_index"]

    from piilot_pack_compta_esms.repositories import bilan_repo

    rows = await run_in_thread(bilan_repo.list_by_document, ctx.document_id, type_bilan="financier")
    index: dict[str, dict[str, Decimal]] = {}
    for r in rows:
        compte = (r.get("compte_m22bis") or "").strip()
        if not compte:
            continue
        index[compte] = {
            "brut_n": Decimal(r.get("montant_brut_n") or 0),
            "amort_n": Decimal(r.get("montant_amort_n") or 0),
            "net_n": Decimal(r.get("montant_net_n") or 0),
            "net_n1": Decimal(r.get("montant_net_n1") or 0),
            "type_actif_passif": r.get("type_actif_passif"),
        }
    ctx.custom["bilan_index"] = index
    return index


async def _load_crp_totals_by_account(ctx: RatioContext) -> dict[str, dict[str, Decimal]]:
    """Agrège ``crp_lignes`` par ``compte_m22bis`` sur le document.

    Retourne ``{compte: {"charges_realise": Decimal, "produits_realise":
    Decimal, "charges_prevu": Decimal, "produits_prevu": Decimal}}``.

    Mémoïsé sous ``ctx.custom["crp_by_account"]``.
    """
    if "crp_by_account" in ctx.custom:
        return ctx.custom["crp_by_account"]

    from piilot_pack_compta_esms.repositories import cr_repo, crp_ligne_repo

    crs = await run_in_thread(cr_repo.list_by_document, ctx.document_id)
    index: dict[str, dict[str, Decimal]] = {}
    for cr in crs:
        lignes = await run_in_thread(crp_ligne_repo.list_by_cr, cr["id"], groupe=None, nature=None)
        for ligne in lignes:
            compte = (ligne.get("compte_m22bis") or "").strip()
            if not compte:
                continue
            entry = index.setdefault(
                compte,
                {
                    "charges_realise": Decimal(0),
                    "produits_realise": Decimal(0),
                    "charges_prevu": Decimal(0),
                    "produits_prevu": Decimal(0),
                },
            )
            realise = Decimal(ligne.get("montant_realise") or 0)
            prevu = Decimal(ligne.get("montant_previsions_totales") or 0)
            if ligne.get("nature") == "charge":
                entry["charges_realise"] += realise
                entry["charges_prevu"] += prevu
            elif ligne.get("nature") == "produit":
                entry["produits_realise"] += realise
                entry["produits_prevu"] += prevu

    ctx.custom["crp_by_account"] = index
    return index


async def _load_emprunts_totals(ctx: RatioContext) -> dict[str, Decimal]:
    """Charge les emprunts/dettes du doc et agrège.

    Retourne ``{"capital_emprunte": Decimal, "capital_rembourse_n":
    Decimal, "capital_rembourse_n1": Decimal, "capital_restant_du":
    Decimal}``. Mémoïsé."""
    if "emprunts_totals" in ctx.custom:
        return ctx.custom["emprunts_totals"]

    from piilot_pack_compta_esms.repositories import emprunts_repo

    rows = await run_in_thread(emprunts_repo.list_by_document, ctx.document_id)
    totals = {
        "capital_emprunte": Decimal(0),
        "capital_rembourse_n": Decimal(0),
        "capital_rembourse_n1": Decimal(0),
    }
    for r in rows:
        totals["capital_emprunte"] += Decimal(r.get("capital_emprunte") or 0)
        totals["capital_rembourse_n"] += Decimal(r.get("capital_rembourse_n") or 0)
        totals["capital_rembourse_n1"] += Decimal(r.get("capital_rembourse_n1") or 0)
    ctx.custom["emprunts_totals"] = totals
    return totals


async def _load_pgfp_index(ctx: RatioContext) -> dict[tuple[str, str], dict[str, Any]]:
    """Charge les lignes PGFP et indexe par (section, ligne_key).

    Mémoïsé sous ``ctx.custom["pgfp_index"]``.
    """
    if "pgfp_index" in ctx.custom:
        return ctx.custom["pgfp_index"]

    from piilot_pack_compta_esms.repositories import pgfp_repo

    rows = await run_in_thread(pgfp_repo.list_by_document, ctx.document_id)
    index: dict[tuple[str, str], dict[str, Any]] = {}
    for r in rows:
        key = (r.get("section"), r.get("ligne_key"))
        index[key] = r
    ctx.custom["pgfp_index"] = index
    return index


# ---------------------------------------------------------------------------
# RatioContext convenience methods (helpers métier)
# ---------------------------------------------------------------------------


async def get_compte_total_bilan(
    ctx: RatioContext,
    prefix: str,
    *,
    field: str = "net_n",
    exclude: tuple[str, ...] = (),
) -> Decimal:
    """Σ des montants Bilan pour les comptes commençant par ``prefix`` —
    exclusions spécifiques optionnelles.

    Exemple D-091 §8.1 ratio 1.1 : ``c/16 hors c/165, c/1688, c/169``
    → ``get_compte_total_bilan(ctx, "16", exclude=("165", "1688", "169"))``.
    """
    bilan = await _load_bilan_montants(ctx)
    total = Decimal(0)
    for compte, montants in bilan.items():
        if not compte.startswith(prefix):
            continue
        if any(compte.startswith(ex) for ex in exclude):
            continue
        total += montants.get(field, Decimal(0))
    return total


async def get_compte_total_crp(
    ctx: RatioContext,
    prefix: str,
    *,
    field: str = "charges_realise",
    exclude: tuple[str, ...] = (),
) -> Decimal:
    """Σ des montants CRP pour les comptes commençant par ``prefix``.

    ``field`` ∈ ``{charges_realise, produits_realise, charges_prevu,
    produits_prevu}``."""
    crp = await _load_crp_totals_by_account(ctx)
    total = Decimal(0)
    for compte, montants in crp.items():
        if not compte.startswith(prefix):
            continue
        if any(compte.startswith(ex) for ex in exclude):
            continue
        total += montants.get(field, Decimal(0))
    return total


async def get_total_produits(ctx: RatioContext, *, realise: bool = True) -> Decimal:
    """Σ produits classe 7 (réalisé ou prévu)."""
    field = "produits_realise" if realise else "produits_prevu"
    return await get_compte_total_crp(ctx, "7", field=field)


async def get_total_charges_decaissables(ctx: RatioContext, *, realise: bool = True) -> Decimal:
    """Charges décaissables = Σ classe 6 − dotations c/68 − reprises/non-
    décaissables.

    D-091 §8.3 dénominateur — convention de place. Non-décaissables
    exclus : c/68 (dotations amortissements/provisions), c/675 (VNC
    immo cédées), c/689 (reports fonds dédiés).
    """
    field = "charges_realise" if realise else "charges_prevu"
    total_classe_6 = await get_compte_total_crp(ctx, "6", field=field)
    dotations = await get_compte_total_crp(ctx, "68", field=field)
    vnc = await get_compte_total_crp(ctx, "675", field=field)
    fonds_dedies = await get_compte_total_crp(ctx, "689", field=field)
    return total_classe_6 - dotations - vnc - fonds_dedies


async def get_caf(ctx: RatioContext, *, realise: bool = True) -> Decimal | None:
    """Calcule la CAF via §I.4 ``compute_caf`` à partir des inputs CRP.

    Formule simplifiée v0.2 : CAF = (Produits classe 7 décaissables) −
    (Charges classe 6 décaissables). Si on n'a pas saisi de produits/
    charges (CRP vide), retourne None.

    Pour l'EPRD (prévisionnel) on prend les colonnes `_prevu`, sinon
    `_realise`. Le caller décide via ``realise=``.
    """
    charges_dec = await get_total_charges_decaissables(ctx, realise=realise)
    produits = await get_total_produits(ctx, realise=realise)
    if charges_dec == Decimal(0) and produits == Decimal(0):
        return None
    return produits - charges_dec


# ---------------------------------------------------------------------------
# Helpers Decimal — division safe
# ---------------------------------------------------------------------------


def safe_div(numerator: Decimal, denominator: Decimal) -> Decimal | None:
    """Division retournant None si dénominateur = 0 (pas de DivisionByZero)."""
    if denominator == Decimal(0):
        return None
    return numerator / denominator


def serialize_amount(value: Decimal | None) -> float | None:
    return None if value is None else float(value)
