"""§AA.6 — 8 ratios PGFP prévisionnels D-095 bloc 10 (KB25 §12.3 lignes 135-142).

Le PGFP couvre 8 exercices (N-1 → N+6). Pour chaque ratio prévisionnel,
on retourne 1 valeur par exercice. Les formules réutilisent celles de
D-091 (ERRD) mais appliquées sur les colonnes PGFP du document.

Reco squelette v0.2 : on lit les lignes PGFP via le repo (§O livré),
mais le mapping ligne_key → formule n'étant pas standardisé en
v0.2 (chaque cabinet ajuste légèrement), on retourne 8 cellules avec
``valeur=None / verdict='na'`` quand on n'a pas la donnée précise.

Le wiring fin (extraire les bons numérateurs/dénominateurs des lignes
PGFP correspondantes) sera fait au fur et à mesure des cabinets pilotes
qui remontent la mécanique exacte de leur reporting prévisionnel.

**8 ratios** (KB25 §12.3) : endettement, vétusté, taux CAF, marge brute,
FRNG/jours, BFR/jours, Trésorerie/jours, durée apparente dette.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Final

from piilot_pack_compta_esms.ratios._base import (
    RatioContext,
    RatioPgfpExerciceValue,
    RatioResultPgfp,
    _load_pgfp_index,
    register,
)

_ANNEE_OFFSETS: Final[tuple[int, ...]] = (-1, 0, 1, 2, 3, 4, 5, 6)
"""8 exercices PGFP : N-1, N, N+1, N+2, N+3, N+4, N+5, N+6."""


async def _empty_series(
    reason: str = "Données PGFP non disponibles",
) -> list[RatioPgfpExerciceValue]:
    """8 cellules toutes na — usage quand le PGFP est vide ou que les
    inputs précis ne sont pas câblés v0.2."""
    return [
        RatioPgfpExerciceValue(annee_offset=offset, valeur=None, verdict="na")
        for offset in _ANNEE_OFFSETS
    ]


async def _series_from_pgfp(
    ctx: RatioContext,
    *,
    section: str,
    ligne_key: str,
) -> list[RatioPgfpExerciceValue]:
    """Lookup d'une ligne PGFP par (section, ligne_key) et extraction des
    8 valeurs ``montant_nm1, montant_n, montant_np1 … montant_np6``.

    Si la ligne n'existe pas → 8 cellules NA.
    """
    pgfp = await _load_pgfp_index(ctx)
    row = pgfp.get((section, ligne_key))
    if row is None:
        return await _empty_series(f"Ligne PGFP {section}/{ligne_key} absente.")

    field_map = {
        -1: "montant_nm1",
        0: "montant_n",
        1: "montant_np1",
        2: "montant_np2",
        3: "montant_np3",
        4: "montant_np4",
        5: "montant_np5",
        6: "montant_np6",
    }
    out: list[RatioPgfpExerciceValue] = []
    for offset in _ANNEE_OFFSETS:
        raw = row.get(field_map[offset])
        if raw is None:
            out.append(RatioPgfpExerciceValue(annee_offset=offset, valeur=None, verdict="na"))
        else:
            out.append(
                RatioPgfpExerciceValue(
                    annee_offset=offset,
                    valeur=Decimal(str(raw)),
                    verdict="ok",
                )
            )
    return out


# ---------------------------------------------------------------------------
# Helper — construit un RatioResultPgfp standard
# ---------------------------------------------------------------------------


def _result(
    *,
    id: str,
    label: str,
    unite: str,
    formule_textuelle: str,
    par_exercice: list[RatioPgfpExerciceValue],
    seuil_min: Decimal | None = None,
    seuil_max: Decimal | None = None,
) -> RatioResultPgfp:
    return RatioResultPgfp(
        id=id,
        label=label,
        unite=unite,  # type: ignore[arg-type]
        formule_textuelle=formule_textuelle,
        par_exercice=par_exercice,
        seuil_min=seuil_min,
        seuil_max=seuil_max,
    )


# ---------------------------------------------------------------------------
# 8 ratios PGFP — squelette v0.2
# ---------------------------------------------------------------------------


@register("pgfp.endettement")
async def r_pgfp_endettement(ctx: RatioContext) -> RatioResultPgfp:
    """Indépendance financière prévisionnelle par exercice. Seuil < 50%.

    Squelette v0.2 — lookup ligne PGFP section "Données complémentaires"
    ligne_key "ratio_endettement" si présent."""
    series = await _series_from_pgfp(ctx, section="Ratios", ligne_key="endettement_financier")
    return _result(
        id="pgfp.endettement",
        label="Indépendance financière (prévisionnelle)",
        unite="%",
        formule_textuelle="Emprunts / FRI × 100 — par exercice PGFP",
        par_exercice=series,
        seuil_max=Decimal("50"),
    )


@register("pgfp.vetuste")
async def r_pgfp_vetuste(ctx: RatioContext) -> RatioResultPgfp:
    """Vétusté immobilière prévisionnelle par exercice. Indicatif."""
    series = await _series_from_pgfp(ctx, section="Ratios", ligne_key="vetuste_immo")
    return _result(
        id="pgfp.vetuste",
        label="Vétusté immobilisations (prévisionnelle)",
        unite="%",
        formule_textuelle="Amortissements c/28 / Valeur brute c/21 — par exercice PGFP",
        par_exercice=series,
    )


@register("pgfp.taux_caf")
async def r_pgfp_taux_caf(ctx: RatioContext) -> RatioResultPgfp:
    """Taux de CAF prévisionnel par exercice. Seuil 5-10%."""
    series = await _series_from_pgfp(ctx, section="Ratios", ligne_key="taux_caf")
    return _result(
        id="pgfp.taux_caf",
        label="Taux de CAF (prévisionnel)",
        unite="%",
        formule_textuelle="CAF × 100 / Produits c/7 — par exercice PGFP",
        par_exercice=series,
        seuil_min=Decimal("5"),
        seuil_max=Decimal("10"),
    )


@register("pgfp.marge_brute")
async def r_pgfp_marge_brute(ctx: RatioContext) -> RatioResultPgfp:
    """Taux marge brute prévisionnel par exercice. Indicatif."""
    series = await _series_from_pgfp(ctx, section="Ratios", ligne_key="marge_brute")
    return _result(
        id="pgfp.marge_brute",
        label="Taux marge brute (prévisionnel)",
        unite="%",
        formule_textuelle="(Produits c/70-75 − Charges c/60-65) × 100 / Produits c/7",
        par_exercice=series,
    )


@register("pgfp.frng_jours")
async def r_pgfp_frng_jours(ctx: RatioContext) -> RatioResultPgfp:
    """FRNG en jours d'exploitation prévisionnel."""
    series = await _series_from_pgfp(ctx, section="Ratios", ligne_key="frng_jours")
    return _result(
        id="pgfp.frng_jours",
        label="FRNG en jours d'exploitation (prévisionnel)",
        unite="jours",
        formule_textuelle="FRNG × 365 / Charges décaissables — par exercice PGFP",
        par_exercice=series,
    )


@register("pgfp.bfr_jours")
async def r_pgfp_bfr_jours(ctx: RatioContext) -> RatioResultPgfp:
    """BFR en jours d'exploitation prévisionnel."""
    series = await _series_from_pgfp(ctx, section="Ratios", ligne_key="bfr_jours")
    return _result(
        id="pgfp.bfr_jours",
        label="BFR en jours (prévisionnel)",
        unite="jours",
        formule_textuelle="BFR × 365 / Charges décaissables — par exercice PGFP",
        par_exercice=series,
    )


@register("pgfp.tresorerie_jours")
async def r_pgfp_tresorerie_jours(ctx: RatioContext) -> RatioResultPgfp:
    """Trésorerie en jours d'exploitation prévisionnelle."""
    series = await _series_from_pgfp(ctx, section="Ratios", ligne_key="tresorerie_jours")
    return _result(
        id="pgfp.tresorerie_jours",
        label="Trésorerie en jours (prévisionnel)",
        unite="jours",
        formule_textuelle="Trésorerie × 365 / Charges décaissables — par exercice PGFP",
        par_exercice=series,
    )


@register("pgfp.duree_dette")
async def r_pgfp_duree_dette(ctx: RatioContext) -> RatioResultPgfp:
    """Durée apparente de la dette prévisionnelle (années)."""
    series = await _series_from_pgfp(ctx, section="Ratios", ligne_key="duree_apparente_dette")
    return _result(
        id="pgfp.duree_dette",
        label="Durée apparente de la dette (prévisionnelle)",
        unite="annees",
        formule_textuelle="Emprunts / CAF — par exercice PGFP",
        par_exercice=series,
    )
