"""§AA.2 — Ratio patrimoine immobilier (D-091 KB25 §8.2).

* **2.1 Vétusté immobilisations** : Amortissements c/28 / Valeur brute c/21.
  Indicatif (pas de seuil DGCS — chaque cabinet apprécie selon son âge
  immobilier).
"""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.ratios._base import (
    RatioContext,
    RatioResult,
    get_compte_total_bilan,
    make_na,
    make_result,
    register,
    safe_div,
    serialize_amount,
)

_HUNDRED = Decimal("100")


@register("2.1")
async def r_2_1(ctx: RatioContext) -> RatioResult:
    """Amortissements c/28 / Valeur brute c/21 × 100 (en %)."""
    amort = await get_compte_total_bilan(ctx, "28", field="amort_n")
    # Fallback : si c/28 amort_n est vide, lookup via amort_n agrégé.
    if amort == Decimal(0):
        amort = await get_compte_total_bilan(ctx, "2", field="amort_n")
    brut = await get_compte_total_bilan(ctx, "21", field="brut_n")

    if brut == Decimal(0):
        return make_na(
            id="2.1",
            label="Vétusté immobilisations",
            unite="%",
            formule_textuelle="Amortissements c/28 / Valeur brute c/21 × 100",
            reason="Valeur brute c/21 = 0 — pas d'immobilisations corporelles saisies.",
            inputs={"amort": serialize_amount(amort), "brut": serialize_amount(brut)},
        )

    return make_result(
        id="2.1",
        label="Vétusté immobilisations",
        valeur=safe_div(amort * _HUNDRED, brut),
        unite="%",
        formule_textuelle="Amortissements c/28 / Valeur brute c/21 × 100",
        inputs={"amort": serialize_amount(amort), "brut": serialize_amount(brut)},
    )
