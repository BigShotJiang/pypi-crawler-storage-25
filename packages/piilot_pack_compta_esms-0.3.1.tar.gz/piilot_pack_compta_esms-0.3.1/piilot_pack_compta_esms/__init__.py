"""Piilot plugin ``compta_esms`` — verticale comptabilité ESMS.

Entry point of the plugin. The ``Plugin`` class is referenced by
``[project.entry-points."piilot.plugins"]`` in ``pyproject.toml`` and
instantiated once at Piilot backend startup.

v0.2 — métier foundation
------------------------

Spec source : ``docs/docs_dev/dev-package-compta-esms-v0.2/`` (10 livrables
L1→L5e, 109 décisions D-001→D-109, 24 KBs métier).

8 modules top-level déclarés dans le manifest (dashboard, documents, sources,
etablissements, effectifs, activite, annexes_financieres, eps_sanitaire). Les
handlers, routes, migrations et frontend views sont câblés progressivement
dans les chantiers de ``suivi.md`` (§D→§AH côté plugin).

Cette release ne contient pas encore de schéma SQL fonctionnel (placeholder
``001_init_schema.sql`` qui ne fait que ``CREATE SCHEMA IF NOT EXISTS
compta_esms``). Le schéma réel des 24 tables ``compta_esms.*`` (cf. L1) est
posé dans ``001_compta_esms_core.sql`` lors du chantier §D.
"""

from __future__ import annotations

from piilot.sdk import Plugin as _Plugin
from piilot.sdk import load_manifest

from .agent_tools import register_all_tools, register_assistant_template
from .kb_templates import register_all_templates
from .routes import wire_routes
from .seeds import wire_seeds


class Plugin(_Plugin):
    """Plugin entry class — must subclass ``piilot.sdk.Plugin``."""

    manifest = load_manifest(__file__)

    def register(self, ctx) -> None:
        """Wire up everything this plugin provides at boot.

        Called once at backend startup with a boot-time ``Context``
        (``ctx.company`` is None here; runtime contexts are built per
        request later on).
        """
        ctx.migrations.register_schema(
            "compta_esms",
            __file__,
            "migrations",
        )

        ctx.i18n.register_locales(
            "compta_esms",
            __file__,
            "locales",
        )

        # Module handlers — wired in §E onwards as each module ships.
        # ctx.handlers.register("compta_esms.dashboard", dashboard_handler)
        # ctx.handlers.register("compta_esms.documents", documents_handler)
        # ...

        # HTTP routes — §E.1 ships OG + Établissement CRUD
        # (/plugins/compta_esms/orgs/* + /etablissements/*).
        wire_routes()

        # Module seeds — 8 entries in modules.modules table.
        wire_seeds()

        # §AH — Agent tools + template (9 tools + 1 "Assistant Compta-ESMS").
        register_all_tools()
        register_assistant_template()

        # §BI v0.3 — KB templates plugin-shipped (rapport_budgetaire_sections).
        register_all_templates()
