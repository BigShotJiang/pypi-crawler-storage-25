"""C-005 — Annexe 4 Activité prévisionnelle non vide (bloquant transition).

Source réglementaire : ``R.314-219 CASF`` — Annexe 4 obligatoire pour
l'EPRD (Activité prévisionnelle : journées, places, GIR pour EHPAD).

Couplé à ``R.314-225 CASF`` : un EPRD incomplet (annexe obligatoire
manquante) est refusé par l'ATC à la réception. D-036 / E-018 — on
pré-modélise le contrôle plugin-side.

Bloquant transition : `is_bloquant_transition=true`. Verdict KO →
422 ``transition_blocked_by_failed_control`` (D-034 pattern).

Applicable : EPRD initial uniquement. DM / RIA / AVENANT héritent de
l'annexe 4 du parent (cf. C-004). ERRD utilise l'Annexe 9 réalisée
(préfixe ``9A_*``/``9B_*``/``9C_*``/``9D_*`` dans ``annexe_variante``),
qui n'est pas couverte par ce contrôle.

Filtre : on compte uniquement les lignes prévisionnelles (préfixe
``4A_*``/``4B_*``/``4C_*``/``4D_*`` dans ``annexe_variante``), pas
les lignes réalisées qui appartiennent à l'Annexe 9.
"""

from __future__ import annotations

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.controls._base import (
    ControlContext,
    ControleResult,
    ko,
    not_applicable,
    ok,
    register,
)

# Variantes Annexe 4 prévisionnelles — cf. CHECK constraint
# ``activite_lignes.annexe_variante`` (migration 002 ligne 367-370).
_ANNEXE_4_VARIANTES = frozenset(
    {
        "4A_ehpad_puv",
        "4B_autres_essms",
        "4C_creton",
        "4D_sad_spasad",
    }
)


@register("C-005")
async def evaluate(ctx: ControlContext) -> ControleResult:
    """KO si l'Annexe 4 (Activité prévisionnelle) ne contient aucune ligne."""
    type_document = ctx.document["type_document"]
    if type_document != "eprd":
        return not_applicable(
            f"C-005 Annexe 4 applicable seulement à l'EPRD initial "
            f"(type='{type_document}'). DM/RIA/AVENANT héritent de "
            f"l'annexe 4 parent ; ERRD utilise l'Annexe 9 réalisée."
        )

    from piilot_pack_compta_esms.repositories import activite_repo

    # On charge toutes les lignes du document et on filtre les variantes
    # prévisionnelles côté Python. `list_by_filter` ne sait filtrer que
    # par 1 variante à la fois — un seul SELECT économique vs 4.
    rows = await run_in_thread(
        activite_repo.list_by_filter,
        ctx.document_id,
        None,  # ets_id
        None,  # annexe_variante (on filtre côté Python)
    )
    nb_lignes_4x = sum(1 for r in rows if r.get("annexe_variante") in _ANNEXE_4_VARIANTES)

    if nb_lignes_4x == 0:
        return ko(
            "Annexe 4 (Activité prévisionnelle) vide — R.314-219 exige "
            "le tableau d'activité (journées, places, GIR pour EHPAD) "
            "pour transmettre un EPRD. Saisissez au moins une ligne "
            "par section × GIR (ou équivalent selon variante 4A/B/C/D).",
            severite="error",
            nb_lignes_annexe4=0,
        )

    return ok(
        f"Annexe 4 renseignée : {nb_lignes_4x} ligne(s) prévisionnelle(s) saisie(s).",
        nb_lignes_annexe4=nb_lignes_4x,
    )
