"""§Z — Catalogue des contrôles intégrés DGCS (PLT-43, D-077→D-081).

Chaque module `c_xxx.py` enregistre une implémentation pour un code
stable du catalogue ``com.piilot.core.audit-controls-esms``. Au boot
du plugin, l'import de ce package déclenche l'enregistrement (via le
décorateur ``@register``) — l'engine peut alors dispatcher par code.

L'évaluation est triggered par :

* ``POST /documents/{id}/controles:run`` — explicit user action
* Hook §S workflow : à la transition ``brouillon → transmis``, l'engine
  exécute en interne les 3 contrôles ``is_bloquant_transition=true``
  et refuse 409 si l'un est KO (D-034).
"""

from __future__ import annotations

# Importing implementations triggers their @register side-effect.
# Listed explicitly rather than glob-imported for IDE friendliness and
# to make the load order deterministic.
from piilot_pack_compta_esms.controls import (  # noqa: F401
    c_001,  # Équilibre Bilan TOTAL ACTIF = TOTAL PASSIF (bloquant)
    c_002,  # Cohérence Annexe 5A H/D/S = total CRP (bloquant)
    c_003,  # Équilibre réel R.314-222 5 conditions (bloquant)
    c_004,  # TPER annexe 6 non vide R.314-224 (bloquant, EPRD)
    c_005,  # Annexe 4 Activité prévisionnelle non vide R.314-219 (bloquant, EPRD)
    c_computables,  # ~30 contrôles computables (niveau B)
    c_skeletons,  # ~84 squelettes NA (niveau C)
)
