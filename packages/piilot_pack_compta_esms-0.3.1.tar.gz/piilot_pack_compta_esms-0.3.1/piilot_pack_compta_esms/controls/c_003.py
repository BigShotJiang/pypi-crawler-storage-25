"""C-003 — Équilibre réel R.314-222 5 conditions EPRD (bloquant transition).

KB core source : ``com.piilot.core.audit-controls-esms`` ligne C-003.

Règle : les 5 conditions de l'équilibre réel R.314-222 CASF doivent
toutes être satisfaites simultanément :

1. Produits tarifs saisis = produits tarifs notifiés.
2. Sincérité (qualitatif, vérifié par le cabinet en booléen).
3. Remboursement capital N non couvert par un produit d'emprunt.
4. CAF suffisante pour le capital à rembourser N.
5. Recettes affectées employées à l'usage prévu.

Applicable uniquement aux **EPRD** (D-034) — l'ERRD n'est pas concerné
(c'est un réalisé, pas un prévisionnel à équilibrer).

§I a livré :func:`validate_equilibre_reel` qui prend un input
structuré et retourne le verdict. C-003 charge l'input depuis les
tables existantes et délègue.

**v0.2 squelette soft** : les 5 inputs réels ne sont pas tous câblés
au niveau document (CAF projection §I + capital emprunts §N + tarifs
notifiés §H + recettes affectées §J). En attendant le wiring complet
(reporté v0.3 quand on aura tous les agrégats), C-003 retourne `na`
quand un input manque. Le guard §S transmit ne bloque que sur KO,
donc na = passe.
"""

from __future__ import annotations

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.controls._base import (
    ControlContext,
    ControleResult,
    ko,
    not_applicable,
    ok,
    register,
)
from piilot_pack_compta_esms.models.finance import EquilibreReelInput
from piilot_pack_compta_esms.services.finance.equilibre_validator import (
    validate_equilibre_reel,
)


@register("C-003")
async def evaluate(ctx: ControlContext) -> ControleResult:
    """Charge les 5 inputs et délègue à validate_equilibre_reel."""
    type_document = ctx.document["type_document"]
    if type_document != "eprd":
        return not_applicable(
            f"C-003 R.314-222 applicable seulement à l'EPRD " f"(type='{type_document}')"
        )

    # v0.2 squelette : tous les inputs à None — validate_equilibre_reel
    # retournera evaluable_globalement=False et 5 conditions na.
    # Wiring réel reporté v0.3 : charger CAF depuis §I caf_calculator,
    # capital_a_rembourser_n depuis §N emprunts.list_by_document,
    # produits_tarif_saisis depuis §H crp_ligne_repo agrégat,
    # produits_tarif_notifies depuis §E exercice metadata, etc.
    payload = EquilibreReelInput(
        produits_tarif_saisis=None,
        produits_tarif_notifies=None,
        sincerite_commentee=None,
        capital_rembourse_via_emprunt=None,
        caf_n=None,
        capital_a_rembourser_n=None,
        recettes_affectees=None,
        recettes_affectees_utilisees=None,
    )

    # Permet aux tests de surcharger l'input via ctx.custom['equilibre_input']
    if "equilibre_input" in ctx.custom:
        payload = ctx.custom["equilibre_input"]

    # validate_equilibre_reel est sync mais on garde le pattern async
    # pour rester cohérent avec les autres handlers.
    _ = run_in_thread  # unused mais l'import doit rester pour cohérence

    result = validate_equilibre_reel(payload)

    if not result.evaluable_globalement:
        # Squelette v0.2 — inputs partiels → na non-bloquant.
        nb_na = 5 - result.nb_evaluables
        return not_applicable(
            f"Équilibre R.314-222 non-évaluable : {nb_na}/5 conditions "
            f"avec input manquant. Wiring complet différé (CAF §I + "
            f"emprunts §N + recettes affectées §J).",
            conditions=[c.model_dump() for c in result.conditions],
            nb_evaluables=result.nb_evaluables,
        )

    if result.equilibre:
        return ok(
            "Équilibre R.314-222 satisfait — 5/5 conditions passées",
            conditions=[c.model_dump() for c in result.conditions],
        )

    # KO bloquant — au moins 1 condition évaluable ET non-passée.
    failed = [c for c in result.conditions if c.evaluable and not c.passed]
    first_failed = failed[0]
    return ko(
        f"Équilibre R.314-222 non atteint — {len(failed)}/5 condition(s) "
        f"KO. Première : condition {first_failed.id} {first_failed.label} : "
        f"{first_failed.message}",
        severite="error",
        nb_conditions_ko=len(failed),
        condition_ko_ids=[c.id for c in failed],
        conditions=[c.model_dump() for c in result.conditions],
    )
