"""C-002 — Cohérence Annexe 5A : Σ ventilations H/D/S = total CRP (bloquant).

KB core source : ``com.piilot.core.audit-controls-esms`` ligne C-002.

Règle : pour chaque compte M22Bis présent dans un CR ventilé H/D/S
(EHPAD), la somme des montants H + D + S [+ SEA] doit égaler le
montant_basis du compte (réalisé pour ERRD, prévisions_totales pour
EPRD). Tolérance 0.01€ par ligne (déjà enforced par §Y validator).

§Y a déjà câblé ``ventilation_service.validate_explicit_ventilation``
qui rejette à la saisie. C-002 sert de **filet de sécurité** pour les
documents anciens (créés avant §Y) ou les imports balance qui
contourneraient le hook.

Bloquant transition : un cabinet ne doit pas transmettre un EPRD/ERRD
avec ventilation incohérente — les ratios soins/dépendance/hébergement
calculés en aval sortiraient faussés.
"""

from __future__ import annotations

from decimal import Decimal

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.controls._base import (
    ControlContext,
    ControleResult,
    ko,
    not_applicable,
    ok,
    register,
    serialize_amount,
)

_TOLERANCE = Decimal("0.01")
_ZERO = Decimal("0")


@register("C-002")
async def evaluate(ctx: ControlContext) -> ControleResult:
    """Itère sur les lignes ventilées du document et vérifie Σ = basis."""
    from piilot_pack_compta_esms.repositories import cr_repo, crp_ligne_repo
    from piilot_pack_compta_esms.services import ventilation_service

    crs = await run_in_thread(cr_repo.list_by_document, ctx.document_id)
    ternaire_crs = [cr for cr in crs if cr["ventilation"] in {"ternaire_hds", "ternaire_hdsea"}]

    if not ternaire_crs:
        return not_applicable(
            "Aucun CR en ventilation ternaire H/D/S — contrôle " "non-applicable au document."
        )

    issues: list[dict] = []
    total_lignes_evaluees = 0

    for cr in ternaire_crs:
        lignes = await run_in_thread(
            crp_ligne_repo.list_by_cr, cr["id"], groupe=None, nature="charge"
        )
        for ligne in lignes:
            basis = ventilation_service.extract_basis_amount(ligne)
            h = _dec_or_zero(ligne.get("montant_hebergement"))
            d = _dec_or_zero(ligne.get("montant_dependance"))
            s = _dec_or_zero(ligne.get("montant_soins"))
            sea = _dec_or_zero(ligne.get("montant_soins_autonomie"))
            ventilation = h + d + s + sea

            # Skip les lignes non ventilées (toutes cols = 0 ET basis non-None)
            # — c'est de la saisie manuelle en attente.
            if basis is None or (ventilation == _ZERO and basis != _ZERO):
                continue

            total_lignes_evaluees += 1
            ecart = abs(ventilation - basis)
            if ecart > _TOLERANCE:
                issues.append(
                    {
                        "cr_denomination": cr["denomination"],
                        "compte": ligne["compte_m22bis"],
                        "ventilation": serialize_amount(ventilation),
                        "total_crp": serialize_amount(basis),
                        "ecart": serialize_amount(ecart),
                    }
                )

    if total_lignes_evaluees == 0:
        return not_applicable("Aucune ligne ventilée trouvée — saisie H/D/S à effectuer.")

    if not issues:
        return ok(
            f"Cohérence H/D/S satisfaite sur {total_lignes_evaluees} ligne(s) ventilée(s)",
            lignes_verifiees=total_lignes_evaluees,
        )

    return ko(
        f"{len(issues)} ligne(s) ventilée(s) sur {total_lignes_evaluees} avec "
        f"écart > {_TOLERANCE}€ entre Σ H/D/S et total CRP.",
        severite="error",
        nb_anomalies=len(issues),
        nb_lignes_evaluees=total_lignes_evaluees,
        anomalies_top10=issues[:10],
    )


def _dec_or_zero(value) -> Decimal:  # noqa: ANN001
    if value is None:
        return _ZERO
    return Decimal(str(value))
