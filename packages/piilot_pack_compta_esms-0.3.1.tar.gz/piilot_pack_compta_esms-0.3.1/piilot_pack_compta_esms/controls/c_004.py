"""C-004 — TPER annexe 6 non vide (bloquant transition).

Source réglementaire : ``R.314-224 CASF`` — Annexe 6 obligatoire pour
l'EPRD (TPER : Tableau Prévisionnel des Effectifs Rémunérés).

Couplé à ``R.314-225 CASF`` : un EPRD incomplet (annexe obligatoire
manquante) est refusé par l'ATC à la réception. D-036 / E-018 — on
pré-modélise le contrôle plugin-side pour éviter ce rejet avant
transmission.

Bloquant transition : `is_bloquant_transition=true`. Verdict KO →
422 ``transition_blocked_by_failed_control`` (D-034 pattern).

Applicable : EPRD initial uniquement (DM / RIA / AVENANT héritent du
TPER de l'EPRD parent, EPCP est sanitaire et n'a pas de TPER, ERRD a
le TER au lieu du TPER).
"""

from __future__ import annotations

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.controls._base import (
    ControlContext,
    ControleResult,
    ko,
    not_applicable,
    ok,
    register,
)


@register("C-004")
async def evaluate(ctx: ControlContext) -> ControleResult:
    """KO si le TPER (annexe 6) du document EPRD ne contient aucune ligne."""
    type_document = ctx.document["type_document"]
    if type_document != "eprd":
        return not_applicable(
            f"C-004 TPER applicable seulement à l'EPRD initial (type='{type_document}'). "
            f"DM/RIA/AVENANT héritent du TPER parent ; EPCP/ERRD ont leur propre annexe."
        )

    from piilot_pack_compta_esms.repositories import tper_ter_repo

    rows = await run_in_thread(
        tper_ter_repo.list_by_filter,
        ctx.document_id,
        None,  # ets_id
        "TPER",  # type_tableau
    )
    nb_lignes = len(rows)
    if nb_lignes == 0:
        return ko(
            "Annexe 6 (TPER) vide — R.314-224 exige le tableau prévisionnel "
            "des effectifs rémunérés pour transmettre un EPRD. Saisissez "
            "au moins une ligne par catégorie CNSA × fonction.",
            severite="error",
            nb_lignes_tper=0,
        )

    return ok(
        f"TPER renseigné : {nb_lignes} ligne(s) annexe 6 saisie(s).",
        nb_lignes_tper=nb_lignes,
    )
