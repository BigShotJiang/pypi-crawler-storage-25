"""Niveau C — 101 squelettes NA pour les codes seedés structurels v0.2.

KB core source : ``com.piilot.core.audit-controls-esms`` v0_2_seed_categories.

Le seed v0.2 du catalogue DGCS livre 80 contrôles ERRD (C-200→C-279)
et 21 contrôles EPRD/TPER/Annexes/Bilans (C-300→C-320) sous forme
**structurelle catégorisée** — un libellé court + une catégorie, mais
sans formule exécutable trivialement (les onglets ``onglet_contrôle``
XLS sont multi-sheets avec formules incorporées qu'on n'extrait pas
en v0.2).

En attendant l'enrichissement progressif via les cabinets pilotes,
on enregistre 101 handlers ``not_applicable`` qui retournent un
message homogène. L'engine les call comme les autres ; le frontend
les affiche en `na` avec le libellé du catalogue core (la metadata
existe, c'est juste l'implémentation qui est différée).

Cette approche permet :
* le frontend rend tout le catalogue sans erreur (UX cohérente),
* les agents IA peuvent énumérer tous les codes seedés,
* on enrichit code par code sans diff massif (un fichier ``c_<code>.py``
  séparé suffit à remplacer l'enregistrement squelette).
"""

from __future__ import annotations

from piilot_pack_compta_esms.controls._base import (
    ControlContext,
    ControleResult,
    not_applicable,
    register,
)

# Plages couvertes par les squelettes (codes inclusifs).
_ERRD_RANGE: tuple[int, ...] = tuple(range(200, 280))  # C-200 → C-279 (80)
_OTHERS_RANGE: tuple[int, ...] = tuple(range(300, 321))  # C-300 → C-320 (21)

SKELETON_CODES: tuple[str, ...] = tuple(f"C-{n:03d}" for n in (_ERRD_RANGE + _OTHERS_RANGE))


def _make_handler(code: str):
    """Factory — crée un handler async pour ``code``.

    Le code est capturé par closure pour que le message NA reste
    spécifique au code (utile au frontend pour l'affichage)."""

    async def _handler(ctx: ControlContext) -> ControleResult:
        return not_applicable(
            f"Implémentation différée — règle métier non câblée pour "
            f"le contrôle {code} en v0.2. Catalogue KB core fournit "
            f"la métadonnée (libellé, sévérité, catégorie), "
            f"l'évaluation viendra avec les cabinets pilotes."
        )

    _handler.__name__ = f"evaluate_{code.replace('-', '_').lower()}"
    return _handler


# Enregistrement en boucle — équivalent à 101 @register manuels mais
# sans 101 fichiers.
for _code in SKELETON_CODES:
    register(_code)(_make_handler(_code))
