"""C-001 — Équilibre Bilan TOTAL ACTIF = TOTAL PASSIF (bloquant transition).

KB core source : ``com.piilot.core.audit-controls-esms`` ligne C-001.

Règle : ``Σ(actif net N) = Σ(passif net N) ± tolérance``. Dans le
contexte ESMS (R.314-223), "ACTIF" et "TOTAL BIENS" sont équivalents,
de même pour "PASSIF" et "TOTAL FINANCEMENTS" — c'est la même équation
comptable.

D-077 — la majorité des contrôles sont soft (warning) mais celui-ci est
``is_bloquant_transition=true`` : un Bilan déséquilibré rend tout
l'EPRD/ERRD incohérent (les ratios financiers §AA et les contrôles
provisions/TF dépendent du Bilan équilibré).

Implémentation : délègue à :func:`bilan_service.validate_equilibre`
déjà livré §K (D-077 / KB25 §1.3 C56-C58).
"""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.controls._base import (
    ControlContext,
    ControleResult,
    ko,
    not_applicable,
    ok,
    register,
    serialize_amount,
)


@register("C-001")
async def evaluate(ctx: ControlContext) -> ControleResult:
    """Vérifie l'équilibre Bilan TOTAL ACTIF = TOTAL PASSIF."""
    from piilot_pack_compta_esms.services import bilan_service

    result = await bilan_service.validate_equilibre(ctx.document_id, ctx.company_id)

    # Aucune ligne bilan présente → result.valide=True mais issues=[] et
    # aucun block. C'est notre cas "non-évaluable" (le doc est en brouillon
    # début de saisie).
    if result.valide and not result.issues:
        # validate_equilibre retourne valide=True sur 2 cas : tout passe,
        # ou aucun bloc à valider. On distingue via les totaux. Si tous
        # les blocs vides → NA, sinon OK.
        from piilot_pack_compta_esms.services.bilan_service import compute_totals

        totals = await compute_totals(ctx.document_id, ctx.company_id)
        has_any_block = bool(totals.financier or totals.comptable_pc or totals.comptable_pnl)
        if not has_any_block:
            return not_applicable(
                "Aucune ligne Bilan saisie — le contrôle d'équilibre "
                "actif/passif ne s'applique pas encore."
            )
        # Toutes les variantes présentes équilibrées
        return ok(
            "Équilibre Bilan satisfait sur toutes les variantes présentes",
            variantes_validees=list(_present_variantes(totals)),
            tolerance=serialize_amount(result.tolerance_appliquee),
        )

    # Issues KO — on remonte le 1er écart le plus grossier en message
    # principal et on agrège la liste des types_bilan fautifs.
    types_ko = [issue.type_bilan for issue in result.issues]
    biggest = max(result.issues, key=lambda i: abs(i.ecart))

    return ko(
        f"Total actif ≠ Total passif sur {len(result.issues)} variante(s) "
        f"de Bilan ({', '.join(types_ko)}). Écart le plus grossier : "
        f"{biggest.ecart:.2f}€ sur {biggest.type_bilan}.",
        severite="error",
        types_bilan_ko=types_ko,
        ecart_max=serialize_amount(Decimal(biggest.ecart)),
        tolerance=serialize_amount(result.tolerance_appliquee),
    )


def _present_variantes(totals) -> list[str]:  # noqa: ANN001 — circular-safe
    out = []
    if totals.financier:
        out.append("financier")
    if totals.comptable_pc:
        out.append("comptable_pc")
    if totals.comptable_pnl:
        out.append("comptable_pnl")
    return out
