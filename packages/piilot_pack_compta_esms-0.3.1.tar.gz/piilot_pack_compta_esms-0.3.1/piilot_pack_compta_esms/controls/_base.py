"""Types + registry + helpers communs au catalogue de contrôles §Z.

Pattern :

* :class:`ControlContext` — état partagé entre tous les contrôles d'un
  ``:run``. Lazy loading des sections (1 SELECT par section, mémoïsé).
* :class:`ControleResult` — DTO de retour, structurellement identique
  à la table ``controles_resultats``.
* :func:`register` — décorateur de classement dans :data:`CONTROL_HANDLERS`.
* Helpers ``ok / ko / not_applicable`` — factories pour construire un
  ControleResult sans boilerplate.

Aucun import de service "lourd" ici — les contrôles individuels
importent ce qu'ils utilisent. On évite ainsi les cycles : `controls/`
peut importer `services/` mais `services/` ne doit jamais importer
`controls/` (sauf le service orchestrateur :mod:`controles_service`).
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

logger = logging.getLogger(__name__)

Statut = Literal["ok", "ko", "na"]
Severite = Literal["info", "warning", "error"]


# ---------------------------------------------------------------------------
# ControleResult — DTO unique pour tous les contrôles
# ---------------------------------------------------------------------------


class ControleResult(BaseModel):
    """Résultat structuré renvoyé par un handler de contrôle.

    Le service orchestrateur enrichit ce résultat avec ``code`` (depuis
    le registry) avant persistance — chaque handler ne renseigne pas
    son propre code, ça évite les drifts code-fichier/code-payload.
    """

    model_config = ConfigDict(extra="forbid")

    statut: Statut
    severite: Severite
    message: str | None = None
    valeurs_observees: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# ControlContext — partagé entre tous les handlers d'un :run
# ---------------------------------------------------------------------------


@dataclass
class ControlContext:
    """État de contexte chargé une fois par ``:run`` et passé à tous
    les handlers du batch.

    Lazy fields : ``crs``, ``crp_lignes``, ``bilan_lignes``,
    ``affectations``, ``tf_lignes``, ``annexe5_lignes``. Chaque accès
    déclenche le SELECT correspondant (memoized), sauf si le caller
    a déjà chargé. Pas de pre-fetch — un contrôle qui n'a pas besoin
    du Bilan n'en paye pas le coût.

    Le ``document`` est mandatory (chargé par l'orchestrateur avant
    de construire le context). ``company_id`` est dupliqué pour les
    helpers qui doivent re-checker tenant.
    """

    document_id: UUID
    company_id: UUID
    document: dict[str, Any]
    # Lazy caches — None = pas encore chargé.
    _crs: list[dict[str, Any]] | None = None
    _crp_lignes_by_cr: dict[UUID, list[dict[str, Any]]] = field(default_factory=dict)
    _bilan_lignes: list[dict[str, Any]] | None = None
    _affectations: list[dict[str, Any]] | None = None
    _tf_lignes: list[dict[str, Any]] | None = None
    _annexe5_lignes: list[dict[str, Any]] | None = None
    # Cache de chargement custom-friendly — un contrôle peut stocker
    # ce qu'il veut sous une clé string, par ex. 'caf' / 'frng'.
    custom: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Registry — décorateur + lookup
# ---------------------------------------------------------------------------


# Signature d'un handler : reçoit le contexte du document et retourne
# un ControleResult. Asynchrone car les chargements lazy passent par
# ``run_in_thread``.
ControlHandler = Callable[[ControlContext], Awaitable[ControleResult]]

CONTROL_HANDLERS: dict[str, ControlHandler] = {}
"""Registry global. Renseigné au boot via :func:`register`.

Clé = code (ex: ``"C-001"``), valeur = handler async."""


def register(code: str) -> Callable[[ControlHandler], ControlHandler]:
    """Décorateur — enregistre ``handler`` sous ``code``.

    Refuse 2 enregistrements pour le même code (raise au boot — diff
    de code-base évident, pas un bug runtime à debugger).
    """

    def _wrapper(handler: ControlHandler) -> ControlHandler:
        if code in CONTROL_HANDLERS:
            raise RuntimeError(
                f"control handler {code!r} already registered "
                f"(double @register dans le code-base)"
            )
        CONTROL_HANDLERS[code] = handler
        return handler

    return _wrapper


def get_handler(code: str) -> ControlHandler | None:
    """Lookup non-strict — None si le code n'est pas (encore) implémenté."""
    return CONTROL_HANDLERS.get(code)


def list_registered_codes() -> list[str]:
    """Retourne la liste triée des codes enregistrés (helper tests)."""
    return sorted(CONTROL_HANDLERS)


# ---------------------------------------------------------------------------
# Factories de ControleResult
# ---------------------------------------------------------------------------


def ok(message: str | None = None, **observed: Any) -> ControleResult:
    """Contrôle satisfait — sévérité ``info`` (le résultat n'est pas
    diffusé en alerte, mais le rendering UI peut l'afficher comme
    "validé" en vert)."""
    return ControleResult(
        statut="ok",
        severite="info",
        message=message,
        valeurs_observees=observed,
    )


def ko(
    message: str,
    *,
    severite: Severite = "warning",
    **observed: Any,
) -> ControleResult:
    """Anomalie détectée. Sévérité ``warning`` par défaut (D-077 —
    titre expérimental DGCS = soft warnings). Les 3 contrôles
    bloquants posent explicitement ``severite='error'``."""
    return ControleResult(
        statut="ko",
        severite=severite,
        message=message,
        valeurs_observees=observed,
    )


def not_applicable(reason: str, **observed: Any) -> ControleResult:
    """Contrôle non-évaluable — input manquant ou règle pas câblée v0.2.

    Sévérité ``info`` car ce n'est pas une alerte mais un signal au
    cabinet "vérifie tes saisies ou attends la v suivante du plugin".
    """
    return ControleResult(
        statut="na",
        severite="info",
        message=reason,
        valeurs_observees=observed,
    )


# ---------------------------------------------------------------------------
# Helper conversion Decimal → float pour valeurs_observees JSON-safe
# ---------------------------------------------------------------------------


def serialize_amount(value: Decimal | None) -> float | None:
    """Sérialise un Decimal pour JSON (les routes posent un response_model
    Pydantic qui peut sérialiser Decimal en str, mais on préfère float
    pour le frontend qui veut comparer numériquement)."""
    return None if value is None else float(value)
