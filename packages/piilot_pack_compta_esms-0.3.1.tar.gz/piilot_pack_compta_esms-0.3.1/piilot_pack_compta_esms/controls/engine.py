"""Engine §Z — orchestre l'évaluation du catalogue contrôles.

Pattern : 1 instance par ``:run``. Charge la liste des codes
applicables, dispatch chacun vers son handler registered, agrège les
résultats pour persistance.

Le service appelant (``controles_service``) est responsable de :

* charger le document (et passer son row à l'engine),
* persister les résultats via :mod:`controles_resultats_repo`,
* mapper les exceptions en HTTPException au niveau route.
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from piilot_pack_compta_esms.controls._base import (
    CONTROL_HANDLERS,
    ControlContext,
    ControleResult,
    not_applicable,
)

logger = logging.getLogger(__name__)


class ControlsEngine:
    """Orchestre 1 ``:run`` de contrôles sur 1 document.

    Stateful sur la durée d'un :run uniquement — pas de cache cross-run
    (le ControlContext sera reconstruit à chaque appel pour respecter
    la cohérence avec la saisie en cours).
    """

    def __init__(
        self,
        *,
        document_id: UUID,
        company_id: UUID,
        document: dict[str, Any],
        codes_filter: list[str] | None = None,
        applicable_codes: set[str] | None = None,
    ) -> None:
        """Initialise l'engine.

        Args :
            document_id / company_id / document : passés au ControlContext.
            codes_filter : si fourni, n'évaluer que ces codes (sinon tous
                ceux registered ET applicable_codes).
            applicable_codes : set des codes issus du catalogue KB core
                filtrés par ``applicable_doc_types LIKE %type_document%``.
                Si None, on évalue tous les registered (cas test/debug).
        """
        self.ctx = ControlContext(
            document_id=document_id,
            company_id=company_id,
            document=document,
        )
        self.codes_filter = set(codes_filter) if codes_filter else None
        self.applicable_codes = applicable_codes

    def _resolve_target_codes(self) -> list[str]:
        """Calcule l'intersection des codes à évaluer."""
        target = set(CONTROL_HANDLERS)
        if self.applicable_codes is not None:
            target &= self.applicable_codes
        if self.codes_filter is not None:
            target &= self.codes_filter
        return sorted(target)

    async def run(self) -> list[dict[str, Any]]:
        """Lance l'évaluation et retourne la liste des résultats prêts
        à être bulk-upsertés en DB (clé code, statut, severite_observee,
        valeurs_observees, message_humain).

        Un handler qui crash est wrappé en `na` avec le message d'erreur
        (defensive — un bug dans un contrôle ne doit pas faire tomber
        tout le :run).
        """
        target_codes = self._resolve_target_codes()
        results: list[dict[str, Any]] = []

        for code in target_codes:
            handler = CONTROL_HANDLERS.get(code)
            if handler is None:
                # Catalogue côté core mentionne un code non-impl. côté
                # plugin — on renvoie NA pour ne pas trou silencieusement.
                control_result = not_applicable(f"Handler {code} non enregistré côté plugin.")
            else:
                try:
                    control_result = await handler(self.ctx)
                except Exception as exc:  # noqa: BLE001 — defensive
                    logger.exception(
                        "controls engine: handler %r raised — wrapping en NA",
                        code,
                    )
                    control_result = not_applicable(f"Erreur d'évaluation : {type(exc).__name__}")
            results.append(_to_row(code, control_result))
        return results


def _to_row(code: str, result: ControleResult) -> dict[str, Any]:
    """Convertit un :class:`ControleResult` en row prête pour le repo."""
    return {
        "code": code,
        "statut": result.statut,
        "severite_observee": result.severite,
        "valeurs_observees": result.valeurs_observees,
        "message_humain": result.message,
    }
