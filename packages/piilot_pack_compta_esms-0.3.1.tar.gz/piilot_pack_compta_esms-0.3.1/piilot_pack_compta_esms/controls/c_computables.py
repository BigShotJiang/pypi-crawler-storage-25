"""Niveau B — 13 contrôles TER computables (C-101 → C-113).

KB core source : ``com.piilot.core.audit-controls-esms`` lignes
C-101 à C-113 — contrôles transcrits 1:1 de KB17 §10.1.

Ces 13 contrôles vérifient des bornes simples sur les données saisies
en §P TPER/TER (effectifs et rémunérations). Tous ``warning``, aucun
bloquant transition.

Implémentation : 1 fonction par code, registered via le décorateur.
Tous chargent les lignes TER/TPER via le repo et appliquent une
règle simple (>0, <1000, écart ±10%, etc.).
"""

from __future__ import annotations

from decimal import Decimal

from piilot.sdk.db import run_in_thread

from piilot_pack_compta_esms.controls._base import (
    ControlContext,
    ControleResult,
    ko,
    not_applicable,
    ok,
    register,
    serialize_amount,
)

_ZERO = Decimal("0")
_MAX_ETP = Decimal("1000")
_TEN_PCT = Decimal("0.10")


async def _load_ter_lignes(ctx: ControlContext) -> list[dict]:
    """Helper — charge les lignes TER du document (memoized via ctx).

    ``tper_ter_repo.list_by_filter`` retourne TPER+TER. Le filtre par
    type_tableau='TER' est fait côté Python pour éviter 2 round-trips
    (les contrôles C-101+ ne lisent que TER, mais d'autres contrôles
    futurs pourront utiliser TPER — autant cacher le tout)."""
    if "ter_lignes" not in ctx.custom:
        from piilot_pack_compta_esms.repositories import tper_ter_repo

        ctx.custom["ter_lignes"] = await run_in_thread(
            tper_ter_repo.list_by_filter, ctx.document_id
        )
    return ctx.custom["ter_lignes"]


def _filter_type(rows: list[dict], type_tableau: str) -> list[dict]:
    return [r for r in rows if r.get("type_tableau") == type_tableau]


def _sum_field(rows: list[dict], field: str) -> Decimal:
    total = _ZERO
    for r in rows:
        val = r.get(field)
        if val is not None:
            total += Decimal(str(val))
    return total


# ---------------------------------------------------------------------------
# C-101 — ETPR salariés > 0
# ---------------------------------------------------------------------------


@register("C-101")
async def c_101(ctx: ControlContext) -> ControleResult:
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    total = _sum_field(rows, "etpr_realises")
    if total > _ZERO:
        return ok(f"ETPR salariés = {total} > 0", valeur=serialize_amount(total))
    return ko(
        f"ETPR salariés > 0 — valeur observée {total}",
        valeur=serialize_amount(total),
    )


# ---------------------------------------------------------------------------
# C-102 — ETPR salariés < 1 000
# ---------------------------------------------------------------------------


@register("C-102")
async def c_102(ctx: ControlContext) -> ControleResult:
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    total = _sum_field(rows, "etpr_realises")
    if total < _MAX_ETP:
        return ok(f"ETPR salariés = {total} < 1000", valeur=serialize_amount(total))
    return ko(
        f"ETPR salariés ≥ 1000 (atypie) — valeur observée {total}",
        valeur=serialize_amount(total),
        seuil=serialize_amount(_MAX_ETP),
    )


# ---------------------------------------------------------------------------
# C-103 — ETPT salariés > 0
# ---------------------------------------------------------------------------


@register("C-103")
async def c_103(ctx: ControlContext) -> ControleResult:
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    total = _sum_field(rows, "etpt_realises")
    if total > _ZERO:
        return ok(f"ETPT salariés = {total} > 0", valeur=serialize_amount(total))
    return ko(
        f"ETPT salariés > 0 — valeur observée {total}",
        valeur=serialize_amount(total),
    )


# ---------------------------------------------------------------------------
# C-104 — ETPT salariés < 1 000
# ---------------------------------------------------------------------------


@register("C-104")
async def c_104(ctx: ControlContext) -> ControleResult:
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    total = _sum_field(rows, "etpt_realises")
    if total < _MAX_ETP:
        return ok(f"ETPT salariés = {total} < 1000", valeur=serialize_amount(total))
    return ko(
        f"ETPT salariés ≥ 1000 (atypie) — valeur observée {total}",
        valeur=serialize_amount(total),
        seuil=serialize_amount(_MAX_ETP),
    )


# ---------------------------------------------------------------------------
# C-105 — ETPR salariés = Σ ETPR par section
# ---------------------------------------------------------------------------


@register("C-105")
async def c_105(ctx: ControlContext) -> ControleResult:
    """Σ par section_imputation doit égaler le total global (tolérance 0.01)."""
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    total_global = _sum_field(rows, "etpr_realises")
    # Aggregate par section
    by_section: dict[str, Decimal] = {}
    for r in rows:
        section = r.get("section_imputation")
        if section is None:
            continue
        val = r.get("etpr_realises")
        if val is not None:
            by_section[section] = by_section.get(section, _ZERO) + Decimal(str(val))
    total_sections = sum(by_section.values(), _ZERO)
    ecart = abs(total_global - total_sections)
    if ecart <= Decimal("0.01"):
        return ok(
            f"Σ ETPR sections = {total_sections} = total global {total_global}",
            total_global=serialize_amount(total_global),
            total_sections=serialize_amount(total_sections),
        )
    return ko(
        f"Σ ETPR sections ({total_sections}) ≠ total global ({total_global}) " f"— écart {ecart}",
        total_global=serialize_amount(total_global),
        total_sections=serialize_amount(total_sections),
        ecart=serialize_amount(ecart),
    )


# ---------------------------------------------------------------------------
# C-106 — ETPR AS-AMP-AES > 0
# ---------------------------------------------------------------------------


@register("C-106")
async def c_106(ctx: ControlContext) -> ControleResult:
    """Filtre les lignes dont la fonction est dans la famille AS/AMP/AES.

    Heuristique : fonction contient 'AS', 'AMP' ou 'AES' (case-insensitive)."""
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    family = {"AS", "AMP", "AES", "aide_soignant", "aide_medico_psy", "accompagnant"}
    matching = [
        r for r in rows if any(tag.lower() in (r.get("fonction") or "").lower() for tag in family)
    ]
    if not matching:
        return not_applicable("Aucune ligne fonction AS/AMP/AES — contrôle non-applicable.")
    total = _sum_field(matching, "etpr_realises")
    if total > _ZERO:
        return ok(f"ETPR AS-AMP-AES = {total} > 0", valeur=serialize_amount(total))
    return ko(
        f"ETPR AS-AMP-AES > 0 attendu — valeur observée {total}",
        valeur=serialize_amount(total),
    )


# ---------------------------------------------------------------------------
# C-107 — ETPR sur forfait soins > 0
# ---------------------------------------------------------------------------


@register("C-107")
async def c_107(ctx: ControlContext) -> ControleResult:
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    forfait = [r for r in rows if r.get("section_imputation") == "forfait_soins"]
    if not forfait:
        return not_applicable("Aucune ligne section_imputation='forfait_soins' — non-applicable.")
    total = _sum_field(forfait, "etpr_realises")
    if total > _ZERO:
        return ok(f"ETPR forfait soins = {total} > 0", valeur=serialize_amount(total))
    return ko(
        f"ETPR forfait soins > 0 attendu — valeur observée {total}",
        valeur=serialize_amount(total),
    )


# ---------------------------------------------------------------------------
# C-108 — ETPR sur forfait soins < ETPR global
# ---------------------------------------------------------------------------


@register("C-108")
async def c_108(ctx: ControlContext) -> ControleResult:
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    total_global = _sum_field(rows, "etpr_realises")
    forfait_rows = [r for r in rows if r.get("section_imputation") == "forfait_soins"]
    if not forfait_rows:
        return not_applicable("Pas de section forfait_soins — non-applicable.")
    total_forfait = _sum_field(forfait_rows, "etpr_realises")
    if total_forfait <= total_global:
        return ok(
            f"ETPR forfait soins {total_forfait} < global {total_global}",
            forfait=serialize_amount(total_forfait),
            global_=serialize_amount(total_global),
        )
    return ko(
        f"ETPR forfait soins ({total_forfait}) > global ({total_global}) — " f"incohérence",
        forfait=serialize_amount(total_forfait),
        global_=serialize_amount(total_global),
    )


# ---------------------------------------------------------------------------
# C-109 — Rémunérations globales salariés > 0
# ---------------------------------------------------------------------------


@register("C-109")
async def c_109(ctx: ControlContext) -> ControleResult:
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    total = _sum_field(rows, "remunerations_realisees")
    if total > _ZERO:
        return ok(
            f"Rémunérations globales = {total}€ > 0",
            valeur=serialize_amount(total),
        )
    return ko(
        f"Rémunérations globales > 0 attendu — valeur observée {total}€",
        valeur=serialize_amount(total),
    )


# ---------------------------------------------------------------------------
# C-110 — Rémunérations globales AS-AMP-AES > 0
# ---------------------------------------------------------------------------


@register("C-110")
async def c_110(ctx: ControlContext) -> ControleResult:
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    family = {"AS", "AMP", "AES", "aide_soignant", "aide_medico_psy", "accompagnant"}
    matching = [
        r for r in rows if any(tag.lower() in (r.get("fonction") or "").lower() for tag in family)
    ]
    if not matching:
        return not_applicable("Aucune ligne fonction AS/AMP/AES.")
    total = _sum_field(matching, "remunerations_realisees")
    if total > _ZERO:
        return ok(
            f"Rémunérations AS-AMP-AES = {total}€ > 0",
            valeur=serialize_amount(total),
        )
    return ko(
        f"Rémunérations AS-AMP-AES > 0 attendu — valeur observée {total}€",
        valeur=serialize_amount(total),
    )


# ---------------------------------------------------------------------------
# C-111 — Rémunérations globales = Σ rémunérations par section
# ---------------------------------------------------------------------------


@register("C-111")
async def c_111(ctx: ControlContext) -> ControleResult:
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    total_global = _sum_field(rows, "remunerations_realisees")
    by_section: dict[str, Decimal] = {}
    for r in rows:
        section = r.get("section_imputation")
        if section is None:
            continue
        val = r.get("remunerations_realisees")
        if val is not None:
            by_section[section] = by_section.get(section, _ZERO) + Decimal(str(val))
    total_sections = sum(by_section.values(), _ZERO)
    ecart = abs(total_global - total_sections)
    if ecart <= Decimal("0.01"):
        return ok(
            f"Σ rémunérations sections = global ({total_global}€)",
            total_global=serialize_amount(total_global),
            total_sections=serialize_amount(total_sections),
        )
    return ko(
        f"Σ rémunérations sections ({total_sections}€) ≠ global "
        f"({total_global}€) — écart {ecart}€",
        total_global=serialize_amount(total_global),
        total_sections=serialize_amount(total_sections),
        ecart=serialize_amount(ecart),
    )


# ---------------------------------------------------------------------------
# C-112 — Écart réalisé/prévisionnel ETPR > ±10%
# ---------------------------------------------------------------------------


@register("C-112")
async def c_112(ctx: ControlContext) -> ControleResult:
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    realise = _sum_field(rows, "etpr_realises")
    prevu = _sum_field(rows, "etpr_prevus")
    if prevu == _ZERO:
        return not_applicable("ETPR prévus = 0 — taux d'écart non calculable.")
    ecart_pct = abs(realise - prevu) / prevu
    if ecart_pct <= _TEN_PCT:
        return ok(
            f"Écart ETPR réalisé/prévu = {ecart_pct * 100:.2f}% ≤ 10%",
            realise=serialize_amount(realise),
            prevu=serialize_amount(prevu),
            ecart_pct=float(ecart_pct),
        )
    return ko(
        f"Écart ETPR réalisé/prévu = {ecart_pct * 100:.2f}% > 10% (atypie)",
        realise=serialize_amount(realise),
        prevu=serialize_amount(prevu),
        ecart_pct=float(ecart_pct),
    )


# ---------------------------------------------------------------------------
# C-113 — Écart réalisé/prévisionnel rémunérations > ±10%
# ---------------------------------------------------------------------------


@register("C-113")
async def c_113(ctx: ControlContext) -> ControleResult:
    rows = _filter_type(await _load_ter_lignes(ctx), "TER")
    if not rows:
        return not_applicable("Aucune ligne TER saisie.")
    realise = _sum_field(rows, "remunerations_realisees")
    prevu = _sum_field(rows, "remunerations_prevues")
    if prevu == _ZERO:
        return not_applicable("Rémunérations prévues = 0 — taux non calculable.")
    ecart_pct = abs(realise - prevu) / prevu
    if ecart_pct <= _TEN_PCT:
        return ok(
            f"Écart rémunérations réalisé/prévu = {ecart_pct * 100:.2f}% ≤ 10%",
            realise=serialize_amount(realise),
            prevu=serialize_amount(prevu),
            ecart_pct=float(ecart_pct),
        )
    return ko(
        f"Écart rémunérations réalisé/prévu = {ecart_pct * 100:.2f}% > 10% (atypie)",
        realise=serialize_amount(realise),
        prevu=serialize_amount(prevu),
        ecart_pct=float(ecart_pct),
    )
