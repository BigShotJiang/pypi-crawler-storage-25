"""Repository for ``compta_esms.documents_budgetaires``.

Beyond the usual list/get/create/update/delete, this module exposes
two specialized helpers :

* :func:`create_with_default_crpp` — inserts the document **and** its
  default CRPP in a single transaction (D-073). The SDK's
  :func:`piilot.sdk.db.cursor` context manager wraps both writes in
  one transaction, so a failure on the CRPP insert rolls back the
  document insert too.
* :func:`load_parent_for_clone` — fetches the parent doc with the
  fields the clone service needs (exercice_id, type_document) so the
  service can validate "parent is EPRD" without a second round trip.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "exercice_id",
    "type_document",
    "cadre_version",
    "parent_id",
    "statut",
    "periode_observation_debut",
    "periode_observation_fin",
    "transmis_at",
    "executoire_at",
    "transmis_par_user_id",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

# PATCH /documents accepts very few fields — workflow-driven changes
# (statut, transmis_at, executoire_at, transmis_par_user_id) live in §X.
_UPDATABLE: frozenset[str] = frozenset(
    {"cadre_version", "periode_observation_debut", "periode_observation_fin"}
)


def list_documents(
    company_id: UUID,
    *,
    type_document: str | None = None,
    statut: str | None = None,
    annee: int | None = None,
    og_id: UUID | None = None,
) -> list[dict[str, Any]]:
    """Filter-aware list. JOINs ``exercices`` for ``annee`` / ``og_id`` filters.

    The L2 spec advertises ``?type``, ``?statut`` and ``?annee`` ; we
    also accept ``?og_id`` because a cabinet dashboard regularly wants
    "all documents of OG X across years" and adding a query parameter
    later is cheaper than refactoring the route.
    """
    where = ["d.company_id = %s"]
    params: list[Any] = [str(company_id)]
    needs_exercice_join = annee is not None or og_id is not None

    if type_document is not None:
        where.append("d.type_document = %s")
        params.append(type_document)
    if statut is not None:
        where.append("d.statut = %s")
        params.append(statut)
    if annee is not None:
        where.append("e.annee = %s")
        params.append(annee)
    if og_id is not None:
        where.append("e.og_id = %s")
        params.append(str(og_id))

    join_sql = "JOIN compta_esms.exercices e ON e.id = d.exercice_id" if needs_exercice_join else ""
    select_cols = ", ".join(f"d.{c}" for c in _COLUMNS)

    sql = (
        f"SELECT {select_cols} FROM compta_esms.documents_budgetaires d "
        f"{join_sql} "
        f"WHERE {' AND '.join(where)} "
        "ORDER BY d.created_at DESC"
    )
    with cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def get_by_id(doc_id: UUID) -> dict[str, Any] | None:
    """Return a single document (RLS-scoped)."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.documents_budgetaires " "WHERE id = %s",
            (str(doc_id),),
        )
        return cur.fetchone()


def load_parent_for_clone(
    parent_id: UUID,
) -> dict[str, Any] | None:
    """Fetch only the fields the clone service needs.

    Returns ``{id, company_id, exercice_id, type_document, statut}`` or
    None. ``statut`` is included for §V DM ``is_simultaneous`` audit
    flag (KB23 §2.6 — dépôt simultané quand parent != 'executoire').
    """
    with cursor() as cur:
        cur.execute(
            "SELECT id, company_id, exercice_id, type_document, statut "
            "FROM compta_esms.documents_budgetaires WHERE id = %s",
            (str(parent_id),),
        )
        return cur.fetchone()


def list_crs_of_document(document_id: UUID) -> list[dict[str, Any]]:
    """Return the CRs of a document (used by §V clone DM with CR inheritance).

    Order matches the user-defined CR ordering so the clone preserves
    the visual order. Returns the columns needed to recreate the CRs in
    the clone : ``cr_type``, ``cr_variante``, ``denomination``,
    ``cr_identifiant``, ``etablissement_id``, ``finess_rattachement``,
    ``capacite_installee``, ``amplitude_ouverture``, ``ventilation``,
    ``ordre``.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT cr_type, cr_variante, denomination, cr_identifiant, "
            "       etablissement_id, finess_rattachement, capacite_installee, "
            "       amplitude_ouverture, ventilation, ordre "
            "FROM compta_esms.comptes_resultat "
            "WHERE document_id = %s "
            "ORDER BY ordre, created_at",
            (str(document_id),),
        )
        return cur.fetchall()


def load_dm_parent_ets_distincts(dm_id: UUID) -> dict[str, Any] | None:
    """Return ``{parent_eprd_id, ets_ids: set[UUID]}`` for a DM, or None
    if the document is not a DM or has no parent.

    Used by §V guards on CR mutations (D-063 immutable périmètre) :
    a CR on a DM must reference an ``etablissement_id`` that appears
    in the parent EPRD's CR list. Pure SET semantics — duplicates and
    NULLs are filtered out (NULL ``etablissement_id`` is allowed in CR
    but doesn't constrain the DM perimeter).
    """
    with cursor() as cur:
        cur.execute(
            "SELECT parent_id FROM compta_esms.documents_budgetaires "
            "WHERE id = %s AND type_document = 'dm'",
            (str(dm_id),),
        )
        row = cur.fetchone()
        if row is None or row["parent_id"] is None:
            return None
        parent_id = row["parent_id"]
        cur.execute(
            "SELECT DISTINCT etablissement_id FROM compta_esms.comptes_resultat "
            "WHERE document_id = %s AND etablissement_id IS NOT NULL",
            (str(parent_id),),
        )
        ets_ids = {r["etablissement_id"] for r in cur.fetchall()}
    return {"parent_eprd_id": parent_id, "ets_ids": ets_ids}


def clone_with_cr_inheritance(
    *,
    company_id: UUID,
    exercice_id: UUID,
    type_document: str,
    cadre_version: str,
    parent_id: UUID,
    periode_observation_debut: Any | None,
    periode_observation_fin: Any | None,
    parent_crs: list[dict[str, Any]],
) -> dict[str, Any]:
    """Atomic INSERT du DM/RIA + copie des CRs du parent (§V D-063).

    Pattern aligné sur :func:`create_with_default_crpp` — 1 cursor()
    enveloppe document INSERT + N CR INSERTs, roll-back complet si
    n'importe lequel échoue. Pas d'auto-CRPP par défaut — c'est la
    liste ``parent_crs`` qui définit le périmètre hérité (KB23 §2.3).
    """
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.documents_budgetaires "
            "(company_id, exercice_id, type_document, cadre_version, "
            " parent_id, statut, periode_observation_debut, "
            " periode_observation_fin) "
            "VALUES (%s, %s, %s, %s, %s, 'brouillon', %s, %s) "
            f"RETURNING {_COLUMNS_SQL}",
            (
                str(company_id),
                str(exercice_id),
                type_document,
                cadre_version,
                str(parent_id),
                periode_observation_debut,
                periode_observation_fin,
            ),
        )
        doc = cur.fetchone()

        # Copie des CRs du parent (D-063 héritage immutable du périmètre).
        # Pas copier les crp_lignes (différé v0.3 si demande "pré-remplir
        # lignes inchangées"). Le DM démarre avec un cadre vide où le
        # cabinet saisit les modifications.
        for cr in parent_crs:
            cur.execute(
                "INSERT INTO compta_esms.comptes_resultat "
                "(company_id, document_id, cr_type, cr_variante, "
                " denomination, cr_identifiant, etablissement_id, "
                " finess_rattachement, capacite_installee, "
                " amplitude_ouverture, ventilation, ordre) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (
                    str(company_id),
                    str(doc["id"]),
                    cr["cr_type"],
                    cr["cr_variante"],
                    cr["denomination"],
                    cr["cr_identifiant"],
                    str(cr["etablissement_id"]) if cr["etablissement_id"] else None,
                    cr["finess_rattachement"],
                    cr["capacite_installee"],
                    cr["amplitude_ouverture"],
                    cr["ventilation"],
                    cr["ordre"],
                ),
            )
        return doc


def find_errd_n_minus_1_for_ria(ria_id: UUID, company_id: UUID) -> dict[str, Any] | None:
    """Return the ERRD of year N-1 for the same OG, if executoire-grade.

    Helper §W RIA Synthèse résultats (D-065). The "Résultat comptable N-1"
    column on the synthese-resultats sheet pulls from the ERRD finalised
    just before the current exercice. We look up via JOIN through
    ``exercices`` (same ``og_id``, ``annee = ria_annee - 1``) and we
    accept the ERRD only if its statut is ``executoire`` or
    ``affectation_definie`` — earlier statuts mean the result column
    isn't yet meaningful and we'd rather report ``null`` than half-baked
    figures.

    Returns ``{id, exercice_id, statut}`` or None if no ERRD matches.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT errd.id, errd.exercice_id, errd.statut "
            "FROM compta_esms.documents_budgetaires ria "
            "JOIN compta_esms.exercices ria_e ON ria_e.id = ria.exercice_id "
            "JOIN compta_esms.exercices errd_e "
            "  ON errd_e.og_id = ria_e.og_id "
            "  AND errd_e.annee = ria_e.annee - 1 "
            "JOIN compta_esms.documents_budgetaires errd "
            "  ON errd.exercice_id = errd_e.id "
            "  AND errd.type_document = 'errd' "
            "  AND errd.statut IN ('executoire', 'affectation_definie') "
            "WHERE ria.id = %s AND ria.company_id = %s "
            "ORDER BY errd.executoire_at DESC NULLS LAST, errd.updated_at DESC "
            "LIMIT 1",
            (str(ria_id), str(company_id)),
        )
        return cur.fetchone()


def exercice_lookup(exercice_id: UUID) -> dict[str, Any] | None:
    """Return ``{id, company_id, og_id, annee}`` for the parent exercice.

    Used by the service to verify the exercice exists in the caller's
    company before creating a document, and to derive a default
    ``cadre_version`` from ``annee``.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT id, company_id, og_id, annee " "FROM compta_esms.exercices WHERE id = %s",
            (str(exercice_id),),
        )
        return cur.fetchone()


def create_without_crpp(
    *,
    company_id: UUID,
    exercice_id: UUID,
    type_document: str,
    cadre_version: str,
    parent_id: UUID | None,
    periode_observation_debut: Any | None,
    periode_observation_fin: Any | None,
) -> dict[str, Any]:
    """Atomic INSERT of the document without auto-CRPP.

    Used by §X for ERCP/EPCP : D-060 forbids CRP PRINCIPAL on these
    sanitary documents — the cabinet creates its own CRPA/CRA_SF/CRP_SF
    explicitly via the CR endpoints. Same INSERT path as the default
    create, just without the second INSERT for CRPP.
    """
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.documents_budgetaires "
            "(company_id, exercice_id, type_document, cadre_version, "
            " parent_id, statut, periode_observation_debut, "
            " periode_observation_fin) "
            "VALUES (%s, %s, %s, %s, %s, 'brouillon', %s, %s) "
            f"RETURNING {_COLUMNS_SQL}",
            (
                str(company_id),
                str(exercice_id),
                type_document,
                cadre_version,
                str(parent_id) if parent_id else None,
                periode_observation_debut,
                periode_observation_fin,
            ),
        )
        return cur.fetchone()


def create_with_default_crpp(
    *,
    company_id: UUID,
    exercice_id: UUID,
    type_document: str,
    cadre_version: str,
    parent_id: UUID | None,
    periode_observation_debut: Any | None,
    periode_observation_fin: Any | None,
    crpp_denomination: str,
    crpp_variante: str,
) -> dict[str, Any]:
    """Atomic INSERT of the document **and** its default CRPP.

    Both INSERTs share one cursor() — the SDK commits on context exit
    and rolls back on any exception, so a failure to insert the CRPP
    (eg. CHECK violation on cr_variante) discards the document insert
    too. D-073 (auto-création CRPP at document create).
    """
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.documents_budgetaires "
            "(company_id, exercice_id, type_document, cadre_version, "
            " parent_id, statut, periode_observation_debut, "
            " periode_observation_fin) "
            "VALUES (%s, %s, %s, %s, %s, 'brouillon', %s, %s) "
            f"RETURNING {_COLUMNS_SQL}",
            (
                str(company_id),
                str(exercice_id),
                type_document,
                cadre_version,
                str(parent_id) if parent_id else None,
                periode_observation_debut,
                periode_observation_fin,
            ),
        )
        doc = cur.fetchone()

        # Auto-CRPP (D-073). etablissement_id stays NULL — the cabinet
        # binds it via the CR PATCH endpoint (§E.4 / L2 §5.3) once the
        # establishment is picked.
        cur.execute(
            "INSERT INTO compta_esms.comptes_resultat "
            "(company_id, document_id, cr_type, cr_variante, "
            " denomination, ordre) "
            "VALUES (%s, %s, 'CRPP', %s, %s, 0)",
            (
                str(company_id),
                str(doc["id"]),
                crpp_variante,
                crpp_denomination,
            ),
        )
        return doc


def update(doc_id: UUID, payload: dict[str, Any]) -> dict[str, Any] | None:
    """Patch the document. Only the fields in :data:`_UPDATABLE` apply."""
    fields = [c for c in payload if c in _UPDATABLE]
    if not fields:
        return get_by_id(doc_id)
    set_clause = ", ".join(f"{c} = %s" for c in fields)
    values = [payload[c] for c in fields] + [str(doc_id)]
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.documents_budgetaires "
            f"SET {set_clause}, updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def delete(doc_id: UUID) -> bool:
    """Hard delete. Service must check statut='brouillon' first."""
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.documents_budgetaires WHERE id = %s",
            (str(doc_id),),
        )
        return cur.rowcount > 0
