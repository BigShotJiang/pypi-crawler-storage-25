"""Repository for workflow transitions on ``compta_esms.documents_budgetaires`` (§S).

Charges le snapshot complet (statut + 8 colonnes side ajoutées par
migration 013) puis pose la mutation atomique. L'INSERT
``audit_events`` partage le même curseur que l'UPDATE, donc roll-back
au moindre échec — c'est la garantie de cohérence audit demandée par
``kb/05-workflows.md``.

Le repo n'a aucune logique métier (machine d'état, R.314-222, etc.) —
toute la décision vit dans :mod:`workflow_state_machine` (pure) et
:mod:`workflow_service` (orchestration). Le repo se contente de
charger des rows et d'appliquer un patch validé par allowlist.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

from piilot_pack_compta_esms.services.audit_service import record_event_in

_SNAPSHOT_COLS: tuple[str, ...] = (
    "id",
    "company_id",
    "type_document",
    "statut",
    "transmis_at",
    "executoire_at",
    "transmis_par_user_id",
    "approuve_par_ars_at",
    "approuve_par_cd_at",
    "approuve_par_ars_user_id",
    "approuve_par_cd_user_id",
    "rejete_at",
    "rejete_par_autorite",
    "motif_rejet",
    "affectation_definie_at",
)
_SNAPSHOT_SQL = ", ".join(_SNAPSHOT_COLS)

_MUTABLE_COLS: frozenset[str] = frozenset(
    {
        "statut",
        "transmis_at",
        "executoire_at",
        "transmis_par_user_id",
        "approuve_par_ars_at",
        "approuve_par_cd_at",
        "approuve_par_ars_user_id",
        "approuve_par_cd_user_id",
        "rejete_at",
        "rejete_par_autorite",
        "motif_rejet",
        "affectation_definie_at",
    }
)
"""Allowlist passée par le service. Tout autre champ est ignoré (defense
in depth). Pas de ``updated_at`` ici — la clause UPDATE l'ajoute via
``now()`` systématiquement."""


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def load_snapshot(document_id: UUID) -> dict[str, Any] | None:
    """Retourne le snapshot complet du document (15 colonnes), ou None
    si le doc n'existe pas. RLS-scoped par la session SDK."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_SNAPSHOT_SQL} FROM compta_esms.documents_budgetaires WHERE id = %s",
            (str(document_id),),
        )
        return cur.fetchone()


def load_equilibre_context(document_id: UUID) -> dict[str, Any] | None:
    """Charge le contexte nécessaire au choix réel/strict + données
    d'enrichissement guard.

    Retourne ``{type_document, nature_juridique, any_inclus_cpom}`` ou
    None si le doc/og n'existe pas.

    ``nature_juridique`` est lu directement sur l'OG (5 valeurs UPPER
    DGCS, migration 021 §BC) et passé tel quel à
    :func:`finance.equilibre_validator.choose_equilibre_type` qui
    attend le même Literal ``NatureJuridique``. La couche de mapping
    L1→finance qui existait en v0.2 est supprimée — alignement direct
    spec.

    ``any_inclus_cpom`` = True ssi au moins 1 ETS de l'OG est inclus
    CPOM (colonne ``etablissements.inclus_cpom``). Pattern aligné sur
    :func:`affectation_repo.get_doc_affectation_context` mais simplifié
    (pas besoin de ``all_inclus_cpom`` ni de ``plan_comptable``)."""
    with cursor() as cur:
        cur.execute(
            "SELECT d.type_document, "
            "       og.nature_juridique, "
            "       COALESCE(BOOL_OR(ets.inclus_cpom), false) AS any_inclus_cpom "
            "FROM compta_esms.documents_budgetaires d "
            "JOIN compta_esms.exercices ex ON ex.id = d.exercice_id "
            "JOIN compta_esms.organismes_gestionnaires og ON og.id = ex.og_id "
            "LEFT JOIN compta_esms.etablissements ets ON ets.og_id = og.id "
            "WHERE d.id = %s "
            "GROUP BY d.type_document, og.nature_juridique",
            (str(document_id),),
        )
        row = cur.fetchone()
    if row is None:
        return None
    return {
        "type_document": row["type_document"],
        "nature_juridique": row["nature_juridique"],
        "any_inclus_cpom": bool(row["any_inclus_cpom"]),
    }


# ---------------------------------------------------------------------------
# Mutation atomique : UPDATE + audit_event en 1 transaction
# ---------------------------------------------------------------------------


def apply_transition(
    *,
    document_id: UUID,
    company_id: UUID,
    user_id: UUID,
    patch: dict[str, Any],
    audit_action: str,
    audit_payload: dict[str, Any],
) -> dict[str, Any] | None:
    """UPDATE de ``documents_budgetaires`` + INSERT ``audit_events``
    dans la même cursor() (1 transaction).

    ``patch`` doit déjà être filtré côté service via
    :data:`_MUTABLE_COLS` ; les clés non autorisées sont silencieusement
    ignorées ici (defense in depth — pas de raise pour ne pas masquer
    une erreur de service en prod).

    Retourne le row complet post-UPDATE (15 colonnes du snapshot) ou
    ``None`` si le document n'existait pas."""
    cols = [c for c in patch if c in _MUTABLE_COLS]
    if not cols:
        # Pas de changement — defensive, le service ne devrait pas
        # appeler avec un patch vide.
        return load_snapshot(document_id)

    set_clause = ", ".join(f"{c} = %s" for c in cols)
    values: list[Any] = [patch[c] for c in cols] + [str(document_id)]

    with cursor() as cur:
        cur.execute(
            f"UPDATE compta_esms.documents_budgetaires "
            f"SET {set_clause}, updated_at = now() "
            f"WHERE id = %s "
            f"RETURNING {_SNAPSHOT_SQL}",
            values,
        )
        row = cur.fetchone()
        if row is None:
            return None
        record_event_in(
            cur,
            company_id=company_id,
            user_id=user_id,
            action=audit_action,
            resource_type="document",
            resource_id=document_id,
            payload=audit_payload,
            document_id=document_id,
        )
        return row
