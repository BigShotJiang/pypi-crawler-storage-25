"""Repository for ``compta_esms.organismes_gestionnaires``.

Functions are synchronous; the service layer wraps them via
:func:`piilot.sdk.db.run_in_thread` to keep the RLS user context
propagated across the worker thread.

Column allowlist :data:`_COLUMNS` is the single source of truth for
``SELECT`` projection. Adding a column to the table requires an
explicit edit here — that's intentional, it forces a code review
when a new field becomes API-visible.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "finess_juridique",
    "raison_sociale",
    "nature_juridique",
    "plan_comptable",
    "adresse",
    "cpom_date_effet",
    "representant_legal",
    "representant_qualite",
    "siret",
    "telephone",
    "email",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

# Fields a Create body can populate (everything except DB-generated).
_INSERTABLE: tuple[str, ...] = tuple(
    c for c in _COLUMNS if c not in {"id", "created_at", "updated_at"}
)

# Fields a Patch body can mutate (no id / company_id / timestamps).
_UPDATABLE: frozenset[str] = frozenset(_COLUMNS) - {
    "id",
    "company_id",
    "created_at",
    "updated_at",
}


def list_by_company(company_id: UUID) -> list[dict[str, Any]]:
    """Return all OGs of a company, ordered by raison_sociale.

    Relies on RLS for company isolation as a defense in depth — the
    explicit ``WHERE company_id`` keeps queries clear even if RLS were
    disabled in a dev shell.
    """
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.organismes_gestionnaires "
            "WHERE company_id = %s ORDER BY raison_sociale",
            (str(company_id),),
        )
        return cur.fetchall()


def get_by_id(og_id: UUID) -> dict[str, Any] | None:
    """Return a single OG by id (RLS-scoped) or None if not found."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.organismes_gestionnaires " "WHERE id = %s",
            (str(og_id),),
        )
        return cur.fetchone()


def find_by_finess(company_id: UUID, finess_juridique: str) -> dict[str, Any] | None:
    """Conflict-check helper used by the service before insert/update.

    The DB has ``UNIQUE (company_id, finess_juridique)``; this lookup
    lets the service raise a clean 409 rather than bouncing on a
    ``UniqueViolation``.
    """
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.organismes_gestionnaires "
            "WHERE company_id = %s AND finess_juridique = %s",
            (str(company_id), finess_juridique),
        )
        return cur.fetchone()


def create(company_id: UUID, payload: dict[str, Any]) -> dict[str, Any]:
    """Insert a new OG and return the full row."""
    fields = [c for c in _INSERTABLE if c != "company_id" and c in payload]
    columns = ["company_id"] + fields
    values = [str(company_id)] + [payload[c] for c in fields]
    placeholders = ", ".join(["%s"] * len(columns))
    columns_sql = ", ".join(columns)
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.organismes_gestionnaires "
            f"({columns_sql}) VALUES ({placeholders}) "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def update(og_id: UUID, payload: dict[str, Any]) -> dict[str, Any] | None:
    """Patch an OG. Returns the updated row or None if not found."""
    fields = [c for c in payload if c in _UPDATABLE]
    if not fields:
        # Nothing to update — return current row so the API surface is
        # consistent (the service decides whether to 304/200).
        return get_by_id(og_id)
    set_clause = ", ".join(f"{c} = %s" for c in fields)
    values = [payload[c] for c in fields] + [str(og_id)]
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.organismes_gestionnaires "
            f"SET {set_clause}, updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def delete(og_id: UUID) -> bool:
    """Hard delete an OG. Returns True if a row was deleted.

    Service must check :func:`count_etablissements` first to return a
    clean 409 when the OG still owns établissements.
    """
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.organismes_gestionnaires WHERE id = %s",
            (str(og_id),),
        )
        return cur.rowcount > 0


def count_etablissements(og_id: UUID) -> int:
    """Count direct dependent établissements — used by the service for
    the 409-on-dependencies check before delete."""
    with cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) AS n FROM compta_esms.etablissements " "WHERE og_id = %s",
            (str(og_id),),
        )
        row = cur.fetchone()
        return int(row["n"]) if row else 0


def count_exercices(og_id: UUID) -> int:
    """Count exercices attached to this OG — second dependency check.

    Exercices ``ON DELETE CASCADE`` to the OG in the schema, but a
    cabinet wouldn't want a silent cascade through their accounting
    history; we surface the count and let the service refuse.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) AS n FROM compta_esms.exercices WHERE og_id = %s",
            (str(og_id),),
        )
        row = cur.fetchone()
        return int(row["n"]) if row else 0
