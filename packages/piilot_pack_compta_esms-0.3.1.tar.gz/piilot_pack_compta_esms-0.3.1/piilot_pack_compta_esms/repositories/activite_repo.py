"""Repository for ``compta_esms.activite_lignes`` (§Q, L2 §12).

Sémantique Q1 — **replace_by_(doc, ets, annexe_variante)** : DELETE +
INSERT batch atomique (cohérent §P/§K/§N).

Pour :compute-theorique (Q4 idempotent) : DELETE WHERE
(doc, ets, annexe, nature='theorique') + INSERT batch — pas d'ON
CONFLICT (le DDL n'a pas de UNIQUE constraint sur (doc, ets, annexe,
section, annee_offset, nature) ; le DELETE-by-scope-spécifique-theorique
préserve les lignes prévu/realisé saisies par le cabinet).
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "etablissement_id",
    "annexe_variante",
    "mode_creton",
    "section",
    "gir",
    "annee_offset",
    "nature_donnee",
    "nombre_places",
    "nombre_personnes",
    "nombre_journees",
    "absences_moins72h_convenance",
    "absences_moins72h_hospi",
    "absences_plus72h_convenance",
    "absences_plus72h_hospi",
    "hors_departement_count",
    "beneficiaires_aide_sociale",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def list_by_filter(
    document_id: UUID,
    ets_id: UUID | None = None,
    annexe_variante: str | None = None,
) -> list[dict[str, Any]]:
    """Liste les lignes activité d'un document, optionnellement filtré
    par ETS et/ou annexe_variante.

    Tri stable : annexe_variante, etablissement_id, section, gir
    (NULLS LAST), annee_offset, nature_donnee."""
    sql = f"SELECT {_COLUMNS_SQL} FROM compta_esms.activite_lignes WHERE document_id = %s"
    params: tuple[Any, ...] = (str(document_id),)
    if ets_id is not None:
        sql += " AND etablissement_id = %s"
        params = (*params, str(ets_id))
    if annexe_variante is not None:
        sql += " AND annexe_variante = %s"
        params = (*params, annexe_variante)
    sql += (
        " ORDER BY annexe_variante, etablissement_id, section, gir NULLS LAST, "
        "annee_offset, nature_donnee"
    )
    with cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def document_belongs_to_company(document_id: UUID, company_id: UUID) -> bool:
    """Defense in depth (pattern §H/§J/§K/§M/§N/§P)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def get_ets_capacite(etablissement_id: UUID, company_id: UUID) -> dict[str, Any] | None:
    """Q3 — retourne ``{capacite_financee, amplitude_ouverture}`` pour
    le calcul D-051 (Activité théorique = capacite × amplitude)."""
    with cursor() as cur:
        cur.execute(
            "SELECT capacite_financee, amplitude_ouverture "
            "FROM compta_esms.etablissements "
            "WHERE id = %s AND company_id = %s",
            (str(etablissement_id), str(company_id)),
        )
        return cur.fetchone()


# ---------------------------------------------------------------------------
# Writes — Q1 replace_by_doc_ets_annexe
# ---------------------------------------------------------------------------


def _insert_one(
    cur,
    *,
    company_id: UUID,
    document_id: UUID,
    etablissement_id: UUID,
    annexe_variante: str,
    item: dict[str, Any],
) -> dict[str, Any]:
    """Helper interne : 1 INSERT + RETURNING."""
    values = (
        str(company_id),
        str(document_id),
        str(etablissement_id),
        annexe_variante,
        bool(item.get("mode_creton", False)),
        item["section"],
        item.get("gir"),
        item["annee_offset"],
        item["nature_donnee"],
        item.get("nombre_places"),
        item.get("nombre_personnes"),
        item.get("nombre_journees"),
        item.get("absences_moins72h_convenance"),
        item.get("absences_moins72h_hospi"),
        item.get("absences_plus72h_convenance"),
        item.get("absences_plus72h_hospi"),
        item.get("hors_departement_count"),
        item.get("beneficiaires_aide_sociale"),
    )
    cur.execute(
        "INSERT INTO compta_esms.activite_lignes "
        "(company_id, document_id, etablissement_id, annexe_variante, "
        " mode_creton, section, gir, annee_offset, nature_donnee, "
        " nombre_places, nombre_personnes, nombre_journees, "
        " absences_moins72h_convenance, absences_moins72h_hospi, "
        " absences_plus72h_convenance, absences_plus72h_hospi, "
        " hors_departement_count, beneficiaires_aide_sociale) "
        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, "
        "        %s, %s, %s, %s, %s, %s) "
        f"RETURNING {_COLUMNS_SQL}",
        values,
    )
    return cur.fetchone()


def replace_by_doc_ets_annexe(
    *,
    company_id: UUID,
    document_id: UUID,
    etablissement_id: UUID,
    annexe_variante: str,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """DELETE WHERE doc+ets+annexe + INSERT batch atomique (Q1).

    Ne touche QUE les lignes de l'onglet ciblé (annexe_variante). Les
    autres onglets (autre annexe) ou autres ETS sont préservés. Les
    lignes ``nature_donnee='theorique'`` sont aussi écrasées par cet
    appel — le cabinet qui rebulk-upsert un onglet doit éventuellement
    relancer :compute-theorique après."""
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.activite_lignes "
            "WHERE document_id = %s AND etablissement_id = %s "
            "  AND annexe_variante = %s",
            (str(document_id), str(etablissement_id), annexe_variante),
        )
        for item in items:
            out.append(
                _insert_one(
                    cur,
                    company_id=company_id,
                    document_id=document_id,
                    etablissement_id=etablissement_id,
                    annexe_variante=annexe_variante,
                    item=item,
                )
            )
    return out


# ---------------------------------------------------------------------------
# Writes — Q4 :compute-theorique (idempotent DELETE+INSERT par scope)
# ---------------------------------------------------------------------------


def replace_theorique_by_doc_ets_annexe(
    *,
    company_id: UUID,
    document_id: UUID,
    etablissement_id: UUID,
    annexe_variante: str,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Q4 idempotent — DELETE les lignes ``nature='theorique'`` du
    scope (doc, ets, annexe) + INSERT batch.

    Préserve les lignes ``nature IN ('prevu', 'realise')`` saisies par
    le cabinet. Toutes les ``items`` portent ``nature_donnee='theorique'``
    (forcé par le service appelant)."""
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.activite_lignes "
            "WHERE document_id = %s AND etablissement_id = %s "
            "  AND annexe_variante = %s AND nature_donnee = 'theorique'",
            (str(document_id), str(etablissement_id), annexe_variante),
        )
        for item in items:
            out.append(
                _insert_one(
                    cur,
                    company_id=company_id,
                    document_id=document_id,
                    etablissement_id=etablissement_id,
                    annexe_variante=annexe_variante,
                    item=item,
                )
            )
    return out
