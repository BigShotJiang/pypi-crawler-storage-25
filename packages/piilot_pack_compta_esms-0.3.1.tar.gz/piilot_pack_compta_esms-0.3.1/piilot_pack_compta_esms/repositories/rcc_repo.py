"""Repository for ``compta_esms.rcc_lignes`` (§N, L2 §16.5-§16.7).

Sémantique Q5 — **replace_all_by_document** : DELETE WHERE doc +
INSERT batch atomique (pattern §M).

``repartition_json`` est un JSONB côté DDL (§D.9 ligne 599). Wrappé
via :func:`piilot.sdk.db.Json` adapter (avec fallback ``json.dumps``
pour le test stub), même pattern que ``kb_binding_repo`` et
``balance_import_repo``.
"""

from __future__ import annotations

import json
from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

try:
    from piilot.sdk.db import Json
except ImportError:  # pragma: no cover — defensive, the SDK ships it
    Json = None  # type: ignore[assignment]


def _wrap_jsonb(value: Any) -> Any:
    """Adapter for psycopg2 JSONB params. Same fallback as the rest of
    the repository layer — see ``balance_import_repo._wrap_jsonb``."""
    if Json is not None:
        return Json(value)
    return json.dumps(value)


_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "compte_m22bis",
    "libelle",
    "montant_total",
    "cle_repartition",
    "repartition_json",
    "is_frais_siege",
    "is_quote_part_commune",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def list_by_document(document_id: UUID) -> list[dict[str, Any]]:
    """Liste les lignes RCC d'un document. Tri stable : compte_m22bis."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.rcc_lignes "
            "WHERE document_id = %s "
            "ORDER BY compte_m22bis",
            (str(document_id),),
        )
        return cur.fetchall()


def document_belongs_to_company(document_id: UUID, company_id: UUID) -> bool:
    """Defense in depth (pattern §H/§J/§K/§M)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


# ---------------------------------------------------------------------------
# Writes
# ---------------------------------------------------------------------------


def _coerce_decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def _repartition_to_jsonb(repartition: dict[Any, Any]) -> dict[str, Any]:
    """Normalise ``{UUID: {pct, montant}}`` → ``{str(uuid): {pct: str,
    montant: str}}`` pour stockage JSONB. Les Decimal sont convertis
    en string pour préserver la précision (PG les retournera tels
    quels au SELECT)."""
    out: dict[str, Any] = {}
    for cr_id, entry in (repartition or {}).items():
        key = str(cr_id)
        if hasattr(entry, "model_dump"):
            entry = entry.model_dump(mode="json")
        out[key] = {
            "pct": str(entry["pct"]) if entry.get("pct") is not None else "0",
            "montant": str(entry["montant"]) if entry.get("montant") is not None else "0",
        }
    return out


def replace_all_by_document(
    *,
    company_id: UUID,
    document_id: UUID,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """DELETE WHERE doc + INSERT batch atomique (Q5)."""
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.rcc_lignes WHERE document_id = %s",
            (str(document_id),),
        )
        for item in items:
            repartition = item.get("repartition") or {}
            values = (
                str(company_id),
                str(document_id),
                item["compte_m22bis"],
                item.get("libelle"),
                _coerce_decimal(item.get("montant_total")),
                item.get("cle_repartition"),
                _wrap_jsonb(_repartition_to_jsonb(repartition)),
                bool(item.get("is_frais_siege", False)),
                bool(item.get("is_quote_part_commune", False)),
            )
            cur.execute(
                "INSERT INTO compta_esms.rcc_lignes "
                "(company_id, document_id, compte_m22bis, libelle, montant_total, "
                " cle_repartition, repartition_json, is_frais_siege, is_quote_part_commune) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) "
                f"RETURNING {_COLUMNS_SQL}",
                values,
            )
            out.append(cur.fetchone())
    return out
