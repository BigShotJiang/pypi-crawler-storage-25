"""Repository for ``compta_esms.annexe5_lignes`` (§R, L2 §13).

Sémantique Q1 — **replace_by_(doc, ets, variante)** : DELETE + INSERT
batch atomique (cohérent §P/§K/§N/§Q).
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "etablissement_id",
    "variante",
    "compte_m22bis",
    "compte_label",
    "nature",
    "montant_hebergement_n1",
    "montant_hebergement_n",
    "montant_dependance_n1",
    "montant_dependance_n",
    "montant_soins_n1",
    "montant_soins_n",
    "montant_sea_n1",
    "montant_sea_n",
    "montant_budget_global_n1",
    "montant_budget_global_n",
    "montant_forfait_soins_n1",
    "montant_forfait_soins_n",
    "montant_soins_sad_n1",
    "montant_soins_sad_n",
    "montant_aide_acc_n1",
    "montant_aide_acc_n",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def list_by_filter(
    document_id: UUID,
    ets_id: UUID | None = None,
    variante: str | None = None,
) -> list[dict[str, Any]]:
    """Liste les lignes Annexe 5 d'un document, optionnellement
    filtré par ets_id + variante. Tri stable : variante, ets,
    nature, compte_m22bis."""
    sql = f"SELECT {_COLUMNS_SQL} FROM compta_esms.annexe5_lignes WHERE document_id = %s"
    params: tuple[Any, ...] = (str(document_id),)
    if ets_id is not None:
        sql += " AND etablissement_id = %s"
        params = (*params, str(ets_id))
    if variante is not None:
        sql += " AND variante = %s"
        params = (*params, variante)
    sql += " ORDER BY variante, etablissement_id, nature, compte_m22bis"
    with cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def document_belongs_to_company(document_id: UUID, company_id: UUID) -> bool:
    """Defense in depth (pattern §H/§J/§K/§M/§N/§P/§Q)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def get_ets_typologie(etablissement_id: UUID, company_id: UUID) -> dict[str, Any] | None:
    """Q6 — retourne ``{typologie}`` pour auto-déduire variante Annexe 5
    via :func:`reference_lookup.deduce_variante_annexe5`."""
    with cursor() as cur:
        cur.execute(
            "SELECT typologie FROM compta_esms.etablissements " "WHERE id = %s AND company_id = %s",
            (str(etablissement_id), str(company_id)),
        )
        return cur.fetchone()


# ---------------------------------------------------------------------------
# Writes — Q1 replace_by_doc_ets_variante
# ---------------------------------------------------------------------------


def _coerce_decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def replace_by_doc_ets_variante(
    *,
    company_id: UUID,
    document_id: UUID,
    etablissement_id: UUID,
    variante: str,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """DELETE WHERE doc+ets+variante + INSERT batch atomique (Q1).

    Ne touche QUE les lignes de l'onglet ciblé. Les autres variantes
    (autre ets ou autre variante du même document) sont préservées."""
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.annexe5_lignes "
            "WHERE document_id = %s AND etablissement_id = %s "
            "  AND variante = %s",
            (str(document_id), str(etablissement_id), variante),
        )
        for item in items:
            values = (
                str(company_id),
                str(document_id),
                str(etablissement_id),
                variante,
                item["compte_m22bis"],
                item.get("compte_label"),
                item["nature"],
                _coerce_decimal(item.get("montant_hebergement_n1")),
                _coerce_decimal(item.get("montant_hebergement_n")),
                _coerce_decimal(item.get("montant_dependance_n1")),
                _coerce_decimal(item.get("montant_dependance_n")),
                _coerce_decimal(item.get("montant_soins_n1")),
                _coerce_decimal(item.get("montant_soins_n")),
                _coerce_decimal(item.get("montant_sea_n1")),
                _coerce_decimal(item.get("montant_sea_n")),
                _coerce_decimal(item.get("montant_budget_global_n1")),
                _coerce_decimal(item.get("montant_budget_global_n")),
                _coerce_decimal(item.get("montant_forfait_soins_n1")),
                _coerce_decimal(item.get("montant_forfait_soins_n")),
                _coerce_decimal(item.get("montant_soins_sad_n1")),
                _coerce_decimal(item.get("montant_soins_sad_n")),
                _coerce_decimal(item.get("montant_aide_acc_n1")),
                _coerce_decimal(item.get("montant_aide_acc_n")),
            )
            cur.execute(
                "INSERT INTO compta_esms.annexe5_lignes "
                "(company_id, document_id, etablissement_id, variante, "
                " compte_m22bis, compte_label, nature, "
                " montant_hebergement_n1, montant_hebergement_n, "
                " montant_dependance_n1, montant_dependance_n, "
                " montant_soins_n1, montant_soins_n, "
                " montant_sea_n1, montant_sea_n, "
                " montant_budget_global_n1, montant_budget_global_n, "
                " montant_forfait_soins_n1, montant_forfait_soins_n, "
                " montant_soins_sad_n1, montant_soins_sad_n, "
                " montant_aide_acc_n1, montant_aide_acc_n) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, "
                "        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) "
                f"RETURNING {_COLUMNS_SQL}",
                values,
            )
            out.append(cur.fetchone())
    return out
