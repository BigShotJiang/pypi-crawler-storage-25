"""Repository for ``compta_esms.balance_imports`` (D-108)."""

from __future__ import annotations

import json
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

# ``Json`` adapter — wired by the SDK loader. We import the symbol
# (the SDK exposes it as a module-level re-export of
# ``psycopg2.extras.Json``) and wrap any dict/list we pass as a
# JSONB parameter so psycopg2 doesn't trip on plain Python dicts.
try:
    from piilot.sdk.db import Json
except ImportError:  # pragma: no cover — defensive, the SDK ships it
    Json = None  # type: ignore[assignment]

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "exercice_id",
    "etablissement_id",
    "source_plan",
    "source_filename",
    "source_storage_key",
    "periode_label",
    "nb_lignes_source",
    "nb_lignes_mappees",
    "nb_lignes_non_mappees",
    "column_detection",
    "preview_data",
    "suggestions",
    "unmapped_accounts",
    "applied_at",
    "mapping_snapshot",
    "materialized_kb_id",
    "materialized_kb_table_name",
    "status",
    "error_payload",
    "imported_by_user_id",
    "imported_at",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


def _wrap_jsonb(value: Any) -> Any:
    """Wrap a dict/list with ``psycopg2.extras.Json`` if available.

    Without this wrapper psycopg2 doesn't know how to adapt a Python
    dict to a JSONB parameter (it serializes the ``repr()``, which
    PG rejects with ``invalid input syntax for type json``). When the
    SDK re-export is missing (tests that stub the wiring) we fall
    back to ``json.dumps`` — the resulting string is also accepted
    by PG as JSON input."""
    if Json is not None:
        return Json(value)
    return json.dumps(value)


def get_by_id(import_id: UUID) -> dict[str, Any] | None:
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.balance_imports " "WHERE id = %s",
            (str(import_id),),
        )
        return cur.fetchone()


def create(
    *,
    company_id: UUID,
    user_id: UUID,
    source_plan: str,
    source_filename: str,
    source_storage_key: str,
    periode_label: str,
    nb_lignes_source: int,
    column_detection: dict[str, Any],
    preview_data: list[list[Any]],
    exercice_id: UUID | None = None,
    etablissement_id: UUID | None = None,
) -> dict[str, Any]:
    """Insert a freshly-uploaded balance import in ``status='pending'``.

    The mapping is still empty at this point ; the cabinet runs
    ``:detect-columns`` (if needed) then triggers the suggestion
    pipeline (§F.4) and finally apply-mapping (§F.5)."""
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.balance_imports "
            "(company_id, exercice_id, etablissement_id, source_plan, "
            " source_filename, source_storage_key, periode_label, "
            " nb_lignes_source, column_detection, preview_data, "
            " status, imported_by_user_id) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'pending', %s) "
            f"RETURNING {_COLUMNS_SQL}",
            (
                str(company_id),
                str(exercice_id) if exercice_id else None,
                str(etablissement_id) if etablissement_id else None,
                source_plan,
                source_filename,
                source_storage_key,
                periode_label,
                nb_lignes_source,
                _wrap_jsonb(column_detection),
                _wrap_jsonb(preview_data),
                str(user_id),
            ),
        )
        return cur.fetchone()


def update_column_detection(import_id: UUID, detection: dict[str, Any]) -> dict[str, Any] | None:
    """Replace the ``column_detection`` payload atomically.

    Called by ``POST .../detect-columns`` after applying user hints
    on top of the auto-detection."""
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.balance_imports "
            "SET column_detection = %s, updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            (_wrap_jsonb(detection), str(import_id)),
        )
        return cur.fetchone()


def update_apply_result(
    import_id: UUID,
    *,
    mapping_snapshot: dict[str, Any],
    unmapped_accounts: list[dict[str, Any]],
    nb_lignes_mappees: int,
    nb_lignes_non_mappees: int,
    status: str,
) -> dict[str, Any] | None:
    """Persist the outcome of an apply-mapping pass.

    Sets ``applied_at = now()`` so the replay endpoint can flag stale
    runs ("Last applied 3 days ago — suggestions changed since")."""
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.balance_imports "
            "SET mapping_snapshot = %s, "
            "    unmapped_accounts = %s, "
            "    nb_lignes_mappees = %s, "
            "    nb_lignes_non_mappees = %s, "
            "    status = %s, "
            "    applied_at = now(), "
            "    updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            (
                _wrap_jsonb(mapping_snapshot),
                _wrap_jsonb(unmapped_accounts),
                nb_lignes_mappees,
                nb_lignes_non_mappees,
                status,
                str(import_id),
            ),
        )
        return cur.fetchone()


def update_materialized_kb(
    import_id: UUID,
    *,
    kb_id: UUID,
    kb_table_name: str | None,
) -> dict[str, Any] | None:
    """Pin a materialised KB to the import.

    Called once :func:`balance_apply_service.materialize_kb` has
    finished creating the plugin-owned KB + inserting the rows. Flips
    the import's ``status`` to ``'completed'`` (the apply pass might
    have left it ``'partial'`` when there were unmapped accounts ; once
    the cabinet has manually mapped them and re-materialised, completion
    is the right semantics)."""
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.balance_imports "
            "SET materialized_kb_id = %s, "
            "    materialized_kb_table_name = %s, "
            "    status = 'completed', "
            "    updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            (str(kb_id), kb_table_name, str(import_id)),
        )
        return cur.fetchone()


def list_history(
    company_id: UUID,
    *,
    exercice_id: UUID | None = None,
    etablissement_id: UUID | None = None,
    status: str | None = None,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """List balance imports for the history endpoint.

    Filters are AND-joined. Default ``limit=20`` mirrors the L2 spec ;
    we cap at 200 in the route to keep the listing responsive."""
    where = ["company_id = %s"]
    params: list[Any] = [str(company_id)]
    if exercice_id is not None:
        where.append("exercice_id = %s")
        params.append(str(exercice_id))
    if etablissement_id is not None:
        where.append("etablissement_id = %s")
        params.append(str(etablissement_id))
    if status is not None:
        where.append("status = %s")
        params.append(status)
    sql = (
        f"SELECT {_COLUMNS_SQL} FROM compta_esms.balance_imports "
        f"WHERE {' AND '.join(where)} "
        "ORDER BY imported_at DESC LIMIT %s"
    )
    params.append(limit)
    with cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def delete(import_id: UUID) -> bool:
    """Hard delete a balance_imports row.

    The associated materialised KB (when present) is **not** dropped
    by this call ; the service decides based on the ``?delete_kb=``
    query param. The S3 file is also left untouched — a later janitor
    job (out of §F.5) can sweep ``compta_esms.balance_imports``
    deletes and clean ``balance_imports/{id}/*`` accordingly."""
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.balance_imports WHERE id = %s",
            (str(import_id),),
        )
        return cur.rowcount > 0


def update_suggestions(import_id: UUID, suggestions: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Replace the ``suggestions`` JSONB array atomically.

    Called at the end of the §F.4 ``:suggest-mappings`` pipeline. The
    array carries one entry per distinct source account, each with a
    list of scored targets (cf. migration 007 docstring for the
    shape)."""
    with cursor() as cur:
        cur.execute(
            "SELECT id, suggestions FROM compta_esms.balance_imports " "WHERE id = %s",
            (str(import_id),),
        )
        if cur.fetchone() is None:
            return None
        cur.execute(
            "UPDATE compta_esms.balance_imports "
            "SET suggestions = %s, updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            (_wrap_jsonb(suggestions), str(import_id)),
        )
        return cur.fetchone()
