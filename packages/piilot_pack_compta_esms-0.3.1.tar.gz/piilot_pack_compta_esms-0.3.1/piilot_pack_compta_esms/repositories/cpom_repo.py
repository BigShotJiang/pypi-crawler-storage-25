"""Repository for ``compta_esms.esms_cpom`` — §BA v0.3 (D-027).

Sync functions wrapped by the service layer in
:func:`piilot.sdk.db.run_in_thread`. RLS is enforced at the DB layer
(migration 019) — explicit ``WHERE company_id`` here is defense in
depth.

Column allowlist :data:`_COLUMNS` is the single source of truth for
``SELECT`` projection — adding a column to the table requires an
explicit edit here.
"""

from __future__ import annotations

from datetime import date
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "og_id",
    "numero",
    "date_signature",
    "date_effet",
    "duree_annees",
    "date_fin_theorique",
    "categorie",
    "cosignataires",
    "est_proroge",
    "motif_prorogation",
    "libre_affectation_resultats_o_n",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

# ``og_id`` is set at create-time from the route path and never
# mutable (re-parenting would break cpom_esms_link consistency).
# ``date_fin_theorique`` is a derived value written by the service.
_INSERTABLE: tuple[str, ...] = tuple(
    c for c in _COLUMNS if c not in {"id", "created_at", "updated_at"}
)

_UPDATABLE: frozenset[str] = frozenset(_COLUMNS) - {
    "id",
    "company_id",
    "og_id",
    "created_at",
    "updated_at",
}


def list_by_og(og_id: UUID) -> list[dict[str, Any]]:
    """Return all CPOMs of an OG, ordered by descending ``date_effet``
    (most recent contract first — UI default sort)."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.esms_cpom "
            "WHERE og_id = %s ORDER BY date_effet DESC",
            (str(og_id),),
        )
        return cur.fetchall()


def get_by_id(cpom_id: UUID) -> dict[str, Any] | None:
    """Return a single CPOM by id (RLS-scoped) or None if not found."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.esms_cpom WHERE id = %s",
            (str(cpom_id),),
        )
        return cur.fetchone()


def create(company_id: UUID, og_id: UUID, payload: dict[str, Any]) -> dict[str, Any]:
    """Insert a new CPOM and return the full row.

    ``company_id`` and ``og_id`` come from the route path and the
    auth context — they are not read from the body. The service must
    have called :func:`og_repo.get_by_id` first so the FK insert
    doesn't bounce on a foreign-key violation.
    """
    fields = [c for c in _INSERTABLE if c not in {"company_id", "og_id"} and c in payload]
    columns = ["company_id", "og_id"] + fields
    values: list[Any] = [str(company_id), str(og_id)] + [payload[c] for c in fields]
    placeholders = ", ".join(["%s"] * len(columns))
    columns_sql = ", ".join(columns)
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.esms_cpom "
            f"({columns_sql}) VALUES ({placeholders}) "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def update(cpom_id: UUID, payload: dict[str, Any]) -> dict[str, Any] | None:
    """Patch a CPOM. Returns the updated row or None if not found.

    The service is expected to have already recomputed
    ``date_fin_theorique`` whenever ``date_effet`` or ``duree_annees``
    appears in ``payload``.
    """
    fields = [c for c in payload if c in _UPDATABLE]
    if not fields:
        return get_by_id(cpom_id)
    set_clause = ", ".join(f"{c} = %s" for c in fields)
    values = [payload[c] for c in fields] + [str(cpom_id)]
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.esms_cpom "
            f"SET {set_clause}, updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def delete(cpom_id: UUID) -> bool:
    """Hard delete a CPOM. Returns True if a row was removed.

    Both ``cpom_esms_link`` and ``cpom_objectifs`` ``ON DELETE
    CASCADE`` to the CPOM — the service surfaces a confirmation
    payload to the UI before calling this.
    """
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.esms_cpom WHERE id = %s",
            (str(cpom_id),),
        )
        return cur.rowcount > 0


def og_exists_for_company(og_id: UUID, company_id: UUID) -> bool:
    """Defense-in-depth check that the path's ``og_id`` belongs to
    the caller's tenant. The service calls this before inserting a
    CPOM so we return a clean 404 instead of an RLS-induced silent
    no-op.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.organismes_gestionnaires "
            "WHERE id = %s AND company_id = %s",
            (str(og_id), str(company_id)),
        )
        return cur.fetchone() is not None


def find_active_cpoms_for_og_on_date(og_id: UUID, target_date: date) -> list[dict[str, Any]]:
    """Return every CPOM of an OG that is active on ``target_date``.

    A CPOM is active when ``date_effet <= target_date <
    date_fin_theorique``. Used by
    :func:`cpom_service.is_etablissement_in_cpom` (§BD pre-req).
    The half-open interval matches the legal semantics — the
    contract ends on its theorical end date but doesn't include it.
    """
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.esms_cpom "
            "WHERE og_id = %s "
            "  AND date_effet <= %s "
            "  AND date_fin_theorique > %s "
            "ORDER BY date_effet DESC",
            (str(og_id), target_date, target_date),
        )
        return cur.fetchall()
