"""Repository for ``compta_esms.provisions_lignes`` (§N, L2 §16.1-§16.2).

Sémantique Q3 — **replace_all_by_document** : DELETE WHERE doc +
INSERT batch atomique (pattern §M). Le tableau provisions est un
tout cohérent (~30-50 lignes max, 4 catégories D-099).

``montant_fin_n`` est ``GENERATED ALWAYS AS (montant_debut_n +
dotations - reprises) STORED`` côté DDL (§D.9 ligne 546). On ne l'écrit
jamais — PG la calcule.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "categorie",
    "cr_id",
    "compte_imputation",
    "objet",
    "montant_debut_n",
    "dotations",
    "reprises",
    "montant_fin_n",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def list_by_document(document_id: UUID) -> list[dict[str, Any]]:
    """Liste les provisions d'un document. Tri stable : categorie,
    compte_imputation."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.provisions_lignes "
            "WHERE document_id = %s "
            "ORDER BY categorie, compte_imputation",
            (str(document_id),),
        )
        return cur.fetchall()


def document_belongs_to_company(document_id: UUID, company_id: UUID) -> bool:
    """Defense in depth (pattern §H/§J/§K/§M)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def totals_by_categorie(document_id: UUID) -> list[dict[str, Any]]:
    """Aggrège par categorie sur les 4 colonnes monétaires.

    ``COALESCE(SUM, 0)`` partout. Tri stable par categorie."""
    with cursor() as cur:
        cur.execute(
            "SELECT categorie, "
            "       COALESCE(SUM(montant_debut_n), 0) AS montant_debut_n, "
            "       COALESCE(SUM(dotations), 0)      AS dotations, "
            "       COALESCE(SUM(reprises), 0)       AS reprises, "
            "       COALESCE(SUM(montant_fin_n), 0)  AS montant_fin_n "
            "FROM compta_esms.provisions_lignes "
            "WHERE document_id = %s "
            "GROUP BY categorie "
            "ORDER BY categorie",
            (str(document_id),),
        )
        return cur.fetchall()


# ---------------------------------------------------------------------------
# Writes
# ---------------------------------------------------------------------------


def _coerce_decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def replace_all_by_document(
    *,
    company_id: UUID,
    document_id: UUID,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """DELETE WHERE doc + INSERT batch atomique (Q3).

    ``montant_fin_n`` non passé — PG la calcule via GENERATED ALWAYS AS.
    """
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.provisions_lignes WHERE document_id = %s",
            (str(document_id),),
        )
        for item in items:
            cr_id = item.get("cr_id")
            values = (
                str(company_id),
                str(document_id),
                item["categorie"],
                str(cr_id) if cr_id else None,
                item["compte_imputation"],
                item.get("objet"),
                _coerce_decimal(item.get("montant_debut_n")),
                _coerce_decimal(item.get("dotations")),
                _coerce_decimal(item.get("reprises")),
            )
            cur.execute(
                "INSERT INTO compta_esms.provisions_lignes "
                "(company_id, document_id, categorie, cr_id, compte_imputation, objet, "
                " montant_debut_n, dotations, reprises) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) "
                f"RETURNING {_COLUMNS_SQL}",
                values,
            )
            out.append(cur.fetchone())
    return out
