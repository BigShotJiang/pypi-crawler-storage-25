"""Repository for ``compta_esms.forfait_parametres`` (§R, L2 §13.3-§13.4).

Sémantique Q7 — **DELETE+INSERT par (doc, ets)** (pattern §Q
:compute-theorique idempotent). Le DDL n'a pas de UNIQUE
(doc, ets) — la migration n'est pas nécessaire car le scope du
DELETE garantit l'idempotence.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "etablissement_id",
    "date_evaluation",
    "nombre_points_gir",
    "nombre_personnes_girees",
    "valeur_point_gir",
    "gmp",
    "pmp",
    "gmps",
    "created_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def list_by_document(document_id: UUID) -> list[dict[str, Any]]:
    """Liste les params forfait d'un document, 1 par ets. Tri stable
    par etablissement_id (NULLS LAST)."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.forfait_parametres "
            "WHERE document_id = %s "
            "ORDER BY etablissement_id NULLS LAST",
            (str(document_id),),
        )
        return cur.fetchall()


def document_belongs_to_company(document_id: UUID, company_id: UUID) -> bool:
    """Defense in depth."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def etablissement_belongs_to_company(etablissement_id: UUID, company_id: UUID) -> bool:
    """Defense in depth — refuse ETS d'un autre tenant (Q8 fail-open
    sur typologie, mais strict sur cross-tenant)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.etablissements " "WHERE id = %s AND company_id = %s",
            (str(etablissement_id), str(company_id)),
        )
        return cur.fetchone() is not None


# ---------------------------------------------------------------------------
# Writes — Q7 DELETE+INSERT par (doc, ets) idempotent
# ---------------------------------------------------------------------------


def _coerce_decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def _coerce_date(value: Any) -> date | None:
    if value is None:
        return None
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value))


def upsert_by_doc_ets(
    *,
    company_id: UUID,
    document_id: UUID,
    etablissement_id: UUID,
    params: dict[str, Any],
) -> dict[str, Any]:
    """DELETE WHERE doc+ets + INSERT 1 row (Q7).

    Idempotent par construction (cohérent pattern §Q :compute-theorique).
    Préserve les params des autres établissements du document."""
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.forfait_parametres "
            "WHERE document_id = %s AND etablissement_id = %s",
            (str(document_id), str(etablissement_id)),
        )
        values = (
            str(company_id),
            str(document_id),
            str(etablissement_id),
            _coerce_date(params.get("date_evaluation")),
            params.get("nombre_points_gir"),
            params.get("nombre_personnes_girees"),
            _coerce_decimal(params.get("valeur_point_gir")),
            _coerce_decimal(params.get("gmp")),
            _coerce_decimal(params.get("pmp")),
            _coerce_decimal(params.get("gmps")),
        )
        cur.execute(
            "INSERT INTO compta_esms.forfait_parametres "
            "(company_id, document_id, etablissement_id, date_evaluation, "
            " nombre_points_gir, nombre_personnes_girees, valeur_point_gir, "
            " gmp, pmp, gmps) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s) "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()
