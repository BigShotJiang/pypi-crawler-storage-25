"""Repository for ``compta_esms.cpom_esms_link`` — §BA v0.3 (D-027).

N:N relation between a CPOM and the establishments of its OG. The
``inclus_dans_perimetre`` text flag separates ESMS sous périmètre
tarifaire CPOM (``OUI``) from ESMS referenced but hors périmètre
(``NON``) — S03 p.10-11.

The cohérence rule "the ETS belongs to the CPOM's OG" is checked at
the service layer (we'd need a cross-table SELECT to enforce it
otherwise; doing it once in the service is cheaper than at every
write).
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "cpom_id",
    "etablissement_id",
    "inclus_dans_perimetre",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

_INSERTABLE: tuple[str, ...] = tuple(
    c for c in _COLUMNS if c not in {"id", "created_at", "updated_at"}
)

# Only the perimetre flag is patchable — re-pointing a link to a
# different cpom/ets would be a delete+create.
_UPDATABLE: frozenset[str] = frozenset({"inclus_dans_perimetre"})


def list_by_cpom(cpom_id: UUID) -> list[dict[str, Any]]:
    """Return all links of a CPOM, ordered by created_at."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.cpom_esms_link "
            "WHERE cpom_id = %s ORDER BY created_at",
            (str(cpom_id),),
        )
        return cur.fetchall()


def list_by_etablissement(etablissement_id: UUID) -> list[dict[str, Any]]:
    """Return all links of an établissement — used by §BD
    :func:`is_etablissement_in_cpom`.

    Ordered descending by created_at so the most recent CPOM rattaché
    appears first.
    """
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.cpom_esms_link "
            "WHERE etablissement_id = %s ORDER BY created_at DESC",
            (str(etablissement_id),),
        )
        return cur.fetchall()


def get_by_cpom_and_ets(cpom_id: UUID, etablissement_id: UUID) -> dict[str, Any] | None:
    """Idempotency-helper — the UNIQUE (cpom_id, etablissement_id) in
    the DDL lets us detect "already linked" before bouncing on a
    ``UniqueViolation``. Returns the existing row or None."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.cpom_esms_link "
            "WHERE cpom_id = %s AND etablissement_id = %s",
            (str(cpom_id), str(etablissement_id)),
        )
        return cur.fetchone()


def get_by_id(link_id: UUID) -> dict[str, Any] | None:
    """Return a single link row by id (RLS-scoped) or None."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.cpom_esms_link " "WHERE id = %s",
            (str(link_id),),
        )
        return cur.fetchone()


def upsert(
    company_id: UUID,
    cpom_id: UUID,
    etablissement_id: UUID,
    inclus_dans_perimetre: str,
) -> dict[str, Any]:
    """Insert a link or refresh ``inclus_dans_perimetre`` if it
    already exists. The DDL UNIQUE (cpom_id, etablissement_id)
    triggers the ON CONFLICT path. Always returns the row.

    Used by ``POST /cpoms/{cpom_id}/etablissements:bulk-link`` which
    accepts a list of (ets_id, perimetre) and re-asserts the desired
    state in one shot.
    """
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.cpom_esms_link "
            "(company_id, cpom_id, etablissement_id, inclus_dans_perimetre) "
            "VALUES (%s, %s, %s, %s) "
            "ON CONFLICT (cpom_id, etablissement_id) DO UPDATE SET "
            "    inclus_dans_perimetre = EXCLUDED.inclus_dans_perimetre, "
            "    updated_at = now() "
            f"RETURNING {_COLUMNS_SQL}",
            (
                str(company_id),
                str(cpom_id),
                str(etablissement_id),
                inclus_dans_perimetre,
            ),
        )
        return cur.fetchone()


def delete_by_cpom_and_ets(cpom_id: UUID, etablissement_id: UUID) -> bool:
    """Unlink an établissement from a CPOM. Returns True if a row
    was removed."""
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.cpom_esms_link "
            "WHERE cpom_id = %s AND etablissement_id = %s",
            (str(cpom_id), str(etablissement_id)),
        )
        return cur.rowcount > 0


def ets_belongs_to_og(etablissement_id: UUID, og_id: UUID) -> bool:
    """Cross-check that the ets to be linked belongs to the CPOM's
    OG. Service helper called before :func:`upsert` to refuse a
    bulk-link that would create a cross-OG link.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.etablissements " "WHERE id = %s AND og_id = %s",
            (str(etablissement_id), str(og_id)),
        )
        return cur.fetchone() is not None


def count_in_perimetre(cpom_id: UUID) -> int:
    """Count ESMS effectively in the CPOM's tarifaire perimeter.

    Used in the dashboard and as a quick consistency check before
    closing a CPOM (zero ESMS dans le périmètre = warning UI).
    """
    with cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) AS n FROM compta_esms.cpom_esms_link "
            "WHERE cpom_id = %s AND inclus_dans_perimetre = 'OUI'",
            (str(cpom_id),),
        )
        row = cur.fetchone()
        return int(row["n"]) if row else 0
