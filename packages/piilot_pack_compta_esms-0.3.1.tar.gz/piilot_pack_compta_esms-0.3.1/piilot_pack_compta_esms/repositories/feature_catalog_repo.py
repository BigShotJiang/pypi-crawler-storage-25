"""Repository for ``compta_esms.feature_catalog``.

The catalog is global — no ``company_id``, no RLS, no UPDATE path.
It's seeded by migration ``003_seed_feature_catalog.sql`` and bumped
via subsequent migrations when contracts evolve (cf. ``contract_version``).
Read-only from the route layer.

``columns_required`` and the typology / doc-type ARRAY columns come
back as native Python ``dict`` / ``list`` thanks to psycopg2's JSON
and array adapters.
"""

from __future__ import annotations

from typing import Any

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "feature_key",
    "label",
    "description",
    "columns_required",
    "is_mandatory",
    "applicable_typologies",
    "applicable_doc_types",
    "plan_comptable_cible",
    "contract_version",
    "ordre",
    "created_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


def list_all(
    *,
    doc_type: str | None = None,
    typologie: str | None = None,
    mandatory_only: bool = False,
) -> list[dict[str, Any]]:
    """Return features filtered by doc_type / typologie.

    Filter semantics (matches L3 E03 mockup) :

    * ``doc_type`` matches when the feature's ``applicable_doc_types``
      array contains the value (or the array is empty — meaning "all
      doc types").
    * ``typologie`` matches when ``applicable_typologies`` contains
      the value, or the array is empty.

    Empty-array-means-all keeps the seed migration short (we only
    list the restrictions) while letting the route layer filter
    naturally per-document.
    """
    where: list[str] = []
    params: list[Any] = []
    if doc_type is not None:
        where.append("(cardinality(applicable_doc_types) = 0 OR %s = ANY(applicable_doc_types))")
        params.append(doc_type)
    if typologie is not None:
        where.append("(cardinality(applicable_typologies) = 0 OR %s = ANY(applicable_typologies))")
        params.append(typologie)
    if mandatory_only:
        where.append("is_mandatory = true")
    where_sql = f"WHERE {' AND '.join(where)}" if where else ""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.feature_catalog "
            f"{where_sql} ORDER BY ordre, feature_key",
            params,
        )
        return cur.fetchall()


def get_by_key(feature_key: str) -> dict[str, Any] | None:
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.feature_catalog WHERE feature_key = %s",
            (feature_key,),
        )
        return cur.fetchone()
