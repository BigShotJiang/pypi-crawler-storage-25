"""Repository — lecture de ``compta_esms.audit_events`` (§AI L2 §22.1).

Side-write hot path lives in :mod:`piilot_pack_compta_esms.services.audit_service`
(``record_event`` / ``record_event_in``). This repo provides the read side
consumed by the admin audit log endpoint.

Column allowlist explicite — la table n'a pas de SELECT * pour ne pas
exposer d'éventuelles colonnes futures sans contrôle.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

# Liste blanche des colonnes retournées — alignée sur le schema
# migration 002:749 (immutables, pas de updated_at).
_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "user_id",
    "document_id",
    "action",
    "resource_type",
    "resource_id",
    "payload",
    "occurred_at",
)
_SELECT_COLUMNS_SQL = ", ".join(_COLUMNS)


def list_by_document(
    document_id: UUID,
    *,
    action_filter: str | None = None,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """Liste les ``audit_events`` d'un document, plus récent en tête.

    Args:
        document_id: UUID du document.
        action_filter: filtre exact sur la colonne ``action`` (ex
            ``"workflow.transmit"``). ``None`` = pas de filtre.
        limit: cap rows retournées (la route enforce [1, 500]).

    Returns:
        Liste de dicts (rows), ordonnée par ``occurred_at DESC``. Les
        UUID sont casted en ``str`` par le DictCursor, ``payload`` est
        un dict (JSONB).
    """
    sql = (
        f"SELECT {_SELECT_COLUMNS_SQL} " "FROM compta_esms.audit_events " "WHERE document_id = %s "
    )
    params: list[Any] = [str(document_id)]

    if action_filter is not None:
        sql += "AND action = %s "
        params.append(action_filter)

    sql += "ORDER BY occurred_at DESC LIMIT %s"
    params.append(int(limit))

    with cursor() as cur:
        cur.execute(sql, tuple(params))
        return cur.fetchall()
