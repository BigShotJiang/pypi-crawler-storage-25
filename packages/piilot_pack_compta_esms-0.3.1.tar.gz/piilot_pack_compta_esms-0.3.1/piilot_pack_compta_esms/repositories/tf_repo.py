"""Repository for ``compta_esms.tf_lignes`` (§M, L2 §15).

Sémantique Q2 — **replace_all_by_document** : DELETE WHERE doc +
INSERT batch atomique. Le TF est un tout cohérent (équilibre global,
50-100 lignes max), pas de PATCH ligne par ligne ni de natural-key
UNIQUE.

Le DDL n'a pas de discriminant ``variante`` (Q1) — ``doc.type_document``
décide quelles colonnes sont remplies (TF=4 colonnes ERRD, TFP=8
colonnes EPRD). Le service amont (§M.3) interroge
:func:`get_doc_type_document` pour décider.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "cote",
    "titre",
    "compte_m22bis",
    "libelle",
    "montant_budget_initial_n1",
    "montant_realisations_n1",
    "montant_previsions_n",
    "montant_realisations_n",
    "montant_nm1",
    "montant_n",
    "montant_np1",
    "montant_np2",
    "montant_np3",
    "montant_np4",
    "montant_np5",
    "montant_np6",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

# Toutes les colonnes monétaires — utilisées par totals_by_titre_cote
# pour construire le SUM dynamique. Pas de discriminant ; le service
# expose seulement les pertinentes selon doc.type_document.
_MONEY_COLUMNS: tuple[str, ...] = (
    "montant_budget_initial_n1",
    "montant_realisations_n1",
    "montant_previsions_n",
    "montant_realisations_n",
    "montant_nm1",
    "montant_n",
    "montant_np1",
    "montant_np2",
    "montant_np3",
    "montant_np4",
    "montant_np5",
    "montant_np6",
)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def list_by_document(document_id: UUID) -> list[dict[str, Any]]:
    """Liste les lignes d'un document. Tri stable : cote, titre
    (NULLS LAST), libelle."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.tf_lignes "
            "WHERE document_id = %s "
            "ORDER BY cote, titre NULLS LAST, libelle",
            (str(document_id),),
        )
        return cur.fetchall()


def document_belongs_to_company(document_id: UUID, company_id: UUID) -> bool:
    """Defense in depth (pattern §H/§J/§K)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def get_doc_type_document(document_id: UUID, company_id: UUID) -> dict[str, Any] | None:
    """Retourne ``{type_document}`` du document — utilisé par le
    service pour décider TF vs TFP (Q1)."""
    with cursor() as cur:
        cur.execute(
            "SELECT type_document FROM compta_esms.documents_budgetaires "
            "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone()


# ---------------------------------------------------------------------------
# Writes — replace all by document (Q2)
# ---------------------------------------------------------------------------


def _coerce_decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def replace_all_by_document(
    *,
    company_id: UUID,
    document_id: UUID,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """DELETE WHERE doc + INSERT batch atomique (Q2).

    Tous les ``items`` sont insérés en 1 transaction. Le TF est un
    tout cohérent — le cabinet renvoie l'intégralité à chaque save.
    """
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.tf_lignes WHERE document_id = %s",
            (str(document_id),),
        )
        for item in items:
            values = (
                str(company_id),
                str(document_id),
                item["cote"],
                item.get("titre"),
                item.get("compte_m22bis"),
                item["libelle"],
                _coerce_decimal(item.get("montant_budget_initial_n1")),
                _coerce_decimal(item.get("montant_realisations_n1")),
                _coerce_decimal(item.get("montant_previsions_n")),
                _coerce_decimal(item.get("montant_realisations_n")),
                _coerce_decimal(item.get("montant_nm1")),
                _coerce_decimal(item.get("montant_n")),
                _coerce_decimal(item.get("montant_np1")),
                _coerce_decimal(item.get("montant_np2")),
                _coerce_decimal(item.get("montant_np3")),
                _coerce_decimal(item.get("montant_np4")),
                _coerce_decimal(item.get("montant_np5")),
                _coerce_decimal(item.get("montant_np6")),
            )
            cur.execute(
                "INSERT INTO compta_esms.tf_lignes "
                "(company_id, document_id, cote, titre, compte_m22bis, libelle, "
                " montant_budget_initial_n1, montant_realisations_n1, "
                " montant_previsions_n, montant_realisations_n, "
                " montant_nm1, montant_n, montant_np1, montant_np2, "
                " montant_np3, montant_np4, montant_np5, montant_np6) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, "
                "        %s, %s, %s, %s, %s, %s) "
                f"RETURNING {_COLUMNS_SQL}",
                values,
            )
            out.append(cur.fetchone())
    return out


# ---------------------------------------------------------------------------
# Aggregates (Q3 + Q4)
# ---------------------------------------------------------------------------


def totals_by_titre_cote(document_id: UUID) -> list[dict[str, Any]]:
    """Aggrège **toutes les colonnes monétaires** par (cote, titre).

    Le service amont (§M.3) ignore les colonnes non pertinentes selon
    ``doc.type_document`` (TF expose 4 cols, TFP en expose 8).

    Tri stable : cote, titre (NULLS LAST). ``COALESCE(SUM, 0)``
    partout pour éviter les NULL en sortie."""
    sum_clauses = ", ".join(f"COALESCE(SUM({col}), 0) AS {col}" for col in _MONEY_COLUMNS)
    with cursor() as cur:
        cur.execute(
            f"SELECT cote, titre, {sum_clauses} "
            "FROM compta_esms.tf_lignes "
            "WHERE document_id = %s "
            "GROUP BY cote, titre "
            "ORDER BY cote, titre NULLS LAST",
            (str(document_id),),
        )
        return cur.fetchall()
