"""Repository for ``compta_esms.cles_repartition_charges_communes`` (§Y, D-057).

Pattern aligné sur le reste du repo layer : fonctions sync, allowlist
explicite, RLS-scoped via ``cursor()``. ``etablissement_id`` est
immutable post-create (l'URL parent l'identifie) ; ``compte_m22bis``
et ``exercice_annee`` aussi (ils composent la clé naturelle UNIQUE).
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "etablissement_id",
    "compte_m22bis",
    "exercice_annee",
    "taux_hebergement",
    "taux_dependance",
    "taux_soins",
    "taux_soins_autonomie",
    "source",
    "notes",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

_INSERTABLE: tuple[str, ...] = (
    "etablissement_id",
    "compte_m22bis",
    "exercice_annee",
    "taux_hebergement",
    "taux_dependance",
    "taux_soins",
    "taux_soins_autonomie",
    "source",
    "notes",
)

# Naturel key fields locked post-create — service raises on attempts.
_UPDATABLE: frozenset[str] = frozenset(
    {
        "taux_hebergement",
        "taux_dependance",
        "taux_soins",
        "taux_soins_autonomie",
        "source",
        "notes",
    }
)


def list_by_etablissement(
    etablissement_id: UUID,
    *,
    compte_m22bis: str | None = None,
    exercice_annee: int | None = None,
) -> list[dict[str, Any]]:
    """Liste les clés d'un établissement, ordre stable (annee desc, compte asc)."""
    where = ["etablissement_id = %s"]
    params: list[Any] = [str(etablissement_id)]
    if compte_m22bis is not None:
        where.append("compte_m22bis = %s")
        params.append(compte_m22bis)
    if exercice_annee is not None:
        where.append("exercice_annee = %s")
        params.append(exercice_annee)
    sql = (
        f"SELECT {_COLUMNS_SQL} FROM compta_esms.cles_repartition_charges_communes "
        f"WHERE {' AND '.join(where)} "
        "ORDER BY exercice_annee DESC, compte_m22bis"
    )
    with cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def get_by_id(key_id: UUID) -> dict[str, Any] | None:
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.cles_repartition_charges_communes "
            "WHERE id = %s",
            (str(key_id),),
        )
        return cur.fetchone()


def find_by_natural_key(
    etablissement_id: UUID, compte_m22bis: str, exercice_annee: int
) -> dict[str, Any] | None:
    """Conflict-check helper utilisé par le service avant insert (la DB
    a la même UNIQUE constraint mais on veut la 409 explicit, pas la
    psycopg2 UniqueViolation brute)."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.cles_repartition_charges_communes "
            "WHERE etablissement_id = %s AND compte_m22bis = %s AND exercice_annee = %s",
            (str(etablissement_id), compte_m22bis, exercice_annee),
        )
        return cur.fetchone()


def etablissement_belongs_to_company(etablissement_id: UUID, company_id: UUID) -> bool:
    """Cross-tenant defense in depth (RLS would block too, mais on
    veut le 404 explicit pour le service)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.etablissements " "WHERE id = %s AND company_id = %s",
            (str(etablissement_id), str(company_id)),
        )
        return cur.fetchone() is not None


def create(company_id: UUID, payload: dict[str, Any]) -> dict[str, Any]:
    fields = [c for c in _INSERTABLE if c in payload]
    columns = ["company_id"] + fields
    values: list[Any] = [str(company_id)] + [
        str(payload[c]) if isinstance(payload[c], UUID) else payload[c] for c in fields
    ]
    placeholders = ", ".join(["%s"] * len(columns))
    columns_sql = ", ".join(columns)
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.cles_repartition_charges_communes "
            f"({columns_sql}) VALUES ({placeholders}) "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def update(key_id: UUID, payload: dict[str, Any]) -> dict[str, Any] | None:
    fields = [c for c in payload if c in _UPDATABLE]
    if not fields:
        return get_by_id(key_id)
    set_clause = ", ".join(f"{c} = %s" for c in fields)
    values = [payload[c] for c in fields] + [str(key_id)]
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.cles_repartition_charges_communes "
            f"SET {set_clause}, updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def delete(key_id: UUID) -> bool:
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.cles_repartition_charges_communes WHERE id = %s",
            (str(key_id),),
        )
        return cur.rowcount > 0


def batch_lookup(
    etablissement_id: UUID,
    exercice_annee: int,
    comptes: list[str],
) -> dict[str, dict[str, Decimal]]:
    """Charge en 1 query les clés pour une liste de comptes.

    Pattern §Y bulk-upsert auto-ventilation : avant d'appliquer la
    ventilation par défaut sur N lignes, le service charge en 1 round-
    trip les clés correspondantes. Retourne ``{compte_m22bis: {taux_h,
    taux_d, taux_s, taux_sea}}`` — comptes sans clé absents du dict.
    """
    if not comptes:
        return {}
    with cursor() as cur:
        cur.execute(
            "SELECT compte_m22bis, taux_hebergement, taux_dependance, "
            "       taux_soins, taux_soins_autonomie "
            "FROM compta_esms.cles_repartition_charges_communes "
            "WHERE etablissement_id = %s AND exercice_annee = %s "
            "  AND compte_m22bis = ANY(%s::TEXT[])",
            (str(etablissement_id), exercice_annee, comptes),
        )
        rows = cur.fetchall()
    return {
        r["compte_m22bis"]: {
            "taux_hebergement": Decimal(r["taux_hebergement"]),
            "taux_dependance": Decimal(r["taux_dependance"]),
            "taux_soins": Decimal(r["taux_soins"]),
            "taux_soins_autonomie": Decimal(r["taux_soins_autonomie"]),
        }
        for r in rows
    }


def find_n_minus_1(
    etablissement_id: UUID, compte_m22bis: str, exercice_annee: int
) -> dict[str, Any] | None:
    """Lookup de la clé N-1 pour la même (ETS, compte). Helper KB20 §8.2
    stabilité année/année — le service compare les 4 taux et logue
    WARN si écart."""
    with cursor() as cur:
        cur.execute(
            "SELECT taux_hebergement, taux_dependance, taux_soins, "
            "       taux_soins_autonomie "
            "FROM compta_esms.cles_repartition_charges_communes "
            "WHERE etablissement_id = %s AND compte_m22bis = %s "
            "  AND exercice_annee = %s",
            (str(etablissement_id), compte_m22bis, exercice_annee - 1),
        )
        return cur.fetchone()


def get_etablissement_forfait_flag(etablissement_id: UUID) -> bool | None:
    """Helper pour le service ventilation — D-085 ``forfait_global_unique``
    autorise SEA. Retourne le bool, None si l'ETS n'existe pas."""
    with cursor() as cur:
        cur.execute(
            "SELECT forfait_global_unique FROM compta_esms.etablissements " "WHERE id = %s",
            (str(etablissement_id),),
        )
        row = cur.fetchone()
        return None if row is None else bool(row["forfait_global_unique"])
