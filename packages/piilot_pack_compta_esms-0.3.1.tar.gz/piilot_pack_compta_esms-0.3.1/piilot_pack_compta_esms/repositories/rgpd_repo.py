"""Repository pour ``compta_esms.recueil_consentement_rgpd`` (§T).

Une seule entrée par ``exercice_id`` (DDL §D.11 ``UNIQUE
(exercice_id)``). UPSERT atomique côté :func:`upsert_by_exercice`.

Le payload ``federations_consenties`` est JSONB côté DB (DDL ligne
737), wrappé via ``Json()`` côté Python (pattern aligné sur rcc_repo).
"""

from __future__ import annotations

import json
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

try:
    from piilot.sdk.db import Json
except ImportError:  # pragma: no cover — defensive, SDK ships it
    Json = None  # type: ignore[assignment]


def _wrap_jsonb(value: Any) -> Any:
    """Adapter for psycopg2 JSONB params (pattern rcc_repo)."""
    if Json is not None:
        return Json(value)
    return json.dumps(value)


_SELECT_COLS: tuple[str, ...] = (
    "id",
    "company_id",
    "exercice_id",
    "consentement_cnsa",
    "federations_consenties",
    "duree",
    "consenti_par_user_id",
    "consenti_at",
    "revoque_at",
)
_SELECT_SQL = ", ".join(_SELECT_COLS)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def get_by_exercice(exercice_id: UUID) -> dict[str, Any] | None:
    """Retourne le row pour cet exercice ou None si jamais posé. RLS
    par session SDK."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_SELECT_SQL} "
            "FROM compta_esms.recueil_consentement_rgpd "
            "WHERE exercice_id = %s",
            (str(exercice_id),),
        )
        return cur.fetchone()


def exercice_belongs_to_company(exercice_id: UUID, company_id: UUID) -> bool:
    """Defense in depth — empêche un cabinet de poser un recueil sur
    l'exercice d'un autre tenant. RLS l'attraperait aussi mais le 404
    explicite est plus honnête qu'un blocage RLS silencieux."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.exercices " "WHERE id = %s AND company_id = %s",
            (str(exercice_id), str(company_id)),
        )
        return cur.fetchone() is not None


# ---------------------------------------------------------------------------
# Mutation — UPSERT
# ---------------------------------------------------------------------------


def upsert_by_exercice(
    *,
    company_id: UUID,
    exercice_id: UUID,
    consentement_cnsa: bool,
    federations_consenties: dict[str, Any],
    duree: str | None,
    consenti_par_user_id: UUID | None,
    consenti_at: Any | None,
    revoque_at: Any | None,
) -> dict[str, Any]:
    """INSERT ... ON CONFLICT (exercice_id) DO UPDATE — retourne le
    row complet post-mutation.

    Le service §T décide quels timestamps poser/reset. Le repo se
    contente de persister ce qu'on lui donne."""
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.recueil_consentement_rgpd "
            "(company_id, exercice_id, consentement_cnsa, "
            " federations_consenties, duree, consenti_par_user_id, "
            " consenti_at, revoque_at) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s) "
            "ON CONFLICT (exercice_id) DO UPDATE SET "
            "  consentement_cnsa = EXCLUDED.consentement_cnsa, "
            "  federations_consenties = EXCLUDED.federations_consenties, "
            "  duree = EXCLUDED.duree, "
            "  consenti_par_user_id = EXCLUDED.consenti_par_user_id, "
            "  consenti_at = EXCLUDED.consenti_at, "
            "  revoque_at = EXCLUDED.revoque_at "
            f"RETURNING {_SELECT_SQL}",
            (
                str(company_id),
                str(exercice_id),
                consentement_cnsa,
                _wrap_jsonb(federations_consenties),
                duree,
                str(consenti_par_user_id) if consenti_par_user_id is not None else None,
                consenti_at,
                revoque_at,
            ),
        )
        return cur.fetchone()
