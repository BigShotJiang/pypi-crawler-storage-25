"""Repository for ``compta_esms.kb_bindings`` (D-103).

One binding per ``(document_id, feature_key)`` couple, enforced by a
UNIQUE constraint. ``column_mapping`` is JSONB (wrapped through the
SDK's ``Json`` adapter, with a ``json.dumps`` fallback for the test
suite that stubs the wiring — same pattern as
``balance_import_repo``).

Defense in depth : the service layer (§G.6) calls
:func:`document_belongs_to_company` before every read/write to refuse
a request that smuggles a document_id of another tenant, even though
RLS would block the actual row read.
"""

from __future__ import annotations

import json
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

try:
    from piilot.sdk.db import Json
except ImportError:  # pragma: no cover — defensive, the SDK ships it
    Json = None  # type: ignore[assignment]


def _wrap_jsonb(value: Any) -> Any:
    """Adapter for psycopg2 JSONB params. Same fallback as the rest of
    the repository layer — see ``balance_import_repo._wrap_jsonb``."""
    if Json is not None:
        return Json(value)
    return json.dumps(value)


_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "feature_key",
    "kb_id",
    "kb_table",
    "column_mapping",
    "plan_comptable_source",
    "bound_by_user_id",
    "bound_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


def list_by_document(document_id: UUID) -> list[dict[str, Any]]:
    """Return every binding attached to a document, sorted by feature key."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.kb_bindings "
            "WHERE document_id = %s ORDER BY feature_key",
            (str(document_id),),
        )
        return cur.fetchall()


def get_by_doc_feature(document_id: UUID, feature_key: str) -> dict[str, Any] | None:
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.kb_bindings "
            "WHERE document_id = %s AND feature_key = %s",
            (str(document_id), feature_key),
        )
        return cur.fetchone()


def upsert(
    *,
    company_id: UUID,
    document_id: UUID,
    feature_key: str,
    kb_id: UUID,
    kb_table: str,
    column_mapping: dict[str, str],
    plan_comptable_source: str,
    bound_by_user_id: UUID,
) -> dict[str, Any]:
    """Idempotent upsert : replaces an existing binding for the same
    ``(document_id, feature_key)`` couple, or inserts a fresh one."""
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.kb_bindings "
            "(company_id, document_id, feature_key, kb_id, kb_table, "
            " column_mapping, plan_comptable_source, bound_by_user_id) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s) "
            "ON CONFLICT (document_id, feature_key) DO UPDATE SET "
            "  kb_id = EXCLUDED.kb_id, "
            "  kb_table = EXCLUDED.kb_table, "
            "  column_mapping = EXCLUDED.column_mapping, "
            "  plan_comptable_source = EXCLUDED.plan_comptable_source, "
            "  bound_by_user_id = EXCLUDED.bound_by_user_id, "
            "  bound_at = now() "
            f"RETURNING {_COLUMNS_SQL}",
            (
                str(company_id),
                str(document_id),
                feature_key,
                str(kb_id),
                kb_table,
                _wrap_jsonb(column_mapping),
                plan_comptable_source,
                str(bound_by_user_id),
            ),
        )
        return cur.fetchone()


def delete(document_id: UUID, feature_key: str) -> bool:
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.kb_bindings " "WHERE document_id = %s AND feature_key = %s",
            (str(document_id), feature_key),
        )
        return cur.rowcount > 0


def document_belongs_to_company(document_id: UUID, company_id: UUID) -> bool:
    """Verify the document exists and belongs to the caller's company.

    Same pattern as ``cr_repo.document_exists_for_company`` — keeps
    the service from operating on a document of another tenant even
    if RLS would block the actual row read."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def load_document_context(document_id: UUID, company_id: UUID) -> dict[str, Any] | None:
    """Return ``{type_document, exercice_id}`` + (optional) typologie of
    the dominant établissement. Used by ``:validation`` to filter the
    mandatory features to those applicable to *this* document.

    Strategy : pick the typologie of the first CR's établissement, if
    any. Documents without CRs (newly created with no CR beyond the
    auto-CRPP) fall back to ``None`` typologie — the validation then
    counts all mandatory features regardless of typology.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT d.id, d.type_document, d.exercice_id, "
            "       ( "
            "         SELECT e.typologie "
            "         FROM compta_esms.comptes_resultat c "
            "         JOIN compta_esms.etablissements e ON e.id = c.etablissement_id "
            "         WHERE c.document_id = d.id "
            "         ORDER BY c.ordre, c.created_at "
            "         LIMIT 1 "
            "       ) AS typologie "
            "FROM compta_esms.documents_budgetaires d "
            "WHERE d.id = %s AND d.company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone()
