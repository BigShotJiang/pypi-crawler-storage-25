"""Repository for ``compta_esms.bilan_lignes`` (§K, L2 §14).

Sémantique replace-all-by-type_bilan (Q3) implémentée via
:func:`replace_by_type_bilan` — chaque type_bilan présent dans le
body est intégralement remplacé (DELETE puis INSERT atomique). Les
autres types_bilan restent intacts (pas d'effet de bord).

Pas de UNIQUE constraint requis sur la table — le replace-all gère
naturellement la collision (la combinaison ``poste_label`` libre +
``section`` libre rend une natural key fragile).
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "type_bilan",
    "section",
    "poste_label",
    "compte_m22bis",
    "montant_brut_n",
    "montant_amort_n",
    "montant_net_n",
    "montant_net_n1",
    "type_actif_passif",
    "montant_soins_n",
    "montant_dependance_n",
    "montant_hebergement_n",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def list_by_document(document_id: UUID, *, type_bilan: str | None = None) -> list[dict[str, Any]]:
    """Liste les lignes d'un document. Filtre optionnel sur
    ``type_bilan``.

    Tri stable : type_bilan, section, poste_label."""
    where = ["document_id = %s"]
    params: list[Any] = [str(document_id)]
    if type_bilan is not None:
        where.append("type_bilan = %s")
        params.append(type_bilan)
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.bilan_lignes "
            f"WHERE {' AND '.join(where)} "
            "ORDER BY type_bilan, section, poste_label",
            params,
        )
        return cur.fetchall()


def document_belongs_to_company(document_id: UUID, company_id: UUID) -> bool:
    """Defense in depth (pattern §H/§J)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def get_doc_plan_comptable(document_id: UUID, company_id: UUID) -> dict[str, Any] | None:
    """Retourne ``{type_document, plan_comptable}`` (OG via exercice).

    ``plan_comptable`` ∈ ('PC', 'PNL') — utilisé par le service pour
    auto-déduire ``comptable_pc`` vs ``comptable_pnl`` (Q1, D-067)."""
    with cursor() as cur:
        cur.execute(
            "SELECT d.type_document, og.plan_comptable "
            "FROM compta_esms.documents_budgetaires d "
            "JOIN compta_esms.exercices e ON e.id = d.exercice_id "
            "JOIN compta_esms.organismes_gestionnaires og ON og.id = e.og_id "
            "WHERE d.id = %s AND d.company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone()


# ---------------------------------------------------------------------------
# Writes — replace by type_bilan (Q3)
# ---------------------------------------------------------------------------


def _coerce_decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def replace_by_type_bilan(
    *,
    company_id: UUID,
    document_id: UUID,
    type_bilan: str,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """DELETE WHERE doc + type_bilan + INSERT batch atomique.

    Tous les items doivent avoir le même ``type_bilan`` (le service
    groupe en amont). La nullabilité ``type_actif_passif`` est
    respectée (Q8 souplesse DDL) — si absent du payload, NULL inséré.

    Returns les rows post-insert (avec id + timestamps DB)."""
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.bilan_lignes " "WHERE document_id = %s AND type_bilan = %s",
            (str(document_id), type_bilan),
        )
        for item in items:
            values = (
                str(company_id),
                str(document_id),
                type_bilan,
                item["section"],
                item["poste_label"],
                item.get("compte_m22bis"),
                _coerce_decimal(item.get("montant_brut_n")),
                _coerce_decimal(item.get("montant_amort_n")),
                _coerce_decimal(item.get("montant_net_n")),
                _coerce_decimal(item.get("montant_net_n1")),
                item.get("type_actif_passif"),
                _coerce_decimal(item.get("montant_soins_n")),
                _coerce_decimal(item.get("montant_dependance_n")),
                _coerce_decimal(item.get("montant_hebergement_n")),
            )
            cur.execute(
                "INSERT INTO compta_esms.bilan_lignes "
                "(company_id, document_id, type_bilan, section, poste_label, "
                " compte_m22bis, montant_brut_n, montant_amort_n, "
                " montant_net_n, montant_net_n1, type_actif_passif, "
                " montant_soins_n, montant_dependance_n, montant_hebergement_n) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) "
                f"RETURNING {_COLUMNS_SQL}",
                values,
            )
            out.append(cur.fetchone())
    return out


# ---------------------------------------------------------------------------
# Aggregates (Q4 — :totals)
# ---------------------------------------------------------------------------


def totals_by_type_section(
    document_id: UUID, *, type_bilan: str | None = None
) -> list[dict[str, Any]]:
    """Aggrège ``montant_net_n`` par (type_bilan, section,
    type_actif_passif). Le service pivote en
    :class:`BilanTotalsForType`. ``COALESCE(SUM, 0)`` pour les
    sections sans actif ou sans passif."""
    where = ["document_id = %s"]
    params: list[Any] = [str(document_id)]
    if type_bilan is not None:
        where.append("type_bilan = %s")
        params.append(type_bilan)
    with cursor() as cur:
        cur.execute(
            "SELECT type_bilan, section, type_actif_passif, "
            "       COALESCE(SUM(montant_net_n), 0) AS total "
            "FROM compta_esms.bilan_lignes "
            f"WHERE {' AND '.join(where)} "
            "GROUP BY type_bilan, section, type_actif_passif "
            "ORDER BY type_bilan, section, type_actif_passif NULLS LAST",
            params,
        )
        return cur.fetchall()


def list_types_present(document_id: UUID) -> set[str]:
    """Retourne l'ensemble des ``type_bilan`` présents pour ce
    document. Sert à savoir si financier+comptable_pc+comptable_pnl
    coexistent ou non (D-066)."""
    with cursor() as cur:
        cur.execute(
            "SELECT DISTINCT type_bilan FROM compta_esms.bilan_lignes " "WHERE document_id = %s",
            (str(document_id),),
        )
        return {row["type_bilan"] for row in cur.fetchall()}
