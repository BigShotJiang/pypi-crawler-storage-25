"""Repository for ``compta_esms.exports`` (§AB L2 §19)."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "type",
    "s3_key",
    "filename",
    "file_size",
    "generated_by_user_id",
    "generated_at",
    "deleted_at",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


def create(
    *,
    company_id: UUID,
    document_id: UUID,
    type: str,
    s3_key: str,
    filename: str,
    file_size: int,
    generated_by_user_id: UUID | None,
) -> dict[str, Any]:
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.exports "
            "(company_id, document_id, type, s3_key, filename, file_size, "
            " generated_by_user_id) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s) "
            f"RETURNING {_COLUMNS_SQL}",
            (
                str(company_id),
                str(document_id),
                type,
                s3_key,
                filename,
                file_size,
                str(generated_by_user_id) if generated_by_user_id else None,
            ),
        )
        return cur.fetchone()


def list_by_document(document_id: UUID) -> list[dict[str, Any]]:
    """Liste les exports actifs (deleted_at NULL) du document, plus récents
    en premier."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.exports "
            "WHERE document_id = %s AND deleted_at IS NULL "
            "ORDER BY generated_at DESC",
            (str(document_id),),
        )
        return cur.fetchall()


def get_by_id(export_id: UUID) -> dict[str, Any] | None:
    """Retourne l'export même si soft-deleted (utile pour DELETE
    idempotent). Le caller vérifie ``deleted_at`` selon l'usage."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.exports WHERE id = %s",
            (str(export_id),),
        )
        return cur.fetchone()


def soft_delete(export_id: UUID) -> bool:
    """Marque deleted_at = now() — idempotent (no-op si déjà delete)."""
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.exports SET deleted_at = now(), updated_at = now() "
            "WHERE id = %s AND deleted_at IS NULL",
            (str(export_id),),
        )
        return cur.rowcount > 0
