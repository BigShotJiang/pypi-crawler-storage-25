"""Repository for ``compta_esms.cpom_objectifs`` — §BA v0.3 (D-027).

N objectives per CPOM (KB B.5). ``impact_eprd_o_n`` flags the
objectives that must surface in the §AC DOCX rapport budgétaire EPRD.
``statut`` may be NULL (objectif non encore initié).
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "cpom_id",
    "intitule",
    "impact_eprd_o_n",
    "description",
    "date_realisation_prevue",
    "statut",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

_INSERTABLE: tuple[str, ...] = tuple(
    c for c in _COLUMNS if c not in {"id", "created_at", "updated_at"}
)

# ``cpom_id`` is locked after creation — moving an objectif to
# another CPOM would break audit history.
_UPDATABLE: frozenset[str] = frozenset(_COLUMNS) - {
    "id",
    "company_id",
    "cpom_id",
    "created_at",
    "updated_at",
}


def list_by_cpom(cpom_id: UUID) -> list[dict[str, Any]]:
    """Return all objectives of a CPOM ordered by created_at."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.cpom_objectifs "
            "WHERE cpom_id = %s ORDER BY created_at",
            (str(cpom_id),),
        )
        return cur.fetchall()


def list_with_eprd_impact_by_cpom(cpom_id: UUID) -> list[dict[str, Any]]:
    """Return only the objectives with ``impact_eprd_o_n = OUI`` —
    consumed by §AC DOCX export."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.cpom_objectifs "
            "WHERE cpom_id = %s AND impact_eprd_o_n = 'OUI' "
            "ORDER BY created_at",
            (str(cpom_id),),
        )
        return cur.fetchall()


def get_by_id(obj_id: UUID) -> dict[str, Any] | None:
    """Return a single objectif by id (RLS-scoped) or None."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.cpom_objectifs " "WHERE id = %s",
            (str(obj_id),),
        )
        return cur.fetchone()


def create(company_id: UUID, cpom_id: UUID, payload: dict[str, Any]) -> dict[str, Any]:
    """Insert a new objectif and return the full row.

    ``company_id`` and ``cpom_id`` come from auth + path, not the
    body.
    """
    fields = [c for c in _INSERTABLE if c not in {"company_id", "cpom_id"} and c in payload]
    columns = ["company_id", "cpom_id"] + fields
    values: list[Any] = [str(company_id), str(cpom_id)] + [payload[c] for c in fields]
    placeholders = ", ".join(["%s"] * len(columns))
    columns_sql = ", ".join(columns)
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.cpom_objectifs "
            f"({columns_sql}) VALUES ({placeholders}) "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def update(obj_id: UUID, payload: dict[str, Any]) -> dict[str, Any] | None:
    """Patch an objectif. Returns the updated row or None."""
    fields = [c for c in payload if c in _UPDATABLE]
    if not fields:
        return get_by_id(obj_id)
    set_clause = ", ".join(f"{c} = %s" for c in fields)
    values = [payload[c] for c in fields] + [str(obj_id)]
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.cpom_objectifs "
            f"SET {set_clause}, updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def delete(obj_id: UUID) -> bool:
    """Hard delete an objectif. Returns True if a row was removed."""
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.cpom_objectifs WHERE id = %s",
            (str(obj_id),),
        )
        return cur.rowcount > 0


def aggregate_status_by_cpom(cpom_id: UUID) -> dict[str, int]:
    """Return a status histogram for the progress dashboard.

    Keys: ``total``, ``prevus``, ``en_cours``, ``realises``,
    ``abandonnes``, ``sans_statut`` (statut NULL). Always returns
    every key (zero when absent) so the consumer doesn't have to
    defaut-fill.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT statut, COUNT(*) AS n "
            "FROM compta_esms.cpom_objectifs "
            "WHERE cpom_id = %s "
            "GROUP BY statut",
            (str(cpom_id),),
        )
        rows = cur.fetchall()

    histogram = {
        "total": 0,
        "prevus": 0,
        "en_cours": 0,
        "realises": 0,
        "abandonnes": 0,
        "sans_statut": 0,
    }
    label_by_statut = {
        "PREVU": "prevus",
        "EN_COURS": "en_cours",
        "REALISE": "realises",
        "ABANDONNE": "abandonnes",
        None: "sans_statut",
    }
    for row in rows:
        n = int(row["n"])
        histogram["total"] += n
        bucket = label_by_statut.get(row["statut"])
        if bucket is not None:
            histogram[bucket] += n
    return histogram
