"""Repository for ``compta_esms.comptes_resultat``.

Same conventions as the rest of the repository layer. ``cr_type`` is
absent from :data:`_UPDATABLE` — flipping it post-create would orphan
the document's downstream line history.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "etablissement_id",
    "cr_type",
    "cr_variante",
    "cr_identifiant",
    "denomination",
    "finess_rattachement",
    "capacite_installee",
    "amplitude_ouverture",
    "ventilation",
    "ordre",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

_INSERTABLE: tuple[str, ...] = (
    "etablissement_id",
    "cr_type",
    "cr_variante",
    "cr_identifiant",
    "denomination",
    "finess_rattachement",
    "capacite_installee",
    "amplitude_ouverture",
    "ventilation",
    "ordre",
)

# cr_type is locked after creation ; the service raises on attempts to
# patch it. ``company_id`` and ``document_id`` are immutable too — a
# CR can't move between documents.
_UPDATABLE: frozenset[str] = frozenset(
    {
        "cr_variante",
        "cr_identifiant",
        "denomination",
        "etablissement_id",
        "finess_rattachement",
        "capacite_installee",
        "amplitude_ouverture",
        "ventilation",
        "ordre",
    }
)


def list_by_document(document_id: UUID) -> list[dict[str, Any]]:
    """Return CRs ordered by ``ordre`` then ``created_at`` (insertion order)."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.comptes_resultat "
            "WHERE document_id = %s ORDER BY ordre, created_at",
            (str(document_id),),
        )
        return cur.fetchall()


def get_by_id(cr_id: UUID) -> dict[str, Any] | None:
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.comptes_resultat " "WHERE id = %s",
            (str(cr_id),),
        )
        return cur.fetchone()


def create(company_id: UUID, document_id: UUID, payload: dict[str, Any]) -> dict[str, Any]:
    fields = [c for c in _INSERTABLE if c in payload]
    columns = ["company_id", "document_id"] + fields
    values: list[Any] = [str(company_id), str(document_id)] + [payload[c] for c in fields]
    placeholders = ", ".join(["%s"] * len(columns))
    columns_sql = ", ".join(columns)
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.comptes_resultat "
            f"({columns_sql}) VALUES ({placeholders}) "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def update(cr_id: UUID, payload: dict[str, Any]) -> dict[str, Any] | None:
    fields = [c for c in payload if c in _UPDATABLE]
    if not fields:
        return get_by_id(cr_id)
    set_clause = ", ".join(f"{c} = %s" for c in fields)
    values = [payload[c] for c in fields] + [str(cr_id)]
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.comptes_resultat "
            f"SET {set_clause}, updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def delete(cr_id: UUID) -> bool:
    """Hard delete. ``crp_lignes`` cascade via FK ON DELETE CASCADE."""
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.comptes_resultat WHERE id = %s",
            (str(cr_id),),
        )
        return cur.rowcount > 0


def document_exists_for_company(document_id: UUID, company_id: UUID) -> bool:
    """Verify the document belongs to the caller's company (defense in depth)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def get_doc_type_and_dm_perimeter(document_id: UUID) -> dict[str, Any] | None:
    """Return ``{type_document, parent_id, parent_ets_ids: set[UUID]}`` —
    helper §V D-063 immutable périmètre.

    Si ``type_document == 'dm'`` : ``parent_ets_ids`` est l'ensemble
    des ``etablissement_id`` distincts (non-NULL) des CRs du parent
    EPRD. Une création/PATCH de CR sur ce DM doit avoir
    ``etablissement_id`` ∈ cet ensemble (sinon 422
    ``dm_perimeter_breach``).

    Si ``type_document != 'dm'`` : ``parent_ets_ids`` est vide (le
    service n'applique pas le guard sur les autres types).

    Retourne ``None`` si le document n'existe pas (defensive — le caller
    devrait l'avoir déjà filtré via :func:`document_exists_for_company`).
    """
    with cursor() as cur:
        cur.execute(
            "SELECT type_document, parent_id "
            "FROM compta_esms.documents_budgetaires WHERE id = %s",
            (str(document_id),),
        )
        row = cur.fetchone()
        if row is None:
            return None
        type_document = row["type_document"]
        parent_id = row["parent_id"]
        ets_ids: set[UUID] = set()
        if type_document == "dm" and parent_id is not None:
            cur.execute(
                "SELECT DISTINCT etablissement_id FROM compta_esms.comptes_resultat "
                "WHERE document_id = %s AND etablissement_id IS NOT NULL",
                (str(parent_id),),
            )
            ets_ids = {r["etablissement_id"] for r in cur.fetchall()}
    return {
        "type_document": type_document,
        "parent_id": parent_id,
        "parent_ets_ids": ets_ids,
    }


def aggregate_charges_produits_by_cr(document_id: UUID) -> dict[UUID, dict[str, Decimal]]:
    """Return ``{cr_id: {"charges": Decimal, "produits": Decimal}}`` for a
    document — helper §W RIA Synthèse résultats (D-065, D-087).

    Aggregates ``crp_lignes.montant_previsions_totales`` for prévisionnels
    (EPRD/RIA/DM/AVENANT) and ``montant_realise`` for réalisés
    (ERRD/ERCP/EPCP). The caller passes ``use_realise=True`` to switch the
    aggregation column ; we expose the choice via two thin wrappers below
    rather than coupling the SQL with the document type lookup.

    NULL montants are coerced to 0 via ``COALESCE`` so a CR with no
    saisie returns ``{"charges": 0, "produits": 0}`` rather than being
    absent from the result dict.

    Returns an empty dict if the document has no CRs (RIA with empty
    parent perimeter — defensive, shouldn't happen since §V clone
    inherits parent CRs).
    """
    return _aggregate_by_column(document_id, "montant_previsions_totales")


def aggregate_realise_by_cr(document_id: UUID) -> dict[UUID, dict[str, Decimal]]:
    """Same as :func:`aggregate_charges_produits_by_cr` but for the
    réalisé column (used by ERRD N-1 lookup in §W RIA)."""
    return _aggregate_by_column(document_id, "montant_realise")


def _aggregate_by_column(document_id: UUID, montant_column: str) -> dict[UUID, dict[str, Decimal]]:
    # Whitelist the column name — never interpolate from user input.
    if montant_column not in {"montant_previsions_totales", "montant_realise"}:
        raise ValueError(f"unsupported aggregation column: {montant_column}")
    sql = (
        "SELECT cr.id AS cr_id, "
        "       COALESCE(SUM(CASE WHEN l.nature = 'charge' "
        f"               THEN l.{montant_column} ELSE 0 END), 0) AS charges, "
        "       COALESCE(SUM(CASE WHEN l.nature = 'produit' "
        f"               THEN l.{montant_column} ELSE 0 END), 0) AS produits "
        "FROM compta_esms.comptes_resultat cr "
        "LEFT JOIN compta_esms.crp_lignes l ON l.cr_id = cr.id "
        "WHERE cr.document_id = %s "
        "GROUP BY cr.id"
    )
    with cursor() as cur:
        cur.execute(sql, (str(document_id),))
        rows = cur.fetchall()
    return {
        row["cr_id"]: {
            "charges": Decimal(row["charges"] or 0),
            "produits": Decimal(row["produits"] or 0),
        }
        for row in rows
    }


def get_ventilation_context(cr_id: UUID) -> dict[str, Any] | None:
    """Charge ``{ventilation, etablissement_id, exercice_annee}`` pour
    un CR — helper §Y auto-ventilation H/D/S.

    JOIN sur ``documents_budgetaires`` → ``exercices`` pour remonter
    l'année. Retourne None si le CR n'existe pas.

    Le service ventilation utilise ces 3 valeurs pour :

    * Décider si on auto-ventile (``ventilation`` ∈ ternaire_*)
    * Trouver les clés gestionnaires (``etablissement_id`` +
      ``exercice_annee``)
    * Valider SEA conditionnel (D-085 — lookup forfait_global_unique
      via le helper repo séparé ``cles_repartition_repo.get_etablissement_forfait_flag``).
    """
    with cursor() as cur:
        cur.execute(
            "SELECT cr.ventilation, cr.etablissement_id, e.annee AS exercice_annee "
            "FROM compta_esms.comptes_resultat cr "
            "JOIN compta_esms.documents_budgetaires d ON d.id = cr.document_id "
            "JOIN compta_esms.exercices e ON e.id = d.exercice_id "
            "WHERE cr.id = %s",
            (str(cr_id),),
        )
        return cur.fetchone()


def etablissement_belongs_to_company(etablissement_id: UUID, company_id: UUID) -> bool:
    """Verify the optional etablissement_id is owned by the caller's company.

    Without this check, a clever client could attach a CR to an
    établissement of another tenant by simply guessing the UUID — RLS
    would block reads later, but the dangling FK would surface as
    orphaned data.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.etablissements " "WHERE id = %s AND company_id = %s",
            (str(etablissement_id), str(company_id)),
        )
        return cur.fetchone() is not None
