"""Repository for ``compta_esms.exercices``.

Same conventions as :mod:`og_repo` — sync functions, explicit column
allowlist, RLS-scoped queries. No ``update`` or ``delete`` exposed
since the L2 spec doesn't surface a PATCH or DELETE on exercices
(see L2 §3 — only list, create, get).
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "og_id",
    "annee",
    "millesime_m22bis",
    "created_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


def list_by_og(og_id: UUID) -> list[dict[str, Any]]:
    """Return all exercices of an OG, ordered by year descending.

    Descending order so the cabinet sees the current year first in
    the UI — that's the one they're working on 99% of the time.
    """
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.exercices "
            "WHERE og_id = %s ORDER BY annee DESC",
            (str(og_id),),
        )
        return cur.fetchall()


def get_by_id(exercice_id: UUID) -> dict[str, Any] | None:
    """Return a single exercice (RLS-scoped)."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.exercices WHERE id = %s",
            (str(exercice_id),),
        )
        return cur.fetchone()


def find_by_og_annee(og_id: UUID, annee: int) -> dict[str, Any] | None:
    """Conflict-check helper — DB has ``UNIQUE (company_id, og_id, annee)``.

    The lookup is scoped on (og_id, annee) ; ``company_id`` is implied
    by the RLS context, which keeps the helper signature simple.
    """
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.exercices " "WHERE og_id = %s AND annee = %s",
            (str(og_id), annee),
        )
        return cur.fetchone()


def create(company_id: UUID, og_id: UUID, annee: int, millesime_m22bis: str) -> dict[str, Any]:
    """Insert a new exercice and return the full row."""
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.exercices "
            "(company_id, og_id, annee, millesime_m22bis) "
            "VALUES (%s, %s, %s, %s) "
            f"RETURNING {_COLUMNS_SQL}",
            (str(company_id), str(og_id), annee, millesime_m22bis),
        )
        return cur.fetchone()


def og_exists_for_company(og_id: UUID, company_id: UUID) -> bool:
    """Verify the OG belongs to the caller's company before insert.

    Mirrors :func:`etablissement_repo.og_exists_for_company` — defense
    in depth on top of RLS.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.organismes_gestionnaires "
            "WHERE id = %s AND company_id = %s",
            (str(og_id), str(company_id)),
        )
        return cur.fetchone() is not None
