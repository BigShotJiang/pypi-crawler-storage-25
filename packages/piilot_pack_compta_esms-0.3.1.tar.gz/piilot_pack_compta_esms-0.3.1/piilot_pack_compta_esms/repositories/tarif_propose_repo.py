"""Repository for ``compta_esms.eprd_tarifs_proposes`` — §BB v0.3.

Same conventions as :mod:`cpom_repo` — sync, RLS-scoped, column
allowlist explicite.

``ecart`` est GENERATED côté DB (read-only) — il apparaît dans
``_COLUMNS`` pour la SELECT projection mais jamais dans ``_UPDATABLE``
ni ``_INSERTABLE``.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "etablissement_id",
    "section",
    "libelle",
    "montant_propose",
    "montant_notifie",
    "ecart",  # GENERATED — read-only
    "motif",
    "statut",
    "date_validation",
    "valide_par",
    "motif_rejet",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

# ``ecart`` GENERATED + DB defaults (statut, created_at, updated_at)
# sont exclus de l'INSERTABLE — psycopg2 doit laisser PG défaulter.
_INSERTABLE: tuple[str, ...] = tuple(
    c for c in _COLUMNS if c not in {"id", "ecart", "created_at", "updated_at"}
)

# ``document_id``, ``etablissement_id`` et ``section`` sont la clé
# naturelle de l'UNIQUE — un move = delete + create.
_UPDATABLE: frozenset[str] = frozenset(_COLUMNS) - {
    "id",
    "company_id",
    "document_id",
    "etablissement_id",
    "section",
    "ecart",
    "created_at",
    "updated_at",
}


def list_by_document(document_id: UUID) -> list[dict[str, Any]]:
    """Return every tarif row of an EPRD ordered by (ETS, section)."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.eprd_tarifs_proposes "
            "WHERE document_id = %s "
            "ORDER BY etablissement_id, section",
            (str(document_id),),
        )
        return cur.fetchall()


def get_by_id(tarif_id: UUID) -> dict[str, Any] | None:
    """Single row by id (RLS-scoped) or None."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.eprd_tarifs_proposes " "WHERE id = %s",
            (str(tarif_id),),
        )
        return cur.fetchone()


def get_by_natural_key(
    document_id: UUID, etablissement_id: UUID, section: str
) -> dict[str, Any] | None:
    """Idempotency-helper — UNIQUE (document_id, etablissement_id, section)
    permet de détecter "already exists" avant un UniqueViolation."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.eprd_tarifs_proposes "
            "WHERE document_id = %s AND etablissement_id = %s "
            "  AND section = %s",
            (str(document_id), str(etablissement_id), section),
        )
        return cur.fetchone()


def create(company_id: UUID, document_id: UUID, payload: dict[str, Any]) -> dict[str, Any]:
    """Insert a new tarif row. ``company_id`` and ``document_id`` come
    from auth + path."""
    fields = [c for c in _INSERTABLE if c not in {"company_id", "document_id"} and c in payload]
    columns = ["company_id", "document_id"] + fields
    values: list[Any] = [str(company_id), str(document_id)] + [payload[c] for c in fields]
    placeholders = ", ".join(["%s"] * len(columns))
    columns_sql = ", ".join(columns)
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.eprd_tarifs_proposes "
            f"({columns_sql}) VALUES ({placeholders}) "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def update(tarif_id: UUID, payload: dict[str, Any]) -> dict[str, Any] | None:
    """Patch a tarif row. Returns updated row or None if not found."""
    fields = [c for c in payload if c in _UPDATABLE]
    if not fields:
        return get_by_id(tarif_id)
    set_clause = ", ".join(f"{c} = %s" for c in fields)
    values = [payload[c] for c in fields] + [str(tarif_id)]
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.eprd_tarifs_proposes "
            f"SET {set_clause}, updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def delete(tarif_id: UUID) -> bool:
    """Hard delete a tarif row. Returns True if a row was removed."""
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.eprd_tarifs_proposes WHERE id = %s",
            (str(tarif_id),),
        )
        return cur.rowcount > 0


def upsert(
    company_id: UUID,
    document_id: UUID,
    etablissement_id: UUID,
    section: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    """ON CONFLICT (document, ets, section) DO UPDATE.

    Sur conflit, on **ne touche pas** aux champs ATC (``montant_notifie``,
    ``statut``, ``date_validation``, ``valide_par``, ``motif_rejet``) —
    ils sont gérés par un PATCH dédié. Le bulk-upsert remplace
    seulement les champs ESMS-side : libelle, montant_propose, motif.
    """
    with cursor() as cur:
        cur.execute(
            """
            INSERT INTO compta_esms.eprd_tarifs_proposes
                (company_id, document_id, etablissement_id, section,
                 libelle, montant_propose, motif)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (document_id, etablissement_id, section) DO UPDATE SET
                libelle         = EXCLUDED.libelle,
                montant_propose = EXCLUDED.montant_propose,
                motif           = EXCLUDED.motif,
                updated_at      = now()
            RETURNING """ + _COLUMNS_SQL,
            (
                str(company_id),
                str(document_id),
                str(etablissement_id),
                section,
                payload.get("libelle"),
                payload["montant_propose"],
                payload.get("motif"),
            ),
        )
        return cur.fetchone()


def aggregate_by_section(document_id: UUID) -> list[dict[str, Any]]:
    """Aggregate par section pour le validation report §BD C1.

    Retourne pour chaque section présente :
      - ``rows_count``           : nb de rows
      - ``total_propose``        : SUM(montant_propose)
      - ``total_notifie``        : SUM(montant_notifie) ou NULL si au
                                    moins une row a montant_notifie NULL
      - ``all_validated_tripartite`` : bool, True ssi toutes les rows
                                       de la section sont en
                                       VALIDE_TRIPARTITE
      - ``has_rejected``         : True si ≥1 row en REJETE
    """
    with cursor() as cur:
        cur.execute(
            """
            SELECT section,
                   COUNT(*) AS rows_count,
                   COALESCE(SUM(montant_propose), 0) AS total_propose,
                   CASE
                       WHEN COUNT(*) FILTER (WHERE montant_notifie IS NULL) > 0
                            THEN NULL
                       ELSE SUM(montant_notifie)
                   END AS total_notifie,
                   bool_and(statut = 'VALIDE_TRIPARTITE')
                       AS all_validated_tripartite,
                   bool_or(statut = 'REJETE') AS has_rejected
            FROM compta_esms.eprd_tarifs_proposes
            WHERE document_id = %s
            GROUP BY section
            ORDER BY section
            """,
            (str(document_id),),
        )
        return cur.fetchall()


def document_exists_for_company(document_id: UUID, company_id: UUID) -> bool:
    """Cross-check guard called by the service before insert / update.

    Returns False if the document_id doesn't exist OR belongs to
    another tenant — service returns a clean 404 instead of bouncing
    on RLS silently.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def get_document_type(document_id: UUID) -> str | None:
    """Return ``type_document`` of a doc — service uses this to enforce
    "tarifs proposés ne s'appliquent qu'aux EPRD" (or its variants
    EPCP / DM that prévisionnent aussi).
    """
    with cursor() as cur:
        cur.execute(
            "SELECT type_document FROM compta_esms.documents_budgetaires " "WHERE id = %s",
            (str(document_id),),
        )
        row = cur.fetchone()
        return row["type_document"] if row else None


def ets_belongs_to_company(etablissement_id: UUID, company_id: UUID) -> bool:
    """Defense-in-depth check : the ETS must belong to the caller's
    tenant. Service calls this before insert so we surface a clean
    422 / 404 instead of an RLS silent-no-op.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.etablissements " "WHERE id = %s AND company_id = %s",
            (str(etablissement_id), str(company_id)),
        )
        return cur.fetchone() is not None
