"""Repository for ``compta_esms.tper_ter_lignes`` (§P, L2 §11).

Sémantique Q3 — **replace_by_(doc, ets, type_tableau)** : DELETE WHERE
doc+ets+type + INSERT batch atomique. Cohérent §K Bilan + §N emprunts
pour onglets coexistants.

Le DDL accommode TPER + TER unifiés via ``type_tableau`` Literal
+ ``type_etablissement`` Literal 4 valeurs. Migration 012 ajoute
``type_poste`` P/T (bug spec L1 + plugin omettaient).
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "etablissement_id",
    "type_tableau",
    "type_etablissement",
    "categorie_cnsa",
    "fonction",
    "type_poste",
    "etpr_prevus",
    "etpt_prevus",
    "etpr_realises",
    "etpt_realises",
    "remunerations_prevues",
    "remunerations_realisees",
    "section_imputation",
    "pct_section",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def list_by_filter(
    document_id: UUID,
    ets_id: UUID | None = None,
    type_tableau: str | None = None,
) -> list[dict[str, Any]]:
    """Liste les lignes d'un document, optionnellement filtré par ETS
    et/ou type_tableau.

    Tri stable : type_tableau, type_etablissement, categorie_cnsa,
    fonction (NULLS LAST), type_poste."""
    sql = f"SELECT {_COLUMNS_SQL} FROM compta_esms.tper_ter_lignes WHERE document_id = %s"
    params: tuple[Any, ...] = (str(document_id),)
    if ets_id is not None:
        sql += " AND etablissement_id = %s"
        params = (*params, str(ets_id))
    if type_tableau is not None:
        sql += " AND type_tableau = %s"
        params = (*params, type_tableau)
    sql += (
        " ORDER BY type_tableau, type_etablissement, categorie_cnsa, "
        "fonction NULLS LAST, type_poste"
    )
    with cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def document_belongs_to_company(document_id: UUID, company_id: UUID) -> bool:
    """Defense in depth (pattern §H/§J/§K/§M/§N)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def get_ets_typologie(etablissement_id: UUID, company_id: UUID) -> dict[str, Any] | None:
    """Q9 — retourne ``{typologie}`` pour auto-déduire ``type_etablissement``
    via :func:`reference_lookup.deduce_type_etablissement`."""
    with cursor() as cur:
        cur.execute(
            "SELECT typologie FROM compta_esms.etablissements " "WHERE id = %s AND company_id = %s",
            (str(etablissement_id), str(company_id)),
        )
        return cur.fetchone()


def totals_by_categorie(document_id: UUID) -> list[dict[str, Any]]:
    """Aggrège par categorie_cnsa sur 6 colonnes (ETPR/ETPT prevus/
    realises + 2 rémunérations). COALESCE(SUM, 0) partout."""
    with cursor() as cur:
        cur.execute(
            "SELECT categorie_cnsa, "
            "       COALESCE(SUM(etpr_prevus), 0)         AS etpr_prevus, "
            "       COALESCE(SUM(etpt_prevus), 0)         AS etpt_prevus, "
            "       COALESCE(SUM(etpr_realises), 0)       AS etpr_realises, "
            "       COALESCE(SUM(etpt_realises), 0)       AS etpt_realises, "
            "       COALESCE(SUM(remunerations_prevues), 0)   AS remunerations_prevues, "
            "       COALESCE(SUM(remunerations_realisees), 0) AS remunerations_realisees "
            "FROM compta_esms.tper_ter_lignes "
            "WHERE document_id = %s "
            "GROUP BY categorie_cnsa "
            "ORDER BY categorie_cnsa",
            (str(document_id),),
        )
        return cur.fetchall()


def totals_by_section(document_id: UUID) -> list[dict[str, Any]]:
    """Aggrège par section_imputation avec pondération par pct_section.

    ``etpr_ventile = SUM(etpr_* × pct_section/100)``. Pour les lignes
    où section_imputation IS NULL ou pct_section IS NULL, la ligne
    n'est pas ventilée (pas comptée)."""
    with cursor() as cur:
        cur.execute(
            "SELECT section_imputation, "
            "       COALESCE(SUM(etpr_prevus * COALESCE(pct_section, 0) / 100), 0)   "
            "         AS etpr_prevus_ventile, "
            "       COALESCE(SUM(etpr_realises * COALESCE(pct_section, 0) / 100), 0) "
            "         AS etpr_realises_ventile, "
            "       COALESCE(SUM(remunerations_prevues * COALESCE(pct_section, 0) / 100), 0) "
            "         AS remunerations_prevues_ventilees, "
            "       COALESCE(SUM(remunerations_realisees * COALESCE(pct_section, 0) / 100), 0) "
            "         AS remunerations_realisees_ventilees "
            "FROM compta_esms.tper_ter_lignes "
            "WHERE document_id = %s AND section_imputation IS NOT NULL "
            "GROUP BY section_imputation "
            "ORDER BY section_imputation",
            (str(document_id),),
        )
        return cur.fetchall()


def list_existing_keys(
    document_id: UUID, ets_id: UUID, type_tableau: str
) -> set[tuple[str, str | None, str]]:
    """Retourne le set des natural keys déjà présentes en DB pour
    (doc, ets, type) — utilisé par le prefill pour skip les lignes
    déjà saisies (pattern §H.6 prefill semantics)."""
    with cursor() as cur:
        cur.execute(
            "SELECT categorie_cnsa, fonction, type_poste "
            "FROM compta_esms.tper_ter_lignes "
            "WHERE document_id = %s AND etablissement_id = %s "
            "  AND type_tableau = %s",
            (str(document_id), str(ets_id), type_tableau),
        )
        return {(r["categorie_cnsa"], r["fonction"], r["type_poste"]) for r in cur.fetchall()}


# ---------------------------------------------------------------------------
# Writes — replace by (doc, ets, type_tableau)  (Q3)
# ---------------------------------------------------------------------------


def _coerce_decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def replace_by_doc_ets_type(
    *,
    company_id: UUID,
    document_id: UUID,
    etablissement_id: UUID,
    type_tableau: str,
    type_etablissement: str,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """DELETE WHERE doc+ets+type + INSERT batch atomique (Q3).

    Ne touche QUE les lignes de l'onglet ciblé — les autres
    (type_tableau différent ou ets différent) sont préservées."""
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.tper_ter_lignes "
            "WHERE document_id = %s AND etablissement_id = %s "
            "  AND type_tableau = %s",
            (str(document_id), str(etablissement_id), type_tableau),
        )
        for item in items:
            values = (
                str(company_id),
                str(document_id),
                str(etablissement_id),
                type_tableau,
                type_etablissement,
                item["categorie_cnsa"],
                item.get("fonction"),
                item["type_poste"],
                _coerce_decimal(item.get("etpr_prevus")),
                _coerce_decimal(item.get("etpt_prevus")),
                _coerce_decimal(item.get("etpr_realises")),
                _coerce_decimal(item.get("etpt_realises")),
                _coerce_decimal(item.get("remunerations_prevues")),
                _coerce_decimal(item.get("remunerations_realisees")),
                item.get("section_imputation"),
                _coerce_decimal(item.get("pct_section")),
            )
            cur.execute(
                "INSERT INTO compta_esms.tper_ter_lignes "
                "(company_id, document_id, etablissement_id, type_tableau, "
                " type_etablissement, categorie_cnsa, fonction, type_poste, "
                " etpr_prevus, etpt_prevus, etpr_realises, etpt_realises, "
                " remunerations_prevues, remunerations_realisees, "
                " section_imputation, pct_section) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, "
                "        %s, %s, %s, %s) "
                f"RETURNING {_COLUMNS_SQL}",
                values,
            )
            out.append(cur.fetchone())
    return out


def insert_one(
    *,
    company_id: UUID,
    document_id: UUID,
    etablissement_id: UUID,
    type_tableau: str,
    type_etablissement: str,
    item: dict[str, Any],
) -> dict[str, Any]:
    """Single INSERT pour usage prefill (n'efface rien). Le service
    appelant filtre déjà les natural keys déjà présentes via
    :func:`list_existing_keys`."""
    values = (
        str(company_id),
        str(document_id),
        str(etablissement_id),
        type_tableau,
        type_etablissement,
        item["categorie_cnsa"],
        item.get("fonction"),
        item["type_poste"],
        _coerce_decimal(item.get("etpr_prevus")),
        _coerce_decimal(item.get("etpt_prevus")),
        _coerce_decimal(item.get("etpr_realises")),
        _coerce_decimal(item.get("etpt_realises")),
        _coerce_decimal(item.get("remunerations_prevues")),
        _coerce_decimal(item.get("remunerations_realisees")),
        item.get("section_imputation"),
        _coerce_decimal(item.get("pct_section")),
    )
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.tper_ter_lignes "
            "(company_id, document_id, etablissement_id, type_tableau, "
            " type_etablissement, categorie_cnsa, fonction, type_poste, "
            " etpr_prevus, etpt_prevus, etpr_realises, etpt_realises, "
            " remunerations_prevues, remunerations_realisees, "
            " section_imputation, pct_section) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, "
            "        %s, %s, %s, %s) "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()
