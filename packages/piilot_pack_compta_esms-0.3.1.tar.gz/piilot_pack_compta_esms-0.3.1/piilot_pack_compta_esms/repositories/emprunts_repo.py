"""Repository for ``compta_esms.emprunts_dettes`` (§N, L2 §16.3-§16.4).

Sémantique Q4 — **replace_by_document_and_type_dette** : DELETE WHERE
doc AND type_dette + INSERT batch atomique. Précédent §K Bilan
(PC/PNL coexistants), pas §M (replace_all).

Le DDL n'a pas de variante — la **même table** accommode les 9
types_dette via la colonne ``type_dette`` (CHECK §D.9 ligne 564).
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "type_dette",
    "libelle",
    "capital_emprunte",
    "taux",
    "duree_annees",
    "date_debut",
    "capital_rembourse_n1",
    "capital_rembourse_n",
    "interets_n1",
    "interets_n",
    "solde_restant_du",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def list_by_document(document_id: UUID, type_dette: str | None = None) -> list[dict[str, Any]]:
    """Liste les emprunts d'un document, optionnellement filtré par
    type_dette. Tri stable : type_dette, libelle (NULLS LAST)."""
    sql = f"SELECT {_COLUMNS_SQL} FROM compta_esms.emprunts_dettes " "WHERE document_id = %s"
    params: tuple[Any, ...] = (str(document_id),)
    if type_dette is not None:
        sql += " AND type_dette = %s"
        params = (*params, type_dette)
    sql += " ORDER BY type_dette, libelle NULLS LAST"
    with cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def document_belongs_to_company(document_id: UUID, company_id: UUID) -> bool:
    """Defense in depth (pattern §H/§J/§K/§M)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def totals_by_type_dette(document_id: UUID, type_dette: str | None = None) -> list[dict[str, Any]]:
    """Aggrège par type_dette : count(*) + sums monétaires.

    Si ``type_dette`` est fourni, retourne au plus 1 row pour ce type.
    Sinon, retourne 1 row par type_dette présent (max 9)."""
    sql = (
        "SELECT type_dette, COUNT(*) AS nb_lignes, "
        "       COALESCE(SUM(capital_emprunte), 0)     AS capital_emprunte_total, "
        "       COALESCE(SUM(capital_rembourse_n1), 0) AS capital_rembourse_n1_total, "
        "       COALESCE(SUM(capital_rembourse_n), 0)  AS capital_rembourse_n_total, "
        "       COALESCE(SUM(interets_n1), 0)          AS interets_n1_total, "
        "       COALESCE(SUM(interets_n), 0)           AS interets_n_total, "
        "       COALESCE(SUM(solde_restant_du), 0)     AS solde_restant_du_total "
        "FROM compta_esms.emprunts_dettes "
        "WHERE document_id = %s"
    )
    params: tuple[Any, ...] = (str(document_id),)
    if type_dette is not None:
        sql += " AND type_dette = %s"
        params = (*params, type_dette)
    sql += " GROUP BY type_dette ORDER BY type_dette"
    with cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


# ---------------------------------------------------------------------------
# Writes
# ---------------------------------------------------------------------------


def _coerce_decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def _coerce_date(value: Any) -> date | None:
    if value is None:
        return None
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value))


def replace_by_document_and_type_dette(
    *,
    company_id: UUID,
    document_id: UUID,
    type_dette: str,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """DELETE WHERE doc AND type_dette + INSERT batch atomique (Q4).

    Ne touche QUE les lignes du type_dette donné — les 8 autres
    onglets sont préservés."""
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.emprunts_dettes " "WHERE document_id = %s AND type_dette = %s",
            (str(document_id), type_dette),
        )
        for item in items:
            values = (
                str(company_id),
                str(document_id),
                type_dette,
                item.get("libelle"),
                _coerce_decimal(item.get("capital_emprunte")),
                _coerce_decimal(item.get("taux")),
                item.get("duree_annees"),
                _coerce_date(item.get("date_debut")),
                _coerce_decimal(item.get("capital_rembourse_n1")),
                _coerce_decimal(item.get("capital_rembourse_n")),
                _coerce_decimal(item.get("interets_n1")),
                _coerce_decimal(item.get("interets_n")),
                _coerce_decimal(item.get("solde_restant_du")),
            )
            cur.execute(
                "INSERT INTO compta_esms.emprunts_dettes "
                "(company_id, document_id, type_dette, libelle, capital_emprunte, taux, "
                " duree_annees, date_debut, capital_rembourse_n1, capital_rembourse_n, "
                " interets_n1, interets_n, solde_restant_du) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) "
                f"RETURNING {_COLUMNS_SQL}",
                values,
            )
            out.append(cur.fetchone())
    return out
