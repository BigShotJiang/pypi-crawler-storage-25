"""Repository for ``compta_esms.etablissements``.

Same conventions as :mod:`og_repo` — sync functions, explicit column
allowlist, RLS-scoped queries, dependency counters for safe deletes.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "og_id",
    "finess_ets",
    "raison_sociale",
    "typologie",
    "categorie",
    "adresse",
    "date_autorisation",
    "capacite_autorisee",
    "capacite_installee",
    "capacite_financee",
    # D-048 — décomposition par section (migration 014)
    "capacite_hp",
    "capacite_uhr",
    "capacite_pasa",
    "capacite_ht",
    "capacite_aj",
    "capacite_externat",
    "capacite_semi_internat",
    "capacite_internat",
    "amplitude_ouverture",
    "convention_collective",
    "inclus_cpom",
    "soumis_equilibre",
    "tarification_ternaire",
    "forfait_global_unique",
    "cofinancement",
    # v0.3 — D-030 champs étendus (migration 018)
    "eligible_aide_sociale",
    "option_tarifaire",
    "gmp_valeur",
    "gmp_date_validation",
    "gmp_validation_mode",
    "pmp_valeur",
    "pmp_date_validation",
    "prix_journee_moyen",
    "tarification_differenciee_o_n",
    "nb_chambres_individuelles",
    "nb_chambres_doubles",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

_INSERTABLE: tuple[str, ...] = tuple(
    c for c in _COLUMNS if c not in {"id", "created_at", "updated_at"}
)

# og_id is locked after creation — re-parenting would break document
# history (cf. ``EtablissementUpdate`` docstring).
_UPDATABLE: frozenset[str] = frozenset(_COLUMNS) - {
    "id",
    "company_id",
    "og_id",
    "created_at",
    "updated_at",
}


def list_by_og(og_id: UUID, typologie: str | None = None) -> list[dict[str, Any]]:
    """Return all établissements of an OG, optionally filtered by typologie."""
    sql = f"SELECT {_COLUMNS_SQL} FROM compta_esms.etablissements " "WHERE og_id = %s"
    params: list[Any] = [str(og_id)]
    if typologie is not None:
        sql += " AND typologie = %s"
        params.append(typologie)
    sql += " ORDER BY raison_sociale"
    with cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def get_by_id(ets_id: UUID) -> dict[str, Any] | None:
    """Return a single établissement by id (RLS-scoped)."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.etablissements " "WHERE id = %s",
            (str(ets_id),),
        )
        return cur.fetchone()


def find_by_finess(company_id: UUID, finess_ets: str) -> dict[str, Any] | None:
    """Conflict-check helper — DB has ``UNIQUE (company_id, finess_ets)``."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.etablissements "
            "WHERE company_id = %s AND finess_ets = %s",
            (str(company_id), finess_ets),
        )
        return cur.fetchone()


def create(company_id: UUID, og_id: UUID, payload: dict[str, Any]) -> dict[str, Any]:
    """Insert a new établissement.

    ``company_id`` and ``og_id`` come from the route path, not the body,
    so we inject them explicitly here.
    """
    fields = [c for c in _INSERTABLE if c not in {"company_id", "og_id"} and c in payload]
    columns = ["company_id", "og_id"] + fields
    values: list[Any] = [str(company_id), str(og_id)] + [payload[c] for c in fields]
    placeholders = ", ".join(["%s"] * len(columns))
    columns_sql = ", ".join(columns)
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.etablissements "
            f"({columns_sql}) VALUES ({placeholders}) "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def update(ets_id: UUID, payload: dict[str, Any]) -> dict[str, Any] | None:
    """Patch an établissement. Returns the updated row or None."""
    fields = [c for c in payload if c in _UPDATABLE]
    if not fields:
        return get_by_id(ets_id)
    set_clause = ", ".join(f"{c} = %s" for c in fields)
    values = [payload[c] for c in fields] + [str(ets_id)]
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.etablissements "
            f"SET {set_clause}, updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def delete(ets_id: UUID) -> bool:
    """Hard delete an établissement. Returns True if a row was removed.

    Service must check :func:`count_crs` first (RESTRICT FK on the
    ``comptes_resultat.etablissement_id``) to return 409 instead of a
    raw psycopg2 error.
    """
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.etablissements WHERE id = %s",
            (str(ets_id),),
        )
        return cur.rowcount > 0


def count_crs(ets_id: UUID) -> int:
    """Count Comptes de Résultat referencing this établissement.

    ``comptes_resultat.etablissement_id`` has ``ON DELETE RESTRICT`` so
    the DB would refuse with a FK violation; this helper surfaces it
    as a 409 with a meaningful message.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) AS n FROM compta_esms.comptes_resultat " "WHERE etablissement_id = %s",
            (str(ets_id),),
        )
        row = cur.fetchone()
        return int(row["n"]) if row else 0


def og_exists_for_company(og_id: UUID, company_id: UUID) -> bool:
    """Verify that the path's ``og_id`` belongs to the auth's company.

    Defense in depth on top of RLS — confirms the OG exists *and* is
    in the caller's tenant before we try to create an établissement
    under it.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.organismes_gestionnaires "
            "WHERE id = %s AND company_id = %s",
            (str(og_id), str(company_id)),
        )
        return cur.fetchone() is not None
