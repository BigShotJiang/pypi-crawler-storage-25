"""Repository layer — direct SQL against the ``compta_esms.*`` schema.

Each repository module owns a single table; queries select against an
explicit column allowlist (``_COLUMNS`` constant) so a future
``ALTER TABLE ADD COLUMN`` cannot accidentally leak into API responses.

All functions are **synchronous** — they call ``with cursor() as cur``
from :mod:`piilot.sdk.db`. Async services wrap them via
:func:`piilot.sdk.db.run_in_thread` so the RLS user context propagates
across threads.
"""
