"""Repository for ``compta_esms.affectations_resultats`` (§J).

Bulk-upsert "by section" (plan-dev §7.5 Q8) implémenté via 2 paths
distincts pour respecter les 2 UNIQUE partiels posés par migration
010 :

* :func:`bulk_upsert_variant_I` — ON CONFLICT ``(document_id,
  variante, cr_id, compte_m22bis)`` — variants pre-CPOM (par CR).
* :func:`bulk_upsert_variant_II` — ON CONFLICT ``(document_id,
  variante, compte_m22bis)`` — variants post-CPOM (consolidé). cr_id
  doit être NULL.

Le service §J.7 dispatche selon la variante auto-déduite (Q3) et
écrit dans une seule transaction.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "variante",
    "ventilation",
    "cr_id",
    "compte_m22bis",
    "compte_label",
    "montant_soins_dependance",
    "montant_hebergement",
    "montant_total",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def list_by_document(document_id: UUID) -> list[dict[str, Any]]:
    """Retourne toutes les affectations du document.

    Tri stable : variante asc, cr_id (NULLS LAST), compte_m22bis asc."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.affectations_resultats "
            "WHERE document_id = %s "
            "ORDER BY variante, cr_id NULLS LAST, compte_m22bis",
            (str(document_id),),
        )
        return cur.fetchall()


def document_belongs_to_company(document_id: UUID, company_id: UUID) -> bool:
    """Defense in depth (pattern §H)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def get_doc_affectation_context(document_id: UUID, company_id: UUID) -> dict[str, Any] | None:
    """Retourne ``{type_document, exercice_id, og_id, nature_juridique,
    plan_comptable, any_inclus_cpom, all_inclus_cpom}`` du document.

    ``any_inclus_cpom`` = True ssi au moins un ETS de l'OG est inclus
    CPOM. ``all_inclus_cpom`` = True ssi tous les ETS le sont. Le
    service utilise ``any_inclus_cpom`` pour décider variante II
    (D-082 "pas de variante mixte" — on respecte la décision majeure
    portée par l'OG).

    ``nature_juridique`` est la 5-valeurs UPPER alignée sur la spec
    KB B.1 (migration 021).

    Returns None si le document n'existe pas ou n'appartient pas à
    la company (RLS-friendly).
    """
    with cursor() as cur:
        cur.execute(
            "SELECT d.id, d.type_document, d.exercice_id, "
            "       e.og_id, "
            "       og.nature_juridique, og.plan_comptable, "
            "       COALESCE(BOOL_OR(ets.inclus_cpom), false) AS any_inclus_cpom, "
            "       COALESCE(BOOL_AND(ets.inclus_cpom), false) AS all_inclus_cpom "
            "FROM compta_esms.documents_budgetaires d "
            "JOIN compta_esms.exercices e ON e.id = d.exercice_id "
            "JOIN compta_esms.organismes_gestionnaires og ON og.id = e.og_id "
            "LEFT JOIN compta_esms.etablissements ets ON ets.og_id = og.id "
            "WHERE d.id = %s AND d.company_id = %s "
            "GROUP BY d.id, d.type_document, d.exercice_id, "
            "         e.og_id, og.nature_juridique, og.plan_comptable",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone()


def list_etablissements_for_doc(document_id: UUID) -> list[dict[str, Any]]:
    """Retourne les ETS de l'OG du document (pour le snapshot
    suivi_affectations par ETS — Q6 auto au PUT)."""
    with cursor() as cur:
        cur.execute(
            "SELECT ets.id, ets.finess_ets, ets.raison_sociale "
            "FROM compta_esms.documents_budgetaires d "
            "JOIN compta_esms.exercices e ON e.id = d.exercice_id "
            "JOIN compta_esms.etablissements ets ON ets.og_id = e.og_id "
            "WHERE d.id = %s "
            "ORDER BY ets.raison_sociale, ets.id",
            (str(document_id),),
        )
        return cur.fetchall()


def cr_belongs_to_document(cr_id: UUID, document_id: UUID) -> bool:
    """Refuse un cr_id qui n'appartient pas au document — évite qu'un
    cabinet attache une affectation à un CR d'un autre document."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.comptes_resultat " "WHERE id = %s AND document_id = %s",
            (str(cr_id), str(document_id)),
        )
        return cur.fetchone() is not None


# ---------------------------------------------------------------------------
# Writes — bulk upsert
# ---------------------------------------------------------------------------


def _build_upsert_sql(unique_constraint_name: str) -> str:
    """Build the UPSERT template targeting the partial UNIQUE index
    (migration 010). Each variant family points at its own index :
    ``uq_affectations_variant_i`` or ``uq_affectations_variant_ii``."""
    insert_cols = [
        "company_id",
        "document_id",
        "variante",
        "ventilation",
        "cr_id",
        "compte_m22bis",
        "compte_label",
        "montant_soins_dependance",
        "montant_hebergement",
        "montant_total",
    ]
    insert_cols_sql = ", ".join(insert_cols)
    placeholders = ", ".join(["%s"] * len(insert_cols))

    update_cols = [
        "ventilation",
        "compte_label",
        "montant_soins_dependance",
        "montant_hebergement",
        "montant_total",
    ]
    update_sql = ", ".join(f"{c} = EXCLUDED.{c}" for c in update_cols)

    return (
        "INSERT INTO compta_esms.affectations_resultats "
        f"({insert_cols_sql}) VALUES ({placeholders}) "
        f"ON CONFLICT ON CONSTRAINT {unique_constraint_name} DO UPDATE SET "
        f"{update_sql}, updated_at = now() "
        f"RETURNING {_COLUMNS_SQL}"
    )


_UPSERT_VARIANT_I_SQL = _build_upsert_sql("uq_affectations_variant_i")
_UPSERT_VARIANT_II_SQL = _build_upsert_sql("uq_affectations_variant_ii")


def bulk_upsert_variant_I(
    *,
    company_id: UUID,
    document_id: UUID,
    variante: str,
    ventilation: str,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Bulk-upsert pour variantes ``prive_I`` / ``public_I``. Chaque
    item doit avoir ``cr_id`` non-NULL.

    Atomique (1 transaction via ``cursor()``). Returns la liste des
    rows post-UPSERT (created_at == updated_at pour les inserts)."""
    if not items:
        return []
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        for item in items:
            cr_id = item.get("cr_id")
            if cr_id is None:
                raise ValueError(f"variant_I requires cr_id (variante={variante!r})")
            values = (
                str(company_id),
                str(document_id),
                variante,
                ventilation,
                str(cr_id),
                item["compte_m22bis"],
                item.get("compte_label"),
                item.get("montant_soins_dependance"),
                item.get("montant_hebergement"),
                item.get("montant_total"),
            )
            cur.execute(_UPSERT_VARIANT_I_SQL, values)
            out.append(cur.fetchone())
    return out


def bulk_upsert_variant_II(
    *,
    company_id: UUID,
    document_id: UUID,
    variante: str,
    ventilation: str,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Bulk-upsert pour variantes ``prive_II`` / ``public_II``. cr_id
    doit être NULL (consolidé post-CPOM).
    """
    if not items:
        return []
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        for item in items:
            values = (
                str(company_id),
                str(document_id),
                variante,
                ventilation,
                None,  # cr_id always NULL for variant_II
                item["compte_m22bis"],
                item.get("compte_label"),
                item.get("montant_soins_dependance"),
                item.get("montant_hebergement"),
                item.get("montant_total"),
            )
            cur.execute(_UPSERT_VARIANT_II_SQL, values)
            out.append(cur.fetchone())
    return out


def delete_by_document(document_id: UUID) -> int:
    """Drop toutes les affectations du document — utilisé quand le
    cabinet change de variante (rare) ou réinitialise complètement."""
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.affectations_resultats " "WHERE document_id = %s",
            (str(document_id),),
        )
        return cur.rowcount
