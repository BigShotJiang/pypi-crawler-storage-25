"""Repository for ``compta_esms.balance_mappings`` (D-108).

Standard CRUD layer with two domain-specific helpers :

* :func:`bulk_upsert` — atomic upsert on the table's UNIQUE constraint
  ``(company_id, source_plan, source_account, target_m22bis_account,
  version_m22bis)``. Used by the ``:bulk-upsert`` action endpoint and
  by the CSV import path.
* :func:`sum_weights_by_source` — per-source aggregation used by the
  ``:validate`` endpoint to surface mappings whose Σ weight ≠ 1.0
  *before* an apply-mapping attempt rolls back on the DB trigger.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "source_plan",
    "source_account",
    "target_m22bis_account",
    "weight",
    "label_hint",
    "confidence",
    "suggestion_origin",
    "version_m22bis",
    "valid_from",
    "valid_to",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

_INSERTABLE: tuple[str, ...] = (
    "source_plan",
    "source_account",
    "target_m22bis_account",
    "weight",
    "label_hint",
    "confidence",
    "suggestion_origin",
    "version_m22bis",
    "valid_from",
    "valid_to",
)

# Patch is voluntarily narrow : the UNIQUE key columns aren't mutable.
# A "change of target" is delete + create, not a patch.
_UPDATABLE: frozenset[str] = frozenset(
    {
        "weight",
        "label_hint",
        "confidence",
        "suggestion_origin",
        "valid_from",
        "valid_to",
    }
)


def list_filtered(
    company_id: UUID,
    *,
    source_plan: str | None = None,
    source_account: str | None = None,
    version_m22bis: str | None = None,
    limit: int = 200,
) -> list[dict[str, Any]]:
    """List the mappings of a company, narrowed by optional filters.

    The default ``limit=200`` is generous — a typical balance has 800
    accounts but the dict only grows by the *unique* sources, so 200
    covers a healthy cabinet. Frontend paginates beyond if needed
    (the endpoint will pass the cap through)."""
    where = ["company_id = %s"]
    params: list[Any] = [str(company_id)]

    if source_plan is not None:
        where.append("source_plan = %s")
        params.append(source_plan)
    if source_account is not None:
        where.append("source_account = %s")
        params.append(source_account)
    if version_m22bis is not None:
        where.append("version_m22bis = %s")
        params.append(version_m22bis)

    sql = (
        f"SELECT {_COLUMNS_SQL} FROM compta_esms.balance_mappings "
        f"WHERE {' AND '.join(where)} "
        "ORDER BY source_plan, source_account, target_m22bis_account "
        "LIMIT %s"
    )
    params.append(limit)
    with cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def get_by_id(mapping_id: UUID) -> dict[str, Any] | None:
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.balance_mappings " "WHERE id = %s",
            (str(mapping_id),),
        )
        return cur.fetchone()


def find_unique(
    company_id: UUID,
    source_plan: str,
    source_account: str,
    target_m22bis_account: str,
    version_m22bis: str,
) -> dict[str, Any] | None:
    """Lookup by the table's UNIQUE 5-tuple.

    Used by the service before create to return a clean 409 rather than
    bouncing on the unique-violation. Also used by bulk_upsert when we
    need to know which rows already exist."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.balance_mappings "
            "WHERE company_id = %s AND source_plan = %s "
            "AND source_account = %s AND target_m22bis_account = %s "
            "AND version_m22bis = %s",
            (
                str(company_id),
                source_plan,
                source_account,
                target_m22bis_account,
                version_m22bis,
            ),
        )
        return cur.fetchone()


def create(company_id: UUID, payload: dict[str, Any]) -> dict[str, Any]:
    fields = [c for c in _INSERTABLE if c in payload]
    columns = ["company_id"] + fields
    values: list[Any] = [str(company_id)] + [payload[c] for c in fields]
    placeholders = ", ".join(["%s"] * len(columns))
    columns_sql = ", ".join(columns)
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.balance_mappings "
            f"({columns_sql}) VALUES ({placeholders}) "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def update(mapping_id: UUID, payload: dict[str, Any]) -> dict[str, Any] | None:
    fields = [c for c in payload if c in _UPDATABLE]
    if not fields:
        return get_by_id(mapping_id)
    set_clause = ", ".join(f"{c} = %s" for c in fields)
    values = [payload[c] for c in fields] + [str(mapping_id)]
    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.balance_mappings "
            f"SET {set_clause}, updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def delete(mapping_id: UUID) -> bool:
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.balance_mappings WHERE id = %s",
            (str(mapping_id),),
        )
        return cur.rowcount > 0


def bulk_upsert(company_id: UUID, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Atomic upsert of N mapping rows.

    Conflict resolution : ON CONFLICT on the UNIQUE 5-tuple, the row's
    mutable fields (``weight``, ``label_hint``, ``confidence``,
    ``suggestion_origin``, ``valid_from``, ``valid_to``) get the new
    values and ``updated_at`` bumps. The 5-tuple itself stays put
    (changing a target = delete + create, not a patch).

    The whole call sits in one cursor() transaction — if the Σ weight
    trigger fires on any row, the whole batch rolls back. We iterate
    ``cur.execute`` per row instead of ``execute_values`` so we can
    pull each RETURNING row back ; for our scale (~200 unique sources
    per balance) the round-trip overhead is negligible (~50ms total)
    compared to the LLM tier that comes next."""
    if not items:
        return []
    sql = (
        "INSERT INTO compta_esms.balance_mappings "
        "(company_id, source_plan, source_account, target_m22bis_account, "
        " weight, label_hint, confidence, suggestion_origin, version_m22bis) "
        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) "
        "ON CONFLICT (company_id, source_plan, source_account, "
        "             target_m22bis_account, version_m22bis) "
        "DO UPDATE SET "
        "  weight = EXCLUDED.weight, "
        "  label_hint = EXCLUDED.label_hint, "
        "  confidence = EXCLUDED.confidence, "
        "  suggestion_origin = EXCLUDED.suggestion_origin, "
        "  updated_at = now() "
        f"RETURNING {_COLUMNS_SQL}"
    )
    results: list[dict[str, Any]] = []
    with cursor() as cur:
        for item in items:
            cur.execute(
                sql,
                (
                    str(company_id),
                    item["source_plan"],
                    item["source_account"],
                    item["target_m22bis_account"],
                    item.get("weight", 1.0),
                    item.get("label_hint"),
                    item.get("confidence"),
                    item.get("suggestion_origin"),
                    item.get("version_m22bis", "2025-2026"),
                ),
            )
            row = cur.fetchone()
            if row is not None:
                results.append(row)
    return results


def sum_weights_by_source(
    company_id: UUID,
) -> list[dict[str, Any]]:
    """Per-source Σ weight aggregation.

    Returns one row per ``(source_plan, source_account, version_m22bis)``
    with ``total_weight`` and ``target_count``. The ``:validate``
    endpoint filters this to surface only the keys whose Σ ≠ 1.0
    (tolerance 1e-4 — matches the DB trigger's float fudge factor)."""
    with cursor() as cur:
        cur.execute(
            "SELECT source_plan, source_account, version_m22bis, "
            "       SUM(weight)::float AS total_weight, "
            "       COUNT(*)::int AS target_count "
            "FROM compta_esms.balance_mappings "
            "WHERE company_id = %s "
            "GROUP BY source_plan, source_account, version_m22bis "
            "ORDER BY source_plan, source_account",
            (str(company_id),),
        )
        return cur.fetchall()


def list_for_export(company_id: UUID) -> list[dict[str, Any]]:
    """Full mapping list for the CSV export — ordered for clean diffs.

    Project the columns the export contract needs ; we don't ship
    ``id`` / ``company_id`` / timestamps in the CSV (they'd round-trip
    to garbage on re-import)."""
    with cursor() as cur:
        cur.execute(
            "SELECT source_plan, source_account, target_m22bis_account, "
            "       weight, label_hint, confidence, suggestion_origin, "
            "       version_m22bis, valid_from, valid_to "
            "FROM compta_esms.balance_mappings "
            "WHERE company_id = %s "
            "ORDER BY source_plan, source_account, target_m22bis_account",
            (str(company_id),),
        )
        return cur.fetchall()
