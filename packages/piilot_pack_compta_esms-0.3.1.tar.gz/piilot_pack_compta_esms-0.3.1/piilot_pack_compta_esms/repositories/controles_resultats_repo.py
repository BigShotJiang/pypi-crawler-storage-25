"""Repository for ``compta_esms.controles_resultats`` (§Z).

Persistence des résultats d'évaluation. Pattern aligné sur les autres
repos : sync, column allowlist, RLS-scoped via ``cursor()``.

Spécificité : bulk-upsert idempotent (1 résultat par (doc, code))
plutôt qu'INSERT+UPDATE séparés — on écrase le résultat précédent
à chaque ``:run`` complet.
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

import psycopg2.extras
from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "code",
    "statut",
    "severite_observee",
    "valeurs_observees",
    "message_humain",
    "evaluated_at",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


def list_by_document(
    document_id: UUID,
    *,
    statut: str | None = None,
    severite: str | None = None,
) -> list[dict[str, Any]]:
    """Liste les résultats d'un document, ordre alphabétique des codes."""
    where = ["document_id = %s"]
    params: list[Any] = [str(document_id)]
    if statut is not None:
        where.append("statut = %s")
        params.append(statut)
    if severite is not None:
        where.append("severite_observee = %s")
        params.append(severite)
    sql = (
        f"SELECT {_COLUMNS_SQL} FROM compta_esms.controles_resultats "
        f"WHERE {' AND '.join(where)} "
        "ORDER BY code"
    )
    with cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def get_by_doc_code(document_id: UUID, code: str) -> dict[str, Any] | None:
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.controles_resultats "
            "WHERE document_id = %s AND code = %s",
            (str(document_id), code),
        )
        return cur.fetchone()


def bulk_upsert(
    company_id: UUID,
    document_id: UUID,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Upsert idempotent par (document_id, code) — écrase à chaque run.

    Chaque item doit avoir : ``code``, ``statut``, ``severite_observee``,
    ``valeurs_observees`` (dict → JSONB), ``message_humain``.
    ``evaluated_at`` est posé côté DB via ``now()``.
    """
    if not items:
        return []

    with cursor() as cur:
        # 1 ROUND-TRIP via execute_values + ON CONFLICT DO UPDATE.
        values = [
            (
                str(company_id),
                str(document_id),
                item["code"],
                item["statut"],
                item["severite_observee"],
                psycopg2.extras.Json(item.get("valeurs_observees") or {}),
                item.get("message_humain"),
            )
            for item in items
        ]
        psycopg2.extras.execute_values(
            cur,
            (
                "INSERT INTO compta_esms.controles_resultats "
                "(company_id, document_id, code, statut, severite_observee, "
                " valeurs_observees, message_humain, evaluated_at) "
                "VALUES %s "
                "ON CONFLICT (document_id, code) DO UPDATE SET "
                "  statut = EXCLUDED.statut, "
                "  severite_observee = EXCLUDED.severite_observee, "
                "  valeurs_observees = EXCLUDED.valeurs_observees, "
                "  message_humain = EXCLUDED.message_humain, "
                "  evaluated_at = now(), "
                "  updated_at = now() "
                f"RETURNING {_COLUMNS_SQL}"
            ),
            values,
            template="(%s, %s, %s, %s, %s, %s, %s, now())",
            page_size=200,
        )
        return cur.fetchall()


def compute_summary_for_doc(document_id: UUID) -> dict[str, int]:
    """Agrège les compteurs OK/KO/NA pour le summary endpoint.

    Retourne ``{ok: N, ko: M, na: K, total: T, ko_bloquant: B, ko_error: E}``.
    ``ko_bloquant`` = count des statut='ko' AND severite_observee='error'
    sur les 3 contrôles bloquants D-034 (C-001, C-002, C-003)."""
    with cursor() as cur:
        cur.execute(
            "SELECT statut, severite_observee, code "
            "FROM compta_esms.controles_resultats "
            "WHERE document_id = %s",
            (str(document_id),),
        )
        rows = cur.fetchall()

    summary = {
        "ok": 0,
        "ko": 0,
        "na": 0,
        "total": len(rows),
        "ko_bloquant": 0,
        "ko_error": 0,
        "ko_warning": 0,
    }
    bloquant_codes = {"C-001", "C-002", "C-003"}
    for r in rows:
        statut = r["statut"]
        sev = r["severite_observee"]
        summary[statut] = summary.get(statut, 0) + 1
        if statut == "ko":
            if sev == "error":
                summary["ko_error"] += 1
            elif sev == "warning":
                summary["ko_warning"] += 1
            if r["code"] in bloquant_codes:
                summary["ko_bloquant"] += 1
    return summary


def list_ko_bloquants_for_doc(document_id: UUID) -> list[dict[str, Any]]:
    """Liste les KO sur les codes bloquants D-034 — utilisé par §S guard
    transmit pour refuser 409 transition_blocked_by_failed_control."""
    bloquant_codes = ("C-001", "C-002", "C-003")
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.controles_resultats "
            "WHERE document_id = %s AND statut = 'ko' "
            "  AND code = ANY(%s::TEXT[])",
            (str(document_id), list(bloquant_codes)),
        )
        return cur.fetchall()
