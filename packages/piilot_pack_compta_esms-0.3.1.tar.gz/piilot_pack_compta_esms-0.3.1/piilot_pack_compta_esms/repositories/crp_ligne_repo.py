"""Repository for ``compta_esms.crp_lignes`` (§H, L2 §6).

The natural key ``(cr_id, groupe, nature, compte_m22bis)`` is enforced
by migration 009. Repos here rely on it for :

* :func:`upsert_one` and :func:`bulk_upsert` use ``ON CONFLICT
  ON CONSTRAINT crp_lignes_natural_key DO UPDATE`` and COALESCE the
  preservation fields (``notes`` / ``binding_id`` / ``override_*``) so
  re-runs of a bulk-upsert don't blow away cabinet-side metadata.
* :func:`update` keeps the natural key out of the UPDATE list — the
  service layer raises if the cabinet tries to flip ``groupe`` or
  ``nature`` on an existing line.

``compte_m22bis`` validation is done in the service layer
(fail-open lookup against the core PLT-M21 KB) — not here.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "cr_id",
    "groupe",
    "nature",
    "compte_m22bis",
    "compte_label",
    "montant_budget_initial",
    "montant_virements_credits",
    "montant_decisions_modif",
    "montant_previsions_totales",
    "montant_realise",
    "montant_hebergement",
    "montant_dependance",
    "montant_soins",
    "montant_soins_autonomie",
    "binding_id",
    "saisie_manuelle",
    "override_balance",
    "override_reason",
    "override_at",
    "notes",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

# Columns whose value can be patched by the cabinet on PATCH. The
# natural key (cr_id, groupe, nature, compte_m22bis) is excluded — the
# service layer raises if a payload would change it. ``binding_id`` /
# ``saisie_manuelle`` are also excluded — they're set at creation time
# (manual vs prefill) and stay stable. ``override_balance`` /
# ``override_at`` are flipped by the service (Q6 auto-flip), not by
# the route payload.
_UPDATABLE: frozenset[str] = frozenset(
    {
        "compte_label",
        "montant_budget_initial",
        "montant_virements_credits",
        "montant_decisions_modif",
        "montant_previsions_totales",
        "montant_realise",
        "montant_hebergement",
        "montant_dependance",
        "montant_soins",
        "montant_soins_autonomie",
        "notes",
        "override_reason",
    }
)

# Columns the bulk-upsert preserves via COALESCE when not in the
# payload. The natural key is in the ON CONFLICT clause itself, so
# it's not listed here.
_PRESERVE_ON_UPSERT: tuple[str, ...] = (
    "compte_label",
    "montant_budget_initial",
    "montant_virements_credits",
    "montant_decisions_modif",
    "montant_previsions_totales",
    "montant_realise",
    "montant_hebergement",
    "montant_dependance",
    "montant_soins",
    "montant_soins_autonomie",
    "notes",
    "binding_id",
    "override_balance",
    "override_reason",
    "override_at",
    "saisie_manuelle",
)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def list_by_cr(
    cr_id: UUID,
    *,
    groupe: str | None = None,
    nature: str | None = None,
) -> list[dict[str, Any]]:
    """Return lignes for a CR, optionally filtered by groupe / nature.

    Sort key : ``(groupe, nature, compte_m22bis)`` so a section's
    saisie tableau is rendered in a stable, account-ordered way."""
    where: list[str] = ["cr_id = %s"]
    params: list[Any] = [str(cr_id)]
    if groupe is not None:
        where.append("groupe = %s")
        params.append(groupe)
    if nature is not None:
        where.append("nature = %s")
        params.append(nature)
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.crp_lignes "
            f"WHERE {' AND '.join(where)} "
            "ORDER BY groupe, nature, compte_m22bis",
            params,
        )
        return cur.fetchall()


def get_by_id(ligne_id: UUID) -> dict[str, Any] | None:
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.crp_lignes WHERE id = %s",
            (str(ligne_id),),
        )
        return cur.fetchone()


def cr_belongs_to_company(cr_id: UUID, company_id: UUID) -> bool:
    """Defense in depth — used by the service before any cr-scoped op."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.comptes_resultat " "WHERE id = %s AND company_id = %s",
            (str(cr_id), str(company_id)),
        )
        return cur.fetchone() is not None


def get_cr_context(cr_id: UUID) -> dict[str, Any] | None:
    """Return ``{cr_variante, document_id, type_document}`` for :totals
    and :prefill-from-binding. One SQL hop instead of two."""
    with cursor() as cur:
        cur.execute(
            "SELECT cr.cr_variante, cr.document_id, d.type_document "
            "FROM compta_esms.comptes_resultat cr "
            "JOIN compta_esms.documents_budgetaires d ON d.id = cr.document_id "
            "WHERE cr.id = %s",
            (str(cr_id),),
        )
        return cur.fetchone()


# ---------------------------------------------------------------------------
# Writes — single row
# ---------------------------------------------------------------------------


def create(
    *,
    company_id: UUID,
    cr_id: UUID,
    payload: dict[str, Any],
    binding_id: UUID | None = None,
) -> dict[str, Any]:
    """Insert one ligne. Raises ``psycopg2.errors.UniqueViolation``
    when the natural key collides — the service layer maps that to a
    409 ``ConflictError``."""
    fields = [
        c
        for c in payload
        if c in _UPDATABLE or c in ("groupe", "nature", "compte_m22bis", "saisie_manuelle")
    ]
    columns = ["company_id", "cr_id"] + fields
    values: list[Any] = [str(company_id), str(cr_id)] + [payload[c] for c in fields]
    if binding_id is not None:
        columns.append("binding_id")
        values.append(str(binding_id))
    columns_sql = ", ".join(columns)
    placeholders = ", ".join(["%s"] * len(columns))
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.crp_lignes "
            f"({columns_sql}) VALUES ({placeholders}) "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def update(
    ligne_id: UUID,
    payload: dict[str, Any],
    *,
    flip_override_balance: bool = False,
) -> dict[str, Any] | None:
    """PATCH a ligne. ``payload`` is filtered to :data:`_UPDATABLE`.

    When ``flip_override_balance=True`` (service layer decides — Q6
    auto-flip when the row has ``binding_id`` non-NULL), we add
    ``override_balance=true`` and ``override_at=now()`` to the SET
    clause."""
    fields = [c for c in payload if c in _UPDATABLE]
    if not fields and not flip_override_balance:
        return get_by_id(ligne_id)

    set_parts = [f"{c} = %s" for c in fields]
    values = [payload[c] for c in fields]
    if flip_override_balance:
        set_parts.append("override_balance = true")
        set_parts.append("override_at = now()")
    set_clause = ", ".join(set_parts)
    values.append(str(ligne_id))

    with cursor() as cur:
        cur.execute(
            "UPDATE compta_esms.crp_lignes "
            f"SET {set_clause}, updated_at = now() "
            f"WHERE id = %s RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def delete(ligne_id: UUID) -> bool:
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.crp_lignes WHERE id = %s",
            (str(ligne_id),),
        )
        return cur.rowcount > 0


# ---------------------------------------------------------------------------
# Writes — bulk upsert (Q4)
# ---------------------------------------------------------------------------


def _build_upsert_sql() -> str:
    """Return the :data:`bulk_upsert` SQL template. Built once at
    module load time so we don't re-concat the COALESCE clause for
    every call."""
    # Columns we INSERT — natural key + every value column + binding /
    # saisie / override_* / notes. Order matters : matches the VALUES
    # tuple built in :func:`bulk_upsert`.
    insert_cols = [
        "company_id",
        "cr_id",
        "groupe",
        "nature",
        "compte_m22bis",
        "compte_label",
        "montant_budget_initial",
        "montant_virements_credits",
        "montant_decisions_modif",
        "montant_previsions_totales",
        "montant_realise",
        "montant_hebergement",
        "montant_dependance",
        "montant_soins",
        "montant_soins_autonomie",
        "binding_id",
        "saisie_manuelle",
        "override_balance",
        "override_reason",
        "override_at",
        "notes",
    ]
    insert_cols_sql = ", ".join(insert_cols)
    placeholders = ", ".join(["%s"] * len(insert_cols))

    # COALESCE clauses : on conflict, prefer the EXCLUDED value (what
    # the caller passed) but fall back to the existing row when the
    # caller passed NULL. Preserves the cabinet's manual notes /
    # binding linkage / overrides across bulk-upsert re-runs (Q4).
    coalesce_parts = [
        f"{col} = COALESCE(EXCLUDED.{col}, compta_esms.crp_lignes.{col})"
        for col in _PRESERVE_ON_UPSERT
    ]
    coalesce_sql = ", ".join(coalesce_parts)

    return (
        "INSERT INTO compta_esms.crp_lignes "
        f"({insert_cols_sql}) VALUES ({placeholders}) "
        "ON CONFLICT ON CONSTRAINT crp_lignes_natural_key DO UPDATE SET "
        f"{coalesce_sql}, updated_at = now() "
        f"RETURNING {_COLUMNS_SQL}"
    )


_UPSERT_SQL = _build_upsert_sql()


def _coerce_decimal(value: Any) -> Decimal | None:
    """Pass-through helper used by :func:`bulk_upsert` to keep
    ``Decimal`` instances intact (psycopg2 adapts them to PG
    ``NUMERIC`` natively) while letting ``None`` flow as SQL NULL."""
    if value is None:
        return None
    return Decimal(str(value)) if not isinstance(value, Decimal) else value


def bulk_upsert(
    *,
    company_id: UUID,
    cr_id: UUID,
    items: list[dict[str, Any]],
    binding_id: UUID | None = None,
) -> list[dict[str, Any]]:
    """Atomic bulk upsert.

    Each item is a flat dict matching :class:`BulkUpsertItem`. The
    function executes one INSERT per item inside a single transaction
    so partial failures roll back (the SDK's ``cursor()`` context
    commits at the end). ``binding_id`` is the same for every item
    when called from :func:`prefill_from_binding`, and None when
    called from the manual ``:bulk-upsert`` route.

    Returns the list of resulting rows (each is the post-UPSERT state,
    so the caller can show "+5 inserted, ~3 updated" by comparing
    ``created_at == updated_at``).
    """
    if not items:
        return []
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        for item in items:
            values = (
                str(company_id),
                str(cr_id),
                item["groupe"],
                item["nature"],
                item["compte_m22bis"],
                item.get("compte_label"),
                _coerce_decimal(item.get("montant_budget_initial")),
                _coerce_decimal(item.get("montant_virements_credits")),
                _coerce_decimal(item.get("montant_decisions_modif")),
                _coerce_decimal(item.get("montant_previsions_totales")),
                _coerce_decimal(item.get("montant_realise")),
                _coerce_decimal(item.get("montant_hebergement")),
                _coerce_decimal(item.get("montant_dependance")),
                _coerce_decimal(item.get("montant_soins")),
                _coerce_decimal(item.get("montant_soins_autonomie")),
                str(binding_id) if binding_id is not None else None,
                item.get("saisie_manuelle", False),
                False,  # override_balance — fresh inserts never flip it
                None,
                None,
                item.get("notes"),
            )
            cur.execute(_UPSERT_SQL, values)
            out.append(cur.fetchone())
    return out


def list_overridden_keys(cr_id: UUID) -> set[tuple[str, str, str]]:
    """Return the set of ``(groupe, nature, compte_m22bis)`` tuples in
    a CR whose ``override_balance`` is true. The prefill service uses
    this to filter out rows it shouldn't touch (Q6)."""
    with cursor() as cur:
        cur.execute(
            "SELECT groupe, nature, compte_m22bis "
            "FROM compta_esms.crp_lignes "
            "WHERE cr_id = %s AND override_balance = true",
            (str(cr_id),),
        )
        return {(r["groupe"], r["nature"], r["compte_m22bis"]) for r in cur.fetchall()}


# ---------------------------------------------------------------------------
# Totals (Q5)
# ---------------------------------------------------------------------------


def totals_by_groupe(cr_id: UUID) -> list[dict[str, Any]]:
    """Aggregate ``previsions_totales`` and ``realise`` by groupe ×
    nature. NULL montants are treated as 0 by ``SUM`` (PG default).

    Returns one row per (groupe, nature) couple that has data ; the
    service layer pivots these into the flat
    :class:`CrpTotalsResponse` shape with explicit zeros for missing
    sections.
    """
    with cursor() as cur:
        cur.execute(
            "SELECT groupe, nature, "
            "       COALESCE(SUM(montant_previsions_totales), 0) AS previsions_totales, "
            "       COALESCE(SUM(montant_realise), 0) AS realise "
            "FROM compta_esms.crp_lignes "
            "WHERE cr_id = %s "
            "GROUP BY groupe, nature "
            "ORDER BY groupe, nature",
            (str(cr_id),),
        )
        return cur.fetchall()
