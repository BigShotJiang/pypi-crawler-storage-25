"""Repository for ``compta_esms.pgfp_lignes`` (§O, L2 §9).

Sémantique Q4 — **upsert partiel par ligne_key**. ON CONFLICT
``(document_id, ligne_key)`` WHERE cr_id IS NULL via partial unique
index ``uq_pgfp_lignes_doc_key_global`` (migration 011).

Le DDL supporte aussi un usage CRP_PGFP par CR (cr_id défini, D-096) qui
sera traité en §Y. §O ne touche QUE les rows avec ``cr_id IS NULL``.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "cr_id",
    "section",
    "ligne_key",
    "ligne_label",
    "montant_nm1",
    "montant_n",
    "montant_np1",
    "montant_np2",
    "montant_np3",
    "montant_np4",
    "montant_np5",
    "montant_np6",
    "created_at",
    "updated_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)

_MONEY_COLUMNS: tuple[str, ...] = (
    "montant_nm1",
    "montant_n",
    "montant_np1",
    "montant_np2",
    "montant_np3",
    "montant_np4",
    "montant_np5",
    "montant_np6",
)


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------


def list_by_document(document_id: UUID) -> list[dict[str, Any]]:
    """Liste les rows PGFP global d'un document (cr_id IS NULL).

    Tri stable : section (selon ordre alphabétique DB pas idéal mais
    le service merge avec le template ordonné), ligne_key."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.pgfp_lignes "
            "WHERE document_id = %s AND cr_id IS NULL "
            "ORDER BY section, ligne_key",
            (str(document_id),),
        )
        return cur.fetchall()


def document_belongs_to_company(document_id: UUID, company_id: UUID) -> bool:
    """Defense in depth (pattern §H/§J/§K/§M/§N)."""
    with cursor() as cur:
        cur.execute(
            "SELECT 1 FROM compta_esms.documents_budgetaires " "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone() is not None


def get_doc_type_document(document_id: UUID, company_id: UUID) -> dict[str, Any] | None:
    """Q8 — retourne ``{type_document}`` pour le guard EPRD/DM/RIA only."""
    with cursor() as cur:
        cur.execute(
            "SELECT type_document FROM compta_esms.documents_budgetaires "
            "WHERE id = %s AND company_id = %s",
            (str(document_id), str(company_id)),
        )
        return cur.fetchone()


# ---------------------------------------------------------------------------
# Writes — upsert by (doc, ligne_key) WHERE cr_id IS NULL  (Q4)
# ---------------------------------------------------------------------------


def _coerce_decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def upsert_by_ligne_key(
    *,
    company_id: UUID,
    document_id: UUID,
    ligne_key: str,
    section: str,
    ligne_label: str | None,
    montants: dict[str, Decimal | None],
) -> dict[str, Any]:
    """Upsert atomique pour une ligne PGFP global (cr_id IS NULL).

    ON CONFLICT cible le partial unique index
    ``uq_pgfp_lignes_doc_key_global`` (migration 011). Update seulement
    les colonnes monétaires non-NULL du payload (préserve les valeurs
    existantes pour les colonnes omises — sémantique PATCH partial)."""
    values = (
        str(company_id),
        str(document_id),
        section,
        ligne_key,
        ligne_label,
        _coerce_decimal(montants.get("montant_nm1")),
        _coerce_decimal(montants.get("montant_n")),
        _coerce_decimal(montants.get("montant_np1")),
        _coerce_decimal(montants.get("montant_np2")),
        _coerce_decimal(montants.get("montant_np3")),
        _coerce_decimal(montants.get("montant_np4")),
        _coerce_decimal(montants.get("montant_np5")),
        _coerce_decimal(montants.get("montant_np6")),
    )
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.pgfp_lignes "
            "(company_id, document_id, cr_id, section, ligne_key, ligne_label, "
            " montant_nm1, montant_n, montant_np1, montant_np2, montant_np3, "
            " montant_np4, montant_np5, montant_np6) "
            "VALUES (%s, %s, NULL, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) "
            "ON CONFLICT (document_id, ligne_key) WHERE cr_id IS NULL "
            "DO UPDATE SET "
            "  ligne_label = EXCLUDED.ligne_label, "
            "  section = EXCLUDED.section, "
            "  montant_nm1 = COALESCE(EXCLUDED.montant_nm1, "
            "                         compta_esms.pgfp_lignes.montant_nm1), "
            "  montant_n   = COALESCE(EXCLUDED.montant_n, "
            "                         compta_esms.pgfp_lignes.montant_n), "
            "  montant_np1 = COALESCE(EXCLUDED.montant_np1, "
            "                         compta_esms.pgfp_lignes.montant_np1), "
            "  montant_np2 = COALESCE(EXCLUDED.montant_np2, "
            "                         compta_esms.pgfp_lignes.montant_np2), "
            "  montant_np3 = COALESCE(EXCLUDED.montant_np3, "
            "                         compta_esms.pgfp_lignes.montant_np3), "
            "  montant_np4 = COALESCE(EXCLUDED.montant_np4, "
            "                         compta_esms.pgfp_lignes.montant_np4), "
            "  montant_np5 = COALESCE(EXCLUDED.montant_np5, "
            "                         compta_esms.pgfp_lignes.montant_np5), "
            "  montant_np6 = COALESCE(EXCLUDED.montant_np6, "
            "                         compta_esms.pgfp_lignes.montant_np6), "
            "  updated_at = now() "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()


def overwrite_by_ligne_key(
    *,
    company_id: UUID,
    document_id: UUID,
    ligne_key: str,
    section: str,
    ligne_label: str | None,
    montants: dict[str, Decimal | None],
) -> dict[str, Any]:
    """Upsert atomique qui **écrase** les 8 colonnes (vs ``upsert_by_ligne_key``
    qui préserve via COALESCE).

    Utilisé par :recompute pour les lignes ``is_computed=True`` : les
    formules produisent la valeur complète des 8 exercices, on remplace
    intégralement (pas de COALESCE)."""
    values = (
        str(company_id),
        str(document_id),
        section,
        ligne_key,
        ligne_label,
        _coerce_decimal(montants.get("montant_nm1")),
        _coerce_decimal(montants.get("montant_n")),
        _coerce_decimal(montants.get("montant_np1")),
        _coerce_decimal(montants.get("montant_np2")),
        _coerce_decimal(montants.get("montant_np3")),
        _coerce_decimal(montants.get("montant_np4")),
        _coerce_decimal(montants.get("montant_np5")),
        _coerce_decimal(montants.get("montant_np6")),
    )
    with cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.pgfp_lignes "
            "(company_id, document_id, cr_id, section, ligne_key, ligne_label, "
            " montant_nm1, montant_n, montant_np1, montant_np2, montant_np3, "
            " montant_np4, montant_np5, montant_np6) "
            "VALUES (%s, %s, NULL, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) "
            "ON CONFLICT (document_id, ligne_key) WHERE cr_id IS NULL "
            "DO UPDATE SET "
            "  ligne_label = EXCLUDED.ligne_label, "
            "  section = EXCLUDED.section, "
            "  montant_nm1 = EXCLUDED.montant_nm1, "
            "  montant_n   = EXCLUDED.montant_n, "
            "  montant_np1 = EXCLUDED.montant_np1, "
            "  montant_np2 = EXCLUDED.montant_np2, "
            "  montant_np3 = EXCLUDED.montant_np3, "
            "  montant_np4 = EXCLUDED.montant_np4, "
            "  montant_np5 = EXCLUDED.montant_np5, "
            "  montant_np6 = EXCLUDED.montant_np6, "
            "  updated_at = now() "
            f"RETURNING {_COLUMNS_SQL}",
            values,
        )
        return cur.fetchone()
