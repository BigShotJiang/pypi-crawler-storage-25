"""Repository for ``compta_esms.suivi_affectations`` (§J, D-084).

Audit trail triplet (solde_debut_n / mouvements / solde_fin_n) par
``(document, etablissement, compte_m22bis)``. Alimenté automatiquement
par le service §J.7 au moment du ``PUT /affectations`` (Q6 = auto).
Pas d'endpoint mut séparé — seulement GET §L2 §10.4.

Sémantique du replace : à chaque PUT affectations on remplace le
suivi du document (DELETE + INSERT batch). C'est cohérent avec le
fait que le suivi est dérivé des affectations + du suivi N-1 (le
service ré-applique la formule à chaque PUT).
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID

from piilot.sdk.db import cursor

_COLUMNS: tuple[str, ...] = (
    "id",
    "company_id",
    "document_id",
    "etablissement_id",
    "compte_m22bis",
    "solde_debut_n",
    "mouvements_credit",
    "mouvements_debit",
    "solde_fin_n",
    "created_at",
)
_COLUMNS_SQL = ", ".join(_COLUMNS)


def list_by_document(document_id: UUID) -> list[dict[str, Any]]:
    """Tri stable : etablissement_id (NULLS LAST), compte_m22bis."""
    with cursor() as cur:
        cur.execute(
            f"SELECT {_COLUMNS_SQL} FROM compta_esms.suivi_affectations "
            "WHERE document_id = %s "
            "ORDER BY etablissement_id NULLS LAST, compte_m22bis",
            (str(document_id),),
        )
        return cur.fetchall()


def bulk_replace_by_document(
    *,
    company_id: UUID,
    document_id: UUID,
    items: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """DELETE puis INSERT batch — atomique (1 transaction).

    Chaque item porte ``etablissement_id`` (optionnel — NULL pour
    consolidé), ``compte_m22bis``, ``solde_debut_n``,
    ``mouvements_credit``, ``mouvements_debit``, ``solde_fin_n``.
    Les Decimal sont gérés nativement par psycopg2 NUMERIC adapter.
    """
    out: list[dict[str, Any]] = []
    with cursor() as cur:
        cur.execute(
            "DELETE FROM compta_esms.suivi_affectations WHERE document_id = %s",
            (str(document_id),),
        )
        for item in items:
            values = (
                str(company_id),
                str(document_id),
                str(item["etablissement_id"]) if item.get("etablissement_id") else None,
                item["compte_m22bis"],
                _coerce_decimal(item.get("solde_debut_n")),
                _coerce_decimal(item.get("mouvements_credit")),
                _coerce_decimal(item.get("mouvements_debit")),
                _coerce_decimal(item.get("solde_fin_n")),
            )
            cur.execute(
                "INSERT INTO compta_esms.suivi_affectations "
                "(company_id, document_id, etablissement_id, compte_m22bis, "
                " solde_debut_n, mouvements_credit, mouvements_debit, "
                " solde_fin_n) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s) "
                f"RETURNING {_COLUMNS_SQL}",
                values,
            )
            out.append(cur.fetchone())
    return out


def _coerce_decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def lookup_n_minus_1_balances(
    *,
    company_id: UUID,
    og_id: UUID,
    annee_courante: int,
) -> dict[tuple[str | None, str], Decimal]:
    """Cherche les ``solde_fin_n`` des affectations de l'exercice N-1
    du même OG. Retourne un dict ``{(etablissement_id_str_or_None,
    compte_m22bis): Decimal}`` que le service §J.7 utilise pour
    initialiser ``solde_debut_n`` au PUT.

    Stratégie : trouver le document ERRD de l'exercice ``annee - 1``
    pour cet OG, puis lire son ``suivi_affectations``. Retourne dict
    vide s'il n'y a pas d'exercice N-1 (cas premier ERRD du cabinet).
    """
    with cursor() as cur:
        cur.execute(
            "SELECT s.etablissement_id, s.compte_m22bis, s.solde_fin_n "
            "FROM compta_esms.suivi_affectations s "
            "JOIN compta_esms.documents_budgetaires d ON d.id = s.document_id "
            "JOIN compta_esms.exercices e ON e.id = d.exercice_id "
            "WHERE d.company_id = %s "
            "  AND e.og_id = %s "
            "  AND e.annee = %s "
            "  AND d.type_document = 'errd'",
            (str(company_id), str(og_id), annee_courante - 1),
        )
        out: dict[tuple[str | None, str], Decimal] = {}
        for row in cur.fetchall():
            key = (
                str(row["etablissement_id"]) if row.get("etablissement_id") else None,
                row["compte_m22bis"],
            )
            if row["solde_fin_n"] is not None:
                out[key] = Decimal(str(row["solde_fin_n"]))
        return out
