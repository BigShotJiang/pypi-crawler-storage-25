"""Unit tests for :mod:`piilot_pack_compta_esms.services.pgfp_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.pgfp import (
    PGFP_LINES_TEMPLATE,
    PgfpPatchItem,
    PgfpPatchRequest,
)
from piilot_pack_compta_esms.services import pgfp_service
from piilot_pack_compta_esms.services.errors import NotFoundError, ValidationError

COMPANY = uuid4()
DOC_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr("piilot_pack_compta_esms.services.pgfp_service.run_in_thread", _passthrough)


@pytest.fixture
def valid_eprd_doc(monkeypatch):
    """doc.type_document='eprd' → PGFP applicable (Q8)."""
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "get_doc_type_document",
        lambda doc, company: {"type_document": "eprd"},
    )


@pytest.fixture
def errd_doc(monkeypatch):
    """doc.type_document='errd' → PGFP refusé (Q8)."""
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "get_doc_type_document",
        lambda doc, company: {"type_document": "errd"},
    )


def _db_row(ligne_key: str, section: str = "crp_consolides", **montants):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "cr_id": None,
        "section": section,
        "ligne_key": ligne_key,
        "ligne_label": None,
        "montant_nm1": None,
        "montant_n": None,
        "montant_np1": None,
        "montant_np2": None,
        "montant_np3": None,
        "montant_np4": None,
        "montant_np5": None,
        "montant_np6": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(montants)
    return base


# ---------------------------------------------------------------------------
# Template structural tests
# ---------------------------------------------------------------------------


def test_template_covers_all_10_sections():
    sections = {spec.section for spec in PGFP_LINES_TEMPLATE}
    expected = {
        "crp_consolides",
        "caf",
        "fri",
        "fre",
        "frng",
        "bfr",
        "tresorerie",
        "controles_coherence",
        "donnees_complementaires",
        "ratios",
    }
    assert sections == expected


def test_template_has_unique_ligne_keys():
    keys = [spec.ligne_key for spec in PGFP_LINES_TEMPLATE]
    assert len(keys) == len(set(keys))


# ---------------------------------------------------------------------------
# list_pgfp
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_empty_db_returns_full_template(
    patch_run_in_thread, valid_eprd_doc, monkeypatch
):
    """DB vide → 125 lignes du template, toutes à null."""
    monkeypatch.setattr(pgfp_service.pgfp_repo, "list_by_document", lambda d: [])

    result = await pgfp_service.list_pgfp(DOC_ID, COMPANY)

    assert len(result.items) == len(PGFP_LINES_TEMPLATE)
    # All montants null
    for item in result.items:
        assert item.montant_nm1 is None
        assert item.id is None


@pytest.mark.asyncio
async def test_list_merges_db_rows_into_template(patch_run_in_thread, valid_eprd_doc, monkeypatch):
    """DB a 2 lignes → template complet avec ces 2 lignes renseignées."""
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "list_by_document",
        lambda d: [
            _db_row("crp_g1_charges", montant_n=Decimal("100000")),
            _db_row("frng_initial", section="frng", montant_n=Decimal("250000")),
        ],
    )

    result = await pgfp_service.list_pgfp(DOC_ID, COMPANY)

    g1 = next(it for it in result.items if it.ligne_key == "crp_g1_charges")
    frng_init = next(it for it in result.items if it.ligne_key == "frng_initial")
    assert g1.montant_n == Decimal("100000")
    assert g1.id is not None
    assert frng_init.montant_n == Decimal("250000")


@pytest.mark.asyncio
async def test_list_errd_doc_rejects_422_pgfp_not_applicable(patch_run_in_thread, errd_doc):
    """Q8 — type_document='errd' → 422."""
    with pytest.raises(ValidationError) as exc:
        await pgfp_service.list_pgfp(DOC_ID, COMPANY)
    assert exc.value.code == "pgfp_not_applicable"


@pytest.mark.asyncio
async def test_list_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "get_doc_type_document",
        lambda doc, company: None,
    )

    with pytest.raises(NotFoundError):
        await pgfp_service.list_pgfp(DOC_ID, COMPANY)


# ---------------------------------------------------------------------------
# patch_pgfp
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_patch_upserts_saisie_lines(patch_run_in_thread, valid_eprd_doc, monkeypatch):
    calls = []

    def _upsert(*, company_id, document_id, ligne_key, section, ligne_label, montants):
        calls.append({"ligne_key": ligne_key, "section": section})
        return _db_row(ligne_key, section=section, **montants)

    monkeypatch.setattr(pgfp_service.pgfp_repo, "upsert_by_ligne_key", _upsert)
    monkeypatch.setattr(pgfp_service.pgfp_repo, "list_by_document", lambda d: [])

    payload = PgfpPatchRequest(
        items=[
            PgfpPatchItem(ligne_key="crp_g1_charges", montant_n=Decimal("100000")),
            PgfpPatchItem(ligne_key="frng_initial", montant_n=Decimal("250000")),
        ]
    )
    result = await pgfp_service.patch_pgfp(DOC_ID, COMPANY, payload)

    assert len(calls) == 2
    assert calls[0]["ligne_key"] == "crp_g1_charges"
    assert calls[0]["section"] == "crp_consolides"
    assert calls[1]["ligne_key"] == "frng_initial"
    assert calls[1]["section"] == "frng"
    assert len(result.items) == len(PGFP_LINES_TEMPLATE)


@pytest.mark.asyncio
async def test_patch_unknown_ligne_key_422(patch_run_in_thread, valid_eprd_doc, monkeypatch):
    monkeypatch.setattr(pgfp_service.pgfp_repo, "upsert_by_ligne_key", lambda **kw: None)
    monkeypatch.setattr(pgfp_service.pgfp_repo, "list_by_document", lambda d: [])

    payload = PgfpPatchRequest(
        items=[
            PgfpPatchItem(ligne_key="unknown_garbage_key", montant_n=Decimal("100")),
        ]
    )
    with pytest.raises(ValidationError) as exc:
        await pgfp_service.patch_pgfp(DOC_ID, COMPANY, payload)
    assert exc.value.code == "unknown_ligne_key"


@pytest.mark.asyncio
async def test_patch_computed_ligne_key_422(patch_run_in_thread, valid_eprd_doc, monkeypatch):
    """Q4 — PATCH refuse les lignes is_computed=True (réservées :recompute)."""
    monkeypatch.setattr(pgfp_service.pgfp_repo, "upsert_by_ligne_key", lambda **kw: None)

    payload = PgfpPatchRequest(
        items=[
            PgfpPatchItem(ligne_key="frng_fin_periode", montant_n=Decimal("100")),
        ]
    )
    with pytest.raises(ValidationError) as exc:
        await pgfp_service.patch_pgfp(DOC_ID, COMPANY, payload)
    assert exc.value.code == "ligne_is_computed"


@pytest.mark.asyncio
async def test_patch_errd_doc_422(patch_run_in_thread, errd_doc):
    payload = PgfpPatchRequest(items=[])
    with pytest.raises(ValidationError) as exc:
        await pgfp_service.patch_pgfp(DOC_ID, COMPANY, payload)
    assert exc.value.code == "pgfp_not_applicable"


# ---------------------------------------------------------------------------
# recompute_pgfp
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_recompute_computes_crp_total_charges(
    patch_run_in_thread, valid_eprd_doc, monkeypatch
):
    """Σ G1+G2+G3 charges → crp_total_charges."""
    persisted = {}

    def _overwrite(*, company_id, document_id, ligne_key, section, ligne_label, montants):
        persisted[ligne_key] = dict(montants)
        return _db_row(ligne_key, section=section)

    monkeypatch.setattr(pgfp_service.pgfp_repo, "overwrite_by_ligne_key", _overwrite)
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "list_by_document",
        lambda d: [
            _db_row(
                "crp_g1_charges",
                section="crp_consolides",
                montant_n=Decimal("100000"),
            ),
            _db_row(
                "crp_g2_charges",
                section="crp_consolides",
                montant_n=Decimal("200000"),
            ),
            _db_row(
                "crp_g3_charges",
                section="crp_consolides",
                montant_n=Decimal("50000"),
            ),
        ],
    )

    await pgfp_service.recompute_pgfp(DOC_ID, COMPANY)

    assert persisted["crp_total_charges"]["montant_n"] == Decimal("350000")


@pytest.mark.asyncio
async def test_recompute_frng_equals_fri_plus_fre(patch_run_in_thread, valid_eprd_doc, monkeypatch):
    """Q6 — FRNG apport/prélèvement = FRI variations + FRE variations."""
    persisted = {}

    def _overwrite(*, company_id, document_id, ligne_key, section, ligne_label, montants):
        persisted[ligne_key] = dict(montants)
        return _db_row(ligne_key, section=section)

    monkeypatch.setattr(pgfp_service.pgfp_repo, "overwrite_by_ligne_key", _overwrite)
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "list_by_document",
        lambda d: [
            _db_row("fri_aug_emprunts_c16", section="fri", montant_n=Decimal("100000")),
            _db_row(
                "fri_dim_remboursements_emprunts_anterieurs",
                section="fri",
                montant_n=Decimal("30000"),
            ),
            _db_row("fre_aug_autres", section="fre", montant_n=Decimal("20000")),
            _db_row("fre_dim_autres", section="fre", montant_n=Decimal("10000")),
        ],
    )

    await pgfp_service.recompute_pgfp(DOC_ID, COMPANY)

    # FRI variations = 100k - 30k = 70k
    assert persisted["fri_variations"]["montant_n"] == Decimal("70000")
    # FRE variations = 20k - 10k = 10k
    assert persisted["fre_variations"]["montant_n"] == Decimal("10000")
    # FRNG apport = 70k + 10k = 80k
    assert persisted["frng_apport_prelevement"]["montant_n"] == Decimal("80000")


@pytest.mark.asyncio
async def test_recompute_tresorerie_equals_frng_minus_bfr(
    patch_run_in_thread, valid_eprd_doc, monkeypatch
):
    """Bloc 7 — Trésorerie variations = FRNG apport - BFR variations."""
    persisted = {}

    def _overwrite(*, company_id, document_id, ligne_key, section, ligne_label, montants):
        persisted[ligne_key] = dict(montants)
        return _db_row(ligne_key, section=section)

    monkeypatch.setattr(pgfp_service.pgfp_repo, "overwrite_by_ligne_key", _overwrite)
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "list_by_document",
        lambda d: [
            _db_row("fri_aug_emprunts_c16", section="fri", montant_n=Decimal("100000")),
            _db_row("fre_aug_autres", section="fre", montant_n=Decimal("0")),  # FRE neutre
            _db_row("bfr_aug_stocks", section="bfr", montant_n=Decimal("30000")),
            _db_row("bfr_dim_stocks", section="bfr", montant_n=Decimal("10000")),
        ],
    )

    await pgfp_service.recompute_pgfp(DOC_ID, COMPANY)

    # FRNG = 100k + 0 = 100k
    # BFR variations = 30k - 10k = 20k
    # Trésorerie variations = 100k - 20k = 80k
    assert persisted["tresorerie_variations"]["montant_n"] == Decimal("80000")


@pytest.mark.asyncio
async def test_recompute_emits_warning_on_missing_upstream(
    patch_run_in_thread, valid_eprd_doc, monkeypatch
):
    """Q7 — pas de hard fail, warning émis pour les saisies manquantes."""
    monkeypatch.setattr(pgfp_service.pgfp_repo, "overwrite_by_ligne_key", lambda **kw: _db_row("x"))
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "list_by_document",
        lambda d: [],  # tout vide
    )

    result = await pgfp_service.recompute_pgfp(DOC_ID, COMPANY)

    # Au minimum le warning "bloc_8_10_deferred" + au moins 1
    # "upstream_line_not_saisie" pour les saisies manquantes
    codes = [w.code for w in result.warnings]
    assert "bloc_8_10_deferred" in codes
    assert "upstream_line_not_saisie" in codes


@pytest.mark.asyncio
async def test_recompute_empty_db_doesnt_raise(patch_run_in_thread, valid_eprd_doc, monkeypatch):
    """Q7 — DB totalement vide ne plante pas."""
    monkeypatch.setattr(pgfp_service.pgfp_repo, "overwrite_by_ligne_key", lambda **kw: _db_row("x"))
    monkeypatch.setattr(pgfp_service.pgfp_repo, "list_by_document", lambda d: [])

    result = await pgfp_service.recompute_pgfp(DOC_ID, COMPANY)
    assert len(result.items) == len(PGFP_LINES_TEMPLATE)


@pytest.mark.asyncio
async def test_recompute_errd_doc_422(patch_run_in_thread, errd_doc):
    """Q8 — recompute aussi gardé par EPRD-only."""
    with pytest.raises(ValidationError) as exc:
        await pgfp_service.recompute_pgfp(DOC_ID, COMPANY)
    assert exc.value.code == "pgfp_not_applicable"


@pytest.mark.asyncio
async def test_recompute_dm_doc_passes_q8(patch_run_in_thread, monkeypatch):
    """D-088 — DM hérite et révise le PGFP, doit passer."""
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "get_doc_type_document",
        lambda doc, company: {"type_document": "dm"},
    )
    monkeypatch.setattr(pgfp_service.pgfp_repo, "overwrite_by_ligne_key", lambda **kw: _db_row("x"))
    monkeypatch.setattr(pgfp_service.pgfp_repo, "list_by_document", lambda d: [])

    result = await pgfp_service.recompute_pgfp(DOC_ID, COMPANY)
    assert len(result.items) == len(PGFP_LINES_TEMPLATE)


@pytest.mark.asyncio
async def test_recompute_ria_doc_passes_q8(patch_run_in_thread, monkeypatch):
    """RIA hérite aussi le PGFP."""
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        pgfp_service.pgfp_repo,
        "get_doc_type_document",
        lambda doc, company: {"type_document": "ria"},
    )
    monkeypatch.setattr(pgfp_service.pgfp_repo, "overwrite_by_ligne_key", lambda **kw: _db_row("x"))
    monkeypatch.setattr(pgfp_service.pgfp_repo, "list_by_document", lambda d: [])

    result = await pgfp_service.recompute_pgfp(DOC_ID, COMPANY)
    assert len(result.items) == len(PGFP_LINES_TEMPLATE)
