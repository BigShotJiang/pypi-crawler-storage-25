"""Integration tests for plugin migrations 001 → 004.

These tests spin up a temporary PostgreSQL container via Docker, apply
the plugin migrations in order, then assert on the resulting schema
(table count, RLS policies, triggers, idempotence of a 2nd run, trigger
weight enforcement).

**Skipped automatically** if Docker is not available — these tests are
opt-in via the ``integration`` pytest marker and meant for CI / manual
verification, not the default unit test suite.

Run explicitly with:
    pytest -m integration tests/test_migrations_integration.py -v
"""

from __future__ import annotations

import shutil
import subprocess
import time
import uuid
from pathlib import Path

import psycopg2
import pytest

pytestmark = pytest.mark.integration

MIGRATIONS_DIR = Path(__file__).parent.parent / "piilot_pack_compta_esms" / "migrations"
PG_IMAGE = "postgres:16-alpine"


def _docker_available() -> bool:
    return shutil.which("docker") is not None


@pytest.fixture(scope="module")
def pg_container():
    """Spin a temporary PostgreSQL container, return a psycopg2 connection.

    Container is auto-removed after the module's tests complete.
    """
    if not _docker_available():
        pytest.skip("Docker not available — skipping integration tests")

    container_name = f"compta_esms_test_{uuid.uuid4().hex[:8]}"
    port = 55432

    subprocess.run(
        [
            "docker",
            "run",
            "--rm",
            "-d",
            "--name",
            container_name,
            "-e",
            "POSTGRES_PASSWORD=test",
            "-e",
            "POSTGRES_DB=test",
            "-p",
            f"{port}:5432",
            PG_IMAGE,
        ],
        check=True,
        capture_output=True,
    )

    # Wait for PG ready inside the container
    for _ in range(20):
        ready = subprocess.run(
            ["docker", "exec", container_name, "pg_isready", "-U", "postgres"],
            capture_output=True,
        )
        if ready.returncode == 0:
            break
        time.sleep(0.5)
    else:
        subprocess.run(["docker", "rm", "-f", container_name], capture_output=True)
        pytest.fail("PG container failed to become ready in 10s")

    # Wait for the host port mapping to actually accept TCP connections
    # (pg_isready inside the container can return OK before Docker finishes
    # propagating the publish→host mapping). Retry psycopg2.connect a few times.
    conn = None
    last_err = None
    for _ in range(20):
        try:
            conn = psycopg2.connect(
                host="127.0.0.1",
                port=port,
                user="postgres",
                password="test",
                database="test",
                connect_timeout=2,
            )
            break
        except psycopg2.OperationalError as e:
            last_err = e
            time.sleep(0.5)
    if conn is None:
        subprocess.run(["docker", "rm", "-f", container_name], capture_output=True)
        pytest.fail(f"psycopg2.connect failed after 10s: {last_err}")
    yield conn
    conn.close()
    subprocess.run(["docker", "rm", "-f", container_name], capture_output=True)


def _apply_sql_file(conn, path: Path) -> None:
    sql = path.read_text(encoding="utf-8")
    with conn.cursor() as cur:
        cur.execute(sql)
    conn.commit()


@pytest.fixture(scope="module")
def applied_schema(pg_container):
    """Apply migrations 001 → 005 in order and return the connection."""
    _apply_sql_file(pg_container, MIGRATIONS_DIR / "001_init.sql")
    _apply_sql_file(pg_container, MIGRATIONS_DIR / "002_compta_esms_core.sql")
    _apply_sql_file(pg_container, MIGRATIONS_DIR / "003_seed_feature_catalog.sql")
    _apply_sql_file(pg_container, MIGRATIONS_DIR / "004_seed_controls_catalog.sql")
    _apply_sql_file(pg_container, MIGRATIONS_DIR / "005_llm_suggestion_cache.sql")
    _apply_sql_file(pg_container, MIGRATIONS_DIR / "006_balance_import_columns.sql")
    _apply_sql_file(pg_container, MIGRATIONS_DIR / "007_balance_import_suggestions.sql")
    _apply_sql_file(pg_container, MIGRATIONS_DIR / "008_balance_import_apply.sql")
    return pg_container


@pytest.fixture(scope="module")
def app_conn(pg_container, applied_schema):
    """Return a psycopg2 connection as a non-superuser app role.

    RLS policies are ignored by SUPERUSER (and table owners, even with FORCE).
    The host backend connects with a normal app role — we mimic that here so
    RLS tests are meaningful.
    """
    # Create the app role and grant minimal privileges
    with pg_container.cursor() as cur:
        cur.execute(
            "DO $$ BEGIN "
            "  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='compta_esms_app') THEN "
            "    CREATE ROLE compta_esms_app LOGIN PASSWORD 'test';"
            "  END IF;"
            "END $$;"
        )
        cur.execute("GRANT USAGE ON SCHEMA compta_esms TO compta_esms_app;")
        cur.execute(
            "GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA compta_esms "
            "TO compta_esms_app;"
        )
        cur.execute(
            "ALTER DEFAULT PRIVILEGES IN SCHEMA compta_esms "
            "GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO compta_esms_app;"
        )
    pg_container.commit()

    # Connect as the app role
    conn = psycopg2.connect(
        host="127.0.0.1",
        port=55432,
        user="compta_esms_app",
        password="test",
        database="test",
    )
    yield conn
    conn.close()


# ---------------------------------------------------------------------------
# Schema shape
# ---------------------------------------------------------------------------


def test_27_tables_created(applied_schema):
    """28 base tables under compta_esms.* after migrations 002 + 005.

    Originally 27 (migration 002 — core). Migration 005 adds 1 more
    (``llm_suggestion_cache`` — cross-tenant LLM suggestion memoizer
    for §F.4)."""
    with applied_schema.cursor() as cur:
        cur.execute(
            "SELECT count(*) FROM information_schema.tables "
            "WHERE table_schema='compta_esms' AND table_type='BASE TABLE';"
        )
        (count,) = cur.fetchone()
    assert count == 28, f"expected 28 base tables, got {count}"


def test_balance_imports_006_columns(applied_schema):
    """Migration 006 adds column_detection + preview_data to balance_imports."""
    with applied_schema.cursor() as cur:
        cur.execute(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_schema='compta_esms' "
            "AND table_name='balance_imports' "
            "AND column_name IN ('column_detection', 'preview_data');"
        )
        names = {row[0] for row in cur.fetchall()}
    assert names == {"column_detection", "preview_data"}


def test_balance_imports_008_columns(applied_schema):
    """Migration 008 adds unmapped_accounts JSONB + applied_at TIMESTAMPTZ."""
    with applied_schema.cursor() as cur:
        cur.execute(
            "SELECT column_name, data_type FROM information_schema.columns "
            "WHERE table_schema='compta_esms' "
            "AND table_name='balance_imports' "
            "AND column_name IN ('unmapped_accounts', 'applied_at');"
        )
        by_name = {row[0]: row[1] for row in cur.fetchall()}
    assert by_name.get("unmapped_accounts") == "jsonb"
    # PostgreSQL renders TIMESTAMPTZ as "timestamp with time zone"
    assert by_name.get("applied_at") == "timestamp with time zone"


def test_balance_imports_007_suggestions(applied_schema):
    """Migration 007 adds suggestions JSONB to balance_imports."""
    with applied_schema.cursor() as cur:
        cur.execute(
            "SELECT column_name, data_type, column_default "
            "FROM information_schema.columns "
            "WHERE table_schema='compta_esms' "
            "AND table_name='balance_imports' "
            "AND column_name='suggestions';"
        )
        row = cur.fetchone()
    assert row is not None
    assert row[1] == "jsonb"
    # Default must be an empty array — drives the §F.4 contract.
    assert row[2] is not None and "[]" in row[2]


def test_llm_suggestion_cache_table(applied_schema):
    """Migration 005 — table + 2 indexes, no RLS (cross-tenant by design)."""
    with applied_schema.cursor() as cur:
        cur.execute(
            "SELECT count(*) FROM information_schema.tables "
            "WHERE table_schema='compta_esms' "
            "AND table_name='llm_suggestion_cache';"
        )
        (table_count,) = cur.fetchone()
        cur.execute(
            "SELECT count(*) FROM pg_indexes "
            "WHERE schemaname='compta_esms' "
            "AND tablename='llm_suggestion_cache' "
            "AND indexname LIKE 'idx_llm_cache_%';"
        )
        (index_count,) = cur.fetchone()
        cur.execute(
            "SELECT count(*) FROM pg_policies "
            "WHERE schemaname='compta_esms' "
            "AND tablename='llm_suggestion_cache';"
        )
        (policy_count,) = cur.fetchone()
    assert table_count == 1
    assert index_count == 2  # lookup + cached_at
    assert policy_count == 0  # cross-tenant, no RLS


def test_rls_enabled_on_all_tables_except_feature_catalog(applied_schema):
    """26 tables have a company_isolation policy. feature_catalog has none."""
    with applied_schema.cursor() as cur:
        cur.execute(
            "SELECT count(*) FROM pg_policies "
            "WHERE schemaname='compta_esms' AND policyname LIKE '%company_isolation';"
        )
        (count,) = cur.fetchone()
    assert count == 26, f"expected 26 RLS policies, got {count}"

    with applied_schema.cursor() as cur:
        cur.execute(
            "SELECT count(*) FROM pg_policies "
            "WHERE schemaname='compta_esms' AND tablename='feature_catalog';"
        )
        (count,) = cur.fetchone()
    assert count == 0, "feature_catalog must not have RLS (global catalogue)"


def test_updated_at_triggers(applied_schema):
    """Each table with an updated_at column has a tg_<t>_updated_at trigger."""
    with applied_schema.cursor() as cur:
        cur.execute(
            "SELECT count(*) FROM information_schema.triggers "
            "WHERE event_object_schema='compta_esms' "
            "AND trigger_name LIKE 'tg_%_updated_at';"
        )
        (count,) = cur.fetchone()
    # 18 tables with updated_at (every table except exercices, suivi_affectations,
    # ratios_calcules, controles_resultats, feature_catalog, recueil_consentement_rgpd,
    # audit_events, forfait_parametres which only have created_at).
    # Each table emits 1 BEFORE UPDATE trigger.
    assert count >= 17, f"expected >=17 updated_at triggers, got {count}"


def test_balance_weight_trigger_present(applied_schema):
    """The integrity trigger on balance_mappings is registered."""
    with applied_schema.cursor() as cur:
        cur.execute(
            "SELECT trigger_name FROM information_schema.triggers "
            "WHERE event_object_schema='compta_esms' "
            "AND event_object_table='balance_mappings';"
        )
        names = {row[0] for row in cur.fetchall()}
    assert "tg_balance_mapping_weights_check" in names


# ---------------------------------------------------------------------------
# Idempotence
# ---------------------------------------------------------------------------


def test_002_idempotent(applied_schema):
    """Re-applying 002_compta_esms_core.sql produces no error and no diff."""
    with applied_schema.cursor() as cur:
        cur.execute(
            "SELECT count(*) FROM information_schema.tables "
            "WHERE table_schema='compta_esms' AND table_type='BASE TABLE';"
        )
        (before,) = cur.fetchone()

    _apply_sql_file(applied_schema, MIGRATIONS_DIR / "002_compta_esms_core.sql")

    with applied_schema.cursor() as cur:
        cur.execute(
            "SELECT count(*) FROM information_schema.tables "
            "WHERE table_schema='compta_esms' AND table_type='BASE TABLE';"
        )
        (after,) = cur.fetchone()
    assert before == after, f"table count drift on re-apply: {before} → {after}"


def test_003_idempotent(applied_schema):
    """Re-applying 003_seed_feature_catalog.sql doesn't duplicate features."""
    with applied_schema.cursor() as cur:
        cur.execute("SELECT count(*) FROM compta_esms.feature_catalog;")
        (before,) = cur.fetchone()

    _apply_sql_file(applied_schema, MIGRATIONS_DIR / "003_seed_feature_catalog.sql")

    with applied_schema.cursor() as cur:
        cur.execute("SELECT count(*) FROM compta_esms.feature_catalog;")
        (after,) = cur.fetchone()
    assert before == after, f"feature_catalog row count drift: {before} → {after}"


# ---------------------------------------------------------------------------
# Seed feature_catalog
# ---------------------------------------------------------------------------


def test_feature_catalog_has_16_features(applied_schema):
    """Seed 003 inserts exactly 16 features."""
    with applied_schema.cursor() as cur:
        cur.execute("SELECT count(*) FROM compta_esms.feature_catalog;")
        (count,) = cur.fetchone()
    assert count == 16, f"expected 16 features, got {count}"


def test_feature_catalog_required_keys(applied_schema):
    """The mandatory feature_keys must be present."""
    expected = {
        "crp_charges_g1",
        "crp_charges_g2",
        "crp_charges_g3",
        "crp_produits",
        "tper_effectifs",
        "ter_effectifs",
        "annexe4_activite",
        "annexe5_forfait",
        "bilan_actif",
        "bilan_passif",
        "tf_ressources",
        "tf_emplois",
        "provisions_mouvements",
        "emprunts_principal",
        "rcc_repartition",
        "pgfp_lignes",
    }
    with applied_schema.cursor() as cur:
        cur.execute("SELECT feature_key FROM compta_esms.feature_catalog;")
        keys = {row[0] for row in cur.fetchall()}
    assert (
        keys == expected
    ), f"feature keys diff: missing={expected - keys}, extra={keys - expected}"


def test_feature_catalog_targets_m22bis_only(applied_schema):
    """All features have plan_comptable_cible = M22Bis (D-106 + D-107)."""
    with applied_schema.cursor() as cur:
        cur.execute(
            "SELECT count(*) FROM compta_esms.feature_catalog "
            "WHERE plan_comptable_cible != 'M22Bis';"
        )
        (count,) = cur.fetchone()
    assert count == 0


# ---------------------------------------------------------------------------
# Trigger Σ weight ≤ 1.0 on balance_mappings
# ---------------------------------------------------------------------------


def test_balance_weight_accepts_1to1(applied_schema):
    """A single mapping with weight=1.0 is accepted."""
    # Disable RLS for tests (no app.current_company_id set)
    with applied_schema.cursor() as cur:
        cur.execute("ALTER TABLE compta_esms.balance_mappings DISABLE ROW LEVEL SECURITY;")
        cur.execute("TRUNCATE compta_esms.balance_mappings;")
        cur.execute(
            "INSERT INTO compta_esms.balance_mappings "
            "(company_id, source_plan, source_account, target_m22bis_account, weight) "
            "VALUES (%s, 'PCG', '601000', '60611', 1.0);",
            (str(uuid.uuid4()),),
        )
    applied_schema.commit()


def test_balance_weight_accepts_fractional_split(applied_schema):
    """1:N split with Σ weight = 1.0 is accepted."""
    company_id = str(uuid.uuid4())
    with applied_schema.cursor() as cur:
        cur.execute("TRUNCATE compta_esms.balance_mappings;")
        cur.execute(
            "INSERT INTO compta_esms.balance_mappings "
            "(company_id, source_plan, source_account, target_m22bis_account, weight) "
            "VALUES (%s, 'PCG', '602000', '60621', 0.6),"
            "       (%s, 'PCG', '602000', '60622', 0.4);",
            (company_id, company_id),
        )
    applied_schema.commit()


def test_balance_weight_rejects_overflow(applied_schema):
    """An insert that pushes Σ weight > 1.0 raises an error."""
    company_id = str(uuid.uuid4())
    with applied_schema.cursor() as cur:
        cur.execute("TRUNCATE compta_esms.balance_mappings;")
        cur.execute(
            "INSERT INTO compta_esms.balance_mappings "
            "(company_id, source_plan, source_account, target_m22bis_account, weight) "
            "VALUES (%s, 'PCG', '602000', '60621', 0.4),"
            "       (%s, 'PCG', '602000', '60622', 0.4);",
            (company_id, company_id),
        )
    applied_schema.commit()

    # Now try to push it to 1.2
    with pytest.raises(psycopg2.errors.RaiseException) as exc:
        with applied_schema.cursor() as cur:
            cur.execute(
                "INSERT INTO compta_esms.balance_mappings "
                "(company_id, source_plan, source_account, target_m22bis_account, weight) "
                "VALUES (%s, 'PCG', '602000', '60623', 0.5);",
                (company_id,),
            )
        applied_schema.commit()
    assert "exceeds 1.0" in str(exc.value)
    applied_schema.rollback()


# ---------------------------------------------------------------------------
# RLS company isolation
# ---------------------------------------------------------------------------


def test_rls_blocks_cross_company_select(applied_schema, app_conn):
    """A non-superuser app role acting as company A cannot see rows of company B."""
    # Seed via superuser (bypasses RLS) so the test focuses on read isolation
    with applied_schema.cursor() as cur:
        cur.execute("TRUNCATE compta_esms.organismes_gestionnaires CASCADE;")
    applied_schema.commit()

    company_a = str(uuid.uuid4())
    company_b = str(uuid.uuid4())

    with applied_schema.cursor() as cur:
        cur.execute(
            "INSERT INTO compta_esms.organismes_gestionnaires "
            "(company_id, finess_juridique, raison_sociale, nature_juridique, plan_comptable) "
            "VALUES (%s, 'FINESS-A', 'OG A', 'PRIVE_NON_LUCRATIF', 'PNL'),"
            "       (%s, 'FINESS-B', 'OG B', 'PRIVE_NON_LUCRATIF', 'PNL');",
            (company_a, company_b),
        )
    applied_schema.commit()

    # Read as app role under company A → sees only its own row
    with app_conn.cursor() as cur:
        cur.execute(f"SET app.current_company_id = '{company_a}';")
        cur.execute("SELECT count(*) FROM compta_esms.organismes_gestionnaires;")
        (count_a,) = cur.fetchone()
    assert count_a == 1, f"RLS should expose 1 row to company A, got {count_a}"

    # Read as app role under company B → sees only its own row
    with app_conn.cursor() as cur:
        cur.execute(f"SET app.current_company_id = '{company_b}';")
        cur.execute("SELECT count(*) FROM compta_esms.organismes_gestionnaires;")
        (count_b,) = cur.fetchone()
    assert count_b == 1
    app_conn.rollback()


def test_rls_blocks_cross_company_insert(applied_schema, app_conn):
    """A non-superuser app role can't insert a row with company_id ≠ current_setting."""
    with applied_schema.cursor() as cur:
        cur.execute("TRUNCATE compta_esms.organismes_gestionnaires CASCADE;")
    applied_schema.commit()

    company_a = str(uuid.uuid4())
    company_b = str(uuid.uuid4())

    with pytest.raises(psycopg2.Error):
        with app_conn.cursor() as cur:
            cur.execute(f"SET app.current_company_id = '{company_a}';")
            cur.execute(
                "INSERT INTO compta_esms.organismes_gestionnaires "
                "(company_id, finess_juridique, raison_sociale, nature_juridique, plan_comptable) "
                "VALUES (%s, 'FINESS-B', 'OG B', 'PRIVE_NON_LUCRATIF', 'PNL');",
                (company_b,),
            )
        app_conn.commit()
    app_conn.rollback()
