"""Unit tests for :mod:`piilot_pack_compta_esms.services.bilan_variante`."""

from __future__ import annotations

import pytest

from piilot_pack_compta_esms.services.bilan_variante import (
    UnknownPlanComptableError,
    choose_bilan_comptable_variant,
)


def test_pc_returns_comptable_pc():
    """D-067 — plan_comptable=PC → variante comptable_pc."""
    assert choose_bilan_comptable_variant("PC") == "comptable_pc"


def test_pnl_returns_comptable_pnl():
    """D-067 — plan_comptable=PNL → variante comptable_pnl."""
    assert choose_bilan_comptable_variant("PNL") == "comptable_pnl"


def test_unknown_plan_raises():
    with pytest.raises(UnknownPlanComptableError):
        choose_bilan_comptable_variant("XYZ")
