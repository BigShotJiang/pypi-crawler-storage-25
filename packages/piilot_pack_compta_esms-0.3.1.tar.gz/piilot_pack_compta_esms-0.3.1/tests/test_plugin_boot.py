"""Smoke tests that prove the plugin boots correctly.

These are the minimal tests every plugin should ship. They prove:

1. The plugin package imports without error.
2. The manifest loaded from ``pyproject.toml`` is valid against the
   Piilot SDK JSON Schema (namespace, sdk_compat, supported_modes, ...).
3. The ``Plugin.register(ctx)`` call wires migrations + locales + the
   module seeds without raising.
4. The seeds module declares exactly the same modules as the manifest
   (no drift between manifest and seeds).

v0.2 = 8 modules. v0.3 §BA adds ``compta_esms.cpom`` → 9 modules total.
"""

from __future__ import annotations

import importlib

_EXPECTED_SLUGS = [
    "compta_esms.dashboard",
    "compta_esms.documents",
    "compta_esms.sources",
    "compta_esms.etablissements",
    "compta_esms.effectifs",
    "compta_esms.activite",
    "compta_esms.annexes_financieres",
    "compta_esms.eps_sanitaire",
    "compta_esms.cpom",
]


def test_plugin_package_imports():
    """The plugin package is importable — basic syntactic smoke."""
    pkg = importlib.import_module("piilot_pack_compta_esms")
    assert hasattr(pkg, "Plugin"), "The plugin package must expose a 'Plugin' class"


def test_manifest_valid():
    """The pyproject.toml manifest passes the SDK schema."""
    pkg = importlib.import_module("piilot_pack_compta_esms")
    m = pkg.Plugin.manifest
    assert m["manifest_version"] == 1
    assert m["namespace"] == "compta_esms"
    assert "supported_modes" in m and m["supported_modes"]
    assert m["sdk_compat"] == ">=0.8.0,<1.0.0"


def test_manifest_declares_all_modules():
    """The manifest must list exactly the expected métier modules."""
    pkg = importlib.import_module("piilot_pack_compta_esms")
    modules = pkg.Plugin.manifest["provides"]["modules"]
    assert len(modules) == len(_EXPECTED_SLUGS)
    ids = sorted(m["id"] for m in modules)
    assert ids == sorted(_EXPECTED_SLUGS)


def test_seeds_declare_same_modules():
    """The seeds module must declare exactly the same modules as the
    manifest.

    Guards against drift between the manifest (loader-side contract)
    and the seeds (which actually upsert ``modules.modules`` rows).
    """
    from piilot_pack_compta_esms.seeds import _MODULES

    assert len(_MODULES) == len(_EXPECTED_SLUGS)
    slugs = sorted(spec["slug"] for spec in _MODULES)
    assert slugs == sorted(_EXPECTED_SLUGS)
    # Each seed has a name, description, icon and draft status (v0.2).
    for spec in _MODULES:
        assert spec["module_name"]
        assert spec["description"]
        assert spec["icon"]
        assert spec["status"] == "published"


def test_plugin_register_wires_without_raising(fake_ctx, plugin_context):
    """Plugin.register() runs to completion against a fake Context.

    The plugin_context fixture sets ``current_plugin`` so that SDK
    primitives (register_module, ...) called from ``register()`` can
    resolve the plugin's namespace.
    """
    pkg = importlib.import_module("piilot_pack_compta_esms")
    plugin = pkg.Plugin()
    with plugin_context("compta_esms"):
        plugin.register(fake_ctx)  # must not raise
