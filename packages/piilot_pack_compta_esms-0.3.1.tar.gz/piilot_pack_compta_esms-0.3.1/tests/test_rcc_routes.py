"""Route tests for RCC endpoints (L2 §16.5-§16.7, 3 endpoints)."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.rcc import (
    RccLigneRead,
    RccLigneValidation,
    RccResponse,
    RccValidateResponse,
)
from piilot_pack_compta_esms.routes import rcc as rcc_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import rcc_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
RCC_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)


def _ligne_read(**overrides) -> RccLigneRead:
    base = {
        "id": RCC_ID,
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "compte_m22bis": "611",
        "libelle": "Loyers",
        "montant_total": Decimal("10000"),
        "cle_repartition": "Surface",
        "repartition": {},
        "is_frais_siege": False,
        "is_quote_part_commune": False,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return RccLigneRead.model_validate(base)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(rcc_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# §16.5 GET /rcc
# ---------------------------------------------------------------------------


def test_get_rcc_200(client, monkeypatch):
    async def _fake(doc, company):
        return RccResponse(items=[_ligne_read()])

    monkeypatch.setattr(rcc_service, "list_rcc", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/rcc")
    assert r.status_code == 200
    assert len(r.json()["items"]) == 1


def test_get_rcc_404(client, monkeypatch):
    async def _fake(doc, company):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(rcc_service, "list_rcc", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/rcc")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §16.6 POST :bulk-upsert
# ---------------------------------------------------------------------------


def test_bulk_upsert_rcc_200(client, monkeypatch):
    async def _fake(doc, company, payload):
        return RccResponse(items=[_ligne_read()])

    monkeypatch.setattr(rcc_service, "bulk_upsert_rcc", _fake)
    cr_id = str(uuid4())
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/rcc:bulk-upsert",
        json={
            "items": [
                {
                    "compte_m22bis": "611",
                    "libelle": "Loyers",
                    "montant_total": "10000",
                    "cle_repartition": "Surface",
                    "repartition": {
                        cr_id: {"pct": "100", "montant": "10000"},
                    },
                }
            ]
        },
    )
    assert r.status_code == 200


def test_bulk_upsert_rcc_403_user_role(client):
    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/rcc:bulk-upsert",
        json={"items": []},
    )
    assert r.status_code == 403


def test_bulk_upsert_pct_out_of_range_422(client):
    """pct ∈ [0, 100] — 150 rejeté Pydantic."""
    cr_id = str(uuid4())
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/rcc:bulk-upsert",
        json={
            "items": [
                {
                    "compte_m22bis": "611",
                    "repartition": {cr_id: {"pct": "150", "montant": "0"}},
                }
            ]
        },
    )
    assert r.status_code == 422


# ---------------------------------------------------------------------------
# §16.7 POST :validate (D-092 Σ%=100)
# ---------------------------------------------------------------------------


def test_validate_200_all_valid(client, monkeypatch):
    async def _fake(doc, company):
        return RccValidateResponse(
            lignes=[
                RccLigneValidation(
                    rcc_ligne_id=RCC_ID,
                    compte_m22bis="611",
                    somme_pct=Decimal("100"),
                    ecart=Decimal("0"),
                    valide=True,
                ),
            ],
            valide_globalement=True,
            tolerance_appliquee=Decimal("0.01"),
        )

    monkeypatch.setattr(rcc_service, "validate_rcc", _fake)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/rcc:validate")
    assert r.status_code == 200
    body = r.json()
    assert body["valide_globalement"] is True
    assert len(body["lignes"]) == 1
    assert body["lignes"][0]["valide"] is True


def test_validate_200_with_ecart(client, monkeypatch):
    async def _fake(doc, company):
        return RccValidateResponse(
            lignes=[
                RccLigneValidation(
                    rcc_ligne_id=RCC_ID,
                    compte_m22bis="611",
                    somme_pct=Decimal("95"),
                    ecart=Decimal("-5"),
                    valide=False,
                ),
            ],
            valide_globalement=False,
            tolerance_appliquee=Decimal("0.01"),
        )

    monkeypatch.setattr(rcc_service, "validate_rcc", _fake)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/rcc:validate")
    assert r.status_code == 200
    body = r.json()
    assert body["valide_globalement"] is False
    assert body["lignes"][0]["ecart"] == "-5"


def test_validate_404(client, monkeypatch):
    async def _fake(doc, company):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(rcc_service, "validate_rcc", _fake)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/rcc:validate")
    assert r.status_code == 404
