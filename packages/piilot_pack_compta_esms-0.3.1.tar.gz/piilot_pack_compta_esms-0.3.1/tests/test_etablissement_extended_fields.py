"""Tests §BE — Champs ETS étendus v0.3 (D-030).

Couvre :
- Pydantic Literal allowed values (OuiNon, OptionTarifaire,
  GmpValidationMode)
- Field bounds (Decimal ≥ 0 sur valeurs numériques)
- Compat rétro : tous Optional → un Create sans aucun nouveau champ
  reste valide
- Repo column allowlist mis à jour
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from uuid import uuid4

import pytest
from pydantic import ValidationError

from piilot_pack_compta_esms.models.etablissement import (
    EtablissementCreate,
    EtablissementUpdate,
)
from piilot_pack_compta_esms.repositories import etablissement_repo

_BASE_CREATE_KWARGS: dict = {
    "og_id": uuid4(),
    "finess_ets": "123456789",
    "raison_sociale": "EHPAD Les Lilas",
    "typologie": "EHPAD",
}


# ---------------------------------------------------------------------------
# Rétro-compat : tous nouveaux champs Optional
# ---------------------------------------------------------------------------


def test_create_without_extended_fields_is_valid():
    """Les ETS v0.2 (sans aucun champ étendu) doivent rester valides."""
    obj = EtablissementCreate(**_BASE_CREATE_KWARGS)
    assert obj.eligible_aide_sociale is None
    assert obj.option_tarifaire is None
    assert obj.gmp_valeur is None
    assert obj.prix_journee_moyen is None


# ---------------------------------------------------------------------------
# Literal allowed values
# ---------------------------------------------------------------------------


def test_eligible_aide_sociale_accepts_oui_non():
    for value in ("OUI", "NON"):
        obj = EtablissementCreate(**_BASE_CREATE_KWARGS, eligible_aide_sociale=value)
        assert obj.eligible_aide_sociale == value


def test_eligible_aide_sociale_rejects_other_value():
    with pytest.raises(ValidationError, match="eligible_aide_sociale"):
        EtablissementCreate(**_BASE_CREATE_KWARGS, eligible_aide_sociale="yes")


def test_option_tarifaire_accepts_3_dgcs_values():
    for value in ("GMPS_DROIT_COMMUN", "FORFAIT_SOINS", "CONVENTION_SSIAD_EXT"):
        obj = EtablissementCreate(**_BASE_CREATE_KWARGS, option_tarifaire=value)
        assert obj.option_tarifaire == value


def test_option_tarifaire_rejects_unknown_value():
    with pytest.raises(ValidationError, match="option_tarifaire"):
        EtablissementCreate(**_BASE_CREATE_KWARGS, option_tarifaire="TARIFICATION_GLOBAL")


def test_gmp_validation_mode_accepts_3_dgcs_values():
    for value in ("MEDECIN_ARS", "MEDECIN_CD", "MEDECIN_COORDONNATEUR_TACITE"):
        obj = EtablissementCreate(**_BASE_CREATE_KWARGS, gmp_validation_mode=value)
        assert obj.gmp_validation_mode == value


def test_gmp_validation_mode_rejects_unknown_value():
    with pytest.raises(ValidationError, match="gmp_validation_mode"):
        EtablissementCreate(**_BASE_CREATE_KWARGS, gmp_validation_mode="INFIRMIER_REF")


def test_tarification_differenciee_o_n_accepts_oui_non():
    for value in ("OUI", "NON"):
        obj = EtablissementCreate(**_BASE_CREATE_KWARGS, tarification_differenciee_o_n=value)
        assert obj.tarification_differenciee_o_n == value


def test_tarification_differenciee_o_n_rejects_bool():
    """Le contrat est text 'OUI'/'NON', pas bool — un client envoyant `True`
    se prend un 422 (extra='forbid' + Literal strict)."""
    with pytest.raises(ValidationError, match="tarification_differenciee_o_n"):
        EtablissementCreate(**_BASE_CREATE_KWARGS, tarification_differenciee_o_n=True)


# ---------------------------------------------------------------------------
# Field bounds (Decimal ≥ 0)
# ---------------------------------------------------------------------------


def test_gmp_valeur_accepts_positive_decimal():
    obj = EtablissementCreate(**_BASE_CREATE_KWARGS, gmp_valeur=Decimal("720.5432"))
    assert obj.gmp_valeur == Decimal("720.5432")


def test_gmp_valeur_rejects_negative():
    with pytest.raises(ValidationError, match="gmp_valeur"):
        EtablissementCreate(**_BASE_CREATE_KWARGS, gmp_valeur=Decimal("-1"))


def test_pmp_valeur_rejects_negative():
    with pytest.raises(ValidationError, match="pmp_valeur"):
        EtablissementCreate(**_BASE_CREATE_KWARGS, pmp_valeur=Decimal("-0.01"))


def test_prix_journee_moyen_rejects_negative():
    with pytest.raises(ValidationError, match="prix_journee_moyen"):
        EtablissementCreate(**_BASE_CREATE_KWARGS, prix_journee_moyen=Decimal("-5"))


def test_nb_chambres_individuelles_rejects_negative():
    with pytest.raises(ValidationError, match="nb_chambres_individuelles"):
        EtablissementCreate(**_BASE_CREATE_KWARGS, nb_chambres_individuelles=-3)


def test_nb_chambres_doubles_zero_is_valid():
    """Une ETS sans chambre double doit pouvoir saisir 0 (pas NULL)."""
    obj = EtablissementCreate(**_BASE_CREATE_KWARGS, nb_chambres_doubles=0)
    assert obj.nb_chambres_doubles == 0


# ---------------------------------------------------------------------------
# Dates
# ---------------------------------------------------------------------------


def test_gmp_pmp_dates_accept_python_date():
    obj = EtablissementCreate(
        **_BASE_CREATE_KWARGS,
        gmp_date_validation=date(2025, 6, 30),
        pmp_date_validation=date(2025, 6, 30),
    )
    assert obj.gmp_date_validation == date(2025, 6, 30)
    assert obj.pmp_date_validation == date(2025, 6, 30)


# ---------------------------------------------------------------------------
# extra='forbid' — un champ inconnu reste rejeté
# ---------------------------------------------------------------------------


def test_unknown_field_still_rejected():
    with pytest.raises(ValidationError, match="ghost"):
        EtablissementCreate(**_BASE_CREATE_KWARGS, ghost="value")  # type: ignore


# ---------------------------------------------------------------------------
# Update mirrors Base (les 11 nouveaux champs sont updatables)
# ---------------------------------------------------------------------------


def test_update_accepts_all_11_extended_fields_optional():
    obj = EtablissementUpdate(
        eligible_aide_sociale="OUI",
        option_tarifaire="FORFAIT_SOINS",
        gmp_valeur=Decimal("700"),
        gmp_date_validation=date(2025, 1, 1),
        gmp_validation_mode="MEDECIN_ARS",
        pmp_valeur=Decimal("180"),
        pmp_date_validation=date(2025, 1, 1),
        prix_journee_moyen=Decimal("87.50"),
        tarification_differenciee_o_n="NON",
        nb_chambres_individuelles=42,
        nb_chambres_doubles=8,
    )
    assert obj.eligible_aide_sociale == "OUI"
    assert obj.option_tarifaire == "FORFAIT_SOINS"
    assert obj.gmp_valeur == Decimal("700")
    assert obj.gmp_validation_mode == "MEDECIN_ARS"
    assert obj.prix_journee_moyen == Decimal("87.50")


def test_update_with_empty_payload_is_valid():
    """PATCH sans aucun champ reste légal (no-op côté repo)."""
    obj = EtablissementUpdate()
    assert obj.eligible_aide_sociale is None


# ---------------------------------------------------------------------------
# Repo column allowlist
# ---------------------------------------------------------------------------


def test_repo_columns_include_all_11_extended_fields():
    """Le repo doit lister les 11 nouvelles colonnes pour qu'INSERT /
    UPDATE les forwarde au DDL."""
    expected = {
        "eligible_aide_sociale",
        "option_tarifaire",
        "gmp_valeur",
        "gmp_date_validation",
        "gmp_validation_mode",
        "pmp_valeur",
        "pmp_date_validation",
        "prix_journee_moyen",
        "tarification_differenciee_o_n",
        "nb_chambres_individuelles",
        "nb_chambres_doubles",
    }
    assert expected.issubset(set(etablissement_repo._COLUMNS))


def test_repo_extended_fields_are_updatable():
    """Les 11 nouveaux champs doivent être dans _UPDATABLE (PATCH OK)."""
    expected = {
        "eligible_aide_sociale",
        "option_tarifaire",
        "gmp_valeur",
        "gmp_date_validation",
        "gmp_validation_mode",
        "pmp_valeur",
        "pmp_date_validation",
        "prix_journee_moyen",
        "tarification_differenciee_o_n",
        "nb_chambres_individuelles",
        "nb_chambres_doubles",
    }
    assert expected.issubset(set(etablissement_repo._UPDATABLE))
