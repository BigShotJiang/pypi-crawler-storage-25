"""Route tests for provisions endpoints (L2 §16.1-§16.2, 2 endpoints)."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.provisions import (
    ProvisionLigneRead,
    ProvisionsMontants,
    ProvisionsResponse,
    ProvisionsTotals,
)
from piilot_pack_compta_esms.routes import provisions as provisions_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import provisions_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)


def _ligne_read(**overrides) -> ProvisionLigneRead:
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "categorie": "provisions_reglementees",
        "cr_id": None,
        "compte_imputation": "14",
        "objet": "P",
        "montant_debut_n": Decimal("1000"),
        "dotations": Decimal("500"),
        "reprises": Decimal("200"),
        "montant_fin_n": Decimal("1300"),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return ProvisionLigneRead.model_validate(base)


def _totals_zero() -> ProvisionsTotals:
    return ProvisionsTotals(
        by_categorie=[],
        total_general=ProvisionsMontants(
            montant_debut_n=Decimal("0"),
            dotations=Decimal("0"),
            reprises=Decimal("0"),
            montant_fin_n=Decimal("0"),
        ),
    )


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(provisions_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# §16.1 GET /provisions
# ---------------------------------------------------------------------------


def test_get_provisions_200(client, monkeypatch):
    async def _fake(doc, company):
        return ProvisionsResponse(items=[_ligne_read()], totals=_totals_zero())

    monkeypatch.setattr(provisions_service, "list_provisions", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/provisions")
    assert r.status_code == 200
    body = r.json()
    assert len(body["items"]) == 1
    assert "totals" in body
    assert body["totals"]["total_general"]["montant_fin_n"] == "0"


def test_get_provisions_404(client, monkeypatch):
    async def _fake(doc, company):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(provisions_service, "list_provisions", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/provisions")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §16.2 POST :bulk-upsert
# ---------------------------------------------------------------------------


def test_bulk_upsert_200(client, monkeypatch):
    async def _fake(doc, company, payload):
        return ProvisionsResponse(items=[_ligne_read()], totals=_totals_zero())

    monkeypatch.setattr(provisions_service, "bulk_upsert_provisions", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/provisions:bulk-upsert",
        json={
            "items": [
                {
                    "categorie": "provisions_reglementees",
                    "compte_imputation": "14",
                    "objet": "Test",
                    "montant_debut_n": "1000.00",
                    "dotations": "100.00",
                    "reprises": "0",
                }
            ]
        },
    )
    assert r.status_code == 200


def test_bulk_upsert_403_user_role(client):
    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/provisions:bulk-upsert",
        json={"items": []},
    )
    assert r.status_code == 403


def test_bulk_upsert_invalid_categorie_422(client):
    """categorie Literal — 'invalid' rejeté."""
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/provisions:bulk-upsert",
        json={
            "items": [
                {
                    "categorie": "invalid",
                    "compte_imputation": "14",
                }
            ]
        },
    )
    assert r.status_code == 422


def test_bulk_upsert_missing_compte_imputation_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/provisions:bulk-upsert",
        json={
            "items": [
                {
                    "categorie": "provisions_reglementees",
                }
            ]
        },
    )
    assert r.status_code == 422
