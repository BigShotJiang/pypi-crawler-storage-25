"""Tests §X D-060 — guards cr_type sur ERCP/EPCP.

Couvre :

* create_cr cr_type='CRPP' sur ERCP → 422 crpp_forbidden_for_ercp_epcp
* create_cr cr_type='CRPP' sur EPCP → 422 crpp_forbidden_for_ercp_epcp
* create_cr cr_type='CRPA' sur ERCP → OK
* create_cr cr_type='CRA_SF' sur ERCP → OK
* create_cr cr_type='CRPP' sur EPRD → OK (régression)
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.cr import CrCreate
from piilot_pack_compta_esms.services import cr_service, document_scope
from piilot_pack_compta_esms.services.errors import ValidationError

COMPANY = uuid4()
DOC_ID = uuid4()
ETS_A = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.cr_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def cr_repo_setup(monkeypatch):
    monkeypatch.setattr(cr_service.cr_repo, "document_exists_for_company", lambda d, c: True)
    monkeypatch.setattr(cr_service.cr_repo, "etablissement_belongs_to_company", lambda e, c: True)
    return monkeypatch


def _row(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "cr_type": "CRPA",
        "cr_variante": "non_soumis_equil",
        "denomination": "CRPA",
        "cr_identifiant": None,
        "etablissement_id": ETS_A,
        "finess_rattachement": None,
        "capacite_installee": None,
        "amplitude_ouverture": None,
        "ventilation": "simple",
        "ordre": 0,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# CRPP refusé sur ERCP/EPCP
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_crpp_on_ercp_422(monkeypatch, patch_run_in_thread, cr_repo_setup):
    """ERCP + CRPP → 422 crpp_forbidden_for_ercp_epcp."""

    async def _ercp(*_args, **_kwargs):
        return "ercp"

    monkeypatch.setattr(document_scope, "get_doc_type", _ercp)

    with pytest.raises(ValidationError) as exc:
        await cr_service.create_cr(
            COMPANY,
            DOC_ID,
            CrCreate(cr_type="CRPP", denomination="CRPP forbidden", etablissement_id=ETS_A),
        )
    assert exc.value.code == "crpp_forbidden_for_ercp_epcp"


@pytest.mark.asyncio
async def test_create_crpp_on_epcp_422(monkeypatch, patch_run_in_thread, cr_repo_setup):
    """EPCP + CRPP → 422 crpp_forbidden_for_ercp_epcp."""

    async def _epcp(*_args, **_kwargs):
        return "epcp"

    monkeypatch.setattr(document_scope, "get_doc_type", _epcp)

    with pytest.raises(ValidationError) as exc:
        await cr_service.create_cr(
            COMPANY,
            DOC_ID,
            CrCreate(cr_type="CRPP", denomination="CRPP forbidden EPCP", etablissement_id=ETS_A),
        )
    assert exc.value.code == "crpp_forbidden_for_ercp_epcp"


# ---------------------------------------------------------------------------
# CRPA + CRA_SF acceptés sur ERCP/EPCP
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_crpa_on_ercp_ok(monkeypatch, patch_run_in_thread, cr_repo_setup):
    """ERCP + CRPA → OK (CRP ANNEXE est précisément ce qui est attendu)."""

    async def _ercp(*_args, **_kwargs):
        return "ercp"

    monkeypatch.setattr(document_scope, "get_doc_type", _ercp)
    monkeypatch.setattr(cr_service.cr_repo, "create", lambda c, d, p: _row(cr_type="CRPA"))

    out = await cr_service.create_cr(
        COMPANY,
        DOC_ID,
        CrCreate(cr_type="CRPA", denomination="CRPA EHPAD 1", etablissement_id=ETS_A),
    )
    assert out.cr_type == "CRPA"


@pytest.mark.asyncio
async def test_create_cra_sf_on_ercp_ok(monkeypatch, patch_run_in_thread, cr_repo_setup):
    """ERCP + CRA_SF → OK (variante Sans FINESS de l'Annexe 11)."""

    async def _ercp(*_args, **_kwargs):
        return "ercp"

    monkeypatch.setattr(document_scope, "get_doc_type", _ercp)
    monkeypatch.setattr(
        cr_service.cr_repo,
        "create",
        lambda c, d, p: _row(cr_type="CRA_SF", etablissement_id=None),
    )

    out = await cr_service.create_cr(
        COMPANY,
        DOC_ID,
        CrCreate(cr_type="CRA_SF", denomination="CRA Sans FINESS"),
    )
    assert out.cr_type == "CRA_SF"


@pytest.mark.asyncio
async def test_create_crpp_on_eprd_still_ok(monkeypatch, patch_run_in_thread, cr_repo_setup):
    """Régression — EPRD + CRPP reste accepté (l'autouse fixture retourne 'eprd')."""
    monkeypatch.setattr(cr_service.cr_repo, "create", lambda c, d, p: _row(cr_type="CRPP"))

    out = await cr_service.create_cr(
        COMPANY,
        DOC_ID,
        CrCreate(cr_type="CRPP", denomination="CRPP standard EPRD", etablissement_id=ETS_A),
    )
    assert out.cr_type == "CRPP"
