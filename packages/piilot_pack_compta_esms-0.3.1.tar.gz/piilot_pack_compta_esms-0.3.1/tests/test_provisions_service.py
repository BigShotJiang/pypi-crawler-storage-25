"""Unit tests for :mod:`piilot_pack_compta_esms.services.provisions_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.provisions import (
    ProvisionLigneCreate,
    ProvisionsBulkUpsertRequest,
)
from piilot_pack_compta_esms.services import provisions_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
DOC_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.provisions_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def valid_doc(monkeypatch):
    monkeypatch.setattr(
        provisions_service.provisions_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )


def _row(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "categorie": "provisions_reglementees",
        "cr_id": None,
        "compte_imputation": "14",
        "objet": "Provision X",
        "montant_debut_n": Decimal("1000.00"),
        "dotations": Decimal("500.00"),
        "reprises": Decimal("200.00"),
        "montant_fin_n": Decimal("1300.00"),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# list_provisions
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_returns_items_and_totals(patch_run_in_thread, valid_doc, monkeypatch):
    monkeypatch.setattr(
        provisions_service.provisions_repo,
        "list_by_document",
        lambda doc: [_row(), _row(categorie="depreciations", compte_imputation="29")],
    )
    monkeypatch.setattr(
        provisions_service.provisions_repo,
        "totals_by_categorie",
        lambda doc: [
            {
                "categorie": "provisions_reglementees",
                "montant_debut_n": Decimal("1000"),
                "dotations": Decimal("500"),
                "reprises": Decimal("200"),
                "montant_fin_n": Decimal("1300"),
            },
            {
                "categorie": "depreciations",
                "montant_debut_n": Decimal("2000"),
                "dotations": Decimal("0"),
                "reprises": Decimal("100"),
                "montant_fin_n": Decimal("1900"),
            },
        ],
    )

    result = await provisions_service.list_provisions(DOC_ID, COMPANY)

    assert len(result.items) == 2
    assert len(result.totals.by_categorie) == 2
    assert result.totals.total_general.montant_debut_n == Decimal("3000")
    assert result.totals.total_general.dotations == Decimal("500")
    assert result.totals.total_general.reprises == Decimal("300")
    assert result.totals.total_general.montant_fin_n == Decimal("3200")


@pytest.mark.asyncio
async def test_list_empty_returns_zero_totals(patch_run_in_thread, valid_doc, monkeypatch):
    monkeypatch.setattr(provisions_service.provisions_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(provisions_service.provisions_repo, "totals_by_categorie", lambda d: [])

    result = await provisions_service.list_provisions(DOC_ID, COMPANY)

    assert result.items == []
    assert result.totals.by_categorie == []
    assert result.totals.total_general.montant_debut_n == Decimal("0")
    assert result.totals.total_general.montant_fin_n == Decimal("0")


@pytest.mark.asyncio
async def test_list_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        provisions_service.provisions_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    with pytest.raises(NotFoundError) as exc:
        await provisions_service.list_provisions(DOC_ID, COMPANY)
    assert exc.value.code == "document_not_found"


# ---------------------------------------------------------------------------
# bulk_upsert_provisions
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_upsert_replace_all(patch_run_in_thread, valid_doc, monkeypatch):
    calls = {}

    def _replace(*, company_id, document_id, items):
        calls["items"] = items
        calls["company_id"] = company_id
        calls["document_id"] = document_id
        return []

    monkeypatch.setattr(provisions_service.provisions_repo, "replace_all_by_document", _replace)
    monkeypatch.setattr(provisions_service.provisions_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(provisions_service.provisions_repo, "totals_by_categorie", lambda d: [])

    payload = ProvisionsBulkUpsertRequest(
        items=[
            ProvisionLigneCreate(
                categorie="provisions_reglementees",
                compte_imputation="14",
                objet="Test",
                montant_debut_n=Decimal("1000"),
                dotations=Decimal("100"),
                reprises=Decimal("50"),
            ),
            ProvisionLigneCreate(
                categorie="subventions_investissement",
                compte_imputation="13",
                montant_debut_n=Decimal("5000"),
            ),
        ]
    )
    await provisions_service.bulk_upsert_provisions(DOC_ID, COMPANY, payload)

    assert len(calls["items"]) == 2
    assert calls["items"][0]["categorie"] == "provisions_reglementees"
    assert calls["items"][1]["categorie"] == "subventions_investissement"
    assert calls["company_id"] == COMPANY
    assert calls["document_id"] == DOC_ID


@pytest.mark.asyncio
async def test_bulk_upsert_empty_items_is_valid(patch_run_in_thread, valid_doc, monkeypatch):
    calls = {}

    def _replace(*, company_id, document_id, items):
        calls["items"] = items
        return []

    monkeypatch.setattr(provisions_service.provisions_repo, "replace_all_by_document", _replace)
    monkeypatch.setattr(provisions_service.provisions_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(provisions_service.provisions_repo, "totals_by_categorie", lambda d: [])

    payload = ProvisionsBulkUpsertRequest(items=[])
    await provisions_service.bulk_upsert_provisions(DOC_ID, COMPANY, payload)
    assert calls["items"] == []


@pytest.mark.asyncio
async def test_bulk_upsert_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        provisions_service.provisions_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    payload = ProvisionsBulkUpsertRequest(items=[])
    with pytest.raises(NotFoundError):
        await provisions_service.bulk_upsert_provisions(DOC_ID, COMPANY, payload)
