"""Route tests for TPER/TER endpoints (L2 §11, 4 endpoints)."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.tper_ter import (
    TperTerLigneRead,
    TperTerPrefillResponse,
    TperTerResponse,
    TperTerTotalsResponse,
)
from piilot_pack_compta_esms.routes import tper_ter as tper_ter_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import tper_ter_prefill, tper_ter_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
ETS_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)


def _ligne_read(**overrides) -> TperTerLigneRead:
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "etablissement_id": ETS_ID,
        "type_tableau": "TPER",
        "type_etablissement": "ehpad_aja",
        "categorie_cnsa": "INFIRMIERS",
        "fonction": "IDE",
        "type_poste": "P",
        "etpr_prevus": Decimal("2.5"),
        "etpt_prevus": Decimal("2.5"),
        "etpr_realises": None,
        "etpt_realises": None,
        "remunerations_prevues": Decimal("100000"),
        "remunerations_realisees": None,
        "section_imputation": "soins",
        "pct_section": Decimal("100"),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return TperTerLigneRead.model_validate(base)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(tper_ter_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# §11.1 GET /tper-ter
# ---------------------------------------------------------------------------


def test_get_no_filters_200(client, monkeypatch):
    async def _fake(doc, company, ets_id=None, type_tableau=None):
        return TperTerResponse(ets_id_filtre=None, type_tableau_filtre=None, items=[_ligne_read()])

    monkeypatch.setattr(tper_ter_service, "list_tper_ter", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter")
    assert r.status_code == 200
    body = r.json()
    assert body["ets_id_filtre"] is None
    assert body["type_tableau_filtre"] is None
    assert len(body["items"]) == 1


def test_get_with_filters_200(client, monkeypatch):
    captured = {}

    async def _fake(doc, company, ets_id=None, type_tableau=None):
        captured["ets_id"] = ets_id
        captured["type_tableau"] = type_tableau
        return TperTerResponse(ets_id_filtre=ets_id, type_tableau_filtre=type_tableau, items=[])

    monkeypatch.setattr(tper_ter_service, "list_tper_ter", _fake)
    r = client.get(
        f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter",
        params={"ets_id": str(ETS_ID), "type_tableau": "TER"},
    )
    assert r.status_code == 200
    assert captured["ets_id"] == ETS_ID
    assert captured["type_tableau"] == "TER"


def test_get_invalid_type_tableau_422(client):
    r = client.get(
        f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter",
        params={"type_tableau": "invalid"},
    )
    assert r.status_code == 422


def test_get_404(client, monkeypatch):
    async def _fake(doc, company, ets_id=None, type_tableau=None):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(tper_ter_service, "list_tper_ter", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §11.2 POST :bulk-upsert
# ---------------------------------------------------------------------------


def test_bulk_upsert_200(client, monkeypatch):
    async def _fake(doc, company, payload):
        return TperTerResponse(
            ets_id_filtre=payload.ets_id,
            type_tableau_filtre=payload.type_tableau,
            items=[_ligne_read()],
        )

    monkeypatch.setattr(tper_ter_service, "bulk_upsert_tper_ter", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "type_tableau": "TPER",
            "items": [
                {
                    "categorie_cnsa": "INFIRMIERS",
                    "fonction": "IDE",
                    "type_poste": "P",
                    "etpr_prevus": "2.5",
                }
            ],
        },
    )
    assert r.status_code == 200


def test_bulk_upsert_missing_ets_id_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter:bulk-upsert",
        json={"type_tableau": "TPER", "items": []},
    )
    assert r.status_code == 422


def test_bulk_upsert_invalid_type_poste_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "type_tableau": "TPER",
            "items": [
                {
                    "categorie_cnsa": "INFIRMIERS",
                    "type_poste": "X",
                }
            ],
        },
    )
    assert r.status_code == 422


def test_bulk_upsert_pct_out_of_range_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "type_tableau": "TPER",
            "items": [
                {
                    "categorie_cnsa": "INFIRMIERS",
                    "type_poste": "P",
                    "pct_section": "150",
                }
            ],
        },
    )
    assert r.status_code == 422


def test_bulk_upsert_404_ets(client, monkeypatch):
    async def _fake(doc, company, payload):
        raise NotFoundError("nope", code="etablissement_not_found")

    monkeypatch.setattr(tper_ter_service, "bulk_upsert_tper_ter", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "type_tableau": "TPER",
            "items": [],
        },
    )
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "etablissement_not_found"


# ---------------------------------------------------------------------------
# §11.3 POST :prefill
# ---------------------------------------------------------------------------


def test_prefill_200(client, monkeypatch):
    async def _fake(*, document_id, company_id, ets_id, type_tableau):
        return TperTerPrefillResponse(inserted=12, updated=0, skipped=3)

    monkeypatch.setattr(tper_ter_prefill, "prefill_from_binding", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter:prefill",
        json={"ets_id": str(ETS_ID), "type_tableau": "TER"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body == {"inserted": 12, "updated": 0, "skipped": 3}


def test_prefill_binding_not_configured_404(client, monkeypatch):
    async def _fake(*, document_id, company_id, ets_id, type_tableau):
        raise NotFoundError("no binding", code="binding_not_configured")

    monkeypatch.setattr(tper_ter_prefill, "prefill_from_binding", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter:prefill",
        json={"ets_id": str(ETS_ID), "type_tableau": "TPER"},
    )
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "binding_not_configured"


def test_prefill_invalid_type_tableau_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter:prefill",
        json={"ets_id": str(ETS_ID), "type_tableau": "INVALID"},
    )
    assert r.status_code == 422


# ---------------------------------------------------------------------------
# §11.4 GET :totals
# ---------------------------------------------------------------------------


def test_get_totals_200(client, monkeypatch):
    async def _fake(doc, company):
        return TperTerTotalsResponse(
            by_categorie=[],
            by_section=[],
            total_etpr_prevus=Decimal("0"),
            total_etpt_prevus=Decimal("0"),
            total_etpr_realises=Decimal("0"),
            total_etpt_realises=Decimal("0"),
            total_remunerations_prevues=Decimal("0"),
            total_remunerations_realisees=Decimal("0"),
        )

    monkeypatch.setattr(tper_ter_service, "compute_totals", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter:totals")
    assert r.status_code == 200
    body = r.json()
    assert "by_categorie" in body
    assert "by_section" in body


def test_get_totals_404(client, monkeypatch):
    async def _fake(doc, company):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(tper_ter_service, "compute_totals", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tper-ter:totals")
    assert r.status_code == 404
