"""Unit tests for :mod:`piilot_pack_compta_esms.services.binding_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.feature_catalog import FeatureCatalogRead
from piilot_pack_compta_esms.models.kb_binding import KbBindingCreate
from piilot_pack_compta_esms.services import binding_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
    ValidationError,
)

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
KB_ID = uuid4()


def _make_feature(**overrides) -> FeatureCatalogRead:
    base = {
        "feature_key": "crp_charges_g1",
        "label": "CRP G1",
        "description": None,
        "columns_required": {"compte": "text", "montant": "numeric"},
        "is_mandatory": True,
        "applicable_typologies": [],
        "applicable_doc_types": ["eprd", "errd"],
        "plan_comptable_cible": "M22Bis",
        "contract_version": 1,
        "ordre": 11,
        "created_at": datetime.now(UTC),
    }
    base.update(overrides)
    return FeatureCatalogRead.model_validate(base)


def _make_kb_meta(**overrides):
    base = {
        "id": KB_ID,
        "name": "balance",
        "table_name": "compta_esms__bal__abc12345",
        "scope": "company",
        "owner_type": "plugin",
        "owner_ref": "compta_esms",
        "columns": [
            {"name": "compte", "column_type": "text", "pg_column": "c_a1"},
            {"name": "montant", "column_type": "numeric", "pg_column": "c_a2"},
        ],
    }
    base.update(overrides)
    return base


def _make_binding_row(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "feature_key": "crp_charges_g1",
        "kb_id": KB_ID,
        "kb_table": "compta_esms__bal__abc12345",
        "column_mapping": {},
        "plan_comptable_source": "M22Bis",
        "bound_by_user_id": USER,
        "bound_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.binding_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def owned_doc(monkeypatch):
    """Default : the document belongs to the caller's company."""
    monkeypatch.setattr(
        binding_service.kb_binding_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )


# ---------------------------------------------------------------------------
# list_bindings
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_bindings_happy(monkeypatch, owned_doc, patch_run_in_thread):
    monkeypatch.setattr(
        binding_service.kb_binding_repo,
        "list_by_document",
        lambda doc: [
            _make_binding_row(feature_key="crp_charges_g1"),
            _make_binding_row(feature_key="crp_produits"),
        ],
    )
    out = await binding_service.list_bindings(DOC_ID, COMPANY)
    assert [b.feature_key for b in out] == ["crp_charges_g1", "crp_produits"]


@pytest.mark.asyncio
async def test_list_bindings_cross_tenant(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        binding_service.kb_binding_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )
    with pytest.raises(NotFoundError) as exc:
        await binding_service.list_bindings(DOC_ID, COMPANY)
    assert exc.value.code == "document_not_found"


# ---------------------------------------------------------------------------
# put_binding
# ---------------------------------------------------------------------------


async def _stub_feature(feature_key):
    return _make_feature(feature_key=feature_key)


@pytest.mark.asyncio
async def test_put_binding_happy(monkeypatch, owned_doc, patch_run_in_thread):
    monkeypatch.setattr(binding_service.feature_catalog_service, "get_feature", _stub_feature)

    async def _fake_meta(kb_id, company_id):
        return _make_kb_meta()

    monkeypatch.setattr(binding_service.kb_discovery, "fetch_kb_meta", _fake_meta)
    captured: dict = {}

    def _fake_upsert(**kwargs):
        captured.update(kwargs)
        return _make_binding_row(
            **{
                "company_id": kwargs["company_id"],
                "document_id": kwargs["document_id"],
                "feature_key": kwargs["feature_key"],
                "kb_id": kwargs["kb_id"],
                "kb_table": kwargs["kb_table"],
                "column_mapping": kwargs["column_mapping"],
                "plan_comptable_source": kwargs["plan_comptable_source"],
                "bound_by_user_id": kwargs["bound_by_user_id"],
            }
        )

    monkeypatch.setattr(binding_service.kb_binding_repo, "upsert", _fake_upsert)

    out = await binding_service.put_binding(
        document_id=DOC_ID,
        feature_key="crp_charges_g1",
        payload=KbBindingCreate(kb_id=KB_ID),
        company_id=COMPANY,
        user_id=USER,
    )
    assert out.kb_id == KB_ID
    assert captured["kb_table"] == "compta_esms__bal__abc12345"


@pytest.mark.asyncio
async def test_put_binding_unknown_feature(monkeypatch, owned_doc, patch_run_in_thread):
    async def _missing(_):
        raise NotFoundError("nope", code="feature_not_found")

    monkeypatch.setattr(binding_service.feature_catalog_service, "get_feature", _missing)
    with pytest.raises(NotFoundError):
        await binding_service.put_binding(
            document_id=DOC_ID,
            feature_key="ghost",
            payload=KbBindingCreate(kb_id=KB_ID),
            company_id=COMPANY,
            user_id=USER,
        )


@pytest.mark.asyncio
async def test_put_binding_kb_inaccessible(monkeypatch, owned_doc, patch_run_in_thread):
    monkeypatch.setattr(binding_service.feature_catalog_service, "get_feature", _stub_feature)

    async def _none(kb, company):
        return None

    monkeypatch.setattr(binding_service.kb_discovery, "fetch_kb_meta", _none)
    with pytest.raises(NotFoundError) as exc:
        await binding_service.put_binding(
            document_id=DOC_ID,
            feature_key="crp_charges_g1",
            payload=KbBindingCreate(kb_id=KB_ID),
            company_id=COMPANY,
            user_id=USER,
        )
    assert exc.value.code == "kb_not_accessible"


@pytest.mark.asyncio
async def test_put_binding_contract_violation(monkeypatch, owned_doc, patch_run_in_thread):
    """KB missing the ``montant`` column required by the contract."""
    monkeypatch.setattr(binding_service.feature_catalog_service, "get_feature", _stub_feature)

    async def _meta_missing(kb, company):
        return _make_kb_meta(
            columns=[{"name": "compte", "column_type": "text", "pg_column": "c_a1"}]
        )

    monkeypatch.setattr(binding_service.kb_discovery, "fetch_kb_meta", _meta_missing)
    with pytest.raises(ValidationError) as exc:
        await binding_service.put_binding(
            document_id=DOC_ID,
            feature_key="crp_charges_g1",
            payload=KbBindingCreate(kb_id=KB_ID),
            company_id=COMPANY,
            user_id=USER,
        )
    assert exc.value.code == "binding_contract_violation"


@pytest.mark.asyncio
async def test_put_binding_accepts_type_mismatch_with_warning(
    monkeypatch, owned_doc, patch_run_in_thread
):
    """Permissive (Q3.b) — numeric column accepted where text is expected."""
    monkeypatch.setattr(binding_service.feature_catalog_service, "get_feature", _stub_feature)

    async def _meta_warn(kb, company):
        return _make_kb_meta(
            columns=[
                {"name": "compte", "column_type": "numeric", "pg_column": "c_a1"},
                {"name": "montant", "column_type": "numeric", "pg_column": "c_a2"},
            ]
        )

    monkeypatch.setattr(binding_service.kb_discovery, "fetch_kb_meta", _meta_warn)
    monkeypatch.setattr(
        binding_service.kb_binding_repo,
        "upsert",
        lambda **kw: _make_binding_row(
            **{
                "company_id": kw["company_id"],
                "document_id": kw["document_id"],
                "feature_key": kw["feature_key"],
                "kb_id": kw["kb_id"],
                "kb_table": kw["kb_table"],
                "column_mapping": kw["column_mapping"],
                "plan_comptable_source": kw["plan_comptable_source"],
                "bound_by_user_id": kw["bound_by_user_id"],
            }
        ),
    )
    out = await binding_service.put_binding(
        document_id=DOC_ID,
        feature_key="crp_charges_g1",
        payload=KbBindingCreate(kb_id=KB_ID),
        company_id=COMPANY,
        user_id=USER,
    )
    # Type mismatch did not block — binding is in place.
    assert out.feature_key == "crp_charges_g1"


# ---------------------------------------------------------------------------
# delete_binding
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_delete_binding_happy(monkeypatch, owned_doc, patch_run_in_thread):
    monkeypatch.setattr(binding_service.kb_binding_repo, "delete", lambda doc, key: True)
    await binding_service.delete_binding(DOC_ID, "crp_charges_g1", COMPANY)


@pytest.mark.asyncio
async def test_delete_binding_not_found(monkeypatch, owned_doc, patch_run_in_thread):
    monkeypatch.setattr(binding_service.kb_binding_repo, "delete", lambda doc, key: False)
    with pytest.raises(NotFoundError) as exc:
        await binding_service.delete_binding(DOC_ID, "missing", COMPANY)
    assert exc.value.code == "binding_not_found"


# ---------------------------------------------------------------------------
# preview_binding
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_preview_binding_happy(monkeypatch, owned_doc, patch_run_in_thread):
    monkeypatch.setattr(binding_service.feature_catalog_service, "get_feature", _stub_feature)
    monkeypatch.setattr(
        binding_service.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, key: _make_binding_row(),
    )

    async def _meta(kb, company):
        return _make_kb_meta()

    monkeypatch.setattr(binding_service.kb_discovery, "fetch_kb_meta", _meta)

    captured: dict = {}

    async def _fake_agg(**kwargs):
        captured.update(kwargs)
        return [
            {"compte": "6064", "montant": 12450.0},
            {"compte": "60611", "montant": 3050.0},
        ]

    monkeypatch.setattr(binding_service.kb_discovery, "aggregate_preview", _fake_agg)

    out = await binding_service.preview_binding(
        document_id=DOC_ID,
        feature_key="crp_charges_g1",
        company_id=COMPANY,
        filters={},
    )
    assert out.row_count == 2
    assert out.rows[0].data == {"compte": "6064", "montant": 12450.0}
    # contract dims = compte, measures = montant
    assert captured["dimension_logical_cols"] == ["compte"]
    assert captured["measure_logical_cols"] == ["montant"]
    # Post-SDK-0.8 refactor : wrapper takes kb_id + contract_to_kb_logical
    # instead of kb_table + pg_column_by_name (SDK resolves pg_column from
    # kb_id internally via list_columns). Check the new signature lands.
    assert "kb_id" in captured
    assert captured["contract_to_kb_logical"] == {"compte": "compte", "montant": "montant"}


@pytest.mark.asyncio
async def test_preview_binding_no_binding(monkeypatch, owned_doc, patch_run_in_thread):
    monkeypatch.setattr(binding_service.feature_catalog_service, "get_feature", _stub_feature)
    monkeypatch.setattr(
        binding_service.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, key: None,
    )
    with pytest.raises(NotFoundError) as exc:
        await binding_service.preview_binding(
            document_id=DOC_ID,
            feature_key="crp_charges_g1",
            company_id=COMPANY,
            filters={},
        )
    assert exc.value.code == "binding_not_found"


@pytest.mark.asyncio
async def test_preview_binding_kb_dangling(monkeypatch, owned_doc, patch_run_in_thread):
    monkeypatch.setattr(binding_service.feature_catalog_service, "get_feature", _stub_feature)
    monkeypatch.setattr(
        binding_service.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, key: _make_binding_row(),
    )

    async def _none(kb, company):
        return None

    monkeypatch.setattr(binding_service.kb_discovery, "fetch_kb_meta", _none)
    with pytest.raises(ConflictError) as exc:
        await binding_service.preview_binding(
            document_id=DOC_ID,
            feature_key="crp_charges_g1",
            company_id=COMPANY,
            filters={},
        )
    assert exc.value.code == "binding_kb_dangling"


# ---------------------------------------------------------------------------
# validation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_validation_ready_to_produce(monkeypatch, patch_run_in_thread):
    """All mandatory features are bound → ready_to_produce=True."""

    def _fake_ctx(doc, company):
        return {"type_document": "eprd", "exercice_id": uuid4(), "typologie": "ehpad"}

    monkeypatch.setattr(binding_service.kb_binding_repo, "load_document_context", _fake_ctx)

    async def _list_features(**kw):
        return [
            _make_feature(feature_key="crp_charges_g1"),
            _make_feature(feature_key="crp_charges_g2"),
        ]

    monkeypatch.setattr(binding_service.feature_catalog_service, "list_features", _list_features)
    monkeypatch.setattr(
        binding_service.kb_binding_repo,
        "list_by_document",
        lambda doc: [
            _make_binding_row(feature_key="crp_charges_g1"),
            _make_binding_row(feature_key="crp_charges_g2"),
            _make_binding_row(feature_key="bilan_actif"),  # optional, extra
        ],
    )
    out = await binding_service.validation(document_id=DOC_ID, company_id=COMPANY)
    assert out.ready_to_produce is True
    assert out.missing == []


@pytest.mark.asyncio
async def test_validation_missing_mandatory(monkeypatch, patch_run_in_thread):
    def _fake_ctx(doc, company):
        return {"type_document": "eprd", "exercice_id": uuid4(), "typologie": None}

    monkeypatch.setattr(binding_service.kb_binding_repo, "load_document_context", _fake_ctx)

    async def _list_features(**kw):
        return [
            _make_feature(feature_key="crp_charges_g1"),
            _make_feature(feature_key="crp_charges_g2"),
            _make_feature(feature_key="crp_charges_g3"),
        ]

    monkeypatch.setattr(binding_service.feature_catalog_service, "list_features", _list_features)
    monkeypatch.setattr(
        binding_service.kb_binding_repo,
        "list_by_document",
        lambda doc: [_make_binding_row(feature_key="crp_charges_g1")],
    )
    out = await binding_service.validation(document_id=DOC_ID, company_id=COMPANY)
    assert out.ready_to_produce is False
    assert sorted(out.missing) == ["crp_charges_g2", "crp_charges_g3"]


@pytest.mark.asyncio
async def test_validation_doc_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        binding_service.kb_binding_repo,
        "load_document_context",
        lambda doc, company: None,
    )
    with pytest.raises(NotFoundError):
        await binding_service.validation(document_id=DOC_ID, company_id=COMPANY)
