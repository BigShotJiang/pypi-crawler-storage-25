"""Unit tests for :mod:`piilot_pack_compta_esms.services.cpom_service`.

DB-free — repo functions are monkeypatched. Focus areas :

* :func:`compute_date_fin_theorique` arithmetic edge cases
* CPOM CRUD happy / 404 / 403 / 422 (og_id mismatch)
* Bulk link OG-cohérence validation
* Objectif CRUD with cross-CPOM mismatch detection
* :func:`is_etablissement_in_cpom` — every branch of the temporal
  + perimetre intersection (§BD pre-req)
"""

from __future__ import annotations

from datetime import UTC, date, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.cpom import (
    CpomCreate,
    CpomEsmsLinkItem,
    CpomObjectifCreate,
    CpomObjectifUpdate,
    CpomUpdate,
)
from piilot_pack_compta_esms.services import cpom_service
from piilot_pack_compta_esms.services.errors import (
    CrossCompanyError,
    NotFoundError,
    ValidationError,
)

COMPANY = uuid4()
OTHER_COMPANY = uuid4()
OG_ID = uuid4()
CPOM_ID = uuid4()
ETS_ID = uuid4()
OBJ_ID = uuid4()


# --------------------------------------------------------------------
# Fixtures
# --------------------------------------------------------------------


@pytest.fixture
def passthrough_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.cpom_service.run_in_thread",
        _passthrough,
    )


def _make_cpom_row(**overrides):
    base = {
        "id": CPOM_ID,
        "company_id": COMPANY,
        "og_id": OG_ID,
        "numero": "CPOM-2024-001",
        "date_signature": date(2024, 1, 15),
        "date_effet": date(2024, 1, 1),
        "duree_annees": Decimal("5"),
        "date_fin_theorique": date(2029, 1, 1),
        "categorie": "EHPAD_IVTER",
        "cosignataires": ["ARS", "CD"],
        "est_proroge": None,
        "motif_prorogation": None,
        "libre_affectation_resultats_o_n": "OUI",
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


def _make_link_row(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "cpom_id": CPOM_ID,
        "etablissement_id": ETS_ID,
        "inclus_dans_perimetre": "OUI",
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


def _make_obj_row(**overrides):
    base = {
        "id": OBJ_ID,
        "company_id": COMPANY,
        "cpom_id": CPOM_ID,
        "intitule": "Test objectif",
        "impact_eprd_o_n": "OUI",
        "description": None,
        "date_realisation_prevue": None,
        "statut": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# --------------------------------------------------------------------
# compute_date_fin_theorique
# --------------------------------------------------------------------


def test_compute_date_fin_theorique_5_years_exact():
    assert cpom_service.compute_date_fin_theorique(date(2024, 1, 1), Decimal("5")) == date(
        2029, 1, 1
    )


def test_compute_date_fin_theorique_7_years_max():
    assert cpom_service.compute_date_fin_theorique(date(2024, 6, 15), Decimal("7")) == date(
        2031, 6, 15
    )


def test_compute_date_fin_theorique_half_year_fraction():
    # 2024-01-01 + 5.5 ans → 2029-07-02 (2029 = 365 jours, +182 jours)
    assert cpom_service.compute_date_fin_theorique(date(2024, 1, 1), Decimal("5.5")) == date(
        2029, 7, 2
    )


def test_compute_date_fin_theorique_feb_29_collapses_to_feb_28():
    # 2024 = leap year, 2025 = non-leap → Feb-29 → Feb-28.
    assert cpom_service.compute_date_fin_theorique(date(2024, 2, 29), Decimal("1")) == date(
        2025, 2, 28
    )


def test_compute_date_fin_theorique_feb_29_stays_feb_29_when_target_is_leap():
    # 2024 → 2028 sont tous les deux bissextiles → Feb-29 préservé.
    assert cpom_service.compute_date_fin_theorique(date(2024, 2, 29), Decimal("4")) == date(
        2028, 2, 29
    )


def test_compute_date_fin_theorique_1_year_minimum():
    assert cpom_service.compute_date_fin_theorique(date(2024, 7, 1), Decimal("1")) == date(
        2025, 7, 1
    )


# --------------------------------------------------------------------
# get_cpom / list / create / update / delete
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_cpom_returns_read(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    out = await cpom_service.get_cpom(COMPANY, CPOM_ID)
    assert out.id == CPOM_ID
    assert out.cosignataires == ["ARS", "CD"]


@pytest.mark.asyncio
async def test_get_cpom_404_when_missing(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: None)
    with pytest.raises(NotFoundError):
        await cpom_service.get_cpom(COMPANY, CPOM_ID)


@pytest.mark.asyncio
async def test_get_cpom_403_when_cross_company(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        cpom_service.cpom_repo,
        "get_by_id",
        lambda cpom_id: _make_cpom_row(company_id=OTHER_COMPANY),
    )
    with pytest.raises(CrossCompanyError):
        await cpom_service.get_cpom(COMPANY, CPOM_ID)


@pytest.mark.asyncio
async def test_list_cpoms_404_when_og_not_found(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "og_exists_for_company", lambda og, c: False)
    with pytest.raises(NotFoundError):
        await cpom_service.list_cpoms_by_og(COMPANY, OG_ID)


@pytest.mark.asyncio
async def test_list_cpoms_returns_reads(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "og_exists_for_company", lambda og, c: True)
    monkeypatch.setattr(
        cpom_service.cpom_repo,
        "list_by_og",
        lambda og: [_make_cpom_row(), _make_cpom_row(id=uuid4(), numero="OTHER")],
    )
    out = await cpom_service.list_cpoms_by_og(COMPANY, OG_ID)
    assert len(out) == 2


@pytest.mark.asyncio
async def test_create_cpom_404_when_og_not_found(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "og_exists_for_company", lambda og, c: False)
    payload = CpomCreate(
        og_id=OG_ID,
        date_signature=date(2024, 1, 15),
        date_effet=date(2024, 1, 1),
        duree_annees=Decimal("5"),
        categorie="EHPAD_IVTER",
        cosignataires=["ARS"],
        libre_affectation_resultats_o_n="OUI",
    )
    with pytest.raises(NotFoundError):
        await cpom_service.create_cpom(COMPANY, OG_ID, payload)


@pytest.mark.asyncio
async def test_create_cpom_422_on_body_path_og_mismatch(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "og_exists_for_company", lambda og, c: True)
    payload = CpomCreate(
        og_id=uuid4(),  # ne matche pas l'OG_ID du path
        date_signature=date(2024, 1, 15),
        date_effet=date(2024, 1, 1),
        duree_annees=Decimal("5"),
        categorie="EHPAD_IVTER",
        cosignataires=["ARS"],
        libre_affectation_resultats_o_n="OUI",
    )
    with pytest.raises(ValidationError, match="og_id") as exc_info:
        await cpom_service.create_cpom(COMPANY, OG_ID, payload)
    assert exc_info.value.code == "og_id_mismatch"


@pytest.mark.asyncio
async def test_create_cpom_writes_date_fin_theorique(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "og_exists_for_company", lambda og, c: True)
    captured = {}

    def _create(company_id, og_id, payload):
        captured["payload"] = payload
        return _make_cpom_row(date_fin_theorique=payload["date_fin_theorique"])

    monkeypatch.setattr(cpom_service.cpom_repo, "create", _create)
    payload = CpomCreate(
        og_id=OG_ID,
        date_signature=date(2024, 1, 15),
        date_effet=date(2024, 1, 1),
        duree_annees=Decimal("5"),
        categorie="EHPAD_IVTER",
        cosignataires=["ARS"],
        libre_affectation_resultats_o_n="OUI",
    )
    out = await cpom_service.create_cpom(COMPANY, OG_ID, payload)
    assert captured["payload"]["date_fin_theorique"] == date(2029, 1, 1)
    assert out.date_fin_theorique == date(2029, 1, 1)


@pytest.mark.asyncio
async def test_update_cpom_recomputes_date_fin_when_effet_changes(
    monkeypatch, passthrough_run_in_thread
):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    captured = {}

    def _update(cpom_id, payload):
        captured["payload"] = payload
        return _make_cpom_row(**payload)

    monkeypatch.setattr(cpom_service.cpom_repo, "update", _update)
    payload = CpomUpdate(date_effet=date(2025, 6, 1))
    out = await cpom_service.update_cpom(COMPANY, CPOM_ID, payload)
    # date_effet 2025-06-01 + duree_annees 5 (current) → 2030-06-01
    assert captured["payload"]["date_fin_theorique"] == date(2030, 6, 1)
    assert out.id == CPOM_ID


@pytest.mark.asyncio
async def test_update_cpom_recomputes_when_duree_changes(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    captured = {}

    def _update(cpom_id, payload):
        captured["payload"] = payload
        return _make_cpom_row(**payload)

    monkeypatch.setattr(cpom_service.cpom_repo, "update", _update)
    payload = CpomUpdate(duree_annees=Decimal("7"))
    await cpom_service.update_cpom(COMPANY, CPOM_ID, payload)
    # date_effet 2024-01-01 (current) + duree 7 → 2031-01-01
    assert captured["payload"]["date_fin_theorique"] == date(2031, 1, 1)


@pytest.mark.asyncio
async def test_update_cpom_no_recompute_when_neither_field_in_payload(
    monkeypatch, passthrough_run_in_thread
):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    captured = {}

    def _update(cpom_id, payload):
        captured["payload"] = payload
        return _make_cpom_row(**payload)

    monkeypatch.setattr(cpom_service.cpom_repo, "update", _update)
    payload = CpomUpdate(numero="REV-001")
    await cpom_service.update_cpom(COMPANY, CPOM_ID, payload)
    assert "date_fin_theorique" not in captured["payload"]


@pytest.mark.asyncio
async def test_update_cpom_404_when_missing(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: None)
    with pytest.raises(NotFoundError):
        await cpom_service.update_cpom(COMPANY, CPOM_ID, CpomUpdate(numero="x"))


@pytest.mark.asyncio
async def test_update_cpom_403_when_cross_company(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        cpom_service.cpom_repo,
        "get_by_id",
        lambda cpom_id: _make_cpom_row(company_id=OTHER_COMPANY),
    )
    with pytest.raises(CrossCompanyError):
        await cpom_service.update_cpom(COMPANY, CPOM_ID, CpomUpdate(numero="x"))


@pytest.mark.asyncio
async def test_delete_cpom_happy_path(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    monkeypatch.setattr(cpom_service.cpom_repo, "delete", lambda cpom_id: True)
    await cpom_service.delete_cpom(COMPANY, CPOM_ID)


@pytest.mark.asyncio
async def test_delete_cpom_404_when_missing(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: None)
    with pytest.raises(NotFoundError):
        await cpom_service.delete_cpom(COMPANY, CPOM_ID)


# --------------------------------------------------------------------
# Bulk link OG-cohérence
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_link_rejects_cross_og_ets(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "ets_belongs_to_og",
        lambda ets, og: False,
    )
    items = [CpomEsmsLinkItem(etablissement_id=ETS_ID, inclus_dans_perimetre="OUI")]
    with pytest.raises(ValidationError, match="does not belong to OG") as exc_info:
        await cpom_service.bulk_link_etablissements(COMPANY, CPOM_ID, items)
    assert exc_info.value.code == "ets_og_mismatch"


@pytest.mark.asyncio
async def test_bulk_link_happy_path(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "ets_belongs_to_og",
        lambda ets, og: True,
    )
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "upsert",
        lambda c, cp, ets, perimetre: _make_link_row(
            etablissement_id=ets, inclus_dans_perimetre=perimetre
        ),
    )
    items = [
        CpomEsmsLinkItem(etablissement_id=ETS_ID, inclus_dans_perimetre="OUI"),
        CpomEsmsLinkItem(etablissement_id=uuid4(), inclus_dans_perimetre="NON"),
    ]
    out = await cpom_service.bulk_link_etablissements(COMPANY, CPOM_ID, items)
    assert len(out) == 2
    assert out[0].inclus_dans_perimetre == "OUI"
    assert out[1].inclus_dans_perimetre == "NON"


@pytest.mark.asyncio
async def test_bulk_link_empty_returns_empty(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    out = await cpom_service.bulk_link_etablissements(COMPANY, CPOM_ID, [])
    assert out == []


@pytest.mark.asyncio
async def test_unlink_etablissement_404_when_no_link(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "get_by_cpom_and_ets",
        lambda cp, ets: None,
    )
    with pytest.raises(NotFoundError):
        await cpom_service.unlink_etablissement(COMPANY, CPOM_ID, ETS_ID)


@pytest.mark.asyncio
async def test_unlink_etablissement_happy(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "get_by_cpom_and_ets",
        lambda cp, ets: _make_link_row(),
    )
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "delete_by_cpom_and_ets",
        lambda cp, ets: True,
    )
    await cpom_service.unlink_etablissement(COMPANY, CPOM_ID, ETS_ID)


# --------------------------------------------------------------------
# Objectifs CRUD
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_objectifs_404_when_cpom_missing(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: None)
    with pytest.raises(NotFoundError):
        await cpom_service.list_objectifs(COMPANY, CPOM_ID)


@pytest.mark.asyncio
async def test_list_objectifs_returns_reads(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    monkeypatch.setattr(
        cpom_service.cpom_objectifs_repo,
        "list_by_cpom",
        lambda cp: [_make_obj_row(), _make_obj_row(id=uuid4(), statut="REALISE")],
    )
    out = await cpom_service.list_objectifs(COMPANY, CPOM_ID)
    assert len(out) == 2


@pytest.mark.asyncio
async def test_create_objectif_happy(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    captured = {}

    def _create(company_id, cpom_id, payload):
        captured["payload"] = payload
        return _make_obj_row(**payload)

    monkeypatch.setattr(cpom_service.cpom_objectifs_repo, "create", _create)
    payload = CpomObjectifCreate(intitule="New goal", impact_eprd_o_n="OUI")
    out = await cpom_service.create_objectif(COMPANY, CPOM_ID, payload)
    assert out.intitule == "New goal"
    assert "intitule" in captured["payload"]


@pytest.mark.asyncio
async def test_update_objectif_422_on_cpom_mismatch(monkeypatch, passthrough_run_in_thread):
    other_cpom = uuid4()
    monkeypatch.setattr(
        cpom_service.cpom_objectifs_repo,
        "get_by_id",
        lambda oid: _make_obj_row(cpom_id=other_cpom),
    )
    with pytest.raises(ValidationError, match="does not belong to CPOM") as exc_info:
        await cpom_service.update_objectif(
            COMPANY, CPOM_ID, OBJ_ID, CpomObjectifUpdate(statut="REALISE")
        )
    assert exc_info.value.code == "objectif_cpom_mismatch"


@pytest.mark.asyncio
async def test_update_objectif_403_on_cross_company(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        cpom_service.cpom_objectifs_repo,
        "get_by_id",
        lambda oid: _make_obj_row(company_id=OTHER_COMPANY),
    )
    with pytest.raises(CrossCompanyError):
        await cpom_service.update_objectif(
            COMPANY, CPOM_ID, OBJ_ID, CpomObjectifUpdate(statut="REALISE")
        )


@pytest.mark.asyncio
async def test_update_objectif_404_when_missing(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_objectifs_repo, "get_by_id", lambda oid: None)
    with pytest.raises(NotFoundError):
        await cpom_service.update_objectif(
            COMPANY, CPOM_ID, OBJ_ID, CpomObjectifUpdate(statut="REALISE")
        )


@pytest.mark.asyncio
async def test_update_objectif_empty_payload_is_idempotent(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        cpom_service.cpom_objectifs_repo,
        "get_by_id",
        lambda oid: _make_obj_row(),
    )
    # The repo update should NOT be called when the payload is empty.
    monkeypatch.setattr(
        cpom_service.cpom_objectifs_repo,
        "update",
        lambda oid, p: (_ for _ in ()).throw(  # pragma: no cover
            AssertionError("update should not be called for empty payload")
        ),
    )
    out = await cpom_service.update_objectif(COMPANY, CPOM_ID, OBJ_ID, CpomObjectifUpdate())
    assert out.id == OBJ_ID


@pytest.mark.asyncio
async def test_delete_objectif_happy(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        cpom_service.cpom_objectifs_repo,
        "get_by_id",
        lambda oid: _make_obj_row(),
    )
    monkeypatch.setattr(cpom_service.cpom_objectifs_repo, "delete", lambda oid: True)
    await cpom_service.delete_objectif(COMPANY, CPOM_ID, OBJ_ID)


# --------------------------------------------------------------------
# compute_progress
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_compute_progress_with_objectives(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    monkeypatch.setattr(
        cpom_service.cpom_objectifs_repo,
        "aggregate_status_by_cpom",
        lambda cp: {
            "total": 10,
            "prevus": 2,
            "en_cours": 3,
            "realises": 4,
            "abandonnes": 1,
            "sans_statut": 0,
        },
    )
    out = await cpom_service.compute_progress(COMPANY, CPOM_ID)
    assert out.total == 10
    assert out.realises == 4
    assert out.ratio_realise == 0.4


@pytest.mark.asyncio
async def test_compute_progress_with_zero_objectives_returns_zero_ratio(
    monkeypatch, passthrough_run_in_thread
):
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cpom_id: _make_cpom_row())
    monkeypatch.setattr(
        cpom_service.cpom_objectifs_repo,
        "aggregate_status_by_cpom",
        lambda cp: {
            "total": 0,
            "prevus": 0,
            "en_cours": 0,
            "realises": 0,
            "abandonnes": 0,
            "sans_statut": 0,
        },
    )
    out = await cpom_service.compute_progress(COMPANY, CPOM_ID)
    assert out.ratio_realise == 0.0


# --------------------------------------------------------------------
# §BD pre-req: is_etablissement_in_cpom
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_is_in_cpom_no_links_returns_false(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "list_by_etablissement",
        lambda ets: [],
    )
    assert await cpom_service.is_etablissement_in_cpom(ETS_ID, 2025) is False


@pytest.mark.asyncio
async def test_is_in_cpom_link_perimetre_non_excluded(monkeypatch, passthrough_run_in_thread):
    """Un ETS rattaché à un CPOM mais hors périmètre tarifaire ne
    compte pas — il faut explicitement ``OUI``."""
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "list_by_etablissement",
        lambda ets: [_make_link_row(inclus_dans_perimetre="NON")],
    )
    monkeypatch.setattr(
        cpom_service.cpom_repo,
        "get_by_id",
        lambda cp: _make_cpom_row(),
    )
    assert await cpom_service.is_etablissement_in_cpom(ETS_ID, 2025) is False


@pytest.mark.asyncio
async def test_is_in_cpom_exercice_inside_cpom_returns_true(monkeypatch, passthrough_run_in_thread):
    """Exercice 2025 dans [2024-01-01, 2029-01-01) → True."""
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "list_by_etablissement",
        lambda ets: [_make_link_row(inclus_dans_perimetre="OUI")],
    )
    monkeypatch.setattr(
        cpom_service.cpom_repo,
        "get_by_id",
        lambda cp: _make_cpom_row(
            date_effet=date(2024, 1, 1),
            date_fin_theorique=date(2029, 1, 1),
        ),
    )
    assert await cpom_service.is_etablissement_in_cpom(ETS_ID, 2025) is True


@pytest.mark.asyncio
async def test_is_in_cpom_exercice_before_cpom_returns_false(
    monkeypatch, passthrough_run_in_thread
):
    """Exercice 2023 antérieur au CPOM (effet 2024-01-01) → False."""
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "list_by_etablissement",
        lambda ets: [_make_link_row(inclus_dans_perimetre="OUI")],
    )
    monkeypatch.setattr(
        cpom_service.cpom_repo,
        "get_by_id",
        lambda cp: _make_cpom_row(
            date_effet=date(2024, 1, 1),
            date_fin_theorique=date(2029, 1, 1),
        ),
    )
    assert await cpom_service.is_etablissement_in_cpom(ETS_ID, 2023) is False


@pytest.mark.asyncio
async def test_is_in_cpom_exercice_after_cpom_returns_false(monkeypatch, passthrough_run_in_thread):
    """Exercice 2030 postérieur au CPOM (fin 2029-01-01 exclusive) → False."""
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "list_by_etablissement",
        lambda ets: [_make_link_row(inclus_dans_perimetre="OUI")],
    )
    monkeypatch.setattr(
        cpom_service.cpom_repo,
        "get_by_id",
        lambda cp: _make_cpom_row(
            date_effet=date(2024, 1, 1),
            date_fin_theorique=date(2029, 1, 1),
        ),
    )
    assert await cpom_service.is_etablissement_in_cpom(ETS_ID, 2030) is False


@pytest.mark.asyncio
async def test_is_in_cpom_partial_overlap_returns_true(monkeypatch, passthrough_run_in_thread):
    """Un CPOM qui se finit en milieu d'année d'exercice doit toujours
    compter pour cet exercice (couverture partielle ≥ 1 jour suffit)."""
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "list_by_etablissement",
        lambda ets: [_make_link_row(inclus_dans_perimetre="OUI")],
    )
    monkeypatch.setattr(
        cpom_service.cpom_repo,
        "get_by_id",
        lambda cp: _make_cpom_row(
            date_effet=date(2020, 1, 1),
            date_fin_theorique=date(2025, 6, 30),
        ),
    )
    # Exercice 2025 : la borne fin tombe au milieu de l'année.
    assert await cpom_service.is_etablissement_in_cpom(ETS_ID, 2025) is True


@pytest.mark.asyncio
async def test_is_in_cpom_boundary_end_exclusive(monkeypatch, passthrough_run_in_thread):
    """``date_fin_theorique`` au 2025-01-01 doit exclure l'exercice
    2025 — l'intervalle est semi-ouvert ``[effet, fin)``."""
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "list_by_etablissement",
        lambda ets: [_make_link_row(inclus_dans_perimetre="OUI")],
    )
    monkeypatch.setattr(
        cpom_service.cpom_repo,
        "get_by_id",
        lambda cp: _make_cpom_row(
            date_effet=date(2020, 1, 1),
            date_fin_theorique=date(2025, 1, 1),
        ),
    )
    assert await cpom_service.is_etablissement_in_cpom(ETS_ID, 2025) is False


@pytest.mark.asyncio
async def test_is_in_cpom_skips_stale_link_to_deleted_cpom(monkeypatch, passthrough_run_in_thread):
    """Si la row CPOM a disparu mid-flight (race), la link est
    ignorée silencieusement."""
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "list_by_etablissement",
        lambda ets: [_make_link_row(inclus_dans_perimetre="OUI")],
    )
    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", lambda cp: None)
    assert await cpom_service.is_etablissement_in_cpom(ETS_ID, 2025) is False


@pytest.mark.asyncio
async def test_is_in_cpom_multiple_links_short_circuits_on_first_match(
    monkeypatch, passthrough_run_in_thread
):
    """3 links — le 1er est NON, le 2e est OUI + actif, le 3e ne
    devrait pas être inspecté (court-circuit)."""
    other_cp_1 = uuid4()
    other_cp_2 = uuid4()
    links = [
        _make_link_row(cpom_id=other_cp_1, inclus_dans_perimetre="NON"),
        _make_link_row(cpom_id=other_cp_2, inclus_dans_perimetre="OUI"),
        _make_link_row(cpom_id=uuid4(), inclus_dans_perimetre="OUI"),
    ]
    monkeypatch.setattr(
        cpom_service.cpom_esms_link_repo,
        "list_by_etablissement",
        lambda ets: links,
    )

    inspected = []

    def _get_cpom(cp):
        inspected.append(cp)
        # Le 1er est skipped (NON), 2e match — on retourne un CPOM
        # actif sur 2025. Pour les autres on retourne aussi un match
        # mais le service ne devrait jamais y arriver.
        return _make_cpom_row(
            date_effet=date(2024, 1, 1),
            date_fin_theorique=date(2029, 1, 1),
        )

    monkeypatch.setattr(cpom_service.cpom_repo, "get_by_id", _get_cpom)
    assert await cpom_service.is_etablissement_in_cpom(ETS_ID, 2025) is True
    # Le 1er link a perimetre=NON donc get_by_id n'a même pas été
    # appelé pour lui. Le 2e match → on s'arrête.
    assert inspected == [other_cp_2]
