"""Unit tests for :mod:`piilot_pack_compta_esms.services.emprunts_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.emprunts import (
    EmpruntCreate,
    EmpruntsBulkUpsertRequest,
)
from piilot_pack_compta_esms.services import emprunts_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
DOC_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.emprunts_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def valid_doc(monkeypatch):
    monkeypatch.setattr(
        emprunts_service.emprunts_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )


def _row(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "type_dette": "emprunts_prives",
        "libelle": "Crédit Mutuel #1",
        "capital_emprunte": Decimal("500000"),
        "taux": Decimal("2.5"),
        "duree_annees": 15,
        "date_debut": None,
        "capital_rembourse_n1": Decimal("30000"),
        "capital_rembourse_n": Decimal("30000"),
        "interets_n1": Decimal("12000"),
        "interets_n": Decimal("11500"),
        "solde_restant_du": Decimal("440000"),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# list_emprunts
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_no_filter_returns_all_with_breakdown(
    patch_run_in_thread, valid_doc, monkeypatch
):
    """Sans ?type_dette : tous les emprunts + totals breakdown sur tous
    les types présents."""
    monkeypatch.setattr(
        emprunts_service.emprunts_repo,
        "list_by_document",
        lambda doc, type_dette=None: [
            _row(),
            _row(type_dette="dettes_financieres_publics_1"),
        ],
    )
    monkeypatch.setattr(
        emprunts_service.emprunts_repo,
        "totals_by_type_dette",
        lambda doc, type_dette=None: [
            {
                "type_dette": "emprunts_prives",
                "nb_lignes": 1,
                "capital_emprunte_total": Decimal("500000"),
                "capital_rembourse_n1_total": Decimal("30000"),
                "capital_rembourse_n_total": Decimal("30000"),
                "interets_n1_total": Decimal("12000"),
                "interets_n_total": Decimal("11500"),
                "solde_restant_du_total": Decimal("440000"),
            },
            {
                "type_dette": "dettes_financieres_publics_1",
                "nb_lignes": 1,
                "capital_emprunte_total": Decimal("200000"),
                "capital_rembourse_n1_total": Decimal("10000"),
                "capital_rembourse_n_total": Decimal("10000"),
                "interets_n1_total": Decimal("5000"),
                "interets_n_total": Decimal("4800"),
                "solde_restant_du_total": Decimal("180000"),
            },
        ],
    )

    result = await emprunts_service.list_emprunts(DOC_ID, COMPANY)

    assert result.type_dette_filtre is None
    assert len(result.items) == 2
    assert len(result.totals.by_type_dette) == 2
    assert result.totals.total_general.capital_emprunte_total == Decimal("700000")
    assert result.totals.total_general.solde_restant_du_total == Decimal("620000")


@pytest.mark.asyncio
async def test_list_with_filter_restricts_items_and_totals(
    patch_run_in_thread, valid_doc, monkeypatch
):
    """Avec ?type_dette : seul ce type est retourné."""
    captured = {}

    def _list(doc, type_dette=None):
        captured["list_filter"] = type_dette
        return [_row(type_dette="dettes_financieres_publics_3")]

    def _totals(doc, type_dette=None):
        captured["totals_filter"] = type_dette
        return [
            {
                "type_dette": "dettes_financieres_publics_3",
                "nb_lignes": 1,
                "capital_emprunte_total": Decimal("100000"),
                "capital_rembourse_n1_total": Decimal("5000"),
                "capital_rembourse_n_total": Decimal("5000"),
                "interets_n1_total": Decimal("2000"),
                "interets_n_total": Decimal("1900"),
                "solde_restant_du_total": Decimal("90000"),
            }
        ]

    monkeypatch.setattr(emprunts_service.emprunts_repo, "list_by_document", _list)
    monkeypatch.setattr(emprunts_service.emprunts_repo, "totals_by_type_dette", _totals)

    result = await emprunts_service.list_emprunts(
        DOC_ID, COMPANY, type_dette="dettes_financieres_publics_3"
    )

    assert result.type_dette_filtre == "dettes_financieres_publics_3"
    assert captured["list_filter"] == "dettes_financieres_publics_3"
    assert captured["totals_filter"] == "dettes_financieres_publics_3"
    assert len(result.items) == 1
    assert len(result.totals.by_type_dette) == 1


@pytest.mark.asyncio
async def test_list_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        emprunts_service.emprunts_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    with pytest.raises(NotFoundError) as exc:
        await emprunts_service.list_emprunts(DOC_ID, COMPANY)
    assert exc.value.code == "document_not_found"


# ---------------------------------------------------------------------------
# bulk_upsert_emprunts
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_upsert_replace_by_type_dette(patch_run_in_thread, valid_doc, monkeypatch):
    """Q4 — replace_by_document_AND_type_dette : ne touche QUE le
    type_dette du payload."""
    calls = {}

    def _replace(*, company_id, document_id, type_dette, items):
        calls["type_dette"] = type_dette
        calls["items"] = items
        return []

    monkeypatch.setattr(
        emprunts_service.emprunts_repo,
        "replace_by_document_and_type_dette",
        _replace,
    )
    monkeypatch.setattr(
        emprunts_service.emprunts_repo,
        "list_by_document",
        lambda doc, type_dette=None: [],
    )
    monkeypatch.setattr(
        emprunts_service.emprunts_repo,
        "totals_by_type_dette",
        lambda doc, type_dette=None: [],
    )

    payload = EmpruntsBulkUpsertRequest(
        type_dette="dettes_financieres_publics_2",
        items=[
            EmpruntCreate(
                libelle="Caisse Dépôts #A",
                capital_emprunte=Decimal("300000"),
                taux=Decimal("1.5"),
                duree_annees=20,
            ),
        ],
    )
    result = await emprunts_service.bulk_upsert_emprunts(DOC_ID, COMPANY, payload)

    assert calls["type_dette"] == "dettes_financieres_publics_2"
    assert len(calls["items"]) == 1
    # Le GET de retour est filtré sur le même type_dette
    assert result.type_dette_filtre == "dettes_financieres_publics_2"


@pytest.mark.asyncio
async def test_bulk_upsert_empty_items_clears_type(patch_run_in_thread, valid_doc, monkeypatch):
    """items: [] sur un type_dette → équivaut à supprimer tous les
    emprunts de ce type pour ce document."""
    calls = {}

    def _replace(*, company_id, document_id, type_dette, items):
        calls["type_dette"] = type_dette
        calls["items"] = items
        return []

    monkeypatch.setattr(
        emprunts_service.emprunts_repo,
        "replace_by_document_and_type_dette",
        _replace,
    )
    monkeypatch.setattr(
        emprunts_service.emprunts_repo,
        "list_by_document",
        lambda doc, type_dette=None: [],
    )
    monkeypatch.setattr(
        emprunts_service.emprunts_repo,
        "totals_by_type_dette",
        lambda doc, type_dette=None: [],
    )

    payload = EmpruntsBulkUpsertRequest(type_dette="emprunts_prives", items=[])
    await emprunts_service.bulk_upsert_emprunts(DOC_ID, COMPANY, payload)

    assert calls["type_dette"] == "emprunts_prives"
    assert calls["items"] == []


@pytest.mark.asyncio
async def test_bulk_upsert_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        emprunts_service.emprunts_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    payload = EmpruntsBulkUpsertRequest(type_dette="emprunts_prives", items=[])
    with pytest.raises(NotFoundError):
        await emprunts_service.bulk_upsert_emprunts(DOC_ID, COMPANY, payload)
