"""Tests §AB — helpers _base + styles.

Couvre sanitize / format / write helpers, truncate sheet name.
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

import pytest
from openpyxl import Workbook

from piilot_pack_compta_esms.exports.xlsx._base import (
    format_date,
    format_montant,
    sanitize_for_xlsx,
    truncate_sheet_name,
    write_date,
    write_integer,
    write_montant,
    write_percent,
    write_text,
)

# ---------------------------------------------------------------------------
# sanitize_for_xlsx
# ---------------------------------------------------------------------------


def test_sanitize_none_returns_empty() -> None:
    assert sanitize_for_xlsx(None) == ""


def test_sanitize_trims_multiple_spaces() -> None:
    assert sanitize_for_xlsx("  hello   world  ") == "hello world"


def test_sanitize_rejects_pipe_d075() -> None:
    with pytest.raises(ValueError, match="pipe_char_forbidden"):
        sanitize_for_xlsx("foo|bar")


def test_sanitize_non_str_coerced() -> None:
    assert sanitize_for_xlsx(42) == "42"
    assert sanitize_for_xlsx(3.14) == "3.14"


# ---------------------------------------------------------------------------
# format_montant
# ---------------------------------------------------------------------------


def test_format_montant_decimal_2_decimals() -> None:
    assert format_montant(Decimal("123.456")) == 123.46
    assert format_montant(Decimal("100")) == 100.00


def test_format_montant_none() -> None:
    assert format_montant(None) is None


# ---------------------------------------------------------------------------
# format_date
# ---------------------------------------------------------------------------


def test_format_date_from_date() -> None:
    d = date(2026, 5, 19)
    assert format_date(d) == d


def test_format_date_from_datetime() -> None:
    dt = datetime(2026, 5, 19, 14, 30)
    assert format_date(dt) == date(2026, 5, 19)


def test_format_date_from_iso_string() -> None:
    assert format_date("2026-05-19") == date(2026, 5, 19)


def test_format_date_none() -> None:
    assert format_date(None) is None


def test_format_date_invalid_returns_none() -> None:
    assert format_date("not-a-date") is None


# ---------------------------------------------------------------------------
# truncate_sheet_name
# ---------------------------------------------------------------------------


def test_truncate_sheet_short_kept() -> None:
    assert truncate_sheet_name("CRPP - 2026") == "CRPP - 2026"


def test_truncate_sheet_long_truncated() -> None:
    name = "X" * 40
    result = truncate_sheet_name(name)
    assert len(result) == 31
    assert result.endswith("...")


def test_truncate_sheet_forbidden_chars_replaced() -> None:
    assert truncate_sheet_name("CRP/SF:test") == "CRP_SF_test"
    assert truncate_sheet_name("[brackets]") == "_brackets_"


# ---------------------------------------------------------------------------
# Cell writers
# ---------------------------------------------------------------------------


def test_write_text_sanitizes() -> None:
    wb = Workbook()
    ws = wb.active
    write_text(ws, "A1", "  hello   world  ")
    assert ws["A1"].value == "hello world"


def test_write_text_rejects_pipe() -> None:
    wb = Workbook()
    ws = wb.active
    with pytest.raises(ValueError):
        write_text(ws, "A1", "bad|value")


def test_write_montant_sets_format() -> None:
    wb = Workbook()
    ws = wb.active
    write_montant(ws, "A1", Decimal("1234.5"))
    assert ws["A1"].value == 1234.50
    assert ws["A1"].number_format == "#,##0.00"


def test_write_montant_none() -> None:
    wb = Workbook()
    ws = wb.active
    write_montant(ws, "A1", None)
    assert ws["A1"].value is None


def test_write_percent_format() -> None:
    wb = Workbook()
    ws = wb.active
    write_percent(ws, "A1", Decimal("0.5"))
    assert ws["A1"].value == 0.5
    assert ws["A1"].number_format == "0.0%"


def test_write_date_format() -> None:
    wb = Workbook()
    ws = wb.active
    write_date(ws, "A1", date(2026, 5, 19))
    assert ws["A1"].value == date(2026, 5, 19)
    assert ws["A1"].number_format == "DD/MM/YYYY"


def test_write_integer() -> None:
    wb = Workbook()
    ws = wb.active
    write_integer(ws, "A1", 42)
    assert ws["A1"].value == 42
    assert ws["A1"].number_format == "#,##0"
