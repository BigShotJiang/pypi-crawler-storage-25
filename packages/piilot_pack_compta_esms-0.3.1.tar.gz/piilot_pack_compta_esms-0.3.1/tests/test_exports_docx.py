"""Tests §AC — rapport DOCX builder + service + route.

Couvre :

* format helpers (currency_fr, date_fr, percent_fr, int_fr) format
  français + None → "—"
* sanitize D-075 wrapper
* rapport_builder end-to-end smoke (3 parties + métadonnées)
* exports_service.export_docx 422 type non supporté
* exports_service.export_docx happy + 404 cross-tenant + pipe
* route POST /export/docx 200 (replaces ancien stub 501)
"""

from __future__ import annotations

from datetime import UTC, date, datetime
from decimal import Decimal
from io import BytesIO
from uuid import uuid4

import pytest
from docx import Document

from piilot_pack_compta_esms.exports.docx import rapport_builder
from piilot_pack_compta_esms.exports.docx._base import (
    add_heading_styled,
    add_paragraph_text,
    add_table_styled,
    fill_table_row,
    format_currency_fr,
    format_date_fr,
    format_int_fr,
    format_percent_fr,
    sanitize,
)
from piilot_pack_compta_esms.services import exports_service
from piilot_pack_compta_esms.services.errors import (
    NotFoundError,
    ValidationError,
)

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
EXERCICE_ID = uuid4()
OG_ID = uuid4()


def _doc(type_document="errd"):
    return {
        "id": DOC_ID,
        "company_id": COMPANY,
        "exercice_id": EXERCICE_ID,
        "type_document": type_document,
        "cadre_version": "#ERRDHA-2025-01#",
        "parent_id": None,
        "statut": "brouillon",
        "periode_observation_debut": None,
        "periode_observation_fin": None,
        "transmis_at": None,
        "executoire_at": None,
        "transmis_par_user_id": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }


def _export_row():
    return {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "type": "docx",
        "s3_key": "exports/.../rapport.docx",
        "filename": "RAPPORT_ERRD_2025.docx",
        "file_size": 5678,
        "generated_by_user_id": USER,
        "generated_at": datetime.now(UTC),
        "deleted_at": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }


# ---------------------------------------------------------------------------
# Format helpers
# ---------------------------------------------------------------------------


def test_format_currency_fr_decimal() -> None:
    """Decimal → "1 234,56 €" avec espace milliers et virgule décimale."""
    assert format_currency_fr(Decimal("1234.56")) == "1 234,56 €"


def test_format_currency_fr_large() -> None:
    assert format_currency_fr(Decimal("1234567.89")) == "1 234 567,89 €"


def test_format_currency_fr_none() -> None:
    assert format_currency_fr(None) == "—"


def test_format_currency_fr_zero() -> None:
    assert format_currency_fr(Decimal("0")) == "0,00 €"


def test_format_int_fr() -> None:
    assert format_int_fr(1234567) == "1 234 567"
    assert format_int_fr(None) == "—"


def test_format_percent_fr() -> None:
    assert format_percent_fr(12.5) == "12,5 %"
    assert format_percent_fr(None) == "—"


def test_format_date_fr() -> None:
    assert format_date_fr(date(2026, 5, 19)) == "19/05/2026"
    assert format_date_fr(datetime(2026, 5, 19, 14, 30)) == "19/05/2026"
    assert format_date_fr("2026-05-19") == "19/05/2026"
    assert format_date_fr(None) == "—"
    assert format_date_fr("invalid") == "—"


def test_sanitize_d075_pipe_rejected() -> None:
    with pytest.raises(ValueError, match="pipe_char_forbidden"):
        sanitize("bad|value")


# ---------------------------------------------------------------------------
# DOCX helpers — heading/paragraph/table
# ---------------------------------------------------------------------------


def test_add_heading_styled_writes() -> None:
    doc = Document()
    add_heading_styled(doc, "Titre Test", level=1)
    # Heading ajouté + sanitize
    assert any("Titre Test" in (p.text or "") for p in doc.paragraphs)


def test_add_paragraph_text_writes() -> None:
    doc = Document()
    add_paragraph_text(doc, "Phrase test")
    assert any("Phrase test" in (p.text or "") for p in doc.paragraphs)


def test_add_table_styled_creates_with_header() -> None:
    doc = Document()
    table = add_table_styled(doc, ["Col1", "Col2", "Col3"])
    assert len(table.rows) == 1
    assert table.rows[0].cells[0].text == "Col1"
    assert table.rows[0].cells[2].text == "Col3"


def test_fill_table_row_appends() -> None:
    doc = Document()
    table = add_table_styled(doc, ["A", "B"])
    fill_table_row(table, ["valeur 1", "valeur 2"])
    assert len(table.rows) == 2
    assert table.rows[1].cells[0].text == "valeur 1"


# ---------------------------------------------------------------------------
# rapport_builder smoke
# ---------------------------------------------------------------------------


@pytest.fixture
def _patch_loaders(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr("piilot_pack_compta_esms.exports.xlsx._base.run_in_thread", _passthrough)

    from piilot_pack_compta_esms.repositories import (
        affectation_repo,
        bilan_repo,
        controles_resultats_repo,
        cr_repo,
        crp_ligne_repo,
        document_repo,
        emprunts_repo,
        etablissement_repo,
        og_repo,
        provisions_repo,
        rcc_repo,
        rgpd_repo,
        suivi_affectation_repo,
        tf_repo,
        tper_ter_repo,
    )

    monkeypatch.setattr(
        document_repo,
        "exercice_lookup",
        lambda eid: {
            "id": EXERCICE_ID,
            "company_id": COMPANY,
            "og_id": OG_ID,
            "annee": 2025,
        },
    )
    monkeypatch.setattr(
        og_repo,
        "get_by_id",
        lambda og: {
            "id": OG_ID,
            "company_id": COMPANY,
            "finess_juridique": "750000123",
            "raison_sociale": "OG Test",
            "nature_juridique": "PRIVE_NON_LUCRATIF",
            "plan_comptable": "PC",
            "adresse": "1 rue test",
            "telephone": "0102030405",
            "email": "contact@test.fr",
            "representant_legal": "Jean Test",
            "representant_qualite": "Directeur",
            "cpom_date_effet": date(2024, 1, 1),
            "siret": None,
            "created_at": datetime.now(UTC),
            "updated_at": datetime.now(UTC),
        },
    )
    monkeypatch.setattr(
        etablissement_repo,
        "list_by_og",
        lambda og, typologie=None: [
            {
                "id": uuid4(),
                "finess_ets": "750100001",
                "raison_sociale": "EHPAD Test",
                "typologie": "ehpad",
                "capacite_autorisee": 80,
                "capacite_installee": 80,
                "capacite_financee": 80,
                "convention_collective": "CCN_51",
                "inclus_cpom": True,
                "soumis_equilibre": False,
            }
        ],
    )
    monkeypatch.setattr(cr_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(crp_ligne_repo, "list_by_cr", lambda c, **kw: [])
    monkeypatch.setattr(bilan_repo, "list_by_document", lambda d, **kw: [])
    monkeypatch.setattr(tf_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(affectation_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(suivi_affectation_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(provisions_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(emprunts_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(rcc_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(controles_resultats_repo, "list_by_document", lambda d, **kw: [])
    monkeypatch.setattr(rgpd_repo, "get_by_exercice", lambda e: None)
    monkeypatch.setattr(tper_ter_repo, "list_by_filter", lambda d, ets_id=None, **kw: [])

    # Patch ratios_service used inside partie_3
    from piilot_pack_compta_esms.services import ratios_service

    async def _fake_compute_ratios(*args, **kwargs):
        return ratios_service.RatiosResponse(
            document_id=DOC_ID,
            type_document="errd",
            ratios_errd=[],
            ratios_pgfp=[],
            summary_errd=ratios_service.RatiosSummary(nb_ok=0, nb_atypie=0, nb_na=0, total=0),
            computed_at=datetime.now(UTC),
        )

    monkeypatch.setattr(ratios_service, "compute_ratios", _fake_compute_ratios)


@pytest.mark.asyncio
async def test_build_rapport_docx_returns_bytes(_patch_loaders) -> None:
    """Smoke — le builder produit un DOCX valide et non-vide."""
    bytes_data = await rapport_builder.build_rapport_docx(DOC_ID, COMPANY, _doc("errd"))
    assert len(bytes_data) > 1000  # un DOCX vide fait ~3KB, ici on attend plus
    # Re-ouvre le doc pour vérifier qu'il est lisible
    doc = Document(BytesIO(bytes_data))
    text_all = " ".join(p.text for p in doc.paragraphs)
    assert "Partie 1" in text_all
    assert "Partie 2" in text_all
    assert "Partie 3" in text_all


@pytest.mark.asyncio
async def test_build_rapport_docx_metadata(_patch_loaders) -> None:
    """Métadonnées core_properties sont posées L5d §181-188."""
    bytes_data = await rapport_builder.build_rapport_docx(
        DOC_ID, COMPANY, _doc("errd"), user_label="Test User"
    )
    doc = Document(BytesIO(bytes_data))
    props = doc.core_properties
    assert props.author == "Test User"
    assert "ERRD" in (props.title or "")
    assert "2025" in (props.title or "")
    assert "R.314-223" in (props.subject or "")


@pytest.mark.asyncio
async def test_build_rapport_docx_header_footer(_patch_loaders) -> None:
    """Header + footer sont renseignés."""
    bytes_data = await rapport_builder.build_rapport_docx(DOC_ID, COMPANY, _doc("errd"))
    doc = Document(BytesIO(bytes_data))
    header_text = doc.sections[0].header.paragraphs[0].text
    footer_text = doc.sections[0].footer.paragraphs[0].text
    assert "ERRD" in header_text
    assert "Piilot" in footer_text


@pytest.mark.asyncio
async def test_build_rapport_docx_contains_t1_periode(_patch_loaders) -> None:
    """T1 ESMS périmètre contient l'établissement mocké."""
    bytes_data = await rapport_builder.build_rapport_docx(DOC_ID, COMPANY, _doc("errd"))
    doc = Document(BytesIO(bytes_data))
    # Cherche le finess dans une cellule de tableau
    found = False
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                if "750100001" in cell.text or "EHPAD Test" in cell.text:
                    found = True
                    break
    assert found, "ESMS du périmètre absent du rapport"


def test_derive_filename_with_annee() -> None:
    fname = rapport_builder.derive_filename(_doc(), {"annee": 2025})
    assert fname == "RAPPORT_ERRD_2025.docx"


# ---------------------------------------------------------------------------
# Service export_docx
# ---------------------------------------------------------------------------


@pytest.fixture
def patch_run_in_thread_service(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.exports_service.run_in_thread",
        _passthrough,
    )


@pytest.mark.asyncio
async def test_export_docx_404_cross_tenant(monkeypatch, patch_run_in_thread_service):
    other = _doc()
    other["company_id"] = uuid4()
    monkeypatch.setattr(exports_service.document_repo, "get_by_id", lambda d: other)
    with pytest.raises(NotFoundError):
        await exports_service.export_docx(DOC_ID, COMPANY, user_id=USER)


@pytest.mark.asyncio
async def test_export_docx_422_for_dm(monkeypatch, patch_run_in_thread_service):
    """v0.2 supporte EPRD + ERRD only — DM refusé 422."""
    monkeypatch.setattr(exports_service.document_repo, "get_by_id", lambda d: _doc("dm"))
    with pytest.raises(ValidationError) as exc:
        await exports_service.export_docx(DOC_ID, COMPANY, user_id=USER)
    assert exc.value.code == "docx_only_eprd_errd_v02"


@pytest.mark.asyncio
async def test_export_docx_422_for_ercp(monkeypatch, patch_run_in_thread_service):
    """ERCP secteur sanitaire M21 refusé v0.2."""
    monkeypatch.setattr(exports_service.document_repo, "get_by_id", lambda d: _doc("ercp"))
    with pytest.raises(ValidationError) as exc:
        await exports_service.export_docx(DOC_ID, COMPANY, user_id=USER)
    assert exc.value.code == "docx_only_eprd_errd_v02"


@pytest.mark.asyncio
async def test_export_docx_happy_uploads_and_persists(monkeypatch, patch_run_in_thread_service):
    """Happy path : build → S3 put_object → repo.create."""
    monkeypatch.setattr(exports_service.document_repo, "get_by_id", lambda d: _doc("errd"))
    monkeypatch.setattr(
        exports_service.document_repo,
        "exercice_lookup",
        lambda eid: {"id": eid, "company_id": COMPANY, "og_id": uuid4(), "annee": 2025},
    )

    async def _fake_build(*args, **kwargs):
        return b"FAKE DOCX BYTES"

    monkeypatch.setattr(exports_service.docx_builder, "build_rapport_docx", _fake_build)

    s3_calls = []

    async def _fake_put(key, body, content_type):
        s3_calls.append({"key": key, "size": len(body), "content_type": content_type})
        return f"plugins/compta_esms/{key}"

    monkeypatch.setattr(exports_service.storage, "put_object", _fake_put)
    monkeypatch.setattr(exports_service.exports_repo, "create", lambda **kw: _export_row())

    out = await exports_service.export_docx(DOC_ID, COMPANY, user_id=USER)
    assert out.type == "docx"
    assert len(s3_calls) == 1
    assert s3_calls[0]["content_type"] == exports_service.DOCX_CONTENT_TYPE


@pytest.mark.asyncio
async def test_export_docx_pipe_char_422(monkeypatch, patch_run_in_thread_service):
    """ValueError du builder → ValidationError(pipe_char_forbidden)."""
    monkeypatch.setattr(exports_service.document_repo, "get_by_id", lambda d: _doc("errd"))
    monkeypatch.setattr(
        exports_service.document_repo,
        "exercice_lookup",
        lambda eid: {"id": eid, "company_id": COMPANY, "og_id": uuid4(), "annee": 2025},
    )

    async def _fake_build(*args, **kwargs):
        raise ValueError("pipe_char_forbidden:caractère '|' interdit")

    monkeypatch.setattr(exports_service.docx_builder, "build_rapport_docx", _fake_build)

    with pytest.raises(ValidationError) as exc:
        await exports_service.export_docx(DOC_ID, COMPANY, user_id=USER)
    assert exc.value.code == "pipe_char_forbidden"
