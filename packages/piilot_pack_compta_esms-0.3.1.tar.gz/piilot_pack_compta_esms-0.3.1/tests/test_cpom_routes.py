"""HTTP smoke tests for CPOM routes — §BA v0.3 (L2 §22).

Goal : verify path resolution, request parsing, response shape and
permission gating. Service logic is exercised in
:mod:`tests.test_cpom_service`.
"""

from __future__ import annotations

from datetime import UTC, date, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_admin, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.cpom import (
    CpomEsmsLinkRead,
    CpomObjectifRead,
    CpomProgress,
    CpomRead,
)
from piilot_pack_compta_esms.routes import cpom as cpom_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import cpom_service
from piilot_pack_compta_esms.services.errors import (
    CrossCompanyError,
    NotFoundError,
    ValidationError,
)

COMPANY = uuid4()
USER = uuid4()
OG_ID = uuid4()
CPOM_ID = uuid4()
ETS_ID = uuid4()
OBJ_ID = uuid4()

ADMIN_AUTH = (USER, "admin", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


def _cpom_dict(**overrides):
    base = {
        "id": CPOM_ID,
        "company_id": COMPANY,
        "og_id": OG_ID,
        "numero": "CPOM-2024-001",
        "date_signature": date(2024, 1, 15),
        "date_effet": date(2024, 1, 1),
        "duree_annees": Decimal("5"),
        "date_fin_theorique": date(2029, 1, 1),
        "categorie": "EHPAD_IVTER",
        "cosignataires": ["ARS", "CD"],
        "est_proroge": None,
        "motif_prorogation": None,
        "libre_affectation_resultats_o_n": "OUI",
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


def _link_dict(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "cpom_id": CPOM_ID,
        "etablissement_id": ETS_ID,
        "inclus_dans_perimetre": "OUI",
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


def _obj_dict(**overrides):
    base = {
        "id": OBJ_ID,
        "company_id": COMPANY,
        "cpom_id": CPOM_ID,
        "intitule": "Test goal",
        "impact_eprd_o_n": "OUI",
        "description": None,
        "date_realisation_prevue": None,
        "statut": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def app():
    """Fresh app per test so slowapi state never leaks."""
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(cpom_routes.router_under_og, prefix="/plugins/compta_esms")
    app.include_router(cpom_routes.router_flat, prefix="/plugins/compta_esms")
    app.include_router(cpom_routes.router_objectifs_flat, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_admin] = lambda: ADMIN_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# --------------------------------------------------------------------
# CPOM CRUD
# --------------------------------------------------------------------


def test_list_cpoms_returns_200(client, monkeypatch):
    async def _fake(c, og):
        return [CpomRead.model_validate(_cpom_dict())]

    monkeypatch.setattr(cpom_service, "list_cpoms_by_og", _fake)
    r = client.get(f"/plugins/compta_esms/orgs/{OG_ID}/cpoms")
    assert r.status_code == 200, r.text
    body = r.json()
    assert isinstance(body, list)
    assert body[0]["id"] == str(CPOM_ID)


def test_list_cpoms_404_when_og_missing(client, monkeypatch):
    async def _fake(c, og):
        raise NotFoundError(f"OG {og} not found", code="og_not_found")

    monkeypatch.setattr(cpom_service, "list_cpoms_by_og", _fake)
    r = client.get(f"/plugins/compta_esms/orgs/{OG_ID}/cpoms")
    assert r.status_code == 404


def test_create_cpom_201(client, monkeypatch):
    async def _fake(c, og, payload):
        return CpomRead.model_validate(_cpom_dict(date_fin_theorique=date(2029, 1, 1)))

    monkeypatch.setattr(cpom_service, "create_cpom", _fake)
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/cpoms",
        json={
            "og_id": str(OG_ID),
            "date_signature": "2024-01-15",
            "date_effet": "2024-01-01",
            "duree_annees": "5",
            "categorie": "EHPAD_IVTER",
            "cosignataires": ["ARS", "CD"],
            "libre_affectation_resultats_o_n": "OUI",
        },
    )
    assert r.status_code == 201, r.text
    assert r.json()["date_fin_theorique"] == "2029-01-01"


def test_create_cpom_422_on_invalid_body(client):
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/cpoms",
        json={
            "og_id": str(OG_ID),
            "date_signature": "2024-01-15",
            "date_effet": "2024-01-01",
            "duree_annees": "0.5",  # < 1
            "categorie": "EHPAD_IVTER",
            "cosignataires": ["ARS"],
            "libre_affectation_resultats_o_n": "OUI",
        },
    )
    assert r.status_code == 422


def test_create_cpom_422_on_og_id_mismatch(client, monkeypatch):
    async def _fake(c, og, payload):
        raise ValidationError("body.og_id must match path", code="og_id_mismatch")

    monkeypatch.setattr(cpom_service, "create_cpom", _fake)
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/cpoms",
        json={
            "og_id": str(uuid4()),
            "date_signature": "2024-01-15",
            "date_effet": "2024-01-01",
            "duree_annees": "5",
            "categorie": "EHPAD_IVTER",
            "cosignataires": ["ARS"],
            "libre_affectation_resultats_o_n": "OUI",
        },
    )
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "og_id_mismatch"


def test_get_cpom_200(client, monkeypatch):
    async def _fake(c, cp):
        return CpomRead.model_validate(_cpom_dict())

    monkeypatch.setattr(cpom_service, "get_cpom", _fake)
    r = client.get(f"/plugins/compta_esms/cpoms/{CPOM_ID}")
    assert r.status_code == 200
    assert r.json()["id"] == str(CPOM_ID)


def test_get_cpom_404(client, monkeypatch):
    async def _fake(c, cp):
        raise NotFoundError("missing", code="cpom_not_found")

    monkeypatch.setattr(cpom_service, "get_cpom", _fake)
    r = client.get(f"/plugins/compta_esms/cpoms/{CPOM_ID}")
    assert r.status_code == 404


def test_get_cpom_403_when_cross_company(client, monkeypatch):
    async def _fake(c, cp):
        raise CrossCompanyError("nope", code="cpom_cross_company")

    monkeypatch.setattr(cpom_service, "get_cpom", _fake)
    r = client.get(f"/plugins/compta_esms/cpoms/{CPOM_ID}")
    assert r.status_code == 403


def test_patch_cpom_200(client, monkeypatch):
    async def _fake(c, cp, payload):
        return CpomRead.model_validate(_cpom_dict(numero="REV-001"))

    monkeypatch.setattr(cpom_service, "update_cpom", _fake)
    r = client.patch(
        f"/plugins/compta_esms/cpoms/{CPOM_ID}",
        json={"numero": "REV-001"},
    )
    assert r.status_code == 200
    assert r.json()["numero"] == "REV-001"


def test_patch_cpom_404(client, monkeypatch):
    async def _fake(c, cp, payload):
        raise NotFoundError("nope", code="cpom_not_found")

    monkeypatch.setattr(cpom_service, "update_cpom", _fake)
    r = client.patch(f"/plugins/compta_esms/cpoms/{CPOM_ID}", json={"numero": "X"})
    assert r.status_code == 404


def test_delete_cpom_204(client, monkeypatch):
    async def _fake(c, cp):
        return None

    monkeypatch.setattr(cpom_service, "delete_cpom", _fake)
    r = client.delete(f"/plugins/compta_esms/cpoms/{CPOM_ID}")
    assert r.status_code == 204


# --------------------------------------------------------------------
# Links
# --------------------------------------------------------------------


def test_list_links_200(client, monkeypatch):
    async def _fake(c, cp):
        return [CpomEsmsLinkRead.model_validate(_link_dict())]

    monkeypatch.setattr(cpom_service, "list_links_by_cpom", _fake)
    r = client.get(f"/plugins/compta_esms/cpoms/{CPOM_ID}/etablissements")
    assert r.status_code == 200
    assert len(r.json()) == 1


def test_bulk_link_200(client, monkeypatch):
    async def _fake(c, cp, items):
        return [
            CpomEsmsLinkRead.model_validate(
                _link_dict(
                    etablissement_id=it.etablissement_id,
                    inclus_dans_perimetre=it.inclus_dans_perimetre,
                )
            )
            for it in items
        ]

    monkeypatch.setattr(cpom_service, "bulk_link_etablissements", _fake)
    r = client.post(
        f"/plugins/compta_esms/cpoms/{CPOM_ID}/etablissements:bulk-link",
        json=[
            {"etablissement_id": str(ETS_ID), "inclus_dans_perimetre": "OUI"},
            {"etablissement_id": str(uuid4()), "inclus_dans_perimetre": "NON"},
        ],
    )
    assert r.status_code == 200, r.text
    assert len(r.json()) == 2


def test_bulk_link_422_on_cross_og(client, monkeypatch):
    async def _fake(c, cp, items):
        raise ValidationError("ETS does not belong to OG", code="ets_og_mismatch")

    monkeypatch.setattr(cpom_service, "bulk_link_etablissements", _fake)
    r = client.post(
        f"/plugins/compta_esms/cpoms/{CPOM_ID}/etablissements:bulk-link",
        json=[{"etablissement_id": str(ETS_ID), "inclus_dans_perimetre": "OUI"}],
    )
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "ets_og_mismatch"


def test_unlink_etablissement_204(client, monkeypatch):
    async def _fake(c, cp, ets):
        return None

    monkeypatch.setattr(cpom_service, "unlink_etablissement", _fake)
    r = client.delete(f"/plugins/compta_esms/cpoms/{CPOM_ID}/etablissements/{ETS_ID}")
    assert r.status_code == 204


# --------------------------------------------------------------------
# Objectifs
# --------------------------------------------------------------------


def test_list_objectifs_200(client, monkeypatch):
    async def _fake(c, cp):
        return [CpomObjectifRead.model_validate(_obj_dict())]

    monkeypatch.setattr(cpom_service, "list_objectifs", _fake)
    r = client.get(f"/plugins/compta_esms/cpoms/{CPOM_ID}/objectifs")
    assert r.status_code == 200
    assert len(r.json()) == 1


def test_create_objectif_201(client, monkeypatch):
    async def _fake(c, cp, payload):
        return CpomObjectifRead.model_validate(_obj_dict(intitule=payload.intitule))

    monkeypatch.setattr(cpom_service, "create_objectif", _fake)
    r = client.post(
        f"/plugins/compta_esms/cpoms/{CPOM_ID}/objectifs",
        json={"intitule": "Test goal 2", "impact_eprd_o_n": "OUI"},
    )
    assert r.status_code == 201, r.text
    assert r.json()["intitule"] == "Test goal 2"


def test_create_objectif_422_on_invalid_body(client):
    r = client.post(
        f"/plugins/compta_esms/cpoms/{CPOM_ID}/objectifs",
        json={"intitule": "", "impact_eprd_o_n": "OUI"},  # min_length 1
    )
    assert r.status_code == 422


def test_patch_objectif_200(client, monkeypatch):
    async def _fake(c, cp, oid, payload):
        return CpomObjectifRead.model_validate(_obj_dict(statut="REALISE"))

    monkeypatch.setattr(cpom_service, "update_objectif", _fake)
    r = client.patch(
        f"/plugins/compta_esms/cpoms/{CPOM_ID}/objectifs/{OBJ_ID}",
        json={"statut": "REALISE"},
    )
    assert r.status_code == 200
    assert r.json()["statut"] == "REALISE"


def test_patch_objectif_422_cpom_mismatch(client, monkeypatch):
    async def _fake(c, cp, oid, payload):
        raise ValidationError("objectif belongs to other CPOM", code="objectif_cpom_mismatch")

    monkeypatch.setattr(cpom_service, "update_objectif", _fake)
    r = client.patch(
        f"/plugins/compta_esms/cpoms/{CPOM_ID}/objectifs/{OBJ_ID}",
        json={"statut": "REALISE"},
    )
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "objectif_cpom_mismatch"


def test_delete_objectif_204(client, monkeypatch):
    async def _fake(c, cp, oid):
        return None

    monkeypatch.setattr(cpom_service, "delete_objectif", _fake)
    r = client.delete(f"/plugins/compta_esms/cpoms/{CPOM_ID}/objectifs/{OBJ_ID}")
    assert r.status_code == 204


# --------------------------------------------------------------------
# Progress
# --------------------------------------------------------------------


def test_get_progress_200(client, monkeypatch):
    async def _fake(c, cp):
        return CpomProgress(
            cpom_id=CPOM_ID,
            total=5,
            prevus=1,
            en_cours=2,
            realises=1,
            abandonnes=1,
            sans_statut=0,
            ratio_realise=0.2,
        )

    monkeypatch.setattr(cpom_service, "compute_progress", _fake)
    r = client.get(f"/plugins/compta_esms/cpoms/{CPOM_ID}/progress")
    assert r.status_code == 200
    body = r.json()
    assert body["total"] == 5
    assert body["ratio_realise"] == 0.2


# --------------------------------------------------------------------
# Permissions — mutations require admin (negative test)
# --------------------------------------------------------------------


def test_create_cpom_403_when_not_admin(app, client):
    """If require_admin is not satisfied, the route must refuse — we
    simulate by overriding with a 403-throwing dependency."""
    from fastapi import HTTPException

    def _deny():
        raise HTTPException(status_code=403, detail={"code": "forbidden", "message": "no"})

    app.dependency_overrides[require_admin] = _deny
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/cpoms",
        json={
            "og_id": str(OG_ID),
            "date_signature": "2024-01-15",
            "date_effet": "2024-01-01",
            "duree_annees": "5",
            "categorie": "EHPAD_IVTER",
            "cosignataires": ["ARS"],
            "libre_affectation_resultats_o_n": "OUI",
        },
    )
    assert r.status_code == 403
