"""Tests §Z — service controles_service (orchestration + transmit guard).

Couvre :

* list_controles 404 si doc inexistant
* list_controles applique filters statut/severite
* run_controles persiste + retourne summary
* compute_summary délègue au repo
* run_bloquants n'écrit PAS en DB (ne touche pas bulk_upsert)
* workflow_service.apply_transition transmit → KO bloquant → 422
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.services import controles_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
DOC_ID = uuid4()


def _doc():
    return {
        "id": DOC_ID,
        "company_id": COMPANY,
        "type_document": "errd",
        "statut": "brouillon",
        "exercice_id": uuid4(),
        "cadre_version": "#ERRDHA-2025-01#",
        "parent_id": None,
        "periode_observation_debut": None,
        "periode_observation_fin": None,
        "transmis_at": None,
        "executoire_at": None,
        "transmis_par_user_id": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.controles_service.run_in_thread",
        _passthrough,
    )


# ---------------------------------------------------------------------------
# list_controles
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_controles_doc_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(controles_service.document_repo, "get_by_id", lambda _: None)
    with pytest.raises(NotFoundError) as exc:
        await controles_service.list_controles(DOC_ID, COMPANY)
    assert exc.value.code == "document_not_found"


@pytest.mark.asyncio
async def test_list_controles_cross_tenant_404(monkeypatch, patch_run_in_thread):
    """Doc d'une autre company → 404 (pas 403, pour ne pas leak)."""
    other = _doc()
    other["company_id"] = uuid4()
    monkeypatch.setattr(controles_service.document_repo, "get_by_id", lambda _: other)
    with pytest.raises(NotFoundError):
        await controles_service.list_controles(DOC_ID, COMPANY)


@pytest.mark.asyncio
async def test_list_controles_filters_propagated(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(controles_service.document_repo, "get_by_id", lambda _: _doc())
    captured = {}

    def _list(doc_id, *, statut, severite):
        captured["doc"] = doc_id
        captured["statut"] = statut
        captured["severite"] = severite
        return []

    monkeypatch.setattr(controles_service.controles_resultats_repo, "list_by_document", _list)

    await controles_service.list_controles(DOC_ID, COMPANY, statut="ko", severite="error")
    assert captured["statut"] == "ko"
    assert captured["severite"] == "error"


# ---------------------------------------------------------------------------
# run_controles
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_controles_persists_and_returns_summary(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(controles_service.document_repo, "get_by_id", lambda _: _doc())

    async def _no_applicable(*args, **kwargs):
        return set()

    monkeypatch.setattr(controles_service, "_load_applicable_codes", _no_applicable)

    upsert_called: list = []
    monkeypatch.setattr(
        controles_service.controles_resultats_repo,
        "bulk_upsert",
        lambda co, doc, items: (upsert_called.extend(items), [])[1],
    )
    monkeypatch.setattr(
        controles_service.controles_resultats_repo,
        "compute_summary_for_doc",
        lambda _: {
            "total": 0,
            "ok": 0,
            "ko": 0,
            "na": 0,
            "ko_error": 0,
            "ko_warning": 0,
            "ko_bloquant": 0,
        },
    )

    out = await controles_service.run_controles(DOC_ID, COMPANY)
    assert out.nb_codes_evalues == 0
    assert out.summary.total == 0


@pytest.mark.asyncio
async def test_run_controles_with_codes_filter(monkeypatch, patch_run_in_thread):
    """codes_filter limite l'évaluation aux codes demandés."""
    monkeypatch.setattr(controles_service.document_repo, "get_by_id", lambda _: _doc())

    async def _applicable(_type):
        return {"C-001", "C-002", "C-003"}

    monkeypatch.setattr(controles_service, "_load_applicable_codes", _applicable)

    monkeypatch.setattr(
        controles_service.controles_resultats_repo,
        "bulk_upsert",
        lambda co, doc, items: items,
    )
    monkeypatch.setattr(
        controles_service.controles_resultats_repo,
        "compute_summary_for_doc",
        lambda _: {
            "total": 1,
            "ok": 0,
            "ko": 0,
            "na": 1,
            "ko_error": 0,
            "ko_warning": 0,
            "ko_bloquant": 0,
        },
    )

    out = await controles_service.run_controles(DOC_ID, COMPANY, codes_filter=["C-001"])
    # Seul C-001 a tourné (intersection avec applicable + registry).
    assert out.nb_codes_evalues == 1


# ---------------------------------------------------------------------------
# compute_summary
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_compute_summary_delegates(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(controles_service.document_repo, "get_by_id", lambda _: _doc())
    monkeypatch.setattr(
        controles_service.controles_resultats_repo,
        "compute_summary_for_doc",
        lambda _: {
            "total": 117,
            "ok": 10,
            "ko": 2,
            "na": 105,
            "ko_error": 2,
            "ko_warning": 0,
            "ko_bloquant": 2,
        },
    )
    s = await controles_service.compute_summary(DOC_ID, COMPANY)
    assert s.total == 117
    assert s.ko_bloquant == 2


# ---------------------------------------------------------------------------
# run_bloquants — n'écrit PAS en DB
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_bloquants_does_not_persist(monkeypatch, patch_run_in_thread):
    """run_bloquants évalue les 3 bloquants sans toucher bulk_upsert."""
    monkeypatch.setattr(controles_service.document_repo, "get_by_id", lambda _: _doc())
    bulk_upsert_calls = []
    monkeypatch.setattr(
        controles_service.controles_resultats_repo,
        "bulk_upsert",
        lambda *args, **kwargs: bulk_upsert_calls.append(1),
    )

    out = await controles_service.run_bloquants(DOC_ID, COMPANY)
    assert isinstance(out, list)
    # Pas d'écriture DB sur le path bloquants.
    assert bulk_upsert_calls == []
