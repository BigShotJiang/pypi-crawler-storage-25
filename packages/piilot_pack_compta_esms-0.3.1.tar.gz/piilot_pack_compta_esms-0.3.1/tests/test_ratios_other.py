"""Tests §AA — ratios équilibres + rotation + autres + patrimoine.

Couvre ~16 cas représentatifs sur les 12 ratios restants
(non-endettement), en mode tableau paramétré.
"""

from __future__ import annotations

from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.ratios import (
    r_autres,
    r_equilibres,
    r_patrimoine,
    r_rotation,
)
from piilot_pack_compta_esms.ratios._base import RatioContext

COMPANY = uuid4()
DOC_ID = uuid4()


@pytest.fixture(autouse=True)
def _patch_lazy_loaders(monkeypatch):
    """Les tests fournissent les caches via ctx.custom — stub loaders."""

    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr("piilot_pack_compta_esms.ratios._base.run_in_thread", _passthrough)

    from piilot_pack_compta_esms.repositories import bilan_repo, cr_repo, emprunts_repo

    monkeypatch.setattr(bilan_repo, "list_by_document", lambda d, **kw: [])
    monkeypatch.setattr(cr_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(emprunts_repo, "list_by_document", lambda d: [])


def _ctx(**custom):
    ctx = RatioContext(
        document_id=DOC_ID,
        company_id=COMPANY,
        document={"id": DOC_ID, "company_id": COMPANY, "type_document": "errd"},
    )
    ctx.custom.update(custom)
    return ctx


def _bilan(**overrides):
    base = {}
    for compte, montants in overrides.items():
        base[compte] = {
            "brut_n": Decimal(montants.get("brut_n", 0)),
            "amort_n": Decimal(montants.get("amort_n", 0)),
            "net_n": Decimal(montants.get("net_n", 0)),
            "net_n1": Decimal(montants.get("net_n1", 0)),
            "type_actif_passif": montants.get("type"),
        }
    return base


def _crp(**overrides):
    base = {}
    for compte, montants in overrides.items():
        base[compte] = {
            "charges_realise": Decimal(montants.get("charges_realise", 0)),
            "produits_realise": Decimal(montants.get("produits_realise", 0)),
            "charges_prevu": Decimal(montants.get("charges_prevu", 0)),
            "produits_prevu": Decimal(montants.get("produits_prevu", 0)),
        }
    return base


# ---------------------------------------------------------------------------
# Patrimoine 2.1
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_r_2_1_ok_calcul() -> None:
    """Vétusté = amort 28 / brut 21 × 100."""
    ctx = _ctx(
        bilan_index=_bilan(
            **{
                "28": {"amort_n": "200000"},
                "21": {"brut_n": "500000"},
            }
        )
    )
    r = await r_patrimoine.r_2_1(ctx)
    assert r.verdict == "ok"
    assert r.valeur == Decimal("40")  # 200000 * 100 / 500000


@pytest.mark.asyncio
async def test_r_2_1_na_brut_zero() -> None:
    ctx = _ctx(bilan_index={})
    r = await r_patrimoine.r_2_1(ctx)
    assert r.verdict == "na"


# ---------------------------------------------------------------------------
# Équilibres 3.1.a/b/c + 3.2
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_r_3_1_a_na_no_charges() -> None:
    ctx = _ctx(bilan_index={}, crp_by_account={})
    r = await r_equilibres.r_3_1_a(ctx)
    assert r.verdict == "na"


@pytest.mark.asyncio
async def test_r_3_1_a_computes_days() -> None:
    """FRNG ~ c/1 net (capitaux+dettes) - c/2 net (immo)."""
    ctx = _ctx(
        bilan_index=_bilan(
            **{
                "10": {"net_n": "500000"},  # capitaux (commence par 1)
                "21": {"net_n": "100000"},  # immo (commence par 2)
            }
        ),
        crp_by_account=_crp(**{"60": {"charges_realise": "365000"}}),
    )
    r = await r_equilibres.r_3_1_a(ctx)
    # FRNG = c/1 net - c/2 net = 500000 - 100000 = 400000
    # Charges décaissables = 365000 (pas de c/68/675/689)
    # Jours = 400000 * 365 / 365000 = 400
    assert r.verdict == "ok"
    assert r.valeur == Decimal("400")


@pytest.mark.asyncio
async def test_r_3_1_b_bfr_jours() -> None:
    ctx = _ctx(
        bilan_index=_bilan(
            **{
                "3": {"net_n": "50000"},  # stocks
                "41": {"net_n": "100000"},  # créances
                "401": {"net_n": "30000"},  # dettes fournisseurs
            }
        ),
        crp_by_account=_crp(**{"60": {"charges_realise": "365000"}}),
    )
    # BFR = 50000 + 100000 - 30000 = 120000
    r = await r_equilibres.r_3_1_b(ctx)
    assert r.verdict == "ok"
    assert r.valeur == Decimal("120")


@pytest.mark.asyncio
async def test_r_3_1_c_tresorerie_jours() -> None:
    ctx = _ctx(
        bilan_index=_bilan(
            **{
                "1": {"net_n": "500000"},
                "2": {"net_n": "100000"},
                "3": {"net_n": "50000"},
                "41": {"net_n": "100000"},
                "401": {"net_n": "30000"},
            }
        ),
        crp_by_account=_crp(**{"60": {"charges_realise": "365000"}}),
    )
    # FRNG=400000, BFR=120000, Trésorerie=280000, jours = 280
    r = await r_equilibres.r_3_1_c(ctx)
    assert r.verdict == "ok"
    assert r.valeur == Decimal("280")


@pytest.mark.asyncio
async def test_r_3_2_reserve_couverture_bfr() -> None:
    ctx = _ctx(
        bilan_index=_bilan(
            **{
                "141": {"net_n": "50000"},
                "10685": {"net_n": "30000"},
            }
        ),
        crp_by_account=_crp(**{"60": {"charges_realise": "365000"}}),
    )
    # Réserve = 80000, jours = 80
    r = await r_equilibres.r_3_2(ctx)
    assert r.verdict == "ok"
    assert r.valeur == Decimal("80")


# ---------------------------------------------------------------------------
# Rotation 4.1/4.2/4.3/4.4
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_r_4_1_stocks_in_range_ok() -> None:
    """Stocks 15 jours → in range [10-20]."""
    ctx = _ctx(
        bilan_index=_bilan(**{"3": {"net_n": "15000"}}),
        crp_by_account=_crp(**{"60": {"charges_realise": "365000"}}),
    )
    # 15000 * 365 / 365000 = 15
    r = await r_rotation.r_4_1(ctx)
    assert r.verdict == "ok"
    assert r.valeur == Decimal("15")


@pytest.mark.asyncio
async def test_r_4_1_stocks_too_high_atypie() -> None:
    """Stocks > 20 jours → atypie."""
    ctx = _ctx(
        bilan_index=_bilan(**{"3": {"net_n": "30000"}}),
        crp_by_account=_crp(**{"60": {"charges_realise": "365000"}}),
    )
    r = await r_rotation.r_4_1(ctx)
    assert r.verdict == "atypie"


@pytest.mark.asyncio
async def test_r_4_2_creances_ok_below_30() -> None:
    """Créances 20 jours < 30 → ok."""
    ctx = _ctx(
        bilan_index=_bilan(**{"41": {"net_n": "20000"}}),
        crp_by_account=_crp(**{"70": {"produits_realise": "365000"}}),
    )
    r = await r_rotation.r_4_2(ctx)
    assert r.verdict == "ok"


@pytest.mark.asyncio
async def test_r_4_3_dettes_fournisseurs_atypie() -> None:
    """Dettes fournisseurs > 45 jours → atypie."""
    ctx = _ctx(
        bilan_index=_bilan(**{"401": {"net_n": "60000"}}),
        crp_by_account=_crp(**{"60": {"charges_realise": "365000"}}),
    )
    # 60000 * 365 / 365000 = 60 > 45
    r = await r_rotation.r_4_3(ctx)
    assert r.verdict == "atypie"


@pytest.mark.asyncio
async def test_r_4_4_dettes_sociales_no_seuil() -> None:
    """Dettes sociales — indicatif, ok dès que calculable."""
    ctx = _ctx(
        bilan_index=_bilan(**{"43": {"net_n": "30000"}, "44": {"net_n": "20000"}}),
        crp_by_account=_crp(**{"60": {"charges_realise": "365000"}}),
    )
    r = await r_rotation.r_4_4(ctx)
    assert r.verdict == "ok"
    assert r.valeur == Decimal("50")


# ---------------------------------------------------------------------------
# Autres 5.1/5.2/5.3
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_r_5_1_taux_caf_in_range() -> None:
    """Taux CAF 7% → ok (range 5-10%)."""
    ctx = _ctx(
        bilan_index={},
        crp_by_account=_crp(
            **{
                "70": {"produits_realise": "1000000"},
                "60": {"charges_realise": "930000"},
            }
        ),
    )
    # CAF = 1000000 - 930000 = 70000
    # Taux = 70000 * 100 / 1000000 = 7
    r = await r_autres.r_5_1(ctx)
    assert r.verdict == "ok"
    assert r.valeur == Decimal("7")


@pytest.mark.asyncio
async def test_r_5_1_taux_caf_too_low_atypie() -> None:
    """Taux CAF 2% → atypie."""
    ctx = _ctx(
        bilan_index={},
        crp_by_account=_crp(
            **{
                "70": {"produits_realise": "1000000"},
                "60": {"charges_realise": "980000"},
            }
        ),
    )
    r = await r_autres.r_5_1(ctx)
    assert r.verdict == "atypie"


@pytest.mark.asyncio
async def test_r_5_2_reserve_compensation_indicatif() -> None:
    """Réserve indicatif."""
    ctx = _ctx(
        bilan_index=_bilan(**{"10686": {"net_n": "50000"}}),
        crp_by_account=_crp(**{"70": {"produits_realise": "1000000"}}),
    )
    r = await r_autres.r_5_2(ctx)
    assert r.verdict == "ok"
    assert r.valeur == Decimal("5")


@pytest.mark.asyncio
async def test_r_5_3_marge_brute_indicatif() -> None:
    """Taux marge brute indicatif."""
    ctx = _ctx(
        bilan_index={},
        crp_by_account=_crp(
            **{
                "70": {"produits_realise": "1000000"},
                "60": {"charges_realise": "500000"},
                "65": {"charges_realise": "100000"},
                "7": {"produits_realise": "1000000"},  # total produits
            }
        ),
    )
    # produits_op = c/70..75 = 1000000 (uniquement c/70 ici)
    # charges_op = c/60..65 = 500000 + 100000 = 600000
    # marge = 400000, taux = 40%
    r = await r_autres.r_5_3(ctx)
    assert r.verdict == "ok"
    # Note: c/7 prefix capte aussi c/70 dans get_total_produits
    # → produits_total via get_total_produits = somme tous comptes commençant par 7
    assert r.valeur is not None
