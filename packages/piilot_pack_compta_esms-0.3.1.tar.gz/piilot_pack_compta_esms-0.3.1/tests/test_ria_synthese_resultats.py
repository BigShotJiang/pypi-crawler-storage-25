"""Tests §W D-065 — RIA Synthèse résultats (KB23 §3.3 + KB25 §14).

Couvre :

Service ``ria_service.compute_synthese_resultats`` :
* 404 ``document_not_found`` (doc inexistant)
* 404 ``document_not_found`` (cross-tenant — RIA d'une autre company)
* 409 ``not_a_ria`` (doc de type EPRD)
* 409 ``ria_orphan`` (RIA avec parent_id NULL, data corruption defensive)
* Cas standard : 3 CRs RIA matchés au parent EPRD + ERRD N-1 → tous les
  champs remplis, TOTAL correct
* Pas d'ERRD N-1 → ``errd_n_minus_1_id=None`` et tous les
  ``resultat_comptable_n_minus_1=None``
* CR RIA sans pendant côté parent EPRD → ``eprd_executoire_n=None`` pour
  cette ligne uniquement
* CR RIA sans pendant côté ERRD N-1 → ``resultat_comptable_n_minus_1=None``
  pour cette ligne, mais TOTAL N-1 reste la Σ des lignes matchées
* Calcul Résultat = produits - charges
* Précision Decimal préservée (pas d'arrondi à 2 décimales côté service)

Route ``GET /documents/{ria_id}/synthese-resultats`` :
* 200 OK avec body conforme
* 404 propagé depuis ``NotFoundError``
* 409 propagé depuis ``ConflictError``
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import _limiter as limiter_module
from piilot_pack_compta_esms.routes import ria as ria_routes
from piilot_pack_compta_esms.services import ria_service
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

COMPANY = uuid4()
USER = uuid4()
RIA_ID = uuid4()
PARENT_EPRD = uuid4()
ERRD_N_MINUS_1 = uuid4()
ETS_A = uuid4()
ETS_B = uuid4()
CR_RIA_CRPP = uuid4()
CR_RIA_CRPA = uuid4()
CR_RIA_CRP_SF = uuid4()
CR_PARENT_CRPP = uuid4()
CR_PARENT_CRPA = uuid4()
CR_PARENT_CRP_SF = uuid4()
CR_ERRD_CRPP = uuid4()
CR_ERRD_CRPA = uuid4()
USER_AUTH = (USER, "user", COMPANY)


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.ria_service.run_in_thread",
        _passthrough,
    )


def _make_doc_row(
    *,
    type_document: str = "ria",
    parent_id: UUID | None = PARENT_EPRD,
    company_id: UUID = COMPANY,
    doc_id: UUID = RIA_ID,
) -> dict[str, Any]:
    return {
        "id": doc_id,
        "company_id": company_id,
        "exercice_id": uuid4(),
        "type_document": type_document,
        "cadre_version": "#RIAHA-2026-01#",
        "parent_id": parent_id,
        "statut": "brouillon",
    }


def _make_cr_row(
    *,
    cr_id: UUID,
    cr_type: str,
    etablissement_id: UUID | None,
    denomination: str,
) -> dict[str, Any]:
    return {
        "id": cr_id,
        "cr_type": cr_type,
        "cr_variante": "non_soumis_equil",
        "denomination": denomination,
        "etablissement_id": etablissement_id,
    }


def _setup_full_scenario(monkeypatch):
    """3 CRs RIA matchés 1:1 au parent EPRD + ERRD N-1.

    Périmètre :
    * CRPP / ETS_A
    * CRPA / ETS_B
    * CRP_SF / no ETS  → seulement parent EPRD (pas dans ERRD)
    """
    monkeypatch.setattr(ria_service.document_repo, "get_by_id", lambda _: _make_doc_row())

    ria_crs = [
        _make_cr_row(
            cr_id=CR_RIA_CRPP, cr_type="CRPP", etablissement_id=ETS_A, denomination="CRPP - 2026"
        ),
        _make_cr_row(
            cr_id=CR_RIA_CRPA, cr_type="CRPA", etablissement_id=ETS_B, denomination="CRPA 1"
        ),
        _make_cr_row(
            cr_id=CR_RIA_CRP_SF,
            cr_type="CRP_SF",
            etablissement_id=None,
            denomination="Section financière",
        ),
    ]
    parent_crs = [
        {
            **_make_cr_row(
                cr_id=CR_PARENT_CRPP,
                cr_type="CRPP",
                etablissement_id=ETS_A,
                denomination="CRPP - 2026",
            )
        },
        {
            **_make_cr_row(
                cr_id=CR_PARENT_CRPA, cr_type="CRPA", etablissement_id=ETS_B, denomination="CRPA 1"
            )
        },
        {
            **_make_cr_row(
                cr_id=CR_PARENT_CRP_SF,
                cr_type="CRP_SF",
                etablissement_id=None,
                denomination="Section financière",
            )
        },
    ]
    errd_crs = [
        _make_cr_row(
            cr_id=CR_ERRD_CRPP, cr_type="CRPP", etablissement_id=ETS_A, denomination="CRPP - 2025"
        ),
        _make_cr_row(
            cr_id=CR_ERRD_CRPA, cr_type="CRPA", etablissement_id=ETS_B, denomination="CRPA 1"
        ),
    ]

    def _list_by_document(doc_id):
        if doc_id == RIA_ID:
            return ria_crs
        if doc_id == PARENT_EPRD:
            return parent_crs
        if doc_id == ERRD_N_MINUS_1:
            return errd_crs
        return []

    monkeypatch.setattr(ria_service.cr_repo, "list_by_document", _list_by_document)

    def _aggregate_charges_produits_by_cr(doc_id):
        if doc_id == RIA_ID:
            return {
                CR_RIA_CRPP: {"charges": Decimal("1000.00"), "produits": Decimal("1200.00")},
                CR_RIA_CRPA: {"charges": Decimal("500.00"), "produits": Decimal("550.00")},
                CR_RIA_CRP_SF: {"charges": Decimal("100.00"), "produits": Decimal("80.00")},
            }
        if doc_id == PARENT_EPRD:
            return {
                CR_PARENT_CRPP: {"charges": Decimal("900.00"), "produits": Decimal("1100.00")},
                CR_PARENT_CRPA: {"charges": Decimal("450.00"), "produits": Decimal("500.00")},
                CR_PARENT_CRP_SF: {"charges": Decimal("90.00"), "produits": Decimal("70.00")},
            }
        return {}

    monkeypatch.setattr(
        ria_service.cr_repo,
        "aggregate_charges_produits_by_cr",
        _aggregate_charges_produits_by_cr,
    )

    def _aggregate_realise_by_cr(doc_id):
        if doc_id == ERRD_N_MINUS_1:
            return {
                CR_ERRD_CRPP: {"charges": Decimal("850.00"), "produits": Decimal("1050.00")},
                CR_ERRD_CRPA: {"charges": Decimal("420.00"), "produits": Decimal("470.00")},
            }
        return {}

    monkeypatch.setattr(ria_service.cr_repo, "aggregate_realise_by_cr", _aggregate_realise_by_cr)

    monkeypatch.setattr(
        ria_service.document_repo,
        "find_errd_n_minus_1_for_ria",
        lambda _ria_id, _company_id: {
            "id": ERRD_N_MINUS_1,
            "exercice_id": uuid4(),
            "statut": "affectation_definie",
        },
    )


# ---------------------------------------------------------------------------
# Service — erreurs
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_404_document_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(ria_service.document_repo, "get_by_id", lambda _: None)
    with pytest.raises(NotFoundError) as exc:
        await ria_service.compute_synthese_resultats(ria_id=RIA_ID, company_id=COMPANY)
    assert exc.value.code == "document_not_found"


@pytest.mark.asyncio
async def test_404_cross_tenant(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        ria_service.document_repo,
        "get_by_id",
        lambda _: _make_doc_row(company_id=uuid4()),
    )
    with pytest.raises(NotFoundError) as exc:
        await ria_service.compute_synthese_resultats(ria_id=RIA_ID, company_id=COMPANY)
    assert exc.value.code == "document_not_found"


@pytest.mark.asyncio
async def test_409_not_a_ria(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        ria_service.document_repo,
        "get_by_id",
        lambda _: _make_doc_row(type_document="eprd"),
    )
    with pytest.raises(ConflictError) as exc:
        await ria_service.compute_synthese_resultats(ria_id=RIA_ID, company_id=COMPANY)
    assert exc.value.code == "not_a_ria"


@pytest.mark.asyncio
async def test_409_ria_orphan(monkeypatch, patch_run_in_thread):
    """RIA avec parent_id NULL (data corruption defensive)."""
    monkeypatch.setattr(
        ria_service.document_repo,
        "get_by_id",
        lambda _: _make_doc_row(parent_id=None),
    )
    with pytest.raises(ConflictError) as exc:
        await ria_service.compute_synthese_resultats(ria_id=RIA_ID, company_id=COMPANY)
    assert exc.value.code == "ria_orphan"


# ---------------------------------------------------------------------------
# Service — cas standard 3 CRs + ERRD N-1
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_full_scenario_3_crs_with_errd(monkeypatch, patch_run_in_thread):
    """3 CRs RIA + parent EPRD complet + ERRD N-1 sur 2 des 3 CRs."""
    _setup_full_scenario(monkeypatch)

    out = await ria_service.compute_synthese_resultats(ria_id=RIA_ID, company_id=COMPANY)

    assert out.ria_id == RIA_ID
    assert out.parent_eprd_id == PARENT_EPRD
    assert out.errd_n_minus_1_id == ERRD_N_MINUS_1
    assert len(out.rows) == 3

    # Ligne CRPP / ETS_A — match parent + ERRD N-1
    crpp = next(r for r in out.rows if r.cr_id == CR_RIA_CRPP)
    assert crpp.cr_type == "CRPP"
    assert crpp.etablissement_id == ETS_A
    assert crpp.projection_actualisee_n.charges == Decimal("1000.00")
    assert crpp.projection_actualisee_n.produits == Decimal("1200.00")
    assert crpp.projection_actualisee_n.resultat == Decimal("200.00")
    assert crpp.eprd_executoire_n is not None
    assert crpp.eprd_executoire_n.charges == Decimal("900.00")
    assert crpp.eprd_executoire_n.produits == Decimal("1100.00")
    assert crpp.eprd_executoire_n.resultat == Decimal("200.00")
    # ERRD N-1 résultat = 1050 - 850 = 200
    assert crpp.resultat_comptable_n_minus_1 == Decimal("200.00")

    # Ligne CRPA / ETS_B
    crpa = next(r for r in out.rows if r.cr_id == CR_RIA_CRPA)
    assert crpa.projection_actualisee_n.resultat == Decimal("50.00")
    assert crpa.eprd_executoire_n is not None
    assert crpa.eprd_executoire_n.resultat == Decimal("50.00")
    assert crpa.resultat_comptable_n_minus_1 == Decimal("50.00")

    # Ligne CRP_SF — pas dans l'ERRD N-1
    crp_sf = next(r for r in out.rows if r.cr_id == CR_RIA_CRP_SF)
    assert crp_sf.etablissement_id is None
    assert crp_sf.projection_actualisee_n.resultat == Decimal("-20.00")
    assert crp_sf.eprd_executoire_n is not None
    assert crp_sf.resultat_comptable_n_minus_1 is None

    # TOTAL
    assert out.total.projection_actualisee_n.charges == Decimal("1600.00")
    assert out.total.projection_actualisee_n.produits == Decimal("1830.00")
    assert out.total.projection_actualisee_n.resultat == Decimal("230.00")
    assert out.total.eprd_executoire_n is not None
    assert out.total.eprd_executoire_n.resultat == Decimal("230.00")
    # 200 + 50 = 250 (CRP_SF non comptée car non-évaluable)
    assert out.total.resultat_comptable_n_minus_1 == Decimal("250.00")


# ---------------------------------------------------------------------------
# Service — pas d'ERRD N-1
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_no_errd_n_minus_1(monkeypatch, patch_run_in_thread):
    """Pas d'ERRD N-1 finalisé — 1ère année OG → colonne N-1 = None partout."""
    _setup_full_scenario(monkeypatch)
    # Override : pas d'ERRD trouvé
    monkeypatch.setattr(
        ria_service.document_repo,
        "find_errd_n_minus_1_for_ria",
        lambda _ria_id, _company_id: None,
    )

    out = await ria_service.compute_synthese_resultats(ria_id=RIA_ID, company_id=COMPANY)

    assert out.errd_n_minus_1_id is None
    assert all(r.resultat_comptable_n_minus_1 is None for r in out.rows)
    assert out.total.resultat_comptable_n_minus_1 is None
    # Mais le reste fonctionne
    assert out.total.projection_actualisee_n.resultat == Decimal("230.00")
    assert out.total.eprd_executoire_n is not None


# ---------------------------------------------------------------------------
# Service — CR RIA sans pendant parent
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_ria_cr_without_parent_match(monkeypatch, patch_run_in_thread):
    """RIA avec 1 CR ajouté en cours d'exercice (pas dans le parent EPRD).

    Cas dégénéré théorique — §V garantit l'héritage du périmètre, mais
    si la balance est cassée, on retourne ``eprd_executoire_n=None``
    pour cette ligne plutôt que de crasher.
    """
    monkeypatch.setattr(ria_service.document_repo, "get_by_id", lambda _: _make_doc_row())

    extra_cr_id = uuid4()
    ria_crs = [
        _make_cr_row(
            cr_id=CR_RIA_CRPP, cr_type="CRPP", etablissement_id=ETS_A, denomination="CRPP"
        ),
        _make_cr_row(
            cr_id=extra_cr_id, cr_type="CRPA", etablissement_id=ETS_B, denomination="CRPA orphelin"
        ),
    ]
    # Parent n'a que le CRPP
    parent_crs = [
        _make_cr_row(
            cr_id=CR_PARENT_CRPP, cr_type="CRPP", etablissement_id=ETS_A, denomination="CRPP"
        ),
    ]

    def _list_by_document(doc_id):
        return ria_crs if doc_id == RIA_ID else parent_crs if doc_id == PARENT_EPRD else []

    monkeypatch.setattr(ria_service.cr_repo, "list_by_document", _list_by_document)

    def _aggregate(doc_id):
        if doc_id == RIA_ID:
            return {
                CR_RIA_CRPP: {"charges": Decimal("100"), "produits": Decimal("110")},
                extra_cr_id: {"charges": Decimal("50"), "produits": Decimal("60")},
            }
        if doc_id == PARENT_EPRD:
            return {CR_PARENT_CRPP: {"charges": Decimal("90"), "produits": Decimal("105")}}
        return {}

    monkeypatch.setattr(ria_service.cr_repo, "aggregate_charges_produits_by_cr", _aggregate)
    monkeypatch.setattr(ria_service.cr_repo, "aggregate_realise_by_cr", lambda _: {})
    monkeypatch.setattr(
        ria_service.document_repo,
        "find_errd_n_minus_1_for_ria",
        lambda _ria, _co: None,
    )

    out = await ria_service.compute_synthese_resultats(ria_id=RIA_ID, company_id=COMPANY)

    crpp = next(r for r in out.rows if r.cr_id == CR_RIA_CRPP)
    assert crpp.eprd_executoire_n is not None

    extra = next(r for r in out.rows if r.cr_id == extra_cr_id)
    assert extra.eprd_executoire_n is None  # pas de pendant côté parent

    # TOTAL n'agrège que la cellule EPRD trouvée
    assert out.total.eprd_executoire_n is not None
    assert out.total.eprd_executoire_n.charges == Decimal("90")
    assert out.total.eprd_executoire_n.produits == Decimal("105")


# ---------------------------------------------------------------------------
# Service — précision Decimal
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_decimal_precision_preserved(monkeypatch, patch_run_in_thread):
    """Σ de montants à 2 décimales reste à 2 décimales sans arrondi parasite."""
    monkeypatch.setattr(ria_service.document_repo, "get_by_id", lambda _: _make_doc_row())
    monkeypatch.setattr(
        ria_service.cr_repo,
        "list_by_document",
        lambda d: (
            [
                _make_cr_row(
                    cr_id=CR_RIA_CRPP, cr_type="CRPP", etablissement_id=ETS_A, denomination="CRPP"
                )
            ]
            if d == RIA_ID
            else []
        ),
    )
    monkeypatch.setattr(
        ria_service.cr_repo,
        "aggregate_charges_produits_by_cr",
        lambda d: (
            {CR_RIA_CRPP: {"charges": Decimal("123456.78"), "produits": Decimal("987654.32")}}
            if d == RIA_ID
            else {}
        ),
    )
    monkeypatch.setattr(ria_service.cr_repo, "aggregate_realise_by_cr", lambda _: {})
    monkeypatch.setattr(
        ria_service.document_repo, "find_errd_n_minus_1_for_ria", lambda _r, _c: None
    )

    out = await ria_service.compute_synthese_resultats(ria_id=RIA_ID, company_id=COMPANY)
    assert out.rows[0].projection_actualisee_n.resultat == Decimal("864197.54")


# ---------------------------------------------------------------------------
# Route — 200 / 404 / 409
# ---------------------------------------------------------------------------


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter_module.limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(ria_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    return app


def test_route_synthese_200(app, monkeypatch):
    from piilot_pack_compta_esms.models.ria import (
        SyntheseResultatsCell,
        SyntheseResultatsResponse,
        SyntheseResultatsRow,
        SyntheseResultatsTotal,
    )

    cell = SyntheseResultatsCell(
        charges=Decimal("100"), produits=Decimal("120"), resultat=Decimal("20")
    )

    async def _fake(*, ria_id, company_id):
        return SyntheseResultatsResponse(
            ria_id=ria_id,
            parent_eprd_id=PARENT_EPRD,
            errd_n_minus_1_id=None,
            rows=[
                SyntheseResultatsRow(
                    cr_id=CR_RIA_CRPP,
                    cr_type="CRPP",
                    denomination="CRPP",
                    etablissement_id=ETS_A,
                    resultat_comptable_n_minus_1=None,
                    eprd_executoire_n=cell,
                    projection_actualisee_n=cell,
                ),
            ],
            total=SyntheseResultatsTotal(
                resultat_comptable_n_minus_1=None,
                eprd_executoire_n=cell,
                projection_actualisee_n=cell,
            ),
        )

    monkeypatch.setattr(ria_service, "compute_synthese_resultats", _fake)
    client = TestClient(app)
    r = client.get(f"/plugins/compta_esms/documents/{RIA_ID}/synthese-resultats")
    assert r.status_code == 200
    body = r.json()
    assert body["ria_id"] == str(RIA_ID)
    assert body["parent_eprd_id"] == str(PARENT_EPRD)
    assert body["errd_n_minus_1_id"] is None
    assert len(body["rows"]) == 1
    assert body["total"]["projection_actualisee_n"]["resultat"] == "20"


def test_route_synthese_404(app, monkeypatch):
    async def _fake(*, ria_id, company_id):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(ria_service, "compute_synthese_resultats", _fake)
    client = TestClient(app)
    r = client.get(f"/plugins/compta_esms/documents/{RIA_ID}/synthese-resultats")
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "document_not_found"


def test_route_synthese_409_not_a_ria(app, monkeypatch):
    async def _fake(*, ria_id, company_id):
        raise ConflictError("nope", code="not_a_ria")

    monkeypatch.setattr(ria_service, "compute_synthese_resultats", _fake)
    client = TestClient(app)
    r = client.get(f"/plugins/compta_esms/documents/{RIA_ID}/synthese-resultats")
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "not_a_ria"


def test_route_synthese_409_ria_orphan(app, monkeypatch):
    async def _fake(*, ria_id, company_id):
        raise ConflictError("nope", code="ria_orphan")

    monkeypatch.setattr(ria_service, "compute_synthese_resultats", _fake)
    client = TestClient(app)
    r = client.get(f"/plugins/compta_esms/documents/{RIA_ID}/synthese-resultats")
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "ria_orphan"
