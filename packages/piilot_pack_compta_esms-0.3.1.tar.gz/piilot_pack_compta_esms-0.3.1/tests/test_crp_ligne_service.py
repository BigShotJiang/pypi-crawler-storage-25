"""Unit tests for :mod:`piilot_pack_compta_esms.services.crp_ligne_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import psycopg2
import pytest

from piilot_pack_compta_esms.models.crp_ligne import (
    BulkUpsertItem,
    CrpLigneCreate,
    CrpLigneUpdate,
)
from piilot_pack_compta_esms.services import crp_ligne_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)

COMPANY = uuid4()
OTHER_COMPANY = uuid4()
CR_ID = uuid4()
LIGNE_ID = uuid4()
BINDING_ID = uuid4()
DOC_ID = uuid4()


def _make_row(**overrides):
    base = {
        "id": LIGNE_ID,
        "company_id": COMPANY,
        "cr_id": CR_ID,
        "groupe": "G1",
        "nature": "charge",
        "compte_m22bis": "6064",
        "compte_label": "Fournitures admin",
        "montant_budget_initial": Decimal("12000.00"),
        "montant_virements_credits": None,
        "montant_decisions_modif": None,
        "montant_previsions_totales": Decimal("12000.00"),
        "montant_realise": Decimal("12450.00"),
        "montant_hebergement": None,
        "montant_dependance": None,
        "montant_soins": None,
        "montant_soins_autonomie": None,
        "binding_id": None,
        "saisie_manuelle": True,
        "override_balance": False,
        "override_reason": None,
        "override_at": None,
        "notes": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.crp_ligne_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def lookup_fail_open(monkeypatch):
    """Q7 — by default the lookup says "unknown" so we test the
    fail-open path. Individual tests can override per-call."""

    async def _fake(_):
        return False

    monkeypatch.setattr(crp_ligne_service.reference_lookup, "compte_m22bis_exists", _fake)


@pytest.fixture
def owned_cr(monkeypatch):
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo,
        "cr_belongs_to_company",
        lambda cr, company: True,
    )


# ---------------------------------------------------------------------------
# list / get
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_lignes_filters_forwarded(monkeypatch, owned_cr, patch_run_in_thread):
    captured: dict = {}

    def _fake(cr_id, *, groupe=None, nature=None):
        captured["groupe"] = groupe
        captured["nature"] = nature
        return [_make_row()]

    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "list_by_cr", _fake)
    out = await crp_ligne_service.list_lignes(CR_ID, COMPANY, groupe="G1", nature="charge")
    assert captured == {"groupe": "G1", "nature": "charge"}
    assert len(out) == 1


@pytest.mark.asyncio
async def test_list_lignes_cross_tenant(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo,
        "cr_belongs_to_company",
        lambda cr, company: False,
    )
    with pytest.raises(NotFoundError) as exc:
        await crp_ligne_service.list_lignes(CR_ID, COMPANY)
    assert exc.value.code == "cr_not_found"


@pytest.mark.asyncio
async def test_get_ligne_cross_tenant_returns_404(monkeypatch, patch_run_in_thread):
    """Cross-tenant returns 404, not 403 — no existence leak."""
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo,
        "get_by_id",
        lambda _: _make_row(company_id=OTHER_COMPANY),
    )
    with pytest.raises(NotFoundError) as exc:
        await crp_ligne_service.get_ligne(LIGNE_ID, COMPANY)
    assert exc.value.code == "ligne_not_found"


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_ligne_happy(monkeypatch, owned_cr, lookup_fail_open, patch_run_in_thread):
    captured: dict = {}

    def _fake_create(*, company_id, cr_id, payload, binding_id=None):
        captured["payload"] = payload
        return _make_row(compte_m22bis=payload["compte_m22bis"])

    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "create", _fake_create)
    out = await crp_ligne_service.create_ligne(
        CR_ID,
        COMPANY,
        CrpLigneCreate(groupe="G1", nature="charge", compte_m22bis="6064"),
    )
    assert out.compte_m22bis == "6064"
    assert captured["payload"]["groupe"] == "G1"


@pytest.mark.asyncio
async def test_create_ligne_compte_unknown_warning_fail_open(
    monkeypatch, owned_cr, patch_run_in_thread, caplog
):
    """Q7 — unknown compte logs but doesn't raise."""
    import logging

    async def _fake_lookup(_):
        return False  # KB has codes, but our value isn't one

    monkeypatch.setattr(crp_ligne_service.reference_lookup, "compte_m22bis_exists", _fake_lookup)
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo,
        "create",
        lambda **kw: _make_row(compte_m22bis="99999"),
    )
    with caplog.at_level(logging.INFO, logger="piilot_pack_compta_esms.services.crp_ligne_service"):
        out = await crp_ligne_service.create_ligne(
            CR_ID,
            COMPANY,
            CrpLigneCreate(groupe="G1", nature="charge", compte_m22bis="99999"),
        )
    assert out.compte_m22bis == "99999"
    assert any("99999" in r.message for r in caplog.records)


@pytest.mark.asyncio
async def test_create_ligne_409_on_unique_violation(
    monkeypatch, owned_cr, lookup_fail_open, patch_run_in_thread
):
    def _raise(**kw):
        raise psycopg2.errors.UniqueViolation("dup")

    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "create", _raise)
    with pytest.raises(ConflictError) as exc:
        await crp_ligne_service.create_ligne(
            CR_ID,
            COMPANY,
            CrpLigneCreate(groupe="G1", nature="charge", compte_m22bis="6064"),
        )
    assert exc.value.code == "ligne_duplicate"


# ---------------------------------------------------------------------------
# update — Q6 auto-flip
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_update_ligne_flips_override_balance_when_bound(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo,
        "get_by_id",
        lambda _: _make_row(binding_id=BINDING_ID),
    )
    captured: dict = {}

    def _fake_update(ligne_id, data, *, flip_override_balance):
        captured["flip"] = flip_override_balance
        captured["data"] = data
        return _make_row(
            binding_id=BINDING_ID,
            override_balance=True,
            override_at=datetime.now(UTC),
            montant_realise=Decimal("12500.00"),
        )

    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "update", _fake_update)
    out = await crp_ligne_service.update_ligne(
        LIGNE_ID,
        COMPANY,
        CrpLigneUpdate(montant_realise=Decimal("12500.00"), override_reason="correction"),
    )
    assert captured["flip"] is True
    assert "override_reason" in captured["data"]
    assert out.override_balance is True


@pytest.mark.asyncio
async def test_update_ligne_no_flip_when_unbound(monkeypatch, patch_run_in_thread):
    """Manual saisie row (binding_id=None) — no auto-flip."""
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo,
        "get_by_id",
        lambda _: _make_row(binding_id=None),
    )
    captured: dict = {}

    def _fake_update(ligne_id, data, *, flip_override_balance):
        captured["flip"] = flip_override_balance
        return _make_row()

    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "update", _fake_update)
    await crp_ligne_service.update_ligne(LIGNE_ID, COMPANY, CrpLigneUpdate(notes="hello"))
    assert captured["flip"] is False


@pytest.mark.asyncio
async def test_update_ligne_cross_tenant_404(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo,
        "get_by_id",
        lambda _: _make_row(company_id=OTHER_COMPANY),
    )
    with pytest.raises(NotFoundError):
        await crp_ligne_service.update_ligne(LIGNE_ID, COMPANY, CrpLigneUpdate(notes="x"))


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_delete_ligne_happy(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "get_by_id", lambda _: _make_row())
    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "delete", lambda _: True)
    await crp_ligne_service.delete_ligne(LIGNE_ID, COMPANY)


@pytest.mark.asyncio
async def test_delete_ligne_404(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "get_by_id", lambda _: None)
    with pytest.raises(NotFoundError):
        await crp_ligne_service.delete_ligne(LIGNE_ID, COMPANY)


# ---------------------------------------------------------------------------
# bulk_upsert
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_upsert_happy(monkeypatch, owned_cr, lookup_fail_open, patch_run_in_thread):
    captured: dict = {}

    def _fake_bulk(*, company_id, cr_id, items, binding_id):
        captured["items"] = items
        captured["binding_id"] = binding_id
        return [_make_row(compte_m22bis=i["compte_m22bis"]) for i in items]

    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "bulk_upsert", _fake_bulk)
    out = await crp_ligne_service.bulk_upsert(
        CR_ID,
        COMPANY,
        [
            BulkUpsertItem(groupe="G1", nature="charge", compte_m22bis="6064"),
            BulkUpsertItem(
                groupe="G1",
                nature="charge",
                compte_m22bis="6065",
                montant_realise=Decimal("100.00"),
            ),
        ],
    )
    assert len(out) == 2
    assert captured["binding_id"] is None  # manual bulk, no binding


# ---------------------------------------------------------------------------
# totals (Q5)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_totals_pivots_correctly(monkeypatch, owned_cr, patch_run_in_thread):
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo,
        "get_cr_context",
        lambda _: {
            "cr_variante": "soumis_equilibre",
            "document_id": DOC_ID,
            "type_document": "eprd",
        },
    )
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo,
        "totals_by_groupe",
        lambda _: [
            {
                "groupe": "G1",
                "nature": "charge",
                "previsions_totales": Decimal("100"),
                "realise": Decimal("110"),
            },
            {
                "groupe": "G2",
                "nature": "charge",
                "previsions_totales": Decimal("200"),
                "realise": Decimal("210"),
            },
            {
                "groupe": "G1",
                "nature": "produit",
                "previsions_totales": Decimal("400"),
                "realise": Decimal("420"),
            },
        ],
    )
    out = await crp_ligne_service.totals(CR_ID, COMPANY)
    assert out.cr_variante == "soumis_equilibre"
    assert out.by_groupe["G1"].charges.previsions_totales == Decimal("100")
    assert out.by_groupe["G2"].charges.realise == Decimal("210")
    # G3 has no rows → empty pair (zero)
    assert out.by_groupe["G3"].charges.previsions_totales == Decimal("0")
    assert out.total_charges.previsions_totales == Decimal("300")
    assert out.total_produits.realise == Decimal("420")
    # ecart = produits - charges
    assert out.ecart.previsions_totales == Decimal("100")
    assert out.ecart.realise == Decimal("100")
    assert out.ecart.is_equilibre_required is True


@pytest.mark.asyncio
async def test_totals_empty_cr_returns_zeros(monkeypatch, owned_cr, patch_run_in_thread):
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo,
        "get_cr_context",
        lambda _: {
            "cr_variante": "non_soumis_equil",
            "document_id": DOC_ID,
            "type_document": "errd",
        },
    )
    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "totals_by_groupe", lambda _: [])
    out = await crp_ligne_service.totals(CR_ID, COMPANY)
    assert out.total_charges.previsions_totales == Decimal("0")
    assert out.ecart.is_equilibre_required is False
