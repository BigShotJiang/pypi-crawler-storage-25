"""Route tests for apply / materialize / history endpoints (L2 §F.5)."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import balance_apply as ba_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import balance_apply_service
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

COMPANY = uuid4()
USER = uuid4()
IMPORT_ID = uuid4()
BUILDER_AUTH = (USER, "builder", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(ba_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


def test_apply_mapping_200(client, monkeypatch):
    async def _fake(company_id, import_id, request):
        from piilot_pack_compta_esms.models.balance_apply import ApplyResult

        return ApplyResult(
            import_id=import_id,
            status="completed",
            nb_lignes_source=10,
            nb_lignes_mappees=10,
            nb_lignes_non_mappees=0,
            nb_unmapped_accounts=0,
            applied_at=datetime.now(UTC),
            dry_run=request.dry_run,
        )

    monkeypatch.setattr(balance_apply_service, "apply_mapping", _fake)
    r = client.post(
        f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/apply-mapping",
        json={"dry_run": True, "version_m22bis": "2024-2025"},
    )
    assert r.status_code == 200
    assert r.json()["dry_run"] is True
    assert r.json()["status"] == "completed"


def test_apply_mapping_empty_body(client, monkeypatch):
    """No body → defaults via ApplyRequest()."""
    captured: dict = {}

    async def _fake(company_id, import_id, request):
        captured["dry_run"] = request.dry_run
        captured["version"] = request.version_m22bis
        from piilot_pack_compta_esms.models.balance_apply import ApplyResult

        return ApplyResult(
            import_id=import_id,
            status="completed",
            nb_lignes_source=0,
            nb_lignes_mappees=0,
            nb_lignes_non_mappees=0,
            nb_unmapped_accounts=0,
            applied_at=None,
            dry_run=False,
        )

    monkeypatch.setattr(balance_apply_service, "apply_mapping", _fake)
    r = client.post(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/apply-mapping")
    assert r.status_code == 200
    assert captured["dry_run"] is False
    assert captured["version"] == "2025-2026"


def test_apply_mapping_409_compte_unset(client, monkeypatch):
    async def _fake(company_id, import_id, request):
        raise ConflictError("nope", code="apply_compte_unset")

    monkeypatch.setattr(balance_apply_service, "apply_mapping", _fake)
    r = client.post(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/apply-mapping")
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "apply_compte_unset"


def test_get_unmapped_accounts(client, monkeypatch):
    async def _fake(company_id, import_id):
        from piilot_pack_compta_esms.models.balance_apply import UnmappedAccount

        return [
            UnmappedAccount(
                source_account="UNK",
                label_hint="x",
                montant=5.0,
                nb_lignes=1,
            )
        ]

    monkeypatch.setattr(balance_apply_service, "list_unmapped", _fake)
    r = client.get(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/unmapped-accounts")
    assert r.status_code == 200
    body = r.json()
    assert body[0]["source_account"] == "UNK"
    assert body[0]["montant"] == 5.0


def test_get_unmapped_404(client, monkeypatch):
    async def _fake(company_id, import_id):
        raise NotFoundError("nope", code="balance_import_not_found")

    monkeypatch.setattr(balance_apply_service, "list_unmapped", _fake)
    r = client.get(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/unmapped-accounts")
    assert r.status_code == 404


def test_materialize_kb_200(client, monkeypatch):
    async def _fake(company_id, import_id, request):
        from piilot_pack_compta_esms.models.balance_apply import MaterializeResult

        return MaterializeResult(
            import_id=import_id,
            kb_id=uuid4(),
            kb_name="Balance M22bis - 2025-12 - PCG",
            kb_table_name="kbs.compta_esms__x",
            rows_inserted=42,
            overwritten=False,
        )

    monkeypatch.setattr(balance_apply_service, "materialize_kb", _fake)
    r = client.post(
        f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/materialize-kb",
        json={"kb_label": "Custom name", "overwrite_existing": False},
    )
    assert r.status_code == 200
    assert r.json()["rows_inserted"] == 42


def test_materialize_kb_409_already(client, monkeypatch):
    async def _fake(company_id, import_id, request):
        raise ConflictError("nope", code="materialize_already_done")

    monkeypatch.setattr(balance_apply_service, "materialize_kb", _fake)
    r = client.post(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/materialize-kb")
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "materialize_already_done"


def test_delete_import_204(client, monkeypatch):
    captured: dict = {}

    async def _fake(company_id, import_id, *, delete_kb):
        captured["delete_kb"] = delete_kb

    monkeypatch.setattr(balance_apply_service, "delete_import", _fake)
    r = client.delete(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}?delete_kb=true")
    assert r.status_code == 204
    assert captured["delete_kb"] is True


def test_delete_import_default_no_kb(client, monkeypatch):
    captured: dict = {}

    async def _fake(company_id, import_id, *, delete_kb):
        captured["delete_kb"] = delete_kb

    monkeypatch.setattr(balance_apply_service, "delete_import", _fake)
    r = client.delete(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}")
    assert r.status_code == 204
    assert captured["delete_kb"] is False


def test_list_history(client, monkeypatch):
    captured: dict = {}

    async def _fake(company_id, **kwargs):
        captured.update(kwargs)
        return []

    monkeypatch.setattr(balance_apply_service, "list_history", _fake)
    r = client.get("/plugins/compta_esms/balance-imports?limit=5&import_status=completed")
    assert r.status_code == 200
    assert captured["limit"] == 5
    assert captured["status"] == "completed"


def test_replay_200(client, monkeypatch):
    async def _fake(company_id, import_id):
        from piilot_pack_compta_esms.models.balance_apply import ApplyResult

        return ApplyResult(
            import_id=import_id,
            status="completed",
            nb_lignes_source=10,
            nb_lignes_mappees=10,
            nb_lignes_non_mappees=0,
            nb_unmapped_accounts=0,
            applied_at=datetime.now(UTC),
            dry_run=False,
        )

    monkeypatch.setattr(balance_apply_service, "replay_import", _fake)
    r = client.post(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/replay")
    assert r.status_code == 200


def test_user_cannot_apply(client):
    """Builder is required for apply-mapping."""
    from fastapi import HTTPException

    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.post(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/apply-mapping")
    assert r.status_code == 403
