"""Tests for CAF + marge brute + FRNG + BFR + Trésorerie (§I.4 + §I.5)."""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.models.finance import (
    BfrInput,
    CafInput,
    FrngInput,
    MargeBruteInput,
    TresorerieInput,
)
from piilot_pack_compta_esms.services.finance import (
    caf_calculator,
    structure_financiere,
)

# ---------------------------------------------------------------------------
# CAF (F.IND.02)
# ---------------------------------------------------------------------------


def test_caf_formule_complete():
    """CAF = Résultat + Amort + Dot.prov - Reprises prov - Reprises subv ± autres."""
    result = caf_calculator.compute_caf(
        CafInput(
            resultat_net=Decimal("10000"),
            dotations_amortissements=Decimal("50000"),
            dotations_provisions=Decimal("3000"),
            reprises_provisions=Decimal("1000"),
            reprises_subventions=Decimal("2000"),
            autres_non_decaissables=Decimal("0"),
        )
    )
    # 10000 + 50000 + 3000 - 1000 - 2000 = 60000
    assert result.caf == Decimal("60000")


def test_caf_sain_when_ratio_above_1_2():
    """CAF/IAF >= 1.2 → santé sain."""
    result = caf_calculator.compute_caf(
        CafInput(
            resultat_net=Decimal("0"),
            dotations_amortissements=Decimal("60000"),
            capital_a_rembourser_n=Decimal("40000"),
        )
    )
    # ratio = 60000/40000 = 1.5
    assert result.ratio_caf_iaf == Decimal("1.5")
    assert result.sante == "sain"


def test_caf_attention_when_ratio_between_1_and_1_2():
    result = caf_calculator.compute_caf(
        CafInput(
            resultat_net=Decimal("0"),
            dotations_amortissements=Decimal("44000"),
            capital_a_rembourser_n=Decimal("40000"),
        )
    )
    # ratio = 1.1
    assert result.sante == "attention"


def test_caf_negative_critique():
    """CAF négatif → critique, ratio non calculable utilement."""
    result = caf_calculator.compute_caf(
        CafInput(
            resultat_net=Decimal("-30000"),
            dotations_amortissements=Decimal("0"),
            capital_a_rembourser_n=Decimal("40000"),
        )
    )
    assert result.caf < 0
    assert result.sante == "critique"


def test_caf_no_iaf_returns_no_ratio_but_sain():
    """Pas de capital à rembourser → ratio None, santé "sain" par défaut."""
    result = caf_calculator.compute_caf(CafInput(resultat_net=Decimal("5000")))
    assert result.ratio_caf_iaf is None
    assert result.sante == "sain"


# ---------------------------------------------------------------------------
# Marge brute (F.IND.01)
# ---------------------------------------------------------------------------


def test_marge_brute_sain():
    result = caf_calculator.compute_marge_brute(
        MargeBruteInput(
            resultat_net=Decimal("6000"),
            total_produits=Decimal("100000"),
        )
    )
    # 6% → sain
    assert result.marge_brute_pct == Decimal("6")
    assert result.sante == "sain"


def test_marge_brute_alerte_seuil_2pct():
    """Seuil S01 trame VF vKAS : < 2% = situation tendue."""
    result = caf_calculator.compute_marge_brute(
        MargeBruteInput(
            resultat_net=Decimal("1500"),
            total_produits=Decimal("100000"),
        )
    )
    # 1.5% → alerte
    assert result.sante == "alerte"


def test_marge_brute_critique_negative():
    result = caf_calculator.compute_marge_brute(
        MargeBruteInput(
            resultat_net=Decimal("-1000"),
            total_produits=Decimal("100000"),
        )
    )
    assert result.sante == "critique"


def test_marge_brute_zero_produits():
    """Division par zéro guard — retourne 0% + critique."""
    result = caf_calculator.compute_marge_brute(
        MargeBruteInput(resultat_net=Decimal("0"), total_produits=Decimal("0"))
    )
    assert result.marge_brute_pct == Decimal("0")
    assert result.sante == "critique"


# ---------------------------------------------------------------------------
# FRNG (F.IND.03)
# ---------------------------------------------------------------------------


def test_frng_positif_sain():
    """FRI > 0 + FRE = 0 → FRNG positif, santé sain."""
    result = structure_financiere.compute_frng(
        FrngInput(
            fonds_propres=Decimal("500000"),
            subventions_invest=Decimal("100000"),
            provisions_invest=Decimal("0"),
            dettes_long_terme=Decimal("200000"),
            immobilisations_nettes=Decimal("700000"),
        )
    )
    # ressources_durables = 800000 ; FRI = 100000 ; FRE = 0 ; FRNG = 100000
    assert result.fri == Decimal("100000")
    assert result.fre == Decimal("0")
    assert result.frng == Decimal("100000")
    assert result.sante == "sain"


def test_frng_fri_plus_fre():
    result = structure_financiere.compute_frng(
        FrngInput(
            fonds_propres=Decimal("100000"),
            immobilisations_nettes=Decimal("80000"),
            fre_ressources=Decimal("50000"),
            fre_emplois=Decimal("30000"),
        )
    )
    assert result.fri == Decimal("20000")
    assert result.fre == Decimal("20000")
    assert result.frng == Decimal("40000")
    assert result.sante == "sain"


def test_frng_deficit_critique():
    """FRNG très négatif → critique."""
    result = structure_financiere.compute_frng(
        FrngInput(
            fonds_propres=Decimal("100000"),
            immobilisations_nettes=Decimal("500000"),
        )
    )
    # FRI = -400000 sur ressources 100000 → ratio -4 → critique
    assert result.frng < 0
    assert result.sante == "critique"


# ---------------------------------------------------------------------------
# BFR (F.IND.04)
# ---------------------------------------------------------------------------


def test_bfr_negatif_sain():
    """BFR négatif (S01 §9) = exploitation autofinance → sain."""
    result = structure_financiere.compute_bfr(
        BfrInput(
            creances_clients=Decimal("10000"),
            stocks=Decimal("5000"),
            dettes_fournisseurs=Decimal("25000"),
            dettes_sociales=Decimal("0"),
        )
    )
    # (10000 + 5000) - (25000 + 0) = -10000
    assert result.bfr == Decimal("-10000")
    assert result.sante == "sain"


def test_bfr_positif_alerte():
    result = structure_financiere.compute_bfr(
        BfrInput(
            creances_clients=Decimal("80000"),
            stocks=Decimal("20000"),
            dettes_fournisseurs=Decimal("30000"),
            dettes_sociales=Decimal("10000"),
        )
    )
    # BFR = +60000 sur actif circulant 100000 → 60% → alerte
    assert result.bfr == Decimal("60000")
    assert result.sante == "alerte"


# ---------------------------------------------------------------------------
# Trésorerie nette (F.IND.05)
# ---------------------------------------------------------------------------


def test_tresorerie_positive_sain():
    """Trésorerie = FRNG - BFR > 0 → sain."""
    result = structure_financiere.compute_tresorerie(
        TresorerieInput(frng=Decimal("100000"), bfr=Decimal("30000"))
    )
    assert result.tresorerie == Decimal("70000")
    assert result.sante == "sain"


def test_tresorerie_negative_alerte():
    """Trésorerie légèrement négative → alerte."""
    result = structure_financiere.compute_tresorerie(
        TresorerieInput(frng=Decimal("50000"), bfr=Decimal("60000"))
    )
    # tresorerie = -10000, abs(BFR) * 0.2 = 12000, -10000 > -12000 → alerte
    assert result.tresorerie == Decimal("-10000")
    assert result.sante == "alerte"


def test_tresorerie_zero_attention():
    result = structure_financiere.compute_tresorerie(
        TresorerieInput(frng=Decimal("100000"), bfr=Decimal("100000"))
    )
    assert result.tresorerie == Decimal("0")
    assert result.sante == "attention"
