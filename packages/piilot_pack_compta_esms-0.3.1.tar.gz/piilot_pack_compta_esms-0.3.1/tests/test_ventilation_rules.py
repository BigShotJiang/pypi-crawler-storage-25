"""Tests §Y D-055 — règles dures de ventilation (KB20 §8.1).

Couvre la résolution :

* 65* → Hébergement 100% (administration générale)
* 66* → Soins 100% (intérêts emprunts D.314-205)
* 6021* → Soins (charges pharmaceutiques)
* 62113* → Soins (personnel médical extérieur)
* 6288 → Soins (pharmacie logistique)
* 602261 → Dépendance (couches, alèses)
* Autres comptes → None (clé gestionnaire prendra le relais)
"""

from __future__ import annotations

import pytest

from piilot_pack_compta_esms.services.ventilation_rules import (
    list_hard_rules,
    resolve_section_dure,
)


@pytest.mark.parametrize(
    "compte, expected",
    [
        # 65xx → H
        ("65", "hebergement"),
        ("651", "hebergement"),
        ("6511", "hebergement"),
        ("65818", "hebergement"),
        # 66xx → S (intérêts emprunts)
        ("66", "soins"),
        ("661", "soins"),
        ("66111", "soins"),
        # 6021* → S (pharmacie)
        ("6021", "soins"),
        ("60211", "soins"),
        ("602131", "soins"),
        # 62113* → S (personnel médical extérieur)
        ("62113", "soins"),
        ("621131", "soins"),
        # 6288 → S (pharmacie logistique)
        ("6288", "soins"),
        ("62881", "soins"),
        # 602261 → D (couches, alèses) — match avant 6021 grâce à l'ordre
        ("602261", "dependance"),
        ("6022611", "dependance"),
    ],
)
def test_resolve_section_dure_hard_rules(compte: str, expected: str) -> None:
    """Tous les comptes catalogués matchent leur règle dure."""
    assert resolve_section_dure(compte) == expected


@pytest.mark.parametrize(
    "compte",
    [
        # Charges communes — clé gestionnaire requise (None)
        "60222",  # entretien (KB20 §8.1 footnote (1))
        "60226",  # hôtelier (KB20 §8.1 footnote (1))
        "6064",  # fournitures administratives
        "61",  # services extérieurs
        "62",  # autres services extérieurs (hors 62113, 6288)
        "63",  # impôts taxes
        "64",  # personnel (sauf 64 spécifiques)
        "67",  # charges exceptionnelles
        "68",  # dotations
        # Produits — pas de règle dure
        "70",
        "73",
        "74",
        # Empty / weird
        "",
        "   ",
    ],
)
def test_resolve_section_dure_none_for_unmatched(compte: str) -> None:
    """Comptes hors règles dures retournent None."""
    assert resolve_section_dure(compte) is None


def test_resolve_section_dure_whitespace_tolerant() -> None:
    """Le helper trim les espaces avant le match."""
    assert resolve_section_dure("  65  ") == "hebergement"
    assert resolve_section_dure(" 66") == "soins"


def test_list_hard_rules_returns_complete_catalog() -> None:
    """L'export liste les 6 règles documentées."""
    rules = list_hard_rules()
    assert len(rules) == 6
    prefixes = {prefix for prefix, _ in rules}
    assert prefixes == {"602261", "62113", "6288", "6021", "65", "66"}


def test_602261_priority_over_6021() -> None:
    """Régression — '602261' (D) doit matcher avant '6021' (S) car le
    préfixe le plus long doit gagner. La table _RULES_PREFIX est
    ordonnée explicitement pour ce cas."""
    # Note: en théorie 602261 commence par 6021... non en fait 602261
    # commence par 6022, pas 6021. Donc pas de collision réelle.
    # Mais on garde le test au cas où la table serait ré-ordonnée.
    assert resolve_section_dure("602261") == "dependance"
    assert resolve_section_dure("6021") == "soins"  # 6021 != 602261 prefix
