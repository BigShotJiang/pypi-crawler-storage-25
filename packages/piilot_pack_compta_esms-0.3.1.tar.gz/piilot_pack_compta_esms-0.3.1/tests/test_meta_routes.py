"""Route tests for ``/health`` + ``/version`` (§AI L2 §23.1+§23.2)."""

from __future__ import annotations

from types import SimpleNamespace
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import meta as meta_routes
from piilot_pack_compta_esms.routes._limiter import limiter

COMPANY = uuid4()
USER = uuid4()
USER_AUTH = (USER, "user", COMPANY)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(meta_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# /health — non-auth
# ---------------------------------------------------------------------------


def test_health_returns_200_no_auth(client):
    """``/health`` ne demande pas d'auth — Coolify healthcheck doit
    pouvoir le frapper sans JWT."""
    r = client.get("/plugins/compta_esms/health")
    assert r.status_code == 200


def test_health_body_minimal(client):
    r = client.get("/plugins/compta_esms/health")
    assert r.json() == {"status": "ok", "plugin": "compta_esms"}


def test_health_no_db_check(client, monkeypatch):
    """Health ne déclenche aucune lecture DB — patcher ``cursor`` pour
    raise garantit qu'on n'y touche pas."""
    from piilot.sdk import db as sdk_db

    def _raise_cursor():
        raise RuntimeError("DB should NOT be touched by /health")

    monkeypatch.setattr(sdk_db, "cursor", _raise_cursor)
    r = client.get("/plugins/compta_esms/health")
    assert r.status_code == 200


# ---------------------------------------------------------------------------
# /version — user
# ---------------------------------------------------------------------------


def test_version_returns_200(client, monkeypatch):
    fake_manifest = SimpleNamespace(
        version="0.2.0",
        namespace="compta_esms",
        display_name="Comptabilité ESMS",
        sdk_compat=">=0.7.0,<1.0.0",
    )
    monkeypatch.setattr(
        meta_routes,
        "_read_manifest_metadata",
        lambda: {
            "plugin_version": fake_manifest.version,
            "namespace": fake_manifest.namespace,
            "display_name": fake_manifest.display_name,
            "sdk_compat": fake_manifest.sdk_compat,
        },
    )
    r = client.get("/plugins/compta_esms/version")
    assert r.status_code == 200
    body = r.json()
    assert body == {
        "plugin_version": "0.2.0",
        "namespace": "compta_esms",
        "display_name": "Comptabilité ESMS",
        "sdk_compat": ">=0.7.0,<1.0.0",
    }


def test_version_real_manifest_in_test_runtime(client):
    """Sanity check — quand on lit le vrai manifest plugin, les champs
    sont là (version 0.2.0 lue depuis pyproject.toml ou Plugin.manifest).
    """
    r = client.get("/plugins/compta_esms/version")
    assert r.status_code == 200
    body = r.json()
    assert "plugin_version" in body
    assert body["namespace"] == "compta_esms"
    assert "display_name" in body
    assert "sdk_compat" in body


def test_version_response_extra_forbid(client, monkeypatch):
    """Pydantic ``extra='forbid'`` doit refuser tout champ surajouté
    qu'un service surcharge ne déclarerait pas. Vérifié indirectement
    via ``response_model`` qui drop les extras."""

    monkeypatch.setattr(
        meta_routes,
        "_read_manifest_metadata",
        lambda: {
            "plugin_version": "0.2.0",
            "namespace": "compta_esms",
            "display_name": "Comptabilité ESMS",
            "sdk_compat": ">=0.7.0,<1.0.0",
        },
    )
    r = client.get("/plugins/compta_esms/version")
    assert set(r.json().keys()) == {
        "plugin_version",
        "namespace",
        "display_name",
        "sdk_compat",
    }
