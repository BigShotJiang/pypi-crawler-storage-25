"""Unit tests for :mod:`piilot_pack_compta_esms.services.balance_mapping_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.balance_mapping import (
    BalanceMappingBulkItem,
    BalanceMappingCreate,
    BalanceMappingUpdate,
)
from piilot_pack_compta_esms.services import balance_mapping_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)

COMPANY = uuid4()
OTHER_COMPANY = uuid4()
MAPPING_ID = uuid4()


def _make_row(**overrides):
    base = {
        "id": MAPPING_ID,
        "company_id": COMPANY,
        "source_plan": "PCG",
        "source_account": "60611",
        "target_m22bis_account": "60611",
        "weight": 1.0,
        "label_hint": None,
        "confidence": None,
        "suggestion_origin": None,
        "version_m22bis": "2025-2026",
        "valid_from": None,
        "valid_to": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.balance_mapping_service.run_in_thread",
        _passthrough,
    )


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_returns_pydantic(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "list_filtered",
        lambda company_id, **kw: [_make_row(), _make_row(source_account="60612")],
    )
    out = await balance_mapping_service.list_mappings(COMPANY)
    assert [m.source_account for m in out] == ["60611", "60612"]


@pytest.mark.asyncio
async def test_get_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(balance_mapping_service.balance_mapping_repo, "get_by_id", lambda _: None)
    with pytest.raises(NotFoundError):
        await balance_mapping_service.get_mapping(MAPPING_ID)


@pytest.mark.asyncio
async def test_create_happy_1to1(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "find_unique",
        lambda *a, **kw: None,
    )
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "list_filtered",
        lambda company_id, **kw: [],
    )
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "create",
        lambda company_id, payload: _make_row(**payload),
    )
    out = await balance_mapping_service.create_mapping(
        COMPANY,
        BalanceMappingCreate(
            source_plan="PCG",
            source_account="60611",
            target_m22bis_account="60611",
        ),
    )
    assert out.target_m22bis_account == "60611"


@pytest.mark.asyncio
async def test_create_duplicate_409(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "find_unique",
        lambda *a, **kw: _make_row(),
    )
    with pytest.raises(ConflictError) as exc:
        await balance_mapping_service.create_mapping(
            COMPANY,
            BalanceMappingCreate(
                source_plan="PCG",
                source_account="60611",
                target_m22bis_account="60611",
            ),
        )
    assert exc.value.code == "mapping_already_exists"


@pytest.mark.asyncio
async def test_create_rejects_weight_overflow(monkeypatch, patch_run_in_thread):
    """A 1:N split that pushes Σ weight > 1.0 fails before the DB trigger."""
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "find_unique",
        lambda *a, **kw: None,
    )
    # Existing siblings already sum to 0.8 — adding 0.5 → 1.3 overflow.
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "list_filtered",
        lambda company_id, **kw: [
            _make_row(target_m22bis_account="6411", weight=0.5),
            _make_row(target_m22bis_account="6451", weight=0.3),
        ],
    )
    with pytest.raises(ConflictError) as exc:
        await balance_mapping_service.create_mapping(
            COMPANY,
            BalanceMappingCreate(
                source_plan="PCG",
                source_account="64",
                target_m22bis_account="6452",
                weight=0.5,
            ),
        )
    assert exc.value.code == "mapping_weight_overflow"


@pytest.mark.asyncio
async def test_update_weight_revalidates_sum(monkeypatch, patch_run_in_thread):
    """Patching weight from 0.5 → 0.9 when the other split holds 0.3 → 1.2 overflow."""
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "get_by_id",
        lambda _: _make_row(target_m22bis_account="6411", weight=0.5),
    )
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "list_filtered",
        lambda company_id, **kw: [
            _make_row(target_m22bis_account="6411", weight=0.5),
            _make_row(target_m22bis_account="6451", weight=0.3),
        ],
    )
    with pytest.raises(ConflictError) as exc:
        await balance_mapping_service.update_mapping(
            COMPANY, MAPPING_ID, BalanceMappingUpdate(weight=0.9)
        )
    assert exc.value.code == "mapping_weight_overflow"


@pytest.mark.asyncio
async def test_update_cross_tenant_404(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "get_by_id",
        lambda _: _make_row(company_id=OTHER_COMPANY),
    )
    with pytest.raises(NotFoundError):
        await balance_mapping_service.update_mapping(
            COMPANY, MAPPING_ID, BalanceMappingUpdate(weight=0.5)
        )


@pytest.mark.asyncio
async def test_delete_happy(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "get_by_id",
        lambda _: _make_row(),
    )
    monkeypatch.setattr(balance_mapping_service.balance_mapping_repo, "delete", lambda _: True)
    await balance_mapping_service.delete_mapping(COMPANY, MAPPING_ID)


# ---------------------------------------------------------------------------
# Bulk + validate
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_upsert_empty_short_circuits(monkeypatch, patch_run_in_thread):
    """Empty payload → no repo call, empty list."""

    def _should_not_be_called(*a, **kw):
        raise AssertionError("bulk_upsert must not run on empty input")

    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "bulk_upsert",
        _should_not_be_called,
    )
    out = await balance_mapping_service.bulk_upsert_mappings(COMPANY, [])
    assert out == []


@pytest.mark.asyncio
async def test_bulk_upsert_returns_pydantic(monkeypatch, patch_run_in_thread):
    captured = {}

    def _bulk(company_id, payload):
        captured["payload"] = payload
        return [_make_row(target_m22bis_account=p["target_m22bis_account"]) for p in payload]

    monkeypatch.setattr(balance_mapping_service.balance_mapping_repo, "bulk_upsert", _bulk)
    out = await balance_mapping_service.bulk_upsert_mappings(
        COMPANY,
        [
            BalanceMappingBulkItem(
                source_plan="PCG",
                source_account="60611",
                target_m22bis_account="60611",
            ),
            BalanceMappingBulkItem(
                source_plan="PCG",
                source_account="60612",
                target_m22bis_account="60612",
            ),
        ],
    )
    assert {m.target_m22bis_account for m in out} == {"60611", "60612"}
    assert len(captured["payload"]) == 2


@pytest.mark.asyncio
async def test_validate_flags_imbalanced_sources(monkeypatch, patch_run_in_thread):
    """Sources with Σ ≠ 1.0 (±1e-4) surface as issues ; consistent
    sources are filtered out."""
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "sum_weights_by_source",
        lambda company_id: [
            # OK : Σ = 1.0 exactement
            {
                "source_plan": "PCG",
                "source_account": "60611",
                "version_m22bis": "2025-2026",
                "total_weight": 1.0,
                "target_count": 1,
            },
            # OK : Σ = 0.9999 dans la tolérance
            {
                "source_plan": "PCG",
                "source_account": "60612",
                "version_m22bis": "2025-2026",
                "total_weight": 0.99995,
                "target_count": 2,
            },
            # KO : 1:N incomplet (0.8 + 0.1 = 0.9)
            {
                "source_plan": "PCG",
                "source_account": "64",
                "version_m22bis": "2025-2026",
                "total_weight": 0.9,
                "target_count": 2,
            },
            # KO : overflow (1.5 — should already have been blocked by trigger,
            # but bulk imports racing on the same source can leave it)
            {
                "source_plan": "PCG",
                "source_account": "75",
                "version_m22bis": "2025-2026",
                "total_weight": 1.5,
                "target_count": 3,
            },
        ],
    )
    issues = await balance_mapping_service.validate_weights(COMPANY)
    assert {(i.source_account, i.total_weight) for i in issues} == {
        ("64", 0.9),
        ("75", 1.5),
    }


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_for_export_projects_correct_columns(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_mapping_service.balance_mapping_repo,
        "list_for_export",
        lambda company_id: [
            {
                "source_plan": "PCG",
                "source_account": "60611",
                "target_m22bis_account": "60611",
                "weight": 1.0,
                "label_hint": "Eau",
                "confidence": 1.0,
                "suggestion_origin": "pcg_to_m22bis_kb",
                "version_m22bis": "2025-2026",
                "valid_from": None,
                "valid_to": None,
            }
        ],
    )
    rows = await balance_mapping_service.list_for_export(COMPANY)
    assert len(rows) == 1
    # Ensure the projection matches the CSV header exactly
    assert set(rows[0].keys()) == set(balance_mapping_service.CSV_HEADER)
