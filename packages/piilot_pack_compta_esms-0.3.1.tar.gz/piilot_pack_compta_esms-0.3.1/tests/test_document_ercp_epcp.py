"""Tests §X — création ERCP/EPCP (D-013, D-025, D-059, D-060, KB22).

Couvre :

* Cadre auto SA généré (``#ERRDSA-2022-01#`` / ``#EPRDSA-2023-01#``)
  millésime DGCS figé, pas l'année du document
* Auto-CRPP **skippé** pour ERCP/EPCP (D-060)
* 422 ``eps_required_for_ercp_epcp`` si OG.nature_juridique != 'ETABLISSEMENT_PUBLIC_SANTE'
* OG.nature_juridique='ETABLISSEMENT_PUBLIC_SANTE' permet la création
* Override ``cadre_version`` reste possible (cabinet a la main)
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.document import DocumentCreate
from piilot_pack_compta_esms.services import document_service
from piilot_pack_compta_esms.services.errors import NotFoundError, ValidationError

COMPANY = uuid4()
EXERCICE_ID = uuid4()
DOC_ID = uuid4()
OG_ID = uuid4()


def _make_doc_row(**overrides):
    base = {
        "id": DOC_ID,
        "company_id": COMPANY,
        "exercice_id": EXERCICE_ID,
        "type_document": "ercp",
        "cadre_version": "#ERRDSA-2022-01#",
        "parent_id": None,
        "statut": "brouillon",
        "periode_observation_debut": None,
        "periode_observation_fin": None,
        "transmis_at": None,
        "executoire_at": None,
        "transmis_par_user_id": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


def _make_exercice_lookup(**overrides):
    base = {
        "id": EXERCICE_ID,
        "company_id": COMPANY,
        "og_id": OG_ID,
        "annee": 2026,
    }
    base.update(overrides)
    return base


def _make_og(nature_juridique="ETABLISSEMENT_PUBLIC_SANTE"):
    return {
        "id": OG_ID,
        "company_id": COMPANY,
        "nature_juridique": nature_juridique,
        "plan_comptable": "PC",
    }


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.document_service.run_in_thread",
        _passthrough,
    )


# ---------------------------------------------------------------------------
# Cadre auto SA
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_ercp_cadre_auto_is_sa_2022(monkeypatch, patch_run_in_thread):
    """ERCP → cadre auto = #ERRDSA-2022-01# (millésime DGCS figé)."""
    monkeypatch.setattr(
        document_service.document_repo, "exercice_lookup", lambda _: _make_exercice_lookup()
    )
    monkeypatch.setattr(document_service.og_repo, "get_by_id", lambda _: _make_og())
    captured: dict = {}

    def _create_without_crpp(**kwargs):
        captured.update(kwargs)
        return _make_doc_row(cadre_version=kwargs["cadre_version"])

    monkeypatch.setattr(document_service.document_repo, "create_without_crpp", _create_without_crpp)

    out = await document_service.create_document(
        COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="ercp")
    )
    assert out.cadre_version == "#ERRDSA-2022-01#"
    assert captured["cadre_version"] == "#ERRDSA-2022-01#"


@pytest.mark.asyncio
async def test_epcp_cadre_auto_is_sa_2023(monkeypatch, patch_run_in_thread):
    """EPCP → cadre auto = #EPRDSA-2023-01# (millésime DGCS figé)."""
    monkeypatch.setattr(
        document_service.document_repo, "exercice_lookup", lambda _: _make_exercice_lookup()
    )
    monkeypatch.setattr(document_service.og_repo, "get_by_id", lambda _: _make_og())
    monkeypatch.setattr(
        document_service.document_repo,
        "create_without_crpp",
        lambda **kw: _make_doc_row(type_document="epcp", cadre_version=kw["cadre_version"]),
    )

    out = await document_service.create_document(
        COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="epcp")
    )
    assert out.cadre_version == "#EPRDSA-2023-01#"


@pytest.mark.asyncio
async def test_ercp_cadre_override_kept(monkeypatch, patch_run_in_thread):
    """Cabinet peut override cadre_version pour cas transitoire DGCS."""
    monkeypatch.setattr(
        document_service.document_repo, "exercice_lookup", lambda _: _make_exercice_lookup()
    )
    monkeypatch.setattr(document_service.og_repo, "get_by_id", lambda _: _make_og())
    monkeypatch.setattr(
        document_service.document_repo,
        "create_without_crpp",
        lambda **kw: _make_doc_row(cadre_version=kw["cadre_version"]),
    )

    out = await document_service.create_document(
        COMPANY,
        DocumentCreate(
            exercice_id=EXERCICE_ID,
            type_document="ercp",
            cadre_version="#CUSTOMSA-2026-99#",
        ),
    )
    assert out.cadre_version == "#CUSTOMSA-2026-99#"


# ---------------------------------------------------------------------------
# Auto-CRPP skippé
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_ercp_skips_auto_crpp(monkeypatch, patch_run_in_thread):
    """ERCP → pas d'auto-CRPP (D-060). On vérifie qu'on appelle
    ``create_without_crpp`` et **pas** ``create_with_default_crpp``."""
    monkeypatch.setattr(
        document_service.document_repo, "exercice_lookup", lambda _: _make_exercice_lookup()
    )
    monkeypatch.setattr(document_service.og_repo, "get_by_id", lambda _: _make_og())

    without_crpp_calls: list = []
    with_crpp_calls: list = []
    monkeypatch.setattr(
        document_service.document_repo,
        "create_without_crpp",
        lambda **kw: (without_crpp_calls.append(kw), _make_doc_row())[1],
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "create_with_default_crpp",
        lambda **kw: (with_crpp_calls.append(kw), _make_doc_row())[1],
    )

    await document_service.create_document(
        COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="ercp")
    )
    assert len(without_crpp_calls) == 1
    assert len(with_crpp_calls) == 0


@pytest.mark.asyncio
async def test_epcp_skips_auto_crpp(monkeypatch, patch_run_in_thread):
    """EPCP → pas d'auto-CRPP (D-060)."""
    monkeypatch.setattr(
        document_service.document_repo, "exercice_lookup", lambda _: _make_exercice_lookup()
    )
    monkeypatch.setattr(document_service.og_repo, "get_by_id", lambda _: _make_og())

    without_crpp_calls: list = []
    with_crpp_calls: list = []
    monkeypatch.setattr(
        document_service.document_repo,
        "create_without_crpp",
        lambda **kw: (without_crpp_calls.append(kw), _make_doc_row(type_document="epcp"))[1],
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "create_with_default_crpp",
        lambda **kw: (with_crpp_calls.append(kw), _make_doc_row(type_document="epcp"))[1],
    )

    await document_service.create_document(
        COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="epcp")
    )
    assert len(without_crpp_calls) == 1
    assert len(with_crpp_calls) == 0


@pytest.mark.asyncio
async def test_eprd_still_creates_auto_crpp(monkeypatch, patch_run_in_thread):
    """Régression — pour EPRD le comportement reste auto-CRPP D-073."""
    monkeypatch.setattr(
        document_service.document_repo, "exercice_lookup", lambda _: _make_exercice_lookup()
    )

    without_crpp_calls: list = []
    with_crpp_calls: list = []
    monkeypatch.setattr(
        document_service.document_repo,
        "create_without_crpp",
        lambda **kw: (without_crpp_calls.append(kw), _make_doc_row())[1],
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "create_with_default_crpp",
        lambda **kw: (
            with_crpp_calls.append(kw),
            _make_doc_row(type_document="eprd", cadre_version="#EPRDHA-2026-01#"),
        )[1],
    )

    await document_service.create_document(
        COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="eprd")
    )
    assert len(with_crpp_calls) == 1
    assert len(without_crpp_calls) == 0


# ---------------------------------------------------------------------------
# EPS check
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_ercp_requires_eps_statut_juridique(monkeypatch, patch_run_in_thread):
    """OG.nature_juridique != 'ETABLISSEMENT_PUBLIC_SANTE' → 422 eps_required_for_ercp_epcp."""
    monkeypatch.setattr(
        document_service.document_repo, "exercice_lookup", lambda _: _make_exercice_lookup()
    )
    monkeypatch.setattr(
        document_service.og_repo,
        "get_by_id",
        lambda _: _make_og(nature_juridique="ESMS_PUBLIC_AUTONOME"),
    )

    with pytest.raises(ValidationError) as exc:
        await document_service.create_document(
            COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="ercp")
        )
    assert exc.value.code == "eps_required_for_ercp_epcp"


@pytest.mark.asyncio
async def test_epcp_requires_eps_statut_juridique(monkeypatch, patch_run_in_thread):
    """Symétrique pour EPCP."""
    monkeypatch.setattr(
        document_service.document_repo, "exercice_lookup", lambda _: _make_exercice_lookup()
    )
    monkeypatch.setattr(
        document_service.og_repo,
        "get_by_id",
        lambda _: _make_og(nature_juridique="PRIVE_NON_LUCRATIF"),
    )

    with pytest.raises(ValidationError) as exc:
        await document_service.create_document(
            COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="epcp")
        )
    assert exc.value.code == "eps_required_for_ercp_epcp"


@pytest.mark.asyncio
async def test_eprd_does_not_require_eps(monkeypatch, patch_run_in_thread):
    """Régression — EPRD reste créable depuis n'importe quel statut juridique."""
    monkeypatch.setattr(
        document_service.document_repo, "exercice_lookup", lambda _: _make_exercice_lookup()
    )
    # Aucun appel à og_repo pour EPRD — la guard est conditionnée sur le type.
    monkeypatch.setattr(
        document_service.document_repo,
        "create_with_default_crpp",
        lambda **kw: _make_doc_row(type_document="eprd"),
    )

    out = await document_service.create_document(
        COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="eprd")
    )
    assert out.type_document == "eprd"


@pytest.mark.asyncio
async def test_ercp_og_missing_404(monkeypatch, patch_run_in_thread):
    """Defensive — exercice référence un og_id qui n'existe pas → 404."""
    monkeypatch.setattr(
        document_service.document_repo, "exercice_lookup", lambda _: _make_exercice_lookup()
    )
    monkeypatch.setattr(document_service.og_repo, "get_by_id", lambda _: None)

    with pytest.raises(NotFoundError) as exc:
        await document_service.create_document(
            COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="ercp")
        )
    assert exc.value.code == "og_not_found_for_document_create"
