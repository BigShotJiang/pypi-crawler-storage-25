"""Tests §X — guards ``feature_not_available_for_eps`` sur 9 services.

KB22 §3 + KB25 §15+§16 confirment que ERCP/EPCP n'ont pas :
* Bilan financier séparé
* Tableau de financement (TF)
* PGFP
* TPER/TER (personnel dans le système hospitalier global)
* Annexe 4 (activité GIR)
* Annexe 5 (forfait financière)
* Provisions / Emprunts / RCC

Le helper ``document_scope.assert_not_eps_only_doc`` est branché dans
chacun de ces 9 services. Ce test exerce le guard helper directement
(les tests par-service couvrent déjà le wiring du freeze §S — le
guard EPS suit le même pattern).

Plus 2 tests d'intégration sur 2 des services pour vérifier que le
guard est bien appelé (par ricochet via le helper unmocké)."""

from __future__ import annotations

from uuid import uuid4

import pytest

from piilot_pack_compta_esms.services import document_scope
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

DOC_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.document_scope.run_in_thread",
        _passthrough,
    )


def _doc(type_document: str) -> dict:
    return {
        "id": DOC_ID,
        "type_document": type_document,
        "company_id": uuid4(),
        "statut": "brouillon",
    }


# ---------------------------------------------------------------------------
# assert_not_eps_only_doc — direct helper coverage
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_assert_not_eps_refuses_ercp(monkeypatch):
    """ERCP → 409 feature_not_available_for_eps."""
    # Override l'autouse fixture (qui mocke assert_not_eps_only_doc en
    # no-op) — on recharge le module pour récupérer le helper réel.
    import importlib

    from piilot_pack_compta_esms.services import document_scope as ds_module

    importlib.reload(ds_module)
    monkeypatch.setattr(ds_module.document_repo, "get_by_id", lambda _: _doc("ercp"))

    async def _passthrough_run(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(ds_module, "run_in_thread", _passthrough_run)

    with pytest.raises(ConflictError) as exc:
        await ds_module.assert_not_eps_only_doc(DOC_ID)
    assert exc.value.code == "feature_not_available_for_eps"


@pytest.mark.asyncio
async def test_assert_not_eps_refuses_epcp(monkeypatch):
    """EPCP → 409 feature_not_available_for_eps."""
    import importlib

    from piilot_pack_compta_esms.services import document_scope as ds_module

    importlib.reload(ds_module)
    monkeypatch.setattr(ds_module.document_repo, "get_by_id", lambda _: _doc("epcp"))

    async def _passthrough_run(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(ds_module, "run_in_thread", _passthrough_run)

    with pytest.raises(ConflictError) as exc:
        await ds_module.assert_not_eps_only_doc(DOC_ID)
    assert exc.value.code == "feature_not_available_for_eps"


@pytest.mark.asyncio
async def test_assert_not_eps_passes_eprd(monkeypatch):
    """EPRD → no-op (le helper passe sans rien lever)."""
    import importlib

    from piilot_pack_compta_esms.services import document_scope as ds_module

    importlib.reload(ds_module)
    monkeypatch.setattr(ds_module.document_repo, "get_by_id", lambda _: _doc("eprd"))

    async def _passthrough_run(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(ds_module, "run_in_thread", _passthrough_run)

    # Pas d'exception attendue
    await ds_module.assert_not_eps_only_doc(DOC_ID)


@pytest.mark.asyncio
async def test_assert_not_eps_passes_errd(monkeypatch):
    """ERRD → no-op."""
    import importlib

    from piilot_pack_compta_esms.services import document_scope as ds_module

    importlib.reload(ds_module)
    monkeypatch.setattr(ds_module.document_repo, "get_by_id", lambda _: _doc("errd"))

    async def _passthrough_run(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(ds_module, "run_in_thread", _passthrough_run)

    await ds_module.assert_not_eps_only_doc(DOC_ID)


@pytest.mark.asyncio
async def test_assert_not_eps_404_if_doc_missing(monkeypatch):
    """Defensive — doc inexistant → 404 document_not_found."""
    import importlib

    from piilot_pack_compta_esms.services import document_scope as ds_module

    importlib.reload(ds_module)
    monkeypatch.setattr(ds_module.document_repo, "get_by_id", lambda _: None)

    async def _passthrough_run(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(ds_module, "run_in_thread", _passthrough_run)

    with pytest.raises(NotFoundError) as exc:
        await ds_module.assert_not_eps_only_doc(DOC_ID)
    assert exc.value.code == "document_not_found"


# ---------------------------------------------------------------------------
# resolve_plan_comptable
# ---------------------------------------------------------------------------


def test_resolve_plan_comptable_returns_m21_for_ercp_epcp() -> None:
    assert document_scope.resolve_plan_comptable("ercp") == "M21"
    assert document_scope.resolve_plan_comptable("epcp") == "M21"


def test_resolve_plan_comptable_returns_m22bis_otherwise() -> None:
    assert document_scope.resolve_plan_comptable("eprd") == "M22Bis"
    assert document_scope.resolve_plan_comptable("errd") == "M22Bis"
    assert document_scope.resolve_plan_comptable("dm") == "M22Bis"
    assert document_scope.resolve_plan_comptable("ria") == "M22Bis"
    assert document_scope.resolve_plan_comptable("avenant") == "M22Bis"
