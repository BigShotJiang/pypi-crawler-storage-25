"""Tests for valeur point GIR resolver (§I.8, F.GIR.01).

Cas réels DGCS sourcés ``S03`` p.21 + R.314-175 (clapet + TVA privé)."""

from __future__ import annotations

from decimal import Decimal

import pytest

from piilot_pack_compta_esms.models.finance import ValeurPointGirInput
from piilot_pack_compta_esms.services import reference_lookup
from piilot_pack_compta_esms.services.finance import (
    valeur_point_gir_resolver as resolver,
)


@pytest.fixture
def vpg_cache(monkeypatch):
    """Pre-populate the reference_lookup VPG cache so tests don't hit
    the DB. Each test sets the desired dataset via _override()."""

    def _override(data: dict[tuple[str, int], Decimal]):
        # Replace the global cache dict directly — simpler than
        # mocking the run_in_thread loader.
        monkeypatch.setattr(reference_lookup, "_VPG_CACHE", data)

    return _override


@pytest.mark.asyncio
async def test_lookup_happy(vpg_cache):
    """Valeur N existe, valeur N-1 absente → retour brute, pas de clapet."""
    vpg_cache({("75", 2026): Decimal("12.50")})
    out = await resolver.resolve_valeur_point_gir(
        ValeurPointGirInput(code_departement="75", annee=2026)
    )
    assert out.valeur == Decimal("12.50")
    assert out.valeur_brute == Decimal("12.50")
    assert out.clapet_applique is False
    assert out.fallback_annee == 2026
    assert out.est_prive_commercial is False


@pytest.mark.asyncio
async def test_clapet_anti_retour_enforce(vpg_cache):
    """R.314-175 — valeur(N) < valeur(N-1) → on retourne valeur(N-1),
    flag clapet_applique=True."""
    vpg_cache(
        {
            ("75", 2026): Decimal("11.80"),  # N : régression
            ("75", 2025): Decimal("12.50"),  # N-1
        }
    )
    out = await resolver.resolve_valeur_point_gir(
        ValeurPointGirInput(code_departement="75", annee=2026)
    )
    assert out.valeur == Decimal("12.50")
    assert out.valeur_brute == Decimal("11.80")
    assert out.clapet_applique is True
    assert out.fallback_annee == 2025


@pytest.mark.asyncio
async def test_fallback_annee_when_n_missing(vpg_cache):
    """KB ref n'a pas encore la valeur N → fallback N-1."""
    vpg_cache({("75", 2025): Decimal("12.50")})
    out = await resolver.resolve_valeur_point_gir(
        ValeurPointGirInput(code_departement="75", annee=2026)
    )
    assert out.valeur == Decimal("12.50")
    assert out.valeur_brute is None
    assert out.clapet_applique is False
    assert out.fallback_annee == 2025


@pytest.mark.asyncio
async def test_prive_commercial_applies_tva(vpg_cache):
    """Prive commercial → valeur × 1.055 (TVA 5.5%, S03 p.21)."""
    vpg_cache({("75", 2026): Decimal("12.50")})
    out = await resolver.resolve_valeur_point_gir(
        ValeurPointGirInput(
            code_departement="75",
            annee=2026,
            est_prive_commercial=True,
        )
    )
    # 12.50 × 1.055 = 13.1875
    assert out.valeur == Decimal("13.1875")
    assert out.valeur_brute == Decimal("12.50")
    assert out.est_prive_commercial is True


@pytest.mark.asyncio
async def test_kb_ref_empty_returns_none(vpg_cache):
    """KB ref vide / pas synced → valeur None, fallback None."""
    vpg_cache({})
    out = await resolver.resolve_valeur_point_gir(
        ValeurPointGirInput(code_departement="75", annee=2026)
    )
    assert out.valeur is None
    assert out.valeur_brute is None
    assert out.clapet_applique is False
    assert out.fallback_annee is None


@pytest.mark.asyncio
async def test_reference_lookup_helper_with_clapet(vpg_cache):
    """Helper bas niveau reference_lookup.valeur_point_gir_with_clapet :
    teste séparément du resolver pour confirmer le pattern §E.1."""
    vpg_cache(
        {
            ("33", 2026): Decimal("11.00"),  # régression
            ("33", 2025): Decimal("12.00"),
        }
    )
    valeur, clapet, fallback = await reference_lookup.valeur_point_gir_with_clapet("33", 2026)
    assert valeur == Decimal("12.00")
    assert clapet is True
    assert fallback == 2025


@pytest.mark.asyncio
async def test_reference_lookup_raw_valeur_point_gir(vpg_cache):
    """Helper bas niveau reference_lookup.valeur_point_gir : raw lookup
    sans clapet."""
    vpg_cache({("33", 2026): Decimal("11.00")})
    valeur = await reference_lookup.valeur_point_gir("33", 2026)
    assert valeur == Decimal("11.00")
    valeur_missing = await reference_lookup.valeur_point_gir("99", 2026)
    assert valeur_missing is None
