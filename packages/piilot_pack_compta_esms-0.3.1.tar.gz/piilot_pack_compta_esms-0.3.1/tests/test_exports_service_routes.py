"""Tests §AB — service exports + routes.

Couvre :

* export_xlsx 422 si type_document != errd
* export_xlsx 404 cross-tenant
* export_xlsx happy → upload S3 + DB row
* list_exports retourne actifs (deleted_at NULL)
* get_download 404 + 409 si soft-deleted
* delete_export idempotent
* routes POST/GET/DELETE smoke
* route /export/docx → 501 stub
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import _limiter as limiter_module
from piilot_pack_compta_esms.routes import exports as exports_routes
from piilot_pack_compta_esms.services import exports_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
    ValidationError,
)

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
EXPORT_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)


def _doc(type_document="errd"):
    return {
        "id": DOC_ID,
        "company_id": COMPANY,
        "type_document": type_document,
        "statut": "brouillon",
        "exercice_id": uuid4(),
        "cadre_version": "#ERRDHA-2025-01#",
        "parent_id": None,
        "periode_observation_debut": None,
        "periode_observation_fin": None,
        "transmis_at": None,
        "executoire_at": None,
        "transmis_par_user_id": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }


def _export_row(deleted: bool = False):
    return {
        "id": EXPORT_ID,
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "type": "xlsx",
        "s3_key": f"exports/{COMPANY}/{DOC_ID}/{EXPORT_ID}/ERRD_2025.xlsx",
        "filename": "ERRD_2025.xlsx",
        "file_size": 1234,
        "generated_by_user_id": USER,
        "generated_at": datetime.now(UTC),
        "deleted_at": datetime.now(UTC) if deleted else None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.exports_service.run_in_thread",
        _passthrough,
    )


# ---------------------------------------------------------------------------
# export_xlsx service
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_export_xlsx_404_cross_tenant(monkeypatch, patch_run_in_thread):
    other = _doc()
    other["company_id"] = uuid4()
    monkeypatch.setattr(exports_service.document_repo, "get_by_id", lambda d: other)
    with pytest.raises(NotFoundError):
        await exports_service.export_xlsx(DOC_ID, COMPANY, user_id=USER)


@pytest.mark.asyncio
async def test_export_xlsx_422_for_eprd(monkeypatch, patch_run_in_thread):
    """v0.2 supporte ERRD only — autres types refusés 422."""
    monkeypatch.setattr(exports_service.document_repo, "get_by_id", lambda d: _doc("eprd"))
    with pytest.raises(ValidationError) as exc:
        await exports_service.export_xlsx(DOC_ID, COMPANY, user_id=USER)
    assert exc.value.code == "xlsx_only_errd_v02"


@pytest.mark.asyncio
async def test_export_xlsx_happy_uploads_and_persists(monkeypatch, patch_run_in_thread):
    """Happy path : build workbook + storage.put_object + repo.create."""
    monkeypatch.setattr(exports_service.document_repo, "get_by_id", lambda d: _doc("errd"))
    monkeypatch.setattr(
        exports_service.document_repo,
        "exercice_lookup",
        lambda eid: {"id": eid, "company_id": COMPANY, "og_id": uuid4(), "annee": 2025},
    )

    async def _fake_build(*args, **kwargs):
        return b"FAKE XLSX BYTES"

    monkeypatch.setattr(exports_service.workbook_builder, "build_errd_workbook", _fake_build)

    s3_calls: list = []

    async def _fake_put(key, body, content_type):
        s3_calls.append({"key": key, "size": len(body), "content_type": content_type})
        return f"plugins/compta_esms/{key}"

    monkeypatch.setattr(exports_service.storage, "put_object", _fake_put)

    monkeypatch.setattr(
        exports_service.exports_repo,
        "create",
        lambda **kw: _export_row(),
    )

    out = await exports_service.export_xlsx(DOC_ID, COMPANY, user_id=USER)
    assert out.type == "xlsx"
    assert out.file_size == 1234  # depuis _export_row
    assert len(s3_calls) == 1
    assert s3_calls[0]["size"] == len(b"FAKE XLSX BYTES")
    assert s3_calls[0]["content_type"] == exports_service.XLSX_CONTENT_TYPE


@pytest.mark.asyncio
async def test_export_xlsx_pipe_char_422(monkeypatch, patch_run_in_thread):
    """Si une cellule contient `|`, le builder lève ValueError → service
    re-raise en ValidationError(pipe_char_forbidden)."""
    monkeypatch.setattr(exports_service.document_repo, "get_by_id", lambda d: _doc("errd"))
    monkeypatch.setattr(
        exports_service.document_repo,
        "exercice_lookup",
        lambda eid: {"id": eid, "company_id": COMPANY, "og_id": uuid4(), "annee": 2025},
    )

    async def _fake_build(*args, **kwargs):
        raise ValueError("pipe_char_forbidden:caractère '|' interdit")

    monkeypatch.setattr(exports_service.workbook_builder, "build_errd_workbook", _fake_build)

    with pytest.raises(ValidationError) as exc:
        await exports_service.export_xlsx(DOC_ID, COMPANY, user_id=USER)
    assert exc.value.code == "pipe_char_forbidden"


# ---------------------------------------------------------------------------
# list_exports
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_exports_returns_actives(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(exports_service.document_repo, "get_by_id", lambda d: _doc("errd"))
    monkeypatch.setattr(
        exports_service.exports_repo,
        "list_by_document",
        lambda d: [_export_row(), _export_row()],
    )
    out = await exports_service.list_exports(DOC_ID, COMPANY)
    assert len(out) == 2


# ---------------------------------------------------------------------------
# get_download
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_download_404_missing(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(exports_service.exports_repo, "get_by_id", lambda e: None)
    with pytest.raises(NotFoundError):
        await exports_service.get_download(EXPORT_ID, COMPANY)


@pytest.mark.asyncio
async def test_get_download_404_cross_tenant(monkeypatch, patch_run_in_thread):
    row = _export_row()
    row["company_id"] = uuid4()
    monkeypatch.setattr(exports_service.exports_repo, "get_by_id", lambda e: row)
    with pytest.raises(NotFoundError):
        await exports_service.get_download(EXPORT_ID, COMPANY)


@pytest.mark.asyncio
async def test_get_download_409_if_deleted(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        exports_service.exports_repo, "get_by_id", lambda e: _export_row(deleted=True)
    )
    with pytest.raises(ConflictError) as exc:
        await exports_service.get_download(EXPORT_ID, COMPANY)
    assert exc.value.code == "export_deleted"


@pytest.mark.asyncio
async def test_get_download_happy(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(exports_service.exports_repo, "get_by_id", lambda e: _export_row())

    async def _fake_get(key):
        return b"DOWNLOADED BYTES"

    monkeypatch.setattr(exports_service.storage, "get_object", _fake_get)

    bytes_data, filename, content_type = await exports_service.get_download(EXPORT_ID, COMPANY)
    assert bytes_data == b"DOWNLOADED BYTES"
    assert filename == "ERRD_2025.xlsx"
    assert content_type == exports_service.XLSX_CONTENT_TYPE


# ---------------------------------------------------------------------------
# delete_export
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_delete_export_404_missing(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(exports_service.exports_repo, "get_by_id", lambda e: None)
    with pytest.raises(NotFoundError):
        await exports_service.delete_export(EXPORT_ID, COMPANY)


@pytest.mark.asyncio
async def test_delete_export_idempotent(monkeypatch, patch_run_in_thread):
    """Soft-delete déjà effectué → 204 silencieux."""
    monkeypatch.setattr(
        exports_service.exports_repo,
        "get_by_id",
        lambda e: _export_row(deleted=True),
    )
    calls = []
    monkeypatch.setattr(
        exports_service.exports_repo,
        "soft_delete",
        lambda e: calls.append(e) or False,
    )
    await exports_service.delete_export(EXPORT_ID, COMPANY)
    assert len(calls) == 1


# ---------------------------------------------------------------------------
# Routes — TestClient
# ---------------------------------------------------------------------------


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter_module.limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(exports_routes.router_under_doc, prefix="/plugins/compta_esms")
    app.include_router(exports_routes.router_flat, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


def test_route_post_export_xlsx_200(app, monkeypatch):
    from piilot_pack_compta_esms.services.exports_service import ExportRead

    async def _fake(*args, **kwargs):
        return ExportRead.model_validate(_export_row())

    monkeypatch.setattr(exports_service, "export_xlsx", _fake)

    client = TestClient(app)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/export/xlsx")
    assert r.status_code == 200
    body = r.json()
    assert body["type"] == "xlsx"


def test_route_post_export_docx_200(app, monkeypatch):
    """§AC livré — route DOCX retourne 200 + ExportRead (plus de 501)."""
    from piilot_pack_compta_esms.services.exports_service import ExportRead

    async def _fake(*args, **kwargs):
        return ExportRead.model_validate({**_export_row(), "type": "docx"})

    monkeypatch.setattr(exports_service, "export_docx", _fake)

    client = TestClient(app)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/export/docx")
    assert r.status_code == 200
    body = r.json()
    assert body["type"] == "docx"


def test_route_get_exports_200(app, monkeypatch):
    from piilot_pack_compta_esms.services.exports_service import ExportRead

    async def _fake(*args, **kwargs):
        return [ExportRead.model_validate(_export_row())]

    monkeypatch.setattr(exports_service, "list_exports", _fake)

    client = TestClient(app)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/exports")
    assert r.status_code == 200
    assert len(r.json()) == 1


def test_route_get_download_200(app, monkeypatch):
    async def _fake(*args, **kwargs):
        return (b"XLSX BYTES", "ERRD_2025.xlsx", exports_service.XLSX_CONTENT_TYPE)

    monkeypatch.setattr(exports_service, "get_download", _fake)

    client = TestClient(app)
    r = client.get(f"/plugins/compta_esms/exports/{EXPORT_ID}/download")
    assert r.status_code == 200
    assert r.content == b"XLSX BYTES"
    assert "ERRD_2025.xlsx" in r.headers["content-disposition"]


def test_route_delete_export_204(app, monkeypatch):
    async def _fake(*args, **kwargs):
        return None

    monkeypatch.setattr(exports_service, "delete_export", _fake)

    client = TestClient(app)
    r = client.delete(f"/plugins/compta_esms/exports/{EXPORT_ID}")
    assert r.status_code == 204
