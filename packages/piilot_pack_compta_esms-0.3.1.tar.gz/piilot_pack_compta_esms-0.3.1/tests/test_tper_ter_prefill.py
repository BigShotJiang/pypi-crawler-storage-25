"""Unit tests for :mod:`piilot_pack_compta_esms.services.tper_ter_prefill`."""

from __future__ import annotations

from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.kb_binding import (
    BindingPreviewResponse,
    BindingPreviewRow,
)
from piilot_pack_compta_esms.services import tper_ter_prefill
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
DOC_ID = uuid4()
ETS_ID = uuid4()
BINDING_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.tper_ter_prefill.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def valid_doc_ehpad(monkeypatch):
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "get_ets_typologie",
        lambda ets, company: {"typologie": "ehpad"},
    )


def _preview(rows: list[dict]) -> BindingPreviewResponse:
    return BindingPreviewResponse(
        feature_key="tper_effectifs",
        rows=[BindingPreviewRow(data=r) for r in rows],
        row_count=len(rows),
    )


# ---------------------------------------------------------------------------
# prefill_from_binding — happy path
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_prefill_inserts_new_rows(patch_run_in_thread, valid_doc_ehpad, monkeypatch):
    """KB preview a 2 rows, DB vide → 2 inserted."""
    monkeypatch.setattr(
        tper_ter_prefill.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, feature: {"id": BINDING_ID, "kb_id": uuid4()},
    )
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "list_existing_keys",
        lambda doc, ets, t: set(),
    )

    async def _fake_preview(**kwargs):
        return _preview(
            [
                {
                    "categorie_cnsa": "INFIRMIERS",
                    "fonction": "IDE",
                    "etpr": "5",
                    "etpt": "5",
                    "remunerations": "200000",
                },
                {
                    "categorie_cnsa": "DIRECTION_ADMINISTRATION",
                    "fonction": "Directeur",
                    "etpr": "1",
                    "etpt": "1",
                    "remunerations": "80000",
                },
            ]
        )

    monkeypatch.setattr(tper_ter_prefill.binding_service, "preview_binding", _fake_preview)

    inserts = []

    def _insert(**kwargs):
        inserts.append(kwargs)
        return {}

    monkeypatch.setattr(tper_ter_prefill.tper_ter_repo, "insert_one", _insert)

    result = await tper_ter_prefill.prefill_from_binding(
        document_id=DOC_ID,
        company_id=COMPANY,
        ets_id=ETS_ID,
        type_tableau="TPER",
    )

    assert result.inserted == 2
    assert result.skipped == 0
    assert len(inserts) == 2
    # Default type_poste='P' applied (v0.2 limitation)
    assert inserts[0]["item"]["type_poste"] == "P"
    # TPER → col_etpr=etpr_prevus
    assert "etpr_prevus" in inserts[0]["item"]
    assert inserts[0]["item"]["etpr_prevus"] == Decimal("5")


@pytest.mark.asyncio
async def test_prefill_skips_existing_keys(patch_run_in_thread, valid_doc_ehpad, monkeypatch):
    """1 row déjà saisie (natural key) → skip + 1 inserted."""
    monkeypatch.setattr(
        tper_ter_prefill.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, feature: {"id": BINDING_ID, "kb_id": uuid4()},
    )
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "list_existing_keys",
        lambda doc, ets, t: {("INFIRMIERS", "IDE", "P")},
    )

    async def _fake_preview(**kwargs):
        return _preview(
            [
                {
                    "categorie_cnsa": "INFIRMIERS",
                    "fonction": "IDE",
                    "etpr": "5",
                },
                {
                    "categorie_cnsa": "DIRECTION_ADMINISTRATION",
                    "fonction": "Directeur",
                    "etpr": "1",
                },
            ]
        )

    monkeypatch.setattr(tper_ter_prefill.binding_service, "preview_binding", _fake_preview)

    inserts = []
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "insert_one",
        lambda **kw: inserts.append(kw) or {},
    )

    result = await tper_ter_prefill.prefill_from_binding(
        document_id=DOC_ID,
        company_id=COMPANY,
        ets_id=ETS_ID,
        type_tableau="TPER",
    )

    assert result.inserted == 1
    assert result.skipped == 1
    assert inserts[0]["item"]["categorie_cnsa"] == "DIRECTION_ADMINISTRATION"


@pytest.mark.asyncio
async def test_prefill_ter_uses_realises_columns(patch_run_in_thread, valid_doc_ehpad, monkeypatch):
    """type_tableau=TER → col_etpr=etpr_realises (pas etpr_prevus)."""
    monkeypatch.setattr(
        tper_ter_prefill.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, feature: {"id": BINDING_ID, "kb_id": uuid4()},
    )
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "list_existing_keys",
        lambda doc, ets, t: set(),
    )

    async def _fake_preview(**kwargs):
        # Vérifier que la bonne feature_key est utilisée
        assert kwargs["feature_key"] == "ter_effectifs"
        return _preview([{"categorie_cnsa": "INFIRMIERS", "fonction": "IDE", "etpr": "3"}])

    monkeypatch.setattr(tper_ter_prefill.binding_service, "preview_binding", _fake_preview)

    inserts = []
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "insert_one",
        lambda **kw: inserts.append(kw) or {},
    )

    result = await tper_ter_prefill.prefill_from_binding(
        document_id=DOC_ID,
        company_id=COMPANY,
        ets_id=ETS_ID,
        type_tableau="TER",
    )

    assert result.inserted == 1
    assert "etpr_realises" in inserts[0]["item"]
    assert "etpr_prevus" not in inserts[0]["item"]


@pytest.mark.asyncio
async def test_prefill_skips_rows_without_categorie(
    patch_run_in_thread, valid_doc_ehpad, monkeypatch
):
    """Rows sans categorie_cnsa = malformed → skipped."""
    monkeypatch.setattr(
        tper_ter_prefill.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, feature: {"id": BINDING_ID, "kb_id": uuid4()},
    )
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "list_existing_keys",
        lambda doc, ets, t: set(),
    )

    async def _fake_preview(**kwargs):
        return _preview([{"fonction": "IDE", "etpr": "3"}])  # no categorie

    monkeypatch.setattr(tper_ter_prefill.binding_service, "preview_binding", _fake_preview)

    inserts = []
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "insert_one",
        lambda **kw: inserts.append(kw) or {},
    )

    result = await tper_ter_prefill.prefill_from_binding(
        document_id=DOC_ID,
        company_id=COMPANY,
        ets_id=ETS_ID,
        type_tableau="TPER",
    )

    assert result.inserted == 0
    assert result.skipped == 1


@pytest.mark.asyncio
async def test_prefill_binding_not_configured(patch_run_in_thread, valid_doc_ehpad, monkeypatch):
    monkeypatch.setattr(
        tper_ter_prefill.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, feature: None,
    )

    with pytest.raises(NotFoundError) as exc:
        await tper_ter_prefill.prefill_from_binding(
            document_id=DOC_ID,
            company_id=COMPANY,
            ets_id=ETS_ID,
            type_tableau="TPER",
        )
    assert exc.value.code == "binding_not_configured"


@pytest.mark.asyncio
async def test_prefill_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    with pytest.raises(NotFoundError) as exc:
        await tper_ter_prefill.prefill_from_binding(
            document_id=DOC_ID,
            company_id=COMPANY,
            ets_id=ETS_ID,
            type_tableau="TPER",
        )
    assert exc.value.code == "document_not_found"


@pytest.mark.asyncio
async def test_prefill_ets_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "get_ets_typologie",
        lambda ets, company: None,
    )

    with pytest.raises(NotFoundError) as exc:
        await tper_ter_prefill.prefill_from_binding(
            document_id=DOC_ID,
            company_id=COMPANY,
            ets_id=ETS_ID,
            type_tableau="TPER",
        )
    assert exc.value.code == "etablissement_not_found"


# ---------------------------------------------------------------------------
# §BJ — type_poste mappé depuis le binding (D3 contract)
# ---------------------------------------------------------------------------


def test_resolve_type_poste_helper_normalizes_values() -> None:
    """Helper pure : 'P'/'T' (toute casse) → conservé, autre → 'P'."""
    assert tper_ter_prefill._resolve_type_poste("P") == "P"
    assert tper_ter_prefill._resolve_type_poste("T") == "T"
    assert tper_ter_prefill._resolve_type_poste("p") == "P"  # casse normalisée
    assert tper_ter_prefill._resolve_type_poste("t") == "T"
    assert tper_ter_prefill._resolve_type_poste(" P ") == "P"  # whitespace
    # Fallback 'P' pour valeurs non-DGCS
    assert tper_ter_prefill._resolve_type_poste(None) == "P"
    assert tper_ter_prefill._resolve_type_poste("") == "P"
    assert tper_ter_prefill._resolve_type_poste("X") == "P"
    assert tper_ter_prefill._resolve_type_poste("CDI") == "P"  # libellé verbeux
    assert tper_ter_prefill._resolve_type_poste(42) == "P"  # type non-str


@pytest.mark.asyncio
async def test_prefill_consumes_mapped_type_poste_t(
    patch_run_in_thread, valid_doc_ehpad, monkeypatch
):
    """§BJ — row preview avec type_poste='T' → inséré avec type_poste='T'.

    Garantit que le binding peut désormais distinguer P (permanents) et
    T (temporaires) via le contrat type_poste exposé en migration 023.
    """
    monkeypatch.setattr(
        tper_ter_prefill.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, feature: {"id": BINDING_ID, "kb_id": uuid4()},
    )
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "list_existing_keys",
        lambda doc, ets, t: set(),
    )

    async def _fake_preview(**kwargs):
        return _preview(
            [
                {
                    "categorie_cnsa": "INFIRMIERS",
                    "fonction": "IDE",
                    "type_poste": "T",  # ← mappé temporaire
                    "etpr": "2",
                    "etpt": "1.5",
                    "remunerations": "60000",
                },
            ]
        )

    monkeypatch.setattr(tper_ter_prefill.binding_service, "preview_binding", _fake_preview)

    inserts: list[dict] = []
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "insert_one",
        lambda **kw: inserts.append(kw) or {},
    )

    result = await tper_ter_prefill.prefill_from_binding(
        document_id=DOC_ID,
        company_id=COMPANY,
        ets_id=ETS_ID,
        type_tableau="TPER",
    )

    assert result.inserted == 1
    assert inserts[0]["item"]["type_poste"] == "T"


@pytest.mark.asyncio
async def test_prefill_natural_key_uses_mapped_type_poste(
    patch_run_in_thread, valid_doc_ehpad, monkeypatch
):
    """§BJ — un (cat, fonction, 'P') existant n'empêche pas un INSERT
    de la même (cat, fonction, 'T'). Garantit que le dedup natural key
    discrimine sur type_poste mappé.
    """
    monkeypatch.setattr(
        tper_ter_prefill.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, feature: {"id": BINDING_ID, "kb_id": uuid4()},
    )
    # Une row 'P' existe déjà ; le 'T' incoming doit passer (clé distincte).
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "list_existing_keys",
        lambda doc, ets, t: {("INFIRMIERS", "IDE", "P")},
    )

    async def _fake_preview(**kwargs):
        return _preview(
            [
                {"categorie_cnsa": "INFIRMIERS", "fonction": "IDE", "type_poste": "T", "etpr": "1"},
                {"categorie_cnsa": "INFIRMIERS", "fonction": "IDE", "type_poste": "P", "etpr": "5"},
            ]
        )

    monkeypatch.setattr(tper_ter_prefill.binding_service, "preview_binding", _fake_preview)

    inserts: list[dict] = []
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "insert_one",
        lambda **kw: inserts.append(kw) or {},
    )

    result = await tper_ter_prefill.prefill_from_binding(
        document_id=DOC_ID,
        company_id=COMPANY,
        ets_id=ETS_ID,
        type_tableau="TPER",
    )

    # La row 'T' passe (clé distincte), la row 'P' skip (déjà saisie).
    assert result.inserted == 1
    assert result.skipped == 1
    assert inserts[0]["item"]["type_poste"] == "T"


@pytest.mark.asyncio
async def test_prefill_falls_back_to_p_when_type_poste_missing(
    patch_run_in_thread, valid_doc_ehpad, monkeypatch
):
    """§BJ rétrocompat — binding v0.2 sans mapping type_poste → fallback 'P'.

    Garantit que les bindings existants (qui ne mappaient pas type_poste,
    cf. contrat avant migration 023) continuent à fonctionner avec
    type_poste='P' implicite.
    """
    monkeypatch.setattr(
        tper_ter_prefill.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, feature: {"id": BINDING_ID, "kb_id": uuid4()},
    )
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "list_existing_keys",
        lambda doc, ets, t: set(),
    )

    async def _fake_preview(**kwargs):
        # Row sans clé type_poste (binding pré-§BJ)
        return _preview([{"categorie_cnsa": "INFIRMIERS", "fonction": "IDE", "etpr": "5"}])

    monkeypatch.setattr(tper_ter_prefill.binding_service, "preview_binding", _fake_preview)

    inserts: list[dict] = []
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "insert_one",
        lambda **kw: inserts.append(kw) or {},
    )

    result = await tper_ter_prefill.prefill_from_binding(
        document_id=DOC_ID,
        company_id=COMPANY,
        ets_id=ETS_ID,
        type_tableau="TPER",
    )

    assert result.inserted == 1
    assert inserts[0]["item"]["type_poste"] == "P"


@pytest.mark.asyncio
async def test_prefill_invalid_type_poste_falls_back_to_p(
    patch_run_in_thread, valid_doc_ehpad, monkeypatch
):
    """§BJ — type_poste invalide (ex: 'CDI', 'X') → fallback 'P'.

    Protection CHECK constraint DB ``tper_ter_lignes_type_poste_check``
    (migration 012) qui n'accepte que {'P', 'T'} : un mapping incorrect
    ne doit pas faire échouer l'INSERT.
    """
    monkeypatch.setattr(
        tper_ter_prefill.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, feature: {"id": BINDING_ID, "kb_id": uuid4()},
    )
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "list_existing_keys",
        lambda doc, ets, t: set(),
    )

    async def _fake_preview(**kwargs):
        return _preview(
            [
                {
                    "categorie_cnsa": "INFIRMIERS",
                    "fonction": "IDE",
                    "type_poste": "CDI",  # ← valeur non-DGCS
                    "etpr": "5",
                },
            ]
        )

    monkeypatch.setattr(tper_ter_prefill.binding_service, "preview_binding", _fake_preview)

    inserts: list[dict] = []
    monkeypatch.setattr(
        tper_ter_prefill.tper_ter_repo,
        "insert_one",
        lambda **kw: inserts.append(kw) or {},
    )

    result = await tper_ter_prefill.prefill_from_binding(
        document_id=DOC_ID,
        company_id=COMPANY,
        ets_id=ETS_ID,
        type_tableau="TPER",
    )

    assert result.inserted == 1
    assert inserts[0]["item"]["type_poste"] == "P"
