"""Unit tests for :mod:`piilot_pack_compta_esms.services.annexe5_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.annexe5 import (
    Annexe5BulkUpsertRequest,
    Annexe5LigneCreate,
)
from piilot_pack_compta_esms.services import annexe5_service
from piilot_pack_compta_esms.services.errors import NotFoundError, ValidationError

COMPANY = uuid4()
DOC_ID = uuid4()
ETS_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.annexe5_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def valid_doc_ehpad(monkeypatch):
    """Doc OK + ETS typologie=ehpad → variante déductible 5A."""
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "get_ets_typologie",
        lambda ets, company: {"typologie": "ehpad"},
    )


def _row(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "etablissement_id": ETS_ID,
        "variante": "5A_ehpad",
        "compte_m22bis": "611",
        "compte_label": "Sous-traitance",
        "nature": "charge",
        "montant_hebergement_n1": Decimal("1000"),
        "montant_hebergement_n": Decimal("1050"),
        "montant_dependance_n1": None,
        "montant_dependance_n": None,
        "montant_soins_n1": None,
        "montant_soins_n": None,
        "montant_sea_n1": None,
        "montant_sea_n": None,
        "montant_budget_global_n1": None,
        "montant_budget_global_n": None,
        "montant_forfait_soins_n1": None,
        "montant_forfait_soins_n": None,
        "montant_soins_sad_n1": None,
        "montant_soins_sad_n": None,
        "montant_aide_acc_n1": None,
        "montant_aide_acc_n": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# list_annexe5
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_no_filters_returns_all(patch_run_in_thread, valid_doc_ehpad, monkeypatch):
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "list_by_filter",
        lambda doc, ets=None, variante=None: [_row(), _row(variante="5C_fam_samsah")],
    )

    result = await annexe5_service.list_annexe5(DOC_ID, COMPANY)

    assert result.ets_id_filtre is None
    assert result.variante_filtre is None
    assert len(result.items) == 2


@pytest.mark.asyncio
async def test_list_with_filters(patch_run_in_thread, valid_doc_ehpad, monkeypatch):
    captured = {}

    def _list(doc, ets=None, variante=None):
        captured["ets"] = ets
        captured["variante"] = variante
        return [_row()]

    monkeypatch.setattr(annexe5_service.annexe5_repo, "list_by_filter", _list)

    result = await annexe5_service.list_annexe5(DOC_ID, COMPANY, ets_id=ETS_ID, variante="5A_ehpad")

    assert captured["ets"] == ETS_ID
    assert captured["variante"] == "5A_ehpad"
    assert result.variante_filtre == "5A_ehpad"


@pytest.mark.asyncio
async def test_list_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    with pytest.raises(NotFoundError) as exc:
        await annexe5_service.list_annexe5(DOC_ID, COMPANY)
    assert exc.value.code == "document_not_found"


# ---------------------------------------------------------------------------
# bulk_upsert_annexe5 — Q6 auto-déduction
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_upsert_ehpad_eligible(patch_run_in_thread, valid_doc_ehpad, monkeypatch):
    """Q6 — ETS typologie=ehpad → eligible → bulk-upsert OK."""
    captured = {}

    def _replace(**kwargs):
        captured.update(kwargs)
        return []

    monkeypatch.setattr(annexe5_service.annexe5_repo, "replace_by_doc_ets_variante", _replace)
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "list_by_filter",
        lambda d, e=None, v=None: [],
    )

    payload = Annexe5BulkUpsertRequest(
        ets_id=ETS_ID,
        variante="5A_ehpad",
        items=[
            Annexe5LigneCreate(
                compte_m22bis="611",
                nature="charge",
                montant_hebergement_n=Decimal("1000"),
            ),
        ],
    )
    await annexe5_service.bulk_upsert_annexe5(DOC_ID, COMPANY, payload)

    assert captured["variante"] == "5A_ehpad"
    assert captured["etablissement_id"] == ETS_ID
    assert len(captured["items"]) == 1


@pytest.mark.asyncio
async def test_bulk_upsert_fam_eligible(patch_run_in_thread, monkeypatch):
    """Q6 — ETS typologie=fam → eligible → bulk-upsert OK avec 5C."""
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "get_ets_typologie",
        lambda ets, company: {"typologie": "fam"},
    )
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "replace_by_doc_ets_variante",
        lambda **kw: [],
    )
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "list_by_filter",
        lambda d, e=None, v=None: [],
    )

    payload = Annexe5BulkUpsertRequest(ets_id=ETS_ID, variante="5C_fam_samsah", items=[])
    result = await annexe5_service.bulk_upsert_annexe5(DOC_ID, COMPANY, payload)
    assert result.variante_filtre == "5C_fam_samsah"


@pytest.mark.asyncio
async def test_bulk_upsert_sad_eligible(patch_run_in_thread, monkeypatch):
    """Q6 — ETS typologie=sad → eligible → bulk-upsert OK avec 5D."""
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "get_ets_typologie",
        lambda ets, company: {"typologie": "sad"},
    )
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "replace_by_doc_ets_variante",
        lambda **kw: [],
    )
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "list_by_filter",
        lambda d, e=None, v=None: [],
    )

    payload = Annexe5BulkUpsertRequest(ets_id=ETS_ID, variante="5D_sad_spasad", items=[])
    result = await annexe5_service.bulk_upsert_annexe5(DOC_ID, COMPANY, payload)
    assert result.variante_filtre == "5D_sad_spasad"


@pytest.mark.asyncio
async def test_bulk_upsert_esat_not_applicable_422(patch_run_in_thread, monkeypatch):
    """Q6 — ETS typologie=esat → pas eligible Annexe 5 → 422."""
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "get_ets_typologie",
        lambda ets, company: {"typologie": "esat"},
    )

    payload = Annexe5BulkUpsertRequest(ets_id=ETS_ID, variante="5A_ehpad", items=[])
    with pytest.raises(ValidationError) as exc:
        await annexe5_service.bulk_upsert_annexe5(DOC_ID, COMPANY, payload)
    assert exc.value.code == "annexe5_not_applicable"


@pytest.mark.asyncio
async def test_bulk_upsert_ime_not_applicable_422(patch_run_in_thread, monkeypatch):
    """Q6 — ETS typologie=ime → pas eligible Annexe 5 → 422."""
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "get_ets_typologie",
        lambda ets, company: {"typologie": "ime"},
    )

    payload = Annexe5BulkUpsertRequest(ets_id=ETS_ID, variante="5A_ehpad", items=[])
    with pytest.raises(ValidationError) as exc:
        await annexe5_service.bulk_upsert_annexe5(DOC_ID, COMPANY, payload)
    assert exc.value.code == "annexe5_not_applicable"


@pytest.mark.asyncio
async def test_bulk_upsert_ets_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "get_ets_typologie",
        lambda ets, company: None,
    )

    payload = Annexe5BulkUpsertRequest(ets_id=ETS_ID, variante="5A_ehpad", items=[])
    with pytest.raises(NotFoundError) as exc:
        await annexe5_service.bulk_upsert_annexe5(DOC_ID, COMPANY, payload)
    assert exc.value.code == "etablissement_not_found"


@pytest.mark.asyncio
async def test_bulk_upsert_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        annexe5_service.annexe5_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    payload = Annexe5BulkUpsertRequest(ets_id=ETS_ID, variante="5A_ehpad", items=[])
    with pytest.raises(NotFoundError) as exc:
        await annexe5_service.bulk_upsert_annexe5(DOC_ID, COMPANY, payload)
    assert exc.value.code == "document_not_found"
