"""Tests §V D-063 — guards périmètre DM sur CR mutations.

Couvre :

* create_cr sur DM avec ETS ∈ parent → OK
* create_cr sur DM avec ETS ∉ parent → 422 dm_perimeter_breach
* create_cr sur EPRD (non-DM) → guard skipped (pas de breach, non applicable)
* update_cr DM avec nouvel ETS hors périmètre → 422
* delete_cr sur DM → 409 dm_cr_immutable
* delete_cr sur EPRD → OK (pas de guard)
"""

from __future__ import annotations

from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.cr import CrCreate, CrUpdate
from piilot_pack_compta_esms.services import cr_service
from piilot_pack_compta_esms.services.errors import ConflictError, ValidationError

COMPANY = uuid4()
DM_DOC = uuid4()
EPRD_DOC = uuid4()
CR_ID = uuid4()
ETS_IN_PERIMETER = uuid4()
ETS_OUT_PERIMETER = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.cr_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def cr_repo_setup(monkeypatch):
    """Common mocks — doc exists, ETS belongs to company."""
    monkeypatch.setattr(cr_service.cr_repo, "document_exists_for_company", lambda d, c: True)
    monkeypatch.setattr(cr_service.cr_repo, "etablissement_belongs_to_company", lambda e, c: True)
    return monkeypatch


# ---------------------------------------------------------------------------
# create_cr
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_cr_dm_ets_in_perimeter_ok(monkeypatch, patch_run_in_thread, cr_repo_setup):
    """DM + ETS du parent → succès."""
    monkeypatch.setattr(
        cr_service.cr_repo,
        "get_doc_type_and_dm_perimeter",
        lambda _: {
            "type_document": "dm",
            "parent_id": uuid4(),
            "parent_ets_ids": {ETS_IN_PERIMETER},
        },
    )
    monkeypatch.setattr(
        cr_service.cr_repo,
        "create",
        lambda c, d, p: _row(etablissement_id=ETS_IN_PERIMETER),
    )

    out = await cr_service.create_cr(
        COMPANY,
        DM_DOC,
        CrCreate(
            cr_type="CRPA",
            denomination="CRPA EHPAD 2",
            etablissement_id=ETS_IN_PERIMETER,
        ),
    )
    assert out.etablissement_id == ETS_IN_PERIMETER


@pytest.mark.asyncio
async def test_create_cr_dm_ets_out_perimeter_422(monkeypatch, patch_run_in_thread, cr_repo_setup):
    """DM + ETS hors parent → 422 dm_perimeter_breach."""
    monkeypatch.setattr(
        cr_service.cr_repo,
        "get_doc_type_and_dm_perimeter",
        lambda _: {
            "type_document": "dm",
            "parent_id": uuid4(),
            "parent_ets_ids": {ETS_IN_PERIMETER},  # ETS_OUT_PERIMETER pas dedans
        },
    )
    with pytest.raises(ValidationError) as exc:
        await cr_service.create_cr(
            COMPANY,
            DM_DOC,
            CrCreate(
                cr_type="CRPA",
                denomination="CRPA hors périmètre",
                etablissement_id=ETS_OUT_PERIMETER,
            ),
        )
    assert exc.value.code == "dm_perimeter_breach"


@pytest.mark.asyncio
async def test_create_cr_eprd_skip_guard(monkeypatch, patch_run_in_thread, cr_repo_setup):
    """EPRD (non-DM) → pas de guard, même si on simule un retour."""
    # Le fixture autouse conftest met le perimeter à None par défaut, donc le
    # guard skip. On vérifie qu'on passe.
    monkeypatch.setattr(
        cr_service.cr_repo, "create", lambda c, d, p: _row(etablissement_id=uuid4())
    )

    out = await cr_service.create_cr(
        COMPANY,
        EPRD_DOC,
        CrCreate(
            cr_type="CRPP",
            denomination="CRPP EPRD",
            etablissement_id=uuid4(),
        ),
    )
    assert out is not None


# ---------------------------------------------------------------------------
# update_cr
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_update_cr_dm_new_ets_out_perimeter_422(
    monkeypatch, patch_run_in_thread, cr_repo_setup
):
    """Patch d'un CR DM vers ETS hors parent → 422."""
    monkeypatch.setattr(
        cr_service.cr_repo,
        "get_by_id",
        lambda _: {
            "id": CR_ID,
            "company_id": COMPANY,
            "document_id": DM_DOC,
            "ordre": 1,
        },
    )
    monkeypatch.setattr(
        cr_service.cr_repo,
        "get_doc_type_and_dm_perimeter",
        lambda _: {
            "type_document": "dm",
            "parent_id": uuid4(),
            "parent_ets_ids": {ETS_IN_PERIMETER},
        },
    )
    with pytest.raises(ValidationError) as exc:
        await cr_service.update_cr(
            COMPANY,
            CR_ID,
            CrUpdate(etablissement_id=ETS_OUT_PERIMETER),
        )
    assert exc.value.code == "dm_perimeter_breach"


# ---------------------------------------------------------------------------
# delete_cr
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_delete_cr_dm_409_immutable(monkeypatch, patch_run_in_thread, cr_repo_setup):
    """DELETE CR sur DM → 409 dm_cr_immutable."""
    monkeypatch.setattr(
        cr_service.cr_repo,
        "get_by_id",
        lambda _: {
            "id": CR_ID,
            "company_id": COMPANY,
            "document_id": DM_DOC,
            "ordre": 1,
        },
    )
    monkeypatch.setattr(
        cr_service.cr_repo,
        "get_doc_type_and_dm_perimeter",
        lambda _: {
            "type_document": "dm",
            "parent_id": uuid4(),
            "parent_ets_ids": {ETS_IN_PERIMETER},
        },
    )
    with pytest.raises(ConflictError) as exc:
        await cr_service.delete_cr(COMPANY, CR_ID)
    assert exc.value.code == "dm_cr_immutable"


@pytest.mark.asyncio
async def test_delete_cr_eprd_passes(monkeypatch, patch_run_in_thread, cr_repo_setup):
    """DELETE CR sur EPRD → pas de guard, succès."""
    monkeypatch.setattr(
        cr_service.cr_repo,
        "get_by_id",
        lambda _: {
            "id": CR_ID,
            "company_id": COMPANY,
            "document_id": EPRD_DOC,
            "ordre": 1,
        },
    )
    # Autouse fixture conftest met perimeter à None → guard skip
    monkeypatch.setattr(cr_service.cr_repo, "delete", lambda _: True)
    await cr_service.delete_cr(COMPANY, CR_ID)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _row(*, etablissement_id):
    from datetime import UTC, datetime

    return {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DM_DOC,
        "cr_type": "CRPA",
        "cr_variante": "non_soumis_equil",
        "denomination": "CRPA",
        "cr_identifiant": None,
        "etablissement_id": etablissement_id,
        "finess_rattachement": None,
        "capacite_installee": None,
        "amplitude_ouverture": None,
        "ventilation": "simple",
        "ordre": 0,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
