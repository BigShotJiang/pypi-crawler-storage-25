"""Tests §BI.1 — KB template ``rapport_budgetaire_sections``.

Couvre :

* Constants SECTION_CODES + SECTION_LABELS_FR (9 valeurs cohérentes spec)
* Template dict shape (5 columns, enum section_codes, locales bilingues)
* register_template() pousse dans le buffer SDK
"""

from __future__ import annotations

import pytest
from piilot.sdk.kb_templates import _drain

from piilot_pack_compta_esms.kb_templates import rapport_budgetaire_sections


def test_section_codes_constant_has_9_entries() -> None:
    """9 sections conformes au plan DOCX (L5d §11-32)."""
    assert len(rapport_budgetaire_sections.SECTION_CODES) == 9
    expected = {
        "AVANCEMENT_CPOM",
        "OBSERVATIONS_GENERALES",
        "COMPTE_RESULTAT",
        "PREVISIONS_RECETTES",
        "PREVISIONS_DEPENSES",
        "TABLEAU_FINANCEMENT",
        "ANALYSE_FINANCIERE",
        "PGFP",
        "PERSPECTIVES",
    }
    assert set(rapport_budgetaire_sections.SECTION_CODES) == expected


def test_section_labels_fr_covers_all_codes() -> None:
    """Tout code SECTION_CODES doit avoir un label FR humain."""
    for code in rapport_budgetaire_sections.SECTION_CODES:
        assert code in rapport_budgetaire_sections.SECTION_LABELS_FR
        assert rapport_budgetaire_sections.SECTION_LABELS_FR[code]


def test_template_dict_shape() -> None:
    """Template dict conforme à KBTemplate core (slug, columns, etc.)."""
    template = rapport_budgetaire_sections._template_dict()
    assert template["slug"] == "rapport_budgetaire_sections"
    assert template["category"] == "vertical_esms"
    assert "fr" in template["display_name"]
    assert "en" in template["display_name"]
    assert "fr" in template["description"]
    assert "en" in template["description"]
    assert len(template["columns"]) == 5
    col_names = [c["name"] for c in template["columns"]]
    assert col_names == ["document_id", "section_code", "contenu_md", "auteur", "date_maj"]


def test_template_section_code_column_has_enum() -> None:
    """La colonne section_code expose les 9 valeurs en enum (UI select)."""
    template = rapport_budgetaire_sections._template_dict()
    section_col = next(c for c in template["columns"] if c["name"] == "section_code")
    assert section_col["column_type"] == "text"
    assert section_col["required"] is True
    assert section_col["enum"] == rapport_budgetaire_sections.SECTION_CODES


def test_template_date_maj_is_date_type() -> None:
    """date_maj doit être typée date (pas text) pour rendu UI calendar."""
    template = rapport_budgetaire_sections._template_dict()
    date_col = next(c for c in template["columns"] if c["name"] == "date_maj")
    assert date_col["column_type"] == "date"
    assert date_col["required"] is False


def test_register_template_pushes_to_sdk_buffer() -> None:
    """register_template() bufferise le dict dans le SDK pour drain au boot."""
    # On vide le buffer avant pour partir d'un état propre — d'autres tests
    # peuvent l'avoir touché.
    _drain()
    rapport_budgetaire_sections.register_template()
    collected = _drain()
    assert len(collected) == 1
    assert collected[0]["slug"] == "rapport_budgetaire_sections"


def test_register_template_idempotent_via_drain() -> None:
    """Appels multiples cumulent dans le buffer (le loader drain entre).

    Garantit qu'un re-register après drain remet une entrée fraîche
    sans crash.
    """
    _drain()  # clean
    rapport_budgetaire_sections.register_template()
    rapport_budgetaire_sections.register_template()
    collected = _drain()
    # 2 appels = 2 entrées identiques bufferisées (par design SDK)
    assert len(collected) == 2
    assert all(c["slug"] == "rapport_budgetaire_sections" for c in collected)


@pytest.fixture(autouse=True)
def _flush_sdk_buffer():
    """Drain le buffer SDK avant chaque test de ce module pour
    déterminisme (les imports d'autres tests peuvent y avoir poussé)."""
    _drain()
    yield
    _drain()
