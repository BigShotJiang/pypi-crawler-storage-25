"""Tests §BI.4 — injection des commentaires utilisateur dans le DOCX.

Couvre :

* inject_user_section skip si contenu vide
* inject_user_section skip si KB absente (EPRDs pre-§BI)
* inject_user_section rend en plain text (pas de markdown rendering v0.3)
* inject_user_section split sur \\n\\n (paragraphes multiples)
* load_user_sections mémoïse (1 SELECT par export)
* load_user_sections catch exception → dict vide non-bloquant
"""

from __future__ import annotations

from uuid import uuid4

import pytest
from docx import Document

from piilot_pack_compta_esms.exports.docx._base import (
    RapportContext,
    inject_user_section,
    load_user_sections,
)
from piilot_pack_compta_esms.services import rapport_sections_service

COMPANY = uuid4()
DOC_ID = uuid4()


def _make_ctx() -> RapportContext:
    return RapportContext(
        document_id=DOC_ID,
        company_id=COMPANY,
        document={"id": DOC_ID, "company_id": COMPANY, "type_document": "eprd"},
    )


def _count_paragraphs(doc) -> int:
    return len(doc.paragraphs)


def _all_text(doc) -> str:
    return "\n".join(p.text for p in doc.paragraphs)


# ---------------------------------------------------------------------------
# load_user_sections — cache + defensive
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_load_user_sections_memoizes_first_call(monkeypatch) -> None:
    """Le 2e appel sur le même ctx ne re-call PAS le service."""
    ctx = _make_ctx()
    call_count = []

    async def _fake_load(*, document_id, company_id):
        call_count.append(1)
        return {"PGFP": "content"}

    monkeypatch.setattr(rapport_sections_service, "load_sections_by_code", _fake_load)

    out1 = await load_user_sections(ctx)
    out2 = await load_user_sections(ctx)
    assert out1 == out2 == {"PGFP": "content"}
    assert len(call_count) == 1  # mémoïsé


@pytest.mark.asyncio
async def test_load_user_sections_returns_empty_on_service_exception(monkeypatch) -> None:
    """Si rapport_sections_service raise → DOCX continue sans crash."""
    ctx = _make_ctx()

    async def _boom(*, document_id, company_id):
        raise RuntimeError("SDK indispo")

    monkeypatch.setattr(rapport_sections_service, "load_sections_by_code", _boom)

    out = await load_user_sections(ctx)
    assert out == {}


# ---------------------------------------------------------------------------
# inject_user_section — skip cases
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_inject_skips_when_section_empty(monkeypatch) -> None:
    """contenu_md vide → no-op, pas de paragraphe ajouté."""
    ctx = _make_ctx()

    async def _load(*, document_id, company_id):
        return {"PGFP": ""}

    monkeypatch.setattr(rapport_sections_service, "load_sections_by_code", _load)
    doc = Document()
    before = _count_paragraphs(doc)

    await inject_user_section(doc, ctx, "PGFP")

    assert _count_paragraphs(doc) == before


@pytest.mark.asyncio
async def test_inject_skips_when_section_only_whitespace(monkeypatch) -> None:
    """contenu_md whitespace-only → skip aussi (strip avant check)."""
    ctx = _make_ctx()

    async def _load(*, document_id, company_id):
        return {"PGFP": "   \n  \t  "}

    monkeypatch.setattr(rapport_sections_service, "load_sections_by_code", _load)
    doc = Document()
    before = _count_paragraphs(doc)

    await inject_user_section(doc, ctx, "PGFP")

    assert _count_paragraphs(doc) == before


@pytest.mark.asyncio
async def test_inject_skips_when_section_code_not_in_dict(monkeypatch) -> None:
    """Section_code pas dans le mapping → skip (EPRD avec sections partielles)."""
    ctx = _make_ctx()

    async def _load(*, document_id, company_id):
        return {"OBSERVATIONS_GENERALES": "Other section"}

    monkeypatch.setattr(rapport_sections_service, "load_sections_by_code", _load)
    doc = Document()
    before = _count_paragraphs(doc)

    await inject_user_section(doc, ctx, "PGFP")

    assert _count_paragraphs(doc) == before


@pytest.mark.asyncio
async def test_inject_skips_when_kb_missing(monkeypatch) -> None:
    """load_sections retourne {} (KB inexistante) → no-op."""
    ctx = _make_ctx()

    async def _load(*, document_id, company_id):
        return {}

    monkeypatch.setattr(rapport_sections_service, "load_sections_by_code", _load)
    doc = Document()
    before = _count_paragraphs(doc)

    await inject_user_section(doc, ctx, "PGFP")

    assert _count_paragraphs(doc) == before


# ---------------------------------------------------------------------------
# inject_user_section — happy paths
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_inject_renders_plain_text_paragraph(monkeypatch) -> None:
    """contenu_md plein → heading 'Commentaires' + 1 paragraphe plain text."""
    ctx = _make_ctx()
    contenu = "Avancement CPOM 2024 : 3 objectifs atteints sur 5."

    async def _load(*, document_id, company_id):
        return {"AVANCEMENT_CPOM": contenu}

    monkeypatch.setattr(rapport_sections_service, "load_sections_by_code", _load)
    doc = Document()

    await inject_user_section(doc, ctx, "AVANCEMENT_CPOM")

    text = _all_text(doc)
    assert "Commentaires" in text  # heading
    assert contenu in text


@pytest.mark.asyncio
async def test_inject_splits_on_double_newline(monkeypatch) -> None:
    """Le contenu_md avec \\n\\n produit plusieurs paragraphes."""
    ctx = _make_ctx()
    contenu = "Premier paragraphe.\n\nSecond paragraphe.\n\nTroisième paragraphe."

    async def _load(*, document_id, company_id):
        return {"PGFP": contenu}

    monkeypatch.setattr(rapport_sections_service, "load_sections_by_code", _load)
    doc = Document()
    before = _count_paragraphs(doc)

    await inject_user_section(doc, ctx, "PGFP")

    after = _count_paragraphs(doc)
    # 1 heading (h3) + 3 paragraphes = +4 par rapport au baseline (mais heading
    # peut être compté différemment par python-docx selon version, on vérifie
    # juste que les 3 paragraphes sont là).
    text = _all_text(doc)
    assert "Premier paragraphe." in text
    assert "Second paragraphe." in text
    assert "Troisième paragraphe." in text
    # Au moins +3 nouveaux blocs textuels
    assert after - before >= 3


@pytest.mark.asyncio
async def test_inject_joins_single_newlines_into_one_paragraph(monkeypatch) -> None:
    """Sauts simples \\n DANS un paragraphe → espace (pas de soft-wrap docx)."""
    ctx = _make_ctx()
    contenu = "Ligne 1\nLigne 2\nLigne 3"

    async def _load(*, document_id, company_id):
        return {"PERSPECTIVES": contenu}

    monkeypatch.setattr(rapport_sections_service, "load_sections_by_code", _load)
    doc = Document()

    await inject_user_section(doc, ctx, "PERSPECTIVES")

    text = _all_text(doc)
    # Doit produire un seul paragraphe "Ligne 1 Ligne 2 Ligne 3"
    assert "Ligne 1 Ligne 2 Ligne 3" in text
