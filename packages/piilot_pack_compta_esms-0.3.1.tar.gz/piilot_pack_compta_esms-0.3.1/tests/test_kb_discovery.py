"""Unit tests for :mod:`piilot_pack_compta_esms.services.kb_discovery`.

Post-SDK-0.8 refactor : ``list_candidate_kbs`` and ``aggregate_preview``
are thin wrappers over the upstream SDK primitives
(:func:`piilot.sdk.knowledge.find_kbs` / :func:`piilot.sdk.knowledge.aggregate`).
We mock the SDK functions directly — the SDK has its own dedicated
test suite for the SQL layer (`backend/tests/test_sdk_knowledge.py`).

The remaining in-plugin logic still tested here :

* ``check_compat`` — contract → KB columns matching (permissive on types).
* ``fetch_kb_meta`` — async wrapper around ``_fetch_kb_meta_sync``,
  used by binding_service to read ``table_name`` + ``columns`` before
  validating a binding payload.
* The two wrappers — SDK call dispatched correctly + output adapted
  to :class:`CandidateKb` / re-keyed from KB logical → contract space.
"""

from __future__ import annotations

from uuid import uuid4

import pytest

from piilot_pack_compta_esms.services import kb_discovery

# ---------------------------------------------------------------------------
# check_compat
# ---------------------------------------------------------------------------


def test_check_compat_happy_match():
    columns_required = {"compte": "text", "montant": "numeric"}
    kb_columns = [
        {"name": "compte", "column_type": "text"},
        {"name": "montant", "column_type": "numeric"},
        {"name": "extra", "column_type": "text"},
    ]
    compatible, warnings = kb_discovery.check_compat(columns_required, kb_columns)
    assert compatible is True
    assert warnings == []


def test_check_compat_missing_column_rejects():
    columns_required = {"compte": "text", "montant": "numeric"}
    kb_columns = [{"name": "compte", "column_type": "text"}]
    compatible, warnings = kb_discovery.check_compat(columns_required, kb_columns)
    assert compatible is False
    assert warnings == []


def test_check_compat_permissive_type_mismatch_warns():
    """A KB whose ``compte`` is numeric still binds — emits a warning."""
    columns_required = {"compte": "text", "montant": "numeric"}
    kb_columns = [
        {"name": "compte", "column_type": "numeric"},
        {"name": "montant", "column_type": "numeric"},
    ]
    compatible, warnings = kb_discovery.check_compat(columns_required, kb_columns)
    assert compatible is True
    assert len(warnings) == 1
    assert warnings[0].contract_column == "compte"
    assert warnings[0].expected_type == "text"
    assert warnings[0].actual_type == "numeric"


def test_check_compat_uses_column_mapping():
    columns_required = {"compte": "text", "montant": "numeric"}
    kb_columns = [
        {"name": "account_number", "column_type": "text"},
        {"name": "montant", "column_type": "numeric"},
    ]
    compatible, warnings = kb_discovery.check_compat(
        columns_required, kb_columns, column_mapping={"compte": "account_number"}
    )
    assert compatible is True
    assert warnings == []


def test_check_compat_integer_accepts_numeric_kb_column():
    columns_required = {"places": "integer"}
    kb_columns = [{"name": "places", "column_type": "numeric"}]
    compatible, warnings = kb_discovery.check_compat(columns_required, kb_columns)
    assert compatible is True
    assert warnings == []


# ---------------------------------------------------------------------------
# fetch_kb_meta — async wrapper around sync loader
# ---------------------------------------------------------------------------


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.kb_discovery.run_in_thread",
        _passthrough,
    )


@pytest.mark.asyncio
async def test_fetch_kb_meta_returns_dict(monkeypatch, patch_run_in_thread):
    kb_id = uuid4()
    company_id = uuid4()

    def _fake(kb, company):
        assert kb == kb_id
        assert company == company_id
        return {
            "id": kb_id,
            "name": "balance_m22bis_2026",
            "table_name": "kbs.compta_esms__balance__abc12345",
            "scope": "company",
            "owner_type": "plugin",
            "owner_ref": "compta_esms",
            "columns": [{"name": "compte", "column_type": "text", "pg_column": "c_x"}],
        }

    monkeypatch.setattr(kb_discovery, "_fetch_kb_meta_sync", _fake)
    out = await kb_discovery.fetch_kb_meta(kb_id, company_id)
    assert out is not None
    assert out["table_name"] == "kbs.compta_esms__balance__abc12345"


@pytest.mark.asyncio
async def test_fetch_kb_meta_returns_none_when_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(kb_discovery, "_fetch_kb_meta_sync", lambda *a: None)
    out = await kb_discovery.fetch_kb_meta(uuid4(), uuid4())
    assert out is None


# ---------------------------------------------------------------------------
# list_candidate_kbs — thin wrapper over piilot.sdk.knowledge.find_kbs
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_candidates_adapts_sdk_output(monkeypatch, patch_run_in_thread):
    """SDK ``find_kbs`` returns dicts — the wrapper adapts each to
    :class:`CandidateKb` + re-builds :class:`ColumnCompatWarning` from
    the warning dicts."""
    company_id = uuid4()
    kb_id_a = uuid4()
    kb_id_b = uuid4()

    def _fake_find_kbs(*, company_id, columns_required, scope):
        assert columns_required == {"compte": "text", "montant": "numeric"}
        assert scope == "all"
        return [
            {
                "kb_id": kb_id_a,
                "name": "kb-clean",
                "kb_table": "tbl_a",
                "scope": "company",
                "owner_type": "plugin",
                "owner_ref": "pennylane",
                "row_count": 42,
                "columns": [
                    {"name": "compte", "type": "text"},
                    {"name": "montant", "type": "numeric"},
                ],
                "warnings": [],
            },
            {
                "kb_id": kb_id_b,
                "name": "kb-warn",
                "kb_table": "tbl_b",
                "scope": "company",
                "owner_type": None,
                "owner_ref": None,
                "row_count": 17,
                "columns": [
                    {"name": "compte", "type": "numeric"},
                    {"name": "montant", "type": "numeric"},
                ],
                "warnings": [
                    {
                        "contract_column": "compte",
                        "kb_column": "compte",
                        "expected_type": "text",
                        "actual_type": "numeric",
                    }
                ],
            },
        ]

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.kb_discovery.sdk_knowledge.find_kbs",
        _fake_find_kbs,
    )

    out = await kb_discovery.list_candidate_kbs(
        company_id=company_id,
        columns_required={"compte": "text", "montant": "numeric"},
    )
    assert len(out) == 2
    assert out[0].kb_id == kb_id_a
    assert out[0].row_count == 42
    assert out[0].warnings == []
    assert out[1].kb_id == kb_id_b
    assert len(out[1].warnings) == 1
    assert out[1].warnings[0].contract_column == "compte"
    assert out[1].warnings[0].actual_type == "numeric"


@pytest.mark.asyncio
async def test_list_candidates_empty_when_sdk_returns_nothing(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.kb_discovery.sdk_knowledge.find_kbs",
        lambda **kwargs: [],
    )
    out = await kb_discovery.list_candidate_kbs(
        company_id=uuid4(),
        columns_required={"compte": "text"},
    )
    assert out == []


# ---------------------------------------------------------------------------
# aggregate_preview — thin wrapper over piilot.sdk.knowledge.aggregate
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_aggregate_preview_translates_contract_to_kb_then_remaps(
    monkeypatch,
    patch_run_in_thread,
):
    """The wrapper :
    1. Translates contract → KB logical names before invoking the SDK,
    2. Re-keys the SDK output back to contract names so the frontend
       stays in contract-space.
    """
    kb_id = uuid4()
    captured_kwargs: dict = {}

    def _fake_aggregate(**kwargs):
        captured_kwargs.update(kwargs)
        # SDK returns rows keyed by KB logical names
        return [
            {"account_number": "401", "amount": 1000},
            {"account_number": "411", "amount": 500},
        ]

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.kb_discovery.sdk_knowledge.aggregate",
        _fake_aggregate,
    )

    contract_to_kb = {"compte": "account_number", "montant": "amount"}
    rows = await kb_discovery.aggregate_preview(
        kb_id=kb_id,
        contract_to_kb_logical=contract_to_kb,
        dimension_logical_cols=["compte"],
        measure_logical_cols=["montant"],
        filters={"compte": "401"},
        limit=50,
    )

    # SDK was called with KB logical names
    assert captured_kwargs["kb_id"] == str(kb_id)
    assert captured_kwargs["dimensions"] == ["account_number"]
    assert captured_kwargs["measures"] == [("amount", "SUM")]
    assert captured_kwargs["filters"] == {"account_number": "401"}
    assert captured_kwargs["limit"] == 50

    # Output re-keyed to contract names
    assert len(rows) == 2
    assert rows[0] == {"compte": "401", "montant": 1000}
    assert rows[1] == {"compte": "411", "montant": 500}


@pytest.mark.asyncio
async def test_aggregate_preview_filter_on_unknown_column_is_dropped(
    monkeypatch,
    patch_run_in_thread,
):
    """A filter on a column not in the contract mapping must NOT reach
    the SDK (tolerance vs UI state drift)."""
    captured_kwargs: dict = {}

    def _fake_aggregate(**kwargs):
        captured_kwargs.update(kwargs)
        return []

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.kb_discovery.sdk_knowledge.aggregate",
        _fake_aggregate,
    )

    await kb_discovery.aggregate_preview(
        kb_id=uuid4(),
        contract_to_kb_logical={"compte": "account_number"},
        dimension_logical_cols=["compte"],
        measure_logical_cols=[],
        filters={"compte": "401", "ghost": "x"},
    )

    # ``ghost`` dropped, only ``account_number`` reached the SDK
    assert captured_kwargs["filters"] == {"account_number": "401"}


@pytest.mark.asyncio
async def test_aggregate_preview_no_filters(monkeypatch, patch_run_in_thread):
    captured_kwargs: dict = {}

    def _fake_aggregate(**kwargs):
        captured_kwargs.update(kwargs)
        return []

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.kb_discovery.sdk_knowledge.aggregate",
        _fake_aggregate,
    )

    await kb_discovery.aggregate_preview(
        kb_id=uuid4(),
        contract_to_kb_logical={"compte": "compte"},
        dimension_logical_cols=["compte"],
        measure_logical_cols=[],
    )
    assert captured_kwargs["filters"] == {}
