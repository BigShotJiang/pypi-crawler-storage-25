"""Unit tests for :mod:`piilot_pack_compta_esms.services.affectation_variante`."""

from __future__ import annotations

import pytest

from piilot_pack_compta_esms.services.affectation_variante import (
    UnknownNatureJuridiqueError,
    choose_affectation_variante,
    is_variant_I,
    is_variant_II,
)

# ---------------------------------------------------------------------------
# choose_affectation_variante — D-082 mapping
# ---------------------------------------------------------------------------


def test_eps_hors_cpom_is_public_I():
    assert (
        choose_affectation_variante(
            nature_juridique="ETABLISSEMENT_PUBLIC_SANTE", inclus_cpom=False
        )
        == "public_I"
    )


def test_eps_inclus_cpom_is_public_II():
    assert (
        choose_affectation_variante(nature_juridique="ETABLISSEMENT_PUBLIC_SANTE", inclus_cpom=True)
        == "public_II"
    )


def test_essms_public_non_eps_hors_cpom():
    assert (
        choose_affectation_variante(nature_juridique="ESMS_PUBLIC_AUTONOME", inclus_cpom=False)
        == "public_I"
    )


def test_essms_public_non_eps_inclus_cpom():
    assert (
        choose_affectation_variante(nature_juridique="ESMS_PUBLIC_AUTONOME", inclus_cpom=True)
        == "public_II"
    )


def test_prive_non_lucratif_hors_cpom():
    assert (
        choose_affectation_variante(nature_juridique="PRIVE_NON_LUCRATIF", inclus_cpom=False)
        == "prive_I"
    )


def test_prive_non_lucratif_inclus_cpom():
    assert (
        choose_affectation_variante(nature_juridique="PRIVE_NON_LUCRATIF", inclus_cpom=True)
        == "prive_II"
    )


def test_prive_commercial_hors_cpom():
    assert (
        choose_affectation_variante(nature_juridique="PRIVE_COMMERCIAL", inclus_cpom=False)
        == "prive_I"
    )


def test_prive_commercial_inclus_cpom():
    assert (
        choose_affectation_variante(nature_juridique="PRIVE_COMMERCIAL", inclus_cpom=True)
        == "prive_II"
    )


def test_unknown_statut_raises():
    with pytest.raises(UnknownNatureJuridiqueError):
        choose_affectation_variante(nature_juridique="unknown_garbage", inclus_cpom=False)


# ---------------------------------------------------------------------------
# is_variant_I / is_variant_II helpers
# ---------------------------------------------------------------------------


def test_is_variant_I():
    assert is_variant_I("prive_I") is True
    assert is_variant_I("public_I") is True
    assert is_variant_I("prive_II") is False
    assert is_variant_I("public_II") is False


def test_is_variant_II():
    assert is_variant_II("prive_II") is True
    assert is_variant_II("public_II") is True
    assert is_variant_II("prive_I") is False
    assert is_variant_II("public_I") is False
