"""Tests pour :mod:`rgpd_service` — orchestration §T.

Couvre :

* GET 200 (recueil posé), 404 (exercice not found), 404 (exercice
  appartient à la company mais pas encore de consentement).
* PUT happy paths : first time pose ``consenti_at``, toggle True→False
  pose ``revoque_at``, toggle False→True reset ``revoque_at`` à
  NULL, audit_event INSERT vérifié.
* Pydantic 422 : cnsa=false avec fédérations, custom > 3, durée
  obligatoire si cnsa=true.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

import pytest
from pydantic import ValidationError

from piilot_pack_compta_esms.models.rgpd import (
    FederationsConsenties,
    RecueilConsentementUpdate,
)
from piilot_pack_compta_esms.services import rgpd_service
from piilot_pack_compta_esms.services.errors import (
    CrossCompanyError,
    NotFoundError,
)

COMPANY = uuid4()
USER = uuid4()
EXERCICE = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.rgpd_service.run_in_thread",
        _passthrough,
    )


def _row(
    *,
    consentement_cnsa: bool = True,
    federations: dict[str, Any] | None = None,
    duree: str | None = "1_an",
    consenti_at: datetime | None = None,
    revoque_at: datetime | None = None,
    company_id: UUID = COMPANY,
) -> dict[str, Any]:
    return {
        "id": uuid4(),
        "company_id": company_id,
        "exercice_id": EXERCICE,
        "consentement_cnsa": consentement_cnsa,
        "federations_consenties": federations or {"selected_known": [], "selected_custom": []},
        "duree": duree,
        "consenti_par_user_id": USER,
        "consenti_at": consenti_at or datetime.now(tz=UTC),
        "revoque_at": revoque_at,
    }


# ---------------------------------------------------------------------------
# Pydantic model validation (model_validator + custom validator)
# ---------------------------------------------------------------------------


def test_payload_cnsa_false_with_federations_raises():
    with pytest.raises(ValidationError):
        RecueilConsentementUpdate(
            consentement_cnsa=False,
            federations=FederationsConsenties(
                selected_known=["MUTUALITE"],
            ),
        )


def test_payload_cnsa_false_with_duree_raises():
    with pytest.raises(ValidationError):
        RecueilConsentementUpdate(
            consentement_cnsa=False,
            duree="1_an",
        )


def test_payload_cnsa_true_without_duree_raises():
    with pytest.raises(ValidationError):
        RecueilConsentementUpdate(
            consentement_cnsa=True,
            federations=FederationsConsenties(selected_known=["FEHAP"]),
        )


def test_payload_custom_more_than_3_raises():
    with pytest.raises(ValidationError):
        FederationsConsenties(
            selected_custom=["a", "b", "c", "d"],
        )


def test_payload_custom_with_pipe_raises():
    with pytest.raises(ValidationError):
        FederationsConsenties(
            selected_custom=["valid", "pipe | inside"],
        )


def test_payload_invalid_federation_code_raises():
    with pytest.raises(ValidationError):
        FederationsConsenties(selected_known=["NOT_A_REAL_FEDERATION"])  # type: ignore


def test_payload_happy_path():
    p = RecueilConsentementUpdate(
        consentement_cnsa=True,
        federations=FederationsConsenties(
            selected_known=["MUTUALITE", "FEHAP", "SYNERPA"],
            selected_custom=["FNADEPA IDF"],
        ),
        duree="5_ans",
    )
    assert p.consentement_cnsa is True
    assert len(p.federations.selected_known) == 3
    assert p.duree == "5_ans"


# ---------------------------------------------------------------------------
# GET
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_consentement_404_exercice_unknown(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        rgpd_service.rgpd_repo,
        "exercice_belongs_to_company",
        lambda ex, co: False,
    )
    with pytest.raises(NotFoundError) as exc:
        await rgpd_service.get_consentement(EXERCICE, COMPANY)
    assert exc.value.code == "exercice_not_found"


@pytest.mark.asyncio
async def test_get_consentement_404_not_yet_set(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        rgpd_service.rgpd_repo,
        "exercice_belongs_to_company",
        lambda ex, co: True,
    )
    monkeypatch.setattr(rgpd_service.rgpd_repo, "get_by_exercice", lambda ex: None)
    with pytest.raises(NotFoundError) as exc:
        await rgpd_service.get_consentement(EXERCICE, COMPANY)
    assert exc.value.code == "consentement_not_found"


@pytest.mark.asyncio
async def test_get_consentement_200(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        rgpd_service.rgpd_repo,
        "exercice_belongs_to_company",
        lambda ex, co: True,
    )
    monkeypatch.setattr(
        rgpd_service.rgpd_repo,
        "get_by_exercice",
        lambda ex: _row(),
    )
    resp = await rgpd_service.get_consentement(EXERCICE, COMPANY)
    assert resp.exercice_id == EXERCICE
    assert resp.consentement_cnsa is True


@pytest.mark.asyncio
async def test_get_consentement_403_cross_company(monkeypatch, patch_run_in_thread):
    other = uuid4()
    monkeypatch.setattr(
        rgpd_service.rgpd_repo,
        "exercice_belongs_to_company",
        lambda ex, co: True,
    )
    monkeypatch.setattr(
        rgpd_service.rgpd_repo,
        "get_by_exercice",
        lambda ex: _row(company_id=other),
    )
    with pytest.raises(CrossCompanyError) as exc:
        await rgpd_service.get_consentement(EXERCICE, COMPANY)
    assert exc.value.code == "consentement_cross_company"


# ---------------------------------------------------------------------------
# PUT — toggle timestamps + audit log
# ---------------------------------------------------------------------------


@pytest.fixture
def patch_repo_upsert(monkeypatch):
    """Capture le payload du upsert pour assertions."""
    captured: dict[str, Any] = {}

    def _fake_upsert(**kwargs):
        captured["kwargs"] = kwargs
        return _row(
            consentement_cnsa=kwargs["consentement_cnsa"],
            federations=kwargs["federations_consenties"],
            duree=kwargs["duree"],
            consenti_at=kwargs["consenti_at"],
            revoque_at=kwargs["revoque_at"],
        )

    monkeypatch.setattr(rgpd_service.rgpd_repo, "upsert_by_exercice", _fake_upsert)
    monkeypatch.setattr(
        rgpd_service.rgpd_repo,
        "exercice_belongs_to_company",
        lambda ex, co: True,
    )
    return captured


@pytest.fixture
def patch_audit(monkeypatch):
    """Capture l'audit_event posé."""
    captured: list[dict[str, Any]] = []

    def _fake_record(**kwargs):
        captured.append(kwargs)

    monkeypatch.setattr(rgpd_service.audit_service, "record_event", _fake_record)
    return captured


@pytest.mark.asyncio
async def test_put_first_time_cnsa_true_sets_consenti_at(
    monkeypatch, patch_run_in_thread, patch_repo_upsert, patch_audit
):
    monkeypatch.setattr(rgpd_service.rgpd_repo, "get_by_exercice", lambda ex: None)
    payload = RecueilConsentementUpdate(
        consentement_cnsa=True,
        federations=FederationsConsenties(selected_known=["FEHAP"]),
        duree="1_an",
    )
    resp = await rgpd_service.put_consentement(
        exercice_id=EXERCICE,
        company_id=COMPANY,
        user_id=USER,
        payload=payload,
    )
    kwargs = patch_repo_upsert["kwargs"]
    assert kwargs["consenti_at"] is not None
    assert kwargs["revoque_at"] is None
    assert resp.consentement_cnsa is True
    # Audit posé
    assert len(patch_audit) == 1
    ev = patch_audit[0]
    assert ev["action"] == "rgpd.consent"
    assert ev["payload"]["from_cnsa"] is None
    assert ev["payload"]["to_cnsa"] is True
    assert ev["payload"]["federations_count"] == 1
    assert ev["payload"]["duree"] == "1_an"


@pytest.mark.asyncio
async def test_put_first_time_cnsa_false_keeps_both_null(
    monkeypatch, patch_run_in_thread, patch_repo_upsert, patch_audit
):
    monkeypatch.setattr(rgpd_service.rgpd_repo, "get_by_exercice", lambda ex: None)
    payload = RecueilConsentementUpdate(consentement_cnsa=False)
    await rgpd_service.put_consentement(
        exercice_id=EXERCICE,
        company_id=COMPANY,
        user_id=USER,
        payload=payload,
    )
    kwargs = patch_repo_upsert["kwargs"]
    assert kwargs["consenti_at"] is None
    assert kwargs["revoque_at"] is None


@pytest.mark.asyncio
async def test_put_toggle_true_to_false_sets_revoque_at(
    monkeypatch, patch_run_in_thread, patch_repo_upsert, patch_audit
):
    prev_consenti = datetime(2026, 1, 1, tzinfo=UTC)
    monkeypatch.setattr(
        rgpd_service.rgpd_repo,
        "get_by_exercice",
        lambda ex: _row(consentement_cnsa=True, consenti_at=prev_consenti),
    )
    payload = RecueilConsentementUpdate(consentement_cnsa=False)
    await rgpd_service.put_consentement(
        exercice_id=EXERCICE,
        company_id=COMPANY,
        user_id=USER,
        payload=payload,
    )
    kwargs = patch_repo_upsert["kwargs"]
    assert kwargs["consenti_at"] == prev_consenti  # inchangé
    assert kwargs["revoque_at"] is not None  # nouvellement posé


@pytest.mark.asyncio
async def test_put_toggle_false_to_true_resets_revoque_at(
    monkeypatch, patch_run_in_thread, patch_repo_upsert, patch_audit
):
    prev_revoque = datetime(2026, 2, 1, tzinfo=UTC)
    monkeypatch.setattr(
        rgpd_service.rgpd_repo,
        "get_by_exercice",
        lambda ex: _row(consentement_cnsa=False, revoque_at=prev_revoque),
    )
    payload = RecueilConsentementUpdate(
        consentement_cnsa=True,
        federations=FederationsConsenties(selected_known=["FHF"]),
        duree="jusqu_revocation",
    )
    await rgpd_service.put_consentement(
        exercice_id=EXERCICE,
        company_id=COMPANY,
        user_id=USER,
        payload=payload,
    )
    kwargs = patch_repo_upsert["kwargs"]
    assert kwargs["consenti_at"] is not None  # nouveau cycle
    assert kwargs["revoque_at"] is None  # reset


@pytest.mark.asyncio
async def test_put_404_exercice_unknown(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        rgpd_service.rgpd_repo,
        "exercice_belongs_to_company",
        lambda ex, co: False,
    )
    payload = RecueilConsentementUpdate(consentement_cnsa=False)
    with pytest.raises(NotFoundError) as exc:
        await rgpd_service.put_consentement(
            exercice_id=EXERCICE,
            company_id=COMPANY,
            user_id=USER,
            payload=payload,
        )
    assert exc.value.code == "exercice_not_found"
