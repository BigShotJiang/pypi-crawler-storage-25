"""Tests §Y — hook auto-ventilation H/D/S/SEA dans crp_ligne_service.

Couvre :

* create_ligne avec CR ternaire + compte 65 + montant_realise + cols
  H/D/S/SEA toutes None → auto-fill 100% H
* create_ligne avec CR ternaire + clé gestionnaire matchée →
  distribution selon taux
* create_ligne avec CR ternaire + saisie manuelle Σ KO → 422
* create_ligne avec CR 'simple' + user pose H → 422 forbidden
* create_ligne avec CR ternaire + nature='produit' → pas d'auto-vent
* bulk_upsert avec mix règle dure + clé + saisie manuelle Σ
* apply_default_ventilation_to_cr report counters
"""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.crp_ligne import BulkUpsertItem, CrpLigneCreate
from piilot_pack_compta_esms.repositories import cr_repo
from piilot_pack_compta_esms.services import crp_ligne_service, ventilation_service
from piilot_pack_compta_esms.services.errors import ValidationError

COMPANY = uuid4()
CR_ID = uuid4()
ETS_ID = uuid4()
LIGNE_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.crp_ligne_service.run_in_thread",
        _passthrough,
    )
    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.ventilation_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def cr_ternaire(monkeypatch):
    """Surcharge l'autouse fixture pour que le CR soit en ternaire_hds."""
    monkeypatch.setattr(
        cr_repo,
        "get_ventilation_context",
        lambda _: {
            "ventilation": "ternaire_hds",
            "etablissement_id": ETS_ID,
            "exercice_annee": 2026,
        },
    )


@pytest.fixture
def cr_repo_owns(monkeypatch):
    """Mock standard pour cr_belongs_to_company + freeze passthrough."""
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo, "cr_belongs_to_company", lambda c, co: True
    )


def _row(**overrides):
    # Filtre les overrides qui auraient un id=None (cas BulkUpsertItem
    # qui dump id=None par défaut) — on garde l'id du base.
    overrides = {k: v for k, v in overrides.items() if not (k == "id" and v is None)}
    base = {
        "id": LIGNE_ID,
        "company_id": COMPANY,
        "cr_id": CR_ID,
        "groupe": "G1",
        "nature": "charge",
        "compte_m22bis": "65",
        "compte_label": None,
        "montant_budget_initial": None,
        "montant_virements_credits": None,
        "montant_decisions_modif": None,
        "montant_previsions_totales": None,
        "montant_realise": Decimal("1000"),
        "montant_hebergement": None,
        "montant_dependance": None,
        "montant_soins": None,
        "montant_soins_autonomie": None,
        "binding_id": None,
        "saisie_manuelle": True,
        "override_balance": False,
        "override_reason": None,
        "override_at": None,
        "notes": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# create_ligne — règle dure auto-fill
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_ligne_compte_65_auto_h(
    monkeypatch, patch_run_in_thread, cr_ternaire, cr_repo_owns
):
    """CR ternaire + compte 65 + montant_realise → auto-fill 100% H."""
    captured: dict = {}

    def _create_capture(company_id, cr_id, payload):
        captured.update(payload)
        return _row(
            montant_hebergement=payload.get("montant_hebergement"),
            montant_dependance=payload.get("montant_dependance"),
            montant_soins=payload.get("montant_soins"),
            montant_soins_autonomie=payload.get("montant_soins_autonomie"),
        )

    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "create", _create_capture)

    out = await crp_ligne_service.create_ligne(
        CR_ID,
        COMPANY,
        CrpLigneCreate(
            groupe="G1",
            nature="charge",
            compte_m22bis="65",
            montant_realise=Decimal("1000"),
        ),
    )
    assert out.montant_hebergement == Decimal("1000")
    assert captured["montant_hebergement"] == Decimal("1000")
    assert captured["montant_dependance"] == Decimal("0")
    assert captured["montant_soins"] == Decimal("0")


@pytest.mark.asyncio
async def test_create_ligne_clef_gestionnaire(
    monkeypatch, patch_run_in_thread, cr_ternaire, cr_repo_owns
):
    """CR ternaire + compte avec clé → distribution taux."""
    monkeypatch.setattr(
        ventilation_service.cles_repartition_repo,
        "batch_lookup",
        lambda ets, annee, comptes: {
            "60222": {
                "taux_hebergement": Decimal("60"),
                "taux_dependance": Decimal("30"),
                "taux_soins": Decimal("10"),
                "taux_soins_autonomie": Decimal("0"),
            }
        },
    )
    captured: dict = {}

    def _create_clef(*, company_id, cr_id, payload):
        captured.update(payload)
        return _row(**payload)

    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "create", _create_clef)

    await crp_ligne_service.create_ligne(
        CR_ID,
        COMPANY,
        CrpLigneCreate(
            groupe="G1",
            nature="charge",
            compte_m22bis="60222",
            montant_realise=Decimal("1000"),
        ),
    )
    assert captured["montant_hebergement"] == Decimal("600.00")
    assert captured["montant_dependance"] == Decimal("300.00")
    assert captured["montant_soins"] == Decimal("100.00")


@pytest.mark.asyncio
async def test_create_ligne_explicit_sum_mismatch_422(
    monkeypatch, patch_run_in_thread, cr_ternaire, cr_repo_owns
):
    """CR ternaire + saisie explicite Σ KO → 422 sum_mismatch."""
    monkeypatch.setattr(
        ventilation_service.cles_repartition_repo,
        "batch_lookup",
        lambda ets, annee, comptes: {},
    )
    with pytest.raises(ValidationError) as exc:
        await crp_ligne_service.create_ligne(
            CR_ID,
            COMPANY,
            CrpLigneCreate(
                groupe="G1",
                nature="charge",
                compte_m22bis="60226",
                montant_realise=Decimal("1000"),
                montant_hebergement=Decimal("500"),
                montant_dependance=Decimal("200"),
                montant_soins=Decimal("100"),  # 800 ≠ 1000
            ),
        )
    assert exc.value.code == "ventilation_sum_mismatch"


@pytest.mark.asyncio
async def test_create_ligne_simple_forbids_h_d_s(monkeypatch, patch_run_in_thread, cr_repo_owns):
    """CR ventilation='simple' (autouse default) + user pose H → 422."""
    with pytest.raises(ValidationError) as exc:
        await crp_ligne_service.create_ligne(
            CR_ID,
            COMPANY,
            CrpLigneCreate(
                groupe="G1",
                nature="charge",
                compte_m22bis="65",
                montant_realise=Decimal("100"),
                montant_hebergement=Decimal("100"),
            ),
        )
    assert exc.value.code == "ventilation_forbidden_for_simple"


@pytest.mark.asyncio
async def test_create_ligne_produit_no_auto_vent(
    monkeypatch, patch_run_in_thread, cr_ternaire, cr_repo_owns
):
    """nature='produit' → pas d'auto-vent (les produits suivent règles
    fiscales différentes hors v0.2 scope)."""
    captured: dict = {}

    def _create_produit(*, company_id, cr_id, payload):
        captured.update(payload)
        return _row(**payload)

    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "create", _create_produit)
    monkeypatch.setattr(
        ventilation_service.cles_repartition_repo,
        "batch_lookup",
        lambda ets, annee, comptes: {},
    )

    await crp_ligne_service.create_ligne(
        CR_ID,
        COMPANY,
        CrpLigneCreate(
            groupe="G1",
            nature="produit",
            compte_m22bis="70",
            montant_realise=Decimal("500"),
        ),
    )
    # Aucune col H/D/S/SEA n'a été remplie automatiquement
    assert captured.get("montant_hebergement") is None
    assert captured.get("montant_dependance") is None
    assert captured.get("montant_soins") is None


# ---------------------------------------------------------------------------
# bulk_upsert
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_upsert_batch_auto_vent(
    monkeypatch, patch_run_in_thread, cr_ternaire, cr_repo_owns
):
    """Bulk upsert : 1 règle dure 65, 1 clé 60222 — toutes ventilées."""
    monkeypatch.setattr(
        ventilation_service.cles_repartition_repo,
        "batch_lookup",
        lambda ets, annee, comptes: {
            "60222": {
                "taux_hebergement": Decimal("50"),
                "taux_dependance": Decimal("30"),
                "taux_soins": Decimal("20"),
                "taux_soins_autonomie": Decimal("0"),
            }
        },
    )
    captured: list = []

    def _bulk(*, company_id, cr_id, items, binding_id):
        captured.extend(items)
        return [_row(**it) for it in items]

    monkeypatch.setattr(crp_ligne_service.crp_ligne_repo, "bulk_upsert", _bulk)

    items = [
        BulkUpsertItem(
            groupe="G1",
            nature="charge",
            compte_m22bis="65",
            montant_realise=Decimal("1000"),
        ),
        BulkUpsertItem(
            groupe="G1",
            nature="charge",
            compte_m22bis="60222",
            montant_realise=Decimal("500"),
        ),
    ]
    await crp_ligne_service.bulk_upsert(CR_ID, COMPANY, items)

    # Ligne 65 → 100% H
    assert captured[0]["montant_hebergement"] == Decimal("1000")
    assert captured[0]["montant_soins"] == Decimal("0")
    # Ligne 60222 → distribution clé
    assert captured[1]["montant_hebergement"] == Decimal("250.00")
    assert captured[1]["montant_dependance"] == Decimal("150.00")
    assert captured[1]["montant_soins"] == Decimal("100.00")


# ---------------------------------------------------------------------------
# apply_default_ventilation_to_cr
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_apply_default_to_cr_counters(
    monkeypatch, patch_run_in_thread, cr_ternaire, cr_repo_owns
):
    """Reporting buckets correct sur un mix de lignes."""
    monkeypatch.setattr(
        ventilation_service.cles_repartition_repo,
        "batch_lookup",
        lambda ets, annee, comptes: {},
    )
    lignes = [
        # Ligne déjà ventilée manuellement → skip
        _row(compte_m22bis="65", montant_hebergement=Decimal("1000")),
        # Ligne ventilable par règle dure
        _row(compte_m22bis="66", id=uuid4(), montant_realise=Decimal("500")),
        # Ligne sans règle ni clé → sans_regle
        _row(compte_m22bis="60226", id=uuid4(), montant_realise=Decimal("200")),
        # Ligne sans montant_basis → sans_regle
        _row(compte_m22bis="65", id=uuid4(), montant_realise=None),
    ]
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo,
        "list_by_cr",
        lambda cr_id, groupe, nature: lignes,
    )
    monkeypatch.setattr(
        crp_ligne_service.crp_ligne_repo,
        "update",
        lambda ligne_id, payload, flip_override_balance: _row(**payload),
    )

    report = await crp_ligne_service.apply_default_ventilation_to_cr(CR_ID, COMPANY)
    assert report["lignes_ventilees"] == 1  # règle dure 66
    assert report["lignes_skipees_manuelles"] == 1  # ligne déjà ventilée
    assert report["lignes_sans_regle"] == 2  # 60226 + ligne sans basis
    assert report["total_lignes_evaluees"] == 4
