"""Tests §Z — 5 contrôles bloquants C-001 / C-002 / C-003 / C-004 / C-005.

Couvre :

* C-001 — Bilan équilibré → ok ; déséquilibré → ko error ; rien saisi → na
* C-002 — H/D/S = total CRP sur lignes ventilées → ok ; écart → ko error ;
  aucun CR ternaire → na
* C-003 — R.314-222 EPRD : pas applicable ERRD → na ; squelette v0.2 → na ;
  KO condition évaluable → ko error
* C-004 — TPER annexe 6 (R.314-224, v0.3 §BG') : pas applicable hors
  EPRD → na ; aucune ligne TPER → ko error ; ≥1 ligne → ok
* C-005 — Annexe 4 Activité prévisionnelle (R.314-219, v0.3 §BG') :
  pas applicable hors EPRD → na ; aucune ligne 4A/B/C/D → ko error ;
  lignes 4x présentes → ok ; lignes 9x (réalisé) seules → ko
"""

from __future__ import annotations

from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.controls import c_001, c_002, c_003, c_004, c_005
from piilot_pack_compta_esms.controls._base import ControlContext
from piilot_pack_compta_esms.models.finance import EquilibreReelInput

COMPANY = uuid4()
DOC_ID = uuid4()


@pytest.fixture(autouse=True)
def _patch_controls_run_in_thread(monkeypatch):
    """Mock run_in_thread dans les modules de contrôle (sync passthrough)."""

    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    for module_path in (
        "piilot_pack_compta_esms.controls.c_002.run_in_thread",
        "piilot_pack_compta_esms.controls.c_003.run_in_thread",
        "piilot_pack_compta_esms.controls.c_004.run_in_thread",
        "piilot_pack_compta_esms.controls.c_005.run_in_thread",
        "piilot_pack_compta_esms.controls.c_computables.run_in_thread",
    ):
        monkeypatch.setattr(module_path, _passthrough)


def _ctx(type_document="errd"):
    return ControlContext(
        document_id=DOC_ID,
        company_id=COMPANY,
        document={
            "id": DOC_ID,
            "company_id": COMPANY,
            "type_document": type_document,
            "statut": "brouillon",
        },
    )


# ---------------------------------------------------------------------------
# C-001 Bilan équilibre
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_001_no_bilan_returns_na(monkeypatch) -> None:
    """Aucune ligne bilan saisie → na."""
    from piilot_pack_compta_esms.services import bilan_service

    async def _validate(*args, **kwargs):
        from piilot_pack_compta_esms.models.bilan import BilanValidationResult

        return BilanValidationResult(valide=True, issues=[], tolerance_appliquee=Decimal("0.01"))

    async def _totals(*args, **kwargs):
        from piilot_pack_compta_esms.models.bilan import BilanTotalsResponse

        return BilanTotalsResponse(financier=None, comptable_pc=None, comptable_pnl=None)

    monkeypatch.setattr(bilan_service, "validate_equilibre", _validate)
    monkeypatch.setattr(bilan_service, "compute_totals", _totals)

    r = await c_001.evaluate(_ctx())
    assert r.statut == "na"


@pytest.mark.asyncio
async def test_c_001_equilibre_ok(monkeypatch) -> None:
    """Bilan financier équilibré → ok."""
    from piilot_pack_compta_esms.services import bilan_service

    async def _validate(*args, **kwargs):
        from piilot_pack_compta_esms.models.bilan import BilanValidationResult

        return BilanValidationResult(valide=True, issues=[], tolerance_appliquee=Decimal("0.01"))

    async def _totals(*args, **kwargs):
        from piilot_pack_compta_esms.models.bilan import (
            BilanTotalsForType,
            BilanTotalsResponse,
        )

        block = BilanTotalsForType(
            type_bilan="financier",
            by_section=[],
            total_biens=Decimal("100000"),
            total_financements=Decimal("100000"),
            ecart=Decimal("0"),
        )
        return BilanTotalsResponse(financier=block, comptable_pc=None, comptable_pnl=None)

    monkeypatch.setattr(bilan_service, "validate_equilibre", _validate)
    monkeypatch.setattr(bilan_service, "compute_totals", _totals)

    r = await c_001.evaluate(_ctx())
    assert r.statut == "ok"
    assert "financier" in r.valeurs_observees["variantes_validees"]


@pytest.mark.asyncio
async def test_c_001_desequilibre_ko_error(monkeypatch) -> None:
    """Bilan déséquilibré → ko severite=error (bloquant transition)."""
    from piilot_pack_compta_esms.services import bilan_service

    async def _validate(*args, **kwargs):
        from piilot_pack_compta_esms.models.bilan import (
            BilanValidationIssue,
            BilanValidationResult,
        )

        return BilanValidationResult(
            valide=False,
            issues=[
                BilanValidationIssue(
                    code="ecart_above_tolerance",
                    type_bilan="financier",
                    message="désequilibre",
                    ecart=Decimal("50"),
                )
            ],
            tolerance_appliquee=Decimal("0.01"),
        )

    monkeypatch.setattr(bilan_service, "validate_equilibre", _validate)

    r = await c_001.evaluate(_ctx())
    assert r.statut == "ko"
    assert r.severite == "error"
    assert r.valeurs_observees["types_bilan_ko"] == ["financier"]


# ---------------------------------------------------------------------------
# C-002 Cohérence H/D/S = total CRP
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_002_no_ternaire_returns_na(monkeypatch) -> None:
    """Aucun CR ternaire → na."""
    from piilot_pack_compta_esms.repositories import cr_repo

    monkeypatch.setattr(
        cr_repo,
        "list_by_document",
        lambda _: [{"id": uuid4(), "ventilation": "simple", "denomination": "X"}],
    )

    r = await c_002.evaluate(_ctx())
    assert r.statut == "na"


@pytest.mark.asyncio
async def test_c_002_coherent_returns_ok(monkeypatch) -> None:
    """Lignes ventilées Σ = total → ok."""
    from piilot_pack_compta_esms.repositories import cr_repo, crp_ligne_repo

    cr_id = uuid4()
    monkeypatch.setattr(
        cr_repo,
        "list_by_document",
        lambda _: [{"id": cr_id, "ventilation": "ternaire_hds", "denomination": "CRPP"}],
    )
    monkeypatch.setattr(
        crp_ligne_repo,
        "list_by_cr",
        lambda cr, groupe, nature: [
            {
                "compte_m22bis": "65",
                "montant_realise": Decimal("100"),
                "montant_hebergement": Decimal("100"),
                "montant_dependance": Decimal("0"),
                "montant_soins": Decimal("0"),
                "montant_soins_autonomie": Decimal("0"),
            }
        ],
    )

    r = await c_002.evaluate(_ctx())
    assert r.statut == "ok"
    assert r.valeurs_observees["lignes_verifiees"] == 1


@pytest.mark.asyncio
async def test_c_002_incoherent_returns_ko_error(monkeypatch) -> None:
    """Σ H/D/S ≠ basis → ko error bloquant."""
    from piilot_pack_compta_esms.repositories import cr_repo, crp_ligne_repo

    cr_id = uuid4()
    monkeypatch.setattr(
        cr_repo,
        "list_by_document",
        lambda _: [{"id": cr_id, "ventilation": "ternaire_hds", "denomination": "CRPP"}],
    )
    monkeypatch.setattr(
        crp_ligne_repo,
        "list_by_cr",
        lambda cr, groupe, nature: [
            {
                "compte_m22bis": "60222",
                "montant_realise": Decimal("100"),
                "montant_hebergement": Decimal("50"),
                "montant_dependance": Decimal("30"),
                "montant_soins": Decimal("10"),  # 90 ≠ 100
                "montant_soins_autonomie": Decimal("0"),
            }
        ],
    )

    r = await c_002.evaluate(_ctx())
    assert r.statut == "ko"
    assert r.severite == "error"
    assert r.valeurs_observees["nb_anomalies"] == 1


@pytest.mark.asyncio
async def test_c_002_skipped_lines_not_counted(monkeypatch) -> None:
    """Lignes avec 4 cols à 0 (pas encore saisies) sont skip — na si toutes."""
    from piilot_pack_compta_esms.repositories import cr_repo, crp_ligne_repo

    cr_id = uuid4()
    monkeypatch.setattr(
        cr_repo,
        "list_by_document",
        lambda _: [{"id": cr_id, "ventilation": "ternaire_hds", "denomination": "CRPP"}],
    )
    monkeypatch.setattr(
        crp_ligne_repo,
        "list_by_cr",
        lambda cr, groupe, nature: [
            {
                "compte_m22bis": "60222",
                "montant_realise": Decimal("100"),
                "montant_hebergement": Decimal("0"),
                "montant_dependance": Decimal("0"),
                "montant_soins": Decimal("0"),
                "montant_soins_autonomie": Decimal("0"),
            }
        ],
    )
    r = await c_002.evaluate(_ctx())
    assert r.statut == "na"


# ---------------------------------------------------------------------------
# C-003 Équilibre réel R.314-222
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_003_errd_not_applicable() -> None:
    """ERRD → C-003 na (applicable EPRD seulement)."""
    r = await c_003.evaluate(_ctx(type_document="errd"))
    assert r.statut == "na"
    assert "EPRD" in (r.message or "")


@pytest.mark.asyncio
async def test_c_003_eprd_squelette_returns_na() -> None:
    """EPRD avec inputs None (v0.2 squelette) → na non-bloquant."""
    r = await c_003.evaluate(_ctx(type_document="eprd"))
    assert r.statut == "na"
    assert "non-évaluable" in (r.message or "")


@pytest.mark.asyncio
async def test_c_003_eprd_all_passed_returns_ok() -> None:
    """EPRD avec input équilibre complet et tout OK → ok."""
    ctx = _ctx(type_document="eprd")
    ctx.custom["equilibre_input"] = EquilibreReelInput(
        produits_tarif_saisis=Decimal("100000"),
        produits_tarif_notifies=Decimal("100000"),
        sincerite_commentee=True,
        capital_rembourse_via_emprunt=Decimal("0"),
        caf_n=Decimal("50000"),
        capital_a_rembourser_n=Decimal("30000"),
        recettes_affectees=Decimal("10000"),
        recettes_affectees_utilisees=Decimal("10000"),
    )
    r = await c_003.evaluate(ctx)
    assert r.statut == "ok"


@pytest.mark.asyncio
async def test_c_003_eprd_caf_insufficient_returns_ko_error() -> None:
    """CAF < capital → condition 4 KO → ko error bloquant."""
    ctx = _ctx(type_document="eprd")
    ctx.custom["equilibre_input"] = EquilibreReelInput(
        produits_tarif_saisis=Decimal("100000"),
        produits_tarif_notifies=Decimal("100000"),
        sincerite_commentee=True,
        capital_rembourse_via_emprunt=Decimal("0"),
        caf_n=Decimal("10000"),
        capital_a_rembourser_n=Decimal("30000"),
        recettes_affectees=Decimal("10000"),
        recettes_affectees_utilisees=Decimal("10000"),
    )
    r = await c_003.evaluate(ctx)
    assert r.statut == "ko"
    assert r.severite == "error"
    assert 4 in r.valeurs_observees["condition_ko_ids"]


# ---------------------------------------------------------------------------
# C-004 TPER annexe 6 non vide (R.314-224, v0.3 §BG')
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_004_errd_not_applicable() -> None:
    """ERRD → C-004 na (applicable EPRD seulement, ERRD a TER pas TPER)."""
    r = await c_004.evaluate(_ctx(type_document="errd"))
    assert r.statut == "na"
    assert "EPRD" in (r.message or "")


@pytest.mark.asyncio
async def test_c_004_dm_not_applicable() -> None:
    """DM → C-004 na (hérite du TPER parent EPRD)."""
    r = await c_004.evaluate(_ctx(type_document="dm"))
    assert r.statut == "na"


@pytest.mark.asyncio
async def test_c_004_epcp_not_applicable() -> None:
    """EPCP (sanitaire) → C-004 na (pas de TPER)."""
    r = await c_004.evaluate(_ctx(type_document="epcp"))
    assert r.statut == "na"


@pytest.mark.asyncio
async def test_c_004_eprd_empty_tper_returns_ko_error(monkeypatch) -> None:
    """EPRD avec 0 ligne TPER → ko severite=error (bloquant transition)."""
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo,
        "list_by_filter",
        lambda doc, ets, tt: [],
    )
    r = await c_004.evaluate(_ctx(type_document="eprd"))
    assert r.statut == "ko"
    assert r.severite == "error"
    assert r.valeurs_observees["nb_lignes_tper"] == 0
    assert "R.314-224" in (r.message or "")


@pytest.mark.asyncio
async def test_c_004_eprd_with_tper_returns_ok(monkeypatch) -> None:
    """EPRD avec ≥1 ligne TPER → ok."""
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo,
        "list_by_filter",
        lambda doc, ets, tt: [
            {"id": uuid4(), "type_tableau": "TPER", "categorie_cnsa": "DIRECTION"},
            {"id": uuid4(), "type_tableau": "TPER", "categorie_cnsa": "SOINS"},
            {"id": uuid4(), "type_tableau": "TPER", "categorie_cnsa": "ASH"},
        ],
    )
    r = await c_004.evaluate(_ctx(type_document="eprd"))
    assert r.statut == "ok"
    assert r.valeurs_observees["nb_lignes_tper"] == 3


@pytest.mark.asyncio
async def test_c_004_eprd_repo_called_with_tper_filter(monkeypatch) -> None:
    """Le contrôle ne doit voir QUE les lignes TPER, pas TER (réalisé)."""
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    captured: dict = {}

    def _fake_list(doc, ets, type_tableau):
        captured["type_tableau"] = type_tableau
        return [{"id": uuid4()}]

    monkeypatch.setattr(tper_ter_repo, "list_by_filter", _fake_list)
    await c_004.evaluate(_ctx(type_document="eprd"))
    assert captured["type_tableau"] == "TPER"


# ---------------------------------------------------------------------------
# C-005 Annexe 4 Activité prévisionnelle non vide (R.314-219, v0.3 §BG')
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_005_errd_not_applicable() -> None:
    """ERRD → C-005 na (Annexe 9 réalisée gérée séparément)."""
    r = await c_005.evaluate(_ctx(type_document="errd"))
    assert r.statut == "na"
    assert "EPRD" in (r.message or "")


@pytest.mark.asyncio
async def test_c_005_avenant_not_applicable() -> None:
    """AVENANT → C-005 na (hérite de l'annexe 4 parent EPRD)."""
    r = await c_005.evaluate(_ctx(type_document="avenant"))
    assert r.statut == "na"


@pytest.mark.asyncio
async def test_c_005_eprd_empty_returns_ko_error(monkeypatch) -> None:
    """EPRD avec 0 ligne annexe 4 → ko severite=error."""
    from piilot_pack_compta_esms.repositories import activite_repo

    monkeypatch.setattr(activite_repo, "list_by_filter", lambda doc, ets, av: [])
    r = await c_005.evaluate(_ctx(type_document="eprd"))
    assert r.statut == "ko"
    assert r.severite == "error"
    assert r.valeurs_observees["nb_lignes_annexe4"] == 0
    assert "R.314-219" in (r.message or "")


@pytest.mark.asyncio
async def test_c_005_eprd_with_4a_lines_returns_ok(monkeypatch) -> None:
    """EPRD avec ≥1 ligne 4A → ok."""
    from piilot_pack_compta_esms.repositories import activite_repo

    monkeypatch.setattr(
        activite_repo,
        "list_by_filter",
        lambda doc, ets, av: [
            {"annexe_variante": "4A_ehpad_puv", "section": "hp", "gir": "gir3"},
            {"annexe_variante": "4A_ehpad_puv", "section": "hp", "gir": "gir4"},
        ],
    )
    r = await c_005.evaluate(_ctx(type_document="eprd"))
    assert r.statut == "ok"
    assert r.valeurs_observees["nb_lignes_annexe4"] == 2


@pytest.mark.asyncio
async def test_c_005_eprd_with_4_mixed_variants_counts_all(monkeypatch) -> None:
    """4A + 4B + 4C + 4D toutes comptées comme annexe 4 prévisionnelle."""
    from piilot_pack_compta_esms.repositories import activite_repo

    monkeypatch.setattr(
        activite_repo,
        "list_by_filter",
        lambda doc, ets, av: [
            {"annexe_variante": "4A_ehpad_puv"},
            {"annexe_variante": "4B_autres_essms"},
            {"annexe_variante": "4C_creton"},
            {"annexe_variante": "4D_sad_spasad"},
        ],
    )
    r = await c_005.evaluate(_ctx(type_document="eprd"))
    assert r.statut == "ok"
    assert r.valeurs_observees["nb_lignes_annexe4"] == 4


@pytest.mark.asyncio
async def test_c_005_eprd_only_9x_lines_returns_ko(monkeypatch) -> None:
    """EPRD avec seulement des lignes 9A/9B (réalisé) → ko (les 9x sont
    l'Annexe 9 ERRD, pas l'Annexe 4 prévisionnelle EPRD).
    """
    from piilot_pack_compta_esms.repositories import activite_repo

    monkeypatch.setattr(
        activite_repo,
        "list_by_filter",
        lambda doc, ets, av: [
            {"annexe_variante": "9A_ehpad_realise"},
            {"annexe_variante": "9B_autres_realise"},
        ],
    )
    r = await c_005.evaluate(_ctx(type_document="eprd"))
    assert r.statut == "ko"
    assert r.valeurs_observees["nb_lignes_annexe4"] == 0


@pytest.mark.asyncio
async def test_c_005_eprd_mixed_4_and_9_counts_only_4x(monkeypatch) -> None:
    """EPRD avec 2 lignes 4A + 3 lignes 9A → ok mais nb_lignes_annexe4=2."""
    from piilot_pack_compta_esms.repositories import activite_repo

    monkeypatch.setattr(
        activite_repo,
        "list_by_filter",
        lambda doc, ets, av: [
            {"annexe_variante": "4A_ehpad_puv"},
            {"annexe_variante": "4A_ehpad_puv"},
            {"annexe_variante": "9A_ehpad_realise"},
            {"annexe_variante": "9A_ehpad_realise"},
            {"annexe_variante": "9A_ehpad_realise"},
        ],
    )
    r = await c_005.evaluate(_ctx(type_document="eprd"))
    assert r.statut == "ok"
    assert r.valeurs_observees["nb_lignes_annexe4"] == 2


# ---------------------------------------------------------------------------
# BLOQUANT_CODES — exposed set is the source of truth pour workflow guard
# ---------------------------------------------------------------------------


def test_bloquant_codes_includes_c_004_c_005() -> None:
    """Garde-fou : la modification de BLOQUANT_CODES doit suivre l'ajout
    des handlers @register(C-004) / @register(C-005). Sinon les contrôles
    sont enregistrés mais non appliqués au transmit guard.
    """
    from piilot_pack_compta_esms.services.controles_service import BLOQUANT_CODES

    assert "C-004" in BLOQUANT_CODES
    assert "C-005" in BLOQUANT_CODES
    assert len(BLOQUANT_CODES) == 5
