"""Tests §AA — ratios endettement (D-091 KB25 §8.1).

Couvre R-1.1 (indépendance financière), R-1.2 (apurement dette),
R-1.3 (durée apparente dette).
"""

from __future__ import annotations

from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.ratios import r_endettement
from piilot_pack_compta_esms.ratios._base import RatioContext

COMPANY = uuid4()
DOC_ID = uuid4()


@pytest.fixture(autouse=True)
def _patch_lazy_loaders(monkeypatch):
    """Les tests fournissent les caches via ctx.custom — stub loaders."""

    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr("piilot_pack_compta_esms.ratios._base.run_in_thread", _passthrough)

    from piilot_pack_compta_esms.repositories import bilan_repo, cr_repo, emprunts_repo

    monkeypatch.setattr(bilan_repo, "list_by_document", lambda d, **kw: [])
    monkeypatch.setattr(cr_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(emprunts_repo, "list_by_document", lambda d: [])


def _ctx(**custom):
    ctx = RatioContext(
        document_id=DOC_ID,
        company_id=COMPANY,
        document={"id": DOC_ID, "company_id": COMPANY, "type_document": "errd"},
    )
    ctx.custom.update(custom)
    return ctx


def _bilan(**overrides):
    """Helper Bilan : un dict compte → {net_n, brut_n, amort_n, ...}."""
    base = {}
    for compte, montants in overrides.items():
        base[compte] = {
            "brut_n": Decimal(montants.get("brut_n", 0)),
            "amort_n": Decimal(montants.get("amort_n", 0)),
            "net_n": Decimal(montants.get("net_n", 0)),
            "net_n1": Decimal(montants.get("net_n1", 0)),
            "type_actif_passif": montants.get("type"),
        }
    return base


# ---------------------------------------------------------------------------
# R-1.1 Indépendance financière
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_r_1_1_ok_below_seuil() -> None:
    """Ratio 1.1 < 50% → ok."""
    ctx = _ctx(
        bilan_index=_bilan(
            **{
                "164": {"net_n": "100000"},  # emprunts c/16
                "11": {"net_n": "50000"},  # à exclure du FRI calc
                "12": {"net_n": "30000"},  # à exclure
                "10": {"net_n": "300000"},  # capital
                "16": {"net_n": "100000"},  # emprunts agrégés
            }
        )
    )
    r = await r_endettement.r_1_1(ctx)
    # FRI = c/1 net_n - c/11 - c/12 = (50000+30000+300000+100000) - 50000 - 30000 = 400000
    # Emprunts c/16 hors 165/1688/169 = 100000 (164) + 100000 (16) = 200000
    # Ratio = 200000 * 100 / 400000 = 50% → seuil_max=50 → ok (égal)
    assert r.verdict in {"ok", "atypie"}  # à la borne


@pytest.mark.asyncio
async def test_r_1_1_atypie_above_seuil() -> None:
    """Ratio 1.1 > 50% → atypie."""
    ctx = _ctx(
        bilan_index=_bilan(
            **{
                "164": {"net_n": "300000"},  # emprunts élevés
                "10": {"net_n": "100000"},  # capital faible
            }
        )
    )
    r = await r_endettement.r_1_1(ctx)
    assert r.verdict == "atypie"
    assert r.valeur is not None
    assert r.valeur > Decimal("50")


@pytest.mark.asyncio
async def test_r_1_1_na_when_fri_zero() -> None:
    """FRI = 0 → na."""
    ctx = _ctx(bilan_index={})
    r = await r_endettement.r_1_1(ctx)
    assert r.verdict == "na"


# ---------------------------------------------------------------------------
# R-1.2 Apurement de la dette
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_r_1_2_ok_above_seuil() -> None:
    """Immo / dette > 2 → ok."""
    ctx = _ctx(
        bilan_index=_bilan(
            **{
                "21": {"net_n": "500000"},  # immo
                "164": {"net_n": "100000"},  # dette
            }
        )
    )
    r = await r_endettement.r_1_2(ctx)
    # Ratio = 500000 / 100000 = 5 > 2 → ok
    assert r.verdict == "ok"
    assert r.valeur == Decimal("5")


@pytest.mark.asyncio
async def test_r_1_2_atypie_below_seuil() -> None:
    """Immo / dette < 2 → atypie."""
    ctx = _ctx(
        bilan_index=_bilan(
            **{
                "21": {"net_n": "100000"},
                "164": {"net_n": "200000"},
            }
        )
    )
    r = await r_endettement.r_1_2(ctx)
    assert r.verdict == "atypie"


@pytest.mark.asyncio
async def test_r_1_2_na_when_no_dette() -> None:
    """Pas de dette → na (pas de division par 0)."""
    ctx = _ctx(bilan_index=_bilan(**{"21": {"net_n": "100000"}}))
    r = await r_endettement.r_1_2(ctx)
    assert r.verdict == "na"


# ---------------------------------------------------------------------------
# R-1.3 Durée apparente de la dette
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_r_1_3_na_when_caf_zero() -> None:
    """CAF nulle → na (durée non calculable)."""
    ctx = _ctx(
        bilan_index=_bilan(**{"164": {"net_n": "100000"}}),
        crp_by_account={},  # CAF = 0
    )
    r = await r_endettement.r_1_3(ctx)
    assert r.verdict == "na"


@pytest.mark.asyncio
async def test_r_1_3_computes_years() -> None:
    """CAF positive → durée en années."""
    ctx = _ctx(
        bilan_index=_bilan(**{"164": {"net_n": "500000"}}),
        crp_by_account={
            "70": {
                "charges_realise": Decimal(0),
                "produits_realise": Decimal("200000"),
                "charges_prevu": Decimal(0),
                "produits_prevu": Decimal(0),
            },
            "60": {
                "charges_realise": Decimal("100000"),
                "produits_realise": Decimal(0),
                "charges_prevu": Decimal(0),
                "produits_prevu": Decimal(0),
            },
        },
    )
    # CAF = produits 200000 - charges décaissables 100000 = 100000
    # Durée = 500000 / 100000 = 5 ans
    r = await r_endettement.r_1_3(ctx)
    assert r.verdict == "ok"
    assert r.valeur == Decimal("5")
