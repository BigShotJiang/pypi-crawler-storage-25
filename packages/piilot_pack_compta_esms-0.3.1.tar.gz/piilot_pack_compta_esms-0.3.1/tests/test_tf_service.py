"""Unit tests for :mod:`piilot_pack_compta_esms.services.tf_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.tf import (
    TfBulkUpsertRequest,
    TfLigneCreate,
)
from piilot_pack_compta_esms.services import tf_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
DOC_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.tf_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def errd_doc(monkeypatch):
    """doc.type_document='errd' → type_tf=TF (4 colonnes)."""
    monkeypatch.setattr(
        tf_service.tf_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        tf_service.tf_repo,
        "get_doc_type_document",
        lambda doc, company: {"type_document": "errd"},
    )


@pytest.fixture
def eprd_doc(monkeypatch):
    """doc.type_document='eprd' → type_tf=TFP (8 colonnes)."""
    monkeypatch.setattr(
        tf_service.tf_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        tf_service.tf_repo,
        "get_doc_type_document",
        lambda doc, company: {"type_document": "eprd"},
    )


def _row(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "cote": "ressources",
        "titre": "Titre 1",
        "compte_m22bis": None,
        "libelle": "CAF",
        "montant_budget_initial_n1": None,
        "montant_realisations_n1": None,
        "montant_previsions_n": None,
        "montant_realisations_n": Decimal("100000"),
        "montant_nm1": None,
        "montant_n": None,
        "montant_np1": None,
        "montant_np2": None,
        "montant_np3": None,
        "montant_np4": None,
        "montant_np5": None,
        "montant_np6": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Q1 — auto-déduction type_tf via doc.type_document
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_tf_errd_is_tf(monkeypatch, errd_doc, patch_run_in_thread):
    monkeypatch.setattr(tf_service.tf_repo, "list_by_document", lambda _: [])
    out = await tf_service.list_tf(DOC_ID, COMPANY)
    assert out.type_tf == "TF"
    assert out.items == []


@pytest.mark.asyncio
async def test_list_tf_eprd_is_tfp(monkeypatch, eprd_doc, patch_run_in_thread):
    monkeypatch.setattr(tf_service.tf_repo, "list_by_document", lambda _: [])
    out = await tf_service.list_tf(DOC_ID, COMPANY)
    assert out.type_tf == "TFP"


@pytest.mark.asyncio
async def test_list_tf_other_doc_type_defaults_to_tf(monkeypatch, patch_run_in_thread):
    """Q1 — autres doc_types (dm, ria, ercp, epcp) → TF par défaut."""
    monkeypatch.setattr(
        tf_service.tf_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        tf_service.tf_repo,
        "get_doc_type_document",
        lambda doc, company: {"type_document": "dm"},
    )
    monkeypatch.setattr(tf_service.tf_repo, "list_by_document", lambda _: [])
    out = await tf_service.list_tf(DOC_ID, COMPANY)
    assert out.type_tf == "TF"


@pytest.mark.asyncio
async def test_list_tf_cross_tenant(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        tf_service.tf_repo,
        "get_doc_type_document",
        lambda doc, company: None,
    )
    with pytest.raises(NotFoundError):
        await tf_service.list_tf(DOC_ID, COMPANY)


@pytest.mark.asyncio
async def test_list_tf_items(monkeypatch, errd_doc, patch_run_in_thread):
    monkeypatch.setattr(
        tf_service.tf_repo,
        "list_by_document",
        lambda _: [_row(), _row(cote="emplois", libelle="Acquisitions")],
    )
    out = await tf_service.list_tf(DOC_ID, COMPANY)
    assert len(out.items) == 2
    assert out.items[0].cote == "ressources"
    assert out.items[1].cote == "emplois"


# ---------------------------------------------------------------------------
# Q2 — bulk_upsert_tf : replace_all_by_document atomique
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_upsert_replaces_all(monkeypatch, errd_doc, patch_run_in_thread):
    captured: dict = {}

    def _fake_replace(*, company_id, document_id, items):
        captured["items_count"] = len(items)
        return [_row()]

    monkeypatch.setattr(tf_service.tf_repo, "replace_all_by_document", _fake_replace)
    monkeypatch.setattr(tf_service.tf_repo, "list_by_document", lambda _: [_row()])

    await tf_service.bulk_upsert_tf(
        DOC_ID,
        COMPANY,
        TfBulkUpsertRequest(
            items=[
                TfLigneCreate(
                    cote="ressources",
                    titre="Titre 1",
                    libelle="CAF",
                    montant_realisations_n=Decimal("100000"),
                ),
                TfLigneCreate(
                    cote="emplois",
                    libelle="Total emplois",
                    montant_realisations_n=Decimal("100000"),
                ),
            ]
        ),
    )
    assert captured["items_count"] == 2


# ---------------------------------------------------------------------------
# Q3 + Q4 — compute_totals breakdown par titre + Q5 équilibre par colonne
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_compute_totals_tf_4_columns(monkeypatch, errd_doc, patch_run_in_thread):
    """TF (ERRD) — 4 colonnes ; les 8 TFP doivent être ignorées."""
    monkeypatch.setattr(
        tf_service.tf_repo,
        "totals_by_titre_cote",
        lambda _: [
            {
                "cote": "ressources",
                "titre": "Titre 1",
                "montant_budget_initial_n1": Decimal("0"),
                "montant_realisations_n1": Decimal("90000"),
                "montant_previsions_n": Decimal("0"),
                "montant_realisations_n": Decimal("100000"),
                "montant_nm1": Decimal("0"),
                "montant_n": Decimal("0"),
                "montant_np1": Decimal("0"),
                "montant_np2": Decimal("0"),
                "montant_np3": Decimal("0"),
                "montant_np4": Decimal("0"),
                "montant_np5": Decimal("0"),
                "montant_np6": Decimal("0"),
            },
            {
                "cote": "emplois",
                "titre": "Titre 2",
                "montant_budget_initial_n1": Decimal("0"),
                "montant_realisations_n1": Decimal("90000"),
                "montant_previsions_n": Decimal("0"),
                "montant_realisations_n": Decimal("100000"),
                "montant_nm1": Decimal("0"),
                "montant_n": Decimal("0"),
                "montant_np1": Decimal("0"),
                "montant_np2": Decimal("0"),
                "montant_np3": Decimal("0"),
                "montant_np4": Decimal("0"),
                "montant_np5": Decimal("0"),
                "montant_np6": Decimal("0"),
            },
        ],
    )
    out = await tf_service.compute_totals(DOC_ID, COMPANY)
    assert out.type_tf == "TF"
    # 4 colonnes TF, pas 8
    assert len(out.equilibre_by_column) == 4
    # Ressources et emplois s'équilibrent → valide_globalement=True
    assert out.valide_globalement is True
    # Breakdown par titre
    assert out.ressources is not None
    assert len(out.ressources.by_titre) == 1
    assert out.ressources.by_titre[0].titre == "Titre 1"


@pytest.mark.asyncio
async def test_compute_totals_tfp_8_columns(monkeypatch, eprd_doc, patch_run_in_thread):
    """TFP (EPRD) — 8 colonnes (D-094)."""
    monkeypatch.setattr(
        tf_service.tf_repo,
        "totals_by_titre_cote",
        lambda _: [
            {
                "cote": "ressources",
                "titre": "Titre 1",
                "montant_budget_initial_n1": Decimal("0"),
                "montant_realisations_n1": Decimal("0"),
                "montant_previsions_n": Decimal("0"),
                "montant_realisations_n": Decimal("0"),
                "montant_nm1": Decimal("50000"),
                "montant_n": Decimal("100000"),
                "montant_np1": Decimal("110000"),
                "montant_np2": Decimal("120000"),
                "montant_np3": Decimal("130000"),
                "montant_np4": Decimal("140000"),
                "montant_np5": Decimal("150000"),
                "montant_np6": Decimal("160000"),
            },
        ],
    )
    out = await tf_service.compute_totals(DOC_ID, COMPANY)
    assert out.type_tf == "TFP"
    assert len(out.equilibre_by_column) == 8
    # Pas d'emplois → ressources ≠ emplois → invalide
    assert out.valide_globalement is False


@pytest.mark.asyncio
async def test_compute_totals_equilibre_tolerance_accepted(
    monkeypatch, errd_doc, patch_run_in_thread
):
    """Q5 — écart ≤ 0.01€ accepté (arrondi comptable)."""
    monkeypatch.setattr(
        tf_service.tf_repo,
        "totals_by_titre_cote",
        lambda _: [
            {
                "cote": "ressources",
                "titre": "Titre 1",
                "montant_budget_initial_n1": Decimal("0"),
                "montant_realisations_n1": Decimal("0"),
                "montant_previsions_n": Decimal("0"),
                "montant_realisations_n": Decimal("100000.005"),
                "montant_nm1": Decimal("0"),
                "montant_n": Decimal("0"),
                "montant_np1": Decimal("0"),
                "montant_np2": Decimal("0"),
                "montant_np3": Decimal("0"),
                "montant_np4": Decimal("0"),
                "montant_np5": Decimal("0"),
                "montant_np6": Decimal("0"),
            },
            {
                "cote": "emplois",
                "titre": "Titre 1",
                "montant_budget_initial_n1": Decimal("0"),
                "montant_realisations_n1": Decimal("0"),
                "montant_previsions_n": Decimal("0"),
                "montant_realisations_n": Decimal("100000"),
                "montant_nm1": Decimal("0"),
                "montant_n": Decimal("0"),
                "montant_np1": Decimal("0"),
                "montant_np2": Decimal("0"),
                "montant_np3": Decimal("0"),
                "montant_np4": Decimal("0"),
                "montant_np5": Decimal("0"),
                "montant_np6": Decimal("0"),
            },
        ],
    )
    out = await tf_service.compute_totals(DOC_ID, COMPANY)
    assert out.valide_globalement is True


@pytest.mark.asyncio
async def test_compute_totals_ecart_above_tolerance(monkeypatch, errd_doc, patch_run_in_thread):
    monkeypatch.setattr(
        tf_service.tf_repo,
        "totals_by_titre_cote",
        lambda _: [
            {
                "cote": "ressources",
                "titre": None,
                "montant_budget_initial_n1": Decimal("0"),
                "montant_realisations_n1": Decimal("0"),
                "montant_previsions_n": Decimal("0"),
                "montant_realisations_n": Decimal("100000"),
                "montant_nm1": Decimal("0"),
                "montant_n": Decimal("0"),
                "montant_np1": Decimal("0"),
                "montant_np2": Decimal("0"),
                "montant_np3": Decimal("0"),
                "montant_np4": Decimal("0"),
                "montant_np5": Decimal("0"),
                "montant_np6": Decimal("0"),
            },
            {
                "cote": "emplois",
                "titre": None,
                "montant_budget_initial_n1": Decimal("0"),
                "montant_realisations_n1": Decimal("0"),
                "montant_previsions_n": Decimal("0"),
                "montant_realisations_n": Decimal("95000"),
                "montant_nm1": Decimal("0"),
                "montant_n": Decimal("0"),
                "montant_np1": Decimal("0"),
                "montant_np2": Decimal("0"),
                "montant_np3": Decimal("0"),
                "montant_np4": Decimal("0"),
                "montant_np5": Decimal("0"),
                "montant_np6": Decimal("0"),
            },
        ],
    )
    out = await tf_service.compute_totals(DOC_ID, COMPANY)
    assert out.valide_globalement is False
    # Une colonne en écart
    ecart_col = next(eq for eq in out.equilibre_by_column if not eq.valide)
    assert ecart_col.column == "montant_realisations_n"
    assert ecart_col.ecart == Decimal("5000")


@pytest.mark.asyncio
async def test_compute_totals_no_rows(monkeypatch, errd_doc, patch_run_in_thread):
    """Aucune ligne → ressources=None, emplois=None, valide_globalement=True
    (rien à valider, cabinet en cours)."""
    monkeypatch.setattr(tf_service.tf_repo, "totals_by_titre_cote", lambda _: [])
    out = await tf_service.compute_totals(DOC_ID, COMPANY)
    assert out.ressources is None
    assert out.emplois is None
    # 4 colonnes équilibrées (toutes à 0)
    assert all(eq.valide for eq in out.equilibre_by_column)
    assert out.valide_globalement is True


# ---------------------------------------------------------------------------
# Lignes calculées (Apport FR, Prélèvement FR) gérées comme items
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_compute_totals_with_apport_prelevement_fr(
    monkeypatch, errd_doc, patch_run_in_thread
):
    """Spec 25-deepdive §6 : équilibre = Total ressources + Prélèvement FR
    = Total emplois + Apport FR. Ces ajustements sont des **lignes** du TF
    (Q7 : compte_m22bis nullable pour ces lignes calculées)."""
    monkeypatch.setattr(
        tf_service.tf_repo,
        "totals_by_titre_cote",
        lambda _: [
            {
                "cote": "ressources",
                # 80000 CAF + 20000 Prélèvement FR = 100000
                "titre": None,
                "montant_budget_initial_n1": Decimal("0"),
                "montant_realisations_n1": Decimal("0"),
                "montant_previsions_n": Decimal("0"),
                "montant_realisations_n": Decimal("100000"),
                "montant_nm1": Decimal("0"),
                "montant_n": Decimal("0"),
                "montant_np1": Decimal("0"),
                "montant_np2": Decimal("0"),
                "montant_np3": Decimal("0"),
                "montant_np4": Decimal("0"),
                "montant_np5": Decimal("0"),
                "montant_np6": Decimal("0"),
            },
            {
                "cote": "emplois",
                # 100000 Acquisitions
                "titre": None,
                "montant_budget_initial_n1": Decimal("0"),
                "montant_realisations_n1": Decimal("0"),
                "montant_previsions_n": Decimal("0"),
                "montant_realisations_n": Decimal("100000"),
                "montant_nm1": Decimal("0"),
                "montant_n": Decimal("0"),
                "montant_np1": Decimal("0"),
                "montant_np2": Decimal("0"),
                "montant_np3": Decimal("0"),
                "montant_np4": Decimal("0"),
                "montant_np5": Decimal("0"),
                "montant_np6": Decimal("0"),
            },
        ],
    )
    out = await tf_service.compute_totals(DOC_ID, COMPANY)
    assert out.valide_globalement is True
