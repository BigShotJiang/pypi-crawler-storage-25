"""Tests §BD.4 — hook équilibre R.314-222 dans ``workflow_service.apply_transition``.

Le hook est appelé pour les transitions ``transmit`` :
1. Après les bloquants §Z C-001/2/3
2. Appelle equilibre_service.apply_equilibre_check_for_document
3. Bloque (ValidationError 422) si verdict == NON
4. Passe si verdict ∈ {OUI, NON_APPLICABLE}
5. Pose ``equilibre_atteint_o_n`` dans audit_payload
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.workflow import TransitionRequest
from piilot_pack_compta_esms.services import equilibre_service, workflow_service
from piilot_pack_compta_esms.services.errors import ValidationError

DOC_ID = uuid4()
COMPANY = uuid4()
USER_ID = uuid4()


def _snapshot_row(statut="brouillon"):
    """Row brouillon prêt à passer en transmis (EPRD)."""
    return {
        "id": DOC_ID,
        "company_id": COMPANY,
        "type_document": "eprd",
        "statut": statut,
        "transmis_at": None,
        "executoire_at": None,
        "approuve_par_ars_at": None,
        "approuve_par_cd_at": None,
        "approuve_par_ars_user_id": None,
        "approuve_par_cd_user_id": None,
        "rejete_at": None,
        "rejete_par_autorite": None,
        "motif_rejet": None,
        "affectation_definie_at": None,
    }


@pytest.fixture
def passthrough_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.workflow_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def transit_setup(monkeypatch):
    """Common setup : snapshot + apply_transition mock returning the new
    statut. Returns the captured audit_payload for assertion."""
    monkeypatch.setattr(
        workflow_service.workflow_repo,
        "load_snapshot",
        lambda _: _snapshot_row(),
    )

    captured: dict = {}

    def _apply(*args, **kwargs):
        captured["audit_payload"] = kwargs.get("audit_payload")
        captured["patch"] = kwargs.get("patch")
        return _snapshot_row(statut="transmis") | {
            "transmis_at": datetime.now(UTC),
            "transmis_par_user_id": kwargs.get("user_id"),
        }

    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _apply)
    monkeypatch.setattr(
        workflow_service.workflow_repo,
        "load_equilibre_context",
        lambda _: {
            "type_document": "eprd",
            "nature_juridique": "PRIVE_NON_LUCRATIF",
            "any_inclus_cpom": True,
        },
    )
    return captured


@pytest.mark.asyncio
async def test_transit_oui_passes_and_writes_audit(
    monkeypatch, transit_setup, passthrough_run_in_thread
):
    """Verdict OUI → transition passe. Audit contient le verdict."""

    async def _ok(*_, **__):
        return equilibre_service.EquilibreCheckResult(mode="STRICT", verdict="OUI")

    monkeypatch.setattr(equilibre_service, "apply_equilibre_check_for_document", _ok)
    out = await workflow_service.apply_transition(
        document_id=DOC_ID,
        payload=TransitionRequest(action="transmit"),
        company_id=COMPANY,
        user_id=USER_ID,
        role="admin",
    )
    assert out.statut_after == "transmis"
    assert transit_setup["audit_payload"]["equilibre_atteint_o_n"] == "OUI"


@pytest.mark.asyncio
async def test_transit_non_blocks_with_422(monkeypatch, transit_setup, passthrough_run_in_thread):
    """Verdict NON → ValidationError code transition_blocked_by_equilibre_check."""

    async def _non(*_, **__):
        return equilibre_service.EquilibreCheckResult(mode="STRICT", verdict="NON")

    monkeypatch.setattr(equilibre_service, "apply_equilibre_check_for_document", _non)
    with pytest.raises(ValidationError) as exc:
        await workflow_service.apply_transition(
            document_id=DOC_ID,
            payload=TransitionRequest(action="transmit"),
            company_id=COMPANY,
            user_id=USER_ID,
            role="admin",
        )
    assert exc.value.code == "transition_blocked_by_equilibre_check"


@pytest.mark.asyncio
async def test_transit_non_applicable_passes(monkeypatch, transit_setup, passthrough_run_in_thread):
    """Verdict NON_APPLICABLE (PRIVE_COMMERCIAL hors CPOM) → transition passe."""

    async def _na(*_, **__):
        return equilibre_service.EquilibreCheckResult(
            mode="NON_APPLICABLE", verdict="NON_APPLICABLE"
        )

    monkeypatch.setattr(equilibre_service, "apply_equilibre_check_for_document", _na)
    out = await workflow_service.apply_transition(
        document_id=DOC_ID,
        payload=TransitionRequest(action="transmit"),
        company_id=COMPANY,
        user_id=USER_ID,
        role="admin",
    )
    assert out.statut_after == "transmis"
    assert transit_setup["audit_payload"]["equilibre_atteint_o_n"] == "NON_APPLICABLE"


@pytest.mark.asyncio
async def test_transit_non_applicable_does_not_raise_even_if_unbalanced(
    monkeypatch, transit_setup, passthrough_run_in_thread
):
    """Defensive : un PRIVE_COMMERCIAL hors CPOM passe la transition
    même si les recettes ≠ dépenses (R.314-222 ne s'applique pas)."""

    async def _na(*_, **__):
        return equilibre_service.EquilibreCheckResult(
            mode="NON_APPLICABLE", verdict="NON_APPLICABLE"
        )

    monkeypatch.setattr(equilibre_service, "apply_equilibre_check_for_document", _na)
    out = await workflow_service.apply_transition(
        document_id=DOC_ID,
        payload=TransitionRequest(action="transmit"),
        company_id=COMPANY,
        user_id=USER_ID,
        role="admin",
    )
    assert out.statut_after == "transmis"
