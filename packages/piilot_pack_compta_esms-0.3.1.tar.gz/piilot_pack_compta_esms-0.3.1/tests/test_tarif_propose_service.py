"""Service tests for EPRD tarifs proposés — §BB v0.3.

DB-free — repo monkeypatched. Couvre :
* CRUD happy / 404 / 403 / 422 / 409
* Document type gate (EPRD/EPCP/DM/RIA accepted, ERRD refusé)
* Bulk-upsert OG-cohérence + dedup batch
* Workflow lock VALIDE_TRIPARTITE → autre statut refusé
* build_validation_report (sections + has_rejected + all_tripartite)
"""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.tarif_propose import (
    TarifProposeBulkItem,
    TarifProposeCreate,
    TarifProposeUpdate,
)
from piilot_pack_compta_esms.services import tarifs_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
    ValidationError,
)

COMPANY = uuid4()
OTHER_COMPANY = uuid4()
DOC_ID = uuid4()
ETS_ID = uuid4()
TARIF_ID = uuid4()


@pytest.fixture
def passthrough_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.tarifs_service.run_in_thread",
        _passthrough,
    )


def _row(**overrides):
    base = {
        "id": TARIF_ID,
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "etablissement_id": ETS_ID,
        "section": "HEBERGEMENT",
        "libelle": None,
        "montant_propose": Decimal("75.50"),
        "montant_notifie": None,
        "ecart": None,
        "motif": None,
        "statut": "PROPOSE",
        "date_validation": None,
        "valide_par": None,
        "motif_rejet": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


def _setup_doc_eprd(monkeypatch):
    """Convenience helper — wire the document existence + type=eprd
    guards to passthrough."""
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "document_exists_for_company",
        lambda doc, c: True,
    )
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "get_document_type",
        lambda doc: "eprd",
    )


def _setup_ets(monkeypatch, exists=True):
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "ets_belongs_to_company",
        lambda ets, c: exists,
    )


# --------------------------------------------------------------------
# Document type gate
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_404_when_document_missing(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "document_exists_for_company",
        lambda doc, c: False,
    )
    with pytest.raises(NotFoundError):
        await tarifs_service.list_by_document(COMPANY, DOC_ID)


@pytest.mark.asyncio
async def test_list_422_when_document_type_is_errd(monkeypatch, passthrough_run_in_thread):
    """ERRD est rétrospectif → pas de tarifs proposés."""
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "document_exists_for_company",
        lambda doc, c: True,
    )
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "get_document_type",
        lambda doc: "errd",
    )
    with pytest.raises(ValidationError) as exc:
        await tarifs_service.list_by_document(COMPANY, DOC_ID)
    assert exc.value.code == "document_type_no_tarifs"


@pytest.mark.asyncio
@pytest.mark.parametrize("doc_type", ["eprd", "epcp", "dm", "ria"])
async def test_list_accepts_4_provisional_doc_types(
    monkeypatch, passthrough_run_in_thread, doc_type
):
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "document_exists_for_company",
        lambda doc, c: True,
    )
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "get_document_type",
        lambda doc: doc_type,
    )
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "list_by_document",
        lambda doc: [_row()],
    )
    out = await tarifs_service.list_by_document(COMPANY, DOC_ID)
    assert len(out) == 1


# --------------------------------------------------------------------
# Create
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_happy_path(monkeypatch, passthrough_run_in_thread):
    _setup_doc_eprd(monkeypatch)
    _setup_ets(monkeypatch)
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "get_by_natural_key",
        lambda doc, ets, sec: None,
    )
    captured = {}

    def _create(c, doc, payload):
        captured["payload"] = payload
        return _row(**payload)

    monkeypatch.setattr(tarifs_service.tarif_propose_repo, "create", _create)
    payload = TarifProposeCreate(
        etablissement_id=ETS_ID,
        section="HEBERGEMENT",
        montant_propose=Decimal("75.50"),
    )
    out = await tarifs_service.create_tarif(COMPANY, DOC_ID, payload)
    assert out.section == "HEBERGEMENT"
    assert captured["payload"]["section"] == "HEBERGEMENT"


@pytest.mark.asyncio
async def test_create_404_when_ets_not_in_company(monkeypatch, passthrough_run_in_thread):
    _setup_doc_eprd(monkeypatch)
    _setup_ets(monkeypatch, exists=False)
    payload = TarifProposeCreate(
        etablissement_id=ETS_ID,
        section="HEBERGEMENT",
        montant_propose=Decimal("1"),
    )
    with pytest.raises(NotFoundError) as exc:
        await tarifs_service.create_tarif(COMPANY, DOC_ID, payload)
    assert exc.value.code == "ets_not_found"


@pytest.mark.asyncio
async def test_create_409_on_natural_key_conflict(monkeypatch, passthrough_run_in_thread):
    _setup_doc_eprd(monkeypatch)
    _setup_ets(monkeypatch)
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "get_by_natural_key",
        lambda doc, ets, sec: _row(),
    )
    payload = TarifProposeCreate(
        etablissement_id=ETS_ID,
        section="HEBERGEMENT",
        montant_propose=Decimal("1"),
    )
    with pytest.raises(ConflictError) as exc:
        await tarifs_service.create_tarif(COMPANY, DOC_ID, payload)
    assert exc.value.code == "tarif_natural_key_taken"


# --------------------------------------------------------------------
# Get / Update / Delete
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_404_when_missing(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(tarifs_service.tarif_propose_repo, "get_by_id", lambda t: None)
    with pytest.raises(NotFoundError):
        await tarifs_service.get_tarif(COMPANY, TARIF_ID)


@pytest.mark.asyncio
async def test_get_403_cross_company(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "get_by_id",
        lambda t: _row(company_id=OTHER_COMPANY),
    )
    with pytest.raises(CrossCompanyError):
        await tarifs_service.get_tarif(COMPANY, TARIF_ID)


@pytest.mark.asyncio
async def test_get_returns_read(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(tarifs_service.tarif_propose_repo, "get_by_id", lambda t: _row())
    out = await tarifs_service.get_tarif(COMPANY, TARIF_ID)
    assert out.id == TARIF_ID


@pytest.mark.asyncio
async def test_update_montant_notifie_happy(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(tarifs_service.tarif_propose_repo, "get_by_id", lambda t: _row())

    def _update(t, payload):
        return _row(**payload)

    monkeypatch.setattr(tarifs_service.tarif_propose_repo, "update", _update)
    out = await tarifs_service.update_tarif(
        COMPANY,
        TARIF_ID,
        TarifProposeUpdate(montant_notifie=Decimal("80.00")),
    )
    assert out.montant_notifie == Decimal("80.00")


@pytest.mark.asyncio
async def test_update_statut_to_tripartite_happy(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "get_by_id",
        lambda t: _row(statut="VALIDE_ARS"),
    )

    def _update(t, payload):
        merged = {**payload, "statut": "VALIDE_TRIPARTITE"}
        return _row(**merged)

    monkeypatch.setattr(tarifs_service.tarif_propose_repo, "update", _update)
    out = await tarifs_service.update_tarif(
        COMPANY,
        TARIF_ID,
        TarifProposeUpdate(statut="VALIDE_TRIPARTITE"),
    )
    assert out.statut == "VALIDE_TRIPARTITE"


@pytest.mark.asyncio
async def test_update_locked_after_tripartite(monkeypatch, passthrough_run_in_thread):
    """Refuse de revenir en arrière depuis VALIDE_TRIPARTITE."""
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "get_by_id",
        lambda t: _row(statut="VALIDE_TRIPARTITE"),
    )
    with pytest.raises(ValidationError) as exc:
        await tarifs_service.update_tarif(COMPANY, TARIF_ID, TarifProposeUpdate(statut="PROPOSE"))
    assert exc.value.code == "tarif_statut_locked"


@pytest.mark.asyncio
async def test_update_tripartite_can_self_repeat(monkeypatch, passthrough_run_in_thread):
    """L'idempotent re-write VALIDE_TRIPARTITE → VALIDE_TRIPARTITE passe."""
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "get_by_id",
        lambda t: _row(statut="VALIDE_TRIPARTITE"),
    )

    def _update(t, payload):
        return _row(statut="VALIDE_TRIPARTITE")

    monkeypatch.setattr(tarifs_service.tarif_propose_repo, "update", _update)
    out = await tarifs_service.update_tarif(
        COMPANY,
        TARIF_ID,
        TarifProposeUpdate(statut="VALIDE_TRIPARTITE"),
    )
    assert out.statut == "VALIDE_TRIPARTITE"


@pytest.mark.asyncio
async def test_delete_happy(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(tarifs_service.tarif_propose_repo, "get_by_id", lambda t: _row())
    monkeypatch.setattr(tarifs_service.tarif_propose_repo, "delete", lambda t: True)
    await tarifs_service.delete_tarif(COMPANY, TARIF_ID)


@pytest.mark.asyncio
async def test_delete_404(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(tarifs_service.tarif_propose_repo, "get_by_id", lambda t: None)
    with pytest.raises(NotFoundError):
        await tarifs_service.delete_tarif(COMPANY, TARIF_ID)


# --------------------------------------------------------------------
# Bulk-upsert
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_upsert_empty_returns_empty(monkeypatch, passthrough_run_in_thread):
    _setup_doc_eprd(monkeypatch)
    out = await tarifs_service.bulk_upsert(COMPANY, DOC_ID, [])
    assert out == []


@pytest.mark.asyncio
async def test_bulk_upsert_happy(monkeypatch, passthrough_run_in_thread):
    _setup_doc_eprd(monkeypatch)
    _setup_ets(monkeypatch)

    def _upsert(c, doc, ets, sec, payload):
        return _row(
            etablissement_id=ets,
            section=sec,
            montant_propose=payload["montant_propose"],
        )

    monkeypatch.setattr(tarifs_service.tarif_propose_repo, "upsert", _upsert)
    items = [
        TarifProposeBulkItem(
            etablissement_id=ETS_ID,
            section="HEBERGEMENT",
            montant_propose=Decimal("75"),
        ),
        TarifProposeBulkItem(
            etablissement_id=ETS_ID,
            section="DEPENDANCE",
            montant_propose=Decimal("25"),
        ),
    ]
    out = await tarifs_service.bulk_upsert(COMPANY, DOC_ID, items)
    assert len(out) == 2
    assert out[0].section == "HEBERGEMENT"
    assert out[1].section == "DEPENDANCE"


@pytest.mark.asyncio
async def test_bulk_upsert_rejects_cross_tenant_ets(monkeypatch, passthrough_run_in_thread):
    _setup_doc_eprd(monkeypatch)
    _setup_ets(monkeypatch, exists=False)
    items = [
        TarifProposeBulkItem(
            etablissement_id=ETS_ID,
            section="SOINS",
            montant_propose=Decimal("1"),
        )
    ]
    with pytest.raises(NotFoundError) as exc:
        await tarifs_service.bulk_upsert(COMPANY, DOC_ID, items)
    assert exc.value.code == "ets_not_found"


@pytest.mark.asyncio
async def test_bulk_upsert_rejects_duplicate_key_in_batch(monkeypatch, passthrough_run_in_thread):
    _setup_doc_eprd(monkeypatch)
    _setup_ets(monkeypatch)
    items = [
        TarifProposeBulkItem(
            etablissement_id=ETS_ID,
            section="SOINS",
            montant_propose=Decimal("10"),
        ),
        TarifProposeBulkItem(
            etablissement_id=ETS_ID,
            section="SOINS",
            montant_propose=Decimal("20"),  # doublon (ets, section)
        ),
    ]
    with pytest.raises(ValidationError) as exc:
        await tarifs_service.bulk_upsert(COMPANY, DOC_ID, items)
    assert exc.value.code == "bulk_duplicate_key"


# --------------------------------------------------------------------
# Validation report
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_report_empty_document(monkeypatch, passthrough_run_in_thread):
    _setup_doc_eprd(monkeypatch)
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "aggregate_by_section",
        lambda doc: [],
    )
    out = await tarifs_service.build_validation_report(COMPANY, DOC_ID)
    assert out.total_rows == 0
    # Pas de sections → all_sections_tripartite False (par convention).
    assert out.all_sections_tripartite is False
    assert out.has_rejected_rows is False


@pytest.mark.asyncio
async def test_report_all_sections_tripartite(monkeypatch, passthrough_run_in_thread):
    _setup_doc_eprd(monkeypatch)
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "aggregate_by_section",
        lambda doc: [
            {
                "section": "HEBERGEMENT",
                "rows_count": 2,
                "total_propose": Decimal("100"),
                "total_notifie": Decimal("100"),
                "all_validated_tripartite": True,
                "has_rejected": False,
            },
            {
                "section": "SOINS",
                "rows_count": 1,
                "total_propose": Decimal("50"),
                "total_notifie": Decimal("50"),
                "all_validated_tripartite": True,
                "has_rejected": False,
            },
        ],
    )
    out = await tarifs_service.build_validation_report(COMPANY, DOC_ID)
    assert out.total_rows == 3
    assert out.all_sections_tripartite is True
    assert out.has_rejected_rows is False
    assert len(out.sections) == 2
    assert out.sections[0].ecart == Decimal("0")


@pytest.mark.asyncio
async def test_report_with_rejected_row_blocks_tripartite(monkeypatch, passthrough_run_in_thread):
    """Une row REJETE en HEBERGEMENT bloque all_sections_tripartite
    même si SOINS est OK."""
    _setup_doc_eprd(monkeypatch)
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "aggregate_by_section",
        lambda doc: [
            {
                "section": "HEBERGEMENT",
                "rows_count": 1,
                "total_propose": Decimal("100"),
                "total_notifie": None,
                "all_validated_tripartite": False,
                "has_rejected": True,
            },
            {
                "section": "SOINS",
                "rows_count": 1,
                "total_propose": Decimal("50"),
                "total_notifie": Decimal("50"),
                "all_validated_tripartite": True,
                "has_rejected": False,
            },
        ],
    )
    out = await tarifs_service.build_validation_report(COMPANY, DOC_ID)
    assert out.all_sections_tripartite is False
    assert out.has_rejected_rows is True


@pytest.mark.asyncio
async def test_report_partial_notifications(monkeypatch, passthrough_run_in_thread):
    """Une section avec une row non notifiée → total_notifie = None
    et ecart = None."""
    _setup_doc_eprd(monkeypatch)
    monkeypatch.setattr(
        tarifs_service.tarif_propose_repo,
        "aggregate_by_section",
        lambda doc: [
            {
                "section": "HEBERGEMENT",
                "rows_count": 2,
                "total_propose": Decimal("100"),
                "total_notifie": None,
                "all_validated_tripartite": False,
                "has_rejected": False,
            }
        ],
    )
    out = await tarifs_service.build_validation_report(COMPANY, DOC_ID)
    assert out.sections[0].total_notifie is None
    assert out.sections[0].ecart is None
    assert out.all_sections_tripartite is False
