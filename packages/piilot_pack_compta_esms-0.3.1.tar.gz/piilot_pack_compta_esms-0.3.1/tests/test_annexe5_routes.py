"""Route tests for Annexe 5 + forfait paramètres (L2 §13, 4 endpoints)."""

from __future__ import annotations

from datetime import UTC, date, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.annexe5 import (
    Annexe5LigneRead,
    Annexe5Response,
    ForfaitParametresListResponse,
    ForfaitParametresRead,
)
from piilot_pack_compta_esms.routes import annexe5 as annexe5_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import annexe5_service, forfait_service
from piilot_pack_compta_esms.services.errors import NotFoundError, ValidationError

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
ETS_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)


def _ligne_read(**overrides) -> Annexe5LigneRead:
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "etablissement_id": ETS_ID,
        "variante": "5A_ehpad",
        "compte_m22bis": "611",
        "compte_label": "Sous-traitance",
        "nature": "charge",
        "montant_hebergement_n1": Decimal("1000"),
        "montant_hebergement_n": Decimal("1050"),
        "montant_dependance_n1": None,
        "montant_dependance_n": None,
        "montant_soins_n1": None,
        "montant_soins_n": None,
        "montant_sea_n1": None,
        "montant_sea_n": None,
        "montant_budget_global_n1": None,
        "montant_budget_global_n": None,
        "montant_forfait_soins_n1": None,
        "montant_forfait_soins_n": None,
        "montant_soins_sad_n1": None,
        "montant_soins_sad_n": None,
        "montant_aide_acc_n1": None,
        "montant_aide_acc_n": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return Annexe5LigneRead.model_validate(base)


def _forfait_read(**overrides) -> ForfaitParametresRead:
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "etablissement_id": ETS_ID,
        "date_evaluation": date(2025, 6, 30),
        "nombre_points_gir": 12500,
        "nombre_personnes_girees": 80,
        "valeur_point_gir": Decimal("7.2300"),
        "gmp": Decimal("720.5000"),
        "pmp": Decimal("180.0000"),
        "gmps": Decimal("900.5000"),
        "created_at": datetime.now(UTC),
    }
    base.update(overrides)
    return ForfaitParametresRead.model_validate(base)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(annexe5_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# §13.1 GET /annexe5
# ---------------------------------------------------------------------------


def test_get_annexe5_200(client, monkeypatch):
    async def _fake(doc, company, ets_id=None, variante=None):
        return Annexe5Response(ets_id_filtre=None, variante_filtre=None, items=[_ligne_read()])

    monkeypatch.setattr(annexe5_service, "list_annexe5", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/annexe5")
    assert r.status_code == 200
    assert len(r.json()["items"]) == 1


def test_get_annexe5_with_filters_200(client, monkeypatch):
    captured = {}

    async def _fake(doc, company, ets_id=None, variante=None):
        captured["ets_id"] = ets_id
        captured["variante"] = variante
        return Annexe5Response(ets_id_filtre=ets_id, variante_filtre=variante, items=[])

    monkeypatch.setattr(annexe5_service, "list_annexe5", _fake)
    r = client.get(
        f"/plugins/compta_esms/documents/{DOC_ID}/annexe5",
        params={"ets_id": str(ETS_ID), "variante": "5A_ehpad"},
    )
    assert r.status_code == 200
    assert captured["ets_id"] == ETS_ID
    assert captured["variante"] == "5A_ehpad"


def test_get_annexe5_invalid_variante_422(client):
    r = client.get(
        f"/plugins/compta_esms/documents/{DOC_ID}/annexe5",
        params={"variante": "5Z_invalid"},
    )
    assert r.status_code == 422


def test_get_annexe5_404(client, monkeypatch):
    async def _fake(doc, company, ets_id=None, variante=None):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(annexe5_service, "list_annexe5", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/annexe5")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §13.2 POST :bulk-upsert
# ---------------------------------------------------------------------------


def test_bulk_upsert_200(client, monkeypatch):
    async def _fake(doc, company, payload):
        return Annexe5Response(
            ets_id_filtre=payload.ets_id,
            variante_filtre=payload.variante,
            items=[_ligne_read()],
        )

    monkeypatch.setattr(annexe5_service, "bulk_upsert_annexe5", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/annexe5:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "variante": "5A_ehpad",
            "items": [
                {
                    "compte_m22bis": "611",
                    "nature": "charge",
                    "montant_hebergement_n": "1000",
                }
            ],
        },
    )
    assert r.status_code == 200


def test_bulk_upsert_missing_ets_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/annexe5:bulk-upsert",
        json={"variante": "5A_ehpad", "items": []},
    )
    assert r.status_code == 422


def test_bulk_upsert_invalid_variante_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/annexe5:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "variante": "5B_intermediaire",
            "items": [],
        },
    )
    assert r.status_code == 422


def test_bulk_upsert_invalid_nature_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/annexe5:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "variante": "5A_ehpad",
            "items": [
                {"compte_m22bis": "611", "nature": "bogus"},
            ],
        },
    )
    assert r.status_code == 422


def test_bulk_upsert_422_annexe5_not_applicable(client, monkeypatch):
    """Q6 — typologie hors EHPAD/FAM/SAD → 422."""

    async def _fake(doc, company, payload):
        raise ValidationError("esat not eligible", code="annexe5_not_applicable")

    monkeypatch.setattr(annexe5_service, "bulk_upsert_annexe5", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/annexe5:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "variante": "5A_ehpad",
            "items": [],
        },
    )
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "annexe5_not_applicable"


def test_bulk_upsert_404(client, monkeypatch):
    async def _fake(doc, company, payload):
        raise NotFoundError("nope", code="etablissement_not_found")

    monkeypatch.setattr(annexe5_service, "bulk_upsert_annexe5", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/annexe5:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "variante": "5A_ehpad",
            "items": [],
        },
    )
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §13.3 GET /forfait-parametres
# ---------------------------------------------------------------------------


def test_get_forfait_parametres_200(client, monkeypatch):
    async def _fake(doc, company):
        return ForfaitParametresListResponse(items=[_forfait_read()])

    monkeypatch.setattr(forfait_service, "list_forfait_parametres", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/forfait-parametres")
    assert r.status_code == 200
    body = r.json()
    assert len(body["items"]) == 1
    assert body["items"][0]["gmp"] == "720.5000"


def test_get_forfait_parametres_empty_200(client, monkeypatch):
    async def _fake(doc, company):
        return ForfaitParametresListResponse(items=[])

    monkeypatch.setattr(forfait_service, "list_forfait_parametres", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/forfait-parametres")
    assert r.status_code == 200
    assert r.json()["items"] == []


def test_get_forfait_parametres_404(client, monkeypatch):
    async def _fake(doc, company):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(forfait_service, "list_forfait_parametres", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/forfait-parametres")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §13.4 PUT /forfait-parametres (builder)
# ---------------------------------------------------------------------------


def test_put_forfait_parametres_200(client, monkeypatch):
    async def _fake(doc, company, payload):
        return _forfait_read()

    monkeypatch.setattr(forfait_service, "upsert_forfait_parametres", _fake)
    r = client.put(
        f"/plugins/compta_esms/documents/{DOC_ID}/forfait-parametres",
        json={
            "ets_id": str(ETS_ID),
            "date_evaluation": "2025-06-30",
            "nombre_points_gir": 12500,
            "nombre_personnes_girees": 80,
            "valeur_point_gir": "7.23",
            "gmp": "720.5",
            "pmp": "180",
            "gmps": "900.5",
        },
    )
    assert r.status_code == 200


def test_put_forfait_parametres_403_user_role(client):
    """L2 §13.4 = builder. Le user-role doit être refusé."""

    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.put(
        f"/plugins/compta_esms/documents/{DOC_ID}/forfait-parametres",
        json={"ets_id": str(ETS_ID)},
    )
    assert r.status_code == 403


def test_put_forfait_parametres_missing_ets_422(client):
    r = client.put(
        f"/plugins/compta_esms/documents/{DOC_ID}/forfait-parametres",
        json={"gmp": "720"},
    )
    assert r.status_code == 422


def test_put_forfait_parametres_negative_gmp_422(client):
    """ge=0 constraint."""
    r = client.put(
        f"/plugins/compta_esms/documents/{DOC_ID}/forfait-parametres",
        json={"ets_id": str(ETS_ID), "gmp": "-100"},
    )
    assert r.status_code == 422


def test_put_forfait_parametres_404(client, monkeypatch):
    async def _fake(doc, company, payload):
        raise NotFoundError("nope", code="etablissement_not_found")

    monkeypatch.setattr(forfait_service, "upsert_forfait_parametres", _fake)
    r = client.put(
        f"/plugins/compta_esms/documents/{DOC_ID}/forfait-parametres",
        json={"ets_id": str(ETS_ID)},
    )
    assert r.status_code == 404
