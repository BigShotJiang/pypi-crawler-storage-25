"""Route tests for Établissement endpoints."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_admin, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import etablissement as ets_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import etablissement_service
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

COMPANY = uuid4()
USER = uuid4()
OG_ID = uuid4()
ETS_ID = uuid4()
ADMIN_AUTH = (USER, "admin", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


def _make_ets_dict(**overrides):
    base = {
        "id": ETS_ID,
        "company_id": COMPANY,
        "og_id": OG_ID,
        "finess_ets": "555555555",
        "raison_sociale": "ETS Test",
        "typologie": "EHPAD",
        "categorie": None,
        "adresse": None,
        "date_autorisation": None,
        "capacite_autorisee": 80,
        "capacite_installee": 75,
        "capacite_financee": 75,
        "amplitude_ouverture": 365,
        "convention_collective": None,
        "inclus_cpom": False,
        "soumis_equilibre": False,
        "tarification_ternaire": True,
        "forfait_global_unique": False,
        "cofinancement": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(ets_routes.router_under_og, prefix="/plugins/compta_esms")
    app.include_router(ets_routes.router_flat, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_admin] = lambda: ADMIN_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


def test_list_etablissements(client, monkeypatch):
    async def _fake(og_id, typologie):
        from piilot_pack_compta_esms.models.etablissement import EtablissementRead

        return [EtablissementRead.model_validate(_make_ets_dict())]

    monkeypatch.setattr(etablissement_service, "list_etablissements", _fake)
    r = client.get(f"/plugins/compta_esms/orgs/{OG_ID}/etablissements")
    assert r.status_code == 200
    assert r.json()[0]["typologie"] == "EHPAD"


def test_list_etablissements_with_typologie_filter(client, monkeypatch):
    captured = {}

    async def _fake(og_id, typologie):
        captured["typologie"] = typologie
        return []

    monkeypatch.setattr(etablissement_service, "list_etablissements", _fake)
    r = client.get(f"/plugins/compta_esms/orgs/{OG_ID}/etablissements?typologie=MAS")
    assert r.status_code == 200
    assert captured["typologie"] == "MAS"


def test_create_ets_201(client, monkeypatch):
    async def _fake(company_id, og_id, payload):
        from piilot_pack_compta_esms.models.etablissement import EtablissementRead

        return EtablissementRead.model_validate(_make_ets_dict(finess_ets=payload.finess_ets))

    monkeypatch.setattr(etablissement_service, "create_etablissement", _fake)
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/etablissements",
        json={
            "og_id": str(OG_ID),
            "finess_ets": "999999999",
            "raison_sociale": "New ETS",
            "typologie": "MAS",
        },
    )
    assert r.status_code == 201, r.text
    assert r.json()["finess_ets"] == "999999999"


def test_create_ets_409_finess_taken(client, monkeypatch):
    async def _fake(company_id, og_id, payload):
        raise ConflictError("dup", code="ets_finess_taken")

    monkeypatch.setattr(etablissement_service, "create_etablissement", _fake)
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/etablissements",
        json={
            "og_id": str(OG_ID),
            "finess_ets": "555555555",
            "raison_sociale": "Dup",
            "typologie": "EHPAD",
        },
    )
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "ets_finess_taken"


def test_create_ets_409_unknown_typologie(client, monkeypatch):
    """Unknown typologie code → 409 ``ets_typologie_unknown`` from the
    service (was 422 with the hardcoded Literal — now validated against
    the core KB com.piilot.core.typologies-essms at the service layer)."""
    from piilot_pack_compta_esms.services.errors import ConflictError

    async def _fake(company_id, og_id, payload):
        raise ConflictError("nope", code="ets_typologie_unknown")

    monkeypatch.setattr(etablissement_service, "create_etablissement", _fake)
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/etablissements",
        json={
            "og_id": str(OG_ID),
            "finess_ets": "999999999",
            "raison_sociale": "X",
            "typologie": "UNKNOWN_TYPE",
        },
    )
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "ets_typologie_unknown"


def test_get_ets_404(client, monkeypatch):
    async def _fake(ets_id):
        raise NotFoundError("nope", code="ets_not_found")

    monkeypatch.setattr(etablissement_service, "get_etablissement", _fake)
    r = client.get(f"/plugins/compta_esms/etablissements/{ETS_ID}")
    assert r.status_code == 404


def test_patch_ets_200(client, monkeypatch):
    async def _fake(company_id, ets_id, payload):
        from piilot_pack_compta_esms.models.etablissement import EtablissementRead

        return EtablissementRead.model_validate(_make_ets_dict(raison_sociale="Renamed"))

    monkeypatch.setattr(etablissement_service, "update_etablissement", _fake)
    r = client.patch(
        f"/plugins/compta_esms/etablissements/{ETS_ID}",
        json={"raison_sociale": "Renamed"},
    )
    assert r.status_code == 200


def test_patch_ets_cannot_change_og_id(client):
    """``og_id`` is not in ``EtablissementUpdate`` → ``extra='forbid'`` → 422."""
    r = client.patch(
        f"/plugins/compta_esms/etablissements/{ETS_ID}",
        json={"og_id": str(uuid4())},
    )
    assert r.status_code == 422


def test_delete_ets_204(client, monkeypatch):
    async def _fake(company_id, ets_id):
        return None

    monkeypatch.setattr(etablissement_service, "delete_etablissement", _fake)
    r = client.delete(f"/plugins/compta_esms/etablissements/{ETS_ID}")
    assert r.status_code == 204


def test_delete_ets_409_has_crs(client, monkeypatch):
    async def _fake(company_id, ets_id):
        raise ConflictError("nope", code="ets_has_crs")

    monkeypatch.setattr(etablissement_service, "delete_etablissement", _fake)
    r = client.delete(f"/plugins/compta_esms/etablissements/{ETS_ID}")
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "ets_has_crs"
