"""Tests §X — proxy endpoint /references/m21 (et /m22bis symétrique).

Couvre :

* GET /references/m21 → 200, filtre type='M21' transmis à reference_lookup
* GET /references/m22bis → 200, filtre type='M22Bis' transmis
* Param ``version`` propagé dans le filter
* Param ``class_num`` propagé dans le filter
"""

from __future__ import annotations

from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import _limiter as limiter_module
from piilot_pack_compta_esms.routes import reference as reference_routes
from piilot_pack_compta_esms.services import reference_lookup

USER = uuid4()
COMPANY = uuid4()
USER_AUTH = (USER, "user", COMPANY)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter_module.limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(reference_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    return app


def test_get_m21_routes_filter_type_m21(app, monkeypatch):
    """GET /references/m21 → service appelé avec filters={'type': 'M21'}."""
    captured: dict = {}

    async def _fake(slug, *, filters=None, limit=None):
        captured["slug"] = slug
        captured["filters"] = filters
        captured["limit"] = limit
        return [{"account_number": "601", "account_label": "Achats stockés", "type": "M21"}]

    monkeypatch.setattr(reference_lookup, "list_filtered_rows", _fake)

    client = TestClient(app)
    r = client.get("/plugins/compta_esms/references/m21")
    assert r.status_code == 200
    assert captured["slug"] == reference_lookup.PLAN_COMPTABLE_ESMS_SLUG
    assert captured["filters"]["type"] == "M21"
    body = r.json()
    assert len(body) == 1
    assert body[0]["type"] == "M21"


def test_get_m22bis_routes_filter_type_m22bis(app, monkeypatch):
    """GET /references/m22bis → service appelé avec filters={'type': 'M22Bis'}."""
    captured: dict = {}

    async def _fake(slug, *, filters=None, limit=None):
        captured["filters"] = filters
        return []

    monkeypatch.setattr(reference_lookup, "list_filtered_rows", _fake)

    client = TestClient(app)
    r = client.get("/plugins/compta_esms/references/m22bis")
    assert r.status_code == 200
    assert captured["filters"]["type"] == "M22Bis"


def test_get_m21_with_version_and_class_num(app, monkeypatch):
    """Params ``version`` + ``class_num`` propagés au filter."""
    captured: dict = {}

    async def _fake(slug, *, filters=None, limit=None):
        captured["filters"] = filters
        return []

    monkeypatch.setattr(reference_lookup, "list_filtered_rows", _fake)

    client = TestClient(app)
    r = client.get("/plugins/compta_esms/references/m21?version=2024-2025&class_num=6")
    assert r.status_code == 200
    assert captured["filters"]["type"] == "M21"
    assert captured["filters"]["version"] == "2024-2025"
    assert captured["filters"]["class_num"] == "6"
