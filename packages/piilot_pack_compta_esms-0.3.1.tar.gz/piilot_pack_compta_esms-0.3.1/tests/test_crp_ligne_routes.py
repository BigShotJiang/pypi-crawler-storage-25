"""Route tests for CRP lignes endpoints (L2 §6 — 7 endpoints)."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.crp_ligne import (
    CrpEcart,
    CrpLigneRead,
    CrpTotalsColumnPair,
    CrpTotalsGroupe,
    CrpTotalsResponse,
    PrefillFeatureResult,
    PrefillFromBindingResponse,
)
from piilot_pack_compta_esms.routes import crp_ligne as crp_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import (
    crp_ligne_service,
    crp_prefill_service,
)
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)

COMPANY = uuid4()
USER = uuid4()
CR_ID = uuid4()
LIGNE_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)


def _ligne_dict(**overrides):
    base = {
        "id": LIGNE_ID,
        "company_id": COMPANY,
        "cr_id": CR_ID,
        "groupe": "G1",
        "nature": "charge",
        "compte_m22bis": "6064",
        "compte_label": "Fournitures",
        "montant_budget_initial": None,
        "montant_virements_credits": None,
        "montant_decisions_modif": None,
        "montant_previsions_totales": None,
        "montant_realise": None,
        "montant_hebergement": None,
        "montant_dependance": None,
        "montant_soins": None,
        "montant_soins_autonomie": None,
        "binding_id": None,
        "saisie_manuelle": True,
        "override_balance": False,
        "override_reason": None,
        "override_at": None,
        "notes": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return CrpLigneRead.model_validate(base)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(crp_routes.router_under_cr, prefix="/plugins/compta_esms")
    app.include_router(crp_routes.router_flat, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# §6.1 GET /crs/{cr_id}/lignes
# ---------------------------------------------------------------------------


def test_list_lignes_200(client, monkeypatch):
    captured: dict = {}

    async def _fake(cr_id, company_id, *, groupe=None, nature=None):
        captured["groupe"] = groupe
        captured["nature"] = nature
        return [_ligne_dict(), _ligne_dict(compte_m22bis="60611")]

    monkeypatch.setattr(crp_ligne_service, "list_lignes", _fake)
    r = client.get(f"/plugins/compta_esms/crs/{CR_ID}/lignes?groupe=G1&nature=charge")
    assert r.status_code == 200
    assert captured == {"groupe": "G1", "nature": "charge"}
    assert [li["compte_m22bis"] for li in r.json()] == ["6064", "60611"]


def test_list_lignes_invalid_groupe_422(client):
    r = client.get(f"/plugins/compta_esms/crs/{CR_ID}/lignes?groupe=G4")
    assert r.status_code == 422


# ---------------------------------------------------------------------------
# §6.2 POST /crs/{cr_id}/lignes
# ---------------------------------------------------------------------------


def test_create_ligne_201(client, monkeypatch):
    async def _fake(cr_id, company_id, payload):
        return _ligne_dict(compte_m22bis=payload.compte_m22bis)

    monkeypatch.setattr(crp_ligne_service, "create_ligne", _fake)
    r = client.post(
        f"/plugins/compta_esms/crs/{CR_ID}/lignes",
        json={"groupe": "G1", "nature": "charge", "compte_m22bis": "6064"},
    )
    assert r.status_code == 201
    assert r.json()["compte_m22bis"] == "6064"


def test_create_ligne_409_duplicate(client, monkeypatch):
    async def _fake(cr_id, company_id, payload):
        raise ConflictError("dup", code="ligne_duplicate")

    monkeypatch.setattr(crp_ligne_service, "create_ligne", _fake)
    r = client.post(
        f"/plugins/compta_esms/crs/{CR_ID}/lignes",
        json={"groupe": "G1", "nature": "charge", "compte_m22bis": "6064"},
    )
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "ligne_duplicate"


# ---------------------------------------------------------------------------
# §6.3 PATCH /lignes/{ligne_id} — Q6 auto-flip
# ---------------------------------------------------------------------------


def test_patch_ligne_200_with_override_flip(client, monkeypatch):
    """Q6 — the service flips override_balance on a bound row. The
    route doesn't care; it just relays the result."""

    async def _fake(ligne_id, company_id, payload):
        return _ligne_dict(
            override_balance=True,
            override_at=datetime.now(UTC),
            montant_realise=Decimal("12500"),
        )

    monkeypatch.setattr(crp_ligne_service, "update_ligne", _fake)
    r = client.patch(
        f"/plugins/compta_esms/lignes/{LIGNE_ID}",
        json={"montant_realise": "12500.00", "override_reason": "correction"},
    )
    assert r.status_code == 200
    assert r.json()["override_balance"] is True


def test_patch_ligne_404(client, monkeypatch):
    async def _fake(ligne_id, company_id, payload):
        raise NotFoundError("nope", code="ligne_not_found")

    monkeypatch.setattr(crp_ligne_service, "update_ligne", _fake)
    r = client.patch(
        f"/plugins/compta_esms/lignes/{LIGNE_ID}",
        json={"notes": "x"},
    )
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §6.4 DELETE /lignes/{ligne_id}
# ---------------------------------------------------------------------------


def test_delete_ligne_204(client, monkeypatch):
    async def _fake(ligne_id, company_id):
        return None

    monkeypatch.setattr(crp_ligne_service, "delete_ligne", _fake)
    r = client.delete(f"/plugins/compta_esms/lignes/{LIGNE_ID}")
    assert r.status_code == 204


def test_delete_ligne_404(client, monkeypatch):
    async def _fake(ligne_id, company_id):
        raise NotFoundError("nope", code="ligne_not_found")

    monkeypatch.setattr(crp_ligne_service, "delete_ligne", _fake)
    r = client.delete(f"/plugins/compta_esms/lignes/{LIGNE_ID}")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §6.5 POST /crs/{cr_id}/lignes:bulk-upsert
# ---------------------------------------------------------------------------


def test_bulk_upsert_200(client, monkeypatch):
    async def _fake(cr_id, company_id, items):
        return [_ligne_dict(compte_m22bis=i.compte_m22bis) for i in items]

    monkeypatch.setattr(crp_ligne_service, "bulk_upsert", _fake)
    r = client.post(
        f"/plugins/compta_esms/crs/{CR_ID}/lignes:bulk-upsert",
        json=[
            {"groupe": "G1", "nature": "charge", "compte_m22bis": "6064"},
            {"groupe": "G2", "nature": "charge", "compte_m22bis": "6411"},
        ],
    )
    assert r.status_code == 200
    body = r.json()
    assert len(body) == 2
    assert body[1]["compte_m22bis"] == "6411"


# ---------------------------------------------------------------------------
# §6.6 POST /crs/{cr_id}/lignes:prefill-from-binding (Q3 explicit)
# ---------------------------------------------------------------------------


def test_prefill_200(client, monkeypatch):
    captured: dict = {}

    async def _fake(*, cr_id, company_id, feature_keys, target_column):
        captured["feature_keys"] = feature_keys
        captured["target_column"] = target_column
        return PrefillFromBindingResponse(
            target_column=target_column,
            results=[
                PrefillFeatureResult(
                    feature_key=fk,
                    inserted=10,
                    updated=2,
                    skipped_overridden=1,
                )
                for fk in feature_keys
            ],
        )

    monkeypatch.setattr(crp_prefill_service, "prefill_from_binding", _fake)
    r = client.post(
        f"/plugins/compta_esms/crs/{CR_ID}/lignes:prefill-from-binding",
        json={
            "feature_keys": ["crp_charges_g1", "crp_produits"],
            "target_column": "montant_realise",
        },
    )
    assert r.status_code == 200
    assert captured["target_column"] == "montant_realise"
    body = r.json()
    assert body["target_column"] == "montant_realise"
    assert len(body["results"]) == 2
    assert body["results"][0]["inserted"] == 10


def test_prefill_missing_target_column_422(client):
    """Q3 — target_column is required, no auto-deduction."""
    r = client.post(
        f"/plugins/compta_esms/crs/{CR_ID}/lignes:prefill-from-binding",
        json={"feature_keys": ["crp_charges_g1"]},
    )
    assert r.status_code == 422


def test_prefill_invalid_target_column_422(client):
    """Q3 — target_column is a Literal of the 5 montant_* columns."""
    r = client.post(
        f"/plugins/compta_esms/crs/{CR_ID}/lignes:prefill-from-binding",
        json={
            "feature_keys": ["crp_charges_g1"],
            "target_column": "montant_hebergement",  # not in MontantColumn Literal
        },
    )
    assert r.status_code == 422


def test_prefill_unknown_feature_404(client, monkeypatch):
    async def _fake(*, cr_id, company_id, feature_keys, target_column):
        raise NotFoundError("nope", code="feature_not_prefillable")

    monkeypatch.setattr(crp_prefill_service, "prefill_from_binding", _fake)
    r = client.post(
        f"/plugins/compta_esms/crs/{CR_ID}/lignes:prefill-from-binding",
        json={
            "feature_keys": ["tper_effectifs"],
            "target_column": "montant_realise",
        },
    )
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "feature_not_prefillable"


# ---------------------------------------------------------------------------
# §6.7 GET /crs/{cr_id}/totals (Q5)
# ---------------------------------------------------------------------------


def test_totals_200_structure(client, monkeypatch):
    pair = CrpTotalsColumnPair(previsions_totales=Decimal("100"), realise=Decimal("110"))
    zero_pair = CrpTotalsColumnPair(previsions_totales=Decimal("0"), realise=Decimal("0"))

    async def _fake(cr_id, company_id):
        return CrpTotalsResponse(
            cr_id=cr_id,
            cr_variante="soumis_equilibre",
            by_groupe={
                "G1": CrpTotalsGroupe(charges=pair, produits=zero_pair),
                "G2": CrpTotalsGroupe(charges=zero_pair, produits=zero_pair),
                "G3": CrpTotalsGroupe(charges=zero_pair, produits=zero_pair),
            },
            total_charges=pair,
            total_produits=zero_pair,
            ecart=CrpEcart(
                previsions_totales=Decimal("-100"),
                realise=Decimal("-110"),
                is_equilibre_required=True,
            ),
        )

    monkeypatch.setattr(crp_ligne_service, "totals", _fake)
    r = client.get(f"/plugins/compta_esms/crs/{CR_ID}/lignes/totals")
    assert r.status_code == 200
    body = r.json()
    assert body["cr_variante"] == "soumis_equilibre"
    assert body["ecart"]["is_equilibre_required"] is True
    assert body["ecart"]["realise"] == "-110"
    assert "G1" in body["by_groupe"]
    assert "G2" in body["by_groupe"]
    assert "G3" in body["by_groupe"]


def test_totals_cr_not_found(client, monkeypatch):
    async def _fake(cr_id, company_id):
        raise NotFoundError("nope", code="cr_not_found")

    monkeypatch.setattr(crp_ligne_service, "totals", _fake)
    r = client.get(f"/plugins/compta_esms/crs/{CR_ID}/lignes/totals")
    assert r.status_code == 404
