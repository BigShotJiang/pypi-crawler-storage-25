"""Tests §V D-064 — service & endpoint economy_bouleversee (soft v0.2).

Couvre :

* Service `validate_economy_bouleversee` retourne 2 conditions toutes
  evaluable=False en v0.2 (squelette non-bloquant)
* 404 document_not_found
* 409 not_a_dm si document = EPRD
* 409 dm_orphan si DM sans parent_id (data corruption defensive)
* Route POST /economy-bouleversee:validate 200 + 404 + 409
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import _limiter as limiter_module
from piilot_pack_compta_esms.routes import dm as dm_routes
from piilot_pack_compta_esms.services import dm_service
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

COMPANY = uuid4()
USER = uuid4()
DM_ID = uuid4()
EPRD_ID = uuid4()
PARENT_EPRD = uuid4()
USER_AUTH = (USER, "user", COMPANY)


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.dm_service.run_in_thread",
        _passthrough,
    )


def _make_doc_row(
    *,
    type_document: str = "dm",
    parent_id=PARENT_EPRD,
    company_id=COMPANY,
) -> dict[str, Any]:
    return {
        "id": DM_ID,
        "company_id": company_id,
        "exercice_id": uuid4(),
        "type_document": type_document,
        "cadre_version": "#DMHA-2026-01#",
        "parent_id": parent_id,
        "statut": "brouillon",
        "periode_observation_debut": None,
        "periode_observation_fin": None,
        "transmis_at": None,
        "executoire_at": None,
        "transmis_par_user_id": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }


# ---------------------------------------------------------------------------
# Service
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_validate_economy_soft_skeleton_evaluable_false(monkeypatch, patch_run_in_thread):
    """v0.2 squelette — 2 conditions toutes evaluable=False."""
    monkeypatch.setattr(dm_service.document_repo, "get_by_id", lambda _: _make_doc_row())
    result = await dm_service.validate_economy_bouleversee(dm_id=DM_ID, company_id=COMPANY)
    assert result.dm_id == DM_ID
    assert result.parent_eprd_id == PARENT_EPRD
    assert result.is_soft_verdict is True
    assert len(result.conditions) == 2
    assert all(not c.evaluable for c in result.conditions)
    assert result.nb_evaluables == 0
    assert result.nb_bouleverse == 0
    assert result.bouleverse_globalement is False
    # Les 2 conditions sont labellisées
    assert result.conditions[0].id == 1
    assert "CAF" in result.conditions[0].label
    assert result.conditions[1].id == 2
    assert "Prélèvement FR" in result.conditions[1].label


@pytest.mark.asyncio
async def test_validate_economy_404_document_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(dm_service.document_repo, "get_by_id", lambda _: None)
    with pytest.raises(NotFoundError) as exc:
        await dm_service.validate_economy_bouleversee(dm_id=DM_ID, company_id=COMPANY)
    assert exc.value.code == "document_not_found"


@pytest.mark.asyncio
async def test_validate_economy_404_cross_tenant(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        dm_service.document_repo,
        "get_by_id",
        lambda _: _make_doc_row(company_id=uuid4()),
    )
    with pytest.raises(NotFoundError) as exc:
        await dm_service.validate_economy_bouleversee(dm_id=DM_ID, company_id=COMPANY)
    assert exc.value.code == "document_not_found"


@pytest.mark.asyncio
async def test_validate_economy_409_not_a_dm(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        dm_service.document_repo,
        "get_by_id",
        lambda _: _make_doc_row(type_document="eprd"),
    )
    with pytest.raises(ConflictError) as exc:
        await dm_service.validate_economy_bouleversee(dm_id=DM_ID, company_id=COMPANY)
    assert exc.value.code == "not_a_dm"


@pytest.mark.asyncio
async def test_validate_economy_409_dm_orphan(monkeypatch, patch_run_in_thread):
    """DM avec parent_id NULL (data corruption defensive)."""
    monkeypatch.setattr(
        dm_service.document_repo,
        "get_by_id",
        lambda _: _make_doc_row(parent_id=None),
    )
    with pytest.raises(ConflictError) as exc:
        await dm_service.validate_economy_bouleversee(dm_id=DM_ID, company_id=COMPANY)
    assert exc.value.code == "dm_orphan"


# ---------------------------------------------------------------------------
# Route
# ---------------------------------------------------------------------------


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter_module.limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(dm_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    return app


def test_route_validate_200(app, monkeypatch):
    from piilot_pack_compta_esms.services.dm_service import (
        EconomyBouleverseResult,
    )

    async def _fake(*, dm_id, company_id):
        return EconomyBouleverseResult(
            dm_id=dm_id,
            parent_eprd_id=PARENT_EPRD,
            conditions=[],
            nb_evaluables=0,
            nb_bouleverse=0,
            bouleverse_globalement=False,
            is_soft_verdict=True,
        )

    monkeypatch.setattr(dm_service, "validate_economy_bouleversee", _fake)
    client = TestClient(app)
    r = client.post(f"/plugins/compta_esms/documents/{DM_ID}/economy-bouleversee:validate")
    assert r.status_code == 200
    body = r.json()
    assert body["is_soft_verdict"] is True
    assert body["bouleverse_globalement"] is False


def test_route_validate_404(app, monkeypatch):
    async def _fake(*, dm_id, company_id):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(dm_service, "validate_economy_bouleversee", _fake)
    client = TestClient(app)
    r = client.post(f"/plugins/compta_esms/documents/{DM_ID}/economy-bouleversee:validate")
    assert r.status_code == 404


def test_route_validate_409_not_a_dm(app, monkeypatch):
    async def _fake(*, dm_id, company_id):
        raise ConflictError("nope", code="not_a_dm")

    monkeypatch.setattr(dm_service, "validate_economy_bouleversee", _fake)
    client = TestClient(app)
    r = client.post(f"/plugins/compta_esms/documents/{DM_ID}/economy-bouleversee:validate")
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "not_a_dm"
