"""Route tests for workflow transitions (L2 §4.6 + §4.7)."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.workflow import (
    DoubleValidationState,
    TransitionResponse,
    TransitionsAllowedResponse,
)
from piilot_pack_compta_esms.routes import _limiter as limiter_module
from piilot_pack_compta_esms.routes import workflow as workflow_routes
from piilot_pack_compta_esms.services import workflow_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
)

COMPANY = uuid4()
USER = uuid4()
DOC = uuid4()
USER_AUTH = (USER, "user", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)
ADMIN_AUTH = (USER, "admin", COMPANY)


def _transition_response(
    *, statut_before: str, statut_after: str, action: str, **kwargs
) -> TransitionResponse:
    return TransitionResponse(
        document_id=DOC,
        type_document="errd",
        statut_before=statut_before,
        statut_after=statut_after,
        action=action,
        transmis_at=datetime.now(tz=UTC) if action == "transmit" else None,
        affectation_definie_at=(datetime.now(tz=UTC) if action == "set_affectation" else None),
        double_validation=DoubleValidationState(applicable=False),
        **kwargs,
    )


def _allowed_response(*, statut: str, type_document: str = "errd") -> TransitionsAllowedResponse:
    return TransitionsAllowedResponse(
        document_id=DOC,
        type_document=type_document,
        current_statut=statut,
        allowed=[],
        blocked=[],
        double_validation=DoubleValidationState(applicable=False),
    )


@pytest.fixture
def app_user():
    app = FastAPI()
    app.state.limiter = limiter_module.limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(workflow_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    return app


@pytest.fixture
def app_builder():
    app = FastAPI()
    app.state.limiter = limiter_module.limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(workflow_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def app_admin():
    app = FastAPI()
    app.state.limiter = limiter_module.limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(workflow_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: ADMIN_AUTH
    return app


# ---------------------------------------------------------------------------
# POST /transitions — happy paths
# ---------------------------------------------------------------------------


def test_post_transition_transmit_errd_200(app_builder, monkeypatch):
    async def _fake(*, document_id, payload, company_id, user_id, role):
        return _transition_response(
            statut_before="brouillon", statut_after="transmis", action="transmit"
        )

    monkeypatch.setattr(workflow_service, "apply_transition", _fake)
    client = TestClient(app_builder)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC}/transitions",
        json={"action": "transmit"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["statut_after"] == "transmis"
    assert body["action"] == "transmit"


def test_post_transition_approve_admin_200(app_admin, monkeypatch):
    async def _fake(*, document_id, payload, company_id, user_id, role):
        return TransitionResponse(
            document_id=DOC,
            type_document="eprd",
            statut_before="en_instruction",
            statut_after="en_instruction",
            action="approve",
            autorite="ars",
            double_validation=DoubleValidationState(
                applicable=True,
                approuve_par_ars_at=datetime.now(tz=UTC),
            ),
        )

    monkeypatch.setattr(workflow_service, "apply_transition", _fake)
    client = TestClient(app_admin)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC}/transitions",
        json={"action": "approve", "autorite": "ars"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["autorite"] == "ars"


def test_post_transition_reject_admin_200(app_admin, monkeypatch):
    async def _fake(*, document_id, payload, company_id, user_id, role):
        return TransitionResponse(
            document_id=DOC,
            type_document="eprd",
            statut_before="en_instruction",
            statut_after="rejete",
            action="reject",
            autorite="cd",
            rejete_at=datetime.now(tz=UTC),
            rejete_par_autorite="cd",
            motif_rejet="Recettes incohérentes",
            double_validation=DoubleValidationState(applicable=True),
        )

    monkeypatch.setattr(workflow_service, "apply_transition", _fake)
    client = TestClient(app_admin)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC}/transitions",
        json={
            "action": "reject",
            "autorite": "cd",
            "motif": "Recettes incohérentes",
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert body["statut_after"] == "rejete"
    assert body["motif_rejet"] == "Recettes incohérentes"


# ---------------------------------------------------------------------------
# POST /transitions — Pydantic 422 (cross-field validation)
# ---------------------------------------------------------------------------


def test_post_transition_reject_missing_motif_422(app_admin):
    client = TestClient(app_admin)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC}/transitions",
        json={"action": "reject", "autorite": "ars"},
    )
    assert r.status_code == 422


def test_post_transition_approve_with_motif_422(app_admin):
    """approve doit refuser un motif (champ exclusivement pour reject)."""
    client = TestClient(app_admin)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC}/transitions",
        json={"action": "approve", "autorite": "ars", "motif": "Should not appear"},
    )
    assert r.status_code == 422


def test_post_transition_transmit_with_autorite_422(app_builder):
    """transmit ne doit pas avoir d'autorite."""
    client = TestClient(app_builder)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC}/transitions",
        json={"action": "transmit", "autorite": "ars"},
    )
    assert r.status_code == 422


def test_post_transition_approve_without_autorite_422(app_admin):
    client = TestClient(app_admin)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC}/transitions",
        json={"action": "approve"},
    )
    assert r.status_code == 422


# ---------------------------------------------------------------------------
# POST /transitions — service errors → HTTP codes
# ---------------------------------------------------------------------------


def test_post_transition_404_document_not_found(app_builder, monkeypatch):
    async def _fake(*, document_id, payload, company_id, user_id, role):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(workflow_service, "apply_transition", _fake)
    client = TestClient(app_builder)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC}/transitions",
        json={"action": "transmit"},
    )
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "document_not_found"


def test_post_transition_403_role_required(app_user, monkeypatch):
    async def _fake(*, document_id, payload, company_id, user_id, role):
        raise CrossCompanyError("role required", code="role_required")

    monkeypatch.setattr(workflow_service, "apply_transition", _fake)
    client = TestClient(app_user)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC}/transitions",
        json={"action": "transmit"},
    )
    assert r.status_code == 403
    assert r.json()["detail"]["code"] == "role_required"


def test_post_transition_409_idempotence(app_builder, monkeypatch):
    async def _fake(*, document_id, payload, company_id, user_id, role):
        raise ConflictError(
            "already transmitted",
            code="transition_not_allowed_from_statut",
        )

    monkeypatch.setattr(workflow_service, "apply_transition", _fake)
    client = TestClient(app_builder)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC}/transitions",
        json={"action": "transmit"},
    )
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "transition_not_allowed_from_statut"


# ---------------------------------------------------------------------------
# GET /transitions-allowed
# ---------------------------------------------------------------------------


def test_get_transitions_allowed_200(app_user, monkeypatch):
    async def _fake(*, document_id, company_id, role):
        return _allowed_response(statut="brouillon")

    monkeypatch.setattr(workflow_service, "get_transitions_allowed", _fake)
    client = TestClient(app_user)
    r = client.get(f"/plugins/compta_esms/documents/{DOC}/transitions-allowed")
    assert r.status_code == 200
    body = r.json()
    assert body["current_statut"] == "brouillon"
    assert "allowed" in body
    assert "blocked" in body
    assert "double_validation" in body


def test_get_transitions_allowed_404(app_user, monkeypatch):
    async def _fake(*, document_id, company_id, role):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(workflow_service, "get_transitions_allowed", _fake)
    client = TestClient(app_user)
    r = client.get(f"/plugins/compta_esms/documents/{DOC}/transitions-allowed")
    assert r.status_code == 404
