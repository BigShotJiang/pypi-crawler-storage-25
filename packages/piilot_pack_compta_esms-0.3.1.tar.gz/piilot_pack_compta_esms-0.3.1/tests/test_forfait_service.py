"""Unit tests for :mod:`piilot_pack_compta_esms.services.forfait_service`."""

from __future__ import annotations

from datetime import UTC, date, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.annexe5 import ForfaitParametresUpdate
from piilot_pack_compta_esms.services import forfait_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
DOC_ID = uuid4()
ETS_ID_A = uuid4()
ETS_ID_B = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.forfait_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def valid_doc_ets(monkeypatch):
    monkeypatch.setattr(
        forfait_service.forfait_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        forfait_service.forfait_repo,
        "etablissement_belongs_to_company",
        lambda ets, company: True,
    )


def _row(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "etablissement_id": ETS_ID_A,
        "date_evaluation": date(2025, 6, 30),
        "nombre_points_gir": 12500,
        "nombre_personnes_girees": 80,
        "valeur_point_gir": Decimal("7.2300"),
        "gmp": Decimal("720.5000"),
        "pmp": Decimal("180.0000"),
        "gmps": Decimal("900.5000"),
        "created_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# list_forfait_parametres
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_returns_one_per_ets(patch_run_in_thread, valid_doc_ets, monkeypatch):
    monkeypatch.setattr(
        forfait_service.forfait_repo,
        "list_by_document",
        lambda d: [_row(), _row(etablissement_id=ETS_ID_B)],
    )

    result = await forfait_service.list_forfait_parametres(DOC_ID, COMPANY)

    assert len(result.items) == 2
    ets_ids = {item.etablissement_id for item in result.items}
    assert ets_ids == {ETS_ID_A, ETS_ID_B}


@pytest.mark.asyncio
async def test_list_empty(patch_run_in_thread, valid_doc_ets, monkeypatch):
    monkeypatch.setattr(forfait_service.forfait_repo, "list_by_document", lambda d: [])

    result = await forfait_service.list_forfait_parametres(DOC_ID, COMPANY)

    assert result.items == []


@pytest.mark.asyncio
async def test_list_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        forfait_service.forfait_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    with pytest.raises(NotFoundError) as exc:
        await forfait_service.list_forfait_parametres(DOC_ID, COMPANY)
    assert exc.value.code == "document_not_found"


# ---------------------------------------------------------------------------
# upsert_forfait_parametres — Q7 DELETE+INSERT
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_upsert_creates_new(patch_run_in_thread, valid_doc_ets, monkeypatch):
    captured = {}

    def _upsert(**kwargs):
        captured.update(kwargs)
        return _row()

    monkeypatch.setattr(forfait_service.forfait_repo, "upsert_by_doc_ets", _upsert)

    payload = ForfaitParametresUpdate(
        ets_id=ETS_ID_A,
        date_evaluation=date(2025, 6, 30),
        nombre_points_gir=12500,
        nombre_personnes_girees=80,
        valeur_point_gir=Decimal("7.23"),
        gmp=Decimal("720.5"),
        pmp=Decimal("180"),
        gmps=Decimal("900.5"),
    )
    result = await forfait_service.upsert_forfait_parametres(DOC_ID, COMPANY, payload)

    assert captured["etablissement_id"] == ETS_ID_A
    assert captured["document_id"] == DOC_ID
    assert captured["params"]["nombre_points_gir"] == 12500
    assert result.etablissement_id == ETS_ID_A


@pytest.mark.asyncio
async def test_upsert_idempotent_overwrite(patch_run_in_thread, valid_doc_ets, monkeypatch):
    """2 appels successifs sur (doc, ets) → DELETE+INSERT chaque fois."""
    call_count = {"n": 0}

    def _upsert(**kwargs):
        call_count["n"] += 1
        return _row()

    monkeypatch.setattr(forfait_service.forfait_repo, "upsert_by_doc_ets", _upsert)

    payload = ForfaitParametresUpdate(ets_id=ETS_ID_A, gmp=Decimal("700"))
    await forfait_service.upsert_forfait_parametres(DOC_ID, COMPANY, payload)

    payload2 = ForfaitParametresUpdate(ets_id=ETS_ID_A, gmp=Decimal("750"))
    await forfait_service.upsert_forfait_parametres(DOC_ID, COMPANY, payload2)

    # Le repo a été appelé 2 fois (pattern DELETE+INSERT idempotent)
    assert call_count["n"] == 2


@pytest.mark.asyncio
async def test_upsert_partial_params_only(patch_run_in_thread, valid_doc_ets, monkeypatch):
    """Q8 fail-open — payload partiel (juste GMP) accepté sans hard
    reject typologie."""
    captured = {}

    def _upsert(**kwargs):
        captured.update(kwargs)
        return _row()

    monkeypatch.setattr(forfait_service.forfait_repo, "upsert_by_doc_ets", _upsert)

    payload = ForfaitParametresUpdate(ets_id=ETS_ID_A, gmp=Decimal("720"))
    await forfait_service.upsert_forfait_parametres(DOC_ID, COMPANY, payload)

    # Tous les autres params doivent être None mais le payload doit
    # passer (fail-open Q8)
    assert captured["params"]["gmp"] == "720"
    assert captured["params"]["pmp"] is None
    assert captured["params"]["gmps"] is None


@pytest.mark.asyncio
async def test_upsert_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        forfait_service.forfait_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    payload = ForfaitParametresUpdate(ets_id=ETS_ID_A)
    with pytest.raises(NotFoundError) as exc:
        await forfait_service.upsert_forfait_parametres(DOC_ID, COMPANY, payload)
    assert exc.value.code == "document_not_found"


@pytest.mark.asyncio
async def test_upsert_ets_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        forfait_service.forfait_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        forfait_service.forfait_repo,
        "etablissement_belongs_to_company",
        lambda ets, company: False,
    )

    payload = ForfaitParametresUpdate(ets_id=ETS_ID_A)
    with pytest.raises(NotFoundError) as exc:
        await forfait_service.upsert_forfait_parametres(DOC_ID, COMPANY, payload)
    assert exc.value.code == "etablissement_not_found"
