"""Unit tests for :mod:`piilot_pack_compta_esms.services.og_service`.

The service layer is isolated from the DB by monkeypatching
``og_repo.*`` functions and the SDK's ``run_in_thread`` helper. We
exercise: list, get, create (happy + FINESS conflict), update (happy
+ not-found + FINESS conflict + race), delete (happy + has-deps +
not-found).
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.og import OGCreate, OGUpdate
from piilot_pack_compta_esms.services import og_service
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

COMPANY = uuid4()
OG_ID = uuid4()


def _make_og_row(**overrides):
    """Build a fake row matching the repo SELECT projection."""
    base = {
        "id": OG_ID,
        "company_id": COMPANY,
        "finess_juridique": "111111111",
        "raison_sociale": "OG Test",
        "nature_juridique": "PRIVE_NON_LUCRATIF",
        "plan_comptable": "PNL",
        "adresse": None,
        "cpom_date_effet": None,
        "representant_legal": None,
        "representant_qualite": None,
        "siret": None,
        "telephone": None,
        "email": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    """Replace ``run_in_thread`` with a sync passthrough.

    The repo functions are sync; bypassing the threadpool keeps tests
    fast and deterministic — RLS thread propagation is exercised by
    the integration suite, not here.
    """

    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr("piilot_pack_compta_esms.services.og_service.run_in_thread", _passthrough)


@pytest.mark.asyncio
async def test_list_returns_pydantic_reads(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        og_service.og_repo,
        "list_by_company",
        lambda company_id: [_make_og_row(), _make_og_row(finess_juridique="222222222")],
    )
    out = await og_service.list_orgs(COMPANY)
    assert len(out) == 2
    assert out[0].finess_juridique == "111111111"
    assert out[1].finess_juridique == "222222222"


@pytest.mark.asyncio
async def test_get_raises_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(og_service.og_repo, "get_by_id", lambda og_id: None)
    with pytest.raises(NotFoundError):
        await og_service.get_org(OG_ID)


@pytest.mark.asyncio
async def test_get_returns_read(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(og_service.og_repo, "get_by_id", lambda og_id: _make_og_row())
    out = await og_service.get_org(OG_ID)
    assert out.id == OG_ID


@pytest.mark.asyncio
async def test_create_happy_path(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(og_service.og_repo, "find_by_finess", lambda company_id, finess: None)
    captured = {}

    def _create(company_id, payload):
        captured["company_id"] = company_id
        captured["payload"] = payload
        return _make_og_row(finess_juridique=payload["finess_juridique"])

    monkeypatch.setattr(og_service.og_repo, "create", _create)
    payload = OGCreate(
        finess_juridique="333333333",
        raison_sociale="New OG",
        nature_juridique="PRIVE_NON_LUCRATIF",
        plan_comptable="PNL",
    )
    out = await og_service.create_org(COMPANY, payload)
    assert out.finess_juridique == "333333333"
    assert captured["company_id"] == COMPANY


@pytest.mark.asyncio
async def test_create_finess_conflict(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        og_service.og_repo,
        "find_by_finess",
        lambda company_id, finess: _make_og_row(finess_juridique=finess),
    )
    payload = OGCreate(
        finess_juridique="111111111",
        raison_sociale="Dup",
        nature_juridique="PRIVE_NON_LUCRATIF",
        plan_comptable="PNL",
    )
    with pytest.raises(ConflictError) as exc:
        await og_service.create_org(COMPANY, payload)
    assert exc.value.code == "og_finess_taken"


@pytest.mark.asyncio
async def test_update_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(og_service.og_repo, "get_by_id", lambda og_id: None)
    with pytest.raises(NotFoundError):
        await og_service.update_org(COMPANY, OG_ID, OGUpdate(raison_sociale="X"))


@pytest.mark.asyncio
async def test_update_finess_conflict(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(og_service.og_repo, "get_by_id", lambda og_id: _make_og_row())
    other_id = uuid4()
    monkeypatch.setattr(
        og_service.og_repo,
        "find_by_finess",
        lambda company_id, finess: _make_og_row(id=other_id, finess_juridique=finess),
    )
    with pytest.raises(ConflictError):
        await og_service.update_org(COMPANY, OG_ID, OGUpdate(finess_juridique="999999999"))


@pytest.mark.asyncio
async def test_update_happy_path(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(og_service.og_repo, "get_by_id", lambda og_id: _make_og_row())
    monkeypatch.setattr(og_service.og_repo, "find_by_finess", lambda company_id, finess: None)
    monkeypatch.setattr(
        og_service.og_repo,
        "update",
        lambda og_id, payload: _make_og_row(**payload),
    )
    out = await og_service.update_org(COMPANY, OG_ID, OGUpdate(raison_sociale="Renamed"))
    assert out.raison_sociale == "Renamed"


@pytest.mark.asyncio
async def test_delete_blocks_when_etablissements_exist(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(og_service.og_repo, "get_by_id", lambda og_id: _make_og_row())
    monkeypatch.setattr(og_service.og_repo, "count_etablissements", lambda og_id: 3)
    monkeypatch.setattr(og_service.og_repo, "count_exercices", lambda og_id: 0)
    with pytest.raises(ConflictError) as exc:
        await og_service.delete_org(OG_ID)
    assert exc.value.code == "og_has_etablissements"


@pytest.mark.asyncio
async def test_delete_blocks_when_exercices_exist(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(og_service.og_repo, "get_by_id", lambda og_id: _make_og_row())
    monkeypatch.setattr(og_service.og_repo, "count_etablissements", lambda og_id: 0)
    monkeypatch.setattr(og_service.og_repo, "count_exercices", lambda og_id: 2)
    with pytest.raises(ConflictError) as exc:
        await og_service.delete_org(OG_ID)
    assert exc.value.code == "og_has_exercices"


@pytest.mark.asyncio
async def test_delete_happy_path(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(og_service.og_repo, "get_by_id", lambda og_id: _make_og_row())
    monkeypatch.setattr(og_service.og_repo, "count_etablissements", lambda og_id: 0)
    monkeypatch.setattr(og_service.og_repo, "count_exercices", lambda og_id: 0)
    monkeypatch.setattr(og_service.og_repo, "delete", lambda og_id: True)
    # No exception → ok.
    await og_service.delete_org(OG_ID)


@pytest.mark.asyncio
async def test_delete_race_returns_not_found(monkeypatch, patch_run_in_thread):
    """If delete returns False (row got removed by another caller), 404."""
    monkeypatch.setattr(og_service.og_repo, "get_by_id", lambda og_id: _make_og_row())
    monkeypatch.setattr(og_service.og_repo, "count_etablissements", lambda og_id: 0)
    monkeypatch.setattr(og_service.og_repo, "count_exercices", lambda og_id: 0)
    monkeypatch.setattr(og_service.og_repo, "delete", lambda og_id: False)
    with pytest.raises(NotFoundError):
        await og_service.delete_org(OG_ID)
