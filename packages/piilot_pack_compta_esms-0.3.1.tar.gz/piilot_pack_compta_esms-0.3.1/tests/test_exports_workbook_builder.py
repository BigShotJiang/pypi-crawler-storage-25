"""Tests §AB — workbook_builder orchestrateur.

Couvre la construction end-to-end avec mocks des repos pour vérifier
que les 12-13 onglets sont créés et le mapping cellules de base
fonctionne.
"""

from __future__ import annotations

from datetime import UTC, date, datetime
from decimal import Decimal
from io import BytesIO
from uuid import uuid4

import pytest
from openpyxl import load_workbook

from piilot_pack_compta_esms.exports.xlsx import workbook_builder

COMPANY = uuid4()
DOC_ID = uuid4()
EXERCICE_ID = uuid4()
OG_ID = uuid4()


def _doc():
    return {
        "id": DOC_ID,
        "company_id": COMPANY,
        "exercice_id": EXERCICE_ID,
        "type_document": "errd",
        "cadre_version": "#ERRDHA-2025-01#",
        "parent_id": None,
        "statut": "brouillon",
        "periode_observation_debut": None,
        "periode_observation_fin": None,
        "transmis_at": None,
        "executoire_at": None,
        "transmis_par_user_id": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }


@pytest.fixture(autouse=True)
def _patch_loaders(monkeypatch):
    """Mock tous les repos pour que workbook_builder tourne sans DB."""

    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr("piilot_pack_compta_esms.exports.xlsx._base.run_in_thread", _passthrough)

    from piilot_pack_compta_esms.repositories import (
        affectation_repo,
        bilan_repo,
        controles_resultats_repo,
        cr_repo,
        crp_ligne_repo,
        document_repo,
        emprunts_repo,
        etablissement_repo,
        og_repo,
        provisions_repo,
        rcc_repo,
        rgpd_repo,
        suivi_affectation_repo,
        tf_repo,
    )

    monkeypatch.setattr(
        document_repo,
        "exercice_lookup",
        lambda eid: {
            "id": EXERCICE_ID,
            "company_id": COMPANY,
            "og_id": OG_ID,
            "annee": 2025,
        },
    )
    monkeypatch.setattr(
        og_repo,
        "get_by_id",
        lambda og: {
            "id": OG_ID,
            "company_id": COMPANY,
            "finess_juridique": "750000123",
            "raison_sociale": "OG Test",
            "nature_juridique": "PRIVE_NON_LUCRATIF",
            "plan_comptable": "PC",
            "adresse": "1 rue test",
            "telephone": "0102030405",
            "email": "contact@test.fr",
            "representant_legal": "Jean Test",
            "representant_qualite": "Directeur",
            "cpom_date_effet": date(2024, 1, 1),
            "siret": None,
            "created_at": datetime.now(UTC),
            "updated_at": datetime.now(UTC),
        },
    )
    monkeypatch.setattr(
        etablissement_repo,
        "list_by_og",
        lambda og, typologie=None: [
            {
                "id": uuid4(),
                "finess_ets": "750100001",
                "raison_sociale": "EHPAD Test",
                "typologie": "ehpad",
                "capacite_installee": 80,
                "convention_collective": "CCN_51",
            }
        ],
    )

    cr_id = uuid4()
    monkeypatch.setattr(
        cr_repo,
        "list_by_document",
        lambda d: [
            {
                "id": cr_id,
                "company_id": COMPANY,
                "document_id": d,
                "cr_type": "CRPP",
                "cr_variante": "soumis_equilibre",
                "denomination": "CRPP Test",
                "cr_identifiant": "CRPP-001",
                "etablissement_id": uuid4(),
                "finess_rattachement": "750100001",
                "capacite_installee": 80,
                "amplitude_ouverture": 365,
                "ventilation": "ternaire_hds",
                "ordre": 0,
                "created_at": datetime.now(UTC),
                "updated_at": datetime.now(UTC),
            }
        ],
    )

    monkeypatch.setattr(
        crp_ligne_repo,
        "list_by_cr",
        lambda c, groupe=None, nature=None: [
            {
                "compte_m22bis": "601",
                "compte_label": "Achats stockés",
                "groupe": "G1",
                "nature": "charge",
                "montant_budget_initial": Decimal("10000"),
                "montant_virements_credits": Decimal("0"),
                "montant_decisions_modif": Decimal("0"),
                "montant_previsions_totales": Decimal("10000"),
                "montant_realise": Decimal("9500"),
                "montant_hebergement": Decimal("9500"),
                "montant_dependance": Decimal("0"),
                "montant_soins": Decimal("0"),
                "montant_soins_autonomie": Decimal("0"),
            },
            {
                "compte_m22bis": "70",
                "compte_label": "Produits",
                "groupe": "G1",
                "nature": "produit",
                "montant_budget_initial": Decimal("12000"),
                "montant_virements_credits": Decimal("0"),
                "montant_decisions_modif": Decimal("0"),
                "montant_previsions_totales": Decimal("12000"),
                "montant_realise": Decimal("11500"),
                "montant_hebergement": Decimal("0"),
                "montant_dependance": Decimal("0"),
                "montant_soins": Decimal("0"),
                "montant_soins_autonomie": Decimal("0"),
            },
        ],
    )

    # Tous les autres repos retournent vide — c'est OK pour le smoke test.
    monkeypatch.setattr(bilan_repo, "list_by_document", lambda d, **kw: [])
    monkeypatch.setattr(tf_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(affectation_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(suivi_affectation_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(provisions_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(emprunts_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(rcc_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(controles_resultats_repo, "list_by_document", lambda d, **kw: [])
    monkeypatch.setattr(rgpd_repo, "get_by_exercice", lambda e: None)


@pytest.mark.asyncio
async def test_build_errd_workbook_creates_all_sheets() -> None:
    """Le workbook ERRD contient tous les onglets attendus."""
    bytes_data = await workbook_builder.build_errd_workbook(DOC_ID, COMPANY, _doc())
    wb = load_workbook(BytesIO(bytes_data))
    expected = {
        "Page de garde",
        "Id_CR_SF",
        "Sommaire",
        "Tabl. de financement",
        "Bilan financier",
        "Provisions",
        "Emprunts",
        "Affectation Résultats",
        "Suivi Affectation",
        "Tableau Rcc",
        "onglet_contrôle",
    }
    assert expected.issubset(set(wb.sheetnames))
    # Pas de "Sheet" par défaut résiduel
    assert "Sheet" not in wb.sheetnames


@pytest.mark.asyncio
async def test_build_errd_workbook_includes_recueil_only_when_flag() -> None:
    """L'onglet Recueil consentement n'est présent que si flag=True."""
    bytes_off = await workbook_builder.build_errd_workbook(
        DOC_ID, COMPANY, _doc(), include_recueil_consentement=False
    )
    bytes_on = await workbook_builder.build_errd_workbook(
        DOC_ID, COMPANY, _doc(), include_recueil_consentement=True
    )
    wb_off = load_workbook(BytesIO(bytes_off))
    wb_on = load_workbook(BytesIO(bytes_on))
    assert "Recueil consentement" not in wb_off.sheetnames
    assert "Recueil consentement" in wb_on.sheetnames


@pytest.mark.asyncio
async def test_build_errd_workbook_writes_page_de_garde_cells() -> None:
    """Les cellules clés de la Page de garde sont remplies."""
    bytes_data = await workbook_builder.build_errd_workbook(DOC_ID, COMPANY, _doc())
    wb = load_workbook(BytesIO(bytes_data))
    ws = wb["Page de garde"]
    assert ws["A1"].value == "#ERRDHA-2025-01#"
    assert ws["D4"].value == 2025
    assert ws["D6"].value == "750000123"
    assert ws["D8"].value == "OG Test"


@pytest.mark.asyncio
async def test_build_errd_workbook_creates_crp_sheet_per_cr() -> None:
    """1 feuille par CR avec préfixe CRP_SE_."""
    bytes_data = await workbook_builder.build_errd_workbook(DOC_ID, COMPANY, _doc())
    wb = load_workbook(BytesIO(bytes_data))
    crp_sheets = [s for s in wb.sheetnames if s.startswith("CRP_SE_")]
    assert len(crp_sheets) == 1
    assert "CRPP Test" in crp_sheets[0]


@pytest.mark.asyncio
async def test_build_errd_workbook_perf_under_5s() -> None:
    """Construction < 5s — L5c §242 critère acceptance."""
    import time

    start = time.monotonic()
    await workbook_builder.build_errd_workbook(DOC_ID, COMPANY, _doc())
    elapsed = time.monotonic() - start
    assert elapsed < 5.0, f"Build trop lent : {elapsed:.2f}s"


@pytest.mark.asyncio
async def test_build_errd_workbook_no_pipe_char_in_cells() -> None:
    """Aucune cellule ne contient `|` — L5c §240 critère."""
    bytes_data = await workbook_builder.build_errd_workbook(DOC_ID, COMPANY, _doc())
    wb = load_workbook(BytesIO(bytes_data))
    for sheet in wb.sheetnames:
        ws = wb[sheet]
        for row in ws.iter_rows(values_only=True):
            for value in row:
                if isinstance(value, str) and "|" in value:
                    pytest.fail(f"`|` trouvé dans {sheet} : {value!r}")


@pytest.mark.asyncio
async def test_build_errd_workbook_cadre_version_in_a1() -> None:
    """L5c §241 — cadre_version snapshot apparaît en A1 Page de garde."""
    bytes_data = await workbook_builder.build_errd_workbook(DOC_ID, COMPANY, _doc())
    wb = load_workbook(BytesIO(bytes_data))
    assert wb["Page de garde"]["A1"].value == "#ERRDHA-2025-01#"


def test_derive_filename_with_annee() -> None:
    """derive_filename utilise type_document.upper() + annee."""
    fname = workbook_builder.derive_filename(_doc(), {"annee": 2025})
    assert fname == "ERRD_2025.xlsx"


def test_derive_filename_fallback_no_exercice() -> None:
    fname = workbook_builder.derive_filename(_doc(), None)
    assert fname.startswith("ERRD_")
    assert fname.endswith(".xlsx")
