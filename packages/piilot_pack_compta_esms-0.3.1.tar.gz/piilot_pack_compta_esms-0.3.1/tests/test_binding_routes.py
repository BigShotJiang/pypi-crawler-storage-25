"""Route tests for binding endpoints (L2 §7, 6 endpoints)."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.kb_binding import (
    BindingPreviewResponse,
    BindingValidationResult,
    CandidateKb,
    KbBindingRead,
)
from piilot_pack_compta_esms.routes import binding as binding_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import binding_service
from piilot_pack_compta_esms.services.errors import (
    NotFoundError,
    ValidationError,
)

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
KB_ID = uuid4()
BUILDER_AUTH = (USER, "builder", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


def _binding_read(**overrides) -> KbBindingRead:
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "feature_key": "crp_charges_g1",
        "kb_id": KB_ID,
        "kb_table": "compta_esms__bal__abc12345",
        "column_mapping": {},
        "plan_comptable_source": "M22Bis",
        "bound_by_user_id": USER,
        "bound_at": datetime.now(UTC),
    }
    base.update(overrides)
    return KbBindingRead.model_validate(base)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(binding_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# §7.1 GET /documents/{doc_id}/bindings
# ---------------------------------------------------------------------------


def test_list_bindings_200(client, monkeypatch):
    async def _fake(doc, company):
        return [
            _binding_read(),
            _binding_read(feature_key="crp_produits"),
        ]

    monkeypatch.setattr(binding_service, "list_bindings", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/bindings")
    assert r.status_code == 200
    assert [b["feature_key"] for b in r.json()] == ["crp_charges_g1", "crp_produits"]


def test_list_bindings_doc_not_found(client, monkeypatch):
    async def _fake(doc, company):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(binding_service, "list_bindings", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/bindings")
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "document_not_found"


# ---------------------------------------------------------------------------
# §7.2 GET /documents/{doc_id}/bindings/candidate-kbs
# ---------------------------------------------------------------------------


def test_list_candidate_kbs_200(client, monkeypatch):
    async def _fake(*, document_id, feature_key, company_id):
        assert feature_key == "crp_charges_g1"
        return [
            CandidateKb(
                kb_id=KB_ID,
                name="balance_m22bis_2026",
                kb_table="compta_esms__bal__abc12345",
                row_count=842,
                owner_type="plugin",
                owner_ref="compta_esms",
                columns=[{"name": "compte", "type": "text"}],
                warnings=[],
            )
        ]

    monkeypatch.setattr(binding_service, "list_candidate_kbs", _fake)
    r = client.get(
        f"/plugins/compta_esms/documents/{DOC_ID}/bindings/candidate-kbs"
        "?feature_key=crp_charges_g1"
    )
    assert r.status_code == 200
    body = r.json()
    assert body[0]["row_count"] == 842


def test_list_candidate_kbs_missing_feature_key(client):
    """feature_key is a required query param."""
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/bindings/candidate-kbs")
    assert r.status_code == 422


# ---------------------------------------------------------------------------
# §7.3 PUT /documents/{doc_id}/bindings/{feature_key}
# ---------------------------------------------------------------------------


def test_put_binding_200(client, monkeypatch):
    captured: dict = {}

    async def _fake(*, document_id, feature_key, payload, company_id, user_id):
        captured["feature_key"] = feature_key
        captured["kb_id"] = payload.kb_id
        return _binding_read(feature_key=feature_key, kb_id=payload.kb_id)

    monkeypatch.setattr(binding_service, "put_binding", _fake)
    r = client.put(
        f"/plugins/compta_esms/documents/{DOC_ID}/bindings/crp_charges_g1",
        json={"kb_id": str(KB_ID), "column_mapping": {"compte": "account_number"}},
    )
    assert r.status_code == 200
    assert r.json()["feature_key"] == "crp_charges_g1"
    assert captured["feature_key"] == "crp_charges_g1"


def test_put_binding_contract_violation_422(client, monkeypatch):
    async def _fake(**kw):
        raise ValidationError("missing column", code="binding_contract_violation")

    monkeypatch.setattr(binding_service, "put_binding", _fake)
    r = client.put(
        f"/plugins/compta_esms/documents/{DOC_ID}/bindings/crp_charges_g1",
        json={"kb_id": str(KB_ID)},
    )
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "binding_contract_violation"


def test_put_binding_unknown_feature_404(client, monkeypatch):
    async def _fake(**kw):
        raise NotFoundError("nope", code="feature_not_found")

    monkeypatch.setattr(binding_service, "put_binding", _fake)
    r = client.put(
        f"/plugins/compta_esms/documents/{DOC_ID}/bindings/ghost",
        json={"kb_id": str(KB_ID)},
    )
    assert r.status_code == 404


def test_put_binding_user_role_403(client):
    """builder is required for PUT."""

    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.put(
        f"/plugins/compta_esms/documents/{DOC_ID}/bindings/crp_charges_g1",
        json={"kb_id": str(KB_ID)},
    )
    assert r.status_code == 403


# ---------------------------------------------------------------------------
# §7.4 DELETE /documents/{doc_id}/bindings/{feature_key}
# ---------------------------------------------------------------------------


def test_delete_binding_204(client, monkeypatch):
    async def _fake(doc, key, company):
        return None

    monkeypatch.setattr(binding_service, "delete_binding", _fake)
    r = client.delete(f"/plugins/compta_esms/documents/{DOC_ID}/bindings/crp_charges_g1")
    assert r.status_code == 204


def test_delete_binding_404(client, monkeypatch):
    async def _fake(doc, key, company):
        raise NotFoundError("nope", code="binding_not_found")

    monkeypatch.setattr(binding_service, "delete_binding", _fake)
    r = client.delete(f"/plugins/compta_esms/documents/{DOC_ID}/bindings/missing")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §7.5 POST /documents/{doc_id}/bindings/{feature_key}:preview
# ---------------------------------------------------------------------------


def test_preview_binding_200(client, monkeypatch):
    captured: dict = {}

    async def _fake(*, document_id, feature_key, company_id, filters):
        captured["filters"] = filters
        return BindingPreviewResponse(
            feature_key=feature_key,
            rows=[],
            warnings=[],
            row_count=0,
            truncated=False,
        )

    monkeypatch.setattr(binding_service, "preview_binding", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/bindings/crp_charges_g1:preview",
        json={"filters": {"periode": "2026-Q1"}},
    )
    assert r.status_code == 200
    assert captured["filters"] == {"periode": "2026-Q1"}


def test_preview_binding_empty_body(client, monkeypatch):
    captured: dict = {}

    async def _fake(*, document_id, feature_key, company_id, filters):
        captured["filters"] = filters
        return BindingPreviewResponse(
            feature_key=feature_key,
            rows=[],
            warnings=[],
            row_count=0,
        )

    monkeypatch.setattr(binding_service, "preview_binding", _fake)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/bindings/crp_charges_g1:preview")
    assert r.status_code == 200
    assert captured["filters"] == {}


# ---------------------------------------------------------------------------
# §7.6 GET /documents/{doc_id}/bindings:validation
# ---------------------------------------------------------------------------


def test_validation_ready(client, monkeypatch):
    async def _fake(*, document_id, company_id):
        return BindingValidationResult(
            mandatory_features=["crp_charges_g1", "crp_charges_g2"],
            bindings_present=["crp_charges_g1", "crp_charges_g2"],
            missing=[],
            ready_to_produce=True,
        )

    monkeypatch.setattr(binding_service, "validation", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/bindings:validation")
    assert r.status_code == 200
    body = r.json()
    assert body["ready_to_produce"] is True
    assert body["missing"] == []


def test_validation_missing(client, monkeypatch):
    async def _fake(*, document_id, company_id):
        return BindingValidationResult(
            mandatory_features=["crp_charges_g1", "crp_charges_g2"],
            bindings_present=["crp_charges_g1"],
            missing=["crp_charges_g2"],
            ready_to_produce=False,
        )

    monkeypatch.setattr(binding_service, "validation", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/bindings:validation")
    assert r.status_code == 200
    body = r.json()
    assert body["ready_to_produce"] is False
    assert body["missing"] == ["crp_charges_g2"]
