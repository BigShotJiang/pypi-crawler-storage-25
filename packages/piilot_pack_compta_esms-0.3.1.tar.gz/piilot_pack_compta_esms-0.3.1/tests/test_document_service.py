"""Unit tests for :mod:`piilot_pack_compta_esms.services.document_service`.

Same pattern as the OG/Établissement/Exercice service tests : mock
``run_in_thread`` to a sync passthrough, monkeypatch
``document_repo.*`` functions. The auto-CRPP transaction is tested
by asserting on the captured call to ``create_with_default_crpp``
(the actual DB transaction is exercised by integration tests later).
"""

from __future__ import annotations

from datetime import UTC, date, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.document import (
    DocumentClone,
    DocumentCreate,
    DocumentUpdate,
)
from piilot_pack_compta_esms.services import document_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
)

COMPANY = uuid4()
OTHER_COMPANY = uuid4()
EXERCICE_ID = uuid4()
DOC_ID = uuid4()
PARENT_EPRD_ID = uuid4()


def _make_doc_row(**overrides):
    base = {
        "id": DOC_ID,
        "company_id": COMPANY,
        "exercice_id": EXERCICE_ID,
        "type_document": "eprd",
        "cadre_version": "#EPRDHA-2026-01#",
        "parent_id": None,
        "statut": "brouillon",
        "periode_observation_debut": None,
        "periode_observation_fin": None,
        "transmis_at": None,
        "executoire_at": None,
        "transmis_par_user_id": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


def _make_exercice_lookup(**overrides):
    base = {
        "id": EXERCICE_ID,
        "company_id": COMPANY,
        "og_id": uuid4(),
        "annee": 2026,
    }
    base.update(overrides)
    return base


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.document_service.run_in_thread",
        _passthrough,
    )


# ---------------------------------------------------------------------------
# Parent rule (DM/RIA require EPRD parent ; EPRD/ERRD forbid parent)
# ---------------------------------------------------------------------------


def test_create_rejects_dm_without_parent():
    """Pydantic model-level validator catches this at parse time."""
    with pytest.raises(ValueError) as exc:
        DocumentCreate(exercice_id=EXERCICE_ID, type_document="dm")
    assert "requires parent_id" in str(exc.value)


def test_create_rejects_eprd_with_parent():
    with pytest.raises(ValueError) as exc:
        DocumentCreate(
            exercice_id=EXERCICE_ID,
            type_document="eprd",
            parent_id=PARENT_EPRD_ID,
        )
    assert "forbids parent_id" in str(exc.value)


def test_ria_periode_must_be_paired():
    with pytest.raises(ValueError):
        DocumentCreate(
            exercice_id=EXERCICE_ID,
            type_document="ria",
            parent_id=PARENT_EPRD_ID,
            periode_observation_debut=date(2026, 1, 1),
            # fin missing — must raise
        )


def test_ria_periode_debut_after_fin_rejected():
    with pytest.raises(ValueError):
        DocumentCreate(
            exercice_id=EXERCICE_ID,
            type_document="ria",
            parent_id=PARENT_EPRD_ID,
            periode_observation_debut=date(2026, 6, 1),
            periode_observation_fin=date(2026, 3, 1),
        )


# ---------------------------------------------------------------------------
# create_document — DB-side checks
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_exercice_cross_tenant_404(monkeypatch, patch_run_in_thread):
    """If exercice belongs to another company, surface as 404 (no leak)."""
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: _make_exercice_lookup(company_id=OTHER_COMPANY),
    )
    payload = DocumentCreate(exercice_id=EXERCICE_ID, type_document="eprd")
    with pytest.raises(NotFoundError) as exc:
        await document_service.create_document(COMPANY, payload)
    assert exc.value.code == "exercice_not_found_for_document_create"


@pytest.mark.asyncio
async def test_create_dm_parent_wrong_type_409(monkeypatch, patch_run_in_thread):
    """DM with a non-EPRD parent → ConflictError ``parent_wrong_type``."""
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: _make_exercice_lookup(),
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "load_parent_for_clone",
        lambda _: {
            "id": PARENT_EPRD_ID,
            "company_id": COMPANY,
            "exercice_id": EXERCICE_ID,
            "type_document": "errd",  # wrong — must be eprd
        },
    )
    payload = DocumentCreate(
        exercice_id=EXERCICE_ID,
        type_document="dm",
        parent_id=PARENT_EPRD_ID,
    )
    with pytest.raises(ConflictError) as exc:
        await document_service.create_document(COMPANY, payload)
    assert exc.value.code == "parent_wrong_type"


@pytest.mark.asyncio
async def test_create_auto_cadre_and_crpp(monkeypatch, patch_run_in_thread):
    """Default cadre derived from (type, annee), CRPP denomination auto."""
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: _make_exercice_lookup(annee=2026),
    )
    captured: dict = {}

    def _create(**kwargs):
        captured.update(kwargs)
        return _make_doc_row(cadre_version=kwargs["cadre_version"])

    monkeypatch.setattr(document_service.document_repo, "create_with_default_crpp", _create)
    out = await document_service.create_document(
        COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="eprd")
    )
    assert out.cadre_version == "#EPRDHA-2026-01#"
    assert captured["cadre_version"] == "#EPRDHA-2026-01#"
    assert captured["crpp_denomination"] == "CRPP - EPRD 2026"
    assert captured["crpp_variante"] == "non_soumis_equil"


@pytest.mark.asyncio
async def test_create_errd_uses_previous_year_cadre(monkeypatch, patch_run_in_thread):
    """ERRD/ERCP cadres reference the prior year (executed exercise)."""
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: _make_exercice_lookup(annee=2026),
    )
    captured: dict = {}

    def _create(**kwargs):
        captured.update(kwargs)
        return _make_doc_row(type_document="errd", cadre_version=kwargs["cadre_version"])

    monkeypatch.setattr(document_service.document_repo, "create_with_default_crpp", _create)
    out = await document_service.create_document(
        COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="errd")
    )
    assert out.cadre_version == "#ERRDHA-2025-01#"


@pytest.mark.asyncio
async def test_create_explicit_cadre_override(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: _make_exercice_lookup(annee=2026),
    )
    captured: dict = {}

    def _create(**kwargs):
        captured.update(kwargs)
        return _make_doc_row(cadre_version=kwargs["cadre_version"])

    monkeypatch.setattr(document_service.document_repo, "create_with_default_crpp", _create)
    await document_service.create_document(
        COMPANY,
        DocumentCreate(
            exercice_id=EXERCICE_ID,
            type_document="eprd",
            cadre_version="#OVERRIDE#",
        ),
    )
    assert captured["cadre_version"] == "#OVERRIDE#"


# ---------------------------------------------------------------------------
# delete_document — brouillon-only enforcement
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_delete_brouillon_ok(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(document_service.document_repo, "get_by_id", lambda _: _make_doc_row())
    monkeypatch.setattr(document_service.document_repo, "delete", lambda _: True)
    # No exception → success
    await document_service.delete_document(COMPANY, DOC_ID)


@pytest.mark.asyncio
async def test_delete_transmis_blocked(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        document_service.document_repo,
        "get_by_id",
        lambda _: _make_doc_row(statut="transmis"),
    )
    with pytest.raises(ConflictError) as exc:
        await document_service.delete_document(COMPANY, DOC_ID)
    assert exc.value.code == "document_not_brouillon"


@pytest.mark.asyncio
async def test_delete_cross_company_403(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        document_service.document_repo,
        "get_by_id",
        lambda _: _make_doc_row(company_id=OTHER_COMPANY),
    )
    with pytest.raises(CrossCompanyError):
        await document_service.delete_document(COMPANY, DOC_ID)


# ---------------------------------------------------------------------------
# update_document — metadata patch
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_update_happy(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(document_service.document_repo, "get_by_id", lambda _: _make_doc_row())
    monkeypatch.setattr(
        document_service.document_repo,
        "update",
        lambda doc_id, payload: _make_doc_row(**payload),
    )
    out = await document_service.update_document(DOC_ID, DocumentUpdate(cadre_version="#NEW#"))
    assert out.cadre_version == "#NEW#"


@pytest.mark.asyncio
async def test_update_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(document_service.document_repo, "get_by_id", lambda _: None)
    with pytest.raises(NotFoundError):
        await document_service.update_document(DOC_ID, DocumentUpdate())


# ---------------------------------------------------------------------------
# clone_document
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_clone_eprd_to_dm(monkeypatch, patch_run_in_thread):
    """Happy path : EPRD parent in same company, clone to DM."""
    monkeypatch.setattr(
        document_service.document_repo,
        "load_parent_for_clone",
        lambda _: {
            "id": PARENT_EPRD_ID,
            "company_id": COMPANY,
            "exercice_id": EXERCICE_ID,
            "type_document": "eprd",
            "statut": "brouillon",
        },
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: _make_exercice_lookup(annee=2026),
    )
    # Parent sans CRs → fallback create_with_default_crpp path
    monkeypatch.setattr(
        document_service.document_repo,
        "list_crs_of_document",
        lambda _: [],
    )
    captured: dict = {}

    def _create(**kwargs):
        captured.update(kwargs)
        return _make_doc_row(
            type_document="dm",
            cadre_version=kwargs["cadre_version"],
            parent_id=kwargs["parent_id"],
        )

    monkeypatch.setattr(document_service.document_repo, "create_with_default_crpp", _create)
    out = await document_service.clone_document(
        COMPANY, PARENT_EPRD_ID, DocumentClone(new_type="dm")
    )
    assert out.type_document == "dm"
    assert out.parent_id == PARENT_EPRD_ID
    assert captured["cadre_version"] == "#DMHA-2026-01#"
    assert captured["parent_id"] == PARENT_EPRD_ID


@pytest.mark.asyncio
async def test_clone_source_not_eprd(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        document_service.document_repo,
        "load_parent_for_clone",
        lambda _: {
            "id": PARENT_EPRD_ID,
            "company_id": COMPANY,
            "exercice_id": EXERCICE_ID,
            "type_document": "dm",  # wrong source type
            "statut": "brouillon",
        },
    )
    with pytest.raises(ConflictError) as exc:
        await document_service.clone_document(
            COMPANY, PARENT_EPRD_ID, DocumentClone(new_type="ria")
        )
    assert exc.value.code == "clone_source_wrong_type"


@pytest.mark.asyncio
async def test_clone_source_cross_tenant(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        document_service.document_repo,
        "load_parent_for_clone",
        lambda _: {
            "id": PARENT_EPRD_ID,
            "company_id": OTHER_COMPANY,
            "exercice_id": EXERCICE_ID,
            "type_document": "eprd",
            "statut": "brouillon",
        },
    )
    with pytest.raises(NotFoundError):
        await document_service.clone_document(COMPANY, PARENT_EPRD_ID, DocumentClone(new_type="dm"))
