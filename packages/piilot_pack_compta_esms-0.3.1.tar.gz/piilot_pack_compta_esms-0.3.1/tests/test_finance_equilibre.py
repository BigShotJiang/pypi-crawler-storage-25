"""Unit tests for equilibre validator (§I.3, F.EQ.01 + F.EQ.02).

Cas réels DGCS sourcés ``S03`` p.29 quand pertinents."""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.models.finance import (
    EquilibreReelInput,
    EquilibreStrictInput,
)
from piilot_pack_compta_esms.services.finance import equilibre_validator

# ---------------------------------------------------------------------------
# choose_equilibre_type — D-016
# ---------------------------------------------------------------------------


def test_choose_reel_when_cpom():
    """ESMS inclus dans CPOM → équilibre réel (R.314-222 5 conditions)."""
    out = equilibre_validator.choose_equilibre_type(
        nature_juridique="PRIVE_NON_LUCRATIF",
        inclus_dans_cpom=True,
    )
    assert out == "reel"


def test_choose_strict_when_hors_cpom():
    """ESMS hors CPOM → équilibre strict (recettes == dépenses)."""
    out = equilibre_validator.choose_equilibre_type(
        nature_juridique="PRIVE_COMMERCIAL",
        inclus_dans_cpom=False,
    )
    assert out == "strict"


# ---------------------------------------------------------------------------
# validate_equilibre_reel — 5 conditions R.314-222
# ---------------------------------------------------------------------------


def _passing_input() -> EquilibreReelInput:
    return EquilibreReelInput(
        produits_tarif_saisis=Decimal("100000"),
        produits_tarif_notifies=Decimal("100000"),
        sincerite_commentee=True,
        capital_rembourse_via_emprunt=Decimal("0"),
        caf_n=Decimal("50000"),
        capital_a_rembourser_n=Decimal("40000"),
        recettes_affectees=Decimal("20000"),
        recettes_affectees_utilisees=Decimal("20000"),
    )


def test_equilibre_reel_all_passing():
    """Toutes les conditions OK → equilibre=True."""
    result = equilibre_validator.validate_equilibre_reel(_passing_input())
    assert result.equilibre is True
    assert result.evaluable_globalement is True
    assert result.nb_evaluables == 5
    assert result.nb_passees == 5
    assert all(c.passed for c in result.conditions)


def test_condition_1_ecart_produits_tarifs():
    """Condition 1 KO si produits_saisis != notifiés."""
    payload = _passing_input()
    payload.produits_tarif_saisis = Decimal("99000")
    result = equilibre_validator.validate_equilibre_reel(payload)
    assert result.equilibre is False
    c1 = next(c for c in result.conditions if c.id == 1)
    assert c1.evaluable is True
    assert c1.passed is False
    assert "Écart" in c1.message


def test_condition_2_sincerite_false():
    """Condition 2 KO si sincerite_commentee=False."""
    payload = _passing_input()
    payload.sincerite_commentee = False
    result = equilibre_validator.validate_equilibre_reel(payload)
    c2 = next(c for c in result.conditions if c.id == 2)
    assert c2.passed is False
    assert c2.evaluable is True


def test_condition_3_capital_couvert_par_emprunt():
    """Condition 3 KO si capital_rembourse_via_emprunt > 0."""
    payload = _passing_input()
    payload.capital_rembourse_via_emprunt = Decimal("5000")
    result = equilibre_validator.validate_equilibre_reel(payload)
    c3 = next(c for c in result.conditions if c.id == 3)
    assert c3.passed is False
    assert "couvert" in c3.message


def test_condition_4_caf_insuffisante():
    """Condition 4 KO si CAF < capital_à_rembourser_N."""
    payload = _passing_input()
    payload.caf_n = Decimal("30000")
    payload.capital_a_rembourser_n = Decimal("40000")
    result = equilibre_validator.validate_equilibre_reel(payload)
    c4 = next(c for c in result.conditions if c.id == 4)
    assert c4.passed is False
    assert "insuffisante" in c4.message


def test_condition_5_recettes_affectees_non_utilisees():
    """Condition 5 KO si recettes affectées != utilisées."""
    payload = _passing_input()
    payload.recettes_affectees_utilisees = Decimal("15000")
    result = equilibre_validator.validate_equilibre_reel(payload)
    c5 = next(c for c in result.conditions if c.id == 5)
    assert c5.passed is False
    assert "Solde" in c5.message


def test_partial_input_not_evaluable_globally():
    """Input incomplet (CAF manquante) → evaluable_globalement=False.
    D-034 — transition BROUILLON → TRANSMIS bloquée tant que tout n'est
    pas évalué."""
    payload = _passing_input()
    payload.caf_n = None
    result = equilibre_validator.validate_equilibre_reel(payload)
    assert result.evaluable_globalement is False
    assert result.equilibre is False
    c4 = next(c for c in result.conditions if c.id == 4)
    assert c4.evaluable is False


def test_empty_input_no_evaluable_conditions():
    """Aucun input fourni → 0 conditions évaluables, verdict bloqué."""
    result = equilibre_validator.validate_equilibre_reel(EquilibreReelInput())
    assert result.nb_evaluables == 0
    assert result.evaluable_globalement is False
    assert result.equilibre is False


# ---------------------------------------------------------------------------
# validate_equilibre_strict — F.EQ.02
# ---------------------------------------------------------------------------


def test_strict_happy():
    """Recettes == dépenses → équilibre strict OK."""
    out = equilibre_validator.validate_equilibre_strict(
        EquilibreStrictInput(
            total_recettes=Decimal("125000.00"),
            total_depenses=Decimal("125000.00"),
        )
    )
    assert out.equilibre is True
    assert out.ecart == Decimal("0")


def test_strict_tolerance_arrondi():
    """Tolérance 0.01 € (S03 p.29 — "à 0 € près, tolérance arrondis")."""
    out = equilibre_validator.validate_equilibre_strict(
        EquilibreStrictInput(
            total_recettes=Decimal("125000.005"),
            total_depenses=Decimal("125000.00"),
        )
    )
    assert out.equilibre is True


def test_strict_mismatch():
    """Recettes < dépenses au-delà de la tolérance → KO."""
    out = equilibre_validator.validate_equilibre_strict(
        EquilibreStrictInput(
            total_recettes=Decimal("124000"),
            total_depenses=Decimal("125000"),
        )
    )
    assert out.equilibre is False
    assert out.ecart == Decimal("-1000")
