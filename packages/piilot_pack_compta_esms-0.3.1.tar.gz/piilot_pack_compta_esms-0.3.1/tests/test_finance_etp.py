"""Tests for ETP calculator (§I.6, F.ETP.01 → F.ETP.05).

Cas réels CDC TER ``S20`` §16."""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.models.finance import (
    EtpGlobalInput,
    EtpImputationInput,
    EtpProrataInput,
)
from piilot_pack_compta_esms.services.finance import etp_calculator

# ---------------------------------------------------------------------------
# F.ETP.01 + F.ETP.02 + F.ETP.03
# ---------------------------------------------------------------------------


def test_etp_prorata_temps_plein_annee_complete():
    """Salarié temps plein (ETP=1) sur 12 mois complets : 1820h paie."""
    result = etp_calculator.compute_etp_prorata(
        EtpProrataInput(
            etp=Decimal("1"),
            heures_reelles_paie=Decimal("1820"),
            nbre_mois_travaille_saisi=Decimal("12"),
        )
    )
    # F.ETP.01 : 1820/1820 × 12 = 12
    assert result.nbre_mois_remun == Decimal("12")
    # F.ETP.02 : 1 × 12 / 12 = 1
    assert result.etp_prorata_remun == Decimal("1")
    # F.ETP.03 : 1 × 12 / 12 = 1
    assert result.etp_prorata_trav == Decimal("1")


def test_etp_prorata_temps_partiel():
    """Salarié temps partiel (ETP=0.5) sur 6 mois : 455h paie (= 0.25 année)."""
    result = etp_calculator.compute_etp_prorata(
        EtpProrataInput(
            etp=Decimal("0.5"),
            heures_reelles_paie=Decimal("455"),
            nbre_mois_travaille_saisi=Decimal("6"),
        )
    )
    # F.ETP.01 : 455/1820 × 12 = 3
    assert result.nbre_mois_remun == Decimal("3")
    # F.ETP.02 : 0.5 × 3 / 12 = 0.125
    assert result.etp_prorata_remun == Decimal("0.125")
    # F.ETP.03 : 0.5 × 6 / 12 = 0.25
    assert result.etp_prorata_trav == Decimal("0.25")


def test_etp_prorata_without_mois_travaille_saisi():
    """nbre_mois_travaille absent → F.ETP.03 retourné None."""
    result = etp_calculator.compute_etp_prorata(
        EtpProrataInput(
            etp=Decimal("1"),
            heures_reelles_paie=Decimal("910"),
        )
    )
    assert result.etp_prorata_trav is None
    assert result.nbre_mois_remun == Decimal("6")


# ---------------------------------------------------------------------------
# F.ETP.04
# ---------------------------------------------------------------------------


def test_etp_global_temps_plein():
    """1820.04h → ETP global = 1 exactement."""
    result = etp_calculator.compute_etp_global(
        EtpGlobalInput(heures_travaillees=Decimal("1820.04"))
    )
    assert result.etp_global == Decimal("1")


def test_etp_global_demi_temps():
    result = etp_calculator.compute_etp_global(EtpGlobalInput(heures_travaillees=Decimal("910.02")))
    assert result.etp_global == Decimal("0.5")


# ---------------------------------------------------------------------------
# F.ETP.05 — Imputation par section
# ---------------------------------------------------------------------------


def test_imputation_hds_100pct():
    """EHPAD H=40%, D=20%, S=40% → ETP=1 → 0.4 / 0.2 / 0.4."""
    result = etp_calculator.compute_etp_imputation(
        EtpImputationInput(
            etp_prorata_remun=Decimal("1"),
            taux_par_section={
                "H": Decimal("40"),
                "D": Decimal("20"),
                "S": Decimal("40"),
            },
        )
    )
    assert result.valide is True
    assert result.sum_taux_pct == Decimal("100")
    assert result.imputation_par_section["H"] == Decimal("0.40")
    assert result.imputation_par_section["D"] == Decimal("0.20")
    assert result.imputation_par_section["S"] == Decimal("0.40")


def test_imputation_sum_taux_invalide():
    """Σ taux ≠ 100% → valide=False, imputation calculée quand même."""
    result = etp_calculator.compute_etp_imputation(
        EtpImputationInput(
            etp_prorata_remun=Decimal("1"),
            taux_par_section={"H": Decimal("50"), "D": Decimal("30")},
        )
    )
    assert result.valide is False
    assert result.sum_taux_pct == Decimal("80")


def test_imputation_tolerance_arrondi():
    """Tolérance 0.001 sur Σ taux = 100%."""
    result = etp_calculator.compute_etp_imputation(
        EtpImputationInput(
            etp_prorata_remun=Decimal("1"),
            taux_par_section={
                "H": Decimal("33.334"),
                "D": Decimal("33.333"),
                "S": Decimal("33.333"),
            },
        )
    )
    # 33.334 + 33.333 + 33.333 = 100.000 → valide
    assert result.valide is True


def test_imputation_with_sea_section():
    """SEA = expérimentation 2026 EHPAD (forfait global unique D-085)."""
    result = etp_calculator.compute_etp_imputation(
        EtpImputationInput(
            etp_prorata_remun=Decimal("0.8"),
            taux_par_section={
                "H": Decimal("50"),
                "SEA": Decimal("50"),
            },
        )
    )
    assert result.valide is True
    assert result.imputation_par_section["SEA"] == Decimal("0.4")
