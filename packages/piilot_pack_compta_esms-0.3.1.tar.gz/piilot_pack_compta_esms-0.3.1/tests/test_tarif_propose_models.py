"""Pydantic tests for EPRD tarifs proposés — §BB v0.3.

Couvre :
* Literal allowed values (section × 4, statut × 5)
* Bornes (montant >= 0)
* Longueurs (libelle, motif, motif_rejet, valide_par)
* ``extra='forbid'``
* Update partiel + bulk item
* Validation report shape
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from uuid import uuid4

import pytest
from pydantic import ValidationError

from piilot_pack_compta_esms.models.tarif_propose import (
    TarifProposeBulkItem,
    TarifProposeCreate,
    TarifProposeUpdate,
    TarifSectionAggregate,
    TarifValidationReport,
)

_BASE_CREATE_KWARGS: dict = {
    "etablissement_id": uuid4(),
    "section": "HEBERGEMENT",
    "montant_propose": Decimal("75.50"),
}


# --------------------------------------------------------------------
# Section Literal (4 valeurs DGCS)
# --------------------------------------------------------------------


def test_section_accepts_4_dgcs_values():
    for value in ("HEBERGEMENT", "DEPENDANCE", "SOINS", "SOINS_AUTONOMIE_SEA"):
        obj = TarifProposeCreate(**{**_BASE_CREATE_KWARGS, "section": value})
        assert obj.section == value


def test_section_rejects_unknown():
    with pytest.raises(ValidationError, match="section"):
        TarifProposeCreate(**{**_BASE_CREATE_KWARGS, "section": "REPAS"})


# --------------------------------------------------------------------
# montant_propose bornes
# --------------------------------------------------------------------


def test_montant_propose_accepts_zero():
    obj = TarifProposeCreate(**{**_BASE_CREATE_KWARGS, "montant_propose": Decimal("0")})
    assert obj.montant_propose == Decimal("0")


def test_montant_propose_accepts_positive_decimal():
    obj = TarifProposeCreate(**{**_BASE_CREATE_KWARGS, "montant_propose": Decimal("123.45")})
    assert obj.montant_propose == Decimal("123.45")


def test_montant_propose_rejects_negative():
    with pytest.raises(ValidationError, match="montant_propose"):
        TarifProposeCreate(**{**_BASE_CREATE_KWARGS, "montant_propose": Decimal("-1")})


# --------------------------------------------------------------------
# Optional fields + length bounds
# --------------------------------------------------------------------


def test_libelle_max_255():
    obj = TarifProposeCreate(**_BASE_CREATE_KWARGS, libelle="x" * 255)
    assert len(obj.libelle or "") == 255


def test_libelle_rejects_256():
    with pytest.raises(ValidationError, match="libelle"):
        TarifProposeCreate(**_BASE_CREATE_KWARGS, libelle="x" * 256)


def test_motif_max_500():
    obj = TarifProposeCreate(**_BASE_CREATE_KWARGS, motif="m" * 500)
    assert len(obj.motif or "") == 500


def test_motif_rejects_501():
    with pytest.raises(ValidationError, match="motif"):
        TarifProposeCreate(**_BASE_CREATE_KWARGS, motif="m" * 501)


def test_libelle_rejects_pipe():
    with pytest.raises(ValidationError):
        TarifProposeCreate(**_BASE_CREATE_KWARGS, libelle="bad|name")


def test_motif_rejects_pipe():
    with pytest.raises(ValidationError):
        TarifProposeCreate(**_BASE_CREATE_KWARGS, motif="bad|motif")


# --------------------------------------------------------------------
# extra='forbid' — both Create and Update
# --------------------------------------------------------------------


def test_create_rejects_unknown_field():
    with pytest.raises(ValidationError, match="ghost"):
        TarifProposeCreate(**_BASE_CREATE_KWARGS, ghost="x")  # type: ignore


def test_update_rejects_unknown_field():
    with pytest.raises(ValidationError, match="ghost"):
        TarifProposeUpdate(ghost="x")  # type: ignore


def test_create_rejects_atc_fields():
    """Create body doit refuser les champs ATC — on passe par PATCH
    pour les renseigner."""
    with pytest.raises(ValidationError):
        TarifProposeCreate(
            **_BASE_CREATE_KWARGS,
            statut="VALIDE_ARS",  # type: ignore
        )


# --------------------------------------------------------------------
# Update partial
# --------------------------------------------------------------------


def test_update_empty_payload_valid():
    obj = TarifProposeUpdate()
    assert obj.model_dump(exclude_none=True) == {}


def test_update_can_patch_montant_notifie_only():
    obj = TarifProposeUpdate(montant_notifie=Decimal("80.00"))
    assert obj.montant_notifie == Decimal("80.00")
    assert obj.montant_propose is None
    assert obj.statut is None


def test_update_statut_accepts_5_values():
    for s in ("PROPOSE", "VALIDE_ARS", "VALIDE_CD", "VALIDE_TRIPARTITE", "REJETE"):
        obj = TarifProposeUpdate(statut=s)
        assert obj.statut == s


def test_update_statut_rejects_unknown():
    with pytest.raises(ValidationError, match="statut"):
        TarifProposeUpdate(statut="EN_INSTRUCTION")


def test_update_montant_notifie_rejects_negative():
    with pytest.raises(ValidationError, match="montant_notifie"):
        TarifProposeUpdate(montant_notifie=Decimal("-1"))


def test_update_motif_rejet_max_1000():
    obj = TarifProposeUpdate(motif_rejet="r" * 1000)
    assert len(obj.motif_rejet or "") == 1000


def test_update_motif_rejet_rejects_1001():
    with pytest.raises(ValidationError, match="motif_rejet"):
        TarifProposeUpdate(motif_rejet="r" * 1001)


def test_update_valide_par_max_255():
    obj = TarifProposeUpdate(valide_par="v" * 255)
    assert len(obj.valide_par or "") == 255


def test_update_date_validation_accepts_date():
    obj = TarifProposeUpdate(date_validation=date(2026, 1, 15))
    assert obj.date_validation == date(2026, 1, 15)


# --------------------------------------------------------------------
# Bulk item
# --------------------------------------------------------------------


def test_bulk_item_minimal():
    item = TarifProposeBulkItem(
        etablissement_id=uuid4(),
        section="DEPENDANCE",
        montant_propose=Decimal("12.50"),
    )
    assert item.section == "DEPENDANCE"


def test_bulk_item_rejects_atc_fields():
    """Le bulk-upsert ne touche pas aux champs ATC — refuse statut."""
    with pytest.raises(ValidationError):
        TarifProposeBulkItem(
            etablissement_id=uuid4(),
            section="DEPENDANCE",
            montant_propose=Decimal("1"),
            statut="VALIDE_ARS",  # type: ignore
        )


def test_bulk_item_montant_propose_required():
    with pytest.raises(ValidationError):
        TarifProposeBulkItem(  # type: ignore
            etablissement_id=uuid4(),
            section="DEPENDANCE",
        )


# --------------------------------------------------------------------
# Validation report shape
# --------------------------------------------------------------------


def test_section_aggregate_minimal():
    agg = TarifSectionAggregate(
        section="SOINS",
        rows_count=2,
        total_propose=Decimal("100"),
        total_notifie=Decimal("105"),
        ecart=Decimal("5"),
        all_validated_tripartite=True,
    )
    assert agg.section == "SOINS"
    assert agg.ecart == Decimal("5")


def test_section_aggregate_allows_null_notifie():
    agg = TarifSectionAggregate(
        section="SOINS",
        rows_count=2,
        total_propose=Decimal("100"),
        total_notifie=None,
        ecart=None,
        all_validated_tripartite=False,
    )
    assert agg.total_notifie is None
    assert agg.ecart is None


def test_validation_report_aggregates_sections():
    report = TarifValidationReport(
        document_id=uuid4(),
        sections=[
            TarifSectionAggregate(
                section="HEBERGEMENT",
                rows_count=1,
                total_propose=Decimal("50"),
                total_notifie=Decimal("50"),
                ecart=Decimal("0"),
                all_validated_tripartite=True,
            ),
            TarifSectionAggregate(
                section="DEPENDANCE",
                rows_count=1,
                total_propose=Decimal("25"),
                total_notifie=None,
                ecart=None,
                all_validated_tripartite=False,
            ),
        ],
        total_rows=2,
        all_sections_tripartite=False,
        has_rejected_rows=False,
    )
    assert len(report.sections) == 2
    assert report.all_sections_tripartite is False
