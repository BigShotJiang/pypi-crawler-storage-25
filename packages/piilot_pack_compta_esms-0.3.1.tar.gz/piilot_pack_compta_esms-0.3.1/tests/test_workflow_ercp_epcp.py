"""Tests §X — workflow ERCP (ERRD-family) vs EPCP (EPRD-family).

KB22 §3.1 — ERCP a Affectation_Resultats → ERRD-family.
KB22 §3.3 — EPCP est prévisionnel, pas d'affectation → EPRD-family.

Couvre :

* ERCP suit le workflow ERRD : transmit → 'transmis' + set_affectation
  dispo depuis 'transmis'
* EPCP suit le workflow EPRD-family : transmit → 'en_instruction',
  approve/reject ARS+CD dispo, pas de set_affectation
* affectation_service refuse 422 sur EPCP (prévisionnel)
* affectation_service refuse 422 sur EPRD (prévisionnel)
* affectation_service accepte ERCP (réalisé sanitaire)
"""

from __future__ import annotations

from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.affectation import AffectationBulkRequest
from piilot_pack_compta_esms.models.workflow import WorkflowSnapshot
from piilot_pack_compta_esms.services import affectation_service
from piilot_pack_compta_esms.services import workflow_state_machine as sm
from piilot_pack_compta_esms.services.errors import ValidationError

COMPANY = uuid4()
DOC_ID = uuid4()


def _snap(*, type_document: str, statut: str = "brouillon", **overrides) -> WorkflowSnapshot:
    base = {
        "document_id": DOC_ID,
        "type_document": type_document,
        "statut": statut,
        "transmis_at": None,
        "executoire_at": None,
        "approuve_par_ars_at": None,
        "approuve_par_cd_at": None,
        "approuve_par_ars_user_id": None,
        "approuve_par_cd_user_id": None,
        "rejete_at": None,
        "rejete_par_autorite": None,
        "motif_rejet": None,
        "affectation_definie_at": None,
    }
    base.update(overrides)
    return WorkflowSnapshot.model_validate(base)


# ---------------------------------------------------------------------------
# ERCP suit ERRD-family
# ---------------------------------------------------------------------------


def test_ercp_workflow_is_errd_family() -> None:
    """sm.workflow_family('ercp') == 'errd' (§X)."""
    assert sm.workflow_family("ercp") == "errd"


def test_ercp_transmit_goes_to_transmis() -> None:
    """ERCP transmit → 'transmis' (pas 'en_instruction' comme EPRD)."""
    snap = _snap(type_document="ercp")
    assert sm.derive_target_statut(snap, action="transmit", autorite=None) == "transmis"


def test_ercp_set_affectation_allowed_from_transmis() -> None:
    """ERCP en 'transmis' → set_affectation dispo pour admin."""
    snap = _snap(type_document="ercp", statut="transmis")
    allowed, _ = sm.compute_allowed_actions(snap, role="admin")
    actions = {a.action for a in allowed}
    assert "set_affectation" in actions


def test_ercp_approve_not_applicable() -> None:
    """ERCP (ERRD-family) → pas d'approve (machine simplifiée D-023)."""
    snap = _snap(type_document="ercp", statut="transmis")
    _, blocked = sm.compute_allowed_actions(snap, role="admin")
    approve_block = next((b for b in blocked if b.action == "approve"), None)
    assert approve_block is not None
    assert approve_block.reason == "not_applicable_for_type"


# ---------------------------------------------------------------------------
# EPCP suit EPRD-family
# ---------------------------------------------------------------------------


def test_epcp_workflow_is_eprd_family() -> None:
    """sm.workflow_family('epcp') == 'eprd_family' (§X)."""
    assert sm.workflow_family("epcp") == "eprd_family"


def test_epcp_transmit_goes_to_en_instruction() -> None:
    """EPCP transmit → 'en_instruction' (double validation ATC)."""
    snap = _snap(type_document="epcp")
    assert sm.derive_target_statut(snap, action="transmit", autorite=None) == "en_instruction"


def test_epcp_set_affectation_not_applicable() -> None:
    """EPCP est prévisionnel — pas d'affectation."""
    snap = _snap(type_document="epcp", statut="transmis")
    _, blocked = sm.compute_allowed_actions(snap, role="admin")
    set_aff = next((b for b in blocked if b.action == "set_affectation"), None)
    assert set_aff is not None
    assert set_aff.reason == "not_applicable_for_type"


# ---------------------------------------------------------------------------
# Affectation refusée sur EPRD/EPCP, acceptée sur ERRD/ERCP
# ---------------------------------------------------------------------------


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.affectation_service.run_in_thread",
        _passthrough,
    )


def _ctx(type_document: str) -> dict:
    return {
        "id": DOC_ID,
        "type_document": type_document,
        "exercice_id": uuid4(),
        "og_id": uuid4(),
        "nature_juridique": "PRIVE_NON_LUCRATIF",
        "any_inclus_cpom": False,
    }


@pytest.mark.asyncio
async def test_affectation_refuses_eprd(monkeypatch, patch_run_in_thread):
    """EPRD est prévisionnel — affectation non-applicable."""
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "get_doc_affectation_context",
        lambda d, c: _ctx("eprd"),
    )

    with pytest.raises(ValidationError) as exc:
        await affectation_service.put_affectations_bulk(
            COMPANY, DOC_ID, AffectationBulkRequest(items=[])
        )
    assert exc.value.code == "affectation_not_applicable_for_doc_type"


@pytest.mark.asyncio
async def test_affectation_refuses_epcp(monkeypatch, patch_run_in_thread):
    """EPCP est prévisionnel — affectation non-applicable."""
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "get_doc_affectation_context",
        lambda d, c: _ctx("epcp"),
    )

    with pytest.raises(ValidationError) as exc:
        await affectation_service.put_affectations_bulk(
            COMPANY, DOC_ID, AffectationBulkRequest(items=[])
        )
    assert exc.value.code == "affectation_not_applicable_for_doc_type"


@pytest.mark.asyncio
async def test_affectation_accepts_ercp_via_assert_helper(monkeypatch, patch_run_in_thread):
    """ERCP est réalisé sanitaire — KB22 §3.1 confirme onglet Affectation_Resultats."""
    # On teste juste l'assertion helper directement — le PUT bulk a
    # beaucoup d'autres dépendances (CR loading, variante deduce, etc).
    affectation_service._assert_affectation_applicable(_ctx("ercp"), DOC_ID)
    affectation_service._assert_affectation_applicable(_ctx("errd"), DOC_ID)
    # Pas d'exception — OK
