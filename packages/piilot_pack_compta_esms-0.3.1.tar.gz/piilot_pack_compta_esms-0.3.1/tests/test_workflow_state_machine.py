"""Tests purs sur :mod:`workflow_state_machine` (§S).

Ne fait pas d'IO — exerce le mapping ERRD vs EPRD-family + les
permissions par rôle + le calcul de ``statut_after`` (double
validation, auto-flip executoire).
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.workflow import WorkflowSnapshot
from piilot_pack_compta_esms.services import workflow_state_machine as sm


def _snap(
    *,
    type_document: str = "errd",
    statut: str = "brouillon",
    ars_at: datetime | None = None,
    cd_at: datetime | None = None,
) -> WorkflowSnapshot:
    return WorkflowSnapshot(
        document_id=uuid4(),
        type_document=type_document,
        statut=statut,
        transmis_at=None,
        executoire_at=None,
        approuve_par_ars_at=ars_at,
        approuve_par_cd_at=cd_at,
        approuve_par_ars_user_id=None,
        approuve_par_cd_user_id=None,
        rejete_at=None,
        rejete_par_autorite=None,
        motif_rejet=None,
        affectation_definie_at=None,
    )


# ---------------------------------------------------------------------------
# workflow_family + double validation state
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "type_doc, expected",
    [
        ("errd", "errd"),
        ("ercp", "errd"),  # §X — ERCP est un réalisé sanitaire avec affectation
        ("eprd", "eprd_family"),
        ("dm", "eprd_family"),
        ("ria", "eprd_family"),
        ("avenant", "eprd_family"),
        ("epcp", "eprd_family"),  # §X — EPCP prévisionnel sanitaire, pas d'affectation
    ],
)
def test_workflow_family_mapping(type_doc: str, expected: str) -> None:
    assert sm.workflow_family(type_doc) == expected


def test_workflow_family_unknown_raises() -> None:
    with pytest.raises(ValueError, match="unknown_workflow_family"):
        sm.workflow_family("unknown_type")


def test_double_validation_state_errd_not_applicable() -> None:
    snap = _snap(type_document="errd")
    state = sm.build_double_validation_state(snap)
    assert state.applicable is False
    assert state.approuve_par_ars_at is None
    assert state.approuve_par_cd_at is None


def test_double_validation_state_eprd_applicable_no_approvals() -> None:
    snap = _snap(type_document="eprd")
    state = sm.build_double_validation_state(snap)
    assert state.applicable is True
    assert state.approuve_par_ars_at is None


def test_double_validation_state_eprd_with_ars() -> None:
    now = datetime.now(tz=UTC)
    snap = _snap(type_document="eprd", statut="en_instruction", ars_at=now)
    state = sm.build_double_validation_state(snap)
    assert state.applicable is True
    assert state.approuve_par_ars_at == now
    assert state.approuve_par_cd_at is None


# ---------------------------------------------------------------------------
# ERRD machine — brouillon → transmis → affectation_definie
# ---------------------------------------------------------------------------


def test_errd_brouillon_allows_transmit_for_builder() -> None:
    snap = _snap(type_document="errd", statut="brouillon")
    allowed, _ = sm.compute_allowed_actions(snap, role="builder")
    actions = {a.action for a in allowed}
    assert "transmit" in actions
    # ERRD has no approve/reject in any state
    assert "approve" not in actions
    assert "reject" not in actions
    # set_affectation only opens after transmit
    assert "set_affectation" not in actions


def test_errd_brouillon_user_role_blocked_transmit() -> None:
    snap = _snap(type_document="errd", statut="brouillon")
    allowed, blocked = sm.compute_allowed_actions(snap, role="user")
    assert not allowed
    reasons = {(b.action, b.reason) for b in blocked}
    assert ("transmit", "role_required") in reasons


def test_errd_transmis_allows_set_affectation_for_admin() -> None:
    snap = _snap(type_document="errd", statut="transmis")
    allowed, _ = sm.compute_allowed_actions(snap, role="admin")
    actions = {a.action for a in allowed}
    assert "set_affectation" in actions
    # transmit refused — already past it
    assert "transmit" not in actions


def test_errd_transmis_set_affectation_blocked_for_builder() -> None:
    snap = _snap(type_document="errd", statut="transmis")
    allowed, blocked = sm.compute_allowed_actions(snap, role="builder")
    assert not allowed  # builder cannot set_affectation
    reasons = {(b.action, b.reason) for b in blocked}
    assert ("set_affectation", "role_required") in reasons


def test_errd_affectation_definie_terminal() -> None:
    snap = _snap(type_document="errd", statut="affectation_definie")
    allowed, blocked = sm.compute_allowed_actions(snap, role="admin")
    assert not allowed
    # All actions are blocked from this state
    blocked_actions = {b.action for b in blocked}
    assert blocked_actions == {"transmit", "approve", "reject", "set_affectation"}


# ---------------------------------------------------------------------------
# EPRD-family machine — brouillon → en_instruction → executoire | rejete
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("type_doc", ["eprd", "dm", "ria", "avenant", "epcp"])
def test_eprd_family_brouillon_transmit_allowed(type_doc: str) -> None:
    snap = _snap(type_document=type_doc, statut="brouillon")
    allowed, _ = sm.compute_allowed_actions(snap, role="builder")
    actions = {a.action for a in allowed}
    assert "transmit" in actions
    # No set_affectation for EPRD-family
    assert "set_affectation" not in actions


def test_eprd_en_instruction_allows_both_approve_and_both_reject() -> None:
    snap = _snap(type_document="eprd", statut="en_instruction")
    allowed, _ = sm.compute_allowed_actions(snap, role="admin")
    pairs = {(a.action, a.autorite) for a in allowed}
    assert ("approve", "ars") in pairs
    assert ("approve", "cd") in pairs
    assert ("reject", "ars") in pairs
    assert ("reject", "cd") in pairs


def test_eprd_en_instruction_ars_already_approved_blocks_ars_only() -> None:
    """ARS déjà OK : on ne peut plus approuver pour ARS, mais on peut
    encore pour CD ; on peut aussi rejeter au nom des 2 (rejet
    global = ARS ou CD)."""
    now = datetime.now(tz=UTC)
    snap = _snap(type_document="eprd", statut="en_instruction", ars_at=now)
    allowed, blocked = sm.compute_allowed_actions(snap, role="admin")
    pairs_allowed = {(a.action, a.autorite) for a in allowed}
    assert ("approve", "ars") not in pairs_allowed
    assert ("approve", "cd") in pairs_allowed
    assert ("reject", "ars") in pairs_allowed
    assert ("reject", "cd") in pairs_allowed
    pairs_blocked = {(b.action, b.autorite, b.reason) for b in blocked}
    assert ("approve", "ars", "already_approved") in pairs_blocked


def test_eprd_en_instruction_user_role_blocks_approve_and_reject() -> None:
    snap = _snap(type_document="eprd", statut="en_instruction")
    allowed, blocked = sm.compute_allowed_actions(snap, role="user")
    assert not allowed
    reasons = {(b.action, b.autorite, b.reason) for b in blocked}
    assert ("approve", "ars", "role_required") in reasons
    assert ("approve", "cd", "role_required") in reasons


def test_eprd_executoire_terminal() -> None:
    snap = _snap(type_document="eprd", statut="executoire")
    allowed, _ = sm.compute_allowed_actions(snap, role="admin")
    assert not allowed


def test_eprd_rejete_terminal() -> None:
    snap = _snap(type_document="eprd", statut="rejete")
    allowed, _ = sm.compute_allowed_actions(snap, role="admin")
    assert not allowed


# ---------------------------------------------------------------------------
# can_apply — guards spécifiques
# ---------------------------------------------------------------------------


def test_can_apply_transmit_errd_brouillon_builder() -> None:
    snap = _snap(type_document="errd", statut="brouillon")
    ok, reason = sm.can_apply(snap, action="transmit", autorite=None, role="builder")
    assert ok is True
    assert reason is None


def test_can_apply_transmit_already_transmis_refused() -> None:
    snap = _snap(type_document="errd", statut="transmis")
    ok, reason = sm.can_apply(snap, action="transmit", autorite=None, role="builder")
    assert ok is False
    assert reason == "transition_not_allowed_from_statut"


def test_can_apply_set_affectation_on_eprd_refused() -> None:
    snap = _snap(type_document="eprd", statut="transmis")
    ok, reason = sm.can_apply(snap, action="set_affectation", autorite=None, role="admin")
    assert ok is False
    assert reason == "not_applicable_for_type"


def test_can_apply_approve_on_errd_refused() -> None:
    snap = _snap(type_document="errd", statut="transmis")
    ok, reason = sm.can_apply(snap, action="approve", autorite="ars", role="admin")
    assert ok is False
    assert reason == "not_applicable_for_type"


def test_can_apply_approve_requires_autorite() -> None:
    snap = _snap(type_document="eprd", statut="en_instruction")
    ok, reason = sm.can_apply(snap, action="approve", autorite=None, role="admin")
    assert ok is False
    assert reason == "autorite_required"


def test_can_apply_reject_requires_autorite() -> None:
    snap = _snap(type_document="eprd", statut="en_instruction")
    ok, reason = sm.can_apply(snap, action="reject", autorite=None, role="admin")
    assert ok is False
    assert reason == "autorite_required"


def test_can_apply_approve_already_approved_refused() -> None:
    now = datetime.now(tz=UTC)
    snap = _snap(type_document="eprd", statut="en_instruction", ars_at=now)
    ok, reason = sm.can_apply(snap, action="approve", autorite="ars", role="admin")
    assert ok is False
    assert reason == "already_approved"


def test_can_apply_approve_other_autorite_ok_after_one_validates() -> None:
    """ARS a approuvé — CD peut encore approuver."""
    now = datetime.now(tz=UTC)
    snap = _snap(type_document="eprd", statut="en_instruction", ars_at=now)
    ok, reason = sm.can_apply(snap, action="approve", autorite="cd", role="admin")
    assert ok is True
    assert reason is None


# ---------------------------------------------------------------------------
# derive_target_statut — résultats
# ---------------------------------------------------------------------------


def test_derive_transmit_errd_goes_transmis() -> None:
    snap = _snap(type_document="errd", statut="brouillon")
    assert sm.derive_target_statut(snap, action="transmit", autorite=None) == "transmis"


@pytest.mark.parametrize("type_doc", ["eprd", "dm", "ria", "avenant", "epcp"])
def test_derive_transmit_eprd_family_goes_en_instruction(type_doc: str) -> None:
    """Collapse ``transmis → en_instruction`` : on saute direct."""
    snap = _snap(type_document=type_doc, statut="brouillon")
    target = sm.derive_target_statut(snap, action="transmit", autorite=None)
    assert target == "en_instruction"


def test_derive_set_affectation_to_affectation_definie() -> None:
    snap = _snap(type_document="errd", statut="transmis")
    assert (
        sm.derive_target_statut(snap, action="set_affectation", autorite=None)
        == "affectation_definie"
    )


def test_derive_reject_to_rejete() -> None:
    snap = _snap(type_document="eprd", statut="en_instruction")
    assert sm.derive_target_statut(snap, action="reject", autorite="ars") == "rejete"


def test_derive_approve_ars_alone_stays_en_instruction() -> None:
    snap = _snap(type_document="eprd", statut="en_instruction")
    assert sm.derive_target_statut(snap, action="approve", autorite="ars") == "en_instruction"


def test_derive_approve_cd_when_ars_already_flips_executoire() -> None:
    now = datetime.now(tz=UTC)
    snap = _snap(type_document="eprd", statut="en_instruction", ars_at=now)
    target = sm.derive_target_statut(snap, action="approve", autorite="cd")
    assert target == "executoire"


def test_derive_approve_ars_when_cd_already_flips_executoire() -> None:
    now = datetime.now(tz=UTC)
    snap = _snap(type_document="eprd", statut="en_instruction", cd_at=now)
    target = sm.derive_target_statut(snap, action="approve", autorite="ars")
    assert target == "executoire"
