"""Tests §Z + §S — guard transmit refuse 422 si KO bloquant.

D-034 : la transition `BROUILLON → TRANSMIS` doit refuser si l'un des
3 contrôles C-001/C-002/C-003 (`is_bloquant_transition=true`) retourne
KO.

Couvre :

* Transition transmit sans KO bloquant → passe
* Transition transmit avec C-001 KO → 422 transition_blocked_by_failed_control
* Transition transmit avec C-001+C-002 KO → 422, codes_ko listés
* Transition non-transmit (approve, set_affectation) → pas de guard
* run_bloquants n'est appelé que sur transmit
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.workflow import TransitionRequest
from piilot_pack_compta_esms.services import controles_service, workflow_service
from piilot_pack_compta_esms.services.errors import ValidationError

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.workflow_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def workflow_repo_setup(monkeypatch):
    """Mock workflow_repo pour que _load_snapshot retourne un snapshot ERRD brouillon."""
    from piilot_pack_compta_esms.repositories import workflow_repo

    snapshot_row = {
        "id": DOC_ID,
        "company_id": COMPANY,
        "type_document": "errd",
        "statut": "brouillon",
        "transmis_at": None,
        "executoire_at": None,
        "approuve_par_ars_at": None,
        "approuve_par_cd_at": None,
        "approuve_par_ars_user_id": None,
        "approuve_par_cd_user_id": None,
        "rejete_at": None,
        "rejete_par_autorite": None,
        "motif_rejet": None,
        "affectation_definie_at": None,
    }
    monkeypatch.setattr(workflow_repo, "load_snapshot", lambda d: snapshot_row)
    # Mock load_equilibre_context to skip _resolve_equilibre_mode side effects
    monkeypatch.setattr(
        workflow_repo,
        "load_equilibre_context",
        lambda d: None,
    )
    monkeypatch.setattr(
        workflow_repo,
        "apply_transition",
        lambda **kwargs: {**snapshot_row, "statut": kwargs["patch"]["statut"]},
    )


# ---------------------------------------------------------------------------
# Transmit sans KO bloquant
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_transmit_no_bloquant_ko_passes(
    monkeypatch, patch_run_in_thread, workflow_repo_setup
):
    """run_bloquants retourne [] → transition passe."""

    async def _no_ko(*args, **kwargs):
        return []

    monkeypatch.setattr(controles_service, "run_bloquants", _no_ko)

    out = await workflow_service.apply_transition(
        document_id=DOC_ID,
        payload=TransitionRequest(action="transmit"),
        company_id=COMPANY,
        user_id=USER,
        role="builder",
    )
    assert out.statut_after == "transmis"


# ---------------------------------------------------------------------------
# Transmit avec C-001 KO
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_transmit_c_001_ko_blocked(monkeypatch, patch_run_in_thread, workflow_repo_setup):
    """run_bloquants retourne C-001 KO → 422."""

    async def _ko_c001(*args, **kwargs):
        return [
            {
                "code": "C-001",
                "statut": "ko",
                "severite_observee": "error",
                "valeurs_observees": {"actif": 100.0, "passif": 50.0},
                "message_humain": "Bilan déséquilibré",
            }
        ]

    monkeypatch.setattr(controles_service, "run_bloquants", _ko_c001)

    with pytest.raises(ValidationError) as exc:
        await workflow_service.apply_transition(
            document_id=DOC_ID,
            payload=TransitionRequest(action="transmit"),
            company_id=COMPANY,
            user_id=USER,
            role="builder",
        )
    assert exc.value.code == "transition_blocked_by_failed_control"
    assert "C-001" in str(exc.value)


@pytest.mark.asyncio
async def test_transmit_multiple_bloquants_listed(
    monkeypatch, patch_run_in_thread, workflow_repo_setup
):
    """Plusieurs KO bloquants → 422 avec tous les codes listés."""

    async def _ko_multi(*args, **kwargs):
        return [
            {
                "code": "C-001",
                "statut": "ko",
                "severite_observee": "error",
                "valeurs_observees": {},
                "message_humain": None,
            },
            {
                "code": "C-002",
                "statut": "ko",
                "severite_observee": "error",
                "valeurs_observees": {},
                "message_humain": None,
            },
        ]

    monkeypatch.setattr(controles_service, "run_bloquants", _ko_multi)

    with pytest.raises(ValidationError) as exc:
        await workflow_service.apply_transition(
            document_id=DOC_ID,
            payload=TransitionRequest(action="transmit"),
            company_id=COMPANY,
            user_id=USER,
            role="builder",
        )
    message = str(exc.value)
    assert "C-001" in message
    assert "C-002" in message


# ---------------------------------------------------------------------------
# Actions non-transmit ne déclenchent pas le guard
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_set_affectation_does_not_call_run_bloquants(
    monkeypatch, patch_run_in_thread, workflow_repo_setup
):
    """Transition set_affectation (post-transmit) → run_bloquants pas appelé."""
    calls = []

    async def _track(*args, **kwargs):
        calls.append(1)
        return []

    monkeypatch.setattr(controles_service, "run_bloquants", _track)
    # Set snapshot statut='transmis' pour autoriser set_affectation
    from piilot_pack_compta_esms.repositories import workflow_repo

    monkeypatch.setattr(
        workflow_repo,
        "load_snapshot",
        lambda d: {
            "id": DOC_ID,
            "company_id": COMPANY,
            "type_document": "errd",
            "statut": "transmis",
            "transmis_at": datetime.now(UTC),
            "executoire_at": None,
            "approuve_par_ars_at": None,
            "approuve_par_cd_at": None,
            "approuve_par_ars_user_id": None,
            "approuve_par_cd_user_id": None,
            "rejete_at": None,
            "rejete_par_autorite": None,
            "motif_rejet": None,
            "affectation_definie_at": None,
        },
    )

    await workflow_service.apply_transition(
        document_id=DOC_ID,
        payload=TransitionRequest(action="set_affectation"),
        company_id=COMPANY,
        user_id=USER,
        role="admin",
    )
    assert calls == []
