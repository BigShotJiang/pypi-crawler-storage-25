"""Tests §Y service cles_repartition_service (D-057).

Couvre :

* validation Σ taux = 100 ± 0.01 (Pydantic)
* validation Σ != 100 → ValueError au parse
* CHECK chaque taux ∈ [0, 100]
* 404 ets cross-tenant
* 409 duplicate (natural key)
* 404 si update sur key inexistante
* WARN year-diff loggé quand taux N != N-1
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from pydantic import ValidationError as PydanticValidationError

from piilot_pack_compta_esms.models.cles_repartition import (
    ClesRepartitionBulkUpsertItem,
    ClesRepartitionCreate,
    ClesRepartitionUpdate,
)
from piilot_pack_compta_esms.services import cles_repartition_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
)

COMPANY = uuid4()
ETS = uuid4()
KEY_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.cles_repartition_service.run_in_thread",
        _passthrough,
    )


def _make_row(**overrides):
    base = {
        "id": KEY_ID,
        "company_id": COMPANY,
        "etablissement_id": ETS,
        "compte_m22bis": "60222",
        "exercice_annee": 2026,
        "taux_hebergement": Decimal("50"),
        "taux_dependance": Decimal("20"),
        "taux_soins": Decimal("30"),
        "taux_soins_autonomie": Decimal("0"),
        "source": None,
        "notes": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Pydantic validation
# ---------------------------------------------------------------------------


def test_create_pydantic_sum_100_ok() -> None:
    """Σ = 100 → parse OK."""
    ClesRepartitionCreate(
        etablissement_id=ETS,
        compte_m22bis="60222",
        exercice_annee=2026,
        taux_hebergement=Decimal("50"),
        taux_dependance=Decimal("30"),
        taux_soins=Decimal("20"),
        taux_soins_autonomie=Decimal("0"),
    )


def test_create_pydantic_sum_not_100_rejected() -> None:
    """Σ = 90 → Pydantic refuse au parse."""
    with pytest.raises(PydanticValidationError) as exc:
        ClesRepartitionCreate(
            etablissement_id=ETS,
            compte_m22bis="60222",
            exercice_annee=2026,
            taux_hebergement=Decimal("50"),
            taux_dependance=Decimal("30"),
            taux_soins=Decimal("10"),  # 90 total
            taux_soins_autonomie=Decimal("0"),
        )
    assert "taux_sum_must_be_100" in str(exc.value)


def test_create_pydantic_tolerance_001() -> None:
    """99.99 → accepté ; 99.98 → refusé."""
    ClesRepartitionCreate(
        etablissement_id=ETS,
        compte_m22bis="60222",
        exercice_annee=2026,
        taux_hebergement=Decimal("33.33"),
        taux_dependance=Decimal("33.33"),
        taux_soins=Decimal("33.33"),
        taux_soins_autonomie=Decimal("0"),
    )
    with pytest.raises(PydanticValidationError):
        ClesRepartitionCreate(
            etablissement_id=ETS,
            compte_m22bis="60222",
            exercice_annee=2026,
            taux_hebergement=Decimal("33"),
            taux_dependance=Decimal("33"),
            taux_soins=Decimal("33"),
            taux_soins_autonomie=Decimal("0"),  # 99 total
        )


def test_update_pydantic_partial_taux_rejected() -> None:
    """Patch partiel (1 seul taux) → Pydantic refuse."""
    with pytest.raises(PydanticValidationError) as exc:
        ClesRepartitionUpdate(taux_hebergement=Decimal("70"))
    assert "taux_must_be_all_or_none" in str(exc.value)


def test_update_pydantic_source_only_ok() -> None:
    """Patch uniquement source/notes (sans taux) → OK."""
    ClesRepartitionUpdate(source="CPOM 2024-2028", notes="ajustement marge")


def test_bulk_upsert_item_validates_sum() -> None:
    """Items du batch portent les mêmes contraintes Σ."""
    with pytest.raises(PydanticValidationError):
        ClesRepartitionBulkUpsertItem(
            compte_m22bis="60222",
            exercice_annee=2026,
            taux_hebergement=Decimal("50"),
            taux_dependance=Decimal("30"),
            taux_soins=Decimal("10"),
            taux_soins_autonomie=Decimal("0"),
        )


# ---------------------------------------------------------------------------
# Service — guards
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_404_ets_cross_tenant(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "etablissement_belongs_to_company",
        lambda ets, co: False,
    )
    with pytest.raises(NotFoundError) as exc:
        await cles_repartition_service.list_cles_repartition(ETS, COMPANY)
    assert exc.value.code == "etablissement_not_found"


@pytest.mark.asyncio
async def test_create_etablissement_id_mismatch_409(monkeypatch, patch_run_in_thread):
    """payload.etablissement_id != URL etablissement_id → 409."""
    payload = ClesRepartitionCreate(
        etablissement_id=uuid4(),  # autre ETS
        compte_m22bis="60222",
        exercice_annee=2026,
        taux_hebergement=Decimal("50"),
        taux_dependance=Decimal("30"),
        taux_soins=Decimal("20"),
        taux_soins_autonomie=Decimal("0"),
    )
    with pytest.raises(ConflictError) as exc:
        await cles_repartition_service.create_cle(COMPANY, ETS, payload)
    assert exc.value.code == "etablissement_id_mismatch"


@pytest.mark.asyncio
async def test_create_duplicate_409(monkeypatch, patch_run_in_thread):
    """Clé déjà existante sur (ets, compte, annee) → 409."""
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "etablissement_belongs_to_company",
        lambda ets, co: True,
    )
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "find_by_natural_key",
        lambda ets, compte, annee: _make_row(),
    )
    payload = ClesRepartitionCreate(
        etablissement_id=ETS,
        compte_m22bis="60222",
        exercice_annee=2026,
        taux_hebergement=Decimal("50"),
        taux_dependance=Decimal("30"),
        taux_soins=Decimal("20"),
        taux_soins_autonomie=Decimal("0"),
    )
    with pytest.raises(ConflictError) as exc:
        await cles_repartition_service.create_cle(COMPANY, ETS, payload)
    assert exc.value.code == "cles_repartition_duplicate"


@pytest.mark.asyncio
async def test_create_happy_returns_row(monkeypatch, patch_run_in_thread):
    """Création OK → row complet renvoyé."""
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "etablissement_belongs_to_company",
        lambda ets, co: True,
    )
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "find_by_natural_key",
        lambda ets, compte, annee: None,
    )
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "find_n_minus_1",
        lambda ets, compte, annee: None,
    )
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "create",
        lambda co, payload: _make_row(),
    )

    payload = ClesRepartitionCreate(
        etablissement_id=ETS,
        compte_m22bis="60222",
        exercice_annee=2026,
        taux_hebergement=Decimal("50"),
        taux_dependance=Decimal("20"),
        taux_soins=Decimal("30"),
        taux_soins_autonomie=Decimal("0"),
    )
    out = await cles_repartition_service.create_cle(COMPANY, ETS, payload)
    assert out.id == KEY_ID


@pytest.mark.asyncio
async def test_create_logs_warn_year_diff(monkeypatch, patch_run_in_thread, caplog):
    """N-1 a des taux différents → WARN log."""
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "etablissement_belongs_to_company",
        lambda ets, co: True,
    )
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "find_by_natural_key",
        lambda ets, compte, annee: None,
    )
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "find_n_minus_1",
        lambda ets, compte, annee: {
            "taux_hebergement": Decimal("70"),  # N-1 diff
            "taux_dependance": Decimal("10"),
            "taux_soins": Decimal("20"),
            "taux_soins_autonomie": Decimal("0"),
        },
    )
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "create",
        lambda co, payload: _make_row(),
    )

    payload = ClesRepartitionCreate(
        etablissement_id=ETS,
        compte_m22bis="60222",
        exercice_annee=2026,
        taux_hebergement=Decimal("50"),
        taux_dependance=Decimal("20"),
        taux_soins=Decimal("30"),
        taux_soins_autonomie=Decimal("0"),
    )

    logger_name = "piilot_pack_compta_esms.services.cles_repartition_service"
    with caplog.at_level(logging.WARNING, logger=logger_name):
        await cles_repartition_service.create_cle(COMPANY, ETS, payload)
    assert any("stabilité année/année" in r.message for r in caplog.records)


@pytest.mark.asyncio
async def test_update_cross_company_403(monkeypatch, patch_run_in_thread):
    """Update sur clé d'une autre company → CrossCompanyError."""
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "get_by_id",
        lambda _: _make_row(company_id=uuid4()),
    )
    with pytest.raises(CrossCompanyError) as exc:
        await cles_repartition_service.update_cle(
            COMPANY, KEY_ID, ClesRepartitionUpdate(source="x")
        )
    assert exc.value.code == "cles_repartition_cross_company"


@pytest.mark.asyncio
async def test_delete_404_if_missing(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        cles_repartition_service.cles_repartition_repo,
        "get_by_id",
        lambda _: None,
    )
    with pytest.raises(NotFoundError) as exc:
        await cles_repartition_service.delete_cle(COMPANY, KEY_ID)
    assert exc.value.code == "cles_repartition_not_found"
