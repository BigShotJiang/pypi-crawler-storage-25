"""Tests §AA — engine + service + routes.

Couvre :

* engine handler crash → wrap NA defensive
* engine handler non-enregistré → NA
* registry contient les 23 ids (15 ERRD + 8 PGFP)
* service _summarize compteurs
* service compute_ratios 404 cross-tenant
* service compute_ratios skip PGFP pour ERRD doc_type
* service ratios_errd vide pour ERCP/EPCP (Q8)
* route GET 200 + filter
* route POST :recompute 200
"""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.ratios._base import (
    RATIO_HANDLERS,
    RatioContext,
    RatioResult,
)
from piilot_pack_compta_esms.ratios.engine import run_ids
from piilot_pack_compta_esms.routes import _limiter as limiter_module
from piilot_pack_compta_esms.routes import ratios as ratios_routes
from piilot_pack_compta_esms.services import ratios_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)


def _doc(type_document="errd"):
    return {
        "id": DOC_ID,
        "company_id": COMPANY,
        "type_document": type_document,
        "statut": "brouillon",
        "exercice_id": uuid4(),
        "cadre_version": "#ERRDHA-2025-01#",
        "parent_id": None,
        "periode_observation_debut": None,
        "periode_observation_fin": None,
        "transmis_at": None,
        "executoire_at": None,
        "transmis_par_user_id": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }


def _ctx(type_document="errd"):
    return RatioContext(
        document_id=DOC_ID,
        company_id=COMPANY,
        document=_doc(type_document=type_document),
    )


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


def test_registry_contains_15_errd_ids() -> None:
    """Les 15 ratios ERRD D-091 sont enregistrés."""
    for id in ratios_service.ERRD_IDS:
        assert id in RATIO_HANDLERS


def test_registry_contains_8_pgfp_ids() -> None:
    """Les 8 ratios PGFP D-095 bloc 10 sont enregistrés."""
    for id in ratios_service.PGFP_IDS:
        assert id in RATIO_HANDLERS


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_engine_handler_crash_wrapped_in_na(monkeypatch) -> None:
    """Un handler qui crash retourne NA — batch ne tombe pas."""

    async def _crash(_ctx):
        raise RuntimeError("oops")

    monkeypatch.setitem(RATIO_HANDLERS, "1.1", _crash)
    results = await run_ids(_ctx(), ["1.1"])
    assert len(results) == 1
    assert isinstance(results[0], RatioResult)
    assert results[0].verdict == "na"
    assert "Erreur d'évaluation" in (results[0].message or "")


@pytest.mark.asyncio
async def test_engine_handler_unregistered_returns_na() -> None:
    """Code inconnu → NA defensive."""
    results = await run_ids(_ctx(), ["X-9999"])
    assert len(results) == 1
    assert isinstance(results[0], RatioResult)
    assert results[0].verdict == "na"


# ---------------------------------------------------------------------------
# Service — summary + 404
# ---------------------------------------------------------------------------


def test_summarize_compteurs() -> None:
    """_summarize compte ok/atypie/na."""
    results = [
        RatioResult(
            id="1.1",
            label="x",
            valeur=Decimal("10"),
            unite="%",
            verdict="ok",
            formule_textuelle="",
        ),
        RatioResult(
            id="1.2",
            label="x",
            valeur=Decimal("60"),
            unite="%",
            verdict="atypie",
            formule_textuelle="",
        ),
        RatioResult(
            id="1.3",
            label="x",
            valeur=None,
            unite="%",
            verdict="na",
            formule_textuelle="",
        ),
    ]
    s = ratios_service._summarize(results)
    assert s.nb_ok == 1
    assert s.nb_atypie == 1
    assert s.nb_na == 1
    assert s.total == 3


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.ratios_service.run_in_thread",
        _passthrough,
    )
    monkeypatch.setattr(
        "piilot_pack_compta_esms.ratios._base.run_in_thread",
        _passthrough,
    )
    # Stub tous les repos appelés par les loaders lazy → retournent vide.
    from piilot_pack_compta_esms.repositories import (
        bilan_repo,
        cr_repo,
        emprunts_repo,
        pgfp_repo,
    )

    monkeypatch.setattr(bilan_repo, "list_by_document", lambda d, **kw: [])
    monkeypatch.setattr(cr_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(emprunts_repo, "list_by_document", lambda d: [])
    monkeypatch.setattr(pgfp_repo, "list_by_document", lambda d: [])


@pytest.mark.asyncio
async def test_compute_ratios_404_cross_tenant(monkeypatch, patch_run_in_thread):
    """Doc cross-tenant → 404."""
    other = _doc()
    other["company_id"] = uuid4()
    monkeypatch.setattr(ratios_service.document_repo, "get_by_id", lambda _: other)
    with pytest.raises(NotFoundError):
        await ratios_service.compute_ratios(DOC_ID, COMPANY)


@pytest.mark.asyncio
async def test_compute_ratios_skips_pgfp_for_errd(monkeypatch, patch_run_in_thread):
    """ERRD → pas de ratios PGFP (D-095 prévisionnel only)."""
    monkeypatch.setattr(ratios_service.document_repo, "get_by_id", lambda _: _doc("errd"))

    out = await ratios_service.compute_ratios(DOC_ID, COMPANY)
    assert out.type_document == "errd"
    assert out.ratios_pgfp == []
    # 15 ratios ERRD attendus
    assert len(out.ratios_errd) == 15


@pytest.mark.asyncio
async def test_compute_ratios_skips_errd_for_ercp(monkeypatch, patch_run_in_thread):
    """ERCP (secteur sanitaire M21) → pas de ratios ERRD v0.2 (Q8)."""
    monkeypatch.setattr(ratios_service.document_repo, "get_by_id", lambda _: _doc("ercp"))
    out = await ratios_service.compute_ratios(DOC_ID, COMPANY)
    assert out.ratios_errd == []
    assert out.ratios_pgfp == []


@pytest.mark.asyncio
async def test_compute_ratios_eprd_includes_pgfp(monkeypatch, patch_run_in_thread):
    """EPRD → 15 ratios ERRD + 8 ratios PGFP."""
    monkeypatch.setattr(ratios_service.document_repo, "get_by_id", lambda _: _doc("eprd"))
    out = await ratios_service.compute_ratios(DOC_ID, COMPANY)
    assert len(out.ratios_errd) == 15
    assert len(out.ratios_pgfp) == 8


@pytest.mark.asyncio
async def test_compute_ratios_type_filter_errd_only(monkeypatch, patch_run_in_thread):
    """type=errd skip les PGFP même sur EPRD."""
    monkeypatch.setattr(ratios_service.document_repo, "get_by_id", lambda _: _doc("eprd"))
    out = await ratios_service.compute_ratios(DOC_ID, COMPANY, type_filter="errd")
    assert len(out.ratios_errd) == 15
    assert out.ratios_pgfp == []


# ---------------------------------------------------------------------------
# Routes — TestClient
# ---------------------------------------------------------------------------


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter_module.limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(ratios_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


def test_route_get_ratios_200(app, monkeypatch):
    from piilot_pack_compta_esms.services.ratios_service import (
        RatiosResponse,
        RatiosSummary,
    )

    async def _fake(*args, **kwargs):
        return RatiosResponse(
            document_id=DOC_ID,
            type_document="errd",
            ratios_errd=[],
            ratios_pgfp=[],
            summary_errd=RatiosSummary(nb_ok=0, nb_atypie=0, nb_na=0, total=0),
            computed_at=datetime.now(UTC),
        )

    monkeypatch.setattr(ratios_service, "compute_ratios", _fake)

    client = TestClient(app)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/ratios")
    assert r.status_code == 200
    body = r.json()
    assert body["type_document"] == "errd"


def test_route_post_recompute_200(app, monkeypatch):
    from piilot_pack_compta_esms.services.ratios_service import (
        RatiosResponse,
        RatiosSummary,
    )

    async def _fake(*args, **kwargs):
        return RatiosResponse(
            document_id=DOC_ID,
            type_document="errd",
            ratios_errd=[],
            ratios_pgfp=[],
            summary_errd=RatiosSummary(nb_ok=0, nb_atypie=0, nb_na=0, total=0),
            computed_at=datetime.now(UTC),
        )

    monkeypatch.setattr(ratios_service, "recompute_ratios", _fake)

    client = TestClient(app)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/ratios:recompute")
    assert r.status_code == 200
