"""Unit tests for :mod:`piilot_pack_compta_esms.services.bilan_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.bilan import (
    BilanBulkUpsertRequest,
    BilanLigneCreate,
)
from piilot_pack_compta_esms.services import bilan_service
from piilot_pack_compta_esms.services.errors import (
    NotFoundError,
    ValidationError,
)

COMPANY = uuid4()
DOC_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.bilan_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def owned_doc_pc(monkeypatch):
    monkeypatch.setattr(
        bilan_service.bilan_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        bilan_service.bilan_repo,
        "get_doc_plan_comptable",
        lambda doc, company: {"type_document": "errd", "plan_comptable": "PC"},
    )


@pytest.fixture
def owned_doc_pnl(monkeypatch):
    monkeypatch.setattr(
        bilan_service.bilan_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        bilan_service.bilan_repo,
        "get_doc_plan_comptable",
        lambda doc, company: {"type_document": "errd", "plan_comptable": "PNL"},
    )


def _row(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "type_bilan": "financier",
        "section": "I",
        "poste_label": "Immo brutes",
        "compte_m22bis": None,
        "montant_brut_n": None,
        "montant_amort_n": None,
        "montant_net_n": Decimal("100000"),
        "montant_net_n1": None,
        "type_actif_passif": "actif",
        "montant_soins_n": None,
        "montant_dependance_n": None,
        "montant_hebergement_n": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# list_bilan
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_bilan_filtered(monkeypatch, owned_doc_pc, patch_run_in_thread):
    captured: dict = {}

    def _fake(doc, *, type_bilan=None):
        captured["type_bilan"] = type_bilan
        return [_row(), _row(section="II", poste_label="Capitaux", type_actif_passif="passif")]

    monkeypatch.setattr(bilan_service.bilan_repo, "list_by_document", _fake)
    out = await bilan_service.list_bilan(DOC_ID, COMPANY, type_bilan="financier")
    assert captured["type_bilan"] == "financier"
    assert out.plan_comptable_og == "PC"
    assert len(out.items) == 2


@pytest.mark.asyncio
async def test_list_bilan_cross_tenant(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        bilan_service.bilan_repo,
        "get_doc_plan_comptable",
        lambda doc, company: None,
    )
    with pytest.raises(NotFoundError):
        await bilan_service.list_bilan(DOC_ID, COMPANY)


# ---------------------------------------------------------------------------
# bulk_upsert_bilan — auto-déduction + reject incohérent
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_upsert_financier_only(monkeypatch, owned_doc_pc, patch_run_in_thread):
    captured: dict = {}

    def _fake_replace(*, company_id, document_id, type_bilan, items):
        captured.setdefault("groups", []).append((type_bilan, len(items)))
        return [_row(type_bilan=type_bilan)]

    monkeypatch.setattr(bilan_service.bilan_repo, "replace_by_type_bilan", _fake_replace)
    monkeypatch.setattr(bilan_service.bilan_repo, "list_by_document", lambda doc, **kw: [])

    await bilan_service.bulk_upsert_bilan(
        DOC_ID,
        COMPANY,
        BilanBulkUpsertRequest(
            items=[
                BilanLigneCreate(
                    type_bilan="financier",
                    section="I",
                    poste_label="Immo brutes",
                    montant_net_n=Decimal("100000"),
                    type_actif_passif="actif",
                ),
            ]
        ),
    )
    assert captured["groups"] == [("financier", 1)]


@pytest.mark.asyncio
async def test_bulk_upsert_comptable_pc_auto_deduce_ok(
    monkeypatch, owned_doc_pc, patch_run_in_thread
):
    """Q1 — payload comptable_pc autorisé quand og.plan_comptable=PC."""
    captured: dict = {}

    def _fake_replace(*, company_id, document_id, type_bilan, items):
        captured["type_bilan"] = type_bilan
        return [_row(type_bilan=type_bilan)]

    monkeypatch.setattr(bilan_service.bilan_repo, "replace_by_type_bilan", _fake_replace)
    monkeypatch.setattr(bilan_service.bilan_repo, "list_by_document", lambda doc, **kw: [])

    await bilan_service.bulk_upsert_bilan(
        DOC_ID,
        COMPANY,
        BilanBulkUpsertRequest(
            items=[
                BilanLigneCreate(
                    type_bilan="comptable_pc",
                    section="Capital",
                    poste_label="Capital social",
                    montant_net_n=Decimal("50000"),
                    type_actif_passif="passif",
                ),
            ]
        ),
    )
    assert captured["type_bilan"] == "comptable_pc"


@pytest.mark.asyncio
async def test_bulk_upsert_incoherent_comptable_variant(
    monkeypatch, owned_doc_pc, patch_run_in_thread
):
    """Q1 — payload comptable_pnl rejeté quand og.plan_comptable=PC."""
    with pytest.raises(ValidationError) as exc:
        await bilan_service.bulk_upsert_bilan(
            DOC_ID,
            COMPANY,
            BilanBulkUpsertRequest(
                items=[
                    BilanLigneCreate(
                        type_bilan="comptable_pnl",
                        section="Fonds propres",
                        poste_label="Fonds propres sans droit reprise",
                        montant_net_n=Decimal("80000"),
                        type_actif_passif="passif",
                    ),
                ]
            ),
        )
    assert exc.value.code == "incoherent_comptable_variant"


@pytest.mark.asyncio
async def test_bulk_upsert_pnl_accepted_when_og_pnl(
    monkeypatch, owned_doc_pnl, patch_run_in_thread
):
    captured: dict = {}

    def _fake_replace(*, company_id, document_id, type_bilan, items):
        captured["type_bilan"] = type_bilan
        return [_row(type_bilan=type_bilan)]

    monkeypatch.setattr(bilan_service.bilan_repo, "replace_by_type_bilan", _fake_replace)
    monkeypatch.setattr(bilan_service.bilan_repo, "list_by_document", lambda doc, **kw: [])

    await bilan_service.bulk_upsert_bilan(
        DOC_ID,
        COMPANY,
        BilanBulkUpsertRequest(
            items=[
                BilanLigneCreate(
                    type_bilan="comptable_pnl",
                    section="Fonds propres",
                    poste_label="Fonds propres sans droit reprise",
                    montant_net_n=Decimal("80000"),
                    type_actif_passif="passif",
                ),
            ]
        ),
    )
    assert captured["type_bilan"] == "comptable_pnl"


@pytest.mark.asyncio
async def test_bulk_upsert_groups_multi_types(monkeypatch, owned_doc_pc, patch_run_in_thread):
    """Body mixte financier + comptable_pc → 2 DELETE+INSERT distincts."""
    captured: list = []

    def _fake_replace(*, company_id, document_id, type_bilan, items):
        captured.append((type_bilan, len(items)))
        return [_row(type_bilan=type_bilan)]

    monkeypatch.setattr(bilan_service.bilan_repo, "replace_by_type_bilan", _fake_replace)
    monkeypatch.setattr(bilan_service.bilan_repo, "list_by_document", lambda doc, **kw: [])

    await bilan_service.bulk_upsert_bilan(
        DOC_ID,
        COMPANY,
        BilanBulkUpsertRequest(
            items=[
                BilanLigneCreate(
                    type_bilan="financier",
                    section="I",
                    poste_label="Immo brutes",
                    type_actif_passif="actif",
                    montant_net_n=Decimal("100000"),
                ),
                BilanLigneCreate(
                    type_bilan="comptable_pc",
                    section="Capital",
                    poste_label="Capital social",
                    type_actif_passif="passif",
                    montant_net_n=Decimal("50000"),
                ),
            ]
        ),
    )
    types_called = {t for t, _ in captured}
    assert types_called == {"financier", "comptable_pc"}


# ---------------------------------------------------------------------------
# compute_totals — pivot par section + actif/passif
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_compute_totals_pivots_correctly(monkeypatch, owned_doc_pc, patch_run_in_thread):
    monkeypatch.setattr(
        bilan_service.bilan_repo,
        "totals_by_type_section",
        lambda doc, **kw: [
            {
                "type_bilan": "financier",
                "section": "I",
                "type_actif_passif": "actif",
                "total": Decimal("100000"),
            },
            {
                "type_bilan": "financier",
                "section": "I",
                "type_actif_passif": "passif",
                "total": Decimal("100000"),
            },
            {
                "type_bilan": "financier",
                "section": "II",
                "type_actif_passif": "actif",
                "total": Decimal("50000"),
            },
            {
                "type_bilan": "financier",
                "section": "II",
                "type_actif_passif": "passif",
                "total": Decimal("50000"),
            },
        ],
    )
    out = await bilan_service.compute_totals(DOC_ID, COMPANY)
    assert out.financier is not None
    assert out.comptable_pc is None
    assert out.comptable_pnl is None
    fin = out.financier
    assert fin.total_biens == Decimal("150000")
    assert fin.total_financements == Decimal("150000")
    assert fin.ecart == Decimal("0")
    assert len(fin.by_section) == 2


@pytest.mark.asyncio
async def test_compute_totals_no_rows(monkeypatch, owned_doc_pc, patch_run_in_thread):
    monkeypatch.setattr(
        bilan_service.bilan_repo,
        "totals_by_type_section",
        lambda doc, **kw: [],
    )
    out = await bilan_service.compute_totals(DOC_ID, COMPANY)
    assert out.financier is None
    assert out.comptable_pc is None
    assert out.comptable_pnl is None


@pytest.mark.asyncio
async def test_compute_totals_filter_by_type(monkeypatch, owned_doc_pc, patch_run_in_thread):
    captured: dict = {}

    def _fake(doc, *, type_bilan=None):
        captured["type_bilan"] = type_bilan
        return [
            {
                "type_bilan": "comptable_pc",
                "section": "Capital",
                "type_actif_passif": "passif",
                "total": Decimal("50000"),
            },
        ]

    monkeypatch.setattr(bilan_service.bilan_repo, "totals_by_type_section", _fake)
    out = await bilan_service.compute_totals(DOC_ID, COMPANY, type_bilan="comptable_pc")
    assert captured["type_bilan"] == "comptable_pc"
    assert out.comptable_pc is not None
    assert out.financier is None


# ---------------------------------------------------------------------------
# validate_equilibre — C-56/C-57 (tolérance 0.01€ Q5)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_validate_happy(monkeypatch, owned_doc_pc, patch_run_in_thread):
    monkeypatch.setattr(
        bilan_service.bilan_repo,
        "totals_by_type_section",
        lambda doc, **kw: [
            {
                "type_bilan": "financier",
                "section": "I",
                "type_actif_passif": "actif",
                "total": Decimal("100000"),
            },
            {
                "type_bilan": "financier",
                "section": "I",
                "type_actif_passif": "passif",
                "total": Decimal("100000"),
            },
        ],
    )
    out = await bilan_service.validate_equilibre(DOC_ID, COMPANY)
    assert out.valide is True
    assert out.issues == []


@pytest.mark.asyncio
async def test_validate_ecart_above_tolerance(monkeypatch, owned_doc_pc, patch_run_in_thread):
    monkeypatch.setattr(
        bilan_service.bilan_repo,
        "totals_by_type_section",
        lambda doc, **kw: [
            {
                "type_bilan": "financier",
                "section": "I",
                "type_actif_passif": "actif",
                "total": Decimal("100000"),
            },
            {
                "type_bilan": "financier",
                "section": "I",
                "type_actif_passif": "passif",
                "total": Decimal("95000"),
            },
        ],
    )
    out = await bilan_service.validate_equilibre(DOC_ID, COMPANY)
    assert out.valide is False
    assert len(out.issues) == 1
    assert out.issues[0].code == "ecart_above_tolerance"
    assert out.issues[0].type_bilan == "financier"
    assert out.issues[0].ecart == Decimal("5000")


@pytest.mark.asyncio
async def test_validate_tolerance_accepted(monkeypatch, owned_doc_pc, patch_run_in_thread):
    """Q5 — écart ≤ 0.01€ accepté (arrondi comptable)."""
    monkeypatch.setattr(
        bilan_service.bilan_repo,
        "totals_by_type_section",
        lambda doc, **kw: [
            {
                "type_bilan": "financier",
                "section": "I",
                "type_actif_passif": "actif",
                "total": Decimal("100000.005"),
            },
            {
                "type_bilan": "financier",
                "section": "I",
                "type_actif_passif": "passif",
                "total": Decimal("100000"),
            },
        ],
    )
    out = await bilan_service.validate_equilibre(DOC_ID, COMPANY)
    assert out.valide is True


@pytest.mark.asyncio
async def test_validate_empty_bilan(monkeypatch, owned_doc_pc, patch_run_in_thread):
    """Aucun bilan saisi → valide=true (rien à valider, c'est le cabinet en cours)."""
    monkeypatch.setattr(bilan_service.bilan_repo, "totals_by_type_section", lambda doc, **kw: [])
    out = await bilan_service.validate_equilibre(DOC_ID, COMPANY)
    assert out.valide is True


@pytest.mark.asyncio
async def test_validate_filter_by_type(monkeypatch, owned_doc_pc, patch_run_in_thread):
    captured: dict = {}

    def _fake(doc, *, type_bilan=None):
        captured["type_bilan"] = type_bilan
        return []

    monkeypatch.setattr(bilan_service.bilan_repo, "totals_by_type_section", _fake)
    await bilan_service.validate_equilibre(DOC_ID, COMPANY, type_bilan="comptable_pc")
    assert captured["type_bilan"] == "comptable_pc"
