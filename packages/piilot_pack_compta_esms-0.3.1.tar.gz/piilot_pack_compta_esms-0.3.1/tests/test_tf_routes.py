"""Route tests for tableau de financement endpoints (L2 §15, 3 endpoints)."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.tf import (
    TfEquilibreByColumn,
    TfLigneRead,
    TfResponse,
    TfTitreSubtotal,
    TfTotalsForCote,
    TfTotalsResponse,
)
from piilot_pack_compta_esms.routes import tf as tf_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import tf_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)


def _ligne_read(**overrides) -> TfLigneRead:
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "cote": "ressources",
        "titre": "Titre 1",
        "compte_m22bis": None,
        "libelle": "CAF",
        "montant_budget_initial_n1": None,
        "montant_realisations_n1": None,
        "montant_previsions_n": None,
        "montant_realisations_n": Decimal("100000"),
        "montant_nm1": None,
        "montant_n": None,
        "montant_np1": None,
        "montant_np2": None,
        "montant_np3": None,
        "montant_np4": None,
        "montant_np5": None,
        "montant_np6": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return TfLigneRead.model_validate(base)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(tf_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# §15.1 GET /tableau-financement
# ---------------------------------------------------------------------------


def test_get_tf_200_returns_type_tf(client, monkeypatch):
    async def _fake(doc, company):
        return TfResponse(type_tf="TF", items=[_ligne_read()])

    monkeypatch.setattr(tf_service, "list_tf", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tableau-financement")
    assert r.status_code == 200
    body = r.json()
    assert body["type_tf"] == "TF"
    assert len(body["items"]) == 1


def test_get_tf_200_tfp_for_eprd(client, monkeypatch):
    async def _fake(doc, company):
        return TfResponse(type_tf="TFP", items=[])

    monkeypatch.setattr(tf_service, "list_tf", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tableau-financement")
    assert r.status_code == 200
    assert r.json()["type_tf"] == "TFP"


def test_get_tf_404(client, monkeypatch):
    async def _fake(doc, company):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(tf_service, "list_tf", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tableau-financement")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §15.2 POST :bulk-upsert
# ---------------------------------------------------------------------------


def test_bulk_upsert_200(client, monkeypatch):
    async def _fake(doc, company, payload):
        return TfResponse(type_tf="TF", items=[_ligne_read()])

    monkeypatch.setattr(tf_service, "bulk_upsert_tf", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tableau-financement:bulk-upsert",
        json={
            "items": [
                {
                    "cote": "ressources",
                    "titre": "Titre 1",
                    "libelle": "CAF",
                    "montant_realisations_n": "100000.00",
                }
            ]
        },
    )
    assert r.status_code == 200


def test_bulk_upsert_403_user_role(client):
    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tableau-financement:bulk-upsert",
        json={"items": []},
    )
    assert r.status_code == 403


def test_bulk_upsert_invalid_cote_422(client):
    """cote Literal — 'invalid' rejeté."""
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tableau-financement:bulk-upsert",
        json={
            "items": [
                {
                    "cote": "invalid",
                    "libelle": "X",
                }
            ]
        },
    )
    assert r.status_code == 422


# ---------------------------------------------------------------------------
# §15.3 GET :totals
# ---------------------------------------------------------------------------


def test_get_totals_200_with_breakdown(client, monkeypatch):
    async def _fake(doc, company):
        return TfTotalsResponse(
            type_tf="TF",
            ressources=TfTotalsForCote(
                cote="ressources",
                by_titre=[
                    TfTitreSubtotal(
                        titre="Titre 1",
                        totals_by_column={"montant_realisations_n": Decimal("100000")},
                    ),
                ],
                totals_by_column={"montant_realisations_n": Decimal("100000")},
            ),
            emplois=TfTotalsForCote(
                cote="emplois",
                by_titre=[
                    TfTitreSubtotal(
                        titre="Titre 2",
                        totals_by_column={"montant_realisations_n": Decimal("100000")},
                    ),
                ],
                totals_by_column={"montant_realisations_n": Decimal("100000")},
            ),
            equilibre_by_column=[
                TfEquilibreByColumn(
                    column="montant_realisations_n",
                    total_ressources=Decimal("100000"),
                    total_emplois=Decimal("100000"),
                    ecart=Decimal("0"),
                    valide=True,
                ),
            ],
            valide_globalement=True,
            tolerance_appliquee=Decimal("0.01"),
        )

    monkeypatch.setattr(tf_service, "compute_totals", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tableau-financement:totals")
    assert r.status_code == 200
    body = r.json()
    assert body["type_tf"] == "TF"
    assert body["valide_globalement"] is True
    assert len(body["ressources"]["by_titre"]) == 1
    assert body["equilibre_by_column"][0]["valide"] is True


def test_get_totals_with_ecart(client, monkeypatch):
    async def _fake(doc, company):
        return TfTotalsResponse(
            type_tf="TF",
            ressources=None,
            emplois=None,
            equilibre_by_column=[
                TfEquilibreByColumn(
                    column="montant_realisations_n",
                    total_ressources=Decimal("100000"),
                    total_emplois=Decimal("95000"),
                    ecart=Decimal("5000"),
                    valide=False,
                ),
            ],
            valide_globalement=False,
            tolerance_appliquee=Decimal("0.01"),
        )

    monkeypatch.setattr(tf_service, "compute_totals", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tableau-financement:totals")
    assert r.status_code == 200
    body = r.json()
    assert body["valide_globalement"] is False
    assert body["equilibre_by_column"][0]["ecart"] == "5000"
