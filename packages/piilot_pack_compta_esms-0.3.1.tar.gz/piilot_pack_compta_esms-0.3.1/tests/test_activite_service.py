"""Unit tests for :mod:`piilot_pack_compta_esms.services.activite_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.activite import (
    ActiviteBulkUpsertRequest,
    ActiviteLigneCreate,
)
from piilot_pack_compta_esms.services import activite_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
DOC_ID = uuid4()
ETS_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.activite_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def valid_doc_ets(monkeypatch):
    """Doc OK + ETS avec capacite 80 + amplitude 365."""
    monkeypatch.setattr(
        activite_service.activite_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        activite_service.activite_repo,
        "get_ets_capacite",
        lambda ets, company: {"capacite_financee": 80, "amplitude_ouverture": 365},
    )


def _row(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "etablissement_id": ETS_ID,
        "annexe_variante": "4A_ehpad_puv",
        "mode_creton": False,
        "section": "hp",
        "gir": "gir1",
        "annee_offset": 0,
        "nature_donnee": "prevu",
        "nombre_places": 80,
        "nombre_personnes": 78,
        "nombre_journees": 28000,
        "absences_moins72h_convenance": None,
        "absences_moins72h_hospi": None,
        "absences_plus72h_convenance": None,
        "absences_plus72h_hospi": None,
        "hors_departement_count": None,
        "beneficiaires_aide_sociale": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# list_activite
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_no_filters_returns_all(patch_run_in_thread, valid_doc_ets, monkeypatch):
    monkeypatch.setattr(
        activite_service.activite_repo,
        "list_by_filter",
        lambda doc, ets=None, annexe=None: [_row(), _row(annexe_variante="9A_ehpad_realise")],
    )

    result = await activite_service.list_activite(DOC_ID, COMPANY)

    assert result.ets_id_filtre is None
    assert result.annexe_filtre is None
    assert len(result.items) == 2


@pytest.mark.asyncio
async def test_list_with_filters(patch_run_in_thread, valid_doc_ets, monkeypatch):
    captured = {}

    def _list(doc, ets=None, annexe=None):
        captured["ets"] = ets
        captured["annexe"] = annexe
        return [_row()]

    monkeypatch.setattr(activite_service.activite_repo, "list_by_filter", _list)

    result = await activite_service.list_activite(
        DOC_ID, COMPANY, ets_id=ETS_ID, annexe_variante="4A_ehpad_puv"
    )

    assert captured["ets"] == ETS_ID
    assert captured["annexe"] == "4A_ehpad_puv"
    assert result.ets_id_filtre == ETS_ID
    assert result.annexe_filtre == "4A_ehpad_puv"


@pytest.mark.asyncio
async def test_list_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        activite_service.activite_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    with pytest.raises(NotFoundError) as exc:
        await activite_service.list_activite(DOC_ID, COMPANY)
    assert exc.value.code == "document_not_found"


# ---------------------------------------------------------------------------
# bulk_upsert_activite — Q1 replace_by_doc_ets_annexe
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_upsert_replace_by_scope(patch_run_in_thread, valid_doc_ets, monkeypatch):
    captured = {}

    def _replace(**kwargs):
        captured.update(kwargs)
        return []

    monkeypatch.setattr(activite_service.activite_repo, "replace_by_doc_ets_annexe", _replace)
    monkeypatch.setattr(
        activite_service.activite_repo,
        "list_by_filter",
        lambda d, e=None, a=None: [],
    )

    payload = ActiviteBulkUpsertRequest(
        ets_id=ETS_ID,
        annexe_variante="4A_ehpad_puv",
        items=[
            ActiviteLigneCreate(
                section="hp",
                gir="gir1",
                annee_offset=0,
                nature_donnee="prevu",
                nombre_places=80,
                nombre_journees=28000,
            ),
        ],
    )
    await activite_service.bulk_upsert_activite(DOC_ID, COMPANY, payload)

    assert captured["annexe_variante"] == "4A_ehpad_puv"
    assert captured["etablissement_id"] == ETS_ID
    assert len(captured["items"]) == 1


@pytest.mark.asyncio
async def test_bulk_upsert_empty_items_is_valid(patch_run_in_thread, valid_doc_ets, monkeypatch):
    """Items vide = clear l'onglet."""
    captured = {}

    def _replace(**kwargs):
        captured.update(kwargs)
        return []

    monkeypatch.setattr(activite_service.activite_repo, "replace_by_doc_ets_annexe", _replace)
    monkeypatch.setattr(
        activite_service.activite_repo,
        "list_by_filter",
        lambda d, e=None, a=None: [],
    )

    payload = ActiviteBulkUpsertRequest(ets_id=ETS_ID, annexe_variante="4D_sad_spasad", items=[])
    await activite_service.bulk_upsert_activite(DOC_ID, COMPANY, payload)

    assert captured["items"] == []


@pytest.mark.asyncio
async def test_bulk_upsert_ets_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        activite_service.activite_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        activite_service.activite_repo,
        "get_ets_capacite",
        lambda ets, company: None,
    )

    payload = ActiviteBulkUpsertRequest(ets_id=ETS_ID, annexe_variante="4A_ehpad_puv", items=[])
    with pytest.raises(NotFoundError) as exc:
        await activite_service.bulk_upsert_activite(DOC_ID, COMPANY, payload)
    assert exc.value.code == "etablissement_not_found"


@pytest.mark.asyncio
async def test_bulk_upsert_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        activite_service.activite_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    payload = ActiviteBulkUpsertRequest(ets_id=ETS_ID, annexe_variante="4A_ehpad_puv", items=[])
    with pytest.raises(NotFoundError) as exc:
        await activite_service.bulk_upsert_activite(DOC_ID, COMPANY, payload)
    assert exc.value.code == "document_not_found"


# ---------------------------------------------------------------------------
# compute_theorique — Q3+Q4 D-051
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_compute_theorique_ehpad_3_sections_5_annees(
    patch_run_in_thread, valid_doc_ets, monkeypatch
):
    """4A EHPAD → 3 sections (hp/ht/aj) × 5 années (N-4..N) = 15 items."""
    captured = {}

    def _replace_theorique(**kwargs):
        captured.update(kwargs)
        return kwargs["items"]

    monkeypatch.setattr(
        activite_service.activite_repo,
        "replace_theorique_by_doc_ets_annexe",
        _replace_theorique,
    )
    monkeypatch.setattr(
        activite_service.activite_repo,
        "list_by_filter",
        lambda d, e=None, a=None: [],
    )

    result = await activite_service.compute_theorique(DOC_ID, COMPANY, ETS_ID, "4A_ehpad_puv")

    assert result.capacite_financee == 80
    assert result.amplitude_ouverture == 365
    assert result.nombre_journees_theorique == 80 * 365
    assert len(captured["items"]) == 15  # 3 sections × 5 années
    # All items have nature='theorique', gir=NULL
    for item in captured["items"]:
        assert item["nature_donnee"] == "theorique"
        assert item["gir"] is None
        assert item["nombre_journees"] == 80 * 365
    # Sections couvertes
    sections_in_items = {it["section"] for it in captured["items"]}
    assert sections_in_items == {"hp", "ht", "aj"}


@pytest.mark.asyncio
async def test_compute_theorique_annexe9_4_annees(patch_run_in_thread, valid_doc_ets, monkeypatch):
    """9A Annexe réalisée → 4 années (N-3..N), pas 5 (D-098)."""
    captured = {}
    monkeypatch.setattr(
        activite_service.activite_repo,
        "replace_theorique_by_doc_ets_annexe",
        lambda **kw: captured.update(kw) or kw["items"],
    )
    monkeypatch.setattr(
        activite_service.activite_repo,
        "list_by_filter",
        lambda d, e=None, a=None: [],
    )

    await activite_service.compute_theorique(DOC_ID, COMPANY, ETS_ID, "9A_ehpad_realise")

    assert len(captured["items"]) == 12  # 3 sections × 4 années (N-3..N)


@pytest.mark.asyncio
async def test_compute_theorique_autres_essms(patch_run_in_thread, valid_doc_ets, monkeypatch):
    """4B → externat/semi_internat/internat × 5 années = 15 items."""
    captured = {}
    monkeypatch.setattr(
        activite_service.activite_repo,
        "replace_theorique_by_doc_ets_annexe",
        lambda **kw: captured.update(kw) or kw["items"],
    )
    monkeypatch.setattr(
        activite_service.activite_repo,
        "list_by_filter",
        lambda d, e=None, a=None: [],
    )

    await activite_service.compute_theorique(DOC_ID, COMPANY, ETS_ID, "4B_autres_essms")

    sections = {it["section"] for it in captured["items"]}
    assert sections == {"externat", "semi_internat", "internat"}
    assert len(captured["items"]) == 15


@pytest.mark.asyncio
async def test_compute_theorique_creton_sets_mode_creton(
    patch_run_in_thread, valid_doc_ets, monkeypatch
):
    """4C Creton → mode_creton=True sur toutes les lignes."""
    captured = {}
    monkeypatch.setattr(
        activite_service.activite_repo,
        "replace_theorique_by_doc_ets_annexe",
        lambda **kw: captured.update(kw) or kw["items"],
    )
    monkeypatch.setattr(
        activite_service.activite_repo,
        "list_by_filter",
        lambda d, e=None, a=None: [],
    )

    await activite_service.compute_theorique(DOC_ID, COMPANY, ETS_ID, "4C_creton")

    for item in captured["items"]:
        assert item["mode_creton"] is True


@pytest.mark.asyncio
async def test_compute_theorique_idempotent(patch_run_in_thread, valid_doc_ets, monkeypatch):
    """Q4 — 2 appels successifs produisent même résultat."""
    insert_log = []

    def _replace_theorique(**kwargs):
        insert_log.append(len(kwargs["items"]))
        return kwargs["items"]

    monkeypatch.setattr(
        activite_service.activite_repo,
        "replace_theorique_by_doc_ets_annexe",
        _replace_theorique,
    )

    # 1er appel : DB vide, 15 inserted
    monkeypatch.setattr(
        activite_service.activite_repo,
        "list_by_filter",
        lambda d, e=None, a=None: [],
    )
    r1 = await activite_service.compute_theorique(DOC_ID, COMPANY, ETS_ID, "4A_ehpad_puv")
    assert r1.inserted == 15
    assert r1.updated == 0

    # 2e appel : DB déjà avec 15 lignes theorique, 0 inserted + 15 updated
    monkeypatch.setattr(
        activite_service.activite_repo,
        "list_by_filter",
        lambda d, e=None, a=None: [_row(nature_donnee="theorique") for _ in range(15)],
    )
    r2 = await activite_service.compute_theorique(DOC_ID, COMPANY, ETS_ID, "4A_ehpad_puv")
    assert r2.inserted == 0
    assert r2.updated == 15
    assert insert_log == [15, 15]  # 2 appels avec 15 items chacun


@pytest.mark.asyncio
async def test_compute_theorique_zero_capacite(patch_run_in_thread, monkeypatch):
    """ETS sans capacite_financee (0) → nombre_journees = 0 mais
    n'échoue pas."""
    monkeypatch.setattr(
        activite_service.activite_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        activite_service.activite_repo,
        "get_ets_capacite",
        lambda ets, company: {"capacite_financee": 0, "amplitude_ouverture": 365},
    )
    captured = {}
    monkeypatch.setattr(
        activite_service.activite_repo,
        "replace_theorique_by_doc_ets_annexe",
        lambda **kw: captured.update(kw) or kw["items"],
    )
    monkeypatch.setattr(
        activite_service.activite_repo,
        "list_by_filter",
        lambda d, e=None, a=None: [],
    )

    result = await activite_service.compute_theorique(DOC_ID, COMPANY, ETS_ID, "4A_ehpad_puv")

    assert result.nombre_journees_theorique == 0
    assert all(it["nombre_journees"] == 0 for it in captured["items"])


@pytest.mark.asyncio
async def test_compute_theorique_ets_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        activite_service.activite_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        activite_service.activite_repo,
        "get_ets_capacite",
        lambda ets, company: None,
    )

    with pytest.raises(NotFoundError) as exc:
        await activite_service.compute_theorique(DOC_ID, COMPANY, ETS_ID, "4A_ehpad_puv")
    assert exc.value.code == "etablissement_not_found"


@pytest.mark.asyncio
async def test_compute_theorique_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        activite_service.activite_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    with pytest.raises(NotFoundError) as exc:
        await activite_service.compute_theorique(DOC_ID, COMPANY, ETS_ID, "4A_ehpad_puv")
    assert exc.value.code == "document_not_found"
