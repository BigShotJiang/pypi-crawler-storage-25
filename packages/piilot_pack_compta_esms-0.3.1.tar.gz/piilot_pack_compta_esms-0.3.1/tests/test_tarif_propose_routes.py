"""HTTP smoke tests for EPRD tarifs proposés routes — §BB v0.3.

Path resolution + request parsing + status codes + permission gating.
"""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_admin, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.tarif_propose import (
    TarifProposeRead,
    TarifSectionAggregate,
    TarifValidationReport,
)
from piilot_pack_compta_esms.routes import tarif_propose as tarif_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import tarifs_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
    ValidationError,
)

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
ETS_ID = uuid4()
TARIF_ID = uuid4()

ADMIN_AUTH = (USER, "admin", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


def _tarif_dict(**overrides):
    base = {
        "id": TARIF_ID,
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "etablissement_id": ETS_ID,
        "section": "HEBERGEMENT",
        "libelle": None,
        "montant_propose": Decimal("75.50"),
        "montant_notifie": None,
        "ecart": None,
        "motif": None,
        "statut": "PROPOSE",
        "date_validation": None,
        "valide_par": None,
        "motif_rejet": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(tarif_routes.router_under_doc, prefix="/plugins/compta_esms")
    app.include_router(tarif_routes.router_flat, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_admin] = lambda: ADMIN_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# --------------------------------------------------------------------
# CRUD
# --------------------------------------------------------------------


def test_list_200(client, monkeypatch):
    async def _fake(c, d):
        return [TarifProposeRead.model_validate(_tarif_dict())]

    monkeypatch.setattr(tarifs_service, "list_by_document", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tarifs-proposes")
    assert r.status_code == 200
    assert r.json()[0]["id"] == str(TARIF_ID)


def test_list_404_when_document_missing(client, monkeypatch):
    async def _fake(c, d):
        raise NotFoundError("missing", code="document_not_found")

    monkeypatch.setattr(tarifs_service, "list_by_document", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tarifs-proposes")
    assert r.status_code == 404


def test_list_422_when_document_type_wrong(client, monkeypatch):
    async def _fake(c, d):
        raise ValidationError("errd not supported", code="document_type_no_tarifs")

    monkeypatch.setattr(tarifs_service, "list_by_document", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tarifs-proposes")
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "document_type_no_tarifs"


def test_create_201(client, monkeypatch):
    async def _fake(c, d, payload):
        return TarifProposeRead.model_validate(_tarif_dict(section=payload.section))

    monkeypatch.setattr(tarifs_service, "create_tarif", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tarifs-proposes",
        json={
            "etablissement_id": str(ETS_ID),
            "section": "DEPENDANCE",
            "montant_propose": "12.50",
        },
    )
    assert r.status_code == 201, r.text
    assert r.json()["section"] == "DEPENDANCE"


def test_create_422_on_invalid_section(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tarifs-proposes",
        json={
            "etablissement_id": str(ETS_ID),
            "section": "REPAS",
            "montant_propose": "1",
        },
    )
    assert r.status_code == 422


def test_create_409_on_conflict(client, monkeypatch):
    async def _fake(c, d, payload):
        raise ConflictError("taken", code="tarif_natural_key_taken")

    monkeypatch.setattr(tarifs_service, "create_tarif", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tarifs-proposes",
        json={
            "etablissement_id": str(ETS_ID),
            "section": "HEBERGEMENT",
            "montant_propose": "1",
        },
    )
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "tarif_natural_key_taken"


def test_get_tarif_200(client, monkeypatch):
    async def _fake(c, t):
        return TarifProposeRead.model_validate(_tarif_dict())

    monkeypatch.setattr(tarifs_service, "get_tarif", _fake)
    r = client.get(f"/plugins/compta_esms/tarifs-proposes/{TARIF_ID}")
    assert r.status_code == 200
    assert r.json()["id"] == str(TARIF_ID)


def test_patch_tarif_200(client, monkeypatch):
    async def _fake(c, t, payload):
        return TarifProposeRead.model_validate(
            _tarif_dict(montant_notifie=Decimal("80.00"), statut="VALIDE_ARS")
        )

    monkeypatch.setattr(tarifs_service, "update_tarif", _fake)
    r = client.patch(
        f"/plugins/compta_esms/tarifs-proposes/{TARIF_ID}",
        json={"montant_notifie": "80.00", "statut": "VALIDE_ARS"},
    )
    assert r.status_code == 200
    assert r.json()["montant_notifie"] == "80.00"
    assert r.json()["statut"] == "VALIDE_ARS"


def test_patch_tarif_422_when_locked(client, monkeypatch):
    async def _fake(c, t, payload):
        raise ValidationError("locked", code="tarif_statut_locked")

    monkeypatch.setattr(tarifs_service, "update_tarif", _fake)
    r = client.patch(
        f"/plugins/compta_esms/tarifs-proposes/{TARIF_ID}",
        json={"statut": "PROPOSE"},
    )
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "tarif_statut_locked"


def test_delete_tarif_204(client, monkeypatch):
    async def _fake(c, t):
        return None

    monkeypatch.setattr(tarifs_service, "delete_tarif", _fake)
    r = client.delete(f"/plugins/compta_esms/tarifs-proposes/{TARIF_ID}")
    assert r.status_code == 204


# --------------------------------------------------------------------
# Bulk upsert
# --------------------------------------------------------------------


def test_bulk_upsert_200(client, monkeypatch):
    async def _fake(c, d, items):
        return [
            TarifProposeRead.model_validate(
                _tarif_dict(
                    etablissement_id=it.etablissement_id,
                    section=it.section,
                    montant_propose=it.montant_propose,
                )
            )
            for it in items
        ]

    monkeypatch.setattr(tarifs_service, "bulk_upsert", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tarifs-proposes:bulk-upsert",
        json=[
            {
                "etablissement_id": str(ETS_ID),
                "section": "HEBERGEMENT",
                "montant_propose": "75",
            },
            {
                "etablissement_id": str(ETS_ID),
                "section": "DEPENDANCE",
                "montant_propose": "25",
            },
        ],
    )
    assert r.status_code == 200, r.text
    assert len(r.json()) == 2


def test_bulk_upsert_422_on_duplicate(client, monkeypatch):
    async def _fake(c, d, items):
        raise ValidationError("dup", code="bulk_duplicate_key")

    monkeypatch.setattr(tarifs_service, "bulk_upsert", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tarifs-proposes:bulk-upsert",
        json=[
            {
                "etablissement_id": str(ETS_ID),
                "section": "SOINS",
                "montant_propose": "10",
            }
        ],
    )
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "bulk_duplicate_key"


# --------------------------------------------------------------------
# Validation report
# --------------------------------------------------------------------


def test_validate_200(client, monkeypatch):
    async def _fake(c, d):
        return TarifValidationReport(
            document_id=DOC_ID,
            sections=[
                TarifSectionAggregate(
                    section="HEBERGEMENT",
                    rows_count=1,
                    total_propose=Decimal("75"),
                    total_notifie=Decimal("75"),
                    ecart=Decimal("0"),
                    all_validated_tripartite=True,
                )
            ],
            total_rows=1,
            all_sections_tripartite=True,
            has_rejected_rows=False,
        )

    monkeypatch.setattr(tarifs_service, "build_validation_report", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/tarifs-proposes:validate")
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["all_sections_tripartite"] is True
    assert body["total_rows"] == 1
    assert len(body["sections"]) == 1


# --------------------------------------------------------------------
# Permission gating
# --------------------------------------------------------------------


def test_create_403_when_not_admin(app, client):
    from fastapi import HTTPException

    def _deny():
        raise HTTPException(status_code=403, detail={"code": "forbidden", "message": "no"})

    app.dependency_overrides[require_admin] = _deny
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/tarifs-proposes",
        json={
            "etablissement_id": str(ETS_ID),
            "section": "SOINS",
            "montant_propose": "1",
        },
    )
    assert r.status_code == 403
