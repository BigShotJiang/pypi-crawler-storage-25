"""Route tests for affectation endpoints (L2 §10, 4 endpoints)."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.affectation import (
    AffectationRead,
    AffectationsResponse,
    AllocationValidationResult,
    ResultatBrutBySection,
    SuiviAffectationRead,
    ValidationIssue,
)
from piilot_pack_compta_esms.routes import affectation as aff_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import affectation_service
from piilot_pack_compta_esms.services.errors import (
    NotFoundError,
    ValidationError,
)

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
CR_ID = uuid4()
ETS_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)


def _aff_read(**overrides) -> AffectationRead:
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "variante": "prive_I",
        "ventilation": "simple",
        "cr_id": CR_ID,
        "compte_m22bis": "11501",
        "compte_label": "Report excédentaire",
        "montant_soins_dependance": None,
        "montant_hebergement": None,
        "montant_total": Decimal("1000"),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return AffectationRead.model_validate(base)


def _resp(items=None, valide=True, issues=None) -> AffectationsResponse:
    return AffectationsResponse(
        variante_active="prive_I",
        ventilation_active="simple",
        items=items or [_aff_read()],
        resultats_bruts=[
            ResultatBrutBySection(
                cr_id=CR_ID,
                cr_denomination="CRPP",
                total_charges_realise=Decimal("80000"),
                total_produits_realise=Decimal("81000"),
                resultat_brut=Decimal("1000"),
            )
        ],
        validation=AllocationValidationResult(
            valide=valide,
            issues=issues or [],
            tolerance_appliquee=Decimal("0.01"),
        ),
    )


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(aff_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# §10.1 GET /affectations
# ---------------------------------------------------------------------------


def test_get_affectations_200(client, monkeypatch):
    async def _fake(doc, company):
        return _resp()

    monkeypatch.setattr(affectation_service, "list_affectations", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/affectations")
    assert r.status_code == 200
    body = r.json()
    assert body["variante_active"] == "prive_I"
    assert len(body["items"]) == 1
    assert body["validation"]["valide"] is True


def test_get_affectations_404(client, monkeypatch):
    async def _fake(doc, company):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(affectation_service, "list_affectations", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/affectations")
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "document_not_found"


# ---------------------------------------------------------------------------
# §10.2 PUT /affectations
# ---------------------------------------------------------------------------


def test_put_affectations_200(client, monkeypatch):
    captured = {}

    async def _fake(doc, company, payload):
        captured["doc"] = doc
        captured["items_count"] = len(payload.items)
        return _resp()

    monkeypatch.setattr(affectation_service, "put_affectations_bulk", _fake)
    r = client.put(
        f"/plugins/compta_esms/documents/{DOC_ID}/affectations",
        json={
            "items": [
                {
                    "compte_m22bis": "11501",
                    "cr_id": str(CR_ID),
                    "montant_total": "1000.00",
                }
            ]
        },
    )
    assert r.status_code == 200
    assert captured["items_count"] == 1


def test_put_affectations_403_user(client):
    """L2 §10.2 builder required — user-role bloqué."""

    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.put(
        f"/plugins/compta_esms/documents/{DOC_ID}/affectations",
        json={"items": []},
    )
    assert r.status_code == 403


def test_put_affectations_422_validation_error(client, monkeypatch):
    """variant_I sans cr_id → 422."""

    async def _fake(doc, company, payload):
        raise ValidationError("missing", code="missing_cr_id")

    monkeypatch.setattr(affectation_service, "put_affectations_bulk", _fake)
    r = client.put(
        f"/plugins/compta_esms/documents/{DOC_ID}/affectations",
        json={"items": [{"compte_m22bis": "11501", "montant_total": "1000.00"}]},
    )
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "missing_cr_id"


# ---------------------------------------------------------------------------
# §10.3 POST :validate
# ---------------------------------------------------------------------------


def test_validate_200_valide(client, monkeypatch):
    async def _fake(doc, company):
        return AllocationValidationResult(
            valide=True, issues=[], tolerance_appliquee=Decimal("0.01")
        )

    monkeypatch.setattr(affectation_service, "validate_allocations", _fake)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/affectations:validate")
    assert r.status_code == 200
    assert r.json()["valide"] is True


def test_validate_200_with_issues(client, monkeypatch):
    async def _fake(doc, company):
        return AllocationValidationResult(
            valide=False,
            issues=[
                ValidationIssue(
                    code="ecart_above_tolerance",
                    cr_id=CR_ID,
                    message="Écart 1000€",
                    ecart=Decimal("1000"),
                )
            ],
            tolerance_appliquee=Decimal("0.01"),
        )

    monkeypatch.setattr(affectation_service, "validate_allocations", _fake)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/affectations:validate")
    assert r.status_code == 200
    body = r.json()
    assert body["valide"] is False
    assert len(body["issues"]) == 1
    assert body["issues"][0]["code"] == "ecart_above_tolerance"


# ---------------------------------------------------------------------------
# §10.4 GET /suivi-affectations
# ---------------------------------------------------------------------------


def test_get_suivi_affectations_200(client, monkeypatch):
    async def _fake(doc, company):
        return [
            SuiviAffectationRead(
                id=uuid4(),
                company_id=COMPANY,
                document_id=DOC_ID,
                etablissement_id=ETS_ID,
                compte_m22bis="11501",
                solde_debut_n=Decimal("500"),
                mouvements_credit=Decimal("1000"),
                mouvements_debit=Decimal("0"),
                solde_fin_n=Decimal("1500"),
                created_at=datetime.now(UTC),
            )
        ]

    monkeypatch.setattr(affectation_service, "list_suivi_affectations", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/suivi-affectations")
    assert r.status_code == 200
    body = r.json()
    assert len(body) == 1
    assert body[0]["solde_fin_n"] == "1500"


def test_get_suivi_affectations_404(client, monkeypatch):
    async def _fake(doc, company):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(affectation_service, "list_suivi_affectations", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/suivi-affectations")
    assert r.status_code == 404
