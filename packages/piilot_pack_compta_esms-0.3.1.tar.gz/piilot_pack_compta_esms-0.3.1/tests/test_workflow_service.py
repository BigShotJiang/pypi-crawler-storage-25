"""Tests pour :mod:`workflow_service` — orchestration avec mocks repo.

Couvre :

* ``apply_transition`` happy path par action (transmit/approve/reject/
  set_affectation) sur ERRD + EPRD-family.
* 404 ``document_not_found``, 403 cross_company, 403 ``role_required``,
  409 ``transition_refused`` (idempotence).
* Auto-flip executoire quand la 2e autorité valide.
* Audit payload posé avec from/to + autorite + motif.
* Guard équilibre journalise mode réel/strict (non-blocking en v0.2).
* ``get_transitions_allowed`` retourne le bon shape.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

import pytest

from piilot_pack_compta_esms.models.workflow import TransitionRequest
from piilot_pack_compta_esms.services import workflow_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
)

COMPANY = uuid4()
USER = uuid4()
DOC = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.workflow_service.run_in_thread",
        _passthrough,
    )


def _snapshot_row(
    *,
    statut: str = "brouillon",
    type_document: str = "errd",
    ars_at: datetime | None = None,
    cd_at: datetime | None = None,
    company_id: UUID = COMPANY,
) -> dict[str, Any]:
    return {
        "id": DOC,
        "company_id": company_id,
        "type_document": type_document,
        "statut": statut,
        "transmis_at": None,
        "executoire_at": None,
        "transmis_par_user_id": None,
        "approuve_par_ars_at": ars_at,
        "approuve_par_cd_at": cd_at,
        "approuve_par_ars_user_id": None,
        "approuve_par_cd_user_id": None,
        "rejete_at": None,
        "rejete_par_autorite": None,
        "motif_rejet": None,
        "affectation_definie_at": None,
    }


def _apply_returns(updated: dict[str, Any]):
    def _fake_apply(*, document_id, company_id, user_id, patch, audit_action, audit_payload):
        # Merge patch onto initial snapshot to produce the post-update row.
        result = dict(updated)
        for k, v in patch.items():
            result[k] = v
        result["captured_patch"] = patch
        result["captured_audit"] = audit_payload
        result["captured_action"] = audit_action
        return result

    return _fake_apply


# ---------------------------------------------------------------------------
# 404 / 403 cases
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_apply_transition_document_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: None)
    with pytest.raises(NotFoundError) as exc:
        await workflow_service.apply_transition(
            document_id=DOC,
            payload=TransitionRequest(action="transmit"),
            company_id=COMPANY,
            user_id=USER,
            role="builder",
        )
    assert exc.value.code == "document_not_found"


@pytest.mark.asyncio
async def test_apply_transition_cross_company(monkeypatch, patch_run_in_thread):
    other_company = uuid4()
    monkeypatch.setattr(
        workflow_service.workflow_repo,
        "load_snapshot",
        lambda doc: _snapshot_row(company_id=other_company),
    )
    with pytest.raises(CrossCompanyError) as exc:
        await workflow_service.apply_transition(
            document_id=DOC,
            payload=TransitionRequest(action="transmit"),
            company_id=COMPANY,
            user_id=USER,
            role="builder",
        )
    assert exc.value.code == "document_cross_company"


@pytest.mark.asyncio
async def test_apply_transition_role_required_maps_to_cross_company(
    monkeypatch, patch_run_in_thread
):
    monkeypatch.setattr(
        workflow_service.workflow_repo,
        "load_snapshot",
        lambda doc: _snapshot_row(statut="brouillon", type_document="errd"),
    )
    with pytest.raises(CrossCompanyError) as exc:
        await workflow_service.apply_transition(
            document_id=DOC,
            payload=TransitionRequest(action="transmit"),
            company_id=COMPANY,
            user_id=USER,
            role="user",  # not allowed
        )
    assert exc.value.code == "role_required"


@pytest.mark.asyncio
async def test_apply_transition_idempotence_refused(monkeypatch, patch_run_in_thread):
    """Re-transmit on already-transmis ERRD → 409."""
    monkeypatch.setattr(
        workflow_service.workflow_repo,
        "load_snapshot",
        lambda doc: _snapshot_row(statut="transmis"),
    )
    with pytest.raises(ConflictError) as exc:
        await workflow_service.apply_transition(
            document_id=DOC,
            payload=TransitionRequest(action="transmit"),
            company_id=COMPANY,
            user_id=USER,
            role="builder",
        )
    assert exc.value.code == "transition_not_allowed_from_statut"


# ---------------------------------------------------------------------------
# Happy paths — transmit + set_affectation (ERRD)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_apply_transmit_errd_happy(monkeypatch, patch_run_in_thread):
    initial = _snapshot_row(statut="brouillon", type_document="errd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _apply_returns(initial))
    # No equilibre context needed for ERRD transmit (no R.314-222)
    monkeypatch.setattr(
        workflow_service.workflow_repo,
        "load_equilibre_context",
        lambda doc: {
            "type_document": "errd",
            "nature_juridique": "PRIVE_NON_LUCRATIF",
            "any_inclus_cpom": False,
        },
    )
    resp = await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(action="transmit"),
        company_id=COMPANY,
        user_id=USER,
        role="builder",
    )
    assert resp.statut_before == "brouillon"
    assert resp.statut_after == "transmis"
    assert resp.action == "transmit"
    assert resp.transmis_at is not None
    assert resp.double_validation.applicable is False  # ERRD


@pytest.mark.asyncio
async def test_apply_set_affectation_errd_happy(monkeypatch, patch_run_in_thread):
    initial = _snapshot_row(statut="transmis", type_document="errd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _apply_returns(initial))
    resp = await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(action="set_affectation"),
        company_id=COMPANY,
        user_id=USER,
        role="admin",
    )
    assert resp.statut_before == "transmis"
    assert resp.statut_after == "affectation_definie"
    assert resp.affectation_definie_at is not None


# ---------------------------------------------------------------------------
# Happy paths — EPRD double validation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_apply_transmit_eprd_flips_en_instruction(monkeypatch, patch_run_in_thread):
    """EPRD : transmit collapse → en_instruction direct."""
    initial = _snapshot_row(statut="brouillon", type_document="eprd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _apply_returns(initial))
    monkeypatch.setattr(
        workflow_service.workflow_repo,
        "load_equilibre_context",
        lambda doc: {
            "type_document": "eprd",
            "nature_juridique": "PRIVE_NON_LUCRATIF",
            "any_inclus_cpom": True,  # CPOM → équilibre réel
        },
    )
    resp = await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(action="transmit"),
        company_id=COMPANY,
        user_id=USER,
        role="builder",
    )
    assert resp.statut_after == "en_instruction"
    assert resp.double_validation.applicable is True


@pytest.mark.asyncio
async def test_apply_approve_ars_alone_stays_en_instruction(monkeypatch, patch_run_in_thread):
    initial = _snapshot_row(statut="en_instruction", type_document="eprd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _apply_returns(initial))
    resp = await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(action="approve", autorite="ars"),
        company_id=COMPANY,
        user_id=USER,
        role="admin",
    )
    assert resp.statut_after == "en_instruction"
    assert resp.autorite == "ars"


@pytest.mark.asyncio
async def test_apply_approve_cd_after_ars_flips_executoire(monkeypatch, patch_run_in_thread):
    now = datetime.now(tz=UTC)
    initial = _snapshot_row(statut="en_instruction", type_document="eprd", ars_at=now)
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    captured: dict = {}

    def _fake_apply(*, document_id, company_id, user_id, patch, audit_action, audit_payload):
        captured["patch"] = patch
        captured["audit"] = audit_payload
        result = dict(initial)
        result.update(patch)
        return result

    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _fake_apply)
    resp = await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(action="approve", autorite="cd"),
        company_id=COMPANY,
        user_id=USER,
        role="admin",
    )
    assert resp.statut_after == "executoire"
    assert resp.executoire_at is not None
    assert captured["patch"]["statut"] == "executoire"
    assert "executoire_at" in captured["patch"]
    assert captured["audit"]["auto_flip_executoire"] is True


@pytest.mark.asyncio
async def test_apply_reject_eprd_terminal(monkeypatch, patch_run_in_thread):
    initial = _snapshot_row(statut="en_instruction", type_document="eprd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    captured: dict = {}

    def _fake_apply(*, document_id, company_id, user_id, patch, audit_action, audit_payload):
        captured["patch"] = patch
        captured["audit"] = audit_payload
        result = dict(initial)
        result.update(patch)
        return result

    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _fake_apply)
    resp = await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(
            action="reject", autorite="ars", motif="Recettes tarifs incohérentes"
        ),
        company_id=COMPANY,
        user_id=USER,
        role="admin",
    )
    assert resp.statut_after == "rejete"
    assert resp.motif_rejet == "Recettes tarifs incohérentes"
    assert resp.rejete_par_autorite == "ars"
    assert captured["audit"]["motif"] == "Recettes tarifs incohérentes"
    assert captured["audit"]["autorite"] == "ars"


# ---------------------------------------------------------------------------
# Guard équilibre — non-blocking en v0.2, mais audit log mode applicable
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_apply_transmit_eprd_cpom_logs_reel_in_audit(monkeypatch, patch_run_in_thread):
    """EPRD inclus CPOM → audit_payload['equilibre_applicable'] == 'reel'."""
    initial = _snapshot_row(statut="brouillon", type_document="eprd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    monkeypatch.setattr(
        workflow_service.workflow_repo,
        "load_equilibre_context",
        lambda doc: {
            "type_document": "eprd",
            "nature_juridique": "PRIVE_NON_LUCRATIF",
            "any_inclus_cpom": True,
        },
    )
    captured: dict = {}

    def _fake_apply(*, document_id, company_id, user_id, patch, audit_action, audit_payload):
        captured["audit"] = audit_payload
        result = dict(initial)
        result.update(patch)
        return result

    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _fake_apply)
    await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(action="transmit"),
        company_id=COMPANY,
        user_id=USER,
        role="builder",
    )
    assert captured["audit"]["equilibre_applicable"] == "reel"


@pytest.mark.asyncio
async def test_apply_transmit_eprd_no_cpom_logs_strict_in_audit(monkeypatch, patch_run_in_thread):
    """EPRD hors CPOM → audit_payload['equilibre_applicable'] == 'strict'."""
    initial = _snapshot_row(statut="brouillon", type_document="eprd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    monkeypatch.setattr(
        workflow_service.workflow_repo,
        "load_equilibre_context",
        lambda doc: {
            "type_document": "eprd",
            "nature_juridique": "ETABLISSEMENT_PUBLIC_SANTE",
            "any_inclus_cpom": False,
        },
    )

    def _fake_apply(*, document_id, company_id, user_id, patch, audit_action, audit_payload):
        result = dict(initial)
        result.update(patch)
        result["_audit"] = audit_payload
        return result

    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _fake_apply)
    resp = await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(action="transmit"),
        company_id=COMPANY,
        user_id=USER,
        role="builder",
    )
    assert resp.statut_after == "en_instruction"


# ---------------------------------------------------------------------------
# transitions_allowed
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_transitions_allowed_brouillon_user_role(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        workflow_service.workflow_repo,
        "load_snapshot",
        lambda doc: _snapshot_row(statut="brouillon", type_document="errd"),
    )
    resp = await workflow_service.get_transitions_allowed(
        document_id=DOC, company_id=COMPANY, role="user"
    )
    assert resp.current_statut == "brouillon"
    actions = {a.action for a in resp.allowed}
    assert "transmit" not in actions  # blocked for user role
    reasons = {(b.action, b.reason) for b in resp.blocked}
    assert ("transmit", "role_required") in reasons


@pytest.mark.asyncio
async def test_transitions_allowed_eprd_en_instruction_admin(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        workflow_service.workflow_repo,
        "load_snapshot",
        lambda doc: _snapshot_row(statut="en_instruction", type_document="eprd"),
    )
    resp = await workflow_service.get_transitions_allowed(
        document_id=DOC, company_id=COMPANY, role="admin"
    )
    pairs = {(a.action, a.autorite) for a in resp.allowed}
    assert ("approve", "ars") in pairs
    assert ("approve", "cd") in pairs
    assert ("reject", "ars") in pairs
    assert ("reject", "cd") in pairs
    assert resp.double_validation.applicable is True


# ---------------------------------------------------------------------------
# §BF — Workflow EPRD double validation ARS/CD parallèle (durcissement)
# ---------------------------------------------------------------------------
# Ces tests complètent les scénarios v0.2 §S (ARS first → CD → executoire,
# reject ARS) pour atteindre une couverture symétrique CD-first et durcir
# l'idempotence + les transitions interdites depuis les états terminaux
# (rejete / executoire). Aucune modif de code §BF : la state machine et le
# patch builder couvrent déjà 100% des cas, seuls les tests manquaient.
# ---------------------------------------------------------------------------


# §BF.1 — Scénario 2 symétrique : CD first, then ARS → executoire ------------


@pytest.mark.asyncio
async def test_apply_approve_cd_alone_stays_en_instruction(monkeypatch, patch_run_in_thread):
    """Mirror de test_apply_approve_ars_alone_stays_en_instruction.

    CD approuve en premier (ARS pas encore) → le statut reste
    ``en_instruction`` (pas de flip executoire) et la réponse expose
    ``autorite='cd'``.
    """
    initial = _snapshot_row(statut="en_instruction", type_document="eprd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _apply_returns(initial))
    resp = await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(action="approve", autorite="cd"),
        company_id=COMPANY,
        user_id=USER,
        role="admin",
    )
    assert resp.statut_after == "en_instruction"
    assert resp.autorite == "cd"
    # executoire_at ne doit pas être posé tant que les 2 ATC ne sont pas OK
    assert resp.executoire_at is None


@pytest.mark.asyncio
async def test_apply_approve_ars_after_cd_flips_executoire(monkeypatch, patch_run_in_thread):
    """Symétrique de test_apply_approve_cd_after_ars_flips_executoire.

    CD a déjà approuvé → ARS valide → flip auto en ``executoire`` avec
    ``executoire_at`` posé et ``auto_flip_executoire=True`` dans
    l'audit_payload.
    """
    now = datetime.now(tz=UTC)
    initial = _snapshot_row(statut="en_instruction", type_document="eprd", cd_at=now)
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    captured: dict = {}

    def _fake_apply(*, document_id, company_id, user_id, patch, audit_action, audit_payload):
        captured["patch"] = patch
        captured["audit"] = audit_payload
        result = dict(initial)
        result.update(patch)
        return result

    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _fake_apply)
    resp = await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(action="approve", autorite="ars"),
        company_id=COMPANY,
        user_id=USER,
        role="admin",
    )
    assert resp.statut_after == "executoire"
    assert resp.executoire_at is not None
    assert captured["patch"]["statut"] == "executoire"
    assert "executoire_at" in captured["patch"]
    assert "approuve_par_ars_at" in captured["patch"]
    # CD était déjà approuvé via le snapshot initial — pas de re-posage
    assert "approuve_par_cd_at" not in captured["patch"]
    assert captured["audit"]["auto_flip_executoire"] is True
    assert captured["audit"]["autorite"] == "ars"


# §BF.2 — Reject CD terminal symétrique --------------------------------------


@pytest.mark.asyncio
async def test_apply_reject_cd_eprd_terminal(monkeypatch, patch_run_in_thread):
    """Mirror de test_apply_reject_eprd_terminal côté CD.

    Un seul rejet (CD) emporte le rejet global (S03 FAQ DGCS p.15,
    plan-dev L317). ``rejete_par_autorite='cd'`` + motif posés.
    """
    initial = _snapshot_row(statut="en_instruction", type_document="eprd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    captured: dict = {}

    def _fake_apply(*, document_id, company_id, user_id, patch, audit_action, audit_payload):
        captured["patch"] = patch
        captured["audit"] = audit_payload
        result = dict(initial)
        result.update(patch)
        return result

    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _fake_apply)
    resp = await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(
            action="reject", autorite="cd", motif="Capacités EHPAD non conformes au CPOM"
        ),
        company_id=COMPANY,
        user_id=USER,
        role="admin",
    )
    assert resp.statut_after == "rejete"
    assert resp.rejete_par_autorite == "cd"
    assert resp.motif_rejet == "Capacités EHPAD non conformes au CPOM"
    assert captured["audit"]["autorite"] == "cd"
    assert captured["audit"]["motif"] == "Capacités EHPAD non conformes au CPOM"


# §BF.3 — Idempotence double-approve -----------------------------------------


@pytest.mark.asyncio
async def test_apply_approve_ars_twice_blocks_already_approved(monkeypatch, patch_run_in_thread):
    """ARS a déjà approuvé → 2e approve ARS → ConflictError
    ``already_approved`` (la state machine guard, repo jamais appelé).
    """
    now = datetime.now(tz=UTC)
    initial = _snapshot_row(statut="en_instruction", type_document="eprd", ars_at=now)
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)

    def _should_not_be_called(**kwargs):  # pragma: no cover — defensive
        raise AssertionError("apply_transition repo must not be called on rejected guard")

    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _should_not_be_called)

    with pytest.raises(ConflictError) as exc:
        await workflow_service.apply_transition(
            document_id=DOC,
            payload=TransitionRequest(action="approve", autorite="ars"),
            company_id=COMPANY,
            user_id=USER,
            role="admin",
        )
    assert exc.value.code == "already_approved"


@pytest.mark.asyncio
async def test_apply_approve_cd_twice_blocks_already_approved(monkeypatch, patch_run_in_thread):
    """CD a déjà approuvé → 2e approve CD → ConflictError ``already_approved``."""
    now = datetime.now(tz=UTC)
    initial = _snapshot_row(statut="en_instruction", type_document="eprd", cd_at=now)
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)

    def _should_not_be_called(**kwargs):  # pragma: no cover — defensive
        raise AssertionError("apply_transition repo must not be called on rejected guard")

    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _should_not_be_called)

    with pytest.raises(ConflictError) as exc:
        await workflow_service.apply_transition(
            document_id=DOC,
            payload=TransitionRequest(action="approve", autorite="cd"),
            company_id=COMPANY,
            user_id=USER,
            role="admin",
        )
    assert exc.value.code == "already_approved"


# §BF.4 — Transitions interdites depuis rejete / executoire ------------------


@pytest.mark.asyncio
async def test_apply_approve_cd_from_rejete_blocked(monkeypatch, patch_run_in_thread):
    """Doc rejeté par ARS → tentative approve CD → refusée.

    Le rejet d'une autorité emporte le rejet global (rejete = terminal).
    can_apply renvoie ``transition_not_allowed_from_statut``.
    """
    initial = _snapshot_row(statut="rejete", type_document="eprd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    with pytest.raises(ConflictError) as exc:
        await workflow_service.apply_transition(
            document_id=DOC,
            payload=TransitionRequest(action="approve", autorite="cd"),
            company_id=COMPANY,
            user_id=USER,
            role="admin",
        )
    assert exc.value.code == "transition_not_allowed_from_statut"


@pytest.mark.asyncio
async def test_apply_reject_cd_from_rejete_blocked(monkeypatch, patch_run_in_thread):
    """Doc rejeté par ARS → tentative reject CD aussi → refusée (terminal)."""
    initial = _snapshot_row(statut="rejete", type_document="eprd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    with pytest.raises(ConflictError) as exc:
        await workflow_service.apply_transition(
            document_id=DOC,
            payload=TransitionRequest(action="reject", autorite="cd", motif="double rejet inutile"),
            company_id=COMPANY,
            user_id=USER,
            role="admin",
        )
    assert exc.value.code == "transition_not_allowed_from_statut"


@pytest.mark.asyncio
async def test_apply_approve_from_executoire_blocked(monkeypatch, patch_run_in_thread):
    """Doc déjà executoire → toute approve refusée (les 2 ATC ont validé)."""
    initial = _snapshot_row(statut="executoire", type_document="eprd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    with pytest.raises(ConflictError) as exc:
        await workflow_service.apply_transition(
            document_id=DOC,
            payload=TransitionRequest(action="approve", autorite="ars"),
            company_id=COMPANY,
            user_id=USER,
            role="admin",
        )
    assert exc.value.code == "transition_not_allowed_from_statut"


# §BF.5 — Isolation patch builder (colonnes side strictes) -------------------


@pytest.mark.asyncio
async def test_apply_approve_ars_alone_patch_isolation(monkeypatch, patch_run_in_thread):
    """Approve ARS seul → patch ne touche QUE approuve_par_ars_{at,user_id}
    + statut. Ne pose PAS executoire_at, NI approuve_par_cd_*.
    """
    initial = _snapshot_row(statut="en_instruction", type_document="eprd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    captured: dict = {}

    def _fake_apply(*, document_id, company_id, user_id, patch, audit_action, audit_payload):
        captured["patch"] = patch
        captured["audit"] = audit_payload
        result = dict(initial)
        result.update(patch)
        return result

    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _fake_apply)
    await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(action="approve", autorite="ars"),
        company_id=COMPANY,
        user_id=USER,
        role="admin",
    )
    patch = captured["patch"]
    # Présentes
    assert "approuve_par_ars_at" in patch
    assert "approuve_par_ars_user_id" in patch
    assert patch["statut"] == "en_instruction"
    # Absentes (CD non touché, executoire pas encore déclenché)
    assert "approuve_par_cd_at" not in patch
    assert "approuve_par_cd_user_id" not in patch
    assert "executoire_at" not in patch
    assert "rejete_at" not in patch
    # Audit ne contient pas auto_flip_executoire
    assert "auto_flip_executoire" not in captured["audit"]


@pytest.mark.asyncio
async def test_apply_approve_cd_alone_patch_isolation(monkeypatch, patch_run_in_thread):
    """Approve CD seul → patch symétrique : ne touche QUE approuve_par_cd_*
    + statut. Ne pose PAS executoire_at, NI approuve_par_ars_*.
    """
    initial = _snapshot_row(statut="en_instruction", type_document="eprd")
    monkeypatch.setattr(workflow_service.workflow_repo, "load_snapshot", lambda doc: initial)
    captured: dict = {}

    def _fake_apply(*, document_id, company_id, user_id, patch, audit_action, audit_payload):
        captured["patch"] = patch
        captured["audit"] = audit_payload
        result = dict(initial)
        result.update(patch)
        return result

    monkeypatch.setattr(workflow_service.workflow_repo, "apply_transition", _fake_apply)
    await workflow_service.apply_transition(
        document_id=DOC,
        payload=TransitionRequest(action="approve", autorite="cd"),
        company_id=COMPANY,
        user_id=USER,
        role="admin",
    )
    patch = captured["patch"]
    # Présentes
    assert "approuve_par_cd_at" in patch
    assert "approuve_par_cd_user_id" in patch
    assert patch["statut"] == "en_instruction"
    # Absentes
    assert "approuve_par_ars_at" not in patch
    assert "approuve_par_ars_user_id" not in patch
    assert "executoire_at" not in patch
    assert "rejete_at" not in patch
    assert "auto_flip_executoire" not in captured["audit"]
