"""Unit tests for :mod:`piilot_pack_compta_esms.services.feature_catalog_service`."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from piilot_pack_compta_esms.services import feature_catalog_service
from piilot_pack_compta_esms.services.errors import NotFoundError


def _make_row(**overrides):
    base = {
        "feature_key": "crp_charges_g1",
        "label": "CRP — Charges G1",
        "description": None,
        "columns_required": {"compte": "text", "montant": "numeric"},
        "is_mandatory": True,
        "applicable_typologies": [],
        "applicable_doc_types": ["eprd", "errd"],
        "plan_comptable_cible": "M22Bis",
        "contract_version": 1,
        "ordre": 11,
        "created_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.feature_catalog_service.run_in_thread",
        _passthrough,
    )


@pytest.mark.asyncio
async def test_list_features_passes_filters(monkeypatch, patch_run_in_thread):
    captured: dict = {}

    def _fake_list_all(*, doc_type, typologie, mandatory_only):
        captured["doc_type"] = doc_type
        captured["typologie"] = typologie
        captured["mandatory_only"] = mandatory_only
        return [_make_row()]

    monkeypatch.setattr(feature_catalog_service.feature_catalog_repo, "list_all", _fake_list_all)
    out = await feature_catalog_service.list_features(
        doc_type="eprd", typologie="ehpad", mandatory_only=True
    )
    assert captured == {"doc_type": "eprd", "typologie": "ehpad", "mandatory_only": True}
    assert len(out) == 1
    assert out[0].feature_key == "crp_charges_g1"


@pytest.mark.asyncio
async def test_list_features_empty(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        feature_catalog_service.feature_catalog_repo,
        "list_all",
        lambda **kw: [],
    )
    assert await feature_catalog_service.list_features() == []


@pytest.mark.asyncio
async def test_get_feature_happy(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        feature_catalog_service.feature_catalog_repo,
        "get_by_key",
        lambda key: _make_row(feature_key=key),
    )
    out = await feature_catalog_service.get_feature("crp_charges_g1")
    assert out.feature_key == "crp_charges_g1"
    assert out.plan_comptable_cible == "M22Bis"


@pytest.mark.asyncio
async def test_get_feature_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        feature_catalog_service.feature_catalog_repo,
        "get_by_key",
        lambda key: None,
    )
    with pytest.raises(NotFoundError) as exc:
        await feature_catalog_service.get_feature("ghost")
    assert exc.value.code == "feature_not_found"
