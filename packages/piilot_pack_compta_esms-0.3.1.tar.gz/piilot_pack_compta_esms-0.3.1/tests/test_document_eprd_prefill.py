"""Tests §BC.6 — hook ``_prefill_eprd_structural_crpas`` au create EPRD.

Couvre :
* Quand type='eprd', le hook appelle compute_eprd_structure
* Les CRPA spec sont insérés via cr_repo.create
* Les autres types (errd, dm, ria) ne déclenchent PAS le hook
* Si compute_eprd_structure échoue, le doc reste créé (skip silencieux)
* Les CrpSpec sans etablissement_id ne carriy pas la clé dans le payload
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.document import DocumentCreate
from piilot_pack_compta_esms.models.eprd_structure import (
    AnnexeSpec,
    CrpSpec,
    EprdStructureSpec,
)
from piilot_pack_compta_esms.services import document_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
EXERCICE_ID = uuid4()
OG_ID = uuid4()
DOC_ID = uuid4()
ETS_A = uuid4()
ETS_B = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.document_service.run_in_thread",
        _passthrough,
    )


def _exercice_lookup(annee: int = 2026) -> dict:
    return {
        "id": EXERCICE_ID,
        "og_id": OG_ID,
        "annee": annee,
        "company_id": COMPANY,
    }


def _doc_row(type_document: str = "eprd", annee: int = 2026) -> dict:
    return {
        "id": DOC_ID,
        "company_id": COMPANY,
        "exercice_id": EXERCICE_ID,
        "type_document": type_document,
        "cadre_version": f"#EPRDHA-{annee + 1}-01#",
        "parent_id": None,
        "statut": "brouillon",
        "periode_observation_debut": None,
        "periode_observation_fin": None,
        "transmis_at": None,
        "executoire_at": None,
        "transmis_par_user_id": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }


def _make_spec(crps: list[CrpSpec]) -> EprdStructureSpec:
    return EprdStructureSpec(
        og_id=OG_ID,
        nature_juridique="ESMS_PUBLIC_AUTONOME",
        crps=crps,
        annexes=[
            AnnexeSpec(code="4", obligatoire=True, description="Activité"),
        ],
        equilibre_applicable_initial="STRICT",
        notes=[],
    )


# --------------------------------------------------------------------
# Hook actif pour type='eprd'
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_eprd_triggers_prefill_with_crpas(monkeypatch, patch_run_in_thread):
    """type='eprd' → compute_eprd_structure + cr_repo.create pour chaque CrpSpec."""
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: _exercice_lookup(),
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "create_with_default_crpp",
        lambda **kw: _doc_row(),
    )

    async def _fake_compute(og_id):
        return _make_spec(
            [
                CrpSpec(
                    cr_type="CRPA",
                    cr_variante="soumis_equilibre",
                    etablissement_id=ETS_A,
                    denomination="CRPA — Alpha",
                    ordre=1,
                ),
                CrpSpec(
                    cr_type="CRPA",
                    cr_variante="soumis_equilibre",
                    etablissement_id=ETS_B,
                    denomination="CRPA — Bravo",
                    ordre=2,
                ),
            ]
        )

    monkeypatch.setattr(
        document_service.eprd_structure_service,
        "compute_eprd_structure",
        _fake_compute,
    )

    captured_creates: list[dict] = []

    def _fake_cr_create(company_id, document_id, payload):
        captured_creates.append(payload)
        return {"id": uuid4(), **payload}

    monkeypatch.setattr(document_service.cr_repo, "create", _fake_cr_create)

    await document_service.create_document(
        COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="eprd")
    )

    # 2 CRPA insérés.
    assert len(captured_creates) == 2
    assert captured_creates[0]["cr_type"] == "CRPA"
    assert captured_creates[0]["denomination"] == "CRPA — Alpha"
    assert captured_creates[0]["etablissement_id"] == str(ETS_A)
    assert captured_creates[1]["etablissement_id"] == str(ETS_B)


@pytest.mark.asyncio
async def test_eprd_prefill_handles_crps_without_etablissement_id(monkeypatch, patch_run_in_thread):
    """Si le CrpSpec a etablissement_id=None, la clé n'est pas envoyée
    au repo (sinon le repo writerait NULL explicite)."""
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: _exercice_lookup(),
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "create_with_default_crpp",
        lambda **kw: _doc_row(),
    )

    async def _fake_compute(og_id):
        return _make_spec(
            [
                CrpSpec(
                    cr_type="CRPA",
                    cr_variante="soumis_equilibre",
                    etablissement_id=None,
                    denomination="CRPA générique",
                    ordre=1,
                ),
            ]
        )

    monkeypatch.setattr(
        document_service.eprd_structure_service,
        "compute_eprd_structure",
        _fake_compute,
    )

    captured: list[dict] = []

    def _fake_cr_create(company_id, document_id, payload):
        captured.append(payload)
        return {"id": uuid4(), **payload}

    monkeypatch.setattr(document_service.cr_repo, "create", _fake_cr_create)

    await document_service.create_document(
        COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="eprd")
    )

    assert len(captured) == 1
    assert "etablissement_id" not in captured[0]


@pytest.mark.asyncio
async def test_eprd_prefill_with_empty_crps_no_calls(monkeypatch, patch_run_in_thread):
    """Si compute_eprd_structure retourne crps=[] (cas PRIVE_COMMERCIAL
    / CCAS / ESMS sans ESMS suppl), cr_repo.create n'est pas appelé."""
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: _exercice_lookup(),
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "create_with_default_crpp",
        lambda **kw: _doc_row(),
    )

    async def _fake_compute(og_id):
        return _make_spec([])

    monkeypatch.setattr(
        document_service.eprd_structure_service,
        "compute_eprd_structure",
        _fake_compute,
    )

    captured: list[dict] = []

    def _fake_cr_create(company_id, document_id, payload):
        captured.append(payload)
        return {}

    monkeypatch.setattr(document_service.cr_repo, "create", _fake_cr_create)

    await document_service.create_document(
        COMPANY, DocumentCreate(exercice_id=EXERCICE_ID, type_document="eprd")
    )
    assert captured == []


# --------------------------------------------------------------------
# Hook NE déclenche PAS pour les autres types
# --------------------------------------------------------------------


@pytest.mark.asyncio
@pytest.mark.parametrize("doc_type", ["errd", "dm", "ria"])
async def test_non_eprd_does_not_trigger_prefill(monkeypatch, patch_run_in_thread, doc_type):
    """ERRD/DM/RIA/AVENANT — pas de hook. Le CRPP par défaut suffit."""
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: _exercice_lookup(),
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "load_parent_for_clone",
        lambda _: {
            "id": uuid4(),
            "company_id": COMPANY,
            "type_document": "eprd",
            "exercice_id": EXERCICE_ID,
        },
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "create_with_default_crpp",
        lambda **kw: _doc_row(type_document=doc_type),
    )

    compute_called = False

    async def _fake_compute(og_id):
        nonlocal compute_called
        compute_called = True
        return _make_spec([])

    monkeypatch.setattr(
        document_service.eprd_structure_service,
        "compute_eprd_structure",
        _fake_compute,
    )

    # DM/RIA exigent un parent_id ; on en fournit un.
    parent_id = uuid4() if doc_type in ("dm", "ria") else None
    await document_service.create_document(
        COMPANY,
        DocumentCreate(
            exercice_id=EXERCICE_ID,
            type_document=doc_type,
            parent_id=parent_id,
        ),
    )
    assert compute_called is False


# --------------------------------------------------------------------
# Skip silencieux si compute_eprd_structure échoue
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_eprd_prefill_skips_silently_on_compute_error(
    monkeypatch, patch_run_in_thread, caplog
):
    """Le document est déjà créé en DB — si compute échoue, on log et
    on ne re-raise pas (sinon le doc serait perdu côté API)."""
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: _exercice_lookup(),
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "create_with_default_crpp",
        lambda **kw: _doc_row(),
    )

    async def _failing_compute(og_id):
        raise NotFoundError(f"OG {og_id} not found", code="og_not_found")

    monkeypatch.setattr(
        document_service.eprd_structure_service,
        "compute_eprd_structure",
        _failing_compute,
    )

    create_called = False

    def _fake_cr_create(company_id, document_id, payload):
        nonlocal create_called
        create_called = True
        return {}

    monkeypatch.setattr(document_service.cr_repo, "create", _fake_cr_create)

    with caplog.at_level("WARNING"):
        out = await document_service.create_document(
            COMPANY,
            DocumentCreate(exercice_id=EXERCICE_ID, type_document="eprd"),
        )
    # Document créé malgré l'échec du prefill.
    assert out.id == DOC_ID
    assert create_called is False
    # Trace warning posée.
    assert any("pre-fill skipped" in r.message for r in caplog.records)


@pytest.mark.asyncio
async def test_eprd_prefill_skips_silently_on_unexpected_error(
    monkeypatch, patch_run_in_thread, caplog
):
    """Même behavior pour les exceptions inattendues (ex. DB down)."""
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: _exercice_lookup(),
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "create_with_default_crpp",
        lambda **kw: _doc_row(),
    )

    async def _exploding(og_id):
        raise RuntimeError("DB connection lost")

    monkeypatch.setattr(
        document_service.eprd_structure_service,
        "compute_eprd_structure",
        _exploding,
    )

    with caplog.at_level("WARNING"):
        out = await document_service.create_document(
            COMPANY,
            DocumentCreate(exercice_id=EXERCICE_ID, type_document="eprd"),
        )
    assert out.id == DOC_ID
    assert any("pre-fill skipped" in r.message for r in caplog.records)
