"""Unit tests for :mod:`piilot_pack_compta_esms.services.exercice_service`.

Same isolation pattern as the OG/Établissement service tests : mock
``run_in_thread`` to a sync passthrough, monkeypatch each ``exercice_repo``
function.

Year-window validation uses ``date.today().year`` ; we freeze it via
``monkeypatch.setattr(date, ...)`` so tests don't drift over time.
"""

from __future__ import annotations

from datetime import UTC, date, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.exercice import ExerciceCreate
from piilot_pack_compta_esms.services import exercice_service
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

COMPANY = uuid4()
OG_ID = uuid4()
EXERCICE_ID = uuid4()
FIXED_YEAR = 2026  # frozen via patch on date.today()


def _make_exercice_row(**overrides):
    base = {
        "id": EXERCICE_ID,
        "company_id": COMPANY,
        "og_id": OG_ID,
        "annee": FIXED_YEAR,
        "millesime_m22bis": "2025-2026",
        "created_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


class _FrozenDate(date):
    @classmethod
    def today(cls):
        return cls(FIXED_YEAR, 6, 15)


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.exercice_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def freeze_year(monkeypatch):
    """Freeze ``date.today()`` inside the service so year-window
    assertions don't drift with the calendar."""
    monkeypatch.setattr("piilot_pack_compta_esms.services.exercice_service.date", _FrozenDate)


@pytest.mark.asyncio
async def test_list_orders_descending(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        exercice_service.exercice_repo,
        "list_by_og",
        lambda og_id: [
            _make_exercice_row(annee=2026),
            _make_exercice_row(annee=2025),
        ],
    )
    out = await exercice_service.list_exercices(OG_ID)
    assert [e.annee for e in out] == [2026, 2025]


@pytest.mark.asyncio
async def test_get_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(exercice_service.exercice_repo, "get_by_id", lambda eid: None)
    with pytest.raises(NotFoundError):
        await exercice_service.get_exercice(EXERCICE_ID)


@pytest.mark.asyncio
async def test_create_happy_path_auto_millesime(monkeypatch, patch_run_in_thread, freeze_year):
    monkeypatch.setattr(
        exercice_service.exercice_repo,
        "og_exists_for_company",
        lambda og_id, company_id: True,
    )
    monkeypatch.setattr(
        exercice_service.exercice_repo,
        "find_by_og_annee",
        lambda og_id, annee: None,
    )
    captured = {}

    def _create(company_id, og_id, annee, millesime):
        captured["millesime"] = millesime
        return _make_exercice_row(annee=annee, millesime_m22bis=millesime)

    monkeypatch.setattr(exercice_service.exercice_repo, "create", _create)
    out = await exercice_service.create_exercice(COMPANY, OG_ID, ExerciceCreate(annee=2026))
    assert out.annee == 2026
    assert captured["millesime"] == "2025-2026"


@pytest.mark.asyncio
async def test_create_respects_explicit_millesime(monkeypatch, patch_run_in_thread, freeze_year):
    monkeypatch.setattr(
        exercice_service.exercice_repo,
        "og_exists_for_company",
        lambda og_id, company_id: True,
    )
    monkeypatch.setattr(
        exercice_service.exercice_repo,
        "find_by_og_annee",
        lambda og_id, annee: None,
    )
    captured = {}

    def _create(company_id, og_id, annee, millesime):
        captured["millesime"] = millesime
        return _make_exercice_row(annee=annee, millesime_m22bis=millesime)

    monkeypatch.setattr(exercice_service.exercice_repo, "create", _create)
    out = await exercice_service.create_exercice(
        COMPANY,
        OG_ID,
        ExerciceCreate(annee=2026, millesime_m22bis="2024-2025"),
    )
    assert captured["millesime"] == "2024-2025"
    assert out.millesime_m22bis == "2024-2025"


@pytest.mark.asyncio
async def test_create_year_out_of_window(monkeypatch, patch_run_in_thread, freeze_year):
    """Frozen year is 2026, so 2024 and 2028 must be rejected."""
    payload_low = ExerciceCreate(annee=2024)
    with pytest.raises(ConflictError) as exc:
        await exercice_service.create_exercice(COMPANY, OG_ID, payload_low)
    assert exc.value.code == "exercice_annee_out_of_window"

    payload_high = ExerciceCreate(annee=2028)
    with pytest.raises(ConflictError) as exc:
        await exercice_service.create_exercice(COMPANY, OG_ID, payload_high)
    assert exc.value.code == "exercice_annee_out_of_window"


@pytest.mark.asyncio
async def test_create_og_not_in_company(monkeypatch, patch_run_in_thread, freeze_year):
    monkeypatch.setattr(
        exercice_service.exercice_repo,
        "og_exists_for_company",
        lambda og_id, company_id: False,
    )
    with pytest.raises(NotFoundError):
        await exercice_service.create_exercice(COMPANY, OG_ID, ExerciceCreate(annee=2026))


@pytest.mark.asyncio
async def test_create_year_conflict(monkeypatch, patch_run_in_thread, freeze_year):
    monkeypatch.setattr(
        exercice_service.exercice_repo,
        "og_exists_for_company",
        lambda og_id, company_id: True,
    )
    monkeypatch.setattr(
        exercice_service.exercice_repo,
        "find_by_og_annee",
        lambda og_id, annee: _make_exercice_row(annee=annee),
    )
    with pytest.raises(ConflictError) as exc:
        await exercice_service.create_exercice(COMPANY, OG_ID, ExerciceCreate(annee=2026))
    assert exc.value.code == "exercice_annee_taken"
