"""Tests Pydantic models CPOM — §BA v0.3 (D-027).

Couvre :

* Literal allowed values (categorie, cosignataire, OuiNon, statut)
* Field bounds (duree_annees 1..7, longueurs max sur intitule /
  description / motif_prorogation)
* ``cosignataires`` non-vide + unique
* ``extra='forbid'`` rejette les champs inconnus
* ``Update`` accepte un payload partiel
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from uuid import uuid4

import pytest
from pydantic import ValidationError

from piilot_pack_compta_esms.models.cpom import (
    CpomCreate,
    CpomEsmsLinkItem,
    CpomObjectifCreate,
    CpomObjectifUpdate,
    CpomUpdate,
)

_BASE_CPOM_KWARGS: dict = {
    "og_id": uuid4(),
    "date_signature": date(2024, 1, 15),
    "date_effet": date(2024, 1, 1),
    "duree_annees": Decimal("5"),
    "categorie": "EHPAD_IVTER",
    "cosignataires": ["ARS", "CD"],
    "libre_affectation_resultats_o_n": "OUI",
}

_BASE_OBJ_KWARGS: dict = {
    "intitule": "Améliorer le taux d'occupation",
    "impact_eprd_o_n": "OUI",
}


# --------------------------------------------------------------------
# CpomCreate — happy paths + Literals
# --------------------------------------------------------------------


def test_create_cpom_minimal_payload_is_valid():
    obj = CpomCreate(**_BASE_CPOM_KWARGS)
    assert obj.numero is None
    assert obj.est_proroge is None
    assert obj.motif_prorogation is None
    assert obj.cosignataires == ["ARS", "CD"]


def test_create_cpom_with_all_optional_fields():
    obj = CpomCreate(
        **_BASE_CPOM_KWARGS,
        numero="CPOM-2024-001",
        est_proroge="NON",
        motif_prorogation="N/A",
    )
    assert obj.numero == "CPOM-2024-001"
    assert obj.est_proroge == "NON"


def test_categorie_accepts_5_dgcs_values():
    for value in (
        "EHPAD_IVTER",
        "ESMS_PH_SSIAD",
        "RESIDENCE_AUTONOMIE",
        "EHPAD_PUV",
        "MIXTE",
    ):
        obj = CpomCreate(**{**_BASE_CPOM_KWARGS, "categorie": value})
        assert obj.categorie == value


def test_categorie_rejects_unknown_value():
    with pytest.raises(ValidationError, match="categorie"):
        CpomCreate(**{**_BASE_CPOM_KWARGS, "categorie": "EHPAD_DROIT_COMMUN"})


def test_cosignataires_accepts_3_dgcs_values():
    obj = CpomCreate(**{**_BASE_CPOM_KWARGS, "cosignataires": ["ARS_CD_TRIPARTITE"]})
    assert obj.cosignataires == ["ARS_CD_TRIPARTITE"]


def test_cosignataires_rejects_unknown_value():
    with pytest.raises(ValidationError, match="cosignataires"):
        CpomCreate(**{**_BASE_CPOM_KWARGS, "cosignataires": ["ARS", "PREFET"]})


def test_cosignataires_rejects_empty_list():
    with pytest.raises(ValidationError, match="cosignataires"):
        CpomCreate(**{**_BASE_CPOM_KWARGS, "cosignataires": []})


def test_cosignataires_rejects_duplicates():
    with pytest.raises(ValidationError, match="unique"):
        CpomCreate(**{**_BASE_CPOM_KWARGS, "cosignataires": ["ARS", "ARS"]})


def test_libre_affectation_accepts_oui_non():
    for value in ("OUI", "NON"):
        obj = CpomCreate(**{**_BASE_CPOM_KWARGS, "libre_affectation_resultats_o_n": value})
        assert obj.libre_affectation_resultats_o_n == value


def test_libre_affectation_rejects_bool():
    with pytest.raises(ValidationError, match="libre_affectation"):
        CpomCreate(**{**_BASE_CPOM_KWARGS, "libre_affectation_resultats_o_n": True})


# --------------------------------------------------------------------
# duree_annees bounds
# --------------------------------------------------------------------


def test_duree_annees_1_year_minimum_accepted():
    obj = CpomCreate(**{**_BASE_CPOM_KWARGS, "duree_annees": Decimal("1")})
    assert obj.duree_annees == Decimal("1")


def test_duree_annees_7_years_max_accepted():
    obj = CpomCreate(**{**_BASE_CPOM_KWARGS, "duree_annees": Decimal("7")})
    assert obj.duree_annees == Decimal("7")


def test_duree_annees_fractional_accepted_for_puv_prorogation():
    obj = CpomCreate(**{**_BASE_CPOM_KWARGS, "duree_annees": Decimal("5.5")})
    assert obj.duree_annees == Decimal("5.5")


def test_duree_annees_below_1_rejected():
    with pytest.raises(ValidationError, match="duree_annees"):
        CpomCreate(**{**_BASE_CPOM_KWARGS, "duree_annees": Decimal("0.9")})


def test_duree_annees_above_7_rejected():
    with pytest.raises(ValidationError, match="duree_annees"):
        CpomCreate(**{**_BASE_CPOM_KWARGS, "duree_annees": Decimal("7.1")})


# --------------------------------------------------------------------
# motif_prorogation length
# --------------------------------------------------------------------


def test_motif_prorogation_max_500():
    obj = CpomCreate(**{**_BASE_CPOM_KWARGS, "motif_prorogation": "a" * 500})
    assert len(obj.motif_prorogation or "") == 500


def test_motif_prorogation_rejects_501_chars():
    with pytest.raises(ValidationError, match="motif_prorogation"):
        CpomCreate(**{**_BASE_CPOM_KWARGS, "motif_prorogation": "a" * 501})


# --------------------------------------------------------------------
# extra='forbid'
# --------------------------------------------------------------------


def test_unknown_field_rejected_on_create():
    with pytest.raises(ValidationError, match="ghost"):
        CpomCreate(**_BASE_CPOM_KWARGS, ghost="value")  # type: ignore


def test_unknown_field_rejected_on_update():
    with pytest.raises(ValidationError, match="ghost"):
        CpomUpdate(ghost="value")  # type: ignore


# --------------------------------------------------------------------
# CpomUpdate — partial payload
# --------------------------------------------------------------------


def test_update_empty_payload_is_valid():
    obj = CpomUpdate()
    assert obj.model_dump(exclude_none=True) == {}


def test_update_can_patch_single_field():
    obj = CpomUpdate(numero="REV-001")
    assert obj.numero == "REV-001"


def test_update_cosignataires_uniqueness_enforced():
    with pytest.raises(ValidationError, match="unique"):
        CpomUpdate(cosignataires=["ARS", "ARS"])


def test_update_cosignataires_none_is_valid():
    obj = CpomUpdate(cosignataires=None)
    assert obj.cosignataires is None


# --------------------------------------------------------------------
# Pipe char rejection (D-075)
# --------------------------------------------------------------------


def test_numero_rejects_pipe_char():
    with pytest.raises(ValidationError):
        CpomCreate(**{**_BASE_CPOM_KWARGS, "numero": "CPOM|001"})


def test_motif_prorogation_rejects_pipe_char():
    with pytest.raises(ValidationError):
        CpomCreate(**{**_BASE_CPOM_KWARGS, "motif_prorogation": "trop|long"})


# --------------------------------------------------------------------
# CpomEsmsLinkItem
# --------------------------------------------------------------------


def test_link_item_requires_inclus_dans_perimetre():
    with pytest.raises(ValidationError):
        CpomEsmsLinkItem(etablissement_id=uuid4())  # type: ignore


def test_link_item_inclus_perimetre_oui_non():
    for value in ("OUI", "NON"):
        item = CpomEsmsLinkItem(etablissement_id=uuid4(), inclus_dans_perimetre=value)
        assert item.inclus_dans_perimetre == value


def test_link_item_rejects_unknown_perimetre():
    with pytest.raises(ValidationError, match="inclus_dans_perimetre"):
        CpomEsmsLinkItem(etablissement_id=uuid4(), inclus_dans_perimetre="MAYBE")


def test_link_item_rejects_extra_field():
    with pytest.raises(ValidationError, match="extra"):
        CpomEsmsLinkItem(
            etablissement_id=uuid4(),
            inclus_dans_perimetre="OUI",
            ghost="x",  # type: ignore
        )


# --------------------------------------------------------------------
# CpomObjectif
# --------------------------------------------------------------------


def test_objectif_create_minimal_payload():
    obj = CpomObjectifCreate(**_BASE_OBJ_KWARGS)
    assert obj.intitule == "Améliorer le taux d'occupation"
    assert obj.statut is None


def test_objectif_create_with_full_payload():
    obj = CpomObjectifCreate(
        **_BASE_OBJ_KWARGS,
        description="Cible : 95% d'occupation à fin 2026",
        date_realisation_prevue=date(2026, 12, 31),
        statut="EN_COURS",
    )
    assert obj.statut == "EN_COURS"
    assert obj.date_realisation_prevue == date(2026, 12, 31)


def test_objectif_intitule_max_500():
    obj = CpomObjectifCreate(intitule="a" * 500, impact_eprd_o_n="NON")
    assert len(obj.intitule) == 500


def test_objectif_intitule_rejects_501_chars():
    with pytest.raises(ValidationError, match="intitule"):
        CpomObjectifCreate(intitule="a" * 501, impact_eprd_o_n="NON")


def test_objectif_intitule_rejects_empty():
    with pytest.raises(ValidationError, match="intitule"):
        CpomObjectifCreate(intitule="", impact_eprd_o_n="NON")


def test_objectif_description_max_2000():
    obj = CpomObjectifCreate(**_BASE_OBJ_KWARGS, description="x" * 2000)
    assert len(obj.description or "") == 2000


def test_objectif_description_rejects_2001_chars():
    with pytest.raises(ValidationError, match="description"):
        CpomObjectifCreate(**_BASE_OBJ_KWARGS, description="x" * 2001)


def test_objectif_statut_accepts_4_dgcs_values():
    for value in ("PREVU", "EN_COURS", "REALISE", "ABANDONNE"):
        obj = CpomObjectifCreate(**_BASE_OBJ_KWARGS, statut=value)
        assert obj.statut == value


def test_objectif_statut_rejects_unknown():
    with pytest.raises(ValidationError, match="statut"):
        CpomObjectifCreate(**_BASE_OBJ_KWARGS, statut="EN_RETARD")


def test_objectif_impact_eprd_oui_non():
    for value in ("OUI", "NON"):
        obj = CpomObjectifCreate(intitule="x", impact_eprd_o_n=value)
        assert obj.impact_eprd_o_n == value


def test_objectif_update_empty_payload_is_valid():
    obj = CpomObjectifUpdate()
    assert obj.model_dump(exclude_none=True) == {}


def test_objectif_update_can_patch_statut_only():
    obj = CpomObjectifUpdate(statut="REALISE")
    assert obj.statut == "REALISE"


def test_objectif_intitule_rejects_pipe_char():
    with pytest.raises(ValidationError):
        CpomObjectifCreate(intitule="bad|name", impact_eprd_o_n="OUI")
