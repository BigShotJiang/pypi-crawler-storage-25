"""Route tests for balance_mappings endpoints (L2 §7bis.3, 8 endpoints)."""

from __future__ import annotations

import io
from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_admin, require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import balance_mapping as bm_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import balance_mapping_service
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

COMPANY = uuid4()
USER = uuid4()
MAPPING_ID = uuid4()
ADMIN_AUTH = (USER, "admin", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


def _make_dict(**overrides):
    base = {
        "id": MAPPING_ID,
        "company_id": COMPANY,
        "source_plan": "PCG",
        "source_account": "60611",
        "target_m22bis_account": "60611",
        "weight": 1.0,
        "label_hint": None,
        "confidence": None,
        "suggestion_origin": None,
        "version_m22bis": "2025-2026",
        "valid_from": None,
        "valid_to": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(bm_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    app.dependency_overrides[require_admin] = lambda: ADMIN_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------


def test_list_mappings_200(client, monkeypatch):
    captured = {}

    async def _fake(company_id, **kwargs):
        captured.update(kwargs)
        from piilot_pack_compta_esms.models.balance_mapping import BalanceMappingRead

        return [BalanceMappingRead.model_validate(_make_dict())]

    monkeypatch.setattr(balance_mapping_service, "list_mappings", _fake)
    r = client.get("/plugins/compta_esms/balance-mappings?source_plan=PCG&source_account=60611")
    assert r.status_code == 200
    assert captured["source_plan"] == "PCG"
    assert captured["source_account"] == "60611"


def test_create_mapping_201(client, monkeypatch):
    async def _fake(company_id, payload):
        from piilot_pack_compta_esms.models.balance_mapping import BalanceMappingRead

        return BalanceMappingRead.model_validate(
            _make_dict(target_m22bis_account=payload.target_m22bis_account)
        )

    monkeypatch.setattr(balance_mapping_service, "create_mapping", _fake)
    r = client.post(
        "/plugins/compta_esms/balance-mappings",
        json={
            "source_plan": "PCG",
            "source_account": "60611",
            "target_m22bis_account": "60611",
        },
    )
    assert r.status_code == 201, r.text


def test_create_mapping_409_duplicate(client, monkeypatch):
    async def _fake(company_id, payload):
        raise ConflictError("dup", code="mapping_already_exists")

    monkeypatch.setattr(balance_mapping_service, "create_mapping", _fake)
    r = client.post(
        "/plugins/compta_esms/balance-mappings",
        json={
            "source_plan": "PCG",
            "source_account": "60611",
            "target_m22bis_account": "60611",
        },
    )
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "mapping_already_exists"


def test_create_mapping_422_bad_weight(client):
    """Pydantic enforces 0 < weight ≤ 1.0 — 1.5 should fail at parse."""
    r = client.post(
        "/plugins/compta_esms/balance-mappings",
        json={
            "source_plan": "PCG",
            "source_account": "60611",
            "target_m22bis_account": "60611",
            "weight": 1.5,
        },
    )
    assert r.status_code == 422


def test_patch_mapping_200(client, monkeypatch):
    async def _fake(company_id, mapping_id, payload):
        from piilot_pack_compta_esms.models.balance_mapping import BalanceMappingRead

        return BalanceMappingRead.model_validate(_make_dict(weight=0.5))

    monkeypatch.setattr(balance_mapping_service, "update_mapping", _fake)
    r = client.patch(
        f"/plugins/compta_esms/balance-mappings/{MAPPING_ID}",
        json={"weight": 0.5},
    )
    assert r.status_code == 200
    assert r.json()["weight"] == 0.5


def test_patch_mapping_422_target_immutable(client):
    """target_m22bis_account is part of the UNIQUE key — not in Update model."""
    r = client.patch(
        f"/plugins/compta_esms/balance-mappings/{MAPPING_ID}",
        json={"target_m22bis_account": "74122"},
    )
    assert r.status_code == 422


def test_delete_mapping_204(client, monkeypatch):
    async def _fake(company_id, mapping_id):
        return None

    monkeypatch.setattr(balance_mapping_service, "delete_mapping", _fake)
    r = client.delete(f"/plugins/compta_esms/balance-mappings/{MAPPING_ID}")
    assert r.status_code == 204


def test_delete_mapping_404(client, monkeypatch):
    async def _fake(company_id, mapping_id):
        raise NotFoundError("nope", code="mapping_not_found")

    monkeypatch.setattr(balance_mapping_service, "delete_mapping", _fake)
    r = client.delete(f"/plugins/compta_esms/balance-mappings/{MAPPING_ID}")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------


def test_bulk_upsert_200(client, monkeypatch):
    captured = {}

    async def _fake(company_id, items):
        captured["count"] = len(items)
        from piilot_pack_compta_esms.models.balance_mapping import BalanceMappingRead

        return [
            BalanceMappingRead.model_validate(
                _make_dict(target_m22bis_account=item.target_m22bis_account)
            )
            for item in items
        ]

    monkeypatch.setattr(balance_mapping_service, "bulk_upsert_mappings", _fake)
    r = client.post(
        "/plugins/compta_esms/balance-mappings:bulk-upsert",
        json=[
            {
                "source_plan": "PCG",
                "source_account": "60611",
                "target_m22bis_account": "60611",
            },
            {
                "source_plan": "PCG",
                "source_account": "60612",
                "target_m22bis_account": "60612",
            },
        ],
    )
    assert r.status_code == 200
    assert captured["count"] == 2


def test_validate_returns_issues_list(client, monkeypatch):
    async def _fake(company_id):
        from piilot_pack_compta_esms.models.balance_mapping import (
            BalanceMappingValidationIssue,
        )

        return [
            BalanceMappingValidationIssue(
                source_plan="PCG",
                source_account="64",
                version_m22bis="2025-2026",
                total_weight=0.9,
                target_count=2,
            )
        ]

    monkeypatch.setattr(balance_mapping_service, "validate_weights", _fake)
    r = client.post("/plugins/compta_esms/balance-mappings:validate")
    assert r.status_code == 200
    body = r.json()
    assert body[0]["source_account"] == "64"
    assert body[0]["total_weight"] == 0.9


def test_export_csv_returns_text_csv(client, monkeypatch):
    async def _fake(company_id):
        return [
            {
                "source_plan": "PCG",
                "source_account": "60611",
                "target_m22bis_account": "60611",
                "weight": 1.0,
                "label_hint": "Eau",
                "confidence": 1.0,
                "suggestion_origin": "pcg_to_m22bis_kb",
                "version_m22bis": "2025-2026",
                "valid_from": None,
                "valid_to": None,
            }
        ]

    monkeypatch.setattr(balance_mapping_service, "list_for_export", _fake)
    r = client.post("/plugins/compta_esms/balance-mappings:export-csv")
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("text/csv")
    assert "balance_mappings.csv" in r.headers["content-disposition"]
    assert "source_plan,source_account" in r.text  # header
    assert "PCG,60611,60611" in r.text  # data row


def test_import_csv_parses_and_calls_service(client, monkeypatch):
    captured = {}

    async def _fake(company_id, items):
        captured["count"] = len(items)
        captured["first_target"] = items[0].target_m22bis_account
        from piilot_pack_compta_esms.models.balance_mapping import BalanceMappingRead

        return [BalanceMappingRead.model_validate(_make_dict())]

    monkeypatch.setattr(balance_mapping_service, "import_csv_rows", _fake)

    csv_body = (
        "source_plan,source_account,target_m22bis_account,weight,"
        "label_hint,confidence,suggestion_origin,version_m22bis\n"
        "PCG,60611,60611,1.0,Eau,1.0,pcg_to_m22bis_kb,2025-2026\n"
        "PCG,60612,60612,1.0,Électricité,1.0,pcg_to_m22bis_kb,2025-2026\n"
    )
    files = {"file": ("mappings.csv", io.BytesIO(csv_body.encode("utf-8")), "text/csv")}
    r = client.post("/plugins/compta_esms/balance-mappings:import-csv", files=files)
    assert r.status_code == 200, r.text
    assert captured["count"] == 2
    assert captured["first_target"] == "60611"


def test_import_csv_422_bad_row(client, monkeypatch):
    """A weight > 1.0 in a row should bubble up as a 422 before bulk_upsert."""

    async def _should_not_be_called(*a, **kw):
        raise AssertionError("import_csv_rows must not run on bad CSV")

    monkeypatch.setattr(balance_mapping_service, "import_csv_rows", _should_not_be_called)

    csv_body = (
        "source_plan,source_account,target_m22bis_account,weight\n"
        "PCG,60611,60611,2.0\n"  # weight = 2.0, hors limite
    )
    files = {"file": ("bad.csv", io.BytesIO(csv_body.encode("utf-8")), "text/csv")}
    r = client.post("/plugins/compta_esms/balance-mappings:import-csv", files=files)
    assert r.status_code == 422


def test_import_csv_400_non_utf8(client):
    """A non-UTF-8 CSV upload surfaces as 400 not 500."""
    files = {"file": ("bad.csv", io.BytesIO(b"\xff\xfe\x00\x00"), "text/csv")}
    r = client.post("/plugins/compta_esms/balance-mappings:import-csv", files=files)
    assert r.status_code == 400
    assert r.json()["detail"]["code"] == "csv_decode_error"


def test_user_cannot_post(client):
    """Builder is required for create — plain user → 403."""
    from fastapi import HTTPException

    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.post(
        "/plugins/compta_esms/balance-mappings",
        json={
            "source_plan": "PCG",
            "source_account": "60611",
            "target_m22bis_account": "60611",
        },
    )
    assert r.status_code == 403


def test_builder_cannot_import_csv(client):
    """Import CSV is admin-only — builder → 403."""
    from fastapi import HTTPException

    def _no_admin():
        raise HTTPException(status_code=403, detail="admin required")

    client.app.dependency_overrides[require_admin] = _no_admin
    files = {
        "file": (
            "x.csv",
            io.BytesIO(b"source_plan,source_account,target_m22bis_account\n"),
            "text/csv",
        )
    }
    r = client.post("/plugins/compta_esms/balance-mappings:import-csv", files=files)
    assert r.status_code == 403
