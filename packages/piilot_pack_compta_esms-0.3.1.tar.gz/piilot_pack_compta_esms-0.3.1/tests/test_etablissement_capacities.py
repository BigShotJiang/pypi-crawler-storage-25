"""Tests §U — décomposition capacités ETS par typologie (D-048).

Couvre :

* EHPAD : capacite_hp / uhr / pasa / ht / aj acceptées au create.
* Autres ESSMS (IME/ITEP/SESSAD/...) : capacite_externat / semi_internat
  / internat acceptées au create.
* Pydantic : valeurs négatives rejetées (ge=0).
* Update partiel : 1 colonne touchée, le reste préservé.
* Read : les 8 colonnes nullable apparaissent (None si pas posées).

Pas de hard guard typologie ↔ section (la cohérence "EHPAD ne devrait
pas remplir externat" relève d'une validation différée §Z).
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from pydantic import ValidationError

from piilot_pack_compta_esms.models.etablissement import (
    EtablissementCreate,
    EtablissementRead,
    EtablissementUpdate,
)
from piilot_pack_compta_esms.services import etablissement_service

COMPANY = uuid4()
OG_ID = uuid4()
ETS_ID = uuid4()


def _row_with_capacities(**overrides):
    """ETS row including the 8 new capacity columns (default None)."""
    base = {
        "id": ETS_ID,
        "company_id": COMPANY,
        "og_id": OG_ID,
        "finess_ets": "555555555",
        "raison_sociale": "ETS Test",
        "typologie": "EHPAD",
        "categorie": None,
        "adresse": None,
        "date_autorisation": None,
        "capacite_autorisee": 80,
        "capacite_installee": 75,
        "capacite_financee": 75,
        "capacite_hp": None,
        "capacite_uhr": None,
        "capacite_pasa": None,
        "capacite_ht": None,
        "capacite_aj": None,
        "capacite_externat": None,
        "capacite_semi_internat": None,
        "capacite_internat": None,
        "amplitude_ouverture": 365,
        "convention_collective": None,
        "inclus_cpom": False,
        "soumis_equilibre": False,
        "tarification_ternaire": True,
        "forfait_global_unique": False,
        "cofinancement": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Pydantic model validation
# ---------------------------------------------------------------------------


def test_ets_create_ehpad_with_hp_uhr_pasa_ht_aj():
    payload = EtablissementCreate(
        og_id=OG_ID,
        finess_ets="555555555",
        raison_sociale="EHPAD Saint-Joseph",
        typologie="EHPAD",
        capacite_autorisee=80,
        capacite_installee=80,
        capacite_financee=80,
        capacite_hp=64,
        capacite_uhr=8,
        capacite_pasa=4,
        capacite_ht=2,
        capacite_aj=2,
    )
    assert payload.capacite_hp == 64
    assert payload.capacite_uhr == 8
    assert payload.capacite_pasa == 4
    assert payload.capacite_ht == 2
    assert payload.capacite_aj == 2
    # Autres restent None
    assert payload.capacite_externat is None
    assert payload.capacite_internat is None


def test_ets_create_ime_with_externat_semi_internat_internat():
    payload = EtablissementCreate(
        og_id=OG_ID,
        finess_ets="555555555",
        raison_sociale="IME Les Hortensias",
        typologie="IME",
        capacite_autorisee=60,
        capacite_installee=60,
        capacite_financee=60,
        capacite_externat=20,
        capacite_semi_internat=20,
        capacite_internat=20,
    )
    assert payload.capacite_externat == 20
    assert payload.capacite_semi_internat == 20
    assert payload.capacite_internat == 20
    assert payload.capacite_hp is None
    assert payload.capacite_uhr is None


def test_ets_create_rejects_negative_capacity_hp():
    with pytest.raises(ValidationError):
        EtablissementCreate(
            og_id=OG_ID,
            finess_ets="555555555",
            raison_sociale="EHPAD Bad",
            typologie="EHPAD",
            capacite_hp=-1,
        )


def test_ets_create_rejects_negative_capacity_externat():
    with pytest.raises(ValidationError):
        EtablissementCreate(
            og_id=OG_ID,
            finess_ets="555555555",
            raison_sociale="IME Bad",
            typologie="IME",
            capacite_externat=-5,
        )


def test_ets_update_partial_only_hp():
    payload = EtablissementUpdate(capacite_hp=70)
    dumped = payload.model_dump(exclude_unset=True)
    assert dumped == {"capacite_hp": 70}


def test_ets_read_round_trips_all_8_breakdown_cols():
    """Le row repo avec les 8 cols à None passe Pydantic sans erreur."""
    row = _row_with_capacities(capacite_hp=64, capacite_aj=2)
    read = EtablissementRead.model_validate(row)
    assert read.capacite_hp == 64
    assert read.capacite_aj == 2
    assert read.capacite_uhr is None
    assert read.capacite_externat is None


# ---------------------------------------------------------------------------
# Service round-trip — create with breakdown columns persists them
# ---------------------------------------------------------------------------


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.etablissement_service.run_in_thread",
        _passthrough,
    )


@pytest.mark.asyncio
async def test_service_create_persists_breakdown(monkeypatch, patch_run_in_thread):
    """Service.create() doit transmettre les 8 cols au repo via
    model_dump(exclude_unset=True). Pas de filtre côté service."""
    captured: dict = {}

    def _fake_create(company_id, og_id, payload):
        captured["payload"] = payload
        return _row_with_capacities(
            capacite_hp=payload.get("capacite_hp"),
            capacite_uhr=payload.get("capacite_uhr"),
        )

    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "og_exists_for_company",
        lambda og, co: True,
    )
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "find_by_finess",
        lambda co, fi: None,
    )
    monkeypatch.setattr(etablissement_service.etablissement_repo, "create", _fake_create)

    # Mock the reference lookups (typologie + convention collective) — they
    # otherwise hit the core via run_in_thread.
    async def _fake_typo_exists(_t):
        return True

    async def _fake_conv_exists(_c):
        return True

    monkeypatch.setattr(
        etablissement_service.reference_lookup,
        "typologie_exists",
        _fake_typo_exists,
    )
    monkeypatch.setattr(
        etablissement_service.reference_lookup,
        "convention_collective_exists",
        _fake_conv_exists,
    )

    payload = EtablissementCreate(
        og_id=OG_ID,
        finess_ets="555555555",
        raison_sociale="EHPAD Test",
        typologie="EHPAD",
        capacite_hp=50,
        capacite_uhr=10,
    )
    result = await etablissement_service.create_etablissement(COMPANY, OG_ID, payload)
    # Le payload reçu par le repo contient bien les nouvelles cols
    assert captured["payload"]["capacite_hp"] == 50
    assert captured["payload"]["capacite_uhr"] == 10
    # Round-trip — la réponse contient ce que le repo a renvoyé
    assert result.capacite_hp == 50
    assert result.capacite_uhr == 10
