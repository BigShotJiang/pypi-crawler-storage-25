"""Unit tests for :mod:`piilot_pack_compta_esms.services.cr_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.cr import CrCreate, CrReorder, CrUpdate
from piilot_pack_compta_esms.services import cr_service
from piilot_pack_compta_esms.services.errors import (
    CrossCompanyError,
    NotFoundError,
)

COMPANY = uuid4()
OTHER_COMPANY = uuid4()
DOC_ID = uuid4()
CR_ID = uuid4()
ETS_ID = uuid4()


def _make_cr_row(**overrides):
    base = {
        "id": CR_ID,
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "etablissement_id": None,
        "cr_type": "CRPP",
        "cr_variante": "non_soumis_equil",
        "cr_identifiant": None,
        "denomination": "CRPP - EPRD 2026",
        "finess_rattachement": None,
        "capacite_installee": None,
        "amplitude_ouverture": None,
        "ventilation": "simple",
        "ordre": 0,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.cr_service.run_in_thread",
        _passthrough,
    )


@pytest.mark.asyncio
async def test_list_returns_pydantic(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        cr_service.cr_repo,
        "list_by_document",
        lambda doc_id: [
            _make_cr_row(),
            _make_cr_row(cr_type="CRPA", ordre=1, denomination="CRPA 1"),
        ],
    )
    out = await cr_service.list_crs(DOC_ID)
    assert [c.cr_type for c in out] == ["CRPP", "CRPA"]


@pytest.mark.asyncio
async def test_get_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(cr_service.cr_repo, "get_by_id", lambda _: None)
    with pytest.raises(NotFoundError):
        await cr_service.get_cr(CR_ID)


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_happy(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        cr_service.cr_repo,
        "document_exists_for_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        cr_service.cr_repo,
        "create",
        lambda company_id, doc_id, payload: _make_cr_row(
            cr_type=payload["cr_type"],
            denomination=payload["denomination"],
        ),
    )
    out = await cr_service.create_cr(
        COMPANY,
        DOC_ID,
        CrCreate(cr_type="CRPA", denomination="Extra CRPA"),
    )
    assert out.cr_type == "CRPA"
    assert out.denomination == "Extra CRPA"


@pytest.mark.asyncio
async def test_create_document_cross_tenant_404(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        cr_service.cr_repo,
        "document_exists_for_company",
        lambda doc, company: False,
    )
    with pytest.raises(NotFoundError) as exc:
        await cr_service.create_cr(
            COMPANY,
            DOC_ID,
            CrCreate(cr_type="CRPA", denomination="X"),
        )
    assert exc.value.code == "document_not_found_for_cr_create"


@pytest.mark.asyncio
async def test_create_etablissement_cross_tenant_404(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        cr_service.cr_repo,
        "document_exists_for_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        cr_service.cr_repo,
        "etablissement_belongs_to_company",
        lambda ets, company: False,
    )
    with pytest.raises(NotFoundError) as exc:
        await cr_service.create_cr(
            COMPANY,
            DOC_ID,
            CrCreate(
                cr_type="CRPP",
                denomination="With ETS",
                etablissement_id=ETS_ID,
            ),
        )
    assert exc.value.code == "etablissement_not_found_for_cr_create"


@pytest.mark.asyncio
async def test_create_with_etablissement_happy(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        cr_service.cr_repo,
        "document_exists_for_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        cr_service.cr_repo,
        "etablissement_belongs_to_company",
        lambda ets, company: True,
    )
    captured: dict = {}

    def _create(company_id, doc_id, payload):
        captured.update(payload)
        return _make_cr_row(etablissement_id=payload.get("etablissement_id"))

    monkeypatch.setattr(cr_service.cr_repo, "create", _create)
    await cr_service.create_cr(
        COMPANY,
        DOC_ID,
        CrCreate(
            cr_type="CRPA",
            denomination="Attached",
            etablissement_id=ETS_ID,
            ventilation="ternaire_hds",
        ),
    )
    # Pydantic serializes the UUID as a UUID object via model_dump ;
    # the repo will str() it on insert.
    assert captured["etablissement_id"] == ETS_ID
    assert captured["ventilation"] == "ternaire_hds"


# ---------------------------------------------------------------------------
# update
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_update_happy(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(cr_service.cr_repo, "get_by_id", lambda _: _make_cr_row())
    monkeypatch.setattr(
        cr_service.cr_repo,
        "update",
        lambda cr_id, payload: _make_cr_row(**payload),
    )
    out = await cr_service.update_cr(COMPANY, CR_ID, CrUpdate(denomination="Renamed"))
    assert out.denomination == "Renamed"


@pytest.mark.asyncio
async def test_update_cross_company(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        cr_service.cr_repo,
        "get_by_id",
        lambda _: _make_cr_row(company_id=OTHER_COMPANY),
    )
    with pytest.raises(CrossCompanyError):
        await cr_service.update_cr(COMPANY, CR_ID, CrUpdate(denomination="X"))


@pytest.mark.asyncio
async def test_update_cannot_change_cr_type_pydantic():
    """``cr_type`` is not in ``CrUpdate`` — extra='forbid' rejects it."""
    with pytest.raises(ValueError):
        CrUpdate(cr_type="CRPA")


@pytest.mark.asyncio
async def test_update_etablissement_cross_tenant(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(cr_service.cr_repo, "get_by_id", lambda _: _make_cr_row())
    monkeypatch.setattr(
        cr_service.cr_repo,
        "etablissement_belongs_to_company",
        lambda ets, company: False,
    )
    with pytest.raises(NotFoundError):
        await cr_service.update_cr(COMPANY, CR_ID, CrUpdate(etablissement_id=ETS_ID))


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_delete_happy(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(cr_service.cr_repo, "get_by_id", lambda _: _make_cr_row())
    monkeypatch.setattr(cr_service.cr_repo, "delete", lambda _: True)
    await cr_service.delete_cr(COMPANY, CR_ID)


@pytest.mark.asyncio
async def test_delete_cross_company(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        cr_service.cr_repo,
        "get_by_id",
        lambda _: _make_cr_row(company_id=OTHER_COMPANY),
    )
    with pytest.raises(CrossCompanyError):
        await cr_service.delete_cr(COMPANY, CR_ID)


@pytest.mark.asyncio
async def test_delete_race_returns_not_found(monkeypatch, patch_run_in_thread):
    """If repo.delete returns False (row got removed), 404."""
    monkeypatch.setattr(cr_service.cr_repo, "get_by_id", lambda _: _make_cr_row())
    monkeypatch.setattr(cr_service.cr_repo, "delete", lambda _: False)
    with pytest.raises(NotFoundError):
        await cr_service.delete_cr(COMPANY, CR_ID)


# ---------------------------------------------------------------------------
# reorder
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_reorder_happy(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(cr_service.cr_repo, "get_by_id", lambda _: _make_cr_row(ordre=0))
    captured: dict = {}

    def _update(cr_id, payload):
        captured.update(payload)
        return _make_cr_row(**payload)

    monkeypatch.setattr(cr_service.cr_repo, "update", _update)
    out = await cr_service.reorder_cr(COMPANY, CR_ID, CrReorder(ordre=3))
    assert captured == {"ordre": 3}
    assert out.ordre == 3


@pytest.mark.asyncio
async def test_reorder_noop_when_same_ordre(monkeypatch, patch_run_in_thread):
    """Sending the current ordre is idempotent — no UPDATE issued."""
    monkeypatch.setattr(cr_service.cr_repo, "get_by_id", lambda _: _make_cr_row(ordre=2))

    def _update_should_not_be_called(*args, **kwargs):
        raise AssertionError("update must not be called on no-op reorder")

    monkeypatch.setattr(cr_service.cr_repo, "update", _update_should_not_be_called)
    out = await cr_service.reorder_cr(COMPANY, CR_ID, CrReorder(ordre=2))
    assert out.ordre == 2


@pytest.mark.asyncio
async def test_reorder_cross_company(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        cr_service.cr_repo,
        "get_by_id",
        lambda _: _make_cr_row(company_id=OTHER_COMPANY),
    )
    with pytest.raises(CrossCompanyError):
        await cr_service.reorder_cr(COMPANY, CR_ID, CrReorder(ordre=5))
