"""Route tests for Annexe 4 Activité GIR endpoints (L2 §12, 3 endpoints)."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.activite import (
    ActiviteComputeTheoriqueResponse,
    ActiviteLigneRead,
    ActiviteResponse,
)
from piilot_pack_compta_esms.routes import activite as activite_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import activite_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
ETS_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)


def _ligne_read(**overrides) -> ActiviteLigneRead:
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "etablissement_id": ETS_ID,
        "annexe_variante": "4A_ehpad_puv",
        "mode_creton": False,
        "section": "hp",
        "gir": "gir1",
        "annee_offset": 0,
        "nature_donnee": "prevu",
        "nombre_places": 80,
        "nombre_personnes": 78,
        "nombre_journees": 28000,
        "absences_moins72h_convenance": None,
        "absences_moins72h_hospi": None,
        "absences_plus72h_convenance": None,
        "absences_plus72h_hospi": None,
        "hors_departement_count": None,
        "beneficiaires_aide_sociale": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return ActiviteLigneRead.model_validate(base)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(activite_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# §12.1 GET /activite
# ---------------------------------------------------------------------------


def test_get_no_filters_200(client, monkeypatch):
    async def _fake(doc, company, ets_id=None, annexe_variante=None):
        return ActiviteResponse(ets_id_filtre=None, annexe_filtre=None, items=[_ligne_read()])

    monkeypatch.setattr(activite_service, "list_activite", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/activite")
    assert r.status_code == 200
    body = r.json()
    assert body["ets_id_filtre"] is None
    assert body["annexe_filtre"] is None
    assert len(body["items"]) == 1


def test_get_with_filters_200(client, monkeypatch):
    """Q5 — query param `annexe` mappé vers `annexe_variante` côté service."""
    captured = {}

    async def _fake(doc, company, ets_id=None, annexe_variante=None):
        captured["ets_id"] = ets_id
        captured["annexe_variante"] = annexe_variante
        return ActiviteResponse(ets_id_filtre=ets_id, annexe_filtre=annexe_variante, items=[])

    monkeypatch.setattr(activite_service, "list_activite", _fake)
    r = client.get(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite",
        params={"ets_id": str(ETS_ID), "annexe": "4A_ehpad_puv"},
    )
    assert r.status_code == 200
    assert captured["ets_id"] == ETS_ID
    assert captured["annexe_variante"] == "4A_ehpad_puv"


def test_get_invalid_annexe_422(client):
    r = client.get(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite",
        params={"annexe": "invalid_variant"},
    )
    assert r.status_code == 422


def test_get_404(client, monkeypatch):
    async def _fake(doc, company, ets_id=None, annexe_variante=None):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(activite_service, "list_activite", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/activite")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §12.2 POST :bulk-upsert
# ---------------------------------------------------------------------------


def test_bulk_upsert_200(client, monkeypatch):
    async def _fake(doc, company, payload):
        return ActiviteResponse(
            ets_id_filtre=payload.ets_id,
            annexe_filtre=payload.annexe_variante,
            items=[_ligne_read()],
        )

    monkeypatch.setattr(activite_service, "bulk_upsert_activite", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "annexe_variante": "4A_ehpad_puv",
            "items": [
                {
                    "section": "hp",
                    "gir": "gir1",
                    "annee_offset": 0,
                    "nature_donnee": "prevu",
                    "nombre_places": 80,
                }
            ],
        },
    )
    assert r.status_code == 200


def test_bulk_upsert_missing_ets_id_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite:bulk-upsert",
        json={"annexe_variante": "4A_ehpad_puv", "items": []},
    )
    assert r.status_code == 422


def test_bulk_upsert_invalid_annexe_variante_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "annexe_variante": "5Z_invalid",
            "items": [],
        },
    )
    assert r.status_code == 422


def test_bulk_upsert_invalid_section_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "annexe_variante": "4A_ehpad_puv",
            "items": [
                {
                    "section": "bogus",
                    "annee_offset": 0,
                    "nature_donnee": "prevu",
                }
            ],
        },
    )
    assert r.status_code == 422


def test_bulk_upsert_invalid_gir_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "annexe_variante": "4A_ehpad_puv",
            "items": [
                {
                    "section": "hp",
                    "gir": "gir99",
                    "annee_offset": 0,
                    "nature_donnee": "prevu",
                }
            ],
        },
    )
    assert r.status_code == 422


def test_bulk_upsert_annee_offset_out_of_range_422(client):
    """Q10 — annee_offset ∈ [-4, 0] (D-098). +1 rejeté."""
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "annexe_variante": "4A_ehpad_puv",
            "items": [
                {
                    "section": "hp",
                    "annee_offset": 1,
                    "nature_donnee": "prevu",
                }
            ],
        },
    )
    assert r.status_code == 422


def test_bulk_upsert_404_ets(client, monkeypatch):
    async def _fake(doc, company, payload):
        raise NotFoundError("nope", code="etablissement_not_found")

    monkeypatch.setattr(activite_service, "bulk_upsert_activite", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite:bulk-upsert",
        json={
            "ets_id": str(ETS_ID),
            "annexe_variante": "4A_ehpad_puv",
            "items": [],
        },
    )
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "etablissement_not_found"


# ---------------------------------------------------------------------------
# §12.3 POST :compute-theorique
# ---------------------------------------------------------------------------


def test_compute_theorique_200(client, monkeypatch):
    async def _fake(doc, company, ets_id, annexe_variante):
        return ActiviteComputeTheoriqueResponse(
            capacite_financee=80,
            amplitude_ouverture=365,
            nombre_journees_theorique=80 * 365,
            inserted=15,
            updated=0,
        )

    monkeypatch.setattr(activite_service, "compute_theorique", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite:compute-theorique",
        json={"ets_id": str(ETS_ID), "annexe_variante": "4A_ehpad_puv"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["nombre_journees_theorique"] == 80 * 365
    assert body["inserted"] == 15


def test_compute_theorique_404(client, monkeypatch):
    async def _fake(doc, company, ets_id, annexe_variante):
        raise NotFoundError("nope", code="etablissement_not_found")

    monkeypatch.setattr(activite_service, "compute_theorique", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite:compute-theorique",
        json={"ets_id": str(ETS_ID), "annexe_variante": "4A_ehpad_puv"},
    )
    assert r.status_code == 404


def test_compute_theorique_invalid_annexe_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite:compute-theorique",
        json={"ets_id": str(ETS_ID), "annexe_variante": "BAD"},
    )
    assert r.status_code == 422


def test_compute_theorique_missing_ets_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/activite:compute-theorique",
        json={"annexe_variante": "4A_ehpad_puv"},
    )
    assert r.status_code == 422
