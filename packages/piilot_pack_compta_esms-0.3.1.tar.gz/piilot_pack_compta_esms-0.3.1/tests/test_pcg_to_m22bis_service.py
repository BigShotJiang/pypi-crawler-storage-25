"""Unit tests for :mod:`piilot_pack_compta_esms.services.pcg_to_m22bis`.

The service loads the CSV at import time (module-level state), so we
test against the actual shipped catalog rather than mocking.
"""

from __future__ import annotations

from piilot_pack_compta_esms.services import pcg_to_m22bis


def test_csv_loaded_at_boot():
    """The generator script ships a 100+ row CSV with the wheel."""
    assert pcg_to_m22bis.total_rows() > 100


def test_lookup_identity_match():
    """60611 (Eau) is identity-mapped 1:1 — confidence=1.0."""
    rows = pcg_to_m22bis.lookup("PCG", "60611")
    assert len(rows) == 1
    row = rows[0]
    assert row["target_m22bis_account"] == "60611"
    assert row["weight"] == 1.0
    assert row["confidence"] == 1.0
    assert row["origin"] == "identity"


def test_lookup_class_73_hardcoded_split():
    """PCG 758 splits to 7351 (0.7) + 7358 (0.3) — sum to 1.0."""
    rows = pcg_to_m22bis.lookup("PCG", "758")
    assert len(rows) == 2
    targets = {r["target_m22bis_account"]: r["weight"] for r in rows}
    assert targets == {"7351": 0.7, "7358": 0.3}
    assert all(r["origin"] == "expert_hardcoded" for r in rows)
    assert all(r["confidence"] < 1.0 for r in rows)  # 0.7 — ambigu


def test_lookup_unknown_account_returns_empty():
    """Unknown source account → empty list, LLM tier takes over."""
    rows = pcg_to_m22bis.lookup("PCG", "999999")
    assert rows == []


def test_lookup_respects_version_m22bis():
    """A different millésime returns nothing (catalog seeded for 2025-2026)."""
    rows = pcg_to_m22bis.lookup("PCG", "60611", version_m22bis="1999-2000")
    assert rows == []


def test_search_by_libelle_substring():
    """``q='eau'`` finds account 60611 (case-insensitive)."""
    out = pcg_to_m22bis.search(q="eau")
    accounts = {row["source_account"] for row in out}
    assert "60611" in accounts


def test_search_by_class_prefix():
    """``class_num='606'`` returns 6061x variants (60611, 60612, 60613)."""
    out = pcg_to_m22bis.search(class_num="606", limit=100)
    accounts = {row["source_account"] for row in out}
    assert {"60611", "60612", "60613"} <= accounts


def test_search_combines_filters():
    """``q='eau'`` + ``class_num='606'`` narrows to 60611 only."""
    out = pcg_to_m22bis.search(q="eau", class_num="606")
    assert all(r["source_account"].startswith("606") for r in out)
    assert all("eau" in r["label_hint"].lower() for r in out)


def test_search_respects_limit():
    """Default limit caps the result set."""
    out = pcg_to_m22bis.search(class_num="6", limit=5)
    assert len(out) <= 5


def test_list_presets_returns_names_only():
    """The list endpoint omits the mapping body to keep the payload light."""
    presets = pcg_to_m22bis.list_presets()
    names = {p["name"] for p in presets}
    assert names == {"Pennylane", "Sage", "EBP", "Cegid"}
    for p in presets:
        assert "mappings" not in p
        assert "description" in p


def test_get_preset_full_body():
    """The detail endpoint returns name + description + mappings."""
    preset = pcg_to_m22bis.get_preset("Pennylane")
    assert preset is not None
    assert preset["name"] == "Pennylane"
    assert "mappings" in preset
    assert isinstance(preset["mappings"], list)


def test_get_preset_unknown_returns_none():
    assert pcg_to_m22bis.get_preset("InvalidOutil") is None
