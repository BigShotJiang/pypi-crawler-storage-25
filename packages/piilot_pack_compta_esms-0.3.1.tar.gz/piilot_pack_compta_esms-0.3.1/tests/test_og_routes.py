"""Route tests for OG endpoints.

Uses :class:`fastapi.testclient.TestClient` against a minimal FastAPI
app built per-test (no Piilot core boot needed). We override the
``require_user`` / ``require_admin`` Depends to inject a stable auth
tuple, and we patch ``og_service.*`` to short-circuit the DB layer —
the goal here is to verify the HTTP surface (status codes, request
parsing, response shape, permission gating) rather than re-test
service logic.
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import UUID, uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_admin, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import og as og_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import og_service
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

COMPANY = uuid4()
USER = uuid4()
OG_ID = uuid4()

ADMIN_AUTH = (USER, "admin", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


def _make_og_dict(**overrides):
    base = {
        "id": OG_ID,
        "company_id": COMPANY,
        "finess_juridique": "111111111",
        "raison_sociale": "OG Test",
        "nature_juridique": "PRIVE_NON_LUCRATIF",
        "plan_comptable": "PNL",
        "adresse": None,
        "cpom_date_effet": None,
        "representant_legal": None,
        "representant_qualite": None,
        "siret": None,
        "telephone": None,
        "email": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def app():
    """Fresh FastAPI app per test with the OG router mounted.

    A new app each time so the slowapi state never leaks across tests
    (rate limit counters reset).
    """
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(og_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_admin] = lambda: ADMIN_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


def test_list_orgs_returns_200(client, monkeypatch):
    async def _fake(company_id):
        from piilot_pack_compta_esms.models.og import OGRead

        return [OGRead.model_validate(_make_og_dict())]

    monkeypatch.setattr(og_service, "list_orgs", _fake)
    r = client.get("/plugins/compta_esms/orgs")
    assert r.status_code == 200
    body = r.json()
    assert isinstance(body, list)
    assert body[0]["finess_juridique"] == "111111111"


def test_create_og_201(client, monkeypatch):
    async def _fake(company_id, payload):
        from piilot_pack_compta_esms.models.og import OGRead

        return OGRead.model_validate(_make_og_dict(finess_juridique=payload.finess_juridique))

    monkeypatch.setattr(og_service, "create_org", _fake)
    r = client.post(
        "/plugins/compta_esms/orgs",
        json={
            "finess_juridique": "222222222",
            "raison_sociale": "New",
            "nature_juridique": "PRIVE_NON_LUCRATIF",
            "plan_comptable": "PNL",
        },
    )
    assert r.status_code == 201, r.text
    assert r.json()["finess_juridique"] == "222222222"


def test_create_og_409_on_conflict(client, monkeypatch):
    async def _fake(company_id, payload):
        raise ConflictError("dup", code="og_finess_taken")

    monkeypatch.setattr(og_service, "create_org", _fake)
    r = client.post(
        "/plugins/compta_esms/orgs",
        json={
            "finess_juridique": "111111111",
            "raison_sociale": "Dup",
            "nature_juridique": "PRIVE_NON_LUCRATIF",
            "plan_comptable": "PNL",
        },
    )
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "og_finess_taken"


def test_create_og_422_bad_finess(client):
    """A FINESS that's not 9 digits gets rejected by Pydantic → 422."""
    r = client.post(
        "/plugins/compta_esms/orgs",
        json={
            "finess_juridique": "123",
            "raison_sociale": "X",
            "nature_juridique": "PRIVE_NON_LUCRATIF",
            "plan_comptable": "PNL",
        },
    )
    assert r.status_code == 422


def test_create_og_422_extra_field(client):
    """``extra='forbid'`` rejects unknown keys → 422."""
    r = client.post(
        "/plugins/compta_esms/orgs",
        json={
            "finess_juridique": "123456789",
            "raison_sociale": "X",
            "nature_juridique": "PRIVE_NON_LUCRATIF",
            "plan_comptable": "PNL",
            "unknown": "x",
        },
    )
    assert r.status_code == 422


def test_get_og_404(client, monkeypatch):
    async def _fake(og_id: UUID):
        raise NotFoundError("nope", code="og_not_found")

    monkeypatch.setattr(og_service, "get_org", _fake)
    r = client.get(f"/plugins/compta_esms/orgs/{OG_ID}")
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "og_not_found"


def test_update_og_200(client, monkeypatch):
    async def _fake(company_id, og_id, payload):
        from piilot_pack_compta_esms.models.og import OGRead

        return OGRead.model_validate(_make_og_dict(raison_sociale="Renamed"))

    monkeypatch.setattr(og_service, "update_org", _fake)
    r = client.patch(
        f"/plugins/compta_esms/orgs/{OG_ID}",
        json={"raison_sociale": "Renamed"},
    )
    assert r.status_code == 200
    assert r.json()["raison_sociale"] == "Renamed"


def test_delete_og_204(client, monkeypatch):
    async def _fake(og_id):
        return None

    monkeypatch.setattr(og_service, "delete_org", _fake)
    r = client.delete(f"/plugins/compta_esms/orgs/{OG_ID}")
    assert r.status_code == 204


def test_delete_og_409_has_etablissements(client, monkeypatch):
    async def _fake(og_id):
        raise ConflictError("nope", code="og_has_etablissements")

    monkeypatch.setattr(og_service, "delete_org", _fake)
    r = client.delete(f"/plugins/compta_esms/orgs/{OG_ID}")
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "og_has_etablissements"


def test_user_cannot_post(client, monkeypatch):
    """Override ``require_admin`` to raise like a real 403 — user role can't POST."""
    from fastapi import HTTPException

    def _no_admin():
        raise HTTPException(status_code=403, detail="admin required")

    client.app.dependency_overrides[require_admin] = _no_admin
    r = client.post(
        "/plugins/compta_esms/orgs",
        json={
            "finess_juridique": "111111111",
            "raison_sociale": "X",
            "nature_juridique": "PRIVE_NON_LUCRATIF",
            "plan_comptable": "PNL",
        },
    )
    assert r.status_code == 403
