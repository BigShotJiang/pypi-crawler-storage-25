"""Tests §BC v0.3 — ``compute_eprd_structure`` (D-037).

Couvre les 5 variantes ``nature_juridique`` + edge cases :
* ETABLISSEMENT_PUBLIC_SANTE — CRPA pour chaque ESMS
* ESMS_PUBLIC_AUTONOME — 1er ETS sur CRPP par défaut + N-1 CRPA
* CCAS_CIAS_COLLECTIVITE — pas de CRPA structurel (budget annexe unique)
* PRIVE_NON_LUCRATIF — pattern ESMS_PUBLIC_AUTONOME
* PRIVE_COMMERCIAL — pas de CRPA + annexes simplifiées
* Edge : OG sans ETS, OG inclus CPOM, OG manquant, nature inconnue
* Équilibre initial REEL/STRICT/NON_APPLICABLE
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.services import eprd_structure_service
from piilot_pack_compta_esms.services.errors import (
    NotFoundError,
    ValidationError,
)

OG_ID = uuid4()
ETS_A = uuid4()
ETS_B = uuid4()
ETS_C = uuid4()


@pytest.fixture
def passthrough_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.eprd_structure_service.run_in_thread",
        _passthrough,
    )


def _og_row(nature_juridique: str) -> dict:
    return {
        "id": OG_ID,
        "company_id": uuid4(),
        "finess_juridique": "750000001",
        "raison_sociale": "OG Test",
        "nature_juridique": nature_juridique,
        "plan_comptable": "PNL",
        "adresse": None,
        "cpom_date_effet": None,
        "representant_legal": None,
        "representant_qualite": None,
        "siret": None,
        "telephone": None,
        "email": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }


def _ets_row(ets_id, raison, *, inclus_cpom: bool = False) -> dict:
    return {
        "id": ets_id,
        "company_id": uuid4(),
        "og_id": OG_ID,
        "finess_ets": "750000002",
        "raison_sociale": raison,
        "typologie": "EHPAD",
        "inclus_cpom": inclus_cpom,
        "soumis_equilibre": False,
        "categorie": None,
        "adresse": None,
        "date_autorisation": None,
        "capacite_autorisee": 0,
        "capacite_installee": 0,
        "capacite_financee": 0,
        "capacite_hp": None,
        "capacite_uhr": None,
        "capacite_pasa": None,
        "capacite_ht": None,
        "capacite_aj": None,
        "capacite_externat": None,
        "capacite_semi_internat": None,
        "capacite_internat": None,
        "amplitude_ouverture": 365,
        "convention_collective": None,
        "tarification_ternaire": False,
        "forfait_global_unique": False,
        "cofinancement": None,
        "eligible_aide_sociale": None,
        "option_tarifaire": None,
        "gmp_valeur": None,
        "gmp_date_validation": None,
        "gmp_validation_mode": None,
        "pmp_valeur": None,
        "pmp_date_validation": None,
        "prix_journee_moyen": None,
        "tarification_differenciee_o_n": None,
        "nb_chambres_individuelles": None,
        "nb_chambres_doubles": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }


def _setup_og(monkeypatch, nature: str, ets_rows: list[dict]) -> None:
    monkeypatch.setattr(
        eprd_structure_service.og_repo,
        "get_by_id",
        lambda og: _og_row(nature),
    )
    monkeypatch.setattr(
        eprd_structure_service.etablissement_repo,
        "list_by_og",
        lambda og: ets_rows,
    )


# --------------------------------------------------------------------
# ETABLISSEMENT_PUBLIC_SANTE
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_eps_with_2_esms_creates_2_crpas(monkeypatch, passthrough_run_in_thread):
    """EPS → 1 CRPP sanitaire (déjà créé par défaut) + 1 CRPA par ESMS."""
    _setup_og(
        monkeypatch,
        "ETABLISSEMENT_PUBLIC_SANTE",
        [
            _ets_row(ETS_A, "EHPAD Alice"),
            _ets_row(ETS_B, "SSIAD Bob"),
        ],
    )
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    assert spec.nature_juridique == "ETABLISSEMENT_PUBLIC_SANTE"
    # CRPA pour chacun des 2 ESMS (CRPP par défaut est créé ailleurs).
    assert len(spec.crps) == 2
    assert all(c.cr_type == "CRPA" for c in spec.crps)
    assert spec.crps[0].etablissement_id == ETS_A
    assert spec.crps[1].etablissement_id == ETS_B
    assert spec.crps[0].ordre == 1
    assert spec.crps[1].ordre == 2


@pytest.mark.asyncio
async def test_eps_annexes_are_full(monkeypatch, passthrough_run_in_thread):
    _setup_og(
        monkeypatch,
        "ETABLISSEMENT_PUBLIC_SANTE",
        [_ets_row(ETS_A, "EHPAD")],
    )
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    # 4 annexes obligatoires : 4, 5, 6, 8
    assert {a.code for a in spec.annexes} == {"4", "5", "6", "8"}
    assert all(a.obligatoire for a in spec.annexes)


# --------------------------------------------------------------------
# ESMS_PUBLIC_AUTONOME
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_esms_public_with_1_ets_no_extra_crpa(monkeypatch, passthrough_run_in_thread):
    """1 OG → 1 ESMS — CRPP par défaut suffit, pas de CRPA structurel."""
    _setup_og(
        monkeypatch,
        "ESMS_PUBLIC_AUTONOME",
        [_ets_row(ETS_A, "EHPAD seul")],
    )
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    # Le 1er ETS est porté par le CRPP par défaut → 0 CRPA structurel.
    assert len(spec.crps) == 0


@pytest.mark.asyncio
async def test_esms_public_with_2_ets_creates_1_crpa(monkeypatch, passthrough_run_in_thread):
    """Cas spec 1 — 1 OG → 1 EHPAD + 1 SSIAD → CRPP=EHPAD + CRPA=SSIAD."""
    _setup_og(
        monkeypatch,
        "ESMS_PUBLIC_AUTONOME",
        [
            _ets_row(ETS_A, "EHPAD Alice"),
            _ets_row(ETS_B, "SSIAD Bob"),
        ],
    )
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    # Le 1er ETS (Alice) est porté par le CRPP par défaut → 1 CRPA pour Bob.
    assert len(spec.crps) == 1
    assert spec.crps[0].etablissement_id == ETS_B


@pytest.mark.asyncio
async def test_esms_public_with_3_ets_creates_2_crpas(monkeypatch, passthrough_run_in_thread):
    _setup_og(
        monkeypatch,
        "ESMS_PUBLIC_AUTONOME",
        [
            _ets_row(ETS_A, "EHPAD Alpha"),
            _ets_row(ETS_B, "FAM Bravo"),
            _ets_row(ETS_C, "MAS Charlie"),
        ],
    )
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    assert len(spec.crps) == 2
    ets_ids = {c.etablissement_id for c in spec.crps}
    assert ets_ids == {ETS_B, ETS_C}


@pytest.mark.asyncio
async def test_esms_public_without_ets_skips_crps(monkeypatch, passthrough_run_in_thread):
    _setup_og(monkeypatch, "ESMS_PUBLIC_AUTONOME", [])
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    assert spec.crps == []
    # Note cabinet présente :
    assert any("sans établissement" in n for n in spec.notes)


# --------------------------------------------------------------------
# CCAS_CIAS_COLLECTIVITE
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_ccas_returns_zero_crpa(monkeypatch, passthrough_run_in_thread):
    """CCAS/CIAS — variante (a) budget annexe global = pas de CRPA structurel."""
    _setup_og(
        monkeypatch,
        "CCAS_CIAS_COLLECTIVITE",
        [_ets_row(ETS_A, "EHPAD CCAS"), _ets_row(ETS_B, "EHPAD CCAS-2")],
    )
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    assert spec.crps == []
    # Note explique la variante (b) "N EPRD" alternative.
    assert any("CCAS" in n.upper() or "ccas" in n for n in spec.notes)


# --------------------------------------------------------------------
# PRIVE_NON_LUCRATIF
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_prive_non_lucratif_pattern_like_esms_public(monkeypatch, passthrough_run_in_thread):
    """PRIVE_NON_LUCRATIF — même pattern que ESMS_PUBLIC_AUTONOME."""
    _setup_og(
        monkeypatch,
        "PRIVE_NON_LUCRATIF",
        [
            _ets_row(ETS_A, "EHPAD Asso"),
            _ets_row(ETS_B, "FAM Asso"),
        ],
    )
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    assert spec.nature_juridique == "PRIVE_NON_LUCRATIF"
    assert len(spec.crps) == 1  # 1er ETS sur CRPP, 1 CRPA pour le 2e
    assert spec.crps[0].etablissement_id == ETS_B


# --------------------------------------------------------------------
# PRIVE_COMMERCIAL
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_prive_commercial_returns_no_crpa_structural(monkeypatch, passthrough_run_in_thread):
    """PRIVE_COMMERCIAL — EPRD simplifié, pas de CRPA structurel."""
    _setup_og(
        monkeypatch,
        "PRIVE_COMMERCIAL",
        [_ets_row(ETS_A, "EHPAD SARL")],
    )
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    assert spec.crps == []
    # Annexes 6 et 8 facultatives.
    annexes_by_code = {a.code: a for a in spec.annexes}
    assert annexes_by_code["4"].obligatoire is True
    assert annexes_by_code["5"].obligatoire is True
    assert annexes_by_code["6"].obligatoire is False
    assert annexes_by_code["8"].obligatoire is False
    assert any("simplifié" in n for n in spec.notes)


# --------------------------------------------------------------------
# Équilibre applicable initial
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_equilibre_reel_when_any_ets_in_cpom(monkeypatch, passthrough_run_in_thread):
    """Au moins 1 ETS inclus CPOM → REEL pour toutes natures."""
    _setup_og(
        monkeypatch,
        "PRIVE_NON_LUCRATIF",
        [
            _ets_row(ETS_A, "EHPAD CPOM", inclus_cpom=True),
            _ets_row(ETS_B, "EHPAD non-CPOM"),
        ],
    )
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    assert spec.equilibre_applicable_initial == "REEL"


@pytest.mark.asyncio
async def test_equilibre_strict_when_no_cpom_for_public(monkeypatch, passthrough_run_in_thread):
    """ESMS public hors CPOM → STRICT."""
    _setup_og(
        monkeypatch,
        "ESMS_PUBLIC_AUTONOME",
        [_ets_row(ETS_A, "EHPAD")],
    )
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    assert spec.equilibre_applicable_initial == "STRICT"


@pytest.mark.asyncio
async def test_equilibre_non_applicable_for_prive_commercial_no_cpom(
    monkeypatch, passthrough_run_in_thread
):
    """PRIVE_COMMERCIAL hors CPOM → NON_APPLICABLE (pas d'obligation)."""
    _setup_og(
        monkeypatch,
        "PRIVE_COMMERCIAL",
        [_ets_row(ETS_A, "EHPAD SARL")],
    )
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    assert spec.equilibre_applicable_initial == "NON_APPLICABLE"


@pytest.mark.asyncio
async def test_equilibre_reel_for_prive_commercial_with_cpom(
    monkeypatch, passthrough_run_in_thread
):
    """PRIVE_COMMERCIAL inclus CPOM → REEL (toutes natures)."""
    _setup_og(
        monkeypatch,
        "PRIVE_COMMERCIAL",
        [_ets_row(ETS_A, "EHPAD SARL", inclus_cpom=True)],
    )
    spec = await eprd_structure_service.compute_eprd_structure(OG_ID)
    assert spec.equilibre_applicable_initial == "REEL"


# --------------------------------------------------------------------
# Edge cases
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_og_not_found_raises_404(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        eprd_structure_service.og_repo,
        "get_by_id",
        lambda og: None,
    )
    with pytest.raises(NotFoundError) as exc:
        await eprd_structure_service.compute_eprd_structure(OG_ID)
    assert exc.value.code == "og_not_found"


@pytest.mark.asyncio
async def test_nature_juridique_unknown_raises_422(monkeypatch, passthrough_run_in_thread):
    """Defensive — si la DB contient une valeur inconnue (corruption ou
    migration partielle), le service refuse explicitement."""
    monkeypatch.setattr(
        eprd_structure_service.og_repo,
        "get_by_id",
        lambda og: _og_row("UNKNOWN_NATURE"),
    )
    monkeypatch.setattr(
        eprd_structure_service.etablissement_repo,
        "list_by_og",
        lambda og: [],
    )
    with pytest.raises(ValidationError) as exc:
        await eprd_structure_service.compute_eprd_structure(OG_ID)
    assert exc.value.code == "nature_juridique_unhandled"


# --------------------------------------------------------------------
# Helper _initial_equilibre (unitaire)
# --------------------------------------------------------------------


def test_initial_equilibre_matrix():
    """Vérifie le mapping exhaustif (5 natures × {CPOM ON/OFF})."""
    matrix = {
        ("ETABLISSEMENT_PUBLIC_SANTE", False): "STRICT",
        ("ETABLISSEMENT_PUBLIC_SANTE", True): "REEL",
        ("ESMS_PUBLIC_AUTONOME", False): "STRICT",
        ("ESMS_PUBLIC_AUTONOME", True): "REEL",
        ("CCAS_CIAS_COLLECTIVITE", False): "STRICT",
        ("CCAS_CIAS_COLLECTIVITE", True): "REEL",
        ("PRIVE_NON_LUCRATIF", False): "STRICT",
        ("PRIVE_NON_LUCRATIF", True): "REEL",
        ("PRIVE_COMMERCIAL", False): "NON_APPLICABLE",
        ("PRIVE_COMMERCIAL", True): "REEL",
    }
    for (nature, cpom), expected in matrix.items():
        actual = eprd_structure_service._initial_equilibre(nature, cpom)
        assert actual == expected, f"{nature} × cpom={cpom} → {actual} (want {expected})"
