"""Unit tests for :mod:`piilot_pack_compta_esms.services.etablissement_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.etablissement import (
    EtablissementCreate,
    EtablissementUpdate,
)
from piilot_pack_compta_esms.services import etablissement_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    CrossCompanyError,
    NotFoundError,
)

COMPANY = uuid4()
OG_ID = uuid4()
ETS_ID = uuid4()


def _make_ets_row(**overrides):
    base = {
        "id": ETS_ID,
        "company_id": COMPANY,
        "og_id": OG_ID,
        "finess_ets": "555555555",
        "raison_sociale": "ETS Test",
        "typologie": "EHPAD",
        "categorie": None,
        "adresse": None,
        "date_autorisation": None,
        "capacite_autorisee": 80,
        "capacite_installee": 75,
        "capacite_financee": 75,
        "amplitude_ouverture": 365,
        "convention_collective": None,
        "inclus_cpom": False,
        "soumis_equilibre": False,
        "tarification_ternaire": True,
        "forfait_global_unique": False,
        "cofinancement": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.etablissement_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture(autouse=True)
def _stub_reference_lookup(monkeypatch):
    """Default reference lookup to accept any code so existing tests that
    don't care about typologie validation keep passing. Individual tests
    that exercise the validation path override these explicitly."""

    async def _accept_anything(value):
        return True

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.etablissement_service."
        "reference_lookup.typologie_exists",
        _accept_anything,
    )
    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.etablissement_service."
        "reference_lookup.convention_collective_exists",
        _accept_anything,
    )


@pytest.mark.asyncio
async def test_list_filtered_by_typologie(monkeypatch, patch_run_in_thread):
    captured = {}

    def _list(og_id, typologie):
        captured["og_id"] = og_id
        captured["typologie"] = typologie
        return [_make_ets_row()]

    monkeypatch.setattr(etablissement_service.etablissement_repo, "list_by_og", _list)
    out = await etablissement_service.list_etablissements(OG_ID, "EHPAD")
    assert len(out) == 1
    assert captured["typologie"] == "EHPAD"


@pytest.mark.asyncio
async def test_create_happy_path(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "og_exists_for_company",
        lambda og_id, company_id: True,
    )
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "find_by_finess",
        lambda company_id, finess: None,
    )

    def _create(company_id, og_id, payload):
        # The service strips og_id from the payload before passing to the repo
        # (path takes precedence).
        assert "og_id" not in payload
        return _make_ets_row(finess_ets=payload["finess_ets"])

    monkeypatch.setattr(etablissement_service.etablissement_repo, "create", _create)
    payload = EtablissementCreate(
        og_id=OG_ID,
        finess_ets="777777777",
        raison_sociale="ETS New",
        typologie="MAS",
    )
    out = await etablissement_service.create_etablissement(COMPANY, OG_ID, payload)
    assert out.finess_ets == "777777777"


@pytest.mark.asyncio
async def test_create_body_og_mismatch(monkeypatch, patch_run_in_thread):
    payload = EtablissementCreate(
        og_id=uuid4(),  # Body OG ≠ URL OG
        finess_ets="777777777",
        raison_sociale="ETS X",
        typologie="EHPAD",
    )
    with pytest.raises(ConflictError) as exc:
        await etablissement_service.create_etablissement(COMPANY, OG_ID, payload)
    assert exc.value.code == "ets_og_id_mismatch"


@pytest.mark.asyncio
async def test_create_og_not_in_company(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "og_exists_for_company",
        lambda og_id, company_id: False,
    )
    payload = EtablissementCreate(
        og_id=OG_ID,
        finess_ets="888888888",
        raison_sociale="X",
        typologie="EHPAD",
    )
    with pytest.raises(NotFoundError):
        await etablissement_service.create_etablissement(COMPANY, OG_ID, payload)


@pytest.mark.asyncio
async def test_create_finess_conflict(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "og_exists_for_company",
        lambda og_id, company_id: True,
    )
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "find_by_finess",
        lambda company_id, finess: _make_ets_row(finess_ets=finess),
    )
    payload = EtablissementCreate(
        og_id=OG_ID,
        finess_ets="555555555",
        raison_sociale="Dup",
        typologie="EHPAD",
    )
    with pytest.raises(ConflictError) as exc:
        await etablissement_service.create_etablissement(COMPANY, OG_ID, payload)
    assert exc.value.code == "ets_finess_taken"


@pytest.mark.asyncio
async def test_delete_blocks_when_crs_exist(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "get_by_id",
        lambda ets_id: _make_ets_row(),
    )
    monkeypatch.setattr(etablissement_service.etablissement_repo, "count_crs", lambda ets_id: 2)
    with pytest.raises(ConflictError) as exc:
        await etablissement_service.delete_etablissement(COMPANY, ETS_ID)
    assert exc.value.code == "ets_has_crs"


@pytest.mark.asyncio
async def test_delete_cross_company_guard(monkeypatch, patch_run_in_thread):
    other_company = uuid4()
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "get_by_id",
        lambda ets_id: _make_ets_row(company_id=other_company),
    )
    with pytest.raises(CrossCompanyError):
        await etablissement_service.delete_etablissement(COMPANY, ETS_ID)


@pytest.mark.asyncio
async def test_delete_happy_path(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "get_by_id",
        lambda ets_id: _make_ets_row(),
    )
    monkeypatch.setattr(etablissement_service.etablissement_repo, "count_crs", lambda ets_id: 0)
    monkeypatch.setattr(etablissement_service.etablissement_repo, "delete", lambda ets_id: True)
    await etablissement_service.delete_etablissement(COMPANY, ETS_ID)


@pytest.mark.asyncio
async def test_update_happy_path(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "get_by_id",
        lambda ets_id: _make_ets_row(),
    )
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "find_by_finess",
        lambda company_id, finess: None,
    )
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "update",
        lambda ets_id, payload: _make_ets_row(**payload),
    )
    out = await etablissement_service.update_etablissement(
        COMPANY, ETS_ID, EtablissementUpdate(raison_sociale="Renamed")
    )
    assert out.raison_sociale == "Renamed"


# ---------------------------------------------------------------------------
# Reference KB validation (typologie + convention_collective via PLT-T1/bonus)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_rejects_unknown_typologie(monkeypatch, patch_run_in_thread):
    """When the catalog is populated and rejects the code, return 409."""
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "og_exists_for_company",
        lambda og_id, company_id: True,
    )

    async def _reject(value):
        return False

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.etablissement_service."
        "reference_lookup.typologie_exists",
        _reject,
    )

    payload = EtablissementCreate(
        og_id=OG_ID,
        finess_ets="999999999",
        raison_sociale="ETS Unknown Typo",
        typologie="NOT_IN_CATALOG",
    )
    with pytest.raises(ConflictError) as exc:
        await etablissement_service.create_etablissement(COMPANY, OG_ID, payload)
    assert exc.value.code == "ets_typologie_unknown"


@pytest.mark.asyncio
async def test_create_rejects_unknown_convention_collective(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "og_exists_for_company",
        lambda og_id, company_id: True,
    )

    async def _reject(value):
        return False

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.etablissement_service."
        "reference_lookup.convention_collective_exists",
        _reject,
    )

    payload = EtablissementCreate(
        og_id=OG_ID,
        finess_ets="999999999",
        raison_sociale="ETS Unknown CCN",
        typologie="EHPAD",
        convention_collective="NOT_A_CCN",
    )
    with pytest.raises(ConflictError) as exc:
        await etablissement_service.create_etablissement(COMPANY, OG_ID, payload)
    assert exc.value.code == "ets_convention_collective_unknown"


@pytest.mark.asyncio
async def test_create_accepts_any_typologie_when_catalog_empty(monkeypatch, patch_run_in_thread):
    """Fail-open : empty catalog returns True from the lookup helper, so
    create still succeeds. Protects against bricking the plugin during a
    fresh deployment when the core sync hasn't run yet."""
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "og_exists_for_company",
        lambda og_id, company_id: True,
    )
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "find_by_finess",
        lambda company_id, finess: None,
    )
    monkeypatch.setattr(
        etablissement_service.etablissement_repo,
        "create",
        lambda company_id, og_id, payload: _make_ets_row(typologie=payload["typologie"]),
    )

    # Default fixture _stub_reference_lookup already returns True (fail-open),
    # so this exercise just confirms the happy path doesn't break with an
    # arbitrary typology string.
    payload = EtablissementCreate(
        og_id=OG_ID,
        finess_ets="888888888",
        raison_sociale="ETS Future Typology",
        typologie="FUTURE_DGCS_TYPO_2030",
    )
    out = await etablissement_service.create_etablissement(COMPANY, OG_ID, payload)
    assert out.typologie == "FUTURE_DGCS_TYPO_2030"
