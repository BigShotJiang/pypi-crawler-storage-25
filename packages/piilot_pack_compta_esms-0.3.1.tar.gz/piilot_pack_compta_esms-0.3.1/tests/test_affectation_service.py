"""Unit tests for :mod:`piilot_pack_compta_esms.services.affectation_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.affectation import (
    AffectationBulkRequest,
    AffectationItemCreate,
)
from piilot_pack_compta_esms.models.crp_ligne import (
    CrpEcart,
    CrpTotalsColumnPair,
    CrpTotalsGroupe,
    CrpTotalsResponse,
)
from piilot_pack_compta_esms.services import affectation_service
from piilot_pack_compta_esms.services.errors import (
    NotFoundError,
    ValidationError,
)

COMPANY = uuid4()
DOC_ID = uuid4()
OG_ID = uuid4()
EXERCICE_ID = uuid4()
CR_A = uuid4()
CR_B = uuid4()
ETS_1 = uuid4()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.affectation_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def owned_doc(monkeypatch):
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )


def _make_ctx(*, nature_juridique="PRIVE_NON_LUCRATIF", any_inclus_cpom=False):
    return {
        "id": DOC_ID,
        "type_document": "errd",
        "exercice_id": EXERCICE_ID,
        "og_id": OG_ID,
        "nature_juridique": nature_juridique,
        "plan_comptable": "PC",
        "any_inclus_cpom": any_inclus_cpom,
        "all_inclus_cpom": any_inclus_cpom,
    }


def _totals(*, cr_id, charges, produits) -> CrpTotalsResponse:
    pair_charges = CrpTotalsColumnPair(previsions_totales=Decimal("0"), realise=Decimal(charges))
    pair_produits = CrpTotalsColumnPair(previsions_totales=Decimal("0"), realise=Decimal(produits))
    zero = CrpTotalsColumnPair(previsions_totales=Decimal("0"), realise=Decimal("0"))
    return CrpTotalsResponse(
        cr_id=cr_id,
        cr_variante="non_soumis_equil",
        by_groupe={
            "G1": CrpTotalsGroupe(charges=pair_charges, produits=pair_produits),
            "G2": CrpTotalsGroupe(charges=zero, produits=zero),
            "G3": CrpTotalsGroupe(charges=zero, produits=zero),
        },
        total_charges=pair_charges,
        total_produits=pair_produits,
        ecart=CrpEcart(
            previsions_totales=Decimal("0"),
            realise=Decimal(produits) - Decimal(charges),
            is_equilibre_required=False,
        ),
    )


def _aff_row(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "variante": "prive_I",
        "ventilation": "simple",
        "cr_id": CR_A,
        "compte_m22bis": "11501",
        "compte_label": "Report excédentaire",
        "montant_soins_dependance": None,
        "montant_hebergement": None,
        "montant_total": Decimal("1000.00"),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# compute_resultats_bruts (§J.6)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_compute_resultats_bruts_per_cr(monkeypatch, owned_doc, patch_run_in_thread):
    monkeypatch.setattr(
        affectation_service.cr_repo,
        "list_by_document",
        lambda _: [
            {"id": CR_A, "denomination": "CRPP EHPAD", "etablissement_id": ETS_1},
            {"id": CR_B, "denomination": "CRPA SSIAD", "etablissement_id": None},
        ],
    )

    async def _totals_for(cr_id, company):
        if cr_id == CR_A:
            return _totals(cr_id=CR_A, charges="80000", produits="92000")
        return _totals(cr_id=CR_B, charges="30000", produits="30000")

    monkeypatch.setattr(affectation_service.crp_ligne_service, "totals", _totals_for)

    out = await affectation_service.compute_resultats_bruts(DOC_ID, COMPANY)
    assert len(out) == 2
    assert out[0].cr_id == CR_A
    assert out[0].resultat_brut == Decimal("12000")
    assert out[1].cr_id == CR_B
    assert out[1].resultat_brut == Decimal("0")


@pytest.mark.asyncio
async def test_compute_resultats_bruts_cross_tenant(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )
    with pytest.raises(NotFoundError):
        await affectation_service.compute_resultats_bruts(DOC_ID, COMPANY)


# ---------------------------------------------------------------------------
# list_affectations + validation in_memory
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_affectations_empty_returns_variante_auto(
    monkeypatch, owned_doc, patch_run_in_thread
):
    """Pas d'items → variante auto-déduite depuis OG, validation tolère sections=0."""
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "list_by_document",
        lambda _: [],
    )
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "get_doc_affectation_context",
        lambda doc, company: _make_ctx(),
    )
    monkeypatch.setattr(affectation_service.cr_repo, "list_by_document", lambda _: [])

    out = await affectation_service.list_affectations(DOC_ID, COMPANY)
    assert out.variante_active == "prive_I"
    assert out.items == []
    assert out.validation.valide is True  # pas de sections à affecter


@pytest.mark.asyncio
async def test_list_affectations_ecart_above_tolerance(monkeypatch, owned_doc, patch_run_in_thread):
    """variant_I : 1 CR avec résultat 12000, affectation 11000 → écart 1000."""
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "list_by_document",
        lambda _: [_aff_row(montant_total=Decimal("11000"))],
    )
    monkeypatch.setattr(
        affectation_service.cr_repo,
        "list_by_document",
        lambda _: [{"id": CR_A, "denomination": "CRPP", "etablissement_id": ETS_1}],
    )

    async def _totals_for(cr_id, company):
        return _totals(cr_id=CR_A, charges="80000", produits="92000")

    monkeypatch.setattr(affectation_service.crp_ligne_service, "totals", _totals_for)

    out = await affectation_service.list_affectations(DOC_ID, COMPANY)
    assert out.validation.valide is False
    assert len(out.validation.issues) == 1
    issue = out.validation.issues[0]
    assert issue.code == "ecart_above_tolerance"
    assert issue.ecart == Decimal("-1000")
    assert issue.cr_id == CR_A


@pytest.mark.asyncio
async def test_list_affectations_section_unaffected(monkeypatch, owned_doc, patch_run_in_thread):
    """CR avec résultat 5000 mais aucune affectation → section_unaffected."""
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "list_by_document",
        lambda _: [],  # aucune affectation
    )
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "get_doc_affectation_context",
        lambda doc, company: _make_ctx(),
    )
    monkeypatch.setattr(
        affectation_service.cr_repo,
        "list_by_document",
        lambda _: [{"id": CR_A, "denomination": "CRPP", "etablissement_id": ETS_1}],
    )

    async def _totals_for(cr_id, company):
        return _totals(cr_id=CR_A, charges="80000", produits="85000")

    monkeypatch.setattr(affectation_service.crp_ligne_service, "totals", _totals_for)

    out = await affectation_service.list_affectations(DOC_ID, COMPANY)
    # Pas d'items donc variant_I (déduction OG) mais 0 items → pas d'issue
    # car la logique skip si pas de variant_I/II declared. Vérifions le
    # comportement réel.
    # Note : variante_active vient de _resolve_variante(ctx) = prive_I
    # → on entre dans la branche variant_I → loop resultats_bruts →
    # section CR_A a resultat != 0 et sum_by_cr ne contient pas CR_A →
    # section_unaffected expected.
    issues = [i for i in out.validation.issues if i.code == "section_unaffected"]
    assert len(issues) == 1
    assert issues[0].cr_id == CR_A


@pytest.mark.asyncio
async def test_list_affectations_balance_perfect(monkeypatch, owned_doc, patch_run_in_thread):
    """Σ B = A exactement → valide."""
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "list_by_document",
        lambda _: [
            _aff_row(montant_total=Decimal("8000"), compte_m22bis="11501"),
            _aff_row(montant_total=Decimal("4000"), compte_m22bis="106852"),
        ],
    )
    monkeypatch.setattr(
        affectation_service.cr_repo,
        "list_by_document",
        lambda _: [{"id": CR_A, "denomination": "CRPP", "etablissement_id": ETS_1}],
    )

    async def _totals_for(cr_id, company):
        return _totals(cr_id=CR_A, charges="80000", produits="92000")

    monkeypatch.setattr(affectation_service.crp_ligne_service, "totals", _totals_for)

    out = await affectation_service.list_affectations(DOC_ID, COMPANY)
    assert out.validation.valide is True
    assert out.validation.issues == []


# ---------------------------------------------------------------------------
# put_affectations_bulk
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_put_variant_I_happy(monkeypatch, patch_run_in_thread):
    """Privé hors CPOM → variant_I avec cr_id obligatoire."""
    captured = {}
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "get_doc_affectation_context",
        lambda doc, company: _make_ctx(),
    )
    monkeypatch.setattr(
        affectation_service.cr_repo,
        "list_by_document",
        lambda _: [
            {"id": CR_A, "denomination": "CRPP", "etablissement_id": ETS_1, "ventilation": "simple"}
        ],
    )
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "cr_belongs_to_document",
        lambda cr, doc: True,
    )
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "delete_by_document",
        lambda _: 0,
    )

    def _fake_bulk_I(**kwargs):
        captured["variant_I"] = kwargs
        return [_aff_row()]

    monkeypatch.setattr(affectation_service.affectation_repo, "bulk_upsert_variant_I", _fake_bulk_I)
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "list_by_document",
        lambda _: [_aff_row()],
    )

    async def _totals_for(cr_id, company):
        return _totals(cr_id=CR_A, charges="80000", produits="81000")

    monkeypatch.setattr(affectation_service.crp_ligne_service, "totals", _totals_for)

    # mock suivi auto-refresh
    from piilot.sdk.db import cursor as _cursor  # noqa: F401

    monkeypatch.setattr(
        affectation_service.suivi_affectation_repo,
        "lookup_n_minus_1_balances",
        lambda **kw: {},
    )
    monkeypatch.setattr(
        affectation_service.suivi_affectation_repo,
        "bulk_replace_by_document",
        lambda **kw: [],
    )

    async def _annee(ctx):
        return 2026

    monkeypatch.setattr(affectation_service, "_get_exercice_annee", _annee)

    out = await affectation_service.put_affectations_bulk(
        DOC_ID,
        COMPANY,
        AffectationBulkRequest(
            items=[
                AffectationItemCreate(
                    compte_m22bis="11501",
                    cr_id=CR_A,
                    montant_total=Decimal("1000"),
                )
            ]
        ),
    )
    assert captured["variant_I"]["variante"] == "prive_I"
    assert out.variante_active == "prive_I"


@pytest.mark.asyncio
async def test_put_variant_II_consolidé(monkeypatch, patch_run_in_thread):
    """Privé inclus CPOM → variant_II avec cr_id NULL."""
    captured = {}
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "get_doc_affectation_context",
        lambda doc, company: _make_ctx(any_inclus_cpom=True),
    )
    monkeypatch.setattr(
        affectation_service.cr_repo,
        "list_by_document",
        lambda _: [
            {"id": CR_A, "denomination": "CRPP", "etablissement_id": ETS_1, "ventilation": "simple"}
        ],
    )
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "delete_by_document",
        lambda _: 0,
    )

    def _fake_bulk_II(**kwargs):
        captured["variant_II"] = kwargs
        return [_aff_row(variante="prive_II", cr_id=None)]

    monkeypatch.setattr(
        affectation_service.affectation_repo, "bulk_upsert_variant_II", _fake_bulk_II
    )
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "list_by_document",
        lambda _: [_aff_row(variante="prive_II", cr_id=None)],
    )

    async def _totals_for(cr_id, company):
        return _totals(cr_id=CR_A, charges="80000", produits="81000")

    monkeypatch.setattr(affectation_service.crp_ligne_service, "totals", _totals_for)
    monkeypatch.setattr(
        affectation_service.suivi_affectation_repo,
        "lookup_n_minus_1_balances",
        lambda **kw: {},
    )
    monkeypatch.setattr(
        affectation_service.suivi_affectation_repo,
        "bulk_replace_by_document",
        lambda **kw: [],
    )

    async def _annee(ctx):
        return 2026

    monkeypatch.setattr(affectation_service, "_get_exercice_annee", _annee)

    out = await affectation_service.put_affectations_bulk(
        DOC_ID,
        COMPANY,
        AffectationBulkRequest(
            items=[
                AffectationItemCreate(
                    compte_m22bis="11501",
                    cr_id=None,  # consolidé
                    montant_total=Decimal("1000"),
                )
            ]
        ),
    )
    assert captured["variant_II"]["variante"] == "prive_II"
    assert out.variante_active == "prive_II"


@pytest.mark.asyncio
async def test_put_variant_I_missing_cr_id_raises(monkeypatch, patch_run_in_thread):
    """variant_I sans cr_id → 422 ValidationError."""
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "get_doc_affectation_context",
        lambda doc, company: _make_ctx(),  # privé hors CPOM
    )
    monkeypatch.setattr(
        affectation_service.cr_repo,
        "list_by_document",
        lambda _: [],
    )
    with pytest.raises(ValidationError) as exc:
        await affectation_service.put_affectations_bulk(
            DOC_ID,
            COMPANY,
            AffectationBulkRequest(
                items=[
                    AffectationItemCreate(
                        compte_m22bis="11501",
                        cr_id=None,
                        montant_total=Decimal("1000"),
                    )
                ]
            ),
        )
    assert exc.value.code == "missing_cr_id"


@pytest.mark.asyncio
async def test_put_variant_II_with_cr_id_raises(monkeypatch, patch_run_in_thread):
    """variant_II avec cr_id → 422 cr_id_not_allowed."""
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "get_doc_affectation_context",
        lambda doc, company: _make_ctx(any_inclus_cpom=True),
    )
    monkeypatch.setattr(
        affectation_service.cr_repo,
        "list_by_document",
        lambda _: [],
    )
    with pytest.raises(ValidationError) as exc:
        await affectation_service.put_affectations_bulk(
            DOC_ID,
            COMPANY,
            AffectationBulkRequest(
                items=[
                    AffectationItemCreate(
                        compte_m22bis="11501",
                        cr_id=CR_A,
                        montant_total=Decimal("1000"),
                    )
                ]
            ),
        )
    assert exc.value.code == "cr_id_not_allowed"


@pytest.mark.asyncio
async def test_put_unknown_statut_raises(monkeypatch, patch_run_in_thread):
    """OG avec nature_juridique inconnu → og_nature_juridique_unknown."""
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "get_doc_affectation_context",
        lambda doc, company: _make_ctx(nature_juridique="weird"),
    )
    with pytest.raises(ValidationError) as exc:
        await affectation_service.put_affectations_bulk(
            DOC_ID,
            COMPANY,
            AffectationBulkRequest(items=[]),
        )
    assert exc.value.code == "og_nature_juridique_unknown"


@pytest.mark.asyncio
async def test_put_doc_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "get_doc_affectation_context",
        lambda doc, company: None,
    )
    with pytest.raises(NotFoundError) as exc:
        await affectation_service.put_affectations_bulk(
            DOC_ID, COMPANY, AffectationBulkRequest(items=[])
        )
    assert exc.value.code == "document_not_found"


# ---------------------------------------------------------------------------
# validate_allocations + list_suivi_affectations
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_validate_returns_validation_field(monkeypatch, owned_doc, patch_run_in_thread):
    """:validate ré-utilise list_affectations.validation."""
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "list_by_document",
        lambda _: [],
    )
    monkeypatch.setattr(
        affectation_service.affectation_repo,
        "get_doc_affectation_context",
        lambda doc, company: _make_ctx(),
    )
    monkeypatch.setattr(affectation_service.cr_repo, "list_by_document", lambda _: [])

    result = await affectation_service.validate_allocations(DOC_ID, COMPANY)
    assert result.valide is True
    assert result.tolerance_appliquee == Decimal("0.01")


@pytest.mark.asyncio
async def test_list_suivi_affectations(monkeypatch, owned_doc, patch_run_in_thread):
    monkeypatch.setattr(
        affectation_service.suivi_affectation_repo,
        "list_by_document",
        lambda _: [
            {
                "id": uuid4(),
                "company_id": COMPANY,
                "document_id": DOC_ID,
                "etablissement_id": ETS_1,
                "compte_m22bis": "11501",
                "solde_debut_n": Decimal("500"),
                "mouvements_credit": Decimal("1000"),
                "mouvements_debit": Decimal("0"),
                "solde_fin_n": Decimal("1500"),
                "created_at": datetime.now(UTC),
            }
        ],
    )
    out = await affectation_service.list_suivi_affectations(DOC_ID, COMPANY)
    assert len(out) == 1
    assert out[0].compte_m22bis == "11501"
    assert out[0].solde_fin_n == Decimal("1500")
