"""Route tests for emprunts endpoints (L2 §16.3-§16.4, 2 endpoints)."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.emprunts import (
    EmpruntRead,
    EmpruntsMontants,
    EmpruntsResponse,
    EmpruntsTotals,
)
from piilot_pack_compta_esms.routes import emprunts as emprunts_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import emprunts_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)


def _ligne_read(**overrides) -> EmpruntRead:
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "type_dette": "emprunts_prives",
        "libelle": "Crédit",
        "capital_emprunte": Decimal("100000"),
        "taux": Decimal("2.5"),
        "duree_annees": 15,
        "date_debut": None,
        "capital_rembourse_n1": None,
        "capital_rembourse_n": None,
        "interets_n1": None,
        "interets_n": None,
        "solde_restant_du": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return EmpruntRead.model_validate(base)


def _totals_zero() -> EmpruntsTotals:
    return EmpruntsTotals(
        by_type_dette=[],
        total_general=EmpruntsMontants(
            capital_emprunte_total=Decimal("0"),
            capital_rembourse_n1_total=Decimal("0"),
            capital_rembourse_n_total=Decimal("0"),
            interets_n1_total=Decimal("0"),
            interets_n_total=Decimal("0"),
            solde_restant_du_total=Decimal("0"),
        ),
    )


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(emprunts_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# §16.3 GET /emprunts
# ---------------------------------------------------------------------------


def test_get_emprunts_no_filter_200(client, monkeypatch):
    async def _fake(doc, company, type_dette=None):
        return EmpruntsResponse(
            type_dette_filtre=None,
            items=[_ligne_read()],
            totals=_totals_zero(),
        )

    monkeypatch.setattr(emprunts_service, "list_emprunts", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/emprunts")
    assert r.status_code == 200
    body = r.json()
    assert body["type_dette_filtre"] is None
    assert len(body["items"]) == 1


def test_get_emprunts_with_filter_200(client, monkeypatch):
    captured = {}

    async def _fake(doc, company, type_dette=None):
        captured["type_dette"] = type_dette
        return EmpruntsResponse(
            type_dette_filtre=type_dette,
            items=[],
            totals=_totals_zero(),
        )

    monkeypatch.setattr(emprunts_service, "list_emprunts", _fake)
    r = client.get(
        f"/plugins/compta_esms/documents/{DOC_ID}/emprunts",
        params={"type_dette": "dettes_financieres_publics_3"},
    )
    assert r.status_code == 200
    assert captured["type_dette"] == "dettes_financieres_publics_3"
    assert r.json()["type_dette_filtre"] == "dettes_financieres_publics_3"


def test_get_emprunts_invalid_filter_422(client):
    r = client.get(
        f"/plugins/compta_esms/documents/{DOC_ID}/emprunts",
        params={"type_dette": "invalid_value"},
    )
    assert r.status_code == 422


def test_get_emprunts_404(client, monkeypatch):
    async def _fake(doc, company, type_dette=None):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(emprunts_service, "list_emprunts", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/emprunts")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §16.4 POST :bulk-upsert
# ---------------------------------------------------------------------------


def test_bulk_upsert_200(client, monkeypatch):
    captured = {}

    async def _fake(doc, company, payload):
        captured["type_dette"] = payload.type_dette
        return EmpruntsResponse(
            type_dette_filtre=payload.type_dette,
            items=[],
            totals=_totals_zero(),
        )

    monkeypatch.setattr(emprunts_service, "bulk_upsert_emprunts", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/emprunts:bulk-upsert",
        json={
            "type_dette": "dettes_financieres_publics_2",
            "items": [
                {
                    "libelle": "Caisse Dépôts",
                    "capital_emprunte": "300000",
                    "taux": "1.5",
                    "duree_annees": 20,
                }
            ],
        },
    )
    assert r.status_code == 200
    assert captured["type_dette"] == "dettes_financieres_publics_2"


def test_bulk_upsert_403_user_role(client):
    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/emprunts:bulk-upsert",
        json={"type_dette": "emprunts_prives", "items": []},
    )
    assert r.status_code == 403


def test_bulk_upsert_invalid_type_dette_422(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/emprunts:bulk-upsert",
        json={"type_dette": "invalid_type", "items": []},
    )
    assert r.status_code == 422


def test_bulk_upsert_missing_type_dette_422(client):
    """``type_dette`` est top-level obligatoire (Q4)."""
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/emprunts:bulk-upsert",
        json={"items": []},
    )
    assert r.status_code == 422


def test_bulk_upsert_taux_out_of_range_422(client):
    """taux ∈ [0, 100]."""
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/emprunts:bulk-upsert",
        json={
            "type_dette": "emprunts_prives",
            "items": [{"taux": "150"}],
        },
    )
    assert r.status_code == 422
