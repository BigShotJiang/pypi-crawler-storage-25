"""Tests §BI.2 — service ``rapport_sections_service``.

Couvre :

* find_or_create_rapport_kb : crée si absent, retourne existant idempotent
* materialize_for_document : insère 9 rows initiales + idempotent
* load_sections_by_code : retourne dict {section_code: contenu_md}
  ou {} si KB absente
"""

from __future__ import annotations

from typing import Any
from uuid import uuid4

import pytest
from piilot.sdk import knowledge

from piilot_pack_compta_esms.services import rapport_sections_service

COMPANY = uuid4()
DOC_ID = uuid4()
USER_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    """Sync passthrough — les tests mockent les SDK calls directement."""

    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.rapport_sections_service.run_in_thread",
        _passthrough,
    )


# ---------------------------------------------------------------------------
# find_or_create_rapport_kb
# ---------------------------------------------------------------------------


def test_find_or_create_returns_existing_kb_when_found(monkeypatch) -> None:
    """KB plugin-owned existante → retourne son id sans create_kb."""
    monkeypatch.setattr(
        knowledge,
        "find_kbs",
        lambda **kw: [
            {"kb_id": "existing-kb-uuid", "owner_type": "plugin", "name": "X"},
        ],
    )
    create_called: list[bool] = []
    monkeypatch.setattr(
        knowledge,
        "create_kb",
        lambda **kw: create_called.append(True) or {"id": "should-not-create"},
    )
    out = rapport_sections_service.find_or_create_rapport_kb(COMPANY)
    assert out == "existing-kb-uuid"
    assert not create_called


def test_find_or_create_skips_non_plugin_kbs(monkeypatch) -> None:
    """Une KB user-owned ne doit pas être réutilisée (filter owner_type)."""
    monkeypatch.setattr(
        knowledge,
        "find_kbs",
        lambda **kw: [
            {"kb_id": "user-kb", "owner_type": "user", "name": "user"},
        ],
    )
    columns_added: list[dict] = []

    def _create(**kw):
        return {"id": "new-plugin-kb"}

    def _add_col(kb_id, **kw):
        columns_added.append({"kb_id": kb_id, **kw})
        return {"id": "col"}

    monkeypatch.setattr(knowledge, "create_kb", _create)
    monkeypatch.setattr(knowledge, "add_column", _add_col)
    out = rapport_sections_service.find_or_create_rapport_kb(COMPANY)
    assert out == "new-plugin-kb"
    # 5 colonnes attendues — contrat schéma
    assert len(columns_added) == 5
    names = [c["name"] for c in columns_added]
    assert names == ["document_id", "section_code", "contenu_md", "auteur", "date_maj"]


def test_find_or_create_creates_schema_locked_kb(monkeypatch) -> None:
    """La KB plugin doit être créée avec schema_locked=True (plugin owns)."""
    monkeypatch.setattr(knowledge, "find_kbs", lambda **kw: [])
    capture: dict = {}

    def _create(**kw):
        capture.update(kw)
        return {"id": "new-kb"}

    monkeypatch.setattr(knowledge, "create_kb", _create)
    monkeypatch.setattr(knowledge, "add_column", lambda *a, **k: {"id": "col"})
    rapport_sections_service.find_or_create_rapport_kb(COMPANY)
    assert capture["schema_locked"] is True


# ---------------------------------------------------------------------------
# materialize_for_document
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_materialize_inserts_9_initial_rows(monkeypatch, patch_run_in_thread) -> None:
    """1er appel pour ce document → 9 rows insérées (1 par section_code)."""
    monkeypatch.setattr(
        knowledge,
        "find_kbs",
        lambda **kw: [{"kb_id": "kb-1", "owner_type": "plugin", "name": "X"}],
    )
    monkeypatch.setattr(knowledge, "find_rows", lambda **kw: [])
    captured_batch: list[list[dict]] = []

    def _batch(kb_id, rows):
        captured_batch.append(rows)
        return len(rows)

    monkeypatch.setattr(knowledge, "insert_batch", _batch)

    out = await rapport_sections_service.materialize_for_document(
        document_id=DOC_ID,
        company_id=COMPANY,
        user_id=USER_ID,
    )
    assert out["kb_id"] == "kb-1"
    assert out["rows_inserted"] == 9
    assert out["was_idempotent"] is False
    assert len(captured_batch) == 1
    rows = captured_batch[0]
    assert len(rows) == 9
    section_codes = {r["data"]["section_code"] for r in rows}
    assert (
        section_codes == set(rapport_sections_service.SECTION_CODES)  # type: ignore[attr-defined]
        if hasattr(rapport_sections_service, "SECTION_CODES")
        else section_codes
    )
    # Toutes les rows portent le bon document_id
    for r in rows:
        assert r["data"]["document_id"] == str(DOC_ID)
        assert r["data"]["auteur"] == str(USER_ID)
        assert r["data"]["contenu_md"] == ""


@pytest.mark.asyncio
async def test_materialize_idempotent_no_op_if_rows_exist(monkeypatch, patch_run_in_thread) -> None:
    """Re-call avec rows déjà présentes → 0 insert, was_idempotent=True."""
    monkeypatch.setattr(
        knowledge,
        "find_kbs",
        lambda **kw: [{"kb_id": "kb-existing", "owner_type": "plugin"}],
    )
    # find_rows retourne ≥1 row → idempotent path
    monkeypatch.setattr(
        knowledge,
        "find_rows",
        lambda **kw: [{"id": "row1", "data": {"section_code": "AVANCEMENT_CPOM"}}],
    )
    batch_calls: list[Any] = []
    monkeypatch.setattr(
        knowledge,
        "insert_batch",
        lambda kb_id, rows: batch_calls.append((kb_id, rows)) or len(rows),
    )

    out = await rapport_sections_service.materialize_for_document(
        document_id=DOC_ID,
        company_id=COMPANY,
    )
    assert out["was_idempotent"] is True
    assert out["rows_inserted"] == 0
    assert batch_calls == []  # insert_batch jamais appelé


@pytest.mark.asyncio
async def test_materialize_accepts_user_id_none(monkeypatch, patch_run_in_thread) -> None:
    """user_id=None → auteur vide dans les rows (compat hook create_document)."""
    monkeypatch.setattr(
        knowledge,
        "find_kbs",
        lambda **kw: [{"kb_id": "kb-1", "owner_type": "plugin"}],
    )
    monkeypatch.setattr(knowledge, "find_rows", lambda **kw: [])
    captured: list[list[dict]] = []
    monkeypatch.setattr(
        knowledge,
        "insert_batch",
        lambda kb_id, rows: captured.append(rows) or len(rows),
    )

    await rapport_sections_service.materialize_for_document(
        document_id=DOC_ID,
        company_id=COMPANY,
        user_id=None,
    )
    rows = captured[0]
    assert all(r["data"]["auteur"] == "" for r in rows)


# ---------------------------------------------------------------------------
# load_sections_by_code
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_load_sections_returns_dict_keyed_by_code(monkeypatch, patch_run_in_thread) -> None:
    """find_rows → mapping section_code → contenu_md."""
    monkeypatch.setattr(
        knowledge,
        "find_kbs",
        lambda **kw: [{"kb_id": "kb-1", "owner_type": "plugin"}],
    )
    monkeypatch.setattr(
        knowledge,
        "find_rows",
        lambda **kw: [
            {"data": {"section_code": "OBSERVATIONS_GENERALES", "contenu_md": "Commentaire A"}},
            {"data": {"section_code": "PGFP", "contenu_md": "Commentaire B"}},
            {"data": {"section_code": "AVANCEMENT_CPOM", "contenu_md": ""}},
        ],
    )
    out = await rapport_sections_service.load_sections_by_code(
        document_id=DOC_ID, company_id=COMPANY
    )
    assert out == {
        "OBSERVATIONS_GENERALES": "Commentaire A",
        "PGFP": "Commentaire B",
        "AVANCEMENT_CPOM": "",
    }


@pytest.mark.asyncio
async def test_load_sections_empty_when_kb_missing(monkeypatch, patch_run_in_thread) -> None:
    """KB pas trouvée (EPRD pre-§BI) → dict vide, pas de raise."""
    monkeypatch.setattr(knowledge, "find_kbs", lambda **kw: [])

    out = await rapport_sections_service.load_sections_by_code(
        document_id=DOC_ID, company_id=COMPANY
    )
    assert out == {}


@pytest.mark.asyncio
async def test_load_sections_skips_rows_without_section_code(
    monkeypatch, patch_run_in_thread
) -> None:
    """Row sans section_code (data corruption) → skip silencieux."""
    monkeypatch.setattr(
        knowledge,
        "find_kbs",
        lambda **kw: [{"kb_id": "kb-1", "owner_type": "plugin"}],
    )
    monkeypatch.setattr(
        knowledge,
        "find_rows",
        lambda **kw: [
            {"data": {"contenu_md": "orphan"}},  # pas de section_code
            {"data": {"section_code": "PGFP", "contenu_md": "valid"}},
        ],
    )
    out = await rapport_sections_service.load_sections_by_code(
        document_id=DOC_ID, company_id=COMPANY
    )
    assert out == {"PGFP": "valid"}


@pytest.mark.asyncio
async def test_load_sections_dedup_keeps_first(monkeypatch, patch_run_in_thread) -> None:
    """Doublons (anomalie) → garde le 1er pour reproductibilité."""
    monkeypatch.setattr(
        knowledge,
        "find_kbs",
        lambda **kw: [{"kb_id": "kb-1", "owner_type": "plugin"}],
    )
    monkeypatch.setattr(
        knowledge,
        "find_rows",
        lambda **kw: [
            {"data": {"section_code": "PGFP", "contenu_md": "first"}},
            {"data": {"section_code": "PGFP", "contenu_md": "duplicate"}},
        ],
    )
    out = await rapport_sections_service.load_sections_by_code(
        document_id=DOC_ID, company_id=COMPANY
    )
    assert out == {"PGFP": "first"}
