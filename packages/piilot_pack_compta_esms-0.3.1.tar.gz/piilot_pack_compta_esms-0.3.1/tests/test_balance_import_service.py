"""Unit tests for :mod:`piilot_pack_compta_esms.services.balance_import_service`.

The service orchestrates parser + storage + repo. We mock storage
(no S3) and the repo (no DB) to verify the orchestration."""

from __future__ import annotations

import io
from datetime import UTC, datetime
from uuid import uuid4

import pytest
from openpyxl import Workbook

from piilot_pack_compta_esms.models.balance_import import ColumnHints
from piilot_pack_compta_esms.services import balance_import_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)

COMPANY = uuid4()
USER = uuid4()
IMPORT_ID = uuid4()


def _build_xlsx_body() -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.append(["Compte", "Libellé", "Débit", "Crédit", "Solde"])
    ws.append(["60611", "Eau", 12.5, 0, 12.5])
    ws.append(["60612", "Électricité", 8.5, 0, 8.5])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _make_row(**overrides):
    base = {
        "id": IMPORT_ID,
        "company_id": COMPANY,
        "exercice_id": None,
        "etablissement_id": None,
        "source_plan": "PCG",
        "source_filename": "balance.xlsx",
        "source_storage_key": "plugins/compta_esms/balance_imports/x/balance.xlsx",
        "periode_label": "2025-12",
        "nb_lignes_source": 2,
        "nb_lignes_mappees": 0,
        "nb_lignes_non_mappees": 0,
        "column_detection": {
            "compte": 0,
            "libelle": 1,
            "debit": 2,
            "credit": 3,
            "solde": 4,
            "periode": None,
        },
        "preview_data": {
            "header": ["Compte", "Libellé", "Débit", "Crédit", "Solde"],
            "rows": [["60611", "Eau", 12.5, 0, 12.5]],
        },
        "mapping_snapshot": {},
        "materialized_kb_id": None,
        "materialized_kb_table_name": None,
        "status": "pending",
        "error_payload": {},
        "imported_by_user_id": USER,
        "imported_at": datetime.now(UTC),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.balance_import_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def fake_storage(monkeypatch):
    captured: dict = {}

    async def _put(key, body, content_type="application/octet-stream"):
        captured["key"] = key
        captured["body_len"] = len(body)
        captured["content_type"] = content_type
        return f"plugins/compta_esms/{key}"

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.balance_import_service.storage.put_object",
        _put,
    )
    return captured


@pytest.mark.asyncio
async def test_upload_rejects_unsupported_extension(monkeypatch, patch_run_in_thread, fake_storage):
    with pytest.raises(ConflictError) as exc:
        await balance_import_service.upload_balance(
            company_id=COMPANY,
            user_id=USER,
            file_bytes=b"x",
            filename="balance.pdf",
            source_plan="PCG",
            periode_label="2025-12",
        )
    assert exc.value.code == "balance_import_unsupported_format"


@pytest.mark.asyncio
async def test_upload_rejects_empty_file(monkeypatch, patch_run_in_thread, fake_storage):
    """An XLSX with header but no data rows → 409 ``balance_import_empty``."""
    wb = Workbook()
    ws = wb.active
    ws.append(["Compte", "Libellé"])  # header only
    buf = io.BytesIO()
    wb.save(buf)
    body = buf.getvalue()

    with pytest.raises(ConflictError) as exc:
        await balance_import_service.upload_balance(
            company_id=COMPANY,
            user_id=USER,
            file_bytes=body,
            filename="balance.xlsx",
            source_plan="PCG",
            periode_label="2025-12",
        )
    assert exc.value.code == "balance_import_empty"


@pytest.mark.asyncio
async def test_upload_happy_path(monkeypatch, patch_run_in_thread, fake_storage):
    captured_create: dict = {}

    def _create(**kw):
        captured_create.update(kw)
        return _make_row(**{k: v for k, v in kw.items() if k != "user_id"})

    monkeypatch.setattr(balance_import_service.balance_import_repo, "create", _create)

    out = await balance_import_service.upload_balance(
        company_id=COMPANY,
        user_id=USER,
        file_bytes=_build_xlsx_body(),
        filename="balance.xlsx",
        source_plan="PCG",
        periode_label="2025-12",
    )
    assert out.nb_lignes_source == 2
    assert out.column_detection["compte"] == 0

    # S3 upload happened
    assert "balance_imports/" in fake_storage["key"]
    assert fake_storage["key"].endswith("balance.xlsx")
    assert fake_storage["content_type"].startswith("application/vnd.openxml")

    # Sanitized body uploaded — not the original (round-trip changes bytes)
    assert fake_storage["body_len"] > 0

    # DB row stamped with the user + S3 key returned by put_object
    assert captured_create["source_storage_key"].startswith("plugins/compta_esms/")
    assert captured_create["company_id"] == COMPANY
    assert captured_create["user_id"] == USER


@pytest.mark.asyncio
async def test_get_import_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(balance_import_service.balance_import_repo, "get_by_id", lambda _: None)
    with pytest.raises(NotFoundError) as exc:
        await balance_import_service.get_import(IMPORT_ID)
    assert exc.value.code == "balance_import_not_found"


@pytest.mark.asyncio
async def test_get_import_happy(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_import_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_row(),
    )
    out = await balance_import_service.get_import(IMPORT_ID)
    assert out.id == IMPORT_ID
    assert out.status == "pending"


@pytest.mark.asyncio
async def test_detect_columns_applies_hints(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_import_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_row(),
    )

    captured: dict = {}

    def _update(import_id, detection):
        captured["detection"] = detection
        return _make_row(column_detection=detection)

    monkeypatch.setattr(
        balance_import_service.balance_import_repo,
        "update_column_detection",
        _update,
    )

    out = await balance_import_service.detect_columns(IMPORT_ID, ColumnHints(periode=5))
    assert out.column_detection["periode"] == 5
    # Other roles untouched
    assert captured["detection"]["compte"] == 0


@pytest.mark.asyncio
async def test_detect_columns_no_hints_keeps_current(monkeypatch, patch_run_in_thread):
    """Empty body re-persists the current detection (no-op-ish)."""
    monkeypatch.setattr(
        balance_import_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_row(),
    )
    monkeypatch.setattr(
        balance_import_service.balance_import_repo,
        "update_column_detection",
        lambda import_id, detection: _make_row(column_detection=detection),
    )
    out = await balance_import_service.detect_columns(IMPORT_ID, None)
    # Same detection as the make_row default
    assert out.column_detection["compte"] == 0


@pytest.mark.asyncio
async def test_get_preview_returns_header_and_rows(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_import_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_row(),
    )
    preview = await balance_import_service.get_preview(IMPORT_ID)
    assert preview.header == ["Compte", "Libellé", "Débit", "Crédit", "Solde"]
    assert preview.rows[0][0] == "60611"
    assert preview.column_detection["compte"] == 0


@pytest.mark.asyncio
async def test_get_preview_tolerates_legacy_empty_payload(monkeypatch, patch_run_in_thread):
    """Rows imported before migration 006 might have an empty preview_data
    — the service returns empty lists without raising."""
    monkeypatch.setattr(
        balance_import_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_row(preview_data={}),
    )
    preview = await balance_import_service.get_preview(IMPORT_ID)
    assert preview.header == []
    assert preview.rows == []
