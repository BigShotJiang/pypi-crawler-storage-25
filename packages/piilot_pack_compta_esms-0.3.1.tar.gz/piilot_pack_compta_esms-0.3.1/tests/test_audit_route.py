"""Route tests for ``GET /documents/{doc_id}/audit`` (§AI L2 §22.1, admin).

Mock le service (pas le repo) pour éviter ``run_in_thread`` non wiré
hors host — pattern identique à test_workflow_routes / test_balance_*.
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_admin, require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.audit import AuditEventRead
from piilot_pack_compta_esms.routes import audit as audit_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import audit_service
from piilot_pack_compta_esms.services.errors import NotFoundError, ValidationError

COMPANY = uuid4()
USER = uuid4()
DOC = uuid4()
ADMIN_AUTH = (USER, "admin", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


def _audit_event(action="workflow.transmit", payload=None):
    return AuditEventRead(
        id=uuid4(),
        company_id=COMPANY,
        user_id=USER,
        document_id=DOC,
        action=action,
        resource_type="document",
        resource_id=DOC,
        payload=payload or {},
        occurred_at=datetime.now(UTC),
    )


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(audit_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_admin] = lambda: ADMIN_AUTH
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: USER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# Happy path + filtres
# ---------------------------------------------------------------------------


def test_list_audit_events_200_default_limit(client, monkeypatch):
    captured: dict = {}

    async def _fake(document_id, company_id, *, action_filter=None, limit=50):
        captured["doc"] = document_id
        captured["company"] = company_id
        captured["action_filter"] = action_filter
        captured["limit"] = limit
        return [_audit_event("workflow.transmit", {"from": "brouillon", "to": "transmis"})]

    monkeypatch.setattr(audit_service, "list_for_document", _fake)

    r = client.get(f"/plugins/compta_esms/documents/{DOC}/audit")
    assert r.status_code == 200
    body = r.json()
    assert len(body) == 1
    assert body[0]["action"] == "workflow.transmit"
    assert body[0]["payload"] == {"from": "brouillon", "to": "transmis"}
    assert captured["action_filter"] is None
    assert captured["limit"] == 50
    assert str(captured["doc"]) == str(DOC)
    assert str(captured["company"]) == str(COMPANY)


def test_list_audit_events_filter_by_action(client, monkeypatch):
    captured: dict = {}

    async def _fake(document_id, company_id, *, action_filter=None, limit=50):
        captured["action_filter"] = action_filter
        return [_audit_event(action="rgpd.consentement_saisi")]

    monkeypatch.setattr(audit_service, "list_for_document", _fake)

    r = client.get(f"/plugins/compta_esms/documents/{DOC}/audit?action=rgpd.consentement_saisi")
    assert r.status_code == 200
    assert captured["action_filter"] == "rgpd.consentement_saisi"


def test_list_audit_events_custom_limit(client, monkeypatch):
    captured: dict = {}

    async def _fake(document_id, company_id, *, action_filter=None, limit=50):
        captured["limit"] = limit
        return []

    monkeypatch.setattr(audit_service, "list_for_document", _fake)

    r = client.get(f"/plugins/compta_esms/documents/{DOC}/audit?limit=200")
    assert r.status_code == 200
    assert captured["limit"] == 200


# ---------------------------------------------------------------------------
# Erreurs
# ---------------------------------------------------------------------------


def test_list_audit_events_404_unknown_doc(client, monkeypatch):
    async def _fake(*args, **kwargs):
        raise NotFoundError(f"document_not_found:{DOC}", code="document_not_found")

    monkeypatch.setattr(audit_service, "list_for_document", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC}/audit")
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "document_not_found"


def test_list_audit_events_422_limit_too_high(client, monkeypatch):
    async def _fake(*args, **kwargs):
        raise ValidationError(
            "limit=10000 hors plage [1, 500].",
            code="audit_limit_out_of_range",
        )

    monkeypatch.setattr(audit_service, "list_for_document", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC}/audit?limit=10000")
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "audit_limit_out_of_range"


def test_list_audit_events_ordering_preserved(client, monkeypatch):
    """La route ne re-ordonne pas — sortent dans l'ordre du service."""

    rows = [
        _audit_event("workflow.transmit"),
        _audit_event("rgpd.consentement_saisi"),
        _audit_event("document.create"),
    ]

    async def _fake(document_id, company_id, *, action_filter=None, limit=50):
        return rows

    monkeypatch.setattr(audit_service, "list_for_document", _fake)

    r = client.get(f"/plugins/compta_esms/documents/{DOC}/audit")
    body = r.json()
    assert [row["action"] for row in body] == [
        "workflow.transmit",
        "rgpd.consentement_saisi",
        "document.create",
    ]


# ---------------------------------------------------------------------------
# Service-level tests (limit guard + tenant guard)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_service_rejects_limit_zero():
    """``list_for_document`` raise ValidationError pour limit < 1."""
    with pytest.raises(ValidationError) as exc_info:
        await audit_service.list_for_document(DOC, COMPANY, limit=0)
    assert exc_info.value.code == "audit_limit_out_of_range"


@pytest.mark.asyncio
async def test_service_rejects_limit_above_500():
    with pytest.raises(ValidationError) as exc_info:
        await audit_service.list_for_document(DOC, COMPANY, limit=501)
    assert exc_info.value.code == "audit_limit_out_of_range"
