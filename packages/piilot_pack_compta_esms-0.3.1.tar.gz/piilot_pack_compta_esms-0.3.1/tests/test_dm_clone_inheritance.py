"""Tests §V D-063 — héritage périmètre EPRD lors du clone DM/RIA.

Couvre :

* clone DM avec parent EPRD qui a 3 CRs → les 3 CRs sont copiés
  dans le DM clone (CRPP + CRPA + CRP_SF).
* clone DM avec parent EPRD sans CRs (cas dégénéré) → fallback
  ``create_with_default_crpp`` posé.
* clone DM depuis parent brouillon → ``is_simultaneous=True`` audit.
* clone DM depuis parent executoire → ``is_simultaneous=False`` audit.
* clone refuse new_type='errd' (`clone_invalid_new_type`).
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.document import DocumentClone
from piilot_pack_compta_esms.services import document_service

COMPANY = uuid4()
USER = uuid4()
PARENT_EPRD = uuid4()
EXERCICE = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.document_service.run_in_thread",
        _passthrough,
    )


def _make_parent(statut: str = "brouillon") -> dict[str, Any]:
    return {
        "id": PARENT_EPRD,
        "company_id": COMPANY,
        "exercice_id": EXERCICE,
        "type_document": "eprd",
        "statut": statut,
    }


def _make_cr(
    *, cr_type: str = "CRPP", denomination: str = "CRPP - 2026", ordre: int = 0
) -> dict[str, Any]:
    return {
        "cr_type": cr_type,
        "cr_variante": "non_soumis_equil",
        "denomination": denomination,
        "cr_identifiant": None,
        "etablissement_id": uuid4(),
        "finess_rattachement": None,
        "capacite_installee": 80,
        "amplitude_ouverture": 365,
        "ventilation": "ternaire_hds",
        "ordre": ordre,
    }


def _make_doc_row(
    *,
    type_document: str = "dm",
    cadre_version: str = "#DMHA-2026-01#",
    parent_id=PARENT_EPRD,
) -> dict[str, Any]:
    return {
        "id": uuid4(),
        "company_id": COMPANY,
        "exercice_id": EXERCICE,
        "type_document": type_document,
        "cadre_version": cadre_version,
        "parent_id": parent_id,
        "statut": "brouillon",
        "periode_observation_debut": None,
        "periode_observation_fin": None,
        "transmis_at": None,
        "executoire_at": None,
        "transmis_par_user_id": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }


@pytest.mark.asyncio
async def test_clone_dm_inherits_3_crs(monkeypatch, patch_run_in_thread):
    """Parent EPRD avec CRPP + CRPA + CRP_SF → DM hérite des 3."""
    monkeypatch.setattr(
        document_service.document_repo,
        "load_parent_for_clone",
        lambda _: _make_parent(statut="brouillon"),
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: {"id": EXERCICE, "company_id": COMPANY, "og_id": uuid4(), "annee": 2026},
    )
    parent_crs = [
        _make_cr(cr_type="CRPP", denomination="CRPP - 2026", ordre=0),
        _make_cr(cr_type="CRPA", denomination="CRPA 1", ordre=1),
        _make_cr(cr_type="CRP_SF", denomination="Section financière", ordre=2),
    ]
    monkeypatch.setattr(
        document_service.document_repo, "list_crs_of_document", lambda _: parent_crs
    )
    captured: dict = {}

    def _clone(**kwargs):
        captured.update(kwargs)
        return _make_doc_row()

    monkeypatch.setattr(document_service.document_repo, "clone_with_cr_inheritance", _clone)

    audit_calls: list[dict] = []

    def _audit(**kwargs):
        audit_calls.append(kwargs)

    monkeypatch.setattr(document_service.audit_service, "record_event", _audit)

    out = await document_service.clone_document(
        COMPANY, PARENT_EPRD, DocumentClone(new_type="dm"), user_id=USER
    )

    assert out.type_document == "dm"
    assert captured["parent_crs"] == parent_crs
    assert captured["cadre_version"] == "#DMHA-2026-01#"

    # Audit dm.create posé
    assert len(audit_calls) == 1
    audit = audit_calls[0]
    assert audit["action"] == "dm.create"
    assert audit["payload"]["parent_eprd_id"] == str(PARENT_EPRD)
    assert audit["payload"]["parent_statut"] == "brouillon"
    assert audit["payload"]["is_simultaneous"] is True
    assert audit["payload"]["inherited_cr_count"] == 3


@pytest.mark.asyncio
async def test_clone_dm_parent_executoire_not_simultaneous(monkeypatch, patch_run_in_thread):
    """Parent EPRD en executoire → is_simultaneous=False."""
    monkeypatch.setattr(
        document_service.document_repo,
        "load_parent_for_clone",
        lambda _: _make_parent(statut="executoire"),
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: {"id": EXERCICE, "company_id": COMPANY, "og_id": uuid4(), "annee": 2026},
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "list_crs_of_document",
        lambda _: [_make_cr()],
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "clone_with_cr_inheritance",
        lambda **kw: _make_doc_row(),
    )
    audit_calls: list[dict] = []
    monkeypatch.setattr(
        document_service.audit_service,
        "record_event",
        lambda **kw: audit_calls.append(kw),
    )

    await document_service.clone_document(
        COMPANY, PARENT_EPRD, DocumentClone(new_type="dm"), user_id=USER
    )

    assert audit_calls[0]["payload"]["is_simultaneous"] is False
    assert audit_calls[0]["payload"]["parent_statut"] == "executoire"


@pytest.mark.asyncio
async def test_clone_dm_no_parent_crs_fallback_default_crpp(monkeypatch, patch_run_in_thread):
    """Parent EPRD sans CRs (dégénéré) → fallback create_with_default_crpp."""
    monkeypatch.setattr(
        document_service.document_repo,
        "load_parent_for_clone",
        lambda _: _make_parent(),
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: {"id": EXERCICE, "company_id": COMPANY, "og_id": uuid4(), "annee": 2026},
    )
    monkeypatch.setattr(document_service.document_repo, "list_crs_of_document", lambda _: [])
    fallback_calls: list[dict] = []
    inheritance_calls: list[dict] = []

    def _fallback(**kw):
        fallback_calls.append(kw)
        return _make_doc_row()

    def _inheritance(**kw):
        inheritance_calls.append(kw)
        return _make_doc_row()

    monkeypatch.setattr(document_service.document_repo, "create_with_default_crpp", _fallback)
    monkeypatch.setattr(document_service.document_repo, "clone_with_cr_inheritance", _inheritance)
    monkeypatch.setattr(document_service.audit_service, "record_event", lambda **kw: None)

    await document_service.clone_document(
        COMPANY, PARENT_EPRD, DocumentClone(new_type="dm"), user_id=USER
    )

    # Fallback create_with_default_crpp utilisé, pas inheritance
    assert len(fallback_calls) == 1
    assert len(inheritance_calls) == 0
    assert fallback_calls[0]["crpp_denomination"] == "CRPP - DM 2026"


@pytest.mark.asyncio
async def test_clone_ria_inherits_perimeter(monkeypatch, patch_run_in_thread):
    """RIA hérite aussi du périmètre EPRD parent (KB23 §3.2)."""
    monkeypatch.setattr(
        document_service.document_repo,
        "load_parent_for_clone",
        lambda _: _make_parent(statut="executoire"),
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "exercice_lookup",
        lambda _: {"id": EXERCICE, "company_id": COMPANY, "og_id": uuid4(), "annee": 2026},
    )
    parent_crs = [_make_cr(), _make_cr(cr_type="CRPA", denomination="CRPA EHPAD 2")]
    monkeypatch.setattr(
        document_service.document_repo, "list_crs_of_document", lambda _: parent_crs
    )
    monkeypatch.setattr(
        document_service.document_repo,
        "clone_with_cr_inheritance",
        lambda **kw: _make_doc_row(type_document="ria", cadre_version="#RIAHA-2026-01#"),
    )
    audit_calls: list[dict] = []
    monkeypatch.setattr(
        document_service.audit_service,
        "record_event",
        lambda **kw: audit_calls.append(kw),
    )

    out = await document_service.clone_document(
        COMPANY, PARENT_EPRD, DocumentClone(new_type="ria"), user_id=USER
    )

    assert out.type_document == "ria"
    assert out.cadre_version == "#RIAHA-2026-01#"
    assert audit_calls[0]["action"] == "ria.create"
    assert audit_calls[0]["payload"]["inherited_cr_count"] == 2
