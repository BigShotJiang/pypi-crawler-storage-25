"""Tests for forfait dépendance + GMP départemental (§I.7).

Cas réels DGCS sourcés ``S03`` p.18-22 (formule + modulation R.314-174)."""

from __future__ import annotations

from decimal import Decimal

from piilot_pack_compta_esms.models.finance import (
    ForfaitDependanceInput,
    GmpDepartementalInput,
)
from piilot_pack_compta_esms.services.finance import (
    forfait_dependance_calculator as fdc,
)

# ---------------------------------------------------------------------------
# F.DEP.01 — formule de base
# ---------------------------------------------------------------------------


def test_forfait_dependance_formule_base_sans_modulation():
    """S03 p.19 : Forfait_CD = Forfait_global - [(particip × TO) + (hors_dep × TO)].
    Pas de modulation (annee < 2018 ou apply_modulation=False)."""
    result = fdc.compute_forfait_dependance_cd(
        ForfaitDependanceInput(
            forfait_global_dependance=Decimal("500000"),
            montant_participations_residents=Decimal("100000"),
            to_previsionnel=Decimal("0.95"),
            montant_hors_departement=Decimal("20000"),
            annee=2026,
            apply_modulation=False,
        )
    )
    # brut = 500000 - [(100000 × 0.95) + (20000 × 0.95)]
    #      = 500000 - 95000 - 19000 = 386000
    assert result.forfait_cd_implantation_brut == Decimal("386000.00")
    assert result.modulation_appliquee is False
    assert result.abattement_pct == Decimal("0")
    assert result.forfait_cd_implantation_module == Decimal("386000.00")


def test_forfait_dependance_to_100pct_desequilibre():
    """S03 p.19 — si TO retenu = 100% → budget dépendance présenté en déséquilibre
    (APA cessant d'être facturée au 1er jour d'absence)."""
    result = fdc.compute_forfait_dependance_cd(
        ForfaitDependanceInput(
            forfait_global_dependance=Decimal("500000"),
            montant_participations_residents=Decimal("100000"),
            to_previsionnel=Decimal("1"),
            annee=2026,
            apply_modulation=False,
        )
    )
    # brut = 500000 - 100000 = 400000 (déséquilibre acté côté calculator —
    # le caller / UI affiche un warning)
    assert result.forfait_cd_implantation_brut == Decimal("400000")


# ---------------------------------------------------------------------------
# F.GIR.03 — modulation R.314-174
# ---------------------------------------------------------------------------


def test_modulation_to_realise_below_seuil():
    """TO réalisé 75% < seuil 85% → abattement = (85-75)/2 = 5 points."""
    result = fdc.compute_forfait_dependance_cd(
        ForfaitDependanceInput(
            forfait_global_dependance=Decimal("100000"),
            to_previsionnel=Decimal("0.90"),
            annee=2026,
            to_realise=Decimal("0.75"),
            seuil_modulation_pct=Decimal("85"),
            apply_modulation=True,
        )
    )
    # brut = 100000 - 0 = 100000 (pas de particip ni hors-dep)
    # abattement = (0.85 - 0.75) / 2 = 0.05 → ×100 = 5 (en pct)
    assert result.modulation_appliquee is True
    assert result.abattement_pct == Decimal("5.0")
    # module = 100000 × (100-5)/100 = 95000
    assert result.forfait_cd_implantation_module == Decimal("95000.0000")


def test_modulation_to_above_95pct_no_modulation():
    """S03 p.22 — pas de modulation à la hausse au-dessus de 95% TO."""
    result = fdc.compute_forfait_dependance_cd(
        ForfaitDependanceInput(
            forfait_global_dependance=Decimal("100000"),
            to_previsionnel=Decimal("0.95"),
            annee=2026,
            to_realise=Decimal("0.96"),
            seuil_modulation_pct=Decimal("85"),
            apply_modulation=True,
        )
    )
    assert result.modulation_appliquee is False
    assert result.abattement_pct == Decimal("0")


def test_modulation_to_at_seuil_no_modulation():
    """TO réalisé = seuil → pas d'abattement."""
    result = fdc.compute_forfait_dependance_cd(
        ForfaitDependanceInput(
            forfait_global_dependance=Decimal("100000"),
            to_previsionnel=Decimal("0.85"),
            annee=2026,
            to_realise=Decimal("0.85"),
            seuil_modulation_pct=Decimal("85"),
            apply_modulation=True,
        )
    )
    assert result.modulation_appliquee is False


def test_modulation_disabled_cas_exceptionnel():
    """S03 p.22 — le CD peut renoncer à la modulation en cas exceptionnel.
    Flag apply_modulation=False → pas de modulation même si TO < seuil."""
    result = fdc.compute_forfait_dependance_cd(
        ForfaitDependanceInput(
            forfait_global_dependance=Decimal("100000"),
            to_previsionnel=Decimal("0.85"),
            annee=2026,
            to_realise=Decimal("0.70"),
            seuil_modulation_pct=Decimal("85"),
            apply_modulation=False,
        )
    )
    assert result.modulation_appliquee is False


# ---------------------------------------------------------------------------
# F.GIR.02 — GMP départemental
# ---------------------------------------------------------------------------


def test_gmp_departemental():
    """GMP = Σ(points × HP) / Σ(HP) hors USLD (S03 p.21)."""
    result = fdc.compute_gmp_departemental(
        GmpDepartementalInput(
            ehpads=[
                {"points_gir": Decimal("700"), "capacite_hp": Decimal("100")},
                {"points_gir": Decimal("750"), "capacite_hp": Decimal("80")},
                {"points_gir": Decimal("680"), "capacite_hp": Decimal("120")},
            ]
        )
    )
    # numerateur = 700*100 + 750*80 + 680*120 = 70000 + 60000 + 81600 = 211600
    # denominateur = 100 + 80 + 120 = 300
    # gmp = 211600 / 300 ≈ 705.33
    assert result.gmp.quantize(Decimal("0.01")) == Decimal("705.33")
    assert result.nb_ehpads == 3


def test_gmp_departemental_empty_returns_zero():
    """Liste vide ou Σ(HP)=0 → gmp=0 (defensive)."""
    result = fdc.compute_gmp_departemental(GmpDepartementalInput(ehpads=[]))
    assert result.gmp == Decimal("0")
    assert result.nb_ehpads == 0
