"""Unit tests for :mod:`piilot_pack_compta_esms.services.crp_prefill_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.kb_binding import (
    BindingPreviewResponse,
    BindingPreviewRow,
)
from piilot_pack_compta_esms.services import crp_prefill_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
CR_ID = uuid4()
DOC_ID = uuid4()
BINDING_ID = uuid4()
KB_ID = uuid4()


def _make_upserted_row(compte: str, target_column: str, value: Decimal, **overrides):
    now = datetime.now(UTC)
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "cr_id": CR_ID,
        "groupe": "G1",
        "nature": "charge",
        "compte_m22bis": compte,
        "compte_label": "label",
        "montant_budget_initial": None,
        "montant_virements_credits": None,
        "montant_decisions_modif": None,
        "montant_previsions_totales": None,
        "montant_realise": None,
        "montant_hebergement": None,
        "montant_dependance": None,
        "montant_soins": None,
        "montant_soins_autonomie": None,
        "binding_id": BINDING_ID,
        "saisie_manuelle": False,
        "override_balance": False,
        "override_reason": None,
        "override_at": None,
        "notes": None,
        "created_at": now,
        "updated_at": now,  # equal → counted as "inserted"
    }
    base[target_column] = value
    base.update(overrides)
    return base


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.crp_prefill_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def owned_cr_with_doc(monkeypatch):
    """Default : cr exists, belongs to company, links to DOC_ID."""
    monkeypatch.setattr(
        crp_prefill_service.crp_ligne_repo,
        "get_cr_context",
        lambda _: {
            "cr_variante": "soumis_equilibre",
            "document_id": DOC_ID,
            "type_document": "errd",
        },
    )
    monkeypatch.setattr(
        crp_prefill_service.crp_ligne_repo,
        "cr_belongs_to_company",
        lambda cr, company: True,
    )


@pytest.fixture
def no_overrides(monkeypatch):
    monkeypatch.setattr(
        crp_prefill_service.crp_ligne_repo,
        "list_overridden_keys",
        lambda _: set(),
    )


def _binding_row():
    return {
        "id": BINDING_ID,
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "feature_key": "crp_charges_g1",
        "kb_id": KB_ID,
        "kb_table": "kbs.compta_esms__bal__abc",
        "column_mapping": {},
        "plan_comptable_source": "M22Bis",
        "bound_by_user_id": uuid4(),
        "bound_at": datetime.now(UTC),
    }


async def _stub_preview(*, document_id, feature_key, company_id, filters):
    return BindingPreviewResponse(
        feature_key=feature_key,
        rows=[
            BindingPreviewRow(
                data={"compte": "6064", "compte_label": "Fournitures", "montant": Decimal("12450")}
            ),
            BindingPreviewRow(
                data={"compte": "60611", "compte_label": "Eau", "montant": Decimal("3050")}
            ),
        ],
        warnings=[],
        row_count=2,
        truncated=False,
    )


# ---------------------------------------------------------------------------
# happy
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_prefill_happy(monkeypatch, owned_cr_with_doc, no_overrides, patch_run_in_thread):
    monkeypatch.setattr(
        crp_prefill_service.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, key: _binding_row(),
    )
    monkeypatch.setattr(crp_prefill_service.binding_service, "preview_binding", _stub_preview)
    captured: dict = {}

    def _fake_bulk(*, company_id, cr_id, items, binding_id):
        captured["items"] = items
        captured["binding_id"] = binding_id
        return [
            _make_upserted_row("6064", "montant_realise", Decimal("12450")),
            _make_upserted_row("60611", "montant_realise", Decimal("3050")),
        ]

    monkeypatch.setattr(crp_prefill_service.crp_ligne_repo, "bulk_upsert", _fake_bulk)

    out = await crp_prefill_service.prefill_from_binding(
        cr_id=CR_ID,
        company_id=COMPANY,
        feature_keys=["crp_charges_g1"],
        target_column="montant_realise",
    )
    assert out.target_column == "montant_realise"
    assert len(out.results) == 1
    assert out.results[0].feature_key == "crp_charges_g1"
    assert out.results[0].inserted == 2
    assert out.results[0].updated == 0
    assert out.results[0].skipped_overridden == 0
    # bulk_upsert received the correct binding_id
    assert captured["binding_id"] == BINDING_ID
    # items mapped correctly
    assert captured["items"][0]["groupe"] == "G1"
    assert captured["items"][0]["nature"] == "charge"
    assert captured["items"][0]["compte_m22bis"] == "6064"
    assert captured["items"][0]["montant_realise"] == Decimal("12450")
    assert captured["items"][0]["saisie_manuelle"] is False


@pytest.mark.asyncio
async def test_prefill_skips_overridden(monkeypatch, owned_cr_with_doc, patch_run_in_thread):
    """The cabinet's manual edit on a prefilled row must survive a
    subsequent prefill (Q6)."""
    monkeypatch.setattr(
        crp_prefill_service.crp_ligne_repo,
        "list_overridden_keys",
        lambda _: {("G1", "charge", "6064")},
    )
    monkeypatch.setattr(
        crp_prefill_service.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, key: _binding_row(),
    )
    monkeypatch.setattr(crp_prefill_service.binding_service, "preview_binding", _stub_preview)
    captured: dict = {}

    def _fake_bulk(*, company_id, cr_id, items, binding_id):
        captured["items"] = items
        return [_make_upserted_row("60611", "montant_realise", Decimal("3050"))]

    monkeypatch.setattr(crp_prefill_service.crp_ligne_repo, "bulk_upsert", _fake_bulk)

    out = await crp_prefill_service.prefill_from_binding(
        cr_id=CR_ID,
        company_id=COMPANY,
        feature_keys=["crp_charges_g1"],
        target_column="montant_realise",
    )
    # 6064 was filtered out at item-build time, 60611 made it through
    assert captured["items"][0]["compte_m22bis"] == "60611"
    assert len(captured["items"]) == 1
    assert out.results[0].skipped_overridden == 1


@pytest.mark.asyncio
async def test_prefill_unknown_feature_key_404(
    monkeypatch, owned_cr_with_doc, no_overrides, patch_run_in_thread
):
    with pytest.raises(NotFoundError) as exc:
        await crp_prefill_service.prefill_from_binding(
            cr_id=CR_ID,
            company_id=COMPANY,
            feature_keys=["tper_effectifs"],
            target_column="montant_realise",
        )
    assert exc.value.code == "feature_not_prefillable"


@pytest.mark.asyncio
async def test_prefill_missing_binding_404(
    monkeypatch, owned_cr_with_doc, no_overrides, patch_run_in_thread
):
    monkeypatch.setattr(
        crp_prefill_service.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, key: None,
    )
    with pytest.raises(NotFoundError) as exc:
        await crp_prefill_service.prefill_from_binding(
            cr_id=CR_ID,
            company_id=COMPANY,
            feature_keys=["crp_charges_g1"],
            target_column="montant_realise",
        )
    assert exc.value.code == "binding_not_found"


@pytest.mark.asyncio
async def test_prefill_cross_tenant_cr_404(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        crp_prefill_service.crp_ligne_repo,
        "get_cr_context",
        lambda _: None,
    )
    with pytest.raises(NotFoundError) as exc:
        await crp_prefill_service.prefill_from_binding(
            cr_id=CR_ID,
            company_id=COMPANY,
            feature_keys=["crp_charges_g1"],
            target_column="montant_realise",
        )
    assert exc.value.code == "cr_not_found"


@pytest.mark.asyncio
async def test_prefill_target_column_is_explicit(
    monkeypatch, owned_cr_with_doc, no_overrides, patch_run_in_thread
):
    """Q3 — the target_column from the request is the one written. No
    auto-deduction based on doc.type_document (cr_context says ERRD but
    we pass montant_budget_initial)."""
    monkeypatch.setattr(
        crp_prefill_service.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, key: _binding_row(),
    )
    monkeypatch.setattr(crp_prefill_service.binding_service, "preview_binding", _stub_preview)
    captured: dict = {}

    def _fake_bulk(*, company_id, cr_id, items, binding_id):
        captured["items"] = items
        return []

    monkeypatch.setattr(crp_prefill_service.crp_ligne_repo, "bulk_upsert", _fake_bulk)

    await crp_prefill_service.prefill_from_binding(
        cr_id=CR_ID,
        company_id=COMPANY,
        feature_keys=["crp_charges_g1"],
        target_column="montant_budget_initial",
    )
    assert "montant_budget_initial" in captured["items"][0]
    assert "montant_realise" not in captured["items"][0]


@pytest.mark.asyncio
async def test_prefill_produits_lands_in_g1(
    monkeypatch, owned_cr_with_doc, no_overrides, patch_run_in_thread
):
    """v0.2 simplification : crp_produits → (G1, produit)."""
    monkeypatch.setattr(
        crp_prefill_service.kb_binding_repo,
        "get_by_doc_feature",
        lambda doc, key: _binding_row(),
    )
    monkeypatch.setattr(crp_prefill_service.binding_service, "preview_binding", _stub_preview)
    captured: dict = {}

    def _fake_bulk(*, company_id, cr_id, items, binding_id):
        captured["items"] = items
        return []

    monkeypatch.setattr(crp_prefill_service.crp_ligne_repo, "bulk_upsert", _fake_bulk)

    await crp_prefill_service.prefill_from_binding(
        cr_id=CR_ID,
        company_id=COMPANY,
        feature_keys=["crp_produits"],
        target_column="montant_realise",
    )
    assert captured["items"][0]["groupe"] == "G1"
    assert captured["items"][0]["nature"] == "produit"
