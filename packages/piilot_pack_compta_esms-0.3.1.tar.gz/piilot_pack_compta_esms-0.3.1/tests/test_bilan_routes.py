"""Route tests for bilan endpoints (L2 §14, 4 endpoints)."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.bilan import (
    BilanLigneRead,
    BilanResponse,
    BilanSectionTotal,
    BilanTotalsForType,
    BilanTotalsResponse,
    BilanValidationIssue,
    BilanValidationResult,
)
from piilot_pack_compta_esms.routes import bilan as bilan_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import bilan_service
from piilot_pack_compta_esms.services.errors import (
    NotFoundError,
    ValidationError,
)

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)


def _ligne_read(**overrides) -> BilanLigneRead:
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "type_bilan": "financier",
        "section": "I",
        "poste_label": "Immo brutes",
        "compte_m22bis": None,
        "montant_brut_n": None,
        "montant_amort_n": None,
        "montant_net_n": Decimal("100000"),
        "montant_net_n1": None,
        "type_actif_passif": "actif",
        "montant_soins_n": None,
        "montant_dependance_n": None,
        "montant_hebergement_n": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return BilanLigneRead.model_validate(base)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(bilan_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# §14.1 GET /bilan
# ---------------------------------------------------------------------------


def test_get_bilan_200(client, monkeypatch):
    async def _fake(doc, company, *, type_bilan=None):
        return BilanResponse(plan_comptable_og="PC", items=[_ligne_read()])

    monkeypatch.setattr(bilan_service, "list_bilan", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/bilan")
    assert r.status_code == 200
    body = r.json()
    assert body["plan_comptable_og"] == "PC"
    assert len(body["items"]) == 1


def test_get_bilan_with_type_filter(client, monkeypatch):
    captured: dict = {}

    async def _fake(doc, company, *, type_bilan=None):
        captured["type_bilan"] = type_bilan
        return BilanResponse(plan_comptable_og="PNL", items=[])

    monkeypatch.setattr(bilan_service, "list_bilan", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/bilan?type_bilan=comptable_pnl")
    assert r.status_code == 200
    assert captured["type_bilan"] == "comptable_pnl"


def test_get_bilan_invalid_type_422(client):
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/bilan?type_bilan=invalid")
    assert r.status_code == 422


def test_get_bilan_404(client, monkeypatch):
    async def _fake(doc, company, *, type_bilan=None):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(bilan_service, "list_bilan", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/bilan")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# §14.2 POST :bulk-upsert
# ---------------------------------------------------------------------------


def test_bulk_upsert_200(client, monkeypatch):
    async def _fake(doc, company, payload):
        return BilanResponse(plan_comptable_og="PC", items=[_ligne_read()])

    monkeypatch.setattr(bilan_service, "bulk_upsert_bilan", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/bilan:bulk-upsert",
        json={
            "items": [
                {
                    "type_bilan": "financier",
                    "section": "I",
                    "poste_label": "Immo brutes",
                    "montant_net_n": "100000.00",
                    "type_actif_passif": "actif",
                }
            ]
        },
    )
    assert r.status_code == 200


def test_bulk_upsert_403_user_role(client):
    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/bilan:bulk-upsert",
        json={"items": []},
    )
    assert r.status_code == 403


def test_bulk_upsert_422_incoherent_variant(client, monkeypatch):
    async def _fake(doc, company, payload):
        raise ValidationError("nope", code="incoherent_comptable_variant")

    monkeypatch.setattr(bilan_service, "bulk_upsert_bilan", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/bilan:bulk-upsert",
        json={
            "items": [
                {
                    "type_bilan": "comptable_pnl",
                    "section": "Fonds propres",
                    "poste_label": "FP sans droit",
                    "montant_net_n": "50000",
                    "type_actif_passif": "passif",
                }
            ]
        },
    )
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "incoherent_comptable_variant"


# ---------------------------------------------------------------------------
# §14.3 GET :totals
# ---------------------------------------------------------------------------


def test_get_totals_200_all_types(client, monkeypatch):
    async def _fake(doc, company, *, type_bilan=None):
        return BilanTotalsResponse(
            financier=BilanTotalsForType(
                type_bilan="financier",
                by_section=[
                    BilanSectionTotal(
                        section="I",
                        total_actif=Decimal("100000"),
                        total_passif=Decimal("100000"),
                        ecart=Decimal("0"),
                    )
                ],
                total_biens=Decimal("100000"),
                total_financements=Decimal("100000"),
                ecart=Decimal("0"),
            )
        )

    monkeypatch.setattr(bilan_service, "compute_totals", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/bilan:totals")
    assert r.status_code == 200
    body = r.json()
    assert body["financier"]["total_biens"] == "100000"
    assert body["comptable_pc"] is None
    assert body["comptable_pnl"] is None


def test_get_totals_with_type_filter(client, monkeypatch):
    captured: dict = {}

    async def _fake(doc, company, *, type_bilan=None):
        captured["type_bilan"] = type_bilan
        return BilanTotalsResponse()

    monkeypatch.setattr(bilan_service, "compute_totals", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/bilan:totals?type_bilan=financier")
    assert r.status_code == 200
    assert captured["type_bilan"] == "financier"


# ---------------------------------------------------------------------------
# §14.4 POST :validate
# ---------------------------------------------------------------------------


def test_validate_200_valide(client, monkeypatch):
    async def _fake(doc, company, *, type_bilan=None):
        return BilanValidationResult(valide=True, issues=[], tolerance_appliquee=Decimal("0.01"))

    monkeypatch.setattr(bilan_service, "validate_equilibre", _fake)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/bilan:validate")
    assert r.status_code == 200
    assert r.json()["valide"] is True


def test_validate_200_with_ecart(client, monkeypatch):
    async def _fake(doc, company, *, type_bilan=None):
        return BilanValidationResult(
            valide=False,
            issues=[
                BilanValidationIssue(
                    code="ecart_above_tolerance",
                    type_bilan="financier",
                    message="Écart 5000€",
                    ecart=Decimal("5000"),
                )
            ],
            tolerance_appliquee=Decimal("0.01"),
        )

    monkeypatch.setattr(bilan_service, "validate_equilibre", _fake)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/bilan:validate")
    assert r.status_code == 200
    body = r.json()
    assert body["valide"] is False
    assert body["issues"][0]["code"] == "ecart_above_tolerance"
