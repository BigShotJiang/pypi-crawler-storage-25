"""Unit tests for :mod:`piilot_pack_compta_esms.services.balance_apply_service`."""

from __future__ import annotations

import io
from datetime import UTC, datetime
from uuid import uuid4

import pytest
from openpyxl import Workbook

from piilot_pack_compta_esms.models.balance_apply import (
    ApplyRequest,
    MaterializeRequest,
)
from piilot_pack_compta_esms.services import balance_apply_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)

COMPANY = uuid4()
OTHER = uuid4()
IMPORT_ID = uuid4()


def _build_xlsx() -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.append(["Compte", "Libellé", "Débit", "Crédit", "Solde"])
    ws.append(["60611", "Eau", 12.5, 0, 12.5])
    ws.append(["60611", "Eau (mois 2)", 8.0, 0, 8.0])  # same source twice
    ws.append(["UNKNOWN", "Compte inconnu", 5.0, 0, 5.0])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _make_import(**overrides):
    base = {
        "id": IMPORT_ID,
        "company_id": COMPANY,
        "exercice_id": None,
        "etablissement_id": None,
        "source_plan": "PCG",
        "source_filename": "balance.xlsx",
        "source_storage_key": "plugins/compta_esms/balance_imports/x/balance.xlsx",
        "periode_label": "2025-12",
        "nb_lignes_source": 3,
        "nb_lignes_mappees": 0,
        "nb_lignes_non_mappees": 0,
        "column_detection": {
            "compte": 0,
            "libelle": 1,
            "debit": 2,
            "credit": 3,
            "solde": 4,
            "periode": None,
        },
        "preview_data": {"header": [], "rows": []},
        "suggestions": [],
        "unmapped_accounts": [],
        "applied_at": None,
        "mapping_snapshot": {},
        "materialized_kb_id": None,
        "materialized_kb_table_name": None,
        "status": "pending",
        "error_payload": {},
        "imported_by_user_id": uuid4(),
        "imported_at": datetime.now(UTC),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.balance_apply_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def fake_storage(monkeypatch):
    async def _get(key):
        return _build_xlsx()

    # Late-bound — patch the symbol the service resolves at runtime.
    import piilot.sdk.storage as storage_module

    monkeypatch.setattr(storage_module, "get_object", _get)


# ---------------------------------------------------------------------------
# apply_mapping
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_apply_404_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(balance_apply_service.balance_import_repo, "get_by_id", lambda _: None)
    with pytest.raises(NotFoundError):
        await balance_apply_service.apply_mapping(COMPANY, IMPORT_ID, ApplyRequest())


@pytest.mark.asyncio
async def test_apply_cross_tenant_404(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_import(company_id=OTHER),
    )
    with pytest.raises(NotFoundError):
        await balance_apply_service.apply_mapping(COMPANY, IMPORT_ID, ApplyRequest())


@pytest.mark.asyncio
async def test_apply_compte_unset_409(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_import(
            column_detection={
                "compte": None,
                "libelle": None,
                "debit": None,
                "credit": None,
                "solde": None,
                "periode": None,
            }
        ),
    )
    with pytest.raises(ConflictError) as exc:
        await balance_apply_service.apply_mapping(COMPANY, IMPORT_ID, ApplyRequest())
    assert exc.value.code == "apply_compte_unset"


@pytest.mark.asyncio
async def test_apply_happy_path(monkeypatch, patch_run_in_thread, fake_storage):
    """Mapping 60611 → 60611 ; UNKNOWN unmapped. Counts mapped=2 / unmapped=1."""
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_import(),
    )
    monkeypatch.setattr(
        balance_apply_service.balance_mapping_repo,
        "list_filtered",
        lambda company_id, **kw: [
            {
                "id": uuid4(),
                "company_id": COMPANY,
                "source_plan": "PCG",
                "source_account": "60611",
                "target_m22bis_account": "60611",
                "weight": 1.0,
                "label_hint": "Eau",
                "confidence": 1.0,
                "suggestion_origin": "pcg_to_m22bis_kb",
                "version_m22bis": "2025-2026",
                "valid_from": None,
                "valid_to": None,
                "created_at": datetime.now(UTC),
                "updated_at": datetime.now(UTC),
            }
        ],
    )
    captured: dict = {}

    def _update(import_id, **kw):
        captured.update(kw)
        return _make_import(
            applied_at=datetime.now(UTC),
            status=kw["status"],
            mapping_snapshot=kw["mapping_snapshot"],
            unmapped_accounts=kw["unmapped_accounts"],
            nb_lignes_mappees=kw["nb_lignes_mappees"],
            nb_lignes_non_mappees=kw["nb_lignes_non_mappees"],
        )

    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "update_apply_result",
        _update,
    )

    result = await balance_apply_service.apply_mapping(COMPANY, IMPORT_ID, ApplyRequest())
    assert result.nb_lignes_mappees == 2
    assert result.nb_lignes_non_mappees == 1
    assert result.nb_unmapped_accounts == 1
    assert result.status == "partial"
    assert captured["status"] == "partial"

    # The single unmapped source account aggregates its 1 row + 5.0 montant.
    unmapped = captured["unmapped_accounts"]
    assert len(unmapped) == 1
    assert unmapped[0]["source_account"] == "UNKNOWN"
    assert unmapped[0]["montant"] == 5.0
    assert unmapped[0]["nb_lignes"] == 1


@pytest.mark.asyncio
async def test_apply_dry_run_skips_persistence(monkeypatch, patch_run_in_thread, fake_storage):
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_import(),
    )
    monkeypatch.setattr(
        balance_apply_service.balance_mapping_repo,
        "list_filtered",
        lambda company_id, **kw: [],
    )

    def _should_not_be_called(*a, **kw):
        raise AssertionError("update_apply_result must not run in dry_run")

    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "update_apply_result",
        _should_not_be_called,
    )

    result = await balance_apply_service.apply_mapping(
        COMPANY, IMPORT_ID, ApplyRequest(dry_run=True)
    )
    # Zero mapping rules ⇒ everything unmapped
    assert result.nb_lignes_mappees == 0
    assert result.nb_lignes_non_mappees == 3
    assert result.dry_run is True
    assert result.applied_at is None


@pytest.mark.asyncio
async def test_apply_all_mapped_completes(monkeypatch, patch_run_in_thread, fake_storage):
    """When every source has a mapping, status flips to 'completed'."""
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_import(),
    )
    monkeypatch.setattr(
        balance_apply_service.balance_mapping_repo,
        "list_filtered",
        lambda company_id, **kw: [
            {
                "id": uuid4(),
                "company_id": COMPANY,
                "source_plan": "PCG",
                "source_account": acct,
                "target_m22bis_account": acct,
                "weight": 1.0,
                "label_hint": None,
                "confidence": 1.0,
                "suggestion_origin": "pcg_to_m22bis_kb",
                "version_m22bis": "2025-2026",
                "valid_from": None,
                "valid_to": None,
                "created_at": datetime.now(UTC),
                "updated_at": datetime.now(UTC),
            }
            for acct in ("60611", "UNKNOWN")
        ],
    )
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "update_apply_result",
        lambda import_id, **kw: _make_import(applied_at=datetime.now(UTC), status=kw["status"]),
    )

    result = await balance_apply_service.apply_mapping(COMPANY, IMPORT_ID, ApplyRequest())
    assert result.status == "completed"
    assert result.nb_lignes_non_mappees == 0


# ---------------------------------------------------------------------------
# list_unmapped
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_unmapped_happy(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_import(
            unmapped_accounts=[
                {
                    "source_account": "UNK",
                    "label_hint": "x",
                    "montant": 5.0,
                    "nb_lignes": 1,
                }
            ]
        ),
    )
    out = await balance_apply_service.list_unmapped(COMPANY, IMPORT_ID)
    assert len(out) == 1
    assert out[0].source_account == "UNK"


# ---------------------------------------------------------------------------
# delete_import
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_delete_import_no_kb(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_import(),
    )
    monkeypatch.setattr(balance_apply_service.balance_import_repo, "delete", lambda _: True)
    # Should not touch the KB
    monkeypatch.setattr(
        balance_apply_service.kb_sdk,
        "delete_rows_by",
        lambda *a, **kw: (_ for _ in ()).throw(
            AssertionError("delete_rows_by must not run when no KB")
        ),
    )
    await balance_apply_service.delete_import(COMPANY, IMPORT_ID)


@pytest.mark.asyncio
async def test_delete_import_with_kb(monkeypatch, patch_run_in_thread):
    kb_id = uuid4()
    captured: dict = {}

    def _delete_rows_by(kb_id_arg, filters):
        captured["kb_id"] = kb_id_arg
        captured["filters"] = filters
        return 42

    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_import(materialized_kb_id=kb_id, periode_label="2025-12"),
    )
    monkeypatch.setattr(balance_apply_service.balance_import_repo, "delete", lambda _: True)
    monkeypatch.setattr(balance_apply_service.kb_sdk, "delete_rows_by", _delete_rows_by)
    await balance_apply_service.delete_import(COMPANY, IMPORT_ID, delete_kb=True)
    assert captured["kb_id"] == str(kb_id)
    assert captured["filters"] == {"periode": "2025-12"}


# ---------------------------------------------------------------------------
# materialize_kb
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_materialize_kb_requires_snapshot(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_import(mapping_snapshot={}),
    )
    with pytest.raises(ConflictError) as exc:
        await balance_apply_service.materialize_kb(COMPANY, IMPORT_ID, MaterializeRequest())
    assert exc.value.code == "materialize_no_snapshot"


@pytest.mark.asyncio
async def test_materialize_kb_409_already_done(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_import(
            materialized_kb_id=uuid4(),
            mapping_snapshot={"rules": [{"source_account": "x", "targets": []}]},
        ),
    )
    with pytest.raises(ConflictError) as exc:
        await balance_apply_service.materialize_kb(
            COMPANY,
            IMPORT_ID,
            MaterializeRequest(overwrite_existing=False),
        )
    assert exc.value.code == "materialize_already_done"


@pytest.mark.asyncio
async def test_materialize_kb_creates_and_inserts(monkeypatch, patch_run_in_thread, fake_storage):
    snapshot = {
        "version_m22bis": "2025-2026",
        "source_plan": "PCG",
        "rules": [
            {
                "source_account": "60611",
                "targets": [
                    {
                        "target_m22bis_account": "60611",
                        "weight": 1.0,
                        "label_hint": "Eau",
                    }
                ],
            }
        ],
    }
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_import(mapping_snapshot=snapshot),
    )

    captured: dict = {"columns": []}

    def _create_kb(*, company_id, name, description, schema_locked):
        captured["company_id"] = company_id
        captured["kb_name"] = name
        return {"id": str(uuid4()), "table_name": "kbs.compta_esms__x"}

    def _add_column(kb_id, **kw):
        captured["columns"].append(kw["name"])
        return {"id": str(uuid4()), **kw}

    def _insert_batch(kb_id, rows):
        captured["rows_inserted"] = len(rows)
        captured["first_row"] = rows[0]["data"] if rows else None
        return len(rows)

    monkeypatch.setattr(balance_apply_service.kb_sdk, "create_kb", _create_kb)
    monkeypatch.setattr(balance_apply_service.kb_sdk, "add_column", _add_column)
    monkeypatch.setattr(balance_apply_service.kb_sdk, "insert_batch", _insert_batch)
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "update_materialized_kb",
        lambda import_id, **kw: _make_import(),
    )

    result = await balance_apply_service.materialize_kb(COMPANY, IMPORT_ID, MaterializeRequest())
    # 7 columns declared in _KB_COLUMNS
    assert captured["columns"] == [
        "source_account",
        "source_plan",
        "target_m22bis_account",
        "label",
        "montant",
        "weight",
        "periode",
    ]
    # Test fixture has 2 rows for source 60611 ⇒ 2 inserted rows
    assert captured["rows_inserted"] == 2
    assert result.rows_inserted == 2
    assert "Balance M22bis" in result.kb_name
    assert result.overwritten is False


# ---------------------------------------------------------------------------
# list_history + replay
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_history_caps_limit(monkeypatch, patch_run_in_thread):
    captured: dict = {}

    def _list(company_id, **kw):
        captured.update(kw)
        return []

    monkeypatch.setattr(balance_apply_service.balance_import_repo, "list_history", _list)
    await balance_apply_service.list_history(COMPANY, limit=9999)
    assert captured["limit"] == 200


@pytest.mark.asyncio
async def test_replay_invokes_apply(monkeypatch, patch_run_in_thread, fake_storage):
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_import(mapping_snapshot={"version_m22bis": "2024-2025"}),
    )
    monkeypatch.setattr(
        balance_apply_service.balance_mapping_repo,
        "list_filtered",
        lambda company_id, **kw: [],
    )
    monkeypatch.setattr(
        balance_apply_service.balance_import_repo,
        "update_apply_result",
        lambda import_id, **kw: _make_import(applied_at=datetime.now(UTC), status=kw["status"]),
    )
    out = await balance_apply_service.replay_import(COMPANY, IMPORT_ID)
    # Replay propagates the snapshot's version_m22bis through
    assert out.import_id == IMPORT_ID
