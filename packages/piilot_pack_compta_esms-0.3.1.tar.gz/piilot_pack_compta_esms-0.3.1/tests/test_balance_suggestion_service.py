"""Unit tests for :mod:`piilot_pack_compta_esms.services.balance_suggestion_service`."""

from __future__ import annotations

import io
from datetime import UTC, datetime
from uuid import uuid4

import pytest
from openpyxl import Workbook

from piilot_pack_compta_esms.models.suggestion import (
    AcceptAboveRequest,
    SuggestRequest,
)
from piilot_pack_compta_esms.services import balance_suggestion_service
from piilot_pack_compta_esms.services.errors import (
    ConflictError,
    NotFoundError,
)

COMPANY = uuid4()
OTHER_COMPANY = uuid4()
IMPORT_ID = uuid4()


def _build_xlsx_body() -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.append(["Compte", "Libellé", "Débit", "Crédit", "Solde"])
    ws.append(["60611", "Eau", 12.5, 0, 12.5])
    ws.append(["60612", "Électricité", 8.5, 0, 8.5])
    ws.append(["UNKNOWN999", "Compte inconnu", 1.0, 0, 1.0])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _make_row(**overrides):
    base = {
        "id": IMPORT_ID,
        "company_id": COMPANY,
        "exercice_id": None,
        "etablissement_id": None,
        "source_plan": "PCG",
        "source_filename": "balance.xlsx",
        "source_storage_key": "plugins/compta_esms/balance_imports/x/balance.xlsx",
        "periode_label": "2025-12",
        "nb_lignes_source": 3,
        "nb_lignes_mappees": 0,
        "nb_lignes_non_mappees": 0,
        "column_detection": {
            "compte": 0,
            "libelle": 1,
            "debit": 2,
            "credit": 3,
            "solde": 4,
            "periode": None,
        },
        "preview_data": {"header": [], "rows": []},
        "suggestions": [],
        "mapping_snapshot": {},
        "materialized_kb_id": None,
        "materialized_kb_table_name": None,
        "status": "pending",
        "error_payload": {},
        "imported_by_user_id": uuid4(),
        "imported_at": datetime.now(UTC),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.balance_suggestion_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def fake_storage(monkeypatch):
    async def _get(key):
        return _build_xlsx_body()

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.balance_suggestion_service.storage.get_object",
        _get,
    )


# ---------------------------------------------------------------------------
# suggest_mappings
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_suggest_404_not_found(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_suggestion_service.balance_import_repo,
        "get_by_id",
        lambda _: None,
    )
    with pytest.raises(NotFoundError):
        await balance_suggestion_service.suggest_mappings(COMPANY, IMPORT_ID, SuggestRequest())


@pytest.mark.asyncio
async def test_suggest_cross_tenant_404(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_suggestion_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_row(company_id=OTHER_COMPANY),
    )
    with pytest.raises(NotFoundError):
        await balance_suggestion_service.suggest_mappings(COMPANY, IMPORT_ID, SuggestRequest())


@pytest.mark.asyncio
async def test_suggest_rejects_when_compte_unset(monkeypatch, patch_run_in_thread, fake_storage):
    """``compte`` index is the lookup key — if it's None, the whole
    pipeline can't run."""
    monkeypatch.setattr(
        balance_suggestion_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_row(
            column_detection={
                "compte": None,
                "libelle": None,
                "debit": None,
                "credit": None,
                "solde": None,
                "periode": None,
            }
        ),
    )
    with pytest.raises(ConflictError) as exc:
        await balance_suggestion_service.suggest_mappings(COMPANY, IMPORT_ID, SuggestRequest())
    assert exc.value.code == "suggestions_compte_unset"


@pytest.mark.asyncio
async def test_suggest_happy_path(monkeypatch, patch_run_in_thread, fake_storage):
    """Real KB lookup runs : 60611 + 60612 match identity (confidence=1.0,
    origin=pcg_to_m22bis_kb) ; UNKNOWN999 returns no targets."""
    monkeypatch.setattr(
        balance_suggestion_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_row(),
    )
    captured: dict = {}

    def _update(import_id, suggestions):
        captured["suggestions"] = suggestions
        return _make_row(suggestions=suggestions)

    monkeypatch.setattr(
        balance_suggestion_service.balance_import_repo,
        "update_suggestions",
        _update,
    )

    out = await balance_suggestion_service.suggest_mappings(COMPANY, IMPORT_ID, SuggestRequest())
    # 3 source accounts in our fixture file
    assert len(out.suggestions) == 3
    accounts = {s["source_account"] for s in out.suggestions}
    assert accounts == {"60611", "60612", "UNKNOWN999"}

    # 60611 must have a matching target via identity
    by_account = {s["source_account"]: s for s in out.suggestions}
    assert by_account["60611"]["targets"][0]["origin"] == "pcg_to_m22bis_kb"
    assert by_account["60611"]["targets"][0]["target_m22bis_account"] == "60611"

    # UNKNOWN999 has no targets — LLM tier is stubbed
    assert by_account["UNKNOWN999"]["targets"] == []


@pytest.mark.asyncio
async def test_suggest_llm_stub_is_inert(monkeypatch, patch_run_in_thread, fake_storage):
    """include_llm=True still returns no LLM rows in v0.2 (stub)."""
    monkeypatch.setattr(
        balance_suggestion_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_row(),
    )
    monkeypatch.setattr(
        balance_suggestion_service.balance_import_repo,
        "update_suggestions",
        lambda import_id, suggestions: _make_row(suggestions=suggestions),
    )

    out = await balance_suggestion_service.suggest_mappings(
        COMPANY,
        IMPORT_ID,
        SuggestRequest(include_llm=True, llm_threshold=0.5),
    )
    # No target has origin='llm' (Tier 3 stub returns nothing)
    for entry in out.suggestions:
        for target in entry["targets"]:
            assert target["origin"] != "llm"


# ---------------------------------------------------------------------------
# list_suggestions
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_filters_by_confidence_and_origin(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_suggestion_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_row(
            suggestions=[
                {
                    "source_account": "60611",
                    "label_hint": "Eau",
                    "targets": [
                        {
                            "target_m22bis_account": "60611",
                            "weight": 1.0,
                            "confidence": 1.0,
                            "origin": "pcg_to_m22bis_kb",
                        }
                    ],
                },
                {
                    "source_account": "AMBIG",
                    "label_hint": "x",
                    "targets": [
                        {
                            "target_m22bis_account": "7351",
                            "weight": 1.0,
                            "confidence": 0.6,
                            "origin": "llm",
                        }
                    ],
                },
            ]
        ),
    )
    out = await balance_suggestion_service.list_suggestions(COMPANY, IMPORT_ID, confidence_min=0.9)
    assert len(out) == 1
    assert out[0].source_account == "60611"

    # Restrict to LLM origin only — only AMBIG matches, but it's
    # already below the threshold so the empty list is the right
    # answer when both filters apply.
    out = await balance_suggestion_service.list_suggestions(
        COMPANY, IMPORT_ID, confidence_min=0.5, origins=["llm"]
    )
    assert len(out) == 1
    assert out[0].source_account == "AMBIG"


# ---------------------------------------------------------------------------
# accept_all_above
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_accept_above_bulk_upserts(monkeypatch, patch_run_in_thread):
    """Suggestions ≥ threshold flow through to bulk_upsert_mappings."""
    monkeypatch.setattr(
        balance_suggestion_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_row(
            suggestions=[
                {
                    "source_account": "60611",
                    "label_hint": "Eau",
                    "targets": [
                        {
                            "target_m22bis_account": "60611",
                            "weight": 1.0,
                            "confidence": 1.0,
                            "origin": "pcg_to_m22bis_kb",
                        }
                    ],
                },
                {
                    "source_account": "AMBIG",
                    "label_hint": None,
                    "targets": [
                        {
                            "target_m22bis_account": "7351",
                            "weight": 1.0,
                            "confidence": 0.6,  # below threshold
                            "origin": "llm",
                        }
                    ],
                },
            ]
        ),
    )

    captured: dict = {}

    async def _fake_bulk(company_id, items):
        captured["items"] = items
        return []

    monkeypatch.setattr(
        balance_suggestion_service.balance_mapping_service,
        "bulk_upsert_mappings",
        _fake_bulk,
    )

    await balance_suggestion_service.accept_all_above(
        COMPANY,
        IMPORT_ID,
        AcceptAboveRequest(confidence_threshold=0.9),
    )
    # Only the 60611 suggestion clears the threshold.
    assert len(captured["items"]) == 1
    assert captured["items"][0].source_account == "60611"


@pytest.mark.asyncio
async def test_accept_above_returns_empty_when_no_match(monkeypatch, patch_run_in_thread):
    monkeypatch.setattr(
        balance_suggestion_service.balance_import_repo,
        "get_by_id",
        lambda _: _make_row(suggestions=[]),
    )

    async def _fake_bulk(company_id, items):
        raise AssertionError("bulk_upsert must not be called when no items pass")

    monkeypatch.setattr(
        balance_suggestion_service.balance_mapping_service,
        "bulk_upsert_mappings",
        _fake_bulk,
    )

    out = await balance_suggestion_service.accept_all_above(
        COMPANY, IMPORT_ID, AcceptAboveRequest(confidence_threshold=0.5)
    )
    assert out == []
