"""Unit tests for :mod:`piilot_pack_compta_esms.services.rcc_service`.

Couvre principalement :func:`validate_rcc` (D-092 Σ%=100 par ligne,
tolérance 0.01 Q7) — c'est la règle métier dure de §N.
"""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.rcc import (
    RccBulkUpsertRequest,
    RccLigneCreate,
    RccRepartitionEntry,
)
from piilot_pack_compta_esms.services import rcc_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
DOC_ID = uuid4()
CR_A = uuid4()
CR_B = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr("piilot_pack_compta_esms.services.rcc_service.run_in_thread", _passthrough)


@pytest.fixture
def valid_doc(monkeypatch):
    monkeypatch.setattr(
        rcc_service.rcc_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )


def _row(*, somme_pct=None, **overrides):
    """Si ``somme_pct`` est passé, construit un repartition_json sur
    2 CR qui somment à cette valeur."""
    if somme_pct is not None:
        half = Decimal(somme_pct) / 2
        rep = {
            str(CR_A): {"pct": str(half), "montant": "0"},
            str(CR_B): {"pct": str(half), "montant": "0"},
        }
    else:
        rep = {}
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "compte_m22bis": "611",
        "libelle": "Loyers",
        "montant_total": Decimal("10000"),
        "cle_repartition": "Surface",
        "repartition_json": rep,
        "is_frais_siege": False,
        "is_quote_part_commune": False,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# list_rcc
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_normalizes_repartition_key(patch_run_in_thread, valid_doc, monkeypatch):
    """Le repo retourne ``repartition_json`` (clé DB), le service
    renomme en ``repartition`` (clé Pydantic)."""
    monkeypatch.setattr(rcc_service.rcc_repo, "list_by_document", lambda d: [_row(somme_pct=100)])

    result = await rcc_service.list_rcc(DOC_ID, COMPANY)

    assert len(result.items) == 1
    assert len(result.items[0].repartition) == 2
    # Validate UUID keys parsed correctly
    keys = set(result.items[0].repartition.keys())
    assert CR_A in keys
    assert CR_B in keys


@pytest.mark.asyncio
async def test_list_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        rcc_service.rcc_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    with pytest.raises(NotFoundError):
        await rcc_service.list_rcc(DOC_ID, COMPANY)


# ---------------------------------------------------------------------------
# bulk_upsert_rcc (replace_all_by_document Q5)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_upsert_replace_all(patch_run_in_thread, valid_doc, monkeypatch):
    calls = {}

    def _replace(*, company_id, document_id, items):
        calls["items"] = items
        return []

    monkeypatch.setattr(rcc_service.rcc_repo, "replace_all_by_document", _replace)
    monkeypatch.setattr(rcc_service.rcc_repo, "list_by_document", lambda d: [])

    payload = RccBulkUpsertRequest(
        items=[
            RccLigneCreate(
                compte_m22bis="611",
                libelle="Loyers",
                montant_total=Decimal("10000"),
                cle_repartition="Surface",
                repartition={
                    CR_A: RccRepartitionEntry(pct=Decimal("60"), montant=Decimal("6000")),
                    CR_B: RccRepartitionEntry(pct=Decimal("40"), montant=Decimal("4000")),
                },
                is_frais_siege=False,
            ),
        ]
    )
    await rcc_service.bulk_upsert_rcc(DOC_ID, COMPANY, payload)

    assert len(calls["items"]) == 1
    assert calls["items"][0]["compte_m22bis"] == "611"
    assert str(CR_A) in calls["items"][0]["repartition"]


# ---------------------------------------------------------------------------
# validate_rcc (D-092, Q7 tolérance 0.01)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_validate_all_lignes_at_100_valid(patch_run_in_thread, valid_doc, monkeypatch):
    monkeypatch.setattr(
        rcc_service.rcc_repo,
        "list_by_document",
        lambda d: [_row(somme_pct=100), _row(somme_pct=100, compte_m22bis="612")],
    )

    result = await rcc_service.validate_rcc(DOC_ID, COMPANY)

    assert len(result.lignes) == 2
    assert result.valide_globalement is True
    assert all(ligne.valide for ligne in result.lignes)
    assert result.tolerance_appliquee == Decimal("0.01")


@pytest.mark.asyncio
async def test_validate_ligne_below_100_invalid(patch_run_in_thread, valid_doc, monkeypatch):
    monkeypatch.setattr(rcc_service.rcc_repo, "list_by_document", lambda d: [_row(somme_pct=95)])

    result = await rcc_service.validate_rcc(DOC_ID, COMPANY)

    assert result.valide_globalement is False
    assert result.lignes[0].valide is False
    assert result.lignes[0].somme_pct == Decimal("95")
    assert result.lignes[0].ecart == Decimal("-5")


@pytest.mark.asyncio
async def test_validate_ligne_above_100_invalid(patch_run_in_thread, valid_doc, monkeypatch):
    monkeypatch.setattr(rcc_service.rcc_repo, "list_by_document", lambda d: [_row(somme_pct=110)])

    result = await rcc_service.validate_rcc(DOC_ID, COMPANY)

    assert result.valide_globalement is False
    assert result.lignes[0].somme_pct == Decimal("110")
    assert result.lignes[0].ecart == Decimal("10")


@pytest.mark.asyncio
async def test_validate_within_tolerance(patch_run_in_thread, valid_doc, monkeypatch):
    """Tolérance 0.01 — 100.005 doit passer (|ecart| = 0.005 < 0.01)."""
    row = _row()
    row["repartition_json"] = {
        str(CR_A): {"pct": "33.335", "montant": "0"},
        str(CR_B): {"pct": "66.670", "montant": "0"},
    }
    monkeypatch.setattr(rcc_service.rcc_repo, "list_by_document", lambda d: [row])

    result = await rcc_service.validate_rcc(DOC_ID, COMPANY)

    assert result.lignes[0].somme_pct == Decimal("100.005")
    assert result.lignes[0].valide is True


@pytest.mark.asyncio
async def test_validate_outside_tolerance(patch_run_in_thread, valid_doc, monkeypatch):
    """Tolérance 0.01 — 100.02 doit échouer (|ecart| = 0.02 > 0.01)."""
    row = _row()
    row["repartition_json"] = {
        str(CR_A): {"pct": "50.01", "montant": "0"},
        str(CR_B): {"pct": "50.01", "montant": "0"},
    }
    monkeypatch.setattr(rcc_service.rcc_repo, "list_by_document", lambda d: [row])

    result = await rcc_service.validate_rcc(DOC_ID, COMPANY)

    assert result.lignes[0].somme_pct == Decimal("100.02")
    assert result.lignes[0].valide is False


@pytest.mark.asyncio
async def test_validate_empty_repartition_is_invalid(patch_run_in_thread, valid_doc, monkeypatch):
    """Ligne sans repartition (dict vide) → somme_pct=0, ecart=-100,
    invalide."""
    monkeypatch.setattr(rcc_service.rcc_repo, "list_by_document", lambda d: [_row()])

    result = await rcc_service.validate_rcc(DOC_ID, COMPANY)

    assert result.lignes[0].somme_pct == Decimal("0")
    assert result.lignes[0].ecart == Decimal("-100")
    assert result.lignes[0].valide is False


@pytest.mark.asyncio
async def test_validate_empty_document_globally_valid(patch_run_in_thread, valid_doc, monkeypatch):
    """Document sans aucune ligne RCC → ``all([])`` est True."""
    monkeypatch.setattr(rcc_service.rcc_repo, "list_by_document", lambda d: [])

    result = await rcc_service.validate_rcc(DOC_ID, COMPANY)

    assert result.lignes == []
    assert result.valide_globalement is True


@pytest.mark.asyncio
async def test_validate_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        rcc_service.rcc_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    with pytest.raises(NotFoundError):
        await rcc_service.validate_rcc(DOC_ID, COMPANY)
