"""Route tests for balance_imports endpoints (L2 §7bis.1, 4 endpoints)."""

from __future__ import annotations

import io
from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import balance_import as bi_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import balance_import_service
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

COMPANY = uuid4()
USER = uuid4()
IMPORT_ID = uuid4()
BUILDER_AUTH = (USER, "builder", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


def _make_dict(**overrides):
    base = {
        "id": IMPORT_ID,
        "company_id": COMPANY,
        "exercice_id": None,
        "etablissement_id": None,
        "source_plan": "PCG",
        "source_filename": "balance.xlsx",
        "source_storage_key": "plugins/compta_esms/balance_imports/x/balance.xlsx",
        "periode_label": "2025-12",
        "nb_lignes_source": 2,
        "nb_lignes_mappees": 0,
        "nb_lignes_non_mappees": 0,
        "column_detection": {
            "compte": 0,
            "libelle": 1,
            "debit": 2,
            "credit": 3,
            "solde": 4,
            "periode": None,
        },
        "preview_data": {
            "header": ["Compte", "Libellé", "Débit", "Crédit", "Solde"],
            "rows": [["60611", "Eau", 12.5, 0, 12.5]],
        },
        "mapping_snapshot": {},
        "materialized_kb_id": None,
        "materialized_kb_table_name": None,
        "status": "pending",
        "error_payload": {},
        "imported_by_user_id": USER,
        "imported_at": datetime.now(UTC),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(bi_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# Upload (§7bis.1.1)
# ---------------------------------------------------------------------------


def test_upload_201(client, monkeypatch):
    captured: dict = {}

    async def _fake(**kw):
        captured.update(kw)
        from piilot_pack_compta_esms.models.balance_import import BalanceImportRead

        return BalanceImportRead.model_validate(_make_dict())

    monkeypatch.setattr(balance_import_service, "upload_balance", _fake)
    files = {"file": ("balance.xlsx", io.BytesIO(b"PK..."), "application/vnd.openxml")}
    data = {"source_plan": "PCG", "periode_label": "2025-12"}
    r = client.post("/plugins/compta_esms/balance-imports/upload", files=files, data=data)
    assert r.status_code == 201, r.text
    assert captured["source_plan"] == "PCG"
    assert captured["periode_label"] == "2025-12"


def test_upload_400_unsupported_extension(client, monkeypatch):
    """Service raises ConflictError → translated to 409, BUT the route
    also catches ValueError for parser errors → 400. Confirms the
    error dispatch keeps both paths distinct."""

    async def _fake(**kw):
        raise ConflictError("nope", code="balance_import_unsupported_format")

    monkeypatch.setattr(balance_import_service, "upload_balance", _fake)
    files = {"file": ("balance.pdf", io.BytesIO(b"x"), "application/pdf")}
    data = {"source_plan": "PCG", "periode_label": "2025-12"}
    r = client.post("/plugins/compta_esms/balance-imports/upload", files=files, data=data)
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "balance_import_unsupported_format"


def test_upload_400_parser_value_error(client, monkeypatch):
    async def _fake(**kw):
        raise ValueError("Unsupported file type")

    monkeypatch.setattr(balance_import_service, "upload_balance", _fake)
    files = {"file": ("balance.txt", io.BytesIO(b"x"), "text/plain")}
    data = {"source_plan": "PCG", "periode_label": "2025-12"}
    r = client.post("/plugins/compta_esms/balance-imports/upload", files=files, data=data)
    assert r.status_code == 400
    assert r.json()["detail"]["code"] == "balance_import_parse_error"


def test_upload_422_missing_source_plan(client):
    """``source_plan`` is required as a Form field."""
    files = {"file": ("balance.xlsx", io.BytesIO(b"x"), "application/vnd.openxml")}
    data = {"periode_label": "2025-12"}  # missing source_plan
    r = client.post("/plugins/compta_esms/balance-imports/upload", files=files, data=data)
    assert r.status_code == 422


# ---------------------------------------------------------------------------
# detect-columns (§7bis.1.2)
# ---------------------------------------------------------------------------


def test_detect_columns_with_hints(client, monkeypatch):
    captured: dict = {}

    async def _fake(import_id, hints):
        captured["import_id"] = import_id
        captured["hints"] = hints.model_dump(exclude_unset=True) if hints else {}
        from piilot_pack_compta_esms.models.balance_import import BalanceImportRead

        d = _make_dict()
        d["column_detection"]["periode"] = 5
        return BalanceImportRead.model_validate(d)

    monkeypatch.setattr(balance_import_service, "detect_columns", _fake)
    r = client.post(
        f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/detect-columns",
        json={"periode": 5},
    )
    assert r.status_code == 200
    assert r.json()["column_detection"]["periode"] == 5
    assert captured["hints"] == {"periode": 5}


def test_detect_columns_empty_body(client, monkeypatch):
    """No body → no hints, returns current detection."""

    async def _fake(import_id, hints):
        from piilot_pack_compta_esms.models.balance_import import BalanceImportRead

        return BalanceImportRead.model_validate(_make_dict())

    monkeypatch.setattr(balance_import_service, "detect_columns", _fake)
    r = client.post(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/detect-columns")
    assert r.status_code == 200


def test_detect_columns_422_invalid_role(client):
    """``extra='forbid'`` on ColumnHints rejects unknown role keys."""
    r = client.post(
        f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/detect-columns",
        json={"unknown_role": 5},
    )
    assert r.status_code == 422


def test_detect_columns_422_negative_index(client):
    """``ge=0`` Pydantic rejects negative column indices."""
    r = client.post(
        f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/detect-columns",
        json={"compte": -1},
    )
    assert r.status_code == 422


# ---------------------------------------------------------------------------
# get + preview (§7bis.1.3 + .4)
# ---------------------------------------------------------------------------


def test_get_balance_import_200(client, monkeypatch):
    async def _fake(import_id):
        from piilot_pack_compta_esms.models.balance_import import BalanceImportRead

        return BalanceImportRead.model_validate(_make_dict())

    monkeypatch.setattr(balance_import_service, "get_import", _fake)
    r = client.get(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}")
    assert r.status_code == 200
    assert r.json()["status"] == "pending"


def test_get_balance_import_404(client, monkeypatch):
    async def _fake(import_id):
        raise NotFoundError("nope", code="balance_import_not_found")

    monkeypatch.setattr(balance_import_service, "get_import", _fake)
    r = client.get(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}")
    assert r.status_code == 404


def test_get_preview_200(client, monkeypatch):
    async def _fake(import_id):
        from piilot_pack_compta_esms.models.balance_import import BalanceImportPreview

        return BalanceImportPreview(
            header=["Compte", "Libellé"],
            rows=[["60611", "Eau"]],
            column_detection={
                "compte": 0,
                "libelle": 1,
                "debit": None,
                "credit": None,
                "solde": None,
                "periode": None,
            },
        )

    monkeypatch.setattr(balance_import_service, "get_preview", _fake)
    r = client.get(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/preview")
    assert r.status_code == 200
    body = r.json()
    assert body["header"] == ["Compte", "Libellé"]
    assert body["rows"] == [["60611", "Eau"]]


def test_user_cannot_upload(client):
    """Builder is required for upload."""
    from fastapi import HTTPException

    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    files = {"file": ("balance.xlsx", io.BytesIO(b"x"), "application/vnd.openxml")}
    data = {"source_plan": "PCG", "periode_label": "2025-12"}
    r = client.post("/plugins/compta_esms/balance-imports/upload", files=files, data=data)
    assert r.status_code == 403
