"""Tests §Y ventilation_service — orchestration apply_default + validate.

Couvre :

* apply_default_ventilation : simple → None, règle dure 65→H 100%,
  règle dure 66→S 100%, clé gestionnaire → distribution taux,
  aucun → None
* batch_apply_default_ventilation : 1 round-trip lookup
* validate_explicit_ventilation : Σ OK, Σ KO 422, SEA conditional,
  forbidden simple
* extract_basis_amount : ERRD vs EPRD vs fallback budget_initial
"""

from __future__ import annotations

from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.services import ventilation_service
from piilot_pack_compta_esms.services.errors import ValidationError

ETS = uuid4()
ANNEE = 2026


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.ventilation_service.run_in_thread",
        _passthrough,
    )


# ---------------------------------------------------------------------------
# apply_default_ventilation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_apply_default_simple_returns_none(monkeypatch, patch_run_in_thread):
    """ventilation_type='simple' → None peu importe le compte."""
    result = await ventilation_service.apply_default_ventilation(
        compte_m22bis="65",
        montant_total=Decimal("100"),
        etablissement_id=ETS,
        exercice_annee=ANNEE,
        ventilation_type="simple",
    )
    assert result is None


@pytest.mark.asyncio
async def test_apply_default_compte_65_full_hebergement(monkeypatch, patch_run_in_thread):
    """Compte 65 → 100% H, 0% reste."""
    result = await ventilation_service.apply_default_ventilation(
        compte_m22bis="6511",
        montant_total=Decimal("1000"),
        etablissement_id=ETS,
        exercice_annee=ANNEE,
        ventilation_type="ternaire_hds",
    )
    assert result == {
        "hebergement": Decimal("1000"),
        "dependance": Decimal("0"),
        "soins": Decimal("0"),
        "soins_autonomie": Decimal("0"),
    }


@pytest.mark.asyncio
async def test_apply_default_compte_66_full_soins(monkeypatch, patch_run_in_thread):
    """Compte 66 → 100% S (intérêts emprunts D.314-205)."""
    result = await ventilation_service.apply_default_ventilation(
        compte_m22bis="66111",
        montant_total=Decimal("500"),
        etablissement_id=ETS,
        exercice_annee=ANNEE,
        ventilation_type="ternaire_hds",
    )
    assert result["soins"] == Decimal("500")
    assert result["hebergement"] == Decimal("0")


@pytest.mark.asyncio
async def test_apply_default_compte_clef_gestionnaire(monkeypatch, patch_run_in_thread):
    """Compte sans règle dure → lookup clé gestionnaire → distribution."""
    monkeypatch.setattr(
        ventilation_service.cles_repartition_repo,
        "batch_lookup",
        lambda ets, annee, comptes: {
            "60222": {
                "taux_hebergement": Decimal("60"),
                "taux_dependance": Decimal("20"),
                "taux_soins": Decimal("20"),
                "taux_soins_autonomie": Decimal("0"),
            }
        },
    )
    result = await ventilation_service.apply_default_ventilation(
        compte_m22bis="60222",
        montant_total=Decimal("1000"),
        etablissement_id=ETS,
        exercice_annee=ANNEE,
        ventilation_type="ternaire_hds",
    )
    assert result["hebergement"] == Decimal("600.00")
    assert result["dependance"] == Decimal("200.00")
    assert result["soins"] == Decimal("200.00")


@pytest.mark.asyncio
async def test_apply_default_no_rule_no_key_returns_none(monkeypatch, patch_run_in_thread):
    """Compte sans règle ET sans clé → None (saisie manuelle attendue)."""
    monkeypatch.setattr(
        ventilation_service.cles_repartition_repo,
        "batch_lookup",
        lambda ets, annee, comptes: {},
    )
    result = await ventilation_service.apply_default_ventilation(
        compte_m22bis="60226",
        montant_total=Decimal("100"),
        etablissement_id=ETS,
        exercice_annee=ANNEE,
        ventilation_type="ternaire_hds",
    )
    assert result is None


@pytest.mark.asyncio
async def test_apply_default_residue_corrected_on_biggest(monkeypatch, patch_run_in_thread):
    """Σ après arrondi = montant_total exact (residue corrigé sur la
    section la plus grosse)."""
    monkeypatch.setattr(
        ventilation_service.cles_repartition_repo,
        "batch_lookup",
        lambda ets, annee, comptes: {
            "60222": {
                "taux_hebergement": Decimal("33.33"),
                "taux_dependance": Decimal("33.33"),
                "taux_soins": Decimal("33.34"),
                "taux_soins_autonomie": Decimal("0"),
            }
        },
    )
    result = await ventilation_service.apply_default_ventilation(
        compte_m22bis="60222",
        montant_total=Decimal("100.00"),
        etablissement_id=ETS,
        exercice_annee=ANNEE,
        ventilation_type="ternaire_hds",
    )
    total = (
        result["hebergement"] + result["dependance"] + result["soins"] + result["soins_autonomie"]
    )
    assert total == Decimal("100.00")


# ---------------------------------------------------------------------------
# batch_apply_default_ventilation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_batch_apply_mix_of_rules(monkeypatch, patch_run_in_thread):
    """Batch : 1 compte règle dure, 1 compte clé, 1 compte rien → 3 résultats positionnels."""
    monkeypatch.setattr(
        ventilation_service.cles_repartition_repo,
        "batch_lookup",
        lambda ets, annee, comptes: {
            "60222": {
                "taux_hebergement": Decimal("50"),
                "taux_dependance": Decimal("30"),
                "taux_soins": Decimal("20"),
                "taux_soins_autonomie": Decimal("0"),
            }
        },
    )
    items = [
        {"compte_m22bis": "65", "montant_basis": Decimal("100")},  # règle dure
        {"compte_m22bis": "60222", "montant_basis": Decimal("100")},  # clé
        {"compte_m22bis": "60226", "montant_basis": Decimal("100")},  # rien
    ]
    results = await ventilation_service.batch_apply_default_ventilation(
        items=items,
        etablissement_id=ETS,
        exercice_annee=ANNEE,
        ventilation_type="ternaire_hds",
    )
    assert len(results) == 3
    assert results[0]["hebergement"] == Decimal("100")  # règle dure 65→H
    assert results[1]["hebergement"] == Decimal("50.00")  # clé 50%
    assert results[2] is None  # rien


@pytest.mark.asyncio
async def test_batch_apply_simple_returns_all_none(monkeypatch, patch_run_in_thread):
    """ventilation_type='simple' → tous None peu importe les comptes."""
    items = [{"compte_m22bis": "65", "montant_basis": Decimal("100")}]
    results = await ventilation_service.batch_apply_default_ventilation(
        items=items,
        etablissement_id=ETS,
        exercice_annee=ANNEE,
        ventilation_type="simple",
    )
    assert results == [None]


# ---------------------------------------------------------------------------
# validate_explicit_ventilation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_validate_simple_forbids_h_d_s(monkeypatch, patch_run_in_thread):
    """ventilation='simple' + user pose H → 422 forbidden."""
    with pytest.raises(ValidationError) as exc:
        await ventilation_service.validate_explicit_ventilation(
            montant_basis=Decimal("100"),
            montant_hebergement=Decimal("100"),
            montant_dependance=None,
            montant_soins=None,
            montant_soins_autonomie=None,
            ventilation_type="simple",
            etablissement_id=ETS,
        )
    assert exc.value.code == "ventilation_forbidden_for_simple"


@pytest.mark.asyncio
async def test_validate_sum_ok(monkeypatch, patch_run_in_thread):
    """Σ H+D+S = montant_basis (tolérance OK)."""
    await ventilation_service.validate_explicit_ventilation(
        montant_basis=Decimal("100"),
        montant_hebergement=Decimal("60"),
        montant_dependance=Decimal("20"),
        montant_soins=Decimal("20"),
        montant_soins_autonomie=None,
        ventilation_type="ternaire_hds",
        etablissement_id=ETS,
    )


@pytest.mark.asyncio
async def test_validate_sum_mismatch_422(monkeypatch, patch_run_in_thread):
    """Σ ≠ basis → 422 ventilation_sum_mismatch."""
    with pytest.raises(ValidationError) as exc:
        await ventilation_service.validate_explicit_ventilation(
            montant_basis=Decimal("100"),
            montant_hebergement=Decimal("50"),
            montant_dependance=Decimal("30"),
            montant_soins=Decimal("10"),  # 50+30+10 = 90 ≠ 100
            montant_soins_autonomie=None,
            ventilation_type="ternaire_hds",
            etablissement_id=ETS,
        )
    assert exc.value.code == "ventilation_sum_mismatch"


@pytest.mark.asyncio
async def test_validate_sea_requires_ternaire_hdsea(monkeypatch, patch_run_in_thread):
    """SEA renseigné mais ventilation='ternaire_hds' → 422."""
    with pytest.raises(ValidationError) as exc:
        await ventilation_service.validate_explicit_ventilation(
            montant_basis=Decimal("100"),
            montant_hebergement=Decimal("60"),
            montant_dependance=Decimal("20"),
            montant_soins=Decimal("10"),
            montant_soins_autonomie=Decimal("10"),
            ventilation_type="ternaire_hds",
            etablissement_id=ETS,
        )
    assert exc.value.code == "sea_requires_ternaire_hdsea"


@pytest.mark.asyncio
async def test_validate_sea_requires_forfait_global_unique(monkeypatch, patch_run_in_thread):
    """SEA + ventilation='ternaire_hdsea' mais ETS forfait_global_unique=False → 422."""
    monkeypatch.setattr(
        ventilation_service.cles_repartition_repo,
        "get_etablissement_forfait_flag",
        lambda _: False,
    )
    with pytest.raises(ValidationError) as exc:
        await ventilation_service.validate_explicit_ventilation(
            montant_basis=Decimal("100"),
            montant_hebergement=Decimal("60"),
            montant_dependance=Decimal("10"),
            montant_soins=Decimal("20"),
            montant_soins_autonomie=Decimal("10"),
            ventilation_type="ternaire_hdsea",
            etablissement_id=ETS,
        )
    assert exc.value.code == "sea_requires_forfait_global_unique"


@pytest.mark.asyncio
async def test_validate_no_h_d_s_provided_skips_sum_check(monkeypatch, patch_run_in_thread):
    """Aucune col H/D/S/SEA posée → pas de validation Σ (cas standard:
    auto-vent a échoué, cabinet n'a pas encore saisi)."""
    await ventilation_service.validate_explicit_ventilation(
        montant_basis=Decimal("100"),
        montant_hebergement=None,
        montant_dependance=None,
        montant_soins=None,
        montant_soins_autonomie=None,
        ventilation_type="ternaire_hds",
        etablissement_id=ETS,
    )


# ---------------------------------------------------------------------------
# extract_basis_amount
# ---------------------------------------------------------------------------


def test_extract_basis_prefers_realise() -> None:
    """ERRD : montant_realise prioritaire."""
    ligne = {"montant_realise": Decimal("100"), "montant_previsions_totales": Decimal("90")}
    assert ventilation_service.extract_basis_amount(ligne) == Decimal("100")


def test_extract_basis_fallback_previsions() -> None:
    """EPRD : montant_realise NULL → previsions_totales."""
    ligne = {"montant_realise": None, "montant_previsions_totales": Decimal("90")}
    assert ventilation_service.extract_basis_amount(ligne) == Decimal("90")


def test_extract_basis_fallback_budget_initial() -> None:
    """Dernier fallback : budget_initial."""
    ligne = {
        "montant_realise": None,
        "montant_previsions_totales": None,
        "montant_budget_initial": Decimal("80"),
    }
    assert ventilation_service.extract_basis_amount(ligne) == Decimal("80")


def test_extract_basis_none_when_empty() -> None:
    """Tous montants None → None."""
    ligne = {"montant_realise": None, "montant_previsions_totales": None}
    assert ventilation_service.extract_basis_amount(ligne) is None
