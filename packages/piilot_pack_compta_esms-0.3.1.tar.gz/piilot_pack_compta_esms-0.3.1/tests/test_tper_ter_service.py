"""Unit tests for :mod:`piilot_pack_compta_esms.services.tper_ter_service`."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.tper_ter import (
    TperTerBulkUpsertRequest,
    TperTerLigneCreate,
)
from piilot_pack_compta_esms.services import tper_ter_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
DOC_ID = uuid4()
ETS_ID = uuid4()


@pytest.fixture
def patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.tper_ter_service.run_in_thread",
        _passthrough,
    )


@pytest.fixture
def valid_doc_ehpad(monkeypatch):
    """Doc + ETS valides, typologie='ehpad' → type_etablissement=ehpad_aja."""
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "get_ets_typologie",
        lambda ets, company: {"typologie": "ehpad"},
    )

    # Disable async fail-open warning lookup
    async def _exists_true(*a, **kw):
        return True

    monkeypatch.setattr(tper_ter_service.reference_lookup, "cnsa_categorie_exists", _exists_true)
    monkeypatch.setattr(tper_ter_service.reference_lookup, "cnsa_fonction_exists", _exists_true)


def _row(**overrides):
    base = {
        "id": uuid4(),
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "etablissement_id": ETS_ID,
        "type_tableau": "TPER",
        "type_etablissement": "ehpad_aja",
        "categorie_cnsa": "DIRECTION_ADMINISTRATION",
        "fonction": "Directeur",
        "type_poste": "P",
        "etpr_prevus": Decimal("1.00"),
        "etpt_prevus": Decimal("1.00"),
        "etpr_realises": None,
        "etpt_realises": None,
        "remunerations_prevues": Decimal("80000"),
        "remunerations_realisees": None,
        "section_imputation": "hebergement",
        "pct_section": Decimal("100"),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# list_tper_ter
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_no_filters_returns_all(patch_run_in_thread, valid_doc_ehpad, monkeypatch):
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "list_by_filter",
        lambda doc, ets=None, t=None: [_row(), _row(type_tableau="TER")],
    )

    result = await tper_ter_service.list_tper_ter(DOC_ID, COMPANY)

    assert result.ets_id_filtre is None
    assert result.type_tableau_filtre is None
    assert len(result.items) == 2


@pytest.mark.asyncio
async def test_list_with_filters(patch_run_in_thread, valid_doc_ehpad, monkeypatch):
    captured = {}

    def _list(doc, ets=None, t=None):
        captured["ets"] = ets
        captured["t"] = t
        return [_row(type_tableau="TPER")]

    monkeypatch.setattr(tper_ter_service.tper_ter_repo, "list_by_filter", _list)

    result = await tper_ter_service.list_tper_ter(
        DOC_ID, COMPANY, ets_id=ETS_ID, type_tableau="TPER"
    )

    assert captured["ets"] == ETS_ID
    assert captured["t"] == "TPER"
    assert result.ets_id_filtre == ETS_ID
    assert result.type_tableau_filtre == "TPER"


@pytest.mark.asyncio
async def test_list_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    with pytest.raises(NotFoundError) as exc:
        await tper_ter_service.list_tper_ter(DOC_ID, COMPANY)
    assert exc.value.code == "document_not_found"


# ---------------------------------------------------------------------------
# bulk_upsert_tper_ter — Q9 auto-déduit type_etablissement
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bulk_upsert_deduce_ehpad_aja(patch_run_in_thread, valid_doc_ehpad, monkeypatch):
    captured = {}

    def _replace(**kwargs):
        captured.update(kwargs)
        return []

    monkeypatch.setattr(tper_ter_service.tper_ter_repo, "replace_by_doc_ets_type", _replace)
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo, "list_by_filter", lambda d, e=None, t=None: []
    )

    payload = TperTerBulkUpsertRequest(
        ets_id=ETS_ID,
        type_tableau="TPER",
        items=[
            TperTerLigneCreate(
                categorie_cnsa="INFIRMIERS",
                fonction="IDE",
                type_poste="P",
                etpr_prevus=Decimal("2.5"),
                section_imputation="soins",
                pct_section=Decimal("100"),
            ),
        ],
    )
    await tper_ter_service.bulk_upsert_tper_ter(DOC_ID, COMPANY, payload)

    assert captured["type_tableau"] == "TPER"
    assert captured["type_etablissement"] == "ehpad_aja"
    assert len(captured["items"]) == 1


@pytest.mark.asyncio
async def test_bulk_upsert_deduce_fam_samsah(patch_run_in_thread, monkeypatch):
    """ETS typologie='fam' → type_etablissement='fam_samsah'."""

    async def _exists_true(*a, **kw):
        return True

    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "get_ets_typologie",
        lambda ets, company: {"typologie": "fam"},
    )
    monkeypatch.setattr(tper_ter_service.reference_lookup, "cnsa_categorie_exists", _exists_true)
    monkeypatch.setattr(tper_ter_service.reference_lookup, "cnsa_fonction_exists", _exists_true)

    captured = {}

    def _replace(**kwargs):
        captured.update(kwargs)
        return []

    monkeypatch.setattr(tper_ter_service.tper_ter_repo, "replace_by_doc_ets_type", _replace)
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo, "list_by_filter", lambda d, e=None, t=None: []
    )

    payload = TperTerBulkUpsertRequest(ets_id=ETS_ID, type_tableau="TER", items=[])
    await tper_ter_service.bulk_upsert_tper_ter(DOC_ID, COMPANY, payload)

    assert captured["type_etablissement"] == "fam_samsah"


@pytest.mark.asyncio
async def test_bulk_upsert_deduce_autre_essms_fallback(patch_run_in_thread, monkeypatch):
    """ETS typologie='esat' (inconnu mapping) → fallback autre_essms."""

    async def _exists_true(*a, **kw):
        return True

    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "get_ets_typologie",
        lambda ets, company: {"typologie": "esat"},
    )
    monkeypatch.setattr(tper_ter_service.reference_lookup, "cnsa_categorie_exists", _exists_true)
    monkeypatch.setattr(tper_ter_service.reference_lookup, "cnsa_fonction_exists", _exists_true)

    captured = {}
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "replace_by_doc_ets_type",
        lambda **kw: captured.update(kw) or [],
    )
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo, "list_by_filter", lambda d, e=None, t=None: []
    )

    payload = TperTerBulkUpsertRequest(ets_id=ETS_ID, type_tableau="TER", items=[])
    await tper_ter_service.bulk_upsert_tper_ter(DOC_ID, COMPANY, payload)

    assert captured["type_etablissement"] == "autre_essms"


@pytest.mark.asyncio
async def test_bulk_upsert_ets_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "document_belongs_to_company",
        lambda doc, company: True,
    )
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "get_ets_typologie",
        lambda ets, company: None,
    )

    payload = TperTerBulkUpsertRequest(ets_id=ETS_ID, type_tableau="TPER", items=[])
    with pytest.raises(NotFoundError) as exc:
        await tper_ter_service.bulk_upsert_tper_ter(DOC_ID, COMPANY, payload)
    assert exc.value.code == "etablissement_not_found"


@pytest.mark.asyncio
async def test_bulk_upsert_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    payload = TperTerBulkUpsertRequest(ets_id=ETS_ID, type_tableau="TPER", items=[])
    with pytest.raises(NotFoundError) as exc:
        await tper_ter_service.bulk_upsert_tper_ter(DOC_ID, COMPANY, payload)
    assert exc.value.code == "document_not_found"


# ---------------------------------------------------------------------------
# compute_totals — by_categorie + by_section
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_totals_with_breakdown(patch_run_in_thread, valid_doc_ehpad, monkeypatch):
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "totals_by_categorie",
        lambda d: [
            {
                "categorie_cnsa": "DIRECTION_ADMINISTRATION",
                "etpr_prevus": Decimal("3"),
                "etpt_prevus": Decimal("3"),
                "etpr_realises": Decimal("3"),
                "etpt_realises": Decimal("3"),
                "remunerations_prevues": Decimal("240000"),
                "remunerations_realisees": Decimal("245000"),
            },
            {
                "categorie_cnsa": "INFIRMIERS",
                "etpr_prevus": Decimal("10"),
                "etpt_prevus": Decimal("9.5"),
                "etpr_realises": Decimal("10"),
                "etpt_realises": Decimal("9.5"),
                "remunerations_prevues": Decimal("400000"),
                "remunerations_realisees": Decimal("410000"),
            },
        ],
    )
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "totals_by_section",
        lambda d: [
            {
                "section_imputation": "hebergement",
                "etpr_prevus_ventile": Decimal("3"),
                "etpr_realises_ventile": Decimal("3"),
                "remunerations_prevues_ventilees": Decimal("240000"),
                "remunerations_realisees_ventilees": Decimal("245000"),
            },
            {
                "section_imputation": "soins",
                "etpr_prevus_ventile": Decimal("10"),
                "etpr_realises_ventile": Decimal("10"),
                "remunerations_prevues_ventilees": Decimal("400000"),
                "remunerations_realisees_ventilees": Decimal("410000"),
            },
        ],
    )

    result = await tper_ter_service.compute_totals(DOC_ID, COMPANY)

    assert len(result.by_categorie) == 2
    assert len(result.by_section) == 2
    assert result.total_etpr_prevus == Decimal("13")
    assert result.total_etpt_prevus == Decimal("12.5")
    assert result.total_remunerations_prevues == Decimal("640000")
    assert result.total_remunerations_realisees == Decimal("655000")


@pytest.mark.asyncio
async def test_totals_empty(patch_run_in_thread, valid_doc_ehpad, monkeypatch):
    monkeypatch.setattr(tper_ter_service.tper_ter_repo, "totals_by_categorie", lambda d: [])
    monkeypatch.setattr(tper_ter_service.tper_ter_repo, "totals_by_section", lambda d: [])

    result = await tper_ter_service.compute_totals(DOC_ID, COMPANY)

    assert result.by_categorie == []
    assert result.by_section == []
    assert result.total_etpr_prevus == Decimal("0")


@pytest.mark.asyncio
async def test_totals_doc_not_found(patch_run_in_thread, monkeypatch):
    monkeypatch.setattr(
        tper_ter_service.tper_ter_repo,
        "document_belongs_to_company",
        lambda doc, company: False,
    )

    with pytest.raises(NotFoundError):
        await tper_ter_service.compute_totals(DOC_ID, COMPANY)
