"""Route tests for feature_catalog endpoints (L2 §8)."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.feature_catalog import FeatureCatalogRead
from piilot_pack_compta_esms.routes import feature_catalog as fc_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import feature_catalog_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
USER = uuid4()
USER_AUTH = (USER, "user", COMPANY)


def _make_row(**overrides) -> FeatureCatalogRead:
    base = {
        "feature_key": "crp_charges_g1",
        "label": "CRP — Charges G1",
        "description": None,
        "columns_required": {"compte": "text", "montant": "numeric"},
        "is_mandatory": True,
        "applicable_typologies": [],
        "applicable_doc_types": ["eprd", "errd"],
        "plan_comptable_cible": "M22Bis",
        "contract_version": 1,
        "ordre": 11,
        "created_at": datetime.now(UTC),
    }
    base.update(overrides)
    return FeatureCatalogRead.model_validate(base)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(fc_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


def test_list_features_200(client, monkeypatch):
    captured: dict = {}

    async def _fake(**kw):
        captured.update(kw)
        return [_make_row(), _make_row(feature_key="crp_produits", ordre=14)]

    monkeypatch.setattr(feature_catalog_service, "list_features", _fake)
    r = client.get(
        "/plugins/compta_esms/feature-catalog" "?doc_type=eprd&typologie=ehpad&mandatory_only=true"
    )
    assert r.status_code == 200
    assert captured == {"doc_type": "eprd", "typologie": "ehpad", "mandatory_only": True}
    body = r.json()
    assert [f["feature_key"] for f in body] == ["crp_charges_g1", "crp_produits"]


def test_list_features_invalid_doc_type_422(client):
    """The DocType Literal rejects unknown doc_type values."""
    r = client.get("/plugins/compta_esms/feature-catalog?doc_type=nope")
    assert r.status_code == 422


def test_list_features_empty(client, monkeypatch):
    async def _fake(**kw):
        return []

    monkeypatch.setattr(feature_catalog_service, "list_features", _fake)
    r = client.get("/plugins/compta_esms/feature-catalog")
    assert r.status_code == 200
    assert r.json() == []


def test_get_feature_200(client, monkeypatch):
    async def _fake(key):
        return _make_row(feature_key=key)

    monkeypatch.setattr(feature_catalog_service, "get_feature", _fake)
    r = client.get("/plugins/compta_esms/feature-catalog/crp_charges_g1")
    assert r.status_code == 200
    body = r.json()
    assert body["feature_key"] == "crp_charges_g1"
    assert body["columns_required"]["montant"] == "numeric"


def test_get_feature_404(client, monkeypatch):
    async def _fake(key):
        raise NotFoundError("nope", code="feature_not_found")

    monkeypatch.setattr(feature_catalog_service, "get_feature", _fake)
    r = client.get("/plugins/compta_esms/feature-catalog/ghost")
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "feature_not_found"
