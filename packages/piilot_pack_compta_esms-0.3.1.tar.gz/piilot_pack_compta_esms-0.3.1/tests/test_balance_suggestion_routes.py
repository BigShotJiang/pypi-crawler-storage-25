"""Route tests for the balance suggestion endpoints (L2 §7bis.2)."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import balance_suggestion as bs_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import balance_suggestion_service

COMPANY = uuid4()
USER = uuid4()
IMPORT_ID = uuid4()
BUILDER_AUTH = (USER, "builder", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


def _make_import_dict(**overrides):
    base = {
        "id": IMPORT_ID,
        "company_id": COMPANY,
        "exercice_id": None,
        "etablissement_id": None,
        "source_plan": "PCG",
        "source_filename": "balance.xlsx",
        "source_storage_key": "plugins/compta_esms/balance_imports/x/balance.xlsx",
        "periode_label": "2025-12",
        "nb_lignes_source": 3,
        "nb_lignes_mappees": 0,
        "nb_lignes_non_mappees": 0,
        "column_detection": {
            "compte": 0,
            "libelle": 1,
            "debit": 2,
            "credit": 3,
            "solde": 4,
            "periode": None,
        },
        "preview_data": {"header": [], "rows": []},
        "suggestions": [
            {
                "source_account": "60611",
                "label_hint": "Eau",
                "targets": [
                    {
                        "target_m22bis_account": "60611",
                        "weight": 1.0,
                        "confidence": 1.0,
                        "origin": "pcg_to_m22bis_kb",
                    }
                ],
            }
        ],
        "mapping_snapshot": {},
        "materialized_kb_id": None,
        "materialized_kb_table_name": None,
        "status": "pending",
        "error_payload": {},
        "imported_by_user_id": USER,
        "imported_at": datetime.now(UTC),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(bs_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


def test_suggest_mappings_200_empty_body(client, monkeypatch):
    """An empty POST body should use the SuggestRequest defaults."""
    captured: dict = {}

    async def _fake(company_id, import_id, request):
        captured["include_llm"] = request.include_llm
        captured["source_plan"] = request.source_plan
        from piilot_pack_compta_esms.models.balance_import import BalanceImportRead

        return BalanceImportRead.model_validate(_make_import_dict())

    monkeypatch.setattr(balance_suggestion_service, "suggest_mappings", _fake)
    r = client.post(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/suggest-mappings")
    assert r.status_code == 200
    assert captured["include_llm"] is False  # default
    assert captured["source_plan"] is None  # default


def test_suggest_mappings_with_body(client, monkeypatch):
    captured: dict = {}

    async def _fake(company_id, import_id, request):
        captured["include_llm"] = request.include_llm
        captured["llm_threshold"] = request.llm_threshold
        from piilot_pack_compta_esms.models.balance_import import BalanceImportRead

        return BalanceImportRead.model_validate(_make_import_dict())

    monkeypatch.setattr(balance_suggestion_service, "suggest_mappings", _fake)
    r = client.post(
        f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/suggest-mappings",
        json={"include_llm": True, "llm_threshold": 0.5},
    )
    assert r.status_code == 200
    assert captured["include_llm"] is True
    assert captured["llm_threshold"] == 0.5


def test_list_suggestions_200(client, monkeypatch):
    captured: dict = {}

    async def _fake(company_id, import_id, *, confidence_min, origins):
        captured["confidence_min"] = confidence_min
        captured["origins"] = origins
        from piilot_pack_compta_esms.models.suggestion import (
            SourceAccountSuggestion,
            SuggestionTarget,
        )

        return [
            SourceAccountSuggestion(
                source_account="60611",
                label_hint="Eau",
                targets=[
                    SuggestionTarget(
                        target_m22bis_account="60611",
                        weight=1.0,
                        confidence=1.0,
                        origin="pcg_to_m22bis_kb",
                    )
                ],
            )
        ]

    monkeypatch.setattr(balance_suggestion_service, "list_suggestions", _fake)
    r = client.get(
        f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/suggestions"
        "?confidence_min=0.5&origin=pcg_to_m22bis_kb,preset"
    )
    assert r.status_code == 200
    assert captured["confidence_min"] == 0.5
    assert captured["origins"] == ["pcg_to_m22bis_kb", "preset"]
    assert r.json()[0]["source_account"] == "60611"


def test_list_suggestions_422_bad_confidence(client):
    """``confidence_min`` is bounded to [0, 1.0] — 1.5 should 422."""
    r = client.get(
        f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/suggestions" "?confidence_min=1.5"
    )
    assert r.status_code == 422


def test_accept_all_above_200(client, monkeypatch):
    captured: dict = {}

    async def _fake(company_id, import_id, payload):
        captured["threshold"] = payload.confidence_threshold
        return []  # Empty list of BalanceMappingRead

    monkeypatch.setattr(balance_suggestion_service, "accept_all_above", _fake)
    r = client.post(
        f"/plugins/compta_esms/balance-imports/{IMPORT_ID}" "/suggestions:accept-all-above",
        json={"confidence_threshold": 0.9},
    )
    assert r.status_code == 200
    assert captured["threshold"] == 0.9


def test_accept_all_above_422_missing_threshold(client):
    """``confidence_threshold`` is required by the Pydantic model."""
    r = client.post(
        f"/plugins/compta_esms/balance-imports/{IMPORT_ID}" "/suggestions:accept-all-above",
        json={},
    )
    assert r.status_code == 422


def test_user_cannot_suggest(client):
    """Builder is required for POST suggest-mappings — plain user → 403."""
    from fastapi import HTTPException

    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.post(f"/plugins/compta_esms/balance-imports/{IMPORT_ID}/suggest-mappings")
    assert r.status_code == 403
