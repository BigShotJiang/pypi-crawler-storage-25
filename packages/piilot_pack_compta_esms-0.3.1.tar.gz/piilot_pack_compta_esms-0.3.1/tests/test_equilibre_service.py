"""Tests §BD v0.3 — equilibre_service applicator (D-034).

Couvre :
* _dispatch_equilibre 5 natures × CPOM ON/OFF (matrice complète)
* compute_equilibre_applicable (per-ETS) — appel cpom_service +
  og_repo + etablissement_repo
* load_equilibre_strict_inputs (SUM produits / charges)
* load_equilibre_reel_inputs (C1 via tarifs, C2-C5 None)
* apply_equilibre_check_for_document : 5 paths
  (ERRD skip / NON_APPLICABLE / STRICT OK/KO / REEL OK/KO)
"""

from __future__ import annotations

from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.models.finance import (
    EquilibreReelInput,
)
from piilot_pack_compta_esms.models.tarif_propose import (
    TarifSectionAggregate,
    TarifValidationReport,
)
from piilot_pack_compta_esms.services import equilibre_service
from piilot_pack_compta_esms.services.errors import NotFoundError

# Capture la VRAIE fonction avant que le conftest autouse mock ne soit
# appliqué (ce fichier doit tester le service réel, pas le mock).
_REAL_APPLY = equilibre_service.apply_equilibre_check_for_document


@pytest.fixture(autouse=True)
def _restore_real_apply_for_this_file(monkeypatch):
    """Override le mock conftest `_default_equilibre_check_passthrough`
    pour réactiver la vraie fonction sur les tests de ce fichier."""
    monkeypatch.setattr(
        equilibre_service,
        "apply_equilibre_check_for_document",
        _REAL_APPLY,
    )


COMPANY = uuid4()
DOC_ID = uuid4()
ETS_ID = uuid4()
OG_ID = uuid4()


@pytest.fixture
def passthrough_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.services.equilibre_service.run_in_thread",
        _passthrough,
    )


# --------------------------------------------------------------------
# _dispatch_equilibre — matrice 5 × 2
# --------------------------------------------------------------------


def test_dispatch_matrix_5_natures_x_cpom():
    """Source : KB B.7 + 05-workflows §équilibre R.314-222."""
    matrix = {
        ("ETABLISSEMENT_PUBLIC_SANTE", False): "STRICT",
        ("ETABLISSEMENT_PUBLIC_SANTE", True): "REEL",
        ("ESMS_PUBLIC_AUTONOME", False): "STRICT",
        ("ESMS_PUBLIC_AUTONOME", True): "REEL",
        ("CCAS_CIAS_COLLECTIVITE", False): "STRICT",
        ("CCAS_CIAS_COLLECTIVITE", True): "REEL",
        ("PRIVE_NON_LUCRATIF", False): "STRICT",
        ("PRIVE_NON_LUCRATIF", True): "REEL",
        ("PRIVE_COMMERCIAL", False): "NON_APPLICABLE",
        ("PRIVE_COMMERCIAL", True): "REEL",
    }
    for (nature, cpom), expected in matrix.items():
        actual = equilibre_service._dispatch_equilibre(nature, cpom)
        assert actual == expected, f"{nature} × cpom={cpom} → {actual} (want {expected})"


# --------------------------------------------------------------------
# compute_equilibre_applicable — per-ETS
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_compute_per_ets_returns_reel_when_in_cpom(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        equilibre_service.etablissement_repo,
        "get_by_id",
        lambda _: {"id": ETS_ID, "og_id": OG_ID},
    )
    monkeypatch.setattr(
        equilibre_service.og_repo,
        "get_by_id",
        lambda _: {"id": OG_ID, "nature_juridique": "PRIVE_NON_LUCRATIF"},
    )

    async def _in_cpom(*_, **__):
        return True

    monkeypatch.setattr(equilibre_service.cpom_service, "is_etablissement_in_cpom", _in_cpom)
    assert await equilibre_service.compute_equilibre_applicable(ETS_ID, 2026) == "REEL"


@pytest.mark.asyncio
async def test_compute_per_ets_returns_non_applicable_for_prive_commercial_no_cpom(
    monkeypatch, passthrough_run_in_thread
):
    monkeypatch.setattr(
        equilibre_service.etablissement_repo,
        "get_by_id",
        lambda _: {"id": ETS_ID, "og_id": OG_ID},
    )
    monkeypatch.setattr(
        equilibre_service.og_repo,
        "get_by_id",
        lambda _: {"id": OG_ID, "nature_juridique": "PRIVE_COMMERCIAL"},
    )

    async def _no_cpom(*_, **__):
        return False

    monkeypatch.setattr(equilibre_service.cpom_service, "is_etablissement_in_cpom", _no_cpom)
    assert await equilibre_service.compute_equilibre_applicable(ETS_ID, 2026) == "NON_APPLICABLE"


@pytest.mark.asyncio
async def test_compute_per_ets_404_when_ets_missing(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(equilibre_service.etablissement_repo, "get_by_id", lambda _: None)
    with pytest.raises(NotFoundError) as exc:
        await equilibre_service.compute_equilibre_applicable(ETS_ID, 2026)
    assert exc.value.code == "ets_not_found"


@pytest.mark.asyncio
async def test_compute_per_ets_404_when_og_missing(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        equilibre_service.etablissement_repo,
        "get_by_id",
        lambda _: {"id": ETS_ID, "og_id": OG_ID},
    )
    monkeypatch.setattr(equilibre_service.og_repo, "get_by_id", lambda _: None)
    with pytest.raises(NotFoundError) as exc:
        await equilibre_service.compute_equilibre_applicable(ETS_ID, 2026)
    assert exc.value.code == "og_not_found"


# --------------------------------------------------------------------
# load_equilibre_strict_inputs
# --------------------------------------------------------------------


@pytest.mark.asyncio
async def test_load_strict_returns_zero_for_empty_doc(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        equilibre_service,
        "_query_strict_aggregates",
        lambda _: {
            "total_recettes": Decimal("0"),
            "total_depenses": Decimal("0"),
            "rows_count": 0,
        },
    )
    out = await equilibre_service.load_equilibre_strict_inputs(DOC_ID)
    assert out.total_recettes == Decimal("0")
    assert out.total_depenses == Decimal("0")


@pytest.mark.asyncio
async def test_load_strict_returns_aggregated_inputs(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        equilibre_service,
        "_query_strict_aggregates",
        lambda _: {
            "total_recettes": Decimal("100000.00"),
            "total_depenses": Decimal("99999.50"),
            "rows_count": 42,
        },
    )
    out = await equilibre_service.load_equilibre_strict_inputs(DOC_ID)
    assert out.total_recettes == Decimal("100000.00")
    assert out.total_depenses == Decimal("99999.50")


# --------------------------------------------------------------------
# load_equilibre_reel_inputs
# --------------------------------------------------------------------


def _report_with_partial_notif() -> TarifValidationReport:
    """Une section avec montant_notifie NULL → C1 doit rester None."""
    return TarifValidationReport(
        document_id=DOC_ID,
        sections=[
            TarifSectionAggregate(
                section="HEBERGEMENT",
                rows_count=1,
                total_propose=Decimal("75"),
                total_notifie=None,
                ecart=None,
                all_validated_tripartite=False,
            )
        ],
        total_rows=1,
        all_sections_tripartite=False,
        has_rejected_rows=False,
    )


def _report_fully_notif() -> TarifValidationReport:
    """Toutes les sections sont notifiées → C1 calculable."""
    return TarifValidationReport(
        document_id=DOC_ID,
        sections=[
            TarifSectionAggregate(
                section="HEBERGEMENT",
                rows_count=1,
                total_propose=Decimal("100"),
                total_notifie=Decimal("100"),
                ecart=Decimal("0"),
                all_validated_tripartite=True,
            ),
            TarifSectionAggregate(
                section="DEPENDANCE",
                rows_count=1,
                total_propose=Decimal("50"),
                total_notifie=Decimal("50"),
                ecart=Decimal("0"),
                all_validated_tripartite=True,
            ),
        ],
        total_rows=2,
        all_sections_tripartite=True,
        has_rejected_rows=False,
    )


@pytest.mark.asyncio
async def test_load_reel_c1_populated_when_all_sections_notified(
    monkeypatch, passthrough_run_in_thread
):
    async def _report(*_, **__):
        return _report_fully_notif()

    monkeypatch.setattr(equilibre_service.tarifs_service, "build_validation_report", _report)
    out = await equilibre_service.load_equilibre_reel_inputs(COMPANY, DOC_ID)
    assert out.produits_tarif_saisis == Decimal("150")
    assert out.produits_tarif_notifies == Decimal("150")
    # C2-C5 restent None (v0.3 not wired)
    assert out.caf_n is None
    assert out.sincerite_commentee is None


@pytest.mark.asyncio
async def test_load_reel_c1_none_when_partial_notification(monkeypatch, passthrough_run_in_thread):
    """Section sans montant_notifie → C1 doit rester non-évaluable."""

    async def _report(*_, **__):
        return _report_with_partial_notif()

    monkeypatch.setattr(equilibre_service.tarifs_service, "build_validation_report", _report)
    out = await equilibre_service.load_equilibre_reel_inputs(COMPANY, DOC_ID)
    assert out.produits_tarif_saisis is None
    assert out.produits_tarif_notifies is None


@pytest.mark.asyncio
async def test_load_reel_tolerant_to_tarifs_failure(monkeypatch, passthrough_run_in_thread):
    """Si le doc n'a pas de tarifs proposés (NotFoundError),
    le service ne propage pas et retourne un input vide."""

    async def _raise(*_, **__):
        raise NotFoundError("no doc", code="document_not_found")

    monkeypatch.setattr(equilibre_service.tarifs_service, "build_validation_report", _raise)
    out = await equilibre_service.load_equilibre_reel_inputs(COMPANY, DOC_ID)
    assert out.produits_tarif_saisis is None


# --------------------------------------------------------------------
# apply_equilibre_check_for_document — 5 paths
# --------------------------------------------------------------------


def _ctx(type_doc="eprd", nature="PRIVE_NON_LUCRATIF", any_cpom=False):
    return {
        "type_document": type_doc,
        "nature_juridique": nature,
        "any_inclus_cpom": any_cpom,
    }


@pytest.mark.asyncio
async def test_apply_check_errd_skips_and_returns_non_applicable(
    monkeypatch, passthrough_run_in_thread
):
    """ERRD est hors scope §BD — return NON_APPLICABLE sans toucher la DB."""
    monkeypatch.setattr(
        equilibre_service,
        "_query_doc_context_for_equilibre",
        lambda _: _ctx(type_doc="errd"),
    )
    write_called = False

    def _no_write(*_, **__):
        nonlocal write_called
        write_called = True

    monkeypatch.setattr(equilibre_service, "_update_equilibre_atteint", _no_write)
    out = await equilibre_service.apply_equilibre_check_for_document(COMPANY, DOC_ID)
    assert out.mode == "NON_APPLICABLE"
    assert out.verdict == "NON_APPLICABLE"
    # ERRD short-circuit n'écrit pas la colonne (laisse NULL).
    assert write_called is False


@pytest.mark.asyncio
async def test_apply_check_doc_not_found(monkeypatch, passthrough_run_in_thread):
    monkeypatch.setattr(
        equilibre_service,
        "_query_doc_context_for_equilibre",
        lambda _: None,
    )
    with pytest.raises(NotFoundError):
        await equilibre_service.apply_equilibre_check_for_document(COMPANY, DOC_ID)


@pytest.mark.asyncio
async def test_apply_check_non_applicable_writes_column(monkeypatch, passthrough_run_in_thread):
    """PRIVE_COMMERCIAL hors CPOM → NON_APPLICABLE + update DB."""
    monkeypatch.setattr(
        equilibre_service,
        "_query_doc_context_for_equilibre",
        lambda _: _ctx(nature="PRIVE_COMMERCIAL", any_cpom=False),
    )
    captured = []

    def _capture(doc, verdict):
        captured.append(verdict)

    monkeypatch.setattr(equilibre_service, "_update_equilibre_atteint", _capture)
    out = await equilibre_service.apply_equilibre_check_for_document(COMPANY, DOC_ID)
    assert out.mode == "NON_APPLICABLE"
    assert out.verdict == "NON_APPLICABLE"
    assert captured == ["NON_APPLICABLE"]


@pytest.mark.asyncio
async def test_apply_check_strict_oui_when_balanced(monkeypatch, passthrough_run_in_thread):
    """ESMS_PUBLIC_AUTONOME hors CPOM → STRICT. Recettes == dépenses → OUI."""
    monkeypatch.setattr(
        equilibre_service,
        "_query_doc_context_for_equilibre",
        lambda _: _ctx(nature="ESMS_PUBLIC_AUTONOME", any_cpom=False),
    )
    monkeypatch.setattr(
        equilibre_service,
        "_query_strict_aggregates",
        lambda _: {
            "total_recettes": Decimal("100"),
            "total_depenses": Decimal("100"),
            "rows_count": 2,
        },
    )
    captured = []

    def _capture(doc, verdict):
        captured.append(verdict)

    monkeypatch.setattr(equilibre_service, "_update_equilibre_atteint", _capture)
    out = await equilibre_service.apply_equilibre_check_for_document(COMPANY, DOC_ID)
    assert out.mode == "STRICT"
    assert out.verdict == "OUI"
    assert captured == ["OUI"]


@pytest.mark.asyncio
async def test_apply_check_strict_non_when_unbalanced(monkeypatch, passthrough_run_in_thread):
    """Recettes != dépenses → STRICT NON. Bloque la transition."""
    monkeypatch.setattr(
        equilibre_service,
        "_query_doc_context_for_equilibre",
        lambda _: _ctx(nature="ESMS_PUBLIC_AUTONOME", any_cpom=False),
    )
    monkeypatch.setattr(
        equilibre_service,
        "_query_strict_aggregates",
        lambda _: {
            "total_recettes": Decimal("100"),
            "total_depenses": Decimal("99"),  # 1€ d'écart > tolerance 0.01
            "rows_count": 2,
        },
    )
    captured = []
    monkeypatch.setattr(
        equilibre_service,
        "_update_equilibre_atteint",
        lambda doc, verdict: captured.append(verdict),
    )
    out = await equilibre_service.apply_equilibre_check_for_document(COMPANY, DOC_ID)
    assert out.mode == "STRICT"
    assert out.verdict == "NON"
    assert captured == ["NON"]


@pytest.mark.asyncio
async def test_apply_check_strict_oui_within_tolerance(monkeypatch, passthrough_run_in_thread):
    """Écart 0.01€ exact → toléré (S03 p.29 arrondi)."""
    monkeypatch.setattr(
        equilibre_service,
        "_query_doc_context_for_equilibre",
        lambda _: _ctx(nature="ESMS_PUBLIC_AUTONOME", any_cpom=False),
    )
    monkeypatch.setattr(
        equilibre_service,
        "_query_strict_aggregates",
        lambda _: {
            "total_recettes": Decimal("100.00"),
            "total_depenses": Decimal("99.99"),
            "rows_count": 2,
        },
    )
    monkeypatch.setattr(equilibre_service, "_update_equilibre_atteint", lambda doc, v: None)
    out = await equilibre_service.apply_equilibre_check_for_document(COMPANY, DOC_ID)
    assert out.verdict == "OUI"


@pytest.mark.asyncio
async def test_apply_check_reel_non_when_inputs_partial(monkeypatch, passthrough_run_in_thread):
    """In CPOM → REEL. Sans toutes les inputs (C2-C5 None v0.3) →
    evaluable_globalement=False → verdict NON (D-034 conservateur)."""
    monkeypatch.setattr(
        equilibre_service,
        "_query_doc_context_for_equilibre",
        lambda _: _ctx(nature="PRIVE_NON_LUCRATIF", any_cpom=True),
    )

    async def _empty_inputs(*_, **__):
        return EquilibreReelInput()

    monkeypatch.setattr(equilibre_service, "load_equilibre_reel_inputs", _empty_inputs)
    captured = []
    monkeypatch.setattr(
        equilibre_service,
        "_update_equilibre_atteint",
        lambda doc, v: captured.append(v),
    )
    out = await equilibre_service.apply_equilibre_check_for_document(COMPANY, DOC_ID)
    assert out.mode == "REEL"
    assert out.verdict == "NON"
    assert captured == ["NON"]


@pytest.mark.asyncio
async def test_apply_check_reel_oui_when_all_conditions_pass(
    monkeypatch, passthrough_run_in_thread
):
    """Tous les inputs renseignés + 5 conditions passent → OUI."""
    monkeypatch.setattr(
        equilibre_service,
        "_query_doc_context_for_equilibre",
        lambda _: _ctx(nature="PRIVE_NON_LUCRATIF", any_cpom=True),
    )

    async def _full_inputs(*_, **__):
        return EquilibreReelInput(
            produits_tarif_saisis=Decimal("100"),
            produits_tarif_notifies=Decimal("100"),
            sincerite_commentee=True,
            capital_rembourse_via_emprunt=Decimal("0"),
            caf_n=Decimal("50"),
            capital_a_rembourser_n=Decimal("40"),
            recettes_affectees=Decimal("10"),
            recettes_affectees_utilisees=Decimal("10"),
        )

    monkeypatch.setattr(equilibre_service, "load_equilibre_reel_inputs", _full_inputs)
    captured = []
    monkeypatch.setattr(
        equilibre_service,
        "_update_equilibre_atteint",
        lambda doc, v: captured.append(v),
    )
    out = await equilibre_service.apply_equilibre_check_for_document(COMPANY, DOC_ID)
    assert out.mode == "REEL"
    assert out.verdict == "OUI"
    assert captured == ["OUI"]


@pytest.mark.asyncio
async def test_apply_check_reel_non_when_c1_fails(monkeypatch, passthrough_run_in_thread):
    """C1 KO (saisis != notifiés) → NON."""
    monkeypatch.setattr(
        equilibre_service,
        "_query_doc_context_for_equilibre",
        lambda _: _ctx(nature="PRIVE_NON_LUCRATIF", any_cpom=True),
    )

    async def _c1_ko(*_, **__):
        return EquilibreReelInput(
            produits_tarif_saisis=Decimal("100"),
            produits_tarif_notifies=Decimal("95"),  # 5€ d'écart
            sincerite_commentee=True,
            capital_rembourse_via_emprunt=Decimal("0"),
            caf_n=Decimal("50"),
            capital_a_rembourser_n=Decimal("40"),
            recettes_affectees=Decimal("10"),
            recettes_affectees_utilisees=Decimal("10"),
        )

    monkeypatch.setattr(equilibre_service, "load_equilibre_reel_inputs", _c1_ko)
    monkeypatch.setattr(
        equilibre_service,
        "_update_equilibre_atteint",
        lambda doc, v: None,
    )
    out = await equilibre_service.apply_equilibre_check_for_document(COMPANY, DOC_ID)
    assert out.verdict == "NON"


@pytest.mark.asyncio
async def test_apply_check_reel_non_when_c4_fails(monkeypatch, passthrough_run_in_thread):
    """C4 KO (CAF insuffisante pour IAF) → NON."""
    monkeypatch.setattr(
        equilibre_service,
        "_query_doc_context_for_equilibre",
        lambda _: _ctx(nature="ESMS_PUBLIC_AUTONOME", any_cpom=True),
    )

    async def _c4_ko(*_, **__):
        return EquilibreReelInput(
            produits_tarif_saisis=Decimal("100"),
            produits_tarif_notifies=Decimal("100"),
            sincerite_commentee=True,
            capital_rembourse_via_emprunt=Decimal("0"),
            caf_n=Decimal("30"),
            capital_a_rembourser_n=Decimal("40"),  # CAF < IAF
            recettes_affectees=Decimal("10"),
            recettes_affectees_utilisees=Decimal("10"),
        )

    monkeypatch.setattr(equilibre_service, "load_equilibre_reel_inputs", _c4_ko)
    monkeypatch.setattr(equilibre_service, "_update_equilibre_atteint", lambda doc, v: None)
    out = await equilibre_service.apply_equilibre_check_for_document(COMPANY, DOC_ID)
    assert out.verdict == "NON"
