"""Route tests for Documents endpoints (L2 §4)."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import document as document_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import document_service
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

COMPANY = uuid4()
USER = uuid4()
EXERCICE_ID = uuid4()
DOC_ID = uuid4()
PARENT_EPRD_ID = uuid4()
BUILDER_AUTH = (USER, "builder", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


def _make_doc_dict(**overrides):
    base = {
        "id": DOC_ID,
        "company_id": COMPANY,
        "exercice_id": EXERCICE_ID,
        "type_document": "eprd",
        "cadre_version": "#EPRDHA-2026-01#",
        "parent_id": None,
        "statut": "brouillon",
        "periode_observation_debut": None,
        "periode_observation_fin": None,
        "transmis_at": None,
        "executoire_at": None,
        "transmis_par_user_id": None,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(document_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


def test_list_documents_200(client, monkeypatch):
    captured = {}

    async def _fake(company_id, **kwargs):
        captured.update(kwargs)
        from piilot_pack_compta_esms.models.document import DocumentRead

        return [DocumentRead.model_validate(_make_doc_dict())]

    monkeypatch.setattr(document_service, "list_documents", _fake)
    r = client.get("/plugins/compta_esms/documents?type=eprd&statut=brouillon&annee=2026")
    assert r.status_code == 200
    assert captured["type_document"] == "eprd"
    assert captured["statut"] == "brouillon"
    assert captured["annee"] == 2026


def test_list_documents_422_invalid_statut(client):
    """Literal validator rejects unknown statut → 422."""
    r = client.get("/plugins/compta_esms/documents?statut=invalid")
    assert r.status_code == 422


def test_create_document_201(client, monkeypatch):
    async def _fake(company_id, payload):
        from piilot_pack_compta_esms.models.document import DocumentRead

        return DocumentRead.model_validate(_make_doc_dict())

    monkeypatch.setattr(document_service, "create_document", _fake)
    r = client.post(
        "/plugins/compta_esms/documents",
        json={"exercice_id": str(EXERCICE_ID), "type_document": "eprd"},
    )
    assert r.status_code == 201, r.text


def test_create_document_422_dm_without_parent(client):
    """Model-level cross-field validator rejects DM without parent → 422."""
    r = client.post(
        "/plugins/compta_esms/documents",
        json={"exercice_id": str(EXERCICE_ID), "type_document": "dm"},
    )
    assert r.status_code == 422
    assert "parent_id" in r.text


def test_create_document_404_exercice_not_found(client, monkeypatch):
    async def _fake(company_id, payload):
        raise NotFoundError("nope", code="exercice_not_found_for_document_create")

    monkeypatch.setattr(document_service, "create_document", _fake)
    r = client.post(
        "/plugins/compta_esms/documents",
        json={"exercice_id": str(EXERCICE_ID), "type_document": "eprd"},
    )
    assert r.status_code == 404


def test_get_document_200(client, monkeypatch):
    async def _fake(doc_id):
        from piilot_pack_compta_esms.models.document import DocumentRead

        return DocumentRead.model_validate(_make_doc_dict())

    monkeypatch.setattr(document_service, "get_document", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}")
    assert r.status_code == 200


def test_get_document_404(client, monkeypatch):
    async def _fake(doc_id):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(document_service, "get_document", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}")
    assert r.status_code == 404


def test_patch_document_200(client, monkeypatch):
    async def _fake(doc_id, payload):
        from piilot_pack_compta_esms.models.document import DocumentRead

        return DocumentRead.model_validate(_make_doc_dict(cadre_version="#NEW#"))

    monkeypatch.setattr(document_service, "update_document", _fake)
    r = client.patch(
        f"/plugins/compta_esms/documents/{DOC_ID}",
        json={"cadre_version": "#NEW#"},
    )
    assert r.status_code == 200
    assert r.json()["cadre_version"] == "#NEW#"


def test_patch_document_422_unknown_field(client):
    """``extra='forbid'`` rejects statut mutation through PATCH."""
    r = client.patch(
        f"/plugins/compta_esms/documents/{DOC_ID}",
        json={"statut": "transmis"},
    )
    assert r.status_code == 422


def test_delete_document_204(client, monkeypatch):
    async def _fake(company_id, doc_id):
        return None

    monkeypatch.setattr(document_service, "delete_document", _fake)
    r = client.delete(f"/plugins/compta_esms/documents/{DOC_ID}")
    assert r.status_code == 204


def test_delete_document_409_not_brouillon(client, monkeypatch):
    async def _fake(company_id, doc_id):
        raise ConflictError("nope", code="document_not_brouillon")

    monkeypatch.setattr(document_service, "delete_document", _fake)
    r = client.delete(f"/plugins/compta_esms/documents/{DOC_ID}")
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "document_not_brouillon"


def test_clone_document_201(client, monkeypatch):
    async def _fake(company_id, source_id, payload, *, user_id=None):
        from piilot_pack_compta_esms.models.document import DocumentRead

        return DocumentRead.model_validate(
            _make_doc_dict(id=uuid4(), type_document="dm", parent_id=source_id)
        )

    monkeypatch.setattr(document_service, "clone_document", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{PARENT_EPRD_ID}/clone",
        json={"new_type": "dm"},
    )
    assert r.status_code == 201, r.text
    assert r.json()["type_document"] == "dm"
    assert r.json()["parent_id"] == str(PARENT_EPRD_ID)


def test_clone_document_422_invalid_new_type(client):
    """new_type must be 'dm' or 'ria'."""
    r = client.post(
        f"/plugins/compta_esms/documents/{PARENT_EPRD_ID}/clone",
        json={"new_type": "errd"},
    )
    assert r.status_code == 422


def test_clone_document_409_wrong_source_type(client, monkeypatch):
    async def _fake(company_id, source_id, payload, *, user_id=None):
        raise ConflictError("nope", code="clone_source_wrong_type")

    monkeypatch.setattr(document_service, "clone_document", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{PARENT_EPRD_ID}/clone",
        json={"new_type": "dm"},
    )
    assert r.status_code == 409


def test_user_cannot_post(client):
    from fastapi import HTTPException

    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.post(
        "/plugins/compta_esms/documents",
        json={"exercice_id": str(EXERCICE_ID), "type_document": "eprd"},
    )
    assert r.status_code == 403
