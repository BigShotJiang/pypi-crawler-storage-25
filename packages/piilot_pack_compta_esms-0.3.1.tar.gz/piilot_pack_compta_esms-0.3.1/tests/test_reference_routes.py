"""Route tests for the reference proxy endpoints (L2 §21.3 + bonus)."""

from __future__ import annotations

from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import reference as reference_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import reference_lookup

COMPANY = uuid4()
USER = uuid4()
USER_AUTH = (USER, "user", COMPANY)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(reference_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


def test_list_typologies_200(client, monkeypatch):
    async def _fake(slug):
        assert slug == reference_lookup.TYPOLOGIES_SLUG
        return [
            {"code": "EHPAD", "libelle": "Établissement hébergement..."},
            {"code": "MAS", "libelle": "Maison d'accueil spécialisée"},
        ]

    monkeypatch.setattr(reference_lookup, "list_all_rows", _fake)
    r = client.get("/plugins/compta_esms/references/typologies-essms")
    assert r.status_code == 200
    body = r.json()
    assert {row["code"] for row in body} == {"EHPAD", "MAS"}


def test_list_typologies_empty_when_catalog_not_synced(client, monkeypatch):
    """Empty list rather than a 404 — frontend renders 'sync pending'."""

    async def _fake(slug):
        return []

    monkeypatch.setattr(reference_lookup, "list_all_rows", _fake)
    r = client.get("/plugins/compta_esms/references/typologies-essms")
    assert r.status_code == 200
    assert r.json() == []


def test_list_conventions_collectives_200(client, monkeypatch):
    async def _fake(slug):
        assert slug == reference_lookup.CONVENTIONS_COLLECTIVES_SLUG
        return [{"code": "CCN51", "libelle": "Convention 51"}]

    monkeypatch.setattr(reference_lookup, "list_all_rows", _fake)
    r = client.get("/plugins/compta_esms/references/conventions-collectives-esms")
    assert r.status_code == 200
    assert r.json()[0]["code"] == "CCN51"


# ---------------------------------------------------------------------------
# L2 §21.4 — cnsa-fonctions proxy (PLT-44 KB core)
# ---------------------------------------------------------------------------


def test_list_cnsa_fonctions_no_filter_200(client, monkeypatch):
    """No filter — passes None filters to reference_lookup."""

    captured: dict = {}

    async def _fake(slug, *, filters=None, limit=None):
        captured["slug"] = slug
        captured["filters"] = filters
        return [
            {
                "code": "AS_ASG",
                "categorie_code": "ehpad_aja",
                "libelle": "Aide-soignant",
            },
        ]

    monkeypatch.setattr(reference_lookup, "list_filtered_rows", _fake)
    r = client.get("/plugins/compta_esms/references/cnsa-fonctions")
    assert r.status_code == 200
    assert captured["slug"] == reference_lookup.CNSA_FONCTIONS_SLUG
    assert captured["filters"] is None
    body = r.json()
    assert body[0]["code"] == "AS_ASG"


def test_list_cnsa_fonctions_with_type_etablissement(client, monkeypatch):
    """``type_etablissement`` is mapped to ``categorie_code`` filter."""

    captured: dict = {}

    async def _fake(slug, *, filters=None, limit=None):
        captured["filters"] = filters
        return []

    monkeypatch.setattr(reference_lookup, "list_filtered_rows", _fake)
    r = client.get("/plugins/compta_esms/references/cnsa-fonctions?type_etablissement=ehpad_aja")
    assert r.status_code == 200
    assert captured["filters"] == {"categorie_code": "ehpad_aja"}


def test_list_cnsa_fonctions_empty_when_kb_not_synced(client, monkeypatch):
    """KB PLT-44 not yet seeded (v0.4) → empty list (not 404)."""

    async def _fake(slug, *, filters=None, limit=None):
        return []

    monkeypatch.setattr(reference_lookup, "list_filtered_rows", _fake)
    r = client.get("/plugins/compta_esms/references/cnsa-fonctions")
    assert r.status_code == 200
    assert r.json() == []


def test_list_cnsa_fonctions_invalid_type_etablissement_422(client):
    """Invalid ``type_etablissement`` rejected before the lookup."""

    r = client.get("/plugins/compta_esms/references/cnsa-fonctions?type_etablissement=bogus")
    assert r.status_code == 422
    detail = r.json()["detail"]
    assert detail["code"] == "type_etablissement_invalid"


def test_list_cnsa_fonctions_all_4_categories_accepted(client, monkeypatch):
    async def _fake(slug, *, filters=None, limit=None):
        return []

    monkeypatch.setattr(reference_lookup, "list_filtered_rows", _fake)
    for cat in ("ehpad_aja", "fam_samsah", "sad_spasad", "autre_essms"):
        r = client.get(f"/plugins/compta_esms/references/cnsa-fonctions?type_etablissement={cat}")
        assert r.status_code == 200, cat


# ---------------------------------------------------------------------------
# pcg_to_m22bis + presets-outils (L2 §7bis.5)
# ---------------------------------------------------------------------------


def test_lookup_pcg_to_m22bis_identity(client):
    """60611 (Eau) is shipped in the wheel — no mock needed."""
    r = client.get("/plugins/compta_esms/references/pcg-to-m22bis?source_account=60611")
    assert r.status_code == 200
    body = r.json()
    assert len(body) == 1
    assert body[0]["target_m22bis_account"] == "60611"


def test_lookup_pcg_to_m22bis_empty_when_no_account(client):
    """No ``source_account`` query param → empty list (not an error)."""
    r = client.get("/plugins/compta_esms/references/pcg-to-m22bis")
    assert r.status_code == 200
    assert r.json() == []


def test_search_pcg_to_m22bis(client):
    r = client.get("/plugins/compta_esms/references/pcg-to-m22bis/search?q=eau")
    assert r.status_code == 200
    accounts = {row["source_account"] for row in r.json()}
    assert "60611" in accounts


def test_search_pcg_to_m22bis_caps_limit(client):
    """The route caps ``limit`` to 100 even if the client asks for more."""
    r = client.get("/plugins/compta_esms/references/pcg-to-m22bis/search?class_num=6&limit=9999")
    assert r.status_code == 200
    assert len(r.json()) <= 100


def test_list_presets_outils(client):
    r = client.get("/plugins/compta_esms/references/presets-outils")
    assert r.status_code == 200
    names = {p["name"] for p in r.json()}
    assert names == {"Pennylane", "Sage", "EBP", "Cegid"}


def test_get_preset_pennylane(client):
    r = client.get("/plugins/compta_esms/references/presets-outils/Pennylane")
    assert r.status_code == 200
    body = r.json()
    assert body["name"] == "Pennylane"
    assert "mappings" in body


def test_get_preset_unknown_404(client):
    r = client.get("/plugins/compta_esms/references/presets-outils/InvalidOutil")
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "preset_not_found"
