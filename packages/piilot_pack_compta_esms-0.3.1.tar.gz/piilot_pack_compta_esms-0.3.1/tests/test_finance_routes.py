"""Tests §R Q10 — routes finance/* :compute.

3 endpoints stateless qui exposent la biblio §I (`services/finance/*`)
via HTTP REST :

* POST /finance/forfait-dependance:compute
* POST /finance/gmp-departemental:compute
* POST /finance/valeur-point-gir:compute

Tests :
- 200 happy path pour chaque endpoint
- Validation Pydantic (`extra='forbid'` + bornes Field)
- Branche modulation TO appliquée vs skip (forfait)
- Liste vide / Σ(HP)=0 (GMP dégénéré)
- TVA TTC privé commercial (valeur point GIR)
- Clapet anti-retour R.314-175 (valeur point GIR)
"""

from __future__ import annotations

from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import _limiter as limiter_module
from piilot_pack_compta_esms.routes import finance as finance_routes

COMPANY = uuid4()
USER = uuid4()
USER_AUTH = (USER, "user", COMPANY)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter_module.limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(finance_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    return app


# ---------------------------------------------------------------------------
# POST /finance/forfait-dependance:compute
# ---------------------------------------------------------------------------


def test_forfait_dependance_compute_no_modulation(app):
    """Pas de TO_realise → modulation skipped."""
    client = TestClient(app)
    payload = {
        "forfait_global_dependance": "1000000",
        "montant_participations_residents": "200000",
        "to_previsionnel": "0.95",
        "montant_hors_departement": "50000",
        "apply_modulation": False,
        "annee": 2025,
    }
    response = client.post(
        "/plugins/compta_esms/finance/forfait-dependance:compute",
        json=payload,
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert "forfait_cd_implantation_brut" in body
    assert "forfait_cd_implantation_module" in body
    assert body["modulation_appliquee"] is False
    assert body["abattement_pct"] == "0"


def test_forfait_dependance_compute_with_modulation(app):
    """TO_realise sous le seuil → modulation appliquée (TO_realise < 95%)."""
    client = TestClient(app)
    payload = {
        "forfait_global_dependance": "1000000",
        "montant_participations_residents": "200000",
        "to_previsionnel": "0.95",
        "montant_hors_departement": "50000",
        "apply_modulation": True,
        "to_realise": "0.85",
        "seuil_modulation_pct": "95",
        "annee": 2025,
    }
    response = client.post(
        "/plugins/compta_esms/finance/forfait-dependance:compute",
        json=payload,
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["modulation_appliquee"] is True
    # abattement_pct = (0.95 - 0.85) / 2 × 100 = 5
    assert Decimal(body["abattement_pct"]) == Decimal("5.00")


def test_forfait_dependance_compute_to_above_plafond(app):
    """TO réalisé >= 95% → pas de modulation (plafond S03 p.22)."""
    client = TestClient(app)
    payload = {
        "forfait_global_dependance": "1000000",
        "montant_participations_residents": "0",
        "to_previsionnel": "0.95",
        "montant_hors_departement": "0",
        "apply_modulation": True,
        "to_realise": "0.96",
        "seuil_modulation_pct": "95",
        "annee": 2025,
    }
    response = client.post(
        "/plugins/compta_esms/finance/forfait-dependance:compute",
        json=payload,
    )
    assert response.status_code == 200
    assert response.json()["modulation_appliquee"] is False


def test_forfait_dependance_rejects_unknown_field(app):
    """Pydantic `extra='forbid'` rejette un champ inconnu (422)."""
    client = TestClient(app)
    payload = {
        "forfait_global_dependance": "1000000",
        "montant_participations_residents": "0",
        "to_previsionnel": "0.95",
        "montant_hors_departement": "0",
        "annee": 2025,
        "champ_inconnu": "rejected",
    }
    response = client.post(
        "/plugins/compta_esms/finance/forfait-dependance:compute",
        json=payload,
    )
    assert response.status_code == 422


def test_forfait_dependance_rejects_to_out_of_range(app):
    """`to_previsionnel` Field(ge=0, le=1) → 422 si hors borne."""
    client = TestClient(app)
    payload = {
        "forfait_global_dependance": "1000000",
        "montant_participations_residents": "0",
        "to_previsionnel": "1.5",  # > 1 → rejet
        "montant_hors_departement": "0",
        "annee": 2025,
    }
    response = client.post(
        "/plugins/compta_esms/finance/forfait-dependance:compute",
        json=payload,
    )
    assert response.status_code == 422


# ---------------------------------------------------------------------------
# POST /finance/gmp-departemental:compute
# ---------------------------------------------------------------------------


def test_gmp_departemental_compute_happy_path(app):
    """3 EHPAD → GMP = Σ(points × HP) / Σ(HP)."""
    client = TestClient(app)
    payload = {
        "ehpads": [
            {"points_gir": "700", "capacite_hp": "80"},
            {"points_gir": "750", "capacite_hp": "60"},
            {"points_gir": "650", "capacite_hp": "100"},
        ],
    }
    response = client.post(
        "/plugins/compta_esms/finance/gmp-departemental:compute",
        json=payload,
    )
    assert response.status_code == 200, response.text
    body = response.json()
    # (700*80 + 750*60 + 650*100) / (80+60+100) = 166000 / 240 = 691.666...
    expected = (Decimal("700") * 80 + Decimal("750") * 60 + Decimal("650") * 100) / Decimal("240")
    assert abs(Decimal(body["gmp"]) - expected) < Decimal("0.01")
    assert body["nb_ehpads"] == 3


def test_gmp_departemental_empty_list_returns_zero(app):
    """Liste vide → gmp=0, nb_ehpads=0 (cas dégénéré)."""
    client = TestClient(app)
    response = client.post(
        "/plugins/compta_esms/finance/gmp-departemental:compute",
        json={"ehpads": []},
    )
    assert response.status_code == 200
    body = response.json()
    assert Decimal(body["gmp"]) == Decimal("0")
    assert body["nb_ehpads"] == 0


def test_gmp_departemental_zero_hp_returns_zero(app):
    """Σ(HP)=0 → gmp=0 (évite division par zéro)."""
    client = TestClient(app)
    payload = {
        "ehpads": [
            {"points_gir": "700", "capacite_hp": "0"},
        ],
    }
    response = client.post(
        "/plugins/compta_esms/finance/gmp-departemental:compute",
        json=payload,
    )
    assert response.status_code == 200
    assert Decimal(response.json()["gmp"]) == Decimal("0")


# ---------------------------------------------------------------------------
# POST /finance/valeur-point-gir:compute
# ---------------------------------------------------------------------------


def test_valeur_point_gir_happy_path(app, monkeypatch):
    """Lookup KB ref → valeur retournée + flag clapet."""

    async def _fake_clapet(code, annee):
        return Decimal("13.20"), False, annee

    async def _fake_brute(code, annee):
        return Decimal("13.20")

    from piilot_pack_compta_esms.services.finance import valeur_point_gir_resolver

    monkeypatch.setattr(
        valeur_point_gir_resolver.reference_lookup,
        "valeur_point_gir_with_clapet",
        _fake_clapet,
    )
    monkeypatch.setattr(
        valeur_point_gir_resolver.reference_lookup,
        "valeur_point_gir",
        _fake_brute,
    )

    client = TestClient(app)
    response = client.post(
        "/plugins/compta_esms/finance/valeur-point-gir:compute",
        json={
            "code_departement": "75",
            "annee": 2025,
            "est_prive_commercial": False,
        },
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["code_departement"] == "75"
    assert body["annee"] == 2025
    assert Decimal(body["valeur"]) == Decimal("13.20")
    assert Decimal(body["valeur_brute"]) == Decimal("13.20")
    assert body["clapet_applique"] is False
    assert body["est_prive_commercial"] is False


def test_valeur_point_gir_tva_prive_commercial(app, monkeypatch):
    """EHPAD privé commercial → multiplie par 1,055 (TTC)."""

    async def _fake_clapet(code, annee):
        return Decimal("13.00"), False, annee

    async def _fake_brute(code, annee):
        return Decimal("13.00")

    from piilot_pack_compta_esms.services.finance import valeur_point_gir_resolver

    monkeypatch.setattr(
        valeur_point_gir_resolver.reference_lookup,
        "valeur_point_gir_with_clapet",
        _fake_clapet,
    )
    monkeypatch.setattr(
        valeur_point_gir_resolver.reference_lookup,
        "valeur_point_gir",
        _fake_brute,
    )

    client = TestClient(app)
    response = client.post(
        "/plugins/compta_esms/finance/valeur-point-gir:compute",
        json={
            "code_departement": "75",
            "annee": 2025,
            "est_prive_commercial": True,
        },
    )
    assert response.status_code == 200
    body = response.json()
    # 13.00 × 1.055 = 13.715
    assert Decimal(body["valeur"]) == Decimal("13.715")
    assert Decimal(body["valeur_brute"]) == Decimal("13.00")
    assert body["est_prive_commercial"] is True


def test_valeur_point_gir_clapet_anti_retour_applied(app, monkeypatch):
    """KB ref a valeur(N) < valeur(N-1) → service retourne N-1 + flag."""

    async def _fake_clapet(code, annee):
        # valeur(N-1) = 13.50, valeur(N) = 13.20 → clapet renvoie 13.50
        return Decimal("13.50"), True, annee - 1

    async def _fake_brute(code, annee):
        return Decimal("13.20")

    from piilot_pack_compta_esms.services.finance import valeur_point_gir_resolver

    monkeypatch.setattr(
        valeur_point_gir_resolver.reference_lookup,
        "valeur_point_gir_with_clapet",
        _fake_clapet,
    )
    monkeypatch.setattr(
        valeur_point_gir_resolver.reference_lookup,
        "valeur_point_gir",
        _fake_brute,
    )

    client = TestClient(app)
    response = client.post(
        "/plugins/compta_esms/finance/valeur-point-gir:compute",
        json={
            "code_departement": "75",
            "annee": 2025,
            "est_prive_commercial": False,
        },
    )
    assert response.status_code == 200
    body = response.json()
    assert Decimal(body["valeur"]) == Decimal("13.50")
    assert Decimal(body["valeur_brute"]) == Decimal("13.20")
    assert body["clapet_applique"] is True
    assert body["fallback_annee"] == 2024


def test_valeur_point_gir_rejects_invalid_code_dept(app):
    """`code_departement` Field(min_length=2, max_length=3) → 422."""
    client = TestClient(app)
    response = client.post(
        "/plugins/compta_esms/finance/valeur-point-gir:compute",
        json={
            "code_departement": "7",  # < 2 chars
            "annee": 2025,
            "est_prive_commercial": False,
        },
    )
    assert response.status_code == 422


# ---------------------------------------------------------------------------
# Wiring smoke — router monté + 3 endpoints exposés
# ---------------------------------------------------------------------------


def test_wire_includes_finance_router():
    """Le routes/wire.py exporte bien le finance router."""
    from piilot_pack_compta_esms.routes import wire as wire_module

    # `finance_routes` est importé dans le module wire — sanity check
    assert hasattr(wire_module, "finance_routes")
    assert wire_module.finance_routes.router.prefix == "/finance"
    # 3 endpoints sous /finance
    routes = wire_module.finance_routes.router.routes
    paths = sorted(r.path for r in routes if hasattr(r, "path"))
    assert "/finance/forfait-dependance:compute" in paths
    assert "/finance/gmp-departemental:compute" in paths
    assert "/finance/valeur-point-gir:compute" in paths
