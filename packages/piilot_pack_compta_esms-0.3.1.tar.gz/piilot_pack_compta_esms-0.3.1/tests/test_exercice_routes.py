"""Route tests for Exercice endpoints (L2 §3.x)."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import exercice as exercice_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import exercice_service
from piilot_pack_compta_esms.services.errors import ConflictError, NotFoundError

COMPANY = uuid4()
USER = uuid4()
OG_ID = uuid4()
EXERCICE_ID = uuid4()
BUILDER_AUTH = (USER, "builder", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


def _make_exercice_dict(**overrides):
    base = {
        "id": EXERCICE_ID,
        "company_id": COMPANY,
        "og_id": OG_ID,
        "annee": 2026,
        "millesime_m22bis": "2025-2026",
        "created_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(exercice_routes.router_under_og, prefix="/plugins/compta_esms")
    app.include_router(exercice_routes.router_flat, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


def test_list_exercices_200(client, monkeypatch):
    async def _fake(og_id):
        from piilot_pack_compta_esms.models.exercice import ExerciceRead

        return [
            ExerciceRead.model_validate(_make_exercice_dict(annee=2026)),
            ExerciceRead.model_validate(_make_exercice_dict(annee=2025)),
        ]

    monkeypatch.setattr(exercice_service, "list_exercices", _fake)
    r = client.get(f"/plugins/compta_esms/orgs/{OG_ID}/exercices")
    assert r.status_code == 200
    body = r.json()
    assert [e["annee"] for e in body] == [2026, 2025]


def test_create_exercice_201(client, monkeypatch):
    async def _fake(company_id, og_id, payload):
        from piilot_pack_compta_esms.models.exercice import ExerciceRead

        return ExerciceRead.model_validate(_make_exercice_dict(annee=payload.annee))

    monkeypatch.setattr(exercice_service, "create_exercice", _fake)
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/exercices",
        json={"annee": 2026},
    )
    assert r.status_code == 201, r.text
    assert r.json()["annee"] == 2026


def test_create_exercice_422_extra_field(client):
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/exercices",
        json={"annee": 2026, "unknown": "x"},
    )
    assert r.status_code == 422


def test_create_exercice_409_year_taken(client, monkeypatch):
    async def _fake(company_id, og_id, payload):
        raise ConflictError("dup", code="exercice_annee_taken")

    monkeypatch.setattr(exercice_service, "create_exercice", _fake)
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/exercices",
        json={"annee": 2026},
    )
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "exercice_annee_taken"


def test_create_exercice_409_year_out_of_window(client, monkeypatch):
    async def _fake(company_id, og_id, payload):
        raise ConflictError("bad", code="exercice_annee_out_of_window")

    monkeypatch.setattr(exercice_service, "create_exercice", _fake)
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/exercices",
        json={"annee": 2099},
    )
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "exercice_annee_out_of_window"


def test_create_exercice_404_unknown_og(client, monkeypatch):
    async def _fake(company_id, og_id, payload):
        raise NotFoundError("nope", code="og_not_found_for_exercice_create")

    monkeypatch.setattr(exercice_service, "create_exercice", _fake)
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/exercices",
        json={"annee": 2026},
    )
    assert r.status_code == 404


def test_get_exercice_200(client, monkeypatch):
    async def _fake(exercice_id):
        from piilot_pack_compta_esms.models.exercice import ExerciceRead

        return ExerciceRead.model_validate(_make_exercice_dict())

    monkeypatch.setattr(exercice_service, "get_exercice", _fake)
    r = client.get(f"/plugins/compta_esms/exercices/{EXERCICE_ID}")
    assert r.status_code == 200
    assert r.json()["millesime_m22bis"] == "2025-2026"


def test_get_exercice_404(client, monkeypatch):
    async def _fake(exercice_id):
        raise NotFoundError("nope", code="exercice_not_found")

    monkeypatch.setattr(exercice_service, "get_exercice", _fake)
    r = client.get(f"/plugins/compta_esms/exercices/{EXERCICE_ID}")
    assert r.status_code == 404


def test_user_cannot_post(client):
    """Builder is required for POST — plain user gets 403."""
    from fastapi import HTTPException

    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.post(
        f"/plugins/compta_esms/orgs/{OG_ID}/exercices",
        json={"annee": 2026},
    )
    assert r.status_code == 403
