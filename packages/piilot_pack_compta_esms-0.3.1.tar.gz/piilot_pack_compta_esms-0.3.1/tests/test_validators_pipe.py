"""Tests transverses D-075 — caractère ``|`` interdit.

Couvre le helper :func:`reject_pipe_char` directement + sa branche sur
les models qui l'utilisent (échantillon des 10+ models patchés)."""

from __future__ import annotations

from uuid import uuid4

import pytest
from pydantic import ValidationError

from piilot_pack_compta_esms.services.validators import reject_pipe_char

# ---------------------------------------------------------------------------
# Unit — reject_pipe_char direct
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "value",
    [
        None,
        "",
        "valid string",
        "with space and digits 42",
        "avec accents éàü œ",
        "with-dash_underscore.dot",
    ],
)
def test_reject_pipe_char_passes_on_clean(value):
    assert reject_pipe_char(value) == value


@pytest.mark.parametrize(
    "value",
    [
        "|",
        "before|after",
        "|leading",
        "trailing|",
        "FAM Saint-Joseph | 75 places",
        "multi|||pipes",
    ],
)
def test_reject_pipe_char_raises_on_pipe(value):
    with pytest.raises(ValueError, match="pipe_char_forbidden"):
        reject_pipe_char(value)


# ---------------------------------------------------------------------------
# Integration — branchement dans models critiques
# ---------------------------------------------------------------------------


def test_og_create_rejects_pipe_in_raison_sociale():
    from piilot_pack_compta_esms.models.og import OGCreate

    with pytest.raises(ValidationError):
        OGCreate(
            finess_juridique="123456789",
            raison_sociale="Asso | XYZ",  # KO
            nature_juridique="PRIVE_NON_LUCRATIF",
            plan_comptable="PNL",
        )


def test_og_create_accepts_clean_raison_sociale():
    from piilot_pack_compta_esms.models.og import OGCreate

    og = OGCreate(
        finess_juridique="123456789",
        raison_sociale="Asso XYZ",
        nature_juridique="PRIVE_NON_LUCRATIF",
        plan_comptable="PNL",
    )
    assert og.raison_sociale == "Asso XYZ"


def test_etablissement_create_rejects_pipe_in_adresse():
    from piilot_pack_compta_esms.models.etablissement import EtablissementCreate

    with pytest.raises(ValidationError):
        EtablissementCreate(
            og_id=uuid4(),
            finess_ets="987654321",
            raison_sociale="EHPAD Test",
            typologie="ehpad",
            adresse="3 rue X | étage 2",  # KO
        )


def test_cr_create_rejects_pipe_in_denomination():
    from piilot_pack_compta_esms.models.cr import CrCreate

    with pytest.raises(ValidationError):
        CrCreate(cr_type="CRPP", denomination="CRPP | section A")


def test_crp_ligne_create_rejects_pipe_in_compte_label():
    from piilot_pack_compta_esms.models.crp_ligne import CrpLigneCreate

    with pytest.raises(ValidationError):
        CrpLigneCreate(
            groupe="G1",
            nature="charge",
            compte_m22bis="6011",
            compte_label="Achats | non-stockés",
        )


def test_workflow_transition_rejects_pipe_in_motif():
    from piilot_pack_compta_esms.models.workflow import TransitionRequest

    with pytest.raises(ValidationError):
        TransitionRequest(
            action="reject",
            autorite="ars",
            motif="Recettes | tarifs incohérentes",
        )


def test_workflow_transition_accepts_clean_motif():
    from piilot_pack_compta_esms.models.workflow import TransitionRequest

    req = TransitionRequest(
        action="reject",
        autorite="ars",
        motif="Recettes tarifs incohérentes",
    )
    assert req.motif == "Recettes tarifs incohérentes"
