"""Route tests for CR endpoints (L2 §5)."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.routes import cr as cr_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import cr_service
from piilot_pack_compta_esms.services.errors import NotFoundError

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
CR_ID = uuid4()
ETS_ID = uuid4()
BUILDER_AUTH = (USER, "builder", COMPANY)
USER_AUTH = (USER, "user", COMPANY)


def _make_cr_dict(**overrides):
    base = {
        "id": CR_ID,
        "company_id": COMPANY,
        "document_id": DOC_ID,
        "etablissement_id": None,
        "cr_type": "CRPP",
        "cr_variante": "non_soumis_equil",
        "cr_identifiant": None,
        "denomination": "CRPP - EPRD 2026",
        "finess_rattachement": None,
        "capacite_installee": None,
        "amplitude_ouverture": None,
        "ventilation": "simple",
        "ordre": 0,
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return base


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(cr_routes.router_under_doc, prefix="/plugins/compta_esms")
    app.include_router(cr_routes.router_flat, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


def test_list_crs_200(client, monkeypatch):
    async def _fake(doc_id):
        from piilot_pack_compta_esms.models.cr import CrRead

        return [
            CrRead.model_validate(_make_cr_dict()),
            CrRead.model_validate(_make_cr_dict(cr_type="CRPA", ordre=1)),
        ]

    monkeypatch.setattr(cr_service, "list_crs", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/crs")
    assert r.status_code == 200
    assert [c["cr_type"] for c in r.json()] == ["CRPP", "CRPA"]


def test_create_cr_201(client, monkeypatch):
    async def _fake(company_id, doc_id, payload):
        from piilot_pack_compta_esms.models.cr import CrRead

        return CrRead.model_validate(
            _make_cr_dict(cr_type=payload.cr_type, denomination=payload.denomination)
        )

    monkeypatch.setattr(cr_service, "create_cr", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/crs",
        json={"cr_type": "CRPA", "denomination": "Extra"},
    )
    assert r.status_code == 201, r.text
    assert r.json()["cr_type"] == "CRPA"


def test_create_cr_422_invalid_cr_type(client):
    """Literal CrType rejects unknown values."""
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/crs",
        json={"cr_type": "UNKNOWN", "denomination": "X"},
    )
    assert r.status_code == 422


def test_create_cr_422_missing_denomination(client):
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/crs",
        json={"cr_type": "CRPP"},
    )
    assert r.status_code == 422


def test_create_cr_404_document_not_found(client, monkeypatch):
    async def _fake(company_id, doc_id, payload):
        raise NotFoundError("nope", code="document_not_found_for_cr_create")

    monkeypatch.setattr(cr_service, "create_cr", _fake)
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/crs",
        json={"cr_type": "CRPA", "denomination": "X"},
    )
    assert r.status_code == 404


def test_patch_cr_200(client, monkeypatch):
    async def _fake(company_id, cr_id, payload):
        from piilot_pack_compta_esms.models.cr import CrRead

        return CrRead.model_validate(_make_cr_dict(denomination="Renamed"))

    monkeypatch.setattr(cr_service, "update_cr", _fake)
    r = client.patch(
        f"/plugins/compta_esms/crs/{CR_ID}",
        json={"denomination": "Renamed"},
    )
    assert r.status_code == 200
    assert r.json()["denomination"] == "Renamed"


def test_patch_cr_422_cr_type_forbidden(client):
    """cr_type is locked at create — PATCH attempt → 422."""
    r = client.patch(
        f"/plugins/compta_esms/crs/{CR_ID}",
        json={"cr_type": "CRPA"},
    )
    assert r.status_code == 422


def test_patch_cr_422_unknown_field(client):
    r = client.patch(
        f"/plugins/compta_esms/crs/{CR_ID}",
        json={"document_id": str(uuid4())},
    )
    assert r.status_code == 422


def test_patch_cr_404(client, monkeypatch):
    async def _fake(company_id, cr_id, payload):
        raise NotFoundError("nope", code="cr_not_found")

    monkeypatch.setattr(cr_service, "update_cr", _fake)
    r = client.patch(
        f"/plugins/compta_esms/crs/{CR_ID}",
        json={"denomination": "X"},
    )
    assert r.status_code == 404


def test_delete_cr_204(client, monkeypatch):
    async def _fake(company_id, cr_id):
        return None

    monkeypatch.setattr(cr_service, "delete_cr", _fake)
    r = client.delete(f"/plugins/compta_esms/crs/{CR_ID}")
    assert r.status_code == 204


def test_delete_cr_403_cross_company(client, monkeypatch):
    from piilot_pack_compta_esms.services.errors import CrossCompanyError

    async def _fake(company_id, cr_id):
        raise CrossCompanyError("nope", code="cr_cross_company")

    monkeypatch.setattr(cr_service, "delete_cr", _fake)
    r = client.delete(f"/plugins/compta_esms/crs/{CR_ID}")
    assert r.status_code == 403


def test_reorder_cr_200(client, monkeypatch):
    async def _fake(company_id, cr_id, payload):
        from piilot_pack_compta_esms.models.cr import CrRead

        return CrRead.model_validate(_make_cr_dict(ordre=payload.ordre))

    monkeypatch.setattr(cr_service, "reorder_cr", _fake)
    r = client.post(
        f"/plugins/compta_esms/crs/{CR_ID}/reorder",
        json={"ordre": 5},
    )
    assert r.status_code == 200
    assert r.json()["ordre"] == 5


def test_reorder_cr_422_negative(client):
    """ordre must be ge=0."""
    r = client.post(
        f"/plugins/compta_esms/crs/{CR_ID}/reorder",
        json={"ordre": -1},
    )
    assert r.status_code == 422


def test_reorder_cr_422_missing_ordre(client):
    r = client.post(
        f"/plugins/compta_esms/crs/{CR_ID}/reorder",
        json={},
    )
    assert r.status_code == 422


def test_user_cannot_post(client):
    from fastapi import HTTPException

    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.post(
        f"/plugins/compta_esms/documents/{DOC_ID}/crs",
        json={"cr_type": "CRPA", "denomination": "X"},
    )
    assert r.status_code == 403
