"""Tests §Z — 13 contrôles TER computables (C-101 → C-113).

Couvre les cas happy + edge :

* Aucune ligne TER → tous NA
* ETPR > 0 ok / = 0 ko (C-101)
* ETPR < 1000 ok / ≥ 1000 ko (C-102)
* ETPT > 0 ok / = 0 ko (C-103)
* ETPT < 1000 ok / ≥ 1000 ko (C-104)
* Σ par section = global ok / != ko (C-105)
* Fonction AS/AMP/AES — match heuristique (C-106 + C-110)
* section_imputation='forfait_soins' (C-107 + C-108)
* Σ remunerations par section = global (C-111)
* Écart ±10% ETPR (C-112) + rémunérations (C-113)
* Squelette NA renvoie message standard
"""

from __future__ import annotations

from decimal import Decimal
from uuid import uuid4

import pytest

from piilot_pack_compta_esms.controls import c_computables, c_skeletons
from piilot_pack_compta_esms.controls._base import ControlContext

COMPANY = uuid4()
DOC_ID = uuid4()


def _ctx():
    return ControlContext(
        document_id=DOC_ID,
        company_id=COMPANY,
        document={"id": DOC_ID, "company_id": COMPANY, "type_document": "errd"},
    )


def _ter(**overrides):
    base = {
        "type_tableau": "TER",
        "etpr_prevus": None,
        "etpt_prevus": None,
        "etpr_realises": Decimal("10"),
        "etpt_realises": Decimal("10"),
        "remunerations_prevues": None,
        "remunerations_realisees": Decimal("500000"),
        "section_imputation": "hebergement",
        "fonction": "infirmier",
    }
    base.update(overrides)
    return base


@pytest.fixture(autouse=True)
def _patch_run_in_thread(monkeypatch):
    async def _passthrough(fn, *args, **kwargs):
        return fn(*args, **kwargs)

    monkeypatch.setattr(
        "piilot_pack_compta_esms.controls.c_computables.run_in_thread",
        _passthrough,
    )


# ---------------------------------------------------------------------------
# Empty fixture
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_101_no_lines_na(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(tper_ter_repo, "list_by_filter", lambda _: [])
    r = await c_computables.c_101(_ctx())
    assert r.statut == "na"


# ---------------------------------------------------------------------------
# C-101 / C-102 ETPR
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_101_etpr_positive_ok(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo, "list_by_filter", lambda _: [_ter(etpr_realises=Decimal("50"))]
    )
    r = await c_computables.c_101(_ctx())
    assert r.statut == "ok"


@pytest.mark.asyncio
async def test_c_101_etpr_zero_ko(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo, "list_by_filter", lambda _: [_ter(etpr_realises=Decimal("0"))]
    )
    r = await c_computables.c_101(_ctx())
    assert r.statut == "ko"


@pytest.mark.asyncio
async def test_c_102_etpr_below_1000_ok(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo, "list_by_filter", lambda _: [_ter(etpr_realises=Decimal("500"))]
    )
    r = await c_computables.c_102(_ctx())
    assert r.statut == "ok"


@pytest.mark.asyncio
async def test_c_102_etpr_above_1000_ko(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo, "list_by_filter", lambda _: [_ter(etpr_realises=Decimal("1500"))]
    )
    r = await c_computables.c_102(_ctx())
    assert r.statut == "ko"


# ---------------------------------------------------------------------------
# C-103 / C-104 ETPT
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_103_etpt_positive_ok(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo, "list_by_filter", lambda _: [_ter(etpt_realises=Decimal("50"))]
    )
    r = await c_computables.c_103(_ctx())
    assert r.statut == "ok"


@pytest.mark.asyncio
async def test_c_104_etpt_above_1000_ko(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo, "list_by_filter", lambda _: [_ter(etpt_realises=Decimal("1200"))]
    )
    r = await c_computables.c_104(_ctx())
    assert r.statut == "ko"


# ---------------------------------------------------------------------------
# C-105 Σ ETPR par section = global
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_105_sum_sections_match_ok(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    rows = [
        _ter(etpr_realises=Decimal("30"), section_imputation="hebergement"),
        _ter(etpr_realises=Decimal("20"), section_imputation="dependance"),
    ]
    monkeypatch.setattr(tper_ter_repo, "list_by_filter", lambda _: rows)
    r = await c_computables.c_105(_ctx())
    assert r.statut == "ok"


@pytest.mark.asyncio
async def test_c_105_sum_sections_mismatch_ko(monkeypatch) -> None:
    """Une ligne avec section_imputation=None ne s'agrège pas → écart."""
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    rows = [
        _ter(etpr_realises=Decimal("30"), section_imputation="hebergement"),
        _ter(etpr_realises=Decimal("20"), section_imputation=None),  # absente du Σ
    ]
    monkeypatch.setattr(tper_ter_repo, "list_by_filter", lambda _: rows)
    r = await c_computables.c_105(_ctx())
    assert r.statut == "ko"


# ---------------------------------------------------------------------------
# C-106 AS-AMP-AES filter
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_106_no_as_amp_aes_na(monkeypatch) -> None:
    """Si pas de fonction AS/AMP/AES → na."""
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(tper_ter_repo, "list_by_filter", lambda _: [_ter(fonction="infirmier")])
    r = await c_computables.c_106(_ctx())
    assert r.statut == "na"


@pytest.mark.asyncio
async def test_c_106_as_function_match_ok(monkeypatch) -> None:
    """Fonction contient 'AS' → match → vérif > 0."""
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo,
        "list_by_filter",
        lambda _: [_ter(fonction="AS aide-soignant", etpr_realises=Decimal("10"))],
    )
    r = await c_computables.c_106(_ctx())
    assert r.statut == "ok"


# ---------------------------------------------------------------------------
# C-107 / C-108 forfait_soins
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_107_no_forfait_soins_na(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo,
        "list_by_filter",
        lambda _: [_ter(section_imputation="hebergement")],
    )
    r = await c_computables.c_107(_ctx())
    assert r.statut == "na"


@pytest.mark.asyncio
async def test_c_108_forfait_le_global_ok(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    rows = [
        _ter(etpr_realises=Decimal("30"), section_imputation="hebergement"),
        _ter(etpr_realises=Decimal("10"), section_imputation="forfait_soins"),
    ]
    monkeypatch.setattr(tper_ter_repo, "list_by_filter", lambda _: rows)
    r = await c_computables.c_108(_ctx())
    assert r.statut == "ok"


# ---------------------------------------------------------------------------
# C-109 / C-110 rémunérations
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_109_remunerations_positive_ok(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo,
        "list_by_filter",
        lambda _: [_ter(remunerations_realisees=Decimal("100000"))],
    )
    r = await c_computables.c_109(_ctx())
    assert r.statut == "ok"


@pytest.mark.asyncio
async def test_c_109_remunerations_zero_ko(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo,
        "list_by_filter",
        lambda _: [_ter(remunerations_realisees=Decimal("0"))],
    )
    r = await c_computables.c_109(_ctx())
    assert r.statut == "ko"


# ---------------------------------------------------------------------------
# C-112 / C-113 écarts ±10%
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_c_112_ecart_below_10pct_ok(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo,
        "list_by_filter",
        lambda _: [_ter(etpr_prevus=Decimal("100"), etpr_realises=Decimal("105"))],  # 5%
    )
    r = await c_computables.c_112(_ctx())
    assert r.statut == "ok"


@pytest.mark.asyncio
async def test_c_112_ecart_above_10pct_ko(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo,
        "list_by_filter",
        lambda _: [_ter(etpr_prevus=Decimal("100"), etpr_realises=Decimal("130"))],  # 30%
    )
    r = await c_computables.c_112(_ctx())
    assert r.statut == "ko"


@pytest.mark.asyncio
async def test_c_112_prevu_zero_na(monkeypatch) -> None:
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo,
        "list_by_filter",
        lambda _: [_ter(etpr_prevus=None, etpr_realises=Decimal("10"))],
    )
    r = await c_computables.c_112(_ctx())
    assert r.statut == "na"


@pytest.mark.asyncio
async def test_c_113_remuneration_ecart(monkeypatch) -> None:
    """Symétrique de C-112 sur rémunérations."""
    from piilot_pack_compta_esms.repositories import tper_ter_repo

    monkeypatch.setattr(
        tper_ter_repo,
        "list_by_filter",
        lambda _: [
            _ter(
                remunerations_prevues=Decimal("100000"),
                remunerations_realisees=Decimal("105000"),
            )
        ],
    )
    r = await c_computables.c_113(_ctx())
    assert r.statut == "ok"


# ---------------------------------------------------------------------------
# Squelettes — sanity check sur ~3 codes représentatifs
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@pytest.mark.parametrize("code", ["C-200", "C-250", "C-300", "C-320"])
async def test_skeleton_returns_na_with_message(code: str) -> None:
    """Échantillon : chaque squelette retourne na avec message standard."""
    handler = c_skeletons._make_handler(code)
    r = await handler(_ctx())
    assert r.statut == "na"
    assert "Implémentation différée" in (r.message or "")


def test_skeleton_count_exact() -> None:
    """Squelette = 80 ERRD (C-200→C-279) + 21 autres (C-300→C-320) = 101."""
    assert len(c_skeletons.SKELETON_CODES) == 101
    assert "C-200" in c_skeletons.SKELETON_CODES
    assert "C-279" in c_skeletons.SKELETON_CODES
    assert "C-300" in c_skeletons.SKELETON_CODES
    assert "C-320" in c_skeletons.SKELETON_CODES
