"""Unit tests for :mod:`piilot_pack_compta_esms.services.balance_file_parser`.

We test the parser in isolation (pure-function behaviour) — no S3,
no DB. Crafted XLSX and CSV bodies cover the headers cabinets
actually produce."""

from __future__ import annotations

import io

import pytest
from openpyxl import Workbook

from piilot_pack_compta_esms.services import balance_file_parser


def _build_xlsx(rows: list[list]) -> bytes:
    """Helper — produce an XLSX BytesIO from a list of rows."""
    wb = Workbook()
    ws = wb.active
    for row in rows:
        ws.append(row)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def test_normalise_strips_accents_and_lowers():
    assert balance_file_parser._normalise("Libellé COMPTE") == "libelle compte"
    assert balance_file_parser._normalise("N°  Compte") == "n° compte"
    assert balance_file_parser._normalise("  Débit ") == "debit"
    assert balance_file_parser._normalise("") == ""


def test_detect_roles_exact_match():
    header = ["N° Compte", "Libellé", "Débit", "Crédit", "Solde", "Période"]
    out = balance_file_parser.detect_roles(header)
    assert out == {
        "compte": 0,
        "libelle": 1,
        "debit": 2,
        "credit": 3,
        "solde": 4,
        "periode": 5,
    }


def test_detect_roles_substring_fallback():
    """Headers like "Solde N" / "Période 2026" still hit the right role."""
    header = ["Num Compte", "Désignation", "Solde N", "Période 2026"]
    out = balance_file_parser.detect_roles(header)
    assert out["compte"] == 0
    assert out["libelle"] == 1
    assert out["solde"] == 2
    assert out["periode"] == 3
    assert out["debit"] is None
    assert out["credit"] is None


def test_apply_hints_overrides_and_unsets():
    detection = {"compte": 0, "libelle": 1, "debit": 2, "credit": 3, "solde": 4, "periode": None}
    hints = {"solde": None, "periode": 5}
    out = balance_file_parser.apply_hints(detection, hints)
    assert out["solde"] is None  # explicit unset
    assert out["periode"] == 5
    assert out["compte"] == 0  # untouched


def test_apply_hints_ignores_unknown_role():
    """A hint with an unknown role key is dropped silently — defends
    against a stale frontend dropping an extra column."""
    detection = {"compte": 0, "libelle": 1, "debit": 2, "credit": 3, "solde": 4, "periode": 5}
    hints = {"totally_invalid_role": 7, "compte": 1}
    out = balance_file_parser.apply_hints(detection, hints)
    assert out["compte"] == 1
    assert "totally_invalid_role" not in out


def test_parse_xlsx_extracts_header_and_rows():
    body = _build_xlsx(
        [
            ["N° Compte", "Libellé", "Débit", "Crédit", "Solde"],
            ["60611", "Eau", 12.5, 0, 12.5],
            ["60612", "Électricité", 8.5, 0, 8.5],
        ]
    )
    parsed = balance_file_parser.parse(body, filename="balance.xlsx")
    assert parsed["nb_lignes_source"] == 2
    assert parsed["column_detection"]["compte"] == 0
    assert parsed["column_detection"]["solde"] == 4
    # preview_data carries header + rows
    assert parsed["preview_data"]["header"][0] == "N° Compte"
    assert parsed["preview_data"]["rows"][0][0] == "60611"  # values_only=True keeps str


def test_parse_xlsx_skips_logo_row_above_header():
    """openpyxl sometimes returns a sparse first row (cabinet stuck a
    logo or a title) — the parser picks the first row with ≥ 2
    non-empty cells as the header."""
    body = _build_xlsx(
        [
            [None, None, "Balance 2025"],  # title row
            ["N° Compte", "Libellé", "Débit", "Crédit"],
            ["60611", "Eau", 12.5, 0],
        ]
    )
    parsed = balance_file_parser.parse(body, filename="balance.xlsx")
    assert parsed["nb_lignes_source"] == 1
    assert parsed["column_detection"]["compte"] == 0


def test_parse_csv_french_dialect():
    """French Excel exports use ``;`` not ``,`` — sniffer must detect."""
    body = (
        "N° Compte;Libellé;Débit;Crédit;Solde\n"
        "60611;Eau;12.5;0;12.5\n"
        "60612;Électricité;8.5;0;8.5\n"
    ).encode()
    parsed = balance_file_parser.parse(body, filename="balance.csv")
    assert parsed["nb_lignes_source"] == 2
    assert parsed["column_detection"]["compte"] == 0


def test_parse_csv_with_bom():
    """Excel exports often include a UTF-8 BOM — must be tolerated."""
    body = "﻿Compte;Libellé;Solde\n60611;Eau;12.5\n".encode()
    parsed = balance_file_parser.parse(body, filename="balance.csv")
    # BOM stripped — header reads "Compte" not "﻿Compte"
    assert parsed["column_detection"]["compte"] == 0


def test_parse_rejects_unknown_extension():
    with pytest.raises(ValueError):
        balance_file_parser.parse(b"x", filename="balance.txt")


def test_sanitize_xlsx_round_trip():
    """A clean XLSX survives the sanitize round-trip ; the body
    changes (different bytes after re-save) but the parser still
    reads the same rows."""
    body = _build_xlsx([["Compte", "Libellé"], ["60611", "Eau"]])
    sanitized = balance_file_parser.sanitize_xlsx(body)
    parsed = balance_file_parser.parse(sanitized, filename="balance.xlsx")
    assert parsed["nb_lignes_source"] == 1
    assert parsed["preview_data"]["rows"][0][0] == "60611"


def test_preview_limit():
    """Preview caps at 20 rows even if the file has 100."""
    rows = [["Compte", "Libellé"]] + [[f"60{i:03d}", f"Compte {i}"] for i in range(100)]
    body = _build_xlsx(rows)
    parsed = balance_file_parser.parse(body, filename="balance.xlsx")
    assert parsed["nb_lignes_source"] == 100
    assert len(parsed["preview_data"]["rows"]) == 20
