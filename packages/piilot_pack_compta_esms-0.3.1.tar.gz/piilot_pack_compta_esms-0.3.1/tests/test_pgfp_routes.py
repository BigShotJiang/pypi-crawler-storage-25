"""Route tests for PGFP endpoints (L2 §9, 3 endpoints)."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.pgfp import (
    PgfpLigneRead,
    PgfpRecomputeResponse,
    PgfpRecomputeWarning,
    PgfpResponse,
)
from piilot_pack_compta_esms.routes import pgfp as pgfp_routes
from piilot_pack_compta_esms.routes._limiter import limiter
from piilot_pack_compta_esms.services import pgfp_service
from piilot_pack_compta_esms.services.errors import NotFoundError, ValidationError

COMPANY = uuid4()
USER = uuid4()
DOC_ID = uuid4()
USER_AUTH = (USER, "user", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)


def _ligne_read(**overrides) -> PgfpLigneRead:
    base = {
        "id": uuid4(),
        "ligne_key": "crp_g1_charges",
        "section": "crp_consolides",
        "label": "Groupe I — Charges",
        "is_computed": False,
        "montant_n": Decimal("100000"),
        "created_at": datetime.now(UTC),
        "updated_at": datetime.now(UTC),
    }
    base.update(overrides)
    return PgfpLigneRead.model_validate(base)


@pytest.fixture
def app():
    app = FastAPI()
    app.state.limiter = limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(pgfp_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# §9.1 GET /pgfp
# ---------------------------------------------------------------------------


def test_get_pgfp_200(client, monkeypatch):
    async def _fake(doc, company):
        return PgfpResponse(items=[_ligne_read()])

    monkeypatch.setattr(pgfp_service, "list_pgfp", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/pgfp")
    assert r.status_code == 200
    body = r.json()
    assert len(body["items"]) == 1


def test_get_pgfp_404(client, monkeypatch):
    async def _fake(doc, company):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(pgfp_service, "list_pgfp", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/pgfp")
    assert r.status_code == 404


def test_get_pgfp_422_not_applicable(client, monkeypatch):
    """Q8 — type_document='errd' → 422."""

    async def _fake(doc, company):
        raise ValidationError("PGFP not applicable to errd", code="pgfp_not_applicable")

    monkeypatch.setattr(pgfp_service, "list_pgfp", _fake)
    r = client.get(f"/plugins/compta_esms/documents/{DOC_ID}/pgfp")
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "pgfp_not_applicable"


# ---------------------------------------------------------------------------
# §9.2 PATCH /pgfp
# ---------------------------------------------------------------------------


def test_patch_pgfp_200(client, monkeypatch):
    async def _fake(doc, company, payload):
        return PgfpResponse(items=[_ligne_read()])

    monkeypatch.setattr(pgfp_service, "patch_pgfp", _fake)
    r = client.patch(
        f"/plugins/compta_esms/documents/{DOC_ID}/pgfp",
        json={
            "items": [
                {"ligne_key": "crp_g1_charges", "montant_n": "100000"},
            ]
        },
    )
    assert r.status_code == 200


def test_patch_pgfp_403_user_role(client):
    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.patch(
        f"/plugins/compta_esms/documents/{DOC_ID}/pgfp",
        json={"items": []},
    )
    assert r.status_code == 403


def test_patch_pgfp_unknown_ligne_key_422(client, monkeypatch):
    async def _fake(doc, company, payload):
        raise ValidationError("unknown ligne_key 'foo'", code="unknown_ligne_key")

    monkeypatch.setattr(pgfp_service, "patch_pgfp", _fake)
    r = client.patch(
        f"/plugins/compta_esms/documents/{DOC_ID}/pgfp",
        json={"items": [{"ligne_key": "foo", "montant_n": "100"}]},
    )
    assert r.status_code == 422


def test_patch_pgfp_computed_ligne_422(client, monkeypatch):
    """Q4 — refuse PATCH d'une ligne is_computed=True."""

    async def _fake(doc, company, payload):
        raise ValidationError("ligne is computed", code="ligne_is_computed")

    monkeypatch.setattr(pgfp_service, "patch_pgfp", _fake)
    r = client.patch(
        f"/plugins/compta_esms/documents/{DOC_ID}/pgfp",
        json={"items": [{"ligne_key": "frng_fin_periode", "montant_n": "100"}]},
    )
    assert r.status_code == 422
    assert r.json()["detail"]["code"] == "ligne_is_computed"


def test_patch_pgfp_extra_fields_422(client):
    """Pydantic extra='forbid' rejects extra fields in body."""
    r = client.patch(
        f"/plugins/compta_esms/documents/{DOC_ID}/pgfp",
        json={
            "items": [
                {"ligne_key": "crp_g1_charges", "unknown_field": "bad"},
            ]
        },
    )
    assert r.status_code == 422


# ---------------------------------------------------------------------------
# §9.3 POST :recompute
# ---------------------------------------------------------------------------


def test_recompute_200(client, monkeypatch):
    async def _fake(doc, company):
        return PgfpRecomputeResponse(
            items=[_ligne_read()],
            warnings=[
                PgfpRecomputeWarning(
                    code="bloc_8_10_deferred",
                    message="MVP",
                    ligne_key=None,
                )
            ],
        )

    monkeypatch.setattr(pgfp_service, "recompute_pgfp", _fake)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/pgfp:recompute")
    assert r.status_code == 200
    body = r.json()
    assert len(body["items"]) == 1
    assert len(body["warnings"]) == 1
    assert body["warnings"][0]["code"] == "bloc_8_10_deferred"


def test_recompute_403_user_role(client):
    def _no_builder():
        raise HTTPException(status_code=403, detail="builder required")

    client.app.dependency_overrides[require_builder] = _no_builder
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/pgfp:recompute")
    assert r.status_code == 403


def test_recompute_422_not_applicable(client, monkeypatch):
    """Q8 — errd doc → 422."""

    async def _fake(doc, company):
        raise ValidationError("PGFP not applicable", code="pgfp_not_applicable")

    monkeypatch.setattr(pgfp_service, "recompute_pgfp", _fake)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/pgfp:recompute")
    assert r.status_code == 422


def test_recompute_404(client, monkeypatch):
    async def _fake(doc, company):
        raise NotFoundError("nope", code="document_not_found")

    monkeypatch.setattr(pgfp_service, "recompute_pgfp", _fake)
    r = client.post(f"/plugins/compta_esms/documents/{DOC_ID}/pgfp:recompute")
    assert r.status_code == 404
