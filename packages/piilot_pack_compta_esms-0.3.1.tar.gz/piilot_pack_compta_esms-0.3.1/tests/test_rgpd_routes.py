"""Route tests pour §T recueil consentement RGPD (L2 §20)."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from piilot.sdk.http import require_builder, require_user
from slowapi.errors import RateLimitExceeded

from piilot_pack_compta_esms.models.rgpd import (
    FederationsConsenties,
    RecueilConsentementRead,
)
from piilot_pack_compta_esms.routes import _limiter as limiter_module
from piilot_pack_compta_esms.routes import rgpd as rgpd_routes
from piilot_pack_compta_esms.services import rgpd_service
from piilot_pack_compta_esms.services.errors import (
    CrossCompanyError,
    NotFoundError,
)

COMPANY = uuid4()
USER = uuid4()
EXERCICE = uuid4()
USER_AUTH = (USER, "user", COMPANY)
BUILDER_AUTH = (USER, "builder", COMPANY)


def _read_response(
    *, cnsa: bool = True, federations: list[str] | None = None
) -> RecueilConsentementRead:
    return RecueilConsentementRead(
        id=uuid4(),
        company_id=COMPANY,
        exercice_id=EXERCICE,
        consentement_cnsa=cnsa,
        federations=FederationsConsenties(selected_known=federations or []),
        duree="1_an" if cnsa else None,
        consenti_par_user_id=USER,
        consenti_at=datetime.now(tz=UTC) if cnsa else None,
        revoque_at=None,
    )


@pytest.fixture
def app_user():
    app = FastAPI()
    app.state.limiter = limiter_module.limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(rgpd_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    app.dependency_overrides[require_builder] = lambda: BUILDER_AUTH
    return app


@pytest.fixture
def app_user_only():
    """user role for require_builder routes → 403 expected."""
    app = FastAPI()
    app.state.limiter = limiter_module.limiter

    async def _rate_limit_handler(request, exc):  # noqa: ANN001
        from fastapi.responses import JSONResponse

        return JSONResponse(status_code=429, content={"detail": "rate_limited"})

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.include_router(rgpd_routes.router, prefix="/plugins/compta_esms")
    app.dependency_overrides[require_user] = lambda: USER_AUTH
    # No override for require_builder → returns the real dependency
    # which will reject the user role.
    return app


# ---------------------------------------------------------------------------
# GET /recueil-consentement
# ---------------------------------------------------------------------------


def test_get_recueil_consentement_200(app_user, monkeypatch):
    async def _fake(ex, co):
        return _read_response(cnsa=True, federations=["FEHAP"])

    monkeypatch.setattr(rgpd_service, "get_consentement", _fake)
    client = TestClient(app_user)
    r = client.get(f"/plugins/compta_esms/exercices/{EXERCICE}/recueil-consentement")
    assert r.status_code == 200
    body = r.json()
    assert body["consentement_cnsa"] is True
    assert "FEHAP" in body["federations"]["selected_known"]


def test_get_recueil_consentement_404_exercice(app_user, monkeypatch):
    async def _fake(ex, co):
        raise NotFoundError("nope", code="exercice_not_found")

    monkeypatch.setattr(rgpd_service, "get_consentement", _fake)
    client = TestClient(app_user)
    r = client.get(f"/plugins/compta_esms/exercices/{EXERCICE}/recueil-consentement")
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "exercice_not_found"


def test_get_recueil_consentement_404_not_set(app_user, monkeypatch):
    async def _fake(ex, co):
        raise NotFoundError("nope", code="consentement_not_found")

    monkeypatch.setattr(rgpd_service, "get_consentement", _fake)
    client = TestClient(app_user)
    r = client.get(f"/plugins/compta_esms/exercices/{EXERCICE}/recueil-consentement")
    assert r.status_code == 404
    assert r.json()["detail"]["code"] == "consentement_not_found"


def test_get_recueil_consentement_403_cross_company(app_user, monkeypatch):
    async def _fake(ex, co):
        raise CrossCompanyError("cross", code="consentement_cross_company")

    monkeypatch.setattr(rgpd_service, "get_consentement", _fake)
    client = TestClient(app_user)
    r = client.get(f"/plugins/compta_esms/exercices/{EXERCICE}/recueil-consentement")
    assert r.status_code == 403


# ---------------------------------------------------------------------------
# PUT /recueil-consentement
# ---------------------------------------------------------------------------


def test_put_recueil_consentement_200(app_user, monkeypatch):
    async def _fake(*, exercice_id, company_id, user_id, payload):
        return _read_response(cnsa=True, federations=list(payload.federations.selected_known))

    monkeypatch.setattr(rgpd_service, "put_consentement", _fake)
    client = TestClient(app_user)
    r = client.put(
        f"/plugins/compta_esms/exercices/{EXERCICE}/recueil-consentement",
        json={
            "consentement_cnsa": True,
            "federations": {
                "selected_known": ["FEHAP", "SYNERPA"],
                "selected_custom": ["FNADEPA IDF"],
            },
            "duree": "5_ans",
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert body["consentement_cnsa"] is True


def test_put_recueil_consentement_422_invalid_federation(app_user):
    client = TestClient(app_user)
    r = client.put(
        f"/plugins/compta_esms/exercices/{EXERCICE}/recueil-consentement",
        json={
            "consentement_cnsa": True,
            "federations": {"selected_known": ["NOT_A_REAL_FEDERATION"]},
            "duree": "1_an",
        },
    )
    assert r.status_code == 422


def test_put_recueil_consentement_422_invalid_duree(app_user):
    client = TestClient(app_user)
    r = client.put(
        f"/plugins/compta_esms/exercices/{EXERCICE}/recueil-consentement",
        json={
            "consentement_cnsa": True,
            "federations": {"selected_known": ["FHF"]},
            "duree": "2_ans",  # KO
        },
    )
    assert r.status_code == 422


def test_put_recueil_consentement_422_cnsa_false_with_federations(app_user):
    client = TestClient(app_user)
    r = client.put(
        f"/plugins/compta_esms/exercices/{EXERCICE}/recueil-consentement",
        json={
            "consentement_cnsa": False,
            "federations": {"selected_known": ["FEHAP"]},
        },
    )
    assert r.status_code == 422


def test_put_recueil_consentement_422_cnsa_true_without_duree(app_user):
    client = TestClient(app_user)
    r = client.put(
        f"/plugins/compta_esms/exercices/{EXERCICE}/recueil-consentement",
        json={
            "consentement_cnsa": True,
            "federations": {"selected_known": ["MUTUALITE"]},
        },
    )
    assert r.status_code == 422


def test_put_recueil_consentement_422_custom_more_than_3(app_user):
    client = TestClient(app_user)
    r = client.put(
        f"/plugins/compta_esms/exercices/{EXERCICE}/recueil-consentement",
        json={
            "consentement_cnsa": True,
            "federations": {
                "selected_known": [],
                "selected_custom": ["a", "b", "c", "d"],
            },
            "duree": "1_an",
        },
    )
    assert r.status_code == 422


def test_put_recueil_consentement_422_custom_with_pipe(app_user):
    client = TestClient(app_user)
    r = client.put(
        f"/plugins/compta_esms/exercices/{EXERCICE}/recueil-consentement",
        json={
            "consentement_cnsa": True,
            "federations": {
                "selected_custom": ["valid", "pipe | inside"],
            },
            "duree": "1_an",
        },
    )
    assert r.status_code == 422


def test_put_recueil_consentement_404_exercice(app_user, monkeypatch):
    async def _fake(**_kwargs):
        raise NotFoundError("nope", code="exercice_not_found")

    monkeypatch.setattr(rgpd_service, "put_consentement", _fake)
    client = TestClient(app_user)
    r = client.put(
        f"/plugins/compta_esms/exercices/{EXERCICE}/recueil-consentement",
        json={"consentement_cnsa": False},
    )
    assert r.status_code == 404
