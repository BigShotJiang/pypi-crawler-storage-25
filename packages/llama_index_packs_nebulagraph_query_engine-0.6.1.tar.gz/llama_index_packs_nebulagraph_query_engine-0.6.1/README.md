# llama-index-packs-nebulagraph-query-engine

> **DEPRECATED**: This package is deprecated and no longer maintained.
> It will not receive any further updates or bug fixes.
> Please consider alternative solutions.
