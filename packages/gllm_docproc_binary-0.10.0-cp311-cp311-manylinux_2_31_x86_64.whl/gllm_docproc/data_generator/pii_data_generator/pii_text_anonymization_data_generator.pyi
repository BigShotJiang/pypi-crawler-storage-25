from _typeshed import Incomplete
from gllm_docproc.data_generator.base_data_generator import BaseDataGenerator as BaseDataGenerator
from gllm_docproc.model.element import Element as Element
from gllm_privacy.pii_detector.text_anonymizer import BaseTextAnalyzer
from typing import Any

class PIITextAnonymizationDataGenerator(BaseDataGenerator):
    """A data generator for anonymizing PII text data with TextAnonymizer.

    This class extends the BaseDataGenerator class and implements the generate method to anonymize the PII text data.
    """
    text_analyzer: Incomplete
    pii_entities: Incomplete
    default_language: Incomplete
    supported_languages: Incomplete
    logger: Incomplete
    def __init__(self, text_analyzer: BaseTextAnalyzer | None = None, pii_entities: list[str] | None = None, default_language: str = 'id', supported_languages: list[str] | None = None) -> None:
        '''Initialize the PIITextAnonymizationDataGenerator.

        Args:
            text_analyzer (BaseTextAnalyzer | None, optional): The text analyzer instance to use for analyzing
                the PII text data. Defaults to None, which will use the TextAnalyzer instance.
            pii_entities (list[str] | None, optional): The list of PII entities to anonymize. Defaults to None.
            default_language (str, optional): The default language of the text to be analyzed. Defaults to "id".
            supported_languages (list[str] | None, optional): The list of supported languages.
                Defaults to None, which will use ["en", "id"] as the supported languages.
        '''
    def generate(self, elements: list[dict[str, Any]], **kwargs: Any) -> list[dict[str, Any]]:
        """Generate the PII text anonymization data for elements.

        Args:
            elements (list[dict[str, Any]]): The list of elements to anonymize.
            **kwargs (Any): Additional keyword arguments.

        Kwargs:
            pii_enabled (bool, optional): Whether to enable PII anonymization. Defaults to True.

        Returns:
            list[dict[str, Any]]: The list of anonymized elements if pii_enabled is True, else the original elements.
                The anonymized elements will have:
                1. `text` replaced with anonymized text.
                2. `metadata.entities` contains the list of unique PII entities values.
                3. `metadata.pii_mapping` contains the mapping of PII entities values to their original values.
        """
