from _typeshed import Incomplete
from gllm_core.utils.retry import RetryConfig
from gllm_docproc.downloader.base_downloader import BaseDownloader as BaseDownloader
from typing import Any

DEFAULT_MAX_RETRIES: int
DEFAULT_TIMEOUT: int

class RetryableDownloader(BaseDownloader):
    """A base downloader with built-in tenacity retry logic for transient failures."""
    NETWORK_RETRY_EXCEPTIONS: tuple[type[BaseException], ...]
    RETRYABLE_HTTP_STATUS_CODES: tuple[int, ...]
    logger: Incomplete
    retry_config: Incomplete
    def __init__(self, retry_config: RetryConfig | dict[str, Any] | None = None) -> None:
        """Initialize the RetryableDownloader.

        Args:
            retry_config (RetryConfig | dict[str, Any] | None, optional): Retry configuration.
                When a dict, it is validated into RetryConfig. When None, a default RetryConfig
                is built. Note: retry_on_exceptions cannot be customized; it is always
                NETWORK_RETRY_EXCEPTIONS. Defaults to None.
        """
