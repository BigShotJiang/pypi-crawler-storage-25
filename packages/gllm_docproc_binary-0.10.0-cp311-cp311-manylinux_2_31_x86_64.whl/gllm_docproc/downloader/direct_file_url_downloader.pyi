from _typeshed import Incomplete
from gllm_core.utils.retry import RetryConfig
from gllm_docproc.downloader import RetryableDownloader as RetryableDownloader
from typing import Any

UNKNOWN_EXTENSION: str
FALLBACK_EXTENSION: str
TMP_EXTENSION: str
MIME_TYPE_TO_EXTENSION_MAP: Incomplete

class DirectFileURLDownloader(RetryableDownloader):
    """A class for downloading files from a direct file URL to the defined output directory."""
    NETWORK_RETRY_EXCEPTIONS: Incomplete
    stream_buffer_size: Incomplete
    session: Incomplete
    def __init__(self, stream_buffer_size: int = 65536, retry_config: RetryConfig | dict[str, Any] | None = None) -> None:
        """Initialize the DirectFileURLDownloader.

        Args:
            stream_buffer_size (int, optional): The size of the buffer for streaming downloads in bytes.
                Defaults to 64KB (65536 bytes).
            retry_config (RetryConfig | dict[str, Any] | None, optional): Retry configuration. When a dict,
                it is validated into RetryConfig. When None, a default RetryConfig is built by the base
                class with a default timeout of 30 seconds. Defaults to None. Note: retry_on_exceptions
                cannot be customized; it is always NETWORK_RETRY_EXCEPTIONS.
        """
    def download(self, source: str, output: str, **kwargs: Any) -> list[str]:
        """Download source to the output directory.

        Args:
            source (str): The source to be downloaded.
            output (str): The output directory where the downloaded source will be saved.
            **kwargs (Any): Additional keyword arguments.

        kwargs:
            ca_certs_path (str, optional): The path to the CA certificates file. Defaults to None.
            extension (str, optional): The extension of the file to be downloaded. If not provided,
                the extension will be detected from the response headers or content mime type.

        Returns:
            list[str]: A list of file paths of successfully downloaded files.
        """
