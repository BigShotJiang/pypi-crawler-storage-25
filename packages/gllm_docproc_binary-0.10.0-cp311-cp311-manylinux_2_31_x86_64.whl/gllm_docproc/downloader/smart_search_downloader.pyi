from _typeshed import Incomplete
from gllm_core.utils.retry import RetryConfig
from gllm_docproc.downloader import RetryableDownloader as RetryableDownloader
from gllm_docproc.utils.async_utils import run_async_in_sync as run_async_in_sync
from typing import Any

class SmartSearchDownloader(RetryableDownloader):
    """A downloader for fetching web page content via the Smart Search SDK."""
    NETWORK_RETRY_EXCEPTIONS: Incomplete
    base_url: Incomplete
    token: Incomplete
    def __init__(self, base_url: str, token: str, retry_config: RetryConfig | dict[str, Any] | None = None) -> None:
        """Initialize the SmartSearchDownloader.

        Args:
            base_url (str): The base URL for the Smart Search Client.
            token (str): The access token for authentication.
            retry_config (RetryConfig | dict[str, Any] | None, optional): Retry configuration.
                - When a dict, it is validated into RetryConfig.
                - When None, a default RetryConfig is built.
                Note: retry_on_exceptions cannot be customized; it is always NETWORK_RETRY_EXCEPTIONS.
                Defaults to None.
        """
    def download(self, source: str, output: str, **kwargs: Any) -> list[str]:
        """Fetch and download a specific web page's content utilizing the Smart Search SDK.

        Args:
            source (str): The specific URL of the web page to fetch content from.
            output (str): The output directory where the downloaded JSON data will be saved.
            **kwargs (Any): Additional keyword arguments.

        Kwargs:
            return_html (bool, optional): Return raw HTML if True, cleaned text if False.
                Defaults to False.
            json_schema (dict, optional): JSON schema for custom structured data extraction.
                Defaults to None.

        Returns:
            list[str]: A list of file paths of successfully downloaded files.
        """
