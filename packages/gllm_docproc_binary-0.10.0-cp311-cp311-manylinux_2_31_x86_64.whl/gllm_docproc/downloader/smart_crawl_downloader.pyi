from _typeshed import Incomplete
from gllm_core.utils.retry import RetryConfig
from gllm_docproc.downloader import RetryableDownloader as RetryableDownloader
from typing import Any

class SmartCrawlDownloader(RetryableDownloader):
    """A downloader for retrieving crawled records from Smart Crawl."""
    NETWORK_RETRY_EXCEPTIONS: Incomplete
    OPTIONAL_QUERY_PARAMS: Incomplete
    endpoint_url: Incomplete
    session: Incomplete
    def __init__(self, endpoint_url: str, retry_config: RetryConfig | dict[str, Any] | None = None) -> None:
        """Initialize the SmartCrawlDownloader.

        Args:
            endpoint_url (str): The URL of the Smart Crawl API endpoint.
            retry_config (RetryConfig | dict[str, Any] | None, optional): Retry configuration. When a dict,
                it is validated into RetryConfig. When None, a default RetryConfig is built.
                Note: retry_on_exceptions cannot be customized; it is always NETWORK_RETRY_EXCEPTIONS.
                Defaults to None.
        """
    def download(self, source: str, output: str, **kwargs: Any) -> list[str]:
        """Download the data from the Smart Crawl API.

        Args:
            source (str): The smart crawl domains to be downloaded in comma separated format.
            output (str): The output directory where the downloaded data will be saved.
            **kwargs (Any): Additional keyword arguments.

        Kwargs:
            start_date (str): Start datetime in ISO 8601 with timezone.
            end_date (str): End datetime in ISO 8601 with timezone.
            queries (str, optional): Comma separated of search queries.
            schema (str, optional): Comma separated of fields to be included in the response.
            page (int, optional): The page number to be downloaded.
            page_size (int, optional): The number of items to be downloaded per page.
            after_timestamp (str, optional): The ISO 8601 timestamp to be used as the cursor for the next page.

        Returns:
            list[str]: A list of file paths of successfully downloaded files.
        """
