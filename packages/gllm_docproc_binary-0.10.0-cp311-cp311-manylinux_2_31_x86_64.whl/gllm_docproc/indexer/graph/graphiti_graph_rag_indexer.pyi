from _typeshed import Incomplete
from gllm_datastore.graph_data_store.graphiti_graph_rag_data_store import GraphitiGraphRAGDataStore
from gllm_docproc.indexer.graph.graph_rag_indexer import BaseGraphRAGIndexer as BaseGraphRAGIndexer
from gllm_docproc.model.element import Element as Element
from typing import Any

logger: Incomplete

class GraphitiGraphRAGIndexer(BaseGraphRAGIndexer):
    """Indexer for GraphRAG using Graphiti.

    Attributes:
        _graph_store (GraphitiGraphRAGDataStore): The Graphiti data store used for indexing.
    """
    def __init__(self, graph_store: GraphitiGraphRAGDataStore) -> None:
        """Initialize the GraphitiGraphRAGIndexer.

        Args:
            graph_store (GraphitiGraphRAGDataStore): The Graphiti data store to use for indexing.

        Raises:
            ValueError: If the graph store's index_name is None or empty. A non-empty index_name
                is required because Graphiti normalizes empty group_ids to None, which removes all
                namespace filtering and causes embedding dimension mismatch errors at query time.
        """
    def index(self, elements: list[dict[str, Any]], **kwargs: Any) -> dict[str, Any]:
        """Index elements into the Graphiti system and create graph relationships.

        This method validates that file_id or document_id is present in kwargs and delegates
        to index_file_chunks.

        Args:
            elements (list[dict[str, Any]]): List of Element objects containing text and metadata.
                Each element should have a metadata attribute with a chunk_id and a file_id.
            **kwargs (Any): Additional keyword arguments.

        Kwargs:
            file_id (str): The ID of the file these chunks belong to.
            document_id (str): The document ID. If file_id is not provided, document_id is used as file_id.

        Returns:
            dict[str, Any]: Response with success status, error message, and total count.
                - success (bool): True if indexing succeeded, False otherwise.
                - error_message (str): Error message if indexing failed, empty string otherwise.
                - total (int): The total number of chunks indexed.

        Raises:
            ValueError: If neither file_id nor document_id is provided in kwargs.
        """
    def delete(self, file_id: str | None = None, chunk_id: str | None = None, entity_id: str | None = None, **kwargs: Any) -> dict[str, Any]:
        """Delete entities from the Graphiti system and graph.

        Supports multiple deletion modes based on the provided keyword arguments.
        Exactly one of the supported deletion parameters must be provided.
        If file_id is provided, delegates to delete_file_chunks.

        Args:
            file_id (str | None, optional): Delete a file and all its associated chunks. Defaults to None.
            chunk_id (str | None, optional): Delete a specific chunk entity. Defaults to None.
            entity_id (str | None, optional): Delete a specific entity or node. Defaults to None.
            **kwargs (Any): Additional keyword arguments.

        Returns:
            dict[str, Any]: Response with success status and error message.
                - success (bool): True if deletion succeeded, False otherwise.
                - error_message (str): Error message if deletion failed, empty string otherwise.

        Raises:
            ValueError: If no deletion parameter is provided or multiple are provided.
        """
    def resolve_entities(self) -> None:
        """Resolve entities from the graph.

        Currently, this method does nothing. Entity resolution
        is implicitly implemented in the Graphiti instance.
        """
    def index_file_chunks(self, elements: list[dict[str, Any]], file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Index chunks for a specific file.

        This method extracts text and chunk IDs from the provided elements,
        converts them to Chunk objects, and inserts them into the Graphiti system.

        Args:
            elements (list[dict[str, Any]]): The chunks to be indexed.
            file_id (str): The ID of the file these chunks belong to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status, error message, and total count.
        """
    def index_chunks(self, elements: list[dict[str, Any]], **kwargs: Any) -> dict[str, Any]:
        """Index multiple chunks.

        This method enables indexing multiple chunks in a single operation without requiring file
        replacement semantics (i.e., it inserts or overwrites the provided chunks directly without
        first deleting existing chunks). The chunks provided can belong to multiple different files.

        Args:
            elements (list[dict[str, Any]]): The chunks to be indexed. Each dict should follow the Element
                structure with 'text' and 'metadata' keys. Metadata must include 'file_id' and 'chunk_id'.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status, error message, and total count.
                - success (bool): True if indexing succeeded, False otherwise.
                - error_message (str): Error message if indexing failed, empty string otherwise.
                - total (int): The total number of chunks indexed.
        """
    def get_file_chunks(self, file_id: str, page: int = 0, size: int = 20, **kwargs: Any) -> dict[str, Any]:
        """Get chunks for a specific file with pagination support.

        Args:
            file_id (str): The ID of the file to get chunks from.
            page (int, optional): The page number (0-indexed). Defaults to 0.
            size (int, optional): The number of chunks per page. Defaults to 20.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with chunks list, total count, and pagination info.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def delete_file_chunks(self, file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Delete all chunks for a specific file.

        Args:
            file_id (str): The ID of the file whose chunks should be deleted.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status and error message.
        """
    def index_chunk(self, element: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Index a single chunk.

        This method only indexes the chunk. It does NOT update the metadata of neighboring chunks
        (previous_chunk/next_chunk). The caller is responsible for maintaining chunk relationships by updating
        adjacent chunks' metadata separately.

        Args:
            element (dict[str, Any]): The chunk to be indexed.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status, error message, and chunk_id.
                - success (bool): True if indexing succeeded, False otherwise.
                - error_message (str): Error message if indexing failed, empty string otherwise.
                - chunk_id (str | None): The ID of the indexed chunk if successful, None otherwise.
        """
    def get_chunk(self, chunk_id: str, file_id: str, **kwargs: Any) -> dict[str, Any] | None:
        """Get a single chunk by chunk ID and file ID.

        Args:
            chunk_id (str): The ID of the chunk to retrieve.
            file_id (str): The ID of the file the chunk belongs to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any] | None: The chunk data, or None if not found.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def update_chunk(self, element: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Update a chunk by chunk ID.

        This method updates both the text content and metadata of a chunk. When text content is updated, the chunk
        should be re-processed through data generators and re-indexed with updated vector embeddings.

        Args:
            element (dict[str, Any]): The updated chunk data.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status, error message, and chunk_id.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def update_chunk_metadata(self, chunk_id: str, file_id: str, metadata: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Update metadata for a specific chunk.

        This method patches new metadata into the existing chunk metadata. Existing metadata fields will be
        overwritten, and new fields will be added. System-managed metadata fields (file_id, chunk_id, etc.) should
        be preserved and not overwritten.

        Args:
            chunk_id (str): The ID of the chunk to update.
            file_id (str): The ID of the file the chunk belongs to.
            metadata (dict[str, Any]): The metadata fields to update.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status and error message.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
    def delete_chunk(self, chunk_id: str, file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Delete a single chunk by chunk ID and file ID.

        Args:
            chunk_id (str): The ID of the chunk to delete.
            file_id (str): The ID of the file the chunk belongs to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response with success status and error message.
                - success (bool): True if deletion succeeded, False otherwise.
                - error_message (str): Error message if deletion failed, empty string otherwise.
        """
