from abc import ABC, abstractmethod
from typing import Any

class BaseIndexer(ABC):
    """An abstract base class for document indexers.

    This class defines the structure for managing document chunks in a database.
    Subclasses are expected to implement methods to handle file-level and chunk-level
    indexing operations such as creating, reading, updating, and deleting chunks.

    Methods:
        index_file_chunks(elements, file_id, **kwargs): Abstract method to index chunks for a specific file.
        get_file_chunks(file_id, page, size, **kwargs): Abstract method to get chunks for a specific file.
        delete_file_chunks(file_id, **kwargs): Abstract method to delete all chunks for a specific file.
        index_chunks(elements, **kwargs): Abstract method to index multiple chunks.
        index_chunk(element, **kwargs): Abstract method to index a single chunk.
        get_chunk(chunk_id, file_id, **kwargs): Abstract method to get a single chunk.
        update_chunk(element, **kwargs): Abstract method to update a chunk.
        update_chunk_metadata(chunk_id, file_id, metadata, **kwargs): Abstract method to update
            metadata for a specific chunk.
        delete_chunk(chunk_id, file_id, **kwargs): Abstract method to delete a single chunk.
    """
    @abstractmethod
    def index_file_chunks(self, elements: list[dict[str, Any]], file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Index chunks for a specific file.

        This method indexes chunks for a file. The indexer is responsible for deleting any existing chunks
        for the file_id before indexing the new chunks to ensure consistency. This ensures that the file's
        chunks are completely replaced with the new set of chunks.

        Args:
            elements (list[dict[str, Any]]): The chunks to be indexed. Each dict should follow the Element
                structure with 'text' and 'metadata' keys. Metadata must include 'file_id' and 'chunk_id'.
            file_id (str): The ID of the file these chunks belong to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: The response from the indexing process. Should include:
                1. success (bool): True if indexing succeeded, False otherwise.
                2. error_message (str): Error message if indexing failed, empty string otherwise.
                3. total (int): The total number of chunks indexed.
        """
    @abstractmethod
    def get_file_chunks(self, file_id: str, page: int = 0, size: int = 20, **kwargs: Any) -> dict[str, Any]:
        """Get chunks for a specific file with pagination support.

        Args:
            file_id (str): The ID of the file to get chunks from.
            page (int, optional): The page number (0-indexed). Defaults to 0.
            size (int, optional): The number of chunks per page. Defaults to 20.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: Response containing:
                1. chunks (list[dict[str, Any]]): List of chunks (elements) with text, structure, and metadata.
                2. pagination (dict[str, Any]): Pagination metadata with:
                    - page (int): Current page number.
                    - size (int): Number of items per page.
                    - total_chunks (int): Total number of chunks for the file.
                    - total_pages (int): Total number of pages.
                    - has_next (bool): Whether there is a next page.
                    - has_previous (bool): Whether there is a previous page.

        Note:
            Chunks should be sorted by their metadata.order field (position within the file).
        """
    @abstractmethod
    def delete_file_chunks(self, file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Delete all chunks for a specific file.

        Args:
            file_id (str): The ID of the file whose chunks should be deleted.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: The response from the deletion process. Should include:
                1. success (bool): True if deletion succeeded, False otherwise.
                2. error_message (str): Error message if deletion failed, empty string otherwise.
        """
    @abstractmethod
    def index_chunks(self, elements: list[dict[str, Any]], **kwargs: Any) -> dict[str, Any]:
        """Index multiple chunks.

        This method enables indexing multiple chunks in a single operation without requiring file
        replacement semantics (i.e., it inserts or overwrites the provided chunks directly without
        first deleting existing chunks). The chunks provided can belong to multiple different files.

        Args:
            elements (list[dict[str, Any]]): The chunks to be indexed. Each dict should follow the Element
                structure with 'text' and 'metadata' keys. Metadata must include 'file_id' and 'chunk_id'.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: The response from the indexing process. Should include:
                1. success (bool): True if indexing succeeded, False otherwise.
                2. error_message (str): Error message if indexing failed, empty string otherwise.
                3. total (int): The total number of chunks indexed.
        """
    @abstractmethod
    def index_chunk(self, element: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Index a single chunk.

        Note: This method only indexes the chunk. It does NOT update the metadata of neighboring chunks
        (previous_chunk/next_chunk). The caller is responsible for maintaining chunk relationships by updating
        adjacent chunks' metadata separately.

        Args:
            element (dict[str, Any]): The chunk to be indexed. Should follow the Element structure
                with 'text' and 'metadata' keys. Metadata must include 'file_id' and 'chunk_id'.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: The response from the indexing process. Should include:
                1. success (bool): True if indexing succeeded, False otherwise.
                2. error_message (str): Error message if indexing failed, empty string otherwise.
                3. chunk_id (str): The ID of the indexed chunk.
        """
    @abstractmethod
    def get_chunk(self, chunk_id: str, file_id: str, **kwargs: Any) -> dict[str, Any] | None:
        """Get a single chunk by chunk ID and file ID.

        Args:
            chunk_id (str): The ID of the chunk to retrieve.
            file_id (str): The ID of the file the chunk belongs to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any] | None: The chunk data following the Element structure with 'text' and 'metadata' keys,
                or None if the chunk is not found.
        """
    @abstractmethod
    def update_chunk(self, element: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Update a chunk by chunk ID.

        This method updates both the text content and metadata of a chunk.

        Fails on chunk not found.

        Args:
            element (dict[str, Any]): The updated chunk data. Should follow the Element structure
                with 'text' and 'metadata' keys. Metadata must include 'file_id' and 'chunk_id'.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: The response from the update process. Should include:
                1. success (bool): True if update succeeded, False otherwise.
                2. error_message (str): Error message if update failed, empty string otherwise.
                3. chunk_id (str): The ID of the updated chunk.
        """
    @abstractmethod
    def update_chunk_metadata(self, chunk_id: str, file_id: str, metadata: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
        """Update metadata for a specific chunk.

        This method patches new metadata into the existing chunk metadata. Existing metadata
        fields will be overwritten, and new fields will be added.

        Fails on chunk not found.

        Args:
            chunk_id (str): The ID of the chunk to update.
            file_id (str): The ID of the file the chunk belongs to.
            metadata (dict[str, Any]): The metadata fields to update. Only the provided fields will be updated;
                other existing metadata will remain unchanged.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: The response from the update process. Should include:
                1. success (bool): True if update succeeded, False otherwise.
                2. error_message (str): Error message if update failed, empty string otherwise.
        """
    @abstractmethod
    def delete_chunk(self, chunk_id: str, file_id: str, **kwargs: Any) -> dict[str, Any]:
        """Delete a single chunk by chunk ID and file ID.

        Args:
            chunk_id (str): The ID of the chunk to delete.
            file_id (str): The ID of the file the chunk belongs to.
            **kwargs (Any): Additional keyword arguments for customization.

        Returns:
            dict[str, Any]: The response from the deletion process. Should include:
                1. success (bool): True if deletion succeeded, False otherwise.
                2. error_message (str): Error message if deletion failed, empty string otherwise.
        """
