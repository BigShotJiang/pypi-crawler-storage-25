from _typeshed import Incomplete
from gllm_docproc.loader.base_loader import BaseLoader as BaseLoader
from gllm_docproc.loader.loader_utils import create_base_element_metadata as create_base_element_metadata
from gllm_docproc.loader.video.video_loader_utils import extract_video_frame_at_timestamp as extract_video_frame_at_timestamp
from gllm_docproc.model.element import Element as Element, VIDEO as VIDEO
from gllm_docproc.model.element_metadata import ElementMetadata as ElementMetadata
from gllm_docproc.model.media import Media as Media, MediaContentType as MediaContentType, MediaType as MediaType
from gllm_docproc.utils import run_async_in_sync as run_async_in_sync
from gllm_multimodal.modality_converter.video_to_text.video_to_caption.video_to_caption import BaseVideoToCaption
from typing import Any

class VideoCaptionLoader(BaseLoader):
    """Video Caption Loader class for processing video files.

    This class provides a pipeline for processing video files by:
    - Analyzing video content to generate descriptive captions
    - Dividing videos into time-based segments (e.g., 0-10s, 10-20s)
    - Extracting representative keyframes (images) from each segment
    - Creating structured Element objects for downstream processing
    - Supporting flexible output: one element per segment or one for entire video

    The caption generation approach is flexible and depends on the video-to-caption
    converter implementation provided (e.g., AI/LM-based, hybrid, rule-based, etc.).

    Use Cases:
        - Segment level mode (segment_level_elements=True): Best for long videos where you want
          granular search/retrieval per segment (e.g., lecture videos, tutorials)
        - Single video mode (segment_level_elements=False): Best for short videos where you want
          the entire video treated as one searchable unit

    Attributes:
        video_to_caption (BaseVideoToCaption): The video-to-caption converter instance.
        segment_level_elements (bool): Default strategy for generating output elements.
        logger (Logger): Logger instance for the class.
    """
    video_to_caption: Incomplete
    segment_level_elements: Incomplete
    logger: Incomplete
    def __init__(self, video_to_caption: BaseVideoToCaption, segment_level_elements: bool = False) -> None:
        """Initialize the VideoCaptionLoader class.

        Args:
            video_to_caption (BaseVideoToCaption): The video-to-caption converter instance.
                Can be any implementation (AI-based, hybrid, rule-based, etc.).
            segment_level_elements (bool): Default strategy for output elements.
                Supported values:
                    - True: Creates one Element per video segment. Example: a 60s video
                          with 6 segments produces 6 separate elements, each with its own
                          segment metadata and keyframes. Good for granular retrieval.
                    - False: Creates one Element for the entire video with all segments
                          and keyframes in metadata. Good for treating video as single unit.
                    Default: False.
        """
    def load(self, source: str, loaded_elements: Any = None, **kwargs: Any) -> list[dict[str, Any]]:
        '''Load and process video file through the caption generation pipeline.

        This method orchestrates the complete video processing workflow:
        1. Analyzes video to generate descriptive captions
        2. Identifies video segments and keyframes
        3. Extracts keyframe images and converts to base64
        4. Creates structured Element objects with metadata
        5. Returns serialized elements ready for indexing/search

        Args:
            source (str): Path to the video file (e.g., "/path/to/video.mp4").
            loaded_elements (Any, optional): The loaded elements from previous loaders (currently not used).
            **kwargs (Any): Additional keyword arguments for customization.

        Kwargs:
            segment_level_elements (bool, optional): Override default behavior.
                If True, creates one Element per segment. If False, creates a single Element.

        Returns:
            list[dict[str, Any]]: List of video elements as dictionaries following the Element model format.
                Each element contains:
                - text: Video summary description
                - metadata: Segment info, keyframes, timestamps, base64 images

        Example:
            >>> loader = VideoCaptionLoader(video_to_caption)
            >>> elements = loader.load("/path/to/lecture.mp4", segment_level_elements=True)
            >>> # Returns list of elements, one per video segment
        '''
