from _typeshed import Incomplete
from gllm_docproc.loader.base_loader import BaseLoader as BaseLoader
from gllm_docproc.loader.loader_utils import create_base_element_metadata as create_base_element_metadata, validate_file_extension as validate_file_extension
from gllm_docproc.model.element import Element as Element, TABLE as TABLE
from gllm_docproc.model.element_metadata import ElementMetadata as ElementMetadata, SMART_CRAWL as SMART_CRAWL
from typing import Any

class SmartCrawlJSONLoader(BaseLoader):
    """Loader for Smart Crawl JSON payloads.

    Extracts records from a Smart Crawl JSON file to list of Elements in dictionary format.
    Each record inside the top-level 'data' list maps to exactly one Element.

    1. All keys are extracted when no schema is provided.
    2. Only schema-listed keys are extracted when schema is provided, in the listed order.
    """
    logger: Incomplete
    def __init__(self) -> None:
        """Initialize the Smart Crawl JSON Loader."""
    def load(self, source: str, loaded_elements: list[dict[str, Any]] | None = None, **kwargs: Any) -> list[dict[str, Any]]:
        """Load and extract content from a Smart Crawl JSON file.

        Args:
            source (str): Path to the Smart Crawl JSON file.
            loaded_elements (list[dict[str, Any]] | None, optional): Previous loaded elements.
                Smart Crawl JSON Loader ignores this parameter. Defaults to None.
            **kwargs (Any): Additional keyword arguments.

        Kwargs:
            schema (list[str], optional): column names to extract. If not provided, all keys found across rows
                are used in first-seen order.
            original_source (str, optional): The original source of the document.

        Returns:
            list[dict[str, Any]]: Extracted elements as a list of Element in dictionary format.

        Raises:
            ValueError: If schema is provided but invalid.
        """
