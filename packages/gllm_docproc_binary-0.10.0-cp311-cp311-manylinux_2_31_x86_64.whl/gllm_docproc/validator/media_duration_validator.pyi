from _typeshed import Incomplete
from gllm_docproc.validator.base_validator import BaseValidator as BaseValidator
from gllm_docproc.validator.model.validator_input import ValidatorInput as ValidatorInput
from gllm_docproc.validator.model.validator_result import ValidatorResult as ValidatorResult

class MediaDurationValidator(BaseValidator):
    """Validator for checking that audio or video (media) file duration does not exceed a maximum limit.

    Duration is read using pymediainfo which supports a wide range of formats including
    audio (e.g. MP3, FLAC, OGG, M4A, WAV, AAC) and video (e.g. MP4, M4V, WebM, MKV, AVI, MOV)
    containers.
    """
    max_duration_seconds: Incomplete
    def __init__(self, max_duration_seconds: float = 1800.0, stop_on_failure: bool = True, applicable_extensions: list[str] | None = None) -> None:
        """Initialize the MediaDurationValidator.

        Args:
            max_duration_seconds (float, optional): The maximum allowed duration in seconds.
                Default is 1800.0 (30 minutes). Must be greater than 0.
            stop_on_failure (bool, optional): Whether to stop the validation process if this
                validator fails. Default is True.
            applicable_extensions (list[str] | None, optional): The list of file extensions
                that this validator is applicable to. Default is None (all extensions).
        """
