# Ontis

Local-first AI Knowledge OS for building your private ontology.

> Coming soon. This package is under active development.
