# Copyright (C) 2022 Rainer Garus
#
# This file is part of the ooresults Python package, a software to
# compute results of orienteering events.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.


import datetime
from enum import Enum
from typing import Optional

from ooresults.otypes import result_type
from ooresults.otypes import series_type
from ooresults.otypes import start_type
from ooresults.otypes.class_params import ClassParams
from ooresults.otypes.class_type import ClassInfoType
from ooresults.otypes.class_type import ClassType
from ooresults.otypes.club_type import ClubType
from ooresults.otypes.competitor_type import CompetitorBaseDataType
from ooresults.otypes.competitor_type import CompetitorType
from ooresults.otypes.course_type import CourseType
from ooresults.otypes.entry_type import EntryBaseDataType
from ooresults.otypes.entry_type import EntryType
from ooresults.otypes.event_type import EventType


class ClassUsedError(RuntimeError):
    pass


class CourseUsedError(RuntimeError):
    pass


class ClubUsedError(RuntimeError):
    pass


class CompetitorUsedError(RuntimeError):
    pass


class EventNotFoundError(RuntimeError):
    pass


class ConstraintError(RuntimeError):
    pass


class OperationalError(RuntimeError):
    pass


class DatabaseError(RuntimeError):
    pass


class TransactionMode(Enum):
    DEFERRED = "DEFERRED"
    IMMEDIATE = "IMMEDIATE"
    EXCLUSIVE = "EXCLUSIVE"


class Transaction:
    """Database transaction."""

    def __init__(self, db, mode: TransactionMode = TransactionMode.DEFERRED) -> None:
        self.db = db
        self.mode = mode

    def __enter__(self):
        self.db.start_transaction(mode=self.mode)
        return self

    def __exit__(self, exctype, excvalue, traceback) -> None:
        if exctype is not None:
            self.db.rollback()
        else:
            self.db.commit()


class Repo:
    def __init__(self) -> None:
        raise NotImplementedError

    def transaction(
        self, mode: TransactionMode = TransactionMode.DEFERRED
    ) -> Transaction:
        return Transaction(db=self, mode=mode)

    def start_transaction(
        self, mode: TransactionMode = TransactionMode.DEFERRED
    ) -> None:
        raise NotImplementedError

    def commit(self) -> None:
        raise NotImplementedError

    def rollback(self) -> None:
        raise NotImplementedError

    def close(self) -> None:
        raise NotImplementedError

    def get_classes(self, event_id: int) -> list[ClassInfoType]:
        raise NotImplementedError

    def get_class(self, id: int) -> ClassType:
        raise NotImplementedError

    def add_class(
        self,
        event_id: int,
        name: str,
        short_name: Optional[str],
        course_id: Optional[int],
        params: ClassParams,
    ) -> int:
        raise NotImplementedError

    def update_class(
        self,
        id: int,
        name: str,
        short_name: Optional[str],
        course_id: Optional[int],
        params: ClassParams,
    ) -> None:
        raise NotImplementedError

    def delete_classes(self, event_id: int) -> None:
        raise NotImplementedError

    def delete_class(self, id: int) -> None:
        raise NotImplementedError

    def get_courses(self, event_id: int) -> list[CourseType]:
        raise NotImplementedError

    def get_course(self, id: int) -> CourseType:
        raise NotImplementedError

    def add_course(
        self,
        event_id: int,
        name: str,
        length: Optional[float],
        climb: Optional[float],
        controls: list[str],
    ) -> int:
        raise NotImplementedError

    def update_course(
        self,
        id: int,
        name: str,
        length: Optional[float],
        climb: Optional[float],
        controls: list[str],
    ) -> None:
        raise NotImplementedError

    def delete_courses(self, event_id: int) -> None:
        raise NotImplementedError

    def delete_course(self, id: int) -> None:
        raise NotImplementedError

    def get_clubs(self) -> list[ClubType]:
        raise NotImplementedError

    def get_club(self, id: int) -> ClubType:
        raise NotImplementedError

    def add_club(self, name: str) -> int:
        raise NotImplementedError

    def update_club(self, id: int, name: str) -> None:
        raise NotImplementedError

    def delete_club(self, id: int) -> None:
        raise NotImplementedError

    def get_competitors(self) -> list[CompetitorType]:
        raise NotImplementedError

    def get_competitor(self, id: int) -> CompetitorType:
        raise NotImplementedError

    def get_competitor_by_name(
        self, first_name: str, last_name: str
    ) -> Optional[CompetitorType]:
        raise NotImplementedError

    def add_competitor(
        self,
        first_name: str,
        last_name: str,
        club_id: Optional[int],
        gender: str,
        year: Optional[int],
        chip: str,
    ) -> int:
        raise NotImplementedError

    def update_competitor(
        self,
        id: int,
        first_name: str,
        last_name: str,
        club_id: Optional[int],
        gender: str,
        year: Optional[int],
        chip: str,
    ) -> None:
        raise NotImplementedError

    def delete_competitor(self, id: int) -> None:
        raise NotImplementedError

    def add_many_competitors(
        self, list_of_competitors: list[CompetitorBaseDataType]
    ) -> None:
        raise NotImplementedError

    def get_entries(self, event_id: int) -> list[EntryType]:
        raise NotImplementedError

    def get_entry(self, id: int) -> EntryType:
        raise NotImplementedError

    def get_entry_ids_by_competitor(
        self, event_id: int, competitor_id: int
    ) -> list[int]:
        raise NotImplementedError

    def get_entries_by_name(
        self, event_id: int, first_name: str, last_name: str
    ) -> list[EntryType]:
        raise NotImplementedError

    def add_entry(
        self,
        event_id: int,
        competitor_id: int,
        class_id: int,
        club_id: Optional[int],
        not_competing: bool,
        chip: str,
        fields: dict[int, str],
        result: result_type.PersonRaceResult,
        start: start_type.PersonRaceStart,
    ) -> int:
        raise NotImplementedError

    def add_entry_result(
        self,
        event_id: int,
        chip: str,
        result: result_type.PersonRaceResult,
        start: start_type.PersonRaceStart,
    ) -> int:
        raise NotImplementedError

    def update_entry(
        self,
        id: int,
        class_id: int,
        club_id: Optional[int],
        not_competing: bool,
        chip: str,
        fields: dict[int, str],
        result: result_type.PersonRaceResult,
        start: start_type.PersonRaceStart,
    ) -> None:
        raise NotImplementedError

    def update_entry_result(
        self,
        id: int,
        chip: str,
        result: result_type.PersonRaceResult,
        start: start_type.PersonRaceStart,
    ) -> None:
        raise NotImplementedError

    def delete_entries(self, event_id: int) -> None:
        raise NotImplementedError

    def delete_entry(self, id: int) -> None:
        raise NotImplementedError

    def add_many_entries(self, list_of_entries: list[EntryBaseDataType]) -> None:
        raise NotImplementedError

    def get_events(self) -> list[EventType]:
        raise NotImplementedError

    def get_event(self, id: int) -> EventType:
        raise NotImplementedError

    def add_event(
        self,
        name: str,
        date: datetime.date,
        key: Optional[str],
        publish: bool,
        series: Optional[str],
        fields: list[str],
        streaming_address: Optional[str] = None,
        streaming_key: Optional[str] = None,
        streaming_enabled: Optional[bool] = None,
    ) -> int:
        raise NotImplementedError

    def update_event(
        self,
        id: int,
        name: str,
        date: datetime.date,
        key: Optional[str],
        publish: bool,
        series: Optional[str],
        fields: list[str],
        streaming_address: Optional[str] = None,
        streaming_key: Optional[str] = None,
        streaming_enabled: Optional[bool] = None,
    ) -> None:
        raise NotImplementedError

    def delete_event(self, id: int) -> None:
        raise NotImplementedError

    def get_series_settings(self) -> series_type.Settings:
        raise NotImplementedError

    def update_series_settings(self, settings: series_type.Settings) -> None:
        raise NotImplementedError
