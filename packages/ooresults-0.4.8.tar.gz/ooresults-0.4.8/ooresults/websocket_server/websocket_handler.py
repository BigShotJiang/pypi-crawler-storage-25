# Copyright (C) 2022 Rainer Garus
#
# This file is part of the ooresults Python package, a software to
# compute results of orienteering events.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.


import asyncio
import bz2
import copy
import dataclasses
import datetime
import functools
import json
import logging
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor

import tzlocal
import websockets.exceptions
from websockets.asyncio.server import ServerConnection

from ooresults import model
from ooresults.otypes import result_type
from ooresults.otypes.event_type import EventType
from ooresults.otypes.result_type import ResultStatus
from ooresults.otypes.result_type import SpStatus
from ooresults.repo.repo import EventNotFoundError
from ooresults.utils import render
from ooresults.websocket_server import streaming_status


@dataclasses.dataclass
class ConnectionParameter:
    event_id: int
    event_key: str
    key_valid: bool
    show_result: bool


class WebSocketHandler:
    def __init__(self, demo_reader: bool = False, import_stream: bool = False):
        self.demo_reader = demo_reader
        self.import_stream = import_stream
        self.connections: dict[ServerConnection, ConnectionParameter] = {}
        self.messages = []
        self.cardreader_status: dict[int, str] = {}
        self.executor = ThreadPoolExecutor(max_workers=2)
        self.update_result = asyncio.Event()
        streaming_status.status.register(awaitable=self.update_event)

        #
        # Cardreader status:
        #
        # readerOffline
        # readerDisconnected
        # readerConnected
        # cardInserted
        # cardRemoved
        # cardRead
        # result
        #

    async def send_new_result(self):
        while True:
            try:
                await asyncio.wait_for(self.update_result.wait(), timeout=60)
                self.update_result.clear()
            except asyncio.TimeoutError:
                pass

            try:
                d: defaultdict[int, list[ServerConnection]] = defaultdict(list)
                for conn, v in self.connections.items():
                    if conn.request.path == "/si1" and v.key_valid and v.show_result:
                        d[v.event_id].append(conn)

                for event_id, connections in d.items():
                    try:
                        (
                            event,
                            class_results,
                        ) = await asyncio.get_event_loop().run_in_executor(
                            executor=self.executor,
                            func=functools.partial(
                                model.results.event_class_results, event_id=event_id
                            ),
                        )

                        # display only finished entries
                        finished_class_results = []
                        for class_, ranked_results in class_results:
                            results = [
                                r
                                for r in ranked_results
                                if r.entry.result.status
                                not in (
                                    ResultStatus.INACTIVE,
                                    ResultStatus.ACTIVE,
                                    ResultStatus.DID_NOT_START,
                                )
                            ]
                            finished_class_results.append((class_, results))

                        html_code = render.si1_results(
                            event=event, class_results=finished_class_results
                        )
                        data = json.dumps({"status": "result", "data": html_code})

                        for conn in connections:
                            try:
                                await conn.send(data)
                            except websockets.exceptions.ConnectionClosed:
                                pass
                    except EventNotFoundError:
                        pass

            except asyncio.CancelledError:
                raise
            except Exception as e:
                logging.exception(e)

    async def update_event(self, event: EventType) -> None:
        # update connections
        for conn, value in self.connections.items():
            if event.id == value.event_id:
                value.key_valid = event.key == value.event_key

                if conn.request.path == "/si2":
                    await self.send(conn=conn, event=copy.deepcopy(event), message={})

    async def send_to_all(self, event: EventType, message: dict) -> None:
        connections = [c for c, v in self.connections.items() if event.id == v.event_id]
        for conn in connections:
            await self.send(conn=conn, event=copy.deepcopy(event), message=message)

    async def send(
        self, conn: ServerConnection, event: EventType, message: dict
    ) -> None:
        status = (
            self.cardreader_status[event.id]
            if event and event.id in self.cardreader_status
            else "readerOffline"
        )
        if conn.request.path == "/si2":
            stream_status = streaming_status.status.get(id=event.id)
            print("stream_status:", stream_status)
            data = render.si2_data(
                status=status,
                stream_status=stream_status,
                event=event,
                messages=self.messages,
            )
        else:
            if status != "cardRead":
                data = message.get("controlCard", "")
            elif message.get("error", None) is not None:
                data = render.si1_error(message=message)
            elif message.get("lastName", None) is not None:
                data = render.si1_data(message=message)
            else:
                data = ""
                # Cardreader status cardRead does not switch back to readerConnected.
                # Send readerConnected if no data exist.
                if status == "cardRead":
                    status = "readerConnected"
            data = json.dumps({"status": status, "data": str(data)})
        try:
            await conn.send(str(data))
        except websockets.exceptions.ConnectionClosed:
            pass

    async def handler(self, websocket: ServerConnection) -> None:
        addr = f"addr: {websocket.remote_address}, path: {websocket.request.path}"
        logging.info(f"WebSocket connected, {addr}")

        if websocket.request.path == "/import":
            event_key = websocket.request.headers.get("X-Event-Key", "")
            try:
                if self.import_stream:
                    async for message in websocket:
                        t1 = time.time()
                        try:
                            data = bz2.decompress(message)
                        except Exception:
                            data = message

                        await asyncio.get_event_loop().run_in_executor(
                            executor=self.executor,
                            func=functools.partial(
                                model.entries.import_iof_result_list,
                                event_key=event_key,
                                content=data,
                            ),
                        )
                        await websocket.send(json.dumps({"result": "ok"}))
                        t2 = time.time()
                        logging.info(
                            f"Importing result, {websocket.remote_address[0]}, {len(message)}, {t2 - t1:.3f}"
                        )

            except websockets.exceptions.ConnectionClosed:
                pass
            except EventNotFoundError:
                await websocket.send(json.dumps({"result": "eventNotFound"}))
            except Exception as e:
                logging.exception(e)
                await websocket.send(json.dumps({"result": "error"}))
            finally:
                await websocket.close()
                logging.info(f"WebSocket closed, {addr}")

        elif websocket.request.path == "/demo":
            event = None
            try:
                if self.demo_reader:
                    async for message in websocket:
                        # workaround to detect lost websocket connection in the browser
                        # see https://stackoverflow.com/questions/26971026/handling-connection-loss-with-websockets
                        if message == "__ping__":
                            await websocket.send("__pong__")
                        else:
                            print("WEBSOCKET RECEIVED", websocket, message)

                            item = json.loads(message)
                            #
                            # item = {
                            #     'key': 4711,
                            #     'code': ['Check', 'Start', '', '', '', '', '', '', '', '', 'Finish'],
                            #     'time': ['10:11:12', '', '', '', '', '', '', '', '', '', '10:23:23'],
                            #     'card': '1111',
                            # }
                            #

                            d = result_type.CardReaderMessage(
                                entry_type="cardRead",
                                entry_time=datetime.datetime.now(),
                                control_card=item.get("card", None),
                                result=None,
                            )

                            # add the event date to the times entered on the webpage
                            events = await asyncio.get_event_loop().run_in_executor(
                                executor=self.executor, func=model.events.get_events
                            )
                            date_of_event = datetime.date.today()
                            for e in events:
                                if e.key == item.get("key", None):
                                    date_of_event = e.date
                                    break

                            def parse_time(value: str) -> datetime.datetime:
                                return datetime.datetime.combine(
                                    date=date_of_event,
                                    time=datetime.datetime.strptime(
                                        value, "%H:%M:%S"
                                    ).time(),
                                    tzinfo=tzlocal.get_localzone(),
                                )

                            result = result_type.PersonRaceResult(
                                status=ResultStatus.FINISHED
                            )
                            _code = item["code"]
                            _time = item["time"]
                            if _code[0] == "Check" and _time[0] != "":
                                result.punched_check_time = parse_time(_time[0])
                            if _code[1] == "Start" and _time[1] != "":
                                result.punched_start_time = parse_time(_time[1])
                                result.si_punched_start_time = parse_time(_time[1])
                            if _code[-1] == "Finish" and _time[-1] != "":
                                result.punched_finish_time = parse_time(_time[-1])
                                result.si_punched_finish_time = parse_time(_time[-1])

                            result.start_time = result.punched_start_time
                            result.finish_time = result.punched_finish_time
                            for i in range(2, 10):
                                if _code[i] != "" and _time[i] != "":
                                    result.split_times.append(
                                        result_type.SplitTime(
                                            control_code=_code[i],
                                            punch_time=parse_time(_time[i]),
                                            si_punch_time=parse_time(_time[i]),
                                            status=SpStatus.ADDITIONAL,
                                        )
                                    )
                            d.result = result

                            try:
                                (
                                    status,
                                    event,
                                    res,
                                ) = await asyncio.get_event_loop().run_in_executor(
                                    executor=self.executor,
                                    func=functools.partial(
                                        model.results.store_cardreader_result,
                                        event_key=item["key"],
                                        item=d,
                                    ),
                                )
                            except EventNotFoundError as e:
                                raise RuntimeError(str(e))

                            self.cardreader_status[event.id] = status

                            if "entryTime" in res:
                                res["entryTime"] = res["entryTime"].strftime("%H:%M:%S")

                            if status == "cardRead":
                                self.messages.append(res.copy())
                            await self.send_to_all(
                                event=copy.deepcopy(event), message=res.copy()
                            )

                            res["readerStatus"] = status
                            res["event"] = event.name
                            if "status" in res:
                                res["status"] = res["status"].name
                            print(res)

                            if status == "cardRead":
                                self.update_result.set()

            except websockets.exceptions.ConnectionClosed:
                pass
            except Exception as e:
                logging.exception(e)
                await websocket.close()
            finally:
                logging.info(f"WebSocket closed, {addr}")
                if event:
                    if event.id in self.cardreader_status:
                        del self.cardreader_status[event.id]
                    await self.send_to_all(event=copy.deepcopy(event), message={})

        elif websocket.request.path == "/cardreader":
            event = None
            event_key = websocket.request.headers.get("X-Event-Key", "")
            try:
                print(f">>>>>> cardreader, key: {event_key}, {addr}")
                async for message in websocket:
                    try:
                        data = bz2.decompress(message)
                    except Exception:
                        raise RuntimeError("Data not bz2 encoded")

                    try:
                        item = json.loads(data.decode())
                    except Exception:
                        raise RuntimeError("Data not json deserialisable")

                    try:
                        item = model.results.parse_cardreader_log(item=item)
                    except Exception as e:
                        raise RuntimeError(str(e))

                    try:
                        (
                            status,
                            event,
                            res,
                        ) = await asyncio.get_event_loop().run_in_executor(
                            executor=self.executor,
                            func=functools.partial(
                                model.results.store_cardreader_result,
                                event_key=event_key,
                                item=item,
                            ),
                        )
                    except EventNotFoundError as e:
                        raise RuntimeError(str(e))

                    self.cardreader_status[event.id] = status

                    if "entryTime" in res:
                        res["entryTime"] = res["entryTime"].strftime("%H:%M:%S")

                    if status == "cardRead":
                        self.messages.append(res.copy())
                    await self.send_to_all(
                        event=copy.deepcopy(event), message=res.copy()
                    )

                    res["readerStatus"] = status
                    res["event"] = event.name
                    if "status" in res:
                        res["status"] = res["status"].name
                    print(res)
                    await websocket.send(json.dumps(res))

                    if status == "cardRead":
                        self.update_result.set()

            except websockets.exceptions.ConnectionClosed:
                pass
            except Exception as e:
                logging.exception(e)
                await websocket.send(str(e))
                await websocket.close()
            finally:
                logging.info(f"WebSocket closed, {addr}")
                if event:
                    if event.id in self.cardreader_status:
                        del self.cardreader_status[event.id]
                    await self.send_to_all(event=copy.deepcopy(event), message={})

        else:
            try:
                if websocket.request.path in ("/si1", "/si2"):
                    data = await websocket.recv()
                    event_id, event_key, results = data.split(",")
                    print(f">>>>>> websocket, id: {event_id}, key: {event_key}, {addr}")

                    # check event key
                    events = await asyncio.get_event_loop().run_in_executor(
                        executor=self.executor, func=model.events.get_events
                    )
                    for e in events:
                        if str(e.id) == event_id and e.key == event_key:
                            self.connections[websocket] = ConnectionParameter(
                                event_id=e.id,
                                event_key=e.key,
                                key_valid=True,
                                show_result=results == "true",
                            )
                            await self.send(conn=websocket, event=e, message={})
                            if websocket.request.path == "/si1":
                                self.update_result.set()
                            async for message in websocket:
                                # workaround to detect lost websocket connection in the browser
                                # see https://stackoverflow.com/questions/26971026/handling-connection-loss-with-websockets
                                if message == "__ping__":
                                    await websocket.send("__pong__")
                                else:
                                    print(f"WEBSOCKET RECEIVED, {addr}, {message}")
                                    break
                    await websocket.send("__no_access__")
            except websockets.exceptions.ConnectionClosed:
                pass
            finally:
                if websocket in self.connections:
                    del self.connections[websocket]
                await websocket.close()
                logging.info(f"WebSocket closed, {addr}")
