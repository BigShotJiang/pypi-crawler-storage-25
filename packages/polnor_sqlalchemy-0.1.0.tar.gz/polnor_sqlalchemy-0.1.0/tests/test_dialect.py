"""Unit tests for polnor-sqlalchemy — HTTP-mocked via responses."""

from __future__ import annotations

import pytest
import responses
from sqlalchemy import create_engine, text
from sqlalchemy.engine.url import make_url

from polnor_sqlalchemy.dialect import PolnorDialect
from polnor_sqlalchemy.types import normalise_type_name, to_sa_type


def test_dialect_is_registered_via_create_engine():
    """SQLAlchemy resolves `polnor://` via the entry point in pyproject.toml."""
    engine = create_engine(
        "polnor://api.polnor.test/?token=t&warehouse_id=wh-1",
        # lazy connect — don't actually hit the wire on engine creation
        _initialize=False,
    )
    assert isinstance(engine.dialect, PolnorDialect)
    assert engine.dialect.name == "polnor"


def test_create_connect_args_full_url():
    d = PolnorDialect()
    url = make_url("polnor://api.polnor.test:8080/?token=tok&warehouse_id=wh-1&workspace_slug=ws-a")
    args, kwargs = d.create_connect_args(url)
    assert args == []
    assert kwargs["api_url"] == "https://api.polnor.test:8080"
    assert kwargs["token"] == "tok"
    assert kwargs["warehouse_id"] == "wh-1"
    assert kwargs["workspace_slug"] == "ws-a"


def test_create_connect_args_password_as_token():
    """Some tools only know `user:password@host` URLs — accept that."""
    d = PolnorDialect()
    url = make_url("polnor://user:tok@api.polnor.test/?warehouse_id=wh-1")
    _, kwargs = d.create_connect_args(url)
    assert kwargs["token"] == "tok"


def test_create_connect_args_bare_url_falls_back():
    """`polnor://` with no host means: use env vars / config file."""
    d = PolnorDialect()
    url = make_url("polnor:///")
    _, kwargs = d.create_connect_args(url)
    # api_url not set → DBAPI's connect() will resolve from env/config
    assert "api_url" not in kwargs


def test_type_normalise():
    assert normalise_type_name("StringType()") == "STRING"
    assert normalise_type_name("LongType()") == "LONG"
    assert normalise_type_name("BIGINT") == "BIGINT"
    assert normalise_type_name("DECIMAL(10,2)") == "DECIMAL"
    assert normalise_type_name("BIGINT NOT NULL") == "BIGINT"
    assert normalise_type_name("varchar(255)") == "VARCHAR"


def test_type_mapping():
    import sqlalchemy.types as sa
    assert isinstance(to_sa_type("BIGINT"), sa.BigInteger)
    assert isinstance(to_sa_type("INT"), sa.Integer)
    assert isinstance(to_sa_type("STRING"), sa.String)
    assert isinstance(to_sa_type("BOOLEAN"), sa.Boolean)
    assert isinstance(to_sa_type("TIMESTAMP"), sa.DateTime)
    assert isinstance(to_sa_type("DOUBLE"), sa.Float)
    dec = to_sa_type("DECIMAL(12,4)")
    assert isinstance(dec, sa.Numeric)
    assert dec.precision == 12 and dec.scale == 4
    # Unknown type falls back to String (doesn't crash)
    assert isinstance(to_sa_type("WEIRD_TYPE"), sa.String)


@responses.activate
def test_execute_select_via_dbapi():
    """End-to-end: engine.connect().execute() should hit /sql/execute."""
    # Submit
    responses.post(
        "https://api.polnor.test/api/v1/sql/execute",
        json={"statement_id": "stmt-1"},
    )
    # Poll
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-1",
        json={"status": "succeeded", "duration_ms": 5},
    )
    # Results
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-1/results",
        json={
            "schema": [{"name": "x", "type": "BIGINT"}],
            "data": [[1], [2], [3]],
        },
    )

    engine = create_engine("polnor://api.polnor.test/?token=t&warehouse_id=wh-1")
    with engine.connect() as conn:
        rows = conn.execute(text("SELECT x FROM t")).fetchall()
    assert rows == [(1,), (2,), (3,)]


@responses.activate
def test_pandas_read_sql_no_warning():
    """pandas.read_sql with a sqlalchemy engine — the warning that came
    from raw DBAPI usage should be gone now."""
    import pandas as pd

    responses.post(
        "https://api.polnor.test/api/v1/sql/execute",
        json={"statement_id": "stmt-pd"},
    )
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-pd",
        json={"status": "succeeded"},
    )
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-pd/results",
        json={
            "schema": [{"name": "id", "type": "BIGINT"}, {"name": "name", "type": "STRING"}],
            "data": [[1, "alice"], [2, "bob"]],
        },
    )

    engine = create_engine("polnor://api.polnor.test/?token=t&warehouse_id=wh-1")
    # Use pd.read_sql_query — the version that's explicit about
    # "this is SQL, not a table name". The bare pd.read_sql can hit
    # schema reflection paths that don't suit warehouses without tables.
    df = pd.read_sql_query(text("SELECT * FROM t"), engine)
    assert list(df.columns) == ["id", "name"]
    assert len(df) == 2
