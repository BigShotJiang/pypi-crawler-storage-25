"""Type mapping Polnor / Iceberg ↔ SQLAlchemy.

Polnor's SQL warehouse returns column metadata in two flavours :

- DuckDB sidecar : ``"NUMBER"``, ``"STRING"``, ``"BOOLEAN"``, ``"DATE"``,
  ``"TIMESTAMP"``, ``"BIGINT"``, ``"DOUBLE"``, ``"DECIMAL(p,s)"``, etc.
  (DuckDB types as strings).
- Spark sidecar : ``"LongType()"``, ``"StringType()"``, ``"DoubleType()"``,
  ``"BooleanType()"``, ``"TimestampType()"``, ``"StructType(...)"``, etc.

We normalise both into SQLAlchemy generic types so the same engine works
regardless of which sidecar served the query.
"""

from __future__ import annotations

import re
from typing import Type

from sqlalchemy import types as sqltypes


# Pre-compile because reflection / type lookups are hot paths.
_DECIMAL_RE = re.compile(r"^DECIMAL\((\d+),(\d+)\)$", re.IGNORECASE)
_SPARK_TYPE_RE = re.compile(r"^(\w+)(?:Type\(\))?", re.IGNORECASE)


# Direct mapping table. Keys are upper-case so we lookup with .upper().
_TYPE_MAP: dict[str, Type[sqltypes.TypeEngine]] = {
    # Integer family
    "TINYINT":   sqltypes.SmallInteger,
    "SMALLINT":  sqltypes.SmallInteger,
    "INT":       sqltypes.Integer,
    "INTEGER":   sqltypes.Integer,
    "BIGINT":    sqltypes.BigInteger,
    "LONG":      sqltypes.BigInteger,        # Spark LongType
    "NUMBER":    sqltypes.Numeric,           # DuckDB generic numeric
    # Float / Double
    "FLOAT":     sqltypes.Float,
    "REAL":      sqltypes.Float,
    "DOUBLE":    sqltypes.Float,
    # Boolean
    "BOOLEAN":   sqltypes.Boolean,
    "BOOL":      sqltypes.Boolean,
    # String
    "STRING":    sqltypes.String,
    "VARCHAR":   sqltypes.String,
    "TEXT":      sqltypes.Text,
    "CHAR":      sqltypes.CHAR,
    # Binary
    "BINARY":    sqltypes.LargeBinary,
    "BYTES":     sqltypes.LargeBinary,
    "VARBINARY": sqltypes.LargeBinary,
    "BLOB":      sqltypes.LargeBinary,
    # Date/time
    "DATE":      sqltypes.Date,
    "TIMESTAMP": sqltypes.DateTime,
    "TIMESTAMPTZ": sqltypes.DateTime,
    "DATETIME":  sqltypes.DateTime,
    "TIME":      sqltypes.Time,
    # JSON / Struct / Map → fall back to JSON (lossy but usable for reads)
    "JSON":      sqltypes.JSON,
    "ARRAY":     sqltypes.ARRAY(sqltypes.String) if False else sqltypes.JSON,
    "STRUCT":    sqltypes.JSON,
    "MAP":       sqltypes.JSON,
}


def normalise_type_name(raw: str) -> str:
    """Reduce a DuckDB/Spark type string to its head keyword.

    Examples::

        normalise_type_name("StringType()")     == "STRING"
        normalise_type_name("DECIMAL(10,2)")    == "DECIMAL"
        normalise_type_name("BIGINT NOT NULL")  == "BIGINT"
    """
    if not raw:
        return ""
    s = raw.strip().upper()
    # Spark "LongType()" → "LONG"
    m = _SPARK_TYPE_RE.match(s)
    if m:
        head = m.group(1)
        if head.endswith("TYPE"):
            head = head[:-4]
        s = head
    # Strip trailing modifiers ("BIGINT NOT NULL" → "BIGINT")
    s = s.split()[0]
    # Strip parens ("VARCHAR(255)" → "VARCHAR")
    if "(" in s and not s.upper().startswith("DECIMAL"):
        s = s.split("(", 1)[0]
    return s


def to_sa_type(raw: str) -> sqltypes.TypeEngine:
    """Translate a Polnor column type string to a SQLAlchemy ``TypeEngine``.

    Falls back to ``String`` for unknown types — better than crashing,
    callers can always inspect the raw string via reflection metadata.
    """
    if not raw:
        return sqltypes.String()

    # Special case DECIMAL(p,s) — preserve precision / scale
    m = _DECIMAL_RE.match(raw.strip().upper())
    if m:
        return sqltypes.Numeric(precision=int(m.group(1)), scale=int(m.group(2)))

    head = normalise_type_name(raw)
    cls = _TYPE_MAP.get(head)
    if cls is None:
        return sqltypes.String()
    # Some classes need instantiation, some are already instances
    try:
        return cls()
    except TypeError:
        return cls
