"""SQL compiler overrides for the Polnor dialect.

SQLAlchemy's default compiler emits ANSI SQL. Polnor's engines (DuckDB
+ Spark) are mostly compatible, but a few quirks need tweaking :

- **Identifier quoting** : we use double quotes (standard SQL — DuckDB +
  Spark both accept). The default compiler already quotes with ``"…"``
  when the identifier needs quoting; we just don't switch to backticks.

- **LIMIT / OFFSET** : both engines support the standard ``LIMIT n OFFSET m``
  trailer. No translation needed.

- **CTE (WITH)** : the Polnor SQL router uses a regex on the first
  keyword to decide DuckDB vs Spark. A leading ``WITH`` routes to Spark
  (because some CTE-INSERT patterns must go to Spark). For pure-read
  CTEs the user can still call ``polnor.sql`` directly to bypass.

- **Quoted column inside expressions** : default compiler is fine.
"""

from __future__ import annotations

from sqlalchemy.sql import compiler


class PolnorSQLCompiler(compiler.SQLCompiler):
    """SQL compiler — currently inherits everything; placeholder for
    future per-engine workarounds.
    """

    # Polnor accepts standard LIMIT n OFFSET m. Override just for
    # documentation purposes; default impl is already this shape.
    def limit_clause(self, select, **kw):
        text = ""
        if select._limit_clause is not None:
            text += "\n LIMIT " + self.process(select._limit_clause, **kw)
        if select._offset_clause is not None:
            text += " OFFSET " + self.process(select._offset_clause, **kw)
        return text


class PolnorDDLCompiler(compiler.DDLCompiler):
    """DDL compiler — emits ``CREATE TABLE ... USING iceberg`` so the
    server-side router sends the DDL to Spark (the only engine that
    can write Iceberg).
    """

    def post_create_table(self, table):
        # Append ``USING iceberg`` so the Spark catalog creates an
        # Iceberg table instead of the default file-backed table.
        return " USING iceberg"


class PolnorTypeCompiler(compiler.GenericTypeCompiler):
    """Render SQLAlchemy types as Spark / DuckDB-friendly strings."""

    def visit_BIGINT(self, type_, **kw):
        return "BIGINT"

    def visit_INTEGER(self, type_, **kw):
        return "INT"

    def visit_SMALLINT(self, type_, **kw):
        return "SMALLINT"

    def visit_FLOAT(self, type_, **kw):
        return "DOUBLE"  # Spark prefers DOUBLE; DuckDB accepts both

    def visit_NUMERIC(self, type_, **kw):
        if type_.precision is not None and type_.scale is not None:
            return f"DECIMAL({type_.precision},{type_.scale})"
        return "DECIMAL(38,18)"

    def visit_BOOLEAN(self, type_, **kw):
        return "BOOLEAN"

    def visit_VARCHAR(self, type_, **kw):
        return "STRING"

    def visit_CHAR(self, type_, **kw):
        return "STRING"

    def visit_TEXT(self, type_, **kw):
        return "STRING"

    def visit_string(self, type_, **kw):
        return "STRING"

    def visit_DATE(self, type_, **kw):
        return "DATE"

    def visit_DATETIME(self, type_, **kw):
        return "TIMESTAMP"

    def visit_TIMESTAMP(self, type_, **kw):
        return "TIMESTAMP"

    def visit_LARGE_BINARY(self, type_, **kw):
        return "BINARY"

    def visit_JSON(self, type_, **kw):
        return "STRING"  # no native JSON type in Iceberg; users store as STRING
