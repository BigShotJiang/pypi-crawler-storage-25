"""SQLAlchemy dialect for Polnor.

Lets every SQLAlchemy-aware tool (pandas, FastAPI, Alembic, Superset,
Metabase, dbt-sql adapters, etc.) talk to a Polnor SQL warehouse over
a single ``polnor://`` URL.

Quick start::

    from sqlalchemy import create_engine, text
    engine = create_engine("polnor://api.polnor.net/?token=xxx&warehouse_id=wh-1")
    with engine.connect() as conn:
        rows = conn.execute(text("SELECT * FROM demo.orders LIMIT 5")).fetchall()

The dialect uses :mod:`polnor.dbapi` (PEP 249) under the hood, so any
fixes / features that land in the core SDK propagate automatically.
"""

from .dialect import PolnorDialect

__all__ = ["PolnorDialect"]
__version__ = "0.1.0"
