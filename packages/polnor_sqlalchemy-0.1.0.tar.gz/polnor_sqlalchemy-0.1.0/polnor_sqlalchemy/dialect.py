"""Main dialect class — wires URL parsing, DBAPI loading, reflection,
and the compilers together.

URL grammar :

    polnor://<host>[:<port>]/?token=<...>&warehouse_id=<...>[&workspace_slug=<...>]

The host part is the bare api hostname (e.g. ``api.polnor.net``) — we
auto-prefix ``https://``. ``port`` is rarely needed; if present, it's
passed through. Token + warehouse_id are query string args because
SQLAlchemy URLs don't have a place for "warehouse" in the standard
position.

A bare ``polnor://`` (no host) falls back to the SDK's auto-resolution
(env vars + ``~/.polnor/config.toml``). Handy for notebooks running
inside Polnor's own infrastructure.
"""

from __future__ import annotations

from sqlalchemy.engine import default
from sqlalchemy.engine.url import URL

from .compiler import PolnorDDLCompiler, PolnorSQLCompiler, PolnorTypeCompiler
from .types import to_sa_type


class PolnorDialect(default.DefaultDialect):
    name = "polnor"
    driver = "polnor"
    paramstyle = "qmark"
    statement_compiler = PolnorSQLCompiler
    ddl_compiler = PolnorDDLCompiler
    type_compiler = PolnorTypeCompiler
    supports_statement_cache = True

    # Auto-commit semantics — every statement is its own transaction
    # in Polnor (DuckDB/Spark both single-statement). SQLAlchemy 2.0
    # expects us to declare this explicitly.
    supports_sane_rowcount = True
    supports_sane_multi_rowcount = False
    supports_native_boolean = True
    supports_default_values = False
    supports_empty_insert = False
    supports_native_decimal = True
    supports_native_enum = False
    supports_multivalues_insert = True
    supports_simple_order_by_label = True

    # Polnor doesn't support per-connection schema search paths;
    # users qualify with ``catalog.namespace.table`` instead.
    @classmethod
    def import_dbapi(cls):
        import polnor.dbapi as dbapi
        return dbapi

    # Legacy SQLAlchemy <2.0 path — keep an alias for compatibility.
    @classmethod
    def dbapi(cls):  # pragma: no cover
        return cls.import_dbapi()

    def create_connect_args(self, url: URL):
        """Translate a sqlalchemy URL → kwargs for ``polnor.dbapi.connect()``.

        Accepts both ``token=...`` in the query string and ``user:pass@``
        (treats password as token, ignores user) to maximise compat with
        tools that only understand basic-auth URLs.
        """
        kwargs: dict[str, str] = {}

        # API URL = scheme (always https) + host [+ port]
        if url.host:
            api_url = f"https://{url.host}"
            if url.port:
                api_url += f":{url.port}"
            kwargs["api_url"] = api_url

        # Token : query string > url.password > env var (via polnor SDK)
        token = url.query.get("token") or url.password or None
        if token:
            kwargs["token"] = token

        # Warehouse: query string. Polnor's URLs put it here because
        # there's no standard slot for "warehouse" in DBAPI URLs.
        warehouse = url.query.get("warehouse_id") or url.query.get("warehouse")
        if warehouse:
            kwargs["warehouse_id"] = warehouse

        # Optional workspace pinning
        ws = url.query.get("workspace_slug") or url.query.get("workspace_id")
        if ws:
            kwargs["workspace_slug"] = ws

        return [], kwargs

    # --- Reflection ---

    def get_schema_names(self, connection, **kw):
        """List databases (Iceberg namespaces) in the workspace."""
        import polnor
        return [db["name"] for db in polnor.tables.list_databases()]

    def get_table_names(self, connection, schema=None, **kw):
        """List tables in a database."""
        import polnor
        db = schema or "default"
        try:
            return [t["name"] for t in polnor.tables.list(db)]
        except Exception:
            return []

    def get_columns(self, connection, table_name, schema=None, **kw):
        """Return SQLAlchemy column dicts for a table."""
        import polnor
        db = schema or "default"
        try:
            t = polnor.tables.get(db, table_name)
        except Exception:
            return []
        cols = []
        for c in t.get("columns") or []:
            cols.append({
                "name": c["name"],
                "type": to_sa_type(c.get("type") or "string"),
                "nullable": c.get("nullable", True),
                "default": c.get("default"),
                "autoincrement": False,
                "comment": c.get("description"),
            })
        return cols

    def get_pk_constraint(self, connection, table_name, schema=None, **kw):
        """Iceberg has no primary keys — return empty."""
        return {"constrained_columns": [], "name": None}

    def get_foreign_keys(self, connection, table_name, schema=None, **kw):
        """Iceberg has no FK constraints."""
        return []

    def get_indexes(self, connection, table_name, schema=None, **kw):
        """Iceberg has no traditional indexes (it has partition specs
        + sort orders; those are exposed via ``polnor.tables.get`` but
        we don't surface them as indexes for SQLAlchemy)."""
        return []

    def get_view_names(self, connection, schema=None, **kw):
        """Iceberg views are supported by Polnor but not surfaced
        separately from tables in the catalog API yet. Return empty
        so pandas / sqlalchemy schema reflection doesn't crash."""
        return []

    def get_materialized_view_names(self, connection, schema=None, **kw):
        return []

    def get_view_definition(self, connection, view_name, schema=None, **kw):
        return ""

    def get_unique_constraints(self, connection, table_name, schema=None, **kw):
        return []

    def get_check_constraints(self, connection, table_name, schema=None, **kw):
        return []

    def get_temp_table_names(self, connection, schema=None, **kw):
        return []

    def get_temp_view_names(self, connection, schema=None, **kw):
        return []

    def get_sequence_names(self, connection, schema=None, **kw):
        return []

    def has_table(self, connection, table_name, schema=None, **kw):
        try:
            self.get_columns(connection, table_name, schema=schema)
            return True
        except Exception:
            return False

    def do_rollback(self, dbapi_connection):
        """Polnor is auto-commit at the engine level; no-op."""
        pass

    def _check_unicode_returns(self, connection, additional_tests=None):
        """All strings come back as str — no need to probe."""
        return True

    def _check_unicode_description(self, connection):
        return True
