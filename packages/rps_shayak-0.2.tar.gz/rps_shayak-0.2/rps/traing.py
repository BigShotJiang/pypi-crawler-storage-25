import json
import random as r
from pathlib import Path

def train_with_dummy_data():
    user_file = Path.home() / ".shayak_bot_history.json"
    
 
    if user_file.exists():
        with open(user_file, "r") as f:
            data = json.load(f)
    else:
        data = {}

    print("Training bot with dummy patterns...")
    
    moves = ["R", "P", "S"]
    dummy_patterns = []

 
    for i1 in moves:
        for i2 in moves:
            for i3 in moves:
                for i4 in moves:
                     for i5 in moves:
                          dummy_patterns.append([i1, i2, i3, i4, i5])

    print(f"pARTTERN  {len(dummy_patterns)}  ")
    for i in range(1000):
  
        history = []
        for _ in range(5):
            history.append(r.choice(["R", "P", "S"]))
        
        key = ""
        for move in history:
            key += move
        
        
        if r.random() < 0.2: 
            user_move = r.choice(["R", "P", "S"])  
        else:
            pattern = r.choice(dummy_patterns)
            user_move = pattern[i % 3] 
        if key not in data:
            data[key] = {"R": 1, "P": 1, "S": 1}
        
        data[key][user_move] += 2 
    for pattern in dummy_patterns:
        key = "".join(pattern)
        
       
        if key not in data:
            data[key] = {"R": 1, "P": 1, "S": 1}
        
        
        last_move = pattern[-1]
        if last_move == "R":
            data[key]["P"] += 2  
        elif last_move == "P":
            data[key]["S"] += 2
        elif last_move == "S":
            data[key]["R"] += 2  
    with open(user_file, "w") as f:
        json.dump(data, f, indent=4)
        
    print("Training completed!")

if __name__ == "__main__":
    train_with_dummy_data()