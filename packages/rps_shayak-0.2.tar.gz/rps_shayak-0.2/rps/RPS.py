import random as r
import json
from pathlib import Path

from traing import train_with_dummy_data
def inteligance(data,history ):
    key=""
    for i in range(len(history)):
         key=key+history[i]
    if key not in data :
         return r.choice(["R","P","S"])
    temp=data[key]
    predict = max(temp, key=temp.get)
    counter = {"R": "P", "P": "S", "S": "R"}
    return counter[predict]

def update_learning(data,history, actual_user_move,computer_won):
    key=""
    for i in range(len(history)):
         key=key+history[i]
    if key not in data:
        data[key] = {"R": 1, "P": 1, "S": 1}
    if computer_won:
        data[key][actual_user_move] += 2  
    else:
        data[key][actual_user_move] -= 1  
    if data[key][actual_user_move] > 15:
                data[key][actual_user_move] = 15
        
            
    if data[key][actual_user_move] < 1:
                data[key][actual_user_move] = 1

    return data

def play_game():
    user_file=Path.home()/".shayak_bot_history.json"
    count=0
    
    try:
                  with open( user_file, "r") as f:
                      data = json.load(f)
                       
    except FileNotFoundError:
              train_with_dummy_data()
              with open( user_file, "r") as f:
                      data = json.load(f)
    com_score = 0
    user_score = 0
    prev_move = None
    option = ["R", "P", "S"]
    
    print('''
      !! WELCOME !!
           TO
    STONE PAPER SCISSORS

    Do you want to play ? (y/n)
    ''')
    
    ch = input().lower()
    if ch == "y":
        print('''
    Enter:
    R FOR STONE/ROCK
    P FOR PAPER
    S FOR SCISSORS
    ''')
    else:
        print("Goodbye!")
        return
    history=[]
    while com_score < 5 and user_score < 5:
         
        
        
        while True:
            user_ch = input("ENTER YOUR CHOICE: ").upper().strip()
            if user_ch not in option:
                print("Wrong choice! Try again.")
            else:
                break
        com_ch = inteligance(data,history)       
        print(f"COMPUTER CHOSE: {com_ch}")
        
       
        
        if com_ch == user_ch:
                  print("TIE! CHOICES ARE SAME")
                  data = update_learning(data, history, user_ch, False)

        elif ( user_ch == "R" and com_ch == "S") or (user_ch == "P" and com_ch == "R") or (user_ch == "S" and com_ch == "P"):
                  user_score += 1
                  data = update_learning(data, history, user_ch , False)
                  print("You won this round!")
                   
        else:
                 com_score += 1
                 data = update_learning(data, history, user_ch, True)
                 print("Computer won this round!")
                  
             
        print(f"Score -> YOU: {user_score} | COMPUTER: {com_score}\n")       
       
        history.append(user_ch)
        if len(history) > 5:
             history.pop(0)
             
        
    with open( user_file, "w") as f:
        json.dump(data,f)
    if com_score == 5:
        print("COMPUTER WINS!")
    else:
        print("USER WINS!")

if __name__ == "__main__":
    play_game()