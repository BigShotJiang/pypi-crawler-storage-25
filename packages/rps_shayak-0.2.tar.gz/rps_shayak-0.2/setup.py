# setup.py
from setuptools import setup, find_packages

setup(
    name="rps-shayak",
    version="0.2",
    packages=find_packages(),
    description="A simple Rock Paper Scissors game",
    author="Shayak",
    entry_points={
        'console_scripts': [
            
            'play-rps = rps.RPS:play_game',
        ],
    },
)