"""Tests for epsin.fetch — RSS parsing with mocked HTTP responses."""

from __future__ import annotations

import textwrap
import time
from unittest.mock import patch

import httpx
import pytest

from epsin.fetch import _extract_summary, _is_safe_url, _parse_feed_datetime, fetch_rss
from epsin.models import Item, Source

# ---------------------------------------------------------------------------
# Fixture: a realistic RSS 2.0 XML document
# ---------------------------------------------------------------------------

SAMPLE_RSS = textwrap.dedent("""\
    <?xml version="1.0" encoding="UTF-8"?>
    <rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
      <channel>
        <title>The Batch by Andrew Ng</title>
        <link>https://www.deeplearning.ai/the-batch/</link>
        <description>Weekly AI newsletter</description>
        <language>en</language>
        <item>
          <title>GPT-5 Announced with Multimodal Reasoning</title>
          <link>https://example.com/gpt5-announced</link>
          <description>&lt;p&gt;OpenAI announces GPT-5 with breakthrough multimodal reasoning capabilities. This changes everything.&lt;/p&gt;</description>
          <pubDate>Wed, 02 Apr 2025 10:00:00 +0000</pubDate>
        </item>
        <item>
          <title>AlphaFold 4 Predicts Protein Interactions</title>
          <link>https://example.com/alphafold4</link>
          <description>&lt;p&gt;DeepMind releases AlphaFold 4, capable of predicting protein-protein interactions with 95% accuracy!&lt;/p&gt;</description>
          <pubDate>Tue, 01 Apr 2025 09:00:00 +0000</pubDate>
        </item>
        <item>
          <title></title>
          <link>https://example.com/no-title</link>
          <description>Entry with no title should be skipped.</description>
          <pubDate>Mon, 31 Mar 2025 08:00:00 +0000</pubDate>
        </item>
      </channel>
    </rss>
""")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _MockResponse:
    """Lightweight httpx.Response stand-in."""

    def __init__(self, text: str, status_code: int = 200):
        self.text = text
        self.status_code = status_code

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            raise httpx.HTTPStatusError(
                "error",
                request=httpx.Request("GET", "http://x"),
                response=httpx.Response(self.status_code),
            )


# ---------------------------------------------------------------------------
# Tests: fetch_rss
# ---------------------------------------------------------------------------


class TestFetchRss:
    """Tests for the fetch_rss function."""

    @patch("epsin.fetch.httpx.get")
    def test_parses_entries(self, mock_get: patch) -> None:
        """Parses RSS entries into Item objects."""
        mock_get.return_value = _MockResponse(SAMPLE_RSS)
        source = Source(name="The Batch", url="https://example.com/feed.xml", rss="https://example.com/feed.xml")
        items = fetch_rss(source)

        # The empty-title entry should be skipped -> 2 items
        assert len(items) == 2

        first = items[0]
        assert isinstance(first, Item)
        assert first.source == "The Batch"
        assert first.title == "GPT-5 Announced with Multimodal Reasoning"
        assert first.url == "https://example.com/gpt5-announced"
        assert first.date.startswith("2025-04-02")
        assert "OpenAI" in first.summary

    @patch("epsin.fetch.httpx.get")
    def test_summary_first_sentence(self, mock_get: patch) -> None:
        """Summary contains only the first sentence, truncated to 120 chars."""
        mock_get.return_value = _MockResponse(SAMPLE_RSS)
        source = Source(name="The Batch", url="https://example.com/feed.xml", rss="https://example.com/feed.xml")
        items = fetch_rss(source)

        # Second entry: first sentence ends at "accuracy!"
        second = items[1]
        assert "95% accuracy" in second.summary
        assert len(second.summary) <= 120

    @patch("epsin.fetch.httpx.get")
    def test_skips_empty_title(self, mock_get: patch) -> None:
        """Entries with empty titles are silently skipped."""
        mock_get.return_value = _MockResponse(SAMPLE_RSS)
        source = Source(name="The Batch", url="https://example.com/feed.xml", rss="https://example.com/feed.xml")
        items = fetch_rss(source)
        assert all(it.title for it in items)

    @patch("epsin.fetch.httpx.get")
    def test_uses_url_when_no_rss(self, mock_get: patch) -> None:
        """Falls back to source.url when source.rss is None."""
        mock_get.return_value = _MockResponse(SAMPLE_RSS)
        source = Source(name="The Batch", url="https://example.com/feed.xml", rss=None)
        items = fetch_rss(source)
        assert len(items) == 2

    def test_ssrf_rejects_private_ip(self) -> None:
        """SSRF protection blocks private IP addresses."""
        source = Source(name="Evil", url="http://192.168.1.1/feed.xml", rss="http://192.168.1.1/feed.xml")
        with pytest.raises(ValueError, match="SSRF"):
            fetch_rss(source)

    def test_ssrf_rejects_localhost(self) -> None:
        """SSRF protection blocks localhost."""
        source = Source(name="Evil", url="http://127.0.0.1/feed.xml", rss="http://127.0.0.1/feed.xml")
        with pytest.raises(ValueError, match="SSRF"):
            fetch_rss(source)

    def test_ssrf_rejects_non_http(self) -> None:
        """SSRF protection blocks non-HTTP schemes."""
        source = Source(name="Evil", url="file:///etc/passwd", rss="file:///etc/passwd")
        with pytest.raises(ValueError, match="SSRF"):
            fetch_rss(source)


# ---------------------------------------------------------------------------
# Tests: _parse_feed_datetime
# ---------------------------------------------------------------------------


class TestParseFeedDatetime:
    """Tests for _parse_feed_datetime."""

    def test_struct_time_published(self) -> None:
        """Parses published_parsed struct_time into ISO 8601."""

        class Entry:
            published_parsed = time.struct_time((2025, 4, 2, 10, 0, 0, 2, 92, 0))

        result = _parse_feed_datetime(Entry())
        assert result == "2025-04-02T10:00:00+00:00"

    def test_fallback_raw_string(self) -> None:
        """Falls back to parsing raw string date fields."""

        class Entry:
            published_parsed = None
            updated_parsed = None
            created_parsed = None
            published = "2025-04-02T10:00:00Z"
            updated = ""
            created = ""

        result = _parse_feed_datetime(Entry())
        assert result.startswith("2025-04-02")

    def test_no_date_returns_empty(self) -> None:
        """Returns empty string when no date fields are present."""

        class Entry:
            pass

        assert _parse_feed_datetime(Entry()) == ""


# ---------------------------------------------------------------------------
# Tests: _extract_summary
# ---------------------------------------------------------------------------


class TestExtractSummary:
    """Tests for _extract_summary."""

    def test_strips_html(self) -> None:
        """Strips HTML tags and extracts first sentence."""

        class Entry:
            summary = "<p>Hello <b>world</b>. Second sentence.</p>"

        result = _extract_summary(Entry())
        assert result == "Hello world"

    def test_truncates_long_text(self) -> None:
        """Truncates to 120 characters."""

        class Entry:
            summary = "x" * 300

        result = _extract_summary(Entry())
        assert len(result) <= 120

    def test_empty_summary(self) -> None:
        """Returns empty string for entries with no summary."""

        class Entry:
            pass

        assert _extract_summary(Entry()) == ""


# ---------------------------------------------------------------------------
# Tests: _is_safe_url
# ---------------------------------------------------------------------------


class TestIsSafeUrl:
    """Tests for _is_safe_url."""

    def test_allows_public_domain(self) -> None:
        assert _is_safe_url("https://example.com/feed.xml") is True

    def test_blocks_private_ip(self) -> None:
        assert _is_safe_url("http://10.0.0.1/feed.xml") is False

    def test_blocks_localhost(self) -> None:
        assert _is_safe_url("http://127.0.0.1/feed.xml") is False

    def test_blocks_file_scheme(self) -> None:
        assert _is_safe_url("file:///etc/passwd") is False

    def test_blocks_no_host(self) -> None:
        assert _is_safe_url("http:///feed.xml") is False

    def test_blocks_unresolvable(self) -> None:
        assert _is_safe_url("http://this-domain-definitely-does-not-exist-xyz.invalid/feed.xml") is False
