"""Tests for epsin.fetch — web scrape extraction with fixture HTML."""

from __future__ import annotations

import textwrap
from unittest.mock import patch

import pytest

from epsin.fetch import (
    _extract_article_links,
    _extract_single_page,
    fetch_scrape,
    fetch_source,
)
from epsin.models import Item, Source


# ---------------------------------------------------------------------------
# Fixture HTML
# ---------------------------------------------------------------------------

BLOG_LIST_HTML = textwrap.dedent("""\
    <!DOCTYPE html>
    <html>
    <head><title>AI Blog</title></head>
    <body>
      <article>
        <h2><a href="/posts/gpt-5-launch">GPT-5 Launches With Reasoning</a></h2>
        <p>Summary of the new model release.</p>
      </article>
      <article>
        <h2><a href="/posts/claude-update">Claude Gets Tool Use</a></h2>
        <p>Anthropic announces major update.</p>
      </article>
      <article>
        <h2><a href="/posts/gemini-news">Gemini 2.0 Announced</a></h2>
        <p>Google DeepMind unveils Gemini 2.0.</p>
      </article>
    </body>
    </html>
""")

SINGLE_ARTICLE_HTML = textwrap.dedent("""\
    <!DOCTYPE html>
    <html>
    <head>
      <title>Breaking: New AI Model Released</title>
      <meta property="article:published_time" content="2026-04-01T10:00:00Z" />
    </head>
    <body>
      <article>
        <h1>Breaking: New AI Model Released</h1>
        <p>A major AI lab has released a groundbreaking new model that achieves
        state-of-the-art results on all major benchmarks. The model uses a novel
        architecture that combines transformer layers with recurrent connections,
        enabling more efficient long-context processing.</p>
        <p>Experts predict this will reshape the competitive landscape of AI
        development for years to come. Early testers report significant improvements
        in coding, reasoning, and creative tasks.</p>
      </article>
    </body>
    </html>
""")

ARTICLE_WITH_TRAFILATURA = textwrap.dedent("""\
    <!DOCTYPE html>
    <html>
    <head>
      <title>Test Article Title</title>
    </head>
    <body>
      <p>This is the main content of the article. It contains enough text to be
      considered a real article and not just a snippet. The content discusses
      important developments in the field of artificial intelligence and machine
      learning research.</p>
    </body>
    </html>
""")

POST_TITLE_BLOG_HTML = textwrap.dedent("""\
    <!DOCTYPE html>
    <html>
    <head><title>Blog</title></head>
    <body>
      <div class="post-title"><a href="https://example.com/post1">First Post Title Here</a></div>
      <div class="post-title"><a href="https://example.com/post2">Second Post Title Here</a></div>
    </body>
    </html>
""")

HEADING_LINKS_HTML = textwrap.dedent("""\
    <!DOCTYPE html>
    <html>
    <head><title>News</title></head>
    <body>
      <h2><a href="https://example.com/a">Headline One</a></h2>
      <h2><a href="https://example.com/b">Headline Two</a></h2>
      <h3><a href="https://example.com/c">Sub Headline Three</a></h3>
    </body>
    </html>
""")

EMPTY_PAGE_HTML = textwrap.dedent("""\
    <!DOCTYPE html>
    <html>
    <head><title></title></head>
    <body></body>
    </html>
""")


# ---------------------------------------------------------------------------
# _extract_article_links tests
# ---------------------------------------------------------------------------


class TestExtractArticleLinks:
    """Test _extract_article_links with various HTML structures."""

    def test_finds_article_tag_links(self) -> None:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(BLOG_LIST_HTML, "html.parser")
        links = _extract_article_links(soup, "https://example.com")
        assert len(links) == 3
        assert "https://example.com/posts/gpt-5-launch" in links
        assert "https://example.com/posts/claude-update" in links
        assert "https://example.com/posts/gemini-news" in links

    def test_resolves_relative_urls(self) -> None:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(BLOG_LIST_HTML, "html.parser")
        links = _extract_article_links(soup, "https://example.com")
        for link in links:
            assert link.startswith("http")

    def test_finds_post_title_links(self) -> None:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(POST_TITLE_BLOG_HTML, "html.parser")
        links = _extract_article_links(soup, "https://example.com")
        assert len(links) == 2
        assert "https://example.com/post1" in links

    def test_finds_heading_links(self) -> None:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(HEADING_LINKS_HTML, "html.parser")
        links = _extract_article_links(soup, "https://example.com")
        assert len(links) == 3

    def test_deduplicates_links(self) -> None:
        html = textwrap.dedent("""\
            <html><body>
              <article><h2><a href="/same">Title A</a></h2></article>
              <article><h2><a href="/same">Title B</a></h2></article>
            </body></html>
        """)
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(html, "html.parser")
        links = _extract_article_links(soup, "https://example.com")
        assert len(links) == 1

    def test_empty_page(self) -> None:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(EMPTY_PAGE_HTML, "html.parser")
        links = _extract_article_links(soup, "https://example.com")
        assert links == []

    def test_respects_max_links(self) -> None:
        html = "<html><body>"
        for i in range(30):
            html += f'<article><a href="/post/{i}">Post {i}</a></article>'
        html += "</body></html>"
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(html, "html.parser")
        links = _extract_article_links(soup, "https://example.com", max_links=5)
        assert len(links) == 5


# ---------------------------------------------------------------------------
# _extract_single_page tests
# ---------------------------------------------------------------------------


class TestExtractSinglePage:
    """Test _extract_single_page with fixture HTML."""

    def test_extracts_title_from_trafilatura(self) -> None:
        result = _extract_single_page(
            ARTICLE_WITH_TRAFILATURA, "https://example.com/test"
        )
        assert result["title"] == "Test Article Title"
        assert result["content_md"]  # non-empty content

    def test_extracts_date_from_meta_tag(self) -> None:
        result = _extract_single_page(
            SINGLE_ARTICLE_HTML, "https://example.com/breaking"
        )
        assert result["date"] == "2026-04-01"

    def test_fallback_title_from_html_title_tag(self) -> None:
        result = _extract_single_page(
            SINGLE_ARTICLE_HTML, "https://example.com/breaking"
        )
        assert "New AI Model Released" in result["title"]

    def test_empty_page_returns_empty(self) -> None:
        result = _extract_single_page(EMPTY_PAGE_HTML, "https://example.com")
        assert result["title"] == ""
        assert result["content_md"] == ""


# ---------------------------------------------------------------------------
# fetch_scrape tests (mocked HTTP)
# ---------------------------------------------------------------------------


class TestFetchScrape:
    """Test fetch_scrape with mocked HTTP responses."""

    @patch("epsin.fetch._fetch_html")
    def test_blog_list_page_extracts_multiple_items(
        self, mock_fetch: pytest.MonkeyPatch
    ) -> None:
        source = Source(name="Test Blog", url="https://blog.example.com")

        # First call: list page; subsequent calls: individual articles
        article_html = textwrap.dedent("""\
            <html><head>
              <title>GPT-5 Launches With Reasoning</title>
            </head><body>
              <p>The full article text about GPT-5 is quite detailed and long enough
              for trafilatura to extract meaningful content from the page.</p>
            </body></html>
        """)
        mock_fetch.side_effect = [BLOG_LIST_HTML, article_html, article_html, article_html]

        items = fetch_scrape(source)
        assert len(items) == 3
        assert all(isinstance(i, Item) for i in items)
        assert items[0].source == "Test Blog"
        assert items[0].url == "https://blog.example.com/posts/gpt-5-launch"

    @patch("epsin.fetch._fetch_html")
    def test_single_article_page(self, mock_fetch: pytest.MonkeyPatch) -> None:
        source = Source(name="Test", url="https://example.com/article")

        mock_fetch.return_value = SINGLE_ARTICLE_HTML
        items = fetch_scrape(source)

        assert len(items) == 1
        assert items[0].url == "https://example.com/article"
        assert "New AI Model Released" in items[0].title
        assert items[0].date == "2026-04-01"

    @patch("epsin.fetch._fetch_html")
    def test_empty_page_returns_empty_list(self, mock_fetch: pytest.MonkeyPatch) -> None:
        source = Source(name="Empty", url="https://example.com")

        mock_fetch.return_value = EMPTY_PAGE_HTML
        items = fetch_scrape(source)
        assert items == []

    @patch("epsin.fetch._fetch_html")
    def test_http_failure_returns_empty(self, mock_fetch: pytest.MonkeyPatch) -> None:
        source = Source(name="Down", url="https://down.example.com")

        mock_fetch.return_value = ""
        items = fetch_scrape(source)
        assert items == []

    def test_no_url_returns_empty(self) -> None:
        source = Source(name="NoURL", url="")
        items = fetch_scrape(source)
        assert items == []


# ---------------------------------------------------------------------------
# fetch_source dispatcher tests
# ---------------------------------------------------------------------------


class TestFetchSource:
    """Test fetch_source dispatcher with RSS-first fallback to scrape."""

    @patch("epsin.fetch.fetch_scrape")
    @patch("epsin.fetch.fetch_rss")
    def test_rss_succeeds_no_scrape(
        self, mock_rss: pytest.MonkeyPatch, mock_scrape: pytest.MonkeyPatch
    ) -> None:
        source = Source(
            name="RSS Blog",
            url="https://example.com",
            rss="https://example.com/feed.xml",
        )
        mock_rss.return_value = [
            Item(source="RSS Blog", title="Post", url="https://example.com/post",
                 date="2026-04-01", summary="test"),
        ]

        items = fetch_source(source)
        assert len(items) == 1
        mock_scrape.assert_not_called()

    @patch("epsin.fetch.fetch_scrape")
    @patch("epsin.fetch.fetch_rss")
    def test_rss_empty_falls_back_to_scrape(
        self, mock_rss: pytest.MonkeyPatch, mock_scrape: pytest.MonkeyPatch
    ) -> None:
        source = Source(
            name="No Feed",
            url="https://example.com",
            rss="https://example.com/feed.xml",
        )
        mock_rss.return_value = []
        mock_scrape.return_value = [
            Item(source="No Feed", title="Scraped", url="https://example.com/s",
                 date="", summary=""),
        ]

        items = fetch_source(source)
        assert len(items) == 1
        assert items[0].title == "Scraped"
        mock_scrape.assert_called_once()

    @patch("epsin.fetch.fetch_scrape")
    @patch("epsin.fetch.fetch_rss")
    def test_rss_exception_falls_back_to_scrape(
        self, mock_rss: pytest.MonkeyPatch, mock_scrape: pytest.MonkeyPatch
    ) -> None:
        source = Source(
            name="Broken RSS",
            url="https://example.com",
            rss="https://example.com/feed.xml",
        )
        mock_rss.side_effect = ConnectionError("network error")
        mock_scrape.return_value = [
            Item(source="Broken RSS", title="Fallback", url="https://example.com/f",
                 date="", summary=""),
        ]

        items = fetch_source(source)
        assert len(items) == 1
        assert items[0].title == "Fallback"

    @patch("epsin.fetch.fetch_scrape")
    def test_no_rss_url_goes_straight_to_scrape(
        self, mock_scrape: pytest.MonkeyPatch
    ) -> None:
        source = Source(
            name="Scrape Only",
            url="https://example.com",
        )
        mock_scrape.return_value = [
            Item(source="Scrape Only", title="Direct", url="https://example.com/d",
                 date="", summary=""),
        ]

        items = fetch_source(source)
        assert len(items) == 1
        mock_scrape.assert_called_once_with(source)

    @patch("epsin.fetch.fetch_scrape")
    def test_both_fail_returns_empty(self, mock_scrape: pytest.MonkeyPatch) -> None:
        source = Source(
            name="Dead",
            url="https://dead.example.com",
        )
        mock_scrape.side_effect = RuntimeError("everything broken")

        items = fetch_source(source)
        assert items == []

    @patch("epsin.fetch._enrich_with_content")
    @patch("epsin.fetch.fetch_scrape")
    @patch("epsin.fetch.fetch_rss")
    def test_include_content_enriches_rss_items(
        self, mock_rss: pytest.MonkeyPatch, mock_scrape: pytest.MonkeyPatch,
        mock_enrich: pytest.MonkeyPatch,
    ) -> None:
        source = Source(
            name="Rich",
            url="https://example.com",
            rss="https://example.com/feed.xml",
        )
        rss_items = [
            Item(source="Rich", title="Post", url="https://example.com/post",
                 date="2026-04-01", summary="test"),
        ]
        mock_rss.return_value = rss_items
        mock_enrich.return_value = rss_items

        items = fetch_source(source, include_content=True)
        assert len(items) == 1
        mock_enrich.assert_called_once()
        mock_scrape.assert_not_called()


# ---------------------------------------------------------------------------
# SSRF protection integration test
# ---------------------------------------------------------------------------


class TestSSRFProtection:
    """Test that SSRF-blocked URLs return safely."""

    def test_scrape_blocks_private_ip(self) -> None:
        source = Source(name="Internal", url="http://192.168.1.1/admin")
        items = fetch_scrape(source)
        assert items == []

    def test_scrape_blocks_localhost(self) -> None:
        source = Source(name="Local", url="http://localhost:8080/secret")
        items = fetch_scrape(source)
        assert items == []
