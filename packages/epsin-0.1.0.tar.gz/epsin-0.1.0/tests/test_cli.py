"""Tests for epsin CLI (cyclopts-based)."""

from __future__ import annotations

import copy
import json
import textwrap
from io import StringIO
from pathlib import Path
from unittest.mock import patch

import pytest

from epsin.cli import app
from epsin.models import Item, Source


# ── fixtures ──────────────────────────────────────────────────────────

SAMPLE_CONFIG_YAML = textwrap.dedent("""\
    sources:
      - name: test-rss
        url: https://example.com/feed.xml
        rss: https://example.com/feed.xml
        tags: [ai, ml]
      - name: test-blog
        url: https://example.com/blog
        tags: [llm]
""").encode()

SAMPLE_ITEMS = [
    Item(
        source="test-rss",
        title="GPT-5 announced",
        url="https://example.com/gpt5",
        date="2025-06-01",
        summary="Big news from OpenAI.",
        content_md="# GPT-5\n\nBig news!",
        tags=["ai", "ml"],
    ),
    Item(
        source="test-blog",
        title="Open-source LLMs in 2025",
        url="https://example.com/oss-llms",
        date="2025-05-20",
        summary="A round-up of open-source models.",
        content_md=None,
        tags=["llm"],
    ),
]


@pytest.fixture()
def config_file(tmp_path: Path):
    p = tmp_path / "epsin.yaml"
    p.write_bytes(SAMPLE_CONFIG_YAML)
    return str(p)


def _run(args: list[str], exit_on_error: bool = False) -> tuple[int, str]:
    """Invoke the cyclopts app and capture stdout. Returns (exit_code, output)."""
    import sys

    buf = StringIO()
    old_stdout = sys.stdout
    sys.stdout = buf
    try:
        app(args, exit_on_error=exit_on_error)
        code = 0
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else 1
    finally:
        sys.stdout = old_stdout
    return code, buf.getvalue()


def _make_extractor_stub(items):
    """Return a mock extractor module with a fetch method."""
    class _StubExtractor:
        @staticmethod
        def fetch(source, *, full=False):
            return copy.deepcopy(items)
    return _StubExtractor()


# ── top-level commands ────────────────────────────────────────────────


class TestMainGroup:
    """Tests for the top-level ``epsin`` group."""

    def test_help(self):
        code, output = _run(["--help"])
        assert code == 0
        assert "epsin" in output.lower() or "newsletter" in output.lower()

    def test_version(self):
        code, output = _run(["--version"])
        assert code == 0
        assert "0.1.0" in output


# ── epsin fetch ────────────────────────────────────────────────────────


class TestFetch:
    """Tests for ``epsin fetch``."""

    def _patch_resolve(self, items=None):
        """Patch extractors.resolve to return a stub extractor."""
        if items is None:
            items = SAMPLE_ITEMS
        stub = _make_extractor_stub(items)
        return patch("epsin.cli.resolve", return_value=stub)

    def test_fetch_empty(self, config_file):
        with self._patch_resolve(items=[]):
            code, output = _run(["fetch", "--config", config_file])
        assert code == 0
        assert output.strip() == ""

    def test_fetch_outputs_jsonl(self, config_file):
        with self._patch_resolve():
            code, output = _run(["fetch", "--config", config_file])
        assert code == 0
        lines = [line for line in output.strip().splitlines() if line.strip()]
        assert len(lines) == 4  # 2 sources x 2 items each
        obj = json.loads(lines[0])
        assert "source" in obj
        assert "title" in obj

    def test_fetch_strips_content_by_default(self, config_file):
        with self._patch_resolve():
            code, output = _run(["fetch", "--config", config_file])
        lines = [line for line in output.strip().splitlines() if line.strip()]
        obj = json.loads(lines[0])
        assert "content_md" not in obj

    def test_fetch_full_includes_content(self, config_file):
        with self._patch_resolve():
            code, output = _run(["fetch", "--full", "--config", config_file])
        lines = [line for line in output.strip().splitlines() if line.strip()]
        obj = json.loads(lines[0])
        assert obj["content_md"] == "# GPT-5\n\nBig news!"

    def test_fetch_source_filter(self, config_file):
        with self._patch_resolve():
            code, output = _run(["fetch", "--source", "test-rss", "--config", config_file])
        assert code == 0

    def test_fetch_unknown_source(self, config_file):
        with self._patch_resolve():
            code, output = _run(["fetch", "--source", "nonexistent", "--config", config_file])
        assert code == 1

    def test_fetch_tag_filter(self, config_file):
        with self._patch_resolve():
            code, output = _run(["fetch", "--tag", "llm", "--config", config_file])
        assert code == 0
        lines = [line for line in output.strip().splitlines() if line.strip()]
        for line in lines:
            obj = json.loads(line)
            assert "llm" in obj["tags"]

    def test_fetch_since_filter(self, config_file):
        with self._patch_resolve():
            code, output = _run(["fetch", "--since", "2025-05-25", "--config", config_file])
        assert code == 0
        lines = [line for line in output.strip().splitlines() if line.strip()]
        assert len(lines) == 2  # 2 sources x 1 matching item
        obj = json.loads(lines[0])
        assert obj["title"] == "GPT-5 announced"

    def test_fetch_json_envelope(self, config_file):
        with self._patch_resolve():
            code, output = _run(["fetch", "--json", "--config", config_file])
        assert code == 0
        envelope = json.loads(output)
        assert envelope["ok"] is True
        assert envelope["command"] == "epsin fetch"
        assert "items" in envelope["result"]
        assert envelope["result"]["count"] == 4

    def test_fetch_no_config_file(self):
        with self._patch_resolve(items=[]):
            code, output = _run(["fetch"])
        assert code == 0


# ── epsin sources list ────────────────────────────────────────────────


class TestSourcesList:
    """Tests for ``epsin sources list``."""

    def test_sources_list(self, config_file):
        code, output = _run(["sources", "list", "--config", config_file])
        assert code == 0
        assert "test-rss" in output
        assert "test-blog" in output

    def test_sources_list_empty(self):
        with patch("epsin.cli.load_sources", return_value=[]):
            code, output = _run(["sources", "list"])
        assert code == 0
        assert "No sources" in output

    def test_sources_list_json(self, config_file):
        code, output = _run(["sources", "list", "--json", "--config", config_file])
        assert code == 0
        envelope = json.loads(output)
        assert envelope["ok"] is True
        assert envelope["result"]["count"] == 2


# ── epsin sources check ───────────────────────────────────────────────


class TestSourcesCheck:
    """Tests for ``epsin sources check``."""

    def test_sources_check_ok(self, config_file):
        fake_resp = type("Resp", (), {"status_code": 200})()
        with patch("epsin.cli.httpx.head", return_value=fake_resp):
            code, output = _run(["sources", "check", "--config", config_file])
        assert code == 0
        assert "OK" in output

    def test_sources_check_http_error(self, config_file):
        import httpx

        with patch("epsin.cli.httpx.head", side_effect=httpx.ConnectError("refused")):
            code, output = _run(["sources", "check", "--config", config_file])
        assert code == 0
        assert "ERROR" in output

    def test_sources_check_json(self, config_file):
        fake_resp = type("Resp", (), {"status_code": 200})()
        with patch("epsin.cli.httpx.head", return_value=fake_resp):
            code, output = _run(["sources", "check", "--json", "--config", config_file])
        assert code == 0
        envelope = json.loads(output)
        assert envelope["ok"] is True
        assert envelope["result"]["healthy"] == 2


# ── output formatters ─────────────────────────────────────────────────


class TestFormatJsonl:
    """Tests for output.format_jsonl."""

    def test_empty(self):
        from epsin.output import format_jsonl
        assert format_jsonl([]) == ""

    def test_single_item(self):
        from epsin.output import format_jsonl
        item = Item(source="s", title="t", url="http://x", date="2025-01-01", summary="sum", tags=["a"])
        out = format_jsonl([item])
        obj = json.loads(out)
        assert obj["source"] == "s"

    def test_drops_none_values(self):
        from epsin.output import format_jsonl
        item = Item(source="s", title="t", url="http://x", date="2025-01-01", summary="sum", content_md=None)
        out = format_jsonl([item])
        obj = json.loads(out)
        assert "content_md" not in obj


class TestFormatTable:
    """Tests for output.format_table."""

    def test_empty(self):
        from epsin.output import format_table
        assert format_table([]) == ""

    def test_headers_present(self):
        from epsin.output import format_table
        item = Item(source="src", title="Title", url="http://x", date="2025-01-01", summary="s")
        out = format_table([item])
        assert "SOURCE" in out
        assert "TITLE" in out
