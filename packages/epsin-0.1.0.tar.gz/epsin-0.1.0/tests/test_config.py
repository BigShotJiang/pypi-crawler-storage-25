"""Tests for epsin.config — YAML config loading."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest
import yaml

from epsin.config import _load_yaml, _parse_sources, load_sources
from epsin.models import Source


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SAMPLE_YAML = textwrap.dedent("""\
    sources:
      - name: Test Blog
        url: https://example.com
        rss: https://example.com/feed.xml
        tags: [ai, test]

      - name: No RSS Blog
        url: https://noreply.example.com
        tags: [ai]
""")


@pytest.fixture
def config_file(tmp_path: Path) -> Path:
    p = tmp_path / "sources.yaml"
    p.write_text(SAMPLE_YAML, encoding="utf-8")
    return p


@pytest.fixture
def empty_config(tmp_path: Path) -> Path:
    p = tmp_path / "empty.yaml"
    p.write_text("", encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# _load_yaml tests
# ---------------------------------------------------------------------------

class TestLoadYaml:
    def test_reads_valid_file(self, config_file: Path) -> None:
        data = _load_yaml(config_file)
        assert "sources" in data
        assert len(data["sources"]) == 2

    def test_returns_empty_on_missing_file(self, tmp_path: Path) -> None:
        data = _load_yaml(tmp_path / "nonexistent.yaml")
        assert data == {}

    def test_returns_empty_on_empty_file(self, empty_config: Path) -> None:
        data = _load_yaml(empty_config)
        assert data == {}

    def test_returns_empty_on_non_dict(self, tmp_path: Path) -> None:
        p = tmp_path / "list.yaml"
        p.write_text("- a\n- b\n", encoding="utf-8")
        data = _load_yaml(p)
        assert data == {}


# ---------------------------------------------------------------------------
# _parse_sources tests
# ---------------------------------------------------------------------------

class TestParseSources:
    def test_parses_sources(self) -> None:
        raw = yaml.safe_load(SAMPLE_YAML)
        sources = _parse_sources(raw)
        assert len(sources) == 2

        first = sources[0]
        assert first.name == "Test Blog"
        assert first.url == "https://example.com"
        assert first.rss == "https://example.com/feed.xml"
        assert first.tags == ["ai", "test"]

    def test_no_rss_field_is_none(self) -> None:
        raw = yaml.safe_load(SAMPLE_YAML)
        sources = _parse_sources(raw)
        assert sources[1].rss is None

    def test_skips_entries_without_name_or_url(self) -> None:
        data = {
            "sources": [
                {"url": "https://no-name.com", "tags": ["ai"]},
                {"name": "No URL", "tags": ["ai"]},
                {"name": "Valid", "url": "https://ok.com"},
            ]
        }
        sources = _parse_sources(data)
        assert len(sources) == 1
        assert sources[0].name == "Valid"

    def test_empty_data(self) -> None:
        assert _parse_sources({}) == []


# ---------------------------------------------------------------------------
# load_sources integration tests
# ---------------------------------------------------------------------------

class TestLoadSources:
    def test_load_from_explicit_path(self, config_file: Path) -> None:
        sources = load_sources(config_file)
        assert len(sources) == 2
        assert isinstance(sources[0], Source)

    def test_load_from_bundled_default(self) -> None:
        """load_sources with no arg and no XDG file returns bundled defaults."""
        sources = load_sources()
        assert len(sources) > 0
        # Every bundled source should have 'ai' in tags
        for src in sources:
            assert "ai" in src.tags, f"{src.name} missing 'ai' tag"

    def test_empty_override_returns_empty(self, empty_config: Path) -> None:
        sources = load_sources(empty_config)
        assert sources == []
