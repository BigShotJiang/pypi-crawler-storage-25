"""Data models for epsin sources and scraped items."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class Source:
    """A configured news source (blog, newsletter, RSS feed)."""

    name: str
    url: str
    rss: str | None = None
    tags: list[str] = field(default_factory=list)
    extractor: str | None = None


@dataclass(slots=True)
class Item:
    """A single scraped item from a source."""

    source: str
    title: str
    url: str
    date: str
    summary: str
    content_md: str | None = None
    tags: list[str] = field(default_factory=list)
