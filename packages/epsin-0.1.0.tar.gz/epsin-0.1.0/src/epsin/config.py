"""Configuration loading for epsin — YAML source config via XDG path or override."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

from epsin.models import Source


def _xdg_config_home() -> Path:
    """Return XDG_CONFIG_HOME, defaulting to ~/.config."""
    raw = os.getenv("XDG_CONFIG_HOME")
    if raw:
        return Path(raw).expanduser().resolve()
    return Path.home() / ".config"


def default_config_path() -> Path:
    """Default path for epsin sources config: ~/.config/epsin/sources.yaml."""
    return _xdg_config_home() / "epsin" / "sources.yaml"


def bundled_sources_path() -> Path:
    """Path to the bundled default.yaml shipped with epsin."""
    return Path(__file__).with_name("sources") / "default.yaml"


def _load_yaml(path: Path) -> dict[str, Any]:
    """Load a YAML file, returning {} on missing / empty / invalid."""
    if not path.exists():
        return {}
    text = path.read_text(encoding="utf-8")
    data = yaml.safe_load(os.path.expandvars(text))
    if not isinstance(data, dict):
        return {}
    return data


def _parse_sources(data: dict[str, Any]) -> list[Source]:
    """Extract Source objects from the YAML data dict."""
    sources: list[Source] = []
    for value in data.values():
        if isinstance(value, list):
            for entry in value:
                if not isinstance(entry, dict):
                    continue
                name = entry.get("name")
                url = entry.get("url")
                if not name or not url:
                    continue
                sources.append(Source(
                    name=str(name),
                    url=str(url),
                    rss=entry.get("rss"),
                    tags=list(entry.get("tags", [])),
                    extractor=entry.get("extractor"),
                ))
    return sources


def load_sources(config_path: str | Path | None = None) -> list[Source]:
    """Load sources from the given path, or XDG default, or bundled fallback.

    Resolution order:
      1. Explicit config_path override
      2. ~/.config/epsin/sources.yaml
      3. Bundled default.yaml shipped with the package
    """
    if config_path is not None:
        path = Path(config_path).expanduser().resolve()
        data = _load_yaml(path)
        return _parse_sources(data)

    # Try XDG default
    xdg_path = default_config_path()
    if xdg_path.exists():
        data = _load_yaml(xdg_path)
        if data:
            return _parse_sources(data)

    # Fallback to bundled
    data = _load_yaml(bundled_sources_path())
    return _parse_sources(data)
