"""Output formatters for epsin CLI."""

from __future__ import annotations

import json
from dataclasses import asdict

from epsin.models import Item


def format_jsonl(items: list[Item]) -> str:
    """Return *items* as one JSON object per line.

    Each line is a self-contained JSON object with keys matching the Item
    dataclass fields.  ``None`` values are omitted for cleaner output.
    """
    lines: list[str] = []
    for item in items:
        obj = asdict(item)
        # Drop keys with None values for cleaner JSONL
        obj = {k: v for k, v in obj.items() if v is not None}
        lines.append(json.dumps(obj, ensure_ascii=False))
    return "\n".join(lines)


def format_table(items: list[Item]) -> str:
    """Return *items* as a human-readable plain-text table.

    Columns: SOURCE, DATE, TITLE, URL.  Column widths are auto-sized to
    fit the widest value (capped so they don't blow up the terminal).
    """
    if not items:
        return ""

    rows: list[tuple[str, str, str, str]] = [
        (item.source, item.date, item.title, item.url) for item in items
    ]

    headers = ("SOURCE", "DATE", "TITLE", "URL")
    all_rows = [headers] + rows

    # Calculate column widths
    widths = [max(len(str(row[i])) for row in all_rows) for i in range(4)]

    # Cap widths to reasonable maxima
    caps = (20, 12, 60, 80)
    widths = [min(w, c) for w, c in zip(widths, caps)]

    def fmt_row(row: tuple[str, ...]) -> str:
        parts: list[str] = []
        for i in range(4):
            val = str(row[i]) if i < len(row) else ""
            w = widths[i]
            if len(val) > w:
                val = val[: w - 1] + "…"
            parts.append(val.ljust(w))
        return "  ".join(parts)

    header_line = fmt_row(headers)
    sep_line = "  ".join("─" * w for w in widths)
    data_lines = [fmt_row(r) for r in rows]

    return "\n".join([header_line, sep_line, *data_lines])
