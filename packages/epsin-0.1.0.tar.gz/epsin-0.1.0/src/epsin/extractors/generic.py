"""Generic extractor — RSS-first with trafilatura scrape fallback.

This is the default extractor used when no source-specific extractor exists.
Implements the Extractor protocol: ``fetch(source, full=False) -> list[Item]``.
"""

from __future__ import annotations

from epsin.fetch import fetch_source
from epsin.models import Item, Source


def fetch(source: Source, *, full: bool = False) -> list[Item]:
    """Fetch items using the generic RSS → scrape fallback chain."""
    return fetch_source(source, include_content=full)
