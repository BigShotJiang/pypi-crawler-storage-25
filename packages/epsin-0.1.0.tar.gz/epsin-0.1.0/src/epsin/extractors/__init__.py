"""Extractor registry — resolves Source -> extractor function.

Resolution order:
  1. Source config ``extractor`` field (dotted module path)
  2. Name-based registry lookup (snake_case match)
  3. Generic fallback (RSS → trafilatura)
"""

from __future__ import annotations

import importlib
import re
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from epsin.models import Item, Source


class Extractor(Protocol):
    """Protocol that all extractors implement."""

    def fetch(self, source: Source, *, full: bool = False) -> list[Item]: ...


# Name -> module path within epsin.extractors
_REGISTRY: dict[str, str] = {}


def register(name: str, module_path: str) -> None:
    """Register a source name -> extractor module path."""
    _REGISTRY[name] = module_path


def _snake(name: str) -> str:
    """Convert source name to snake_case module name."""
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")


def resolve(source: Source) -> Extractor:
    """Resolve the best extractor for a source.

    1. If source has an ``extractor`` field, import that module.
    2. Elif source name matches a registered extractor, use it.
    3. Else fall back to the generic extractor.
    """
    # Check explicit extractor field
    extractor_path = getattr(source, "extractor", None)
    if extractor_path:
        mod = importlib.import_module(extractor_path)
        return mod  # type: ignore[return-value]

    # Check registry by snake_case name
    snake_name = _snake(source.name)
    if snake_name in _REGISTRY:
        mod = importlib.import_module(_REGISTRY[snake_name])
        return mod  # type: ignore[return-value]

    # Try auto-discovery: epsin.extractors.<snake_name>
    try:
        mod = importlib.import_module(f"epsin.extractors.{snake_name}")
        return mod  # type: ignore[return-value]
    except ImportError:
        pass

    # Fallback to generic
    from epsin.extractors import generic

    return generic  # type: ignore[return-value]
