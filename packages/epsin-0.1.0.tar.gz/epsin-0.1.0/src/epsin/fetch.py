"""Fetch logic for epsin sources — RSS-first with web-scrape fallback.

Public API
----------
- ``fetch_source(source)``  — try RSS, fall back to scrape.
- ``fetch_rss(source)``     — fetch and parse an RSS/Atom feed.
- ``fetch_scrape(source)``  — extract items by scraping the source URL.

The dispatcher follows a 2-tier pattern inspired by the pinocytosis effector:
fast/cheap RSS first, then slower but universal HTTP scrape as fallback.
"""

from __future__ import annotations

import calendar
import ipaddress
import logging
import re
import socket
from datetime import UTC, datetime
from typing import Any
from urllib.parse import urljoin, urlparse

import feedparser
import httpx
import trafilatura
from bs4 import BeautifulSoup

from epsin.models import Item, Source

__all__ = ["fetch_source", "fetch_rss", "fetch_scrape"]

logger = logging.getLogger(__name__)

_HEADERS = {
    "User-Agent": "epsin/0.1 (+https://github.com/user/epsin)",
}
_TIMEOUT = 15


# ---------------------------------------------------------------------------
# SSRF protection
# ---------------------------------------------------------------------------


def _is_safe_url(url: str) -> bool:
    """Block URLs targeting private/reserved IP ranges (SSRF protection)."""
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return False
        hostname = parsed.hostname
        if not hostname:
            return False
        addrs = socket.getaddrinfo(hostname, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
        for _family, _type, _proto, _canonname, sockaddr in addrs:
            ip = ipaddress.ip_address(sockaddr[0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
                return False
    except (socket.gaierror, ValueError, OSError):
        return False
    return True


# ---------------------------------------------------------------------------
# Feed entry helpers
# ---------------------------------------------------------------------------


def _entry_get(entry: Any, key: str, default: Any = "") -> Any:
    """Retrieve a value from a feedparser entry (dict-like or attribute)."""
    if hasattr(entry, "get"):
        try:
            return entry.get(key, default)
        except TypeError:
            pass
    return getattr(entry, key, default)


def _parse_feed_datetime(entry: Any) -> str:
    """Return ISO 8601 UTC datetime string from an RSS entry, or ``''``."""
    for field in ("published_parsed", "updated_parsed", "created_parsed"):
        parsed = getattr(entry, field, None)
        if parsed is None:
            parsed = _entry_get(entry, field, None)
        if parsed:
            try:
                ts = calendar.timegm(parsed)
                dt = datetime.fromtimestamp(ts, tz=UTC)
                return dt.isoformat()
            except (TypeError, OverflowError, OSError):
                continue

    # Fallback: raw string fields (RFC 2822 / ISO 8601)
    for field in ("published", "updated", "created"):
        raw = _entry_get(entry, field, "")
        if not raw:
            continue
        for fmt in (
            "%a, %d %b %Y %H:%M:%S %z",
            "%Y-%m-%dT%H:%M:%S%z",
            "%Y-%m-%dT%H:%M:%SZ",
        ):
            try:
                dt = datetime.strptime(str(raw).strip(), fmt)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=UTC)
                return dt.astimezone(UTC).isoformat()
            except ValueError:
                continue

    return ""


def _extract_summary(entry: Any) -> str:
    """Extract a short summary from an RSS entry's summary field."""
    summary = _entry_get(entry, "summary", "")
    if not summary:
        return ""
    soup = BeautifulSoup(summary, "html.parser")
    text = soup.get_text().replace("\n", " ").strip()
    first = re.split(r"[.!?。！？]", text)[0].strip()
    return first[:120]


# ---------------------------------------------------------------------------
# RSS fetcher
# ---------------------------------------------------------------------------


def fetch_rss(source: Source) -> list[Item]:
    """Fetch and parse an RSS/Atom feed, returning a list of Items.

    Args:
        source: A Source with an ``rss`` (or ``url``) field pointing to the
                feed URL.

    Raises:
        ValueError: If the feed URL fails SSRF protection.
        httpx.HTTPStatusError: If the HTTP request returns a 4xx/5xx.
    """
    url = source.rss or source.url
    if not url:
        return []
    if not _is_safe_url(url):
        raise ValueError(f"Blocked (SSRF): {url}")

    response = httpx.get(url, headers=_HEADERS, timeout=_TIMEOUT, follow_redirects=True)
    response.raise_for_status()

    feed = feedparser.parse(response.text)

    items: list[Item] = []
    for entry in feed.entries:
        title = str(_entry_get(entry, "title", "")).strip()
        if not title:
            continue

        link = str(_entry_get(entry, "link", ""))
        date = _parse_feed_datetime(entry)
        summary = _extract_summary(entry)

        items.append(
            Item(
                source=source.name,
                title=title,
                url=link,
                date=date,
                summary=summary,
                tags=list(source.tags),
            )
        )

    return items


# ---------------------------------------------------------------------------
# Web scrape fetcher
# ---------------------------------------------------------------------------


def _fetch_html(url: str) -> str:
    """Fetch raw HTML from *url* via httpx.  Returns empty string on failure."""
    if not _is_safe_url(url):
        logger.warning("Blocked (SSRF): %s", url)
        return ""
    try:
        resp = httpx.get(url, headers=_HEADERS, timeout=_TIMEOUT, follow_redirects=True)
        resp.raise_for_status()
        return resp.text
    except httpx.HTTPError as exc:
        logger.warning("HTTP error fetching %s: %s", url, exc)
        return ""


def _extract_article_links(soup: BeautifulSoup, base_url: str, max_links: int = 20) -> list[str]:
    """Discover article links from a list/blog page.

    Strategy (ordered by specificity):
      1. ``<article>`` tags → first ``<a href>`` inside.
      2. Common blog CSS selectors (``.post-title a``, ``.entry-title a``, etc.).
      3. ``<h2>`` / ``<h3>`` → child ``<a href>``.
    """
    links: list[str] = []

    # Strategy 1: <article> tags
    for article in soup.find_all("article"):
        a = article.find("a", href=True)
        if a:
            href = str(a["href"])
            if not href.startswith("http"):
                href = urljoin(base_url, href)
            if href not in links:
                links.append(href)
        if len(links) >= max_links:
            return links

    # Strategy 2: common blog selectors
    for selector in (
        ".post-title a",
        ".entry-title a",
        ".post-listing a",
        ".blog-post a",
        ".card-title a",
    ):
        for tag in soup.select(selector):
            href = str(tag.get("href", ""))
            if not href:
                continue
            if not href.startswith("http"):
                href = urljoin(base_url, href)
            if href not in links:
                links.append(href)
            if len(links) >= max_links:
                return links

    # Strategy 3: heading links
    for tag in soup.select("h2 a, h3 a"):
        href = str(tag.get("href", ""))
        if not href:
            continue
        if not href.startswith("http"):
            href = urljoin(base_url, href)
        if href not in links:
            links.append(href)
        if len(links) >= max_links:
            return links

    return links


def _extract_single_page(html: str, url: str) -> dict[str, str]:
    """Extract title, date, and content from a single article page.

    Uses trafilatura for main-content extraction, with BeautifulSoup as a
    fallback for title and date.

    trafilatura's ``bare_extraction`` returns a ``Document`` object with
    attributes (not dict keys).
    """
    result: dict[str, str] = {"title": "", "date": "", "content_md": ""}

    # trafilatura for content + metadata
    doc = trafilatura.bare_extraction(html, url=url, include_formatting=True)
    if doc:
        result["title"] = (doc.title or "").strip()
        result["date"] = (doc.date or "").strip()[:10]
        result["content_md"] = (doc.text or "").strip()

    # Fallback: BeautifulSoup for title if trafilatura missed it
    if not result["title"]:
        soup = BeautifulSoup(html, "html.parser")
        title_tag = soup.find("title")
        if title_tag:
            result["title"] = title_tag.get_text().strip()

        # Try meta tags for date
        if not result["date"]:
            for sel in (
                'meta[property="article:published_time"]',
                'meta[name="date"]',
                'meta[name="pubdate"]',
                'time[datetime]',
            ):
                meta = soup.select_one(sel)
                if meta:
                    raw_date = str(meta.get("content") or meta.get("datetime") or "")
                    result["date"] = raw_date[:10]
                    break

    return result


def fetch_scrape(source: Source) -> list[Item]:
    """Scrape items from *source* URL.

    For blog/list pages: discovers article links and extracts each.
    For single-article pages: extracts title/date/content directly.

    Args:
        source: A Source with a ``url`` to scrape.

    Returns:
        List of Items extracted from the page(s).
    """
    url = source.url
    if not url:
        return []

    html = _fetch_html(url)
    if not html:
        logger.warning("No HTML returned for %s", url)
        return []

    soup = BeautifulSoup(html, "html.parser")

    # Try to find article links (list/blog page)
    article_links = _extract_article_links(soup, url)

    if article_links:
        # Blog/list page: fetch each linked article
        items: list[Item] = []
        for link in article_links:
            article_html = _fetch_html(link)
            if not article_html:
                continue
            extracted = _extract_single_page(article_html, link)
            if not extracted["title"]:
                continue
            items.append(
                Item(
                    source=source.name,
                    title=extracted["title"],
                    url=link,
                    date=extracted["date"],
                    summary="",
                    tags=list(source.tags),
                    content_md=extracted["content_md"] or None,
                )
            )
        return items

    # Single article page: extract directly
    extracted = _extract_single_page(html, url)
    if not extracted["title"]:
        return []

    return [
        Item(
            source=source.name,
            title=extracted["title"],
            url=url,
            date=extracted["date"],
            summary="",
            tags=list(source.tags),
            content_md=extracted["content_md"] or None,
        )
    ]


# ---------------------------------------------------------------------------
# Dispatcher — RSS first, scrape fallback
# ---------------------------------------------------------------------------


def _enrich_with_content(items: list[Item]) -> list[Item]:
    """Fetch full article content for RSS items that lack ``content_md``."""
    for item in items:
        if item.content_md or not item.url:
            continue
        html = _fetch_html(item.url)
        if not html:
            continue
        doc = trafilatura.bare_extraction(html, url=item.url, include_formatting=True)
        if doc and doc.text:
            item.content_md = doc.text.strip()
    return items


def fetch_source(source: Source, *, include_content: bool = False) -> list[Item]:
    """Fetch items from *source*, trying RSS first and falling back to scrape.

    Follows a 2-tier fallback pattern:
      Tier 1: RSS (fast, structured, cheap)
      Tier 2: Web scrape (slower, universal fallback)

    Parameters
    ----------
    source:
        A configured source to fetch from.
    include_content:
        When True, populate ``content_md`` on returned items (always populated
        for scrape; fetched on-demand for RSS when this flag is set).

    Returns
    -------
    list[Item]
        Scraped items (may be empty if both methods fail).
    """
    # Tier 1: try RSS if an RSS URL is configured
    if source.rss:
        try:
            items = fetch_rss(source)
            if items:
                if include_content:
                    items = _enrich_with_content(items)
                return items
        except Exception as exc:
            logger.info("RSS failed for %s, falling back to scrape: %s", source.name, exc)

    # Tier 2: web scrape fallback
    try:
        return fetch_scrape(source)
    except Exception as exc:
        logger.warning("Scrape failed for %s: %s", source.name, exc)
        return []
