"""epsin — AI newsletter/blog scraper CLI."""

__version__ = "0.1.0"
