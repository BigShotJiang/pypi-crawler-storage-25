"""epsin CLI — AI newsletter/blog scraper.

Uses cyclopts for type-driven CLI and porin for agent-facing JSON output.
"""

from __future__ import annotations

import sys
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Annotated

import cyclopts
import httpx
import porin

from epsin import __version__
from epsin.config import load_sources
from epsin.extractors import resolve
from epsin.models import Item, Source
from epsin.output import format_jsonl

app = cyclopts.App(
    name="epsin",
    help="AI newsletter/blog scraper CLI.",
    version=__version__,
)

sources_app = cyclopts.App(name="sources", help="List and inspect configured sources.")
app.command(sources_app)


# ---------------------------------------------------------------------------
# epsin fetch
# ---------------------------------------------------------------------------


@app.command
def fetch(
    *,
    source: Annotated[str | None, cyclopts.Parameter(name="--source", help="Only fetch this source by name.")] = None,
    tag: Annotated[str | None, cyclopts.Parameter(name="--tag", help="Only include items with this tag.")] = None,
    since: Annotated[str | None, cyclopts.Parameter(name="--since", help="Only items on or after DATE (ISO 8601).")] = None,
    full: Annotated[bool, cyclopts.Parameter(name="--full", help="Include full article content.")] = False,
    config: Annotated[Path | None, cyclopts.Parameter(name="--config", help="Path to sources YAML.")] = None,
    json_output: Annotated[bool, cyclopts.Parameter(name=("--json", "-j"), help="Output porin JSON envelope.")] = False,
) -> None:
    """Fetch items from configured sources."""
    sources_list = load_sources(config)

    if source:
        sources_list = [s for s in sources_list if s.name == source]
        if not sources_list:
            if json_output:
                porin.emit_err("epsin fetch", f"No source named '{source}'", "NOT_FOUND", "Run: epsin sources list")
                sys.exit(porin.EXIT_NOT_FOUND)
            print(f"No source named '{source}' found in config.", file=sys.stderr)
            sys.exit(1)

    all_items: list[Item] = []
    for src in sources_list:
        extractor = resolve(src)
        items = extractor.fetch(src, full=full)
        all_items.extend(items)

    if tag:
        all_items = [item for item in all_items if tag in item.tags]

    if since:
        try:
            cutoff = datetime.fromisoformat(since)
        except ValueError:
            if json_output:
                porin.emit_err("epsin fetch", f"Invalid --since date: {since!r}", "USAGE", "Use ISO 8601 format")
                sys.exit(porin.EXIT_USAGE)
            print(f"Invalid --since date: {since!r}", file=sys.stderr)
            sys.exit(2)
        filtered: list[Item] = []
        for item in all_items:
            try:
                if datetime.fromisoformat(item.date) >= cutoff:
                    filtered.append(item)
            except (ValueError, TypeError):
                continue
        all_items = filtered

    if not full:
        for item in all_items:
            item.content_md = None

    if json_output:
        result = [_item_dict(item) for item in all_items]
        porin.emit_ok("epsin fetch", {"items": result, "count": len(result)})
    else:
        output = format_jsonl(all_items)
        if output:
            print(output)


# ---------------------------------------------------------------------------
# epsin sources list
# ---------------------------------------------------------------------------


@sources_app.command(name="list")
def sources_list_cmd(
    *,
    config: Annotated[Path | None, cyclopts.Parameter(name="--config", help="Path to sources YAML.")] = None,
    json_output: Annotated[bool, cyclopts.Parameter(name=("--json", "-j"), help="Output porin JSON envelope.")] = False,
) -> None:
    """List configured sources."""
    srcs = load_sources(config)
    if json_output:
        result = [{"name": s.name, "url": s.url, "rss": s.rss, "tags": s.tags} for s in srcs]
        porin.emit_ok("epsin sources list", {"sources": result, "count": len(result)})
    elif not srcs:
        print("No sources configured.")
    else:
        print(_sources_table(srcs))


# ---------------------------------------------------------------------------
# epsin sources check
# ---------------------------------------------------------------------------


@sources_app.command(name="check")
def sources_check_cmd(
    *,
    config: Annotated[Path | None, cyclopts.Parameter(name="--config", help="Path to sources YAML.")] = None,
    json_output: Annotated[bool, cyclopts.Parameter(name=("--json", "-j"), help="Output porin JSON envelope.")] = False,
) -> None:
    """Health-check all configured sources."""
    srcs = load_sources(config)
    results = []
    for src in srcs:
        try:
            resp = httpx.head(src.url, timeout=10, follow_redirects=True)
            status_str = "OK" if 200 <= resp.status_code < 400 else f"HTTP {resp.status_code}"
            healthy = 200 <= resp.status_code < 400
        except httpx.HTTPError as exc:
            status_str = f"ERROR: {exc}"
            healthy = False
        results.append({"name": src.name, "url": src.url, "status": status_str, "ok": healthy})

    if json_output:
        ok_count = sum(1 for r in results if r["ok"])
        porin.emit_ok("epsin sources check", {"sources": results, "healthy": ok_count, "total": len(results)})
    else:
        for r in results:
            print(f"{r['name']:<25} {r['status']}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _item_dict(item: Item) -> dict:
    """Convert Item to dict, dropping None values."""
    obj = asdict(item)
    return {k: v for k, v in obj.items() if v is not None}


def _sources_table(sources: list[Source]) -> str:
    """Format sources as a plain-text table."""
    headers = ("NAME", "RSS", "TAGS", "URL")
    rows = [
        (s.name, s.rss or "-", ", ".join(s.tags) if s.tags else "-", s.url)
        for s in sources
    ]
    all_rows = [headers] + rows
    widths = [max(len(str(row[i])) for row in all_rows) for i in range(4)]
    caps = (25, 30, 30, 60)
    widths = [min(w, c) for w, c in zip(widths, caps)]

    def fmt(row: tuple[str, ...]) -> str:
        parts: list[str] = []
        for i in range(4):
            val = str(row[i]) if i < len(row) else ""
            w = widths[i]
            if len(val) > w:
                val = val[: w - 1] + "\u2026"
            parts.append(val.ljust(w))
        return "  ".join(parts)

    header_line = fmt(headers)
    sep_line = "  ".join("\u2500" * w for w in widths)
    data_lines = [fmt(r) for r in rows]
    return "\n".join([header_line, sep_line, *data_lines])
