"""Panic-cooldown gate (L10) + process-abort scanner (L10b)."""
from __future__ import annotations

import datetime
import glob
import json
import os
import pathlib
import re
from dataclasses import dataclass, field

from metal_guard._constants import log


# ---------------------------------------------------------------------------
# L10 — Panic cooldown gate (C1 in Harper fork)
# ---------------------------------------------------------------------------

PANIC_REPORTS_GLOBS: tuple[str, ...] = (
    "/Library/Logs/DiagnosticReports/Retired/panic-full-*.panic",
    "/Library/Logs/DiagnosticReports/panic-full-*.panic",
)

# v0.11.0 (critic R1 P0-1): macOS writes process-level aborts (SIGABRT,
# `.ips` reports for app crashes) to a different path than kernel panics.
# `panic-full-*.panic` files only cover kernel-level reboots; the
# `command_buffer_oom` / `gpu_hang` / `gpu_page_fault` / `descriptor_leak`
# class strings appear in:
#   - subprocess stderr (caught by `SubprocessCrashError(detail=...)`)
#   - `*.ips` reports (system + user DiagnosticReports), JSON-ish format
#     containing the crash trace
#   - cascade-into-panic dumps when an abort triggers kernel-level fault
#
# `scan_recent_aborts` reads both globs so dashboard surface reflects
# reality. Tests wrote synthetic abort strings into `.panic` files; that
# still works (cascade case) AND now `.ips` reports also contribute.
_ABORT_REPORTS_GLOBS: tuple[str, ...] = (
    "/Library/Logs/DiagnosticReports/*.ips",
    os.path.expanduser("~/Library/Logs/DiagnosticReports/*.ips"),
    # Cascade case: abort signature appearing inside a kernel panic dump
    *PANIC_REPORTS_GLOBS,
)

_PANIC_SENTINEL_PATH = os.path.expanduser("~/.cache/metal-guard/panic-sentinel.json")
_PANIC_LOCKOUT_ACK_PATH = os.path.expanduser("~/.metal-guard-ack")

# AND-pattern: core signature + IOGPUMemory.cpp context. Avoids matching
# unrelated panics that mention "underflow" or "IOGPUMemory" in isolation.
_PANIC_CORE_RE = re.compile(r"prepare[_ ]count[_ ]underflow", re.IGNORECASE)
_PANIC_CONTEXT_RE = re.compile(
    r"IOGPUMemory\.cpp:\d+|completeMemory\(\)",
    re.IGNORECASE,
)

# Staircase cooldown defaults (env-overridable)
_GATE_STAGE1_ENV = "METALGUARD_PANIC_COOLDOWN_STAGE1_H"
_GATE_LOCKOUT_MAX_ENV = "METALGUARD_PANIC_LOCKOUT_MAX_H"
_GATE_LOCKOUT_24H_N_ENV = "METALGUARD_PANIC_LOCKOUT_24H_N"
_GATE_LOCKOUT_72H_N_ENV = "METALGUARD_PANIC_LOCKOUT_72H_N"
_GATE_KILL_SWITCH_ENV = "METALGUARD_PANIC_GATE_DISABLED"

_GATE_STAGE1_DEFAULT_H = 2.0
_GATE_LOCKOUT_MAX_DEFAULT_H = 72.0
_GATE_LOCKOUT_24H_N_DEFAULT = 2
_GATE_LOCKOUT_72H_N_DEFAULT = 3


@dataclass(frozen=True)
class PanicRecord:
    """A single IOGPU panic observation (filtered by AND-pattern match)."""
    path: pathlib.Path
    timestamp: datetime.datetime


@dataclass(frozen=True)
class CooldownVerdict:
    """Evaluation result returned by :func:`evaluate_panic_cooldown`.

    ``exit_code`` semantics mirror Harper's plist wrapper protocol:
        0 → proceed (no panic / cooldown expired / kill-switch)
        2 → skip this run (cooldown active or lockout)
        ≥3 → gate broken; wrappers should treat as fail-open

    v0.11.0: ``abort_count_24h`` exposes process-aborts (non-rebooting
    failures: command_buffer_oom / gpu_hang / gpu_page_fault /
    descriptor_leak) for dashboard surface. Aborts DO NOT influence
    ``exit_code`` — the 24h/72h staircase lockout is reserved for kernel
    panics that actually rebooted the machine. Abort frequency is exposed
    for ops visibility but does not gate plist wrapper retry decisions.
    """
    exit_code: int
    reason: str
    recent_panics_24h: int
    recent_panics_72h: int
    cooldown_until: datetime.datetime | None
    abort_count_24h: int = 0  # v0.11.0 informational only


def _gate_env_float(name: str, default: float) -> float:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        log.warning("metal-guard: invalid %s=%r, using default %.1f", name, raw, default)
        return default


def _gate_env_int(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        log.warning("metal-guard: invalid %s=%r, using default %d", name, raw, default)
        return default


def _iter_panic_files() -> list[str]:
    """Enumerate panic report files across Retired + active dirs."""
    out: list[str] = []
    for pattern in PANIC_REPORTS_GLOBS:
        out.extend(glob.glob(pattern))
    return out


def _file_matches_iogpu_signature(path: str) -> bool:
    """AND-match core + context. False positive guard for unrelated panics."""
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            content = f.read()
    except OSError as exc:
        # Some .panic files are root-owned 0600; cannot read = cannot confirm.
        log.debug("metal-guard: cannot read %s: %s", path, exc)
        return False
    return bool(_PANIC_CORE_RE.search(content)) and bool(_PANIC_CONTEXT_RE.search(content))


def scan_recent_panics(
    hours: float = 72.0,
    *,
    now: datetime.datetime | None = None,
) -> list[PanicRecord]:
    """Return MLX-matching IOGPU panic records within the last ``hours``.

    Uses file mtime as the panic timestamp. Sorted newest-first. Files
    that fail to read or fail the AND-pattern are skipped silently —
    this is best-effort detection, callers must not rely on completeness.
    """
    now = now or datetime.datetime.now()
    cutoff = now - datetime.timedelta(hours=hours)
    records: list[PanicRecord] = []
    for p in _iter_panic_files():
        try:
            mtime_ts = os.path.getmtime(p)
        except OSError:
            continue
        mtime = datetime.datetime.fromtimestamp(mtime_ts)
        if mtime < cutoff:
            continue
        if not _file_matches_iogpu_signature(p):
            continue
        records.append(PanicRecord(pathlib.Path(p), mtime))
    records.sort(key=lambda r: r.timestamp, reverse=True)
    return records


def _staircase_cooldown_hours(count_24h: int, count_72h: int) -> float | None:
    """Map (24h count, 72h count) to cooldown duration.

    Returns:
        None — no cooldown
        positive float — wait this many hours since latest panic
        ``-1.0`` — lockout (require ack or absolute-max elapsed)
    """
    lock_24 = _gate_env_int(_GATE_LOCKOUT_24H_N_ENV, _GATE_LOCKOUT_24H_N_DEFAULT)
    lock_72 = _gate_env_int(_GATE_LOCKOUT_72H_N_ENV, _GATE_LOCKOUT_72H_N_DEFAULT)
    if count_24h >= lock_24 or count_72h >= lock_72:
        return -1.0
    if count_24h == 1:
        return _gate_env_float(_GATE_STAGE1_ENV, _GATE_STAGE1_DEFAULT_H)
    return None


def _read_panic_sentinel_until(now: datetime.datetime) -> datetime.datetime | None:
    """Read sentinel cooldown_until; None if absent / corrupt / expired."""
    path = pathlib.Path(_PANIC_SENTINEL_PATH)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        log.warning("metal-guard: panic sentinel corrupt (%s), ignoring", exc)
        return None
    raw = data.get("cooldown_until")
    if not isinstance(raw, str):
        return None
    try:
        until = datetime.datetime.fromisoformat(raw)
    except ValueError:
        return None
    if until <= now:
        return None
    return until


def _read_lockout_ack_valid(
    now: datetime.datetime,
    latest_panic: datetime.datetime | None = None,
) -> bool:
    """Return True if ack is valid (24h TTL AND mtime > latest panic).

    The ``mtime > latest_panic`` constraint blocks the "ack survived a new
    panic" race: user touches ack at T, panic occurs at T+23h, reboot at
    T+23.5h. Pure-TTL semantics would let the ack still pass, exactly when
    the gate should be locked. Requiring ack newer than the latest panic
    forces re-acknowledgement after every fresh panic.
    """
    ack_path = pathlib.Path(_PANIC_LOCKOUT_ACK_PATH)
    if not ack_path.exists():
        return False
    try:
        mtime = datetime.datetime.fromtimestamp(ack_path.stat().st_mtime)
    except OSError:
        return False
    if (now - mtime) >= datetime.timedelta(hours=24):
        return False
    if latest_panic is not None and mtime < latest_panic:
        return False
    return True


def _lockout_absolute_max_reached(
    earliest_panic: datetime.datetime, now: datetime.datetime
) -> bool:
    """After ``METALGUARD_PANIC_LOCKOUT_MAX_H`` since earliest panic, auto-clear."""
    max_h = _gate_env_float(_GATE_LOCKOUT_MAX_ENV, _GATE_LOCKOUT_MAX_DEFAULT_H)
    return (now - earliest_panic) >= datetime.timedelta(hours=max_h)


def evaluate_panic_cooldown(
    *,
    now: datetime.datetime | None = None,
) -> CooldownVerdict:
    """Evaluate whether the caller should defer Metal work right now.

    Inspects ``/Library/Logs/DiagnosticReports/`` for AND-pattern IOGPU
    panics within 72h, applies the staircase policy, and consults the
    sentinel + ack files. Stdlib-only by design — works even when MLX is
    wedged mid-recovery.

    Kill switch: ``METALGUARD_PANIC_GATE_DISABLED=1`` short-circuits to
    exit 0 unconditionally (used for emergency override).
    """
    now = now or datetime.datetime.now()

    if os.environ.get(_GATE_KILL_SWITCH_ENV) == "1":
        return CooldownVerdict(0, "kill-switch active", 0, 0, None)

    sentinel_until = _read_panic_sentinel_until(now)
    if sentinel_until is not None:
        return CooldownVerdict(
            2,
            f"sentinel cooldown until {sentinel_until.isoformat(timespec='seconds')}",
            0, 0, sentinel_until,
        )

    panics_72h = scan_recent_panics(72.0, now=now)
    cutoff_24h = now - datetime.timedelta(hours=24)
    panics_24h = [p for p in panics_72h if p.timestamp >= cutoff_24h]
    count_24h = len(panics_24h)
    count_72h = len(panics_72h)

    # v0.11.0: surface abort_count_24h on every verdict for dashboard.
    # Defensive try/except so abort scan failure never blocks the panic
    # gate decision — gate safety > telemetry richness.
    abort_count_24h = 0
    try:
        abort_count_24h = len(scan_recent_aborts(24.0, now=now))
    except Exception as exc:  # noqa: BLE001
        log.debug("scan_recent_aborts failed: %s", exc)

    hours = _staircase_cooldown_hours(count_24h, count_72h)

    if hours is None:
        return CooldownVerdict(
            0, "no recent IOGPU panics", count_24h, count_72h, None,
            abort_count_24h=abort_count_24h,
        )

    if hours < 0:
        latest = panics_72h[0].timestamp if panics_72h else None
        if _read_lockout_ack_valid(now, latest_panic=latest):
            return CooldownVerdict(
                0, "lockout cleared by ack", count_24h, count_72h, None,
                abort_count_24h=abort_count_24h,
            )
        # critic R1 P1-3 guard: if user sets METALGUARD_PANIC_LOCKOUT_72H_N=0
        # the gate enters lockout-on-empty-list path. Default to "no auto-clear"
        # (treat earliest as `now` so MAX_H window never elapses).
        earliest = panics_72h[-1].timestamp if panics_72h else now
        if _lockout_absolute_max_reached(earliest, now):
            return CooldownVerdict(
                0, "lockout absolute-max elapsed", count_24h, count_72h, None,
                abort_count_24h=abort_count_24h,
            )
        return CooldownVerdict(
            2,
            f"lockout: 24h={count_24h} 72h={count_72h}; "
            f"touch {_PANIC_LOCKOUT_ACK_PATH} to clear",
            count_24h, count_72h, None,
            abort_count_24h=abort_count_24h,
        )

    latest = panics_72h[0].timestamp
    cooldown_until = latest + datetime.timedelta(hours=hours)
    if cooldown_until > now:
        return CooldownVerdict(
            2,
            f"cooldown {hours:.1f}h until {cooldown_until.isoformat(timespec='seconds')}",
            count_24h, count_72h, cooldown_until,
            abort_count_24h=abort_count_24h,
        )
    return CooldownVerdict(
        0,
        f"cooldown expired (latest panic {latest.isoformat(timespec='seconds')})",
        count_24h, count_72h, None,
        abort_count_24h=abort_count_24h,
    )


def mark_panic_sentinel_cooldown(
    duration_hours: float,
    *,
    now: datetime.datetime | None = None,
    reason: str | None = None,
) -> pathlib.Path:
    """Write a sentinel cooldown extending exit=2 for ``duration_hours``.

    Atomic write (rename) so concurrent gate readers never see partial JSON.
    Typically called by the postmortem collector (L12) right after writing
    a bundle, to extend the cooldown beyond DiagnosticReports rotation lag.

    ``reason`` is an optional free-form forensic tag. When ``None`` (default)
    the payload keeps its original 2-key shape (``cooldown_until`` +
    ``created_at``) so pre-W6 sentinel readers are unaffected — a 0-BC
    additive extension. When given, it is persisted as a 3rd ``reason`` key.
    """
    now = now or datetime.datetime.now()
    until = now + datetime.timedelta(hours=duration_hours)
    path = pathlib.Path(_PANIC_SENTINEL_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    record: dict[str, str] = {
        "cooldown_until": until.isoformat(timespec="seconds"),
        "created_at": now.isoformat(timespec="seconds"),
    }
    if reason is not None:
        record["reason"] = reason
    payload = json.dumps(record)
    tmp.write_text(payload, encoding="utf-8")
    os.replace(tmp, path)
    return path


def ack_panic_lockout() -> pathlib.Path:
    """Touch ``~/.metal-guard-ack`` (atomic) to clear an active lockout.

    Atomic rename so concurrent gate evaluations never read a half-written
    ack. Operator should write a brief reason line into the file before
    touching — future versions may mandate this content for audit.
    """
    ack = pathlib.Path(_PANIC_LOCKOUT_ACK_PATH)
    tmp = ack.with_suffix(ack.suffix + ".pending")
    tmp.write_text(datetime.datetime.now().isoformat(timespec="seconds") + "\n")
    os.replace(tmp, ack)
    return ack


def clear_panic_ack() -> bool:
    """Remove ``~/.metal-guard-ack``. Returns True if removed, False if absent."""
    ack = pathlib.Path(_PANIC_LOCKOUT_ACK_PATH)
    try:
        ack.unlink()
        return True
    except FileNotFoundError:
        return False
    except OSError as exc:
        log.warning("metal-guard: clear_panic_ack failed: %s", exc)
        return False


def clear_panic_sentinel() -> bool:
    """Remove the sentinel cooldown file."""
    path = pathlib.Path(_PANIC_SENTINEL_PATH)
    try:
        path.unlink()
        return True
    except FileNotFoundError:
        return False
    except OSError as exc:
        log.warning("metal-guard: clear_panic_sentinel failed: %s", exc)
        return False


# ---------------------------------------------------------------------------
# L10b — Process-abort scanner (separate counter from kernel panics)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AbortRecord:
    """A non-kernel-panic abort observed in DiagnosticReports / panic logs.

    ``error_class`` is the :class:`ErrorClass` ``name`` string.
    """
    path: pathlib.Path
    timestamp: datetime.datetime
    error_class: str


def _file_matches_process_abort(path: str) -> tuple[bool, str | None]:
    """Read panic file + classify as process-level abort (not kernel panic).

    Kernel-panic signatures take priority — if the file matches both kernel
    + abort patterns, classify as kernel_panic and return False here. The
    abort counter must not double-count machines that already rebooted.
    """
    from metal_guard.error_classifier import classify_mlx_error
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            content = f.read()
    except OSError as exc:
        log.debug("metal-guard abort scan: cannot read %s: %s", path, exc)
        return False, None
    cls = classify_mlx_error(content)
    if cls is None or cls.severity == "kernel_panic":
        return False, None
    return True, cls.name


def _iter_abort_files() -> list[str]:
    """Enumerate abort report files: ``.ips`` (user + system) + cascade panics.

    See `_ABORT_REPORTS_GLOBS` for rationale (critic R1 P0-1).
    """
    out: list[str] = []
    for pattern in _ABORT_REPORTS_GLOBS:
        out.extend(glob.glob(pattern))
    return out


def scan_recent_aborts(
    hours: float = 24.0,
    *,
    now: datetime.datetime | None = None,
) -> list[AbortRecord]:
    """Return process-abort records (NOT kernel panics) within ``hours``.

    Default 24h window (vs panics' 72h) because aborts respawn fast and
    cumulative exposure decays quicker; longer history is noise.

    v0.11.0 (critic R1 P0-1): now reads `.ips` files (where macOS writes
    process abort traces) IN ADDITION TO `panic-full-*.panic` (where
    abort signatures sometimes appear when an abort cascades into a
    kernel panic). Caller should still treat 0 results as "either nothing
    aborted, or the abort happened on a path metal-guard doesn't observe"
    (e.g. subprocess died with no stderr captured + no `.ips` written).
    """
    now = now or datetime.datetime.now()
    cutoff = now - datetime.timedelta(hours=hours)
    records: list[AbortRecord] = []
    seen_paths: set[str] = set()
    for p in _iter_abort_files():
        if p in seen_paths:
            continue
        seen_paths.add(p)
        try:
            mtime_ts = os.path.getmtime(p)
        except OSError:
            continue
        mtime = datetime.datetime.fromtimestamp(mtime_ts)
        if mtime < cutoff:
            continue
        matched, error_class = _file_matches_process_abort(p)
        if not matched or error_class is None:
            continue
        records.append(AbortRecord(pathlib.Path(p), mtime, error_class))
    records.sort(key=lambda r: r.timestamp, reverse=True)
    return records
