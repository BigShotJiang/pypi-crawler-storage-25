"""Memory-stat snapshot type, recoverable OOM exception, KV-pressure helper."""

from __future__ import annotations

import datetime
import gc
import glob
import json
import logging
import multiprocessing
import os
import pathlib
import re
import shutil
import signal
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from multiprocessing.connection import Connection
from pathlib import Path
from typing import Any, Callable, Generator, Iterator, Tuple, TypeVar

from metal_guard._constants import log

# ---------------------------------------------------------------------------
# Memory stats
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class MemoryStats:
    """Snapshot of Metal GPU memory state."""

    active_bytes: int = 0
    peak_bytes: int = 0
    limit_bytes: int = 0

    @property
    def active_gb(self) -> float:
        return self.active_bytes / 1e9

    @property
    def peak_gb(self) -> float:
        return self.peak_bytes / 1e9

    @property
    def limit_gb(self) -> float:
        return self.limit_bytes / 1e9

    @property
    def available_gb(self) -> float:
        return (self.limit_bytes - self.active_bytes) / 1e9

    @property
    def active_pct(self) -> float:
        return (self.active_bytes / self.limit_bytes * 100) if self.limit_bytes else 0

    @property
    def peak_pct(self) -> float:
        return (self.peak_bytes / self.limit_bytes * 100) if self.limit_bytes else 0

    def __str__(self) -> str:
        return (
            f"active={self.active_gb:.1f}GB peak={self.peak_gb:.1f}GB "
            f"limit={self.limit_gb:.0f}GB avail={self.available_gb:.1f}GB "
            f"(active {self.active_pct:.0f}% / peak {self.peak_pct:.0f}%)"
        )


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class MetalOOMError(RuntimeError):
    """Raised when Metal GPU runs out of memory.

    Unlike the raw C++ RuntimeError, this is catchable and recoverable.
    MetalGuard catches the raw error, cleans up GPU state, and re-raises
    as this so callers can handle it gracefully (e.g. return HTTP 503).
    """

    def __init__(self, message: str, stats: MemoryStats | None = None):
        super().__init__(message)
        self.stats = stats


# ---------------------------------------------------------------------------
# KV cache pressure helpers
# ---------------------------------------------------------------------------

def kv_cache_clear_on_pressure(
    available_gb: float,
    growth_rate_gb_per_min: float,
) -> None:
    """Default ``on_pressure`` callback for :meth:`MetalGuard.start_kv_cache_monitor`.

    Clears MLX's cache when headroom is low or growth is too fast. Safe
    to pass directly::

        metal_guard.start_kv_cache_monitor(
            on_pressure=kv_cache_clear_on_pressure,
        )

    Does NOT evict application-level KV caches (those are held by the
    caller's server process — only it can invalidate them). This only
    asks Metal to return as much unused GPU memory as possible.
    """
    try:
        import mlx.core as mx
    except ImportError:
        return

    log.warning(
        "KV pressure callback firing: avail=%.1fGB growth=%.2fGB/min — "
        "calling mx.clear_cache()",
        available_gb, growth_rate_gb_per_min,
    )
    try:
        mx.clear_cache()
    except Exception as exc:
        log.error("mx.clear_cache() from pressure callback failed: %s", exc)
