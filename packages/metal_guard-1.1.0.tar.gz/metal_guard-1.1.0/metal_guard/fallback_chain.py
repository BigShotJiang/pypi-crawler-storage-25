"""Engine fallback chain — tier-by-tier dispatch over process-local backends.

Tier-by-tier dispatch over process-local backends (mlx + ollama). On any
tier failure / lockout / panic-cooldown refuse / daemon-unreachable the chain
falls forward to the next tier. All tiers exhausted -> return empty result
+ ``all_local_failed: True`` telemetry (NO raise) so the caller can
gracefully escalate to a higher dispatch layer.

L1/L2 boundary: this module dispatches ONLY process-local backends. Cloud
LLM dispatch belongs to a higher layer and is refused at
``BackendTier.__post_init__`` + ``load_chain`` time.

Public API:
    - ``BackendTier`` — frozen dataclass (name, backend, model, max_attempts,
      timeout_sec)
    - ``call_with_fallback(workload_class, prompt, chain, **params)`` ->
      ``(result, used_tier, telemetry)`` tuple
    - ``load_chain(workload_class, *, config_path=None)`` — read tier list
      from ``~/.metal-guard/workload_chains.json``
    - ``BackendTierLayerViolationError`` — raised on cloud / unknown backend
    - ``ModelSubstitutionForbiddenError`` — raised when chain spans multiple
      model identities without explicit ``allow_model_substitution=True``

EVENT_KINDS:
    - ``fallback_attempted``
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from metal_guard import corpus as panic_corpus
from metal_guard._constants import log

_ALLOWED_BACKENDS = frozenset({"mlx", "ollama"})
_DEFAULT_CONFIG_PATH = Path("~/.metal-guard/workload_chains.json").expanduser()
_DEFAULT_BASELINE_PATH = Path(
    "~/.metal-guard/state/workload_chains.sha256"
).expanduser()
_OLLAMA_HEALTH_TTL_SEC = 30.0
_DEFAULT_OLLAMA_URL = "http://localhost:11434"
# Once-per-process latch so the mlx tier stub surfaces its unwired state in
# operator logs exactly once, not every fallback walk (which would spam logs
# in production).
_mlx_unwired_warned: bool = False
# Cap ollama response body to avoid OOM on a hung/misbehaving daemon
# returning multi-GB bodies (e.g. stuck streaming response despite stream=False).
# 10 MiB is generous for a non-streaming completion; readers exceeding this raise
# _DispatchError so the chain falls through rather than OOMs the host.
_OLLAMA_MAX_RESPONSE_BYTES = 10 * 1024 * 1024


# ── Exceptions ───────────────────────────────────────────────────────


class BackendTierLayerViolationError(ValueError):
    """AC4.6: tier backend ∉ {'mlx', 'ollama'} (e.g. cloud) violates L1/L2 boundary."""


class ModelSubstitutionForbiddenError(ValueError):
    """AC4.7: chain spans multiple model identities without opt-in."""


class WorkloadChainsTamperError(RuntimeError):
    """Live ``workload_chains.json`` sha256 differs from baseline.

    Caller MUST resolve before dispatch (operator review + explicit
    ``update_chain_config_baseline()`` if change is legitimate). Loader
    refuses to return chain config until baseline matches.
    """


# ── BackendTier dataclass ────────────────────────────────────────────


@dataclass(frozen=True)
class BackendTier:
    """One step in a fallback chain. Frozen so chains can be shared safely."""

    name: str
    backend: str
    model: str
    max_attempts: int = 1
    timeout_sec: int = 60

    def __post_init__(self) -> None:
        # AC4.6 / AC4.8: validate at construction time, not dispatch time.
        if self.backend not in _ALLOWED_BACKENDS:
            raise BackendTierLayerViolationError(
                f"backend={self.backend!r} not in {sorted(_ALLOWED_BACKENDS)} — "
                "cloud / arbitrary backends belong to a higher dispatch layer, "
                "not this process-local fallback chain"
            )
        # Enforce numeric types at construct time so dispatch-side
        # `float(tier.timeout_sec)` cannot raise ValueError on string-typed
        # JSON config values. ``load_chain`` already coerces via int(); this
        # closes the gap for direct ``BackendTier(...)`` construction.
        if not isinstance(self.max_attempts, int) or isinstance(self.max_attempts, bool):
            raise TypeError(
                f"max_attempts must be int, got {type(self.max_attempts).__name__}"
            )
        if not isinstance(self.timeout_sec, int) or isinstance(self.timeout_sec, bool):
            raise TypeError(
                f"timeout_sec must be int, got {type(self.timeout_sec).__name__}"
            )


# ── Ollama daemon health check cache (AC4.9) ─────────────────────────


_ollama_health_cache: dict[str, tuple[bool, float]] = {}
_ollama_health_lock = threading.Lock()


def _raw_ollama_health_probe(daemon_url: str) -> bool:
    """Real network probe — overridden by tests via patch."""
    try:
        import urllib.request
        with urllib.request.urlopen(f"{daemon_url}/api/tags", timeout=2.0) as r:
            return 200 <= r.status < 300
    except Exception:
        return False


def _is_ollama_daemon_reachable(daemon_url: str) -> bool:
    """Cached health check (TTL 30s). AC4.9 cache key = (daemon_url,) ONLY.

    Model identity is NOT part of the cache key — daemon-up/down is the
    coarse-grained signal; per-model load failures surface at dispatch
    time as ollama 5xx and fall through to the next tier.
    """
    now = time.monotonic()
    with _ollama_health_lock:
        cached = _ollama_health_cache.get(daemon_url)
        if cached is not None and (now - cached[1]) < _OLLAMA_HEALTH_TTL_SEC:
            return cached[0]
    # Cache miss — single probe under thundering-herd lock.
    with _ollama_health_lock:
        cached = _ollama_health_cache.get(daemon_url)
        if cached is not None and (now - cached[1]) < _OLLAMA_HEALTH_TTL_SEC:
            return cached[0]
        ok = _raw_ollama_health_probe(daemon_url)
        _ollama_health_cache[daemon_url] = (ok, now)
        return ok


def _is_mlx_tier_available(tier: BackendTier) -> bool:
    """Skip mlx tier if panic cooldown rc=2 / recovery_lockout active.

    Best-effort: missing modules / import errors degrade to "available" —
    let dispatch fail naturally rather than false-deny early.
    """
    try:
        from metal_guard import panic_gate as panic_cooldown
        if panic_cooldown.evaluate_panic_cooldown().exit_code == 2:
            return False
    except Exception:
        pass
    try:
        from metal_guard import recovery_lockout
        if recovery_lockout.is_locked_out():
            return False
    except Exception:
        pass
    return True


# ── Substitution policy (AC4.7) ──────────────────────────────────────


def _enforce_substitution_lazy(
    new_model: str,
    attempted_models: set[str],
    allow_model_substitution: bool,
) -> None:
    """Lazy per-tier substitution check.

    Earlier eager check (over the whole declared chain) rejected valid
    configs like ``[mlx_tier(phi4), ollama_tier(phi4:q4_K_M)]`` even
    when the mlx tier is permanently skipped (panic cooldown /
    recovery_lockout) — the chain would never actually substitute models
    in practice, but the eager pre-check raised nonetheless.

    Lazy check: only compare against models for which dispatch was
    ATTEMPTED (success-or-fail; tiers skipped via panic cooldown / lockout /
    daemon-unreachable do NOT count). First attempted dispatch always
    allowed. Subsequent attempts compare model identity. "attempted" not
    "successfully reached" — failed dispatch still populates
    attempted_models so substitution semantic matches caller's declared
    chain intent (caller wanted multiple model identities to try same
    prompt).
    """
    if allow_model_substitution:
        return
    if not attempted_models or new_model in attempted_models:
        return
    raise ModelSubstitutionForbiddenError(
        f"dispatch model={new_model!r} differs from previously-attempted "
        f"{sorted(attempted_models)}; set allow_model_substitution=True "
        "if intentional"
    )


# ── Telemetry ─────────────────────────────────────────────────────────


def _emit_attempt(
    tier: BackendTier,
    *,
    workload_class: str,
    outcome: str,           # 'success' | 'skip' | 'fail'
    error_kind: str | None = None,
    latency_ms: float | None = None,
) -> None:
    try:
        panic_corpus.emit_event(
            event_kind="fallback_attempted",
            payload={
                "workload_class": workload_class,
                "tier_name": tier.name,
                "backend": tier.backend,
                "model": tier.model,
                "outcome": outcome,
                "error_kind": error_kind,
                "latency_ms": latency_ms,
            },
        )
    except Exception as exc:
        log.debug("fallback_chain: emit_event failed: %s", exc)


# ── Tier dispatch (real backend call — patchable by tests) ───────────


class _DispatchError(RuntimeError):
    """Backend-agnostic dispatch failure — fall through to next tier."""


def _dispatch_ollama(
    tier: BackendTier,
    prompt: str,
    *,
    daemon_url: str = _DEFAULT_OLLAMA_URL,
    timeout_sec: float | None = None,
    **params: Any,
) -> tuple[str, dict[str, Any]]:
    """Ollama backend dispatch via HTTP ``/api/generate`` (non-streaming).

    Returns ``(result_text, tier_telemetry)`` or raises ``_DispatchError`` on
    daemon 4xx/5xx / network error / json parse failure. Caller's loop
    catches via broad ``except Exception`` and falls through to next tier.

    No subprocess spawn — pure stdlib ``urllib.request``. Safe under
    panic cooldown (no mlx import).
    """
    import urllib.request
    import urllib.error
    body = {
        "model": tier.model,
        "prompt": prompt,
        "stream": False,
    }
    # Optional pass-through params (temperature / num_predict / etc.) —
    # caller responsible for ollama-compatible keys.
    for k in ("temperature", "num_predict", "top_p", "top_k", "seed"):
        if k in params:
            body.setdefault("options", {})[k] = params[k]
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        f"{daemon_url}/api/generate",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    effective_timeout = timeout_sec if timeout_sec is not None else float(tier.timeout_sec)
    try:
        with urllib.request.urlopen(req, timeout=effective_timeout) as r:
            # Bounded read — read 1 byte past cap so we can distinguish
            # "exact cap" (legal) from "exceeds cap" (raise).
            raw = r.read(_OLLAMA_MAX_RESPONSE_BYTES + 1)
            if len(raw) > _OLLAMA_MAX_RESPONSE_BYTES:
                raise _DispatchError(
                    f"ollama response exceeds {_OLLAMA_MAX_RESPONSE_BYTES} byte cap"
                )
            payload = json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise _DispatchError(f"ollama HTTP {exc.code}: {exc.reason}") from exc
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        raise _DispatchError(f"ollama transport: {type(exc).__name__}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise _DispatchError(f"ollama response parse: {exc}") from exc
    result = payload.get("response", "")
    telem = {
        "ollama_eval_count": payload.get("eval_count"),
        "ollama_eval_duration_ns": payload.get("eval_duration"),
        "ollama_done": payload.get("done"),
    }
    return result, telem


def _dispatch_tier(
    tier: BackendTier, prompt: str, **params: Any,
) -> tuple[str, dict[str, Any]]:
    """Dispatch one tier. Returns ``(result, telemetry)`` or raises on failure.

    Backend routing:
        - ``ollama``: HTTP POST ``/api/generate`` non-streaming via
          ``_dispatch_ollama`` (pure stdlib, no spawn, panic-cooldown-safe)
        - ``mlx``: NotImplementedError — mlx tier dispatch is an unwired
          stub. Caller's ``except Exception`` catches and falls through to
          the next tier; production-pending log.warning suppressed to avoid
          spam during chain walk.
    """
    if tier.backend == "ollama":
        daemon_url = params.pop("ollama_daemon_url", _DEFAULT_OLLAMA_URL)
        timeout_sec = params.pop("ollama_timeout_sec", None)
        return _dispatch_ollama(
            tier, prompt,
            daemon_url=daemon_url,
            timeout_sec=timeout_sec,
            **params,
        )
    if tier.backend == "mlx":
        # Once-per-process surface so unwired stub state shows up exactly
        # once in operator logs (not every chain walk). Subsequent calls
        # fall through to the same NotImplementedError without re-logging.
        global _mlx_unwired_warned
        if not _mlx_unwired_warned:
            _mlx_unwired_warned = True
            log.warning(
                "fallback_chain: mlx tier dispatch is an unwired stub — "
                "every mlx tier in a chain falls through to the next tier."
            )
        raise NotImplementedError(
            "fallback_chain mlx tier dispatch is an unwired stub"
        )
    # Unreachable due to BackendTier.__post_init__ guard, but defensive.
    raise _DispatchError(f"unknown backend: {tier.backend!r}")


# ── Public API: call_with_fallback (AC4.1-4.4) ───────────────────────


def call_with_fallback(
    workload_class: str,
    prompt: str,
    chain: list[BackendTier],
    *,
    allow_model_substitution: bool = False,
    ollama_daemon_url: str = _DEFAULT_OLLAMA_URL,
    **params: Any,
) -> tuple[str, BackendTier | None, dict[str, Any]]:
    """Walk ``chain`` tier-by-tier; return first success or all-fail summary.

    Returns:
        (result, used_tier, telemetry) — on all-fail, ``result == ""`` and
        ``used_tier is None`` and ``telemetry["all_local_failed"] is True``
        per AC4.2.

    Raises:
        ModelSubstitutionForbiddenError: chain spans multiple model
            identities without ``allow_model_substitution=True`` (AC4.7).
    """
    telemetry: dict[str, Any] = {"attempts": []}
    attempted_models: set[str] = set()

    for tier in chain:
        # AC4.3: per-tier skip conditions.
        if tier.backend == "mlx" and not _is_mlx_tier_available(tier):
            _emit_attempt(tier, workload_class=workload_class,
                          outcome="skip", error_kind="mlx_unavailable")
            telemetry["attempts"].append((tier.name, "skip", "mlx_unavailable"))
            continue
        if tier.backend == "ollama" and not _is_ollama_daemon_reachable(
            ollama_daemon_url
        ):
            _emit_attempt(tier, workload_class=workload_class,
                          outcome="skip", error_kind="ollama_unreachable")
            telemetry["attempts"].append(
                (tier.name, "skip", "ollama_unreachable")
            )
            continue

        # AC4.7: lazy substitution check — only compare against tiers that
        # actually reached dispatch. Skipped tiers don't count as
        # "substituting" since they never produced output.
        _enforce_substitution_lazy(
            tier.model, attempted_models, allow_model_substitution
        )
        attempted_models.add(tier.model)

        # Attempt dispatch.
        t0 = time.monotonic()
        try:
            result, tier_telem = _dispatch_tier(tier, prompt, **params)
        except Exception as exc:
            latency_ms = (time.monotonic() - t0) * 1000.0
            _emit_attempt(tier, workload_class=workload_class,
                          outcome="fail",
                          error_kind=type(exc).__name__,
                          latency_ms=latency_ms)
            telemetry["attempts"].append(
                (tier.name, "fail", type(exc).__name__)
            )
            continue

        latency_ms = (time.monotonic() - t0) * 1000.0
        _emit_attempt(tier, workload_class=workload_class,
                      outcome="success", latency_ms=latency_ms)
        telemetry["attempts"].append((tier.name, "success", None))
        return result, tier, telemetry

    # AC4.2: all tiers exhausted — caller can escalate to a higher layer.
    telemetry["all_local_failed"] = True
    return "", None, telemetry


# ── sha256 watchdog for workload_chains.json ─────────────────────────


def _compute_sha256(path: Path) -> str:
    """Compute sha256 hex digest of file bytes (no decode)."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _baseline_path_for(config_path: Path) -> Path:
    """Resolve baseline file location.

    Default ``~/.metal-guard/state/workload_chains.sha256`` for the canonical
    config; for non-canonical paths (tests, alt deployments) sibling
    ``<config>.sha256`` is used.
    """
    if config_path == _DEFAULT_CONFIG_PATH:
        return _DEFAULT_BASELINE_PATH
    return config_path.with_suffix(config_path.suffix + ".sha256")


def update_chain_config_baseline(config_path: Path | None = None) -> str:
    """Operator-explicit trust update: write current file digest as baseline.

    Use when you have legitimately edited ``workload_chains.json`` (e.g.
    new tier wired). Pre-existing baseline is overwritten atomically.
    Returns the new sha256 hex digest.

    Caller responsibility: review the diff before calling — this is the
    explicit-trust API, intended for human operator (or a deploy script
    that has already audited the change).
    """
    path = config_path or _DEFAULT_CONFIG_PATH
    digest = _compute_sha256(path)
    baseline = _baseline_path_for(path)
    baseline.parent.mkdir(parents=True, exist_ok=True)
    tmp = baseline.with_suffix(baseline.suffix + ".tmp")
    tmp.write_text(digest)
    os.replace(tmp, baseline)
    return digest


def _verify_bytes(
    raw_bytes: bytes, baseline_path: Path,
) -> tuple[bool, str, str | None]:
    """Verify hash of *exact bytes already loaded* against baseline — not a
    re-read of the file. Caller responsible for reading bytes once and
    passing here, then parsing the same bytes (TOCTOU-safe).

    Baseline seed uses ``O_EXCL`` open so concurrent cold-start callers
    can't race; if another process won the race, fall through to the
    standard read+compare path.

    Returns ``(verified, current, baseline_hex)`` where baseline_hex is
    None on TOFU first-seed.
    """
    current = hashlib.sha256(raw_bytes).hexdigest()
    if not baseline_path.exists():
        # TOFU seed via O_EXCL: lossless under concurrent first-use.
        baseline_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = baseline_path.with_suffix(baseline_path.suffix + ".tmp")
        try:
            fd = os.open(
                str(tmp),
                os.O_WRONLY | os.O_CREAT | os.O_EXCL,
                0o644,
            )
            try:
                os.write(fd, current.encode("ascii"))
            finally:
                os.close(fd)
            os.replace(tmp, baseline_path)
            return True, current, None
        except FileExistsError:
            # Another process is mid-seed — fall through to read+compare
            # below. log.debug over bare pass per coding-style rule.
            # Best-effort cleanup of orphan .tmp deferred.
            log.debug(
                "fallback_chain: TOFU race lost on %s — falling through to "
                "read+compare", baseline_path,
            )
    # Either baseline exists already, or another process won the TOFU race.
    if not baseline_path.exists():
        # Race winner hasn't completed os.replace yet — treat as TOFU-pass
        # this round; next call will pick up the established baseline.
        return True, current, None
    expected = baseline_path.read_text().strip()
    return (current == expected), current, expected


def verify_chain_config(
    config_path: Path | None = None,
) -> tuple[bool, str, str | None]:
    """Verify live config sha256 against baseline.

    Returns:
        (verified, current_digest, baseline_digest)
        - verified True if baseline missing (TOFU first-use seeding) OR
          current matches baseline
        - verified False if mismatch (caller must raise / emit)

    Side-effect: when baseline is missing, writes current digest as new
    baseline (TOFU semantic — first observed config is trusted).

    Note: this is a convenience wrapper that re-reads the file. For
    consistency with parsed content (TOCTOU-safe), prefer ``load_chain``
    which reads bytes once and verifies the same bytes that get parsed.
    """
    path = config_path or _DEFAULT_CONFIG_PATH
    raw_bytes = path.read_bytes()
    return _verify_bytes(raw_bytes, _baseline_path_for(path))


# ── workload_chains.json loader (AC4.5 / AC4.8) ──────────────────────


def load_chain(
    workload_class: str,
    *,
    config_path: Path | None = None,
    verify: bool = True,
) -> list[BackendTier]:
    """Read chain config for ``workload_class`` from JSON.

    AC4.5: source is ``~/.metal-guard/workload_chains.json``.
    AC4.8: validation at file-load time — cloud backends raise
    ``BackendTierLayerViolationError`` BEFORE any dispatch.

    ``verify=True`` (default) cross-checks file sha256 against
    ``~/.metal-guard/state/workload_chains.sha256`` baseline. Mismatch
    raises ``WorkloadChainsTamperError`` + emits ``workload_chains_tampered``
    corpus event. Pass ``verify=False`` only for offline tooling (e.g.
    static config audit) where the integrity check is undesired.
    """
    path = Path(config_path or _DEFAULT_CONFIG_PATH)
    # TOCTOU-safe: read bytes ONCE, verify hash + parse same bytes —
    # otherwise an attacker can swap the file between sha256 and json.loads.
    raw_bytes = path.read_bytes()
    if verify:
        ok, current, baseline_hex = _verify_bytes(
            raw_bytes, _baseline_path_for(path)
        )
        if not ok:
            try:
                panic_corpus.emit_event(
                    event_kind="workload_chains_tampered",
                    payload={
                        "config_path": str(path),
                        "current_sha256": current,
                        "baseline_sha256": baseline_hex,
                    },
                )
            except Exception as exc:
                log.debug("fallback_chain: tamper emit failed: %s", exc)
            raise WorkloadChainsTamperError(
                f"workload_chains.json sha256 mismatch: live={current[:16]}... "
                f"vs baseline={(baseline_hex or 'NONE')[:16]}... — operator review "
                "required (call update_chain_config_baseline() to accept change)"
            )
    raw = json.loads(raw_bytes)
    if workload_class not in raw:
        raise KeyError(
            f"workload_class={workload_class!r} not in {path} "
            f"(known: {sorted(raw.keys())})"
        )
    chain: list[BackendTier] = []
    for entry in raw[workload_class]:
        # __post_init__ validates backend ∈ {'mlx','ollama'} → raises
        # BackendTierLayerViolationError on cloud / unknown.
        chain.append(
            BackendTier(
                name=entry["name"],
                backend=entry["backend"],
                model=entry["model"],
                max_attempts=int(entry.get("max_attempts", 1)),
                timeout_sec=int(entry.get("timeout_sec", 60)),
            )
        )
    return chain
