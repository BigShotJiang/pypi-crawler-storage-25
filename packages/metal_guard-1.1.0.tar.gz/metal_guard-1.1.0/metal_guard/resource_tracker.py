"""Descriptor-leak resource tracker (Layer 14)."""

from __future__ import annotations

import datetime
import gc
import glob
import json
import logging
import multiprocessing
import os
import pathlib
import re
import shutil
import signal
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from multiprocessing.connection import Connection
from pathlib import Path
from typing import Any, Callable, Generator, Iterator, Tuple, TypeVar

from metal_guard._constants import log

# ---------------------------------------------------------------------------
# L14 — Resource-leak heuristic (Metal descriptor count cold-restart)
# ---------------------------------------------------------------------------


_RESOURCE_TRACKER_DEFAULT_THRESHOLD = 4000
_RESOURCE_TRACKER_KILL_SWITCH_ENV = "METALGUARD_COLD_RESTART_DISABLED"
_RESOURCE_TRACKER_THRESHOLD_ENV = "METALGUARD_COLD_RESTART_AFTER_N"


@dataclass
class ResourceTracker:
    """Per-runner inference counter with cold-restart heuristic.

    Thread-safe. Counter resets on :meth:`reset` after a cold restart cycle.
    Defaults are conservative — based on community evidence in mlx-lm#1185
    that crashes happened "partway through LoRA training" with peak memory
    stable, suggesting descriptor exhaustion rather than RAM exhaustion.
    """

    cold_restart_after: int = _RESOURCE_TRACKER_DEFAULT_THRESHOLD
    _count: int = field(default=0, init=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False)
    _last_restart_at_count: int = field(default=0, init=False)

    def __post_init__(self) -> None:
        env_raw = os.environ.get(_RESOURCE_TRACKER_THRESHOLD_ENV, "").strip()
        if env_raw:
            try:
                env_val = int(env_raw)
                if env_val > 0:
                    object.__setattr__(self, "cold_restart_after", env_val)
            except ValueError:
                log.warning(
                    "metal-guard ResourceTracker: invalid %s=%r, using %d",
                    _RESOURCE_TRACKER_THRESHOLD_ENV, env_raw,
                    self.cold_restart_after,
                )

    def record_inference(self) -> int:
        """Increment counter; return new total."""
        with self._lock:
            self._count += 1
            return self._count

    def should_cold_restart(self) -> bool:
        """True iff cumulative inferences hit threshold.

        ``METALGUARD_COLD_RESTART_DISABLED=1`` short-circuits to False.
        """
        if os.environ.get(_RESOURCE_TRACKER_KILL_SWITCH_ENV) == "1":
            return False
        with self._lock:
            return self._count >= self.cold_restart_after

    def reset(self) -> int:
        """Zero the counter after a cold-restart cycle. Returns prior count."""
        with self._lock:
            prior = self._count
            self._last_restart_at_count = prior
            self._count = 0
            return prior

    def snapshot(self) -> dict[str, Any]:
        """Read-only state for status / dashboard."""
        with self._lock:
            return {
                "current_count": self._count,
                "threshold": self.cold_restart_after,
                "fraction_used": (
                    self._count / self.cold_restart_after
                    if self.cold_restart_after > 0 else 0.0
                ),
                "last_restart_at_count": self._last_restart_at_count,
                "kill_switch_active": (
                    os.environ.get(_RESOURCE_TRACKER_KILL_SWITCH_ENV) == "1"
                ),
            }


_GLOBAL_RESOURCE_TRACKER: ResourceTracker | None = None


def global_resource_tracker() -> ResourceTracker:
    """Lazy-initialised singleton :class:`ResourceTracker`."""
    global _GLOBAL_RESOURCE_TRACKER
    if _GLOBAL_RESOURCE_TRACKER is None:
        _GLOBAL_RESOURCE_TRACKER = ResourceTracker()
    return _GLOBAL_RESOURCE_TRACKER


def _reset_global_resource_tracker() -> None:
    """Test helper — production callers should not need this."""
    global _GLOBAL_RESOURCE_TRACKER
    _GLOBAL_RESOURCE_TRACKER = None
